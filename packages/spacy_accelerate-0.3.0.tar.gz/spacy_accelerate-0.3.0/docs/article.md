# Ускорение spaCy-трансформеров через TensorRT и ONNX Runtime

## Проблема

spaCy — де-факто стандарт для production NLP-пайплайнов. Модели типа `en_core_web_trf` используют трансформеры (RoBERTa, BERT) как feature-extractor: на каждый батч текстов трансформер делает forward pass, результат идёт в компоненты NER, POS-теггера и других.

Проблема в том, что PyTorch сам по себе не оптимален для инференса. Он был написан для обучения: граф вычислений строится динамически, каждый оператор запускается отдельно, есть overhead на Python-уровне, автодифференцирование тянет за собой граф для градиентов, которые для инференса не нужны.

При продакшн-нагрузке это заметно. На NVIDIA RTX 4090, CoNLL-2003, батч 128:

| Режим                  | WPS    | Ускорение |
|------------------------|--------|-----------|
| PyTorch FP32 (baseline)| ~16 800| 1.00×     |
| PyTorch FP16 (autocast)| ~18 000| 1.07×     |
| ONNX Runtime CUDA FP32 | ~17 000| 1.01×     |
| ONNX Runtime CUDA FP16 | ~24 500| 1.46×     |
| TensorRT FP32          | ~19 000| 1.13×     |
| **TensorRT FP16**      |**~27 000**|**1.60×** |

Цель — получить TensorRT FP16 с точностью NER ≥ 99% относительно baseline.

---

## Как устроен spaCy изнутри

### Архитектура пайплайна

```
nlp("Apple was founded by Steve Jobs")
         │
         ▼
┌─────────────────────────────────────────────────────────┐
│                  spaCy Language (nlp)                   │
│                                                         │
│  ┌──────────────┐  ┌──────────────┐  ┌───────────────┐ │
│  │  tokenizer   │→ │  transformer │→ │      ner      │ │
│  └──────────────┘  └──────────────┘  └───────────────┘ │
│                           │                             │
│                    ┌──────▼──────┐                      │
│                    │  tagger /   │                      │
│                    │  parser /   │                      │
│                    │  lemmatizer │                      │
│                    └─────────────┘                      │
└─────────────────────────────────────────────────────────┘
```

Компонент `transformer` — ключевое звено. Он принимает batch документов, прогоняет их через трансформер и записывает hidden states в `Doc._.trf_data`. Все последующие компоненты читают эти векторы.

### Внутренняя структура transformer-компонента

spaCy использует библиотеку **thinc** как слой абстракции над ML-фреймворками. Это создаёт вложенную иерархию объектов:

```
TransformerModel (spaCy component)
    └── thinc Model
            └── PyTorchShim          ← точка входа в PyTorch
                    └── _model       ← curated-transformers или HF-модель
                            └── RoBERTa / BERT / XLM-R / DistilBERT
```

`PyTorchShim` — обёртка, которая принимает данные из thinc-мира (ragged arrays, xp-arrays) и вызывает обычный `nn.Module.forward()`. Именно `_model` внутри шима мы заменяем.

---

## Подход к ускорению

Идея простая: PyTorch нужен для обучения, для инференса он избыточен. Нужно:

1. Один раз экспортировать модель в статичный граф (ONNX)
2. Запустить его через специализированный inference-движок (TensorRT или ORT)
3. Подменить `shim._model` на прокси-объект с тем же интерфейсом

Пользователь вызывает один метод:

```python
nlp = spacy_accelerate.optimize(nlp, provider="tensorrt", precision="fp16")
```

После этого `nlp` работает как обычно — тот же API, те же методы, но transformer forward pass идёт через TensorRT.

### Pipeline оптимизации

```
optimize(nlp)
    │
    ├─ 1. Validate pipeline
    │      проверяем наличие transformer-компонента
    │
    ├─ 2. Find transformer shim
    │      рекурсивно обходим thinc-иерархию,
    │      ищем PyTorchShim
    │
    ├─ 3. Detect architecture
    │      читаем state_dict, определяем
    │      num_layers и hidden_size
    │
    ├─ 4. Build OptimizeConfig
    │      собираем конфигурацию runtime
    │
    ├─ 5. Check provider
    │      TensorrtExecutionProvider доступен?
    │
    ├─ 6. Get or export ONNX model  ─────────────────────────────┐
    │      cache hit? → берём готовый файл                       │
    │      cache miss? → конвертируем                            │
    │                                                            │
    ├─ 7. Create proxy (IOBindingProxy / ORTProxy / CPUProxy)    │
    │                                                            │
    ├─ 8. Patch pipeline                                         │
    │      shim._original_model = shim._model                    │
    │      shim._model = proxy                                   │
    │                                                            │
    └─ 9. Warmup inference                                       │
           прогреваем движок, компилируем TRT-ядра              │
                                                                 │
─────────────────────── конвертация ─────────────────────────────┘
export_to_onnx(shim, output_dir, precision)
    │
    ├─ map_weights_to_hf()     ← перекладываем веса в HF-формат
    ├─ create_hf_model()       ← создаём HF-модель с этими весами
    ├─ _verify_parity()        ← проверяем совпадение выходов
    ├─ torch.onnx.export()     ← экспортируем в ONNX
    └─ convert_to_fp16()       ← (если fp16) конвертируем
```

---

## Конвертация весов: самая нетривиальная часть

spaCy использует библиотеку **curated-transformers** со своим форматом хранения весов. Он отличается от HuggingFace. Чтобы экспортировать модель в ONNX, нужна HF-модель — значит, надо переложить веса.

### Разница форматов: Multi-Head Attention

Главная проблема — матрицы Q, K, V. В curated-transformers они объединены в одну:

```
curated-transformers:
    mha.input.weight    shape: (3 × hidden, hidden)   ← Q, K, V вместе
    mha.output.weight   shape: (hidden, hidden)

HuggingFace RoBERTa:
    attention.self.query.weight   shape: (hidden, hidden)
    attention.self.key.weight     shape: (hidden, hidden)
    attention.self.value.weight   shape: (hidden, hidden)
    attention.output.dense.weight shape: (hidden, hidden)
```

Разбиваем `mha.input.weight` по dim=0:
```python
q_w, k_w, v_w = torch.chunk(mha_in_weight, 3, dim=0)
```

### Полная карта переименований

```
curated-transformers                           →  HuggingFace RoBERTa
──────────────────────────────────────────────────────────────────────────
Embeddings:
  embeddings.inner.word_embeddings.weight      →  embeddings.word_embeddings.weight
  embeddings.inner.position_embeddings.weight  →  embeddings.position_embeddings.weight
  embeddings.inner.token_type_embeddings.weight→  embeddings.token_type_embeddings.weight
  embeddings.inner.layer_norm.{weight, bias}   →  embeddings.LayerNorm.{weight, bias}

Слой i:
  layers.{i}.mha.input.weight [chunk 0]        →  layer.{i}.attention.self.query.weight
  layers.{i}.mha.input.weight [chunk 1]        →  layer.{i}.attention.self.key.weight
  layers.{i}.mha.input.weight [chunk 2]        →  layer.{i}.attention.self.value.weight
  layers.{i}.mha.input.bias [chunk 0,1,2]      →  layer.{i}.attention.self.{q,k,v}.bias
  layers.{i}.mha.output.weight                 →  layer.{i}.attention.output.dense.weight
  layers.{i}.attn_output_layernorm.weight      →  layer.{i}.attention.output.LayerNorm.weight
  layers.{i}.ffn.intermediate.{weight, bias}   →  layer.{i}.intermediate.dense.{weight, bias}
  layers.{i}.ffn.output.{weight, bias}         →  layer.{i}.output.dense.{weight, bias}
  layers.{i}.ffn_output_layernorm.weight       →  layer.{i}.output.LayerNorm.weight
```

После маппинга создаём HF-модель (`RobertaModel`, `BertModel`, etc.), загружаем веса через `load_state_dict(strict=False)` и проверяем parity: прогоняем dummy input через обе модели, сравниваем max absolute diff — должно быть < 1e-4.

### ONNX export

```python
torch.onnx.export(
    ONNXWrapper(hf_model),          # Обёртка: возвращает только last_hidden_state
    (dummy_input_ids, dummy_mask),
    onnx_path,
    input_names=["input_ids", "attention_mask"],
    output_names=["last_hidden_state"],
    dynamic_axes={                  # Динамические оси для батча и длины
        "input_ids":        {0: "batch", 1: "seq"},
        "attention_mask":   {0: "batch", 1: "seq"},
        "last_hidden_state":{0: "batch", 1: "seq"},
    },
    opset_version=17,
)
```

Важный момент: `batch_size=2` в dummy input, а не 1. Если передать 1, ONNX-оптимизатор может статически вывести batch dimension = 1 через constant folding. При `batch_size=2` это невозможно — ось остаётся динамической.

### FP16 конвертация

Применяем ONNX Runtime transformer optimizer:

```python
optimizer.optimize_model(
    onnx_path,
    model_type="bert",
    optimization_options=FusionOptions(...)
)
model.convert_float_to_float16(keep_io_types=True)
```

`keep_io_types=True` — критично: входы (`int64` input_ids) и выход (`float32`) остаются в оригинальных типах. Только внутренние операции переводятся в FP16.

`enable_bias_gelu = False` — отключаем, потому что TensorRT не поддерживает этот кастомный ORT-оператор. Остальные фьюжны (LayerNorm, MHA, GELU) применяются.

---

## Кеширование ONNX-моделей

Экспорт занимает 20-60 секунд. Повторять его при каждом запуске неприемлемо.

Ключ кеша строится из:

```python
cache_key = SHA256({
    "name":               nlp.meta["name"],        # "en_core_web_trf"
    "version":            nlp.meta["version"],      # "3.8.0"
    "lang":               nlp.meta["lang"],         # "en"
    "precision":          "fp16",
    "fixed_batch_size":   None,
    "structure_hash":     SHA256(sorted first 20 state_dict keys)[:8],
    "first_weight_shape": str(state_dict[first_key].shape),
})[:16]
```

`structure_hash` и `first_weight_shape` — страховка от модификации весов в runtime. Если модель менялась, ключ изменится и экспорт произойдёт заново.

Структура кеша:

```
~/.cache/spacy-accelerate/
├── a3f1b2c4d5e6f7a8/
│   ├── model.onnx
│   └── model_fp16.onnx
├── 9d8e7f6a5b4c3d2e/
│   └── model_fp16.onnx
└── trt_engines/
    ├── TensorrtExecutionProvider_cache_...
    └── ...
```

TensorRT отдельно кеширует скомпилированные GPU-ядра в `trt_engines/`. При совпадении формы входа TRT переиспользует готовый engine, не компилируя заново.

---

## Runtime: что происходит при каждом forward pass

### Без IO Binding (ORTProxy)

```
PyTorch GPU tensor
    │
    ▼
.cpu().numpy()       ← D2H transfer (медленно)
    │
    ▼
ORT CUDA session     ← инференс на GPU, но входы/выходы через CPU
    │
    ▼
torch.from_numpy()
.to(device)          ← H2D transfer (медленно)
    │
    ▼
UniversalTransformerOutput
```

Есть два roundtrip через CPU. При большом batch и коротких последовательностях transfer overhead может доминировать.

### С IO Binding (IOBindingProxy) — основной режим

```
PyTorch GPU tensor
    │
    │  data_ptr() → GPU-адрес буфера
    │
    ▼
ORT IO Binding
    │  input:  binding.bind_input(..., buffer_ptr=ids.data_ptr())
    │  output: binding.bind_output(..., buffer_ptr=out.data_ptr())
    │
    ▼
session.run_with_iobinding(binding)   ← данные не покидают GPU
    │
    ▼
output_tensor (уже на GPU)
    │
    ▼
UniversalTransformerOutput
```

IO Binding передаёт в ONNX Runtime не данные, а указатели на GPU-память. Движок читает входы и пишет выходы напрямую в GPU-буферы. Никаких D2H/H2D трансферов.

### Batch bucketing для TensorRT

TensorRT компилирует отдельное GPU-ядро для каждой формы входа. Если в рантайме приходят батчи разных размеров — каждый новый размер вызывает компиляцию (100-500ms). Это неприемлемо.

Решение — batch buckets: заранее определяем набор размеров и паддим каждый батч до ближайшего сверху:

```
Батч из 25 документов, buckets = [1, 8, 32, 64, 128]

25 → паддим до 32
          │
          ▼
┌──────────────────────┐
│  [doc1 ... doc25     │  ← реальные данные
│   PAD PAD PAD PAD PAD│  ← 7 padding rows
│   PAD ... PAD        │
└──────────────────────┘
          │
          ▼  TRT engine для batch=32 (уже скомпилирован)
          │
          ▼
output[0:25, :, :]       ← берём только реальные строки
```

При инициализации прокси делается warmup по всем bucket-размерам — компилируем все ядра заранее, в рантайме компиляций нет.

Аналогично работает `fixed_seq_length`: если известна максимальная длина последовательности (например, 144 токена для `en_core_web_trf`), паддим всегда до неё — TRT может дополнительно оптимизировать под фиксированную форму.

---

## Совместимость выходов: UniversalTransformerOutput

ONNX экспортирует только `last_hidden_state` — финальный слой трансформера. Но spaCy и разные версии spacy-transformers обращаются к атрибутам по-разному:

```python
# Разные части кода используют разные имена:
output.embedding_output
output.last_hidden_layer_state
output.all_hidden_layer_states[i]
output.layer_hidden_states
output.all_outputs
```

Создаём объект-обёртку, который под всеми этими именами возвращает один и тот же финальный hidden state:

```python
class UniversalTransformerOutput:
    def __init__(self, hidden_state, num_layers):
        self.embedding_output          = hidden_state
        self.last_hidden_layer_state   = hidden_state
        self.all_hidden_layer_states   = [hidden_state] * num_layers
        self.layer_hidden_states       = self.all_hidden_layer_states
        self.last_hidden_layer_states  = self.all_hidden_layer_states
        self.all_outputs               = self.all_hidden_layer_states
        self.num_layers                = num_layers
```

Это упрощение: все "слои" одинаковы. Для задач NER/POS это не проблема — они используют только финальный слой. Для probing по промежуточным слоям потребовался бы полный экспорт.

---

## Режимы работы

### TensorRT FP16 — максимальная скорость

```python
nlp = spacy_accelerate.optimize(
    nlp,
    provider="tensorrt",
    precision="fp16",
    trt_max_workspace_size=4 * 1024**3,      # GPU-память для TRT-ядер
    trt_builder_optimization_level=3,         # 0-5, выше = медленнее компиляция
    trt_timing_cache=True,                    # кешировать timing при компиляции
    batch_buckets=[8, 16, 64, 128],          # размеры батчей для прекомпиляции
    fixed_seq_length=144,                    # фиксированная длина (опционально)
)
```

Первый запуск после чистого кеша: 2-5 минут на компиляцию TRT-ядер.
Все последующие запуски: ядра берутся из кеша, warmup ~10 секунд.

### ONNX Runtime CUDA FP16

```python
nlp = spacy_accelerate.optimize(
    nlp,
    provider="cuda",
    precision="fp16",
)
```

Нет времени на компиляцию TRT. Быстрый старт, хорошая скорость. Хороший выбор если TRT недоступен или не нужна максимальная производительность.

### CPU

```python
nlp = spacy_accelerate.optimize(
    nlp,
    provider="cpu",
    precision="fp32",
)
```

Без GPU. Скорость ниже PyTorch за счёт ORT-оптимизаций графа, но на практике выигрыш небольшой.

---

## Поддерживаемые модели

| spaCy модель         | Архитектура  | Статус     |
|----------------------|--------------|------------|
| en_core_web_trf      | RoBERTa      | Протестировано |
| xx_ent_wiki_sm       | XLM-RoBERTa  | Протестировано |
| BERT-based           | BERT         | Поддерживается |
| DistilBERT-based     | DistilBERT   | Поддерживается |

Автоматическое определение архитектуры — по ключам `state_dict`:

```
"curated_encoder" в ключах  →  curated-transformers (spaCy native)
"roberta" в ключах          →  RoBERTa
"distilbert" в ключах       →  DistilBERT
"xlm" в ключах              →  XLM-RoBERTa
иначе                       →  BERT
```

---

## Ограничения

**Только inference.** Граф заморожен после экспорта. Fine-tuning через spacy-accelerate невозможен — нет градиентов.

**Только финальный hidden state.** ONNX экспортирует один выход. Если downstream-компонент использует промежуточные слои, они будут одинаковы (дубликат финального).

**Формы батчей.** TensorRT требует заранее известных форм. Для нетипичных размеров батчей нужно добавить их в `batch_buckets`. Иначе при первом появлении нового размера будет пауза на компиляцию.

**CUDA 12.x.** Весь стек (PyTorch, TensorRT, cupy, onnxruntime-gpu) собран под CUDA 12. CUDA 11 не поддерживается.

**Только GPU.** CPU-режим работает, но TensorRT и IO Binding доступны только с NVIDIA GPU.

**Один GPU.** Мульти-GPU не реализован. `device_id` выбирает конкретное устройство, но параллелизм по нескольким GPU не поддерживается.

---

## Установка

```bash
# Шаг 1: пакет + TensorRT Python bindings
pip install spacy-accelerate

# Шаг 2: NVIDIA-сборка onnxruntime-gpu с TensorRT EP
# (стандартная PyPI-сборка TensorRT EP не включает)
pip install --force-reinstall \
    --extra-index-url https://pypi.nvidia.com \
    onnxruntime-gpu==1.23.2

# Проверка
python -m spacy_accelerate
# Ожидаемый вывод:
# TensorRT EP      : OK
# CUDA EP          : OK
```

---

## Итог

Ключевые решения, которые дают результат:

**IO Binding** — устраняет основной bottleneck PyTorch-инференса: данные остаются на GPU, никаких roundtrip через CPU.

**Batch bucketing** — делает TensorRT предсказуемым в production: все ядра компилируются один раз при старте, в рантайме нет пауз.

**Weight mapping** — позволяет использовать HuggingFace как промежуточный формат для ONNX-экспорта, не меняя spaCy-модели.

**Transparent patching** — замена `shim._model` не трогает остальной пайплайн. NER, POS-теггер, лемматизатор работают без изменений.

**Кеширование** — экспорт и компиляция TRT-ядер происходят один раз. Последующие запуски начинают работу через ~10 секунд.
