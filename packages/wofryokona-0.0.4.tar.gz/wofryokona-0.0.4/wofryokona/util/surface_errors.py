#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import numpy as np

from okona.surface_error_generator import SurfaceErrorGenerator

__surface_error_generator = SurfaceErrorGenerator()

def generate_figure_error_from_psd(mirror_length: float,
                                   slope_error_rms: float,
                                   sampling_step: float=1e-3,
                                   beta:float=2.5) ->  tuple[np.ndarray, np.ndarray]: 
    return __surface_error_generator.generate_figure_error_from_psd(mirror_length=mirror_length,
                                                                  slope_error_rms=slope_error_rms,
                                                                  sampling_step=sampling_step,
                                                                  alpha=beta)


def generate_figure_error_from_ar_model(mirror_length: float,
                                        slope_error_rms: float,
                                        sampling_step: float=1e-3,
                                        ar_coefficients: np.ndarray | None=None) -> tuple[np.ndarray, np.ndarray]:
    return __surface_error_generator.generate_figure_error_from_ar_model(mirror_length=mirror_length,
                                                                         slope_error_rms=slope_error_rms,
                                                                         sampling_step=sampling_step,
                                                                         ar_coeffs=ar_coefficients)

def generate_microroughness_from_broken_power_law(patch_length: float,
                                                  height_error_rms: float,
                                                  correlation_length: float,
                                                  n_low: float,
                                                  n_high: float,
                                                  sampling_step: float=5e-7) ->  tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    x, mr_profile, frequencies, psd = __surface_error_generator.generate_microroughness_from_broken_power_law(length=patch_length,
                                                                                                              height_rms=height_error_rms,
                                                                                                              correlation_length=correlation_length,
                                                                                                              n_low=n_low,
                                                                                                              n_high=n_high,
                                                                                                              sampling_step=sampling_step)

    # convert in Wavelength (um), PSD (nm^2 * um)
    valid      = frequencies > 0
    wavelength = (1 / frequencies[valid]) * 1e6
    psd        = psd[valid] * 1e24

    return x, mr_profile, wavelength, psd




