#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
from typing import List

import numpy as np
from matplotlib import gridspec
from matplotlib.figure import Figure
from scipy.ndimage import gaussian_filter1d

from okona.beamline_manager import ResultsManager
from okona.optics_elements import PlaneMirror, EllipticalMirror, Slit

def get_oe_names(results: dict):
    result_manager = ResultsManager(results)
    return [element['constructor_args']['name'] for element in result_manager.config['elements']][:-1] # no detector

def get_oe_with_surface_errors_names(results: dict):
    result_manager = ResultsManager(results)
    return [element['constructor_args']['name'] for element in result_manager.config['elements'] if 'surface_config' in element]

def draw_source_figure(figure: Figure, results: dict):
    result_manager = ResultsManager(results)

    total_source_intensity = result_manager.intensities[0]
    source_fwhm            = result_manager._compute_fwhm(result_manager.history[0]['x'], total_source_intensity)

    figure.clear()
    figure.gca().plot(result_manager.history[0]['x'] * 1e6, total_source_intensity / np.max(total_source_intensity), color='purple')
    figure.gca().set_title(f'Effective Source Intensity (Sum of {result_manager.source.num_modes} Modes)')
    figure.gca().set_xlabel("Position (µm)")
    figure.gca().set_ylabel("Normalized Intensity")
    figure.gca().grid(True)
    target_size_fwhm = result_manager.config.get('target_size_fwhm', 0)
    if source_fwhm > 0: figure.gca().set_xlim(-4 * source_fwhm * 1e6, 4 * source_fwhm * 1e6)
    figure.gca().text(0.95, 0.9, f'Source FWHM, Effective: {source_fwhm * 1e6:.2f} µm\nTarget: {target_size_fwhm * 1e6:.2f} µm',
                      ha='right', fontsize=8, transform=figure.gca().transAxes)

def draw_oe_surface_errors_figures(figures: List[Figure], results: dict):
    result_manager = ResultsManager(results)

    oe_index = -1
    for element in result_manager.config['elements']:
        if 'surface_config' in element:
            oe_index += 1
            figure = figures[oe_index]
            figure.clear()
            axs = figure.subplots(1, 2)

            name_key     = element['constructor_args']['name']
            figure_error = element['surface_config']['figure_error_data']
            roughness    = result_manager.roughness.get(name_key, result_manager.roughness.get(name_key)) if result_manager.roughness else None

            # Plot Figure Error
            ax = axs[0]
            if figure_error and figure_error[0] is not None and len(figure_error[1]) > 0:
                ax.plot(figure_error[0] * 1000, figure_error[1] * 1e9)
                ax.set_title(f"{name_key} Figure Error (RMS: {np.std(figure_error[1] * 1e9):.3f} nm)", fontsize=8)
            else:
                ax.set_title(f"{name_key} Figure Error (Not Loaded)", fontsize=8)
            ax.set_ylabel("Height (nm)")
            ax.set_xlabel("Position (mm)")
            ax.grid(True)

            # Plot Roughness
            ax = axs[1]
            if roughness and roughness[0] is not None and len(roughness[1]) > 0:
                ax.plot(roughness[0] * 1000, roughness[1] * 1e9)
                ax.set_title(f"{name_key} Roughness (RMS: {np.std(roughness[1] * 1e9):.3f} nm)", fontsize=8)
            else:
                ax.set_title(f"{name_key} Roughness (Not Generated)", fontsize=8)
            ax.set_ylabel("Height (nm)")
            ax.set_xlabel("Position (mm)")
            ax.grid(True)

            figure.tight_layout()

def draw_oe_intensity_figures(figures: List[Figure], results: dict):
    result_manager = ResultsManager(results)

    oe_index = -1
    for step, intensity in zip(result_manager.history[1:-1], result_manager.intensities[1:-1]):
        oe_index += 1
        figure = figures[oe_index]
        figure.clear()

        if np.max(intensity) == 0: continue
        element_obj = step['element_object']

        if isinstance(element_obj, (PlaneMirror, EllipticalMirror)):
            if np.sin(element_obj.angle) > 1e-9:
                x_footprint         = step['x'] / np.sin(element_obj.angle)
                mirror_axis         = np.linspace(-element_obj.length / 2, element_obj.length / 2, 2048)
                intensity_on_mirror = np.interp(mirror_axis, x_footprint, intensity, left=0, right=0)
                if np.max(intensity_on_mirror) > 0: figure.gca().plot(mirror_axis * 1000, intensity_on_mirror / np.max(intensity_on_mirror))
                figure.gca().set_xlabel("Position along mirror (mm)")
            else:
                figure.gca().plot(step['x'] * 1e6, intensity / np.max(intensity))
                figure.gca().set_xlabel("Position (µm)")
        elif isinstance(element_obj, Slit):
            slit_fwhm = result_manager._compute_fwhm(step['x'], intensity)
            slit_hew  = result_manager._compute_hew(step['x'], intensity)
            figure.gca().plot(step['x'] * 1e6, intensity / np.max(intensity), color='darkcyan')
            figure.gca().set_title(f"Beam Profile at Slit\nFWHM = {slit_fwhm*1e6:.2f} µm | HEW = {slit_hew*1e6:.2f} µm")
            figure.gca().set_xlabel("Position (µm)")
            figure.gca().set_ylabel("Normalized Intensity")
            figure.gca().grid(True)
            if slit_fwhm > 0: figure.gca().set_xlim(-4 * slit_fwhm * 1e6, 4 * slit_fwhm * 1e6)
        else:
            figure.gca().plot(step['x'] * 1e6, intensity / np.max(intensity))
            figure.gca().set_xlabel("Position (µm)")

        figure.gca().set_title(f"Intensity at: {step['name']} (Sum of All Modes)")
        figure.gca().set_ylabel("Norm. Intensity")
        figure.gca().grid(True)

        figure.tight_layout()

def draw_detector_figure(figure: Figure, results: dict, sigma_smooth: int=1):
    result_manager = ResultsManager(results)

    total_detector_intensity = result_manager.intensities[-1]
    final_detector_x_axis    = result_manager.history[-1]['x']

    figure.clear()

    if np.max(total_detector_intensity) > 0:
        smoothed_I = gaussian_filter1d(total_detector_intensity, sigma=sigma_smooth)

        gs = gridspec.GridSpec(
            nrows=2,
            ncols=2,
            width_ratios=[4, 1],  # 80% / 20%
            hspace=0.4,  # vertical spacing between the two left plots
            wspace=0.05,  # horizontal spacing between columns
        )

        # --- Left column: two stacked plots ---
        ax_top = figure.add_subplot(gs[0, 0])
        ax_top.plot(final_detector_x_axis * 1e6, total_detector_intensity / np.max(total_detector_intensity), label='Raw Intensity', alpha=0.3)
        ax_top.set_xlabel("Position (µm)")
        ax_top.set_ylabel("Normalized Intensity")
        ax_top.grid(True)
        ax_top.legend()

        ax_bottom = figure.add_subplot(gs[1, 0])
        ax_bottom.plot(final_detector_x_axis * 1e6, smoothed_I / np.max(smoothed_I), label='Smoothed Intensity', color='firebrick')
        ax_bottom.set_xlabel("Position (µm)")
        ax_bottom.set_ylabel("Normalized Intensity")
        ax_bottom.grid(True)
        ax_bottom.legend()

        final_fwhm = result_manager._compute_fwhm(final_detector_x_axis, smoothed_I)
        final_hew  = result_manager._compute_hew(final_detector_x_axis, smoothed_I)

        final_coherence_length = result_manager.source.sigma_mu
        target_size_fwhm       = result_manager.config.get('target_size_fwhm', 0)
        target_divergence_fwhm = result_manager.config.get('target_divergence_fwhm', 0)
        wavelength             = result_manager.config.get('wavelength', 1e-10)

        # Calculate Theoretical Visibility (from phase space area)
        fwhm_to_rms            = 1 / (2 * np.sqrt(2 * np.log(2)))
        total_sigma_s          = target_size_fwhm * fwhm_to_rms
        total_sigma_div        = target_divergence_fwhm * fwhm_to_rms
        phase_space_area       = total_sigma_s * total_sigma_div
        diffraction_limit      = wavelength / (4 * np.pi)
        theoretical_visibility = min(1.0, diffraction_limit / phase_space_area) if phase_space_area > 0 else 1.0

        if final_coherence_length is not None and np.isfinite(final_coherence_length) and final_coherence_length > 0:
            global_coherence = final_coherence_length / total_sigma_s

            # Calculate Simulated Visibility (from GSM M-factor)
            M_factor = np.sqrt(1 + (2 * total_sigma_s / final_coherence_length) ** 2)
            simulated_visibility = 1.0 / M_factor

            coherence_text  = f"Total RMS Source Size (sigma_s):\n{total_sigma_s * 1e6:.3f} µm\n\n"
            coherence_text += f"Transverse Coherence Length (sigma_mu):\n{final_coherence_length * 1e6:.3f} µm\n\n"
            coherence_text += f"Global Coherence Degree (sigma_mu / sigma_s):\n{global_coherence:.4f}\n\n"
            coherence_text += f"Simulated 1D Coherent Fraction (1/M): {simulated_visibility * 100:.2f}%"
        else:
            coherence_text  = f"Source is Fully Coherent (sigma_mu = infinity)\n"
            coherence_text += f"Simulated 1D Coherent Fraction: 100.00%"

        ax_top.set_title(f'Final Detector Spot (Sum of {result_manager.source.num_modes} Modes)\n'
                         f'FWHM = {final_fwhm * 1e6:.4f} µm | HEW = {final_hew * 1e6:.4f} µm')

        text  = f"Final Spot FWHM (smoothed):\n{final_fwhm * 1e6:.4f} µm\n\n"
        text += f"Final Spot HEW (smoothed):\n{final_hew * 1e6:.4f} µm\n"
        text += f"\n--- Source Coherence Properties ---\n\n"
        text += f"Total Source FWHM Size:\n{target_size_fwhm * 1e6:.3f} µm\n\n"
        text += f"Total Source FWHM Divergence:\n{target_divergence_fwhm * 1e6:.3f} µrad\n\n"
        text += f"Theoretical 1D Coherent Fraction:\n{theoretical_visibility * 100:.2f}%\n\n"
        text += coherence_text

        ax_text = figure.add_subplot(gs[:, 1])
        ax_text.axis("off")
        ax_text.text(x=0.02, y=0.2, s=text, fontsize=8, wrap=True, transform=ax_text.transAxes)
