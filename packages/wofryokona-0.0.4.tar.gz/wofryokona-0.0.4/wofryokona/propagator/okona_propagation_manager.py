#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #

from okona.beamline_manager import SimulationRunner
from okona.simulation_functions import simulate_single_mode_ray_tracing, simulate_single_mode_wave_optics

from wofryokona.beamline.okona_beamline import OKONABeamline

class OKONAPropagationModes:
    RAY_TRACING = 'ray_tracing'
    WAVE_OPTICS = 'wave_optics'

class OKONAPropagationManager:

    @staticmethod
    def do_propagation(beamline: OKONABeamline,
                       propagation_mode: str = OKONAPropagationModes.WAVE_OPTICS,
                       **kwargs) -> dict:
        """

        :param wavelength:
        :param beamline:
        :param simulation_plane:
        :param propagation_mode:
        :param kwargs:
        :return: a dictionary with the following keys: history_for_plotting,
                                                       total_history_intensities,
                                                       roughness_for_plotting,
                                                       source,
                                                       beamline_config

        """
        if   propagation_mode == OKONAPropagationModes.RAY_TRACING: simulate_single_mode_func = simulate_single_mode_ray_tracing
        elif propagation_mode == OKONAPropagationModes.WAVE_OPTICS: simulate_single_mode_func = simulate_single_mode_wave_optics
        else: raise ValueError("Unknown propagation mode")


        simulation_plane = beamline.get_light_source().simulation_plane
        source           = beamline.get_light_source().okona_source

        # --- 7. Run the Simulation ---
        runner = SimulationRunner(source=source,
                                  beamline_config=beamline.to_okona_beamline_config(simulation_plane=simulation_plane,
                                                                                    wavelength=source.wavelength,
                                                                                    **kwargs),
                                  simulate_single_mode_func=simulate_single_mode_func)

        if kwargs.get("parallel", True): return runner.run_parallel()
        else:                            return runner.run_sequential()