#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
from typing import Any

import numpy as np

from okona.surface_errors import SurfaceManager
from syned.beamline.element_coordinates import ElementCoordinates
from syned.beamline.optical_elements.mirrors.mirror import Mirror
from syned.beamline.shape import SurfaceShape, Rectangle, Plane, EllipticalCylinder, Direction, Convexity, HyperbolicCylinder, SphericalCylinder, ParabolicCylinder, Toroid
from wofryokona.beamline.okona_beamline_element import OKONABeamlineElement, OKONAPropagators
from wofryokona.beamline.optical_elements.okona_optical_element import OKONAOpticalElement, OKONAOpticalElements
from wofryokona.storage_ring.okona_light_source import OKONASimulationPlane

class MirrorOrientation:
    UP   = 0
    DOWN = 1
    LEFT  = 2
    RIGHT = 3

    @staticmethod
    def angle_azimuthal(orientation: int):
        if   orientation == MirrorOrientation.UP:    return 0.0
        elif orientation == MirrorOrientation.DOWN:  return np.pi
        elif orientation == MirrorOrientation.LEFT:  return 0.5*np.pi
        elif orientation == MirrorOrientation.RIGHT: return 1.5*np.pi
        else: raise ValueError("Orientation must be UP, DOWN, LEFT, or RIGHT")

class OKONAMirror(Mirror, OKONAOpticalElement):
    def __init__(self,
                 name: str = "Mirror",
                 width: float = 0.0,
                 length: float = 0.0,
                 grazing_angle: float = 0.0,
                 surface_shape: SurfaceShape = None,
                 figure_error_data_file: str | None =None,
                 psd_data_file: str | None = None,
                 axis_points: float = 2**15,
                 high_pass_wavelength_cutoff_m: Any = None):
        boundary_shape = Rectangle()
        boundary_shape.set_width_and_length(width, length)
        Mirror.__init__(self,name, surface_shape, boundary_shape)

        self._grazing_angle                 = grazing_angle
        self._figure_error_data_file        = figure_error_data_file
        self._psd_data_file                 = psd_data_file
        self._axis_points                   = axis_points
        self._high_pass_wavelength_cutoff_m = high_pass_wavelength_cutoff_m

    def _has_surface_config(self): return True

    def _get_okona_element_type(self):
        if   isinstance(self.get_surface_shape(), Plane):              return OKONAOpticalElements.PLANE_MIRROR
        elif isinstance(self.get_surface_shape(), EllipticalCylinder): return OKONAOpticalElements.ELLIPTICAL_MIRROR
        elif isinstance(self.get_surface_shape(), HyperbolicCylinder): return OKONAOpticalElements.HYPERBOLIC_MIRROR
        elif isinstance(self.get_surface_shape(), SphericalCylinder):  return OKONAOpticalElements.SPHERICAL_MIRROR
        elif isinstance(self.get_surface_shape(), ParabolicCylinder):  return OKONAOpticalElements.PARABOLIC_MIRROR
        elif isinstance(self.get_surface_shape(), Toroid):             return OKONAOpticalElements.TOROIDAL_MIRROR
        else: raise ValueError("Surface shape not recognized")

    def _get_okona_constructor_args(self, simulation_plane: str = OKONASimulationPlane.VERTICAL, **kwargs):
        _, _, yt, yb = self.get_boundary_shape().get_boundaries()

        return {'length': abs(yt-yb), 'angle' : self._grazing_angle, 'name': self.get_name()}

    def _get_okona_surface_config(self, wavelength: float | None = None, **kwargs):
        config = {}
        if not self._figure_error_data_file is None:
            if wavelength is None: raise ValueError("wavelength must be provided if a figure error data file is provided")
            config.update({'figure_error_data': SurfaceManager(wavelength).load_figure_error(self._figure_error_data_file)})
        else:
            config.update({'figure_error_data': (None, None)})

        if not self._psd_data_file is None:
            config.update({'psd_filepath': self._psd_data_file})
        else:
            config.update({'psd_filepath': None})

        config.update({'axis_points': self._axis_points,
                       'high_pass_wavelength_cutoff_m' : self._high_pass_wavelength_cutoff_m})

        return config

class OKONAMirrorBeamlineElementDecorator():
    def __init__(self, orientation = MirrorOrientation.UP):
        self._orientation = orientation

    def belongs(self, simulation_plane: str = OKONASimulationPlane.VERTICAL):
        return ((simulation_plane == OKONASimulationPlane.VERTICAL   and self._orientation in [MirrorOrientation.UP, MirrorOrientation.DOWN]) or
                (simulation_plane == OKONASimulationPlane.HORIZONTAL and self._orientation in [MirrorOrientation.LEFT, MirrorOrientation.RIGHT]))

class OKONAPlaneMirror(OKONAMirror):
    def __init__(self,
                 name="Plane Mirror",
                 width: float = 0.0,
                 length: float = 0.0,
                 grazing_angle: float = 0.0,
                 figure_error_data_file: str | None =None,
                 psd_data_file: str | None = None,
                 axis_points: float = 2**15,
                 high_pass_wavelength_cutoff_m: Any = None):
        OKONAMirror.__init__(self,
                             name=name,
                             width=width,
                             length=length,
                             grazing_angle=grazing_angle,
                             surface_shape=Plane(),
                             figure_error_data_file=figure_error_data_file,
                             psd_data_file=psd_data_file,
                             axis_points=axis_points,
                             high_pass_wavelength_cutoff_m=high_pass_wavelength_cutoff_m)

class OKONAPlaneMirrorElement(OKONABeamlineElement, OKONAMirrorBeamlineElementDecorator):
    def __init__(self,
                 name="Plane Mirror",
                 width: float = 0.0,
                 length: float = 0.0,
                 grazing_angle: float = 0.0,
                 orientation = MirrorOrientation.UP,
                 figure_error_data_file: str | None = None,
                 psd_data_file: str | None = None,
                 axis_points: float = 2 ** 15,
                 high_pass_wavelength_cutoff_m: Any = None,
                 distance: float = 0.0,
                 propagator: str = OKONAPropagators.FRESNEL,
                 max_points_before: float | None = None):
        coordinates = ElementCoordinates(p=distance,
                                         q=0.0,
                                         angle_radial=(0.5 * np.pi) - grazing_angle,
                                         angle_azimuthal=MirrorOrientation.angle_azimuthal(orientation),
                                         angle_radial_out=(0.5 * np.pi) - grazing_angle)
        optical_element = OKONAPlaneMirror(name=name,
                                           width=width,
                                           length=length,
                                           grazing_angle=grazing_angle,
                                           figure_error_data_file=figure_error_data_file,
                                           psd_data_file=psd_data_file,
                                           axis_points=axis_points,
                                           high_pass_wavelength_cutoff_m=high_pass_wavelength_cutoff_m)
        OKONABeamlineElement.__init__(self,
                                      optical_element=optical_element,
                                      coordinates=coordinates,
                                      distance=distance,
                                      propagator=propagator,
                                      max_points_before=max_points_before)
        OKONAMirrorBeamlineElementDecorator.__init__(self, orientation=orientation)

        self.__python_code = "beamline_element = OKONAPlaneMirrorElement("
        self.__python_code += f"\n  name='{name}',"
        self.__python_code += f"\n  width={width},"
        self.__python_code += f"\n  length={length},"
        self.__python_code += f"\n  grazing_angle={grazing_angle},"
        self.__python_code += f"\n  orientation={orientation},"
        self.__python_code += f"\n  figure_error_data_file='{figure_error_data_file}',"
        self.__python_code += f"\n  psd_data_file='{psd_data_file}',"
        self.__python_code += f"\n  axis_points={axis_points},"
        if type(high_pass_wavelength_cutoff_m) is str: self.__python_code += f"\n  high_pass_wavelength_cutoff_m='{high_pass_wavelength_cutoff_m}',"
        else:                                          self.__python_code += f"\n  high_pass_wavelength_cutoff_m={high_pass_wavelength_cutoff_m},"
        self.__python_code += f"\n  distance={distance},"
        self.__python_code += f"\n  propagator='{propagator}',"
        self.__python_code += f"\n  max_points_before={max_points_before}"
        self.__python_code += "\n)"

    def to_python_code(self) -> str: return self.__python_code

class OKONAEllipticalMirror(OKONAMirror):
    def __init__(self,
                 name="Elliptical Mirror",
                 width: float = 0.0,
                 length: float = 0.0,
                 p_distance: float = 0.0,
                 q_distance: float = 0.0,
                 grazing_angle: float = 0.0,
                 figure_error_data_file: str | None =None,
                 psd_data_file: str | None = None,
                 axis_points: float = 2**15,
                 high_pass_wavelength_cutoff_m: Any = 0.0):
        OKONAMirror.__init__(self,
                             name=name,
                             width=width,
                             length=length,
                             grazing_angle=grazing_angle,
                             surface_shape=EllipticalCylinder.create_elliptical_cylinder_from_p_q(p=p_distance,
                                                                                                  q=q_distance,
                                                                                                  grazing_angle=grazing_angle,
                                                                                                  convexity=Convexity.UPWARD,
                                                                                                  cylinder_direction=Direction.TANGENTIAL),
                             figure_error_data_file=figure_error_data_file,
                             psd_data_file=psd_data_file,
                             axis_points=axis_points,
                             high_pass_wavelength_cutoff_m=high_pass_wavelength_cutoff_m)

    def _get_okona_constructor_args(self, simulation_plane: str = OKONASimulationPlane.VERTICAL, **kwargs):
        config = super(OKONAEllipticalMirror, self)._get_okona_constructor_args(simulation_plane, **kwargs)
        surface_shape = self.get_surface_shape()

        if isinstance(surface_shape, EllipticalCylinder):
            p, q = surface_shape.get_p_q(self._grazing_angle)
            config.update({'p_distance' : p, 'q_distance': q})

        return config

class OKONAEllipticalMirrorElement(OKONABeamlineElement, OKONAMirrorBeamlineElementDecorator):
    def __init__(self,
                 name="Elliptical Mirror",
                 width: float = 0.0,
                 length: float = 0.0,
                 p_distance: float = 0.0,
                 q_distance: float = 0.0,
                 grazing_angle: float = 0.0,
                 orientation = MirrorOrientation.UP,
                 figure_error_data_file: str | None = None,
                 psd_data_file: str | None = None,
                 axis_points: float = 2 ** 15,
                 high_pass_wavelength_cutoff_m: Any = None,
                 distance: float = 0.0,
                 propagator: str = OKONAPropagators.FRESNEL,
                 max_points_before: float | None = None):
        coordinates = ElementCoordinates(p=distance,
                                         q=0.0,
                                         angle_radial=(0.5 * np.pi) - grazing_angle,
                                         angle_azimuthal=MirrorOrientation.angle_azimuthal(orientation),
                                         angle_radial_out=(0.5 * np.pi) - grazing_angle)
        optical_element = OKONAEllipticalMirror(name=name,
                                                width=width,
                                                length=length,
                                                p_distance=p_distance,
                                                q_distance=q_distance,
                                                grazing_angle=grazing_angle,
                                                figure_error_data_file=figure_error_data_file,
                                                psd_data_file=psd_data_file,
                                                axis_points=axis_points,
                                                high_pass_wavelength_cutoff_m=high_pass_wavelength_cutoff_m)
        OKONABeamlineElement.__init__(self,
                                      optical_element=optical_element,
                                      coordinates=coordinates,
                                      distance=distance,
                                      propagator=propagator,
                                      max_points_before=max_points_before)
        OKONAMirrorBeamlineElementDecorator.__init__(self, orientation=orientation)

        self.__python_code = "beamline_element = OKONAEllipticalMirrorElement("
        self.__python_code += f"\n  name='{name}',"
        self.__python_code += f"\n  width={width},"
        self.__python_code += f"\n  length={length},"
        self.__python_code += f"\n  p_distance={p_distance},"
        self.__python_code += f"\n  q_distance={q_distance},"
        self.__python_code += f"\n  grazing_angle={grazing_angle},"
        self.__python_code += f"\n  orientation={orientation},"
        self.__python_code += f"\n  figure_error_data_file='{figure_error_data_file}',"
        self.__python_code += f"\n  psd_data_file='{psd_data_file}',"
        self.__python_code += f"\n  axis_points={axis_points},"
        if type(high_pass_wavelength_cutoff_m) is str:
            self.__python_code += f"\n  high_pass_wavelength_cutoff_m='{high_pass_wavelength_cutoff_m}',"
        else:
            self.__python_code += f"\n  high_pass_wavelength_cutoff_m={high_pass_wavelength_cutoff_m},"
        self.__python_code += f"\n  distance={distance},"
        self.__python_code += f"\n  propagator='{propagator}',"
        self.__python_code += f"\n  max_points_before={max_points_before}"
        self.__python_code += "\n)"

    def to_python_code(self) -> str: return self.__python_code