#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import numpy as np

from syned.beamline.element_coordinates import ElementCoordinates
from syned.beamline.optical_elements.absorbers.slit import Slit
from syned.beamline.shape import Rectangle
from wofryokona.beamline.okona_beamline_element import OKONABeamlineElement, OKONAPropagators
from wofryokona.beamline.optical_elements.okona_optical_element import OKONAOpticalElement, OKONAOpticalElements
from wofryokona.storage_ring.okona_light_source import OKONASimulationPlane

class OKONADetector(Slit, OKONAOpticalElement):
    def __init__(self,
                 name: str = "Focal Plane",
                 width: float = 0.0,
                 height: float = 0.0,
                 N: int = 50048):
        boundary_shape = Rectangle()
        boundary_shape.set_width_and_length(width=width, length=height)
        Slit.__init__(self,
                      name=name,
                      boundary_shape=boundary_shape)
        self._N = N

    def _get_okona_element_type(self): return OKONAOpticalElements.DETECTOR

    def _get_okona_constructor_args(self, simulation_plane: str, **kwargs):
        xl, xr, yt, yb = self.get_boundary_shape().get_boundaries()

        if   simulation_plane == OKONASimulationPlane.VERTICAL:   return {'width' : abs(yb - yt), 'N' : self._N, 'name' : self.get_name()}
        elif simulation_plane == OKONASimulationPlane.HORIZONTAL: return {'width' : abs(xr - xl), 'N' : self._N, 'name' : self.get_name()}
        else: raise ValueError("Unknown simulation plane")


class OKONADetectorElement(OKONABeamlineElement):
    def __init__(self,
                 name: str = "Focal Plane",
                 width: float = 0.0,
                 height: float = 0.0,
                 N: int = 50048,
                 distance: float = 0.0,
                 propagator: str = OKONAPropagators.FRESNEL,
                 max_points_before: float | None = None):
        coordinates = ElementCoordinates(p=distance,
                                         q=0.0,
                                         angle_radial=0.0,
                                         angle_azimuthal=0.0,
                                         angle_radial_out=np.pi)
        optical_element = OKONADetector(name=name,
                                        width=width,
                                        height=height,
                                        N=N)
        OKONABeamlineElement.__init__(self,
                                      optical_element=optical_element,
                                      coordinates=coordinates,
                                      distance=distance,
                                      propagator=propagator,
                                      max_points_before=max_points_before)

        self.__python_code = "beamline_element = OKONADetectorElement("
        self.__python_code += f"\n  name='{name}',"
        self.__python_code += f"\n  width={width},"
        self.__python_code += f"\n  height={height},"
        self.__python_code += f"\n  N={N},"
        self.__python_code += f"\n  distance={distance},"
        self.__python_code += f"\n  propagator='{propagator}',"
        self.__python_code += f"\n  max_points_before={max_points_before}"
        self.__python_code += "\n)"

    def to_python_code(self) -> str: return self.__python_code