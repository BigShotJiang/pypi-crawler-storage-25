#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
from typing import List

from okona.beamline_manager import BeamlineProcessor

from syned.beamline.beamline import Beamline

from wofryokona.beamline.okona_beamline_element import OKONABeamlineElement
from wofryokona.storage_ring.okona_light_source import OKONALightSource
from wofryokona.util.okona_object import OKONAObject

class OKONABeamline(Beamline, OKONAObject):
    def __init__(self,
                 light_source: OKONALightSource,
                 beamline_elements_list: List[OKONABeamlineElement] = None):
        Beamline.__init__(self, light_source, beamline_elements_list)

    def to_okona_beamline_config(self, simulation_plane: str, wavelength: float, **kwargs):
        beamline_config = {'wavelength': wavelength}

        elements_config        = []
        not_belonging_distance = 0.0
        for beamline_element in self.get_beamline_elements():
            be_config = beamline_element.to_okona_beamline_element_config(simulation_plane=simulation_plane, wavelength=wavelength, **kwargs)
            if beamline_element.belongs(simulation_plane=simulation_plane):
                be_config['distance'] += not_belonging_distance
                elements_config.append(be_config)
            else:
                not_belonging_distance += be_config['distance']

        beamline_config.update(self.get_light_source().okona_source_config)
        beamline_config.update({'elements' : elements_config})

        processor = BeamlineProcessor(wavelength)
        beamline_config = processor.process_ashenbach_cutoff(beamline_config)
        beamline_config = processor.process_sampling_points(beamline_config)

        return beamline_config

    def to_python_code(self, propagation_mode: str, run_parallel: bool):
        script  = "import numpy as np"
        script += "\nfrom matplotlib import pyplot as plt"
        script += "\nfrom wofryokona.beamline.okona_beamline import OKONABeamline"
        script += "\nfrom wofryokona.beamline.okona_beamline_element import OKONABeamlineElement"
        script += "\nfrom wofryokona.storage_ring.okona_light_source import OKONALightSource"
        script += "\nfrom wofryokona.beamline.optical_elements.absorbers.okona_slit import OKONASlitElement"
        script += "\nfrom wofryokona.beamline.optical_elements.ideal_elements.okona_detector import OKONADetectorElement"
        script += "\nfrom wofryokona.beamline.optical_elements.mirrors.okona_mirror import OKONAPlaneMirrorElement, OKONAEllipticalMirrorElement"
        script += "\nfrom wofryokona.propagator.okona_propagation_manager import OKONAPropagationManager, OKONAPropagationModes"
        script += "\nfrom wofryokona.util.plots import *"

        script += "\n\n# ---------- Execution Parameters ------------"
        script += f"\n\nPROPAGATION_MODE = '{propagation_mode}'"
        script += f"\nRUN_PARALLEL     = {run_parallel}"

        script += "\n\n# ---------- Light Source ------------"

        light_source: OKONALightSource = self.get_light_source()

        if light_source is None: script += "\n\nlight_source = None"
        else:                    script += "\n\n" + light_source.to_python_code()

        script += "\n\n# ---------- Beamline Elements ------------"

        beamline_elements = self.get_beamline_elements()

        if beamline_elements is None: script += "\n\nbeamline_elements = None"
        else:
            script += "\n\nbeamline_elements = []"
            for i, beamline_element in enumerate(beamline_elements):
                script += f"\n\n# ------- # B.E. {i+1}"
                script += "\n" + beamline_element.to_python_code()
                script += "\n\nbeamline_elements.append(beamline_element)"

        script +="\n\n# ---------- Run Simulation ------------"

        script += f"\n\nbeamline = OKONABeamline(light_source=light_source,"
        script += f"\n                         beamline_elements_list=beamline_elements)"
        script += "\n\nresults = OKONAPropagationManager.do_propagation(beamline=beamline,"
        script += "\n                                                 propagation_mode=PROPAGATION_MODE,"
        script += "\n                                                 parallel=RUN_PARALLEL)"

        script += "\n\n# ---------- Plot Results ------------"
        script += "\n\nfigure = plt.figure(figsize=(8, 6))"
        script += "\ndraw_source_figure(figure, results)"
        script += "\n\nfigure = plt.figure(figsize=(8, 6))"
        script += "\ndraw_detector_figure(figure, results)"
        script += "\n\nfigures_oe = [plt.figure(figsize=(8, 6)) for oe in get_oe_names(results)]"
        script += "\ndraw_oe_intensity_figures(figures_oe, results)"
        script += "\n\nfigures_errors  = [plt.figure(figsize=(8, 6)) for oe in get_oe_with_surface_errors_names(results)]"
        script += "\ndraw_oe_surface_errors_figures(figures_errors, results)"
        script += "\n\nplt.show()"

        return script
