#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
from typing import Any

from syned.beamline.beamline_element import BeamlineElement
from syned.beamline.element_coordinates import ElementCoordinates
from wofryokona.beamline.optical_elements.okona_optical_element import OKONAOpticalElement
from wofryokona.storage_ring.okona_light_source import OKONASimulationPlane
from wofryokona.util.okona_object import OKONAObject


class OKONAPropagators:
    FRESNEL = 'fresnel'
    HUYGENS = 'huygens'

class OKONAHighPassWavelengthCutoff:
    ASHENBACH = 'ashenbach'

class OKONABeamlineElement(BeamlineElement, OKONAObject):
    def __init__(self,
                 optical_element: OKONAOpticalElement,
                 coordinates: ElementCoordinates,
                 distance: float = 0.0,
                 propagator: str = OKONAPropagators.FRESNEL,
                 max_points_before : float | None = None,
                 high_pass_wavelength_cutoff_m: Any = None,
                 ):
        self._distance                      = distance
        self._propagator                    = propagator
        self._max_points_before             = max_points_before
        self._high_pass_wavelength_cutoff_m = high_pass_wavelength_cutoff_m

        BeamlineElement.__init__(self, optical_element, coordinates)

    @property
    def distance(self): return self._distance

    def belongs(self, simulation_plane: str = OKONASimulationPlane.VERTICAL): return True

    def to_okona_beamline_element_config(self, simulation_plane: str = OKONASimulationPlane.VERTICAL, **kwargs) -> dict:
        config = self.get_optical_element().to_okona_config(simulation_plane, **kwargs)

        config.update({'distance' : self._distance, 'propagator': self._propagator})
        if self._max_points_before is not None: config['max_points_before'] = self._max_points_before

        return config