#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
from syned.storage_ring.electron_beam import ElectronBeam
from syned.storage_ring.light_source import LightSource
from syned.storage_ring.magnetic_structures.undulator import Undulator
from syned.storage_ring.magnetic_structures.bending_magnet import BendingMagnet
from syned.storage_ring.magnetic_structures.wiggler import Wiggler

from okona.optics_elements import SourceFactory, PartiallyCoherentSource, GaussianSchellModelSource
from wofryokona.util.okona_object import OKONAObject


class OKONASourceType:
    UNDULATOR      = 'undulator'
    BENDING_MAGNET = 'bending_magnet'
    WIGGLER        = 'wiggler'

class OKONASourceModel:
    GAUSSIAN_SHELL_MODEL = "gsm"
    PARTIALLY_COHERENT = "pc"

class OKONASimulationPlane:
    HORIZONTAL = 'horizontal'
    VERTICAL   = 'vertical'

class OKONANumberOfModes:
    AUTOMATIC = 'auto'

class OKONALightSource(LightSource, OKONAObject):
    def __init__(self,
                 source_name: str = "OKONA Source",
                 source_type: str = OKONASourceType.UNDULATOR,
                 simulation_plane: str = OKONASimulationPlane.VERTICAL,
                 wavelength: float = 1.0e-9,
                 electron_sigma_s_h: float | None = None,
                 electron_sigma_div_h:float | None = None,
                 electron_sigma_s_v: float | None = None,
                 electron_sigma_div_v: float | None = None,
                 target_size_fwhm: float | None=None,
                 target_divergence_fwhm: float | None=None,
                 undulator_L: float | None = None,
                 num_modes: int | str | None = OKONANumberOfModes.AUTOMATIC,
                 N: int = 8192,
                 source_model: str = OKONASourceModel.GAUSSIAN_SHELL_MODEL,
                 coherence_length: float | None = None):
        electron_beam = ElectronBeam(energy_in_GeV=0.0,
                                     energy_spread=0.0,
                                     current=0.0,
                                     number_of_bunches=0)
        if not electron_sigma_s_h is None and not electron_sigma_div_h is None:
            electron_beam.set_sigmas_horizontal(sigma_x=electron_sigma_s_h,
                                                sigma_xp=electron_sigma_div_h)
        if not electron_sigma_div_v is None and not electron_sigma_div_v is None:
            electron_beam.set_sigmas_vertical(sigma_y=electron_sigma_s_v,
                                              sigma_yp=electron_sigma_div_v)

        if   source_type == OKONASourceType.UNDULATOR:       magnetic_structure = Undulator(period_length=undulator_L, number_of_periods=1)
        elif source_type == OKONASourceType.BENDING_MAGNET:  magnetic_structure = BendingMagnet()
        elif source_type == OKONASourceType.WIGGLER:         magnetic_structure = Wiggler()
        else: raise ValueError("Unknown source type")

        super(OKONALightSource, self).__init__(name=source_name,
                                               electron_beam=electron_beam,
                                               magnetic_structure=magnetic_structure)

        self.__source_factory = SourceFactory()

        (self.__source,
         self.__source_config) = self.__source_factory.create_source(source_type=source_type,
                                                                     simulation_plane=simulation_plane,
                                                                     wavelength=wavelength,
                                                                     electron_sigma_s_h=electron_sigma_s_h,
                                                                     electron_sigma_div_h=electron_sigma_div_h,
                                                                     electron_sigma_s_v=electron_sigma_s_v,
                                                                     electron_sigma_div_v=electron_sigma_div_v,
                                                                     target_size_fwhm=target_size_fwhm,
                                                                     target_divergence_fwhm=target_divergence_fwhm,
                                                                     undulator_L=undulator_L,
                                                                     num_modes=num_modes,
                                                                     N=N,
                                                                     source_model=source_model,
                                                                     coherence_length=coherence_length)
        self.__simulation_plane = simulation_plane

        self.__python_code = "light_source = OKONALightSource("
        self.__python_code += f"\n  source_name='{source_name}',"
        self.__python_code += f"\n  source_type='{source_type}',"
        self.__python_code += f"\n  simulation_plane='{simulation_plane}',"
        self.__python_code += f"\n  wavelength={wavelength},"
        self.__python_code += f"\n  electron_sigma_s_h={electron_sigma_s_h},"
        self.__python_code += f"\n  electron_sigma_div_h={electron_sigma_div_h},"
        self.__python_code += f"\n  electron_sigma_s_v={electron_sigma_s_v},"
        self.__python_code += f"\n  electron_sigma_div_v={electron_sigma_div_v},"
        self.__python_code += f"\n  target_size_fwhm={target_size_fwhm},"
        self.__python_code += f"\n  target_divergence_fwhm={target_divergence_fwhm},"
        self.__python_code += f"\n  undulator_L={undulator_L},"
        if type(num_modes) is str: self.__python_code += f"\n  num_modes='{num_modes}',"
        else:                      self.__python_code += f"\n  num_modes={num_modes},"
        self.__python_code += f"\n  N={N},"
        self.__python_code += f"\n  source_model='{source_model}',"
        self.__python_code += f"\n  coherence_length={coherence_length}"
        self.__python_code += "\n)"

    @property
    def simulation_plane(self) -> str: return self.__simulation_plane

    @property
    def okona_source_factory(self) -> SourceFactory: return self.__source_factory

    @property
    def okona_source(self) -> PartiallyCoherentSource | GaussianSchellModelSource: return self.__source

    @property
    def okona_source_config(self) -> dict: return self.__source_config

    def to_python_code(self) -> str: return self.__python_code

