import os
import pathlib
from collections.abc import Iterator
from importlib.resources import files
from importlib.resources.abc import Traversable
from types import ModuleType
from typing import Any, override


class LazyTraversable(Traversable):
    """A lazy traversable."""

    __slots__ = ("_anchor", "_path_segments", "_traversable_cache")

    _anchor: str | ModuleType
    _path_segments: tuple[str | os.PathLike[str], ...]
    _traversable_cache: dict[str | ModuleType, Traversable]

    def __init__(
        self,
        anchor: str | ModuleType,
        *segments: str | os.PathLike[str],
        _traversable_cache: dict[str | ModuleType, Traversable] | None = None,
    ) -> None:
        """Initialize self."""
        self._anchor = anchor
        self._path_segments = segments
        if _traversable_cache is None:
            _traversable_cache = {}

            if hasattr(os, "register_at_fork"):
                os.register_at_fork(after_in_child=_traversable_cache.clear)

        self._traversable_cache = _traversable_cache

    def _traversable(self) -> Traversable:
        """Create a non-lazy Traversable."""
        if not (path := self._traversable_cache.get(self._anchor)):
            path = files(self._anchor)
            self._traversable_cache[self._anchor] = path
        return path.joinpath(*self._path_segments)

    @override
    def is_dir(self) -> bool:
        """Return True if self is a directory."""
        return self._traversable().is_dir()

    @override
    def is_file(self) -> bool:
        """Return True if self is a file."""
        return self._traversable().is_file()

    @override
    def iterdir(self) -> Iterator[Traversable]:
        """Yield Traversable objects in self."""
        return self._traversable().iterdir()

    @override
    def joinpath(self, *descendants: str | os.PathLike[str]) -> Traversable:
        """
        Return Traversable resolved with any descendants applied.

        Each descendant should be a path segment relative to self
        and each may contain multiple levels separated by
        ``posixpath.sep`` (``/``).
        """
        self._traversable().joinpath(  # fail early for invalid args
            *descendants
        )
        return LazyTraversable(
            self._anchor,
            *self._path_segments,
            *descendants,
            _traversable_cache=self._traversable_cache,  # use same cache for sub-paths
        )

    @override
    @property
    def name(self) -> str:
        """The base name of this object without any parent references."""
        return self._traversable().name

    @override
    def open(self, mode: Any = "r", *args: Any, **kwargs: Any) -> Any:
        """
        Open the file.

        mode may be 'r' or 'rb' to open as text or binary. Return a handle
        suitable for reading (same as pathlib.Path.open).

        When opening as text, accepts encoding parameters such as those
        accepted by io.TextIOWrapper.
        """
        return self._traversable().open(mode, *args, **kwargs)

    @override
    def read_bytes(self) -> bytes:
        """Read contents of self as bytes."""
        with self._traversable().open("rb") as strm:
            return strm.read()

    @override
    def read_text(self, encoding: str | None = None) -> str:
        """Read contents of self as text."""
        with self._traversable().open(encoding=encoding) as strm:
            return strm.read()
