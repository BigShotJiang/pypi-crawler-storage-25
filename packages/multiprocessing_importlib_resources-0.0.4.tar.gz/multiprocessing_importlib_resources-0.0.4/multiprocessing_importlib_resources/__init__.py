"""
multiprocessing-safe importlib.resource.files implementation.
"""

import importlib.resources
import pathlib
from importlib.resources import as_file
from importlib.resources import files as _unsafe_files
from importlib.resources.abc import Traversable
from types import ModuleType

from . import _lazy_traversable


def files(anchor: str | ModuleType) -> Traversable:
    """
    Get a Traversable resource for an anchor.

    Multiprocesing-safe alternative to `importlib.resources.files`.
    """

    if isinstance(traversable := _unsafe_files(anchor), pathlib.Path):
        return traversable
    return _lazy_traversable.LazyTraversable(anchor)


def _patch() -> None:
    """Path importlib.resources.files to be safe."""
    importlib.resources.files = files  # type: ignore[assignment]


__all__ = ("files", "as_file")
