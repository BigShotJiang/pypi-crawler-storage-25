# multiprocessing-importlib-resources

Storing the Traversable returned by `importlib.resources.files` is not save in zipapps using multiple processes.
Use multiprocessing-importlib-resources to make this safe.

For more information see:

- https://discuss.python.org/t/importlib-resources-files-and-multiprocessing/106813/4
- https://github.com/Joshix-1/importlib.resources.files-multiprocessing--bug
- https://github.com/python/cpython/issues/83544

## Use as importlib.resources.files replacement
```py
from importlib.resources.abc import Traversable
from multiprocessing_importlib_resources import files


PATH: Traversable = files(__name__)
```

## Patch importlib.resources.files for everyone
```py
from importlib.resources.abc import Traversable
import multiprocessing_importlib_resources
multiprocessing_importlib_resources._patch()

# fine now
from importlib.resources import files
PATH: Traversable = files(__name__)
```
