import {useMemo, useRef, useState} from "react";
import {motion, useDragControls} from "framer-motion";
import {AssistantRuntimeProvider, useLocalRuntime} from "@assistant-ui/react";
import makeOmniaModelAdapter from "./OmniaModelAdapter";
import useKeyboardShortcut from "../hooks/useKeyboardShortcut";
import useResize from "../hooks/useResize";
import useIsMobile from "../hooks/useIsMobile";
import useTextSelection from "../hooks/useTextSelection";
import usePageContentLength from "../hooks/usePageContentLength";
import FloatingFab from "./FloatingFab";
import PanelHeader from "./PanelHeader";
import ContextBanner from "./ContextBanner";
import ChatThread from "./ChatThread";
import Disclaimer from "./Disclaimer";
import ResizeHandle from "./ResizeHandle";
import {readConfigValue} from "../utils/config";

const containerVariants = {
    closed: {scale: 0, opacity: 0},
    open: {borderRadius: "0.5rem", scale: 1, opacity: 1},
};

const mobileVariants = {
    closed: {y: "100%", opacity: 0},
    open: {y: 0, opacity: 1, borderRadius: "0.75rem 0.75rem 0 0"},
};

const DEFAULT_DISCLAIMER =
    "L'intelligence artificielle peut commettre des erreurs, vérifiez les informations importantes.";

export default function AIAssistant({config = {}}) {
    const mode = readConfigValue(config, "mode", "mode", "floating");
    const initialWidth = readConfigValue(config, "initialWidth", "initial_width", 380);
    const initialHeight = readConfigValue(config, "initialHeight", "initial_height", 520);
    const disclaimer = readConfigValue(config, "disclaimer", "disclaimer", DEFAULT_DISCLAIMER);
    const maxContextChars = readConfigValue(config, "maxContextChars", "max_context_chars", 20_000);

    const isFixed = mode === "fixed";
    const {isMobile} = useIsMobile();

    const [isOpen, setIsOpen] = useState(false);
    const [panelSize, setPanelSize] = useState({width: initialWidth, height: initialHeight});
    const dragControls = useDragControls();
    const constraintsRef = useRef(null);
    const panelRef = useRef(null);

    const {hasMounted} = useKeyboardShortcut(isOpen, setIsOpen);
    const {onResizePointerDown} = useResize(panelRef, setPanelSize);
    const {selectedText} = useTextSelection(isOpen, panelRef);
    const {pageContentLength} = usePageContentLength(config);

    const includePageContent = readConfigValue(config, "includePageContent", "include_page_content", true);
    const isTooLarge = includePageContent && pageContentLength > maxContextChars;
    const isSelectionTooLarge = selectedText.length > maxContextChars;
    const hasValidSelection = selectedText.length > 0 && !isSelectionTooLarge;

    const enrichedConfig = isTooLarge
        ? {...config, pageContentOverride: hasValidSelection ? selectedText : ""}
        : config;

    const enrichedConfigRef = useRef(enrichedConfig);
    enrichedConfigRef.current = enrichedConfig;
    const adapter = useMemo(() => makeOmniaModelAdapter(() => enrichedConfigRef.current), []);
    const runtime = useLocalRuntime(adapter);

    const fixedStyle = {
        position: "fixed",
        bottom: 16,
        right: 16,
        borderRadius: "50%",
        pointerEvents: isOpen ? "auto" : "none",
        zIndex: 999999,
        backgroundColor: "white",
        boxShadow: "0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1)",
        width: panelSize.width,
        height: panelSize.height,
    };

    const floatingStyle = {
        ...fixedStyle,
        bottom: undefined,
        right: undefined,
        top: window.innerHeight - initialHeight - 16,
        left: window.innerWidth - initialWidth - 16,
    };

    const mobileStyle = {
        position: "fixed",
        bottom: 0,
        left: 0,
        width: "100vw",
        height: "66.67dvh",
        borderRadius: "0.75rem 0.75rem 0 0",
        zIndex: 999999,
        backgroundColor: "white",
        boxShadow: "0 -4px 20px rgb(0 0 0 / 0.12)",
        pointerEvents: isOpen ? "auto" : "none",
    };

    const panelStyle = isMobile ? mobileStyle : isFixed ? fixedStyle : floatingStyle;

    return (
        <AssistantRuntimeProvider runtime={runtime}>
            <FloatingFab isOpen={isOpen} onOpen={() => setIsOpen(true)} hasMounted={hasMounted} />

            <div
                ref={constraintsRef}
                className={`pointer-events-none fixed ${isMobile ? "inset-0" : "bottom-[10px] right-[10px]"}`}
                style={
                    isMobile
                        ? {width: "100vw", height: "66.67dvh", zIndex: 999999}
                        : {width: "calc(100vw - 80px)", height: "calc(100vh - 100px)", zIndex: 100}
                }
            >
                <motion.div
                    ref={panelRef}
                    {...(!isFixed && !isMobile && {
                        drag: true,
                        dragConstraints: constraintsRef,
                        dragControls: dragControls,
                        dragListener: false,
                        dragTransition: {
                            power: 0.2,
                            timeConstant: 150,
                            bounceStiffness: 50,
                            bounceDamping: 10,
                        },
                    })}
                    variants={isMobile ? mobileVariants : containerVariants}
                    initial="closed"
                    animate={isOpen ? "open" : "closed"}
                    transition={isMobile ? {type: "tween", duration: 0.25, ease: "easeOut"} : {duration: 0.15}}
                    className="relative flex flex-col border border-gray-200"
                    style={panelStyle}
                >
                    <PanelHeader isFixed={isFixed} isMobile={isMobile} dragControls={dragControls} onClose={() => setIsOpen(false)} />

                    <ContextBanner
                        isTooLarge={isTooLarge}
                        isSelectionTooLarge={isSelectionTooLarge}
                        hasValidSelection={hasValidSelection}
                        selectedText={selectedText}
                        maxContextChars={maxContextChars}
                    />

                    <div className={`min-h-0 flex-1 overflow-hidden bg-white${!disclaimer ? " rounded-b-lg" : ""}`}>
                        <div id="aui-chat-root" className={`h-full overflow-y-auto bg-white${!disclaimer ? " rounded-b-lg" : ""}`}>
                            <ChatThread config={enrichedConfig} />
                        </div>
                    </div>

                    <Disclaimer text={disclaimer} />

                    {!isFixed && !isMobile && <ResizeHandle onPointerDown={onResizePointerDown} />}
                </motion.div>
            </div>
        </AssistantRuntimeProvider>
    );
}
