const prefixSelector = require('postcss-prefix-selector');

const ROOT_ID = '#omnia-assistant-root';

module.exports = {
  plugins: [
    require('@tailwindcss/nesting'),
    require('tailwindcss'),
    require('autoprefixer'),
    prefixSelector({
      prefix: ROOT_ID,
      transform(prefix, selector, prefixedSelector) {
        // Already scoped — don't double-prefix
        if (selector.startsWith(ROOT_ID)) {
          return selector;
        }
        // Document/pseudo-root selectors become the outer widget container
        // so preflight/root variables apply to the whole assistant shell.
        if (
          [':root', 'html', ':host', 'body'].includes(selector) ||
          /^html\s+body$/.test(selector.trim())
        ) {
          return prefix;
        }
        // ::backdrop can't be a descendant — leave global (harmless --tw-* vars)
        if (selector.startsWith('::backdrop')) {
          return selector;
        }
        return prefixedSelector;
      },
    }),
  ],
};
