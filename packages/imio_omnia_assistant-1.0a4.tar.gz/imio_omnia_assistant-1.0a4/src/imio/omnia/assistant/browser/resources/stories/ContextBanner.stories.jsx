import ContextBanner from '../src/components/ContextBanner';

const panelDecorator = (Story) => (
    <div style={{width: 380, border: '1px solid #e5e7eb', borderRadius: 8, overflow: 'hidden'}}>
        <Story />
    </div>
);

export default {
    title: 'UI/ContextBanner',
    component: ContextBanner,
    decorators: [panelDecorator],
    parameters: {
        layout: 'centered',
        docs: {
            description: {
                component:
                    "Contextual warning banner displayed when page content exceeds the configured limit. " +
                    'Three variants: warning (yellow), selection error (red), valid selection (blue with progress bar).',
            },
        },
    },
    argTypes: {
        isTooLarge: {
            control: 'boolean',
            description: "Page content exceeds `maxContextChars`. No banner is shown if `false`.",
            table: {defaultValue: {summary: 'false'}},
        },
        isSelectionTooLarge: {
            control: 'boolean',
            description: "The user's selection itself exceeds `maxContextChars`.",
            table: {defaultValue: {summary: 'false'}},
        },
        hasValidSelection: {
            control: 'boolean',
            description: 'A non-empty selection within the limit is active.',
            table: {defaultValue: {summary: 'false'}},
        },
        selectedText: {
            control: 'text',
            description: "Text selected by the user (used to calculate the percentage).",
        },
        maxContextChars: {
            control: {type: 'number', min: 100, step: 1000},
            description: 'Character threshold for the context.',
            table: {defaultValue: {summary: 20000}},
        },
    },
    args: {
        maxContextChars: 20000,
        selectedText: '',
    },
};

export const Warning = {
    name: 'Warning (yellow)',
    args: {
        isTooLarge: true,
        isSelectionTooLarge: false,
        hasValidSelection: false,
    },
};

export const SelectionTooLarge = {
    name: 'Selection too large (red)',
    args: {
        isTooLarge: true,
        isSelectionTooLarge: true,
        hasValidSelection: false,
    },
};

export const ValidSelectionSmall = {
    name: 'Valid selection — 25%',
    args: {
        isTooLarge: true,
        isSelectionTooLarge: false,
        hasValidSelection: true,
        selectedText: 'x'.repeat(5000),
        maxContextChars: 20000,
    },
};

export const ValidSelectionMedium = {
    name: 'Valid selection — 60%',
    args: {
        isTooLarge: true,
        isSelectionTooLarge: false,
        hasValidSelection: true,
        selectedText: 'x'.repeat(12000),
        maxContextChars: 20000,
    },
};

export const ValidSelectionFull = {
    name: 'Valid selection — 100%',
    args: {
        isTooLarge: true,
        isSelectionTooLarge: false,
        hasValidSelection: true,
        selectedText: 'x'.repeat(20000),
        maxContextChars: 20000,
    },
};

export const Hidden = {
    name: 'Hidden (content OK)',
    args: {
        isTooLarge: false,
        isSelectionTooLarge: false,
        hasValidSelection: false,
    },
};
