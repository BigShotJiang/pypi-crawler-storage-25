import {useState} from 'react';
import FloatingFab from '../src/components/FloatingFab';

function InteractiveFab() {
    const [isOpen, setIsOpen] = useState(false);
    return (
        <>
            <FloatingFab isOpen={isOpen} onOpen={() => setIsOpen(true)} hasMounted={true} />
            {isOpen && (
                <div className="fixed bottom-4 right-4 flex items-center gap-2 rounded-lg border bg-white px-4 py-3 shadow-md">
                    <span className="text-sm text-gray-600">Panneau ouvert</span>
                    <button
                        onClick={() => setIsOpen(false)}
                        className="rounded bg-gray-100 px-2 py-1 text-xs text-gray-700 hover:bg-gray-200"
                    >
                        Fermer
                    </button>
                </div>
            )}
        </>
    );
}

export default {
    title: 'UI/FloatingFab',
    component: FloatingFab,
    parameters: {
        layout: 'fullscreen',
        docs: {
            description: {
                component:
                    "Floating action button (FAB) at the bottom-right of the screen. " +
                    "Disappears with an animation when the panel is open.",
            },
        },
    },
    argTypes: {
        isOpen: {
            control: 'boolean',
            description: "If `true`, the FAB is hidden (the panel is open).",
            table: {defaultValue: {summary: 'false'}},
        },
        hasMounted: {
            control: 'boolean',
            description: "If `false`, no entry animation on first render.",
            table: {defaultValue: {summary: 'false'}},
        },
    },
};

export const Visible = {
    name: 'Visible',
    args: {
        isOpen: false,
        hasMounted: true,
        onOpen: () => {},
    },
};

export const Hidden = {
    name: 'Hidden (panel open)',
    args: {
        isOpen: true,
        hasMounted: true,
        onOpen: () => {},
    },
};

export const Interactive = {
    name: 'Interactive',
    render: () => <InteractiveFab />,
};
