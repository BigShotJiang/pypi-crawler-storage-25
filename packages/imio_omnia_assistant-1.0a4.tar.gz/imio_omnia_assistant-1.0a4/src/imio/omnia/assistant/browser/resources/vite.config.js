import { defineConfig } from 'vite';
import preact from '@preact/preset-vite';
import svgr from 'vite-plugin-svgr';

export default defineConfig({
  plugins: [preact(), svgr()],
  define: {
    'process.env.NODE_ENV': '"production"',
  },
  build: {
    lib: {
      entry: 'src/index.jsx',
      name: 'OmniaAssistantUI',
      formats: ['es', 'umd'],
      fileName: 'omnia-assistant-ui',
    },
  },
});
