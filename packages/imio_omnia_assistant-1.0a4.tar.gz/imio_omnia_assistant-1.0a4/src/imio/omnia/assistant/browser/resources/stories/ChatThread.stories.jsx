import {useMemo} from 'react';
import {AssistantRuntimeProvider, useLocalRuntime} from '@assistant-ui/react';
import makeOmniaModelAdapter from '../src/components/OmniaModelAdapter';
import ChatThread from '../src/components/ChatThread';

export default {
    title: 'Omnia/ChatThread',
    component: ChatThread,
    parameters: {
        layout: 'centered',
        docs: {
            description: {
                component:
                    'Chat thread with SSE streaming, Markdown rendering, and message composer.',
            },
        },
    },
};

function StoryWrapper({config = {}}) {
    const adapter = useMemo(() => makeOmniaModelAdapter(() => ({})), []);
    const runtime = useLocalRuntime(adapter);
    return (
        <div id="aui-chat-root"
             style={{width: 480, height: 600, border: '1px solid #ddd', borderRadius: 8, overflow: 'hidden'}}>
            <AssistantRuntimeProvider runtime={runtime}>
                <ChatThread config={config}/>
            </AssistantRuntimeProvider>
        </div>
    );
}

export const Default = {
    render: () => <StoryWrapper/>,
};

export const CustomWelcome = {
    render: () => <StoryWrapper
        config={{welcome_message: "{greeting} ! Bienvenue sur le portail citoyen.\nComment puis-je vous aider aujourd'hui ?"}}/>,
};
