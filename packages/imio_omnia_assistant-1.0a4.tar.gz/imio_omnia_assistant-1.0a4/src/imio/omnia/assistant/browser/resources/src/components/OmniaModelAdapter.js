import readPageContent from "../utils/readPageContent";
import {readConfigValue} from "../utils/config";

export default function makeOmniaModelAdapter(configOrGetter = {}) {
    return {
        async* run({messages, abortSignal}) {
            const config = typeof configOrGetter === "function" ? configOrGetter() : configOrGetter;
            const apiServiceUrl = readConfigValue(config, "apiServiceUrl", "api_service_url");
            const apiKey = readConfigValue(config, "apiKey", "api_key");
            const model = readConfigValue(config, "model", "model");
            const basePrompt = readConfigValue(config, "basePrompt", "base_prompt");
            const configuredSystemMessages =
                readConfigValue(config, "systemMessages", "system_messages", []);
            const includePageContent = readConfigValue(config, "includePageContent", "include_page_content", true);

            const normalizeContent = (content) => {
                if (typeof content === "string") return content;
                if (Array.isArray(content)) {
                    return content.map((c) => c.text ?? "").join("");
                }
                return String(content ?? "");
            };

            const systemMessages = [];
            if (basePrompt) {
                systemMessages.push({role: "system", content: basePrompt});
            }
            for (const message of Array.isArray(configuredSystemMessages) ? configuredSystemMessages : [configuredSystemMessages]) {
                if (!message) continue;
                if (typeof message === "string") {
                    systemMessages.push({role: "system", content: message});
                    continue;
                }
                if (message.role === "system" && message.content) {
                    systemMessages.push({role: "system", content: normalizeContent(message.content)});
                }
            }
            if (includePageContent) {
                let pageContent;
                if (config.pageContentOverride != null) {
                    pageContent = config.pageContentOverride || "No content found on the page.";
                } else {
                    pageContent = readPageContent(config);
                }
                systemMessages.push({role: "system", content: pageContent});
            }

            const finalMessages = [
                ...systemMessages,
                ...messages.map((m) => ({role: m.role, content: normalizeContent(m.content)})),
            ];

            const completionUrl = `${apiServiceUrl}/chat/completions`;
            const response = await fetch(completionUrl, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${apiKey}`,
                },
                body: JSON.stringify({
                    model,
                    messages: finalMessages,
                    stream: true,
                }),
                signal: abortSignal,
            });

            if (!response.ok) {
                const errorBody = await response.json().catch(() => ({}));
                const errMsg = errorBody?.error?.message || JSON.stringify(errorBody);
                throw new Error(`API returned status ${response.status}: ${errMsg}`);
            }

            const reader = response.body.getReader();
            const textDecoder = new TextDecoder("utf-8");
            let accumulatedText = "";
            let done = false;
            let leftover = "";

            while (!done) {
                const {value, done: isDone} = await reader.read();
                done = isDone;
                if (!value) continue;

                const chunk = textDecoder.decode(value, {stream: true});
                const combined = leftover + chunk;
                const lines = combined.split("\n");
                leftover = lines.pop() || "";

                for (const line of lines) {
                    const trimmed = line.trim();
                    if (!trimmed || !trimmed.startsWith("data: ")) continue;

                    const jsonStr = trimmed.substring("data: ".length).trim();
                    if (jsonStr === "[DONE]") return;

                    try {
                        const parsed = JSON.parse(jsonStr);
                        const token = parsed?.choices?.[0]?.delta?.content;
                        if (token) {
                            accumulatedText += token;
                            yield {
                                content: [{type: "text", text: accumulatedText}],
                            };
                        }
                    } catch (err) {
                        console.warn("Could not parse SSE line", line, err);
                    }
                }
            }
        },
    };
}
