import {render} from 'preact';
import './styles/index.css';
import AIAssistant from './components/AIAssistant';

export function mount(container, config = {}) {
    if (typeof container === 'string') {
        container = document.getElementById(container);
    }
    if (!container) {
        console.warn('[omnia-assistant-ui] Mount container not found');
        return;
    }
    render(<AIAssistant config={config}/>, container);
    return container;
}

export {AIAssistant};

// Auto-mount when window.omnia_assistant_settings has been set (e.g. by a server-side integration).
function autoMount() {
  const settings = window.omnia_assistant_settings;
  if (!settings) return;
  const container =
    document.getElementById('omnia-assistant-root') ||
    document.createElement('div');

  if (!container.id) {
    container.id = 'omnia-assistant-root';
    document.body.appendChild(container);
  }

  mount(container, settings);
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', autoMount);
} else {
  autoMount();
}
