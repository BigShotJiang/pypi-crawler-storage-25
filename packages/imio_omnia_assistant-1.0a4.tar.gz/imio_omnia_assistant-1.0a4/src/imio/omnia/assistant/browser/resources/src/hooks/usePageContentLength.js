import {useEffect, useState} from "react";
import readPageContent from "../utils/readPageContent";
import {readConfigValue} from "../utils/config";

/**
 * Measures the character length of the extracted page content.
 *
 * Re-runs whenever the page content config changes (`pageContentSelector`,
 * `pageContentClean`, `includePageContent`). Used to determine whether the
 * context banner should warn about oversized content.
 *
 * @param {object} config - Assistant config object.
 * @param {string|string[]} config.pageContentSelector - CSS selector(s) to extract.
 * @param {boolean} config.pageContentClean - Whether to strip HTML tags.
 * @param {boolean} config.includePageContent - Whether page content injection is enabled.
 * @returns {{ pageContentLength: number }} Character count of the extracted content.
 */
export default function usePageContentLength(config) {
    const [pageContentLength, setPageContentLength] = useState(0);
    const includePageContent = readConfigValue(config, "includePageContent", "include_page_content", true);
    const pageContentSelector = readConfigValue(config, "pageContentSelector", "page_content_selector", "#content");
    const pageContentClean = readConfigValue(config, "pageContentClean", "page_content_clean", false);

    useEffect(() => {
        const content = readPageContent(config);
        setPageContentLength(content.length);
    }, [config, includePageContent, pageContentSelector, pageContentClean]);

    return {pageContentLength};
}
