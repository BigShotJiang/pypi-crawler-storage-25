import {useMemo} from 'react';
import {useDragControls} from 'framer-motion';
import {AssistantRuntimeProvider, useLocalRuntime} from '@assistant-ui/react';
import makeOmniaModelAdapter from '../src/components/OmniaModelAdapter';
import PanelHeader from '../src/components/PanelHeader';

function HeaderWrapper({isFixed, onClose}) {
    const dragControls = useDragControls();
    const adapter = useMemo(() => makeOmniaModelAdapter(() => ({})), []);
    const runtime = useLocalRuntime(adapter);
    return (
        <AssistantRuntimeProvider runtime={runtime}>
            <PanelHeader isFixed={isFixed} dragControls={dragControls} onClose={onClose} />
        </AssistantRuntimeProvider>
    );
}

const panelDecorator = (Story) => (
    <div style={{width: 380, border: '1px solid #e5e7eb', borderRadius: 8, overflow: 'hidden'}}>
        <Story />
    </div>
);

export default {
    title: 'UI/PanelHeader',
    component: PanelHeader,
    decorators: [panelDecorator],
    parameters: {
        layout: 'centered',
        docs: {
            description: {
                component:
                    "Assistant panel header bar. Contains the Omnia logo, title, " +
                    '"New conversation" button, and close button. ' +
                    'In floating mode, the bar serves as a drag handle.',
            },
        },
    },
    argTypes: {
        isFixed: {
            control: 'boolean',
            description: 'In fixed mode, the grab cursor and drag are disabled.',
            table: {defaultValue: {summary: 'false'}},
        },
    },
    render: (args) => <HeaderWrapper {...args} onClose={() => alert('Fermer')} />,
};

export const Floating = {
    name: 'Floating (draggable)',
    args: {isFixed: false},
};

export const Fixed = {
    name: 'Fixed',
    args: {isFixed: true},
};
