import {AnimatePresence, motion} from "framer-motion";
import OmniaIcon from "../assets/omnia-icon.svg?react";

export default function FloatingFab({isOpen, onOpen, hasMounted}) {
    return (
        <AnimatePresence>
            {!isOpen && (
                <motion.button
                    key="fab"
                    onClick={onOpen}
                    className="fixed bottom-4 right-4 z-50 flex h-14 w-14 items-center justify-center rounded-full border border-gray-100 bg-white shadow-md"
                    initial={hasMounted ? {scale: 0, opacity: 0} : false}
                    animate={{scale: 1, opacity: 1}}
                    exit={{scale: 0, opacity: 0}}
                    transition={{duration: 0.15}}
                >
                    <OmniaIcon className="h-10 w-10" />
                </motion.button>
            )}
        </AnimatePresence>
    );
}
