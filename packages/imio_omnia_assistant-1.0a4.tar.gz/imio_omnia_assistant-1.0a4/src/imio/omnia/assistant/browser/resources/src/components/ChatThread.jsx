import {Thread} from "@assistant-ui/react";
import {makeMarkdownText} from "@assistant-ui/react-markdown";
import omniaIconUrl from "../assets/omnia-icon.svg?url";
import ChatComposer from "./ChatComposer";
import {readConfigValue} from "../utils/config";

const MarkdownText = makeMarkdownText();

function getGreeting() {
    return new Date().getHours() < 18 ? "Bonjour" : "Bonsoir";
}

const DEFAULT_WELCOME_MESSAGE = "{greeting} !\nComment puis-je vous aider aujourd'hui ?";

function buildWelcomeMessage(template) {
    const greeting = getGreeting();
    const lines = template.replace("{greeting}", greeting).split("\n");
    return (
        <div>
            {lines.map((line, i) => <p key={i} class="text-center">{line}</p>)}
        </div>
    );
}

export default function ChatThread({config = {}}) {
    const suggestions = readConfigValue(config, "suggestions", "suggestions");
    const welcomeTemplate = readConfigValue(
        config,
        "welcomeMessage",
        "welcome_message",
        DEFAULT_WELCOME_MESSAGE
    );
    const Composer = () => <ChatComposer config={config} />;

    return (
        <div className="h-full">
            <Thread
                assistantAvatar={{src: omniaIconUrl, alt: "Omnia"}}
                assistantMessage={{components: {Text: MarkdownText}}}
                components={{Composer}}
                welcome={{
                    message: buildWelcomeMessage(welcomeTemplate),
                    suggestions,
                }}
                strings={{
                    thread: {
                        scrollToBottom: {tooltip: "Défiler vers le bas"},
                    },
                    userMessage: {
                        edit: {tooltip: "Modifier"},
                    },
                    assistantMessage: {
                        reload: {tooltip: "Regénérer"},
                        copy: {tooltip: "Copier"},
                    },
                    branchPicker: {
                        previous: {tooltip: "Précédent"},
                        next: {tooltip: "Suivant"},
                    },
editComposer: {
                        send: {label: "Envoyer"},
                        cancel: {label: "Annuler"},
                    },
                    code: {
                        header: {copy: {tooltip: "Copier"}},
                    },
                }}
            />
        </div>
    );
}
