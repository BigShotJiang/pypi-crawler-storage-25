import {useEffect, useState} from "react";

/**
 * Tracks the user's text selection on the page while the panel is open.
 *
 * Listens to `selectionchange` events and updates `selectedText` whenever
 * a non-collapsed selection is made outside the panel element. Clears the
 * selection when the panel is closed or when the selection collapses outside
 * the panel.
 *
 * @param {boolean} isOpen - Whether the panel is currently open.
 * @param {import('react').RefObject} panelRef - Ref to the panel DOM element,
 *   used to ignore selections made within the panel itself.
 * @returns {{ selectedText: string }} The current page text selection.
 */
export default function useTextSelection(isOpen, panelRef) {
    const [selectedText, setSelectedText] = useState("");

    useEffect(() => {
        if (!isOpen) {
            setSelectedText("");
            return;
        }
        const handler = () => {
            const sel = window.getSelection();
            if (!sel || sel.isCollapsed) {
                if (!panelRef.current?.contains(sel?.anchorNode)) {
                    setSelectedText("");
                }
                return;
            }
            if (panelRef.current?.contains(sel.anchorNode)) return;
            setSelectedText(sel.toString());
        };
        document.addEventListener("selectionchange", handler);
        return () => document.removeEventListener("selectionchange", handler);
    }, [isOpen]);

    return {selectedText};
}
