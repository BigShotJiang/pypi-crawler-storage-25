import Disclaimer from '../src/components/Disclaimer';

const panelDecorator = (Story) => (
    <div style={{width: 380, border: '1px solid #e5e7eb', borderRadius: 8, overflow: 'hidden'}}>
        <Story />
    </div>
);

export default {
    title: 'UI/Disclaimer',
    component: Disclaimer,
    decorators: [panelDecorator],
    parameters: {
        layout: 'centered',
        docs: {
            description: {
                component:
                    'Footer with AI disclaimer displayed at the bottom of the assistant panel. ' +
                    'Can be hidden by passing a falsy value.',
            },
        },
    },
    argTypes: {
        text: {
            control: 'text',
            description: 'Disclaimer text. Set to empty to hide.',
        },
    },
};

export const Default = {
    name: 'Default text',
    args: {
        text: "L'intelligence artificielle peut commettre des erreurs, vérifiez les informations importantes.",
    },
};

export const Custom = {
    name: 'Custom text',
    args: {
        text: "Cet assistant est fourni à titre informatif uniquement et ne constitue pas un avis juridique.",
    },
};

export const Hidden = {
    name: 'Hidden',
    args: {
        text: '',
    },
};
