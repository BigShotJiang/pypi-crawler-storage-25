export default function ResizeHandle({onPointerDown}) {
    return (
        <div
            className="absolute bottom-0 right-0 flex h-6 w-6 cursor-nwse-resize items-end justify-end p-1 text-gray-400 opacity-60 transition-opacity hover:opacity-100"
            onPointerDown={onPointerDown}
        >
            <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
                <path d="M9 1L1 9" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/>
                <path d="M9 5L5 9" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/>
            </svg>
        </div>
    );
}
