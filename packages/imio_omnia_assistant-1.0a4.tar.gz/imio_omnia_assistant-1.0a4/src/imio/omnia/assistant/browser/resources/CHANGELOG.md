# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

### Added
- AI chat assistant widget with draggable panel and FAB button
- Chat thread with streaming responses via @assistant-ui/react
- OpenAI-compatible SSE streaming adapter (RuntimeProvider)
- Keyboard shortcut (Alt+I) to toggle assistant
- Storybook stories with mock chat completions API
- Library entry point with `mount()` function
