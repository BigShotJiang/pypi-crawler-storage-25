import InfoCircle from "../assets/info-circle.svg?react";
import ExclamationCircle from "../assets/exclamation-circle.svg?react";
import ExclamationTriangle from "../assets/exclamation-triangle.svg?react";

export default function ContextBanner({isTooLarge, isSelectionTooLarge, hasValidSelection, selectedText, maxContextChars}) {
    if (!isTooLarge) return null;

    if (hasValidSelection) {
        const pct = Math.round(selectedText.length / maxContextChars * 100);
        return (
            <div className="shrink-0 border-b border-blue-200 bg-blue-50 px-3 pt-1.5 pb-2 text-[11px] text-blue-800">
                <div className="flex items-center gap-2 mb-1.5">
                    <InfoCircle className="h-4 w-4 mr-0.5" />Questions sur la sélection ({pct} % du contexte)
                </div>
                <div className="h-1 w-full rounded-full bg-blue-200">
                    <div
                        className="h-1 rounded-full bg-blue-500 transition-all duration-150"
                        style={{width: `${Math.min(pct, 100)}%`}}
                    />
                </div>
            </div>
        );
    }

    if (isSelectionTooLarge) {
        return (
            <div className="flex shrink-0 items-center gap-2 border-b border-red-200 bg-red-50 px-3 py-1.5 text-[11px] text-red-800">
                <ExclamationTriangle className="h-5 w-5 mr-1" />
                Sélection trop longue: choisissez un extrait plus court.
            </div>
        );
    }

    return (
        <div className="flex shrink-0 items-center gap-2 border-b border-yellow-200 bg-yellow-50 px-3 py-1.5 text-[11px] text-yellow-800">
            <ExclamationCircle className="h-5 w-5 mr-1" />
            Le contenu est trop volumineux: sélectionnez un extrait du texte.
        </div>
    );
}
