/** @type { import('storybook').StorybookConfig } */
const config = {
  stories: ['../stories/**/*.stories.@(js|jsx)'],
  framework: {
    name: '@storybook/react-vite',
    options: {},
  },
  async viteFinal(config) {
    config.plugins = [...(config.plugins ?? []), mockChatCompletionsPlugin()];

    // If VITE_OMNIA_BASE_URL is a full URL, proxy it to avoid CORS.
    const apiTarget = process.env.VITE_OMNIA_BASE_URL;
    if (apiTarget?.startsWith('http')) {
      const { origin, pathname } = new URL(apiTarget);
      config.server ??= {};
      config.server.proxy ??= {};
      config.server.proxy['/omnia-proxy'] = {
        target: origin,
        changeOrigin: true,
        rewrite: (path) => {
          const rewritten = path.replace(/^\/omnia-proxy/, pathname);
          console.log(`[omnia-proxy] ${path} → ${origin}${rewritten}`);
          return rewritten;
        },
        configure: (proxy) => {
          proxy.on('proxyReq', (proxyReq) => {
            proxyReq.removeHeader('accept-encoding');
          });
        },
      };
      config.define ??= {};
      config.define['import.meta.env.VITE_OMNIA_BASE_URL'] = JSON.stringify('/omnia-proxy');
    }

    return config;
  },
};

export default config;

function mockChatCompletionsPlugin() {
  return {
    name: 'omnia-mock-chat-completions',
    configureServer(server) {
      function readBody(req) {
        return new Promise((resolve) => {
          let body = '';
          req.on('data', (c) => (body += c));
          req.on('end', () => {
            try { resolve(JSON.parse(body)); } catch { resolve({}); }
          });
        });
      }

      server.middlewares.use('/api/chat/completions', async (req, res) => {
        const body = await readBody(req);
        const userMessage = body.messages?.findLast((m) => m.role === 'user')?.content || '';

        const reply = `Voici une réponse mock à votre message : "${userMessage}". `
          + 'Je suis l\u2019assistant Omnia en mode développement. '
          + 'Ce texte est généré par le serveur mock de Storybook.';

        res.writeHead(200, {
          'Content-Type': 'text/event-stream',
          'Cache-Control': 'no-cache',
          Connection: 'keep-alive',
          'X-Accel-Buffering': 'no',
        });
        res.flushHeaders();

        const words = reply.split(' ');
        let i = 0;
        const interval = setInterval(() => {
          if (i >= words.length) {
            res.write('data: [DONE]\n\n');
            res.end();
            clearInterval(interval);
            return;
          }
          const token = (i > 0 ? ' ' : '') + words[i];
          const chunk = JSON.stringify({
            choices: [{ delta: { content: token } }],
          });
          res.write(`data: ${chunk}\n\n`);
          i++;
        }, 40);

        res.on('close', () => clearInterval(interval));
      });
    },
  };
}
