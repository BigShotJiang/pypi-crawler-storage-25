# omnia-assistant-ui

AI chat assistant widget that integrates iMio's Omnia API for conversational AI interactions. Features a draggable/resizable chat panel, streaming responses via SSE, page content injection, and keyboard shortcuts.

Published as `@imiobe/omnia-assistant-ui` on npm.

## Commands

- `make dev` / `npm run dev` — Start Storybook dev server on port 6006
- `make build` / `npm run build` — Build library to `dist/` (ES + UMD + CSS)
- `make build-storybook` / `npm run build-storybook` — Build static Storybook site
- `make lint` / `npm run lint` — Run ESLint
- `make lint-fix` / `npm run lint:fix` — Run ESLint with auto-fix
- `make clean` — Remove `dist/` and `storybook-static/`
- `make publish` — Build and publish to npm

No test runner is configured.

## Architecture

- **Entry point:** `src/index.jsx` — Library entry, exports `mount()` and `AIAssistant`
- **Adapter:** `src/components/OmniaModelAdapter.js` — SSE streaming adapter for OpenAI-compatible API
- **Orchestrator:** `src/components/AIAssistant.jsx` — Wires hooks, sub-components, and @assistant-ui runtime together
- **Chat:** `src/components/ChatThread.jsx` — @assistant-ui Thread with markdown rendering and French strings
- **Composer:** `src/components/ChatComposer.jsx` — Message input with send/cancel buttons
- **UI panels:** `src/components/FloatingFab.jsx`, `PanelHeader.jsx`, `ContextBanner.jsx`, `Disclaimer.jsx`, `ResizeHandle.jsx`
- **Hooks:** `src/hooks/` — `useKeyboardShortcut` (Alt+I toggle), `useResize` (pointer-event panel resize), `useTextSelection` (page selection tracking), `usePageContentLength` (content length measurement)
- **Utils:** `src/utils/readPageContent.js` — DOM content extraction by CSS selector
- **Stories:** `stories/` — Storybook stories with mock API
- **Examples:** `stories/examples/` — HTML integration examples (CDLD, publication)
- **Styles:** `src/styles/` — Tailwind directives, @assistant-ui vendored classes, iMio theme variables, overrides

The widget builds as a self-contained library (UMD + ESM) via Vite. Preact is bundled inside.

## Stack

- **Preact** for UI (functional components + hooks, aliased from React via `@preact/preset-vite`)
- **@assistant-ui/react** for chat thread, composer, and markdown rendering
- **Vite** for builds (library mode) and dev server
- **Tailwind CSS v3** with @assistant-ui plugins
- **Framer Motion** for animations (drag, resize, open/close)
- **Mousetrap** for keyboard shortcuts (Alt+I)
- **Storybook 10** (React framework with Preact alias) for component development

## Workflow

- When modifying a UI component, update its corresponding Storybook stories in `stories/`.
- The Storybook preview injects `window.assistant_settings` with mock values for development.
- The mock API in `.storybook/main.js` serves OpenAI-format SSE responses at `/api/chat/completions`.
- Configuration can be provided via the `config` prop (camelCase) or via `window.assistant_settings` (snake_case). The `config` prop takes precedence.

## Code conventions

- JSX components use React-style imports (aliased to Preact via `@preact/preset-vite`)
- Tailwind utility classes (no prefix)
- Streaming responses use SSE in OpenAI chat completions format
- Feature labels and UI text are in French
- Runtime configuration via `window.assistant_settings` (snake_case) or `config` prop (camelCase)

## Environment

Copy `.env.example` to `.env` for Storybook live API stories. Variables:
- `VITE_OMNIA_BASE_URL` — Omnia API base URL
- `VITE_OMNIA_API_KEY` — Bearer token
- `VITE_OMNIA_MODEL` — Model name
