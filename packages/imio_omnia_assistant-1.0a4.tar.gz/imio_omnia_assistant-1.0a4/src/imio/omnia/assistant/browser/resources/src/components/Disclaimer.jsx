export default function Disclaimer({text}) {
    if (!text) return null;
    return (
        <p className="shrink-0 rounded-b-lg border-t border-gray-200 bg-gray-50 px-3 py-1 text-center text-[10px] leading-snug text-gray-500">
            {text}
        </p>
    );
}
