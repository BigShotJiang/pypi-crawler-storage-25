import AIAssistant from '../src/components/AIAssistant';
import publicationHtml from './examples/deliberationsbe_publication.html?raw';
import cdldHtml from './examples/cdld.html?raw';

const liveApiUrl = import.meta.env.VITE_OMNIA_BASE_URL;
const liveApiKey = import.meta.env.VITE_OMNIA_API_KEY;
const liveModel = import.meta.env.VITE_OMNIA_MODEL;

const PAGE_EXAMPLES = {
    'Publication (ordonnance de police)': publicationHtml,
    'CDLD': cdldHtml,
};

export default {
    title: 'Omnia/AIAssistant',
    component: AIAssistant,
    parameters: {
        layout: 'fullscreen',
        docs: {
            description: {
                component:
                    'Chat panel with FAB button and keyboard shortcut (Alt+I). ' +
                    '`floating` mode: draggable and resizable. `fixed` mode: anchored bottom-right.',
            },
        },
    },
    argTypes: {
        disclaimer: {
            control: 'text',
            description: "AI disclaimer text displayed at the bottom of the panel. Set to `false` to hide.",
            table: {
                defaultValue: {
                    summary: "L'intelligence artificielle peut commettre des erreurs…",
                },
            },
        },
        mode: {
            control: {type: 'select'},
            options: ['floating', 'fixed'],
            description: 'floating = draggable + resizable; fixed = anchored bottom-right',
            table: {defaultValue: {summary: 'floating'}},
        },
        initialWidth: {
            control: {type: 'number', min: 280, step: 10},
            description: 'Initial panel width (px)',
            table: {defaultValue: {summary: 380}},
        },
        initialHeight: {
            control: {type: 'number', min: 200, step: 10},
            description: 'Initial panel height (px)',
            table: {defaultValue: {summary: 520}},
        },
        apiServiceUrl: {
            control: 'text',
            description: "API base URL (without /chat/completions)",
            table: {category: 'API'},
        },
        apiKey: {
            control: 'text',
            description: 'Bearer token',
            table: {category: 'API'},
        },
        model: {
            control: 'text',
            description: 'Model name',
            table: {category: 'API'},
        },
        basePrompt: {
            control: 'text',
            description: 'System prompt',
            table: {category: 'API'},
        },
        includePageContent: {
            control: 'boolean',
            description: "Inject page content as system context.",
            table: {category: 'Page content', defaultValue: {summary: true}},
        },
        pageContentSelector: {
            control: 'text',
            description: "CSS selector of the area to extract. Accepts a string or an array of selectors; all matching elements are concatenated.",
            table: {category: 'Page content', defaultValue: {summary: '#content'}},
        },
        pageContentClean: {
            control: 'boolean',
            description: "When enabled, only plain text is extracted (HTML tags are stripped) to reduce token consumption.",
            table: {category: 'Page content', defaultValue: {summary: false}},
        },
        maxContextChars: {
            control: {type: 'number', min: 100, step: 1000},
            description: "Character threshold beyond which the panel displays a context-too-large warning.",
            table: {category: 'Page content', defaultValue: {summary: 20000}},
        },
        maxMessagesPerSession: {
            control: {type: 'number', min: 0, step: 1},
            description: 'Maximum number of user messages allowed in one conversation. Set to 0 to disable the limit.',
            table: {category: 'Conversation', defaultValue: {summary: 0}},
        },
        suggestions: {
            control: 'object',
            description: "Suggested questions displayed on the welcome screen. Array of `{ prompt: string, text?: string }` objects. `prompt` is the text sent to the API; `text` is the displayed label (optional, defaults to `prompt`).",
            table: {category: 'Welcome', defaultValue: {summary: 'undefined'}},
        },
    },
    args: {
        apiServiceUrl: '/api',
        apiKey: 'mock-key',
        model: 'gpt-mock',
        basePrompt: 'You are a helpful assistant.',
        includePageContent: true,
        pageContentSelector: '#content',
        pageContentClean: false,
        maxMessagesPerSession: 0,
        initialWidth: 380,
        initialHeight: 520,
    },
    render: (args) => <AIAssistant config={args}/>,
};

const DEMO_SUGGESTIONS = [
    {prompt: "De quoi parle ce document ?"},
    {prompt: "Résume ce document en quelques phrases."},
    {prompt: "Quelles sont les décisions prises ?"},
];

export const MockFloating = {
    name: 'Mock API / Floating',
    args: {
        mode: 'floating'
    },
};

export const MockFixed = {
    name: 'Mock API / Fixed',
    args: {
        mode: 'fixed'
    },
};

export const MockFixedWithMessageLimit = {
    name: 'Mock API / Fixed + message limit',
    args: {
        mode: 'fixed',
        maxMessagesPerSession: 2,
    },
};

export const Live = {
    name: 'Omnia API / Fixed',
    args: {
        mode: 'fixed',
        apiServiceUrl: liveApiUrl || '/omnia-proxy',
        apiKey: liveApiKey || '',
        model: liveModel || '',
        basePrompt: 'Tu es un assistant utile.',
    },
};

export const LiveWithPageContent = {
    name: 'Omnia API / Fixed + page content',
    argTypes: {
        example: {
            control: {type: 'select'},
            options: Object.keys(PAGE_EXAMPLES),
            description: 'Content page example to load in the story. This allows testing the assistant with real page content without needing to navigate to an actual page in the browser.',
            table: {category: 'Page content'},
        },
    },
    args: {
        mode: 'fixed',
        initialHeight: 720,
        apiServiceUrl: liveApiUrl || '/omnia-proxy',
        apiKey: liveApiKey || '',
        model: liveModel || '',
        basePrompt: "Tu es Omnia, un assistant intégré à deliberations.be, une plateforme où les autorités locales wallonnes publient leurs décisions et documents officiels.\n\n## Ton rôle\nAider les visiteurs à comprendre le contenu de la page qu'ils sont en train de lire. Le contenu de la page te sera fourni dans chaque conversation.\n\n## Tu peux\n- Expliquer ou clarifier le contenu de la page en langage clair et accessible\n- Résumer des sections ou l'intégralité du document\n- Répondre aux questions directement tirées du contenu de la page\n- Définir des termes administratifs ou juridiques présents dans le document\n\n## Tu ne peux pas\n- Répondre à des questions sans rapport avec le contenu de la page en cours\n- Fournir des conseils juridiques ou des interprétations officielles\n- Prendre des engagements ou faire des déclarations au nom d'une autorité locale, d'une administration ou d'iMio\n- Participer à des discussions politiques ou exprimer des opinions sur les décisions\n- Répondre à des questions portant sur d'autres pages, documents ou sujets externes non présents dans le contenu fourni\n\n## Comment gérer les demandes hors sujet\nSi un visiteur pose une question hors de ton périmètre, réponds-lui poliment que tu es uniquement en mesure de l'aider à comprendre le contenu de la page en cours, et suggère-lui de contacter directement l'autorité compétente pour toute autre demande.\n\n## Ton ton\n- Clair, neutre et accessible: de nombreux visiteurs ne sont pas des experts juridiques ou administratifs\n- Jamais spéculatif: si quelque chose n'est pas indiqué sur la page, dis-le explicitement\n- N'utilise jamais \"je pense\", \"je crois\" ou des formulations similaires pour parler du contenu de la page: soit c'est écrit, soit ça ne l'est pas\n\n## Important\nTu n'as aucune autorité, aucune affiliation et aucune responsabilité. Tu es uniquement un outil d'aide à la lecture. Ne donne jamais l'impression de représenter ou de parler au nom d'une institution.",
        includePageContent: true,
        pageContentSelector: "#content",
        pageContentClean: true,
        example: "Publication (ordonnance de police)",
        maxContextChars: 20000,
        initialWidth: 460,
        suggestions: DEMO_SUGGESTIONS
    },
    render: ({example, ...args}) => (
        <div className="border mx-16 my-8 p-4 rounded-xl" style={{minHeight: '80vh'}}>
            <div className="prose max-w-none" dangerouslySetInnerHTML={{__html: PAGE_EXAMPLES[example]}}/>
            <AIAssistant key={example} config={args}/>
        </div>
    ),
};
