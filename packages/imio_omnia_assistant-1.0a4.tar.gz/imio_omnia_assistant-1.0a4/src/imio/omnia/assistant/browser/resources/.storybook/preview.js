import '../src/styles/index.css';

window.omnia_assistant_settings = {
  api_service_url: import.meta.env.VITE_OMNIA_BASE_URL || '/api',
  api_key: import.meta.env.VITE_OMNIA_API_KEY || 'mock-key',
  model: import.meta.env.VITE_OMNIA_MODEL || 'gpt-mock',
  base_prompt: 'You are a helpful assistant.',
};

/** @type { import('storybook').Preview } */
const preview = {
  parameters: {
    layout: 'fullscreen',
  },
};

export default preview;
