function getWindowConfig() {
    if (typeof window === "undefined") {
        return {};
    }
    return window.omnia_assistant_settings ?? {};
}

export function readConfigValue(config = {}, camelKey, snakeKey, fallback) {
    if (config?.[camelKey] !== undefined) {
        return config[camelKey];
    }
    if (snakeKey && config?.[snakeKey] !== undefined) {
        return config[snakeKey];
    }

    const windowConfig = getWindowConfig();
    if (windowConfig?.[camelKey] !== undefined) {
        return windowConfig[camelKey];
    }
    if (snakeKey && windowConfig?.[snakeKey] !== undefined) {
        return windowConfig[snakeKey];
    }

    return fallback;
}
