import OmniaIcon from "../assets/omnia-icon.svg?react";
import ArrowClockwiseIcon from "../assets/arrow-clockwise.svg?react";
import {useAssistantRuntime} from "@assistant-ui/react";



const HEADER_BUTTON_CLASSNAMES = "cursor-pointer rounded p-1 text-gray-500 hover:bg-black/5 hover:text-gray-500 w-6";

function NewThreadButton() {
    const runtime = useAssistantRuntime();
    return (
        <button
            onClick={() => runtime.threads.switchToNewThread()}
            onPointerDown={(e) => e.stopPropagation()}
            className={HEADER_BUTTON_CLASSNAMES}
            title="Nouvelle conversation"
            aria-label="Nouvelle conversation"
        >
            <ArrowClockwiseIcon></ArrowClockwiseIcon>
        </button>
    );
}


function CloseButton({onClick}) {
    return (
        <button
            onClick={onClick}
            onPointerDown={(e) => e.stopPropagation()}
            className={HEADER_BUTTON_CLASSNAMES}
            aria-label="Fermer"
        >
            &#x2715;
        </button>
    );
}


export default function PanelHeader({isFixed, isMobile, dragControls, onClose}) {
    const isDraggable = !isFixed && !isMobile;
    return (
        <div
            className={`flex shrink-0 items-center justify-between rounded-t-lg border-b border-gray-100 bg-white px-3 py-2.5 select-none${isDraggable ? " cursor-grab active:cursor-grabbing" : ""}`}
            onPointerDown={isDraggable ? (e) => dragControls.start(e) : undefined}
        >
            <div className="flex items-center gap-2">
                <OmniaIcon className="h-7 w-7 flex-shrink-0" />
                <span className="text-[14px] text-gray-700">Omnia – L'assistant IA d'iMio</span>
            </div>
            <div className="flex gap-1 items-stretch">
                <NewThreadButton />
                <CloseButton onClick={onClose} />
            </div>
        </div>
    );
}
