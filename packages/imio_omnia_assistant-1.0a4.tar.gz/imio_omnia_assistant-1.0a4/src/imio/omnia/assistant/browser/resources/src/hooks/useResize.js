/**
 * Handles pointer-event-based resizing of the floating panel.
 *
 * On pointerdown on the resize handle, tracks pointermove to compute a new
 * width and height relative to the drag start position, clamped to a minimum
 * of 280×200 px and a maximum of viewport minus 32 px on each axis.
 *
 * @param {import('react').RefObject} panelRef - Ref to the panel DOM element.
 * @param {Function} setPanelSize - State setter accepting `{ width, height }`.
 * @returns {{ onResizePointerDown: Function }} Event handler to attach to the resize handle.
 */
export default function useResize(panelRef, setPanelSize) {
    function onResizePointerDown(e) {
        e.preventDefault();
        e.stopPropagation();
        const startX = e.clientX;
        const startY = e.clientY;
        const startWidth = panelRef.current.offsetWidth;
        const startHeight = panelRef.current.offsetHeight;

        const onMove = (ev) => {
            const newWidth = Math.max(280, Math.min(startWidth + ev.clientX - startX, window.innerWidth - 32));
            const newHeight = Math.max(200, Math.min(startHeight + ev.clientY - startY, window.innerHeight - 32));
            setPanelSize({width: newWidth, height: newHeight});
        };
        const onUp = () => {
            document.removeEventListener("pointermove", onMove);
            document.removeEventListener("pointerup", onUp);
        };
        document.addEventListener("pointermove", onMove);
        document.addEventListener("pointerup", onUp);
    }

    return {onResizePointerDown};
}
