import {readConfigValue} from "./config";

export default function readPageContent(config = {}) {
    const pageContentSelector = readConfigValue(config, "pageContentSelector", "page_content_selector", "#content");
    const pageContentClean = readConfigValue(config, "pageContentClean", "page_content_clean", false);

    if (typeof document === "undefined") return "No content found on the page.";

    const selectors = Array.isArray(pageContentSelector) ? pageContentSelector : [pageContentSelector];
    const parts = [];
    for (const selector of selectors) {
        for (const node of document.querySelectorAll(selector)) {
            const raw = (pageContentClean ? node.innerText : node.innerHTML).trim();
            if (raw) parts.push(raw);
        }
    }
    return parts.length > 0 ? parts.join("\n\n") : "No content found on the page.";
}
