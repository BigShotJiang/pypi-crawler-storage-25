import {useEffect, useState} from "react";
import Mousetrap from "mousetrap";

/**
 * Binds the Alt+I keyboard shortcut to toggle the assistant panel open/closed.
 *
 * When opening, focuses the composer input after a short delay.
 * When closing, blurs it. Also patches the composer input with the "mousetrap"
 * class so Mousetrap captures keystrokes even when the input is focused.
 *
 * @param {boolean} isOpen - Whether the panel is currently open.
 * @param {Function} setIsOpen - State setter to toggle the panel.
 * @returns {{ hasMounted: boolean }} `hasMounted` is false on the first render,
 *   used to suppress entry animations.
 */
export default function useKeyboardShortcut(isOpen, setIsOpen) {
    const [hasMounted, setHasMounted] = useState(false);

    useEffect(() => {
        setHasMounted(true);
        const input = document.querySelector(".aui-composer-input");
        if (input && !input.className.includes("mousetrap")) {
            input.className += " mousetrap";
        }
    }, []);

    useEffect(() => {
        Mousetrap.bind("alt+i", () => {
            const input = document.querySelector(".aui-composer-input");
            if (isOpen) {
                input?.blur();
            } else {
                setTimeout(() => input?.focus(), 100);
            }
            setIsOpen(!isOpen);
        });
        return () => Mousetrap.unbind("alt+i");
    }, [isOpen]);

    return {hasMounted};
}
