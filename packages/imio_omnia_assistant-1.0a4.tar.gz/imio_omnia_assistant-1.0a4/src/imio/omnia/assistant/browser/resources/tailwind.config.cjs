/** @type {import('tailwindcss').Config} */
module.exports = {
    content: ['./src/**/*.{js,jsx}', './stories/**/*.{js,jsx}'],
    theme: {
        extend: {
            colors: {
                'imio-pink': {
                    DEFAULT: '#E6007E',
                    hover: '#CF0071',
                },
            },
        },
    },
    plugins: [
        require('tailwindcss-animate'),
        require('@assistant-ui/react-markdown/tailwindcss'),
        ...(process.env.STORYBOOK ? [require('@tailwindcss/typography')] : []),
    ],
};
