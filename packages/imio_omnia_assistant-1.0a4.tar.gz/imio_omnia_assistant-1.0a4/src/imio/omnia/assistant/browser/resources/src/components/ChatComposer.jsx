import {ComposerPrimitive, ThreadPrimitive, useThread} from "@assistant-ui/react";
import ArrowUpIcon from "../assets/arrow-up-short.svg?react";
import StopFillIcon from "../assets/stop-fill.svg?react";
import {readConfigValue} from "../utils/config";

function MessageLimitNotice({messageCount, maxMessages}) {
    return (
        <div className="mx-3 mb-2 rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-900">
            Limite atteinte pour cette conversation: {messageCount}/{maxMessages} messages.
            Démarrez une nouvelle conversation pour continuer.
        </div>
    );
}

export default function ChatComposer({config = {}}) {
    const maxMessagesPerSession = Number(
        readConfigValue(config, "maxMessagesPerSession", "max_messages_per_session", 0)
    ) || 0;
    const userMessagesCount = useThread(
        (thread) => thread.messages.filter((message) => message.role === "user").length
    );
    const isLimitReached =
        maxMessagesPerSession > 0 && userMessagesCount >= maxMessagesPerSession;

    return (
        <ComposerPrimitive.Root className="aui-composer-root">
            {isLimitReached && (
                <MessageLimitNotice
                    messageCount={userMessagesCount}
                    maxMessages={maxMessagesPerSession}
                />
            )}
            <ComposerPrimitive.Input
                className="aui-composer-input mousetrap"
                rows={1}
                autoFocus
                disabled={isLimitReached}
                placeholder={
                    isLimitReached
                        ? "Limite atteinte pour cette conversation"
                        : "Tapez votre message ici"
                }
            />
            <ThreadPrimitive.If running={false}>
                <ComposerPrimitive.Send
                    className="relative aui-button aui-button-icon aui-composer-send rounded-full shadow-sm bg-imio-pink disabled:cursor-not-allowed disabled:opacity-50"
                    title={isLimitReached ? "Démarrer une nouvelle conversation pour continuer" : "Envoyer"}
                    disabled={isLimitReached}
                >
                    <ArrowUpIcon width={24} height={24} className="absolute w-12 h-12 -mx-2 -my-2" />
                </ComposerPrimitive.Send>
            </ThreadPrimitive.If>
            <ThreadPrimitive.If running={true}>
                <ComposerPrimitive.Cancel className="aui-button aui-button-ghost aui-button-icon aui-composer-cancel rounded-full shadow-sm bg-imio-pink" title="Annuler">
                    <StopFillIcon />
                </ComposerPrimitive.Cancel>
            </ThreadPrimitive.If>
        </ComposerPrimitive.Root>
    );
}
