# arthur_client.api_bindings.PoliciesV1Api

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**check_assignment_compliance**](PoliciesV1Api.md#check_assignment_compliance) | **POST** /api/v1/policy_assignments/{assignment_id}/check_compliance | Check Assignment Compliance
[**check_model_compliance**](PoliciesV1Api.md#check_model_compliance) | **POST** /api/v1/models/{model_id}/check_compliance | Check Model Compliance
[**check_policy_compliance**](PoliciesV1Api.md#check_policy_compliance) | **POST** /api/v1/policies/{policy_id}/check_compliance | Check Policy Compliance
[**create_attestation**](PoliciesV1Api.md#create_attestation) | **POST** /api/v1/policy_assignments/{assignment_id}/attestations | Create Attestation
[**create_policy**](PoliciesV1Api.md#create_policy) | **POST** /api/v1/organization/policies | Create Policy
[**create_policy_alert_rule**](PoliciesV1Api.md#create_policy_alert_rule) | **POST** /api/v1/policies/{policy_id}/alert_rules | Create Policy Alert Rule
[**create_policy_assignments**](PoliciesV1Api.md#create_policy_assignments) | **POST** /api/v1/policies/{policy_id}/assignments | Create Policy Assignments
[**create_policy_attestation_rule**](PoliciesV1Api.md#create_policy_attestation_rule) | **POST** /api/v1/policies/{policy_id}/attestation_rules | Create Policy Attestation Rule
[**delete_policy**](PoliciesV1Api.md#delete_policy) | **DELETE** /api/v1/policies/{policy_id} | Delete Policy
[**delete_policy_alert_rule**](PoliciesV1Api.md#delete_policy_alert_rule) | **DELETE** /api/v1/policy_alert_rules/{rule_id} | Delete Policy Alert Rule
[**delete_policy_assignment**](PoliciesV1Api.md#delete_policy_assignment) | **DELETE** /api/v1/policy_assignments/{assignment_id} | Delete Policy Assignment
[**delete_policy_attestation_rule**](PoliciesV1Api.md#delete_policy_attestation_rule) | **DELETE** /api/v1/policy_attestation_rules/{rule_id} | Delete Policy Attestation Rule
[**get_policy**](PoliciesV1Api.md#get_policy) | **GET** /api/v1/policies/{policy_id} | Get Policy
[**get_policy_alert_rule**](PoliciesV1Api.md#get_policy_alert_rule) | **GET** /api/v1/policy_alert_rules/{rule_id} | Get Policy Alert Rule
[**get_policy_assignment**](PoliciesV1Api.md#get_policy_assignment) | **GET** /api/v1/policy_assignments/{assignment_id} | Get Policy Assignment
[**get_policy_attestation_rule**](PoliciesV1Api.md#get_policy_attestation_rule) | **GET** /api/v1/policy_attestation_rules/{rule_id} | Get Policy Attestation Rule
[**list_assignment_attestations**](PoliciesV1Api.md#list_assignment_attestations) | **GET** /api/v1/policy_assignments/{assignment_id}/attestations | List Assignment Attestations
[**list_model_attestations**](PoliciesV1Api.md#list_model_attestations) | **GET** /api/v1/models/{model_id}/attestations | List Model Attestations
[**list_model_policy_assignments**](PoliciesV1Api.md#list_model_policy_assignments) | **GET** /api/v1/models/{model_id}/assignments | List Model Policy Assignments
[**list_policies**](PoliciesV1Api.md#list_policies) | **GET** /api/v1/organization/policies | List Policies
[**list_policy_alert_rules**](PoliciesV1Api.md#list_policy_alert_rules) | **GET** /api/v1/policies/{policy_id}/alert_rules | List Policy Alert Rules
[**list_policy_assignments**](PoliciesV1Api.md#list_policy_assignments) | **GET** /api/v1/policies/{policy_id}/assignments | List Policy Assignments
[**list_policy_attestation_rules**](PoliciesV1Api.md#list_policy_attestation_rules) | **GET** /api/v1/policies/{policy_id}/attestation_rules | List Policy Attestation Rules
[**list_policy_compliance_history**](PoliciesV1Api.md#list_policy_compliance_history) | **GET** /api/v1/policies/{policy_id}/compliance_history | List Policy Compliance History
[**list_workspace_compliance**](PoliciesV1Api.md#list_workspace_compliance) | **GET** /api/v1/workspaces/{workspace_id}/compliance | List Workspace Compliance
[**list_workspace_policy_assignments**](PoliciesV1Api.md#list_workspace_policy_assignments) | **GET** /api/v1/workspaces/{workspace_id}/policy_assignments | List Workspace Policy Assignments
[**set_compliance_status**](PoliciesV1Api.md#set_compliance_status) | **PUT** /api/v1/policy_assignments/{assignment_id}/compliance_status | Set Compliance Status
[**update_policy**](PoliciesV1Api.md#update_policy) | **PATCH** /api/v1/policies/{policy_id} | Update Policy
[**update_policy_alert_rule**](PoliciesV1Api.md#update_policy_alert_rule) | **PATCH** /api/v1/policy_alert_rules/{rule_id} | Update Policy Alert Rule
[**update_policy_attestation_rule**](PoliciesV1Api.md#update_policy_attestation_rule) | **PATCH** /api/v1/policy_attestation_rules/{rule_id} | Update Policy Attestation Rule


# **check_assignment_compliance**
> JobsBatch check_assignment_compliance(assignment_id)

Check Assignment Compliance

Enqueues a compliance check job for a specific policy assignment. Requires policy_assignment_check_compliance permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.jobs_batch import JobsBatch
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.PoliciesV1Api(api_client)
    assignment_id = 'assignment_id_example' # str | 

    try:
        # Check Assignment Compliance
        api_response = api_instance.check_assignment_compliance(assignment_id)
        print("The response of PoliciesV1Api->check_assignment_compliance:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PoliciesV1Api->check_assignment_compliance: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **assignment_id** | **str**|  | 

### Return type

[**JobsBatch**](JobsBatch.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**202** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **check_model_compliance**
> JobsBatch check_model_compliance(model_id)

Check Model Compliance

Enqueues a compliance check job for all assignments on this model. Requires model_check_compliance permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.jobs_batch import JobsBatch
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.PoliciesV1Api(api_client)
    model_id = 'model_id_example' # str | 

    try:
        # Check Model Compliance
        api_response = api_instance.check_model_compliance(model_id)
        print("The response of PoliciesV1Api->check_model_compliance:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PoliciesV1Api->check_model_compliance: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **model_id** | **str**|  | 

### Return type

[**JobsBatch**](JobsBatch.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**202** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **check_policy_compliance**
> JobsBatch check_policy_compliance(policy_id)

Check Policy Compliance

Enqueues a compliance check job for every assignment in this policy. Requires policy_check_compliance permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.jobs_batch import JobsBatch
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.PoliciesV1Api(api_client)
    policy_id = 'policy_id_example' # str | 

    try:
        # Check Policy Compliance
        api_response = api_instance.check_policy_compliance(policy_id)
        print("The response of PoliciesV1Api->check_policy_compliance:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PoliciesV1Api->check_policy_compliance: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **policy_id** | **str**|  | 

### Return type

[**JobsBatch**](JobsBatch.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**202** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_attestation**
> AttestationRecord create_attestation(assignment_id, post_attestation_record)

Create Attestation

Submits an attestation for a policy assignment. Requires policy_assignment_create_attestation permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.attestation_record import AttestationRecord
from arthur_client.api_bindings.models.post_attestation_record import PostAttestationRecord
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.PoliciesV1Api(api_client)
    assignment_id = 'assignment_id_example' # str | 
    post_attestation_record = arthur_client.api_bindings.PostAttestationRecord() # PostAttestationRecord | 

    try:
        # Create Attestation
        api_response = api_instance.create_attestation(assignment_id, post_attestation_record)
        print("The response of PoliciesV1Api->create_attestation:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PoliciesV1Api->create_attestation: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **assignment_id** | **str**|  | 
 **post_attestation_record** | [**PostAttestationRecord**](PostAttestationRecord.md)|  | 

### Return type

[**AttestationRecord**](AttestationRecord.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_policy**
> PolicySummary create_policy(post_policy)

Create Policy

Creates a new policy with inline rules for the organization. At least one alert or attestation rule is required. Requires organization_create_policy permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.policy_summary import PolicySummary
from arthur_client.api_bindings.models.post_policy import PostPolicy
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.PoliciesV1Api(api_client)
    post_policy = arthur_client.api_bindings.PostPolicy() # PostPolicy | 

    try:
        # Create Policy
        api_response = api_instance.create_policy(post_policy)
        print("The response of PoliciesV1Api->create_policy:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PoliciesV1Api->create_policy: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **post_policy** | [**PostPolicy**](PostPolicy.md)|  | 

### Return type

[**PolicySummary**](PolicySummary.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_policy_alert_rule**
> PolicyAlertRule create_policy_alert_rule(policy_id, post_policy_alert_rule)

Create Policy Alert Rule

Creates a new alert rule for a policy. Propagates to all assigned applications. Requires policy_create_alert_rule permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.policy_alert_rule import PolicyAlertRule
from arthur_client.api_bindings.models.post_policy_alert_rule import PostPolicyAlertRule
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.PoliciesV1Api(api_client)
    policy_id = 'policy_id_example' # str | 
    post_policy_alert_rule = arthur_client.api_bindings.PostPolicyAlertRule() # PostPolicyAlertRule | 

    try:
        # Create Policy Alert Rule
        api_response = api_instance.create_policy_alert_rule(policy_id, post_policy_alert_rule)
        print("The response of PoliciesV1Api->create_policy_alert_rule:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PoliciesV1Api->create_policy_alert_rule: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **policy_id** | **str**|  | 
 **post_policy_alert_rule** | [**PostPolicyAlertRule**](PostPolicyAlertRule.md)|  | 

### Return type

[**PolicyAlertRule**](PolicyAlertRule.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**404** | Not Found |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_policy_assignments**
> ResourceListPolicyAssignment create_policy_assignments(policy_id, create_policy_assignments_request)

Create Policy Assignments

Applies a policy to one or more applications. Requires policy_assignment_create permission on the policy and model_assign_policy permission on each target application.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.create_policy_assignments_request import CreatePolicyAssignmentsRequest
from arthur_client.api_bindings.models.resource_list_policy_assignment import ResourceListPolicyAssignment
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.PoliciesV1Api(api_client)
    policy_id = 'policy_id_example' # str | 
    create_policy_assignments_request = arthur_client.api_bindings.CreatePolicyAssignmentsRequest() # CreatePolicyAssignmentsRequest | 

    try:
        # Create Policy Assignments
        api_response = api_instance.create_policy_assignments(policy_id, create_policy_assignments_request)
        print("The response of PoliciesV1Api->create_policy_assignments:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PoliciesV1Api->create_policy_assignments: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **policy_id** | **str**|  | 
 **create_policy_assignments_request** | [**CreatePolicyAssignmentsRequest**](CreatePolicyAssignmentsRequest.md)|  | 

### Return type

[**ResourceListPolicyAssignment**](ResourceListPolicyAssignment.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_policy_attestation_rule**
> PolicyAttestationRule create_policy_attestation_rule(policy_id, post_policy_attestation_rule)

Create Policy Attestation Rule

Creates a new attestation rule for a policy. Requires policy_create_attestation_rule permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.policy_attestation_rule import PolicyAttestationRule
from arthur_client.api_bindings.models.post_policy_attestation_rule import PostPolicyAttestationRule
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.PoliciesV1Api(api_client)
    policy_id = 'policy_id_example' # str | 
    post_policy_attestation_rule = arthur_client.api_bindings.PostPolicyAttestationRule() # PostPolicyAttestationRule | 

    try:
        # Create Policy Attestation Rule
        api_response = api_instance.create_policy_attestation_rule(policy_id, post_policy_attestation_rule)
        print("The response of PoliciesV1Api->create_policy_attestation_rule:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PoliciesV1Api->create_policy_attestation_rule: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **policy_id** | **str**|  | 
 **post_policy_attestation_rule** | [**PostPolicyAttestationRule**](PostPolicyAttestationRule.md)|  | 

### Return type

[**PolicyAttestationRule**](PolicyAttestationRule.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**404** | Not Found |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_policy**
> delete_policy(policy_id)

Delete Policy

Deletes a policy and cascades to all assignments, materialized rules, and attestation records. Requires policy_delete permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.PoliciesV1Api(api_client)
    policy_id = 'policy_id_example' # str | 

    try:
        # Delete Policy
        api_instance.delete_policy(policy_id)
    except Exception as e:
        print("Exception when calling PoliciesV1Api->delete_policy: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **policy_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_policy_alert_rule**
> delete_policy_alert_rule(rule_id)

Delete Policy Alert Rule

Deletes a policy alert rule. CASCADE deletes materialized rules. Rejected if this is the last rule on an applied policy. Requires policy_alert_rule_delete permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.PoliciesV1Api(api_client)
    rule_id = 'rule_id_example' # str | 

    try:
        # Delete Policy Alert Rule
        api_instance.delete_policy_alert_rule(rule_id)
    except Exception as e:
        print("Exception when calling PoliciesV1Api->delete_policy_alert_rule: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **rule_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**404** | Not Found |  -  |
**409** | Conflict |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_policy_assignment**
> delete_policy_assignment(assignment_id)

Delete Policy Assignment

Unapplies a policy from an application. Cascades to materialized alert rules and attestation records. Requires policy_assignment_delete permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.PoliciesV1Api(api_client)
    assignment_id = 'assignment_id_example' # str | 

    try:
        # Delete Policy Assignment
        api_instance.delete_policy_assignment(assignment_id)
    except Exception as e:
        print("Exception when calling PoliciesV1Api->delete_policy_assignment: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **assignment_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_policy_attestation_rule**
> delete_policy_attestation_rule(rule_id)

Delete Policy Attestation Rule

Deletes a policy attestation rule. Rejected if this is the last rule on an applied policy. Requires policy_attestation_rule_delete permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.PoliciesV1Api(api_client)
    rule_id = 'rule_id_example' # str | 

    try:
        # Delete Policy Attestation Rule
        api_instance.delete_policy_attestation_rule(rule_id)
    except Exception as e:
        print("Exception when calling PoliciesV1Api->delete_policy_attestation_rule: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **rule_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**404** | Not Found |  -  |
**409** | Conflict |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_policy**
> Policy get_policy(policy_id)

Get Policy

Returns a single policy by ID including nested alert rules and attestation rules. Requires policy_read permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.policy import Policy
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.PoliciesV1Api(api_client)
    policy_id = 'policy_id_example' # str | 

    try:
        # Get Policy
        api_response = api_instance.get_policy(policy_id)
        print("The response of PoliciesV1Api->get_policy:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PoliciesV1Api->get_policy: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **policy_id** | **str**|  | 

### Return type

[**Policy**](Policy.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_policy_alert_rule**
> PolicyAlertRule get_policy_alert_rule(rule_id)

Get Policy Alert Rule

Returns a single policy alert rule by ID. Requires policy_alert_rule_read permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.policy_alert_rule import PolicyAlertRule
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.PoliciesV1Api(api_client)
    rule_id = 'rule_id_example' # str | 

    try:
        # Get Policy Alert Rule
        api_response = api_instance.get_policy_alert_rule(rule_id)
        print("The response of PoliciesV1Api->get_policy_alert_rule:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PoliciesV1Api->get_policy_alert_rule: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **rule_id** | **str**|  | 

### Return type

[**PolicyAlertRule**](PolicyAlertRule.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**404** | Not Found |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_policy_assignment**
> PolicyAssignmentDetail get_policy_assignment(assignment_id)

Get Policy Assignment

Returns a single policy assignment with full policy and model detail. Requires policy_assignment_read permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.policy_assignment_detail import PolicyAssignmentDetail
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.PoliciesV1Api(api_client)
    assignment_id = 'assignment_id_example' # str | 

    try:
        # Get Policy Assignment
        api_response = api_instance.get_policy_assignment(assignment_id)
        print("The response of PoliciesV1Api->get_policy_assignment:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PoliciesV1Api->get_policy_assignment: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **assignment_id** | **str**|  | 

### Return type

[**PolicyAssignmentDetail**](PolicyAssignmentDetail.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_policy_attestation_rule**
> PolicyAttestationRule get_policy_attestation_rule(rule_id)

Get Policy Attestation Rule

Returns a single policy attestation rule by ID. Requires policy_attestation_rule_read permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.policy_attestation_rule import PolicyAttestationRule
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.PoliciesV1Api(api_client)
    rule_id = 'rule_id_example' # str | 

    try:
        # Get Policy Attestation Rule
        api_response = api_instance.get_policy_attestation_rule(rule_id)
        print("The response of PoliciesV1Api->get_policy_attestation_rule:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PoliciesV1Api->get_policy_attestation_rule: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **rule_id** | **str**|  | 

### Return type

[**PolicyAttestationRule**](PolicyAttestationRule.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**404** | Not Found |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_assignment_attestations**
> ResourceListAttestationRecord list_assignment_attestations(assignment_id, page=page, page_size=page_size)

List Assignment Attestations

Lists attestation history for a policy assignment. Requires policy_assignment_list_attestations permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.resource_list_attestation_record import ResourceListAttestationRecord
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.PoliciesV1Api(api_client)
    assignment_id = 'assignment_id_example' # str | 
    page = 1 # int | The page to return starting from 1 up to total_pages. (optional) (default to 1)
    page_size = 20 # int | The number of records per page. The max is 1000. (optional) (default to 20)

    try:
        # List Assignment Attestations
        api_response = api_instance.list_assignment_attestations(assignment_id, page=page, page_size=page_size)
        print("The response of PoliciesV1Api->list_assignment_attestations:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PoliciesV1Api->list_assignment_attestations: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **assignment_id** | **str**|  | 
 **page** | **int**| The page to return starting from 1 up to total_pages. | [optional] [default to 1]
 **page_size** | **int**| The number of records per page. The max is 1000. | [optional] [default to 20]

### Return type

[**ResourceListAttestationRecord**](ResourceListAttestationRecord.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_model_attestations**
> ResourceListAttestationRecord list_model_attestations(model_id, latest=latest, valid=valid, policy_assignment_id=policy_assignment_id, page=page, page_size=page_size)

List Model Attestations

Lists all attestations across all policy assignments for an application. Requires model_list_attestations permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.resource_list_attestation_record import ResourceListAttestationRecord
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.PoliciesV1Api(api_client)
    model_id = 'model_id_example' # str | 
    latest = False # bool | If true, only return the most recent attestation for each rule. (optional) (default to False)
    valid = False # bool | If true, only return attestations that have not expired. (optional) (default to False)
    policy_assignment_id = 'policy_assignment_id_example' # str | Optional policy assignment ID to filter attestations by. (optional)
    page = 1 # int | The page to return starting from 1 up to total_pages. (optional) (default to 1)
    page_size = 20 # int | The number of records per page. The max is 1000. (optional) (default to 20)

    try:
        # List Model Attestations
        api_response = api_instance.list_model_attestations(model_id, latest=latest, valid=valid, policy_assignment_id=policy_assignment_id, page=page, page_size=page_size)
        print("The response of PoliciesV1Api->list_model_attestations:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PoliciesV1Api->list_model_attestations: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **model_id** | **str**|  | 
 **latest** | **bool**| If true, only return the most recent attestation for each rule. | [optional] [default to False]
 **valid** | **bool**| If true, only return attestations that have not expired. | [optional] [default to False]
 **policy_assignment_id** | **str**| Optional policy assignment ID to filter attestations by. | [optional] 
 **page** | **int**| The page to return starting from 1 up to total_pages. | [optional] [default to 1]
 **page_size** | **int**| The number of records per page. The max is 1000. | [optional] [default to 20]

### Return type

[**ResourceListAttestationRecord**](ResourceListAttestationRecord.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_model_policy_assignments**
> ResourceListPolicyAssignment list_model_policy_assignments(model_id, assignment_id=assignment_id, name=name, page=page, page_size=page_size)

List Model Policy Assignments

Lists all policy assignments for an application including policy summary and compliance status. Requires model_list_policy_assignments permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.resource_list_policy_assignment import ResourceListPolicyAssignment
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.PoliciesV1Api(api_client)
    model_id = 'model_id_example' # str | 
    assignment_id = 'assignment_id_example' # str | Optional assignment ID to filter by. (optional)
    name = 'name_example' # str | Filter by policy name (case-insensitive partial match). (optional)
    page = 1 # int | The page to return starting from 1 up to total_pages. (optional) (default to 1)
    page_size = 20 # int | The number of records per page. The max is 1000. (optional) (default to 20)

    try:
        # List Model Policy Assignments
        api_response = api_instance.list_model_policy_assignments(model_id, assignment_id=assignment_id, name=name, page=page, page_size=page_size)
        print("The response of PoliciesV1Api->list_model_policy_assignments:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PoliciesV1Api->list_model_policy_assignments: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **model_id** | **str**|  | 
 **assignment_id** | **str**| Optional assignment ID to filter by. | [optional] 
 **name** | **str**| Filter by policy name (case-insensitive partial match). | [optional] 
 **page** | **int**| The page to return starting from 1 up to total_pages. | [optional] [default to 1]
 **page_size** | **int**| The number of records per page. The max is 1000. | [optional] [default to 20]

### Return type

[**ResourceListPolicyAssignment**](ResourceListPolicyAssignment.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_policies**
> ResourceListPolicy list_policies(sort=sort, order=order, name=name, page=page, page_size=page_size)

List Policies

Lists all policies for the organization. Requires organization_list_policies permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.policy_sort import PolicySort
from arthur_client.api_bindings.models.resource_list_policy import ResourceListPolicy
from arthur_client.api_bindings.models.sort_order import SortOrder
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.PoliciesV1Api(api_client)
    sort = arthur_client.api_bindings.PolicySort() # PolicySort | Override the field used for sorting the returned list. (optional)
    order = arthur_client.api_bindings.SortOrder() # SortOrder | Override the sort order used. (optional)
    name = 'name_example' # str | Filter policies by name (case-insensitive partial match). (optional)
    page = 1 # int | The page to return starting from 1 up to total_pages. (optional) (default to 1)
    page_size = 20 # int | The number of records per page. The max is 1000. (optional) (default to 20)

    try:
        # List Policies
        api_response = api_instance.list_policies(sort=sort, order=order, name=name, page=page, page_size=page_size)
        print("The response of PoliciesV1Api->list_policies:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PoliciesV1Api->list_policies: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | [**PolicySort**](.md)| Override the field used for sorting the returned list. | [optional] 
 **order** | [**SortOrder**](.md)| Override the sort order used. | [optional] 
 **name** | **str**| Filter policies by name (case-insensitive partial match). | [optional] 
 **page** | **int**| The page to return starting from 1 up to total_pages. | [optional] [default to 1]
 **page_size** | **int**| The number of records per page. The max is 1000. | [optional] [default to 20]

### Return type

[**ResourceListPolicy**](ResourceListPolicy.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_policy_alert_rules**
> ResourceListPolicyAlertRule list_policy_alert_rules(policy_id, page=page, page_size=page_size, sort=sort, order=order, name=name)

List Policy Alert Rules

Lists alert rules for a policy. Requires policy_list_alert_rules permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.policy_sort import PolicySort
from arthur_client.api_bindings.models.resource_list_policy_alert_rule import ResourceListPolicyAlertRule
from arthur_client.api_bindings.models.sort_order import SortOrder
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.PoliciesV1Api(api_client)
    policy_id = 'policy_id_example' # str | 
    page = 1 # int |  (optional) (default to 1)
    page_size = 20 # int |  (optional) (default to 20)
    sort = arthur_client.api_bindings.PolicySort() # PolicySort |  (optional)
    order = arthur_client.api_bindings.SortOrder() # SortOrder |  (optional)
    name = 'name_example' # str | Filter by name (partial match). (optional)

    try:
        # List Policy Alert Rules
        api_response = api_instance.list_policy_alert_rules(policy_id, page=page, page_size=page_size, sort=sort, order=order, name=name)
        print("The response of PoliciesV1Api->list_policy_alert_rules:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PoliciesV1Api->list_policy_alert_rules: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **policy_id** | **str**|  | 
 **page** | **int**|  | [optional] [default to 1]
 **page_size** | **int**|  | [optional] [default to 20]
 **sort** | [**PolicySort**](.md)|  | [optional] 
 **order** | [**SortOrder**](.md)|  | [optional] 
 **name** | **str**| Filter by name (partial match). | [optional] 

### Return type

[**ResourceListPolicyAlertRule**](ResourceListPolicyAlertRule.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_policy_assignments**
> ResourceListPolicyAssignment list_policy_assignments(policy_id, compliance_status=compliance_status, name=name, page=page, page_size=page_size)

List Policy Assignments

Lists all assignments for a policy, filtered to applications the caller can access. Requires policy_list_assignments permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.compliance_status import ComplianceStatus
from arthur_client.api_bindings.models.resource_list_policy_assignment import ResourceListPolicyAssignment
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.PoliciesV1Api(api_client)
    policy_id = 'policy_id_example' # str | 
    compliance_status = arthur_client.api_bindings.ComplianceStatus() # ComplianceStatus | Filter by compliance status. (optional)
    name = 'name_example' # str | Filter by policy name (case-insensitive partial match). (optional)
    page = 1 # int | The page to return starting from 1 up to total_pages. (optional) (default to 1)
    page_size = 20 # int | The number of records per page. The max is 1000. (optional) (default to 20)

    try:
        # List Policy Assignments
        api_response = api_instance.list_policy_assignments(policy_id, compliance_status=compliance_status, name=name, page=page, page_size=page_size)
        print("The response of PoliciesV1Api->list_policy_assignments:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PoliciesV1Api->list_policy_assignments: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **policy_id** | **str**|  | 
 **compliance_status** | [**ComplianceStatus**](.md)| Filter by compliance status. | [optional] 
 **name** | **str**| Filter by policy name (case-insensitive partial match). | [optional] 
 **page** | **int**| The page to return starting from 1 up to total_pages. | [optional] [default to 1]
 **page_size** | **int**| The number of records per page. The max is 1000. | [optional] [default to 20]

### Return type

[**ResourceListPolicyAssignment**](ResourceListPolicyAssignment.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_policy_attestation_rules**
> ResourceListPolicyAttestationRule list_policy_attestation_rules(policy_id, page=page, page_size=page_size, sort=sort, order=order, name=name)

List Policy Attestation Rules

Lists attestation rules for a policy. Requires policy_list_attestation_rules permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.policy_sort import PolicySort
from arthur_client.api_bindings.models.resource_list_policy_attestation_rule import ResourceListPolicyAttestationRule
from arthur_client.api_bindings.models.sort_order import SortOrder
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.PoliciesV1Api(api_client)
    policy_id = 'policy_id_example' # str | 
    page = 1 # int |  (optional) (default to 1)
    page_size = 20 # int |  (optional) (default to 20)
    sort = arthur_client.api_bindings.PolicySort() # PolicySort |  (optional)
    order = arthur_client.api_bindings.SortOrder() # SortOrder |  (optional)
    name = 'name_example' # str | Filter by name (partial match). (optional)

    try:
        # List Policy Attestation Rules
        api_response = api_instance.list_policy_attestation_rules(policy_id, page=page, page_size=page_size, sort=sort, order=order, name=name)
        print("The response of PoliciesV1Api->list_policy_attestation_rules:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PoliciesV1Api->list_policy_attestation_rules: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **policy_id** | **str**|  | 
 **page** | **int**|  | [optional] [default to 1]
 **page_size** | **int**|  | [optional] [default to 20]
 **sort** | [**PolicySort**](.md)|  | [optional] 
 **order** | [**SortOrder**](.md)|  | [optional] 
 **name** | **str**| Filter by name (partial match). | [optional] 

### Return type

[**ResourceListPolicyAttestationRule**](ResourceListPolicyAttestationRule.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_policy_compliance_history**
> InfiniteResourceListComplianceRow list_policy_compliance_history(policy_id, compliance_status=compliance_status, model_id=model_id, rule_type=rule_type, rule_id=rule_id, sort=sort, order=order, page=page, page_size=page_size)

List Policy Compliance History

Returns the full rule compliance evaluation history for a policy. Requires policy_list_compliance_history permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.compliance_rule_status_filter import ComplianceRuleStatusFilter
from arthur_client.api_bindings.models.compliance_rule_type import ComplianceRuleType
from arthur_client.api_bindings.models.infinite_resource_list_compliance_row import InfiniteResourceListComplianceRow
from arthur_client.api_bindings.models.sort_order import SortOrder
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.PoliciesV1Api(api_client)
    policy_id = 'policy_id_example' # str | 
    compliance_status = arthur_client.api_bindings.ComplianceRuleStatusFilter() # ComplianceRuleStatusFilter | Filter by rule compliance status: 'COMPLIANT' or 'NON_COMPLIANT'. (optional)
    model_id = 'model_id_example' # str | Filter to a specific model. (optional)
    rule_type = arthur_client.api_bindings.ComplianceRuleType() # ComplianceRuleType | Filter by rule type: 'alert_rule' or 'attestation_rule'. (optional)
    rule_id = 'rule_id_example' # str | Filter to rows for a specific rule. (optional)
    sort = 'sort_example' # str | Sort field: rule_name, rule_type, compliance_status, updated_at, created_at. (optional)
    order = arthur_client.api_bindings.SortOrder() # SortOrder | Sort order: asc or desc. (optional)
    page = 1 # int | The page to return starting from 1 up to total_pages. (optional) (default to 1)
    page_size = 20 # int | The number of records per page. The max is 1000. (optional) (default to 20)

    try:
        # List Policy Compliance History
        api_response = api_instance.list_policy_compliance_history(policy_id, compliance_status=compliance_status, model_id=model_id, rule_type=rule_type, rule_id=rule_id, sort=sort, order=order, page=page, page_size=page_size)
        print("The response of PoliciesV1Api->list_policy_compliance_history:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PoliciesV1Api->list_policy_compliance_history: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **policy_id** | **str**|  | 
 **compliance_status** | [**ComplianceRuleStatusFilter**](.md)| Filter by rule compliance status: &#39;COMPLIANT&#39; or &#39;NON_COMPLIANT&#39;. | [optional] 
 **model_id** | **str**| Filter to a specific model. | [optional] 
 **rule_type** | [**ComplianceRuleType**](.md)| Filter by rule type: &#39;alert_rule&#39; or &#39;attestation_rule&#39;. | [optional] 
 **rule_id** | **str**| Filter to rows for a specific rule. | [optional] 
 **sort** | **str**| Sort field: rule_name, rule_type, compliance_status, updated_at, created_at. | [optional] 
 **order** | [**SortOrder**](.md)| Sort order: asc or desc. | [optional] 
 **page** | **int**| The page to return starting from 1 up to total_pages. | [optional] [default to 1]
 **page_size** | **int**| The number of records per page. The max is 1000. | [optional] [default to 20]

### Return type

[**InfiniteResourceListComplianceRow**](InfiniteResourceListComplianceRow.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**404** | Not Found |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_workspace_compliance**
> ComplianceResponse list_workspace_compliance(workspace_id, compliance_status=compliance_status, model_id=model_id, policy_id=policy_id, rule_type=rule_type, rule_id=rule_id, frequency=frequency, search=search, sort=sort, order=order, page=page, page_size=page_size)

List Workspace Compliance

Returns a flat compliance table with per-rule, per-model status across all policies in a workspace. Requires workspace_list_policy_compliance permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.compliance_response import ComplianceResponse
from arthur_client.api_bindings.models.compliance_rule_status_filter import ComplianceRuleStatusFilter
from arthur_client.api_bindings.models.compliance_rule_type import ComplianceRuleType
from arthur_client.api_bindings.models.sort_order import SortOrder
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.PoliciesV1Api(api_client)
    workspace_id = 'workspace_id_example' # str | 
    compliance_status = arthur_client.api_bindings.ComplianceRuleStatusFilter() # ComplianceRuleStatusFilter | Filter by rule compliance status: 'COMPLIANT' or 'NON_COMPLIANT'. (optional)
    model_id = 'model_id_example' # str | Filter to a specific model. (optional)
    policy_id = 'policy_id_example' # str | Filter to a specific policy. (optional)
    rule_type = arthur_client.api_bindings.ComplianceRuleType() # ComplianceRuleType | Filter by rule type: 'alert_rule' or 'attestation_rule'. (optional)
    rule_id = 'rule_id_example' # str | Filter to rows for a specific rule. (optional)
    frequency = 56 # int | Filter attestation rules by validity period in days. (optional)
    search = 'search_example' # str | Search across rule, model, and policy names (case-insensitive). (optional)
    sort = 'sort_example' # str | Sort field: rule_name, rule_type, compliance_status, updated_at, created_at. (optional)
    order = arthur_client.api_bindings.SortOrder() # SortOrder | Sort order: asc or desc. (optional)
    page = 1 # int | The page to return starting from 1 up to total_pages. (optional) (default to 1)
    page_size = 20 # int | The number of records per page. The max is 1000. (optional) (default to 20)

    try:
        # List Workspace Compliance
        api_response = api_instance.list_workspace_compliance(workspace_id, compliance_status=compliance_status, model_id=model_id, policy_id=policy_id, rule_type=rule_type, rule_id=rule_id, frequency=frequency, search=search, sort=sort, order=order, page=page, page_size=page_size)
        print("The response of PoliciesV1Api->list_workspace_compliance:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PoliciesV1Api->list_workspace_compliance: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workspace_id** | **str**|  | 
 **compliance_status** | [**ComplianceRuleStatusFilter**](.md)| Filter by rule compliance status: &#39;COMPLIANT&#39; or &#39;NON_COMPLIANT&#39;. | [optional] 
 **model_id** | **str**| Filter to a specific model. | [optional] 
 **policy_id** | **str**| Filter to a specific policy. | [optional] 
 **rule_type** | [**ComplianceRuleType**](.md)| Filter by rule type: &#39;alert_rule&#39; or &#39;attestation_rule&#39;. | [optional] 
 **rule_id** | **str**| Filter to rows for a specific rule. | [optional] 
 **frequency** | **int**| Filter attestation rules by validity period in days. | [optional] 
 **search** | **str**| Search across rule, model, and policy names (case-insensitive). | [optional] 
 **sort** | **str**| Sort field: rule_name, rule_type, compliance_status, updated_at, created_at. | [optional] 
 **order** | [**SortOrder**](.md)| Sort order: asc or desc. | [optional] 
 **page** | **int**| The page to return starting from 1 up to total_pages. | [optional] [default to 1]
 **page_size** | **int**| The number of records per page. The max is 1000. | [optional] [default to 20]

### Return type

[**ComplianceResponse**](ComplianceResponse.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_workspace_policy_assignments**
> ResourceListPolicyAssignment list_workspace_policy_assignments(workspace_id, policy_id=policy_id, compliance_status=compliance_status, name=name, page=page, page_size=page_size)

List Workspace Policy Assignments

Lists all policy assignments within a workspace, filtered to applications the caller can access. Requires workspace_list_policy_assignments permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.compliance_status import ComplianceStatus
from arthur_client.api_bindings.models.resource_list_policy_assignment import ResourceListPolicyAssignment
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.PoliciesV1Api(api_client)
    workspace_id = 'workspace_id_example' # str | 
    policy_id = 'policy_id_example' # str | Filter by policy ID. (optional)
    compliance_status = arthur_client.api_bindings.ComplianceStatus() # ComplianceStatus | Filter by compliance status. (optional)
    name = 'name_example' # str | Filter by policy name (case-insensitive partial match). (optional)
    page = 1 # int | The page to return starting from 1 up to total_pages. (optional) (default to 1)
    page_size = 20 # int | The number of records per page. The max is 1000. (optional) (default to 20)

    try:
        # List Workspace Policy Assignments
        api_response = api_instance.list_workspace_policy_assignments(workspace_id, policy_id=policy_id, compliance_status=compliance_status, name=name, page=page, page_size=page_size)
        print("The response of PoliciesV1Api->list_workspace_policy_assignments:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PoliciesV1Api->list_workspace_policy_assignments: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workspace_id** | **str**|  | 
 **policy_id** | **str**| Filter by policy ID. | [optional] 
 **compliance_status** | [**ComplianceStatus**](.md)| Filter by compliance status. | [optional] 
 **name** | **str**| Filter by policy name (case-insensitive partial match). | [optional] 
 **page** | **int**| The page to return starting from 1 up to total_pages. | [optional] [default to 1]
 **page_size** | **int**| The number of records per page. The max is 1000. | [optional] [default to 20]

### Return type

[**ResourceListPolicyAssignment**](ResourceListPolicyAssignment.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **set_compliance_status**
> PolicyAssignment set_compliance_status(assignment_id, set_compliance_status_request)

Set Compliance Status

Sets the compliance status for a policy assignment. Called by the data-plane compliance check executor. Requires policy_assignment_set_compliance_status permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.policy_assignment import PolicyAssignment
from arthur_client.api_bindings.models.set_compliance_status_request import SetComplianceStatusRequest
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.PoliciesV1Api(api_client)
    assignment_id = 'assignment_id_example' # str | 
    set_compliance_status_request = arthur_client.api_bindings.SetComplianceStatusRequest() # SetComplianceStatusRequest | 

    try:
        # Set Compliance Status
        api_response = api_instance.set_compliance_status(assignment_id, set_compliance_status_request)
        print("The response of PoliciesV1Api->set_compliance_status:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PoliciesV1Api->set_compliance_status: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **assignment_id** | **str**|  | 
 **set_compliance_status_request** | [**SetComplianceStatusRequest**](SetComplianceStatusRequest.md)|  | 

### Return type

[**PolicyAssignment**](PolicyAssignment.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_policy**
> Policy update_policy(policy_id, patch_policy)

Update Policy

Updates a policy's metadata or enforcement delay. Requires policy_update permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.patch_policy import PatchPolicy
from arthur_client.api_bindings.models.policy import Policy
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.PoliciesV1Api(api_client)
    policy_id = 'policy_id_example' # str | 
    patch_policy = arthur_client.api_bindings.PatchPolicy() # PatchPolicy | 

    try:
        # Update Policy
        api_response = api_instance.update_policy(policy_id, patch_policy)
        print("The response of PoliciesV1Api->update_policy:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PoliciesV1Api->update_policy: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **policy_id** | **str**|  | 
 **patch_policy** | [**PatchPolicy**](PatchPolicy.md)|  | 

### Return type

[**Policy**](Policy.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_policy_alert_rule**
> PolicyAlertRule update_policy_alert_rule(rule_id, patch_policy_alert_rule)

Update Policy Alert Rule

Updates a policy alert rule. Propagates to materialized rules on all assigned applications. Requires policy_alert_rule_update permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.patch_policy_alert_rule import PatchPolicyAlertRule
from arthur_client.api_bindings.models.policy_alert_rule import PolicyAlertRule
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.PoliciesV1Api(api_client)
    rule_id = 'rule_id_example' # str | 
    patch_policy_alert_rule = arthur_client.api_bindings.PatchPolicyAlertRule() # PatchPolicyAlertRule | 

    try:
        # Update Policy Alert Rule
        api_response = api_instance.update_policy_alert_rule(rule_id, patch_policy_alert_rule)
        print("The response of PoliciesV1Api->update_policy_alert_rule:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PoliciesV1Api->update_policy_alert_rule: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **rule_id** | **str**|  | 
 **patch_policy_alert_rule** | [**PatchPolicyAlertRule**](PatchPolicyAlertRule.md)|  | 

### Return type

[**PolicyAlertRule**](PolicyAlertRule.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**404** | Not Found |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_policy_attestation_rule**
> PolicyAttestationRule update_policy_attestation_rule(rule_id, patch_policy_attestation_rule)

Update Policy Attestation Rule

Updates a policy attestation rule. Requires policy_attestation_rule_update permission.

### Example

* OAuth Authentication (OAuth2AuthorizationCode):

```python
import arthur_client.api_bindings
from arthur_client.api_bindings.models.patch_policy_attestation_rule import PatchPolicyAttestationRule
from arthur_client.api_bindings.models.policy_attestation_rule import PolicyAttestationRule
from arthur_client.api_bindings.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = arthur_client.api_bindings.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with arthur_client.api_bindings.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = arthur_client.api_bindings.PoliciesV1Api(api_client)
    rule_id = 'rule_id_example' # str | 
    patch_policy_attestation_rule = arthur_client.api_bindings.PatchPolicyAttestationRule() # PatchPolicyAttestationRule | 

    try:
        # Update Policy Attestation Rule
        api_response = api_instance.update_policy_attestation_rule(rule_id, patch_policy_attestation_rule)
        print("The response of PoliciesV1Api->update_policy_attestation_rule:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PoliciesV1Api->update_policy_attestation_rule: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **rule_id** | **str**|  | 
 **patch_policy_attestation_rule** | [**PatchPolicyAttestationRule**](PatchPolicyAttestationRule.md)|  | 

### Return type

[**PolicyAttestationRule**](PolicyAttestationRule.md)

### Authorization

[OAuth2AuthorizationCode](../README.md#OAuth2AuthorizationCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**500** | Internal Server Error |  -  |
**404** | Not Found |  -  |
**422** | Validation Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

