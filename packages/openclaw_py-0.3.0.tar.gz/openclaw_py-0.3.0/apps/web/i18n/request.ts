import { getRequestConfig } from 'next-intl/server';
import { locales, type Locale } from '../i18n';

export default getRequestConfig(async ({ requestLocale }) => {
  // Get the locale from the request (from middleware)
  let locale = await requestLocale;

  // Validate that the locale is supported
  if (!locale || !locales.includes(locale as Locale)) {
    locale = 'en';
  }

  return {
    locale,
    messages: (await import(`../messages/${locale}.json`)).default,
  };
});
