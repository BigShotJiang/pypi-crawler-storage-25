import createMiddleware from 'next-intl/middleware';
import { locales, defaultLocale } from './i18n';

export default createMiddleware({
  locales,
  defaultLocale,
  localePrefix: 'always', // Always use /en/ or /zh/ prefix
});

export const config = {
  matcher: [
    // Match all pathnames except for
    // - api routes
    // - _next/static files
    // - _next/image files
    // - favicon.ico, sitemap.xml, robots.txt, manifest.json
    // - public files (images, icons, etc.)
    '/((?!api|_next|favicon.ico|sitemap.xml|robots.txt|manifest.json|sw.js|icons|images).*)',
  ],
};
