import { describe, it, expect, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import SessionsPage from '../../app/[locale]/sessions/page';

// Mock shared package with data
vi.mock('@pyclaw/shared', () => ({
  useGatewayWebSocket: () => ({
    connect: vi.fn(),
    connected: false,
    connectionState: 'disconnected' as const,
  }),
  useSessionsList: () => ({
    data: [
      { agentId: 'main', file: 'session-1.json', path: 'sessions/session-1.json', size: 2048 },
    ],
    isLoading: false,
    error: null,
  }),
}));

describe('SessionsPage - with data', () => {
  it('renders sessions list', async () => {
    const queryClient = new QueryClient({
      defaultOptions: { queries: { retry: false } },
    });

    render(
      <QueryClientProvider client={queryClient}>
        <SessionsPage />
      </QueryClientProvider>
    );

    await waitFor(() => {
      expect(screen.getByText('session-1.json')).toBeDefined();
    });
  });
});
