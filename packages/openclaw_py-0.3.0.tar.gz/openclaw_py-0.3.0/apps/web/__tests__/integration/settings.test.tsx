import { describe, it, expect, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import SettingsPage from '../../app/[locale]/settings/page';

// Mock shared package
vi.mock('@pyclaw/shared', async () => {
  return {
    useGatewayWebSocket: () => ({
      connect: vi.fn(),
      connected: false,
      connectionState: 'disconnected' as const,
    }),
    useConfig: () => ({
      data: { models: { default: 'claude-sonnet-4-6' } },
      isLoading: false,
      error: null,
    }),
    platform: {
      isTauri: false,
      isReactNative: false,
      isBrowser: true,
      isWeb: true,
    },
  };
});

describe('SettingsPage', () => {
  it('renders settings page with configuration', async () => {
    const queryClient = new QueryClient({
      defaultOptions: { queries: { retry: false } },
    });

    render(
      <QueryClientProvider client={queryClient}>
        <SettingsPage />
      </QueryClientProvider>
    );

    expect(screen.getByText('Settings')).toBeDefined();
    expect(screen.getByText('Configuration')).toBeDefined();
  });

  it('displays config JSON after loading', async () => {
    const queryClient = new QueryClient({
      defaultOptions: { queries: { retry: false } },
    });

    render(
      <QueryClientProvider client={queryClient}>
        <SettingsPage />
      </QueryClientProvider>
    );

    await waitFor(() => {
      expect(screen.getByText(/claude-sonnet/)).toBeDefined();
    });
  });
});
