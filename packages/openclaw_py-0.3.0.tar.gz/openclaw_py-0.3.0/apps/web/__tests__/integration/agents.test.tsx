import { describe, it, expect, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import AgentsPage from '../../app/[locale]/agents/page';

// Mock shared package
vi.mock('@pyclaw/shared', async () => {
  return {
    useGatewayWebSocket: () => ({
      connect: vi.fn(),
      connected: false,
      connectionState: 'disconnected' as const,
    }),
    useAgentsList: () => ({
      data: [
        { id: 'test-agent', session_count: 5, config: { name: 'Test Agent' } },
      ],
      isLoading: false,
      error: null,
    }),
    useCreateAgent: () => ({
      mutateAsync: vi.fn(),
      isPending: false,
    }),
  };
});

describe('AgentsPage', () => {
  it('renders agent list', async () => {
    const queryClient = new QueryClient({
      defaultOptions: { queries: { retry: false } },
    });

    render(
      <QueryClientProvider client={queryClient}>
        <AgentsPage />
      </QueryClientProvider>
    );

    await waitFor(() => {
      expect(screen.getByText('test-agent')).toBeDefined();
    });
  });
});
