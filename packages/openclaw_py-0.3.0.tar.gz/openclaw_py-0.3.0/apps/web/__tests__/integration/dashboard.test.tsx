import { describe, it, expect, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import DashboardPage from '../../app/[locale]/dashboard/page';

// Mock the WebSocket hook since we can't connect in tests
vi.mock('@pyclaw/shared', async () => {
  const actual = await vi.importActual('@pyclaw/shared');
  return {
    ...actual,
    useGatewayWebSocket: () => ({
      connect: vi.fn(),
      connected: false,
      connectionState: 'disconnected' as const,
    }),
  };
});

// Create a test query client
function createTestQueryClient() {
  return new QueryClient({
    defaultOptions: {
      queries: {
        retry: false,
        gcTime: 0,
        staleTime: 0,
      },
      mutations: {
        retry: false,
      },
    },
  });
}

// Wrapper for tests that need React Query
function TestWrapper({ children }: { children: React.ReactNode }) {
  const queryClient = createTestQueryClient();
  return (
    <QueryClientProvider client={queryClient}>
      {children}
    </QueryClientProvider>
  );
}

describe('DashboardPage', () => {
  it('renders dashboard with status cards', () => {
    render(<DashboardPage />, { wrapper: TestWrapper });

    expect(screen.getByText('Dashboard')).toBeDefined();
    expect(screen.getByText('Connection')).toBeDefined();
    expect(screen.getByText('Active Agents')).toBeDefined();
    expect(screen.getByText('Sessions')).toBeDefined();
    expect(screen.getByText('Messages Today')).toBeDefined();
  });

  it('shows disconnected status', () => {
    render(<DashboardPage />, { wrapper: TestWrapper });

    expect(screen.getByText('Disconnected')).toBeDefined();
    expect(screen.getByText('disconnected')).toBeDefined();
  });
});
