'use client';

import { useTranslations } from 'next-intl';
import { PageHeader, Card, CardContent, EmptyState, Button } from '@pyclaw/ui';
import { useUsageStats, useUsageDaily, useTokenSavings } from '@pyclaw/shared';
import { BarChart3, Clock, DollarSign, Loader2, Hash, TrendingDown, Zap } from 'lucide-react';
import { useState } from 'react';

const RANGE_OPTIONS = [
  { value: '1d', labelKey: '1Day' },
  { value: '7d', labelKey: '7Days' },
  { value: '30d', labelKey: '30Days' },
] as const;

type RangeValue = (typeof RANGE_OPTIONS)[number]['value'];

function formatNumber(num: number): string {
  if (num >= 1_000_000) {
    return (num / 1_000_000).toFixed(1) + 'M';
  }
  if (num >= 1_000) {
    return (num / 1_000).toFixed(1) + 'K';
  }
  return num.toString();
}

function formatCost(cost: number): string {
  return '$' + cost.toFixed(4);
}

function formatDate(dateStr: string): string {
  const date = new Date(dateStr);
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

function formatDateTime(dateStr: string): string {
  const date = new Date(dateStr);
  return date.toLocaleString('en-US', {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

interface StatCardProps {
  title: string;
  value: string;
  icon: React.ReactNode;
  description?: string;
}

function StatCard({ title, value, icon, description }: StatCardProps) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center gap-4">
          <div className="rounded-lg bg-primary/10 p-2.5">
            {icon}
          </div>
          <div>
            <p className="text-sm text-muted-foreground">{title}</p>
            <p className="text-2xl font-bold">{value}</p>
            {description && (
              <p className="text-xs text-muted-foreground mt-1">{description}</p>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

interface RangeSelectorProps {
  value: RangeValue;
  onChange: (value: RangeValue) => void;
  t: (key: string) => string;
}

function RangeSelector({ value, onChange, t }: RangeSelectorProps) {
  return (
    <div className="flex gap-1 rounded-lg border p-1">
      {RANGE_OPTIONS.map((option) => (
        <Button
          key={option.value}
          variant={value === option.value ? 'default' : 'ghost'}
          size="sm"
          onClick={() => onChange(option.value)}
          className="px-3"
        >
          {t(option.labelKey)}
        </Button>
      ))}
    </div>
  );
}

interface DailyChartProps {
  data: Array<{ date: string; tokens: number; calls: number }>;
  noDataText: string;
}

function DailyChart({ data, noDataText }: DailyChartProps) {
  if (data.length === 0) {
    return (
      <div className="flex h-48 items-center justify-center text-muted-foreground">
        {noDataText}
      </div>
    );
  }

  const maxTokens = Math.max(...data.map((d) => d.tokens), 1);

  return (
    <div className="space-y-3">
      {/* Y-axis labels */}
      <div className="flex justify-between text-xs text-muted-foreground">
        <span>{formatNumber(maxTokens)}</span>
        <span>0</span>
      </div>

      {/* Bar chart */}
      <div className="flex h-48 items-end gap-1">
        {data.map((point) => {
          const heightPercent = (point.tokens / maxTokens) * 100;
          return (
            <div
              key={point.date}
              className="group relative flex flex-1 flex-col items-center"
            >
              {/* Tooltip */}
              <div className="absolute -top-16 left-1/2 z-10 hidden w-24 -translate-x-1/2 rounded bg-popover px-2 py-1 text-xs shadow-lg group-hover:block">
                <div className="font-medium">{formatDate(point.date)}</div>
                <div className="text-muted-foreground">
                  {formatNumber(point.tokens)} tokens
                </div>
              </div>

              {/* Bar */}
              <div
                className="w-full rounded-t bg-primary/80 transition-all hover:bg-primary"
                style={{ height: `${Math.max(heightPercent, 2)}%` }}
              />
            </div>
          );
        })}
      </div>

      {/* X-axis labels */}
      <div className="flex gap-1">
        {data.map((point, index) => {
          // Show every nth label to avoid overcrowding
          const showLabel =
            data.length <= 7 ||
            index === 0 ||
            index === data.length - 1 ||
            index % Math.ceil(data.length / 7) === 0;

          return (
            <div
              key={point.date}
              className="flex-1 text-center text-xs text-muted-foreground"
            >
              {showLabel ? formatDate(point.date) : ''}
            </div>
          );
        })}
      </div>
    </div>
  );
}

interface SessionTableProps {
  sessions: Array<{
    id: string;
    name: string;
    tokens: number;
    input_tokens: number;
    output_tokens: number;
    calls: number;
    updated_at: string;
  }>;
  t: (key: string) => string;
}

function SessionTable({ sessions, t }: SessionTableProps) {
  if (sessions.length === 0) {
    return (
      <EmptyState
        title={t('noSessions')}
        description={t('noUsageData')}
        icon={<Clock className="h-12 w-12" />}
      />
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b text-left">
            <th className="py-3 pr-4 font-medium text-muted-foreground">
              {t('session')}
            </th>
            <th className="py-3 px-4 text-right font-medium text-muted-foreground">
              {t('tokens')}
            </th>
            <th className="py-3 px-4 text-right font-medium text-muted-foreground">
              {t('input')}
            </th>
            <th className="py-3 px-4 text-right font-medium text-muted-foreground">
              {t('output')}
            </th>
            <th className="py-3 px-4 text-right font-medium text-muted-foreground">
              {t('calls')}
            </th>
            <th className="py-3 pl-4 text-right font-medium text-muted-foreground">
              {t('lastActive')}
            </th>
          </tr>
        </thead>
        <tbody>
          {sessions.map((session) => (
            <tr
              key={session.id}
              className="border-b last:border-0 hover:bg-muted/50"
            >
              <td className="py-3 pr-4">
                <div className="font-medium">{session.name || session.id}</div>
                {session.name && (
                  <div className="text-xs text-muted-foreground">
                    {session.id}
                  </div>
                )}
              </td>
              <td className="py-3 px-4 text-right font-mono">
                {formatNumber(session.tokens)}
              </td>
              <td className="py-3 px-4 text-right font-mono text-muted-foreground">
                {formatNumber(session.input_tokens)}
              </td>
              <td className="py-3 px-4 text-right font-mono text-muted-foreground">
                {formatNumber(session.output_tokens)}
              </td>
              <td className="py-3 px-4 text-right font-mono text-muted-foreground">
                {session.calls}
              </td>
              <td className="py-3 pl-4 text-right text-muted-foreground">
                {formatDateTime(session.updated_at)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function UsagePage() {
  const t = useTranslations('pages.usage');
  const [range, setRange] = useState<RangeValue>('7d');

  const { data: statsData, isLoading: statsLoading } = useUsageStats(range);
  const { data: dailyData, isLoading: dailyLoading } = useUsageDaily(range);
  const { data: savingsData } = useTokenSavings();

  const isLoading = statsLoading || dailyLoading;

  return (
    <div className="flex h-full flex-col">
      <PageHeader
        title={t('title')}
        description={t('description')}
        icon={<BarChart3 className="h-5 w-5" />}
        actions={<RangeSelector value={range} onChange={setRange} t={t} />}
      />

      <div className="flex-1 overflow-auto p-6">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <div className="space-y-6">
            {/* Stat Cards */}
            <div className="grid gap-4 md:grid-cols-4">
              <StatCard
                title={t('totalTokens')}
                value={formatNumber(statsData?.total_tokens ?? 0)}
                icon={<Hash className="h-5 w-5 text-primary" />}
                description={t('lastDays').replace('{days}', String(statsData?.window_days ?? 7))}
              />
              <StatCard
                title={t('sessions')}
                value={(statsData?.sessions_count ?? 0).toString()}
                icon={<Clock className="h-5 w-5 text-primary" />}
                description={t('activeSessions')}
              />
              <StatCard
                title={t('estimatedCost')}
                value={formatCost(statsData?.cost_estimate ?? 0)}
                icon={<DollarSign className="h-5 w-5 text-primary" />}
                description={t('approximateCost')}
              />
              <StatCard
                title={t('tokensSaved')}
                value={formatNumber(savingsData?.total_savings ?? 0)}
                icon={<TrendingDown className="h-5 w-5 text-green-500" />}
                description={t('viaFeatures')}
              />
            </div>

            {/* Token Savings Breakdown */}
            {savingsData && savingsData.total_savings > 0 && (
              <Card>
                <CardContent className="p-6">
                  <h2 className="mb-4 text-lg font-semibold flex items-center gap-2">
                    <Zap className="h-5 w-5 text-green-500" />
                    {t('savingsBreakdown')}
                  </h2>
                  <div className="grid gap-4 md:grid-cols-3">
                    <div className="rounded-lg bg-muted/50 p-4">
                      <p className="text-sm text-muted-foreground">{t('anatomyLookups')}</p>
                      <p className="text-xl font-bold text-green-600">
                        {formatNumber(savingsData.anatomy_savings)}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {savingsData.lifetime_stats?.anatomy_hits ?? 0} {t('fileDescriptions')}
                      </p>
                    </div>
                    <div className="rounded-lg bg-muted/50 p-4">
                      <p className="text-sm text-muted-foreground">{t('repeatedReads')}</p>
                      <p className="text-xl font-bold text-green-600">
                        {formatNumber(savingsData.repeat_savings)}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {savingsData.lifetime_stats?.repeated_reads_blocked ?? 0} {t('duplicateReads')}
                      </p>
                    </div>
                    <div className="rounded-lg bg-muted/50 p-4">
                      <p className="text-sm text-muted-foreground">{t('totalSessions')}</p>
                      <p className="text-xl font-bold">
                        {savingsData.lifetime_stats?.total_sessions ?? 0}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {savingsData.lifetime_stats?.total_reads ?? 0} {t('readsTracked')}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Daily Usage Chart */}
            <Card>
              <CardContent className="p-6">
                <h2 className="mb-4 text-lg font-semibold">{t('dailyUsage')}</h2>
                <DailyChart data={dailyData ?? []} noDataText={t('noData')} />
              </CardContent>
            </Card>

            {/* Top Sessions */}
            <Card>
              <CardContent className="p-6">
                <h2 className="mb-4 text-lg font-semibold">
                  {t('topSessions')}
                </h2>
                <SessionTable sessions={statsData?.sessions ?? []} t={t} />
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
