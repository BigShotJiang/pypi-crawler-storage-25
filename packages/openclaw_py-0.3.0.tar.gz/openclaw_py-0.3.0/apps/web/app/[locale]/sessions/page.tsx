'use client';

import { useTranslations } from 'next-intl';
import { PageHeader, EmptyState, Button } from '@pyclaw/ui';
import { useSessionsList } from '@pyclaw/shared';
import { FileText, Plus, Loader2 } from 'lucide-react';

export default function SessionsPage() {
  const t = useTranslations('pages.sessions');
  const tCommon = useTranslations('common');
  const { data: sessions, isLoading, error } = useSessionsList();

  return (
    <div className="flex h-full flex-col">
      <PageHeader
        title={t('title')}
        description={t('description')}
        actions={<Button size="sm"><Plus className="mr-1 h-4 w-4" />{tCommon('create')}</Button>}
      />
      <div className="flex-1 overflow-auto p-4">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : error ? (
          <EmptyState
            title={t('errorLoading')}
            description={error.message}
            icon={<FileText className="h-12 w-12" />}
          />
        ) : sessions && sessions.length > 0 ? (
          <div className="space-y-2">
            {sessions.map((session) => (
              <div
                key={session.path}
                className="flex items-center justify-between rounded-lg border bg-card p-4"
              >
                <div>
                  <div className="font-medium">{session.file}</div>
                  <div className="text-sm text-muted-foreground">{session.agentId}</div>
                </div>
                <div className="text-sm text-muted-foreground">{(session.size / 1024).toFixed(1)} KB</div>
              </div>
            ))}
          </div>
        ) : (
          <EmptyState
            title={t('noSessions')}
            description={t('startConversation')}
            icon={<FileText className="h-12 w-12" />}
          />
        )}
      </div>
    </div>
  );
}
