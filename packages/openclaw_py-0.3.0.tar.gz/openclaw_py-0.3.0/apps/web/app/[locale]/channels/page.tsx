'use client';

import { useState } from 'react';
import { useTranslations } from 'next-intl';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { PageHeader, EmptyState } from '@pyclaw/ui';
import { Radio, Settings, RefreshCw, Check, X, Loader2, ChevronRight, Plus } from 'lucide-react';
import { channelsApi } from '@pyclaw/shared/api';
import type { ChannelResponse, ChannelCatalogEntry } from '@pyclaw/shared/types';
import { ChannelConfigSheet } from './channel-config-sheet';

// 通道图标映射
const CHANNEL_ICONS: Record<string, string> = {
  telegram: '✈️',
  discord: '💬',
  slack: '💼',
  feishu: '🪽',
  dingtalk: '📱',
  msteams: '👥',
  whatsapp: '📞',
  signal: '🔒',
  matrix: '🧩',
  irc: '💻',
  line: '💚',
  qq: '🐧',
  wecom: '🏢',
  webchat: '🌐',
};

// 通道颜色映射
const CHANNEL_COLORS: Record<string, string> = {
  telegram: '#0088cc',
  discord: '#5865F2',
  slack: '#4A154B',
  feishu: '#3370FF',
  dingtalk: '#0089FF',
  msteams: '#6264A7',
  whatsapp: '#25D366',
  signal: '#3A76F0',
  matrix: '#0DBD8B',
  line: '#00B900',
  qq: '#12B7F5',
  wecom: '#0082C9',
};

interface ChannelCardProps {
  channel: ChannelResponse;
  onConfigure: (channel: ChannelResponse) => void;
}

function ChannelCard({ channel, onConfigure }: ChannelCardProps) {
  const getStatusColor = () => {
    if (!channel.enabled) return 'bg-gray-100 text-gray-600';
    if (channel.running) return 'bg-green-100 text-green-700';
    return 'bg-yellow-100 text-yellow-700';
  };

  const getStatusText = () => {
    if (!channel.enabled) return '已禁用';
    if (channel.running) return '运行中';
    return '已配置';
  };

  // 优先使用 emoji 映射，否则使用默认
  const displayIcon = CHANNEL_ICONS[channel.id] || '📡';
  const displayColor = CHANNEL_COLORS[channel.id] || channel.color || '#6366f1';

  return (
    <div
      className="flex items-center justify-between p-4 bg-white rounded-lg border hover:shadow-md transition-shadow cursor-pointer"
      onClick={() => onConfigure(channel)}
    >
      <div className="flex items-center gap-4">
        <div
          className="w-12 h-12 rounded-lg flex items-center justify-center text-2xl"
          style={{ backgroundColor: displayColor + '20' }}
        >
          {displayIcon}
        </div>
        <div>
          <h3 className="font-semibold text-lg">{channel.display_name || channel.name}</h3>
          <div className="flex items-center gap-2 mt-1">
            <span className={`text-xs px-2 py-0.5 rounded-full ${getStatusColor()}`}>
              {getStatusText()}
            </span>
            {channel.category && (
              <span className="text-xs text-gray-500">{channel.category}</span>
            )}
          </div>
        </div>
      </div>
      <div className="flex items-center gap-2">
        {channel.running && (
          <span className="flex items-center gap-1 text-sm text-green-600">
            <Check className="h-4 w-4" />
            已连接
          </span>
        )}
        <ChevronRight className="h-5 w-5 text-gray-400" />
      </div>
    </div>
  );
}

interface CatalogChannelCardProps {
  entry: ChannelCatalogEntry;
  onConfigure: (entry: ChannelCatalogEntry) => void;
}

function CatalogChannelCard({ entry, onConfigure }: CatalogChannelCardProps) {
  const icon = CHANNEL_ICONS[entry.type] || '📡';
  const color = CHANNEL_COLORS[entry.type] || '#6366f1';

  return (
    <div
      className="flex items-center justify-between p-4 bg-white rounded-lg border border-dashed hover:shadow-md hover:border-solid transition-all cursor-pointer"
      onClick={() => onConfigure(entry)}
    >
      <div className="flex items-center gap-4">
        <div
          className="w-12 h-12 rounded-lg flex items-center justify-center text-2xl"
          style={{ backgroundColor: color + '20' }}
        >
          {icon}
        </div>
        <div>
          <h3 className="font-semibold text-lg">{entry.name}</h3>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-xs px-2 py-0.5 rounded-full bg-gray-100 text-gray-500">
              未配置
            </span>
            <span className="text-xs text-gray-500">{entry.category}</span>
            {entry.dm && (
              <span className="text-xs text-blue-500">DM</span>
            )}
            {entry.groups && (
              <span className="text-xs text-purple-500">群组</span>
            )}
          </div>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <Plus className="h-5 w-5 text-primary" />
      </div>
    </div>
  );
}

export default function ChannelsPage() {
  const t = useTranslations('pages.channels');
  const tCommon = useTranslations('common');
  const queryClient = useQueryClient();
  const [selectedChannel, setSelectedChannel] = useState<ChannelResponse | null>(null);
  const [selectedCatalogEntry, setSelectedCatalogEntry] = useState<ChannelCatalogEntry | null>(null);

  // 获取已配置的通道
  const { data: channelsData, isLoading: channelsLoading, error, refetch } = useQuery({
    queryKey: ['channels', 'list'],
    queryFn: () => channelsApi.list(),
  });

  // 获取所有可用通道 catalog
  const { data: catalogData, isLoading: catalogLoading } = useQuery({
    queryKey: ['channels', 'catalog'],
    queryFn: () => channelsApi.catalog(),
  });

  const channels = channelsData?.data?.channels || [];
  const catalog = catalogData?.data || [];

  // 找出已配置的通道 ID
  const configuredIds = new Set(channels.map(ch => ch.id));

  // 未配置的通道
  const unconfiguredCatalog = catalog.filter(entry => !configuredIds.has(entry.type));

  // 分类已配置的通道
  const runningChannels = channels.filter((ch) => ch.running);
  const configuredChannels = channels.filter((ch) => ch.enabled && !ch.running);
  const disabledChannels = channels.filter((ch) => !ch.enabled);

  const isLoading = channelsLoading || catalogLoading;

  // 打开配置面板
  const handleConfigureChannel = (channel: ChannelResponse) => {
    setSelectedChannel(channel);
    setSelectedCatalogEntry(null);
  };

  const handleConfigureCatalog = (entry: ChannelCatalogEntry) => {
    // 从 catalog entry 创建一个临时的 ChannelResponse
    const tempChannel: ChannelResponse = {
      id: entry.type,
      name: entry.name,
      running: false,
      enabled: false,
      status: 'unconfigured',
      source: 'catalog',
      display_name: entry.name,
      category: entry.category,
      color: CHANNEL_COLORS[entry.type] || null,
      icon: CHANNEL_ICONS[entry.type] || null,
      capabilities: {
        typing: false,
        reactions: entry.reactions,
        threads: entry.threads,
        editing: false,
        deletion: false,
        buttons: false,
        pins: false,
        read_receipts: false,
      },
      media_limits: null,
      supports_dm: entry.dm,
      supports_groups: entry.groups,
      metrics: null,
    };
    setSelectedChannel(tempChannel);
  };

  return (
    <div className="flex h-full flex-col">
      <PageHeader
        title={t('title')}
        description={t('description')}
        actions={
          <button
            onClick={() => refetch()}
            className="flex items-center gap-2 px-3 py-1.5 text-sm bg-white border rounded-lg hover:bg-gray-50"
          >
            <RefreshCw className="h-4 w-4" />
            {tCommon('refresh')}
          </button>
        }
      />

      <div className="flex-1 overflow-auto p-4">
        {isLoading ? (
          <div className="flex items-center justify-center h-64">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : error ? (
          <EmptyState
            title={t('errorLoading')}
            description={t('errorLoading')}
            icon={<X className="h-12 w-12 text-red-500" />}
          />
        ) : (
          <div className="space-y-8">
            {/* 运行中的通道 */}
            {runningChannels.length > 0 && (
              <section>
                <h2 className="text-sm font-medium text-gray-500 mb-3 flex items-center gap-2">
                  <Check className="h-4 w-4 text-green-600" />
                  运行中 ({runningChannels.length})
                </h2>
                <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                  {runningChannels.map((channel) => (
                    <ChannelCard
                      key={channel.id}
                      channel={channel}
                      onConfigure={handleConfigureChannel}
                    />
                  ))}
                </div>
              </section>
            )}

            {/* 已配置但未运行的通道 */}
            {configuredChannels.length > 0 && (
              <section>
                <h2 className="text-sm font-medium text-gray-500 mb-3 flex items-center gap-2">
                  <Settings className="h-4 w-4 text-yellow-600" />
                  已配置 ({configuredChannels.length})
                </h2>
                <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                  {configuredChannels.map((channel) => (
                    <ChannelCard
                      key={channel.id}
                      channel={channel}
                      onConfigure={handleConfigureChannel}
                    />
                  ))}
                </div>
              </section>
            )}

            {/* 已禁用的通道 */}
            {disabledChannels.length > 0 && (
              <section>
                <h2 className="text-sm font-medium text-gray-500 mb-3 flex items-center gap-2">
                  <X className="h-4 w-4 text-gray-400" />
                  已禁用 ({disabledChannels.length})
                </h2>
                <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 opacity-60">
                  {disabledChannels.map((channel) => (
                    <ChannelCard
                      key={channel.id}
                      channel={channel}
                      onConfigure={handleConfigureChannel}
                    />
                  ))}
                </div>
              </section>
            )}

            {/* 可用但未配置的通道 */}
            {unconfiguredCatalog.length > 0 && (
              <section>
                <h2 className="text-sm font-medium text-gray-500 mb-3 flex items-center gap-2">
                  <Plus className="h-4 w-4 text-primary" />
                  可用通道 ({unconfiguredCatalog.length})
                </h2>
                <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                  {unconfiguredCatalog.map((entry) => (
                    <CatalogChannelCard
                      key={entry.type}
                      entry={entry}
                      onConfigure={handleConfigureCatalog}
                    />
                  ))}
                </div>
              </section>
            )}

            {/* 空状态 */}
            {channels.length === 0 && catalog.length === 0 && (
              <EmptyState
                title={t('noChannels')}
                description={t('noChannels')}
                icon={<Radio className="h-12 w-12" />}
              />
            )}
          </div>
        )}
      </div>

      {/* 配置面板 */}
      <ChannelConfigSheet
        channel={selectedChannel}
        open={!!selectedChannel}
        onClose={() => {
          setSelectedChannel(null);
          setSelectedCatalogEntry(null);
        }}
        onUpdated={() => {
          queryClient.invalidateQueries({ queryKey: ['channels'] });
        }}
      />
    </div>
  );
}
