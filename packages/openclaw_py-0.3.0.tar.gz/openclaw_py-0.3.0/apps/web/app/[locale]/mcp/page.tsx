'use client';

import { useState, useEffect } from 'react';
import { useTranslations } from 'next-intl';
import { Puzzle, RefreshCw } from 'lucide-react';
import { PageHeader, EmptyState, McpServerCard, ToolList } from '@pyclaw/ui';
import { mcpApi } from '@pyclaw/shared';
import type { McpServer, McpTool } from '@pyclaw/shared/types';

export default function McpPage() {
  const t = useTranslations('pages.mcp');
  const tCommon = useTranslations('common');
  const [servers, setServers] = useState<McpServer[]>([]);
  const [totalTools, setTotalTools] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [expandedServer, setExpandedServer] = useState<string | null>(null);
  const [tools, setTools] = useState<McpTool[]>([]);
  const [toolsLoading, setToolsLoading] = useState(false);

  useEffect(() => {
    loadStatus();
  }, []);

  async function loadStatus() {
    setLoading(true);
    setError(null);
    const result = await mcpApi.status();
    if (result.data) {
      setServers(result.data.servers);
      setTotalTools(result.data.total_tools);
    } else {
      setError(result.error?.message || 'Failed to load MCP status');
    }
    setLoading(false);
  }

  async function loadTools(serverId: string) {
    setToolsLoading(true);
    const result = await mcpApi.tools(serverId);
    if (result.data) {
      setTools(result.data.tools);
    } else {
      setTools([]);
    }
    setToolsLoading(false);
  }

  function handleExpand(server: McpServer) {
    if (expandedServer === server.id) {
      setExpandedServer(null);
      setTools([]);
    } else {
      setExpandedServer(server.id);
      loadTools(server.id);
    }
  }

  const connectedCount = servers.filter((s) => s.status === 'connected').length;

  return (
    <div className="flex h-full flex-col">
      <PageHeader
        title={t('title')}
        description={t('description')}
        icon={<Puzzle />}
        actions={
          <button
            onClick={loadStatus}
            disabled={loading}
            className="flex items-center gap-1 rounded border px-3 py-1 text-sm hover:bg-muted disabled:opacity-50"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            {t('refresh')}
          </button>
        }
      />

      <div className="border-b p-4">
        <div className="flex gap-4 text-sm text-muted-foreground">
          <span>{servers.length} {t('servers')}</span>
          <span>{connectedCount} {t('connected')}</span>
          <span>{totalTools} {t('tools')}</span>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-4">
        {loading ? (
          <div className="flex h-32 items-center justify-center">
            <RefreshCw className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : error ? (
          <EmptyState
            icon={<Puzzle />}
            title={t('errorLoading')}
            description={error}
          />
        ) : servers.length === 0 ? (
          <EmptyState
            icon={<Puzzle />}
            title={t('noServers')}
            description={t('addServers')}
          />
        ) : (
          <div className="space-y-4">
            {servers.map((server) => (
              <div key={server.id}>
                <McpServerCard
                  server={server}
                  onExpand={() => handleExpand(server)}
                />
                {expandedServer === server.id && (
                  <div className="ml-4 mt-2">
                    {toolsLoading ? (
                      <div className="flex h-16 items-center justify-center">
                        <RefreshCw className="h-4 w-4 animate-spin text-muted-foreground" />
                      </div>
                    ) : (
                      <ToolList tools={tools} />
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
