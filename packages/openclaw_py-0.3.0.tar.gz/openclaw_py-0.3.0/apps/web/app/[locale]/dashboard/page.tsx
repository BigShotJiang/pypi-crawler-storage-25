'use client';

import { useTranslations } from 'next-intl';
import { PageHeader, StatusChip } from '@pyclaw/ui';
import { useGatewayWebSocket, useAgentsList, useSessionsList } from '@pyclaw/shared';

export default function DashboardPage() {
  const t = useTranslations('pages.dashboard');
  const tStatus = useTranslations('status');
  const { connected, connectionState } = useGatewayWebSocket();
  const { data: agents } = useAgentsList();
  const { data: sessions } = useSessionsList();

  return (
    <div className="flex h-full flex-col">
      <PageHeader
        title={t('title')}
        description={t('description')}
        actions={
          <StatusChip status={connected ? 'success' : 'error'}>
            {connected ? tStatus('connected') : tStatus('disconnected')}
          </StatusChip>
        }
      />
      <div className="flex-1 p-6">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <div className="rounded-lg border bg-card p-4">
            <div className="text-sm text-muted-foreground">{t('connection')}</div>
            <div className="text-2xl font-bold capitalize">{connectionState}</div>
          </div>
          <div className="rounded-lg border bg-card p-4">
            <div className="text-sm text-muted-foreground">{t('activeAgents')}</div>
            <div className="text-2xl font-bold">{agents?.length ?? '-'}</div>
          </div>
          <div className="rounded-lg border bg-card p-4">
            <div className="text-sm text-muted-foreground">{t('sessions')}</div>
            <div className="text-2xl font-bold">{sessions?.length ?? '-'}</div>
          </div>
          <div className="rounded-lg border bg-card p-4">
            <div className="text-sm text-muted-foreground">{t('messagesToday')}</div>
            <div className="text-2xl font-bold">-</div>
          </div>
        </div>
      </div>
    </div>
  );
}
