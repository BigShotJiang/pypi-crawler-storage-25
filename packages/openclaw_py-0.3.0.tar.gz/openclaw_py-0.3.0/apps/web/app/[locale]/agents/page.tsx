'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useTranslations } from 'next-intl';
import { PageHeader, Button, EmptyState, StatusChip } from '@pyclaw/ui';
import { useAgentsList, useCreateAgent } from '@pyclaw/shared';
import { Bot, Plus, Loader2 } from 'lucide-react';

export default function AgentsPage() {
  const router = useRouter();
  const t = useTranslations('pages.agents');
  const tCommon = useTranslations('common');
  const { data: agents, isLoading, error } = useAgentsList();
  const createAgent = useCreateAgent();
  const [isCreating, setIsCreating] = useState(false);
  const [newAgentId, setNewAgentId] = useState('');

  const handleCreateAgent = async () => {
    if (!newAgentId.trim()) return;
    setIsCreating(true);
    try {
      await createAgent.mutateAsync({ agent_id: newAgentId.trim() });
      router.push(`/agents/${newAgentId.trim()}`);
      setNewAgentId('');
    } finally {
      setIsCreating(false);
    }
  };

  return (
    <div className="flex h-full flex-col">
      <PageHeader
        title={t('title')}
        description={t('description')}
        actions={
          <Button size="sm" onClick={() => setNewAgentId('agent-' + Date.now())}>
            <Plus className="mr-1 h-4 w-4" />
            New Agent
          </Button>
        }
      />
      {newAgentId && (
        <div className="border-b bg-muted/50 p-4">
          <div className="flex items-center gap-4">
            <input
              type="text"
              value={newAgentId}
              onChange={(e) => setNewAgentId(e.target.value)}
              placeholder="Enter agent ID"
              className="flex-1 rounded-md border px-3 py-2 text-sm"
            />
            <Button
              size="sm"
              onClick={handleCreateAgent}
              disabled={isCreating || !newAgentId.trim()}
            >
              {isCreating ? <Loader2 className="h-4 w-4 animate-spin" /> : tCommon('create')}
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => setNewAgentId('')}
            >
              {tCommon('cancel')}
            </Button>
          </div>
        </div>
      )}
      <div className="flex-1 overflow-auto p-4">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : error ? (
          <EmptyState
            title={t('errorLoading')}
            description={error.message}
            icon={<Bot className="h-12 w-12" />}
          />
        ) : agents && agents.length > 0 ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {agents.map((agent) => (
              <button
                key={agent.id}
                onClick={() => router.push(`/agents/${agent.id}`)}
                className="rounded-lg border bg-card p-4 text-left transition-colors hover:bg-accent"
              >
                <div className="flex items-center justify-between">
                  <div className="font-medium">{agent.id}</div>
                  <StatusChip status="success">{agent.session_count ?? 0} sessions</StatusChip>
                </div>
                {agent.config?.name && (
                  <div className="mt-1 text-sm text-muted-foreground">
                    {agent.config.name}
                  </div>
                )}
              </button>
            ))}
          </div>
        ) : (
          <EmptyState
            title={t('noAgents')}
            description={t('createFirst')}
            icon={<Bot className="h-12 w-12" />}
            action={
              <Button onClick={() => setNewAgentId('agent-' + Date.now())}>
                <Plus className="mr-1 h-4 w-4" />Create Agent
              </Button>
            }
          />
        )}
      </div>
    </div>
  );
}