'use client';

import { useState, useEffect } from 'react';
import { useTranslations } from 'next-intl';
import { Search, Cpu, RefreshCw } from 'lucide-react';
import { PageHeader, EmptyState, ModelCard } from '@pyclaw/ui';
import { modelsApi } from '@pyclaw/shared';
import type { Model } from '@pyclaw/shared/types';

export default function ModelsPage() {
  const t = useTranslations('pages.models');
  const tCommon = useTranslations('common');
  const [models, setModels] = useState<Model[]>([]);
  const [defaultModel, setDefaultModel] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');

  useEffect(() => {
    loadModels();
  }, []);

  async function loadModels() {
    setLoading(true);
    setError(null);
    const result = await modelsApi.list();
    if (result.data) {
      setModels(result.data.models);
      setDefaultModel(result.data.default_model);
    } else {
      setError(result.error?.message || 'Failed to load models');
    }
    setLoading(false);
  }

  const filteredModels = models.filter(
    (m) =>
      m.name.toLowerCase().includes(search.toLowerCase()) ||
      m.id.toLowerCase().includes(search.toLowerCase()) ||
      m.provider.toLowerCase().includes(search.toLowerCase()) ||
      m.aliases.some((a) => a.toLowerCase().includes(search.toLowerCase()))
  );

  const grouped = groupByProvider(filteredModels);

  return (
    <div className="flex h-full flex-col">
      <PageHeader
        title={t('title')}
        description={t('description')}
        icon={<Cpu />}
        actions={
          <button
            onClick={loadModels}
            disabled={loading}
            className="flex items-center gap-1 rounded border px-3 py-1 text-sm hover:bg-muted disabled:opacity-50"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            {t('refresh')}
          </button>
        }
      />

      <div className="border-b p-4">
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            type="text"
            placeholder={t('searchPlaceholder')}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full rounded-lg border py-2 pl-10 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
          />
        </div>
      </div>

      <div className="flex-1 overflow-auto p-4">
        {loading ? (
          <div className="flex h-32 items-center justify-center">
            <RefreshCw className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : error ? (
          <EmptyState
            icon={<Cpu />}
            title={t('errorLoading')}
            description={error}
          />
        ) : filteredModels.length === 0 ? (
          <EmptyState
            icon={<Cpu />}
            title={t('noModels')}
            description={search ? t('tryDifferent') : t('configureProviders')}
          />
        ) : (
          <div className="space-y-6">
            {Object.entries(grouped).map(([provider, providerModels]) => (
              <div key={provider}>
                <h2 className="mb-3 text-lg font-semibold capitalize">{provider}</h2>
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {providerModels.map((model) => (
                    <ModelCard
                      key={model.id}
                      model={model}
                      isDefault={model.id === defaultModel}
                    />
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function groupByProvider(models: Model[]): Record<string, Model[]> {
  return models.reduce(
    (acc, model) => {
      const provider = model.provider;
      if (!acc[provider]) acc[provider] = [];
      acc[provider].push(model);
      return acc;
    },
    {} as Record<string, Model[]>
  );
}
