// Stub for @react-native-async-storage/async-storage
// This module is not available in web builds
// Real implementation is used only in React Native builds

export default {
  getItem: async () => null,
  setItem: async () => {},
  removeItem: async () => {},
};