// Stub for @tauri-apps/plugin-store
// This module is not available in web builds
// Real implementation is used only in Tauri desktop builds

export const Store = null;