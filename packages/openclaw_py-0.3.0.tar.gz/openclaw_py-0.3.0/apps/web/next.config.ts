import type { NextConfig } from "next";
import createNextIntlPlugin from "next-intl/plugin";
import path from "path";

// Check if we're building for Tauri or static export (gh-pages)
const isTauriBuild = process.env.TAURI_BUILD === "1";
const isStaticExport = process.env.STATIC_EXPORT === "1";
const shouldStaticExport = isTauriBuild || isStaticExport;

// Log for debugging
console.log("[next.config.ts] TAURI_BUILD:", process.env.TAURI_BUILD);
console.log("[next.config.ts] STATIC_EXPORT:", process.env.STATIC_EXPORT);
console.log("[next.config.ts] shouldStaticExport:", shouldStaticExport);

// next-intl plugin is needed for NextIntlClientProvider to work
const withNextIntl = createNextIntlPlugin("./i18n/request.ts");

const baseConfig: NextConfig = {
  trailingSlash: true,
  images: {
    unoptimized: true,
  },
  transpilePackages: ["@pyclaw/shared", "@pyclaw/ui"],
  webpack: (config) => {
    // Platform-specific modules are dynamically imported at runtime only on
    // their respective platforms (Tauri / React Native).  They are never
    // available in the web build, so we provide empty stubs.
    config.resolve.alias["@tauri-apps/plugin-store"] = path.resolve(
      __dirname,
      "stubs/tauri-plugin-store.ts"
    );
    config.resolve.alias["@react-native-async-storage/async-storage"] = path.resolve(
      __dirname,
      "stubs/async-storage.ts"
    );

    // Konva uses browser APIs and cannot be bundled for server
    // Note: moved this handling to be part of webpack config

    return config;
  },
};

// Apply next-intl plugin first
const configWithIntl = withNextIntl(baseConfig);

// For Tauri/static builds: static export, skip serwist
// For web builds: apply serwist
let finalConfig: NextConfig;

if (shouldStaticExport) {
  finalConfig = {
    ...configWithIntl,
    output: "export" as const,
  };
} else {
  // Web build: apply serwist
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const withSerwistInit = require("@serwist/next").default;

  const withSerwist = withSerwistInit({
    swSrc: "sw.ts",
    swDest: "public/sw.js",
    disable: process.env.NODE_ENV === "development",
  });

  finalConfig = withSerwist(configWithIntl);
}

console.log("[next.config.ts] Final config output:", (finalConfig as any).output);

export default finalConfig;
