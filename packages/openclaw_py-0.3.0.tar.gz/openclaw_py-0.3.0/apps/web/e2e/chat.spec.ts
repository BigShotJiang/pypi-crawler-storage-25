import { test, expect } from '@playwright/test';

test.describe('Chat Page', () => {
  test('should display chat interface', async ({ page }) => {
    // The app uses next-intl with locale prefix, default locale is 'en'
    await page.goto('/en/chat');
    await expect(page.getByRole('heading', { name: 'Chat' })).toBeVisible();
  });

  test('should show empty state when no messages', async ({ page }) => {
    await page.goto('/en/chat');
    // The empty state shows "No messages yet" or localized equivalent
    // Use getByRole for heading to be more precise
    await expect(page.getByRole('heading', { name: /No messages/i })).toBeVisible();
  });

  test('should redirect to locale-prefixed URL', async ({ page }) => {
    // Test that accessing /chat redirects to /en/chat (or user's locale)
    await page.goto('/chat');
    // Wait for redirect or check final URL
    await page.waitForURL(/\/(en|zh-CN)\/chat/);
    await expect(page.getByRole('heading', { name: 'Chat' })).toBeVisible();
  });
});