import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './apps/web/e2e',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: 'html',
  use: {
    baseURL: process.env.CI ? 'http://localhost:3000' : 'http://localhost:18000',
    trace: 'on-first-retry',
  },
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
  ],
  webServer: {
    command: process.env.CI ? 'pnpm --filter @pyclaw/web dev -p 3000' : 'pnpm --filter @pyclaw/web dev',
    url: process.env.CI ? 'http://localhost:3000' : 'http://localhost:18000',
    reuseExistingServer: !process.env.CI,
    timeout: 120000,
  },
});
