'use client';

import { useEffect } from 'react';
import Prism from 'prismjs';
import 'prismjs/components/prism-javascript';
import 'prismjs/components/prism-typescript';
import 'prismjs/components/prism-python';
import 'prismjs/components/prism-bash';
import 'prismjs/components/prism-json';
import 'prismjs/components/prism-markdown';
import 'prismjs/components/prism-yaml';
import 'prismjs/components/prism-toml';
import 'prismjs/components/prism-docker';
import 'prismjs/components/prism-css';
import 'prismjs/components/prism-sql';

interface CodeBlockProps {
  code: string;
  language?: string;
  filename?: string;
  showCopy?: boolean;
}

export function CodeBlock({
  code,
  language = 'typescript',
  filename,
  showCopy = true
}: CodeBlockProps) {
  useEffect(() => {
    // Ensure Prism is loaded
    if (typeof window !== 'undefined') {
      Prism.highlightAll();
    }
  }, [code, language]);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(code);
  };

  const normalizedLanguage = normalizeLanguage(language);

  return (
    <div className="relative group rounded-lg border bg-muted/30 overflow-hidden">
      {filename && (
        <div className="flex items-center gap-2 px-4 py-2 bg-muted/50 border-b">
          <svg className="w-4 h-4 text-muted-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
          <span className="text-sm font-mono text-muted-foreground">{filename}</span>
        </div>
      )}
      <pre className={`language-${normalizedLanguage} !bg-transparent !m-0 !p-4 overflow-x-auto`}>
        <code className={`language-${normalizedLanguage}`}>
          {code}
        </code>
      </pre>
      {showCopy && (
        <button
          onClick={handleCopy}
          className="absolute top-2 right-2 p-2 rounded-md bg-background/80 hover:bg-background border opacity-0 group-hover:opacity-100 transition-opacity"
          title="Copy code"
        >
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
          </svg>
        </button>
      )}
    </div>
  );
}

function normalizeLanguage(lang: string): string {
  const languageMap: Record<string, string> = {
    'js': 'javascript',
    'ts': 'typescript',
    'py': 'python',
    'sh': 'bash',
    'shell': 'bash',
    'yml': 'yaml',
    'md': 'markdown',
    'dockerfile': 'docker',
    'tsx': 'typescript',
    'jsx': 'javascript',
  };

  return languageMap[lang.toLowerCase()] || lang.toLowerCase();
}

// Markdown 渲染器支持代码块的组件
export function MarkdownCodeRenderer({
  className,
  children,
  ...props
}: React.HTMLAttributes<HTMLElement>) {
  const match = /language-(\w+)/.exec(className || '');
  const language = match ? match[1] : 'text';
  const code = String(children).replace(/\n$/, '');

  if (match) {
    return <CodeBlock code={code} language={language} />;
  }

  return (
    <code className="px-1.5 py-0.5 rounded bg-muted font-mono text-sm" {...props}>
      {children}
    </code>
  );
}