import * as React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { cn } from '../lib/utils';
import { StreamingText } from '../composite/streaming-text';
import { CodeBlock } from '../markdown/code-block';

interface MessageBubbleProps extends React.HTMLAttributes<HTMLDivElement> {
  role: 'user' | 'assistant' | 'system';
  content: string;
  isStreaming?: boolean;
  /** Render additional action buttons inside the bubble */
  actions?: React.ReactNode;
}

export function MessageBubble({
  role,
  content,
  isStreaming = false,
  actions,
  className,
  ...props
}: MessageBubbleProps) {
  const isUser = role === 'user';
  const isSystem = role === 'system';

  return (
    <div
      className={cn(
        'flex w-full',
        isSystem ? 'justify-center' : isUser ? 'justify-end' : 'justify-start',
        className
      )}
      {...props}
    >
      <div
        className={cn(
          'max-w-[80%] rounded-2xl px-4 py-2.5',
          isSystem
            ? 'bg-muted/50 text-muted-foreground italic text-center'
            : isUser
              ? 'bg-primary text-primary-foreground'
              : 'bg-muted text-muted-foreground'
        )}
      >
        {isSystem ? (
          <p className="text-sm whitespace-pre-wrap">{content}</p>
        ) : isUser ? (
          <p className="text-sm whitespace-pre-wrap">{content}</p>
        ) : (
          <div>
            <div className="prose prose-sm dark:prose-invert max-w-none">
              <ReactMarkdown
                remarkPlugins={[remarkGfm]}
                components={{
                  pre: ({ children, ...preProps }) => (
                    <pre className="overflow-auto" {...preProps}>
                      {children}
                    </pre>
                  ),
                  code: ({ className, children, ...codeProps }) => {
                    const match = /language-(\w+)/.exec(className || '');
                    const language = match ? match[1] : '';
                    const codeString = String(children).replace(/\n$/, '');

                    // 如果是代码块（有语言类名），使用 CodeBlock 组件
                    if (match) {
                      return <CodeBlock code={codeString} language={language} />;
                    }

                    // 行内代码
                    return (
                      <code
                        className="rounded bg-muted px-1.5 py-0.5 text-sm font-mono"
                        {...codeProps}
                      >
                        {children}
                      </code>
                    );
                  },
                  // 改进表格样式
                  table: ({ children }) => (
                    <div className="my-4 overflow-x-auto">
                      <table className="w-full border-collapse">{children}</table>
                    </div>
                  ),
                  thead: ({ children }) => (
                    <thead className="border-b border-border">{children}</thead>
                  ),
                  th: ({ children }) => (
                    <th className="px-3 py-2 text-left text-sm font-semibold text-foreground">
                      {children}
                    </th>
                  ),
                  tbody: ({ children }) => <tbody>{children}</tbody>,
                  tr: ({ children }) => (
                    <tr className="border-b border-border last:border-b-0 hover:bg-muted/50 transition-colors">
                      {children}
                    </tr>
                  ),
                  td: ({ children }) => (
                    <td className="px-3 py-2 text-sm text-muted-foreground">
                      {children}
                    </td>
                  ),
                  // 改进列表样式
                  ul: ({ children }) => (
                    <ul className="list-disc list-outside space-y-1 pl-6 my-2">
                      {children}
                    </ul>
                  ),
                  ol: ({ children }) => (
                    <ol className="list-decimal list-outside space-y-1 pl-6 my-2">
                      {children}
                    </ol>
                  ),
                  li: ({ children }) => (
                    <li className="text-sm leading-relaxed">{children}</li>
                  ),
                  // 改进链接样式
                  a: ({ href, children }) => (
                    <a
                      href={href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary underline underline-offset-4 hover:opacity-80 transition-opacity"
                    >
                      {children}
                    </a>
                  ),
                  // 改进引用样式
                  blockquote: ({ children }) => (
                    <blockquote className="border-l-4 border-primary pl-4 italic text-muted-foreground my-4">
                      {children}
                    </blockquote>
                  ),
                }}
              >
                {content}
              </ReactMarkdown>
              {isStreaming && (
                <StreamingText isStreaming={true} className="text-foreground">
                  {''}
                </StreamingText>
              )}
            </div>
            {actions && !isStreaming && (
              <div className="mt-2 flex items-center gap-1">
                {actions}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
