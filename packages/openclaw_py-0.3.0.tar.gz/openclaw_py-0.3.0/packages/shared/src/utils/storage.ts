/**
 * Cross-platform storage adapter.
 *
 * Automatically selects the best storage backend:
 * - Tauri: @tauri-apps/plugin-store (loaded only when running in Tauri)
 * - React Native: @react-native-async-storage/async-storage
 * - Browser: localStorage
 */

import { platform } from "./env";

export interface StorageAdapter {
  getItem: (name: string) => string | null | Promise<string | null>;
  setItem: (name: string, value: string) => void | Promise<void>;
  removeItem: (name: string) => void | Promise<void>;
}

/** Lazily resolve a storage adapter for the current platform. */
export async function getStorage(): Promise<StorageAdapter> {
  // Tauri storage - only attempt if actually running in Tauri
  if (platform.isTauri) {
    try {
      // Dynamic import - webpack will stub this module in web builds
      const mod = await import("@tauri-apps/plugin-store");
      if (mod && mod.Store) {
        const Store = mod.Store;
        const store = await Store.load("pyclaw-state.json");
        return {
          getItem: (name) => store.get(name) as Promise<string | null>,
          setItem: (name, value) => store.set(name, value),
          removeItem: (name) => store.delete(name).then(() => {}),
        };
      }
    } catch {
      // plugin-store not available
    }
  }

  // React Native storage
  if (platform.isReactNative) {
    try {
      const AsyncStorage = await import("@react-native-async-storage/async-storage");
      return AsyncStorage.default ?? AsyncStorage;
    } catch {
      // async-storage not available
    }
  }

  // Browser fallback — localStorage
  return {
    getItem: (name: string) =>
      typeof localStorage !== "undefined"
        ? localStorage.getItem(name)
        : null,
    setItem: (name: string, value: string) => {
      if (typeof localStorage !== "undefined")
        localStorage.setItem(name, value);
    },
    removeItem: (name: string) => {
      if (typeof localStorage !== "undefined")
        localStorage.removeItem(name);
    },
  };
}