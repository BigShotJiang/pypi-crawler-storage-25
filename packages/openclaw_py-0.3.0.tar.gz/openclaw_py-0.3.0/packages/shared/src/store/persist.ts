/**
 * State persistence for AppStore.
 *
 * Persists a subset of UI state (sidebar open/close, etc.) to
 * the cross-platform storage adapter so it survives app restarts.
 */

import { useAppStore } from "./index";

const PERSIST_KEY = "pyclaw-app-state";

// Dynamically import storage to avoid webpack issues with platform-specific modules
async function getStorageAdapter() {
  try {
    const { getStorage } = await import("../utils/storage");
    return getStorage();
  } catch {
    // Fallback to localStorage if storage module fails
    return {
      getItem: (name: string) =>
        typeof localStorage !== "undefined" ? localStorage.getItem(name) : null,
      setItem: (name: string, value: string) => {
        if (typeof localStorage !== "undefined") localStorage.setItem(name, value);
      },
      removeItem: (name: string) => {
        if (typeof localStorage !== "undefined") localStorage.removeItem(name);
      },
    };
  }
}

/** Load persisted state from storage into the store. */
export async function loadPersistedState(): Promise<void> {
  const storage = await getStorageAdapter();
  const saved = await storage.getItem(PERSIST_KEY);
  if (saved) {
    try {
      useAppStore.setState(JSON.parse(saved));
    } catch {
      console.warn("Failed to parse persisted state");
    }
  }
}

/** Subscribe to store changes and persist selected fields. */
export function setupPersistence(): void {
  useAppStore.subscribe((state) => {
    const partial = { sidebarOpen: state.sidebarOpen };
    getStorageAdapter()
      .then((storage) =>
        storage.setItem(PERSIST_KEY, JSON.stringify(partial)),
      )
      .catch(() => {
        /* silently ignore persistence errors */
      });
  });
}