# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.4] - 2026-05-10

### Fixed
- Install script now includes all gateway server dependencies:
  - `fastapi` (was missing - required for gateway)
  - `websockets` (was missing - required for gateway)
  - `uvicorn` (already fixed in 0.2.2)

## [0.2.3] - 2026-05-10

### Fixed
- Playwright E2E test configuration: fix port argument parsing (`dev -- -p 3000` → `dev -p 3000`)

## [0.2.2] - 2026-05-10

### Fixed
- Install script now includes `uvicorn` for gateway server (was missing due to Pyodide compatibility)
  - pipx: uses `pipx inject openclaw-py uvicorn`
  - uv: uses `uv tool install --with uvicorn`
  - pip: uses `pip install uvicorn`

## [0.2.1] - 2026-05-09

### Added
- **Version Management System** — Unified version sync across Python and TypeScript packages
  - `scripts/sync-version.ts` — Sync version from `pyproject.toml` to all `package.json` files
  - `scripts/check-version-sync.py` — CI-ready version consistency checker
  - `pnpm version:sync` / `pnpm version:check` commands
  - Documentation at `docs/reference/version-management.md`
- **Sidebar Cleanup** — Removed unused Plans and Models navigation items

### Fixed
- Move `aiosqlite` to optional perf dependencies (Pyodide compatibility)
- GitHub Actions test failures
- CSS priority issues with `!important` declarations

### Changed
- Homepage styling improvements

## [0.3.0] - 2026-05-16

### Added
- **Token-Aware Module** (`pyclaw.token_aware`) — Intelligent context optimization
  - `estimator.py` — Fast token estimation without tokenizer (code/prose/mixed)
  - `description.py` — Intelligent file description extraction for 20+ languages
  - `anatomy.py` — Project file index with descriptions and token estimates
  - `cerebrum.py` — Learning memory (Do-Not-Repeat, Preferences, Learnings, Decisions)
  - `buglog.py` — Bug fix memory with auto-detection patterns
  - `ledger.py` — Token usage tracking and waste detection
  - `session.py` — In-memory session state for repeat detection
  - CLI: `pyclaw token-aware init|scan|status|stats|cerebrum|buglog`
  - Estimated 50-70% token savings via anatomy descriptions
- **PACS — Agentic Capability Stack** — Event-driven plugin system for agentic patterns
  - `AgentEventBus` — Priority-sorted hook dispatch with control flow (CONTINUE/SKIP/ABORT/RETRY)
  - `AgenticCapability` ABC — Base class with layer, hooks, priority, should_activate/on_event
  - `CapabilityRegistry` — Singleton factory for capability instantiation
  - `Recipe` system — Preset configs (react_agent, planner_agent, research_agent, safe_agent, full_stack_agent)
  - 21 built-in capabilities across 5 layers (Perception, Reasoning, Action, Feedback, Infrastructure)
  - 328 tests passing
- **Multi-Agent Collaboration System** — Four orchestration modes
  - `CollaborationEngine` — Unified orchestration layer
  - Custom Agent Mode — YAML/Markdown predefined agents
  - Fork/Swarm Mode — Parallel child agents
  - Coordinator-Worker Mode — Task distribution
  - Dynamic Decompose Mode — Automatic task decomposition
  - 6 collaboration tools + CLI commands (`pyclaw agents custom`, `pyclaw mode status|switch|--suggest`)
- **Multiagent Module Unification** — Consolidated into `agents/multiagent/`
  - Unified `MultiagentEngine` ABC with 5 implementations (Centralized, DynamicDecompose, ForkSwarm, Pipeline, Hybrid)
  - `TaskDecomposer` system — Heuristic and LLM-based decomposition
  - Registry base classes: `Registry[K, V]`, `SingletonRegistry`, `ThreadSafeRegistry`
  - 103 integration tests
- **Active Memory** — Automatic memory retrieval before responses
  - Query modes: MESSAGE, RECENT, FULL
  - Six prompt styles: BALANCED, STRICT, CONTEXTUAL, RECALL_HEAVY, PRECISION_HEAVY, PREFERENCE_ONLY
  - CLI: `pyclaw active-memory on|off|status`
- **Wiki System** — Structured knowledge base for humans and agents
  - Claim/Evidence model with contradiction detection
  - Block markers to protect human edits
  - `MemoryBridge` for syncing with MemoryDirectory
  - CLI: `pyclaw wiki init`
- **Dreaming System** — Three-phase memory consolidation (LIGHT/DEEP/REM)
  - Six-dimensional scoring algorithm
  - Automatic promotion to MEMORY.md
- **Channel Configuration Documentation** — 24+ channels reference
  - Telegram, Discord, Slack, Feishu/Lark, DingTalk, MS Teams, 企业微信 (wecom) and more
  - `pyclaw.example.json5` complete config template

### Changed
- **Registry Consolidation** — 22 registries aligned with unified interface
  - `CapabilityRegistry` extends `SingletonRegistry`
  - `ToolRegistry` extends `Registry[str, AgentTool]`
- **Module Deprecations** — Legacy modules emit deprecation warnings
  - `pyclaw.agents.orchestration` → Use `pyclaw.agents.multiagent`
  - `pyclaw.agents.collaboration` → Use `pyclaw.agents.multiagent`
  - Planned removal: version 2.0.0

### Migration Guide
- Types: `from pyclaw.agents.multiagent.types import CollaborationModeType, OrchestrationMode`
- Engines: `from pyclaw.agents.multiagent.engines import CentralizedEngine, PipelineEngine`
- Registry: `from pyclaw.agents.multiagent.registry import Registry, SingletonRegistry`
- Docs: `docs/architecture/registry-patterns.md`

## [Unreleased]

### Added
- (nothing yet)

### Changed
- (nothing yet)

### Fixed
- (nothing yet)

## [0.1.8] - 2026-04-11

### Added
- **UI MVC Architecture** — BasePanel, BaseController, Reactive state management
- **Agent Extensions** — Extensible agent runtime with tools and session management
- **Memory System** — SQLite + LanceDB hybrid search with MMR reranking
- **GatewayService** — Mock service for UI testing
- **EventBus** — Decoupled event-driven communication

### Changed
- Refactored UI panels to MVC pattern (Agents panel migrated)
- Split `components.py` into modular components
- Improved type annotations across codebase

### Fixed
- Agent import, parameter, and cache issues
- Lint and type annotation warnings

## [0.1.4] - 2026-03-15

### Added
- Versioned pre-push hook: `scripts/githooks/pre-push`（推送 tag 时跳过测试，由 release workflow 执行）
- `scripts/githooks/README.md` — 安装说明

### Changed
- pre-push：仅对分支推送跑全量 pytest，推送 tag 时跳过，避免与 release 重复
- ci-local.sh：不再跑 pytest，只做 ruff + mypy，pytest 由 pre-push 统一执行
- commit.sh：文案改为“本地检查（ruff + mypy）”

### Fixed
- 测试耗时：`test_infra_misc.test_with_timeout_expired`、`test_cron_tts_logging.test_timeout` 中 `asyncio.sleep(10)` 改为最小必要时长（0.1s / 0.2s），pre-push 全量测试减少约 20 秒

## [0.1.3] - 2026-03-14

### Added
- Responsive shell module (`ui/responsive_shell.py`) — breakpoint-based layout management
- External locale JSON files (`ui/locales/*.json`) — i18n data no longer hardcoded
- Desktop tray quick actions — new chat, toggle theme, mute notifications
- PWA support — manifest, service worker, offline caching for web builds
- Provider/model configuration linkage — switching provider auto-updates model list, base URL, API key hint
- CJK font fallback chain for proper Chinese/Japanese display
- Shimmer loading animation, message fade-in, send button scale animation
- Chat export to Markdown, file attachment support
- Keyboard shortcuts (Cmd/Ctrl+K search, +N new session, +E export)
- Streaming typing indicator with animated dots
- Scroll-to-bottom floating button
- Reusable UI components (`ui/components.py`): page_header, empty_state, card_tile, status_chip
- New UI panels: config, cron, debug, instances, logs, nodes, overview, plans, sessions, skills, system, usage
- Docs site (MkDocs) and GitHub Pages deploy workflow
- Reference docs restructure: PROGRESS.md + REFERENCE_TABLES.md milestone-driven layout

### Changed
- Provider defaults consolidated into single source of truth (`model_catalog._KNOWN_PROVIDERS`)
- Toolbar refactored to `ChatToolbar` class with dynamic model updates
- Chat bubble design enhanced — asymmetric border radius, role-colored avatars, improved shadows
- Provider names use English-first format with CJK in parentheses
- Dependencies reorganized — heavy channel SDKs moved to optional `[channels]` extra
- Reference and docs layout: legacy plans moved/archived, single source in `reference/`

### Fixed
- ChatMessage search: `_message_content` initialized in constructor
- Tool display metadata: correct nested key access with fallback

## [0.1.0] - 2026-03-04

### Added
- Initial release
- Multi-channel AI gateway (Telegram, Discord, Slack, WeChat, WhatsApp, Matrix, and more)
- 20+ LLM provider support (OpenAI, Anthropic, Google, DeepSeek, Qwen, GLM, MiniMax, etc.)
- WebSocket v3 protocol for UI-gateway communication
- TypeScript cross-platform UI (Web, Desktop, Mobile)
- Agent system with tool calling, planning, and memory
- CLI with interactive setup wizard
- Docker support with multi-stage build
- Cron job scheduling
- Voice interaction (TTS via edge-tts, STT via Whisper API)

[Unreleased]: https://github.com/chensaics/openclaw-py/compare/v0.2.1...HEAD
[0.2.1]: https://github.com/chensaics/openclaw-py/compare/v0.2.0...v0.2.1
[0.2.0]: https://github.com/chensaics/openclaw-py/releases/tag/v0.2.0
[0.1.9]: https://github.com/chensaics/openclaw-py/compare/v0.1.8...v0.1.9
