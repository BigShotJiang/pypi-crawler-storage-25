#!/usr/bin/env python3

import os
import sys
import time
import shutil
import subprocess
import re
import datetime
import argparse

# Platform-specific imports for raw keyboard input
try:
    import tty
    import termios
except ImportError:
    pass # Windows fallback will be handled in getch()

# Configuration
home_dir = os.path.expanduser("~")

# Color definitions
RED = '\033[0;31m'
GREEN = '\033[0;32m'
YELLOW = '\033[1;33m'
BLUE = '\033[0;34m'
PURPLE = '\033[0;35m'
CYAN = '\033[0;36m'
ORANGE = '\033[0;33m'
PINK = '\033[1;35m'
WHITE = '\033[1;37m'
NC = '\033[0m' # No Color
BOLD = '\033[1m'

# Global variable to track the last Ctrl+C time (for double-tap detection)
last_sigint_time = 0

DEPENDENCIES = {
    "subfinder": {
        "required": True,
        "detect": {"type": "cli", "name": "subfinder"},
        "install": {"type": "apt", "package": "subfinder", "command": "apt install -y subfinder"},
    },
    "assetfinder": {
        "required": True,
        "detect": {"type": "cli", "name": "assetfinder"},
        "install": {"type": "apt", "package": "assetfinder", "command": "apt install -y assetfinder"},
    },
    "gau": {
        "required": True,
        "detect": {"type": "cli", "name": "gau"},
        "install": {"type": "go", "command": "go install github.com/lc/gau/v2/cmd/gau@latest"},
    },
    "waybackurls": {
        "required": True,
        "detect": {"type": "cli", "name": "waybackurls"},
        "install": {"type": "go", "command": "go install github.com/tomnomnom/waybackurls@latest"},
    },
    "katana": {
        "required": True,
        "detect": {"type": "cli", "name": "katana"},
        "install": {"type": "go", "command": "go install github.com/projectdiscovery/katana/cmd/katana@latest"},
    },
    "arjun": {
        "required": True,
        "detect": {"type": "cli", "name": "arjun"},
        "install": {"type": "apt", "package": "arjun", "command": "apt install -y arjun"},
    },
    "http_probe": {
        "required": True,
        "label": "httpx-toolkit OR httprobe",
        "detect": {"type": "any_cli", "names": ["httpx-toolkit", "httprobe"]},
        "install": {
            "type": "apt",
            "package": "httpx-toolkit httprobe",
            "command": "apt install -y httpx-toolkit httprobe",
        },
    },
    "LinkFinder": {
        "required": False,
        "detect": {"type": "file", "path": "~/tools/LinkFinder/linkfinder.py"},
        "install": {},
    },
    "JSParser": {
        "required": False,
        "detect": {"type": "file", "path": "~/tools/JSParser/JSParser.py"},
        "install": {},
    },
    "xnLinkFinder": {
        "required": False,
        "detect": {"type": "cli", "name": "xnLinkFinder"},
        "install": {"type": "pip", "command": f'"{sys.executable}" -m pip install xnLinkFinder'},
    },
}

# Helper to read a single keypress without requiring 'Enter'
def getch():
    if sys.platform == "win32":
        import msvcrt
        return msvcrt.getch().decode('utf-8', 'ignore')
    else:
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        try:
            tty.setraw(sys.stdin.fileno())
            ch = sys.stdin.read(1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        return ch

# Helper to run shell commands comfortably with Interactive Interrupts
def run_command(command, shell=True, check=False, silent=False, stdout=None):
    global last_sigint_time
    
    while True: # Loop allows us to restart the command if 'c' is pressed
        try:
            kwargs = {
                'shell': shell,
                'check': check
            }
            
            if shell and shutil.which('bash'):
                kwargs['executable'] = shutil.which('bash')

            if silent:
                result = subprocess.run(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, **kwargs)
            elif stdout:
                result = subprocess.run(command, stdout=stdout, stderr=subprocess.DEVNULL, **kwargs)
            else:
                result = subprocess.run(command, **kwargs)
                
            return result.returncode == 0
            
        except KeyboardInterrupt:
            # Detect Double Ctrl+C (within 1 second)
            current_time = time.time()
            if current_time - last_sigint_time < 1.0:
                print(f"\r\n{RED}[!] Double Ctrl+C detected! Force stopping scan completely...{NC}\n")
                sys.exit(1)
                
            last_sigint_time = current_time
            
            # Interactive prompt
            print(f"\r\n{YELLOW}┌────────────────────────────────────────────────────────┐{NC}")
            print(f"\r{YELLOW}│{NC} ⚠️ {BOLD}Process Interrupted!{NC}                                 {YELLOW}│{NC}")
            print(f"\r{YELLOW}│{NC} '{CYAN}c{NC}' to restart tool | '{CYAN}n{NC}' to skip | '{RED}s{NC}' to stop scan   {YELLOW}│{NC}")
            print(f"\r{YELLOW}└────────────────────────────────────────────────────────┘{NC}")
            print("\r> ", end='', flush=True)

            while True:
                choice = getch().lower()
                if choice == 'c':
                    print(f"\r{YELLOW}[♦] INFO    ❯ Restarting the interrupted tool...{NC}\n")
                    break # Breaks the inner prompt loop, goes back to while True to restart the command
                elif choice == 'n':
                    print(f"\r{YELLOW}[♦] INFO    ❯ Skipping current tool and continuing...{NC}\n")
                    return False # Gracefully return and move to the next command
                elif choice == 's':
                    print(f"\r\n{RED}[♦] ERROR   ❯ Scan stopped by user.{NC}\n")
                    sys.exit(1)
                elif choice == '\x03': # \x03 is the ASCII code for Ctrl+C
                    print(f"\r\n{RED}[!] Force stopping scan completely...{NC}\n")
                    sys.exit(1)

# Helper to count lines in a file
def count_lines(filepath):
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            return sum(1 for _ in f)
    except FileNotFoundError:
        return 0

# Phantom Recon - Advanced Reconnaissance Suite
def show_banner():
    os.system('cls' if os.name == 'nt' else 'clear')
    print(f"{CYAN}┌──────────────────────────────────────────────────────────────┐")
    print(f"│                                                              │")
    print(f"│{BOLD}{WHITE}           ⚡ SURFMAP ⚡                  {NC}{CYAN}│")
    print(f"│{PURPLE}          Advanced Reconnaissance & Analysis Suite            {NC}{CYAN}│")
    print(f"│                                                              │")
    print(f"│     {WHITE}[ Target Acquisition ]{NC}{CYAN} ❯ {ORANGE}[ Asset Discovery ]{NC}{CYAN} ❯ {GREEN}[ Analysis ]{NC}{CYAN}│")
    print(f"│                                                              │")
    print(f"├──────────────────────────────────────────────────────────────┤")
    print(f"│  {WHITE}🔍 Subdomain Enumeration     🎯 Parameter Discovery{NC}{CYAN}         │")
    print(f"│  {WHITE}⚡ Live Host Detection       🔮 JavaScript Analysis{NC}{CYAN}         │")
    print(f"│  {WHITE}🌐 Asset Reconnaissance      🛡️ Vulnerability Scanning{NC}{CYAN}      │")
    print(f"│                                                              │")
    print(f"├──────────────────────────────────────────────────────────────┤")
    print(f"│                                                              │")
    print(f"│  {PINK}Created by:{NC} {WHITE}Khrish{NC}{CYAN}                                              │")
    print(f"│  {CYAN}Cybersecurity Specialist & VAPT Analyst{NC}{CYAN}                │")
    print(f"│                                                              │")
    print(f"└──────────────────────────────────────────────────────────────┘{NC}")

def show_help():
    show_banner()
    print(f"{PURPLE}┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓")
    print(f"┃{BOLD}{WHITE}                   COMMAND LINE USAGE                     {NC}{PURPLE}┃")
    print(f"┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛{NC}\n")
    
    print(f"{CYAN}🎯 TARGET OPTIONS (Default Mode - Choose One):{NC}")
    print(f"  {GREEN}-u, --url{NC}             Single target domain to scan (e.g., example.com)")
    print(f"  {GREEN}-f, --file{NC}            Text file containing a list of target domains\n")
    
    print(f"{CYAN}🛡️ SKIP & FILTER OPTIONS:{NC}")
    print(f"  {YELLOW}-skip-sub{NC}             Skip subdomain enumeration and use the target directly")
    print(f"  {YELLOW}-skip-u, --skip-url{NC}   Single domain to skip/exclude from final results")
    print(f"  {YELLOW}-skip-f, --skip-file{NC}  Text file containing domains to skip/exclude\n")
    
    print(f"{CYAN}ℹ️ MISCELLANEOUS:{NC}")
    print(f"  {BLUE}--setup{NC}                Install/validate dependencies only, then exit")
    print(f"  {BLUE}-h, --help, /h{NC}        Show this help message and exit\n")
    
    print(f"{PURPLE}============================================================{NC}")
    print(f"{WHITE}💡 EXAMPLES:{NC}")
    print(f"  {GREEN}1. Setup mode only:{NC}             surfmap --setup")
    print(f"  {GREEN}2. Basic scan:{NC}                  surfmap -u example.com")
    print(f"  {GREEN}3. Scan without subdomains:{NC}     surfmap -u example.com -skip-sub")
    print(f"  {GREEN}4. Scan list with exclusions:{NC}   surfmap -f targets.txt -skip-f out_of_scope.txt")
    print(f"{PURPLE}============================================================{NC}\n")
    sys.exit(0)

def startup_animation():
    print(f"\n{YELLOW}")
    print("Initializing reconnaissance framework...")
    time.sleep(0.5)
    print("Loading security modules...")
    time.sleep(0.5)
    print("Preparing attack surface analysis...")
    time.sleep(0.5)
    print(f"{GREEN}✓ All systems ready!{NC}")
    print()

def progress_indicator(message):
    print(f"\n{YELLOW}┌──────────────────────────────────────┐{NC}")
    print(f"{YELLOW}│{NC} 🚀 {message}")
    print(f"{YELLOW}└──────────────────────────────────────┘{NC}")
    
    spinstr = '⣾⣽⣻⢿⡿⣟⣯⣷'
    sys.stdout.write("  ")
    for _ in range(15):
        for char in spinstr:
            sys.stdout.write(f" {CYAN}[{char}]{NC} ")
            sys.stdout.flush()
            time.sleep(0.1)
            sys.stdout.write("\b" * 6)
    sys.stdout.write("    \b\b\b\b")
    print()

def section_header(title):
    title_length = len(title)
    padding = (50 - title_length) // 2
    pad_str = ' ' * padding
    
    print(f"\n{PURPLE}┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓")
    print(f"┃{pad_str}{BOLD}{WHITE}{title}{NC}{PURPLE}{pad_str}        ┃")
    print(f"┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛{NC}")

def print_status(message):
    print(f"{BLUE}[♦] {BOLD}INFO{NC}    ❯ {message}")

def print_success(message):
    print(f"{GREEN}[♦] {BOLD}SUCCESS{NC} ❯ {message}")

def print_warning(message):
    print(f"{YELLOW}[♦] {BOLD}WARNING{NC} ❯ {message}")

def print_error(message):
    print(f"{RED}[♦] {BOLD}ERROR{NC}   ❯ {message}")

def is_linux():
    return sys.platform.startswith("linux")


def is_root_user():
    if hasattr(os, "geteuid"):
        return os.geteuid() == 0
    return False


def run_setup_command(command, required=True):
    kwargs = {"shell": True}
    if shutil.which("bash"):
        kwargs["executable"] = shutil.which("bash")

    result = subprocess.run(command, capture_output=True, text=True, **kwargs)
    if result.returncode == 0:
        return True

    error_text = (result.stderr or result.stdout or "").strip()
    if error_text:
        print_error(error_text.splitlines()[-1])

    if required:
        return False

    return False


def ensure_go_path_in_environment():
    try:
        gopath = subprocess.run("go env GOPATH", shell=True, capture_output=True, text=True, check=False).stdout.strip()
    except Exception:
        gopath = ""

    if not gopath:
        print_error("Unable to resolve GOPATH. Go-based dependency installation may fail.")
        return False

    go_bin = os.path.join(gopath, "bin")
    current_path = os.environ.get("PATH", "")
    path_entries = current_path.split(os.pathsep) if current_path else []
    if go_bin not in path_entries:
        os.environ["PATH"] = f"{current_path}{os.pathsep}{go_bin}" if current_path else go_bin
        print_status(f"Added Go binaries to current PATH: {go_bin}")
        print_status("For persistence, add this to your shell profile:")
        print_status(f"export PATH=$PATH:{go_bin}")

    return True


def detect_dependency(dep_name, config):
    detect_cfg = config.get("detect", {})
    dep_type = detect_cfg.get("type")

    if dep_type == "cli":
        tool_name = detect_cfg.get("name", dep_name)
        return bool(shutil.which(tool_name)), tool_name

    if dep_type == "any_cli":
        for tool_name in detect_cfg.get("names", []):
            if shutil.which(tool_name):
                return True, tool_name
        return False, ", ".join(detect_cfg.get("names", []))

    if dep_type == "file":
        file_path = os.path.expanduser(detect_cfg.get("path", ""))
        return os.path.isfile(file_path), file_path

    return False, "unknown"


def check_dependencies(log_missing=True):
    section_header("DEPENDENCY CHECK")
    print_status("Checking dependencies...")

    status = {
        "installed": [],
        "missing_required": [],
        "missing_optional": [],
        "details": {},
    }

    for dep_name, config in DEPENDENCIES.items():
        display_name = config.get("label", dep_name)
        installed, detected_with = detect_dependency(dep_name, config)
        status["details"][dep_name] = {
            "installed": installed,
            "detected_with": detected_with,
            "required": config.get("required", False),
            "display_name": display_name,
        }

        if installed:
            status["installed"].append(dep_name)
            print_success(f"{display_name} is installed")
            continue

        if config.get("required", False):
            status["missing_required"].append(dep_name)
            if log_missing:
                print_warning(f"{display_name} is missing")
        else:
            status["missing_optional"].append(dep_name)
            if log_missing:
                print_warning(f"{display_name} not found (optional)")

    print_status(
        f"Installed: {len(status['installed'])} | Missing required: {len(status['missing_required'])} | Missing optional: {len(status['missing_optional'])}"
    )
    return status


def install_base_prerequisites():
    section_header("BASE PREREQUISITES")

    if not is_linux():
        print_warning("Automatic setup is currently supported for Linux environments only.")
        return False

    if not shutil.which("apt"):
        print_error("apt is not available on this system. Cannot perform automatic setup.")
        return False

    apt_basics = ["zip", "curl", "wget", "git"]
    missing_basics = [pkg for pkg in apt_basics if not shutil.which(pkg)]
    go_missing = shutil.which("go") is None
    if not missing_basics and not go_missing:
        print_success("Base prerequisites already present")
        return True

    print_status("Installing base prerequisites...")
    if not run_setup_command("apt update", required=True):
        return False

    if go_missing:
        if shutil.which("snap"):
            run_setup_command("snap refresh", required=False)
            if not run_setup_command("snap install golang --classic", required=True):
                return False
        else:
            print_error("snap is not available to install golang. Install Go manually and retry.")
            return False
    else:
        print_success("Go is already installed")

    if missing_basics:
        if not run_setup_command(f"apt install -y {' '.join(missing_basics)}", required=True):
            return False
        print_success("Installed base utilities")
    else:
        print_success("Base utilities already installed")

    return True


def install_dependencies(status):
    section_header("DEPENDENCY INSTALLATION")
    print_status("Installing missing dependencies...")

    if not is_linux():
        print_error("Automatic dependency installation is supported only on Linux at the moment.")
        return False

    install_candidates = []
    for dep_name in status["missing_required"]:
        install_candidates.append(dep_name)

    if not install_candidates:
        print_success("No missing dependencies to install")
        return True

    apt_required = []
    for dep_name in install_candidates:
        install_cfg = DEPENDENCIES[dep_name].get("install", {})
        if install_cfg.get("type") == "apt":
            package_value = install_cfg.get("package", "")
            if package_value:
                apt_required.extend(package_value.split())

    apt_required = sorted(set(apt_required))

    if apt_required and not is_root_user():
        print_warning("Some tools require sudo privileges.")
        surfmap_path = shutil.which("surfmap")
        if surfmap_path:
            print_warning(f"Try: sudo \"{surfmap_path}\" --setup")
        print_warning(f"Try: sudo \"{sys.executable}\" -m surfmap --setup")
        print_warning("Or run from project root: sudo python3 surfmap.py --setup")
        return False

    if apt_required and not install_base_prerequisites():
        return False

    if apt_required:
        print_status(f"[INSTALL] Installing APT tools: {' '.join(apt_required)}")
        if not run_setup_command(f"apt install -y {' '.join(apt_required)}", required=True):
            print_error("Failed to install required APT tools")
            return False
        print_success("APT tool installation completed")

    if any(DEPENDENCIES[d].get("install", {}).get("type") == "go" for d in install_candidates):
        if not ensure_go_path_in_environment():
            return False

    for dep_name in install_candidates:
        dep_cfg = DEPENDENCIES[dep_name]
        dep_required = dep_cfg.get("required", False)
        display_name = dep_cfg.get("label", dep_name)
        install_cfg = dep_cfg.get("install", {})
        install_type = install_cfg.get("type")

        if install_type == "apt":
            installed, _ = detect_dependency(dep_name, dep_cfg)
            if installed:
                print_success(f"{display_name} installed successfully")
            elif dep_required:
                print_error(f"Failed to install {display_name}")
                print_error(f"Critical dependency installation failed: {display_name}")
                return False
            else:
                print_warning(f"Failed to install optional dependency: {display_name}")
            continue

        command = install_cfg.get("command")
        if not command:
            continue

        print_status(f"[INSTALL] Installing {display_name} via {install_type}...")

        if install_type == "git":
            detect_path = os.path.expanduser(dep_cfg.get("detect", {}).get("path", ""))
            if detect_path and os.path.isfile(detect_path):
                print_success(f"{display_name} already present")
                continue

        if not run_setup_command(command, required=dep_required):
            if dep_required:
                print_error(f"Critical dependency installation failed: {display_name}")
                return False
            print_warning(f"Failed to install optional dependency: {display_name}")
            continue

        installed, _ = detect_dependency(dep_name, dep_cfg)
        if installed:
            print_success(f"{display_name} installed successfully")
        elif dep_required:
            print_error(f"Critical dependency installation failed: {display_name}")
            return False
        else:
            print_warning(f"{display_name} installation completed but validation did not pass")

    return True


def prepare_environment(setup_only=False):
    status = check_dependencies(log_missing=True)

    if status["missing_required"]:
        if not install_dependencies(status):
            return False

        print_status("Re-validating dependency state...")
        status = check_dependencies(log_missing=False)

    if status["missing_required"]:
        failed_dep = DEPENDENCIES[status["missing_required"][0]].get("label", status["missing_required"][0])
        print_error(f"Critical dependency installation failed: {failed_dep}")
        print_error("Aborting execution.")
        return False

    if setup_only:
        print_success("Setup mode complete. All required dependencies are available.")

    return True

def subdomain_enum(target):
    section_header("SUBDOMAIN ENUMERATION")
    
    print_status("Running subfinder...")
    run_command(f"subfinder -d {target} -all -o subfinder.txt")
    
    print_status("Running assetfinder...")
    run_command(f"assetfinder --subs-only {target} > assetfinder.txt")
    
    print_status("Combining and sorting results...")
    run_command("cat subfinder.txt assetfinder.txt | sort -u > all_subs.txt")
    
    subdomain_count = count_lines("all_subs.txt")
    print_success(f"Discovered {subdomain_count} unique subdomains")
    
    print(f"\n{CYAN}Top 5 subdomains:{NC}")
    run_command("head -n 5 all_subs.txt | nl", shell=True)

def live_host_discovery():
    section_header("LIVE HOST DISCOVERY")
    
    if shutil.which("httpx-toolkit"):
        print_status("Probing for live hosts with httpx-toolkit...")
        if run_command("httpx-toolkit -l all_subs.txt --silent --status-code --title --tech-detect -o alive_subs.txt", silent=True):
            print_success("httpx-toolkit with long-form flags worked")
        else:
            print_warning("httpx-toolkit long-form flags failed, trying basic mode")
            run_command("cat all_subs.txt | httpx-toolkit -o alive_subs.txt")
            
    elif shutil.which("httprobe"):
        print_status("Probing for live hosts with httprobe...")
        run_command("cat all_subs.txt | httprobe -c 50 > alive_subs.txt")
    else:
        print_error("Neither httpx-toolkit nor httprobe is available")
        sys.exit(1)
    
    alive_count = count_lines("alive_subs.txt")
    print_success(f"Found {alive_count} live hosts (Detailed output saved to alive_subs.txt)")
    
    print_status("Creating clean URLs file (just domains)...")
    run_command("awk '{print $1}' alive_subs.txt > plain_domains.txt")
    print_success("Saved clean URLs to plain_domains.txt")
    
    print(f"\n{CYAN}Top 5 live hosts:{NC}")
    run_command("head -n 5 plain_domains.txt | nl", shell=True)

def url_collection():
    section_header("URL COLLECTION")
    
    print_status("Fetching URLs with GAU...")
    run_command("cat plain_domains.txt | gau --threads 50 --blacklist png,jpg,gif,svg > gau_urls.txt")
    
    print_status("Fetching URLs with Wayback Machine...")
    run_command("cat plain_domains.txt | waybackurls > wayback.txt")
    
    print_status("Crawling with Katana...")
    run_command("katana -list plain_domains.txt -d 5 -js-crawl -o katana_urls.txt")
    
    print_status("Combining and sorting results...")
    run_command("cat gau_urls.txt wayback.txt katana_urls.txt | sort -u > all_urls.txt")
    
    url_count = count_lines("all_urls.txt")
    print_success(f"Collected {url_count} unique URLs")

def js_endpoint_extraction():
    section_header("JAVASCRIPT ANALYSIS")
    
    print_status("Extracting JavaScript files...")
    run_command("cat all_urls.txt | grep -Ei \"\\.js$\" | sort -u > jsfiles.txt")
    
    js_count = count_lines("jsfiles.txt")
    print_success(f"Found {js_count} JavaScript files")
    
    if os.path.isfile(f"{home_dir}/tools/LinkFinder/linkfinder.py"):
        print_status("Running LinkFinder...")
        run_command(f"python3 {home_dir}/tools/LinkFinder/linkfinder.py -i jsfiles.txt -o cli > linkfinder_endpoints.txt")
    
    if os.path.isfile(f"{home_dir}/tools/JSParser/JSParser.py"):
        print_status("Running JSParser...")
        try:
            with open("jsfiles.txt", "r") as f:
                with open("jsparser_endpoints.txt", "w") as out:
                    for url in f:
                        url = url.strip()
                        if url:
                            run_command(f"python3 {home_dir}/tools/JSParser/JSParser.py -u \"{url}\"", shell=True, stdout=out)
        except Exception:
            pass
    
    if shutil.which("xnLinkFinder"):
        print_status("Running xnLinkFinder...")
        run_command("cat jsfiles.txt | xnLinkFinder -stdin -o xn_endpoints.txt")

def parameter_discovery():
    section_header("PARAMETER DISCOVERY")
    
    print_status("Preparing URLs for parameter discovery...")

    if os.path.exists("all_urls.txt"):
        run_command("grep \"=\" all_urls.txt | sort -u > urls_temp.txt")
    else:
        run_command("touch urls_temp.txt")

    valid_file = "urls_for_arjun.txt"
    invalid_file = "bad_urls.txt"
    
    open(valid_file, 'w').close()
    open(invalid_file, 'w').close()

    try:
        with open("urls_temp.txt", "r", encoding="utf-8", errors="ignore") as f_in, \
             open(valid_file, "a") as f_valid, \
             open(invalid_file, "a") as f_invalid:
            
            for url in f_in:
                url = url.strip()
                if not url:
                    continue

                if not re.match(r"^https?://", url):
                    f_invalid.write(url + "\n")
                    continue
                
                proto_count = url.lower().count("http")
                if proto_count > 1:
                    f_invalid.write(url + "\n")
                    continue
                
                if re.search(r"[\(\)\<\>\'\"\ \{\\]", url):
                    f_invalid.write(url + "\n")
                    continue
                
                f_valid.write(url + "\n")
                
    except FileNotFoundError:
        pass

    if os.path.exists("urls_temp.txt"):
        os.remove("urls_temp.txt")

    count_valid = count_lines(valid_file)
    print_success(f"Prepared {count_valid} valid URLs for Arjun")
    
    print_status("Running Arjun for parameter discovery...")
    if count_valid > 0:
        run_command(f"arjun -i {valid_file} -t 50 -oT arjun_params.txt 2> arjun_run.log", shell=True)
    else:
        run_command("touch arjun_params.txt")
        print_warning("No valid URLs to scan with Arjun.")

    param_count = count_lines("arjun_params.txt")
    print_success(f"Discovered {param_count} parameters")
    
    print(f"\n{CYAN}Top 5 discovered parameters:{NC}")
    run_command("head -n 5 arjun_params.txt | nl", shell=True)

def cleanup_and_merge():
    section_header("RESULTS AGGREGATION")
    
    print_status("Merging all endpoints...")
    cmd = "cat linkfinder_endpoints.txt jsparser_endpoints.txt xn_endpoints.txt arjun_params.txt 2>/dev/null | sort -u > final_endpoints.txt"
    run_command(cmd)
    
    print_status("Filtering endpoints with parameters...")
    run_command("cat final_endpoints.txt | grep \"=\" > endpoints_with_params.txt")
    
    endpoint_count = count_lines("final_endpoints.txt")
    param_endpoint_count = count_lines("endpoints_with_params.txt")
    
    print_success(f"Merged {endpoint_count} unique endpoints")
    print_success(f"Found {param_endpoint_count} endpoints with parameters")

def filter_exclusions(work_dir, excluded_domains):
    section_header("OUT-OF-SCOPE FILTERING")
    print_status("Checking for ineligible domains and cleaning output...")
    print_status(f"Domains to purge: {len(excluded_domains)}")
    
    excluded_lower = [d.lower() for d in excluded_domains]
            
    files_to_clean = [
        "all_subs.txt", "alive_subs.txt", "plain_domains.txt", 
        "all_urls.txt", "jsfiles.txt", "final_endpoints.txt", 
        "endpoints_with_params.txt", "subfinder.txt", "assetfinder.txt",
        "gau_urls.txt", "wayback.txt", "katana_urls.txt", "urls_for_arjun.txt",
        "arjun_params.txt"
    ]
    
    for fname in files_to_clean:
        file_path = os.path.join(work_dir, fname)
        if os.path.isfile(file_path):
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    lines = f.readlines()
                
                with open(file_path, 'w', encoding='utf-8') as f:
                    for line in lines:
                        if not any(ex in line.lower() for ex in excluded_lower):
                            f.write(line)
            except Exception:
                pass
        
    print_success("Ineligible domains successfully wiped from all output files!")

def generate_report(target, duration):
    section_header("REPORT GENERATION")
    
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    report_file = f"recon_summary_{timestamp}.txt"
    date_str = datetime.datetime.now().strftime("%a %b %d %H:%M:%S %Z %Y")
    
    sub_count = count_lines("all_subs.txt")
    live_count = count_lines("alive_subs.txt")
    url_count = count_lines("all_urls.txt")
    js_count = count_lines("jsfiles.txt")
    end_count = count_lines("final_endpoints.txt")
    param_end_count = count_lines("endpoints_with_params.txt")

    def get_head(filename, n=10):
        try:
            res = subprocess.run(f"head -n {n} {filename} | nl", shell=True, capture_output=True, text=True)
            return res.stdout
        except: return ""

    with open(report_file, "w") as f:
        f.write("╔══════════════════════════════════════════════════════════════╗\n")
        f.write("║                    RECONNAISSANCE SUMMARY                    ║\n")
        f.write("╠══════════════════════════════════════════════════════════════╣\n")
        f.write(f"║ Target: {target}\n")
        f.write(f"║ Date: {date_str}\n")
        f.write(f"║ Duration: {duration} seconds\n")
        f.write("╠══════════════════════════════════════════════════════════════╣\n")
        f.write(f"║ Subdomains Found: {sub_count}\n")
        f.write(f"║ Live Hosts: {live_count}\n")
        f.write(f"║ URLs Collected: {url_count}\n")
        f.write(f"║ JavaScript Files: {js_count}\n")
        f.write(f"║ Endpoints Discovered: {end_count}\n")
        f.write(f"║ Endpoints with Parameters: {param_end_count}\n")
        f.write("╚══════════════════════════════════════════════════════════════╝\n")
        f.write("\n")
        f.write("TOP SUBDOMAINS:\n")
        f.write(get_head("all_subs.txt"))
        f.write("\n")
        f.write("TOP LIVE HOSTS (CLEAN URLS):\n")
        f.write(get_head("plain_domains.txt"))
        f.write("\n")
        f.write("TOP ENDPOINTS:\n")
        f.write(get_head("final_endpoints.txt"))
        f.write("\n")
        f.write("========================================\n")
        f.write("Report generated by SurfMap\n")
        f.write("Created by Khrish - Cybersecurity Specialist\n")
        f.write("========================================\n")
    
    print_success(f"Report saved to: {report_file}")

def show_summary(target, duration, target_dir):
    section_header(f"MISSION COMPLETE: {target}")
    
    print(f"{GREEN}╔══════════════════════════════════════════════════════════════╗")
    print(f"║                   RECONNAISSANCE COMPLETED                   ║")
    print(f"╠══════════════════════════════════════════════════════════════╣")
    print(f"║ Target: {CYAN}{target:<52}{NC}{GREEN} ║")
    print(f"║ Duration: {CYAN}{str(duration) + ' seconds':<50}{NC}{GREEN} ║")
    print(f"║ Results: {CYAN}{target_dir:<51}{NC}{GREEN} ║")
    print(f"╚══════════════════════════════════════════════════════════════╝{NC}")
    
    print(f"\n{YELLOW}Key Findings:{NC}")
    print(f"• Subdomains: {count_lines('all_subs.txt')}")
    print(f"• Live Hosts: {count_lines('plain_domains.txt')}")
    print(f"• URLs: {count_lines('all_urls.txt')}")
    print(f"• Endpoints: {count_lines('final_endpoints.txt')}")
    print(f"• Parameters: {count_lines('endpoints_with_params.txt')}")

def run_target_pipeline(target, work_dir, excluded_domains, skip_sub):
    os.makedirs(work_dir, exist_ok=True)
    os.chdir(work_dir)
    print_status(f"Working directory set to: {os.getcwd()}")
    
    start_time = time.time()
    
    if skip_sub:
        progress_indicator(f"Subdomain Enumeration Skipped - {target}")
        print_status(f"Skipping enum. Seeding target list directly with {target}...")
        with open("all_subs.txt", "w") as f:
            f.write(f"{target}\n")
    else:
        progress_indicator(f"Subdomain Enumeration - {target}")
        subdomain_enum(target)
    
    progress_indicator(f"Live Host Discovery - {target}")
    live_host_discovery()
    
    progress_indicator(f"URL Collection - {target}")
    url_collection()
    
    progress_indicator(f"JavaScript Analysis - {target}")
    js_endpoint_extraction()
    
    progress_indicator(f"Parameter Discovery - {target}")
    parameter_discovery()
    
    progress_indicator(f"Results Aggregation - {target}")
    cleanup_and_merge()
    
    if excluded_domains:
        progress_indicator(f"Filtering Ineligible Domains - {target}")
        filter_exclusions(work_dir, excluded_domains)
    
    end_time = time.time()
    duration = int(end_time - start_time)
    
    generate_report(target, duration)
    show_summary(target, duration, work_dir)

def aggregate_mixed_results(base_dir):
    section_header("AGGREGATING MIXED RESULTS")
    mixed_dir = os.path.join(base_dir, "mixed")
    os.makedirs(mixed_dir, exist_ok=True)
    
    print_status(f"Merging all isolated target data into {mixed_dir}...")
    
    files_to_merge = [
        "all_subs.txt", 
        "alive_subs.txt", 
        "plain_domains.txt",
        "all_urls.txt", 
        "jsfiles.txt", 
        "final_endpoints.txt", 
        "endpoints_with_params.txt"
    ]
    
    for fname in files_to_merge:
        cmd = f"find \"{base_dir}\" -type f -name \"{fname}\" | grep -v \"/mixed/\" | xargs cat 2>/dev/null | sort -u > \"{mixed_dir}/{fname}\""
        run_command(cmd)
        
    print_success(f"All target results cleanly aggregated into: {mixed_dir}")

def main():
    initial_cwd = os.getcwd()
        
    if '-h' in sys.argv or '--help' in sys.argv or '/h' in sys.argv:
        show_help()

    parser = argparse.ArgumentParser(description="SurfMap - Advanced Reconnaissance Suite", add_help=False)
    
    group = parser.add_mutually_exclusive_group(required=False)
    group.add_argument('-u', '--url', help="Single target domain to scan")
    group.add_argument('-f', '--file', help="Text file containing a list of target domains")
    
    parser.add_argument('-skip-u', '--skip-url', help="Single domain to skip/exclude from results")
    parser.add_argument('-skip-f', '--skip-file', help="Text file containing domains to skip/exclude")
    parser.add_argument('-skip-sub', '--skip-subdomains', action='store_true', help="Skip subdomain enumeration and use the target directly")
    parser.add_argument('--setup', action='store_true', help="Install and validate dependencies only")
    
    try:
        args = parser.parse_args()
    except SystemExit:
        print(f"\n{YELLOW}[♦] INFO    ❯ Use -h, --help, or /h to see the correct usage syntax.{NC}")
        sys.exit(1)

    if not args.setup and not args.url and not args.file:
        show_banner()
        print_error("No target specified! Provide -u/--url or -f/--file, or use --setup.")
        print_status("Run the tool with -h, --help, or /h to see available commands and usage.\n")
        sys.exit(1)

    if args.setup and (args.url or args.file):
        print_warning("--setup mode ignores target arguments and exits after environment preparation.")
    
    excluded_domains = []
    if args.skip_url:
        excluded_domains.append(args.skip_url)
    
    if args.skip_file:
        if os.path.isfile(args.skip_file):
            with open(args.skip_file, 'r') as f:
                excluded_domains.extend([line.strip() for line in f if line.strip()])
        else:
            print(f"{RED}[♦] {BOLD}ERROR{NC}   ❯ Skip file '{args.skip_file}' not found. Exiting.{NC}")
            sys.exit(1)
            
    show_banner()
    startup_animation()
    if not prepare_environment(setup_only=args.setup):
        sys.exit(1)

    if args.setup:
        print(f"\n{YELLOW}Setup mode finished successfully.{NC}")
        sys.exit(0)
    
    if args.url:
        target = args.url
        work_dir = os.path.abspath(os.path.join(initial_cwd, "recon", target))
        run_target_pipeline(target, work_dir, excluded_domains, args.skip_subdomains)
        
    elif args.file:
        if not os.path.isfile(args.file):
            print_error(f"Provided target file '{args.file}' does not exist.")
            sys.exit(1)
            
        filename = os.path.basename(args.file)
        name_without_ext = os.path.splitext(filename)[0]
        
        base_dir = os.path.abspath(os.path.join(initial_cwd, "recon", name_without_ext))
        
        with open(args.file, 'r') as f:
            targets = [line.strip() for line in f if line.strip()]
            
        if not targets:
            print_error("The provided domains file is empty.")
            sys.exit(1)
            
        print_status(f"Loaded {len(targets)} targets from {args.file}")
        if excluded_domains:
            print_status(f"Loaded {len(excluded_domains)} domains to exclude.")
        
        for target in targets:
            print(f"\n{PURPLE}============================================================{NC}")
            print(f"{PURPLE}  STARTING PIPELINE FOR: {WHITE}{target}{NC}")
            print(f"{PURPLE}============================================================{NC}")
            
            work_dir = os.path.join(base_dir, target)
            run_target_pipeline(target, work_dir, excluded_domains, args.skip_subdomains)
            
        aggregate_mixed_results(base_dir)

    print(f"\n{YELLOW}Thank you for using {BOLD}SurfMap{NC}{YELLOW}!{NC}")
    print(f"{CYAN}Stay curious, stay secure! 🔒{NC}")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n\r{RED}[!] Process interrupted by user. Scan aborted.{NC}")
        sys.exit(1)
