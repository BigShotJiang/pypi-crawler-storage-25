# ==============================================================================
# hatsu - Emotion-Responsive Text Generator
# Copyright (c) 2026 Kouhei Takagi
# 
# This software operates under the Spatial Dual License (Kármán Line Provision).
# Commercial exploitation, mass cognitive manipulation, or integration into 
# political propaganda / advertising algorithms is STRICTLY PROHIBITED on Earth.
# 
# [CRITICAL WARNING]
# The 'minus' mode in this library is designed to generate adversarial text.
# The creator assumes ZERO liability for any psychological distress or harm.
# By using this software, the developer assumes full and exclusive responsibility.
# ==============================================================================

import json
import time
import threading
from typing import Any, Dict

# 新しいSDKのインポート
from google import genai

# OpenAI SDKのインポート（オプショナル）
try:
    import openai
except ImportError:
    openai = None

from .prompts import build_prompt

_CFG: Dict[str, Any] = {
    "activated": False,
    "llm": None,
    "model": None,
    "client": None,  # クライアントオブジェクトを保持するキー
    "lock": threading.Lock(),       # 追加: プロセス全体のロック
    "last_execution": 0.0,          # 追加: 最終実行時刻
}

def activate(
    llm: str = "gemini",
    api_key: str | None = None,
    model: str | None = None,
    base_url: str | None = None,
    **kwargs
) -> None:
    """
    hatsu を初期化し、指定されたLLMのクライアントをセットアップします。
    """
    if not api_key:
        raise ValueError("API key must be provided.")

    if llm == "gemini":
        _CFG["client"] = genai.Client(api_key=api_key)
        _CFG["model"] = model or "gemini-3-flash-preview"
        
    elif llm == "openai":
        if openai is None:
            raise ImportError(
                "The 'openai' library is not installed. "
                "Please install it with 'pip install openai'."
            )
        # base_urlを指定可能にすることで、互換API（DeepSeek等）に対応
        _CFG["client"] = openai.OpenAI(api_key=api_key, base_url=base_url)
        _CFG["model"] = model or "gpt-4o"
        
    else:
        raise NotImplementedError(f"LLM '{llm}' is not supported yet.")

    _CFG["llm"] = llm
    _CFG["activated"] = True


def suggest(
    text: str,
    estimate_data: dict,
    mode: str,
    allow_amplification: bool = False,
    acknowledge_adversarial_risk: bool = False,
    **kwargs
) -> dict:
    """
    外部から受け取った感情推定データに基づき、指定されたモードでテキストを生成します。
    """
    if not _CFG.get("activated"):
        raise RuntimeError("hatsu is not activated. Call hatsu.activate(...) first.")

    # --- 連続使用を防ぐためのインターバル（マルチスレッド対応の摩擦） ---
    with _CFG["lock"]:
        current_time = time.time()
        elapsed = current_time - _CFG["last_execution"]
        if elapsed < 1.3:
            time.sleep(1.3 - elapsed)
        _CFG["last_execution"] = time.time()

    # --- Safety Guard (Safety Flag) Validation ---
    if mode == "plus":
        if not allow_amplification:
            raise PermissionError(
                "[hatsu Safety Guard]\n"
                "The 'plus' mode intentionally amplifies the user's emotions, which entails risks.\n"
                "To execute, you must explicitly specify 'allow_amplification=True' in the arguments."
            )
    elif mode == "minus":
        if not acknowledge_adversarial_risk:
            raise PermissionError(
                "[hatsu CRITICAL WARNING]\n"
                "The 'minus' mode causes the AI to directly and logically oppose or deny the user's emotions and inputs.\n"
                "Because this may cause severe psychological distress, strong consent is required for execution.\n"
                "To execute, you must explicitly specify 'acknowledge_adversarial_risk=True' in the arguments."
            )
    elif mode == "sync":
        # syncモードは「同調と知的昇華」を目的とするため、特殊な警告フラグは不要
        pass
    else:
        raise ValueError(f"Unknown mode: '{mode}'. Expected 'plus' or 'minus'.")

    # --- LLMによるテキスト生成 ---
    prompt = build_prompt(text=text, estimate_data=estimate_data, mode=mode)

    generated_text = ""
    
    if _CFG["llm"] == "gemini":
        client = _CFG["client"]
        # 新しいSDKでのコンテンツ生成メソッド
        response = client.models.generate_content(
            model=_CFG["model"],
            contents=prompt
        )
        generated_text = response.text
        
    elif _CFG["llm"] == "openai":
        client = _CFG["client"]
        # OpenAI SDKでのChat Completions API呼び出し
        response = client.chat.completions.create(
            model=_CFG["model"],
            messages=[{"role": "user", "content": prompt}]
        )
        generated_text = response.choices[0].message.content

    return {
        "original_text": text,
        "mode": mode,
        "suggestion": generated_text.strip()
    }