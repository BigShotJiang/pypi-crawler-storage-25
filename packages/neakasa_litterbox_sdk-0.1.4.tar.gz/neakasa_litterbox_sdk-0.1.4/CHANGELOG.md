# Changelog

## [0.1.4](https://github.com/roquerodrigo/neakasa-litterbox-sdk/compare/v0.1.3...v0.1.4) (2026-05-23)


### Bug Fixes

* **client:** fall back to full REST re-login on handshake failure ([e758985](https://github.com/roquerodrigo/neakasa-litterbox-sdk/commit/e7589854fe7b77b795604a52392dbb8d30476680))
* **client:** fall back to full REST re-login when Aliyun handshake fails ([838c323](https://github.com/roquerodrigo/neakasa-litterbox-sdk/commit/838c32392cd865e7aa5a118366e24c57629d31db))

## [0.1.3](https://github.com/roquerodrigo/neakasa-litterbox-sdk/compare/v0.1.2...v0.1.3) (2026-05-22)


### Bug Fixes

* **aliyun:** auto-refresh iotToken on 401 instead of failing the call ([47b13ed](https://github.com/roquerodrigo/neakasa-litterbox-sdk/commit/47b13ed1891a8246462ea60d390db7bd74ddc808))

## [0.1.2](https://github.com/roquerodrigo/neakasa-litterbox-sdk/compare/v0.1.1...v0.1.2) (2026-05-21)


### Bug Fixes

* **mqtt:** defer TLS context build to connect() to avoid blocking event loop ([ec9c823](https://github.com/roquerodrigo/neakasa-litterbox-sdk/commit/ec9c8230132f17773127ff3773b1950d74922a0e))

## [0.1.1](https://github.com/roquerodrigo/neakasa-litterbox-sdk/compare/v0.1.0...v0.1.1) (2026-05-19)


### Features

* initial public release of neakasa-litterbox-sdk ([3b8baa0](https://github.com/roquerodrigo/neakasa-litterbox-sdk/commit/3b8baa09e18c4c27d68d0dd7d9ad62c45123676d))
