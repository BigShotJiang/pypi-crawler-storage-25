"""Utility helpers for ExecuTrace."""
