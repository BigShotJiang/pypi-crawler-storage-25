TEMPLATES = {

    "rag_pipeline": """
Build a COMPLETE RAG pipeline using:

- LangChain
- FAISS
- OpenAI embeddings

Requirements:
- Load documents
- Split into chunks
- Create embeddings
- Store in FAISS
- Create retriever
- Build QA chain

Rules:
- NO CLI loop
- NO input()
- NO unrelated project code
- Return clean standalone Python script
""",

    "code_generation": """
Generate clean Python code.

Rules:
- No input()
- Use hardcoded values
- Must be runnable
""",

    "filesystem": """
Use ONLY tools for filesystem operations.

DO NOT write Python code.
""",

    "general": """
Solve the task using best available tools.
"""
}