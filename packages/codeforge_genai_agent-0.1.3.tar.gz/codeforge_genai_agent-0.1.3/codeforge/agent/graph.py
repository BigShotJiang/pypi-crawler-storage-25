from langgraph.graph import StateGraph, END
from codeforge.agent.state import AgentState

from codeforge.agents.planner import planner
from codeforge.agents.executor import executor
from codeforge.agents.reviewer import reviewer

def should_continue(state):
    return "end" if "FINAL" in state.get("review", "") else "loop"

def build_graph():
    graph = StateGraph(AgentState)

    graph.add_node("planner", planner)
    graph.add_node("executor", executor)
    graph.add_node("reviewer", reviewer)

    graph.set_entry_point("planner")

    graph.add_edge("planner", "executor")
    graph.add_edge("executor", "reviewer")

    graph.add_conditional_edges(
        "reviewer",
        should_continue,
        {
            "loop": "executor",
            "end": END
        }
    )

    return graph.compile()