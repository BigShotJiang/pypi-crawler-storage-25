# codeforge/agent/validator.py

import json


def validate_json_output(text: str):
    try:
        parsed = json.loads(text)
        return True, parsed, None
    except Exception as e:
        return False, None, f"Invalid JSON: {e}"


def validate_tool(action: str, tools: dict):
    if action not in tools:
        return False, f"Invalid tool '{action}'. Allowed: {list(tools.keys())}"
    return True, None


def validate_python_file_input(tool_input: str):
    """
    Must be:
    filename|||code
    OR
    filename\ncode
    """

    if "|||" in tool_input:
        return True, None

    if "\n" in tool_input:
        return True, None

    return False, "create_python_file requires: filename|||FULL CODE"


def validate_action(action: str, tool_input: str, tools: dict):
    """
    Master validator
    """

    # tool check
    valid, err = validate_tool(action, tools)
    if not valid:
        return False, err

    # special rules
    if action == "create_python_file":
        valid, err = validate_python_file_input(tool_input)
        if not valid:
            return False, err

    return True, None