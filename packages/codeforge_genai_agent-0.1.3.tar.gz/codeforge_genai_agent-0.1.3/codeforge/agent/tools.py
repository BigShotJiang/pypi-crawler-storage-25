# codeforge/agent/tools.py

import os
import shutil
import subprocess
import tempfile
import textwrap
import re
import uuid
from pathlib import Path

# -------------------------
# 📄 FILE OPERATIONS
# -------------------------

def read_file(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except Exception as e:
        return str(e)


def write_file(data):
    try:
        path, content = data.split("|||", 1)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        return f"File '{path}' written"
    except Exception as e:
        return str(e)


def delete_file(path):
    try:
        os.remove(path)
        return f"File '{path}' deleted"
    except Exception as e:
        return str(e)


# -------------------------
# 📁 DIRECTORY OPERATIONS
# -------------------------

def create_directory(path):
    try:
        Path(path).mkdir(parents=True, exist_ok=True)
        return f"Directory '{path}' created"
    except Exception as e:
        return str(e)


def delete_directory(path):
    try:
        shutil.rmtree(path)
        return f"Directory '{path}' deleted"
    except Exception as e:
        return str(e)


def rename_directory(data):
    try:
        old, new = data.split("|||")
        os.rename(old.strip(), new.strip())
        return f"Renamed '{old}' → '{new}'"
    except Exception as e:
        return str(e)


def list_directory(path="."):
    try:
        if not path or path.strip() == "":
            path = "."  # default to current directory

        return "\n".join(os.listdir(path))
    except Exception as e:
        return str(e)


# -------------------------
# 📦 PACKAGE MANAGEMENT
# -------------------------

def is_package_installed(pkg):
    try:
        __import__(pkg)
        return True
    except ImportError:
        return False


def install_package(pkg):
    try:
        return subprocess.getoutput(f"pip install {pkg}")
    except Exception as e:
        return str(e)


def extract_imports(code: str):
    imports = re.findall(r"^\s*import\s+(\w+)|^\s*from\s+(\w+)", code, re.MULTILINE)
    pkgs = set()

    for imp in imports:
        pkg = imp[0] or imp[1]
        if pkg:
            pkgs.add(pkg.split(".")[0])

    return list(pkgs)


# -------------------------
# 🐍 PYTHON EXECUTION
# -------------------------

def sanitize_code(code: str):
    code = re.sub(r"input\(.*?\)", "5", code)
    return code


def run_python_code(code: str):
    try:
        code = sanitize_code(code)
        code = textwrap.dedent(code)

        with tempfile.NamedTemporaryFile(delete=False, suffix=".py", mode="w") as f:
            f.write(code)
            temp_path = f.name

        result = subprocess.run(
            ["python", temp_path],
            capture_output=True,
            text=True,
            timeout=15
        )

        output = result.stdout + result.stderr

        if result.returncode != 0:
            return f"❌ Error:\n{output}"

        return output if output else "✅ Code executed"

    except Exception as e:
        return str(e)


# -------------------------
# 🐍 CREATE PYTHON FILE
# -------------------------

def create_python_file(data):
    try:
        raw = data.strip()
        raw = re.sub(r"```python|```", "", raw).strip()

        if "|||" in raw:
            filename, code = raw.split("|||", 1)
        else:
            parts = raw.split("\n", 1)
            if len(parts) < 2:
                return "❌ No code detected"
            filename, code = parts

        filename = os.path.basename(filename.strip())
        if not filename.endswith(".py"):
            filename += ".py"

        code = code.strip()
        if not code:
            return "❌ No code detected"

        with open(filename, "w", encoding="utf-8") as f:
            f.write(code)

        return f"✅ Python file '{filename}' created successfully"

    except Exception as e:
        return f"❌ Error: {str(e)}"


# -------------------------
# 🌐 SYSTEM
# -------------------------

def get_current_directory(_=None):
    return os.getcwd()


# -------------------------
# 🧠 TOOL REGISTRY
# -------------------------

TOOLS = {
    "read_file": read_file,
    "write_file": write_file,
    "delete_file": delete_file,

    "create_directory": create_directory,
    "delete_directory": delete_directory,
    "rename_directory": rename_directory,
    "list_directory": list_directory,

    "run_python_code": run_python_code,
    "create_python_file": create_python_file,

    "is_package_installed": is_package_installed,
    "install_package": install_package,
    "extract_imports": extract_imports,

    "get_current_directory": get_current_directory,
}