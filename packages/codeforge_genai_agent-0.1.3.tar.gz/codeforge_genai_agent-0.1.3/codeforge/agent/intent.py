def detect_intent(query: str) -> str:
    q = query.lower()

    # -------------------------
    # RAG
    # -------------------------
    if any(k in q for k in ["rag", "retrieval", "faiss", "vector store"]):
        return "rag_pipeline"

    # -------------------------
    # FILE SYSTEM OPS
    # -------------------------
    if any(k in q for k in ["rename", "delete", "folder", "directory", "list"]):
        return "filesystem"

    # -------------------------
    # CODE GENERATION
    # -------------------------
    if any(k in q for k in ["python", "script", "code"]):
        return "code_generation"

    # -------------------------
    # DEFAULT
    # -------------------------
    return "general"