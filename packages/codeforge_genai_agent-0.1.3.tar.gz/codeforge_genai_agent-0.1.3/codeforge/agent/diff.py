import difflib

def apply_patch(path, new_content):
    try:
        with open(path) as f:
            old = f.read()
    except:
        old = ""

    diff = "\n".join(difflib.unified_diff(
        old.splitlines(),
        new_content.splitlines(),
        lineterm=""
    ))

    print("\n📌 Proposed Changes:\n")
    print(diff)

    confirm = input("\nApply changes? (y/n): ")
    if confirm.lower() == "y":
        with open(path, "w") as f:
            f.write(new_content)
        return "Patch applied"

    return "Cancelled"