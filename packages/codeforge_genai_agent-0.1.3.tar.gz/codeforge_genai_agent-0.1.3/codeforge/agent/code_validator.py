# codeforge/agent/code_validator.py

from openai import OpenAI
import re

client = OpenAI()


def clean_code(text: str):
    return re.sub(r"```python|```", "", text).strip()


def validate_syntax(code: str):
    try:
        compile(code, "<string>", "exec")
        return True, None
    except Exception as e:
        return False, str(e)


def fix_code(code: str, error: str, filename: str):
    prompt = f"""
Fix this Python code.

STRICT:
- Return ONLY raw Python code
- NO markdown
- NO explanation
- Fix ALL syntax/runtime errors

Code:
{code}

Error:
{error}
"""

    res = client.chat.completions.create(
        model="gpt-4.1",
        messages=[{"role": "user", "content": prompt}]
    )

    fixed = clean_code(res.choices[0].message.content)

    if not fixed or len(fixed) < 10:
        return None

    return fixed


def validate_and_fix(code: str, filename: str, max_attempts=3):
    """
    Full validation + auto-fix loop
    """

    for attempt in range(max_attempts):

        valid, error = validate_syntax(code)

        if valid:
            return code, True

        print(f"⚠️ Syntax issue detected (attempt {attempt+1}): {error}")

        fixed = fix_code(code, error, filename)

        if not fixed:
            break

        code = fixed

    return code, False