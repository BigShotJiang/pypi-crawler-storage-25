import os
import chromadb

client = chromadb.Client()
collection = client.get_or_create_collection("codebase")

def index_repo(path="."):
    for root, _, files in os.walk(path):
        for f in files:
            if f.endswith(".py"):
                full = os.path.join(root, f)
                try:
                    with open(full, "r") as file:
                        content = file.read()

                    collection.add(documents=[content], ids=[full])
                except:
                    pass

def retrieve(query):
    results = collection.query(query_texts=[query], n_results=2)
    return "\n".join(results["documents"][0]) if results["documents"] else ""