from typing import TypedDict, List

class AgentState(TypedDict):
    messages: List[dict]
    plan: str
    execution_result: str
    review: str