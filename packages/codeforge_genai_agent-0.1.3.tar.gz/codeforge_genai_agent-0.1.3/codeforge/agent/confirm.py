def ask_user_confirmation(message: str) -> bool:
    try:
        choice = input(f"\n⚠️ {message} (y/n): ")
        return choice.strip().lower() == "y"
    except:
        return False