import typer
from rich import print

app = typer.Typer(help="CodeForge CLI")


# -------------------------
# 💬 CHAT COMMAND
# -------------------------
@app.command()
def chat():
    """
    Start interactive chat session
    """

    print("[bold green]⚡ CodeForge Ready (type exit)[/bold green]")

    # Lazy load
    from codeforge.agent.graph import build_graph
    from codeforge.agent.rag import index_repo

    print("[yellow]⚙️ Initializing agent...[/yellow]")
    agent = build_graph()
    print("[green]✅ Agent ready[/green]")

    # Background indexing
    import threading

    def run_index():
        try:
            index_repo()
            print("\n[green]✅ Indexing done[/green]")
        except Exception as e:
            print(f"\n[yellow]⚠️ Indexing failed: {e}[/yellow]")

    threading.Thread(target=run_index, daemon=True).start()
    print("[yellow]⚙️ Indexing running in background...[/yellow]")

    state = {"messages": []}

    while True:
        try:
            user_input = input(">> ").strip()

            if not user_input:
                continue

            if user_input.lower() in ["exit", "quit"]:
                print("[bold red]👋 Exiting CodeForge[/bold red]")
                break

            state["messages"].append({
                "role": "user",
                "content": user_input
            })

            result = agent.invoke(state)

            print("\n[bold cyan]✅ FINAL OUTPUT:[/bold cyan]\n")
            print(result.get("execution_result"))

            state["messages"].append({
                "role": "assistant",
                "content": str(result.get("execution_result"))
            })

        except KeyboardInterrupt:
            print("\n[bold red]👋 Interrupted[/bold red]")
            break

        except Exception as e:
            print(f"[red]❌ Error: {e}[/red]")


# -------------------------
# 🚀 ENTRY POINT
# -------------------------
def main():
    app()


if __name__ == "__main__":
    app()