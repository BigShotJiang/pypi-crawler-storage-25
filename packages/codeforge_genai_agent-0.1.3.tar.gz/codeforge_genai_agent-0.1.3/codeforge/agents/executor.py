# codeforge/agent/executor.py

from openai import OpenAI
from codeforge.agent.tools import TOOLS
from codeforge.agent.rag import retrieve
from codeforge.agent.confirm import ask_user_confirmation
from codeforge.agent.code_validator import validate_and_fix

import json
import re
import platform

client = OpenAI()


# -------------------------
# 🧹 HELPERS
# -------------------------

def extract_json(text: str):
    text = re.sub(r"```json|```", "", text).strip()
    match = re.search(r"\{.*\}", text, re.DOTALL)
    return match.group(0) if match else text


def clean_code(text: str):
    return re.sub(r"```python|```", "", text).strip()


def has_error(output: str):
    return any(e in output for e in ["Error", "Traceback", "SyntaxError", "Exception"])


def normalize_input(inp):
    if isinstance(inp, str) and inp.strip() == "":
        return "."
    return inp


# -------------------------
# 🚀 EXECUTOR
# -------------------------

def executor(state):
    user_query = state["messages"][-1]["content"]
    context = retrieve(user_query)
    os_name = platform.system()

    base_prompt = f"""
You are a highly reliable coding agent running on {os_name}.

Think internally step-by-step, but DO NOT output reasoning.

--------------------------------
🎯 TOOL POLICY
--------------------------------
- Code → create_python_file
- Execution → run_python_code
- Files/dirs → use tools
- Packages → only if needed

--------------------------------
🚨 STRICT OUTPUT
--------------------------------
- JSON ONLY
- NO markdown
- NO explanation

FORMAT:
{{"action": "...", "input": "..."}}

For code:
filename.py|||FULL CODE
"""

    feedback = ""

    for attempt in range(4):

        prompt = f"""
{base_prompt}

User Query:
{user_query}

Context:
{context}

Previous feedback:
{feedback}
"""

        res = client.chat.completions.create(
            model="gpt-4.1",
            messages=[{"role": "user", "content": prompt}]
        )

        text = res.choices[0].message.content
        print("\n🧠 RAW OUTPUT:\n", text)

        try:
            parsed = json.loads(extract_json(text))
            action = parsed.get("action")
            tool_input = normalize_input(parsed.get("input"))

            # -------------------------
            # 🔐 TOOL VALIDATION
            # -------------------------
            if action not in TOOLS:
                feedback = f"Invalid tool: {action}"
                continue

            # -------------------------
            # 🧠 INTENT GUARD
            # -------------------------
            if any(k in user_query.lower() for k in ["python", "code", "script", "pipeline"]):
                if action != "create_python_file":
                    feedback = "Use create_python_file for code tasks"
                    continue

            # -------------------------
            # 🐍 CREATE PYTHON FILE
            # -------------------------
            if action == "create_python_file":

                if "|||" not in str(tool_input):
                    feedback = "Use format filename.py|||FULL CODE"
                    continue

                for retry in range(3):

                    result = TOOLS[action](tool_input)

                    if "❌" in result:
                        feedback = result
                        continue

                    filename = tool_input.split("|||")[0].strip()

                    with open(filename, "r", encoding="utf-8") as f:
                        code = f.read()

                    # ❌ incomplete guard
                    if "..." in code:
                        feedback = "Code truncated. Return full code."
                        continue

                    # -------------------------
                    # 🧠 SYNTAX FIX
                    # -------------------------
                    code, is_valid = validate_and_fix(code, filename)

                    if not is_valid:
                        feedback = "Fix syntax errors completely"
                        continue

                    # -------------------------
                    # 📦 DEPENDENCIES
                    # -------------------------
                    imports = TOOLS["extract_imports"](code)
                    missing = [p for p in imports if not TOOLS["is_package_installed"](p)]

                    if missing:
                        if ask_user_confirmation(f"Install packages {missing}?"):
                            for pkg in missing:
                                TOOLS["install_package"](pkg)

                    # -------------------------
                    # ▶️ RUN
                    # -------------------------
                    run_result = TOOLS["run_python_code"](code)

                    # -------------------------
                    # 🔁 RUNTIME FIX
                    # -------------------------
                    if has_error(run_result):
                        feedback = f"""
Fix runtime error.

Code:
{code}

Error:
{run_result}

Return:
filename.py|||FULL FIXED CODE
"""
                        continue

                    # -------------------------
                    # 🚀 SAFE IMPROVEMENT
                    # -------------------------
                    improve_prompt = f"""
Improve this Python code.

STRICT:
- Return ONLY code
- NO markdown
- NO explanation
- DO NOT change functionality

Code:
{code}
"""

                    improved = client.chat.completions.create(
                        model="gpt-4.1",
                        messages=[{"role": "user", "content": improve_prompt}]
                    )

                    improved_code = clean_code(improved.choices[0].message.content)

                    if improved_code and len(improved_code) > 20:

                        improved_code, is_valid = validate_and_fix(improved_code, filename)

                        if is_valid:
                            improved_result = TOOLS["run_python_code"](improved_code)

                            if not has_error(improved_result):
                                with open(filename, "w", encoding="utf-8") as f:
                                    f.write(improved_code)

                                code = improved_code
                            else:
                                improved_result = "⚠️ Improvement caused error. Original kept."
                        else:
                            improved_result = "⚠️ Invalid improvement. Original kept."
                    else:
                        improved_result = "⚠️ No valid improvement generated."

                    return {
                        "execution_result": f"""
{result}

--- Initial ---
{run_result}

--- Improved ---
{improved_result}
"""
                    }

                return {"execution_result": "❌ Failed after retries"}

            # -------------------------
            # 🔧 OTHER TOOLS
            # -------------------------
            result = TOOLS[action](tool_input)

            if not str(result).startswith("❌"):
                return {"execution_result": result}

            feedback = f"""
Execution failed.

Action: {action}
Input: {tool_input}
Error:
{result}
"""

        except Exception as e:
            feedback = f"Parsing error: {str(e)}\n{text}"

    return {"execution_result": "❌ Failed after multiple attempts"}