from openai import OpenAI
client = OpenAI()

def planner(state):
    query = state["messages"][-1]["content"]

    prompt = f"Create a short step-by-step plan:\n{query}"

    res = client.chat.completions.create(
        model="gpt-4.1",
        messages=[{"role": "user", "content": prompt}]
    )

    return {"plan": res.choices[0].message.content}