from openai import OpenAI
client = OpenAI()

def reviewer(state):
    prompt = f"""
Plan:
{state['plan']}

Result:
{state['execution_result']}

If correct → say FINAL
Else → suggest fix
"""

    res = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}]
    )

    return {"review": res.choices[0].message.content}