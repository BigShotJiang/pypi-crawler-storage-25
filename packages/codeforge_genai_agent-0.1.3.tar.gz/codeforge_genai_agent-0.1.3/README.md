🚀 CodeForge – Autonomous Coding Agent

CodeForge is an intelligent coding agent that can:

Generate Python code
Execute code safely
Fix syntax/runtime errors automatically
Install missing dependencies
Improve code quality
Perform file & system operations
📦 Installation
1. Clone the repository
git clone https://github.com/your-username/codeforge.git
cd codeforge
2. Create virtual environment (recommended)
Windows
python -m venv codeforge
codeforge\Scripts\activate
Linux / Mac
python3 -m venv codeforge
source codeforge/bin/activate
3. Install dependencies
pip install -r requirements.txt
4. Set OpenAI API Key
Windows (temporary)
set OPENAI_API_KEY=your_api_key_here
Windows (permanent)
setx OPENAI_API_KEY your_api_key_here
Linux / Mac
export OPENAI_API_KEY=your_api_key_here
5. Install CodeForge CLI
pip install -e .
⚡ Usage
Start the agent
codeforge chat

You’ll see:

⚡ CodeForge Ready (type exit)
>>
💡 Example Commands
📁 File operations
>> create a directory called test
>> list the current directory
>> rename folder test to demo
🐍 Code generation + execution
>> write a python program to add 2 numbers
🧠 Advanced (auto-fixing + execution)
>> create a python script for rag pipeline using FAISS and LangChain

CodeForge will:

Generate code
Install dependencies (with confirmation)
Fix errors automatically
Run the script
🔄 How It Works
User Input
   ↓
LLM (planning + tool selection)
   ↓
Executor
   ↓
Code Generation
   ↓
Code Validator (auto-fix)
   ↓
Dependency Installer
   ↓
Execution
   ↓
Improvement Loop (safe)
🛠️ Features
✅ Autonomous Coding
Generates complete Python scripts
No partial code or placeholders
🔁 Self-Healing
Detects syntax errors
Automatically fixes them
Retries execution
📦 Smart Dependency Handling
Detects missing packages
Asks before installing
Installs automatically
🧠 Intelligent Tool Usage

Supports:

File operations
Directory management
Python execution
System commands (restricted)
🚀 Safe Code Improvement
Improves code readability/performance
Never breaks working code
Falls back if improvement fails
🔐 Safety Features
Blocks dangerous commands
Prevents destructive operations
Disallows unsafe Python execution
Requires confirmation for:
Package installs
Code execution
📂 Project Structure
codeforge/
│
├── agent/
│   ├── executor.py          # Main execution engine
│   ├── tools.py             # Tool registry
│   ├── code_validator.py    # Syntax + fix loop
│   ├── rag.py               # Retrieval system
│   ├── confirm.py           # User confirmations
│
├── main.py                  # CLI entrypoint
├── requirements.txt
├── README.md
🧪 Example Output
>> write a python program to multiply 2 numbers

✅ Python file 'multiply.py' created successfully

--- Initial ---
50

--- Improved ---
50
⚠️ Notes
Do NOT use input() in generated code (non-interactive environment)
Always provide clear instructions
Some operations require user confirmation
🚀 Future Improvements
Function calling (no JSON parsing)
Multi-file project generation
Code diff preview before applying changes
UI / Web interface
Memory + session persistence
🤝 Contributing

Contributions are welcome!

Fork the repo
Create a feature branch
Submit a PR
📄 License

MIT License

🙌 Credits

Built with:

OpenAI
LangChain
LangGraph
FAISS