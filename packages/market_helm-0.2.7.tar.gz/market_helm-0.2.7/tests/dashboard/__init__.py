"""Tests for dashboard modules."""
