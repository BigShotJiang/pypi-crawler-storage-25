"""Dashboard FastAPI application."""
