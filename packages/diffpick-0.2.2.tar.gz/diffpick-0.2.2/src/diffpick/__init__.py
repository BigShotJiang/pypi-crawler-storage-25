"""diffpick — interactive git commit picker and diff viewer."""

__version__ = "0.2.2"
