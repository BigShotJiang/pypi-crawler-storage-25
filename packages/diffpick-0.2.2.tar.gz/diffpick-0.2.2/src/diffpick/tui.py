#!/usr/bin/env python3
"""diffpick — interactive commit picker and diff viewer.

diffpick is not a git client; it is a diff
GUI. The commits panel exists to drive the diff pane — selection (single or
range) is reflected immediately in a delta-rendered side-by-side diff.
Pressing enter on a commit (or range) zooms into a file-tree view of the
files that changed; the right-hand pane then shows the selected file as a
"full-file" diff (the entire file as context, with hunks highlighted).

Bindings track lazygit muscle memory:
    j/k or ↑/↓        move cursor
    G                 jump to bottom (oldest commit shown)
    < / >             top / bottom
    , / .             page up / down
    v                 toggle sticky range mode (anchor here, j/k extends)
    shift+↑/↓         non-sticky range extend
    tab               alias for v
    enter             zoom into selected commit(s) / toggle folder
    o                 open focused hunk / selected file in VS Code
    esc               zoom back / cancel range / clear filter / quit
    ` (backtick)      tree / flat toggle (in zoom)
    z                 hide / show left pane (full-width diff)
    - / =             collapse / expand all folders (in zoom)
    K / J             scroll diff up / down
    ctrl+u / ctrl+d   half-page diff scroll
    F7 / shift+F7     next / previous diff hunk (auto-advances files in zoom)
    1 / 2             unified / side-by-side
    { / }             decrease / increase diff context (commit view)
    R                 reload commits
    /                 filter commits by subject
    q                 quit
    ?                 keybinding help
"""

from __future__ import annotations

import argparse
import difflib
import os
import re
import shutil
import subprocess
import sys
from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Iterable, Literal, Optional, Sequence

from rich.ansi import AnsiDecoder
from rich.segment import Segment
from rich.style import Style
from rich.text import Text
from textual.geometry import Size
from textual.message import Message
from textual.scrollbar import ScrollTo
from textual.scroll_view import ScrollView
from textual.strip import Strip
from textual import events, work
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal
from textual.reactive import reactive
from textual.screen import ModalScreen
from textual.timer import Timer
from textual.widgets import Footer, Input, ListItem, ListView, Static


# ── prerequisites ────────────────────────────────────────────────────────

_GIT_MISSING_MESSAGE = (
    "diffpick: required dependency 'git' was not found on PATH.\n"
    "Install git from https://git-scm.com or your package manager and re-run.\n"
)

_DELTA_MISSING_MESSAGE = (
    "diffpick: required dependency 'delta' (git-delta) was not found on PATH.\n"
    "\n"
    "Install delta:\n"
    "  macOS:        brew install git-delta\n"
    "  Windows:      winget install dandavison.delta   (or: scoop install delta)\n"
    "  Debian/Ubuntu: sudo apt install git-delta\n"
    "  Arch:         sudo pacman -S git-delta\n"
    "  Fedora:       sudo dnf install git-delta\n"
    "  Any platform: cargo install git-delta\n"
    "\n"
    "After installing, ensure 'delta' is on your PATH and re-run diffpick.\n"
    "See https://github.com/dandavison/delta for details.\n"
)


def _check_prerequisites() -> Optional[str]:
    """Return None if all prerequisites are present, else an error message."""
    if shutil.which("git") is None:
        return _GIT_MISSING_MESSAGE
    if shutil.which("delta") is None:
        return _DELTA_MISSING_MESSAGE
    return None


# ── data ─────────────────────────────────────────────────────────────────

DIFF_RENDER_DELAY = 0.045
DIFF_CACHE_SIZE = 48
LINE_CACHE_SIZE = 512
DIFF_SCROLL_EASING = "linear"
DIFF_SCROLL_MIN_DURATION = 0.06
DIFF_SCROLL_MAX_DURATION = 0.18
DIFF_SCROLL_LINES_PER_SECOND = 90.0
# In file-zoom mode we ask git for "the whole file as context". A huge -U
# value is the standard trick — bigger than any source file we'll meet in
# practice, so the entire file appears around each hunk.
FULL_FILE_CONTEXT = 999_999
HUNK_NAVIGATION_CONTEXT = 3
WORKTREE_SHA = "__diffpick_worktree__"

RenderedDiff = tuple[Text, ...]
DEFAULT_STYLE = Style()
ViewMode = Literal["commits", "files"]
HunkBlock = tuple[int, int]
NavigationHunkBlocks = Optional[tuple[HunkBlock, ...]]
GitCommand = Sequence[str]

DELTA_HUNK_HEADER_RE = re.compile(r"^(?:.+:)?\d+:(?:\s|$)")
DELTA_HUNK_HEADER_LINE_RE = re.compile(r"^(?:.+:)?(?P<line>\d+):(?:\s|$)")
DELTA_HUNK_HEADER_PATH_RE = re.compile(
    r"^(?P<path>.+):(?P<line>\d+):(?:\s|$)"
)
RAW_HUNK_DEST_LINE_RE = re.compile(
    r"^@@+ .*\+(?P<line>\d+)(?:,\d+)?\s+@@+"
)
RAW_HUNK_DEST_RANGE_RE = re.compile(
    r"^@@+ .*\+(?P<line>\d+)(?:,(?P<count>\d+))?\s+@@+"
)
RAW_DIFF_GIT_PATH_RE = re.compile(r"^diff --git a/(?P<old>.+) b/(?P<new>.+)$")
CHANGE_BG_COLORS = {"#124b25", "#1f7a3a", "#5a1518", "#8a2428"}
HUNK_HIGHLIGHT_BG = "#384e6e"
HUNK_HIGHLIGHT_BAR_FG = "#fbbf24"
HUNK_HIGHLIGHT_BAR = "▌"
FILE_HEADER_BG = "#2d3748"
FILE_HEADER_FG = "#f0f0f0"
FILE_HEADER_ICON = " 📄 "
FILE_HEADER_STATUS_FG = {
    "A": "#4ade80",   # green
    "M": "#facc15",   # yellow
    "D": "#f87171",   # red
    "R": "#e879f9",   # magenta
    "C": "#22d3ee",   # cyan
    "T": "#60a5fa",   # blue
}
DELTA_FILE_MARKERS = ("• ", "Δ ")


def _scroll_animation_kwargs(distance: float) -> dict[str, object]:
    duration = abs(distance) / DIFF_SCROLL_LINES_PER_SECOND
    duration = max(DIFF_SCROLL_MIN_DURATION, min(DIFF_SCROLL_MAX_DURATION, duration))
    return {
        "animate": True,
        "duration": duration,
        "easing": DIFF_SCROLL_EASING,
    }


def _is_hunk_header_line(line: Text) -> bool:
    plain = line.plain
    stripped = plain.strip()
    if stripped.startswith(("@@ ", "@@@ ")):
        return True
    if plain.startswith("│"):
        return False
    return plain == plain.lstrip() and bool(
        DELTA_HUNK_HEADER_RE.match(stripped)
    )


def _has_change_background(line: Text) -> bool:
    line_style_bg = getattr(getattr(line, "style", None), "bgcolor", None)
    if line_style_bg is not None and line_style_bg.name.lower() in CHANGE_BG_COLORS:
        return True
    return any(
        span.style is not None
        and span.style.bgcolor is not None
        and span.style.bgcolor.name.lower() in CHANGE_BG_COLORS
        for span in line.spans
    )


def _is_raw_change_line(line: Text) -> bool:
    plain = line.plain
    return plain.startswith(("+", "-")) and not plain.startswith(("+++", "---"))


def _side_by_side_text_changed(parts: list[str]) -> bool:
    if len(parts) < 5:
        return False
    return parts[2].strip() != parts[4].strip()


def _delta_gutter_change_state(line: Text) -> Optional[bool]:
    plain = line.plain
    if plain.startswith("│"):
        parts = plain.split("│")
        if len(parts) < 5:
            return None
        old_line = _positive_int(parts[1])
        new_line = _positive_int(parts[3])
        if old_line is None and new_line is None:
            return _has_change_background(line) and _side_by_side_text_changed(parts)
        if old_line is None or new_line is None:
            return True
        return _has_change_background(line) and _side_by_side_text_changed(parts)

    if "⋮" in plain and "│" in plain:
        gutter = plain.split("│", 1)[0]
        old_gutter, new_gutter = gutter.split("⋮", 1)
        old_line = _positive_int(old_gutter)
        new_line = _positive_int(new_gutter)
        if old_line is None and new_line is None:
            return False
        return old_line is None or new_line is None

    return None


def _is_changed_line(line: Text) -> bool:
    gutter_change_state = _delta_gutter_change_state(line)
    if gutter_change_state is not None:
        return gutter_change_state
    return _has_change_background(line) or _is_raw_change_line(line)


def _change_blocks(lines: RenderedDiff) -> tuple[HunkBlock, ...]:
    blocks: list[HunkBlock] = []
    start: Optional[int] = None
    for index, line in enumerate(lines):
        is_change = _is_changed_line(line)
        if is_change and start is None:
            start = index
        elif not is_change and start is not None:
            blocks.append((start, index - 1))
            start = None
    if start is not None:
        blocks.append((start, len(lines) - 1))
    return tuple(blocks)


def _hunk_blocks(
    lines: RenderedDiff, *, prefer_changes: bool = False
) -> tuple[HunkBlock, ...]:
    header_indexes = tuple(
        index for index, line in enumerate(lines) if _is_hunk_header_line(line)
    )
    change_blocks = _change_blocks(lines)
    if change_blocks and (prefer_changes or len(header_indexes) <= 1):
        return change_blocks
    return tuple((index, index) for index in header_indexes)


def _hunk_line_indexes(lines: RenderedDiff) -> tuple[int, ...]:
    return tuple(start for start, _ in _hunk_blocks(lines))


def _raw_hunk_destination_ranges(raw_diff: str) -> tuple[tuple[int, int], ...]:
    ranges: list[tuple[int, int]] = []
    for line in raw_diff.splitlines():
        match = RAW_HUNK_DEST_RANGE_RE.match(line.strip())
        if match is None:
            continue
        start = int(match.group("line"))
        count_text = match.group("count")
        count = 1 if count_text is None else int(count_text)
        end = start if count <= 0 else start + count - 1
        ranges.append((start, end))
    return tuple(ranges)


def _raw_hunk_navigation_blocks(
    lines: RenderedDiff, raw_diff: str
) -> tuple[HunkBlock, ...]:
    """Map normal-context raw git hunks onto full-context rendered change rows."""
    hunk_ranges = _raw_hunk_destination_ranges(raw_diff)
    change_blocks = _change_blocks(lines)
    if not hunk_ranges or not change_blocks:
        return ()

    block_destinations = tuple(
        _destination_line_for_hunk(lines, start) for start, _ in change_blocks
    )
    mapped: list[HunkBlock] = []
    block_index = 0
    for range_start, range_end in hunk_ranges:
        first: Optional[int] = None
        last: Optional[int] = None
        while block_index < len(change_blocks):
            destination = block_destinations[block_index]
            if destination is None:
                block_index += 1
                continue
            if destination < range_start:
                block_index += 1
                continue
            if destination > range_end:
                break

            start, end = change_blocks[block_index]
            first = start if first is None else first
            last = end
            block_index += 1

        if first is not None and last is not None:
            mapped.append((first, last))
    return tuple(mapped)


def _positive_int(text: str) -> Optional[int]:
    stripped = text.strip()
    if not stripped.isdigit():
        return None
    value = int(stripped)
    return value if value > 0 else None


def _destination_line_from_rendered_line(line: Text) -> Optional[int]:
    """Best-effort destination-file line number from a delta/raw rendered row."""
    plain = line.plain
    stripped = plain.strip()

    raw_match = RAW_HUNK_DEST_LINE_RE.match(stripped)
    if raw_match:
        return _positive_int(raw_match.group("line"))

    header_match = DELTA_HUNK_HEADER_LINE_RE.match(stripped)
    if header_match:
        return _positive_int(header_match.group("line"))

    if plain.startswith("│"):
        # delta side-by-side: │ old │ old text │ new │ new text
        parts = plain.split("│")
        if len(parts) >= 5:
            return _positive_int(parts[3])

    if "⋮" in plain and "│" in plain:
        # delta unified: old ⋮ new │ text
        gutter = plain.split("│", 1)[0]
        _, new_gutter = gutter.split("⋮", 1)
        return _positive_int(new_gutter)

    return None


def _raw_destination_line_for_row(
    lines: RenderedDiff, row_index: int
) -> Optional[int]:
    """Translate a raw unified-diff row to the nearest destination line."""
    hunk_start: Optional[int] = None
    dest_line: Optional[int] = None
    for index in range(min(row_index, len(lines) - 1), -1, -1):
        match = RAW_HUNK_DEST_LINE_RE.match(lines[index].plain.strip())
        if match:
            hunk_start = index
            dest_line = _positive_int(match.group("line"))
            break
    if hunk_start is None or dest_line is None:
        return None

    for index in range(hunk_start + 1, row_index + 1):
        plain = lines[index].plain
        if plain.startswith("\\"):
            continue
        if plain.startswith("+") and not plain.startswith("+++"):
            if index == row_index:
                return dest_line
            dest_line += 1
        elif plain.startswith("-") and not plain.startswith("---"):
            if index == row_index:
                return dest_line
        else:
            if index == row_index:
                return dest_line
            dest_line += 1
    return dest_line


def _rendered_hunk_span(
    lines: RenderedDiff, row_index: int
) -> tuple[int, int]:
    headers = tuple(
        index for index, line in enumerate(lines) if _is_hunk_header_line(line)
    )
    if not headers:
        return (max(0, row_index), min(len(lines) - 1, row_index))

    start = next(
        (index for index in reversed(headers) if index <= row_index),
        headers[0],
    )
    end = next(
        (index - 1 for index in headers if index > row_index),
        len(lines) - 1,
    )
    return start, end


def _destination_line_for_hunk(
    lines: RenderedDiff, row_index: int
) -> Optional[int]:
    if not lines:
        return None

    row_index = max(0, min(len(lines) - 1, row_index))
    direct = _destination_line_from_rendered_line(lines[row_index])
    if direct is not None:
        return direct

    raw = _raw_destination_line_for_row(lines, row_index)
    if raw is not None:
        return raw

    span_start, span_end = _rendered_hunk_span(lines, row_index)
    for index in range(row_index + 1, span_end + 1):
        line_number = _destination_line_from_rendered_line(lines[index])
        if line_number is not None:
            return line_number
    for index in range(row_index - 1, span_start - 1, -1):
        line_number = _destination_line_from_rendered_line(lines[index])
        if line_number is not None:
            return line_number
    return None


def _raw_diff_marker_path(line: str) -> Optional[str]:
    if not line.startswith(("--- ", "+++ ")):
        return None
    path = line[4:].strip()
    if path == "/dev/null":
        return None
    if path.startswith(("a/", "b/")):
        return path[2:]
    return path


def _clean_rendered_file_path(path: str) -> str:
    cleaned = path.strip()
    for marker in DELTA_FILE_MARKERS:
        if cleaned.startswith(marker):
            return cleaned[len(marker):].strip()
    return cleaned


def _file_path_from_rendered_line(line: Text) -> Optional[str]:
    stripped = line.plain.strip()

    header_match = DELTA_HUNK_HEADER_PATH_RE.match(stripped)
    if header_match:
        path = _clean_rendered_file_path(header_match.group("path"))
        return path or None

    marker_path = _raw_diff_marker_path(stripped)
    if marker_path is not None:
        return _clean_rendered_file_path(marker_path)

    git_path_match = RAW_DIFF_GIT_PATH_RE.match(stripped)
    if git_path_match:
        path = _clean_rendered_file_path(
            git_path_match.group("new") or git_path_match.group("old")
        )
        return path or None

    return None


def _file_path_for_hunk(lines: RenderedDiff, row_index: int) -> Optional[str]:
    if not lines:
        return None

    row_index = max(0, min(len(lines) - 1, row_index))
    for index in range(row_index, -1, -1):
        path = _file_path_from_rendered_line(lines[index])
        if path is not None:
            return path
    return None


@dataclass
class Commit:
    sha: str
    short: str
    date: str
    author: str
    subject: str
    decoration: str
    unpushed: bool
    is_worktree: bool = False


@dataclass(frozen=True)
class DiffRequest:
    args: tuple[str, ...]
    side_by_side: bool
    width: int
    fallback_args: tuple[str, ...] = ()
    hunk_args: tuple[str, ...] = ()
    hunk_fallback_args: tuple[str, ...] = ()
    includes_worktree: bool = False


@dataclass(frozen=True)
class RenderedDiffResult:
    lines: RenderedDiff
    hunk_blocks: NavigationHunkBlocks = None


@dataclass(frozen=True)
class CommitSelection:
    """Current commit selection, normalized for newest-first git log order."""

    current: Commit
    newest: Commit
    oldest: Commit
    is_range: bool


@dataclass
class FileChange:
    """A single file's change as reported by `git diff --name-status`."""
    status: str   # M / A / D / R / C / T (first letter of git's status code)
    path: str     # destination path (post-rename)


@dataclass
class TreeNode:
    """A node in the file tree shown in zoom mode.

    Folder nodes have `is_folder=True` and may have `children`. File nodes
    carry a `FileChange` describing their status and full path. The `label`
    is what's shown for that row — for collapsed folder chains this may be
    a `/`-joined multi-segment label like `src/components/foo`.
    """
    label: str
    is_folder: bool
    expanded: bool = True
    children: list["TreeNode"] = field(default_factory=list)
    file: Optional[FileChange] = None


def delta_args_for_request(request: DiffRequest) -> list[str]:
    args = [
        "delta",
        "--paging=never",
        "--line-numbers",
        "--true-color=always",
        "--hunk-header-style=file line-number syntax",
        "--hunk-header-decoration-style=cyan ul",
        "--plus-style=syntax #124b25",
        "--plus-emph-style=syntax bold #1f7a3a",
        "--minus-style=syntax #5a1518",
        "--minus-emph-style=syntax bold #8a2428",
        "--line-numbers-plus-style=bold #4ade80",
        "--line-numbers-minus-style=bold #ff6b6b",
        f"--width={request.width}",
    ]
    if request.side_by_side:
        args.append("--side-by-side")
    return args


def _run(args: GitCommand, **kw: object) -> str:
    kw.setdefault("stderr", subprocess.DEVNULL)
    return subprocess.check_output(list(args), **kw).decode(
        "utf-8", errors="replace"
    )


def _append_pathspec(args: list[str], paths: Sequence[str]) -> None:
    if paths and args:
        args.extend(("--", *paths))


def _first_command_output(
    commands: Sequence[GitCommand],
) -> tuple[Optional[str], Optional[BaseException]]:
    last_error: Optional[BaseException] = None
    for command in commands:
        if not command:
            continue
        try:
            return _run(command), None
        except (subprocess.CalledProcessError, FileNotFoundError) as error:
            last_error = error
    return None, last_error


def _worktree_has_changes(paths: Sequence[str]) -> bool:
    args = [
        "git",
        "status",
        "--porcelain=v1",
        "-z",
        "--untracked-files=all",
        "--ignore-submodules=dirty",
    ]
    _append_pathspec(args, paths)
    try:
        return bool(_run(args))
    except subprocess.CalledProcessError:
        return False


def _worktree_commit() -> Commit:
    return Commit(
        sha=WORKTREE_SHA,
        short="WORKTREE",
        date="",
        author="",
        subject="working tree changes",
        decoration="",
        unpushed=False,
        is_worktree=True,
    )


def _git_diff_context(args: Sequence[str]) -> int:
    for arg in args:
        if arg.startswith("-U") and len(arg) > 2:
            try:
                return int(arg[2:])
            except ValueError:
                continue
        if arg.startswith("--unified="):
            try:
                return int(arg.split("=", 1)[1])
            except ValueError:
                continue
    return HUNK_NAVIGATION_CONTEXT


def _git_diff_pathspec(args: Sequence[str]) -> list[str]:
    try:
        separator = list(args).index("--")
    except ValueError:
        return []
    return list(args[separator + 1 :])


def _untracked_paths(paths: Sequence[str]) -> list[str]:
    args = ["git", "ls-files", "--others", "--exclude-standard", "-z"]
    _append_pathspec(args, paths)
    try:
        out = _run(args)
    except subprocess.CalledProcessError:
        return []
    return [path for path in out.split("\0") if path]


def _untracked_diff_output(paths: Sequence[str], context: int) -> str:
    chunks: list[str] = []
    for path in _untracked_paths(paths):
        result = subprocess.run(
            [
                "git",
                "diff",
                "--no-index",
                "--color=never",
                f"-U{context}",
                "--",
                "/dev/null",
                path,
            ],
            capture_output=True,
            text=True,
        )
        if result.stdout:
            chunks.append(result.stdout.rstrip("\n"))
    return "\n".join(chunks)


def _worktree_diff_output(
    args: GitCommand, fallback_args: GitCommand = ()
) -> tuple[Optional[str], Optional[BaseException]]:
    tracked, error = _first_command_output((args, fallback_args))
    context = _git_diff_context(args)
    paths = _git_diff_pathspec(args)
    untracked = _untracked_diff_output(paths, context)

    chunks = [chunk.rstrip("\n") for chunk in (tracked, untracked) if chunk]
    if chunks:
        return "\n".join(chunks) + "\n", None
    if tracked is not None:
        return tracked, None
    return None, error


def load_commits(paths: list[str], limit: int = 500) -> list[Commit]:
    try:
        unpushed_out = _run(["git", "log", "--format=%H", "@{u}..HEAD"]).strip()
        unpushed = set(unpushed_out.split("\n")) if unpushed_out else set()
    except subprocess.CalledProcessError:
        unpushed = set()

    args = [
        "git",
        "log",
        "--topo-order",
        "--abbrev=8",
        f"-n{limit}",
        "--pretty=format:%H\x1f%h\x1f%ad\x1f%an\x1f%s\x1f%d",
        "--date=format:%Y-%m-%d",
    ]
    _append_pathspec(args, paths)

    commits: list[Commit] = []
    if _worktree_has_changes(paths):
        commits.append(_worktree_commit())

    try:
        out = _run(args)
    except subprocess.CalledProcessError:
        return commits

    for line in out.split("\n"):
        if not line:
            continue
        parts = line.split("\x1f")
        if len(parts) < 6:
            continue
        sha, short, date, author, subject, decoration = parts[:6]
        commits.append(
            Commit(
                sha=sha,
                short=short,
                date=date,
                author=author,
                subject=subject,
                decoration=decoration.strip(),
                unpushed=sha in unpushed,
            )
        )
    return commits


def render_commit_text(c: Commit) -> Text:
    t = Text(no_wrap=True, overflow="ellipsis")
    if c.is_worktree:
        t.append(c.short, style="bold green")
        t.append("  ")
        t.append(c.subject, style="bold")
        return t
    t.append(c.short, style=f"bold {'red' if c.unpushed else 'yellow'}")
    t.append("  ")
    t.append(c.date, style="dim")
    t.append("  ")
    t.append(c.author[:8].ljust(8), style="cyan")
    t.append("  ")
    t.append(c.subject)
    if c.decoration:
        t.append(" ")
        t.append(c.decoration, style="bold magenta")
    return t


# ── file-list helpers ────────────────────────────────────────────────────

def _parse_name_status(out: str) -> list[FileChange]:
    """Parse output of `git diff --name-status -M -C` into FileChange list.

    Rename/copy lines look like `R100\told\tnew`; we keep the destination.
    A given path may appear multiple times in a range (modified by several
    commits) — last writer wins, since it best reflects the net status.
    """
    seen: dict[str, FileChange] = {}
    for line in out.split("\n"):
        if not line:
            continue
        parts = line.split("\t")
        if len(parts) < 2:
            continue
        letter = parts[0][:1]
        if letter in ("R", "C") and len(parts) >= 3:
            path = parts[2]
        else:
            path = parts[1]
        if not path:
            continue
        seen[path] = FileChange(status=letter, path=path)
    return sorted(seen.values(), key=lambda f: f.path)


def file_changes_for_single_commit(sha: str, paths: list[str]) -> list[FileChange]:
    args = [
        "git", "diff-tree", "--no-commit-id", "--name-status",
        "-r", "-M", "-C", "--cc", sha,
    ]
    _append_pathspec(args, paths)
    try:
        return _parse_name_status(_run(args))
    except subprocess.CalledProcessError:
        return []


def _file_changes_for_worktree_base(
    base_refs: Sequence[str], paths: list[str]
) -> list[FileChange]:
    changes_by_path: dict[str, FileChange] = {}
    for base_ref in base_refs:
        args = ["git", "diff", "--name-status", "-M", "-C", base_ref]
        _append_pathspec(args, paths)
        try:
            changes_by_path = {
                change.path: change for change in _parse_name_status(_run(args))
            }
            break
        except subprocess.CalledProcessError:
            continue

    for path in _untracked_paths(paths):
        changes_by_path[path] = FileChange(status="A", path=path)

    return sorted(changes_by_path.values(), key=lambda f: f.path)


def file_changes_for_worktree(paths: list[str]) -> list[FileChange]:
    return _file_changes_for_worktree_base(("HEAD",), paths)


def file_changes_for_worktree_range(
    oldest: str, paths: list[str]
) -> list[FileChange]:
    return _file_changes_for_worktree_base((f"{oldest}^", oldest), paths)


def file_changes_for_range(
    oldest: str, newest: str, paths: list[str]
) -> list[FileChange]:
    base = ["git", "diff", "--name-status", "-M", "-C"]
    primary = [*base, f"{oldest}^..{newest}"]
    fallback = [*base, f"{oldest}..{newest}"]
    _append_pathspec(primary, paths)
    _append_pathspec(fallback, paths)
    for cmd in (primary, fallback):
        try:
            return _parse_name_status(_run(cmd))
        except subprocess.CalledProcessError:
            continue
    return []


def build_file_tree(changes: list[FileChange]) -> TreeNode:
    """Build a folder tree from file changes, lazygit-style.

    Folders are sorted before files; both are then alphabetical.
    Single-child folder chains are collapsed (e.g. `a/b/c/Foo.py`, when each
    intermediate folder has only one child, becomes one row `a/b/c/`).
    """
    root = TreeNode(label="", is_folder=True)
    for ch in changes:
        parts = ch.path.split("/")
        cur = root
        for part in parts[:-1]:
            existing = next(
                (c for c in cur.children if c.is_folder and c.label == part),
                None,
            )
            if existing is None:
                existing = TreeNode(label=part, is_folder=True)
                cur.children.append(existing)
            cur = existing
        cur.children.append(
            TreeNode(label=parts[-1], is_folder=False, file=ch)
        )

    def sort_recursive(node: TreeNode) -> None:
        node.children.sort(key=lambda c: (not c.is_folder, c.label.lower()))
        for c in node.children:
            if c.is_folder:
                sort_recursive(c)

    def collapse_chains(node: TreeNode) -> None:
        for child in node.children:
            if child.is_folder:
                while len(child.children) == 1 and child.children[0].is_folder:
                    only = child.children[0]
                    child.label = f"{child.label}/{only.label}"
                    child.children = only.children
                collapse_chains(child)

    sort_recursive(root)
    collapse_chains(root)
    return root


# ── widgets ──────────────────────────────────────────────────────────────

class CommitItem(ListItem):
    def __init__(self, commit: Commit, idx: int) -> None:
        super().__init__()
        self.commit = commit
        self.idx = idx
        self._in_range = False

    def compose(self) -> ComposeResult:
        yield Static(render_commit_text(self.commit), markup=False, classes="commit-row")

    def set_in_range(self, in_range: bool) -> None:
        if self._in_range != in_range:
            self._in_range = in_range
            self.set_class(in_range, "in-range")


class HelpScreen(ModalScreen):
    BINDINGS = [Binding("escape,q,question_mark", "dismiss", show=False)]

    MODAL_WIDTH = 80
    HORIZONTAL_PADDING = 3
    CONTENT_WIDTH = MODAL_WIDTH - 2 - (HORIZONTAL_PADDING * 2)
    KEY_COLUMN_WIDTH = 13
    HELP_SECTIONS: tuple[tuple[str, tuple[tuple[str, str], ...]], ...] = (
        (
            "navigation",
            (
                ("j / k", "move cursor down / up"),
                ("↑ / ↓", "move cursor (alternate)"),
                ("G", "jump to bottom"),
                ("< / >", "top / bottom (lazygit)"),
                (", / .", "page up / down"),
            ),
        ),
        (
            "selection",
            (
                ("v", "toggle sticky range mode"),
                ("tab", "alias for v"),
                ("shift+↑/↓", "extend range without sticky mode"),
            ),
        ),
        (
            "zoom / file pane",
            (
                ("enter", "zoom into commit(s) / toggle folder"),
                ("o", "open focused hunk / selected file in VS Code"),
                ("esc", "zoom back to commits"),
                ("-", "collapse all folders"),
                ("=", "expand all folders"),
                ("`", "tree / flat toggle"),
                ("z", "hide / show left pane"),
            ),
        ),
        (
            "diff pane",
            (
                ("K / J", "scroll up / down"),
                ("ctrl+u / d", "half-page scroll"),
                ("F7", "next hunk; advances to next file in zoom"),
                ("shift+F7", "previous hunk; advances to previous file in zoom"),
                ("1 / 2", "unified / side-by-side"),
                ("{ / }", "diff context -/+ (commit view only)"),
                ("0", "focus diff pane"),
            ),
        ),
        (
            "misc",
            (
                ("/", "filter commits by subject"),
                ("R", "reload"),
                ("esc", "cancel range / clear filter / quit"),
                ("q", "quit"),
                ("?", "this help"),
            ),
        ),
    )
    HASH_NOTES = (
        ("red hash", "unpushed (ahead of @{u})", "bold red"),
        ("yellow hash", "pushed", "bold yellow"),
    )

    @classmethod
    def help_text(cls) -> Text:
        text = Text(no_wrap=True, overflow="ellipsis")
        for section_index, (title, rows) in enumerate(cls.HELP_SECTIONS):
            if section_index:
                text.append("\n\n")
            text.append(title, style="bold")
            text.append("\n")
            for keys, description in rows:
                text.append(f"  {keys:<{cls.KEY_COLUMN_WIDTH}}", style="bold cyan")
                text.append(description)
                text.append("\n")

        text.append("\n")
        for label, description, style in cls.HASH_NOTES:
            text.append(label, style=style)
            text.append(f" = {description}\n", style="dim")
        return text

    def compose(self) -> ComposeResult:
        body = Static(self.help_text(), id="help-body")
        body.border_title = " keybindings "
        body.border_subtitle = " esc / q to close "
        yield body


class DiffView(ScrollView):
    """Line-oriented diff viewport for large delta output."""

    class WidthChanged(Message):
        """Posted when the diff pane's content width changes."""

    def __init__(self, *args, **kwargs) -> None:
        kwargs.setdefault("can_focus", True)
        super().__init__(*args, **kwargs)
        self.lines: RenderedDiff = ()
        self._widest_line_width = 0
        self._line_cache: OrderedDict[tuple[int, int, int, int], Strip] = OrderedDict()
        self._last_hunk_target: Optional[int] = None
        self._last_hunk_prefer_changes = False
        self._navigation_hunk_blocks: NavigationHunkBlocks = None
        self._hunk_block_cache: dict[bool, tuple[HunkBlock, ...]] = {}
        self._highlighted_hunk: Optional[HunkBlock] = None
        self._last_resized_width: int = 0
        # When True (file-zoom mode), the hunk highlight always tracks the
        # scroll position so it shows exactly what "o" will open on.
        self.persistent_hunk_highlight: bool = False
        # Sticky file-name banner shown at the top of the viewport in zoom mode.
        self.file_header: Optional[FileChange] = None

    def on_resize(self, event: events.Resize) -> None:
        width = event.size.width
        if width != self._last_resized_width:
            self._last_resized_width = width
            self.post_message(self.WidthChanged())

    def set_lines(
        self,
        lines: RenderedDiff,
        *,
        hunk_blocks: NavigationHunkBlocks = None,
    ) -> None:
        self.lines = lines
        self._navigation_hunk_blocks = hunk_blocks
        self._widest_line_width = max((line.cell_len for line in lines), default=0)
        self._line_cache.clear()
        self._hunk_block_cache.clear()
        self._clear_hunk_focus()
        self.virtual_size = Size(self._widest_line_width, len(lines))
        self.refresh()

    def _clear_hunk_focus(self) -> None:
        had_highlight = self._highlighted_hunk is not None
        self._last_hunk_target = None
        self._last_hunk_prefer_changes = False
        self._highlighted_hunk = None
        if had_highlight:
            self._line_cache.clear()
            self.refresh()

    def _update_hunk_highlight_from_scroll(self) -> None:
        """Set the hunk highlight to the block nearest the current scroll target.

        Used in file-zoom mode so the highlight always shows what "o" will
        open, even after scrolling (not just after F7). This is passive
        highlight state; it must not become the next explicit F7 target.
        """
        if not self.lines:
            return
        prefer_changes = self._default_hunk_prefer_changes()
        hunk_blocks = self._navigation_blocks(prefer_changes=prefer_changes)
        if not hunk_blocks:
            self._clear_hunk_focus()
            return

        current_scroll_y = int(round(self.scroll_target_y))
        best_block: Optional[HunkBlock] = None
        for block in hunk_blocks:
            start, end = block
            if start <= current_scroll_y <= end:
                best_block = block
                break
            if start > current_scroll_y:
                best_block = block
                break
        if best_block is None:
            best_block = hunk_blocks[-1]

        if best_block != self._highlighted_hunk:
            self._highlighted_hunk = best_block
            self._line_cache.clear()
            self.refresh()

    def sync_hunk_highlight(self) -> None:
        """Public entry point: ensure the highlight matches the scroll position."""
        if self.persistent_hunk_highlight:
            self._update_hunk_highlight_from_scroll()

    def _default_hunk_prefer_changes(self) -> bool:
        return (
            self._last_hunk_prefer_changes
            or self._navigation_hunk_blocks is not None
        )

    def smooth_scroll_relative(self, y: float) -> None:
        self._last_hunk_target = None
        self.scroll_to(
            y=self.scroll_target_y + y,
            **_scroll_animation_kwargs(y),
        )
        if self.persistent_hunk_highlight:
            self._update_hunk_highlight_from_scroll()
        else:
            self._clear_hunk_focus()

    def _hunk_center_offset(self) -> int:
        return max(0, self._viewport_height() // 2)

    def _hunk_top_margin(self) -> int:
        return min(3, max(0, self._viewport_height() // 6))

    def _viewport_height(self) -> int:
        try:
            h = self.scrollable_content_region.height
        except Exception:
            h = self.size.height
        # The sticky file header steals one row from visible content.
        if self.file_header:
            h = max(1, h - 1)
        return h

    def _scroll_y_for_hunk_block(
        self, target_start: int, target_end: int, *, center: bool
    ) -> int:
        if not center:
            return target_start

        height = self._viewport_height()
        block_height = target_end - target_start + 1
        if block_height >= height:
            return target_start - self._hunk_top_margin()

        target_line = (target_start + target_end) // 2
        return target_line - self._hunk_center_offset()

    def _navigation_blocks(self, *, prefer_changes: bool) -> tuple[HunkBlock, ...]:
        if prefer_changes and self._navigation_hunk_blocks:
            return self._navigation_hunk_blocks
        if prefer_changes not in self._hunk_block_cache:
            self._hunk_block_cache[prefer_changes] = _hunk_blocks(
                self.lines, prefer_changes=prefer_changes
            )
        return self._hunk_block_cache[prefer_changes]

    def jump_to_hunk(
        self, direction: int, *, center: bool = False, prefer_changes: bool = False,
        wrap: bool = True,
    ) -> bool:
        hunk_blocks = self._navigation_blocks(prefer_changes=prefer_changes)
        if not hunk_blocks:
            return False

        current_scroll_y = int(round(self.scroll_target_y))
        if (
            self._last_hunk_target is not None
            and self._last_hunk_prefer_changes == prefer_changes
        ):
            current = self._last_hunk_target
        else:
            current = current_scroll_y

        # On a fresh forward press from the very top, treat the reference as
        # "before line 0" so a hunk that starts at line 0 still counts as the
        # next hunk forward (otherwise F7 silently skips to the second hunk).
        reference = current
        if (
            self._last_hunk_target is None
            and direction > 0
            and current_scroll_y == 0
        ):
            reference = -1

        if direction > 0:
            found = next(
                (block for block in hunk_blocks if block[0] > reference),
                None,
            )
            if found is None:
                if not wrap:
                    return False
                target_start, target_end = hunk_blocks[0]
            else:
                target_start, target_end = found
        else:
            found = next(
                (block for block in reversed(hunk_blocks) if block[0] < reference),
                None,
            )
            if found is None:
                if not wrap:
                    return False
                target_start, target_end = hunk_blocks[-1]
            else:
                target_start, target_end = found

        if target_start == reference:
            return False
        next_scroll_y = self._scroll_y_for_hunk_block(
            target_start, target_end, center=center
        )

        # Centering can clamp to the current scroll when the target hunk sits
        # near the top or bottom of the file. On a fresh navigation press this
        # produces no visible movement and feels swallowed, so advance one more
        # block so the keypress actually moves the viewport. Only fires when
        # the centering math actually clamped — otherwise an exact "land on
        # the current scroll" target (e.g. first hunk at line 0 in commits
        # mode) would also be advanced, re-introducing the skip-first-hunk
        # bug.
        if (
            self._last_hunk_target is None
            and len(hunk_blocks) > 1
            and self.virtual_size.height > self._viewport_height()
        ):
            max_y = max(0, self.virtual_size.height - self._viewport_height())
            was_clamped = next_scroll_y < 0 or next_scroll_y > max_y
            clamped = max(0, min(next_scroll_y, max_y))
            if was_clamped and clamped == current_scroll_y:
                if direction > 0:
                    advanced = next(
                        (block for block in hunk_blocks if block[0] > target_start),
                        None,
                    )
                else:
                    advanced = next(
                        (block for block in reversed(hunk_blocks) if block[0] < target_start),
                        None,
                    )
                if advanced is not None and advanced != (target_start, target_end):
                    target_start, target_end = advanced
                    next_scroll_y = self._scroll_y_for_hunk_block(
                        target_start, target_end, center=center
                    )

        self.scroll_to(
            y=next_scroll_y,
            **_scroll_animation_kwargs(next_scroll_y - current_scroll_y),
        )
        self._last_hunk_target = target_start
        self._last_hunk_prefer_changes = prefer_changes
        new_highlight = (target_start, target_end)
        if new_highlight != self._highlighted_hunk:
            self._highlighted_hunk = new_highlight
            self._line_cache.clear()
            self.refresh()
        return True

    def focused_hunk_line_index(
        self, *, prefer_changes: Optional[bool] = None
    ) -> Optional[int]:
        block = self.focused_hunk_block(prefer_changes=prefer_changes)
        return None if block is None else block[0]

    def focused_hunk_block(
        self, *, prefer_changes: Optional[bool] = None
    ) -> Optional[HunkBlock]:
        if prefer_changes is None:
            prefer_changes = self._default_hunk_prefer_changes()
        hunk_blocks = self._navigation_blocks(prefer_changes=prefer_changes)
        if not hunk_blocks:
            return None
        if (
            self._last_hunk_target is not None
            and self._last_hunk_prefer_changes == prefer_changes
        ):
            return next(
                (
                    block
                    for block in hunk_blocks
                    if block[0] == self._last_hunk_target
                ),
                (self._last_hunk_target, self._last_hunk_target),
            )

        current_scroll_y = int(round(self.scroll_target_y))
        for start, end in hunk_blocks:
            if start <= current_scroll_y <= end:
                return (start, end)
            if start > current_scroll_y:
                return (start, end)
        return hunk_blocks[-1]

    def focused_hunk_ordinal(
        self, *, prefer_changes: Optional[bool] = None
    ) -> Optional[int]:
        if prefer_changes is None:
            prefer_changes = self._last_hunk_prefer_changes
        hunk_index = self.focused_hunk_line_index(prefer_changes=prefer_changes)
        if hunk_index is None:
            return None
        for ordinal, (start, _) in enumerate(
            self._navigation_blocks(prefer_changes=prefer_changes)
        ):
            if start == hunk_index:
                return ordinal
        return None

    def focused_hunk_destination_line(
        self, *, prefer_changes: Optional[bool] = None
    ) -> Optional[int]:
        hunk_index = self.focused_hunk_line_index(prefer_changes=prefer_changes)
        if hunk_index is None:
            return None
        return _destination_line_for_hunk(self.lines, hunk_index)

    def _on_scroll_to(self, message: ScrollTo) -> None:
        if self._allow_scroll:
            x_distance = (
                0.0 if message.x is None else abs(message.x - self.scroll_x)
            )
            y_distance = (
                0.0 if message.y is None else abs(message.y - self.scroll_y)
            )
            self.scroll_to(
                message.x,
                message.y,
                **_scroll_animation_kwargs(max(x_distance, y_distance)),
            )
            if self.persistent_hunk_highlight:
                self._last_hunk_target = None
                self._update_hunk_highlight_from_scroll()
            else:
                self._clear_hunk_focus()
            message.stop()

    def _on_mouse_scroll_down(self, event: events.MouseScrollDown) -> None:
        if event.ctrl or event.shift:
            if self.allow_horizontal_scroll:
                if self._scroll_right_for_pointer(
                    **_scroll_animation_kwargs(self.app.scroll_sensitivity_x)
                ):
                    event.stop()
        elif self.allow_vertical_scroll:
            if self._scroll_down_for_pointer(
                **_scroll_animation_kwargs(self.app.scroll_sensitivity_y)
            ):
                self._last_hunk_target = None
                if self.persistent_hunk_highlight:
                    self._update_hunk_highlight_from_scroll()
                else:
                    self._clear_hunk_focus()
                event.stop()

    def _on_mouse_scroll_up(self, event: events.MouseScrollUp) -> None:
        if event.ctrl or event.shift:
            if self.allow_horizontal_scroll:
                if self._scroll_left_for_pointer(
                    **_scroll_animation_kwargs(self.app.scroll_sensitivity_x)
                ):
                    event.stop()
        elif self.allow_vertical_scroll:
            if self._scroll_up_for_pointer(
                **_scroll_animation_kwargs(self.app.scroll_sensitivity_y)
            ):
                self._last_hunk_target = None
                if self.persistent_hunk_highlight:
                    self._update_hunk_highlight_from_scroll()
                else:
                    self._clear_hunk_focus()
                event.stop()

    def _highlight_segments(self, segments: list[Segment]) -> list[Segment]:
        highlight_bg = Style(bgcolor=HUNK_HIGHLIGHT_BG)
        result = []
        for seg in segments:
            if seg.style is not None and seg.style.bgcolor is not None:
                result.append(seg)
            else:
                new_style = highlight_bg + (seg.style or DEFAULT_STYLE)
                result.append(Segment(seg.text, new_style, seg.control))
        return result

    def render_line(self, y: int) -> Strip:
        scroll_x, scroll_y = self.scroll_offset
        width = self.scrollable_content_region.width

        # Sticky file-name banner pinned to the top of the viewport.
        if y == 0 and self.file_header:
            return self._render_file_header(width)

        # When the header is shown, content shifts down by one row.
        if self.file_header:
            y -= 1

        line_index = scroll_y + y
        if line_index >= len(self.lines):
            return Strip.blank(width, self.rich_style)

        highlighted_block = self._highlighted_hunk
        is_highlighted = (
            highlighted_block is not None
            and highlighted_block[0] <= line_index <= highlighted_block[1]
        )
        cache_key = (line_index, scroll_x, width, self._widest_line_width, is_highlighted)
        cached = self._line_cache.get(cache_key)
        if cached is not None:
            self._line_cache.move_to_end(cache_key)
            return cached

        base_segments = self._segments_with_styles(
            self.lines[line_index].render(self.app.console)
        )
        if is_highlighted:
            segments = self._highlight_segments(list(base_segments))
            fill_style = self.rich_style + Style(bgcolor=HUNK_HIGHLIGHT_BG)
        else:
            segments = base_segments
            fill_style = self.rich_style

        strip = Strip(segments).crop_extend(scroll_x, scroll_x + width, fill_style)
        if is_highlighted and width > 0:
            # Overlay a bright left-edge bar so the focused hunk is unmistakable
            # even on +/- change-bg lines (which keep their green/red bg and
            # otherwise show no focus indicator).
            bar_style = Style(
                color=HUNK_HIGHLIGHT_BAR_FG,
                bgcolor=HUNK_HIGHLIGHT_BG,
                bold=True,
            )
            bar = Strip([Segment(HUNK_HIGHLIGHT_BAR, bar_style)], cell_length=1)
            strip = Strip.join([bar, strip.crop(1, width)])
        self._line_cache[cache_key] = strip
        if len(self._line_cache) > LINE_CACHE_SIZE:
            self._line_cache.popitem(last=False)
        return strip

    def _segments_with_styles(self, segments: Iterable[Segment]) -> Iterable[Segment]:
        for segment in segments:
            if segment.style is None:
                yield Segment(segment.text, DEFAULT_STYLE, segment.control)
            else:
                yield segment

    def _render_file_header(self, width: int) -> Strip:
        fc = self.file_header
        assert fc is not None
        status_fg = FILE_HEADER_STATUS_FG.get(fc.status, FILE_HEADER_FG)
        status_style = Style(color=status_fg, bgcolor=FILE_HEADER_BG, bold=True)
        path_style = Style(color=FILE_HEADER_FG, bgcolor=FILE_HEADER_BG, bold=True)
        fill_style = Style(bgcolor=FILE_HEADER_BG)

        segments = [
            Segment(FILE_HEADER_ICON, path_style),
            Segment(f"{fc.status} ", status_style),
            Segment(fc.path, path_style),
        ]
        strip = Strip(segments)
        cell_len = strip.cell_length
        if cell_len < width:
            segments.append(Segment(" " * (width - cell_len), fill_style))
            return Strip(segments, cell_length=width)
        return strip.crop_extend(0, width, fill_style)


class FileTreeView(ScrollView):
    """Single-cursor flat-rendered tree of changed files (lazygit-shaped).

    The tree is owned by this widget; cursor movement, expand/collapse, and
    tree/flat toggling all happen here. The host App reads `selected_file()`
    after any mutation to drive the diff pane.
    """

    # Don't inherit ScrollView's arrow/page bindings — the App owns navigation
    # and we drive scroll programmatically as the cursor moves.
    BINDINGS: list[Binding] = []

    STATUS_STYLE = {
        "A": "bold green",
        "M": "bold yellow",
        "D": "bold red",
        "R": "bold magenta",
        "C": "bold cyan",
        "T": "bold blue",
    }
    CURSOR_BG = "#264f78"

    def __init__(self, *args, **kwargs) -> None:
        kwargs.setdefault("can_focus", True)
        super().__init__(*args, **kwargs)
        self.root: Optional[TreeNode] = None
        self.flat_view: bool = False
        self.cursor: int = 0
        self._visible: list[tuple[int, TreeNode]] = []

    # ── data ────────────────────────────────────────────────────────────

    def set_root(self, root: Optional[TreeNode], cursor_path: Optional[str] = None) -> None:
        self.root = root
        self.cursor = 0
        self._recompute_visible()
        if cursor_path:
            self._cursor_to_path(cursor_path)
        self.scroll_to(y=self.cursor, animate=False)

    def _recompute_visible(self) -> None:
        rows: list[tuple[int, TreeNode]] = []
        if self.root is not None:
            if self.flat_view:
                def walk_flat(node: TreeNode) -> None:
                    for c in node.children:
                        if c.is_folder:
                            walk_flat(c)
                        else:
                            rows.append((0, c))
                walk_flat(self.root)
                rows.sort(
                    key=lambda r: r[1].file.path if r[1].file else r[1].label
                )
            else:
                def walk_tree(node: TreeNode, depth: int) -> None:
                    for c in node.children:
                        rows.append((depth, c))
                        if c.is_folder and c.expanded:
                            walk_tree(c, depth + 1)
                walk_tree(self.root, 0)
        self._visible = rows
        widest = max(
            (self._row_text(d, n).cell_len for d, n in rows), default=0
        )
        self.virtual_size = Size(widest, len(rows))
        if rows:
            self.cursor = max(0, min(self.cursor, len(rows) - 1))
        else:
            self.cursor = 0
        self.refresh()

    # ── cursor ──────────────────────────────────────────────────────────

    def selected_node(self) -> Optional[TreeNode]:
        if 0 <= self.cursor < len(self._visible):
            return self._visible[self.cursor][1]
        return None

    def selected_file(self) -> Optional[FileChange]:
        n = self.selected_node()
        if n is None or n.is_folder:
            return None
        return n.file

    def visible_count(self) -> int:
        return len(self._visible)

    def _cursor_to_path(self, path: str) -> None:
        for i, (_, node) in enumerate(self._visible):
            if not node.is_folder and node.file is not None and node.file.path == path:
                self.cursor = i
                return

    def move_cursor(self, delta: int) -> bool:
        if not self._visible:
            return False
        new = max(0, min(len(self._visible) - 1, self.cursor + delta))
        if new == self.cursor:
            return False
        self.cursor = new
        self._scroll_to_cursor()
        self.refresh()
        return True

    def cursor_to(self, idx: int) -> bool:
        if not self._visible:
            return False
        new = max(0, min(len(self._visible) - 1, idx))
        if new == self.cursor:
            return False
        self.cursor = new
        self._scroll_to_cursor()
        self.refresh()
        return True

    def move_cursor_to_next_file(self) -> bool:
        """Advance cursor to the next file node (skipping folders). Returns False if already on the last file."""
        if not self._visible:
            return False
        for i in range(self.cursor + 1, len(self._visible)):
            _, node = self._visible[i]
            if not node.is_folder:
                self.cursor = i
                self._scroll_to_cursor()
                self.refresh()
                return True
        return False

    def move_cursor_to_prev_file(self) -> bool:
        """Move cursor to the previous file node (skipping folders). Returns False if already on the first file."""
        if not self._visible:
            return False
        for i in range(self.cursor - 1, -1, -1):
            _, node = self._visible[i]
            if not node.is_folder:
                self.cursor = i
                self._scroll_to_cursor()
                self.refresh()
                return True
        return False

    def row_at_event(self, event: events.MouseEvent) -> Optional[int]:
        """Return the visible tree row under a mouse event, if any."""
        if not self._visible:
            return None
        if event.screen_x is None or event.screen_y is None:
            return None
        if event.screen_offset not in self.scrollable_content_region:
            return None

        row_y = int(event.screen_offset.y - self.scrollable_content_region.y)
        row = int(self.scroll_offset.y) + row_y
        if 0 <= row < len(self._visible):
            return row
        return None

    def page_height(self) -> int:
        return max(1, self.scrollable_content_region.height - 1)

    def _scroll_to_cursor(self) -> None:
        h = self.scrollable_content_region.height
        if h <= 0:
            return
        scroll_y = int(self.scroll_offset.y)
        if self.cursor < scroll_y:
            self.scroll_to(y=self.cursor, animate=False)
        elif self.cursor >= scroll_y + h:
            self.scroll_to(y=max(0, self.cursor - h + 1), animate=False)

    # ── toggles ────────────────────────────────────────────────────────

    def toggle_under_cursor(self) -> bool:
        """Toggle expansion of the folder under the cursor.

        Returns True iff the cursor was on a folder (i.e. something was
        toggled). File rows return False so the caller can fall through.
        """
        n = self.selected_node()
        if n is None or not n.is_folder:
            return False
        n.expanded = not n.expanded
        self._recompute_visible()
        return True

    def expand_all(self) -> None:
        if self.root is None:
            return
        self._set_all(self.root, True)
        self._recompute_visible()

    def collapse_all(self) -> None:
        if self.root is None:
            return
        self._set_all(self.root, False)
        self._recompute_visible()

    def _set_all(self, node: TreeNode, expanded: bool) -> None:
        for child in node.children:
            if child.is_folder:
                child.expanded = expanded
                self._set_all(child, expanded)

    def toggle_flat(self) -> None:
        # Preserve the file under the cursor across the mode switch.
        sel = self.selected_node()
        keep_path = (
            sel.file.path if sel is not None and not sel.is_folder and sel.file else None
        )
        self.flat_view = not self.flat_view
        self._recompute_visible()
        if keep_path:
            self._cursor_to_path(keep_path)
        self._scroll_to_cursor()
        self.refresh()

    # ── render ─────────────────────────────────────────────────────────

    def _row_text(self, depth: int, node: TreeNode) -> Text:
        t = Text(no_wrap=True, overflow="ellipsis")
        t.append("  " * depth)
        if node.is_folder:
            t.append("▼ " if node.expanded else "▶ ", style="bold")
            t.append(node.label + "/", style="bold cyan")
        else:
            status = node.file.status if node.file else " "
            t.append((status or " ") + " ", style=self.STATUS_STYLE.get(status, ""))
            t.append(node.label)
        return t

    def render_line(self, y: int) -> Strip:
        scroll_x, scroll_y = self.scroll_offset
        width = self.scrollable_content_region.width
        line_index = int(scroll_y) + y

        if not self._visible:
            if line_index == 0:
                placeholder = Text("(no files changed)", style="dim italic")
                segs = [
                    Segment(s.text, s.style or DEFAULT_STYLE, s.control)
                    for s in placeholder.render(self.app.console)
                ]
                return Strip(segs).crop_extend(
                    scroll_x, scroll_x + width, self.rich_style
                )
            return Strip.blank(width, self.rich_style)

        if line_index >= len(self._visible):
            return Strip.blank(width, self.rich_style)

        depth, node = self._visible[line_index]
        text = self._row_text(depth, node)

        if line_index == self.cursor:
            cursor_style = Style(bgcolor=self.CURSOR_BG)
            text = text.copy()
            text.stylize(cursor_style)
            fill_style = self.rich_style + cursor_style
        else:
            fill_style = self.rich_style

        segments = [
            Segment(s.text, s.style or DEFAULT_STYLE, s.control)
            for s in text.render(self.app.console)
        ]
        return Strip(segments).crop_extend(scroll_x, scroll_x + width, fill_style)


# ── app ──────────────────────────────────────────────────────────────────

class DiffpickApp(App):
    CSS = """
    Screen {
        layout: horizontal;
    }

    #commits, #files {
        width: 64;
        max-width: 50%;
        border-right: tall $primary 50%;
        padding: 0;
    }

    #commits > ListItem {
        padding: 0 1;
        height: 1;
    }

    #commits > ListItem.--highlight {
        background: $primary 35%;
    }

    #commits > ListItem.in-range {
        background: $accent 30%;
    }

    #commits > ListItem.in-range.--highlight {
        background: $accent 60%;
    }

    .commit-row {
        height: 1;
    }

    #files {
        scrollbar-gutter: stable;
    }

    #diff {
        width: 1fr;
        scrollbar-gutter: stable;
        background: #242a33;
        color: #f8f8f2;
        padding: 0 1;
    }

    #status {
        dock: top;
        height: 1;
        background: $boost;
        color: $text;
        padding: 0 1;
    }

    #filter {
        dock: bottom;
        height: 1;
        border: none;
        padding: 0 1;
    }

    HelpScreen {
        align: center middle;
        background: $background 45%;
    }

    #help-body {
        width: 80;
        max-width: 96%;
        max-height: 92%;
        height: auto;
        border: round $accent;
        padding: 1 3;
        background: #1d2027;
        color: $text;
        text-wrap: nowrap;
        text-overflow: ellipsis;
        border-title-align: left;
        border-subtitle-align: right;
        border-title-color: $accent;
        border-title-style: bold;
        border-subtitle-color: $text-muted;
    }
    """

    BINDINGS = [
        Binding("j", "cursor_down", show=False),
        Binding("k", "cursor_up", show=False),
        Binding("down", "cursor_down", show=False),
        Binding("up", "cursor_up", show=False),
        Binding("G", "go_bottom", show=False),
        Binding("less_than_sign", "go_top", show=False),
        Binding("greater_than_sign", "go_bottom", show=False),
        Binding("comma", "page_up", show=False),
        Binding("full_stop", "page_down", show=False),
        Binding("v", "toggle_range", "range"),
        Binding("tab", "toggle_range", show=False),
        Binding("shift+down", "extend_down", show=False),
        Binding("shift+up", "extend_up", show=False),
        Binding("enter", "primary", "↵:zoom", priority=True),
        Binding("o", "open_in_vscode", "o:open"),
        Binding("grave_accent", "toggle_flat", show=False),
        Binding("z", "toggle_sidebar", show=False),
        Binding("minus", "collapse_all", show=False),
        Binding("equals_sign", "expand_all", show=False),
        Binding("K", "diff_up", show=False),
        Binding("J", "diff_down", show=False),
        Binding("ctrl+u", "diff_half_up", show=False),
        Binding("ctrl+d", "diff_half_down", show=False),
        Binding("f7", "next_hunk", show=False),
        Binding("shift+f7", "previous_hunk", show=False),
        Binding("f19", "previous_hunk", show=False),
        Binding("0", "focus_diff", show=False),
        Binding("1", "set_unified", "1:unified"),
        Binding("2", "set_side", "2:side-by-side"),
        Binding("left_curly_bracket", "context_dec", show=False),
        Binding("right_curly_bracket", "context_inc", show=False),
        Binding("R", "reload", show=False),
        Binding("slash", "filter", "/:filter"),
        Binding("escape", "cancel", show=False),
        Binding("q", "quit", "quit"),
        Binding("question_mark", "help", "?:help"),
    ]

    range_anchor: reactive[Optional[int]] = reactive(None)
    side_by_side: reactive[bool] = reactive(True)
    context_size: reactive[int] = reactive(3)
    mode: reactive[ViewMode] = reactive("commits")
    sidebar_hidden: reactive[bool] = reactive(False)

    def __init__(self, paths: list[str], side_by_side: bool) -> None:
        super().__init__()
        self.paths = paths
        self.side_by_side = side_by_side
        self.commits: list[Commit] = []
        self._all_commits: list[Commit] = []
        self._render_token = 0
        self._filter: str = ""
        self._diff_timer: Optional[Timer] = None
        self._pending_diff_request: Optional[DiffRequest] = None
        self._pending_diff_token: Optional[int] = None
        self._range_bounds: Optional[tuple[int, int]] = None
        self._suppress_highlight = False
        self._diff_cache: OrderedDict[DiffRequest, RenderedDiffResult] = OrderedDict()
        # Last file selected in zoom mode, so re-zooming with the same commit
        # selection lands the cursor where the user left it.
        self._last_file_path: Optional[str] = None
        # Snapshot of which commit(s) the current file tree was built from.
        # Surfaced in the status bar; used as a stable label for the zoom.
        self._zoom_label: str = ""
        self._repo_root: Optional[str] = None
        self._last_file_hunk_line: Optional[
            tuple[str, tuple[str, ...], tuple[str, ...], int]
        ] = None
        # When set to +1 or -1, _set_diff will auto-jump to the first/last
        # hunk after loading the new file's diff (cross-file F7 navigation).
        self._jump_to_hunk_after_load: int = 0

    # ── compose / mount ──────────────────────────────────────────────────

    def compose(self) -> ComposeResult:
        yield Static("", id="status")
        with Horizontal():
            yield ListView(id="commits")
            file_tree = FileTreeView(id="files")
            file_tree.display = False
            yield file_tree
            yield DiffView(id="diff")
        yield Footer()

    def on_mount(self) -> None:
        self._all_commits = load_commits(self.paths)
        self._apply_filter(render_diff=False)
        # Wait for layout before the first render so delta gets the real width.
        self.call_after_refresh(self.refresh_diff, False)

    def on_resize(self) -> None:
        # Keep delta's --width in sync with the actual diff pane width.
        if self.commits:
            self.refresh_diff()

    def on_diff_view_width_changed(self, _event: DiffView.WidthChanged) -> None:
        # Fires when the diff pane's content width actually changes — covers
        # both terminal resizes and layout-only changes (e.g., sidebar toggle).
        if self.commits:
            self.refresh_diff(False)

    def on_list_view_highlighted(self, event: ListView.Highlighted) -> None:
        # Single source of truth for cursor changes in commits mode: arrow
        # keys (handled by ListView itself), j/k, page nav, top/bottom —
        # everything that moves the index funnels through this event.
        if self._suppress_highlight or self.mode != "commits":
            return
        self._sync_after_change()

    def on_click(self, event: events.Click) -> None:
        if self.mode != "files" or event.button != 1:
            return
        row = self.file_tree.row_at_event(event)
        if row is None:
            return
        event.stop()
        if self.file_tree.cursor_to(row):
            self._sync_after_change()

    # ── helpers ──────────────────────────────────────────────────────────

    @property
    def listview(self) -> ListView:
        return self.query_one("#commits", ListView)

    @property
    def diff_scroll(self) -> DiffView:
        return self.query_one("#diff", DiffView)

    @property
    def file_tree(self) -> FileTreeView:
        return self.query_one("#files", FileTreeView)

    def _commit_selection(self) -> Optional[CommitSelection]:
        if not self.commits:
            return None

        current_index = min(max(self.listview.index or 0, 0), len(self.commits) - 1)
        current = self.commits[current_index]
        if (
            self.range_anchor is not None
            and 0 <= self.range_anchor < len(self.commits)
        ):
            newest_index, oldest_index = sorted([self.range_anchor, current_index])
            return CommitSelection(
                current=current,
                newest=self.commits[newest_index],
                oldest=self.commits[oldest_index],
                is_range=True,
            )

        return CommitSelection(
            current=current,
            newest=current,
            oldest=current,
            is_range=False,
        )

    def _populate_list(self, render_diff: bool = True, debounce: bool = False) -> None:
        lv = self.listview
        self._range_bounds = None
        self._suppress_highlight = True
        try:
            lv.clear()
            for i, c in enumerate(self.commits):
                lv.append(CommitItem(c, i))
            if self.commits:
                lv.index = 0
        finally:
            self._suppress_highlight = False
        self._sync_after_change(render_diff=render_diff, debounce=debounce)

    def _apply_filter(self, render_diff: bool = True, debounce: bool = False) -> None:
        if self._filter:
            needle = self._filter.lower()
            self.commits = [c for c in self._all_commits if needle in c.subject.lower()]
        else:
            self.commits = list(self._all_commits)
        if self.range_anchor is not None and self.range_anchor >= len(self.commits):
            self.range_anchor = None
        self._populate_list(render_diff=render_diff, debounce=debounce)

    def _sync_after_change(
        self, render_diff: bool = True, debounce: bool = True
    ) -> None:
        self._update_range_visual()
        self._update_status()
        if render_diff:
            self.refresh_diff(debounce)

    def _update_range_visual(self) -> None:
        cur = self.listview.index or 0
        if (
            self.range_anchor is not None
            and self.commits
            and 0 <= self.range_anchor < len(self.commits)
        ):
            lo, hi = sorted([self.range_anchor, cur])
            bounds: Optional[tuple[int, int]] = (lo, hi)
        else:
            bounds = None
        if bounds == self._range_bounds:
            return

        children = self.listview.children
        for start, end, in_range in self._range_change_spans(self._range_bounds, bounds):
            for idx in range(max(0, start), min(len(children) - 1, end) + 1):
                child = children[idx]
                if isinstance(child, CommitItem):
                    child.set_in_range(in_range)
        self._range_bounds = bounds

    def _range_change_spans(
        self,
        old: Optional[tuple[int, int]],
        new: Optional[tuple[int, int]],
    ) -> list[tuple[int, int, bool]]:
        if old == new:
            return []

        changes: list[tuple[int, int, bool]] = []
        if old is not None:
            old_lo, old_hi = old
            if new is None:
                changes.append((old_lo, old_hi, False))
            else:
                new_lo, new_hi = new
                if old_lo < new_lo:
                    changes.append((old_lo, min(old_hi, new_lo - 1), False))
                if old_hi > new_hi:
                    changes.append((max(old_lo, new_hi + 1), old_hi, False))

        if new is not None:
            new_lo, new_hi = new
            if old is None:
                changes.append((new_lo, new_hi, True))
            else:
                old_lo, old_hi = old
                if new_lo < old_lo:
                    changes.append((new_lo, min(new_hi, old_lo - 1), True))
                if new_hi > old_hi:
                    changes.append((max(new_lo, old_hi + 1), new_hi, True))

        return [(start, end, state) for start, end, state in changes if start <= end]

    def _update_status(self) -> None:
        bar = self.query_one("#status", Static)
        n = len(self.commits)
        cur = (self.listview.index or 0) + 1 if self.commits else 0
        mode_label = "side-by-side" if self.side_by_side else "unified"
        ctx_label = "ctx=full" if self.mode == "files" else f"ctx={self.context_size}"
        bits = [f"[b]diffpick[/b]  {cur}/{n}", ctx_label, mode_label]
        if self.mode == "files":
            file_count = self.file_tree.visible_count()
            zoom_bits = "[b $accent]ZOOM[/]"
            if self._zoom_label:
                zoom_bits += f" {self._zoom_label}"
            zoom_bits += f"  files:{file_count}"
            bits.insert(1, zoom_bits)
        elif self.range_anchor is not None and self.commits:
            cur_idx = self.listview.index or 0
            count = abs(self.range_anchor - cur_idx) + 1
            bits.insert(1, f"[b $accent]RANGE[/]:{count}")
        if self._filter:
            bits.append(f"/{self._filter}")
        bar.update("  ·  ".join(bits))

    def _term_cols(self) -> int:
        # Prefer the actual content area of the diff pane once layout runs.
        try:
            w = self.diff_scroll.scrollable_content_region.width
            if w >= 40:
                return w
        except Exception:
            pass
        try:
            w = self.diff_scroll.content_size.width
            if w >= 40:
                return w
        except Exception:
            pass
        # Fallback before first layout: app width minus the commits rail and
        # padding/border, which is deterministic from on_mount onward.
        try:
            return max(40, self.size.width - 68)
        except Exception:
            return 80

    # ── actions: navigation ─────────────────────────────────────────────

    # In commits mode, cursor actions only mutate the index;
    # on_list_view_highlighted handles the diff refresh + range visual + status.
    # In files mode, cursor actions drive the FileTreeView directly and we
    # call _sync_after_change ourselves (no Highlighted event).

    def action_cursor_down(self) -> None:
        if self.mode == "files":
            if self.file_tree.move_cursor(+1):
                self._sync_after_change()
            return
        if not self.commits:
            return
        self.listview.index = min(len(self.commits) - 1, (self.listview.index or 0) + 1)

    def action_cursor_up(self) -> None:
        if self.mode == "files":
            if self.file_tree.move_cursor(-1):
                self._sync_after_change()
            return
        if not self.commits:
            return
        self.listview.index = max(0, (self.listview.index or 0) - 1)

    def action_go_top(self) -> None:
        if self.mode == "files":
            if self.file_tree.cursor_to(0):
                self._sync_after_change()
            return
        if self.commits:
            self.listview.index = 0

    def action_go_bottom(self) -> None:
        if self.mode == "files":
            if self.file_tree.cursor_to(10**9):
                self._sync_after_change()
            return
        if self.commits:
            self.listview.index = len(self.commits) - 1

    def action_page_up(self) -> None:
        if self.mode == "files":
            if self.file_tree.move_cursor(-self.file_tree.page_height()):
                self._sync_after_change()
            return
        if not self.commits:
            return
        page = max(1, self.listview.size.height - 2)
        self.listview.index = max(0, (self.listview.index or 0) - page)

    def action_page_down(self) -> None:
        if self.mode == "files":
            if self.file_tree.move_cursor(self.file_tree.page_height()):
                self._sync_after_change()
            return
        if not self.commits:
            return
        page = max(1, self.listview.size.height - 2)
        self.listview.index = min(
            len(self.commits) - 1, (self.listview.index or 0) + page
        )

    # ── actions: range (commits mode only) ──────────────────────────────

    def action_toggle_range(self) -> None:
        if self.mode != "commits" or not self.commits:
            return
        if self.range_anchor is None:
            self.range_anchor = self.listview.index or 0
        else:
            self.range_anchor = None
        self._sync_after_change()

    def action_extend_down(self) -> None:
        if self.mode != "commits":
            return
        if self.range_anchor is None and self.commits:
            self.range_anchor = self.listview.index or 0
        self.action_cursor_down()

    def action_extend_up(self) -> None:
        if self.mode != "commits":
            return
        if self.range_anchor is None and self.commits:
            self.range_anchor = self.listview.index or 0
        self.action_cursor_up()

    # ── actions: diff pane (both modes) ─────────────────────────────────

    def _smooth_diff_scroll(self, y: float) -> None:
        self.diff_scroll.smooth_scroll_relative(y)

    def action_diff_up(self) -> None:
        self._smooth_diff_scroll(-1)

    def action_diff_down(self) -> None:
        self._smooth_diff_scroll(1)

    def action_diff_half_up(self) -> None:
        h = self.diff_scroll.size.height // 2
        self._smooth_diff_scroll(-max(1, h))

    def action_diff_half_down(self) -> None:
        h = self.diff_scroll.size.height // 2
        self._smooth_diff_scroll(max(1, h))

    def action_next_hunk(self) -> None:
        in_files = self.mode == "files"
        if self.diff_scroll.jump_to_hunk(
            +1,
            center=in_files,
            prefer_changes=in_files,
            wrap=not in_files,
        ):
            self._remember_focused_file_hunk_line()
        elif in_files:
            # Past the last hunk — advance to the next file in the tree.
            if self.file_tree.move_cursor_to_next_file():
                self._jump_to_hunk_after_load = +1
                self._sync_after_change()

    def action_previous_hunk(self) -> None:
        in_files = self.mode == "files"
        if self.diff_scroll.jump_to_hunk(
            -1,
            center=in_files,
            prefer_changes=in_files,
            wrap=not in_files,
        ):
            self._remember_focused_file_hunk_line()
        elif in_files:
            # Before the first hunk — go to the previous file in the tree.
            if self.file_tree.move_cursor_to_prev_file():
                self._jump_to_hunk_after_load = -1
                self._sync_after_change()

    def action_focus_diff(self) -> None:
        self.diff_scroll.focus()

    def action_set_unified(self) -> None:
        if not self.side_by_side:
            return
        self.side_by_side = False
        self._update_status()
        self.refresh_diff(False)

    def action_set_side(self) -> None:
        if self.side_by_side:
            return
        self.side_by_side = True
        self._update_status()
        self.refresh_diff(False)

    def action_context_dec(self) -> None:
        if self.mode != "commits":
            return
        next_context = max(0, self.context_size - 1)
        if next_context == self.context_size:
            return
        self.context_size = next_context
        self._update_status()
        self.refresh_diff(False)

    def action_context_inc(self) -> None:
        if self.mode != "commits":
            return
        next_context = min(99, self.context_size + 1)
        if next_context == self.context_size:
            return
        self.context_size = next_context
        self._update_status()
        self.refresh_diff(False)

    # ── actions: zoom (file mode) ───────────────────────────────────────

    def action_primary(self) -> None:
        """Enter: zoom into commits or toggle folders."""
        if self.mode == "commits":
            self._zoom_in()
        else:
            if self.file_tree.toggle_under_cursor():
                self._update_status()
            return

    def check_action(self, action: str, parameters: tuple[object, ...]) -> Optional[bool]:
        # `enter` is a priority binding so it works from any pane, but it must
        # yield to modal screens (e.g. the filter input) where enter means
        # "submit", not "zoom".
        if action == "primary" and len(self.screen_stack) > 1:
            return False
        return True

    def action_open_in_vscode(self) -> None:
        if self.mode == "files":
            self._open_selected_file_in_vscode()
        else:
            self._open_focused_hunk_in_vscode()

    def _git_root(self) -> str:
        if self._repo_root is None:
            try:
                self._repo_root = _run(
                    ["git", "rev-parse", "--show-toplevel"]
                ).strip()
            except (subprocess.CalledProcessError, FileNotFoundError):
                self._repo_root = os.getcwd()
        return self._repo_root

    def _open_selected_file_in_vscode(self) -> bool:
        selected = self.file_tree.selected_file()
        if selected is None:
            return False

        path = selected.path
        if not os.path.isabs(path):
            path = os.path.join(self._git_root(), path)

        line_number, has_focused_line = self._selected_file_line_number_and_focus()
        if line_number is not None and has_focused_line:
            line_number = self._map_revision_line_to_worktree(
                selected.path, path, line_number
            )
        return self._open_path_in_vscode(path, line_number)

    def _open_focused_hunk_in_vscode(self) -> bool:
        hunk_index = self.diff_scroll.focused_hunk_line_index()
        if hunk_index is None:
            return False

        path = _file_path_for_hunk(self.diff_scroll.lines, hunk_index)
        if path is None:
            return False

        absolute_path = path
        if not os.path.isabs(absolute_path):
            absolute_path = os.path.join(self._git_root(), path)

        line_number = self.diff_scroll.focused_hunk_destination_line()
        if line_number is not None:
            line_number = self._map_revision_line_to_worktree(
                path, absolute_path, line_number
            )
        return self._open_path_in_vscode(absolute_path, line_number)

    def _open_path_in_vscode(
        self, path: str, line_number: Optional[int] = None
    ) -> bool:
        from diffpick.editor import resolve_open_argv

        line = line_number if line_number is not None else 1
        argv = resolve_open_argv(path, line)
        if argv is None:
            self._log_open_debug("no editor configured")
            return False
        self._log_open_command(argv)
        try:
            subprocess.Popen(
                argv,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
            )
        except FileNotFoundError:
            return False
        return True

    def _log_open_command(self, command: list[str]) -> None:
        self._log_open_message(" ".join(command))

    def _log_open_debug(self, message: str) -> None:
        self._log_open_message(f"# {message}")

    def _log_open_message(self, message: str) -> None:
        log_path = os.environ.get("DIFFPICK_OPEN_LOG")
        if not log_path:
            return
        try:
            with open(log_path, "a", encoding="utf-8") as fh:
                fh.write(message + "\n")
        except OSError:
            pass

    def _selected_file_line_number(self) -> Optional[int]:
        line_number, _has_focused_line = self._selected_file_line_number_and_focus()
        return line_number

    def _selected_file_line_number_and_focus(self) -> tuple[Optional[int], bool]:
        request = self._file_diff_request()
        if request is None:
            return 1, False

        selected = self.file_tree.selected_file()
        if selected is None:
            return 1, False
        focused_line = self.diff_scroll.focused_hunk_destination_line(
            prefer_changes=True
        )
        if focused_line is not None:
            self._log_open_debug(
                f"line source=focused path={selected.path} "
                f"line={focused_line}"
            )
            return focused_line, True

        focused_line = self._focused_file_hunk_line(selected, request)
        if focused_line is not None:
            self._log_open_debug(
                f"line source=remembered path={selected.path} "
                f"line={focused_line}"
            )
            return focused_line, True

        self._log_open_debug(f"line source=default path={selected.path} line=1")
        return 1, False

    def _focused_file_hunk_line(
        self, selected: FileChange, request: DiffRequest
    ) -> Optional[int]:
        if (
            self._last_file_hunk_line is not None
            and self._last_file_hunk_line[0] == selected.path
            and self._last_file_hunk_line[1] == request.args
            and self._last_file_hunk_line[2] == request.fallback_args
        ):
            return self._last_file_hunk_line[3]
        return None

    def _selected_file_revision(self) -> Optional[str]:
        selection = self._commit_selection()
        if selection is None or selection.newest.is_worktree:
            return None
        return selection.newest.sha

    def _map_revision_line_to_worktree(
        self, file_path: str, absolute_path: str, line_number: int
    ) -> int:
        revision = self._selected_file_revision()
        if revision is None or line_number <= 0 or not os.path.isfile(absolute_path):
            return line_number

        try:
            revision_text = _run(["git", "show", f"{revision}:{file_path}"])
            with open(
                absolute_path, "r", encoding="utf-8", errors="replace"
            ) as fh:
                worktree_text = fh.read()
        except (OSError, subprocess.CalledProcessError, FileNotFoundError):
            return line_number

        revision_lines = revision_text.splitlines()
        worktree_lines = worktree_text.splitlines()
        target = line_number - 1
        if (
            target < 0
            or target >= len(revision_lines)
            or not worktree_lines
        ):
            return line_number
        if (
            target < len(worktree_lines)
            and worktree_lines[target] == revision_lines[target]
        ):
            return line_number

        matcher = difflib.SequenceMatcher(
            None, revision_lines, worktree_lines, autojunk=False
        )
        for tag, i1, i2, j1, j2 in matcher.get_opcodes():
            if i1 <= target < i2:
                offset = target - i1
                if tag == "equal":
                    mapped = j1 + offset + 1
                else:
                    mapped = self._approximate_worktree_line_for_changed_block(
                        revision_lines[target], offset, worktree_lines, j1, j2
                    )
                if mapped != line_number:
                    self._log_open_debug(
                        f"line mapped path={file_path} revision={revision[:8]} "
                        f"revision_line={line_number} worktree_line={mapped}"
                    )
                return mapped

        return line_number

    def _approximate_worktree_line_for_changed_block(
        self,
        target_text: str,
        offset: int,
        worktree_lines: list[str],
        start: int,
        end: int,
    ) -> int:
        candidates = [
            index for index in range(start, end) if worktree_lines[index] == target_text
        ]
        if len(candidates) == 1:
            return candidates[0] + 1
        if start >= len(worktree_lines):
            return len(worktree_lines)
        mapped_index = start + min(offset, max(0, end - start - 1))
        return max(1, min(len(worktree_lines), mapped_index + 1))

    def _remember_focused_file_hunk_line(self) -> None:
        if self.mode != "files":
            return
        selected = self.file_tree.selected_file()
        if selected is None:
            return
        request = self._file_diff_request()
        if request is None:
            return
        focused_line = self.diff_scroll.focused_hunk_destination_line(
            prefer_changes=True
        )
        if focused_line is None:
            return
        self._last_file_hunk_line = (
            selected.path,
            request.args,
            request.fallback_args,
            focused_line,
        )
        self._log_open_debug(f"focus path={selected.path} line={focused_line}")

    def _zoom_in(self) -> None:
        selection = self._commit_selection()
        if selection is None:
            return
        if selection.is_range and selection.newest.is_worktree:
            if selection.oldest.is_worktree:
                changes = file_changes_for_worktree(self.paths)
                self._zoom_label = selection.newest.short
            else:
                changes = file_changes_for_worktree_range(
                    selection.oldest.sha, self.paths
                )
                self._zoom_label = (
                    f"{selection.oldest.short}..{selection.newest.short}"
                )
        elif selection.is_range:
            changes = file_changes_for_range(
                selection.oldest.sha, selection.newest.sha, self.paths
            )
            self._zoom_label = f"{selection.oldest.short}..{selection.newest.short}"
        elif selection.current.is_worktree:
            changes = file_changes_for_worktree(self.paths)
            self._zoom_label = selection.current.short
        else:
            changes = file_changes_for_single_commit(selection.current.sha, self.paths)
            self._zoom_label = selection.current.short

        root = build_file_tree(changes)
        self.file_tree.set_root(root, cursor_path=self._last_file_path)
        self.mode = "files"
        self.diff_scroll.persistent_hunk_highlight = True
        self._apply_sidebar_visibility()
        self._sync_after_change(debounce=False)

    def action_zoom_out(self) -> None:
        if self.mode != "files":
            return
        sel = self.file_tree.selected_file()
        if sel is not None:
            self._last_file_path = sel.path
        self.mode = "commits"
        self.diff_scroll.persistent_hunk_highlight = False
        self._apply_sidebar_visibility()
        if not self.sidebar_hidden:
            self.listview.focus()
        else:
            self.diff_scroll.focus()
        self._sync_after_change(debounce=False)

    def _apply_sidebar_visibility(self) -> None:
        if self.sidebar_hidden:
            self.listview.display = False
            self.file_tree.display = False
        else:
            self.listview.display = self.mode == "commits"
            self.file_tree.display = self.mode == "files"

    def action_toggle_sidebar(self) -> None:
        self.sidebar_hidden = not self.sidebar_hidden
        self._apply_sidebar_visibility()
        if self.sidebar_hidden:
            self.diff_scroll.focus()
        elif self.mode == "files":
            self.file_tree.focus()
        else:
            self.listview.focus()
        # The diff pane's WidthChanged message (posted from its on_resize)
        # drives the actual re-render once layout settles.

    def action_toggle_flat(self) -> None:
        if self.mode != "files":
            return
        self.file_tree.toggle_flat()
        self._sync_after_change(debounce=False)

    def action_collapse_all(self) -> None:
        if self.mode != "files":
            return
        self.file_tree.collapse_all()
        self._update_status()

    def action_expand_all(self) -> None:
        if self.mode != "files":
            return
        self.file_tree.expand_all()
        self._update_status()

    # ── actions: misc ───────────────────────────────────────────────────

    def action_reload(self) -> None:
        prev = self.listview.index or 0
        prev_mode = self.mode
        self._diff_cache.clear()
        self._all_commits = load_commits(self.paths)
        self._apply_filter(render_diff=False)
        if self.commits:
            self._suppress_highlight = True
            try:
                self.listview.index = min(prev, len(self.commits) - 1)
            finally:
                self._suppress_highlight = False
        if prev_mode == "files":
            # Re-derive the file tree from the (possibly updated) commit selection
            self._zoom_in()
        else:
            self._sync_after_change(render_diff=True, debounce=False)

    def action_filter(self) -> None:
        if self.mode != "commits":
            return
        self.push_screen(FilterScreen(self._filter), self._filter_done)

    def _filter_done(self, value: Optional[str]) -> None:
        if value is None:
            return
        self._filter = value
        self.range_anchor = None
        self._apply_filter()

    def action_cancel(self) -> None:
        if self.mode == "files":
            self.action_zoom_out()
        elif self.range_anchor is not None:
            self.range_anchor = None
            self._sync_after_change()
        elif self._filter:
            self._filter = ""
            self.range_anchor = None
            self._apply_filter()
        else:
            self.exit()

    def action_help(self) -> None:
        self.push_screen(HelpScreen())

    # ── diff rendering ──────────────────────────────────────────────────

    def _update_file_header(self) -> None:
        if self.mode == "files":
            header = self.file_tree.selected_file()
        else:
            header = None
        if self.diff_scroll.file_header != header:
            self.diff_scroll.file_header = header
            self.diff_scroll._line_cache.clear()
            self.diff_scroll.refresh()

    def refresh_diff(self, debounce: bool = True) -> None:
        request = self._current_diff_request()
        self._render_token += 1
        token = self._render_token

        # Update the sticky file-name header in the diff pane.
        self._update_file_header()

        if request is None:
            self._cancel_pending_diff()
            placeholder = (
                "(no files changed)" if self.mode == "files" else "(no commits)"
            )
            self._set_diff((Text(placeholder),), token)
            return

        cached = self._cached_diff(request)
        if cached is not None:
            self._cancel_pending_diff()
            self._set_diff(cached.lines, token, request, cached.hunk_blocks)
            return

        self._pending_diff_request = request
        self._pending_diff_token = token
        self._cancel_pending_diff_timer()
        if debounce:
            self._diff_timer = self.set_timer(
                DIFF_RENDER_DELAY, self._start_pending_diff
            )
        else:
            self._start_pending_diff()

    def _current_diff_request(self) -> Optional[DiffRequest]:
        if self.mode == "files":
            return self._file_diff_request()
        return self._commit_diff_request()

    def _commit_diff_request(self) -> Optional[DiffRequest]:
        selection = self._commit_selection()
        if selection is None:
            return None

        includes_worktree = False
        if selection.is_range and selection.newest.is_worktree:
            includes_worktree = True
            if selection.oldest.is_worktree:
                args, fallback_args = self._worktree_args(self.context_size)
            else:
                args, fallback_args = self._worktree_range_args(
                    selection.oldest.sha, self.context_size
                )
        elif selection.is_range:
            args, fallback_args = self._range_args(
                selection.oldest.sha, selection.newest.sha, self.context_size
            )
        elif selection.current.is_worktree:
            includes_worktree = True
            args, fallback_args = self._worktree_args(self.context_size)
        else:
            args = [
                "git",
                "show",
                "--color=never",
                f"-U{self.context_size}",
                selection.current.sha,
            ]
            fallback_args = []
        _append_pathspec(args, self.paths)
        _append_pathspec(fallback_args, self.paths)

        return DiffRequest(
            args=tuple(args),
            side_by_side=self.side_by_side,
            width=max(40, self._term_cols() - 2),
            fallback_args=tuple(fallback_args),
            includes_worktree=includes_worktree,
        )

    def _file_diff_request(self) -> Optional[DiffRequest]:
        sel = self.file_tree.selected_file()
        selection = self._commit_selection()
        if sel is None or selection is None:
            return None

        ctx_flag = f"-U{FULL_FILE_CONTEXT}"
        hunk_ctx_flag = f"-U{HUNK_NAVIGATION_CONTEXT}"
        includes_worktree = False
        if selection.is_range and selection.newest.is_worktree:
            includes_worktree = True
            if selection.oldest.is_worktree:
                args, fallback_args = self._worktree_args(FULL_FILE_CONTEXT)
                hunk_args, hunk_fallback_args = self._worktree_args(
                    HUNK_NAVIGATION_CONTEXT
                )
            else:
                args, fallback_args = self._worktree_range_args(
                    selection.oldest.sha, FULL_FILE_CONTEXT
                )
                hunk_args, hunk_fallback_args = self._worktree_range_args(
                    selection.oldest.sha, HUNK_NAVIGATION_CONTEXT
                )
        elif selection.is_range:
            args, fallback_args = self._range_args(
                selection.oldest.sha, selection.newest.sha, FULL_FILE_CONTEXT
            )
            hunk_args, hunk_fallback_args = self._range_args(
                selection.oldest.sha, selection.newest.sha, HUNK_NAVIGATION_CONTEXT
            )
        elif selection.current.is_worktree:
            includes_worktree = True
            args, fallback_args = self._worktree_args(FULL_FILE_CONTEXT)
            hunk_args, hunk_fallback_args = self._worktree_args(
                HUNK_NAVIGATION_CONTEXT
            )
        else:
            sha = selection.current.sha
            args = ["git", "show", "--color=never", ctx_flag, sha]
            fallback_args = []
            hunk_args = ["git", "show", "--color=never", hunk_ctx_flag, sha]
            hunk_fallback_args = []

        _append_pathspec(args, [sel.path])
        _append_pathspec(fallback_args, [sel.path])
        _append_pathspec(hunk_args, [sel.path])
        _append_pathspec(hunk_fallback_args, [sel.path])

        return DiffRequest(
            args=tuple(args),
            side_by_side=self.side_by_side,
            width=max(40, self._term_cols() - 2),
            fallback_args=tuple(fallback_args),
            hunk_args=tuple(hunk_args),
            hunk_fallback_args=tuple(hunk_fallback_args),
            includes_worktree=includes_worktree,
        )

    def _range_args(
        self, oldest: str, newest: str, context: int
    ) -> tuple[list[str], list[str]]:
        base = ["git", "diff", "--color=never", f"-U{context}"]
        return (
            [*base, f"{oldest}^..{newest}"],
            [*base, f"{oldest}..{newest}"],
        )

    def _worktree_args(self, context: int) -> tuple[list[str], list[str]]:
        base = ["git", "diff", "--color=never", f"-U{context}"]
        return ([*base, "HEAD"], [])

    def _worktree_range_args(
        self, oldest: str, context: int
    ) -> tuple[list[str], list[str]]:
        base = ["git", "diff", "--color=never", f"-U{context}"]
        return ([*base, f"{oldest}^"], [*base, oldest])

    def _cancel_pending_diff_timer(self) -> None:
        if self._diff_timer is not None:
            self._diff_timer.stop()
            self._diff_timer = None

    def _cancel_pending_diff(self) -> None:
        self._cancel_pending_diff_timer()
        self._pending_diff_request = None
        self._pending_diff_token = None

    def _start_pending_diff(self) -> None:
        request = self._pending_diff_request
        token = self._pending_diff_token
        self._diff_timer = None
        self._pending_diff_request = None
        self._pending_diff_token = None
        if request is None or token is None or token != self._render_token:
            return
        self._do_diff(request, token)

    def _cached_diff(self, request: DiffRequest) -> Optional[RenderedDiffResult]:
        cached = self._diff_cache.get(request)
        if cached is None:
            return None
        self._diff_cache.move_to_end(request)
        return cached

    def _remember_diff(
        self,
        request: DiffRequest,
        lines: RenderedDiff,
        hunk_blocks: NavigationHunkBlocks,
    ) -> None:
        self._diff_cache[request] = RenderedDiffResult(lines, hunk_blocks)
        self._diff_cache.move_to_end(request)
        while len(self._diff_cache) > DIFF_CACHE_SIZE:
            self._diff_cache.popitem(last=False)

    @work(thread=True, exclusive=True)
    def _do_diff(self, request: DiffRequest, token: int) -> None:
        if request.includes_worktree:
            diff_out, error = _worktree_diff_output(
                request.args, request.fallback_args
            )
        else:
            diff_out, error = _first_command_output(
                (request.args, request.fallback_args)
            )
        if diff_out is None:
            diff_out = f"# diff error: {error}"

        if token != self._render_token:
            return

        try:
            res = subprocess.run(
                delta_args_for_request(request),
                input=diff_out,
                capture_output=True,
                text=True,
            )
            rendered = res.stdout or diff_out
        except FileNotFoundError:
            rendered = diff_out

        if token != self._render_token:
            return

        lines = tuple(AnsiDecoder().decode(rendered))
        hunk_blocks: NavigationHunkBlocks = None
        if request.hunk_args:
            hunk_diff_out = self._hunk_diff_output(request)
            hunk_blocks = _raw_hunk_navigation_blocks(lines, hunk_diff_out)
        self.call_from_thread(self._set_diff, lines, token, request, hunk_blocks)

    def _hunk_diff_output(self, request: DiffRequest) -> str:
        if request.includes_worktree:
            output, _error = _worktree_diff_output(
                request.hunk_args, request.hunk_fallback_args
            )
        else:
            output, _error = _first_command_output(
                (request.hunk_args, request.hunk_fallback_args)
            )
        return output or ""

    def _set_diff(
        self,
        lines: RenderedDiff,
        token: int,
        request: Optional[DiffRequest] = None,
        hunk_blocks: NavigationHunkBlocks = None,
    ) -> None:
        if token != self._render_token:
            return
        if request is not None:
            self._remember_diff(request, lines, hunk_blocks)
        self.diff_scroll.set_lines(lines, hunk_blocks=hunk_blocks)
        self.diff_scroll.scroll_home(animate=False)
        self.diff_scroll.sync_hunk_highlight()

        # Cross-file hunk navigation: after a new file's diff loads, auto-jump
        # to the first (or last) hunk so F7/shift-F7 flows seamlessly.
        direction = self._jump_to_hunk_after_load
        if direction != 0:
            self._jump_to_hunk_after_load = 0
            if self.mode == "files":
                if direction > 0:
                    self.diff_scroll.jump_to_hunk(
                        +1, center=True, prefer_changes=True
                    )
                else:
                    # Jump to the last hunk for shift-F7 going backwards.
                    self.diff_scroll.jump_to_hunk(
                        -1, center=True, prefer_changes=True
                    )
                self._remember_focused_file_hunk_line()


class FilterScreen(ModalScreen[Optional[str]]):
    BINDINGS = [Binding("escape", "cancel", show=False)]

    def __init__(self, initial: str = "") -> None:
        super().__init__()
        self._initial = initial

    def compose(self) -> ComposeResult:
        yield Input(value=self._initial, placeholder="filter by subject…", id="filter")

    def on_input_submitted(self, event: Input.Submitted) -> None:
        self.dismiss(event.value)

    def action_cancel(self) -> None:
        self.dismiss(None)


# ── entrypoint ───────────────────────────────────────────────────────────

def main() -> int:
    parser = argparse.ArgumentParser(description="interactive commit picker and diff viewer")
    parser.add_argument(
        "--side-by-side", dest="sbs", action="store_true", default=None
    )
    parser.add_argument("--unified", dest="sbs", action="store_false")
    parser.add_argument("paths", nargs="*", help="optional path filters")
    args = parser.parse_args()

    err = _check_prerequisites()
    if err is not None:
        sys.stderr.write(err)
        return 1

    try:
        subprocess.check_output(
            ["git", "rev-parse", "--show-toplevel"], stderr=subprocess.DEVNULL
        )
    except (subprocess.CalledProcessError, FileNotFoundError):
        print("diffpick: not in a git repository", file=sys.stderr)
        return 1

    if args.sbs is None:
        try:
            cols = os.get_terminal_size().columns
        except OSError:
            cols = 100
        args.sbs = cols >= 140

    DiffpickApp(paths=args.paths, side_by_side=args.sbs).run()
    return 0


if __name__ == "__main__":
    sys.exit(main())
