"""Entry point for `python -m diffpick`."""

import sys

from diffpick.tui import main

if __name__ == "__main__":
    sys.exit(main())
