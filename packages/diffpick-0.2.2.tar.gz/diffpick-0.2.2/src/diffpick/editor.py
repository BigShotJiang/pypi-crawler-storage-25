"""Editor launching for diffpick.

Resolves an editor command from environment variables and a small registry
of known editors, then opens a given file at a specific line.

Resolution precedence:
  1. DIFFPICK_OPEN_CMD — full format string with {file} and {line}.
  2. VISUAL or EDITOR  — basename matched against a known-editor table;
                         falls back to `<editor> {file}` for unknown ones.
  3. Fallback          — `code -g {file}:{line}` if `code` is on PATH.
"""

from __future__ import annotations

import os
import shlex
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Optional

# Known editor basenames -> argv template (with {file} and {line} placeholders).
_KNOWN_EDITORS: dict[str, list[str]] = {
    "code":          ["code", "-g", "{file}:{line}"],
    "code-insiders": ["code-insiders", "-g", "{file}:{line}"],
    "vim":           ["vim", "+{line}", "{file}"],
    "nvim":          ["nvim", "+{line}", "{file}"],
    "subl":          ["subl", "{file}:{line}"],
    "idea":          ["idea", "--line", "{line}", "{file}"],
    "pycharm":       ["pycharm", "--line", "{line}", "{file}"],
    "webstorm":      ["webstorm", "--line", "{line}", "{file}"],
    "goland":        ["goland", "--line", "{line}", "{file}"],
    "rubymine":      ["rubymine", "--line", "{line}", "{file}"],
    "emacs":         ["emacs", "+{line}", "{file}"],
}


def _format_argv(template: list[str], file: str, line: int) -> list[str]:
    return [arg.format(file=file, line=line) for arg in template]


def _split(cmd: str) -> list[str]:
    """Split a user-supplied command string into argv, sh-style on POSIX."""
    return shlex.split(cmd, posix=os.name != "nt")


def resolve_open_argv(file: str, line: int) -> Optional[list[str]]:
    """Return the argv to launch an editor at file:line, or None if unresolved."""
    user_cmd = os.environ.get("DIFFPICK_OPEN_CMD")
    if user_cmd:
        template = _split(user_cmd)
        return _format_argv(template, file, line)

    for env_var in ("VISUAL", "EDITOR"):
        editor = os.environ.get(env_var)
        if not editor:
            continue
        parts = _split(editor)
        if not parts:
            continue
        basename = Path(parts[0]).name
        if basename in _KNOWN_EDITORS:
            return _format_argv(_KNOWN_EDITORS[basename], file, line)
        # Unknown editor: open without line number rather than crash.
        return parts + [file]

    if shutil.which("code"):
        return _format_argv(_KNOWN_EDITORS["code"], file, line)

    return None


_NO_EDITOR_MESSAGE = (
    "diffpick: no editor configured. "
    "Set DIFFPICK_OPEN_CMD, $VISUAL, or $EDITOR. "
    "Example: DIFFPICK_OPEN_CMD='code -g {file}:{line}'\n"
)


def open_in_editor(file: str, line: int) -> bool:
    """Launch the configured editor at file:line. Returns True on success."""
    argv = resolve_open_argv(file, line)
    if argv is None:
        sys.stderr.write(_NO_EDITOR_MESSAGE)
        return False
    try:
        subprocess.Popen(
            argv,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
    except FileNotFoundError:
        sys.stderr.write(f"diffpick: could not launch {argv[0]} (not on PATH)\n")
        return False
    return True
