# diffpick

An interactive commit picker and diff viewer for git.

Designed as a diff-viewing companion to [lazygit](https://github.com/jesseduffield/lazygit) — built because viewing diffs felt like the rough edge in lazygit's otherwise excellent UX. Keybindings follow lazygit conventions where it makes sense; see [KEYBINDINGS.md](./KEYBINDINGS.md) for the full table.

Rendering is done by [git-delta](https://github.com/dandavison/delta).

## What it does

- Lazygit-inspired commit picker with single-commit and range selection
- Side-by-side or unified diff view (auto-adapts to terminal width)
- Zoom into a commit to browse its file tree
- Hunk navigation, full-file context view, "open in editor" jump
- Filter by path or commit subject
- Familiar keybindings: `j`/`k`, `/`, `v` for range, `F7` for next hunk, `?` for help

## Prerequisites

- Python ≥ 3.10
- git
- [git-delta](https://github.com/dandavison/delta)

Install delta:

```
macOS:        brew install git-delta
Windows:      winget install dandavison.delta   (or: scoop install delta)
Debian/Ubuntu: sudo apt install git-delta
Arch:         sudo pacman -S git-delta
Fedora:       sudo dnf install git-delta
Any:          cargo install git-delta
```

If you don't have Python yet:

- macOS:   `brew install python`
- Windows: install from <https://python.org> or `winget install Python.Python.3.12`
- Linux:   already there on most distros (`python3 --version` to check)

## Install

The recommended way is [pipx](https://pipx.pypa.io), which installs CLI tools into isolated environments:

```
pipx install diffpick
```

If you don't have pipx:

```
macOS:    brew install pipx && pipx ensurepath
Windows:  python -m pip install --user pipx && python -m pipx ensurepath
Linux:    sudo apt install pipx && pipx ensurepath   (or: python -m pip install --user pipx)
```

Alternative — with [uv](https://docs.astral.sh/uv/):

```
uv tool install diffpick
```

Or plain pip into a venv:

```
python -m venv ~/.venvs/diffpick
~/.venvs/diffpick/bin/pip install diffpick
~/.venvs/diffpick/bin/diffpick
```

## Usage

```
diffpick                  # open the TUI in the current repo
diffpick path/to/file     # narrow to commits touching one path
diffpick --side-by-side   # force side-by-side layout
diffpick --unified        # force unified layout
diffpick --help
```

Inside the TUI, press `?` for the keybinding list.

## Configuration

### Editor for "open file at line"

Pressing `o` on a focused hunk or selected file launches it in your editor at
the right line. The command is resolved in this order:

1. **`DIFFPICK_OPEN_CMD`** — full format string, with `{file}` and `{line}` placeholders.
   Power-user override:
   ```
   export DIFFPICK_OPEN_CMD='code -g {file}:{line}'
   ```
2. **`$VISUAL` or `$EDITOR`** — if the basename matches a known editor (`code`,
   `code-insiders`, `vim`, `nvim`, `subl`, `idea`, `pycharm`, `webstorm`,
   `goland`, `rubymine`, `emacs`), the right "open at line" invocation is used
   automatically. Unknown editors are launched without a line number.
3. **Fallback** — `code -g {file}:{line}` if `code` is on PATH.

### WSL note

If you're on WSL and use VS Code, install the **WSL** extension in your
Windows VS Code (formerly "Remote - WSL"). With the extension and `code` on
PATH inside WSL, opening files from diffpick "just works." If `code` is
missing, run `Shell Command: Install 'code' command in PATH` from VS Code's
command palette (`Ctrl+Shift+P`).

## License

MIT — see [LICENSE](./LICENSE).
