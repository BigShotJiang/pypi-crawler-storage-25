"""Tests for diffpick.editor.resolve_open_argv."""

from __future__ import annotations

import sys
from unittest.mock import patch

import pytest


pytest.importorskip("diffpick.editor")
from diffpick.editor import resolve_open_argv


@pytest.fixture(autouse=True)
def _clear_env(monkeypatch):
    """Each test starts with no editor env vars set."""
    for var in ("DIFFPICK_OPEN_CMD", "VISUAL", "EDITOR"):
        monkeypatch.delenv(var, raising=False)


def test_user_cmd_takes_precedence_over_visual(monkeypatch):
    monkeypatch.setenv("DIFFPICK_OPEN_CMD", "code -g {file}:{line}")
    monkeypatch.setenv("VISUAL", "vim")
    argv = resolve_open_argv("path/to/file.py", 42)
    assert argv == ["code", "-g", "path/to/file.py:42"]


@pytest.mark.skipif(
    sys.platform == "win32",
    reason="shlex.split with posix=False keeps surrounding quotes; this test asserts POSIX behavior",
)
def test_user_cmd_with_quoted_args(monkeypatch):
    monkeypatch.setenv("DIFFPICK_OPEN_CMD", 'myedit --target "{file}:{line}"')
    argv = resolve_open_argv("a b.py", 9)
    assert argv == ["myedit", "--target", "a b.py:9"]


def test_visual_known_editor_nvim(monkeypatch):
    monkeypatch.setenv("VISUAL", "nvim")
    argv = resolve_open_argv("foo.py", 7)
    assert argv == ["nvim", "+7", "foo.py"]


def test_editor_known_editor_subl(monkeypatch):
    monkeypatch.setenv("EDITOR", "subl")
    argv = resolve_open_argv("foo.py", 7)
    assert argv == ["subl", "foo.py:7"]


def test_visual_takes_precedence_over_editor(monkeypatch):
    monkeypatch.setenv("VISUAL", "vim")
    monkeypatch.setenv("EDITOR", "nano")
    argv = resolve_open_argv("foo.py", 3)
    assert argv == ["vim", "+3", "foo.py"]


def test_visual_with_args_uses_basename_template(monkeypatch):
    """If VISUAL is 'code --new-window', basename is 'code' so we use the known
    template (which knows how to jump to a line). User-supplied args are
    discarded; if they want full control they should use DIFFPICK_OPEN_CMD."""
    monkeypatch.setenv("VISUAL", "code --new-window")
    argv = resolve_open_argv("foo.py", 7)
    assert argv == ["code", "-g", "foo.py:7"]


def test_unknown_editor_drops_line(monkeypatch):
    monkeypatch.setenv("VISUAL", "weird-editor")
    argv = resolve_open_argv("foo.py", 7)
    assert argv == ["weird-editor", "foo.py"]


def test_no_env_falls_back_to_code_when_present(monkeypatch):
    with patch("diffpick.editor.shutil.which", return_value="/usr/local/bin/code"):
        argv = resolve_open_argv("foo.py", 7)
    assert argv == ["code", "-g", "foo.py:7"]


def test_no_env_no_code_returns_none(monkeypatch):
    with patch("diffpick.editor.shutil.which", return_value=None):
        argv = resolve_open_argv("foo.py", 7)
    assert argv is None


@pytest.mark.parametrize(
    "basename,expected_template",
    [
        ("idea", ["idea", "--line", "5", "foo.py"]),
        ("pycharm", ["pycharm", "--line", "5", "foo.py"]),
        ("webstorm", ["webstorm", "--line", "5", "foo.py"]),
        ("goland", ["goland", "--line", "5", "foo.py"]),
        ("rubymine", ["rubymine", "--line", "5", "foo.py"]),
        ("emacs", ["emacs", "+5", "foo.py"]),
        ("vim", ["vim", "+5", "foo.py"]),
        ("code-insiders", ["code-insiders", "-g", "foo.py:5"]),
    ],
)
def test_jetbrains_and_others(monkeypatch, basename, expected_template):
    monkeypatch.setenv("EDITOR", basename)
    assert resolve_open_argv("foo.py", 5) == expected_template
