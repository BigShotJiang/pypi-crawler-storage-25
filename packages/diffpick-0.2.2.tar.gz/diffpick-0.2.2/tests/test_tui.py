from __future__ import annotations

import builtins
import shutil
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import pytest
from rich.style import Style
from rich.text import Text
from textual.app import App, ComposeResult

import diffpick.tui as pdiff_tui


def make_commit(sha: str) -> Any:
    return pdiff_tui.Commit(
        sha=sha,
        short=sha[:8],
        date="2026-05-01",
        author="tester",
        subject=f"subject {sha}",
        decoration="",
        unpushed=False,
    )


class DummyTimer:
    def __init__(self, delay: float, callback: Any) -> None:
        self.delay = delay
        self.callback = callback
        self.stopped = False

    def stop(self) -> None:
        self.stopped = True


class DummyListView:
    def __init__(self) -> None:
        self.index = 0
        self.children: list[Any] = []
        self.size = SimpleNamespace(height=20)


class DummyScroll:
    def __init__(self) -> None:
        self.content_size = SimpleNamespace(width=120)
        self.size = SimpleNamespace(height=40)
        self.scroll_target_y = 0
        self.home_calls = 0
        self.lines: tuple[Text, ...] = ()
        self.line_updates: list[str] = []
        self.smooth_scroll_calls: list[float] = []
        self.jump_to_hunk_calls: list[tuple[int, bool, bool]] = []
        self.focused_hunk_destination: int | None = None
        self.focused_hunk_index: int | None = None
        self.focused_hunk: int | None = None
        self.focused_prefer_changes: bool | None = None
        self.hunk_updates: list[Any] = []
        self.persistent_hunk_highlight: bool = False
        self.file_header: Any = None
        self._line_cache: dict[Any, Any] = {}

    def scroll_home(self, *, animate: bool = False) -> None:
        self.home_calls += 1

    def smooth_scroll_relative(self, y: float) -> None:
        self.smooth_scroll_calls.append(y)
        self.scroll_target_y += y

    def jump_to_hunk(
        self, direction: int, *, center: bool = False, prefer_changes: bool = False,
        wrap: bool = True,
    ) -> bool:
        self.jump_to_hunk_calls.append((direction, center, prefer_changes))
        return True

    def focused_hunk_destination_line(
        self, *, prefer_changes: bool | None = None
    ) -> int | None:
        self.focused_prefer_changes = prefer_changes
        return self.focused_hunk_destination

    def focused_hunk_line_index(
        self, *, prefer_changes: bool | None = None
    ) -> int | None:
        self.focused_prefer_changes = prefer_changes
        return self.focused_hunk_index

    def focused_hunk_ordinal(self, *, prefer_changes: bool | None = None) -> int | None:
        return self.focused_hunk

    def set_lines(
        self, lines: tuple[Text, ...], *, hunk_blocks: Any = None
    ) -> None:
        self.lines = lines
        self.hunk_updates.append(hunk_blocks)
        self.line_updates.append("\n".join(line.plain for line in lines))

    def sync_hunk_highlight(self) -> None:
        pass

    def refresh(self) -> None:
        pass


class DummyFileTree:
    def __init__(self) -> None:
        self.selected: Any = None
        self.toggle_result = False
        self.toggle_calls = 0

    def toggle_under_cursor(self) -> bool:
        self.toggle_calls += 1
        return self.toggle_result

    def selected_file(self) -> Any:
        return self.selected


class HarnessApp(pdiff_tui.DiffpickApp):
    def __init__(self) -> None:
        super().__init__(paths=[], side_by_side=True)
        self.fake_listview = DummyListView()
        self.fake_scroll = DummyScroll()
        self.fake_file_tree = DummyFileTree()
        self.started_work: list[tuple[Any, ...]] = []
        self.timers: list[DummyTimer] = []
        self.diff_updates: list[tuple[str, int, Any]] = []

    @property
    def listview(self) -> DummyListView:
        return self.fake_listview

    @property
    def diff_scroll(self) -> DummyScroll:
        return self.fake_scroll

    @property
    def file_tree(self) -> DummyFileTree:
        return self.fake_file_tree

    def _update_status(self) -> None:
        pass

    def _term_cols(self) -> int:
        return 120

    def _do_diff(self, *args: Any) -> None:
        self.started_work.append(args)

    def _set_diff(
        self,
        lines: tuple[Text, ...],
        token: int,
        request: Any = None,
        hunk_blocks: Any = None,
    ) -> None:
        plain = "\n".join(line.plain for line in lines)
        self.diff_updates.append((plain, token, request))

    def set_timer(self, delay: float, callback: Any = None, **_: Any) -> DummyTimer:
        timer = DummyTimer(delay, callback)
        self.timers.append(timer)
        return timer


class FakeStatic:
    def __init__(self) -> None:
        self.updates: list[str] = []

    def update(self, content: Any = "") -> None:
        self.updates.append(content.plain if isinstance(content, Text) else str(content))


class CacheHarnessApp(pdiff_tui.DiffpickApp):
    def __init__(self) -> None:
        super().__init__(paths=[], side_by_side=True)
        self.fake_listview = DummyListView()
        self.fake_scroll = DummyScroll()
        self.diff_static = FakeStatic()
        self.status_static = FakeStatic()
        self.started_work: list[tuple[Any, ...]] = []

    @property
    def listview(self) -> DummyListView:
        return self.fake_listview

    @property
    def diff_scroll(self) -> DummyScroll:
        return self.fake_scroll

    def query_one(self, selector: str, *_: Any, **__: Any) -> FakeStatic:
        if selector == "#diff-content":
            return self.diff_static
        return self.status_static

    def _do_diff(self, *args: Any) -> None:
        self.started_work.append(args)
        if hasattr(args[0], "args"):
            self._set_diff((Text("rendered diff"),), args[1], args[0])
        else:
            self._set_diff((Text("rendered diff"),), args[1])


class RecordingCommitItem(pdiff_tui.CommitItem):
    def __init__(self, commit: Any, idx: int) -> None:
        super().__init__(commit, idx)
        self.calls: list[bool] = []

    def set_in_range(self, in_range: bool) -> None:
        self.calls.append(in_range)
        self._in_range = in_range


def test_cursor_sync_debounces_diff_render_work() -> None:
    app = HarnessApp()
    app.commits = [make_commit("a" * 40), make_commit("b" * 40), make_commit("c" * 40)]

    for index in [0, 1, 2]:
        app.fake_listview.index = index
        app._sync_after_change()

    assert app.started_work == []
    assert len(app.timers) == 3
    assert [timer.stopped for timer in app.timers] == [True, True, False]

    app.timers[-1].callback()

    assert len(app.started_work) == 1
    rendered_request = app.started_work[0][0]
    assert "c" * 40 in " ".join(rendered_request.args)


def test_empty_commit_list_invalidates_stale_diff_work() -> None:
    app = HarnessApp()
    app._render_token = 7
    app.commits = []

    app.refresh_diff()

    assert app._render_token == 8
    assert app.diff_updates == [("(no commits)", 8, None)]


def test_refresh_diff_reuses_rendered_diff_for_same_request() -> None:
    app = CacheHarnessApp()
    app.commits = [make_commit("a" * 40)]

    app.refresh_diff(debounce=False)
    assert len(app.started_work) == 1

    app.started_work.clear()
    app.refresh_diff(debounce=False)

    assert app.started_work == []
    assert app.fake_scroll.line_updates == ["rendered diff", "rendered diff"]


def test_update_status_uses_textual_static_update_signature() -> None:
    class StatusHarnessApp(pdiff_tui.DiffpickApp):
        def __init__(self) -> None:
            super().__init__(paths=[], side_by_side=False)
            self.fake_listview = DummyListView()
            self.fake_file_tree = DummyFileTree()
            self.status_static = FakeStatic()

        @property
        def listview(self) -> DummyListView:
            return self.fake_listview

        @property
        def file_tree(self) -> DummyFileTree:
            return self.fake_file_tree

        def query_one(self, selector: str, *_: Any, **__: Any) -> FakeStatic:
            assert selector == "#status"
            return self.status_static

    app = StatusHarnessApp()
    app.commits = [make_commit("a" * 40)]

    app._update_status()

    assert app.status_static.updates == ["[b]diffpick[/b]  1/1  ·  ctx=3  ·  unified"]


def test_single_commit_diff_request_uses_raw_diff_for_delta() -> None:
    app = HarnessApp()
    app.commits = [make_commit("a" * 40)]

    request = app._current_diff_request()

    assert request is not None
    assert "--color=never" in request.args
    assert "--color=always" not in request.args


def test_load_commits_prepends_worktree_when_dirty(monkeypatch: Any) -> None:
    def fake_run(args: list[str], **_: Any) -> str:
        if args == ["git", "log", "--format=%H", "@{u}..HEAD"]:
            return ""
        if args[:2] == ["git", "status"]:
            return " M\0"
        if args[:3] == ["git", "log", "--topo-order"]:
            return "a" * 40 + "\x1faaaaaaaa\x1f2026-05-01\x1ftester\x1fsubject\x1f\n"
        raise AssertionError(f"unexpected command: {args}")

    monkeypatch.setattr(pdiff_tui, "_run", fake_run)

    commits = pdiff_tui.load_commits([])

    assert [commit.short for commit in commits] == ["WORKTREE", "aaaaaaaa"]
    assert commits[0].is_worktree is True


def test_load_commits_omits_worktree_when_clean(monkeypatch: Any) -> None:
    def fake_run(args: list[str], **_: Any) -> str:
        if args == ["git", "log", "--format=%H", "@{u}..HEAD"]:
            return ""
        if args[:2] == ["git", "status"]:
            return ""
        if args[:3] == ["git", "log", "--topo-order"]:
            return "a" * 40 + "\x1faaaaaaaa\x1f2026-05-01\x1ftester\x1fsubject\x1f\n"
        raise AssertionError(f"unexpected command: {args}")

    monkeypatch.setattr(pdiff_tui, "_run", fake_run)

    commits = pdiff_tui.load_commits([])

    assert [commit.short for commit in commits] == ["aaaaaaaa"]
    assert commits[0].is_worktree is False


def test_worktree_commit_diff_request_uses_git_diff_head() -> None:
    app = HarnessApp()
    app.commits = [pdiff_tui._worktree_commit()]

    request = app._current_diff_request()

    assert request is not None
    assert request.includes_worktree is True
    assert request.args == (
        "git",
        "diff",
        "--color=never",
        f"-U{app.context_size}",
        "HEAD",
    )


def test_worktree_file_diff_request_uses_full_and_hunk_context() -> None:
    app = HarnessApp()
    app.mode = "files"
    app.commits = [pdiff_tui._worktree_commit()]
    app.fake_file_tree.selected = pdiff_tui.FileChange("M", "src/foo.py")

    request = app._file_diff_request()

    assert request is not None
    assert request.includes_worktree is True
    assert request.args == (
        "git",
        "diff",
        "--color=never",
        f"-U{pdiff_tui.FULL_FILE_CONTEXT}",
        "HEAD",
        "--",
        "src/foo.py",
    )
    assert request.hunk_args == (
        "git",
        "diff",
        "--color=never",
        f"-U{pdiff_tui.HUNK_NAVIGATION_CONTEXT}",
        "HEAD",
        "--",
        "src/foo.py",
    )


def test_worktree_range_diff_request_targets_worktree() -> None:
    app = HarnessApp()
    app.commits = [pdiff_tui._worktree_commit(), make_commit("a" * 40)]
    app.range_anchor = 0
    app.fake_listview.index = 1

    request = app._current_diff_request()

    assert request is not None
    assert request.includes_worktree is True
    assert request.args == (
        "git",
        "diff",
        "--color=never",
        f"-U{app.context_size}",
        f"{'a' * 40}^",
    )
    assert request.fallback_args == (
        "git",
        "diff",
        "--color=never",
        f"-U{app.context_size}",
        "a" * 40,
    )


def test_file_changes_for_worktree_includes_untracked(monkeypatch: Any) -> None:
    def fake_run(args: list[str], **_: Any) -> str:
        if args == ["git", "diff", "--name-status", "-M", "-C", "HEAD"]:
            return "M\ttracked.py\n"
        if args == ["git", "ls-files", "--others", "--exclude-standard", "-z"]:
            return "new.py\0"
        raise AssertionError(f"unexpected command: {args}")

    monkeypatch.setattr(pdiff_tui, "_run", fake_run)

    changes = pdiff_tui.file_changes_for_worktree([])

    assert [(change.status, change.path) for change in changes] == [
        ("A", "new.py"),
        ("M", "tracked.py"),
    ]


def test_worktree_diff_output_appends_untracked_diffs(monkeypatch: Any) -> None:
    def fake_run(args: list[str], **_: Any) -> str:
        args = list(args)
        if args == ["git", "diff", "--color=never", "-U3", "HEAD"]:
            return "diff --git a/tracked.py b/tracked.py\n"
        if args == ["git", "ls-files", "--others", "--exclude-standard", "-z"]:
            return "new.py\0"
        raise AssertionError(f"unexpected command: {args}")

    def fake_subprocess_run(args: list[str], **_: Any) -> Any:
        assert args == [
            "git",
            "diff",
            "--no-index",
            "--color=never",
            "-U3",
            "--",
            "/dev/null",
            "new.py",
        ]
        return SimpleNamespace(stdout="diff --git a/dev/null b/new.py\n")

    monkeypatch.setattr(pdiff_tui, "_run", fake_run)
    monkeypatch.setattr(pdiff_tui.subprocess, "run", fake_subprocess_run)

    output, error = pdiff_tui._worktree_diff_output(
        ("git", "diff", "--color=never", "-U3", "HEAD")
    )

    assert error is None
    assert output == (
        "diff --git a/tracked.py b/tracked.py\n"
        "diff --git a/dev/null b/new.py\n"
    )


def test_delta_args_force_truecolor_and_terminal_pdiff_hunk_style() -> None:
    request = pdiff_tui.DiffRequest(
        args=("git", "show", "--color=never", "a" * 40),
        side_by_side=True,
        width=120,
    )

    delta_args = pdiff_tui.delta_args_for_request(request)

    assert "--true-color=always" in delta_args
    assert "--hunk-header-style=file line-number syntax" in delta_args
    assert "--hunk-header-decoration-style=cyan ul" in delta_args
    assert "--side-by-side" in delta_args


def test_delta_args_use_high_contrast_tui_change_colors() -> None:
    request = pdiff_tui.DiffRequest(
        args=("git", "show", "--color=never", "a" * 40),
        side_by_side=False,
        width=120,
    )

    delta_args = pdiff_tui.delta_args_for_request(request)

    assert "--plus-style=syntax #124b25" in delta_args
    assert "--plus-emph-style=syntax bold #1f7a3a" in delta_args
    assert "--minus-style=syntax #5a1518" in delta_args
    assert "--minus-emph-style=syntax bold #8a2428" in delta_args
    assert "--line-numbers-plus-style=bold #4ade80" in delta_args
    assert "--line-numbers-minus-style=bold #ff6b6b" in delta_args


def test_diff_pane_uses_lighter_dark_surface_for_contrast() -> None:
    assert "background: #242a33;" in pdiff_tui.DiffpickApp.CSS
    assert "color: #f8f8f2;" in pdiff_tui.DiffpickApp.CSS


def test_help_text_is_non_wrapping_and_fits_dialog_width() -> None:
    help_text = pdiff_tui.HelpScreen.help_text()
    line_widths = [len(line) for line in help_text.plain.splitlines()]

    assert help_text.no_wrap is True
    assert max(line_widths) <= pdiff_tui.HelpScreen.CONTENT_WIDTH
    assert "text-wrap: nowrap;" in pdiff_tui.DiffpickApp.CSS


@pytest.mark.asyncio
async def test_diff_view_renders_large_output_by_visible_line() -> None:
    class DiffHarness(App):
        def compose(self) -> ComposeResult:
            yield pdiff_tui.DiffView(id="diff")

    app = DiffHarness()
    lines = tuple(Text(f"line {i:04d}") for i in range(2000))

    async with app.run_test(size=(80, 20)) as pilot:
        view = app.query_one("#diff", pdiff_tui.DiffView)
        view.set_lines(lines)
        view.scroll_to(y=1500, animate=False, immediate=True, force=True)
        await pilot.pause()

        assert view.virtual_size.height == 2000
        assert "line 1500" in view.render_line(0).text


@pytest.mark.asyncio
async def test_diff_scrollbar_drag_uses_smooth_absolute_scroll(
    monkeypatch: Any,
) -> None:
    class DiffHarness(App):
        def compose(self) -> ComposeResult:
            yield pdiff_tui.DiffView(id="diff")

    app = DiffHarness()
    lines = tuple(Text(f"line {i:04d}") for i in range(2000))

    async with app.run_test(size=(80, 20)) as pilot:
        view = app.query_one("#diff", pdiff_tui.DiffView)
        view.set_lines(lines)
        view.scroll_to(y=10, animate=False, immediate=True, force=True)
        await pilot.pause()

        calls: list[tuple[Any, Any, dict[str, Any]]] = []

        def record_scroll_to(x: Any = None, y: Any = None, **kwargs: Any) -> None:
            calls.append((x, y, kwargs))

        monkeypatch.setattr(view, "scroll_to", record_scroll_to)
        view._on_scroll_to(pdiff_tui.ScrollTo(y=110, animate=False))

    assert calls == [
        (
            None,
            110,
            {
                "animate": True,
                "duration": pdiff_tui.DIFF_SCROLL_MAX_DURATION,
                "easing": "linear",
            },
        )
    ]


def test_diff_scroll_actions_use_smooth_relative_scroll() -> None:
    app = HarnessApp()

    app.action_diff_down()
    app.action_diff_up()
    app.action_diff_half_down()
    app.action_diff_half_up()

    assert app.fake_scroll.smooth_scroll_calls == [1, -1, 20, -20]


def test_hunk_navigation_bindings_are_registered() -> None:
    keys = {binding.key for binding in pdiff_tui.DiffpickApp.BINDINGS}

    assert "f7" in keys
    assert "shift+f7" in keys
    assert "f19" in keys
    assert "o" in keys


def test_hunk_navigation_actions_delegate_to_diff_view() -> None:
    app = HarnessApp()

    app.action_next_hunk()
    app.action_previous_hunk()

    assert app.fake_scroll.jump_to_hunk_calls == [
        (1, False, False),
        (-1, False, False),
    ]


def test_hunk_navigation_actions_center_only_in_file_mode() -> None:
    app = HarnessApp()
    app.mode = "files"

    app.action_next_hunk()
    app.action_previous_hunk()

    assert app.fake_scroll.jump_to_hunk_calls == [
        (1, True, True),
        (-1, True, True),
    ]


def test_enter_on_zoomed_file_does_not_open_vscode(
    monkeypatch: Any,
) -> None:
    app = HarnessApp()
    app.mode = "files"
    app.fake_file_tree.selected = pdiff_tui.FileChange("M", "src/foo.py")

    def fail_popen(*_: Any, **__: Any) -> object:
        raise AssertionError("Enter should not open VS Code")

    monkeypatch.setattr(pdiff_tui.subprocess, "Popen", fail_popen)

    app.action_primary()

    assert app.fake_file_tree.toggle_calls == 1


def test_o_on_zoomed_file_opens_vscode_at_focused_hunk(
    monkeypatch: Any,
) -> None:
    monkeypatch.setenv("DIFFPICK_OPEN_CMD", "code -g {file}:{line}")
    app = HarnessApp()
    app.mode = "files"
    app.commits = [make_commit("a" * 40)]
    app.fake_file_tree.selected = pdiff_tui.FileChange("M", "src/foo.py")
    app.fake_scroll.focused_hunk_destination = 42

    popen_calls: list[tuple[list[str], dict[str, Any]]] = []

    def fake_run(args: list[str], **_: Any) -> str:
        assert args == ["git", "rev-parse", "--show-toplevel"]
        return "/repo\n"

    def fake_popen(args: list[str], **kwargs: Any) -> object:
        popen_calls.append((args, kwargs))
        return object()

    monkeypatch.setattr(pdiff_tui, "_run", fake_run)
    monkeypatch.setattr(pdiff_tui.subprocess, "Popen", fake_popen)

    app.action_open_in_vscode()

    argv = popen_calls[0][0]
    assert [a.replace("\\", "/") for a in argv] == ["code", "-g", "/repo/src/foo.py:42"]
    assert popen_calls[0][1]["stdout"] == pdiff_tui.subprocess.DEVNULL
    assert popen_calls[0][1]["stderr"] == pdiff_tui.subprocess.DEVNULL
    assert popen_calls[0][1]["start_new_session"] is True


def test_enter_on_zoomed_folder_still_toggles_without_opening(
    monkeypatch: Any,
) -> None:
    app = HarnessApp()
    app.mode = "files"
    app.fake_file_tree.toggle_result = True

    def fail_popen(*_: Any, **__: Any) -> object:
        raise AssertionError("folder toggle should not open VS Code")

    monkeypatch.setattr(pdiff_tui.subprocess, "Popen", fail_popen)

    app.action_primary()

    assert app.fake_file_tree.toggle_calls == 1


def test_o_on_zoomed_file_uses_remembered_f7_hunk_line(
    monkeypatch: Any,
) -> None:
    monkeypatch.setenv("DIFFPICK_OPEN_CMD", "code -g {file}:{line}")
    app = HarnessApp()
    app.mode = "files"
    app.commits = [make_commit("a" * 40)]
    app.fake_file_tree.selected = pdiff_tui.FileChange("M", "src/foo.py")
    request = app._file_diff_request()
    assert request is not None
    app._last_file_hunk_line = (
        "src/foo.py",
        request.args,
        request.fallback_args,
        88,
    )
    popen_calls: list[list[str]] = []

    def fake_run(args: list[str], **_: Any) -> str:
        assert args == ["git", "rev-parse", "--show-toplevel"]
        return "/repo\n"

    def fake_popen(args: list[str], **_: Any) -> object:
        popen_calls.append(args)
        return object()

    monkeypatch.setattr(pdiff_tui, "_run", fake_run)
    monkeypatch.setattr(pdiff_tui.subprocess, "Popen", fake_popen)

    app.action_open_in_vscode()

    assert [[a.replace("\\", "/") for a in c] for c in popen_calls] == [
        ["code", "-g", "/repo/src/foo.py:88"]
    ]


def test_o_on_commit_diff_opens_focused_hunk_file(
    monkeypatch: Any,
) -> None:
    monkeypatch.setenv("DIFFPICK_OPEN_CMD", "code -g {file}:{line}")
    app = HarnessApp()
    app.mode = "commits"
    app.commits = [make_commit("a" * 40)]
    app.fake_scroll.lines = (
        Text("src/foo.py:42: def changed():"),
        Text("│    │                                            │ 42 │changed"),
    )
    app.fake_scroll.focused_hunk_index = 0
    app.fake_scroll.focused_hunk_destination = 42
    popen_calls: list[list[str]] = []

    def fake_run(args: list[str], **_: Any) -> str:
        assert args == ["git", "rev-parse", "--show-toplevel"]
        return "/repo\n"

    def fake_popen(args: list[str], **_: Any) -> object:
        popen_calls.append(args)
        return object()

    monkeypatch.setattr(pdiff_tui, "_run", fake_run)
    monkeypatch.setattr(pdiff_tui.subprocess, "Popen", fake_popen)

    app.action_open_in_vscode()

    assert [[a.replace("\\", "/") for a in c] for c in popen_calls] == [
        ["code", "-g", "/repo/src/foo.py:42"]
    ]


def test_hunk_file_path_resolves_delta_and_raw_diff_headers() -> None:
    delta_lines = (
        Text("• src/foo.py:42: def changed():"),
        Text("│    │                                            │ 42 │changed"),
    )
    raw_lines = (
        Text("diff --git a/src/old.py b/src/new.py"),
        Text("--- a/src/old.py"),
        Text("+++ b/src/new.py"),
        Text("@@ -1,1 +1,1 @@"),
        Text("+changed"),
    )
    deleted_lines = (
        Text("diff --git a/src/deleted.py b/src/deleted.py"),
        Text("--- a/src/deleted.py"),
        Text("+++ /dev/null"),
        Text("@@ -1,1 +0,0 @@"),
        Text("-removed"),
    )

    assert pdiff_tui._file_path_for_hunk(delta_lines, 1) == "src/foo.py"
    assert pdiff_tui._file_path_for_hunk(raw_lines, 3) == "src/new.py"
    assert pdiff_tui._file_path_for_hunk(deleted_lines, 3) == "src/deleted.py"


def test_file_diff_request_uses_full_render_and_normal_hunk_context() -> None:
    app = HarnessApp()
    app.mode = "files"
    app.commits = [make_commit("a" * 40)]
    app.fake_file_tree.selected = pdiff_tui.FileChange("M", "src/foo.py")

    request = app._file_diff_request()

    assert request is not None
    assert f"-U{pdiff_tui.FULL_FILE_CONTEXT}" in request.args
    assert f"-U{pdiff_tui.HUNK_NAVIGATION_CONTEXT}" in request.hunk_args
    assert request.args[-2:] == ("--", "src/foo.py")
    assert request.hunk_args[-2:] == ("--", "src/foo.py")


def test_focused_revision_line_maps_to_current_worktree_line(
    monkeypatch: Any, tmp_path: Path
) -> None:
    app = HarnessApp()
    worktree_file = tmp_path / "src" / "foo.py"
    worktree_file.parent.mkdir()
    worktree_file.write_text("inserted\nabove\nalpha\nbeta\ngamma\n", encoding="utf-8")

    monkeypatch.setattr(app, "_selected_file_revision", lambda: "abc123")

    def fake_run(args: list[str], **_: Any) -> str:
        assert args == ["git", "show", "abc123:src/foo.py"]
        return "alpha\nbeta\ngamma\n"

    monkeypatch.setattr(pdiff_tui, "_run", fake_run)

    assert (
        app._map_revision_line_to_worktree("src/foo.py", str(worktree_file), 2) == 4
    )


def test_selected_file_line_uses_rendered_focus() -> None:
    app = HarnessApp()
    app.mode = "files"
    app.commits = [make_commit("a" * 40)]
    app.fake_file_tree.selected = pdiff_tui.FileChange("M", "src/foo.py")
    app.fake_scroll.focused_hunk_destination = 99

    assert app._selected_file_line_number() == 99


def test_hunk_navigation_remembers_focused_file_line() -> None:
    app = HarnessApp()
    app.mode = "files"
    app.commits = [make_commit("a" * 40)]
    app.fake_file_tree.selected = pdiff_tui.FileChange("M", "src/foo.py")
    app.fake_scroll.focused_hunk_destination = 88
    request = app._file_diff_request()
    assert request is not None

    app.action_next_hunk()

    assert app._last_file_hunk_line == (
        "src/foo.py",
        request.args,
        request.fallback_args,
        88,
    )
    assert app.fake_scroll.focused_prefer_changes is True


def test_open_command_can_be_logged_for_debugging(
    monkeypatch: Any, tmp_path: Path
) -> None:
    app = HarnessApp()
    log_path = tmp_path / "diffpick-open.log"

    monkeypatch.setenv("DIFFPICK_OPEN_LOG", str(log_path))

    app._log_open_command(["code", "--reuse-window", "--goto", "/repo/src/foo.py:4:1"])

    assert log_path.read_text(encoding="utf-8") == (
        "code --reuse-window --goto /repo/src/foo.py:4:1\n"
    )


@pytest.mark.asyncio
async def test_file_tree_click_selects_visible_file_and_refreshes_diff() -> None:
    class FileClickHarness(pdiff_tui.DiffpickApp):
        def __init__(self) -> None:
            super().__init__(paths=[], side_by_side=True)
            self.refreshes: list[bool] = []

        def on_mount(self) -> None:
            pass

        def _update_status(self) -> None:
            pass

        def refresh_diff(self, debounce: bool = True) -> None:
            self.refreshes.append(debounce)

    app = FileClickHarness()
    root = pdiff_tui.build_file_tree(
        [
            pdiff_tui.FileChange("M", f"file_{index:02d}.py")
            for index in range(30)
        ]
    )

    async with app.run_test(size=(100, 20)) as pilot:
        tree = app.file_tree
        app.mode = "files"
        app.listview.display = False
        tree.display = True
        tree.set_root(root)
        tree.scroll_to(y=10, animate=False, immediate=True, force=True)
        await pilot.pause()
        app.refreshes.clear()

        await pilot.click("#files", offset=(1, 2))
        await pilot.pause()

        selected = tree.selected_file()

    assert selected is not None
    assert selected.path == "file_12.py"
    assert app.refreshes == [True]


def test_hunk_indexing_handles_delta_and_raw_diff_headers() -> None:
    lines = (
        Text("foo.py"),
        Text("1: "),
        Text("src/foo.py:8: def rendered_by_delta_side_by_side():"),
        Text("  1 ⋮  1 │line1"),
        Text("@@ -10,3 +11,3 @@ def f():"),
        Text("+not a header"),
        Text("11: def f(): "),
        Text("@@@ -1,2 -1,2 +1,3 @@@"),
        Text(" 12: raw context line, not a hunk header"),
        Text('│    │                                                      │ 355│        Text("src/foo.py:8: not a header")'),
    )

    assert pdiff_tui._hunk_line_indexes(lines) == (1, 2, 4, 6, 7)


def test_hunk_indexing_handles_real_delta_side_by_side_headers() -> None:
    if shutil.which("delta") is None:
        pytest.skip("delta is not installed")

    raw_diff = "\n".join(
        [
            "diff --git a/foo.py b/foo.py",
            "index 1111111..2222222 100644",
            "--- a/foo.py",
            "+++ b/foo.py",
            "@@ -1,3 +1,4 @@",
            " line1",
            "-old",
            "+new",
            "+more",
            " line3",
            "@@ -10,3 +11,3 @@ def f():",
            " a",
            "-b",
            "+c",
            " d",
            "",
        ]
    )
    request = pdiff_tui.DiffRequest(
        args=("git", "diff"),
        side_by_side=True,
        width=100,
    )
    rendered = subprocess.run(
        pdiff_tui.delta_args_for_request(request),
        input=raw_diff,
        capture_output=True,
        text=True,
        check=True,
    ).stdout

    lines = tuple(pdiff_tui.AnsiDecoder().decode(rendered))

    assert pdiff_tui._hunk_line_indexes(lines) == (4, 12)


def test_hunk_indexing_uses_change_blocks_when_full_context_collapses_hunks() -> None:
    lines = (
        Text("test_pdiff_tui.py"),
        Text("test_pdiff_tui.py:1: "),
        Text("unchanged context"),
        Text("added import", style=Style(bgcolor="#124b25")),
        Text("unchanged context"),
        Text("deleted helper", style=Style(bgcolor="#5a1518")),
        Text("added helper", style=Style(bgcolor="#124b25")),
        Text("unchanged context"),
        Text("added test", style=Style(bgcolor="#124b25")),
    )

    assert pdiff_tui._hunk_line_indexes(lines) == (3, 5, 8)
    assert pdiff_tui._hunk_blocks(lines) == ((3, 3), (5, 6), (8, 8))


def test_raw_hunk_navigation_groups_rendered_change_runs_by_git_hunk() -> None:
    change = Style(bgcolor="#124b25")
    lines = (
        Text("foo.py:190: "),
        Text("│    │                                            │ 196│changed", style=change),
        Text("│    │                                            │ 197│changed", style=change),
        Text("unchanged blank/context row"),
        Text("│    │                                            │ 204│changed", style=change),
        Text("│    │                                            │ 205│changed", style=change),
        Text("unchanged context"),
        Text("│    │                                            │ 260│changed", style=change),
    )
    raw_diff = "\n".join(
        [
            "diff --git a/foo.py b/foo.py",
            "@@ -193,40 +193,40 @@",
            "+first hunk",
            "@@ -257,8 +257,8 @@",
            "+second hunk",
        ]
    )

    assert pdiff_tui._raw_hunk_navigation_blocks(lines, raw_diff) == (
        (1, 5),
        (7, 7),
    )


def test_hunk_indexing_uses_raw_change_blocks_without_delta() -> None:
    lines = (
        Text("--- a/test_pdiff_tui.py"),
        Text("+++ b/test_pdiff_tui.py"),
        Text("@@ -1,400 +1,450 @@"),
        Text(" unchanged"),
        Text("+added import"),
        Text(" unchanged"),
        Text("-old helper"),
        Text("+new helper"),
        Text(" unchanged"),
        Text("+added test"),
    )

    assert pdiff_tui._hunk_line_indexes(lines) == (4, 6, 9)


def test_delta_gutters_keep_context_rows_out_of_change_blocks() -> None:
    lines = (
        Text("test_pdiff_tui.py:361: "),
        Text(
            "│ 361│context                                     │ 361│context",
            style=Style(bgcolor="#124b25"),
        ),
        Text(
            "│    │                                            │ 388│changed",
            style=Style(bgcolor="#124b25"),
        ),
        Text(
            "  2 ⋮  2 │context",
            style=Style(bgcolor="#124b25"),
        ),
        Text("    ⋮  3 │changed", style=Style(bgcolor="#124b25")),
        Text(
            "│  4│old value                                   │  4│new value",
            style=Style(bgcolor="#124b25"),
        ),
    )

    assert pdiff_tui._hunk_blocks(lines, prefer_changes=True) == (
        (2, 2),
        (4, 5),
    )


def test_hunk_destination_line_reads_delta_header_and_gutter() -> None:
    lines = (
        Text("foo.py"),
        Text("foo.py:1: "),
        Text("│  1 │line1                                       │  1 │line1"),
        Text("│  2 │old                                         │    │"),
        Text("│    │                                            │  2 │new"),
    )

    assert pdiff_tui._destination_line_for_hunk(lines, 1) == 1
    assert pdiff_tui._destination_line_for_hunk(lines, 3) == 2


def test_hunk_destination_line_maps_raw_diff_rows() -> None:
    lines = (
        Text("--- a/foo.py"),
        Text("+++ b/foo.py"),
        Text("@@ -10,3 +20,3 @@"),
        Text(" context"),
        Text("-old"),
        Text("+new"),
        Text(" after"),
    )

    assert pdiff_tui._destination_line_for_hunk(lines, 4) == 21
    assert pdiff_tui._destination_line_for_hunk(lines, 5) == 21


@pytest.mark.asyncio
async def test_diff_view_jump_to_hunk_scrolls_between_hunks() -> None:
    class DiffHarness(App):
        def compose(self) -> ComposeResult:
            yield pdiff_tui.DiffView(id="diff")

    app = DiffHarness()
    lines = [Text(f"line {i}") for i in range(30)]
    lines[5] = Text("10: def first():")
    lines[18] = Text("25: def second():")

    async with app.run_test(size=(80, 10)) as pilot:
        view = app.query_one("#diff", pdiff_tui.DiffView)
        view.set_lines(tuple(lines))
        await pilot.pause()

        assert view.jump_to_hunk(+1) is True
        assert view.scroll_target_y == 5

        assert view.jump_to_hunk(+1) is True
        assert view.scroll_target_y == 18

        assert view.jump_to_hunk(-1) is True
        assert view.scroll_target_y == 5


@pytest.mark.asyncio
async def test_diff_view_centered_hunk_jump_keeps_context_and_advances() -> None:
    class DiffHarness(App):
        def compose(self) -> ComposeResult:
            yield pdiff_tui.DiffView(id="diff")

    app = DiffHarness()
    lines = [Text(f"line {i}") for i in range(50)]
    lines[12] = Text("12: first change")
    lines[28] = Text("28: second change")

    async with app.run_test(size=(80, 10)) as pilot:
        view = app.query_one("#diff", pdiff_tui.DiffView)
        view.set_lines(tuple(lines))
        await pilot.pause()

        assert view.jump_to_hunk(+1, center=True) is True
        assert view.scroll_target_y == 7

        assert view.jump_to_hunk(+1, center=True) is True
        assert view.scroll_target_y == 23

        assert view.jump_to_hunk(-1, center=True) is True
        assert view.scroll_target_y == 7


@pytest.mark.asyncio
async def test_diff_view_centered_hunk_jump_centers_change_block() -> None:
    class DiffHarness(App):
        def compose(self) -> ComposeResult:
            yield pdiff_tui.DiffView(id="diff")

    app = DiffHarness()
    lines = [Text(f"line {i}") for i in range(50)]
    for index in range(12, 21):
        lines[index] = Text(f"added line {index}", style=Style(bgcolor="#124b25"))
    lines[30] = Text("next change", style=Style(bgcolor="#124b25"))

    async with app.run_test(size=(80, 10)) as pilot:
        view = app.query_one("#diff", pdiff_tui.DiffView)
        view.set_lines(tuple(lines))
        await pilot.pause()

        assert view.jump_to_hunk(+1, center=True) is True
        assert view.scroll_target_y == 11

        assert view.jump_to_hunk(+1, center=True) is True
        assert view.scroll_target_y == 25


@pytest.mark.asyncio
async def test_diff_view_reports_focused_hunk_destination_line() -> None:
    class DiffHarness(App):
        def compose(self) -> ComposeResult:
            yield pdiff_tui.DiffView(id="diff")

    app = DiffHarness()
    lines = [Text(f"line {i}") for i in range(40)]
    lines[10] = Text(
        "│    │                                            │ 12 │added",
        style=Style(bgcolor="#124b25"),
    )
    lines[25] = Text(
        "│    │                                            │ 31 │later",
        style=Style(bgcolor="#124b25"),
    )

    async with app.run_test(size=(80, 10)) as pilot:
        view = app.query_one("#diff", pdiff_tui.DiffView)
        view.set_lines(tuple(lines))
        await pilot.pause()

        assert view.jump_to_hunk(+1, center=True) is True
        assert view.focused_hunk_destination_line() == 12

        assert view.jump_to_hunk(+1, center=True) is True
        assert view.focused_hunk_destination_line() == 31


@pytest.mark.asyncio
async def test_diff_view_file_mode_hunk_jump_prefers_change_blocks() -> None:
    class DiffHarness(App):
        def compose(self) -> ComposeResult:
            yield pdiff_tui.DiffView(id="diff")

    app = DiffHarness()
    lines = (
        Text("test.py:361: "),
        Text("│ 361│context                                     │ 361│context"),
        Text(
            "│    │                                            │ 388│changed",
            style=Style(bgcolor="#124b25"),
        ),
        Text("test.py:700: "),
        Text(
            "│    │                                            │ 720│changed",
            style=Style(bgcolor="#124b25"),
        ),
    )

    async with app.run_test(size=(80, 10)) as pilot:
        view = app.query_one("#diff", pdiff_tui.DiffView)
        view.set_lines(lines)
        await pilot.pause()

        assert view.jump_to_hunk(+1, center=True, prefer_changes=True) is True
        assert view.focused_hunk_destination_line(prefer_changes=True) == 388


@pytest.mark.asyncio
async def test_diff_view_keeps_explicit_hunk_focus_during_animation() -> None:
    class DiffHarness(App):
        def compose(self) -> ComposeResult:
            yield pdiff_tui.DiffView(id="diff")

    app = DiffHarness()
    lines = [Text(f"line {i}") for i in range(40)]
    lines[10] = Text(
        "│    │                                            │ 12 │added",
        style=Style(bgcolor="#124b25"),
    )
    lines[25] = Text(
        "│    │                                            │ 31 │later",
        style=Style(bgcolor="#124b25"),
    )

    async with app.run_test(size=(80, 10)) as pilot:
        view = app.query_one("#diff", pdiff_tui.DiffView)
        view.set_lines(tuple(lines))
        await pilot.pause()

        assert view.jump_to_hunk(+1, center=True) is True
        view.scroll_to(y=0, animate=False, immediate=True, force=True)
        await pilot.pause()

        assert view.focused_hunk_ordinal() == 0
        assert view.focused_hunk_destination_line() == 12


@pytest.mark.asyncio
async def test_diff_view_large_centered_hunk_jump_uses_top_margin() -> None:
    class DiffHarness(App):
        def compose(self) -> ComposeResult:
            yield pdiff_tui.DiffView(id="diff")

    app = DiffHarness()
    lines = [Text(f"line {i}") for i in range(80)]
    for index in range(20, 40):
        lines[index] = Text(f"added line {index}", style=Style(bgcolor="#124b25"))

    async with app.run_test(size=(80, 10)) as pilot:
        view = app.query_one("#diff", pdiff_tui.DiffView)
        view.set_lines(tuple(lines))
        await pilot.pause()

        assert view.jump_to_hunk(+1, center=True) is True
        assert view.scroll_target_y == 19


@pytest.mark.asyncio
async def test_diff_view_large_centered_hunk_jump_advances_from_hunk_focus() -> None:
    class DiffHarness(App):
        def compose(self) -> ComposeResult:
            yield pdiff_tui.DiffView(id="diff")

    app = DiffHarness()
    lines = [Text(f"line {i}") for i in range(90)]
    for index in range(20, 40):
        lines[index] = Text(f"added line {index}", style=Style(bgcolor="#124b25"))
    lines[60] = Text("next change", style=Style(bgcolor="#124b25"))

    async with app.run_test(size=(80, 10)) as pilot:
        view = app.query_one("#diff", pdiff_tui.DiffView)
        view.set_lines(tuple(lines))
        await pilot.pause()

        assert view.jump_to_hunk(+1, center=True) is True
        assert view.scroll_target_y == 19

        view.scroll_to(y=0, animate=False, immediate=True, force=True)
        await pilot.pause()

        assert view.jump_to_hunk(+1, center=True) is True
        assert view.scroll_target_y == 55


@pytest.mark.asyncio
async def test_diff_view_file_hunk_jump_uses_raw_navigation_blocks() -> None:
    class DiffHarness(App):
        def compose(self) -> ComposeResult:
            yield pdiff_tui.DiffView(id="diff")

    app = DiffHarness()
    lines = [Text(f"line {i}") for i in range(90)]
    for index in (20, 21, 24, 25, 60):
        lines[index] = Text(f"added line {index}", style=Style(bgcolor="#124b25"))

    async with app.run_test(size=(80, 10)) as pilot:
        view = app.query_one("#diff", pdiff_tui.DiffView)
        view.set_lines(tuple(lines), hunk_blocks=((20, 25), (60, 60)))
        await pilot.pause()

        assert pdiff_tui._hunk_blocks(view.lines, prefer_changes=True) == (
            (20, 21),
            (24, 25),
            (60, 60),
        )

        assert view.jump_to_hunk(+1, center=True, prefer_changes=True) is True
        assert view.focused_hunk_ordinal(prefer_changes=True) == 0

        assert view.jump_to_hunk(+1, center=True, prefer_changes=True) is True
        assert view.focused_hunk_ordinal(prefer_changes=True) == 1
        assert view.scroll_target_y == 55


@pytest.mark.asyncio
async def test_diff_view_manual_scroll_clears_hunk_focus() -> None:
    class DiffHarness(App):
        def compose(self) -> ComposeResult:
            yield pdiff_tui.DiffView(id="diff")

    app = DiffHarness()
    lines = [Text(f"line {i}") for i in range(90)]
    lines[20] = Text("first change", style=Style(bgcolor="#124b25"))
    lines[60] = Text("next change", style=Style(bgcolor="#124b25"))

    async with app.run_test(size=(80, 10)) as pilot:
        view = app.query_one("#diff", pdiff_tui.DiffView)
        view.set_lines(tuple(lines))
        await pilot.pause()

        assert view.jump_to_hunk(+1, center=True) is True
        assert view._last_hunk_target == 20

        view.smooth_scroll_relative(3)

        assert view._last_hunk_target is None


@pytest.mark.asyncio
async def test_diff_view_persistent_highlight_updates_on_scroll() -> None:
    """In file-zoom mode the hunk highlight tracks the scroll position."""

    class DiffHarness(App):
        def compose(self) -> ComposeResult:
            yield pdiff_tui.DiffView(id="diff")

    app = DiffHarness()
    lines = [Text(f"line {i}") for i in range(90)]
    lines[10] = Text("first change", style=Style(bgcolor="#124b25"))
    lines[40] = Text("second change", style=Style(bgcolor="#124b25"))
    lines[70] = Text("third change", style=Style(bgcolor="#124b25"))

    async with app.run_test(size=(80, 10)) as pilot:
        view = app.query_one("#diff", pdiff_tui.DiffView)
        view.persistent_hunk_highlight = True
        view.set_lines(tuple(lines))
        await pilot.pause()

        # After set_lines + sync, highlight should be set to the first hunk
        view.scroll_to(y=0, animate=False, immediate=True, force=True)
        view.sync_hunk_highlight()
        assert view._highlighted_hunk is not None
        assert view._highlighted_hunk[0] == 10
        assert view._last_hunk_target is None
        assert view._highlighted_hunk == view.focused_hunk_block()

        # Scrolling down should move the highlight to the nearest hunk
        view.smooth_scroll_relative(35)
        assert view._highlighted_hunk is not None
        assert view._highlighted_hunk[0] == 40
        assert view._last_hunk_target is None
        assert view._highlighted_hunk == view.focused_hunk_block()

        # Scrolling further down should move to the third hunk
        view.smooth_scroll_relative(35)
        assert view._highlighted_hunk is not None
        assert view._highlighted_hunk[0] == 70
        assert view._last_hunk_target is None
        assert view._highlighted_hunk == view.focused_hunk_block()


@pytest.mark.asyncio
async def test_file_mode_first_f7_after_passive_highlight_jumps_to_first_hunk() -> None:
    class DiffHarness(App):
        def compose(self) -> ComposeResult:
            yield pdiff_tui.DiffView(id="diff")

    app = DiffHarness()
    lines = [Text(f"line {i}") for i in range(90)]
    lines[60] = Text("only change", style=Style(bgcolor="#124b25"))

    async with app.run_test(size=(80, 10)) as pilot:
        view = app.query_one("#diff", pdiff_tui.DiffView)
        view.persistent_hunk_highlight = True
        view.set_lines(tuple(lines))
        await pilot.pause()

        view.scroll_to(y=0, animate=False, immediate=True, force=True)
        view.sync_hunk_highlight()

        assert view._highlighted_hunk == (60, 60)
        assert view._last_hunk_target is None
        assert view.jump_to_hunk(+1, center=True, prefer_changes=True) is True
        assert view._last_hunk_target == 60
        assert view.scroll_target_y == 55


@pytest.mark.asyncio
async def test_diff_view_persistent_highlight_matches_focused_hunk() -> None:
    """The persistent highlight always matches what 'o' would open."""

    class DiffHarness(App):
        def compose(self) -> ComposeResult:
            yield pdiff_tui.DiffView(id="diff")

    app = DiffHarness()
    lines = [Text(f"line {i}") for i in range(90)]
    lines[20] = Text("first change", style=Style(bgcolor="#124b25"))
    lines[60] = Text("second change", style=Style(bgcolor="#124b25"))

    async with app.run_test(size=(80, 10)) as pilot:
        view = app.query_one("#diff", pdiff_tui.DiffView)
        view.persistent_hunk_highlight = True
        view.set_lines(tuple(lines))
        await pilot.pause()

        # Jump to first hunk via F7
        assert view.jump_to_hunk(+1, center=True) is True
        assert view._highlighted_hunk is not None
        assert view._highlighted_hunk == view.focused_hunk_block()

        # Scroll away — highlight should update to match focused hunk
        view.smooth_scroll_relative(50)
        assert view._highlighted_hunk is not None
        assert view._highlighted_hunk == view.focused_hunk_block()


def test_diff_scroll_animation_is_short_and_linear() -> None:
    assert pdiff_tui._scroll_animation_kwargs(1) == {
        "animate": True,
        "duration": pdiff_tui.DIFF_SCROLL_MIN_DURATION,
        "easing": "linear",
    }
    page_scroll = pdiff_tui._scroll_animation_kwargs(100)
    assert page_scroll["duration"] == pdiff_tui.DIFF_SCROLL_MAX_DURATION


def test_range_visual_updates_only_rows_that_changed_state() -> None:
    app = HarnessApp()
    app.commits = [make_commit(str(i) * 40) for i in range(10)]
    app.fake_listview.children = [
        RecordingCommitItem(commit, i) for i, commit in enumerate(app.commits)
    ]

    app.range_anchor = 2
    app.fake_listview.index = 4
    app._update_range_visual()

    assert {
        item.idx: item.calls
        for item in app.fake_listview.children
        if isinstance(item, RecordingCommitItem) and item.calls
    } == {2: [True], 3: [True], 4: [True]}

    for item in app.fake_listview.children:
        item.calls.clear()

    app.fake_listview.index = 5
    app._update_range_visual()

    assert {
        item.idx: item.calls
        for item in app.fake_listview.children
        if isinstance(item, RecordingCommitItem) and item.calls
    } == {5: [True]}


def test_range_refresh_does_not_probe_git_before_debounce(
    monkeypatch: Any,
) -> None:
    def fail_on_rev_parse(args: list[str], **_: Any) -> bytes:
        if args[:3] == ["git", "rev-parse", "--verify"]:
            raise AssertionError("range selection should not probe git synchronously")
        raise subprocess.CalledProcessError(1, args)

    monkeypatch.setattr(pdiff_tui.subprocess, "check_output", fail_on_rev_parse)

    app = HarnessApp()
    newest = "a" * 40
    oldest = "b" * 40
    app.commits = [make_commit(newest), make_commit(oldest)]
    app.range_anchor = 0
    app.fake_listview.index = 1

    app.refresh_diff()

    assert app.started_work == []
    assert app._pending_diff_request is not None
    assert app._pending_diff_request.args[-1] == f"{oldest}^..{newest}"
    assert app._pending_diff_request.fallback_args[-1] == f"{oldest}..{newest}"


def test_range_visual_extend_does_not_materialize_full_selected_span(
    monkeypatch: Any,
) -> None:
    def fail_on_large_range(iterable: Any = ()) -> set[Any]:
        if isinstance(iterable, range) and len(iterable) > 10:
            raise AssertionError("range visual update materialized the full selection")
        return builtins.set(iterable)

    monkeypatch.setattr(pdiff_tui, "set", fail_on_large_range, raising=False)

    app = HarnessApp()
    app.commits = [make_commit(f"{i:040d}") for i in range(1000)]
    app.fake_listview.children = [
        RecordingCommitItem(commit, i) for i, commit in enumerate(app.commits)
    ]
    app.range_anchor = 100
    app._range_bounds = (100, 900)
    app.fake_listview.index = 901

    app._update_range_visual()

    assert {
        item.idx: item.calls
        for item in app.fake_listview.children
        if isinstance(item, RecordingCommitItem) and item.calls
    } == {901: [True]}


# ── prerequisite check tests ─────────────────────


def test_check_prerequisites_returns_none_when_all_present(monkeypatch):
    monkeypatch.setattr(
        "diffpick.tui.shutil.which",
        lambda binary: f"/usr/bin/{binary}",
    )
    assert pdiff_tui._check_prerequisites() is None


def test_check_prerequisites_reports_missing_git(monkeypatch):
    def which(binary):
        return None if binary == "git" else f"/usr/bin/{binary}"
    monkeypatch.setattr("diffpick.tui.shutil.which", which)
    msg = pdiff_tui._check_prerequisites()
    assert msg is not None
    assert "git" in msg.lower()


def test_check_prerequisites_reports_missing_delta(monkeypatch):
    def which(binary):
        return None if binary == "delta" else f"/usr/bin/{binary}"
    monkeypatch.setattr("diffpick.tui.shutil.which", which)
    msg = pdiff_tui._check_prerequisites()
    assert msg is not None
    assert "delta" in msg.lower()
    assert "git-delta" in msg or "delta" in msg
