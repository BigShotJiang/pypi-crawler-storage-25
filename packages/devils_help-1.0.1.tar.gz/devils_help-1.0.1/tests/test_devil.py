"""
tests/test_devil.py
~~~~~~~~~~~~~~~~~~~
pytest test suite for the devils-help package.

Run with:
    pytest -v tests/
"""

from __future__ import annotations

import os
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

import devil
from devil import AuthenticationError, Devil
from devil.exceptions import InputError, ModeError
from devil.utils import save_response, strip_fenced_code


# ─── Fixtures ────────────────────────────────────────────────────────────────


@pytest.fixture()
def authenticated_devil() -> Devil:
    """Return an authenticated Devil instance with Groq client mocked out."""
    with patch("groq.Groq") as mock_groq_cls:
        # Make the Groq constructor return a usable mock
        mock_client = MagicMock()
        mock_groq_cls.return_value = mock_client
        cn = devil.connect(pwd="devil123")
    return cn


# ─── Authentication tests ─────────────────────────────────────────────────────


class TestConnect:
    def test_correct_password_returns_devil(self) -> None:
        """connect() with the correct password must return a Devil instance."""
        with patch("groq.Groq"):
            result = devil.connect(pwd="devil123")
        assert isinstance(result, Devil)

    def test_wrong_password_raises_authentication_error(self) -> None:
        """connect() with any wrong password must raise AuthenticationError."""
        with pytest.raises(AuthenticationError):
            devil.connect(pwd="wrongpassword")

    def test_empty_password_raises_authentication_error(self) -> None:
        """An empty string is not the correct password."""
        with pytest.raises(AuthenticationError):
            devil.connect(pwd="")

    def test_case_sensitive_password(self) -> None:
        """Password check must be case-sensitive."""
        with pytest.raises(AuthenticationError):
            devil.connect(pwd="Devil123")  # capital D


# ─── Devil.ask() — input validation tests ────────────────────────────────────


class TestAskValidation:
    def test_no_text_no_image_raises_input_error(
        self, authenticated_devil: Devil
    ) -> None:
        """ask() with neither text nor image must raise InputError."""
        with pytest.raises(InputError):
            authenticated_devil.ask()

    def test_invalid_mode_raises_mode_error(
        self, authenticated_devil: Devil
    ) -> None:
        """ask() with an unrecognised mode string must raise ModeError."""
        with pytest.raises(ModeError):
            authenticated_devil.ask(text="hello", mode="invalid_mode")

    @pytest.mark.parametrize("mode", ["code", "explain", "both"])
    def test_valid_modes_accepted(
        self, authenticated_devil: Devil, mode: str
    ) -> None:
        """All three recognised modes must not raise ModeError."""
        with patch.object(
            authenticated_devil.solver,
            "solve",
            return_value="fake answer",
        ):
            result = authenticated_devil.ask(text="test problem", mode=mode)
        assert isinstance(result, str)


# ─── Devil.ask() — solver integration (mocked) ───────────────────────────────


class TestAskWithMockedSolver:
    def test_ask_returns_solver_response(
        self, authenticated_devil: Devil
    ) -> None:
        """ask() must return exactly what Solver.solve() returns."""
        expected = "print('hello world')"

        with patch.object(
            authenticated_devil.solver,
            "solve",
            return_value=expected,
        ) as mock_solve:
            result = authenticated_devil.ask(
                text="Print hello world", mode="code", lang="python"
            )

        mock_solve.assert_called_once()
        assert result == expected

    def test_ask_passes_correct_arguments_to_solver(
        self, authenticated_devil: Devil
    ) -> None:
        """ask() must forward text and image_path to Solver.solve()."""
        fake_response = "some answer"

        with patch.object(
            authenticated_devil.solver,
            "solve",
            return_value=fake_response,
        ) as mock_solve:
            authenticated_devil.ask(
                text="my problem",
                image=None,
                mode="explain",
            )

        call_kwargs = mock_solve.call_args
        # text should be forwarded
        assert call_kwargs.kwargs.get("text") == "my problem" or (
            len(call_kwargs.args) > 1 and call_kwargs.args[1] == "my problem"
        )

    def test_ask_with_save_creates_file(
        self, authenticated_devil: Devil, tmp_path: Path
    ) -> None:
        """ask() with save= must create the output file with the response."""
        fake_response = "saved content here"
        output_file = tmp_path / "output" / "solution.txt"

        with patch.object(
            authenticated_devil.solver,
            "solve",
            return_value=fake_response,
        ):
            authenticated_devil.ask(
                text="some problem",
                mode="both",
                save=str(output_file),
            )

        assert output_file.exists()
        assert output_file.read_text(encoding="utf-8") == fake_response

    def test_lang_appended_to_system_prompt(
        self, authenticated_devil: Devil
    ) -> None:
        """When lang is specified the system prompt must include the language."""
        captured: list[str] = []

        def capture_solve(system_prompt, **kwargs):
            captured.append(system_prompt)
            return "code here"

        with patch.object(
            authenticated_devil.solver, "solve", side_effect=capture_solve
        ):
            authenticated_devil.ask(text="problem", mode="code", lang="cpp")

        assert len(captured) == 1
        assert "cpp" in captured[0]

    def test_custom_prompt_appended(
        self, authenticated_devil: Devil
    ) -> None:
        """When prompt is given it must be appended to the system prompt."""
        captured: list[str] = []

        def capture_solve(system_prompt, **kwargs):
            captured.append(system_prompt)
            return "result"

        with patch.object(
            authenticated_devil.solver, "solve", side_effect=capture_solve
        ):
            authenticated_devil.ask(
                text="problem",
                mode="both",
                prompt="Optimize for O(n log n)",
            )

        assert "Optimize for O(n log n)" in captured[0]


# ─── Utility function tests ───────────────────────────────────────────────────


class TestSaveResponse:
    def test_creates_file_with_correct_content(
        self, tmp_path: Path
    ) -> None:
        """save_response() must write the exact content to the file."""
        dest = tmp_path / "deep" / "nested" / "output.txt"
        content = "Hello, Devil!\nLine two."

        returned_path = save_response(content, str(dest))

        assert dest.exists()
        assert dest.read_text(encoding="utf-8") == content
        assert returned_path == str(dest.resolve())

    def test_creates_missing_parent_directories(
        self, tmp_path: Path
    ) -> None:
        """save_response() must create all missing parent directories."""
        dest = tmp_path / "a" / "b" / "c" / "result.txt"
        save_response("data", str(dest))
        assert dest.exists()

    def test_returns_absolute_path(self, tmp_path: Path) -> None:
        """save_response() must return an absolute path string."""
        dest = tmp_path / "out.txt"
        returned = save_response("x", str(dest))
        assert os.path.isabs(returned)


class TestStripFencedCode:
    def test_strips_python_fenced_block(self) -> None:
        """strip_fenced_code() must extract code from ```python fences."""
        text = "```python\nprint('hello')\n```"
        assert strip_fenced_code(text) == "print('hello')"

    def test_strips_plain_fenced_block(self) -> None:
        """strip_fenced_code() must extract code from plain ``` fences."""
        text = "```\nx = 1\ny = 2\n```"
        assert strip_fenced_code(text) == "x = 1\ny = 2"

    def test_returns_original_when_no_fence(self) -> None:
        """Plain text without fences must be returned unchanged."""
        text = "x = 1\ny = 2"
        assert strip_fenced_code(text) == text

    def test_strips_cpp_fenced_block(self) -> None:
        """strip_fenced_code() must handle ```cpp fences."""
        text = "```cpp\nint main() { return 0; }\n```"
        assert strip_fenced_code(text) == "int main() { return 0; }"

    def test_multiline_code_preserved(self) -> None:
        """Multi-line code inside fences must be preserved exactly."""
        inner = "line1\nline2\nline3"
        text = f"```\n{inner}\n```"
        assert strip_fenced_code(text) == inner


# ─── Package-level metadata tests ────────────────────────────────────────────


class TestPackageMetadata:
    def test_version_attribute_exists(self) -> None:
        assert hasattr(devil, "__version__")
        assert devil.__version__ == "1.0.0"

    def test_connect_is_callable(self) -> None:
        assert callable(devil.connect)

    def test_authentication_error_importable(self) -> None:
        from devil import AuthenticationError as AE  # noqa: F401
