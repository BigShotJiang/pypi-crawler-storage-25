"""
devil.config
~~~~~~~~~~~~
Internal configuration for the devils-help package.

WARNING: Do NOT expose this file publicly with a real API key committed.
         Fill in GROQ_API_KEY before publishing. The end-user never sets this.
"""

# ── Groq API credentials ───────────────────────────────────────────────────────
# Replace with your real Groq API key before publishing.
# The end-user of this package NEVER needs to see or set this value.
GROQ_API_KEY: str = "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"

# Llama 4 Scout vision-capable model hosted on Groq
MODEL: str = "meta-llama/llama-4-scout-17b-16e-instruct"

# ── Access control ─────────────────────────────────────────────────────────────
# Password is stored ONLY as its SHA-256 hex digest — plaintext is never stored.
# This hash corresponds to the password: devil123
# Generate a new hash with: hashlib.sha256(b"your_password").hexdigest()
PASSWORD_HASH: str = (
    "05449566fb2666fafd717dc179d33111f62030a5c1e7a520d1289950bb9279da"
)
