"""
devil.core
~~~~~~~~~~
Main user-facing class for the devils-help package.

After authenticating via :func:`devil.connect`, the user interacts exclusively
with instances of :class:`Devil`.
"""

from __future__ import annotations

from devil.exceptions import InputError, ModeError
from devil.modes import DEFAULT_MODE, MODES, VALID_MODES
from devil.solver import Solver
from devil.utils import print_banner, print_divider, save_response


class Devil:
    """High-level AI assistant object.

    Do not instantiate directly — use :func:`devil.connect` instead.

    Example
    -------
    >>> import devil
    >>> cn = devil.connect(pwd="devil123")
    >>> cn.ask(text="Find the LIS of an array", mode="code", lang="python")
    """

    def __init__(self) -> None:
        """Initialise the Devil assistant.

        Prints the banner, sets up the Groq solver, and signals readiness.
        """
        print_banner()
        self.solver: Solver = Solver()
        print("[✓] Devil connected. Ready to solve.")

    # ── Public API ─────────────────────────────────────────────────────────────

    def ask(
        self,
        text: str | None = None,
        image: str | None = None,
        mode: str = DEFAULT_MODE,
        lang: str | None = None,
        prompt: str | None = None,
        save: str | None = None,
    ) -> str:
        """Submit a problem and receive the AI's response.

        Parameters
        ----------
        text:
            The problem description as a plain-text string.  Optional if
            *image* is provided; both can be supplied together.
        image:
            File path to a screenshot or image of the problem.  Optional if
            *text* is provided.
        mode:
            Response style — one of ``"code"``, ``"explain"``, ``"both"``
            (default: ``"both"``).
        lang:
            Target programming language, e.g. ``"python"``, ``"cpp"``,
            ``"java"``.  When given, the system prompt is extended with an
            explicit language instruction.
        prompt:
            Any additional custom instruction appended to the system prompt.
        save:
            Optional file path.  When given, the response is written to this
            file (parent directories are created automatically).

        Returns
        -------
        str
            The AI's response text.

        Raises
        ------
        ModeError
            If *mode* is not one of the recognised values.
        InputError
            If neither *text* nor *image* is provided.
        APIError
            If the Groq API call fails.
        """
        # ── 1. Validate mode ───────────────────────────────────────────────────
        if mode not in VALID_MODES:
            raise ModeError(
                f"Invalid mode '{mode}'. Valid modes: {VALID_MODES}."
            )

        # ── 2. Validate inputs ─────────────────────────────────────────────────
        if text is None and image is None:
            raise InputError(
                "You must provide at least one of 'text' or 'image'."
            )

        # ── 3. Build system prompt ─────────────────────────────────────────────
        system_prompt: str = MODES[mode]

        if lang:
            system_prompt += f"\nRespond with {lang} code only."

        if prompt:
            system_prompt += f"\nAdditional instruction: {prompt}"

        # ── 4. Status line ─────────────────────────────────────────────────────
        if text is not None and image is not None:
            input_label = "image+text"
        elif image is not None:
            input_label = "image"
        else:
            input_label = "text"

        print(
            f"[*] Mode: {mode.upper()} | "
            f"Lang: {lang or 'any'} | "
            f"Input: {input_label}"
        )

        # ── 5. Call the solver ─────────────────────────────────────────────────
        strip_code_flag = mode == "code"
        result: str = self.solver.solve(
            system_prompt=system_prompt,
            text=text,
            image_path=image,
            strip_code=strip_code_flag,
        )

        # ── 6. Print response ──────────────────────────────────────────────────
        print_divider()
        print(result)
        print_divider()

        # ── 7. Save if requested ───────────────────────────────────────────────
        if save is not None:
            abs_path = save_response(result, save)
            print(f"[✓] Response saved to: {abs_path}")

        return result
