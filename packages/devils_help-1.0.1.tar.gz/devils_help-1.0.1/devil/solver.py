"""
devil.solver
~~~~~~~~~~~~
Low-level Groq API wrapper.

The Solver class is responsible for building the API request payload and
returning the raw response text.  Higher-level logic (mode selection,
password checking, etc.) lives in core.py.
"""

from __future__ import annotations

from groq import Groq  # module-level import — required for test patching

from devil.config import GROQ_API_KEY, MODEL
from devil.exceptions import APIError, InputError
from devil.utils import encode_image, strip_fenced_code


class Solver:
    """Thin wrapper around the Groq chat-completions API.

    Usage
    -----
    >>> solver = Solver()
    >>> result = solver.solve(system_prompt="...", text="Two Sum problem")
    """

    def __init__(self) -> None:
        """Initialise the Groq client.

        Raises
        ------
        APIError
            If the Groq client cannot be created (e.g. invalid key format,
            missing dependency, network error during handshake).
        """
        try:
            self.client: Groq = Groq(api_key=GROQ_API_KEY)
            self.model: str = MODEL
        except Exception as exc:
            raise APIError(
                f"Failed to initialise Groq client: {exc}"
            ) from exc

    # ── Public API ─────────────────────────────────────────────────────────────

    def solve(
        self,
        system_prompt: str,
        text: str | None = None,
        image_path: str | None = None,
        strip_code: bool = False,
    ) -> str:
        """Send a request to the Groq API and return the model's response.

        Parameters
        ----------
        system_prompt:
            The instruction string that defines the model's behaviour.
        text:
            Optional problem description as plain text.
        image_path:
            Optional path to a screenshot / image of the problem.
        strip_code:
            If ``True``, the result is passed through
            :func:`~devil.utils.strip_fenced_code` before being returned.
            Set by the caller when ``mode == "code"``.

        Returns
        -------
        str
            The model's response text (stripped of leading/trailing whitespace).

        Raises
        ------
        InputError
            If both *text* and *image_path* are ``None``.
        APIError
            If the Groq API call raises any exception.
        """
        if text is None and image_path is None:
            raise InputError(
                "At least one of 'text' or 'image' must be provided."
            )

        # Build the user content list
        content: list[dict] = []

        if text is not None:
            content.append({"type": "text", "text": text})

        if image_path is not None:
            b64, mime = encode_image(image_path)
            content.append(
                {
                    "type": "image_url",
                    "image_url": {
                        "url": f"data:{mime};base64,{b64}"
                    },
                }
            )

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": content},
        ]

        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                max_tokens=3000,
                temperature=0.1,
            )
            result: str = response.choices[0].message.content.strip()
        except Exception as exc:
            raise APIError(
                f"Groq API call failed: {exc}"
            ) from exc

        if strip_code:
            result = strip_fenced_code(result)

        return result
