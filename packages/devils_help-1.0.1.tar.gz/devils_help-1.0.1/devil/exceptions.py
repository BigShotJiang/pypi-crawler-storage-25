"""
devil.exceptions
~~~~~~~~~~~~~~~~
Custom exception classes for the devils-help package.
All exceptions inherit from DevilBaseException for easy catching.
"""


class DevilBaseException(Exception):
    """Base class for all devils-help package errors."""

    def __init__(self, message: str = "An error occurred in devils-help."):
        self.message = message
        super().__init__(self.message)

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({self.message!r})"


class AuthenticationError(DevilBaseException):
    """Raised when an incorrect password is provided to devil.connect()."""

    def __init__(self, message: str = "Authentication failed. Wrong password."):
        super().__init__(message)


class InputError(DevilBaseException):
    """
    Raised when the user provides invalid or missing input.

    Scenarios:
    - Neither text nor image is provided to ask().
    - Image file path does not exist on disk.
    - Image file has an unsupported extension.
    """

    def __init__(self, message: str = "Invalid or missing input."):
        super().__init__(message)


class APIError(DevilBaseException):
    """
    Raised when communication with the Groq API fails.

    Scenarios:
    - Groq client fails to initialise (bad key, network issue, etc.).
    - API call returns an error or an unexpected response format.
    """

    def __init__(self, message: str = "Groq API request failed."):
        super().__init__(message)


class ModeError(DevilBaseException):
    """Raised when an invalid mode string is passed to ask()."""

    def __init__(self, message: str = "Invalid mode specified."):
        super().__init__(message)
