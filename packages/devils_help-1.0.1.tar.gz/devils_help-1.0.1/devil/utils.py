"""
devil.utils
~~~~~~~~~~~
Utility helpers used across the devils-help package.

Functions
---------
encode_image     — Base64-encode an image file and detect its MIME type.
save_response    — Persist a response string to a file on disk.
strip_fenced_code — Extract inner code from markdown fenced blocks.
print_banner     — Print the Devil's Help ASCII art banner.
print_divider    — Print a horizontal divider line.
"""

from __future__ import annotations

import base64
import os
import re
from pathlib import Path

from devil.exceptions import InputError

# ── MIME type map ──────────────────────────────────────────────────────────────

_MIME_MAP: dict[str, str] = {
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
}


# ── Public helpers ─────────────────────────────────────────────────────────────


def encode_image(image_path: str) -> tuple[str, str]:
    """Encode an image file to a base64 string and detect its MIME type.

    Parameters
    ----------
    image_path:
        Absolute or relative path to the image file.

    Returns
    -------
    tuple[str, str]
        A ``(base64_string, mime_type)`` pair, where ``base64_string`` is the
        raw base64-encoded content and ``mime_type`` is e.g. ``"image/png"``.

    Raises
    ------
    InputError
        If the file does not exist or has an unsupported extension.
    """
    path = Path(image_path)

    if not path.is_file():
        raise InputError(
            f"Image file not found: '{image_path}'. "
            "Please provide a valid file path."
        )

    ext = path.suffix.lower()
    mime_type = _MIME_MAP.get(ext)
    if mime_type is None:
        supported = ", ".join(_MIME_MAP.keys())
        raise InputError(
            f"Unsupported image extension '{ext}'. "
            f"Supported extensions: {supported}."
        )

    with open(path, "rb") as f:
        b64_string = base64.b64encode(f.read()).decode("utf-8")

    return b64_string, mime_type


def save_response(content: str, output_path: str) -> str:
    """Write *content* to *output_path*, creating parent directories if needed.

    Parameters
    ----------
    content:
        The text to save.
    output_path:
        Destination file path (relative or absolute).

    Returns
    -------
    str
        The resolved absolute path of the saved file.
    """
    dest = Path(output_path).resolve()
    dest.parent.mkdir(parents=True, exist_ok=True)

    with open(dest, "w", encoding="utf-8") as f:
        f.write(content)

    return str(dest)


def strip_fenced_code(text: str) -> str:
    """Extract the inner code from a markdown fenced code block.

    Handles both typed fences (e.g. ` ```python `) and plain fences
    (` ``` `). If no fenced block is found the original *text* is returned
    unchanged.

    Parameters
    ----------
    text:
        The raw text that may contain a fenced code block.

    Returns
    -------
    str
        The extracted code (stripped of leading/trailing whitespace), or the
        original text if no fenced block is detected.
    """
    # Match optional language tag after the opening fence
    pattern = re.compile(
        r"```(?:\w+)?\s*\n(.*?)```",
        re.DOTALL,
    )
    match = pattern.search(text)
    if match:
        return match.group(1).strip()
    return text


def print_banner() -> None:
    """Print the Devil's Help ASCII art banner to stdout."""
    banner = (
        "\n"
        "╔══════════════════════════════════╗\n"
        "║       🔥  DEVIL'S  HELP  🔥      ║\n"
        "║     Your Personal AI Devil       ║\n"
        "╚══════════════════════════════════╝\n"
    )
    print(banner)


def print_divider() -> None:
    """Print a horizontal divider line to stdout."""
    print("─" * 60)
