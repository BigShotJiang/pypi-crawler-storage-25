"""
devil
~~~~~
Password-locked personal AI assistant that solves coding problems
from plain text or screenshots using the Groq API (Llama 4 Scout).

Quick start
-----------
>>> import devil
>>> cn = devil.connect(pwd="devil123")
>>> cn.ask(text="Find the longest increasing subsequence", mode="code", lang="python")

The Groq API key is pre-configured inside the package.
Only a password is required to access the assistant.
"""

from __future__ import annotations

import hashlib

from devil.config import PASSWORD_HASH
from devil.core import Devil
from devil.exceptions import AuthenticationError

__version__: str = "1.0.0"
__all__ = ["connect", "Devil", "AuthenticationError", "__version__"]


def connect(pwd: str) -> Devil:
    """Authenticate and return a ready-to-use :class:`Devil` instance.

    Parameters
    ----------
    pwd:
        The access password as a plain-text string.  It is never stored —
        only its SHA-256 hash is compared against the stored hash.

    Returns
    -------
    Devil
        An authenticated :class:`Devil` assistant object.

    Raises
    ------
    AuthenticationError
        If the provided password does not match.

    Example
    -------
    >>> import devil
    >>> cn = devil.connect(pwd="devil123")
    >>> cn.ask(text="Reverse a linked list", mode="both", lang="python")
    """
    provided_hash = hashlib.sha256(pwd.encode("utf-8")).hexdigest()

    if provided_hash != PASSWORD_HASH:
        raise AuthenticationError("Wrong password. Access denied. 🔒")

    return Devil()
