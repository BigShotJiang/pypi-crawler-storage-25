"""
devil.modes
~~~~~~~~~~~
Defines the three solver modes and their system prompts.
Each mode drives a distinct AI behaviour when calling the Groq API.
"""

# ── System prompts ─────────────────────────────────────────────────────────────

_CODE_PROMPT: str = (
    "You are a competitive programming / software development code generator. "
    "Given a problem (via text or screenshot), output ONLY raw executable code. "
    "Absolutely NO explanations, NO comments, NO markdown, NO backticks. "
    "Raw runnable code only. Use standard I/O (input/print). "
    "Handle edge cases and multiple test cases if needed. "
    "If a specific language is requested, use only that language."
)

_EXPLAIN_PROMPT: str = (
    "You are a problem analysis expert. "
    "Given a problem (via text or screenshot), provide a clear structured explanation: "
    "problem summary, key observations, algorithm/approach, step-by-step logic, "
    "and time & space complexity analysis. "
    "Do NOT write any code whatsoever."
)

_BOTH_PROMPT: str = (
    "You are an expert problem solver. "
    "Given a problem (via text or screenshot), first provide a structured explanation "
    "(summary, observations, algorithm, complexity), then output the complete raw "
    "executable code below a clear separator line `--- CODE ---`. "
    "No markdown, no backticks in the code section. "
    "If a specific language is requested, write the code in that language."
)

# ── Modes registry ─────────────────────────────────────────────────────────────

MODES: dict[str, str] = {
    "code": _CODE_PROMPT,
    "explain": _EXPLAIN_PROMPT,
    "both": _BOTH_PROMPT,
}

VALID_MODES: list[str] = ["code", "explain", "both"]
DEFAULT_MODE: str = "both"
