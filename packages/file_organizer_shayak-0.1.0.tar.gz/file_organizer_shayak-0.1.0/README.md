###  Welcome to File Organizer

### A product of SHAYAK_ARROW

This program sorts and moves your files into different folders based on their file types.

 

* How to use

Step 1: Open terminal in the folder where the program is located and run it.

Step 2: You will see a menu with options.

Step 3: Choose option 1 to organize files.

Step 4: The program will show the current folder and ask for confirmation.

Step 5: Type “y” to start organizing.

 

* How it works

The program checks all files in the current folder.

It reads each file’s extension like .jpg, .pdf, .mp4.

It creates folders based on file types.

It moves files into the correct folders automatically.

---

* Example

Before:
photo.jpg
notes.pdf
video.mp4

After:
IMAGE FILES/photo.jpg
PDF FILES/notes.pdf
VIDEO FILES/video.mp4

---

* Important note

This program only works in the folder where you run it.

If you want to organize another folder, run the program inside that folder.
