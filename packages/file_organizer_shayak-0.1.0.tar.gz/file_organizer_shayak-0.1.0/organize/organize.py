import os 
import pathlib
import json
def organizer():
     filename=os.path.join(pathlib.Path.home(), '.lib_organizer_shayak.json')
     try:
        
          with open(filename, 'r') as f:     
               dictionary_for_organize=json.load(f)
     except:
           

     
          dictionary_for_organize={
               'txt':"TEXT FILES",
               'pdf':"PDF FILES",    
               'docx':"WORD FILES",
               'doc':"WORD FILES BEFORE 2007",
               'xlsx':"EXCEL FILES",
               'xls':"EXCEL FILES",
               'jpg':"IMAGE FILES",
               'png':"IMAGE FILES",
               'jpeg':"IMAGE FILES",
               'mp4':"VIDEO FILES",
               'mkv':"VIDEO FILES", 
               'zip':"COMPRESSED FILES",
               'rar':"COMPRESSED FILES",
               'py':"PYTHON FILES",
               'exe':"EXECUTABLE FILES",
               'pptx':"POWERPOINT FILES",
               'ppt':"POWERPOINT FILES BEFORE 2007",
               'csv':"CSV FILES",
               'html':"HTML RELATED FILES",
               'css':"HTML RELATED FILES",
               'js':"HTML RELATED FILES",
               'json':"JSON FILES",
               'xml':"XML FILES",
               'mp3':"AUDIO FILES",
               'wav':"AUDIO FILES",
               'accdb':"DATABASE FILES",
           
          
               }
          with open(filename, 'w') as f:
               json.dump(dictionary_for_organize, f)

     


     base_dir = os.getcwd()
     list_ = os.listdir(base_dir)
     print("Current folder:", base_dir)
     confirm = input("Are you sure? (y/n): ")
     if  confirm.lower() != "y":
              return
     for i in list_:
          if '.' not in i:
                continue
          full_path = os.path.join(base_dir, i)
          if os.path.isfile(full_path):
           
               if i!='Organizer_app.py' and i!='manual.txt' and i!='.lib_organizer_shayak.json':
                     extension=i.split('.')[-1].lower()
                     folder=dictionary_for_organize.get(extension)
                     if folder== None:
                          folder="Other"
                     folder_path = os.path.join(base_dir, folder)
                     path = os.path.join(folder_path, i)
               
                     try:
                               if not os.path.exists(folder_path):
                                 os.mkdir(folder_path)
  
                               os.rename(full_path, path)
                     except Exception as e :
                             print(f"Error organizing file {i}: {e}")
                             break
               
 
def read_manual():
    try:
        location = os.path.dirname(__file__)
        file_path = os.path.join(location, "README.md")
        with open(file_path, 'r') as file:
               manual_content = file.read()
               print(manual_content)
 
    except:
        print("Manual not found")
      
           
def add_extension( ):
     filename=os.path.join(pathlib.Path.home(), '.lib_organizer_shayak.json')
     with open(filename, 'r') as f:
          dictionary_for_organize=json.load(f)
     while True:
          extension=input("Enter extension to add (*enter exit):").replace('.',"")
          if extension.lower().replace('(','').replace(')','')=='exit':
               return  
          filetype=input ("Enter file type for this extension: ")
          dictionary_for_organize[extension]=filetype
          filename=os.path.join(pathlib.Path.home(), '.lib_organizer_shayak.json')
          with open(filename, 'w') as f:
               json.dump(dictionary_for_organize, f)
     

          





def main():
    print('''
          Welcome To File Organizer
             This program will help you to organize your files in a folder
          This program will move a file as per extension
           
          ''')


    while True:
          print("1.Organize Files\n  2.Add more extension \n 3.read Manual")
          
          try:
                   programchoice=int(input())
                    
                   match (programchoice):
                             case 1:
                               organizer()
                               print("Files Organized Successfully")
                               x=input("Press enter to exit")
                               exit()
                             case 2:
                                  add_extension( )
                                  print("Extension added successfully")
                             case 3:
                                     read_manual()
                             case _ :
                                   print("Invalid choice.  Please enter a valid input from menu.")
                   
                                       
                         
                    
                         
          except ValueError:
                   print("Invalid input. Please enter a number (1 or 2).")


if __name__=="__main__":   
     main()
