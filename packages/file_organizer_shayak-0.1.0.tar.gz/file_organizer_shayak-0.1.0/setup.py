from setuptools import setup, find_packages

setup(
    name="file-organizer-shayak",
    version="0.1.0",
    description="A simple file organizer tool",
    author="Shayak",
    packages=find_packages(),
    include_package_data=True,
    entry_points={
        "console_scripts": [
            "organize = organize.organize:main"
        ]
    },
    python_requires=">=3.7",
)