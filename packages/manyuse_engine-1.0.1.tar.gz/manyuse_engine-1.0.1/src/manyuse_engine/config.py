import os
from pathlib import Path
from dotenv import load_dotenv

# Try to load from engine's .env or backend's .env
backend_env = Path(__file__).parent.parent.parent / "manyuse-backend" / ".env"
load_dotenv(dotenv_path=backend_env)
load_dotenv() # Also load local .env if it exists

PORT = int(os.getenv("MANYUSE_PORT", "8899"))
TEMP_DIR = Path.home() / ".manyuse" / "temp"
ALLOWED_ORIGINS = ["https://manyuse.id", "http://localhost:3000"]
TEMP_DIR.mkdir(parents=True, exist_ok=True)
