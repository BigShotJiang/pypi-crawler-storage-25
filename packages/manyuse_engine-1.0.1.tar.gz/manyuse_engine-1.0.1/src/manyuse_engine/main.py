from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from manyuse_engine.routers import health, input as input_router, process as process_router, clips as clips_router, export as export_router
from manyuse_engine.config import ALLOWED_ORIGINS

app = FastAPI(title="ManyUse Engine", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["*"],
    expose_headers=["*"],
    max_age=3600,
)
app.include_router(health.router)
app.include_router(input_router.router)
app.include_router(process_router.router)
app.include_router(clips_router.router)
app.include_router(export_router.router)



