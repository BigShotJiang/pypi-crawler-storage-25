from dataclasses import dataclass, field
from typing import Optional
from enum import Enum

class JobStatus(Enum):
    PENDING = "pending"
    ANALYZING = "analyzing"
    CUTTING = "cutting"
    CAPTIONING = "captioning"
    DONE = "done"
    FAILED = "failed"
    CANCELLED = "cancelled"

@dataclass
class ProcessSettings:
    mode: str = "auto"
    clip_count: int = 3
    duration_sec: int = 60
    aspect_ratio: str = "9:16"
    caption_on: bool = True
    caption_font: str = "Arial"
    caption_size: int = 32
    caption_color: str = "white"
    caption_pos: str = "bottom"
    export_srt: bool = True
    export_vtt: bool = True
    scoring_audio: bool = True
    scoring_scene: bool = True
    scoring_transcript: bool = True

@dataclass
class ProcessingJob:
    job_id: str
    video_path: str
    settings: ProcessSettings
    status: JobStatus = JobStatus.PENDING
    progress: int = 0
    message: str = ""
    error: Optional[str] = None
    clips: list = field(default_factory=list)
