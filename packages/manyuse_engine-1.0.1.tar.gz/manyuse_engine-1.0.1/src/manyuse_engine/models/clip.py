from dataclasses import dataclass, field
from typing import Optional, List

@dataclass
class Clip:
    clip_id: str
    index: int
    path: str
    start_sec: float
    duration: int
    aspect_ratio: str
    width: int
    height: int
    score: float = 0.0
    text_preview: str = ""
    caption_text: str = ""
    srt_path: Optional[str] = None
    vtt_path: Optional[str] = None
    words: List[dict] = field(default_factory=list)
    captioned_path: Optional[str] = None
    ai_meta: dict = field(default_factory=dict)
