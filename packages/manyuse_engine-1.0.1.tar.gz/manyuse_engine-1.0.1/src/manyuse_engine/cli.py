import subprocess, sys

def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else "start"
    if cmd == "version" or cmd == "--version" or cmd == "-v":
        from manyuse_engine import __version__
        print(f"manyuse-engine v{__version__}")
        return
    if cmd == "start":
        print("Starting ManyUse Engine on http://localhost:8899")
        subprocess.run([sys.executable, "-m", "uvicorn",
            "manyuse_engine.main:app", "--host", "0.0.0.0",
            "--port", "8899", "--reload"])
    elif cmd == "stop":
        import psutil
        try:
            for conn in psutil.net_connections():
                if conn.laddr.port == 8899 and conn.pid:
                    try:
                        psutil.Process(conn.pid).terminate()
                        print("Engine stopped.")
                        return
                    except psutil.NoSuchProcess:
                        pass
        except Exception as e:
            print(f"Error stopping engine: {e}")
        print("Engine not running.")
    elif cmd == "status":
        import httpx
        try:
            r = httpx.get("http://localhost:8899/health", timeout=3)
            d = r.json()
            print("Online:", d["version"], "| FFmpeg:", d["ffmpeg"])
        except Exception:
            print("Offline")

if __name__ == "__main__":
    main()
