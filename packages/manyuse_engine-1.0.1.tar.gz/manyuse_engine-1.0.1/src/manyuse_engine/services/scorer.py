import asyncio, subprocess, json
import numpy as np
from pathlib import Path
from imageio_ffmpeg import get_ffmpeg_exe
from scenedetect import detect, AdaptiveDetector
from manyuse_engine.services.transcriber import transcribe_audio, analyze_transcript_with_llm

FFMPEG = get_ffmpeg_exe()

HOOK_WORDS = [
    "cara","tips","rahasia","penting","wajib","harus","jangan",
    "gratis","mudah","cepat","viral","terbukti","ikuti","ternyata",
    "fakta","tutorial","review","secret","trick","hack"
]

async def score_audio_energy(video_path: str, duration: float) -> list:
    cmd = [FFMPEG, "-i", video_path,
           "-af", "astats=metadata=1:reset=1,ametadata=print:key=lavfi.astats.Overall.RMS_level",
           "-f", "null", "-"]
    result = await asyncio.to_thread(subprocess.run, cmd, capture_output=True, text=True)
    rms_values = []
    for line in result.stderr.split("\n"):
        if "RMS_level" in line and "=" in line:
            try: 
                v = float(line.split("=")[1])
                if str(v).lower() in ("-inf", "inf", "nan"):
                    v = -100.0
                rms_values.append(v)
            except: pass
    if not rms_values: return []
    rms = np.array(rms_values)
    mn, mx = rms.min(), rms.max()
    norm = (rms - mn) / (mx - mn) if mx > mn else np.zeros_like(rms)
    segments, win = [], max(1, len(norm) // max(1, int(duration) // 10))
    for i in range(0, len(norm) - win, win // 2):
        t0 = i * (duration / len(norm))
        t1 = (i + win) * (duration / len(norm))
        segments.append({"start": round(t0,1), "end": round(t1,1),
                          "score": float(norm[i:i+win].mean())})
    return segments

async def score_scene_changes(video_path: str) -> list:
    def _detect():
        return detect(video_path, AdaptiveDetector(adaptive_threshold=3.0))
    scenes = await asyncio.to_thread(_detect)
    return [{"start": s[0].get_seconds(), "end": s[1].get_seconds(), "score": 0.7}
            for s in scenes]

async def score_transcript(video_path: str, temp_dir: str, duration: float) -> dict:
    audio_path = str(Path(temp_dir) / "audio.mp3")
    await asyncio.to_thread(subprocess.run, [FFMPEG, "-y", "-i", video_path,
        "-vn", "-acodec", "mp3", "-ar", "16000", audio_path], capture_output=True)
    transcript = await transcribe_audio(audio_path)
    
    # AI LLM Analysis
    full_text = transcript.get("text", "")
    llm_data = await analyze_transcript_with_llm(full_text, int(duration))
    llm_clips = llm_data.get("llm_clips", [])
    
    scored = []
    for seg in transcript.get("segments", []):
        text = seg.get("text","").lower()
        sc = 0.3 + min(sum(1 for w in HOOK_WORDS if w in text) * 0.1, 0.4)
        if text.strip().endswith((".!","!","?")): sc += 0.1
        if len(text.split()) >= 10: sc += 0.1
        
        # Boost based on LLM findings
        for lclip in llm_clips:
            qa = str(lclip.get("quote_awal", "")).lower()[:20]
            qk = str(lclip.get("quote_akhir", "")).lower()[-20:]
            if (qa and qa in text) or (qk and qk in text):
                sc += float(lclip.get("score", 0.9)) # Massive AI boost
                
        scored.append({"start": seg.get("start",0), "end": seg.get("end",0),
                        "text": seg.get("text",""), "score": round(min(sc,1.5),3)})
    return {"full_transcript": full_text, "llm_clips": llm_clips,
            "scored_segments": scored, "words": transcript.get("words",[])}

async def find_best_segments(video_path, temp_dir, duration,
                              clip_duration, clip_count, settings) -> tuple:
    tasks = []
    if settings.get("scoring_audio"):      tasks.append(score_audio_energy(video_path, duration))
    if settings.get("scoring_scene"):      tasks.append(score_scene_changes(video_path))
    if settings.get("scoring_transcript"): tasks.append(score_transcript(video_path, temp_dir, duration))
    results = await asyncio.gather(*tasks, return_exceptions=True)
    
    # Map results correctly based on what was enabled
    audio_segs = []
    scene_segs = []
    trans_data = {}
    
    idx = 0
    if settings.get("scoring_audio"):
        res = results[idx]
        if not isinstance(res, Exception): audio_segs = res
        else: print(f"Audio scoring error: {res}")
        idx += 1
        
    if settings.get("scoring_scene"):
        res = results[idx]
        if not isinstance(res, Exception): scene_segs = res
        else: print(f"Scene scoring error: {res}")
        idx += 1
        
    if settings.get("scoring_transcript"):
        res = results[idx]
        if not isinstance(res, Exception): trans_data = res
        else: print(f"Transcript scoring error: {res}")
        idx += 1

    trans_segs = trans_data.get("scored_segments",[]) if isinstance(trans_data,dict) else []
    words_data = trans_data.get("words",[]) if isinstance(trans_data,dict) else []
    full_trans = trans_data.get("full_transcript","") if isinstance(trans_data,dict) else ""
    llm_clips  = trans_data.get("llm_clips",[]) if isinstance(trans_data,dict) else []
    scored, step = [], 5
    for t in range(0, int(duration) - clip_duration, step):
        fs = 0.0
        if audio_segs:
            a = [s["score"] for s in audio_segs if s["start"]>=t and s["end"]<=t+clip_duration]
            fs += (sum(a)/len(a) if a else 0.3) * 0.3
        if scene_segs:
            sc = min(sum(1 for s in scene_segs if s["start"]>=t and s["end"]<=t+clip_duration)/3, 1.0)
            fs += sc * 0.3
        if trans_segs:
            ts = [s["score"] for s in trans_segs if s["start"]>=t and s["end"]<=t+clip_duration]
            fs += (sum(ts)/len(ts) if ts else 0.3) * 0.4
        wtext = " ".join(s["text"] for s in trans_segs if s["start"]>=t and s["end"]<=t+clip_duration)
        if np.isnan(fs) or np.isinf(fs): fs = 0.0
        
        # Inject AI LLM metadata if it falls within this window
        ai_meta = {}
        for lclip in llm_clips:
            qa = str(lclip.get("quote_awal", "")).lower()[:20]
            if qa and qa in wtext.lower():
                ai_meta = lclip
                fs += 1.0 # Guarantee selection
                break
                
        scored.append({"start":t,"end":t+clip_duration,"score":round(fs,3),
                        "text":wtext[:120], "ai_meta": ai_meta,
                        "words":[w for w in words_data if w.get("start",0)>=t and w.get("end",0)<=t+clip_duration]})
    scored.sort(key=lambda x: x["score"], reverse=True)
    selected, used = [], []
    for seg in scored:
        if not any(abs(seg["start"]-u) < clip_duration*0.7 for u in used):
            selected.append(seg)
            used.append(seg["start"])
        if len(selected) >= clip_count: break
    selected.sort(key=lambda x: x["start"])
    return selected, full_trans, words_data
