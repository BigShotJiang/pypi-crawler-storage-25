import json, subprocess, asyncio
from imageio_ffmpeg import get_ffmpeg_exe
from pathlib import Path

FFMPEG = get_ffmpeg_exe()
FFPROBE = "ffprobe"

async def probe_video(video_path: str) -> dict:
    cmd = [FFPROBE, "-v", "quiet", "-print_format", "json",
           "-show_streams", "-show_format", video_path]
    result = await asyncio.to_thread(subprocess.run, cmd, capture_output=True, text=True)
    data = json.loads(result.stdout)
    vs = next((s for s in data["streams"] if s["codec_type"]=="video"), {})
    duration = float(data["format"].get("duration", 0))
    size_mb = int(data["format"].get("size", 0)) / 1024 / 1024
    m, s = divmod(int(duration), 60)
    h, m = divmod(m, 60)
    dur_str = f"{h:02d}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"
    return {
        "duration_sec": round(duration, 2), "duration_str": dur_str,
        "width": vs.get("width", 0), "height": vs.get("height", 0),
        "fps": round(eval(vs.get("r_frame_rate", "0/1")), 2),
        "codec": vs.get("codec_name", "unknown"),
        "size_mb": round(size_mb, 1),
    }

async def extract_thumbnail(video_path: str, output_dir: str) -> str:
    thumb = str(Path(output_dir) / "thumbnail.jpg")
    await asyncio.to_thread(subprocess.run, [FFMPEG, "-y", "-i", video_path,
        "-vf", "thumbnail,scale=640:-1", "-frames:v", "1", thumb],
        capture_output=True)
    return thumb
