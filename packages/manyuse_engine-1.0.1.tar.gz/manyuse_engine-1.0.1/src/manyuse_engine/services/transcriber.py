import os, asyncio
from groq import Groq

_groq_token: str = ""

def set_groq_token(token: str):
    global _groq_token
    _groq_token = token

async def transcribe_audio(audio_path: str) -> dict:
    token = _groq_token or os.getenv("GROQ_API_KEY")
    if not token:
        raise ValueError("Groq token not set. Tolong masukkan GROQ_API_KEY di environment variable (.env).")
    def _transcribe():
        client = Groq(api_key=token)
        with open(audio_path, "rb") as f:
            return client.audio.transcriptions.create(
                file=f, model="whisper-large-v3",
                response_format="verbose_json",
                timestamp_granularities=["word", "segment"],
            )
    result = await asyncio.to_thread(_transcribe)
    return {"text": result.text,
            "words": [dict(w) for w in (result.words or [])],
            "segments": [dict(s) for s in (result.segments or [])]}

async def analyze_transcript_with_llm(transcript_text: str, duration: int) -> dict:
    """Menggunakan Llama-3 di Groq untuk analisa Hook, CTA, dan Virality."""
    token = _groq_token or os.getenv("GROQ_API_KEY")
    if not token or not transcript_text.strip(): return {}
    
    prompt = f"""
Kamu adalah pakar Social Media (TikTok/Reels). Analisa transkrip video berikut (Durasi: {duration}s).
Tugasmu adalah mencari 1 hingga 5 bagian momen (durasi 15-60 detik) yang paling berpotensi VIRAL.

Transkrip:
{transcript_text}

Balas HANYA dalam format JSON valid (array of objects) seperti contoh ini, tanpa teks tambahan:
[
  {{
    "quote_awal": "kata kata pembuka dari klip",
    "quote_akhir": "kata kata penutup dari klip",
    "score": 0.95,
    "hook": "Kalimat pancingan utama di awal klip",
    "cta": "Ajakan bertindak jika ada (atau null)",
    "reason": "Kenapa bagian ini viral"
  }}
]
"""
    def _analyze():
        client = Groq(api_key=token)
        res = client.chat.completions.create(
            model="llama-3.1-8b-instant",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3,
            response_format={"type": "json_object"} if False else None # Optional JSON mode
        )
        return res.choices[0].message.content

    try:
        content = await asyncio.to_thread(_analyze)
        import json
        # Bersihkan markdown json jika ada
        content = content.replace("```json", "").replace("```", "").strip()
        data = json.loads(content)
        return {"llm_clips": data if isinstance(data, list) else data.get("clips", [])}
    except Exception as e:
        print(f"LLM Analysis error: {e}")
        return {}
