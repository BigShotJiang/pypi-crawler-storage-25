import subprocess, uuid, json, asyncio
from pathlib import Path
from imageio_ffmpeg import get_ffmpeg_exe
from manyuse_engine.models.clip import Clip

FFMPEG = get_ffmpeg_exe()
FFPROBE = "ffprobe"

RATIO_MAP = {
    "9:16": (1080,1920), "16:9": (1920,1080),
    "1:1":  (1080,1080), "4:5":  (1080,1350),
}

def build_scale_filter(ratio, src_w, src_h):
    tw, th = RATIO_MAP.get(ratio,(1080,1920))
    if src_w/src_h > tw/th:
        sw = int(src_w * th / src_h)
        return f"scale={sw}:{th},crop={tw}:{th}:(iw-{tw})/2:0"
    else:
        sw = tw; sh = int(src_h * tw / src_w); py = (th-sh)//2
        return f"scale={sw}:{sh},pad={tw}:{th}:0:{py}:black"

async def cut_clip(video_path, start_sec, duration, ratio, output_dir, clip_index):
    clip_id = str(uuid.uuid4())[:8]
    out = str(Path(output_dir) / f"clip_{clip_index:02d}_{clip_id}.mp4")
    probe = await asyncio.to_thread(subprocess.run, [FFPROBE,"-v","quiet","-print_format","json",
        "-show_streams",video_path], capture_output=True, text=True)
    data = json.loads(probe.stdout)
    vs = next((s for s in data["streams"] if s["codec_type"]=="video"),{})
    sf = build_scale_filter(ratio, vs.get("width",1920), vs.get("height",1080))
    tw, th = RATIO_MAP.get(ratio,(1080,1920))
    await asyncio.to_thread(subprocess.run, [
        FFMPEG, "-y", "-ss", str(start_sec), "-i", video_path,
        "-t", str(duration), "-vf", sf,
        "-af", "loudnorm=I=-14:LRA=11:TP=-1.5",
        "-c:v","libx264","-crf","23","-preset","fast",
        "-c:a","aac","-b:a","128k","-movflags","+faststart", out
    ], capture_output=True, check=True)
    return Clip(clip_id=clip_id, index=clip_index, path=out,
                start_sec=start_sec, duration=duration,
                aspect_ratio=ratio, width=tw, height=th)
