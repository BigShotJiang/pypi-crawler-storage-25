import subprocess
import textwrap
from pathlib import Path
from imageio_ffmpeg import get_ffmpeg_exe

FFMPEG = get_ffmpeg_exe()

def escape_text(t):
    return t.replace("%", "\\%").replace(":", "\\:").replace("'", "\\'").replace(",", "\\,")

async def burn_caption(video_path, output_path, caption_text,
                        font_size=56, color="yellow", position="bottom"):
    ymap = {"top": "h*0.1", "center": "(h-text_h)/2", "bottom": "h*0.75"}
    y = ymap.get(position, "h*0.75")
    
    # Wrap text to ~25 characters per line so it fits on vertical screens
    wrapped_text = textwrap.fill(caption_text[:150], width=25)
    txt = escape_text(wrapped_text)
    
    # Use line_spacing and fix alignment for multiline
    vf = (f"drawtext=text='{txt}':fontsize={font_size}:"
          f"fontcolor={color}:borderw=3:bordercolor=black:"
          f"x=(w-text_w)/2:y={y}:line_spacing=10:text_align=M")
    
    import asyncio
    await asyncio.to_thread(subprocess.run, [FFMPEG, "-y", "-i", video_path, "-vf", vf,
        "-c:v", "libx264", "-crf", "23", "-preset", "fast", "-c:a", "copy",
        output_path], capture_output=True, check=True)
    return output_path

def _fmt_srt(sec):
    h=int(sec//3600); m=int((sec%3600)//60); s=int(sec%60); ms=int((sec-int(sec))*1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

def generate_srt(words, output_path, chunk=5):
    lines, idx = [], 1
    for i in range(0,len(words),chunk):
        c = words[i:i+chunk]
        if not c: continue
        lines.append(f"{idx}\n{_fmt_srt(c[0].get('start',0))} --> {_fmt_srt(c[-1].get('end',0))}\n{' '.join(w.get('word','') for w in c)}\n")
        idx += 1
    Path(output_path).write_text("\n".join(lines), encoding="utf-8")
    return output_path

def generate_vtt(words, output_path, chunk=5):
    lines = ["WEBVTT\n"]
    for i in range(0,len(words),chunk):
        c = words[i:i+chunk]
        if not c: continue
        lines.append(f"{_fmt_srt(c[0].get('start',0)).replace(',','.')} --> {_fmt_srt(c[-1].get('end',0)).replace(',','.')}\n{' '.join(w.get('word','') for w in c)}\n")
    Path(output_path).write_text("\n".join(lines), encoding="utf-8")
    return output_path
