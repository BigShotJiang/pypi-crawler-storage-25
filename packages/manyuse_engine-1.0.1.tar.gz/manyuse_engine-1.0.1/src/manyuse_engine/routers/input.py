import uuid, aiofiles
from fastapi import APIRouter, UploadFile, File, HTTPException
from pathlib import Path
from manyuse_engine.config import TEMP_DIR
from manyuse_engine.services.downloader import download_url
from manyuse_engine.services.probe import probe_video, extract_thumbnail

router = APIRouter(prefix="/input", tags=["input"])

@router.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    allowed = [".mp4",".mov",".avi",".mkv",".webm"]
    ext = Path(file.filename).suffix.lower()
    if ext not in allowed:
        raise HTTPException(400, f"File type {ext} not supported")
    job_id = str(uuid.uuid4())
    job_dir = TEMP_DIR / job_id
    job_dir.mkdir(parents=True, exist_ok=True)
    video_path = str(job_dir / f"source{ext}")
    async with aiofiles.open(video_path, "wb") as f:
        await f.write(await file.read())
    info = await probe_video(video_path)
    thumb = await extract_thumbnail(video_path, str(job_dir))
    return {"job_id": job_id, "video_path": video_path, "thumbnail": thumb, **info}

@router.post("/url")
async def input_from_url(body: dict):
    url = body.get("url")
    if not url: raise HTTPException(400, "url required")
    job_id = str(uuid.uuid4())
    try:
        video_path = await download_url(url, job_id)
    except Exception as e:
        raise HTTPException(400, f"Download failed: {e}")
    info = await probe_video(video_path)
    thumb = await extract_thumbnail(video_path, str(TEMP_DIR / job_id))
    return {"job_id": job_id, "video_path": video_path, "thumbnail": thumb, **info}
