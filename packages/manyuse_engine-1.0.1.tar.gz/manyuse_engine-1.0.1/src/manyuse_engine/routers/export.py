import zipfile, uuid, subprocess, shutil
from pathlib import Path
from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse
from manyuse_engine.routers.process import _jobs
from imageio_ffmpeg import get_ffmpeg_exe

router = APIRouter(prefix="/export", tags=["export"])
FFMPEG = get_ffmpeg_exe()
_exports: dict = {}

RES_MAP = {
    "9:16": {"1080p":"1080:1920","720p":"720:1280"},
    "16:9": {"1080p":"1920:1080","720p":"1280:720"},
    "1:1":  {"1080p":"1080:1080","720p":"720:720"},
    "4:5":  {"1080p":"1080:1350","720p":"720:900"},
}

@router.post("")
async def create_export(body: dict):
    pid         = body.get("process_id")
    clip_ids    = body.get("clip_ids", [])
    fmt         = body.get("format", "1080p")
    burned      = body.get("burned_caption", True)
    inc_srt     = body.get("include_srt", True)
    inc_vtt     = body.get("include_vtt", False)
    job = _jobs.get(pid)
    if not job: raise HTTPException(404, "Process not found")
    clips = [c for c in job.clips if not clip_ids or c.clip_id in clip_ids]
    if not clips: raise HTTPException(400, "No clips")
    eid = str(uuid.uuid4())
    exp_dir = Path(job.video_path).parent / "export" / eid
    exp_dir.mkdir(parents=True, exist_ok=True)
    files = []
    for clip in clips:
        src = clip.captioned_path if (burned and clip.captioned_path) else clip.path
        res = RES_MAP.get(clip.aspect_ratio,{}).get(fmt,"1080:1920")
        out_name = f"clip_{clip.index:02d}_score{int(clip.score*100)}.mp4"
        out_path = str(exp_dir / out_name)
        subprocess.run([FFMPEG,"-y","-i",src,"-vf",f"scale={res}",
            "-c:v","libx264","-crf","22","-preset","medium",
            "-c:a","aac","-b:a","192k","-movflags","+faststart",out_path],
            capture_output=True)
        entry = {"clip_id":clip.clip_id,"path":out_path,"name":out_name}
        if inc_srt and clip.srt_path and Path(clip.srt_path).exists():
            sd = str(exp_dir/out_name.replace(".mp4",".srt"))
            shutil.copy2(clip.srt_path,sd); entry["srt"] = sd
        if inc_vtt and clip.vtt_path and Path(clip.vtt_path).exists():
            vd = str(exp_dir/out_name.replace(".mp4",".vtt"))
            shutil.copy2(clip.vtt_path,vd); entry["vtt"] = vd
        files.append(entry)
    zip_path = str(exp_dir/"manyuse_clips.zip")
    with zipfile.ZipFile(zip_path,"w",zipfile.ZIP_DEFLATED) as zf:
        for ef in files:
            zf.write(ef["path"],Path(ef["path"]).name)
            if ef.get("srt"): zf.write(ef["srt"],Path(ef["srt"]).name)
            if ef.get("vtt"): zf.write(ef["vtt"],Path(ef["vtt"]).name)
    _exports[eid] = {"files":files,"zip":zip_path}
    return {"export_id":eid,"clip_count":len(files)}

@router.get("/{eid}/download/{clip_id}")
async def dl_clip(eid:str, clip_id:str):
    exp = _exports.get(eid)
    if not exp: raise HTTPException(404)
    ef = next((f for f in exp["files"] if f["clip_id"]==clip_id), None)
    if not ef: raise HTTPException(404)
    return FileResponse(ef["path"],media_type="video/mp4",filename=ef["name"])

@router.get("/{eid}/zip")
async def dl_zip(eid:str):
    exp = _exports.get(eid)
    if not exp: raise HTTPException(404)
    return FileResponse(exp["zip"],media_type="application/zip",filename="manyuse_clips.zip")
