import asyncio, uuid
from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from manyuse_engine.models.job import ProcessingJob, JobStatus, ProcessSettings
from manyuse_engine.config import TEMP_DIR
from manyuse_engine.services.probe import probe_video
from manyuse_engine.services.scorer import find_best_segments
from manyuse_engine.services.cutter import cut_clip
from manyuse_engine.services.caption import burn_caption, generate_srt, generate_vtt
from pathlib import Path

router = APIRouter(prefix="/process", tags=["process"])
_jobs: dict = {}   # process_id -> ProcessingJob
_ws:   dict = {}   # process_id -> WebSocket

@router.post("/start")
async def start_processing(body: dict):
    job_id   = body.get("job_id")
    settings = ProcessSettings(**body.get("settings", {}))
    video_path = str(next((TEMP_DIR / job_id).glob("source.*")))
    pid = str(uuid.uuid4())
    job = ProcessingJob(job_id=job_id, video_path=video_path, settings=settings)
    _jobs[pid] = job
    asyncio.create_task(run_pipeline(pid, job))
    return {"process_id": pid}

@router.websocket("/progress/{pid}")
async def ws_progress(ws: WebSocket, pid: str):
    await ws.accept()
    _ws[pid] = ws
    job = _jobs.get(pid)
    if job:
        try:
            await ws.send_json({"status":"processing", "step": "CONNECT", "progress": getattr(job, 'progress', 0), "message": getattr(job, 'message', "Terhubung ke engine...")})
            print(f"Sent CONNECT to {pid}")
        except Exception as e:
            print(f"WS CONNECT SEND ERROR: {e}")
    try:
        while True:
            await asyncio.sleep(0.5)
            job = _jobs.get(pid)
            if not job: break
            if job.status in (JobStatus.DONE, JobStatus.FAILED, JobStatus.CANCELLED):
                await ws.send_json({"status": job.status.value, "progress": 100,
                    "message": job.message, "clips": [clip_dict(c) for c in job.clips],
                    "error": job.error})
                break
    except WebSocketDisconnect: pass
    finally: _ws.pop(pid, None)

async def send_prog(pid, step, pct, msg):
    job = _jobs.get(pid)
    if job: job.progress = pct; job.message = msg
    w = _ws.get(pid)
    if w:
        try: await w.send_json({"status":"processing","step":step,"progress":pct,"message":msg})
        except: pass

async def run_pipeline(pid, job):
    s = job.settings
    clips_dir = str(TEMP_DIR / job.job_id / "clips")
    Path(clips_dir).mkdir(exist_ok=True, parents=True)
    await asyncio.sleep(1.0) # Beri waktu agar frontend berhasil connect WebSocket
    try:
        await send_prog(pid,"PROBE",5,"Membaca informasi video...")
        info = await probe_video(job.video_path)
        duration = info["duration_sec"]
        await send_prog(pid,"ANALYZING",15,"Menganalisis audio, scene, dan transkrip...")
        segments, full_trans, words = await find_best_segments(
            video_path=job.video_path, temp_dir=str(TEMP_DIR/job.job_id),
            duration=duration, clip_duration=s.duration_sec, clip_count=s.clip_count,
            settings={"scoring_audio":s.scoring_audio,"scoring_scene":s.scoring_scene,
                      "scoring_transcript":s.scoring_transcript})
        clips = []
        for i, seg in enumerate(segments):
            await send_prog(pid,"CUTTING",50+int(i/len(segments)*20),f"Memotong klip {i+1}...")
            clip = await cut_clip(job.video_path, seg["start"], s.duration_sec,
                                   s.aspect_ratio, clips_dir, i+1)
            clip.score = seg["score"]; clip.text_preview = seg.get("text","")[:100]
            clip.caption_text = seg.get("text","")[:100]; clip.words = seg.get("words",[])
            clip.ai_meta = seg.get("ai_meta", {})
            clips.append(clip)
        for i, clip in enumerate(clips):
            await send_prog(pid,"CAPTIONING",75+int(i/len(clips)*20),f"Caption klip {i+1}...")
            if s.caption_on and clip.caption_text:
                cp_path = clip.path.replace(".mp4","_captioned.mp4")
                await burn_caption(clip.path, cp_path, clip.caption_text,
                    s.caption_size, s.caption_color, s.caption_pos)
                clip.captioned_path = cp_path
            if clip.words:
                if s.export_srt:
                    clip.srt_path = generate_srt(clip.words, clip.path.replace(".mp4",".srt"))
                if s.export_vtt:
                    clip.vtt_path = generate_vtt(clip.words, clip.path.replace(".mp4",".vtt"))
        job.clips = clips; job.status = JobStatus.DONE
        await send_prog(pid,"DONE",100,f"{len(clips)} klip berhasil dibuat")
    except Exception as e:
        job.status = JobStatus.FAILED; job.error = str(e)
        await send_prog(pid,"FAILED",job.progress,f"Error: {e}")

def clip_dict(c):
    return {"clip_id":c.clip_id,"index":c.index,"path":c.path,
            "captioned_path":c.captioned_path,"start_sec":c.start_sec,
            "duration":c.duration,"aspect_ratio":c.aspect_ratio,
            "score":c.score,"text_preview":c.text_preview,
            "caption_text":c.caption_text,"srt_path":c.srt_path,"vtt_path":c.vtt_path,
            "ai_meta": getattr(c, "ai_meta", {})}
