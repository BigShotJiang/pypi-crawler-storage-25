import platform, psutil, subprocess, httpx
from fastapi import APIRouter
from imageio_ffmpeg import get_ffmpeg_exe
import yt_dlp
from manyuse_engine import __version__

router = APIRouter(tags=["health"])

@router.get("/health")
async def health_check():
    ffmpeg = get_ffmpeg_exe()
    try:
        result = subprocess.run([ffmpeg, "-version"], capture_output=True, text=True)
        ffmpeg_ver = result.stdout.split("\n")[0].split(" ")[2]
    except Exception:
        ffmpeg_ver = "unknown"

    latest_version = None
    try:
        async with httpx.AsyncClient() as client:
            r = await client.get(
                "https://pypi.org/pypi/manyuse-engine/json",
                timeout=3.0
            )
            if r.status_code == 200:
                latest_version = r.json()["info"]["version"]
    except Exception:
        pass

    return {
        "status": "ok",
        "version": __version__,
        "latest_version": latest_version,
        "update_available": (
            latest_version is not None and
            latest_version != __version__
        ),
        "ffmpeg": ffmpeg_ver,
        "ytdlp": yt_dlp.version.__version__,
        "platform": platform.system(),
        "cpu_cores": psutil.cpu_count(logical=True),
        "ram_gb": round(psutil.virtual_memory().total / 1024**3, 1),
        "ram_free_gb": round(psutil.virtual_memory().available / 1024**3, 1),
    }
