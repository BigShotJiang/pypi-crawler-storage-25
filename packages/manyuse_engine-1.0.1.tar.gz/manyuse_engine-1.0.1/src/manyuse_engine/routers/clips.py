from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse
from pathlib import Path
from manyuse_engine.routers.process import _jobs, clip_dict
from manyuse_engine.services.cutter import cut_clip
from manyuse_engine.services.caption import burn_caption, generate_srt, generate_vtt

router = APIRouter(prefix="/clips", tags=["clips"])

@router.get("/{pid}")
async def get_clips(pid: str):
    job = _jobs.get(pid)
    if not job: raise HTTPException(404, "Process not found")
    return {"status": job.status.value, "clips": [clip_dict(c) for c in job.clips]}

@router.get("/{pid}/{clip_id}/stream")
async def stream_clip(pid: str, clip_id: str):
    job = _jobs.get(pid)
    if not job: raise HTTPException(404)
    clip = next((c for c in job.clips if c.clip_id == clip_id), None)
    if not clip: raise HTTPException(404)
    vpath = clip.captioned_path or clip.path
    if not Path(vpath).exists(): raise HTTPException(404)
    return FileResponse(vpath, media_type="video/mp4",
                        headers={"Accept-Ranges":"bytes"})

@router.patch("/{pid}/{clip_id}")
async def edit_clip(pid: str, clip_id: str, body: dict):
    job = _jobs.get(pid)
    if not job: raise HTTPException(404)
    clip = next((c for c in job.clips if c.clip_id == clip_id), None)
    if not clip: raise HTTPException(404)
    s = job.settings
    trim_in  = body.get("trim_in",  clip.start_sec)
    trim_out = body.get("trim_out", clip.start_sec + clip.duration)
    new_cap  = body.get("caption_text", clip.caption_text)
    new_dur  = int(trim_out - trim_in)
    if abs(trim_in - clip.start_sec) > 0.1 or abs(new_dur - clip.duration) > 0.1:
        clips_dir = str(Path(clip.path).parent)
        nc = await cut_clip(job.video_path, trim_in, new_dur,
                             clip.aspect_ratio, clips_dir, clip.index)
        clip.path = nc.path; clip.start_sec = trim_in
        clip.duration = new_dur; clip.captioned_path = None
    if new_cap != clip.caption_text or body.get("trim_in") is not None:
        clip.caption_text = new_cap
        if s.caption_on and new_cap:
            cp_path = clip.path.replace(".mp4","_captioned.mp4")
            await burn_caption(clip.path, cp_path, new_cap,
                s.caption_size, s.caption_color, s.caption_pos)
            clip.captioned_path = cp_path
    return clip_dict(clip)

@router.delete("/{pid}/{clip_id}")
async def delete_clip(pid: str, clip_id: str):
    job = _jobs.get(pid)
    if not job: raise HTTPException(404)
    clip = next((c for c in job.clips if c.clip_id == clip_id), None)
    if not clip: raise HTTPException(404)
    for p in [clip.path, clip.captioned_path, clip.srt_path, clip.vtt_path]:
        if p and Path(p).exists(): Path(p).unlink()
    job.clips = [c for c in job.clips if c.clip_id != clip_id]
    return {"deleted": clip_id}
