# ManyUse Engine

Local processing engine untuk fitur **ManyUse Clipper** — potong video otomatis
menjadi klip viral dengan AI caption dan subtitle.

## Instalasi

```bash
pip install manyuse-engine
```

## Cara Pakai

```bash
# Jalankan engine
manyuse start

# Cek status
manyuse status

# Hentikan engine
manyuse stop
```

Engine akan berjalan di `http://localhost:8899` dan terhubung otomatis
dengan [ManyUse](https://manyuse.id) di browser kamu.

## Requirements

- Python 3.10 atau lebih baru
- Windows 10+, macOS 11+, atau Linux
- RAM minimal 4GB (8GB recommended untuk video 1080p)
- Browser: Chrome 94+ atau Edge (untuk koneksi localhost)

## Fitur

- Download video dari YouTube, TikTok, Instagram, Facebook
- Potong otomatis segmen terbaik berdasarkan AI scoring
- Burn caption dengan FFmpeg
- Export subtitle .SRT dan .VTT
- FFmpeg sudah bundled — tidak perlu install terpisah

## Dokumentasi Lengkap

Kunjungi [manyuse.id/docs/clipper](https://manyuse.id/docs/clipper)
