import logging
from datetime import UTC, datetime, timedelta

import pytest
from fa_purity import Unsafe
from fa_purity.date_time import DatetimeUTC

from fluidattacks_batch_job_sdk._api import new_api_client
from fluidattacks_batch_job_sdk.core import AfterDate, BeforeDate, DateRange, QueueName

LOG = logging.getLogger(__name__)

_PROBES_QUEUE = QueueName("probes")
_NOW = DatetimeUTC.assert_utc(datetime.now(tz=UTC)).alt(Unsafe.raise_exception).to_union()
_YESTERDAY = (
    DatetimeUTC.assert_utc(datetime.now(tz=UTC) - timedelta(days=1))
    .alt(Unsafe.raise_exception)
    .to_union()
)


def test_list_queues() -> None:
    cmd = new_api_client().bind(lambda c: c.list_queues)
    with pytest.raises(SystemExit):
        cmd.compute()


def test_list_jobs_range() -> None:
    cmd = new_api_client().bind(
        lambda c: c.list_jobs(_PROBES_QUEUE, DateRange(after=_YESTERDAY, before=_NOW)).map(
            lambda r: r.alt(Unsafe.raise_exception).to_union()
        )
    )
    with pytest.raises(SystemExit):
        cmd.compute()


def test_list_jobs_after() -> None:
    cmd = new_api_client().bind(
        lambda c: c.list_jobs_after(_PROBES_QUEUE, AfterDate(_YESTERDAY)).map(
            lambda r: r.alt(Unsafe.raise_exception).to_union()
        )
    )
    with pytest.raises(SystemExit):
        cmd.compute()


def test_list_jobs_before() -> None:
    cmd = new_api_client().bind(
        lambda c: c.list_jobs_before(_PROBES_QUEUE, BeforeDate(_NOW)).map(
            lambda r: r.alt(Unsafe.raise_exception).to_union()
        )
    )
    with pytest.raises(SystemExit):
        cmd.compute()
