"""AWS Batch job execution SDK."""

from fa_purity import (
    Unsafe,
)

from ._logger import (
    set_logger,
)
from .core import (
    AfterDate,
    ApiClient,
    BeforeDate,
    DateRange,
    JobItem,
    QueueName,
    TerminalJobStatus,
)

__version__ = "1.0.1"

Unsafe.compute(set_logger(__name__, __version__))

__all__ = [
    "AfterDate",
    "ApiClient",
    "BeforeDate",
    "DateRange",
    "JobItem",
    "QueueName",
    "TerminalJobStatus",
]
