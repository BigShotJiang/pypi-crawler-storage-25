"""Factory for the AWS Batch API client."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import boto3
from fa_purity import Cmd

if TYPE_CHECKING:
    from mypy_boto3_batch import BatchClient

from fluidattacks_batch_job_sdk._api._list_jobs import (
    list_jobs,
    list_jobs_after,
    list_jobs_before,
)
from fluidattacks_batch_job_sdk._api._list_queues import list_queues
from fluidattacks_batch_job_sdk.core import ApiClient

LOG = logging.getLogger(__name__)


def _new_batch_client() -> Cmd[BatchClient]:
    return Cmd.wrap_impure(lambda: boto3.client("batch"))


def new_api_client() -> Cmd[ApiClient]:
    """Build an ApiClient using a fresh boto3 Batch client."""
    return _new_batch_client().map(
        lambda client: ApiClient(
            list_queues=list_queues(client, LOG),
            list_jobs=lambda queue, date_range: list_jobs(client, LOG, queue, date_range),
            list_jobs_after=lambda queue, after_date: list_jobs_after(
                client, LOG, queue, after_date
            ),
            list_jobs_before=lambda queue, before_date: list_jobs_before(
                client, LOG, queue, before_date
            ),
        )
    )
