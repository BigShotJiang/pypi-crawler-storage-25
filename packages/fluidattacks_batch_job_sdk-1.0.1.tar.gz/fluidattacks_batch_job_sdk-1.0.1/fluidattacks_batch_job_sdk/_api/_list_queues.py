"""Fetch all AWS Batch queue names with pagination."""

from __future__ import annotations

from typing import TYPE_CHECKING

from fa_purity import Cmd, FrozenList, Maybe, PureIterFactory, StreamTransform
from fluidattacks_etl_utils.paginate import cursor_pagination

if TYPE_CHECKING:
    from logging import Logger

    from mypy_boto3_batch import BatchClient
    from mypy_boto3_batch.type_defs import DescribeJobQueuesResponseTypeDef

from fluidattacks_batch_job_sdk.core import QueueName


def _get_queues_page(
    client: BatchClient,
    next_token: Maybe[str],
) -> Cmd[DescribeJobQueuesResponseTypeDef]:
    def _run() -> DescribeJobQueuesResponseTypeDef:
        token = next_token.value_or(None)
        if token:
            return client.describe_job_queues(maxResults=100, nextToken=token)
        return client.describe_job_queues(maxResults=100)

    return Cmd.wrap_impure(_run)


def _decode_page(
    resp: DescribeJobQueuesResponseTypeDef,
    log: Logger,
) -> tuple[FrozenList[QueueName], Maybe[str]]:
    queues = tuple(QueueName(q["jobQueueName"]) for q in resp.get("jobQueues", []))
    log.info("Fetched %d queues", len(queues))
    return queues, Maybe.from_optional(resp.get("nextToken"))


def list_queues(client: BatchClient, log: Logger) -> Cmd[FrozenList[QueueName]]:
    """Return all queue names that exist in AWS Batch."""
    log_start = Cmd.wrap_impure(lambda: log.info("Fetching all batch queues"))
    paginate = cursor_pagination(
        lambda next_token: (
            Cmd.wrap_impure(lambda: log.info("Fetching queues page"))
            + _get_queues_page(client, next_token).map(lambda resp: _decode_page(resp, log))
        )
    )
    all_queues = paginate.transform(
        lambda s: StreamTransform.chain(s.map(PureIterFactory.from_list))
    ).to_list()
    return log_start + all_queues
