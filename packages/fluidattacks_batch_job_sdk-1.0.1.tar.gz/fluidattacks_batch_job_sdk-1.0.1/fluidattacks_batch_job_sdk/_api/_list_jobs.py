"""Fetch AWS Batch jobs for a queue filtered by date range."""

from __future__ import annotations

from typing import TYPE_CHECKING

from fa_purity import (
    Cmd,
    FrozenList,
    Maybe,
    PureIterFactory,
    Result,
    ResultE,
    StreamTransform,
    cast_exception,
)
from fluidattacks_etl_utils.paginate import cursor_pagination

if TYPE_CHECKING:
    from logging import Logger

    from fa_purity.date_time import DatetimeUTC
    from mypy_boto3_batch import BatchClient
    from mypy_boto3_batch.type_defs import KeyValuesPairTypeDef, ListJobsResponseTypeDef

    from fluidattacks_batch_job_sdk.core import (
        AfterDate,
        BeforeDate,
        DateRange,
        JobItem,
        QueueName,
    )

from fluidattacks_batch_job_sdk._api._decode import decode_job


def _to_ms(date: DatetimeUTC) -> str:
    return str(int(date.date_time.timestamp() * 1000))


def _make_filter(name: str, value: str) -> list[KeyValuesPairTypeDef]:
    return [{"name": name, "values": [value]}]


def _get_jobs_page(
    client: BatchClient,
    queue: QueueName,
    filters: list[KeyValuesPairTypeDef],
    next_token: Maybe[str],
) -> Cmd[ListJobsResponseTypeDef]:
    def _run() -> ListJobsResponseTypeDef:
        token = next_token.value_or(None)
        if token:
            return client.list_jobs(
                jobQueue=queue.value,
                maxResults=100,
                filters=filters,
                nextToken=token,
            )
        return client.list_jobs(
            jobQueue=queue.value,
            maxResults=100,
            filters=filters,
        )

    return Cmd.wrap_impure(_run)


def _decode_page(
    resp: ListJobsResponseTypeDef,
    log: Logger,
    queue: QueueName,
) -> tuple[FrozenList[JobItem], Maybe[str]]:
    raw_jobs = resp.get("jobSummaryList", [])
    jobs = tuple(
        item for j in raw_jobs for item in (decode_job(j).value_or(None),) if item is not None
    )
    log.info(
        "Decoded %d terminal jobs queue=%s",
        len(jobs),
        queue.value,
    )
    return jobs, Maybe.from_optional(resp.get("nextToken"))


def _fetch_jobs(
    client: BatchClient,
    log: Logger,
    queue: QueueName,
    filters: list[KeyValuesPairTypeDef],
) -> Cmd[FrozenList[JobItem]]:
    return (
        cursor_pagination(
            lambda next_token: (
                Cmd.wrap_impure(lambda: log.info("Fetching page queue=%s", queue.value))
                + _get_jobs_page(client, queue, filters, next_token).map(
                    lambda resp: _decode_page(resp, log, queue)
                )
            )
        )
        .transform(lambda s: StreamTransform.chain(s.map(PureIterFactory.from_list)))
        .to_list()
        .map(tuple)
    )


def _wrap_result(
    log: Logger,
    queue: QueueName,
    jobs: FrozenList[JobItem],
) -> Cmd[ResultE[FrozenList[JobItem]]]:
    return Cmd.wrap_impure(
        lambda: log.info("Fetched %d total jobs queue=%s", len(jobs), queue.value)
    ) + Cmd.wrap_impure(lambda: Result.success(jobs).alt(cast_exception))


def _trim_before(
    jobs: FrozenList[JobItem],
    before: DatetimeUTC,
) -> FrozenList[JobItem]:
    """Keep only jobs created strictly before `before` (exclusive upper bound)."""
    return tuple(j for j in jobs if j.created_at.date_time < before.date_time)


def list_jobs(
    client: BatchClient,
    log: Logger,
    queue: QueueName,
    date_range: DateRange,
) -> Cmd[ResultE[FrozenList[JobItem]]]:
    """Fetch jobs in range: AFTER_CREATED_AT server-side, trim to before client-side."""
    filters = _make_filter("AFTER_CREATED_AT", _to_ms(date_range.after))
    log_start = Cmd.wrap_impure(
        lambda: log.info(
            "Fetching jobs queue=%s after=%s before=%s",
            queue.value,
            date_range.after,
            date_range.before,
        )
    )
    before = date_range.before
    return log_start + _fetch_jobs(client, log, queue, filters).bind(
        lambda jobs: _wrap_result(log, queue, _trim_before(jobs, before))
    )


def list_jobs_after(
    client: BatchClient,
    log: Logger,
    queue: QueueName,
    after_date: AfterDate,
) -> Cmd[ResultE[FrozenList[JobItem]]]:
    """Fetch all jobs created after after_date (AFTER_CREATED_AT, no upper bound)."""
    filters = _make_filter("AFTER_CREATED_AT", _to_ms(after_date.value))
    log_start = Cmd.wrap_impure(
        lambda: log.info("Fetching jobs queue=%s after=%s", queue.value, after_date.value)
    )
    return log_start + _fetch_jobs(client, log, queue, filters).bind(
        lambda jobs: _wrap_result(log, queue, jobs)
    )


def list_jobs_before(
    client: BatchClient,
    log: Logger,
    queue: QueueName,
    before_date: BeforeDate,
) -> Cmd[ResultE[FrozenList[JobItem]]]:
    """Fetch all jobs created before before_date (BEFORE_CREATED_AT, no lower bound)."""
    filters = _make_filter("BEFORE_CREATED_AT", _to_ms(before_date.value))
    log_start = Cmd.wrap_impure(
        lambda: log.info("Fetching jobs queue=%s before=%s", queue.value, before_date.value)
    )
    return log_start + _fetch_jobs(client, log, queue, filters).bind(
        lambda jobs: _wrap_result(log, queue, jobs)
    )
