# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Build & Development

Package manager: **uv** with Hatchling build backend.

```bash
# Install dependencies (dev included)
uv sync --all-extras

# Run all tests
uv run pytest

# Run single test file
uv run pytest tests/core/test_config_builder.py

# Run specific test
uv run pytest tests/core/test_config_builder.py::test_should_instantiate_from_package

# Type checking
uv run mypy src/ezconfy --ignore-missing-imports

# Lint
uv run ruff check src tests

# Format
uv run ruff format src tests

# Build package
uv build
```

Pre-commit hooks (ruff lint, ruff format, nbstripout) run automatically on commit.

## Architecture

EZConfy has two main subsystems under `src/ezconfy/`:

### Core (`core/`) — Config loading & instantiation

Pipeline: YAML files → merge → instantiate objects → validate against schema

- **`config_builder.py`** — Orchestrator. `ConfigBuilder.from_files()` is the main library entry point. Deep-merges multiple YAML configs, runs instantiation, optionally validates against a Pydantic schema.
- **`instantiator.py`** — Resolves `${placeholder}` references by building a dependency graph, topologically sorting it (`graphlib.TopologicalSorter`), then instantiating objects in order. Objects with `_target_type_` are dynamically constructed.
- **`schema_parser.py`** — Converts YAML schema definitions into dynamic Pydantic BaseModel classes. Handles enums, nested models, inheritance, unions, optionals, and external type imports.
- **`module_loader.py`** — Dynamic class loading from import paths (`module:Class`) or file paths (`path/to/file.py:Class`).
- **`io.py`** — YAML read/write utilities.

### Code Generation (`codegen/`) — Schema → Python source

Generates standalone `.py` files with Pydantic model definitions from schema YAML.

- **`generator.py`** — Orchestrates the generation pipeline.
- **`walker.py`** — Depth-first traversal of the schema type tree (visitor pattern) with memoization.
- **`extractors.py`** — Abstract `Extractor` base class with `EnumExtractor` and `ModelExtractor` implementations. Each extractor has `children()`, `extract()`, and `emit()` methods.
- **`emitter.py`** — Renders extracted types as Python code with grouped imports.
- **`type_utils.py`** — Type introspection for generating correct annotations and imports.

### CLI (`cli.py`)

Typer-based CLI. Entry point: `ezconfy generate schema.yaml -o output.py`.

## Key Design Patterns

- **Topological sort** for dependency resolution (both in instantiation and schema parsing)
- **Visitor pattern** in codegen walker/extractors
- **Placeholder injection** (`${key}`) enables forward references between config sections
- **Dynamic imports** via `_target_type_` and `_init_method_` keys in config YAML

## Project Config

- Python >= 3.11, tested on 3.11 and 3.12
- Line length: 120
- MyPy strict mode enabled
- CI runs pytest, mypy, and ruff on PRs
