"""
       Name: base_install
DESCRIPTION: installs helm repos, updates them, and installs charts for
             metallb, cert-manager, and ingress-nginx
     AUTHOR: https://jessebot.work
    LICENSE: GNU AFFERO GENERAL PUBLIC LICENSE Version 3
"""
# external libraries
import asyncio
import logging as log

# internal libraries
from .argocd import configure_argocd
from ..bitwarden.bw_cli import BwCLI
from ..k8s_tools.helm import prepare_helm
from ..k8s_tools.k8s_lib import K8s
from ..k8s_tools.argocd_util import ArgoCD
from .identity_provider.zitadel import configure_zitadel
from .identity_provider.zitadel_api import Zitadel
from .ingress.cert_manager import configure_cert_manager, create_cluster_issuers
from .ingress.ingress_nginx_controller import configure_ingress_nginx
from .secrets_management.external_secrets_operator import configure_external_secrets
from .secrets_management.openbao import configure_openbao
from .social.forgejo import ConfigureForgejo
from .renovate import configure_renovate
from .social.ghost import configure_ghost
from .social.gotosocial import configure_gotosocial
from .social.harbor import configure_harbor
from .social.home_assistant import configure_home_assistant
from .social.matrix import configure_matrix
from .social.mastodon import configure_mastodon
from .social.nextcloud import configure_nextcloud
from .social.jellyfin import configure_jellyfin
from .storage.juicefs import configure_juicefs
from .social.peertube import configure_peertube
from .social.writefreely import configure_writefreely
from ..utils.rich_cli.console_logging import header


def setup_k8s_secrets_management(argocd: ArgoCD,
                                 k8s_distro: str,
                                 eso_dict: dict = {},
                                 eso_provider: str = "",
                                 openboa_dict: dict = {},
                                 bitwarden: BwCLI = None) -> None:
    """
    sets up k8s secrets management tooling
    """
    # secrets management section
    header_msg = "Setting up K8s secret management with [green]"

    # setup external secrets operator and bitwarden external secrets
    if eso_dict.get('enabled', False):
        header_msg += (f'External Secrets Operator[/] and [blue]{eso_provider}'
                       '[/] as the Provider')
        header(header_msg, '🤫')
        configure_external_secrets(argocd,
                                   eso_dict,
                                   eso_provider,
                                   k8s_distro,
                                   bitwarden)

    # setup openboa, a secret key management system that works with eso
    if openboa_dict.get('enabled', False):
        configure_openbao(argocd, openboa_dict)


def setup_oidc_provider(argocd: ArgoCD,
                        api_tls_verify: bool = False,
                        zitadel_dict: dict = {},
                        pvc_storage_class: str = "local-path",
                        bw: BwCLI = None,
                        argocd_fqdn: str = "") -> Zitadel | None:
    """
    sets up oidc provider. only zitadel is supported right now

    Returns Zitadel object for configuring other Zitadel authed services
    """
    header("Setting up [green]OIDC[/]/[green]Oauth[/] Applications")

    zitadel_enabled = zitadel_dict.get('enabled', False)

    # setup zitadel if we're using that for OIDC
    if zitadel_enabled:
        zitadel_init_enabled = zitadel_dict['init'].get('enabled', False)
        log.debug("Setting up zitadel")
        if zitadel_init_enabled:
            zitadel_obj = configure_zitadel(
                    argocd,
                    zitadel_dict,
                    pvc_storage_class,
                    api_tls_verify,
                    bitwarden=bw
                    )
        else:
            configure_zitadel(argocd, zitadel_dict, bitwarden=bw)

    if zitadel_enabled and zitadel_init_enabled:
        return zitadel_obj


def setup_base_apps(k8s_obj: K8s,
                    k8s_distro: str,
                    metallb_dict: dict = {},
                    ingress_dict: dict = {},
                    cert_manager_dict: dict = {},
                    argocd_dict: dict = {},
                    plugin_secrets: dict = {},
                    bw: BwCLI = None) -> ArgoCD:
    """
    Uses Helm to install all base apps that need to be running being argo cd:
        metallb, ingess-nginx, cert-manager, argo cd, argocd secrets plugin
    All Needed for getting Argo CD up and running.

    Returns an ArgoCD object for further argo actions
    """
    metallb_enabled = metallb_dict.get('enabled', False)
    ingress_nginx_enabled = ingress_dict.get('enabled', False)
    argocd_enabled = argocd_dict.get('enabled', False)
    cert_manager_enabled = cert_manager_dict.get('enabled', False)
    argo_secrets_plugin_enabled = argocd_dict['argo']['directory_recursion']
    cnpg_operator_enabled = True
    pxc_operator_enabled = True
    # make sure helm is installed and the repos are up to date
    prepare_helm(k8s_distro,
                 metallb_enabled,
                 cnpg_operator_enabled,
                 pxc_operator_enabled,
                 argocd_enabled,
                 argo_secrets_plugin_enabled)

    # ingress controller: so we can accept traffic from outside the cluster
    if ingress_nginx_enabled:
        header("Installing [green]ingress-nginx-controller[/green] to access"
               " web apps outside the cluster", "🌐")
        configure_ingress_nginx(k8s_obj, k8s_distro)

    # manager SSL/TLS certificates via lets-encrypt
    header("Installing [green]cert-manager[/green] for TLS certificates...",
           '📜')
    if cert_manager_enabled:
        cert_manager_init_enabled = cert_manager_dict['init'].get('enabled',
                                                                  False)
        cert_manager_init_values = cert_manager_dict['init'].get('values', {})
        configure_cert_manager(k8s_obj)
        if not argocd_enabled and cert_manager_init_enabled:
            create_cluster_issuers(cert_manager_init_values, k8s_obj)

    # then we install argo cd if it's enabled
    if argocd_enabled:
        argocd = configure_argocd(k8s_obj,
                                  argocd_dict,
                                  plugin_secrets,
                                  bw)

        # needed for metal (non-cloud provider) installs
        if metallb_enabled:
            header("Installing [green]metallb[/green] so we have an IP pool",
                   '🛜')
            if metallb_dict['init']['enabled']:
                argocd.install_init_app("metallb", metallb_dict, 4)

        if ingress_nginx_enabled:
            header("Syncing [green]ingress-nginx-controller[/green] Argo App",
                   "🌐")
            argocd.install_init_app("ingress-nginx", ingress_dict, 4)

        if cert_manager_enabled:
            if cert_manager_init_enabled:
                header("initializing [green]cert-manager[/green] issuers", '📜')
                create_cluster_issuers(cert_manager_init_values,
                                       k8s_obj,
                                       argocd,
                                       bw)

        return argocd


async def setup_federated_apps(
        argocd: ArgoCD,
        api_tls_verify: bool = False,
        forgejo_dict: dict = {},
        ghost_dict: dict = {},
        harbor_dict: dict = {},
        jellyfin_dict: dict = {},
        home_assistant_dict: dict = {},
        nextcloud_dict: dict = {},
        mastodon_dict: dict = {},
        gotosocial_dict: dict = {},
        matrix_dict: dict = {},
        peertube_dict: dict = {},
        writefreely_dict: dict = {},
        renovate_dict: dict = {},
        pvc_storage_class: str = "local-path",
        zitadel_obj: Zitadel = None,
        libretranslate_api_key: str = "",
        bw: BwCLI = None
        ) -> None:
    """
    Setup any federated apps with initialization supported
    """
    log.debug(f"current zitadel hostname is {zitadel_obj.hostname}")

    # blogging platforms
    if ghost_dict.get('enabled', False):
        await configure_ghost(argocd,
                              ghost_dict,
                              pvc_storage_class,
                              zitadel_obj,
                              bw)

    # git server
    if forgejo_dict.get('enabled', False):
        ConfigureForgejo(argocd,
                         forgejo_dict,
                         pvc_storage_class,
                         zitadel_obj,
                         bw)

    if renovate_dict.get('enabled', False):
        log.info("🤖  🤖  Awaiting renovate 🤖  🤖")
        await configure_renovate(argocd,
                                 renovate_dict,
                                 bw)

    # federated social micro blogging apps
    if gotosocial_dict.get('enabled', False):
        await configure_gotosocial(argocd,
                                   gotosocial_dict,
                                   pvc_storage_class,
                                   zitadel_obj,
                                   bw)

    if mastodon_dict.get('enabled', False):
        await configure_mastodon(argocd,
                                 mastodon_dict,
                                 pvc_storage_class,
                                 libretranslate_api_key,
                                 bw)

    # federated video hosting - similar to youtube
    if peertube_dict.get('enabled', False):
        await configure_peertube(argocd,
                                 peertube_dict,
                                 pvc_storage_class,
                                 bw)

    if writefreely_dict.get('enabled', False):
        await configure_writefreely(argocd,
                                    writefreely_dict,
                                    pvc_storage_class,
                                    zitadel_obj,
                                    bw)

    # oci registry for docker and helm
    if harbor_dict.get('enabled', False):
        await configure_harbor(argocd,
                               harbor_dict,
                               pvc_storage_class,
                               zitadel_obj,
                               bw)

    # home media server
    if jellyfin_dict.get('enabled', False):
        await configure_jellyfin(argocd,
                                 jellyfin_dict,
                                 pvc_storage_class,
                                 bw)

    # home iot management
    if home_assistant_dict.get('enabled', False):
        await configure_home_assistant(argocd,
                                       home_assistant_dict,
                                       pvc_storage_class,
                                       api_tls_verify,
                                       bw)

    if nextcloud_dict.get('enabled', False):
        await configure_nextcloud(argocd,
                                  nextcloud_dict,
                                  pvc_storage_class,
                                  zitadel_obj,
                                  bw)
    # federated chat apps
    if matrix_dict.get('enabled', False):
        await configure_matrix(argocd,
                               matrix_dict,
                               pvc_storage_class,
                               zitadel_obj,
                               bw)


async def setup_storage_apps(argocd: ArgoCD,
                             juicefs_dict: dict = {},
                             pvc_storage_class: str = "local-path",
                             bw: BwCLI = None) -> None:

    if juicefs_dict.get('enabled', False):
        await configure_juicefs(argocd,
                                juicefs_dict,
                                pvc_storage_class,
                                bw)
