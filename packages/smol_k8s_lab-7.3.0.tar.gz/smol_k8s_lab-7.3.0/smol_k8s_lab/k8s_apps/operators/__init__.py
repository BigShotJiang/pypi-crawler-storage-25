from smol_k8s_lab.bitwarden.bw_cli import BwCLI
from smol_k8s_lab.k8s_tools.argocd_util import ArgoCD
from smol_k8s_lab.utils.rich_cli.console_logging import header
from .seaweedfs import configure_seaweedfs


def setup_operators(argocd: ArgoCD,
                    prometheus_config: dict = {},
                    longhorn_config: dict = {},
                    k8up_config: dict = {},
                    k8tz_config: dict = {},
                    seaweed_config: dict = {},
                    cnpg_config: dict = {},
                    pxc_config: dict = {},
                    bitwarden: BwCLI = None) -> None:
    """
    deploy all k8s operators that can block other apps:
        - prometheus
        - longhorn
        - k8up
        - k8tz
        - seaweedfs
        - cnpg (cloud native postgres) operator
        - pxc (percona mysql) operator
    """
    header("Setting up Operators", "⚙️ ")

    # deploy the prometheus CRDs before everything else so that apps with
    # metrics don't fail
    if prometheus_config and prometheus_config.get('enabled', False):
        argocd.install_app('prometheus-crds', prometheus_config['argo'])

    # longhorn operator is used to have expanding volumes that span multiple
    # nodes
    if longhorn_config and longhorn_config.get('enabled', False):
        argocd.install_app('longhorn', longhorn_config['argo'])

    # k8up operator is a used for backups
    if k8up_config and k8up_config.get('enabled', False):
        argocd.install_init_app('k8up', k8up_config, 2)

    # k8tz operator is a used for setting timezone the same everywhere
    if k8tz_config and k8tz_config.get('enabled', False):
        argocd.install_init_app('k8tz', k8tz_config, 2)

    # seaweedfs
    if seaweed_config and seaweed_config.get('enabled', False):
        configure_seaweedfs(argocd, seaweed_config, bitwarden)

    # cnpg operator is a postgres operator for creating postgresql clusters
    if cnpg_config and cnpg_config.get('enabled', False):
        argocd.install_app('cnpg-operator', cnpg_config['argo'])

    # pxc operator is a mysql operator for creating mysql clusters
    if pxc_config and pxc_config.get('enabled', False):
        argocd.install_app('pxc-operator', pxc_config['argo'])
