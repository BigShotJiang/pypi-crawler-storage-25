"""
           NAME: smol-k8s-lab
    DESCRIPTION: package, cli, and tui for setting up k8s on metal with
                 k3s, KinD, and k3d, as well as installing our or your own
                 Argo CD Apps, ApplicationSets, and Projects.
                 And now we support restores too!

         AUTHOR: jessebot(AT)linux(d0t)com
        LICENSE: GNU AFFERO GENERAL PUBLIC LICENSE
"""

import asyncio
from click import option, command
import logging
from os import environ as env
from rich.logging import RichHandler
from rich.panel import Panel
from rich.prompt import Prompt, Confirm

# custom libs and constants
from .constants import (INITIAL_USR_CONFIG,
                        XDG_CONFIG_FILE,
                        APPS_DIR,
                        load_yaml,
                        load_apps_configs
                        )
from .env_config import check_os_support, process_configs
from .bitwarden.bw_cli import BwCLI
from .bitwarden.tui.bitwarden_app import BitwardenCredentialsApp
from .constants import KUBECONFIG, VERSION
from .k8s_apps import (setup_oidc_provider, setup_base_apps,
                       setup_k8s_secrets_management, setup_federated_apps,
                       setup_storage_apps)
from .k8s_apps.monitoring.grafana_stack import configure_grafana_stack
from .k8s_apps.networking.headscale import ConfigureHeadscale
from .k8s_apps.operators import setup_operators
from .k8s_apps.social.libretranslate import configure_libretranslate
from .k8s_apps.valkey import configure_valkey
from .k8s_distros import create_k8s_distro, delete_cluster, check_all_contexts
from .k8s_tools.backup import run_cli_backup
from .tui import launch_config_tui
from .utils.rich_cli.console_logging import CONSOLE, sub_header, header
from .utils.rich_cli.help_text import RichCommand, options_help
from .utils.run.final_cmd import run_final_cmd


HELP = options_help()
HELP_SETTINGS = dict(help_option_names=["-h", "--help"])


def process_log_config(log_dict: dict = {"level": "warn", "file": ""}):
    """
    Sets up rich logger for the entire project.
    Returns logging.getLogger("rich")

    TODO: change this to always add file logger
    """

    # determine logging level and default to warning level
    level = log_dict.get("level", "warn")
    log_level = getattr(logging, level.upper(), None)

    # these are params to be passed into logging.basicConfig
    opts = {"level": log_level, "format": "%(message)s", "datefmt": "[%X]"}

    # we only log to a file if one was passed into config.yaml
    # determine logging level
    log_file = log_dict.get("file", None)

    # rich typically handles much of this but we don't use rich with files
    if log_file:
        opts['filename'] = log_file
        opts['format'] = "%(asctime)s %(levelname)s %(funcName)s: %(message)s"
    else:
        rich_handler_opts = {"rich_tracebacks": True}
        # 10 is the DEBUG logging level int value
        if log_level == 10:
            # log the name of the function if we're in debug mode :)
            opts['format'] = "[bold]%(funcName)s()[/bold]: %(message)s"
            rich_handler_opts['markup'] = True
        else:
            rich_handler_opts['show_path'] = False
            rich_handler_opts['show_level'] = False

        opts['handlers'] = [RichHandler(**rich_handler_opts)]

    # this removes all former loggers, we hope
    for handler in logging.root.handlers[:]:
        logging.root.removeHandler(handler)

    kubernetes = logging.getLogger("kubernetes")
    kubernetes.level = "WARNING"

    # this uses the opts dictionary as parameters to logging.basicConfig()
    logging.basicConfig(**opts)

    if not log_file:
        return logging.getLogger("rich")
    # if the user requested logging to a file, we don't use rich logging
    else:
        return logging


def determine_current_configs(config: str = "") -> [dict, dict]:
    """
    grab initial config dict and apps config dicts
    """
    if config:
        config_dict = load_yaml(config)
    else:
        config_dict = INITIAL_USR_CONFIG

    apps_dict = load_apps_configs(APPS_DIR)

    return config_dict, apps_dict


# an ugly list of decorators, but these are the opts/args for the whole script
@command(cls=RichCommand, context_settings=HELP_SETTINGS)
@option("--backup", "-b",
        type=str,
        default="",
        help=HELP['backup'])
@option("--config", "-c",
        metavar="CONFIG_FILE",
        type=str,
        default=XDG_CONFIG_FILE,
        help=HELP['config'])
@option("--delete", "-D",
        metavar="CLUSTER_NAME",
        type=str,
        help=HELP['delete'])
@option("--final_cmd", "-f",
        type=str,
        default="",
        help=HELP['command'])
@option("--interactive", "-i",
        is_flag=True,
        help=HELP['interactive'])
@option("--version", "-v",
        is_flag=True,
        help=HELP['version'])
def main(backup: str = "",
         config: str = "",
         delete: bool = False,
         final_cmd: str = "",
         interactive: bool = False,
         log_file: str = "",
         version: bool = False):
    """
    Quickly install a k8s distro for a homelab setup. Installs k3s
    with metallb, ingess-nginx, cert-manager, and argocd
    (plus all the argocd apps)
    """
    # only return the version if --version was passed in
    if version:
        print(f"\n🎉 v{VERSION}\n")
        return True

    # make sure this OS is supported
    check_os_support()

    # if we're just deleting a cluster, do that immediately
    if delete:
        logging.debug("Cluster deletion was requested")
        # exits the script after deleting the cluster
        delete_cluster(delete)

    if backup:
        config_dict, apps = determine_current_configs(config)
        run_cli_backup(backup, apps[backup])
        return True

    # declaring bitwarden for the future in case user doesn't enable this
    bw_creds = None

    # declaring the default name to be smol-k8s-lab
    cluster_name = "smol-k8s-lab"

    # verify if the TUI should be used
    config_dict, apps = determine_current_configs(config)
    tui_enabled = config_dict['smol_k8s_lab']['tui']['enabled']

    if tui_enabled == "ask":
        print("Please note: The TUI is not screenreader friendly.")
        tui_enabled = Confirm.ask("Would you like to enable the TUI?")

    if interactive or tui_enabled:
        cluster_name, USR_CFG, SECRETS, apps, bw_creds = launch_config_tui(
                config_dict,
                apps
                )
    else:
        # process the config files, or create ones, and also grab secrets
        USR_CFG, apps, SECRETS = process_configs(config_dict, apps)

        contexts = check_all_contexts()

        if contexts:
            if len(contexts) == 1:
                cluster_name = contexts[0][0]
            else:
                print("Found multiple clusters...")
                for context in contexts:
                    print(context[0])
                cluster_name = Prompt(
                        "Which cluster would you like to modify?")

        # if we're using bitwarden for the password manager, unlock the vault
        pwm = USR_CFG['smol_k8s_lab']['local_password_manager']
        using_bw_pw_manager = pwm['enabled'] and pwm['name'] == 'bitwarden'
        using_bweso = SECRETS['global_external_secrets']

        if using_bw_pw_manager or using_bweso == 'bitwarden':
            # get bitwarden credentials from the env if there are any
            password = env.get("BW_PASSWORD", None)
            client_id = env.get("BW_CLIENTID", None)
            client_secret = env.get("BW_CLIENTSECRET", None)

            # if any of the credentials are missing from env, launch the tui
            if not any([password, client_id, client_secret]):
                bw_creds = BitwardenCredentialsApp().run()
                if not bw_creds:
                    raise Exception(
                            "Exiting because no credentials were passed in "
                            "but bitwarden is enabled")
            else:
                bw_creds = {"password": password,
                            "client_id": client_id,
                            "client_secret": client_secret}

    # setup logging immediately
    log = process_log_config(USR_CFG['smol_k8s_lab']['log'])
    log.debug("Logging configured.")

    k8s_distros = USR_CFG['k8s_distros']

    # if we have bitwarden credetials unlock the vault
    if bw_creds:
        pw_mngr = USR_CFG['smol_k8s_lab']['local_password_manager']
        bw = BwCLI(**bw_creds,
                   duplicate_strategy=pw_mngr['duplicate_strategy'])
        bw.unlock()
    else:
        bw = None

    # check immediately if metallb is enabled
    metallb_enabled = apps['metallb']['enabled']

    # iterate through each passed in k8s distro & create cluster + install apps
    for distro, metadata in k8s_distros.items():
        # if the cluster isn't enabled, just continue on
        if k8s_distros[distro].get('enabled', False):
            selected_distro = distro
            break

    # install the actual KIND, k3s, or k3d cluster
    k8s_obj = create_k8s_distro(cluster_name, selected_distro, metadata,
                                metallb_enabled)

    # run the final command immediately after k8s is up, if it's running in a
    # new tab, window, or pane
    window_behavior = USR_CFG['smol_k8s_lab']['run_command']['window_behavior']
    terminal = USR_CFG['smol_k8s_lab']['run_command']['terminal']
    if not final_cmd:
        final_cmd = USR_CFG['smol_k8s_lab']['run_command']['command']

    if final_cmd and window_behavior != "same window":
        run_final_cmd(final_cmd, terminal, window_behavior)

    # check if argo is enabled
    argo_enabled = apps['argo_cd']['enabled']

    # installs all the base apps: metallb ingess-nginx, cert-manager, & argocd
    argocd = setup_base_apps(k8s_obj,
                             distro,
                             apps['metallb'],
                             apps.get('ingress_nginx', {}),
                             apps.get('cert_manager', {}),
                             apps['argo_cd'],
                             SECRETS,
                             bw)

    # 🦑 Install Argo CD: continuous deployment app for k8s
    if argo_enabled:
        # setup k8s secrets management and secret stores
        setup_k8s_secrets_management(argocd,
                                     distro,
                                     apps.pop('external_secrets_operator', {}),
                                     SECRETS['global_external_secrets'],
                                     apps.pop('openbao', {}),
                                     bw)

        # if the global cluster issuer is set to letsencrypt-staging don't
        # verify TLS certs in requests to APIs
        if 'staging' in SECRETS['global_cluster_issuer']:
            api_tls_verify = False
        else:
            api_tls_verify = True

        # Setup minio, our local s3 provider, is essential for creating buckets
        # & cnpg operator, our postgres operator for creating postgres clusters
        setup_operators(argocd,
                        apps.pop('prometheus_crds', {'enabled': False}),
                        apps.pop('longhorn', {'enabled': False}),
                        apps.pop('k8up', {'enabled': False}),
                        apps.pop('k8tz', {'enabled': False}),
                        apps.pop('seaweedfs', {'enabled': False}),
                        apps.pop('cnpg_operator', {'enabled': False}),
                        apps.pop('pxc_operator', {'enabled': False}),
                        bw)

        # global pvc storage class
        pvc_storage_class = SECRETS.get('global_pvc_storage_class',
                                        'local-path')

        # check if zitadel is enabled
        zitadel_enabled = apps['zitadel']['enabled']
        argo_cd_hostname = apps['argo_cd']['hostnames']['argocd']
        zitadel_hostname = apps.get(
                'zitadel', {}).get('hostnames', {}).get('zitadel', '')

        # setup OIDC for securing all endpoints with SSO
        oidc_obj = setup_oidc_provider(argocd,
                                       api_tls_verify,
                                       apps.pop('zitadel', {}),
                                       pvc_storage_class,
                                       bw,
                                       argo_cd_hostname)

        # setup headscale, a wireguard vpn management web interface
        headscale_dict = apps.pop('headscale', {'enabled': False})
        headscale_hostname = headscale_dict.get(
                'hostnames', {"headscale": ""})['headscale']
        # only do this if the user has smol-k8s-lab init enabled
        if headscale_dict['enabled']:
            ConfigureHeadscale(argocd,
                               headscale_dict,
                               pvc_storage_class,
                               oidc_obj,
                               bw)

        grafana_stack = apps.pop('grafana_stack', {'enabled': False})
        if grafana_stack['enabled']:
            configure_grafana_stack(argocd,
                                    grafana_stack,
                                    pvc_storage_class,
                                    oidc_obj,
                                    bw)

        # set up self hosted translation
        libretranslate_dict = apps.pop('libretranslate', {'enabled': False})
        libretranslate_hostname = libretranslate_dict.get(
                'hostnames', {}).get("libretranslate", "")
        if libretranslate_dict['enabled']:
            libretranslate_api_key = configure_libretranslate(
                    argocd, libretranslate_dict, bw
                    )
        else:
            libretranslate_api_key = ""

        # setup federated init apps such as nextcloud, gotosocial, and matrix
        forgejo_hostname = apps.get(
                'forgejo', {}).get('hostnames', {})['forgejo']
        ghost_hostname = apps.get('ghost', {}).get('hostnames', {})['ghost']
        harbor_hostname = apps.get('harbor', {}).get('hostnames', {})['harbor']
        jellyfin_hostname = apps.get(
                'jellyfin', {}).get('hostnames', {})['jellyfin']
        home_assistant_hostname = apps.get(
                'home_assistant', {}).get('hostnames', {})['home_assistant']
        nextcloud_hostname = apps.get(
                'nextcloud', {}).get('hostnames', {})['nextcloud']
        mastodon_hostname = apps.get(
                'mastodon', {}).get('hostnames', {})['mastodon']
        gotosocial_hostname = apps.get(
                'gotosocial', {}).get('hostnames', {})['gotosocial']
        matrix_hostname = apps.get('matrix', {}).get('hostnames', {})['matrix']
        peertube_hostname = apps.get(
                'peertube', {}).get('hostnames', {})['peertube']
        asyncio.run(
                setup_federated_apps(
                    argocd,
                    api_tls_verify,
                    apps.pop('forgejo', {}),
                    apps.pop('ghost', {}),
                    apps.pop('harbor', {}),
                    apps.pop('jellyfin', {}),
                    apps.pop('home_assistant', {}),
                    apps.pop('nextcloud', {}),
                    apps.pop('mastodon', {}),
                    apps.pop('gotosocial', {}),
                    apps.pop('matrix', {}),
                    apps.pop('peertube', {}),
                    apps.pop('writefreely', {}),
                    apps.pop('renovate', {}),
                    pvc_storage_class,
                    oidc_obj,
                    libretranslate_api_key,
                    bw
                    )
                )

        # stand alone valkey
        if apps.get('valkey'):
            configure_valkey(argocd, apps.pop('valkey'), bw)

        if apps.get('valkey_cluster'):
            configure_valkey(argocd, apps.pop('valkey_cluster'), bw)

        if apps.get('juicefs'):
            asyncio.run(
                    setup_storage_apps(
                        argocd=argocd,
                        juicefs_dict=apps['juicefs'],
                        pvc_storage_class=pvc_storage_class,
                        bw=bw
                        )
                    )

        # after argocd, zitadel, and bweso are up, we install all apps
        # as Argo CD Applications
        header("Installing the rest of the Argo CD apps")
        for app_key, app_meta in apps.items():
            if app_meta['enabled']:
                argo_app = app_key.replace('_', '-')
                sub_header(f"Installing app: {argo_app}")
                argocd.install_app(argo_app, app_meta['argo'])

        # lock the bitwarden vault on the way out, to be polite :3
        if bw:
            bw.lock()

    # we're done :D
    print("")
    final_msg = (
            "\nMake sure you run the following to pick up your k8s config:\n"
            f"[gold3]export[/gold3] [green]KUBECONFIG={KUBECONFIG}[/green]\n")
    if bw:
        final_msg += "\n[i]All credentials are in Bitwarden[/i]\n"

    if argo_enabled:
        if zitadel_enabled:
            final_msg += (
                    f"\n🔑 Zitadel, your identity provider:\n"
                    f"[blue][link]https://{zitadel_hostname}[/][/]\n"
                     )

        final_msg += ("\n🦑 Argo CD, your k8s apps console:\n"
                      f"[blue][link]https://{argo_cd_hostname}[/][/]\n")

        if forgejo_hostname:
            final_msg += ("\n🦊 Forgejo, for hosting your own git server:\n"
                          f"[blue][link]https://{forgejo_hostname}[/][/]\n")

        if ghost_hostname:
            final_msg += ("\n👻 Ghost, for hosting your blogging platform:\n"
                          f"[blue][link]https://{ghost_hostname}[/][/]\n")

        if harbor_hostname:
            final_msg += (
                    "\n⛵ Harbor, for your docker and helm hosting needs:\n"
                    f"[blue][link]https://{harbor_hostname}[/][/]\n")

        if nextcloud_hostname:
            final_msg += ("\n☁️ Nextcloud, for your worksuite:\n"
                          f"[blue][link]https://{nextcloud_hostname}[/][/]\n")

        if mastodon_hostname:
            final_msg += (
                    "\n🐘 Mastodon, for your social media:\n"
                    f"[blue][link]https://{mastodon_hostname}[/][/]\n")

        if gotosocial_hostname:
            final_msg += (
                    "\n🦥 GoToSocial, for your lightweight social media:\n"
                    f"[blue][link]https://{gotosocial_hostname}[/][/]\n")

        if peertube_hostname:
            final_msg += ("\n🐙 PeerTube, for your video hosting:\n"
                          f"[blue][link]https://{peertube_hostname}[/][/]\n")

        if jellyfin_hostname:
            final_msg += ("\n🪼 Jellyfin, for your home media server:\n"
                          f"[blue][link]https://{jellyfin_hostname}[/][/]\n")

        if matrix_hostname:
            final_msg += (
                    "\n💬 Matrix (with Element frontend), for your chat:\n"
                    f"[blue][link]https://{matrix_hostname}[/][/]\n")

        if home_assistant_hostname:
            final_msg += (
                    "\n🏠 Home Assistant, for managing your IoT needs:\n"
                    f"[blue][link]https://{home_assistant_hostname}[/][/]\n")

        if libretranslate_hostname:
            final_msg += (
                    "\n📖, LibreTranslate for self-hosted translations:\n"
                    f"[blue][link]https://{libretranslate_hostname}[/][/]\n")

        if headscale_hostname:
            final_msg += ("\n🛜 Headscale, for managing your own VPN:\n"
                          f"[blue][link]https://{headscale_hostname}[/][/]\n")

    CONSOLE.print(Panel(final_msg,
                        title='[green]◝(ᵔᵕᵔ)◜ Success!',
                        subtitle='♥ [cyan]Have a nice day[/] ♥',
                        border_style="cornflower_blue"))
    print("")

    # run final command after it all ends
    if final_cmd and window_behavior == "same-window":
        run_final_cmd(final_cmd, terminal, window_behavior)


if __name__ == '__main__':
    main()
