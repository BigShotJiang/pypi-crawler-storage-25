"""
       Name: restores.py
DESCRIPTION: restore stuff with k8up (restic on k8s) and cnpg operator
     AUTHOR: @jessebot
    LICENSE: GNU AFFERO GENERAL PUBLIC LICENSE Version 3
"""
# internal libraries
from smol_k8s_lab.bitwarden.bw_cli import BwCLI
from smol_k8s_lab.constants import XDG_CACHE_DIR
from smol_k8s_lab.k8s_tools.argocd_util import ArgoCD
from smol_k8s_lab.k8s_tools.helm import Helm
from smol_k8s_lab.utils.run.subproc import subproc
from smol_k8s_lab.utils.minio_lib import BetterMinio
from smol_k8s_lab.utils.value_from import process_backup_vals

# external libraries
from datetime import datetime
from json import loads
import logging as log
from minio.error import InvalidResponseError
from os import path, environ
from time import sleep


class Restore():
    """
    complete restore app function
    restore seaweedfs PVCs, files and/or config PVC(s),
    and CNPG postgresql cluster
    """

    def __init__(self,
                 app_name: str,
                 argocd: ArgoCD,
                 hostname: str,
                 namespace: str,
                 app_dict: dict,
                 pvc_storage_class: str,
                 restore_seaweedfs: bool = False,
                 bitwarden: BwCLI = None) -> None:
        """
        complete restore app function
        restore seaweedfs PVCs, files and/or config PVC(s),
        and CNPG postgresql cluster
        """
        self.app_name = app_name
        self.namespace = namespace
        self.argocd = argocd
        self.pvc_storage_class = pvc_storage_class

        # this is the info for the REMOTE backups
        backup_dict = process_backup_vals(app_dict.get('backups', {}))
        self.s3_backup = backup_dict['s3']
        self.s3_backup_access_key_id = backup_dict['s3']['access_key_id']
        self.s3_backup_secret_access_key = backup_dict['s3']['secret_access_key']
        self.restic_repo_password = backup_dict['restic_repo_pass']

        restore_dict = app_dict['init'].get('restore', {})
        self.snapshot_ids = restore_dict['restic_snapshot_ids']

        # all database settings
        self.db = app_dict.get('db', {})

        argo_dict = app_dict['argo']

        # get argo git repo info
        self.revision_path = f"{argo_dict['revision']}/{argo_dict['path']}"
        project_ns = argo_dict["project"]["destination"]["namespaces"]
        if namespace not in project_ns:
            project_ns.append(namespace)
        if "argocd" not in project_ns:
            project_ns.append('argocd')

        log.info(f"Creating {app_name} project...")
        argocd.create_project(
                project_name=argo_dict["project"]["name"],
                app=app_name,
                namespaces=set(project_ns),
                clusters=argo_dict["cluster"],
                source_repos=set(argo_dict["project"]["source_repos"]))

        # apply the externalSecrets and PVCs so we can immediately use them
        argocd.install_init_app(app_name, app_dict, 1)

        # then we create all the seaweedfs pvcs we lost and restore them
        if restore_seaweedfs:
            self.s3_pvc_capacity = app_dict['s3']['capacity']
            self.restore_seaweedfs(app_dict)

        # then we finally can restore the postgres database :D
        if restore_dict.get("cnpg_restore", False):
            # first we grab existing bitwarden items if they exist
            if bitwarden:
                # postgresql s3 ID
                s3_db_creds = bitwarden.get_item(
                        f"{app_name}-postgres-s3-credentials-{hostname}", False
                        )[0]['login']

            pg_access_key_id = s3_db_creds["username"]
            pg_secret_access_key = s3_db_creds["password"]

            pgsql_cluster_name = app_name + "-postgres"
            s3_endpoint = app_dict['s3']['endpoint']
            cnpg_backup_schedule = backup_dict['db']['schedule']
            self.restore_cnpg_cluster(pgsql_cluster_name,
                                      s3_endpoint,
                                      pg_access_key_id,
                                      pg_secret_access_key,
                                      pgsql_cluster_name,
                                      cnpg_backup_schedule)

        log.info(f"Restoring {app_name} PVCs...")
        app_pvcs = app_dict.get('pvc', {})
        if app_pvcs:
            # then begin the restic restore of all the PVCs we lost
            for pvc, pvc_vals in app_pvcs.items():
                pvc_enabled = pvc_vals.get('enabled', False)

                if pvc_enabled:
                    # sometimes the only app pvc has the same name as the app
                    if pvc == app_name.replace("-", "_"):
                        snapshot_key = pvc
                        restore_pvc = app_name
                    else:
                        restore_pvc = f'{app_name}-{pvc.replace("_", "-")}'
                        snapshot_key = f'{app_name}_{pvc}'

                    snapshot_id = self.snapshot_ids[snapshot_key]
                    m = f"Restoring {restore_pvc} w/ snapshot id {snapshot_id}"
                    log.info(m)

                    # restores the pvc
                    self.k8up_restore_pvc(
                            pvc=restore_pvc,
                            snapshot_id=snapshot_id)

        # todo: from here on out, this could be async to start on other tasks
        # install app as usual, but wait on it this time
        argocd.install_init_app(app_name, app_dict, 4, True)

    def get_latest_snapshot(self, pvc: str) -> str:
        """
        gets the latest snapshot for a pvc via restic and returns the ID of it
        """
        restic_endpoint = "/".join([self.s3_backup['endpoint'],
                                    self.s3_backup['bucket']])
        restic_pw_cmd = f"echo -n '{self.restic_repo_password}'"

        # set restic environment variables
        env = {"PATH": environ.get("PATH"),
               "HOME": environ.get("HOME"),
               "RESTIC_REPOSITORY": f"s3:{restic_endpoint}",
               "RESTIC_PASSWORD_COMMAND": restic_pw_cmd,
               "AWS_ACCESS_KEY_ID": self.s3_backup_access_key_id,
               "AWS_SECRET_ACCESS_KEY": self.s3_backup_secret_access_key,
               "AWS_DEFAULT_REGION": self.s3_backup['region']}

        snapshots = loads(subproc(["restic snapshots --latest 1 --json"],
                                  env=env))

        for snapshot in snapshots:
            # makes sure this is the snapshot for the correct path
            if pvc in snapshot["paths"][0]:
                # gets the long ID of the latest snapshot for this path
                return snapshot['id']

    def k8up_restore_pvc(self,
                         pvc: str,
                         snapshot_id: str = "latest",
                         pod_config: str = "file-backups-podconfig"):
        """
        builds a k8up restore manifest and applies it
        """
        # if snapshot not passed in, restic/k8up use the latest snapshot
        if snapshot_id and snapshot_id != "latest":
            snapshot_id_final = snapshot_id
        else:
            snapshot_id_final = self.get_latest_snapshot(pvc)

        # we timestamp this restore job just in case there's others around
        now = datetime.now().strftime('%Y-%m-%d-%H-%M')
        restore_name = f"{self.app_name}-{pvc}-{now}"
        restore_dict = {'apiVersion': 'k8up.io/v1',
                        'kind': 'Restore',
                        'metadata': {
                            'name': restore_name,
                            'namespace': self.namespace
                            },
                        'spec': {
                            'snapshot': snapshot_id_final,
                            'failedJobsHistoryLimit': 5,
                            'successfulJobsHistoryLimit': 1,
                            'podConfigRef': {
                                'name': pod_config
                            },
                            'restoreMethod': {
                                'folder': {
                                    'claimName': pvc
                                    }
                                },
                            'backend': {
                                'repoPasswordSecretRef': {
                                    'name': "s3-backups-credentials",
                                    'key': 'resticRepoPassword'
                                    },
                                's3': {
                                    'endpoint': self.s3_backup['endpoint'],
                                    'bucket': self.s3_backup['bucket'],
                                    'accessKeyIDSecretRef': {
                                        'name': "s3-backups-credentials",
                                        'key': 'ACCESS_KEY_ID'
                                        },
                                    'secretAccessKeySecretRef': {
                                        'name': "s3-backups-credentials",
                                        'key': 'ACCESS_SECRET_KEY'
                                        }
                                    }
                                }
                            }
                        }

        # apply the k8up restore job
        self.argocd.k8s.apply_custom_resources([restore_dict])

        # loop on check to make sure the restore is done before continuing
        check_cmd = (f"kubectl get restore -n {self.namespace} --no-headers -o "
                     f"custom-columns=COMPLETION:.status.finished {restore_name}")
        while True:
            restore_done = subproc([check_cmd]).strip()
            log.debug(f"restore done returns {restore_done}")

            pod_cmd = (f"kubectl get pods -n {self.namespace} --no-headers -o "
                       f"custom-columns=NAME:.metadata.name | grep {restore_name}")
            pod = subproc([pod_cmd], universal_newlines=True, shell=True)
            subproc([f"kubectl logs -n {self.namespace} --tail=5 {pod}"], error_ok=True)

            if restore_done != "true":
                # sleep then try again
                sleep(5)
            else:
                break

    def restore_seaweedfs(self, app_dict: dict):
        """
        recreate the seaweedfs PVCs for a given namespace and restore them via
        restic, before applying the app's s3 provider Argo CD application set
        """
        exists = self.argocd.check_if_app_exists(f"{self.app_name}-seaweedfs")

        if exists:
            log.info("Seaweedfs looks like it's already installed")
            return

        snapshots = {'swfs-volume-data': self.snapshot_ids['seaweedfs_volume'],
                     'swfs-filer-data': self.snapshot_ids['seaweedfs_filer']}

        for swfs_pvc, snapshot_id in snapshots.items():
            # build a k8up restore file and apply it
            self.k8up_restore_pvc(swfs_pvc, snapshot_id, "s3-backups-podconfig")

        # deploy the seaweedfs appset, which will use the restored PVCs above
        self.argocd.install_init_app(self.app_name, app_dict, 2, True)

        # and finally wait for the seaweedfs helm chart app to be ready
        self.argocd.wait_for_app(f"{self.app_name}-seaweedfs", retry=True)

        # but then wait again on the pods, just in case...
        self.argocd.k8s.wait(self.namespace,
                             instance=f"{self.app_name}-seaweedfs",
                             timeout=1)

    def restore_cnpg_cluster(self,
                             cluster_name: str,
                             s3_endpoint: str,
                             access_key_id: str,
                             secret_access_key: str,
                             s3_bucket: str,
                             scheduled_backup: str = "0 0 0 * * *"
                             ):
        """
        restore a CNPG operator controlled postgresql cluster
        """
        log.info(f"Beginning the restoration cnpg cluster, {cluster_name}.")
        # need to first get the correct backup.info file and make sure s3 is up
        s3 = BetterMinio("", s3_endpoint, access_key_id, secret_access_key)
        base_folder = f"{s3_bucket}/base"
        while True:
            try:
                s3_files = s3.list_object(s3_bucket, base_folder, recursive=True)
                log.info(f"Found folder: {base_folder} in bucket: {s3_bucket}, continuing...")
            except Exception as e:
                log.info(e)
                log.info("S3 not up yet, so couldn't find base folder: "
                         f"{base_folder} in bucket: {s3_bucket}")

            possible_files = []
            try:
                for backup_file in s3_files:
                    if "backup.info" in backup_file.object_name:
                        # will be like: matrix-postgres/base/20240507T122317/backup.info
                        possible_files.append(backup_file.object_name)
            except InvalidResponseError:
                log.info("We got a not found error... trying again in 10 seconds")
                sleep(10)
                continue
            else:
                break

        # get the oldest object and save it to our cache dir for inspection later
        save_path = path.join(XDG_CACHE_DIR,
                              "cnpg-backup-info-files",
                              f'{self.app_name}_backup.info.env')
        s3.get_object(s3_bucket, possible_files[-1], save_path)

        with open(save_path) as backup_info_file:
            lines = backup_info_file.readlines()
            # time_var = "begin_time"
            time_var = "end_time"
            for line in lines:
                if time_var in line:
                    log.debug(f"{time_var} line: {line}")
                    pitr_time = line.replace(f"{time_var}=", "").strip()
                    log.debug(f"{time_var}: {pitr_time}")

        restore_dict = {
                "fullnameOverride": cluster_name,
                "name": cluster_name,
                "mode": "recovery",
                "cluster": {
                  "instances": 1,
                  "storage": {
                      "size": self.db.get('capacity', "5Gi"),
                      "storageClass": self.pvc_storage_class
                  },
                  "initdb": {
                      'database': self.app_name,
                      'owner': self.app_name,
                      'secret': {'name': f"{self.app_name}-pgsql-credentials"}
                  }
                },
                "version": {"postgresql": f"{self.db['version']}"},
                "recovery": {
                    "method": "object_store",
                    "clusterName": cluster_name,
                    "endpointURL": f"https://{s3_endpoint}",
                    "destinationPath": f"s3://{s3_bucket}",
                    "pitrTarget": {
                        "time": pitr_time
                    },
                    "provider": "s3",
                    "database": self.app_name,
                    "secret": {
                        "name": "s3-postgres-credentials",
                        "create": False
                    },
                    "s3": {
                      "bucket": cluster_name,
                      "accessKey": "ACCESS_KEY_ID",
                      "secretKey": "ACCESS_SECRET_KEY"
                    }
                },
                "backups": {},
                "scheduledBackup": {},
                "monitoring": {"enablePodMonitor": False},
                "testApp": {"enabled": False},
                }

        # set certs only if we're using mTLS for app -> postgresql communication
        if self.db.get('certs', False):
            restore_dict ["cluster"]["certificates"] = {
                      "serverTLSSecret": f"{cluster_name}-server-cert",
                      "serverCASecret": f"{cluster_name}-server-cert",
                      "clientCASecret": f"{cluster_name}-client-cert",
                      "replicationTLSSecret": f"{cluster_name}-client-cert"}

        # this creates a values.yaml from restore_dict above
        release_dict = {"release_name": f"{self.app_name}-postgres",
                        "namespace": self.namespace,
                        "values_dict": restore_dict,
                        "values_file": f"{self.app_name}-restore-values.yaml",
                        "chart_name": "cnpg/cluster",
                        "chart_version": "0.5.0"}
        release = Helm.chart(**release_dict)

        # this actually applies the helm chart release using the values dict
        # we've defined above and waits for it to be ready
        release.install(wait=True)

        # wait on cluster to be ready
        cmd = ("kubectl get clusters.postgresql.cnpg.io "
               f"-n {self.namespace} {cluster_name} "
               "-o jsonpath='{.status.phase}'")

        while True:
            res = subproc([cmd])
            if "Cluster in healthy state" in res:
                log.info(f"{cluster_name} cluster restored.")
                break
            else:
                log.info("Cluster not up yet. Sleeping 5 seconds")
                sleep(5)

        # update the mode kind after the restore
        restore_dict['mode'] = "standalone"

        restore_dict['externalClusters'] = []

        # fix backups after restore
        restore_dict['backups'] = {
                "enabled": True,
                "destinationPath": f"s3://{s3_bucket}",
                "endpointURL": f"https://{s3_endpoint}",
                "provider": "s3",
                "s3": {
                    "region": "auto",
                    "bucket": s3_bucket,
                    "accessKey": "ACCESS_KEY_ID",
                    "secretKey": "ACCESS_SECRET_KEY"
                },
                "secret": {
                    "create": False,
                    "name": "s3-postgres-credentials"
                },
                "wal": {
                    "compression": "gzip",
                    "maxParallel": 8,
                    "encryption": "AES256"
                    },
                "retentionPolicy": "2d",
                "scheduledBackups": [{
                    "name": f"{self.app_name}-pg-backup",
                    "schedule": scheduled_backup,
                    "backupOwnerReference": "self",
                    "method": "barmanObjectStore"
                    }]
                }

        restore_dict['cluster']['annotations'] = {
                "cnpg.io/skipEmptyWalArchiveCheck": "enabled"
                }

        # this creates a values.yaml from restore_dict above
        release.update_values_file(restore_dict,
                                   f"{self.app_name}-after-restore-values.yaml")
        release.install(wait=True, upgrade=True)

        # prepare s3 bucket for backups again, by wiping it. The data is still
        # upstream in the remote bucket, don't worry... unless no remote, then worry
        s3.delete_object(s3_bucket, cluster_name, True)
