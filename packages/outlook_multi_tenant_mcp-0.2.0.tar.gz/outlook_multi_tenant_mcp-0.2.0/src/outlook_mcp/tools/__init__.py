"""MCP tool implementations."""
