from .smtp import (
    ConfiguracaoSMTP,
    carregar_configuracao_smtp,
    enviar_email,
    verificar_conexao_smtp,
)

__all__ = [
    "ConfiguracaoSMTP",
    "carregar_configuracao_smtp",
    "enviar_email",
    "verificar_conexao_smtp",
]

__version__ = "0.1.0"

default_app_config = "django_email_sender.apps.DjangoEmailSenderConfig"
