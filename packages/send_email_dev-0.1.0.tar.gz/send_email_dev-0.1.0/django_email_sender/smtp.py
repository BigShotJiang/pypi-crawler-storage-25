import logging
import re
import smtplib
from dataclasses import dataclass
from email import encoders
from email.message import Message
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path
from urllib.parse import unquote, urlparse
from urllib.request import Request, urlopen

from decouple import config


logger = logging.getLogger(__name__)


@dataclass
class ConfiguracaoSMTP:
    servidor: str = "smtp.zoho.com"
    porta: int = 465
    usar_ssl: bool = True
    usuario: str = ""
    senha: str = ""
    rodape_html: str = "Enviado via django-email-sender"

    def validar(self) -> None:
        if not self.usuario:
            raise ValueError("Campo 'usuario' (email remetente) e obrigatorio")
        if not self.senha:
            raise ValueError("Campo 'senha' e obrigatorio")
        if not self.servidor:
            raise ValueError("Campo 'servidor' SMTP e obrigatorio")


def carregar_configuracao_smtp() -> ConfiguracaoSMTP:
    smtp_config = ConfiguracaoSMTP(
        servidor=config("SMTP_SERVIDOR", default="smtp.zoho.com"),
        porta=config("SMTP_PORTA", default=465, cast=int),
        usar_ssl=config("SMTP_USAR_SSL", default=True, cast=bool),
        usuario=config("EMAIL_USUARIO", default=""),
        senha=config("EMAIL_SENHA", default=""),
        rodape_html=config("EMAIL_RODAPE_HTML", default="Enviado via django-email-sender"),
    )
    smtp_config.validar()
    return smtp_config


def _montar_corpo_html(corpo_texto: str, rodape: str) -> str:
    corpo_escapado = corpo_texto.replace("\n", "<br>")
    return f"""<html>
<body style="font-family: Arial, sans-serif; font-size: 14px; line-height: 1.6;">
{corpo_escapado}
<br><br>
<hr style="border: none; border-top: 1px solid #ccc;">
<p style="font-size: 12px; color: #666;">
{rodape}
</p>
</body>
</html>"""


def _anexar_arquivo(msg: MIMEMultipart, anexo_path: str) -> None:
    caminho = Path(anexo_path)
    if not caminho.exists():
        raise FileNotFoundError(f"Arquivo de anexo nao encontrado: {caminho}")

    with caminho.open("rb") as arquivo:
        parte = MIMEBase("application", "octet-stream")
        parte.set_payload(arquivo.read())
        encoders.encode_base64(parte)

    nome_sanitizado = re.sub(r'[";\\\\<>|]', "_", caminho.name)
    parte.add_header(
        "Content-Disposition",
        "attachment",
        filename=("utf-8", "", nome_sanitizado),
    )
    msg.attach(parte)


def _extrair_nome_arquivo_url(url: str, headers: Message) -> str:
    content_disposition = headers.get("Content-Disposition", "")
    match = re.search(r"filename\*=UTF-8''([^;]+)", content_disposition, re.IGNORECASE)
    if match:
        return unquote(match.group(1))

    match = re.search(r'filename="?([^";]+)"?', content_disposition, re.IGNORECASE)
    if match:
        return match.group(1)

    caminho = urlparse(url).path
    nome = Path(unquote(caminho)).name
    return nome or "anexo"


def _anexar_arquivo_url(msg: MIMEMultipart, anexo_url: str) -> None:
    requisicao = Request(
        anexo_url,
        headers={
            "User-Agent": "Mozilla/5.0 django-email-sender/1.0",
            "Accept": "*/*",
        },
    )

    with urlopen(requisicao, timeout=30) as resposta:
        conteudo = resposta.read()
        nome_arquivo = _extrair_nome_arquivo_url(anexo_url, resposta.headers)

    parte = MIMEBase("application", "octet-stream")
    parte.set_payload(conteudo)
    encoders.encode_base64(parte)

    nome_sanitizado = re.sub(r'[";\\\\<>|]', "_", nome_arquivo)
    parte.add_header(
        "Content-Disposition",
        "attachment",
        filename=("utf-8", "", nome_sanitizado),
    )
    msg.attach(parte)


def _montar_mensagem(
    smtp_config: ConfiguracaoSMTP,
    destinatario: str,
    assunto: str,
    corpo: str,
    anexo_path: str | None = None,
    anexo_url: str | None = None,
) -> MIMEMultipart:
    if anexo_path or anexo_url:
        msg = MIMEMultipart("mixed")
        corpo_part = MIMEMultipart("alternative")
    else:
        msg = MIMEMultipart("alternative")
        corpo_part = msg

    msg["Subject"] = assunto
    msg["From"] = smtp_config.usuario
    msg["To"] = destinatario

    corpo_part.attach(MIMEText(corpo, "plain", "utf-8"))
    corpo_part.attach(
        MIMEText(_montar_corpo_html(corpo, smtp_config.rodape_html), "html", "utf-8")
    )

    if anexo_path or anexo_url:
        msg.attach(corpo_part)
        if anexo_path:
            _anexar_arquivo(msg, anexo_path)
        else:
            _anexar_arquivo_url(msg, anexo_url)

    return msg


def enviar_email(
    destinatario: str,
    assunto: str,
    corpo: str,
    anexo_path: str | None = None,
    anexo_url: str | None = None,
    smtp_config: ConfiguracaoSMTP | None = None,
) -> bool:
    smtp_config = smtp_config or carregar_configuracao_smtp()
    smtp_config.validar()

    logger.info("[SMTP] Enviando para %s | Assunto: %s", destinatario, assunto[:80])
    mensagem = _montar_mensagem(
        smtp_config,
        destinatario,
        assunto,
        corpo,
        anexo_path=anexo_path,
        anexo_url=anexo_url,
    )

    if smtp_config.usar_ssl:
        with smtplib.SMTP_SSL(smtp_config.servidor, smtp_config.porta) as servidor:
            servidor.login(smtp_config.usuario, smtp_config.senha)
            servidor.send_message(mensagem)
    else:
        with smtplib.SMTP(smtp_config.servidor, smtp_config.porta) as servidor:
            servidor.starttls()
            servidor.login(smtp_config.usuario, smtp_config.senha)
            servidor.send_message(mensagem)

    logger.info("[SMTP] Email enviado com sucesso para %s", destinatario)
    return True


def verificar_conexao_smtp(
    smtp_config: ConfiguracaoSMTP | None = None,
    timeout: int = 10,
) -> bool:
    smtp_config = smtp_config or carregar_configuracao_smtp()
    try:
        if smtp_config.usar_ssl:
            with smtplib.SMTP_SSL(smtp_config.servidor, smtp_config.porta, timeout=timeout) as servidor:
                servidor.noop()
        else:
            with smtplib.SMTP(smtp_config.servidor, smtp_config.porta, timeout=timeout) as servidor:
                servidor.ehlo()
        return True
    except Exception:
        return False
