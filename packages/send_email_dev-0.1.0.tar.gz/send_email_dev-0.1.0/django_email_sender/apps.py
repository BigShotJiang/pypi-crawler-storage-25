from django.apps import AppConfig


class DjangoEmailSenderConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "django_email_sender"
    verbose_name = "Django Email Sender"
