from django.urls import path

from .views import enviar_email_manual


app_name = "django_email_sender"

urlpatterns = [
    path("enviar/", enviar_email_manual, name="enviar-email-manual"),
]
