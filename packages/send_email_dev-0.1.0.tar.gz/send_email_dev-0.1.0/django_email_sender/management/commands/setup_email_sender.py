from pathlib import Path

from django.conf import settings
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = (
        "Configura o django_email_sender no projeto: cria/atualiza o .env "
        "com as variaveis genericas necessarias."
    )

    def add_arguments(self, parser):
        parser.add_argument(
            "--force",
            action="store_true",
            help="Sobrescreve variaveis ja existentes no .env",
        )
        parser.add_argument(
            "--path",
            default=None,
            help="Caminho onde o .env deve ser criado (padrao: BASE_DIR/.env)",
        )

    def handle(self, *args, **options):
        base_dir = Path(settings.BASE_DIR)
        env_path = Path(options["path"]) if options["path"] else base_dir / ".env"

        template_path = (
            Path(__file__).resolve().parent.parent.parent
            / "templates"
            / "env_template.txt"
        )
        if not template_path.exists():
            self.stderr.write(
                self.style.ERROR(f"Template nao encontrado em {template_path}")
            )
            return

        template_content = template_path.read_text(encoding="utf-8")

        if not env_path.exists():
            env_path.write_text(template_content, encoding="utf-8")
            self.stdout.write(self.style.SUCCESS(f"OK .env criado em {env_path}"))
        else:
            existing = env_path.read_text(encoding="utf-8")
            existing_keys = {
                line.split("=", 1)[0].strip()
                for line in existing.splitlines()
                if "=" in line and not line.strip().startswith("#")
            }

            linhas_para_adicionar = []
            for line in template_content.splitlines():
                stripped = line.strip()
                if "=" in stripped and not stripped.startswith("#"):
                    key = stripped.split("=", 1)[0].strip()
                    if key in existing_keys and not options["force"]:
                        continue
                linhas_para_adicionar.append(line)

            chaves_novas = [
                l for l in linhas_para_adicionar
                if "=" in l and not l.strip().startswith("#")
            ]

            if chaves_novas:
                with env_path.open("a", encoding="utf-8") as f:
                    f.write("\n" + "\n".join(linhas_para_adicionar) + "\n")
                self.stdout.write(
                    self.style.SUCCESS(
                        f"OK {len(chaves_novas)} variavel(eis) adicionada(s) em {env_path}"
                    )
                )
            else:
                self.stdout.write(
                    self.style.WARNING(
                        "Nenhuma variavel nova para adicionar "
                        "(use --force para sobrescrever as existentes)."
                    )
                )

        self.stdout.write(self.style.NOTICE(
            "\nProximos passos:\n"
            "  1. Adicione 'django_email_sender' em INSTALLED_APPS\n"
            "  2. Preencha as credenciais reais no .env\n"
            "  3. Carregue o .env no settings.py (ex: python-decouple ja basta)\n"
            "  4. Use: from django_email_sender import enviar_email\n"
            "\n"
            "Opcional (endpoint REST):\n"
            "  - Inclua em urls.py:\n"
            "      path('emails/', include('django_email_sender.urls'))\n"
            "  - Requer 'djangorestframework' instalado.\n"
        ))
