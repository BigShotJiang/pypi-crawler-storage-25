"""
View generica para envio de email via API.

Requer Django REST Framework instalado. Se DRF nao estiver disponivel,
o import simplesmente nao expoe a view e o app continua funcional via
import direto de `enviar_email` em `django_email_sender.smtp`.
"""

try:
    from rest_framework import status
    from rest_framework.decorators import api_view
    from rest_framework.response import Response
except ImportError:  # DRF e opcional
    api_view = None
    Response = None
    status = None

from .smtp import enviar_email


if api_view is not None:

    @api_view(["POST"])
    def enviar_email_manual(request):
        """
        Envia email diretamente a partir do payload recebido.

        Payload JSON esperado:
            {
                "destinatario": "email@exemplo.com",
                "assunto": "Assunto",
                "corpo": "Texto do email",
                "anexoPath": "/caminho/local/arquivo.pdf",   # opcional
                "anexoUrl":  "https://exemplo.com/arq.pdf"   # opcional
            }
        """
        destinatario = request.data.get("destinatario")
        assunto = request.data.get("assunto")
        corpo = request.data.get("corpo")
        anexo_path = request.data.get("anexoPath")
        anexo_url = request.data.get("anexoUrl")

        if not destinatario:
            return Response(
                {"success": False, "error": "O campo 'destinatario' e obrigatorio."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        if not assunto:
            return Response(
                {"success": False, "error": "O campo 'assunto' e obrigatorio."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        if not corpo:
            return Response(
                {"success": False, "error": "O campo 'corpo' e obrigatorio."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        try:
            enviar_email(
                destinatario=destinatario,
                assunto=assunto,
                corpo=corpo,
                anexo_path=anexo_path,
                anexo_url=anexo_url,
            )
        except Exception as exc:
            return Response(
                {"success": False, "error": str(exc), "status": "ERRO"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

        return Response(
            {
                "success": True,
                "destinatario": destinatario,
                "assunto": assunto,
                "status": "ENVIADO",
            },
            status=status.HTTP_200_OK,
        )
