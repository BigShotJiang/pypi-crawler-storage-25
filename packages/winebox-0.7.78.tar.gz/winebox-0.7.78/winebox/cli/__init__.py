"""CLI tools for WineBox."""
