"""Transaction document model for tracking wine check-ins and check-outs.

DEPRECATED — kept so historical rows in the `transactions` collection
still load. Phase 4 of the cases-first-class plan converged the event
log onto :mod:`winebox.models.cellar_event`.

Writes:    no live code path inserts into this collection any more.
Reads:     served via :mod:`winebox.services.cellar_event_view`, which
           projects `CellarEvent` rows onto the `TransactionResponse`
           shape so the `/api/transactions` endpoint and CSV exports
           keep working unchanged.

Dropping the collection is a separate ticket — once Phase 4 has been
live for a release and we're confident no readers remain we can
schedule the drop. The class stays here meanwhile so the demo
"remove demo data" cleanup and the migration script can keep
referencing it.
"""

import enum
from datetime import datetime, timezone
from typing import Optional

from pydantic import Field, model_validator

from winebox.db import MongoDocument, PyObjectId


class TransactionType(str, enum.Enum):
    """Type of transaction.

    Values match ``CellarEventType.ADDED`` / ``.REMOVED`` so audit queries
    across the two collections can use the same token set.
    """

    ADDED = "ADDED"
    REMOVED = "REMOVED"


class RemovalReason(str, enum.Enum):
    """Reason for removing wine from the cellar."""

    DRINK = "DRINK"
    SELL = "SELL"
    GIFT = "GIFT"
    OTHER = "OTHER"


class Transaction(MongoDocument):
    """Transaction document model for tracking wine movements."""

    owner_id: PyObjectId  # Denormalized for efficient user queries
    wine_id: PyObjectId
    transaction_type: TransactionType
    quantity: int = Field(..., ge=1)
    notes: Optional[str] = None
    transaction_date: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    # Removal metadata (only valid when transaction_type is REMOVED)
    removal_reason: Optional[RemovalReason] = None
    tasting_notes: Optional[str] = None
    sale_price_usd: Optional[float] = Field(default=None, ge=0)
    gift_recipient: Optional[str] = None
    removal_notes: Optional[str] = None

    @model_validator(mode="after")
    def validate_removal_fields(self) -> "Transaction":
        """Enforce cross-field validation for removal metadata."""
        if self.transaction_type == TransactionType.ADDED:
            if self.removal_reason is not None:
                raise ValueError("removal_reason is only valid for REMOVED transactions")
            if self.tasting_notes is not None:
                raise ValueError("tasting_notes is only valid for REMOVED transactions")
            if self.sale_price_usd is not None:
                raise ValueError("sale_price_usd is only valid for REMOVED transactions")
            if self.gift_recipient is not None:
                raise ValueError("gift_recipient is only valid for REMOVED transactions")
            if self.removal_notes is not None:
                raise ValueError("removal_notes is only valid for REMOVED transactions")

        if self.removal_reason == RemovalReason.SELL and self.sale_price_usd is None:
            raise ValueError("sale_price_usd is required when removal_reason is SELL")

        if self.removal_reason == RemovalReason.GIFT and not self.gift_recipient:
            raise ValueError("gift_recipient is required when removal_reason is GIFT")

        # Cross-field: fields only valid for their specific reason
        if self.sale_price_usd is not None and self.removal_reason != RemovalReason.SELL:
            raise ValueError("sale_price_usd is only valid when removal_reason is SELL")

        if self.gift_recipient is not None and self.removal_reason != RemovalReason.GIFT:
            raise ValueError("gift_recipient is only valid when removal_reason is GIFT")

        if self.tasting_notes is not None and self.removal_reason != RemovalReason.DRINK:
            raise ValueError("tasting_notes is only valid when removal_reason is DRINK")

        if self.removal_notes is not None and self.removal_reason != RemovalReason.OTHER:
            raise ValueError("removal_notes is only valid when removal_reason is OTHER")

        return self

    class Settings:
        name = "transactions"

    def __repr__(self) -> str:
        return f"<Transaction(id={self.id}, type={self.transaction_type}, quantity={self.quantity})>"
