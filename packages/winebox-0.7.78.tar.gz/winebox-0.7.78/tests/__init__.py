"""WineBox test suite."""
