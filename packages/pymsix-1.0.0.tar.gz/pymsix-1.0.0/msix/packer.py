"""
msix/packer.py
--------------
Cross-platform MSIX packer using:
  - Windows  : makeappx.exe  (from Windows SDK, auto-detected)
  - Linux    : makemsix      (built from microsoft/msix-packaging via cmake)
  - macOS    : makemsix      (same)

The binary is only built once and cached in ~/.cache/pymsix/.

Signing uses:
  - Windows  : signtool.exe  (from Windows SDK, auto-detected)
  - Linux    : osslsigncode  (installed via package manager)
  - macOS    : osslsigncode  (installed via Homebrew)
"""

from __future__ import annotations

import os
import platform
import shutil
import subprocess
import tempfile

from pathlib import Path
from typing import Optional


MSIX_SDK_REPO = "https://github.com/microsoft/msix-packaging.git"
MSIX_SDK_TAG = "master"
CACHE_DIR = Path.home() / ".cache" / "pymsix"
BINARY_NAME = "makemsix"

DEFAULT_TIMESTAMP_URL = "http://timestamp.digicert.com"

_WIN_SDK_ROOTS = [
    r"C:\Program Files (x86)\Windows Kits\10\bin",
    r"C:\Program Files\Windows Kits\10\bin",
]


def _find_makeappx_windows() -> Optional[Path]:
    """Search common Windows SDK locations for makeappx.exe."""
    for root in _WIN_SDK_ROOTS:
        root_path = Path(root)
        if not root_path.exists():
            continue
        for child in sorted(root_path.iterdir(), reverse=True):
            for arch in ["x64", "x86", "arm64"]:
                candidate = child / arch / "makeappx.exe"
                if candidate.exists():
                    return candidate
    found = shutil.which("makeappx")
    return Path(found) if found else None


def _cached_binary() -> Optional[Path]:
    """Return the cached makemsix binary if it exists."""
    binary = CACHE_DIR / ("makeappx.exe" if platform.system() == "Windows" else BINARY_NAME)
    if binary.exists() and os.access(binary, os.X_OK):
        return binary
    return None


def _build_makemsix() -> Path:
    """
    Clone microsoft/msix-packaging and compile makemsix.
    Requires: git, cmake, a C++ compiler (clang or gcc).
    Returns the path to the compiled binary.
    """
    system = platform.system()
    if system == "Windows":
        raise RuntimeError(
            "Auto-build is not supported on Windows. "
            "Install the Windows 10 SDK to get makeappx.exe:\n"
            "https://developer.microsoft.com/en-us/windows/downloads/windows-sdk/"
        )

    print("[pymsix] makemsix not found — building from source (one-time setup).")
    print("[pymsix] This requires: git, cmake, clang or gcc, libssl-dev, libicu-dev")

    _check_build_dependencies()

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    src_dir = CACHE_DIR / "msix-packaging-src"

    if not src_dir.exists():
        print(f"[pymsix] Cloning {MSIX_SDK_REPO} …")
        _run(["git", "clone", "--depth", "1", "--branch", MSIX_SDK_TAG,
              MSIX_SDK_REPO, str(src_dir)])
    else:
        print("[pymsix] Updating existing clone …")
        _run(["git", "-C", str(src_dir), "pull", "--ff-only"])

    build_dir = src_dir / "build"
    if build_dir.exists():
        shutil.rmtree(build_dir)
    build_dir.mkdir()

    if system in ["Linux", "Darwin"]:
        _cmake_build(src_dir, build_dir)
    else:
        raise RuntimeError(f"Unsupported platform: {system}")

    candidates = [p for p in src_dir.rglob(BINARY_NAME) if p.is_file()]
    if not candidates:
        raise RuntimeError(
            "Build finished but makemsix binary was not found. "
            f"Check build output in: {build_dir}"
        )

    dest = CACHE_DIR / BINARY_NAME
    shutil.copy2(candidates[0], dest)
    dest.chmod(0o755)
    print(f"[pymsix] Binary cached at: {dest}")
    return dest


def _cmake_build(src_dir: Path, build_dir: Path) -> None:
    """Generic cmake configure + build for Linux and macOS."""
    _run([
        "cmake", str(src_dir),
        "-DCMAKE_BUILD_TYPE=Release",
        "-DMSIX_PACK=ON",
        "-DUSE_VALIDATION_PARSER=ON",
    ], cwd=str(build_dir))

    threads = str(os.cpu_count() or 2)
    _run(["make", f"-j{threads}"], cwd=str(build_dir))


def _check_build_dependencies() -> None:
    """Raise if required build tools are missing."""
    if not (shutil.which("clang") or shutil.which("gcc") or shutil.which("cc")):
        print("[pymsix] WARNING: No C++ compiler found (clang/gcc). Build will likely fail.")
    for tool in ["git", "cmake"]:
        if not shutil.which(tool):
            raise RuntimeError(
                f"[pymsix] Required build tool not found: '{tool}'. "
                "Please install it before using pymsix on this platform."
            )


def _resolve_binary(custom_path: Optional[str | Path] = None) -> Path:
    """
    Return the path to the packing binary for this platform.

    Resolution order:
      1. ``custom_path`` argument
      2. ``PYMSIX_BINARY`` environment variable
      3. Already-cached binary  (~/.cache/pymsix/)
      4. Windows SDK makeappx.exe  (Windows only)
      5. Build from source         (Linux / macOS)
    """
    if custom_path is not None:
        p = Path(custom_path)
        if not p.exists():
            raise FileNotFoundError(f"[pymsix] Custom binary not found: {p}")
        if not os.access(p, os.X_OK):
            raise PermissionError(f"[pymsix] Custom binary is not executable: {p}")
        return p

    env_path = os.environ.get("PYMSIX_BINARY")
    if env_path:
        p = Path(env_path)
        if not p.exists():
            raise FileNotFoundError(f"[pymsix] PYMSIX_BINARY points to a non-existent file: {p}")
        if not os.access(p, os.X_OK):
            raise PermissionError(f"[pymsix] PYMSIX_BINARY is not executable: {p}")
        print(f"[pymsix] Using binary from PYMSIX_BINARY: {p}")
        return p

    if platform.system() == "Windows":
        found = _find_makeappx_windows()
        if found:
            return found
        cached = _cached_binary()
        if cached:
            return cached
        raise RuntimeError(
            "makeappx.exe not found. Options:\n"
            "  a) Install the Windows 10 SDK: "
            "https://developer.microsoft.com/en-us/windows/downloads/windows-sdk/\n"
            "  b) Pass the path directly:  MsixPacker(binary=r'C:\\...\\makeappx.exe')\n"
            "  c) Set env var:             set PYMSIX_BINARY=C:\\...\\makeappx.exe"
        )

    cached = _cached_binary()
    if cached:
        return cached
    return _build_makemsix()


def _find_signtool_windows() -> Optional[Path]:
    """Search common Windows SDK locations for signtool.exe."""
    for root in _WIN_SDK_ROOTS:
        root_path = Path(root)
        if not root_path.exists():
            continue
        for child in sorted(root_path.iterdir(), reverse=True):
            for arch in ["x64", "x86", "arm64"]:
                candidate = child / arch / "signtool.exe"
                if candidate.exists():
                    return candidate
    found = shutil.which("signtool")
    return Path(found) if found else None


def _resolve_signing_binary(custom_path: Optional[str | Path] = None) -> Path:
    """
    Return the path to the signing binary for this platform.

    Resolution order:
      1. ``custom_path`` argument
      2. ``PYMSIX_SIGN_BINARY`` environment variable
      3. Windows  → signtool.exe  (auto-detected in Windows SDK)
      4. Linux / macOS → osslsigncode (must be on PATH)
    """
    if custom_path is not None:
        p = Path(custom_path)
        if not p.exists():
            raise FileNotFoundError(f"[pymsix] Custom signing binary not found: {p}")
        if not os.access(p, os.X_OK):
            raise PermissionError(f"[pymsix] Custom signing binary is not executable: {p}")
        return p

    env_path = os.environ.get("PYMSIX_SIGN_BINARY")
    if env_path:
        p = Path(env_path)
        if not p.exists():
            raise FileNotFoundError(f"[pymsix] PYMSIX_SIGN_BINARY points to a non-existent file: {p}")
        if not os.access(p, os.X_OK):
            raise PermissionError(f"[pymsix] PYMSIX_SIGN_BINARY is not executable: {p}")
        print(f"[pymsix] Using signing binary from PYMSIX_SIGN_BINARY: {p}")
        return p

    system = platform.system()

    if system == "Windows":
        found = _find_signtool_windows()
        if found:
            return found
        raise RuntimeError(
            "signtool.exe not found. Options:\n"
            "  a) Install the Windows 10 SDK: "
            "https://developer.microsoft.com/en-us/windows/downloads/windows-sdk/\n"
            "  b) Pass the path directly:  MsixPacker(sign_binary=r'C:\\...\\signtool.exe')\n"
            "  c) Set env var:             set PYMSIX_SIGN_BINARY=C:\\...\\signtool.exe"
        )

    found = shutil.which("osslsigncode")
    if found:
        return Path(found)

    install_hint = (
        "  brew install osslsigncode" if system == "Darwin"
        else "  sudo apt install osslsigncode   # Debian/Ubuntu\n"
             "  sudo dnf install osslsigncode   # Fedora/RHEL"
    )
    raise RuntimeError(
        f"osslsigncode not found. Install it with:\n{install_hint}\n"
        "Or pass the path directly:  MsixPacker(sign_binary='/path/to/osslsigncode')\n"
        "Or set env var:             export PYMSIX_SIGN_BINARY=/path/to/osslsigncode"
    )


def _run(cmd: list[str], cwd: Optional[str] = None) -> None:
    result = subprocess.run(cmd, cwd=cwd, capture_output=False)
    if result.returncode != 0:
        raise RuntimeError(
            f"Command failed (exit {result.returncode}): {' '.join(cmd)}"
        )


class MsixPacker:
    """
    High-level wrapper for creating, extracting, and signing MSIX packages.

    Parameters
    ----------
    binary      : Optional path to ``makeappx.exe`` or ``makemsix``.
                  If omitted, the binary is resolved automatically.
                  Can also be set via the ``PYMSIX_BINARY`` environment variable.
    sign_binary : Optional path to ``signtool.exe`` or ``osslsigncode``.
                  If omitted, the signing binary is resolved automatically.
                  An explicit path passed to ``sign()`` takes precedence over
                  this value. Can also be set via the ``PYMSIX_SIGN_BINARY``
                  environment variable.
    verbose     : Print the command being executed.

    Examples
    --------
    >>> packer = MsixPacker()
    >>> packer = MsixPacker(binary=r"C:\\Tools\\makeappx.exe")
    >>> packer = MsixPacker(binary="/usr/local/bin/makemsix")
    >>> packer = MsixPacker(sign_binary="/usr/local/bin/osslsigncode")
    >>> packer = MsixPacker(
    ...     binary=r"C:\\Tools\\makeappx.exe",
    ...     sign_binary=r"C:\\Tools\\signtool.exe",
    ... )
    """

    def __init__(self, binary: Optional[str | Path] = None, sign_binary: Optional[str | Path] = None, verbose: bool = False):
        self._binary: Optional[Path] = Path(binary) if binary is not None else None
        if self._binary is not None and not self._binary.exists():
            raise FileNotFoundError(f"[pymsix] Binary not found: {self._binary}")

        self._sign_binary: Optional[Path] = Path(sign_binary) if sign_binary is not None else None
        if self._sign_binary is not None and not self._sign_binary.exists():
            raise FileNotFoundError(f"[pymsix] Signing binary not found: {self._sign_binary}")

        self.verbose = verbose

    @property
    def binary(self) -> Path:
        if self._binary is None:
            self._binary = _resolve_binary()
        return self._binary

    @property
    def sign_binary(self) -> Path:
        if self._sign_binary is None:
            self._sign_binary = _resolve_signing_binary()
        return self._sign_binary

    def _exec(self, args: list[str]) -> subprocess.CompletedProcess:
        cmd = [str(self.binary)] + args
        if self.verbose:
            print(f"[pymsix] Running: {' '.join(cmd)}")
        result = subprocess.run(cmd, capture_output=not self.verbose, text=True)
        if result.returncode != 0:
            raise RuntimeError(
                f"msix tool failed (exit {result.returncode}):\n"
                f"STDOUT: {result.stdout or ''}\nSTDERR: {result.stderr or ''}"
            )
        return result

    def pack(self, content_dir: str | Path, output_package: str | Path, *, overwrite: bool = True, skip_validation: bool = False, hash_algorithm: str = "SHA256" ) -> Path:
        """
        Create an MSIX package from a directory.

        Parameters
        ----------
        content_dir     : Directory containing app files + AppxManifest.xml
        output_package  : Path for the resulting .msix file
        overwrite       : Overwrite existing output file (default True)
        skip_validation : Skip semantic validation of manifest
        hash_algorithm  : Hash algorithm for block map (default SHA256)

        Returns
        -------
        Path to the created .msix file.
        """
        content_dir = Path(content_dir)
        output_package = Path(output_package)

        if not content_dir.is_dir():
            raise FileNotFoundError(f"Content directory not found: {content_dir}")

        if platform.system() == "Windows":
            args = ["pack", "/d", str(content_dir), "/p", str(output_package)]
            if overwrite:
                args.append("/o")
            if skip_validation:
                args.append("/nv")
            args += ["/h", hash_algorithm]
        else:
            args = ["pack", "-d", str(content_dir), "-p", str(output_package)]

        self._exec(args)
        print(f"[pymsix] Package created: {output_package}")
        return output_package

    def unpack(self, package: str | Path, output_dir: str | Path, *, overwrite: bool = True, skip_validation: bool = False) -> Path:
        """
        Extract an MSIX package to a directory.

        Parameters
        ----------
        package         : Path to the .msix file
        output_dir      : Directory to extract into
        overwrite       : Overwrite existing output directory (default True, Windows only)
        skip_validation : Skip signature/cert validation (default False).
                          On Windows uses ``/nv``, on Linux/macOS uses ``-ss``.
                          Useful when unpacking packages with untrusted or
                          self-signed certificates.

        Returns
        -------
        Path to the extraction directory.
        """
        package = Path(package)
        output_dir = Path(output_dir)

        if not package.exists():
            raise FileNotFoundError(f"Package not found: {package}")

        output_dir.mkdir(parents=True, exist_ok=True)

        if platform.system() == "Windows":
            args = ["unpack", "/p", str(package), "/d", str(output_dir)]
            if overwrite:
                args.append("/o")
            if skip_validation:
                args.append("/nv")
        else:
            args = ["unpack", "-p", str(package), "-d", str(output_dir)]
            if skip_validation:
                args.append("-ss")

        self._exec(args)
        print(f"[pymsix] Package extracted to: {output_dir}")
        return output_dir

    def sign(self, package: str | Path, pfx: str | Path, *, pfx_password: Optional[str] = None, timestamp_url: str = DEFAULT_TIMESTAMP_URL, digest_algorithm: str = "SHA256") -> Path:
        """
        Sign an MSIX package in-place using a PFX certificate.

        On Windows, ``signtool.exe`` is used (auto-detected from the Windows SDK).
        On Linux and macOS, ``osslsigncode`` is used and must be installed.

        Parameters
        ----------
        package          : Path to the ``.msix`` file to sign.
        pfx              : Path to a ``.pfx`` certificate file.
        pfx_password     : Password for the ``.pfx`` file. Omit if not password-protected.
        timestamp_url    : RFC 3161 timestamp server URL.
                           Defaults to ``http://timestamp.digicert.com``.
                           Set to ``""`` to disable timestamping.
        digest_algorithm : Digest algorithm for the signature (default ``"SHA256"``).

        Returns
        -------
        Path to the signed ``.msix`` file (signed in-place).

        Raises
        ------
        FileNotFoundError  – if the package or pfx file does not exist.
        RuntimeError       – if the signing binary is not found or signing fails.

        Examples
        --------
        >>> packer = MsixPacker(sign_binary="/usr/local/bin/osslsigncode")
        >>> packer.sign("MyApp.msix", "cert.pfx", pfx_password="s3cr3t")
        >>> packer.sign("MyApp.msix", "cert.pfx", timestamp_url="")
        """
        package = Path(package)
        pfx = Path(pfx)

        if not package.exists():
            raise FileNotFoundError(f"[pymsix] Package not found: {package}")
        if not pfx.exists():
            raise FileNotFoundError(f"[pymsix] PFX certificate not found: {pfx}")

        resolved_binary = self.sign_binary

        if platform.system() == "Windows":
            self._sign_signtool(resolved_binary, package, pfx, pfx_password, timestamp_url, digest_algorithm)
        else:
            self._sign_osslsigncode(resolved_binary, package, pfx, pfx_password, timestamp_url, digest_algorithm)

        print(f"[pymsix] Package signed: {package}")
        return package

    def _sign_signtool(self, binary: Path, package: Path, pfx: Path, pfx_password: Optional[str], timestamp_url: str, digest_algorithm: str) -> None:
        """Sign using signtool.exe (Windows)."""
        cmd = [str(binary), "sign", "/fd", digest_algorithm, "/f", str(pfx)]
        if pfx_password is not None:
            cmd += ["/p", pfx_password]
        if timestamp_url:
            cmd += ["/tr", timestamp_url, "/td", digest_algorithm]
        cmd.append(str(package))

        if self.verbose:
            print(f"[pymsix] Running: {' '.join('***' if (i > 0 and cmd[i-1] == '/p') else v for i, v in enumerate(cmd))}")

        result = subprocess.run(cmd, capture_output=not self.verbose, text=True)
        if result.returncode != 0:
            raise RuntimeError(
                f"signtool.exe failed (exit {result.returncode}):\n"
                f"STDOUT: {result.stdout or ''}\nSTDERR: {result.stderr or ''}"
            )

    def _sign_osslsigncode(self, binary: Path, package: Path, pfx: Path, pfx_password: Optional[str], timestamp_url: str, digest_algorithm: str) -> None:
        """Sign using osslsigncode (Linux / macOS). Signs in-place via a temp file."""
        with tempfile.NamedTemporaryFile(suffix=".msix", dir=package.parent, delete=True) as tmp:
            tmp_path = Path(tmp.name)

        if tmp_path.exists():
            tmp_path.unlink()

        try:
            cmd = [
                str(binary), "sign",
                "-pkcs12", str(pfx),
                "-h", digest_algorithm.lower(),
                "-in", str(package),
                "-out", str(tmp_path),
            ]
            if pfx_password is not None:
                cmd += ["-pass", pfx_password]
            if timestamp_url:
                cmd += ["-t", timestamp_url]

            if self.verbose:
                print(f"[pymsix] Running: {' '.join('***' if (i > 0 and cmd[i - 1] == '-pass') else v for i, v in enumerate(cmd))}")

            result = subprocess.run(cmd, capture_output=not self.verbose, text=True)
            if result.returncode != 0:
                raise RuntimeError(
                    f"osslsigncode failed (exit {result.returncode}):\n"
                    f"STDOUT: {result.stdout or ''}\nSTDERR: {result.stderr or ''}"
                )
            shutil.move(str(tmp_path), str(package))
        except Exception:
            if tmp_path.exists():
                tmp_path.unlink()
            raise