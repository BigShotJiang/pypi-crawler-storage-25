# pymsix

Cross-platform Python library for creating, extracting and signing MSIX packages. Wraps `makeappx.exe` (Windows) or `makemsix` (Linux/macOS) — binaries are resolved automatically and built from source if needed.

## Requirements

- Python 3.10+

| Platform | Requirements |
|----------|--------------|
| **Windows** | [Windows 10 SDK](https://developer.microsoft.com/en-us/windows/downloads/windows-sdk/) |
| **Linux** | `git`, `cmake ≥ 3.29.0`, `clang`, `osslsigncode` (for signing) |
| **macOS** | `git`, `cmake ≥ 3.29.0`, `clang` (Xcode CLT), `osslsigncode` (for signing) |

On Linux/macOS, `makemsix` is compiled automatically from [microsoft/msix-packaging](https://github.com/microsoft/msix-packaging) on first use and cached in `~/.cache/pymsix/`.

## Installation
```bash
pip install pymsix
```

## Usage
```python
from msix import MsixPacker

packer = MsixPacker()
packer.pack("path/to/app-content/", "output/MyApp.msix")
packer.unpack("output/MyApp.msix", "path/to/extracted/")
```

The `app-content/` directory must contain a valid `AppxManifest.xml`.

### Signing
```python
packer = MsixPacker(sign_binary="/usr/local/bin/osslsigncode")
packer.sign("output/MyApp.msix", "cert.pfx", pfx_password="s3cr3t")
```

## API

### `MsixPacker(binary=None, sign_binary=None, verbose=False)`

| Parameter | Description |
|-----------|-------------|
| `binary` | Path to `makeappx.exe` or `makemsix`. Auto-resolved if omitted. |
| `sign_binary` | Path to `signtool.exe` (Windows) or `osslsigncode` (Linux/macOS). Auto-resolved if omitted. |
| `verbose` | Print the command being executed. |

### `pack(content_dir, output_package, *, overwrite=True, skip_validation=False, hash_algorithm="SHA256")`

Creates an MSIX package from a directory. Returns the path to the created file.

> **Note:** `overwrite`, `skip_validation`, and `hash_algorithm` are only supported on Windows (`makeappx.exe`). These parameters are silently ignored on Linux and macOS, as `makemsix` does not support them.

### `unpack(package, output_dir, *, overwrite=True)`

Extracts an MSIX package into a directory. Returns the path to the extraction directory.

> **Note:** `overwrite` is only supported on Windows (`makeappx.exe`). These parameter is silently ignored on Linux and macOS, as `makemsix` does not support it.

### `sign(package, pfx, *, pfx_password=None, timestamp_url="http://timestamp.digicert.com", digest_algorithm="SHA256")`

Signs an MSIX package in-place using a PFX certificate. Returns the path to the signed file.

On Windows, `signtool.exe` is used (auto-detected from the Windows SDK). On Linux and macOS, `osslsigncode` must be installed:
```bash
# Debian/Ubuntu
sudo apt install osslsigncode

# Fedora/RHEL
sudo dnf install osslsigncode

# macOS
brew install osslsigncode
```

| Parameter | Description |
|-----------|-------------|
| `package` | Path to the `.msix` file to sign. |
| `pfx` | Path to the `.pfx` certificate file. |
| `pfx_password` | Password for the `.pfx` file. Omit if not password-protected. |
| `timestamp_url` | RFC 3161 timestamp server URL. Set to `""` to disable timestamping. |
| `digest_algorithm` | Digest algorithm for the signature (default `"SHA256"`). |

## Binary Resolution Order

### Pack binary (`makeappx.exe` / `makemsix`)

1. `binary` constructor argument
2. `PYMSIX_BINARY` environment variable
3. Cached binary at `~/.cache/pymsix/`
4. Windows SDK `makeappx.exe` (Windows only)
5. Build from source (Linux/macOS)

### Sign binary (`signtool.exe` / `osslsigncode`)

1. `sign_binary` constructor argument
2. `PYMSIX_SIGN_BINARY` environment variable
3. Windows SDK `signtool.exe` (Windows only)
4. `osslsigncode` on `PATH` (Linux/macOS)

## License

MIT