"""
Streamlit web UI for the DB Optimizer Agent.

Three-step flow:
  Step 1: Test DB connection
  Step 2: Configure LLM provider + depth → Run Analysis (Call 1)
  Step 3: Per-finding Remediate (Call 2)
"""

from __future__ import annotations

import streamlit as st

from db_optimiser_agent.agent import DatabaseOptimizerAgent, PromptTooLargeError
from db_optimiser_agent.adapters.factory import get_adapter
from db_optimiser_agent.config import AgentConfig, DatabaseType, ModelProvider
from db_optimiser_agent.models import AnalysisReport, RemediationScope, Severity

# ---------------------------------------------------------------------------
# Page config
# ---------------------------------------------------------------------------

st.set_page_config(
    page_title="DB Optimizer Agent",
    page_icon="🗄️",
    layout="wide",
)

# Remove Streamlit's default top padding so the title sits near the top.
st.markdown(
    "<style>.block-container{padding-top:0.75rem !important;}</style>",
    unsafe_allow_html=True,
)

st.sidebar.markdown("---")
st.sidebar.markdown("[💬 Give feedback](https://docs.google.com/forms/d/e/1FAIpQLSco0U2l8_ecKPV0YVecGVvZet0dTcTqDKGquematAGMzH9mXA/viewform?usp=dialog)")

st.title("DB Optimizer Agent")
st.caption("AI-powered database performance analysis")
st.warning(
    "⚠️ Beta — your credentials stay in your browser session only and are never stored. "
    "Use your own Anthropic or Google API key."
)

# ---------------------------------------------------------------------------
# Info expander — collapsed once the DB is connected
# ---------------------------------------------------------------------------

_info_expanded = not st.session_state.get("db_connected", False)
with st.expander("What does this tool do?", expanded=_info_expanded):
    st.markdown("""
**DB Optimizer Agent** connects to your PostgreSQL or MySQL database, collects performance
metadata, and uses an AI model (Claude or Gemini) to diagnose issues and generate
ready-to-run SQL fixes.

**Three-step flow:**
1. **Test Connection** — verify the agent can reach your database before spending any API tokens.
2. **Run Analysis** — the agent inspects your schema, indexes, slow queries, and server config,
   then produces a prioritised list of findings ranked by severity (CRITICAL → HIGH → MEDIUM → LOW).
3. **Get Remediation SQL** — for any finding you choose, the agent generates a fix SQL statement
   and a rollback SQL statement to copy and apply at your own pace.

**The agent never writes to your database** — all generated SQL is shown for you to review first.

---

**Analysis depth options:**

| Depth | What it collects | Best for |
|---|---|---|
| **auto** | Scores complexity first, then picks fast / standard / deep automatically | Most users — let the agent decide |
| **fast** | Tables, indexes, slow queries, missing FK indexes, unused indexes | Large databases or quick health checks |
| **standard** | Everything in fast + column statistics + server configuration | Balanced — catches schema and config issues too |
| **deep** | Everything in standard + view definitions + stored function bodies | Full audit — use when you suspect view or function problems |

> **Tip:** Start with **auto**. If the prompt is too large the agent will tell you and suggest
> switching to **fast** or **standard**.
""")

# ---------------------------------------------------------------------------
# Session state initialisation
# ---------------------------------------------------------------------------

if "db_connected" not in st.session_state:
    st.session_state.db_connected = False     # True after a successful connection test
if "db_test_kwargs" not in st.session_state:
    st.session_state.db_test_kwargs = {}      # DB params captured at test time
if "report" not in st.session_state:
    st.session_state.report = None
if "db_ctx" not in st.session_state:
    st.session_state.db_ctx = None
if "agent" not in st.session_state:
    st.session_state.agent = None
if "remediations_loaded" not in st.session_state:
    st.session_state.remediations_loaded = set()
if "_scrub_secrets" not in st.session_state:
    st.session_state._scrub_secrets = []

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _scrub(text: str, *secrets: str) -> str:
    """Replace any secret that appears in an error message with ***."""
    for secret in secrets:
        if secret:
            text = text.replace(secret, "***")
    return text


_SEVERITY_COLOUR = {
    Severity.CRITICAL: "#d32f2f",
    Severity.HIGH:     "#f57c00",
    Severity.MEDIUM:   "#f9a825",
    Severity.LOW:      "#388e3c",
}


def _badge(severity: Severity) -> str:
    colour = _SEVERITY_COLOUR.get(severity, "#555")
    return (
        f'<span style="background:{colour};color:#fff;padding:2px 8px;'
        f'border-radius:4px;font-size:0.75rem;font-weight:700;">'
        f'{severity.value}</span>'
    )


def _count_by_severity(report: AnalysisReport) -> dict[str, int]:
    counts: dict[str, int] = {s.value: 0 for s in Severity}
    for f in report.findings:
        counts[f.severity.value] += 1
    return counts


# ---------------------------------------------------------------------------
# Step 1 — Database connection
# ---------------------------------------------------------------------------

st.subheader("Step 1 — Database Connection")

col1, col2, col3 = st.columns([2, 2, 1])
with col1:
    db_type_label = st.selectbox("DB Type", ["PostgreSQL", "MySQL"], key="sel_db_type")
    db_host = st.text_input("Host", value="localhost", key="inp_db_host")
    default_port = "5432" if db_type_label == "PostgreSQL" else "3306"
    db_port = st.text_input("Port", value=default_port, key="inp_db_port")

with col2:
    db_name = st.text_input("Database name", key="inp_db_name")
    db_user = st.text_input("Username", key="inp_db_user")
    db_password = st.text_input("Password", type="password", key="inp_db_password")

with col3:
    st.markdown("<br>" * 3, unsafe_allow_html=True)  # vertical align with inputs
    test_clicked = st.button("Test Connection", use_container_width=True)

if test_clicked:
    # Validate port
    try:
        port_int = int(db_port)
        if not (1 <= port_int <= 65535):
            st.error(f"Port must be between 1 and 65535, got {port_int}.")
            st.stop()
    except ValueError:
        st.error(f"Port must be a number, got {db_port!r}")
        st.stop()

    if not db_name.strip() or not db_user.strip() or not db_password:
        st.error("Please fill in Database name, Username, and Password.")
        st.stop()

    db_type = DatabaseType.POSTGRES if db_type_label == "PostgreSQL" else DatabaseType.MYSQL

    # Build a minimal config — dummy API key since we're only testing the DB connection.
    try:
        test_config = AgentConfig(
            db_type=db_type,
            db_host=db_host.strip(),
            db_port=port_int,
            db_name=db_name.strip(),
            db_user=db_user.strip(),
            db_password=db_password,
            anthropic_api_key="test-not-used",
        )
    except Exception as exc:
        st.error(f"Configuration error: {_scrub(str(exc), db_password)}")
        st.stop()

    with st.spinner("Testing connection…"):
        try:
            with get_adapter(test_config):
                pass  # connect + immediate close
        except Exception as exc:
            err_msg = _scrub(str(exc), db_password)
            st.session_state.db_connected = False
            if "password" in err_msg.lower() or "auth" in err_msg.lower() or "access denied" in err_msg.lower():
                st.error("Connection failed — check your credentials.")
            else:
                st.error(f"Connection failed: {err_msg}")
            st.stop()

    # Store DB params for reuse in Run Analysis
    st.session_state.db_connected = True
    st.session_state.db_test_kwargs = dict(
        db_type=db_type,
        db_host=db_host.strip(),
        db_port=port_int,
        db_name=db_name.strip(),
        db_user=db_user.strip(),
        db_password=db_password,
    )
    # Clear any previous analysis results when re-testing
    st.session_state.report = None
    st.session_state.db_ctx = None
    st.session_state.agent = None
    st.session_state.remediations_loaded = set()
    st.session_state._scrub_secrets = [db_password]
    st.rerun()

if st.session_state.db_connected:
    kw = st.session_state.db_test_kwargs
    st.success(
        f"Connected to **{kw['db_name']}** on {kw['db_host']}:{kw['db_port']} "
        f"({'PostgreSQL' if kw['db_type'] == DatabaseType.POSTGRES else 'MySQL'})"
    )

# ---------------------------------------------------------------------------
# Step 2 — Analysis settings (only shown after a successful connection test)
# ---------------------------------------------------------------------------

if not st.session_state.db_connected:
    st.stop()

st.divider()
st.subheader("Step 2 — Analysis Settings")

col_a, col_b = st.columns(2)
with col_a:
    provider_label = st.selectbox("Provider", ["Anthropic", "Google"], key="sel_provider")
    api_key = st.text_input("API Key", type="password", key="inp_api_key")

with col_b:
    depth = st.selectbox(
        "Analysis depth",
        ["auto", "fast", "standard", "deep"],
        index=0,
        key="sel_depth",
    )
    extra_context = st.text_area(
        "Extra context (optional)",
        placeholder="e.g. High-traffic OLTP app, tables > 10M rows are orders and order_items",
        key="inp_extra_context",
    )

run_clicked = st.button("Run Analysis", type="primary", use_container_width=True)

# ---------------------------------------------------------------------------
# Run analysis on button click
# ---------------------------------------------------------------------------

if run_clicked:
    if not api_key.strip():
        st.error("Please enter your API key.")
        st.stop()

    provider = ModelProvider.ANTHROPIC if provider_label == "Anthropic" else ModelProvider.GOOGLE
    db_password = st.session_state.db_test_kwargs["db_password"]

    config_kwargs = dict(**st.session_state.db_test_kwargs, provider=provider, analysis_depth=depth)
    if provider == ModelProvider.ANTHROPIC:
        config_kwargs["anthropic_api_key"] = api_key
    else:
        config_kwargs["gemini_api_key"] = api_key

    st.session_state.report = None
    st.session_state.db_ctx = None
    st.session_state.agent = None
    st.session_state.remediations_loaded = set()
    st.session_state._scrub_secrets = [s for s in [db_password, api_key] if s]

    try:
        config = AgentConfig(**config_kwargs)
    except Exception as exc:
        st.error(f"Configuration error: {_scrub(str(exc), db_password, api_key)}")
        st.stop()

    _MAX_EXTRA_CONTEXT = 2_000
    extra_context_clean = extra_context.strip()[:_MAX_EXTRA_CONTEXT]
    if len(extra_context.strip()) > _MAX_EXTRA_CONTEXT:
        st.warning(f"Extra context was trimmed to {_MAX_EXTRA_CONTEXT} characters.")

    with st.spinner("Collecting database metadata…"):
        try:
            with get_adapter(config) as adapter:
                ctx = adapter.collect(extra_context=extra_context_clean, depth=depth)
        except Exception as exc:
            err_msg = _scrub(str(exc), db_password, api_key)
            if "password" in err_msg.lower() or "auth" in err_msg.lower() or "access denied" in err_msg.lower():
                st.error("Database connection failed — check your credentials.")
            else:
                st.error(f"Database connection failed: {err_msg}")
            st.stop()

    st.session_state.db_ctx = ctx

    with st.spinner("Running AI analysis (Call 1)…"):
        try:
            agent = DatabaseOptimizerAgent(config)
            report = agent.analyse(ctx)
        except PromptTooLargeError as exc:
            st.warning(
                f"Prompt too large for the current settings.\n\n{exc}\n\n"
                "**Suggestions:** use a shallower depth (`fast` or `standard`), "
                "or add a `MAX_INPUT_TOKENS` hint in the extra context field."
            )
            st.stop()
        except Exception as exc:
            err_msg = _scrub(str(exc), db_password, api_key)
            if "api_key" in err_msg.lower() or "authentication" in err_msg.lower() or "invalid" in err_msg.lower() or "unauthorized" in err_msg.lower():
                st.error("API key rejected by the provider — check your API key and try again.")
            elif "rate" in err_msg.lower() or "quota" in err_msg.lower():
                st.error("Rate limit or quota exceeded — please wait a moment and try again.")
            else:
                st.error(f"Analysis failed: {err_msg}")
            st.stop()

    st.session_state.agent = agent
    st.session_state.report = report
    st.rerun()

# ---------------------------------------------------------------------------
# Step 3 — Results
# ---------------------------------------------------------------------------

report: AnalysisReport | None = st.session_state.report

if report is None:
    st.info("Configure your API key and depth above, then click **Run Analysis**.")
    st.stop()

st.divider()
st.subheader("Step 3 — Analysis Results")

counts = _count_by_severity(report)
total = len(report.findings)
cols = st.columns(5)
cols[0].metric("Total Findings", total)
cols[1].metric("🔴 Critical", counts["CRITICAL"])
cols[2].metric("🟠 High",     counts["HIGH"])
cols[3].metric("🟡 Medium",   counts["MEDIUM"])
cols[4].metric("🟢 Low",      counts["LOW"])

if report.summary:
    st.info(report.summary)

st.markdown("---")

if not report.findings:
    st.success("No performance issues found!")
    st.stop()

agent: DatabaseOptimizerAgent | None = st.session_state.agent
ctx = st.session_state.db_ctx

for finding in report.findings:
    header = f"{finding.id} — {finding.affected}"
    with st.expander(header, expanded=False):
        # Severity badge — unsafe_allow_html is safe: only enum values interpolated.
        badge_html = _badge(finding.severity)
        st.markdown(
            f"{badge_html} &nbsp; **{finding.category.value}** &nbsp; | "
            f"Risk: `{finding.risk.value}`",
            unsafe_allow_html=True,
        )
        # LLM-generated fields rendered without unsafe_allow_html.
        st.markdown(f"**Root cause:** {finding.root_cause}", unsafe_allow_html=False)
        st.markdown(f"**Impact:** {finding.impact}", unsafe_allow_html=False)

        existing = next((r for r in report.remediations if r.id == finding.id), None)

        if existing is None:
            if st.button(
                f"Get Remediation SQL for {finding.id}",
                key=f"remediate_{finding.id}",
                disabled=(agent is None or ctx is None),
            ):
                with st.spinner(f"Generating SQL fix for {finding.id} (Call 2)…"):
                    try:
                        updated_report = agent.remediate(
                            report=report,
                            ctx=ctx,
                            scope=RemediationScope.IDS,
                            ids=[finding.id],
                        )
                        st.session_state.report = updated_report
                        st.session_state.remediations_loaded.add(finding.id)
                    except PromptTooLargeError as exc:
                        st.warning(
                            f"Prompt too large for remediation: {exc}\n\n"
                            "Try reducing analysis depth."
                        )
                    except Exception as exc:
                        st.error(f"Remediation failed: {_scrub(str(exc), *st.session_state._scrub_secrets)}")
                st.rerun()
        else:
            st.markdown("#### Fix")
            if existing.fix_sql:
                st.code(existing.fix_sql, language="sql")
            elif existing.fix_notes:
                st.info(existing.fix_notes)

            if existing.rollback_sql:
                st.markdown("#### Rollback")
                st.code(existing.rollback_sql, language="sql")
