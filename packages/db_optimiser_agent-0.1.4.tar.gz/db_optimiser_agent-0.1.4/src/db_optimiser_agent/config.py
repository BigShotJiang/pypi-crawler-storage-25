"""
Configuration management for db-optimiser-agent.

All settings are read from environment variables (or a .env file).
"""

from __future__ import annotations

import os
from enum import Enum

from dotenv import find_dotenv, load_dotenv
from pydantic import BaseModel, Field, field_validator, model_validator

load_dotenv(find_dotenv(usecwd=True))  # search from cwd, not from site-packages


class DatabaseType(str, Enum):
    POSTGRES = "postgresql"
    MYSQL = "mysql"


class ModelProvider(str, Enum):
    ANTHROPIC = "anthropic"
    GOOGLE = "google"


class AgentConfig(BaseModel):
    """All runtime configuration for the agent."""

    # --- Provider ---
    provider: ModelProvider = Field(
        default_factory=lambda: ModelProvider(os.getenv("MODEL_PROVIDER", "anthropic"))
    )

    # --- Anthropic ---
    anthropic_api_key: str = Field(default_factory=lambda: os.getenv("ANTHROPIC_API_KEY", ""))
    model: str = Field(
        default_factory=lambda: os.getenv(
            "MODEL",
            "claude-sonnet-4-6" if os.getenv("MODEL_PROVIDER", "anthropic") == "anthropic"
            else "gemini-2.5-flash",
        )
    )
    max_tokens: int = Field(
        default_factory=lambda: int(os.getenv("MAX_TOKENS", "16384"))
    )
    # Maximum tokens allowed in the *input* prompt before pruning kicks in.
    # 60 000 leaves ample headroom inside the 200k context window for output.
    max_input_tokens: int = Field(
        default_factory=lambda: int(os.getenv("MAX_INPUT_TOKENS", "60000"))
    )

    # --- Google Gemini ---
    gemini_api_key: str = Field(default_factory=lambda: os.getenv("GEMINI_API_KEY", ""))

    # --- Database ---
    db_type: DatabaseType = Field(
        default_factory=lambda: DatabaseType(
            os.getenv("DB_TYPE", DatabaseType.POSTGRES.value)
        )
    )
    db_host: str = Field(default_factory=lambda: os.getenv("DB_HOST", "localhost"))
    db_port: int = Field(
        default_factory=lambda: int(os.getenv("DB_PORT", "5432"))
    )
    db_name: str = Field(default_factory=lambda: os.environ["DB_NAME"])
    db_user: str = Field(default_factory=lambda: os.environ["DB_USER"])
    db_password: str = Field(default_factory=lambda: os.environ["DB_PASSWORD"])
    db_schema: str = Field(default_factory=lambda: os.getenv("DB_SCHEMA", "public"))

    # --- Agent behaviour ---
    # Controls which optional collectors run.
    # "auto"     → score from required collectors, then decide
    # "fast"     → tables, indexes, slow queries, missing FKs, unused indexes only
    # "standard" → fast + column_stats + server_config  (default when not auto)
    # "deep"     → standard + views + functions
    analysis_depth: str = Field(
        default_factory=lambda: os.getenv("ANALYSIS_DEPTH", "auto")
    )
    max_findings: int = Field(default=20, ge=1, le=100)
    slow_query_threshold_ms: float = Field(default=100.0, ge=0.0)
    output_format: str = Field(default="markdown")  # "markdown" | "json" | "both"

    @model_validator(mode="before")
    @classmethod
    def resolve_default_model(cls, data: object) -> object:
        if not isinstance(data, dict):
            return data
        if "model" not in data and not os.getenv("MODEL"):
            provider = data.get("provider", os.getenv("MODEL_PROVIDER", "anthropic"))
            provider_str = provider.value if isinstance(provider, ModelProvider) else str(provider)
            data = {
                **data,
                "model": "gemini-2.5-flash" if provider_str == "google" else "claude-sonnet-4-6",
            }
        return data

    @model_validator(mode="after")
    def validate_provider_api_key(self) -> "AgentConfig":
        if self.provider == ModelProvider.ANTHROPIC and not self.anthropic_api_key:
            raise ValueError(
                "ANTHROPIC_API_KEY is not set. "
                "Add it to your .env file or set MODEL_PROVIDER=google to use Gemini."
            )
        if self.provider == ModelProvider.GOOGLE and not self.gemini_api_key:
            raise ValueError(
                "GEMINI_API_KEY is not set. "
                "Add it to your .env file or set MODEL_PROVIDER=anthropic to use Claude."
            )
        return self

    @field_validator("analysis_depth", mode="before")
    @classmethod
    def validate_depth(cls, v: object) -> str:
        allowed = {"auto", "fast", "standard", "deep"}
        s = str(v).lower()
        if s not in allowed:
            raise ValueError(f"analysis_depth must be one of {allowed}, got {v!r}")
        return s

    @field_validator("db_port", mode="before")
    @classmethod
    def coerce_port(cls, v: object) -> int:
        return int(str(v))

    @property
    def db_url(self) -> str:
        """Return a DSN string appropriate for the configured database type."""
        if self.db_type == DatabaseType.POSTGRES:
            return (
                f"postgresql://{self.db_user}:{self.db_password}"
                f"@{self.db_host}:{self.db_port}/{self.db_name}"
            )
        return (
            f"mysql+connector://{self.db_user}:{self.db_password}"
            f"@{self.db_host}:{self.db_port}/{self.db_name}"
        )

    model_config = {"frozen": True}


def load_config() -> AgentConfig:
    """Build and return a validated AgentConfig from the environment."""
    return AgentConfig()
