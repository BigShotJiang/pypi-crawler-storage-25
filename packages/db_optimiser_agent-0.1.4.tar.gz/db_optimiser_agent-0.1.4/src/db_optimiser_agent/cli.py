"""
CLI entry point for db-optimiser-agent.

Commands:
  db-optimiser analyse   — run analysis (Call 1); optionally generate SQL fixes (Call 2)
  db-optimiser ask       — ask the agent a free-form question
  db-optimiser version   — print version info
"""

from __future__ import annotations

import json
import logging
import subprocess
import sys
from pathlib import Path

import typer
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table

from db_optimiser_agent import __version__
from db_optimiser_agent.adapters.factory import get_adapter
from db_optimiser_agent.agent import DatabaseOptimizerAgent, PromptTooLargeError
from db_optimiser_agent.config import load_config
from db_optimiser_agent.models import AnalysisReport, DatabaseContext, RemediationScope, ReportDiff, Severity, diff_reports

app = typer.Typer(
    name="db-optimiser",
    help="AI-powered database performance optimisation agent.",
    add_completion=False,
)
# All human-readable output (panels, tables, status, markdown) goes to stderr
# so that --output json can be safely piped or redirected to a file.
console = Console(stderr=True)
# JSON-only output goes to stdout
json_console = Console(highlight=False)
err_console = Console(stderr=True)


_RUNS_DIR = Path.home() / ".db-optimiser" / "runs"


def _save_report(report: AnalysisReport, output_file: str | None) -> None:
    """Auto-save report JSON to ~/.db-optimiser/runs/ and optionally to output_file."""
    payload = json.dumps(report.model_dump(mode="json"), indent=2, default=str)

    _RUNS_DIR.mkdir(parents=True, exist_ok=True)
    auto_path = _RUNS_DIR / f"{report.db_name}_{report.run_id}.json"
    auto_path.write_text(payload, encoding="utf-8")
    console.print(f"[dim]Report saved → {auto_path}[/dim]")

    if output_file:
        explicit_path = Path(output_file)
        explicit_path.parent.mkdir(parents=True, exist_ok=True)
        explicit_path.write_text(payload, encoding="utf-8")
        console.print(f"[dim]Report saved → {explicit_path}[/dim]")


def _auto_discover_baseline(db_name: str, current_run_id: str) -> AnalysisReport | None:
    """Return the most recent saved report for db_name, excluding the current run."""
    if not _RUNS_DIR.exists():
        return None
    candidates = sorted(
        _RUNS_DIR.glob(f"{db_name}_*.json"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    for path in candidates:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if data.get("run_id") == current_run_id:
                continue
            return AnalysisReport.model_validate(data)
        except Exception:
            continue
    return None


def _load_baseline(since: str, db_name: str, current_run_id: str) -> AnalysisReport | None:
    """
    Load a baseline report for differential analysis.

    since="latest"    → auto-discover the most recent saved report for this DB
    since=<path>      → load that specific file
    """
    if since == "latest":
        baseline = _auto_discover_baseline(db_name, current_run_id)
        if baseline is None:
            err_console.print(
                "[yellow]--since latest: no previous reports found in "
                f"{_RUNS_DIR} for database '{db_name}'. Skipping diff.[/yellow]"
            )
        return baseline

    path = Path(since)
    if not path.exists():
        err_console.print(f"[red]--since: file not found: {path}[/red]")
        raise typer.Exit(1)
    try:
        return AnalysisReport.model_validate(json.loads(path.read_text(encoding="utf-8")))
    except Exception as e:
        err_console.print(f"[red]--since: could not parse {path}: {e}[/red]")
        raise typer.Exit(1)


def _print_diff(diff: ReportDiff) -> None:
    baseline_date = diff.baseline_analysed_at.strftime("%Y-%m-%d %H:%M")
    header = (
        f"Changes since run [bold]{diff.baseline_run_id}[/bold] ({baseline_date})  "
        f"[green]▲ {len(diff.new)} new[/green]  "
        f"[red]▼ {len(diff.resolved)} resolved[/red]  "
        f"[yellow]~ {len(diff.changed)} changed[/yellow]"
    )
    console.print()
    console.print(Panel(header, title="[bold]Differential[/bold]", expand=False))

    if diff.new:
        console.print("[green bold]New findings:[/green bold]")
        for f in diff.new:
            console.print(f"  [green]+[/green] [{_severity_colour(f.severity)}]{f.id} {f.severity.value}[/] {f.category.value} — {f.affected}")

    if diff.resolved:
        console.print("[red bold]Resolved findings:[/red bold]")
        for f in diff.resolved:
            console.print(f"  [red]-[/red] [{_severity_colour(f.severity)}]{f.id} {f.severity.value}[/] {f.category.value} — {f.affected}")

    if diff.changed:
        console.print("[yellow bold]Changed findings:[/yellow bold]")
        for c in diff.changed:
            sev_change = (
                f"{c.baseline.severity.value} → {c.current.severity.value}"
                if c.baseline.severity != c.current.severity else ""
            )
            risk_change = (
                f"risk {c.baseline.risk.value} → {c.current.risk.value}"
                if c.baseline.risk != c.current.risk else ""
            )
            detail = ", ".join(filter(None, [sev_change, risk_change]))
            console.print(f"  [yellow]~[/yellow] [{_severity_colour(c.current.severity)}]{c.current.id} {c.current.category.value}[/] — {c.current.affected} ([yellow]{detail}[/yellow])")


def _severity_colour(s: Severity) -> str:
    return {
        Severity.CRITICAL: "bold red",
        Severity.HIGH: "red",
        Severity.MEDIUM: "yellow",
        Severity.LOW: "dim",
    }[s]


@app.command()
def analyse(
    extra_context: str = typer.Option(
        "",
        "--context", "-c",
        help="Extra context to pass to the agent (e.g. 'this is a read-heavy OLAP workload').",
    ),
    output: str = typer.Option(
        "markdown",
        "--output", "-o",
        help="Output format: markdown | json | both",
    ),
    stream: bool = typer.Option(
        False,
        "--stream",
        help="Stream the raw markdown response as it arrives (analysis only).",
    ),
    remediate: bool = typer.Option(
        False,
        "--remediate", "-r",
        help="Run Call 2 after analysis to generate fix SQL for selected findings.",
    ),
    top: int = typer.Option(
        5,
        "--top",
        help="With --remediate: generate SQL for the top N findings by severity.",
        min=1,
    ),
    full: bool = typer.Option(
        False,
        "--full",
        help="With --remediate: generate SQL for ALL findings (overrides --top).",
    ),
    finding_ids: str = typer.Option(
        "",
        "--ids",
        help="With --remediate: comma-separated finding IDs to remediate (e.g. FIND-001,FIND-003).",
    ),
    depth: str = typer.Option(
        "",
        "--depth", "-d",
        help=(
            "Collection depth: auto | fast | standard | deep. "
            "Overrides ANALYSIS_DEPTH from .env. "
            "'auto' scores complexity from required collectors and decides automatically."
        ),
    ),
    output_file: str = typer.Option(
        "",
        "--output-file", "-f",
        help="Also write the JSON report to this file path (auto-save to ~/.db-optimiser/runs/ always happens).",
    ),
    since: str = typer.Option(
        "",
        "--since",
        help=(
            "Compare results against a previous report. "
            "Pass a file path or 'latest' to auto-discover the most recent "
            "saved report for this database in ~/.db-optimiser/runs/."
        ),
    ),
    model: str = typer.Option(
        "",
        "--model", "-m",
        help=(
            "Override the model from .env. "
            "Anthropic: claude-sonnet-4-6, claude-opus-4-7. "
            "Google: gemini-2.5-flash, gemini-2.5-pro."
        ),
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Run a full optimisation analysis against the configured database."""
    if verbose:
        logging.basicConfig(level=logging.DEBUG)

    try:
        config = load_config()
    except Exception as e:
        err_console.print(f"[red]Configuration error:[/red] {e}")
        err_console.print("Make sure your .env file is set up correctly (see .env.example).")
        raise typer.Exit(1)

    if model:
        config = config.model_copy(update={"model": model})

    # CLI --depth overrides config; fall back to config value (default "auto")
    effective_depth = depth.lower() if depth else config.analysis_depth

    console.print(
        Panel(
            f"[bold]db-optimiser-agent[/bold] v{__version__}\n"
            f"Provider: [cyan]{config.provider.value}[/cyan]  |  "
            f"Model: [cyan]{config.model}[/cyan]  |  "
            f"DB: [cyan]{config.db_type.value}/{config.db_name}[/cyan]  |  "
            f"Depth: [cyan]{effective_depth}[/cyan]",
            expand=False,
        )
    )

    # --- Collect database context ---
    try:
        with console.status("[bold green]Connecting to database…[/bold green]"):
            with get_adapter(config) as adapter:
                ctx = adapter.collect(extra_context=extra_context, depth=effective_depth)
    except Exception as e:
        err_console.print(f"[red]Database connection error:[/red] {e}")
        raise typer.Exit(1)

    agent = DatabaseOptimizerAgent(config)

    # --- Streaming mode (analysis only) ---
    if stream:
        console.print("\n[bold]Streaming analysis…[/bold]\n")
        try:
            for chunk in agent.analyse_streaming(ctx):
                console.print(chunk, end="")
        except PromptTooLargeError as e:
            err_console.print(f"\n[red]Prompt too large:[/red] {e}")
            raise typer.Exit(1)
        console.print()
        return

    # --- Call 1: Analysis ---
    try:
        with console.status("[bold green]Analysing database (Call 1)…[/bold green]"):
            report = agent.analyse(ctx)
    except PromptTooLargeError as e:
        err_console.print(f"[red]Prompt too large:[/red] {e}")
        raise typer.Exit(1)

    # --- Summary panel ---
    console.print()
    console.print(Panel(report.summary, title=f"[bold]Run {report.run_id}[/bold]", expand=False))

    # --- Findings table ---
    if report.findings:
        table = Table(title="Findings", show_lines=True)
        table.add_column("ID", style="bold", width=10)
        table.add_column("Severity", width=10)
        table.add_column("Category", width=16)
        table.add_column("Affected", width=24)
        table.add_column("Risk", width=12)
        table.add_column("Root cause")

        for f in report.findings:
            table.add_row(
                f.id,
                f"[{_severity_colour(f.severity)}]{f.severity.value}[/]",
                f.category.value,
                f.affected,
                f.risk.value,
                f.root_cause[:80] + ("…" if len(f.root_cause) > 80 else ""),
            )
        console.print(table)

    # --- Quick wins ---
    if report.quick_wins:
        console.print("\n[bold green]Quick wins (safe to apply now):[/bold green]")
        for qw_id in report.quick_wins:
            finding = next((f for f in report.findings if f.id == qw_id), None)
            if finding:
                console.print(f"  [green]OK[/green] {qw_id} - {finding.affected}")

    # --- Call 2: Remediation (optional) ---
    if remediate and report.findings:
        if finding_ids:
            scope = RemediationScope.IDS
            ids_list = [i.strip().upper() for i in finding_ids.split(",") if i.strip()]
        elif full:
            scope = RemediationScope.FULL
            ids_list = None
        else:
            scope = RemediationScope.TOP_N
            ids_list = None

        scope_label = (
            f"IDs: {finding_ids}" if scope == RemediationScope.IDS
            else ("all findings" if scope == RemediationScope.FULL else f"top {top}")
        )
        with console.status(
            f"[bold green]Generating SQL fixes (Call 2 — {scope_label})…[/bold green]"
        ):
            report = agent.remediate(report, ctx, scope=scope, n=top, ids=ids_list)

        if report.remediations:
            console.print(f"\n[bold]Remediations ({len(report.remediations)} findings):[/bold]")
            for r in report.remediations:
                console.print(
                    f"\n[{_severity_colour(r.severity)}]"
                    f"[bold]{r.id}[/bold] — {r.affected}[/]"
                )
                if r.fix_sql:
                    console.print(Markdown(f"```sql\n{r.fix_sql}\n```"))
                elif r.fix_notes:
                    console.print(Markdown(r.fix_notes))
                if r.rollback_sql:
                    console.print("[dim]Rollback:[/dim]")
                    console.print(Markdown(f"```sql\n{r.rollback_sql}\n```"))

    # --- Full markdown output ---
    if output in ("markdown", "both"):
        console.print("\n[bold]Full analysis report:[/bold]")
        console.print(Markdown(report.raw_markdown))
        if report.remediation_markdown:
            console.print("\n[bold]Full remediation report:[/bold]")
            console.print(Markdown(report.remediation_markdown))

    if output in ("json", "both"):
        json_console.print_json(
            json.dumps(report.model_dump(mode="json"), indent=2, default=str)
        )

    _save_report(report, output_file or None)

    if since:
        baseline = _load_baseline(since, report.db_name, report.run_id)
        if baseline is not None:
            _print_diff(diff_reports(baseline, report))


@app.command()
def ask(
    question: str = typer.Argument(..., help="Question to ask the agent."),
    with_context: bool = typer.Option(
        False,
        "--with-context",
        help="Include current DB config as context.",
    ),
    model: str = typer.Option(
        "",
        "--model", "-m",
        help="Override the model from .env.",
    ),
) -> None:
    """Ask the agent a free-form question about your database."""
    try:
        config = load_config()
    except Exception as e:
        err_console.print(f"[red]Configuration error:[/red] {e}")
        raise typer.Exit(1)

    if model:
        config = config.model_copy(update={"model": model})

    agent = DatabaseOptimizerAgent(config)

    ctx = None
    if with_context:
        ctx = DatabaseContext(
            db_type=config.db_type.value,
            db_name=config.db_name,
            schema_name=config.db_schema,
        )

    with console.status("[bold green]Thinking…[/bold green]"):
        answer = agent.ask(question, ctx)

    console.print(Markdown(answer))


@app.command()
def ui() -> None:
    """Launch the Streamlit web UI in your browser."""
    app_path = Path(__file__).parent / "app.py"
    try:
        subprocess.run(["streamlit", "run", str(app_path)], check=True)
    except FileNotFoundError:
        console.print(
            "[red]Streamlit is not installed.[/red] "
            "Run: [bold]pip install 'db-optimiser-agent[web]'[/bold]"
        )
        raise typer.Exit(1)


@app.command()
def version() -> None:
    """Print version information."""
    console.print(f"db-optimiser-agent [bold]{__version__}[/bold]")


def main() -> None:  # pragma: no cover
    app()


if __name__ == "__main__":
    main()
