"""
Abstract base class for database adapters.

Every adapter must implement all five collection methods.
The `collect()` method orchestrates them and returns a populated DatabaseContext.
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import Any

from db_optimiser_agent.models import DatabaseContext

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Complexity scoring
# ---------------------------------------------------------------------------

def _score_complexity(
    tables: list[dict],
    slow_queries: list[dict],
    missing_fk_indexes: list[dict],
    unused_indexes: list[dict],
) -> str:
    """
    Derive an analysis depth from the five required collectors.

    Scoring rationale:
      - Each table counts as 1 (schema surface area)
      - Each slow query counts as 2 (most diagnostic value, drives output size)
      - Missing FK indexes and unused indexes each count as 1

    Thresholds (tunable):
      score ≤ 12  → "fast"     (tiny db, minimal optional context needed)
      score ≤ 35  → "standard" (typical SMB db)
      score  > 35 → "deep"     (complex db, include views + functions)
    """
    score = (
        len(tables)
        + len(slow_queries) * 2
        + len(missing_fk_indexes)
        + len(unused_indexes)
    )

    # Floor: pg_stat_statements may be absent, producing 0 slow queries and
    # under-counting the score for a large database.  A 200-table schema with
    # no slow query data would otherwise score ≤ 12 and be treated as "fast".
    # Force at least "standard" whenever the schema surface is non-trivial.
    if len(tables) > 30 or len(unused_indexes) > 20:
        score = max(score, 13)

    if score <= 12:
        return "fast"
    if score <= 35:
        return "standard"
    return "deep"


class BaseAdapter(ABC):
    """
    Contract that all database adapters must satisfy.
    Subclasses implement the five _collect_* methods; the base class
    orchestrates them and assembles the DatabaseContext.
    """

    db_type: str = ""  # set by subclasses: "postgresql" | "mysql"

    def __init__(
        self,
        host: str,
        port: int,
        dbname: str,
        user: str,
        password: str,
        schema: str = "public",
        slow_query_threshold_ms: float = 100.0,
    ) -> None:
        self.host = host
        self.port = port
        self.dbname = dbname
        self.user = user
        self.password = password
        self.schema = schema
        self.slow_query_threshold_ms = slow_query_threshold_ms
        self._conn: Any = None

    # ------------------------------------------------------------------
    # Connection lifecycle
    # ------------------------------------------------------------------

    @abstractmethod
    def connect(self) -> None:
        """Open a database connection and store it in self._conn."""

    @abstractmethod
    def close(self) -> None:
        """Close the database connection cleanly."""

    def __enter__(self) -> "BaseAdapter":
        self.connect()
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    # ------------------------------------------------------------------
    # Collection methods — implemented per database
    # ------------------------------------------------------------------

    @abstractmethod
    def _collect_tables(self) -> list[dict[str, Any]]:
        """
        Return a list of table summaries.
        Each dict must contain: name, row_count, size.
        """

    @abstractmethod
    def _collect_indexes(self) -> list[dict[str, Any]]:
        """
        Return a list of all indexes.
        Each dict must contain: name, table, columns, scans, size.
        """

    @abstractmethod
    def _collect_slow_queries(self) -> list[dict[str, Any]]:
        """
        Return the top slow queries ranked by total execution time.
        Each dict must contain: query, mean_ms, calls, total_ms.
        """

    @abstractmethod
    def _collect_missing_fk_indexes(self) -> list[dict[str, Any]]:
        """
        Return foreign keys that have no supporting index.
        Each dict must contain: table, column, references.
        """

    @abstractmethod
    def _collect_unused_indexes(self) -> list[dict[str, Any]]:
        """
        Return indexes with zero or very low usage.
        Each dict must contain: name, table, scans, size.
        """

    # Optional collectors — subclasses override where supported
    def _collect_views(self) -> list[dict[str, Any]]:
        """Return view definitions. Each dict: name, definition."""
        return []

    def _collect_functions(self) -> list[dict[str, Any]]:
        """Return user-defined function definitions. Each dict: name, arguments, definition."""
        return []

    def _collect_column_stats(self) -> list[dict[str, Any]]:
        """Return column type/constraint details for schema issue detection."""
        return []

    def _collect_server_config(self) -> list[dict[str, Any]]:
        """Return relevant server configuration settings."""
        return []

    # ------------------------------------------------------------------
    # Orchestrator
    # ------------------------------------------------------------------

    def collect(self, extra_context: str = "", depth: str = "standard") -> DatabaseContext:
        """
        Run collectors and return a populated DatabaseContext.

        ``depth`` controls which optional collectors are executed:

        * ``"fast"``     — required collectors only (tables, indexes, slow queries,
                           missing FK indexes, unused indexes)
        * ``"standard"`` — fast + column_stats + server_config
        * ``"deep"``     — standard + views + functions
        * ``"auto"``     — run required collectors first, score complexity,
                           then run optional collectors appropriate for that score

        Each collector is called independently; a failure in one does not abort
        the others.
        """
        logger.info(
            "Collecting context from %s db=%s schema=%s depth=%s",
            self.db_type, self.dbname, self.schema, depth,
        )

        def _safe(name: str, fn: Any) -> list[dict[str, Any]]:
            try:
                result = fn()
                logger.debug("%s returned %d rows", name, len(result))
                return result
            except Exception as exc:
                logger.warning("%s failed: %s", name, exc)
                return []

        # --- Required collectors (always run) ---
        tables           = _safe("_collect_tables",           self._collect_tables)
        indexes          = _safe("_collect_indexes",          self._collect_indexes)
        slow_queries     = _safe("_collect_slow_queries",     self._collect_slow_queries)
        missing_fk       = _safe("_collect_missing_fk_indexes", self._collect_missing_fk_indexes)
        unused_indexes   = _safe("_collect_unused_indexes",   self._collect_unused_indexes)

        # --- Auto-detect depth from required results ---
        if depth == "auto":
            depth = _score_complexity(tables, slow_queries, missing_fk, unused_indexes)
            logger.info("Auto depth resolved to '%s'", depth)

        # --- Optional collectors, gated by depth ---
        column_stats  = _safe("_collect_column_stats",  self._collect_column_stats)  if depth in ("standard", "deep") else []
        server_config = _safe("_collect_server_config", self._collect_server_config) if depth in ("standard", "deep") else []
        views         = _safe("_collect_views",         self._collect_views)         if depth == "deep" else []
        functions     = _safe("_collect_functions",     self._collect_functions)     if depth == "deep" else []

        logger.info(
            "Collection complete: tables=%d indexes=%d slow_queries=%d "
            "unused=%d missing_fk=%d column_stats=%d views=%d functions=%d",
            len(tables), len(indexes), len(slow_queries),
            len(unused_indexes), len(missing_fk),
            len(column_stats), len(views), len(functions),
        )

        return DatabaseContext(
            db_type=self.db_type,
            db_name=self.dbname,
            schema_name=self.schema,
            tables=tables,
            indexes=indexes,
            slow_queries=slow_queries,
            missing_fk_indexes=missing_fk,
            unused_indexes=unused_indexes,
            column_stats=column_stats,
            server_config=server_config,
            views=views,
            functions=functions,
            extra_context=extra_context,
        )
