from __future__ import annotations

import json
from typing import Any, cast

import httpx

from f69.errors import F69EdgeError
from f69.types import (
    EvaluateRequest,
    EvaluateResponse,
    HealthResponse,
    IdentifyRequest,
    IdentifyResponse,
)


def _normalize_base_url(base_url: str) -> str:
    return base_url.rstrip("/")


def _read_json_body(text: str) -> Any:
    if not text:
        return None
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return text


class F69EdgeClient:
    """Client for the f69-edge HTTP API."""

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        client: httpx.Client | None = None,
    ) -> None:
        self._base_url = _normalize_base_url(base_url)
        self._api_key = api_key
        self._own_client = client is None
        self._client = client if client is not None else httpx.Client()

    def close(self) -> None:
        if self._own_client:
            self._client.close()

    def __enter__(self) -> F69EdgeClient:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    def _auth_headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self._api_key}",
            "Accept": "application/json",
        }

    def _request_json(
        self,
        method: str,
        path: str,
        *,
        body: Any | None = None,
        auth: bool = False,
    ) -> Any:
        url = f"{self._base_url}{path}"
        headers: dict[str, str] = {"Accept": "application/json"}
        if auth:
            headers.update(self._auth_headers())
        content: str | None = None
        if body is not None:
            headers["Content-Type"] = "application/json"
            content = json.dumps(body)

        response = self._client.request(method, url, headers=headers, content=content)
        text = response.text
        parsed = _read_json_body(text)

        if not response.is_success:
            msg = "HTTP %s" % response.status_code
            if isinstance(parsed, dict) and "error" in parsed:
                err_val = parsed["error"]
                if isinstance(err_val, str):
                    msg = err_val
            raise F69EdgeError(
                msg,
                status=response.status_code,
                url=url,
                body=parsed,
            )
        return parsed

    def health(self) -> HealthResponse:
        """GET /health - no API key."""
        out = self._request_json("GET", "/health")
        return cast(HealthResponse, out)

    def open_api_document(self) -> Any:
        """GET /openapi.json - no API key."""
        return self._request_json("GET", "/openapi.json")

    def identify(self, body: IdentifyRequest) -> IdentifyResponse:
        """POST /v1/identify - upsert entity for the workspace tied to the API key."""
        payload: dict[str, Any] = {
            "type": body["type"],
            "external_id": body["external_id"],
            "attributes": body.get("attributes", {}),
        }
        out = self._request_json("POST", "/v1/identify", body=payload, auth=True)
        return cast(IdentifyResponse, out)

    def evaluate(self, body: EvaluateRequest) -> EvaluateResponse:
        """POST /v1/evaluate - return every flag in the token's environment.

        The request body only carries the entity's external ``id`` and
        ``type``. The server looks up the entity (it must have been identified
        first via ``/v1/identify``; otherwise a ``404`` is raised) and uses
        its stored attributes during evaluation. The response is a list where
        each entry has ``key``, ``value``, ``reason`` (one of
        ``TARGETING_MATCH`` / ``SPLIT`` / ``DEFAULT`` / ``FALLBACK`` /
        ``ERROR``), and a manifest ``version`` string.
        """
        payload: dict[str, Any] = {
            "id": body["id"],
            "type": body["type"],
        }
        out = self._request_json("POST", "/v1/evaluate", body=payload, auth=True)
        return cast(EvaluateResponse, out)
