from __future__ import annotations

from typing import Literal, TypedDict

JsonValue = (
    None | bool | int | float | str | list["JsonValue"] | dict[str, "JsonValue"]
)


class _IdentifyRequestBase(TypedDict):
    type: str
    external_id: str


class IdentifyRequest(_IdentifyRequestBase, total=False):
    attributes: dict[str, JsonValue]


class IdentifyResponse(TypedDict):
    id: str
    type: str
    external_id: str
    attributes: dict[str, JsonValue]


class EvaluateRequest(TypedDict):
    """Evaluate request body: only the entity's external `id` and `type`.

    The server looks up the entity in the token's environment (it must have
    been identified first via ``POST /v1/identify``) and uses its stored
    attributes during evaluation.
    """

    id: str
    type: str


EvaluationReason = Literal[
    "TARGETING_MATCH",
    "SPLIT",
    "DEFAULT",
    "FALLBACK",
    "ERROR",
]


class EvaluatedFlag(TypedDict):
    """A single evaluated flag in the response list."""

    key: str
    value: bool
    reason: EvaluationReason
    version: str


EvaluateResponse = list[EvaluatedFlag]


class HealthResponse(TypedDict, total=False):
    ok: bool
    service: str
