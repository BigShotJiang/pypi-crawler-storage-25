from __future__ import annotations

from typing import Any


class F69EdgeError(Exception):
    """Raised when the edge API returns a non-2xx response."""

    def __init__(
        self,
        message: str,
        *,
        status: int,
        url: str,
        body: Any | None = None,
    ) -> None:
        super().__init__(message)
        self.status = status
        self.url = url
        self.body = body
