import json
import sys
from pathlib import Path

import httpx
import pytest

source_path = str(Path(__file__).parent.parent / "src")
sys.path.append(source_path)


from f69 import (  # noqa: E402 # pyright: ignore[reportMissingImports]
    F69EdgeClient,
    F69EdgeError,
)


def test_evaluate_sends_id_and_type_and_parses_list() -> None:
    expected = [
        {"key": "a", "value": True, "reason": "TARGETING_MATCH", "version": "live"},
        {"key": "b", "value": False, "reason": "DEFAULT", "version": "live"},
    ]

    def handler(request: httpx.Request) -> httpx.Response:
        assert str(request.url) == "http://edge.test/v1/evaluate"
        assert request.method == "POST"
        body = json.loads(request.content.decode())
        assert "context" not in body
        assert "keys" not in body
        assert body["id"] == "u1"
        assert body["type"] == "user"
        return httpx.Response(200, json=expected)

    transport = httpx.MockTransport(handler)
    client = httpx.Client(transport=transport)
    edge = F69EdgeClient(
        base_url="http://edge.test",
        api_key="00000000-0000-0000-0000-000000000001.secret",
        client=client,
    )
    try:
        out = edge.evaluate({"id": "u1", "type": "user"})
        assert out == expected
    finally:
        edge.close()


def test_raises_f69_edge_error_with_server_message() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            400,
            json={"error": "nope"},
            headers={"Content-Type": "application/json"},
        )

    transport = httpx.MockTransport(handler)
    client = httpx.Client(transport=transport)
    edge = F69EdgeClient(base_url="http://edge.test/", api_key="k", client=client)
    try:
        with pytest.raises(F69EdgeError) as exc_info:
            edge.identify({"type": "x", "external_id": "y"})
        err = exc_info.value
        assert err.status == 400
        assert str(err) == "nope"
    finally:
        edge.close()
