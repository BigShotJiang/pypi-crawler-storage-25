"""
Navigation menu items for NetBox Catalyst Center Plugin
"""

from netbox.plugins import PluginMenu, PluginMenuItem

menu = PluginMenu(
    label="Catalyst Center",
    groups=(
        (
            "Devices",
            (
                PluginMenuItem(
                    link="plugins:netbox_catalyst_center:import_page",
                    link_text="Import Devices",
                    permissions=["dcim.add_device"],
                ),
                PluginMenuItem(
                    link="plugins:netbox_catalyst_center:comparison",
                    link_text="Inventory Comparison",
                    permissions=["dcim.view_device"],
                ),
            ),
        ),
        (
            "Configs",
            (
                PluginMenuItem(
                    link="plugins:netbox_catalyst_center:config_diff",
                    link_text="Config Diff",
                    permissions=["dcim.view_device"],
                ),
                PluginMenuItem(
                    link="plugins:netbox_catalyst_center:config_audit",
                    link_text="Config Audit",
                    permissions=["dcim.view_device"],
                ),
                PluginMenuItem(
                    link="plugins:netbox_catalyst_center:neighbor_discovery",
                    link_text="Neighbor Discovery",
                    permissions=["dcim.view_device"],
                ),
            ),
        ),
        (
            "Settings",
            (
                PluginMenuItem(
                    link="plugins:netbox_catalyst_center:settings",
                    link_text="Configuration",
                    permissions=["netbox_catalyst_center.configure_catalystcenter"],
                ),
            ),
        ),
    ),
    icon_class="mdi mdi-lan",
)
