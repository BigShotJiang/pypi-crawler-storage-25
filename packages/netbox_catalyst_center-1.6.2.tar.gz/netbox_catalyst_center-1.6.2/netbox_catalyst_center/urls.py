"""
URL patterns for NetBox Catalyst Center Plugin
"""

from django.urls import path

from .views import (
    ENDPOINTS_PLUGIN_INSTALLED,
    AddDeviceToInventoryView,
    AddDeviceToPnPView,
    AssignPrimaryIPView,
    CatalystCenterSettingsView,
    ConfigAuditView,
    ConfigDiffView,
    CreateCablesView,
    DeviceCatalystCenterContentView,
    ExportPnPCSVView,
    ImportDevicesView,
    ImportPageView,
    InventoryComparisonView,
    NeighborDiscoveryView,
    SearchDevicesView,
    SyncDeviceFromDNACView,
    TestConnectionView,
)

urlpatterns = [
    path("settings/", CatalystCenterSettingsView.as_view(), name="settings"),
    path("import/", ImportPageView.as_view(), name="import_page"),
    path("comparison/", InventoryComparisonView.as_view(), name="comparison"),
    path("test-connection/", TestConnectionView.as_view(), name="test_connection"),
    path("sync-device/<int:pk>/", SyncDeviceFromDNACView.as_view(), name="sync_device"),
    path("search-devices/", SearchDevicesView.as_view(), name="search_devices"),
    path("import-devices/", ImportDevicesView.as_view(), name="import_devices"),
    path("device/<int:pk>/content/", DeviceCatalystCenterContentView.as_view(), name="device_content"),
    path("add-to-pnp/<int:pk>/", AddDeviceToPnPView.as_view(), name="add_to_pnp"),
    path("add-to-inventory/<int:pk>/", AddDeviceToInventoryView.as_view(), name="add_to_inventory"),
    path("export-pnp-csv/", ExportPnPCSVView.as_view(), name="export_pnp_csv"),
    path("diff/", ConfigDiffView.as_view(), name="config_diff"),
    path("audit/", ConfigAuditView.as_view(), name="config_audit"),
    path("neighbors/", NeighborDiscoveryView.as_view(), name="neighbor_discovery"),
    path("create-cables/", CreateCablesView.as_view(), name="create_cables"),
    path("assign-ip/<int:pk>/", AssignPrimaryIPView.as_view(), name="assign_primary_ip"),
]

# Add endpoint URLs if netbox_endpoints is installed
if ENDPOINTS_PLUGIN_INSTALLED:
    from .views import EndpointCatalystCenterContentView, SyncEndpointFromDNACView

    urlpatterns.extend(
        [
            path("endpoint/<int:pk>/content/", EndpointCatalystCenterContentView.as_view(), name="endpoint_content"),
            path("sync-endpoint/<int:pk>/", SyncEndpointFromDNACView.as_view(), name="sync_endpoint"),
        ]
    )
