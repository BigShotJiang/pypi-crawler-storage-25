Models
======


These models are used for argument and return value validation. They are based on the `pydantic <https://pydantic-docs.helpmanual.io/>`_ package.

Definitions
-----------

.. automodule:: avatars.models
   :members:
   :undoc-members:


.. autoclass:: avatar_yaml.models.parameters.AlignmentMethod
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: avatar_yaml.models.parameters.ExcludeVariablesMethod
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: avatar_yaml.models.parameters.ImputeMethod
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: avatar_yaml.models.parameters.ProjectionType
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: avatar_yaml.models.schema.ColumnType
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: avatar_yaml.models.schema.LinkMethod
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: avatars.constants.PlotKind
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: avatars.constants.Results
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: avatar_yaml.models.parameters.AugmentationStrategy
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: avatar_yaml.models.parameters.AvatarizationProcessorParameters
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: avatar_yaml.models.parameters.InterRecordRangeDifferenceParameters
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: avatar_yaml.models.parameters.RelativeDifferenceParameters
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: avatar_yaml.models.avatar_metadata.SensitivityLevel
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: avatar_yaml.models.avatar_metadata.DataType
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: avatar_yaml.models.avatar_metadata.DataSubject
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: avatar_yaml.models.avatar_metadata.DataRecipient
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: avatar_yaml.models.schema.PiiType
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: avatar_yaml.models.schema.FakeDataStrategy
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: avatar_yaml.models.schema.HashSha256Strategy
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: avatar_yaml.models.schema.Uuid4Strategy
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: avatar_yaml.models.schema.ConstantStrategy
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: avatar_yaml.models.schema.IntegerStrategy
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: avatar_yaml.models.schema.SpecificIdLetterCase
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: avatar_yaml.models.schema.SpecificIdStrategy
   :members:
   :undoc-members:
   :show-inheritance:
