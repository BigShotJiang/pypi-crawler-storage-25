__version__ = "1.23.0"

# Re-export main public entry points for convenience so users can do for example:
# from avatars import Manager, Runner, ApiClient
# Auto-install the crash handler for enhanced error reporting
from avatar_yaml import ConstantStrategy as ConstantStrategy  # noqa: F401
from avatar_yaml import FakeDataStrategy as FakeDataStrategy  # noqa: F401
from avatar_yaml import HashSha256Strategy as HashSha256Strategy  # noqa: F401
from avatar_yaml import IntegerStrategy as IntegerStrategy  # noqa: F401
from avatar_yaml import PiiType as PiiType  # noqa: F401
from avatar_yaml import PseudonymizationStrategy as PseudonymizationStrategy  # noqa: F401
from avatar_yaml import SpecificIdLetterCase as SpecificIdLetterCase  # noqa: F401
from avatar_yaml import SpecificIdStrategy as SpecificIdStrategy  # noqa: F401
from avatar_yaml import Uuid4Strategy as Uuid4Strategy  # noqa: F401

from avatars import crash_handler as _crash_handler  # noqa: F401
from avatars.client import ApiClient  # noqa: F401
from avatars.manager import Manager  # noqa: F401
from avatars.models import JobStatus  # noqa: F401
from avatars.runner import Runner  # noqa: F401

__all__ = [
    "__version__",
    "Manager",
    "ApiClient",
    "Runner",
    "JobStatus",
    "PiiType",
    "PseudonymizationStrategy",
    "FakeDataStrategy",
    "HashSha256Strategy",
    "Uuid4Strategy",
    "ConstantStrategy",
    "IntegerStrategy",
    "SpecificIdStrategy",
    "SpecificIdLetterCase",
]
