import uuid
from abc import ABCMeta, abstractmethod
from copy import copy
from functools import cached_property
from typing import List, Type, get_origin, get_args, TYPE_CHECKING
import os
import re
import time
from collections import defaultdict

import numpy as np
from IPython.display import HTML

from efootprint.abstract_modeling_classes.explainable_quantity import ExplainableQuantity
from efootprint.abstract_modeling_classes.explainable_hourly_quantities import ExplainableHourlyQuantities
from efootprint.abstract_modeling_classes.empty_explainable_object import EmptyExplainableObject
from efootprint.logger import logger
from efootprint.abstract_modeling_classes.explainable_object_base_class import (
    retrieve_update_function_from_mod_obj_and_attr_name, ExplainableObject)
from efootprint.abstract_modeling_classes.object_linked_to_modeling_obj import (
    ObjectLinkedToModelingObj, ObjectLinkedToModelingObjBase)
from efootprint.utils.graph_tools import WIDTH, HEIGHT, add_unique_id_to_mynetwork
from efootprint.utils.object_relationships_graphs import build_object_relationships_graph, \
    USAGE_PATTERN_VIEW_CLASSES_TO_IGNORE
from efootprint.utils.tools import get_init_signature_params
from efootprint.constants.units import u
from efootprint.core.lifecycle_phases import LifeCyclePhases

if TYPE_CHECKING:
    from efootprint.abstract_modeling_classes.contextual_modeling_object_attribute import ContextualModelingObjectAttribute
    from efootprint.abstract_modeling_classes.explainable_object_dict import ExplainableObjectDict

compute_times = defaultdict(float)


def get_instance_attributes(obj, target_class):
    return {attr_name: attr_value for attr_name, attr_value in obj.__dict__.items()
            if isinstance(attr_value, target_class)}


def check_type_homogeneity_within_list_or_set(input_list_or_set):
    type_set = [type(value) for value in input_list_or_set]
    base_type = type(type_set[0])

    if not all(isinstance(item, base_type) for item in type_set):
        raise ValueError(
            f"There shouldn't be objects of different types within the same list, found {type_set}")
    else:
        return type_set.pop()


def get_canonical_class_for_cls(modeling_object_class: type) -> type:
    from efootprint.all_classes_in_order import CANONICAL_COMPUTATION_ORDER

    for canonical_class in CANONICAL_COMPUTATION_ORDER:
        if issubclass(modeling_object_class, canonical_class):
            return canonical_class
    return modeling_object_class


class AfterInitMeta(type):
    def __call__(cls, *args, **kwargs):
        instance = super(AfterInitMeta, cls).__call__(*args, **kwargs)
        instance.after_init()

        return instance

    @property
    def canonical_class(cls):
        return get_canonical_class_for_cls(cls)


class ABCAfterInitMeta(AfterInitMeta, ABCMeta):
    def __instancecheck__(cls, instance):
        from efootprint.abstract_modeling_classes.contextual_modeling_object_attribute import \
            ContextualModelingObjectAttribute
        # Allow an instance of ContextualModelingObjectAttribute to be considered as an instance of ModelingObject
        if isinstance(instance, ContextualModelingObjectAttribute):
            return AfterInitMeta.__instancecheck__(cls, instance._value)

        return AfterInitMeta.__instancecheck__(cls, instance)


def css_escape(input_string):
    """
    Escape a string to be used as a CSS identifier.
    """
    def escape_char(c):
        if re.match(r'[a-zA-Z0-9_-]', c):
            return c
        elif c == ' ':
            return '-'
        else:
            return f'{ord(c):x}'

    return ''.join(escape_char(c) for c in input_string)


def optimize_mod_objs_computation_chain(mod_objs_computation_chain):
    from efootprint.all_classes_in_order import CANONICAL_COMPUTATION_ORDER
    initial_chain_len = len(mod_objs_computation_chain)
    # Keep only last occurrence of each mod_obj
    optimized_chain = []

    for index in range(len(mod_objs_computation_chain)):
        mod_obj = mod_objs_computation_chain[index]

        if mod_obj not in mod_objs_computation_chain[index + 1:]:
            optimized_chain.append(mod_obj)

    optimized_chain_len = len(optimized_chain)

    if optimized_chain_len != initial_chain_len:
        logger.info(f"Optimized modeling object computation chain from {initial_chain_len} to {optimized_chain_len}"
                    f" modeling object calculated attributes recomputations.")

    ordered_chain = []
    for efootprint_class in CANONICAL_COMPUTATION_ORDER:
        for mod_obj in optimized_chain:
            if issubclass(mod_obj.efootprint_class, efootprint_class):
                ordered_chain.append(mod_obj)

    ordered_chain_ids = [elt.id for elt in ordered_chain]
    optimized_chain_ids = [elt.id for elt in optimized_chain]

    if len(optimized_chain) != len(ordered_chain):
        in_ordered_not_in_optimized = [elt_id for elt_id in ordered_chain_ids if elt_id not in optimized_chain_ids]
        in_optimized_not_in_ordered = [elt_id for elt_id in optimized_chain_ids if elt_id not in ordered_chain_ids]
        raise AssertionError(
            f"Ordered modeling object computation chain \n{ordered_chain_ids} doesn’t have the same length as "
            f"\n{optimized_chain_ids}. This should never happen.\n"
            f"In ordered not in optimized: {in_ordered_not_in_optimized}\n"
            f"In optimized not in ordered: {in_optimized_not_in_ordered}")

    if ordered_chain_ids != optimized_chain_ids:
        logger.debug(f"Reordered modeling object computation chain from \n{ordered_chain_ids} to "
                    f"\n{optimized_chain_ids}")

    # In case system isn’t naturally present in chain, add it at the end
    from efootprint.core.system import System
    if ordered_chain and not isinstance(ordered_chain[-1], System):
        for mod_obj in ordered_chain:
            if mod_obj.systems:
                ordered_chain.append(mod_obj.systems[0])
                logger.debug("Added system to optimized chain")
                break

    return ordered_chain


class ModelingObject(metaclass=ABCAfterInitMeta):
    classes_outside_init_params_needed_for_generating_from_json = []
    _use_name_as_id: bool = False
    _attributed_footprint_cached_property_names = (
        "attributed_fabrication_footprint_per_source",
        "attributed_fabrication_footprint",
        "attributed_energy_footprint_per_source",
        "attributed_energy_footprint",
    )
    _impact_repartition_phases = ("fabrication", "usage")

    @classmethod
    def from_json_dict(cls, object_json_dict: dict, flat_obj_dict: dict, set_trigger_modeling_updates_to_true=False,
                       is_loaded_from_system_with_calculated_attributes=False):
        from efootprint.abstract_modeling_classes.explainable_object_dict import ExplainableObjectDict
        new_obj = cls.__new__(cls)
        new_obj.__dict__["contextual_modeling_obj_containers"] = []
        new_obj.__dict__["explainable_object_dicts_containers"] = []
        new_obj.trigger_modeling_updates = False
        explainable_object_dicts_to_create_after_objects_creation = {}
        for attr_key, attr_value in object_json_dict.items():
            if isinstance(attr_value, dict) and "label" in attr_value:
                new_value = ExplainableObject.from_json_dict(attr_value)
                new_obj.__setattr__(attr_key, new_value, check_input_validity=False)
                # Calculus graph data is added after setting as new_obj attribute to not interfere
                # with set_modeling_obj_container logic
                new_value.initialize_calculus_graph_data_from_json(attr_value, flat_obj_dict)
            elif isinstance(attr_value, dict) and "label" not in attr_value:
                explainable_object_dicts_to_create_after_objects_creation[(new_obj, attr_key)] = attr_value
            elif isinstance(attr_value, str) and attr_key != "id" and attr_value in flat_obj_dict:
                new_obj.__setattr__(attr_key, flat_obj_dict[attr_value], check_input_validity=False)
            elif isinstance(attr_value, list):
                new_obj.__setattr__(
                    attr_key, [flat_obj_dict[elt] for elt in attr_value], check_input_validity=False)
            else:
                new_obj.__setattr__(attr_key, attr_value)

        if not is_loaded_from_system_with_calculated_attributes:
            for calculated_attribute_name in new_obj.calculated_attributes:
                if getattr(new_obj, calculated_attribute_name, None) is None:
                    if hasattr(new_obj, f"update_dict_element_in_{calculated_attribute_name}"):
                        default_value = ExplainableObjectDict()
                    else:
                        default_value = EmptyExplainableObject()
                    new_obj.__setattr__(calculated_attribute_name, default_value, check_input_validity=False)

        # Initialize input ExplainableObjectDicts that were deferred to empty, so they exist before after_init
        for (obj, attr_key) in list(explainable_object_dicts_to_create_after_objects_creation.keys()):
            if obj is new_obj and attr_key not in new_obj.calculated_attributes:
                if getattr(new_obj, attr_key, None) is None:
                    new_obj.__setattr__(attr_key, ExplainableObjectDict(), check_input_validity=False)

        if set_trigger_modeling_updates_to_true:
            new_obj.trigger_modeling_updates = True

        return new_obj, explainable_object_dicts_to_create_after_objects_creation

    default_values = {}

    list_values =  {}

    conditional_list_values =  {}

    @classmethod
    def attributes_with_depending_values(cls):
        output_dict = {}
        for dependent_attribute, dependent_attribute_dependencies in cls.conditional_list_values.items():
            if dependent_attribute not in output_dict:
                output_dict[dependent_attribute_dependencies["depends_on"]] = [dependent_attribute]
            else:
                output_dict[dependent_attribute_dependencies["depends_on"]].append(dependent_attribute)

        return output_dict

    @classmethod
    def from_defaults(cls, name, **kwargs):
        from copy import deepcopy
        output_kwargs = deepcopy(cls.default_values)
        output_kwargs.update(kwargs)

        return cls(name, **output_kwargs)

    def copy_with(self, name: str | None = None, **overrides):
        """
        Create a new instance of this class by reusing the current initialization inputs.

        Args:
            name: Optional name for the copy. Defaults to "<current name> copy".
            **overrides: Replacement values for constructor arguments. Inputs whose annotations are
                ModelingObjects or Lists must always be provided explicitly.

        Returns:
            A new ModelingObject instance.
        """
        overrides = dict(overrides)
        init_params = get_init_signature_params(type(self))
        allowed_kwargs = {param for param in init_params if param not in ("self", "name")}
        unexpected_kwargs = set(overrides) - allowed_kwargs
        if unexpected_kwargs:
            raise TypeError(
                f"Unexpected overrides for {type(self).__name__}.copy_with: {sorted(unexpected_kwargs)}")

        constructor_kwargs = {}

        for param_name, param in init_params.items():
            if param_name in ("self", "name"):
                continue

            if param_name in overrides:
                value = overrides.pop(param_name)
            else:
                if hasattr(self, param_name):
                    value = getattr(self, param_name)
                elif param.default is not param.empty:
                    value = param.default
                else:
                    raise AttributeError(
                        f"{type(self).__name__}.{param_name} is missing on {self.name} and no override was provided.")

                if self._value_requires_manual_override(value):
                    annotation_str = getattr(param.annotation, "__name__", str(param.annotation))
                    raise ValueError(
                        f"{type(self).__name__}.copy_with requires explicit '{param_name}' because it is annotated "
                        f"as {annotation_str}.")

            constructor_kwargs[param_name] = self._prepare_value_for_copy(value)

        if overrides:
            raise TypeError(
                f"Some overrides could not be consumed when copying {type(self).__name__}: {sorted(overrides.keys())}")

        new_name = name or f"{self.name} copy"
        return type(self)(new_name, **constructor_kwargs)

    @staticmethod
    def _prepare_value_for_copy(value):
        if isinstance(value, ObjectLinkedToModelingObjBase):
            return copy(value)

        return value

    @staticmethod
    def _value_requires_manual_override(value):
        from efootprint.abstract_modeling_classes.contextual_modeling_object_attribute import \
            ContextualModelingObjectAttribute
        from efootprint.abstract_modeling_classes.explainable_object_dict import ExplainableObjectDict

        if isinstance(value, list):
            return True

        if isinstance(value, ExplainableObjectDict):
            return True

        if isinstance(value, ContextualModelingObjectAttribute):
            return True

        return isinstance(value, ModelingObject)

    @classmethod
    def archetypes(cls):
        return []

    @classmethod
    def attributes_that_can_have_negative_values(cls):
        return []

    def __init__(self, name):
        from efootprint.abstract_modeling_classes.explainable_object_dict import ExplainableObjectDict

        self.trigger_modeling_updates = False
        self.name = name
        self.id = css_escape(name) if ModelingObject._use_name_as_id else str(uuid.uuid4())[:6]
        self.contextual_modeling_obj_containers = []
        self.explainable_object_dicts_containers = []

        for phase in self._impact_repartition_phases:
            weights_attr = f"{phase}_impact_repartition_weights"
            weight_sum_attr = f"{phase}_impact_repartition_weight_sum"
            repartition_attr = f"{phase}_impact_repartition"
            if weights_attr in self.calculated_attributes:
                self.__setattr__(weights_attr, ExplainableObjectDict(), check_input_validity=False)
            if weight_sum_attr in self.calculated_attributes:
                self.__setattr__(weight_sum_attr, EmptyExplainableObject(), check_input_validity=False)
            if repartition_attr in self.calculated_attributes:
                self.__setattr__(repartition_attr, ExplainableObjectDict(), check_input_validity=False)

    @property
    def readable_id(self):
        return f"id-{self.id}-{css_escape(self.name)}"

    @property
    def efootprint_class(self):
        return type(self)

    @classmethod
    def sort_within_computation_chain(cls, instances):
        return instances

    def check_input_value_type_positivity_and_unit(self, name, input_value):
        init_sig_params = get_init_signature_params(type(self))
        if name in init_sig_params:
            annotation = init_sig_params[name].annotation
            if get_origin(annotation):
                if get_origin(annotation) in (list, List):
                    inner_type = get_args(annotation)[0]
                    if not all(isinstance(item, inner_type) for item in input_value):
                        raise TypeError(f"All elements in '{name}' must be instances of {inner_type.__name__}, "
                                         f"got {[type(item) for item in input_value]}")
            elif not isinstance(input_value, annotation) and not isinstance(input_value, EmptyExplainableObject):
                raise TypeError(f"In {self.name}, attribute {name} should be of type {annotation} "
                                      f"but is of type {type(input_value)}")
            elif issubclass(annotation, ExplainableQuantity):
                default_value = self.default_values[name]
                if (not isinstance(input_value, EmptyExplainableObject)
                        and input_value.value.dimensionality != default_value.value.dimensionality):
                    raise ValueError(
                        f"Value {input_value} for attribute {name} is not homogeneous to "
                        f"{default_value.value.units} ({default_value.value.dimensionality})")
                if input_value.magnitude < 0 and name not in self.attributes_that_can_have_negative_values():
                    raise ValueError(
                        f"Value {input_value} for attribute {name} should be positive but is negative")

    def check_belonging_to_authorized_values(self, name, input_value, attributes_with_depending_values):
        if name in self.list_values:
            if input_value not in self.list_values[name]:
                raise ValueError(
                    f"Value {input_value} for attribute {name} is not in the list of possible values: "
                    f"{[elt.value for elt in self.list_values[name]]}")

        if name in self.conditional_list_values:
            conditional_attr_name = self.conditional_list_values[name]['depends_on']
            conditional_value = getattr(self, self.conditional_list_values[name]["depends_on"])
            if conditional_value is None:
                raise ValueError(f"Value for attribute {conditional_attr_name} is not set but required for checking "
                                 f"validity of {name}")
            if (conditional_value in self.conditional_list_values[name]["conditional_list_values"]
                    and input_value not in
                    self.conditional_list_values[name]["conditional_list_values"][conditional_value]):
                raise ValueError(
                    f"Value {input_value} for attribute {name} is not in the list of possible values for "
                    f"{conditional_attr_name} {conditional_value}: "
                    f"{self.conditional_list_values[name]['conditional_list_values'][conditional_value]}")

        if name in attributes_with_depending_values:
            for dependent_attribute in attributes_with_depending_values[name]:
                dependent_attribute_value = getattr(self, dependent_attribute, None)
                if (dependent_attribute_value is not None
                        and input_value
                        in self.conditional_list_values[dependent_attribute]["conditional_list_values"]
                        and dependent_attribute_value not in
                        self.conditional_list_values[dependent_attribute]["conditional_list_values"][input_value]):
                    raise ValueError(
                        f"Setting {name} as {input_value} is not possible because {dependent_attribute_value}"
                        f" is not in the list of possible values for {dependent_attribute} "
                        f"when {name} is {input_value}."
                        f"\nYou might want to use the ModelingUpdate object to be able to change both inputs "
                        f"at the same time."
                        f"\nList of possible values for {input_value}:"
                        f"\n{self.conditional_list_values[dependent_attribute]['conditional_list_values'][input_value]}"
                    )

    @property
    def modeling_obj_containers(self):
        return list(dict.fromkeys(
            [contextual_mod_obj_container.modeling_obj_container
             for contextual_mod_obj_container in self.contextual_modeling_obj_containers
             if contextual_mod_obj_container.modeling_obj_container is not None]))

    @classmethod
    def is_subclass_of(cls, base_class_name: str) -> bool:
        """Check if this class inherits from base_class_name or any of its subclasses.

        Args:
            base_class_name: The name of the base class to check against

        Returns:
            True if this object's class or any of its parent classes has the given name
        """
        for parent_cls in cls.__mro__:
            if parent_cls.__name__ == base_class_name:
                return True
        return False

    def add_to_contextual_modeling_obj_containers(self, contextual_mod_obj_container):
        self.contextual_modeling_obj_containers.append(contextual_mod_obj_container)

    def is_structural_input_dict_attribute(self, attr_name: str, attr_value=None) -> bool:
        from efootprint.abstract_modeling_classes.explainable_object_dict import ExplainableObjectDict

        if attr_name in self.calculated_attributes:
            return False

        init_sig_params = get_init_signature_params(type(self))
        if attr_name not in init_sig_params:
            return False

        if attr_value is None:
            attr_value = getattr(self, attr_name, None)

        return isinstance(attr_value, ExplainableObjectDict)

    @property
    @abstractmethod
    def modeling_objects_whose_attributes_depend_directly_on_me(self) -> List[Type["ModelingObject"]]:
        pass

    @property
    def calculated_attributes(self) -> List[str]:
        return [
            "fabrication_impact_repartition_weights",
            "fabrication_impact_repartition_weight_sum",
            "fabrication_impact_repartition",
            "usage_impact_repartition_weights",
            "usage_impact_repartition_weight_sum",
            "usage_impact_repartition",
        ]

    @property
    def validation_attributes(self) -> List[str]:
        return [attr for attr in self.calculated_attributes if attr.endswith("_validation")]

    @property
    def calculated_attributes_without_validations(self) -> List[str]:
        return [attr for attr in self.calculated_attributes if not attr.endswith("_validation")]

    @property
    def systems(self) -> List:
        return list(dict.fromkeys(sum([mod_obj.systems for mod_obj in self.modeling_obj_containers], start=[])))

    def compute_calculated_attributes(self):
        logger.info(f"Computing calculated attributes for {type(self).__name__} {self.name}")
        for attr_name in self.calculated_attributes:
            start = time.perf_counter()
            update_func = retrieve_update_function_from_mod_obj_and_attr_name(self, attr_name)
            update_func()
            duration = time.perf_counter() - start
            if attr_name in compute_times:
                compute_times[attr_name]["total_duration"] += duration
                compute_times[attr_name]["nb_calls"] += 1
            else:
                compute_times[attr_name] = {"total_duration": duration, "nb_calls": 1}

    @property
    def mod_objs_computation_chain(self) -> List[Type["ModelingObject"]]:
        mod_objs_computation_chain = [self]

        mod_objs_with_attributes_to_compute = self.modeling_objects_whose_attributes_depend_directly_on_me

        while len(mod_objs_with_attributes_to_compute) > 0:
            current_mod_obj_to_update = mod_objs_with_attributes_to_compute[0]
            mod_objs_computation_chain.append(current_mod_obj_to_update)
            mod_objs_with_attributes_to_compute = mod_objs_with_attributes_to_compute[1:]

            for mod_obj in current_mod_obj_to_update.modeling_objects_whose_attributes_depend_directly_on_me:
                if mod_obj not in mod_objs_with_attributes_to_compute:
                    mod_objs_with_attributes_to_compute.append(mod_obj)

        return mod_objs_computation_chain

    @staticmethod
    def launch_mod_objs_computation_chain(mod_objs_computation_chain):
        for mod_obj in mod_objs_computation_chain:
            mod_obj.compute_calculated_attributes()

    def after_init(self):
        from efootprint.abstract_modeling_classes.explainable_object_dict import ExplainableObjectDict
        self.trigger_modeling_updates = True
        for attr_name, attr_value in self.__dict__.items():
            if (isinstance(attr_value, ExplainableObjectDict)
                    and attr_name not in self.calculated_attributes):
                attr_value.trigger_modeling_updates = True

    def __hash__(self):
        return hash(self.id)

    def __eq__(self, other):
        from efootprint.abstract_modeling_classes.contextual_modeling_object_attribute import \
            ContextualModelingObjectAttribute

        if isinstance(other, ContextualModelingObjectAttribute):
            return self.id == other._value.id
        elif isinstance(other, ModelingObject):
            return self.id == other.id

        return False

    @property
    def attributes_that_shouldnt_trigger_update_logic(self):
        return ["name", "id", "trigger_modeling_updates", "contextual_modeling_obj_containers",
                "explainable_object_dicts_containers"] + list(self._attributed_footprint_cached_property_names)

    def __setattr__(self, name, input_value, check_input_validity=True):
        current_attr = getattr(self, name, None)
        if name in self.attributes_that_shouldnt_trigger_update_logic:
            super().__setattr__(name, input_value)
        elif name in self.calculated_attributes or not self.trigger_modeling_updates:
            if check_input_validity and name not in self.calculated_attributes:
                self.check_input_value_type_positivity_and_unit(name, input_value)
                self.check_belonging_to_authorized_values(name, input_value, self.attributes_with_depending_values())
            value_to_set = input_value
            if isinstance(value_to_set, ModelingObject):
                from efootprint.abstract_modeling_classes.contextual_modeling_object_attribute import \
                    ContextualModelingObjectAttribute
                value_to_set = ContextualModelingObjectAttribute(value_to_set, self, name)
            elif type(value_to_set) == list:
                from efootprint.abstract_modeling_classes.list_linked_to_modeling_obj import ListLinkedToModelingObj
                value_to_set = ListLinkedToModelingObj(value_to_set)
            elif type(value_to_set) == dict:
                value_to_set = current_attr.__class__(value_to_set)
            assert isinstance(value_to_set, ObjectLinkedToModelingObjBase) or value_to_set is None, \
                    f"input {name} of value {value_to_set} should be an ObjectLinkedToModelingObjBase or None but is of type {type(value_to_set)}"
            if isinstance(current_attr, ObjectLinkedToModelingObjBase):
                current_attr.set_modeling_obj_container(None, None)
            if isinstance(value_to_set, ObjectLinkedToModelingObjBase):
                value_to_set.set_modeling_obj_container(self, name)
            # attribute setting must be done after setting modeling_obj_container because if system has been loaded
            # with calculated attributes from json, the calculation graph must be loaded before the attribute setting.
            super().__setattr__(name, value_to_set)
        else:
            from efootprint.abstract_modeling_classes.modeling_update import ModelingUpdate
            logger.debug(f"Updating {name} in {self.name}")
            ModelingUpdate([[current_attr, input_value]])

    def compute_mod_objs_computation_chain_from_old_and_new_modeling_objs(
            self, old_value: Type["ModelingObject"], input_value: Type["ModelingObject"], optimize_chain=True)\
            -> List[Type["ModelingObject"]]:
        if (self in old_value.modeling_objects_whose_attributes_depend_directly_on_me and
                old_value in self.modeling_objects_whose_attributes_depend_directly_on_me):
            raise AssertionError(
                f"There is a circular recalculation dependency between {self.id} and {old_value.id}")

        mod_objs_computation_chain = input_value.mod_objs_computation_chain + old_value.mod_objs_computation_chain

        # Preventive: compute self.mod_objs_computation_chain for both old and new states, because
        # dynamic properties on self (e.g. System.countries) may discover different objects depending
        # on the attribute value. Old state catches objects being removed, new state catches objects
        # being added.
        mod_objs_computation_chain += self.mod_objs_computation_chain
        attr_name = old_value.attr_name_in_mod_obj_container
        self.__dict__[attr_name] = input_value
        mod_objs_computation_chain += self.mod_objs_computation_chain
        self.__dict__[attr_name] = old_value

        if optimize_chain:
            optimized_chain = optimize_mod_objs_computation_chain(mod_objs_computation_chain)
            return optimized_chain
        else:
            return mod_objs_computation_chain

    def compute_mod_objs_computation_chain_from_old_and_new_lists(
            self, old_value: List[Type["ModelingObject"]], input_value: List[Type["ModelingObject"]],
            optimize_chain=True) -> List[Type["ModelingObject"]]:
        return self._compute_mod_objs_computation_chain_from_old_and_new_collection(
            old_value, input_value,
            old_mod_objs=old_value, new_mod_objs=input_value,
            optimize_chain=optimize_chain)

    def _compute_mod_objs_computation_chain_from_old_and_new_collection(
            self, old_value, input_value, old_mod_objs, new_mod_objs,
            optimize_chain=True) -> List[Type["ModelingObject"]]:
        removed_objs = [obj for obj in old_mod_objs if obj not in new_mod_objs]
        added_objs = [obj for obj in new_mod_objs if obj not in old_mod_objs]

        mod_objs_computation_chain = []
        attr_name = old_value.attr_name_in_mod_obj_container
        for obj in removed_objs:
            if self not in obj.modeling_objects_whose_attributes_depend_directly_on_me:
                mod_objs_computation_chain += obj.mod_objs_computation_chain

        mod_objs_computation_chain += self.mod_objs_computation_chain
        # Evaluate added objects in the context of the new collection state, not as standalone objects.
        # Example: when updating UsageJourneyStep.jobs, a freshly re-created Job only sees its Network once the
        # temporary jobs list is attached to the step. Without this attachment, Job.networks is still empty while the
        # recomputation chain is built, so the network would be skipped and remain stale after the update.
        input_value.set_modeling_obj_container(self, attr_name)
        self.__dict__[attr_name] = input_value
        for obj in added_objs:
            if self not in obj.modeling_objects_whose_attributes_depend_directly_on_me:
                mod_objs_computation_chain += obj.mod_objs_computation_chain
        # self.mod_objs_computation_chain is also evaluated in the previewed new state so container-side contextual
        # links are discovered consistently with child-side ones.
        mod_objs_computation_chain += self.mod_objs_computation_chain
        self.__dict__[attr_name] = old_value
        input_value.set_modeling_obj_container(None, None)

        if optimize_chain:
            return optimize_mod_objs_computation_chain(mod_objs_computation_chain)
        return mod_objs_computation_chain

    def compute_mod_objs_computation_chain_from_old_and_new_dicts(
            self, old_value, input_value, optimize_chain=True) -> List[Type["ModelingObject"]]:
        old_mod_obj_keys = [k for k in old_value if isinstance(k, ModelingObject)]
        new_mod_obj_keys = [k for k in input_value if isinstance(k, ModelingObject)]
        return self._compute_mod_objs_computation_chain_from_old_and_new_collection(
            old_value, input_value,
            old_mod_objs=old_mod_obj_keys, new_mod_objs=new_mod_obj_keys,
            optimize_chain=optimize_chain)

    @property
    def mod_obj_attributes(self) -> List[Type["ContextualModelingObjectAttribute"]]:
        from efootprint.abstract_modeling_classes.list_linked_to_modeling_obj import ListLinkedToModelingObj
        output_list = []
        for attr_name, attr_value in get_instance_attributes(self, ModelingObject).items():
            output_list.append(attr_value)
        for attr_value in get_instance_attributes(self, ListLinkedToModelingObj).values():
            output_list += list(attr_value)

        return output_list

    def object_relationship_graph_to_file(
            self, filename=None, classes_to_ignore=USAGE_PATTERN_VIEW_CLASSES_TO_IGNORE, width=WIDTH, height=HEIGHT,
            notebook=False):
        object_relationships_graph = build_object_relationships_graph(
            self, classes_to_ignore=classes_to_ignore, width=width, height=height, notebook=notebook)

        if filename is None:
            filename = os.path.join(".", f"{self.name} object relationship graph.html")
        object_relationships_graph.show(filename, notebook=notebook)

        add_unique_id_to_mynetwork(filename)

        if notebook:
            return HTML(filename)

    def self_delete(self):
        logger.warning(
            f"Deleting {self.name}, removing backward links pointing to it in "
            f"{','.join([mod_obj.name for mod_obj in self.mod_obj_attributes])}")
        if self.modeling_obj_containers:
            raise PermissionError(
                f"You can’t delete {self.name} because "
                f"{','.join([mod_obj.name for mod_obj in self.modeling_obj_containers])} have it as attribute.")

        mod_objs_computation_chain = [elt for elt in self.mod_objs_computation_chain if elt != self]

        for contextual_attr in self.mod_obj_attributes:
            contextual_attr.set_modeling_obj_container(None, None)
        for attr_value in get_instance_attributes(self, ObjectLinkedToModelingObj).values():
                attr_value.set_modeling_obj_container(None, None)

        if self.trigger_modeling_updates:
            optimized_chain = optimize_mod_objs_computation_chain(mod_objs_computation_chain)
            self.launch_mod_objs_computation_chain(optimized_chain)

        del self

    def to_json(self, save_calculated_attributes=False) -> dict:
        from efootprint.abstract_modeling_classes.modeling_update import ModelingUpdate
        output_dict = {}

        for key, value in self.__dict__.items():
            if key in ["name", "id", "short_name", "impact_url"]:
                output_dict[key] = value
            if (
                    (key in self.calculated_attributes and not save_calculated_attributes)
                    or key in self.attributes_that_shouldnt_trigger_update_logic
            ):
                continue
            elif value is None or isinstance(value, str):
                output_dict[key] = value
            elif isinstance(value, ModelingObject):
                output_dict[key] = value.id
            elif isinstance(value, ModelingUpdate):
                continue
            elif getattr(value, "to_json", None) is not None:
                output_dict[key] = value.to_json(save_calculated_attributes)
            else:
                raise ValueError(f"Attribute {key} of {self.name} {type(value)}) is not handled in to_json")

        return output_dict

    @property
    def class_as_simple_str(self):
        return type(self).__name__

    @property
    def canonical_class(self):
        return type(self).canonical_class

    def __repr__(self):
        return str(self)

    def __str__(self):
        output_str = ""

        def key_value_to_str(input_key, input_value):
            key_value_str = ""

            if type(input_value) in (str, int) or input_value is None:
                key_value_str = f"{input_key}: {input_value}\n"
            elif isinstance(input_value, list):
                if len(input_value) == 0:
                    key_value_str = f"{input_key}: {input_value}\n"
                else:
                    if type(input_value[0]) == str:
                        key_value_str = f"{input_key}: {input_value}"
                    elif isinstance(input_value[0], ModelingObject):
                        str_value = "[" + ", ".join([elt.id for elt in input_value]) + "]"
                        key_value_str = f"{input_key}: {str_value}\n"
            elif isinstance(input_value, ModelingObject):
                key_value_str = f"{input_key}: {input_value.id}\n"
            elif isinstance(input_value, ObjectLinkedToModelingObjBase):
                key_value_str = f"{input_key}: {input_value}\n"

            return key_value_str

        output_str += f"{self.class_as_simple_str} {self.id}\n \nname: {self.name}\n"

        for key, attr_value in self.__dict__.items():
            if (key in self.attributes_that_shouldnt_trigger_update_logic or key in self.calculated_attributes):
                continue
            output_str += key_value_to_str(key, attr_value)

        if len(self.calculated_attributes) > 0:
            output_str += " \ncalculated_attributes:\n"
            for key in self.calculated_attributes:
                output_str += "  " + key_value_to_str(key, getattr(self, key))

        return output_str

    @property
    def attribute_update_entanglements(self):
        # Used to generate new changes that depend on a change in certain attributes
        # Used in RecurrentEdgeProcess class for generating entanglements so that whenever device is updated,
        # component needs are updated too.
        return {}

    @property
    def nb_of_occurrences_per_container(self) -> dict["ModelingObject", ExplainableQuantity]:
        from efootprint.abstract_modeling_classes.explainable_object_dict import ExplainableObjectDict

        output_dict = {}
        for contextual_mod_obj_container in self.contextual_modeling_obj_containers:
            if contextual_mod_obj_container.modeling_obj_container is None:
                continue
            if contextual_mod_obj_container.modeling_obj_container not in output_dict:
                output_dict[contextual_mod_obj_container.modeling_obj_container] = 1
            else:
                output_dict[contextual_mod_obj_container.modeling_obj_container] += 1

        return ExplainableObjectDict({key: ExplainableQuantity(
            value * u.dimensionless, label=f"Number of occurrences of {self.name} in {key.name}")
            for key, value in output_dict.items()})

    def _compute_default_impact_repartition_weight(
            self, modeling_object: "ModelingObject", phase: str):
        weight = (sum([val for val in getattr(modeling_object, f"{phase}_impact_repartition_weights").values()],
                      start=EmptyExplainableObject())
                * self.nb_of_occurrences_per_container[modeling_object]).set_label(
            f"{modeling_object.name} weight in {self.name} impact repartition")
        return weight

    def update_dict_element_in_fabrication_impact_repartition_weights(self, modeling_object: "ModelingObject"):
        self.fabrication_impact_repartition_weights[modeling_object] = self._compute_default_impact_repartition_weight(
            modeling_object, "fabrication")

    def update_fabrication_impact_repartition_weights(self):
        from efootprint.abstract_modeling_classes.explainable_object_dict import ExplainableObjectDict
        self.fabrication_impact_repartition_weights = ExplainableObjectDict()
        for modeling_object in self.modeling_obj_containers:
            self.update_dict_element_in_fabrication_impact_repartition_weights(modeling_object)

    def update_dict_element_in_usage_impact_repartition_weights(self, modeling_object: "ModelingObject"):
        self.usage_impact_repartition_weights[modeling_object] = self._compute_default_impact_repartition_weight(
            modeling_object, "usage")

    def update_usage_impact_repartition_weights(self):
        from efootprint.abstract_modeling_classes.explainable_object_dict import ExplainableObjectDict
        self.usage_impact_repartition_weights = ExplainableObjectDict()
        for modeling_object in self.modeling_obj_containers:
            self.update_dict_element_in_usage_impact_repartition_weights(modeling_object)

    def _update_impact_repartition_weight_sum(self, phase: str):
        impact_repartition_weight_sum = sum(
            getattr(self, f"{phase}_impact_repartition_weights").values(), start=EmptyExplainableObject())
        setattr(
            self,
            f"{phase}_impact_repartition_weight_sum",
            impact_repartition_weight_sum.set_label(f"Sum of {self.name} {phase} impact repartition weights"),
        )

    def update_fabrication_impact_repartition_weight_sum(self):
        self._update_impact_repartition_weight_sum("fabrication")

    def update_usage_impact_repartition_weight_sum(self):
        self._update_impact_repartition_weight_sum("usage")

    def _update_dict_element_in_impact_repartition(self, phase: str, modeling_obj: "ModelingObject"):
        impact_repartition_weight_sum = getattr(self, f"{phase}_impact_repartition_weight_sum")
        if ((isinstance(impact_repartition_weight_sum, ExplainableQuantity)
                or isinstance(impact_repartition_weight_sum, EmptyExplainableObject))
                and impact_repartition_weight_sum.magnitude == 0):
            repartition_value = EmptyExplainableObject()
        elif (isinstance(impact_repartition_weight_sum, ExplainableHourlyQuantities)
              and impact_repartition_weight_sum.sum().magnitude == 0):
            repartition_value = EmptyExplainableObject()
        else:
            repartition_value = (
                getattr(self, f"{phase}_impact_repartition_weights")[modeling_obj] / impact_repartition_weight_sum
            ).to(u.concurrent).set_label(f"{self.name} {phase} impact attribution to {modeling_obj.name}")

        if isinstance(repartition_value, ExplainableHourlyQuantities):
            nan_values_mask = np.isnan(repartition_value.magnitude)
            repartition_value.value[nan_values_mask] = 1

        getattr(self, f"{phase}_impact_repartition")[modeling_obj] = repartition_value

    def update_dict_element_in_fabrication_impact_repartition(self, modeling_obj: "ModelingObject"):
        self._update_dict_element_in_impact_repartition("fabrication", modeling_obj)

    def update_dict_element_in_usage_impact_repartition(self, modeling_obj: "ModelingObject"):
        self._update_dict_element_in_impact_repartition("usage", modeling_obj)

    def _update_impact_repartition(self, phase: str):
        from efootprint.abstract_modeling_classes.explainable_object_dict import ExplainableObjectDict
        current_impact_repartition = getattr(self, f"{phase}_impact_repartition", None)
        old_impacted_objects = set(current_impact_repartition.keys()) if isinstance(current_impact_repartition, dict) else set()
        repartition_attr_name = f"{phase}_impact_repartition"
        weights = getattr(self, f"{phase}_impact_repartition_weights")
        setattr(self, repartition_attr_name, ExplainableObjectDict())
        for modeling_obj in weights:
            getattr(self, f"update_dict_element_in_{phase}_impact_repartition")(modeling_obj)
        for modeling_obj in old_impacted_objects | set(getattr(self, repartition_attr_name).keys()):
            if isinstance(modeling_obj, ModelingObject):
                modeling_obj.invalidate_impact_repartition_cache(recursive=True)

    def update_fabrication_impact_repartition(self):
        self._update_impact_repartition("fabrication")

    def update_usage_impact_repartition(self):
        self._update_impact_repartition("usage")

    def invalidate_impact_repartition_cache(self, recursive=False, visited=None):
        visited = set() if visited is None else visited
        if self.id in visited:
            return
        visited.add(self.id)

        for cached_property_name in self._attributed_footprint_cached_property_names:
            self.__dict__.pop(cached_property_name, None)

        if recursive:
            for phase in self._impact_repartition_phases:
                impact_repartition = getattr(self, f"{phase}_impact_repartition", None)
                if not isinstance(impact_repartition, dict):
                    continue
                for modeling_obj in impact_repartition:
                    if isinstance(modeling_obj, ModelingObject):
                        modeling_obj.invalidate_impact_repartition_cache(recursive=True, visited=visited)

    @property
    def is_impact_source(self):
        return hasattr(self, "instances_fabrication_footprint") or hasattr(self, "energy_footprint")

    @property
    def attributed_footprint_per_source(self):
        return {
            LifeCyclePhases.MANUFACTURING: self.attributed_fabrication_footprint_per_source,
            LifeCyclePhases.USAGE: self.attributed_energy_footprint_per_source
        }
            
    @cached_property
    def attributed_fabrication_footprint_per_source(self):
        from efootprint.abstract_modeling_classes.explainable_object_dict import ExplainableObjectDict
        attributed_fabrication_footprint_per_source = ExplainableObjectDict()
        if self.is_impact_source:
            attributed_fabrication_footprint_per_source[self] = self.instances_fabrication_footprint
        else:
            for expl_dict in self.explainable_object_dicts_containers:
                if expl_dict.attr_name_in_mod_obj_container == "fabrication_impact_repartition":
                    attributed_fabrication_footprint_per_source[expl_dict.modeling_obj_container] = (
                            expl_dict[self] * expl_dict.modeling_obj_container.attributed_fabrication_footprint
                    ).set_label(f"{self.name} fabrication footprint due to {expl_dict.modeling_obj_container.name}")
                
        return attributed_fabrication_footprint_per_source

    @cached_property
    def attributed_fabrication_footprint(self):
        attributed_fabrication_footprint = sum(
            [val for val in self.attributed_fabrication_footprint_per_source.values()], start=EmptyExplainableObject())
        
        return attributed_fabrication_footprint.to(u.kg).set_label(f"{self.name} attributed fabrication footprint")

    @cached_property
    def attributed_energy_footprint_per_source(self):
        from efootprint.abstract_modeling_classes.explainable_object_dict import ExplainableObjectDict
        attributed_energy_footprint_per_source = ExplainableObjectDict()
        if self.is_impact_source:
            attributed_energy_footprint_per_source[self] = self.energy_footprint
        else:
            for expl_dict in self.explainable_object_dicts_containers:
                if expl_dict.attr_name_in_mod_obj_container == "usage_impact_repartition":
                    attributed_energy_footprint_per_source[expl_dict.modeling_obj_container] = (
                            expl_dict[self] * expl_dict.modeling_obj_container.attributed_energy_footprint
                    ).set_label(f"{self.name} energy footprint due to {expl_dict.modeling_obj_container.name}")

        return attributed_energy_footprint_per_source

    @cached_property
    def attributed_energy_footprint(self):
        attributed_energy_footprint = sum(
            [val for val in self.attributed_energy_footprint_per_source.values()], start=EmptyExplainableObject())

        return attributed_energy_footprint.to(u.kg).set_label(f"{self.name} attributed energy footprint")
