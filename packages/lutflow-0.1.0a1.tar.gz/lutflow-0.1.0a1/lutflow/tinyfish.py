"""
TinyFish integration for real-time GPU price discovery.

TinyFish navigates GPU cloud provider pricing pages in real time using
browser automation, returning structured pricing data without static APIs.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional
import logging
import os
import time

import httpx

logger = logging.getLogger("lutflow")

TINYFISH_RUN_URL = "https://agent.tinyfish.ai/v1/automation/run"

CACHED_PRICES: Dict[str, Dict[str, float]] = {
    "runpod": {"spot": 0.44, "ondemand": 0.74},
    "vastai": {"spot": 0.39, "ondemand": 0.65},
    "coreweave": {"spot": 0.54, "ondemand": 0.81},
    "lambdalabs": {"spot": 0.50, "ondemand": 0.80},
}

GPU_PROVIDER_URLS: Dict[str, str] = {
    "runpod": "https://www.runpod.io/gpu-instance/pricing",
    "vastai": "https://vast.ai/pricing",
    "coreweave": "https://www.coreweave.com/gpu-cloud-pricing",
    "lambdalabs": "https://lambdalabs.com/service/gpu-cloud",
}


@dataclass
class GPUPrice:
    """Price quote from a single provider."""

    provider: str
    gpu_type: str
    spot_usd_per_hour: float
    ondemand_usd_per_hour: Optional[float] = None
    source: str = "cached_fallback"
    fetched_at: float = field(default_factory=time.time)


@dataclass
class GPUPricingResult:
    """Aggregated pricing result across providers."""

    gpu_type: str
    prices: List[GPUPrice] = field(default_factory=list)

    @property
    def cheapest(self) -> Optional[GPUPrice]:
        valid = [p for p in self.prices if p.spot_usd_per_hour > 0]
        if not valid:
            return None
        return min(valid, key=lambda p: p.spot_usd_per_hour)

    def budget_runtime_minutes(self, budget_usd: float) -> Optional[float]:
        best = self.cheapest
        if not best or best.spot_usd_per_hour <= 0:
            return None
        return (budget_usd / best.spot_usd_per_hour) * 60


class TinyFishClient:
    """
    Client for TinyFish Web Agent API.

    Falls back to cached prices when the API key is not set or requests fail.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        timeout: float = 60.0,
    ):
        self.api_key = api_key or os.getenv("TINYFISH_API_KEY")
        self.timeout = timeout

    @property
    def is_live(self) -> bool:
        return self.api_key is not None and self.api_key != ""

    def fetch_gpu_price(
        self,
        provider: str,
        gpu_type: str = "nvidia-l4",
    ) -> GPUPrice:
        """Fetch a single provider's GPU price, live or cached."""
        provider = provider.lower().replace(".", "").replace(" ", "")

        if self.is_live:
            try:
                return self._fetch_live(provider, gpu_type)
            except Exception as exc:
                logger.debug("TinyFish live fetch failed for %s: %s", provider, exc)

        return self._fetch_cached(provider, gpu_type)

    def fetch_all_prices(
        self,
        gpu_type: str = "nvidia-l4",
        providers: Optional[List[str]] = None,
    ) -> GPUPricingResult:
        """Fetch prices from all (or specified) providers."""
        targets = providers or list(GPU_PROVIDER_URLS.keys())
        result = GPUPricingResult(gpu_type=gpu_type)

        for provider in targets:
            price = self.fetch_gpu_price(provider, gpu_type)
            result.prices.append(price)

        return result

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _fetch_live(self, provider: str, gpu_type: str) -> GPUPrice:
        url = GPU_PROVIDER_URLS.get(provider)
        if not url:
            raise ValueError(f"Unknown provider: {provider}")

        response = httpx.post(
            TINYFISH_RUN_URL,
            headers={
                "X-API-Key": self.api_key,
                "Content-Type": "application/json",
            },
            json={
                "url": url,
                "goal": (
                    f"Find the current spot and on-demand price per hour for "
                    f"{gpu_type.upper().replace('-', ' ')} GPU. "
                    f"Return JSON: {{spot_usd_per_hour: float, ondemand_usd_per_hour: float}}"
                ),
                "output_format": "json",
            },
            timeout=self.timeout,
        )
        response.raise_for_status()
        data = response.json()

        result = data.get("result", {})
        spot = float(result.get("spot_usd_per_hour", 0))
        ondemand = float(result.get("ondemand_usd_per_hour", 0)) or None

        return GPUPrice(
            provider=provider,
            gpu_type=gpu_type,
            spot_usd_per_hour=spot,
            ondemand_usd_per_hour=ondemand,
            source="tinyfish_live",
        )

    def _fetch_cached(self, provider: str, gpu_type: str) -> GPUPrice:
        cached = CACHED_PRICES.get(provider, {"spot": 0.50, "ondemand": 0.80})

        return GPUPrice(
            provider=provider,
            gpu_type=gpu_type,
            spot_usd_per_hour=cached["spot"],
            ondemand_usd_per_hour=cached.get("ondemand"),
            source="cached_fallback",
        )
