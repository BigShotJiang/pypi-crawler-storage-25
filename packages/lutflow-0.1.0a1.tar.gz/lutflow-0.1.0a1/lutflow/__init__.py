"""
Lutflow — GPU Financial Firewall for AI inference.

Track costs, enforce budgets, and kill runaway GPU spending in real time.

Example:
    >>> from lutflow import Client
    >>> client = Client(tenant_id="acme", budget_usd=10.00)
    >>> wrapped = client.wrap(openai.OpenAI())
    >>> response = wrapped.chat.completions.create(model="gpt-4o", messages=[...])
"""

from lutflow.client import Client
from lutflow.budget import BudgetStrategy, BudgetExceededError
from lutflow.pricing import PricingMode
from lutflow.pcpo import CostPredictor, CostPrediction, PredictiveBudgetGuard

__version__ = "0.1.0a1"
__all__ = [
    "Client",
    "BudgetStrategy",
    "BudgetExceededError",
    "PricingMode",
    "CostPredictor",
    "CostPrediction",
    "PredictiveBudgetGuard",
]
