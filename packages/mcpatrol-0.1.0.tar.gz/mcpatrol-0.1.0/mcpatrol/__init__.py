"""MCPatrol — security & quality scanner for MCP servers."""

__version__ = "0.1.0"
