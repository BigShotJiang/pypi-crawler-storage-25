#!/usr/bin/env python
# coding: utf-8

"""Dilithium (ML-DSA-44) cryptographic module for post-quantum signatures."""

import hashlib
from typing import Tuple
from dilithium_py.ml_dsa import ML_DSA_44


def sha512_48(data: bytes) -> bytes:
    """
    Compute SHA-512 hash and return first 48 bytes.

    Args:
        data: Input data to hash

    Returns:
        First 48 bytes of SHA-512 hash
    """
    return hashlib.sha512(data).digest()[:48]


def derive_keypair(entropy: bytes) -> Tuple[str, str]:
    """
    Derive Dilithium keypair from entropy.

    Args:
        entropy: 32 bytes of random entropy

    Returns:
        Tuple of (private_key_hex, public_key_hex)
        Private key: 2560 bytes (5120 hex chars)
        Public key: 1312 bytes (2624 hex chars)
    """
    if len(entropy) != 32:
        raise ValueError("Entropy must be exactly 32 bytes")

    seed = sha512_48(entropy)
    ML_DSA_44.set_drbg_seed(seed)
    public_key, secret_key = ML_DSA_44.keygen()

    return (
        secret_key.hex(),  # 2560 bytes = 5120 hex chars
        public_key.hex()   # 1312 bytes = 2624 hex chars
    )


def sign(message: bytes, private_key: str) -> str:
    """
    Sign message with Dilithium private key.

    Args:
        message: Message to sign (as bytes)
        private_key: Hex-encoded private key (5120 hex chars)

    Returns:
        Hex-encoded signature (uppercase)

    Raises:
        ValueError: If private key length is invalid
    """
    if len(private_key) != 5120:
        raise ValueError("Private key must be 2560 bytes (5120 hex chars)")

    private_key_bytes = bytes.fromhex(private_key)
    signature = ML_DSA_44.sign(private_key_bytes, message)
    return signature.hex().upper()


def verify(message: bytes, signature: str, public_key: str) -> bool:
    """
    Verify Dilithium signature.

    Args:
        message: Original message (as bytes)
        signature: Hex-encoded signature
        public_key: Hex-encoded public key (2624 hex chars)

    Returns:
        True if signature is valid, False otherwise

    Raises:
        ValueError: If public key length is invalid
    """
    if len(public_key) != 2624:
        raise ValueError("Public key must be 1312 bytes (2624 hex chars)")

    try:
        public_key_bytes = bytes.fromhex(public_key)
        signature_bytes = bytes.fromhex(signature)
        return ML_DSA_44.verify(public_key_bytes, message, signature_bytes)
    except Exception:
        return False
