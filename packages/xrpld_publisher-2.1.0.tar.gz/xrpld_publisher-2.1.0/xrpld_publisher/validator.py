#!/usr/bin/env python
# coding: utf-8

import os
from typing import Dict, Any, List  # noqa: F401
import binascii
import base64

from xrpld_publisher.utils import (
    read_json,
    read_txt,
    write_json,
    write_file,
    encode_blob,
)
from xrpld_publisher import dilithium as dilithium_mod
from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.hazmat.primitives import serialization

from xrpl.core.addresscodec.codec import _encode, _decode
from xrpl.core.addresscodec import encode_node_public_key, decode_node_public_key
from xrpl.core.binarycodec import encode
from xrpl.core.keypairs import sign as sign_message, generate_seed, derive_keypair
from xrpl.constants import CryptoAlgorithm

DER_PRIVATE_KEY_PREFIX = bytes.fromhex("302E020100300506032B657004220420")
DER_PUBLIC_KEY_PREFIX = bytes.fromhex("302A300506032B6570032100")
VALIDATOR_HEX_PREFIX_ED25519 = "ED"


def _get_algorithm_from_key_length(key_hex: str) -> str:
    byte_length = len(key_hex) // 2
    if byte_length == 2560 or byte_length == 1312:
        return "dilithium"
    if key_hex.startswith("ED") and byte_length == 33:
        return "ed25519"
    return "secp256k1"


class KeystoreInterface:
    def __init__(
        self,
        domain=None,
        key_type="ed25519",
        manifest=None,
        public_key="",
        revoked=False,
        secret_key="",
        token_sequence=0,
        ephemeral_public_key=None,
        ephemeral_private_key=None,
        ephemeral_key_type=None,
    ):
        self.domain = domain
        self.key_type = key_type
        self.manifest = manifest
        self.public_key = public_key
        self.revoked = revoked
        self.secret_key = secret_key
        self.token_sequence = token_sequence
        self.ephemeral_public_key = ephemeral_public_key
        self.ephemeral_private_key = ephemeral_private_key
        self.ephemeral_key_type = ephemeral_key_type

    def to_dict(self):
        d = {
            "domain": self.domain,
            "key_type": self.key_type,
            "manifest": self.manifest,
            "public_key": self.public_key,
            "revoked": self.revoked,
            "secret_key": self.secret_key,
            "token_sequence": self.token_sequence,
        }
        if self.ephemeral_public_key is not None:
            d["ephemeral_public_key"] = self.ephemeral_public_key
        if self.ephemeral_private_key is not None:
            d["ephemeral_private_key"] = self.ephemeral_private_key
        if self.ephemeral_key_type is not None:
            d["ephemeral_key_type"] = self.ephemeral_key_type
        return d


class ManifestInterface:
    def __init__(
        self,
        Sequence,
        PublicKey,
        SigningPubKey,
        Domain=None,
        SigningPrivateKey="",
        MasterPrivateKey="",
    ):
        self.Sequence = Sequence
        self.PublicKey = PublicKey
        self.SigningPubKey = SigningPubKey
        self.Domain = Domain
        self.SigningPrivateKey = SigningPrivateKey
        self.MasterPrivateKey = MasterPrivateKey


class ManifestResponse:
    def __init__(self, base64="", xrpl=""):
        self.base64 = base64
        self.xrpl = xrpl


def generate_keystore(algorithm: str = "ed25519") -> KeystoreInterface:
    if algorithm == "dilithium":
        entropy = os.urandom(32)
        private_key_hex, public_key_hex = dilithium_mod.derive_keypair(entropy)

        return KeystoreInterface(
            key_type="dilithium",
            secret_key=private_key_hex,
            public_key=public_key_hex,
            revoked=False,
            token_sequence=0,
        )

    private_key = ed25519.Ed25519PrivateKey.generate()
    public_key = private_key.public_key()

    private_bytes = private_key.private_bytes(
        encoding=serialization.Encoding.DER,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )

    public_bytes = public_key.public_bytes(
        encoding=serialization.Encoding.DER,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )

    public_key_hex = (
        VALIDATOR_HEX_PREFIX_ED25519
        + public_bytes[len(DER_PUBLIC_KEY_PREFIX) :].hex().upper()
    )

    secret_key = _encode(
        private_bytes[len(DER_PRIVATE_KEY_PREFIX) :],
        [0x20],
        32,
    )

    return KeystoreInterface(
        key_type="ed25519",
        secret_key=secret_key,
        public_key=encode_node_public_key(bytes.fromhex(public_key_hex)),
        revoked=False,
        token_sequence=0,
    )


def sign(message, secret) -> str:
    if isinstance(message, str):
        message = message.encode("utf-8")

    algorithm = _get_algorithm_from_key_length(secret)

    if algorithm == "dilithium":
        return dilithium_mod.sign(message, secret)

    try:
        decoded = _decode(secret, bytes([0x20]))
        secret = VALIDATOR_HEX_PREFIX_ED25519 + decoded.hex()
    except Exception:
        pass

    return sign_message(message, secret).upper()


def _encode_vl_length(field_id: int, data: bytes) -> bytes:
    length = len(data)
    if length <= 192:
        return (
            field_id.to_bytes(1, byteorder="big")
            + length.to_bytes(1, byteorder="big")
            + data
        )
    # Variable length encoding for larger keys (dilithium)
    byte1 = 193 + (length - 193) // 256
    byte2 = (length - 193) % 256
    return (
        field_id.to_bytes(1, byteorder="big")
        + byte1.to_bytes(1, byteorder="big")
        + byte2.to_bytes(1, byteorder="big")
        + data
    )


def generate_manifest(manifest):
    verify_fields = [b"MAN\x00"]

    # Sequence (soeREQUIRED)
    sequence_buffer = (0x24).to_bytes(1, byteorder="big") + manifest[
        "Sequence"
    ].to_bytes(4, byteorder="big")
    verify_fields.append(sequence_buffer)

    # PublicKey (soeREQUIRED)
    public_key_bytes = bytes.fromhex(manifest["PublicKey"])
    verify_fields.append(_encode_vl_length(0x71, public_key_bytes))

    # SigningPubKey (soeOPTIONAL)
    signing_pub_key_bytes = bytes.fromhex(manifest["SigningPubKey"])
    verify_fields.append(_encode_vl_length(0x73, signing_pub_key_bytes))

    # Domain (soeOPTIONAL)
    if "Domain" in manifest:
        domain_length = len(manifest["Domain"]) // 2
        domain_buffer = bytearray([0x77, domain_length])
        domain_buffer += bytes.fromhex(manifest["Domain"])
        verify_fields.append(domain_buffer)

    verify_data = b"".join(verify_fields)

    # Signature (soeOPTIONAL)
    ephemeral_signature = sign(verify_data, manifest["SigningPrivateKey"])

    # MasterSignature (soeREQUIRED)
    master_signature = sign(verify_data, manifest["MasterPrivateKey"])

    json_dict = {
        "Sequence": manifest["Sequence"],
        "PublicKey": manifest["PublicKey"],
        "SigningPubKey": manifest["SigningPubKey"],
        "Signature": ephemeral_signature,
        "MasterSignature": master_signature,
    }
    if "Domain" in manifest:
        json_dict["Domain"] = manifest["Domain"]

    manifest_buffer = bytes.fromhex(encode(json_dict))

    return {
        "base64": base64.b64encode(manifest_buffer).decode("utf-8"),
        "xrpl": manifest_buffer.hex().upper(),
    }


class ValidatorClient(object):
    name: str = ""
    keystore_path: str = ""
    bin_path: str = ""
    key_path: str = ""

    def __init__(cls, name: str) -> None:
        cls.name = name
        cls.keystore_path = "keystore"
        cls.key_path = os.path.join(cls.keystore_path, f"{cls.name}/key.json")
        os.makedirs(cls.keystore_path, exist_ok=True)

    def get_keys(cls):
        try:
            return read_json(cls.key_path)
        except Exception as e:
            print(e)
            return None

    def create_keys(cls, algorithm: str = "ed25519") -> str:
        os.makedirs(os.path.join(cls.keystore_path, cls.name), exist_ok=True)
        write_json(generate_keystore(algorithm).to_dict(), cls.key_path)

    def set_domain(cls, domain: str) -> None:
        keys = cls.get_keys()
        keys["domain"] = domain
        keys["token_sequence"] += 1

        attestation = sign(
            f"[domain-attestation-blob:{keys['domain']}:{keys['public_key']}]",
            keys["secret_key"],
        )
        name_path = os.path.join(cls.keystore_path, cls.name)
        write_file(attestation, f"{name_path}/attestation.txt")
        write_json(keys, cls.key_path)

    def create_token(cls, ephemeral_algorithm: str = "secp256k1") -> str:
        keys = cls.get_keys()
        keys["token_sequence"] += 1

        if ephemeral_algorithm == "dilithium":
            eph_entropy = os.urandom(32)
            eph_private_hex, eph_public_hex = dilithium_mod.derive_keypair(eph_entropy)
        else:
            algo = CryptoAlgorithm.SECP256K1
            seed = generate_seed(algorithm=algo)
            keypair = derive_keypair(seed)
            eph_public_hex = keypair[0]
            eph_private_hex = keypair[1]

        # Get master public key hex
        if keys.get("key_type") == "dilithium":
            master_public_key = keys["public_key"]
        else:
            master_public_key = (
                decode_node_public_key(keys["public_key"]).hex().upper()
            )

        manifest = generate_manifest(
            {
                "Sequence": keys["token_sequence"],
                "Domain": keys["domain"].encode("utf-8").hex(),
                "PublicKey": master_public_key,
                "SigningPubKey": eph_public_hex,
                "SigningPrivateKey": eph_private_hex,
                "MasterPrivateKey": keys["secret_key"],
            }
        )
        keys["manifest"] = manifest["xrpl"]

        # Store ephemeral key info
        keys["ephemeral_public_key"] = eph_public_hex
        keys["ephemeral_private_key"] = eph_private_hex
        keys["ephemeral_key_type"] = ephemeral_algorithm

        if ephemeral_algorithm == "dilithium":
            validation_key = eph_private_hex
        else:
            validation_key = eph_private_hex[2:]

        token = encode_blob(
            {
                "validation_secret_key": validation_key,
                "manifest": manifest["base64"],
            }
        )

        token_path = os.path.join(cls.keystore_path, f"{cls.name}/token.txt")
        write_file(token.decode("utf-8"), token_path)
        manifest_path = os.path.join(cls.keystore_path, f"{cls.name}/manifest.txt")
        write_file(manifest["base64"], manifest_path)
        write_json(keys, cls.key_path)

    def read_token(cls) -> str:
        token_path = os.path.join(cls.keystore_path, f"{cls.name}/token.txt")
        token = read_txt(token_path)
        return token[0]

    def read_manifest(cls) -> str:
        manifest_path = os.path.join(cls.keystore_path, f"{cls.name}/manifest.txt")
        manifest = read_txt(manifest_path)
        return manifest[0]
