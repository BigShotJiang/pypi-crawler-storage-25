# Changelog

All notable changes to the `roovy-sdk` will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.3.3] - 2026-04-14
### Added
- **Auto-fallback Recovery:** Streaming wrappers (`generate_stream`, `generate_template_stream`) automatically intercept critical validation failures and transparently trigger a non-streaming background recovery call.
- **Terminal Retry Logging:** Added integrated Python `logging` warnings out of the box so that retry counts and background recovery efforts are visible when generating via console or pipelines.

### Improved
- **Conversational Validation Feedback Context:** `RoovyClient` now prepends the LLM’s previous invalid JSON as an assistant message into the API message history buffer, providing the final validation rules exact contextual layout for the next retry iteration.
- **Precision Validation Readouts:** Enhanced `_format_validation_errors()` logs the precise input `e.get('input')` value directly back to the LLM to easily isolate and patch dictionary discrepancies in the schema object matrix.
- **Garbage-Tolerant Parsing:** `_clean_json_response()` now uses a stable depth-tracking brace algorithm to perfectly isolate nested JSON blocks even when preceded or trailed by LLM "chatty" markdown artifacts.

## [0.3.2] - Previous Version
- Stable release with core WhatsApp Flow Components, Message Templates, and default LLM bindings.
