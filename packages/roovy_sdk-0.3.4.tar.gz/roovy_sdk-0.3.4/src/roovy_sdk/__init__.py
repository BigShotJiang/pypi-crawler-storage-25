"""Roovy SDK - Python SDK for generating WhatsApp Flows and Message Templates using LLMs."""

from roovy_sdk.client import RoovyClient
from roovy_sdk.docs import get_enhanced_prompt, load_docs_from_file
from roovy_sdk.schema import (
    WhatsAppFlow,
    Screen,
    SingleColumnLayout,
    Form,
    Component,
    DataSourceItem,
    validate_flow,
    # Text components
    TextHeading,
    TextSubheading,
    TextBody,
    TextCaption,
    # Input components
    TextInput,
    TextArea,
    Dropdown,
    RadioButtonsGroup,
    ChipsSelector,
    CheckboxGroup,
    OptIn,
    # Date/Media components
    CalendarPicker,
    DatePicker,
    PhotoPicker,
    DocumentPicker,
    Image,
    # Navigation components
    Footer,
    Button,
    EmbeddedLink,
    # Conditional components
    IfConditional,
    SwitchConditional,
    # Actions
    NavigateAction,
    CompleteAction,
    OpenUrlAction,
)
from roovy_sdk.template_schema import (
    TemplateResult,
    TemplateCreation,
    TemplateSend,
    TemplateSendInfo,
    # Creation components
    HeaderComponent,
    BodyComponent,
    FooterComponent as TemplateFooterComponent,
    ButtonsComponent,
    # Button types
    QuickReplyButton,
    UrlButton,
    PhoneNumberButton,
    FlowButton,
    # Send types
    SendComponent,
    TextParameter,
    ImageParameter,
    VideoParameter,
    DocumentParameter,
    FlowAction,
    FlowActionParameter,
    # Validation
    validate_template_creation,
    validate_template_result,
)

__version__ = "0.3.2"

__all__ = [
    # Main client
    "RoovyClient",
    # === Flow types ===
    "WhatsAppFlow",
    "Screen",
    "SingleColumnLayout",
    "Form",
    "Component",
    "DataSourceItem",
    "validate_flow",
    # Text components
    "TextHeading",
    "TextSubheading",
    "TextBody",
    "TextCaption",
    # Input components
    "TextInput",
    "TextArea",
    "Dropdown",
    "RadioButtonsGroup",
    "ChipsSelector",
    "CheckboxGroup",
    "OptIn",
    # Date/Media components
    "CalendarPicker",
    "DatePicker",
    "PhotoPicker",
    "DocumentPicker",
    "Image",
    # Navigation components
    "Footer",
    "Button",
    "EmbeddedLink",
    # Conditional components
    "IfConditional",
    "SwitchConditional",
    # Actions
    "NavigateAction",
    "CompleteAction",
    "OpenUrlAction",
    # === Template types ===
    "TemplateResult",
    "TemplateCreation",
    "TemplateSend",
    "TemplateSendInfo",
    # Creation components
    "HeaderComponent",
    "BodyComponent",
    "TemplateFooterComponent",
    "ButtonsComponent",
    # Button types
    "QuickReplyButton",
    "UrlButton",
    "PhoneNumberButton",
    "FlowButton",
    # Send types
    "SendComponent",
    "TextParameter",
    "ImageParameter",
    "VideoParameter",
    "DocumentParameter",
    "FlowAction",
    "FlowActionParameter",
    # Validation
    "validate_template_creation",
    "validate_template_result",
    # Docs utilities
    "get_enhanced_prompt",
    "load_docs_from_file",
]
