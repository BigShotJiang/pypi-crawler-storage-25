from html import escape
from html.parser import HTMLParser
from typing import Callable, List, Optional, Tuple

from .utils import should_translate, split_preserve_whitespace


SKIP_TAGS = {"script", "style", "noscript"}
TRANSLATABLE_ATTRS = {"placeholder", "title", "alt", "aria-label"}
BUTTON_VALUE_TYPES = {"button", "submit", "reset"}


def resolve_prompt_type(tag: Optional[str], attr_name: Optional[str]) -> str:
    if tag == "button" or attr_name == "value":
        return "button"
    if attr_name is not None:
        return "attr"
    return "normal"


class SimpleHTMLTranslator(HTMLParser):
    def __init__(self, translate_callback: Callable[[str, Optional[str], Optional[str]], str]):
        super().__init__(convert_charrefs=False)
        self.result: List[str] = []
        self.translate_callback = translate_callback
        self.tag_stack: List[str] = []
        self.skip_stack: List[bool] = []
        self.skip_depth = 0

    @property
    def current_tag(self) -> Optional[str]:
        return self.tag_stack[-1] if self.tag_stack else None

    def _should_skip_tag(self, tag: str, attrs: List[Tuple[str, Optional[str]]]) -> bool:
        if tag in SKIP_TAGS:
            return True

        attrs_dict = {k: v for k, v in attrs}
        if attrs_dict.get("id") == "langSwitch":
            return True
        if attrs_dict.get("translate") == "no":
            return True
        if attrs_dict.get("data-translate") == "no":
            return True
        return False

    def _render_starttag(self, tag: str, attrs: List[Tuple[str, Optional[str]]], closing: str = ">") -> str:
        rendered_attrs = []
        attrs_dict = {k: v for k, v in attrs}
        input_type = (attrs_dict.get("type") or "").strip().lower()

        for name, value in attrs:
            if value is None:
                rendered_attrs.append(name)
                continue

            new_value = value

            if self.skip_depth == 0:
                if name in TRANSLATABLE_ATTRS and should_translate(value, attr_name=name):
                    new_value = self.translate_callback(value, tag, name)
                elif (
                    tag == "input"
                    and name == "value"
                    and input_type in BUTTON_VALUE_TYPES
                    and should_translate(value, attr_name=name)
                ):
                    new_value = self.translate_callback(value, tag, name)

            rendered_attrs.append(f'{name}="{escape(new_value, quote=True)}"')

        if rendered_attrs:
            return f"<{tag} {' '.join(rendered_attrs)}{closing}"
        return f"<{tag}{closing}"

    def handle_starttag(self, tag, attrs):
        skip_this_tag = self._should_skip_tag(tag, attrs)
        self.result.append(self._render_starttag(tag, attrs, closing=">"))
        self.tag_stack.append(tag)
        self.skip_stack.append(skip_this_tag)
        if skip_this_tag:
            self.skip_depth += 1

    def handle_startendtag(self, tag, attrs):
        self.result.append(self._render_starttag(tag, attrs, closing=" />"))

    def handle_endtag(self, tag):
        self.result.append(f"</{tag}>")
        if self.tag_stack:
            self.tag_stack.pop()
        if self.skip_stack:
            skip_this_tag = self.skip_stack.pop()
            if skip_this_tag and self.skip_depth > 0:
                self.skip_depth -= 1

    def handle_data(self, data):
        if self.skip_depth > 0:
            self.result.append(data)
            return

        if not should_translate(data):
            self.result.append(data)
            return

        leading, core, trailing = split_preserve_whitespace(data)
        if not core:
            self.result.append(data)
            return

        translated = self.translate_callback(core, self.current_tag, None)
        self.result.append(f"{leading}{translated}{trailing}")

    def handle_entityref(self, name):
        self.result.append(f"&{name};")

    def handle_charref(self, name):
        self.result.append(f"&#{name};")

    def handle_comment(self, data):
        self.result.append(f"<!--{data}-->")

    def handle_decl(self, decl):
        self.result.append(f"<!{decl}>")

    def handle_pi(self, data):
        self.result.append(f"<?{data}>")

    def unknown_decl(self, data):
        self.result.append(f"<![{data}]>")

    def get_html(self) -> str:
        return "".join(self.result)


def collect_translatable_items(html: str) -> List[Tuple[str, str]]:
    collected: List[Tuple[str, str]] = []
    seen = set()

    def collector(text: str, tag: Optional[str], attr_name: Optional[str]) -> str:
        key = (text, resolve_prompt_type(tag, attr_name))
        if key not in seen:
            seen.add(key)
            collected.append(key)
        return text

    parser = SimpleHTMLTranslator(translate_callback=collector)
    parser.feed(html)
    parser.close()
    return collected