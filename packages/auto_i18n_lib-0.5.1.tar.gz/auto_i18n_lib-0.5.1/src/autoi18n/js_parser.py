import hashlib
import os
import re
from typing import Dict, List


CALL_WITH_DEFAULT_RE = re.compile(
    r"""(?:\bt|\btranslateKey)\(\s*["']([^"']+)["']\s*,\s*["']([^"']+)["']\s*\)"""
)
DICT_PROP_RE = re.compile(r"""([A-Za-z0-9_\-]+)\s*:\s*["']([^"']+)["']""")


def _stable_hash(value: str, size: int = 10) -> str:
    return hashlib.sha1(value.encode("utf-8")).hexdigest()[:size]


def _compose_key(namespace: str, raw_key: str) -> str:
    key = str(raw_key or "").strip().replace(" ", "_")
    if not key:
        key = "key"
    key = re.sub(r"[^A-Za-z0-9_\-\.]", "_", key)
    return f"{namespace}.{key}"


def _looks_like_phrase(text: str) -> bool:
    stripped = str(text or "").strip()
    if not stripped:
        return False
    if len(stripped) < 2:
        return False
    return True


def extract_js_keys_from_content(content: str, namespace: str = "ui") -> List[Dict[str, str]]:
    result: Dict[str, Dict[str, str]] = {}

    for key, default_text in CALL_WITH_DEFAULT_RE.findall(content):
        translated_key = _compose_key(namespace, key)
        result[translated_key] = {
            "key": translated_key,
            "text": default_text.strip(),
            "source": "call",
        }

    for prop, text in DICT_PROP_RE.findall(content):
        clean = text.strip()
        if not _looks_like_phrase(clean):
            continue
        generated_key = _compose_key(namespace, prop)
        if generated_key not in result:
            result[generated_key] = {
                "key": generated_key,
                "text": clean,
                "source": "dict",
            }

    return [result[key] for key in sorted(result.keys())]


def extract_js_keys_from_files(file_paths: List[str], namespace: str = "ui") -> List[Dict[str, str]]:
    all_items: Dict[str, Dict[str, str]] = {}

    for path in sorted(file_paths):
        try:
            with open(path, "r", encoding="utf-8") as f:
                content = f.read()
        except Exception:
            continue

        for item in extract_js_keys_from_content(content, namespace=namespace):
            stable_key = item["key"]
            if stable_key in all_items:
                continue
            all_items[stable_key] = {
                **item,
                "file": os.path.abspath(path),
                "fingerprint": _stable_hash(f'{path}:{item["key"]}:{item["text"]}'),
            }

    return [all_items[key] for key in sorted(all_items.keys())]
