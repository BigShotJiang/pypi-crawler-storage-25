import json
from typing import Dict


def build_frontend_runtime_script(
    translations: Dict[str, str],
    fallback_lang: str = "ru",
    dynamic_dom_enabled: bool = False,
) -> str:
    payload = json.dumps(translations or {}, ensure_ascii=False)
    observer_enabled = "true" if dynamic_dom_enabled else "false"

    return f"""
(function () {{
  const store = {payload};
  const fallbackLang = {json.dumps(fallback_lang)};
  const dynamicDomEnabled = {observer_enabled};

  function translateKey(key, fallback) {{
    if (typeof key !== "string" || !key.trim()) {{
      return fallback || key;
    }}
    if (Object.prototype.hasOwnProperty.call(store, key)) {{
      return store[key];
    }}
    return fallback || key;
  }}

  function translateDom(root) {{
    const scope = root || document;
    const nodes = scope.querySelectorAll("[data-i18n]");
    nodes.forEach(function (node) {{
      const key = node.getAttribute("data-i18n");
      if (!key) return;
      node.textContent = translateKey(key, node.textContent || key);
    }});
  }}

  function mountObserver() {{
    if (!dynamicDomEnabled || typeof MutationObserver === "undefined") {{
      return;
    }}
    const observer = new MutationObserver(function (mutations) {{
      mutations.forEach(function (mutation) {{
        mutation.addedNodes.forEach(function (node) {{
          if (!node || node.nodeType !== 1) return;
          if (node.matches && node.matches("[data-i18n]")) {{
            node.textContent = translateKey(
              node.getAttribute("data-i18n"),
              node.textContent || node.getAttribute("data-i18n")
            );
          }}
          if (node.querySelectorAll) {{
            translateDom(node);
          }}
        }});
      }});
    }});
    observer.observe(document.documentElement || document.body, {{ childList: true, subtree: true }});
  }}

  window.autoI18n = window.autoI18n || {{}};
  window.autoI18n.fallbackLang = fallbackLang;
  window.autoI18n.translateKey = translateKey;
  window.autoI18n.translateDom = translateDom;
  window.autoI18n.translations = store;

  if (document.readyState === "loading") {{
    document.addEventListener("DOMContentLoaded", function () {{
      translateDom(document);
      mountObserver();
    }});
  }} else {{
    translateDom(document);
    mountObserver();
  }}
}})();
""".strip()
