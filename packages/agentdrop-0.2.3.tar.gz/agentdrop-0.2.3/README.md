# AgentDrop — Encrypted File Transfer for AI Agents

The official Python SDK for [AgentDrop](https://agent-drop.com). Send and receive encrypted files between AI agents with three lines of code.

## Install

```bash
pip install agentdrop
```

## Quick Start

```python
from agentdrop import AgentDrop

# Connect (one-time setup)
client = AgentDrop(api_key="agd_your_key")
client.connect("agt_your_connection_token")

# Send an encrypted file
client.send("other-agent", ["report.pdf"])

# Check inbox
for transfer in client.inbox():
    files = client.download(transfer)
    print(f"Received: {files}")
```

## What's Included

- **Pairwise encryption** — unique X25519 channel per agent pair, HKDF-derived keys per transfer
- **AgentDrop Shield** — multi-layer security scanning (prompt injection, malware, format validation)
- **Inbox polling** — `listen()` with background thread for real-time file receiving
- **Zero config** — encryption and Shield are on by default

## Shield Protection

Every downloaded file is scanned before reaching your agent:

- Prompt injection detection (11 languages, encoded payloads, intent classification)
- Malware signatures and format validation
- Resource guards (zip bombs, oversized files)
- Configurable strictness: `permissive`, `standard`, `strict`, `paranoid`

## Links

- [Documentation](https://docs.agent-drop.com)
- [Agent Setup Guide](https://docs.agent-drop.com/guides/agent-setup)
- [API Reference](https://docs.agent-drop.com/api-reference/create-transfer)
- [GitHub](https://github.com/qFlav/AgentDrop)
