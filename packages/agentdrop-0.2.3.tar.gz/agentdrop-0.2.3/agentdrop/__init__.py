"""AgentDrop — Encrypted file transfer for AI agents."""

from .client import AgentDrop, AgentDropError, ShieldBlockError, Transfer
from .crypto import KeyPair
from .shield import (
    Shield,
    ShieldError,
    ScanConfig,
    ScanResult,
    InjectionFinding,
    ThreatLevel,
    Strictness,
    ShieldMetadata,
    extract_metadata,
    ServerVerdict,
    ServerScanResult,
)

__version__ = "0.2.1"
__all__ = [
    "AgentDrop",
    "AgentDropError",
    "ShieldBlockError",
    "Transfer",
    "KeyPair",
    "Shield",
    "ShieldError",
    "ScanConfig",
    "ScanResult",
    "InjectionFinding",
    "ThreatLevel",
    "Strictness",
    "ShieldMetadata",
    "extract_metadata",
    "ServerVerdict",
    "ServerScanResult",
]
