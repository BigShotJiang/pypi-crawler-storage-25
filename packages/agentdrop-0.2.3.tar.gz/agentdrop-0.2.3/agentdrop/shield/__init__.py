"""
AgentDrop Shield -- File security scanner for AI agent pipelines.

Multi-layer scanning engine that sits between decryption and the LLM,
detecting prompt injection, format anomalies, resource exhaustion
attacks, and content-level threats.

Quick start::

    from agentdrop.shield import Shield

    shield = Shield()
    result = shield.scan(file_bytes, "report.pdf")

    if result.blocked:
        print(f"BLOCKED: {result.summary()}")
    else:
        print(f"OK: {result.summary()}")

Customise strictness::

    from agentdrop.shield import Shield, ScanConfig, Strictness

    config = ScanConfig(strictness=Strictness.PARANOID)
    shield = Shield(config)
"""

from .models import (
    InjectionFinding,
    ScanConfig,
    ScanResult,
    Strictness,
    ThreatLevel,
)
from .scanner import Shield, ShieldError
from .intent_classifier import IntentClassifier, IntentClassification, IntentSignal
from .semantic_analyzer import SemanticAnalyzer, SemanticScore, SemanticSignal
from .behavioral_tracker import BehavioralTracker, BehavioralAssessment
from .metadata_extractor import ShieldMetadata, extract_metadata
from .server_types import ServerVerdict, ServerScanResult

__all__ = [
    "Shield",
    "ShieldError",
    "ScanConfig",
    "ScanResult",
    "InjectionFinding",
    "ThreatLevel",
    "Strictness",
    "IntentClassifier",
    "IntentClassification",
    "IntentSignal",
    "BehavioralTracker",
    "BehavioralAssessment",
    "SemanticAnalyzer",
    "SemanticScore",
    "SemanticSignal",
    "ShieldMetadata",
    "extract_metadata",
    "ServerVerdict",
    "ServerScanResult",
]
