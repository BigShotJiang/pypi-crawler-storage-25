import g4f
import json
import os
from rich.console import Console
from rich.panel import Panel

# Отключаем весь спам в консоли
os.environ["G4F_VERSION_CHECK"] = "False"
console = Console(width=70)
PROFILE_FILE = os.path.join(os.path.expanduser("~"), "ai_matish_profile.json")

def get_profile():
    if not os.path.exists(PROFILE_FILE):
        console.print("[bold yellow]ЗНАКОМСТВО[/bold yellow]\nКак тебя зовут?")
        name = input(">>> ").strip() or "Даниил"
        profile = {"name": name}
        json.dump(profile, open(PROFILE_FILE, "w", encoding="utf-8"), ensure_ascii=False)
        return profile
    return json.load(open(PROFILE_FILE, "r", encoding="utf-8"))

def get_ai_response(user_input, user_name):
    try:
        # Самый простой и быстрый запрос без поиска и раздумий
        response = g4f.ChatCompletion.create(
            model=g4f.models.default,
            messages=[
                {"role": "system", "content": f"Ты - AI Matish, ассистент {user_name}. Отвечай кратко, без смайлов."},
                {"role": "user", "content": user_input}
            ]
        )
        return response
    except Exception as e:
        return f"Ошибка: {e}"

def main():
    profile = get_profile()
    user_name = profile.get("name")
    
    console.print(Panel(f"[bold magenta]AI Matish v12.0[/bold magenta]\n[cyan]Пользователь: {user_name}[/cyan]", width=50))

    while True:
        try:
            user_input = console.input(f"\n[bold green]{user_name}[/bold green] >>> ").strip()
            if user_input.lower() in ['exit', 'q', 'выход']: break
            if not user_input: continue

            with console.status("[bold yellow]Думаю..."):
                reply = get_ai_response(user_input, user_name)
            
            # Выводим просто текст в рамке, без Markdown (чтобы не жмыхало)
            console.print(Panel(str(reply), title="Matish", border_style="cyan", width=65))
            
        except KeyboardInterrupt:
            console.print("\n[yellow]Сброс.[/yellow]"); continue
        except Exception as e:
            console.print(f"[red]Сбой: {e}[/red]")

if __name__ == "__main__":
    main()
