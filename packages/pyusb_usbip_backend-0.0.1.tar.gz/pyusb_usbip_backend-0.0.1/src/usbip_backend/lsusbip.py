"""lsusbip -- list USB devices available over USB/IP, like lsusb."""

from __future__ import annotations

import argparse
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed

from .backend import get_backend, USBIP_TCP_PORT
from .mdns import discover_usbip_servers


def _parse_host_port(spec: str):
    """Parse 'host' or 'host:port' into (host, port)."""
    if ":" in spec:
        host, port_str = spec.rsplit(":", 1)
        return host, int(port_str)
    return spec, USBIP_TCP_PORT


def _list_devices(host: str, port: int, timeout: float):
    """Return (host, port, devices) or (host, port, error_string)."""
    try:
        backend = get_backend(host, port, timeout)
        devices = list(backend.enumerate_devices())
        return host, port, devices
    except Exception as e:
        return host, port, str(e)


def main() -> int:
    p = argparse.ArgumentParser(
        prog="lsusbip",
        description="List USB devices available over USB/IP (like lsusb)",
    )
    p.add_argument(
        "host",
        nargs="*",
        help="USB/IP server(s) as host or host:port "
        "(if none given, discover via mDNS)",
    )
    p.add_argument(
        "--mdns-timeout",
        type=float,
        default=3.0,
        help="mDNS discovery timeout in seconds (default: 3.0)",
    )
    p.add_argument(
        "--timeout",
        type=float,
        default=2.0,
        help="TCP connect timeout in seconds (default: 2.0)",
    )
    p.add_argument(
        "-t", "--tree",
        action="store_true",
        help="Show tree view grouped by host",
    )
    p.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Show interface details",
    )
    args = p.parse_args()

    # Build target list from explicit hosts and/or mDNS discovery
    # Each target is (address, port, mdns_name) where mdns_name may be None.
    seen = set()
    targets = []

    for spec in args.host:
        host, port = _parse_host_port(spec)
        key = (host, port)
        if key not in seen:
            seen.add(key)
            targets.append((host, port, None))

    if not targets:
        services = discover_usbip_servers(timeout=args.mdns_timeout)
        if not services:
            print("No USB/IP servers found via mDNS", file=sys.stderr)
            return 1
        for svc in services:
            key = (svc["address"], svc["port"])
            if key not in seen:
                seen.add(key)
                mdns_name = svc.get("host") or svc.get("name") or None
                targets.append((svc["address"], svc["port"], mdns_name))

    # Query all hosts in parallel
    results = []
    mdns_names = {}  # (addr, port) -> mdns_name
    with ThreadPoolExecutor(max_workers=max(1, len(targets))) as pool:
        futures = {
            pool.submit(_list_devices, addr, port, args.timeout): (addr, port)
            for addr, port, _name in targets
        }
        for addr, port, name in targets:
            if name:
                mdns_names[(addr, port)] = name
        for fut in as_completed(futures):
            results.append(fut.result())

    # Sort by host, then port
    results.sort(key=lambda r: (r[0], r[1]))

    found_any = False
    for host, port, devices in results:
        mdns_name = mdns_names.get((host, port))
        host_label = f"{mdns_name} ({host}:{port})" if mdns_name else f"{host}:{port}"

        if isinstance(devices, str):
            # Error
            print(f"# {host_label} -- error: {devices}", file=sys.stderr)
            continue

        if not devices:
            if args.tree:
                print(f"{host_label}  (no devices)")
            continue

        found_any = True

        if args.tree:
            print(host_label)
            for d in devices:
                print(
                    f"  Bus {d.busnum:03d} Device {d.devnum:03d}: "
                    f"ID {d.id_vendor:04x}:{d.id_product:04x} "
                    f"({d.busid})"
                )
                if args.verbose:
                    for i, (cls, sub, proto) in enumerate(d.interfaces):
                        print(
                            f"    Interface {i}: "
                            f"class={cls:02x} subclass={sub:02x} protocol={proto:02x}"
                        )
        else:
            for d in devices:
                print(
                    f"Bus {d.busnum:03d} Device {d.devnum:03d}: "
                    f"ID {d.id_vendor:04x}:{d.id_product:04x} "
                    f"({host_label} {d.busid})"
                )
                if args.verbose:
                    for i, (cls, sub, proto) in enumerate(d.interfaces):
                        print(
                            f"  Interface {i}: "
                            f"class={cls:02x} subclass={sub:02x} protocol={proto:02x}"
                        )

    if not found_any:
        print("No USB devices found on any USB/IP server", file=sys.stderr)
        return 1

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
