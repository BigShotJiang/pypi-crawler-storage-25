from __future__ import annotations

import argparse
import json

import usb.core

from .backend import get_backend
from .mdns import discover_usbip_servers
from .pcap import PcapWriter
from .syslog import SyslogReceiver


def _require_host(args: argparse.Namespace) -> None:
    if not args.host:
        raise SystemExit("--host is required for this command")


class _Session:
    """Manages backend, pcap writer, and syslog receiver lifecycle."""

    def __init__(self, args: argparse.Namespace):
        self.pcap = None
        self._pcap_file = None
        self.syslog = None

        if args.pcap:
            self._pcap_file = open(args.pcap, "wb")
            self.pcap = PcapWriter(self._pcap_file)

        self.backend = get_backend(args.host, args.port, args.timeout, pcap=self.pcap)

        if args.host and args.syslog:
            self.syslog = SyslogReceiver(args.host, port=args.syslog_port, pcap=self.pcap)
            self.syslog.start()

    def close(self):
        if self.syslog is not None:
            self.syslog.stop()
        if self.pcap is not None:
            self.pcap.close()
        if self._pcap_file is not None:
            self._pcap_file.close()


def _cmd_discover(args: argparse.Namespace) -> int:
    services = discover_usbip_servers(timeout=args.mdns_timeout)
    if args.json:
        print(json.dumps(services, indent=2))
        return 0

    if not services:
        print("No USB/IP mDNS services found")
        return 0

    for svc in services:
        txt = svc.get("txt", {})
        txt_bits = " ".join(f"{k}={v}" if v != "" else k for k, v in txt.items())
        print(f"{svc['name']} {svc['host']} ({svc['address']}):{svc['port']} {txt_bits}".rstrip())
    return 0


def _cmd_list(args: argparse.Namespace) -> int:
    _require_host(args)
    session = _Session(args)
    try:
        devices = list(session.backend.enumerate_devices())
        if not devices:
            print("No exported USB/IP devices")
            return 0

        for d in devices:
            print(
                f"{d.busid} vid:pid={d.id_vendor:04x}:{d.id_product:04x} "
                f"class={d.device_class:02x}/{d.device_subclass:02x}/{d.device_protocol:02x} "
                f"cfg={d.configuration_value} ifaces={d.num_interfaces}"
            )
        return 0
    finally:
        session.close()


def _cmd_probe(args: argparse.Namespace) -> int:
    _require_host(args)
    session = _Session(args)
    try:
        dev = usb.core.find(backend=session.backend, idVendor=args.vid, idProduct=args.pid)
        if dev is None:
            print("Device not found")
            return 1

        info = {
            "vendor_id": dev.idVendor,
            "product_id": dev.idProduct,
            "bcd_device": dev.bcdDevice,
            "class": dev.bDeviceClass,
            "subclass": dev.bDeviceSubClass,
            "protocol": dev.bDeviceProtocol,
            "num_configurations": dev.bNumConfigurations,
            "bus": dev.bus,
            "address": dev.address,
        }
        print(json.dumps(info, indent=2))

        if args.get_device_desc:
            raw = dev.ctrl_transfer(0x80, 0x06, 0x0100, 0, 18, timeout=args.ctrl_timeout_ms)
            print("device_descriptor_raw:", bytes(raw).hex())
        return 0
    finally:
        session.close()


def _cmd_control(args: argparse.Namespace) -> int:
    _require_host(args)
    session = _Session(args)
    try:
        dev = usb.core.find(backend=session.backend, idVendor=args.vid, idProduct=args.pid)
        if dev is None:
            print("Device not found")
            return 1

        if args.direction == "in":
            data = dev.ctrl_transfer(
                args.bm_request_type | 0x80,
                args.b_request,
                args.w_value,
                args.w_index,
                args.length,
                timeout=args.ctrl_timeout_ms,
            )
            print(bytes(data).hex())
        else:
            payload = bytes.fromhex(args.data_hex)
            wrote = dev.ctrl_transfer(
                args.bm_request_type & 0x7F,
                args.b_request,
                args.w_value,
                args.w_index,
                payload,
                timeout=args.ctrl_timeout_ms,
            )
            print(f"wrote {wrote} bytes")
        return 0
    finally:
        session.close()


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Test PyUSB USB/IP backend")
    p.add_argument("--host", help="USB/IP server host")
    p.add_argument("--port", type=int, default=3240)
    p.add_argument("--timeout", type=float, default=2.0, help="TCP connect timeout in seconds")
    p.add_argument("--pcap", metavar="PATH",
                   help="Write USB URBs to a pcap file or FIFO for Wireshark "
                        "(use mkfifo PATH && wireshark -k -i PATH for live view)")
    p.add_argument("--syslog", action="store_true",
                   help="Connect to ESP syslog on the same host and print log messages")
    p.add_argument("--syslog-port", type=int, default=1514,
                   help="TCP port for syslog (default: 1514)")

    sub = p.add_subparsers(dest="cmd", required=True)

    p_discover = sub.add_parser("discover", help="Discover USB/IP servers via mDNS")
    p_discover.add_argument("--mdns-timeout", type=float, default=3.0)
    p_discover.add_argument("--json", action="store_true", help="Output JSON")
    p_discover.set_defaults(func=_cmd_discover)

    p_list = sub.add_parser("list", help="List exported devices")
    p_list.set_defaults(func=_cmd_list)

    p_probe = sub.add_parser("probe", help="Find a device through PyUSB and print summary")
    p_probe.add_argument("--vid", type=lambda x: int(x, 0), required=True)
    p_probe.add_argument("--pid", type=lambda x: int(x, 0), required=True)
    p_probe.add_argument("--get-device-desc", action="store_true")
    p_probe.add_argument("--ctrl-timeout-ms", type=int, default=1000)
    p_probe.set_defaults(func=_cmd_probe)

    p_ctrl = sub.add_parser("control", help="Issue one control transfer")
    p_ctrl.add_argument("--vid", type=lambda x: int(x, 0), required=True)
    p_ctrl.add_argument("--pid", type=lambda x: int(x, 0), required=True)
    p_ctrl.add_argument("--direction", choices=["in", "out"], required=True)
    p_ctrl.add_argument("--bm-request-type", type=lambda x: int(x, 0), required=True)
    p_ctrl.add_argument("--b-request", type=lambda x: int(x, 0), required=True)
    p_ctrl.add_argument("--w-value", type=lambda x: int(x, 0), default=0)
    p_ctrl.add_argument("--w-index", type=lambda x: int(x, 0), default=0)
    p_ctrl.add_argument("--length", type=int, default=0, help="IN length")
    p_ctrl.add_argument("--data-hex", default="", help="OUT payload as hex")
    p_ctrl.add_argument("--ctrl-timeout-ms", type=int, default=1000)
    p_ctrl.set_defaults(func=_cmd_control)

    return p


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
