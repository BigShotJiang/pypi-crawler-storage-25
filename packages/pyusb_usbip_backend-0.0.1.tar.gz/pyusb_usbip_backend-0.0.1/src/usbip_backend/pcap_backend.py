"""Wrapper backend that adds pcapng capture to any PyUSB backend."""

from __future__ import annotations

import struct
import time
from typing import Optional

import usb.backend

from .pcap import (
    XFER_BULK,
    XFER_CONTROL,
    XFER_INTERRUPT,
    PcapWriter,
)


def _setup_packet(bmRequestType, bRequest, wValue, wIndex, wLength):
    return struct.pack("<BBHHH", bmRequestType & 0xFF, bRequest & 0xFF,
                       wValue & 0xFFFF, wIndex & 0xFFFF, wLength & 0xFFFF)


class PcapBackendWrapper(usb.backend.IBackend):
    """Wraps another PyUSB backend, logging all transfers to a PcapWriter."""

    def __init__(self, wrapped: usb.backend.IBackend, pcap: PcapWriter):
        self._wrapped = wrapped
        self._pcap = pcap

    # -- Passthrough methods (no capture needed) --

    def enumerate_devices(self):
        return self._wrapped.enumerate_devices()

    def get_parent(self, dev):
        return self._wrapped.get_parent(dev)

    def get_device_descriptor(self, dev):
        return self._wrapped.get_device_descriptor(dev)

    def get_configuration_descriptor(self, dev, config):
        return self._wrapped.get_configuration_descriptor(dev, config)

    def get_interface_descriptor(self, dev, intf, alt, config):
        return self._wrapped.get_interface_descriptor(dev, intf, alt, config)

    def get_endpoint_descriptor(self, dev, ep, intf, alt, config):
        return self._wrapped.get_endpoint_descriptor(dev, ep, intf, alt, config)

    def open_device(self, dev):
        return self._wrapped.open_device(dev)

    def close_device(self, dev_handle):
        return self._wrapped.close_device(dev_handle)

    def set_configuration(self, dev_handle, config_value):
        return self._wrapped.set_configuration(dev_handle, config_value)

    def get_configuration(self, dev_handle):
        return self._wrapped.get_configuration(dev_handle)

    def set_interface_altsetting(self, dev_handle, intf, altsetting):
        return self._wrapped.set_interface_altsetting(dev_handle, intf, altsetting)

    def claim_interface(self, dev_handle, intf):
        return self._wrapped.claim_interface(dev_handle, intf)

    def release_interface(self, dev_handle, intf):
        return self._wrapped.release_interface(dev_handle, intf)

    def clear_halt(self, dev_handle, ep):
        return self._wrapped.clear_halt(dev_handle, ep)

    def reset_device(self, dev_handle):
        return self._wrapped.reset_device(dev_handle)

    def is_kernel_driver_active(self, dev_handle, intf):
        return self._wrapped.is_kernel_driver_active(dev_handle, intf)

    def detach_kernel_driver(self, dev_handle, intf):
        return self._wrapped.detach_kernel_driver(dev_handle, intf)

    def attach_kernel_driver(self, dev_handle, intf):
        return self._wrapped.attach_kernel_driver(dev_handle, intf)

    # -- Device address helpers --

    def _dev_addr(self, dev_handle):
        """Best-effort extraction of bus/address from the device handle."""
        # PyUSB device handles vary by backend; try common attributes
        for attr in ("dev", "devid"):
            obj = getattr(dev_handle, attr, None)
            if obj is not None:
                bus = getattr(obj, "bus", None)
                addr = getattr(obj, "address", None)
                if bus is not None and addr is not None:
                    return int(bus), int(addr)
        return 0, 0

    # -- Captured transfer methods --

    def ctrl_transfer(self, dev_handle, bmRequestType, bRequest, wValue, wIndex, data, timeout):
        busnum, devnum = self._dev_addr(dev_handle)
        direction_in = bool(bmRequestType & 0x80)
        data_nbytes = len(data) * data.itemsize
        setup = _setup_packet(bmRequestType, bRequest, wValue, wIndex, data_nbytes)
        out_payload = b"" if direction_in else data.tobytes()

        urb_id = self._pcap.write_submit(
            transfer_type=XFER_CONTROL,
            ep=0,
            direction_in=direction_in,
            devnum=devnum,
            busnum=busnum,
            setup=setup,
            data=out_payload,
            urb_len=data_nbytes,
        )

        try:
            result = self._wrapped.ctrl_transfer(dev_handle, bmRequestType, bRequest,
                                                  wValue, wIndex, data, timeout)
        except Exception:
            self._pcap.write_complete(
                urb_id=urb_id,
                transfer_type=XFER_CONTROL,
                ep=0,
                direction_in=direction_in,
                devnum=devnum,
                busnum=busnum,
                status=-1,
            )
            raise

        if direction_in:
            resp = data[:result].tobytes()
        else:
            resp = b""

        self._pcap.write_complete(
            urb_id=urb_id,
            transfer_type=XFER_CONTROL,
            ep=0,
            direction_in=direction_in,
            devnum=devnum,
            busnum=busnum,
            status=0,
            data=resp,
            urb_len=result,
        )
        return result

    def bulk_write(self, dev_handle, ep, intf, data, timeout):
        return self._captured_write(XFER_BULK, dev_handle, ep, intf, data, timeout)

    def bulk_read(self, dev_handle, ep, intf, buff, timeout):
        return self._captured_read(XFER_BULK, dev_handle, ep, intf, buff, timeout)

    def intr_write(self, dev_handle, ep, intf, data, timeout):
        return self._captured_write(XFER_INTERRUPT, dev_handle, ep, intf, data, timeout)

    def intr_read(self, dev_handle, ep, intf, buff, timeout):
        return self._captured_read(XFER_INTERRUPT, dev_handle, ep, intf, buff, timeout)

    def iso_write(self, dev_handle, ep, intf, data, timeout):
        return self._wrapped.iso_write(dev_handle, ep, intf, data, timeout)

    def iso_read(self, dev_handle, ep, intf, buff, timeout):
        return self._wrapped.iso_read(dev_handle, ep, intf, buff, timeout)

    def _captured_write(self, xfer_type, dev_handle, ep, intf, data, timeout):
        busnum, devnum = self._dev_addr(dev_handle)
        payload = data.tobytes()

        urb_id = self._pcap.write_submit(
            transfer_type=xfer_type,
            ep=ep & 0x0F,
            direction_in=False,
            devnum=devnum,
            busnum=busnum,
            data=payload,
            urb_len=len(payload),
        )

        try:
            writer = self._wrapped.bulk_write if xfer_type == XFER_BULK else self._wrapped.intr_write
            result = writer(dev_handle, ep, intf, data, timeout)
        except Exception:
            self._pcap.write_complete(
                urb_id=urb_id, transfer_type=xfer_type, ep=ep & 0x0F,
                direction_in=False, devnum=devnum, busnum=busnum, status=-1,
            )
            raise

        self._pcap.write_complete(
            urb_id=urb_id, transfer_type=xfer_type, ep=ep & 0x0F,
            direction_in=False, devnum=devnum, busnum=busnum,
            status=0, urb_len=result,
        )
        return result

    def _captured_read(self, xfer_type, dev_handle, ep, intf, buff, timeout):
        busnum, devnum = self._dev_addr(dev_handle)
        nbytes = len(buff) * buff.itemsize

        urb_id = self._pcap.write_submit(
            transfer_type=xfer_type,
            ep=ep & 0x0F,
            direction_in=True,
            devnum=devnum,
            busnum=busnum,
            urb_len=nbytes,
        )

        try:
            reader = self._wrapped.bulk_read if xfer_type == XFER_BULK else self._wrapped.intr_read
            result = reader(dev_handle, ep, intf, buff, timeout)
        except Exception:
            self._pcap.write_complete(
                urb_id=urb_id, transfer_type=xfer_type, ep=ep & 0x0F,
                direction_in=True, devnum=devnum, busnum=busnum, status=-1,
            )
            raise

        self._pcap.write_complete(
            urb_id=urb_id, transfer_type=xfer_type, ep=ep & 0x0F,
            direction_in=True, devnum=devnum, busnum=busnum,
            status=0, data=buff[:result].tobytes(), urb_len=result,
        )
        return result
