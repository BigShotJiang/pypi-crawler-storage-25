"""Write USB URB and syslog captures in pcapng format for Wireshark.

Produces pcapng with two interfaces:
- Interface 0: LINKTYPE_USB_LINUX_MMAPPED (DLT 220) for USB URBs
- Interface 1: LINKTYPE_RAW (DLT 101) for syslog messages as UDP packets

Works with regular files and named pipes (FIFOs) for live Wireshark capture::

    mkfifo /tmp/usb.pcap
    wireshark -k -i /tmp/usb.pcap &
    # then pass pcap="/tmp/usb.pcap" to USBIPBackend
"""

from __future__ import annotations

import struct
import threading
import time
from typing import BinaryIO, Optional

from pcapng.blocks import EnhancedPacket, InterfaceDescription, SectionHeader
from pcapng.writer import FileWriter

# 64-byte usbmon pseudo-header (pcap_usb_header_mmapped)
_USBMON = struct.Struct("<QBBBBHbbqiiII8siiII")
assert _USBMON.size == 64

LINKTYPE_USB_LINUX_MMAPPED = 220
LINKTYPE_RAW = 101  # Raw IPv4/IPv6

USB_INTERFACE_ID = 0
SYSLOG_INTERFACE_ID = 1

# Transfer types (as used in usbmon)
XFER_ISO = 0
XFER_INTERRUPT = 1
XFER_CONTROL = 2
XFER_BULK = 3

# Event types
EVENT_SUBMIT = ord("S")
EVENT_COMPLETE = ord("C")


def _wrap_udp(payload: bytes, src_port: int = 1514, dst_port: int = 514) -> bytes:
    """Wrap payload in minimal IPv4 + UDP headers for LINKTYPE_RAW."""
    udp_len = 8 + len(payload)
    udp = struct.pack("!HHHH", src_port, dst_port, udp_len, 0)  # checksum=0

    total_len = 20 + udp_len
    # IPv4: version=4, ihl=5, total_length, id=0, flags=0, ttl=64, proto=17(UDP)
    ip = struct.pack("!BBHHHBBH4s4s",
        0x45, 0, total_len, 0, 0, 64, 17, 0,
        b"\x7f\x00\x00\x01",  # src 127.0.0.1
        b"\x7f\x00\x00\x01",  # dst 127.0.0.1
    )
    return ip + udp + payload


class PcapWriter:
    """Thread-safe pcapng writer for USB URBs."""

    def __init__(self, stream: BinaryIO) -> None:
        self._lock = threading.Lock()
        self._id_counter = 0

        self._shb = SectionHeader(options={
            "shb_userappl": "pyusb-usbip-backend",
        })
        self._shb.new_member(InterfaceDescription,
            link_type=LINKTYPE_USB_LINUX_MMAPPED,
            snaplen=0,
            options={
                "if_name": "usbip0",
                "if_description": "USB/IP remote device capture",
            },
        )
        self._shb.new_member(InterfaceDescription,
            link_type=LINKTYPE_RAW,
            snaplen=0,
            options={
                "if_name": "syslog0",
                "if_description": "ESP syslog (RFC 5424 over TCP)",
            },
        )
        self._writer = FileWriter(stream, self._shb)

    def _next_id(self) -> int:
        self._id_counter += 1
        return self._id_counter

    def write_urb(
        self,
        *,
        event_type: int,
        transfer_type: int,
        ep: int,
        direction_in: bool,
        devnum: int,
        busnum: int,
        setup: bytes = b"\x00" * 8,
        status: int = 0,
        urb_len: int = 0,
        data: bytes = b"",
        urb_id: Optional[int] = None,
        ts: Optional[float] = None,
    ) -> int:
        """Write one usbmon record.  Returns the urb_id used."""
        if urb_id is None:
            urb_id = self._next_id()
        if ts is None:
            ts = time.time()

        ts_us = int(ts * 1_000_000)

        epnum = (ep & 0x0F) | (0x80 if direction_in else 0x00)

        # setup_flag: 0 means setup bytes are present (control submit only)
        # data_flag: 0 means payload data follows the header
        is_control_submit = (transfer_type == XFER_CONTROL
                             and event_type == EVENT_SUBMIT)
        setup_flag = 0 if is_control_submit else ord("-")
        data_flag = 0 if data else ord("<")

        setup_bytes = setup[:8].ljust(8, b"\x00") if is_control_submit else b"\x00" * 8

        hdr = _USBMON.pack(
            urb_id,
            event_type,
            transfer_type,
            epnum,
            devnum & 0xFF,
            busnum & 0xFFFF,
            setup_flag,
            data_flag,
            int(ts),
            int((ts - int(ts)) * 1_000_000),
            status,
            urb_len,
            len(data),
            setup_bytes,
            0,  # interval
            0,  # start_frame
            0,  # xfer_flags
            0,  # ndesc
        )

        packet_data = hdr + data

        epb = self._shb.new_member(EnhancedPacket,
            interface_id=0,
            timestamp_high=(ts_us >> 32) & 0xFFFFFFFF,
            timestamp_low=ts_us & 0xFFFFFFFF,
            packet_data=packet_data,
        )

        with self._lock:
            self._writer.write_block(epb)

        return urb_id

    def write_submit(
        self,
        *,
        transfer_type: int,
        ep: int,
        direction_in: bool,
        devnum: int,
        busnum: int,
        setup: bytes = b"\x00" * 8,
        data: bytes = b"",
        urb_len: int = 0,
    ) -> int:
        """Write a Submit ('S') record.  Returns urb_id for the matching Complete."""
        return self.write_urb(
            event_type=EVENT_SUBMIT,
            transfer_type=transfer_type,
            ep=ep,
            direction_in=direction_in,
            devnum=devnum,
            busnum=busnum,
            setup=setup,
            status=-115,  # -EINPROGRESS, standard for submit
            urb_len=urb_len,
            data=data,
        )

    def write_complete(
        self,
        *,
        urb_id: int,
        transfer_type: int,
        ep: int,
        direction_in: bool,
        devnum: int,
        busnum: int,
        status: int = 0,
        data: bytes = b"",
        urb_len: int = 0,
    ) -> None:
        """Write a Complete ('C') record matching a prior Submit."""
        self.write_urb(
            event_type=EVENT_COMPLETE,
            transfer_type=transfer_type,
            ep=ep,
            direction_in=direction_in,
            devnum=devnum,
            busnum=busnum,
            status=status,
            urb_len=urb_len,
            data=data,
            urb_id=urb_id,
        )

    def write_syslog(self, message: bytes, *, ts: Optional[float] = None) -> None:
        """Write a syslog message as a fake UDP packet on the syslog interface."""
        if ts is None:
            ts = time.time()
        ts_us = int(ts * 1_000_000)

        packet_data = _wrap_udp(message, src_port=1514, dst_port=514)

        epb = self._shb.new_member(EnhancedPacket,
            interface_id=SYSLOG_INTERFACE_ID,
            timestamp_high=(ts_us >> 32) & 0xFFFFFFFF,
            timestamp_low=ts_us & 0xFFFFFFFF,
            packet_data=packet_data,
        )

        with self._lock:
            self._writer.write_block(epb)

    def close(self) -> None:
        self._writer.stream.flush()
