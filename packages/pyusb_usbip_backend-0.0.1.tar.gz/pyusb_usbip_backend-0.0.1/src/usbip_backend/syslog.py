"""Receive ESP syslog messages (RFC 5424) over TCP and optionally capture to pcapng."""

from __future__ import annotations

import socket
import sys
import threading
from typing import Optional

from .pcap import PcapWriter

SYSLOG_PORT = 1514


class SyslogReceiver:
    """Background thread that reads newline-delimited syslog from TCP."""

    def __init__(self, host: str, port: int = SYSLOG_PORT, pcap: Optional[PcapWriter] = None):
        self._host = host
        self._port = port
        self._pcap = pcap
        self._sock: Optional[socket.socket] = None
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()

    def start(self) -> None:
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._sock is not None:
            try:
                self._sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            self._sock.close()
        if self._thread is not None:
            self._thread.join(timeout=2)

    def _run(self) -> None:
        try:
            self._sock = socket.create_connection((self._host, self._port), timeout=5)
            self._sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        except OSError as exc:
            print(f"[syslog] Could not connect to {self._host}:{self._port}: {exc}",
                  file=sys.stderr)
            return

        self._sock.settimeout(1.0)
        buf = b""
        while not self._stop.is_set():
            try:
                chunk = self._sock.recv(4096)
            except socket.timeout:
                continue
            except OSError:
                break
            if not chunk:
                break
            buf += chunk
            while b"\n" in buf:
                line, buf = buf.split(b"\n", 1)
                line = line.rstrip(b"\r")
                if not line:
                    continue
                self._handle_message(line)

    def _handle_message(self, raw: bytes) -> None:
        # Strip RFC 6587 octet-counting prefix ("123 <pri>..." -> "<pri>...")
        msg = raw
        space = raw.find(b" ")
        if space > 0 and raw[:space].isdigit() and space + 1 < len(raw) and raw[space + 1:space + 2] == b"<":
            msg = raw[space + 1:]

        try:
            text = msg.decode("utf-8", errors="replace")
        except Exception:
            text = repr(msg)
        print(f"[syslog] {text}", file=sys.stderr)

        if self._pcap is not None:
            self._pcap.write_syslog(msg)
