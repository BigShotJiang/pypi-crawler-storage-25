from __future__ import annotations

import array
import errno
import socket
import struct
import threading
from dataclasses import dataclass, field
from types import SimpleNamespace
from typing import Dict, Iterable, List, Optional, Tuple

import usb.backend
import usb.util
from usb.core import USBError

USBIP_VERSION = 0x0111
USBIP_TCP_PORT = 3240

USBIP_OP_REQ_IMPORT = 0x8003
USBIP_OP_REP_IMPORT = 0x0003
USBIP_OP_REQ_DEVLIST = 0x8005
USBIP_OP_REP_DEVLIST = 0x0005

USBIP_CMD_SUBMIT = 0x00000001
USBIP_CMD_UNLINK = 0x00000002
USBIP_RET_SUBMIT = 0x00000003
USBIP_RET_UNLINK = 0x00000004

USBIP_DIR_OUT = 0
USBIP_DIR_IN = 1
USBIP_NON_ISO_PACKETS = 0

_REQ_COMMON = struct.Struct("!HHI")
_DEV_DESC = struct.Struct("!256s32sIIIHHHBBBBBB")
_INTF_DESC = struct.Struct("!BBBB")
_SUBMIT_CMD = struct.Struct("!IIIII Iiiii8s")
_SUBMIT_RET = struct.Struct("!IIIII iIiiiQ")


@dataclass(frozen=True)
class _RemoteDeviceID:
    host: str
    port: int
    busid: str
    path: str
    busnum: int
    devnum: int
    speed: int
    id_vendor: int
    id_product: int
    bcd_device: int
    device_class: int
    device_subclass: int
    device_protocol: int
    configuration_value: int
    num_configurations: int
    num_interfaces: int
    interfaces: Tuple[Tuple[int, int, int], ...]

    @property
    def devid(self) -> int:
        return ((self.busnum & 0xFFFF) << 16) | (self.devnum & 0xFFFF)


@dataclass
class _AltSetting:
    desc: SimpleNamespace
    endpoints: List[SimpleNamespace] = field(default_factory=list)


@dataclass
class _ConfigData:
    config_desc: SimpleNamespace
    interfaces: List[List[_AltSetting]]


@dataclass
class _DescriptorCache:
    device_desc_raw: Optional[bytes] = None
    configs_raw: Dict[int, bytes] = field(default_factory=dict)
    parsed_configs: Dict[int, _ConfigData] = field(default_factory=dict)


class _UsbipConnection:
    # Extra time (ms) added to the user-requested timeout before applying
    # it to the TCP socket.  The USB/IP server has its own USB-level
    # timeout (typically 5 s on the ESP32 firmware).  The socket must
    # stay open long enough to receive the server's timeout response,
    # otherwise the connection desynchronises (the late response is
    # misinterpreted as the reply to a later request).
    _SERVER_TIMEOUT_MARGIN_MS = 2000

    def __init__(self, sock: socket.socket, dev: _RemoteDeviceID, default_timeout_ms: Optional[int] = None, pcap=None, backend: Optional["USBIPBackend"] = None):
        self.sock = sock
        self.dev = dev
        self._default_timeout_ms = default_timeout_ms
        self._seq = 1
        self._lock = threading.Lock()
        self._pcap = pcap
        self._backend = backend
        self._closed = False

    def close(self) -> None:
        self._closed = True
        try:
            self.sock.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        self.sock.close()

    def _reopen(self) -> None:
        """Re-establish the USB/IP import session after a broken connection."""
        if self._backend is None:
            raise USBError("Connection broken and cannot reconnect")
        new_conn = self._backend._import_device(self.dev)
        self.sock = new_conn.sock
        self._seq = 1
        self._closed = False

    def submit(
        self,
        *,
        direction: int,
        ep: int,
        setup: bytes,
        transfer_buffer_length: int,
        out_payload: bytes = b"",
        transfer_flags: int = 0,
        timeout_ms: Optional[int] = None,
    ) -> Tuple[int, bytes]:
        if len(setup) != 8:
            raise ValueError("setup must be 8 bytes")
        if transfer_buffer_length < 0:
            raise ValueError("transfer_buffer_length must be >= 0")
        if direction == USBIP_DIR_OUT and len(out_payload) != transfer_buffer_length:
            raise ValueError("OUT payload length must match transfer_buffer_length")
        if direction == USBIP_DIR_IN and out_payload:
            raise ValueError("IN transfers cannot have out_payload")

        with self._lock:
            if self._closed:
                self._reopen()

            if timeout_ms is None:
                timeout_ms = self._default_timeout_ms
            if timeout_ms is None:
                self.sock.settimeout(None)
            else:
                # Socket timeout must exceed the server-side USB transfer
                # timeout so that we always receive the server's response
                # (even if that response is a USB timeout error).
                socket_ms = timeout_ms + self._SERVER_TIMEOUT_MARGIN_MS
                self.sock.settimeout(socket_ms / 1000.0)

            try:
                seq = self._seq
                self._seq += 1

                cmd = _SUBMIT_CMD.pack(
                    USBIP_CMD_SUBMIT,
                    seq,
                    self.dev.devid,
                    direction,
                    ep,
                    transfer_flags,
                    transfer_buffer_length,
                    0,
                    USBIP_NON_ISO_PACKETS,
                    0,
                    setup,
                )
                self._sendall(cmd)
                if out_payload:
                    self._sendall(out_payload)

                if self._pcap is not None:
                    from .pcap import XFER_CONTROL, XFER_BULK
                    xfer_type = XFER_CONTROL if ep == 0 else XFER_BULK
                    is_in = direction == USBIP_DIR_IN
                    urb_id = self._pcap.write_submit(
                        transfer_type=xfer_type,
                        ep=ep,
                        direction_in=is_in,
                        devnum=self.dev.devnum,
                        busnum=self.dev.busnum,
                        setup=setup,
                        data=out_payload,
                        urb_len=transfer_buffer_length,
                    )

                ret_hdr = self._recv_exact(_SUBMIT_RET.size)
                (
                    command,
                    ret_seq,
                    ret_devid,
                    _ret_direction,
                    _ret_ep,
                    status,
                    actual_length,
                    _start_frame,
                    _num_packets,
                    _error_count,
                    _padding,
                ) = _SUBMIT_RET.unpack(ret_hdr)

                if command != USBIP_RET_SUBMIT:
                    raise USBError(f"Unexpected USB/IP reply command 0x{command:08x}")
                if ret_seq != seq:
                    raise USBError(f"USB/IP sequence mismatch (got {ret_seq}, expected {seq})")
                if ret_devid != 0 and ret_devid != self.dev.devid:
                    raise USBError("USB/IP device id mismatch in reply")

                data = b""
                if direction == USBIP_DIR_IN and actual_length > 0:
                    data = self._recv_exact(actual_length)

                if self._pcap is not None:
                    self._pcap.write_complete(
                        urb_id=urb_id,
                        transfer_type=xfer_type,
                        ep=ep,
                        direction_in=is_in,
                        devnum=self.dev.devnum,
                        busnum=self.dev.busnum,
                        status=status,
                        data=data,
                        urb_len=actual_length if data else 0,
                    )

                return status, data

            except Exception:
                # Any failure (network error, protocol mismatch) leaves
                # the connection in an unknown state.  Close the socket
                # so the next call will re-import on a fresh connection.
                self._closed = True
                try:
                    self.sock.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass
                try:
                    self.sock.close()
                except OSError:
                    pass
                raise

    def _sendall(self, data: bytes) -> None:
        try:
            self.sock.sendall(data)
        except OSError as exc:
            raise USBError(f"USB/IP send failed: {exc}") from exc

    def _recv_exact(self, size: int) -> bytes:
        out = bytearray()
        while len(out) < size:
            try:
                chunk = self.sock.recv(size - len(out))
            except socket.timeout as exc:
                raise USBError("USB/IP receive timeout", errno=errno.ETIMEDOUT) from exc
            except OSError as exc:
                raise USBError(f"USB/IP receive failed: {exc}") from exc
            if not chunk:
                raise USBError("USB/IP connection closed")
            out.extend(chunk)
        return bytes(out)


class USBIPBackend(usb.backend.IBackend):
    def __init__(self, host: str, port: int = USBIP_TCP_PORT, timeout: float = 2.0, pcap=None):
        self.host = host
        self.port = int(port)
        self.timeout = float(timeout)
        self._cache: Dict[Tuple[str, str], _DescriptorCache] = {}
        self._pcap = pcap
        self._conns: Dict[Tuple[str, str], _UsbipConnection] = {}
        self._devices: Optional[List[_RemoteDeviceID]] = None

    def enumerate_devices(self) -> Iterable[_RemoteDeviceID]:
        if self._devices is not None:
            return list(self._devices)
        sock = self._connect()
        try:
            self._send_op(sock, USBIP_OP_REQ_DEVLIST)
            version, code, status = self._recv_op(sock)
            if version != USBIP_VERSION or code != USBIP_OP_REP_DEVLIST:
                raise USBError("Invalid USB/IP DEVLIST reply")
            if status != 0:
                raise USBError(f"USB/IP DEVLIST failed with status {status}")

            count = struct.unpack("!I", self._recv_exact(sock, 4))[0]
            devices: List[_RemoteDeviceID] = []
            for _ in range(count):
                raw = self._recv_exact(sock, _DEV_DESC.size)
                (
                    path_raw,
                    busid_raw,
                    busnum,
                    devnum,
                    speed,
                    vid,
                    pid,
                    bcd_device,
                    dev_cls,
                    dev_sub,
                    dev_proto,
                    cfg_value,
                    num_cfg,
                    num_intf,
                ) = _DEV_DESC.unpack(raw)

                interfaces = []
                for _ in range(num_intf):
                    intf_cls, intf_sub, intf_proto, _pad = _INTF_DESC.unpack(self._recv_exact(sock, _INTF_DESC.size))
                    interfaces.append((intf_cls, intf_sub, intf_proto))

                dev = _RemoteDeviceID(
                    host=self.host,
                    port=self.port,
                    busid=_cstring(busid_raw),
                    path=_cstring(path_raw),
                    busnum=busnum,
                    devnum=devnum,
                    speed=speed,
                    id_vendor=vid,
                    id_product=pid,
                    bcd_device=bcd_device,
                    device_class=dev_cls,
                    device_subclass=dev_sub,
                    device_protocol=dev_proto,
                    configuration_value=cfg_value,
                    num_configurations=num_cfg,
                    num_interfaces=num_intf,
                    interfaces=tuple(interfaces),
                )
                self._cache.setdefault((dev.busid, dev.path), _DescriptorCache())
                devices.append(dev)
            self._devices = devices
            return list(devices)
        finally:
            sock.close()

    def get_parent(self, dev):
        return None

    def get_device_descriptor(self, dev):
        # USB/IP DEVLIST already includes key device identity fields.
        # Use them directly to allow PyUSB device discovery even when
        # control-transfer support is incomplete on the server side.
        return SimpleNamespace(
            bLength=18,
            bDescriptorType=0x01,
            bcdUSB=0x0200,
            bDeviceClass=dev.device_class,
            bDeviceSubClass=dev.device_subclass,
            bDeviceProtocol=dev.device_protocol,
            bMaxPacketSize0=64,
            idVendor=dev.id_vendor,
            idProduct=dev.id_product,
            bcdDevice=dev.bcd_device,
            iManufacturer=0,
            iProduct=0,
            iSerialNumber=0,
            bNumConfigurations=dev.num_configurations,
            bus=dev.busnum,
            address=dev.devnum,
            port_number=None,
            port_numbers=None,
            speed=dev.speed,
        )

    def get_configuration_descriptor(self, dev, config):
        cfg = self._get_config_data(dev, config)
        return cfg.config_desc

    def get_interface_descriptor(self, dev, intf, alt, config):
        cfg = self._get_config_data(dev, config)
        try:
            return cfg.interfaces[intf][alt].desc
        except IndexError as exc:
            raise USBError("Invalid interface index") from exc

    def get_endpoint_descriptor(self, dev, ep, intf, alt, config):
        cfg = self._get_config_data(dev, config)
        try:
            return cfg.interfaces[intf][alt].endpoints[ep]
        except IndexError as exc:
            raise USBError("Invalid endpoint index") from exc

    def _import_device(self, dev) -> _UsbipConnection:
        """Open a TCP connection, import the device, and return a connection."""
        sock = self._connect()
        try:
            self._send_op(sock, USBIP_OP_REQ_IMPORT)
            busid_bytes = dev.busid.encode("ascii", errors="ignore")[:31]
            busid_bytes += b"\0" * (32 - len(busid_bytes))
            sock.sendall(busid_bytes)

            version, code, status = self._recv_op(sock)
            if version != USBIP_VERSION or code != USBIP_OP_REP_IMPORT:
                raise USBError("Invalid USB/IP IMPORT reply")
            if status != 0:
                raise USBError(f"USB/IP import failed for {dev.busid}")

            # consume imported device description payload (device descriptor
            # only — the import reply does NOT include interface descriptors,
            # unlike the devlist reply)
            imported_raw = self._recv_exact(sock, _DEV_DESC.size)
            imported = _DEV_DESC.unpack(imported_raw)
            imported_busid = _cstring(imported[1])
            if imported_busid != dev.busid:
                raise USBError("USB/IP imported wrong device")

            return _UsbipConnection(sock, dev, default_timeout_ms=int(self.timeout * 1000), pcap=self._pcap, backend=self)
        except Exception:
            sock.close()
            raise

    def _get_conn(self, dev) -> _UsbipConnection:
        """Get or create a persistent connection for a device."""
        key = self._cache_key(dev)
        conn = self._conns.get(key)
        if conn is None:
            conn = self._import_device(dev)
            self._conns[key] = conn
        return conn

    def open_device(self, dev):
        return self._get_conn(dev)

    def close_device(self, dev_handle):
        # Persistent connections are shared across PyUSB Device objects
        # for the same physical device.  Don't close here — a Device
        # being garbage-collected must not tear down the connection for
        # other Device instances still using it.
        pass

    def set_configuration(self, dev_handle, config_value):
        setup = _setup_packet(0x00, 0x09, config_value, 0, 0)
        status, _ = dev_handle.submit(direction=USBIP_DIR_OUT, ep=0, setup=setup, transfer_buffer_length=0)
        _raise_if_error(status)

    def get_configuration(self, dev_handle):
        setup = _setup_packet(0x80, 0x08, 0, 0, 1)
        status, data = dev_handle.submit(direction=USBIP_DIR_IN, ep=0, setup=setup, transfer_buffer_length=1)
        _raise_if_error(status)
        if len(data) < 1:
            raise USBError("Short GET_CONFIGURATION response")
        return data[0]

    def set_interface_altsetting(self, dev_handle, intf, altsetting):
        setup = _setup_packet(0x01, 0x0B, altsetting, intf, 0)
        status, _ = dev_handle.submit(direction=USBIP_DIR_OUT, ep=0, setup=setup, transfer_buffer_length=0)
        _raise_if_error(status)

    def claim_interface(self, dev_handle, intf):
        return None

    def release_interface(self, dev_handle, intf):
        return None

    def bulk_write(self, dev_handle, ep, intf, data, timeout):
        payload = data.tobytes()
        status, _ = dev_handle.submit(
            direction=USBIP_DIR_OUT,
            ep=ep & 0x0F,
            setup=b"\0" * 8,
            transfer_buffer_length=len(payload),
            out_payload=payload,
            timeout_ms=timeout,
        )
        _raise_if_error(status)
        return len(payload)

    def bulk_read(self, dev_handle, ep, intf, buff, timeout):
        status, data = dev_handle.submit(
            direction=USBIP_DIR_IN,
            ep=ep & 0x0F,
            setup=b"\0" * 8,
            transfer_buffer_length=len(buff) * buff.itemsize,
            timeout_ms=timeout,
        )
        _raise_if_error(status)
        n = min(len(data), len(buff))
        buff[:n] = array.array('B', data[:n])
        return n

    def intr_write(self, dev_handle, ep, intf, data, timeout):
        return self.bulk_write(dev_handle, ep, intf, data, timeout)

    def intr_read(self, dev_handle, ep, intf, buff, timeout):
        return self.bulk_read(dev_handle, ep, intf, buff, timeout)

    def iso_write(self, dev_handle, ep, intf, data, timeout):
        raise USBError("Isochronous transfers are not implemented")

    def iso_read(self, dev_handle, ep, intf, buff, timeout):
        raise USBError("Isochronous transfers are not implemented")

    def ctrl_transfer(self, dev_handle, bmRequestType, bRequest, wValue, wIndex, data, timeout):
        direction = USBIP_DIR_IN if (bmRequestType & 0x80) else USBIP_DIR_OUT
        data_nbytes = len(data) * data.itemsize
        setup = _setup_packet(bmRequestType, bRequest, wValue, wIndex, data_nbytes)
        payload = b"" if direction == USBIP_DIR_IN else data.tobytes()
        ep = 0

        status, in_data = dev_handle.submit(
            direction=direction,
            ep=ep,
            setup=setup,
            transfer_buffer_length=data_nbytes,
            out_payload=payload,
            timeout_ms=timeout,
        )
        _raise_if_error(status)

        if direction == USBIP_DIR_OUT:
            return len(payload)

        n = min(len(in_data), len(data))
        data[:n] = array.array('B', in_data[:n])
        return n

    def clear_halt(self, dev_handle, ep):
        setup = _setup_packet(0x02, 0x01, 0, ep, 0)
        status, _ = dev_handle.submit(direction=USBIP_DIR_OUT, ep=0, setup=setup, transfer_buffer_length=0)
        _raise_if_error(status)

    def reset_device(self, dev_handle):
        raise USBError("Device reset is not implemented")

    def is_kernel_driver_active(self, dev_handle, intf):
        return False

    def detach_kernel_driver(self, dev_handle, intf):
        return None

    def attach_kernel_driver(self, dev_handle, intf):
        return None

    def _connect(self) -> socket.socket:
        try:
            sock = socket.create_connection((self.host, self.port), timeout=self.timeout)
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            return sock
        except OSError as exc:
            raise USBError(f"Unable to connect to USB/IP server {self.host}:{self.port}: {exc}") from exc

    def _send_op(self, sock: socket.socket, code: int) -> None:
        sock.sendall(_REQ_COMMON.pack(USBIP_VERSION, code, 0))

    def _recv_op(self, sock: socket.socket) -> Tuple[int, int, int]:
        version, code, status = _REQ_COMMON.unpack(self._recv_exact(sock, _REQ_COMMON.size))
        return version, code, status

    def _recv_exact(self, sock: socket.socket, size: int) -> bytes:
        out = bytearray()
        while len(out) < size:
            chunk = sock.recv(size - len(out))
            if not chunk:
                raise USBError("USB/IP connection closed")
            out.extend(chunk)
        return bytes(out)

    def _cache_key(self, dev: _RemoteDeviceID) -> Tuple[str, str]:
        return (dev.busid, dev.path)

    def _get_device_descriptor_raw(self, dev: _RemoteDeviceID) -> bytes:
        cache = self._cache.setdefault(self._cache_key(dev), _DescriptorCache())
        if cache.device_desc_raw is None:
            cache.device_desc_raw = self._fetch_descriptor(dev, dtype=0x01, dindex=0, length=18)
        return cache.device_desc_raw

    def _get_config_raw(self, dev: _RemoteDeviceID, config_index: int) -> bytes:
        cache = self._cache.setdefault(self._cache_key(dev), _DescriptorCache())
        if config_index in cache.configs_raw:
            return cache.configs_raw[config_index]

        header = self._fetch_descriptor(dev, dtype=0x02, dindex=config_index, length=9)
        if len(header) < 9:
            raise USBError("Short configuration descriptor header")
        total_length = struct.unpack_from("<H", header, 2)[0]
        raw = self._fetch_descriptor(dev, dtype=0x02, dindex=config_index, length=total_length)
        cache.configs_raw[config_index] = raw
        return raw

    def _get_config_data(self, dev: _RemoteDeviceID, config_index: int) -> _ConfigData:
        cache = self._cache.setdefault(self._cache_key(dev), _DescriptorCache())
        if config_index not in cache.parsed_configs:
            raw = self._get_config_raw(dev, config_index)
            cache.parsed_configs[config_index] = _parse_config_descriptor(raw)
        return cache.parsed_configs[config_index]

    def _fetch_descriptor(self, dev: _RemoteDeviceID, *, dtype: int, dindex: int, length: int) -> bytes:
        conn = self._get_conn(dev)
        wValue = ((dtype & 0xFF) << 8) | (dindex & 0xFF)
        setup = _setup_packet(0x80, 0x06, wValue, 0, length)
        status, data = conn.submit(
            direction=USBIP_DIR_IN,
            ep=0,
            setup=setup,
            transfer_buffer_length=length,
            timeout_ms=int(self.timeout * 1000),
        )
        _raise_if_error(status)
        return data


def _parse_config_descriptor(raw: bytes) -> _ConfigData:
    if len(raw) < 9:
        raise USBError("Configuration descriptor too short")

    (
        bLength,
        bDescriptorType,
        wTotalLength,
        bNumInterfaces,
        bConfigurationValue,
        iConfiguration,
        bmAttributes,
        bMaxPower,
    ) = struct.unpack_from("<BBHBBBBB", raw, 0)

    config_desc = SimpleNamespace(
        bLength=bLength,
        bDescriptorType=bDescriptorType,
        wTotalLength=wTotalLength,
        bNumInterfaces=bNumInterfaces,
        bConfigurationValue=bConfigurationValue,
        iConfiguration=iConfiguration,
        bmAttributes=bmAttributes,
        bMaxPower=bMaxPower,
        extra_descriptors=b"",
    )

    interfaces: List[List[_AltSetting]] = []
    intf_map: Dict[int, int] = {}
    current_alt: Optional[_AltSetting] = None

    off = 9
    while off + 2 <= len(raw):
        dlen = raw[off]
        dtype = raw[off + 1]
        if dlen < 2 or off + dlen > len(raw):
            break
        chunk = raw[off : off + dlen]

        if dtype == 0x04 and dlen >= 9:
            (
                _len,
                _dtype,
                bInterfaceNumber,
                bAlternateSetting,
                bNumEndpoints,
                bInterfaceClass,
                bInterfaceSubClass,
                bInterfaceProtocol,
                iInterface,
            ) = struct.unpack("<BBBBBBBBB", chunk[:9])

            intf_desc = SimpleNamespace(
                bLength=dlen,
                bDescriptorType=0x04,
                bInterfaceNumber=bInterfaceNumber,
                bAlternateSetting=bAlternateSetting,
                bNumEndpoints=bNumEndpoints,
                bInterfaceClass=bInterfaceClass,
                bInterfaceSubClass=bInterfaceSubClass,
                bInterfaceProtocol=bInterfaceProtocol,
                iInterface=iInterface,
                extra_descriptors=b"",
            )

            logical_intf = intf_map.get(bInterfaceNumber)
            if logical_intf is None:
                logical_intf = len(interfaces)
                intf_map[bInterfaceNumber] = logical_intf
                interfaces.append([])
            current_alt = _AltSetting(desc=intf_desc)
            interfaces[logical_intf].append(current_alt)

        elif dtype == 0x05 and dlen >= 7 and current_alt is not None:
            (
                _len,
                _dtype,
                bEndpointAddress,
                bmAttributes,
                wMaxPacketSize,
                bInterval,
            ) = struct.unpack("<BBBBHB", chunk[:7])

            bRefresh = chunk[7] if dlen >= 8 else 0
            bSynchAddress = chunk[8] if dlen >= 9 else 0
            ep_desc = SimpleNamespace(
                bLength=dlen,
                bDescriptorType=0x05,
                bEndpointAddress=bEndpointAddress,
                bmAttributes=bmAttributes,
                wMaxPacketSize=wMaxPacketSize,
                bInterval=bInterval,
                bRefresh=bRefresh,
                bSynchAddress=bSynchAddress,
                extra_descriptors=b"",
            )
            current_alt.endpoints.append(ep_desc)

        off += dlen

    return _ConfigData(config_desc=config_desc, interfaces=interfaces)


def _setup_packet(bmRequestType: int, bRequest: int, wValue: int, wIndex: int, wLength: int) -> bytes:
    return struct.pack("<BBHHH", bmRequestType & 0xFF, bRequest & 0xFF, wValue & 0xFFFF, wIndex & 0xFFFF, wLength & 0xFFFF)


def _cstring(raw: bytes) -> str:
    return raw.split(b"\0", 1)[0].decode("utf-8", errors="replace")


def _raise_if_error(status: int) -> None:
    if status == 0:
        return
    err = -status if status < 0 else status
    raise USBError(f"USB/IP transfer failed with status {status}", errno=err)


def get_backend(host: str, port: int = USBIP_TCP_PORT, timeout: float = 2.0, pcap=None) -> USBIPBackend:
    return USBIPBackend(host=host, port=port, timeout=timeout, pcap=pcap)
