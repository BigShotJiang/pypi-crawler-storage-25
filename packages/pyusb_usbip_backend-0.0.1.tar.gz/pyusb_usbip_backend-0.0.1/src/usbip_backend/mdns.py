from __future__ import annotations

import threading
import time
from typing import Dict, List

from zeroconf import ServiceBrowser, ServiceListener, Zeroconf


USBIP_MDNS_SERVICE = "_usbip._tcp.local."


class _UsbipListener(ServiceListener):
    def __init__(self, zc: Zeroconf):
        self._zc = zc
        self._lock = threading.Lock()
        self._services: Dict[str, Dict[str, object]] = {}

    def add_service(self, zc: Zeroconf, service_type: str, name: str) -> None:
        self._update(service_type, name)

    def update_service(self, zc: Zeroconf, service_type: str, name: str) -> None:
        self._update(service_type, name)

    def remove_service(self, zc: Zeroconf, service_type: str, name: str) -> None:
        with self._lock:
            self._services.pop(name, None)

    def snapshot(self) -> List[Dict[str, object]]:
        with self._lock:
            return list(self._services.values())

    def _update(self, service_type: str, name: str) -> None:
        info = self._zc.get_service_info(service_type, name, timeout=1500)
        if info is None:
            return

        txt: Dict[str, str] = {}
        for k, v in info.properties.items():
            key = k.decode("utf-8", errors="replace") if isinstance(k, bytes) else str(k)
            if isinstance(v, bytes):
                value = v.decode("utf-8", errors="replace")
            else:
                value = "" if v is None else str(v)
            txt[key] = value

        addresses = info.parsed_addresses()
        service_name = name.removesuffix(service_type)
        if service_name.endswith("."):
            service_name = service_name[:-1]

        service = {
            "name": service_name,
            "host": (info.server or "").rstrip("."),
            "address": addresses[0] if addresses else "",
            "addresses": addresses,
            "port": int(info.port),
            "txt": txt,
            "type": service_type,
        }

        with self._lock:
            self._services[name] = service


def discover_usbip_servers(timeout: float = 3.0) -> List[Dict[str, object]]:
    """Discover USB/IP servers advertised via mDNS/DNS-SD."""

    zc = Zeroconf()
    listener = _UsbipListener(zc)
    browser = ServiceBrowser(zc, USBIP_MDNS_SERVICE, listener)
    try:
        time.sleep(max(0.1, timeout))
        services = listener.snapshot()
        services.sort(key=lambda s: (str(s.get("host", "")), int(s.get("port", 0)), str(s.get("name", ""))))
        return services
    finally:
        browser.cancel()
        zc.close()
