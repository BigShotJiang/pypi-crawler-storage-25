"""Integration tests for the pyusb-usbip-backend.

Connects to a real USB/IP server and runs tests appropriate for the
detected hardware.  Two modes are supported for easy comparison:

    # Our Python USB/IP backend (pcap captures USB URBs)
    python test_integration.py 192.168.1.94 --pcap direct.pcapng --syslog

    # Kernel native usbip client (pcap captures TCP wire traffic)
    python test_integration.py 192.168.1.94 --native --pcap kernel.pcapng --syslog
"""

import argparse
import shutil
import signal
import subprocess
import sys
import time

import usb.core
import usb.util

from usbip_backend.backend import get_backend
from usbip_backend.pcap import PcapWriter
from usbip_backend.syslog import SyslogReceiver

DEFAULT_HOST = "192.168.1.216"

# --------------------------------------------------------------------------
# SiLabs CP210x driver (separate from the pyusb backend layer)
# --------------------------------------------------------------------------

class CP210xDriver:
    """Minimal CP210x USB-to-UART driver using PyUSB control transfers."""

    # CP210x vendor-specific requests
    SET_BAUDRATE = 0x1E
    SET_LINE_CTL = 0x03
    SET_MHS = 0x07  # modem handshake (DTR/RTS)
    SET_FLOW = 0x13
    GET_MDMSTS = 0x08
    IFC_ENABLE = 0x00

    # Line control defaults: 8N1
    BITS_DATA_8 = 0x0800
    BITS_PARITY_NONE = 0x0000
    BITS_STOP_1 = 0x0000

    def __init__(self, dev: usb.core.Device):
        self.dev = dev
        self._intf = 0

    def enable(self) -> None:
        """Enable the UART interface."""
        self.dev.ctrl_transfer(0x41, self.IFC_ENABLE, 0x0001, self._intf, timeout=1000)

    def disable(self) -> None:
        """Disable the UART interface."""
        self.dev.ctrl_transfer(0x41, self.IFC_ENABLE, 0x0000, self._intf, timeout=1000)

    def set_baudrate(self, baud: int) -> None:
        """Set the baud rate."""
        payload = baud.to_bytes(4, "little")
        self.dev.ctrl_transfer(0x41, self.SET_BAUDRATE, 0, self._intf, payload, timeout=1000)

    def set_line_ctl(self, data_bits=BITS_DATA_8, parity=BITS_PARITY_NONE, stop=BITS_STOP_1) -> None:
        """Set data bits, parity, stop bits."""
        value = data_bits | parity | stop
        self.dev.ctrl_transfer(0x41, self.SET_LINE_CTL, value, self._intf, timeout=1000)

    def configure(self, baud: int = 9600) -> None:
        """Enable and configure the UART with sensible defaults (8N1)."""
        self.enable()
        self.set_baudrate(baud)
        self.set_line_ctl()

    def write(self, data: bytes, timeout: int = 1000) -> int:
        """Write data to the bulk OUT endpoint."""
        ep_out = self._find_ep(usb.util.ENDPOINT_OUT)
        return self.dev.write(ep_out, data, timeout=timeout)

    def read(self, size: int, timeout: int = 1000) -> bytes:
        """Read data from the bulk IN endpoint."""
        ep_in = self._find_ep(usb.util.ENDPOINT_IN)
        return bytes(self.dev.read(ep_in, size, timeout=timeout))

    def _find_ep(self, direction: int) -> int:
        cfg = self.dev.get_active_configuration()
        intf = cfg[(self._intf, 0)]
        for ep in intf:
            if usb.util.endpoint_direction(ep.bEndpointAddress) == direction:
                return ep.bEndpointAddress
        raise usb.core.USBError(f"No {'IN' if direction else 'OUT'} endpoint found")


# --------------------------------------------------------------------------
# Test helpers
# --------------------------------------------------------------------------

def run_test(name, func, *args, **kwargs):
    print(f"[TEST] {name}")
    try:
        result = func(*args, **kwargs)
        print(f"[PASS] {name}\n")
        return True, result
    except Exception as e:
        print(f"[FAIL] {name}: {e}\n")
        return False, None


def find_device(backend, vid, pid):
    """Find a device, detaching the kernel driver and setting config if needed."""
    dev = usb.core.find(backend=backend, idVendor=vid, idProduct=pid)
    if dev is not None and backend is None:
        # Local device only: detach kernel driver and set configuration.
        # USBIP backend handles config implicitly per-connection.
        try:
            if dev.is_kernel_driver_active(0):
                dev.detach_kernel_driver(0)
                print("  (detached kernel driver)")
        except (usb.core.USBError, NotImplementedError):
            pass
        try:
            dev.set_configuration()
        except usb.core.USBError:
            pass
    return dev


# --------------------------------------------------------------------------
# Backend-level tests (work with any device)
# --------------------------------------------------------------------------

def test_enumerate(backend):
    """Test that we can enumerate devices (USB/IP only)."""
    devs = list(backend.enumerate_devices())
    assert devs, "No devices found on USB/IP server"
    print(f"  Found {len(devs)} device(s):")
    for d in devs:
        print(
            f"    busid={d.busid} vid:pid={d.id_vendor:04x}:{d.id_product:04x} "
            f"class={d.device_class:02x}/{d.device_subclass:02x}/{d.device_protocol:02x}"
        )
    return devs


def test_pyusb_find(backend, vid, pid):
    """Test that PyUSB can find a device through our backend."""
    dev = find_device(backend, vid, pid)
    assert dev is not None, f"PyUSB find failed for {vid:04x}:{pid:04x}"
    print(f"  PyUSB found device: vid={dev.idVendor:04x} pid={dev.idProduct:04x}")
    return dev


def test_device_descriptor(backend, vid, pid):
    """Test reading the device descriptor and config descriptor via control transfers."""
    dev = find_device(backend, vid, pid)
    assert dev is not None

    # Device descriptor
    raw = dev.ctrl_transfer(0x80, 0x06, 0x0100, 0, 18, timeout=1000)
    assert len(raw) == 18, f"Expected 18 bytes, got {len(raw)}"
    assert raw[1] == 0x01, "Not a device descriptor"
    print(f"  Device descriptor: {bytes(raw).hex()}")

    # Config descriptor header
    header = dev.ctrl_transfer(0x80, 0x06, 0x0200, 0, 9, timeout=1000)
    assert len(header) >= 9, f"Config header too short: {len(header)} bytes"
    total_len = header[2] | (header[3] << 8)
    full = dev.ctrl_transfer(0x80, 0x06, 0x0200, 0, total_len, timeout=1000)
    assert len(full) == total_len, f"Expected {total_len} bytes, got {len(full)}"
    print(f"  Config descriptor: {len(full)} bytes, {header[4]} interface(s)")

    # Don't close — keep the persistent USBIP connection alive


def test_configuration_iteration(backend, vid, pid):
    """Test iterating PyUSB configurations, interfaces, endpoints."""
    dev = find_device(backend, vid, pid)
    assert dev is not None

    for cfg in dev:
        print(f"  Configuration {cfg.bConfigurationValue}: {cfg.bNumInterfaces} interface(s)")
        for intf in cfg:
            print(
                f"    Interface {intf.bInterfaceNumber} alt {intf.bAlternateSetting}: "
                f"class={intf.bInterfaceClass:02x}/{intf.bInterfaceSubClass:02x}/{intf.bInterfaceProtocol:02x} "
                f"{intf.bNumEndpoints} endpoint(s)"
            )
            for ep in intf:
                dir_str = "IN" if usb.util.endpoint_direction(ep.bEndpointAddress) == usb.util.ENDPOINT_IN else "OUT"
                print(f"      EP 0x{ep.bEndpointAddress:02x} {dir_str} maxpacket={ep.wMaxPacketSize}")

    # Don't close — keep the persistent USBIP connection alive


# --------------------------------------------------------------------------
# CP210x-specific tests (require TX looped back to RX)
# --------------------------------------------------------------------------

def test_cp210x_loopback(backend, vid, pid):
    """Test CP210x UART loopback: write data, read it back."""
    dev = find_device(backend, vid, pid)
    assert dev is not None

    uart = CP210xDriver(dev)
    print("  Enabling UART...")
    uart.enable()
    print("  Setting baud rate...")
    uart.set_baudrate(115200)
    print("  Setting line control...")
    uart.set_line_ctl()
    print("  UART configured")

    test_data = b"Hello USB/IP loopback!\r\n"
    written = uart.write(test_data)
    assert written == len(test_data), f"Short write: {written}/{len(test_data)}"
    print(f"  Wrote {written} bytes")

    # Give the loopback a moment
    time.sleep(0.1)

    received = uart.read(len(test_data), timeout=2000)
    assert received == test_data, f"Loopback mismatch: sent {test_data!r}, got {received!r}"
    print(f"  Read back {len(received)} bytes: {received!r}")

    uart.disable()
    # Don't close — keep the persistent USBIP connection alive
    print("  Loopback OK")


# --------------------------------------------------------------------------
# CircuitPython CDC REPL tests
# --------------------------------------------------------------------------

def test_circuitpython_repl(backend, vid, pid):
    """Test CircuitPython REPL over CDC: send Ctrl-C, then evaluate an expression."""
    dev = find_device(backend, vid, pid)
    assert dev is not None

    # CDC control interface is intf 0, data interface is intf 1
    # Data endpoints: OUT=0x02, IN=0x82
    CDC_INTF = 0
    ep_out = 0x02
    ep_in = 0x82

    # Assert DTR (bit 0) via SET_CONTROL_LINE_STATE on the CDC control interface
    # bmRequestType=0x21 (class, interface), bRequest=0x22, wValue=DTR|RTS, wIndex=intf
    dev.ctrl_transfer(0x21, 0x22, 0x03, CDC_INTF, timeout=1000)
    print("  Set DTR/RTS")

    # Send Ctrl-C twice to interrupt any running code and get to REPL
    dev.write(ep_out, b"\x03", timeout=1000)
    time.sleep(0.1)
    dev.write(ep_out, b"\x03", timeout=1000)
    print("  Sent Ctrl-C")
    time.sleep(1.0)

    # Drain any pending output (stop as soon as we see the REPL prompt
    # rather than reading until a USB transfer times out — a timed-out
    # IN transfer can leave the ESP USB host in a bad state).
    drained = b""
    for _ in range(50):
        try:
            chunk = bytes(dev.read(ep_in, 64, timeout=500))
            drained += chunk
            if b">>> " in drained:
                break
        except usb.core.USBError:
            break
    if drained:
        print(f"  Drained: {drained!r}")
    assert b">>> " in drained, "Did not reach REPL prompt after Ctrl-C"

    # Send a simple expression
    cmd = b"print('hello from usbip')\r\n"
    dev.write(ep_out, cmd, timeout=1000)
    print("  Sent print command")
    time.sleep(0.5)

    # Read response — stop once we see the next prompt
    response = b""
    for _ in range(50):
        try:
            chunk = bytes(dev.read(ep_in, 64, timeout=500))
            response += chunk
            if b">>> " in response:
                break
        except usb.core.USBError:
            break

    print(f"  Response: {response!r}")
    assert b"hello from usbip" in response, f"Expected 'hello from usbip' in response"

    # Don't close — keep the persistent USBIP connection alive
    print("  REPL OK")


# --------------------------------------------------------------------------
# Main
# --------------------------------------------------------------------------

# Known device profiles: (vid, pid) -> description and extra tests
KNOWN_DEVICES = {
    (0x10C4, 0xEA60): ("CP2102/CP2104 USB-to-UART", [test_cp210x_loopback]),
    (0x10C4, 0xEA70): ("CP2105 USB-to-UART", [test_cp210x_loopback]),
    (0x10C4, 0xEA80): ("CP2108 USB-to-UART", [test_cp210x_loopback]),
}


def is_circuitpython(dev):
    """Detect CircuitPython by checking for a 'CircuitPython' interface string."""
    try:
        for cfg in dev:
            for intf in cfg:
                if intf.iInterface:
                    name = usb.util.get_string(dev, intf.iInterface)
                    if name and "CircuitPython" in name:
                        return True
    except (usb.core.USBError, ValueError):
        pass
    return False


def run_device_tests(backend, vid, pid, passed, failed):
    """Run the standard test suite for a single device."""
    label = f"{vid:04x}:{pid:04x}"

    tests = [
        (f"pyusb_find({label})", test_pyusb_find, [backend, vid, pid]),
        (f"device_descriptor({label})", test_device_descriptor, [backend, vid, pid]),
        (f"configuration_iteration({label})", test_configuration_iteration, [backend, vid, pid]),
    ]
    for name, func, args in tests:
        ok, _ = run_test(name, func, *args)
        if ok:
            passed += 1
        else:
            failed += 1

    # Device-specific tests — check descriptors first, then fall back to VID/PID
    known = KNOWN_DEVICES.get((vid, pid))
    if known:
        desc, extra_tests = known
        print(f"Detected: {desc}")
        for t in extra_tests:
            ok, _ = run_test(f"{t.__name__}({label})", t, backend, vid, pid)
            if ok:
                passed += 1
            else:
                failed += 1
    else:
        # Try descriptor-based detection
        dev = find_device(backend, vid, pid)
        if dev is not None and is_circuitpython(dev):
            print(f"Detected: CircuitPython (via product string descriptor)")
            for t in [test_circuitpython_repl]:
                ok, _ = run_test(f"{t.__name__}({label})", t, backend, vid, pid)
                if ok:
                    passed += 1
                else:
                    failed += 1
        else:
            print(f"No device-specific tests for {label}")

    return passed, failed


# --------------------------------------------------------------------------
# Native usbip helpers
# --------------------------------------------------------------------------

def usbip_list_remote(host):
    """List remote devices via 'usbip list -r'."""
    result = subprocess.run(
        ["sudo", "usbip", "list", "-r", host],
        capture_output=True, text=True, timeout=10,
    )
    if result.returncode != 0:
        raise RuntimeError(f"usbip list failed:\n{result.stderr}")

    devices = []
    for line in result.stdout.splitlines():
        line = line.strip()
        # Lines like: "1-2: Silicon Labs : CP210x UART Bridge (10c4:ea60)"
        if ":" in line and "(" in line:
            busid = line.split(":")[0].strip()
            # Extract vid:pid from parentheses
            paren = line[line.rfind("(") + 1:line.rfind(")")]
            if ":" in paren:
                vid_s, pid_s = paren.split(":")
                devices.append({
                    "busid": busid,
                    "vid": int(vid_s, 16),
                    "pid": int(pid_s, 16),
                    "desc": line,
                })
    return devices


def usbip_attach(host, busid):
    """Attach a remote device via kernel usbip. Returns the local port number."""
    result = subprocess.run(
        ["sudo", "usbip", "attach", "-r", host, "-b", busid],
        capture_output=True, text=True, timeout=10,
    )
    if result.returncode != 0:
        raise RuntimeError(f"usbip attach failed:\n{result.stderr}")

    # Wait for the device to appear
    time.sleep(1)

    # Find the port number from 'usbip port'
    result = subprocess.run(
        ["sudo", "usbip", "port"],
        capture_output=True, text=True, timeout=10,
    )
    # Lines like: "Port 00: <Port in Use> at Full Speed(12Mbps)"
    for line in result.stdout.splitlines():
        if "Port" in line and "in Use" in line:
            port = line.split(":")[0].strip().split()[-1]
            return port
    raise RuntimeError(f"Could not find attached port:\n{result.stdout}")


def usbip_detach(port):
    """Detach a kernel usbip device by port number."""
    subprocess.run(
        ["sudo", "usbip", "detach", "-p", port],
        capture_output=True, text=True, timeout=10,
    )


def start_tcpdump(host, pcap_path):
    """Start tcpdump capturing USBIP TCP traffic."""
    tcpdump = shutil.which("tcpdump")
    if tcpdump is None:
        raise RuntimeError("tcpdump not found")
    proc = subprocess.Popen(
        ["sudo", tcpdump, "-i", "any", "-w", pcap_path,
         "host", host, "and", "port", "3240"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
    )
    # Wait for tcpdump to start capturing
    time.sleep(0.5)
    if proc.poll() is not None:
        stderr = proc.stderr.read().decode(errors="replace")
        raise RuntimeError(f"tcpdump failed:\n{stderr}")
    return proc


def stop_tcpdump(proc):
    """Stop a tcpdump subprocess."""
    proc.send_signal(signal.SIGINT)
    proc.wait(timeout=5)
    stderr = proc.stderr.read().decode(errors="replace")
    if stderr:
        print(stderr, file=sys.stderr, end="")


# --------------------------------------------------------------------------
# Main
# --------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Integration tests for pyusb-usbip-backend")
    parser.add_argument("host", nargs="?", default=DEFAULT_HOST, help="USB/IP server host")
    parser.add_argument("--native", action="store_true",
                        help="Use kernel native usbip client instead of Python backend "
                             "(captures TCP wire traffic with tcpdump instead of USB URBs)")
    parser.add_argument("--pcap", metavar="PATH",
                        help="Capture to pcapng file (USB URBs in direct mode, "
                             "TCP traffic in --native mode)")
    parser.add_argument("--syslog", action="store_true",
                        help="Connect to ESP syslog and print log messages")
    parser.add_argument("--syslog-port", type=int, default=1514,
                        help="TCP port for syslog (default: 1514)")
    args = parser.parse_args()

    host = args.host
    passed = 0
    failed = 0

    # Syslog works in both modes
    syslog_receiver = None

    if args.native:
        # ---- Kernel native usbip mode ----
        print(f"USB/IP server: {host} (kernel native usbip)\n")

        # Start tcpdump early so it captures everything including the attach
        tcpdump_proc = None
        if args.pcap:
            print(f"Starting tcpdump -> {args.pcap}")
            tcpdump_proc = start_tcpdump(host, args.pcap)

        # List remote devices
        print("Listing remote devices...")
        remote_devs = usbip_list_remote(host)
        if not remote_devs:
            raise SystemExit("No remote devices found")
        for d in remote_devs:
            print(f"  {d['desc']}")
        print()

        # Start syslog (no pcap — syslog goes to our PcapWriter which isn't
        # used in native mode; just print to stderr)
        if args.syslog:
            syslog_receiver = SyslogReceiver(host, port=args.syslog_port)
            syslog_receiver.start()

        # Attach first remote device
        dev_info = remote_devs[0]
        busid = dev_info["busid"]
        vid, pid = dev_info["vid"], dev_info["pid"]
        print(f"Attaching {busid} ({vid:04x}:{pid:04x})...")
        port = usbip_attach(host, busid)
        print(f"Attached on port {port}\n")

        try:
            # backend=None means use default libusb
            passed, failed = run_device_tests(None, vid, pid, passed, failed)
        finally:
            print(f"\nDetaching port {port}...")
            usbip_detach(port)

            if tcpdump_proc is not None:
                stop_tcpdump(tcpdump_proc)
                print(f"TCP capture saved to {args.pcap}")

            if syslog_receiver is not None:
                syslog_receiver.stop()
    else:
        # ---- Python USB/IP backend mode ----
        print(f"USB/IP server: {host} (Python backend)\n")

        pcap = None
        if args.pcap:
            pcap = PcapWriter(open(args.pcap, "wb"))

        if args.syslog:
            syslog_receiver = SyslogReceiver(host, port=args.syslog_port, pcap=pcap)
            syslog_receiver.start()

        backend = get_backend(host, pcap=pcap)

        # Enumerate
        ok, devs = run_test("enumerate", test_enumerate, backend)
        if not ok:
            print("Cannot continue without enumeration")
            if syslog_receiver is not None:
                syslog_receiver.stop()
            return 1
        passed += 1

        # Run per-device tests
        tested_devices = set()
        for dev_info in devs:
            vid, pid = dev_info.id_vendor, dev_info.id_product
            if (vid, pid) in tested_devices:
                continue
            tested_devices.add((vid, pid))
            passed, failed = run_device_tests(backend, vid, pid, passed, failed)

        if syslog_receiver is not None:
            syslog_receiver.stop()

    print(f"\nResults: {passed} passed, {failed} failed")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
