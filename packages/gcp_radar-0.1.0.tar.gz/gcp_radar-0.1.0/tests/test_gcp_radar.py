"""
Basic unit tests for gcp-radar.

Run:
    pytest
"""

import pytest
import csv
import io


# ── inventory helpers ──

def test_row_helper():
    from gcp_radar.inventory import row
    r = row("my-project", "Compute Engine", "web-01", "i-abc", "n1-standard-2", "running", "us-central1", "1.2.3.4")
    assert r["ProjectID"] == "my-project"
    assert r["Service"] == "Compute Engine"
    assert r["Status"] == "running"


def test_get_label_found():
    from gcp_radar.inventory import get_label
    resource = type('obj', (object,), {'name': 'my-instance'})()
    assert get_label(resource, 'name') == 'my-instance'


def test_get_label_missing():
    from gcp_radar.inventory import get_label
    assert get_label(None) == "-"
    resource = type('obj', (object,), {})()
    assert get_label(resource, 'nonexistent') == "-"


# ── drawio generation ──

def test_build_drawio_returns_xml():
    from gcp_radar.drawio import build_drawio
    import xml.etree.ElementTree as ET

    sample = [
        {"ProjectID": "my-project", "Service": "Compute Engine", "Name": "web-01",
         "ID": "i-abc", "Type/Size": "n1-standard-2", "Status": "running",
         "Region": "us-central1", "Extra": "1.2.3.4"},
        {"ProjectID": "my-project", "Service": "Cloud SQL", "Name": "prod-db",
         "ID": "prod-db", "Type/Size": "db-f1-micro", "Status": "RUNNABLE",
         "Region": "us-central1", "Extra": "MySQL 8.0"},
        {"ProjectID": "my-project", "Service": "Cloud Storage", "Name": "my-bucket",
         "ID": "my-bucket", "Type/Size": "-", "Status": "active",
         "Region": "us-central1", "Extra": "Created: 2022-01-01"},
    ]

    mxfile = build_drawio(sample, project_id="my-project")
    assert mxfile.tag == "mxfile"


def test_build_drawio_empty():
    from gcp_radar.drawio import build_drawio
    mxfile = build_drawio([], project_id="my-project")
    assert mxfile.tag == "mxfile"


# ── CSV columns ──

def test_csv_columns():
    from gcp_radar.inventory import COLS
    expected = {"ProjectID", "Service", "Name", "ID", "Type/Size", "Status", "Region", "Extra"}
    assert expected == set(COLS)


def test_export_csv(tmp_path):
    from gcp_radar.inventory import COLS
    import csv
    
    rows = [
        {c: f"val_{c}" for c in COLS},
        {c: f"val2_{c}" for c in COLS},
    ]
    out = tmp_path / "test.csv"
    
    with open(out, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=COLS)
        writer.writeheader()
        writer.writerows(rows)
    
    with open(out) as f:
        reader = csv.DictReader(f)
        read_rows = list(reader)
    
    assert len(read_rows) == 2
    assert read_rows[0]["Service"] == "val_Service"
