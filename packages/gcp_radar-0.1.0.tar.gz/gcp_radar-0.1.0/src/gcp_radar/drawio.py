#!/usr/bin/env python3
"""
GCP Inventory → draw.io Diagram Generator

Reads the CSV produced by gcp_inventory.py and generates a .drawio file
that you can open directly in draw.io (app.diagrams.net) or the desktop app.

Usage:
    # First generate inventory:
    python gcp_inventory.py --all-projects --export inventory.csv

    # Then generate diagram:
    python gcp_to_drawio.py --input inventory.csv --output architecture.drawio

    # Open architecture.drawio in draw.io / diagrams.net
"""

import csv
import argparse
import sys
import xml.etree.ElementTree as ET
from collections import defaultdict
from xml.dom import minidom

# ─────────────────────────────────────────────
# draw.io shape mapping per GCP service
# Uses official GCP icon library
# ─────────────────────────────────────────────

SERVICE_STYLES = {
    "Compute Engine":        "outlineConnect=0;fontColor=#1f2937;gradientColor=none;strokeColor=none;fillColor=#4285F4;labelBackgroundColor=#ffffff;align=center;html=1;fontSize=12;fontStyle=0;aspect=fixed;shape=mxgraph.gcp.resourceIcon;resIcon=mxgraph.gcp.compute_engine;",
    "Cloud SQL":             "outlineConnect=0;fontColor=#1f2937;gradientColor=none;strokeColor=none;fillColor=#4285F4;labelBackgroundColor=#ffffff;align=center;html=1;fontSize=12;fontStyle=0;aspect=fixed;shape=mxgraph.gcp.resourceIcon;resIcon=mxgraph.gcp.sql;",
    "Cloud Functions":       "outlineConnect=0;fontColor=#1f2937;gradientColor=none;strokeColor=none;fillColor=#34A853;labelBackgroundColor=#ffffff;align=center;html=1;fontSize=12;fontStyle=0;aspect=fixed;shape=mxgraph.gcp.resourceIcon;resIcon=mxgraph.gcp.cloud_functions;",
    "GKE":                   "outlineConnect=0;fontColor=#1f2937;gradientColor=none;strokeColor=none;fillColor=#4285F4;labelBackgroundColor=#ffffff;align=center;html=1;fontSize=12;fontStyle=0;aspect=fixed;shape=mxgraph.gcp.resourceIcon;resIcon=mxgraph.gcp.kubernetes_engine;",
    "Cloud Storage":         "outlineConnect=0;fontColor=#1f2937;gradientColor=none;strokeColor=none;fillColor=#34A853;labelBackgroundColor=#ffffff;align=center;html=1;fontSize=12;fontStyle=0;aspect=fixed;shape=mxgraph.gcp.resourceIcon;resIcon=mxgraph.gcp.storage;",
    "Cloud Run":             "outlineConnect=0;fontColor=#1f2937;gradientColor=none;strokeColor=none;fillColor=#FF6D00;labelBackgroundColor=#ffffff;align=center;html=1;fontSize=12;fontStyle=0;aspect=fixed;shape=mxgraph.gcp.resourceIcon;resIcon=mxgraph.gcp.run;",
    "Firestore":             "outlineConnect=0;fontColor=#1f2937;gradientColor=none;strokeColor=none;fillColor=#FBBC04;labelBackgroundColor=#ffffff;align=center;html=1;fontSize=12;fontStyle=0;aspect=fixed;shape=mxgraph.gcp.resourceIcon;resIcon=mxgraph.gcp.firestore;",
    "Pub/Sub Topic":         "outlineConnect=0;fontColor=#1f2937;gradientColor=none;strokeColor=none;fillColor=#4285F4;labelBackgroundColor=#ffffff;align=center;html=1;fontSize=12;fontStyle=0;aspect=fixed;shape=mxgraph.gcp.resourceIcon;resIcon=mxgraph.gcp.pubsub;",
    "Pub/Sub Subscription":  "outlineConnect=0;fontColor=#1f2937;gradientColor=none;strokeColor=none;fillColor=#4285F4;labelBackgroundColor=#ffffff;align=center;html=1;fontSize=12;fontStyle=0;aspect=fixed;shape=mxgraph.gcp.resourceIcon;resIcon=mxgraph.gcp.pubsub;",
    "Vertex AI Model":       "outlineConnect=0;fontColor=#1f2937;gradientColor=none;strokeColor=none;fillColor=#9c27b0;labelBackgroundColor=#ffffff;align=center;html=1;fontSize=12;fontStyle=0;aspect=fixed;shape=mxgraph.gcp.resourceIcon;resIcon=mxgraph.gcp.ml_engine;",
    "Vertex AI Endpoint":    "outlineConnect=0;fontColor=#1f2937;gradientColor=none;strokeColor=none;fillColor=#7b1fa2;labelBackgroundColor=#ffffff;align=center;html=1;fontSize=12;fontStyle=0;aspect=fixed;shape=mxgraph.gcp.resourceIcon;resIcon=mxgraph.gcp.endpoint;",
    "Vertex AI Featurestore":"outlineConnect=0;fontColor=#1f2937;gradientColor=none;strokeColor=none;fillColor=#6a1b9a;labelBackgroundColor=#ffffff;align=center;html=1;fontSize=12;fontStyle=0;aspect=fixed;shape=mxgraph.gcp.resourceIcon;resIcon=mxgraph.gcp.bigtable;",
}

# Service → category grouping for swim lanes
SERVICE_CATEGORY = {
    "Compute Engine": "Compute",
    "Cloud Functions": "Compute",
    "GKE": "Compute",
    "Cloud Run": "Compute",
    "Cloud SQL": "Database",
    "Firestore": "Database",
    "Cloud Storage": "Storage",
    "Pub/Sub Topic": "Messaging",
    "Pub/Sub Subscription": "Messaging",
    "Vertex AI Model": "AI",
    "Vertex AI Endpoint": "AI",
    "Vertex AI Featurestore": "AI",
}

CATEGORY_COLORS = {
    "Compute":   {"fill": "#dae8fc", "stroke": "#6c8ebf"},
    "Database":  {"fill": "#f8cecc", "stroke": "#b85450"},
    "Storage":   {"fill": "#d5e8d4", "stroke": "#82b366"},
    "Messaging": {"fill": "#fff2cc", "stroke": "#d6b656"},
    "AI":       {"fill": "#f3e5f5", "stroke": "#9c4dcc"},
}

# Logical connections: service A → service B (directional)
CONNECTIONS = [
    ("Cloud Run", "Cloud SQL"),
    ("Cloud Run", "Cloud Storage"),
    ("Cloud Run", "Firestore"),
    ("Cloud Run", "Pub/Sub Topic"),
    ("Compute Engine", "Cloud SQL"),
    ("Compute Engine", "Cloud Storage"),
    ("Compute Engine", "Pub/Sub Topic"),
    ("GKE", "Cloud SQL"),
    ("GKE", "Cloud Storage"),
    ("GKE", "Firestore"),
    ("Cloud Functions", "Firestore"),
    ("Cloud Functions", "Cloud Storage"),
    ("Cloud Functions", "Pub/Sub Topic"),
    ("Pub/Sub Topic", "Cloud Functions"),
    ("Pub/Sub Topic", "Pub/Sub Subscription"),
    # Vertex AI logical connections
    ("Vertex AI Model", "Vertex AI Endpoint"),
    ("Vertex AI Endpoint", "Cloud Storage"),
    ("Cloud Storage", "Vertex AI Model"),
    ("Cloud Run", "Vertex AI Endpoint"),
    ("Cloud Functions", "Vertex AI Endpoint"),
]

# ─────────────────────────────────────────────
# Layout constants
# ─────────────────────────────────────────────
ICON_W, ICON_H = 60, 60
LABEL_H        = 30
NODE_W         = 80
NODE_H         = ICON_H + LABEL_H
PAD_X, PAD_Y   = 30, 40
LANE_PAD       = 20
PROJECT_HEADER = 40
CAT_HEADER     = 30


def slugify(text):
    return text.replace(" ", "_").replace("/", "_").replace("-", "_").lower()


def read_csv(path):
    """Read inventory CSV."""
    rows = []
    with open(path) as f:
        reader = csv.DictReader(f)
        for row in reader:
            rows.append(row)
    return rows


def build_drawio(rows, project_id="default"):
    """
    Build a draw.io XML document from inventory rows.
    
    Organizes resources into swim lanes by:
    1. Project ID
    2. Service Category (Compute, Database, Storage, Messaging)
    3. Individual resources
    
    Adds logical connections between services.
    """
    mxfile = ET.Element("mxfile", host="app.diagrams.net", modified=str(ET.Element('mxfile')), version="20.0")
    diagram = ET.SubElement(mxfile, "diagram", name="GCP Architecture")
    mxGraphModel = ET.SubElement(diagram, "mxGraphModel", 
                                 dx="1200", dy="800", grid="1", gridSize="10",
                                 guides="1", tooltips="1", connect="1",
                                 arrows="1", fold="1", page="1", pageScale="1",
                                 pageWidth="1200", pageHeight="800", background="#ffffff",
                                 math="0", shadow="0")
    root = ET.SubElement(mxGraphModel, "root")
    
    # Add default cells
    ET.SubElement(root, "mxCell", id="0")
    ET.SubElement(root, "mxCell", id="1", parent="0")
    
    cell_id = 2
    y_offset = 20
    resource_cells = {}
    
    # Group by category
    by_category = defaultdict(list)
    for row in rows:
        service = row.get("Service", "Unknown")
        category = SERVICE_CATEGORY.get(service, "Other")
        by_category[category].append(row)
    
    # Draw category swim lanes
    for category, resources in by_category.items():
        if not resources:
            continue
        
        # Category header
        cat_height = max(NODE_H * len(resources) + PAD_Y * 2, CAT_HEADER + PAD_Y)
        style = f"rounded=0;whiteSpace=wrap;html=1;fillColor={CATEGORY_COLORS.get(category, {}).get('fill', '#ffffff')};strokeColor={CATEGORY_COLORS.get(category, {}).get('stroke', '#000000')};"
        
        ET.SubElement(root, "mxCell", id=str(cell_id), value=category, 
                     style=style, vertex="1", parent="1",
                     geometry=ET.Element("mxGeometry", x=str(20), y=str(y_offset), 
                                        width="1160", height=str(cat_height), relative="1"))
        cell_id += 1
        y_offset += cat_height + PAD_Y
        
        # Resources in category
        x_pos = 50
        for resource in resources:
            service = resource.get("Service", "Unknown")
            name = resource.get("Name", "Unknown")
            rid = resource.get("ID", "Unknown")[:20]
            
            # Resource node
            style = SERVICE_STYLES.get(service, "shape=ellipse;fillColor=#cccccc;")
            
            ET.SubElement(root, "mxCell", id=f"res_{cell_id}", 
                         value=f"{name}\n({service})",
                         style=style, vertex="1", parent="1",
                         geometry=ET.Element("mxGeometry", x=str(x_pos), y=str(y_offset - cat_height + 60),
                                            width=str(NODE_W), height=str(NODE_H), relative="1"))
            
            resource_cells[f"{service}_{rid}"] = cell_id
            cell_id += 1
            x_pos += NODE_W + PAD_X
    
    # Add connections
    for source_svc, target_svc in CONNECTIONS:
        for row in rows:
            if row.get("Service") == source_svc:
                key = f"{source_svc}_{row.get('ID', 'Unknown')[:20]}"
                src_val = resource_cells.get(key, '')
                source_id = f"res_{src_val}" if src_val != '' else ''
                for target_row in rows:
                    if target_row.get("Service") == target_svc:
                        tkey = f"{target_svc}_{target_row.get('ID', 'Unknown')[:20]}"
                        tgt_val = resource_cells.get(tkey, '')
                        target_id = f"res_{tgt_val}" if tgt_val != '' else ''
                        if source_id and target_id:
                            ET.SubElement(root, "mxCell", id=str(cell_id), style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;",
                                         edge="1", parent="1", source=source_id, target=target_id,
                                         geometry=ET.Element("mxGeometry", relative="1", as_="geometry"))
                            cell_id += 1
    
    return mxfile


def export_drawio(mxfile, output_path):
    """Export mxfile to .drawio XML."""
    xml_str = minidom.parseString(ET.tostring(mxfile)).toprettyxml(indent="  ")
    with open(output_path, "w") as f:
        f.write(xml_str)
    print(f"✓ Architecture diagram generated: {output_path}")


def main():
    parser = argparse.ArgumentParser(description="GCP Inventory to draw.io Diagram")
    parser.add_argument("--input", required=True, help="Input CSV file from gcp_inventory.py")
    parser.add_argument("--output", required=True, help="Output .drawio file")
    
    args = parser.parse_args()
    
    rows = read_csv(args.input)
    mxfile = build_drawio(rows)
    export_drawio(mxfile, args.output)


if __name__ == "__main__":
    main()
