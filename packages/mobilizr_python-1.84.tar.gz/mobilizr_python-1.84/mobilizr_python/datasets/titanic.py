import os
import pandas as pd

def load():
    """Load the titanic dataset."""
    path = os.path.join(os.path.dirname(__file__), '..', 'data', 'titanic.csv')
    df = pd.read_csv(path)
    return df

def describe():
    """Return a description of the titanic dataset."""
    return """
    Titanic Passenger Data
    Description
    A dataset Containing Information on 1,000 Randomly Sampled Passengers of the Titanic.

    Usage
    data(titanic)
    Format
    A data frame with 1,000 observations of 8 variables

    Details
    name. name of passenger
    age. age of passenger
    sex. sex of passenger
    fare. amount paid for ticket (in Pounds) to sail on the Titanic
    class. the class hospitality/room aboard the Titanic
    embarked. location passenger first stepped on board the Titanic
    survived. the survival status of the passenger
    titled. Does the person have a title other than Mr., Mrs., Miss., etc. in their name or not

    Source
    https://hbiostat.org/data/repo/titanic.html

    See Also
    titanic_test

    [Package mobilizr version 0.4.0 Index]
    """.strip()

