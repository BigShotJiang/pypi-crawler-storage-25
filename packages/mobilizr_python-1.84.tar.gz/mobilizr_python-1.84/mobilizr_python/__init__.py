from . import datasets
import pandas as pd
import numpy as np
import random

def data(name):
    """Load a dataset by name."""
    if hasattr(datasets, name):
        return getattr(datasets, name).load()
    else:
        raise ValueError(f"Dataset '{name}' not found in mobilizr_python.datasets")
    
    
def describe(name):
    """Get the description for a dataset by name."""
    if hasattr(datasets, name):
        return getattr(datasets, name).describe()
    else:
        raise ValueError(f"Dataset '{name}' not found in mobilizr_python.datasets")
    
def list_datasets():
    """Return a list of available dataset names."""
    return [name for name in dir(datasets) if not name.startswith("_")]

def View(name):
    """View a dataset by name."""
    if hasattr(datasets, name):
        df = getattr(datasets, name).load()
        if isinstance(df, pd.DataFrame):
            return df
        else:
            raise TypeError(f"Dataset '{name}' is not a pandas DataFrame.")
    else:
        raise ValueError(f"Dataset '{name}' not found in mobilizr_python.datasets")
    
def timeuse_format(df):
    df = df.replace("NOT_DISPLAYED", 0)
    df[df.columns.difference(['user.id', 'timestamp', 'activities'])] = \
        df[df.columns.difference(['user.id', 'timestamp', 'activities'])].apply(pd.to_numeric)

    submissions = df.groupby('user.id').size().rename("submissions")
    
    averages = df.groupby('user.id').mean(numeric_only = True)
    
    return averages.merge(submissions, on = "user.id")

def shuffle(x, seed = None):
    shuffled_x = x.sample(frac = 1, random_state = seed).reset_index(drop = True)
    return shuffled_x

def do_table_shuffle(n, index, y, df, seed = None):
    data = []
    # Anchor random seed for reproducibility
    rng = np.random.default_rng(seed)
    
    # Get names from temp table
    temp_table = pd.crosstab(df[index],
                             df[y],
                             normalize = "columns") * 100
    row_names = temp_table.index
    col_names = temp_table.columns
    
    new_names = [f"{r}.{c}" for c in col_names for r in row_names]
    
    for i in range(n):
        # Current seed for this iteration (using anchor seed)
        current_seed = rng.integers(0, 1000000)
        
        # Shuffle X
        index_shuffle = df[index].sample(frac = 1, random_state = current_seed).reset_index(drop = True)
        
        # Create a table with percentages 
        table = pd.crosstab(index_shuffle, df[y],
                normalize= "columns") * 100
        
        # Save the "inner cells" of the table in the ith observation of data
        data.append(table.values.flatten('F'))
        
    df = pd.DataFrame(data)
    df.columns = new_names
    return df
        
def do_median(n, index, y, df, seed = None):
    data = []
    rng = np.random.default_rng(seed)
    
    
    for i in range(n):
        current_seed = rng.integers(0, 100000)
        index_shuffle = df[index].sample(frac = 1, random_state = current_seed).reset_index(drop = True)
        
        temp = df.copy()
        temp[index] = index_shuffle
        medians = temp.groupby(index)[y].median()
        row = {f"median_{y}_{val}": medians[val] for val in medians.index}
        data.append(row)
        
    return pd.DataFrame(data)

def do_mean(n, index, y, df, seed = None):
    data = []
    rng = np.random.default_rng(seed)
    
    for i in range(n):
        current_seed = rng.integers(0, 100000)
        index_shuffle = df[index].sample(frac = 1, random_state = current_seed).reset_index(drop = True)
        
        temp = df.copy()
        temp[index] = index_shuffle
        means = temp.groupby(index)[y].mean()
        row = {f"mean_{y}_{val}": means[val] for val in means.index}
        data.append(row)
        
    return pd.DataFrame(data)

