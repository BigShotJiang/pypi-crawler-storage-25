
# -*- coding: utf-8 -*-
"""
逻辑回归逐步训练工具类 (Stepwise Training Module)
=============================================
版本信息：v1.0.0
作者: Faster Scoring Team XM
功能:
    1. 支持4种逻辑回归变量逐步筛选策略，输出系数/标准误差/p值/置信区间等统计指标
依赖:
    pandas >= 1.2.0, numpy >= 1.20.0, scipy >= 1.6.0, 
    scikit-learn >= 0.24.0, statsmodels >= 0.13.0, tqdm >= 4.60.0
"""


import time
import warnings
import numpy as np
import pandas as pd
import copy
import scipy.stats as sts
import statsmodels.api as sm
from typing import Dict, List, Tuple, Union, Optional, Any, Callable
from sklearn.linear_model import LogisticRegression
from sklearn.exceptions import NotFittedError
from fasterscoring.general_utils import *
import ipywidgets
if ipywidgets.__version__ > "7.8.5":
    from tqdm import tqdm
else:
    from tqdm.auto import tqdm

# 忽略非关键警告
warnings.filterwarnings('ignore')


def _timeit(func: Callable) -> Callable:
    """
    装饰器：统计函数/类方法执行耗时
    
    Parameters
    ----------
    func : Callable
        被装饰的方法/函数
    
    Returns
    -------
    Callable
        包装后的方法/函数
    """
    def wrapper(*args, **kwargs):
        # 提取类实例self（类方法第一个参数为self）
        self = args[0] if args and hasattr(args[0], '__class__') else None
        start_time = time.time()
        
        # 执行原方法/函数
        result = func(*args, **kwargs)
        
        # 计算耗时并处理日志/存储
        cost = time.time() - start_time
        if self:
            # 类实例方法：存储耗时到results，按verbose打印
            if not hasattr(self, 'results'):
                self.results = {'time_cost': {}}
            if 'time_cost' not in self.results:
                self.results['time_cost'] = {}
            
            self.results['time_cost'][func.__name__] = cost
            
            # 按实例的verbose配置打印
            if hasattr(self, 'verbose') and self.verbose:
                print(f"\n>>>>>>> [{func.__name__}] 执行耗时：{cost:6.4f}秒")
        else:
            # 普通函数：降级打印
            print(f"\n>>>>>>> 函数 [{func.__name__}] 执行耗时：{cost:6.4f}秒")
        
        return result
    return wrapper

class LogisticStepwiseTrain:
    """
    逻辑回归逐步变量筛选器
    支持2种筛选策略和2种模型方法：
    1. 支持通过系数阈值逐步筛选 (stepwise_by_coef_lr)
    2. 支持通过z检验p值逐步筛选 (stepwise_by_pvalue_lr)
    3. 支持statsmodels模型方法
    4. 支持sklearn模型方法

    Attributes
    ----------
    verbose : bool
        是否打印过程信息和结果
    results : Dict
        存储各方法执行耗时等结果
    model : Any
        最终训练好的模型（sklearn/statsmodels逻辑回归模型）
    model_type : str
        模型类型
    model_param: Dict[str, Any]
        最终训练好的模型
    version : str
        当前工具类版本号
    """
    
    def __init__(self, 
        x_cols_desc: Dict[str, str] = None, 
        verbose: bool = True):
        """
        初始化筛选器
        
        Parameters
        ----------
        x_cols_desc: Dict[str, str]
            自变量的说明信息，数据字典
        verbose : bool, default=True
            是否打印过程信息和耗时
        """
        self.verbose = verbose
        self.x_cols_desc = x_cols_desc if x_cols_desc is not None else {}
        self.results = {
             'time_cost': {},    # 各阶段耗时
             'removed_vars': {}, # 各阶段剔除的变量 dict {'vif': [], ...}
        }  # 结果存储
        self.model = None  # 最终训练好的模型
        self.model_type = None  # 最终训练好的模型
        self.model_param = None  # 最终训练好的模型

    
    def _print_filter_result(self, 
        filter_desc: str, 
        rest_cnt: int = None, 
        selected_cnt: int = None, 
        removed_cnt: int = None,
        total_cnt: int = None,
        ) -> None:
        """
        通用打印：筛选结果（移除/剩余变量数），并记录筛选历史
        
        Parameters
        ----------
        filter_desc : str
            筛选步骤名称（如"迭代-p值筛选"）
        rest_cnt: int = None, 
            余下的变量个数
        selected_cnt : int = None
            已选择的变量个数
        removed_cnt : int = None
            移除的变量个数
        total_cnt : int = None
            移除的变量个数  
        """
        if self.verbose:
            print(f'>>>>> [{filter_desc}] , 剩余变量: {rest_cnt:>4d}/{total_cnt}, 已选变量: {selected_cnt:^4d}, 移除变量: {removed_cnt:^4d} ', end = '\r')
    
    
    def _calc_coef_std_err(self, 
        model: Any, 
        df: pd.DataFrame, 
        cols: List[str], 
        model_type: str = 'sklearn'
        ) -> np.ndarray:
        """
        计算回归系数标准误差
        
        Parameters
        ----------
        model : Any
            训练好的模型（sklearn/statsmodels逻辑回归模型）
        df : pd.DataFrame
            训练数据集（含WOE转换后的变量）
        cols : List[str]
            自变量列名列表
        model_type : str, default='sklearn'
            模型类型：'sklearn'/'statsmodel'
        
        Returns
        -------
        np.ndarray
            系数标准误差数组（含截距项）
        
        Raises
        ------
        ValueError
            传入不支持的模型类型时抛出
        """

        # 构建自变量矩阵（添加常数项）
        X_train = df[cols].astype(float).values
        X_design = np.hstack([np.ones((X_train.shape[0], 1)), X_train])
        
        # 计算预测概率方差
        if model_type == 'sklearn':
            try:
                pred_probs = model.predict_proba(X_train)[:, 1]  # 取正类概率
            except NotFittedError:
                raise ValueError("sklearn模型未完成训练，无法计算预测概率方差")
        elif model_type == 'statsmodel':
            pred_probs = model.predict()
        else:
            raise ValueError(f"不支持的模型类型：{model_type}，仅支持'sklearn'/'statsmodel'")
        
        # 计算协方差矩阵及逆矩阵
        var = pred_probs * (1 - pred_probs)
        cov = (X_design.T * var) @ X_design
        cov_inv = np.linalg.pinv(cov)
        
        # 计算系数标准误差
        std_err_arr = np.sqrt(np.diag(cov_inv))
        return std_err_arr
    
    def _calc_coef_pvalue(self, 
        coef_arr: np.ndarray, 
        std_err_arr: np.ndarray
        ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """
        计算系数的z值、p值和95%置信区间
        
        Parameters
        ----------
        coef_arr : np.ndarray
            回归系数数组（含截距项）
        std_err_arr : np.ndarray
            系数标准误差数组
        
        Returns
        -------
        Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]
            (z值数组, p值数组, 置信区间下限, 置信区间上限)
        """
        # 避免除零错误
        std_err_arr = np.where(std_err_arr == 0, 1e-8, std_err_arr)
        z_val_arr = coef_arr / std_err_arr
        p_values = 2 * sts.norm.sf(np.abs(z_val_arr))
        z_alpha = sts.norm.ppf(0.975)  # 1.96，95%置信水平的临界值
        low_v = coef_arr - z_alpha * std_err_arr
        up_v  = coef_arr + z_alpha * std_err_arr
        return z_val_arr, p_values, low_v, up_v
    
    def print_summary(self, model_param: Optional[Dict[str, List[Any]]] = None) -> None:
        """
        格式化打印逻辑回归结果（系数、标准误差、p值、置信区间）
        
        Parameters
        ----------
        model_param = {
            'variable': List[str],
            'coef': np.ndarray,
            'std_err': np.ndarray,
            'z_test': np.ndarray,
            'pvalues': np.ndarray,
            'conf_int': np.ndarray,
        }
        variable : List[str]
            自变量列名列表
        coef : np.ndarray
            回归系数数组（含截距项）
        std_err_arr : np.ndarray
            系数标准误差数组
        zvalues: np.ndarray
            z检验值数组
        pvalues : np.ndarray
            p值数组
        conf_int : np.ndarray
            置信区间数组（p行2列）
        """
        model_param = self.model_param if model_param is None else model_param
        if model_param is None or model_param == {}:
            raise ValueError(f"请先完成模型训练或传入合适model_param参数")
        variable    = model_param.get('variable', [])
        coef_arr    = model_param.get('coef', [])
        std_err_arr = model_param.get('std_err', [])
        z_val_arr   = model_param.get('zvalues', [])
        p_values    = model_param.get('pvalues', [])
        conf_int    = model_param.get('conf_int', [])
        # 构建表头（使用format_str确保对齐）
        head_items = ['seq', 'variable', 'coef', 'std err', 'z', 'P>|z|', '[0.025', '0.975]']
        head_formatted = []
        for item in head_items:
            fmt_item, _ = format_str(item, 10 if item != 'variable' else 50)
            head_formatted.append(fmt_item)
        
        head_str = "{0:^3s}   {1:^50s} {2:^10s} {3:^10s} {4:^10s} {5:^10s} {6:^10s} {7:^10s}".format(*head_formatted)
        
        # 打印结果标题和分隔线
        title = f'Logistic Regression Results ({time.strftime("%Y-%m-%d %H:%M:%S")})'
        print(f"\n{title:^{len(head_str)}}")
        print("=" * len(head_str))
        print(head_str)
        print("-" * len(head_str))
        
        # 逐行打印变量信息（使用format_str处理中文变量名）
        for i in range(len(coef_arr)):
            # 处理变量名（截距项/普通变量）
            if i == 0:
                col_name = 'intercept'
            else:
                col_name = variable[i-1] if (i-1) < len(variable) else f'unknown({i})'
                col_name = f"{col_name}:{self.x_cols_desc.get(col_name)}" if self.x_cols_desc.get(col_name) is not None else str(col_name)
            
            # 中文字符兼容的变量名格式化
            col_name_trunc, col_len = format_str(col_name, 50)
            
            # 提取当前行数据
            coef    = round(coef_arr[i], 4)
            std_err = round(std_err_arr[i], 4)
            z_val   = round(z_val_arr[i], 4)
            p_val   = round(p_values[i], 4)
            ci_low  = round(conf_int[i, 0], 4)
            ci_up   = round(conf_int[i, 1], 4)
            
            # 打印行数据（使用格式化后的长度确保对齐）
            val_str = f"{i:>3d} | {col_name_trunc:<{col_len}s} {coef:^10.4f} {std_err:^10.4f} " \
                      f"{z_val:^10.4f} {p_val:^10.4f} {ci_low:^10.4f} {ci_up:^10.4f}"
            print(val_str)
        print("=" * len(head_str))
 

    @_timeit
    def stepwise_by_coef_lr(self, 
        df: pd.DataFrame, 
        x_cols_list: List[str], 
        ylabel: str, 
        threshold: float = 0, 
        operators: str = "le",
        x_batch_size: int = 10,
        remove_step: int = 3,
        model_type: str = "statsmodel",
        fit_param: Dict[str, Any] = None,
        verbose: bool = None,
        ) -> Tuple[LogisticRegression, Dict[str, Any], List[str]]:
        """
        通过sklearn批次添加变量+按系数阈值逐步剔除变量
        
        Parameters
        ----------
        df : pd.DataFrame
            样本数据，通常是包含WOE转换变量和标签的数据集
        x_cols_list : List[str]
            初始自变量列名列表
        ylabel : str
            标签列名
        threshold : float, default=0
            系数阈值 通常为0，也可以设置为0附近值，意为经验性不显著，需要结合自变量是否标准化来设置
        operators : int, default=1
            比较符，根据WOE的计算逻辑决定剔除方向，当前版本是 WOE = ln(posPct/negPct), 所以WOE值与y正类正相关
            应该逐步剔除回归系数为负的变量 threshold
            "le": less  than or equal to 剔除系数≤threshold的变量
            "ge": great than or equal to 剔除系数≥threshold的变量
        x_batch_size : int, default = 10
            每次添加的变量批次大小, 当为空时为全部自变量
        remove_step : int, default=3
            变量剔除步幅 每次迭代最多剔除的变量数
        model_type: str = "statsmodel",
            需要拟合的模型类型 "statsmodel" 和 "sklearn" 两种, statsmodel是fit_regularized方法
        fit_param: Dict[str, Any] = None,
            传入模型的参数，默认设置如下：
            if model_type == "sklearn":
                fit_param = {"solver": 'newton-cg', "penalty": 'l2'}
            else:
                fit_param = {"disp": False}
        verbose: bool = None,
            是否打印冗余信息

        Returns
        -------
        Tuple[LogisticRegression, Dict[str, Any], List[str] ]
            (训练好的模型, 模型参数字典, 剔除的变量列名)
        """
        model_type = "statsmodel" if model_type != "sklearn" else model_type
        verbose = self.verbose if verbose is None else verbose
        if pd.isna(ylabel):
            raise ValueError(f"ylabel 不可为：{ylabel}")
        validate_cols(df, x_cols_list + [ylabel], "训练数据集")
        if fit_param is None:
            if model_type == "sklearn":
                fit_param = {"solver": 'newton-cg'}
            else:
                fit_param = {"disp": False}
        initial_cols = list(x_cols_list.copy())
        x_cols_list = np.array(x_cols_list.copy())
        total_cnt = len(initial_cols)

        if isinstance(x_batch_size, (int, float)) and x_batch_size > 0:
            # 计算批次数量
            batch_num = int(np.ceil(total_cnt / x_batch_size))
        else:
            batch_num = 1
            x_batch_size = total_cnt

        y = df[ylabel].values.astype(float)
        train_cols = []
        cycle_flag = 1
        iter_times = 1
        removed_count = 0
        # 初始化模型
        if model_type == "sklearn":
            lr_model = LogisticRegression(**fit_param)
        # 批次添加变量并筛选
        for batch_idx in range(batch_num):
            # 批量添加变量
            batch_cols = list(x_cols_list[int(batch_idx*x_batch_size): int((batch_idx+1)*x_batch_size)])
            train_cols += batch_cols
            cycle_flag = 1
            
            # 逐步筛选当前批次的变量
            while cycle_flag > 0:
                X = df[train_cols].values.astype(float)
                if model_type == "sklearn":
                    # 训练模型
                    lr_model.fit(X, y)
                    coef = lr_model.coef_[0]
                else:
                    X = sm.add_constant(X)
                    logit = sm.Logit(y, X)
                    lr_model = logit.fit_regularized(**fit_param)
                    coef = lr_model.params[1:]

                # 筛选待剔除的系数
                if operators == "le":
                    remove_mask = coef <= threshold
                    remove_coef = coef[remove_mask]
                    if len(remove_coef) > remove_step:
                        sort_idx = np.argsort(remove_coef)
                        threshold_step = remove_coef[sort_idx[remove_step - 1]]
                        remove_mask = coef <= threshold_step
                else:
                    remove_mask = coef >= threshold
                    remove_coef = coef[remove_mask]
                    if len(remove_coef) > remove_step:
                        sort_idx = np.argsort(remove_coef)
                        threshold_step = sort_idx[-remove_step]
                        remove_mask = coef >= threshold_step
                
                # 记录本次移除/保留的变量
                train_cols_np = np.array(train_cols)
                train_cols = train_cols_np[~remove_mask].tolist()
                cycle_flag = remove_mask.sum()
                removed_count += cycle_flag
                rest_count     = total_cnt - removed_count
                selected_count = len(train_cols)

                # 核心调用：打印批次筛选结果
                self._print_filter_result(
                    filter_desc = f"{model_type}训练-批次{batch_idx+1:^4d}-迭代次数{iter_times:^4d}",
                    rest_cnt = rest_count,
                    selected_cnt = selected_count,
                    removed_cnt = removed_count,
                    total_cnt = total_cnt,
                )
                
                # 更新迭代次数
                iter_times += 1
        if model_type == "sklearn":
            # 计算模型统计指标
            coef_arr = np.insert(lr_model.coef_[0], 0, lr_model.intercept_[0])
            std_err_arr = self._calc_coef_std_err(lr_model, df, train_cols, model_type = 'sklearn')
            z_val_arr, p_values, low_v, up_v = self._calc_coef_pvalue(coef_arr, std_err_arr)

            # 构建模型参数字典
            model_param = {
                'variable': train_cols,
                'coef': coef_arr,
                'std_err': std_err_arr,
                'zvalues': z_val_arr,
                'pvalues': p_values,
                'conf_int': np.hstack([low_v.reshape(-1, 1), up_v.reshape(-1, 1)])
            }
        else:
            model_param = {
            'variable': train_cols,
            'coef': lr_model.params,
            'std_err': lr_model.bse,
            'zvalues': lr_model.tvalues,
            'pvalues': lr_model.pvalues,
            'conf_int': lr_model.conf_int()
            }
        # 最终打印模型摘要
        if verbose:
            print()
            # 打印回归结果（内部调用format_str处理中文变量名）
            self.print_summary(model_param)

        removed_cols = [icol for icol in initial_cols if icol not in train_cols]
        # 更新类属性
        self.model = lr_model
        self.model_type = model_type
        self.model_param = model_param
        self.results['removed_vars']['coef'] = removed_cols
        self.results['selected_vars'] = train_cols
        return lr_model, model_param, removed_cols
 
    @_timeit
    def stepwise_by_pvalue_lr(self, 
        df: pd.DataFrame, 
        x_cols_list: List[str], 
        ylabel: str, 
        alpha: float = 0.05,
        x_batch_size: int = 10,
        remove_step: int = 3,
        model_type: str = "statsmodel",
        fit_param: Dict[str, Any] = None,
        verbose: bool = None,
        ) -> Tuple[LogisticRegression, Dict[str, Any], List[str]]:
        """
        通过sklearn批次添加变量+按系数阈值逐步剔除变量
        
        Parameters
        ----------
        df : pd.DataFrame
            样本数据，通常是包含WOE转换变量和标签的数据集
        x_cols_list : List[str]
            初始自变量列名列表
        ylabel : str
            标签列名
        alpha: float = 0.01
            alpha : float, default=0.05
            显著性水平（p值≥alpha的变量被剔除）
        x_batch_size : int, default = 10
            每次添加的变量批次大小, 当为空时为全部自变量
        remove_step : int, default=3
            变量剔除步幅 每次迭代最多剔除的变量数
        model_type: str = "statsmodel",
            需要拟合的模型类型 "statsmodel" 和 "sklearn" 两种, statsmodel是fit_regularized方法
        fit_param: Dict[str, Any] = None,
            传入模型的参数，默认设置如下：
            if model_type == "sklearn":
                fit_param = {"solver": 'newton-cg', "penalty": 'l2'}
            else:
                fit_param = {"disp": False}
        verbose: bool = None,
            是否打印冗余信息

        Returns
        -------
        Tuple[LogisticRegression, Dict[str, Any], List[str] ]
            (训练好的模型, 模型参数字典, 剔除的变量列名)
        """
        model_type = "statsmodel" if model_type != "sklearn" else model_type
        verbose = self.verbose if verbose is None else verbose
        if pd.isna(ylabel):
            raise ValueError(f"ylabel 不可为：{ylabel}")
        validate_cols(df, x_cols_list + [ylabel], "训练数据集")
        if fit_param is None:
            if model_type == "sklearn":
                fit_param = {"solver": 'newton-cg'}
            else:
                fit_param = {"disp": False}
        initial_cols = list(x_cols_list.copy())
        x_cols_list = np.array(x_cols_list.copy())
        total_cnt = len(initial_cols)

        if isinstance(x_batch_size, (int, float)) and x_batch_size > 0:
            # 计算批次数量
            batch_num = int(np.ceil(total_cnt / x_batch_size))
        else:
            batch_num = 1
            x_batch_size = total_cnt

        y = df[ylabel].values.astype(float)
        train_cols = []
        cycle_flag = 1
        iter_times = 1
        removed_count = 0
        # 初始化模型
        if model_type == "sklearn":
            lr_model = LogisticRegression(**fit_param)
        # 批次添加变量并筛选
        for batch_idx in range(batch_num):
            # 批量添加变量
            batch_cols = list(x_cols_list[int(batch_idx*x_batch_size): int((batch_idx+1)*x_batch_size)])
            train_cols += batch_cols
            cycle_flag = 1
            
            # 逐步筛选当前批次的变量
            while cycle_flag > 0:
                X = df[train_cols].values.astype(float)
                if model_type == "sklearn":
                    # 训练模型
                    lr_model.fit(X, y)
                    coef = lr_model.coef_[0]
                    # 计算p值
                    coef_arr = np.insert(lr_model.coef_[0], 0, lr_model.intercept_[0])
                    std_err_arr = self._calc_coef_std_err(lr_model, df, train_cols, model_type = 'sklearn')
                    _, p_values, _, _ = self._calc_coef_pvalue(coef_arr, std_err_arr)
                    
                    # 筛选不显著变量（跳过截距项）
                    p_values_vars = p_values[1:]
                else:
                    X = sm.add_constant(X)
                    logit = sm.Logit(y, X)
                    lr_model = logit.fit_regularized(**fit_param)
                    # 筛选不显著变量
                    p_values_vars = lr_model.pvalues[1:]  # 跳过截距项的p值

                non_significant_mask = p_values_vars >= alpha
                non_significant_pv   = p_values_vars[non_significant_mask]
                # 确定本次剔除的阈值
                if len(non_significant_pv) > remove_step:
                    sort_idx = np.argsort(non_significant_pv)
                    alpha_step = non_significant_pv[sort_idx[-remove_step]]
                    remove_mask = p_values_vars >= alpha_step
                else:
                    remove_mask = non_significant_mask
                
                # 记录本次移除/保留的变量
                train_cols_np = np.array(train_cols)
                train_cols = train_cols_np[~remove_mask].tolist()
                cycle_flag = remove_mask.sum()
                removed_count += cycle_flag
                rest_count     = total_cnt - removed_count
                selected_count = len(train_cols)

                # 核心调用：打印批次筛选结果
                self._print_filter_result(
                    filter_desc = f"{model_type}训练-批次{batch_idx+1:^4d}-迭代次数{iter_times:^4d}",
                    rest_cnt = rest_count,
                    selected_cnt = selected_count,
                    removed_cnt = removed_count,
                    total_cnt = total_cnt,
                )
                
                # 更新迭代次数
                iter_times += 1
        if model_type == "sklearn":
            # 计算模型统计指标
            coef_arr = np.insert(lr_model.coef_[0], 0, lr_model.intercept_[0])
            std_err_arr = self._calc_coef_std_err(lr_model, df, train_cols, model_type = 'sklearn')
            z_val_arr, p_values, low_v, up_v = self._calc_coef_pvalue(coef_arr, std_err_arr)

            # 构建模型参数字典
            model_param = {
                'variable': train_cols,
                'coef': coef_arr,
                'std_err': std_err_arr,
                'zvalues': z_val_arr,
                'pvalues': p_values,
                'conf_int': np.hstack([low_v.reshape(-1, 1), up_v.reshape(-1, 1)])
            }
        else:
            model_param = {
            'variable': train_cols,
            'coef': lr_model.params,
            'std_err': lr_model.bse,
            'zvalues': lr_model.tvalues,
            'pvalues': lr_model.pvalues,
            'conf_int': lr_model.conf_int()
            }
        if verbose:
            print()
            # 打印回归结果
            self.print_summary(model_param)

        removed_cols = [icol for icol in initial_cols if icol not in train_cols]
        # 更新类属性
        self.model = lr_model
        self.model_type = model_type
        self.model_param = model_param
        self.results['removed_vars']['pvalue'] = removed_cols
        self.results['selected_vars'] = train_cols
        return lr_model, model_param, removed_cols


    @_timeit
    def filter_vif(self, 
        df: pd.DataFrame, 
        x_cols_list: List[str], 
        df_iv: pd.DataFrame, 
        vif_thresh: float = 10.0,
        verbose: bool = None,
        ) -> Tuple[List[str], List[str], dict]:
        """
        筛选逻辑：基于VIF剔除多重共线性变量（按IV升序优先剔除）
        df: 训练数据集，通常为woe编码后的宽表，pd.DataFrame
        x_cols_list: 自变量列表
        df_iv: 自变量IV信息表，pd.DataFrame, 需包含['variable', 'IV']两个字段
        vif_thresh: VIF阈值（高于此值剔除多重共线性变量）
        """
        verbose = self.verbose if verbose is None else verbose
        # 参数校验
        if df is None or df.empty:
            raise ValueError(f"df 不可为：{df}")
        if x_cols_list is None or len(x_cols_list) == 0:
            raise ValueError(f"x_cols_list 不可为：{x_cols_list}")
        if df_iv is None or df_iv.empty:
            raise ValueError(f"df_iv 不可为：{df_iv}")

        validate_cols(df, list(x_cols_list), "VIF数据集")
        validate_cols(df_iv, ['variable', 'IV'], "IV数据集")

        # 按IV升序排序
        iv_list = []
        for col in x_cols_list:
            iv_vals = df_iv[df_iv['variable'] == col]['IV'].values
            if len(iv_vals) == 0:
                raise ValueError(f"df_iv中无【{col}】变量IV")
            iv = iv_vals[0] if len(iv_vals) > 0 else 0
            iv_list.append([col, iv])
        iv_list_sorted = sorted(iv_list, key = lambda x: x[1])
        x_cols_list_sorted = [x[0] for x in iv_list_sorted]

        # 计算VIF
        vif_info = {}
        removed_vars = []
        selected_vars = []
        candidate_vars = list(copy.deepcopy(x_cols_list))

        with tqdm(x_cols_list_sorted, ascii=True, desc='计算方差膨胀因子') as pbar:
            iter_times = 1
            for col in pbar:
                if col not in candidate_vars:
                    continue

                # 构建自变量矩阵
                x_cols = [c for c in candidate_vars if c != col]
                if not x_cols:
                    break

                try:
                    x = df[x_cols].fillna(0).values.astype(float)
                    x = sm.add_constant(x)
                    y = df[col].fillna(0).values.astype(float)

                    # 拟合OLS模型
                    model = sm.OLS(y, x).fit()
                    r2 = model.rsquared
                    vif = 1 / (1 - r2) if (1 - r2) > 1e-10 else np.inf
                    vif_info[col] = vif

                    # 判断是否剔除
                    if vif >= vif_thresh:
                        candidate_vars.remove(col)
                        removed_vars.append(col)
                    else:
                        selected_vars.append(col)
                except Exception as e:
                    if verbose:
                        print(f"变量{col}计算VIF失败：{str(e)}")
                    vif_info[col] = np.inf
                    removed_vars.append(col)
                    candidate_vars.remove(col)

                # 核心调用：打印筛选结果
                self._print_filter_result(
                    filter_desc = f"方差膨胀因子-迭代次数{iter_times:^4d}",
                    rest_cnt = len(candidate_vars),
                    selected_cnt = len(selected_vars),
                    removed_cnt = len(removed_vars),
                    total_cnt = len(x_cols_list),
                )
                iter_times += 1

        # 更新结果
        removed_vars = list(set(removed_vars))
        selected_vars = [col for col in x_cols_list if col not in removed_vars]
        self.results['removed_vars']['vif'] = removed_vars
        self.results['selected_vars'] = selected_vars
        self.results['vif_info'] = vif_info
        # 打印VIF详情
        if verbose:
            print("\n")
            for idx, icol in enumerate(selected_vars):
                col_name = f"{icol}:{self.x_cols_desc.get(icol)}" if self.x_cols_desc.get(icol) is not None else icol
                vif = vif_info.get(icol)
                col_trunc, slen = format_str(str(col_name), max_len = 60)
                print(f"{idx+1:>4d} | {col_trunc:{slen}s}    VIF: {vif:^8.4f}")
            print()
        return selected_vars, removed_vars, vif_info
