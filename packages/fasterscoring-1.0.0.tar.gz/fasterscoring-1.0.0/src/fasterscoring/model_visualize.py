# -*- coding: utf-8 -*-
"""
评分模型可视化模块 (Model Visualize Module)
=============================================
版本信息：v1.0.0
作者: Faster Scoring Team XM
功能说明：
1. KS AUC GINI PR图像可视化
2. WOE 数据分布可视化
3. 相关系数矩阵可视化
"""
import os
import math
import numpy as np
import pandas as pd
import scipy.stats as sts
from scipy import integrate
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import matplotlib.font_manager
import seaborn as sns
from sklearn import metrics
from fasterscoring.general_utils import *
import warnings
from typing import Dict, List, Tuple, Union, Optional, Any, Callable
import ipywidgets
if ipywidgets.__version__ > "7.8.5":
    from tqdm import tqdm
else:
    from tqdm.auto import tqdm

# 忽略非关键警告
warnings.filterwarnings('ignore')


class ModelVisualizer:
    """
    评分卡建模可视化工具类
    功能：提供密度图、WOE图、相关性热力图、KS/AUC/GINI/PR曲线等评分卡核心可视化能力
    """
    def __init__(self, 
        x_cols_desc: Dict = None, 
        plot_save_path: str = None, 
        font: str = None,
        label_mapping: Dict = None, 
        precision: int = 6,
        ):
        """
        初始化可视化工具
        :param x_cols_desc: x变量描述字典 {变量名: 描述}
        :param plot_save_path: 图片保存根路径
        :param font: 绘图字体（适配中文）
        """
        import matplotlib.font_manager
        # 获取所有已加载的字体系列名称
        font_list = [f.name for f in matplotlib.font_manager.fontManager.ttflist]
        chinese_font = [
        "Microsoft YaHei","Microsoft YaHei UI","SimSun","NSimSun","DengXian", "FangSong","SimHei",
        "KaiTi","Microsoft JhengHei","Microsoft JhengHei UI","PingFang SC","Songti SC","Heiti SC",
        "STHeiti","STKaiti","STSong","STFangsong","STXihei","STXingkai","STXinwei","STHupo","STCaiyun",
        "Apple LiGothic","Apple LiSung","Arial Unicode MS","PingFang TC","PingFang HK","Songti TC",
        "Heiti TC","YouYuan",
        ]
        valid_font_list = [ifont for ifont in chinese_font if ifont in font_list]
        valid_font_list = valid_font_list if valid_font_list else [None]
        self.x_cols_desc = x_cols_desc or {}
        self.label_mapping  = label_mapping or {'positive': 1, 'negative': 0}
        self.precision = precision if precision is not None else 6
        self.plot_save_path = plot_save_path if plot_save_path is not None else os.path.join(".", "ftsmodel", "plot")
        self.font_list = [font] if font else valid_font_list
        self._init_plot_style()  # 初始化绘图样式
        os.makedirs(self.plot_save_path, exist_ok = True)  # 创建保存目录

    def _init_plot_style(self):
        """私有方法：初始化绘图全局样式"""
        sns.set_style("darkgrid")
        plt.rcParams['font.sans-serif'] = self.font_list
        plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

    def _get_valid_path(self, filename: str) -> str:
        """私有方法：处理文件名特殊字符，返回合法保存路径"""
        valid_filename = filename.replace('/', '|').replace('\\', '|')
        return os.path.join(self.plot_save_path, f"{valid_filename}.png")

    def density_plot(self, df: pd.DataFrame, x_col: str, remove_outlier: bool = False, figsize:Tuple = (4, 3), dpi:int = 100):
        """
        绘制单变量密度分布图（含均值/中位数/众数）
        :param df: 数据集
        :param x_col: 变量名
        :param remove_outlier: 是否移除1%/99%分位数外的异常值
        :return: 图片保存路径
        """
        # 获取变量描述
        var_desc = self.x_cols_desc.get(x_col)
        var_name = f"{x_col}:{var_desc}" if pd.notna(var_desc) else str(x_col)
        print(var_name)

        # 提取非空数据
        valid_data = df[df[x_col].notna()][x_col].values
        if len(valid_data) == 0:
            print(f"变量{x_col}无有效数据，跳过绘图")
            return ""

        # 移除异常值
        if remove_outlier:
            q1, q99 = calculate_quantiles(valid_data, perc_arr = [0.0001, 0.9999], precision = self.precision, unique = False)
            # print(f"{x_col}异常值阈值：[{q1:.6f}, {q99:.6f}]")
            valid_data = valid_data[(valid_data >= q1) & (valid_data <= q99)]

        # 计算统计量
        mean_val   = np.mean(valid_data)
        median_val = np.median(valid_data)
        mode_val   = pd.Series(valid_data).mode().iloc[0] if len(pd.Series(valid_data).mode()) > 0 else np.nan

        # 绘图
        fig, ax = plt.subplots(figsize = figsize, dpi = dpi)
        sns.distplot(valid_data, ax = ax)
        # 绘制统计量垂直线
        ax.axvline(mean_val, ls='-', color='#DB7093', label = f"均值: {mean_val:.2f}")
        ax.axvline(median_val, ls='-', color='#5F9F9F', label = f"中位数: {median_val:.2f}")
        if not np.isnan(mode_val):
            ax.axvline(mode_val, ls='-', color='#2F2F4F', label = f"众数: {mode_val:.2f}")
        
        ax.legend(loc = "best", prop={'size': 8})
        ax.set_title(f"{var_name} 概率分布", fontsize = 10, fontweight ='bold')
        # plt.tight_layout()

        # 保存图片
        # save_path = self._get_valid_path(x_col)
        # fig.savefig(save_path, bbox_inches='tight')
        plt.show()
        plt.close(fig)
        # print(f"密度图保存路径：{save_path}\n")

    def woe_plot(self, woe_info: Dict, x_cols_list: List, x_rot: int = 15):
        """
        绘制WOE分布图（单变量WOE值+占比+正样本率）
        :param woe_dict: WOE字典 {变量名: pd.DataFrame}
        :param x_cols_list: 待绘图变量列表
        :param x_rot: x轴标签旋转角度
        """
        with tqdm(x_cols_list, ascii=True, desc='绘制WOE图') as pbar:
            for ivar in pbar:
                woe_data = woe_info.get(ivar, [])
                var_desc = self.x_cols_desc.get(ivar)
                var_name = f"{ivar}:{var_desc}" if pd.notna(var_desc) else str(ivar)
                if len(woe_data) == 0:
                    print(f"变量{var_name}无WOE数据，跳过")
                    continue
                print(var_name)
                # 提取绘图数据
                bins = woe_data['interval'].values
                woe_vals = woe_data['WOE'].values
                tot_rates = woe_data['totPct'].values
                pos_rates = woe_data['binPosRate'].values

                # 绘图
                fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 3.5), dpi=100, facecolor="#eeeeee")
                # WOE柱状图+折线图
                sns.barplot(x = bins, y = woe_vals, palette = 'rocket', ax = ax1, label = 'WOE')
                ax1.axhline(0, color = 'k', clip_on = False)
                ax1.plot(bins, woe_vals, color = '#5F9EA0', marker = '.')
                ax1.tick_params(axis = 'x', labelrotation = x_rot)
                ax1.legend(['WOE'], loc = 'best')

                # 占比柱状图 + 正样本率折线图
                ax2.bar(bins, tot_rates, width = 0.6, color = '#2E8B57', label = 'totPct')
                ax2.set_ylim(0, 1.2)
                ax2.tick_params(axis = 'x', labelrotation = x_rot)
                ax2.legend(loc = 'upper right', bbox_to_anchor = (0.5, 1))

                ax3 = ax2.twinx()
                ax3.plot(bins, pos_rates, marker = 'D', linestyle = '--', markersize = 4, color = '#DC143C', label = 'binPosRate')
                ax3.set_ylim(0, max(pos_rates) + 0.2 if len(pos_rates) > 0 else 1)
                ax3.grid(False)
                ax3.legend(loc='upper right', bbox_to_anchor=(0.8, 1))

                # 添加数值标签
                for a, b in zip(bins, tot_rates):
                    ax2.text(a, b + 0.005, f'{b:.1%}', ha='center', va='bottom', fontsize=8)
                for a, b in zip(bins, pos_rates):
                    ax3.text(a, b + 0.005, f'{b:.1%}', ha='center', va='bottom', fontsize=8, color='#8B0000')

                plt.suptitle(var_name)
                plt.tight_layout()
                plt.show()
                plt.close(fig)


    def _cal_dynamic_shrink(self, fig, ax, corr_data, square=True):
        """
        不临时绘图，直接计算适配热力图高度的shrink值
        参数：
            fig: 画布对象
            ax: 坐标轴对象
            corr_data: 相关性矩阵（DataFrame/二维数组）
            square: 是否强制单元格为正方形（对应heatmap的square参数）
        返回：
            dynamic_shrink: 适配的shrink值
        """
        # 1. 获取基础参数
        n_rows = corr_data.shape[0]  # 矩阵行数（单元格行数）
        fig_height = fig.get_figheight()  # 画布高度（英寸）
        fig_width  = fig.get_figwidth()   # 画布宽度（英寸）
        # 2. 计算画布的有效可用空间（扣除默认边距，matplotlib默认边距约0.1）
        margin_ratio = 0.1  # 边距占画布的比例（可根据实际调整）
        effective_fig_h = fig_height * (1 - 2 * margin_ratio)  # 上下边距
        effective_fig_w = fig_width * (1 - 2 * margin_ratio)   # 左右边距
        
        # 3. 计算单个单元格的尺寸（因square=True，单元格宽高相等）
        if square:
            # 正方形单元格的尺寸由宽度方向的可用空间决定（避免超出画布）
            cell_size = effective_fig_w / (n_rows + 0.5)  # +0.5 预留标注/刻度空间
        else:
            cell_size = effective_fig_h / (n_rows + 0.5)
        
        # 4. 计算热力图矩阵的实际高度（英寸）
        heatmap_height = cell_size * n_rows
        
        # 5. 计算默认颜色条的高度（matplotlib默认颜色条高度约为画布有效高度的80%）
        default_cbar_height = effective_fig_h * 2
        
        # 6. 计算动态shrink值（矩阵高度 / 默认颜色条高度）
        dynamic_shrink = heatmap_height / default_cbar_height

        # 限制shrink范围（避免极端值，0.2-1.0是合理区间）
        dynamic_shrink = np.clip(dynamic_shrink, 0.2, 0.6)
        
        return dynamic_shrink


    def corr_heatmap(self, df: pd.DataFrame, x_cols_list: list, figsize: tuple = (20, 20)):
        """
        绘制变量相关性热力图
        :param df: 数据集
        :param x_cols_list: 待分析变量列表
        :param figsize: 图片尺寸
        """
        x_cols_desc = [f"{ivar}:{self.x_cols_desc.get(ivar, '')}".strip().rstrip(':') for ivar in x_cols_list]
        # 提取有效数据并计算相关系数
        data_array = df[x_cols_list].fillna(0).values.astype(float)
        corr_data = np.round(np.corrcoef(data_array, rowvar = False), 3)
        # 绘图
        fig, ax = plt.subplots(figsize = figsize)
        sns.heatmap(
            corr_data, ax = ax, annot = True, annot_kws = {'size': 12, 'weight': 'bold'},
            vmax=1, vmin=0, xticklabels = True, yticklabels = True, square=True, cmap="YlGnBu",
            cbar_kws = {
                        'shrink': self._cal_dynamic_shrink(fig, ax ,corr_data),   # 长度缩放
                        # 'aspect': 20,         # 宽高比
                        # 'orientation': 'vertical',  # 方向（vertical/horizontal）
                        # 'label': 'Correlation',     # 颜色条标签
                        'pad': 0.05           # 颜色条与热力图的间距
                    }
        )
        ax.set_title('变量相关性矩阵', fontsize=20)
        ax.set_yticklabels(x_cols_desc, fontsize=14, rotation=0,  horizontalalignment='right')
        ax.set_xticklabels(x_cols_desc, fontsize=14, rotation=30, horizontalalignment='right')
        # plt.tight_layout()
        plt.show()
        # 保存图片
        save_path = self._get_valid_path('corr_heatmap')
        fig.savefig(save_path)
        plt.close(fig)


    def _calc_auc(self, df: pd.DataFrame, prob_col: str, ylabel: str, label_mapping: Dict = None) -> float:
        """私有方法：计算AUC值（基于秩和法）"""
        label_mapping = label_mapping if label_mapping else self.label_mapping or {'positive': 1, 'negative': 0}
        pos_label = label_mapping.get('positive', 1)
        neg_label = label_mapping.get('negative', 0)
        
        # 过滤有效标签数据
        df_valid = df[df[ylabel].isin([pos_label, neg_label])].copy()
        if len(df_valid) == 0:
            return 0.0
        
        # 计算秩和
        df_valid['rank'] = df_valid[prob_col].rank(method = "average")
        pos_mask = df_valid[ylabel] == pos_label
        M = pos_mask.sum()
        N = len(df_valid) - M
        
        if M == 0 or N == 0:
            return 0.0 if M == 0 else 1.0
        
        rank_sum = df_valid.loc[pos_mask, 'rank'].sum()
        auc = (rank_sum - M * (M + 1) / 2) / (M * N)
        return auc

    def calc_ks_auc_stats(self, df: pd.DataFrame, prob_cols: list, ylabel: str, 
        label_mapping: Dict = None, prob_trend_pos: Dict = None, precision: int = 6
        ) -> Dict:
        """
        计算KS/AUC/GINI等指标统计量
        :param df: 数据集
        :param prob_cols: 概率/分数列列表
        :param ylabel: 标签列名
        :param label_mapping: 标签映射字典
        :param prob_trend_pos: prob_trend_pos字典key与prob_cols值相对应，prob是否与ylabel正类正相关，便于TRP, FPR, AUC, F1-score的计算
        :param precision: 小数点位数
        :return: 指标统计字典 {列名: {AUC: ..., KS: ..., ...}}
        """
        precision = self.precision if pd.isna(precision) else precision
        label_mapping = label_mapping if label_mapping else self.label_mapping or {'positive': 1, 'negative': 0}
        prob_trend_pos = prob_trend_pos if prob_trend_pos else {}
        pos_label = label_mapping.get('positive', 1)
        neg_label = label_mapping.get('negative', 0)
        
        # 过滤有效标签数据
        y_vals = df[ylabel].values.astype(int)
        pos_mask = y_vals == pos_label
        neg_mask = y_vals == neg_label
        pos_cnt = pos_mask.sum()
        neg_cnt = neg_mask.sum()
        total_cnt = len(df)
        base_prob = pos_cnt / (pos_cnt + neg_cnt) if (pos_cnt + neg_cnt)  > 0 else 0.0

        stats_dict = {}
        for col in prob_cols:
            trend_positive = prob_trend_pos.get(col, True)
            prob_vals = df[col].values.astype(float)
            cut_points = np.unique(prob_vals)
            # 生成分位数切点
            if len(cut_points) > 1000:
                cut_points = calculate_quantiles(prob_vals[pd.notna(prob_vals)], 
                    n_bins = 1000, precision = precision, unique = True, include_extremes = False
                    )
                cut_points[0]  = prob_vals.min()
                cut_points[-1] = prob_vals.max()

            # 提取正负样本概率值
            pos_probs = prob_vals[pos_mask]
            neg_probs = prob_vals[neg_mask]
            
            # 计算各切点的KS/TPR/FPR
            ks_list = []
            tpr_list = []
            fpr_list = []
            precision_list = []
            max_ks = 0.0
            max_ks_idx = 0
            
            # 计算AUC
            auc = self._calc_auc(df, col, ylabel, label_mapping)
            if not trend_positive:
                auc = 1 - auc
            gini = (0.5 - (1 - auc))/0.5  # GINI计算
            cut_points = np.sort(cut_points)
            if trend_positive:
                cut_points = cut_points[::-1]
            for i, cut_val in enumerate(cut_points):
                # 计算TP/FP
                if trend_positive:
                    tot_mask = prob_vals >= cut_points[i]
                    pos_tot_mask = pos_probs >= cut_points[i]
                    neg_tot_mask = neg_probs >= cut_points[i]
                else:
                    tot_mask = prob_vals <= cut_points[i]
                    pos_tot_mask = pos_probs <= cut_points[i]
                    neg_tot_mask = neg_probs <= cut_points[i]
                
                tp  = pos_tot_mask.sum()
                fp  = neg_tot_mask.sum()
                tot = tot_mask.sum()

                # 计算指标
                tpr = tp / pos_cnt if pos_cnt > 0 else 0.0
                fpr = fp / neg_cnt if neg_cnt > 0 else 0.0
                ks = abs(tpr - fpr)
                pred_precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0

                ks_list.append(ks)
                tpr_list.append(tpr)
                fpr_list.append(fpr)
                precision_list.append(pred_precision)

            # 保存统计结果
            stats_dict[col] = {
                'base_prob': base_prob,
                'auc': auc,
                'gini': gini,
                'cut_points': cut_points,
                'ks_list': ks_list,
                'tpr_list': tpr_list,
                'fpr_list': fpr_list,
                'pred_precision': precision_list,
                }
        return stats_dict


    def plot_ks_auc_gini(self, prob_cols: list, stats_dict: Dict, prob_trend_pos: Dict = None, 
        pred_score_xlabel: bool = True, plot_title: str = "Train", figsize:Tuple = (16, 4.5), dpi:int = 100,):
        """
        绘制KS/ROC/GINI组合图
        :param prob_cols
        :param stats_dict: calc_ks_auc_stats返回的统计字典
        :param prob_trend_pos: prob_trend_pos字典key与prob_cols值相对应，prob是否与ylabel正类正相关，便于TRP, FPR, AUC, F1-score的计算
        :param plot_title: 图表标题前缀
        """
        prob_trend_pos = prob_trend_pos if prob_trend_pos else {}
        # 颜色配置
        colors = [
            ['mediumblue', '#FF5809', 'seagreen'],
            ['#4B0091', '#FF359A', 'cadetblue'],
            ['#7373B9', '#FF8EFF', '#A3D1D1']
        ]
        
        fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize = figsize, dpi = dpi, facecolor="#eeeeee")

        # 绘制KS/TPR/FPR图
        valid_cols = [icol for icol in prob_cols if stats_dict.get(icol)]
        for idx, col in enumerate(prob_cols):
            stats = stats_dict.get(col)
            if not stats:
                continue
            trend_positive = prob_trend_pos.get(col, True)
            tpr_list = np.sort(stats['tpr_list'])
            fpr_list = np.sort(stats['fpr_list'])
            if (len(valid_cols) == 1) and pred_score_xlabel:
                cut_points = stats['cut_points']
                xlabel = "预测分数(Pred)"
            else:
                cut_points = np.arange(1, len(stats['tpr_list'])+1)/len(stats['tpr_list'])
                xlabel = "预测分位数(Quantile)"

            ks_list = np.abs(tpr_list - fpr_list)
            max_ks  = np.max(ks_list)
            max_ks_idx = np.argmax(ks_list)

            # 绘图样式
            linestyle = '-' if idx == 0 else '--'
            linewidth = 1.5 if idx == 0 else 1.2
            TPR_color, FPR_color, KS_color = colors[idx] if idx + 1 <= len(colors) else [None, None, None]

            # 绘制曲线
            if len(valid_cols) == 1:
                ax1.plot(cut_points, tpr_list, label = f'TPR-{col}', c = TPR_color, linestyle = linestyle, linewidth = linewidth)
                ax1.plot(cut_points, fpr_list, label = f'FPR-{col}', c = FPR_color, linestyle = linestyle, linewidth = linewidth)
            else:
                ax1.plot(cut_points, tpr_list, c = TPR_color, linestyle = linestyle, linewidth = linewidth)
                ax1.plot(cut_points, fpr_list, c = FPR_color, linestyle = linestyle, linewidth = linewidth)
            ax1.plot(cut_points, ks_list,  label = f'(KS: {max_ks:.4f})-{col}', c = KS_color, linestyle = linestyle, linewidth = linewidth)
            
            # 标注最大KS
            ax1.axvline(x = cut_points[max_ks_idx], color='gray' if idx == 0 else None, linestyle='--', lw=0.8)
            ax1.axhline(y = max_ks, color = KS_color, linestyle='--', lw=1.0)
            if (len(valid_cols) == 1) and trend_positive and pred_score_xlabel:
                ax1.invert_xaxis()

        # 设置KS图样式
        ax1.set_ylim([0, 1])
        ax1.set_title(f"{plot_title} KS曲线", fontsize = 12, fontweight ='bold')
        ax1.set_ylabel('累计率(Cumulative)')
        ax1.set_xlabel(xlabel)
        ax1.legend(loc = 'upper left')

        # 绘制ROC/AUC图
        self._plot_auc(ax2, prob_cols = prob_cols, stats_dict = stats_dict, plot_title = plot_title)
        # 绘制GINI图
        self._plot_gini(ax3, prob_cols = prob_cols, stats_dict = stats_dict, plot_title = plot_title)

        # 保存图片
        save_path = self._get_valid_path(f"{plot_title}_ks_auc_gini")
        # print(f"KS/AUC/GINI图保存路径：{save_path}")
        # plt.tight_layout()
        plt.show()
        fig.savefig(save_path)
        plt.close(fig)

    def _plot_auc(self, ax, prob_cols: list,  stats_dict: Dict = None, plot_title: str = None):
        """私有方法：绘制ROC/AUC子图"""
        colors = ['lightslategray', '#FF95CA', '#81C0C0']
        auc_str = ""
        for idx, col in enumerate(prob_cols):
            stats = stats_dict.get(col)
            if not stats:
                continue
            auc = stats['auc']
            tpr_list = np.sort(stats['tpr_list'])
            fpr_list = np.sort(stats['fpr_list'])
            linestyle = '-' if idx == 0 else '--'
            linewidth = 0.6 if idx == 0 else 0.4
            color = colors[idx] if idx + 1 <= len(colors) else None 
            ax.fill_between(fpr_list, tpr_list, color = 'lightslategrey' if idx == 0 else None, alpha = 0.3)
            ax.plot(fpr_list, tpr_list, label = f'(AUC: {auc:.4f})-ROC-{col}', color = color, linestyle = linestyle, linewidth = linewidth)

        ax.plot([0, 1], [0, 1], color='#696969', linestyle="--", linewidth=1.2)
        ax.set_title(f"{plot_title} ROC曲线 [AUC]", fontsize = 12, fontweight='bold')
        ax.set_xlabel('假正例率(FPR)')
        ax.set_ylabel('真正例率(TPR)')
        ax.set_xlim([0.0, 1.0])
        ax.set_ylim([0.0, 1.0])
        ax.legend(loc = 'lower right')



    def _plot_gini(self, ax, prob_cols: list,  stats_dict: Dict = None, plot_title: str = None):
        """
        1. 保留TPR/FPR原始顺序，确保洛伦兹曲线形态真实
        2. 精准计算两个面积的形心并标注A/B
        ax: 绘图坐标轴
        stats_dict: {列名: {'tpr_list': [...], 'fpr_list': [...], 'gini': 数值}}
        plot_title: 子图标题
        返回值: 目标列的形心坐标 (cx_A, cy_A, cx_B, cy_B)
        """
        ax.clear()
        ax.set_xlim(0.0, 1.0)
        ax.set_ylim(0.0, 1.0)
        ax.set_xticks([0.0, 0.2, 0.4, 0.6, 0.8, 1.0])
        ax.set_yticks([0.0, 0.2, 0.4, 0.6, 0.8, 1.0])

        
        for idx, col in enumerate(prob_cols):
            stats = stats_dict.get(col)
            if not stats:
                continue
            # 1. 数据清洗（仅替换异常值，不改变原始顺序）
            tpr_original = np.sort(stats.get('tpr_list', []))
            fpr_original = np.sort(stats.get('fpr_list', []))
            gini  = stats.get('gini', 0)
            
            # 2. 重构等距TPR序列（用于精准积分，不改变原始曲线形态）
            tpr_eq = np.linspace(0, 1, 100)
            fpr_eq = np.interp(tpr_eq, tpr_original, fpr_original)

            # 3. 计算面积A（洛伦兹曲线 vs 45°线）的形心（基于等距序列）
            if np.__version__ >= "2.0.0":
                trapezoid = np.trapezoid
            else:
                trapezoid = np.trapz
            area_A = trapezoid(tpr_eq - fpr_eq, tpr_eq)
            cx_A = trapezoid(tpr_eq * (tpr_eq - fpr_eq), tpr_eq) / area_A if area_A > 1e-8 else 0.5
            cy_A = trapezoid(0.5 * (tpr_eq**2 - fpr_eq**2), tpr_eq) / area_A if area_A > 1e-8 else 0.5
            cx_A, cy_A = np.clip(cx_A, 0, 1), np.clip(cy_A, 0, 1)

            # 4. 计算面积B（洛伦兹曲线 vs 横轴）的形心（基于等距序列）
            area_B = trapezoid(fpr_eq, tpr_eq)
            cx_B = trapezoid(tpr_eq * fpr_eq, tpr_eq) / area_B if area_B > 1e-8 else 0.5
            cy_B = trapezoid(0.5 * fpr_eq**2, tpr_eq) / area_B if area_B > 1e-8 else 0.2
            cx_B, cy_B = np.clip(cx_B, 0, 1), np.clip(cy_B, 0, 1)

            linestyle = '-' if idx == 0 else '--'
            linewidth = 0.6 if idx == 0 else 0.4

            # 5. 绘图（用原始TPR/FPR，保证曲线形态真实）
            ax.fill_between(tpr_original, tpr_original, fpr_original, color='lightcoral', alpha=0.4)
            ax.fill_between(tpr_original, fpr_original, 0, color='lightslategray', alpha=0.2)
            ax.plot(tpr_original, fpr_original, linestyle = linestyle, linewidth = linewidth, 
                color = 'darkslateblue'  if idx == 0 else None, label=f'(Gini: {gini:.4f})-LC-{col}')

            # 6. 标注A/B（精准形心位置，与原始曲线匹配）
            ax.annotate('A', (cx_A, cy_A), fontsize=12, fontweight='bold',
                        bbox=dict(boxstyle='circle,pad=0.3', facecolor='yellow', alpha=0.2),
                        ha='center', va='center')
            ax.annotate('B', (cx_B, cy_B), fontsize=12, fontweight='bold',
                        bbox=dict(boxstyle='circle,pad=0.3', facecolor='green', alpha=0.2),
                        ha='center', va='center')
        ax.plot([0,1], [0,1], '--', linewidth=1.2, color='red')
        # 基础配置
        ax.set_title(f"{plot_title} LC曲线 [Gini]", fontsize=12, fontweight='bold')
        ax.set_xlabel('真正例率(TPR)')
        ax.set_ylabel('假正例率(FPR)')
        ax.set_xlim([0.0, 1.0])
        ax.set_ylim([0.0, 1.0])
        ax.legend(loc='best')
        

    def plot_pr_curve(self, train_stats: dict, test_stats: Dict, prob_cols: List, 
        plot_title:list = ['Train', 'Test'], figsize:Tuple=(16, 5), dpi:int=100,):
        """
        绘制PR曲线（训练集+测试集对比）
        :param train_stats: 训练集calc_ks_auc_stats结果
        :param test_stats: 测试集calc_ks_auc_stats结果
        :param prob_cols: 概率/分数列列表
        :param plot_title train_stats、test_stats画图的title
        """
        plot_title = plot_title or ['Train', 'Test']
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=figsize, dpi=dpi, facecolor="#eeeeee")
        
        for idx, col in enumerate(prob_cols):
            # 绘制训练集PR曲线
            self._plot_single_pr_curve(ax1, train_stats.get(col), plot_title = plot_title[0], pr_title = col, idx = idx)
            # 绘制测试集PR曲线
            self._plot_single_pr_curve(ax2, test_stats.get(col), plot_title = plot_title[-1], pr_title = col, idx = idx)

        # plt.tight_layout()
        plt.show()
        save_path = self._get_valid_path(f"PR_curve")
        fig.savefig(save_path)
        plt.close(fig)
        # print(f"PR曲线保存路径：{save_path}")


    def _plot_single_pr_curve(self, ax, stats: Dict, plot_title: str, pr_title: str, idx: int = 0):
        """私有方法：绘制单数据集PR曲线"""
        if stats:
            recall = stats['tpr_list']
            pred_precision = stats['pred_precision']
            base_prob = stats['base_prob']

            # 计算F1最优值（原逻辑保留）
            f1 = 0.0
            minv1, minv2 = -np.inf, np.inf
            r1, r2, p1, p2 = -1, -1, -1, -1
            
            for x, y in zip(recall, pred_precision):
                xydif = x - y
                if (xydif > minv1) and (xydif < 0) and (x != 0 and y != 0):
                    minv1 = xydif
                    r1, p1 = x, y
                elif (xydif < minv2) and (xydif >= 0) and (x != 0 and y != 0):
                    minv2 = xydif
                    r2, p2 = x, y

            if r1 == -1 and r2 == -1:
                f1 = 0
            elif r1 == -1:
                f1 = r2
            elif r2 == -1:
                f1 = r1
            elif r2 != r1:
                a = (p2 - p1) / (r2 - r1) if (r2 - r1) != 0 else 0
                b = p2 - a * r2
                f1 = b / (1 - a) if a != 1 else p2
            else:
                f1 = r1
            colors = ["darkslategrey", 'brown', "darkgreen"]
            pr_color, base_prob_color, f1_color = colors if idx == 0 else [None, None, None]
            # 绘图
            ax.plot(recall, pred_precision, label=f'(bestF1: {f1:.2%}  baseP: {base_prob:.2%})-PR-{str(pr_title)}', color = pr_color, lw = 0.9,)
            ax.plot(recall, recall, linestyle='--', lw=1.0, color = '#ff7f0e')
            ax.axhline(y=f1, linestyle='--', lw=0.4, color = f1_color)
            ax.axhline(y=base_prob, linestyle='--', lw=0.4, color = base_prob_color)
            if idx == 0:
                ax.annotate(f'baseP-{str(pr_title)}({base_prob:.2%})', xy=(0.5, base_prob), xytext=(0, 10), textcoords='offset points', fontsize=11)
                ax.annotate(f'bestF1-{str(pr_title)}({f1:.2%})', xy=(f1, f1), xytext=(-10, 20), textcoords='offset points', fontsize=11)
        
        ax.set_title(f"{plot_title} PR曲线", fontsize=14, fontweight='bold')
        ax.set_xlabel('召回率(Recall)')
        ax.set_ylabel('精确率(Precision)')
        ax.set_xlim([0.0, 1.0])
        ax.set_ylim([0.0, 1.0])
        ax.legend()


    def plot_prob_total(self, pred_bins_train: pd.DataFrame, pred_bins_test: pd.DataFrame, 
        rot: int = 15, figsize:Tuple = (16, 6), dpi:int = 100):
        """
        绘制分箱样本占比+正样本率分布图
        :param pred_bins_train: 训练集分箱混淆矩阵结果（含interval/TOTR/posRate列）
        :param pred_bins_test: 测试集分箱混淆矩阵结果（同结构）
        :param rot: x轴标签旋转角度
        """
        fig, ax = plt.subplots(figsize = figsize, dpi = dpi, facecolor="#eeeeee")
        # 提取数据
        intervals  = pred_bins_train['interval'].values
        train_totr = pred_bins_train['totPct'].values
        test_totr  = pred_bins_test['totPct'].values
        train_pos_rate = pred_bins_train['binPosRate'].values
        test_pos_rate  = pred_bins_test['binPosRate'].values

        # 绘制样本占比柱状图
        x = np.arange(len(intervals))
        width = 0.3
        ax.bar(x, train_totr, width=width, color='#FF6347', align='center', label='Train-totPct')
        ax.bar(x + width, test_totr, width=width, color='#708090', align='center', label='Test-totPct')
        
        # 绘制正样本率折线图
        ax2 = ax.twinx()
        ax2.plot(x, train_pos_rate, marker='o', linestyle='--', color='#DC143C', label='Train-binPosRate')
        ax2.plot(x, test_pos_rate, marker='o', linestyle='--', color='#008080', label='Test-binPosRate')
        
        # 样式设置
        ax.set_ylim(0, max(max(train_totr), max(test_totr)) * 4)
        ax2.set_ylim(-max(max(train_pos_rate), max(test_pos_rate)) * 0.2, 
                     max(max(train_pos_rate), max(test_pos_rate)) * 1.2)
        ax2.grid(False)
        ax.tick_params(axis='x', labelrotation=rot)
        ax.legend(loc='upper right', bbox_to_anchor=(0.48, 1))
        ax2.legend(loc='upper right', bbox_to_anchor=(0.68, 1))

        # 添加数值标签
        offset = len(x)/20*0.3
        for a, b in zip(x, train_totr):
            ax.text(a, b + 0.001, f'{b:.1%}', ha='center', va='bottom', fontsize=8, color='#696969')
        for a, b in zip(x, test_totr):
            ax.text(a + 0.4, b + 0.001, f'{b:.1%}', ha='center', va='bottom', fontsize=8, color='#696969')
        for a, b in zip(x, train_pos_rate):
            ax2.text(a - offset, b, f'{b:.1%}', ha='center', va='bottom', fontsize=9, color='#8B0000')
        for a, b in zip(x, test_pos_rate):
            ax2.text(a + offset, b, f'{b:.1%}', ha='center', va='bottom', fontsize=9, color='#008080')

        plt.xticks(x, labels = intervals)
        plt.suptitle("Prob_Dist_Total", fontsize = 14, fontweight = 'bold')
        # plt.tight_layout()
        plt.show()
        save_path = self._get_valid_path(f"prob_dist_total")
        fig.savefig(save_path)
        plt.close(fig)
        # print(f"prob_dist_total保存路径：{save_path}")

    def plot_prob_binary(self, pred_bins_train: pd.DataFrame, pred_bins_test: pd.DataFrame, 
        rot: int = 15, figsize:Tuple = (16, 6), dpi:int = 100):
        """
        绘制分箱TPR/FPR概率分布图
        :param pred_bins_train: 训练集分箱结果（含interval/TPR/FPR列）
        :param pred_bins_test: 测试集分箱结果（同结构）
        :param rot: x轴标签旋转角度
        """
        fig, ax = plt.subplots(figsize=figsize, dpi=dpi, facecolor="#eeeeee")
        # 提取数据
        intervals = pred_bins_train['interval'].values
        train_tpr = pred_bins_train['posPct'].values
        test_tpr  = pred_bins_test['posPct'].values
        train_fpr = pred_bins_train['negPct'].values
        test_fpr  = pred_bins_test['negPct'].values

        # 绘制柱状图
        x = np.arange(len(intervals))
        width = 0.2
        ax.bar(x, train_tpr, width=width, color='#DC143C', align='center', label='Train-posPct')
        ax.bar(x + width, test_tpr, width=width, color='#DB7093', align='center', label='Test-posPct')
        ax.bar(x + 2*width, train_fpr, width=width, color='#708090', align='center', label='Train-negPct')
        ax.bar(x + 3*width, test_fpr, width=width, color='#C0C0C0', align='center', label='Test-negPct')

        # 样式设置
        max_val = max(max(train_tpr), max(test_tpr), max(train_fpr), max(test_fpr))
        ax.set_ylim(0, max_val + 0.1)
        ax.tick_params(axis='x', labelrotation=rot)
        ax.legend(loc='best')

        # 添加数值标签
        for a, b in zip(x, train_tpr):
            ax.text(a, b, f'{b:.1%}', ha='center', fontsize=6)
        for a, b in zip(x, test_tpr):
            ax.text(a + width, b, f'{b:.1%}', ha='center', fontsize=6)
        for a, b in zip(x, train_fpr):
            ax.text(a + 2*width, b, f'{b:.1%}', ha='center', fontsize=6)
        for a, b in zip(x, test_fpr):
            ax.text(a + 3*width, b, f'{b:.1%}', ha='center', fontsize=6)

        plt.xticks(x, labels=intervals)
        plt.suptitle("Prob_Dist_Binary", fontsize=14, fontweight='bold')
        # plt.tight_layout()
        plt.show()
        save_path = self._get_valid_path(f"prob_dist_binary")
        fig.savefig(save_path)
        plt.close(fig)
        # print(f"prob_dist_binary保存路径：{save_path}")


