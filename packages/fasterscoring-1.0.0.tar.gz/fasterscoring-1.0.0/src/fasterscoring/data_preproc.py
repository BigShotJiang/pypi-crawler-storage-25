# -*- coding: utf-8 -*-
"""
数据预处理 (Data Pre-processor Module)
=============================================
版本: 1.0.0
作者: Faster Scoring Team XM
功能: 评分卡建模前的数据标准化、分位数计算、描述性统计
依赖:
    pandas >= 1.2.0, numpy >= 1.20.0, scipy >= 1.6.0, tqdm >= 4.60.0
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Union, Optional, Any, Callable
import scipy.stats as sts
import time
import warnings
from fasterscoring.general_utils import *
import ipywidgets
if ipywidgets.__version__ > "7.8.5":
    from tqdm import tqdm
else:
    from tqdm.auto import tqdm

# 忽略非关键警告
warnings.filterwarnings('ignore')


class DataPreprocessor:
    """
    评分卡建模数据预处理核心类
    核心能力：
    1. 数据类型标准化（空值填充、分类变量编码、数值化）
    2. 变量描述性统计（数值型/分类型）
    3. 统计结果可视化、空值分析
    4. 自动统计核心方法执行耗时
    """

    def __init__(
        self,
        x_cols_desc: Dict[str, str] = {},
        fill_null_value: Any = np.nan,
        special_vals_dict: Dict[str, List[Any]] = None,
        label_mapping: Dict[str, int] = None,
        precision: int = 6,
        verbose: bool = False
    ):
        """
        初始化预处理配置
        
        Parameters
        ----------
        x_cols_desc : Dict[str, str], default={}
            变量描述 {列名: '描述文字'} 自变量的说明信息，数据字典
        fill_null_value : Any, default=np.nan
            空值填充的占位符（如-9999）
        special_vals_dict : Dict[str, List[Any]], optional
            特殊值保留字典 {列名: [特殊值列表]}，这些值不参与编码
        label_mapping : Dict[str, int], optional
            因变量标签映射，默认 {'positive':1, 'negative':0}
            'positive' 表示设置为正类的标记值
            'negative' 表示设置为负类的标记值
        precision : int, default=6
            数值精度（保留小数位数）
        verbose : bool, default=False
            是否打印详细日志（耗时、处理详情、剔除字段等）
        """
        # 基础配置
        self.x_cols_desc = x_cols_desc
        self.fill_null_value = fill_null_value
        self.special_vals_dict = special_vals_dict or {}
        self.label_mapping = label_mapping or {'positive': 1, 'negative': 0}
        self.precision = precision if precision is not None else 6
        self.verbose = verbose

        # 存储处理结果（含耗时统计）
        self.results: Dict[str, Any] = {
            'time_cost': {},          # 方法耗时统计
            'conversion_info': {},    # 数据转换信息
            'stats_info': []          # 变量统计信息
        }

    # ------------------------------ 全局耗时统计装饰器 ------------------------------
    def _timeit(func: Callable) -> Callable:
        """
        全局装饰器：统计类方法/函数执行耗时（适配类实例属性）
        
        Parameters
        ----------
        func : Callable
            被装饰的方法/函数
        
        Returns
        -------
        Callable
            包装后的方法/函数
        """
        def wrapper(*args, **kwargs):
            # 从参数中提取类实例self（类方法第一个参数为self）
            self = args[0] if args and hasattr(args[0], '__class__') else None
            start_time = time.time()
            
            # 执行原方法/函数
            result = func(*args, **kwargs)
            
            # 计算耗时并处理日志/存储
            cost = time.time() - start_time
            if self:
                # 类实例方法：存储耗时到results，按verbose打印
                if not hasattr(self, 'results'):
                    self.results = {'time_cost': {}}  # 初始化results
                if 'time_cost' not in self.results:
                    self.results['time_cost'] = {}
                
                self.results['time_cost'][func.__name__] = cost
                
                # 按实例的verbose配置打印
                if hasattr(self, 'verbose') and self.verbose:
                    print(f">>>>>>> [{func.__name__}] 耗时：{cost:6.4f}秒")
            else:
                # 普通函数：降级打印
                print(f">>>>>>> 函数 [{func.__name__}] 耗时：{cost:6.4f}秒")
            
            return result
        return wrapper

    def _category_encoding(self, col_name: str, col_vals: np.ndarray, y_col: str, df: pd.DataFrame) -> Dict[str, Any]:
        """
        私有工具：分类变量按正类率排序编码
        
        Parameters
        ----------
        col_name : str
            变量名
        col_vals : np.ndarray
            变量值数组
        y_col : str
            标签列名
        df : pd.DataFrame
            原始数据集
        
        Returns
        -------
        Dict[str, Any]
            编码结果字典：
            - encoded_vals: 编码后的值
            - code_to_origin: 编码值→原值映射
            - origin_to_code: 原值→编码值映射
            - is_over_limit: 是否因唯一值过多被剔除
            - instructions: 编码说明
        """
        # 初始化返回结果
        result = {
            "encoded_vals": [],
            "code_to_origin": [],
            "origin_to_code": {},
            "is_over_limit": False,
            "instructions": []
        }

        unique_vals = unique_list(col_vals.tolist())
        null_special_vals = self.special_vals_dict.get(col_name, []) + [self.fill_null_value]

        # 唯一值超过阈值则标记剔除
        if len(unique_vals) > self.max_unique_thresh:
            result["is_over_limit"] = True
            return result

        # 计算每个类别正类率
        sort_items = []
        pos_label = self.label_mapping['positive']
        neg_label = self.label_mapping['negative']

        # 有效标签总数（用于计算类别占比）
        valid_label_total = len(df[y_col][df[y_col].isin([pos_label, neg_label])])

        for val in unique_vals:
            if val in null_special_vals:
                sort_items.append((val, -np.inf))
            else:
                # 筛选当前类别对应的标签
                mask = col_vals == val
                label_vals = df[y_col].values.astype(float)[mask]
                total = len(label_vals)
                pos_count = len(label_vals[label_vals == pos_label])
                neg_count = len(label_vals[label_vals == neg_label])

                # 类别占有效标签比例
                cate_ratio = (pos_count + neg_count) / valid_label_total if valid_label_total > 0 else 0

                if cate_ratio >= self.min_cate_ratio:
                    pos_rate = round(pos_count / (pos_count + neg_count) if (pos_count + neg_count) > 0 else 0, 6)
                    sort_items.append((val, pos_rate))
                else:
                    sort_items.append((val, -1))

        # 按正类率排序
        sort_items.sort(key=lambda x: x[1])

        # 生成编码映射
        seq_num = 0
        for origin, rate in sort_items:
            if origin in null_special_vals:
                code = float(origin)
                encoded_name = str(origin)
            else:
                code = seq_num + 1 if rate >= 0 else -1
                encoded_name = str(code)
                if rate >= 0:
                    seq_num += 1

            # 记录映射关系和编码说明
            result["code_to_origin"].append((code, origin))
            result["origin_to_code"][origin] = code
            s_trunc_col, fmt_col = format_str(str(col_name), 80)
            s_trunc_val, fmt_val = format_str(str(origin), 40)
            result["instructions"].append(
                f"{s_trunc_col:<{fmt_col}s} == {s_trunc_val:<{fmt_val}s} ==> {encoded_name:<10s}"
            )

        # 应用编码
        result["encoded_vals"] = [result["origin_to_code"].get(x, x) for x in col_vals]
        return result

    # ------------------------------ 核心数据转换方法 ------------------------------
    @_timeit  # 添加耗时统计装饰器
    def ana_convert_data(
        self,
        df: pd.DataFrame,
        x_cols_list: List[str] = [],
        ylabel: str = None,
        other_columns: List[str] = [],
        x_cols_type: Dict[str, str] = {},
        need_encoding_cols: List[str] = [],
        max_unique_thresh: int = 50,
        min_cate_ratio: float = 0.03,
        null_fill_mode: Optional[str] = None
    ) -> Tuple[pd.DataFrame, List[str], Dict[str, Any]]:
        """
        数据类型标准化：空值填充、分类变量编码、数值化，剔除无效变量
        
        Parameters
        ----------
        df : pd.DataFrame
            原始数据集
        x_cols_list : List[str], default=[]
            自变量（特征）列名列表
        ylabel : str, default=None
            因变量（标签）列名（分类编码时使用）
        other_columns : List[str], default=[]
            需保留的其他列列表
        x_cols_type : Dict[str, str], default={}
            变量类型指定 {列名: 'numeric'/'category'}
        need_encoding_cols : List[str], default=[]
            需要按正类率编码的分类变量列表
        max_unique_thresh : int, default=50
            分类变量最大唯一值数（超过则剔除）
        min_cate_ratio : float, default=0.03
            分类值最小占比（低于则标记为-1）
        null_fill_mode : Optional[str], default=None
            空值填充策略：
            - 'map': 智能识别空值字符串（如'NULL'/'空'）
            - None: 直接填充fill_null_value
        
        Returns
        -------
        Tuple[pd.DataFrame, List[str], Dict[str, Any]]
            (清洗后的DataFrame, 有效自变量列表, 转换信息字典)
        """
        self.max_unique_thresh = max_unique_thresh
        self.min_cate_ratio = min_cate_ratio

        # 初始化结果容器
        result_dict = {}
        remove_cols = []
        over_limit_cols = []
        unable_numeric_cols = []
        code_to_origin = {}
        origin_to_code = {}
        infer_cols_type = {}
        encode_instructions = []

        # 校验标签列
        if ylabel:
            validate_cols(df, [ylabel], "标签列")
            result_dict[ylabel] = df[ylabel].values.astype(float) 

        # 1. 保留其他列和标签列
        for col in other_columns:
            if col in df.columns:
                result_dict[col] = df[col].values
            else:
                print(f"warning: df 缺失other_columns中列: {col}, 已忽略...")   

        # 2. 处理自变量
        with tqdm(x_cols_list, ascii=True, desc="特征变量转换") as pbar:
            for col in pbar:
                if col not in df.columns:
                    continue

                # 空值填充
                if null_fill_mode == 'map':
                    null_strs = {'NONE', 'NULL', 'NAN', 'MISSING', 'NAT', '', '-', '空', '\\N', str(self.fill_null_value)}
                    col_vals = df[col].apply(
                        lambda x: self.fill_null_value if pd.isna(x) or str(x).strip().upper() in null_strs else x
                    ).values
                else:
                    col_vals = df[col].fillna(self.fill_null_value).values

                # 变量类型判断
                col_type = x_cols_type.get(col)
                if col_type != "category" and col not in need_encoding_cols:
                    # 尝试数值化
                    try:
                        result_dict[col] = col_vals.astype(float)
                        infer_cols_type[col] = 'numeric' if col_type is None else col_type
                    except:
                        # 数值化失败则尝试分类编码
                        if not ylabel:
                            unable_numeric_cols.append(col)
                            continue
                        encode_res = self._category_encoding(col, col_vals, ylabel, df)
                        if encode_res["is_over_limit"]:
                            over_limit_cols.append(col)
                        else:
                            result_dict[col] = encode_res["encoded_vals"]
                            code_to_origin[col] = encode_res["code_to_origin"]
                            origin_to_code[col] = encode_res["origin_to_code"]
                            infer_cols_type[col] = 'category'
                            encode_instructions.extend(encode_res["instructions"])
                else:
                    # 分类变量编码
                    try:
                        if col in need_encoding_cols and ylabel is not None:
                            encode_res = self._category_encoding(col, col_vals, ylabel, df)
                            if encode_res["is_over_limit"]:
                                over_limit_cols.append(col)
                            else:
                                result_dict[col] = encode_res["encoded_vals"]
                                code_to_origin[col] = encode_res["code_to_origin"]
                                origin_to_code[col] = encode_res["origin_to_code"]
                                infer_cols_type[col] = 'category'
                                encode_instructions.extend(encode_res["instructions"])
                        else:
                            # 直接数值化
                            result_dict[col] = col_vals.astype(float)
                            infer_cols_type[col] = 'category' if col_type is None else col_type
                    except Exception as e:
                        if self.verbose:
                            print(f"变量 {col} 编码失败：{e}")
                        unable_numeric_cols.append(col)
                        continue

        # 组装结果
        output_df = pd.DataFrame(result_dict)
        valid_x_cols_list = [col for col in x_cols_list if col in output_df.columns]
        remove_cols = [col for col in x_cols_list if col not in valid_x_cols_list]

        # 转换信息字典
        self.results['conversion_info'] = {
            "infer_cols_type": infer_cols_type,
            "valid_x_cols_list": valid_x_cols_list,
            "code_to_origin": code_to_origin,
            "origin_to_code": origin_to_code,
            "remove_cols": remove_cols,
            "unable_numeric_cols": unable_numeric_cols,
            "over_limit_cols": over_limit_cols,
            "encode_instructions": encode_instructions
        }

        # 打印日志
        if self.verbose:
            if over_limit_cols:
                print('\n-----')
                print(f'以下是唯一值个数 > {max_unique_thresh} 的分类型变量：')
                for col in over_limit_cols:
                    col_desc = self.x_cols_desc.get(col)
                    display_name = f"{col}: {col_desc}" if col_desc else col
                    print(display_name)

            print(f"\n输出表字段数量  : {len(output_df.columns)}")
            print(f"清洗前自变量数量: {len(x_cols_list)}")
            print(f"清洗后自变量数量: {len(valid_x_cols_list)}")
            print(f"移除自变量个数: {len(x_cols_list) - len(valid_x_cols_list)}")

        return output_df, valid_x_cols_list, self.results['conversion_info']


    @_timeit  # 添加耗时统计装饰器
    def regular_convert_data(
        self,
        df: pd.DataFrame,
        x_cols_list: List[str] = [],
        ylabel: str = None,
        other_columns: List[str] = [],
        x_origin_to_code: Dict[str, Dict[Any, Any]] = {},
        null_fill_mode: Optional[str] = None
        ) -> Tuple[pd.DataFrame]:
        """
        数据类型标准化：空值填充、按提供的编码转换
        
        Parameters
        ----------
        df : pd.DataFrame
            原始数据集
        x_cols_list : List[str], default=[]
            自变量（特征）列名列表
        other_columns : List[str], default=[]
            需保留的其他列列表
        x_origin_to_code: Dict[str, Dict[Any, Any]], default={}
            分类变量编码映射 {列名: {原值: 填充值}}
        null_fill_mode : Optional[str], default=None
            空值填充策略：
            - 'map': 智能识别空值字符串（如'NULL'/'空'）
            - None: 直接填充fill_null_value
        
        Returns
        -------
        Tuple[pd.DataFrame, List[str], Dict[str, Any]]
            (转换的DataFrame)
        """
        result_dict = {}
        validate_cols(df, list(x_cols_list), "一般性数据转换自变量")
        if (x_origin_to_code is not None) and (not isinstance(x_origin_to_code, dict)):
            raise TypeError(f"x_origin_to_code 必须是字典类型或None，当前类型：{type(x_origin_to_code)}")
            
        # 1. 保留其他列和标签列
        for col in other_columns:
            if col in df.columns:
                result_dict[col] = df[col].values

        # 2. 处理自变量
        with tqdm(x_cols_list, ascii=True, desc="特征变量转换") as pbar:
            for col in pbar:
                # 空值填充
                if null_fill_mode == 'map':
                    null_strs = {'NONE', 'NULL', 'NAN', 'MISSING', 'NAT', '', '-', '空', '\\N', str(self.fill_null_value)}
                    col_series = df[col].apply(
                        lambda x: np.nan if pd.isna(x) or (str(x).strip().upper() in null_strs) else x
                    )
                else:
                    col_series = df[col]
                null_mask = col_series.isna()
                col_series = col_series.fillna(self.fill_null_value)
                # 应用编码映射
                if isinstance(x_origin_to_code, dict) and (col in x_origin_to_code):
                    fill_map = x_origin_to_code[col]
                    if isinstance(fill_map, dict) and fill_map:
                        # 匹配则替换，未匹配则-1
                        col_series = col_series.map(fill_map)
                        # 只有非原始空值的 NaN（即未匹配）才填 -1
                        col_series = col_series.mask(~null_mask & col_series.isna(), -1)
                result_dict[col] = col_series.values
        # 组装结果
        output_df = pd.DataFrame(result_dict)
        return output_df


    # ------------------------------ 描述性统计方法 ------------------------------
    @_timeit  # 添加耗时统计装饰器
    def var_desc_stats(
        self,
        df: pd.DataFrame,
        x_cols_list: List[str] = None,
        x_cols_type: Dict[str, str] = None,
        x_origin_to_code: Optional[Dict[str, Dict[Any, Any]]] = None,
    ) -> List[Any]:
        """
        变量描述性统计：数值型/分类型变量分别计算统计指标
        
        Parameters
        ----------
        df : pd.DataFrame
            待统计数据集
        x_cols_list : List[str], default=[]
            需统计的自变量列表
        x_cols_type : Dict[str, str], default={}
            变量类型 {列名: 'numeric'/'category'}
        x_origin_to_code: Dict,
            分类型自变量做数字型转化编码映射字典，格式：{变量名：{原值：替换值}}
            若x_column为分类型变量且df为未做编码前数据则需要传入。
        Returns
        -------
        List[Any]
            统计结果列表：[[变量名, 类型, [(统计项, 统计值), ...]], ...]
        """
        x_cols_list = x_cols_list or []
        x_cols_type = x_cols_type or {}
        validate_cols(df, x_cols_list, "描述性统计变量列")
        if (x_cols_type is not None) and (not isinstance(x_cols_type, dict)):
            raise TypeError(f"x_cols_type 必须是字典类型，当前类型：{type(x_cols_type)}")
        if (x_origin_to_code is not None) and (not isinstance(x_origin_to_code, dict)):
            raise TypeError(f"x_origin_to_code 必须是字典类型或None，当前类型：{type(x_origin_to_code)}")

        # 统计项模板
        NUM_STATS = ['count', 'unique', 'avg', 'std', 'min', 'max', '25%', '50%', '75%',
                     'null_cnt', 'null_rate', 'spec_cnt', 'spec_rate', 'mode_val', 'mode_cnt', 'mode_rate',
                     '3std_cnt', '3std_rate', '3IQR_cnt', '3IQR_rate']
        CAT_STATS = ['count', 'unique', 'null_cnt', 'null_rate', 'spec_cnt', 'spec_rate'] + [f'code{i+1}' for i in range(20)]

        x_cols_type = x_cols_type if x_cols_type else self.results.get('conversion_info',{}).get('infer_cols_type',{})

        stats_result = {}
        with tqdm(x_cols_list, ascii=True, desc="变量描述性统计") as pbar:
            for col in pbar:
                # 基础信息
                col_desc = self.x_cols_desc.get(col)
                col_type = x_cols_type.get(col, 'category')
                special_vals = self.special_vals_dict.get(col, [])
                null_mask = df[col].isna()
                col_data  = df[col].fillna(self.fill_null_value)
                if isinstance(x_origin_to_code, dict) and (col in x_origin_to_code):
                    fill_map = x_origin_to_code[col]
                    if isinstance(fill_map, dict) and fill_map:
                        # 匹配则替换，未匹配则-1
                        col_data = col_data.map(fill_map)
                        # 只有非原始空值的 NaN（即未匹配）才填 -1
                        col_data = col_data.mask(~null_mask & col_data.isna(), -1)

                # 空值统计
                total = len(col_data)
                null_mask = (col_data == self.fill_null_value) | pd.isna(col_data)
                null_cnt  = null_mask.sum()
                null_rate = null_cnt / float(total) if total > 0 else 0.0

                spec_mask = col_data.isin(special_vals)
                spec_cnt  = spec_mask.sum()
                spec_rate = spec_cnt / float(total) if total > 0 else 0.0

                # 有效数据（剔除空值）
                valid_data = col_data[(~null_mask) & (~spec_mask)]

                # 数值型统计
                if col_type == 'numeric':
                    try:
                        valid_num = valid_data.astype(float)
                    except:
                        if self.verbose:
                            print(f"变量 {col} 无法数值化，按分类处理")
                        col_type = 'category'

                if col_type == 'numeric':
                    if len(valid_num) > 0:
                        # 基础统计
                        unique_cnt = len(np.unique(valid_num))
                        avg = np.average(valid_num)
                        std = np.std(valid_num, ddof=1) if len(valid_num) > 1 else 0.0
                        min_val = np.min(valid_num)
                        max_val = np.max(valid_num)

                        # 分位数
                        percentiles = calculate_quantiles(valid_num, [0.25, 0.5, 0.75], precision = self.precision, unique = False) or [0, 0, 0]

                        # 众数
                        mode_res = sts.mode(valid_num[valid_num != self.fill_null_value])
                        mode_val = mode_res.mode
                        mode_cnt = mode_res.count

                        # 2. 如果是数组 → 取第一个元素；如果是标量 → 直接用
                        if isinstance(mode_val, np.ndarray):
                            mode_val = mode_val[0] if mode_val.size > 0 else 0.0
                        if isinstance(mode_cnt, np.ndarray):
                            mode_cnt = mode_cnt[0] if mode_cnt.size > 0 else 0

                        # 3. 转成普通数字
                        mode_val = float(mode_val)
                        mode_cnt = int(mode_cnt)
                        mode_rate = mode_cnt / float(total) if total > 0 else 0.0

                        # 3σ异常值
                        std_low = avg - 3 * std
                        std_high = avg + 3 * std
                        std_out_cnt = len(valid_num[(valid_num < std_low) | (valid_num > std_high)])
                        std_out_rate = std_out_cnt / float(total) if total > 0 else 0.0

                        # 3IQR异常值
                        q1, q2, q3 = percentiles
                        iqr = q3 - q1
                        iqr_low = q1 - 3 * iqr
                        iqr_high = q3 + 3 * iqr
                        iqr_out_cnt = len(valid_num[(valid_num < iqr_low) | (valid_num > iqr_high)])
                        iqr_out_rate = iqr_out_cnt / float(total) if total > 0 else 0.0

                    else:
                        unique_cnt = avg = std = min_val = max_val = q1= q2 = q3 = mode_val = mode_cnt = 0
                        mode_rate = std_out_cnt = std_out_rate = iqr_out_cnt = iqr_out_rate = 0
                        null_cnt = total
                        null_rate = 1.0
                    # 组装结果
                    num_vals = [total, unique_cnt, avg, std, min_val, max_val,
                                q1, q2, q3, null_cnt, null_rate, spec_cnt, spec_rate, mode_val, mode_cnt,
                                mode_rate, std_out_cnt, std_out_rate, iqr_out_cnt, iqr_out_rate]
                    col_stats = list(zip(NUM_STATS, num_vals))

                # 分类型统计
                else:
                    if len(valid_data) > 0:
                        cate_counts = valid_data.groupby(valid_data).count().sort_index(ascending=True)
                        unique_cnt = len(cate_counts)
                        code_cates = cate_counts.index.tolist()
                        code_cnts  = cate_counts.values
                        code_rates = [cnt / total if total > 0 else 0.0 for cnt in code_cnts]
                    else:
                        unique_cnt = 0
                        code_cates = []
                        code_cnts  = []
                        code_rates = []

                    # 分类处理
                    code_list = []
                    code_mapping = self.results['conversion_info'].get('code_to_origin', {}).get(col, [])
                    for idx, code in enumerate(code_cates):
                        origin_val = code
                        matched = [v for k, v in code_mapping if k == code]
                        if matched:
                            origin_val = f"{code}: ({','.join(map(str, matched))})"
                        code_list.append([origin_val, str(code_cnts[idx]), f"{code_rates[idx]:.2%}"])

                    # 组装结果
                    CAT_STATS = ['count', 'unique', 'null_cnt', 'null_rate', 'spec_cnt', 'spec_rate'] + [f'code{idx+1}' for idx in range(len(code_list))]
                    cat_vals = [total, unique_cnt, null_cnt, null_rate, spec_cnt, spec_rate] + code_list
                    col_stats = list(zip(CAT_STATS, cat_vals))

                # 保存统计结果
                stats_result[col] = {
                "col_desc": col_desc,
                "col_type": col_type,
                "col_stats": col_stats,
                }

        # 保存统计结果到实例属性
        self.results['stats_info'] = stats_result
        return self.results['stats_info']

    # ------------------------------ 统计结果可视化 ------------------------------
    def desc_summary(self, x_cols_list: List[str] = None, stats_info: Optional[Dict[str, Any]] = None) -> None:
        """
        格式化打印变量统计结果
        
        Parameters
        ----------
        x_cols_list: List[str]，可以筛选的变量名
        stats_info : Optional[Dict[str, Any]], default=None
            统计结果列表（默认使用类内存储的stats_info）
        """
        stats_info = stats_info or self.results['stats_info']
        if not stats_info:
            print("无统计结果可打印")
            return
        if x_cols_list:
            valid_columns = unique_list(x_cols_list)
        else:
            valid_columns = stats_info.keys()
        for var_col in valid_columns:
            data = stats_info.get(var_col)
            if data:
                var_desc  = data.get('col_desc')
                var_type  = data.get('col_type')
                var_stats = data.get('col_stats')
                print("\n" + "="*50)
                display_name = f"{var_col} ({var_type})" if not var_desc else f"{var_col}:{var_desc} ({var_type})"
                print(display_name)        
                print("-"*50)
                if var_type == 'numeric':
                    for stat_name, stat_val in var_stats:
                        display_val = round(stat_val, 4) if isinstance(stat_val, (int, float)) else stat_val
                        print(f"{stat_name:<12s}: {display_val}")
                else:
                    for stat_name, stat_val in var_stats:
                        if isinstance(stat_val, list):
                            cate_val, cnt_val, rate_val = stat_val
                            s_trunc, fmt_len = format_str(str(cate_val), 12)
                            print(f"{stat_name:<12s}: {s_trunc:^{fmt_len}s} | {cnt_val:^10s} | {rate_val:^10s}")
                        else:
                            print(f"{stat_name:<12s}: {stat_val}")
                print("="*50)

 
    def analyze_null(self, stats_info: Optional[Dict[str, Any]] = None) -> None:
        """
        分析空值率分布
        
        Parameters
        ----------
        stats_info : Optional[List[Any]], default=None
            统计结果列表（默认使用类内存储的stats_info）
        """
        stats_info = stats_info or self.results['stats_info']
        if not stats_info:
            print("无统计结果可分析")
            return

        # 提取空值统计
        null_stats_list = []
        for var_info in stats_info.items():
            null_items = list(filter(lambda x: x[0] in ['null_cnt', 'null_rate'], var_info[-1].get('col_stats',[(0,0)])))
            if null_items:
                null_stats_list.append(null_items)

        # 按空值率区间统计
        for thresh in np.arange(0.05, 1.05, 0.05):
            low_count = len([x for x in null_stats_list if x[-1][-1] < thresh])
            high_count = len(null_stats_list) - low_count
            print(f"缺失率 < {thresh:<4.0%} 的变量数: {low_count:<7d}  缺失率 >= {thresh:<4.0%} 的变量数: {high_count:<7d}")

