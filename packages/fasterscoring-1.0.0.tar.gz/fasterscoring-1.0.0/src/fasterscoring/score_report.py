# -*- coding: utf-8 -*-
"""
评分模型报告输出模块 (Model Report Module)
=============================================
版本信息：v1.0.0
作者: Faster Scoring Team XM
功能说明：
1. 输出评分卡EXCEL
2. 输出模型可视化结果EXCEL
3. 输出模型评估矩阵信息EXCEL
4. 输出变量分箱详情EXCEL
5. 输出相关系数矩阵EXCEL
6. 输出变量描述性统计EXCEL
"""
import os
import pandas as pd
import numpy as np
import xlsxwriter
import warnings
import ipywidgets
from typing import Dict, List, Tuple, Union, Optional, Any, Callable
if ipywidgets.__version__ > "7.8.5":
    from tqdm import tqdm
else:
    from tqdm.auto import tqdm

# 忽略非关键警告
warnings.filterwarnings('ignore')


class ScoreCardReporter:
    """
    评分卡自动化报告生成器
    功能：描述统计、评分卡、模型指标、特征详情、特征重要性、相关系数、可视化图表
    """
    _FORMAT_MAP = {
        'int': '#,##0',
        'float': '0.000',
        '%': '0.00%',
        'str': '0',
        'float4': '0.0000'
        }

    def __init__(self,
        file_name: str, 
        x_cols_desc: Optional[Dict[str, str]] = None,
        file_save_path: str = None,
        plot_save_path: str = None,
        font: str = None,
        tab_color: str = None,
        header_bg_color: str = None,
        header_font_color: str = None,
        bg_primary: str = None,
        bg_secondary: str = None,
        bg_ternary: str = None,
        ):
        """
        初始化报告生成器
        :param output_path: 输出Excel文件路径
        """
        self.x_cols_desc = x_cols_desc or {}
        self.file_save_path = file_save_path if file_save_path is not None else os.path.join(".", "ftsmodel", "report")
        os.makedirs(self.file_save_path, exist_ok = True)  # 创建保存目录
        self.file_name = file_name
        self.workbook = xlsxwriter.Workbook(os.path.join(self.file_save_path, file_name))
        self.plot_save_path = plot_save_path if plot_save_path is not None else os.path.join(".", "ftsmodel", "plot")
        self.font = "Arial" if font is None else font
        self.tab_color = "#FFE6D9"  if tab_color is None else tab_color                         # 工作表标签颜色 浅橘粉色
        self.header_bg_color = "#003366" if header_bg_color is None else header_bg_color        # 表头背景色 中性灰
        self.header_font_color = "#FCFCFC" if header_font_color is None else header_font_color  # 表头文字颜色  超浅灰（接近纯白）
        self.bg_primary = "#FFFFFF" if bg_primary is None else bg_primary                       # 基础背景色 (默认行) 纯白色 表格偶数行背景
        self.bg_secondary = "#F5F5F5" if bg_secondary is None else bg_secondary                 # 隔行变色 (交替行)   极浅灰 表格奇数行背景 (隔行变色)
        self.bg_ternary = "#F8F8FF" if bg_ternary is None else bg_ternary                       # 特征详情专用背景色  极浅蓝 / 淡天蓝色 表格奇数行背景 (隔行变色)
        self.info_ws = None

    def save(self) -> None:
        """保存并关闭Excel文件（必须调用）"""
        print(f"文件保存路径: {os.path.join(self.file_save_path, self.file_name)}")
        self.workbook.close()

    def _cell_format(self, **kwargs) -> xlsxwriter.format.Format:
        """内部通用格式生成器"""
        base = {
            "font_name": self.font,
            "font_size": 9,
            "align": "center",
            "valign": "vcenter",
            "text_wrap": False,
            "top": 3,     # 虚线
            "bottom": 3,  # 虚线
            "left": 3,    # 虚线
            "right": 3,   # 虚线
        }
        base.update(kwargs)
        return self.workbook.add_format(base)

    def _header_format(self, **kwargs) -> xlsxwriter.format.Format:
        """内部通用格式生成器"""
        base = {
            "font_name": self.font,
            'font_color': self.header_font_color,
            "font_size": 11,
            'bold':True,
            "align": "center",
            "valign": "vcenter",
            'top':6, 
            'bottom':6,
            'left':1,
            'right':1,
            'bg_color': self.header_bg_color
        }
        base.update(kwargs)
        return self.workbook.add_format(base)

    def _col_type(self, x_name):
        if str(x_name).strip().lower().endswith(('cnt', 'seq')):
            return "int"
        elif str(x_name).strip().lower().endswith(('pct', 'rto', 'rate')):
            return "%"
        elif str(x_name).strip().lower().endswith(('lift', 'woe', 'ks', 'iv', 'r', 'acc', 'f1', 'auc', 'psi')):
            return "float"
        else:
            return "str"

    # ==========================================================================
    # 1. 描述统计工作表
    # ==========================================================================
    def add_var_desc_sheet(
        self,
        describe_info: List[Tuple[str, str, List[Tuple[str, Any]]]],
        x_cols_list:List = None,
        ) -> None:
        """
        创建数值/分类变量描述统计表
        :param describe_info: 变量描述性信息列表 [(变量名, 类型, 统计值列表)]
        """
        FIELDS_TYPE = {
        'variable': 'str', 'count': 'int', 'unique': 'int', 'avg':'float', 'std':'float', 
        'min':'float', 'max':'float', '25%':'float', '50%':'float', '75%':'float',
        'null_cnt': 'int', 'null_rate': '%', 'spec_cnt': 'int', 'spec_rate': '%', 'mode_val': 'float', 
        'mode_cnt': 'int', 'mode_rate': '%','3std_cnt':'int', '3std_rate': '%', '3IQR_cnt': 'int', 
        '3IQR_rate': '%'
        }

        header_fmt = self.workbook.add_format({
        'font_name': self.font, 'font_size': 9, 'bold': True,
        'align': 'center', 'valign': 'vcenter', 'top': 1, 'bottom': 1
        })
        if x_cols_list:
            describe_info = {key: value for key, value in describe_info.items() if key in x_cols_list}
        NUMERIC_HEADERS  = []
        CATEGORY_HEADERS = []
        numeric_data  = []
        category_data = []
        for idx, item in enumerate(describe_info.items()):
            col_field = item[0]
            col_desc  = self.x_cols_desc.get(col_field)
            col_name  = f"{col_field}:{col_desc}" if pd.notna(col_desc) else str(col_field)
            col_type  = item[1].get('col_type')
            sts_data  = item[1].get('col_stats')
            sts_keys  = [irow[0] for irow in sts_data]
            sts_vals  = [irow[1] for irow in sts_data]
            if col_type == 'numeric':
                numeric_data.append([col_name] + sts_vals)
                if len(NUMERIC_HEADERS) - 1 < len(sts_keys):
                    NUMERIC_HEADERS = ['variable'] + sts_keys
            if col_type == 'category':
                category_data.append([col_name] + sts_vals)
                if len(CATEGORY_HEADERS) - 1 < len(sts_keys):
                    CATEGORY_HEADERS = ['variable'] + sts_keys

        # 写入数值型变量表
        if numeric_data:
            ws = self.workbook.add_worksheet("numDesc")
            ws.set_tab_color(self.tab_color)
            ws.hide_gridlines(2)
            ws.set_column(0, 0, 18)
            ws.set_column(1, len(NUMERIC_HEADERS), 8)
            ws.set_row(0, 25)
            ws.write_row(0, 0, NUMERIC_HEADERS, header_fmt)

            with tqdm(numeric_data, ascii=True, desc = "写入数值型变量描述性统计") as pbar:
                for row_idx, row_data in enumerate(pbar):
                    bg = self.bg_secondary if idx % 2 else self.bg_primary
                    for col_idx, val in enumerate(row_data):
                        field = NUMERIC_HEADERS[col_idx]
                        fmt = FIELDS_TYPE.get(field,'str')
                        num_fmt = self._FORMAT_MAP.get(fmt, "0")
                        if col_idx == 0:
                            align = "left"
                        else:
                            align = "center"
                        cell_fmt = self._cell_format(bg_color = bg, font_size = 8, 
                            num_format = num_fmt, align = align, text_wrap = False)
                        ws.write(row_idx + 1, col_idx, val, cell_fmt)

        # 写入分类型变量表
        if category_data:
            ws = self.workbook.add_worksheet("catDesc")
            ws.set_tab_color(self.tab_color)
            ws.hide_gridlines(2)
            ws.set_column(0, 0, 18)
            ws.set_column(1, len(CATEGORY_HEADERS), 8)
            ws.set_row(0, 25)
            ws.write_row(0, 0, CATEGORY_HEADERS, header_fmt)
            
            with tqdm(category_data, ascii=True, desc="写入分类型变量描述性统计") as pbar:
                for row_idx, row_data in enumerate(pbar):
                    bg = self.bg_secondary if idx % 2 else self.bg_primary
                    for col_idx, field in enumerate(CATEGORY_HEADERS):
                        val = row_data[col_idx] if col_idx < len(row_data) else ""
                        fmt = FIELDS_TYPE.get(field,'str')
                        if isinstance(val, list):
                            val = "\n".join(map(str,val))
                            text_wrap = True
                        else:
                            text_wrap = False
                        if col_idx == 0:
                            align = "left"
                        else:
                            align = "center"
                        num_fmt = self._FORMAT_MAP.get(fmt, "0")
                        cell_fmt = self._cell_format(bg_color = bg, align = align, font_size = 8, 
                            num_format = num_fmt, text_wrap = text_wrap)
                        ws.write(row_idx + 1, col_idx, val, cell_fmt)


    # ==========================================================================
    # 2. 评分卡工作表
    # ==========================================================================
    def add_scorecard_sheet(
        self,
        var_bins_score: Dict[str, Dict],
        model_params: Dict,
        ) -> None:
        """
        创建逻辑回归评分卡表
        :param feature_names: 入模变量列表
        :param bin_scores: 分箱得分 {特征名: {分箱: 分数}}
        :param model_params: 模型参数 coef/pvalues/conf_int
        :param base_score: 基础分数
        """
        if not isinstance(var_bins_score, dict):
            raise TypeError(f"var_bins_score 必须是字典类型，当前类型：{type(var_bins_score)}")
        
        if not isinstance(model_params, dict):
            raise TypeError(f"model_params 必须是字典类型，当前类型：{type(model_params)}")

        variable = model_params.get("variable", [])
        if len(variable) == 0:
            raise ValueError(f"model_params中variable为空")

         # 检查分数映射字典的完整性
        missing_score_cols = [col for col in variable if col not in var_bins_score]
        if missing_score_cols:
            raise KeyError(f"以下变量在var_bins_score无分数映射字典：{missing_score_cols}")

        ws = self.workbook.add_worksheet("scoreCard")
        ws.set_tab_color(self.tab_color)
        ws.hide_gridlines(2)
        ws.set_column(2, 2, 5)
        ws.set_column(3, 3, 50)
        ws.set_column(8, 8, 20)
        ws.set_row(3, 12)
        ws.set_row(4, 18)

        title_fmt = self.workbook.add_format({
            'font_name': self.font, 'font_size': 14, 'bold': True, 'align': 'center', 'valign': 'vcenter'
            })
        header_fmt = self._header_format(font_size=11)
        cell_fmt = self._cell_format(font_size=9, text_wrap = True)

        headers = ["序号", "变量", "系数", "P-Value", "[0.025", "0.975]", "区间", "得分"]
        feature_names = ["截距"] + list(variable)
        coef = model_params.get("coef", [])
        pvalues = model_params.get("pvalues", [])
        conf_int = model_params.get("conf_int", [])

        ws.merge_range(2, 2, 2, 9, "逻辑回归评分卡", title_fmt)
        ws.write_row(4, 2, headers, header_fmt)

        row_idx = 5
        with tqdm(feature_names, ascii=True, desc="写入模型各变量评分卡详情") as pbar:
            for idx, var in enumerate(pbar):
                c = round(coef[idx], 4) if idx < len(coef) else 0
                p = round(pvalues[idx], 4) if idx < len(pvalues) else 0
                ci = [round(x, 4) for x in conf_int[idx]] if idx < len(conf_int) else [0.0, 0.0]
                var_desc = self.x_cols_desc.get(var)
                var_name = f"{var}:{var_desc}" if pd.notna(var_desc) else str(var)
                model_data = [idx, var_name, c, p, ci[0], ci[1]]

                if var == "截距":
                    scores = [var_bins_score.get('basescore',{}).get('None', 0)]
                    intervals = ["-"]
                else:
                    try:
                        var_score = var_bins_score[var]
                        intervals = list(var_score.keys())
                        scores = list(var_score.values())
                    except KeyError:
                        print(f"变量{var}评分数据缺失")
                        intervals, scores = ["-"], [0]

                interval_cnt = len(intervals)
                for col_idx, val in enumerate(model_data):
                    if interval_cnt > 1:
                        ws.merge_range(row_idx, col_idx + 2, row_idx + interval_cnt - 1, col_idx + 2, val, cell_fmt)
                    else:
                        ws.write(row_idx, col_idx + 2, val, cell_fmt)

                for i, (itv, score) in enumerate(zip(intervals, scores)):
                    bg = self.bg_secondary if (row_idx - 5 + i) % 2 else self.bg_primary
                    cell_fmt2 = self._cell_format(bg_color = bg)
                    ws.write(row_idx + i, 8, str(itv), cell_fmt2)
                    ws.write(row_idx + i, 9, score, cell_fmt2)
                row_idx += interval_cnt


    # ==========================================================================
    # 3. 模型结果表 + KS/分布图表
    # ==========================================================================
    def add_model_rts_sheet(
        self,
        pred_bins_sts: pd.DataFrame,
        pred_confusion_sts: Dict[str, Any],
        pred_psi_info: Dict[str, float],
        data_type: str = "train",
    ) -> None:
        """
        创建模型评分分布表 + KS图 + 样本分布图
        :param pred_bins_sts: 评分分箱分析结果DataFrame
        :param pred_confusion_sts: 评分混淆矩阵统计结果
        “param pred_psi_info: 评分在训练与测试集上PSI统计信息
        :param data_type: 数据集类型 train/test
        """
        ws = self.workbook.add_worksheet(f"{data_type}Rts")
        ws.set_tab_color(self.tab_color)
        ws.hide_gridlines(2)
        ws.set_column(0, 0, 5)
        ws.set_column(1, 1, 16)
        # ws.set_column(10, 17, 9)
        ws.set_row(7, 18)

        cut_points = pred_confusion_sts['cut_points']
        ks_list = pred_confusion_sts.get("ks_list", [])
        ks  = np.max(ks_list)
        ks_idx = np.argmax(ks_list)
        ks_val = cut_points[ks_idx]
        auc    = pred_confusion_sts.get("auc", 0)
        gini   = pred_confusion_sts.get("gini", 0)

        psi_text = [f"PSI({key}):{val:.4f}" for key, val in pred_psi_info.items()]

        TotCnt = pred_bins_sts["totCnt"].sum()
        NegCnt = pred_bins_sts["negCnt"].sum()
        PosCnt = pred_bins_sts["posCnt"].sum()
        GraCnt = pred_bins_sts["graCnt"].sum()



        text_fmt = self.workbook.add_format({'font_name': self.font, 'font_size': 11, 'bold': True, 'align': 'left', 'valign': 'vcenter'})
        ws.write(1, 0, f"{str(data_type)} Data", text_fmt)
        ws.write(2, 0, f"样本总数(Tot)：{TotCnt:.0f}，负类(Neg)：{NegCnt:.0f}，正类(Pos)：{PosCnt:.0f}，灰类(Gra)：{GraCnt:.0f}", text_fmt)
        ws.write(3, 0, "Model Report", text_fmt)
        ws.write(4, 0, f"KS : {ks:.4f} (cutoff: {ks_val}),  AUC: {auc:.4f},  Gini: {gini:.4f}", text_fmt)
        ws.write(5, 0, f"{',  '.join(psi_text)}", text_fmt)


        cols_list = pred_bins_sts.columns.tolist()
        header_fmt = self._header_format(font_size = 8)
        ws.write_row(7, 0, cols_list, header_fmt)

        with tqdm(pred_bins_sts.iterrows(), ascii=True, total=len(pred_bins_sts), desc=f"写入{data_type}评分分箱评估分布") as pbar:
            for row_idx, (_, row_data) in enumerate(pbar):
                bg = self.bg_secondary if row_idx % 2 else self.bg_primary
                for col_idx, value in enumerate(row_data):
                    fmt_type = self._col_type(cols_list[col_idx])
                    num_fmt = self._FORMAT_MAP.get(fmt_type, "0.000")
                    cell_fmt = self._cell_format(font_size = 8, align = "center", bg_color = bg, num_format = num_fmt)
                    ws.write(row_idx + 8, col_idx, value, cell_fmt)

        self._add_ks_chart(ws, pred_bins_sts, 7, 0, data_type)
        self._add_bin_dist_chart(ws, pred_bins_sts, 7, 0, data_type)


    def _add_ks_chart(
        self,
        ws: xlsxwriter.worksheet.Worksheet,
        df: pd.DataFrame,
        row_start: int,
        col_start: int,
        dtype: str
    ) -> None:
        """添加KS曲线图（深色主题）"""
        chart = self.workbook.add_chart({"type": "line"})
        colors = {"cumNegPct": "#0080FF", "cumPosPct": "#FF5809", "KS": "#00BB00"}
        cat_idx = df.columns.get_loc("interval") + col_start
        max_ks = round(df["KS"].max(), 4)
        n_data = len(df)

        for key, color in colors.items():
            val_idx = df.columns.get_loc(key) + col_start
            chart.add_series({
                "name": [ws.name, row_start, val_idx],
                "categories": [ws.name, row_start + 1, cat_idx, row_start + n_data, cat_idx],
                "values":     [ws.name, row_start + 1, val_idx, row_start + n_data, val_idx],
                "line": {"color": color, "width": 1.5, 'dash_type': 'solid'},
                "marker": {"type": "none"},
                'data_labels': {'value': False, 'num_format': '#,##0.00','font': {'name': 'Consolas', 'color': '#FCFCFC'},},
            })

        chart.set_title({"name": f"{dtype} Data KS = {max_ks:6.4f}", 'name_font': {'size': 14, 'bold': True, 'color':'#E0E0E0'}})
        chart.set_x_axis({'name': 'Pred Score', 'name_font': {'size': 11, 'bold': True, 'color':'#E0E0E0'}, 
                         'num_font': {'size': 9, 'color': '#E0E0E0','rotation': -45},
                         'major_gridlines': {'visible': True, 'line': {'color':'#5B5B5B', 'width': 1, 'dash_type': 'solid'}}})
        chart.set_y_axis({'name': 'Accumulative Rate','name_font': {'size': 11, 'bold': True, 'color':'#E0E0E0'},
                          'min': 0, 'max': 1, 'num_format': "0.00", 'num_font': {'size': 9,'color': '#E0E0E0',}})
        chart.set_plotarea({'gradient': {'colors': ['#3C3C3C', '#4F4F4F', '#5B5B5B']}, 'layout': {'x': 0.13, 'y':  0.16, 'width':  0.79, 'height': 0.57,}})
        chart.set_chartarea({'border': {'none': True}, 'fill': {'color': '#4F4F4F'}})
        chart.set_legend({'position': 'top',  'font': {'size': 10, 'bold': True, 'color':'#E0E0E0'}
         #'layout': {'x': 0.33, 'y': 0.06, 'width': 0.33, 'height': 0.12,}
        })
        chart.set_size({"width": 690, "height": 495})
        ws.insert_chart(row_start + 1 + n_data, col_start, chart, {'x_offset': 25, 'y_offset': 0})

    def _add_bin_dist_chart(
        self,
        ws: xlsxwriter.worksheet.Worksheet,
        df: pd.DataFrame,
        row_start: int,
        col_start: int,
        dtype: str
    ) -> None:
        """添加分箱样本占比+正样本率组合图"""
        col_chart = self.workbook.add_chart({"type": "column"})
        line_chart = self.workbook.add_chart({"type": "line"})
        n_data = len(df)

        cat_idx = df.columns.get_loc("interval") + col_start
        tot_idx = df.columns.get_loc("totPct") + col_start
        pos_idx = df.columns.get_loc("binPosRate") + col_start

        col_chart.add_series({
            "categories": [ws.name, row_start + 1, cat_idx, row_start + n_data, cat_idx],
            "values":     [ws.name, row_start + 1, tot_idx, row_start + n_data, tot_idx],
            'name': 'totPct',
            'fill': {'color': '#93CDDD'},
            'data_labels':{'value': True, 'position': 'inside_end'},
        })
        line_chart.add_series({
            "values": [ws.name, row_start + 1, pos_idx, row_start + n_data, pos_idx],
            'name': 'binPosRate',
            'marker': {'type': 'diamond', 'size': 7},
            'data_labels': {'value': True, 'position': 'outside_end', 'font': {'color': '#E46C0A'}},
            'y2_axis': True,
        })
        col_chart.combine(line_chart)
        # 设置图表的title 和 x，y轴信息
        col_chart.set_title({'name': f'{dtype} Data: 模型预测评分 分布图', 'name_font': {'size' : 12}})

        col_chart.set_x_axis({'major_gridlines': {'visible': False} })
        col_chart.set_y_axis({'name': 'totPct','major_gridlines': {'visible': False},})
        col_chart.set_y2_axis({'name': 'binPosRate','max' : 1,'min' : 0,'major_gridlines': {'visible': False},})
        col_chart.set_legend({'position': 'top',  'font': {'size': 10, 'bold': True,}})
        # 设置图表大小
        width = 30 * n_data
        width = 690 if width < 690 else width
        col_chart.set_size({'width': width, 'height': 495})
        # 把图表插入到worksheet并设置偏移
        ws.insert_chart(row_start + 1 + n_data, col_start + 11, col_chart, {'x_offset': 25, 'y_offset': 0})   


    # ==========================================================================
    # 4. 特征变量信息表 + 图表
    # ==========================================================================
    def add_var_list_sheet(self, var_info_df: pd.DataFrame, var_name: str = None) -> None:
        """
        创建特征变量信息表
        :param var_info_df: 特征变量信息DataFrame
        """
        cols_list = var_info_df.columns.tolist()
        ws = self.workbook.add_worksheet("varList")
        self.info_ws = ws
        ws.set_tab_color(self.tab_color)
        ws.hide_gridlines(2)
        ws.set_row(0, 18)
        ws.set_column(0, 0, 7)
        ws.set_column(1, 1, 44)
        ws.set_column(2, 2, 12)
        var_name = var_name or "variable"
        header_fmt = self._header_format(font_size = 11)
        ws.write_row(0, 0, cols_list, header_fmt)

        for row_idx in tqdm(range(len(var_info_df)), ascii=True, desc = "写入变量信息价值排序列表"):
            bg = self.bg_secondary if row_idx % 2 else self.bg_primary
            for col_idx in range(len(cols_list)):
                val = var_info_df.iloc[row_idx, col_idx]
                col_field = cols_list[col_idx]
                fmt_type = self._col_type(col_field)
                num_fmt = self._FORMAT_MAP.get(fmt_type, "0.000")
                if col_field == var_name:
                    align = "left"
                    val_desc  = self.x_cols_desc.get(val)
                    val  = f"{val}:{val_desc}" if pd.notna(val_desc) else str(val)
                else:
                    align = "center"
                fmt = self._cell_format(font_size=9, align=align, bg_color=bg, num_format=num_fmt)
                ws.write(row_idx + 1, col_idx, val, fmt)
        self._add_var_info_chart(ws, var_info_df)


    def _add_var_info_chart(self, ws: xlsxwriter.worksheet.Worksheet, var_info_df: pd.DataFrame) -> None:
        """添加特征重要性水平条形图"""
        chart = self.workbook.add_chart({"type": "bar"})
        n_data = len(var_info_df)
        chart.add_series({
            "name": [ws.name, 0, 2],
            "categories": [ws.name, 1, 1, n_data, 1],
            "values": [ws.name, 1, 2, n_data, 2],
            'bar': {'color': '#0080FF', 'width': 1, 'dash_type': 'solid'},
            'marker': {'type': 'none'},
            'data_labels': {'value': True, 'num_format': '0.0000', 'font': {'name': 'Consolas', 'color': '#FCFCFC', 'size': 8}},
            })

        # 设置图表的title 和 x，y轴信息
        chart.set_title({'name': "Feature Information", 'name_font': {'size': 14, 'bold': True, 'color':'#E0E0E0'},})
        chart.set_x_axis({'num_font': {'size': 9, 'color': '#E0E0E0','rotation': 0},
                          'major_gridlines': {'visible': True, 'line': {'color':'#5B5B5B', 'width': 1, 'dash_type': 'solid'}},
                        })
        chart.set_y_axis({'num_format': "0.00",'num_font': {'size': 8,'color': '#E0E0E0',},
                          'major_gridlines': {'visible': True, 'line': {'color':'#5B5B5B', 'width': 1, 'dash_type': 'solid'}},
                          'reverse': True,
                        })
        if n_data > 10:
            plotarea_y = 4/n_data
            chartSize_h = 20 * (n_data + 1)
        else:
            plotarea_y = 0.4
            chartSize_h = 200
        plotarea_h = 0.96 - plotarea_y
        # 设置图表大小
        chart.set_size({'width':780, 'height': chartSize_h })
        # 绘图区域填充颜色，位置
        chart.set_plotarea({
            'gradient': {'colors': ['#3C3C3C', '#4F4F4F', '#5B5B5B']},
            'layout': {'x': 0.25, 'y':  plotarea_y, 'width':  0.7, 'height': plotarea_h,}
            })
        # 设置series图例位置,字体
        chart.set_legend({
            'position': 'top',
            'font': {'size': 12, 'bold': True, 'color':'#E0E0E0'}
            #'layout': {'x': 0.33, 'y': 0.06, 'width': 0.33, 'height': 0.12,}
            })
        # 设置图表外部填充
        chart.set_chartarea({'border': {'none': True},'fill': {'color': '#4F4F4F'}})
        # 把图表插入到worksheet并设置偏移
        ws.insert_chart('D1', chart, {'x_offset': 25, 'y_offset': 10})



    # ==========================================================================
    # 5. 特征详情表（WOE+分布+超链接）
    # ==========================================================================
    def add_var_detail_sheet(
        self,
        x_cols_list: List[str],
        train_var_bins_sts: Dict[str, pd.DataFrame],
        test_var_bins_sts: Dict[str, pd.DataFrame],
    ) -> None:
        """
        创建所有特征详情（WOE、分箱、超链接）
        :param x_cols_list: 特征变量名称列表
        :param train_var_bins_sts: 训练集WOE数据
        :param test_var_bins_sts: 测试集WOE数据
        """
        ws = self.workbook.add_worksheet("varDetails")
        ws.set_tab_color(self.tab_color)
        ws.hide_gridlines(2)
        ws.set_column(0, 0, 5)
        ws.set_column(1, 1, 15)
        ws.set_column(2, 9, 7)
        ws.set_column(18, 21, 7)
        ws.set_column(24, 27, 7)

        row_idx = 0
        for var_idx, variable in enumerate(tqdm(x_cols_list, ascii=True, desc="写入变量分箱评估详情分布")):
            var_desc = self.x_cols_desc.get(variable)
            var_name = f"{variable}:{var_desc}" if pd.notna(var_desc) else str(variable)
            self._write_single_fea_detail(ws, train_var_bins_sts[variable], "TrainData", var_name, row_idx, var_idx, back_url = True)
            row_idx += len(train_var_bins_sts[variable]) + 3 + 4

            self._write_single_fea_detail(ws, test_var_bins_sts[variable], "TestData", var_name, row_idx, var_idx, back_url = False)
            row_idx += len(test_var_bins_sts[variable]) + 2 + 7

    def _write_single_fea_detail(
        self,
        ws: xlsxwriter.worksheet.Worksheet,
        sts_data: List[List[Any]],
        dtype: str,
        variable: str,
        row_idx: int,
        var_idx: int,
        back_url: bool = True
    ) -> None:
        """写入单个特征详情（含超链接、图表）"""
        link_fmt1 = self.workbook.add_format({'font_name': self.font, 'font_size': 11, 'font_color': '#0066CC', 'bold':True,'align': 'left', 
                                              'valign':'vcenter', 'underline': True, 'italic': True, })
        bg = self.bg_secondary if var_idx % 2 else self.bg_primary
        link_fmt2 = self._cell_format(font_size=10, bg_color=bg, font_color = "#0066CC", bold = True, underline = True, italic = True)
        title_fmt = self.workbook.add_format({'font_name': self.font, 'font_size': 10, 'bold':True, 'border': 1,'align': 'center', 'valign':'vcenter'})
        header_fmt = self.workbook.add_format({'font_name': self.font, 'font_color': '#FCFCFC', 'font_size': 8, 'bold':True, 'top':6, 'bottom':6,
                                             'left':1, 'right':1, 'align':'center', 'valign':'vcenter', 'bg_color':'#708090' })
        headers = sts_data.columns.tolist()
        if back_url:
            ws.write_url(row_idx, 0, f"internal:{self.info_ws.name}!A{var_idx+2}:C{var_idx+2}", link_fmt1, string = "Back to Contents")
            ws.write_url(row_idx, len(headers), f"internal:{self.info_ws.name}!A{var_idx+2}:C{var_idx+2}", link_fmt1, string = "Back to Contents")
            self.info_ws.write_url(f"A{var_idx+2}", f"internal:{ws.name}!A{row_idx+3+len(sts_data)+2}", link_fmt2, string = f"{var_idx+1:0>2d}")
            row_idx += 1
        ws.merge_range(row_idx, 0, row_idx, len(headers)-1, f"{dtype}:{variable}", title_fmt)
        ws.write_row(row_idx+1, 0, headers, header_fmt)

        for idx_data, row_data in enumerate(sts_data.values):
            bg = self.bg_ternary if idx_data % 2 else self.bg_primary
            for idx, val in enumerate(row_data):
                fmt_type = self._col_type(headers[idx])
                num_fmt = self._FORMAT_MAP.get(fmt_type, "0.000")
                fmt = self._cell_format(font_size=8, align='center', bg_color=bg, num_format=num_fmt)
                ws.write(row_idx+2+idx_data, idx, val, fmt)

        self._add_woe_chart(ws, sts_data, dtype, variable, row_idx)
        self._add_bin_chart(ws, sts_data, dtype, variable, row_idx)

    def _add_woe_chart(
        self,
        ws: xlsxwriter.worksheet.Worksheet,
        sts_data: List[List[Any]],
        dtype: str,
        variable: str,
        row_start: int
    ) -> None:
        """添加WOE双色条形图（正橙负绿）"""
        chart = self.workbook.add_chart({"type": "bar"})
        headers = [str(icol).strip() for icol in sts_data.columns]
        woe_idx = headers.index("WOE")
        points = []
        for row in sts_data.values:
            color = "#FF5575" if row[woe_idx] >= 0 else "#6299FF"
            points.append({"fill": {"color": color}})

        chart.add_series({
            "values": [ws.name, row_start + 2, woe_idx, row_start + 1 + len(sts_data), woe_idx],
            "points": points,
            "data_labels": {"position": "outside_end"},
        })

        # 设置图表的title 和 x，y轴信息
        chart.set_title({'name': f" {dtype}: {variable} WOE分布趋势", 'name_font': {'size': 10, 'bold': True}})
        chart.set_x_axis({'max': 3, 'min': -3, 'visible': False, 'major_gridlines': {'visible': False}})
        chart.set_y_axis({'label_position': 'none', 'reverse': True, 'major_tick_mark': 'none'})
        # 设置series图例
        chart.set_legend({'none': True})
        # 设置图表大小
        chart.set_size({'width': 425, 'height': 12 * (len(sts_data) + 9)})
        # 把图表插入到worksheet并设置偏移
        ws.insert_chart(row_start, len(headers), chart, {'x_offset': 30, 'y_offset': 10})


    def _add_bin_chart(
        self,
        ws: xlsxwriter.worksheet.Worksheet,
        sts_data: List[List[Any]],
        dtype: str,
        variable: str,
        row_start: int
    ) -> None:
        """添加特征分箱样本占比+正样本率图"""
        col_chart = self.workbook.add_chart({"type": "column"})
        line_chart = self.workbook.add_chart({"type": "line"})
        headers = [str(icol).strip() for icol in sts_data.columns]
        n_data = len(sts_data)

        itv_idx = headers.index("interval")
        tot_idx = headers.index("totPct")
        pos_idx = headers.index("binPosRate")

        col_chart.add_series({
            "categories": [ws.name, row_start + 2, itv_idx, row_start + 1 + n_data, itv_idx],
            "values":     [ws.name, row_start + 2, tot_idx, row_start + 1 + n_data, tot_idx],
            "name": "totPct",
            "fill": {"color": "#1C86EE"},
            "data_labels":{"value": True, "position": "inside_end"},
        })
        line_chart.add_series({
            "values": [ws.name, row_start + 2, pos_idx, row_start + 1 + n_data, pos_idx],
            "name": "binPosRate",
            "marker": {"type": "diamond", "size": 6},
            "data_labels":{"value": True, "position": "above", "font": {"color": '#D65D48'}},
            "y2_axis": True,
        })
        col_chart.combine(line_chart)
        # 设置图表的title 和 x，y轴信息
        col_chart.set_title({'name': f'{dtype}: {variable} 分布图', 'name_font': {'size' : 10, 'bold': True}})
        col_chart.set_x_axis({'major_gridlines': {'visible': False}, 'num_font': {'size': 9}})
        col_chart.set_y_axis({'name': 'totPct','max' : 1, 'min' : 0, 'major_gridlines': {'visible': False}})
        col_chart.set_y2_axis({'name': 'binPosRate', 'max' : 1,  'min' : 0, 'major_gridlines': {'visible': False}})
        col_chart.set_legend({'position': 'right',  'font': {'size': 10, 'bold': True,}})
        col_chart.set_size({"width": 768, "height": 12 * (n_data + 9)})
        ws.insert_chart(row_start, len(headers) + 8, col_chart, {'x_offset': 0, 'y_offset': 10})



    # ==========================================================================
    # 6. 相关系数热力图
    # ==========================================================================
    def add_correlation_sheet(self, data_df: pd.DataFrame, x_cols_list: List[str]) -> None:
        """
        创建变量相关系数热力图
        :param data_df: 原始数据
        :param x_cols_list: 变量列表
        """
        x_cols_list = list(x_cols_list)
        n_cols = len(x_cols_list)
        corr_matrix = np.corrcoef(data_df[x_cols_list].values, rowvar=False)
        x_cols_list =  [f"{var}:{self.x_cols_desc.get(var)}" if pd.notna(self.x_cols_desc.get(var)) else str(var) for var in x_cols_list]

        ws = self.workbook.add_worksheet("varCorr")
        ws.set_tab_color(self.tab_color)
        ws.hide_gridlines(2)
        ws.set_row(0, 20)
        ws.set_column(0, 0, 35)
        ws.set_column(1, 1, 3)
        ws.set_column(2, n_cols+1, 2.4)
        x_cols_header = [f"{idx:0>2d}" for idx in range(1, n_cols+1)]
        color_list = [
        '#FFF3EE','#FFE6D9','#FFDAC8','#FFCBB3','#FFBD9D','#FFAD86','#FF9D6F','#FF8F59',
        '#FF8040','#FF5809','#F75000','#D94600','#BB3D00','#A23400','#842B00','#642100',
        ]
        step = 1.0001 / len(color_list)
        rows_fmt = self.workbook.add_format({'font_name': self.font, 'font_size': 8, 'align':'center', 'bold': True, 
                                             'valign':'vcenter','top':1, 'bottom':1, 'left':1, 'right':1,})
        cols_fmt = self.workbook.add_format({'font_name': self.font, 'font_size': 8, 'align':'right', 'valign':'vcenter'})

        ws.write_row(0, 2, x_cols_header, rows_fmt)
        ws.write_column(1, 0, x_cols_list, cols_fmt)
        ws.write_column(1, 1, x_cols_header, rows_fmt)

        with tqdm(range(n_cols), ascii=True, desc = '写入变量相关系数矩阵分布') as pbar:
            for i in pbar:
                for j in range(n_cols):
                    val = corr_matrix[i, j] if not np.isnan(corr_matrix[i, j]) else -999
                    level = int(abs(val) / step) if val != -999 else -1
                    bg = color_list[level]
                    fmt = self.workbook.add_format({'font_name':self.font, 'font_size': 6, 
                        'align':'center', 'valign':'vcenter', 'bg_color':bg, 'num_format':'0.00' })
                    ws.write(i + 1, j + 2, val, fmt)

        num_fmt = self.workbook.add_format({'font_name':self.font, 'font_size': 10, 'align':'center', 
            'valign':'vcenter', 'bold':True, 'underline': True, "num_format": "0.00"})
        ws.write(1 , n_cols + 3 , '±1.0', num_fmt)
        ws.write(2 + len(color_list), n_cols + 3 , '0.0', num_fmt)  
        for idx in range(len(color_list)):
            bg = color_list[-(idx + 1)]
            clo_fmt = self.workbook.add_format({'bg_color': bg})
            ws.write(2 + idx, n_cols + 3 , '', clo_fmt)


    # ==========================================================================
    # 7. 外部图片插入
    # ==========================================================================
    def add_image_sheet(self, image_info:list = None) -> None:
        """
        批量插入外部图片
        :param image_info: [(插入位置, 图片路径, x缩放, y缩放)]
        """
        image_info = image_info if image_info else [
        ('B2', os.path.join(self.plot_save_path, 'Train_ks_auc_gini.png'), 0.8, 0.8),
        ('B19', os.path.join(self.plot_save_path, 'Test_ks_auc_gini.png'), 0.8, 0.8),
        ('B36', os.path.join(self.plot_save_path, 'PR_curve.png'), 0.8, 0.8),
        ('B55', os.path.join(self.plot_save_path, 'prob_dist_total.png'), 0.8, 0.8),
        ('B78', os.path.join(self.plot_save_path, 'prob_dist_binary.png'), 0.8, 0.8),
        ]
        ws = self.workbook.add_worksheet("evalPlot")
        ws.set_tab_color(self.tab_color)
        ws.hide_gridlines(2)
        with tqdm(image_info, ascii=True, desc = '写入模型评分评估统计图表') as pbar:
            for pos, path, x_scale, y_scale in pbar:
                ws.insert_image(pos, path, {'x_scale': x_scale, 'y_scale': y_scale})


