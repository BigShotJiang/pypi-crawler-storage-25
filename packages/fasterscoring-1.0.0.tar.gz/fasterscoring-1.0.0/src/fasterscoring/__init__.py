# -*- coding: utf-8 -*-
"""
简述
=============================================
版本: 1.0.0
作者: Faster Scoring Team XM
功能: 基于逻辑回归更快速的评分卡建模，适配风控专用场景
"""

from .general_utils import *
from .data_preproc import *
from .faster_binner import *
from .variable_filter import *
from .stepwise_train import *
from .model_scoring import *
from .model_visualize import *
from .score_report import *

__version__ = "1.0.0"   # 版本号
__author__ = "Faster Scoring Team XM"