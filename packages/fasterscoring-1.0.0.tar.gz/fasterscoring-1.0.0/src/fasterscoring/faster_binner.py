# -*- coding: utf-8 -*-
"""
自变量快速分箱模块 (Faster Binning Module)
=============================================
版本: 1.0.0
作者: Faster Scoring Team XM
功能:
    1. 基于统计检验对自变量进行离散化处理
    2. 支持对分箱整体数据比例、pos_pct、neg_pct最低阈值约束
    2. 为了满足风控对自变量分布的解释性，支持自动对变量的单调、单折分布约束优化
依赖:
    pandas >= 1.2.0, numpy >= 1.20.0, scipy >= 1.6.0, tqdm >= 4.60.0
"""

import time
import warnings
from typing import Dict, List, Tuple, Union, Optional, Callable, Any
import numpy as np
import pandas as pd
import scipy.stats as sts
from fasterscoring.general_utils import *
import ipywidgets
if ipywidgets.__version__ > "7.8.5":
    from tqdm import tqdm
else:
    from tqdm.auto import tqdm

# 忽略非关键警告
warnings.filterwarnings('ignore')

__version__ = "1.0.0"
__author__ = "Faster Scoring Team XM"


class FasterBinner:
    """
    评分卡分箱器 - 封装完整的分箱流程（粗分箱+合并分箱）
    
    核心特性:
    --------
    1. 支持卡方/Z检验的贪心粗分箱
    2. 支持分箱合并为单调/U型分布（优化折点筛选逻辑）
    3. 完善的参数校验和异常处理
    4. 支持WOE值的软硬约束配置
    """
    
    def __init__(
        self,
        ylabel: str = None,
        label_mapping: Dict[str, int] = {'positive': 1, 'negative': 0},
        fill_null_value: Optional[Any] = np.nan,
        special_vals_dict: Optional[Dict[str, List[Any]]] = {},
        gen_r_limit: Optional[float] = 7,
        precision: int = 6,
        verbose: bool = True
    ):
        """
        初始化分箱器
        
        参数:
        --------
        ylabel : str
            因变量名称（标签列名）
        label_mapping : Dict[str, int]
            标签映射字典，{'positive': 正类值, 'negative': 负类值}
        fill_null_value : int
            空值占位符（如-9999）
        special_vals_dict : Dict[str, List[int]]
            特殊值字典，{'列名': [特殊值列表]}，例：{'age': [-1111, -7777]}
        gen_r_limit: 通用WOE软约束值
        precision : int
            数值精度（保留小数位数）
        verbose : bool
            是否打印详细日志（耗时、进度等）
        """
        # 基础配置
        self.ylabel = ylabel
        self.label_mapping = label_mapping
        self.fill_null_value = fill_null_value
        self.special_vals_dict = special_vals_dict
        self.gen_r_limit = gen_r_limit
        self.precision = precision
        self.verbose = verbose
        
        # 标签值初始化（兼容默认值）
        self.pos_label = label_mapping.get('positive', 1)
        self.neg_label = label_mapping.get('negative', 0)
        
        # 分箱结果存储（类内状态管理）
        self.raw_bins: Dict[str, np.ndarray] = {}  # 粗分箱结果
        self.final_bins: Dict[str, List[float]] = {}  # 最终合并分箱结果

# ------------------------------ 全局耗时统计装饰器 ------------------------------
    def _timeit(func: Callable) -> Callable:
        """
        全局装饰器：统计类方法/函数执行耗时（适配类实例属性）
        
        Parameters
        ----------
        func : Callable
            被装饰的方法/函数
        
        Returns
        -------
        Callable
            包装后的方法/函数
        """
        def wrapper(*args, **kwargs):
            # 从参数中提取类实例self（类方法第一个参数为self）
            self = args[0] if args and hasattr(args[0], '__class__') else None
            start_time = time.time()
            
            # 执行原方法/函数
            result = func(*args, **kwargs)
            
            # 计算耗时并处理日志/存储
            cost = time.time() - start_time
            if self:
                # 类实例方法：存储耗时到results，按verbose打印
                if not hasattr(self, 'results'):
                    self.results = {'time_cost': {}}  # 初始化results
                if 'time_cost' not in self.results:
                    self.results['time_cost'] = {}
                
                self.results['time_cost'][func.__name__] = cost
                
                # 按实例的verbose配置打印
                if hasattr(self, 'verbose') and self.verbose:
                    print(f">>>>>>> [{func.__name__}] 耗时：{cost:6.4f}秒")
            else:
                # 普通函数：降级打印
                print(f">>>>>>> 函数 [{func.__name__}] 耗时：{cost:6.4f}秒")
            
            return result
        return wrapper


    def _best_testing(
        self,
        x_array: np.ndarray,
        y_array: np.ndarray,
        interval: np.ndarray,
        pos_pct_min: float,
        neg_pct_min: float,
        tot_pct_min: float,
        test_type: str = 'chi2'
    ) -> Tuple[float, int]:
        """
        内部方法：遍历所有候选切点，返回检验统计量最高的切点
        
        参数:
        --------
        x_array : np.ndarray
            自变量数组
        y_array : np.ndarray
            因变量数组
        interval : np.ndarray
            候选切点列表
        pos_pct_min : float
            每箱最小pos_pct计数（绝对数）
        neg_pct_min : float
            每箱最小neg_pct计数（绝对数）
        tot_pct_min : float
            每箱最小总样本计数（绝对数）
        test_type : str
            检验类型，'chi2'：卡方检验，'Ztest'：双比率z检验
        
        返回:
        --------
        Tuple[float, int]: (最大检验统计量, 最优切点索引)
        """
        max_stats = 0.0
        best_index = -1
        
        # 过滤当前区间内的数据（仅处理interval范围内的样本）
        mask = (x_array > interval[0]) & (x_array <= interval[-1])
        y_filtered = y_array[mask]
        x_filtered = x_array[mask]
        
        # 遍历所有候选切点（跳过首尾极值）
        for i in range(1, len(interval) - 1):
            # 切分左右两侧样本
            mask_left  = x_filtered > interval[i]
            mask_right = x_filtered <= interval[i]
            
            y1 = y_filtered[mask_left]  # 左侧样本
            y2 = y_filtered[mask_right]  # 右侧样本
            
            # ========== 样本量校验（避免小样本导致检验失效） ==========
            d1 = len(y1)  # 左侧总样本数
            d2 = len(y2)  # 右侧总样本数
            if d1 <= tot_pct_min or d2 <= tot_pct_min:
                continue  # 样本量不足，跳过
            
            # 计算左右侧正/负类计数
            d1y1 = float(len(y1[y1 == self.pos_label]))  # 左侧正类数
            d1y0 = float(len(y1[y1 == self.neg_label]))  # 左侧负类数
            d2y1 = float(len(y2[y2 == self.pos_label]))  # 右侧正类数
            d2y0 = float(len(y2[y2 == self.neg_label]))  # 右侧负类数
            
            # 最小正/负类计数校验
            if d1y1 <= pos_pct_min or d2y1 <= pos_pct_min:
                continue
            if d1y0 <= neg_pct_min or d2y0 <= neg_pct_min:
                continue
            
            # ========== 检验统计量计算 ==========
            if test_type == 'chi2':
                # 卡方检验：构建列联表并计算卡方统计量
                obs = np.array([[d1y1, d2y1], [d1y0, d2y0]])  # 观测频数
                row_tot = obs.sum(axis=1)  # 行总计
                col_tot = obs.sum(axis=0)  # 列总计
                total = obs.sum()  # 总样本数
                
                # 计算期望频数（避免除零）
                expected = np.outer(row_tot, col_tot) / total
                expected[expected == 0] = 1e-10  # 防止除零错误
                
                # 卡方统计量
                chi2 = np.sum((obs - expected) ** 2 / expected)
                test_stats = chi2
                
            elif test_type == 'Ztest':
                # Z检验（双比率检验）
                p1 = d1y1 / d1 if d1 > 0 else 0.0  # 左侧正类率
                p2 = d2y1 / d2 if d2 > 0 else 0.0  # 右侧正类率
                p_pool = (d1y1 + d2y1) / (d1 + d2) if (d1 + d2) > 0 else 0.0  # 合并正类率
                
                # 计算标准误（避免除零）
                se = np.sqrt(p_pool * (1 - p_pool) * (1/d1 + 1/d2)) if (d1 + d2) > 0 else 1e-10
                if se < 1e-10:
                    se = 1e-10  # 防止除零错误
                
                # Z统计量
                z_score = abs((p1 - p2) / se)
                test_stats = z_score
            else:
                raise ValueError(f"不支持的检验类型：{test_type}，仅支持'chi2'/'Ztest'")
            
            # 更新最优切点
            if test_stats > max_stats:
                max_stats = test_stats
                best_index = i
        
        return (max_stats, best_index)
    
    def _testing_divide(
        self,
        x_array: np.ndarray,
        y_array: np.ndarray,
        interval: np.ndarray,
        pos_pct_min: float = 0.01,
        neg_pct_min: float = 0.01,
        tot_pct_min: float= 0.01,
        test_type: str = 'chi2',
        threshold: float = 3.84
    ) -> List[float]:
        """
        内部方法：递归分箱（贪心算法），基于检验统计量筛选最优分箱
        
        参数:
        --------
        x_array : np.ndarray
            自变量数组
        y_array : np.ndarray
            因变量数组
        interval : np.ndarray
            初始候选切点列表
        pos_pct_min : float
            每箱最小pos_pct计数，默认 0.01
        neg_pct_min : float
            每箱最小neg_pct计数，默认 0.01
        tot_pct_min : float
            每箱最小总样本计数，默认 0.01
        test_type : str
            检验类型，默认卡方检验
        threshold : float
            检验统计量阈值（超过则继续分箱）
        
        返回:
        --------
        List[float]: 分箱切点列表
        """
        bin_list = []
        
        # 获取最优切点和对应统计量
        max_stats, best_idx = self._best_testing(
            x_array, y_array, interval, pos_pct_min, neg_pct_min, tot_pct_min, test_type
        )
        
        # ========== 递归终止条件 ==========
        if max_stats < threshold:
            # 统计量未超过阈值，停止分箱，保留当前区间首尾
            bin_list.extend([interval[0], interval[-1]])
        else:
            # 统计量超过阈值，切分左右区间继续递归
            left_interval  = interval[(interval >= interval[0]) & (interval <= interval[best_idx])]
            right_interval = interval[(interval >= interval[best_idx]) & (interval <= interval[-1])]
            
            # 递归处理左右区间
            bin_list += self._testing_divide(
                x_array, y_array, left_interval, pos_pct_min, neg_pct_min, tot_pct_min, test_type, threshold
            )
            bin_list += self._testing_divide(
                x_array, y_array, right_interval, pos_pct_min, neg_pct_min, tot_pct_min, test_type, threshold
            )
        
        # 去重并返回
        return list(np.unique(bin_list))
    
    @_timeit
    def fit_raw_bins(
        self,
        df: pd.DataFrame,
        ylabel: str = None, 
        x_cols_list: List[str] = [],
        x_fit_type: Dict[str, str] = {},
        test_type: str = 'chi2',
        thre_alpha: float = 0.05,
        thre_pos_pct: float = 0.01,
        thre_neg_pct: float = 0.01,
        thre_tot_pct: float = 0.01,
        x_origin_to_code: Optional[Dict[str, Dict[Any, Any]]] = None,
    ) -> Dict[str, np.ndarray]:
        """
        拟合粗分箱：基于卡方/Z检验的贪心分箱，生成初始分箱切点
        分箱的自变量需要转换为数值型的有序数据，若为字符型、布尔型的
        需要提前做数据预处理
        
        参数:
        --------
        df : pd.DataFrame
            输入数据集
        x_cols_list : List[str]
            需分箱的自变量列表
        x_fit_type : Dict[str, str]
            自变量是否按检验标准分箱的配置字典 {'列名': 'test'/'raw'}
            'test' 表示按检验标准分箱，'raw'表示保留所有原值
        test_type : str
            检验类型，'chi2'（默认）/ 'Z-test'
        thre_alpha : float
            检验显著性水平（默认0.05）
        thre_pos_pct : float
            每箱pos_pct最小占比（相对总正类数，默认0.01）
        thre_neg_pct : float
            每箱neg_pct最小占比（相对总负类数，默认0.01）
        thre_tot_pct : float
            每箱总样本最小占比（相对总样本数，默认0.01）
        x_origin_to_code: dict,
            分类型自变量做数字型转化编码映射字典，格式：{变量名：{原值：替换值}}
            若x_column为分类型变量且df为未做编码前数据则需要传入。
        返回:
        --------
        Dict[str, np.ndarray]: 粗分箱结果字典，{列名: 分箱切点数组}
        """

        x_cols_list = list(x_cols_list)  # 确保是列表类型
        self.raw_bins = {}  # 初始化粗分箱结果
        ylabel  = self.ylabel if ylabel is None else ylabel
        if pd.isna(ylabel):
            raise ValueError(f"ylabel 不可为：{ylabel}")
        validate_cols(df, list(x_cols_list) + [ylabel], "分箱占比筛选数据集")
        if x_origin_to_code is not None and not isinstance(x_origin_to_code, dict):
            raise TypeError(f"x_origin_to_code 必须是字典类型或None，当前类型：{type(x_origin_to_code)}")
        # ========== 阈值预处理（转换为绝对计数） ==========
        y_array = df[ylabel].astype(float).values
        total_pos = len(y_array[y_array == self.pos_label])  # 总正类数
        total_neg = len(y_array[y_array == self.neg_label])  # 总负类数
        total_samples = len(y_array)  # 总样本数
        
        # 转换相对占比为绝对计数（避免小样本时阈值失效）
        pos_pct_min = total_pos * thre_pos_pct if total_pos > 0 else 1
        neg_pct_min = total_neg * thre_neg_pct if total_neg > 0 else 1
        tot_pct_min = total_samples * thre_tot_pct if total_samples > 0 else 1
        
        # 计算检验统计量阈值
        if test_type == 'chi2':
            test_threshold = sts.chi2.isf(thre_alpha, 1)  # 卡方检验阈值（自由度1）
        elif test_type == 'Ztest':
            alpha = 1 - thre_alpha / 2
            test_threshold = sts.norm.ppf(alpha)  # Z检验阈值
        else:
            raise ValueError(f"检验类型错误！仅支持'chi2'/'Ztest'，输入：{test_type}")
        
        # ========== 遍历变量分箱 ==========
        with tqdm(x_cols_list, ascii=True, desc="假设检验分箱") as pbar:
            for col in pbar:
                fit_type = x_fit_type.get(col, 'test')  # 默认test型
                special_vals = self.special_vals_dict.get(col, [])  # 该变量的特殊值
                null_mask  = df[col].isna()
                col_series = df[col].fillna(self.fill_null_value)
                if isinstance(x_origin_to_code, dict) and (col in x_origin_to_code):
                    fill_map = x_origin_to_code[col]
                    if isinstance(fill_map, dict) and fill_map:
                        # 匹配则替换，未匹配则-1
                        col_series = col_series.map(fill_map)
                        # 只有非原始空值的 NaN（即未匹配）才填 -1
                        col_series = col_series.mask(~null_mask & col_series.isna(), -1)
                # 数据预处理：填充空值为占位符
                x_array = col_series.values.astype(float)
                y_array = df[ylabel].astype(float).values
                # 提取特殊值+空值占位符
                null_special_vals = np.unique([self.fill_null_value] + list(special_vals))
                if fit_type == 'test':
                    # ========== 检验分箱 ==========
                    # 过滤特殊值/空值（单独处理）
                    mask = np.isin(x_array, null_special_vals) | pd.isna(x_array)
                    y_array = y_array[~mask]
                    x_array = x_array[~mask]
                    
                    # 生成初始候选切点
                    unique_vals = np.unique(x_array)
                    if len(unique_vals) >= 500:
                        # 唯一值过多，用等频分箱生成200个切点
                        init_cuts = calculate_quantiles(
                            x_array, n_bins=500, precision = self.precision, unique=True, include_extremes=False
                        )
                    else:
                        # 唯一值较少，直接使用去重后的值作为切点
                        init_cuts = unique_vals
                    
                    # 构建完整区间（添加极值边界）
                    full_interval = np.unique(np.concatenate([np.round(init_cuts, self.precision), [-np.inf, np.inf]]))
                    
                    # 递归分箱
                    bin_cuts = self._testing_divide(
                        x_array, y_array, full_interval,
                        pos_pct_min, neg_pct_min, tot_pct_min,
                        test_type, test_threshold
                    )
                    
                    # 合并特殊值/空值切点并排序
                    final_cuts = np.sort(np.unique(np.concatenate([bin_cuts, null_special_vals])))
                    self.raw_bins[col] = final_cuts
                
                else:
                    # ========== 保留所有原值 ==========
                    unique_vals = np.round(np.unique(x_array), self.precision)
                    final_cuts = np.sort(np.unique(np.concatenate([unique_vals[:-1], [-np.inf, np.inf], null_special_vals])))
                    self.raw_bins[col] = final_cuts

    
    def _exclude_min_value(
        self,
        pos_neg: List[Tuple[int, int]],
        total_pos_cnt: float,
        total_neg_cnt: float,
        col_dist_type: str,
        threshold: float = 0.1,
    ) -> Optional[int]:
        """
        核心合并策略：优先合并能最大减少折点的区间
        
        合并逻辑:
        --------
        1. 先合并相邻r差小于threshold的区间
        2. 再通过二阶差分找到分布的折点，筛选折点对应的左右一阶差分
        3. 比较每个差分结果对应的区间合并后能够减少折点的数量，取减少折点最多的一阶差分
        4. 如果减少折点最多的一阶差分个数不为1，则筛选最小一阶差分对应的索引
        
        参数:
        --------
        pos_neg : List[Tuple[int, int]]
            每箱的(pos_cnt, neg_cnt)统计结果列表
        total_pos_cnt : float
            总的pos_cnt数量
        total_neg_cnt : float
            总的neg_cnt数量 
        col_dist_type : str
            分布类型，'U'：U型，'L'：单调，'W'：无需合并
        threshold : float
            r值差异阈值（小于该值则合并）r = pos_pct/neg_pct
        
        返回:
        --------
        Optional[int]: 待合并的切点索引（None表示无需合并）
        """
        # ========== 基础计算：总pos_cnt/neg_cnt和r值列表 ==========
        # 计算每箱的r值（pos_pct/neg_pct）
        r_list = []
        for pos_cnt, neg_cnt in pos_neg:
            pos_pct = pos_cnt / total_pos_cnt if total_pos_cnt > 0 else 0.0
            neg_pct = neg_cnt / total_neg_cnt if total_neg_cnt > 0 else 0.0
            r, _, _, _ = weight_ratio(pos_pct, neg_pct, r_soft_limit = self.gen_r_limit)
            r_list.append(r)
        
        # ========== 内部辅助函数 ==========
        def _merge_bins(pos_neg_list: List[Tuple[int, int]], idx: int) -> List[Tuple[int, int]]:
            """合并指定索引的相邻箱"""
            merged_pos_neg = []
            # 合并idx和idx+1箱的pos_cnt/neg_cnt
            merged = tuple(np.array(pos_neg_list[idx]) + np.array(pos_neg_list[idx + 1]))
            # 构建合并后的列表
            for idx2, info in enumerate(pos_neg_list):
                if idx2 not in [idx, idx+1]:
                    merged_pos_neg.append(info)
                elif merged not in merged_pos_neg:
                    merged_pos_neg.append(merged)
            return merged_pos_neg
        
        def _diff_cal(r_vals: List[float]) -> Tuple[np.ndarray, np.ndarray]:
            """计算一阶/二阶差分，返回折点数组和一阶差分绝对值"""
            # 一阶差分（相邻r值变化）
            diff1d_arr = np.diff(r_vals)
            diff1d_abs = np.abs(diff1d_arr)
            # 方向标：0=上升，-1=下降
            direction = np.array([0 if x >= 0 else -1 for x in diff1d_arr])
            # 二阶差分（方向变化=折点）
            diff2d_arr = np.diff(direction)
            return diff2d_arr, diff1d_abs
        
        # ========== 主合并逻辑 ==========
        if col_dist_type != "W":
            # 计算初始差分
            diff2d_arr, diff1d_abs = _diff_cal(r_list)
            
            # 第一步：优先合并r值差异过小的区间
            if len(diff1d_abs) > 0:
                min_diff = min(diff1d_abs)
                if min_diff < threshold:
                    # 返回第一个最小差异的索引（+1对应切点位置）
                    min_index = np.where(diff1d_abs == min_diff)[0][0] + 1
                    return min_index
            
            # 第二步：处理多折分布（折点数量超过阈值）
            # 找到所有折点索引
            turn_point_indices = np.where(diff2d_arr != 0)[0]
            point_count = len(turn_point_indices)
            
            # 分布类型约束：U型允许1个折点，单调型不允许折点
            max_turn_points = 1 if col_dist_type == "U" else 0
            
            if point_count > max_turn_points:
                # 筛选折点对应的左右一阶差分索引
                diff1d_index = []
                for point in turn_point_indices:
                    diff1d_index.extend([point, point + 1])
                diff1d_index = np.unique(diff1d_index)
                
                # 计算每个候选索引合并后的折点数量
                point_residue = []
                for idx in diff1d_index:
                    # 合并指定索引的箱
                    merged_pos_neg = _merge_bins(pos_neg, idx)
                    # 重新计算合并后的r值
                    merged_r_list = []
                    for pos_cnt, neg_cnt in merged_pos_neg:
                        pos_pct = pos_cnt / total_pos_cnt if total_pos_cnt > 0 else 0.0
                        neg_pct = neg_cnt / total_neg_cnt if total_neg_cnt > 0 else 0.0
                        merged_r, _, _, _ = weight_ratio(pos_pct, neg_pct, r_soft_limit = self.gen_r_limit)
                        merged_r_list.append(merged_r)
                    # 计算合并后的折点数量
                    merged_diff2d, _ = _diff_cal(merged_r_list)
                    merged_point_count = len(merged_diff2d[merged_diff2d != 0])
                    point_residue.append(merged_point_count)
                
                # 找到折点减少最多的索引
                point_residue = np.array(point_residue)
                min_residue = min(point_residue)
                min_diff1_residue_idx = diff1d_index[point_residue == min_residue]
                
                # 确定最终合并索引
                if len(min_diff1_residue_idx) == 1:
                    # 折点减少最多的索引唯一
                    min_index = min_diff1_residue_idx[0] + 1
                else:
                    # 多个索引折点减少数相同，选一阶差分最小的
                    toward_abs = np.array([diff1d_abs[i] for i in min_diff1_residue_idx])
                    min_1d_idx = min_diff1_residue_idx[toward_abs == min(toward_abs)][0]
                    min_index = min_1d_idx + 1
                return min_index
            else:
                # 折点数量符合要求，无需合并
                return None
        else:
            # W型分布无需合并
            return None
    
    def _combine_bins(
        self,
        df: pd.DataFrame,
        ylabel: str,
        x_column: str,
        col_dist_type: str,
        bin_arr: List[float],
        threshold: float = 0.1,
        special_vals: List[int] = [],
        x_origin_to_code: Optional[Dict[str, Dict[Any, Any]]] = None,
    ) -> List[float]:
        """
        内部方法：递归合并分箱，使分箱满足单调/U型分布约束
        
        参数:
        --------
        df : pd.DataFrame
            输入数据集
        ylabel: str,
            因变量名
        x_column : str
            变量名
        col_dist_type : str
            分布类型，'U'：U型，'L'：单调，'W'：无需合并
        bin_arr : List[float]
            粗分箱切点列表
        threshold : float
            r值差异阈值
        special_vals : List[int]
            特殊值列表
        x_origin_to_code: dict,
            分类型自变量做数字型转化编码映射字典，格式：{变量名：{原值：替换值}}
            若x_column为分类型变量且df为未做编码前数据则需要传入。
        返回:
        --------
        List[float]: 合并后的分箱切点列表
        """
        if x_origin_to_code is not None and not isinstance(x_origin_to_code, dict):
            raise TypeError(f"x_origin_to_code 必须是字典类型或None，当前类型：{type(x_origin_to_code)}")

        null_mask  = df[x_column].isna()
        col_series = df[x_column].fillna(self.fill_null_value)
        if isinstance(x_origin_to_code, dict) and (x_column in x_origin_to_code):
            fill_map = x_origin_to_code[x_column]
            if isinstance(fill_map, dict) and fill_map:
                # 匹配则替换，未匹配则-1
                col_series = col_series.map(fill_map)
                # 只有非原始空值的 NaN（即未匹配）才填 -1
                col_series = col_series.mask(~null_mask & col_series.isna(), -1)
        x_arr = col_series.values.astype(float)
        y_arr = df[ylabel].values.astype(float)
        
        # 分离正负类的自变量数组
        y1_x_arr = x_arr[y_arr == self.pos_label]  # 正类自变量
        y0_x_arr = x_arr[y_arr == self.neg_label]  # 负类自变量
        total_pos_cnt = float(len(y1_x_arr))
        total_neg_cnt = float(len(y0_x_arr))
        
        # 提取特殊值+空值占位符
        null_special_vals = list(np.unique([self.fill_null_value] + list(special_vals)))
        exist_vals = [ival for ival in bin_arr if ((ival in null_special_vals) | pd.isna(ival))]
        bin_list   = list(np.sort([ival for ival in bin_arr if (ival not in null_special_vals) & (pd.notna(ival))]))
        # 构建空值、特殊值掩码
        y1_mask = np.isin(y1_x_arr, null_special_vals) | pd.isna(y1_x_arr)
        y0_mask = np.isin(y0_x_arr, null_special_vals) | pd.isna(y0_x_arr)
        y1_x_arr = y1_x_arr[~y1_mask]
        y0_x_arr = y0_x_arr[~y0_mask]

        def _recursive_combine(bin_list, y1_x_arr, y0_x_arr):
            """递归合并分箱（内部嵌套函数）"""
            # 计算每箱的pos_cnt/neg_cnt
            pos_neg = []
            for i in range(len(bin_list) - 1):
                left  = bin_list[i]
                right = bin_list[i + 1]
                
                # 统计当前箱的正/负类数量
                pos_cnt = len(y1_x_arr[(y1_x_arr > left) & (y1_x_arr <= right)])
                neg_cnt = len(y0_x_arr[(y0_x_arr > left) & (y0_x_arr <= right)])
                pos_neg.append((pos_cnt, neg_cnt))
            
            # 确定合并索引
            if len(pos_neg) > 1:
                merge_idx = self._exclude_min_value(
                    pos_neg = pos_neg,
                    total_pos_cnt = total_pos_cnt,
                    total_neg_cnt = total_neg_cnt,
                    col_dist_type = col_dist_type,
                    threshold = threshold
                )
            else:
                merge_idx = None
            
            # 递归合并
            if merge_idx is not None:
                bin_list.pop(merge_idx)
                _recursive_combine(bin_list, y1_x_arr, y0_x_arr)
        
        # 执行递归合并
        _recursive_combine(bin_list, y1_x_arr, y0_x_arr)
        bin_list = np.sort(np.unique(exist_vals + bin_list))
        return bin_list
    
    @_timeit
    def fit_final_bins(
        self,
        df: pd.DataFrame,
        ylabel: str = None, 
        x_dist_dict: Dict[str, str] = {},
        threshold: float = 0.1,
        x_origin_to_code: Optional[Dict[str, Dict[Any, Any]]] = None,
    ) -> Dict[str, List[float]]:
        """
        拟合最终分箱：将粗分箱合并为满足单调/U型分布的最终分箱
        
        参数:
        --------
        df : pd.DataFrame
            输入数据集
        x_dist_dict : Dict[str, str]
            变量分布类型字典，{'列名': 'U'/'L'/'W'}
            - U: U型分布
            - L: 单调分布
            - W: 无需合并
        threshold : float
            r值最小差异阈值（默认0.1）
        x_origin_to_code: dict,
            分类型自变量做数字型转化编码映射字典，格式：{变量名：{原值：替换值}}
            若x_column为分类型变量且df为未做编码前数据则需要传入。
        返回:
        --------
        Dict[str, List[float]]: 最终分箱结果字典
        """
        ylabel  = self.ylabel if ylabel is None else ylabel
        if pd.isna(ylabel):
            raise ValueError(f"ylabel 不可为：{ylabel}")
        validate_cols(df, list(self.raw_bins.keys()) + [ylabel], "分箱占比筛选数据集")
        if x_origin_to_code is not None and not isinstance(x_origin_to_code, dict):
            raise TypeError(f"x_origin_to_code 必须是字典类型或None，当前类型：{type(x_origin_to_code)}")
        # 校验粗分箱是否已生成
        if not self.raw_bins:
            raise RuntimeError("请先调用fit_raw_bins生成粗分箱！")
        
        self.final_bins = {}
        # 遍历变量合并分箱
        with tqdm(self.raw_bins.keys(), ascii=True, desc="合并分箱（单调/U型）") as pbar:
            for col in pbar:
                col_dist_type = x_dist_dict.get(col, "L")  # 默认单调分布
                special_vals = self.special_vals_dict.get(col, [])
                raw_bins = np.sort(np.unique(self.raw_bins.get(col, [])))
                
                if col_dist_type == "W":
                    # W型分布无需合并
                    self.final_bins[col] = raw_bins
                else:
                    # 合并分箱
                    final_bins = self._combine_bins(
                        df = df,
                        ylabel = ylabel,
                        x_column = col,
                        col_dist_type = col_dist_type,
                        bin_arr = raw_bins,
                        threshold = threshold,
                        special_vals = special_vals,
                        x_origin_to_code = x_origin_to_code,
                    )
                    self.final_bins[col] = final_bins
        

    def get_bins(self, bin_type: str = 'final') -> Dict[str, Union[List[float], np.ndarray]]:
        """
        获取分箱结果
        
        参数:
        --------
        bin_type : str
            'raw' - 粗分箱结果
            'final' - 最终分箱结果
        
        返回:
        --------
        Dict[str, Union[List[float], np.ndarray]]: 分箱结果字典
        """
        if bin_type == 'raw':
            return self.raw_bins
        elif bin_type == 'final':
            return self.final_bins
        else:
            raise ValueError(f"不支持的分箱类型：{bin_type}，可选：'raw'/'final'")

