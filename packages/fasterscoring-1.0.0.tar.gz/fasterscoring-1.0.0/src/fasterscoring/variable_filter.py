# -*- coding: utf-8 -*-
"""
评分变量筛选模块 (Scoring Variable Filter Module)
=============================================
版本: 1.0.0
作者: Faster Scoring Team XM
功能:
    1. 对评分变量进行筛选，包含分箱数量、数据比例、PSI、IV、相关系数、VIF等
    2. 基于分箱结果转换原样本为WOE宽表
    3. 分箱结果的详细信息打印
依赖:
    pandas >= 1.2.0, numpy >= 1.20.0, scipy >= 1.6.0, 
    scikit-learn >= 0.24.0, statsmodels >= 0.13.0, tqdm >= 4.60.0
"""

import time
import warnings
from typing import Dict, List, Tuple, Union, Optional, Any, Callable
import numpy as np
import pandas as pd
import scipy.stats as sts
from sklearn.model_selection import train_test_split
import statsmodels.api as sm
import copy
from fasterscoring.general_utils import *
import ipywidgets
if ipywidgets.__version__ > "7.8.5":
    from tqdm import tqdm
else:
    from tqdm.auto import tqdm

# 忽略非关键警告
warnings.filterwarnings('ignore')


class ScoringVarFilter:
    """
    评分卡变量筛选核心类
    功能：提供分箱过滤、PSI过滤、VIF过滤、相关系数过滤等全套变量筛选能力，统一管理配置和筛选结果
    """

    def __init__(
        self,
        df: pd.DataFrame = None, 
        x_bins_dict: Dict[str, List[float]] = None, 
        x_cols_list: List[str] = None, 
        ylabel: str = None, 
        fill_null_value: Optional[Any] = np.nan,
        special_vals_dict: Optional[Dict[str, List[Any]]] = None,
        gen_r_limit: Optional[float] = None, 
        null_r_soft_limit: Optional[float] = None, 
        null_r_hard_limit: Optional[float] = None,
        special_r_soft_limit: Optional[float] = None, 
        special_r_hard_limit: Optional[float] = None, 
        x_cols_desc: Dict[str, str] = None,
        label_mapping: Dict[str, int] = None,
        precision: int = None,
        verbose: bool = True
    ):
        """
        初始化变量筛选器
        
        参数说明：
        --------
        df: 样本数据集 pd.DataFrame
        x_bins_dict: 自变量分箱字典，{"变量名": [1,2,3,4]}
        x_cols_list: 自变量列表
        ylabel: 因变量名
        fill_null_value: 空值标识（如-9999）
        special_vals_dict: 变量特殊值字典，格式 {'col1': [-1111,-7777], 'col2': [-8888]}
        gen_r_limit : Optional[float]
            通用WOE软约束值, 基于 r = posPct/negPct 设定
        null_r_soft_limit : Optional[float]
            空值WOE软约束值, 基于 r = posPct/negPct 设定
        null_r_hard_limit : Optional[float]
            空值WOE硬约束值（强制覆盖）, 基于 r = posPct/negPct 设定
        special_r_soft_limit : Optional[float]
            特殊值WOE软约束值, 基于 r = posPct/negPct 设定
        special_r_hard_limit : Optional[float]
            特殊值WOE硬约束值（强制覆盖）, 基于 r = posPct/negPct 设定
        x_cols_desc: Dict[str, str]
            自变量的说明信息，数据字典
        label_mapping: Dict[str, int]
            因变量标签映射，默认 {'positive':1, 'negative':0}
            'positive' 表示设置为正类的标记值
            'negative' 表示设置为负类的标记值
        precision: 分箱结果的数据精度，默认6位
        verbose: 是否打印详细日志
        """
        # 基础配置
        self.df = df.fillna(fill_null_value) if isinstance(df, pd.DataFrame) else None
        self.ylabel = ylabel
        self.fill_null_value = fill_null_value
        self.special_vals_dict = special_vals_dict if special_vals_dict is not None else {}
        self.gen_r_limit = gen_r_limit
        self.null_r_soft_limit = null_r_soft_limit
        self.null_r_hard_limit = null_r_hard_limit
        self.special_r_soft_limit = special_r_soft_limit
        self.special_r_hard_limit = special_r_hard_limit
        self.x_cols_desc = x_cols_desc if x_cols_desc is not None else {}
        self.precision = precision if precision is not None else 6
        self.verbose = verbose
        self.label_mapping = label_mapping if label_mapping is not None else {'positive': 1, 'negative': 0}


        # 筛选结果存储（统一管理）
        self.results: Dict[str, Any] = {
            'selected_vars': list(x_cols_list), # 各阶段筛选后变量列表 list
            'removed_vars': {},          # 各阶段剔除的变量 dict {'bins_count': [], ...}
            'x_bins_dict': x_bins_dict,  # 变量分箱字典（更新后）dict
            'iv_analysis': None,         # 变量IV信息表 pd.DataFrame
            'var_bins_woe': None,        # 变量每个分箱的woe信息 dict
            'psi_info': {},              # PSI统计信息
            'psi_sampling': {},          # PSI采样信息
            'vif_info': [],              # VIF统计信息
            'corr_info': {},             # 相关系数信息
            'time_cost': {}              # 各阶段耗时
        }

    # ------------------------------ 全局耗时统计装饰器 ------------------------------
    def _timeit(func: Callable) -> Callable:
        """
        全局装饰器：统计类方法/函数执行耗时（适配类实例属性）
        
        Parameters
        ----------
        func : Callable
            被装饰的方法/函数
        
        Returns
        -------
        Callable
            包装后的方法/函数
        """
        def wrapper(*args, **kwargs):
            # 从参数中提取类实例self（类方法第一个参数为self）
            self = args[0] if args and hasattr(args[0], '__class__') else None
            start_time = time.time()
            
            # 执行原方法/函数
            result = func(*args, **kwargs)
            
            # 计算耗时并处理日志/存储
            cost = time.time() - start_time
            if self:
                # 类实例方法：存储耗时到results，按verbose打印
                if not hasattr(self, 'results'):
                    self.results = {'time_cost': {}}  # 初始化results
                if 'time_cost' not in self.results:
                    self.results['time_cost'] = {}
                
                self.results['time_cost'][func.__name__] = cost
                
                # 按实例的verbose配置打印
                if hasattr(self, 'verbose') and self.verbose:
                    print(f">>>>>>> [{func.__name__}] 耗时：{cost:6.4f}秒")
            else:
                # 普通函数：降级打印
                print(f">>>>>>> 函数 [{func.__name__}] 耗时：{cost:6.4f}秒")
            
            return result
        return wrapper

    def _print_filter_result(self, step: str, selected: List[str], removed: List[str]) -> None:
        """
        通用打印：筛选结果（移除/剩余变量数）
        """
        if self.verbose:
            print(f"\n【{step}筛选结果】")
            print(f"移除变量个数: {len(removed)}")
            print(f"剩余变量个数: {len(selected)}")

    def _psi_stats(self, psi_arr: np.ndarray, mu: float = 0.01) -> Tuple[np.ndarray, float, float, float, float, float]:
        """
        核心计算：PSI统计分析（均值、标准差、p值、置信区间）
        返回：(分箱PSI, PSI均值, PSI标准差, p值, 置信区间下限, 置信区间上限)
        """
        row_psi = np.mean(psi_arr, axis=0)
        col_psi = np.sum(psi_arr, axis=1)
        psi_avg = np.sum(row_psi)
        psi_std = np.std(col_psi, ddof=1)
        n = len(col_psi)
        df = n - 1

        # 除零保护
        se = psi_std / np.sqrt(n) if n > 1 else 0
        t_stat = (psi_avg - mu) / se if se != 0 else 0
        p_value = 1 - sts.t.cdf(t_stat, df) if df > 0 else 1

        # 双侧t临界值
        t_critical = sts.t.ppf(1 - 0.05/2, df) if df > 0 else 0
        ci_lower = psi_avg - t_critical * se
        ci_upper = psi_avg + t_critical * se

        return row_psi, psi_avg, psi_std, p_value, ci_lower, ci_upper


    def _return_woe(self, x: float, woe_map: Dict[pd.Interval, float]) -> float:
        """
        辅助方法：根据值查找对应的WOE值
        """
        if pd.isna(x):
            return woe_map.get(np.nan)
        for interval, woe_val in woe_map.items():
            if pd.notna(interval) and x in interval:
                return woe_val
        return np.nan

    def _intervals_map(self, interval_map: Dict[Any, float], col_series: pd.Series):
        intervals = [k for k in interval_map.keys() if isinstance(k, pd.Interval)]
        itv_scores_label = [interval_map[k] for k in intervals]
        
        non_itv_map = {k:v for k, v in interval_map.items() if not isinstance(k, pd.Interval)}
        non_itv_scores = col_series.map(non_itv_map).values.astype(float)

        if len(intervals) > 0:
            score_array = pd.cut(col_series.values,
                                  bins = [interval.left for interval in intervals] + [intervals[-1].right],
                                  labels = itv_scores_label,
                                  include_lowest = True,
                                  right = intervals[0].closed in ['right', 'both'],
                                  ordered = False
                                ).astype(float)
            score_array = np.where(
                            pd.notna(score_array),  # 非缺失值判断
                            score_array,    # True  取值
                            non_itv_scores  # False 取值
                        )
        else:
            score_array = non_itv_scores
        return score_array


    @_timeit
    def filter_bins_count(self, 
        x_cols_list: List[str] = None, 
        x_bins_dict: Dict[str, List[float]] = None, 
        bins_cnt_thresh: int = 2
        ) -> Tuple[List[str], List[str]]:
        """
        筛选逻辑：剔除分箱过少的变量（排除空值/特殊值/极值后的有效分箱数）
        x_bins_dict: 自变量分箱字典，{"变量名": [1,2,3,4]}
        x_cols_list: 自变量列表
        bins_cnt_thresh: 有效分箱数量阈值（低于此值的变量会被剔除）
        """
        x_bins_dict = self.results['x_bins_dict']   if x_bins_dict is None else x_bins_dict
        x_cols_list   = self.results['selected_vars'] if x_cols_list   is None else x_cols_list
        if x_bins_dict is None or len(x_bins_dict) == 0:
            raise ValueError(f"x_bins_dict 不可为：{x_bins_dict}")
        if x_cols_list is None or len(x_cols_list) == 0:
            raise ValueError(f"x_cols_list 不可为：{x_cols_list}")
        selected_vars = list(x_cols_list)
        removed_vars = []
        with tqdm(x_cols_list, ascii=True, desc='剔除分箱过少变量') as pbar:
            for icol in pbar:
                bins_array = np.sort(np.unique(x_bins_dict.get(icol, [-np.inf, np.inf])))
                special_vals = list(self.special_vals_dict.get(icol, []))
                if len(bins_array) > 0:
                    # 排除特殊值、极值、空值
                    valid_bins = [b for b in bins_array if  pd.notna(b)]
                    exclude = special_vals + [-np.inf, self.fill_null_value, np.inf] + [valid_bins[0], valid_bins[-1]]
                    valid_bins = [b for b in valid_bins if (b not in exclude) ]

                    if len(valid_bins) < bins_cnt_thresh - 1:
                        removed_vars.append(icol)
                else:
                    removed_vars.append(icol)

        # 更新结果
        removed_vars = list(set(removed_vars))
        selected_vars = [icol for icol in selected_vars if icol not in removed_vars]
        self.results['removed_vars']['bins_count'] = removed_vars
        self.results['selected_vars'] = selected_vars
        self.results['x_bins_dict'] = x_bins_dict

        # 打印结果
        self._print_filter_result("分箱数量", selected_vars, removed_vars)
        return selected_vars, removed_vars

    @_timeit
    def filter_bins_rate(self, 
        df: pd.DataFrame = None, 
        x_cols_list: List[str] = None, 
        x_bins_dict: Dict[str, List[float]] = None, 
        bin_rate_params: Dict[str, float] = {},
        x_origin_to_code: Optional[Dict[str, Dict[Any, Any]]] = None,
    ) -> Tuple[List[str], List[str]]:
        """
        筛选逻辑：剔除单箱数据占比过高的变量（区分通用/空值/特殊值分箱
        df: pd.DataFrame
            数据集
        x_bins_dict: dict
            自变量分箱字典，{"变量名": [1,2,3,4]}
        x_cols_list: list
            自变量列表
        bin_rate_params: dict
            单箱占比阈值字典，格式 {'general':0.95, 'null':0.95, 'special': 0.95}
            'general' 表示一般单箱数据量占比 >= 阈值 则剔除
            'null'    表示一般空值箱数据量占比 >= 阈值 则剔除
            'special' 表示一般特殊值箱数据量占比 >= 阈值 则剔除
        x_origin_to_code: dict,
            分类型自变量做数字型转化编码映射字典，格式：{变量名：{原值：替换值}}
            若x_column为分类型变量且df为未做编码前数据则需要传入。
        """
        # 参数校验
        df = self.df if df is None else df
        x_bins_dict = self.results['x_bins_dict']   if x_bins_dict is None else x_bins_dict
        x_cols_list = self.results['selected_vars'] if x_cols_list is None else x_cols_list
        if df is None or df.empty:
            raise ValueError(f"df 不可为：{df}")
        if x_bins_dict is None or len(x_bins_dict) == 0:
            raise ValueError(f"x_bins_dict 不可为：{x_bins_dict}")
        if x_cols_list is None or len(x_cols_list) == 0:
            raise ValueError(f"x_cols_list 不可为：{x_cols_list}")
        if x_origin_to_code is not None and not isinstance(x_origin_to_code, dict):
            raise TypeError(f"x_origin_to_code 必须是字典类型或None，当前类型：{type(x_origin_to_code)}")
        validate_cols(df, list(x_cols_list), "分箱占比筛选数据集")
        default = {'general':0.95, 'null':0.95, 'special': 0.95}
        bin_rate_params = bin_rate_params.copy() if bin_rate_params else {}
        invalid = [ikey for ikey in bin_rate_params.keys() if ikey not in default.keys()]
        if invalid:
            raise ValueError(f"bin_rate_params 的这些参数是无效的：{invalid}, 应为{list(default.keys())}")
        for ikey in default.keys():
            if ikey not in bin_rate_params.keys():
                bin_rate_params[ikey] = default[ikey]

        removed_vars = []
        selected_vars = list(x_cols_list)

        with tqdm(x_cols_list, ascii=True, desc='剔除单箱数据占比过高变量') as pbar:
            for icol in pbar:
                special_vals = list(self.special_vals_dict.get(icol, []))
                null_mask = df[icol].isna()
                col_series = df[icol].fillna(self.fill_null_value)
                if isinstance(x_origin_to_code, dict) and (icol in x_origin_to_code):
                    fill_map = x_origin_to_code[icol]
                    if isinstance(fill_map, dict) and fill_map:
                        # 匹配则替换，未匹配则-1
                        col_series = col_series.map(fill_map)
                        # 只有非原始空值的 NaN（即未匹配）才填 -1
                        col_series = col_series.mask(~null_mask & col_series.isna(), -1)
                x_vals = col_series.values.astype(float)

                bins_array = np.sort(np.unique(x_bins_dict.get(icol, [-np.inf, np.inf])))
                total = len(x_vals)

                if total == 0:
                    removed_vars.append(icol)
                    continue
                
                # 提取空值占位符
                bins_array = np.sort([ival for ival in bins_array if (ival != self.fill_null_value) & pd.notna(ival) & (ival not in special_vals)])
                null_mask  = (x_vals == self.fill_null_value) | pd.isna(x_vals)
                null_cnt   = np.sum(null_mask)
                null_rate  = null_cnt / total
                if null_rate >= bin_rate_params.get('null', 0.95):
                    removed_vars.append(icol)
                    continue

                spec_mask = np.isin(x_vals, special_vals)
                spec_cnt  = np.sum(spec_mask)
                spec_rate = spec_cnt / total
                if spec_rate >= bin_rate_params.get('special', 0.95):
                    removed_vars.append(icol)
                    continue

                x_vals = x_vals[(~null_mask) & (~spec_mask)]

                # 检查每个分箱的占比
                for idx in range(len(bins_array)-1):
                    left  = bins_array[idx]
                    right = bins_array[idx+1]
                    bin_cnt = len(x_vals[(x_vals > left) & (x_vals <= right)])
                    bin_rate = bin_cnt / total
                    # 区分空值/特殊值/通用分箱的阈值
                    if bin_rate >= bin_rate_params.get('general', 0.95):
                        removed_vars.append(icol)
                        break

        # 更新结果
        removed_vars = list(set(removed_vars))
        selected_vars = [icol for icol in selected_vars if icol not in removed_vars]
        self.results['removed_vars']['bins_rate'] = removed_vars
        self.results['selected_vars'] = selected_vars

        # 打印结果
        self._print_filter_result("单箱占比", selected_vars, removed_vars)
        return selected_vars, removed_vars


    def _cal_arr_psi(self, xarr: np.ndarray) -> np.ndarray:
        xarr = np.array(xarr, dtype=np.float64)
        left_rto = xarr[:,:,0]/np.sum(xarr[:,:,0], axis = 1).reshape(-1, 1)
        righ_rto = xarr[:,:,1]/np.sum(xarr[:,:,1], axis = 1).reshape(-1, 1)
        left_rto = np.nan_to_num(left_rto, nan=0.0, posinf=1, neginf=0)
        righ_rto = np.nan_to_num(righ_rto, nan=0.0, posinf=1, neginf=0)
        psi_arr = self._psi_cal(left_rto, righ_rto)
        return psi_arr

    def _psi_cal(
        self,
        left_ratio: np.ndarray,
        right_ratio: np.ndarray,
    ) -> np.ndarray:
        """
        NumPy 向量化版本：支持批量 array 输入
        left_ratio : 正类占比 (array/float)
        right_ratio : 负类占比 (array/float)
        返回: (r_final, ks, woe, iv_psi) 均为 np.array
        """
        # 统一转为 numpy 数组（兼容标量输入）
        left = np.asarray(left_ratio, dtype=np.float64)
        right = np.asarray(right_ratio, dtype=np.float64)

        # --------------------- 向量化条件分支计算 r ---------------------
        r = np.ones_like(left)  # 默认 r=1.0

        # 条件1：left=0 & right≠0
        cond1 = (left == 0) & (right != 0)
        val1 = np.where(right < 0.005, 1.0, 1/9)
        r = np.where(cond1, val1, r)

        # 条件2：left≠0 & right=0
        cond2 = (left != 0) & (right == 0)
        val2 = np.where(left < 0.005, 1.0, 9)
        r = np.where(cond2, val2, r)

        # 条件3：都≠0
        cond3 = (left != 0) & (right != 0)
        val3 = np.where(
            (left <= 0.005) & (right <= 0.005),
            1.0,
            left / right
        )
        r = np.where(cond3, val3, r)

        psi = (left - right)*np.log(r)
        return psi

    @_timeit
    def cal_var_psi(
        self,
        df: pd.DataFrame = None,
        x_bins_dict: Dict[str, List[float]] = None,
        x_cols_list: List[str] = None,
        ylabel: Optional[str] = None,
        time_col: Optional[str] = None,
        time_split: List[Any] = [],
        psi_params: Dict[str, Any] = None,
        x_origin_to_code: Optional[Dict[str, Dict[Any, Any]]] = None,
        ) -> Tuple[Dict[str, List[float]], Dict[str, Any], List[str], List[str]]:
        """
        筛选逻辑：随机抽样剔除PSI过高的变量（核心方法，支持时间分割/分层抽样）
        df: pd.DataFrame
            数据集
        x_bins_dict: dict
            自变量分箱字典，{"变量名": [1,2,3,4]}
        x_cols_list: list
            自变量列表
        ylabel: str
            因变量名
        time_col: v
            时间字段，若传该字段按时间序列进行psi检验，否则按随机抽样检验
        time_split: list
            传时间字段必须要传时间分割点，否则仍然按随机抽样检验
            eg: [20250601, 20250701, 20250801]，则会分别按照
            <= 20250601 与 > 20250601
            <= 20250701 与 > 20250701
            <= 20250801 与 > 20250801
            分3次统计PSI检验
        psi_params: dict
            PSI筛选参数字典，包含totThre/posThre/negThre等
            tot_thresh   整体数据的PSI检验阈值 默认值 0.01
            pos_thresh   正类数据的PSI检验阈值 默认值 0.1
            neg_thresh   负类数据的PSI检验阈值 默认值 0.1
            tot_alpha    整体数据的PSI的t检验显著性水平α 右单侧检验 默认值 0.05
            pos_alpha    正类数据的PSI的t检验显著性水平α 右单侧检验 默认值 0.05
            neg_alpha    负类数据的PSI的t检验显著性水平α 右单侧检验 默认值 0.05
            num_thresh   随机抽样次数 默认值 10次
            random_ratio 随机抽样比例 默认值 0.7
            stratify     是否按ylabel分层抽样 只有当ylabel不为空时生效 默认值 False
            random_state 随机种子（保证结果可复现）默认 0
            {
                'tot_thresh': 0.01, 'pos_thresh': 0.1, 'neg_thresh': 0.1,
                'tot_alpha' : 0.05, 'pos_alpha': 0.05, 'neg_alpha': 0.05,
                'num_thresh': 10, 'random_ratio': 0.7, 'stratify': False,
                'random_state': 0,
            }
        x_origin_to_code: dict,
            分类型自变量做数字型转化编码映射字典，格式：{变量名：{原值：替换值}}
            若x_column为分类型变量且df为未做编码前数据则需要传入。
        """
        def _merge_arr(xarr: np.ndarray, idx: int) -> np.ndarray:
            xarr = np.array(xarr)
            xarr[:, idx, :] = xarr[:, idx, :] + xarr[:, idx+1, :]
            xarr = np.delete(xarr, idx+1, axis = 1)
            return xarr

        def _merge_bins(pos_neg_list: List[Tuple[int, int]], idx: int) -> List[Tuple[int, int]]:
            """合并指定索引的相邻箱"""
            merged_pos_neg = []
            # 合并idx和idx+1箱的pos_cnt/neg_cnt
            merged = tuple(np.array(pos_neg_list[idx]) + np.array(pos_neg_list[idx + 1]))
            # 构建合并后的列表
            for idx2, info in enumerate(pos_neg_list):
                if idx2 not in [idx, idx+1]:
                    merged_pos_neg.append(info)
                elif merged not in merged_pos_neg:
                    merged_pos_neg.append(merged)
            return merged_pos_neg

        df = self.df if df is None else df
        x_bins_dict = self.results['x_bins_dict']   if x_bins_dict is None else x_bins_dict
        x_cols_list = self.results['selected_vars'] if x_cols_list is None else x_cols_list
        ylabel  = self.ylabel  if ylabel  is None else ylabel
        if df is None or df.empty:
            raise ValueError(f"df 不可为：{df}")
        if x_bins_dict is None or len(x_bins_dict) == 0:
            raise ValueError(f"x_bins_dict 不可为：{x_bins_dict}")
        if x_cols_list is None or len(x_cols_list) == 0:
            raise ValueError(f"x_cols_list 不可为：{x_cols_list}")
        default = {
            'tot_thresh': 0.01, 'pos_thresh': 0.1, 'neg_thresh': 0.1,
            'tot_alpha' : 0.05, 'pos_alpha': 0.05, 'neg_alpha': 0.05,
            'num_thresh': 10, 'random_ratio': 0.7, 'stratify': False,
            'random_state': 0,
        }
        psi_params = psi_params.copy() if psi_params else {}
        invalid = [ikey for ikey in psi_params.keys() if ikey not in default.keys()]
        if invalid:
            raise ValueError(f"psi_params 的这些参数是无效的：{invalid}，应为 {list(default.keys())}")
        for ikey in default.keys():
            if ikey not in psi_params.keys():
                psi_params[ikey] = default[ikey]
        if x_origin_to_code is not None and not isinstance(x_origin_to_code, dict):
            raise TypeError(f"x_origin_to_code 必须是字典类型或None，当前类型：{type(x_origin_to_code)}")
        # 参数校验
        check_cols = list(x_cols_list.copy())
        if ylabel:
            check_cols.append(ylabel)
        if time_col:
            check_cols.append(time_col)
        validate_cols(df, check_cols, "PSI筛选数据集")

        updated_bins_dict = copy.deepcopy(x_bins_dict)
        removed_vars = []
        psi_info = {"DESC": ['PSI', 'stderr', 'p-value', 'lower[0.025]', 'upper[0.975]']}
        psi_sampling = {"DESC": [("left_bin_count", "right_bin_count")]}
        pos = self.label_mapping.get('positive', 1)
        neg = self.label_mapping.get('negative', 0)

        # 覆盖PSI参数
        if (time_col is not None) and (len(time_split) > 0):
            psi_params['num_thresh'] = len(time_split)
        # 预处理标签数据
        if ylabel:
            y_vals = df[ylabel].values.astype(float)
            pos_count = float(len(y_vals[y_vals == pos]))
            neg_count = float(len(y_vals[y_vals == neg]))
            if pos_count == 0 or neg_count == 0:
                raise ValueError(f"ylabel：{ylabel}数据失衡 pos:neg {pos_count}:{neg_count}")

        with tqdm(x_cols_list, ascii=True, desc='基于采样计算变量PSI') as pbar:
            for col in pbar:
                bins_array   = list(np.sort(np.unique(x_bins_dict.get(col, [-np.inf, np.inf]))))
                special_vals = self.special_vals_dict.get(col, [])
                null_special_vals = list(np.unique([self.fill_null_value] + list(special_vals)))

                exist_vals = [ival for ival in bins_array if ((ival in null_special_vals) | pd.isna(ival))]
                bins_array = [ival for ival in bins_array if (ival not in null_special_vals) & (pd.notna(ival))]
                # 构建分析数据集（排除特殊值）
                ana_cols = [col]
                if ylabel:
                    ana_cols.append(ylabel)
                if time_col:
                    ana_cols.append(time_col)

                subdf = df[ana_cols].copy()
                null_spec_mask = subdf[col].isin(null_special_vals) | subdf[col].isna()
                if len(subdf[~null_spec_mask]) == 0:
                    removed_vars.append(col)
                    continue

                null_mask = subdf[col].isna()
                col_series = subdf[col].fillna(self.fill_null_value)
                if isinstance(x_origin_to_code, dict) and (col in x_origin_to_code):
                    fill_map = x_origin_to_code[col]
                    if isinstance(fill_map, dict) and fill_map:
                        # 匹配则替换，未匹配则-1
                        col_series = col_series.map(fill_map)
                        # 只有非原始空值的 NaN（即未匹配）才填 -1
                        col_series = col_series.mask(~null_mask & col_series.isna(), -1)
                subdf[col] = col_series.values.astype(float)

                x_vals = subdf[col].values
                tot_psi_info = []
                pos_psi_info = []
                neg_psi_info = []

                # 预处理标签数据
                pos_neg = []
                if ylabel:
                    y_vals = subdf[ylabel].values.astype(float)
                    x_vals_pos = x_vals[(y_vals == pos) & ~null_spec_mask]
                    x_vals_neg = x_vals[(y_vals == neg) & ~null_spec_mask]
                    if len(x_vals_pos) == 0 or len(x_vals_neg) == 0:
                        removed_vars.append(col)
                        continue
                    for i in range(len(bins_array)-1):
                        left  = bins_array[i]
                        right = bins_array[i+1]
                        pos_cnt = len(x_vals_pos[(x_vals_pos > left) & (x_vals_pos <= right)])
                        neg_cnt = len(x_vals_neg[(x_vals_neg > left) & (x_vals_neg <= right)])
                        pos_neg.append((pos_cnt, neg_cnt))

                # 抽样计算PSI
                num = psi_params.get('num_thresh', 10)
                sampling_tot_arr = []
                sampling_pos_arr = []
                sampling_neg_arr = []
                while num:
                    num -= 1
                    # 数据分割（时间分割/随机抽样）
                    if (time_col is not None) and (len(time_split) > 0):
                        df_left  = subdf[subdf[time_col] <= time_split[num]]
                        df_right = subdf[subdf[time_col] >  time_split[num]]
                    else:
                        stratify_col = subdf[ylabel] if (psi_params.get('stratify', False) and ylabel) else None
                        df_left, df_right = train_test_split(
                            subdf, test_size = psi_params.get('random_ratio', 0.7),
                            stratify = stratify_col, random_state = psi_params.get('random_state', 0) + num
                        )
                    if df_left.empty or df_right.empty:
                        continue

                    sampling_tot = []
                    sampling_pos = []
                    sampling_neg = []
                    # 计算分箱PSI
                    lx_vals = df_left[col].values.astype(float)
                    rx_vals = df_right[col].values.astype(float)

                    lnull_mask = (lx_vals == self.fill_null_value) | pd.isna(lx_vals)
                    rnull_mask = (rx_vals == self.fill_null_value) | pd.isna(rx_vals)
                    lnull_cnt  = np.sum(lnull_mask)
                    rnull_cnt  = np.sum(rnull_mask)
                    sampling_tot.append((lnull_cnt, rnull_cnt))

                    lspec_mask = np.isin(lx_vals, special_vals)
                    rspec_mask = np.isin(rx_vals, special_vals)
                    lspec_cnt  = np.sum(lspec_mask)
                    rspec_cnt  = np.sum(rspec_mask)
                    sampling_tot.append((lspec_cnt, rspec_cnt))

                    if ylabel:
                        ly_vals = df_left[ylabel].values.astype(float)
                        ry_vals = df_right[ylabel].values.astype(float)
                        lx_pos = lx_vals[ly_vals == pos]
                        lx_neg = lx_vals[ly_vals == neg]
                        rx_pos = rx_vals[ry_vals == pos]
                        rx_neg = rx_vals[ry_vals == neg]

                        lnull_pos_mask = (lx_pos == self.fill_null_value) | pd.isna(lx_pos)
                        lnull_neg_mask = (lx_neg == self.fill_null_value) | pd.isna(lx_neg)
                        rnull_pos_mask = (rx_pos == self.fill_null_value) | pd.isna(rx_pos)
                        rnull_neg_mask = (rx_neg == self.fill_null_value) | pd.isna(rx_neg)
                        lnull_pos_cnt = np.sum(lnull_pos_mask)
                        lnull_neg_cnt = np.sum(lnull_neg_mask)
                        rnull_pos_cnt = np.sum(rnull_pos_mask)
                        rnull_neg_cnt = np.sum(rnull_neg_mask)
                        sampling_pos.append((lnull_pos_cnt, rnull_pos_cnt))
                        sampling_neg.append((lnull_neg_cnt, rnull_neg_cnt))

                        lspec_pos_mask = np.isin(lx_pos, special_vals)
                        lspec_neg_mask = np.isin(lx_neg, special_vals)
                        rspec_pos_mask = np.isin(rx_pos, special_vals)
                        rspec_neg_mask = np.isin(rx_neg, special_vals)
                        lspec_pos_cnt = np.sum(lspec_pos_mask)
                        lspec_neg_cnt = np.sum(lspec_neg_mask)
                        rspec_pos_cnt = np.sum(rspec_pos_mask)
                        rspec_neg_cnt = np.sum(rspec_neg_mask)
                        sampling_pos.append((lspec_pos_cnt, rspec_pos_cnt))
                        sampling_neg.append((lspec_neg_cnt, rspec_neg_cnt))

                    for i in range(len(bins_array)-1):
                        left  = bins_array[i]
                        right = bins_array[i+1]
                        # 总体PSI
                        l_count = len(lx_vals[(lx_vals > left) & (lx_vals <= right) & (~lnull_mask) & (~lspec_mask)])
                        r_count = len(rx_vals[(rx_vals > left) & (rx_vals <= right) & (~rnull_mask) & (~rspec_mask)])
                        sampling_tot.append((l_count, r_count))

                        # pos_pct\neg_pct PSI
                        if ylabel:
                            l_pos_cnt = len(lx_pos[(lx_pos > left) & (lx_pos <= right) & (~lnull_pos_mask) & (~lspec_pos_mask)])
                            l_neg_cnt = len(lx_neg[(lx_neg > left) & (lx_neg <= right) & (~lnull_neg_mask) & (~lspec_neg_mask)])
                            r_pos_cnt = len(rx_pos[(rx_pos > left) & (rx_pos <= right) & (~rnull_pos_mask) & (~rspec_pos_mask)])
                            r_neg_cnt = len(rx_neg[(rx_neg > left) & (rx_neg <= right) & (~rnull_neg_mask) & (~rspec_neg_mask)])
                            sampling_pos.append((l_pos_cnt, r_pos_cnt))
                            sampling_neg.append((l_neg_cnt, r_neg_cnt))
                    sampling_tot_arr.append(sampling_tot)
                    sampling_pos_arr.append(sampling_pos)
                    sampling_neg_arr.append(sampling_neg)

                sampling_tot_arr = np.array(sampling_tot_arr)
                sampling_pos_arr = np.array(sampling_pos_arr)
                sampling_neg_arr = np.array(sampling_neg_arr)
                # 递归合并分箱计算PSI
                def _combine_psi_bins(sampling_tot_arr, sampling_pos_arr, sampling_neg_arr, pos_neg, bins_array, ylabel):
                    tot_psi_arr_all = self._cal_arr_psi(sampling_tot_arr)
                    tot_psi_arr_val = self._cal_arr_psi(sampling_tot_arr[:,2:,:])
                    if ylabel:
                        pos_psi_arr_all = self._cal_arr_psi(sampling_pos_arr)
                        neg_psi_arr_all = self._cal_arr_psi(sampling_neg_arr)
                        pos_psi_arr_val = self._cal_arr_psi(sampling_pos_arr[:,2:,:])
                        neg_psi_arr_val = self._cal_arr_psi(sampling_neg_arr[:,2:,:])

                    # PSI统计分析
                    for psi_arr in [tot_psi_arr_all, tot_psi_arr_val]:
                        bins_psi_tot, psi_avg_tot, psi_std_tot, pv_tot, ci_tot_l, ci_tot_u = self._psi_stats(
                            psi_arr, mu = psi_params.get('tot_thresh', 0.01)
                        )
                        tot_psi_info.append([psi_avg_tot, psi_std_tot, pv_tot, ci_tot_l, ci_tot_u])

                    # pos\neg PSI分析
                    if ylabel:
                        for psi_arr in [pos_psi_arr_all, pos_psi_arr_val]:
                            bins_psi_pos, psi_avg_pos, psi_std_pos, pv_pos, ci_pos_l, ci_pos_u = self._psi_stats(
                                psi_arr, mu = psi_params.get('pos_thresh', 0.1)
                            )
                            pos_psi_info.append([psi_avg_pos, psi_std_pos, pv_pos, ci_pos_l, ci_pos_u])

                        for psi_arr in [neg_psi_arr_all, neg_psi_arr_val]:
                            bins_psi_neg, psi_avg_neg, psi_std_neg, pv_neg, ci_neg_l, ci_neg_u = self._psi_stats(
                                psi_arr, mu = psi_params.get('neg_thresh', 0.1)
                            )
                            neg_psi_info.append([psi_avg_neg, psi_std_neg, pv_neg, ci_neg_l, ci_neg_u])


                        # 判断是否需要合并分箱
                        max_idx = None
                        if pv_tot < psi_params.get('tot_alpha', 0.05):
                            max_idx = np.argmax(bins_psi_tot)
                        elif ylabel:
                            if pv_pos < psi_params.get('pos_alpha', 0.05):
                                max_idx = np.argmax(bins_psi_pos)
                            elif pv_neg < psi_params.get('neg_alpha', 0.05):
                                max_idx = np.argmax(bins_psi_neg)

                        # 分箱合并逻辑
                        if max_idx is not None:
                            valid_bins = [x for x in bins_array if x not in [-np.inf, np.inf]]
                            if len(valid_bins) > 1:
                                r_list = [
                                weight_ratio(
                                    pos_cnt/pos_count if pos_count > 0 else 0, 
                                    neg_cnt/neg_count if neg_count > 0 else 0, 
                                    r_soft_limit = self.gen_r_limit
                                    )[0] 
                                for pos_cnt, neg_cnt in pos_neg
                                ]
                                r_diff = np.abs(np.diff(r_list)) if r_list else np.array([])
                                if max_idx == 0:
                                    # 第一箱与第二箱合并
                                    bins_array.pop(max_idx + 1)
                                    sampling_tot_arr = _merge_arr(sampling_tot_arr, max_idx+2)
                                    if ylabel:
                                        sampling_pos_arr = _merge_arr(sampling_pos_arr, max_idx+2)
                                        sampling_neg_arr = _merge_arr(sampling_neg_arr, max_idx+2)
                                    pos_neg = _merge_bins(pos_neg, max_idx)
                                elif max_idx == len(bins_array) - 2:
                                    # 倒数第一箱与倒数第二箱合并
                                    bins_array.pop(max_idx)
                                    sampling_tot_arr = _merge_arr(sampling_tot_arr, max_idx+1)
                                    if ylabel:
                                        sampling_pos_arr = _merge_arr(sampling_pos_arr, max_idx+1)
                                        sampling_neg_arr = _merge_arr(sampling_neg_arr, max_idx+1)
                                    pos_neg = _merge_bins(pos_neg, max_idx - 1)
                                else:
                                    if len(r_diff) > max_idx - 1 and r_diff[max_idx - 1] <= r_diff[max_idx]:
                                        # 中间箱靠左合并
                                        bins_array.pop(max_idx)
                                        sampling_tot_arr = _merge_arr(sampling_tot_arr, max_idx+1)
                                        if ylabel:
                                            sampling_pos_arr = _merge_arr(sampling_pos_arr, max_idx+1)
                                            sampling_neg_arr = _merge_arr(sampling_neg_arr, max_idx+1)
                                        pos_neg = _merge_bins(pos_neg, max_idx - 1)
                                    else:
                                        # 中间箱靠右合并
                                        bins_array.pop(max_idx + 1)
                                        sampling_tot_arr = _merge_arr(sampling_tot_arr, max_idx+2)
                                        if ylabel:
                                            sampling_pos_arr = _merge_arr(sampling_pos_arr, max_idx+2)
                                            sampling_neg_arr = _merge_arr(sampling_neg_arr, max_idx+2)
                                        pos_neg = _merge_bins(pos_neg, max_idx)
                                if len(valid_bins) > 2:
                                    _combine_psi_bins(sampling_tot_arr, sampling_pos_arr, sampling_neg_arr, pos_neg, bins_array, ylabel)
                # 递归执行分箱合并
                if sampling_tot_arr.size > 0:
                    _combine_psi_bins(sampling_tot_arr, sampling_pos_arr, sampling_neg_arr, pos_neg, bins_array, ylabel)

                # 更新结果
                updated_bins_dict[col] = np.sort(np.unique(exist_vals + bins_array))
                # PSI, stderr, p-value, lower, upper
                div_psi_info = {
                    'totPSI': tot_psi_info,
                    'posPSI': pos_psi_info,
                    'negPSI': neg_psi_info
                }
                sampling_info = {
                    'totSample': sampling_tot_arr,
                    'posSample': sampling_pos_arr,
                    'negSample': sampling_neg_arr
                }
                psi_info[col] = div_psi_info
                psi_sampling[col] = sampling_info

        # 更新结果
        removed_vars = list(set(removed_vars))
        selected_vars = [col for col in x_cols_list if col not in removed_vars]
        self.results['removed_vars']['cal_psi'] = removed_vars
        self.results['selected_vars'] = selected_vars
        self.results['x_bins_dict'] = updated_bins_dict
        self.results['psi_info'] = psi_info
        self.results['psi_sampling'] = psi_sampling

        # 打印结果
        self._print_filter_result("PSI计算", selected_vars, removed_vars)
        return updated_bins_dict, psi_info, selected_vars, removed_vars


    @_timeit
    def filter_psi_high(
        self,
        x_cols_list: List[str] = None,
        psi_params: Dict[str, Any] = None,
        psi_only_val: bool = True,
        verbose: bool = None, 
    ) -> Tuple[Dict[str, List[float]], Dict[str, Any], List[str], List[str]]:
        """
        筛选逻辑：随机抽样剔除PSI过高的变量（核心方法，支持时间分割/分层抽样）
        x_cols_list: list
            自变量列表
        psi_params: dict
            PSI筛选参数字典，包含totThre/posThre/negThre等
            tot_thresh   整体数据的PSI检验阈值 默认值 0.01
            pos_thresh   正类数据的PSI检验阈值 默认值 0.1
            neg_thresh   负类数据的PSI检验阈值 默认值 0.1
            tot_alpha    整体数据的PSI的t检验显著性水平α 右单侧检验 默认值 0.05
            pos_alpha    正类数据的PSI的t检验显著性水平α 右单侧检验 默认值 0.05
            neg_alpha    负类数据的PSI的t检验显著性水平α 右单侧检验 默认值 0.05
            num_thresh   随机抽样次数 默认值 10次
            random_ratio 随机抽样比例 默认值 0.7
            stratify     是否按ylabel分层抽样 只有当ylabel不为空时生效 默认值 False
            random_state 随机种子（保证结果可复现）默认 0
            {
                'tot_thresh': 0.01, 'pos_thresh': 0.1, 'neg_thresh': 0.1,
                'tot_alpha' : 0.05, 'pos_alpha': 0.05, 'neg_alpha': 0.05,
                'num_thresh': 10, 'random_ratio': 0.7, 'stratify': False,
                'random_state': 0,
            }
        psi_only_val: bool
            是否只检测有值域PSI即不包含空值和特殊值，默认为True
        """
        x_cols_list = self.results['selected_vars'] if x_cols_list is None else x_cols_list
        verbose = self.verbose if verbose is None else verbose

        if len(self.results.get('psi_sampling',{})) == 0:
            raise ValueError(f"请先进行PSI计算初始化PSI采样信息psi_sampling")

        default = {
            'tot_thresh': 0.01, 'pos_thresh': 0.1, 'neg_thresh': 0.1,
            'tot_alpha' : 0.05, 'pos_alpha': 0.05, 'neg_alpha': 0.05,
            'num_thresh': 10, 'random_ratio': 0.7, 'stratify': False,
            'random_state': 0,
        }
        psi_params = psi_params.copy() if psi_params else {}
        invalid = [ikey for ikey in psi_params.keys() if ikey not in default.keys()]
        if invalid:
            raise ValueError(f"psi_params 的这些参数是无效的：{invalid}，应为 {list(default.keys()[:6])}")
        for ikey in default.keys():
            if ikey not in psi_params.keys():
                psi_params[ikey] = default[ikey]

        removed_vars = []
        psi_info = {"DESC": ['PSI', 'stderr', 'p-value', 'lower[0.025]', 'upper[0.975]']}
        with tqdm(x_cols_list, ascii=True, desc='基于假设检验(右侧检验)剔除PSI过高变量') as pbar:
            for col in pbar:
                # PSI, stderr, p-value, lower, upper
                sampling_info = self.results.get('psi_sampling',{}).get(col, {})
                tot_psi_info = []
                pos_psi_info = []
                neg_psi_info = []
                if sampling_info:
                    sampling_tot_arr = sampling_info.get('totSample')
                    sampling_pos_arr = sampling_info.get('posSample')
                    sampling_neg_arr = sampling_info.get('negSample')
                    if sampling_tot_arr is not None:
                        tot_psi_arr_all = self._cal_arr_psi(sampling_tot_arr)
                        tot_psi_arr_val = self._cal_arr_psi(sampling_tot_arr[:,2:,:])
                        # PSI统计分析
                        for psi_arr in [tot_psi_arr_all, tot_psi_arr_val]:
                            _, psi_avg_tot, psi_std_tot, pv_tot, ci_tot_l, ci_tot_u = self._psi_stats(
                                psi_arr, mu = psi_params.get('tot_thresh', 0.01)
                            )
                            tot_psi_info.append([psi_avg_tot, psi_std_tot, pv_tot, ci_tot_l, ci_tot_u])

                    if sampling_pos_arr is not None:
                        pos_psi_arr_all = self._cal_arr_psi(sampling_pos_arr)
                        pos_psi_arr_val = self._cal_arr_psi(sampling_pos_arr[:,2:,:])
                        for psi_arr in [pos_psi_arr_all, pos_psi_arr_val]:
                            _, psi_avg_pos, psi_std_pos, pv_pos, ci_pos_l, ci_pos_u = self._psi_stats(
                                psi_arr, mu = psi_params.get('pos_thresh', 0.1)
                            )
                            pos_psi_info.append([psi_avg_pos, psi_std_pos, pv_pos, ci_pos_l, ci_pos_u])

                    if sampling_neg_arr is not None:
                        neg_psi_arr_all = self._cal_arr_psi(sampling_neg_arr)
                        neg_psi_arr_val = self._cal_arr_psi(sampling_neg_arr[:,2:,:])
                        for psi_arr in [neg_psi_arr_all, neg_psi_arr_val]:
                            _, psi_avg_neg, psi_std_neg, pv_neg, ci_neg_l, ci_neg_u = self._psi_stats(
                                psi_arr, mu = psi_params.get('neg_thresh', 0.1)
                            )
                            neg_psi_info.append([psi_avg_neg, psi_std_neg, pv_neg, ci_neg_l, ci_neg_u])


                    if psi_only_val:
                        test_psi_tot = tot_psi_info[1] if len(tot_psi_info) > 1 else [np.nan]*5
                        test_psi_pos = pos_psi_info[1] if len(pos_psi_info) > 1 else [np.nan]*5
                        test_psi_neg = neg_psi_info[1] if len(neg_psi_info) > 1 else [np.nan]*5
                    else:
                        test_psi_tot = tot_psi_info[0] if len(tot_psi_info) > 1 else [np.nan]*5
                        test_psi_pos = pos_psi_info[0] if len(pos_psi_info) > 1 else [np.nan]*5
                        test_psi_neg = neg_psi_info[0] if len(neg_psi_info) > 1 else [np.nan]*5

                    # 判断是否剔除变量
                    if (test_psi_tot[2] < psi_params.get('tot_alpha', 0.05) or
                        test_psi_pos[2] < psi_params.get('pos_alpha', 0.05) or
                        test_psi_neg[2] < psi_params.get('neg_alpha', 0.05)):
                        removed_vars.append(col)

                        # 打印PSI详情
                        if verbose:
                            x_name = f"{col}:{self.x_cols_desc.get(col)}" if self.x_cols_desc.get(col) is not None else str(col)
                            col_trunc, slen = format_str(x_name, max_len=40)
                            try:
                                # 打印Total PSI
                                if pd.notna(test_psi_tot[2]):
                                    psi, stderr, pv, lower, upper = test_psi_tot
                                    out_str = f"{col_trunc:<{slen}s} | Total PSI: {psi:^6.4f} | stderr: {stderr:^6.4f} | p-value: {pv:^6.4f} | [0.25 0.975]: [{lower:^6.4f} {upper:^6.4f}]"
                                    print("-" * (len(out_str) + 40 - slen))
                                    print(out_str)

                                # 打印POS/NEG PSI
                                if pd.notna(test_psi_pos[2]):
                                    psi, stderr, pv, lower, upper = test_psi_pos
                                    out_str = f"{col_trunc:<{slen}s} | POS   PSI: {psi:^6.4f} | stderr: {stderr:^6.4f} | p-value: {pv:^6.4f} | [0.25 0.975]: [{lower:^6.4f} {upper:^6.4f}]"
                                    print(out_str)
                                if pd.notna(test_psi_neg[2]):
                                    psi, stderr, pv, lower, upper = test_psi_neg
                                    out_str = f"{col_trunc:<{slen}s} | NEG   PSI: {psi:^6.4f} | stderr: {stderr:^6.4f} | p-value: {pv:^6.4f} | [0.25 0.975]: [{lower:^6.4f} {upper:^6.4f}]"
                                    print(out_str)
                                print("-" * (len(out_str) + 40 - slen))
                            except:
                                continue
                # PSI, stderr, p-value, lower, upper
                div_psi_info = {
                    'totPSI': tot_psi_info,
                    'posPSI': pos_psi_info,
                    'negPSI': neg_psi_info
                }
                psi_info[col] = div_psi_info

        # 更新结果
        removed_vars = list(set(removed_vars))
        selected_vars = [col for col in x_cols_list if col not in removed_vars]
        self.results['removed_vars']['psi_high'] = removed_vars
        self.results['selected_vars'] = selected_vars
        self.results['psi_info'] = psi_info

        # 打印结果
        self._print_filter_result("PSI过高", selected_vars, removed_vars)
        return selected_vars, removed_vars


    @_timeit
    def filter_iv(self, 
         df: pd.DataFrame = None, 
         x_cols_list: List[str] = None, 
         ylabel: str = None, 
         x_bins_dict: Dict[str, List[float]] = None, 
         x_origin_to_code: Optional[Dict[str, Dict[Any, Any]]] = None,
         threshold: float = 0.01, 
         verbose: bool = None,
        ) -> Tuple[pd.DataFrame, List[str], List[str]]:
        """
        IV值筛选:
        df: pd.DataFrame
            数据集
        x_cols_list: list
            自变量列表
        ylabel: str
            因变量名
        x_bins_dict: Dict
            自变量分箱字典，{"变量名": [1,2,3,4]}
        x_origin_to_code: Dict,
            分类型自变量做数字型转化编码映射字典，格式：{变量名：{原值：替换值}}
            若x_column为分类型变量且df为未做编码前数据则需要传入。
        threshold: float
            IV筛选阈值
        verbose: bool
            是否打印冗余信息
        """
        df = self.df if df is None else df
        x_bins_dict = self.results['x_bins_dict']   if x_bins_dict is None else x_bins_dict
        x_cols_list = self.results['selected_vars'] if x_cols_list is None else x_cols_list
        verbose = self.verbose if verbose is None else verbose
        ylabel  = self.ylabel  if ylabel  is None else ylabel
        if df is None or df.empty:
            raise ValueError(f"df 不可为：{df}")
        if x_bins_dict is None or len(x_bins_dict) == 0:
            raise ValueError(f"x_bins_dict 不可为：{x_bins_dict}")
        if x_cols_list is None or len(x_cols_list) == 0:
            raise ValueError(f"x_cols_list 不可为：{x_cols_list}")
        if pd.isna(ylabel):
            raise ValueError(f"ylabel 不可为：{ylabel}")
        validate_cols(df, list(x_cols_list) + [ylabel], "IV筛选数据集")
        if x_origin_to_code is not None and not isinstance(x_origin_to_code, dict):
            raise TypeError(f"x_origin_to_code 必须是字典类型或None，当前类型：{type(x_origin_to_code)}")

        x_cols_list = list(x_cols_list)
        y_arr = df[ylabel].values.astype(float)
        pos = self.label_mapping.get('positive', 1)
        neg = self.label_mapping.get('negative', 0)
        neg_count = float(len(y_arr[y_arr == neg]))
        pos_count = float(len(y_arr[y_arr == pos]))
        
        if verbose:
            print('NegCount: {0:8.0f}  PosCount: {1:8.0f} '.format(neg_count, pos_count))
        
        df_out = []
        with tqdm(x_cols_list, ascii=True, desc='计算变量IV') as pbar:
            for idx, icol in enumerate(pbar):
                row = {}
                special_vals = np.unique(self.special_vals_dict.get(icol, []))
                bin_arr = np.sort(np.unique(x_bins_dict.get(icol, [-np.inf, np.inf])))
                bin_arr = [ival for ival in bin_arr if (ival != self.fill_null_value) & (pd.notna(ival))]
                null_mask = df[icol].isna()
                col_series = df[icol].fillna(self.fill_null_value)
                if isinstance(x_origin_to_code, dict) and (icol in x_origin_to_code):
                    fill_map = x_origin_to_code[icol]
                    if isinstance(fill_map, dict) and fill_map:
                        # 匹配则替换，未匹配则-1
                        col_series = col_series.map(fill_map)
                        # 只有非原始空值的 NaN（即未匹配）才填 -1
                        col_series = col_series.mask(~null_mask & col_series.isna(), -1)
                x_arr = col_series.values.astype(float)
                x_arr_y1 = x_arr[y_arr == pos]
                x_arr_y0 = x_arr[y_arr == neg]
                y1_mask = (x_arr_y1 != self.fill_null_value) & pd.notna(x_arr_y1)
                y0_mask = (x_arr_y0 != self.fill_null_value) & pd.notna(x_arr_y0)

                iv_total = 0
                if np.sum((x_arr == self.fill_null_value) | pd.isna(x_arr)) > 0:
                    pos_cnt = np.sum((x_arr_y1 == self.fill_null_value) | pd.isna(x_arr_y1))
                    neg_cnt = np.sum((x_arr_y0 == self.fill_null_value) | pd.isna(x_arr_y0))
                    pos_pct = pos_cnt / pos_count if pos_count > 0 else 0
                    neg_pct = neg_cnt / neg_count if neg_count > 0 else 0
                    _, _, _, iv = weight_ratio(
                        pos_pct, neg_pct, r_soft_limit = self.null_r_soft_limit, r_hard_limit = self.null_r_hard_limit
                        )
                    iv_total += iv
                for u in range(len(bin_arr) - 1):
                    left  = bin_arr[u]
                    right = bin_arr[u + 1]
                    pos_cnt = len(x_arr_y1[(x_arr_y1 > left) & (x_arr_y1 <= right) & y1_mask])
                    neg_cnt = len(x_arr_y0[(x_arr_y0 > left) & (x_arr_y0 <= right) & y0_mask])
                    pos_pct = pos_cnt / pos_count if pos_count > 0 else 0
                    neg_pct = neg_cnt / neg_count if neg_count > 0 else 0
                    if (len(special_vals) > 0) and (right in special_vals):
                        r_soft_limit = self.special_r_soft_limit
                        r_hard_limit = self.special_r_hard_limit
                    else:
                        r_soft_limit = self.gen_r_limit
                        r_hard_limit = None
                    _, _, _, iv = weight_ratio(
                        pos_pct, neg_pct, r_soft_limit = r_soft_limit, r_hard_limit = r_hard_limit
                        )
                    iv_total += iv 

                if iv_total >= threshold:
                    row['seq'], row['variable'], row['IV'] = idx + 1, icol, iv_total
                    df_out.append(row)

        df_out = pd.DataFrame(df_out)
        if not df_out.empty:
            df_out = df_out.sort_values(by='IV', ascending=False)
            df_out['seq'] = range(1, len(df_out) + 1)
        
        selected_vars = df_out['variable'].tolist() if not df_out.empty else []
        removed_vars  = [icol for icol in x_cols_list if icol not in selected_vars]
        
        # 打印结果
        self._print_filter_result("IV下限", selected_vars, removed_vars)
        if verbose:
            print()
            for _, row in df_out.iterrows():
                seq, x_name, iv_val = row['seq'], row['variable'], row['IV']
                x_name_full = f"{x_name}:{self.x_cols_desc.get(x_name)}" if self.x_cols_desc.get(x_name) is not None else str(x_name)
                s_trunc, fmt_len = format_str(x_name_full, max_len = 80)
                print(f'{seq:<3d}| variable: {s_trunc:<{fmt_len}s}  IV: {iv_val:>10.4f}')
        
        # 更新结果
        self.results['removed_vars']['iv'] = removed_vars
        self.results['selected_vars'] = selected_vars
        self.results['iv_analysis'] = df_out
        
        return df_out, selected_vars, removed_vars


    def _confusion_stats(
        self,
        seq: int,
        itv: str,
        tot_count: float,
        pos_count: float,
        neg_count: float,
        gra_count: float,
        pos_rate: float,
        gra_rate: float,
        cum_tot: float,
        cum_pos: float,
        cum_neg: float,
        iv_total: float,
        tot_cnt: float,
        pos_cnt: float,
        neg_cnt: float,
        gra_cnt: float,
        r_soft_limit: Optional[float] = None,
        r_hard_limit: Optional[float] = None,
    ) -> Tuple[int, float, float, float, float, float, Dict[str, Any]]:
        """
        计算混淆矩阵统计指标（KS/WOE/IV等）
        
        Returns
        -------
        Tuple[int, float, float, float, float, float, Dict[str, Any]]
            (序列ID, 累计总数, 累计正例, 累计负例, 累计IV, 统计行字典)
        """
        # 累计值计算
        cum_tot += tot_cnt
        cum_pos += pos_cnt
        cum_neg += neg_cnt
        cum_gra = cum_tot - cum_pos - cum_neg

        # 基础比率计算（分母保护）
        tot_pct = tot_cnt / tot_count if tot_count > 0 else 0
        pos_pct = pos_cnt / pos_count if pos_count > 0 else 0
        neg_pct = neg_cnt / neg_count if neg_count > 0 else 0
        gra_pct = gra_cnt / gra_count if gra_count > 0 else 0

        cum_tot_pct = cum_tot / tot_count if tot_count > 0 else 0
        cum_pos_pct = cum_pos / pos_count if pos_count > 0 else 0
        cum_neg_pct = cum_neg / neg_count if neg_count > 0 else 0
        cum_gra_pct = cum_gra / gra_count if gra_count > 0 else 0

        # 分箱内比率计算
        if tot_cnt == 0:
            pos_rate_bin = 0
            neg_rate_bin = 0
            gra_rate_bin = 0
        else:
            pos_rate_bin = pos_cnt / tot_cnt
            neg_rate_bin = neg_cnt / tot_cnt
            gra_rate_bin = gra_cnt / tot_cnt

        cum_pos_rate = cum_pos / cum_tot if cum_tot != 0 else 0
        cum_neg_rate = cum_neg / cum_tot if cum_tot != 0 else 0
        cum_gra_rate = cum_gra / cum_tot if cum_tot != 0 else 0

        # Lift值计算（分母保护）
        pos_lift = pos_rate_bin / pos_rate if pos_rate != 0 else 0
        gra_lift = gra_rate_bin / gra_rate if gra_rate != 0 else 0
        cum_pos_lift = cum_pos_rate / pos_rate if pos_rate != 0 else 0
        cum_gra_lift = cum_gra_rate / gra_rate if gra_rate != 0 else 0

        # 权重比KS/WOE/IV计算
        r, ks, woe, iv = weight_ratio(
            pos_pct, neg_pct, r_soft_limit = r_soft_limit, r_hard_limit = r_hard_limit
            )
        iv_total += iv
        ks_val = abs(cum_pos_pct - cum_neg_pct)

        # 构建统计行
        row = {
            'seq': seq,
            'interval': itv,
            'totCnt': tot_cnt,
            'totPct': tot_pct,
            'negCnt': neg_cnt,
            'posCnt': pos_cnt,
            'graCnt': gra_cnt,
            'negPct': neg_pct,
            'posPct': pos_pct,
            'graPct': gra_pct,
            'cumNegPct': cum_neg_pct,
            'cumPosPct': cum_pos_pct,
            'cumGraPct': cum_gra_pct,
            'cumTotPct': cum_tot_pct,
            'binPosRate': pos_rate_bin,
            'binGraRate': gra_rate_bin,
            'PosRate': pos_rate,
            'GraRate': gra_rate,
            'posLift': pos_lift,
            'graLift': gra_lift,
            'WOE': woe,
            'KS': ks_val,
            'IV': iv_total,
            'r': r,
            'cumPosRate': cum_pos_rate,
            'cumGraRate': cum_gra_rate,
            'cumPosLift': cum_pos_lift,
            'cumGraLift': cum_gra_lift,
        }

        seq += 1

        return seq, cum_tot, cum_pos, cum_neg, iv_total, row

    def fea_bins_stats(
        self,
        df: pd.DataFrame,
        x_column: str,
        ylabel: Optional[str] = None,
        bin_arr: List[float] = [],
        n_bins: int = 20,
        pattern: Optional[str] = None,
        reverse: bool = False,
        verbose: Optional[bool] = None,
        precision: Optional[int] = None,
        x_origin_to_code: Optional[Dict[str, Dict[Any, Any]]] = None,
    ) -> Tuple[pd.DataFrame, List[float]]:
        """
        特征分箱统计：计算分箱后的KS/WOE/IV等指标
        
        Parameters
        ----------
        df : pd.DataFrame
            输入数据集
        x_column : str
            自变量列名
        ylabel : str, optional
            因变量列名，默认使用实例的ylabel属性
        bin_arr : List[float], default []
            分箱边界列表，例：[-inf, 1, 2, 3, inf]
        n_bins : int, default 20
            等宽/等频分箱数（仅当bin_arr为空时生效）
        pattern : str, optional
            分箱模式：'range'=等宽分箱，其他=等频分箱
        reverse : bool, default False
            是否逆序统计分箱
        verbose : bool, optional
            是否打印详细日志，默认使用实例的verbose属性
        precision : int, optional
            小数精度，默认使用实例的precision属性
        x_origin_to_code: Dict Optional,
            分类型自变量做数字型转化编码映射字典，格式：{变量名：{原值：替换值}}
            若x_column为分类型变量且df为未做编码前数据则需要传入。
        Returns
        -------
        Tuple[pd.DataFrame, List[float]]
            (分箱统计结果DataFrame, 分箱边界列表)
        
        Raises
        ------
        ValueError
            数据集为空/列名不存在时抛出
        """
        # 参数默认值处理
        ylabel = self.ylabel if ylabel is None else ylabel
        verbose = self.verbose if verbose is None else verbose
        precision = precision if precision is not None else self.precision
        special_vals = self.special_vals_dict.get(x_column, [])
        
        # 输入校验
        if df is None or df.empty:
            raise ValueError(f"df不可为空，当前值：{df}")
        if not isinstance(x_column, str) or pd.isna(x_column):
            raise ValueError(f"x_column必须为非空字符串，当前值：{x_column}")
        if not isinstance(ylabel, str) or pd.isna(ylabel):
            raise ValueError(f"ylabel必须为非空字符串，当前值：{ylabel}")
        if x_origin_to_code is not None and not isinstance(x_origin_to_code, dict):
            raise TypeError(f"x_origin_to_code 必须是字典类型或None，当前类型：{type(x_origin_to_code)}")
        validate_cols(df, [x_column, ylabel], "分箱统计数据集")
        
        # 标签映射
        pos = self.label_mapping.get('positive', 1)
        neg = self.label_mapping.get('negative', 0)

        # 数据预处理
        y_array = df[ylabel].values.astype(float)
        null_mask = df[x_column].isna()
        col_series = df[x_column].fillna(self.fill_null_value)
        if isinstance(x_origin_to_code, dict) and (x_column in x_origin_to_code):
            fill_map = x_origin_to_code[x_column]
            if isinstance(fill_map, dict) and fill_map:
                # 匹配则替换，未匹配则-1
                col_series = col_series.map(fill_map)
                # 只有非原始空值的 NaN（即未匹配）才填 -1
                col_series = col_series.mask(~null_mask & col_series.isna(), -1)
        x_array = col_series.values.astype(float)
        
        # 基础统计
        tot_count = float(len(y_array))
        pos_count = float(len(y_array[y_array == pos]))
        neg_count = float(len(y_array[y_array == neg]))
        gra_count = tot_count - neg_count - pos_count

        pos_rate = pos_count / tot_count if tot_count > 0 else 0
        gra_rate = gra_count / tot_count if tot_count > 0 else 0

        # 生成分箱边界
        if len(bin_arr) == 0:
            # 过滤有效数值（非填充值+非空值）
            valid_x = x_array[(x_array != self.fill_null_value) & pd.notna(x_array)]
            if pattern == 'range':
                # 等宽分箱
                if len(valid_x) > 0:
                    max_v = np.max(valid_x)
                    min_v = np.min(valid_x)
                    bin_arr = np.round(np.linspace(min_v, max_v, n_bins + 1), precision)
                    bin_arr[0], bin_arr[-1] = -np.inf, np.inf
                else:
                    bin_arr = [-np.inf, np.inf]
            else:
                # 等频分箱
                bin_arr = calculate_quantiles(
                    valid_x,
                    n_bins = n_bins,
                    precision = precision,
                    unique = True,
                    include_extremes = False
                )
            
            # 包含空值分箱
            if np.sum((x_array == self.fill_null_value) | (pd.isna(x_array))) > 0:
                bin_arr = [self.fill_null_value] + list(bin_arr)

        # 分箱边界去重排序
        bin_arr_raw = np.sort(np.unique(bin_arr))
        x_arr_y1 = x_array[y_array == pos]
        x_arr_y0 = x_array[y_array == neg]

        # 日志列定义
        data_columns1 = (
            'seq','interval','totPct','negCnt','posCnt','graCnt','negPct','posPct','graPct',
            'bPosRate','bGraRate','posLift','graLift', 'IV', 'r'
        )
        data_columns2 = (
            'seq', 'interval','negCnt', 'posCnt', 'graCnt','totCnt', 'negPct', 'posPct', 'graPct', 'totPct',
            'cumNegPct', 'cumPosPct', 'cumGraPct', 'cumTotPct', 'binPosRate','binGraRate',
            'cumPosRate','cumGraRate', 'PosRate', 'GraRate', 'posLift', 'graLift',
            'cumPosLift', 'cumGraLift', 'WOE', 'KS', 'IV','r'
        )

        # 打印表头
        if verbose:
            x_name = f"{x_column}:{self.x_cols_desc.get(x_column)}" if self.x_cols_desc.get(x_column) else x_column
            print('')
            print(
                'TotalCount: {0:4.0f}  NegCount: {1:4.0f}  PosCount: {2:4.0f}  GraCount: {3:4.0f}  x_column: {4:s}'
                .format(tot_count, neg_count, pos_count, gra_count, x_name)
            )
            header = "{0:^4s}|{1:^26s}|{2:^7s}|{3:^6s}|{4:^6s}|{5:^6s}|{6:^7s}|{7:^7s}|{8:^7s}|{9:^8s}|{10:^8s}|{11:^7s}|{12:^7s}|{13:^5s}|{14:^5s}".format(*data_columns1)
            print('-' * len(header))
            print(header)
            print('-' * len(header))

        # 初始化累计变量
        cum_tot = 0.0
        cum_pos = 0.0
        cum_neg = 0.0
        iv_total = 0.0
        seq = 0
        data_list = []

        # 处理空值分箱
        if np.sum(pd.isna(bin_arr_raw)) > 0:
            itv = "nan"
            tot_cnt = len(x_array[pd.isna(x_array)])
            pos_cnt = len(x_arr_y1[pd.isna(x_arr_y1)])
            neg_cnt = len(x_arr_y0[pd.isna(x_arr_y0)])
            gra_cnt = tot_cnt - pos_cnt - neg_cnt
            
            # 计算统计指标
            seq, cum_tot, cum_pos, cum_neg, iv_total, row = self._confusion_stats(
                seq = seq, itv = itv, tot_count = tot_count, pos_count = pos_count, neg_count = neg_count, gra_count = gra_count,
                pos_rate = pos_rate, gra_rate = gra_rate, cum_tot = cum_tot, cum_pos = cum_pos, cum_neg = cum_neg, iv_total = iv_total,
                tot_cnt = tot_cnt, pos_cnt = pos_cnt, neg_cnt = neg_cnt, gra_cnt = gra_cnt, 
                r_soft_limit = self.null_r_soft_limit, r_hard_limit = self.null_r_hard_limit
                )
            data_list.append(row)
            
            # 打印空值分箱结果
            if verbose:
                print(
                    "{seq:^4d}|{interval:>26s}|{totPct:>7.2%}|{negCnt:>6.0f}|{posCnt:>6.0f}|{graCnt:>6.0f}|{negPct:>7.2%}|{posPct:>7.2%}|{graPct:>7.2%}|".format(**row) +
                    "{binPosRate:>8.2%}|{binGraRate:>8.2%}|{posLift:>7.2f}|{graLift:>7.2f}|{IV:>5.3f}|{r:>5.2f}".format(**row)
                )

        # 过滤非空分箱边界
        bin_arr = [ival for ival in bin_arr_raw if pd.notna(ival)]
        mask = pd.notna(x_array)
        y1_mask = pd.notna(x_arr_y1)
        y0_mask = pd.notna(x_arr_y0)

        # 遍历非空分箱
        for i in range(len(bin_arr) - 1):
            # 分箱边界（支持逆序）
            if reverse:
                left  = bin_arr[-(i+2)]
                right = bin_arr[-(i+1)]
            else:
                left  = bin_arr[i]
                right = bin_arr[i+1]
            
            # 分箱名称格式化
            itv = f"({round(left, precision)}, {round(right, precision)}]"
            
            # 分箱内统计
            tot_cnt = len(x_array[(x_array > left) & (x_array <= right) & mask])
            pos_cnt = len(x_arr_y1[(x_arr_y1 > left) & (x_arr_y1 <= right) & y1_mask])
            neg_cnt = len(x_arr_y0[(x_arr_y0 > left) & (x_arr_y0 <= right) & y0_mask])
            gra_cnt = tot_cnt - pos_cnt - neg_cnt

            if pd.notna(self.fill_null_value) and (right == self.fill_null_value):
                r_soft_limit = self.null_r_soft_limit
                r_hard_limit = self.null_r_hard_limit
            elif len(special_vals) > 0 and (right in special_vals):
                r_soft_limit = self.special_r_soft_limit
                r_hard_limit = self.special_r_hard_limit
            else:
                r_soft_limit = self.gen_r_limit
                r_hard_limit = None
            # 计算统计指标
            seq, cum_tot, cum_pos, cum_neg, iv_total, row = self._confusion_stats(
                seq = seq, itv = itv, tot_count = tot_count, pos_count = pos_count, neg_count = neg_count, gra_count = gra_count,
                pos_rate = pos_rate, gra_rate = gra_rate, cum_tot = cum_tot, cum_pos = cum_pos, cum_neg = cum_neg, iv_total = iv_total,
                tot_cnt = tot_cnt, pos_cnt = pos_cnt, neg_cnt = neg_cnt, gra_cnt = gra_cnt, 
                r_soft_limit = r_soft_limit, r_hard_limit = r_hard_limit
                )
            data_list.append(row)
            
            # 打印分箱结果
            if verbose:
                print(
                    "{seq:^4d}|{interval:>26s}|{totPct:>7.2%}|{negCnt:>6.0f}|{posCnt:>6.0f}|{graCnt:>6.0f}|{negPct:>7.2%}|{posPct:>7.2%}|{graPct:>7.2%}|".format(**row) +
                    "{binPosRate:>8.2%}|{binGraRate:>8.2%}|{posLift:>7.2f}|{graLift:>7.2f}|{IV:>5.3f}|{r:>5.2f}".format(**row)
                )

        # 打印分隔符
        if verbose:
            print('-' * len(header))
        
        # 构建输出DataFrame
        data_rts = [[row[col] for col in data_columns2] for row in data_list]
        data_out = pd.DataFrame(data_rts, columns = data_columns2)
        
        return data_out, bin_arr_raw

    @_timeit
    def data_stats_dict(self, 
        df: pd.DataFrame, 
        ylabel: str = None, 
        x_cols_list: List[str] = None, 
        x_bins_dict: Dict[str, List[float]] = None, 
        x_origin_to_code: Optional[Dict[str, Dict[Any, Any]]] = None,
        verbose: bool = None,
    ) -> Dict[str, pd.DataFrame]:
        """
        批量分箱统计
        df: : pd.DataFrame
            输入数据集
        ylabel: str, optional
            因变量列名，默认使用实例的ylabel属性
        x_cols_list: list
            自变量列表
        x_bins_dict: dict
            自变量分箱字典，{"变量名": [1,2,3,4]}
        x_origin_to_code: dict
            分类型自变量做数字型转化编码映射字典，格式：{变量名：{原值：替换值}}
            若x_cols_list中存在分类型变量且df为未做编码前数据则需要传入。
        verbose：是否打印细节
        """
        df = self.df if df is None else df
        x_bins_dict = self.results['x_bins_dict']   if x_bins_dict is None else x_bins_dict
        x_cols_list = self.results['selected_vars'] if x_cols_list is None else x_cols_list
        verbose = self.verbose if verbose is None else verbose
        ylabel  = self.ylabel  if ylabel  is None else ylabel

        if df is None or df.empty:
            raise ValueError(f"df 不可为：{df}")
        if x_bins_dict is None or len(x_bins_dict) == 0:
            raise ValueError(f"x_bins_dict 不可为：{x_bins_dict}")
        if x_cols_list is None or len(x_cols_list) == 0:
            raise ValueError(f"x_cols_list 不可为：{x_cols_list}")
        if pd.isna(ylabel):
            raise ValueError(f"ylabel 不可为：{ylabel}")
        validate_cols(df, list(x_cols_list) + [ylabel], "有标签分箱统计数据集")
        if x_origin_to_code is not None and not isinstance(x_origin_to_code, dict):
            raise TypeError(f"x_origin_to_code 必须是字典类型或None，当前类型：{type(x_origin_to_code)}")

        stats_dict = {}
        with tqdm(x_cols_list, ascii=True, desc='分箱数据统计') as pbar:
            for icol in pbar:
                stats_dict[icol], _ = self.fea_bins_stats(
                    df, x_column = icol, ylabel = ylabel, bin_arr = list(x_bins_dict[icol]), 
                    reverse = False, verbose = verbose, x_origin_to_code = x_origin_to_code,
                )
        return stats_dict


    def fea_bins_no_label(self, 
        df: pd.DataFrame = None, 
        x_column: str = None, 
        n_bins: int = 16, 
        bin_arr: List[float] = [], 
        pattern: Optional[str] = None,
        reverse: bool = False, 
        precision: int = None, 
        verbose: bool = True, 
        x_origin_to_code: Dict[str, Dict[Any, float]] = None,
    ) -> Tuple[pd.DataFrame, np.ndarray]:
        """
        无标签分箱统计
        df: pd.DataFrame
            数据集
        x_column: str
            自变量名称
        n_bins: int
            等宽或等频分箱个数，只有在bin_arr为空[]的情况下传入值生效
        bin_arr: list
            自变量分箱列表， eg：[-inf, 1, 2, 3, 4, inf]
        pattern: str
            分箱模式，'range'表示等宽，否则等频，只有在bin_arr为空[]的情况下传入值生效
        reverse: bool
            是否按bin_arr逆序统计
        precision: int
            分箱点小数精确位数
        verbose: bool
            是否打印细节
        x_origin_to_code: Dict[str, Dict[Any, float]] = None
            分类型变量做排序型编码的字典，如果提供原数据样本集df分类变量是未编码的，则需要提供
        """
        df = self.df if df is None else df
        precision = self.precision if precision is None else precision
        verbose   = self.verbose   if verbose   is None else verbose
        if df is None or df.empty:
            raise ValueError(f"df 不可为：{df}")
        if pd.isna(x_column):
            raise ValueError(f"x_column 不可为：{x_column}")
        validate_cols(df, [x_column], "无标签分箱统计数据集")
        if x_origin_to_code is not None and not isinstance(x_origin_to_code, dict):
            raise TypeError(f"x_origin_to_code 必须是字典类型或None，当前类型：{type(x_origin_to_code)}")
        
        data_list = []
        null_mask = df[x_column].isna()
        col_series = df[x_column].fillna(self.fill_null_value)
        if isinstance(x_origin_to_code, dict) and (x_column in x_origin_to_code):
            fill_map = x_origin_to_code[x_column]
            if isinstance(fill_map, dict) and fill_map:
                # 匹配则替换，未匹配则-1
                col_series = col_series.map(fill_map)
                col_series = col_series.mask(~null_mask & col_series.isna(), -1)
        x_array = col_series.values.astype(float)
        
        total_count = float(len(x_array))
        cum_total = 0
        
        if verbose:
            print('')
            print(f'TotalCount: {total_count:7.0f} x_column: {x_column:s}')
        
        if len(bin_arr) == 0:
            if pattern == 'range':
                max_v = max(x_array[(x_array != self.fill_null_value) & pd.notna(x_array)])
                min_v = min(x_array[(x_array != self.fill_null_value) & pd.notna(x_array)])
                bin_arr = np.round(np.linspace(min_v, max_v, n_bins + 1), precision)
                bin_arr[0], bin_arr[-1] = -np.inf, np.inf
            else:
                bin_arr = calculate_quantiles(x_array[(x_array != self.fill_null_value) & pd.notna(x_array)], 
                    n_bins = n_bins, precision = precision, unique = True, include_extremes = False)
            if np.sum((x_array == self.fill_null_value) | (pd.isna(x_array))) > 0:
                bin_arr = [self.fill_null_value] + list(bin_arr)
        bin_arr_raw = np.sort(np.unique(bin_arr))

        seq = 0
        data_columns1 = ('seq','Interval','totCnt','cumTotal','TotalCount', 'totPct', 'cumTotPct')
        header = "{0:^4s}|{1:^14s}|{2:^8s}|{3:^8s}|{4:^10s}|{5:^7s}|{6:^9s}".format(*data_columns1)
        
        if verbose:
            print('-'*len(header))
            print(header)
            print('-'*len(header))

        if (np.sum(pd.isna(bin_arr_raw)) > 0):
            row = {}
            itv = "NULL"
            tot_cnt = len(x_array[pd.isna(x_array)])
            cum_total += tot_cnt
            tot_pct = tot_cnt / total_count if total_count > 0 else 0
            cum_tot_pct = cum_total / total_count if total_count > 0 else 0
            row['seq'] = seq
            row['Interval'] = itv
            row['totCnt']   = tot_cnt
            row['cumTotal'] = cum_total
            row['TotalCount'] = total_count
            row['totPct'] = tot_pct
            row['cumTotPct'] = cum_tot_pct

            data_list.append(row)
            if verbose:
                print("{seq:^4d}|{Interval:>14s}|{totCnt:>8.0f}|{cumTotal:>8.0f}|{TotalCount:>10.0f}|{totPct:>7.2%}|{cumTotPct:>9.2%}".format(**row))
            seq += 1

        bin_arr = [ival for ival in bin_arr_raw if pd.notna(ival)]
        mask = pd.notna(x_array)
        for idx in range(len(bin_arr)-1):
            row = {}
            if reverse:
                left  = bin_arr[-(idx+2)]
                right = bin_arr[-(idx+1)]
            else:
                left  = bin_arr[idx]
                right = bin_arr[idx+1]

            tot_cnt = len(x_array[(x_array > left) & (x_array <= right) & mask])
            cum_total += tot_cnt
            tot_pct = tot_cnt / total_count if total_count > 0 else 0
            cum_tot_pct = cum_total / total_count if total_count > 0 else 0
            itv = "(" + str(round(left, precision)) + ", " + str(round(right, precision)) + "]"

            row['seq'] = seq
            row['Interval'] = itv
            row['totCnt']   = tot_cnt
            row['cumTotal'] = cum_total
            row['TotalCount'] = total_count
            row['totPct'] = tot_pct
            row['cumTotPct'] = cum_tot_pct

            data_list.append(row)
            if verbose:
                print("{seq:^4d}|{Interval:>14s}|{totCnt:>8.0f}|{cumTotal:>8.0f}|{TotalCount:>10.0f}|{totPct:>7.2%}|{cumTotPct:>9.2%}".format(**row))
            seq += 1
        
        data_map = [[row[col] for col in data_columns1] for row in data_list]
        data_out = pd.DataFrame(data_map, columns=data_columns1)
        
        return data_out, bin_arr_raw

    @_timeit
    def fit_var_bins_woe(self, 
        df: pd.DataFrame = None, 
        x_cols_list: List[str] = None, 
        ylabel: str = None, 
        x_bins_dict: Dict[str, List[float]] = None, 
        x_origin_to_code: Dict[str, Dict[Any, float]] = None,
        gen_r_limit: Optional[float] = None, 
        null_r_soft_limit: Optional[float] = None, 
        null_r_hard_limit: Optional[float] = None,
        special_r_soft_limit: Optional[float] = None, 
        special_r_hard_limit: Optional[float] = None, 
        verbose: bool = None,
        ) -> Dict[str, Dict[pd.Interval, float]]:
        """
        WOE转换
        df: 原数据样本集，不传则取初始化的参数
        x_cols_list List[str]: 
            需要转换的自变量列表，不传参则取前置环节筛选的变量
        x_bins_dict: Dict[str, List[float]] 
            自变量分箱结果字典，不传则取前置环节处理过的分箱
        x_origin_to_code: Dict[str, Dict[Any, float]] = None
            分类型变量做排序型编码的字典，如果提供原数据样本集df分类变量是未编码的，则需要提供
        gen_r_limit : Optional[float]
            通用WOE软约束值, 基于 r = posPct/negPct 设定
        null_r_soft_limit : Optional[float]
            空值WOE软约束值, 基于 r = posPct/negPct 设定
        null_r_hard_limit : Optional[float]
            空值WOE硬约束值（强制覆盖）, 基于 r = posPct/negPct 设定
        special_r_soft_limit : Optional[float]
            特殊值WOE软约束值, 基于 r = posPct/negPct 设定
        special_r_hard_limit : Optional[float]
            特殊值WOE硬约束值（强制覆盖）, 基于 r = posPct/negPct 设定
        verbose: 是否显示冗余信息
        """
        df = self.df if df is None else df
        x_bins_dict = self.results['x_bins_dict']   if x_bins_dict is None else x_bins_dict
        x_cols_list = self.results['selected_vars'] if x_cols_list is None else x_cols_list
        verbose = self.verbose if verbose is None else verbose
        ylabel  = self.ylabel  if ylabel  is None else ylabel
        gen_r_limit = self.gen_r_limit if gen_r_limit is None else gen_r_limit
        null_r_soft_limit = self.null_r_soft_limit if null_r_soft_limit is None else null_r_soft_limit
        null_r_hard_limit = self.null_r_hard_limit if null_r_hard_limit is None else null_r_hard_limit
        special_r_soft_limit = self.special_r_soft_limit if special_r_soft_limit is None else special_r_soft_limit
        special_r_hard_limit = self.special_r_hard_limit if special_r_hard_limit is None else special_r_hard_limit
        if df is None or df.empty:
            raise ValueError(f"df 不可为：{df}")
        if x_bins_dict is None or len(x_bins_dict) == 0:
            raise ValueError(f"x_bins_dict 不可为：{x_bins_dict}")
        if x_cols_list is None or len(x_cols_list) == 0:
            raise ValueError(f"x_cols_list 不可为：{x_cols_list}")
        if pd.isna(ylabel):
            raise ValueError(f"ylabel 不可为：{ylabel}")
        validate_cols(df, list(x_cols_list) + [ylabel], "WOE转换数据集")
        if x_origin_to_code is not None and not isinstance(x_origin_to_code, dict):
            raise TypeError(f"x_origin_to_code 必须是字典类型或None，当前类型：{type(x_origin_to_code)}")
        pos = self.label_mapping.get('positive', 1)
        neg = self.label_mapping.get('negative', 0)
        y_arr = df[ylabel].values.astype(float)
        neg_count = float(len(y_arr[y_arr == neg]))
        pos_count = float(len(y_arr[y_arr == pos]))
        
        if verbose:
            print('NegCount: {0:8.1f}  PosCount: {1:8.1f} '.format(neg_count, pos_count))

        variable_bins_woe = {}
        with tqdm(x_cols_list, ascii=True, desc='计算变量WOE映射字典') as pbar:
            for icol in pbar:
                if verbose:
                    x_name = f"{icol}:{self.x_cols_desc.get(icol)}" if self.x_cols_desc.get(icol) is not None else icol
                    print(x_name)
                special_vals = self.special_vals_dict.get(icol, [])
                null_mask = df[icol].isna()
                col_series = df[icol].fillna(self.fill_null_value)
                if isinstance(x_origin_to_code, dict) and (icol in x_origin_to_code):
                    fill_map = x_origin_to_code[icol]
                    if isinstance(fill_map, dict) and fill_map:
                        # 匹配则替换，未匹配则-1
                        col_series = col_series.map(fill_map)
                        col_series = col_series.mask(~null_mask & col_series.isna(), -1)
                x_arr = col_series.values.astype(float)
                x_arr_y1 = x_arr[y_arr == pos]
                x_arr_y0 = x_arr[y_arr == neg]
                
                woe_map = {}
                bins_arr = x_bins_dict.get(icol, [-np.inf, np.inf])
                bin_arr_raw = np.sort(np.unique(bins_arr))
                
                if (np.sum(pd.isna(bin_arr_raw)) > 0):
                    interval = np.nan
                    pos_cnt = len(x_arr_y1[pd.isna(x_arr_y1)])
                    neg_cnt = len(x_arr_y0[pd.isna(x_arr_y0)])
                    pos_pct = pos_cnt / pos_count if pos_count > 0 else 0
                    neg_pct = neg_cnt / neg_count if neg_count > 0 else 0
                    r, ks, woe, iv = weight_ratio(
                        pos_pct, neg_pct, r_soft_limit = null_r_soft_limit, r_hard_limit = null_r_hard_limit
                        )
                    woe_map[interval] = woe
                    if verbose:
                        print("X=|{0:>30s} | posCnt:|{1:>8d} | negCnt:|{2:>8d} | posPct:|{3:>6.2%} | negPct:|{4:>6.2%} | WOE:|{5:>6.3f} "\
                            .format(str(interval), pos_cnt, neg_cnt, pos_pct, neg_pct, woe))

                bins_arr = [ival for ival in bin_arr_raw if pd.notna(ival)]
                y1_mask = pd.notna(x_arr_y1)
                y0_mask = pd.notna(x_arr_y0)
                for idx in range(len(bins_arr) - 1):
                    left  = bins_arr[idx]
                    right = bins_arr[idx + 1]
                    pos_cnt = len(x_arr_y1[(x_arr_y1 > left) & (x_arr_y1 <= right) & y1_mask])
                    neg_cnt = len(x_arr_y0[(x_arr_y0 > left) & (x_arr_y0 <= right) & y0_mask])
                    pos_pct = pos_cnt / pos_count if pos_count > 0 else 0
                    neg_pct = neg_cnt / neg_count if neg_count > 0 else 0

                    if pd.notna(self.fill_null_value) and (right == self.fill_null_value):
                        r_soft_limit = null_r_soft_limit
                        r_hard_limit = null_r_hard_limit
                    elif len(special_vals) > 0 and (right in special_vals):
                        r_soft_limit = special_r_soft_limit
                        r_hard_limit = special_r_hard_limit
                    else:
                        r_soft_limit = gen_r_limit
                        r_hard_limit = None
                    r, ks, woe, iv = weight_ratio(
                        pos_pct, neg_pct, r_soft_limit = r_soft_limit, r_hard_limit = r_hard_limit,
                        )
                    if pd.isna(woe):
                        raise ValueError(f"pos_pct: {pos_pct}, neg_pct: {neg_pct}")
                    interval = pd.Interval(left = left, right = right)
                    woe_map[interval] = woe
                    
                    if verbose:
                        print("X=|{0:>30s} | posCnt:|{1:>8d} | negCnt:|{2:>8d} | posPct:|{3:>6.2%} | negPct:|{4:>6.2%} | WOE:|{5:>6.3f} "\
                            .format(str(interval), pos_cnt, neg_cnt, pos_pct, neg_pct, woe))
                if verbose:
                    print()
                
                variable_bins_woe[icol] = woe_map
        self.results['var_bins_woe'] = variable_bins_woe
        return variable_bins_woe


    @_timeit
    def df_woe_encoding(self, 
        df: pd.DataFrame = None, 
        x_cols_list: List[str] = None, 
        var_bins_woe: Dict[str, Dict[Any, float]] = None, 
        other_columns: List[str] = [], 
        x_origin_to_code: Dict[str, Dict[Any, float]] = {},
        fill_null_value: Optional[Union[int, float]] = None,
        ) -> pd.DataFrame:
        """
        WOE转换
        df: 原数据样本集，不传则取初始化的参数
        x_cols_list: 需要转换的自变量列表，不传参则取前置环节筛选的变量
        var_bins_woe: Dict[str, List[float]] 
            自变量分箱区间对应的WOE值字典，不传则取前置环节计算的结果
        other_columns: 其他需要加入woe表的字段列表，默认为[]
        x_origin_to_code: Dict[str, Dict[Any, float]] = {}
            分类型变量做排序型编码的字典，如果提供原数据样本集df分类变量是未编码的，则需要提供
        """
        df = self.df if df is None else df
        var_bins_woe = self.results['var_bins_woe']  if var_bins_woe is None else var_bins_woe
        x_cols_list = self.results['selected_vars'] if x_cols_list is None else x_cols_list
        fill_null_value = fill_null_value if fill_null_value is not None else self.fill_null_value
        if df is None or df.empty:
            raise ValueError(f"df 不可为：{df}")
        if var_bins_woe is None or len(var_bins_woe) == 0:
            raise ValueError(f"var_bins_woe 不可为：{var_bins_woe}")
        if x_cols_list is None or len(x_cols_list) == 0:
            raise ValueError(f"x_cols_list 不可为：{x_cols_list}")
        validate_cols(df, list(x_cols_list), "WOE转换数据集")
        if x_origin_to_code is not None and not isinstance(x_origin_to_code, dict):
            raise TypeError(f"x_origin_to_code 必须是字典类型或None，当前类型：{type(x_origin_to_code)}")

        df_woe = pd.DataFrame()
        if other_columns:
            for icol in other_columns:
                if icol in df.columns:
                    df_woe[icol] = df[icol].values
                else:
                     print(f"warning: df 缺失other_columns中列: {icol}, 已忽略...")

        with tqdm(x_cols_list, ascii=True, desc='转换WOE表') as pbar:
            for icol in pbar:
                null_mask = df[icol].isna()
                col_series = df[icol].fillna(fill_null_value)
                if isinstance(x_origin_to_code, dict) and (icol in x_origin_to_code):
                    fill_map = x_origin_to_code[icol]
                    if isinstance(fill_map, dict) and fill_map:
                        # 匹配则替换，未匹配则-1
                        col_series = col_series.map(fill_map)
                        col_series = col_series.mask(~null_mask & col_series.isna(), -1)

                woe_map = var_bins_woe.get(icol)
                if isinstance(woe_map, dict) and woe_map:
                    df_woe[icol] = self._intervals_map(woe_map, col_series)
                else:
                    print(f"warning: var_bins_woe 缺失x_cols_list中key或为空: {icol}, 已忽略...")
        return df_woe


    @_timeit
    def filter_corr_coef(self, 
        df: pd.DataFrame = None, 
        x_cols_list: List[str] = None, 
        df_iv: pd.DataFrame  = None, 
        corr_thresh: float = 0.85,
        ) -> Tuple[List[str], List[str]]:
        """
        筛选逻辑：过滤相关系数过高且IV较小的变量
        df: 训练数据集，通常为woe编码后的宽表，pd.DataFrame
        x_cols_list: 自变量列表
        df_iv: 自变量IV信息表，pd.DataFrame, 需包含['variable', 'IV']两个字段
        corr_thresh: 相关系数阈值（高于此值且IV更小的变量会被剔除）
        """
        # 参数校验
        df = self.df if df is None else df
        x_cols_list = self.results['selected_vars'] if x_cols_list is None else x_cols_list
        df_iv = self.results['iv_analysis'] if df_iv is None else df_iv
        if df is None or df.empty:
            raise ValueError(f"df 不可为：{df}")
        if x_cols_list is None or len(x_cols_list) == 0:
            raise ValueError(f"x_cols_list 不可为：{x_cols_list}")
        if df_iv is None or df_iv.empty:
            raise ValueError(f"df_iv 不可为：{df_iv}")

        validate_cols(df, list(x_cols_list), "相关系数筛选数据集")
        validate_cols(df_iv, ['variable', 'IV'], "IV数据集")

        # 计算相关系数矩阵
        if self.verbose:
            print('计算相关系数矩阵中...')
        var_array = np.array(x_cols_list)
        data_array = df[x_cols_list].values
        corr_matrix = np.corrcoef(data_array, rowvar = False)

        # 筛选高相关变量
        removed_vars = []
        with tqdm(range(len(var_array)), ascii=True, desc='过滤高相关变量') as pbar:
            for idx in pbar:
                col_left = var_array[idx]
                if col_left in removed_vars:
                    continue

                # 获取高相关变量
                corr_vals = corr_matrix[idx]
                high_corr_vars = var_array[corr_vals >= corr_thresh]

                # 获取左侧变量IV
                left_iv_vals = df_iv[df_iv['variable'] == col_left]['IV'].values
                left_iv = left_iv_vals[0] if len(left_iv_vals) > 0 else 0

                # 比较IV值，剔除IV较小的变量
                to_remove = []
                for col_right in high_corr_vars:
                    if col_right == col_left or col_right in removed_vars:
                        continue

                    # 获取右侧变量IV
                    right_iv_vals = df_iv[df_iv['variable'] == col_right]['IV'].values
                    right_iv = right_iv_vals[0] if len(right_iv_vals) > 0 else 0

                    if left_iv < right_iv:
                        to_remove = [col_left]
                        break
                    else:
                        to_remove.append(col_right)

                removed_vars.extend(to_remove)

        # 更新结果
        removed_vars = list(set(removed_vars))
        selected_vars = [col for col in var_array if col not in removed_vars]
        self.results['removed_vars']['corr_coef'] = removed_vars
        self.results['selected_vars'] = selected_vars
        self.results['corr_info'] = {
            'corr_matrix': corr_matrix,
            'var_order': x_cols_list
        }

        # 打印结果
        self._print_filter_result("高相关", selected_vars, removed_vars)
        return selected_vars, removed_vars


    @_timeit
    def filter_vif(self, 
        df: pd.DataFrame = None, 
        x_cols_list: List[str] = None, 
        df_iv: pd.DataFrame = None, 
        vif_thresh: float = 10.0,
        ) -> Tuple[List[str], List[str], dict]:
        """
        筛选逻辑：基于VIF剔除多重共线性变量（按IV升序优先剔除）
        df: 训练数据集，通常为woe编码后的宽表，pd.DataFrame
        x_cols_list: 自变量列表
        df_iv: 自变量IV信息表，pd.DataFrame, 需包含['variable', 'IV']两个字段
        vif_thresh: VIF阈值（高于此值剔除多重共线性变量）
        """
        # 参数校验
        df = self.df if df is None else df
        x_cols_list = self.results['selected_vars'] if x_cols_list is None else x_cols_list
        df_iv = self.results['iv_analysis'] if df_iv is None else df_iv
        if df is None or df.empty:
            raise ValueError(f"df 不可为：{df}")
        if x_cols_list is None or len(x_cols_list) == 0:
            raise ValueError(f"x_cols_list 不可为：{x_cols_list}")
        if df_iv is None or df_iv.empty:
            raise ValueError(f"df_iv 不可为：{df_iv}")

        validate_cols(df, list(x_cols_list), "VIF数据集")
        validate_cols(df_iv, ['variable', 'IV'], "IV数据集")

        # 按IV升序排序
        iv_list = []
        for col in x_cols_list:
            iv_vals = df_iv[df_iv['variable'] == col]['IV'].values
            if len(iv_vals) == 0:
                raise ValueError(f"df_iv中无【{col}】变量IV")
            iv = iv_vals[0] if len(iv_vals) > 0 else 0
            iv_list.append([col, iv])
        iv_list_sorted = sorted(iv_list, key=lambda x: x[1])
        x_cols_list_sorted = [x[0] for x in iv_list_sorted]

        # 计算VIF
        vif_info = {}
        removed_vars = []
        candidate_vars = list(copy.deepcopy(x_cols_list))

        with tqdm(x_cols_list_sorted, ascii=True, desc='计算方差膨胀因子') as pbar:
            for col in pbar:
                if col not in candidate_vars:
                    continue

                # 构建自变量矩阵
                x_cols = [c for c in candidate_vars if c != col]
                if not x_cols:
                    break

                try:
                    x = df[x_cols].fillna(0).values.astype(float)
                    x = sm.add_constant(x)
                    y = df[col].fillna(0).values.astype(float)

                    # 拟合OLS模型
                    model = sm.OLS(y, x).fit()
                    r2  = model.rsquared
                    vif = 1 / (1 - r2) if (1 - r2) > 1e-10 else np.inf
                    vif_info[col] = vif

                    # 判断是否剔除
                    if vif >= vif_thresh:
                        candidate_vars.remove(col)
                        removed_vars.append(col)

                        # 打印VIF详情
                        if self.verbose:
                            col_trunc, slen = format_str(str(col), max_len=40)
                            print(f"{col_trunc:{slen}s}:  {vif:<8.4f}")
                except Exception as e:
                    if self.verbose:
                        print(f"变量{col}计算VIF失败：{str(e)}")
                    vif_info[col] = np.inf
                    removed_vars.append(col)
                    candidate_vars.remove(col)

        # 更新结果
        removed_vars = list(set(removed_vars))
        selected_vars = [col for col in x_cols_list if col not in removed_vars]
        self.results['removed_vars']['vif'] = removed_vars
        self.results['selected_vars'] = selected_vars
        self.results['vif_info'] = vif_info

        # 打印结果
        self._print_filter_result("VIF过高", selected_vars, removed_vars)
        return selected_vars, removed_vars, vif_info

