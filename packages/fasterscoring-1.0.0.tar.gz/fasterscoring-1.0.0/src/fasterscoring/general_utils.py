# -*- coding: utf-8 -*-
"""
数据预处理 (Utils Module)
=============================================
版本: 1.0.0
作者: Faster Scoring Team XM
功能: 通用功能工具
依赖:
pandas >= 1.2.0, numpy >= 1.20.0
"""
import os
import time
import shutil
import warnings
import numpy as np
import pandas as pd
from pathlib import Path
import json
from typing import Dict, List, Tuple, Union, Optional, Any

# 忽略非关键警告
warnings.filterwarnings('ignore')


def format_str(s: str, max_len: int = 40) -> Tuple[str, int]:
    """
    私有工具：中文字符兼容的字符串截断+格式化长度计算
    
    Parameters
    ----------
    s : str
        待格式化字符串
    max_len : int, default=40
        最大显示长度（中文字符占2位，英文占1位）
    
    Returns
    -------
    Tuple[str, int]
        (截断后的字符串, 格式化显示长度)
    """
    ch_count = 0  # 中文字符数
    trunc_pos = 0  # 截断位置

    for char in s:
        trunc_pos += 1
        try:
            if len(char.encode('utf-8')) > 1:
                ch_count += 1
        except:
            pass
        if (trunc_pos + ch_count) >= max_len:
            break

    extra = trunc_pos + ch_count - max_len if (trunc_pos + ch_count) >= max_len else 0
    trunc_pos = trunc_pos - extra
    s_trunc = s[:trunc_pos]
    fmt_len = max_len - ch_count + extra

    return s_trunc, fmt_len


def validate_cols(df: pd.DataFrame, cols: List[str], name: str = "数据集") -> None:
    """
    私有工具：校验DataFrame是否包含指定列，缺失则抛异常
    
    Parameters
    ----------
    df : pd.DataFrame
        待校验数据集
    cols : List[str]
        需要校验的列名列表
    name : str, default="数据集"
        数据集名称（用于异常提示）
    
    Raises
    ------
    ValueError
        缺失列时抛出异常
    """
    if not isinstance(df, pd.DataFrame):
        raise TypeError(f"{name}必须是pandas.DataFrame类型")
    
    missing_cols = [col for col in cols if col not in df.columns]
    if missing_cols:
        raise ValueError(f"{name}缺失列：{missing_cols}")

def unique_list(lst: List[Any]) -> List[Any]:
    """
    私有工具：保持顺序的列表去重
    
    Parameters
    ----------
    lst : List[Any]
        待去重列表
    
    Returns
    -------
    List[Any]
        去重后的列表（保留首次出现顺序）
    """
    seen = set()
    return [x for x in lst if not (x in seen or seen.add(x))]

# ------------------------------ 分位数计算方法 ------------------------------

def calculate_quantiles(
    arr: np.ndarray,
    perc_arr: Optional[List[float]] = None,
    n_bins: Optional[int] = None,
    precision: int = 6,
    include_extremes: bool = False,
    unique: bool = True
) -> List[float]:
    """
    计算分位数（自定义分位点/等频分箱）
    
    Parameters
    ----------
    arr : np.ndarray
        输入数值数组
    perc_arr : Optional[List[float]], default=None
        自定义分位点列表（0-1之间），优先级高于n_bins
    n_bins : Optional[int], default=None
        等频分箱数（仅perc_arr=None时生效）
    precision : int, default=6
        分位数保留小数位数
    include_extremes : bool, default=False
        是否包含0/1分位点（极值）
    unique : bool, default=True
        是否对结果去重
    
    Returns
    -------
    List[float]
        分位数列表（按顺序）
    """
    # 参数校验
    arr = np.asarray(arr).astype(float)
    arr = arr[np.isfinite(arr)]  # 过滤空值/无穷值
    if len(arr) == 0:
        return []

    # 生成分位点
    if perc_arr is not None:
        perc_vals = np.array(perc_arr, dtype=float)
    elif n_bins is not None and n_bins > 0:
        step = 100.0 / n_bins
        perc_vals = np.arange(0, 100, step) / 100
    else:
        perc_vals = np.array([0.25, 0.5, 0.75])  # 默认四分位数

    # 过滤极值分位点
    if not include_extremes:
        perc_vals = perc_vals[(perc_vals > 0) & (perc_vals < 1)]
    if len(perc_vals) == 0:
        return []

    # 计算分位数
    if np.__version__ >= "2.0.0":
        quantiles = np.percentile(arr, perc_vals * 100, method = 'linear')
    else:
        quantiles = np.percentile(arr, perc_vals * 100, interpolation = 'linear')
    quantiles = np.round(quantiles, precision).tolist()

    # 等频分箱补充极值
    if n_bins is not None:
        quantiles = [-np.inf] + quantiles + [np.inf]

    # 去重
    if unique:
        quantiles = unique_list(quantiles)

    return quantiles


def weight_ratio(
    left_ratio: float,
    right_ratio: float,
    r_soft_limit: Optional[float] = None,
    r_hard_limit: Optional[float] = None,
) -> Tuple[float, float, float, float]:
    """
    left_r : float
        左侧比率（通常为pos_pct：正类占比）
    right_r : float
        右侧比率（通常为neg_pct：负类占比）
    r_soft_limit : Optional[float]
        WOE软约束值
    r_hard_limit : Optional[float]
        WOE硬约束值（强制覆盖）
    
    返回:
    --------
    Tuple[float, float, float, float]: (权重比r, KS, WOE, IV)
    """
    # 基础权重比r计算
    if left_ratio == 0 and right_ratio == 0:
        r = 1.0
    elif left_ratio == 0 and right_ratio != 0:
        r = 1.0 if right_ratio < 0.005 else 1/9
    elif left_ratio != 0 and right_ratio == 0:
        r = 1.0 if left_ratio < 0.005 else 9
    else:
        r = 1.0 if (left_ratio <= 0.005 and right_ratio <= 0.005) else (left_ratio / right_ratio)

    # WOE计算（带约束）
    woe = np.log(r)
    if pd.notna(r_soft_limit):
        soft_log = np.log(r_soft_limit)
        if np.abs(woe) > np.abs(soft_log):
            woe = np.abs(soft_log) if woe > 0 else -np.abs(soft_log)

    ks = left_ratio - right_ratio
    iv_psi = ks * woe
    # woe硬约束
    if pd.notna(r_hard_limit):
        hard_log = np.log(r_hard_limit)
        if hard_log >= 0:
            if woe < hard_log:
                woe = hard_log
        else:
            if woe > hard_log:
                woe = hard_log
    # 最终指标计算
    r_final = np.exp(woe)
    return r_final, ks, woe, iv_psi


    
# 获取包的根目录
PACKAGE_DIR = Path(__file__).parent

def get_demo(output_path: str = None):
    """
    一键将包内的 Jupyter 示例 Notebook 复制到用户当前文件夹
    :param output_path: 输出文件名/路径
    """
    # 包内 Notebook 源路径
    source_nb = PACKAGE_DIR / "xdemo" / "fts_demo.ipynb"
    if output_path is None:
        output_path = f"fts_demo{time.strftime('%Y-%m-%d_%H:%M:%S')}.ipynb"
    else:
        output_path = f"{output_path}.ipynb"
    if not source_nb.exists():
        raise FileNotFoundError(f"Demo notebook 不存在：{source_nb}")
    
    # 复制到用户目录
    shutil.copy2(source_nb, output_path)
    print(f"Demo notebook 已复制到：{os.path.abspath(output_path)}")

def load_sample():
    """
    一键加载包内的样本数据
    :return: 数据对象（DataFrame / dict 等）
    """
    data_path = PACKAGE_DIR / "xdata" / "bank-additional.xlsx"
    
    # 根据文件类型自动加载
    return pd.read_excel(data_path)

