# -*- coding: utf-8 -*-
"""
评分卡模型核心计算模块 (Model Scoring Module)
=============================================
版本信息：v1.0.0
作者: Faster Scoring Team XM
功能说明：
1. 模型评分卡生成 (fit_var_score)
2. 数据集分数计算 (data_scoring)
3. 预测分箱统计 (pred_bins_stats)
4. PSI计算（cal_psi）
5. 辅助工具（分位数计算、权重比计算、空值处理等）
"""

import pandas as pd
import numpy as np
import math
import scipy.stats as sts
from sklearn import metrics
import time
import copy
from typing import Dict, List, Optional, Union, Any, Tuple, Callable
from fasterscoring.general_utils import *
import warnings
import ipywidgets
if ipywidgets.__version__ > "7.8.5":
    from tqdm import tqdm
else:
    from tqdm.auto import tqdm

# 忽略非关键警告
warnings.filterwarnings('ignore')


class ModelScoring:
    """
    评分卡模型核心类
    提供评分卡生成、分数计算、分箱统计、PSI计算等核心功能
    """
    def __init__(
        self,
        ylabel: Optional[str] = None,
        x_cols_desc: Optional[Dict[str, str]] = None,
        fill_null_value: Any = np.nan,
        label_mapping: Optional[Dict[str, int]] = None,
        precision: Optional[int] = None,
        verbose: bool = True
    ):
        """
        初始化评分卡模型
        
        Parameters
        ----------
        ylabel : str, optional
            因变量列名，默认None
        x_cols_desc : Dict[str, str], optional
            自变量描述字典 {列名: 描述}，默认空字典
        fill_null_value : Any, default np.nan
            缺失值填充值
        label_mapping : Dict[str, int], optional
            标签映射字典，默认 {'positive': 1, 'negative': 0}
        precision : int, optional
            数值精度（小数位数），默认6
        verbose : bool, default True
            是否打印详细日志
        """
        # 基础配置（空值处理+默认值赋值）
        self.ylabel = ylabel
        self.fill_null_value = fill_null_value
        self.x_cols_desc = x_cols_desc if x_cols_desc is not None else {}
        self.precision = precision if precision is not None else 6
        self.verbose = verbose
        self.label_mapping = label_mapping if label_mapping is not None else {"positive": 1, "negative": 0}

        # 筛选结果存储（统一管理）
        self.results: Dict[str, Any] = {
            'var_bins_score': {},        # 变量每个分箱的评分信息 dict
            'time_cost': {}              # 各阶段耗时
        }


    # ------------------------------ 全局耗时统计装饰器 ------------------------------
    def _timeit(func: Callable) -> Callable:
        """
        全局装饰器：统计类方法/函数执行耗时（适配类实例属性）
        
        Parameters
        ----------
        func : Callable
            被装饰的方法/函数
        
        Returns
        -------
        Callable
            包装后的方法/函数
        """
        def wrapper(*args, **kwargs):
            # 从参数中提取类实例self（类方法第一个参数为self）
            self = args[0] if args and hasattr(args[0], '__class__') else None
            start_time = time.time()
            
            # 执行原方法/函数
            result = func(*args, **kwargs)
            
            # 计算耗时并处理日志/存储
            cost = time.time() - start_time
            if self:
                # 类实例方法：存储耗时到results，按verbose打印
                if not hasattr(self, 'results'):
                    self.results = {'time_cost': {}}  # 初始化results
                if 'time_cost' not in self.results:
                    self.results['time_cost'] = {}
                
                self.results['time_cost'][func.__name__] = cost
                
                # 按实例的verbose配置打印
                if hasattr(self, 'verbose') and self.verbose:
                    print(f">>>>>>> [{func.__name__}] 耗时：{cost:6.4f}秒")
            else:
                # 普通函数：降级打印
                print(f">>>>>>> 函数 [{func.__name__}] 耗时：{cost:6.4f}秒")
            
            return result
        return wrapper

    def fit_var_score(
        self,
        model_param: Dict[str, Any],
        var_bins_woe: Dict[str, Dict[Any, float]],
        baseline: float,
        p: float,
        pdo: float,
        trend_pos: bool = False,
        precision: Optional[int] = 2,
        verbose: Optional[bool] = None,
    ) -> Dict[str, Dict[Any, float]]:
        """
        单变量分数计算：生成每个变量对应区间的分数字典
        
        Parameters
        ----------
        model_param : Dict[str, Any]
            模型参数字典，需包含 'variable'（变量列表）、'coef'（系数数组）
        var_bins_woe : Dict[str, Dict[Any, float]], default {}
            变量分箱WOE字典 {变量名: {区间: WOE值}}
        baseline : float, eg: 100
            基准分数（对应p值的分数）
        p : float, default 0.05
            基准概率
        pdo : float, eg: 20.0
            odds翻倍对应的分数变化值
        trend_pos : bool, default False
            是否转换为信用分（正相关）
        precision : int, optional
            分数精度，默认使用实例的precision属性
        verbose : bool, optional
            是否打印细节，默认使用实例的verbose属性
        
        Returns
        -------
        Tuple[Dict[str, Dict[Any, float]], float]
            (变量分箱分数字典, 基础分)
        
        Raises
        ------
        KeyError
            model_param缺少必要键时抛出
        """
        # 参数默认值处理
        precision = precision if precision is not None else self.precision
        verbose = verbose if verbose is not None else self.verbose
        
        # 模型参数校验
        required_keys = ['variable', 'coef']
        missing_keys = [k for k in required_keys if k not in model_param]
        if missing_keys:
            raise KeyError(f"model_param缺少必要键：{missing_keys}")
        
        variable = model_param['variable']
        coef_arr = model_param['coef']
        missing_keys2 = [k for k in variable if k not in var_bins_woe]
        if missing_keys2:
            raise KeyError(f"var_bins_woe缺少必要键：{missing_keys2}")

        if len(coef_arr) != len(variable) + 1:
            raise ValueError(f"model_param参数中variable变量数量与包含截距的coef_arr参数数量不匹配，应当len(coef_arr)= len(variable) + 1")

        # 基础分数计算
        intercept = coef_arr[0]
        if trend_pos:
            B = pdo/math.log(2)
        else:
            B = -pdo/math.log(2)
        odds = p / (1 - p) if (1 - p) != 0 else 1e9
        A = baseline - B * math.log(odds)
        base_score = A + B * intercept

        mean_score = base_score / float(len(variable)) if len(variable) > 0 else 0.0
        base_score = 0
        variable_bins_score = {}
        verbose_body = []
        
        # 格式化长度计算
        format_template = f"{'0':<70s} | {1:^3d}: {'0':>30s} | 得分: {1:>6.{precision}f}"
        format_len = len(format_template) + 2

        # 遍历变量计算分数
        for idx, col in enumerate(variable):
            x_name = f"{col}:{self.x_cols_desc.get(col)}" if self.x_cols_desc.get(col) else col
            binsScore = {}
            woeArray = []
            binArray = []

            binswoe = var_bins_woe[col]
            bins_name = np.array(list(binswoe.keys()))
            
            # 处理空值分箱
            nan_bin = bins_name[pd.isna(bins_name)]
            if len(nan_bin) > 0:
                nan_key = nan_bin[0]
                woeArray.append(binswoe[nan_key])
                binArray.append(nan_key)

            # 处理非空值分箱
            itv_bin = np.sort(bins_name[pd.notna(bins_name)])
            for ibin in itv_bin:
                woeArray.append(binswoe[ibin])
                binArray.append(ibin)

            woeArray = np.array(woeArray)
            varCoef = coef_arr[idx + 1] if (idx + 1) < len(coef_arr) else 0.0
            score = B * varCoef * woeArray + mean_score

            # 分数校准
            base_score += np.min(score) if len(score) > 0 else 0.0
            score -= np.min(score) if len(score) > 0 else 0.0

            # 构建分箱分数字典
            seqid = 1
            for idx_bin in range(len(binArray)):
                e = binArray[idx_bin]
                s = score[idx_bin] if idx_bin < len(score) else 0.0
                binsScore[e] = np.round(s, precision)
                
                # 日志格式化
                col_trunc, slen = format_str(str(x_name), 70)
                out_str = f"{col_trunc:<{slen}s} | {seqid:^3d}: {str(e):>30s} | 得分: {s:>6.{precision}f}"
                verbose_body.append(out_str)
                seqid += 1
            
            # 分隔符处理
            if idx + 1 < len(variable):
                verbose_body.append("-" * format_len)
            else:
                verbose_body.append("=" * format_len)
            
            variable_bins_score[col] = binsScore

        # 基础分处理
        base_score = np.round(base_score, precision)
        variable_bins_score['basescore'] = {'None': base_score}

        # 打印详细日志
        if verbose:
            verbose_head = [
                "",
                " " * (int(format_len/2) - 7) + "逻辑回归评分卡" + " " * (format_len - 7 - int(format_len/2)),
                "=" * format_len,
                f"{'base_score':<70s} | {1:^3d}: {'-':>30s} | 得分: {base_score:>5.{precision}f}",
                "-" * format_len,
            ]
            verbose_list = verbose_head + verbose_body
            print("\n".join(verbose_list))
        self.results['var_bins_score'] = variable_bins_score
        return variable_bins_score

    @staticmethod
    def _intervals_map(interval_map: Dict[Any, float], col_series: pd.Series) -> np.ndarray:
        """
        区间映射：将Series值按区间/值映射为分数
        
        Parameters
        ----------
        interval_map : Dict[Any, float]
            映射字典 {区间/值: 分数}
        col_series : pd.Series
            待映射的Series
        
        Returns
        -------
        np.ndarray
            映射后的分数数组
        """
        # 分离区间和非区间映射
        intervals = [k for k in interval_map.keys() if isinstance(k, pd.Interval)]
        itv_scores_label = [interval_map[k] for k in intervals]
        
        non_itv_map = {k: v for k, v in interval_map.items() if not isinstance(k, pd.Interval)}
        non_itv_scores = col_series.map(non_itv_map).values.astype(float)

        # 区间映射处理
        if len(intervals) > 0:
            try:
                score_array = pd.cut(
                    col_series.values,
                    bins=[interval.left for interval in intervals] + [intervals[-1].right],
                    labels=itv_scores_label,
                    include_lowest=True,
                    right=intervals[0].closed in ['right', 'both'],
                    ordered = False
                ).astype(float)
                # 空值填充为非区间映射值
                score_array = np.where(
                    pd.notna(score_array),
                    score_array,
                    non_itv_scores
                )
            except Exception as e:
                # 区间映射失败时降级为非区间映射
                print(f"区间映射失败，降级为普通映射：{e}")
                score_array = non_itv_scores
        else:
            score_array = non_itv_scores
        
        return score_array

    @_timeit
    def data_scoring(
        self,
        df: pd.DataFrame,
        x_cols_list: List[str] = [],
        other_columns: List[str] = [],
        var_bins_score: Dict[str, Dict[Any, float]] = {},
        score_name: Optional[str] = "pred_score",
        x_origin_to_code: Optional[Dict[str, Dict[Any, Any]]] = None,
        fill_null_value: Optional[Union[int, float]] = None
    ) -> pd.DataFrame:
        """
        计算样本的分数，返回包含最终分数的DataFrame
        
        Parameters
        ----------
        df : pd.DataFrame
            输入数据集
        x_cols_list : List[str], default []
            参与映射计算的变量列名列表
        other_columns : List[str], default []
            需要保留的其他列名列表
        var_bins_score : Dict[str, Dict[Any, float]], default {}
            变量区间-映射值字典，格式：{变量名：{区间1: 映射值1, 区间2: 映射值2}}
        score_name : str, optional
            最终分数列的列名，默认使用"pred_score"
        x_origin_to_code : Dict[str, Dict[Any, Any]], optional
            变量值替换字典，格式：{变量名：{原值：替换值}}
        fill_null_value : Union[int, float, str], optional
            缺失值填充值，默认使用实例的fill_null_value属性
        
        Returns
        -------
        pd.DataFrame
            包含保留列、各变量分数列、最终总分列的DataFrame
        
        Raises
        ------
        TypeError
            输入数据类型不符合要求时抛出
        KeyError
            变量名不存在于映射字典或数据集中时抛出
        ValueError
            关键参数为空或无效时抛出
        """
        # 参数默认值处理
        score_name = score_name if score_name is not None else "pred_score"
        fill_null_value = fill_null_value if fill_null_value is not None else self.fill_null_value
        var_bins_score = var_bins_score if var_bins_score else self.results.get('var_bins_score')
        
        # ========== 1. 输入参数校验 ==========
        validate_cols(df, list(x_cols_list) + list(other_columns), "分数计算数据集")
        
        if not isinstance(var_bins_score, dict):
            raise TypeError(f"var_bins_score 必须是字典类型，当前类型：{type(var_bins_score)}")
        
        if x_origin_to_code is not None and not isinstance(x_origin_to_code, dict):
            raise TypeError(f"x_origin_to_code 必须是字典类型或None，当前类型：{type(x_origin_to_code)}")
        
        # 检查分数映射字典的完整性
        missing_score_cols = [col for col in x_cols_list if col not in var_bins_score]
        if missing_score_cols:
            raise KeyError(f"以下变量无映射字典：{missing_score_cols}")
        
        # ========== 2. 数据预处理 ==========
        
        # 筛选需要保留的列，避免冗余复制
        retain_cols = unique_list(other_columns)
        score_dict = {}
        for icol in retain_cols:
            score_dict[icol] = df[icol].values.copy()

        # ========== 3. 基础分处理 ==========
        if 'basescore' in var_bins_score:
            base_score = var_bins_score['basescore'].get('None', 0.0)
            score_dict['basescore'] = np.array([base_score] * len(df))
            score_calc_cols = ['basescore'] + x_cols_list
        else:
            score_calc_cols = x_cols_list
        
        # ========== 4. 分数计算（向量化+进度条） ==========
        # 遍历计算每个变量的分数
        with tqdm(x_cols_list, ascii=True, desc='变量映射') as pbar:
            for idx, col in enumerate(pbar):
                # 变量值替换
                null_mask = df[col].isna()
                col_series = df[col].fillna(fill_null_value)
                if isinstance(x_origin_to_code, dict) and col in x_origin_to_code:
                    fill_map = x_origin_to_code[col]
                    if isinstance(fill_map, dict) and fill_map:
                        # 匹配则替换，未匹配则-1
                        col_series = col_series.map(fill_map)
                        col_series = col_series.mask(~null_mask & col_series.isna(), -1)
                
                # 分数映射
                score_map = var_bins_score.get(col, {})
                score_dict[col] = self._intervals_map(score_map, col_series.astype(float))
        
        # ========== 5. 总分计算 ==========
        score_df = pd.DataFrame(score_dict, index = df.index)
        
        # 计算总分（空值处理：skipna=False → 有空值则总分空）
        if isinstance(score_name, str):
            score_df[score_name] = score_df[score_calc_cols].sum(axis=1, skipna=False)
        return score_df



    def _confusion_stats(
        self,
        seq: int,
        itv: str,
        tot_count: float,
        pos_count: float,
        neg_count: float,
        gra_count: float,
        pos_rate: float,
        gra_rate: float,
        cum_tot: float,
        cum_pos: float,
        cum_neg: float,
        iv_total: float,
        cumrsum: float,
        tot_cnt: float,
        pos_cnt: float,
        neg_cnt: float,
        gra_cnt: float,
        rsum: float,
    ) -> Tuple[int, float, float, float, float, float, Dict[str, Any]]:
        """
        计算混淆矩阵统计指标（TP/FP/SP/KS/WOE/IV等）
        
        Returns
        -------
        Tuple[int, float, float, float, float, float, Dict[str, Any]]
            (序列ID, 累计总数, 累计正例, 累计负例, 累计IV, 累计秩和, 统计行字典)
        """
        # 累计值计算
        cum_tot += tot_cnt
        cum_pos += pos_cnt
        cum_neg += neg_cnt
        cum_gra = cum_tot - cum_pos - cum_neg
        cumrsum += rsum

        # 基础比率计算（分母保护）
        tot_pct = tot_cnt / tot_count if tot_count > 0 else 0
        pos_pct = pos_cnt / pos_count if pos_count > 0 else 0
        neg_pct = neg_cnt / neg_count if neg_count > 0 else 0
        gra_pct = gra_cnt / gra_count if gra_count > 0 else 0

        cum_tot_pct = cum_tot / tot_count if tot_count > 0 else 0
        cum_pos_pct = cum_pos / pos_count if pos_count > 0 else 0
        cum_neg_pct = cum_neg / neg_count if neg_count > 0 else 0
        cum_gra_pct = cum_gra / gra_count if gra_count > 0 else 0

        # 准确率/F1/AUC计算
        denominator_acc = (pos_count + neg_count)
        acc = (cum_pos + neg_count - cum_neg) / denominator_acc if denominator_acc > 0 else 0
        
        denominator_f1 = (2 * cum_pos + cum_neg + pos_count - cum_pos)
        f1 = 2 * cum_pos / denominator_f1 if denominator_f1 > 0 else 0
        
        denominator_auc = (pos_count * neg_count)
        auc = (cumrsum - cum_pos * (cum_pos + 1) / 2) / denominator_auc if denominator_auc > 0 else 0

        # 分箱内比率计算
        if tot_cnt == 0:
            pos_rate_bin = 0
            neg_rate_bin = 0
            gra_rate_bin = 0
        else:
            pos_rate_bin = pos_cnt / tot_cnt
            neg_rate_bin = neg_cnt / tot_cnt
            gra_rate_bin = gra_cnt / tot_cnt
        cum_pos_rate = cum_pos / cum_tot if cum_tot != 0 else 0
        cum_neg_rate = cum_neg / cum_tot if cum_tot != 0 else 0
        cum_gra_rate = cum_gra / cum_tot if cum_tot != 0 else 0

        # Lift值计算（分母保护）
        pos_lift = pos_rate_bin / pos_rate if pos_rate != 0 else 0
        gra_lift = gra_rate_bin / gra_rate if gra_rate != 0 else 0
        cum_pos_lift = cum_pos_rate / pos_rate if pos_rate != 0 else 0
        cum_gra_lift = cum_gra_rate / gra_rate if gra_rate != 0 else 0

        # 权重比/KS/WOE/IV计算
        r, ks, woe, iv = weight_ratio(pos_pct, neg_pct)
        iv_total += iv
        ks_val = abs(cum_pos_pct - cum_neg_pct)

        # 构建统计行
        row = {
            'seq': seq,
            'interval': itv,
            'totCnt': tot_cnt,
            'totPct': tot_pct,
            'negCnt': neg_cnt,
            'posCnt': pos_cnt,
            'graCnt': gra_cnt,
            'negPct': neg_pct,
            'posPct': pos_pct,
            'graPct': gra_pct,
            'cumNegPct': cum_neg_pct,
            'cumPosPct': cum_pos_pct,
            'cumGraPct': cum_gra_pct,
            'cumTotPct': cum_tot_pct,
            'binPosRate': pos_rate_bin,
            'binGraRate': gra_rate_bin,
            'PosRate': pos_rate,
            'GraRate': gra_rate,
            'posLift': pos_lift,
            'graLift': gra_lift,
            'WOE': woe,
            'KS': ks_val,
            'IV': iv_total,
            'r': r,
            'cumPosRate': cum_pos_rate,
            'cumGraRate': cum_gra_rate,
            'cumPosLift': cum_pos_lift,
            'cumGraLift': cum_gra_lift,
            'ACC': acc,
            'F1': f1,
            'AUC': auc
        }

        seq += 1

        return seq, cum_tot, cum_pos, cum_neg, iv_total, cumrsum, row

    def pred_bins_stats(
        self,
        df: pd.DataFrame,
        x_column: str,
        ylabel: Optional[str] = None,
        bin_arr: List[float] = [],
        n_bins: int = 20,
        pattern: Optional[str] = None,
        trend_pos: bool = False,
        reverse: bool = False,
        verbose: Optional[bool] = None,
        precision: Optional[int] = None,
    ) -> Tuple[pd.DataFrame, List[float]]:
        """
        特征分箱统计：计算分箱后的KS/WOE/IV等指标
        
        Parameters
        ----------
        df : pd.DataFrame
            输入数据集
        x_column : str
            自变量列名
        ylabel : str, optional
            因变量列名，默认使用实例的ylabel属性
        bin_arr : List[float], default []
            分箱边界列表，例：[-inf, 1, 2, 3, inf]
        n_bins : int, default 20
            等宽/等频分箱数（仅当bin_arr为空时生效）
        pattern : str, optional
            分箱模式：'range'=等宽分箱，其他=等频分箱
        trend_pos : bool, default False
            是否与正类正相关（影响AUC/F1计算）
        reverse : bool, default False
            是否逆序统计分箱
        verbose : bool, optional
            是否打印详细日志，默认使用实例的verbose属性
        precision : int, optional
            小数精度，默认使用实例的precision属性
        
        Returns
        -------
        Tuple[pd.DataFrame, List[float]]
            (分箱统计结果DataFrame, 分箱边界列表)
        
        Raises
        ------
        ValueError
            数据集为空/列名不存在时抛出
        """
        # 参数默认值处理
        ylabel = self.ylabel if ylabel is None else ylabel
        verbose = self.verbose if verbose is None else verbose
        precision = precision if precision is not None else self.precision
        
        # 输入校验
        if df is None or df.empty:
            raise ValueError(f"df不可为空，当前值：{df}")
        if not isinstance(x_column, str) or pd.isna(x_column):
            raise ValueError(f"x_column必须为非空字符串，当前值：{x_column}")
        if not isinstance(ylabel, str) or pd.isna(ylabel):
            raise ValueError(f"ylabel必须为非空字符串，当前值：{ylabel}")
        
        validate_cols(df, [x_column, ylabel], "分箱统计数据集")
        
        # 标签映射
        pos = self.label_mapping.get('positive', 1)
        neg = self.label_mapping.get('negative', 0)

        # 数据预处理
        y_array = df[ylabel].values.astype(float)
        x_array = df[x_column].fillna(self.fill_null_value).values.astype(float)

        # 筛选有效标签数据
        subdf = df[df[ylabel].isin([pos, neg])].copy(deep=True)
        subdf["rank"] = subdf[x_column].fillna(-np.inf).rank(
            method="average", 
            ascending=trend_pos
        )
        
        # 基础统计
        tot_count = float(len(y_array))
        pos_count = float(len(y_array[y_array == pos]))
        neg_count = float(len(y_array[y_array == neg]))
        gra_count = tot_count - neg_count - pos_count

        pos_rate = pos_count / tot_count if tot_count > 0 else 0
        gra_rate = gra_count / tot_count if tot_count > 0 else 0

        # 生成分箱边界
        if len(bin_arr) == 0:
            # 过滤有效数值（非填充值+非空值）
            valid_x = x_array[(x_array != self.fill_null_value) & pd.notna(x_array)]
            if pattern == 'range':
                # 等宽分箱
                if len(valid_x) > 0:
                    max_v = np.max(valid_x)
                    min_v = np.min(valid_x)
                    bin_arr = np.round(np.linspace(min_v, max_v, n_bins + 1), precision)
                    bin_arr[0], bin_arr[-1] = -np.inf, np.inf
                else:
                    bin_arr = [-np.inf, np.inf]
            else:
                # 等频分箱
                bin_arr = calculate_quantiles(
                    valid_x,
                    n_bins=n_bins,
                    precision=precision,
                    unique=True,
                    include_extr=False
                )
            
            # 包含空值分箱
            if np.sum((x_array == self.fill_null_value) | (pd.isna(x_array))) > 0:
                bin_arr = [self.fill_null_value] + bin_arr

        # 分箱边界去重排序
        bin_arr_raw = np.sort(np.unique(np.round(bin_arr, precision)))
        x_arr_y1 = x_array[y_array == pos]
        x_arr_y0 = x_array[y_array == neg]

        # 日志列定义
        data_columns1 = (
            'seq','interval','totPct','negCnt','posCnt','graCnt','negPct','posPct','graPct',
            'bPosRate','bGraRate','posLift','graLift','KS', 'IV', 'r'
        )
        data_columns2 = (
            'seq', 'interval','negCnt', 'posCnt', 'graCnt','totCnt', 'negPct', 'posPct', 'graPct', 'totPct',
            'cumNegPct', 'cumPosPct', 'cumGraPct', 'cumTotPct', 'binPosRate','binGraRate',
            'cumPosRate','cumGraRate', 'PosRate', 'GraRate', 'posLift', 'graLift',
            'cumPosLift', 'cumGraLift', 'WOE', 'KS', 'IV','r','ACC', 'F1', 'AUC'
        )

        # 打印表头
        if verbose:
            x_name = f"{x_column}:{self.x_cols_desc.get(x_column)}" if self.x_cols_desc.get(x_column) else x_column
            print('')
            print(
                'TotalCount: {0:4.0f}  NegCount: {1:4.0f}  PosCount: {2:4.0f}  GraCount: {3:4.0f}  x_column: {4:s}'
                .format(tot_count, neg_count, pos_count, gra_count, x_name)
            )
            header = "{0:^4s}|{1:^22s}|{2:^7s}|{3:^6s}|{4:^6s}|{5:^6s}|{6:^7s}|{7:^7s}|{8:^7s}|{9:^8s}|{10:^8s}|{11:^7s}|{12:^7s}|{13:^5s}|{14:^5s}|{15:^5s}".format(*data_columns1)
            print('-' * len(header))
            print(header)
            print('-' * len(header))

        # 初始化累计变量
        cum_tot = 0.0
        cum_pos = 0.0
        cum_neg = 0.0
        iv_total = 0.0
        cumrsum = 0.0
        seq = 0
        data_list = []

        # 处理空值分箱
        if np.sum(pd.isna(bin_arr_raw)) > 0:
            itv = "nan"
            tot_cnt = len(x_array[pd.isna(x_array)])
            pos_cnt = len(x_arr_y1[pd.isna(x_arr_y1)])
            neg_cnt = len(x_arr_y0[pd.isna(x_arr_y0)])
            gra_cnt = tot_cnt - pos_cnt - neg_cnt
            rsum = subdf['rank'][(subdf[x_column].isna()) & (subdf[ylabel] == pos)].sum()
            
            # 计算统计指标
            seq, cum_tot, cum_pos, cum_neg, iv_total, cumrsum, row = self._confusion_stats(
                seq = seq, itv = itv, tot_count = tot_count, pos_count = pos_count, neg_count = neg_count, gra_count = gra_count,
                pos_rate = pos_rate, gra_rate = gra_rate, cum_tot = cum_tot, cum_pos = cum_pos, cum_neg = cum_neg, iv_total = iv_total,
                cumrsum = cumrsum, tot_cnt = tot_cnt, pos_cnt = pos_cnt, neg_cnt = neg_cnt, gra_cnt = gra_cnt, rsum = rsum
            )

            data_list.append(row)
            
            # 打印空值分箱结果
            if verbose:
                print(
                    "{seq:^4d}|{interval:>22s}|{totPct:>7.2%}|{negCnt:>6.0f}|{posCnt:>6.0f}|{graCnt:>6.0f}|{negPct:>7.2%}|{posPct:>7.2%}|{graPct:>7.2%}|".format(**row) +
                    "{binPosRate:>8.2%}|{binGraRate:>8.2%}|{posLift:>7.2f}|{graLift:>7.2f}|{KS:>5.3f}|{IV:>5.3f}|{r:>5.2f}".format(**row)
                )

        # 过滤非空分箱边界
        bin_arr = [ival for ival in bin_arr_raw if pd.notna(ival)]
        mask = pd.notna(x_array)
        y1_mask = pd.notna(x_arr_y1)
        y0_mask = pd.notna(x_arr_y0)
        r_mask = subdf[x_column].notna()

        # 遍历非空分箱
        for i in range(len(bin_arr) - 1):
            # 分箱边界（支持逆序）
            if reverse:
                left = bin_arr[-(i+2)]
                right = bin_arr[-(i+1)]
            else:
                left = bin_arr[i]
                right = bin_arr[i+1]
            
            # 分箱名称格式化
            itv = f"({round(left, precision)}, {round(right, precision)}]"
            
            # 分箱内统计
            tot_cnt = len(x_array[(x_array > left) & (x_array <= right) & mask])
            pos_cnt = len(x_arr_y1[(x_arr_y1 > left) & (x_arr_y1 <= right) & y1_mask])
            neg_cnt = len(x_arr_y0[(x_arr_y0 > left) & (x_arr_y0 <= right) & y0_mask])
            gra_cnt = tot_cnt - pos_cnt - neg_cnt
            rsum = subdf['rank'][
                (subdf[x_column] > left) & (subdf[x_column] <= right) & 
                r_mask & (subdf[ylabel] == pos)
            ].sum()

            # 计算统计指标
            seq, cum_tot, cum_pos, cum_neg, iv_total, cumrsum, row = self._confusion_stats(
                seq = seq, itv = itv, tot_count = tot_count, pos_count = pos_count, neg_count = neg_count, gra_count = gra_count,
                pos_rate = pos_rate, gra_rate = gra_rate, cum_tot = cum_tot, cum_pos = cum_pos, cum_neg = cum_neg, iv_total = iv_total,
                cumrsum = cumrsum, tot_cnt = tot_cnt, pos_cnt = pos_cnt, neg_cnt = neg_cnt, gra_cnt = gra_cnt, rsum = rsum
            )
            data_list.append(row)
            
            # 打印分箱结果
            if verbose:
                print(
                    "{seq:^4d}|{interval:>22s}|{totPct:>7.2%}|{negCnt:>6.0f}|{posCnt:>6.0f}|{graCnt:>6.0f}|{negPct:>7.2%}|{posPct:>7.2%}|{graPct:>7.2%}|".format(**row) +
                    "{binPosRate:>8.2%}|{binGraRate:>8.2%}|{posLift:>7.2f}|{graLift:>7.2f}|{KS:>5.3f}|{IV:>5.3f}|{r:>5.2f}".format(**row)
                )

        # 打印分隔符
        if verbose:
            print('-' * len(header))
        
        # 构建输出DataFrame
        data_rts = [[row[col] for col in data_columns2] for row in data_list]
        data_out = pd.DataFrame(data_rts, columns = data_columns2)
        
        return data_out, bin_arr_raw



    def cal_psi(
        self,
        dfleft: pd.DataFrame,
        dfright: pd.DataFrame,
        psi_cols: List[str] = ['totPct', 'posPct']
    ) -> Dict[str, float]:
        """
        计算PSI（群体稳定性指标）：对比两个数据集的totPct/posPct分布
        
        Parameters
        ----------
        dfleft : pd.DataFrame
            左侧数据集分箱统计结果（通常为训练集）
        dfright : pd.DataFrame
            右侧数据集分箱统计结果（通常为测试集）
        psi_cols : List[str], default ['totPct', 'posPct']
            需要计算PSI的列名列表
        
        Returns
        -------
        Dict[str, float]
            {列名: PSI值}
        
        Raises
        ------
        ValueError
            数据集列数不一致/列名不存在时抛出
        """
        # 输入校验
        validate_cols(dfleft,  psi_cols, "左侧PSI数据集")
        validate_cols(dfright, psi_cols, "右侧PSI数据集")
        
        if len(dfleft) != len(dfright):
            raise ValueError(f"左右数据集行数不一致：左侧{len(dfleft)}行，右侧{len(dfright)}行")
        
        psi_dict = {}
        for col in psi_cols:
            left_vals = dfleft[col].values.astype(float)
            right_vals = dfright[col].values.astype(float)
            
            # 计算WOE和PSI
            WOE_arr = []
            for i in range(len(left_vals)):
                left_pct  = left_vals[i]
                right_pct = right_vals[i]
                # 边界保护：避免0值导致log报错
                left_pct  = max(left_pct, 1e-10)
                right_pct = max(right_pct, 1e-10)
                _, _, WOE, _ = weight_ratio(left_pct, right_pct)
                WOE_arr.append(WOE)
            
            WOE_arr = np.array(WOE_arr)
            psiArr = (left_vals - right_vals) * WOE_arr
            psi = np.sum(psiArr)
            psi_dict[col] = psi
        
        return psi_dict

