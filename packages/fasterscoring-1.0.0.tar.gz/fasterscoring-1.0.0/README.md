# fasterscoring
> 简洁、专业、开箱即用的 Python 工具库


## 介绍
fasterscoring 是一个轻量、高效、易于使用的 Python 工具库，专注于 **风控领域二分类问题基于逻辑回归的评分卡建模**。
设计目标：简洁 API、无冗余依赖、开箱即用、适合生产与脚本环境。

---

## 特性
- 极简 API 设计，上手零成本
- 兼容 Python 3.8+，跨平台（Windows / macOS / Linux）
- 主要面向jupyter notebook交互式的分析型开发

---

## 安装
使用 `pip` 直接从 PyPI 安装：
```bash
pip install fasterscoring
import fasterscoring as fts
fts.get_demo() # 即可get Jupyter notebook 操作示例文件
 