"""patch_litellm() — automatic cost tracking for litellm.completion / acompletion."""

from __future__ import annotations

import functools
import logging
import time
from typing import Any

from superpenguin._pricing import calculate_cost_micros
from superpenguin._wrap import (
    _AsyncStreamProxy,
    _OpenAIAccumulator,
    _SyncStreamProxy,
    _normalize_openai,
    _extract_call_metadata,
)

logger = logging.getLogger("superpenguin")

_patched = False


def patch_litellm(
    *,
    name: str | None = None,
    metadata: dict[str, Any] | None = None,
    tags: list[str] | None = None,
) -> None:
    """Monkey-patch ``litellm.completion`` and ``litellm.acompletion``.

    After calling this, every ``litellm.completion()`` and
    ``litellm.acompletion()`` call is automatically tracked.

    Args:
        name: Override the default event name (``"chat.completions"``).
        metadata: Default metadata for every litellm call.
        tags: Tags attached to every event.

    Usage::

        import superpenguin as sp
        import litellm

        sp.init(api_key="sp_...")
        sp.patch_litellm()

        response = litellm.completion(
            model="openai/gpt-4o",
            messages=[{"role": "user", "content": "Hello"}],
        )
    """
    global _patched
    if _patched:
        return

    try:
        import litellm  # noqa: F811
    except ImportError as exc:
        raise ImportError(
            "litellm is not installed. Install it with: pip install litellm"
        ) from exc

    extra: dict[str, Any] = {}
    if name:
        extra["name"] = name
    if metadata:
        extra["metadata"] = metadata
    if tags:
        extra["tags"] = tags

    _do_patch(litellm, "completion", is_async=False, extra=extra)
    _do_patch(litellm, "acompletion", is_async=True, extra=extra)
    _patched = True


def _do_patch(
    module: Any, attr: str, *, is_async: bool, extra: dict[str, Any],
) -> None:
    original = getattr(module, attr)

    if is_async:

        @functools.wraps(original)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            return await _track_async(original, extra, args, kwargs)

        setattr(module, attr, async_wrapper)
    else:

        @functools.wraps(original)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            return _track_sync(original, extra, args, kwargs)

        setattr(module, attr, sync_wrapper)


# ---------------------------------------------------------------------------
# Sync / async tracking
# ---------------------------------------------------------------------------


def _track_sync(
    fn: Any,
    extra: dict[str, Any],
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
) -> Any:
    started_at = time.time()
    is_stream = kwargs.get("stream", False)
    call_meta = _capture_litellm_input(args, kwargs)

    if is_stream:
        kwargs = dict(kwargs)
        opts = dict(kwargs.get("stream_options") or {})
        opts["include_usage"] = True
        kwargs["stream_options"] = opts

    try:
        result = fn(*args, **kwargs)
    except Exception as exc:
        _submit_event(
            extra, call_meta, {}, started_at, time.time(),
            status_code=getattr(exc, "status_code", 500),
            streaming=False,
        )
        raise

    if is_stream:
        acc = _OpenAIAccumulator()

        def on_done() -> None:
            _submit_event(
                extra, call_meta, acc.result(),
                started_at, time.time(), status_code=200, streaming=True,
            )

        return _SyncStreamProxy(result, acc, on_done)

    output = _normalize_openai(result)
    _submit_event(
        extra, call_meta, output,
        started_at, time.time(), status_code=200, streaming=False,
    )
    return result


async def _track_async(
    fn: Any,
    extra: dict[str, Any],
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
) -> Any:
    started_at = time.time()
    is_stream = kwargs.get("stream", False)
    call_meta = _capture_litellm_input(args, kwargs)

    if is_stream:
        kwargs = dict(kwargs)
        opts = dict(kwargs.get("stream_options") or {})
        opts["include_usage"] = True
        kwargs["stream_options"] = opts

    try:
        result = await fn(*args, **kwargs)
    except Exception as exc:
        _submit_event(
            extra, call_meta, {}, started_at, time.time(),
            status_code=getattr(exc, "status_code", 500),
            streaming=False,
        )
        raise

    if is_stream:
        acc = _OpenAIAccumulator()

        def on_done() -> None:
            _submit_event(
                extra, call_meta, acc.result(),
                started_at, time.time(), status_code=200, streaming=True,
            )

        return _AsyncStreamProxy(result, acc, on_done)

    output = _normalize_openai(result)
    _submit_event(
        extra, call_meta, output,
        started_at, time.time(), status_code=200, streaming=False,
    )
    return result


# ---------------------------------------------------------------------------
# litellm-specific input capture
# ---------------------------------------------------------------------------

_POS_PARAMS = ("model", "messages")


def _capture_litellm_input(
    args: tuple[Any, ...], kwargs: dict[str, Any],
) -> dict[str, Any]:
    captured: dict[str, Any] = {}
    for i, param_name in enumerate(_POS_PARAMS):
        if param_name in kwargs:
            captured[param_name] = kwargs[param_name]
        elif i < len(args):
            captured[param_name] = args[i]

    meta_raw = kwargs.get("metadata") or {}
    if isinstance(meta_raw, dict):
        call_meta = _extract_call_metadata({"extra_body": {"metadata": meta_raw}})
        captured.update(call_meta)

    return captured


# ---------------------------------------------------------------------------
# Event submission
# ---------------------------------------------------------------------------


def _submit_event(
    extra: dict[str, Any],
    call_meta: dict[str, Any],
    output_data: dict[str, Any],
    started_at: float,
    ended_at: float,
    *,
    status_code: int,
    streaming: bool,
) -> None:
    from superpenguin import get_client

    usage = output_data.get("usage", {})
    input_tokens = usage.get("input_tokens", 0)
    output_tokens = usage.get("output_tokens", 0)
    cached_tokens = usage.get("cached_tokens", 0)
    model = output_data.get("model") or call_meta.get("model", "")

    cost_micros = calculate_cost_micros(
        model, input_tokens, output_tokens, cached_tokens,
    )

    merged_meta = dict(extra.get("metadata") or {})
    merged_meta.update(
        {k: v for k, v in call_meta.items() if k not in ("model", "messages")}
    )

    event: dict[str, Any] = {
        "provider": "litellm",
        "model": model,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "cached_tokens": cached_tokens,
        "cost_usd_micros": cost_micros,
        "latency_ms": round((ended_at - started_at) * 1000),
        "status_code": status_code,
        "streaming": streaming,
        "has_tools": output_data.get("has_tools", False),
        "has_vision": False,
    }

    for key in (
        "customer_id", "feature", "team", "environment",
        "prompt_key", "prompt_version",
    ):
        val = merged_meta.get(key)
        if val is not None:
            event[key] = str(val) if key == "prompt_version" else val

    if merged_meta.get("custom_tags"):
        event["custom_tags"] = merged_meta["custom_tags"]

    try:
        get_client().submit(event)
    except Exception:
        logger.debug("superpenguin: failed to submit litellm event", exc_info=True)
