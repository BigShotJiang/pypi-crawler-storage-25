from __future__ import annotations

import contextvars

current_trace_id: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "sp_trace_id", default=None
)
