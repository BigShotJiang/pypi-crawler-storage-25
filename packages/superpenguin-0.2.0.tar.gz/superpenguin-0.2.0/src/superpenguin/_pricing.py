"""Built-in cost estimation for known LLM models.

Prices are in USD per 1M tokens. Cost is returned in USD micros
(1 USD = 1,000,000 micros) for lossless integer arithmetic.

Pricing schema
--------------
Each entry is a dict with ``input``, ``output``, and optional ``cache_read``
rates. A rate is normally a ``float`` ($/1M tokens). For models with
input-size-tiered pricing (currently Gemini 2.5 Pro and 3.1 Pro), a rate
may be a 2-element list ``[low_tier, high_tier]`` paired with a
``tier_threshold`` (in input tokens) — values <= threshold use ``low_tier``,
values > threshold use ``high_tier``.

Audio/image input modalities are billed separately by Google. We currently
only track the text rate; audio-heavy workloads will be under-counted by
the SDK estimator but still billed correctly by the provider.
"""

from __future__ import annotations

import logging
import re
from typing import Any

logger = logging.getLogger("superpenguin")

# Dedupe the warning so a hot loop on an unknown model doesn't spam logs.
# Process-local set; sufficient because the server-side
# /api/sdk/ingest route also pings Slack with its own dedupe layer
# (public.unknown_model_alerts) so the dashboard team gets the alert
# even if the SDK process is short-lived.
_warned_unknown_models: set[str] = set()

_MODEL_PRICING: dict[str, dict[str, Any]] = {
    # OpenAI
    "gpt-5.4":          {"input": 2.5,   "output": 15.0,  "cache_read": 0.25},
    "gpt-5.4-mini":     {"input": 0.75,  "output": 4.5,   "cache_read": 0.075},
    "gpt-5.4-nano":     {"input": 0.2,   "output": 1.25,  "cache_read": 0.02},
    "gpt-5":            {"input": 1.25,  "output": 10.0,  "cache_read": 0.125},
    "gpt-5-mini":       {"input": 0.25,  "output": 2.0,   "cache_read": 0.025},
    "gpt-5-nano":       {"input": 0.05,  "output": 0.4,   "cache_read": 0.005},
    "gpt-4o":           {"input": 2.5,   "output": 10.0},
    "gpt-4o-mini":      {"input": 0.15,  "output": 0.6},
    "gpt-4.1":          {"input": 2.0,   "output": 8.0},
    "gpt-4.1-mini":     {"input": 0.4,   "output": 1.6},
    "gpt-4.1-nano":     {"input": 0.1,   "output": 0.4},
    "o3":               {"input": 2.0,   "output": 8.0},
    "o4-mini":          {"input": 1.1,   "output": 4.4},
    # Anthropic
    "claude-opus-4":     {"input": 15.0, "output": 75.0,  "cache_read": 1.5},
    "claude-opus-4-6":   {"input": 5.0,  "output": 25.0,  "cache_read": 0.5},
    "claude-sonnet-4":   {"input": 3.0,  "output": 15.0,  "cache_read": 0.3},
    "claude-sonnet-4-5": {"input": 3.0,  "output": 15.0,  "cache_read": 0.3},
    "claude-sonnet-4-6": {"input": 3.0,  "output": 15.0,  "cache_read": 0.3},
    "claude-haiku-4-5":  {"input": 1.0,  "output": 5.0,   "cache_read": 0.1},
    # Google Gemini — text rates, paid Standard tier (Batch/Flex/Priority not modeled)
    # Source: https://ai.google.dev/gemini-api/docs/pricing (verified 2026-04-16)
    "gemini-3.1-pro-preview": {
        "input":      [2.0,  4.0],
        "output":     [12.0, 18.0],
        "cache_read": [0.20, 0.40],
        "tier_threshold": 200_000,
    },
    "gemini-3.1-flash-lite-preview": {
        "input": 0.25,  "output": 1.5,   "cache_read": 0.025,
    },
    "gemini-3-flash-preview": {
        "input": 0.5,   "output": 3.0,   "cache_read": 0.05,
    },
    "gemini-2.5-pro": {
        "input":      [1.25, 2.5],
        "output":     [10.0, 15.0],
        "cache_read": [0.125, 0.25],
        "tier_threshold": 200_000,
    },
    "gemini-2.5-flash":      {"input": 0.30,  "output": 2.5,   "cache_read": 0.03},
    "gemini-2.5-flash-lite": {"input": 0.10,  "output": 0.4,   "cache_read": 0.01},
    "gemini-2.0-flash":      {"input": 0.10,  "output": 0.4,   "cache_read": 0.025},
    "gemini-2.0-flash-lite": {"input": 0.075, "output": 0.3},
    # xAI / Grok
    "grok-3":      {"input": 3.0,  "output": 15.0},
    "grok-3-mini": {"input": 0.3,  "output": 0.5},
    "grok-3-fast": {"input": 5.0,  "output": 25.0},
}

# Model alias map — maps non-canonical names to a canonical key in _MODEL_PRICING.
# Useful when callers pass either an older alias or a stable name that Google
# has since folded into a -preview SKU.
_MODEL_ALIASES: dict[str, str] = {
    "gemini-3.1-pro": "gemini-3.1-pro-preview",
    "gemini-3-flash": "gemini-3-flash-preview",
    "gemini-3.1-flash-lite": "gemini-3.1-flash-lite-preview",
}

# YYYY-MM-DD or YYYYMMDD trailing date (e.g. "-2025-09-15", "-20250915")
_DATE_SUFFIX = re.compile(r"-\d{4}-\d{2}-\d{2}$|-\d{8}$")
# Google-style trailing month-year (e.g. "-09-2025") used on Gemini preview SKUs
_MONTH_YEAR_SUFFIX = re.compile(r"-\d{2}-\d{4}$")
# Vertex AI version pin (e.g. "-001", "-002")
_VERSION_PIN_SUFFIX = re.compile(r"-\d{3}$")


def _normalize_model(raw: str) -> str:
    """Normalize a raw model name from any provider into a pricing-table key.

    Examples::

        openai/gpt-4o                                  -> gpt-4o
        models/gemini-2.5-pro                          -> gemini-2.5-pro
        gemini-2.5-flash-lite-preview-09-2025          -> gemini-2.5-flash-lite-preview
        gemini-2.0-flash-001                           -> gemini-2.0-flash
        gpt-5-mini-2025-09-15                          -> gpt-5-mini
    """
    if "/" in raw:
        raw = raw.rsplit("/", 1)[-1]
    raw = _DATE_SUFFIX.sub("", raw)
    raw = _MONTH_YEAR_SUFFIX.sub("", raw)
    raw = _VERSION_PIN_SUFFIX.sub("", raw)
    return _MODEL_ALIASES.get(raw, raw)


def _pick(rate: Any, input_tokens: int, threshold: int | None) -> float:
    """Return the per-1M-token rate for the right tier."""
    if isinstance(rate, list):
        if threshold is None or len(rate) < 2:
            return float(rate[0])
        return float(rate[1] if input_tokens > threshold else rate[0])
    return float(rate)


def calculate_cost_micros(
    model: str,
    input_tokens: int,
    output_tokens: int,
    cached_tokens: int = 0,
) -> int:
    """Calculate request cost in USD micros (1 USD = 1,000,000 micros).

    Returns 0 if the model is unknown.
    """
    normalized = _normalize_model(model)
    pricing = _MODEL_PRICING.get(normalized)
    if pricing is None:
        if normalized not in _warned_unknown_models:
            _warned_unknown_models.add(normalized)
            logger.warning(
                "superpenguin: no pricing entry for model %r (normalized %r); "
                "cost will be reported as 0. Open a PR adding it to "
                "sdk/python/src/superpenguin/_pricing.py._MODEL_PRICING.",
                model,
                normalized,
            )
        return 0

    threshold = pricing.get("tier_threshold")
    input_rate = _pick(pricing["input"], input_tokens, threshold)
    output_rate = _pick(pricing["output"], input_tokens, threshold)

    cache_raw = pricing.get("cache_read")
    if cache_raw is None:
        cache_rate = input_rate * 0.5
    else:
        cache_rate = _pick(cache_raw, input_tokens, threshold)

    uncached_input = max(0, input_tokens - cached_tokens)
    input_cost = (uncached_input / 1_000_000) * input_rate
    output_cost = (output_tokens / 1_000_000) * output_rate
    cache_cost = (cached_tokens / 1_000_000) * cache_rate

    return round((input_cost + output_cost + cache_cost) * 1_000_000)
