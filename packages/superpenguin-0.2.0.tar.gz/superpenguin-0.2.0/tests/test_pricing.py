"""Unit tests for the pricing table, model normalization, and cost math."""

from __future__ import annotations

import pytest

from superpenguin._pricing import _normalize_model, calculate_cost_micros


# ---------------------------------------------------------------------------
# _normalize_model
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "raw, expected",
    [
        ("gpt-4o", "gpt-4o"),
        ("openai/gpt-4o", "gpt-4o"),
        ("openai/gpt-5-mini-2025-09-15", "gpt-5-mini"),
        ("models/gemini-2.5-pro", "gemini-2.5-pro"),
        ("gemini-2.5-flash-lite-preview-09-2025", "gemini-2.5-flash-lite-preview"),
        ("gemini-2.0-flash-001", "gemini-2.0-flash"),
        ("gemini-3.1-pro", "gemini-3.1-pro-preview"),
        ("gemini-3.1-pro-preview", "gemini-3.1-pro-preview"),
        ("gemini-3-flash", "gemini-3-flash-preview"),
        ("gemini-3.1-flash-lite", "gemini-3.1-flash-lite-preview"),
        ("claude-sonnet-4-5-20250915", "claude-sonnet-4-5"),
    ],
)
def test_normalize_model(raw: str, expected: str) -> None:
    assert _normalize_model(raw) == expected


# ---------------------------------------------------------------------------
# Tiered pricing — Gemini 2.5 Pro and 3.1 Pro
# ---------------------------------------------------------------------------


def test_gemini_2_5_pro_low_tier() -> None:
    # 100K input (≤200K), 1K output:
    #   input  100_000 * 1.25 / 1M = 0.125
    #   output   1_000 * 10.0 / 1M = 0.01
    #   total = 0.135 USD = 135_000 micros
    assert calculate_cost_micros("gemini-2.5-pro", 100_000, 1_000) == 135_000


def test_gemini_2_5_pro_high_tier() -> None:
    # 300K input (>200K), 1K output:
    #   input  300_000 * 2.50 / 1M = 0.75
    #   output   1_000 * 15.0 / 1M = 0.015
    #   total = 0.765 USD
    assert calculate_cost_micros("gemini-2.5-pro", 300_000, 1_000) == 765_000


def test_gemini_3_1_pro_low_tier() -> None:
    # 100K input ≤200K: input 0.20 + output 0.012 = 0.212 USD
    assert calculate_cost_micros("gemini-3.1-pro", 100_000, 1_000) == 212_000


def test_gemini_3_1_pro_high_tier() -> None:
    # 300K input >200K: input 1.20 + output 0.018 = 1.218 USD
    assert calculate_cost_micros("gemini-3.1-pro", 300_000, 1_000) == 1_218_000


def test_gemini_3_1_pro_tier_threshold_boundary() -> None:
    # Exactly at threshold (200_000) should still use the LOW tier.
    # 200_000 * 2.0 / 1M = 0.40, output 0.012 = 0.412 USD
    assert calculate_cost_micros("gemini-3.1-pro", 200_000, 1_000) == 412_000
    # One token over → high tier.
    # 200_001 * 4.0 / 1M = 0.800004, output 0.018 = 0.818004 USD → 818_004 micros
    assert calculate_cost_micros("gemini-3.1-pro", 200_001, 1_000) == 818_004


# ---------------------------------------------------------------------------
# Cache pricing for Gemini
# ---------------------------------------------------------------------------


def test_gemini_2_5_pro_cache_uses_official_rate() -> None:
    # 100K input total, 50K of which are cached, 1K output (low tier):
    #   uncached input 50_000 * 1.25 / 1M = 0.0625
    #   cache read     50_000 * 0.125 / 1M = 0.00625
    #   output          1_000 * 10.0  / 1M = 0.01
    #   total = 0.07875 USD = 78_750 micros
    assert calculate_cost_micros("gemini-2.5-pro", 100_000, 1_000, 50_000) == 78_750


def test_gemini_3_1_pro_cache_high_tier() -> None:
    # 300K input total, 100K cached, 1K output (high tier):
    #   uncached input 200_000 * 4.0 / 1M = 0.80
    #   cache read     100_000 * 0.40 / 1M = 0.04
    #   output           1_000 * 18.0 / 1M = 0.018
    #   total = 0.858 USD
    assert calculate_cost_micros("gemini-3.1-pro", 300_000, 1_000, 100_000) == 858_000


def test_gemini_2_5_flash_flat_rate() -> None:
    # 1M input, 1K output: input 0.30 + output 0.0025 = 0.3025 USD
    assert calculate_cost_micros("gemini-2.5-flash", 1_000_000, 1_000) == 302_500


# ---------------------------------------------------------------------------
# Regression — non-Gemini models still work
# ---------------------------------------------------------------------------


def test_gpt_4o_regression() -> None:
    # 1M input + 1K output: 2.50 + 0.01 = 2.51 USD
    assert calculate_cost_micros("gpt-4o", 1_000_000, 1_000) == 2_510_000


def test_claude_sonnet_4_with_cache() -> None:
    # 100K input total, 50K cached, 1K output:
    #   uncached input 50_000 * 3.0 / 1M = 0.15
    #   cache read     50_000 * 0.3 / 1M = 0.015
    #   output          1_000 * 15.0 / 1M = 0.015
    #   total = 0.18 USD
    assert calculate_cost_micros("claude-sonnet-4", 100_000, 1_000, 50_000) == 180_000


def test_unknown_model_returns_zero() -> None:
    assert calculate_cost_micros("not-a-real-model-xyz", 1_000, 1_000) == 0


def test_provider_prefix_is_stripped() -> None:
    # litellm-style prefixes should resolve to the underlying model
    assert (
        calculate_cost_micros("openai/gpt-4o", 1_000_000, 1_000)
        == calculate_cost_micros("gpt-4o", 1_000_000, 1_000)
    )
    assert (
        calculate_cost_micros("gemini/gemini-2.5-pro", 100_000, 1_000)
        == calculate_cost_micros("gemini-2.5-pro", 100_000, 1_000)
    )
