# Changelog

All notable changes to the `superpenguin` Python SDK are documented here.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and the project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.0] — 2026-04-18

### Added

- **Google Gemini support** via the unified [`google-genai`](https://github.com/googleapis/python-genai) client (works against both AI Studio and Vertex AI).
  - `sp.wrap(genai.Client(...))` patches `client.models.generate_content`, `generate_content_stream`, and their async equivalents under `client.aio.models.*`.
  - Token counts, cached tokens, latency, tool-call detection, and `model_version` are extracted from both single-shot and streaming responses.
  - New `[google]` install extra: `pip install "superpenguin[google]"`.
- **Pricing table for Gemini text models** (Standard tier, verified against `https://ai.google.dev/gemini-api/docs/pricing` on 2026-04-16):
  - `gemini-3.1-pro-preview` (tiered at 200k input tokens)
  - `gemini-3.1-flash-lite-preview`
  - `gemini-3-flash-preview`
  - `gemini-2.5-pro` (tiered at 200k input tokens), `gemini-2.5-flash`, `gemini-2.5-flash-lite`
  - `gemini-2.0-flash`, `gemini-2.0-flash-lite`
- **Tiered pricing engine**: per-rate `[low, high]` lists paired with `tier_threshold` (in input tokens) so Gemini Pro SKUs bill the right rate above/below the long-context threshold.
- **Model alias map** (`_MODEL_ALIASES`) so stable names like `gemini-3.1-pro` resolve to the canonical `-preview` SKU.
- **Smarter model normalization**: in addition to ISO date suffixes (`-2025-09-15`, `-20250915`), the SDK now strips Google month-year suffixes (`-09-2025`) and Vertex version pins (`-001`, `-002`) before pricing lookup.
- `gemini` and `google` added to the package keyword list.

### Notes

- Audio and image input modalities for Gemini are billed separately by Google. The SDK currently tracks the text rate only — audio-heavy workloads will be under-counted by the SDK estimator (provider-side billing is unaffected).
- Batch / Flex / Priority Gemini tiers are not yet modeled; pricing assumes the paid Standard tier.

## [0.1.0] — 2026-04-11

Initial public release.

### Added

- `sp.init()`, `sp.wrap()`, `sp.flush()`, and the `@sp.trace` decorator.
- OpenAI client support (`chat.completions`, `completions`, `embeddings`, `responses`), including streaming.
- Anthropic client support (`messages`), including streaming.
- LiteLLM patching via `sp.patch_litellm()`.
- Background batched HTTP submission to `https://api.carrotlabs.ai/api/sdk/ingest` with `atexit` flush.
- Per-call attribution metadata (`customer_id`, `feature`, `team`, `environment`, `prompt_key`, `prompt_version`, plus arbitrary string custom tags).
