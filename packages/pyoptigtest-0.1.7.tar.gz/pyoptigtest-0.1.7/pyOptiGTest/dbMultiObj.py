"""
    pyOptiGTest - Database of multi-objective optimization test problems.

    This file is part of pyOptiGTest.

    MIT License
    Copyright (c) 2020 Luc LAURENT
    luc.laurent@lecnam.net

    Sources available at:
    https://github.com/luclaurent/optigtest/
"""



import json
import pathlib
from typing import Any

import numpy as np

_JSON_FILE: pathlib.Path = pathlib.Path(__file__).parent / "dbMultiObj.json"


def _convert_entry(entry: dict[str, Any]) -> dict[str, Any]:
    """Convert a JSON entry to the expected Python types (numpy arrays, etc.)."""
    dim: Any = entry.get("dim")
    if dim == "inf":
        entry["dim"] = np.inf
    elif isinstance(dim, (int, float)):
        entry["dim"] = int(dim)
    for key in ("minFglob",):
        if entry.get(key) is None:
            entry[key] = np.nan
    for key in ("minXglob",):
        v: Any = entry.get(key)
        if v is None:
            entry[key] = np.nan
        elif isinstance(v, list):
            entry[key] = np.asarray(v)
    if entry.get("space") is not None:
        entry["space"] = np.asarray(entry["space"])
    return entry


def listPb() -> dict[str, dict[str, Any]]:
    """Return a dictionary of all multi-objective optimization test problems.

    Each entry maps a problem name to a dict with keys:
        - funobj: list of objective function names
        - funcons: list of constraint function names (or None)
        - typecons: list of constraint types (or None)
        - type: 'MultiObjective'
        - dim: number of design variables (int or np.inf)
        - minFglob: np.nan (Pareto front, no single minimum)
        - minXglob: np.nan (Pareto set)
        - space: design space bounds as numpy array, shape (dim, 2) or list
    """
    with open(_JSON_FILE, "r") as f:
        raw: dict[str, dict[str, Any]] = json.load(f)
    return {name: _convert_entry(data) for name, data in raw.items()}


def loadPb(pbName: str | None = None) -> dict[str, Any]:
    """Load multi-objective problem(s) by name.

    Args:
        pbName: Problem name string. If None, return all problems.

    Returns:
        dict: Single problem dict if pbName given, else all problems.
    """

    allPb: dict[str, dict[str, Any]] = listPb()
    if pbName:
        return allPb.get(pbName, {})
    return allPb
