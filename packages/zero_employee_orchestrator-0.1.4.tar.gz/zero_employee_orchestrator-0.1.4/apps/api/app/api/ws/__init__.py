"""WebSocket event broadcasting."""
