"""Platform API — MCP, external skills, Sentry, IAM, hypothesis testing, session management.

API endpoints for cross-platform features added in v0.1.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps.database import get_db
from app.api.routes.auth import get_current_user
from app.models.user import User

router = APIRouter()


# ===================================================================
# MCP endpoints
# ===================================================================


class MCPToolCallRequest(BaseModel):
    name: str
    arguments: dict = {}


@router.get("/mcp/capabilities")
async def mcp_capabilities(user: User = Depends(get_current_user)):
    """Get MCP server capabilities."""
    from app.integrations.mcp_server import mcp_server

    return mcp_server.get_capabilities()


@router.get("/mcp/tools")
async def mcp_list_tools(user: User = Depends(get_current_user)):
    """List MCP tools."""
    from app.integrations.mcp_server import mcp_server

    return await mcp_server.handle_list_tools()


@router.post("/mcp/tools/call")
async def mcp_call_tool(req: MCPToolCallRequest, user: User = Depends(get_current_user)):
    """Execute MCP tool."""
    from app.integrations.mcp_server import mcp_server

    return await mcp_server.handle_call_tool(req.name, req.arguments)


@router.get("/mcp/resources")
async def mcp_list_resources(user: User = Depends(get_current_user)):
    """List MCP resources."""
    from app.integrations.mcp_server import mcp_server

    return await mcp_server.handle_list_resources()


@router.get("/mcp/prompts")
async def mcp_list_prompts(user: User = Depends(get_current_user)):
    """List MCP prompts."""
    from app.integrations.mcp_server import mcp_server

    return await mcp_server.handle_list_prompts()


# ===================================================================
# External skill import endpoints
# ===================================================================


class SkillSearchRequest(BaseModel):
    query: str
    source_type: str | None = None
    limit: int = 20


class SkillImportRequest(BaseModel):
    source_type: str  # github_agent_skills, skills_sh, openclaw, claude_code, git_repo, url
    source_uri: str


@router.post("/skills/external/search")
async def search_external_skills(req: SkillSearchRequest, user: User = Depends(get_current_user)):
    """Search for skills from external sources."""
    from app.integrations.external_skills import SkillSourceType, skill_importer

    source = SkillSourceType(req.source_type) if req.source_type else None
    results = await skill_importer.search_skills(req.query, source, req.limit)
    return {
        "results": [
            {
                "name": r.name,
                "slug": r.slug,
                "description": r.description,
                "source_type": r.source_type,
                "source_uri": r.source_uri,
                "author": r.author,
                "stars": r.stars,
                "downloads": r.downloads,
            }
            for r in results
        ],
        "total": len(results),
    }


@router.post("/skills/external/import")
async def import_external_skill(
    req: SkillImportRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Import and install a skill from an external source."""
    from app.integrations.external_skills import SkillSourceType, skill_importer
    from app.schemas.registry import SkillCreate
    from app.services import skill_service

    source_type = SkillSourceType(req.source_type)
    manifest = await skill_importer.fetch_skill_manifest(source_type, req.source_uri)
    if not manifest:
        raise HTTPException(status_code=404, detail="Unable to retrieve skill manifest")

    data = skill_importer.to_skill_create_data(manifest)

    # Check for existing
    existing = await skill_service.get_skill_by_slug(db, data["slug"])
    if existing:
        raise HTTPException(status_code=409, detail=f"Skill '{data['slug']}' already exists")

    skill = await skill_service.create_skill(db, SkillCreate(**data))
    await db.commit()

    return {
        "installed": True,
        "skill_id": str(skill.id),
        "name": skill.name,
        "slug": skill.slug,
        "source": req.source_type,
    }


# ===================================================================
# Sentry integration endpoints
# ===================================================================


@router.get("/sentry/stats")
async def sentry_stats(user: User = Depends(get_current_user)):
    """Sentry error statistics."""
    from app.integrations.sentry_integration import sentry

    return sentry.get_error_stats()


@router.get("/sentry/events")
async def sentry_events(
    level: str | None = None,
    event_type: str | None = None,
    limit: int = 50,
    user: User = Depends(get_current_user),
):
    """List Sentry events."""
    from app.integrations.sentry_integration import EventType, SeverityLevel, sentry

    lvl = SeverityLevel(level) if level else None
    et = EventType(event_type) if event_type else None
    events = sentry.get_recent_events(lvl, et, limit)
    return {
        "events": [e.to_dict() for e in events],
        "total": len(events),
    }


@router.post("/sentry/capture")
async def sentry_capture_message(
    message: str = "",
    level: str = "info",
    tags: dict | None = None,
    user: User = Depends(get_current_user),
):
    """Capture a custom event."""
    from app.integrations.sentry_integration import SeverityLevel, sentry

    event_id = sentry.capture_message(message, SeverityLevel(level), tags=tags)
    return {"event_id": event_id, "captured": True}


# ===================================================================
# IAM endpoints
# ===================================================================


class CreateAIAccountRequest(BaseModel):
    agent_id: str
    account_name: str
    company_id: str | None = None
    custom_permissions: list[str] | None = None


@router.post("/iam/ai-accounts")
async def create_ai_account(
    req: CreateAIAccountRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create a service account for an AI agent."""
    from app.security.iam import iam_manager

    account, token = await iam_manager.create_ai_account(
        db,
        req.agent_id,
        req.account_name,
        company_id=req.company_id,
        custom_permissions=req.custom_permissions,
    )
    await db.commit()
    return {
        "account_id": str(account.id),
        "agent_id": account.agent_id,
        "account_name": account.account_name,
        "token": token,  # Displayed only once
        "permissions": account.permissions,
    }


@router.get("/iam/ai-accounts")
async def list_ai_accounts(
    company_id: str | None = None,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """List AI service accounts."""
    from app.security.iam import iam_manager

    accounts = await iam_manager.list_ai_accounts(db, company_id)
    return {
        "accounts": [
            {
                "id": str(a.id),
                "agent_id": a.agent_id,
                "account_name": a.account_name,
                "account_type": a.account_type,
                "permissions": a.permissions,
                "is_active": a.is_active,
                "last_used_at": str(a.last_used_at) if a.last_used_at else None,
            }
            for a in accounts
        ],
    }


@router.delete("/iam/ai-accounts/{account_id}")
async def revoke_ai_account(
    account_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Revoke an AI service account."""
    from app.security.iam import iam_manager

    ok = await iam_manager.revoke_ai_account(db, account_id)
    await db.commit()
    if not ok:
        raise HTTPException(status_code=404, detail="Account not found")
    return {"revoked": True}


# ===================================================================
# AI Investigator endpoints
# ===================================================================


class DBQueryRequest(BaseModel):
    query: str = Field(..., description="Only SELECT statements can be executed")
    params: dict | None = None


class AuditSearchRequest(BaseModel):
    action_type: str | None = None
    entity_type: str | None = None
    actor_id: str | None = None
    since_hours: int = 24
    limit: int = 100


@router.post("/investigate/query")
async def investigate_query(
    req: DBQueryRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """AI investigation: safe DB read query."""
    from app.integrations.ai_investigator import ai_investigator

    result = await ai_investigator.query_db(db, req.query, req.params)
    return result.to_dict()


@router.post("/investigate/audit")
async def investigate_audit(
    req: AuditSearchRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """AI investigation: audit log search."""
    from app.integrations.ai_investigator import ai_investigator

    result = await ai_investigator.search_audit_logs(
        db,
        action_type=req.action_type,
        entity_type=req.entity_type,
        actor_id=req.actor_id,
        since_hours=req.since_hours,
        limit=req.limit,
    )
    return result.to_dict()


@router.get("/investigate/errors")
async def investigate_errors(
    since_hours: int = 24,
    limit: int = 50,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """AI investigation: error pattern analysis."""
    from app.integrations.ai_investigator import ai_investigator

    result = await ai_investigator.analyze_errors(db, since_hours, limit)
    return result.to_dict()


@router.get("/investigate/metrics")
async def investigate_metrics(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """AI investigation: system metrics."""
    from app.integrations.ai_investigator import ai_investigator

    return await ai_investigator.get_system_metrics(db)


@router.get("/investigate/history")
async def investigate_history(limit: int = 50, user: User = Depends(get_current_user)):
    """AI investigation: investigation history."""
    from app.integrations.ai_investigator import ai_investigator

    return {"history": ai_investigator.get_investigation_history(limit)}


# ===================================================================
# Hypothesis testing endpoints
# ===================================================================


class HypothesisRequest(BaseModel):
    title: str
    description: str
    proposer_agent_id: str
    task_id: str | None = None
    company_id: str | None = None
    priority: int = 0


class EvidenceRequest(BaseModel):
    hypothesis_id: str
    agent_id: str
    supports: bool
    description: str
    source: str = ""
    confidence: float = 0.5
    data: dict | None = None


class ReviewRequest(BaseModel):
    hypothesis_id: str
    reviewer_agent_id: str
    verdict: str  # agree, disagree, needs_more_evidence, partially_agree
    reasoning: str
    confidence: float = 0.5
    suggested_actions: list[str] = []


@router.post("/hypotheses")
async def propose_hypothesis(req: HypothesisRequest, user: User = Depends(get_current_user)):
    """Propose a hypothesis."""
    from app.orchestration.hypothesis_engine import hypothesis_engine

    h = hypothesis_engine.propose(
        req.title,
        req.description,
        req.proposer_agent_id,
        task_id=req.task_id,
        company_id=req.company_id,
        priority=req.priority,
    )
    return h.to_dict()


@router.get("/hypotheses")
async def list_hypotheses(
    company_id: str | None = None,
    task_id: str | None = None,
    user: User = Depends(get_current_user),
):
    """List hypotheses."""
    from app.orchestration.hypothesis_engine import hypothesis_engine

    if task_id:
        hypotheses = hypothesis_engine.get_by_task(task_id)
    else:
        hypotheses = hypothesis_engine.get_active(company_id)
    return {"hypotheses": [h.to_dict() for h in hypotheses]}


@router.get("/hypotheses/{hypothesis_id}")
async def get_hypothesis(hypothesis_id: str, user: User = Depends(get_current_user)):
    """Get hypothesis details."""
    from app.orchestration.hypothesis_engine import hypothesis_engine

    h = hypothesis_engine.get(hypothesis_id)
    if not h:
        raise HTTPException(status_code=404, detail="Hypothesis not found")
    return h.to_dict()


@router.post("/hypotheses/evidence")
async def add_evidence(req: EvidenceRequest, user: User = Depends(get_current_user)):
    """Add evidence."""
    from app.orchestration.hypothesis_engine import hypothesis_engine

    ev = hypothesis_engine.add_evidence(
        req.hypothesis_id,
        req.agent_id,
        req.supports,
        req.description,
        source=req.source,
        confidence=req.confidence,
        data=req.data,
    )
    if not ev:
        raise HTTPException(status_code=404, detail="Hypothesis not found")
    return {"evidence_id": ev.evidence_id, "added": True}


@router.post("/hypotheses/review")
async def submit_review(req: ReviewRequest, user: User = Depends(get_current_user)):
    """Submit a review."""
    from app.orchestration.hypothesis_engine import ReviewVerdict, hypothesis_engine

    review = hypothesis_engine.submit_review(
        req.hypothesis_id,
        req.reviewer_agent_id,
        ReviewVerdict(req.verdict),
        req.reasoning,
        confidence=req.confidence,
        suggested_actions=req.suggested_actions,
    )
    if not review:
        raise HTTPException(status_code=404, detail="Hypothesis not found")
    return {"review_id": review.review_id, "submitted": True}


@router.post("/hypotheses/{hypothesis_id}/resolve")
async def resolve_hypothesis(
    hypothesis_id: str, confirmed: bool = True, user: User = Depends(get_current_user)
):
    """Resolve a hypothesis."""
    from app.orchestration.hypothesis_engine import hypothesis_engine

    ok = hypothesis_engine.resolve(hypothesis_id, confirmed)
    if not ok:
        raise HTTPException(status_code=404, detail="Hypothesis not found")
    return {"resolved": True, "confirmed": confirmed}


@router.get("/hypotheses/needing-review")
async def hypotheses_needing_review(
    company_id: str | None = None, user: User = Depends(get_current_user)
):
    """List hypotheses needing review."""
    from app.orchestration.hypothesis_engine import hypothesis_engine

    hypotheses = hypothesis_engine.get_needing_review(company_id)
    return {"hypotheses": [h.to_dict() for h in hypotheses]}


# ===================================================================
# Agent session endpoints
# ===================================================================


class CreateSessionRequest(BaseModel):
    agent_id: str
    role: str = "general"
    company_id: str | None = None
    task_id: str | None = None
    initial_context: dict | None = None
    ttl: float = 86400


class SessionMessageRequest(BaseModel):
    session_id: str
    role: str
    content: str
    metadata: dict | None = None


class WorkingMemoryRequest(BaseModel):
    session_id: str
    key: str
    value: dict | str | list | int | float | bool | None


@router.post("/sessions")
async def create_session(req: CreateSessionRequest, user: User = Depends(get_current_user)):
    """Create an agent session."""
    from app.orchestration.agent_session import session_manager

    session = session_manager.create_session(
        req.agent_id,
        req.role,
        company_id=req.company_id,
        task_id=req.task_id,
        initial_context=req.initial_context,
        ttl=req.ttl,
    )
    return session.to_dict()


@router.get("/sessions")
async def list_sessions(
    company_id: str | None = None,
    status: str | None = None,
    agent_id: str | None = None,
    user: User = Depends(get_current_user),
):
    """List sessions."""
    from app.orchestration.agent_session import SessionStatus, session_manager

    st = SessionStatus(status) if status else None
    sessions = session_manager.list_sessions(company_id, st, agent_id)
    return {"sessions": [s.to_dict() for s in sessions]}


@router.get("/sessions/{session_id}")
async def get_session(session_id: str, user: User = Depends(get_current_user)):
    """Get session details."""
    from app.orchestration.agent_session import session_manager

    session = session_manager.get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    return session.to_dict()


@router.get("/sessions/agent/{agent_id}")
async def get_agent_session(agent_id: str, user: User = Depends(get_current_user)):
    """Get active session for an agent."""
    from app.orchestration.agent_session import session_manager

    session = session_manager.get_active_session(agent_id)
    if not session:
        raise HTTPException(status_code=404, detail="No active session found")
    return session.to_dict()


@router.post("/sessions/agent/{agent_id}/get-or-create")
async def get_or_create_session(
    agent_id: str, req: CreateSessionRequest, user: User = Depends(get_current_user)
):
    """Get session or create if not found."""
    from app.orchestration.agent_session import session_manager

    session = session_manager.get_or_create_session(
        agent_id,
        req.role,
        company_id=req.company_id,
        task_id=req.task_id,
        initial_context=req.initial_context,
        ttl=req.ttl,
    )
    return session.to_dict()


@router.post("/sessions/message")
async def add_session_message(req: SessionMessageRequest, user: User = Depends(get_current_user)):
    """Add a message to a session."""
    from app.orchestration.agent_session import session_manager

    session = session_manager.get_session(req.session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    session.add_message(req.role, req.content, req.metadata)
    return {"added": True, "message_count": session.message_count}


@router.post("/sessions/memory")
async def add_working_memory(req: WorkingMemoryRequest, user: User = Depends(get_current_user)):
    """Add information to working memory."""
    from app.orchestration.agent_session import session_manager

    session = session_manager.get_session(req.session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    session.add_to_working_memory(req.key, req.value)
    return {"stored": True, "key": req.key}


@router.post("/sessions/{session_id}/idle")
async def set_session_idle(session_id: str, user: User = Depends(get_current_user)):
    """Set session to idle state."""
    from app.orchestration.agent_session import session_manager

    session = session_manager.get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    session.go_idle()
    return {"status": "idle", "session_id": session_id}


@router.post("/sessions/{session_id}/resume")
async def resume_session(session_id: str, user: User = Depends(get_current_user)):
    """Resume a session."""
    from app.orchestration.agent_session import session_manager

    session = session_manager.get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    session.resume()
    return session.get_context_summary()


@router.delete("/sessions/{session_id}")
async def terminate_session(session_id: str, user: User = Depends(get_current_user)):
    """Terminate a session."""
    from app.orchestration.agent_session import session_manager

    ok = session_manager.terminate_session(session_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Session not found")
    return {"terminated": True}
