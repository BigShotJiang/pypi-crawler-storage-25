"""Task execution endpoints with state machine enforcement."""

import uuid
from datetime import UTC, datetime

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps.database import get_db
from app.api.deps.validators import parse_uuid
from app.api.routes.auth import get_current_user
from app.models.task import Task, TaskRun
from app.models.user import User
from app.services.task_service import (
    complete_task as svc_complete_task,
)
from app.services.task_service import (
    request_task_approval as svc_request_approval,
)
from app.services.task_service import (
    resolve_task_provider,
    validate_task_transition,
)
from app.services.task_service import (
    start_task as svc_start_task,
)

router = APIRouter()


class TaskProviderOverride(BaseModel):
    """Per-task provider override."""

    provider: str | None = None  # e.g. "anthropic", "openai", "ollama"
    model: str | None = None  # e.g. "anthropic/claude-opus"
    execution_mode: str | None = None  # e.g. "quality", "speed", "cost"


class TaskCreate(BaseModel):
    title: str
    description: str = ""
    task_type: str = "execution"
    requires_approval: bool = False
    sequence_no: int = 0
    provider_override: TaskProviderOverride | None = None


@router.post("/plans/{plan_id}/tasks")
async def create_task(
    plan_id: str,
    req: TaskCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Create a task."""
    task = Task(
        id=uuid.uuid4(),
        plan_id=parse_uuid(plan_id, "plan_id"),
        title=req.title,
        description=req.description,
        sequence_no=req.sequence_no,
        status="pending",
        task_type=req.task_type,
        requires_approval=req.requires_approval,
        provider_override_json=(
            req.provider_override.model_dump(exclude_none=True) if req.provider_override else None
        ),
    )
    db.add(task)
    await db.flush()
    return {
        "id": str(task.id),
        "title": task.title,
        "status": task.status,
        "provider_override": task.provider_override_json,
    }


@router.patch("/tasks/{task_id}/provider")
async def update_task_provider(
    task_id: str,
    req: TaskProviderOverride,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Update task provider override."""
    result = await db.execute(select(Task).where(Task.id == parse_uuid(task_id, "task_id")))
    task = result.scalar_one_or_none()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    if task.status not in ("pending", "ready", "blocked"):
        raise HTTPException(
            status_code=400,
            detail=f"Cannot change provider for task in status: {task.status}",
        )
    override = req.model_dump(exclude_none=True)
    task.provider_override_json = override if override else None
    await db.commit()
    return {
        "id": str(task.id),
        "title": task.title,
        "provider_override": task.provider_override_json,
    }


@router.post("/tasks/{task_id}/start")
async def start_task(
    task_id: str, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)
):
    """Start task execution (state machine enforced)."""
    result = await db.execute(select(Task).where(Task.id == parse_uuid(task_id, "task_id")))
    task = result.scalar_one_or_none()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    try:
        run = await svc_start_task(db, task)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    # Provider resolution & execution monitor notification
    resolved = resolve_task_provider(task)
    try:
        from app.orchestration.execution_monitor import get_execution_monitor

        monitor = get_execution_monitor()
        await monitor.on_task_started(
            task_id=str(task.id),
            agent_id=str(task.assignee_agent_id) if task.assignee_agent_id else "system",
            company_id=str(task.company_id),
            model=resolved.get("model"),
            provider_override=task.provider_override_json,
        )
    except Exception:
        pass  # Continue task execution even if monitor is unavailable

    return {
        "status": "running",
        "run_id": str(run.id),
        "run_no": run.run_no,
        "resolved_provider": resolved,
    }


@router.post("/tasks/{task_id}/complete")
async def complete_task(
    task_id: str, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)
):
    """Complete task."""
    result = await db.execute(select(Task).where(Task.id == parse_uuid(task_id, "task_id")))
    task = result.scalar_one_or_none()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    run_result = await db.execute(
        select(TaskRun).where(TaskRun.task_id == task.id, TaskRun.status == "running")
    )
    run = run_result.scalar_one_or_none()
    if not run:
        raise HTTPException(status_code=400, detail="No running task run found")

    try:
        task = await svc_complete_task(db, task, run, success=True)
        return {"status": task.status}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/tasks/{task_id}/retry")
async def retry_task(
    task_id: str, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)
):
    """Retry task."""
    result = await db.execute(select(Task).where(Task.id == parse_uuid(task_id, "task_id")))
    task = result.scalar_one_or_none()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    if not validate_task_transition(task.status, "retrying"):
        raise HTTPException(status_code=400, detail=f"Cannot retry from status: {task.status}")
    task.status = "retrying"
    await db.commit()
    return {"status": "retrying"}


@router.post("/tasks/{task_id}/request-approval")
async def request_approval(
    task_id: str, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)
):
    """Request task approval."""
    result = await db.execute(select(Task).where(Task.id == parse_uuid(task_id, "task_id")))
    task = result.scalar_one_or_none()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    try:
        task = await svc_request_approval(db, task)
        return {"status": task.status}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/tasks/{task_id}/runs")
async def create_task_run(
    task_id: str, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)
):
    """Create a task run record."""
    tid = parse_uuid(task_id, "task_id")
    existing = await db.execute(select(TaskRun).where(TaskRun.task_id == tid))
    count = len(existing.scalars().all())
    run = TaskRun(
        id=uuid.uuid4(),
        task_id=tid,
        run_no=count + 1,
        status="running",
        started_at=datetime.now(UTC),
    )
    db.add(run)
    await db.flush()
    return {"id": str(run.id), "run_no": run.run_no, "status": run.status}


@router.get("/tasks/{task_id}/runs")
async def list_task_runs(
    task_id: str, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)
):
    """List task run history."""
    tid = parse_uuid(task_id, "task_id")
    result = await db.execute(
        select(TaskRun).where(TaskRun.task_id == tid).order_by(TaskRun.run_no.desc())
    )
    runs = result.scalars().all()
    return [
        {
            "id": str(r.id),
            "run_no": r.run_no,
            "status": r.status,
            "started_at": r.started_at.isoformat() if r.started_at else None,
            "finished_at": r.finished_at.isoformat() if r.finished_at else None,
        }
        for r in runs
    ]
