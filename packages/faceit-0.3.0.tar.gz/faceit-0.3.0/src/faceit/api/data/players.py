from __future__ import annotations

import logging
import warnings
from abc import ABC
from typing import (
    Annotated,
    Any,
    ClassVar,
    Generic,
    Literal,
    TypeAlias,
    final,
    overload,
)

from pydantic import AfterValidator, Field, validate_call

from faceit.api.base import (
    BaseResource,
    MappedValidatorConfig,
    RequestPayload,
)
from faceit.api.pagination import (
    AsyncPageIterator,
    MaxItems,
    MaxItemsType,
    SyncPageIterator,
    TimestampPaginationConfig,
    pages,
)
from faceit.constants import GameID
from faceit.http import AsyncClient, SyncClient
from faceit.models import (
    BanEntry,
    CS2MatchPlayerStats,
    CSPlayerStats,
    FallbackPlayerStats,
    GeneralTeam,
    Hub,
    ItemPage,
    Match,
    Player,
    Tournament,
)
from faceit.models.custom_types import NotStrictTimestampMs  # noqa: TC001
from faceit.models.players.general import AnyPlayerStats
from faceit.models.players.match import AbstractMatchPlayerStats
from faceit.types import (
    AnyCSID,
    APIResponseFormatT,
    ClientT,
    Model,
    Raw,
    RawAPIItem,
    RawAPIPageResponse,
    ValidUUID,
)
from faceit.utils import is_valid_uuid

from .helpers import validate_player_id, validate_player_id_or_nickname

_logger = logging.getLogger(__name__)

PlayerID: TypeAlias = ValidUUID
PlayerIDValidated: TypeAlias = Annotated[PlayerID, AfterValidator(validate_player_id)]
_PlayerIdentifier: TypeAlias = str | ValidUUID
_PlayerIdentifierValidated: TypeAlias = Annotated[
    _PlayerIdentifier, AfterValidator(validate_player_id_or_nickname)
]


class BasePlayers(
    BaseResource[ClientT],
    ABC,
    resource_path="players",
):
    __slots__ = ()

    _matches_stats_validator_cfg: ClassVar = MappedValidatorConfig[
        GameID, AbstractMatchPlayerStats
    ](
        validator_map={
            GameID.CS2: CS2MatchPlayerStats,
            # TODO: Add other games (e.g. CSGO)
        },
        key_name="game",
    )
    _stats_validator_cfg: ClassVar = MappedValidatorConfig[GameID, AnyPlayerStats](
        validator_map={
            GameID.CS2: CSPlayerStats,
            GameID.CSGO: CSPlayerStats,
        },
        key_name="game",
        default_validator=FallbackPlayerStats,
    )

    _matches_stats_timestamp_cfg: ClassVar = TimestampPaginationConfig(
        key="stats.Match Finished At", attr="finished_at"
    )
    _history_timestamp_cfg: ClassVar = TimestampPaginationConfig(
        key="finished_at", attr="finished_at"
    )

    def _process_get_request(
        self,
        player_lookup_key: Any,
        game: GameID | None,
        game_player_id: str | None,
    ) -> RequestPayload:
        params = self.__class__._build_params(game=game, game_player_id=game_player_id)

        if player_lookup_key is None:
            if game is None or game_player_id is None:
                msg = (
                    "When 'player_lookup_key' is not provided, "
                    "both 'game' AND 'game_player_id' must be specified"
                )
                raise ValueError(msg)
            _logger.debug(
                "Fetching player by game parameters: game=%s, game_player_id=%s",
                game,
                game_player_id,
            )
            return RequestPayload(endpoint=self.__class__.PATH, params=params)

        if game is not None or game_player_id is not None:
            warnings.warn(
                "When 'player_lookup_key' is provided, "
                "'game' and 'game_player_id' should not be specified. "
                "The value of 'player_lookup_key' will take precedence.",
                stacklevel=5,
            )

        if is_valid_uuid(player_lookup_key):
            _logger.debug("Fetching player by UUID: %s", player_lookup_key)
            return RequestPayload(
                endpoint=self.__class__.PATH / str(player_lookup_key), params=params
            )

        _logger.debug("Fetching player by nickname: %s", player_lookup_key)
        params["nickname"] = str(player_lookup_key)
        return RequestPayload(endpoint=self.__class__.PATH, params=params)


@final
class SyncPlayers(BasePlayers[SyncClient], Generic[APIResponseFormatT]):
    __slots__ = ()

    @overload
    def get(
        self: SyncPlayers[Raw], player_lookup_key: _PlayerIdentifier
    ) -> RawAPIItem: ...

    @overload
    def get(
        self: SyncPlayers[Raw], *, game: GameID, game_player_id: str
    ) -> RawAPIItem: ...

    @overload
    def get(
        self: SyncPlayers[Model], player_lookup_key: _PlayerIdentifier
    ) -> Player: ...

    @overload
    def get(
        self: SyncPlayers[Model], *, game: GameID, game_player_id: str
    ) -> Player: ...

    @validate_call
    def get(
        self,
        player_lookup_key: _PlayerIdentifierValidated | None = None,
        *,
        game: GameID | None = None,
        game_player_id: str | None = None,
    ) -> RawAPIItem | Player:
        return self._validate_response(
            self._client.get(
                **self._process_get_request(player_lookup_key, game, game_player_id),
                expect_item=True,
            ),
            Player,
        )

    # This creates an alias allowing instances to be called directly like `resource(...)`
    # instead of `resource.get(...)`. While both forms are valid, using the explicit `.get()`
    # method is generally preferred for clarity. NOTE: The alias is maintained for convenience.
    __call__ = get

    # Using `Field(...)` as default value rather than `Annotated[..., Field(...)]`
    # to expose constraints in IDE tooltips and improve developer experience.
    @overload
    def bans(
        self: SyncPlayers[Raw],
        player_id: PlayerID,
        *,
        offset: int = Field(0, ge=0),
        limit: int = Field(20, ge=1, le=100),
    ) -> RawAPIPageResponse: ...

    @overload
    def bans(
        self: SyncPlayers[Model],
        player_id: PlayerID,
        *,
        offset: int = Field(0, ge=0),
        limit: int = Field(20, ge=1, le=100),
    ) -> ItemPage[BanEntry]: ...

    @validate_call
    def bans(
        self,
        player_id: PlayerIDValidated,
        *,
        offset: int = Field(0, ge=0),
        limit: int = Field(20, ge=1, le=100),
    ) -> RawAPIPageResponse | ItemPage[BanEntry]:
        return self._validate_response(
            self._client.get(
                # `player_id` is validated and normalized;
                # `str()` is only for mypy type narrowing.
                self.__class__.PATH / str(player_id) / "bans",
                params=self.__class__._build_params(offset=offset, limit=limit),
                expect_page=True,
            ),
            ItemPage[BanEntry],
        )

    @overload
    def all_bans(
        self: SyncPlayers[Raw],
        player_id: PlayerID,
        max_items: MaxItemsType = MaxItems.SAFE,
    ) -> list[RawAPIItem]: ...

    @overload
    def all_bans(
        self: SyncPlayers[Model],
        player_id: PlayerID,
        max_items: MaxItemsType = MaxItems.SAFE,
    ) -> ItemPage[BanEntry]: ...

    def all_bans(
        self, player_id: PlayerID, max_items: MaxItemsType = MaxItems.SAFE
    ) -> list[RawAPIItem] | ItemPage[BanEntry]:
        iterator = SyncPageIterator(self.bans, player_id, max_items=max_items)
        return iterator.collect()

    @overload
    def matches_stats(
        self: SyncPlayers[Raw],
        player_id: PlayerID,
        game: GameID,
        *,
        offset: int = Field(0, ge=0, le=200),
        limit: int = Field(20, ge=1, le=100),
        start: NotStrictTimestampMs | None = None,
        to: NotStrictTimestampMs | None = None,
    ) -> RawAPIPageResponse: ...

    # TODO: This overload-based approach for specific games feels clunky and doesn't scale well.
    # Need to investigate a more sophisticated way to map `GameID` to specific models,
    # but this is the current best effort.
    @overload
    def matches_stats(
        self: SyncPlayers[Model],
        player_id: PlayerID,
        game: Literal[GameID.CS2],
        *,
        offset: int = Field(0, ge=0, le=200),
        limit: int = Field(20, ge=1, le=100),
        start: NotStrictTimestampMs | None = None,
        to: NotStrictTimestampMs | None = None,
    ) -> ItemPage[CS2MatchPlayerStats]: ...

    @overload
    def matches_stats(  # Fallback
        self: SyncPlayers[Model],
        player_id: PlayerID,
        game: GameID,
        *,
        offset: int = Field(0, ge=0, le=200),
        limit: int = Field(20, ge=1, le=100),
        start: NotStrictTimestampMs | None = None,
        to: NotStrictTimestampMs | None = None,
    ) -> ItemPage[AbstractMatchPlayerStats]: ...

    @validate_call
    def matches_stats(
        self,
        player_id: PlayerIDValidated,
        game: GameID,
        *,
        offset: int = Field(0, ge=0, le=200),
        limit: int = Field(20, ge=1, le=100),
        start: NotStrictTimestampMs | None = None,
        to: NotStrictTimestampMs | None = None,
    ) -> (
        RawAPIPageResponse
        | ItemPage[CS2MatchPlayerStats]
        | ItemPage[AbstractMatchPlayerStats]
    ):
        return self._process_page(
            self._client.get(
                self.__class__.PATH / str(player_id) / "games" / game / "stats",
                params=self.__class__._build_params(
                    offset=offset, limit=limit, start=start, to=to
                ),
                expect_page=True,
            ),
            game,
            self.__class__._matches_stats_validator_cfg,
        )

    @overload
    def all_matches_stats(
        self: SyncPlayers[Raw],
        player_id: PlayerID,
        game: GameID,
        max_items: MaxItemsType = pages(50),
    ) -> list[RawAPIItem]: ...

    @overload
    def all_matches_stats(
        self: SyncPlayers[Model],
        player_id: PlayerID,
        game: Literal[GameID.CS2],
        max_items: MaxItemsType = pages(50),
    ) -> ItemPage[CS2MatchPlayerStats]: ...

    @overload
    def all_matches_stats(
        self: SyncPlayers[Model],
        player_id: PlayerID,
        game: GameID,
        max_items: MaxItemsType = pages(50),
    ) -> ItemPage[AbstractMatchPlayerStats]: ...

    def all_matches_stats(
        self,
        player_id: PlayerID,
        game: GameID,
        max_items: MaxItemsType = pages(50),
    ) -> (
        list[RawAPIItem]
        | ItemPage[CS2MatchPlayerStats]
        | ItemPage[AbstractMatchPlayerStats]
    ):
        return SyncPageIterator.gather_from_iterator(
            SyncPageIterator.unix(
                self.matches_stats,
                player_id,
                game,
                cfg=self.__class__._matches_stats_timestamp_cfg,
                max_items=max_items,
            )
        )

    @overload
    def history(
        self: SyncPlayers[Raw],
        player_id: PlayerID,
        game: GameID,
        *,
        offset: int = Field(0, ge=0, le=1000),
        limit: int = Field(20, ge=1, le=100),
        start: NotStrictTimestampMs | None = None,
        to: NotStrictTimestampMs | None = None,
    ) -> RawAPIPageResponse: ...

    @overload
    def history(
        self: SyncPlayers[Model],
        player_id: PlayerID,
        game: GameID,
        *,
        offset: int = Field(0, ge=0, le=1000),
        limit: int = Field(20, ge=1, le=100),
        start: NotStrictTimestampMs | None = None,
        to: NotStrictTimestampMs | None = None,
    ) -> ItemPage[Match]: ...

    @validate_call
    def history(
        self,
        player_id: PlayerIDValidated,
        game: GameID,
        *,
        offset: int = Field(0, ge=0, le=1000),
        limit: int = Field(20, ge=1, le=100),
        start: NotStrictTimestampMs | None = None,
        to: NotStrictTimestampMs | None = None,
    ) -> RawAPIPageResponse | ItemPage[Match]:
        return self._validate_response(
            self._client.get(
                self.__class__.PATH / str(player_id) / "history",
                params=self.__class__._build_params(
                    game=game, offset=offset, limit=limit, start=start, to=to
                ),
                expect_page=True,
            ),
            ItemPage[Match],
        )

    @overload
    def all_history(
        self: SyncPlayers[Raw],
        player_id: PlayerID,
        game: GameID,
        max_items: MaxItemsType = pages(50),
    ) -> list[RawAPIItem]: ...

    @overload
    def all_history(
        self: SyncPlayers[Model],
        player_id: PlayerID,
        game: GameID,
        max_items: MaxItemsType = pages(50),
    ) -> ItemPage[Match]: ...

    def all_history(
        self,
        player_id: PlayerID,
        game: GameID,
        max_items: MaxItemsType = pages(50),
    ) -> list[RawAPIItem] | ItemPage[Match]:
        return SyncPageIterator.gather_from_iterator(
            SyncPageIterator.unix(
                self.history,
                player_id,
                game,
                cfg=self.__class__._history_timestamp_cfg,
                max_items=max_items,
            )
        )

    @overload
    def hubs(
        self: SyncPlayers[Raw],
        player_id: PlayerID,
        *,
        offset: int = Field(0, ge=0, le=1000),
        limit: int = Field(50, ge=1, le=50),
    ) -> RawAPIPageResponse: ...

    @overload
    def hubs(
        self: SyncPlayers[Model],
        player_id: PlayerID,
        *,
        offset: int = Field(0, ge=0, le=1000),
        limit: int = Field(50, ge=1, le=50),
    ) -> ItemPage[Hub]: ...

    @validate_call
    def hubs(
        self,
        player_id: PlayerIDValidated,
        *,
        offset: int = Field(0, ge=0, le=1000),
        limit: int = Field(50, ge=1, le=50),
    ) -> RawAPIPageResponse | ItemPage[Hub]:
        return self._validate_response(
            self._client.get(
                self.__class__.PATH / str(player_id) / "hubs",
                params=self.__class__._build_params(offset=offset, limit=limit),
                expect_page=True,
            ),
            ItemPage[Hub],
        )

    @overload
    def all_hubs(
        self: SyncPlayers[Raw],
        player_id: PlayerID,
        max_items: MaxItemsType = MaxItems.SAFE,
    ) -> list[RawAPIItem]: ...

    @overload
    def all_hubs(
        self: SyncPlayers[Model],
        player_id: PlayerID,
        max_items: MaxItemsType = MaxItems.SAFE,
    ) -> ItemPage[Hub]: ...

    def all_hubs(
        self, player_id: PlayerID, max_items: MaxItemsType = MaxItems.SAFE
    ) -> list[RawAPIItem] | ItemPage[Hub]:
        iterator = SyncPageIterator(self.hubs, player_id, max_items=max_items)
        return iterator.collect()

    @overload
    def stats(
        self: SyncPlayers[Raw], player_id: PlayerID, game: GameID
    ) -> RawAPIItem: ...

    @overload
    def stats(  # type: ignore[overload-overlap]
        self: SyncPlayers[Model], player_id: PlayerID, game: AnyCSID
    ) -> CSPlayerStats: ...

    @overload
    def stats(
        self: SyncPlayers[Model], player_id: PlayerID, game: GameID
    ) -> FallbackPlayerStats: ...

    @validate_call
    def stats(
        self, player_id: PlayerIDValidated, game: GameID
    ) -> RawAPIItem | AnyPlayerStats:
        return self._process_item(
            self._client.get(
                self.__class__.PATH / str(player_id) / "stats" / game,
                expect_item=True,
            ),
            game,
            self.__class__._stats_validator_cfg,
        )

    @overload
    def teams(
        self: SyncPlayers[Raw],
        player_id: PlayerID,
        *,
        offset: int = Field(0, ge=0),
        limit: int = Field(20, ge=1, le=100),
    ) -> RawAPIPageResponse: ...

    @overload
    def teams(
        self: SyncPlayers[Model],
        player_id: PlayerID,
        *,
        offset: int = Field(0, ge=0),
        limit: int = Field(20, ge=1, le=100),
    ) -> ItemPage[GeneralTeam]: ...

    @validate_call
    def teams(
        self,
        player_id: PlayerIDValidated,
        *,
        offset: int = Field(0, ge=0),
        limit: int = Field(20, ge=1, le=100),
    ) -> RawAPIPageResponse | ItemPage[GeneralTeam]:
        return self._validate_response(
            self._client.get(
                self.__class__.PATH / str(player_id) / "teams",
                params=self.__class__._build_params(offset=offset, limit=limit),
                expect_page=True,
            ),
            ItemPage[GeneralTeam],
        )

    @overload
    def all_teams(
        self: SyncPlayers[Raw],
        player_id: PlayerID,
        max_items: MaxItemsType = MaxItems.SAFE,
    ) -> list[RawAPIItem]: ...

    @overload
    def all_teams(
        self: SyncPlayers[Model],
        player_id: PlayerID,
        max_items: MaxItemsType = MaxItems.SAFE,
    ) -> ItemPage[GeneralTeam]: ...

    def all_teams(
        self, player_id: PlayerID, max_items: MaxItemsType = MaxItems.SAFE
    ) -> list[RawAPIItem] | ItemPage[GeneralTeam]:
        iterator = SyncPageIterator(self.teams, player_id, max_items=max_items)
        return iterator.collect()

    @overload
    def tournaments(
        self: SyncPlayers[Raw],
        player_id: PlayerID,
        *,
        offset: int = Field(0, ge=0),
        limit: int = Field(20, ge=1, le=100),
    ) -> RawAPIPageResponse: ...

    @overload
    def tournaments(
        self: SyncPlayers[Model],
        player_id: PlayerID,
        *,
        offset: int = Field(0, ge=0),
        limit: int = Field(20, ge=1, le=100),
    ) -> ItemPage[Tournament]: ...

    @validate_call
    def tournaments(
        self,
        player_id: PlayerIDValidated,
        *,
        offset: int = Field(0, ge=0),
        limit: int = Field(20, ge=1, le=100),
    ) -> RawAPIPageResponse | ItemPage[Tournament]:
        return self._validate_response(
            self._client.get(
                self.__class__.PATH / str(player_id) / "tournaments",
                params=self.__class__._build_params(offset=offset, limit=limit),
                expect_page=True,
            ),
            ItemPage[Tournament],
        )

    @overload
    def all_tournaments(
        self: SyncPlayers[Raw],
        player_id: PlayerID,
        max_items: MaxItemsType = MaxItems.SAFE,
    ) -> list[RawAPIItem]: ...

    @overload
    def all_tournaments(
        self: SyncPlayers[Model],
        player_id: PlayerID,
        max_items: MaxItemsType = MaxItems.SAFE,
    ) -> ItemPage[Tournament]: ...

    def all_tournaments(
        self, player_id: PlayerID, max_items: MaxItemsType = MaxItems.SAFE
    ) -> list[RawAPIItem] | ItemPage[Tournament]:
        iterator = SyncPageIterator(self.tournaments, player_id, max_items=max_items)
        return iterator.collect()


@final
class AsyncPlayers(BasePlayers[AsyncClient], Generic[APIResponseFormatT]):
    __slots__ = ()

    @overload
    async def get(
        self: AsyncPlayers[Raw], player_lookup_key: _PlayerIdentifier
    ) -> RawAPIItem: ...

    @overload
    async def get(
        self: AsyncPlayers[Raw], *, game: GameID, game_player_id: str
    ) -> RawAPIItem: ...

    @overload
    async def get(
        self: AsyncPlayers[Model], player_lookup_key: _PlayerIdentifier
    ) -> Player: ...

    @overload
    async def get(
        self: AsyncPlayers[Model], *, game: GameID, game_player_id: str
    ) -> Player: ...

    @validate_call
    async def get(
        self,
        player_lookup_key: _PlayerIdentifierValidated | None = None,
        *,
        game: GameID | None = None,
        game_player_id: str | None = None,
    ) -> RawAPIItem | Player:
        return self._validate_response(
            await self._client.get(
                **self._process_get_request(player_lookup_key, game, game_player_id),
                expect_item=True,
            ),
            Player,
        )

    __call__ = get

    @overload
    async def bans(
        self: AsyncPlayers[Raw],
        player_id: PlayerID,
        *,
        offset: int = Field(0, ge=0),
        limit: int = Field(20, ge=1, le=100),
    ) -> RawAPIPageResponse: ...

    @overload
    async def bans(
        self: AsyncPlayers[Model],
        player_id: PlayerID,
        *,
        offset: int = Field(0, ge=0),
        limit: int = Field(20, ge=1, le=100),
    ) -> ItemPage[BanEntry]: ...

    @validate_call
    async def bans(
        self,
        player_id: PlayerIDValidated,
        *,
        offset: int = Field(0, ge=0),
        limit: int = Field(20, ge=1, le=100),
    ) -> RawAPIPageResponse | ItemPage[BanEntry]:
        return self._validate_response(
            await self._client.get(
                self.__class__.PATH / str(player_id) / "bans",
                params=self.__class__._build_params(offset=offset, limit=limit),
                expect_page=True,
            ),
            ItemPage[BanEntry],
        )

    @overload
    async def all_bans(
        self: AsyncPlayers[Raw],
        player_id: PlayerID,
        max_items: MaxItemsType = MaxItems.SAFE,
    ) -> list[RawAPIItem]: ...

    @overload
    async def all_bans(
        self: AsyncPlayers[Model],
        player_id: PlayerID,
        max_items: MaxItemsType = MaxItems.SAFE,
    ) -> ItemPage[BanEntry]: ...

    async def all_bans(
        self, player_id: PlayerID, max_items: MaxItemsType = MaxItems.SAFE
    ) -> list[RawAPIItem] | ItemPage[BanEntry]:
        iterator = AsyncPageIterator(self.bans, player_id, max_items=max_items)
        return await iterator.collect()

    @overload
    async def matches_stats(
        self: AsyncPlayers[Raw],
        player_id: PlayerID,
        game: GameID,
        *,
        offset: int = Field(0, ge=0, le=200),
        limit: int = Field(20, ge=1, le=100),
        start: NotStrictTimestampMs | None = None,
        to: NotStrictTimestampMs | None = None,
    ) -> RawAPIPageResponse: ...

    @overload
    async def matches_stats(
        self: AsyncPlayers[Model],
        player_id: PlayerID,
        game: Literal[GameID.CS2],
        *,
        offset: int = Field(0, ge=0, le=200),
        limit: int = Field(20, ge=1, le=100),
        start: NotStrictTimestampMs | None = None,
        to: NotStrictTimestampMs | None = None,
    ) -> ItemPage[CS2MatchPlayerStats]: ...

    @overload
    async def matches_stats(
        self: AsyncPlayers[Model],
        player_id: PlayerID,
        game: GameID,
        *,
        offset: int = Field(0, ge=0, le=200),
        limit: int = Field(20, ge=1, le=100),
        start: NotStrictTimestampMs | None = None,
        to: NotStrictTimestampMs | None = None,
    ) -> ItemPage[AbstractMatchPlayerStats]: ...

    @validate_call
    async def matches_stats(
        self,
        player_id: PlayerIDValidated,
        game: GameID,
        *,
        offset: int = Field(0, ge=0, le=200),
        limit: int = Field(20, ge=1, le=100),
        start: NotStrictTimestampMs | None = None,
        to: NotStrictTimestampMs | None = None,
    ) -> (
        RawAPIPageResponse
        | ItemPage[CS2MatchPlayerStats]
        | ItemPage[AbstractMatchPlayerStats]
    ):
        return self._process_page(
            await self._client.get(
                self.__class__.PATH / str(player_id) / "games" / game / "stats",
                params=self.__class__._build_params(
                    offset=offset, limit=limit, start=start, to=to
                ),
                expect_page=True,
            ),
            game,
            self.__class__._matches_stats_validator_cfg,
        )

    @overload
    async def all_matches_stats(
        self: AsyncPlayers[Raw],
        player_id: PlayerID,
        game: GameID,
        max_items: MaxItemsType = pages(50),
    ) -> list[RawAPIItem]: ...

    @overload
    async def all_matches_stats(
        self: AsyncPlayers[Model],
        player_id: PlayerID,
        game: Literal[GameID.CS2],
        max_items: MaxItemsType = pages(50),
    ) -> ItemPage[CS2MatchPlayerStats]: ...

    @overload
    async def all_matches_stats(
        self: AsyncPlayers[Model],
        player_id: PlayerID,
        game: GameID,
        max_items: MaxItemsType = pages(50),
    ) -> ItemPage[AbstractMatchPlayerStats]: ...

    async def all_matches_stats(
        self,
        player_id: PlayerID,
        game: GameID,
        max_items: MaxItemsType = pages(50),
    ) -> (
        list[RawAPIItem]
        | ItemPage[CS2MatchPlayerStats]
        | ItemPage[AbstractMatchPlayerStats]
    ):
        return await AsyncPageIterator.gather_from_iterator(
            AsyncPageIterator.unix(
                self.matches_stats,
                player_id,
                game,
                cfg=self.__class__._matches_stats_timestamp_cfg,
                max_items=max_items,
            )
        )

    @overload
    async def history(
        self: AsyncPlayers[Raw],
        player_id: PlayerID,
        game: GameID,
        *,
        offset: int = Field(0, ge=0, le=1000),
        limit: int = Field(20, ge=1, le=100),
        start: NotStrictTimestampMs | None = None,
        to: NotStrictTimestampMs | None = None,
    ) -> RawAPIPageResponse: ...

    @overload
    async def history(
        self: AsyncPlayers[Model],
        player_id: PlayerID,
        game: GameID,
        *,
        offset: int = Field(0, ge=0, le=1000),
        limit: int = Field(20, ge=1, le=100),
        start: NotStrictTimestampMs | None = None,
        to: NotStrictTimestampMs | None = None,
    ) -> ItemPage[Match]: ...

    @validate_call
    async def history(
        self,
        player_id: PlayerIDValidated,
        game: GameID,
        *,
        offset: int = Field(0, ge=0, le=1000),
        limit: int = Field(20, ge=1, le=100),
        start: NotStrictTimestampMs | None = None,
        to: NotStrictTimestampMs | None = None,
    ) -> RawAPIPageResponse | ItemPage[Match]:
        return self._validate_response(
            await self._client.get(
                self.__class__.PATH / str(player_id) / "history",
                params=self.__class__._build_params(
                    game=game, offset=offset, limit=limit, start=start, to=to
                ),
                expect_page=True,
            ),
            ItemPage[Match],
        )

    @overload
    async def all_history(
        self: AsyncPlayers[Raw],
        player_id: PlayerID,
        game: GameID,
        max_items: MaxItemsType = pages(50),
    ) -> list[RawAPIItem]: ...

    @overload
    async def all_history(
        self: AsyncPlayers[Model],
        player_id: PlayerID,
        game: GameID,
        max_items: MaxItemsType = pages(50),
    ) -> ItemPage[Match]: ...

    async def all_history(
        self,
        player_id: PlayerID,
        game: GameID,
        max_items: MaxItemsType = pages(50),
    ) -> list[RawAPIItem] | ItemPage[Match]:
        return await AsyncPageIterator.gather_from_iterator(
            AsyncPageIterator.unix(
                self.history,
                player_id,
                game,
                cfg=self.__class__._history_timestamp_cfg,
                max_items=max_items,
            )
        )

    @overload
    async def hubs(
        self: AsyncPlayers[Raw],
        player_id: PlayerID,
        *,
        offset: int = Field(0, ge=0, le=1000),
        limit: int = Field(50, ge=1, le=50),
    ) -> RawAPIPageResponse: ...

    @overload
    async def hubs(
        self: AsyncPlayers[Model],
        player_id: PlayerID,
        *,
        offset: int = Field(0, ge=0, le=1000),
        limit: int = Field(50, ge=1, le=50),
    ) -> ItemPage[Hub]: ...

    @validate_call
    async def hubs(
        self,
        player_id: PlayerIDValidated,
        *,
        offset: int = Field(0, ge=0, le=1000),
        limit: int = Field(50, ge=1, le=50),
    ) -> RawAPIPageResponse | ItemPage[Hub]:
        return self._validate_response(
            await self._client.get(
                self.__class__.PATH / str(player_id) / "hubs",
                params=self.__class__._build_params(offset=offset, limit=limit),
                expect_page=True,
            ),
            ItemPage[Hub],
        )

    @overload
    async def all_hubs(
        self: AsyncPlayers[Raw],
        player_id: PlayerID,
        max_items: MaxItemsType = MaxItems.SAFE,
    ) -> list[RawAPIItem]: ...

    @overload
    async def all_hubs(
        self: AsyncPlayers[Model],
        player_id: PlayerID,
        max_items: MaxItemsType = MaxItems.SAFE,
    ) -> ItemPage[Hub]: ...

    async def all_hubs(
        self, player_id: PlayerID, max_items: MaxItemsType = MaxItems.SAFE
    ) -> list[RawAPIItem] | ItemPage[Hub]:
        iterator = AsyncPageIterator(self.hubs, player_id, max_items=max_items)
        return await iterator.collect()

    @overload
    async def stats(
        self: AsyncPlayers[Raw], player_id: PlayerID, game: GameID
    ) -> RawAPIItem: ...

    @overload
    async def stats(  # type: ignore[overload-overlap]
        self: AsyncPlayers[Model], player_id: PlayerID, game: AnyCSID
    ) -> CSPlayerStats: ...

    @overload
    async def stats(
        self: AsyncPlayers[Model], player_id: PlayerID, game: GameID
    ) -> FallbackPlayerStats: ...

    @validate_call
    async def stats(
        self, player_id: PlayerIDValidated, game: GameID
    ) -> RawAPIItem | AnyPlayerStats:
        return self._process_item(
            await self._client.get(
                self.__class__.PATH / str(player_id) / "stats" / game,
                expect_item=True,
            ),
            game,
            self.__class__._stats_validator_cfg,
        )

    @overload
    async def teams(
        self: AsyncPlayers[Raw],
        player_id: PlayerID,
        *,
        offset: int = Field(0, ge=0),
        limit: int = Field(20, ge=1, le=100),
    ) -> RawAPIPageResponse: ...

    @overload
    async def teams(
        self: AsyncPlayers[Model],
        player_id: PlayerID,
        *,
        offset: int = Field(0, ge=0),
        limit: int = Field(20, ge=1, le=100),
    ) -> ItemPage[GeneralTeam]: ...

    @validate_call
    async def teams(
        self,
        player_id: PlayerIDValidated,
        *,
        offset: int = Field(0, ge=0),
        limit: int = Field(20, ge=1, le=100),
    ) -> RawAPIPageResponse | ItemPage[GeneralTeam]:
        return self._validate_response(
            await self._client.get(
                self.__class__.PATH / str(player_id) / "teams",
                params=self.__class__._build_params(offset=offset, limit=limit),
                expect_page=True,
            ),
            ItemPage[GeneralTeam],
        )

    @overload
    async def all_teams(
        self: AsyncPlayers[Raw],
        player_id: PlayerID,
        max_items: MaxItemsType = MaxItems.SAFE,
    ) -> list[RawAPIItem]: ...

    @overload
    async def all_teams(
        self: AsyncPlayers[Model],
        player_id: PlayerID,
        max_items: MaxItemsType = MaxItems.SAFE,
    ) -> ItemPage[GeneralTeam]: ...

    async def all_teams(
        self, player_id: PlayerID, max_items: MaxItemsType = MaxItems.SAFE
    ) -> list[RawAPIItem] | ItemPage[GeneralTeam]:
        iterator = AsyncPageIterator(self.teams, player_id, max_items=max_items)
        return await iterator.collect()

    @overload
    async def tournaments(
        self: AsyncPlayers[Raw],
        player_id: PlayerID,
        *,
        offset: int = Field(0, ge=0),
        limit: int = Field(20, ge=1, le=100),
    ) -> RawAPIPageResponse: ...

    @overload
    async def tournaments(
        self: AsyncPlayers[Model],
        player_id: PlayerID,
        *,
        offset: int = Field(0, ge=0),
        limit: int = Field(20, ge=1, le=100),
    ) -> ItemPage[Tournament]: ...

    @validate_call
    async def tournaments(
        self,
        player_id: PlayerIDValidated,
        *,
        offset: int = Field(0, ge=0),
        limit: int = Field(20, ge=1, le=100),
    ) -> RawAPIPageResponse | ItemPage[Tournament]:
        return self._validate_response(
            await self._client.get(
                self.__class__.PATH / str(player_id) / "tournaments",
                params=self.__class__._build_params(offset=offset, limit=limit),
                expect_page=True,
            ),
            ItemPage[Tournament],
        )

    @overload
    async def all_tournaments(
        self: AsyncPlayers[Raw],
        player_id: PlayerID,
        max_items: MaxItemsType = MaxItems.SAFE,
    ) -> list[RawAPIItem]: ...

    @overload
    async def all_tournaments(
        self: AsyncPlayers[Model],
        player_id: PlayerID,
        max_items: MaxItemsType = MaxItems.SAFE,
    ) -> ItemPage[Tournament]: ...

    async def all_tournaments(
        self, player_id: PlayerID, max_items: MaxItemsType = MaxItems.SAFE
    ) -> list[RawAPIItem] | ItemPage[Tournament]:
        iterator = AsyncPageIterator(self.tournaments, player_id, max_items=max_items)
        return await iterator.collect()
