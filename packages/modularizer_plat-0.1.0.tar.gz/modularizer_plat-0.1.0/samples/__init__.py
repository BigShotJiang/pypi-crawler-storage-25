"""Python samples for plat."""
