import numpy as np
import scipy.stats as stats
from typing import Tuple, Any
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import cross_val_score, KFold
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, ConstantKernel as C
from scipy.optimize import minimize_scalar

#### Mean Model - Robust Regression (Polynomial + Kriging) ####

def fit_robust_mean_model(
    X: np.ndarray,
    y: np.ndarray,
    max_degree: int = 10,
    n_folds: int = 10,
    model_override: str = "auto",
    force_degree: int | None = None
) -> Any:
    """
    Fits regression models (Polynomials and Kriging) and selects the optimal one.

    This function performs k-fold Cross Validation (CV) to find the model type
    (Polynomial or Kriging) and parameters (e.g., degree) that minimize the
    Mean Squared Error (MSE), balancing bias and variance.

    When ``model_override`` is set to ``"polynomial"`` or ``"kriging"``, CV
    selection is skipped and the requested model type is fitted directly.

    Args:
        X (np.ndarray): 1D array of input variable values (e.g., flaw size).
        y (np.ndarray): 1D array of outcome values (e.g., signal response).
        max_degree (int, optional): The maximum polynomial degree to test. Defaults to 10.
        n_folds (int, optional): Number of folds for Cross Validation. Defaults to 10.
        model_override (str, optional): Force a model type. One of ``"auto"``,
            ``"polynomial"``, or ``"kriging"``. Defaults to ``"auto"``.
        force_degree (int | None, optional): When ``model_override="polynomial"``,
            use this degree instead of CV selection. Defaults to None (CV selects).

    Returns:
        Any: A fitted scikit-learn model with the following added attributes:
        - `model_type_` (str): Either 'Polynomial' or 'Kriging'.
        - `model_params_` (Any): The selected integer degree or the fitted kernel.
        - `cv_scores_` (dict): The cross-validation MSE scores for all tested models.

    Examples:
        ```python
        import numpy as np
        X = np.linspace(0, 10, 50)
        y = 3 * X + np.random.normal(0, 1, 50)
        model = fit_robust_mean_model(X, y)
        print(model.model_type_)

        # Force a cubic polynomial
        model = fit_robust_mean_model(X, y, model_override="polynomial", force_degree=3)
        ```
    """
    X_2d = np.atleast_2d(X).T if np.asarray(X).ndim == 1 else np.asarray(X)
    cv_scores = {}
    override = model_override.lower()

    # -----------------------------------------------------------------------
    # Step 1: Always run full CV across all polynomials AND Kriging.
    # This ensures cv_scores_ is always fully populated for the plot,
    # regardless of whether the user has forced a model override.
    # -----------------------------------------------------------------------
    cv = KFold(n_splits=n_folds, shuffle=True, random_state=42)

    for d in range(1, max_degree + 1):
        model = make_pipeline(PolynomialFeatures(degree=d), LinearRegression())
        scores = cross_val_score(model, X_2d, y, cv=cv, scoring='neg_mean_squared_error')
        cv_scores[('Polynomial', d)] = -np.mean(scores)

    kernel = C(1.0, (1e-5, 1e6)) * RBF(1.0, (1e-3, 1e5))
    gpr = GaussianProcessRegressor(
        kernel=kernel,
        n_restarts_optimizer=10,
        alpha=np.var(y) * 0.01,
        random_state=42
    )
    gpr_scores = cross_val_score(gpr, X_2d, y, cv=cv, scoring='neg_mean_squared_error')
    cv_scores[('Kriging', None)] = -np.mean(gpr_scores)

    # Record the CV winner before applying any override
    cv_winner = min(cv_scores, key=cv_scores.get)

    # -----------------------------------------------------------------------
    # Step 2: Determine which model to actually use.
    # -----------------------------------------------------------------------
    forced = False

    if override == "polynomial" and force_degree is not None:
        # User forced a specific degree
        best_type, best_params = 'Polynomial', force_degree
        forced = True
    elif override == "kriging":
        # User forced Kriging
        best_type, best_params = 'Kriging', None
        forced = True
    elif override == "polynomial":
        # User wants polynomial but left degree to CV — pick best poly
        poly_scores = {k: v for k, v in cv_scores.items() if k[0] == 'Polynomial'}
        best_type, best_params = min(poly_scores, key=poly_scores.get)
    else:
        # Auto: use overall CV winner
        best_type, best_params = cv_winner

    # -----------------------------------------------------------------------
    # Step 3: Fit the final model using the selected type and parameters.
    # -----------------------------------------------------------------------
    if best_type == 'Polynomial':
        final_model = make_pipeline(PolynomialFeatures(degree=best_params), LinearRegression())
        final_model.fit(X_2d, y)
        final_model.model_params_ = best_params
    else:
        # Use more restarts for the final fit than during CV
        final_model = GaussianProcessRegressor(
            kernel=kernel,
            n_restarts_optimizer=15,
            alpha=np.var(y) * 0.01,
            random_state=42
        )
        final_model.fit(X_2d, y)
        final_model.model_params_ = final_model.kernel_

    final_model.model_type_ = best_type
    final_model.cv_scores_ = cv_scores
    final_model.cv_winner_ = cv_winner
    final_model.forced_model_ = forced

    return final_model

def plot_model_selection(
    cv_scores: dict,
    used_key: tuple | None = None,
    cv_winner_key: tuple | None = None
) -> Any:
    """
    Generates a normalized bar chart of the Bias-Variance Tradeoff from CV scores,
    alongside a sorted table of the exact MSE values in best-fit order.

    Bars are colour-coded to distinguish the CV winner, the user-forced model
    (when different from the CV winner), and all other candidates.

    Args:
        cv_scores (dict): Dictionary mapping ``(model_type, params)`` tuples to
            their Cross-Validation MSE scores.
        used_key (tuple | None): The ``(type, params)`` key of the model that was
            actually used for the PoD calculation. If ``None``, the bar with the
            lowest MSE is treated as the used model.
        cv_winner_key (tuple | None): The ``(type, params)`` key of the CV winner.
            If ``None``, falls back to the bar with the lowest MSE.

    Examples:
        ```python
        fig = plot_model_selection(
            model.cv_scores_,
            used_key=('Polynomial', 5),
            cv_winner_key=model.cv_winner_
        )
        ```
    """
    import matplotlib.pyplot as plt
    import matplotlib.patches as mpatches
    import numpy as np

    # --- 1. Build ordered labels and MSE values ---
    poly_keys = [k for k in cv_scores.keys() if k[0] == 'Polynomial']
    poly_degrees = sorted([k[1] for k in poly_keys])

    labels = []
    mses = []
    keys = []

    for d in poly_degrees:
        labels.append(f"Poly {d}")
        mses.append(cv_scores[('Polynomial', d)])
        keys.append(('Polynomial', d))

    if ('Kriging', None) in cv_scores:
        labels.append("Kriging")
        mses.append(cv_scores[('Kriging', None)])
        keys.append(('Kriging', None))

    # Normalise by minimum error
    min_mse = min(mses)
    normalized_mses = [m / min_mse for m in mses]

    # Resolve which bar is the CV winner and which is the used model
    if cv_winner_key is None:
        cv_winner_key = keys[int(np.argmin(mses))]
    if used_key is None:
        used_key = cv_winner_key

    forced = (used_key != cv_winner_key)

    # --- 2. Assign bar colours ---
    # crimson  = CV winner
    # #1f77b4  = standard blue (other candidates)
    # #ff7f0e  = orange (user-forced model, when different from CV winner)
    colours = []
    for k in keys:
        if k == cv_winner_key:
            colours.append('crimson')
        elif k == used_key:
            colours.append('#ff7f0e')
        else:
            colours.append('#1f77b4')

    # --- 3. Build the sorted MSE table ---
    sorted_scores = sorted(cv_scores.items(), key=lambda item: item[1])
    table_data = []
    for (m_type, m_param), score in sorted_scores:
        name = f"Poly {m_param}" if m_type == 'Polynomial' else "Kriging"
        table_data.append([name, f"{score:.1e}"])

    # --- 4. Create figure ---
    fig, (ax_plot, ax_table) = plt.subplots(
        1, 2, figsize=(9, 5), gridspec_kw={'width_ratios': [2.2, 1]}
    )

    # --- Bar Chart ---
    ax_plot.bar(labels, normalized_mses, color=colours, edgecolor='black', alpha=0.85)

    ax_plot.axhline(1.0, color='red', linestyle='-.', linewidth=1.5, label='Min Error (CV)')
    ax_plot.set_title('Model Selection: Bias-Variance Tradeoff', fontweight='bold')
    ax_plot.set_ylabel('Error / Min Error [-]')
    ax_plot.grid(True, axis='y', linestyle=':', alpha=0.7)
    ax_plot.tick_params(axis='x', rotation=45)

    # Build a legend that only shows relevant entries
    legend_handles = [
        mpatches.Patch(color='crimson', label='CV Winner'),
    ]
    if forced:
        legend_handles.append(
            mpatches.Patch(color='#ff7f0e', label='Used (User Override)')
        )
    legend_handles.append(
        mpatches.Patch(color='#1f77b4', label='Other Candidates')
    )
    ax_plot.legend(handles=legend_handles, fontsize=8)

    # --- Table ---
    ax_table.axis('off')
    ax_table.set_title('MSE Values\n(Best Fit Order)', fontweight='bold', pad=10)

    table = ax_table.table(
        cellText=table_data,
        colLabels=["Model", "MSE"],
        loc='center',
        cellLoc='center'
    )
    table.auto_set_font_size(False)
    table.set_fontsize(10)
    table.scale(1, 1.8)

    # Style table rows: bold headers, highlight CV winner and used model
    cv_winner_name = f"Poly {cv_winner_key[1]}" if cv_winner_key[0] == 'Polynomial' else "Kriging"
    used_name = f"Poly {used_key[1]}" if used_key[0] == 'Polynomial' else "Kriging"

    for (row, col), cell in table.get_celld().items():
        if row == 0:
            cell.set_text_props(weight='bold')
            continue
        cell_label = table_data[row - 1][0]  # row 1 = table_data[0]
        if cell_label == cv_winner_name:
            cell.set_facecolor('#ffcccc')  # light red for CV winner
        if forced and cell_label == used_name:
            cell.set_facecolor('#ffe0b2')  # light orange for forced model

    fig.tight_layout()
    return fig


#### Variance Model - Kernel Smoothing ####

def optimise_bandwidth(
    X: np.ndarray,
    residuals: np.ndarray,
    min_ratio: float = 0.01,
    max_ratio: float = 0.5
) -> float:
    """
    Finds the optimal kernel smoothing bandwidth using Leave-One-Out Cross-Validation (LOO-CV).

    This function automatically determines the best smoothing window (sigma) for the
    variance model. It evaluates different bandwidths by predicting the squared residual
    of each point using a Gaussian weighted average of all *other* points, selecting
    the bandwidth that minimizes the Mean Squared Error (MSE) of these predictions.

    Args:
        X (np.ndarray): A 1D array of the original input locations (e.g., flaw sizes).
        residuals (np.ndarray): The raw residuals calculated from the mean model
            (differences between observed y and predicted mean y).
        min_ratio (float, optional): The lower bound for the optimizer's search space,
            defined as a fraction of the total range of X (X.max() - X.min()). Defaults to 0.01.
        max_ratio (float, optional): The upper bound for the optimizer's search space,
            defined as a fraction of the total range of X. Defaults to 0.5.

    Returns:
        float: The optimal smoothing bandwidth in the absolute units of X.

    Examples:
        ```python
        import numpy as np

        # 1. Generate dummy input data and simulated residuals
        X = np.linspace(0, 10, 50)
        # Simulate heteroscedastic noise (variance increases with X)
        residuals = np.random.normal(0, X * 0.5, size=50)

        # 2. Find the optimal bandwidth
        optimal_bw = optimize_bandwidth(X, residuals)
        print(f"Optimal Bandwidth: {optimal_bw:.4f}")
        ```
    """
    from scipy.spatial.distance import cdist
    X_2d = np.atleast_2d(X).T if np.asarray(X).ndim == 1 else np.asarray(X)
    sq_residuals = residuals.flatten() ** 2
    data_range = np.max(X_2d.max(axis=0) - X_2d.min(axis=0))

    def loo_cv_objective(bw: float) -> float:
        # Calculate euclidean distance matrix
        dists = cdist(X_2d, X_2d, metric='euclidean')

        # Calculate Gaussian weights
        weights = stats.norm.pdf(dists, loc=0, scale=bw)

        # Leave-One-Out: Set diagonal to zero so a point doesn't predict itself
        np.fill_diagonal(weights, 0)

        # Normalize weights so each row sums to 1
        row_sums = weights.sum(axis=1)
        row_sums[row_sums == 0] = 1e-10  # Prevent division by zero
        weights = weights / row_sums.reshape(-1, 1)

        # Predict the squared residuals
        preds = weights @ sq_residuals

        # Return the Mean Squared Error of the variance prediction
        return float(np.mean((sq_residuals - preds) ** 2))

    # Define the search bounds for the optimizer
    bounds = (data_range * min_ratio, data_range * max_ratio)

    # Run a bounded scalar optimization to find the minimum LOO-CV error
    res = minimize_scalar(loo_cv_objective, bounds=bounds, method='bounded')

    return float(res.x)


def fit_variance_model(
    X: np.ndarray,
    y: np.ndarray,
    mean_model: Any,
    auto_bandwidth: bool = True,
    bandwidth_ratio: float = 0.1
) -> Tuple[np.ndarray, float]:
    """
    Calculates residuals and defines the smoothing bandwidth for variance estimation.

    This function acts as the setup phase for modeling heteroscedasticity. It computes
    the raw residuals from the provided mean model and establishes the smoothing
    bandwidth either via automated Cross-Validation or a fixed user-defined ratio.
    It also generates a linearly spaced evaluation grid over the X domain.

    Args:
        X (np.ndarray): The 1D array of original input data (e.g., parameter of interest).
        y (np.ndarray): The 1D array of original outcome data (e.g., signal response).
        mean_model (Any): A fitted scikit-learn estimator (e.g., Pipeline or
            GaussianProcessRegressor) that implements a `.predict()` method.
        auto_bandwidth (bool, optional): If True, dynamically calculates the optimal
            bandwidth using Leave-One-Out Cross-Validation. If False, falls back to
            the fixed `bandwidth_ratio`. Defaults to True.
        bandwidth_ratio (float, optional): The kernel smoothing window size as a
            fraction of the data range (X.max() - X.min()). Only used if
            `auto_bandwidth` is False. Defaults to 0.1.
        n_eval_points (int, optional): The number of points to generate for the
            evaluation grid (`X_eval`). Defaults to 100.

    Returns:
        Tuple[np.ndarray, float]:
            - residuals: Raw differences between `y` and the mean model predictions.
            - bandwidth: The selected smoothing window size (in absolute units of X).

    Examples:
        ```python
        import numpy as np
        from sklearn.linear_model import LinearRegression

        # 1. Setup dummy data and a basic mean model
        X = np.linspace(0, 10, 50)
        y = 2.5 * X + np.random.normal(0, 1, 50)

        model = LinearRegression()
        model.fit(X.reshape(-1, 1), y)

        # 2. Extract residuals and optimized bandwidth
        residuals, bandwidth = fit_variance_model(
            X, y,
            mean_model=model,
            auto_bandwidth=True
        )

        print(f"Calculated Bandwidth: {bandwidth:.4f}")
        print(f"Evaluation Grid Size: {len(X_eval)}")
        ```
    """
    X_2d = np.atleast_2d(X).T if np.asarray(X).ndim == 1 else np.asarray(X)
    y_pred = mean_model.predict(X_2d)
    residuals = y - y_pred

    if auto_bandwidth:
        print("   -> Optimizing bandwidth via LOO-CV...")
        bandwidth = optimise_bandwidth(X_2d, residuals)
    else:
        data_range = np.max(X_2d.max(axis=0) - X_2d.min(axis=0))
        bandwidth = data_range * bandwidth_ratio

    return residuals, bandwidth


def predict_local_std(
    X: np.ndarray,
    residuals: np.ndarray,
    X_eval: np.ndarray,
    bandwidth: float
) -> np.ndarray:
    """
    Estimates the local standard deviation using Gaussian Kernel Smoothing.

    This implements a Nadaraya-Watson estimator specifically for the squared
    residuals to model how noise varies across the input domain (heteroscedasticity).

    Args:
        X (np.ndarray): The source locations (original data inputs).
        residuals (np.ndarray): The residuals observed at `X`.
        X_eval (np.ndarray): The target locations to estimate variance at.
        bandwidth (float): The width of the Gaussian kernel (sigma).

    Returns:
        np.ndarray: An array of standard deviation estimates corresponding to `X_eval`.

    Examples:
        ```python
        local_std = predict_local_std(X, residuals, X_eval, bandwidth)
        ```
    """
    from scipy.spatial.distance import cdist
    X_source = np.atleast_2d(X).T if np.asarray(X).ndim == 1 else np.asarray(X)
    X_target = np.atleast_2d(X_eval).T if np.asarray(X_eval).ndim == 1 else np.asarray(X_eval)

    sq_residuals = residuals.flatten() ** 2

    dists = cdist(X_target, X_source, metric='euclidean')
    weights = stats.norm.pdf(dists, loc=0, scale=bandwidth)

    row_sums = weights.sum(axis=1, keepdims=True)
    row_sums[row_sums == 0] = 1e-10
    weights = weights / row_sums

    return np.sqrt(weights @ sq_residuals)


#### Residual Distribution Fitting ####

def infer_best_distribution(
    residuals: np.ndarray,
    X: np.ndarray,
    bandwidth: float
) -> Tuple[str, Tuple]:
    """
    Selects the best statistical distribution for the standardized residuals using AIC.

    This function normalizes residuals by their local standard deviation (Z-scores)
    and tests them against a suite of candidate distributions (Normal, Gumbel,
    Logistic, Laplace, t-Student).

    Args:
        residuals (np.ndarray): Raw residuals from the mean model.
        X (np.ndarray): Input locations for the residuals.
        bandwidth (float): Bandwidth used for local standardization.

    Returns:
        Tuple[str, Tuple]:
            - best_name: The SciPy name of the best-fitting distribution (e.g., 'norm').
            - best_params: The fitted parameters for that distribution (e.g., loc, scale).

    Examples:
        ```python
        dist_name, dist_params = infer_best_distribution(residuals, X, bandwidth)
        print(f"Best distribution: {dist_name}")
        ```
    """
    #
    local_std = predict_local_std(X, residuals, X, bandwidth)
    z_scores = residuals.flatten() / local_std.flatten()

    candidates = [
        "norm",         # Gaussian (The Standard)
        "gumbel_r",     # Right-skewed Extreme Value
        "gumbel_l",     # Left-skewed Extreme Value (Common for cracks)
        "logistic",     # Heavier tails than Normal
        "laplace",      # Sharper peak, heavy tails
        "t",            # Student's t (Very robust to outliers)
    ]

    best_aic = np.inf
    best_result = ("norm", (0, 1))

    for dist_name in candidates:
        try:
            dist_obj = getattr(stats, dist_name)
            params = dist_obj.fit(z_scores)
            log_likelihood = np.sum(np.log(dist_obj.pdf(z_scores, *params)))

            k = len(params)
            aic = 2*k - 2*log_likelihood

            if aic < best_aic:
                best_aic = aic
                best_result = (dist_name, params)
        except Exception:
            continue

    return best_result


#### PoD Generation and Bootstrap Intervals ####

def compute_pod_curve(
    X_eval: np.ndarray,
    mean_model: Any,
    X: np.ndarray,
    residuals: np.ndarray,
    bandwidth: float,
    dist_info: Tuple[str, Tuple],
    threshold: float
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Calculates the Probability of Detection (PoD) curve.

    Combines the Mean Model, Variance Model, and Error Distribution to compute
    the probability that the signal exceeds the threshold at every point in `X_eval`.

    Args:
        X_eval (np.ndarray): The grid points to calculate PoD for.
        mean_model (Any): The fitted sklearn mean response model.
        X (np.ndarray): Original input data (needed for variance prediction).
        residuals (np.ndarray): Original residuals (needed for variance prediction).
        bandwidth (float): Smoothing bandwidth.
        dist_info (Tuple[str, Tuple]): The (name, params) of the error distribution.
        threshold (float): The detection threshold value.

    Returns:
        Tuple[np.ndarray, np.ndarray]:
            - pod_curve: Array of probabilities [0, 1] for each point in X_eval.
            - mean_curve: Array of mean signal response values for X_eval.

    Examples:
        ```python
        # Assuming we have fitted models (mean_model) and data (X, residuals)
        # Calculate the PoD curve for a threshold of 0.5
        pod, mean_resp = compute_pod_curve(
            X_eval=np.linspace(0, 10, 100),
            mean_model=mean_model,
            X=X,
            residuals=residuals,
            bandwidth=1.5,
            dist_info=('norm', (0, 1)),
            threshold=0.5
        )
        ```
    """
    #
    dist_name, dist_params = dist_info

    X_eval_2d = np.atleast_2d(X_eval).T if np.asarray(X_eval).ndim == 1 else np.asarray(X_eval)
    mean_curve = mean_model.predict(X_eval_2d)
    sigma_curve = predict_local_std(X, residuals, X_eval_2d, bandwidth)

    z_threshold = (threshold - mean_curve) / sigma_curve

    dist_obj = getattr(stats, dist_name)
    pod_curve = 1 - dist_obj.cdf(z_threshold, *dist_params)

    return pod_curve, mean_curve


def bootstrap_pod_ci(
    X: np.ndarray,
    y: np.ndarray,
    X_eval: np.ndarray,
    threshold: float,
    model_type: str,
    model_params: Any,
    bandwidth: float,
    dist_info: Tuple[str, Tuple],
    n_boot: int = 1000,
    nuisance_ranges: dict = None
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Estimates 95% Confidence Bounds for the PoD curve via Bootstrapping.

    This function resamples the original data with replacement `n_boot` times.
    For each resample, it refits the Mean Model (dynamically rebuilding either
    a Polynomial or Kriging model), recalculates residuals, and generates a new PoD curve.
    If Kriging is selected, the optimizer is disabled during bootstrapping to remain
    computationally tractable.

    Args:
        X (np.ndarray): Original input data.
        y (np.ndarray): Original outcome data.
        X_eval (np.ndarray): Grid points for evaluation.
        threshold (float): Detection threshold.
        model_type (str): The type of mean model ('Polynomial' or 'Kriging').
        model_params (Any): Model parameters (integer degree for Poly, kernel for Kriging).
        bandwidth (float): Smoothing bandwidth (fixed from original fit).
        dist_info (Tuple[str, Tuple]): Error distribution (fixed from original fit).
        n_boot (int, optional): Number of bootstrap iterations. Defaults to 1000.

    Returns:
        Tuple[np.ndarray, np.ndarray]:
            - lower_ci: The 2.5th percentile PoD curve (Lower 95% Bound).
            - upper_ci: The 97.5th percentile PoD curve (Upper 95% Bound).

    Examples:
        ```python
        # Generate 95% confidence bounds
        lower, upper = bootstrap_pod_ci(
            X, y, X_eval, threshold=0.5,
            model_type='Polynomial', model_params=3,
            bandwidth=1.5, dist_info=('norm', (0, 1)), n_boot=100
        )
        ```
    """
    n_samples = len(y)
    pod_matrix = np.zeros((n_boot, len(X_eval)))
    
    X_2d = np.atleast_2d(X).T if np.asarray(X).ndim == 1 else np.asarray(X)

    for i in range(n_boot):
        if (i + 1) % max(1, n_boot // 10) == 0:
            print(f"      -> [{int((i + 1) / n_boot * 100):3d}%] Completed {i + 1} iterations")

        # Resample indices
        idx = np.random.choice(n_samples, n_samples, replace=True)
        X_res_2d = X_2d[idx]
        y_res = y[idx]

        # Conditionally Fit Mean Model based on winning type
        if model_type == 'Polynomial':
            mean_model = make_pipeline(PolynomialFeatures(model_params), LinearRegression())
        elif model_type == 'Kriging':
            # Use the already optimized kernel (model_params) and turn off optimizer
            mean_model = GaussianProcessRegressor(
                kernel=model_params, alpha=np.var(y_res)*0.01, optimizer=None
            )

        mean_model.fit(X_res_2d, y_res)

        # Residuals
        y_pred = mean_model.predict(X_res_2d)
        res_res = y_res - y_pred

        # Predict
        from digiqual.integration import compute_multi_dim_pod
        pod_curve, _ = compute_multi_dim_pod(
            X_eval, nuisance_ranges or {}, mean_model, X_res_2d, res_res, bandwidth, dist_info, threshold, n_mc_samples=1000
        )
        pod_matrix[i, :] = pod_curve

    return np.percentile(pod_matrix, 2.5, axis=0), np.percentile(pod_matrix, 97.5, axis=0)


def calculate_reliability_point(
    X_eval: np.ndarray,
    ci_lower: np.ndarray,
    target_pod: float = 0.90
) -> float:
    """
    Calculates the defect size (a90/95) where the Lower Confidence Bound
    crosses the target reliability threshold (usually 0.90).

    Args:
        X_eval (np.ndarray): The evaluation grid points.
        ci_lower (np.ndarray): The lower confidence bound curve (y values).
        target_pod (float, optional): Target reliability level. Defaults to 0.90.

    Returns:
        float: The interpolated x-value, or np.nan if not reached.

    Examples:
        ```python
        a90_95 = calculate_reliability_point(X_eval, lower_ci, target_pod=0.90)
        print(f"a90/95 point: {a90_95:.2f}")
        ```
    """
    # Check if the curve actually reaches the target
    if np.max(ci_lower) < target_pod:
        return np.nan

    # Interpolate to find exact crossing point
    # We swap args because we are solving for X given Y=0.90
    monotonic_ci = np.maximum.accumulate(ci_lower)
    return float(np.interp(target_pod, monotonic_ci, X_eval))
