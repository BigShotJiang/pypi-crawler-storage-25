"""Tests for Security Utilities."""

from framework_m_core.security import hash_password, verify_password


def test_hash_password() -> None:
    """hash_password should return a valid argon2 hash."""
    password = "super-secret-password"
    hashed = hash_password(password)

    assert hashed is not None
    assert hashed != password
    assert hashed.startswith("$argon2")


def test_verify_password_success() -> None:
    """verify_password should return True for matching password."""
    password = "super-secret-password"
    hashed = hash_password(password)

    assert verify_password(password, hashed) is True


def test_verify_password_failure() -> None:
    """verify_password should return False for non-matching password."""
    password = "super-secret-password"
    hashed = hash_password(password)

    assert verify_password("wrong-password", hashed) is False
