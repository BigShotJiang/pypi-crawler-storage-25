"""Tests for MetaRegistry model baking integration."""

import pytest
from framework_m_core.domain.base_doctype import BaseDocType
from framework_m_core.metadata_decorator import MetadataDecoratorRegistry
from framework_m_core.registry import MetaRegistry


class BakingTestDoc(BaseDocType):
    """DocType for testing the baking process."""

    title: str


class BakingTestOverride(BakingTestDoc):
    """Override DocType for testing the baking process."""

    subtitle: str


class TestMetaRegistryBaking:
    """Tests for MetaRegistry.bake_augmented_models()."""

    @pytest.fixture(autouse=True)
    def setup_registries(self) -> None:
        """Clear registries before and after each test."""
        MetaRegistry.get_instance().clear()
        MetadataDecoratorRegistry.get_instance().clear()
        yield
        MetaRegistry.get_instance().clear()
        MetadataDecoratorRegistry.get_instance().clear()

    def test_bake_augmented_models_replaces_registry_classes(self) -> None:
        """Should replace original models in registry with baked models."""
        meta_reg = MetaRegistry.get_instance()
        dec_reg = MetadataDecoratorRegistry.get_instance()

        # 1. Register base doc and an override
        meta_reg.register_doctype(BakingTestDoc)
        meta_reg.register_override("BakingTestDoc", BakingTestOverride)

        # 2. Register augmented properties
        dec_reg.register_property("BakingTestDoc", "regional_tax_id", str)
        dec_reg.register_property("BakingTestOverride", "extra_field", int)

        # 3. Bake!
        meta_reg.bake_augmented_models()

        # 4. Assertions on Base
        BakedBase = meta_reg._doctypes["BakingTestDoc"]
        assert "regional_tax_id" in BakedBase.model_fields

        # 5. Assertions on Override (retrieved via standard get_doctype)
        BakedOverride = meta_reg.get_doctype("BakingTestDoc")
        assert "extra_field" in BakedOverride.model_fields
