"""Tests for the Metadata Decorator Toolkit.

TDD tests for multi-app coexistence and metadata decoration.
Tests written FIRST per CONTRIBUTING.md guidelines.
"""

import logging
from typing import Any

import pytest

# This import will initially fail (TDD requirement!)
from framework_m_core.metadata_decorator import MetadataDecoratorRegistry


@pytest.fixture
def registry() -> MetadataDecoratorRegistry:
    """Provide a fresh registry for each test."""
    reg = MetadataDecoratorRegistry()
    reg.clear()
    return reg


def test_decorator_sequence(registry: MetadataDecoratorRegistry) -> None:
    """Verify decorators run in order of registration as a pipeline."""

    def decorator1(schema: dict[str, Any]) -> dict[str, Any]:
        schema["sequence"].append(1)
        return schema

    def decorator2(schema: dict[str, Any]) -> dict[str, Any]:
        schema["sequence"].append(2)
        return schema

    registry.register("TestDoc", decorator1)
    registry.register("TestDoc", decorator2)

    schema = {"sequence": []}
    result = registry.apply("TestDoc", schema)

    assert result["sequence"] == [1, 2]


def test_decorator_merge_append(registry: MetadataDecoratorRegistry) -> None:
    """Verify decorators can append to lists (like enum or fields)."""

    def add_status(schema: dict[str, Any]) -> dict[str, Any]:
        # Mocking JSON schema structure for a status field
        schema["properties"]["status"]["enum"].append("Archived")
        return schema

    registry.register("Invoice", add_status)

    schema = {"properties": {"status": {"enum": ["Draft", "Submitted"]}}}
    result = registry.apply("Invoice", schema)

    assert result["properties"]["status"]["enum"] == ["Draft", "Submitted", "Archived"]


def test_decorator_conflict_resolution(
    registry: MetadataDecoratorRegistry, caplog: pytest.LogCaptureFixture
) -> None:
    """Verify replacing a scalar value logs a warning and uses Last-In-Wins."""

    def override_label(schema: dict[str, Any]) -> dict[str, Any]:
        schema["title"] = "Overridden Title"
        return schema

    registry.register("TestDoc", override_label)
    schema = {"title": "Original Title"}

    with caplog.at_level(logging.WARNING):
        result = registry.apply("TestDoc", schema)

    assert result["title"] == "Overridden Title"
    assert "conflict" in caplog.text.lower() or "overwriting" in caplog.text.lower()


def test_register_property_and_bake(registry: MetadataDecoratorRegistry) -> None:
    """Verify dynamic properties can be registered and baked into a new model."""
    from framework_m_core.domain.base_doctype import BaseDocType

    class BakeTestDoc(BaseDocType):
        title: str

    # Register new fields with specific persistence targets
    registry.register_property(
        "BakeTestDoc", "regional_tax_id", str, persistence="json"
    )
    registry.register_property(
        "BakeTestDoc", "priority_score", int, persistence="column"
    )

    # Bake the model using pydantic.create_model
    BakedModel = registry.bake(BakeTestDoc)

    # Verify the new model has the augmented fields
    assert "regional_tax_id" in BakedModel.model_fields
    assert "priority_score" in BakedModel.model_fields

    # Verify instances can be created with the new fields
    instance = BakedModel(title="Test", regional_tax_id="GST123", priority_score=5)
    assert instance.regional_tax_id == "GST123"


def test_baking_lock_prevents_divergence(registry: MetadataDecoratorRegistry) -> None:
    """Verify the registry locks after baking to prevent app divergence."""
    from framework_m_core.domain.base_doctype import BaseDocType

    class LockTestDoc(BaseDocType):
        title: str

    registry.bake(LockTestDoc)

    with pytest.raises(RuntimeError, match="locked|after baking"):
        registry.register_property("LockTestDoc", "late_field", str)


def test_register_property_link(registry: MetadataDecoratorRegistry) -> None:
    """Verify link adds 'link' metadata for foreign keys."""
    from framework_m_core.domain.base_doctype import BaseDocType

    class LinkTestDoc(BaseDocType):
        title: str

    registry.register_property("LinkTestDoc", "supplier_id", str, link="Supplier")

    BakedModel = registry.bake(LinkTestDoc)

    assert "supplier_id" in BakedModel.model_fields
    extra = BakedModel.model_fields["supplier_id"].json_schema_extra
    assert isinstance(extra, dict)
    assert extra.get("link") == "Supplier"
