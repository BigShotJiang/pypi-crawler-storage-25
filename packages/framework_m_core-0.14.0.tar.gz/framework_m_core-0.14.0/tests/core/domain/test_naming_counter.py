"""Tests for NamingCounter DocType."""

from framework_m_core.domain.naming_counter import NamingCounter


def test_naming_counter_creation() -> None:
    """Should create NamingCounter with expected fields."""
    counter = NamingCounter(prefix="INV-2026-", current=42)

    assert counter.prefix == "INV-2026-"
    assert counter.current == 42
    assert NamingCounter.get_api_resource() is False


def test_get_counter_name() -> None:
    """Should safely format prefix into a valid counter name."""
    assert NamingCounter.get_counter_name("INV-2026-") == "COUNTER-INV_2026_"
    assert NamingCounter.get_counter_name("REQ.A.") == "COUNTER-REQ_A_"
    assert NamingCounter.get_counter_name("PREFIX") == "COUNTER-PREFIX"


def test_naming_counter_default_current() -> None:
    """Should default current to 0."""
    counter = NamingCounter(prefix="TEST-")
    assert counter.current == 0
