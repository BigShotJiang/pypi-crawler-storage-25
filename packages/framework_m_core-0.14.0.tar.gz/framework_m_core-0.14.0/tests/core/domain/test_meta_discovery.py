"""Tests for metadata-driven aggregate discovery."""

from framework_m_core.domain.base_doctype import BaseDocType
from framework_m_core.registry import MetaRegistry


class StandardDoc(BaseDocType):
    """A standard document, not an aggregate root."""

    name: str


class MyAggregateRoot(BaseDocType):
    """An aggregate root document."""

    name: str

    class Meta:
        is_aggregate_root = True
        aggregate_children = ["ChildOne", "ChildTwo"]


def test_doctype_meta_aggregate_defaults() -> None:
    """Standard DocTypes should not be aggregate roots by default."""
    assert StandardDoc.get_is_aggregate_root() is False
    assert StandardDoc.get_aggregate_children() == []


def test_doctype_meta_aggregate_overrides() -> None:
    """DocTypes can be explicitly marked as aggregate roots with children."""
    assert MyAggregateRoot.get_is_aggregate_root() is True
    assert MyAggregateRoot.get_aggregate_children() == ["ChildOne", "ChildTwo"]


def test_registry_aggregate_discovery() -> None:
    """MetaRegistry should auto-discover all aggregate roots."""
    registry = MetaRegistry()
    registry.clear()
    registry.register_doctype(StandardDoc)
    registry.register_doctype(MyAggregateRoot)

    roots = registry.get_aggregate_roots()
    assert len(roots) == 1
    assert roots[0] is MyAggregateRoot
