"""Tests for Singleton DocType support."""

from framework_m_core.domain.base_doctype import BaseDocType, Field
from framework_m_core.registry import MetaRegistry

# =============================================================================
# Mock Singleton DocType
# =============================================================================


class MockSingleton(BaseDocType):
    """A mock singleton DocType for testing."""

    title: str = Field(default="Test Singleton")

    class Meta:
        table_name = "mock_singleton"
        is_singleton = True
        api_resource = True


# =============================================================================
# Tests
# =============================================================================


class TestSingletonCore:
    """Tests for singleton metadata and registry."""

    def test_singleton_flag(self) -> None:
        """DocType should correctly report is_singleton."""
        assert MockSingleton.get_is_singleton() is True

    def test_meta_flags_include_singleton(self) -> None:
        """get_meta_flags should include is_singleton."""
        flags = MockSingleton.get_meta_flags()
        assert flags["is_singleton"] is True


def test_registry_whitelist() -> None:
    """MetaRegistry should whitelist is_singleton."""
    registry = MetaRegistry.get_instance()
    assert "is_singleton" in registry.get_whitelisted_meta_keys()
