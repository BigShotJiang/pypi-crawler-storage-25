"""Import/export assertions for RFC-0008 public symbols (Step 11.1)."""


def test_import_mixins_exports() -> None:
    """AuditMixin, VersionedMixin, and SiblingMixin should be importable."""
    from framework_m_core.domain.mixins import AuditMixin, SiblingMixin, VersionedMixin

    assert AuditMixin is not None
    assert VersionedMixin is not None
    assert SiblingMixin is not None


def test_import_temporal_query_error_export() -> None:
    """TemporalQueryNotSupportedError should be importable from exceptions."""
    from framework_m_core.exceptions import TemporalQueryNotSupportedError

    assert TemporalQueryNotSupportedError is not None


def test_import_correction_service_export() -> None:
    """CorrectionService should be importable from correction service module."""
    from framework_m.core.services.correction import CorrectionService

    assert CorrectionService is not None


def test_import_versioning_config_export() -> None:
    """is_versioning_enabled should be importable from versioning config module."""
    from framework_m_standard.adapters.db.versioning_config import is_versioning_enabled

    assert is_versioning_enabled is not None
