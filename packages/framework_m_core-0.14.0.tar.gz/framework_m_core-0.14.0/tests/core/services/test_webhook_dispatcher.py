"""Tests for webhook_dispatcher service."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from framework_m_core.doctypes.webhook import Webhook
from framework_m_core.interfaces.event_bus import Event
from framework_m_core.services.webhook_dispatcher import (
    _compare_values,
    _get_nested,
    _parse_literal,
    _to_number,
    evaluate_webhook_condition,
    fire_webhook,
    should_dispatch_webhook,
)


def test_evaluate_webhook_condition_empty() -> None:
    assert evaluate_webhook_condition(None, {"a": 1}) is True
    assert evaluate_webhook_condition("   ", {"a": 1}) is True
    assert evaluate_webhook_condition("", {"a": 1}) is True


def test_evaluate_webhook_condition_jmespath() -> None:
    # Jmespath should handle valid conditions if installed
    try:
        import jmespath  # noqa

        assert evaluate_webhook_condition("a == `1`", {"a": 1}) is True
        assert evaluate_webhook_condition("a == `2`", {"a": 1}) is False
        assert evaluate_webhook_condition("b", {"b": True}) is True
        assert evaluate_webhook_condition("b", {"b": False}) is False
        assert evaluate_webhook_condition("c", {"c": 1}) is True
        assert evaluate_webhook_condition("c", {"c": 0}) is False
        assert evaluate_webhook_condition("d", {"d": "yes"}) is True
        assert evaluate_webhook_condition("e", {}) is False
    except ImportError:
        pytest.skip("jmespath not installed")


def test_evaluate_webhook_condition_fallback() -> None:
    # Force fallback to manual matching by mocking jmespath to raise ImportError
    with patch.dict("sys.modules", {"jmespath": None}):
        assert evaluate_webhook_condition("a == 1", {"a": 1}) is True
        assert evaluate_webhook_condition("a == 2", {"a": 1}) is False
        assert evaluate_webhook_condition("a > 0", {"a": 1}) is True
        assert evaluate_webhook_condition("invalid condition", {"a": 1}) is False


def test_should_dispatch_webhook() -> None:
    webhook = Webhook(
        name="test",
        event="doc.created",
        url="http://test",
        doctype_filter="Invoice",
        enabled=True,
    )

    # Perfect match
    event1 = Event(type="doc.created", data={"doctype": "Invoice"})
    assert should_dispatch_webhook(webhook, event1) is True

    # Event mismatch
    event2 = Event(type="doc.updated", data={"doctype": "Invoice"})
    assert should_dispatch_webhook(webhook, event2) is False

    # Doctype mismatch
    event3 = Event(type="doc.created", data={"doctype": "User"})
    assert should_dispatch_webhook(webhook, event3) is False

    # Event with direct doctype attribute
    mock_event4 = MagicMock(spec=Event)
    mock_event4.type = "doc.created"
    mock_event4.doctype = "Invoice"
    mock_event4.data = {}
    assert should_dispatch_webhook(webhook, mock_event4) is True

    # Webhook with no doctype filter
    webhook_no_filter = Webhook(
        name="test2",
        event="doc.created",
        url="http://test",
        enabled=True,
    )
    assert should_dispatch_webhook(webhook_no_filter, event3) is True


@pytest.mark.asyncio
async def test_fire_webhook_success() -> None:
    webhook = Webhook(name="test", event="e", url="http://t", enabled=True)
    event = Event(type="e")
    deliverer = AsyncMock()

    await fire_webhook(webhook, event, deliverer, max_retries=2, base_delay=0.01)
    deliverer.deliver.assert_called_once_with(webhook, event)


@pytest.mark.asyncio
async def test_fire_webhook_retry_success() -> None:
    webhook = Webhook(name="test", event="e", url="http://t", enabled=True)
    event = Event(type="e")
    deliverer = AsyncMock()
    deliverer.deliver.side_effect = [Exception("fail"), None]
    sleep_func = AsyncMock()

    await fire_webhook(
        webhook,
        event,
        deliverer,
        max_retries=2,
        base_delay=0.01,
        sleep_func=sleep_func,
    )

    assert deliverer.deliver.call_count == 2
    sleep_func.assert_called_once_with(0.01)


@pytest.mark.asyncio
async def test_fire_webhook_exhaust_retries() -> None:
    webhook = Webhook(name="test", event="e", url="http://t", enabled=True)
    event = Event(type="e")
    deliverer = AsyncMock()
    deliverer.deliver.side_effect = Exception("fail")
    sleep_func = AsyncMock()

    with pytest.raises(Exception, match="fail"):
        await fire_webhook(
            webhook,
            event,
            deliverer,
            max_retries=2,
            base_delay=0.01,
            sleep_func=sleep_func,
        )

    assert deliverer.deliver.call_count == 3
    assert sleep_func.call_count == 2


@pytest.mark.asyncio
async def test_fire_webhook_invalid_retries() -> None:
    webhook = Webhook(name="test", event="e", url="http://t", enabled=True)
    event = Event(type="e")
    deliverer = AsyncMock()
    with pytest.raises(ValueError, match="max_retries must be >= 0"):
        await fire_webhook(webhook, event, deliverer, max_retries=-1)


def test_get_nested() -> None:
    data = {"a": {"b": {"c": 1}}}
    assert _get_nested(data, "a.b.c") == 1
    assert _get_nested(data, "a.x") is None
    assert _get_nested(data, "x") is None
    assert _get_nested({"a": 1}, "a.b") is None


def test_parse_literal() -> None:
    assert _parse_literal("`abc`") == "abc"
    assert _parse_literal('"abc"') == "abc"
    assert _parse_literal("'abc'") == "abc"
    assert _parse_literal("true") is True
    assert _parse_literal("False") is False
    assert _parse_literal("null") is None
    assert _parse_literal("None") is None
    assert _parse_literal("123") == 123
    assert _parse_literal("123.45") == 123.45
    assert _parse_literal("some_string") == "some_string"


def test_compare_values() -> None:
    assert _compare_values(1, "==", 1) is True
    assert _compare_values(1, "!=", 2) is True
    assert _compare_values(2, ">", 1) is True
    assert _compare_values(1, "<", 2) is True
    assert _compare_values(2, ">=", 2) is True
    assert _compare_values(1, "<=", 2) is True

    # String comparisons
    assert _compare_values("a", "==", "a") is True
    assert _compare_values("a", "!=", "b") is True

    # Invalid comparisons
    assert _compare_values(None, ">", 1) is False
    assert _compare_values(1, "<", None) is False
    assert _compare_values(None, ">=", 1) is False
    assert _compare_values(1, "<=", None) is False
    assert _compare_values(1, "unknown", 1) is False


def test_to_number() -> None:
    assert _to_number(True) is None
    assert _to_number(None) is None
    assert _to_number(1) == 1.0
    assert _to_number(1.5) == 1.5
    assert _to_number("123") == 123.0
    assert _to_number("123.45") == 123.45
    assert _to_number("abc") is None
