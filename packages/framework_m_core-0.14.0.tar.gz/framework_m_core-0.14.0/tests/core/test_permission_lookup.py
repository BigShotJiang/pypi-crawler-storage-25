"""Tests for PermissionLookupService.

TDD tests for CustomPermission database overrides lookup.
"""

import pytest
from framework_m_core.doctypes.custom_permission import (
    CustomPermission,
    PermissionEffect,
)
from framework_m_core.permission_lookup import PermissionLookupService


class TestPermissionLookupService:
    """Tests for PermissionLookupService."""

    @pytest.fixture(autouse=True)
    def clear_rules(self) -> None:
        """Clear rules before each test."""
        PermissionLookupService.clear_rules()
        yield
        PermissionLookupService.clear_rules()

    def test_register_rule(self) -> None:
        """Should register a permission rule."""
        rule = CustomPermission(
            name="test-rule",
            for_user="alice",
            doctype_name="Invoice",
            action="read",
            effect=PermissionEffect.ALLOW,
        )
        PermissionLookupService.register_rule(rule)

        rules = PermissionLookupService.find_rules(
            user_id="alice",
            roles=[],
            doctype="Invoice",
            action="read",
        )
        assert len(rules) == 1
        assert rules[0].name == "test-rule"

    def test_find_rules_by_user(self) -> None:
        """Should find rules matching specific user."""
        PermissionLookupService.register_rule(
            CustomPermission(
                name="for-alice",
                for_user="alice",
                doctype_name="Invoice",
                action="read",
                effect=PermissionEffect.ALLOW,
            )
        )
        PermissionLookupService.register_rule(
            CustomPermission(
                name="for-bob",
                for_user="bob",
                doctype_name="Invoice",
                action="read",
                effect=PermissionEffect.ALLOW,
            )
        )

        rules = PermissionLookupService.find_rules(
            user_id="alice",
            roles=[],
            doctype="Invoice",
            action="read",
        )
        assert len(rules) == 1
        assert rules[0].name == "for-alice"

    def test_find_rules_by_role(self) -> None:
        """Should find rules matching user roles."""
        PermissionLookupService.register_rule(
            CustomPermission(
                name="for-managers",
                for_role="Manager",
                doctype_name="Invoice",
                action="delete",
                effect=PermissionEffect.ALLOW,
            )
        )

        rules = PermissionLookupService.find_rules(
            user_id="alice",
            roles=["Employee", "Manager"],
            doctype="Invoice",
            action="delete",
        )
        assert len(rules) == 1
        assert rules[0].name == "for-managers"

    def test_find_rules_wildcard_doctype(self) -> None:
        """Should match rules with wildcard doctype."""
        PermissionLookupService.register_rule(
            CustomPermission(
                name="deny-all-delete",
                for_role="Intern",
                doctype_name="*",
                action="delete",
                effect=PermissionEffect.DENY,
            )
        )

        rules = PermissionLookupService.find_rules(
            user_id="intern1",
            roles=["Intern"],
            doctype="Invoice",
            action="delete",
        )
        assert len(rules) == 1
        assert rules[0].effect == PermissionEffect.DENY

    def test_deny_rules_come_first(self) -> None:
        """DENY rules should be sorted before ALLOW rules."""
        PermissionLookupService.register_rule(
            CustomPermission(
                name="allow-rule",
                for_user="alice",
                doctype_name="Invoice",
                action="read",
                effect=PermissionEffect.ALLOW,
            )
        )
        PermissionLookupService.register_rule(
            CustomPermission(
                name="deny-rule",
                for_user="alice",
                doctype_name="Invoice",
                action="read",
                effect=PermissionEffect.DENY,
            )
        )

        rules = PermissionLookupService.find_rules(
            user_id="alice",
            roles=[],
            doctype="Invoice",
            action="read",
        )
        assert len(rules) == 2
        assert rules[0].effect == PermissionEffect.DENY  # DENY first

    def test_check_permission_deny(self) -> None:
        """check_permission should return False for deny rules."""
        PermissionLookupService.register_rule(
            CustomPermission(
                name="deny-alice",
                for_user="alice",
                doctype_name="Invoice",
                action="delete",
                effect=PermissionEffect.DENY,
                description="Alice cannot delete invoices",
            )
        )

        result, reason = PermissionLookupService.check_permission(
            user_id="alice",
            roles=["Employee"],
            doctype="Invoice",
            action="delete",
        )
        assert result is False
        assert "deny-alice" in reason

    def test_check_permission_allow(self) -> None:
        """check_permission should return True for allow rules."""
        PermissionLookupService.register_rule(
            CustomPermission(
                name="allow-alice-read",
                for_user="alice",
                doctype_name="Invoice",
                action="read",
                effect=PermissionEffect.ALLOW,
            )
        )

        result, reason = PermissionLookupService.check_permission(
            user_id="alice",
            roles=[],
            doctype="Invoice",
            action="read",
        )
        assert result is True
        assert "allow-alice-read" in reason

    def test_check_permission_no_match(self) -> None:
        """check_permission should return None if no matching rule."""
        result, reason = PermissionLookupService.check_permission(
            user_id="unknown",
            roles=["Guest"],
            doctype="Invoice",
            action="read",
        )
        assert result is None
        assert reason == ""

    def test_disabled_rules_skipped(self) -> None:
        """Disabled rules should not be matched."""
        PermissionLookupService.register_rule(
            CustomPermission(
                name="disabled-rule",
                for_user="alice",
                doctype_name="Invoice",
                action="read",
                effect=PermissionEffect.ALLOW,
                enabled=False,
            )
        )

        rules = PermissionLookupService.find_rules(
            user_id="alice",
            roles=[],
            doctype="Invoice",
            action="read",
        )
        assert len(rules) == 0

    def test_priority_sorting(self) -> None:
        """Higher priority rules should come first."""
        PermissionLookupService.register_rule(
            CustomPermission(
                name="low-priority",
                for_user="alice",
                doctype_name="Invoice",
                action="read",
                effect=PermissionEffect.ALLOW,
                priority=1,
            )
        )
        PermissionLookupService.register_rule(
            CustomPermission(
                name="high-priority",
                for_user="alice",
                doctype_name="Invoice",
                action="read",
                effect=PermissionEffect.ALLOW,
                priority=10,
            )
        )

        rules = PermissionLookupService.find_rules(
            user_id="alice",
            roles=[],
            doctype="Invoice",
            action="read",
        )
        assert len(rules) == 2
        assert rules[0].name == "high-priority"

    def test_register_rules(self) -> None:
        """Should register multiple permission rules."""
        rules = [
            CustomPermission(
                name="r1", doctype_name="*", action="*", effect=PermissionEffect.ALLOW
            ),
            CustomPermission(
                name="r2", doctype_name="*", action="*", effect=PermissionEffect.ALLOW
            ),
        ]
        PermissionLookupService.register_rules(rules)
        found = PermissionLookupService.find_rules("u1", [], "Invoice", "read")
        assert len(found) == 2

    def test_find_rules_doctype_mismatch(self) -> None:
        """Should skip rule if doctype does not match."""
        PermissionLookupService.register_rule(
            CustomPermission(
                name="r1",
                doctype_name="OtherDoc",
                action="read",
                effect=PermissionEffect.ALLOW,
            )
        )
        rules = PermissionLookupService.find_rules("u1", [], "Invoice", "read")
        assert len(rules) == 0

    def test_find_rules_action_mismatch(self) -> None:
        """Should skip rule if action does not match."""
        PermissionLookupService.register_rule(
            CustomPermission(
                name="r1",
                doctype_name="Invoice",
                action="write",
                effect=PermissionEffect.ALLOW,
            )
        )
        rules = PermissionLookupService.find_rules("u1", [], "Invoice", "read")
        assert len(rules) == 0

    def test_find_rules_applies_to_all(self) -> None:
        """Should match rules that apply to all users and roles."""
        PermissionLookupService.register_rule(
            CustomPermission(
                name="global-rule",
                doctype_name="*",
                action="*",
                effect=PermissionEffect.ALLOW,
            )
        )
        rules = PermissionLookupService.find_rules("u1", [], "Invoice", "read")
        assert len(rules) == 1
        assert rules[0].name == "global-rule"

    def test_check_permission_deny_no_desc(self) -> None:
        """check_permission should return False for deny rules without a description."""
        PermissionLookupService.register_rule(
            CustomPermission(
                name="deny-r",
                for_user="u1",
                doctype_name="Invoice",
                action="read",
                effect=PermissionEffect.DENY,
            )
        )
        res, reason = PermissionLookupService.check_permission(
            "u1", [], "Invoice", "read"
        )
        assert res is False
        assert reason == "Denied by rule 'deny-r'"

    def test_check_permission_allow_with_desc(self) -> None:
        """check_permission should return True for allow rules with a description."""
        PermissionLookupService.register_rule(
            CustomPermission(
                name="allow-r",
                for_user="u1",
                doctype_name="Invoice",
                action="read",
                effect=PermissionEffect.ALLOW,
                description="Allowed for u1",
            )
        )
        res, reason = PermissionLookupService.check_permission(
            "u1", [], "Invoice", "read"
        )
        assert res is True
        assert reason == "Allowed by rule 'allow-r': Allowed for u1"

    def test_check_permission_unknown_effect(self) -> None:
        """check_permission should return None if the effect is neither ALLOW nor DENY."""
        rule = CustomPermission.model_construct(
            name="unknown", doctype_name="*", action="*", effect="invalid_effect"
        )
        PermissionLookupService.register_rule(rule)
        res, reason = PermissionLookupService.check_permission(
            "u1", [], "Invoice", "read"
        )
        assert res is None
        assert reason == ""
