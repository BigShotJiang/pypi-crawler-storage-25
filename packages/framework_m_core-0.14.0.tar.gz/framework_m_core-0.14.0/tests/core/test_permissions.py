"""Security and permission hardening tests (Section 8 checklist).

These tests cover:
- "Read All" bypass rules for record and list access
- Anonymous access behavior on public DocTypes
- RLS overreach prevention for non-admin users
"""

from typing import ClassVar
from uuid import uuid4

import pytest
from framework_m_core.doctypes.todo import Todo
from framework_m_core.domain.base_doctype import BaseDocType
from framework_m_core.interfaces.auth_context import UserContext
from framework_m_core.interfaces.permission import PermissionAction
from framework_m_core.permissions import has_permission_for_doc
from framework_m_core.registry import MetaRegistry
from framework_m_standard.adapters.auth.rbac_permission import RbacPermissionAdapter


class ReadAllDoc(BaseDocType):
    """DocType where read is globally allowed via All wildcard."""

    title: str = ""

    class Meta:
        requires_auth: ClassVar[bool] = True
        apply_rls: ClassVar[bool] = True
        permissions: ClassVar[dict[str, list[str]]] = {
            "read": ["All"],
            "write": ["Manager", "Admin"],
        }


class OwnerScopedDoc(BaseDocType):
    """DocType where reads are role-based but still owner-scoped."""

    title: str = ""

    class Meta:
        requires_auth: ClassVar[bool] = True
        apply_rls: ClassVar[bool] = True
        permissions: ClassVar[dict[str, list[str]]] = {
            "read": ["Employee", "Manager"],
            "write": ["Manager"],
        }


class PublicReadAllDoc(BaseDocType):
    """Public DocType with RLS enabled and global read permission."""

    title: str = ""

    class Meta:
        requires_auth: ClassVar[bool] = False
        apply_rls: ClassVar[bool] = True
        permissions: ClassVar[dict[str, list[str]]] = {
            "read": ["All"],
        }


@pytest.fixture(autouse=True)
def setup_registry() -> None:
    """Register test DocTypes before each test."""
    registry = MetaRegistry.get_instance()
    registry.clear()
    registry.register_doctype(ReadAllDoc)
    registry.register_doctype(OwnerScopedDoc)
    registry.register_doctype(PublicReadAllDoc)


class TestSecurityAndPermissionHardening:
    """Section 8 checklist behavior verification."""

    @pytest.mark.asyncio
    async def test_all_role_can_read_non_owned_document(self) -> None:
        """A user with All-level read should bypass owner check for a single doc."""
        user = UserContext(
            id="user-all",
            email="all@example.com",
            roles=["All"],
        )

        doc = ReadAllDoc(
            id=uuid4(),
            owner="other-user",
            title="Shared record",
        )

        allowed = await has_permission_for_doc(user, doc, PermissionAction.READ)

        assert allowed is True

    @pytest.mark.asyncio
    async def test_anonymous_can_read_public_doc_with_all_permission(self) -> None:
        """Anonymous users can read public docs when DocType is public and read=All."""
        doc = PublicReadAllDoc(
            id=uuid4(),
            owner="owner-123",
            title="Public record",
        )

        allowed = await has_permission_for_doc(None, doc, PermissionAction.READ)

        assert allowed is True

    @pytest.mark.asyncio
    async def test_list_filters_empty_for_read_all_permission_even_non_admin(
        self,
    ) -> None:
        """Read All permission should bypass owner filter even for non-admin roles."""
        adapter = RbacPermissionAdapter()

        filters = await adapter.get_permitted_filters(
            principal="user-employee",
            principal_attributes={"roles": ["Employee"]},
            resource="ReadAllDoc",
        )

        assert filters == {}

    @pytest.mark.asyncio
    async def test_list_filters_owner_scoped_without_read_all_permission(self) -> None:
        """Without higher read permission, users remain owner-scoped."""
        adapter = RbacPermissionAdapter()

        filters = await adapter.get_permitted_filters(
            principal="user-employee",
            principal_attributes={"roles": ["Employee"]},
            resource="OwnerScopedDoc",
        )

        assert filters == {"owner": "user-employee"}

    @pytest.mark.asyncio
    async def test_non_admin_user_is_restricted_to_owner_without_higher_read_role(
        self,
    ) -> None:
        """Non-admin users should not bypass owner checks when no read-all grant exists."""
        user = UserContext(
            id="user-employee",
            email="employee@example.com",
            roles=["Employee"],
        )

        doc = OwnerScopedDoc(
            id=uuid4(),
            owner="someone-else",
            title="Private record",
        )

        allowed = await has_permission_for_doc(user, doc, PermissionAction.READ)

        assert allowed is False

    def test_todo_doctype_disables_rls_for_global_testing(self) -> None:
        """Todo should remain globally readable in test flows."""
        assert Todo.get_apply_rls() is False
