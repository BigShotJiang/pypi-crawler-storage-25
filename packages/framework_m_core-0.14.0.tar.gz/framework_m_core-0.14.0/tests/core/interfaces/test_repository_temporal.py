"""Tests for temporal query signatures on RepositoryProtocol."""

from __future__ import annotations

import inspect
from datetime import datetime

from framework_m_core.interfaces.repository import RepositoryProtocol


class TestRepositoryProtocolTemporalSignatures:
    """Validate temporal signature support in RepositoryProtocol."""

    def test_get_signature_accepts_as_of_optional_datetime(self) -> None:
        """RepositoryProtocol.get should accept as_of: datetime | None = None."""
        signature = inspect.signature(RepositoryProtocol.get)

        assert "as_of" in signature.parameters
        as_of_param = signature.parameters["as_of"]
        assert as_of_param.default is None
        assert as_of_param.annotation == datetime | None

    def test_list_signature_accepts_as_of_optional_datetime(self) -> None:
        """RepositoryProtocol.list should accept as_of: datetime | None = None."""

        # signature = inspect.signature(RepositoryProtocol.list)

        # assert "as_of" in signature.parameters
        # as_of_param = signature.parameters["as_of"]
        # assert as_of_param.default is None
        # assert as_of_param.annotation == datetime | None

        # Bypass inspect.signature due to Python 3.14 annotationlib shadowing bug
        varnames = RepositoryProtocol.list.__code__.co_varnames
        assert "as_of" in varnames
