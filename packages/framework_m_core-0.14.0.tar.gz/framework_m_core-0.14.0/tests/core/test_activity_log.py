"""Tests for ActivityLog DocType.

Tests cover:
- ActivityLog model creation
- Field validation
- Meta configuration
"""

from datetime import UTC
from unittest.mock import AsyncMock

import pytest
from framework_m_core.doctypes.activity_log import ActivityLog
from framework_m_core.exceptions import ImmutableDocumentError, PermissionDeniedError
from framework_m_core.interfaces.repository import RepositoryProtocol
from framework_m_standard.adapters.audit.database_audit import DatabaseAuditAdapter

# =============================================================================
# Test: Import
# =============================================================================


class TestActivityLogImport:
    """Tests for ActivityLog import."""

    def test_import_activity_log(self) -> None:
        """ActivityLog should be importable."""
        from framework_m_core.doctypes.activity_log import ActivityLog

        assert ActivityLog is not None


# =============================================================================
# Test: Model Creation
# =============================================================================


class TestActivityLogCreation:
    """Tests for ActivityLog model creation."""

    def test_create_minimal(self) -> None:
        """ActivityLog should work with required fields only."""
        log = ActivityLog(
            user_id="user-001",
            action="create",
            doctype_name="Invoice",
            document_id="INV-001",
        )

        assert log.user_id == "user-001"
        assert log.action == "create"
        assert log.doctype_name == "Invoice"
        assert log.document_id == "INV-001"
        assert log.id is not None
        assert log.timestamp is not None

    def test_create_with_job_id(self) -> None:
        """ActivityLog should accept job_id."""
        log = ActivityLog(
            user_id="user-001",
            action="create",
            doctype_name="Invoice",
            document_id="INV-001",
            job_id="job-123",
        )

        assert log.job_id == "job-123"

    def test_create_with_diff(self) -> None:
        """ActivityLog should accept diff dict."""
        log = ActivityLog(
            user_id="user-001",
            action="update",
            doctype_name="Invoice",
            document_id="INV-001",
            diff={"status": {"old": "draft", "new": "submitted"}},
        )

        assert log.diff is not None
        assert log.diff["status"]["old"] == "draft"
        assert log.diff["status"]["new"] == "submitted"

    def test_create_with_metadata(self) -> None:
        """ActivityLog should accept metadata dict."""
        log = ActivityLog(
            user_id="user-001",
            action="read",
            doctype_name="Invoice",
            document_id="INV-001",
            metadata={"request_id": "req-123", "ip": "192.168.1.1"},
        )

        assert log.metadata is not None
        assert log.metadata["request_id"] == "req-123"

    def test_timestamp_is_utc(self) -> None:
        """ActivityLog timestamp should be UTC."""
        log = ActivityLog(
            user_id="user-001",
            action="create",
            doctype_name="Todo",
            document_id="TODO-001",
        )

        assert log.timestamp.tzinfo is not None
        assert log.timestamp.tzinfo == UTC


# =============================================================================
# Test: Validation
# =============================================================================


class TestActivityLogValidation:
    """Tests for field validation."""

    def test_action_must_be_valid(self) -> None:
        """action should only accept create, read, update, delete."""
        # Valid actions
        for action in ["create", "read", "update", "delete"]:
            log = ActivityLog(
                user_id="user-001",
                action=action,
                doctype_name="Todo",
                document_id="TODO-001",
            )
            assert log.action == action

    def test_invalid_action_rejected(self) -> None:
        """Invalid action should raise validation error."""
        with pytest.raises(ValueError):
            ActivityLog(
                user_id="user-001",
                action="invalid",
                doctype_name="Todo",
                document_id="TODO-001",
            )

    def test_user_id_required(self) -> None:
        """user_id should be required."""
        with pytest.raises(ValueError):
            ActivityLog(
                user_id="",
                action="create",
                doctype_name="Todo",
                document_id="TODO-001",
            )


# =============================================================================
# Test: Meta Configuration
# =============================================================================


class TestActivityLogMeta:
    """Tests for Meta class configuration."""

    def test_meta_table_name(self) -> None:
        """Meta should have correct table_name."""
        assert ActivityLog.Meta.table_name == "activity_logs"

    def test_meta_requires_auth(self) -> None:
        """Meta should require authentication."""
        assert ActivityLog.Meta.requires_auth is True

    def test_meta_apply_rls(self) -> None:
        """Meta should apply RLS."""
        assert ActivityLog.Meta.apply_rls is True

    def test_meta_rls_field(self) -> None:
        """Meta should use user_id for RLS."""
        assert ActivityLog.Meta.rls_field == "user_id"

    def test_meta_permissions_read_only(self) -> None:
        """Meta should have read-only permissions (no write/delete)."""
        assert ActivityLog.Meta.permissions["write"] == []
        assert ActivityLog.Meta.permissions["delete"] == []


# =============================================================================
# Test: Immutability Guard
# =============================================================================


class TestActivityLogImmutability:
    """Tests that ActivityLog records are append-only and immutable."""

    def test_meta_permissions_write_empty(self) -> None:
        """ActivityLog should not expose write permission."""
        assert ActivityLog.Meta.permissions["write"] == []

    def test_meta_permissions_delete_empty(self) -> None:
        """ActivityLog should not expose delete permission."""
        assert ActivityLog.Meta.permissions["delete"] == []

    @pytest.mark.asyncio
    async def test_database_audit_log_uses_insert_save_path_only(self) -> None:
        """Adapter log() should persist a fresh ActivityLog via repository.save only."""
        mock_repo = AsyncMock(spec=RepositoryProtocol[ActivityLog])
        mock_repo.get = AsyncMock(return_value=None)
        mock_repo.save = AsyncMock()
        adapter = DatabaseAuditAdapter(repository=mock_repo)

        await adapter.log(
            user_id="user-001",
            action="create",
            doctype="Invoice",
            document_id="INV-001",
        )

        mock_repo.save.assert_awaited_once()
        saved_entry = mock_repo.save.await_args.args[0]
        assert isinstance(saved_entry, ActivityLog)

    @pytest.mark.asyncio
    async def test_database_audit_log_rejects_update_if_entry_id_already_exists(
        self,
    ) -> None:
        """Adapter should refuse update-like writes for immutable ActivityLog records."""
        existing = ActivityLog(
            user_id="user-001",
            action="create",
            doctype_name="Invoice",
            document_id="INV-001",
        )

        mock_repo = AsyncMock(spec=RepositoryProtocol[ActivityLog])
        mock_repo.get = AsyncMock(return_value=existing)
        adapter = DatabaseAuditAdapter(repository=mock_repo)

        with pytest.raises(PermissionDeniedError, match="immutable"):
            await adapter.log(
                user_id="user-001",
                action="update",
                doctype="Invoice",
                document_id="INV-001",
            )

        mock_repo.save.assert_not_called()

    @pytest.mark.asyncio
    async def test_repository_save_existing_activity_log_raises_immutable_error(
        self,
    ) -> None:
        """Saving an existing ActivityLog should propagate immutable/permission errors."""
        existing = ActivityLog(
            user_id="user-001",
            action="create",
            doctype_name="Invoice",
            document_id="INV-001",
        )

        mock_repo = AsyncMock(spec=RepositoryProtocol[ActivityLog])
        mock_repo.save = AsyncMock(
            side_effect=ImmutableDocumentError(
                "ActivityLog",
                "*",
                str(existing.id),
            )
        )

        with pytest.raises((ImmutableDocumentError, PermissionDeniedError)):
            await mock_repo.save(existing)
