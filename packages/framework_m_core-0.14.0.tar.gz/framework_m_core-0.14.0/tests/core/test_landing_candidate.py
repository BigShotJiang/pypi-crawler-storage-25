"""Tests for LandingCandidate Child Table.

Tests cover:
- LandingCandidate model creation
- Field validation
- Meta configuration for child table
"""

from framework_m_core.doctypes.landing_candidate import LandingCandidate


def test_landing_candidate_import() -> None:
    """LandingCandidate should be importable."""
    assert LandingCandidate is not None


def test_landing_candidate_creation() -> None:
    """It should create with a route and default optional fields."""
    candidate = LandingCandidate(route="/app/admin")
    assert candidate.route == "/app/admin"
    assert candidate.required_doctype is None
    assert candidate.required_action is None


def test_landing_candidate_with_permissions() -> None:
    """It should store required permission fields."""
    candidate = LandingCandidate(
        route="/app/admin", required_doctype="User", required_action="read"
    )
    assert candidate.required_doctype == "User"
    assert candidate.required_action == "read"


def test_landing_candidate_meta() -> None:
    """Meta should mark it as an internal child table."""
    assert LandingCandidate.get_is_child_table() is True
    assert LandingCandidate.get_api_resource() is False
