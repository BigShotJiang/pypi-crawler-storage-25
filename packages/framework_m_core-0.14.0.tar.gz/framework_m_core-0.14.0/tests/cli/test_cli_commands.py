"""Fast CLI command tests.

Tests CLI commands without heavy npm operations.
Focus on command structure, error handling, and fast validations.
"""

from __future__ import annotations

import subprocess


class TestCLIStructure:
    """Test overall CLI structure."""

    def test_main_cli_runs(self) -> None:
        """Test that main CLI runs without errors."""
        result = subprocess.run(
            ["python", "-m", "framework_m_core.cli.main", "--help"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        assert result.returncode == 0
        assert "framework" in result.stdout.lower() or "usage" in result.stdout.lower()

    def test_all_commands_listed(self) -> None:
        """Test that key commands are listed in help."""
        result = subprocess.run(
            ["python", "-m", "framework_m_core.cli.main", "--help"],
            capture_output=True,
            text=True,
        )

        # Should list major commands
        help_text = result.stdout.lower()
        # discovery check - should see commands from plugins
        assert "prod" in help_text
        assert "new" in help_text
        assert "docs" in help_text
