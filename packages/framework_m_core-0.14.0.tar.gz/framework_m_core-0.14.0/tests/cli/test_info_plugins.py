"""Tests for m info plugin mechanism."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from framework_m_core.cli.utility import info_command
from rich.table import Table


def test_info_command_calls_plugins(capsys: pytest.CaptureFixture[str]) -> None:
    """info_command should discover and call plugins in verbose mode."""

    # Mock entry_points to return a dummy plugin
    mock_plugin = MagicMock()

    def dummy_plugin(table: Table) -> None:
        table.add_row("Dummy Plugin", "Active")
        mock_plugin()

    mock_ep = MagicMock()
    mock_ep.name = "dummy"
    mock_ep.load.return_value = dummy_plugin

    with patch("framework_m_core.cli.utility.entry_points") as mock_entry_points:
        mock_entry_points.return_value = [mock_ep]

        info_command(verbose=True)

        # Check if plugin was called
        mock_plugin.assert_called_once()

        captured = capsys.readouterr()
        assert "Dummy Plugin" in captured.out
        assert "Active" in captured.out


def test_info_command_handles_plugin_errors(capsys: pytest.CaptureFixture[str]) -> None:
    """info_command should handle errors in plugins gracefully."""

    def error_plugin(table: Table) -> None:
        raise RuntimeError("Plugin Failed")

    mock_ep = MagicMock()
    mock_ep.name = "failing_plugin"
    mock_ep.load.return_value = error_plugin

    with patch("framework_m_core.cli.utility.entry_points") as mock_entry_points:
        mock_entry_points.return_value = [mock_ep]

        info_command(verbose=True)

        captured = capsys.readouterr()
        assert "Plugin Error (failing_plugin)" in captured.out
        assert "Plugin Failed" in captured.out
