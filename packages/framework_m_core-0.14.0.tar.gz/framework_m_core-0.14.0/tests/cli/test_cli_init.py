import cyclopts
from framework_m_core.cli.main import app


def test_cli_app_initialization():
    assert isinstance(app, cyclopts.App)
    # Cyclopts App name can be a tuple or string depending on version/config
    name = app.name[0] if isinstance(app.name, tuple) else app.name
    assert name == "m"

    # Check if core commands are registered
    # Cyclopts stores registered commands in _registered_commands (dict)
    # The keys can be the command objects themselves or names
    command_names = [getattr(cmd, "name", str(cmd)) for cmd in app._registered_commands]
    assert any("info" in name for name in command_names)
    assert any("config:show" in name for name in command_names)
    assert any("config:set" in name for name in command_names)
