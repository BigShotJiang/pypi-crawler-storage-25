"""Tests for the Worker Activity Registry."""

import pytest
from framework_m_core.interfaces.worker import ActivityRegistry, worker_activity


@pytest.fixture(autouse=True)
def clear_registry() -> None:
    """Clear the singleton registry before each test."""
    ActivityRegistry.get_instance().clear()


def test_register_and_get_activity() -> None:
    """It should register an activity with a custom name."""

    @worker_activity(name="custom_send_email")
    async def send_email(to: str, body: str) -> bool:
        return True

    registry = ActivityRegistry.get_instance()
    activities = registry.get_all()

    assert "custom_send_email" in activities
    assert activities["custom_send_email"] == send_email


def test_activity_decorator_without_name() -> None:
    """It should default to the function name if no name is provided."""

    @worker_activity()
    async def default_name_activity() -> None:
        pass

    assert "default_name_activity" in ActivityRegistry.get_instance().get_all()
