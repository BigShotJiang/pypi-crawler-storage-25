"""Tests for Authentication interfaces."""

import contextlib
from collections.abc import Mapping

import pytest
from framework_m_core.interfaces.auth_context import UserContext
from framework_m_core.interfaces.authentication import AuthenticationProtocol


class MockAuthentication(AuthenticationProtocol):
    """Mock implementation of AuthenticationProtocol."""

    def supports(self, headers: Mapping[str, str]) -> bool:
        """Check if headers support this auth method."""
        return "x-mock-auth" in headers

    async def authenticate(self, headers: Mapping[str, str]) -> UserContext | None:
        """Authenticate using mock headers."""
        if not self.supports(headers):
            return None
        return UserContext(id="mock-user", email="mock@example.com", roles=["TestRole"])


@pytest.mark.asyncio
async def test_authentication_protocol_implementation() -> None:
    """Test that AuthenticationProtocol can be implemented and used."""
    auth = MockAuthentication()

    # Test supports
    assert auth.supports({"x-mock-auth": "true"}) is True
    assert auth.supports({"other-header": "true"}) is False

    # Test authenticate
    user = await auth.authenticate({"x-mock-auth": "true"})
    assert user is not None
    assert user.id == "mock-user"

    no_user = await auth.authenticate({"other-header": "true"})
    assert no_user is None


@pytest.mark.asyncio
async def test_authentication_protocol_base_methods() -> None:
    """Directly call base methods to satisfy coverage for base class bodies."""

    class BaseCallAuth(AuthenticationProtocol):
        def supports(self, headers: Mapping[str, str]) -> bool:
            return super().supports(headers)  # type: ignore

        async def authenticate(self, headers: Mapping[str, str]) -> UserContext | None:
            return await super().authenticate(headers)  # type: ignore

    auth = BaseCallAuth()

    # We just want to execute the base protocol methods.
    # They will likely raise NotImplementedError or return None/Empty depending on how the Protocol is defined.
    with contextlib.suppress(NotImplementedError, AttributeError):
        auth.supports({})

    with contextlib.suppress(NotImplementedError, AttributeError):
        await auth.authenticate({})
