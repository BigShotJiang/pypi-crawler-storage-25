"""Tests for Worker interfaces and protocols."""

from framework_m_core.interfaces.worker import WorkerProtocol


def test_worker_protocol_implementation() -> None:
    """It should correctly identify valid WorkerProtocol implementations."""

    class ValidWorker:
        async def start(self) -> None:
            pass

        async def stop(self) -> None:
            pass

    class InvalidWorker:
        # Missing the stop() method
        async def start(self) -> None:
            pass

    valid_instance = ValidWorker()
    invalid_instance = InvalidWorker()

    assert isinstance(valid_instance, WorkerProtocol)
    assert not isinstance(invalid_instance, WorkerProtocol)
