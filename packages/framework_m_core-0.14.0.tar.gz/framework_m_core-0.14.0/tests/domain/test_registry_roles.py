"""Tests for Runtime Role Discovery via MetaRegistry.

TDD tests for Milestone 9.5 to ensure the system can dynamically
discover and aggregate roles defined in DocType.Meta classes.
"""

import pytest
from framework_m_core.domain.base_doctype import BaseDocType
from framework_m_core.registry import MetaRegistry


@pytest.fixture(autouse=True)
def clear_registry() -> None:
    """Clear the singleton registry before each test to prevent collisions."""
    MetaRegistry.get_instance().clear()


class SalesInvoice(BaseDocType):
    """Mock DocType for testing role extraction."""

    class Meta:
        roles = {
            "read": ["Sales User", "Auditor"],
            "write": ["Sales Manager"],
            "submit": ["Sales Manager"],
        }


class EmployeeLeave(BaseDocType):
    """Another Mock DocType to test role deduplication."""

    class Meta:
        roles = {
            "read": ["Employee", "HR User"],
            "write": ["Employee"],
            "approve": ["HR Manager", "Sales Manager"],
        }


def test_registry_list_active_roles() -> None:
    """It should extract and deduplicate all roles from registered DocTypes."""
    registry = MetaRegistry()
    registry.register_doctype(SalesInvoice)
    registry.register_doctype(EmployeeLeave)

    active_roles = registry.list_active_roles()

    expected_roles = {
        "Sales User",
        "Auditor",
        "Sales Manager",
        "Employee",
        "HR User",
        "HR Manager",
    }
    assert set(active_roles) == expected_roles


def test_registry_role_injection() -> None:
    """It should allow injecting additional runtime roles that might not be in DocTypes."""
    registry = MetaRegistry()
    registry.register_doctype(SalesInvoice)

    # Inject a system role that has no specific DocType bindings yet
    registry.inject_role("System Administrator")

    active_roles = registry.list_active_roles()
    assert "System Administrator" in active_roles
    assert "Sales Manager" in active_roles
