"""Tests for Landing Domain Models."""

import pytest
from framework_m_core.domain.landing import LandingDescriptor
from pydantic import ValidationError


def test_landing_descriptor_creation() -> None:
    """It should create a LandingDescriptor with a required route."""
    descriptor = LandingDescriptor(route="/app/dashboard")
    assert descriptor.route == "/app/dashboard"
    assert descriptor.metadata == {}


def test_landing_descriptor_with_metadata() -> None:
    """It should create a LandingDescriptor with optional metadata."""
    descriptor = LandingDescriptor(
        route="/app/Todo", metadata={"context": "user_specific"}
    )
    assert descriptor.route == "/app/Todo"
    assert descriptor.metadata == {"context": "user_specific"}


def test_landing_descriptor_requires_route() -> None:
    """It should fail validation if route is missing."""
    with pytest.raises(ValidationError):
        LandingDescriptor()  # type: ignore
