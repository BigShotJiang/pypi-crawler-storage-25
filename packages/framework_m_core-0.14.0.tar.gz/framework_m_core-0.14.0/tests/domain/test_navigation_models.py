"""Tests for Navigation Domain Models.

Validates the Navigation Manifest and Node Tree models, specifically checking
for correct fields and strict validation rules (hierarchical badge topic paths and
route interpolation).
"""

import pytest
from framework_m_core.domain.navigation import (
    NavigationManifest,
    NavigationNode,
    VisibilityPolicy,
)
from pydantic import ValidationError


def test_navigation_node_interactive_fields() -> None:
    """It should correctly accept hardware and interaction intent fields."""
    resource = NavigationNode(
        name="wms.scanner",
        label="Scanner",
        route="/wms/scan",
        badge="wms.queries.pending_scans",
        hardware_intent="barcode_scan",
        interaction_mode="touch_optimized",
    )
    assert resource.badge == "wms.queries.pending_scans"
    assert resource.hardware_intent == "barcode_scan"
    assert resource.interaction_mode == "touch_optimized"


def test_navigation_node_validates_badge_path() -> None:
    """It should strictly validate badge paths as hierarchical topic formats.

    Valid paths should be dot-separated alphanumeric strings.
    """
    # Valid paths should pass without error
    NavigationNode(name="t1", label="T1", route="/t", badge="wms.queries.picks")
    NavigationNode(name="t2", label="T2", route="/t", badge="core.notifications.unread")

    # Invalid paths (e.g., containing spaces, special characters, or consecutive dots)
    with pytest.raises(ValidationError, match="badge"):
        NavigationNode(name="t3", label="T3", route="/t", badge="Invalid Path!")

    with pytest.raises(ValidationError, match="badge"):
        NavigationNode(name="t4", label="T4", route="/t", badge="wms..invalid")

    with pytest.raises(ValidationError, match="badge"):
        NavigationNode(name="t5", label="T5", route="/t", badge="UpperCase.Not.Allowed")


def test_navigation_node_validates_route_interpolation() -> None:
    """It should validate string interpolation formats in routes."""
    # Valid interpolation formats should pass
    NavigationNode(name="t1", label="T1", route="/test/{{ id }}")
    NavigationNode(name="t2", label="T2", route="/test/{{ doc.name }}")

    # Invalid interpolation formats (e.g., mismatched brackets) should fail
    with pytest.raises(ValidationError, match="route"):
        NavigationNode(name="t3", label="T3", route="/test/{{ id }")

    with pytest.raises(ValidationError, match="route"):
        NavigationNode(name="t4", label="T4", route="/test/{ id }}")


def test_navigation_manifest_structure() -> None:
    """It should assemble a complete app manifest with nested children and policies."""
    manifest = NavigationManifest(
        app_id="wms",
        label="Warehouse",
        icon="box",
        resources=[
            NavigationNode(
                name="wms.inventory",
                label="Inventory",
                route="/wms/inventory",
                visibility_policy=VisibilityPolicy(roles=["Warehouse Manager"]),
            )
        ],
    )

    assert manifest.app_id == "wms"
    assert len(manifest.resources) == 1
    assert manifest.resources[0].visibility_policy is not None
    assert manifest.resources[0].visibility_policy.roles == ["Warehouse Manager"]
