"""Tests for IntrospectionProtocol interface compliance."""

from framework_m_core.interfaces.introspection import (
    ColumnMeta,
    IndexMeta,
    IntrospectionProtocol,
    TableMeta,
)


class TestColumnMeta:
    """Tests for ColumnMeta model."""

    def test_column_meta_creation(self) -> None:
        """ColumnMeta should create with required fields and defaults."""
        col = ColumnMeta(name="title", type="VARCHAR", max_length=255)

        assert col.name == "title"
        assert col.type == "VARCHAR"
        assert col.max_length == 255
        assert col.nullable is True
        assert col.primary_key is False
        assert col.default is None

    def test_column_meta_primary_key(self) -> None:
        """ColumnMeta should accept primary_key and nullable flags."""
        col = ColumnMeta(name="id", type="UUID", primary_key=True, nullable=False)

        assert col.primary_key is True
        assert col.nullable is False


class TestIndexMeta:
    """Tests for IndexMeta model."""

    def test_index_meta_creation(self) -> None:
        """IndexMeta should create with required fields."""
        idx = IndexMeta(name="ix_title", columns=["title"])

        assert idx.name == "ix_title"
        assert idx.columns == ["title"]
        assert idx.unique is False


class TestTableMeta:
    """Tests for TableMeta model."""

    def test_table_meta_creation(self) -> None:
        """TableMeta should create with required fields and handle nested models."""
        table = TableMeta(
            name="todo",
            columns=[ColumnMeta(name="id", type="UUID")],
            indexes=[IndexMeta(name="ix_todo_id", columns=["id"], unique=True)],
        )

        assert table.name == "todo"
        assert len(table.columns) == 1
        assert len(table.indexes) == 1
        assert table.indexes[0].unique is True


class TestIntrospectionProtocol:
    """Tests for IntrospectionProtocol interface."""

    def test_protocol_has_introspect_methods(self) -> None:
        """IntrospectionProtocol should define required introspection methods."""
        assert hasattr(IntrospectionProtocol, "introspect_table")
        assert hasattr(IntrospectionProtocol, "introspect_database")
