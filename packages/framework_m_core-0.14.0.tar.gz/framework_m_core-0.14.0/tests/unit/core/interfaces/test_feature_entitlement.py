"""Tests for Feature Entitlement Protocol."""

from typing import Protocol

from framework_m_core.interfaces.feature_entitlement import FeatureEntitlementProtocol


class TestFeatureEntitlementProtocol:
    """Tests for FeatureEntitlementProtocol interface."""

    def test_is_protocol(self) -> None:
        """FeatureEntitlementProtocol should be a Protocol."""
        assert issubclass(FeatureEntitlementProtocol, Protocol)

    def test_has_is_feature_enabled_method(self) -> None:
        """It should define the is_feature_enabled method."""
        assert hasattr(FeatureEntitlementProtocol, "is_feature_enabled")
