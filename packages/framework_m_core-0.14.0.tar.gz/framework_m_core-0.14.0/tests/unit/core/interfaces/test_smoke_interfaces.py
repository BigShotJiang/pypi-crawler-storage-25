from __future__ import annotations

from typing import Protocol, runtime_checkable

from framework_m_core.interfaces.authentication import AuthenticationProtocol
from framework_m_core.interfaces.notification import (
    NotificationProtocol,
    NotificationType,
)
from framework_m_core.interfaces.oauth import (
    OAuth2Protocol,
    OAuth2Token,
    OAuth2UserInfo,
)
from framework_m_core.interfaces.read_model import ReadModelProtocol, ReadQueryResult
from framework_m_core.interfaces.report_engine import ReportEngineProtocol, ReportResult
from framework_m_core.interfaces.secrets import SecretProtocol


def test_authentication_protocol_import():
    assert issubclass(AuthenticationProtocol, Protocol)
    assert runtime_checkable(AuthenticationProtocol) is AuthenticationProtocol


def test_notification_protocol_import():
    assert issubclass(NotificationProtocol, Protocol)
    assert NotificationType.EMAIL == "email"


def test_oauth_protocol_import():
    assert issubclass(OAuth2Protocol, Protocol)
    # Basic check for dataclasses/types
    token = OAuth2Token(access_token="token")
    assert token.access_token == "token"

    user_info = OAuth2UserInfo(
        provider="test", provider_user_id="id", display_name="name"
    )
    assert user_info.provider == "test"


def test_read_model_protocol_import():
    assert issubclass(ReadModelProtocol, Protocol)
    assert issubclass(ReadQueryResult, Protocol) is False


def test_report_engine_protocol_import():
    assert issubclass(ReportEngineProtocol, Protocol)
    assert issubclass(ReportResult, Protocol) is False


def test_secrets_protocol_import():
    assert issubclass(SecretProtocol, Protocol)
