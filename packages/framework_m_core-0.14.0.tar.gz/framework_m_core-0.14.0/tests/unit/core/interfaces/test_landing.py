"""Tests for LandingProtocol interface compliance."""

from typing import Protocol, get_type_hints

from framework_m_core.domain.landing import LandingDescriptor
from framework_m_core.interfaces.auth_context import UserContext
from framework_m_core.interfaces.landing import LandingProtocol


class TestLandingProtocol:
    """Tests for LandingProtocol interface."""

    def test_is_protocol(self) -> None:
        """LandingProtocol should be a Protocol."""
        assert issubclass(LandingProtocol, Protocol)

    def test_has_resolve_method(self) -> None:
        """It should define the resolve method."""
        assert hasattr(LandingProtocol, "resolve")

    def test_resolve_method_signature(self) -> None:
        """resolve() should take UserContext and return LandingDescriptor | None."""
        hints = get_type_hints(LandingProtocol.resolve)
        assert hints["context"] is UserContext
        assert hints["return"] == LandingDescriptor | None
