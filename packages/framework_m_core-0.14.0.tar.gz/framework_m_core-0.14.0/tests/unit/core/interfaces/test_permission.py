"""Tests for PermissionProtocol interface compliance."""

from unittest.mock import MagicMock, patch

import pytest
from framework_m_core.domain.base_doctype import BaseDocType
from framework_m_core.interfaces.auth_context import UserContext
from framework_m_core.interfaces.permission import (
    DecisionSource,
    PermissionAction,
    PermissionProtocol,
    PolicyEvaluateRequest,
    PolicyEvaluateResult,
)
from framework_m_core.permissions import has_permission, has_permission_for_doc


class TestPermissionAction:
    """Tests for PermissionAction enum."""

    def test_permission_action_values(self) -> None:
        """PermissionAction should have all required action types."""
        assert PermissionAction.READ.value == "read"
        assert PermissionAction.WRITE.value == "write"
        assert PermissionAction.CREATE.value == "create"
        assert PermissionAction.DELETE.value == "delete"
        assert PermissionAction.SUBMIT.value == "submit"
        assert PermissionAction.CANCEL.value == "cancel"
        assert PermissionAction.AMEND.value == "amend"


class TestDecisionSource:
    """Tests for DecisionSource enum."""

    def test_decision_source_values(self) -> None:
        """DecisionSource should have all required source types."""
        assert DecisionSource.RBAC.value == "rbac"
        assert DecisionSource.ABAC.value == "abac"
        assert DecisionSource.REBAC.value == "rebac"
        assert DecisionSource.COMBO.value == "combo"


class TestPolicyEvaluateRequest:
    """Tests for PolicyEvaluateRequest dataclass."""

    def test_request_creation(self) -> None:
        """PolicyEvaluateRequest should create with required fields."""
        request = PolicyEvaluateRequest(
            principal="user-001",
            action="read",
            resource="Invoice",
        )
        assert request.principal == "user-001"
        assert request.action == "read"
        assert request.resource == "Invoice"
        assert request.context == {}


class TestPolicyEvaluateResult:
    """Tests for PolicyEvaluateResult dataclass."""

    def test_result_creation(self) -> None:
        """PolicyEvaluateResult should create with required fields."""
        result = PolicyEvaluateResult(
            authorized=True,
            decision_source=DecisionSource.RBAC,
        )
        assert result.authorized is True
        assert result.decision_source == DecisionSource.RBAC


class TestPermissionProtocol:
    """Tests for PermissionProtocol interface."""

    def test_protocol_has_evaluate_method(self) -> None:
        """PermissionProtocol should define evaluate method."""
        assert hasattr(PermissionProtocol, "evaluate")

    def test_protocol_has_get_permitted_filters_method(self) -> None:
        """PermissionProtocol should define get_permitted_filters method."""
        assert hasattr(PermissionProtocol, "get_permitted_filters")


class TestPermissionsModuleHelpers:
    """Tests for the high-level permission helpers in framework_m_core.permissions."""

    @pytest.mark.asyncio
    async def test_has_permission_doctype_none(self) -> None:
        """Should return False if registry returns None for doctype."""
        with patch(
            "framework_m_core.registry.MetaRegistry.get_doctype", return_value=None
        ):
            result = await has_permission(None, "UnknownDoc", "read")
            assert result is False

    @pytest.mark.asyncio
    async def test_has_permission_for_doc_doctype_exception(self) -> None:
        """Should return False if registry raises an exception."""
        doc = MagicMock(spec=BaseDocType)
        doc.get_doctype_name.return_value = "TestDoc"
        doc.id = "123"
        user = UserContext(id="user-123", email="user@example.com", roles=["User"])

        with (
            patch("framework_m_core.permissions.has_permission", return_value=True),
            patch(
                "framework_m_core.registry.MetaRegistry.get_doctype",
                side_effect=Exception("Registry error"),
            ),
        ):
            result = await has_permission_for_doc(user, doc, "read")
            assert result is False

    @pytest.mark.asyncio
    async def test_has_permission_for_doc_doctype_none(self) -> None:
        """Should return False if registry returns None for doctype."""
        doc = MagicMock(spec=BaseDocType)
        doc.get_doctype_name.return_value = "TestDoc"
        doc.id = "123"
        user = UserContext(id="user-123", email="user@example.com", roles=["User"])

        with (
            patch("framework_m_core.permissions.has_permission", return_value=True),
            patch(
                "framework_m_core.registry.MetaRegistry.get_doctype", return_value=None
            ),
        ):
            result = await has_permission_for_doc(user, doc, "read")
            assert result is False

    @pytest.mark.asyncio
    async def test_has_permission_for_doc_public_user_none(self) -> None:
        """Should return True immediately if user is None (public DocType)."""
        doc = MagicMock(spec=BaseDocType)
        doc.get_doctype_name.return_value = "TestDoc"
        doc.id = "123"

        mock_doctype_class = MagicMock()
        mock_doctype_class.get_apply_rls.return_value = False

        # has_permission returns True for public doctype with user=None
        with (
            patch("framework_m_core.permissions.has_permission", return_value=True),
            patch(
                "framework_m_core.registry.MetaRegistry.get_doctype",
                return_value=mock_doctype_class,
            ),
        ):
            result = await has_permission_for_doc(None, doc, "read")
            assert result is True

    @pytest.mark.asyncio
    async def test_has_permission_for_doc_no_owner(self) -> None:
        """Should return True if RLS applies but document has no owner yet."""
        doc = MagicMock(spec=BaseDocType)
        doc.get_doctype_name.return_value = "TestDoc"
        doc.id = "123"
        doc.owner = None

        mock_doctype_class = MagicMock()
        mock_doctype_class.get_apply_rls.return_value = True

        user = UserContext(id="user-123", email="user@example.com", roles=["User"])

        with (
            patch("framework_m_core.permissions.has_permission", return_value=True),
            patch(
                "framework_m_core.registry.MetaRegistry.get_doctype",
                return_value=mock_doctype_class,
            ),
        ):
            result = await has_permission_for_doc(user, doc, "read")
            assert result is True
