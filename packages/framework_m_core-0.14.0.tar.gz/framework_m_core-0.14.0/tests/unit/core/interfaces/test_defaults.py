"""Tests for DefaultsProtocol interface compliance."""

from typing import Any, Protocol, get_type_hints

from framework_m_core.interfaces.defaults import DefaultsProtocol


class TestDefaultsProtocol:
    """Tests for DefaultsProtocol interface."""

    def test_is_protocol(self) -> None:
        """DefaultsProtocol should be a Protocol."""
        assert issubclass(DefaultsProtocol, Protocol)

    def test_has_get_method(self) -> None:
        """It should define the get method."""
        assert hasattr(DefaultsProtocol, "get")

    def test_has_get_all_method(self) -> None:
        """It should define the get_all method."""
        assert hasattr(DefaultsProtocol, "get_all")

    def test_get_method_signature(self) -> None:
        """get() should take key and optional default, returning Any."""
        hints = get_type_hints(DefaultsProtocol.get)
        assert hints["key"] is str
        assert hints["return"] is Any

    def test_get_all_method_signature(self) -> None:
        """get_all() should return a dictionary of string keys to Any values."""
        hints = get_type_hints(DefaultsProtocol.get_all)
        assert hints["return"] == dict[str, Any]
