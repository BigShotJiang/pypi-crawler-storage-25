"""Tests for Navigation Protocols."""

from typing import Protocol

from framework_m_core.interfaces.navigation import NavigationProtocol


class TestNavigationProtocol:
    """Tests for NavigationProtocol interface."""

    def test_is_protocol(self) -> None:
        """NavigationProtocol should be a Protocol."""
        assert issubclass(NavigationProtocol, Protocol)

    def test_has_get_navigation_manifest_method(self) -> None:
        """It should define the get_navigation_manifest method."""
        assert hasattr(NavigationProtocol, "get_navigation_manifest")
