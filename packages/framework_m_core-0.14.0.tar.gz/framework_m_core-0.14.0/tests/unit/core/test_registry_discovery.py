"""Tests for MetaRegistry discovery mechanisms."""

from unittest.mock import MagicMock, patch

import pytest
from framework_m_core.registry import MetaRegistry


@pytest.fixture
def registry():
    """Clear registry before each test."""
    reg = MetaRegistry.get_instance()
    reg.clear()
    return reg


class TestRegistryDiscovery:
    """Tests for MetaRegistry.load_installed_apps and related methods."""

    def test_load_installed_apps_calls_discoveries(self, registry):
        """load_installed_apps should call core discovery and entry points."""
        with (
            patch.object(
                registry, "discover_doctypes", return_value=1
            ) as mock_discover,
            patch("importlib.metadata.entry_points") as mock_eps,
        ):
            # Mock entry points
            mock_ep = MagicMock()
            mock_ep.name = "test_app"
            mock_ep.module = "test_app:app"
            mock_ep.load.return_value = {}
            mock_eps.return_value = [mock_ep]

            count = registry.load_installed_apps()

            assert count > 0
            # Should discover core + test_app
            assert mock_discover.called
            assert any(
                "framework_m_core.doctypes" in str(args)
                for args, _ in mock_discover.call_args_list
            )
