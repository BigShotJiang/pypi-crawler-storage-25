"""Tests for webhook listener integration and dispatcher behavior."""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock

import pytest
from framework_m_core.doctypes.webhook import Webhook
from framework_m_core.events import DocUpdated
from framework_m_core.interfaces.event_bus import Event
from framework_m_core.services.webhook_dispatcher import fire_webhook
from framework_m_standard.adapters.webhooks.listener import WebhookListener


class _FakeEventBus:
    async def subscribe_pattern(self, pattern: str, handler: object) -> str:
        await asyncio.sleep(0)
        return f"sub-{pattern}"

    async def unsubscribe(self, subscription_id: str) -> None:
        await asyncio.sleep(0)
        return None


class _FixedWebhookLoader:
    def __init__(self, webhooks: list[Webhook]) -> None:
        self._webhooks = webhooks

    async def load_active_webhooks(self) -> list[Webhook]:
        await asyncio.sleep(0)
        return self._webhooks


@pytest.mark.asyncio
async def test_webhook_listener_queues_job_on_invoice_after_save() -> None:
    """Matching Invoice update should enqueue a fire_webhook job."""
    webhook = Webhook(
        name="invoice_after_save",
        event="doc.updated",
        doctype_filter="Invoice",
        condition="total > 100",
        url="https://example.com/webhook",
    )

    loader = _FixedWebhookLoader([webhook])
    job_queue = AsyncMock()
    listener = WebhookListener(
        event_bus=_FakeEventBus(),
        webhook_loader=loader,
        deliverer=AsyncMock(),
        job_queue=job_queue,
        use_job_queue=True,
    )

    event = DocUpdated(
        doctype="Invoice",
        doc_name="INV-001",
        changed_fields=["total"],
        data={"doctype": "Invoice", "total": 150},
    )
    await listener.handle_event(event)

    job_queue.enqueue.assert_awaited_once()
    call = job_queue.enqueue.await_args
    assert call.args[0] == "fire_webhook"
    assert call.kwargs["event_type"] == "doc.updated"
    assert call.kwargs["webhook_condition"] == "total > 100"


@pytest.mark.asyncio
async def test_webhook_listener_filters_with_condition_expression() -> None:
    """Condition expression should block non-matching events."""
    webhook = Webhook(
        name="high_total_only",
        event="doc.updated",
        doctype_filter="Invoice",
        condition="total > 100",
        url="https://example.com/webhook",
    )

    loader = _FixedWebhookLoader([webhook])
    deliverer = AsyncMock()
    listener = WebhookListener(
        event_bus=_FakeEventBus(),
        webhook_loader=loader,
        deliverer=deliverer,
    )

    low_total_event = DocUpdated(
        doctype="Invoice",
        doc_name="INV-LOW",
        changed_fields=["total"],
        data={"doctype": "Invoice", "total": 75},
    )
    await listener.handle_event(low_total_event)
    deliverer.deliver.assert_not_awaited()

    high_total_event = DocUpdated(
        doctype="Invoice",
        doc_name="INV-HIGH",
        changed_fields=["total"],
        data={"doctype": "Invoice", "total": 175},
    )
    await listener.handle_event(high_total_event)
    deliverer.deliver.assert_awaited_once()


@pytest.mark.asyncio
async def test_fire_webhook_retries_with_exponential_backoff() -> None:
    """fire_webhook should retry failed deliveries before succeeding."""
    webhook = Webhook(
        name="retry_webhook",
        event="doc.created",
        url="https://example.com/webhook",
    )
    event = Event(type="doc.created", data={"doctype": "Invoice", "total": 200})

    deliverer = AsyncMock()
    deliverer.deliver = AsyncMock(side_effect=[RuntimeError("temporary failure"), None])

    recorded_delays: list[float] = []

    async def fake_sleep(delay: float) -> None:
        await asyncio.sleep(0)
        recorded_delays.append(delay)

    await fire_webhook(
        webhook,
        event,
        deliverer,
        max_retries=2,
        base_delay=0.25,
        sleep_func=fake_sleep,
    )

    assert deliverer.deliver.await_count == 2
    assert recorded_delays == [0.25]
