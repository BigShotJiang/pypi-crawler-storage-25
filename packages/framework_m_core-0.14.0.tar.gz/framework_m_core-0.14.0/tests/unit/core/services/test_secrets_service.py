from unittest.mock import MagicMock

import pytest
from framework_m_core.interfaces.secrets import SecretProtocol
from framework_m_core.services.secrets_service import SecretsManager


def test_secrets_manager_get():
    mock_adapter = MagicMock(spec=SecretProtocol)
    mock_adapter.get_secret.return_value = "secret_value"

    manager = SecretsManager(mock_adapter)
    assert manager.get("my_key") == "secret_value"
    mock_adapter.get_secret.assert_called_once_with("my_key", None)


def test_secrets_manager_validate_success():
    mock_adapter = MagicMock(spec=SecretProtocol)
    mock_adapter.get_secret.side_effect = lambda k, d: (
        "value" if k in ["key1", "key2"] else None
    )

    manager = SecretsManager(mock_adapter)
    # Should not raise
    manager.validate(["key1", "key2"])


def test_secrets_manager_validate_failure():
    mock_adapter = MagicMock(spec=SecretProtocol)
    mock_adapter.get_secret.side_effect = lambda k, d: "value" if k == "key1" else None

    manager = SecretsManager(mock_adapter)
    with pytest.raises(RuntimeError) as excinfo:
        manager.validate(["key1", "key2"])

    assert "Missing required secrets: key2" in str(excinfo.value)
