"""Tests for DefaultsService orchestrator."""

from typing import Any
from unittest.mock import AsyncMock

import pytest
from framework_m_core.domain.base_doctype import BaseDocType
from framework_m_core.interfaces.defaults import DefaultsProtocol
from framework_m_core.services.defaults_service import DefaultsService


class DummySingleton(BaseDocType):
    app_name: str
    timezone: str = "UTC"

    class Meta:
        is_singleton = True
        defaults_file = "dummy.toml"


class DummyRecord(BaseDocType):
    department: str
    leave_days: int = 20

    class Meta:
        defaults_file = "hr_defaults.toml"


@pytest.fixture
def mock_defaults_factory() -> Any:
    """Provides an AsyncMock factory that returns different adapters based on source."""

    def factory(source: str | None) -> DefaultsProtocol:
        mock = AsyncMock(spec=DefaultsProtocol)
        if source == "dummy.toml":
            mock.get_all.return_value = {"app_name": "Virtual App", "timezone": "PST"}
        elif source == "hr_defaults.toml":
            mock.get_all.return_value = {"department": "General", "leave_days": 15}
        else:
            mock.get_all.return_value = {}
        return mock

    return factory


@pytest.mark.asyncio
async def test_build_virtual_singleton(mock_defaults_factory: Any) -> None:
    """It should construct a virtual singleton using the configured defaults file."""
    service = DefaultsService(defaults_factory=mock_defaults_factory)
    doc = await service.build_virtual_singleton(DummySingleton)

    assert isinstance(doc, DummySingleton)
    assert doc.app_name == "Virtual App"
    assert doc.timezone == "PST"  # Overridden by TOML


@pytest.mark.asyncio
async def test_hydrate_with_defaults(mock_defaults_factory: Any) -> None:
    """It should merge user input over the fallback configuration defaults."""
    service = DefaultsService(defaults_factory=mock_defaults_factory)

    # User explicitly overrides the TOML's leave_days, but relies on TOML for department
    user_input = {"leave_days": 30}

    hydrated = await service.hydrate_with_defaults(DummyRecord, user_input)

    assert isinstance(hydrated, DummyRecord)
    assert hydrated.department == "General"  # From TOML fallback
    assert hydrated.leave_days == 30  # User input wins tie
