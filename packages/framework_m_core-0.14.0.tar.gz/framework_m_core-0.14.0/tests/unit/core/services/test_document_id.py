"""Tests for DocumentIdService."""

import uuid

from framework_m_core.services.document_id import (
    FRAMEWORK_M_NAMESPACE,
    DocumentIdService,
)


def test_generate_deterministic_id_consistency() -> None:
    """It should generate the exact same UUID for the same input."""
    service = DocumentIdService()
    id1 = service.generate_deterministic_id("Role", "Admin")
    id2 = service.generate_deterministic_id("Role", "Admin")
    assert id1 == id2


def test_generate_deterministic_id_differs_by_name() -> None:
    """It should generate different UUIDs for different names."""
    service = DocumentIdService()
    id1 = service.generate_deterministic_id("Role", "Admin")
    id2 = service.generate_deterministic_id("Role", "User")
    assert id1 != id2


def test_generate_deterministic_id_differs_by_doctype() -> None:
    """It should generate different UUIDs for the same name in different DocTypes."""
    service = DocumentIdService()
    id1 = service.generate_deterministic_id("Role", "Admin")
    id2 = service.generate_deterministic_id("User", "Admin")
    assert id1 != id2


def test_expected_uuid5_derivation() -> None:
    """It should accurately derive the UUID5 using the framework URL namespace."""
    expected_root = uuid.uuid5(uuid.NAMESPACE_URL, "frameworkm.dev")
    assert expected_root == FRAMEWORK_M_NAMESPACE

    service = DocumentIdService()
    result = service.generate_deterministic_id("PrintFormat", "Standard Invoice")

    expected_result = uuid.uuid5(expected_root, "PrintFormat:Standard Invoice")
    assert result == expected_result
