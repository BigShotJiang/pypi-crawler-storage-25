"""Tests for LandingService orchestration."""

from unittest.mock import AsyncMock

import pytest
from framework_m_core.domain.landing import LandingDescriptor
from framework_m_core.interfaces.auth_context import UserContext
from framework_m_core.interfaces.landing import LandingProtocol
from framework_m_core.services.landing import LandingService


@pytest.fixture
def mock_context() -> UserContext:
    return UserContext(id="user-1", email="test@example.com")


@pytest.mark.asyncio
async def test_landing_service_resolves_first_match(mock_context: UserContext) -> None:
    """It should return the descriptor from the first adapter that resolves."""
    adapter1 = AsyncMock(spec=LandingProtocol)
    adapter1.resolve.return_value = LandingDescriptor(route="/app/override")

    adapter2 = AsyncMock(spec=LandingProtocol)
    adapter2.resolve.return_value = LandingDescriptor(route="/app/fallback")

    service = LandingService(resolvers=[adapter1, adapter2])
    result = await service.resolve(mock_context)

    assert result is not None
    assert result.route == "/app/override"
    adapter1.resolve.assert_called_once_with(mock_context)
    adapter2.resolve.assert_not_called()


@pytest.mark.asyncio
async def test_landing_service_falls_through_to_second(
    mock_context: UserContext,
) -> None:
    """It should try the next adapter if the first returns None."""
    adapter1 = AsyncMock(spec=LandingProtocol)
    adapter1.resolve.return_value = None

    adapter2 = AsyncMock(spec=LandingProtocol)
    adapter2.resolve.return_value = LandingDescriptor(route="/app/fallback")

    service = LandingService(resolvers=[adapter1, adapter2])
    result = await service.resolve(mock_context)

    assert result is not None
    assert result.route == "/app/fallback"
    adapter1.resolve.assert_called_once_with(mock_context)
    adapter2.resolve.assert_called_once_with(mock_context)


@pytest.mark.asyncio
async def test_landing_service_no_resolution(mock_context: UserContext) -> None:
    """It should return None if no adapters resolve the landing page."""
    adapter1 = AsyncMock(spec=LandingProtocol)
    adapter1.resolve.return_value = None

    service = LandingService(resolvers=[adapter1])
    result = await service.resolve(mock_context)

    assert result is None
    adapter1.resolve.assert_called_once_with(mock_context)
