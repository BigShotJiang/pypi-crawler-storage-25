"""Tests for read model projector event handlers."""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock

import pytest
from framework_m_core.events.handlers import (
    subscribe_read_model_projector,
    unsubscribe_read_model_projector,
)
from framework_m_core.interfaces.event_bus import Event


@pytest.mark.asyncio
async def test_doc_created_event_triggers_projection() -> None:
    """Subscribed doc events should project into read model."""
    read_model = AsyncMock()
    read_model.project = AsyncMock()

    subscriptions: dict[str, object] = {}

    class FakeEventBus:
        async def subscribe_pattern(self, pattern: str, handler: object) -> str:
            await asyncio.sleep(0)
            sub_id = f"sub-{pattern}"
            subscriptions[sub_id] = handler
            return sub_id

        async def unsubscribe(self, subscription_id: str) -> None:
            await asyncio.sleep(0)
            subscriptions.pop(subscription_id, None)

    event_bus = FakeEventBus()
    subscription_ids = await subscribe_read_model_projector(
        event_bus=event_bus,
        read_model=read_model,
        event_patterns=["doc.created"],
    )

    event = Event(type="doc.created", data={"doctype": "Invoice", "name": "INV-1"})
    handler = subscriptions[subscription_ids[0]]
    await handler(event)  # type: ignore[misc]

    read_model.project.assert_awaited_once_with(event)


@pytest.mark.asyncio
async def test_doctype_filter_skips_non_matching_events() -> None:
    """Doctype filter should skip events outside configured doctypes."""
    read_model = AsyncMock()
    read_model.project = AsyncMock()

    subscriptions: dict[str, object] = {}

    class FakeEventBus:
        async def subscribe_pattern(self, pattern: str, handler: object) -> str:
            await asyncio.sleep(0)
            sub_id = f"sub-{pattern}"
            subscriptions[sub_id] = handler
            return sub_id

        async def unsubscribe(self, subscription_id: str) -> None:
            await asyncio.sleep(0)
            subscriptions.pop(subscription_id, None)

    event_bus = FakeEventBus()
    subscription_ids = await subscribe_read_model_projector(
        event_bus=event_bus,
        read_model=read_model,
        event_patterns=["doc.*"],
        doctype_filter=["Invoice"],
    )

    handler = subscriptions[subscription_ids[0]]
    await handler(Event(type="doc.created", data={"doctype": "Payment"}))  # type: ignore[misc]

    read_model.project.assert_not_awaited()

    await unsubscribe_read_model_projector(event_bus, subscription_ids)
    assert subscriptions == {}
