"""Tests for Mixins - DocStatus and SubmittableMixin."""

import warnings

import pytest
from framework_m_core import DocType
from framework_m_core.domain.mixins import DocStatus, SubmittableMixin


class TestDocStatus:
    """Tests for DocStatus enum."""

    def test_docstatus_draft_value(self) -> None:
        """DRAFT should have value 0."""
        assert DocStatus.DRAFT.value == 0

    def test_docstatus_submitted_value(self) -> None:
        """SUBMITTED should have value 1."""
        assert DocStatus.SUBMITTED.value == 1

    def test_docstatus_cancelled_value(self) -> None:
        """CANCELLED should have value 2."""
        assert DocStatus.CANCELLED.value == 2

    def test_docstatus_comparison(self) -> None:
        """DocStatus values should be comparable."""
        assert DocStatus.DRAFT < DocStatus.SUBMITTED
        assert DocStatus.SUBMITTED < DocStatus.CANCELLED


# Suppress expected Pydantic warning about field shadowing
# This is intentional for mypy compatibility with mixins
with warnings.catch_warnings():
    warnings.filterwarnings("ignore", message="Field name.*shadows.*")

    class SubmittableInvoice(DocType, SubmittableMixin):
        """Test DocType with SubmittableMixin."""

        customer: str
        total: float = 0.0
        docstatus: DocStatus = DocStatus.DRAFT


class TestSubmittableMixin:
    """Tests for SubmittableMixin functionality."""

    def test_default_docstatus_is_draft(self) -> None:
        """New submittable doc should have DRAFT status."""
        invoice = SubmittableInvoice(customer="Test Customer")

        assert invoice.docstatus == DocStatus.DRAFT

    def test_is_submitted_when_draft(self) -> None:
        """is_submitted should return False for draft."""
        invoice = SubmittableInvoice(customer="Test")

        assert invoice.is_submitted() is False

    def test_is_submitted_when_submitted(self) -> None:
        """is_submitted should return True for submitted."""
        invoice = SubmittableInvoice(customer="Test", docstatus=DocStatus.SUBMITTED)

        assert invoice.is_submitted() is True

    def test_is_cancelled_when_draft(self) -> None:
        """is_cancelled should return False for draft."""
        invoice = SubmittableInvoice(customer="Test")

        assert invoice.is_cancelled() is False

    def test_is_cancelled_when_cancelled(self) -> None:
        """is_cancelled should return True for cancelled."""
        invoice = SubmittableInvoice(customer="Test", docstatus=DocStatus.CANCELLED)

        assert invoice.is_cancelled() is True

    def test_can_edit_when_draft(self) -> None:
        """can_edit should return True for draft."""
        invoice = SubmittableInvoice(customer="Test")

        assert invoice.can_edit() is True

    def test_can_edit_when_submitted(self) -> None:
        """can_edit should return False for submitted."""
        invoice = SubmittableInvoice(customer="Test", docstatus=DocStatus.SUBMITTED)

        assert invoice.can_edit() is False

    def test_can_edit_when_cancelled(self) -> None:
        """can_edit should return False for cancelled."""
        invoice = SubmittableInvoice(customer="Test", docstatus=DocStatus.CANCELLED)

        assert invoice.can_edit() is False

    def test_docstatus_serialization(self) -> None:
        """docstatus should serialize to integer value."""
        invoice = SubmittableInvoice(customer="Test", docstatus=DocStatus.SUBMITTED)
        data = invoice.model_dump()

        assert data["docstatus"] == 1

    def test_docstatus_from_int(self) -> None:
        """docstatus should be settable from integer."""
        invoice = SubmittableInvoice(customer="Test", docstatus=1)  # type: ignore[arg-type]

        assert invoice.docstatus == DocStatus.SUBMITTED


class TestMixinImports:
    """Tests for mixin imports."""

    def test_import_docstatus(self) -> None:
        """DocStatus should be importable."""
        from framework_m_core.domain.mixins import DocStatus

        assert DocStatus is not None

    def test_import_submittable_mixin(self) -> None:
        """SubmittableMixin should be importable."""
        from framework_m_core.domain.mixins import SubmittableMixin

        assert SubmittableMixin is not None


# =============================================================================
# Test: AuditMixin
# =============================================================================


class TestAuditMixin:
    """Tests for AuditMixin marker."""

    def test_import_audit_mixin(self) -> None:
        """AuditMixin should be importable."""
        from framework_m_core.domain.mixins import AuditMixin

        assert AuditMixin is not None

    def test_audited_doctype_has_flag(self) -> None:
        """DocType with AuditMixin should have _audit_enabled = True."""
        from framework_m_core.domain.mixins import AuditMixin

        class AuditedDoc(DocType, AuditMixin):
            pass

        assert getattr(AuditedDoc, "_audit_enabled", False) is True

    def test_plain_doctype_lacks_flag(self) -> None:
        """Plain DocType should not have _audit_enabled flag."""

        class PlainDoc(DocType):
            pass

        assert not hasattr(PlainDoc, "_audit_enabled")

    def test_isinstance_check(self) -> None:
        """isinstance should correctly identify audited doctypes."""
        from framework_m_core.domain.mixins import AuditMixin

        class AuditedDoc(DocType, AuditMixin):
            pass

        doc = AuditedDoc()
        assert isinstance(doc, AuditMixin)


# =============================================================================
# Test: VersionedMixin
# =============================================================================


class TestVersionedMixin:
    """Tests for VersionedMixin marker."""

    def test_import_versioned_mixin(self) -> None:
        """VersionedMixin should be importable."""
        from framework_m_core.domain.mixins import VersionedMixin

        assert VersionedMixin is not None

    def test_versioned_doctype_has_flag(self) -> None:
        """DocType with VersionedMixin should have _versioning_enabled = True."""
        from framework_m_core.domain.mixins import VersionedMixin

        class VersionedDoc(DocType, VersionedMixin):
            pass

        assert getattr(VersionedDoc, "_versioning_enabled", False) is True

    def test_plain_doctype_lacks_versioning_flag(self) -> None:
        """Plain DocType should not have _versioning_enabled flag."""

        class PlainDoc(DocType):
            pass

        assert not hasattr(PlainDoc, "_versioning_enabled")

    def test_isinstance_check(self) -> None:
        """isinstance should correctly identify versioned doctypes."""
        from framework_m_core.domain.mixins import VersionedMixin

        class VersionedDoc(DocType, VersionedMixin):
            pass

        doc = VersionedDoc()
        assert isinstance(doc, VersionedMixin)

    def test_audit_and_versioned_no_mro_conflict(self) -> None:
        """AuditMixin and VersionedMixin should compose without MRO conflicts."""
        from framework_m_core.domain.mixins import AuditMixin, VersionedMixin

        class AuditedVersionedDoc(DocType, AuditMixin, VersionedMixin):
            pass

        doc = AuditedVersionedDoc()
        assert isinstance(doc, AuditMixin)
        assert isinstance(doc, VersionedMixin)
        assert getattr(AuditedVersionedDoc, "_audit_enabled", False) is True
        assert getattr(AuditedVersionedDoc, "_versioning_enabled", False) is True


# =============================================================================
# Test: SiblingMixin
# =============================================================================


class TestSiblingMixin:
    """Tests for SiblingMixin marker and metadata helpers."""

    def test_import_sibling_mixin(self) -> None:
        """SiblingMixin should be importable."""
        from framework_m_core.domain.mixins import SiblingMixin

        assert SiblingMixin is not None

    def test_get_parent_doctype_from_meta_extends(self) -> None:
        """SiblingMixin should return parent DocType name from Meta.extends."""
        from framework_m_core.domain.mixins import SiblingMixin

        class LogisticsMeta(DocType, SiblingMixin):
            class Meta:
                extends = "Invoice"

        assert LogisticsMeta.get_parent_doctype() == "Invoice"

    def test_get_parent_doctype_raises_without_meta_extends(self) -> None:
        """SiblingMixin should raise when Meta.extends is missing."""
        from framework_m_core.domain.mixins import SiblingMixin

        class InvalidSibling(DocType, SiblingMixin):
            class Meta:
                pass

        with pytest.raises(ValueError, match="Meta.extends"):
            InvalidSibling.get_parent_doctype()

    def test_is_metadata_overlay_true_when_meta_flag_set(self) -> None:
        """SiblingMixin should return True when Meta.is_metadata_overlay is True."""
        from framework_m_core.domain.mixins import SiblingMixin

        class OverlaySibling(DocType, SiblingMixin):
            class Meta:
                extends = "Invoice"
                is_metadata_overlay = True

        assert OverlaySibling.is_metadata_overlay() is True

    def test_is_metadata_overlay_false_by_default(self) -> None:
        """SiblingMixin should return False when Meta.is_metadata_overlay is not set."""
        from framework_m_core.domain.mixins import SiblingMixin

        class NonOverlaySibling(DocType, SiblingMixin):
            class Meta:
                extends = "Invoice"

        assert NonOverlaySibling.is_metadata_overlay() is False
