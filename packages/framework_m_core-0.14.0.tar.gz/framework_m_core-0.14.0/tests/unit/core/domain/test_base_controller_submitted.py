"""Tests for BaseController submitted document validation.

Tests the allow_on_submit feature for field-level mutability on submitted documents.
"""

import pytest
from framework_m_core import DocType, Field
from framework_m_core.domain.base_controller import BaseController
from framework_m_core.domain.mixins import DocStatus, SubmittableMixin
from framework_m_core.exceptions import ImmutableDocumentError


class DeliveryNote(DocType, SubmittableMixin):
    """Test DocType for submitted document validation."""

    customer: str = Field(description="Customer name")
    total_amount: float = Field(description="Total amount")

    # Previously allowed fields (now strictly rejected)
    vehicle_no: str = Field(
        default="",
        description="Vehicle number",
    )
    remarks: str | None = Field(
        default=None,
        description="Remarks",
    )


class TestSubmittedDocumentValidation:
    """Tests for validating changes to submitted documents."""

    @pytest.mark.asyncio
    async def test_raise_error_when_updating_any_field(self) -> None:
        """Should raise ImmutableDocumentError when updating any field on submitted doc."""
        existing_doc = DeliveryNote(
            customer="Acme Corp",
            total_amount=1000.0,
            vehicle_no="KA-01-1234",
            docstatus=DocStatus.SUBMITTED,
        )

        new_doc = existing_doc.model_copy()
        new_doc.vehicle_no = "KA-01-5678"  # Try to change what used to be 'allowed'

        controller = BaseController(new_doc)
        with pytest.raises(ImmutableDocumentError) as exc_info:
            await controller._validate_submitted_changes(new_doc, existing_doc)

        assert "vehicle_no" in str(exc_info.value)

        # Same for other fields
        new_doc2 = existing_doc.model_copy()
        new_doc2.total_amount = 1500.0

        controller2 = BaseController(new_doc2)
        with pytest.raises(ImmutableDocumentError) as exc_info:
            await controller2._validate_submitted_changes(new_doc2, existing_doc)

        assert "total_amount" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_allow_all_changes_on_draft_document(self) -> None:
        """Should allow all changes when document is draft."""
        existing_doc = DeliveryNote(
            customer="Acme Corp",
            total_amount=1000.0,
            docstatus=DocStatus.DRAFT,
        )

        new_doc = existing_doc.model_copy()
        new_doc.total_amount = 1500.0
        new_doc.customer = "New Customer"

        controller = BaseController(new_doc)
        # Should not raise (draft docs are mutable)
        # Note: This test assumes validate() skips check for non-submitted docs
        await controller.validate()

    @pytest.mark.asyncio
    async def test_detect_dirty_fields_correctly(self) -> None:
        """Should correctly detect which fields changed."""
        existing_doc = DeliveryNote(
            customer="Acme Corp",
            total_amount=1000.0,
            vehicle_no="KA-01-1234",
            remarks="Original remark",
            docstatus=DocStatus.SUBMITTED,
        )

        new_doc = existing_doc.model_copy()
        new_doc.vehicle_no = "KA-01-5678"
        new_doc.remarks = "Updated remark"

        controller = BaseController(new_doc)
        dirty_fields = controller._get_dirty_fields(new_doc, existing_doc)

        assert "vehicle_no" in dirty_fields
        assert "remarks" in dirty_fields
        assert "customer" not in dirty_fields
        assert "total_amount" not in dirty_fields

    @pytest.mark.asyncio
    async def test_no_dirty_fields_when_no_changes(self) -> None:
        """Should return empty set when no fields changed."""
        existing_doc = DeliveryNote(
            customer="Acme Corp", total_amount=1000.0, docstatus=DocStatus.SUBMITTED
        )

        new_doc = existing_doc.model_copy()

        controller = BaseController(new_doc)
        dirty_fields = controller._get_dirty_fields(new_doc, existing_doc)

        assert len(dirty_fields) == 0

    @pytest.mark.asyncio
    async def test_multiple_field_changes_raises_first_error(self) -> None:
        """Should raise error for first field that changed."""
        existing_doc = DeliveryNote(
            customer="Acme Corp",
            total_amount=1000.0,
            docstatus=DocStatus.SUBMITTED,
        )

        new_doc = existing_doc.model_copy()
        new_doc.customer = "New Customer"
        new_doc.total_amount = 1500.0

        controller = BaseController(new_doc)
        with pytest.raises(ImmutableDocumentError) as exc_info:
            await controller._validate_submitted_changes(new_doc, existing_doc)

        # Should mention at least one of the fields
        error_msg = str(exc_info.value)
        assert "customer" in error_msg or "total_amount" in error_msg
