"""Tests for JSON Diff Utility.

Tests the compute_diff function which calculates changes between
two dictionary states for audit logging.
"""

import pytest
from framework_m_core.domain.diff import compute_diff


class TestComputeDiffImport:
    """Tests for compute_diff import."""

    def test_import_compute_diff(self) -> None:
        """compute_diff should be importable."""
        from framework_m_core.domain.diff import compute_diff

        assert compute_diff is not None


class TestComputeDiff:
    """Tests for compute_diff functionality."""

    def test_empty_dicts_return_empty_diff(self) -> None:
        """Diff of two empty dicts should be empty."""
        assert compute_diff({}, {}) == {}

    def test_identical_dicts_return_empty_diff(self) -> None:
        """Diff of identical dicts should be empty."""
        data = {"a": 1, "b": "test"}
        assert compute_diff(data, data) == {}

    def test_simple_value_change(self) -> None:
        """Should detect value changes in top-level keys."""
        old = {"a": 1}
        new = {"a": 2}

        expected = {"a": {"old": 1, "new": 2}}
        assert compute_diff(old, new) == expected

    def test_partial_change(self) -> None:
        """Should only return changed fields."""
        old = {"a": 1, "b": 2}
        new = {"a": 1, "b": 3}

        expected = {"b": {"old": 2, "new": 3}}
        assert compute_diff(old, new) == expected

    def test_nested_dict_treated_opaquely(self) -> None:
        """Nested dictionaries should be treated as opaque values."""
        # The RFC specifies: Nested dict: top-level key diff treats nested value as opaque
        old = {"config": {"enabled": True, "limit": 10}}
        new = {"config": {"enabled": False, "limit": 10}}

        expected = {
            "config": {
                "old": {"enabled": True, "limit": 10},
                "new": {"enabled": False, "limit": 10},
            }
        }
        assert compute_diff(old, new) == expected

    def test_list_field_change(self) -> None:
        """List fields should be diffed by value equality."""
        old = {"tags": ["a", "b"]}
        new = {"tags": ["a", "c"]}

        expected = {"tags": {"old": ["a", "b"], "new": ["a", "c"]}}
        assert compute_diff(old, new) == expected

    def test_default_exclusions(self) -> None:
        """Should exclude standard metadata fields by default."""
        old = {
            "id": "1",
            "creation": "2023-01-01",
            "modified": "2023-01-01",
            "modified_by": "user1",
            "title": "Old",
        }
        new = {
            "id": "1",
            "creation": "2023-01-01",
            "modified": "2023-01-02",  # Changed
            "modified_by": "user2",  # Changed
            "title": "New",  # Changed
        }

        # Only title should be in diff
        expected = {"title": {"old": "Old", "new": "New"}}
        assert compute_diff(old, new) == expected

    def test_custom_exclusions(self) -> None:
        """Should support custom field exclusions."""
        old = {"secret": "abc", "public": "123"}
        new = {"secret": "xyz", "public": "456"}

        # Exclude 'secret'
        diff = compute_diff(old, new, exclude={"secret"})

        assert "secret" not in diff
        assert "public" in diff

    def test_added_field(self) -> None:
        """Should handle added fields (old value None)."""
        old = {"a": 1}
        new = {"a": 1, "b": 2}

        expected = {"b": {"old": None, "new": 2}}
        assert compute_diff(old, new) == expected

    def test_removed_field(self) -> None:
        """Should handle removed fields (new value None)."""
        old = {"a": 1, "b": 2}
        new = {"a": 1}

        expected = {"b": {"old": 2, "new": None}}
        assert compute_diff(old, new) == expected

    def test_raises_type_error_for_non_dict(self) -> None:
        """Should raise TypeError if inputs are not dicts."""
        with pytest.raises(TypeError):
            compute_diff("not a dict", {})  # type: ignore

        with pytest.raises(TypeError):
            compute_diff({}, "not a dict")  # type: ignore
