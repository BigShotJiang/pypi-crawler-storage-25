"""Tests for the Schema Migration Engine."""

from framework_m_core.domain.migration_engine import (
    ChangeType,
    MigrationEngine,
    RiskLevel,
)
from framework_m_core.interfaces.introspection import ColumnMeta, TableMeta


class TestMigrationEngine:
    """Test suite for comparing desired and current schema states."""

    def test_safe_add_column(self) -> None:
        """Adding a new column should be categorized as a SAFE operation."""
        current = TableMeta(
            name="users",
            columns=[ColumnMeta(name="id", type="INTEGER", primary_key=True)],
        )
        desired = TableMeta(
            name="users",
            columns=[
                ColumnMeta(name="id", type="INTEGER", primary_key=True),
                ColumnMeta(name="email", type="VARCHAR", max_length=255),
            ],
        )

        engine = MigrationEngine(current, desired)
        diffs = engine.compare()

        assert len(diffs) == 1
        assert diffs[0].change_type == ChangeType.ADD_COLUMN
        assert diffs[0].risk == RiskLevel.SAFE
        assert diffs[0].column_name == "email"

    def test_warning_shrink_varchar(self) -> None:
        """Shrinking a VARCHAR length should be a WARNING due to potential data truncation."""
        current = TableMeta(
            name="users",
            columns=[ColumnMeta(name="username", type="VARCHAR", max_length=255)],
        )
        desired = TableMeta(
            name="users",
            columns=[ColumnMeta(name="username", type="VARCHAR", max_length=50)],
        )

        engine = MigrationEngine(current, desired)
        diffs = engine.compare()

        assert len(diffs) == 1
        assert diffs[0].change_type == ChangeType.ALTER_COLUMN
        assert diffs[0].risk == RiskLevel.WARNING
        assert diffs[0].column_name == "username"
        # The message should offer actionable advice
        assert "truncation" in diffs[0].message.lower()

    def test_breaking_drop_column(self) -> None:
        """Dropping a column should be a BREAKING change requiring ZDM backfill patterns."""
        current = TableMeta(
            name="users",
            columns=[
                ColumnMeta(name="id", type="INTEGER", primary_key=True),
                ColumnMeta(name="old_field", type="VARCHAR", max_length=255),
            ],
        )
        desired = TableMeta(
            name="users",
            columns=[ColumnMeta(name="id", type="INTEGER", primary_key=True)],
        )

        engine = MigrationEngine(current, desired)
        diffs = engine.compare()

        assert len(diffs) == 1
        assert diffs[0].change_type == ChangeType.DROP_COLUMN
        assert diffs[0].risk == RiskLevel.BREAKING
        assert diffs[0].column_name == "old_field"
