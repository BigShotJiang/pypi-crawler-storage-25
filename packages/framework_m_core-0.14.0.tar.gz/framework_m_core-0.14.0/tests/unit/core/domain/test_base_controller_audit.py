"""Tests for BaseController Auto-Audit Hook.

Tests that BaseController correctly calls the AuditLogProtocol
when managing DocTypes with AuditMixin.
"""

from unittest.mock import AsyncMock

import pytest
from framework_m_core import DocType
from framework_m_core.domain.base_controller import BaseController
from framework_m_core.domain.mixins import AuditMixin
from framework_m_core.interfaces.audit import AuditLogProtocol


# Dummy DocTypes for testing
class AuditedDoc(DocType, AuditMixin):
    """DocType with AuditMixin enabled."""

    title: str = "Test"


class NonAuditedDoc(DocType):
    """DocType without AuditMixin."""

    title: str = "Test"


class AuditedController(BaseController[AuditedDoc]):
    """Controller for AuditedDoc."""


@pytest.fixture
def mock_audit_adapter() -> AsyncMock:
    """Create a mock audit adapter."""
    return AsyncMock(spec=AuditLogProtocol)


TEST_UUID = "12345678-1234-5678-1234-567812345678"


@pytest.fixture
def audited_doc() -> AuditedDoc:
    """Create a sample audited document."""
    return AuditedDoc(title="New Value", id=TEST_UUID)


@pytest.mark.asyncio
async def test_after_insert_logs_create(
    mock_audit_adapter: AsyncMock, audited_doc: AuditedDoc
) -> None:
    """after_insert should log 'create' action for AuditMixin docs."""
    controller = AuditedController(audited_doc)
    controller._audit_adapter = mock_audit_adapter

    await controller.after_insert(context={"user_id": "user-1"})

    mock_audit_adapter.log.assert_called_once()
    args = mock_audit_adapter.log.call_args.kwargs
    assert args["action"] == "create"
    assert args["user_id"] == "user-1"
    assert args["doctype"] == "AuditedDoc"
    assert args["document_id"] == TEST_UUID
    assert args["changes"] is None


@pytest.mark.asyncio
async def test_update_logs_audit_entry_with_diff(
    mock_audit_adapter: AsyncMock, audited_doc: AuditedDoc
) -> None:
    """after_save should log 'update' with diff if snapshot exists."""
    controller = AuditedController(audited_doc)
    controller._audit_adapter = mock_audit_adapter

    # Simulate snapshot from before_save (state before modification)
    controller._pre_save_snapshot = audited_doc.model_dump()
    controller._pre_save_snapshot["title"] = "Old Value"

    await controller.after_save(context={"user_id": "user-1"})

    mock_audit_adapter.log.assert_called_once()
    args = mock_audit_adapter.log.call_args.kwargs
    assert args["action"] == "update"
    assert args["changes"] == {"title": {"old": "Old Value", "new": "New Value"}}


@pytest.mark.asyncio
async def test_non_audited_doctype_logs_nothing(
    mock_audit_adapter: AsyncMock,
) -> None:
    """Non-AuditMixin doctypes should not trigger audit logs."""
    doc = NonAuditedDoc(title="Test")
    controller = BaseController(doc)
    controller._audit_adapter = mock_audit_adapter

    await controller.after_insert(context={"user_id": "user-1"})
    await controller.before_save()
    await controller.after_save(context={"user_id": "user-1"})

    mock_audit_adapter.log.assert_not_called()


@pytest.mark.asyncio
async def test_empty_diff_logs_nothing(
    mock_audit_adapter: AsyncMock, audited_doc: AuditedDoc
) -> None:
    """If no changes detected, audit log should be skipped."""
    controller = AuditedController(audited_doc)
    controller._audit_adapter = mock_audit_adapter

    # Snapshot same as current
    controller._pre_save_snapshot = audited_doc.model_dump()

    await controller.after_save(context={"user_id": "user-1"})

    mock_audit_adapter.log.assert_not_called()


@pytest.mark.asyncio
async def test_before_save_captures_snapshot(audited_doc: AuditedDoc) -> None:
    """before_save should capture document state as snapshot."""
    controller = AuditedController(audited_doc)

    # Verify attribute doesn't exist or is None initially
    assert getattr(controller, "_pre_save_snapshot", None) is None

    await controller.before_save()

    assert controller._pre_save_snapshot is not None
    assert controller._pre_save_snapshot["title"] == "New Value"


@pytest.mark.asyncio
async def test_audit_failure_propagates(
    mock_audit_adapter: AsyncMock, audited_doc: AuditedDoc
) -> None:
    """Exceptions in audit logging should propagate (not be swallowed)."""
    controller = AuditedController(audited_doc)
    controller._audit_adapter = mock_audit_adapter
    mock_audit_adapter.log.side_effect = Exception("Audit system down")

    with pytest.raises(Exception, match="Audit system down"):
        await controller.after_insert(context={"user_id": "user-1"})


@pytest.mark.asyncio
async def test_job_id_propagation(
    mock_audit_adapter: AsyncMock, audited_doc: AuditedDoc
) -> None:
    """job_id from context should be forwarded to audit metadata."""
    controller = AuditedController(audited_doc)
    controller._audit_adapter = mock_audit_adapter

    context = {"user_id": "user-1", "job_id": "job-abc"}
    await controller.after_insert(context=context)

    mock_audit_adapter.log.assert_called_once()
    args = mock_audit_adapter.log.call_args.kwargs
    assert args["metadata"] is not None
    assert args["metadata"]["job_id"] == "job-abc"
