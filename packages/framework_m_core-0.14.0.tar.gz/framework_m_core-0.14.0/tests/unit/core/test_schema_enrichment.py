"""Tests for schema_enrichment.enrich_schema.

Covers:
- Literal fields: enum already inlined, ui_meta preserved
- Python Enum via $ref: enum inlined, ui_meta from sibling merged
- Validation constraints moved into ui_meta.validation
- Existing ui_meta.validation is never overwritten
- Fields with no special metadata pass through unchanged
- $defs not present — no crash
"""

from __future__ import annotations

from typing import Any

from framework_m_core.schema_enrichment import enrich_schema


def _schema(
    properties: dict[str, Any], defs: dict[str, Any] | None = None
) -> dict[str, Any]:
    s: dict[str, Any] = {"type": "object", "properties": properties}
    if defs:
        s["$defs"] = defs
    return s


# ---------------------------------------------------------------------------
# Literal fields
# ---------------------------------------------------------------------------


class TestLiteralFields:
    def test_enum_options_populated_from_literal(self) -> None:
        schema = _schema(
            {
                "status": {
                    "type": "string",
                    "enum": ["draft", "submitted", "cancelled"],
                    "default": "draft",
                    "title": "Status",
                }
            }
        )
        result = enrich_schema(schema)
        prop = result["properties"]["status"]

        assert prop["ui_meta"]["options"] == [
            {"value": "draft", "label": "Draft"},
            {"value": "submitted", "label": "Submitted"},
            {"value": "cancelled", "label": "Cancelled"},
        ]

    def test_existing_ui_meta_preserved_for_literal(self) -> None:
        schema = _schema(
            {
                "status": {
                    "type": "string",
                    "enum": ["draft", "active"],
                    "ui_meta": {"widget": "status_badge", "colors": {"draft": "gray"}},
                }
            }
        )
        result = enrich_schema(schema)
        prop = result["properties"]["status"]

        # widget and colors preserved
        assert prop["ui_meta"]["widget"] == "status_badge"
        assert prop["ui_meta"]["colors"] == {"draft": "gray"}
        # options added
        assert "options" in prop["ui_meta"]

    def test_existing_ui_meta_options_not_overwritten(self) -> None:
        """Developer-supplied options labels must not be clobbered."""
        custom_options = [
            {"value": "draft", "label": "In Progress"},
            {"value": "done", "label": "Completed"},
        ]
        schema = _schema(
            {
                "status": {
                    "type": "string",
                    "enum": ["draft", "done"],
                    "ui_meta": {"options": custom_options},
                }
            }
        )
        result = enrich_schema(schema)
        assert result["properties"]["status"]["ui_meta"]["options"] == custom_options


# ---------------------------------------------------------------------------
# Python Enum via $ref
# ---------------------------------------------------------------------------


class TestRefResolution:
    def test_enum_ref_resolved_and_inlined(self) -> None:
        schema = _schema(
            {
                "priority": {
                    "$ref": "#/$defs/PriorityEnum",
                    "default": "low",
                    "description": "Task priority",
                }
            },
            defs={
                "PriorityEnum": {
                    "type": "string",
                    "enum": ["low", "medium", "high"],
                    "title": "PriorityEnum",
                }
            },
        )
        result = enrich_schema(schema)
        prop = result["properties"]["priority"]

        # $ref removed
        assert "$ref" not in prop
        # enum inlined
        assert prop["enum"] == ["low", "medium", "high"]
        # sibling keys preserved
        assert prop["default"] == "low"
        assert prop["description"] == "Task priority"
        # options
        assert prop["ui_meta"]["options"] == [
            {"value": "low", "label": "Low"},
            {"value": "medium", "label": "Medium"},
            {"value": "high", "label": "High"},
        ]

    def test_ui_meta_from_sibling_merged_with_resolved_def(self) -> None:
        schema = _schema(
            {
                "status": {
                    "$ref": "#/$defs/StatusEnum",
                    "description": "Status",
                    "ui_meta": {"read_only_when": "doc.docstatus == 1"},
                }
            },
            defs={
                "StatusEnum": {
                    "type": "string",
                    "enum": ["draft", "active", "closed"],
                }
            },
        )
        result = enrich_schema(schema)
        prop = result["properties"]["status"]

        # Both sibling ui_meta and enum values present
        assert prop["ui_meta"]["read_only_when"] == "doc.docstatus == 1"
        assert len(prop["ui_meta"]["options"]) == 3

    def test_missing_ref_def_does_not_crash(self) -> None:
        schema = _schema({"foo": {"$ref": "#/$defs/NonExistent"}})
        result = enrich_schema(schema)
        # $ref removed, property is empty dict with empty ui_meta
        assert "$ref" not in result["properties"]["foo"]
        assert "ui_meta" in result["properties"]["foo"]

    def test_no_defs_section_does_not_crash(self) -> None:
        schema = _schema({"name": {"type": "string", "title": "Name"}})
        result = enrich_schema(schema)
        assert result["properties"]["name"]["type"] == "string"


# ---------------------------------------------------------------------------
# Validation constraints
# ---------------------------------------------------------------------------


class TestValidationConstraints:
    def test_numeric_constraints_moved_to_ui_meta(self) -> None:
        schema = _schema(
            {
                "score": {
                    "type": "number",
                    "minimum": 0,
                    "maximum": 100,
                    "multipleOf": 5,
                    "title": "Score",
                }
            }
        )
        result = enrich_schema(schema)
        validation = result["properties"]["score"]["ui_meta"]["validation"]

        assert validation["minimum"] == 0
        assert validation["maximum"] == 100
        assert validation["multipleOf"] == 5

    def test_string_constraints_moved_to_ui_meta(self) -> None:
        schema = _schema(
            {
                "code": {
                    "type": "string",
                    "pattern": r"^[A-Z]{3}-\d{4}$",
                    "minLength": 8,
                    "maxLength": 8,
                }
            }
        )
        result = enrich_schema(schema)
        validation = result["properties"]["code"]["ui_meta"]["validation"]

        assert validation["pattern"] == r"^[A-Z]{3}-\d{4}$"
        assert validation["minLength"] == 8
        assert validation["maxLength"] == 8

    def test_array_constraints_moved_to_ui_meta(self) -> None:
        schema = _schema(
            {
                "tags": {
                    "type": "array",
                    "minItems": 1,
                    "maxItems": 10,
                }
            }
        )
        result = enrich_schema(schema)
        validation = result["properties"]["tags"]["ui_meta"]["validation"]

        assert validation["minItems"] == 1
        assert validation["maxItems"] == 10

    def test_existing_validation_not_overwritten(self) -> None:
        """Developer-supplied ui_meta.validation values must survive enrichment."""
        schema = _schema(
            {
                "age": {
                    "type": "integer",
                    "minimum": 0,
                    "maximum": 150,
                    "ui_meta": {
                        "validation": {"minimum": 18}  # developer override
                    },
                }
            }
        )
        result = enrich_schema(schema)
        validation = result["properties"]["age"]["ui_meta"]["validation"]

        # The developer's minimum=18 is NOT overwritten by the schema's 0
        assert validation["minimum"] == 18
        # But maximum (not overridden) is populated
        assert validation["maximum"] == 150

    def test_no_constraints_no_validation_key(self) -> None:
        schema = _schema({"name": {"type": "string", "title": "Name"}})
        result = enrich_schema(schema)
        # No validation constraints → ui_meta has no "validation" key
        assert "validation" not in result["properties"]["name"]["ui_meta"]


# ---------------------------------------------------------------------------
# Schema integrity
# ---------------------------------------------------------------------------


class TestSchemaIntegrity:
    def test_original_schema_not_mutated(self) -> None:
        original = _schema({"status": {"type": "string", "enum": ["a", "b"]}})
        import copy

        original_copy = copy.deepcopy(original)
        enrich_schema(original)
        assert original == original_copy

    def test_non_property_schema_keys_preserved(self) -> None:
        schema = {
            "type": "object",
            "title": "Invoice",
            "required": ["name"],
            "properties": {"name": {"type": "string"}},
        }
        result = enrich_schema(schema)
        assert result["title"] == "Invoice"
        assert result["required"] == ["name"]

    def test_fields_without_enum_get_no_options(self) -> None:
        schema = _schema({"description": {"type": "string", "title": "Description"}})
        result = enrich_schema(schema)
        assert "options" not in result["properties"]["description"]["ui_meta"]
