# Framework M Core

[![PyPI version](https://badge.fury.io/py/framework-m-core.svg)](https://badge.fury.io/py/framework-m-core)
[![Python 3.12+](https://img.shields.io/badge/python-3.12+-blue.svg)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)
[![GitLab Pipeline Status](https://gitlab.com/castlecraft/framework-m/badges/main/pipeline.svg)](https://gitlab.com/castlecraft/framework-m/-/pipelines)

Core protocols and foundation for Framework M.

## Overview

Framework M Core provides the essential primitives and architectural patterns used throughout the framework:

- **Protocol Interfaces (Ports)**: Standardized interfaces for repositories, events, storage, and more.
- **Domain Base Classes**: BaseDocType, BaseController, and essential mixins.
- **Dependency Injection**: A robust DI container for clean, testable code.
- **CLI Kernel**: The core command-line framework built on Cyclopts.

For detailed interface documentation, please refer to the official [Framework M API Docs](https://www.frameworkm.dev/api).

### Dependency Injection

Built on `dependency-injector` for clean, testable code:

```python
from framework_m_core.container import Container

container = Container()
container.wire(modules=["my_app.services"])
```

### CLI Framework

Built on `cyclopts` for powerful command-line interfaces:

```python
from framework_m_core.cli import app

@app.command
def my_command():
    """My custom command."""
    pass
```

## Usage

This package is typically used as a dependency of `framework-m` or `framework-m-standard`. 
For most applications, install the full `framework-m` package instead.

## License

Apache 2.0 License - see [LICENSE](https://gitlab.com/castlecraft/framework-m/blob/main/LICENSE) for details.
