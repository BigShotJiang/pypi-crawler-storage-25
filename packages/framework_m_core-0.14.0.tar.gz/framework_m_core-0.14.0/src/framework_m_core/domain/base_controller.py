"""Base Controller - Lifecycle hooks for document operations.

This module defines the BaseController class that provides
lifecycle hooks for document operations like insert, save, delete.

Controllers are separate from DocTypes to maintain clean separation
between data models and business logic.
"""

from typing import TYPE_CHECKING, Any

from framework_m_core.domain.base_doctype import BaseDocType

if TYPE_CHECKING:
    from framework_m_core.interfaces.audit import AuditLogProtocol


class BaseController[T: BaseDocType]:
    """
    Base controller providing lifecycle hooks for DocType operations.

    Controllers handle business logic and side effects during document
    lifecycle events. Override hook methods in subclasses.

    All hooks receive an optional context parameter for passing request
    context (user info, request ID, etc.) without global state.

    Example:
        class TodoController(BaseController[Todo]):
            async def validate(self, context: Any = None) -> None:
                if not self.doc.title.strip():
                    raise ValueError("Title cannot be empty")

            async def after_insert(self, context: Any = None) -> None:
                # Access user from context instead of global state
                user_id = context.get("user_id") if context else None
                await notify_user(user_id, "New todo created")
    """

    def __init__(self, doc: T) -> None:
        """
        Initialize controller with a document.

        Args:
            doc: The document instance this controller manages
        """
        self.doc = doc
        self._pre_save_snapshot: dict[str, Any] | None = None
        self._audit_adapter: AuditLogProtocol | None = None

    async def validate(self, context: Any = None) -> None:
        """
        Validate document before any save operation.

        Called before insert and update. Raise exceptions for validation errors.

        Args:
            context: Optional context (user info, request metadata, etc.)
        """

    async def before_insert(self, context: Any = None) -> None:
        """
        Hook called before inserting a new document.

        Use for setting defaults, generating values, etc.

        Args:
            context: Optional context (user info, request metadata, etc.)
        """

    async def after_insert(self, context: Any = None) -> None:
        """
        Hook called after successfully inserting a new document.

        Use for side effects like notifications, logging, etc.

        Args:
            context: Optional context (user info, request metadata, etc.)
        """
        from framework_m_core.domain.mixins import AuditMixin

        if self._audit_adapter and isinstance(self.doc, AuditMixin):
            user_id = self._get_user_id(context)
            metadata = self._get_audit_metadata(context)

            # Prefer human-readable name if available, else UUID
            doc_id = getattr(self.doc, "name", None) or str(self.doc.id)

            await self._audit_adapter.log(
                user_id=user_id,
                action="create",
                doctype=self.doc.get_doctype_name(),
                document_id=doc_id,
                changes=None,
                metadata=metadata,
            )

    async def after_naming(self, context: Any = None) -> None:
        """
        Hook called after the document has been named and inserted.

        This guarantees that self.doc.name is set to the final value.

        Args:
            context: Optional context (user info, request metadata, etc.)
        """

    async def before_save(self, context: Any = None) -> None:
        """
        Hook called before saving (insert or update).

        Called after validate, before database write.

        Args:
            context: Optional context (user info, request metadata, etc.)
        """
        from framework_m_core.domain.mixins import AuditMixin

        if isinstance(self.doc, AuditMixin) and self._pre_save_snapshot is None:
            self._pre_save_snapshot = self.doc.model_dump()

    async def after_save(self, context: Any = None) -> None:
        """
        Hook called after successfully saving a document.

        Use for cache invalidation, event publishing, etc.

        Args:
            context: Optional context (user info, request metadata, etc.)
        """
        from framework_m_core.domain.diff import compute_diff
        from framework_m_core.domain.mixins import AuditMixin

        try:
            if (
                self._audit_adapter
                and isinstance(self.doc, AuditMixin)
                and self._pre_save_snapshot
            ):
                current_state = self.doc.model_dump()
                diff = compute_diff(self._pre_save_snapshot, current_state)

                if diff:
                    user_id = self._get_user_id(context)
                    metadata = self._get_audit_metadata(context)
                    doc_id = getattr(self.doc, "name", None) or str(self.doc.id)

                    await self._audit_adapter.log(
                        user_id=user_id,
                        action="update",
                        doctype=self.doc.get_doctype_name(),
                        document_id=doc_id,
                        changes=diff,
                        metadata=metadata,
                    )
        finally:
            # Always reset snapshot so each save cycle starts fresh.
            self._pre_save_snapshot = None

    async def before_delete(self, context: Any = None) -> None:
        """
        Hook called before deleting a document.

        Use for validation, preventing deletion of linked docs, etc.

        Args:
            context: Optional context (user info, request metadata, etc.)
        """

    async def after_delete(self, context: Any = None) -> None:
        """
        Hook called after successfully deleting a document.

        Use for cleanup, cascade operations, etc.

        Args:
            context: Optional context (user info, request metadata, etc.)
        """

    async def on_submit(self, context: Any = None) -> None:
        """
        Hook called when a submittable document is submitted.

        Only applies to DocTypes with SubmittableMixin.

        Args:
            context: Optional context (user info, request metadata, etc.)
        """
        from framework_m_core.domain.mixins import AuditMixin

        if self._audit_adapter and isinstance(self.doc, AuditMixin):
            user_id = self._get_user_id(context)
            metadata = self._get_audit_metadata(context)
            doc_id = getattr(self.doc, "name", None) or str(self.doc.id)

            await self._audit_adapter.log(
                user_id=user_id,
                action="submit",
                doctype=self.doc.get_doctype_name(),
                document_id=doc_id,
                changes=None,
                metadata=metadata,
            )

    async def on_cancel(self, context: Any = None) -> None:
        """
        Hook called when a submittable document is cancelled.

        Only applies to DocTypes with SubmittableMixin.

        Args:
            context: Optional context (user info, request metadata, etc.)
        """
        from framework_m_core.domain.mixins import AuditMixin

        if self._audit_adapter and isinstance(self.doc, AuditMixin):
            user_id = self._get_user_id(context)
            metadata = self._get_audit_metadata(context)
            doc_id = getattr(self.doc, "name", None) or str(self.doc.id)

            await self._audit_adapter.log(
                user_id=user_id,
                action="cancel",
                doctype=self.doc.get_doctype_name(),
                document_id=doc_id,
                changes=None,
                metadata=metadata,
            )

    # =========================================================================
    # Permission Convenience Methods (Indie Mode)
    # =========================================================================

    async def check_permission(
        self,
        action: str,
        doc_id: str | None = None,
    ) -> bool:
        """Check if current user has permission for an action.

        Simple helper that builds PolicyEvaluateRequest internally.
        Returns bool instead of raising - use require_permission() to raise.

        Requires the controller to have:
        - `user: UserContext` attribute
        - `doctype_name: str` attribute
        - `permission: PermissionProtocol` attribute (injected via DI)

        Args:
            action: Action to check (read, write, create, delete)
            doc_id: Optional document ID for resource-level checks

        Returns:
            True if authorized, False otherwise

        Example:
            if await self.check_permission("write"):
                # User can write
                ...
        """
        from framework_m_core.interfaces.permission import PolicyEvaluateRequest

        user = getattr(self, "user", None)
        doctype_name = getattr(self, "doctype_name", None)
        permission = getattr(self, "permission", None)

        if user is None or doctype_name is None or permission is None:
            return False

        request = PolicyEvaluateRequest(
            principal=user.id,
            action=action,
            resource=doctype_name,
            resource_id=doc_id,
            principal_attributes={
                "roles": user.roles,
                "tenants": user.tenants,
                "teams": user.teams,
                "is_system_user": user.is_system_user,
            },
        )

        result = await permission.evaluate(request)
        return bool(result.authorized)

    async def require_permission(
        self,
        action: str,
        doc_id: str | None = None,
    ) -> None:
        """Require that user has permission for an action, raising if not.

        Similar to check_permission() but raises PermissionDeniedError
        instead of returning False.

        Args:
            action: Action to check (read, write, create, delete)
            doc_id: Optional document ID for resource-level checks

        Raises:
            PermissionDeniedError: If user is not authorized

        Example:
            await self.require_permission("write")
            # If we get here, user is authorized
        """
        from framework_m_core.exceptions import PermissionDeniedError

        authorized = await self.check_permission(action, doc_id)
        if not authorized:
            user_id = getattr(getattr(self, "user", None), "id", "unknown")
            doctype_name = getattr(self, "doctype_name", "unknown")
            raise PermissionDeniedError(
                f"User '{user_id}' does not have '{action}' permission on '{doctype_name}'"
            )

    # =========================================================================
    # Submitted Document Validation (Field-Level Mutability)
    # =========================================================================

    def _get_dirty_fields(self, new_doc: T, existing_doc: T) -> set[str]:
        """Get set of field names that have changed between documents.

        Compares new_doc and existing_doc to detect which fields were modified.

        Args:
            new_doc: The new/updated document
            existing_doc: The existing document from database

        Returns:
            Set of field names that have different values
        """
        dirty_fields: set[str] = set()

        # Get all field names from the model
        for field_name in type(new_doc).model_fields:
            old_value = getattr(existing_doc, field_name, None)
            new_value = getattr(new_doc, field_name, None)

            if old_value != new_value:
                dirty_fields.add(field_name)

        return dirty_fields

    async def _validate_submitted_changes(self, new_doc: T, existing_doc: T) -> None:
        """Validate changes to a submitted document.

        Submitted documents are strictly immutable. Only `docstatus` can be changed
        (e.g., to CANCELLED). Any other change will raise ImmutableDocumentError.

        Args:
            new_doc: The new/updated document
            existing_doc: The existing submitted document

        Raises:
            ImmutableDocumentError: If attempting to modify any field
        """
        from framework_m_core.domain.mixins import DocStatus
        from framework_m_core.exceptions import ImmutableDocumentError

        # Only validate if existing document is submitted
        if not hasattr(existing_doc, "docstatus"):
            return

        if existing_doc.docstatus != DocStatus.SUBMITTED:
            return

        # Get fields that changed
        dirty_fields = self._get_dirty_fields(new_doc, existing_doc)

        # Remove docstatus from dirty fields (allowed to change for cancellation)
        dirty_fields.discard("docstatus")

        if dirty_fields:
            first_field = next(iter(dirty_fields))
            doc_id = getattr(new_doc, "name", None) or getattr(new_doc, "id", None)
            raise ImmutableDocumentError(
                doctype_name=type(new_doc).__name__,
                field_name=first_field,
                doc_id=str(doc_id) if doc_id else None,
            )

    # =========================================================================
    # Internal Helpers
    # =========================================================================

    def _get_user_id(self, context: Any) -> str:
        """Extract user_id from context or self.user."""
        if isinstance(context, dict) and "user_id" in context:
            return str(context["user_id"])
        if hasattr(self, "user") and hasattr(self.user, "id"):
            return str(self.user.id)
        return "system"

    def _get_audit_metadata(self, context: Any) -> dict[str, Any] | None:
        """Extract metadata for audit log from context."""
        if not isinstance(context, dict):
            return None

        metadata = {}
        if "job_id" in context:
            metadata["job_id"] = context["job_id"]
        return metadata if metadata else None


__all__ = ["BaseController"]
