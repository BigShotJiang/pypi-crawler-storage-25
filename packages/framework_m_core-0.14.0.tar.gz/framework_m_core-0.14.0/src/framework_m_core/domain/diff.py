"""JSON Diff Utility.

Calculates changes between two dictionary states for audit logging.
"""

from typing import Any


def compute_diff(
    old: dict[str, Any],
    new: dict[str, Any],
    exclude: set[str] | None = None,
) -> dict[str, Any]:
    """
    Compute the difference between two dictionaries.

    Args:
        old: The original dictionary state.
        new: The new dictionary state.
        exclude: Set of keys to exclude from diff (e.g. metadata).
            Defaults to {"id", "creation", "modified", "modified_by"}.

    Returns:
        A dictionary containing changed fields:
        {
            "field": {"old": val, "new": val},
            ...
        }

    Raises:
        TypeError: If old or new are not dictionaries.
    """
    if not isinstance(old, dict) or not isinstance(new, dict):
        raise TypeError("Old and new states must be dictionaries.")

    if exclude is None:
        exclude = {"id", "creation", "modified", "modified_by"}

    diff: dict[str, Any] = {}
    all_keys = set(old.keys()) | set(new.keys())

    for key in all_keys:
        if key in exclude:
            continue

        old_val = old.get(key)
        new_val = new.get(key)

        if old_val != new_val:
            diff[key] = {"old": old_val, "new": new_val}

    return diff
