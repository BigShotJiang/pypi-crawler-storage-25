"""Base DocType - Foundation class for all document types."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any, ClassVar
from uuid import UUID, uuid4

from pydantic import BaseModel, ConfigDict, Field, field_validator

from framework_m_core.domain.meta import DocTypeMetaConfig


def _utc_now() -> datetime:
    """Return current UTC time as timezone-aware datetime."""
    return datetime.now(UTC)


class BaseDocType(BaseModel):
    """
    Base class for all DocTypes in Framework M.

    Provides standard fields and configuration for metadata-driven documents.
    All custom DocTypes should inherit from this class.

    Example:
        class Todo(BaseDocType):
            title: str = Field(description="Task title")
            is_completed: bool = False

        class Invoice(BaseDocType):
            customer: str
            total: float = 0.0

            class Meta:
                ui_meta = {"form": {"sections": [{"fields": ["customer", "total"]}]}}
                permissions = {"read": ["Accountant"]}
    """

    model_config = ConfigDict(
        populate_by_name=True,
        validate_assignment=True,
        extra="forbid",
        str_strip_whitespace=True,
    )

    # Standard fields for all DocTypes
    id: UUID = Field(
        default_factory=uuid4, description="Primary key (UUID), auto-generated"
    )
    name: str | None = Field(
        default=None,
        description="Human-readable unique identifier, auto-generated if None",
    )
    creation: datetime = Field(
        default_factory=_utc_now, description="Document creation timestamp"
    )
    modified: datetime = Field(
        default_factory=_utc_now, description="Last modification timestamp"
    )
    modified_by: str | None = Field(
        default=None, description="User who last modified the document"
    )
    owner: str | None = Field(default=None, description="User who created the document")
    deleted_at: datetime | None = Field(
        default=None, description="Soft delete timestamp, None if not deleted"
    )

    # Class-level metadata (not serialized)
    _doctype_name: ClassVar[str | None] = None
    _meta_config: ClassVar[DocTypeMetaConfig]

    @classmethod
    def __init_subclass__(cls, **kwargs: Any) -> None:
        """Hook into subclass creation to validate reserved fields."""
        super().__init_subclass__(**kwargs)

        # Prevent developers from manually defining custom_fields
        if "custom_fields" in cls.__annotations__ or "custom_fields" in cls.__dict__:
            raise ValueError(
                "Reserved field name 'custom_fields' cannot be manually declared."
            )

        # Prevent overriding of system fields
        # We allow type narrowing in annotations, but forbid redefining defaults
        reserved_fields = {
            "id",
            "creation",
            "modified",
            "modified_by",
            "owner",
            "deleted_at",
        }
        for field in reserved_fields:
            if field in cls.__dict__:
                raise ValueError(f"Cannot override reserved system field '{field}'.")

        # Validate and parse Meta class if present
        meta_obj = getattr(cls, "Meta", None)
        meta_attrs = {}
        if meta_obj is not None:
            meta_attrs = {
                k: v for k, v in meta_obj.__dict__.items() if not k.startswith("__")
            }

        # Validate using Pydantic model (will raise ValidationError immediately if invalid)
        cls._meta_config = DocTypeMetaConfig(**meta_attrs)

    @field_validator("id", mode="before")
    @classmethod
    def parse_id(cls, v: UUID | str) -> UUID:
        """Convert string UUID to UUID object for database compatibility."""
        if isinstance(v, UUID):
            return v
        if isinstance(v, str):
            return UUID(v)
        return v

    @field_validator("creation", "modified", "deleted_at", mode="before")
    @classmethod
    def parse_datetime(cls, v: datetime | str | None) -> datetime | None:
        """Convert string datetime to datetime object for database compatibility."""
        if v is None or isinstance(v, datetime):
            return v
        if isinstance(v, str):
            # Handle ISO format with or without timezone
            return datetime.fromisoformat(v.replace("Z", "+00:00"))
        return v

    @classmethod
    def get_doctype_name(cls) -> str:
        """
        Get the DocType name for this class.

        Returns the class name by default, but can be overridden
        via the _doctype_name class variable.
        """
        return cls._doctype_name or cls.__name__

    @classmethod
    def get_permissions(cls) -> dict[str, list[str]]:
        """
        Get the permissions configuration from the Meta class.

        Returns:
            Permissions dict for RBAC mapping actions to roles, or empty dict if not defined.
        """
        return cls._meta_config.permissions

    @classmethod
    def get_requires_auth(cls) -> bool:
        """
        Check if this DocType requires authentication for access.

        Returns:
            True if auth is required (default), False for public DocTypes.

        Example:
            class PublicConfig(BaseDocType):
                class Meta:
                    requires_auth = False  # Public access
        """
        return cls._meta_config.requires_auth

    @classmethod
    def get_apply_rls(cls) -> bool:
        """
        Check if Row-Level Security should be applied to this DocType.

        When True, users only see documents they own (or have explicit access to).
        When False, all authorized users see all documents.

        Returns:
            True if RLS is applied (default), False for shared tables.

        Example:
            class Country(BaseDocType):
                class Meta:
                    apply_rls = False  # Everyone sees all countries
        """
        return cls._meta_config.apply_rls

    @classmethod
    def get_rls_field(cls) -> str:
        """
        Get the field used for Row-Level Security filtering.

        By default, RLS filters by 'owner'. Override this to enable
        team-based or custom field-based RLS.

        Returns:
            The field name used for RLS filtering.

        Example:
            class TeamDocument(BaseDocType):
                team: str

                class Meta:
                    rls_field = "team"  # RLS: WHERE team IN :user_teams
        """
        return cls._meta_config.rls_field

    @classmethod
    def get_api_resource(cls) -> bool:
        """
        Check if this DocType should have auto-generated CRUD API endpoints.

        When True, the meta router will generate standard REST endpoints:
        - GET /api/v1/{doctype} - List
        - POST /api/v1/{doctype} - Create
        - GET /api/v1/{doctype}/{id} - Read
        - PUT /api/v1/{doctype}/{id} - Update
        - DELETE /api/v1/{doctype}/{id} - Delete

        Returns:
            True if CRUD endpoints should be generated, False otherwise (default).

        Example:
            class Invoice(BaseDocType):
                class Meta:
                    api_resource = True  # Enable auto-CRUD endpoints
        """
        return cls._meta_config.api_resource

    @classmethod
    def get_is_child_table(cls) -> bool:
        """
        Check if this DocType is a child table (embedded in parent).

        Child tables:
        - Inherit parent's RLS (no independent permission checks)
        - Are not exposed as API resources
        - Are loaded with their parent (no separate queries)
        - Have parent_doctype and parent_id fields for linking

        Returns:
            True if this is a child table, False otherwise (default).

        Example:
            class InvoiceItem(BaseDocType):
                class Meta:
                    is_child_table = True  # Mark as child table
        """
        return cls._meta_config.is_child_table

    @classmethod
    def get_show_in_desk(cls) -> bool:
        """
        Check if this DocType should be visible in the Desk UI sidebar.

        When False, the DocType is hidden from navigation menus and lists.
        Useful for internal/system DocTypes that users shouldn't interact with directly.

        Returns:
            True if should be shown in Desk (default), False to hide.

        Example:
            class JobLog(BaseDocType):
                class Meta:
                    api_resource = True  # Has API
                    show_in_desk = False  # But hidden from UI
        """
        return cls._meta_config.show_in_desk

    @classmethod
    def get_ui_meta(cls) -> dict[str, Any]:
        """
        Get the unified UI metadata from the Meta class.

        UIMeta encapsulates frontend configuration:
        - ``form``: Layout, sections, tabs
        - ``list``: Columns, sorting, row styling
        - ``additional_views``: Kanban, Tree, Calendar configs

        Returns:
            UIMeta dict, or empty dict if not defined.

        Example:
            class Invoice(BaseDocType):
                class Meta:
                    ui_meta = {
                        "form": {"sections": [...]},
                        "list": {"columns": [...]},
                        "additional_views": {"kanban": {"group_field": "status"}}
                    }
        """
        if not cls._meta_config.ui_meta:
            return {}
        return cls._meta_config.ui_meta.model_dump(exclude_none=True)

    @classmethod
    def get_custom_meta_namespaces(cls) -> dict[str, dict[str, Any]]:
        """
        Get custom plugin metadata namespaces from the Meta class.

        Plugins can define arbitrary metadata blocks on Meta (e.g.
        ``wms_meta``, ``mobile_meta``) that are passed through to the
        frontend via ``/api/meta``.

        Returns:
            Dict of namespace_name → metadata dict.

        Example:
            class PickList(BaseDocType):
                class Meta:
                    wms_meta = {"scanner_mode": "barcode", "auto_submit": True}
                    mobile_meta = {"offline_capable": True}
        """
        if not cls._meta_config.model_extra:
            return {}

        namespaces: dict[str, dict[str, Any]] = {}
        for attr_name, value in cls._meta_config.model_extra.items():
            if attr_name.endswith("_meta") and isinstance(value, dict):
                namespaces[attr_name] = value
        return namespaces

    @classmethod
    def get_indexes(cls) -> list[dict[str, Any]]:
        """
        Get custom indexes defined for this DocType.

        Define indexes in Meta.indexes as a list of dicts with 'fields' key.
        Supports single-column and composite (multi-column) indexes.

        Returns:
            List of index specifications as dictionaries.

        Example:
            class Product(BaseDocType):
                category: str
                status: str

                class Meta:
                    indexes = [
                        {"fields": ["category"]},  # Single column
                        {"fields": ["status", "category"]},  # Composite
                    ]
        """
        return [
            idx.model_dump(exclude_none=True, exclude_defaults=True)
            for idx in cls._meta_config.indexes
        ]

    @classmethod
    def get_is_singleton(cls) -> bool:
        """Check if this DocType is a singleton (Single)."""
        return cls._meta_config.is_singleton

    @classmethod
    def get_meta_flags(cls) -> dict[str, bool | str | int | float]:
        """
        Get all simple configuration flags from the Meta class.

        Iterates through the Meta class attributes and returns those
        that are of simple types (bool, str, int, float). This is used
        by the discovery API to expose and filter metadata.

        Returns:
            Dictionary of flag_name → value.
        """
        flags: dict[str, Any] = {}
        # Safely extract strictly typed flags
        for attr, value in cls._meta_config.model_dump().items():
            if isinstance(value, (bool, str, int, float)) and attr != "table_name":
                flags[attr] = value

        # Include dynamic/custom plugin flags from model_extra
        if cls._meta_config.model_extra:
            for attr, value in cls._meta_config.model_extra.items():
                if isinstance(value, (bool, str, int, float)):
                    flags[attr] = value

        return flags

    @classmethod
    def get_correction_strategy(cls) -> str | None:
        """Get correction strategy from Meta configuration if provided."""
        return cls._meta_config.correction_strategy

    @classmethod
    def get_is_aggregate_root(cls) -> bool:
        """
        Check if this DocType is an aggregate root.

        Returns:
            True if it's an aggregate root, False otherwise.
        """
        return cls._meta_config.is_aggregate_root

    @classmethod
    def get_aggregate_children(cls) -> list[str]:
        """
        Get the list of child DocTypes belonging to this aggregate root.
        """
        return cls._meta_config.aggregate_children


# Re-export Field for convenience
__all__ = ["BaseDocType", "Field"]
