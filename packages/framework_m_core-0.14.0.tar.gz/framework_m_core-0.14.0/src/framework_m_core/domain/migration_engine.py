"""Schema Migration Engine.

Domain logic for comparing desired schema (from code) against the current
database schema (from introspection) and categorizing the risk of changes.
"""

from enum import Enum

from pydantic import BaseModel

from framework_m_core.interfaces.introspection import TableMeta


class ChangeType(Enum):
    """Types of schema changes."""

    ADD_COLUMN = "add_column"
    DROP_COLUMN = "drop_column"
    ALTER_COLUMN = "alter_column"


class RiskLevel(Enum):
    """Risk levels indicating the danger of a schema change."""

    SAFE = "safe"
    WARNING = "warning"
    BREAKING = "breaking"


class SchemaDiff(BaseModel):
    """Represents a single schema change and its associated risk."""

    change_type: ChangeType
    risk: RiskLevel
    column_name: str
    message: str


class MigrationEngine:
    """Compares current and desired schemas to generate risk-categorized diffs."""

    def __init__(self, current: TableMeta, desired: TableMeta) -> None:
        """Initialize the migration engine with current and desired states."""
        self.current = current
        self.desired = desired

    def compare(self) -> list[SchemaDiff]:
        """Compare the schemas and return a list of differences."""
        diffs: list[SchemaDiff] = []

        current_cols = {c.name: c for c in self.current.columns}
        desired_cols = {c.name: c for c in self.desired.columns}

        # 1. Check for added and altered columns
        for name, desired_col in desired_cols.items():
            if name not in current_cols:
                diffs.append(
                    SchemaDiff(
                        change_type=ChangeType.ADD_COLUMN,
                        risk=RiskLevel.SAFE,
                        column_name=name,
                        message=f"Adding new column '{name}'. This is a safe operation.",
                    )
                )
            else:
                current_col = current_cols[name]
                # Warning: Shrinking VARCHAR length
                if (
                    desired_col.type == "VARCHAR"
                    and current_col.type == "VARCHAR"
                    and desired_col.max_length is not None
                    and current_col.max_length is not None
                    and desired_col.max_length < current_col.max_length
                ):
                    diffs.append(
                        SchemaDiff(
                            change_type=ChangeType.ALTER_COLUMN,
                            risk=RiskLevel.WARNING,
                            column_name=name,
                            message=f"Shrinking VARCHAR length from {current_col.max_length} to {desired_col.max_length}. High risk of data truncation.",
                        )
                    )

        # 2. Check for dropped columns
        for name in current_cols:
            if name not in desired_cols:
                diffs.append(
                    SchemaDiff(
                        change_type=ChangeType.DROP_COLUMN,
                        risk=RiskLevel.BREAKING,
                        column_name=name,
                        message=f"Dropping column '{name}'. This is a breaking change requiring ZDM backfill patterns.",
                    )
                )

        return diffs
