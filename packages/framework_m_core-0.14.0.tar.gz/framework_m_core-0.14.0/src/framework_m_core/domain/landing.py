"""Landing Domain Models.

Contains models for defining and resolving application landing pages.
"""

from typing import Any

from pydantic import BaseModel, Field


class LandingDescriptor(BaseModel):
    """Represents a resolved landing page target.

    This descriptor tells the frontend exactly where to send the user
    upon successful login or home page navigation.
    """

    route: str = Field(description="The target frontend route or URL.")
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Optional context or parameters for the landing page.",
    )
