"""Metadata Schema Models.

Strict Pydantic models defining the expected structure of DocType Meta configurations
and UI representations. Ensures consistency across the Backend and Studio UI.
"""

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class UISection(BaseModel):
    """Defines a layout section containing fields."""

    label: str | None = None
    fields: list[str] = Field(default_factory=list)
    columns: int = Field(default=1, ge=1, le=3)
    collapsible: bool = False
    collapsed_by_default: bool = False

    model_config = ConfigDict(extra="allow")


class UITab(BaseModel):
    """Defines a layout tab containing sections."""

    label: str | None = None
    sections: list[UISection] = Field(default_factory=list)

    model_config = ConfigDict(extra="allow")


class UIFormLayout(BaseModel):
    """Defines the overall form layout structure (Tabs vs Scrolling Sections)."""

    layout: Literal["sections", "tabs"] = "sections"
    sections: list[UISection] | None = None
    tabs: list[UITab] | None = None

    model_config = ConfigDict(extra="allow")


class UIFieldMeta(BaseModel):
    """UI-specific metadata for a single field."""

    label: str | None = None
    hidden: bool = False
    read_only: bool = False
    options: list[dict[str, Any]] | None = None
    validation: dict[str, Any] | None = None

    model_config = ConfigDict(extra="allow")


class UIListColumn(BaseModel):
    """Column definition for list view."""

    field: str
    label: str | None = None
    width: int | str | None = None

    model_config = ConfigDict(extra="allow")


class UIListLayout(BaseModel):
    """Defines the list/table view configuration."""

    columns: list[UIListColumn] = Field(default_factory=list)
    sort_by: str | None = None
    sort_order: Literal["asc", "desc"] = "desc"

    model_config = ConfigDict(extra="allow")


class UIMeta(BaseModel):
    """Unified UI metadata configuration for a DocType."""

    form: UIFormLayout | None = None
    list: UIListLayout | None = None
    additional_views: dict[str, Any] | None = None
    fields: dict[str, UIFieldMeta] = Field(default_factory=dict)
    validation: dict[str, Any] | None = None
    options: dict[str, Any] | None = None

    model_config = ConfigDict(extra="allow")


class IndexDef(BaseModel):
    """Strict definition for a database index."""

    fields: list[str]
    unique: bool = False
    name: str | None = None

    model_config = ConfigDict(extra="allow")


class DocTypeMetaConfig(BaseModel):
    """Strict Pydantic schema for the overall DocType Meta configuration.

    Validates the `class Meta:` block on any BaseDocType.
    """

    api_resource: bool = False
    requires_auth: bool = True
    apply_rls: bool = True
    rls_field: str = "owner"
    is_child_table: bool = False
    is_singleton: bool = False
    show_in_desk: bool = False
    defaults_file: str | None = None
    is_submittable: bool = False
    id_strategy: Literal["random", "deterministic"] = "random"
    label: str | None = None
    module: str | None = None
    table_name: str | None = None
    permissions: dict[str, list[str]] = Field(default_factory=dict)
    indexes: list[IndexDef] = Field(default_factory=list)
    ui_meta: UIMeta | None = None
    correction_strategy: Literal["amend_only", "in_place"] | None = None
    is_aggregate_root: bool = False
    aggregate_children: list[str] = Field(default_factory=list)

    model_config = ConfigDict(extra="allow")
