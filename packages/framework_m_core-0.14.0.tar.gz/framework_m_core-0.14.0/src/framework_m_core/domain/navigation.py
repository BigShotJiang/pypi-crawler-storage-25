"""Navigation Domain Models.

Strict Pydantic models for the Navigation Manifest and Node Tree.
Used by the Navigation protocols (Context Port) and consumed by the UI (Fidelity Port).
"""

from __future__ import annotations

import re
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator


class VisibilityPolicy(BaseModel):
    """Defines who can see a specific navigation node."""

    roles: list[str] = Field(default_factory=list)
    attributes: dict[str, Any] = Field(default_factory=dict)
    feature_flag: str | None = None

    model_config = ConfigDict(extra="allow")


class NavigationNode(BaseModel):
    """A single node in the navigation tree.

    Supports multiple resource types, recursive children, and interactive
    extensions for specialized hardware (watches/kiosks).
    """

    name: str = Field(description="Unique identifier for the resource")
    label: str = Field(description="Display label for the navigation item")
    type: Literal["DocType", "Page", "Report", "Kiosk", "Link"] = "DocType"
    route: str = Field(description="The logical route (e.g., /wms/inventory)")
    icon: str | None = Field(
        default=None, description="Emoji or icon library identifier"
    )

    # SaaS & Protection
    feature_id: str | None = Field(
        default=None, description="Entitlement ID for SaaS plans"
    )
    visibility_policy: VisibilityPolicy | None = None

    # Interactive Extensions (Live State & Intents)
    badge: str | None = Field(
        default=None,
        description="Logical path to a badge query/status provider (e.g., wms.queries.picks)",
    )
    hardware_intent: str | None = Field(
        default=None,
        description="Logical mapping to physical button/interaction (e.g., sos, crown_click)",
    )
    interaction_mode: str | None = Field(
        default=None,
        description="Rendering hint for Fidelity Port (e.g., touch_optimized, rotary)",
    )

    # Hierarchy
    children: list[NavigationNode] = Field(default_factory=list)

    model_config = ConfigDict(extra="allow")

    @field_validator("badge")
    @classmethod
    def validate_badge_path(cls, v: str | None) -> str | None:
        if v is None:
            return v
        if not re.match(r"^[a-z0-9_]+(\.[a-z0-9_]+)*$", v):
            raise ValueError(
                "Badge must be a valid hierarchical topic path (lowercase, alphanumeric, dot-separated)."
            )
        return v

    @field_validator("route")
    @classmethod
    def validate_route_interpolation(cls, v: str) -> str:
        cleaned = re.sub(r"\{\{[^}]+\}\}", "", v)
        if "{" in cleaned or "}" in cleaned:
            raise ValueError(
                "Route contains mismatched or invalid interpolation brackets."
            )
        return v


class NavigationManifest(BaseModel):
    """A complete navigation structure for a specific Application module."""

    app_id: str = Field(description="Unique ID of the app (e.g., 'wms')")
    label: str = Field(description="Human-readable app name for the Rail")
    icon: str = Field(description="Icon used in the Primary Rail")
    resources: list[NavigationNode] = Field(
        default_factory=list, description="Top-level resource tree"
    )

    model_config = ConfigDict(extra="allow")


# Handle forward references for recursive children
NavigationNode.model_rebuild()

__all__ = ["NavigationNode", "NavigationManifest", "VisibilityPolicy"]
