"""Event handler wiring helpers for read model projections."""

from __future__ import annotations

from collections.abc import Awaitable, Callable, Sequence

from framework_m_core.interfaces.event_bus import Event, EventBusProtocol
from framework_m_core.interfaces.read_model import ReadModelProtocol


def create_read_model_handler(
    read_model: ReadModelProtocol,
    doctype_filter: Sequence[str] | None = None,
) -> Callable[[Event], Awaitable[None]]:
    """Create an event handler that projects events into a read model."""

    async def handler(event: Event) -> None:
        doctype = event.data.get("doctype") if event.data else None
        if doctype_filter is not None and doctype not in doctype_filter:
            return
        await read_model.project(event)

    return handler


async def subscribe_read_model_projector(
    event_bus: EventBusProtocol,
    read_model: ReadModelProtocol,
    event_patterns: Sequence[str] | None = None,
    doctype_filter: Sequence[str] | None = None,
) -> list[str]:
    """Subscribe a read-model projector handler to event bus patterns."""
    patterns = event_patterns or ["doc.*"]
    handler = create_read_model_handler(read_model, doctype_filter=doctype_filter)

    subscription_ids: list[str] = []
    for pattern in patterns:
        subscription_id = await event_bus.subscribe_pattern(pattern, handler)
        subscription_ids.append(subscription_id)

    return subscription_ids


async def unsubscribe_read_model_projector(
    event_bus: EventBusProtocol,
    subscription_ids: Sequence[str],
) -> None:
    """Unsubscribe previously-registered read-model projector handlers."""
    for subscription_id in subscription_ids:
        await event_bus.unsubscribe(subscription_id)


__all__ = [
    "create_read_model_handler",
    "subscribe_read_model_projector",
    "unsubscribe_read_model_projector",
]
