"""Landing Protocol - Core interface for landing page resolution.

This module defines the LandingProtocol for determining where a user
should be redirected after login or when navigating to the root URL.
"""

from typing import Protocol, runtime_checkable

from framework_m_core.domain.landing import LandingDescriptor
from framework_m_core.interfaces.auth_context import UserContext


@runtime_checkable
class LandingProtocol(Protocol):
    """Protocol defining the contract for landing page resolution."""

    async def resolve(self, context: UserContext) -> LandingDescriptor | None:
        """Resolve the landing page for the given user context.

        Args:
            context: The current authenticated user's context.

        Returns:
            A LandingDescriptor if resolved, or None to fall back to the next resolver.
        """
        ...
