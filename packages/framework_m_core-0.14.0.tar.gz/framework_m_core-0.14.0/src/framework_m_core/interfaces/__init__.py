"""Framework M Core - Interfaces Package."""

from framework_m_core.interfaces.base_doctype import BaseDocTypeProtocol
from framework_m_core.interfaces.bootstrap import BootstrapProtocol
from framework_m_core.interfaces.controller import BaseControllerProtocol
from framework_m_core.interfaces.feature_entitlement import FeatureEntitlementProtocol
from framework_m_core.interfaces.identity import (
    Credentials,
    IdentityProtocol,
    PasswordCredentials,
    Token,
)
from framework_m_core.interfaces.job_logger import JobLoggerProtocol
from framework_m_core.interfaces.navigation import NavigationProtocol
from framework_m_core.interfaces.print import Printable, PrintFormat, PrintProtocol
from framework_m_core.interfaces.read_model import ReadModelProtocol
from framework_m_core.interfaces.schema_mapper import SchemaMapperProtocol
from framework_m_core.interfaces.webhook import (
    WebhookDelivererProtocol,
    WebhookLoaderProtocol,
)

__all__ = [
    "BaseControllerProtocol",
    "BaseDocTypeProtocol",
    "BootstrapProtocol",
    "Credentials",
    "IdentityProtocol",
    "PasswordCredentials",
    "FeatureEntitlementProtocol",
    "NavigationProtocol",
    "SchemaMapperProtocol",
    "Token",
    "JobLoggerProtocol",
    "WebhookDelivererProtocol",
    "WebhookLoaderProtocol",
    "Printable",
    "PrintFormat",
    "PrintProtocol",
    "ReadModelProtocol",
]
