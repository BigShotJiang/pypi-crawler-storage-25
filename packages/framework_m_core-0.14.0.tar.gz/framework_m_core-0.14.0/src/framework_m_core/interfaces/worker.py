"""Worker and Activity Interfaces.

Defines the protocols for durable execution workers and the registry
for custom domain activities.
"""

from collections.abc import Callable
from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class WorkerProtocol(Protocol):
    """Protocol for a durable execution worker (e.g., Temporal)."""

    async def start(self) -> None:
        """Start the worker to begin polling for tasks."""
        ...

    async def stop(self) -> None:
        """Gracefully stop the worker."""
        ...


class ActivityRegistry:
    """Singleton registry for worker activities."""

    _instance: "ActivityRegistry | None" = None
    _activities: dict[str, Callable[..., Any]]

    def __new__(cls) -> "ActivityRegistry":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._activities = {}
        return cls._instance

    @classmethod
    def get_instance(cls) -> "ActivityRegistry":
        return cls()

    def register(self, name: str, func: Callable[..., Any]) -> None:
        """Register an activity function."""
        self._activities[name] = func

    def get_all(self) -> dict[str, Callable[..., Any]]:
        """Get all registered activities."""
        return self._activities.copy()

    def clear(self) -> None:
        """Clear all registered activities (primarily for testing)."""
        self._activities.clear()


def worker_activity(
    name: str | None = None,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Decorator to register a function as a worker activity."""

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        activity_name = name or func.__name__
        ActivityRegistry.get_instance().register(activity_name, func)
        return func

    return decorator
