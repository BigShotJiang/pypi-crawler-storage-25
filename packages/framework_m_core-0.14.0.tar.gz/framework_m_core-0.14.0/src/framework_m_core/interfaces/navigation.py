"""Navigation Protocol - Core interface for manifest resolution.

This module defines the NavigationProtocol for resolving and filtering
the shell/navigation structure based on user context.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from framework_m_core.domain.navigation import NavigationManifest
from framework_m_core.interfaces.auth_context import UserContext


@runtime_checkable
class NavigationProtocol(Protocol):
    """Protocol for resolving the navigation structure for an application.

    This acts as the Context Port for the navigation architecture.
    """

    async def get_navigation_manifest(
        self, user_context: UserContext
    ) -> NavigationManifest:
        """Resolve the navigation manifest for the given user."""
        ...
