"""Secret Management Protocols.

This module defines the interfaces for secrets management in Framework M.
It follows the hexagonal architecture pattern (Port).
"""

from __future__ import annotations

from typing import Protocol, TypeVar

T = TypeVar("T")


class SecretProtocol(Protocol):
    """Protocol for secrets retrieval (Port).

    Implementations (Adapters) should provide methods to fetch sensitive
    configuration data from various sources (Env, Vault, AWS, etc.).
    """

    def get_secret(self, key: str, default: str | None = None) -> str | None:
        """Retrieve a secret by its key.

        Args:
            key: The unique identifier for the secret.
            default: Value to return if the secret is not found.

        Returns:
            The secret value as a string, or the default value.
        """
        ...

    def list_required_secrets(self) -> list[str]:
        """Return a list of secret keys managed by this provider.

        Returns:
            List of secret keys.
        """
        ...


__all__ = ["SecretProtocol"]
