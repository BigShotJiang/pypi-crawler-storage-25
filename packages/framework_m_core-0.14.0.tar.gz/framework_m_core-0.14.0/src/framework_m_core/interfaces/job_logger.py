"""Job Logger Protocol - Interface for job execution logging."""

from typing import Any, Protocol

from framework_m_core.doctypes.job_log import JobLog


class JobLoggerProtocol(Protocol):
    """Protocol for job execution logging.

    Defines the interface for logging job status transitions.
    Implementations may store in memory, database, or external service.
    """

    async def log_enqueue(self, job_id: str, job_name: str) -> JobLog:
        """Log that a job was enqueued."""
        ...  # pragma: no cover

    async def log_start(self, job_id: str) -> JobLog | None:
        """Log that a job started executing."""
        ...  # pragma: no cover

    async def log_success(
        self, job_id: str, result: dict[str, Any] | None = None
    ) -> JobLog | None:
        """Log that a job completed successfully."""
        ...  # pragma: no cover

    async def log_failure(self, job_id: str, error: str) -> JobLog | None:
        """Log that a job failed."""
        ...  # pragma: no cover

    async def get_log(self, job_id: str) -> JobLog | None:
        """Get a job log by ID."""
        ...  # pragma: no cover


__all__ = [
    "JobLoggerProtocol",
]
