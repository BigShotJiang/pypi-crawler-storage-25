"""Schema Introspection Protocol.

Defines the interface for database schema introspection, allowing the core
migration engine to read the current state of a database without knowing
about the underlying infrastructure (SQLAlchemy, etc.).
"""

from typing import Any, Protocol

from pydantic import BaseModel, Field


class ColumnMeta(BaseModel):
    """Normalized metadata for a database column."""

    name: str
    type: str  # Standardized string, e.g., 'VARCHAR', 'INTEGER', 'JSON'
    nullable: bool = True
    primary_key: bool = False
    default: Any | None = None
    max_length: int | None = None


class IndexMeta(BaseModel):
    """Normalized metadata for a database index or constraint."""

    name: str
    columns: list[str]
    unique: bool = False


class TableMeta(BaseModel):
    """Normalized metadata for a database table."""

    name: str
    columns: list[ColumnMeta] = Field(default_factory=list)
    indexes: list[IndexMeta] = Field(default_factory=list)


class IntrospectionProtocol(Protocol):
    """Protocol for database schema introspection adapters."""

    async def introspect_table(self, table_name: str) -> TableMeta | None:
        """Introspect a single table and return its metadata if it exists."""
        ...

    async def introspect_database(self) -> list[TableMeta]:
        """Introspect all tables in the current database."""
        ...
