"""Webhook Protocol - Interfaces for webhook handling."""

from typing import Protocol

from framework_m_core.doctypes.webhook import Webhook
from framework_m_core.interfaces.event_bus import Event


class WebhookLoaderProtocol(Protocol):
    """Protocol for loading webhooks from storage."""

    async def load_active_webhooks(self) -> list[Webhook]:
        """Load all active webhooks."""
        ...  # pragma: no cover


class WebhookDelivererProtocol(Protocol):
    """Protocol for delivering webhooks."""

    async def deliver(self, webhook: Webhook, event: Event) -> None:
        """Deliver an event to a webhook endpoint."""
        ...  # pragma: no cover


__all__ = [
    "WebhookDelivererProtocol",
    "WebhookLoaderProtocol",
]
