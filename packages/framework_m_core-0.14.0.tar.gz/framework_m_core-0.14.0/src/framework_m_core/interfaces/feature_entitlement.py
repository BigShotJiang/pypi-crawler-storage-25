"""Feature Entitlement Protocol - Core interface for SaaS entitlements.

This module defines the FeatureEntitlementProtocol for resolving
which SaaS features are enabled for a given tenant.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class FeatureEntitlementProtocol(Protocol):
    """Protocol for SaaS feature entitlement checks.

    Governs the visibility of entire feature sets before user-level roles are checked.
    """

    async def is_feature_enabled(self, tenant_id: str, feature_id: str) -> bool:
        """Check if the tenant's subscription plan allows this feature."""
        ...
