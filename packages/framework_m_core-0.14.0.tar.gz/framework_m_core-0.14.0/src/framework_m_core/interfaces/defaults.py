"""Defaults Protocol - Core interface for system defaults.

This module defines the DefaultsProtocol for determining configuration
fallbacks when values are not explicitly set in the database.
"""

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class DefaultsProtocol(Protocol):
    """Protocol defining the contract for retrieving system defaults."""

    async def get(self, key: str, default: Any = None) -> Any:
        """Retrieve a specific default value by its key.

        Args:
            key: The configuration key to look up.
            default: The fallback value to return if the key is not found.

        Returns:
            The resolved default value, or the provided fallback.
        """
        ...

    async def get_all(self) -> dict[str, Any]:
        """Retrieve all currently configured defaults.

        Returns:
            A dictionary mapping configuration keys to their values.
        """
        ...
