"""Workflow Transition Definition DocType."""

from __future__ import annotations

from typing import ClassVar

from pydantic import Field

from framework_m_core.domain.base_doctype import BaseDocType


class WorkflowTransitionDefinition(BaseDocType):
    """A transition rule between two workflow states.

    This is a child table for the Workflow DocType.
    """

    __doctype_name__: ClassVar[str] = "WorkflowTransitionDefinition"

    from_state: str = Field(description="The source state of the transition.")
    to_state: str = Field(description="The target state of the transition.")
    action: str = Field(description="The action that triggers this transition.")
    allowed_roles: list[str] | None = Field(
        default_factory=list, description="Roles allowed to perform this transition."
    )
    condition: str | None = Field(
        None, description="Optional Python expression for conditional transitions"
    )
