"""Workflow State Definition - Child DocType for Workflow blueprints."""

from __future__ import annotations

from typing import ClassVar

from framework_m_core.domain.base_doctype import BaseDocType, Field


class WorkflowStateDefinition(BaseDocType):
    """A single state within a workflow blueprint.

    This is a child table for the Workflow DocType.

    Attributes:
        state_name: Name of the state (e.g., Draft, Approved)
        allow_edit: Role allowed to edit documents when in this state
        is_terminal: Whether this is a final state (no further transitions)
    """

    current_state: str = Field(description="Name of the state (e.g., Draft, Approved)")
    allow_edit: str | None = Field(
        default=None, description="Role allowed to edit in this state"
    )
    is_terminal: bool = Field(
        default=False, description="Whether this is a final state"
    )

    class Meta:
        is_child_table: ClassVar[bool] = True


__all__ = ["WorkflowStateDefinition"]
