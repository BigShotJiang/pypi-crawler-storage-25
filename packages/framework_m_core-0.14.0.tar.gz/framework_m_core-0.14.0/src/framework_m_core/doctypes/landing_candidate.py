"""Landing Candidate Child Table."""

from typing import ClassVar

from framework_m_core.domain.base_doctype import BaseDocType, Field


class LandingCandidate(BaseDocType):
    """Child table for configuring landing page fallback rules."""

    route: str = Field(description="The target frontend route.")
    required_doctype: str | None = Field(
        default=None, description="DocType the user must have permission to access."
    )
    required_action: str | None = Field(
        default=None,
        description="Action (e.g., 'read') the user must be permitted to perform.",
    )

    class Meta:
        is_child_table: ClassVar[bool] = True
        api_resource: ClassVar[bool] = False
