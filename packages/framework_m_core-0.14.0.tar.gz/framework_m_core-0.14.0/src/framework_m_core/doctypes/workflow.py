"""Workflow DocType for defining workflow configurations.

This DocType stores the complete workflow definition including
states, transitions, and the target DocType.
"""

from __future__ import annotations

from typing import Any, ClassVar

from framework_m_core.doctypes.workflow_state_definition import WorkflowStateDefinition
from framework_m_core.doctypes.workflow_transition_definition import (
    WorkflowTransitionDefinition,
)
from framework_m_core.domain.base_doctype import BaseDocType, Field


class Workflow(BaseDocType):
    """Defines a complete workflow configuration for a specific DocType.

    Attributes:
        doctype_name: The target DocType this workflow applies to
        initial_state: The starting state for new documents
        states: List of all possible state definitions in this workflow
        transitions: List of all valid actions and state changes
        is_active: Whether this workflow is currently active
    """

    doctype_name: str = Field(description="Target DocType for this workflow")
    initial_state: str = Field(description="Initial state for new documents")
    states: list[WorkflowStateDefinition] = Field(
        default_factory=list,
        description="State definitions",
    )
    transitions: list[WorkflowTransitionDefinition] = Field(
        default_factory=list,
        description="Possible state transitions",
    )
    is_active: bool = Field(default=True, description="Whether workflow is active")

    class Meta:
        """Metadata configuration for Workflow."""

        api_resource: ClassVar[bool] = True
        show_in_desk: ClassVar[bool] = True

        # UI Metadata for Spreadsheet UX (ListField)
        ui_meta: ClassVar[dict[str, Any]] = {
            "fields": {
                "states": {
                    "ui_widget": "grid",
                    "grid_columns": ["current_state", "allow_edit", "is_terminal"],
                },
                "transitions": {
                    "ui_widget": "grid",
                    "grid_columns": [
                        "action",
                        "from_state",
                        "to_state",
                        "allowed_role",
                    ],
                },
            }
        }

        # Permissions aligned with System/Workflow Manager roles
        permissions: ClassVar[dict[str, list[str]]] = {
            "read": ["System Manager", "Workflow Manager", "Admin"],
            "write": ["System Manager", "Workflow Manager", "Admin"],
            "create": ["System Manager", "Workflow Manager", "Admin"],
            "delete": ["Admin"],
        }
