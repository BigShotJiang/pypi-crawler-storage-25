"""Utility commands for Framework M CLI."""

from __future__ import annotations

import contextlib
import platform
import sys
from importlib.metadata import distributions, entry_points, version
from typing import Annotated

import cyclopts
from rich.console import Console
from rich.table import Table

from framework_m_core import __version__

console = Console()


def get_python_version() -> str:
    """Get Python version string."""
    return platform.python_version()


def get_framework_version() -> str:
    """Get Framework M version string."""
    return __version__


def get_pythonpath() -> str:
    """Get PYTHONPATH."""
    return sys.path[0]


def info_command(
    verbose: Annotated[
        bool, cyclopts.Parameter(name="--verbose", help="Show detailed info")
    ] = False,
) -> None:
    """Show system and framework information."""
    table = Table(title="Framework M Information")
    table.add_column("Key", style="cyan")
    table.add_column("Value", style="green")

    table.add_row("Python", get_python_version())

    # List installed framework packages
    fm_pkgs = sorted(
        {
            d.metadata["Name"]
            for d in distributions()
            if d.metadata["Name"].startswith(("framework-m", "framework-mx"))
        }
    )
    for pkg in fm_pkgs:
        with contextlib.suppress(Exception):
            table.add_row(pkg.replace("-", " ").title(), version(pkg))

    # List discovered business apps
    with contextlib.suppress(Exception):
        eps = entry_points(group="framework_m.apps")
        apps = sorted({ep.name for ep in eps})
        if apps:
            table.add_row("Business Apps", ", ".join(apps))

    if verbose:
        table.add_row("Platform", platform.platform())
        table.add_row("Python Path", get_pythonpath())

        # Load and execute info plugins
        with contextlib.suppress(Exception):
            info_eps = entry_points(group="framework_m.cli_info")
            for ep in info_eps:
                try:
                    plugin_func = ep.load()
                    plugin_func(table)
                except Exception as e:
                    table.add_row(f"Plugin Error ({ep.name})", str(e))

    console.print(table)


__all__ = [
    "get_framework_version",
    "get_python_version",
    "get_pythonpath",
    "info_command",
]
