"""Landing Service - Orchestrates landing page resolution.

This service implements the core resolution hierarchy for determining
a user's landing page by iterating through a prioritized list of LandingProtocol
adapters.
"""

from collections.abc import Sequence

from framework_m_core.domain.landing import LandingDescriptor
from framework_m_core.interfaces.auth_context import UserContext
from framework_m_core.interfaces.landing import LandingProtocol


class LandingService:
    """Orchestrator for landing page resolution."""

    def __init__(self, resolvers: Sequence[LandingProtocol]) -> None:
        """Initialize the service with a prioritized list of resolvers.

        Args:
            resolvers: An ordered sequence of LandingProtocol implementations.
                The service will try them in this exact order.
        """
        self.resolvers = resolvers

    async def resolve(self, context: UserContext) -> LandingDescriptor | None:
        """Resolve the landing page by trying adapters in sequence."""
        for resolver in self.resolvers:
            descriptor = await resolver.resolve(context)
            if descriptor is not None:
                return descriptor
        return None
