"""Services - High-level business services for Framework M.

This package contains service classes that provide clean abstractions
over the underlying protocols and adapters.

Services:
- UserManager: User management operations (get, authenticate, create)
"""

from framework_m_core.services.user_manager import UserManager
from framework_m_core.services.webhook_dispatcher import (
    evaluate_webhook_condition,
    fire_webhook,
    should_dispatch_webhook,
)

__all__ = [
    "UserManager",
    "evaluate_webhook_condition",
    "fire_webhook",
    "should_dispatch_webhook",
]
