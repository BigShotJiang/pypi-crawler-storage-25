"""Defaults Service - Orchestrates fallback configuration and virtual state.

This service handles reading declarative fallback files (like TOML) for
Singletons and standard DocTypes, merging them with user input or
instantiating "Virtual Singletons" when the database is empty.
"""

from collections.abc import Callable
from typing import Any, TypeVar

from framework_m_core.domain.base_doctype import BaseDocType
from framework_m_core.interfaces.defaults import DefaultsProtocol

T = TypeVar("T", bound=BaseDocType)


class DefaultsService:
    """Orchestrates configuration fallbacks and virtual state hydration."""

    def __init__(
        self, defaults_factory: Callable[[str | None], DefaultsProtocol]
    ) -> None:
        """Initialize the service with a factory for generating adapters.

        Args:
            defaults_factory: A callable that takes an optional source string
                (e.g., a file path) and returns a configured DefaultsProtocol adapter.
        """
        self.defaults_factory = defaults_factory

    async def build_virtual_singleton(self, doctype_class: type[T]) -> T:
        """Build a virtual singleton instance purely from its defaults file.

        Args:
            doctype_class: The singleton DocType class to instantiate.

        Returns:
            A hydrated instance of the singleton.
        """
        meta = getattr(doctype_class, "Meta", None)
        defaults_file = getattr(meta, "defaults_file", None) or "framework_config.toml"

        adapter = self.defaults_factory(defaults_file)
        data = await adapter.get_all()

        # Support namespaced configs (e.g. [SystemSettings] in framework_config.toml)
        doctype_name = doctype_class.__name__
        if doctype_name in data and isinstance(data[doctype_name], dict):
            data = data[doctype_name]

        return doctype_class(**data)

    async def hydrate_with_defaults(
        self, doctype_class: type[T], raw_data: dict[str, Any]
    ) -> T:
        """Hydrate user input with fallback configuration defaults."""
        meta = getattr(doctype_class, "Meta", None)
        defaults_file = getattr(meta, "defaults_file", None)

        adapter = self.defaults_factory(defaults_file)
        defaults = await adapter.get_all()

        # Support namespaced configs
        doctype_name = doctype_class.__name__
        if doctype_name in defaults and isinstance(defaults[doctype_name], dict):
            defaults = defaults[doctype_name]

        merged_data = {**defaults, **raw_data}
        return doctype_class(**merged_data)
