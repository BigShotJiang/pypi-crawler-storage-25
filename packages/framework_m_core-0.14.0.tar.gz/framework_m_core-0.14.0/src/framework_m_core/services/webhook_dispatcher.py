"""Webhook dispatcher helpers for filtering and resilient delivery."""

from __future__ import annotations

import asyncio
import re
from collections.abc import Awaitable, Callable
from typing import Any

from framework_m_core.doctypes.webhook import Webhook
from framework_m_core.interfaces.event_bus import Event
from framework_m_core.interfaces.webhook import WebhookDelivererProtocol

_COMPARISON_PATTERN = re.compile(
    r"^\s*([a-zA-Z_][a-zA-Z0-9_\.]*)\s*(==|!=|>=|<=|>|<)\s*(.+?)\s*$"
)


def evaluate_webhook_condition(
    condition: str | None,
    event_data: dict[str, Any] | None,
) -> bool:
    """Evaluate webhook condition safely against event payload."""
    if condition is None or condition.strip() == "":
        return True

    data = event_data or {}

    # Optional JMESPath support if dependency is present.
    try:
        import jmespath  # type: ignore[import-untyped]

        result = jmespath.search(condition, data)
        if isinstance(result, bool):
            return result
        if isinstance(result, (int, float)):
            return result != 0
        return result is not None
    except Exception:
        pass

    match = _COMPARISON_PATTERN.match(condition)
    if match is None:
        return False

    key, operator, raw_literal = match.groups()
    left_value = _get_nested(data, key)
    right_value = _parse_literal(raw_literal)
    return _compare_values(left_value, operator, right_value)


def should_dispatch_webhook(webhook: Webhook, event: Event) -> bool:
    """Return True if webhook should be dispatched for event."""
    if webhook.event != event.type:
        return False

    event_doctype = getattr(event, "doctype", None)
    if event_doctype is None and event.data:
        event_doctype = event.data.get("doctype")

    if webhook.doctype_filter and event_doctype != webhook.doctype_filter:
        return False

    return evaluate_webhook_condition(webhook.condition, event.data)


async def fire_webhook(
    webhook: Webhook,
    event: Event,
    deliverer: WebhookDelivererProtocol,
    *,
    max_retries: int = 3,
    base_delay: float = 1.0,
    sleep_func: Callable[[float], Awaitable[None]] = asyncio.sleep,
) -> None:
    """Deliver webhook with exponential-backoff retries."""
    if max_retries < 0:
        raise ValueError("max_retries must be >= 0")

    for attempt in range(max_retries + 1):
        try:
            await deliverer.deliver(webhook, event)
            return
        except Exception:
            if attempt >= max_retries:
                raise
            await sleep_func(base_delay * (2**attempt))


def _get_nested(data: dict[str, Any], key: str) -> Any:
    value: Any = data
    for part in key.split("."):
        if not isinstance(value, dict) or part not in value:
            return None
        value = value[part]
    return value


def _parse_literal(raw: str) -> Any:
    value = raw.strip()

    if (
        (value.startswith("`") and value.endswith("`"))
        or (value.startswith('"') and value.endswith('"'))
        or (value.startswith("'") and value.endswith("'"))
    ):
        return value[1:-1]

    lowered = value.lower()
    if lowered == "true":
        return True
    if lowered == "false":
        return False
    if lowered in {"none", "null"}:
        return None

    try:
        if "." in value:
            return float(value)
        return int(value)
    except ValueError:
        return value


def _compare_values(left: Any, operator: str, right: Any) -> bool:
    left_num = _to_number(left)
    right_num = _to_number(right)

    if left_num is not None and right_num is not None:
        left_cmp: Any = left_num
        right_cmp: Any = right_num
    else:
        left_cmp = left
        right_cmp = right

    if operator == "==":
        return bool(left_cmp == right_cmp)
    if operator == "!=":
        return bool(left_cmp != right_cmp)
    if operator == ">":
        return bool(
            left_cmp is not None and right_cmp is not None and left_cmp > right_cmp
        )
    if operator == "<":
        return bool(
            left_cmp is not None and right_cmp is not None and left_cmp < right_cmp
        )
    if operator == ">=":
        return bool(
            left_cmp is not None and right_cmp is not None and left_cmp >= right_cmp
        )
    if operator == "<=":
        return bool(
            left_cmp is not None and right_cmp is not None and left_cmp <= right_cmp
        )
    return False


def _to_number(value: Any) -> float | None:
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        try:
            return float(value)
        except ValueError:
            return None
    return None


__all__ = [
    "evaluate_webhook_condition",
    "fire_webhook",
    "should_dispatch_webhook",
]
