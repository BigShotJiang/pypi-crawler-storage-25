"""Document ID Service.

Provides deterministic UUID generation for DocTypes to support GitOps
and Zero-Touch Provisioning.
"""

import uuid

# Dynamically generate the framework's root namespace using a URL.
# This prevents hardcoded entropy and Gitleaks warnings while ensuring
# universal consistency across all Framework M installations.
FRAMEWORK_M_NAMESPACE = uuid.uuid5(uuid.NAMESPACE_URL, "frameworkm.dev")


class DocumentIdService:
    """Service for generating deterministic document identifiers."""

    def generate_deterministic_id(self, doctype: str, name: str) -> uuid.UUID:
        """Generate a deterministic UUIDv5 based on DocType and Name.

        Args:
            doctype: The name of the DocType.
            name: The unique human-readable name of the document.

        Returns:
            A consistently reproducible UUID.
        """
        identity_string = f"{doctype}:{name}"
        return uuid.uuid5(FRAMEWORK_M_NAMESPACE, identity_string)
