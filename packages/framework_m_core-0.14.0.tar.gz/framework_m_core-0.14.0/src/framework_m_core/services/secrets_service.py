"""Secrets Manager Service.

This module provides the high-level service for managing application secrets.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from framework_m_core.interfaces.secrets import SecretProtocol

logger = logging.getLogger(__name__)


class SecretsManager:
    """Service for managing sensitive configuration data.

    Wraps a SecretProtocol adapter and provides fail-fast validation for
    critical configuration at startup.
    """

    def __init__(self, adapter: SecretProtocol) -> None:
        """Initialize with a secret provider adapter.

        Args:
            adapter: Port implementation for secrets retrieval.
        """
        self._adapter = adapter

    def get(self, key: str, default: str | None = None) -> str | None:
        """Get a secret value.

        Args:
            key: Secret identifier.
            default: Optional default value.

        Returns:
            The secret value or default.
        """
        return self._adapter.get_secret(key, default)

    def validate(self, required_keys: list[str]) -> None:
        """Validate that all required secrets are present.

        This should be called during application bootstrap to ensure
        critical configuration like DATABASE_URL or JWT_SECRET is present.

        Args:
            required_keys: List of keys that MUST be present.

        Raises:
            RuntimeError: If any required secret is missing.
        """
        missing = []
        for key in required_keys:
            if not self.get(key):
                missing.append(key)

        if missing:
            msg = f"CRITICAL: Missing required secrets: {', '.join(missing)}"
            logger.error(msg)
            raise RuntimeError(msg)

        logger.info("All required secrets validated successfully.")


__all__ = ["SecretsManager"]
