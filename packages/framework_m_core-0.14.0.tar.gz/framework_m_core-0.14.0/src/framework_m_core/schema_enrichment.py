"""Schema Enrichment — Post-processing for Pydantic-generated JSON Schemas.

Purpose
-------
Pydantic's ``model_json_schema()`` is correct but frontend-unfriendly in two ways:

1. **Python Enum types** produce ``$ref`` entries in the property schema
   (e.g. ``{"$ref": "#/$defs/StatusEnum", "ui_meta": {...}}``).  The ``ui_meta``
   key from ``json_schema_extra`` lands on the *property* while the ``enum``
   values live inside ``$defs``.  The JSONSchemaBridge uniforms adapter resolves
   refs for type-checking but the ``AutoField`` never sees ``enum`` and
   ``ui_meta`` together on the same object, so the Select widget is not triggered.

2. **``ui_meta`` from ``json_schema_extra``** is already inlined for plain
   ``Literal`` types, but for the frontend to use it reliably we want every
   property to carry a unified ``ui_meta`` block that also captures standard
   JSON-Schema validation keywords (``minimum``, ``maximum``, ``pattern``, etc.)
   so ``AutoField``/``TextField`` can apply them without re-reading raw schema.

What this module does
---------------------
``enrich_schema(schema)`` is called **after** ``model_json_schema()`` and
**after** any ``MetadataDecoratorRegistry.apply()`` calls.  It mutates a
*deep copy* of the schema (leaving the original unchanged) and:

- Resolves ``$ref`` property entries: merges ``$defs`` enum/const values plus
  any sibling keys (like ``ui_meta``, ``description``, ``default``) into a flat
  property object — matching exactly what uniforms' ``resolveRef`` does
  internally but making it visible to higher-level code.
- Ensures every property that has an ``enum`` array carries the enum values
  under ``ui_meta.options`` for quick access by the frontend SelectField.
- Consolidates validation constraints into ``ui_meta.validation``:
  ``minimum``, ``maximum``, ``exclusiveMinimum``, ``exclusiveMaximum``,
  ``multipleOf``, ``minLength``, ``maxLength``, ``pattern``, ``minItems``,
  ``maxItems``.
- Preserves *all* existing ``ui_meta`` keys — it only adds, never overwrites.
"""

from __future__ import annotations

import copy
from typing import Any


def _resolve_ref(ref: str, defs: dict[str, Any]) -> dict[str, Any]:
    """Resolve a JSON-Schema ``$ref`` string against the schema's ``$defs``."""
    if not ref.startswith("#/$defs/"):
        return {}
    def_name = ref[len("#/$defs/") :]
    return copy.deepcopy(defs.get(def_name, {}))


def _merge_validation(prop: dict[str, Any]) -> dict[str, Any]:
    """Extract standard JSON Schema validation keywords into ``ui_meta.validation``.

    Only populates keys that are NOT already present in ``ui_meta.validation``
    so that explicit developer annotations are never silently overwritten.
    """
    NUMERIC = {
        "minimum",
        "maximum",
        "exclusiveMinimum",
        "exclusiveMaximum",
        "multipleOf",
    }
    STRING = {"minLength", "maxLength", "pattern"}
    ARRAY = {"minItems", "maxItems"}

    ui_meta: dict[str, Any] = prop.get("ui_meta", {})
    validation: dict[str, Any] = dict(ui_meta.get("validation", {}))

    for kw in NUMERIC | STRING | ARRAY:
        if kw in prop and kw not in validation:
            validation[kw] = prop[kw]

    if validation:
        ui_meta = {**ui_meta, "validation": validation}

    return ui_meta


def _enrich_property(
    prop: dict[str, Any],
    defs: dict[str, Any],
) -> dict[str, Any]:
    """Enrich a single property dict in-place (returns modified copy)."""
    prop = copy.deepcopy(prop)
    ref = prop.pop("$ref", None)

    if ref:
        resolved = _resolve_ref(ref, defs)
        # Merge: resolved values provide base, sibling keys override
        merged = {**resolved, **{k: v for k, v in prop.items() if k != "$ref"}}
        prop = merged

    # Ensure ui_meta exists
    ui_meta: dict[str, Any] = copy.deepcopy(prop.get("ui_meta", {}))

    # Surface enum values under ui_meta.options if not already there
    enum_values: list[Any] | None = prop.get("enum")
    if enum_values and "options" not in ui_meta:
        ui_meta["options"] = [
            {"value": v, "label": str(v).replace("_", " ").title()} for v in enum_values
        ]

    # Consolidate validation constraints
    validation_ui = _merge_validation(prop)
    if "validation" in validation_ui:
        ui_meta["validation"] = {
            **ui_meta.get("validation", {}),
            **validation_ui["validation"],
        }

    prop["ui_meta"] = ui_meta
    return prop


def enrich_schema(schema: dict[str, Any]) -> dict[str, Any]:
    """Enrich a Pydantic-generated JSON Schema for frontend consumption.

    Args:
        schema: The raw output of ``MyDocType.model_json_schema()``, optionally
                already processed by ``MetadataDecoratorRegistry.apply()``.

    Returns:
        A new schema dict (deep copy) with all properties enriched.

    Example::

        schema = MyDocType.model_json_schema()
        schema = MetadataDecoratorRegistry.get_instance().apply(\"MyDocType\", schema)
        schema = enrich_schema(schema)
        # Now ``schema[\"properties\"][\"status\"][\"ui_meta\"][\"options\"]``
        # contains the enum options and
        # ``schema[\"properties\"][\"score\"][\"ui_meta\"][\"validation\"][\"minimum\"]``
        # contains the min constraint.
    """
    schema = copy.deepcopy(schema)
    defs: dict[str, Any] = schema.get("$defs", {})
    properties: dict[str, Any] = schema.get("properties", {})

    enriched_properties: dict[str, Any] = {}
    for field_name, prop in properties.items():
        enriched_properties[field_name] = _enrich_property(prop, defs)

    schema["properties"] = enriched_properties
    return schema


__all__ = ["enrich_schema"]
