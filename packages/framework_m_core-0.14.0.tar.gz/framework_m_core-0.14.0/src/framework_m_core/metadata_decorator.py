"""Metadata Decorator Registry for Multi-App Coexistence."""

import copy
import logging
from collections.abc import Callable
from typing import Any

from pydantic import Field, create_model

logger = logging.getLogger(__name__)

MetadataDecorator = Callable[[dict[str, Any]], dict[str, Any]]


class MetadataDecoratorRegistry:
    """Registry for DocType metadata decorators.

    Enables multiple apps (macroservices) to decorate base DocType schemas
    with extensions, enum appends, or contextual overrides safely.
    """

    _instance: "MetadataDecoratorRegistry | None" = None

    def __init__(self) -> None:
        self._decorators: dict[str, list[MetadataDecorator]] = {}
        self._properties: dict[str, dict[str, tuple[type, dict[str, Any]]]] = {}
        self._locked: bool = False

    @classmethod
    def get_instance(cls) -> "MetadataDecoratorRegistry":
        """Get the singleton instance of the registry."""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def clear(self) -> None:
        """Clear all registered decorators (useful for testing)."""
        self._decorators.clear()
        self._properties.clear()
        self._locked = False

    def register(self, doctype_name: str, decorator: MetadataDecorator) -> None:
        """Register a metadata decorator for a specific DocType."""
        if doctype_name not in self._decorators:
            self._decorators[doctype_name] = []
        self._decorators[doctype_name].append(decorator)

    def register_property(
        self,
        doctype_name: str,
        field_name: str,
        field_type: type,
        **metadata: Any,
    ) -> None:
        """Register a dynamic property for a DocType."""
        if self._locked:
            raise RuntimeError("Registry is locked after baking models.")

        if doctype_name not in self._properties:
            self._properties[doctype_name] = {}
        self._properties[doctype_name][field_name] = (field_type, metadata)

    def bake(self, doctype_class: type[Any]) -> type[Any]:
        """Bake augmented properties into a new Pydantic model subclass."""
        self._locked = True
        doctype_name = doctype_class.__name__
        properties = self._properties.get(doctype_name, {})

        if not properties:
            return doctype_class

        field_definitions: dict[str, Any] = {}
        for field_name, (field_type, metadata) in properties.items():
            field_definitions[field_name] = (
                field_type | None,
                Field(default=None, json_schema_extra=metadata),
            )

        return create_model(
            doctype_name,
            __base__=doctype_class,
            __module__=doctype_class.__module__,
            **field_definitions,
        )

    def apply(self, doctype_name: str, schema: dict[str, Any]) -> dict[str, Any]:
        """Apply all registered decorators for a DocType to its schema in sequence."""
        current_schema = copy.deepcopy(schema)

        for decorator in self._decorators.get(doctype_name, []):
            before_state = copy.deepcopy(current_schema)
            current_schema = decorator(current_schema)
            for key, new_val in current_schema.items():
                if (
                    key in before_state
                    and before_state[key] != new_val
                    and not isinstance(new_val, (dict, list))
                ):
                    logger.warning(
                        f"Metadata conflict: overwriting scalar '{key}' in '{doctype_name}'."
                    )
        return current_schema
