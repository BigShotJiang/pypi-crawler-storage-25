"""High-level convenience client for the komputer.ai API.

Quick start:
    client = KomputerClient("http://localhost:8080")
    client.create_agent(name="my-agent", instructions="Say hello", model="claude-sonnet-4-6")

    for event in client.watch_agent("my-agent"):
        print(event.type, event.payload)

Direct API access (model-based):
    from komputer_ai.models import CreateAgentRequest
    client.agents.create_agent(CreateAgentRequest(name="my-agent", instructions="..."))
"""

from typing import Dict, List, Optional

from komputer_ai import Configuration, ApiClient
from komputer_ai.api.agents_api import AgentsApi
from komputer_ai.api.connectors_api import ConnectorsApi
from komputer_ai.api.memories_api import MemoriesApi
from komputer_ai.api.offices_api import OfficesApi
from komputer_ai.api.schedules_api import SchedulesApi
from komputer_ai.api.secrets_api import SecretsApi
from komputer_ai.api.skills_api import SkillsApi
from komputer_ai.api.templates_api import TemplatesApi
from komputer_ai.api.agents_ws import AgentEvent, AgentEventStream, Payload
from komputer_ai.exceptions import ApiException
from komputer_ai.models import (
    CreateAgentRequest, CreateConnectorRequest, CreateMemoryRequest, CreateScheduleAgentSpec, CreateScheduleRequest, CreateSecretRequest, CreateSkillRequest, PatchAgentRequest, PatchMemoryRequest, PatchScheduleRequest, PatchSkillRequest, UpdateSecretRequest,
)


class KomputerClient:
    """Client for the komputer.ai API.

    Provides kwargs-style methods for common operations and direct access
    to the generated API clients via .agents, .memories, .skills, etc.
    """

    def __init__(self, base_url: str = "http://localhost:8080"):
        self._base_url = base_url.rstrip("/")
        config = Configuration(host=f"{self._base_url}/api/v1")
        api_client = ApiClient(config)

        self.agents = AgentsApi(api_client)
        self.connectors = ConnectorsApi(api_client)
        self.memories = MemoriesApi(api_client)
        self.offices = OfficesApi(api_client)
        self.schedules = SchedulesApi(api_client)
        self.secrets = SecretsApi(api_client)
        self.skills = SkillsApi(api_client)
        self.templates = TemplatesApi(api_client)
        self._api_client = api_client

    # --- Agents ---

    def list_agents(self):
        return self.agents.list_agents()

    def create_agent(self, name: str, instructions: str, *, connectors: Optional[List[str]] = None, lifecycle: Optional[str] = None, memories: Optional[List[str]] = None, model: Optional[str] = None, namespace: Optional[str] = None, office_manager: Optional[str] = None, role: Optional[str] = None, secret_refs: Optional[List[str]] = None, skills: Optional[List[str]] = None, system_prompt: Optional[str] = None, template_ref: Optional[str] = None):
        try:
            return self.agents.create_agent(CreateAgentRequest(connectors=connectors, instructions=instructions, lifecycle=lifecycle, memories=memories, model=model, name=name, namespace=namespace, office_manager=office_manager, role=role, secret_refs=secret_refs, skills=skills, system_prompt=system_prompt, template_ref=template_ref))
        except ApiException as e:
            if e.status == 409:
                return self.patch_agent(name, connectors=connectors, instructions=instructions, lifecycle=lifecycle, memories=memories, model=model, secret_refs=secret_refs, skills=skills, system_prompt=system_prompt, template_ref=template_ref)
            raise

    def get_agent(self, name: str):
        return self.agents.get_agent(name)

    def patch_agent(self, name: str, *, connectors: Optional[List[str]] = None, instructions: Optional[str] = None, lifecycle: Optional[str] = None, memories: Optional[List[str]] = None, model: Optional[str] = None, secret_refs: Optional[List[str]] = None, skills: Optional[List[str]] = None, system_prompt: Optional[str] = None, template_ref: Optional[str] = None):
        return self.agents.patch_agent(name, PatchAgentRequest(connectors=connectors, instructions=instructions, lifecycle=lifecycle, memories=memories, model=model, secret_refs=secret_refs, skills=skills, system_prompt=system_prompt, template_ref=template_ref))

    def delete_agent(self, name: str):
        return self.agents.delete_agent(name)

    def cancel_agent_task(self, name: str):
        return self.agents.cancel_agent_task(name)

    def get_agent_events(self, name: str):
        return self.agents.get_agent_events(name)

    # --- Memories ---

    def list_memories(self):
        return self.memories.list_memories()

    def create_memory(self, name: str, content: str, *, description: Optional[str] = None, namespace: Optional[str] = None):
        try:
            return self.memories.create_memory(CreateMemoryRequest(content=content, description=description, name=name, namespace=namespace))
        except ApiException as e:
            if e.status == 409:
                return self.patch_memory(name, content=content, description=description)
            raise

    def get_memory(self, name: str):
        return self.memories.get_memory(name)

    def patch_memory(self, name: str, *, content: Optional[str] = None, description: Optional[str] = None):
        return self.memories.patch_memory(name, PatchMemoryRequest(content=content, description=description))

    def delete_memory(self, name: str):
        return self.memories.delete_memory(name)

    # --- Skills ---

    def list_skills(self):
        return self.skills.list_skills()

    def create_skill(self, name: str, content: str, description: str, *, namespace: Optional[str] = None):
        try:
            return self.skills.create_skill(CreateSkillRequest(content=content, description=description, name=name, namespace=namespace))
        except ApiException as e:
            if e.status == 409:
                return self.patch_skill(name, content=content, description=description)
            raise

    def get_skill(self, name: str):
        return self.skills.get_skill(name)

    def patch_skill(self, name: str, *, content: Optional[str] = None, description: Optional[str] = None):
        return self.skills.patch_skill(name, PatchSkillRequest(content=content, description=description))

    def delete_skill(self, name: str):
        return self.skills.delete_skill(name)

    # --- Schedules ---

    def list_schedules(self):
        return self.schedules.list_schedules()

    def create_schedule(self, name: str, instructions: str, schedule: str, *, agent: Optional[CreateScheduleAgentSpec] = None, agent_name: Optional[str] = None, auto_delete: Optional[bool] = None, keep_agents: Optional[bool] = None, namespace: Optional[str] = None, timezone: Optional[str] = None):
        try:
            return self.schedules.create_schedule(CreateScheduleRequest(agent=agent, agent_name=agent_name, auto_delete=auto_delete, instructions=instructions, keep_agents=keep_agents, name=name, namespace=namespace, schedule=schedule, timezone=timezone))
        except ApiException as e:
            if e.status == 409:
                return self.patch_schedule(name, schedule=schedule)
            raise

    def get_schedule(self, name: str):
        return self.schedules.get_schedule(name)

    def patch_schedule(self, name: str, *, schedule: Optional[str] = None):
        return self.schedules.patch_schedule(name, PatchScheduleRequest(schedule=schedule))

    def delete_schedule(self, name: str):
        return self.schedules.delete_schedule(name)

    # --- Secrets ---

    def list_secrets(self):
        return self.secrets.list_secrets()

    def create_secret(self, name: str, data: Dict[str, str], *, namespace: Optional[str] = None):
        try:
            return self.secrets.create_secret(CreateSecretRequest(data=data, name=name, namespace=namespace))
        except ApiException as e:
            if e.status == 409:
                return self.update_secret(name, data=data, namespace=namespace)
            raise

    def update_secret(self, name: str, data: Dict[str, str], *, namespace: Optional[str] = None):
        return self.secrets.update_secret(name, UpdateSecretRequest(data=data, namespace=namespace))

    def delete_secret(self, name: str):
        return self.secrets.delete_secret(name)

    # --- Connectors ---

    def list_connectors(self):
        return self.connectors.list_connectors()

    def create_connector(self, name: str, service: str, url: str, *, auth_secret_key: Optional[str] = None, auth_secret_name: Optional[str] = None, auth_type: Optional[str] = None, display_name: Optional[str] = None, namespace: Optional[str] = None, oauth_client_id: Optional[str] = None, oauth_client_secret: Optional[str] = None, type: Optional[str] = None):
        return self.connectors.create_connector(CreateConnectorRequest(auth_secret_key=auth_secret_key, auth_secret_name=auth_secret_name, auth_type=auth_type, display_name=display_name, name=name, namespace=namespace, oauth_client_id=oauth_client_id, oauth_client_secret=oauth_client_secret, service=service, type=type, url=url))

    def get_connector(self, name: str):
        return self.connectors.get_connector(name)

    def delete_connector(self, name: str):
        return self.connectors.delete_connector(name)

    def list_connector_tools(self, name: str):
        return self.connectors.list_connector_tools(name)

    # --- Offices ---

    def list_offices(self):
        return self.offices.list_offices()

    def get_office(self, name: str):
        return self.offices.get_office(name)

    def delete_office(self, name: str):
        return self.offices.delete_office(name)

    def get_office_events(self, name: str):
        return self.offices.get_office_events(name)

    # --- Templates ---

    def list_templates(self):
        return self.templates.list_templates()


    # --- WebSocket ---

    def watch_agent(self, name: str) -> AgentEventStream:
        """Stream real-time events from an agent via WebSocket, prefetching history.

        Requires: pip install websocket-client
        """
        ws_url = self._base_url.replace("http://", "ws://").replace("https://", "wss://")
        history = []
        try:
            resp = self.agents.get_agent_events(name, limit=200)
            events = resp.get("events") if isinstance(resp, dict) else None
            if events:
                history = [
                    AgentEvent(
                        agent_name=e.get("agentName", name),
                        type=e.get("type", ""),
                        timestamp=e.get("timestamp", ""),
                        payload=Payload(e.get("payload", {})),
                    )
                    for e in events
                    if isinstance(e, dict)
                ]
        except Exception:
            pass
        return AgentEventStream(ws_url, name, history)

    # --- Lifecycle ---

    def close(self):
        self._api_client.__exit__(None, None, None)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self._api_client.__exit__(*args)
