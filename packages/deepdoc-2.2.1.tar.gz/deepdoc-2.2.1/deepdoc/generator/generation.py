"""V2 Generation Engine — evidence-assembled, single-pass, validated page generation.

Phase 3 of the bucket-based doc pipeline:

  3.1 Evidence assembly: per-bucket, section-aware context gathering from scan data
  3.2 Single-pass generation: one LLM call per bucket with full evidence + mandatory outline
  3.3 Validation: check required sections, evidence citations, no hallucinated paths
  3.4 Graph-lite diagrams: static import/endpoint edges → Mermaid seed context
  3.5 Parallel generation: concurrent LLM calls for independent buckets
  3.6 Graceful degradation: fallbacks for sparse evidence, malformed output, LLM failures
"""

from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import re
import subprocess
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from rich.console import Console
from rich.panel import Panel
from rich.progress import (
    Progress,
    SpinnerColumn,
    TextColumn,
    BarColumn,
    TaskProgressColumn,
)

from .. import __version__ as DEEPDOC_VERSION
from ..llm import LLMClient
from ..parser import parse_file, supported_extensions
from ..parser.base import ParsedFile, Symbol
from ..planner import DocBucket, DocPlan, RepoScan, tracked_bucket_files
from ..prompts_v2 import SYSTEM_V2, get_prompt_for_bucket
from ..scanner import _build_import_lookup, _classify_file_role, _normalize_import
from ..openapi import parse_openapi_spec, spec_to_context_string

console = Console()

# ═════════════════════════════════════════════════════════════════════════════
# 3.1  Evidence Assembly
# ═════════════════════════════════════════════════════════════════════════════


from .evidence import AssembledEvidence, EvidenceAssembler
from .mdx_compile_gate import GateOutcome, apply_mdx_compile_gate
from .validation import PageValidator, ValidationResult
from .post_processors import *
# ═════════════════════════════════════════════════════════════════════════════
# 3.2  Single-Pass Page Generation
# ═════════════════════════════════════════════════════════════════════════════


class PageGenerator:
    """Generates a single doc page from assembled evidence in one LLM pass."""

    def __init__(self, llm: LLMClient, cfg: dict[str, Any], repo_root: Path):
        self.llm = llm
        self.cfg = cfg
        self.repo_root = repo_root

    def generate(
        self,
        evidence: AssembledEvidence,
        sitemap_context: str,
        dependency_links: str,
        openapi_context: str = "",
        quality_feedback: str = "",
        failure_prefix: str = "",
    ) -> str:
        """Generate the complete page from evidence. Returns markdown string."""
        bucket = evidence.bucket

        # Select prompt template via generation_hints.prompt_style
        prompt_template = get_prompt_for_bucket(bucket)

        # Compose the enriched source context
        full_source = evidence.source_context
        if evidence.compressed_cards_context:
            full_source += (
                "\n\n## Compressed File Coverage\n"
                "These files were not dropped. They are represented by derived evidence "
                "cards and still count as authoritative coverage inputs.\n\n"
                f"{evidence.compressed_cards_context}"
            )
        if evidence.cluster_context:
            full_source += f"\n\n## Giant File Clusters\n{evidence.cluster_context}"
        if evidence.integration_context:
            full_source += f"\n\n## Integration Context\n{evidence.integration_context}"
        if evidence.database_context:
            full_source += f"\n\n## Database Schema\n{evidence.database_context}"
        if evidence.runtime_context:
            full_source += (
                f"\n\n## Runtime & Background Jobs\n{evidence.runtime_context}"
            )
        # flow_context is injected via dedicated template placeholder
        if evidence.artifact_context:
            full_source += f"\n\n## Artifacts\n{evidence.artifact_context}"
        if evidence.graph_context:
            full_source += f"\n\n## Dependency Graph\n{evidence.graph_context}"
        if evidence.cross_ref_context:
            full_source += f"\n\n{evidence.cross_ref_context}"
        if evidence.plan_summary_context:
            full_source += f"\n\n## Repository Map\n{evidence.plan_summary_context}"
        if evidence.repo_docs_context:
            full_source += f"\n\n{evidence.repo_docs_context}"
        if evidence.helper_context:
            full_source += f"\n\n{evidence.helper_context}"
        if evidence.config_env_context:
            full_source += (
                f"\n\n## Config & Environment Evidence\n{evidence.config_env_context}"
            )
        page_contract = (bucket.generation_hints or {}).get("page_contract", {})
        if page_contract:
            contract_lines = [
                f"Intent: {page_contract.get('intent', bucket.description or bucket.title)}"
            ]
            must_cover = page_contract.get("must_cover_concepts", [])
            if must_cover:
                contract_lines.append(f"Must cover: {', '.join(must_cover)}")
            sibling_links = page_contract.get("required_sibling_links", [])
            if sibling_links:
                contract_lines.append(
                    f"Required sibling links: {', '.join(sibling_links)}"
                )
            forbidden = page_contract.get("forbidden_filler", [])
            if forbidden:
                contract_lines.append(f"Forbidden filler: {', '.join(forbidden)}")
            full_source += "\n\n## Page Contract\n" + "\n".join(
                f"- {line}" for line in contract_lines
            )

        # Format required sections/diagrams/coverage
        required_sections = (
            ", ".join(bucket.required_sections)
            if bucket.required_sections
            else "default"
        )
        required_diagrams = (
            ", ".join(bucket.required_diagrams)
            if bucket.required_diagrams
            else "architecture_flow"
        )
        coverage_targets = (
            ", ".join(bucket.coverage_targets) if bucket.coverage_targets else ""
        )

        # Resource group for endpoint pages
        resource_group = bucket.slug.replace("-api", "").replace("-", " ").title()

        user_prompt = prompt_template.format(
            title=bucket.title,
            project_name=self.cfg.get("project_name", self.repo_root.name),
            description=self.cfg.get("description", ""),
            page_description=bucket.description,
            languages=", ".join(
                k for k in (self.cfg.get("languages") or ["python", "javascript"])
            ),
            frameworks=", ".join(self.cfg.get("frameworks") or []),
            source_context=full_source,
            flow_context=evidence.flow_context or "",
            endpoints_detail=evidence.endpoints_detail,
            openapi_context=openapi_context,
            resource_group=resource_group,
            required_sections=required_sections,
            required_diagrams=required_diagrams,
            coverage_targets=coverage_targets,
            sitemap_context=sitemap_context,
            dependency_links=dependency_links,
        )

        if failure_prefix:
            user_prompt = failure_prefix + "\n\n" + user_prompt

        if quality_feedback:
            user_prompt += (
                "\n\n## Quality Feedback From Previous Draft\n"
                "Revise the page to address these issues while staying grounded in the same evidence:\n"
                f"{quality_feedback}\n"
            )

        return self.llm.complete(SYSTEM_V2, user_prompt)


# ═════════════════════════════════════════════════════════════════════════════
# 3.5  Parallel Generation Orchestrator
# ═════════════════════════════════════════════════════════════════════════════

# Rate limiting constants — tuned for provisioned providers (Azure PTU, etc.)
# Override via .deepdoc.yaml: batch_size, max_parallel_workers
BATCH_SIZE = 10
RATE_LIMIT_PAUSE = 0.5  # seconds between batches (Azure rarely 429s within quota)
RATE_LIMIT_BACKOFF = 3.0  # initial backoff on 429; doubles each retry
MAX_RETRIES = 5
MAX_PARALLEL_WORKERS = 6  # LLM concurrency — safe for most Azure/OpenAI deployments


@dataclass
class GenerationResult:
    """Result of generating a single page."""

    bucket: DocBucket
    content: str | None = None
    validation: ValidationResult | None = None
    error: str | None = None
    elapsed_seconds: float = 0.0
    retries: int = 0
    degraded: bool = False
    mdx_compile_failed: bool = False
    mdx_compile_retries: int = 0
    mdx_fallback_applied: bool = False
    mdx_last_error: str | None = None


@dataclass
class GenerationSummary:
    """Aggregate summary for a generation run."""

    attempted: int = 0
    succeeded: int = 0
    failed: int = 0
    skipped: int = 0
    invalid: int = 0
    degraded: int = 0
    warnings_total: int = 0
    invalid_slugs: list[str] = field(default_factory=list)
    degraded_slugs: list[str] = field(default_factory=list)
    mdx_compile_retries_total: int = 0
    mdx_compile_retried_slugs: list[str] = field(default_factory=list)
    mdx_fallback_slugs: list[str] = field(default_factory=list)

    @property
    def status(self) -> str:
        if self.failed == 0 and self.invalid == 0 and self.degraded == 0:
            return "success"
        return "partial" if self.succeeded > 0 else "failed"


def summarize_generation_results(results: list[GenerationResult]) -> GenerationSummary:
    """Summarize successful, failed, and skipped generation results."""

    summary = GenerationSummary(attempted=len(results))
    for result in results:
        if result.error:
            summary.failed += 1
        elif result.content:
            summary.succeeded += 1
            validation = getattr(result, "validation", None)
            if validation:
                summary.warnings_total += len(validation.warnings)
                if not validation.is_valid:
                    summary.invalid += 1
                    summary.invalid_slugs.append(result.bucket.slug)
            if getattr(result, "degraded", False):
                summary.degraded += 1
                summary.degraded_slugs.append(result.bucket.slug)
            retries = getattr(result, "mdx_compile_retries", 0) or 0
            if retries:
                summary.mdx_compile_retries_total += retries
                summary.mdx_compile_retried_slugs.append(result.bucket.slug)
            if getattr(result, "mdx_fallback_applied", False):
                summary.mdx_fallback_slugs.append(result.bucket.slug)
        else:
            summary.skipped += 1
    return summary


def _coverage_entry(
    documented: int,
    total: int,
    uncovered: list[str],
) -> dict[str, Any]:
    percent = round((documented / total) * 100.0, 2) if total else 100.0
    return {
        "documented": documented,
        "total": total,
        "percent": percent,
        "uncovered": uncovered[:10],
    }


def _merge_frontmatter_fields(content: str, fields: dict[str, Any]) -> str:
    """Merge generated provenance fields without dropping existing frontmatter."""
    if not content:
        content = ""
    stripped = content.lstrip()
    prefix = content[: len(content) - len(stripped)]
    body = stripped
    existing_lines: list[str] = []
    if stripped.startswith("---"):
        lines = stripped.splitlines()
        try:
            end_idx = lines.index("---", 1)
        except ValueError:
            end_idx = -1
        if end_idx > 0:
            existing_lines = lines[1:end_idx]
            body = "\n".join(lines[end_idx + 1 :]).lstrip()

    managed = set(fields)
    kept = [
        line
        for line in existing_lines
        if line.strip().split(":", 1)[0] not in managed
    ]
    merged = ["---", *kept]
    for key, value in fields.items():
        if isinstance(value, list):
            if value:
                merged.append(f"{key}:")
                merged.extend(f"  - {json.dumps(item)}" for item in value)
            else:
                merged.append(f"{key}: []")
        else:
            merged.append(f"{key}: {json.dumps(value)}")
    merged.append("---")
    return prefix + "\n".join(merged) + "\n\n" + body


class BucketGenerationEngine:
    """Orchestrates parallel generation of all bucket pages with evidence assembly,
    single-pass generation, validation, post-processing, and graceful degradation.
    """

    def __init__(
        self,
        repo_root: Path,
        cfg: dict[str, Any],
        llm: LLMClient,
        scan: RepoScan,
        plan: DocPlan,
        output_dir: Path,
    ):
        self.repo_root = repo_root
        self.cfg = cfg
        self.llm = llm
        self.scan = scan
        self.plan = plan
        self.output_dir = output_dir
        self.assembler = EvidenceAssembler(repo_root, scan, plan, cfg)
        self.generator = PageGenerator(llm, cfg, repo_root)
        self.validator = PageValidator(repo_root, scan)
        self.max_workers = cfg.get("max_parallel_workers", MAX_PARALLEL_WORKERS)
        self.batch_size = cfg.get("batch_size", BATCH_SIZE)
        self.rate_limit_pause = cfg.get("rate_limit_pause", RATE_LIMIT_PAUSE)
        self._repo_file_paths = set(self.scan.file_summaries.keys())
        self.coverage_report: dict[str, Any] = {}
        self.local_dev_warnings: list[str] = []
        self._import_lookup = _build_import_lookup(set(self.scan.file_summaries.keys()))
        self._openapi_context = self._precompute_openapi_context()
        self._doc_pages = self._planned_doc_pages()
        (
            self._valid_doc_urls,
            self._doc_title_to_url,
            self._doc_alias_map,
        ) = build_internal_doc_link_maps(self._doc_pages)

    def _precompute_openapi_context(self) -> str:
        """Parse all available OpenAPI specs, accumulating up to 6 000 chars."""
        if not self.scan.has_openapi:
            return ""
        spec_count = len(self.scan.openapi_paths)
        per_spec_limit = max(2000, min(4000, 6000 // max(1, spec_count)))
        parts: list[str] = []
        total = 0
        for spec_path in self.scan.openapi_paths:
            spec = parse_openapi_spec(self.repo_root / spec_path)
            if spec:
                chunk = (
                    f"\n## OpenAPI Spec ({spec_path}):\n"
                    f"{spec_to_context_string(spec)[:per_spec_limit]}"
                )
                parts.append(chunk)
                total += len(chunk)
                if total >= 6000:
                    break
        return "\n".join(parts)

    def generate_all(self, force: bool = False) -> list[GenerationResult]:
        """Generate all pages. Returns results for each bucket.

        Strategy:
        - Sort buckets by priority
        - Within each priority group, generate pages in parallel
        - Apply rate limiting between batches
        - Validate and post-process each result
        """
        results: list[GenerationResult] = []
        buckets = sorted(self.plan.buckets, key=lambda b: b.priority)

        # Pre-build sitemap context (shared across all pages)
        sitemap_by_slug = self._precompute_sitemaps()

        total = len(buckets)
        generated_count = 0
        failed_count = 0
        stub_slugs: list[str] = []  # track pages that fell back to stubs

        from ..manifest import Manifest
        _manifest = Manifest(self.output_dir)

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            console=console,
        ) as progress:
            task = progress.add_task("Generating pages...", total=total)

            # Process in batches for rate limiting
            for batch_start in range(0, total, self.batch_size):
                batch = buckets[batch_start : batch_start + self.batch_size]

                # Use thread pool for parallel LLM calls within batch
                with ThreadPoolExecutor(
                    max_workers=min(self.max_workers, len(batch))
                ) as executor:
                    futures = {}
                    for bucket in batch:
                        progress.update(
                            task, description=f"[dim]Queuing {bucket.title}...[/dim]"
                        )

                        # Check staleness
                        if not force and not self._bucket_is_stale(bucket, _manifest):
                            results.append(
                                GenerationResult(bucket=bucket, content=None)
                            )
                            progress.advance(task)
                            continue

                        future = executor.submit(
                            self._generate_one,
                            bucket,
                            sitemap_by_slug.get(bucket.slug, ("", "")),
                        )
                        futures[future] = bucket

                    # Collect results as they complete
                    for future in as_completed(futures):
                        bucket = futures[future]
                        try:
                            result = future.result()
                            results.append(result)

                            if result.error:
                                failed_count += 1
                                console.print(
                                    f"  [red]✗[/red] [bold]{bucket.title}[/bold]: {result.error}"
                                )
                                if "stub" in (result.error or "").lower():
                                    stub_slugs.append(bucket.slug)
                            elif result.content:
                                generated_count += 1
                                word_count = len(result.content.split())
                                v = result.validation
                                warnings = ""
                                if v and v.warnings:
                                    warnings = f" [yellow]⚠ {len(v.warnings)} warning(s)[/yellow]"
                                if result.degraded:
                                    warnings += " [yellow]degraded[/yellow]"
                                if v and not v.is_valid:
                                    warnings += " [red]invalid[/red]"
                                diagrams = f" {v.mermaid_block_count}🔀" if v else ""
                                console.print(
                                    f"  [green]✓[/green] [bold]{bucket.title}[/bold] "
                                    f"[dim]({bucket.bucket_type} · "
                                    f"{len(bucket.owned_files)} files · "
                                    f"~{word_count} words{diagrams} · "
                                    f"{result.elapsed_seconds:.1f}s)[/dim]{warnings}"
                                )
                                # Save manifest incrementally so a cancelled run
                                # can resume from completed pages on next generate.
                                self._checkpoint_manifest(_manifest, result)
                        except Exception as e:
                            failed_count += 1
                            results.append(
                                GenerationResult(bucket=bucket, error=str(e))
                            )
                            console.print(
                                f"  [red]✗[/red] [bold]{bucket.title}[/bold]: {e}"
                            )

                        progress.advance(task)

                # Rate limit between batches
                if batch_start + self.batch_size < total and self.rate_limit_pause > 0:
                    time.sleep(self.rate_limit_pause)

        if failed_count > 0:
            console.print(f"[yellow]⚠ {failed_count} page(s) failed[/yellow]")

        console.print(f"[green]✓ Generated {generated_count}/{total} pages[/green]")

        # ── Stub page warning ─────────────────────────────────────────────
        # Collect stubs from all results (catches both LLM-failed stubs and
        # degraded pages that ended up as stubs after retry).
        all_stub_slugs = stub_slugs + [
            r.bucket.slug
            for r in results
            if r.error and "stub" in (r.error or "").lower()
            and r.bucket.slug not in stub_slugs
        ]
        if all_stub_slugs:
            console.print(
                Panel(
                    "[bold red]⚠  STUB PAGES DETECTED — DO NOT PUBLISH[/bold red]\n\n"
                    "The following pages failed to generate and contain stub content only.\n"
                    "They are marked with [bold]stub: true[/bold] in their frontmatter.\n\n"
                    + "\n".join(f"  • [yellow]{slug}[/yellow]" for slug in all_stub_slugs)
                    + "\n\n[dim]Re-run [bold]deepdoc generate[/bold] to retry these pages.[/dim]",
                    title="[red]Stub Pages",
                    border_style="red",
                )
            )

        self.local_dev_warnings = self._verify_local_dev_bucket()
        self.coverage_report = self._build_coverage_report(results)
        self._print_coverage_report(self.coverage_report)

        return results

    def _generate_one(
        self,
        bucket: DocBucket,
        sitemap_deps: tuple[str, str],
    ) -> GenerationResult:
        """Generate, validate, and post-process a single bucket page.

        This runs in a thread pool worker.
        """
        start = time.time()
        sitemap_context, dependency_links = sitemap_deps

        try:
            # Step 1: Assemble evidence
            evidence = self.assembler.assemble(bucket)
            degraded = False

            if evidence.files_compressed > 0:
                total_files = evidence.coverage_files_total
                console.print(
                    f'[yellow]⚠ bucket "{bucket.title}": '
                    f"{evidence.files_compressed} of {total_files} tracked files "
                    f"compressed into derived evidence cards[/yellow]"
                )

            # Step 2: Build OpenAPI context for endpoint pages
            openapi_context = ""
            hints = bucket.generation_hints or {}
            if hints.get("include_openapi") and self.scan.has_openapi:
                openapi_context = self._openapi_context

            # Step 3: Generate with retry
            content = self._call_with_retry(
                evidence, sitemap_context, dependency_links, openapi_context
            )

            # Step 4: Post-process
            content = fix_mermaid_diagrams(content)
            content = fix_file_references(
                content,
                self.repo_root,
                self._repo_file_paths,
                bucket.owned_files,
            )
            content = normalize_html_code_blocks(content)
            content = normalize_code_fence_languages(content)
            content = repair_split_object_code_fences(content)
            content = repair_unbalanced_code_fences(content)
            content = normalize_explanatory_lines_outside_fences(content)
            content = repair_dangling_plain_fences(content)
            content = normalize_mdx_steps(content)
            content = repair_mdx_component_blocks(content)
            content = escape_mdx_route_params(content)
            content = escape_mdx_text_hazards(content)
            content = repair_internal_doc_links(
                content,
                self._valid_doc_urls,
                self._doc_title_to_url,
                self._doc_alias_map,
            )

            # Step 5: Validate
            validation = self.validator.validate(content, bucket, evidence)

            # Step 6: Retry once on weak quality before degrading.
            if not validation.is_valid:
                quality_feedback = self._quality_feedback_to_instructions(validation)
                try:
                    content = self._call_with_retry(
                        evidence,
                        sitemap_context,
                        dependency_links,
                        openapi_context,
                        quality_feedback=quality_feedback,
                    )
                    content = fix_mermaid_diagrams(content)
                    content = fix_file_references(
                        content,
                        self.repo_root,
                        self._repo_file_paths,
                        bucket.owned_files,
                    )
                    content = normalize_html_code_blocks(content)
                    content = normalize_code_fence_languages(content)
                    content = repair_split_object_code_fences(content)
                    content = repair_unbalanced_code_fences(content)
                    content = normalize_explanatory_lines_outside_fences(content)
                    content = repair_dangling_plain_fences(content)
                    content = normalize_mdx_steps(content)
                    content = repair_mdx_component_blocks(content)
                    content = escape_mdx_route_params(content)
                    content = escape_mdx_text_hazards(content)
                    content = repair_internal_doc_links(
                        content,
                        self._valid_doc_urls,
                        self._doc_title_to_url,
                        self._doc_alias_map,
                    )
                    validation = self.validator.validate(content, bucket, evidence)
                except Exception:
                    pass

            # Step 6.5: Full clean regeneration with structured failure context.
            # The Step 6 retry appended feedback as a footnote ("revise this").
            # If that didn't work, start completely fresh with the failure
            # context promoted to the TOP of the prompt so the LLM cannot ignore it.
            if not validation.is_valid:
                failure_prefix = self._build_failure_prefix(validation)
                try:
                    console.print(
                        f"  [dim]↺ {bucket.title}: full regeneration pass (failure context injected)...[/dim]"
                    )
                    content = self._call_with_retry(
                        evidence,
                        sitemap_context,
                        dependency_links,
                        openapi_context,
                        failure_prefix=failure_prefix,
                    )
                    content = fix_mermaid_diagrams(content)
                    content = fix_file_references(
                        content,
                        self.repo_root,
                        self._repo_file_paths,
                        bucket.owned_files,
                    )
                    content = normalize_html_code_blocks(content)
                    content = normalize_code_fence_languages(content)
                    content = repair_split_object_code_fences(content)
                    content = repair_unbalanced_code_fences(content)
                    content = normalize_explanatory_lines_outside_fences(content)
                    content = repair_dangling_plain_fences(content)
                    content = normalize_mdx_steps(content)
                    content = repair_mdx_component_blocks(content)
                    content = escape_mdx_route_params(content)
                    content = escape_mdx_text_hazards(content)
                    content = repair_internal_doc_links(
                        content,
                        self._valid_doc_urls,
                        self._doc_title_to_url,
                        self._doc_alias_map,
                    )
                    validation = self.validator.validate(content, bucket, evidence)
                except Exception:
                    pass

            # Step 7: If validation still fails, apply text-only degradation fixes
            if not validation.is_valid:
                degraded = True
                content = self._apply_degradation_fixes(content, bucket, validation)
                # Re-validate after fixes
                validation = self.validator.validate(content, bucket, evidence)

            elapsed = time.time() - start

            # Step 8: Write to disk
            content = strip_leaked_provenance_fields(content)
            if evidence is not None and evidence.evidence_file_paths:
                content = inject_source_files_disclosure(
                    content, sorted(evidence.evidence_file_paths)
                )
            content = self._add_provenance_frontmatter(
                content,
                bucket,
                validation,
                evidence,
            )

            # Step 8.5: MDX compile gate — last-line guarantee that the file
            # will parse. Reprompts the LLM on compile error, falls back to
            # JSX-stripped Markdown if retries are exhausted.
            gate_outcome = self._run_mdx_compile_gate(content, bucket)
            content = gate_outcome.content
            if gate_outcome.fallback_also_failed:
                err = gate_outcome.last_error
                raise RuntimeError(
                    f"MDX compile gate: JSX-strip fallback also failed to compile for "
                    f"{bucket.title!r}: {err.short() if err else 'unknown error'}. "
                    "Page will be written as a stub to avoid a broken site build."
                )
            if gate_outcome.fallback_applied:
                degraded = True
                console.print(
                    f"  [yellow]⚠ {bucket.title}: MDX did not compile after "
                    f"{gate_outcome.retries} retry(ies); shipping JSX-stripped "
                    f"Markdown fallback.[/yellow]"
                )
            elif gate_outcome.retries:
                console.print(
                    f"  [dim]✓ {bucket.title}: recovered MDX after "
                    f"{gate_outcome.retries} fix retry(ies).[/dim]"
                )

            bucket_hints = bucket.generation_hints or {}
            filename = (
                "index.mdx"
                if bucket_hints.get("is_introduction_page")
                else f"{bucket.slug}.mdx"
            )
            doc_path = self.output_dir / filename
            doc_path.parent.mkdir(parents=True, exist_ok=True)
            doc_path.write_text(content, encoding="utf-8")

            if validation is not None and not validation.is_valid:
                console.print(
                    f"  [yellow]⚠ {bucket.title} still has validation issues after generation.[/yellow]"
                )

            return GenerationResult(
                bucket=bucket,
                content=content,
                validation=validation,
                elapsed_seconds=elapsed,
                degraded=degraded,
                mdx_compile_failed=gate_outcome.compile_failed,
                mdx_compile_retries=gate_outcome.retries,
                mdx_fallback_applied=gate_outcome.fallback_applied,
                mdx_last_error=(
                    gate_outcome.last_error.short()
                    if gate_outcome.last_error is not None
                    else None
                ),
            )

        except Exception as e:
            elapsed = time.time() - start
            # Graceful degradation: generate a stub page
            stub = self._generate_stub_page(bucket)
            stub = self._add_provenance_frontmatter(
                stub,
                bucket,
                None,
                None,
                status="stub",
            )
            bucket_hints = bucket.generation_hints or {}
            filename = (
                "index.mdx"
                if bucket_hints.get("is_introduction_page")
                else f"{bucket.slug}.mdx"
            )
            doc_path = self.output_dir / filename
            doc_path.parent.mkdir(parents=True, exist_ok=True)
            doc_path.write_text(stub, encoding="utf-8")

            return GenerationResult(
                bucket=bucket,
                content=stub,
                error=f"LLM failed, wrote stub: {e}",
                elapsed_seconds=elapsed,
            )

    @staticmethod
    def _is_retryable(err_str: str) -> bool:
        """Check if an error is transient and worth retrying."""
        markers = (
            "rate",
            "429",
            "overloaded",
            "timeout",
            "timed out",
            "502",
            "503",
            "504",
            "bad gateway",
            "service unavailable",
            "connection",
            "temporary",
            "throttl",
            "capacity",
            "server_error",
            "internal_error",
        )
        lower = err_str.lower()
        return any(m in lower for m in markers)

    def _call_with_retry(
        self,
        evidence: AssembledEvidence,
        sitemap_context: str,
        dependency_links: str,
        openapi_context: str,
        quality_feedback: str = "",
        failure_prefix: str = "",
    ) -> str:
        """Call LLM with exponential backoff + jitter on transient errors."""
        import random

        for attempt in range(MAX_RETRIES):
            try:
                return self.generator.generate(
                    evidence,
                    sitemap_context,
                    dependency_links,
                    openapi_context,
                    quality_feedback=quality_feedback,
                    failure_prefix=failure_prefix,
                )
            except Exception as e:
                err = str(e)
                is_last = attempt == MAX_RETRIES - 1

                if self._is_retryable(err):
                    if is_last:
                        raise
                    # Exponential backoff with jitter to avoid thundering herd
                    wait = RATE_LIMIT_BACKOFF * (2**attempt) + random.uniform(0, 1.5)
                    console.print(
                        f"    [yellow]⏳ Transient error ({evidence.bucket.title}) — "
                        f"waiting {wait:.1f}s (attempt {attempt + 1}/{MAX_RETRIES})...[/yellow]"
                    )
                    time.sleep(wait)
                else:
                    raise
        raise RuntimeError(f"Max retries exceeded for {evidence.bucket.title}")

    # ── MDX compile gate ─────────────────────────────────────────────────

    def _run_mdx_compile_gate(
        self, content: str, bucket: DocBucket
    ) -> GateOutcome:
        """Run the MDX compile gate on a single page.

        Wrapped in a try/except so environment failures (missing Node, npm
        install failure) downgrade to "skip the gate, ship as-is" rather than
        aborting the whole generation run. The downstream `pnpm build` will
        still surface MDX problems if any slip through.
        """
        try:
            return apply_mdx_compile_gate(content, self.llm, bucket)
        except Exception as exc:
            console.print(
                f"  [yellow]⚠ MDX compile gate unavailable for "
                f"{bucket.title}: {exc}. Shipping page unverified.[/yellow]"
            )
            return GateOutcome(content=content)

    # ── Graceful degradation ─────────────────────────────────────────────

    def _apply_degradation_fixes(
        self,
        content: str,
        bucket: DocBucket,
        validation: ValidationResult,
    ) -> str:
        """Attempt to fix validation failures without re-calling the LLM.

        Strategies:
        - Remove hallucinated paths
        - Add a notice if page is very short
        - Never fabricate completion markers for missing sections
        """
        # Fix 1: Remove hallucinated file paths (replace with just path, no line num)
        for path in validation.hallucinated_paths:
            content = content.replace(f"`{path}", "`[path-not-found]")

        # Fix 2: Add a notice for very short pages
        if validation.word_count < 100:
            notice = (
                '\n\n<Callout type="warn">\n'
                "This page was auto-generated with limited evidence. "
                "Some sections may be incomplete.\n"
                "</Callout>\n"
            )
            content = notice + content

        return content

    def _quality_feedback_to_instructions(
        self,
        validation: ValidationResult,
    ) -> str:
        """Translate validator warnings into direct LLM repair instructions."""
        instructions: list[str] = []
        if validation.missing_sections:
            instructions.append(
                "Add grounded content for these missing required sections: "
                + ", ".join(validation.missing_sections[:6])
            )
        if validation.placeholder_sections:
            instructions.append(
                "Replace every unresolved placeholder section with grounded prose; never emit TODO markers for: "
                + ", ".join(validation.placeholder_sections[:6])
            )
        if validation.missing_file_refs:
            instructions.append(
                "Reference these assigned source files where relevant; do not omit them: "
                + ", ".join(f"`{path}`" for path in validation.missing_file_refs[:6])
            )
        if validation.hallucinated_paths:
            instructions.append(
                "Remove every reference to these non-existent paths; do not guess replacements: "
                + ", ".join(f"`{path}`" for path in validation.hallucinated_paths[:6])
            )
        if validation.hallucinated_symbols:
            instructions.append(
                "Remove or correct these symbol names unless they appear exactly in evidence: "
                + ", ".join(f"`{name}`" for name in validation.hallucinated_symbols[:6])
            )
        if validation.out_of_evidence_refs:
            instructions.append(
                "Do not mention files outside this page's evidence scope: "
                + ", ".join(f"`{path}`" for path in validation.out_of_evidence_refs[:6])
            )
        if validation.unmatched_routes:
            instructions.append(
                "Remove or correct route claims that are not in scanned endpoint evidence: "
                + ", ".join(f"`{route}`" for route in validation.unmatched_routes[:6])
            )
            sample_valid = sorted(self.validator.known_route_paths)[:12]
            if sample_valid:
                instructions.append(
                    "Only reference these registered API routes (replace invented ones): "
                    + ", ".join(f"`{r}`" for r in sample_valid)
                )
            else:
                instructions.append(
                    "Remove route claims that are not registered in the scanned endpoint list."
                )
        for warning in validation.warnings[:8]:
            if warning and not any(warning in item for item in instructions):
                instructions.append(f"Address this validation issue: {warning}")
        return "\n".join(f"- {item}" for item in instructions[:10])

    def _build_failure_prefix(self, validation: ValidationResult) -> str:
        """Build a structured failure report to prepend at the TOP of the regeneration prompt.

        Unlike Step 6 which appends quality_feedback as a revision hint, this prefix is
        placed BEFORE all evidence so the LLM encounters it first and treats this call
        as a complete fresh generation, not a patch of a previous draft.
        """
        lines: list[str] = [
            "## ⚠ PREVIOUS GENERATION FAILED — COMPLETE REGENERATION REQUIRED",
            "",
            "The documentation page you are about to generate was already attempted once.",
            "That attempt was REJECTED by an automated validator. Do NOT revise a previous",
            "draft — write this page entirely from scratch using the evidence below.",
            "",
            "### Why the previous attempt was rejected:",
            "",
        ]

        if validation.missing_sections:
            lines.append(
                "**Missing required sections** (sections were either omitted or not populated):"
            )
            for s in validation.missing_sections[:8]:
                lines.append(f"  - {s}")
            lines.append(
                "  → You MUST include ALL required sections with grounded, non-placeholder content."
            )
            lines.append("")

        if validation.placeholder_sections:
            lines.append(
                "**Placeholder / TODO sections** (forbidden — page had unresolved stubs):"
            )
            for s in validation.placeholder_sections[:8]:
                lines.append(f"  - {s}")
            lines.append(
                "  → Replace every TODO/placeholder with real content drawn from evidence."
            )
            lines.append("")

        if validation.hallucinated_paths:
            lines.append(
                "**Hallucinated file paths** (paths referenced that do not exist in the repo):"
            )
            for p in validation.hallucinated_paths[:8]:
                lines.append(f"  - `{p}`")
            lines.append(
                "  → Only reference file paths that appear verbatim in the provided evidence."
            )
            lines.append("")

        if validation.missing_file_refs:
            lines.append(
                "**Missing file references** (assigned source files never mentioned):"
            )
            for p in validation.missing_file_refs[:8]:
                lines.append(f"  - `{p}`")
            lines.append(
                "  → Reference each assigned source file at least once where it is relevant."
            )
            lines.append("")

        if validation.hallucinated_symbols:
            lines.append(
                "**Hallucinated symbols** (function/class names not found in evidence):"
            )
            for sym in validation.hallucinated_symbols[:8]:
                lines.append(f"  - `{sym}`")
            lines.append(
                "  → Only name symbols that appear exactly in the provided source evidence."
            )
            lines.append("")

        if validation.unmatched_routes:
            lines.append(
                "**Unmatched API routes** (route claims not in scanned endpoint registry):"
            )
            for route in validation.unmatched_routes[:8]:
                lines.append(f"  - `{route}`")
            sample_valid = sorted(self.validator.known_route_paths)[:8]
            if sample_valid:
                lines.append(
                    "  → Registered routes you MAY reference: "
                    + ", ".join(f"`{r}`" for r in sample_valid)
                )
            else:
                lines.append("  → Remove all invented route claims.")
            lines.append("")

        if validation.out_of_evidence_refs:
            lines.append(
                "**Out-of-scope file references** (files outside this page's evidence boundary):"
            )
            for p in validation.out_of_evidence_refs[:8]:
                lines.append(f"  - `{p}`")
            lines.append(
                "  → Only discuss files that are explicitly part of this page's evidence set."
            )
            lines.append("")

        if validation.warnings:
            remaining = [
                w for w in validation.warnings[:8]
                if w and not any(
                    kw in w
                    for kw in ("missing section", "placeholder", "hallucinated", "route", "out-of-scope")
                )
            ]
            if remaining:
                lines.append("**Additional validator warnings:**")
                for w in remaining[:6]:
                    lines.append(f"  - {w}")
                lines.append("")

        lines += [
            "### What you MUST do differently this time:",
            "",
            "1. Write the page COMPLETELY from scratch — do not patch or copy a previous draft.",
            "2. Include ALL required sections listed above, each with substantive grounded content.",
            "3. Reference ONLY file paths and symbol names that appear in the evidence below.",
            "4. Never emit TODO, placeholder, or stub text.",
            "5. Stay strictly within the evidence boundary provided — do not invent facts.",
            "",
            "---",
            "",
            "Now generate the complete, corrected page:",
            "",
        ]

        return "\n".join(lines)

    def _generate_stub_page(self, bucket: DocBucket) -> str:
        """Generate a minimal stub page when LLM generation completely fails.

        Stubs are marked with ``stub: true`` in their frontmatter so the site
        builder can render a visual warning in the sidebar, and so CI/CD checks
        can refuse to publish a site that still contains stubs.
        """
        files_list = "\n".join(f"- `{f}`" for f in bucket.owned_files[:20])
        more = (
            f"\n- ... and {len(bucket.owned_files) - 20} more"
            if len(bucket.owned_files) > 20
            else ""
        )

        deps = ""
        if bucket.depends_on:
            deps = "\n## Related Pages\n" + "\n".join(
                f"- [{slug}](/{slug})" for slug in bucket.depends_on
            )

        return f"""---
stub: true
title: "{bucket.title}"
---

# {bucket.title}

<Callout type="warn">
This page could not be fully generated. It contains a file listing only.
Re-run `deepdoc generate` to retry.
</Callout>

## Description

{bucket.description}

## Source Files

{files_list}{more}
{deps}
"""

    def _add_provenance_frontmatter(
        self,
        content: str,
        bucket: DocBucket,
        validation: ValidationResult | None,
        evidence: AssembledEvidence | None,
        *,
        status: str | None = None,
    ) -> str:
        """Add or update DeepDoc provenance fields in MDX frontmatter."""
        status_value = status or (
            "valid" if validation is not None and validation.is_valid else "invalid"
        )
        evidence_files = (
            sorted(evidence.evidence_file_paths)
            if evidence is not None and evidence.evidence_file_paths
            else tracked_bucket_files(bucket)
        )
        evidence_records = self._build_page_evidence_records(evidence_files)
        fields: dict[str, Any] = {
            "deepdoc_generated_at": datetime.now(timezone.utc).isoformat(),
            "deepdoc_generated_commit": self._git_commit_short(),
            "deepdoc_generated_version": DEEPDOC_VERSION,
            "deepdoc_status": status_value,
            "deepdoc_evidence_files": evidence_files[:50],
            "deepdoc_evidence_records": evidence_records,
            "deepdoc_prereqs": bucket.depends_on,
        }
        return _merge_frontmatter_fields(content, fields)

    def _build_page_evidence_records(self, evidence_files: list[str]) -> list[dict[str, Any]]:
        """Build lightweight file evidence anchors for generated-page provenance."""
        records: list[dict[str, Any]] = []
        for idx, rel_path in enumerate(evidence_files[:50], start=1):
            path = self.repo_root / rel_path
            try:
                content = path.read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue
            lines = content.splitlines()
            records.append(
                {
                    "id": f"E{idx}",
                    "file_path": rel_path,
                    "start_line": 1 if lines else 0,
                    "end_line": len(lines),
                    "snippet_hash": hashlib.sha256(
                        content.encode("utf-8", errors="replace")
                    ).hexdigest()[:16],
                    "source_kind": self.scan.source_kind_by_file.get(rel_path, "unknown"),
                    "reason": "bucket evidence",
                }
            )
        return records

    def _git_commit_short(self) -> str:
        try:
            return subprocess.check_output(
                ["git", "rev-parse", "--short", "HEAD"],
                cwd=self.repo_root,
                text=True,
                stderr=subprocess.DEVNULL,
            ).strip()
        except Exception:
            return "unknown"

    def _verify_local_dev_bucket(self) -> list[str]:
        setup_signals = [
            path
            for path in self.scan.file_summaries
            if any(
                token in path.lower()
                for token in (
                    "dockerfile",
                    "docker-compose",
                    "makefile",
                    ".env",
                    "package.json",
                    "requirements",
                    "pyproject.toml",
                    "settings",
                    "config",
                )
            )
        ]
        if not setup_signals:
            return []
        bucket = next(
            (b for b in self.plan.buckets if b.slug == "local-development-setup"),
            None,
        )
        warnings: list[str] = []
        if bucket is None:
            warnings.append("Missing Start Here local-development-setup page")
            return warnings
        if bucket.section != "Start Here":
            warnings.append("local-development-setup is not in the Start Here section")
        tracked = set(bucket.owned_files) | set(bucket.artifact_refs)
        if not tracked.intersection(setup_signals):
            warnings.append(
                "local-development-setup has no setup/config evidence files attached"
            )
        if warnings:
            console.print(
                "[yellow]⚠ Local development setup verification: "
                + "; ".join(warnings)
                + "[/yellow]"
            )
        return warnings

    def _build_coverage_report(
        self,
        results: list[GenerationResult],
    ) -> dict[str, Any]:
        generated_text = "\n".join(result.content or "" for result in results)
        generated_lower = generated_text.lower()

        endpoints = self.scan.published_api_endpoints
        documented_endpoints: list[str] = []
        undocumented_endpoints: list[str] = []
        for endpoint in endpoints:
            method = str(endpoint.get("method", "")).upper()
            path = str(endpoint.get("path", ""))
            label = f"{method} {path}".strip()
            if path and (
                path.lower() in generated_lower or label.lower() in generated_lower
            ):
                documented_endpoints.append(label)
            elif label:
                undocumented_endpoints.append(label)

        tracked_files = sorted(
            {
                file_path
                for bucket in self.plan.buckets
                for file_path in tracked_bucket_files(bucket)
            }
        )
        documented_files = [
            file_path
            for file_path in tracked_files
            if file_path.lower() in generated_lower
        ]
        undocumented_files = [
            file_path for file_path in tracked_files if file_path not in documented_files
        ]

        public_symbols = sorted(self._public_symbol_names())
        referenced_symbols = [
            name
            for name in public_symbols
            if re.search(rf"`?{re.escape(name)}(?:\(\))?`?", generated_text)
        ]
        unreferenced_symbols = [
            name for name in public_symbols if name not in referenced_symbols
        ]

        report = {
            "api_endpoints": _coverage_entry(
                len(documented_endpoints),
                len(endpoints),
                undocumented_endpoints,
            ),
            "source_files": _coverage_entry(
                len(documented_files),
                len(tracked_files),
                undocumented_files,
            ),
            "public_symbols": _coverage_entry(
                len(referenced_symbols),
                len(public_symbols),
                unreferenced_symbols,
            ),
        }
        if self.local_dev_warnings:
            report["local_dev_warnings"] = self.local_dev_warnings
        return report

    def _public_symbol_names(self) -> set[str]:
        names: set[str] = set()
        for parsed in self.scan.parsed_files.values():
            for symbol in parsed.symbols:
                name = symbol.name
                if not name or name.startswith("_"):
                    continue
                names.add(name)
        return names

    def _print_coverage_report(self, report: dict[str, Any]) -> None:
        if not report:
            return
        lines = ["[bold]Coverage Report[/bold]"]
        for label, key in (
            ("API endpoints", "api_endpoints"),
            ("Source files", "source_files"),
            ("Public symbols", "public_symbols"),
        ):
            entry = report.get(key, {})
            lines.append(
                f"  {label}: [cyan]{entry.get('documented', 0)}/"
                f"{entry.get('total', 0)}[/cyan] documented "
                f"({entry.get('percent', 100.0):.0f}%)"
            )
            uncovered = entry.get("uncovered", [])
            if uncovered:
                lines.append(
                    "    [yellow]Uncovered:[/yellow] "
                    + ", ".join(f"`{item}`" for item in uncovered[:10])
                )
        if report.get("local_dev_warnings"):
            lines.append(
                "  [yellow]Local setup warnings:[/yellow] "
                + "; ".join(report["local_dev_warnings"])
            )
        console.print(
            Panel("\n".join(lines), title="DeepDoc Quality", border_style="cyan")
        )

    # ── Helpers ──────────────────────────────────────────────────────────

    def _precompute_sitemaps(self) -> dict[str, tuple[str, str]]:
        """Pre-build sitemap + dependency context for each bucket slug."""
        result: dict[str, tuple[str, str]] = {}

        # Build sitemap by section
        for bucket in self.plan.buckets:
            sitemap = self._build_sitemap_for(bucket.slug)
            deps = self._build_dependency_links_for(bucket)
            result[bucket.slug] = (sitemap, deps)

        return result

    def _planned_doc_pages(self) -> list[tuple[str, str]]:
        """Return planned titles mapped to their eventual site URLs."""
        pages: list[tuple[str, str]] = []
        for bucket in self.plan.buckets:
            hints = bucket.generation_hints or {}
            if hints.get("is_introduction_page"):
                url = "/"
            elif self.scan.has_openapi and (
                hints.get("is_endpoint_ref")
                or hints.get("prompt_style") == "endpoint_ref"
                or bucket.bucket_type == "endpoint_ref"
            ):
                url = f"/api/{bucket.slug}"
            else:
                url = f"/{bucket.slug}"
            pages.append((bucket.title, url))
        return pages

    def _bucket_url(self, b: DocBucket) -> str:
        """Return the site URL for a bucket, respecting endpoint_ref /api/* routing."""
        hints = b.generation_hints or {}
        if hints.get("is_introduction_page"):
            return "/"
        if self.scan.has_openapi and (
            hints.get("is_endpoint_ref")
            or hints.get("prompt_style") == "endpoint_ref"
            or b.bucket_type == "endpoint_ref"
        ):
            return f"/api/{b.slug}"
        return f"/{b.slug}"

    def _build_sitemap_for(self, current_slug: str) -> str:
        """Build formatted sitemap ordered by nav_structure, excluding current page."""
        slug_to_bucket = {b.slug: b for b in self.plan.buckets if b.slug != current_slug}
        lines: list[str] = []
        seen: set[str] = set()

        for section, slugs in self.plan.nav_structure.items():
            section_lines: list[str] = []
            for slug in slugs:
                b = slug_to_bucket.get(slug)
                if not b:
                    continue
                seen.add(slug)
                page_path = self._bucket_url(b)
                key_files = ", ".join(f"`{f}`" for f in b.owned_files[:4])
                if len(b.owned_files) > 4:
                    key_files += f" +{len(b.owned_files) - 4} more"
                section_lines.append(f"- [{b.title}]({page_path}) — {b.description}")
                if key_files:
                    section_lines.append(f"  *Covers: {key_files}*")
            if section_lines:
                lines.append(f"**{section}**")
                lines.extend(section_lines)

        # Buckets not referenced by nav_structure — group by section
        orphans_by_section: dict[str, list] = defaultdict(list)
        for slug, b in slug_to_bucket.items():
            if slug not in seen:
                orphans_by_section[b.section or "Other"].append(b)
        for section, orphan_buckets in orphans_by_section.items():
            lines.append(f"**{section}**")
            for b in orphan_buckets:
                lines.append(f"- [{b.title}]({self._bucket_url(b)}) — {b.description}")

        return "\n".join(lines) if lines else "(no other pages)"

    def _build_dependency_links_for(self, bucket: DocBucket) -> str:
        """Build dependency links from explicit depends_on + import analysis."""
        slug_to_bucket = {b.slug: b for b in self.plan.buckets}
        related: dict[str, DocBucket] = {}
        bucket_files = set(bucket.owned_files)

        # Explicit depends_on
        for dep_slug in bucket.depends_on:
            if dep_slug in slug_to_bucket and dep_slug != bucket.slug:
                related[dep_slug] = slug_to_bucket[dep_slug]

        # Import-based: find buckets whose files are imported by this bucket's files.
        # Uses the pre-built import lookup (O(imports) per file) instead of scanning
        # all repo files for each import string.
        file_to_buckets: dict[str, list[DocBucket]] = defaultdict(list)
        for b in self.plan.buckets:
            for f in b.owned_files:
                file_to_buckets[f].append(b)

        for src_file in bucket.owned_files[:15]:
            parsed = self.scan.parsed_files.get(src_file)
            if not parsed or not parsed.imports:
                continue
            for imp in parsed.imports:
                for hint in _normalize_import(imp):
                    key = hint.replace(".", "/").lower().strip("/")
                    if not key:
                        continue
                    matched_files = self._import_lookup.get(key, set())
                    if len(matched_files) > 5:
                        continue  # ambiguous — too many matches to be useful
                    for matched_file in matched_files:
                        for linked_bucket in file_to_buckets.get(matched_file, []):
                            if linked_bucket.slug != bucket.slug:
                                related[linked_bucket.slug] = linked_bucket

        # Strong overlap-based links for database/runtime/interface pages
        for candidate in self.plan.buckets:
            if candidate.slug == bucket.slug:
                continue
            hints = candidate.generation_hints or {}
            if not (
                hints.get("is_database_overview")
                or hints.get("is_database_group")
                or hints.get("is_runtime_overview")
                or hints.get("runtime_group_kind")
                or hints.get("prompt_style") == "graphql"
            ):
                continue
            if bucket_files & set(candidate.owned_files):
                related[candidate.slug] = candidate

        if not related:
            return ""

        lines = [
            "**Dependency Links** (pages this module imports from — MUST link to these):"
        ]
        for b in related.values():
            lines.append(f"- [{b.title}]({self._bucket_url(b)}) — {b.description}")

        return "\n".join(lines)

    def _bucket_is_stale(self, bucket: DocBucket, manifest: Any = None) -> bool:
        """Check if any source file for this bucket has changed since last generation."""
        from ..manifest import Manifest

        if manifest is None:
            manifest = Manifest(self.output_dir)

        for src_file in tracked_bucket_files(bucket):
            src_path = self.repo_root / src_file
            if not src_path.exists():
                continue
            try:
                content = src_path.read_text(encoding="utf-8", errors="replace")
                if manifest.is_stale(src_file, content):
                    return True
            except Exception:
                return True
        return False

    def _checkpoint_manifest(self, manifest: Any, result: "GenerationResult") -> None:
        """Write the manifest for one completed page so a cancelled run can resume."""
        from ..manifest import file_hash as compute_hash
        try:
            for src_file in tracked_bucket_files(result.bucket):
                src_path = self.repo_root / src_file
                if src_path.exists():
                    content = src_path.read_text(encoding="utf-8", errors="replace")
                    manifest.update(src_file, compute_hash(content), result.bucket.slug)
            manifest.save()
        except Exception:
            pass

    def update_manifest(self, results: list[GenerationResult]):
        """Update the manifest with new file hashes for all successfully generated pages."""
        from ..manifest import Manifest, file_hash as compute_hash

        manifest = Manifest(self.output_dir)

        for result in results:
            if result.content and not result.error:
                for src_file in tracked_bucket_files(result.bucket):
                    src_path = self.repo_root / src_file
                    if src_path.exists():
                        try:
                            content = src_path.read_text(
                                encoding="utf-8", errors="replace"
                            )
                            manifest.update(
                                src_file, compute_hash(content), result.bucket.slug
                            )
                        except Exception:
                            pass
        manifest.save()
