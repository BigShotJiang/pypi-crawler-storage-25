# Backwards compatibility: re-export from new location
from ..client.exception import ApiException, AuthenticationFailedException, UnknownException  # noqa: F401
