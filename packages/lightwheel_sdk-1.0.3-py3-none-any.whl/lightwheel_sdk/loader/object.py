# Copyright 2025 Lightwheel Team
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from pathlib import Path
import zipfile
from urllib.parse import unquote, urlparse
import requests
import uuid

from ..client.exception import ApiException
from ..client.client import LightwheelClient
from .file_lock import FileLock

CACHE_PATH = Path("~/.cache/lightwheel_sdk/object/").expanduser()
CACHE_PATH.mkdir(parents=True, exist_ok=True)


class RegistryQuery:
    """
    Query for registry.
    MustHave: registry_type, file_type
    """

    def __init__(self, registry_type: str, registry_name: list[str] = [], exclude_registry_name: list[str] = [], equals: dict = None, contains: dict = None):
        """Registry Parameter Controller

        Args:
            registry_type (str): objects/fixtures/textures
            registry_name (list[str], optional): _description_. Defaults to [].
            exclude_registry_name (list[str], optional): _description_. Defaults to [].
            equals (dict, optional): _description_. Defaults to {}.
            contains (dict, optional): _description_. Defaults to {}.
        """
        if registry_type not in ["objects", "fixtures", "textures"]:
            raise ValueError("Invalid registry type")
        self.registry_type = registry_type
        self.registry_name = registry_name
        self.exclude_registry_name = exclude_registry_name
        self.eqs = []
        if equals is not None:
            for key, value in equals.items():
                self.eqs.append({"key": key, "value": value})
        self.contains_list = []
        if contains is not None:
            for key, value in contains.items():
                self.contains_list.append({"key": key, "value": value})

    def query_file(self, file_type: str, file_name: str = "", source: list[str] = [], projects: list[str] = [], quality_levels: list[int] = []):
        """Query for a file in the registry

        Args:
            file_type (str): USD/MJCF
            file_name (str, optional): _description_. Defaults to "".
            source (list[str], optional): _description_. Defaults to [].
            projects (list[str], optional): _description_. Defaults to [].
            quality_levels (list[int], optional): _description_. Defaults to [], BASIC = 1, GOOD = 2.
        """
        file_type_to_enum = {"USD": 1, "MJCF": 2, "other": 3}
        file_type_enum = file_type_to_enum.get(file_type, "")
        if file_type_enum == "":
            raise ValueError(f"Invalid file type: {file_type}")
        query_dict = {
            "file_type": file_type_enum,
            "registry_type": self.registry_type,
            "eq": self.eqs,
            "contain": self.contains_list,
        }
        if len(source) > 0:
            query_dict["source"] = source
        if len(self.registry_name) > 0:
            query_dict["registry_name"] = self.registry_name
        if len(self.exclude_registry_name) > 0:
            query_dict["exclude_registry_name"] = self.exclude_registry_name
        if file_name != "":
            query_dict["file_name"] = file_name
        if len(projects) > 0:
            query_dict["project_names"] = projects
        if len(quality_levels) > 0:
            query_dict["quality_levels"] = quality_levels
        return query_dict


class ObjectLoader:
    """
    Load an object from the floorplan service.

    Args:
        host (str): The host of the API
    """

    def __init__(self, client: LightwheelClient):
        self.client = client
        self.version_cache = []

    def acquire_by_registry(
        self,
        registry_type: str,
        registry_name: list[str] = [],
        exclude_registry_name: list[str] = [],
        eqs: dict = None,
        contains: dict = None,
        file_type: str = "USD",
        file_name: str = "",
        source: list[str] = [],
        projects: list[str] = [],
        quality_levels: list[int] = [],
    ):
        """Acquire an object from the registry

        Args:
            registry_type (str, must have): objects/fixtures/textures
            registry_name (list[str], optional): asset categories, e.g. "bowl", "cup". Defaults to [].
            exclude_registry_name (list[str], optional): asset categories to exclude, e.g. "old_bowl". Defaults to [].
            eqs (dict, optional): key-value pairs to filter by asset category properties, e.g. {"color": "blue"}. Defaults to {}.
            contains (dict, optional): key-value pairs to filter by asset category properties, e.g. {"material": "plastic"}. Defaults to {}.
            file_type (str, optional): USD/MJCF. Defaults to "USD".
            file_name (str, optional): file name to filter by, e.g. "bowl_001". Defaults to "".
            source (list[str], optional): source to filter by, e.g. ["lightwheel"]. Defaults to []. Projects can be filtered by source.
            projects (list[str], optional): projects to filter by, e.g. ["LiAuto", "TestProject"]. Defaults to []. Sources can be filtered by project.
            quality_levels (list[int], optional): quality levels to filter by, e.g. [1, 2]. Defaults to [], BASIC = 1, GOOD = 2.
        """
        q = RegistryQuery(registry_type, registry_name, exclude_registry_name, eqs, contains)
        data = q.query_file(file_type, file_name, source, projects, quality_levels)
        res = self.client.post("/floorplan/v1/registry/get-object", data=data)
        object_res = res.json()
        file_path, object_name = self.download_to_cache(res)
        del object_res["fileUrl"]
        return file_path, object_name, object_res

    def acquire_by_file_version(self, file_version_id: str):
        res = self.client.post("/floorplan/v1/object/version-get", data={"id": file_version_id}, timeout=300)
        object_res = res.json()
        file_path, object_name = self.download_to_cache(res)
        del object_res["fileUrl"]
        return file_path, object_name, object_res

    def list_registry(self):
        res = self.client.post("/floorplan/v1/registry/list", data={})
        return res.json()["data"]

    def acquire_object(self, rel_path, file_type: str, version=None):
        """
        DEPRECATED! Use acquire_by_registry instead.
        """
        try:
            return self._acquire_object(rel_path, file_type, version)
        except ApiException as e:
            print(e)
        finally:
            pass

    def _acquire_object(self, rel_path, file_type: str, version=None):
        """
        Acquire an object from the floorplan.

        Args:
            levels (list[str]): The levels of the object
            file_type (str): The type of the object, USD, MJCF
        """
        rel_path = rel_path.strip("/")
        levels = rel_path.split("/")
        file_type_to_enum = {"USD": 1, "MJCF": 2}
        if len(levels) > 6 or len(levels) == 0:
            raise ValueError(f"Invalid levels number: {len(levels)}")
        file_type_enum = file_type_to_enum.get(file_type, "")
        if file_type_enum == "":
            raise ValueError(f"Invalid file type: {file_type}")
        if version:
            usd_path, object_name, res = self.acquire_by_file_version(version)
        else:
            filename = rel_path.split("/")[-1]
            registry_name = rel_path.split("/")[-2]
            source = [rel_path.split("/")[-3]]
            usd_path, object_name, res = self.acquire_by_registry("objects", file_type=file_type, file_name=filename, registry_name=[registry_name], source=source)
        self.version_cache.append({object_name: res.get("fileVersionId", None)})
        return usd_path

    def download_to_cache(self, res):
        object_type, object_name, s3_url, cache_file_path = self.get_object_type_and_path(res)
        with FileLock(cache_file_path.with_suffix(".lock")):
            object_dir_path = CACHE_PATH / object_name
            file_version_id = self._get_file_version_id_for_lock(res)
            file_version_path = object_dir_path / f"{file_version_id}.txt"
            if not file_version_path.exists():
                r = requests.get(
                    s3_url,
                    timeout=300,
                    headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3"},
                )
                if r.status_code != 200:
                    raise ApiException(r)
                with open(cache_file_path, "wb") as f:
                    f.write(r.content)
                with zipfile.ZipFile(cache_file_path, "r") as zip_ref:
                    zip_ref.extractall(CACHE_PATH)
                with open(file_version_path, "w") as f:
                    pass
            if object_type == "USD":
                return str(object_dir_path / (object_name + ".usd")), object_name
            elif object_type == "MJCF":
                return str(object_dir_path / "model.xml"), object_name
            else:
                raise ValueError(f"Invalid object type: {object_type}")

    def get_object_type_and_path(self, res):
        res_json = res.json()
        s3_url = res_json["fileUrl"]
        url_path = urlparse(s3_url).path
        url_path = unquote(url_path)
        path_list = url_path.strip("/").split("/")
        object_file_path = path_list[-1]
        object_name = object_file_path.split(".")[0]
        object_type = "USD"
        return object_type, object_name, s3_url, CACHE_PATH / object_file_path

    def _get_file_version_id_for_lock(self, res):
        res_json = res.json()
        return res_json.get("fileVersionId", str(uuid.uuid4()))
