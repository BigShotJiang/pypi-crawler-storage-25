# Backwards compatibility: re-export from new location
from ..client.client import LightwheelClient  # noqa: F401
