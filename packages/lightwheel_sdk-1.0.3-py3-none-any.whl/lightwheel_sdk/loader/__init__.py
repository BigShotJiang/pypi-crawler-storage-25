# Copyright 2025 Lightwheel Team
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from ..client import lw_client, login_manager
from .object import ObjectLoader
from .floorplan import FloorplanLoader
from .scene import SceneLoader

object_loader = ObjectLoader(lw_client)
floorplan_loader = FloorplanLoader(lw_client)
scene_loader = SceneLoader(lw_client)
