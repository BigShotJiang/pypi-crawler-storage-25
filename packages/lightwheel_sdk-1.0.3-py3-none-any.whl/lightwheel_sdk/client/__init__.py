import os
from .client import LightwheelClient
from .login import Login

ENDPOINT = os.environ.get("LW_API_ENDPOINT", "https://api.lightwheel.net")
lw_client = LightwheelClient(host=ENDPOINT)
login_manager = Login(lw_client)
