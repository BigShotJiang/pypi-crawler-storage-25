import uuid
from ..client.client import LightwheelClient
from ..logger import get_logger


class FloorplanUploader:
    """
    Uploader for floorplan USD bundles.

    Args:
        client (LightwheelClient): The client to use for the uploader
    """

    def __init__(self, client: LightwheelClient):
        self.client = client
        self.logger = get_logger("lightwheel_sdk.loader.floorplan_uploader")

    def create_bundle(
        self,
        file_name: str,
        data_path: str,
        *,
        bundle_uuid: str = None,
        layout_uuid: str = None,
        style_uuid: str = None,
        s3_bucket_type: int = None,
    ):
        """
        Create a floorplan USD bundle.

        Args:
            file_name (str): The file name of the bundle.
            data_path (str): The S3 data path of the bundle.
            version (str): The version of the bundle.
            bundle_uuid (str, optional): The UUID of the bundle. If not provided, a new UUID will be generated.
            layout_uuid (str, optional): The layout UUID.
            style_uuid (str, optional): The style UUID.
            s3_bucket_type (int, optional): The S3 bucket type.
        """
        if bundle_uuid is None:
            bundle_uuid = str(uuid.uuid4())
        data = {
            "uuid": bundle_uuid,
            "file_name": file_name,
            "data_path": data_path,
        }
        if layout_uuid is not None:
            data["layout_uuid"] = layout_uuid
        if style_uuid is not None:
            data["style_uuid"] = style_uuid
        if s3_bucket_type is not None:
            data["s3_bucket_type"] = s3_bucket_type
        self.logger.info(f"Creating bundle {bundle_uuid}")
        print(data)

        self.client.post("/floorplan/v1/usd/create", data=data)
        return bundle_uuid

    def update_config(self, floorplan2usd_image: str = None):
        """
        Update config for floorplan2usd.

        Args:
            floorplan2usd_image (str, optional): The floorplan2usd docker image.
        """
        data = {}
        if floorplan2usd_image is not None:
            data["floorplan2usd_image"] = floorplan2usd_image
        self.client.post("/floorplan/v1/usd/update-config", data=data)

    def floorplan2usd(
        self,
        layout_id: int,
        style_id: int,
        scene: str,
        backend: str,
        svn: int,
        docker_image: str,
    ):
        """
        Trigger floorplan to USD conversion.

        Args:
            layout_id (int): The layout ID.
            style_id (int): The style ID.
            scene (str): The scene name.
            backend (str): The backend name.
            svn (int): The SVN number.
            docker_image (str): The docker image to use.

        Returns:
            str: The batch name.
        """
        data = {
            "layout_id": layout_id,
            "style_id": style_id,
            "scene": scene,
            "backend": backend,
            "svn": svn,
            "docker_image": docker_image,
        }
        self.logger.info(
            f"Triggering floorplan2usd for layout={layout_id}, style={style_id}"
        )
        res = self.client.post("/floorplan/v1/usd/floorplan2usd", data=data)
        return res.json()["batchName"]
