from lightwheel_sdk.client import login_manager
from lightwheel_sdk.loader import scene_loader
from lightwheel_sdk.uploader import scene_uploader, floorplan_uploader

# 1. Login
login_manager.login()

# # 2. Create scene with test.yaml
# scene_uploader.create_scene(
#     scene_type="layout",
#     index=1,
#     local_path="test.yaml",
#     name="cloudtest",
#     backend="aigen",
# )
# print("Scene created")

# # 3. Get scene to retrieve its id
# scene_id, scene_data = scene_loader.get_scene(
#     scene_type="layout",
#     index=1,
#     name="cloudtest",
#     backend="aigen",
# )
# print(f"Scene ID: {scene_id}")

# 4. Create a floorplan bundle
bundle_uuid = floorplan_uploader.create_bundle(
    file_name="test.usd",
    data_path="test",
)
print(f"Bundle created with UUID: {bundle_uuid}")
