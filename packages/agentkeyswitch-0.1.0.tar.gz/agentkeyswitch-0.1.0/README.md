# agentkeyswitch

`agentkeyswitch` is a Linux-first CLI for switching API profiles used by local AI agents such as Claude Code and Codex.

It keeps your reusable profiles in one local store and applies them to the real config files only when you run a switch command.

## Current scope

- Linux only
- Supported agents:
  - `claude`
  - `codex`
- Supported commands:
  - `agswitch list`
  - `agswitch status`
  - `agswitch add <profile>`
- `agswitch import <profile>`
- `agswitch import-existing`
- `agswitch use <agent> <profile>`
- `agswitch remove <profile>`
- `agswitch help [command]`

## Install

```bash
pip install agentkeyswitch
```

For local development:

```bash
pip install -e .
```

## Profile store

Profiles are stored at:

```text
~/.config/agentkeyswitch/profiles.json
```

You can override the runtime locations with environment variables:

- `AGSWITCH_HOME`
- `AGSWITCH_STORE`
- `XDG_CONFIG_HOME`

This is mainly useful for testing or migration.

## Examples

Add a profile interactively:

```bash
agswitch add max
```

Add a profile non-interactively:

```bash
agswitch add taiji \
  --agent all \
  --claude-token 'xxx' \
  --claude-base-url 'https://taijiai.online/v1' \
  --claude-model 'opus' \
  --codex-key 'xxx' \
  --codex-base-url 'https://taijiai.online/v1' \
  --codex-provider 'taiji'
```

Import the current live configs into a reusable profile:

```bash
agswitch import max --agent all
```

Batch import your existing named files:

```bash
agswitch import-existing
```

Also include the current live config as `current`:

```bash
agswitch import-existing --include-current
```

Switch Claude only:

```bash
agswitch use claude max
```

Switch both Claude and Codex:

```bash
agswitch use all taiji
```

Check current live status:

```bash
agswitch status
```

Show detailed help:

```bash
agswitch help
agswitch help use
```

## What gets changed

`claude`

- `~/.claude/settings.json`

`codex`

- `~/.codex/auth.json`
- `~/.codex/config.toml`

Named files discovered by `import-existing`

- `~/.claude/settings - *.json`
- `~/.codex/auth - *.json`

The tool updates only the necessary fields and keeps unrelated settings intact. Before writing, it creates timestamped backups under:

```text
~/.config/agentkeyswitch/backups/
```

## Notes

- Secrets are not bundled with the package.
- The package is designed so you can publish the code without publishing your tokens.
- For Codex, the tool updates both `auth.json` and `config.toml` so provider selection remains consistent.
