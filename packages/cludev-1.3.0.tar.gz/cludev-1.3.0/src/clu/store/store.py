"""Local state store facade."""


import sqlite3
from typing import Self

from clu.store.database import open_connection
from clu.store.message_repository import MessageRepository
from clu.store.session_repository import SessionRepository


class Store:
    """Facade that groups local state repositories under one connection."""

    def __init__(self, db: sqlite3.Connection) -> None:
        """Create the store facade from an open SQLite connection."""
        self._db = db
        self.sessions = SessionRepository(db=db)
        self.messages = MessageRepository(db=db)

    @classmethod
    def open(cls) -> Self:
        """Open the local state database."""
        return cls(db=open_connection())

    def commit(self) -> None:
        """Commit the current transaction."""
        self._db.commit()

    def close(self) -> None:
        """Close the underlying SQLite connection."""
        self._db.close()

    def __enter__(self) -> Self:
        """Enter a context manager."""
        return self

    def __exit__(self, exc_type: type[BaseException] | None, *exc: object) -> None:
        """Commit on success, then close the database."""
        if exc_type is None:
            self._db.commit()
        self.close()
