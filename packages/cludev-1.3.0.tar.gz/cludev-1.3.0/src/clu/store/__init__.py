"""Local state store facade."""

from clu.store.store import Store

__all__ = ["Store"]
