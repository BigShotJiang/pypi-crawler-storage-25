"""SQLite connection management for local state."""


import sqlite3

from clu.config import ensure_dir
from clu.store.migrations import apply_migrations


def open_connection() -> sqlite3.Connection:
    """Open the local SQLite database and apply schema migrations."""
    directory = ensure_dir()
    db = sqlite3.connect(
        str(directory / "state.db"),
        detect_types=sqlite3.PARSE_DECLTYPES | sqlite3.PARSE_COLNAMES,
    )
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA journal_mode=WAL")
    apply_migrations(db)
    return db
