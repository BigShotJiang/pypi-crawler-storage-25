"""SQLite schema migrations for local state.

Each statement uses CREATE TABLE IF NOT EXISTS with the full final schema,
so migrations are idempotent and safe to re-run on every connection open.
"""


import sqlite3

MIGRATIONS: list[str] = [
    """CREATE TABLE IF NOT EXISTS sessions (
        id TEXT PRIMARY KEY,
        agent TEXT NOT NULL,
        path TEXT NOT NULL,
        is_git_repo BOOLEAN DEFAULT 1,
        git_remote_url TEXT DEFAULT '',
        start_time INTEGER NOT NULL,
        end_time INTEGER DEFAULT 0,
        active BOOLEAN DEFAULT 1,
        transcript_path TEXT DEFAULT '',
        transcript_parsing_watermark INTEGER DEFAULT 0,
        dirty BOOLEAN DEFAULT 1
    )""",
    """CREATE TABLE IF NOT EXISTS session_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        uuid TEXT NOT NULL DEFAULT '',
        parent_uuid TEXT DEFAULT '',
        session_id TEXT NOT NULL REFERENCES sessions(id),
        turn_index INTEGER NOT NULL,
        role TEXT NOT NULL,
        content TEXT NOT NULL DEFAULT '',
        tool_calls TEXT NOT NULL DEFAULT '',
        tool_results TEXT NOT NULL DEFAULT '',
        model TEXT DEFAULT '',
        timestamp INTEGER DEFAULT 0,
        cwd TEXT DEFAULT '',
        input_tokens INTEGER DEFAULT 0,
        output_tokens INTEGER DEFAULT 0,
        cache_read_tokens INTEGER DEFAULT 0,
        cache_write_tokens INTEGER DEFAULT 0,
        dirty BOOLEAN DEFAULT 1,
        UNIQUE(session_id, turn_index),
        UNIQUE(uuid)
    )""",
]


def apply_migrations(db: sqlite3.Connection) -> None:
    """Apply schema migrations (idempotent)."""
    for sql in MIGRATIONS:
        db.execute(sql)
    db.commit()
