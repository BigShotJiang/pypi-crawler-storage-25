"""clu — local session capture and backend sync for AI-assisted development."""

import importlib.metadata

try:
    __version__ = importlib.metadata.version("cludev")
except importlib.metadata.PackageNotFoundError:
    __version__ = "0.0.0"
