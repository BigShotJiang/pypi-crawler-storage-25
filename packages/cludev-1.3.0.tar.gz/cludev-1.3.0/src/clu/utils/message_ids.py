"""Stable identifier helpers for transcript messages."""

from uuid import NAMESPACE_URL, uuid5


def build_message_uuid(*, session_id: str, turn_index: int) -> str:
    """Build a stable UUID for a transcript message."""
    return str(uuid5(NAMESPACE_URL, f"{session_id}:{turn_index}"))
