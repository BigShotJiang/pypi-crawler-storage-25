"""Secret redaction helpers."""


def redact_secret(secret: str) -> str:
    """Return a safely redacted representation of a secret string."""
    if not secret:
        return ""
    if len(secret) <= 8:
        return "********"
    return secret[:4] + "..." + secret[-4:]
