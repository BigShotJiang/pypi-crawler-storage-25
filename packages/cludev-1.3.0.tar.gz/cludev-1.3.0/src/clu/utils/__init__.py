"""Reusable helper functions shared across the CLI."""
