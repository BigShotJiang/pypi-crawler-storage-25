"""Config viewing services."""

import tomli_w

from clu import config as cfg_mod
from clu.utils.redaction import redact_secret


def render_config_view() -> str:
    """Render the current config with secrets redacted."""
    config = cfg_mod.load()
    redacted = config.model_copy(deep=True)
    redacted.auth.session.access_token = redact_secret(secret=redacted.auth.session.access_token)
    redacted.auth.session.refresh_token = redact_secret(secret=redacted.auth.session.refresh_token)

    path = cfg_mod.config_path()
    body = tomli_w.dumps(redacted.model_dump(mode="python"))
    return f"Config file: {path}\n\n{body}"
