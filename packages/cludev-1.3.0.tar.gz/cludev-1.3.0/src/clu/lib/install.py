"""Installation services."""


import os
import sys

from clu import config as cfg_mod
from clu.adapter import detect_adapters, get_adapter


def run_install(*, global_: bool, agent: str) -> list[str]:
    """Initialize config and install agent hooks."""
    lines = ["Setting up clu..."]

    directory = cfg_mod.ensure_dir()
    lines.append(f"  Config directory: {directory}")

    config = cfg_mod.load()
    cfg_mod.save(cfg=config)
    lines.append("  Configuration initialized.")

    detected = detect_adapters()
    lines.append("  Detecting AI agents...")
    if not detected:
        lines.append("  No supported AI agents detected.")
    for adapter in detected:
        lines.append(f"  Found: {adapter.name()}")

    selected_agent = agent
    if not selected_agent:
        if not detected:
            raise RuntimeError("no agents detected and --agent not specified")
        if len(detected) > 1:
            raise RuntimeError("multiple agents detected; pass --agent explicitly")
        selected_agent = detected[0].name()

    adapter = get_adapter(selected_agent)
    adapter.install_hooks(
        project_dir=os.getcwd(),
        global_=global_,
        clu_binary=os.path.abspath(sys.argv[0]),
    )

    lines.append(f"  Installing {selected_agent} event hooks...")
    lines.append("  Event hooks installed.")
    lines.append("")
    lines.append("clu installed successfully.")
    lines.append("Run `clu auth login` to authenticate with the backend.")
    return lines


