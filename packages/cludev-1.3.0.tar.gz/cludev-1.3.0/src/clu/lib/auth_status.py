"""Authentication status service."""

from clu.api import AuthClient
from clu.models.auth_status import AuthStatus


def get_auth_status() -> AuthStatus:
    """Fetch the current authenticated user profile."""
    return AuthClient().get_auth_status()
