"""Hook append service."""

import os
import sys

from clu.adapter import get_adapter
from clu.lib.event_dispatch import dispatch_event
from clu.lib.hook_log import log_hook_event
from clu.store import Store


def append_hook_event(*, agent: str) -> list[str]:
    """Read a hook event from stdin and store it locally."""
    try:
        payload = sys.stdin.read().strip()
    except Exception as error:
        return [f"clu: reading stdin: {error}"]

    if not payload:
        return []

    cwd = os.getcwd()

    try:
        adapter = get_adapter(agent)
    except KeyError:
        return [f"clu: unknown agent: {agent}"]

    native_event_type, event = adapter.parse_hook_payload(payload)

    log_hook_event(
        agent=agent,
        native_event_type=native_event_type,
        dispatched_event=type(event).__name__,
    )

    try:
        db = Store.open()
    except Exception as error:
        return [f"clu: opening state db: {error}"]

    messages: list[str] = []
    with db:
        try:
            dispatch_event(
                event=event, adapter=adapter, db=db, agent=agent, cwd=cwd,
            )
        except Exception as error:
            messages.append(f"clu: lifecycle handling: {error}")

    return messages
