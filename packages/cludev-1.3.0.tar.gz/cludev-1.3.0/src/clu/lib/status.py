"""Status reporting services."""


from clu.store import Store


def render_status() -> list[str]:
    """Render install state, sessions, and pending work."""
    try:
        db = Store.open()
    except Exception as error:
        return [f"Warning: cannot open state db: {error}"]

    with db:
        try:
            sessions = db.sessions.active_all()
            pending_sessions = db.sessions.dirty_count()
            pending_messages = db.messages.dirty_count()
        except Exception as error:
            return [f"Warning: cannot read state: {error}"]

    lines = ["", f"Active sessions: {len(sessions)}"]
    for session in sessions:
        lines.append(f"  {session.id} — {session.agent} ({session.path})")
    lines.append("")
    lines.append(f"Pending sessions to flush: {pending_sessions}")
    lines.append(f"Pending messages to flush: {pending_messages}")
    return lines
