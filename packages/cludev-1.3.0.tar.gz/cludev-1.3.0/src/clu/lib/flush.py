"""Session flushing service."""


from clu.api import SyncClient
from clu.store import Store


def render_flush(*, limit: int, dry_run: bool) -> list[str]:
    """Flush dirty sessions and their messages to the backend.

    Each dirty session is sent as a single payload to the ``/sessions``
    endpoint, including all of its messages.
    """
    db = Store.open()
    with db:
        dirty_sessions = db.sessions.list_dirty(limit=limit)

        if not dirty_sessions:
            return ["No pending sessions or messages to flush."]

        if dry_run:
            return [
                f"Would flush {len(dirty_sessions)} sessions.",
            ]

        sync_client = SyncClient()
        flushed = 0

        for session in dirty_sessions:
            messages = db.messages.list_for_session(
                session_id=session.id,
            )
            if not messages:
                continue

            sync_client.ingest_session(
                session=session,
                messages=messages,
            )
            flushed += 1

        session_ids = [s.id for s in dirty_sessions]
        db.sessions.mark_clean(session_ids=session_ids)
        db.messages.mark_clean_for_sessions(session_ids=session_ids)

        return [
            f"Flushed {flushed} sessions.",
        ]
