"""Simple file logger for hook events."""

import time
from pathlib import Path

LOG_PATH = Path("/tmp/clu-hooks.log")


def log_hook_event(*, agent: str, native_event_type: str, dispatched_event: str) -> None:
    """Append a hook event line to the log file."""
    ts = time.strftime("%Y-%m-%dT%H:%M:%S%z")
    line = f"[{ts}] agent={agent} hook={native_event_type} dispatched={dispatched_event}\n"
    with open(LOG_PATH, "a") as f:
        f.write(line)
