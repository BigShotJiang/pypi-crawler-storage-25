"""Business-logic entrypoints for CLI commands."""
