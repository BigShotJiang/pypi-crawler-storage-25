"""Authentication login service."""


import errno
import json
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from importlib import resources
from urllib.parse import urlparse

from clu import config as cfg_mod
from clu.models.config import OAuthSession


def run_auth_login(
    *,
    supabase_url: str,
    anon_key: str,
    provider: str,
    listen_addr: str,
    no_browser: bool,
) -> str:
    """Run the local browser-based auth flow and persist the session."""
    config = cfg_mod.load()

    resolved_supabase_url = supabase_url or config.auth.supabase_url
    if not resolved_supabase_url:
        raise RuntimeError(
            "missing Supabase URL; pass --supabase-url or set auth.supabase_url in config"
        )

    resolved_anon_key = anon_key or config.auth.supabase_anon_key
    if not resolved_anon_key:
        raise RuntimeError(
            "missing Supabase anon key; pass --anon-key or set auth.supabase_anon_key in config"
        )

    parsed_url = urlparse(resolved_supabase_url)
    if parsed_url.scheme not in ("http", "https") or not parsed_url.netloc:
        raise RuntimeError(f"invalid Supabase URL {resolved_supabase_url!r}")

    host, _, port_str = listen_addr.partition(":")
    if not port_str:
        raise RuntimeError(f"listen address {listen_addr!r} must include a port")
    port = int(port_str)

    callback_host = (
        host
        if host not in ("", "0.0.0.0", "::", "127.0.0.1", "[::1]")
        else "localhost"
    )
    callback_url = f"http://{callback_host}:{port}"
    template_text = (
        resources.files("clu.templates").joinpath("auth_login_page.html").read_text()
    )
    page_html = (
        template_text.replace("{{ .SupabaseURL }}", resolved_supabase_url)
        .replace("{{ .AnonKey }}", resolved_anon_key)
        .replace("{{ .Provider }}", provider)
        .replace("{{ .CallbackURL }}", callback_url)
    )

    session_result: dict[str, object] | None = None
    session_event = threading.Event()

    class Handler(BaseHTTPRequestHandler):
        """Handle the local OAuth callback browser flow."""

        def do_GET(self) -> None:
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(page_html.encode())

        def do_POST(self) -> None:
            nonlocal session_result
            if self.path != "/session":
                self.send_response(404)
                self.end_headers()
                return

            content_length = int(self.headers.get("Content-Length", 0))
            request_body = json.loads(self.rfile.read(content_length))

            if not request_body.get("access_token") or not request_body.get("refresh_token"):
                self.send_response(400)
                self.send_header("Content-Type", "text/plain")
                self.end_headers()
                self.wfile.write(b"session payload missing token fields")
                return

            session_result = request_body
            session_event.set()

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({"status": "ok"}).encode())

        def log_message(self, format: str, *args: object) -> None:
            """Suppress default request logging."""

    bind_host = host or "localhost"
    try:
        server = HTTPServer((bind_host, port), Handler)
    except OSError as error:
        if error.errno == errno.EADDRINUSE:
            raise RuntimeError(
                f"port {port} on {bind_host} is already in use — "
                f"pass a different port with --listen-addr (e.g. --listen-addr {bind_host}:3001), "
                f"and make sure it is whitelisted as a redirect URL in the Supabase project"
            ) from error
        raise
    server_thread = threading.Thread(target=server.serve_forever, daemon=True)
    server_thread.start()

    if not no_browser:
        webbrowser.open(callback_url)

    if not session_event.wait(timeout=120):
        server.shutdown()
        raise RuntimeError("timed out waiting for the browser login to complete")

    server.shutdown()
    assert session_result is not None

    config.auth.supabase_url = resolved_supabase_url
    config.auth.supabase_anon_key = resolved_anon_key
    config.auth.session = OAuthSession(
        access_token=str(session_result.get("access_token", "")),
        refresh_token=str(session_result.get("refresh_token", "")),
        token_type=str(session_result.get("token_type", "")),
        expires_at=int(session_result.get("expires_at", 0) or 0),
        user_id=str(session_result.get("user_id", "")),
        user_email=str(session_result.get("user_email", "")),
    )
    cfg_mod.save(cfg=config)

    email = str(session_result.get("user_email", "") or "authenticated user")
    return callback_url if no_browser else email
