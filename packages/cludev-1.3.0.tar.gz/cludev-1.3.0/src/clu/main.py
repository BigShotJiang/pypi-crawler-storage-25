"""Entry point for `python -m clu` and the `clu` console script."""

from clu.cli import cli


def main() -> None:
    """Invoke the Click CLI group."""
    cli()


if __name__ == "__main__":
    main()
