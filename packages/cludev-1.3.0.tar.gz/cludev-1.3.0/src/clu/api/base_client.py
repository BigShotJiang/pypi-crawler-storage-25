"""Shared backend API client behavior."""


import threading
import time
from typing import Any

import httpx

from clu import config


class BaseApiClient:
    """Shared authenticated HTTP client for backend access."""

    def __init__(self) -> None:
        """Load persisted auth state and initialize the HTTP client."""
        cfg = config.load()
        self._base_url = cfg.auth.supabase_url.rstrip("/")
        self._anon_key = cfg.auth.supabase_anon_key
        self._access_token = cfg.auth.session.access_token
        self._refresh_token = cfg.auth.session.refresh_token
        self._expires_at = cfg.auth.session.expires_at
        self._http = httpx.Client(timeout=30.0)
        self._lock = threading.Lock()

    def ensure_configured(self) -> None:
        """Raise when the client lacks enough auth state to make requests."""
        if not self._base_url:
            raise RuntimeError("clu is not authenticated — run `clu auth login`")
        if not self._access_token:
            raise RuntimeError("missing access token — run `clu auth login`")

    def send_authenticated_request(
        self,
        *,
        method: str,
        url: str,
        json_body: list[dict[str, Any]] | dict[str, Any] | None = None,
        params: dict[str, str] | None = None,
        extra_headers: dict[str, str] | None = None,
    ) -> httpx.Response:
        """Execute an authenticated request with automatic token refresh."""
        self.ensure_configured()
        self._ensure_valid_session()

        response = self._http.request(
            method=method,
            url=url,
            json=json_body,
            params=params,
            headers=self._build_headers(extra_headers=extra_headers),
        )
        if response.status_code not in (401, 403):
            return response

        self._force_refresh()
        return self._http.request(
            method=method,
            url=url,
            json=json_body,
            params=params,
            headers=self._build_headers(extra_headers=extra_headers),
        )

    def _build_headers(self, extra_headers: dict[str, str] | None = None) -> dict[str, str]:
        """Build request headers with auth plus any extra headers."""
        headers: dict[str, str] = {}
        if self._anon_key:
            headers["apikey"] = self._anon_key
        if self._access_token:
            headers["Authorization"] = f"Bearer {self._access_token}"
        if extra_headers:
            headers.update(extra_headers)
        return headers

    def _ensure_valid_session(self) -> None:
        """Refresh the session if the access token is near expiry."""
        with self._lock:
            access_token = self._access_token
            refresh_token = self._refresh_token
            expires_at = self._expires_at

        if not access_token:
            raise RuntimeError("missing access token — run `clu auth login`")
        if not refresh_token:
            return
        if expires_at == 0 or time.time() < expires_at - 60:
            return
        self._refresh_session(force=False)

    def _force_refresh(self) -> None:
        """Unconditionally refresh the current session token."""
        with self._lock:
            has_refresh = bool(self._refresh_token)
        if not has_refresh:
            raise RuntimeError(
                "access token expired and no refresh token is available — run `clu auth login`"
            )
        self._refresh_session(force=True)

    def _refresh_session(self, *, force: bool) -> None:
        """Exchange the refresh token for a new access token."""
        with self._lock:
            if not self._refresh_token:
                raise RuntimeError("missing refresh token — run `clu auth login`")
            if not force and self._expires_at != 0 and time.time() < self._expires_at - 60:
                return

            headers: dict[str, str] = {"Content-Type": "application/json"}
            if self._anon_key:
                headers["apikey"] = self._anon_key
            response = self._http.post(
                url=f"{self._base_url}/auth/v1/token?grant_type=refresh_token",
                json={"refresh_token": self._refresh_token},
                headers=headers,
            )

        if response.status_code != 200:
            raise RuntimeError(
                f"refresh token request returned {response.status_code}: {response.text}"
            )

        data = response.json()
        access_token = str(data.get("access_token", ""))
        if not access_token:
            raise RuntimeError("refresh response missing access token")

        with self._lock:
            self._access_token = access_token
            refresh_token = data.get("refresh_token")
            if isinstance(refresh_token, str) and refresh_token:
                self._refresh_token = refresh_token
            self._expires_at = int(data.get("expires_at", 0) or 0)

            cfg = config.load()
            cfg.auth.session.access_token = self._access_token
            cfg.auth.session.refresh_token = self._refresh_token
            cfg.auth.session.expires_at = self._expires_at
            config.save(cfg=cfg)
