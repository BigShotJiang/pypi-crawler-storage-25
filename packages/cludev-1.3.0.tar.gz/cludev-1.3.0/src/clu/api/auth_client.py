"""Backend auth client."""

from clu.api.base_client import BaseApiClient
from clu.models.auth_status import AuthStatus


class AuthClient(BaseApiClient):
    """Client for authenticated user profile operations."""

    def get_auth_status(self) -> AuthStatus:
        """Return the authenticated user's profile."""
        response = self.send_authenticated_request(
            method="GET",
            url=f"{self._base_url}/auth/v1/user",
        )
        if response.status_code != 200:
            raise RuntimeError(f"auth status returned {response.status_code}: {response.text}")

        user = response.json()
        return AuthStatus(
            id=user["id"],
            email=user.get("email", ""),
            expires_at=self._expires_at,
        )
