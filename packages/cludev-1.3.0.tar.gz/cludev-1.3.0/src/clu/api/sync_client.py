"""Backend sync client for session ingestion."""


from clu.api.base_client import BaseApiClient
from clu.models.session import Session
from clu.models.session_message import SessionMessage


class SyncClient(BaseApiClient):
    """Client for syncing local session data to the backend."""

    def ingest_session(
        self,
        *,
        session: Session,
        messages: list[SessionMessage],
    ) -> None:
        """POST a session and its messages to the ``sessions`` edge function.

        The payload mirrors the CLI's SQLite ``sessions`` and
        ``session_messages`` tables.
        """
        payload = {
            "external_session_id": session.id,
            "agent": session.agent,
            "path": session.path,
            "is_git_repo": session.is_git_repo,
            "git_remote_url": session.git_remote_url,
            "start_time": session.start_time,
            "end_time": session.end_time,
            "active": session.active,
            "messages": [
                msg.model_dump(
                    mode="json",
                    exclude={"session_id", "dirty"},
                )
                for msg in messages
            ],
        }

        response = self.send_authenticated_request(
            method="POST",
            url=f"{self._base_url}/functions/v1/sessions",
            json_body=payload,
        )
        if response.status_code not in (200, 201, 204):
            raise RuntimeError(
                f"session ingestion returned {response.status_code}: {response.text}",
            )
