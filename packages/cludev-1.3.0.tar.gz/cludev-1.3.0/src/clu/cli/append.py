"""append command — reads hook events from stdin into local store."""


import click

from clu.lib.append_event import append_hook_event


@click.command()
@click.option("--agent", required=True, help="Agent that produced the event (e.g. claude-code)")
def append(agent: str) -> None:
    """Read a hook event from stdin and append to local store."""
    for message in append_hook_event(agent=agent):
        click.echo(message, err=True)
