"""status command — show install state, sessions, and pending work."""


import click

from clu.lib.status import render_status


@click.command()
def status() -> None:
    """Show install state, active sessions, and pending sync work."""
    for line in render_status():
        click.echo(line, err=line.startswith("Warning:"))
