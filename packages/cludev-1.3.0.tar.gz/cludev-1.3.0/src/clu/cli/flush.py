"""flush command — push sessions and messages to the backend."""


import click

from clu.lib.flush import render_flush


@click.command()
@click.option("--limit", default=500, help="Max sessions/messages to flush per invocation")
@click.option("--dry-run", is_flag=True, help="Show what would be flushed without sending")
def flush(limit: int, dry_run: bool) -> None:
    """Push pending sessions and messages to the backend."""
    try:
        lines = render_flush(limit=limit, dry_run=dry_run)
    except Exception as error:
        raise click.ClickException(f"opening state db: {error}") from error

    for line in lines:
        click.echo(line)
