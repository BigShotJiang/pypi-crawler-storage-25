"""install command."""


import click

from clu.lib.install import run_install


@click.command()
@click.option("--global", "global_", is_flag=True, help="Install hooks in user-level agent config")
@click.option("--agent", default="", help="Agent to install for (e.g. claude-code)")
def install(global_: bool, agent: str) -> None:
    """One-time setup: initialize config and install agent event hooks."""
    try:
        lines = run_install(global_=global_, agent=agent)
    except RuntimeError as error:
        raise click.ClickException(str(error)) from error

    for line in lines:
        click.echo(line)
