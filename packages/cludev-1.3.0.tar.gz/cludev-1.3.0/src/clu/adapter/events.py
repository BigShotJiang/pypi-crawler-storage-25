"""Internal lifecycle events emitted by agent adapters."""


from pydantic import BaseModel


class AdapterEvent(BaseModel, frozen=True):
    """Base for internal lifecycle events emitted by adapters."""


class SessionStarted(AdapterEvent, frozen=True):
    """A coding session has started or should be created/resumed."""

    transcript_path: str


class TranscriptUpdated(AdapterEvent, frozen=True):
    """The transcript has new content to parse."""


class SessionEnded(AdapterEvent, frozen=True):
    """The coding session has ended. Implies a final transcript parse."""


class HookEventIgnored(AdapterEvent, frozen=True):
    """The hook event does not map to a lifecycle action."""
