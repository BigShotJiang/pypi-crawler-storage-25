"""Constants for the Claude Code adapter."""

ALL_HOOK_EVENTS = [
    "SessionStart",
    "UserPromptSubmit",
    "PreToolUse",
    "PermissionRequest",
    "PermissionDenied",
    "PostToolUse",
    "PostToolUseFailure",
    "Notification",
    "SubagentStart",
    "SubagentStop",
    "TaskCreated",
    "TaskCompleted",
    "Stop",
    "StopFailure",
    "TeammateIdle",
    "InstructionsLoaded",
    "ConfigChange",
    "CwdChanged",
    "FileChanged",
    "WorktreeCreate",
    "WorktreeRemove",
    "PreCompact",
    "PostCompact",
    "Elicitation",
    "ElicitationResult",
    "SessionEnd",
]

CLU_COMMAND_MARKER = "clu append"

# Hook events that signal a new session should be created/resumed.
SESSION_START_EVENTS = {"SessionStart", "UserPromptSubmit"}

# Hook events that signal the transcript has new content to parse.
TRANSCRIPT_UPDATE_EVENTS = {"Stop", "StopFailure", "SubagentStop", "PostCompact"}

# Hook events that signal the session has ended (implies a final transcript parse).
SESSION_END_EVENTS = {"SessionEnd"}
