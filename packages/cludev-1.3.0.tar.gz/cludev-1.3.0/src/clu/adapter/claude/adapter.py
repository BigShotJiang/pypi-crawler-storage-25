"""Claude Code adapter implementation."""

import json
import shutil
from pathlib import Path
from typing import List, Tuple

from clu.adapter import Adapter
from clu.adapter.claude.constants import (
    ALL_HOOK_EVENTS,
    SESSION_END_EVENTS,
    SESSION_START_EVENTS,
    TRANSCRIPT_UPDATE_EVENTS,
)
from clu.adapter.claude.utils import (
    build_clu_entry,
    find_event,
    has_clu_entry,
    is_clu_entry,
    parse_claude_transcript,
    read_claude_settings,
    shell_quote,
    update_clu_entry,
    write_claude_settings,
)
from clu.adapter.events import (
    AdapterEvent,
    HookEventIgnored,
    SessionEnded,
    SessionStarted,
    TranscriptUpdated,
)
from clu.models.claude_hook_event import ClaudeHookEvent
from clu.models.session_message import SessionMessage


class ClaudeAdapter(Adapter):
    """Adapter for Claude Code."""

    def name(self) -> str:
        """Return the adapter identifier."""
        return "claude-code"

    def detect(self) -> bool:
        """Return whether the ``claude`` binary is available."""
        return shutil.which("claude") is not None

    def install_hooks(self, project_dir: str, global_: bool, clu_binary: str) -> None:
        """Install clu hooks into Claude Code settings."""
        path = _settings_path(project_dir=project_dir, global_=global_)
        settings = read_claude_settings(path=path)
        command = f"{shell_quote(clu_binary)} append --agent {self.name()}"

        updated_events: List[ClaudeHookEvent] = []
        for event_name in ALL_HOOK_EVENTS:
            existing_event = find_event(settings.hook_events, event_name=event_name)
            entries = list(existing_event.entries) if existing_event else []
            if has_clu_entry(entries=entries):
                update_clu_entry(entries=entries, command=command)
            else:
                entries.append(build_clu_entry(command=command))
            updated_events.append(ClaudeHookEvent(event_name=event_name, entries=entries))

        preserved_events = [
            event
            for event in settings.hook_events
            if event.event_name not in {e.event_name for e in updated_events}
        ]
        settings.hook_events = preserved_events + updated_events
        write_claude_settings(path=path, settings=settings)

    def uninstall_hooks(self, project_dir: str, global_: bool) -> None:
        """Remove clu hooks from Claude Code settings."""
        path = _settings_path(project_dir=project_dir, global_=global_)
        settings = read_claude_settings(path=path)

        retained_events: List[ClaudeHookEvent] = []
        for event in settings.hook_events:
            filtered = [e for e in event.entries if not is_clu_entry(entry=e)]
            if filtered:
                retained_events.append(
                    ClaudeHookEvent(event_name=event.event_name, entries=filtered)
                )

        settings.hook_events = retained_events
        write_claude_settings(path=path, settings=settings)

    def parse_hook_payload(self, raw_payload: str) -> Tuple[str, AdapterEvent]:
        """Parse a Claude Code hook JSON payload into an internal event."""
        try:
            data = json.loads(raw_payload)
        except (json.JSONDecodeError, ValueError):
            return ("", HookEventIgnored())

        if not isinstance(data, dict):
            return ("", HookEventIgnored())

        event_type = ""
        for key in ("event", "type", "hook_event_name"):
            value = data.get(key)
            if isinstance(value, str) and value:
                event_type = value
                break

        if event_type in SESSION_START_EVENTS:
            return (event_type, SessionStarted(
                transcript_path=str(data.get("transcript_path", "")),
            ))
        if event_type in TRANSCRIPT_UPDATE_EVENTS:
            return (event_type, TranscriptUpdated())
        if event_type in SESSION_END_EVENTS:
            return (event_type, SessionEnded())
        return (event_type, HookEventIgnored())

    def parse_transcript(
        self,
        *,
        path: str,
        session_id: str,
        cwd: str,
        watermark: int,
        turn_offset: int,
    ) -> Tuple[List[SessionMessage], int]:
        """Parse new messages from a Claude Code JSONL transcript."""
        return parse_claude_transcript(
            path=path,
            session_id=session_id,
            cwd=cwd,
            watermark=watermark,
            turn_offset=turn_offset,
        )


def _settings_path(*, project_dir: str, global_: bool) -> Path:
    """Return the path to Claude Code's settings file."""
    if global_:
        return Path.home() / ".claude" / "settings.json"
    return Path(project_dir) / ".claude" / "settings.json"
