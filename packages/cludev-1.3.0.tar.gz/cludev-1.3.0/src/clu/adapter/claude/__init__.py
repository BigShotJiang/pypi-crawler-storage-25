"""Claude Code adapter."""

from clu.adapter.claude.adapter import ClaudeAdapter

__all__ = ["ClaudeAdapter"]
