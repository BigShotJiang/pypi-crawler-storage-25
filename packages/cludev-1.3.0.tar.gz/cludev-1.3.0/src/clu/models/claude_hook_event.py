"""Claude hook event mapping model."""


from pydantic import BaseModel, Field

from clu.models.claude_hook_entry import ClaudeHookEntry


class ClaudeHookEvent(BaseModel):
    """Claude hook configuration for a named event.

    Attributes:
        event_name: Claude event name such as `SessionStart`.
        entries: Hook entries registered for the event.
    """

    event_name: str
    entries: list[ClaudeHookEntry] = Field(default_factory=list)
