"""Claude hook command model."""

from pydantic import BaseModel


class ClaudeHookCommand(BaseModel):
    """Single Claude hook command definition.

    Attributes:
        type: Hook type, currently always `command`.
        command: Shell command executed by Claude Code.
    """

    type: str
    command: str
