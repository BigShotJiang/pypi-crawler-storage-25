"""Claude hook entry model."""


from pydantic import BaseModel, Field

from clu.models.claude_hook_command import ClaudeHookCommand


class ClaudeHookEntry(BaseModel):
    """Claude hook entry for a single matcher.

    Attributes:
        matcher: Claude matcher expression.
        hooks: Commands executed when the matcher is triggered.
    """

    matcher: str = ""
    hooks: list[ClaudeHookCommand] = Field(default_factory=list)
