"""Authenticated user status model."""

from pydantic import BaseModel


class AuthStatus(BaseModel):
    """Authenticated user profile summary.

    Attributes:
        id: Supabase Auth user UUID.
        email: User email address.
        expires_at: Expiry timestamp of the active access token.
    """

    id: str
    email: str = ""
    expires_at: int = 0
