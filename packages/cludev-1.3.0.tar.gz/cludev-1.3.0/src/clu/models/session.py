"""Tracked session model."""


from pydantic import BaseModel


class Session(BaseModel):
    """AI coding session tracked in local state.

    Attributes:
        id: Local session UUID.
        agent: Adapter name, such as `claude-code`.
        repo_path: Absolute repository root.
        start_time: Session start time.
        end_time: Session end time, if finished.
        active: Whether the session is currently active.
        transcript_path: JSONL transcript path.
        branch: Associated git branch.
        is_git_repo: Whether the working directory is a git repo.
        watermark: JSONL line offset already parsed.
        claude_session_id: Claude Code session identifier.
        dirty: Whether the session needs to be flushed to the backend.
    """

    id: str
    agent: str
    path: str
    is_git_repo: bool = True
    git_remote_url: str
    start_time: int
    end_time: int
    active: bool = True
    transcript_path: str = ""
    transcript_parsing_watermark: int = 0
    dirty: bool = True
