"""Claude settings model."""


from pydantic import BaseModel, Field

from clu.models.claude_hook_event import ClaudeHookEvent


class ClaudeSettings(BaseModel):
    """Subset of Claude Code settings managed by clu.

    Attributes:
        hook_events: Configured hook events.
    """

    hook_events: list[ClaudeHookEvent] = Field(default_factory=list)
