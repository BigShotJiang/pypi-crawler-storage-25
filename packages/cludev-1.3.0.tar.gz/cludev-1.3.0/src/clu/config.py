"""Configuration file access for `~/.clu/config.toml`."""


import tomllib
from pathlib import Path

import tomli_w

from clu.models.config import AuthConfig, Config, OAuthSession


def config_dir() -> Path:
    """Return the clu config directory."""
    return Path.home() / ".clu"


def ensure_dir() -> Path:
    """Create the clu config directory if needed and return it."""
    directory = config_dir()
    directory.mkdir(parents=True, exist_ok=True)
    return directory


def config_path() -> Path:
    """Return the full path to the config file."""
    return config_dir() / "config.toml"


def load() -> Config:
    """Load config from disk or return defaults when missing."""
    path = config_path()
    if not path.exists():
        return Config()
    with open(path, "rb") as file:
        data = tomllib.load(file)
    return Config.model_validate(obj=data)


def save(cfg: Config) -> None:
    """Persist config to disk."""
    directory = ensure_dir()
    path = directory / "config.toml"
    with open(path, "wb") as file:
        tomli_w.dump(cfg.model_dump(mode="python"), file)


__all__ = [
    "AuthConfig",
    "Config",
    "OAuthSession",
    "config_dir",
    "config_path",
    "ensure_dir",
    "load",
    "save",
]
