# Scraping Flow

How clu captures agent session data from Claude Code hooks and turns it into reviewable changesets.

## Overview

The CLI hooks into every Claude Code lifecycle event via `clu append`. Most events are recorded as-is for metadata. Two events drive the session lifecycle: `SessionStart` creates a session record (capturing the `transcript_path`), and `SessionEnd` closes it. On key events (`Stop`, `SessionEnd`), the CLI incrementally parses the JSONL transcript file to extract conversation turns and stores them locally.

At submit time, commits are derived directly from git (not captured at hook time), and conversation turns are assembled into `Thread` objects. Everything keys off `repo_path + branch` — that pair is the unique identity of a unit of work.

## Core design principle

**The branch is the correlation key.** A session operates on a branch. Commits land on that branch. The PR is opened for that branch. Everything ties together through `repo_path + branch` without cross-referencing timestamps or SHAs across tables.

```
repo_path + branch  ←──  the unique key for everything
    │
    ├── sessions[]        (1+ agent sessions that worked on this branch)
    ├── commits[]         (derived from git at submit time)
    └── PR                (opened by developer for this branch → main)
```

Multiple agent sessions on the same branch in the same repo all contribute to the same changeset. No need to track which session produced which commit.

## Hook strategy

### Installed hooks

All 26 Claude Code events are hooked (already implemented in `adapter/claude.py`). Every hook fires `clu append --agent claude-code`, which reads the JSON payload from stdin and inserts it into the `hook_events` table.

### Hook payload (common fields)

Every hook event delivers these fields via stdin JSON:

```json
{
  "session_id": "abc-123",
  "transcript_path": "/Users/…/.claude/projects/<hash>/sessions/<uuid>.jsonl",
  "cwd": "/path/to/repo",
  "hook_event_name": "Stop",
  "permission_mode": "default"
}
```

`transcript_path` is the key field — it tells us where the full conversation lives on disk.

### Which hooks trigger work

Not every hook needs to trigger transcript parsing. The breakdown:

| Hook event      | Action                                                                  |
| --------------- | ----------------------------------------------------------------------- |
| `SessionStart`  | Create session record with `transcript_path`, `repo_path`, `branch`     |
| `Stop`          | Incrementally parse transcript from watermark → store new turns locally |
| `SessionEnd`    | Final incremental parse, close the session                              |
| Everything else | Record in `hook_events` (metadata only, no transcript parsing)          |

`Stop` fires after every assistant response, so parsing there captures turns as they happen. This keeps the local store reasonably up-to-date without parsing on every single tool call.

## Session lifecycle

### State machine

```
SessionStart  ──►  active  ──►  ended
                     │
              (updated on Stop)
```

- **active** — session is in progress. `watermark` advances on each `Stop` event.
- **ended** — `SessionEnd` received. Final transcript parse complete.

### Session identity

A session's identity in clu is `repo_path + branch`, not Claude Code's `session_id`. Multiple Claude Code sessions on the same branch contribute to the same logical unit of work. Claude Code's `session_id` is stored for traceability but isn't the primary key for correlation.

### What a session record stores

```
sessions table (updated schema):
  id              TEXT PRIMARY KEY     -- internally generated, or hash(repo_path + branch)
  agent           TEXT NOT NULL        -- "claude-code"
  transcript_path TEXT NOT NULL        -- absolute path to the JSONL file
  repo_path       TEXT NOT NULL        -- cwd at session start
  branch          TEXT NOT NULL        -- git branch at session start
  is_git_repo     BOOLEAN DEFAULT 1
  claude_session_id TEXT              -- Claude Code's session_id (for traceability)
  start_time      DATETIME NOT NULL
  end_time        DATETIME
  active          BOOLEAN DEFAULT 1
  watermark       INTEGER DEFAULT 0   -- last parsed line number in the JSONL
```

Changes from current schema: add `transcript_path`, `branch`, `is_git_repo`, `watermark`, `claude_session_id`. Drop `log_file` (replaced by `transcript_path`).

## Transcript parsing

### JSONL format

Claude Code stores transcripts as append-only JSONL files. Each line is a JSON object representing one message or event:

```json
{
  "type": "user",
  "message": { "role": "user", "content": "add rate limiting to the API" },
  "uuid": "b4575262-...",
  "timestamp": "2025-07-23T15:00:55.015Z",
  "sessionId": "eb5b0174-...",
  "cwd": "/Users/user/projects/myproject",
  "version": "1.0.58",
  "parentUuid": null,
  "isSidechain": false
}
```

Relevant `type` values: `user`, `assistant`, `tool_use`, `tool_result`, `system`.

### Incremental parsing

On each parse trigger (`Stop` or `SessionEnd`):

1. Open the JSONL file at `transcript_path`.
2. Skip to line `watermark` (the last parsed line number).
3. Parse each new line into a JSON object.
4. Filter to `type` in (`user`, `assistant`) — skip `tool_use`/`tool_result`/`system` for now.
5. Map each entry to a `ConversationTurn` (see below).
6. Insert new turns into `session_turns` table.
7. Update `sessions.watermark` to the new line count.

### Mapping JSONL → ConversationTurn

```
JSONL field          →  ConversationTurn field
────────────────────────────────────────────────
(auto-increment)     →  index
message.role         →  role
message.content      →  content
timestamp            →  timestamp
(from assistant)     →  model          (extract from content metadata if available)
(n/a for now)        →  token_usage    (not in JSONL, available from hook payloads)
(n/a for now)        →  files_referenced
```

Token usage isn't in the JSONL transcript but is available in `Stop` hook payloads. We can enrich turns with token data from the corresponding `hook_events` row.

## Local storage

### New table: `session_turns`

```sql
CREATE TABLE IF NOT EXISTS session_turns (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL REFERENCES sessions(id),
    turn_index INTEGER NOT NULL,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    timestamp DATETIME,
    model TEXT DEFAULT '',
    token_usage_input INTEGER DEFAULT 0,
    token_usage_output INTEGER DEFAULT 0,
    UNIQUE(session_id, turn_index)
);
```

This is the local staging area. At submit time, rows are read out and assembled into `Thread.turns`.

### Updated table: `changesets`

Add a high-water mark so we know where the last submit left off on a branch:

```sql
ALTER TABLE changesets ADD COLUMN head_sha TEXT;
```

Populated at submit time with the latest commit SHA. Queried at next submit time to scope commits to only what's new.

## Commits — derived at submit time, not captured at hook time

Commits are **not** recorded by hooks. Instead, `clu submit` derives them directly from git:

```
git log <base>..origin/<branch>
```

Where `<base>` is either:

- The `head_sha` from the last changeset on this branch (if a prior submit exists), or
- The merge-base with `main` (first submit on this branch)

This eliminates the need for a pre-push hook for commit tracking. Git is the source of truth.

### "Is it pushed?" gate

Before deriving commits, verify everything is pushed:

```
git log origin/<branch>..HEAD
```

If this returns anything, there are unpushed commits. Error out with "push your branch before running `clu submit`" — same UX as today, no hook required.

### Why not capture commits at hook time

- **Pre-commit** captures SHAs that may be rewritten (amend, rebase, squash) before they reach the remote.
- **Pre-push** adds timing-based fuzziness — the push may happen after the session ends.
- **Neither is needed.** At submit time, `origin/<branch>` already contains exactly the commits that will appear on the PR. Git is the source of truth; reading it at submit time is both simpler and more accurate.

## Data flow

### On `clu append` (every hook event)

```
stdin JSON
  │
  ├─ Always: insert into hook_events
  │
  ├─ If SessionStart:
  │    look up or create session for (repo_path, branch)
  │    store transcript_path, claude_session_id
  │
  ├─ If Stop:
  │    find active session for (repo_path, branch)
  │    read transcript from watermark → parse new turns → insert into session_turns
  │    update session watermark
  │
  └─ If SessionEnd:
      find active session for (repo_path, branch)
      read transcript from watermark → parse remaining turns → insert into session_turns
      update session watermark
      set session active=0, end_time=now
```

### On `clu submit`

```
1. Determine repo_path and branch from cwd + git
2. Find all sessions for this (repo_path, branch) → build Thread objects from session_turns
3. Check for unpushed commits (error if any)
4. Look up last changeset head_sha for this (repo_path, branch)
5. Derive commits from git: git log <base>..origin/<branch>
6. Build Intent (from first user prompt or first commit message)
7. Assemble Payload(intent, commits, threads) → POST to backend
8. Record head_sha in new changeset row
```

## Implementation order

1. **Update `sessions` schema** — add `transcript_path`, `watermark`, `branch`, `claude_session_id`; add `session_turns` table; add `head_sha` to `changesets`.
2. **Session lifecycle in `append.py`** — handle `SessionStart` → create/lookup session by `(repo_path, branch)`, `SessionEnd` → close session.
3. **Transcript parser** — new module `cli/src/clu/transcript.py` that reads JSONL from a watermark and returns `ConversationTurn` objects.
4. **Wire parsing into `append.py`** — on `Stop`/`SessionEnd`, call the parser and store turns.
5. **Update `submit.py`** — derive commits from git instead of `pushed_commits`; read `session_turns` and build `Thread` objects; record `head_sha`.
6. **Remove pre-push hook dependency** — delete the `pushed_commits` table usage and `clu internal record-push` flow.
7. **Update `flush.py`** — POST hook events to backend ingest endpoint (separate from submit).

## Open questions

- **Tool calls in turns**: Should we include `tool_use`/`tool_result` entries as conversation turns, or keep them out of the thread and let the transcript speak for itself? Including them makes threads verbose but gives reviewers full context.
- **Subagent transcripts**: `SubagentStop` events include `agent_transcript_path` pointing to a separate JSONL. Do we parse those too and create additional Thread objects per subagent? Probably yes, but deferred.
- **Multi-session threads**: Multiple Claude Code sessions on the same branch produce multiple transcripts. Each becomes its own `Thread` in the changeset (the backend supports multiple threads per changeset). One thread per transcript file, ordered by session start time.
- **Token usage enrichment**: `Stop` hook payloads may include token counts. Worth enriching turns with this data, but the exact payload shape needs verification.
