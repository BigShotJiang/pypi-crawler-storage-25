# Dev

```bash
# Setup environment
pyenv install 3.12.0
pyenv local 3.12.0
uv venv
source .venv/bin/activate

# Install dependencies
uv pip install -e ".[dev]"

# Run tests
pytest

# Format code
black surak tests
ruff check surak tests
```


### install cli locally 
```bash
uv pip install -e .

# run with uv:
uv run surak --version
```


### PyPi
```bash
# build
python3 -m build
# upload
python3 -m twine upload dist/*
# or run 
gh workflow run publish.yml \
  --ref main \
  --field version=0.2.0 \
  --field dry_run=true
```