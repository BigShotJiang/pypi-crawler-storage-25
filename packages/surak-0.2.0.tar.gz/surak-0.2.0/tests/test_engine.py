"""Tests for SurakEngine."""

import pytest

from surak.engine import SurakEngine
from tests.conftest import make_ctx, make_policy


@pytest.fixture
def engine():
    return SurakEngine()


def test_for_workflow_filters_correctly(engine):
    deploy = make_policy(id="deploy", applies_to=[".github/workflows/deploy.yml"])
    ci = make_policy(id="ci", applies_to=[".github/workflows/tests.yml"])
    wildcard = make_policy(id="all", applies_to="*")

    result = engine.for_workflow(".github/workflows/deploy.yml", [deploy, ci, wildcard])
    ids = [p.id for p in result]
    assert "deploy" in ids
    assert "all" in ids
    assert "ci" not in ids


def test_evaluate_passes_when_all_ok(engine):
    policy = make_policy(actor_allowlist={"enabled": True, "allow": ["octocat"]})
    ctx = make_ctx(actor="octocat")
    result = engine.evaluate(policy, ctx)
    assert result.passed


def test_evaluate_fails_on_violation(engine):
    policy = make_policy(actor_allowlist={"enabled": True, "allow": ["octocat"]})
    ctx = make_ctx(actor="intruder")
    result = engine.evaluate(policy, ctx)
    assert not result.passed
    assert result.violations


def test_evaluate_all_report(engine):
    p1 = make_policy(id="p1", actor_allowlist={"enabled": True, "allow": ["octocat"]})
    p2 = make_policy(id="p2", branch_protection={"enabled": True, "require": "main"})
    ctx = make_ctx(actor="octocat", branch="main")

    report = engine.evaluate_all([p1, p2], ctx)
    assert report.ok
    assert report.passed == 2
    assert report.failed == 0


def test_evaluate_all_report_failure(engine):
    p1 = make_policy(id="p1", actor_allowlist={"enabled": True, "allow": ["octocat"]})
    p2 = make_policy(id="p2", branch_protection={"enabled": True, "require": "main"})
    ctx = make_ctx(actor="octocat", branch="feature/oops")

    report = engine.evaluate_all([p1, p2], ctx)
    assert not report.ok
    assert report.failed == 1
    assert report.passed == 1


def test_report_as_dict(engine):
    policy = make_policy()
    report = engine.evaluate_all([policy], make_ctx())
    d = report.as_dict()
    assert d["status"] in ("pass", "fail")
    assert "results" in d
