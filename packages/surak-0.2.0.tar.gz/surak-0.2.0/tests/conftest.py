"""Shared fixtures for Surak v2 tests."""

import pytest

from surak.context.base import CheckStatus, ResolvedContext
from surak.schema import (
    ActorAllowlistConfig,
    BranchProtectionConfig,
    PoliciesBlock,
    PolicyV2,
    RequiredChecksConfig,
    RunnerTypeConfig,
    RunnerOsConfig,
    RunnerArchConfig,
    RunnerImageConfig,
)


def make_ctx(**kwargs) -> ResolvedContext:
    defaults = {
        "actor": "octocat",
        "branch": "main",
        "runner_name": "ubuntu-22.04",
        "runner_os": "Linux",
        "runner_labels": ["ubuntu-22.04", "Linux"],
        "workflow_path": ".github/workflows/deploy.yml",
        "event_name": "push",
        "check_statuses": {
            "Tests": CheckStatus("Tests", "completed", "success"),
            "Security Scan": CheckStatus("Security Scan", "completed", "success"),
        },
        "source": "manual",
    }
    defaults.update(kwargs)
    return ResolvedContext(**defaults)


def make_policy(
    id: str = "test",
    name: str = "Test Policy",
    applies_to=None,
    **policy_kwargs,
) -> PolicyV2:
    if applies_to is None:
        applies_to = [".github/workflows/deploy.yml"]
    return PolicyV2.model_validate({
        "surak": "v2",
        "id": id,
        "name": name,
        "applies-to": applies_to,
        "policies": policy_kwargs or {
            "actor_allowlist": {"enabled": True, "allow": ["octocat"]},
        },
    })


@pytest.fixture
def default_ctx():
    return make_ctx()


@pytest.fixture
def default_policy():
    return make_policy()