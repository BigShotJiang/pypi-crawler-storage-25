"""
Integration tests — full stack from policy construction to evaluation result.
These test the API as a consumer would use it, not individual components.
"""

import pytest
from surak import PolicyV2, SurakEngine
from surak.context import ManualContext, WebhookContext
from surak.context.base import CheckStatus


def make_gha_ctx(
    actor="octocat",
    branch="main",
    runner_os="Linux",
    runner_labels=None,
    workflow_path=".github/workflows/deploy.yml",
    checks=None,
):
    """Simulate a realistic GHA resolved context."""
    return ManualContext.from_dict({
        "actor": actor,
        "branch": branch,
        "runner_os": runner_os,
        "runner_labels": runner_labels or ["github-hosted", "Linux", "ubuntu-22.04", "X64"],
        "workflow_path": workflow_path,
        "check_statuses": checks or {},
    }).build()


engine = SurakEngine()


# ---------------------------------------------------------------------------
# Full policy gate — all constraints
# ---------------------------------------------------------------------------

class TestFullPolicyGate:
    def _policy(self, **overrides):
        defaults = dict(
            id="gate", name="Gate",
            applies_to=[".github/workflows/deploy.yml"],
            actor_allowlist=["octocat"],
            runner_type="github-hosted",
            runner_os=["Linux"],
            runner_arch=["X64"],
            runner_image=["ubuntu-22.04"],
            branch_protection="main",
            required_checks=["Tests"],
        )
        defaults.update(overrides)
        return PolicyV2.build(**defaults)

    def test_all_pass(self):
        policy = self._policy()
        ctx = make_gha_ctx(checks={"Tests": {"status": "completed", "conclusion": "success"}})
        report = engine.evaluate_all([policy], ctx)
        assert report.ok
        assert report.failed == 0

    def test_wrong_actor_blocks(self):
        policy = self._policy()
        ctx = make_gha_ctx(actor="intruder",
                           checks={"Tests": {"status": "completed", "conclusion": "success"}})
        report = engine.evaluate_all([policy], ctx)
        assert not report.ok
        violations = report.results[0].violations
        assert any("intruder" in v for v in violations)

    def test_wrong_branch_blocks(self):
        policy = self._policy()
        ctx = make_gha_ctx(branch="feature/oops",
                           checks={"Tests": {"status": "completed", "conclusion": "success"}})
        report = engine.evaluate_all([policy], ctx)
        assert not report.ok

    def test_self_hosted_blocks_when_github_required(self):
        policy = self._policy()
        ctx = make_gha_ctx(runner_labels=["self-hosted", "Linux", "X64"])
        report = engine.evaluate_all([policy], ctx)
        assert not report.ok
        violations = [v for r in report.results for v in r.violations]
        assert any("self-hosted" in v for v in violations)

    def test_wrong_image_blocks(self):
        policy = self._policy()
        ctx = make_gha_ctx(runner_labels=["github-hosted", "Linux", "ubuntu-24.04", "X64"],
                           checks={"Tests": {"status": "completed", "conclusion": "success"}})
        report = engine.evaluate_all([policy], ctx)
        assert not report.ok

    def test_multiple_violations_reported(self):
        policy = self._policy()
        ctx = make_gha_ctx(actor="intruder", branch="feature/bad")
        report = engine.evaluate_all([policy], ctx)
        assert not report.ok
        # actor + branch both violated — should have 2+ violations
        all_violations = [v for r in report.results for v in r.violations]
        assert len(all_violations) >= 2


# ---------------------------------------------------------------------------
# runner_image skip_if_self_hosted — the tricky case
# ---------------------------------------------------------------------------

class TestRunnerImageSelfHosted:
    def test_skip_passes_with_warning(self):
        policy = PolicyV2.build(
            id="p", name="P", applies_to="*",
            runner_image=["ubuntu-22.04"],
            runner_image_skip_if_self_hosted=True,
        )
        ctx = make_gha_ctx(runner_labels=["self-hosted", "Linux", "X64"])
        report = engine.evaluate_all([policy], ctx)
        assert report.ok
        warnings = [w for r in report.results for w in r.warnings]
        assert any("skipped" in w.lower() for w in warnings)

    def test_no_skip_fails_on_self_hosted(self):
        policy = PolicyV2.build(
            id="p", name="P", applies_to="*",
            runner_image=["ubuntu-22.04"],
            runner_image_skip_if_self_hosted=False,
        )
        ctx = make_gha_ctx(runner_labels=["self-hosted", "Linux", "X64"])
        assert not engine.evaluate_all([policy], ctx).ok

    def test_image_enforced_on_github_hosted(self):
        policy = PolicyV2.build(
            id="p", name="P", applies_to="*",
            runner_image=["ubuntu-22.04"],
            runner_image_skip_if_self_hosted=True,
        )
        # wrong image on github-hosted should still fail
        ctx = make_gha_ctx(runner_labels=["github-hosted", "Linux", "ubuntu-24.04", "X64"])
        assert not engine.evaluate_all([policy], ctx).ok


# ---------------------------------------------------------------------------
# applies-to matching edge cases
# ---------------------------------------------------------------------------

class TestWorkflowMatching:
    def test_wildcard_catches_everything(self):
        policy = PolicyV2.build(
            id="p", name="P", applies_to="*",
            runner_type="github-hosted",
        )
        for path in [
            ".github/workflows/deploy.yml",
            ".github/workflows/tests.yml",
            ".github/workflows/release.yml",
        ]:
            applicable = engine.for_workflow(path, [policy])
            assert len(applicable) == 1

    def test_specific_path_does_not_catch_others(self):
        policy = PolicyV2.build(
            id="p", name="P",
            applies_to=[".github/workflows/deploy.yml"],
            runner_type="github-hosted",
        )
        assert engine.for_workflow(".github/workflows/tests.yml", [policy]) == []
        assert len(engine.for_workflow(".github/workflows/deploy.yml", [policy])) == 1

    def test_multiple_policies_filtered_correctly(self):
        deploy = PolicyV2.build(
            id="deploy", name="Deploy",
            applies_to=[".github/workflows/deploy.yml"],
            actor_allowlist=["octocat"],
        )
        global_ = PolicyV2.build(
            id="global", name="Global",
            applies_to="*",
            runner_type="github-hosted",
        )
        ci = PolicyV2.build(
            id="ci", name="CI",
            applies_to=[".github/workflows/tests.yml"],
            runner_os=["Linux"],
        )

        applicable = engine.for_workflow(".github/workflows/deploy.yml", [deploy, global_, ci])
        ids = [p.id for p in applicable]
        assert "deploy" in ids
        assert "global" in ids
        assert "ci" not in ids


# ---------------------------------------------------------------------------
# from_yaml / from_dict constructors
# ---------------------------------------------------------------------------

class TestConstructors:
    def test_from_yaml_evaluates_correctly(self):
        yaml_text = """
surak: v2
id: yaml-gate
name: YAML Gate
applies-to: "*"
policies:
  runner_type:
    enabled: true
    require: github-hosted
  branch_protection:
    enabled: true
    require: main
"""
        policy = PolicyV2.from_yaml(yaml_text)
        ctx = make_gha_ctx(branch="main")
        assert engine.evaluate_all([policy], ctx).ok

        ctx_bad = make_gha_ctx(branch="feature/x")
        assert not engine.evaluate_all([policy], ctx_bad).ok

    def test_from_dict_roundtrip(self):
        policy = PolicyV2.from_dict({
            "surak": "v2",
            "id": "dict-gate",
            "name": "Dict Gate",
            "applies-to": ["*"],
            "policies": {
                "actor_allowlist": {"enabled": True, "allow": ["octocat"]},
            },
        })
        assert engine.evaluate_all([policy], make_gha_ctx(actor="octocat")).ok
        assert not engine.evaluate_all([policy], make_gha_ctx(actor="intruder")).ok


# ---------------------------------------------------------------------------
# WebhookContext
# ---------------------------------------------------------------------------

class TestWebhookContext:
    def test_actor_resolved_from_triggering_actor(self):
        payload = {
            "workflow_run": {
                "triggering_actor": {"login": "octocat"},
                "head_branch": "main",
                "path": ".github/workflows/deploy.yml",
                "event": "push",
            }
        }
        ctx = WebhookContext.from_payload(payload).build()
        assert ctx.actor == "octocat"
        assert ctx.branch == "main"
        assert ctx.workflow_path == ".github/workflows/deploy.yml"

    def test_check_statuses_injected(self):
        payload = {
            "workflow_run": {"triggering_actor": {"login": "octocat"}, "head_branch": "main"},
            "_check_statuses": {
                "Tests": {"status": "completed", "conclusion": "success"},
            },
        }
        ctx = WebhookContext.from_payload(payload).build()
        assert "Tests" in ctx.check_statuses
        assert ctx.check_statuses["Tests"].conclusion == "success"

    def test_webhook_evaluates_with_engine(self):
        policy = PolicyV2.build(
            id="gate", name="Gate",
            applies_to=[".github/workflows/deploy.yml"],
            actor_allowlist=["octocat"],
            branch_protection="main",
        )
        payload = {
            "workflow_run": {
                "triggering_actor": {"login": "octocat"},
                "head_branch": "main",
                "path": ".github/workflows/deploy.yml",
                "event": "push",
            }
        }
        ctx = WebhookContext.from_payload(payload).build()
        applicable = engine.for_workflow(".github/workflows/deploy.yml", [policy])
        report = engine.evaluate_all(applicable, ctx)
        assert report.ok

    def test_webhook_wrong_actor_fails(self):
        policy = PolicyV2.build(
            id="gate", name="Gate",
            applies_to="*",
            actor_allowlist=["octocat"],
        )
        payload = {
            "workflow_run": {
                "triggering_actor": {"login": "intruder"},
                "head_branch": "main",
            }
        }
        ctx = WebhookContext.from_payload(payload).build()
        assert not engine.evaluate_all([policy], ctx).ok


# ---------------------------------------------------------------------------
# report.as_dict() shape
# ---------------------------------------------------------------------------

class TestReportShape:
    def test_pass_shape(self):
        policy = PolicyV2.build(id="p", name="P", applies_to="*",
                                actor_allowlist=["octocat"])
        d = engine.evaluate_all([policy], make_gha_ctx()).as_dict()
        assert d["status"] == "pass"
        assert d["total"] == 1
        assert d["passed"] == 1
        assert d["failed"] == 0
        assert isinstance(d["results"], list)
        assert d["results"][0]["violations"] == []

    def test_fail_shape(self):
        policy = PolicyV2.build(id="p", name="P", applies_to="*",
                                actor_allowlist=["octocat"])
        d = engine.evaluate_all([policy], make_gha_ctx(actor="intruder")).as_dict()
        assert d["status"] == "fail"
        assert d["failed"] == 1
        assert len(d["results"][0]["violations"]) > 0

    def test_workflow_path_in_report(self):
        policy = PolicyV2.build(id="p", name="P", applies_to="*",
                                runner_type="github-hosted")
        ctx = make_gha_ctx(workflow_path=".github/workflows/deploy.yml")
        d = engine.evaluate_all([policy], ctx, workflow_path=ctx.workflow_path).as_dict()
        assert d["workflow"] == ".github/workflows/deploy.yml"