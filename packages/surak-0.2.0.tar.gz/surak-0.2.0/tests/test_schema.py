"""Tests for PolicyV2 schema and workflow matching."""

import pytest
from pydantic import ValidationError

from surak.schema import PolicyV2
from tests.conftest import make_policy


def test_valid_policy_parses():
    p = make_policy()
    assert p.id == "test"
    assert p.surak == "v2"


def test_wildcard_applies_to():
    p = make_policy(applies_to="*")
    assert p.matches_workflow(".github/workflows/anything.yml")
    assert p.matches_workflow(".github/workflows/deploy.yml")


def test_specific_path_matches():
    p = make_policy(applies_to=[".github/workflows/deploy.yml"])
    assert p.matches_workflow(".github/workflows/deploy.yml")
    assert not p.matches_workflow(".github/workflows/staging.yml")


def test_normalised_path_match():
    p = make_policy(applies_to=[".github/workflows/deploy.yml"])
    # Should match with or without leading ./
    assert p.matches_workflow("./.github/workflows/deploy.yml")
    assert p.matches_workflow("github/workflows/deploy.yml")


def test_multiple_applies_to():
    p = make_policy(applies_to=[
        ".github/workflows/deploy.yml",
        ".github/workflows/release.yml",
    ])
    assert p.matches_workflow(".github/workflows/deploy.yml")
    assert p.matches_workflow(".github/workflows/release.yml")
    assert not p.matches_workflow(".github/workflows/ci.yml")


def test_missing_policies_block_raises():
    with pytest.raises(ValidationError):
        PolicyV2.model_validate({
            "surak": "v2",
            "id": "test",
            "name": "Test",
            "applies-to": "*",
            "policies": {},
        })


def test_v1_schema_rejected():
    with pytest.raises(ValidationError):
        PolicyV2.model_validate({
            "surak": "v1",
            "id": "test",
            "name": "Test",
            "applies-to": "*",
            "policies": {"actor_allowlist": {"enabled": True, "allow": ["octocat"]}},
        })


# ── PolicyV2.build() ───────────────────────────────────────────────────────

class TestPolicyBuild:
    def test_build_minimal(self):
        p = PolicyV2.build(
            id="test", name="Test", applies_to="*",
            actor_allowlist=["octocat"],
        )
        assert p.id == "test"
        assert p.policies.actor_allowlist.allow == ["octocat"]

    def test_build_all_constraints(self):
        p = PolicyV2.build(
            id="full", name="Full", applies_to=["deploy.yml"],
            actor_allowlist=["octocat"],
            runner_type="github-hosted", runner_os=["Linux"], runner_image=["ubuntu-22.04"],
            branch_protection="main",
            required_checks=["Tests", "Lint"],
        )
        assert p.policies.branch_protection.require == "main"
        assert p.policies.required_checks.checks == ["Tests", "Lint"]
        assert p.policies.runner_type.require == "github-hosted"
        assert p.policies.runner_image.allow == ["ubuntu-22.04"]

    def test_build_no_constraints_raises(self):
        with pytest.raises(ValueError, match="At least one"):
            PolicyV2.build(id="empty", name="Empty", applies_to="*")

    def test_build_evaluates_correctly(self):
        from surak.engine import SurakEngine
        from tests.conftest import make_ctx

        policy = PolicyV2.build(
            id="gate", name="Gate",
            applies_to=[".github/workflows/deploy.yml"],
            actor_allowlist=["octocat"],
            branch_protection="main",
        )
        engine = SurakEngine()
        report = engine.evaluate_all([policy], make_ctx(actor="octocat", branch="main"))
        assert report.ok

    def test_build_violation(self):
        from surak.engine import SurakEngine
        from tests.conftest import make_ctx

        policy = PolicyV2.build(
            id="gate", name="Gate", applies_to="*",
            actor_allowlist=["octocat"],
        )
        engine = SurakEngine()
        report = engine.evaluate_all([policy], make_ctx(actor="intruder"))
        assert not report.ok


class TestFromYaml:
    def test_from_yaml_roundtrip(self):
        yaml_text = """
surak: v2
id: yaml-test
name: YAML Test
applies-to: "*"
policies:
  actor_allowlist:
    enabled: true
    allow: [octocat]
"""
        p = PolicyV2.from_yaml(yaml_text)
        assert p.id == "yaml-test"
        assert p.policies.actor_allowlist.allow == ["octocat"]

    def test_from_yaml_bytes(self):
        # GitHub API returns decoded_content as bytes
        yaml_bytes = b"surak: v2\nid: b\nname: B\napplies-to: \"*\"\npolicies:\n  actor_allowlist:\n    enabled: true\n    allow: [octocat]\n"
        p = PolicyV2.from_yaml(yaml_bytes)
        assert p.id == "b"