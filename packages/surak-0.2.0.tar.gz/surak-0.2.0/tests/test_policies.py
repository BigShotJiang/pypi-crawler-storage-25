"""Tests for individual policy evaluators."""

import pytest

from surak.context.base import CheckStatus
from surak.policies import (
    ActorAllowlistEvaluator,
    BranchProtectionEvaluator,
    RequiredChecksEvaluator,
    RunnerArchEvaluator,
    RunnerImageEvaluator,
    RunnerOsEvaluator,
    RunnerTypeEvaluator,
)
from surak.schema import (
    ActorAllowlistConfig,
    BranchProtectionConfig,
    RequiredChecksConfig,
    RunnerArchConfig,
    RunnerImageConfig,
    RunnerOsConfig,
    RunnerTypeConfig,
)
from tests.conftest import make_ctx


def _ctx_github(**kw):
    return make_ctx(runner_labels=["github-hosted", "Linux", "ubuntu-22.04", "X64"], **kw)

def _ctx_self_hosted(**kw):
    return make_ctx(runner_labels=["self-hosted", "Linux", "X64"], runner_os="Linux", **kw)


# ── Actor allowlist ────────────────────────────────────────────────────────

class TestActorAllowlist:
    def _eval(self, allow, **ctx_kwargs):
        cfg = ActorAllowlistConfig(enabled=True, allow=allow)
        return ActorAllowlistEvaluator(cfg).evaluate(make_ctx(**ctx_kwargs))

    def test_allowed_actor_passes(self):
        assert self._eval(["octocat"], actor="octocat").passed

    def test_unlisted_actor_fails(self):
        r = self._eval(["octocat"], actor="bad-actor")
        assert not r.passed
        assert "bad-actor" in r.violations[0]

    def test_glob_pattern(self):
        assert self._eval(["bot-*"], actor="bot-deploy").passed
        assert not self._eval(["bot-*"], actor="octocat").passed

    def test_no_actor_fails(self):
        assert not self._eval(["octocat"], actor=None).passed

    def test_disabled_always_passes(self):
        cfg = ActorAllowlistConfig(enabled=False, allow=[])
        assert ActorAllowlistEvaluator(cfg).evaluate(make_ctx(actor="anyone")).passed


# ── Runner type ────────────────────────────────────────────────────────────

class TestRunnerType:
    def test_github_hosted_passes(self):
        cfg = RunnerTypeConfig(enabled=True, require="github-hosted")
        assert RunnerTypeEvaluator(cfg).evaluate(_ctx_github()).passed

    def test_self_hosted_blocked(self):
        cfg = RunnerTypeConfig(enabled=True, require="github-hosted")
        r = RunnerTypeEvaluator(cfg).evaluate(_ctx_self_hosted())
        assert not r.passed
        assert "self-hosted" in r.violations[0]

    def test_require_self_hosted_passes(self):
        cfg = RunnerTypeConfig(enabled=True, require="self-hosted")
        assert RunnerTypeEvaluator(cfg).evaluate(_ctx_self_hosted()).passed

    def test_unknown_env_fails(self):
        cfg = RunnerTypeConfig(enabled=True, require="github-hosted")
        ctx = make_ctx(runner_labels=[])
        assert not RunnerTypeEvaluator(cfg).evaluate(ctx).passed


# ── Runner OS ──────────────────────────────────────────────────────────────

class TestRunnerOs:
    def test_allowed_os_passes(self):
        cfg = RunnerOsConfig(enabled=True, allow=["Linux"])
        assert RunnerOsEvaluator(cfg).evaluate(make_ctx(runner_os="Linux")).passed

    def test_disallowed_os_fails(self):
        cfg = RunnerOsConfig(enabled=True, allow=["Linux"])
        r = RunnerOsEvaluator(cfg).evaluate(make_ctx(runner_os="Windows"))
        assert not r.passed

    def test_no_os_fails(self):
        cfg = RunnerOsConfig(enabled=True, allow=["Linux"])
        assert not RunnerOsEvaluator(cfg).evaluate(make_ctx(runner_os=None)).passed


# ── Runner arch ────────────────────────────────────────────────────────────

class TestRunnerArch:
    def test_x64_passes(self):
        cfg = RunnerArchConfig(enabled=True, allow=["X64"])
        ctx = make_ctx(runner_labels=["X64", "github-hosted"])
        assert RunnerArchEvaluator(cfg).evaluate(ctx).passed

    def test_arm64_blocked(self):
        cfg = RunnerArchConfig(enabled=True, allow=["X64"])
        ctx = make_ctx(runner_labels=["ARM64", "github-hosted"])
        assert not RunnerArchEvaluator(cfg).evaluate(ctx).passed

    def test_unknown_arch_fails(self):
        cfg = RunnerArchConfig(enabled=True, allow=["X64"])
        assert not RunnerArchEvaluator(cfg).evaluate(make_ctx(runner_labels=[])).passed


# ── Runner image ───────────────────────────────────────────────────────────

class TestRunnerImage:
    def test_allowed_image_passes(self):
        cfg = RunnerImageConfig(enabled=True, allow=["ubuntu-22.04"])
        ctx = make_ctx(runner_labels=["ubuntu-22.04", "github-hosted"])
        assert RunnerImageEvaluator(cfg).evaluate(ctx).passed

    def test_disallowed_image_fails(self):
        cfg = RunnerImageConfig(enabled=True, allow=["ubuntu-22.04"])
        ctx = make_ctx(runner_labels=["ubuntu-24.04", "github-hosted"])
        assert not RunnerImageEvaluator(cfg).evaluate(ctx).passed

    def test_skip_if_self_hosted_passes(self):
        cfg = RunnerImageConfig(enabled=True, allow=["ubuntu-22.04"], skip_if_self_hosted=True)
        r = RunnerImageEvaluator(cfg).evaluate(_ctx_self_hosted())
        assert r.passed
        assert r.warnings  # should warn that check was skipped

    def test_no_skip_self_hosted_fails(self):
        cfg = RunnerImageConfig(enabled=True, allow=["ubuntu-22.04"], skip_if_self_hosted=False)
        r = RunnerImageEvaluator(cfg).evaluate(_ctx_self_hosted())
        assert not r.passed

    def test_glob_image(self):
        cfg = RunnerImageConfig(enabled=True, allow=["ubuntu-*"])
        ctx = make_ctx(runner_labels=["ubuntu-24.04", "github-hosted"])
        assert RunnerImageEvaluator(cfg).evaluate(ctx).passed


# ── Branch protection ──────────────────────────────────────────────────────

class TestBranchProtection:
    def test_exact_match_passes(self):
        cfg = BranchProtectionConfig(enabled=True, require="main")
        assert BranchProtectionEvaluator(cfg).evaluate(make_ctx(branch="main")).passed

    def test_wrong_branch_fails(self):
        cfg = BranchProtectionConfig(enabled=True, require="main")
        r = BranchProtectionEvaluator(cfg).evaluate(make_ctx(branch="feature/x"))
        assert not r.passed

    def test_glob_pattern(self):
        cfg = BranchProtectionConfig(enabled=True, require="release/*")
        assert BranchProtectionEvaluator(cfg).evaluate(make_ctx(branch="release/1.0")).passed
        assert not BranchProtectionEvaluator(cfg).evaluate(make_ctx(branch="main")).passed


# ── Required checks ────────────────────────────────────────────────────────

class TestRequiredChecks:
    def test_all_passing(self):
        cfg = RequiredChecksConfig(enabled=True, checks=["Tests"])
        ctx = make_ctx(check_statuses={"Tests": CheckStatus("Tests", "completed", "success")})
        assert RequiredChecksEvaluator(cfg).evaluate(ctx).passed

    def test_missing_check_fails(self):
        cfg = RequiredChecksConfig(enabled=True, checks=["Tests", "Missing"])
        ctx = make_ctx(check_statuses={"Tests": CheckStatus("Tests", "completed", "success")})
        r = RequiredChecksEvaluator(cfg).evaluate(ctx)
        assert not r.passed
        assert any("Missing" in v for v in r.violations)

    def test_failed_check_fails(self):
        cfg = RequiredChecksConfig(enabled=True, checks=["Tests"])
        ctx = make_ctx(check_statuses={"Tests": CheckStatus("Tests", "completed", "failure")})
        assert not RequiredChecksEvaluator(cfg).evaluate(ctx).passed