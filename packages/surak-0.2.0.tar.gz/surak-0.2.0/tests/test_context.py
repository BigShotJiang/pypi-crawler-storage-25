"""Tests for context builders."""

import pytest

from surak.context.manual import ManualContext
from surak.context.webhook import WebhookContext


def test_manual_context_from_dict():
    ctx = ManualContext.from_dict({
        "actor": "octocat",
        "branch": "main",
        "runner_name": "ubuntu-22.04",
        "check_statuses": {
            "Tests": {"status": "completed", "conclusion": "success"},
        },
    }).build()

    assert ctx.actor == "octocat"
    assert ctx.branch == "main"
    assert ctx.check_statuses["Tests"].conclusion == "success"
    assert ctx.source == "manual"


def test_manual_context_shorthand_check_status():
    ctx = ManualContext.from_dict({
        "actor": "octocat",
        "branch": "main",
        "check_statuses": {"Tests": "success"},
    }).build()
    assert ctx.check_statuses["Tests"].status == "success"


def test_webhook_context_workflow_run_event():
    payload = {
        "workflow_run": {
            "triggering_actor": {"login": "octocat"},
            "head_branch": "main",
            "path": ".github/workflows/deploy.yml",
            "name": "Deploy",
            "event": "push",
        }
    }
    ctx = WebhookContext.from_payload(payload).build()
    assert ctx.actor == "octocat"
    assert ctx.branch == "main"
    assert ctx.workflow_path == ".github/workflows/deploy.yml"
    assert ctx.source == "webhook"


def test_webhook_context_injected_checks():
    payload = {
        "workflow_run": {"triggering_actor": {"login": "octocat"}, "head_branch": "main"},
        "_check_statuses": {
            "Tests": {"status": "completed", "conclusion": "success"},
        },
    }
    ctx = WebhookContext.from_payload(payload).build()
    assert ctx.check_statuses["Tests"].conclusion == "success"
