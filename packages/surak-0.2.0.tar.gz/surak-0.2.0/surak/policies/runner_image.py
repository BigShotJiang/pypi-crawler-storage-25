"""Runner image policy — enforces the runner OS version (synthesised from ImageOS)."""

from __future__ import annotations

import fnmatch

from ..context.base import ResolvedContext
from ..schema import RunnerImageConfig
from .base import PolicyResult

_SELF_HOSTED = "self-hosted"


class RunnerImageEvaluator:
    policy_id = "runner_image"

    def __init__(self, config: RunnerImageConfig) -> None:
        self._config = config

    def evaluate(self, ctx: ResolvedContext) -> PolicyResult:
        if not self._config.enabled:
            return PolicyResult(policy_id=self.policy_id, passed=True)

        is_self_hosted = _SELF_HOSTED in ctx.runner_labels

        # skip_if_self_hosted: silently pass — ImageOS is not set on self-hosted runners
        if is_self_hosted and self._config.skip_if_self_hosted:
            return PolicyResult(
                policy_id=self.policy_id,
                passed=True,
                warnings=["runner_image check skipped — self-hosted runner detected."],
            )

        # Find the canonical image label (e.g. ubuntu-22.04) in runner_labels
        # These are synthesised by GHAContext from the ImageOS env var
        canonical_prefixes = ("ubuntu-", "windows-", "macos-")
        image = next(
            (l for l in ctx.runner_labels if any(l.startswith(p) for p in canonical_prefixes)),
            None,
        )

        if not image:
            msg = (
                "Runner image could not be determined (ImageOS not set). "
                "This env var is only available on github-hosted runners."
            )
            if is_self_hosted:
                msg += " Use skip_if_self_hosted: true to skip this check on self-hosted runners."
            return PolicyResult(
                policy_id=self.policy_id,
                passed=False,
                violations=[msg],
            )

        allowed = self._config.allow
        if any(fnmatch.fnmatch(image, pattern) for pattern in allowed):
            return PolicyResult(policy_id=self.policy_id, passed=True)

        return PolicyResult(
            policy_id=self.policy_id,
            passed=False,
            violations=[
                f"Runner image '{image}' is not allowed. Allowed: {', '.join(allowed)}"
            ],
        )