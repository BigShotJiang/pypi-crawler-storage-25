"""Branch protection policy — enforces that a workflow runs from a specific branch."""

from __future__ import annotations

import fnmatch

from ..context.base import ResolvedContext
from ..schema import BranchProtectionConfig
from .base import PolicyResult


class BranchProtectionEvaluator:
    policy_id = "branch_protection"

    def __init__(self, config: BranchProtectionConfig) -> None:
        self._config = config

    def evaluate(self, ctx: ResolvedContext) -> PolicyResult:
        if not self._config.enabled:
            return PolicyResult(policy_id=self.policy_id, passed=True)

        branch = ctx.branch
        if not branch:
            return PolicyResult(
                policy_id=self.policy_id,
                passed=False,
                violations=["Branch could not be determined from context."],
            )

        required = self._config.require

        # Glob support: "release/*", "hotfix/**"
        if fnmatch.fnmatch(branch, required):
            return PolicyResult(policy_id=self.policy_id, passed=True)

        return PolicyResult(
            policy_id=self.policy_id,
            passed=False,
            violations=[
                f"Branch '{branch}' does not match required branch pattern '{required}'."
            ],
        )
