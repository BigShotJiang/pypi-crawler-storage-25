"""Actor allowlist policy — restricts who can trigger a workflow."""

from __future__ import annotations

import fnmatch

from ..context.base import ResolvedContext
from ..schema import ActorAllowlistConfig
from .base import PolicyResult


class ActorAllowlistEvaluator:
    policy_id = "actor_allowlist"

    def __init__(self, config: ActorAllowlistConfig) -> None:
        self._config = config

    def evaluate(self, ctx: ResolvedContext) -> PolicyResult:
        if not self._config.enabled:
            return PolicyResult(policy_id=self.policy_id, passed=True)

        actor = ctx.actor
        if not actor:
            return PolicyResult(
                policy_id=self.policy_id,
                passed=False,
                violations=["Actor could not be determined from context."],
            )

        allowed = self._config.allow

        # Glob support: allow entries like "dependabot[bot]" or "bot-*"
        matched = any(fnmatch.fnmatch(actor, pattern) for pattern in allowed)

        if matched:
            return PolicyResult(policy_id=self.policy_id, passed=True)

        return PolicyResult(
            policy_id=self.policy_id,
            passed=False,
            violations=[
                f"Actor '{actor}' is not in the allowlist. "
                f"Allowed: {', '.join(allowed) if allowed else '(none)'}"
            ],
        )
