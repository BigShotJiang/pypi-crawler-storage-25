"""Base types for prebuilt policy evaluators."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable

from ..context.base import ResolvedContext


@dataclass
class PolicyResult:
    policy_id: str          # e.g. "actor_allowlist"
    passed: bool
    violations: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def __bool__(self) -> bool:
        return self.passed


@runtime_checkable
class PolicyEvaluator(Protocol):
    policy_id: str

    def evaluate(self, ctx: ResolvedContext) -> PolicyResult: ...
