"""Required checks policy — enforces that named check suites have passed."""

from __future__ import annotations

from ..context.base import ResolvedContext
from ..schema import RequiredChecksConfig
from .base import PolicyResult

_PASSING = {"success", "neutral"}


class RequiredChecksEvaluator:
    policy_id = "required_checks"

    def __init__(self, config: RequiredChecksConfig) -> None:
        self._config = config

    def evaluate(self, ctx: ResolvedContext) -> PolicyResult:
        if not self._config.enabled:
            return PolicyResult(policy_id=self.policy_id, passed=True)

        violations: list[str] = []
        warnings: list[str] = []

        for check_name in self._config.checks:
            status = ctx.check_statuses.get(check_name)

            if status is None:
                violations.append(
                    f"Check '{check_name}' was not found. "
                    "Ensure GITHUB_TOKEN has 'checks: read' permission and the check has run."
                )
                continue

            # A completed check with a passing conclusion
            if status.status == "completed" and status.conclusion in _PASSING:
                continue

            # Still running
            if status.status in ("queued", "in_progress"):
                violations.append(
                    f"Check '{check_name}' is still {status.status} — cannot pass policy."
                )
                continue

            # Failed / cancelled / timed_out / action_required
            conclusion = status.conclusion or status.status
            violations.append(
                f"Check '{check_name}' did not pass (conclusion: {conclusion})."
            )

        passed = len(violations) == 0
        return PolicyResult(
            policy_id=self.policy_id,
            passed=passed,
            violations=violations,
            warnings=warnings,
        )
