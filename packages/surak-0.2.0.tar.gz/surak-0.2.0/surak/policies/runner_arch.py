"""Runner architecture policy — enforces RUNNER_ARCH."""

from __future__ import annotations

import fnmatch

from ..context.base import ResolvedContext
from ..schema import RunnerArchConfig
from .base import PolicyResult


class RunnerArchEvaluator:
    policy_id = "runner_arch"

    def __init__(self, config: RunnerArchConfig) -> None:
        self._config = config

    def evaluate(self, ctx: ResolvedContext) -> PolicyResult:
        if not self._config.enabled:
            return PolicyResult(policy_id=self.policy_id, passed=True)

        arch = next(
            (l for l in ctx.runner_labels if l in ("X64", "ARM64", "X86")),
            None,
        )

        if not arch:
            return PolicyResult(
                policy_id=self.policy_id,
                passed=False,
                violations=["Runner architecture could not be determined (RUNNER_ARCH not set)."],
            )

        allowed = self._config.allow
        if any(fnmatch.fnmatch(arch, pattern) for pattern in allowed):
            return PolicyResult(policy_id=self.policy_id, passed=True)

        return PolicyResult(
            policy_id=self.policy_id,
            passed=False,
            violations=[
                f"Runner architecture '{arch}' is not allowed. Allowed: {', '.join(allowed)}"
            ],
        )