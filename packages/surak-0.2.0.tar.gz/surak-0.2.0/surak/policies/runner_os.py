"""Runner OS policy — enforces operating system (RUNNER_OS)."""

from __future__ import annotations

import fnmatch

from ..context.base import ResolvedContext
from ..schema import RunnerOsConfig
from .base import PolicyResult


class RunnerOsEvaluator:
    policy_id = "runner_os"

    def __init__(self, config: RunnerOsConfig) -> None:
        self._config = config

    def evaluate(self, ctx: ResolvedContext) -> PolicyResult:
        if not self._config.enabled:
            return PolicyResult(policy_id=self.policy_id, passed=True)

        os = ctx.runner_os
        if not os:
            return PolicyResult(
                policy_id=self.policy_id,
                passed=False,
                violations=["Runner OS could not be determined (RUNNER_OS not set)."],
            )

        allowed = self._config.allow
        if any(fnmatch.fnmatch(os, pattern) for pattern in allowed):
            return PolicyResult(policy_id=self.policy_id, passed=True)

        return PolicyResult(
            policy_id=self.policy_id,
            passed=False,
            violations=[
                f"Runner OS '{os}' is not allowed. Allowed: {', '.join(allowed)}"
            ],
        )