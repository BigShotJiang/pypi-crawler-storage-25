"""Runner type policy — enforces github-hosted vs self-hosted."""

from __future__ import annotations

from ..context.base import ResolvedContext
from ..schema import RunnerTypeConfig
from .base import PolicyResult


class RunnerTypeEvaluator:
    policy_id = "runner_type"

    def __init__(self, config: RunnerTypeConfig) -> None:
        self._config = config

    def evaluate(self, ctx: ResolvedContext) -> PolicyResult:
        if not self._config.enabled:
            return PolicyResult(policy_id=self.policy_id, passed=True)

        env = next(
            (l for l in ctx.runner_labels if l in ("github-hosted", "self-hosted")),
            None,
        )

        if not env:
            return PolicyResult(
                policy_id=self.policy_id,
                passed=False,
                violations=["Runner environment (github-hosted/self-hosted) could not be determined."],
            )

        if env == self._config.require:
            return PolicyResult(policy_id=self.policy_id, passed=True)

        return PolicyResult(
            policy_id=self.policy_id,
            passed=False,
            violations=[
                f"Runner is '{env}' but policy requires '{self._config.require}'."
            ],
        )