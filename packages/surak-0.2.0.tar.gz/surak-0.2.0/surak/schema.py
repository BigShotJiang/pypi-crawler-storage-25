"""Surak v2 policy schema — Pydantic models."""

from __future__ import annotations

from typing import Literal, Optional, Union
import yaml
from pathlib import Path
from pydantic import BaseModel, Field, model_validator


# ---------------------------------------------------------------------------
# Per-policy config blocks
# ---------------------------------------------------------------------------

class ActorAllowlistConfig(BaseModel):
    enabled: bool = True
    allow: list[str] = Field(default_factory=list)
    teams: list[str] = Field(default_factory=list)


class RunnerTypeConfig(BaseModel):
    """Enforce whether the runner must be github-hosted or self-hosted."""
    enabled: bool = True
    require: Literal["github-hosted", "self-hosted"]


class RunnerOsConfig(BaseModel):
    """Enforce the runner operating system (RUNNER_OS)."""
    enabled: bool = True
    allow: list[str] = Field(default_factory=list)  # Linux | Windows | macOS


class RunnerArchConfig(BaseModel):
    """Enforce the runner architecture (RUNNER_ARCH)."""
    enabled: bool = True
    allow: list[str] = Field(default_factory=list)  # X64 | ARM64


class RunnerImageConfig(BaseModel):
    """
    Enforce the runner image version (synthesised from ImageOS).
    Only available on github-hosted runners.
    Use skip_if_self_hosted: true to silently pass on self-hosted runners.
    """
    enabled: bool = True
    allow: list[str] = Field(default_factory=list)  # ubuntu-22.04 | ubuntu-24.04 | macos-14 etc.
    skip_if_self_hosted: bool = False


class BranchProtectionConfig(BaseModel):
    enabled: bool = True
    require: str


class RequiredChecksConfig(BaseModel):
    enabled: bool = True
    checks: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Top-level policies block
# ---------------------------------------------------------------------------

class PoliciesBlock(BaseModel):
    actor_allowlist: Optional[ActorAllowlistConfig] = None
    runner_type: Optional[RunnerTypeConfig] = None
    runner_os: Optional[RunnerOsConfig] = None
    runner_arch: Optional[RunnerArchConfig] = None
    runner_image: Optional[RunnerImageConfig] = None
    branch_protection: Optional[BranchProtectionConfig] = None
    required_checks: Optional[RequiredChecksConfig] = None

    @model_validator(mode="after")
    def at_least_one_policy(self) -> "PoliciesBlock":
        fields = [
            self.actor_allowlist,
            self.runner_type,
            self.runner_os,
            self.runner_arch,
            self.runner_image,
            self.branch_protection,
            self.required_checks,
        ]
        if not any(f is not None for f in fields):
            raise ValueError("At least one policy must be defined.")
        return self


# ---------------------------------------------------------------------------
# Top-level policy
# ---------------------------------------------------------------------------

class PolicyV2(BaseModel):
    surak: Literal["v2"]
    id: str
    name: str
    applies_to: Union[Literal["*"], list[str]] = Field(alias="applies-to")
    policies: PoliciesBlock

    model_config = {"populate_by_name": True}

    def matches_workflow(self, workflow_path: str) -> bool:
        if self.applies_to == "*":
            return True
        def _norm(p: str) -> str:
            return p.lstrip("./")
        needle = _norm(workflow_path)
        return any(_norm(p) == needle for p in self.applies_to)  # type: ignore[union-attr]

    # ------------------------------------------------------------------
    # Constructors
    # ------------------------------------------------------------------

    @classmethod
    def from_file(cls, path: Path) -> "PolicyV2":
        with open(path) as f:
            data = yaml.safe_load(f)
        return cls.model_validate(data)

    @classmethod
    def from_dict(cls, data: dict) -> "PolicyV2":
        return cls.model_validate(data)

    @classmethod
    def from_yaml(cls, text: str) -> "PolicyV2":
        """Parse from raw YAML text — useful when fetching from the GitHub API."""
        return cls.model_validate(yaml.safe_load(text))

    @classmethod
    def build(
        cls,
        id: str,
        name: str,
        applies_to: Union[Literal["*"], list[str]],
        *,
        actor_allowlist: Optional[list[str]] = None,
        runner_type: Optional[Literal["github-hosted", "self-hosted"]] = None,
        runner_os: Optional[list[str]] = None,
        runner_arch: Optional[list[str]] = None,
        runner_image: Optional[list[str]] = None,
        runner_image_skip_if_self_hosted: bool = False,
        branch_protection: Optional[str] = None,
        required_checks: Optional[list[str]] = None,
    ) -> "PolicyV2":
        """
        Construct a PolicyV2 programmatically — no YAML or files needed.

        Runner policies:
            runner_type:    "github-hosted" or "self-hosted"
            runner_os:      ["Linux", "macOS", "Windows"]
            runner_arch:    ["X64", "ARM64"]
            runner_image:   ["ubuntu-22.04", "ubuntu-24.04", "macos-14"]
                            Only available on github-hosted runners.
                            Set runner_image_skip_if_self_hosted=True to
                            silently pass when running on self-hosted.
        """
        policies: dict = {}

        if actor_allowlist is not None:
            policies["actor_allowlist"] = {"enabled": True, "allow": actor_allowlist}

        if runner_type is not None:
            policies["runner_type"] = {"enabled": True, "require": runner_type}

        if runner_os is not None:
            policies["runner_os"] = {"enabled": True, "allow": runner_os}

        if runner_arch is not None:
            policies["runner_arch"] = {"enabled": True, "allow": runner_arch}

        if runner_image is not None:
            policies["runner_image"] = {
                "enabled": True,
                "allow": runner_image,
                "skip_if_self_hosted": runner_image_skip_if_self_hosted,
            }

        if branch_protection is not None:
            policies["branch_protection"] = {"enabled": True, "require": branch_protection}

        if required_checks is not None:
            policies["required_checks"] = {"enabled": True, "checks": required_checks}

        if not policies:
            raise ValueError("At least one policy constraint must be provided.")

        return cls.model_validate({
            "surak": "v2",
            "id": id,
            "name": name,
            "applies-to": applies_to,
            "policies": policies,
        })