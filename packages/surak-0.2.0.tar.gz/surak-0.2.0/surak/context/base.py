"""Base context protocol — all context builders must satisfy this."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Protocol, runtime_checkable


@dataclass
class CheckStatus:
    name: str
    status: str  # "success" | "failure" | "pending" | "skipped"
    conclusion: Optional[str] = None


@dataclass
class ResolvedContext:
    """
    Normalised context passed to every policy evaluator.

    Populated from GHA env vars, webhook payloads, or manually for dry-runs.
    Fields that could not be resolved are None — evaluators must handle this.
    """

    # Who triggered the run
    actor: Optional[str] = None

    # The ref that triggered the workflow — normalised to plain branch name
    # e.g. "refs/heads/main" → "main"
    branch: Optional[str] = None

    # Runner info
    runner_name: Optional[str] = None
    runner_os: Optional[str] = None
    runner_labels: list[str] = field(default_factory=list)

    # Workflow metadata
    workflow_path: Optional[str] = None   # .github/workflows/deploy.yml
    workflow_name: Optional[str] = None
    event_name: Optional[str] = None

    # Check suites — populated lazily (requires API call)
    check_statuses: dict[str, CheckStatus] = field(default_factory=dict)

    # Raw source for debugging / pass-through
    source: str = "unknown"   # "gha_env" | "webhook" | "manual"

    def summary(self) -> dict:
        return {
            "actor": self.actor,
            "branch": self.branch,
            "runner_name": self.runner_name,
            "runner_os": self.runner_os,
            "runner_labels": self.runner_labels,
            "workflow_path": self.workflow_path,
            "event_name": self.event_name,
            "check_statuses": list(self.check_statuses.keys()),
            "source": self.source,
        }


@runtime_checkable
class ContextBuilder(Protocol):
    def build(self) -> ResolvedContext: ...
