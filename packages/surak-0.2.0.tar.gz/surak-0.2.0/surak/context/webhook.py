"""Webhook context builder — builds ResolvedContext from a GitHub webhook payload."""

from __future__ import annotations

from typing import Any

from .base import CheckStatus, ResolvedContext
from .gha import _normalise_ref


class WebhookContext:
    """
    Builds a ResolvedContext from a GitHub webhook payload dict.

    Suitable for SpockOps — receives the payload from GitHub App webhooks and
    extracts the same fields the GHA env-based builder produces.

    Usage:
        ctx = WebhookContext.from_payload(payload).build()
    """

    def __init__(self, payload: dict[str, Any]) -> None:
        self._payload = payload

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "WebhookContext":
        return cls(payload)

    def build(self) -> ResolvedContext:
        p = self._payload

        # workflow_run event is the primary source
        wf_run = p.get("workflow_run", {})
        sender = p.get("sender", {})

        actor = (
            wf_run.get("triggering_actor", {}).get("login")
            or sender.get("login")
        )

        raw_ref = wf_run.get("head_branch") or p.get("ref")
        branch = _normalise_ref(raw_ref) if raw_ref and raw_ref.startswith("refs/") else raw_ref

        # Runner info is not available in webhook payloads — populated separately
        # if the caller has it (e.g. from a prior API call or job metadata).
        runner_name = p.get("_runner_name")
        runner_os = p.get("_runner_os")
        runner_labels: list[str] = p.get("_runner_labels", [])

        workflow_path = wf_run.get("path")  # .github/workflows/deploy.yml
        workflow_name = wf_run.get("name")
        event_name = wf_run.get("event") or p.get("action")

        # Check statuses — caller can inject pre-fetched statuses
        raw_checks: dict[str, Any] = p.get("_check_statuses", {})
        check_statuses: dict[str, CheckStatus] = {}
        for name, info in raw_checks.items():
            check_statuses[name] = CheckStatus(
                name=name,
                status=info.get("status", "unknown"),
                conclusion=info.get("conclusion"),
            )

        return ResolvedContext(
            actor=actor,
            branch=branch,
            runner_name=runner_name,
            runner_os=runner_os,
            runner_labels=runner_labels,
            workflow_path=workflow_path,
            workflow_name=workflow_name,
            event_name=event_name,
            check_statuses=check_statuses,
            source="webhook",
        )
