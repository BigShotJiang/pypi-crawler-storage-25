"""Surak exceptions."""


class SurakError(Exception):
    """Base exception for all Surak errors."""


class PolicyLoadError(SurakError):
    """Raised when a policy file cannot be loaded or parsed."""


class ContextError(SurakError):
    """Raised when context cannot be resolved."""
