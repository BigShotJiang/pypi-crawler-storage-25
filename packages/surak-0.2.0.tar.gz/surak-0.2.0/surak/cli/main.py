"""Surak CLI v2 — prebuilt policy engine for CI/CD."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Optional

import click

from ..context.gha import GHAContext
from ..context.manual import ManualContext
from ..engine import SurakEngine
from ..exceptions import SurakError
from ..schema import PolicyV2
from .symbols import Symbols


ASCII_ART = r"""
╔════════════════════════════════╗
║ ╔══╗ ╦╦═╗╔═╗╦╔═════════════✶   ║
║ ╚═╗║ ║╠╦╝╠═╣╠╩╗  v2.0          ║
║ ╚═╝╚═╝╩╚═╩ ╩╩ ╩  POLICY ENGINE ║
╠════════════════════════════════╣
║  https://spockops.com/surak    ║
╚════════════════════════════════╝

"Logic over chaos,
Policies enforce the rules—
Wisdom guards your builds."

"""

# ---------------------------------------------------------------------------
# Dummy context — used when --dummy flag is passed (local dev / smoke testing)
# ---------------------------------------------------------------------------

DUMMY_CONTEXT: dict = {
    "actor": "octocat",
    "branch": "main",
    "runner_name": "GitHub Actions 2",
    "runner_os": "Linux",
    "runner_labels": ["github-hosted", "Linux", "ubuntu-22.04", "X64"],
    "workflow_path": ".github/workflows/deploy.yml",
    "workflow_name": "Deploy",
    "event_name": "push",
    "check_statuses": {
        "Tests": {"status": "completed", "conclusion": "success"},
        "Security Scan": {"status": "completed", "conclusion": "success"},
        "Lint": {"status": "completed", "conclusion": "success"},
    },
}


def _load_policies(paths: tuple[str, ...]) -> list[PolicyV2]:
    engine = SurakEngine()
    policies: list[PolicyV2] = []
    for raw in paths:
        p = Path(raw)
        if p.is_dir():
            policies.extend(engine.load_dir(p))
        else:
            policies.append(engine.load_file(p))
    return policies


def _assert_workflow_exists(workflow: str) -> None:
    """Exit with a clear error if the workflow file doesn't exist on disk."""
    if not Path(workflow).exists():
        click.echo(
            click.style(f"{Symbols.CROSS} Workflow file not found: {workflow}", fg="red"),
            err=True,
        )
        click.echo(
            f"  Make sure the path is relative to your repo root and the file exists.",
            err=True,
        )
        sys.exit(1)


def _print_report(report, json_output: bool) -> None:  # type: ignore[no-untyped-def]
    S = Symbols
    if json_output:
        click.echo(json.dumps(report.as_dict(), indent=2))
        return

    click.echo(f"\n{S.SEPARATOR * 50}")
    for r in report.results:
        icon = S.CHECK if r.passed else S.CROSS
        click.echo(f"{icon} {r.policy_name} [{r.policy_id}]")
        for v in r.violations:
            click.echo(f"   {S.CROSS} {v}")
        for w in r.warnings:
            click.echo(f"   {S.WARNING} {w}")

    click.echo(S.SEPARATOR * 50)
    if report.ok:
        click.echo(
            click.style(
                f"{S.CHECK} All policies passed! ({report.passed}/{report.total})",
                fg="green",
                bold=True,
            )
        )
    else:
        click.echo(
            click.style(
                f"{S.CROSS} {report.failed} policy(ies) failed ({report.passed} passed)",
                fg="red",
                bold=True,
            )
        )


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

@click.group(invoke_without_command=True)
@click.pass_context
@click.version_option(version="0.2.0", prog_name="surak")
def cli(ctx: click.Context) -> None:
    """Surak — Universal Policy Engine for CI/CD (v2)."""
    if ctx.invoked_subcommand is None:
        click.echo(click.style(ASCII_ART, fg="bright_green", bold=True))
        click.echo(ctx.get_help())


@cli.command()
def haiku() -> None:
    """Print the Surak banner."""
    click.echo(click.style(ASCII_ART, fg="bright_green", bold=True))


# ---------------------------------------------------------------------------
# eval
# ---------------------------------------------------------------------------

@cli.command()
@click.argument("policies", nargs=-1, type=click.Path(exists=True), required=True)
@click.option("--workflow", help="Workflow file path (overrides auto-detect)")
@click.option("--context", "context_file", type=click.Path(exists=True), help="Context JSON file")
@click.option("--dummy", is_flag=True, help="Use built-in dummy context (local dev)")
@click.option("--strict/--no-strict", default=True, help="Exit 1 on policy failure")
@click.option("--json-output", is_flag=True, help="Output as JSON")
def eval(  # noqa: A001
    policies: tuple[str, ...],
    workflow: Optional[str],
    context_file: Optional[str],
    dummy: bool,
    strict: bool,
    json_output: bool,
) -> None:
    """
    Evaluate policies against current context.

    \b
    Examples:
      # In GitHub Actions (auto-detects context):
      surak eval .surak/*.yml

      # Local dev with dummy context:
      surak eval .surak/*.yml --dummy

      # With a context JSON file:
      surak eval .surak/*.yml --context ctx.json

      # Target a specific workflow:
      surak eval .surak/*.yml --workflow .github/workflows/deploy.yml --dummy
    """
    try:
        all_policies = _load_policies(policies)

        if not json_output:
            click.echo(click.style(ASCII_ART, fg="bright_green", bold=True))
            click.echo(f"{Symbols.INFO} Loaded {len(all_policies)} policy(ies)")

        # --- Build context ---
        if dummy:
            ctx = ManualContext.from_dict(DUMMY_CONTEXT).build()
            if not json_output:
                click.echo(
                    click.style(
                        f"{Symbols.WARNING} Using dummy context (not for production)",
                        fg="yellow",
                    )
                )
        elif context_file:
            with open(context_file) as f:
                raw = json.load(f)
            ctx = ManualContext.from_dict(raw).build()
        else:
            # Auto-resolve from GHA env
            ctx = GHAContext().build()

        # --- Resolve workflow path ---
        wf_path = workflow or ctx.workflow_path
        if wf_path and workflow:
            # Only validate existence when explicitly passed — not when auto-resolved from env
            _assert_workflow_exists(wf_path)
        if not json_output and wf_path:
            click.echo(f"{Symbols.INFO} Workflow: {wf_path}")

        # --- Filter applicable policies ---
        engine = SurakEngine()
        if wf_path:
            applicable = engine.for_workflow(wf_path, all_policies)
        else:
            applicable = all_policies  # applies-to: * or no path known

        if not json_output:
            click.echo(f"{Symbols.INFO} {len(applicable)} policy(ies) apply to this workflow\n")

        if not applicable:
            if json_output:
                click.echo(json.dumps({"status": "skipped", "message": "No matching policies"}))
            else:
                click.echo(f"{Symbols.INFO} No policies match — nothing to enforce.")
            sys.exit(0)

        # --- Evaluate ---
        report = engine.evaluate_all(applicable, ctx, workflow_path=wf_path)
        _print_report(report, json_output)

        if strict and not report.ok:
            sys.exit(1)

    except SurakError as exc:
        click.echo(f"{Symbols.CROSS} {exc}", err=True)
        sys.exit(1)


# ---------------------------------------------------------------------------
# validate
# ---------------------------------------------------------------------------

@cli.command()
@click.argument("policy", type=click.Path(exists=True), required=True)
def validate(policy: str) -> None:
    """
    Validate a policy file's syntax and structure.

    \b
    Example:
      surak validate .surak/deploy.yml
    """
    try:
        pol = PolicyV2.from_file(Path(policy))
        click.echo(f"{Symbols.CHECK} Policy is valid")
        click.echo(f"\n  ID:         {pol.id}")
        click.echo(f"  Name:       {pol.name}")
        click.echo(f"  Applies to: {pol.applies_to}")
        active = [k for k, v in pol.policies.model_dump().items() if v and v.get("enabled")]
        click.echo(f"  Policies:   {', '.join(active) if active else '(none enabled)'}")
    except Exception as exc:
        click.echo(f"{Symbols.CROSS} Invalid policy: {exc}", err=True)
        sys.exit(1)


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------

@cli.command("list")
@click.argument("policies", nargs=-1, type=click.Path(exists=True))
def list_cmd(policies: tuple[str, ...]) -> None:
    """
    List all policies and their configuration.

    \b
    Example:
      surak list .surak/
    """
    try:
        all_policies = _load_policies(policies)
        if not all_policies:
            click.echo("No policies found.")
            return

        click.echo(f"Found {len(all_policies)} policy(ies):\n")
        for pol in all_policies:
            click.echo(f"{Symbols.DIAMOND} {pol.id}  —  {pol.name}")
            click.echo(f"  applies-to: {pol.applies_to}")
            pb = pol.policies
            if pb.actor_allowlist and pb.actor_allowlist.enabled:
                click.echo(f"  actor_allowlist:   {pb.actor_allowlist.allow}")
            if pb.runner_type and pb.runner_type.enabled:
                click.echo(f"  runner_type:       require={pb.runner_type.require}")
            if pb.runner_os and pb.runner_os.enabled:
                click.echo(f"  runner_os:         {pb.runner_os.allow}")
            if pb.runner_arch and pb.runner_arch.enabled:
                click.echo(f"  runner_arch:       {pb.runner_arch.allow}")
            if pb.runner_image and pb.runner_image.enabled:
                skip = " (skip_if_self_hosted)" if pb.runner_image.skip_if_self_hosted else ""
                click.echo(f"  runner_image:      {pb.runner_image.allow}{skip}")
            if pb.branch_protection and pb.branch_protection.enabled:
                click.echo(f"  branch_protection: require={pb.branch_protection.require}")
            if pb.required_checks and pb.required_checks.enabled:
                click.echo(f"  required_checks:   {pb.required_checks.checks}")
            click.echo()
    except Exception as exc:
        click.echo(f"{Symbols.CROSS} {exc}", err=True)
        sys.exit(1)


# ---------------------------------------------------------------------------
# check
# ---------------------------------------------------------------------------

@cli.command()
@click.argument("policies", nargs=-1, type=click.Path(exists=True), required=True)
@click.option("--workflow", required=True, help="Workflow file path to test against")
def check(policies: tuple[str, ...], workflow: str) -> None:
    """
    Show which policies would apply to a given workflow.

    \b
    Example:
      surak check .surak/ --workflow .github/workflows/deploy.yml
    """
    try:
        _assert_workflow_exists(workflow)
        all_policies = _load_policies(policies)
        engine = SurakEngine()
        applicable = engine.for_workflow(workflow, all_policies)
        skipped = [p for p in all_policies if p not in applicable]

        click.echo(f"Workflow: {workflow}\n")
        click.echo(
            f"{Symbols.CHECK} {len(applicable)} of {len(all_policies)} policy(ies) apply:\n"
        )
        for p in applicable:
            click.echo(f"  {Symbols.DIAMOND} {p.id}  —  {p.name}")

        if skipped:
            click.echo(f"\n{Symbols.SKIP} {len(skipped)} skipped:\n")
            for p in skipped:
                click.echo(f"  {Symbols.SKIP} {p.id}  —  {p.name}  (applies-to: {p.applies_to})")
    except Exception as exc:
        click.echo(f"{Symbols.CROSS} {exc}", err=True)
        sys.exit(1)


if __name__ == "__main__":
    cli()