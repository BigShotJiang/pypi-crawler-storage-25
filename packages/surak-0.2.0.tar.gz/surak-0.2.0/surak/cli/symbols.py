"""Terminal symbols."""


class Symbols:
    CHECK = "✓"
    CROSS = "✗"
    WARNING = "⚠"
    INFO = "ℹ"
    DIAMOND = "◆"
    BULLET = "•"
    SKIP = "○"
    SEPARATOR = "─"

    @staticmethod
    def status(passed: bool) -> str:
        return Symbols.CHECK if passed else Symbols.CROSS
