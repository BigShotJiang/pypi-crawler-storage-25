# SURAK

**The GitHub Actions Policy Engine**

[![SpockOps](https://img.shields.io/badge/SpockOps-FFE200?style=flat&logoColor=black)](https://spockops.com)
[![PyPI](https://img.shields.io/pypi/v/surak)](https://pypi.org/project/surak/)
[![Python](https://img.shields.io/pypi/pyversions/surak)](https://pypi.org/project/surak/)
[![License](https://img.shields.io/badge/license-Apache%202.0-blue.svg)](LICENSE)

Surak lets you define and enforce policies on your GitHub Actions workflows — who can trigger them, which runners are allowed, which branch they must run from, and which checks must pass first.

Policies live in `.surak/` as YAML files. Surak evaluates them inside your workflows and blocks any run that doesn't comply.

---

## Getting started

### 1. Install

```bash
pip install surak
```

### 2. Create a policy

Create `.surak/governance.yml` — a global policy that applies to every workflow:

```yaml
surak: v2
id: runner-governance
name: Runner Governance

applies-to: "*"

policies:
  runner_type:
    enabled: true
    require: github-hosted

  runner_os:
    enabled: true
    allow:
      - Linux

  runner_image:
    enabled: true
    skip_if_self_hosted: true
    allow:
      - ubuntu-22.04
      - ubuntu-24.04
```

### 3. Add a policy gate to your workflow

```yaml
jobs:
  policy-gate:
    runs-on: ubuntu-22.04
    permissions:
      contents: read
      checks: read
    steps:
      - uses: actions/checkout@v4
      - run: pip install surak
      - run: surak eval .surak/ --json-output
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}

  build:
    needs: policy-gate
    runs-on: ubuntu-22.04
    steps:
      - run: echo "policy gate passed"
```

Any workflow that doesn't meet the policy will be blocked at `policy-gate` before the rest of the jobs run.

### 4. Test locally

```bash
# see which policies apply to a workflow
surak check .surak/ --workflow .github/workflows/build.yml

# evaluate with dummy context
surak eval .surak/ --workflow .github/workflows/build.yml --dummy

# validate a policy file
surak validate .surak/governance.yml
```

---

## Policies

Policies are YAML files in `.surak/`. `applies-to` controls which workflows they target — use `"*"` for all workflows or list specific paths.

| Policy | Enforces |
|---|---|
| `actor_allowlist` | Who can trigger the workflow. Glob patterns supported: `bot-*` |
| `runner_type` | `github-hosted` or `self-hosted` |
| `runner_os` | `Linux`, `Windows`, `macOS` |
| `runner_arch` | `X64`, `ARM64` |
| `runner_image` | Specific image: `ubuntu-22.04`, `macos-14`. Use `skip_if_self_hosted: true` for mixed environments |
| `branch_protection` | Required branch. Glob patterns supported: `release/*` |
| `required_checks` | Check suites that must have passed |

See [Policy Reference](docs/policies.md) for full documentation.

---

## GitHub Action

> Coming soon — drop Surak into any workflow with a single `uses:` step, no Python setup required.
> Follow [spockops/surak](https://github.com/SpockOps/surak) for updates.

---

## Platform support

| Platform | Status |
|---|---|
| GitHub Actions | ✅ |

---

```
"Logic over chaos,
Policies enforce the rules —
Wisdom guards your builds."
```
