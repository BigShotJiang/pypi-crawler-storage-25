## Summary

<!-- What does this PR do and why? -->

## Type of change

- [ ] Bug fix
- [ ] New prebuilt policy
- [ ] New platform / context builder
- [ ] Improvement or refactor
- [ ] Documentation
- [ ] Tests only

## Checklist

- [ ] `pytest tests/ -q` passes
- [ ] `surak eval .surak/ --dummy` passes
- [ ] Docs updated if behaviour changed
- [ ] Version bumped in `pyproject.toml` if this is a release PR

## New policy (if applicable)

**Policy name:** `____`  
**Source env var(s):**  
**Works on self-hosted runners:**  

```yaml
# minimal example
surak: v2
id: example
name: Example
applies-to: "*"
policies:
  your_policy:
    enabled: true
```

## Related issues

Closes #