# GitHub Action

> **Coming soon.** The Surak GitHub Action will let you drop a policy gate into any workflow with a single `uses:` step — no Python setup required.

## Planned usage

```yaml
jobs:
  policy-gate:
    runs-on: ubuntu-22.04
    steps:
      - uses: actions/checkout@v4

      - name: Evaluate Surak policies
        uses: spockops/surak-action@v1
        with:
          policies: .surak/
          strict: true
```

The action will:

- Auto-detect the workflow path and actor from the GHA environment
- Fetch check statuses using the built-in `GITHUB_TOKEN`
- Annotate the run with violations via the GitHub Checks API
- Exit non-zero to block downstream jobs on policy failure

## In the meantime

Use Surak directly in your workflow via the CLI:

```yaml
jobs:
  policy-gate:
    runs-on: ubuntu-22.04
    permissions:
      checks: read
    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"

      - name: Install Surak
        run: pip install surak

      - name: Evaluate policies
        run: surak eval .surak/ --json-output
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
```

Follow [spockops/surak](https://github.com/spockops/surak) for updates.