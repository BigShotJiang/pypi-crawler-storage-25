# Policy Reference

Policies are YAML files stored in `.surak/` at your repo root. Each file defines one policy — which workflows it targets and which rules to enforce.

## File format

```yaml
surak: v2                          # required — must be "v2"
id: prod-deployment                # unique identifier, used in reports
name: Production Deployment Policy # human-readable label

applies-to:                        # which workflows this policy covers
  - .github/workflows/deploy.yml
  - .github/workflows/release.yml
  # or: applies-to: "*"  (all workflows)

policies:                          # one or more prebuilt policies
  actor_allowlist:
    enabled: true
    allow:
      - octocat

  runner_type:
    enabled: true
    require: github-hosted

  runner_os:
    enabled: true
    allow:
      - Linux

  runner_arch:
    enabled: true
    allow:
      - X64

  runner_image:
    enabled: true
    skip_if_self_hosted: true
    allow:
      - ubuntu-22.04
      - ubuntu-24.04

  branch_protection:
    enabled: true
    require: main

  required_checks:
    enabled: true
    checks:
      - Tests
      - Security Scan
```

---

## `applies-to`

Controls which workflow files this policy is evaluated against.

```yaml
# Specific files
applies-to:
  - .github/workflows/deploy.yml
  - .github/workflows/release.yml

# All workflows
applies-to: "*"
```

Paths are matched relative to the repo root. Leading `./` is ignored.

---

## Prebuilt policies

### `actor_allowlist`

Restricts who can trigger the workflow.

```yaml
actor_allowlist:
  enabled: true
  allow:
    - octocat
    - deploy-bot
    - "dependabot[bot]"   # glob patterns supported
    - "bot-*"
```

Matched against `$GITHUB_ACTOR`. Glob patterns via `fnmatch`.

---

### `runner_type`

Enforces whether the runner must be GitHub-hosted or self-hosted. This is the primary security boundary between managed and unmanaged infrastructure.

```yaml
runner_type:
  enabled: true
  require: github-hosted    # or: self-hosted
```

Source: `$RUNNER_ENVIRONMENT`

---

### `runner_os`

Enforces the runner operating system.

```yaml
runner_os:
  enabled: true
  allow:
    - Linux
    - macOS
    # - Windows
```

Source: `$RUNNER_OS`. Values are always capitalised: `Linux`, `Windows`, `macOS`.

---

### `runner_arch`

Enforces the runner CPU architecture.

```yaml
runner_arch:
  enabled: true
  allow:
    - X64
    - ARM64
```

Source: `$RUNNER_ARCH`. Values: `X64`, `ARM64`, `X86`.

---

### `runner_image`

Enforces the specific runner image version. Only available on GitHub-hosted runners — `$ImageOS` is not set on self-hosted runners.

```yaml
runner_image:
  enabled: true
  skip_if_self_hosted: true   # silently pass on self-hosted (recommended)
  allow:
    - ubuntu-22.04
    - ubuntu-24.04
    - macos-14
    - ubuntu-*                # glob patterns supported
```

Source: `$ImageOS` → synthesised to canonical label.

| `ImageOS` value | Canonical label |
|---|---|
| `ubuntu22` | `ubuntu-22.04` |
| `ubuntu24` | `ubuntu-24.04` |
| `ubuntu20` | `ubuntu-20.04` |
| `win22` | `windows-2022` |
| `win19` | `windows-2019` |
| `macos14` | `macos-14` |
| `macos13` | `macos-13` |

Set `skip_if_self_hosted: true` to silently pass when `RUNNER_ENVIRONMENT=self-hosted` — useful when a single policy file covers both runner types.

---

### `branch_protection`

Enforces that the workflow runs from a specific branch.

```yaml
branch_protection:
  enabled: true
  require: main

# Glob patterns:
branch_protection:
  enabled: true
  require: "release/*"
```

Source: `$GITHUB_REF`, normalised (`refs/heads/main` → `main`).

---

### `required_checks`

Enforces that named check suites have passed. Requires `GITHUB_TOKEN` with `checks: read`.

```yaml
required_checks:
  enabled: true
  checks:
    - Tests
    - Security Scan
    - "Tests (3.11)"     # matrix job names — must match exactly as shown in GitHub UI
    - "Tests (3.12)"
```

Add to your workflow job:

```yaml
permissions:
  checks: read
```

A check passes if `status=completed` and `conclusion` is `success` or `neutral`. In-progress or queued checks always fail the policy.

---

## Disabling a policy

```yaml
runner_image:
  enabled: false
  allow:
    - ubuntu-22.04
```

---

## Recommended layout

```
.surak/
├── runner-governance.yml   # applies-to: "*" — global runner rules
├── ci.yml                  # CI workflow rules
└── deploy.yml              # deploy workflow rules — full gate
```