"""Official ManyWe IPC client placeholder package reserved on PyPI."""

__all__ = ["PACKAGE_NAME", "__version__", "placeholder_notice"]

PACKAGE_NAME = "manywe-ipc-client"
__version__ = "0.0.1"

def placeholder_notice() -> str:
    return (
        "manywe-ipc-client is an official ManyWe placeholder package on PyPI. "
        "The public Python implementation is not available yet."
    )
