from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path
import inspect
import logging
from typing import Any, Dict, Iterator, Mapping, Optional, Sequence, Union
import uuid

from consist.core._coupler_shared import CouplerMapMixin
from consist.core.coupler import CouplerView, DeclaredOutput
from consist.core.validation import validate_artifact_key
from consist.protocols import TrackerLike
from consist.types import ExecutionOptions

from consist.models.run import Run


@dataclass
class NoopArtifact:
    """
    Minimal artifact placeholder for noop mode.

    Provides stable accessors for `path` and `get_path()` so integrations can
    rely on a consistent artifact interface when Consist is disabled.
    """

    key: str
    path: Path
    container_uri: str
    meta: Dict[str, Any] = field(default_factory=dict)
    driver: str = "file"
    run_id: Optional[str] = None
    id: Optional[str] = None
    table_path: Optional[str] = None
    array_path: Optional[str] = None

    def get_path(self) -> Path:
        return self.path


@dataclass
class NoopRunResult:
    """
    Minimal RunResult-compatible payload for noop mode.
    """

    outputs: Dict[str, NoopArtifact] = field(default_factory=dict)
    cache_hit: bool = False
    run: Optional[Run] = None

    @property
    def output(self) -> Optional[NoopArtifact]:
        if not self.outputs:
            return None
        return next(iter(self.outputs.values()))

    def as_dict(self) -> Dict[str, NoopArtifact]:
        return dict(self.outputs)


class NoopCoupler(CouplerMapMixin[Any, DeclaredOutput]):
    """
    Coupler-compatible helper for noop mode.
    """

    def __init__(self) -> None:
        self._artifacts: Dict[str, Any] = {}
        self._declared_outputs: Dict[str, DeclaredOutput] = {}
        self._warn_undefined = False
        self._undefined_keys: set[str] = set()
        self._output_descriptions: Dict[str, str] = {}

    def _validate_artifact_key(self, key: str) -> None:
        validate_artifact_key(key)

    def _create_declared_output(self) -> DeclaredOutput:
        return DeclaredOutput()

    def _collect_validate_key(self) -> None:
        return None

    def set(self, key: str, artifact: Any) -> Any:
        return self._store_artifact(key, artifact)

    def set_from_artifact(self, key: str, value: Any) -> Any:
        """
        Set an artifact, accepting both Artifact objects and artifact-like values.

        This method is useful when integrating with optional dependencies where you may
        receive either real Artifacts or artifact-like objects with .path/.container_uri properties.

        All forms are stored in the coupler and can be retrieved with get() or require().
        """
        return self._store_artifact(key, value, validate_key=False)

    def keys(self) -> Sequence[str]:
        return list(self._artifacts.keys())

    def items(self) -> Sequence[tuple[str, Any]]:
        return list(self._artifacts.items())

    def values(self) -> Sequence[Any]:
        return list(self._artifacts.values())

    def view(self, namespace: str) -> CouplerView:
        """
        Return a namespace-scoped coupler view.

        Noop mode uses the same namespacing behavior as real couplers so
        workflow code can remain identical across enabled/disabled tracking.
        """
        return CouplerView(self, namespace)

    def __contains__(self, key: object) -> bool:
        return key in self._artifacts

    def __getitem__(self, key: str) -> Any:
        return self.require(key)

    def __setitem__(self, key: str, artifact: Any) -> None:
        self.set(key, artifact)

    def path(self, key: str, *, required: bool = True) -> Optional[Path]:
        artifact = self.require(key) if required else self.get(key)
        if artifact is None:
            return None
        if hasattr(artifact, "get_path"):
            return Path(artifact.get_path())
        if hasattr(artifact, "path"):
            return Path(artifact.path)
        if hasattr(artifact, "container_uri"):
            return Path(artifact.container_uri)
        return None


class NoopRunContext:
    """
    Minimal run context for noop mode that returns artifact placeholders.
    """

    def __init__(self) -> None:
        self._artifacts: Dict[str, NoopArtifact] = {}

    def log_artifact(
        self,
        path: Any,
        key: Optional[str] = None,
        content_hash: Optional[str] = None,
        force_hash_override: bool = False,
        validate_content_hash: bool = False,
        reuse_if_unchanged: bool = False,
        reuse_scope: str = "same_uri",
        facet: Optional[Any] = None,
        facet_schema_version: Optional[Union[str, int]] = None,
        facet_index: bool = False,
        **meta: Any,
    ) -> NoopArtifact:
        _ = content_hash
        _ = force_hash_override
        _ = validate_content_hash
        _ = reuse_if_unchanged
        _ = reuse_scope
        _ = facet
        _ = facet_schema_version
        _ = facet_index
        if key is None:
            if isinstance(path, NoopArtifact):
                key = path.key
            else:
                key = Path(path).stem if path is not None else "artifact"
        artifact = _build_noop_artifact(path, key=key, meta=meta)
        self._artifacts[key] = artifact
        return artifact

    def log_input(
        self, path: Any, key: Optional[str] = None, **meta: Any
    ) -> NoopArtifact:
        return self.log_artifact(path, key=key, **meta)

    def log_output(
        self, path: Any, key: Optional[str] = None, **meta: Any
    ) -> NoopArtifact:
        return self.log_artifact(path, key=key, **meta)

    def log_artifacts(
        self,
        outputs: Mapping[str, Any],
        facets_by_key: Optional[Mapping[str, Any]] = None,
        facet_schema_versions_by_key: Optional[Mapping[str, Union[str, int]]] = None,
        facet_index: bool = False,
        **meta: Any,
    ) -> Dict[str, NoopArtifact]:
        _ = facet_index
        artifacts: Dict[str, NoopArtifact] = {}
        for key, value in outputs.items():
            artifacts[key] = self.log_artifact(
                value,
                key=key,
                facet=facets_by_key.get(key) if facets_by_key else None,
                facet_schema_version=(
                    facet_schema_versions_by_key.get(key)
                    if facet_schema_versions_by_key
                    else None
                ),
                **meta,
            )
        return artifacts


class NoopScenarioContext:
    """
    Scenario-like context that executes without provenance tracking.
    """

    def __init__(self, name: str, **kwargs: Any) -> None:
        self.name = name
        self.kwargs = kwargs
        self.coupler = NoopCoupler()
        self._inputs: Dict[str, NoopArtifact] = {}
        self._output_base_dir = Path(kwargs.get("output_base_dir") or Path.cwd())

    @property
    def run_id(self) -> str:
        return self.name

    @property
    def inputs(self) -> Mapping[str, NoopArtifact]:
        return dict(self._inputs)

    def add_input(self, path: Any, key: str, **kwargs: Any) -> NoopArtifact:
        artifact = _build_noop_artifact(path, key=key, meta=kwargs)
        self._inputs[key] = artifact
        return artifact

    def declare_outputs(
        self,
        *names: str,
        required: bool | Mapping[str, bool] = False,
        warn_undefined: bool = False,
        description: Optional[Mapping[str, str]] = None,
    ) -> None:
        self.coupler.declare_outputs(
            *names,
            required=required,
            warn_undefined=warn_undefined,
            description=description,
        )

    def require_outputs(
        self,
        *names: str,
        required: bool | Mapping[str, bool] = True,
        warn_undefined: bool = False,
        description: Optional[Mapping[str, str]] = None,
    ) -> None:
        self.coupler.require_outputs(
            *names,
            required=required,
            warn_undefined=warn_undefined,
            description=description,
        )

    def collect_by_keys(
        self, artifacts: Mapping[str, Any], *keys: str, prefix: str = ""
    ) -> Dict[str, Any]:
        return self.coupler.collect_by_keys(artifacts, *keys, prefix=prefix)

    def run(
        self,
        fn: Optional[Any] = None,
        name: Optional[str] = None,
        *,
        run_id: Optional[str] = None,
        outputs: Optional[Sequence[str]] = None,
        output_paths: Optional[Mapping[str, Any]] = None,
        execution_options: Optional[ExecutionOptions] = None,
        runtime_kwargs: Optional[Dict[str, Any]] = None,
        inject_context: bool | str | None = None,
        **kwargs: Any,
    ) -> NoopRunResult:
        resolved_runtime_kwargs_mapping = (
            runtime_kwargs
            if runtime_kwargs is not None
            else (
                execution_options.runtime_kwargs
                if execution_options is not None
                else None
            )
        )
        resolved_runtime_kwargs = (
            dict(resolved_runtime_kwargs_mapping)
            if resolved_runtime_kwargs_mapping is not None
            else None
        )
        resolved_inject_context_value = (
            inject_context
            if inject_context is not None
            else (
                execution_options.inject_context
                if execution_options is not None
                else False
            )
        )
        resolved_inject_context: bool | str = (
            resolved_inject_context_value
            if resolved_inject_context_value is not None
            else False
        )
        return _run_noop_step(
            fn=fn,
            name=name,
            run_id=run_id,
            outputs=outputs,
            output_paths=output_paths,
            runtime_kwargs=resolved_runtime_kwargs,
            inject_context=resolved_inject_context,
            default_name=self.name,
            on_outputs=self.coupler.update,
            output_base_dir=self._output_base_dir,
        )

    @contextmanager
    def trace(self, name: str, **kwargs: Any) -> Iterator[NoopRunContext]:
        yield NoopRunContext()


class NoopTracker(TrackerLike):
    """
    Tracker-compatible noop implementation with parity-focused validation.
    """

    def __init__(self, *, output_base_dir: Optional[Path] = None) -> None:
        self._warned = False
        self._output_base_dir = output_base_dir or Path.cwd()

    def _warn_disabled(self) -> None:
        if not self._warned:
            logging.warning(
                "[Consist] Provenance tracking disabled; using noop tracker."
            )
            self._warned = True

    def log_output(
        self, path: Any, key: Optional[str] = None, **metadata: Any
    ) -> NoopArtifact:
        self._warn_disabled()
        return NoopRunContext().log_output(path, key=key, **metadata)

    def log_input(
        self, path: Any, key: Optional[str] = None, **metadata: Any
    ) -> NoopArtifact:
        self._warn_disabled()
        return NoopRunContext().log_input(path, key=key, **metadata)

    def log_artifacts(
        self, outputs: Mapping[str, Any], **metadata: Any
    ) -> Dict[str, NoopArtifact]:
        self._warn_disabled()
        return NoopRunContext().log_artifacts(outputs, **metadata)

    @contextmanager
    def scenario(self, name: str, **kwargs: Any) -> Iterator[NoopScenarioContext]:
        self._warn_disabled()
        yield NoopScenarioContext(name, **kwargs)

    def run(
        self,
        fn: Optional[Any] = None,
        name: Optional[str] = None,
        *,
        run_id: Optional[str] = None,
        outputs: Optional[Sequence[str]] = None,
        output_paths: Optional[Mapping[str, Any]] = None,
        execution_options: Optional[ExecutionOptions] = None,
        runtime_kwargs: Optional[Dict[str, Any]] = None,
        inject_context: bool | str | None = None,
        **kwargs: Any,
    ) -> NoopRunResult:
        self._warn_disabled()
        resolved_runtime_kwargs_mapping = (
            runtime_kwargs
            if runtime_kwargs is not None
            else (
                execution_options.runtime_kwargs
                if execution_options is not None
                else None
            )
        )
        resolved_runtime_kwargs = (
            dict(resolved_runtime_kwargs_mapping)
            if resolved_runtime_kwargs_mapping is not None
            else None
        )
        resolved_inject_context_value = (
            inject_context
            if inject_context is not None
            else (
                execution_options.inject_context
                if execution_options is not None
                else False
            )
        )
        resolved_inject_context: bool | str = (
            resolved_inject_context_value
            if resolved_inject_context_value is not None
            else False
        )
        return _run_noop_step(
            fn=fn,
            name=name,
            run_id=run_id,
            outputs=outputs,
            output_paths=output_paths,
            runtime_kwargs=resolved_runtime_kwargs,
            inject_context=resolved_inject_context,
            output_base_dir=self._output_base_dir,
        )


def _build_noop_artifact(
    value: Any, *, key: str, meta: Optional[Dict[str, Any]] = None
) -> NoopArtifact:
    validate_artifact_key(key)
    if isinstance(value, NoopArtifact):
        return value
    if hasattr(value, "path"):
        try:
            path = Path(value.path)
            return NoopArtifact(
                key=key,
                path=path,
                container_uri=str(path),
                meta=dict(meta or {}),
            )
        except Exception:
            pass
    path = Path(value) if value is not None else Path(key)
    return NoopArtifact(
        key=key,
        path=path,
        container_uri=str(path),
        meta=dict(meta or {}),
    )


def _run_noop_step(
    *,
    fn: Optional[Any],
    name: Optional[str],
    run_id: Optional[str],
    outputs: Optional[Sequence[str]],
    output_paths: Optional[Mapping[str, Any]],
    runtime_kwargs: Optional[Dict[str, Any]],
    inject_context: bool | str,
    default_name: Optional[str] = None,
    on_outputs: Optional[Any] = None,
    output_base_dir: Optional[Path] = None,
) -> NoopRunResult:
    if fn is None and name is None:
        raise ValueError("Noop run requires name when fn is None.")
    resolved_name = name or getattr(fn, "__name__", "run")
    base = default_name or resolved_name
    resolved_run_id = run_id or f"{base}_{resolved_name}_{uuid.uuid4().hex[:8]}"

    call_kwargs: Dict[str, Any] = dict(runtime_kwargs or {})
    required_runtime = getattr(fn, "__consist_runtime_required__", ()) if fn else ()
    if required_runtime:
        missing = [name for name in required_runtime if name not in call_kwargs]
        if missing:
            missing_list = ", ".join(sorted(missing))
            raise ValueError(
                f"Missing runtime_kwargs for {resolved_name!r}: {missing_list}. "
                "Provide them via execution_options=ExecutionOptions(runtime_kwargs={...}) "
                "or runtime_kwargs={...}, or remove "
                "@consist.require_runtime_kwargs."
            )

    if fn is not None:
        sig = inspect.signature(fn)
        params = sig.parameters
        has_var_kw = any(
            p.kind == inspect.Parameter.VAR_KEYWORD for p in params.values()
        )
        if inject_context:
            ctx_name = (
                inject_context if isinstance(inject_context, str) else "_consist_ctx"
            )
            if ctx_name in params or has_var_kw:
                call_kwargs[ctx_name] = NoopRunContext()
            else:
                raise ValueError(
                    f"inject_context requested '{ctx_name}', but fn does not accept it."
                )
        try:
            sig.bind_partial(**call_kwargs)
        except TypeError as exc:
            raise TypeError(
                f"Noop run could not bind arguments for {resolved_name!r}: {exc}"
            ) from exc

    result = None
    if fn is not None:
        result = fn(**call_kwargs)

    outputs_map: Dict[str, NoopArtifact] = {}
    if output_paths:
        for key, ref in output_paths.items():
            outputs_map[str(key)] = _build_noop_artifact(ref, key=str(key))

    if outputs and result is not None:
        if isinstance(result, Mapping):
            for key, value in result.items():
                outputs_map[str(key)] = _build_noop_artifact(value, key=str(key))
        elif isinstance(result, (list, tuple)) and len(result) == len(outputs):
            for key, value in zip(outputs, result):
                outputs_map[str(key)] = _build_noop_artifact(value, key=str(key))
        else:
            if len(outputs) == 1:
                outputs_map[str(outputs[0])] = _build_noop_artifact(
                    result, key=str(outputs[0])
                )
    elif outputs is None and output_paths is None and result is not None:
        fn_name = getattr(fn, "__name__", None) if fn is not None else None
        default_key = (
            fn_name
            if isinstance(fn_name, str) and fn_name and fn_name != "<lambda>"
            else resolved_name
        )
        if isinstance(result, (NoopArtifact, Path)):
            outputs_map[default_key] = _build_noop_artifact(result, key=default_key)
        elif isinstance(result, Mapping):
            inferred: Dict[str, NoopArtifact] = {}
            for key, value in result.items():
                if not isinstance(key, str):
                    inferred = {}
                    break
                if not isinstance(value, (NoopArtifact, Path)):
                    inferred = {}
                    break
                inferred[key] = _build_noop_artifact(value, key=key)
            outputs_map.update(inferred)

    if outputs_map and on_outputs is not None:
        on_outputs(outputs_map)

    return NoopRunResult(
        run=Run(
            id=resolved_run_id,
            model_name=resolved_name,
            config_hash=None,
            git_hash=None,
            status="completed",
        ),
        outputs=outputs_map,
        cache_hit=False,
    )


def _resolve_noop_output_path(ref: Any, base_dir: Path) -> Path:
    if isinstance(ref, NoopArtifact):
        return ref.path
    ref_path = getattr(ref, "path", None)
    if ref_path is not None:
        return Path(ref_path)
    ref_str = str(ref)
    if isinstance(ref, str) and "://" in ref_str:
        return Path(ref_str)
    candidate = Path(ref_str)
    if not candidate.is_absolute():
        return base_dir / candidate
    return candidate
