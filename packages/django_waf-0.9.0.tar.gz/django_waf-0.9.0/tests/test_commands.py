"""Tests for icv-waf management commands.

Each command is tested for:
  - ``--dry-run`` mode (should report without side effects)
  - Normal execution (should call the underlying service)
  - Stdout output
  - Argument handling / edge cases
"""

from __future__ import annotations

from io import StringIO
from unittest.mock import MagicMock, patch

import pytest
from django.core.management import call_command
from django.core.management.base import CommandError
from django.utils import timezone

from icv_waf.testing.factories import BlockRuleFactory, RequestLogFactory

# ---------------------------------------------------------------------------
# icv_waf_generate_blocklist
# ---------------------------------------------------------------------------


class TestGenerateBlocklistCommand:
    """Tests for the ``icv_waf_generate_blocklist`` management command."""

    @pytest.mark.django_db
    def test_dry_run_does_not_write_file(self, tmp_path):
        """Dry-run prints the blocklist to stdout and does not create a permanent file."""
        fake_conf = tmp_path / "blocklist.conf"
        fake_conf.write_text("# placeholder\n")

        with patch(
            "icv_waf.services.blocklist_generator.generate_nginx_blocklist",
            return_value=3,
        ) as mock_generate:
            out = StringIO()
            call_command("icv_waf_generate_blocklist", "--dry-run", stdout=out)

        # The service IS called (to populate the temp file), but the permanent
        # output path is not touched.
        mock_generate.assert_called_once()
        output = out.getvalue()
        assert "dry-run" in output
        assert "3 rule(s)" in output

    @pytest.mark.django_db
    def test_normal_run_calls_service_and_reloads_nginx(self, tmp_path):
        """Normal run calls generate_nginx_blocklist and reload_nginx."""
        with (
            patch(
                "icv_waf.services.blocklist_generator.generate_nginx_blocklist",
                return_value=5,
            ) as mock_generate,
            patch(
                "icv_waf.services.blocklist_generator.reload_nginx",
                return_value=True,
            ) as mock_reload,
        ):
            out = StringIO()
            call_command("icv_waf_generate_blocklist", stdout=out)

        mock_generate.assert_called_once_with(output_path=None)
        mock_reload.assert_called_once()
        output = out.getvalue()
        assert "5 rule(s)" in output
        assert "nginx reloaded" in output

    @pytest.mark.django_db
    def test_normal_run_with_output_path(self, tmp_path):
        """--output-path is forwarded to the service."""
        custom_path = str(tmp_path / "custom.conf")

        with (
            patch(
                "icv_waf.services.blocklist_generator.generate_nginx_blocklist",
                return_value=1,
            ) as mock_generate,
            patch(
                "icv_waf.services.blocklist_generator.reload_nginx",
                return_value=True,
            ),
        ):
            call_command("icv_waf_generate_blocklist", f"--output-path={custom_path}")

        mock_generate.assert_called_once_with(output_path=custom_path)

    @pytest.mark.django_db
    def test_nginx_reload_failure_shows_warning(self):
        """When nginx reload fails the command emits a warning, not an error."""
        with (
            patch(
                "icv_waf.services.blocklist_generator.generate_nginx_blocklist",
                return_value=2,
            ),
            patch(
                "icv_waf.services.blocklist_generator.reload_nginx",
                return_value=False,
            ),
        ):
            out = StringIO()
            call_command("icv_waf_generate_blocklist", stdout=out)

        output = out.getvalue()
        assert "reload nginx manually" in output

    @pytest.mark.django_db
    def test_service_exception_raises_command_error(self):
        """A service exception is converted to CommandError."""
        with (
            patch(
                "icv_waf.services.blocklist_generator.generate_nginx_blocklist",
                side_effect=RuntimeError("disk full"),
            ),
            pytest.raises(CommandError, match="Failed to generate blocklist"),
        ):
            call_command("icv_waf_generate_blocklist")


# ---------------------------------------------------------------------------
# icv_waf_detect_anomalies
# ---------------------------------------------------------------------------


class TestDetectAnomaliesCommand:
    """Tests for the ``icv_waf_detect_anomalies`` management command."""

    @pytest.mark.django_db
    def test_dry_run_reports_without_creating_rules(self):
        """Dry-run emits the dry-run notice and displays detector results."""
        results = {"burst_detector": [MagicMock(), MagicMock()], "ua_rotation": []}

        with patch(
            "icv_waf.services.anomaly_detector.run_all_detectors",
            return_value=results,
        ) as mock_detect:
            out = StringIO()
            call_command("icv_waf_detect_anomalies", "--dry-run", stdout=out)

        mock_detect.assert_called_once_with()
        output = out.getvalue()
        assert "dry-run" in output
        assert "would create" in output
        assert "2 rule(s)" in output

    @pytest.mark.django_db
    def test_normal_run_calls_service(self):
        """Normal run calls run_all_detectors and reports created rule counts."""
        results = {"burst_detector": [MagicMock()], "ua_rotation": [MagicMock(), MagicMock()]}

        with patch(
            "icv_waf.services.anomaly_detector.run_all_detectors",
            return_value=results,
        ) as mock_detect:
            out = StringIO()
            call_command("icv_waf_detect_anomalies", stdout=out)

        mock_detect.assert_called_once_with()
        output = out.getvalue()
        assert "created" in output
        assert "3 anomaly rule(s)" in output

    @pytest.mark.django_db
    def test_window_minutes_forwarded_to_service(self):
        """--window-minutes is passed through to run_all_detectors."""
        with patch(
            "icv_waf.services.anomaly_detector.run_all_detectors",
            return_value={},
        ) as mock_detect:
            call_command("icv_waf_detect_anomalies", "--window-minutes=10")

        mock_detect.assert_called_once_with(window_minutes=10)

    @pytest.mark.django_db
    def test_no_anomalies_detected_message(self):
        """When no anomalies are detected the success message is shown."""
        with patch(
            "icv_waf.services.anomaly_detector.run_all_detectors",
            return_value={"burst_detector": [], "ua_rotation": []},
        ):
            out = StringIO()
            call_command("icv_waf_detect_anomalies", stdout=out)

        assert "No anomalies detected" in out.getvalue()

    @pytest.mark.django_db
    def test_service_exception_raises_command_error(self):
        """A service exception is converted to CommandError."""
        with (
            patch(
                "icv_waf.services.anomaly_detector.run_all_detectors",
                side_effect=ValueError("bad window"),
            ),
            pytest.raises(CommandError, match="Anomaly detection failed"),
        ):
            call_command("icv_waf_detect_anomalies")

    @pytest.mark.django_db
    def test_dry_run_with_window_minutes(self):
        """Dry-run correctly forwards --window-minutes."""
        with patch(
            "icv_waf.services.anomaly_detector.run_all_detectors",
            return_value={"ua_rotation": [MagicMock()]},
        ) as mock_detect:
            out = StringIO()
            call_command("icv_waf_detect_anomalies", "--dry-run", "--window-minutes=20", stdout=out)

        mock_detect.assert_called_once_with(window_minutes=20)
        assert "dry-run" in out.getvalue()


# ---------------------------------------------------------------------------
# icv_waf_prune_logs
# ---------------------------------------------------------------------------


class TestPruneLogsCommand:
    """Tests for the ``icv_waf_prune_logs`` management command."""

    @pytest.mark.django_db
    def test_dry_run_counts_without_deleting(self):
        """Dry-run reports stale record count and does not delete anything."""
        cutoff = timezone.now() - timezone.timedelta(days=31)
        # Create 3 old logs and 1 recent log.
        for _ in range(3):
            RequestLogFactory(timestamp=cutoff - timezone.timedelta(hours=1))
        RequestLogFactory()  # recent — should not be counted

        out = StringIO()
        call_command("icv_waf_prune_logs", "--dry-run", "--days=30", stdout=out)

        from icv_waf.models import RequestLog

        # Nothing should have been deleted.
        assert RequestLog.objects.count() == 4
        output = out.getvalue()
        assert "dry-run" in output
        assert "3 log record(s)" in output

    @pytest.mark.django_db
    def test_normal_run_deletes_old_records(self):
        """Normal run deletes records older than the retention window."""
        cutoff = timezone.now() - timezone.timedelta(days=31)
        for _ in range(2):
            RequestLogFactory(timestamp=cutoff - timezone.timedelta(hours=1))
        RequestLogFactory()  # recent — must survive

        from icv_waf.models import RequestLog

        out = StringIO()
        call_command("icv_waf_prune_logs", "--days=30", stdout=out)

        assert RequestLog.objects.count() == 1
        output = out.getvalue()
        assert "Deleted 2 log record(s)" in output

    @pytest.mark.django_db
    def test_days_argument_overrides_default(self):
        """--days overrides the configured retention period."""
        cutoff = timezone.now() - timezone.timedelta(days=8)
        RequestLogFactory(timestamp=cutoff - timezone.timedelta(hours=1))

        from icv_waf.models import RequestLog

        call_command("icv_waf_prune_logs", "--days=7")
        assert RequestLog.objects.count() == 0

    @pytest.mark.django_db
    def test_zero_days_raises_command_error(self):
        """--days=0 is rejected with a CommandError."""
        with pytest.raises(CommandError, match="positive integer"):
            call_command("icv_waf_prune_logs", "--days=0")

    @pytest.mark.django_db
    def test_no_old_records_reports_zero_deleted(self):
        """When there are no stale records the command reports zero deletions."""
        RequestLogFactory()  # recent only

        out = StringIO()
        call_command("icv_waf_prune_logs", "--days=30", stdout=out)

        assert "Deleted 0 log record(s)" in out.getvalue()

    @pytest.mark.django_db
    def test_default_retention_uses_conf_value(self):
        """When --days is omitted the command reads ICV_WAF_LOG_RETENTION_DAYS from conf."""
        from icv_waf import conf

        default_days = conf.ICV_WAF_LOG_RETENTION_DAYS
        cutoff = timezone.now() - timezone.timedelta(days=default_days + 1)
        RequestLogFactory(timestamp=cutoff)

        from icv_waf.models import RequestLog

        call_command("icv_waf_prune_logs")
        assert RequestLog.objects.count() == 0


# ---------------------------------------------------------------------------
# icv_waf_sync_feed
# ---------------------------------------------------------------------------


class TestSyncFeedCommand:
    """Tests for the ``icv_waf_sync_feed`` management command."""

    @pytest.mark.django_db
    def test_skips_when_feed_disabled_and_no_url(self):
        """Command exits early with a warning when feed is disabled and no URL given."""
        with (
            patch("icv_waf.conf.ICV_WAF_FEED_ENABLED", False),
            patch("icv_waf.services.threat_feed.sync_feed") as mock_sync,
        ):
            out = StringIO()
            call_command("icv_waf_sync_feed", stdout=out)

        mock_sync.assert_not_called()
        assert "Skipping sync" in out.getvalue()

    @pytest.mark.django_db
    def test_dry_run_emits_notice(self):
        """Dry-run prints the notice before calling the service."""
        summary = {"created": 0, "updated": 0, "expired": 0, "skipped": 0}
        with (
            patch("icv_waf.conf.ICV_WAF_FEED_ENABLED", True),
            patch("icv_waf.services.threat_feed.sync_feed", return_value=summary),
        ):
            out = StringIO()
            call_command("icv_waf_sync_feed", "--dry-run", stdout=out)

        assert "dry-run" in out.getvalue()

    @pytest.mark.django_db
    def test_normal_run_calls_sync_feed(self):
        """Normal run calls sync_feed and reports the summary."""
        summary = {"created": 4, "updated": 1, "expired": 2, "skipped": 3}
        with (
            patch("icv_waf.conf.ICV_WAF_FEED_ENABLED", True),
            patch("icv_waf.services.threat_feed.sync_feed", return_value=summary) as mock_sync,
        ):
            out = StringIO()
            call_command("icv_waf_sync_feed", stdout=out)

        mock_sync.assert_called_once_with(feed_url=None, min_confidence=None)
        output = out.getvalue()
        assert "4 created" in output
        assert "1 updated" in output
        assert "2 expired" in output
        assert "3 skipped" in output

    @pytest.mark.django_db
    def test_feed_url_override_bypasses_disabled_check(self):
        """Passing --feed-url overrides the feed-disabled guard and calls the service."""
        summary = {"created": 1, "updated": 0, "expired": 0, "skipped": 0}
        # Feed disabled at conf level — but --feed-url should bypass the guard.
        with (
            patch("icv_waf.conf.ICV_WAF_FEED_ENABLED", False),
            patch("icv_waf.services.threat_feed.sync_feed", return_value=summary) as mock_sync,
        ):
            out = StringIO()
            call_command(
                "icv_waf_sync_feed",
                "--feed-url=https://example.com/feed.json",
                stdout=out,
            )

        mock_sync.assert_called_once_with(
            feed_url="https://example.com/feed.json",
            min_confidence=None,
        )
        assert "Feed sync complete" in out.getvalue()

    @pytest.mark.django_db
    def test_min_confidence_forwarded_to_service(self):
        """--min-confidence is forwarded to sync_feed."""
        summary = {"created": 0, "updated": 0, "expired": 0, "skipped": 10}
        with (
            patch("icv_waf.conf.ICV_WAF_FEED_ENABLED", True),
            patch("icv_waf.services.threat_feed.sync_feed", return_value=summary) as mock_sync,
        ):
            call_command("icv_waf_sync_feed", "--min-confidence=0.9")

        mock_sync.assert_called_once_with(feed_url=None, min_confidence=0.9)

    @pytest.mark.django_db
    def test_service_exception_raises_command_error(self):
        """A service exception is converted to CommandError."""
        with (
            patch("icv_waf.conf.ICV_WAF_FEED_ENABLED", True),
            patch(
                "icv_waf.services.threat_feed.sync_feed",
                side_effect=ConnectionError("timeout"),
            ),
            pytest.raises(CommandError, match="Feed sync failed"),
        ):
            call_command("icv_waf_sync_feed")

    @pytest.mark.django_db
    def test_partial_summary_keys_default_to_zero(self):
        """A summary dict with missing keys defaults missing counts to zero without error."""
        with (
            patch("icv_waf.conf.ICV_WAF_FEED_ENABLED", True),
            patch(
                "icv_waf.services.threat_feed.sync_feed",
                return_value={"created": 2},
            ),
        ):
            out = StringIO()
            call_command("icv_waf_sync_feed", stdout=out)

        output = out.getvalue()
        assert "2 created" in output
        assert "0 updated" in output
        assert "0 expired" in output
        assert "0 skipped" in output


# ---------------------------------------------------------------------------
# icv_waf_block
# ---------------------------------------------------------------------------


class TestBlockCommand:
    """Tests for the ``icv_waf_block`` management command."""

    @pytest.mark.django_db
    def test_block_creates_ip_rule(self):
        """Blocking a plain IP creates a BlockRule with rule_type=ip, match_type=exact."""
        from icv_waf.enums import RuleSource, RuleType
        from icv_waf.models import BlockRule

        out = StringIO()
        call_command("icv_waf_block", "203.0.113.42", stdout=out)

        rule = BlockRule.objects.get(pattern="203.0.113.42")
        assert rule.rule_type == RuleType.IP
        assert rule.match_type == "exact"
        assert rule.source == RuleSource.ADMIN
        assert rule.action == "block"
        assert rule.is_active is True
        assert rule.expires_at is None
        output = out.getvalue()
        assert "Blocked 203.0.113.42" in output
        assert "Permanent" in output

    @pytest.mark.django_db
    def test_block_creates_cidr_rule(self):
        """Blocking a CIDR range creates a rule with rule_type=cidr, match_type=cidr."""
        from icv_waf.enums import RuleType
        from icv_waf.models import BlockRule

        call_command("icv_waf_block", "10.0.0.0/24")

        rule = BlockRule.objects.get(pattern="10.0.0.0/24")
        assert rule.rule_type == RuleType.CIDR
        assert rule.match_type == "cidr"

    @pytest.mark.django_db
    def test_block_with_ttl_sets_expires_at(self):
        """--ttl converts hours into an absolute expires_at timestamp."""
        from icv_waf.models import BlockRule

        out = StringIO()
        call_command("icv_waf_block", "203.0.113.99", "--ttl", "24", stdout=out)

        rule = BlockRule.objects.get(pattern="203.0.113.99")
        assert rule.expires_at is not None
        delta = rule.expires_at - timezone.now()
        # Should be ~24h from now (allow 60s slack for test timing)
        assert 23 * 3600 < delta.total_seconds() < 25 * 3600
        assert "Expires:" in out.getvalue()

    @pytest.mark.django_db
    def test_block_with_reason_populates_notes(self):
        """--reason is stored in the rule's notes field and echoed to stdout."""
        from icv_waf.models import BlockRule

        out = StringIO()
        call_command(
            "icv_waf_block",
            "203.0.113.10",
            "--reason",
            "scanner from threat feed",
            stdout=out,
        )

        rule = BlockRule.objects.get(pattern="203.0.113.10")
        assert rule.notes == "scanner from threat feed"
        assert "Reason: scanner from threat feed" in out.getvalue()

    @pytest.mark.django_db
    def test_block_with_challenge_action(self):
        """--action=challenge produces a challenge rule rather than a block."""
        from icv_waf.models import BlockRule

        out = StringIO()
        call_command("icv_waf_block", "203.0.113.11", "--action", "challenge", stdout=out)

        rule = BlockRule.objects.get(pattern="203.0.113.11")
        assert rule.action == "challenge"
        assert "(challenge)" in out.getvalue()

    @pytest.mark.django_db
    def test_block_idempotent_updates_existing_rule(self):
        """Blocking the same pattern twice updates the existing rule (update_or_create)."""
        from icv_waf.models import BlockRule

        call_command("icv_waf_block", "203.0.113.50", "--reason", "first")
        out = StringIO()
        call_command("icv_waf_block", "203.0.113.50", "--reason", "second", stdout=out)

        # Only one rule exists
        rules = BlockRule.objects.filter(pattern="203.0.113.50")
        assert rules.count() == 1
        assert rules.first().notes == "second"
        assert "Updated existing rule" in out.getvalue()

    @pytest.mark.django_db
    def test_block_db_failure_raises_command_error(self):
        """A BlockRule.update_or_create exception is converted to CommandError."""
        with (
            patch(
                "icv_waf.models.BlockRule.objects.update_or_create",
                side_effect=RuntimeError("db error"),
            ),
            pytest.raises(CommandError, match="Failed to create rule"),
        ):
            call_command("icv_waf_block", "203.0.113.200")


# ---------------------------------------------------------------------------
# icv_waf_unblock
# ---------------------------------------------------------------------------


class TestUnblockCommand:
    """Tests for the ``icv_waf_unblock`` management command."""

    @pytest.mark.django_db
    def test_unblock_deactivates_matching_rules(self):
        """Without --delete, matching rules are deactivated (is_active=False)."""
        from icv_waf.models import BlockRule

        rule = BlockRuleFactory(pattern="198.51.100.1", is_active=True)

        out = StringIO()
        call_command("icv_waf_unblock", "198.51.100.1", stdout=out)

        rule.refresh_from_db()
        assert rule.is_active is False
        # Row still exists — deactivated, not deleted
        assert BlockRule.objects.filter(pk=rule.pk).exists()
        assert "Deactivated 1 rule" in out.getvalue()

    @pytest.mark.django_db
    def test_unblock_with_delete_removes_rules(self):
        """--delete removes matching rules from the database entirely."""
        from icv_waf.models import BlockRule

        rule = BlockRuleFactory(pattern="198.51.100.2", is_active=True)

        out = StringIO()
        call_command("icv_waf_unblock", "198.51.100.2", "--delete", stdout=out)

        assert not BlockRule.objects.filter(pk=rule.pk).exists()
        assert "Deleted 1 rule" in out.getvalue()

    @pytest.mark.django_db
    def test_unblock_no_matching_rules_reports_nothing_to_do(self):
        """When no active rule matches, the command reports and exits cleanly."""
        out = StringIO()
        call_command("icv_waf_unblock", "198.51.100.99", stdout=out)

        assert "No active rules found" in out.getvalue()

    @pytest.mark.django_db
    def test_unblock_ignores_already_inactive_rules(self):
        """Rules that are already inactive are not counted or touched."""
        from icv_waf.models import BlockRule

        BlockRuleFactory(pattern="198.51.100.3", is_active=False)

        out = StringIO()
        call_command("icv_waf_unblock", "198.51.100.3", stdout=out)

        # The inactive rule survives untouched
        assert BlockRule.objects.filter(pattern="198.51.100.3", is_active=False).exists()
        assert "No active rules found" in out.getvalue()

    @pytest.mark.django_db
    def test_unblock_deactivates_multiple_matching_rules(self):
        """All active rules matching the pattern are deactivated in a single call."""
        BlockRuleFactory(pattern="198.51.100.4", is_active=True, action="block")
        BlockRuleFactory(pattern="198.51.100.4", is_active=True, action="challenge")

        out = StringIO()
        call_command("icv_waf_unblock", "198.51.100.4", stdout=out)

        assert "Deactivated 2 rule" in out.getvalue()
