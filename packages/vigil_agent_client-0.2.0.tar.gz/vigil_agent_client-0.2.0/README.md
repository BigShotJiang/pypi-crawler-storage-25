# vigil-client

Python client for [Vigil Cloud](https://vigil-agent.com) — cognitive infrastructure for AI agents.

## Install

```bash
pip install vigil-agent-client
```

## Quick Start

```python
from vigil_client import Vigil

v = Vigil(api_key="vgl_...")

# Emit a signal
v.signal("deploy complete", agent="my-bot")

# Boot with compiled awareness
context = v.boot()
print(context["awareness"])

# End session with handoff
v.handoff(
    agent="my-bot",
    summary="Deployed auth v2",
    files=["auth.py", "middleware.py"],
    next_steps=["Monitor error rates", "Update docs"],
)
```

## Environment Variables

```bash
export VIGIL_API_KEY=vgl_...
export VIGIL_API_URL=https://app.vigil-agent.com  # optional, this is the default
```

```python
# Reads from env automatically
v = Vigil()
```

## API Reference

| Method | Description |
|--------|-------------|
| `v.signal(content, agent, signal_type)` | Emit a signal |
| `v.boot()` | Boot with compiled awareness |
| `v.compile()` | Force awareness compilation |
| `v.status()` | Get current awareness |
| `v.signals(hours, limit, agent)` | Read recent signals |
| `v.handoff(agent, summary, files, decisions, next_steps)` | End session |
| `v.resume(agent)` | Resume from last handoff |
| `v.chain(limit)` | Get handoff briefing |
| `v.focus_add(description, priority)` | Add focus item |
| `v.focus_list()` | List active focus |
| `v.know(key, value, category)` | Store knowledge |
| `v.recall(query)` | Search knowledge |
| `v.frames()` | List frames |
| `v.triggers()` | List triggers |
| `v.usage()` | Get usage and limits |
| `v.agents()` | List known agents |
| `v.mcp_health(server)` | MCP server health stats |
| `v.mcp_errors(server, limit)` | Recent MCP tool errors |
| `v.mcp_latency(server, hours)` | Latency percentiles (p50/p95/p99) |

## Zero Dependencies

Uses only Python stdlib (`urllib`, `json`). No `requests`, no `httpx` — just works.

## License

MIT
