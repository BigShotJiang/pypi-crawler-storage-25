# mmh-cli

MakeMyHouse developer CLI — a `create-next-app`-style entrypoint that wraps the bootstrap script, pre-commit checks, and doc-regeneration into a single installable command.

## Install
```bash
pip install -e /app/scripts/mmh_cli       # editable, dev mode
# or
pip install /app/scripts/mmh_cli           # regular install
```

## Commands
| Command          | What it does                                                          |
|------------------|------------------------------------------------------------------------|
| `mmh init`       | Scaffold a fresh repo via `docs/bootstrap.sh` (flags: `--target`, `--install`, `--docker`, `--skip-prereq`) |
| `mmh check`      | Pre-commit sweep — shellcheck + ruff + `pytest tests/unit/`            |
| `mmh docs`       | Regenerate `docs/MakeMyHouse_Flow_Diagrams_v5.13.0.docx`               |
| `mmh health`     | GET `/api/health` (`--url http://host:8001`)                           |
| `mmh version`    | Print CLI version + repo root                                          |

## Examples
```bash
# Bootstrap a new repo into ./mmh, install deps, bring up mongo+redis
mmh init --target ./mmh --install --docker

# Run the same CI sweep locally before pushing
mmh check

# Regenerate the 18-flow .docx after a release
mmh docs

# Smoke-test a deployment
mmh health --url https://api.yourdomain.com
```

## Vendor neutrality
Zero runtime dependencies — pure Python stdlib. The CLI auto-discovers the repo root
by walking up from the install location until it finds `docs/bootstrap.sh`, or honours
`MMH_REPO_ROOT` if set.
