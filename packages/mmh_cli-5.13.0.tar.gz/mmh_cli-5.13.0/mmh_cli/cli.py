"""mmh — MakeMyHouse developer CLI (vendor-neutral).

Subcommands:
  mmh init [--target ./dir] [--install] [--docker]   Scaffold a fresh repo via bootstrap.sh
  mmh check                                          Run shellcheck + ruff + pytest unit suite
  mmh docs                                           Regenerate the flow-diagram .docx
  mmh health [--url URL]                             Curl the /api/health endpoint
  mmh deploy [--target docker|railway|vercel]        Deploy the app (Docker compose / Railway / Vercel)
  mmh version                                        Print mmh-cli version

Designed for create-next-app-style onboarding. Zero runtime deps beyond stdlib.
"""
from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path

VERSION = "5.13.0"

# Resolve repo root: env override → walk up from cwd looking for /docs/bootstrap.sh
def _repo_root() -> Path:
    env = os.environ.get("MMH_REPO_ROOT")
    if env:
        p = Path(env).resolve()
        if (p / "docs" / "bootstrap.sh").exists():
            return p
    here = Path(__file__).resolve()
    for parent in (here, *here.parents):
        if (parent / "docs" / "bootstrap.sh").exists():
            return parent
    # Fallback: assume we're inside /app
    return Path("/app")


REPO = _repo_root()
BOOTSTRAP = REPO / "docs" / "bootstrap.sh"
DIAGRAMS = REPO / "backend" / "scripts" / "generate_flow_diagrams.py"
BACKEND = REPO / "backend"


def _run(cmd: list[str], **kw) -> int:
    print(f"\033[36m▸\033[0m {' '.join(str(c) for c in cmd)}")
    return subprocess.call(cmd, **kw)


def cmd_init(args) -> int:
    if not BOOTSTRAP.exists():
        print(f"\033[31m✗\033[0m bootstrap.sh not found at {BOOTSTRAP}", file=sys.stderr)
        return 1
    cmd = ["bash", str(BOOTSTRAP), "--target", args.target]
    if args.install:
        cmd.append("--install")
    if args.docker:
        cmd.append("--docker")
    if args.skip_prereq:
        cmd.append("--skip-prereq")
    return _run(cmd)


def cmd_check(_args) -> int:
    """Run the same pre-commit sweep used in CI: shellcheck + ruff + pytest unit."""
    failed: list[str] = []

    if shutil.which("shellcheck") and BOOTSTRAP.exists():
        rc = _run(["shellcheck", "-S", "warning", str(BOOTSTRAP)])
        (failed.append("shellcheck") if rc else None)
    else:
        print("\033[33m⚠\033[0m shellcheck not installed — skipping (apt install shellcheck)")

    if shutil.which("ruff"):
        rc = _run(["ruff", "check", str(BACKEND)])
        (failed.append("ruff") if rc else None)
    else:
        print("\033[33m⚠\033[0m ruff not installed — skipping (pip install ruff)")

    if (BACKEND / "tests" / "unit").exists():
        rc = _run(
            [sys.executable, "-m", "pytest", "-q", "tests/unit/", "--no-header"],
            cwd=str(BACKEND),
        )
        (failed.append("pytest") if rc else None)
    else:
        print("\033[33m⚠\033[0m backend/tests/unit/ not found — skipping pytest")

    if failed:
        print(f"\n\033[31m✗ check failed: {', '.join(failed)}\033[0m")
        return 1
    print("\n\033[32m✓ all checks passed\033[0m")
    return 0


def cmd_docs(_args) -> int:
    if not DIAGRAMS.exists():
        print(f"\033[31m✗\033[0m diagrams script not found at {DIAGRAMS}", file=sys.stderr)
        return 1
    return _run([sys.executable, str(DIAGRAMS)])


def cmd_health(args) -> int:
    import json
    import urllib.error
    import urllib.request

    url = args.url.rstrip("/") + "/api/health"
    try:
        with urllib.request.urlopen(url, timeout=5) as r:
            data = json.loads(r.read())
        print(json.dumps(data, indent=2))
        return 0 if data.get("status") == "healthy" else 1
    except (urllib.error.URLError, TimeoutError, ValueError) as e:
        print(f"\033[31m✗\033[0m {url}: {e}", file=sys.stderr)
        return 1


def cmd_deploy(args) -> int:
    """Deploy the app to a target backend.

    docker  → docker-compose up -d --build (requires docker-compose.yml at repo root)
    railway → railway up --detach (requires `railway login` + RAILWAY_TOKEN env)
    vercel  → vercel --prod (frontend only; requires `vercel login`)
    """
    target = args.target
    if target == "docker":
        compose = REPO / "docker-compose.yml"
        if not compose.exists():
            print(f"\033[31m✗\033[0m {compose} not found", file=sys.stderr)
            return 1
        if not shutil.which("docker"):
            print("\033[31m✗\033[0m docker not installed", file=sys.stderr)
            return 1
        return _run(["docker", "compose", "-f", str(compose), "up", "-d", "--build"])

    if target == "railway":
        if not shutil.which("railway"):
            print("\033[31m✗\033[0m railway CLI not installed (npm i -g @railway/cli)", file=sys.stderr)
            return 1
        if not os.environ.get("RAILWAY_TOKEN"):
            print("\033[33m⚠\033[0m RAILWAY_TOKEN env var not set — interactive login required")
        return _run(["railway", "up", "--detach"])

    if target == "vercel":
        if not shutil.which("vercel"):
            print("\033[31m✗\033[0m vercel CLI not installed (npm i -g vercel)", file=sys.stderr)
            return 1
        return _run(["vercel", "--prod", "--cwd", str(REPO / "frontend")])

    print(f"\033[31m✗\033[0m unknown deploy target: {target}", file=sys.stderr)
    return 1


def cmd_version(_args) -> int:
    print(f"mmh {VERSION}  (repo: {REPO})")
    return 0


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        prog="mmh",
        description=f"MakeMyHouse developer CLI v{VERSION} — vendor-neutral.",
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    p_init = sub.add_parser("init", help="Scaffold a fresh MakeMyHouse repo")
    p_init.add_argument("--target", default="./makemyhouse", help="Target directory")
    p_init.add_argument("--install", action="store_true", help="Run pip + yarn install")
    p_init.add_argument("--docker", action="store_true", help="Bring up mongo + redis")
    p_init.add_argument("--skip-prereq", action="store_true", help="Skip prereq check")
    p_init.set_defaults(fn=cmd_init)

    p_check = sub.add_parser("check", help="Run lint + unit tests (pre-commit sweep)")
    p_check.set_defaults(fn=cmd_check)

    p_docs = sub.add_parser("docs", help="Regenerate flow-diagram .docx")
    p_docs.set_defaults(fn=cmd_docs)

    p_health = sub.add_parser("health", help="GET /api/health")
    p_health.add_argument("--url", default="http://localhost:8001", help="Backend base URL")
    p_health.set_defaults(fn=cmd_health)

    p_deploy = sub.add_parser("deploy", help="Deploy the app")
    p_deploy.add_argument(
        "--target",
        choices=["docker", "railway", "vercel"],
        default="docker",
        help="Deployment target (default: docker)",
    )
    p_deploy.set_defaults(fn=cmd_deploy)

    p_ver = sub.add_parser("version", help="Print mmh-cli version")
    p_ver.set_defaults(fn=cmd_version)

    args = p.parse_args(argv)
    return args.fn(args)


if __name__ == "__main__":
    sys.exit(main())
