"""Allow `python -m mmh_cli`."""
from .cli import main

raise SystemExit(main())
