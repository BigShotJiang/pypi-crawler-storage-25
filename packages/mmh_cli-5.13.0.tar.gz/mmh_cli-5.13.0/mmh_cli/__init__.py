"""mmh — MakeMyHouse developer CLI."""
from .cli import main

__version__ = "5.13.0"
__all__ = ["main"]
