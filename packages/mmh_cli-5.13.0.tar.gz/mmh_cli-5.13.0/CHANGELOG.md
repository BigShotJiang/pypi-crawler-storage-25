# Changelog

All notable changes to `mmh-cli` will be documented in this file.

## [5.13.0] — 2026-02-26
### Added
- `mmh init` — wraps `bootstrap.sh` with `--target`, `--install`, `--docker`, `--skip-prereq` flags.
- `mmh check` — pre-commit sweep (shellcheck + ruff + `pytest tests/unit/`).
- `mmh docs` — regenerates the 18-flow `.docx` via Graphviz + python-docx.
- `mmh health` — GET `/api/health` smoke test.
- `mmh deploy` — Docker / Railway / Vercel deploy targets.
- `mmh version` — version + repo root.

### Notes
- Zero runtime dependencies (pure Python stdlib).
- Auto-discovers repo root by walking up for `docs/bootstrap.sh`; honours `MMH_REPO_ROOT` env override.
- MIT licensed.
