"""
cirqit - A pure NumPy quantum circuit simulator
================================================

Quick Start
-----------
>>> from cirqit import QuantumCircuit
>>> qc = QuantumCircuit(2)
>>> qc.h(0)
>>> qc.cnot(0, 1)
>>> qc.measure_all()
>>> result = qc.run(shots=1024)
>>> print(result)
>>> qc.draw()

Noise Example
-------------
>>> from cirqit import QuantumCircuit
>>> from cirqit.noise import DepolarizingChannel, NoiseModel
>>> nm = NoiseModel()
>>> nm.add_gate_error('h', DepolarizingChannel(0.01))
>>> qc = QuantumCircuit(1)
>>> qc.h(0)
>>> qc.set_noise_model(nm)
>>> qc.measure_all()
>>> print(qc.run(shots=1000))

Algorithms
----------
>>> from cirqit.algorithms import bell_state, qft, grover_diffusion
>>> bell = bell_state('00')
>>> bell.measure_all()
>>> print(bell.run(shots=1024))
"""

__version__ = "0.1.4"
__author__ = "Muhammad"
__license__ = "MIT"

from .circuit import QuantumCircuit
from .statevector import StateVector
from . import noise
from . import algorithms
from . import visualize
from . import gates

__all__ = [
    "QuantumCircuit",
    "StateVector",
    "noise",
    "algorithms",
    "visualize",
    "gates",
]
