"""
cirqit.visualize
================
Qiskit-style professional circuit visualization.
"""
import numpy as np


# ═══════════════════════════════════════════════════════════════
# ASCII TEXT DIAGRAM
# ═══════════════════════════════════════════════════════════════

def draw_ascii(operations, n_qubits, measured_qubits):
    """Qiskit-style unicode ASCII diagram. Returns string."""
    T, M, B = 0, 1, 2

    def gate_cell(label):
        w = max(3, len(label) + 2)
        return ['┌'+'─'*w+'┐', '┤'+label.center(w)+'├', '└'+'─'*w+'┘'], w+2

    def wire_cell(w):
        return [' '*w, '─'*w, ' '*w], w

    def ctrl_cell(w):
        p = w//2
        return [' '*p+'│'+' '*(w-p-1), '─'*p+'■'+'─'*(w-p-1), ' '*p+'│'+' '*(w-p-1)], w

    def vline_cell(w):
        p = w//2
        return [' '*p+'│'+' '*(w-p-1), '─'*p+'┼'+'─'*(w-p-1), ' '*p+'│'+' '*(w-p-1)], w

    def swap_cell(w):
        p = w//2
        return [' '*p+'│'+' '*(w-p-1), '─'*p+'X'+'─'*(w-p-1), ' '*p+'│'+' '*(w-p-1)], w

    def meas_cell():
        return ['┌─┐','┤M├','└─┘'], 3

    columns = []
    for op in operations:
        name = op['name'].upper()
        qbits = op['qubits']
        params = op.get('params', [])
        if name in ('BARRIER','RESET'): continue

        if len(qbits) == 1:
            q = qbits[0]
            label = f"{name}({','.join(f'{p:.2f}' for p in params)})" if params else name
            gc, w = gate_cell(label)
            wc, _ = wire_cell(w)
            columns.append([gc if i==q else wc for i in range(n_qubits)])

        elif len(qbits) == 2:
            ctrl, tgt = qbits
            mn, mx = min(ctrl,tgt), max(ctrl,tgt)
            if name in ('SWAP','ISWAP'):
                w=5; sc=swap_cell(w)[0]; vl=vline_cell(w)[0]; wc=wire_cell(w)[0]
                columns.append([sc if i in (ctrl,tgt) else vl if mn<i<mx else wc for i in range(n_qubits)])
            else:
                tgt_lbl = 'X' if name in ('CNOT','CX') else name
                gc,w = gate_cell(tgt_lbl)
                cc=ctrl_cell(w)[0]; vl=vline_cell(w)[0]; wc=wire_cell(w)[0]
                columns.append([cc if i==ctrl else gc if i==tgt else vl if mn<i<mx else wc for i in range(n_qubits)])

        elif len(qbits) >= 3:
            ctrls,tgt = qbits[:-1],qbits[-1]
            tgt_lbl = 'X' if name in ('CCX','TOFFOLI','CCNOT') else name
            gc,w = gate_cell(tgt_lbl)
            cc=ctrl_cell(w)[0]; vl=vline_cell(w)[0]; wc=wire_cell(w)[0]
            mn,mx = min(qbits),max(qbits)
            columns.append([cc if i in ctrls else gc if i==tgt else vl if mn<i<mx else wc for i in range(n_qubits)])

    if measured_qubits:
        mc,w = meas_cell(); wc,_=wire_cell(w)
        columns.append([mc if i in measured_qubits else wc for i in range(n_qubits)])

    lbl_w = max(len(f'q{i}: ') for i in range(n_qubits))
    rows = []
    for i in range(n_qubits):
        top=' '*lbl_w+'  '; mid=f'q{i}: '.ljust(lbl_w)+'──'; bot=' '*lbl_w+'  '
        for col in columns:
            cell=col[i]; top+=cell[T]; mid+=cell[M]; bot+=cell[B]
        mid+='─'
        rows+=[top,mid,bot]
    return '\n'.join(rows)


# ═══════════════════════════════════════════════════════════════
# MATPLOTLIB — Qiskit style
# ═══════════════════════════════════════════════════════════════

# Exact Qiskit color palette
_CLR = {
    'H'      :('#6929C4','#FFFFFF'),  # purple
    'X'      :('#1192E8','#FFFFFF'),  # blue
    'Y'      :('#9F1853','#FFFFFF'),  # crimson
    'Z'      :('#198038','#FFFFFF'),  # green
    'S'      :('#005D5D','#FFFFFF'),  # teal
    'T'      :('#B28600','#FFFFFF'),  # gold
    'SDG'    :('#005D5D','#FFFFFF'),
    'TDG'    :('#B28600','#FFFFFF'),
    'SX'     :('#EE538B','#FFFFFF'),  # pink
    'I'      :('#8D8D8D','#FFFFFF'),
    'RX'     :('#00539A','#FFFFFF'),  # dark blue
    'RY'     :('#6929C4','#FFFFFF'),
    'RZ'     :('#007D79','#FFFFFF'),  # teal
    'P'      :('#007D79','#FFFFFF'),
    'U'      :('#6929C4','#FFFFFF'),
    'CX'     :('#1192E8','#FFFFFF'),
    'CNOT'   :('#1192E8','#FFFFFF'),
    'CY'     :('#9F1853','#FFFFFF'),
    'CZ'     :('#198038','#FFFFFF'),
    'CRX'    :('#00539A','#FFFFFF'),
    'CRY'    :('#6929C4','#FFFFFF'),
    'CRZ'    :('#007D79','#FFFFFF'),
    'CP'     :('#007D79','#FFFFFF'),
    'SWAP'   :('#FA4D56','#FFFFFF'),  # red
    'ISWAP'  :('#FA4D56','#FFFFFF'),
    'CCX'    :('#FF832B','#FFFFFF'),  # orange
    'TOFFOLI':('#FF832B','#FFFFFF'),
    'CSWAP'  :('#FF832B','#FFFFFF'),
    'RESET'  :('#8D8D8D','#FFFFFF'),
    'DEFAULT':('#6929C4','#FFFFFF'),
}


def draw_matplotlib(operations, n_qubits, measured_qubits,
                    figsize=None, title=''):
    """
    Qiskit-style professional circuit diagram.
    - Zero padding between title and circuit
    - Title centered only if user provides name
    - Returns Figure only — never calls plt.show()
    """
    try:
        import matplotlib.pyplot as plt
        import matplotlib.patches as mpatches
        from matplotlib.patches import FancyBboxPatch
    except ImportError:
        raise ImportError("pip install matplotlib")

    # ── Layout constants (Qiskit proportions) ───────────────
    COL_W  = 1.0    # column width
    ROW_H  = 1.0    # row height per qubit
    BOX_W  = 0.72   # gate box width
    BOX_H  = 0.50   # gate box height
    LBL_W  = 0.55   # qubit label width on left
    WIRE_C = '#000000'
    CTRL_C = '#000000'

    # Title check
    _NO_TITLE = {'circuit', 'circuit_inv', ''}
    show_title = bool(title and title.strip().lower() not in _NO_TITLE)

    # ── Build column layout ──────────────────────────────────
    col_ops = []; bar_xs = []; cx = LBL_W + 0.8
    for op in operations:
        nm = op['name'].upper()
        if nm == 'BARRIER':
            bar_xs.append(cx - 0.3); continue
        col_ops.append((cx, op)); cx += COL_W

    # Measurement columns — each qubit separate column
    meas_x     = cx + 0.2
    MEAS_COL_W = 0.9
    n_meas     = len(measured_qubits)
    total_w    = meas_x + n_meas * MEAS_COL_W + 0.5

    # ── Figure size — dynamic, zero padding ─────────────────
    if figsize is None:
        fw = max(6.0, total_w * 0.88)
        fh = n_qubits * ROW_H + 0.4 + (0.30 if show_title else 0.0)
        figsize = (fw, fh)

    fig, ax = plt.subplots(figsize=figsize)
    fig.patch.set_facecolor('#FFFFFF')
    ax.set_facecolor('#FFFFFF')

    # ── Axes limits — tight, no wasted space ────────────────
    top_lim = n_qubits * ROW_H + (0.25 if show_title else 0.02)
    ax.set_xlim(-LBL_W - 0.1, total_w)
    ax.set_ylim(-1.45, top_lim)
    ax.axis('off')

    def qy(q):
        """q0 at top."""
        return (n_qubits - 1 - q) * ROW_H

    # ── Title — fig.text for true center, zero gap ───────────
    if show_title:
        fig.text(0.5, 1.0, title,
                 ha='center', va='top',
                 fontsize=11, fontweight='bold',
                 color='#111111', fontfamily='monospace')

    # ── Qubit wires + labels ─────────────────────────────────
    for q in range(n_qubits):
        y = qy(q)
        # Wire
        ax.plot([-LBL_W + 0.05, total_w - 0.15], [y, y],
                color=WIRE_C, lw=1.5, zorder=1,
                solid_capstyle='round')
        # Label box (Qiskit style: q_0 |0⟩)
        ax.text(-LBL_W, y + 0.14, f'$q_{{{q}}}$',
                ha='left', va='center', fontsize=9,
                color='#000000', fontweight='bold')
        ax.text(-LBL_W, y - 0.14, '|0⟩',
                ha='left', va='center', fontsize=8,
                color='#555555')

    # ── Classical double-line register ───────────────────────
    n_cb = len(measured_qubits)
    cy   = -0.82
    if n_cb > 0:
        for off in (+0.048, -0.048):
            ax.plot([-LBL_W + 0.05, total_w - 0.15],
                    [cy + off, cy + off],
                    color='#555555', lw=1.2, zorder=1)
        # Label
        ax.text(-LBL_W, cy + 0.14, 'c',
                ha='left', va='center', fontsize=9,
                color='#000000', fontweight='bold')
        ax.text(-LBL_W, cy - 0.14, f'{n_cb}',
                ha='left', va='center', fontsize=8,
                color='#555555')
        # Slash
        ax.plot([-LBL_W + 0.32, -LBL_W + 0.52],
                [cy - 0.12, cy + 0.12],
                color='#555555', lw=1.5, zorder=2)

    # ── Barriers ─────────────────────────────────────────────
    for bx in bar_xs:
        ax.fill_betweenx(
            [qy(n_qubits-1) - 0.42, qy(0) + 0.42],
            bx - 0.06, bx + 0.06,
            color='#BBBBBB', alpha=0.45, zorder=2)

    # ── Gate drawing helpers ─────────────────────────────────
    def _gate(x, q, label, fc, tc, params=None):
        y = qy(q)
        lbl = label
        if params:
            lbl = f"{label}\n({','.join(f'{p:.2f}' for p in params)})"
        # Shadow
        ax.add_patch(FancyBboxPatch(
            (x-BOX_W/2+0.022, y-BOX_H/2-0.022), BOX_W, BOX_H,
            boxstyle='round,pad=0.04',
            facecolor='#00000012', edgecolor='none', zorder=3))
        # Box
        ax.add_patch(FancyBboxPatch(
            (x-BOX_W/2, y-BOX_H/2), BOX_W, BOX_H,
            boxstyle='round,pad=0.04',
            facecolor=fc, edgecolor='#FFFFFF',
            linewidth=1.6, zorder=4))
        fs = 9 if '\n' not in lbl else 6.5
        ax.text(x, y, lbl, ha='center', va='center',
                fontsize=fs, fontweight='bold', color=tc,
                zorder=5, fontfamily='monospace')

    def _ctrl_dot(x, q, color='#000000'):
        ax.plot(x, qy(q), 'o', color=color,
                markersize=11, zorder=5,
                markeredgecolor='white', markeredgewidth=1.0)

    def _vline(x, q0, q1, color='#000000'):
        y0, y1 = qy(q0), qy(q1)
        ax.plot([x, x], [min(y0,y1), max(y0,y1)],
                color=color, lw=1.8, zorder=3)

    def _cnot_target(x, q, color='#1192E8'):
        """Qiskit ⊕ style."""
        y = qy(q); r = 0.22
        # Outer circle
        circle = plt.Circle((x,y), r, color=color,
                             fill=True, zorder=4)
        ax.add_patch(circle)
        # Plus sign
        ax.plot([x-r, x+r], [y, y], color='white', lw=2.0, zorder=5)
        ax.plot([x, x], [y-r, y+r], color='white', lw=2.0, zorder=5)

    def _swap_mark(x, q, color='#FA4D56'):
        y = qy(q); d = 0.17
        ax.plot([x-d,x+d],[y-d,y+d], color=color, lw=2.2, zorder=5)
        ax.plot([x-d,x+d],[y+d,y-d], color=color, lw=2.2, zorder=5)

    def _measure(x, q, idx):
        """Dark measurement box with arc+needle, arrow to classical wire."""
        y = qy(q)
        # Shadow
        ax.add_patch(FancyBboxPatch(
            (x-BOX_W/2+0.022, y-BOX_H/2-0.022), BOX_W, BOX_H,
            boxstyle='round,pad=0.04',
            facecolor='#00000018', edgecolor='none', zorder=3))
        # Dark box
        ax.add_patch(FancyBboxPatch(
            (x-BOX_W/2, y-BOX_H/2), BOX_W, BOX_H,
            boxstyle='round,pad=0.04',
            facecolor='#1A1A2E', edgecolor='#5B8DDE',
            linewidth=1.8, zorder=4))
        # Meter arc
        r = 0.148; cy0 = y - 0.038
        th = np.linspace(np.pi, 0, 50)
        ax.plot(x + r*np.cos(th), cy0 + r*np.sin(th),
                color='#FFFFFF', lw=1.5, zorder=5)
        # Needle arrow
        ax.annotate('',
                    xy=(x+r*0.66, cy0+r*0.66),
                    xytext=(x, cy0),
                    arrowprops=dict(arrowstyle='->',
                                   color='#FFFFFF', lw=1.3),
                    zorder=5)
        # Drop arrow to classical wire
        ax.annotate('',
                    xy=(x, cy + 0.07),
                    xytext=(x, y - BOX_H/2 - 0.02),
                    arrowprops=dict(arrowstyle='->',
                                   color='#777777', lw=1.1),
                    zorder=3)
        # Bit index
        ax.text(x, cy - 0.20, str(idx),
                ha='center', va='top',
                fontsize=8, color='#333333', fontweight='bold')

    # ── Draw all gate operations ─────────────────────────────
    for (x, op) in col_ops:
        nm     = op['name'].upper()
        qbits  = op['qubits']
        params = op.get('params', [])
        fc, tc = _CLR.get(nm, _CLR['DEFAULT'])

        if nm == 'RESET':
            _gate(x, qbits[0], '|0⟩', fc, tc)

        elif len(qbits) == 1:
            _gate(x, qbits[0], nm, fc, tc, params or None)

        elif len(qbits) == 2:
            ctrl, tgt = qbits
            _vline(x, min(ctrl,tgt), max(ctrl,tgt), fc)
            if nm in ('CNOT','CX'):
                _ctrl_dot(x, ctrl, fc)
                _cnot_target(x, tgt, fc)
            elif nm in ('SWAP','ISWAP'):
                _swap_mark(x, ctrl, fc)
                _swap_mark(x, tgt, fc)
            else:
                _ctrl_dot(x, ctrl, fc)
                lbl = nm[1:] if nm.startswith('C') else nm
                _gate(x, tgt, lbl, fc, tc, params or None)

        elif len(qbits) >= 3:
            ctrls, tgt = qbits[:-1], qbits[-1]
            _vline(x, min(qbits), max(qbits), fc)
            for c in ctrls: _ctrl_dot(x, c, fc)
            if nm in ('CCX','TOFFOLI','CCNOT'):
                _cnot_target(x, tgt, fc)
            else:
                _gate(x, tgt, nm, fc, tc, params or None)

    # ── Measurements — each qubit own column ─────────────────
    for idx, q in enumerate(sorted(measured_qubits)):
        mx = meas_x + idx * MEAS_COL_W
        _measure(mx, q, idx)
        # Extend wire to this measurement
        ax.plot([cx - 0.2, mx - BOX_W/2], [qy(q), qy(q)],
                color=WIRE_C, lw=1.5, zorder=1)

    # Extend classical wire
    if n_cb > 0:
        ext_x = meas_x + n_meas * MEAS_COL_W
        for off in (+0.048, -0.048):
            ax.plot([cx - 0.2, ext_x],
                    [cy + off, cy + off],
                    color='#555555', lw=1.2, zorder=1)

    # ── Zero padding — subplots_adjust ───────────────────────
    plt.subplots_adjust(top=1.0, bottom=0.0, left=0.0, right=1.0)

    return fig  # never calls plt.show()


# ═══════════════════════════════════════════════════════════════
# HISTOGRAM
# ═══════════════════════════════════════════════════════════════

def plot_histogram(counts, title='Measurement Results',
                   figsize=None, series_label=None,
                   series_color=None, xlabel='Basis State',
                   ylabel='Probability'):
    """
    Single or multi-series histogram.
    counts: dict or list of dicts
    """
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        raise ImportError("pip install matplotlib")

    if isinstance(counts, dict):
        series_list  = [counts]
        series_label = series_label or ['Results']
        series_color = series_color or ['#6929C4']
    else:
        series_list  = counts
        n = len(series_list)
        series_label = series_label or [f'Series {i+1}' for i in range(n)]
        series_color = (series_color or
                        ['#1192E8','#FA4D56','#198038',
                         '#FF832B','#9F1853','#007D79'])[:n]

    all_states = sorted({k for s in series_list for k in s})
    n_states   = len(all_states)
    n_series   = len(series_list)

    if figsize is None:
        figsize = (max(7, n_states * n_series * 0.55 + 2), 5)

    fig, ax = plt.subplots(figsize=figsize)
    fig.patch.set_facecolor('#FFFFFF')
    ax.set_facecolor('#FAFAFA')

    x = np.arange(n_states)
    bar_w = 0.75 / n_series
    max_v = 0

    for si, (sdata, slbl, scol) in enumerate(
            zip(series_list, series_label, series_color)):
        total  = sum(sdata.values()) or 1
        vals   = [sdata.get(st, 0) for st in all_states]
        probs  = [v/total*100 for v in vals]
        offset = (si - (n_series-1)/2) * bar_w
        bars   = ax.bar(x+offset, probs, bar_w*0.90,
                        label=slbl, color=scol,
                        edgecolor='white', linewidth=0.8,
                        alpha=0.95, zorder=3)
        max_v  = max(max_v, max(probs, default=0))
        for bar, pct in zip(bars, probs):
            if pct > 0.5:
                ax.text(bar.get_x()+bar.get_width()/2,
                        bar.get_height()+0.8,
                        f'{pct:.1f}%',
                        ha='center', va='bottom',
                        fontsize=8, fontweight='bold',
                        color='#222222')

    ax.set_xticks(x)
    ax.set_xticklabels(all_states, fontsize=9,
                       fontweight='bold', rotation=45, ha='right')
    ax.set_xlabel(xlabel, fontsize=11, labelpad=8, color='#333333')
    ax.set_ylabel(ylabel+' (%)', fontsize=11, labelpad=8, color='#333333')
    ax.set_title(title, fontsize=13, fontweight='bold',
                 color='#111111', pad=10)
    ax.set_ylim(0, min(115, max_v*1.20))
    ax.yaxis.grid(True, color='#DDDDDD', lw=0.8, zorder=0)
    ax.set_axisbelow(True)
    for sp in ['top','right']:   ax.spines[sp].set_visible(False)
    for sp in ['left','bottom']: ax.spines[sp].set_color('#CCCCCC')
    ax.tick_params(colors='#444444', length=3)
    if n_series > 1:
        ax.legend(loc='upper right', fontsize=9,
                  framealpha=0.92, edgecolor='#CCCCCC')
    plt.tight_layout()
    return fig


# ═══════════════════════════════════════════════════════════════
# BLOCH SPHERE
# ═══════════════════════════════════════════════════════════════

def plot_bloch_sphere(bx, by, bz, qubit=0):
    """Bloch sphere. Returns Figure."""
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        raise ImportError("pip install matplotlib")

    fig = plt.figure(figsize=(6,6))
    ax  = fig.add_subplot(111, projection='3d')
    ax.set_facecolor('#FFFFFF')
    fig.patch.set_facecolor('#FFFFFF')

    u,v = np.mgrid[0:2*np.pi:40j, 0:np.pi:20j]
    ax.plot_wireframe(np.cos(u)*np.sin(v), np.sin(u)*np.sin(v),
                      np.cos(v), color='#BBCCDD', alpha=0.28, lw=0.5)

    for vec,lbl,col in [
        ([1,0,0],'|+⟩','#888'), ([-1,0,0],'|−⟩','#888'),
        ([0,1,0],'|i+⟩','#888'),([ 0,-1,0],'|i−⟩','#888'),
        ([0,0,1],'|0⟩','#0077BB'),([0,0,-1],'|1⟩','#CC2222'),
    ]:
        ax.plot([0,vec[0]],[0,vec[1]],[0,vec[2]],
                color='#AAAAAA', lw=0.8, alpha=0.6)
        ax.text(vec[0]*1.22,vec[1]*1.22,vec[2]*1.22,
                lbl, color=col, fontsize=9,
                ha='center', fontweight='bold')

    ax.quiver(0,0,0,bx,by,bz, color='#FA4D56',
              lw=2.5, arrow_length_ratio=0.15)
    ax.scatter([bx],[by],[bz], color='#FA4D56', s=60, zorder=5)

    for seg in [([bx,bx],[by,by],[0,bz]),
                ([bx,bx],[0,by],[0,0]),([0,bx],[0,0],[0,0])]:
        ax.plot(*seg, color='#AAAAAA', lw=0.8, ls='--')

    ax.set_title(f'Bloch Sphere — q{qubit}',
                 fontsize=11, fontweight='bold', color='#222222')
    for lim in (ax.set_xlim,ax.set_ylim,ax.set_zlim): lim([-1.3,1.3])
    ax.tick_params(colors='#AAAAAA', labelsize=7)
    for pane in (ax.xaxis.pane,ax.yaxis.pane,ax.zaxis.pane):
        pane.fill=False
    plt.tight_layout()
    return fig
