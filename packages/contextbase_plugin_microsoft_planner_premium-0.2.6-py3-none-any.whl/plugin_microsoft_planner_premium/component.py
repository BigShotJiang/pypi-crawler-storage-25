import dagster as dg
from dagster import AssetExecutionContext
from dagster_dlt import DagsterDltResource
from shared_plugins.automation import non_overlapping_automation_condition
from shared_plugins.bindings import (
    parse_binding_config,
    require_client_credentials,
    resolve_binding_models,
)
from shared_plugins.control_plane import ControlPlaneClient
from shared_plugins.dlt import resolve_partition_binding, run_dlt_pipeline
from shared_plugins.microsoft_dataverse import (
    DataverseClient,
    build_dataverse_dlt_source,
)
from shared_plugins.naming import (
    dagster_asset_group_name,
    dagster_asset_tags,
    dagster_dlt_asset_key,
    dagster_partition_def_name,
    dagster_pool_name,
    dlt_source_name,
    plugin_id_from_module,
)
from shared_plugins.resources import DLT_RESOURCE
from shared_types.client_credentials_auth import ClientCredentialsAuth

from .binding_config import MicrosoftPlannerPremiumBindingConfig
from .tables import (
    DEFAULT_ACTIVE_MODEL_NAMES,
    SUPPORTED_MODEL_NAMES,
    TABLE_SPECS,
)

PLUGIN_ID = plugin_id_from_module(__file__)
SYNC_JOB = "sync"
SYNC_SOURCE_NAME = dlt_source_name(PLUGIN_ID, SYNC_JOB)


def _build_dataverse_client(
    cfg: MicrosoftPlannerPremiumBindingConfig,
    auth: ClientCredentialsAuth,
) -> DataverseClient:
    return DataverseClient(
        org_url=cfg.org_url,
        tenant_id=cfg.tenant_id,
        client_id=auth.client_id,
        client_secret=auth.client_secret,
    )


def _build_sync_specs(
    partitions_def: dg.PartitionsDefinition,
    automation_condition: dg.AutomationCondition,
) -> list[dg.AssetSpec]:
    shared = dict(
        group_name=dagster_asset_group_name(PLUGIN_ID),
        tags=dagster_asset_tags(PLUGIN_ID),
        automation_condition=automation_condition,
        partitions_def=partitions_def,
    )

    return [
        dg.AssetSpec(
            key=dagster_dlt_asset_key(SYNC_SOURCE_NAME, spec.resource_name),
            **shared,
        )
        for spec in TABLE_SPECS
    ]


class MicrosoftPlannerPremiumSyncComponent(dg.Component):
    def build_defs(self, context: dg.ComponentLoadContext) -> dg.Definitions:
        partitions_def = dg.DynamicPartitionsDefinition(
            name=dagster_partition_def_name(PLUGIN_ID)
        )

        sync_specs = _build_sync_specs(
            partitions_def,
            non_overlapping_automation_condition(
                dg.AutomationCondition.on_missing()
                | dg.AutomationCondition.on_cron("*/15 * * * *")
            ),
        )

        @dg.multi_asset(
            specs=sync_specs,
            can_subset=True,
            name="microsoft_planner_premium_sync",
            pool=dagster_pool_name(PLUGIN_ID),
        )
        def microsoft_planner_premium_sync_assets(
            context: AssetExecutionContext,
            dlt_resource: DagsterDltResource,
            control_plane: dg.ResourceParam[ControlPlaneClient],
        ):
            binding = resolve_partition_binding(
                context=context,
                control_plane=control_plane,
                plugin_id=PLUGIN_ID,
            )
            binding_id = str(binding.binding_id)
            cfg = parse_binding_config(binding, MicrosoftPlannerPremiumBindingConfig)
            auth = require_client_credentials(binding)
            binding_models = resolve_binding_models(
                binding,
                supported_models=SUPPORTED_MODEL_NAMES,
                default_active=DEFAULT_ACTIVE_MODEL_NAMES,
            )
            client = _build_dataverse_client(cfg, auth)
            try:
                source = build_dataverse_dlt_source(
                    plugin_id=PLUGIN_ID,
                    job=SYNC_JOB,
                    binding_id=binding_id,
                    client=client,
                    binding_models=binding_models,
                    specs=TABLE_SPECS,
                )
                yield from run_dlt_pipeline(
                    context=context,
                    dlt_resource=dlt_resource,
                    source=source,
                    plugin_id=PLUGIN_ID,
                    binding_id=binding_id,
                    job_name=SYNC_JOB,
                )
            finally:
                client.close()

        automation_sensor = dg.AutomationConditionSensorDefinition(
            name="microsoft_planner_premium_automation_sensor",
            target=dg.AssetSelection.assets(
                microsoft_planner_premium_sync_assets,
            ),
            default_status=dg.DefaultSensorStatus.RUNNING,
            minimum_interval_seconds=30,
        )

        return dg.Definitions(
            assets=[
                microsoft_planner_premium_sync_assets,
            ],
            sensors=[automation_sensor],
            resources={
                "dlt_resource": DLT_RESOURCE,
            },
        )
