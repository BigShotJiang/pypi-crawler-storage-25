"""Inventory of Dataverse entity sets this plugin syncs.

Each `DataverseTableSpec` names one OData entity set, its primary-key
attribute, and the sync mode (delta-tracked vs. full snapshot). Selected
columns are NOT carried on the spec — they are computed at warmup from
per-tenant `EntityDefinitions` metadata via
`shared_plugins.microsoft_dataverse.runtime_schema.build_runtime_table_schemas`,
which lets the typed-column rewrite pick up new attributes without
requiring code changes per tenant.
"""

from __future__ import annotations

from shared_plugins.microsoft_dataverse import (
    DataverseSyncMode,
    DataverseTableSpec,
)

DELTA_TABLE_SPECS: tuple[DataverseTableSpec, ...] = (
    DataverseTableSpec(
        entity_set="msdyn_projects",
        primary_key="msdyn_projectid",
        sync_mode=DataverseSyncMode.DELTA,
        resource_name="msdyn_projects",
    ),
    DataverseTableSpec(
        entity_set="msdyn_projecttasks",
        primary_key="msdyn_projecttaskid",
        sync_mode=DataverseSyncMode.DELTA,
        resource_name="msdyn_projecttasks",
    ),
    DataverseTableSpec(
        entity_set="msdyn_projectteams",
        primary_key="msdyn_projectteamid",
        sync_mode=DataverseSyncMode.DELTA,
        resource_name="msdyn_projectteams",
    ),
    DataverseTableSpec(
        entity_set="msdyn_projectbuckets",
        primary_key="msdyn_projectbucketid",
        sync_mode=DataverseSyncMode.DELTA,
        resource_name="msdyn_projectbuckets",
    ),
    DataverseTableSpec(
        entity_set="msdyn_projecttaskdependencies",
        primary_key="msdyn_projecttaskdependencyid",
        sync_mode=DataverseSyncMode.DELTA,
        resource_name="msdyn_projecttaskdependencies",
    ),
    DataverseTableSpec(
        entity_set="msdyn_resourceassignments",
        primary_key="msdyn_resourceassignmentid",
        sync_mode=DataverseSyncMode.DELTA,
        resource_name="msdyn_resourceassignments",
    ),
    DataverseTableSpec(
        entity_set="msdyn_projectlabels",
        primary_key="msdyn_projectlabelid",
        sync_mode=DataverseSyncMode.DELTA,
        resource_name="msdyn_projectlabels",
    ),
    DataverseTableSpec(
        entity_set="msdyn_projecttasktolabels",
        primary_key="msdyn_projecttasktolabelid",
        sync_mode=DataverseSyncMode.DELTA,
        resource_name="msdyn_projecttasktolabels",
    ),
    DataverseTableSpec(
        entity_set="msdyn_projectstatusreports",
        primary_key="msdyn_projectstatusreportid",
        sync_mode=DataverseSyncMode.DELTA,
        resource_name="msdyn_projectstatusreports",
    ),
    DataverseTableSpec(
        entity_set="msdyn_projectissues",
        primary_key="msdyn_projectissueid",
        sync_mode=DataverseSyncMode.DELTA,
        resource_name="msdyn_projectissues",
    ),
    DataverseTableSpec(
        entity_set="msdyn_projectrisks",
        primary_key="msdyn_projectriskid",
        sync_mode=DataverseSyncMode.DELTA,
        resource_name="msdyn_projectrisks",
    ),
    DataverseTableSpec(
        entity_set="msdyn_projectchanges",
        primary_key="msdyn_projectchangeid",
        sync_mode=DataverseSyncMode.DELTA,
        resource_name="msdyn_projectchanges",
    ),
    DataverseTableSpec(
        entity_set="msdyn_projectparameters",
        primary_key="msdyn_projectparameterid",
        sync_mode=DataverseSyncMode.DELTA,
        resource_name="msdyn_projectparameters",
    ),
    DataverseTableSpec(
        entity_set="msdyn_workhourtemplates",
        primary_key="msdyn_workhourtemplateid",
        sync_mode=DataverseSyncMode.DELTA,
        resource_name="msdyn_workhourtemplates",
    ),
)

SNAPSHOT_TABLE_SPECS: tuple[DataverseTableSpec, ...] = (
    DataverseTableSpec(
        entity_set="msdyn_projectchecklists",
        primary_key="msdyn_projectchecklistid",
        sync_mode=DataverseSyncMode.SNAPSHOT,
        resource_name="msdyn_projectchecklists",
    ),
    DataverseTableSpec(
        entity_set="msdyn_projectsprints",
        primary_key="msdyn_projectsprintid",
        sync_mode=DataverseSyncMode.SNAPSHOT,
        resource_name="msdyn_projectsprints",
    ),
    DataverseTableSpec(
        entity_set="msdyn_projecttaskattachments",
        primary_key="msdyn_projecttaskattachmentid",
        sync_mode=DataverseSyncMode.SNAPSHOT,
        resource_name="msdyn_projecttaskattachments",
    ),
    DataverseTableSpec(
        entity_set="msdyn_projecttaskconversations",
        primary_key="msdyn_projecttaskconversationid",
        sync_mode=DataverseSyncMode.SNAPSHOT,
        resource_name="msdyn_projecttaskconversations",
    ),
    DataverseTableSpec(
        entity_set="msdyn_projecttasktogoals",
        primary_key="msdyn_projecttasktogoalid",
        sync_mode=DataverseSyncMode.SNAPSHOT,
        resource_name="msdyn_projecttasktogoals",
    ),
    DataverseTableSpec(
        entity_set="msdyn_projectgoals",
        primary_key="msdyn_projectgoalid",
        sync_mode=DataverseSyncMode.SNAPSHOT,
        resource_name="msdyn_projectgoals",
    ),
    DataverseTableSpec(
        entity_set="msdyn_projectbaselinedatas",
        primary_key="msdyn_projectbaselinedataid",
        sync_mode=DataverseSyncMode.SNAPSHOT,
        resource_name="msdyn_projectbaselinedatas",
    ),
    DataverseTableSpec(
        entity_set="msdyn_projectbaselinetaskdatas",
        primary_key="msdyn_projectbaselinetaskdataid",
        sync_mode=DataverseSyncMode.SNAPSHOT,
        resource_name="msdyn_projectbaselinetaskdatas",
    ),
    DataverseTableSpec(
        entity_set="msdyn_projectteamschannelmappings",
        primary_key="msdyn_projectteamschannelmappingid",
        sync_mode=DataverseSyncMode.SNAPSHOT,
        resource_name="msdyn_projectteamschannelmappings",
    ),
)

TABLE_SPECS: tuple[DataverseTableSpec, ...] = (
    *DELTA_TABLE_SPECS,
    *SNAPSHOT_TABLE_SPECS,
)

SUPPORTED_MODEL_NAMES: tuple[str, ...] = tuple(
    spec.resource_name for spec in TABLE_SPECS
)
DEFAULT_ACTIVE_MODEL_NAMES: tuple[str, ...] = SUPPORTED_MODEL_NAMES
