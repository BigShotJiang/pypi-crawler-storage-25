from __future__ import annotations

from shared_plugins.microsoft_dataverse import DataverseBindingConfigBase


class MicrosoftPlannerPremiumBindingConfig(DataverseBindingConfigBase):
    pass
