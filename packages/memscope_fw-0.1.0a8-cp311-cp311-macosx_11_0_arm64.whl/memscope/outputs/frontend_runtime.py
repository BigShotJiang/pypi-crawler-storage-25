"""Bundled frontend runtime assets for self-contained offline reports."""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from hashlib import sha256
from pathlib import Path
from typing import cast


@dataclass(frozen=True, slots=True)
class BundledRuntimeAsset:
    """Self-contained JS asset bundled into generated HTML reports."""

    name: str
    version: str
    code: str
    source: str


@dataclass(frozen=True, slots=True)
class RuntimeAssetSize:
    """Size + budget snapshot for one bundled runtime asset."""

    name: str
    filename: str
    size_bytes: int
    min_bytes: int
    max_bytes: int

    @property
    def within_budget(self) -> bool:
        return self.min_bytes <= self.size_bytes <= self.max_bytes


_ASSET_DIR = Path(__file__).resolve().parent / "assets"

_KIB = 1024

_RUNTIME_SPECS = (
    {
        "name": "d3",
        "version": "7.9.0",
        "filename": "d3.v7.9.0.min.js",
        "sha256": "F2094BBF6141B359722C4FE454EB6C4B0F0E42CC10CC7AF921FC158FCEB86539",
        "source": "local-vendor",
        "min_bytes": 250 * _KIB,
        "max_bytes": 320 * _KIB,
    },
    {
        "name": "echarts",
        "version": "5.5.1",
        "filename": "echarts.v5.5.1.min.js",
        "sha256": "E84270BD0CD5BDF60FEFC26D00C2A391CB2E81F4D26A7A9EE16185A54773A3CF",
        "source": "local-vendor",
        "min_bytes": 950 * _KIB,
        "max_bytes": 1100 * _KIB,
    },
    {
        "name": "memscope-runtime",
        "version": "0.8.1-xfilter",
        "filename": "memscope.runtime.v0.2.0.js",
        "sha256": "5E35BEF1FC25F75FAC3907575EAA9C43BFFCD71B5FFF21963AF0F1115617E5F6",
        "source": "local-runtime",
        "min_bytes": 60 * _KIB,
        "max_bytes": 200 * _KIB,
    },
)

TOTAL_RUNTIME_BUDGET_BYTES = 1700 * _KIB


def _load_asset_code(filename: str, expected_sha256: str) -> str:
    path = _ASSET_DIR / filename
    if not path.is_file():
        raise RuntimeError(f"Missing runtime asset: {path}")
    code = path.read_text(encoding="utf-8")
    digest = sha256(code.encode("utf-8")).hexdigest().upper()
    expected = expected_sha256.upper()
    if digest != expected:
        raise RuntimeError(
            "Runtime asset integrity check failed for "
            f"{filename}: expected {expected}, got {digest}",
        )
    return code


@lru_cache(maxsize=1)
def _bundled_runtime_assets() -> tuple[BundledRuntimeAsset, ...]:
    assets: list[BundledRuntimeAsset] = []
    for spec in _RUNTIME_SPECS:
        assets.append(
            BundledRuntimeAsset(
                name=str(spec["name"]),
                version=str(spec["version"]),
                code=_load_asset_code(
                    filename=str(spec["filename"]),
                    expected_sha256=str(spec["sha256"]),
                ),
                source=str(spec["source"]),
            )
        )
    return tuple(assets)


def bundled_runtime_assets() -> list[BundledRuntimeAsset]:
    """Return local frontend runtime assets for HTML embedding."""
    return list(_bundled_runtime_assets())


def runtime_asset_sizes() -> list[RuntimeAssetSize]:
    """Return size + budget snapshot for every declared runtime asset.

    Reads sizes from disk rather than the cached code blob so tests can call
    this without forcing a full asset load + integrity check first.
    """
    snapshots: list[RuntimeAssetSize] = []
    for spec in _RUNTIME_SPECS:
        filename = str(spec["filename"])
        path = _ASSET_DIR / filename
        size = path.stat().st_size if path.is_file() else 0
        snapshots.append(
            RuntimeAssetSize(
                name=str(spec["name"]),
                filename=filename,
                size_bytes=size,
                min_bytes=cast(int, spec["min_bytes"]),
                max_bytes=cast(int, spec["max_bytes"]),
            )
        )
    return snapshots


def declared_asset_filenames() -> frozenset[str]:
    """Filenames the runtime is allowed to ship.

    Used by orphan-file detection so a file dropped into ``assets/`` without a
    matching spec entry fails the budget check rather than silently shipping.
    """
    return frozenset(str(spec["filename"]) for spec in _RUNTIME_SPECS)


def discover_asset_directory_files() -> list[str]:
    """Return every file currently present in the bundled assets directory."""
    if not _ASSET_DIR.is_dir():
        return []
    return sorted(p.name for p in _ASSET_DIR.iterdir() if p.is_file())
