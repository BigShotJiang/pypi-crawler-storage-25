"""Typer-based command-line entrypoint for MemScope."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from importlib.metadata import PackageNotFoundError, version
from typing import Annotated, TypeVar

import typer

from memscope import _build_profile
from memscope.app.commands import analyze, dev, diagnostics, diff, license, validate
from memscope.app.logging_utils import configure_logging
from memscope.app.session import (
    CommandExecutionError,
    CommandResult,
    ExitCode,
    GlobalOptions,
    SessionManager,
)

R = TypeVar("R", bound=CommandResult)


# Whether the real developer-mode bypass module is bundled in this artifact.
# Production wheels exclude `_dev_mode_real.py` via the hatchling build hook
# (see `hatch_build.py`), so this resolves to False there. In source-tree
# runs and developer wheels the import succeeds.
#
# When False, the `--developer-mode` Typer option is *not registered* at all
# — `memscope --help` won't list it and passing the flag fails with Typer's
# standard "no such option" error. See docs/RELEASE_DISTRIBUTION_PLAN.md
# Phase B for the full design.
_DEV_MODE_AVAILABLE: bool
try:
    import memscope.licensing._dev_mode_real  # noqa: F401

    _DEV_MODE_AVAILABLE = True
except ImportError:
    _DEV_MODE_AVAILABLE = False


@dataclass(slots=True)
class AppContext:
    options: GlobalOptions


def _resolve_version() -> str:
    try:
        # PyPI distribution name (`memscope-fw`) — different from the
        # Python import name (`memscope`). See pyproject.toml.
        base = version("memscope-fw")
    except PackageNotFoundError:
        from memscope import __version__

        base = __version__
    profile = "developer" if _build_profile.is_developer_build() else "production"
    return f"{base} ({profile} build)"


app = typer.Typer(
    name="memscope",
    no_args_is_help=True,
    invoke_without_command=True,
    add_completion=False,
    help="Local-first firmware footprint intelligence CLI.",
)


def _session_from_context(ctx: typer.Context) -> SessionManager:
    context = ctx.obj
    if not isinstance(context, AppContext):
        raise RuntimeError("CLI context not initialized")
    return SessionManager(context.options)


def _run_with_error_handling(
    session: SessionManager,
    action: Callable[[SessionManager], CommandResult],
) -> None:
    try:
        result = action(session)
    except CommandExecutionError as exc:
        typer.secho(exc.message, err=True, fg=typer.colors.RED)
        raise typer.Exit(code=int(exc.exit_code)) from exc

    if result.message:
        typer.echo(result.message)
    raise typer.Exit(code=int(result.exit_code))


def _execute_callback(
    ctx: typer.Context,
    *,
    config: str | None,
    log_level: str,
    strict: bool,
    toolchain: str | None,
    target_name: str | None,
    developer_mode: bool,
    no_renewal_reminder: bool,
    show_version: bool,
) -> None:
    """Shared body for both production and developer Typer callbacks.

    Both registered callbacks below differ only in whether they expose
    `--developer-mode` to Typer. The production-build callback hardcodes
    ``developer_mode=False`` when calling this helper. The defense-in-depth
    runtime guard at the top of this function still fires for the
    developer-build callback if `--developer-mode` is passed in a build
    where ``_build_profile.is_developer_build()`` returns False (e.g. a
    locally-rebuilt wheel where someone re-added the flag but forgot to
    flip the build profile).
    """
    if show_version:
        typer.echo(_resolve_version())
        raise typer.Exit(code=0)

    if developer_mode and not _build_profile.is_developer_build():
        typer.secho(
            (
                "--developer-mode is not available in this build. "
                "It is enabled only in the internal-developer wheel; the "
                "production wheel always enforces real licensing. "
                "Run `memscope license activate <KEY>` to use commercial features."
            ),
            err=True,
            fg=typer.colors.RED,
        )
        raise typer.Exit(code=int(ExitCode.LICENSE_FAILURE))

    normalized_log_level = log_level.strip().lower()
    allowed_levels = {"error", "warning", "info", "debug", "trace"}
    if normalized_log_level not in allowed_levels:
        typer.secho(
            f"Invalid --log-level '{log_level}'. Expected one of: {', '.join(sorted(allowed_levels))}.",
            err=True,
            fg=typer.colors.RED,
        )
        raise typer.Exit(code=int(ExitCode.INPUT_OR_PARSING_ERROR))

    try:
        configure_logging(level=normalized_log_level, developer_mode=developer_mode)
    except ValueError as exc:
        typer.secho(str(exc), err=True, fg=typer.colors.RED)
        raise typer.Exit(code=int(ExitCode.INPUT_OR_PARSING_ERROR)) from exc

    ctx.obj = AppContext(
        options=GlobalOptions(
            config_path=config.strip() if config else None,
            log_level=normalized_log_level,
            strict=strict,
            toolchain=toolchain.strip() if toolchain else None,
            target_name=target_name.strip() if target_name else None,
            developer_mode=developer_mode,
            no_renewal_reminder=no_renewal_reminder,
        )
    )


if _DEV_MODE_AVAILABLE:

    @app.callback()
    def app_callback(
        ctx: typer.Context,
        config: Annotated[
            str | None,
            typer.Option("--config", help="Path to MemScope TOML configuration file."),
        ] = None,
        log_level: Annotated[
            str,
            typer.Option("--log-level", help="Log verbosity: error|warning|info|debug|trace."),
        ] = "info",
        strict: Annotated[
            bool,
            typer.Option("--strict", help="Enable strict command behavior."),
        ] = False,
        toolchain: Annotated[
            str | None,
            typer.Option("--toolchain", help="Toolchain hint override."),
        ] = None,
        target_name: Annotated[
            str | None,
            typer.Option("--target-name", help="Target name override."),
        ] = None,
        developer_mode: Annotated[
            bool,
            typer.Option(
                "--developer-mode",
                help="Enable explicit developer mode (watermarks reports and enables trace diagnostics).",
            ),
        ] = False,
        no_renewal_reminder: Annotated[
            bool,
            typer.Option(
                "--no-renewal-reminder",
                help="Suppress the console renewal-reminder banner shown within 14 days of license expiry.",
            ),
        ] = False,
        show_version: Annotated[
            bool,
            typer.Option("--version", help="Show MemScope version and exit.", is_eager=True),
        ] = False,
    ) -> None:
        _execute_callback(
            ctx,
            config=config,
            log_level=log_level,
            strict=strict,
            toolchain=toolchain,
            target_name=target_name,
            developer_mode=developer_mode,
            no_renewal_reminder=no_renewal_reminder,
            show_version=show_version,
        )

else:

    # Production-build callback: same parameters MINUS `developer_mode`.
    # mypy reads this as a redefinition of the developer-build callback
    # above, but only one branch executes per process — the type-system
    # complaint is structural, not a runtime concern.
    @app.callback()
    def app_callback(  # type: ignore[misc]
        ctx: typer.Context,
        config: Annotated[
            str | None,
            typer.Option("--config", help="Path to MemScope TOML configuration file."),
        ] = None,
        log_level: Annotated[
            str,
            typer.Option("--log-level", help="Log verbosity: error|warning|info|debug|trace."),
        ] = "info",
        strict: Annotated[
            bool,
            typer.Option("--strict", help="Enable strict command behavior."),
        ] = False,
        toolchain: Annotated[
            str | None,
            typer.Option("--toolchain", help="Toolchain hint override."),
        ] = None,
        target_name: Annotated[
            str | None,
            typer.Option("--target-name", help="Target name override."),
        ] = None,
        no_renewal_reminder: Annotated[
            bool,
            typer.Option(
                "--no-renewal-reminder",
                help="Suppress the console renewal-reminder banner shown within 14 days of license expiry.",
            ),
        ] = False,
        show_version: Annotated[
            bool,
            typer.Option("--version", help="Show MemScope version and exit.", is_eager=True),
        ] = False,
    ) -> None:
        _execute_callback(
            ctx,
            config=config,
            log_level=log_level,
            strict=strict,
            toolchain=toolchain,
            target_name=target_name,
            developer_mode=False,
            no_renewal_reminder=no_renewal_reminder,
            show_version=show_version,
        )


analyze.register_command(app, _session_from_context, _run_with_error_handling)
diff.register_command(app, _session_from_context, _run_with_error_handling)
validate.register_command(app, _session_from_context, _run_with_error_handling)
license.register_group(app, _session_from_context, _run_with_error_handling)
diagnostics.register_group(app, _session_from_context, _run_with_error_handling)
dev.register_group(app, _session_from_context, _run_with_error_handling)


def main() -> None:
    app()
