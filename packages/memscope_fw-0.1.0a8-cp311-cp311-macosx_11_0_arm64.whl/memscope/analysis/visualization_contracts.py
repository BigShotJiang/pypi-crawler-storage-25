"""Normalized visualization contracts for interactive report rendering."""

from __future__ import annotations

import re
from collections import defaultdict
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, cast

from memscope.analysis.padding_waste import PaddingWasteResult
from memscope.analysis.region_usage import RegionUsageResult
from memscope.domain import ComponentGroup, Issue, IssueCategory, SectionPlacement, SymbolEntry
from memscope.toolchains.base import NormalizedBuildModel

VISUALIZATION_SCHEMA_VERSION = "viz-1.0.0"
_MAX_RANGE_SYMBOLS = 24
_MAX_OWNERSHIP_ROWS = 200
_MAX_TREEMAP_SYMBOLS_PER_OBJECT = 40
_MAX_TREEMAP_OBJECTS_PER_COMPONENT = 80
_MAX_SANKEY_INPUT_NODES = 160
_MAX_SANKEY_OUTPUT_NODES = 180
_MAX_SANKEY_LINKS = 700
_MAX_GRAPH_COMPONENT_NODES = 24
_MAX_GRAPH_OBJECT_NODES = 120
_MAX_GRAPH_SYMBOL_NODES = 160
_MAX_GRAPH_LINKS = 1200
_STACK_TOKENS = ("stack", "stacks")
_HEAP_TOKENS = ("heap",)
_RESERVED_TOKENS = ("reserved",)
_PROTECTED_TOKENS = ("protect", "protected", "secure")
_RENDER_LAYOUT_MODE = "segmented-stacked"
_RENDER_MIN_HEIGHT_PX = 180
_RENDER_BASE_HEIGHT_PX = 220
_RENDER_MAX_HEIGHT_PX = 760


@dataclass(slots=True)
class _Interval:
    start: int
    end: int

    @property
    def size(self) -> int:
        return max(self.end - self.start + 1, 0)


def build_visualization_contract(
    model: NormalizedBuildModel,
    *,
    region_usage: dict[str, RegionUsageResult],
    padding_waste: PaddingWasteResult,
    components: list[ComponentGroup],
    issues: list[Issue],
    regressions: dict[str, object],
    features: Mapping[str, object] | None = None,
) -> dict[str, object]:
    feature_flags = _normalize_feature_flags(features)
    section_symbols = _symbols_by_section(model.symbols)
    section_map = {section.name: section for section in model.sections}
    section_to_region = {
        section.name: (section.execution_region or "").strip()
        for section in model.sections
        if section.name.strip()
    }
    issues_by_entity = _issues_by_entity(issues)
    section_baseline_deltas = _section_baseline_deltas(regressions)

    regions = []
    for region in sorted(model.memory_regions, key=lambda item: (item.start_address, item.end_address, item.name)):
        usage = region_usage.get(region.name)
        layout = _build_region_layout(
            region=region,
            sections=[section for section in model.sections if (section.execution_region or "") == region.name],
            section_symbols=section_symbols,
            issues_by_entity=issues_by_entity,
            section_baseline_deltas=section_baseline_deltas,
            stack_heap_hints=model.stack_heap_hints,
            usage=usage,
            padding_bytes=padding_waste.by_region.get(region.name, 0),
        )
        regions.append(layout)

    total_region_bytes = sum(
        max(int(cast(int, layout.get("size_bytes", 0))), 0) for layout in regions
    )
    for layout in regions:
        layout["render_hints"] = _build_region_render_hints(
            region=layout,
            total_region_bytes=total_region_bytes,
            regions_count=len(regions),
        )

    ownership = _build_ownership_views(
        symbols=model.symbols,
        section_map=section_map,
        section_to_region=section_to_region,
        components=components,
    )
    diff = _build_diff_view(regressions)
    relationships = _build_relationship_views(
        model=model,
        section_map=section_map,
        section_to_region=section_to_region,
        components=components,
        feature_flags=feature_flags,
    )

    return {
        "schema_version": VISUALIZATION_SCHEMA_VERSION,
        "address_units": "bytes",
        "address_format": "hex",
        "features": feature_flags,
        "regions": regions,
        "ownership": ownership,
        "diff": diff,
        "relationships": relationships,
        "policy_issue_index": _policy_issue_index(issues),
        "notes": [
            "All ranges are normalized for renderer consumption.",
            "Address values are absolute and toolchain-agnostic after normalization.",
            "Detailed attribution is included on section ranges for side-panel drilldown.",
        ],
    }


def _build_region_layout(
    *,
    region: Any,
    sections: list[SectionPlacement],
    section_symbols: dict[str, list[SymbolEntry]],
    issues_by_entity: dict[str, list[str]],
    section_baseline_deltas: dict[str, int],
    stack_heap_hints: dict[str, tuple[str, ...]],
    usage: RegionUsageResult | None,
    padding_bytes: int,
) -> dict[str, object]:
    region_start = region.start_address
    region_end = region.end_address
    region_size = max(int(region.size or 0), 0)

    sorted_sections = sorted(
        sections,
        key=lambda item: (item.vma, item.size, item.name),
    )
    used_intervals: list[_Interval] = []
    ranges: list[dict[str, object]] = []
    boundaries = {region_start, region_end}

    stack_hint_sections = {str(item) for item in stack_heap_hints.get("stack_sections", ())}
    heap_hint_sections = {str(item) for item in stack_heap_hints.get("heap_sections", ())}
    stack_bytes = 0
    heap_bytes = 0
    reserved_bytes = 0
    protected_bytes = 0

    for section in sorted_sections:
        section_start = section.vma
        section_size = max(section.size, 0)
        section_end = section_start + section_size - 1 if section_size > 0 else section_start
        kind = _section_kind(
            section.name,
            region.name,
            stack_hint_sections=stack_hint_sections,
            heap_hint_sections=heap_hint_sections,
        )
        if kind == "stack":
            stack_bytes += section_size
        elif kind == "heap":
            heap_bytes += section_size
        elif kind == "reserved":
            reserved_bytes += section_size
        elif kind == "protected":
            protected_bytes += section_size

        boundaries.add(section_start)
        boundaries.add(section_end)

        if section_size > 0:
            clipped = _clip_interval(
                _Interval(start=section_start, end=section_end),
                lower=region_start,
                upper=region_end,
            )
            if clipped is not None:
                used_intervals.append(clipped)

        role = _section_role(section.name, region.name)
        ranges.append(
            _section_range_payload(
                region_name=region.name,
                section=section,
                section_start=section_start,
                section_end=section_end,
                region_size=region_size,
                kind=kind,
                role=role,
                symbols=section_symbols.get(section.name, []),
                issue_ids=_merge_issue_ids(
                    issues_by_entity.get(section.name, []),
                    issues_by_entity.get(region.name, []),
                ),
                baseline_delta=section_baseline_deltas.get(section.name),
            )
        )

        if section.padding_before > 0:
            padding_start = section_start - section.padding_before
            padding_end = section_start - 1
            boundaries.add(padding_start)
            boundaries.add(padding_end)
            ranges.append(
                _synthetic_range_payload(
                    range_id=f"{region.name}:{section.name}:padding-before:{padding_start}",
                    kind="padding",
                    label=f"{section.name} (padding before)",
                    start=padding_start,
                    end=padding_end,
                    region_size=region_size,
                )
            )

        if section.padding_after > 0:
            padding_start = section_end + 1
            padding_end = section_end + section.padding_after
            boundaries.add(padding_start)
            boundaries.add(padding_end)
            ranges.append(
                _synthetic_range_payload(
                    range_id=f"{region.name}:{section.name}:padding-after:{padding_start}",
                    kind="padding",
                    label=f"{section.name} (padding after)",
                    start=padding_start,
                    end=padding_end,
                    region_size=region_size,
                )
            )

    free_intervals = _free_intervals(region_start, region_end, used_intervals)
    free_ranges = [
        _synthetic_range_payload(
            range_id=f"{region.name}:free:{interval.start}",
            kind="free",
            label="Free space",
            start=interval.start,
            end=interval.end,
            region_size=region_size,
        )
        for interval in free_intervals
    ]
    ranges.extend(free_ranges)

    used_bytes = usage.used_bytes if usage is not None else sum(max(section.size, 0) for section in sorted_sections)
    free_bytes = usage.free_bytes if usage is not None else sum(interval.size for interval in free_intervals)
    utilization_ratio = (
        usage.utilization_ratio
        if usage is not None
        else ((used_bytes / region_size) if region_size else 0.0)
    )
    overflow_bytes = usage.overflow_bytes if usage is not None else max(used_bytes - region_size, 0)

    return {
        "id": region.name,
        "name": region.name,
        "category": region.category.value,
        "start_address": region_start,
        "end_address": region_end,
        "size_bytes": region_size,
        "used_bytes": used_bytes,
        "free_bytes": free_bytes,
        "utilization_ratio": utilization_ratio,
        "overflow_bytes": overflow_bytes,
        "range_count": len(ranges),
        "density_score": round(len(ranges) / max(region_size / 4096.0, 1.0), 4),
        "stats": {
            "stack_bytes": stack_bytes,
            "heap_bytes": heap_bytes,
            "padding_bytes": max(int(padding_bytes), 0),
            "reserved_bytes": reserved_bytes,
            "protected_bytes": protected_bytes,
            "sections_count": len(sorted_sections),
            "free_ranges_count": len(free_intervals),
        },
        "boundaries": _boundary_payload(boundaries, region_start=region_start, region_end=region_end),
        "ranges": sorted(
            ranges,
            key=lambda item: (
                int(item.get("start_address", 0)),
                int(item.get("end_address", 0)),
                str(item.get("id", "")),
            ),
        ),
    }


def _build_region_render_hints(
    *,
    region: Mapping[str, object],
    total_region_bytes: int,
    regions_count: int,
) -> dict[str, object]:
    range_count = max(int(region.get("range_count", 0) or 0), 0)
    density_score = float(region.get("density_score", 0.0) or 0.0)
    region_size = max(int(region.get("size_bytes", 0) or 0), 0)

    range_bonus = _clamp((range_count - 40) * 1.2, 0.0, 360.0)
    density_bonus = _clamp((density_score - 1.0) * 140.0, 0.0, 220.0)
    preferred_height_px = int(
        round(
            _clamp(
                _RENDER_BASE_HEIGHT_PX + range_bonus + density_bonus,
                float(_RENDER_MIN_HEIGHT_PX),
                float(_RENDER_MAX_HEIGHT_PX),
            )
        )
    )

    proportional_total_height = max(regions_count * _RENDER_BASE_HEIGHT_PX, _RENDER_BASE_HEIGHT_PX)
    proportional_height_px = int(
        round(
            (region_size / max(total_region_bytes, 1))
            * proportional_total_height
        )
    )

    return {
        "layout_mode": _RENDER_LAYOUT_MODE,
        "min_height_px": _RENDER_MIN_HEIGHT_PX,
        "preferred_height_px": preferred_height_px,
        "scaled_for_readability": preferred_height_px > proportional_height_px,
    }


def _clamp(value: float, lower: float, upper: float) -> float:
    return min(max(value, lower), upper)


def _section_range_payload(
    *,
    region_name: str,
    section: SectionPlacement,
    section_start: int,
    section_end: int,
    region_size: int,
    kind: str,
    role: str | None,
    symbols: list[SymbolEntry],
    issue_ids: list[str],
    baseline_delta: int | None,
) -> dict[str, object]:
    owners = _owners_from_symbols(symbols)
    panel = _section_panel_data(
        section=section,
        symbols=symbols,
        owners=owners,
        issue_ids=issue_ids,
        baseline_delta=baseline_delta,
    )
    section_size = max(section.size, 0)
    return {
        "id": f"{region_name}:{section.name}:{section_start}",
        "kind": kind,
        "role": role,
        "label": section.name,
        "section_name": section.name,
        "execution_region": section.execution_region,
        "load_region": section.load_region,
        "start_address": section_start,
        "end_address": section_end,
        "size_bytes": section_size,
        "size_kib": section_size / 1024.0,
        "utilization_ratio_in_region": (section_size / region_size) if region_size > 0 else 0.0,
        "owners": owners,
        "top_symbols": [
            {
                "name": symbol.demangled_name or symbol.name,
                "size": symbol.size,
                "address": symbol.address,
            }
            for symbol in symbols[:_MAX_RANGE_SYMBOLS]
        ],
        "policy_issue_ids": issue_ids,
        "baseline_delta_bytes": baseline_delta,
        "panel": panel,
        "is_synthetic": False,
        "lod_group_key": None,
    }


def _section_panel_data(
    *,
    section: SectionPlacement,
    symbols: list[SymbolEntry],
    owners: dict[str, list[str]],
    issue_ids: list[str],
    baseline_delta: int | None,
) -> dict[str, object]:
    symbol_rows = [
        {
            "name": symbol.demangled_name or symbol.name,
            "size": symbol.size,
            "object_file": symbol.object_file,
            "archive": symbol.archive,
            "source_file": symbol.source_file,
        }
        for symbol in symbols[:_MAX_RANGE_SYMBOLS]
    ]
    return {
        "section": {
            "name": section.name,
            "execution_region": section.execution_region,
            "load_region": section.load_region,
            "vma": section.vma,
            "lma": section.lma,
            "size_bytes": section.size,
            "padding_before": section.padding_before,
            "padding_after": section.padding_after,
        },
        "symbol_breakdown": symbol_rows,
        "owners": owners,
        "baseline": {
            "delta_bytes": baseline_delta,
            "status": "available" if baseline_delta is not None else "unknown",
        },
        "policy": {
            "issue_ids": issue_ids,
            "violations_count": len(issue_ids),
        },
    }


def _build_ownership_views(
    *,
    symbols: list[SymbolEntry],
    section_map: dict[str, SectionPlacement],
    section_to_region: dict[str, str],
    components: list[ComponentGroup],
) -> dict[str, object]:
    object_to_component: dict[str, str] = {}
    for component in components:
        component_name = component.name.strip() or "Unassigned"
        for obj in component.objects:
            object_name = str(obj).strip()
            if object_name and object_name not in object_to_component:
                object_to_component[object_name] = component_name

    by_object: dict[str, dict[str, object]] = defaultdict(
        lambda: {
            "component_name": "Unassigned",
            "total_bytes": 0,
            "flash_bytes": 0,
            "ram_bytes": 0,
            "other_bytes": 0,
        }
    )
    by_symbol: list[dict[str, object]] = []
    by_component_object_symbol: dict[str, dict[str, list[dict[str, object]]]] = defaultdict(lambda: defaultdict(list))

    for symbol in symbols:
        size = max(symbol.size, 0)
        if size <= 0:
            continue
        owner = (
            symbol.object_file
            or symbol.archive
            or symbol.compilation_unit
            or symbol.source_file
            or "unknown_object"
        ).strip()
        component_name = object_to_component.get(owner, "Unassigned")
        section_name = (symbol.section_name or "").strip()
        region_name = section_to_region.get(section_name, "")
        section = section_map.get(section_name)
        category = _category_for_ownership(region_name=region_name, section=section)

        bucket = by_object[owner]
        bucket["component_name"] = component_name
        bucket["total_bytes"] = int(bucket["total_bytes"]) + size
        bucket[f"{category}_bytes"] = int(bucket[f"{category}_bytes"]) + size

        symbol_row = {
            "name": symbol.demangled_name or symbol.name,
            "size_bytes": size,
            "section_name": section_name or None,
            "object_file": symbol.object_file,
            "archive": symbol.archive,
            "source_file": symbol.source_file,
            "region_name": region_name or None,
            "component_name": component_name,
        }
        by_symbol.append(symbol_row)
        by_component_object_symbol[component_name][owner].append(symbol_row)

    object_rows = [
        {
            "name": name,
            "component_name": str(totals["component_name"]),
            "total_bytes": int(totals["total_bytes"]),
            "flash_bytes": int(totals["flash_bytes"]),
            "ram_bytes": int(totals["ram_bytes"]),
            "other_bytes": int(totals["other_bytes"]),
        }
        for name, totals in by_object.items()
    ]
    object_rows.sort(key=lambda item: int(item["total_bytes"]), reverse=True)

    by_symbol.sort(key=lambda item: int(item["size_bytes"]), reverse=True)
    component_rows_base = [
        {
            "name": component.name,
            "total_flash_bytes": int(component.total_flash),
            "total_ram_bytes": int(component.total_ram),
            "objects_count": len(component.objects),
            "symbols_count": len(component.symbols),
        }
        for component in sorted(components, key=lambda item: (item.total_flash + item.total_ram), reverse=True)
    ]
    component_totals_from_symbols: dict[str, int] = defaultdict(int)
    component_objects_from_symbols: dict[str, set[str]] = defaultdict(set)
    for symbol_row in by_symbol:
        component_name = str(symbol_row.get("component_name") or "Unassigned")
        component_totals_from_symbols[component_name] += int(symbol_row.get("size_bytes", 0))
        object_name = str(symbol_row.get("object_file") or symbol_row.get("archive") or "unknown_object")
        component_objects_from_symbols[component_name].add(object_name)

    component_rows_by_name = {str(item["name"]): item for item in component_rows_base}
    for component_name, total_bytes in component_totals_from_symbols.items():
        if component_name in component_rows_by_name:
            continue
        component_rows_base.append(
            {
                "name": component_name,
                "total_flash_bytes": int(total_bytes),
                "total_ram_bytes": 0,
                "objects_count": len(component_objects_from_symbols.get(component_name, set())),
                "symbols_count": sum(
                    1 for row in by_symbol if str(row.get("component_name") or "Unassigned") == component_name
                ),
            }
        )

    component_rows = sorted(
        component_rows_base,
        key=lambda item: (
            int(item.get("total_flash_bytes", 0)) + int(item.get("total_ram_bytes", 0)),
            str(item.get("name", "")),
        ),
        reverse=True,
    )

    treemap_hierarchy: list[dict[str, object]] = []
    for component_name, object_map in sorted(
        by_component_object_symbol.items(),
        key=lambda item: (
            sum(
                int(symbol_row.get("size_bytes", 0))
                for rows in item[1].values()
                for symbol_row in rows
            ),
            item[0],
        ),
        reverse=True,
    ):
        component_total = 0
        object_nodes: list[dict[str, object]] = []
        sorted_objects = sorted(
            object_map.items(),
            key=lambda item: (
                sum(int(symbol_row.get("size_bytes", 0)) for symbol_row in item[1]),
                item[0],
            ),
            reverse=True,
        )[:_MAX_TREEMAP_OBJECTS_PER_COMPONENT]
        for object_name, symbol_rows in sorted_objects:
            sorted_symbols = sorted(
                symbol_rows,
                key=lambda row: (int(row.get("size_bytes", 0)), str(row.get("name", ""))),
                reverse=True,
            )[:_MAX_TREEMAP_SYMBOLS_PER_OBJECT]
            object_total = sum(int(row.get("size_bytes", 0)) for row in sorted_symbols)
            component_total += object_total
            object_nodes.append(
                {
                    "name": object_name,
                    "value": object_total,
                    "children": [
                        {
                            "name": str(row.get("name", "")),
                            "value": int(row.get("size_bytes", 0)),
                            "section_name": row.get("section_name"),
                            "region_name": row.get("region_name"),
                            "source_file": row.get("source_file"),
                        }
                        for row in sorted_symbols
                    ],
                }
            )
        treemap_hierarchy.append(
            {
                "name": component_name,
                "value": component_total,
                "children": object_nodes,
            }
        )

    treemap_hierarchy = sorted(
        treemap_hierarchy,
        key=lambda item: (int(item.get("value", 0)), str(item.get("name", ""))),
        reverse=True,
    )

    return {
        "by_component": component_rows[:_MAX_OWNERSHIP_ROWS],
        "by_object": object_rows[:_MAX_OWNERSHIP_ROWS],
        "by_symbol": by_symbol[:_MAX_OWNERSHIP_ROWS],
        "treemap_hierarchy": treemap_hierarchy[:_MAX_OWNERSHIP_ROWS],
    }


def _build_diff_view(regressions: dict[str, object]) -> dict[str, object]:
    regions = regressions.get("regions")
    if not isinstance(regions, dict):
        regions = {}
    region_rows = []
    for region_name, values in sorted(regions.items()):
        if not isinstance(values, dict):
            continue
        region_rows.append(
            {
                "region_name": region_name,
                "current_ratio": float(values.get("current", 0.0)),
                "baseline_ratio": float(values.get("baseline", 0.0)),
                "delta_ratio": float(values.get("delta", 0.0)),
            }
        )

    impact_ranking = sorted(
        [
            {
                "name": str(row["region_name"]),
                "delta_ratio": float(row["delta_ratio"]),
                "delta_percent": float(row["delta_ratio"]) * 100.0,
                "current_ratio": float(row["current_ratio"]),
                "baseline_ratio": float(row["baseline_ratio"]),
                "direction": "growth" if float(row["delta_ratio"]) >= 0 else "shrink",
                "abs_delta_ratio": abs(float(row["delta_ratio"])),
            }
            for row in region_rows
        ],
        key=lambda item: (float(item["abs_delta_ratio"]), str(item["name"])),
        reverse=True,
    )
    top_growth = sorted(
        [item for item in impact_ranking if float(item["delta_ratio"]) > 0],
        key=lambda item: (float(item["delta_ratio"]), str(item["name"])),
        reverse=True,
    )
    top_shrink = sorted(
        [item for item in impact_ranking if float(item["delta_ratio"]) < 0],
        key=lambda item: (float(item["delta_ratio"]), str(item["name"])),
    )
    return {
        "status": str(regressions.get("status", "not_requested")),
        "flash_delta_bytes": int(regressions.get("flash_delta_bytes", 0) or 0),
        "ram_delta_bytes": int(regressions.get("ram_delta_bytes", 0) or 0),
        "regions": region_rows,
        "impact_ranking": impact_ranking[:_MAX_OWNERSHIP_ROWS],
        "top_growth": top_growth[:_MAX_OWNERSHIP_ROWS],
        "top_shrink": top_shrink[:_MAX_OWNERSHIP_ROWS],
    }


def _normalize_feature_flags(features: Mapping[str, object] | None) -> dict[str, bool]:
    if not isinstance(features, Mapping):
        return {
            "sankey_enabled": False,
            "relationship_graph_enabled": False,
        }
    sankey_enabled = features.get("sankey_enabled")
    relationship_graph_enabled = features.get("relationship_graph_enabled")
    return {
        "sankey_enabled": bool(sankey_enabled) if isinstance(sankey_enabled, bool) else False,
        "relationship_graph_enabled": bool(relationship_graph_enabled)
        if isinstance(relationship_graph_enabled, bool)
        else False,
    }


def _build_relationship_views(
    *,
    model: NormalizedBuildModel,
    section_map: dict[str, SectionPlacement],
    section_to_region: dict[str, str],
    components: list[ComponentGroup],
    feature_flags: Mapping[str, bool],
) -> dict[str, object]:
    relationships: dict[str, object] = {}
    if feature_flags.get("sankey_enabled", False):
        relationships["sankey"] = _build_sankey_view(
            model=model,
            section_map=section_map,
            section_to_region=section_to_region,
        )
    if feature_flags.get("relationship_graph_enabled", False):
        relationships["graph"] = _build_relationship_graph_view(
            model=model,
            section_to_region=section_to_region,
            components=components,
        )
    return relationships


def _build_sankey_view(
    *,
    model: NormalizedBuildModel,
    section_map: dict[str, SectionPlacement],
    section_to_region: dict[str, str],
) -> dict[str, object]:
    input_to_output: dict[tuple[str, str], int] = defaultdict(int)
    output_to_region: dict[tuple[str, str], int] = defaultdict(int)
    input_totals: dict[str, int] = defaultdict(int)
    output_totals: dict[str, int] = defaultdict(int)
    region_totals: dict[str, int] = defaultdict(int)
    source_basis = "symbols"

    for symbol in model.symbols:
        size = max(int(symbol.size), 0)
        if size <= 0:
            continue
        section_name = (symbol.section_name or "").strip()
        if not section_name:
            continue
        input_name = section_name
        output_name = section_name
        region_name = section_to_region.get(section_name, "").strip() or "UNASSIGNED_REGION"
        input_to_output[(input_name, output_name)] += size
        output_to_region[(output_name, region_name)] += size
        input_totals[input_name] += size
        output_totals[output_name] += size
        region_totals[region_name] += size

    if not input_to_output and not output_to_region:
        source_basis = "sections"
        for section in sorted(section_map.values(), key=lambda item: (item.name, item.vma)):
            size = max(int(section.size), 0)
            if size <= 0:
                continue
            output_name = section.name.strip() or "unnamed-output-section"
            input_name = (section.load_region or section.name or "unknown-input-section").strip()
            region_name = (section.execution_region or "").strip() or "UNASSIGNED_REGION"
            input_to_output[(input_name, output_name)] += size
            output_to_region[(output_name, region_name)] += size
            input_totals[input_name] += size
            output_totals[output_name] += size
            region_totals[region_name] += size

    selected_inputs = {
        name
        for name, _value in sorted(
            input_totals.items(),
            key=lambda item: (item[1], item[0]),
            reverse=True,
        )[:_MAX_SANKEY_INPUT_NODES]
    }
    selected_outputs = {
        name
        for name, _value in sorted(
            output_totals.items(),
            key=lambda item: (item[1], item[0]),
            reverse=True,
        )[:_MAX_SANKEY_OUTPUT_NODES]
    }
    selected_regions = set(region_totals)

    links: list[dict[str, object]] = []
    for (input_name, output_name), value in sorted(
        input_to_output.items(),
        key=lambda item: (item[1], item[0][0], item[0][1]),
        reverse=True,
    ):
        if value <= 0 or input_name not in selected_inputs or output_name not in selected_outputs:
            continue
        links.append(
            {
                "source": f"input::{input_name}",
                "target": f"output::{output_name}",
                "value": int(value),
                "value_bytes": int(value),
                "value_kib": float(value) / 1024.0,
                "kind": "input_to_output",
            }
        )

    for (output_name, region_name), value in sorted(
        output_to_region.items(),
        key=lambda item: (item[1], item[0][0], item[0][1]),
        reverse=True,
    ):
        if (
            value <= 0
            or output_name not in selected_outputs
            or region_name not in selected_regions
        ):
            continue
        links.append(
            {
                "source": f"output::{output_name}",
                "target": f"region::{region_name}",
                "value": int(value),
                "value_bytes": int(value),
                "value_kib": float(value) / 1024.0,
                "kind": "output_to_region",
            }
        )

    links = sorted(
        links,
        key=lambda item: (int(item["value_bytes"]), str(item["source"]), str(item["target"])),
        reverse=True,
    )
    links_total = len(links)
    links = links[:_MAX_SANKEY_LINKS]
    used_ids: set[str] = set()
    for link in links:
        used_ids.add(str(link["source"]))
        used_ids.add(str(link["target"]))

    nodes: list[dict[str, object]] = []
    for input_name, value in sorted(
        input_totals.items(),
        key=lambda item: (item[1], item[0]),
        reverse=True,
    ):
        node_id = f"input::{input_name}"
        if node_id not in used_ids:
            continue
        nodes.append(
            {
                "id": node_id,
                "name": node_id,
                "display_name": input_name,
                "kind": "input_section",
                "value_bytes": int(value),
            }
        )
    for output_name, value in sorted(
        output_totals.items(),
        key=lambda item: (item[1], item[0]),
        reverse=True,
    ):
        node_id = f"output::{output_name}"
        if node_id not in used_ids:
            continue
        nodes.append(
            {
                "id": node_id,
                "name": node_id,
                "display_name": output_name,
                "kind": "output_section",
                "value_bytes": int(value),
            }
        )
    for region_name, value in sorted(
        region_totals.items(),
        key=lambda item: (item[1], item[0]),
        reverse=True,
    ):
        node_id = f"region::{region_name}"
        if node_id not in used_ids:
            continue
        nodes.append(
            {
                "id": node_id,
                "name": node_id,
                "display_name": region_name,
                "kind": "memory_region",
                "value_bytes": int(value),
            }
        )

    kind_order = {"input_section": 0, "output_section": 1, "memory_region": 2}
    nodes = sorted(
        nodes,
        key=lambda item: (
            kind_order.get(str(item.get("kind", "")), 99),
            int(item.get("value_bytes", 0)),
            str(item.get("display_name", "")),
        ),
        reverse=False,
    )

    return {
        "nodes": nodes,
        "links": links,
        "source_basis": source_basis,
        "truncated": (
            len(input_totals) > _MAX_SANKEY_INPUT_NODES
            or len(output_totals) > _MAX_SANKEY_OUTPUT_NODES
            or links_total > _MAX_SANKEY_LINKS
        ),
        "stats": {
            "inputs_count": len(input_totals),
            "outputs_count": len(output_totals),
            "regions_count": len(region_totals),
            "links_count": links_total,
            "rendered_nodes_count": len(nodes),
            "rendered_links_count": len(links),
        },
    }


def _build_relationship_graph_view(
    *,
    model: NormalizedBuildModel,
    section_to_region: dict[str, str],
    components: list[ComponentGroup],
) -> dict[str, object]:
    object_to_component: dict[str, str] = {}
    for component in components:
        component_name = component.name.strip() or "Unassigned"
        for obj in component.objects:
            object_name = str(obj).strip()
            if object_name and object_name not in object_to_component:
                object_to_component[object_name] = component_name

    object_totals: dict[str, int] = defaultdict(int)
    object_region_bytes: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
    object_symbols: dict[str, list[SymbolEntry]] = defaultdict(list)
    for symbol in model.symbols:
        size = max(int(symbol.size), 0)
        if size <= 0:
            continue
        owner = (
            symbol.object_file
            or symbol.archive
            or symbol.compilation_unit
            or symbol.source_file
            or "unknown_object"
        ).strip()
        object_totals[owner] += size
        section_name = (symbol.section_name or "").strip()
        region_name = section_to_region.get(section_name, "").strip() or "UNASSIGNED_REGION"
        object_region_bytes[owner][region_name] += size
        object_symbols[owner].append(symbol)

    sorted_objects = sorted(
        object_totals.items(),
        key=lambda item: (item[1], item[0]),
        reverse=True,
    )
    selected_objects = {name for name, _size in sorted_objects[:_MAX_GRAPH_OBJECT_NODES]}

    component_totals: dict[str, int] = defaultdict(int)
    for object_name in selected_objects:
        component_name = object_to_component.get(object_name, "Unassigned")
        component_totals[component_name] += int(object_totals.get(object_name, 0))
    selected_components = {
        name
        for name, _size in sorted(
            component_totals.items(),
            key=lambda item: (item[1], item[0]),
            reverse=True,
        )[:_MAX_GRAPH_COMPONENT_NODES]
    }

    symbol_rows: list[tuple[str, SymbolEntry]] = []
    for object_name in selected_objects:
        for symbol in object_symbols.get(object_name, []):
            symbol_rows.append((object_name, symbol))
    symbol_rows = sorted(
        symbol_rows,
        key=lambda item: (
            int(item[1].size),
            item[0],
            item[1].demangled_name or item[1].name,
        ),
        reverse=True,
    )[:_MAX_GRAPH_SYMBOL_NODES]

    nodes_by_id: dict[str, dict[str, object]] = {}
    links: list[dict[str, object]] = []

    def upsert_node(
        *,
        node_id: str,
        display_name: str,
        kind: str,
        value_bytes: int,
    ) -> None:
        existing = nodes_by_id.get(node_id)
        if existing is None:
            nodes_by_id[node_id] = {
                "id": node_id,
                "name": node_id,
                "display_name": display_name,
                "kind": kind,
                "value_bytes": int(value_bytes),
            }
            return
        existing["value_bytes"] = max(int(existing.get("value_bytes", 0)), int(value_bytes))

    for object_name in selected_objects:
        object_total = int(object_totals.get(object_name, 0))
        if object_total <= 0:
            continue
        component_name = object_to_component.get(object_name, "Unassigned")
        if component_name not in selected_components:
            component_name = "Unassigned"
            selected_components.add(component_name)

        component_id = f"component::{component_name}"
        object_id = f"object::{object_name}"
        upsert_node(
            node_id=component_id,
            display_name=component_name,
            kind="component",
            value_bytes=int(component_totals.get(component_name, object_total)),
        )
        upsert_node(
            node_id=object_id,
            display_name=object_name,
            kind="object",
            value_bytes=object_total,
        )
        links.append(
            {
                "source": component_id,
                "target": object_id,
                "value": object_total,
                "value_bytes": object_total,
                "kind": "component_to_object",
            }
        )

        for region_name, region_bytes in sorted(
            object_region_bytes.get(object_name, {}).items(),
            key=lambda item: (item[1], item[0]),
            reverse=True,
        ):
            if region_bytes <= 0:
                continue
            region_id = f"region::{region_name}"
            upsert_node(
                node_id=region_id,
                display_name=region_name,
                kind="memory_region",
                value_bytes=region_bytes,
            )
            links.append(
                {
                    "source": object_id,
                    "target": region_id,
                    "value": int(region_bytes),
                    "value_bytes": int(region_bytes),
                    "kind": "object_to_region",
                }
            )

    for symbol_index, (object_name, symbol) in enumerate(symbol_rows):
        object_id = f"object::{object_name}"
        if object_id not in nodes_by_id:
            continue
        symbol_size = max(int(symbol.size), 0)
        if symbol_size <= 0:
            continue
        symbol_name = (symbol.demangled_name or symbol.name or "unnamed_symbol").strip()
        symbol_id = f"symbol::{object_name}::{symbol_name}::{symbol_index}"
        upsert_node(
            node_id=symbol_id,
            display_name=symbol_name,
            kind="symbol",
            value_bytes=symbol_size,
        )
        links.append(
            {
                "source": object_id,
                "target": symbol_id,
                "value": symbol_size,
                "value_bytes": symbol_size,
                "kind": "object_to_symbol",
            }
        )

    links = sorted(
        links,
        key=lambda item: (int(item.get("value_bytes", 0)), str(item.get("source", "")), str(item.get("target", ""))),
        reverse=True,
    )
    links_total = len(links)
    links = links[:_MAX_GRAPH_LINKS]

    linked_nodes: set[str] = set()
    for link in links:
        linked_nodes.add(str(link.get("source", "")))
        linked_nodes.add(str(link.get("target", "")))
    nodes = [
        node
        for node_id, node in nodes_by_id.items()
        if node_id in linked_nodes
    ]
    kind_order = {
        "component": 0,
        "object": 1,
        "memory_region": 2,
        "symbol": 3,
    }
    nodes = sorted(
        nodes,
        key=lambda item: (
            kind_order.get(str(item.get("kind", "")), 99),
            -int(item.get("value_bytes", 0)),
            str(item.get("display_name", "")),
        ),
    )

    return {
        "nodes": nodes,
        "links": links,
        "truncated": (
            len(sorted_objects) > _MAX_GRAPH_OBJECT_NODES
            or len(symbol_rows) >= _MAX_GRAPH_SYMBOL_NODES
            or links_total > _MAX_GRAPH_LINKS
        ),
        "stats": {
            "objects_count": len(sorted_objects),
            "components_count": len(component_totals),
            "symbols_count": len(symbol_rows),
            "links_count": links_total,
            "rendered_nodes_count": len(nodes),
            "rendered_links_count": len(links),
        },
    }


def _section_kind(
    section_name: str,
    region_name: str,
    *,
    stack_hint_sections: set[str],
    heap_hint_sections: set[str],
) -> str:
    normalized_section = section_name.lower()
    normalized_region = region_name.lower()
    if section_name in stack_hint_sections or _contains_token(normalized_section, _STACK_TOKENS):
        return "stack"
    if section_name in heap_hint_sections or _contains_token(normalized_section, _HEAP_TOKENS):
        return "heap"
    if _contains_token(normalized_section, _PROTECTED_TOKENS) or _contains_token(normalized_region, _PROTECTED_TOKENS):
        return "protected"
    if _contains_token(normalized_section, _RESERVED_TOKENS) or _contains_token(normalized_region, _RESERVED_TOKENS):
        return "reserved"
    return "section"


_ROLE_VECTOR_TOKENS = ("vector", "intvec", "isr_vector", "isr_table", "reset_vector", ".vectors")
_ROLE_BSS_TOKENS = (".bss", "$$zi", "$zi$", ".sbss", ".tbss", ".noinit")
_ROLE_DATA_TOKENS = (".data", "$$rw", "$rw$", ".sdata", ".tdata", ".rwdata", ".initdata")
_ROLE_RODATA_TOKENS = (".rodata", ".srodata", ".rdata", ".const", "$$ro$$ro", "$ro$ro", ".init_array", ".fini_array")
_ROLE_TEXT_TOKENS = (".text", ".init", ".fini", ".plt", "$$ro$$code", "$ro$code")
_ROLE_HEAP_TOKENS = ("heap",)
_ROLE_STACK_TOKENS = ("stack", "cstack")


def _section_role(section_name: str, region_name: str = "") -> str | None:
    """Heuristic mapping from section/region name to a logical memory role.

    Returns one of: vectors, bss, data, rodata, text, heap, stack, or None when
    the section name does not match any well-known pattern. Detection is purely
    name-based and works across GNU, Keil scatter, and IAR ICF outputs.
    """
    s = (section_name or "").strip().lower()
    r = (region_name or "").strip().lower()
    if not s and not r:
        return None
    # Vectors first — usually a small named section with very specific tokens.
    if _contains_token(s, _ROLE_VECTOR_TOKENS):
        return "vectors"
    # Stack and heap can be either explicit sections or region-named regions.
    if _contains_token(s, _ROLE_STACK_TOKENS) or s in {"cstack", "stack_mem"}:
        return "stack"
    if s in {"heap", "heap_mem"} or _contains_token(s, _ROLE_HEAP_TOKENS):
        return "heap"
    # BSS variants (incl. Keil ZI / zero-init).
    if s == "bss" or s == "common" or _contains_token(s, _ROLE_BSS_TOKENS):
        return "bss"
    # Initialized data.
    if _contains_token(s, _ROLE_RODATA_TOKENS):
        return "rodata"
    if _contains_token(s, _ROLE_DATA_TOKENS):
        return "data"
    # Code last — many GNU sections start with .text.* and we only get here if
    # nothing more specific matched.
    if _contains_token(s, _ROLE_TEXT_TOKENS):
        return "text"
    # Region-level fallbacks for sections without a recognizable name.
    if _contains_token(r, _ROLE_STACK_TOKENS):
        return "stack"
    if _contains_token(r, _ROLE_HEAP_TOKENS):
        return "heap"
    return None


def _contains_token(value: str, tokens: tuple[str, ...]) -> bool:
    return any(token in value for token in tokens)


def _symbols_by_section(symbols: list[SymbolEntry]) -> dict[str, list[SymbolEntry]]:
    grouped: dict[str, list[SymbolEntry]] = defaultdict(list)
    for symbol in symbols:
        section_name = (symbol.section_name or "").strip()
        if not section_name:
            continue
        grouped[section_name].append(symbol)

    for section_name, items in grouped.items():
        grouped[section_name] = sorted(
            items,
            key=lambda symbol: (-symbol.size, (symbol.address or 0), symbol.name),
        )
    return grouped


def _owners_from_symbols(symbols: list[SymbolEntry]) -> dict[str, list[str]]:
    objects = sorted({symbol.object_file for symbol in symbols if symbol.object_file})
    archives = sorted({symbol.archive for symbol in symbols if symbol.archive})
    sources = sorted({symbol.source_file for symbol in symbols if symbol.source_file})
    return {
        "objects": [str(item) for item in objects[:_MAX_RANGE_SYMBOLS]],
        "archives": [str(item) for item in archives[:_MAX_RANGE_SYMBOLS]],
        "sources": [str(item) for item in sources[:_MAX_RANGE_SYMBOLS]],
    }


def _issues_by_entity(issues: list[Issue]) -> dict[str, list[str]]:
    by_entity: dict[str, list[str]] = defaultdict(list)
    for issue in issues:
        for entity in issue.affected_entities:
            key = str(entity).strip()
            if not key:
                continue
            by_entity[key].append(issue.id)
    return {key: sorted(set(values)) for key, values in by_entity.items()}


def _policy_issue_index(issues: list[Issue]) -> dict[str, dict[str, object]]:
    return {
        issue.id: {
            "id": issue.id,
            "severity": issue.severity.value,
            "category": issue.category.value,
            "title": issue.title,
            "description": issue.description,
            "affected_entities": list(issue.affected_entities),
            "is_policy_violation": issue.category in {
                IssueCategory.POLICY,
                IssueCategory.RESERVED,
                IssueCategory.OVERFLOW,
            },
        }
        for issue in sorted(issues, key=lambda item: item.id)
    }


def _section_baseline_deltas(regressions: dict[str, object]) -> dict[str, int]:
    sections = regressions.get("sections")
    if not isinstance(sections, dict):
        return {}
    deltas: dict[str, int] = {}
    for section_name, values in sections.items():
        if not isinstance(values, dict):
            continue
        delta = values.get("delta_bytes")
        if isinstance(delta, bool):
            continue
        if isinstance(delta, (int, float)):
            deltas[str(section_name)] = int(delta)
    return deltas


def _merge_issue_ids(*groups: list[str]) -> list[str]:
    merged: set[str] = set()
    for group in groups:
        merged.update(str(item) for item in group)
    return sorted(merged)


def _free_intervals(start: int, end: int, occupied: list[_Interval]) -> list[_Interval]:
    if end < start:
        return []
    if not occupied:
        return [_Interval(start=start, end=end)]

    merged: list[_Interval] = []
    for interval in sorted(occupied, key=lambda item: (item.start, item.end)):
        if not merged:
            merged.append(_Interval(start=interval.start, end=interval.end))
            continue
        previous = merged[-1]
        if interval.start <= previous.end + 1:
            previous.end = max(previous.end, interval.end)
        else:
            merged.append(_Interval(start=interval.start, end=interval.end))

    free: list[_Interval] = []
    cursor = start
    for interval in merged:
        if interval.start > cursor:
            free.append(_Interval(start=cursor, end=interval.start - 1))
        cursor = max(cursor, interval.end + 1)
    if cursor <= end:
        free.append(_Interval(start=cursor, end=end))
    return [interval for interval in free if interval.size > 0]


def _clip_interval(interval: _Interval, *, lower: int, upper: int) -> _Interval | None:
    start = max(interval.start, lower)
    end = min(interval.end, upper)
    if end < start:
        return None
    return _Interval(start=start, end=end)


def _synthetic_range_payload(
    *,
    range_id: str,
    kind: str,
    label: str,
    start: int,
    end: int,
    region_size: int,
) -> dict[str, object]:
    size = max(end - start + 1, 0)
    return {
        "id": range_id,
        "kind": kind,
        "label": label,
        "section_name": None,
        "execution_region": None,
        "load_region": None,
        "start_address": start,
        "end_address": end,
        "size_bytes": size,
        "size_kib": size / 1024.0,
        "utilization_ratio_in_region": (size / region_size) if region_size > 0 else 0.0,
        "owners": {"objects": [], "archives": [], "sources": []},
        "top_symbols": [],
        "policy_issue_ids": [],
        "baseline_delta_bytes": None,
        "panel": {},
        "is_synthetic": True,
        "lod_group_key": f"{kind}:{start}",
    }


def _boundary_payload(boundaries: set[int], *, region_start: int, region_end: int) -> list[dict[str, object]]:
    result: list[dict[str, object]] = []
    ordered = sorted(boundaries)
    for address in ordered:
        kind = "internal"
        label = "boundary"
        if address == region_start:
            kind = "start"
            label = "region start"
        elif address == region_end:
            kind = "end"
            label = "region end"
        result.append(
            {
                "address": int(address),
                "kind": kind,
                "label": label,
            }
        )
    return result


def _category_for_ownership(*, region_name: str, section: SectionPlacement | None) -> str:
    if not section:
        return "other"

    section_name = section.name.lower()
    if section.execution_region and re.search(r"flash|rom", section.execution_region, re.IGNORECASE):
        return "flash"
    if section.execution_region and re.search(r"ram|sram|dtcm|itcm|tcm", section.execution_region, re.IGNORECASE):
        return "ram"
    if "text" in section_name or "rodata" in section_name:
        return "flash"
    if any(token in section_name for token in ("data", "bss", "heap", "stack", "noinit")):
        return "ram"
    return "other"
