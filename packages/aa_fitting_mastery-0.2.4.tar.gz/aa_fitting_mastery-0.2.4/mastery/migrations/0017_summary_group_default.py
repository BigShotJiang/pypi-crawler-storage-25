from django.db import migrations, models
from django.db.models import Q


class Migration(migrations.Migration):

    dependencies = [
        ("mastery", "0016_cascade_external_plugin_foreign_keys"),
    ]

    operations = [
        migrations.AddField(
            model_name="summaryaudiencegroup",
            name="is_default",
            field=models.BooleanField(default=False),
        ),
        migrations.AddConstraint(
            model_name="summaryaudiencegroup",
            constraint=models.UniqueConstraint(
                condition=Q(is_default=True),
                fields=("is_default",),
                name="summary_audience_group_single_default",
            ),
        ),
    ]


