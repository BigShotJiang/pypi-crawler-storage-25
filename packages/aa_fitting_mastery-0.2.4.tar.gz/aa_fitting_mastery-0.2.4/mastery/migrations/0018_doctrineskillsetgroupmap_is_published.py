"""Migration: add is_published field to DoctrineSkillSetGroupMap."""
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('mastery', '0017_summary_group_default'),
    ]

    operations = [
        migrations.AddField(
            model_name='doctrineskillsetgroupmap',
            name='is_published',
            field=models.BooleanField(
                db_index=True,
                default=False,
                help_text=(
                    'When enabled, this doctrine is visible in summary and pilot views. '
                    'Requires at least one approved fitting to appear.'
                ),
                verbose_name='published',
            ),
        ),
    ]

