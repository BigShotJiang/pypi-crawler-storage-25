from django.test import TestCase
from django.utils import timezone
from eve_sde.models import ItemType
from fittings.models import Doctrine, Fitting
from memberaudit.models import SkillSet, SkillSetGroup

from mastery.models import (
    DoctrineSkillSetGroupMap,
    DoctrineSkillSnapshot,
    FittingSkillControl,
    FittingSkillsetMap,
)


class TestExternalFkCascades(TestCase):
    def setUp(self):
        now = timezone.now()
        self.skillset_group = SkillSetGroup.objects.create(
            name="Cascade Group",
            description="",
        )
        self.skillset = SkillSet.objects.create(
            name="Cascade SkillSet",
            description="",
        )
        self.doctrine = Doctrine.objects.create(
            name="Cascade Doctrine",
            description="Cascade doctrine for integration test",
            created=now,
        )
        self.ship_type = ItemType.objects.create(id=990001, name="Cascade Ship")
        self.skill_type = ItemType.objects.create(id=990002, name="Cascade Skill")
        self.fitting = Fitting.objects.create(
            name="Cascade Fit",
            description="Cascade fitting for integration test",
            ship_type=self.ship_type,
            ship_type_type_id=self.ship_type.id,
        )
        self.doctrine_map = DoctrineSkillSetGroupMap.objects.create(
            doctrine=self.doctrine,
            skillset_group=self.skillset_group,
        )
        self.fitting_map = FittingSkillsetMap.objects.create(
            doctrine_map=self.doctrine_map,
            fitting=self.fitting,
            skillset=self.skillset,
        )
        self.fitting_control = FittingSkillControl.objects.create(
            fitting=self.fitting,
            skill_type=self.skill_type,
        )
        self.snapshot = DoctrineSkillSnapshot.objects.create(
            doctrine=self.doctrine,
            doctrine_name=self.doctrine.name,
            fitting=self.fitting,
            fitting_name=self.fitting.name,
            ship_type=self.ship_type,
            ship_name=self.ship_type.name,
            skill_type=self.skill_type,
            required_level=1,
            recommended_level=1,
        )

    def test_deleting_doctrine_cascades_mastery_dependents(self):
        self.doctrine.delete()

        self.assertFalse(DoctrineSkillSetGroupMap.objects.filter(pk=self.doctrine_map.pk).exists())
        self.assertFalse(FittingSkillsetMap.objects.filter(pk=self.fitting_map.pk).exists())
        self.assertFalse(DoctrineSkillSnapshot.objects.filter(pk=self.snapshot.pk).exists())

    def test_deleting_skillset_group_cascades_doctrine_map_tree(self):
        self.skillset_group.delete()

        self.assertFalse(DoctrineSkillSetGroupMap.objects.filter(pk=self.doctrine_map.pk).exists())
        self.assertFalse(FittingSkillsetMap.objects.filter(pk=self.fitting_map.pk).exists())

    def test_deleting_fitting_cascades_fitting_bound_rows(self):
        self.fitting.delete()

        self.assertFalse(FittingSkillsetMap.objects.filter(pk=self.fitting_map.pk).exists())
        self.assertFalse(FittingSkillControl.objects.filter(pk=self.fitting_control.pk).exists())
        self.assertFalse(DoctrineSkillSnapshot.objects.filter(pk=self.snapshot.pk).exists())

    def test_deleting_skillset_cascades_fitting_skillset_map(self):
        self.skillset.delete()

        self.assertFalse(FittingSkillsetMap.objects.filter(pk=self.fitting_map.pk).exists())

