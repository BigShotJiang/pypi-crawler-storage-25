from types import SimpleNamespace
from typing import Any, cast

from django.db import models
from django.test import SimpleTestCase

from mastery.models.doctrine_skill_snapshot import DoctrineSkillSnapshot
from mastery.models.doctrine_skillsetgroup_map import DoctrineSkillSetGroupMap
from mastery.models.fitting_skill_control import FittingSkillControl
from mastery.models.fitting_skillset_map import FittingSkillsetMap


def _stub(**attrs: Any) -> SimpleNamespace:
    obj = SimpleNamespace()
    for key, value in attrs.items():
        setattr(obj, key, value)
    return obj


def _named(name: str) -> SimpleNamespace:
    return _stub(name=name)


class TestModelLabels(SimpleTestCase):
    def test_fitting_skillset_map_str_prefers_readable_names(self):
        obj = _stub(fitting=_named("Ferox Fleet"), skillset=_named("Ferox Fleet"), pk=1)

        self.assertEqual(FittingSkillsetMap.__str__(cast(Any, obj)), "Ferox Fleet")

    def test_fitting_skillset_map_str_disambiguates_with_skillset(self):
        obj = _stub(
            fitting=_named("Ferox Fleet"),
            skillset=_named("Ferox Fleet Doctrine"),
            pk=1,
        )

        self.assertEqual(
            FittingSkillsetMap.__str__(cast(Any, obj)),
            "Ferox Fleet [Ferox Fleet Doctrine]",
        )

    def test_doctrine_skillsetgroup_map_str_prefers_readable_names(self):
        obj = _stub(doctrine=_named("Shield HAC"), skillset_group=_named("Shield HAC"), pk=2)

        self.assertEqual(DoctrineSkillSetGroupMap.__str__(cast(Any, obj)), "Shield HAC")

    def test_doctrine_skillsetgroup_map_str_disambiguates_with_group(self):
        obj = _stub(
            doctrine=_named("Shield HAC"),
            skillset_group=_named("Shield HAC Group"),
            pk=2,
        )

        self.assertEqual(
            DoctrineSkillSetGroupMap.__str__(cast(Any, obj)),
            "Shield HAC [Shield HAC Group]",
        )

    def test_doctrine_skillsetgroup_map_doctrine_fk_cascades_on_delete(self):
        doctrine_field = DoctrineSkillSetGroupMap._meta.get_field("doctrine")

        self.assertIs(doctrine_field.remote_field.on_delete, models.CASCADE)

    def test_doctrine_skillsetgroup_map_skillset_group_fk_cascades_on_delete(self):
        group_field = DoctrineSkillSetGroupMap._meta.get_field("skillset_group")

        self.assertIs(group_field.remote_field.on_delete, models.CASCADE)

    def test_fitting_skillset_map_external_fks_cascade_on_delete(self):
        fitting_field = FittingSkillsetMap._meta.get_field("fitting")
        skillset_field = FittingSkillsetMap._meta.get_field("skillset")

        self.assertIs(fitting_field.remote_field.on_delete, models.CASCADE)
        self.assertIs(skillset_field.remote_field.on_delete, models.CASCADE)

    def test_fitting_skill_control_fitting_fk_cascades_on_delete(self):
        fitting_field = FittingSkillControl._meta.get_field("fitting")

        self.assertIs(fitting_field.remote_field.on_delete, models.CASCADE)

    def test_doctrine_skill_snapshot_external_fks_cascade_on_delete(self):
        doctrine_field = DoctrineSkillSnapshot._meta.get_field("doctrine")
        fitting_field = DoctrineSkillSnapshot._meta.get_field("fitting")

        self.assertIs(doctrine_field.remote_field.on_delete, models.CASCADE)
        self.assertIs(fitting_field.remote_field.on_delete, models.CASCADE)

