# sheaffusion

`sheaffusion` is the official Python package namespace for lightweight
multimodal fusion helpers used by the SheafLab project.

This initial public release provides weighted modality scoring, normalized
blends, and compact fusion summaries for small modality sets.

