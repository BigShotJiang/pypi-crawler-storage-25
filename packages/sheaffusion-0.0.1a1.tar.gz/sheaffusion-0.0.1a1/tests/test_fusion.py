import unittest

from sheaffusion import FusionInput, blend_scores, normalize_weights, top_modality


class FusionTests(unittest.TestCase):
    def setUp(self) -> None:
        self.inputs = [
            FusionInput("text", 0.7, 2.0),
            FusionInput("vision", 0.9, 1.0),
        ]

    def test_normalize_weights(self) -> None:
        weights = [item.weight for item in normalize_weights(self.inputs)]
        self.assertAlmostEqual(sum(weights), 1.0)

    def test_blend_scores(self) -> None:
        self.assertGreater(blend_scores(self.inputs), 0.0)

    def test_top_modality(self) -> None:
        self.assertEqual(top_modality(self.inputs), "text")

