def project_info() -> dict[str, str]:
    return {
        "name": "sheaffusion",
        "stage": "bootstrap",
        "homepage": "https://sheaflab.com",
        "repository": "https://github.com/SheafLab/sheaffusion-python",
    }

