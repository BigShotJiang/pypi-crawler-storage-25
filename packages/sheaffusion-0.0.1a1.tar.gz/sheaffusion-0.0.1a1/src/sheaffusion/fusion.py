from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class FusionInput:
    modality: str
    score: float
    weight: float


def normalize_weights(inputs: list[FusionInput]) -> list[FusionInput]:
    total = sum(item.weight for item in inputs) or 1.0
    return [FusionInput(item.modality, item.score, item.weight / total) for item in inputs]


def blend_scores(inputs: list[FusionInput]) -> float:
    return sum(item.score * item.weight for item in normalize_weights(inputs))


def top_modality(inputs: list[FusionInput]) -> str | None:
    if not inputs:
        return None
    return max(inputs, key=lambda item: item.score * item.weight).modality

