from functools import cached_property

import babel


RTL_LANGUAGES = [
    'fa',
    'ar',
    'he',
    'ps',
    'sd',
    'ur',
    'yi',
    'dv',
    'ha',
    'ks',
    'ku',
    'tk',
    'ug',
]


class Locale(babel.Locale):
    @cached_property
    def rtl(self):
        return self.language in RTL_LANGUAGES

    @classmethod
    def parse(cls, locale):
        return super().parse(locale.replace('-', '_'))
