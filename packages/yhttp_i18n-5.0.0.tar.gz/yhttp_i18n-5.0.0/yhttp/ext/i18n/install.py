from pymlconf import Meld

from .cli import I18nCLI
from .middlewares import middleware


DEFAULT_SETTINGS = '''
domain: messages
defaultlocale: en-US
localedirectory: i18n
'''


def install(app, rewriter=None):
    app.cliarguments.append(I18nCLI)
    app.settings |= Meld(DEFAULT_SETTINGS, root='i18n')

    if rewriter:
        rewriter.configure(app.settings.i18n)
        app.request_middlewares.append(rewriter)

    app.request_middlewares.append(middleware)
