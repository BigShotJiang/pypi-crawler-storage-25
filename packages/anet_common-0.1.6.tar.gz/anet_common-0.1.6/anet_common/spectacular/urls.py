from django.urls import path
from drf_spectacular.views import (
    SpectacularAPIView,
    SpectacularRedocView,
    SpectacularSwaggerView,
)

# Consumer loyiha urls.py ga shu urlpatterns ni include qiladi:
#
#   from anet_common.spectacular.urls import urlpatterns as spectacular_urls
#
#   urlpatterns = [
#       ...
#       path("api/", include(spectacular_urls)),
#   ]
#
# Natija:
#   GET /api/schema/            — OpenAPI JSON/YAML schema
#   GET /api/schema/swagger-ui/ — Swagger UI (lokal sidecar statikasidan)
#   GET /api/schema/redoc/      — ReDoc     (lokal sidecar statikasidan)

urlpatterns = [
    path(
        "schema/",
        SpectacularAPIView.as_view(),
        name="schema",
    ),
    path(
        "schema/swagger-ui/",
        SpectacularSwaggerView.as_view(url_name="schema"),
        name="swagger-ui",
    ),
    path(
        "schema/redoc/",
        SpectacularRedocView.as_view(url_name="schema"),
        name="redoc",
    ),
]
