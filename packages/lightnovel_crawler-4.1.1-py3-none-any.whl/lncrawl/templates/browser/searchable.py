from abc import abstractmethod
from typing import Generator

from ...core.soup import PageSoup
from ...exceptions import FallbackToBrowser
from ...models import SearchResult
from ..soup.searchable import SearchableSoupTemplate
from .general import GeneralBrowserTemplate


class SearchableBrowserTemplate(GeneralBrowserTemplate, SearchableSoupTemplate):
    """Attempts to crawl using cloudscraper first, if failed use the browser."""

    def search_novel_in_soup(self, query: str) -> Generator[SearchResult, None, None]:
        tags = self.select_search_items(query)
        yield from self.process_search_results(tags)

    def search_novel_in_browser(self, query: str) -> Generator[SearchResult, None, None]:
        tags = self.select_search_items_in_browser(query)
        yield from self.process_search_results_in_browser(tags)

    def process_search_results_in_browser(
        self, tags: Generator[PageSoup, None, None]
    ) -> Generator[SearchResult, None, None]:
        """Process novel item tag and generates search results from the browser"""
        count = 0
        for tag in tags:
            count += 1
            if count == 10:
                break
            yield self.parse_search_item_in_browser(tag)

    @abstractmethod
    def select_search_items(self, query: str) -> Generator[PageSoup, None, None]:
        raise FallbackToBrowser()

    def select_search_items_in_browser(self, query: str) -> Generator[PageSoup, None, None]:
        """Select novel items found by the query using the browser"""
        yield from self.select_search_items(query)

    def parse_search_item_in_browser(self, tag: PageSoup) -> SearchResult:
        """Parse a tag and return single search result"""
        return self.parse_search_item(tag)
