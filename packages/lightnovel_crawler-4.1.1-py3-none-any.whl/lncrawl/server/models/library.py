from typing import Optional

from pydantic import BaseModel, Field


class LibraryCreateRequest(BaseModel):
    name: str = Field(description="Library name")
    description: Optional[str] = Field(default=None, description="Library description")
    is_public: bool = Field(default=False, description="Is public")


class LibraryUpdateRequest(BaseModel):
    name: Optional[str] = Field(default=None, description="Library name")
    description: Optional[str] = Field(default=None, description="Library description")
    is_public: Optional[bool] = Field(default=None, description="Is public")


class LibraryItem(BaseModel):
    id: str = Field(description="Library ID")
    name: str = Field(description="Library name")
    description: Optional[str] = Field(default=None, description="Library description")
    is_public: bool = Field(description="Is public")
