#!/usr/bin/env python
"""
Unit tests for launcher Cloud Readiness flows.
Tests ensure_lab_ready wiring and Phase F advanced menu prompt/validation/confirm.
"""
from __future__ import print_function

import os
import sys
import unittest

try:
    from io import StringIO
except ImportError:
    from StringIO import StringIO  # pyright: ignore[reportMissingModuleSource]

try:
    from unittest.mock import patch, MagicMock
except ImportError:
    from mock import patch, MagicMock

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


def _cloud_readiness_menu_mocks(cr):
    """MagicMock cr.* defaults are truthy; real menu probes deferred-send and recommendations."""
    cr.read_operator_deferred_support_send = MagicMock(return_value=None)
    cr.clear_operator_deferred_support_send = MagicMock(return_value=True)
    cr.write_operator_deferred_support_send = MagicMock(return_value=True)
    cr.read_operator_deferred_phase_d_dat_smoke = MagicMock(return_value=None)
    cr.clear_operator_deferred_phase_d_dat_smoke = MagicMock(return_value=True)
    cr.write_operator_deferred_phase_d_dat_smoke = MagicMock(return_value=True)
    cr.read_phase_d_dat_smoke_state = MagicMock(return_value={})
    cr.preview_historical_phase_d_reprocess = MagicMock(return_value=(True, '', {}))
    cr.run_historical_phase_d_reprocess = MagicMock(return_value=(True, '', {}))
    cr.compute_operator_support_send_recommendation = MagicMock(return_value={
        'primary_send': 'system_health',
        'preferred_when_stable': 'system_health',
        'best_now_send': 'system_health',
        'summary_line': '',
        'why_lines': [],
        'why_summary': 'Use System Health Pack for broad lab context.',
        'pipeline_label': 'idle',
        'pipeline_running': False,
        'recommended_action_kind': 'send_bundle',
        'best_now_action_kind': 'send_bundle',
        'preferred_when_stable_action_kind': 'send_bundle',
        'recommended_report_kind': 'system_health_pack',
        'recommended_artifact_classes': [],
        'action_requires_confirmation': False,
        'action_preview': {},
        'action_reason_lines': [],
    })


def _make_orchestrator():
    """Create MediCafeOrchestrator with minimal session config."""
    from MediCafe.launcher import MediCafeOrchestrator, SessionConfig
    args = MagicMock()
    args.skip_csv = False
    args.direct_action = None
    args.debug_mode = False
    args.auto_choice = None
    session = SessionConfig(args)
    return MediCafeOrchestrator(session)


class TestConsoleHeartbeatProgress(unittest.TestCase):
    """Console heartbeat progress text stays lightweight but informative."""

    def test_console_heartbeat_progress_renders_latest_stage(self):
        from MediCafe.launcher_cloud_readiness_mixin import _ConsoleHeartbeatProgress

        progress = _ConsoleHeartbeatProgress('sending system health pack')
        self.assertEqual(progress.render(), 'sending system health pack')
        progress.update('creating zip bundle')
        self.assertEqual(progress.render(), 'sending system health pack; creating zip bundle')


class TestStrictRebuildFlow(unittest.TestCase):
    """Strict rebuild (Phase F advanced option 2) prompt/validation/confirm."""

    def test_strict_empty_input_cancels(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['2', '', '', '0']
                orch = _make_orchestrator()
                orch._phase_f_advanced_menu()
        cr.run_phase_f_manual_for_run_id.assert_not_called()

    def test_strict_valid_run_id_calls_service(self):
        from MediCafe import launcher as launcher_mod
        valid_rid = '20250216-120000-abc12345'
        cr = MagicMock()
        cr.run_phase_f_manual_for_run_id = MagicMock(return_value=(True, '', None))
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['2', valid_rid, '', '0']
                orch = _make_orchestrator()
                orch._phase_f_advanced_menu()
            cr.run_phase_f_manual_for_run_id.assert_called_once()
            call_args = cr.run_phase_f_manual_for_run_id.call_args[0]
            self.assertEqual(call_args[3], valid_rid)

    def test_strict_non_standard_decline_cancels(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.run_phase_f_manual_for_run_id = MagicMock()
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['2', 'non-standard-id', 'n', '', '0']
                orch = _make_orchestrator()
                orch._phase_f_advanced_menu()
            cr.run_phase_f_manual_for_run_id.assert_not_called()

    def test_strict_non_standard_accept_calls_service(self):
        from MediCafe import launcher as launcher_mod
        non_standard_rid = 'custom-run-123'
        cr = MagicMock()
        cr.run_phase_f_manual_for_run_id = MagicMock(return_value=(True, '', None))
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['2', non_standard_rid, 'y', '', '0']
                orch = _make_orchestrator()
                orch._phase_f_advanced_menu()
            cr.run_phase_f_manual_for_run_id.assert_called_once()
            call_args = cr.run_phase_f_manual_for_run_id.call_args[0]
            self.assertEqual(call_args[3], non_standard_rid)


class TestCloudReadinessAdvancedMenuEnsureLabReady(unittest.TestCase):
    """_cloud_readiness_advanced_menu calls ensure_lab_ready before rendering."""

    def test_calls_ensure_lab_ready_once_before_rendering(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['0']
                orch = _make_orchestrator()
                orch._cloud_readiness_advanced_menu()
        cr.ensure_lab_ready.assert_called_once()
        call_args = cr.ensure_lab_ready.call_args[0]
        self.assertEqual(call_args[0], orch.repo_root)
        self.assertEqual(call_args[1], orch.python_exe)
        self.assertEqual(call_args[2], orch.environment)
        self.assertTrue(cr.ensure_lab_ready.call_args[1].get('skip_recent_success_autopipeline'))

    def test_menu_renders_on_failure_warning_printed(self):
        from MediCafe import launcher as launcher_mod
        printed = []

        def _capture_print(*args, **kwargs):
            printed.append(' '.join(str(a) for a in args))

        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(False, 'Phase A bootstrap failed', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                with patch.object(launcher_mod.MediCafeOrchestrator, '_clear_console'):
                    with patch.object(launcher_mod.MediCafeOrchestrator, '_print_legacy_banner'):
                        with patch.object(launcher_mod.MediCafeOrchestrator, '_print_troubleshooting_group'):
                            with patch('__builtin__.print' if sys.version_info[0] < 3 else 'builtins.print', side_effect=_capture_print):
                                mock_prompt.side_effect = ['0']
                                orch = _make_orchestrator()
                                orch._cloud_readiness_advanced_menu()
        cr.get_health_lines.assert_called()
        warning_lines = [p for p in printed if '[WARNING]' in p and 'Phase A bootstrap failed' in p]
        self.assertEqual(len(warning_lines), 1)

    def test_manual_pipeline_letter_alias_b_triggers_phase_b(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._run_phase_b_discovery_manual = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['B', '', '0']
                orch._cloud_readiness_advanced_menu()
        orch._run_phase_b_discovery_manual.assert_called_once()


    def test_triage_option_runs_and_prints_hints(self):
        from MediCafe import launcher as launcher_mod
        printed = []

        def _capture_print(*args, **kwargs):
            printed.append(' '.join(str(a) for a in args))

        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.run_system_health_triage = MagicMock(return_value=(
            True,
            'System health triage completed.',
            {'hints': ['XP QA reject ratio: 0.21 (warn)', 'Hint: review latest qa_reject_samples_*.jsonl for unresolved QA rejects.']},
        ))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                with patch('__builtin__.print' if sys.version_info[0] < 3 else 'builtins.print', side_effect=_capture_print):
                    mock_prompt.side_effect = ['9', '1', '', '0', '0']
                    orch = _make_orchestrator()
                    orch._cloud_readiness_advanced_menu()
        cr.run_system_health_triage.assert_called_once()
        rendered = '\n'.join(printed)
        self.assertIn('Manual validation quick hints', rendered)
        self.assertIn('unresolved QA rejects', rendered)

    def test_system_health_triage_honors_medicafe_cloud_required(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.run_system_health_triage = MagicMock(return_value=(True, 'ok', {}))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            with patch.dict(os.environ, {'MEDICAFE_CLOUD_REQUIRED': 'true'}, clear=False):
                orch._run_system_health_triage()
        kwargs = cr.run_system_health_triage.call_args[1]
        self.assertTrue(kwargs.get('cloud_required'))

    def test_send_pack_failure_opens_delivery_diagnostics(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.send_latest_system_health_pack = MagicMock(return_value=(False, 'send failed', {}))
        cr.open_report_delivery_status = MagicMock(return_value=(True, '', os.path.join(_PROJECT_ROOT, 'lab', 'reports', 'report_delivery_status.txt')))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._launch_viewer = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                # O -> Other sends; 1 -> system health send; '' -> pause in submenu; 0 -> back;
                # '' -> pause in advanced after submenu; 0 -> exit advanced (may need an extra '' on some builds).
                mock_prompt.side_effect = ['9', '4', '1', '', '0', '0', '0']
                orch._cloud_readiness_advanced_menu()
        cr.send_latest_system_health_pack.assert_called_once()
        cr.open_report_delivery_status.assert_called()

    def test_send_system_health_pack_passes_progress_callback(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.send_latest_system_health_pack = MagicMock(return_value=(True, '', {}))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            ok = orch._send_latest_system_health_pack()
        self.assertTrue(ok)
        kwargs = cr.send_latest_system_health_pack.call_args[1]
        progress_callback = kwargs.get('progress_callback')
        self.assertTrue(callable(progress_callback))
        progress_callback('creating zip bundle')

    def test_send_run_evidence_bundle_passes_progress_callback(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.send_latest_run_evidence_bundle = MagicMock(return_value=(True, '', {}))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            ok = orch._send_latest_run_evidence_bundle()
        self.assertTrue(ok)
        kwargs = cr.send_latest_run_evidence_bundle.call_args[1]
        progress_callback = kwargs.get('progress_callback')
        self.assertTrue(callable(progress_callback))
        progress_callback('sending email to support')

    def test_guided_patient_completeness_option_runs_letter_flow(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.get_guided_patient_completeness_options = MagicMock(return_value=(
            True,
            'Guided patient completeness options ready.',
            {
                'runbook_lines': ['Guided Patient Completeness Runbook:', ' - data_plane_status=WARN'],
                'options': [{
                    'code': 'A',
                    'title': 'Highest-Risk Completeness Gap',
                    'display_id': '12345',
                    'risk_label': 'HIGH',
                    'reason': 'Highest risk score across chain completeness.',
                    'context_run_id': '20260219-071129-5d5c869f',
                }],
            },
        ))
        cr.open_guided_patient_completeness_runbook = MagicMock(return_value=(
            True,
            'Patient completeness runbook generated.',
            os.path.join(_PROJECT_ROOT, 'lab', 'reports', 'patient_completeness_runbook_latest.txt'),
        ))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._launch_viewer = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['2', '1', 'A', '', '0', '0']
                orch._cloud_readiness_advanced_menu()
        cr.get_guided_patient_completeness_options.assert_called_once()
        cr.open_guided_patient_completeness_runbook.assert_called_once_with(orch.repo_root, 'A')
        orch._launch_viewer.assert_called_once()

    def test_guided_patient_completeness_no_patient_rows_prints_guidance(self):
        from MediCafe import launcher as launcher_mod
        printed = []

        def _capture_print(*args, **kwargs):
            printed.append(' '.join(str(a) for a in args))

        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.get_guided_patient_completeness_options = MagicMock(return_value=(
            False,
            'Guided patient completeness unavailable due to current data-state (0 patient rows). Launcher is healthy; review runbook actions below.',
            {
                'condition': 'no_patient_rows',
                'runbook_lines': [
                    'Guided Patient Completeness Runbook:',
                    ' - patient_count=0',
                    ' - qa_reject_count=4',
                    ' - replay_pending_count=4',
                    ' - projection_success_count=0',
                    'What To Do Now:',
                    ' 1) Review QA rejects/replay queue first.',
                    ' 2) Re-open Cloud Readiness -> Investigate after data-state changes.',
                ],
                'actions': [
                    'Review QA rejects/replay queue first.',
                    'Re-open Cloud Readiness -> 2) Investigate patient / data -> 1) Guided completeness after data-state changes.',
                ],
                'options': [],
            },
        ))
        cr.open_guided_patient_completeness_runbook = MagicMock()
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                with patch('__builtin__.print' if sys.version_info[0] < 3 else 'builtins.print', side_effect=_capture_print):
                    mock_prompt.side_effect = ['2', '1', '', '0', '0']
                    orch = _make_orchestrator()
                    orch._cloud_readiness_advanced_menu()
        cr.get_guided_patient_completeness_options.assert_called_once()
        cr.open_guided_patient_completeness_runbook.assert_not_called()
        rendered = '\n'.join(printed)
        self.assertIn('Guided runbook context:', rendered)
        self.assertIn('patient_count=0', rendered)
        self.assertIn('What To Do Now:', rendered)
        self.assertIn('Investigate', rendered)
        self.assertEqual(rendered.count('What To Do Now:'), 1)



    def test_patient_flow_runbook_option_opens_for_reference(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.get_patient_flow_reference_options = MagicMock(return_value=(
            True,
            'Patient flow reference options ready.',
            {'options': [{
                'index': 1,
                'display_id': '33333',
                'patient_ref': '33333',
                'risk_label': 'HIGH',
                'risk_score': 80,
            }]},
        ))
        cr.open_patient_flow_runbook = MagicMock(return_value=(
            True,
            'Patient flow runbook generated.',
            os.path.join(_PROJECT_ROOT, 'lab', 'reports', 'patient_completeness_runbook_latest.txt'),
        ))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._launch_viewer = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['2', '2', '1', '', '0', '0']
                orch._cloud_readiness_advanced_menu()
        cr.get_patient_flow_reference_options.assert_called_once_with(orch.repo_root, limit=12)
        cr.open_patient_flow_runbook.assert_called_once_with(orch.repo_root, '33333')
        orch._launch_viewer.assert_called_once()

    def test_db_inspection_option_generates_and_opens_overview_report(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.open_data_plane_audit_report = MagicMock(return_value=(
            True,
            'DB data audit report generated.',
            os.path.join(_PROJECT_ROOT, 'lab', 'reports', 'db_data_audit_overview_latest.txt'),
        ))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._launch_viewer = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['2', '3', '1', '', '0', '0', '0']
                orch._cloud_readiness_advanced_menu()
        cr.open_data_plane_audit_report.assert_called_once_with(
            orch.repo_root, report_type='overview', limit=60)
        orch._launch_viewer.assert_called_once()

    def test_db_inspection_manual_reference_opens_patient_flow_runbook(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.open_patient_flow_runbook = MagicMock(return_value=(
            True,
            'Patient flow runbook generated.',
            os.path.join(_PROJECT_ROOT, 'lab', 'reports', 'patient_completeness_runbook_latest.txt'),
        ))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._launch_viewer = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['2', '3', '5', '33333', '', '0', '0', '0']
                orch._cloud_readiness_advanced_menu()
        cr.open_patient_flow_runbook.assert_called_once_with(orch.repo_root, '33333')
        orch._launch_viewer.assert_called_once()

    def test_artifact_tools_letter_a_opens_latest_triage_pack(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._open_latest_artifact_triage_pack = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['A', '', '0']
                orch._cloud_phase_artifacts_menu()
        orch._open_latest_artifact_triage_pack.assert_called_once()

    def test_artifact_tools_letter_d_opens_run_id_index(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._open_run_artifact_index_for_run_id = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['D', '20260219-064740-157a78b1', '', '0']
                orch._cloud_phase_artifacts_menu()
        orch._open_run_artifact_index_for_run_id.assert_called_once_with('20260219-064740-157a78b1')

    def test_manual_pipeline_letter_alias_a_triggers_full_pipeline(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._run_shadow_pipeline = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['a', '', '0']
                orch._cloud_readiness_advanced_menu()
        orch._run_shadow_pipeline.assert_called_once()

    def test_follow_recommendation_stable_send_invokes_bundle_send(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.compute_operator_support_send_recommendation = MagicMock(return_value={
            'primary_send': 'run_evidence',
            'preferred_when_stable': 'run_evidence',
            'best_now_send': 'run_evidence',
            'summary_line': 'Send run evidence.',
            'why_lines': [],
            'why_summary': 'ok',
            'pipeline_label': 'idle',
            'pipeline_running': False,
        })
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._send_latest_run_evidence_bundle = MagicMock(return_value=True)
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['1', '1', '0']
                orch._cloud_readiness_advanced_menu()
        orch._send_latest_run_evidence_bundle.assert_called_once()

    def test_open_recommended_lab_report_uses_triage_when_run_evidence_preferred(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.compute_operator_support_send_recommendation = MagicMock(return_value={
            'primary_send': 'run_evidence',
            'preferred_when_stable': 'run_evidence',
            'best_now_send': 'run_evidence',
            'why_lines': [],
            'why_summary': 'x',
            'pipeline_label': 'idle',
            'pipeline_running': False,
        })
        triage_path = os.path.join(_PROJECT_ROOT, 'lab', 'reports', 'triage.txt')
        cr.open_latest_artifact_triage_pack = MagicMock(return_value=(True, '', triage_path))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._launch_viewer = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['3', '', '0']
                orch._cloud_readiness_advanced_menu()
        cr.open_latest_artifact_triage_pack.assert_called_once()
        orch._launch_viewer.assert_called_once_with(triage_path)

    def test_open_recommended_lab_report_uses_system_health_when_best_now_not_stable_pref(self):
        """When pipeline is running, Best now is system_health while stable pref is run_evidence — open health pack."""
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.compute_operator_support_send_recommendation = MagicMock(return_value={
            'primary_send': 'run_evidence',
            'preferred_when_stable': 'run_evidence',
            'best_now_send': 'system_health',
            'why_lines': [],
            'why_summary': 'Pipeline active',
            'pipeline_label': 'running',
            'pipeline_running': True,
        })
        pack_path = os.path.join(_PROJECT_ROOT, 'lab', 'reports', 'health_pack.txt')
        cr.open_latest_system_health_pack = MagicMock(return_value=(True, '', pack_path))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._launch_viewer = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['3', '', '0']
                orch._cloud_readiness_advanced_menu()
        cr.open_latest_artifact_triage_pack.assert_not_called()
        cr.open_latest_system_health_pack.assert_called_once()
        orch._launch_viewer.assert_called_once_with(pack_path)

    def test_s_alias_routes_to_follow_recommendation_flow(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._follow_recommendation_flow = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['S', '0']
                orch._cloud_readiness_advanced_menu()
        orch._follow_recommendation_flow.assert_called_once()

    def test_follow_recommendation_unstable_defer_writes_stable_preference(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.compute_operator_support_send_recommendation = MagicMock(return_value={
            'primary_send': 'run_evidence',
            'preferred_when_stable': 'run_evidence',
            'best_now_send': 'system_health',
            'summary_line': 'Deferred example.',
            'why_lines': ['Pipeline running'],
            'why_summary': 'Pipeline active',
            'pipeline_label': 'running',
            'pipeline_running': True,
            'recommended_action_kind': 'send_bundle',
            'best_now_action_kind': 'send_bundle',
            'preferred_when_stable_action_kind': 'send_bundle',
            'recommended_report_kind': 'artifact_triage_pack',
            'recommended_artifact_classes': [],
            'action_requires_confirmation': False,
            'action_preview': {},
            'action_reason_lines': [],
        })
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['1', '2', '0']
                orch._cloud_readiness_advanced_menu()
        cr.write_operator_deferred_support_send.assert_called_once()
        call_kw = cr.write_operator_deferred_support_send.call_args
        self.assertEqual(call_kw[0][1], 'run_evidence')
        self.assertEqual(call_kw[1].get('action_kind'), 'send_bundle')

    def test_follow_recommendation_stable_historical_reprocess_runs_preview_then_execute(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.compute_operator_support_send_recommendation = MagicMock(return_value={
            'primary_send': 'run_evidence',
            'preferred_when_stable': 'run_evidence',
            'best_now_send': 'run_evidence',
            'summary_line': 'Re-evaluate historical Phase D rejects.',
            'why_lines': ['Historical rejects still exist.'],
            'why_summary': 'Historical rejects need re-evaluation.',
            'pipeline_label': 'idle',
            'pipeline_running': False,
            'recommended_action_kind': 'historical_phase_d_reprocess',
            'best_now_action_kind': 'historical_phase_d_reprocess',
            'preferred_when_stable_action_kind': 'historical_phase_d_reprocess',
            'recommended_report_kind': 'artifact_triage_pack',
            'recommended_artifact_classes': ['dat'],
            'action_requires_confirmation': True,
            'action_preview': {'qa_policy_version': 'qa_v2'},
            'action_reason_lines': ['Historical DAT rejects still exist.'],
            'recommendation_anchor_run_id': '20260329-anchor-run',
        })
        cr.preview_historical_phase_d_reprocess = MagicMock(return_value=(True, '', {
            'ok': True,
            'targeted_artifact_classes': ['dat'],
            'qa_version': 'qa_v2',
            'targeted_artifact_count': 389,
            'reject_counts_by_class': {'dat': 389},
            'pending_replay_counts_by_class': {'dat': 389},
            'report_path': os.path.join(_PROJECT_ROOT, 'lab', 'reports', 'phase_d_historical_reprocess_preview_latest.txt'),
        }))
        cr.run_historical_phase_d_reprocess = MagicMock(return_value=(True, 'started', {
            'execution_report_path': os.path.join(_PROJECT_ROOT, 'lab', 'reports', 'phase_d_historical_reprocess_execution_latest.txt'),
        }))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['1', '1', 'y', '0']
                orch._cloud_readiness_advanced_menu()
        cr.preview_historical_phase_d_reprocess.assert_called_once_with(
            orch.repo_root,
            artifact_classes=['dat'],
            remediation_context_run_id='20260329-anchor-run',
        )
        cr.run_historical_phase_d_reprocess.assert_called_once_with(
            orch.repo_root,
            orch.python_exe,
            orch.environment,
            artifact_classes=['dat'],
            remediation_context_run_id='20260329-anchor-run',
        )
        cr.clear_operator_deferred_support_send.assert_called_once_with(orch.repo_root)

    def test_follow_recommendation_unstable_historical_reprocess_defers_action(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.compute_operator_support_send_recommendation = MagicMock(return_value={
            'primary_send': 'run_evidence',
            'preferred_when_stable': 'run_evidence',
            'best_now_send': 'system_health',
            'summary_line': 'Wait, then re-evaluate historical rejects.',
            'why_lines': ['Pipeline running'],
            'why_summary': 'Pipeline active',
            'pipeline_label': 'running',
            'pipeline_running': True,
            'recommended_action_kind': 'historical_phase_d_reprocess',
            'best_now_action_kind': 'wait_for_stable',
            'preferred_when_stable_action_kind': 'historical_phase_d_reprocess',
            'recommended_report_kind': 'artifact_triage_pack',
            'recommended_artifact_classes': ['dat'],
            'action_requires_confirmation': True,
            'action_preview': {'qa_policy_version': 'qa_v2'},
            'action_reason_lines': ['Historical DAT rejects still exist.'],
        })
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['1', '1', '0']
                orch._cloud_readiness_advanced_menu()
        cr.write_operator_deferred_support_send.assert_called_once()
        self.assertEqual(cr.write_operator_deferred_support_send.call_args[1].get('action_kind'), 'historical_phase_d_reprocess')
        self.assertEqual(cr.write_operator_deferred_support_send.call_args[1].get('artifact_classes'), ['dat'])

    def test_open_recommended_lab_report_uses_triage_for_historical_reprocess(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.compute_operator_support_send_recommendation = MagicMock(return_value={
            'primary_send': 'system_health',
            'preferred_when_stable': 'run_evidence',
            'best_now_send': 'system_health',
            'why_lines': [],
            'why_summary': 'Historical reprocess guidance',
            'pipeline_label': 'running',
            'pipeline_running': True,
            'recommended_action_kind': 'historical_phase_d_reprocess',
            'best_now_action_kind': 'wait_for_stable',
            'preferred_when_stable_action_kind': 'historical_phase_d_reprocess',
            'recommended_report_kind': 'artifact_triage_pack',
            'recommended_artifact_classes': ['dat'],
            'action_requires_confirmation': True,
            'action_preview': {},
            'action_reason_lines': [],
        })
        triage_path = os.path.join(_PROJECT_ROOT, 'lab', 'reports', 'triage.txt')
        cr.open_latest_artifact_triage_pack = MagicMock(return_value=(True, '', triage_path))
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._launch_viewer = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['3', '', '0']
                orch._cloud_readiness_advanced_menu()
        cr.open_latest_artifact_triage_pack.assert_called_once()
        orch._launch_viewer.assert_called_once_with(triage_path)

    def test_open_recommended_lab_report_uses_run_index_for_dat_qa_full_block(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.compute_operator_support_send_recommendation = MagicMock(return_value={
            'primary_send': 'run_evidence',
            'preferred_when_stable': 'run_evidence',
            'best_now_send': 'run_evidence',
            'why_lines': [],
            'why_summary': 'Review DAT QA full-block evidence.',
            'pipeline_label': 'idle',
            'pipeline_running': False,
            'recommended_action_kind': 'review_dat_qa_full_block',
            'best_now_action_kind': 'review_dat_qa_full_block',
            'preferred_when_stable_action_kind': 'review_dat_qa_full_block',
            'recommended_report_kind': 'artifact_triage_pack',
            'recommended_artifact_classes': ['dat'],
            'action_requires_confirmation': False,
            'action_preview': {'anchor_run_id': '20260329-171213-1ccb1c51'},
            'action_reason_lines': [],
        })
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._open_run_artifact_index_for_run_id = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['3', '', '0']
                orch._cloud_readiness_advanced_menu()
        orch._open_run_artifact_index_for_run_id.assert_called_once_with('20260329-171213-1ccb1c51')
        cr.open_latest_artifact_triage_pack.assert_not_called()

    def test_deferred_dat_smoke_stale_intent_clears_without_running(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.read_operator_deferred_phase_d_dat_smoke = MagicMock(return_value={
            'anchor_run_id': 'anchor-old',
            'context_run_id': 'ctx-old',
            'issue_code': 'ISSUE_OLD',
            'reference_phase_d_summary_path': '',
            'created_at_utc': '2026-03-31T00:00:00Z',
        })
        cr.compute_operator_support_send_recommendation = MagicMock(return_value={
            'primary_send': 'system_health',
            'preferred_when_stable': 'system_health',
            'best_now_send': 'system_health',
            'summary_line': 'Run DAT smoke.',
            'why_lines': [],
            'why_summary': 'smoke needed',
            'pipeline_label': 'idle',
            'pipeline_running': False,
            'recommended_action_kind': 'phase_d_dat_smoke',
            'best_now_action_kind': 'phase_d_dat_smoke',
            'preferred_when_stable_action_kind': 'phase_d_dat_smoke',
            'recommended_report_kind': 'artifact_triage_pack',
            'recommended_artifact_classes': ['dat'],
            'action_requires_confirmation': False,
            'action_preview': {
                'anchor_run_id': 'anchor-new',
                'phase_d_context_run_id': 'ctx-new',
                'remediation_issue_code': 'ISSUE_NEW',
                'reference_phase_d_summary_path': '',
            },
            'action_reason_lines': [],
        })
        cr.read_phase_d_dat_smoke_state = MagicMock(return_value={
            'last_requested_anchor_run_id': 'anchor-new',
            'last_requested_context_run_id': 'ctx-new',
            'last_remediation_issue_code': 'ISSUE_NEW',
            'last_status': 'completed',
            'cooldown_until_utc': '2999-01-01T00:00:00Z',
        })
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._run_phase_d_dat_smoke = MagicMock(return_value=True)
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['0']
                orch._cloud_readiness_advanced_menu()
        cr.clear_operator_deferred_phase_d_dat_smoke.assert_called_once_with(orch.repo_root)
        orch._run_phase_d_dat_smoke.assert_not_called()

    def test_autorun_dat_smoke_suppressed_when_same_target_cooldown_active(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.compute_operator_support_send_recommendation = MagicMock(return_value={
            'primary_send': 'system_health',
            'preferred_when_stable': 'system_health',
            'best_now_send': 'system_health',
            'summary_line': 'Run DAT smoke.',
            'why_lines': [],
            'why_summary': 'smoke needed',
            'pipeline_label': 'idle',
            'pipeline_running': False,
            'recommended_action_kind': 'phase_d_dat_smoke',
            'best_now_action_kind': 'phase_d_dat_smoke',
            'preferred_when_stable_action_kind': 'phase_d_dat_smoke',
            'recommended_report_kind': 'artifact_triage_pack',
            'recommended_artifact_classes': ['dat'],
            'action_requires_confirmation': False,
            'action_preview': {
                'anchor_run_id': 'anchor-1',
                'phase_d_context_run_id': 'ctx-1',
                'remediation_issue_code': 'ISSUE_1',
                'reference_phase_d_summary_path': '',
            },
            'action_reason_lines': [],
        })
        cr.read_phase_d_dat_smoke_state = MagicMock(return_value={
            'last_requested_anchor_run_id': 'anchor-1',
            'last_requested_context_run_id': 'ctx-1',
            'last_remediation_issue_code': 'ISSUE_1',
            'last_status': 'completed',
            'cooldown_until_utc': '2999-01-01T00:00:00Z',
        })
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._run_phase_d_dat_smoke = MagicMock(return_value=True)
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['0']
                orch._cloud_readiness_advanced_menu()
        orch._run_phase_d_dat_smoke.assert_not_called()

    def test_print_operator_send_why_includes_phase_d_remediation_lines(self):
        """Operator menu prints the same phase_d_remediation tokens cloud_readiness can return in why_lines."""
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.compute_operator_support_send_recommendation = MagicMock(return_value={
            'summary_line': 'Recommended: send latest System Health Pack.',
            'why_lines': [
                'phase_d_remediation: verification_target=phase_d_constraint_skips',
                'phase_d_remediation: verification_scope=global_phase_d',
                'phase_d_remediation glossary: verification_scope=dat_lane_only means the DAT-lane gate only;',
            ],
            'pipeline_label': 'idle',
            'pipeline_running': False,
        })
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            buf = StringIO()
            with patch.object(sys, 'stdout', buf):
                orch._print_operator_send_why()
        out = buf.getvalue()
        self.assertIn('phase_d_remediation: verification_target=', out)
        self.assertIn('phase_d_remediation glossary:', out)

    def test_print_operator_send_why_includes_qa_full_block_provenance(self):
        """Show why prints provenance fields for review_dat_qa_full_block (anchored vs smoke)."""
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.compute_operator_support_send_recommendation = MagicMock(return_value={
            'summary_line': 'Recommended: review DAT QA full-block evidence for the anchored run.',
            'why_lines': ['Anchored Phase D telemetry shows DAT rows were selected but fully QA-blocked.'],
            'why_summary': 'Review anchored QA evidence first.',
            'pipeline_label': 'idle',
            'pipeline_running': False,
            'recommended_action_kind': 'review_dat_qa_full_block',
            'best_now_action_kind': 'review_dat_qa_full_block',
            'preferred_when_stable_action_kind': 'review_dat_qa_full_block',
            'recommended_report_kind': 'artifact_triage_pack',
            'recommended_artifact_classes': ['dat'],
            'action_preview': {
                'anchor_run_id': '20260329-171213-1ccb1c51',
                'anchored_diagnosis_source': 'anchored_phase_d_shadow',
                'smoke_source_accepted': False,
                'ignored_smoke_mismatch': True,
                'smoke_anchor_run_id': '20260331-other-smoke-anchor',
                'source_mismatch_note': 'Smoke on disk is not used for displayed counters.',
                'dat_selected_count': 6,
                'dat_qa_pass_count': 0,
                'dat_qa_reject_count': 6,
                'dat_canonical_record_count': 0,
                'phase_d_summary_path': '/lab/reports/qa_x.json',
                'qa_reject_samples_path': '/lab/reports/reject.jsonl',
                'smoke_report_path': '/smoke/report.txt',
            },
            'action_reason_lines': [],
        })
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            buf = StringIO()
            with patch.object(sys, 'stdout', buf):
                orch._print_operator_send_why()
        out = buf.getvalue()
        self.assertIn('anchored_diagnosis_source=', out)
        self.assertIn('smoke_source_accepted=False', out)
        self.assertIn('ignored_smoke_mismatch=True', out)
        self.assertIn('smoke_anchor_run_id=', out)
        self.assertIn('source_mismatch_note=', out)
        self.assertIn('ignored_smoke_report_path=/smoke/report.txt', out)
        self.assertIn('ignore this smoke report for anchored review', out)

    def test_cloud_readiness_advanced_menu_dat_smoke_help_avoids_false_anchor_placeholder(self):
        """Manual DAT smoke menu lines must not promise phase_d_dat_smoke_report_<anchor>.txt."""
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            buf = StringIO()
            with patch.object(sys, 'stdout', buf):
                with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                    mock_prompt.side_effect = ['0']
                    orch._cloud_readiness_advanced_menu()
        out = buf.getvalue()
        self.assertNotIn('phase_d_dat_smoke_report_<anchor>', out)
        self.assertIn('phase_d_dat_smoke_lab/reports/', out)
        self.assertIn('filename from smoke run', out)

    def test_print_operator_send_why_includes_skip_reasons_for_hidden_actions(self):
        """When recommendation remains send_bundle, operator should still see why historical/smoke were skipped."""
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.compute_operator_support_send_recommendation = MagicMock(return_value={
            'summary_line': 'Recommended: send latest run evidence bundle (phases B..F).',
            'why_lines': [
                'Evaluated artifact run_id=20260331-021819-229d2b48.',
            ],
            'historical_reprocess_evaluated': True,
            'historical_reprocess_available': False,
            'historical_reprocess_not_triggered_reason': 'historical reprocess not triggered: Phase D shows new pass/reject movement or row selection for this evaluated run.',
            'dat_smoke_evaluated': True,
            'dat_smoke_available': False,
            'dat_smoke_not_triggered_reason': 'DAT smoke not triggered: post_medisoft_blocked_stage=phase_d indicates the lane was already exercised.',
            'pipeline_label': 'idle',
            'pipeline_running': False,
            'recommended_action_kind': 'send_bundle',
            'best_now_action_kind': 'send_bundle',
            'preferred_when_stable_action_kind': 'send_bundle',
            'recommended_report_kind': 'artifact_triage_pack',
            'recommended_artifact_classes': [],
            'action_requires_confirmation': False,
            'action_preview': {},
            'action_reason_lines': [],
        })
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            buf = StringIO()
            with patch.object(sys, 'stdout', buf):
                orch._print_operator_send_why()
        out = buf.getvalue()
        self.assertIn('historical_reprocess_not_triggered_reason=', out)
        self.assertIn('Phase D shows new pass/reject movement or row selection', out)
        self.assertIn('dat_smoke_not_triggered_reason=', out)
        self.assertIn('post_medisoft_blocked_stage=phase_d', out)

    def test_follow_recommendation_stable_dat_qa_full_block_opens_run_index(self):
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.ensure_lab_ready = MagicMock(return_value=(True, '', None))
        cr.get_health_lines = MagicMock(return_value=[])
        cr.resolve_lab_root = MagicMock(return_value=os.path.join(_PROJECT_ROOT, 'lab'))
        cr.check_pipeline_running_for_action = MagicMock(return_value=(False, None))
        _cloud_readiness_menu_mocks(cr)
        cr.compute_operator_support_send_recommendation = MagicMock(return_value={
            'primary_send': 'run_evidence',
            'preferred_when_stable': 'run_evidence',
            'best_now_send': 'run_evidence',
            'summary_line': 'Review DAT QA full-block evidence.',
            'why_lines': ['DAT lane is exercised and fully QA-blocked.'],
            'why_summary': 'Review anchored QA evidence first.',
            'pipeline_label': 'idle',
            'pipeline_running': False,
            'recommended_action_kind': 'review_dat_qa_full_block',
            'best_now_action_kind': 'review_dat_qa_full_block',
            'preferred_when_stable_action_kind': 'review_dat_qa_full_block',
            'recommended_report_kind': 'artifact_triage_pack',
            'recommended_artifact_classes': ['dat'],
            'action_requires_confirmation': False,
            'action_preview': {
                'anchor_run_id': '20260329-171213-1ccb1c51',
                'phase_d_summary_path': os.path.join(_PROJECT_ROOT, 'lab', 'reports', 'qa_canonical_summary_20260329-171213-1ccb1c51.json'),
            },
            'action_reason_lines': ['Review QA summary and reject samples.'],
        })
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            orch._open_run_artifact_index_for_run_id = MagicMock()
            with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt') as mock_prompt:
                mock_prompt.side_effect = ['1', '1', '0']
                orch._cloud_readiness_advanced_menu()
        orch._open_run_artifact_index_for_run_id.assert_called_once_with('20260329-171213-1ccb1c51')
        cr.clear_operator_deferred_support_send.assert_called_once_with(orch.repo_root)

    def test_follow_recommendation_phase_d_why_lines_does_not_offer_historical_as_option_one(self):
        """phase_d_remediation in why_lines does not switch follow-recommendation Option 1 to historical reprocess (autonomy boundary)."""
        from MediCafe import launcher as launcher_mod
        cr = MagicMock()
        cr.compute_operator_support_send_recommendation = MagicMock(return_value={
            'primary_send': 'run_evidence',
            'preferred_when_stable': 'run_evidence',
            'best_now_send': 'run_evidence',
            'summary_line': 'Recommended: send run evidence.',
            'why_lines': [
                'phase_d_remediation: issue_code=PHASE_D_INVALID_EXTERNAL_ID_SPIKE status=active context_run_id=rid-1',
                'phase_d_remediation: verification_target=phase_d_constraint_skips',
            ],
            'why_summary': 'ok',
            'pipeline_label': 'idle',
            'pipeline_running': False,
            'recommended_action_kind': 'send_bundle',
            'best_now_action_kind': 'send_bundle',
            'preferred_when_stable_action_kind': 'send_bundle',
            'recommended_report_kind': 'artifact_triage_pack',
            'recommended_artifact_classes': [],
            'action_requires_confirmation': False,
            'action_preview': {},
            'action_reason_lines': [],
        })
        printed = []

        def _capture_print(*args, **kwargs):
            printed.append(' '.join(str(a) for a in args))

        print_name = 'builtins.print' if sys.version_info[0] >= 3 else '__builtin__.print'
        with patch.object(launcher_mod, 'cloud_readiness', cr):
            orch = _make_orchestrator()
            with patch(print_name, side_effect=_capture_print):
                with patch.object(launcher_mod.MediCafeOrchestrator, '_prompt', side_effect=['0']):
                    orch._follow_recommendation_flow()
        blob = '\n'.join(printed)
        self.assertIn('Send now', blob)
        self.assertNotIn('historical Phase D re-evaluation', blob)
        cr.preview_historical_phase_d_reprocess.assert_not_called()
        cr.run_historical_phase_d_reprocess.assert_not_called()


if __name__ == '__main__':
    unittest.main()
