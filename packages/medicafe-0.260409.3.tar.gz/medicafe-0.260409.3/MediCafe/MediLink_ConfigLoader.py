# MediLink_ConfigLoader.py
import os, json, logging, sys, platform, copy, tempfile
try:
    import yaml
except ImportError:
    yaml = None
from datetime import datetime
from collections import OrderedDict
from functools import reduce

# Global configuration cache to prevent repeated loading
_CONFIG_CACHE = None
_CROSSWALK_CACHE = None
_CONFIG_LOAD_DIAGNOSTICS = None
_RUN_LOG_FILEPATH = None

_DEFAULT_CONFIG_PATH = os.path.join(os.path.dirname(__file__), '..', 'json', 'config.json')
_DEFAULT_CROSSWALK_PATH = os.path.join(os.path.dirname(__file__), '..', 'json', 'crosswalk.json')

_CERT_PROVIDER_DEFAULTS = {
    'mode': 'self_signed',
    'profile': 'default',
    'root_subject': 'CN=MediLink Managed Root CA',
    'server_subject': 'CN=127.0.0.1',
    'san': ['127.0.0.1', 'localhost'],
    'root_valid_days': 3650,
    'server_valid_days': 365
}


def _copy_cert_provider_defaults():
    try:
        return copy.deepcopy(_CERT_PROVIDER_DEFAULTS)
    except Exception:
        return {
            'mode': 'self_signed',
            'profile': 'default',
            'root_subject': 'CN=MediLink Managed Root CA',
            'server_subject': 'CN=127.0.0.1',
            'san': ['127.0.0.1', 'localhost'],
            'root_valid_days': 3650,
            'server_valid_days': 365
        }

# Import centralized logging configuration and timing utils
# Skip import in minimal mode to avoid circular import warnings
_MINIMAL_IMPORT = os.environ.get('MEDICAFE_MINIMAL_IMPORT', '').strip().lower() in ('1', 'true', 'yes', 'y')

try:
    from MediCafe.timing_utils import start_run, record_stage, stage_timer, noop_timer, is_timing_enabled, get_storage_path
except ImportError:
    start_run = None
    record_stage = None
    stage_timer = None

    class _NoopTimer(object):
        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

    noop_timer = _NoopTimer()
    is_timing_enabled = None
    get_storage_path = None

if not _MINIMAL_IMPORT:
    try:
        from MediCafe.logging_config import PERFORMANCE_LOGGING
    except ImportError:
        # Fallback to local flag if centralized config is not available
        PERFORMANCE_LOGGING = False
else:
    PERFORMANCE_LOGGING = False

try:
    from MediBot.config_editor_helpers import (
        save_config_atomic as _editor_save_config_atomic,
        resolve_config_path as _editor_resolve_config_path,
        load_config_safe as _editor_load_config_safe,
    )
except Exception:
    _editor_save_config_atomic = None
    _editor_resolve_config_path = None
    _editor_load_config_safe = None

def get_default_config():
    """Provide a default configuration when config files are missing."""
    return {
        'MediLink_Config': {
            'local_storage_path': '.',
            'receiptsRoot': './receipts',
            # HTTP mode flag: when True, server runs without SSL/TLS encryption
            # WARNING: Only suitable for localhost (127.0.0.1/localhost) development
            # Do not use in production or over network connections
            #
            # IMPORTANT LIMITATION: HTTP mode does NOT work when webapp is served from HTTPS pages
            # (e.g., Google Apps Script). Chrome's Private Network Access (PNA) blocks HTTPS-to-HTTP
            # localhost requests at the browser level, before they reach the server.
            #
            # Workarounds:
            # 1. Use HTTPS mode (recommended): Avoids PNA blocking but requires certificate trust
            # 2. Serve webapp over HTTP: HTTP mode works when webapp is served from HTTP (not GAS)
            # 3. Disable Chrome PNA (development only): Launch Chrome with flag:
            #    --disable-features=BlockInsecurePrivateNetworkRequests
            #    Example: chrome.exe --disable-features=BlockInsecurePrivateNetworkRequests
            #
            # Recommendation: Use HTTPS mode for production. HTTP mode is only suitable for:
            # - Development when webapp is served over HTTP (not from Google Apps Script)
            # - Testing with PNA disabled via browser flag
            'use_http_mode': False,  # Default: use HTTPS (secure)
            'api_endpoints': {
                'base_url': 'https://api.example.com',
                'timeout': 30
            },
            'logging': {
                'level': 'INFO',
                'console_output': True
            },
            'error_reporting': {
                'enabled': False,
                'endpoint_url': '',
                'auth_token': '',
                'insecure_http': False,
                'max_bundle_bytes': 2097152,
                'email': {
                    'enabled': False,
                    'to': '',
                    'subject_prefix': 'MediCafe Error Report',
                    'max_bundle_bytes': 1572864
                }
            },
            'certificate_provider': {
                'mode': 'self_signed',
                'profile': 'default',
                'root_subject': 'CN=MediLink Managed Root CA',
                'server_subject': 'CN=127.0.0.1',
                'san': ['127.0.0.1', 'localhost'],
                'root_valid_days': 3650,
                'server_valid_days': 365
            },
            # STRATEGIC NOTE (COB Configuration): COB library is fully implemented and ready
            # To enable COB functionality, add the following configuration:
            # 'cob_settings': {
            #     'enabled': False,  # Set to True to activate COB processing
            #     'medicare_payer_ids': ['00850', 'MEDICARE', 'CMS', 'MCARE'],
            #     'cob_mode': 'single_payer_only',  # or 'multi_payer_supported'
            #     'validation_level': 3,  # SNIP level 3+ recommended for COB
            #     'medicare_advantage_identifiers': ['MA', 'MC'],
            #     'default_medicare_type': 'MB',
            #     'require_835_validation': False  # Set True for production
            # }
        }
    }

def get_default_crosswalk():
    """Provide a default crosswalk when crosswalk files are missing."""
    return {
        'payer_id': {},
        'endpoint_payer_ids': {},
        'optum_payer_list': {
            'metadata': {},
            'payers': {}
        },
        'mains_mapping': {},
        'mapat_mapping': {},
        'diagnosis_to_medisoft': {},
        'procedure_to_diagnosis': {},
        'csv_replacements': {},
        'payer_mappings': {},
        'insurance_types': {},
        'diagnosis_codes': {},
        'procedure_codes': {}
    }


def _copy_json_compatible(value):
    try:
        return copy.deepcopy(value)
    except Exception:
        return value


def _resolve_requested_config_paths(config_path, crosswalk_path):
    default_config_abs = os.path.abspath(_DEFAULT_CONFIG_PATH)
    default_crosswalk_abs = os.path.abspath(_DEFAULT_CROSSWALK_PATH)
    explicit_config = bool(config_path) and os.path.abspath(config_path) != default_config_abs
    explicit_crosswalk = bool(crosswalk_path) and os.path.abspath(crosswalk_path) != default_crosswalk_abs
    requested_config = os.path.abspath(config_path) if config_path else default_config_abs
    requested_crosswalk = os.path.abspath(crosswalk_path) if crosswalk_path else default_crosswalk_abs

    env_config = os.environ.get('MEDICAFE_CONFIG_FILE', '').strip()
    if env_config:
        resolved_config = os.path.abspath(env_config)
        env_crosswalk = os.environ.get('MEDICAFE_CROSSWALK_FILE', '').strip()
        resolved_crosswalk = os.path.abspath(env_crosswalk) if env_crosswalk else os.path.join(os.path.dirname(resolved_config), 'crosswalk.json')
        return {
            'requested_config_path': requested_config,
            'requested_crosswalk_path': requested_crosswalk,
            'config_path': resolved_config,
            'crosswalk_path': resolved_crosswalk,
            'path_source': 'environment',
        }

    resolved_config = requested_config
    resolved_crosswalk = requested_crosswalk
    path_source = 'caller' if (explicit_config or explicit_crosswalk) else 'module_default'

    if (not explicit_config) and (not os.path.exists(resolved_config)):
        if platform.system() == 'Windows' and platform.release() == 'XP':
            resolved_config = "F:\\Medibot\\json\\config.json"
            if not explicit_crosswalk:
                resolved_crosswalk = "F:\\Medibot\\json\\crosswalk.json"
            path_source = 'windows_xp_fallback'
        elif platform.system() == 'Windows':
            current_dir = os.getcwd()
            resolved_config = os.path.join(current_dir, 'json', 'config.json')
            if not explicit_crosswalk:
                resolved_crosswalk = os.path.join(current_dir, 'json', 'crosswalk.json')
            path_source = 'windows_cwd_fallback'

    return {
        'requested_config_path': requested_config,
        'requested_crosswalk_path': requested_crosswalk,
        'config_path': resolved_config,
        'crosswalk_path': resolved_crosswalk,
        'path_source': path_source,
    }


def _new_file_diagnostic(label, path, format_name):
    return {
        'label': label,
        'path': os.path.abspath(path) if path else '',
        'format': format_name,
        'status': 'unknown',
        'message': '',
        'hint': '',
        'exists': False,
        'size_bytes': None,
        'fallback_used': False,
        'fallback_scope': '',
    }


def _decode_structured_text(raw_bytes, path, format_name):
    if raw_bytes.startswith(b'\xff\xfe') or raw_bytes.startswith(b'\xfe\xff'):
        decoder = 'utf-16'
    else:
        decoder = 'utf-8-sig'

    if (b'\x00' in raw_bytes) and decoder != 'utf-16':
        return None, {
            'status': 'decode_error',
            'message': '{} contains null bytes and does not look like UTF-8 text'.format(path),
            'hint': 'Re-save the file as UTF-8 JSON text; it may be corrupted or saved in the wrong encoding',
        }

    try:
        return raw_bytes.decode(decoder), {
            'status': 'decoded',
            'encoding': decoder,
        }
    except UnicodeDecodeError as e:
        return None, {
            'status': 'decode_error',
            'message': 'Cannot decode {} as {}: {}'.format(format_name, decoder, e),
            'hint': 'Re-save the file as UTF-8 text and remove any binary or non-text characters',
            'encoding': decoder,
        }
    except Exception as e:
        return None, {
            'status': 'decode_error',
            'message': 'Cannot decode {}: {}'.format(path, e),
            'hint': 'Re-save the file as UTF-8 text and verify the contents are not binary',
        }


def _load_mapping_file(path, label, required_root_key=None):
    format_name = 'yaml' if str(path or '').lower().endswith(('.yaml', '.yml')) else 'json'
    diagnostic = _new_file_diagnostic(label, path, format_name)

    if not path:
        diagnostic['status'] = 'missing'
        diagnostic['message'] = '{} path not provided'.format(label)
        diagnostic['hint'] = 'Provide a valid file path'
        return None, diagnostic

    diagnostic['exists'] = os.path.exists(path)
    if not diagnostic['exists']:
        diagnostic['status'] = 'missing'
        diagnostic['message'] = '{} file not found'.format(path)
        diagnostic['hint'] = 'Create the file or point MEDICAFE_CONFIG_FILE / MEDICAFE_CROSSWALK_FILE to the correct location'
        return None, diagnostic

    if format_name == 'yaml' and yaml is None:
        diagnostic['status'] = 'unsupported_format'
        diagnostic['message'] = 'PyYAML is required to load {}'.format(path)
        diagnostic['hint'] = 'Install PyYAML or switch the file to JSON'
        return None, diagnostic

    if format_name not in ('json', 'yaml'):
        diagnostic['status'] = 'unsupported_format'
        diagnostic['message'] = 'Unsupported configuration format for {}'.format(path)
        diagnostic['hint'] = 'Use .json, .yaml, or .yml files'
        return None, diagnostic

    try:
        with open(path, 'rb') as fh:
            raw_bytes = fh.read()
        diagnostic['size_bytes'] = len(raw_bytes)
    except Exception as e:
        diagnostic['status'] = 'unreadable'
        diagnostic['message'] = 'Cannot open {}: {}'.format(path, e)
        diagnostic['hint'] = 'Check file permissions, locks, and whether the path points to a file'
        return None, diagnostic

    if not raw_bytes:
        diagnostic['status'] = 'empty'
        diagnostic['message'] = '{} is empty'.format(path)
        diagnostic['hint'] = 'Restore the file contents or recreate it from a known-good copy'
        return None, diagnostic

    decoded_text, decode_diag = _decode_structured_text(raw_bytes, path, format_name)
    if decoded_text is None:
        diagnostic['status'] = decode_diag.get('status', 'decode_error')
        diagnostic['message'] = decode_diag.get('message', '')
        diagnostic['hint'] = decode_diag.get('hint', '')
        if decode_diag.get('encoding'):
            diagnostic['encoding'] = decode_diag.get('encoding')
        return None, diagnostic
    if decode_diag.get('encoding'):
        diagnostic['encoding'] = decode_diag.get('encoding')

    try:
        if format_name == 'yaml':
            loaded = yaml.safe_load(decoded_text)
        else:
            loaded = json.loads(decoded_text, object_pairs_hook=OrderedDict)
    except ValueError as e:
        diagnostic['status'] = 'invalid_syntax'
        diagnostic['message'] = '{} contains invalid {} syntax: {}'.format(path, format_name.upper(), e)
        diagnostic['hint'] = 'Fix the file syntax and remove any stray characters before retrying'
        return None, diagnostic
    except Exception as e:
        diagnostic['status'] = 'load_error'
        diagnostic['message'] = 'Unexpected error while parsing {}: {}'.format(path, e)
        diagnostic['hint'] = 'Validate the file contents and encoding'
        return None, diagnostic

    if loaded is None:
        diagnostic['status'] = 'empty'
        diagnostic['message'] = '{} does not contain any data'.format(path)
        diagnostic['hint'] = 'Populate the file with a JSON object'
        return None, diagnostic

    if not isinstance(loaded, dict):
        diagnostic['status'] = 'invalid_structure'
        diagnostic['message'] = '{} must contain a top-level object/dictionary'.format(path)
        diagnostic['hint'] = 'Wrap the file contents in a JSON object'
        return None, diagnostic

    diagnostic['status'] = 'loaded'
    diagnostic['message'] = '{} loaded successfully'.format(path)
    if required_root_key and required_root_key not in loaded:
        diagnostic['status'] = 'missing_required_key'
        diagnostic['message'] = '{} loaded, but required top-level key {!r} is missing'.format(path, required_root_key)
        diagnostic['hint'] = 'Add the missing key or merge in a known-good config.json'

    return loaded, diagnostic


def _apply_config_fallbacks(config, config_diag, crosswalk, crosswalk_diag):
    config_defaults = get_default_config()
    crosswalk_defaults = get_default_crosswalk()

    if not isinstance(config, dict):
        config = _copy_json_compatible(config_defaults)
        config_diag['fallback_used'] = True
        config_diag['fallback_scope'] = 'full_default_config'
    elif config_diag.get('status') == 'missing_required_key':
        config = _copy_json_compatible(config)
        config['MediLink_Config'] = _copy_json_compatible(config_defaults.get('MediLink_Config', {}))
        config_diag['fallback_used'] = True
        config_diag['fallback_scope'] = 'MediLink_Config_section'
    elif config_diag.get('status') != 'loaded':
        config = _copy_json_compatible(config_defaults)
        config_diag['fallback_used'] = True
        config_diag['fallback_scope'] = 'full_default_config'

    if not isinstance(crosswalk, dict) or crosswalk_diag.get('status') != 'loaded':
        crosswalk = _copy_json_compatible(crosswalk_defaults)
        crosswalk_diag['fallback_used'] = True
        crosswalk_diag['fallback_scope'] = 'full_default_crosswalk'

    return config, crosswalk


def _build_config_load_diagnostics(path_info, config_diag, crosswalk_diag):
    diagnostics = {
        'overall_status': 'ok',
        'path_source': path_info.get('path_source', ''),
        'requested_paths': {
            'config': path_info.get('requested_config_path', ''),
            'crosswalk': path_info.get('requested_crosswalk_path', ''),
        },
        'resolved_paths': {
            'config': path_info.get('config_path', ''),
            'crosswalk': path_info.get('crosswalk_path', ''),
        },
        'defaults_in_use': {
            'config': bool(config_diag.get('fallback_used')),
            'crosswalk': bool(crosswalk_diag.get('fallback_used')),
        },
        'config': _copy_json_compatible(config_diag),
        'crosswalk': _copy_json_compatible(crosswalk_diag),
        'summary_lines': [],
    }

    for diag in (config_diag, crosswalk_diag):
        label = diag.get('label', 'file')
        status = diag.get('status', 'unknown')
        message = diag.get('message', '')
        if status != 'loaded':
            diagnostics['overall_status'] = 'degraded'
            line = '{}: {}'.format(label, message or status)
            if diag.get('fallback_used'):
                if diag.get('fallback_scope'):
                    line += ' [fallback: {}]'.format(diag.get('fallback_scope'))
                else:
                    line += ' [fallback active]'
            diagnostics['summary_lines'].append(line)
        elif diag.get('fallback_used'):
            diagnostics['overall_status'] = 'degraded'
            diagnostics['summary_lines'].append(
                '{}: loaded with fallback adjustments ({})'.format(label, diag.get('fallback_scope') or 'partial defaults')
            )

    if diagnostics['overall_status'] == 'ok':
        diagnostics['summary_lines'].append('config and crosswalk loaded successfully')

    return diagnostics


def _format_config_load_diagnostics(diagnostics):
    try:
        lines = []
        lines.append('Configuration loader diagnostics:')
        if diagnostics.get('path_source'):
            lines.append('- path resolution: {}'.format(diagnostics.get('path_source')))
        resolved_paths = diagnostics.get('resolved_paths', {})
        if resolved_paths:
            lines.append('- config path: {}'.format(resolved_paths.get('config', '')))
            lines.append('- crosswalk path: {}'.format(resolved_paths.get('crosswalk', '')))
        for line in diagnostics.get('summary_lines', []):
            lines.append('- {}'.format(line))
        for key in ('config', 'crosswalk'):
            diag = diagnostics.get(key, {})
            hint = diag.get('hint', '')
            if hint and diag.get('status') != 'loaded':
                lines.append('- {} hint: {}'.format(key, hint))
        return '\n'.join(lines)
    except Exception:
        return 'Configuration loader diagnostics unavailable.'


def _log_config_load_diagnostics(diagnostics, config=None):
    if not isinstance(diagnostics, dict) or diagnostics.get('overall_status') == 'ok':
        return
    try:
        print(_format_config_load_diagnostics(diagnostics))
    except Exception:
        pass
    try:
        summary = 'Config loader degraded: {}'.format(' | '.join(diagnostics.get('summary_lines', [])))
        log(summary, config=config if isinstance(config, dict) else {}, level='WARNING')
    except Exception:
        pass


def get_last_load_diagnostics():
    """Return the most recent config/crosswalk load diagnostics snapshot."""
    global _CONFIG_LOAD_DIAGNOSTICS
    return _copy_json_compatible(_CONFIG_LOAD_DIAGNOSTICS) if _CONFIG_LOAD_DIAGNOSTICS is not None else {}

"""
This function should be generalizable to have a initialization script over all the Medi* functions
"""
def load_configuration(config_path=_DEFAULT_CONFIG_PATH, crosswalk_path=_DEFAULT_CROSSWALK_PATH):
    """
    Loads endpoint configuration, credentials, and other settings from JSON or YAML files.

    Returns: A tuple containing dictionaries with configuration settings for the main config and crosswalk.
    """
    global _CONFIG_CACHE, _CROSSWALK_CACHE, _CONFIG_LOAD_DIAGNOSTICS

    # Return cached configuration if available
    if _CONFIG_CACHE is not None and _CROSSWALK_CACHE is not None:
        return _CONFIG_CACHE, _CROSSWALK_CACHE

    import time
    config_start = time.time()
    if PERFORMANCE_LOGGING:
        print("Configuration loading started...")

    _repo = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    _storage = get_storage_path(repo_root=_repo) if get_storage_path else None
    run_id = start_run('config_loader', storage_path=_storage) if (start_run and is_timing_enabled and is_timing_enabled()) else None

    path_check_start = time.time()
    _path_ctx = stage_timer(run_id, 'config_loader', 'path_resolution') if (run_id and stage_timer) else noop_timer
    with _path_ctx:
        path_info = _resolve_requested_config_paths(config_path, crosswalk_path)
        config_path = path_info.get('config_path')
        crosswalk_path = path_info.get('crosswalk_path')
    path_check_end = time.time()
    if PERFORMANCE_LOGGING:
        print("Path resolution completed in {:.2f} seconds".format(path_check_end - path_check_start))

    _load_status = 'ok'

    config_load_start = time.time()
    _config_ctx = stage_timer(run_id, 'config_loader', 'config_parse') if (run_id and stage_timer) else noop_timer
    with _config_ctx:
        config, config_diag = _load_mapping_file(config_path, 'config', required_root_key='MediLink_Config')
    config_load_end = time.time()
    if PERFORMANCE_LOGGING:
        print("Config file loading completed in {:.2f} seconds".format(config_load_end - config_load_start))

    crosswalk_load_start = time.time()
    _crosswalk_ctx = stage_timer(run_id, 'config_loader', 'crosswalk_parse') if (run_id and stage_timer) else noop_timer
    with _crosswalk_ctx:
        crosswalk, crosswalk_diag = _load_mapping_file(crosswalk_path, 'crosswalk')
    crosswalk_load_end = time.time()
    if PERFORMANCE_LOGGING:
        print("Crosswalk file loading completed in {:.2f} seconds".format(crosswalk_load_end - crosswalk_load_start))

    config, crosswalk = _apply_config_fallbacks(config, config_diag, crosswalk, crosswalk_diag)
    try:
        _ensure_certificate_provider_section(config.get('MediLink_Config'))
    except Exception:
        pass

    _CONFIG_LOAD_DIAGNOSTICS = _build_config_load_diagnostics(path_info, config_diag, crosswalk_diag)
    if _CONFIG_LOAD_DIAGNOSTICS.get('overall_status') != 'ok':
        _load_status = 'degraded'
        _log_config_load_diagnostics(_CONFIG_LOAD_DIAGNOSTICS, config=config)

    config_end = time.time()
    if PERFORMANCE_LOGGING:
        print("Total configuration loading completed in {:.2f} seconds".format(config_end - config_start))
    if run_id and record_stage:
        record_stage(run_id, 'config_loader', 'load_total', int((config_end - config_start) * 1000), status=_load_status)

    # Cache the loaded configuration
    _CONFIG_CACHE = config
    _CROSSWALK_CACHE = crosswalk

    return config, crosswalk


def clear_config_cache():
    """Clear the configuration cache to force reloading on next call."""
    global _CONFIG_CACHE, _CROSSWALK_CACHE, _CONFIG_LOAD_DIAGNOSTICS
    _CONFIG_CACHE = None
    _CROSSWALK_CACHE = None
    _CONFIG_LOAD_DIAGNOSTICS = None



def _ensure_certificate_provider_section(medi_config):
    if not isinstance(medi_config, dict):
        return _copy_cert_provider_defaults()
    provider = medi_config.get('certificate_provider')
    if not isinstance(provider, dict):
        provider = _copy_cert_provider_defaults()
        medi_config['certificate_provider'] = provider
        return provider
    defaults = _copy_cert_provider_defaults()
    for key, value in defaults.items():
        if key not in provider:
            provider[key] = copy.deepcopy(value) if isinstance(value, (list, dict)) else value
    if not isinstance(provider.get('san'), list):
        provider['san'] = list(defaults['san'])
    return provider



def get_certificate_provider_config(source_config=None, use_cache=True):
    """
    Return certificate provider settings merged with defaults.
    Accepts either a full config dict or the MediLink_Config subsection.
    """
    try:
        config = source_config
        if config is None:
            config = _CONFIG_CACHE if use_cache and _CONFIG_CACHE else load_configuration()[0]
        if isinstance(config, dict):
            medi = config.get('MediLink_Config')
            if isinstance(medi, dict):
                provider = _ensure_certificate_provider_section(medi)
                return copy.deepcopy(provider)
            provider = _ensure_certificate_provider_section(config)
            return copy.deepcopy(provider)
    except Exception:
        pass
    return _copy_cert_provider_defaults()



def update_certificate_provider_config(new_values, config_path=None, create_backup=True):
    """
    Merge new certificate provider settings into config.json using atomic write semantics.

    Args:
        new_values (dict): Keys/values to merge into certificate_provider.
        config_path (str): Optional override path to config.json.
        create_backup (bool): Placeholder for future behavior (backups handled by editor helpers).

    Returns:
        (success, error_message)
    """
    if not isinstance(new_values, dict):
        return False, "new_values must be a dict"

    target_path = config_path or os.path.join(os.path.dirname(__file__), '..', 'json', 'config.json')
    if _editor_resolve_config_path:
        try:
            target_path = _editor_resolve_config_path(target_path)
        except Exception:
            pass

    if _editor_load_config_safe:
        config_data, load_err = _editor_load_config_safe(target_path)
        if load_err:
            config_data = copy.deepcopy(get_default_config())
    else:
        config_data = copy.deepcopy(load_configuration()[0])

    if 'MediLink_Config' not in config_data or not isinstance(config_data['MediLink_Config'], dict):
        config_data['MediLink_Config'] = {}
    provider = _ensure_certificate_provider_section(config_data['MediLink_Config'])
    for key, value in new_values.items():
        provider[key] = value
    _ensure_certificate_provider_section(config_data['MediLink_Config'])

    writer = _editor_save_config_atomic
    if writer:
        success, error = writer(target_path, config_data)
    else:
        try:
            temp_fd, temp_path = tempfile.mkstemp(suffix='.tmp', dir=os.path.dirname(target_path) or None)
            try:
                with os.fdopen(temp_fd, 'w', encoding='utf-8') as temp_file:
                    json.dump(config_data, temp_file, ensure_ascii=False, indent=4, separators=(',', ': '))
                if os.name == 'nt' and os.path.exists(target_path):
                    os.remove(target_path)
                os.rename(temp_path, target_path)
            except Exception:
                try:
                    os.close(temp_fd)
                except Exception:
                    pass
                if os.path.exists(temp_path):
                    os.remove(temp_path)
                raise
            success, error = True, None
        except Exception as write_err:
            success, error = False, "Error writing config: {}".format(write_err)

    if success:
        clear_config_cache()
    return success, error


def require_config_value(key_path, use_cache=True):
    # TODO This needs expanding a little bit but generally this type of functionality is good to have at this level.
    config = _CONFIG_CACHE if use_cache and _CONFIG_CACHE else load_configuration()[0]
    return reduce(lambda d, k: d[k], key_path.split('.'), config)


_RUN_LOG_TOKEN_ENV_KEYS = (
    'MEDICAFE_RUN_LOG_TOKEN',
    'MEDICAFE_SHADOW_PIPELINE_RUN_ID',
    'MEDICAFE_RUN_ID',
    'MEDICAFE_TIMING_RUN_ID',
)


def _sanitize_run_log_token(raw, max_len=96):
    """Return a filesystem-safe run token suffix."""
    if raw is None:
        return ''
    try:
        text = str(raw).strip()
    except Exception:
        return ''
    if not text:
        return ''
    cleaned = []
    for ch in text:
        if ch.isalnum() or ch in ('-', '_', '.'):
            cleaned.append(ch)
    token = ''.join(cleaned).strip('._-')
    if not token:
        return ''
    return token[:max_len]


def _resolve_run_log_token():
    """Resolve optional run token for appended run-log naming."""
    for key in _RUN_LOG_TOKEN_ENV_KEYS:
        token = _sanitize_run_log_token(os.environ.get(key, ''))
        if token:
            return token
    return ''


def _build_run_log_filename(date_token, run_index, run_token=''):
    """Build run log filename with optional token suffix."""
    base = 'Log_{0}_run{1:03d}'.format(date_token, run_index)
    token = _sanitize_run_log_token(run_token)
    if token:
        return '{0}_{1}.log'.format(base, token)
    return '{0}.log'.format(base)


def _latest_path_by_mtime(paths):
    """Return newest existing path from candidates."""
    newest_path = None
    newest_mtime = None
    for path in paths or []:
        try:
            if not os.path.isfile(path):
                continue
            mtime = os.path.getmtime(path)
            if newest_path is None or mtime > newest_mtime:
                newest_path = path
                newest_mtime = mtime
        except Exception:
            continue
    return newest_path


def _list_log_paths(local_storage_path, require_log_prefix=True):
    """List candidate log files from storage path."""
    try:
        entries = os.listdir(local_storage_path)
    except Exception:
        entries = []
    out = []
    for name in entries:
        try:
            if not name.lower().endswith('.log'):
                continue
            if require_log_prefix and not name.startswith('Log_'):
                continue
            path = os.path.join(local_storage_path, name)
            if os.path.isfile(path):
                out.append(path)
        except Exception:
            continue
    return out


def _resolve_current_run_log_candidate(local_storage_path, expected_path):
    """Resolve current-run path, including appended-token compat matches."""
    if expected_path and os.path.isfile(expected_path):
        return expected_path
    if not expected_path:
        return None
    try:
        expected_name = os.path.basename(expected_path)
        expected_stem = os.path.splitext(expected_name)[0]
    except Exception:
        return None
    candidates = []
    for path in _list_log_paths(local_storage_path, require_log_prefix=True):
        try:
            name = os.path.basename(path)
            if name == expected_name or name.startswith(expected_stem + '_'):
                candidates.append(path)
        except Exception:
            continue
    return _latest_path_by_mtime(candidates)


def resolve_current_run_log_path(local_storage_path):
    """Public helper to resolve current-process run log target path."""
    return _resolve_run_log_filepath(local_storage_path)


def select_preferred_run_log_path(local_storage_path, include_any_log_fallback=False):
    """
    Select best log path with run-scoped preference and bounded fallback.

    Returns a dict:
      - selected_log_path
      - selected_log_name
      - selected_log_selection_strategy
      - app_log_run_id
      - run_log_expected_path
    """
    result = {
        'selected_log_path': '',
        'selected_log_name': '',
        'selected_log_selection_strategy': 'none',
        'app_log_run_id': str(os.environ.get('MEDICAFE_RUN_LOG_ID', '') or '').strip(),
        'run_log_expected_path': '',
    }
    if not local_storage_path:
        local_storage_path = '.'

    expected_path = None
    try:
        expected_path = _resolve_run_log_filepath(local_storage_path)
        result['run_log_expected_path'] = expected_path or ''
        result['app_log_run_id'] = str(os.environ.get('MEDICAFE_RUN_LOG_ID', '') or '').strip()
    except Exception:
        expected_path = None

    current_run = _resolve_current_run_log_candidate(local_storage_path, expected_path)
    if current_run:
        result['selected_log_path'] = current_run
        try:
            result['selected_log_name'] = os.path.basename(current_run)
        except Exception:
            result['selected_log_name'] = ''
        result['selected_log_selection_strategy'] = 'current_process_run_log'
        return result

    latest_prefixed = _latest_path_by_mtime(_list_log_paths(local_storage_path, require_log_prefix=True))
    if latest_prefixed:
        result['selected_log_path'] = latest_prefixed
        try:
            result['selected_log_name'] = os.path.basename(latest_prefixed)
        except Exception:
            result['selected_log_name'] = ''
        result['selected_log_selection_strategy'] = 'latest_modified_fallback'
        return result

    if include_any_log_fallback:
        latest_any = _latest_path_by_mtime(_list_log_paths(local_storage_path, require_log_prefix=False))
        if latest_any:
            result['selected_log_path'] = latest_any
            try:
                result['selected_log_name'] = os.path.basename(latest_any)
            except Exception:
                result['selected_log_name'] = ''
            result['selected_log_selection_strategy'] = 'latest_any_log_fallback'
            return result

    return result



def _extract_daily_run_index(filename, date_token):
    """Parse Log_MMDDYYYY_runNNN*.log filenames and return run index."""
    prefix = 'Log_{0}_run'.format(date_token)
    if not filename.startswith(prefix):
        return None
    if not filename.lower().endswith('.log'):
        return None
    suffix = filename[len(prefix):-4]
    digits = []
    for ch in suffix:
        if ch.isdigit():
            digits.append(ch)
        else:
            break
    if not digits:
        return None
    try:
        return int(''.join(digits))
    except Exception:
        return None



def _next_daily_run_index(local_storage_path, date_token):
    """Find next per-day run index for log filename suffix."""
    max_index = 0
    try:
        entries = os.listdir(local_storage_path)
    except Exception:
        entries = []
    for name in entries:
        idx = _extract_daily_run_index(name, date_token)
        if idx and idx > max_index:
            max_index = idx
    return max_index + 1



def _resolve_run_log_filepath(local_storage_path):
    """Resolve per-run log file path: Log_MMDDYYYY_runNNN.log."""
    global _RUN_LOG_FILEPATH
    if _RUN_LOG_FILEPATH:
        return _RUN_LOG_FILEPATH
    date_token = datetime.now().strftime("%m%d%Y")
    run_id_raw = str(os.environ.get('MEDICAFE_RUN_LOG_ID', '') or '').strip()
    run_index = None
    if run_id_raw.isdigit():
        try:
            run_index = int(run_id_raw)
        except Exception:
            run_index = None
    if run_index is None or run_index <= 0:
        run_index = _next_daily_run_index(local_storage_path, date_token)
        os.environ['MEDICAFE_RUN_LOG_ID'] = str(run_index)
    filename = _build_run_log_filename(date_token, run_index, run_token=_resolve_run_log_token())
    _RUN_LOG_FILEPATH = os.path.join(local_storage_path, filename)
    return _RUN_LOG_FILEPATH

# Logs messages with optional error type and claim data.
def log(message, config=None, level="INFO", error_type=None, claim=None, verbose=False, console_output=False):

    # Check for environment variable to override verbose setting (session-level control)
    if not verbose:
        env_verbose = os.environ.get('MEDICAFE_VERBOSE_LOGGING', '').strip().lower()
        if env_verbose in ('1', 'true', 'yes', 'on'):
            verbose = True

    # If config is not provided, use cached config or load it
    if config is None:
        try:
            if _CONFIG_CACHE is None:
                config, _ = load_configuration()
            else:
                config = _CONFIG_CACHE
        except BaseException:
            # Configuration unavailable; fall back to minimal console logging
            config = {}

    # Setup logger if not already configured
    if not logging.root.handlers:
        local_storage_path = '.'
        if isinstance(config, dict) and config:
            try:
                local_storage_path = config.get('MediLink_Config', {}).get('local_storage_path', '') or '.'
            except Exception:
                local_storage_path = '.'
        if local_storage_path == '.':
            _base = os.environ.get('MEDICAFE_BOOTSTRAP_LOG_DIR', '').strip()
            local_storage_path = os.path.abspath(_base) if _base else os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
        log_filepath = _resolve_run_log_filepath(local_storage_path)

        # Set logging level based on verbosity
        logging_level = logging.DEBUG if verbose else logging.INFO

        # Create formatter
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')

        handlers = []
        try:
            # Create file handler when path is usable
            file_handler = logging.FileHandler(log_filepath, mode='a')
            file_handler.setFormatter(formatter)
            handlers.append(file_handler)
        except Exception:
            # Fall back to console-only if file handler cannot be created
            pass

        # Add console handler only if console_output is True
        if console_output:
            console_handler = logging.StreamHandler()
            console_handler.setFormatter(formatter)
            handlers.append(console_handler)

        # If no handlers could be added (e.g., file path invalid and console_output False), add a console handler
        if not handlers:
            console_handler = logging.StreamHandler()
            console_handler.setFormatter(formatter)
            handlers.append(console_handler)

        logging.basicConfig(level=logging_level, handlers=handlers)
    else:
        # Logger already configured; update level if verbose mode changed
        if verbose:
            logger = logging.getLogger()
            logger.setLevel(logging.DEBUG)
            # Update all handlers to DEBUG level
            for handler in logger.handlers:
                handler.setLevel(logging.DEBUG)

    # Prepare log message
    claim_data = " - Claim Data: {}".format(claim) if claim else ""
    error_info = " - Error Type: {}".format(error_type) if error_type else ""
    full_message = "{} {}{}".format(message, claim_data, error_info)

    # Log the message
    logger = logging.getLogger()
    getattr(logger, level.lower())(full_message)
