BUILD_SHA = "github.com/bihua-university/bhu-cli@d2aace28e2ee"
