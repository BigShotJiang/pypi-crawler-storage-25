# ------------------------------------------------------------------------------
# Project: IFE_Surrogate
# Authors: Tobias Leitgeb, Julian Tischler
# CD Lab 2025
# ------------------------------------------------------------------------------
from ife_surrogate.gp.models.gp_model import GPModel
from ife_surrogate.gp.train import train, train_scipy, train_swarm
from ife_surrogate.gp.likelihood import nlml_scalar
from ife_surrogate.gp.inference import predictive_mean_var_scalar
from ife_surrogate.gp.kernels import Kernel

from jaxtyping import Key, Array, Int, Bool
from typing import Tuple, Dict
import typing
import jax.numpy as jnp
import numpyro
import optax
import numpyro.distributions as dist
from numpyro.infer import MCMC, NUTS


TypeKernel = typing.TypeVar("Kernel", bound=Kernel)


class ScalarGP(GPModel):
    r"""
    Scalar Gaussian Process (GP) model for scalar regression tasks.

    This model implements the standard Gaussian Process framework for 
    non-parametric Bayesian regression as described in [1].

    .. math::
        f(\mathbf{x}) \sim \mathcal{GP}(0, k(\mathbf{x}, \mathbf{x}'))

    Parameters
    ----------
    X : Array
        Training input data of shape (n_samples, n_features).
    Y : Array
        Training output data of shape (n_samples, 1).
    kernel : Kernel
        Instance of a kernel class defining the covariance structure.

    References
    ----------
    .. [1] Rasmussen, C. E., & Williams, C. K. I. (2006). Gaussian Processes 
    for Machine Learning. MIT Press. http://www.GaussianProcess.org/gpml
    """

    def __init__(self, X: Array, Y: Array, kernel: TypeKernel):
        assert X.shape[0] == Y.shape[0] , "X and Y should have the same number of samples"
        assert Y.shape[1] == 1, "Y should be a matrix with shape (N, 1) N: #samples"
        super().__init__(kernel, X, Y)
        self.likelihood = nlml_scalar
        self.jitter = 1e-6
       
    def train(
        self, 
        key: Key,
        optim_dictionary: Dict={"opt": optax.adam, "settings": {"learning_rate": 1e-4}}, 
        n_steps: Int =1000, 
        n_restarts: int=10, 
        save_history: Bool=False, 
        verbose: Bool=False
    ) -> Tuple:
        """
        Optimize kernel parameters by minimizing the negative marginal log-likelihood using gradient-based optimizers.

        Parameters
        ----------
        key : Key
            Random key for parameter initialization and restarts.
        optim_dictionary : Dict, optional
            Dictionary containing the optimizer class (`"opt"`) and its settings (`"settings"`).
        num_steps : int, optional
            Number of optimization steps for each restart.
        number_restarts : int, optional
            Number of independent optimization restarts with different initializations.
        save_history : bool, optional
            If True, saves the full optimization trajectory (parameter history).
        verbose : bool, optional
            If True, prints optimization progress.

        Returns
        -------
        Tuple
            Optimized parameters and, if requested, parameter history.
        """
        self.optimized_parameters, self.parameter_history = train(
            self, key, optim_dictionary, n_steps, n_restarts, save_history, verbose
        )
        self.kernel.update_params(self.optimized_parameters["params"])
        return self.optimized_parameters, self.parameter_history

    def train_scipy(self, 
        key: Key, 
        number_restarts: int=1, 
        opt_algorithm: Dict={"method":"L-BFGS-B"},
        save_history: Bool=False, 
        verbose: Bool=True
    ) -> Tuple:
        """
        Optimize kernel parameters using a scipy-based optimizer (e.g., L-BFGS-B).

        Parameters
        ----------
        key : Key
            Random key for parameter initialization and restarts.
        number_restarts : int, optional
            Number of independent optimization restarts with different initializations.
        opt_algorithm : Dict, optional
            Dictionary specifying the optimization method and settings (e.g., `"method": "L-BFGS-B"`).
        save_history : bool, optional
            If True, saves the full optimization trajectory.
        verbose : bool, optional
            If True, prints optimization progress.

        Returns
        -------
        Tuple
            Optimized parameters and, if requested, parameter history.
        """
        self.optimized_parameters, self.parameter_history = train_scipy(
            self, key, number_restarts, opt_algorithm, save_history, verbose
        )
        self.kernel.update_params(self.optimized_parameters["params"])
        return self.optimized_parameters, self.parameter_history
    
    def train_swarm(
        self,
        key: Key,
        bounds: Tuple[Array, Array] = (),
        optimizer: Dict = {"c1": 0.5, "c2": 0.3, "w": 0.9},
        n_restarts: Int = 1,
        n_particles: Int = 20,
        n_iterations: Int = 100,
        save_history: bool = False,
        verbose: bool = True
    ) -> Tuple:
        """
        Trains the model using PySwarms particle swarm optimizer.
        """
        self.optimized_parameters, self.parameter_history = train_swarm(
            self, key, bounds, optimizer, n_restarts, n_particles, n_iterations, save_history, verbose
        )
        self.kernel.update_params(self.optimized_parameters["params"])
        return self.optimized_parameters, self.parameter_history

    def train_mcmc(
        self, 
        key: Key, 
        num_warmup: int = 500, 
        num_samples: int = 1000, 
        num_chains: int = 1
    ) -> Dict[str, Array]:
        r"""
        Fully Bayesian training using the No-U-Turn Sampler (NUTS) via NumPyro.

        This function defines the joint distribution over the observations and the 
        kernel hyperparameters, following the standard GP regression framework [1].

        .. math:: 
        
             p(\mathbf{y} \mid \mathbf{X}, \boldsymbol{\theta}) p(\boldsymbol{\theta})

        By specifying priors over hyperparameters and a Gaussian Process likelihood, 
        we enable NumPyro to perform inference and approximate the posterior over 
        kernel parameters via NUTS [2]:

        .. math::

            p(\boldsymbol{\theta} \mid \mathcal{D}) \propto 
            p(\mathbf{y} \mid \mathbf{X}, \boldsymbol{\theta}) \, p(\boldsymbol{\theta})

        where:

        - :math:`p(\boldsymbol{\theta})` are the user-defined priors over kernel parameters,
        - :math:`p(\mathbf{y} \mid \mathbf{X}, \boldsymbol{\theta})` is the GP marginal likelihood:


        The inference is accelerated using the JAX backend [3] and the 
        NumPyro probabilistic programming library [4].

        Parameters
        ----------
        key : Key
            Random key for sampling initialization.
        num_warmup : int, optional
            Number of warmup (burn-in) steps for the NUTS sampler.
        num_samples : int, optional
            Number of posterior samples to draw after warmup.
        num_chains : int, optional
            Number of independent MCMC chains to run.

        Returns
        -------
        Dict[str, Array]
            A dictionary containing the posterior samples for each hyperparameter.

        References
        ----------
        .. [1] Rasmussen, C. E., & Williams, C. K. I. (2006). Gaussian Processes 
           for Machine Learning. MIT Press.
        .. [2] Hoffman, M. D., & Gelman, A. (2014). The No-U-Turn sampler: 
           adaptively setting path lengths in Hamiltonian Monte Carlo. JMLR.
        .. [3] Bradbury, J., et al. (2018). JAX: composable transformations of 
           Python+NumPy programs.
        .. [4] Phan, D., Pradhan, N., & Jankowiak, M. (2019). Composable Effects 
           for Flexible and Accelerated Probabilistic Programming in NumPyro.
        """

        def gp_numpyro_model(X, Y, kernel, jitter):
            "Numpyro model for the scalar GP"
            priors = kernel.get_priors()
            current_params = kernel.get_params()
            sampled_params = {}
            
            # Sample each hyperparameter dynamically (with ARD support for multi-dim)
            for param_name, prior_dist in priors.items():
                param_shape = current_params[param_name].shape
                if param_shape and param_shape[0] > 1:
                    sampled_params[param_name] = numpyro.sample(
                        param_name, prior_dist.expand(param_shape)
                    )
                else:
                    sampled_params[param_name] = numpyro.sample(param_name, prior_dist)
            
            # Temporarily update kernel with the current MCMC sample step
            kernel.update_params(sampled_params)
            
            # Compute Covariance Matrix K
            N = X.shape[0]
            K = kernel(X, X) + jitter * jnp.eye(N)
            
            # The fully Bayesian Gaussian Likelihood observation
            numpyro.sample(
                "Y", 
                dist.MultivariateNormal(loc=jnp.zeros(N), covariance_matrix=K), 
                obs=Y.squeeze()
            )

        # Setup and run NUTS sampler
        kernel_nuts = NUTS(gp_numpyro_model)
        self.mcmc = MCMC(
            kernel_nuts, 
            num_warmup=num_warmup, 
            num_samples=num_samples, 
            num_chains=num_chains,
            progress_bar=True
        )
        
        print(f"Running MCMC with {num_samples} samples and {num_chains} chain(s)...")
        self.mcmc.run(key, self.X, self.Y, self.kernel, self.jitter)
        
        # Extract posterior samples
        self.posterior_samples = self.mcmc.get_samples()
        
        # Set kernel parameters to the posterior mean as a clean default point-estimate
        mean_params = {k: jnp.mean(v, axis=0) for k, v in self.posterior_samples.items()}
        self.kernel.update_params(mean_params)
        self.optimized_parameters = {"params": mean_params}
        
        return self.posterior_samples

    def predict(self, X_test: Array) -> Tuple[Array, Array]:
        """
        Predict the mean and variance for the given test inputs.

        Parameters
        ----------
        X_test : Array
            Test input data of shape (n_test_samples, n_features).

        Returns
        -------
        Tuple[Array, Array]
            Mean predictions and variances for each output dimension.
            Shapes: (n_test_samples, n_outputs)
        """ 
        X_test = jnp.atleast_2d(X_test)
        mean, var = predictive_mean_var_scalar(
            self.X, self.Y, self.kernel, self.jitter, X_test 
        )
        return mean, var

    def predict_mcmc(self, X_test: Array) -> Tuple[Array, Array]:
        """
        Predictive mean and variance marginalized over all posterior MCMC samples.
        Provides a true fully Bayesian prediction incorporating hyperparameter uncertainty.

        Parameters
        ----------
        X_test : Array
            Test input data of shape (n_test_samples, n_features).

        Returns
        -------
        Tuple[Array, Array]
            Marginalized mean predictions and variances.
        """
        if not hasattr(self, 'posterior_samples'):
            raise ValueError("You must run train_mcmc() before calling predict_mcmc().")
            
        X_test = jnp.atleast_2d(X_test)
        
        all_means = []
        all_vars = []
        
        # Extract the total number of MCMC samples generated
        num_samples = len(list(self.posterior_samples.values())[0])
        
        # Iterate over all MCMC samples to compute the predictions per sample
        for i in range(num_samples):
            sample_params = {k: v[i] for k, v in self.posterior_samples.items()}
            self.kernel.update_params(sample_params)
            
            mean, var = self.predict(X_test)
            all_means.append(mean)
            all_vars.append(var)
            
        all_means = jnp.array(all_means) # Shape: (samples, N_test, 1)
        all_vars = jnp.array(all_vars)   # Shape: (samples, N_test)
        
        # Marginalize over the posterior using the Law of Total Expectation / Variance
        expected_mean = jnp.mean(all_means, axis=0)
        expected_var = jnp.mean(all_vars, axis=0) + jnp.var(all_means, axis=0)
        
        # Reset the kernel back to the posterior mean to keep state consistent
        self.kernel.update_params(self.optimized_parameters["params"])
        
        return expected_mean, expected_var
   
    def log_marginal_likelihood(self):
        """
        Compute the (negative) log marginal likelihood of the current model.

        Returns
        -------
        float
            The negative log marginal likelihood value.
        """
        return self.likelihood(self.X, self.Y, self.jitter, self.kernel)

    def sample_posterior(self, key: Key, X: Array, n_samples: Int) -> Array:
        """
        Sample from the posterior distribution at new input locations.

        Parameters
        ----------
        key : Key
            Random key for sampling.
        X : Array
            Input locations where to sample the posterior.
        n_samples : int
            Number of posterior samples to draw.

        Returns
        -------
        Array
            Posterior samples of shape (n_samples, n_test_samples, n_outputs).
        """
        return NotImplementedError
    
    def sample_prior(self, key: Key, X: Array, n_samples: Int) -> Array:
        """
        Sample from the prior distribution at new input locations.

        Parameters
        ----------
        key : Key
            Random key for sampling.
        X : Array
            Input locations where to sample the prior.
        n_samples : int
            Number of prior samples to draw.

        Returns
        -------
        Array
            Prior samples of shape (n_samples, n_test_samples, n_outputs).
        """
        return NotImplementedError

    def save(self, path: str):
        """
        Save the model parameters to a file.

        Parameters
        ----------
        path : str
            Path where the model parameters should be saved.
        """
        return NotImplementedError