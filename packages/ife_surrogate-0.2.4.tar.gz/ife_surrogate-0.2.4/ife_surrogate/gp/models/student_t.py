# ------------------------------------------------------------------------------
# Project: IFE_Surrogate
# Authors: Tobias Leitgeb, Julian Tischler
# CD Lab 2025
# ------------------------------------------------------------------------------
from ife_surrogate.gp.models.gp_model import GPModel
from ife_surrogate.gp.train import train_scipy, train, train_swarm
from ife_surrogate.gp.kernels import Kernel
from ife_surrogate.gp.likelihood import nlml_student_t_scalar
from ife_surrogate.gp.inference import predictive_mean_var_student_t

from jaxtyping import Key, Array, Bool, Int
from typing import Tuple, Dict
import typing
import jax.numpy as jnp
import optax
from jax import lax, jit
import numpyro
import numpyro.distributions as dist
from numpyro.infer import MCMC, NUTS

TypeKernel = typing.TypeVar("Kernel", bound=Kernel)


class ScalarTP(GPModel):
    r"""
    Scalar Student-t Process (TP) model for robust regression.

    This model implements the Student-t Process as a consistent alternative 
    to Gaussian Processes, providing increased robustness to outliers [1].

    .. math::
        f(\mathbf{x}) \sim \mathcal{TP}(\nu, 0, k(\mathbf{x}, \mathbf{x}'))

    As :math:`\nu \to \infty`, the Student-t Process converges to a 
    standard Gaussian Process [2].

    Parameters
    ----------
    nu : float
        Degrees of freedom (:math:`\nu > 2`). Controls the "heaviness" of 
        the tails. Values :math:`\nu < 20` provide significant robustification 
        against outliers, while :math:`\nu > 30` closely approximates 
        a Gaussian distribution.
    X : Array
        Training input data of shape (n_samples, n_features).
    Y : Array
        Training output data of shape (n_samples, 1).
    kernel : Kernel
        Instance of a kernel class defining the covariance structure.

    References
    ----------
    .. [1] Shah, A., Wilson, A. G., & Ghahramani, Z. (2014). Student-t Processes 
    as Alternatives to Gaussian Processes. AISTATS.
    .. [2] Rasmussen, C. E., & Williams, C. K. I. (2006). Gaussian Processes 
    for Machine Learning. MIT Press.
    """
    def __init__(self, X: Array, Y: Array, kernel: TypeKernel, nu: float = 3.0):
        super().__init__(kernel, X, Y)
        self.nu = nu
        self.jitter = 1e-6
        
        # We wrap the TP likelihood so it matches the signature expected by the trainers
        self.likelihood = lambda x, y, j, k: nlml_student_t_scalar(x, y, j, k, nu=self.nu)

    def predict(self, X_test: Array) -> Tuple[Array, Array]:
        X_test = jnp.atleast_2d(X_test)
        mean, var = predictive_mean_var_student_t(
            self.X, self.Y, self.kernel, self.jitter, X_test, nu=self.nu
        )
        return mean, var

    def train(
        self, 
        key: Key,
        optim_dictionary: Dict={"opt": optax.adam, "settings": {"learning_rate": 1e-2}}, 
        n_steps: Int = 1000, 
        n_restarts: int = 1, 
        save_history: Bool = False, 
        verbose: Bool = False
    ) -> Tuple:
        """
        Optimize kernel parameters by minimizing the negative marginal log-likelihood 
        using gradient-based Optax optimizers (e.g., Adam).
        """
        self.optimized_parameters, self.parameter_history = train(
            self, key, optim_dictionary, n_steps, n_restarts, save_history, verbose
        )
        self.kernel.update_params(self.optimized_parameters["params"])
        return self.optimized_parameters, self.parameter_history
    
    def train_scipy(self, 
        key: Key, 
        number_restarts: int=1, 
        opt_algorithm: Dict={"method":"L-BFGS-B"},
        save_history: Bool=False, 
        verbose: Bool=True
    ) -> Tuple:
        """
        Optimize kernel parameters using a scipy-based optimizer (e.g., L-BFGS-B).
        """
        self.optimized_parameters, self.parameter_history = train_scipy(
            self, key, number_restarts, opt_algorithm, save_history, verbose
        )
        self.kernel.update_params(self.optimized_parameters["params"])
        return self.optimized_parameters, self.parameter_history

    def train_swarm(
        self,
        key: Key,
        bounds: Tuple[Array, Array] = (),
        optimizer: Dict = {"c1": 0.5, "c2": 0.3, "w": 0.9},
        n_restarts: Int = 1,
        n_particles: Int = 20,
        n_iterations: Int = 100,
        save_history: bool = False,
        verbose: bool = True
    ) -> Tuple:
        """
        Trains the model using PySwarms particle swarm optimizer.
        """
        self.optimized_parameters, self.parameter_history = train_swarm(
            self, key, bounds, optimizer, n_restarts, n_particles, n_iterations, save_history, verbose
        )
        self.kernel.update_params(self.optimized_parameters["params"])
        return self.optimized_parameters, self.parameter_history
    
    def train_mcmc(
        self, 
        key: Key, 
        num_warmup: int = 500, 
        num_samples: int = 1000, 
        num_chains: int = 1
    ) -> Dict[str, Array]:
        r"""
        Fully Bayesian training for the Student-t Process using NUTS via NumPyro.

        This function defines the joint distribution over the observations, the 
        kernel hyperparameters, and the degrees of freedom :math:`\nu`, which 
        controls the heavy-tailed nature of the process [1].

        .. math:: 
        
             p(\mathbf{y}, \boldsymbol{\theta}, \nu \mid \mathbf{X}) \propto p(\mathbf{y} \mid \mathbf{X}, \boldsymbol{\theta}, \nu) \, p(\boldsymbol{\theta}) \, p(\nu)

        By specifying priors over hyperparameters and a Student-t Process (TP) 
        likelihood, we enable NumPyro to perform inference and approximate the 
        posterior over parameters via the No-U-Turn Sampler (NUTS)[2]:

        .. math::

            p(\boldsymbol{\theta}, \nu \mid \mathcal{D}) \propto 
            p(\mathbf{y} \mid \mathbf{X}, \boldsymbol{\theta}, \nu) \, p(\boldsymbol{\theta}) \, p(\nu)

        where:

        - :math:`p(\boldsymbol{\theta})` and :math:`p(\nu)` are user-defined priors,
        - :math:`p(\mathbf{y} \mid \mathbf{X}, \boldsymbol{\theta}, \nu)` is the TP marginal likelihood:


        The Student-t Process generalizes the Gaussian Process. As 
        :math:`\nu \to \infty`, the marginal likelihood converges to the standard 
        Gaussian Process framework described by Rasmussen & Williams [3].

        The inference is accelerated using the JAX backend and the 
        NumPyro probabilistic programming library [4, 5].

        Parameters
        ----------
        key : Key
            Random key for sampling initialization.
        num_warmup : int, optional
            Number of warmup (burn-in) steps for the NUTS sampler.
        num_samples : int, optional
            Number of posterior samples to draw after warmup.
        num_chains : int, optional
            Number of independent MCMC chains to run.

        Returns
        -------
        Dict[str, Array]
            A dictionary containing the posterior samples for kernel 
            hyperparameters and the :math:`\nu` parameter.

        References
        ----------
        .. [1] Shah, A., Wilson, A. G., & Ghahramani, Z. (2014). Student-t Processes 
           as Alternatives to Gaussian Processes. AISTATS.
        .. [2] Hoffman, M. D., & Gelman, A. (2014). The No-U-Turn sampler: 
           adaptively setting path lengths in Hamiltonian Monte Carlo. JMLR.
        .. [3] Rasmussen, C. E., & Williams, C. K. I. (2006). Gaussian Processes 
           for Machine Learning. MIT Press.
        .. [4] Bradbury, J., et al. (2018). JAX: composable transformations of 
           Python+NumPy programs.
        .. [5] Phan, D., Pradhan, N., & Jankowiak, M. (2019). Composable Effects 
           for Flexible and Accelerated Probabilistic Programming in NumPyro.
        """
        #internal generative model for NumPyro
        def tp_numpyro_model(X, Y, kernel, nu, jitter):
            priors = kernel.get_priors()
            current_params = kernel.get_params()
            sampled_params = {}
            
            # Sample each hyperparameter dynamically from its assigned prior
            for param_name, prior_dist in priors.items():
                param_shape = current_params[param_name].shape
                
                # If the parameter is multi-dimensional (e.g., d > 1 for lengthscale), 
                # we expand the prior distribution to draw 'd' independent samples
                if param_shape and param_shape[0] > 1:
                    sampled_params[param_name] = numpyro.sample(
                        param_name, 
                        prior_dist.expand(param_shape)
                    )
                else:
                    # Fallback for scalar parameters like 'noise' or 1D lengthscales
                    sampled_params[param_name] = numpyro.sample(param_name, prior_dist)
            # Temporarily update kernel with the current MCMC sample step
            kernel.update_params(sampled_params)
            
            # Compute Covariance Matrix K
            N = X.shape[0]
            K = kernel(X, X) + jitter * jnp.eye(N)
            
            # Cholesky factorization for NumPyro's distribution
            L = jnp.linalg.cholesky(K)
            
            # The fully Bayesian Student-t Likelihood observation
            numpyro.sample(
                "Y", 
                dist.MultivariateStudentT(df=nu, loc=jnp.zeros(N), scale_tril=L), 
                obs=Y.squeeze()
            )

        # 2. Setup the NUTS sampler
        kernel_nuts = NUTS(tp_numpyro_model)
        self.mcmc = MCMC(
            kernel_nuts, 
            num_warmup=num_warmup, 
            num_samples=num_samples, 
            num_chains=num_chains,
            progress_bar=True
        )
        
        # 3. Run the MCMC simulation
        print(f"Running MCMC with {num_samples} samples and {num_chains} chain(s)...")
        self.mcmc.run(key, self.X, self.Y, self.kernel, self.nu, self.jitter)
        
        # 4. Extract posterior samples
        self.posterior_samples = self.mcmc.get_samples()
        
        # 5. Set kernel parameters to the posterior mean as a clean default point-estimate
        mean_params = {k: jnp.mean(v, axis=0) for k, v in self.posterior_samples.items()}
        self.kernel.update_params(mean_params)
        self.optimized_parameters = {"params": mean_params}
        
        return self.posterior_samples

    def predict_mcmc(self, X_test: Array) -> Tuple[Array, Array]:
        """
        Predictive mean and variance marginalized over all posterior MCMC samples.
        Provides a true fully Bayesian prediction incorporating hyperparameter uncertainty.

        Parameters
        ----------
        X_test : Array
            Test input locations of shape (n_test, n_features).

        Returns
        -------
        mean : Array
            The predictive mean averaged over all posterior samples.
        variance : Array
            The predictive variance incorporating both the process noise and 
            hype
        """
        if not hasattr(self, 'posterior_samples'):
            raise ValueError("You must run train_mcmc() before calling predict_mcmc().")
            
        X_test = jnp.atleast_2d(X_test)
        
        all_means = []
        all_vars = []
        
        # Extract the total number of MCMC samples generated
        num_samples = len(list(self.posterior_samples.values())[0])
        
        # Iterate over all MCMC samples to compute the predictions per sample
        for i in range(num_samples):
            sample_params = {k: v[i] for k, v in self.posterior_samples.items()}
            self.kernel.update_params(sample_params)
            
            mean, var = self.predict(X_test)
            all_means.append(mean)
            all_vars.append(var)
            
        all_means = jnp.array(all_means) # Shape: (samples, N_test, 1)
        all_vars = jnp.array(all_vars)   # Shape: (samples, N_test)
        
        # Marginalize over the posterior using the Law of Total Expectation / Variance
        expected_mean = jnp.mean(all_means, axis=0)
        expected_var = jnp.mean(all_vars, axis=0) + jnp.var(all_means, axis=0)
        
        # Reset the kernel back to the posterior mean to keep state consistent
        self.kernel.update_params(self.optimized_parameters["params"])
        
        return expected_mean, expected_var
    



class WidebandTP(GPModel):
    r"""
    Wideband Student-t Process (TP) model for multi-output regression tasks.

    This model extends the Wideband Gaussian Process architecture to a 
    Student-t Process framework, providing a prior 
    over vector-valued functions[1, 2]. It integrates the structural 
    simultaneous frequency inference of the Gaussian Process Wideband model
    with the heavy-tailed flexibility of the Student-t distribution [3].

    .. math::
        \mathbf{y} \sim \text{MVT}_{n \times p}(\nu, \mathbf{0}, K_{\text{wideband}} + \sigma^2 I)

    Unlike a standard GP, the TP allows for better handling of outliers and 
    predictive covariances that explicitly depend on the values of training 
    observations[cite: 8, 40]. The model converges to a Wideband GP as 
    :math:`\nu \to \infty`[cite: 115].

        Parameters
    ----------
    X : Array
        Training input data of shape (n_samples, n_features).
    Y : Array
        Multi-output training data of shape (n_samples, n_outputs).
    kernel : Kernel
        Instance of a kernel class defining the covariance structure, 
        often utilizing a separable multi-output formulation[cite: 22].
    nu : float
        Degrees of freedom for the Student-t Process (:math:`\nu > 2`). 
        Lower values (:math:`\nu < 20`) increase robustness to outliers 
        by providing heavier tails[cite: 116, 118].
    frequency : Array, optional
        Array of frequency values corresponding to the output dimensions, 
        used for simultaneous multi-frequency inference[cite: 1].

    References
    ----------
    .. [1] Bilionis, I., Zabaras, N., Konomi, B. A., & Lin, G. (2013). 
        Multi-output separable Gaussian process: Towards an efficient, fully 
        Bayesian paradigm for uncertainty quantification. J. Comput. Phys., 
        241, 212–239.
    .. [2] Alvarez, M. A., Rosasco, L., & Lawrence, N. D. (2012). 
        Kernels for Vector-Valued Functions: a Review. arXiv:1106.6251.
    .. [3] Shah, A., Wilson, A. G., & Ghahramani, Z. (2014). Student-t Processes 
        as Alternatives to Gaussian Processes. AISTATS.
    """

    def __init__(self, X: Array, Y: Array, kernel: Kernel, nu: float = 3.0, frequency: Array = None):
        super().__init__(kernel, X, Y)
        self.nu = nu
        self.jitter = 1e-6
        self.frequency = frequency
        
        # Wrapped Wideband TP likelihood that scales by data variance 
        # so optimization perfectly matches the behavior of the Bayesian model.
        self.likelihood = lambda x, y, j, k: self._compute_wideband_nlml(x, y, j, k)

    def _compute_wideband_nlml(self, X, Y, jitter, kernel):
        """Internal function to compute wideband log-likelihood across tasks.
        
        .. math::

            \log p(\mathbf{Y} \mid \mathbf{X}, \boldsymbol{\theta}, \nu) = 
            \sum_{p=1}^{P} \log \text{MVT} \left( \nu, \mathbf{0}, K_{\boldsymbol{\theta}} + \frac{\sigma_{noise}^2}{\text{Var}(y_p)} I \right)
        
        """
        sigma_sq = jnp.var(Y, axis=0, ddof=1)
        sigma = jnp.sqrt(sigma_sq)
        
        def single_ll(carry):
            y_task, sig_task = carry
            # Normalize the data before applying the standard scalar TP likelihood
            y_scaled = y_task / sig_task
            return nlml_student_t_scalar(X, y_scaled, jitter, kernel, nu=self.nu)
            
        # Sum the log-likelihoods across all frequencies sequentially
        return jnp.sum(lax.map(single_ll, (Y.T, sigma)))

    def train(
        self, 
        key: Key,
        optim_dictionary: Dict={"opt": optax.adam, "settings": {"learning_rate": 1e-2}}, 
        n_steps: Int = 1000, 
        n_restarts: int = 1, 
        save_history: Bool = False, 
        verbose: Bool = False
    ) -> Tuple:
        """Optax training function for wideband TP."""
        self.optimized_parameters, self.parameter_history = train(
            self, key, optim_dictionary, n_steps, n_restarts, save_history, verbose
        )
        self.kernel.update_params(self.optimized_parameters["params"])
        return self.optimized_parameters, self.parameter_history

    def train_scipy(self, 
        key: Key, 
        number_restarts: int=1, 
        opt_algorithm: Dict={"method":"L-BFGS-B"},
        save_history: Bool=False, 
        verbose: Bool=True
    ) -> Tuple:
        """Scipy optimization function for wideband TP."""
        self.optimized_parameters, self.parameter_history = train_scipy(
            self, key, number_restarts, opt_algorithm, save_history, verbose
        )
        self.kernel.update_params(self.optimized_parameters["params"])
        return self.optimized_parameters, self.parameter_history

    def train_mcmc(
        self, 
        key: Key, 
        num_warmup: int = 500, 
        num_samples: int = 1000, 
        num_chains: int = 1
    ) -> Dict[str, Array]:
        r"""
        Fully Bayesian training for the Wideband Student-t Process using NUTS via NumPyro.

        This method performs joint inference over kernel hyperparameters and the 
        degrees of freedom :math:`\nu` across all output frequencies simultaneously. 

        .. math::

            p(\boldsymbol{\theta}, \nu \mid \mathcal{D}) \propto 
            p(\mathbf{Y} \mid \mathbf{X}, \boldsymbol{\theta}, \nu) \, p(\boldsymbol{\theta}) \, p(\nu)

        By specifying priors over hyperparameters and a Multivariate Student-t (MVT) 
        likelihood, we enable NumPyro to approximate the posterior via the 
        No-U-Turn Sampler (NUTS) [1]. This treats the multi-frequency data as 
        a unified inference problem using the framework of vector-valued kernels [2].

        The inference is accelerated using the JAX backend [3] and the 
        NumPyro probabilistic programming library [4].

        Parameters
        ----------
        key : Key
            Random key for sampling initialization.
        num_warmup : int, optional
            Number of warmup (burn-in) steps for the NUTS sampler.
        num_samples : int, optional
            Number of posterior samples to draw after warmup.
        num_chains : int, optional
            Number of independent MCMC chains.

        Returns
        -------
        Dict[str, Array]
            Posterior samples for kernel hyperparameters and the :math:`\nu` parameter.

        References
        ----------
        .. [1] Hoffman, M. D., & Gelman, A. (2014). The No-U-Turn sampler. JMLR.
        .. [2] Alvarez, M. A., et al. (2012). Kernels for Vector-Valued Functions: 
           A Review. arXiv:1106.6251.
        .. [3] Bradbury, J., et al. (2018). JAX: composable transformations of 
           Python+NumPy programs.
        .. [4] Phan, D., Pradhan, N., & Jankowiak, M. (2019). Composable Effects 
           for Flexible and Accelerated Probabilistic Programming in NumPyro.
        """
        def wideband_tp_numpyro_model(X, Y, kernel, nu, jitter, data_variances):
            n, p = X.shape[0], Y.shape[1]
            priors = kernel.get_priors()
            current_params = kernel.get_params()
            sampled_params = {}
            
            # 1. Sample hyperparameters dynamically with ARD support
            for param_name, prior_dist in priors.items():
                param_shape = current_params[param_name].shape
                if param_shape and param_shape[0] > 1:
                    sampled_params[param_name] = numpyro.sample(
                        param_name, prior_dist.expand(param_shape)
                    )
                else:
                    sampled_params[param_name] = numpyro.sample(param_name, prior_dist)
            
            kernel.update_params(sampled_params)
            
            # 2. Kernel Matrix & Cholesky Decomposition
            K = kernel(X, X) + jnp.eye(n) * jitter
            L = jnp.linalg.cholesky(K)
            
            # 3. Multivariate Student-T Distribution
            student_t = dist.MultivariateStudentT(df=nu, loc=jnp.zeros(n), scale_tril=L)
            
            # 4. Fast vectorized evaluation: normalize Y by the known task standard deviations
            obs = Y / jnp.sqrt(data_variances)
            
            # 5. Evaluate all frequencies simultaneously in C++/XLA
            with numpyro.plate("frequency_positions", p, dim=-1):
                numpyro.sample("Y", student_t, obs=obs.T)

        # Start NUTS sampling
        kernel_nuts = NUTS(wideband_tp_numpyro_model)
        self.mcmc = MCMC(
            kernel_nuts, 
            num_warmup=num_warmup, 
            num_samples=num_samples, 
            num_chains=num_chains,
            progress_bar=True
        )
        
        data_variances = jnp.var(self.Y, axis=0, ddof=1)
        print(f"Running MCMC with {num_samples} samples and {num_chains} chain(s)...")
        self.mcmc.run(key, self.X, self.Y, self.kernel, self.nu, self.jitter, data_variances)
        
        self.posterior_samples = self.mcmc.get_samples()
        
        # Clean default point-estimate
        mean_params = {k: jnp.mean(v, axis=0) for k, v in self.posterior_samples.items()}
        self.kernel.update_params(mean_params)
        self.optimized_parameters = {"params": mean_params}
        
        return self.posterior_samples

    def predict(self, X_test: Array) -> Tuple[Array, Array]:
        r"""
        Predict the mean and variance for the given test inputs.
        Applies a data normalization trick to allow the exact Student-t inference 
        function to operate independently across different frequency scales.
        """
        X_test = jnp.atleast_2d(X_test)
        
        # Extract variances to scale each frequency task independently
        sigma_sq = jnp.var(self.Y, axis=0, ddof=1)
        sigma = jnp.sqrt(sigma_sq)
        
        def compute_single_task(carry):
            y_task, sig_task = carry
            y_scaled = y_task / sig_task
            
            # Exact inference on the normalized data
            mean_scaled, var_scaled = predictive_mean_var_student_t(
                self.X, y_scaled, self.kernel, self.jitter, X_test, self.nu
            )
            
            # Un-scale the predictions back to the true frequency amplitude
            mean_real = mean_scaled * sig_task
            var_real = var_scaled * (sig_task ** 2)
            
            return mean_real, var_real

        mean_mapped, var_mapped = lax.map(compute_single_task, (self.Y.T, sigma))
        
        return mean_mapped.T, var_mapped.T

    def predict_mcmc(self, X_test: Array) -> Tuple[Array, Array]:
        r"""
        Predictive mean and variance marginalized over all posterior MCMC samples.
        """
        if not hasattr(self, 'posterior_samples'):
            raise ValueError("You must run train_mcmc() before calling predict_mcmc().")
            
        X_test = jnp.atleast_2d(X_test)
        num_samples = len(list(self.posterior_samples.values())[0])
        print(f"Predicting over {num_samples} MCMC samples...")

        
        @jit
        def fast_pure_predict(kernel, X_train, Y_train, jitter, nu, x_t):
            sigma_sq = jnp.var(Y_train, axis=0, ddof=1)
            sigma = jnp.sqrt(sigma_sq)

            def compute_single_task(carry):
                y_task, sig_task = carry
                y_scaled = y_task / sig_task
                
                # Call the exact inference function passing the stateless 'kernel' argument
                mean_scaled, var_scaled = predictive_mean_var_student_t(
                    X_train, y_scaled, kernel, jitter, x_t, nu
                )
                return mean_scaled * sig_task, var_scaled * (sig_task ** 2)

            # lax.map safely processes frequencies sequentially without OOM errors
            mean_mapped, var_mapped = lax.map(compute_single_task, (Y_train.T, sigma))
            return mean_mapped.T, var_mapped.T

        all_means = []
        all_vars = []

        # 2. Python loop keeps memory low, while hitting the JIT cache every iteration
        for i in range(num_samples):
            # SAFE MUTATION: This happens cleanly outside JAX's view!
            sample_params = {k: v[i] for k, v in self.posterior_samples.items()}
            self.kernel.update_params(sample_params)
            
            
            mean, var = fast_pure_predict(
                self.kernel, self.X, self.Y, self.jitter, self.nu, X_test
            )
            
            all_means.append(mean)
            all_vars.append(var)
            
        all_means = jnp.array(all_means) # Shape: (samples, N_test, P)
        all_vars = jnp.array(all_vars)   # Shape: (samples, N_test, P)
        
        # 3. Marginalize over the posterior (Law of Total Expectation / Variance)
        expected_mean = jnp.mean(all_means, axis=0)
        expected_var = jnp.mean(all_vars, axis=0) + jnp.var(all_means, axis=0)
        
        # 4. Clean up: Restore the kernel to the stable point-estimate
        self.kernel.update_params(self.optimized_parameters["params"])
        
        return expected_mean, expected_var