# ------------------------------------------------------------------------------
# Project: IFE_Surrogate
# Authors: Tobias Leitgeb, Julian Tischler
# CD Lab 2025
# ------------------------------------------------------------------------------
"""
Contains all Gaussian Process models of the Library.
"""
from .gp_model import GPModel
from .scalar_gp import ScalarGP
from .wideband_gp import WidebandGP
from .multi_output_gp import SeparableMultiOutputGP
from .student_t import WidebandTP, ScalarTP


__all__ = [
    "GPModel",
    "WidebandGP",
    "ScalarGP",
    "SeparableMultiOutputGP",
    "ScalerTP",
    "WidebandTP"
    ]