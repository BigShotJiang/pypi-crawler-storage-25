# ------------------------------------------------------------------------------
# Project: IFE_Surrogate
# Authors: Tobias Leitgeb, Julian Tischler
# CD Lab 2025
# ------------------------------------------------------------------------------
from ife_surrogate.gp.models.gp_model import GPModel
from ife_surrogate.gp.train import train, train_scipy, train_swarm
from ife_surrogate.gp.likelihood import nmll_wideband, nlml_scalar
from ife_surrogate.gp.inference import predictive_mean_var_wideband, predictive_mean_var_scalar
from ife_surrogate.gp.kernels import Kernel
from ife_surrogate.utils.decorators import experimental, deprecated

from jaxtyping import Key, Array, Int, Bool
from typing import Tuple, Dict
from functools import partial
from jax import vmap, lax, jit
import typing
import jax.numpy as jnp
import numpyro
import optax
import numpyro.distributions as dist
from numpyro.infer import MCMC, NUTS
import warnings

TypeKernel = typing.TypeVar("Kernel", bound=Kernel)


class WidebandGP(GPModel):
    r"""
    Wideband Gaussian Process (GP) model for multi-output regression tasks.

    This model extends the scalar GP framework to vectorial outputs by applying 
    a wideband architecture. 
    .. math::

        f(\mathbf{x}) : \mathbb{R}^D \rarr \mathbb{R}^P
    The structural foundation of this model is based 
    on the approach introduced by Rezende et al. [1] for high-dimensional multiobjective optimization.
    The model is reformulated here as a Multi-output Separable Gaussian Process 
    [2], utilizing the theoretical framework of kernels for vector-valued 
    functions [3].

    .. math::

        \mathbf{f}(\bm x) \sim \mathcal{GP} \left(\bm 0 ,(\bm \sigma^2) \otimes k(\bm x, \bm x'; \bm \theta) \right).

    Parameters
    ----------
    X : Array
        Training input data of shape (n_samples, n_features).
    Y : Array
        Training output data of shape (n_samples, n_outputs), where each output dimension
        typically corresponds to a different frequency.
    kernel : Kernel
        Instance of a kernel class defining the covariance structure.
    frequency : Array, optional
        Array of frequency values corresponding to the output dimensions. If provided, can
        be used to structure the multi-output modeling more explicitly.
    
    .. [1] Rezende, R. S., Hansen, J., Piwonski, A., & Schuhmann, R. (2024). 
        Wideband Kriging for Multiobjective Optimization of a High-Voltage 
        EMI Filter. IEEE Trans. Electromagn. Compat., 66(4), 1116–1124.
    .. [2] Bilionis, I., Zabaras, N., Konomi, B. A., & Lin, G. (2013). 
        Multi-output separable Gaussian process: Towards an efficient, fully 
        Bayesian paradigm for uncertainty quantification. J. Comput. Phys., 
        241, 212–239.
    .. [3] Alvarez, M. A., Rosasco, L., & Lawrence, N. D. (2012). 
        Kernels for Vector-Valued Functions: a Review. arXiv:1106.6251.
    """

    def __init__(self, X: Array, Y: Array, kernel: Kernel, frequency: Array = None):
        super().__init__(kernel, X, Y)
        self.likelihood = nmll_wideband
        self.sigma_sq = Y.var(axis=0, ddof=1) if Y is not None else None
        self.jitter = 1e-6
        self.frequency = frequency

    def train(
        self, 
        key: Key,
        optimizer: Dict = {"opt": optax.adam, "settings": {"learning_rate": 1e-2}, "tolerance": 1e-5, "patience": 20}, 
        sample_parameters: Bool = True,
        n_steps: Int = 1000, 
        n_restarts: int = 1, 
        save_history: Bool = False, 
        verbose: Bool = False
    ) -> Tuple:
        r"""
        Optax training function:
        Optimize kernel parameters by minimizing the negative marginal log-likelihood using gradient-based optimizers.
        """
        self.optimized_parameters, self.parameter_history = train(
            self, key, optimizer, sample_parameters, n_steps, n_restarts, save_history, verbose
        )
        self.kernel.update_params(self.optimized_parameters["params"])

    def train_scipy(self, 
        key: Key, 
        n_restarts: int = 1, 
        optimizer: Dict = {"method": "L-BFGS-B"},
        save_history: Bool = False, 
        verbose: Bool = True
    ) -> None:
        r"""
        Scipy training function:
        Optimize kernel parameters using a scipy-based optimizer (e.g., L-BFGS-B).
        """
        self.optimized_parameters, self.parameter_history = train_scipy(
            self, key, n_restarts, optimizer, save_history, verbose
        )
        self.kernel.update_params(self.optimized_parameters["params"])
    
    def train_swarm(self, 
        key: Key, 
        bounds: Tuple[Array, Array] = (),
        n_restarts: int = 1,
        optimizer: Dict = {"c1": 0.5, "c2": 0.3, "w": 0.9},
        n_particles: int = 20,
        n_iterations: int = 100,
        save_history: Bool = False, 
        verbose: Bool = True
    ) -> None:
        r"""
        Pyswarms training function:
        Optimize kernel parameters using PSO
        """
        self.optimized_parameters, self.parameter_history = train_swarm(
            self, key, bounds, n_restarts=n_restarts, optimizer=optimizer, n_particles=n_particles, n_iterations=n_iterations,
        )
        self.kernel.update_params(self.optimized_parameters["params"])

    def train_mcmc(
        self, 
        key: Key, 
        num_warmup: int = 500, 
        num_samples: int = 1000, 
        num_chains: int = 1
    ) -> Dict[str, Array]:
        r"""
        Fully Bayesian training for the Wideband GP using NUTS via NumPyro.

        This method performs joint inference over kernel hyperparameters across all 
        output frequencies simultaneously.
        .. math::

            p(\boldsymbol{\theta} \mid \mathcal{D}) \propto 
            p(\mathbf{Y} \mid \mathbf{X}, \boldsymbol{\theta}) \, p(\boldsymbol{\theta})

        By specifying priors over hyperparameters, we enable NumPyro to approximate 
        the posterior via the No-U-Turn Sampler (NUTS) [1]. The likelihood 
        evaluation leverages the theoretical framework of vector-valued kernels [2] 
        to treat the multi-frequency data as a unified inference problem.

        The inference is accelerated using the JAX backend [3] and the 
        NumPyro probabilistic programming library [4].
        
                Parameters
        ----------
        key : Key
            Random key for sampling initialization.
        num_warmup : int, optional
            Number of warmup (burn-in) steps for the NUTS sampler.
        num_samples : int, optional
            Number of posterior samples to draw after warmup.
        num_chains : int, optional
            Number of independent MCMC chains.

        Returns
        -------
        Dict[str, Array]
            Posterior samples for kernel hyperparameters and the :math:`\nu` parameter.

        .. [1] Alvarez, M. A., et al. (2012). Kernels for Vector-Valued Functions: 
           A Review. arXiv:1106.6251.
        .. [2] Hoffman, M. D., & Gelman, A. (2014). The No-U-Turn sampler. JMLR.
        .. [3] Bradbury, J., et al. (2018). JAX: composable transformations of 
           Python+NumPy programs.
        .. [4] Phan, D., Pradhan, N., & Jankowiak, M. (2019). Composable Effects 
           for Flexible and Accelerated Probabilistic Programming in NumPyro.
        """
        def wideband_numpyro_model(X, Y, kernel, jitter, data_variances):
            n, p = X.shape[0], Y.shape[1]
            priors = kernel.get_priors()
            current_params = kernel.get_params()
            sampled_params = {}
            
            # Sample hyperparameters dynamically with ARD support
            for param_name, prior_dist in priors.items():
                param_shape = current_params[param_name].shape
                if param_shape and param_shape[0] > 1:
                    sampled_params[param_name] = numpyro.sample(
                        param_name, prior_dist.expand(param_shape)
                    )
                else:
                    sampled_params[param_name] = numpyro.sample(param_name, prior_dist)
            
            kernel.update_params(sampled_params)
            
            K = kernel(X, X) + jnp.eye(n) * jitter
            normal = dist.MultivariateNormal(loc=jnp.zeros(n), covariance_matrix=K)
            
            # Fast vectorized calculation: normalize Y by the known task variances
            obs = Y / jnp.sqrt(data_variances)
            
            #A single plate across the 'p' frequencies.
            # Passing obs.T (shape p, n) evaluates all tasks simultaneously
            with numpyro.plate("frequency_positions", p, dim=-1):
                numpyro.sample("Y", normal, obs=obs.T)

        kernel_nuts = NUTS(wideband_numpyro_model)
        self.mcmc = MCMC(
            kernel_nuts, 
            num_warmup=num_warmup, 
            num_samples=num_samples, 
            num_chains=num_chains,
            progress_bar=True
        )
        
        print(f"Running MCMC with {num_samples} samples and {num_chains} chain(s)...")
        self.mcmc.run(key, self.X, self.Y, self.kernel, self.jitter, self.sigma_sq)
        
        self.posterior_samples = self.mcmc.get_samples()
        
        # Set kernel back to point estimate (mean of posteriors)
        mean_params = {k: jnp.mean(v, axis=0) for k, v in self.posterior_samples.items()}
        self.kernel.update_params(mean_params)
        self.optimized_parameters = {"params": mean_params}
        
        #return self.posterior_samples

    def predict(self, X_test: Array) -> Tuple[Array, Array]:
        r"""
        Predict the mean and variance for the given test inputs.

        .. math::
            \boldsymbol{\mu}_p = \mathbf{K}_*^\top \mathbf{K}_x^{-1} \mathbf{y}_p

        .. math::
            \boldsymbol{\Sigma}_p 
            = \sigma_p^2 \left( \mathbf{K}_{**} - \mathbf{K}_*^\top \mathbf{K}_x^{-1} \mathbf{K}_* \right)

        Returns
        -------
        Tuple[Array, Array]
            Mean predictions and variances for each output dimension.
        """
        pred_wideband = partial(predictive_mean_var_wideband, self.X, kernel=self.kernel, jitter=self.jitter, X_test=X_test)
        sigma_sq = jnp.var(self.Y, axis=0, ddof=1)
        mean, var = vmap(pred_wideband, in_axes=(1,0))(self.Y, sigma_sq)
        return mean.T, var.T
    
    def predict_mcmc(self, X_test: Array) -> Tuple[Array, Array]:
        r"""
        Predictive mean and variance marginalized over all posterior MCMC samples.
        """
        if not hasattr(self, 'posterior_samples'):
            raise ValueError("You must run train_mcmc() before calling predict_mcmc().")
            
        X_test = jnp.atleast_2d(X_test)
        num_samples = len(list(self.posterior_samples.values())[0])
        print(f"Predicting over {num_samples} MCMC samples... (JIT Compiled Loop Mode)")


        @jit
        def fast_pure_predict(kernel, X_train, Y_train, jitter, x_t):
            sigma_sq = jnp.var(Y_train, axis=0, ddof=1)
            sigma = jnp.sqrt(sigma_sq)

            def compute_single_task(carry):
                y_task, sig_task = carry
                y_scaled = y_task / sig_task
                
                # Call the exact inference function passing the stateless 'kernel' argument
                mean_scaled, var_scaled = predictive_mean_var_scalar(
                    X_train, y_scaled, kernel, jitter, x_t
                )
                return mean_scaled * sig_task, var_scaled * (sig_task ** 2)

            # lax.map safely processes frequencies sequentially without OOM errors
            mean_mapped, var_mapped = lax.map(compute_single_task, (Y_train.T, sigma))
            return mean_mapped.T, var_mapped.T

        all_means = []
        all_vars = []

        
        for i in range(num_samples):
            sample_params = {k: v[i] for k, v in self.posterior_samples.items()}
            self.kernel.update_params(sample_params)
            
            
            mean, var = fast_pure_predict(
                self.kernel, self.X, self.Y, self.jitter, X_test
            )
            
            all_means.append(mean)
            all_vars.append(var)
            
        all_means = jnp.array(all_means) # Shape: (samples, N_test, P)
        all_vars = jnp.array(all_vars)   # Shape: (samples, N_test, P)
        
        # 3. Marginalize over the posterior (Law of Total Expectation / Variance)
        expected_mean = jnp.mean(all_means, axis=0)
        expected_var = jnp.mean(all_vars, axis=0) + jnp.var(all_means, axis=0)
        
        # 4. Clean up: Restore the kernel to the stable point-estimate
        self.kernel.update_params(self.optimized_parameters["params"])
        
        return expected_mean, expected_var
   
    def log_marginal_likelihood(self):
        r"""
        Compute the (negative) log marginal likelihood of the wideband model.
        """
        return nmll_wideband(self.X, self.Y, self.sigma_sq, self.jitter, self.kernel)
    
    def log_likelihood_scalar(self):
        r"""
        Compute the (negative) log marginal likelihood assuming scalar outputs.
        """
        return vmap(nlml_scalar, in_axes=(None, 1, None, None))(self.X, self.Y, self.jitter, self.kernel)

    def sample_posterior(self, key: Key, X: Array, n_samples: Int) -> Array:
        return NotImplementedError
    
    def sample_prior(self, key: Key, X: Array, n_samples: Int) -> Array:
        return NotImplementedError