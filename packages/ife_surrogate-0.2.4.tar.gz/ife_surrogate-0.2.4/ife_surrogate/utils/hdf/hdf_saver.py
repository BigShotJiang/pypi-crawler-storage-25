import h5py
import numpy as np

class HDF5DataStore:
    """A utility to save/load nested dictionaries containing arrays to/from HDF5."""
    
    @staticmethod
    def save(filepath, data_dict):
        with h5py.File(filepath, 'w') as f:
            HDF5DataStore._recursive_save(f, data_dict)

    @staticmethod
    def _recursive_save(h5_group, data):
        for key, value in data.items():
            if isinstance(value, dict):
                next_group = h5_group.create_group(key)
                HDF5DataStore._recursive_save(next_group, value)
            else:
                h5_group.create_dataset(key, data=value, compression="gzip")

    @staticmethod
    def load(filepath):
        with h5py.File(filepath, 'r') as f:
            return HDF5DataStore._recursive_load(f)

    @staticmethod
    def _recursive_load(h5_group):
        data = {}
        for key, item in h5_group.items():
            if isinstance(item, h5py.Group):
                data[key] = HDF5DataStore._recursive_load(item)
            else:
                data[key] = item[()]
        return data