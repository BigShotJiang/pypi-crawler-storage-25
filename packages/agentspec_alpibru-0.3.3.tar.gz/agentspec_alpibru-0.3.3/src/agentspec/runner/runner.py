"""Runner — spawns the resolved runtime with the agent's configuration.

Translates a ResolvedPlan into the actual CLI invocation for the
selected runtime (claude-code, gemini-cli, codex-cli, etc.).
"""

from __future__ import annotations

import os
import subprocess
import sys
import tempfile
from pathlib import Path

from agentspec.parser.manifest import AgentManifest
from agentspec.resolver.resolver import ResolvedPlan
from agentspec.resolver.vertex import detect_vertex_ai, vertex_env_for_runtime


# Runtime → command builder
def build_command(plan: ResolvedPlan, manifest: AgentManifest, input_text: str | None) -> list[str]:
    """Build the CLI command for the resolved runtime."""
    builders = {
        "claude-code": _build_claude_cmd,
        "gemini-cli": _build_gemini_cmd,
        "cursor-cli": _build_cursor_cmd,
        "codex-cli": _build_codex_cmd,
        "opencode": _build_opencode_cmd,
        "goose": _build_goose_cmd,
        "aider": _build_aider_cmd,
        "ollama": _build_ollama_cmd,
    }

    builder = builders.get(plan.runtime)
    if not builder:
        raise NotImplementedError(f"Runner not implemented for: {plan.runtime}")

    return builder(plan, manifest, input_text)


def execute(plan: ResolvedPlan, manifest: AgentManifest, input_text: str | None = None) -> int:
    """Execute the agent by spawning the resolved runtime.

    If Vertex AI is configured (via GCP env vars + ADC), the relevant
    backend env vars are injected so the spawned CLI talks to Vertex
    instead of the direct provider API.
    """
    cmd = build_command(plan, manifest, input_text)
    env = build_env(plan)
    result = subprocess.run(cmd, env=env)
    return result.returncode


def build_env(plan: ResolvedPlan) -> dict[str, str]:
    """Build the environment for the spawned runtime.

    Inherits the current process env, then layers Vertex AI vars on top
    when the resolver picked Vertex (auth_source contains 'vertex-ai').
    """
    env = dict(os.environ)
    if "vertex-ai" in (plan.auth_source or "").lower():
        vertex = detect_vertex_ai()
        if vertex:
            env.update(vertex_env_for_runtime(plan.runtime, vertex))
    return env


def _derive_prompt(manifest: AgentManifest, input_text: str | None) -> str | None:
    """Pick the best prompt for the agent when --input was omitted.

    Precedence:
    1. Explicit ``input_text`` (passed to ``agentspec run --input``)
    2. ``SOUL.md`` content (directory-format agents carry it on ``manifest.soul``)
    3. Agent description

    Returns None only when the agent has no usable prompt at all — the caller
    decides what to do (most runtimes interpret "no prompt" as interactive mode).
    """
    if input_text:
        return input_text
    if manifest.soul:
        return manifest.soul.strip()
    if manifest.description:
        return manifest.description
    return None


def _build_claude_cmd(
    plan: ResolvedPlan, manifest: AgentManifest, input_text: str | None
) -> list[str]:
    """Build an argv for claude-code.

    Covered flags (verified via ``claude --help`` on v2+):

    - ``--model <name>`` — model selection; accepts aliases like
      ``sonnet`` / ``opus`` or full names like ``claude-sonnet-4-6``.
      Extracted from ``plan.model`` with the provider prefix stripped.
    - ``--system-prompt <text>`` — explicit system prompt. Claude has
      a dedicated flag (unlike gemini-cli which reads GEMINI.md).
    - ``-p/--print`` — non-interactive mode.
    - ``--dangerously-skip-permissions`` — added under AGENTSPEC_GYM=1
      so autonomous runs don't hang on every tool prompt; interactive
      ``agentspec run`` keeps the default per-tool approval.
    """
    cmd = ["claude"]

    if os.environ.get("AGENTSPEC_GYM") == "1":
        cmd.append("--dangerously-skip-permissions")

    model_name = _claude_model_name(plan.model)
    if model_name:
        cmd.extend(["--model", model_name])

    if plan.system_prompt:
        cmd.extend(["--system-prompt", plan.system_prompt])

    prompt = _derive_prompt(manifest, input_text)
    if prompt:
        cmd.extend(["-p", prompt])
    return cmd


def _claude_model_name(model: str) -> str:
    """Strip a ``provider/`` prefix from a model identifier for claude-code.

    ``claude/claude-sonnet-4-6`` → ``claude-sonnet-4-6``
    ``anthropic/claude-opus-4-6`` → ``claude-opus-4-6``
    ``sonnet``                   → ``sonnet`` (alias already bare)
    ``""`` / None                → ``""`` (caller skips the flag)
    """
    if not model:
        return ""
    if "/" in model:
        return model.split("/", 1)[1]
    return model


def _build_gemini_cmd(
    plan: ResolvedPlan, manifest: AgentManifest, input_text: str | None
) -> list[str]:
    """Build an argv for gemini-cli.

    Covers the flags that matter for agent-like runs:

    - ``-m/--model`` — extracted from ``plan.model`` (e.g. the provider
      prefix is stripped from ``gemini/gemini-2.5-pro`` to pass
      ``gemini-2.5-pro``).
    - ``-y/--yolo`` — added in gym/non-interactive runs so the agent
      doesn't hang on tool-approval prompts. Mirrors the claude-code
      behaviour when AGENTSPEC_GYM=1.
    - ``-p/--prompt`` — non-interactive mode with the supplied prompt.

    System prompt handling: gemini-cli has no ``--system-prompt`` flag.
    It instead reads ``GEMINI.md`` from the current working directory
    as system instructions. ``plan.system_prompt`` is written to that
    file when present. Callers who don't want the file persisted
    should run gemini in a throwaway worktree (the gym does this).
    """
    cmd = ["gemini"]

    # Autonomous mode — skip interactive approval prompts.
    if os.environ.get("AGENTSPEC_GYM") == "1":
        cmd.append("-y")

    # Model selection — strip the provider prefix so `gemini/gemini-2.5-pro`
    # becomes `gemini-2.5-pro`. Don't pass -m if resolution produced an
    # empty string (defensive: the resolver always sets plan.model, but
    # some test fixtures skip it).
    model_name = _gemini_model_name(plan.model)
    if model_name:
        cmd.extend(["-m", model_name])

    # System prompt lands at GEMINI.md in CWD. gemini-cli picks it up
    # automatically as system instructions. Only write when we have
    # something to write — don't stomp an existing GEMINI.md that
    # belongs to the user's project.
    if plan.system_prompt:
        import pathlib
        gemini_md = pathlib.Path.cwd() / "GEMINI.md"
        if not gemini_md.exists():
            gemini_md.write_text(plan.system_prompt)

    prompt = _derive_prompt(manifest, input_text)
    if prompt:
        cmd.extend(["-p", prompt])
    return cmd


def _gemini_model_name(model: str) -> str:
    """Strip a ``provider/`` prefix from a model identifier for gemini-cli.

    ``gemini/gemini-2.5-pro`` → ``gemini-2.5-pro``
    ``google/gemini-2.5-pro`` → ``gemini-2.5-pro``
    ``gemini-2.5-pro``        → ``gemini-2.5-pro`` (already bare)
    ``""`` / None             → ``""`` (caller skips the flag)
    """
    if not model:
        return ""
    if "/" in model:
        return model.split("/", 1)[1]
    return model


def _build_codex_cmd(
    plan: ResolvedPlan, manifest: AgentManifest, input_text: str | None
) -> list[str]:
    """Invoke OpenAI Codex CLI non-interactively.

    Verified against https://developers.openai.com/codex/cli/reference
    (also matches caloron-noether's field-validated FRAMEWORKS table):

    - ``codex exec <prompt>`` is the non-interactive subcommand. Running
      ``codex <prompt>`` without the subcommand drops into the
      interactive TUI.
    - ``--full-auto`` is the recommended autonomous mode (workspace-write
      sandbox + on-request approvals).
    - ``-m/--model`` takes a bare model name.
    - No ``--system-prompt`` or ``--instructions`` flag exists — codex's
      system-prompt story is config-file-only. When an agent manifest
      declares one, we prepend it to the user prompt with a blank-line
      separator.

    The previous builder used ``--instructions <tmpfile>`` which
    codex rejects with "unknown option"; fixed here.
    """
    cmd = ["codex", "exec"]

    if os.environ.get("AGENTSPEC_GYM") == "1":
        cmd.append("--full-auto")

    model_name = _codex_model_name(plan.model)
    if model_name:
        cmd.extend(["-m", model_name])

    prompt = _derive_prompt(manifest, input_text) or ""
    if plan.system_prompt:
        prompt = f"{plan.system_prompt}\n\n{prompt}".strip()
    if prompt:
        cmd.append(prompt)
    return cmd


def _codex_model_name(model: str) -> str:
    """Strip a ``provider/`` prefix for codex's ``-m`` flag.

    ``openai/gpt-5`` → ``gpt-5``
    ``o3``            → ``o3`` (alias already bare)
    ``""`` / None     → ``""`` (caller skips the flag)
    """
    if not model:
        return ""
    if "/" in model:
        return model.split("/", 1)[1]
    return model


def _build_goose_cmd(
    plan: ResolvedPlan, manifest: AgentManifest, input_text: str | None
) -> list[str]:
    """Invoke Block's goose non-interactively.

    Per https://goose-docs.ai/docs/guides/goose-cli-commands, the
    non-interactive form is:

        goose run -t "<prompt>" [--model <name>] [--system <text>]

    Distinguished features vs. the other runners:

    - ``--system <text>`` is a real flag (unlike codex/cursor/opencode
      where we have to prepend the system prompt to the user prompt).
    - ``--model <name>`` works similarly to claude/gemini; we pass the
      bare model name after stripping any ``provider/`` prefix.
    - Goose manages provider+API-key selection itself via its own
      config (``goose configure``) — our resolver doesn't need to
      inject provider-specific env vars.

    Tool access: goose uses MCP by default (built-in "developer" tools
    plus any MCP servers the user has configured). No equivalent of
    claude's ``--dangerously-skip-permissions`` is documented for the
    ``run`` subcommand; autonomous behaviour is the default.
    """
    cmd = ["goose", "run"]

    model_name = _goose_model_name(plan.model)
    if model_name:
        cmd.extend(["--model", model_name])

    if plan.system_prompt:
        cmd.extend(["--system", plan.system_prompt])

    prompt = _derive_prompt(manifest, input_text)
    if prompt:
        cmd.extend(["-t", prompt])
    return cmd


def _goose_model_name(model: str) -> str:
    """Strip a ``provider/`` prefix for goose's ``--model`` flag.

    ``anthropic/claude-sonnet-4-6`` → ``claude-sonnet-4-6``
    ``goose/claude-sonnet-4-6``     → ``claude-sonnet-4-6``
    ``claude-sonnet-4-6``           → ``claude-sonnet-4-6`` (already bare)
    ``""`` / None                   → ``""`` (caller skips the flag)
    """
    if not model:
        return ""
    if "/" in model:
        return model.split("/", 1)[1]
    return model


def _build_opencode_cmd(
    plan: ResolvedPlan, manifest: AgentManifest, input_text: str | None
) -> list[str]:
    """Invoke opencode non-interactively.

    Non-interactive form: ``opencode run <message>``. Verified against
    opencode 1.4.6's ``run --help`` output.

    Supported flags we thread through:

    - ``-m/--model <provider/model>`` — opencode wants the **full**
      ``provider/model`` pair (unlike claude/gemini/goose which take
      bare model names). We pass ``plan.model`` through unchanged.

    No yolo flag exists on the ``run`` subcommand itself; the default
    ``build`` agent has full tool access. Permission-sensitive
    environments scope access via the ``OPENCODE_PERMISSION`` env var.

    opencode has no dedicated ``--system-prompt`` flag, so the
    resolver-built system prompt is prepended to the user prompt.
    """
    cmd = ["opencode", "run"]

    if plan.model:
        # Strip the caller-facing ``opencode/`` prefix so what we pass
        # to ``-m`` is the ``provider/model`` pair opencode itself
        # expects. Example:
        #   manifest: opencode/anthropic/claude-sonnet-4-6
        #   stripped: anthropic/claude-sonnet-4-6  ← what opencode wants
        opencode_model = (
            plan.model.split("/", 1)[1] if "/" in plan.model else plan.model
        )
        cmd.extend(["-m", opencode_model])

    prompt = _derive_prompt(manifest, input_text) or ""
    if plan.system_prompt:
        prompt = f"{plan.system_prompt}\n\n{prompt}".strip()
    if prompt:
        cmd.append(prompt)
    return cmd


def _build_cursor_cmd(
    plan: ResolvedPlan, manifest: AgentManifest, input_text: str | None
) -> list[str]:
    """Invoke cursor-agent non-interactively.

    Verified against cursor-agent 2026.04.15's ``--help`` output.
    Binary is ``cursor-agent`` (the ``cursor`` command is the desktop
    editor).

    Flag shape:

    - ``-p/--print`` is a **boolean** that enables non-interactive
      mode. Not a prompt-carrier — the prompt is a positional arg.
    - ``--model <name>`` accepts cursor-specific names like ``gpt-5``,
      ``sonnet-4``, ``sonnet-4-thinking``.
    - ``--force`` / ``--yolo`` (aliases) auto-approves all tool calls.
      Added under AGENTSPEC_GYM=1 so autonomous runs don't block.
    - ``--output-format text|json|stream-json`` controls stdout shape.

    No dedicated system-prompt flag; system prompt prepended to the
    user prompt with a blank-line separator.
    """
    cmd = ["cursor-agent", "-p", "--output-format", "text"]

    if os.environ.get("AGENTSPEC_GYM") == "1":
        cmd.append("--force")

    model_name = _cursor_model_name(plan.model)
    if model_name:
        cmd.extend(["--model", model_name])

    prompt = _derive_prompt(manifest, input_text) or ""
    if plan.system_prompt:
        prompt = f"{plan.system_prompt}\n\n{prompt}".strip()
    if prompt:
        cmd.append(prompt)
    return cmd


def _cursor_model_name(model: str) -> str:
    """Strip a ``provider/`` prefix for cursor-agent's ``--model`` flag.

    cursor-agent uses its own short model names (``gpt-5``,
    ``sonnet-4``, ``sonnet-4-thinking``). Callers who declare
    ``claude/sonnet-4`` in their manifest get the bare ``sonnet-4``
    passed through; users who want the thinking variant declare
    ``cursor/sonnet-4-thinking`` or just ``sonnet-4-thinking``.
    """
    if not model:
        return ""
    if "/" in model:
        return model.split("/", 1)[1]
    return model


def _build_aider_cmd(
    plan: ResolvedPlan, manifest: AgentManifest, input_text: str | None
) -> list[str]:
    """Invoke aider non-interactively.

    Verified against aider 0.86.2's ``--help`` output:

    - ``--message <text>`` / ``-m <text>`` — single-shot prompt; aider
      runs the message and exits.
    - ``--model <name>`` — model selection (bare name).
    - ``--yes-always`` — auto-approve all confirmations; added under
      AGENTSPEC_GYM=1 so unattended runs don't block on prompts.
    """
    cmd = ["aider"]

    if os.environ.get("AGENTSPEC_GYM") == "1":
        cmd.append("--yes-always")

    if plan.model:
        model_id = plan.model.split("/", 1)[-1] if "/" in plan.model else plan.model
        cmd.extend(["--model", model_id])

    if input_text:
        cmd.extend(["--message", input_text])
    return cmd


def _build_ollama_cmd(
    plan: ResolvedPlan, manifest: AgentManifest, input_text: str | None
) -> list[str]:
    model_id = plan.model.split("/", 1)[-1] if "/" in plan.model else plan.model
    cmd = ["ollama", "run", model_id]
    if input_text:
        cmd.append(input_text)
    return cmd
