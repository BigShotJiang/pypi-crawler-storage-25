import os

import requests


class Client:
    def __init__(self, api_key: str | None = None, base_url: str | None = None):
        api_key = api_key or os.environ.get("DISPOSABLE_EXEC_API_KEY")
        base_url = base_url or os.environ.get(
            "DISPOSABLE_EXEC_BASE_URL", "http://127.0.0.1:8000"
        )

        if not api_key:
            raise ValueError(
                "api_key is required; pass api_key or set DISPOSABLE_EXEC_API_KEY"
            )

        self.api_key = api_key
        self.base_url = base_url.rstrip("/")

    @property
    def headers(self):
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def _request(self, method: str, path: str, **kwargs):
        response = requests.request(
            method,
            f"{self.base_url}{path}",
            headers=self.headers,
            timeout=30,
            **kwargs,
        )
        response.raise_for_status()
        return response.json()

    def me(self):
        return self._request("GET", "/me")

    def run(self, script: str):
        return self._request("POST", "/run", json={"script": script})

    def run_files(self, entrypoint: str, files: list[dict]):
        return self._request(
            "POST",
            "/run",
            json={"entrypoint": entrypoint, "files": files},
        )

    def diagnose_script(self, script: str):
        return self._request("POST", "/diagnose", json={"script": script})

    def diagnose_files(self, entrypoint: str, files: list[dict]):
        return self._request(
            "POST",
            "/diagnose",
            json={"entrypoint": entrypoint, "files": files},
        )

    def status(self, execution_id: str):
        return self._request("GET", f"/status/{execution_id}")

    def result(self, execution_id: str):
        return self._request("GET", f"/result/{execution_id}")

    def cancel(self, execution_id: str, reason: str | None = None):
        payload = {}
        if reason is not None:
            payload["reason"] = reason
        return self._request(
            "POST",
            f"/executions/{execution_id}/cancel",
            json=payload if payload else None,
        )
