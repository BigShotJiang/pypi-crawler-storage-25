from pathlib import Path

from setuptools import setup

README = Path(__file__).with_name("README.md").read_text(encoding="utf-8")

setup(
    name="disposable-exec",
    version="0.2.0",
    description="Python SDK for disposable-exec — a control layer for short-lived Python execution",
    long_description=README,
    long_description_content_type="text/markdown",
    # SDK only — publish client.py + __init__.py, not the server-side backend.
    packages=["disposable_exec"],
    package_data={"disposable_exec": ["py.typed"]},
    install_requires=[
        "requests>=2.31.0",
        "python-multipart>=0.0.9",
    ],
    python_requires=">=3.10",
    project_urls={
        "Homepage": "https://disposable-exec.com",
        "Source": "https://github.com/DevBunny-exe/disposable-exec",
        "Documentation": "https://disposable-exec.com",
        "Tracker": "https://github.com/DevBunny-exe/disposable-exec/issues",
    },
)
