# Changelog

## 0.2.0 - 2026-04-18

- add `Client().cancel(execution_id, reason=None)` method
- `/status` response now includes `timeline` object, `raw_status`, `recovery_attempt_count`, and `failure_reason`
- `/result` response now includes `failure_reason`
- new execution statuses: `canceling` (non-terminal) and `canceled` (terminal)
- queued cancel refunds credits; claimed/running cancel is accepted but execution may finish naturally (docker-kill in future release)
- structured failure reasons: `timeout`, `exit_nonzero`, `sandbox_error`, `platform_error`, `orphaned`
- honest limits section added to README
- updated product positioning to "control layer" framing

## 0.1.6 - 2026-04-06

- fix shared execution aggregate helper availability and keep shared execution state behavior aligned
- normalize Redis URL-based configuration handling used in live deployment prep
- packaging consistency cleanup for the next patch release

## 0.1.5 - 2026-04-03

- add PyPI project URLs
- update README for website / install / source links

## 0.1.4 - 2026-04-03

- finalized billing-window Phase 2 so billing-window usage is the active quota truth
- fixed terminal execution status handling so success persists as `completed` and failure persists as `failed`
- fixed worker heartbeat/admin summary consistency so admin worker readiness reflects live worker activity more accurately

## 0.1.3 - 2026-04-03

- bumped the package version for the previous release-ready SDK/doc pass
