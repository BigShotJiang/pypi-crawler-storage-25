import logging
from pathlib import Path

from rich import print
import typer
from deploy.config import AWS_REGION
from deploy.renderables.util import render_diff
from deploy.terraform import TEMPLATES_DIR, diff_templates, render_templates

app = typer.Typer(name="templates", help="Manage infrastructure templates. (AWS, Terraform, etc.)")


@app.command(help="Initialize deployment by copying template files to local repository.")
def init(
    name: str,
    aws_profile: str = "default",
    aws_state_bucket: str = "terraform-states",
    tf_module: str = "application",
):
    context = {
        "name": name,
        "aws_profile": aws_profile,
        "aws_region": AWS_REGION,
        "aws_state_bucket": aws_state_bucket,
        "tf_module": tf_module,
    }

    for rendered_content, output_path in render_templates(context):
        # If rendered path already exists, skip
        if output_path.exists():
            logging.warning(f"Skipped {output_path} (already exists)")
            continue

        # Ensure parent directories exist
        output_path.parent.mkdir(parents=True, exist_ok=True)

        # Write the file
        output_path.write_text(rendered_content)
        logging.info(f"Created file {output_path}")

    logging.info(f"Deployment '{name}' created")


@app.command(help="Add a subset of templates to local repository.")
def add(
    templates_dir: str,
    aws_profile: str = "default",
    aws_state_bucket: str = "terraform-states",
    tf_module: str = "application",
):
    context = {
        "aws_profile": aws_profile,
        "aws_region": AWS_REGION,
        "aws_state_bucket": aws_state_bucket,
        "tf_module": tf_module,
    }

    for rendered_content, output_path in render_templates(context, templates_dir):
        # If rendered path already exists, skip
        if output_path.exists():
            logging.warning(f"Skipped {output_path} (already exists)")
            continue

        # Ensure parent directories exist
        output_path.parent.mkdir(parents=True, exist_ok=True)

        # Write the file
        output_path.write_text(rendered_content)
        logging.info(f"Created file {output_path}")

    logging.info(f"Added templates from '{templates_dir}'")


@app.command(help="Update deployment templates, overwriting files.")
def update(
    name: str,
    templates_dir: str,
    aws_profile: str = "default",
    aws_state_bucket: str = "terraform-states",
    tf_module: str = "application",
    dry_run: bool = False,
):
    context = {
        "name": name,
        "aws_profile": aws_profile,
        "aws_region": AWS_REGION,
        "aws_state_bucket": aws_state_bucket,
        "tf_module": tf_module,
    }

    for rendered_content, output_path in render_templates(context, templates_dir):
        if "main.tf" in str(output_path):
            continue

        # Ensure parent directories exist
        output_path.parent.mkdir(parents=True, exist_ok=True)

        # Check for existing file and print diff if it exists
        modified_files, created_files = 0, 0
        if output_path.exists():
            if diff := diff_templates(rendered_content, output_path):
                if not dry_run:
                    output_path.write_text(rendered_content)
                    modified_files += 1
                logging.info(f'Modified "{output_path}"')
                print(render_diff(diff, str(output_path)))
        else:
            if not dry_run:
                output_path.write_text(rendered_content)
                created_files += 1
            logging.info(f'Created file "{output_path}"')

    logging.info(f"{modified_files} files were modified and {created_files} files were created.")
    logging.info(f"Deployment '{name}' Updated")


def main():
    app()
