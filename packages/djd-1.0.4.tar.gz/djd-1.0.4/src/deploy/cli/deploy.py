import logging
import os
import subprocess
from datetime import datetime
from importlib.metadata import version as get_package_version
from pathlib import Path

import deploy.renderables.tables as tables
import typer
from deploy import config
from deploy.context import DeployContext, DeployContextObj
from deploy.history import DeployHistoryType
from rich import box, print
from rich.highlighter import ReprHighlighter
from rich.table import Table

app = typer.Typer(name="deploy", help="Manage AWS ECS deployments.")


def _print_version(value: bool) -> None:
    if value:
        print(f"djd {get_package_version('djd')}")
        raise typer.Exit()


@app.callback()
def initialize(
    ctx: typer.Context,
    environment: str = typer.Argument(
        ...,
        help="Deployment environment name (e.g. 'staging', 'production')."
    ),
    version: bool = typer.Option(
        False,
        "--version", "-v",
        callback=_print_version,
        is_eager=True,
        help="Print djd's version and exit."
    ),
    debug: bool = typer.Option(
        False,
        "--debug", "-d",
        help="Enable debug-level logging."
    ),
    confirm: bool = typer.Option(
        config.CONFIRM_DEFAULT,
        "--confirm/--no-confirm",
        help="Prompt for confirmation before destructive operations."
    ),
    refresh: float = typer.Option(
        1.0,
        "--refresh", "-r",
        help="Polling interval (in seconds) when watching deployments or tasks."
    ),
    docker_context_path: Path = typer.Option(
        config.GIT_COPY_PATH,
        "--docker-context-path",
        help="Path used as the Docker build context."
    ),
    github_workflow: bool = typer.Option(
        False,
        "--github-workflow",
        help="Dispatch the deploy via GitHub Actions instead of running locally."
    ),
    terraform_refresh: bool = typer.Option(
        False,
        "--terraform-refresh",
        help="Force terraform refresh, bypassing the cache."
    ),
):
    ctx.obj = DeployContextObj(
        environment,
        debug=debug,
        confirm=confirm,
        refresh=refresh,
        docker_context_path=docker_context_path,
        github_workflow=github_workflow,
        skip_terraform_validation=ctx.invoked_subcommand == "tf",
        terraform_refresh=terraform_refresh,
    )


@app.command(help="Run a generic Terraform command for the specified deployment.")
def tf(
    ctx: DeployContext,
    command: str = typer.Argument(
        ...,
        help="Terraform subcommand to run (e.g. 'plan', 'apply')."
    ),
    terraform_args: list[str] = typer.Argument(
        [],
        help="Extra args forwarded to terraform.",
        hidden=True
    ),
):
    subprocess.run(
        ["terraform", command] + terraform_args,
        cwd=os.path.join(config.TERRAFORM_PATH, "deployments", ctx.obj.environment),
        check=True,
    )


@app.command(help="Log-in to AWS ECR instance with Docker.")
def docker_login(
    ctx: DeployContext,
):
    ecr_image_uri = ctx.obj.terraform.ecr_image_uri

    with ctx.obj.console.status("Logging into ECR..."):
        password = subprocess.check_output(
            ["aws", "ecr", "get-login-password", "--region", config.AWS_REGION],
            text=True,
        )
        subprocess.check_output(
            ["docker", "login", "--username", "AWS", "--password-stdin", ecr_image_uri],
            input=password,
            text=True,
        )


@app.command(help="Build docker image for specified environment.")
def docker_build(
    ctx: DeployContext,
    branch: str = typer.Option(
        "main",
        "--branch", "-b",
        help="Git branch to build from in the local copy repo."
    ),
    push: bool = typer.Option(
        True,
        "--push/--no-push",
        help="Push the built image to ECR."
    ),
    cache: bool = typer.Option(
        True,
        "--cache/--no-cache",
        help="Use ECR registry cache when building."
    ),
    local: bool = typer.Option(
        False,
        "--local", "-l",
        help="Use the current working directory as the build context instead of the git copy path.",
    ),
) -> bool:
    ctx.invoke(docker_login, ctx=ctx)

    # Determine ECR Repo
    ecr_image_uri = ctx.obj.terraform.ecr_image_uri

    build_context_path = Path(".") if local else ctx.obj.docker_context_path

    # Build and upload docker image
    logging.info(f'Building docker image "{ecr_image_uri}"...')
    build_command = [
        "docker", "buildx", "build",
        str(build_context_path),
        "--platform=linux/amd64",
        "--provenance=false",
        "--sbom=false",
        "-t", ecr_image_uri,
    ]

    # Pull latest code
    if build_context_path != Path("."):
        ctx.obj.git.hard_reset_to_branch(branch)
        git_info = ctx.obj.git.get_info()
        build_command += [
            "--build-arg",
            f"COMMIT_HASH_MAIN={git_info['commit']['hexsha']}",
        ]

    if cache:
        build_command += [
            f"--cache-to=type=inline",
            f"--cache-from=type=registry,ref={ecr_image_uri}",
        ]
    else:
        build_command += ["--no-cache"]

    if push:
        build_command += ["--push"]

    build_command += ["-f", config.DOCKERFILE_PATH]

    build_command_str = (' ').join(build_command)
    logging.info(f'Running: \n"{build_command_str}"\n')

    build_process = subprocess.run(build_command)
    if build_process.returncode != 0:
        logging.error("Failed to build image.")
        return False

    if push:
        ctx.obj.log(DeployHistoryType.docker_image)

    if config.PRUNE_DOCKER_BUILDS:
        logging.info("Pruning unused docker images...")
        subprocess.run(["docker", "image", "prune", "-af"])

    return True


@app.command(help="Show ECS Services for a specified environment.")
def show_services(
    ctx: DeployContext,
    services: list[str] = typer.Argument(
        [],
        help="ECS services to inspect. Defaults to all services in the environment."
    ),
):
    deployments = ctx.obj.describe_service_deployments(services)
    print(tables.ECSDeploymentStatusTable(deployments))


@app.command(help="Show tasks for a specified environment.")
def show_tasks(
    ctx: DeployContext,
    services: list[str] = typer.Argument(
        [],
        help="ECS services whose tasks should be listed."
    ),
):
    tasks = ctx.obj.describe_service_tasks(services)
    print(tables.ECSTaskStatusTable(tasks))


@app.command(help="Watch deployments for a specified environment. Exits when the latest deployment completes.")
def watch_deployments(
    ctx: DeployContext,
    services: list[str] = typer.Argument(
        [],
        help="ECS services to watch."
    ),
):
    return ctx.obj.watch_deployments(services)


@app.command(help="Deploy specified EC2 service.")
def force_deploy(
    ctx: DeployContext,
    services: list[str] = typer.Argument(
        [],
        help="ECS services to force-redeploy with their current task definition."
    ),
):
    services = services or config.DEFAULT_SERVICES
    ctx.obj.update_services_and_wait(
        service_kwargs={s: {"forceNewDeployment": True} for s in services},
    )


@app.command(help="Print the current djd configuration (constants from config.py).")
def show_config(
    ctx: DeployContext,
):
    table = Table(title="djd Configuration", title_justify="left", box=box.SIMPLE)
    table.add_column("Name", justify="right", style="bold")
    table.add_column("Value")

    highlighter = ReprHighlighter()
    for name in sorted(vars(config)):
        if not name.isupper() or name.startswith("_"):
            continue
        table.add_row(name, highlighter(repr(getattr(config, name))))

    print(table)


@app.command(help="Show the current deployment state and history")
def history(
    ctx: DeployContext,
    raw: bool = typer.Option(
        False,
        "--raw", "-r",
        help="Print history as raw JSON instead of a formatted table."
    ),
    all: bool = typer.Option(
        False,
        "--all", "-a",
        help="Print all history entries."
    ),
):
    logging.info(f'Environment "{ctx.obj.environment}" deployment history:')

    if raw:
        print(ctx.obj.history)
    else:

        entries = ctx.obj.history[ctx.obj.environment]
        sorted_entries = list(
            reversed(
                sorted(entries, key=lambda x: datetime.fromisoformat(x["datetime"]))
            )
        )

        if all:
            table = tables.DeployHistoryTable(sorted_entries)
            print(table)
        else:
            n = 20
            table = tables.DeployHistoryTable(sorted_entries[:n])
            print(table)

            if len(entries) > n:
                print((
                    f"[dim]There are [reset][blue]{len(entries) - n}[reset][dim] older history entries currently hidden, "
                    f"use the --all arg to display them all. "
                ))


@app.command(help="Open an interactive shell in the latest task instance in the specified environment.")
def ssh(
    ctx: DeployContext,
    service: str = typer.Option(
        "web",
        "--service", "-s",
        help="ECS service to open a shell in (e.g. 'web', 'worker')."
    ),
):
    ctx.obj.execute_command("/bin/bash", service, interactive=True)


@app.command(help="Run a django management command in the latest task instance in the specified environment.")
def manage(
    ctx: DeployContext,
    command: list[str] = typer.Argument(
        ...,
        help="Django management command and its arguments (e.g. 'shell_plus')."
    ),
    service: str = typer.Option(
        "web",
        "--service", "-s",
        help="ECS service to run the management command against."
    ),
    new_task: bool = typer.Option(
        False,
        "--new-task", "-n",
        help="Run the command in a new ephemeral ECS task instead of execing into the existing service task.",
    ),
):
    cmd_str = (' ').join(command)
    cmd = f"uv run manage.py {cmd_str}"
    if new_task:
        run_task_response = ctx.obj.run_task(service, cmd)
        if not run_task_response:
            logging.info("Failed to start task")
            return
        task_arn = run_task_response["tasks"][0]["taskArn"]
        logging.info(f'Started task "{task_arn}"')

        task = ctx.obj.wait_for_task_completion(
            task_arn=task_arn,
            service=service,
            timeout_seconds=config.MIGRATION_TIMEOUT_SECONDS,
        )

        stop_code = task.get("stopCode")
        if stop_code == "EssentialContainerExited":
            logging.info("Task completed successfully")
        elif stop_code:
            logging.info(f"Task stopped with code: {stop_code}")
        else:
            logging.info("Task did not stop within the timeout")
        return
    ctx.obj.execute_command(cmd, service, interactive=True)


@app.command(help="Run migrations on a specified deployment database.")
def run_migrations(
    ctx: DeployContext,
    service: str = typer.Option(
        "web",
        "--service", "-s",
        help="ECS service whose task definition is used to run migrations."
    ),
):
    logging.info("Running Migrations")
    deployments = ctx.obj.describe_service_deployments(services=[service])

    if ctx.obj.confirm or ctx.obj.debug:
        print(tables.ECSDeploymentStatusTable(deployments))

    if ctx.obj.get_confirmation("Run Migration?"):
        run_task_response = ctx.obj.run_task(service, "uv run manage.py migrate --no-input")
        if not run_task_response:
            logging.info("Migration Failed")
            return False

        migration_task_arn = run_task_response["tasks"][0]["taskArn"]
        logging.info(f'Started task "{migration_task_arn}"')
        task = ctx.obj.wait_for_task_completion(
            task_arn=migration_task_arn,
            service=service,
            timeout_seconds=config.MIGRATION_TIMEOUT_SECONDS,
        )

        stop_code = task.get("stopCode")
        if stop_code == "EssentialContainerExited":
            logging.info("Migration Successful")
            ctx.obj.log(DeployHistoryType.migration)
            return True
        elif stop_code == "TaskFailedToStart":
            logging.info("Migration task failed to start. Exiting...")
        elif stop_code:
            logging.info("Migration Task stopcode:")
            logging.info(stop_code)

        logging.info("Migration Failed")
        return False


@app.command(help="Set selected service to desired_count = 0.")
def stop_service(
    ctx: DeployContext,
    services: list[str] = typer.Argument(
        [],
        help="ECS services to stop."
    ),
):
    services = services or config.DEFAULT_SERVICES
    ctx.obj.update_services_and_wait(service_kwargs={
        s: {"desiredCount": 0}
        for s in services
    })


@app.command(help="Restore selected service's desired_count to the terraform-defined value.")
def restart_service(
    ctx: DeployContext,
    services: list[str] = typer.Argument(
        [],
        help="ECS services to restart."
    ),
):
    services = services or config.DEFAULT_SERVICES
    ctx.obj.update_services_and_wait(service_kwargs={
        s: {"desiredCount": ctx.obj.terraform.services[s].desired_count}
        for s in services
    })


@app.command(help="Run entire deployment process.")
def deploy(
    ctx: DeployContext,
    services: list[str] = typer.Argument(
        [],
        help="ECS services to deploy. Defaults to DEFAULT_SERVICES."
    ),
    service: str = typer.Option(
        "web",
        "--service", "-s",
        help="ECS service used to run database migrations."
    ),
    branch: str = typer.Option(
        "main",
        "--branch", "-b",
        help="Git branch to deploy."
    ),
    push: bool = typer.Option(
        True,
        "--push/--no-push",
        help="Push the built image to ECR."
    ),
    cache: bool = typer.Option(
        True,
        "--cache/--no-cache",
        help="Use ECR registry cache when building."
    ),
    migration: bool = typer.Option(
        True,
        "--migration/--no-migration",
        help="Run database migrations as part of the deploy."
    ),
    build: bool = typer.Option(
        True,
        "--build/--no-build",
        help="Build and push a new docker image before deploying."
    ),
    stop_workers: bool = typer.Option(
        True,
        "--stop-workers/--no-stop-workers",
        help="Stop worker services during migration and restart them afterwards.",
    ),
    promote_image: str | None = typer.Option(
        None,
        "--promote-image", "-p",
        help="ECR image URI to promote into this environment instead of building a new one.",
    ),
):
    services = services or config.DEFAULT_SERVICES

    if ctx.obj.github_workflow:
        ctx.obj.git.dispatch_github_workflow(
            "deploy",
            {
                "services": (" ").join(services),
                "environment": ctx.obj.environment,
                "branch": branch,
                "migration": migration,
            },
        )
        return True

    # Build docker container from git code, or promote an image from a separate ECR repo
    if promote_image:
        ctx.obj.promote_image(promote_image)
    elif build:
        build_result = ctx.invoke(docker_build, ctx=ctx, branch=branch, push=push, cache=cache)
        if not build_result:
            logging.error("Failed to build image, aborting deployment.")
            return

    # Poll for the migration task completing successfully (abort whole deploy if it fails)
    if migration:
        if stop_workers:
            ctx.invoke(
                stop_service,
                ctx=ctx,
                services=config.DEFAULT_WORKER_SERVICES,
            )

        migration_result = ctx.invoke(
            run_migrations,
            ctx=ctx,
            service=service,
        )
        if not migration_result:
            logging.error("Failed to run migrations, aborting deployment.")
            return

    ctx.obj.update_services_and_wait(
        service_kwargs={
            s: {
                "forceNewDeployment": True,
                "desiredCount": ctx.obj.terraform.services[s].desired_count,
            }
            for s in services
        },
    )


def main():
    app()
