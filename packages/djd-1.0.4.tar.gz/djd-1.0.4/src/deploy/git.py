import logging
import re
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import git
import github
from github.WorkflowRun import WorkflowRun

from deploy.config import GIT_COPY_PATH, REMOTE_REPO_NAME, REMOTE_REPO_URL


class GitCopyRepo(git.Repo):

    def __init__(self, path: Path = GIT_COPY_PATH, *args, **kwargs) -> None:
        self.remote_repo_name = REMOTE_REPO_NAME or self._discover_origin_repo_name()
        self.remote_repo_url = REMOTE_REPO_URL or f"git@github.com:{self.remote_repo_name}.git"

        if not path.exists():
            git.Repo.clone_from(self.remote_repo_url, GIT_COPY_PATH)
        super().__init__(path, *args, **kwargs)

    @staticmethod
    def _discover_origin_repo_name() -> str:
        local_repo = git.Repo(search_parent_directories=True)
        url = local_repo.remotes.origin.url
        match = re.search(r"[:/]([^/:]+/[^/]+?)(?:\.git)?/?$", url)
        if not match:
            raise ValueError(f'Cannot determine "owner/repo" from origin URL: {url}')
        return match.group(1)

    def hard_reset_to_branch(self, branch: str):
        self.git.fetch("--all")

        logging.info(f'Resetting to remote branch "origin/{branch}"')
        self.git.reset("--hard", f"origin/{branch}")

        # Update submodules recursively
        logging.info("Initializing and updating submodules")
        self.git.submodule("update", "--init", "--recursive", "--force")

    def get_info(self):
        commit = self.head.commit

        return {
            "branch": self.active_branch.name if not self.head.is_detached else None,
            "commit": {
                "hexsha": commit.hexsha,
                "author_name": commit.author.name,
                "author_email": commit.author.email,
                "authored_datetime": commit.authored_datetime.isoformat(),
                "committer_name": commit.committer.name,
                "committer_email": commit.committer.email,
                "committed_datetime": commit.committed_datetime.isoformat(),
                "message": commit.message.strip(),
                "parents": [p.hexsha for p in commit.parents],
                "tags": [tag.name for tag in self.tags if tag.commit == commit],
            },
            "remotes": {remote.name: list(remote.urls) for remote in self.remotes},
            "submodules": {s.name: s.hexsha for s in self.submodules},
            "dirty": self.is_dirty(),
        }

    def init_github_repo(self):
        if self.github and self.github_repo:
            return
        gh_auth_token = subprocess.check_output(["gh", "auth", "token"], text=True)
        gh_auth_token = gh_auth_token.strip("\n")
        self.github = github.Github(gh_auth_token)
        self.github_repo = self.github.get_repo(self.remote_repo_name)

    def dispatch_github_workflow(
        self, name: str, inputs: dict[str, Any], branch: str = "main"
    ):
        self.init_github_repo()

        workflow = self.github_repo.get_workflow(f"{name}.yml")
        dispatch_time = datetime.now(timezone.utc)
        workflow.create_dispatch(ref=branch, inputs=inputs)

        # Poll for the most recent run of this workflow on main
        logging.info(f"Dispatched github workflow {name}, waiting for it to start...")
        logging.info(
            f"View runs: https://github.com/{self.github_repo.full_name}/actions/workflows/{workflow.id}"
        )

        # Get the run that was just dispatched
        run: WorkflowRun | None = None
        while not run:
            runs = workflow.get_runs(branch=branch, event="workflow_dispatch")
            for candidate in runs:
                if candidate.created_at >= dispatch_time:
                    run = candidate
                    break
            if not run:
                time.sleep(1)

        logging.info(f"Workflow run started: {run.html_url}")
