import datetime
import logging
import os
from pathlib import Path
import time

import boto3
import pytz
from rich.logging import RichHandler

from deploy.config import DEPLOY_PATH


LOG_PATH = Path(DEPLOY_PATH, "logs")
LOG_TIME_ZONE = "America/New_York"
LOG_TIME_FORMAT = "%Y-%m-%d %I:%M:%S %p"
LOG_RESET_COLOR = "[white]"
LOG_COLORS = {
    logging.DEBUG: "[gray]",
    logging.INFO: "[green]",
    logging.WARNING: "[yellow]",
    logging.ERROR: "[red]",
    logging.CRITICAL: "[magenta]",
}


class ColoredFormatter(logging.Formatter):
    def format(self, record):
        current_time = time.localtime(record.created)
        date_str = time.strftime(LOG_TIME_FORMAT, current_time)
        log_color = LOG_COLORS.get(record.levelno, LOG_RESET_COLOR)
        levelname = f"{log_color}{record.levelname:<8s}{LOG_RESET_COLOR}"
        formatted = f"{levelname} {date_str}: {record.message}"
        return formatted


def initialize_logging(
    log_name: str = "lab",
    timezone: str = LOG_TIME_ZONE,
    log_level: int | None = None,
):
    if not os.path.exists(LOG_PATH):
        os.makedirs(LOG_PATH)

    log_path = os.path.join(LOG_PATH, f"{log_name}.log")
    file_handler = logging.FileHandler(log_path)

    rich_handler = RichHandler(
        show_time=False,
        show_level=False,
        show_path=False,
        omit_repeated_times=True,
        markup=True,
    )
    level = log_level or logging.INFO
    rich_handler.setLevel(level)
    rich_handler.setFormatter(ColoredFormatter())

    logging.basicConfig(
        level=logging.INFO,
        format="%(levelname)-8s %(asctime)s %(message)s",
        datefmt=LOG_TIME_FORMAT,
        handlers=[
            file_handler,
            rich_handler,
        ],
    )

    # Use selected Timezone
    logging.Formatter.converter = lambda *args: (datetime.datetime.now(tz=pytz.timezone(timezone)).timetuple())

    # Reduce boto3 credentials logging
    # e.g. "Found credentials in shared credentials file: ~/.aws/credentials"
    boto3.set_stream_logger(name="botocore.credentials", level=logging.ERROR)
