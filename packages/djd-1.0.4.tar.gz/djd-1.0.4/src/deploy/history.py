from enum import Enum


class DeployHistoryType(Enum):
    deployment = "Deployment"
    migration = "Migration"
    terraform_apply = "Terraform Apply"
    docker_image = "Docker Image"
