from datetime import timezone
from typing import Any
from rich import box
from rich.table import Table
from rich.text import Text
from github.WorkflowRun import WorkflowRun

from deploy.history import DeployHistoryType
from deploy.renderables.util import RenderableDatetime


class StatusTable(Table):

    def __init__(self, entries: list[Any] = [], *args, **kwargs):
        kwargs.setdefault("title_justify", "left")
        kwargs.setdefault("box", box.SIMPLE)
        super().__init__(*args, **kwargs)

    @classmethod
    def single_entry(cls, entry: Any, *args, **kwargs):
        kwargs.setdefault("title", None)
        kwargs.setdefault("show_header", False)
        table = cls(**kwargs)
        table.add_entry(entry, *args, **kwargs)
        return table

    def add_entry(self, entry: Any, *args, **kwargs):
        pass


class WorkflowRunTable(StatusTable):

    def __init__(self, entries: list[WorkflowRun] = [], *args, **kwargs):
        kwargs.setdefault("title", "Github Workflow Status")
        super().__init__(entries, *args, **kwargs)

        self.add_column("Timestamp", style="dim")
        self.add_column("Actor", width=30)
        self.add_column("Workflow", width=30)
        self.add_column("Status", width=30)

        for entry in entries:
            self.add_entry(entry)

    def add_entry(self, entry: WorkflowRun, *args, **kwargs):
        status_text = {
            "pending": Text("Pending", style="grey"),
            "queued": Text("Queued", style="bright_yellow"),
            "in_progress": Text("In Progress", style="cyan"),
            "completed": Text("Completed", style="green"),
        }[entry.status]

        self.add_row(
            RenderableDatetime.now(timezone.utc),
            entry.actor.name,
            entry.display_title,
            status_text,
        )


class ECSDeploymentStatusTable(StatusTable):

    def __init__(self, entries: list[dict] = [], *args, **kwargs):
        kwargs.setdefault("title", "Deployment Status")
        super().__init__(*args, **kwargs)

        self.add_column("Deployment ID", width=30, style="dim")
        self.add_column("Service", width=30)
        self.add_column("Latest", width=10)
        self.add_column("Created On", width=25)
        self.add_column("Count", width=15)
        self.add_column("Status", width=15)
        self.add_column("Rollout State", width=20)

        for entry in entries:
            self.add_entry(entry)

    def add_entry(self, entry: dict, *args, **kwargs):
        created_at = RenderableDatetime.from_datetime(entry["createdAt"])
        count_str = f"{entry['pendingCount']} -> {entry['runningCount']} / {entry['desiredCount']}"
        deployment_status = {
            "PRIMARY": Text("Primary", style="green"),
            "ACTIVE": Text("Active", style="blue"),
            "DRAINING": Text("Draining", style="red"),
        }.get(entry["status"], entry["status"])
        rollout_state = {
            "IN_PROGRESS": Text("In Progress", style="blue"),
            "FAILED": Text("Failed", style="red"),
            "COMPLETED": Text("Completed", style="green"),
        }.get(entry["rolloutState"], entry["rolloutState"])

        self.add_row(
            entry["id"],
            entry["service"],
            Text("*" if entry["is_latest"] else "", style="green"),
            created_at,
            count_str,
            deployment_status,
            rollout_state,
        )


class ECSTaskStatusTable(StatusTable):

    def __init__(self, entries: list[dict] = [], *args, **kwargs):
        kwargs.setdefault("title", "Task Status")
        super().__init__(*args, **kwargs)

        self.add_column("Task ID", style="dim")
        self.add_column("Task Definition ID")
        self.add_column("Created At")
        self.add_column("Health Status", width=20)
        self.add_column("Status", width=20)

        for entry in entries:
            self.add_entry(entry)

    def add_entry(self, entry: dict, *args, **kwargs):
        created_at = RenderableDatetime.from_datetime(entry["createdAt"])
        task_id = entry["taskArn"].split("/")[-1]
        task_definition_id = entry["taskDefinitionArn"].split("/")[-1]
        task_status = {
            "PROVISIONING": Text("Provisioning", style="blue"),
            "PENDING": Text("Pending", style="yellow"),
            "RUNNING": Text("Running", style="green"),
            "DEPROVISIONING": Text("Deprovisioning", style="red"),
        }.get(entry["lastStatus"], entry["lastStatus"])
        task_health = {
            "UNKNOWN": Text("Unknown", style="blue"),
            "UNHEALTHY": Text("Unhealthy", style="red"),
            "HEALTHY": Text("Healthy", style="green"),
        }.get(entry["healthStatus"], entry["healthStatus"])

        self.add_row(
            task_id,
            task_definition_id,
            created_at,
            task_health,
            task_status,
        )


class DeployHistoryTable(StatusTable):

    def __init__(self, entries: list[dict] = [], *args, **kwargs):
        kwargs.setdefault("title", "Deployment History")
        super().__init__(*args, **kwargs)

        self.add_column("Timestamp", style="dim")
        self.add_column("Action")
        self.add_column("Deployed By")
        self.add_column("Deploy Environment")
        self.add_column("Branch")
        self.add_column("Commit")
        self.add_column("Author")
        self.add_column("Message")

        for entry in entries:
            self.add_entry(entry)

    def add_entry(self, entry: dict, *args, **kwargs):
        timestamp = RenderableDatetime.from_str(entry["datetime"])

        msg = (
            entry["git"]["commit"]["message"]
            if "git" in entry
            else entry["commit"]["msg"]
        )
        messages = [e for e in msg.split("\n") if e]
        message = messages[0] + (f" ..." if len(messages) > 1 else "")

        deployed_by = ""
        if iam_user := entry.get("iam_user"):
            deployed_by = iam_user["Arn"].split("/")[-1]

        deploy_type = DeployHistoryType[entry["deploy_type"]]
        action_text = Text(
            str(deploy_type.value),
            style={
                DeployHistoryType.deployment: "green",
                DeployHistoryType.migration: "yellow",
                DeployHistoryType.terraform_apply: "blue",
                DeployHistoryType.docker_image: "cyan",
            }.get(deploy_type, "white"),
        )

        # Deployment name (if available)
        deployment_name = entry.get("deployment_name", "")

        self.add_row(
            timestamp,
            action_text,
            deployed_by,
            deployment_name,
            *(
                [
                    entry["git"]["branch"],
                    entry["git"]["commit"]["hexsha"][:6],
                    entry["git"]["commit"]["author_name"],
                ]
                if "git" in entry
                else [
                    entry["commit"]["branch"],
                    entry["commit"]["hexsha"][:6],
                    entry["commit"]["author"],
                ]
            ),
            message,
        )
