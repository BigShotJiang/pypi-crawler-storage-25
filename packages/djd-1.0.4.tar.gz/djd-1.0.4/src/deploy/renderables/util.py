import datetime

import pytz
from rich.panel import Panel
from deploy.logging import LOG_TIME_FORMAT, LOG_TIME_ZONE
from rich.text import Text


class RenderableDatetime(datetime.datetime):
    """
    A datetime subclass that renders nicely.
    """

    def __rich__(self):
        if self is None:
            return Text("None", style="dim italic")
        dt = self.astimezone(pytz.timezone(LOG_TIME_ZONE))
        formatted = dt.strftime(LOG_TIME_FORMAT)
        return Text(formatted, style="bold cyan")

    @classmethod
    def from_datetime(cls, dt: datetime.datetime | None):
        if dt is None:
            return None
        return cls(
            dt.year,
            dt.month,
            dt.day,
            dt.hour,
            dt.minute,
            dt.second,
            dt.microsecond,
            dt.tzinfo,
        )

    @classmethod
    def from_str(cls, dt_str: str | None):
        if dt_str is None:
            return None
        dt = datetime.datetime.fromisoformat(dt_str)
        return cls.from_datetime(dt)


def render_diff(diff: list[str], filename: str):
    text = Text()
    for line in diff:
        if line.startswith("+") and not line.startswith("+++"):
            text.append(line, style="green")
        elif line.startswith("-") and not line.startswith("---"):
            text.append(line, style="red")
        else:
            text.append(line)
        if not line.endswith("\n"):
            text.append("\n")
    return Panel(text, title=filename, border_style="blue")
