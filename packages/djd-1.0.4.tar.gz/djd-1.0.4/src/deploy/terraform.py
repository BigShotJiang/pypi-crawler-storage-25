import difflib
from datetime import datetime
from pathlib import Path
from typing import Any
from jinja2 import Environment, FileSystemLoader
from pydantic import BaseModel, Field


TEMPLATES_DIR = Path(__file__).parent / "templates"


class ServiceOutputs(BaseModel):
    service_name: str
    desired_count: int
    log_group_arn: str | None = None
    task_definition_arn: str | None = None
    network_configuration_security_groups: list[str] | None = None
    network_configuration_subnets: list[str] | None = None


class TerraformOutputs(BaseModel):
    cluster_id: str
    ecr_image_uri: str
    ecr_repository_name: str
    s3_bucket_name: str
    services: dict[str, ServiceOutputs]


class TerraformCacheEntry(BaseModel):
    output: dict[str, Any]
    cached_at: datetime

    def is_expired(self, ttl_seconds: float) -> bool:
        return (datetime.now() - self.cached_at).total_seconds() > ttl_seconds


class DeployState(BaseModel):
    terraform: dict[str, TerraformCacheEntry] = Field(default_factory=dict)


def render_templates(context: dict, templates_dir: str):
    """
    Walk all template files recursively, yielding the rendered content itself and the template path.
    """
    templates_dir_path = TEMPLATES_DIR / templates_dir

    env = Environment(loader=FileSystemLoader(TEMPLATES_DIR))
    for template_file in TEMPLATES_DIR.rglob("*.j2"):

        if templates_dir and not template_file.is_relative_to(templates_dir_path):
            continue

        # Relative path from the template root
        template_path = template_file.relative_to(TEMPLATES_DIR)

        # Render the path itself as a Jinja2 template
        rendered_path_str = env.from_string(str(template_path)).render(**context)
        output_path = Path(rendered_path_str).with_suffix("")

        # Render the file contents
        template = env.get_template(str(template_path))
        rendered_content = template.render(**context)

        yield rendered_content, output_path


def diff_templates(rendered_content: str, output_path: Path):
    existing_content = output_path.read_text()
    if existing_content != rendered_content:
        return list(
            difflib.unified_diff(
                existing_content.splitlines(),
                rendered_content.splitlines(),
                fromfile=str(output_path),
                tofile=f"{output_path} (new)",
                lineterm="",
            )
        )


def parse_terraform_output(output: dict, services: list[str], environment: str) -> TerraformOutputs:
    service_outputs: dict[str, ServiceOutputs] = {}
    for service in services:
        prefix = f"{service}_"
        service_fields = {
            key[len(prefix):]: val
            for key, val in output.items()
            if key.startswith(prefix)
        }
        if not service_fields:
            raise RuntimeError(
                f"Terraform outputs for environment '{environment}' have no keys for "
                f"service '{service}'. Expected keys prefixed with '{prefix}'."
            )
        service_outputs[service] = ServiceOutputs.model_validate(service_fields)

    service_prefixes = tuple(f"{s}_" for s in services)
    global_fields = {
        key: val
        for key, val in output.items()
        if not key.startswith(service_prefixes)
    }
    return TerraformOutputs(services=service_outputs, **global_fields)
