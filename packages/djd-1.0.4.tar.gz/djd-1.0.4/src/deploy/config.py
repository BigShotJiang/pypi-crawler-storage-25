import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

# Load .env from config/.env as a fallback
config_env_path = Path("config/.env")
if config_env_path.exists():
    load_dotenv(dotenv_path=config_env_path, override=False)


_true_str_options = ("1", "true", "yes")

# Use env variables if set, otherwise fall back to defaults
DEPLOY_PATH = Path(os.getenv("DEPLOY_PATH", ".deploy"))
STATE_PATH = Path(os.getenv("STATE_PATH", DEPLOY_PATH / Path("state.json")))
HISTORY_PATH = Path(os.getenv("HISTORY_PATH", DEPLOY_PATH / Path("history.json")))
GIT_COPY_PATH = Path(os.getenv("GIT_COPY_PATH", ".git-copy"))
TERRAFORM_PATH = Path(os.getenv("TERRAFORM_PATH", "terraform"))
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
AWS_PROFILE = os.getenv("AWS_PROFILE", None)
MIGRATION_TIMEOUT_SECONDS = float(os.getenv("MIGRATION_TIMEOUT_SECONDS", 10 * 60))
TERRAFORM_CACHE_TTL = float(os.getenv("TERRAFORM_CACHE_TTL", 60 * 60 * 24))  # seconds
REMOTE_REPO_NAME = os.getenv("REMOTE_REPO_NAME", "")
REMOTE_REPO_URL = os.getenv("REMOTE_REPO_URL", f"git@github.com:{REMOTE_REPO_NAME}.git" if REMOTE_REPO_NAME else "")
DOCKERFILE_PATH = os.getenv("DOCKERFILE_PATH", "Dockerfile")
DEFAULT_SERVICES = os.getenv("DEFAULT_SERVICES", "web,worker").split(",")
DEFAULT_WORKER_SERVICES = os.getenv("DEFAULT_WORKER_SERVICES", "worker").split(",")
PRUNE_DOCKER_BUILDS = os.getenv("PRUNE_DOCKER_BUILDS", "false").lower() in _true_str_options
CONFIRM_DEFAULT = os.getenv("CONFIRM_DEFAULT", "false").lower() in _true_str_options

# Documentation --
# Definitely set AWS_PROFILE, AWS_REGION, and REMOTE_REPO_NAME

# TODO: Fix getting `settings.py` from django -- this should be optional somehow
# # Assume user runs code from their project root, otherwise they need to set `PROJECT_ROOT` variable
# PROJECT_ROOT = os.environ.get("PROJECT_ROOT") or os.getcwd()
# if PROJECT_ROOT not in sys.path:
#     sys.path.insert(0, PROJECT_ROOT)
#
# os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
#
# try:
#     django.setup()
# except ModuleNotFoundError:
#     pass
