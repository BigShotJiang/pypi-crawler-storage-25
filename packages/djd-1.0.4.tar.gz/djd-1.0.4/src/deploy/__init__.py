from deploy.logging import initialize_logging

initialize_logging(log_name="deploy")
