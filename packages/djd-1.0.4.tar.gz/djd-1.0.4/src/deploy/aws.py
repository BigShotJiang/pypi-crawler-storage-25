import logging
import pty
import subprocess
import traceback
from typing import Any
from urllib.parse import quote

from botocore.exceptions import BotoCoreError, ClientError

from deploy.config import AWS_REGION

def describe_service_deployments(client, cluster: str, services: list[str]):
    describe_services_response = client.describe_services(cluster=cluster, services=services)

    all_deployment_updates = []
    for response in describe_services_response["services"]:
        service_name = response["serviceName"]
        deployment_updates = response["deployments"]
        latest_deployment_id = next(reversed(sorted(deployment_updates, key=lambda x: x["createdAt"])))["id"]

        for deployment_update in deployment_updates:
            deployment_update["service"] = service_name
            deployment_update["is_latest"] = latest_deployment_id == deployment_update["id"]
            all_deployment_updates.append(deployment_update)

    return all_deployment_updates


def describe_service_tasks(client, cluster: str, services: list[str] | None = None):
    task_ids = []
    if services:
        for service in services:
            list_tasks_response = client.list_tasks(cluster=cluster, serviceName=service)
            task_ids += list_tasks_response["taskArns"]
    else:
        list_tasks_response = client.list_tasks(cluster=cluster)
        task_ids += list_tasks_response["taskArns"]

    tasks = []
    if task_ids:
        describe_tasks_response = client.describe_tasks(cluster=cluster, tasks=task_ids)
        tasks = describe_tasks_response["tasks"]

    return tasks


def execute_command(client, command: str, cluster: str, service: str, interactive: bool = False):
    list_tasks_response = client.list_tasks(cluster=cluster, serviceName=service)
    task_ids = list_tasks_response["taskArns"]

    # TODO: exec command in most recent task (sort first)

    if len(task_ids):
        task_id = task_ids[0]

        logging.info("Starting Interactive Session...")
        cmd = ["aws", "ecs", "execute-command", "--cluster", cluster, "--region",
               AWS_REGION, "--task", task_id, "--interactive", "--command", command]
        logging.info(f'Running Command: \n"{(" ").join(cmd)}"')

        try:
            if interactive:
                pty.spawn(cmd)
            else:
                subprocess.run(
                    cmd,
                    check=True,
                    text=True,
                    capture_output=True
                )

        except subprocess.CalledProcessError as e:
            traceback.print_exception(e)
            logging.error("Command failed")

    else:
        logging.info("No running task")


def copy_ecr_image(
    client,
    source_repo_name: str,
    target_repo_name: str,
    image_tag: str = "latest",
):
    try:
        # Get the image manifest from the source repo
        get_response = client.batch_get_image(repositoryName=source_repo_name, imageIds=[{"imageTag": image_tag}])

        if not get_response["images"]:
            raise RuntimeError("Image not found in source repo")

        image = get_response["images"][0]
        manifest = image["imageManifest"]
        media_type = image.get("imageManifestMediaType", "application/vnd.docker.distribution.manifest.v2+json")

        # Push the manifest to the target repo
        client.put_image(
            repositoryName=target_repo_name,
            imageManifest=manifest,
            imageTag=image_tag,
            imageManifestMediaType=media_type,
        )

    except (ClientError, BotoCoreError):
        return False

    return True


def cloudwatch_start_live_tail(
    client,
    log_group_arn: str,
    log_stream_names: list[str] | None = None,
    log_stream_name_prefixes: list[str] | None = None,
):
    """
    Open a CloudWatch live tail session and return the streaming response.
    Returns None if the caller lacks the logs:StartLiveTail permission.
    """
    kwargs: dict[str, Any] = {"logGroupIdentifiers": [log_group_arn]}
    if log_stream_names:
        kwargs["logStreamNames"] = log_stream_names
    if log_stream_name_prefixes:
        kwargs["logStreamNamePrefixes"] = log_stream_name_prefixes

    try:
        response = client.start_live_tail(**kwargs)
    except ClientError as e:
        if e.response.get("Error", {}).get("Code") == "AccessDeniedException":
            logging.warning(f"Skipping live log tail due to error: {e.response['Error'].get('Message', '')}")
            return None
        raise
    return response["responseStream"]


def cloudwatch_print_live_tail_events(event_stream, cancelled=lambda: False):
    """
    Iterate a live tail event stream, printing log messages until it closes.

    `cancelled` should return True when the stream is being closed intentionally
    by the caller, so the resulting iterator error can be silenced.
    """
    try:
        for event in event_stream:
            if "sessionUpdate" in event:
                for log_event in event["sessionUpdate"].get("sessionResults", []):
                    print(log_event["message"])
            elif "SessionTimeoutException" in event or "SessionStreamingException" in event:
                logging.warning(f"Live tail session ended: {event}")
                break
    except Exception as e:
        if not cancelled():
            logging.warning(f"Live tail stream error: {e}")


def cloudwatch_get_log_url(log_group_arn: str) -> str:
    log_group_name = log_group_arn.split(":log-group:", 1)[1].removesuffix(":*")
    encoded = quote(log_group_name, safe="").replace("%", "$25")
    return f"https://{AWS_REGION}.console.aws.amazon.com/cloudwatch/home?region={AWS_REGION}#logsV2:log-groups/log-group/{encoded}"
