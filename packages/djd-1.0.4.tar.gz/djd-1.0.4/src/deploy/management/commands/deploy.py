from deploy.management.base_command import BaseTyperCommand
from deploy.cli.deploy import app


class Command(BaseTyperCommand):
    app = app
