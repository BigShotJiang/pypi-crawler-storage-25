from deploy.management.base_command import BaseTyperCommand
from deploy.cli.templates import app


class Command(BaseTyperCommand):
    app = app
