import typer
from django.core.management.base import BaseCommand


class BaseTyperCommand(BaseCommand):
    app: typer.Typer

    def run_from_argv(self, argv):
        """
        Override Django’s default behavior to hand off argument parsing entirely to Typer.
        """
        self.app(prog_name=self.app.info.name, args=argv[2:])
