import inspect
import json
import logging
import os
import subprocess
import threading
import time
from collections import defaultdict
from datetime import datetime
from json import JSONDecodeError
from pathlib import Path
from typing import Any

import click
import typer
from boto3 import session as boto_session
from botocore.exceptions import ClientError
from pydantic import ValidationError
from rich import print
from rich.console import Console

import deploy.aws as aws
import deploy.config as config
import deploy.renderables.tables as tables
import deploy.terraform as tf
from deploy.git import GitCopyRepo
from deploy.history import DeployHistoryType
from deploy.renderables.util import RenderableDatetime


class DeployContext(typer.Context):
    obj: "DeployContextObj"


class DeployContextObj:
    state: tf.DeployState
    terraform: tf.TerraformOutputs

    def __init__(
        self,
        environment: str,
        debug: bool = False,
        confirm: bool = False,
        refresh: float = 1.0,
        docker_context_path: Path = config.GIT_COPY_PATH,
        github_workflow: bool = False,
        skip_terraform_validation: bool = False,
        terraform_refresh: bool = False,
    ):
        self.console = Console()

        self.environment = environment

        if config.AWS_PROFILE:
            os.environ['AWS_PROFILE'] = config.AWS_PROFILE
            self.boto_session = boto_session.Session(profile_name=config.AWS_PROFILE)
        else:
            self.boto_session = boto_session.Session()

        self.debug = debug
        self.confirm = confirm
        self.refresh = refresh
        self.docker_context_path = docker_context_path
        self.github_workflow = github_workflow
        self.terraform_refresh = terraform_refresh

        with self.console.status(f'Initializing Git Copy Repo at "{config.GIT_COPY_PATH}"'):
            self.git = GitCopyRepo()

        self.state = self.load_state()

        self.ecs_client = self.boto_session.client(service_name="ecs", region_name=config.AWS_REGION)
        self.ecr_client = self.boto_session.client(service_name="ecr", region_name=config.AWS_REGION)
        self.sts_client = self.boto_session.client(service_name="sts", region_name=config.AWS_REGION)
        self.s3_client = self.boto_session.client(service_name="s3", region_name=config.AWS_REGION)
        self.logs_client = self.boto_session.client(service_name="logs", region_name=config.AWS_REGION)
        self.sts_caller_identity = self.sts_client.get_caller_identity()

        try:
            self.terraform = self.get_terraform_output(self.environment)
        except (ValidationError, RuntimeError) as e:
            if not skip_terraform_validation:
                raise
            logging.warning(f"Skipping terraform output validation: {e}")
            return

        self.s3_bucket_name = self.terraform.s3_bucket_name
        self.history = self._download_history()

    def load_state(self) -> tf.DeployState:
        if config.STATE_PATH.exists():
            try:
                return tf.DeployState.model_validate_json(config.STATE_PATH.read_text())
            except ValidationError as e:
                logging.warning(f"State file at {config.STATE_PATH} is invalid, starting fresh: {e}")
        else:
            config.STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
        return tf.DeployState()

    def save_state(self):
        config.STATE_PATH.write_text(self.state.model_dump_json(indent=4))

    def get_terraform_output(self, environment: str | None = None) -> tf.TerraformOutputs:
        environment = environment or self.environment

        cached = self.state.terraform.get(environment)
        if cached and not cached.is_expired(config.TERRAFORM_CACHE_TTL) and not self.terraform_refresh:
            return tf.parse_terraform_output(cached.output, config.DEFAULT_SERVICES, environment)

        with self.console.status(f"Collecting terraform output for '{environment}'..."):
            cwd = config.TERRAFORM_PATH.joinpath("deployments", environment)
            result = subprocess.run(
                ["terraform", "refresh"],
                cwd=cwd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
            )
            if result.returncode != 0:
                logging.error(f"Terraform refresh failed:\n{result.stderr}")
                raise RuntimeError("Terraform refresh failed")

            output_str = subprocess.check_output(
                ["terraform", "output", "--json"],
                cwd=cwd,
                text=True,
            )

        try:
            output = json.loads(output_str)
        except JSONDecodeError as e:
            logging.error(e)
            logging.error(output_str)
            raise

        for key, val in output.items():
            output[key] = val["value"]

        self.state.terraform[environment] = tf.TerraformCacheEntry(
            output=output,
            cached_at=datetime.now(),
        )
        self.save_state()

        return tf.parse_terraform_output(output, config.DEFAULT_SERVICES, environment)

    def get_confirmation(self, message: str, confirm: bool = False):
        if not self.confirm or confirm:
            logging.info(f"Skipping confirmation...")
            return True

        confirmation = input(f"{message} [Y/n] ")
        return confirmation.lower() in ["y", "yes", ""]

    def describe_service_deployments(self, services: list[str]):
        return aws.describe_service_deployments(
            self.ecs_client,
            self.terraform.cluster_id,
            [self.terraform.services[service].service_name for service in services or config.DEFAULT_SERVICES],
        )

    def describe_service_tasks(self, services: list[str]):
        return aws.describe_service_tasks(
            self.ecs_client,
            self.terraform.cluster_id,
            [self.terraform.services[service].service_name for service in services or config.DEFAULT_SERVICES],
        )

    def describe_tasks(self, task_arns: list[str], *args, **kwargs):
        return self.ecs_client.describe_tasks(cluster=self.terraform.cluster_id, tasks=task_arns, *args, **kwargs)

    def update_service(self, service: str = "web", *args, **kwargs):
        with self.console.status(f"Updating service {service}..."):
            return self.ecs_client.update_service(
                cluster=self.terraform.cluster_id,
                service=self.terraform.services[service].service_name,
                *args,
                **kwargs,
            )

    def watch_deployments(
        self,
        services: list[str],
        service_kwargs: dict[str, dict[str, Any]] | None = None,
        pre_existing_deployment_ids: set[str] | None = None,
    ) -> bool:
        """
        Poll ECS deployments for `services` until the latest deployment per service has rolled out.

        When called from `update_services_and_wait`, `service_kwargs` and
        `pre_existing_deployment_ids` gate completion until the requested change
        is visible in describe_services output — otherwise eventual-consistency
        reads of pre-update state can satisfy `running == desired` prematurely.
        """
        services = services or config.DEFAULT_SERVICES
        service_kwargs = service_kwargs or {}
        pre_existing_deployment_ids = pre_existing_deployment_ids or set()

        status = defaultdict(dict)
        status_keys_watched = ["status", "rolloutState", "runningCount", "desiredCount"]

        table = tables.ECSDeploymentStatusTable()
        deployment_updates = self.describe_service_deployments(services)
        for deployment_update in reversed(sorted(deployment_updates, key=lambda x: x["createdAt"])):
            status[deployment_update["id"]] = deployment_update
            table.add_entry(deployment_update)
        print(table)

        services_pending = set(services)

        try:
            while True:
                changed = False
                removed = set(status.keys())

                deployment_updates = self.describe_service_deployments(services)
                for deployment_update in deployment_updates:
                    if deployment_update["id"] not in removed:
                        status[deployment_update["id"]] = deployment_update
                        changed = True
                    else:
                        removed.remove(deployment_update["id"])

                    deployment = status[deployment_update["id"]]
                    for key in status_keys_watched:
                        if deployment_update[key] != deployment.get(key, None):
                            deployment[key] = deployment_update[key]
                            changed = True

                for removed_deployment in removed:
                    status.pop(removed_deployment)

                if changed:
                    table = tables.ECSDeploymentStatusTable(show_header=False, title=RenderableDatetime.now())
                    for deployment in reversed(sorted(status.values(), key=lambda x: x["createdAt"])):
                        table.add_entry(deployment)
                    print(table)

                # Group current deployments by AWS service name so we can pick
                # each service's latest deployment as the rollout target.
                deployments_by_name: dict[str, list[dict[str, Any]]] = defaultdict(list)
                for deployment in status.values():
                    deployments_by_name[deployment["service"]].append(deployment)

                for svc_key in list(services_pending):
                    deps = deployments_by_name.get(self.terraform.services[svc_key].service_name, [])
                    if not deps:
                        continue

                    latest = max(deps, key=lambda d: d["createdAt"])
                    kw = service_kwargs.get(svc_key, {})

                    # Gate: forceNewDeployment requires a deployment id that wasn't there before.
                    if kw.get("forceNewDeployment") and latest["id"] in pre_existing_deployment_ids:
                        continue
                    # Gate: a requested desiredCount must be reflected on the deployment.
                    if "desiredCount" in kw and latest["desiredCount"] != kw["desiredCount"]:
                        continue

                    if (
                        latest["rolloutState"] == "COMPLETED"
                        and latest["runningCount"] == latest["desiredCount"]
                    ):
                        services_pending.discard(svc_key)

                if not services_pending:
                    logging.info('Deployment completed successfully')
                    return True

                time.sleep(self.refresh)

        except KeyboardInterrupt:
            logging.info('Skipping "watch_deployments"')
            return False

    def update_services_and_wait(
        self,
        service_kwargs: dict[str, dict[str, Any]],
    ) -> bool:
        """
        Apply per-service `update_service` kwargs, poll for the resulting deployments
        to complete, and log a history entry on success.
        """
        services = list(service_kwargs.keys()) or config.DEFAULT_SERVICES

        logging.info(f"Updating service(s) {services} on environment {self.environment}")

        # Snapshot before update_service: confirmation table + forceNewDeployment gate.
        pre_existing = self.describe_service_deployments(services)
        pre_existing_ids = {d["id"] for d in pre_existing}

        if self.confirm or self.debug:
            print(tables.ECSDeploymentStatusTable(pre_existing))

        if not self.get_confirmation("Update service(s)?"):
            return False

        for service, kwargs in service_kwargs.items():
            self.update_service(service=service, **kwargs)

        if self.watch_deployments(
            services,
            service_kwargs=service_kwargs,
            pre_existing_deployment_ids=pre_existing_ids,
        ):
            self.log(DeployHistoryType.deployment)
            return True

        return False

    def execute_command(self, command: str, service: str = "web", interactive: bool = False):
        return aws.execute_command(
            self.ecs_client,
            command=command,
            cluster=self.terraform.cluster_id,
            service=self.terraform.services[service].service_name,
            interactive=interactive,
        )

    def wait_for_task_completion(
        self,
        task_arn: str,
        service: str,
        timeout_seconds: float,
        tail_logs: bool = True,
    ) -> dict[str, Any]:
        """
        Poll an ECS task until it stops (stopCode set) or `timeout_seconds` elapses.

        Returns the most recent task description. While the task is running, log
        events from its CloudWatch stream are tailed on a background thread.
        """
        task = self.describe_tasks(task_arns=[task_arn])["tasks"][0]

        log_thread: threading.Thread | None = None
        log_stop_event = threading.Event()
        started, stopped = None, None

        try:
            start = time.perf_counter()
            while time.perf_counter() - start < timeout_seconds:
                task = self.describe_tasks(task_arns=[task_arn])["tasks"][0]

                if not started:
                    started = task.get("startedAt")
                    if started:
                        logging.info(f"Task started at {started}")
                        if tail_logs:
                            log_thread = self.start_task_log_tail(task_arn, service, log_stop_event)

                if not stopped:
                    stopped = task.get("stoppedAt")
                    if stopped:
                        logging.info(f"Task stopped at {stopped}")

                if task.get("stopCode"):
                    break

                time.sleep(self.refresh)
        finally:
            log_stop_event.set()
            if log_thread is not None:
                log_thread.join(timeout=5)

        return task

    def start_task_log_tail(
        self,
        task_arn: str,
        service: str,
        stop_event: threading.Event,
    ) -> threading.Thread | None:
        log_group_arn = self.terraform.services[service].log_group_arn
        if not log_group_arn:
            logging.warning(f"No log group configured for service '{service}'; skipping log tail")
            return None

        task_id = task_arn.rsplit("/", 1)[-1]
        container_name = self.terraform.services[service].service_name
        stream_name = f"ecs/{container_name}/{task_id}"

        event_stream = aws.cloudwatch_start_live_tail(
            self.logs_client,
            log_group_arn,
            log_stream_names=[stream_name]
        )
        if event_stream is None:
            return None

        logging.info(f'CloudWatch logs: "{aws.cloudwatch_get_log_url(log_group_arn)}"')

        def _close_on_stop():
            stop_event.wait()
            try:
                event_stream.close()
            except Exception:
                pass

        def _consume():
            try:
                aws.cloudwatch_print_live_tail_events(event_stream, cancelled=stop_event.is_set)
            finally:
                stop_event.set()  # wake the watcher if the stream ended on its own

        threading.Thread(target=_close_on_stop, daemon=True).start()
        thread = threading.Thread(target=_consume, daemon=True)
        thread.start()
        return thread

    def run_task(self, service: str, command: str) -> dict | None:
        deployments = self.describe_service_deployments(services=[service])

        # Get the network configuration from the currently-running deployment
        primary_deployment = None
        for deployment in deployments:
            if deployment["status"] == "PRIMARY":
                primary_deployment = deployment

        if primary_deployment is None:
            logging.error("No Primary Deployment Found. Exiting.")
            return

        return self.ecs_client.run_task(
            taskDefinition=primary_deployment["taskDefinition"],
            networkConfiguration=primary_deployment["networkConfiguration"],
            cluster=self.terraform.cluster_id,
            capacityProviderStrategy=[{"capacityProvider": "FARGATE"}],
            overrides={
                "containerOverrides": [
                    {
                        "name": self.terraform.services[service].service_name,
                        "command": command.split(" "),
                    },
                ],
            },
        )

    def _upload_history(self):
        # `default=str` coerces non-JSON values (Paths, CompletedProcess, etc.)
        # captured from caller locals into their string repr instead of failing.
        serialized_data = json.dumps(self.history, default=str)

        try:
            self.s3_client.put_object(Body=serialized_data, Bucket=self.s3_bucket_name, Key=str(config.HISTORY_PATH))
            logging.debug(f'History uploaded to "{self.s3_bucket_name}" / "{config.HISTORY_PATH}"')
        except Exception as e:
            logging.error(f"Failed to upload history to bucket {self.s3_bucket_name}: {e}")

    def _download_history(self) -> dict:
        # If history doesn't exist, upload it
        try:
            self.s3_client.head_object(Bucket=self.s3_bucket_name, Key=str(config.HISTORY_PATH))
        except ClientError:
            self.history = {}
            self._upload_history()

        # Download the file from S3
        try:
            response = self.s3_client.get_object(Bucket=self.s3_bucket_name, Key=str(config.HISTORY_PATH))

            # Deserialize the JSON string back into a Python dictionary
            serialized_data = response["Body"].read().decode("utf-8")
            history = json.loads(serialized_data)

        except Exception as e:
            logging.error(f"Failed to download history from bucket {self.s3_bucket_name}: {e}")
            history = {}

        logging.debug(f'Downloaded history from "{self.s3_bucket_name}" / "{config.HISTORY_PATH}"')

        for key in os.listdir(config.TERRAFORM_PATH.joinpath("deployments")):
            if key not in history:
                history[key] = []

        return history

    def _append_to_history(self, new_state):
        if self.environment in self.history:
            # If `self.history[env]` is currently a dict, convert it to an array
            if isinstance(self.history[self.environment], dict):
                self.history[self.environment] = [self.history[self.environment]]

            self.history[self.environment].append(new_state)

        else:
            self.history[self.environment] = [new_state]

    def promote_image(self, target_environment: str):
        target_terraform = self.get_terraform_output(target_environment)
        return aws.copy_ecr_image(
            self.ecr_client,
            self.terraform.ecr_repository_name,
            target_terraform.ecr_repository_name,
        )

    def log(self, deploy_type: DeployHistoryType, **kwargs):

        # Audit context: caller's frame locals + active Click invocation params.
        # Serialization is lenient (`default=str` in `_upload_history`).
        current_frame = inspect.currentframe()
        caller_frame = current_frame.f_back if current_frame else None
        caller_locals = {
            k: v for k, v in (caller_frame.f_locals if caller_frame else {}).items()
            if k not in ("self", "ctx")
        }
        click_ctx = click.get_current_context(silent=True)

        new_state = {
            **kwargs,
            "deployment_name": self.environment,
            "deploy_type": deploy_type.name,
            "datetime": datetime.now().isoformat(),
            "iam_user": self.sts_caller_identity,
            "git": self.git.get_info(),
            "caller": caller_frame.f_code.co_name if caller_frame else None,
            "cli_command": click_ctx.info_name if click_ctx else None,
            "ctx_params": dict(click_ctx.params) if click_ctx else None,
            "locals": caller_locals,
        }

        self._append_to_history(new_state)
        self._upload_history()

        logging.debug(f'Logged history entry "{deploy_type.value}"')
