from __future__ import annotations

from .retrieval_budget import RetrievalBudget
from .retrieval_models import RetrievalEvidencePack
from .schemas import CodeSnippet
from .services.context_compression import maybe_compress_context
from .types_defs import ResultRow, SemanticSearchResult


class ContextCompiler:
    def __init__(self, budget: RetrievalBudget) -> None:
        self.budget = budget

    def compile(self, evidence: RetrievalEvidencePack) -> str:
        sections = [
            f"User question:\n{evidence.question}",
            self._summary_section(evidence),
        ]

        if evidence.graph_rows:
            sections.append(self._graph_section(evidence.graph_rows))
        if evidence.metadata:
            sections.append(self._metadata_section(evidence.metadata))
        if evidence.semantic_results:
            sections.append(self._semantic_section(evidence.semantic_results))
        if evidence.snippets:
            sections.append(self._snippet_section(evidence.snippets))
        if evidence.file_reads:
            sections.append(self._file_read_section(evidence.file_reads))

        sections.append(self._gaps_section(evidence))

        compiled = "\n\n".join(section for section in sections if section.strip())
        trimmed = self._fit_to_budget(compiled)
        return maybe_compress_context(trimmed)

    def _summary_section(self, evidence: RetrievalEvidencePack) -> str:
        lines = [
            "Evidence pack:",
            f"- intent: {evidence.intent}",
            f"- route: {evidence.route_explanation}",
            f"- summary: {evidence.retrieval_summary or evidence.graph_summary or 'Focused retrieval completed.'}",
            f"- confidence: {evidence.confidence}",
        ]
        if evidence.graph_query_used:
            lines.append(f"- graph query used: {evidence.graph_query_used}")
        return "\n".join(lines)

    def _graph_section(self, rows: list[ResultRow]) -> str:
        lines = ["Graph evidence:"]
        for row in rows[: self.budget.max_graph_rows]:
            parts = [f"{key}={value}" for key, value in row.items()]
            lines.append(f"- {'; '.join(parts)}")
        return "\n".join(lines)

    def _semantic_section(self, rows: list[SemanticSearchResult]) -> str:
        lines = ["Semantic candidates:"]
        for row in rows[: self.budget.max_semantic_candidates]:
            lines.append(
                f"- {row['qualified_name']} (type={row['type']}, score={row['score']})"
            )
        return "\n".join(lines)

    def _metadata_section(self, metadata: dict[str, str | int | bool]) -> str:
        lines = ["Project metadata:"]
        for key, value in metadata.items():
            lines.append(f"- {key}: {value}")
        return "\n".join(lines)

    def _snippet_section(self, snippets: list[CodeSnippet]) -> str:
        sections = ["Code snippets:"]
        for snippet in snippets[: self.budget.max_snippets]:
            body = snippet.source_code.strip()
            if len(body) > 2400:
                body = body[:2400].rstrip() + "\n# Truncated by context compiler."
            sections.append(
                "\n".join(
                    [
                        f"### {snippet.qualified_name} ({snippet.file_path}:{snippet.line_start}-{snippet.line_end})",
                        "```text",
                        body,
                        "```",
                    ]
                )
            )
        return "\n\n".join(sections)

    def _file_read_section(self, file_reads: list[tuple[str, str]]) -> str:
        lines = ["Fallback file reads:"]
        for file_path, content in file_reads:
            body = content.strip()
            if len(body) > 1600:
                body = body[:1600].rstrip() + "\n[Truncated fallback file read.]"
            lines.append(f"### {file_path}\n```text\n{body}\n```")
        return "\n\n".join(lines)

    def _gaps_section(self, evidence: RetrievalEvidencePack) -> str:
        if evidence.gaps:
            return "Gaps:\n" + "\n".join(f"- {gap}" for gap in evidence.gaps)
        return "Gaps:\n- None identified from the bounded retrieval pass."

    def _fit_to_budget(self, compiled: str) -> str:
        if len(compiled) <= self.budget.evidence_char_target:
            return compiled

        trimmed = compiled[: self.budget.evidence_char_target].rstrip()
        return trimmed + "\n\n[Context compiler truncated low-priority evidence to stay within budget.]"
