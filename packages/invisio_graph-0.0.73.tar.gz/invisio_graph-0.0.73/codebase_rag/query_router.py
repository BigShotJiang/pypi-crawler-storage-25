from __future__ import annotations

import re

from .retrieval_models import RetrievalIntent, RetrievalRoute

_EXPLICIT_SYMBOL_PATTERN = re.compile(r"[`'\"](?P<symbol>[A-Za-z_][A-Za-z0-9_:.]*)[`'\"]")
_CAMEL_OR_QUALIFIED_PATTERN = re.compile(
    r"\b(?P<symbol>[A-Za-z_][A-Za-z0-9_]*[A-Z][A-Za-z0-9_]*|[A-Za-z_][A-Za-z0-9_]*\.[A-Za-z0-9_.]+)\b"
)
_EDIT_TERMS = (
    "fix",
    "change",
    "modify",
    "edit",
    "update",
    "implement",
    "add",
    "create",
    "patch",
    "refactor",
    "rename",
)
_STRUCTURAL_TERMS = (
    "neighbor",
    "neighbour",
    "caller",
    "callee",
    "call graph",
    "depends",
    "dependency",
    "inherits",
    "implements",
    "connected",
)
_FLOW_TERMS = ("flow", "trace", "path", "chain", "reach", "route to")
_ENTRYPOINT_TERMS = ("entry point", "startup", "bootstrap", "boot", "init", "main")
_OVERVIEW_TERMS = (
    "architecture",
    "overview",
    "structure",
    "high level",
    "big picture",
    "codebase",
    "repository",
    "repo",
    "project",
    "root directory",
    "root folder",
    "top level",
)
_LOOKUP_TERMS = ("show code", "show me", "source", "implementation", "snippet", "code for")


def extract_anchor_symbols(question: str) -> list[str]:
    anchors: list[str] = []
    seen: set[str] = set()
    for pattern in (_EXPLICIT_SYMBOL_PATTERN, _CAMEL_OR_QUALIFIED_PATTERN):
        for match in pattern.finditer(question):
            symbol = match.group("symbol")
            if len(symbol) < 3:
                continue
            if symbol.lower() in seen:
                continue
            seen.add(symbol.lower())
            anchors.append(symbol)
    return anchors[:5]


class QueryRouter:
    def route(self, question: str) -> RetrievalRoute:
        lowered = question.lower()
        anchors = extract_anchor_symbols(question)

        if any(term in lowered for term in _EDIT_TERMS):
            return RetrievalRoute(
                intent=RetrievalIntent.EDIT_TASK,
                anchor_symbols=anchors,
                explanation="Detected an edit-oriented request; gather focused evidence before enabling mutation tools.",
                allow_file_reads=True,
            )
        if any(term in lowered for term in _ENTRYPOINT_TERMS):
            return RetrievalRoute(
                intent=RetrievalIntent.ENTRYPOINT_TRACE,
                anchor_symbols=anchors,
                explanation="Detected startup or entrypoint language; trace likely bootstrap and route nodes first.",
            )
        if any(term in lowered for term in _OVERVIEW_TERMS):
            return RetrievalRoute(
                intent=RetrievalIntent.ARCHITECTURE_OVERVIEW,
                anchor_symbols=anchors,
                explanation="Detected an architecture-level question; prefer summaries and broad graph context over raw files.",
            )
        if any(term in lowered for term in _FLOW_TERMS):
            return RetrievalRoute(
                intent=RetrievalIntent.FLOW_TRACE,
                anchor_symbols=anchors,
                explanation="Detected a flow-tracing request; follow call relationships before reading files.",
            )
        if any(term in lowered for term in _STRUCTURAL_TERMS):
            return RetrievalRoute(
                intent=RetrievalIntent.STRUCTURAL_GRAPH,
                anchor_symbols=anchors,
                explanation="Detected a structural graph query; use project-scoped graph relationships first.",
            )
        if anchors and any(term in lowered for term in _LOOKUP_TERMS):
            return RetrievalRoute(
                intent=RetrievalIntent.SYMBOL_LOOKUP,
                anchor_symbols=anchors,
                explanation="Detected a direct symbol lookup; retrieve a precise snippet before anything broader.",
            )
        if anchors and ("what does" in lowered or "how does" in lowered):
            return RetrievalRoute(
                intent=RetrievalIntent.SYMBOL_LOOKUP,
                anchor_symbols=anchors,
                explanation="Detected a symbol-focused behavior question; resolve the symbol before expanding context.",
            )
        return RetrievalRoute(
            intent=RetrievalIntent.INTENT_SEARCH,
            anchor_symbols=anchors,
            explanation="Defaulted to intent search; semantic retrieval should find the smallest useful evidence set.",
        )
