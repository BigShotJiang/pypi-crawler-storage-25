from __future__ import annotations

from .context_compiler import ContextCompiler
from .retrieval_budget import RetrievalBudget
from .retrieval_investigator import RetrievalInvestigator


class RetrievalBrain:
    def __init__(self, project_root: str, ingestor) -> None:
        self.budget = RetrievalBudget.from_settings()
        self.investigator = RetrievalInvestigator(
            project_root=project_root,
            ingestor=ingestor,
            budget=self.budget,
        )
        self.compiler = ContextCompiler(self.budget)

    async def build_prompt(self, question: str) -> str:
        evidence = await self.investigator.investigate(question)
        return self.compiler.compile(evidence)

