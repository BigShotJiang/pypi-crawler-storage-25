from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class CommunityMetadata:
    community_id: str
    community_summary: str
    bridge_score: float = 0.0
    importance_score: float = 0.0
    layer: str | None = None


class CommunityIndex:
    def __init__(self, enabled: bool = False) -> None:
        self.enabled = enabled

    def find_relevant_communities(self, _question: str) -> list[CommunityMetadata]:
        return []

