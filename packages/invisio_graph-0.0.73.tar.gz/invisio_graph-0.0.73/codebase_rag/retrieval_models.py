from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum

from .schemas import CodeSnippet
from .types_defs import ResultRow, SemanticSearchResult


class RetrievalIntent(StrEnum):
    SYMBOL_LOOKUP = "symbol_lookup"
    STRUCTURAL_GRAPH = "structural_graph"
    INTENT_SEARCH = "intent_search"
    ENTRYPOINT_TRACE = "entrypoint_trace"
    FLOW_TRACE = "flow_trace"
    ARCHITECTURE_OVERVIEW = "architecture_overview"
    EDIT_TASK = "edit_task"


@dataclass(slots=True)
class RetrievalRoute:
    intent: RetrievalIntent
    anchor_symbols: list[str] = field(default_factory=list)
    explanation: str = ""
    allow_file_reads: bool = False


@dataclass(slots=True)
class RetrievalEvidencePack:
    question: str
    intent: RetrievalIntent
    route_explanation: str
    graph_query_used: str | None = None
    graph_summary: str = ""
    graph_rows: list[ResultRow] = field(default_factory=list)
    semantic_results: list[SemanticSearchResult] = field(default_factory=list)
    snippets: list[CodeSnippet] = field(default_factory=list)
    file_reads: list[tuple[str, str]] = field(default_factory=list)
    retrieval_summary: str = ""
    confidence: str = "medium"
    gaps: list[str] = field(default_factory=list)
    metadata: dict[str, str | int | bool] = field(default_factory=dict)

