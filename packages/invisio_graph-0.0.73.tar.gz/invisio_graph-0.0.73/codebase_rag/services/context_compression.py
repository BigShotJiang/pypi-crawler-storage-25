from __future__ import annotations

from functools import lru_cache

from loguru import logger

from ..config import settings


@lru_cache(maxsize=1)
def _get_prompt_compressor() -> object | None:
    if not settings.RAG_LLM_LINGUA_ENABLED:
        return None
    try:
        from llmlingua import PromptCompressor

        return PromptCompressor(
            model_name="microsoft/llmlingua-2-bert-base-multilingual-cased-meetingbank",
            use_llmlingua2=True,
            device_map="cpu",
        )
    except Exception as e:
        logger.warning("LLMLingua is enabled but unavailable: {}", e)
        return None


def maybe_compress_context(compiled_context: str) -> str:
    threshold = max(400, int(settings.RAG_LLM_LINGUA_THRESHOLD_TOKENS) * 4)
    if len(compiled_context) < threshold:
        return compiled_context

    compressor = _get_prompt_compressor()
    if compressor is None:
        return compiled_context

    try:
        result = compressor.compress_prompt(
            [compiled_context],
            target_token=max(200, int(settings.RAG_EVIDENCE_TOKEN_TARGET)),
        )
        compressed = result.get("compressed_prompt")
        return compressed if isinstance(compressed, str) and compressed.strip() else compiled_context
    except Exception as e:
        logger.warning("LLMLingua compression failed, using uncompressed context: {}", e)
        return compiled_context

