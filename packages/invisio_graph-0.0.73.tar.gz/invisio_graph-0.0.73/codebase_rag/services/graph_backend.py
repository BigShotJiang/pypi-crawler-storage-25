from __future__ import annotations

from ..config import settings
from . import GraphStoreProtocol
from .graph_service import MemgraphIngestor, Neo4jIngestor


def connect_graph_store(batch_size: int | None = None) -> GraphStoreProtocol:
    effective_batch_size = settings.resolve_batch_size(batch_size)
    backend = settings.graph_backend

    if backend == "neo4j":
        return Neo4jIngestor(
            uri=settings.NEO4J_URI,
            database=settings.NEO4J_DATABASE,
            username=settings.NEO4J_USERNAME,
            password=settings.NEO4J_PASSWORD,
            batch_size=effective_batch_size,
        )

    return MemgraphIngestor(
        host=settings.MEMGRAPH_HOST,
        port=settings.MEMGRAPH_PORT,
        username=settings.MEMGRAPH_USERNAME,
        password=settings.MEMGRAPH_PASSWORD,
        batch_size=effective_batch_size,
    )
