from __future__ import annotations

from dataclasses import dataclass

from .config import settings


@dataclass(frozen=True, slots=True)
class RetrievalBudget:
    max_graph_rows: int
    max_semantic_candidates: int
    max_snippets: int
    max_snippet_lines: int
    evidence_token_target: int

    @property
    def evidence_char_target(self) -> int:
        return max(1200, self.evidence_token_target * 4)

    @classmethod
    def from_settings(cls) -> RetrievalBudget:
        return cls(
            max_graph_rows=max(1, int(settings.RAG_MAX_GRAPH_ROWS)),
            max_semantic_candidates=max(1, int(settings.RAG_MAX_SEMANTIC_CANDIDATES)),
            max_snippets=max(1, int(settings.RAG_MAX_SNIPPETS)),
            max_snippet_lines=max(1, int(settings.RAG_MAX_SNIPPET_LINES)),
            evidence_token_target=max(300, int(settings.RAG_EVIDENCE_TOKEN_TARGET)),
        )

