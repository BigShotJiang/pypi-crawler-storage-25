from typing import Any

from loguru import logger

from . import logs as ls
from .config import get_effective_qdrant_collection_name, settings
from .constants import PAYLOAD_NODE_ID, PAYLOAD_QUALIFIED_NAME
from .utils.dependencies import has_qdrant_client

if has_qdrant_client():
    from qdrant_client import QdrantClient
    from qdrant_client.models import Distance, PointStruct, VectorParams

    _CLIENT: QdrantClient | None = None

    def _build_qdrant_client() -> QdrantClient:
        qdrant_url = (settings.QDRANT_URL or "").strip()
        if qdrant_url:
            qdrant_api_key = (settings.QDRANT_API_KEY or "").strip() or None
            return QdrantClient(url=qdrant_url, api_key=qdrant_api_key)
        return QdrantClient(path=settings.QDRANT_DB_PATH)

    def get_qdrant_client() -> QdrantClient:
        global _CLIENT
        if _CLIENT is None:
            _CLIENT = _build_qdrant_client()
            collection_name = get_effective_qdrant_collection_name()
            if not _CLIENT.collection_exists(collection_name):
                _CLIENT.create_collection(
                    collection_name=collection_name,
                    vectors_config=VectorParams(
                        size=settings.QDRANT_VECTOR_DIM, distance=Distance.COSINE
                    ),
                )
        return _CLIENT

    def store_embedding(
        node_id: int,
        embedding: list[float],
        qualified_name: str,
        extra_payload: dict[str, Any] | None = None,
    ) -> None:
        try:
            client = get_qdrant_client()
            collection_name = get_effective_qdrant_collection_name()
            payload: dict[str, Any] = {
                PAYLOAD_NODE_ID: node_id,
                PAYLOAD_QUALIFIED_NAME: qualified_name,
            }
            if extra_payload:
                payload.update(extra_payload)
            client.upsert(
                collection_name=collection_name,
                points=[
                    PointStruct(
                        id=node_id,
                        vector=embedding,
                        payload=payload,
                    )
                ],
            )
        except Exception as e:
            logger.warning(
                ls.EMBEDDING_STORE_FAILED.format(name=qualified_name, error=e)
            )

    def store_embeddings(
        rows: list[tuple[int, list[float], str, dict[str, Any] | None]],
    ) -> None:
        if not rows:
            return
        try:
            client = get_qdrant_client()
            collection_name = get_effective_qdrant_collection_name()
            points = []
            for row in rows:
                node_id, embedding, qualified_name = row[0], row[1], row[2]
                extra_payload = row[3] if len(row) > 3 else None
                payload: dict[str, Any] = {
                    PAYLOAD_NODE_ID: node_id,
                    PAYLOAD_QUALIFIED_NAME: qualified_name,
                }
                if extra_payload:
                    payload.update(extra_payload)
                points.append(
                    PointStruct(
                        id=node_id,
                        vector=embedding,
                        payload=payload,
                    )
                )
            client.upsert(
                collection_name=collection_name,
                points=points,
            )
        except Exception as e:
            logger.warning(ls.EMBEDDING_STORE_FAILED.format(name="batch", error=e))

    def search_embeddings(
        query_embedding: list[float], top_k: int | None = None
    ) -> list[tuple[int, float, dict[str, Any]]]:
        effective_top_k = top_k if top_k is not None else settings.QDRANT_TOP_K
        try:
            client = get_qdrant_client()
            collection_name = get_effective_qdrant_collection_name()
            result = client.query_points(
                collection_name=collection_name,
                query=query_embedding,
                limit=effective_top_k,
            )
            return [
                (
                    hit.payload[PAYLOAD_NODE_ID],
                    hit.score,
                    dict(hit.payload) if hit.payload is not None else {},
                )
                for hit in result.points
                if hit.payload is not None
            ]
        except Exception as e:
            logger.warning(ls.EMBEDDING_SEARCH_FAILED.format(error=e))
            return []

    def get_collection_point_count() -> int:
        """Get the number of points (embeddings) in the current collection."""
        try:
            client = get_qdrant_client()
            collection_name = get_effective_qdrant_collection_name()
            if not client.collection_exists(collection_name):
                return 0
            result = client.count(collection_name=collection_name)
            return result.count
        except Exception as e:
            logger.warning(f"Failed to get collection point count: {e}")
            return 0

    def wipe_semantic_database() -> None:
        """Delete all collections from the configured Qdrant instance.

        This will remove every collection found on the Qdrant host (or local
        instance) referenced by the configured client.
        """
        try:
            client = get_qdrant_client()
            resp = client.get_collections()
            collections = getattr(resp, "collections", []) or []
            for col in collections:
                # collection object may expose name as `name`
                name = getattr(col, "name", None) or getattr(col, "collection_name", None)
                if not name:
                    continue
                logger.info(f"Deleting Qdrant collection: {name}")
                try:
                    client.delete_collection(collection_name=name)
                except TypeError:
                    # older/newer qdrant client versions may accept a single positional arg
                    client.delete_collection(name)
        except Exception as e:
            logger.warning(f"Failed wiping Qdrant collections: {e}")

else:

    def store_embedding(
        node_id: int,
        embedding: list[float],
        qualified_name: str,
        extra_payload: dict[str, Any] | None = None,
    ) -> None:
        pass

    def store_embeddings(
        rows: list[tuple[int, list[float], str, dict[str, Any] | None]],
    ) -> None:
        pass

    def search_embeddings(
        query_embedding: list[float], top_k: int | None = None
    ) -> list[tuple[int, float, dict[str, Any]]]:
        return []

    def get_collection_point_count() -> int:
        return 0

    def wipe_semantic_database() -> None:
        logger.warning("Qdrant client not available; cannot wipe semantic database.")
