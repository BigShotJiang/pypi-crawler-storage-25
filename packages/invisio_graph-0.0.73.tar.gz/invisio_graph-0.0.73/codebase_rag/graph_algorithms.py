from __future__ import annotations

from .constants import KEY_PROJECT_NAME
from .services import QueryProtocol
from .types_defs import ResultRow


def _fetch_all(
    ingestor: QueryProtocol, query: str, params: dict[str, str | int]
) -> list[ResultRow]:
    return ingestor.fetch_all(query, params)


def find_symbol_candidates(
    ingestor: QueryProtocol,
    project_name: str,
    symbol_name: str,
    *,
    limit: int = 5,
) -> list[ResultRow]:
    query = """
MATCH (n)
WHERE n.project_id = $project_name
  AND n.qualified_name IS NOT NULL
  AND (
    n.qualified_name = $exact
    OR n.qualified_name ENDS WITH $suffix
    OR toLower(n.name) = toLower($name)
  )
RETURN n.name AS name,
       n.qualified_name AS qualified_name,
       labels(n) AS type
ORDER BY
  CASE
    WHEN n.qualified_name = $exact THEN 0
    WHEN n.qualified_name ENDS WITH $suffix THEN 1
    ELSE 2
  END,
  n.qualified_name
LIMIT $limit
"""
    return _fetch_all(
        ingestor,
        query,
        {
            KEY_PROJECT_NAME: project_name,
            "exact": symbol_name,
            "suffix": f".{symbol_name}",
            "name": symbol_name,
            "limit": limit,
        },
    )


def find_symbol_neighbors(
    ingestor: QueryProtocol,
    project_name: str,
    symbol_name: str,
    *,
    limit: int = 10,
) -> tuple[str, list[ResultRow]]:
    query = """
MATCH (target)
WHERE target.project_id = $project_name
  AND target.qualified_name IS NOT NULL
  AND (
    target.qualified_name = $exact
    OR target.qualified_name ENDS WITH $suffix
    OR toLower(target.name) = toLower($name)
  )
CALL {
  WITH target
  MATCH (caller)-[:CALLS]->(target)
  WHERE caller.project_id = $project_name
  RETURN 'caller' AS relation,
         caller.name AS name,
         caller.qualified_name AS qualified_name,
         labels(caller) AS type
  UNION
  WITH target
  MATCH (target)-[:CALLS]->(callee)
  WHERE callee.project_id = $project_name
  RETURN 'callee' AS relation,
         callee.name AS name,
         callee.qualified_name AS qualified_name,
         labels(callee) AS type
}
RETURN relation, name, qualified_name, type
LIMIT $limit
"""
    return query, _fetch_all(
        ingestor,
        query,
        {
            KEY_PROJECT_NAME: project_name,
            "exact": symbol_name,
            "suffix": f".{symbol_name}",
            "name": symbol_name,
            "limit": limit,
        },
    )


def find_architecture_overview(
    ingestor: QueryProtocol,
    project_name: str,
    *,
    limit: int = 12,
) -> tuple[str, list[ResultRow]]:
    query = """
MATCH (n)
WHERE n.project_id = $project_name
RETURN labels(n)[0] AS type, count(*) AS count
ORDER BY count DESC, type
LIMIT $limit
"""
    return query, _fetch_all(
        ingestor,
        query,
        {KEY_PROJECT_NAME: project_name, "limit": limit},
    )


def find_entrypoint_candidates(
    ingestor: QueryProtocol,
    project_name: str,
    *,
    limit: int = 10,
) -> tuple[str, list[ResultRow]]:
    query = """
MATCH (n)
WHERE n.project_id = $project_name
  AND (
    (n.name IS NOT NULL AND toLower(n.name) =~ '.*(main|start|init|boot|server|app|route).*')
    OR (n.qualified_name IS NOT NULL AND toLower(n.qualified_name) =~ '.*(main|start|init|boot|server|app|route).*')
    OR (n.path IS NOT NULL AND toLower(n.path) =~ '.*(main|index|server|app|route).*')
  )
RETURN n.name AS name,
       n.qualified_name AS qualified_name,
       n.path AS path,
       labels(n) AS type
ORDER BY n.qualified_name
LIMIT $limit
"""
    return query, _fetch_all(
        ingestor,
        query,
        {KEY_PROJECT_NAME: project_name, "limit": limit},
    )

