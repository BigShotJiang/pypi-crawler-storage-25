from __future__ import annotations

import json
import re

from loguru import logger
from pydantic_ai import Tool

from .. import constants as cs
from .. import exceptions as ex
from .. import logs as ls
from ..config import settings
from ..cypher_queries import (
    CYPHER_GET_FUNCTION_SOURCE_LOCATION,
    build_nodes_by_ids_query,
)
from ..types_defs import SemanticSearchResult
from ..utils.dependencies import has_semantic_dependencies
from . import tool_descriptions as td

RAW_PAYLOAD_DUPLICATE_KEYS = frozenset({"node_id", "qualified_name", "name", "type"})


def _tokenize_query(text: str) -> set[str]:
    normalized = text.lower().replace("_", " ").replace(".", " ")
    return {
        token
        for token in re.findall(r"[a-zA-Z0-9]+", normalized)
        if len(token) > 1
    }


def _rerank_semantic_results(
    query: str, results: list[SemanticSearchResult]
) -> list[SemanticSearchResult]:
    query_tokens = _tokenize_query(query)
    desired_type: str | None = None
    for label in ("class", "method", "function", "module"):
        if label in query.lower():
            desired_type = label
            break

    scored_results: list[tuple[float, int, SemanticSearchResult]] = []
    for index, result in enumerate(results):
        name = str(result.get("name", "")).lower()
        qualified_name = str(result.get("qualified_name", "")).lower()
        payload = result.get("payload", {})
        path = str(payload.get("path", "")).lower()
        result_type = str(result.get("type", "")).lower()
        haystack_tokens = _tokenize_query(" ".join((name, qualified_name, path)))
        overlap = len(query_tokens & haystack_tokens)
        score = float(result["score"])
        if name and name in query.lower():
            score += 0.18
        if overlap:
            score += min(0.2, overlap * 0.05)
        if desired_type and desired_type in result_type:
            score += 0.05
        if path and any(token in path for token in query_tokens):
            score += 0.03
        scored_results.append((score, index, result))

    scored_results.sort(key=lambda item: (-item[0], item[1]))
    return [result for _score, _index, result in scored_results]


def _sanitize_raw_semantic_results(
    results: list[SemanticSearchResult],
) -> list[SemanticSearchResult]:
    sanitized_results: list[SemanticSearchResult] = []

    for result in results:
        raw_payload = result.get("payload", {})
        payload = {
            key: value
            for key, value in raw_payload.items()
            if key not in RAW_PAYLOAD_DUPLICATE_KEYS
        }
        sanitized_results.append(
            SemanticSearchResult(
                node_id=result["node_id"],
                qualified_name=result["qualified_name"],
                name=result["name"],
                type=result["type"],
                score=result["score"],
                payload=payload,
            )
        )

    return sanitized_results


def semantic_code_search(query: str, top_k: int = 5) -> list[SemanticSearchResult]:
    if not has_semantic_dependencies():
        logger.warning(ex.SEMANTIC_EXTRA)
        return []

    try:
        from ..embedder import embed_code
        from ..services.graph_backend import connect_graph_store
        from ..vector_store import search_embeddings

        query_embedding = embed_code(query)

        candidate_count = max(top_k, settings.RAG_SEMANTIC_CANDIDATES)
        search_results = search_embeddings(query_embedding, top_k=candidate_count)

        if not search_results:
            logger.info(ls.SEMANTIC_NO_MATCH.format(query=query))
            return []

        node_ids = [node_id for node_id, _score, _payload in search_results]

        with connect_graph_store(cs.SEMANTIC_BATCH_SIZE) as ingestor:
            cypher_query = build_nodes_by_ids_query(node_ids)
            params = {f"id_{i}": node_id for i, node_id in enumerate(node_ids)}
            results = ingestor.fetch_all(cypher_query, params)

            results_map = {res["node_id"]: res for res in results}

            formatted_results: list[SemanticSearchResult] = []
            for node_id, score, payload in search_results:
                if node_id in results_map:
                    result = results_map[node_id]
                    result_type = result["type"]
                    type_str = (
                        result_type[0]
                        if isinstance(result_type, list) and result_type
                        else cs.SEMANTIC_TYPE_UNKNOWN
                    )
                    name = str(payload.get("name") or result.get("name", ""))
                    formatted_results.append(
                        SemanticSearchResult(
                            node_id=node_id,
                            qualified_name=str(result["qualified_name"]),
                            name=name,
                            type=type_str,
                            score=round(score, 3),
                            payload=payload,
                        )
                    )

            reranked_results = _rerank_semantic_results(query, formatted_results)
            final_limit = max(1, min(top_k, settings.RAG_RERANK_TOP_N))
            final_results = reranked_results[:final_limit]

            logger.info(
                ls.SEMANTIC_FOUND.format(count=len(final_results), query=query)
            )
            return final_results

    except Exception as e:
        logger.error(ls.SEMANTIC_FAILED.format(query=query, error=e))
        return []


def get_function_source_code(node_id: int) -> str | None:
    try:
        from ..services.graph_backend import connect_graph_store
        from ..utils.source_extraction import (
            extract_source_lines,
            validate_source_location,
        )

        with connect_graph_store(cs.SEMANTIC_BATCH_SIZE) as ingestor:
            results = ingestor.fetch_all(
                CYPHER_GET_FUNCTION_SOURCE_LOCATION, {"node_id": node_id}
            )

            if not results:
                logger.warning(ls.SEMANTIC_NODE_NOT_FOUND.format(id=node_id))
                return None

            result = results[0]
            file_path = result.get("path")
            start_line = result.get("start_line")
            end_line = result.get("end_line")

            is_valid, file_path_obj = validate_source_location(
                file_path, start_line, end_line
            )
            if not is_valid or file_path_obj is None:
                logger.warning(ls.SEMANTIC_INVALID_LOCATION.format(id=node_id))
                return None

            return extract_source_lines(file_path_obj, start_line, end_line)

    except Exception as e:
        logger.error(ls.SEMANTIC_SOURCE_FAILED.format(id=node_id, error=e))
        return None


def create_semantic_search_tool() -> Tool:
    async def semantic_search_functions(
        query: str, top_k: int = 5, raw: bool = False
    ) -> str:
        logger.info(ls.SEMANTIC_TOOL_SEARCH.format(query=query))

        results = semantic_code_search(query, top_k)

        if not results:
            return cs.MSG_SEMANTIC_NO_RESULTS.format(query=query)

        if raw:
            sanitized_results = _sanitize_raw_semantic_results(results)
            return json.dumps(sanitized_results, indent=2, ensure_ascii=False)

        formatted_results = []
        for i, result in enumerate(results, 1):
            formatted_results.append(
                f"{i}. {result['qualified_name']} (type: {result['type']}, score: {result['score']})"
            )

        response = cs.MSG_SEMANTIC_RESULT_HEADER.format(count=len(results), query=query)
        response += "\n".join(formatted_results)
        response += cs.MSG_SEMANTIC_RESULT_FOOTER

        return response

    return Tool(
        semantic_search_functions,
        name=td.AgenticToolName.SEMANTIC_SEARCH,
        description=(
            f"{td.SEMANTIC_SEARCH} Set `raw=true` to return raw JSON results, "
            "including payload metadata stored in the vector index."
        ),
    )


def create_get_function_source_tool() -> Tool:
    async def get_function_source_by_id(node_id: int) -> str:
        logger.info(ls.SEMANTIC_TOOL_SOURCE.format(id=node_id))

        source_code = get_function_source_code(node_id)

        if source_code is None:
            return cs.MSG_SEMANTIC_SOURCE_UNAVAILABLE.format(id=node_id)

        return cs.MSG_SEMANTIC_SOURCE_FORMAT.format(id=node_id, code=source_code)

    return Tool(get_function_source_by_id, name=td.AgenticToolName.GET_FUNCTION_SOURCE)
