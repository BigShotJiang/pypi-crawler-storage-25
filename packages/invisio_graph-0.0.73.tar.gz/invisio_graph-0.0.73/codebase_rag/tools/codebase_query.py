from __future__ import annotations

import re

from loguru import logger
from pydantic_ai import Tool
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from .. import exceptions as ex
from .. import logs as ls
from ..config import settings
from ..constants import (
    KEY_PROJECT_NAME,
    QUERY_NOT_AVAILABLE,
    QUERY_RESULTS_PANEL_TITLE,
    QUERY_SUMMARY_DB_ERROR,
    QUERY_SUMMARY_SUCCESS,
    QUERY_SUMMARY_TRANSLATION_FAILED,
)
from ..schemas import QueryGraphData
from ..services import QueryProtocol
from ..services.llm import CypherGenerator
from . import tool_descriptions as td

MAX_QUERY_VALUE_CHARS = 1000
_CONTAINMENT_PATTERN = (
    r"\(p\)-\[:CONTAINS_PACKAGE\|CONTAINS_FOLDER\|CONTAINS_FILE\|CONTAINS_MODULE\*?\]->"
    r"\((?P<alias>[A-Za-z_][A-Za-z0-9_]*)\)"
)


def _truncate_query_value(value: object) -> object:
    if isinstance(value, str) and len(value) > MAX_QUERY_VALUE_CHARS:
        return value[:MAX_QUERY_VALUE_CHARS].rstrip() + "..."
    return value


def _truncate_query_results(
    results: list[dict[str, object]],
) -> tuple[list[dict[str, object]], bool]:
    max_results = max(1, settings.RAG_MAX_QUERY_RESULTS)
    was_truncated = len(results) > max_results
    trimmed_rows = results[:max_results]
    normalized_rows: list[dict[str, object]] = []
    for row in trimmed_rows:
        normalized_rows.append(
            {key: _truncate_query_value(value) for key, value in row.items()}
        )
    return normalized_rows, was_truncated


def _enforce_project_scope(cypher_query: str, project_name: str) -> str:
    """
    Enforce project scoping in a Cypher query.

    Modifies the query to ensure it only queries the specified project.
    If the query has a WHERE clause with p.name, it replaces it.
    Otherwise, it injects a project constraint.
    """
    if not project_name:
        return cypher_query

    if "$project_name" in cypher_query or "project_id" in cypher_query:
        return cypher_query

    # Replace any existing p.name = '...' or p.name = "..." with the correct project
    query = re.sub(
        r"p\.name\s*=\s*['\"][^'\"]+['\"]",
        f"p.name = '{project_name}'",
        cypher_query,
        flags=re.IGNORECASE,
    )

    # If no p.name constraint was found, try to inject one
    if "p.name" not in query:
        # Try to find WHERE clause and add the constraint
        where_match = re.search(r"\bWHERE\b", query, re.IGNORECASE)
        if where_match:
            # Insert after WHERE
            insert_pos = where_match.end()
            query = query[:insert_pos] + f" p.name = '{project_name}' AND" + query[insert_pos:]
        else:
            # Try to find a good place to add WHERE (after main MATCH)
            match_match = re.search(r"\bMATCH\b[^(]*\([^)]*\)", query, re.IGNORECASE)
            if match_match:
                insert_pos = match_match.end()
                query = (
                    query[:insert_pos]
                    + f"\nWHERE p.name = '{project_name}'"
                    + query[insert_pos:]
                )

    return query


def _rewrite_project_traversal_filters(cypher_query: str) -> str:
    """
    Replace containment-based project checks with direct node project_id filters.

    This is more robust across graph backends because code symbols already carry
    a project_id property, while some graphs may not materialize every optional
    containment edge used by the generated query.
    """

    def replace_and(match: re.Match[str]) -> str:
        alias = match.group("alias")
        return f"AND {alias}.project_id = $project_name"

    def replace_where(match: re.Match[str]) -> str:
        alias = match.group("alias")
        return f"WHERE {alias}.project_id = $project_name"

    query = re.sub(
        rf"AND\s+{_CONTAINMENT_PATTERN}",
        replace_and,
        cypher_query,
        flags=re.IGNORECASE,
    )
    query = re.sub(
        rf"WHERE\s+{_CONTAINMENT_PATTERN}",
        replace_where,
        query,
        flags=re.IGNORECASE,
    )
    return query


def create_query_tool(
    ingestor: QueryProtocol,
    cypher_gen: CypherGenerator,
    console: Console | None = None,
    default_project_name: str | None = None,
) -> Tool:
    if console is None:
        console = Console(width=None, force_terminal=True)

    async def query_codebase_knowledge_graph(
        natural_language_query: str,
    ) -> QueryGraphData:
        effective_project_name = default_project_name
        logger.info(ls.TOOL_QUERY_RECEIVED.format(query=natural_language_query))
        cypher_query = QUERY_NOT_AVAILABLE
        try:
            query_input = natural_language_query
            params = None
            if effective_project_name:
                query_input = (
                    f"Only query data for project '{effective_project_name}'. "
                    "Ensure the Cypher query restricts results to this project by matching "
                    "`project_id = $project_name` or `project_id = '{effective_project_name}'`.\n"
                    f"{natural_language_query}"
                )
                params = {KEY_PROJECT_NAME: effective_project_name}

            cypher_query = await cypher_gen.generate(query_input)

            # Enforce project scoping to prevent LLM from querying other projects
            if effective_project_name:
                cypher_query = _enforce_project_scope(cypher_query, effective_project_name)

            if settings.graph_backend == "neo4j":
                cypher_query = _rewrite_project_traversal_filters(cypher_query)

            raw_results = ingestor.fetch_all(cypher_query, params)
            results, was_truncated = _truncate_query_results(raw_results)

            if results:
                table = Table(
                    show_header=True,
                    header_style="bold magenta",
                )
                headers = results[0].keys()
                for header in headers:
                    table.add_column(header)

                for row in results:
                    renderable_values = []
                    for value in row.values():
                        if value is None:
                            renderable_values.append("")
                        elif isinstance(value, bool):
                            renderable_values.append("✓" if value else "✗")
                        elif isinstance(value, int | float):
                            renderable_values.append(str(value))
                        else:
                            renderable_values.append(str(value))
                    table.add_row(*renderable_values)

                console.print(
                    Panel(
                        table,
                        title=QUERY_RESULTS_PANEL_TITLE,
                        expand=False,
                    )
                )

            summary = QUERY_SUMMARY_SUCCESS.format(count=len(results))
            if was_truncated:
                summary += (
                    f" Results were truncated to the first "
                    f"{settings.RAG_MAX_QUERY_RESULTS} row(s)."
                )
            return QueryGraphData(
                query_used=cypher_query, results=results, summary=summary
            )
        except ex.LLMGenerationError as e:
            return QueryGraphData(
                query_used=QUERY_NOT_AVAILABLE,
                results=[],
                summary=QUERY_SUMMARY_TRANSLATION_FAILED.format(error=e),
            )
        except Exception as e:
            logger.exception(ls.TOOL_QUERY_ERROR.format(error=e))
            return QueryGraphData(
                query_used=cypher_query,
                results=[],
                summary=QUERY_SUMMARY_DB_ERROR.format(error=e),
            )

    return Tool(
        function=query_codebase_knowledge_graph,
        name=td.AgenticToolName.QUERY_GRAPH,
        description=td.CODEBASE_QUERY,
    )
