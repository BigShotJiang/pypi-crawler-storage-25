from __future__ import annotations

from pathlib import Path

from . import graph_algorithms as ga
from .community_index import CommunityIndex
from .config import settings
from .query_router import QueryRouter
from .retrieval_budget import RetrievalBudget
from .retrieval_models import RetrievalEvidencePack, RetrievalIntent, RetrievalRoute
from .schemas import CodeSnippet
from .services import QueryProtocol
from .tools.code_retrieval import CodeRetriever
from .tools.file_reader import FileReader
from .tools.semantic_search import semantic_code_search
from .types_defs import ResultRow, SemanticSearchResult


class RetrievalInvestigator:
    def __init__(
        self,
        project_root: str,
        ingestor: QueryProtocol,
        *,
        router: QueryRouter | None = None,
        budget: RetrievalBudget | None = None,
    ) -> None:
        self.project_root = Path(project_root).resolve()
        self.project_name = self.project_root.name
        self.ingestor = ingestor
        self.router = router or QueryRouter()
        self.budget = budget or RetrievalBudget.from_settings()
        self.code_retriever = CodeRetriever(project_root=project_root, ingestor=ingestor)
        self.file_reader = FileReader(project_root=project_root)
        self.community_index = CommunityIndex(enabled=settings.RAG_COMMUNITIES_ENABLED)

    async def investigate(self, question: str) -> RetrievalEvidencePack:
        route = self.router.route(question)
        evidence = RetrievalEvidencePack(
            question=question,
            intent=route.intent,
            route_explanation=route.explanation,
        )

        if route.intent == RetrievalIntent.SYMBOL_LOOKUP:
            return await self._investigate_symbol_lookup(route, evidence)
        if route.intent == RetrievalIntent.STRUCTURAL_GRAPH:
            return await self._investigate_structural_graph(route, evidence)
        if route.intent == RetrievalIntent.ENTRYPOINT_TRACE:
            return await self._investigate_entrypoint_trace(route, evidence)
        if route.intent == RetrievalIntent.FLOW_TRACE:
            return await self._investigate_flow_trace(route, evidence)
        if route.intent == RetrievalIntent.ARCHITECTURE_OVERVIEW:
            return await self._investigate_architecture(route, evidence)
        if route.intent == RetrievalIntent.EDIT_TASK:
            return await self._investigate_edit_task(route, evidence)
        return await self._investigate_intent_search(route, evidence)

    async def _investigate_symbol_lookup(
        self, route: RetrievalRoute, evidence: RetrievalEvidencePack
    ) -> RetrievalEvidencePack:
        if not route.anchor_symbols:
            evidence.gaps.append("No symbol anchor was detected.")
            return await self._investigate_intent_search(route, evidence)

        candidates = ga.find_symbol_candidates(
            self.ingestor,
            self.project_name,
            route.anchor_symbols[0],
            limit=self.budget.max_snippets,
        )
        snippets = await self._fetch_snippets_from_rows(candidates)
        evidence.graph_rows = candidates
        evidence.snippets = snippets
        evidence.retrieval_summary = (
            f"Resolved {route.anchor_symbols[0]} to {len(snippets)} snippet(s) without broad file reads."
        )
        evidence.confidence = "high" if snippets else "low"
        if not snippets:
            evidence.gaps.append("No direct symbol snippet was found.")
        return evidence

    async def _investigate_structural_graph(
        self, route: RetrievalRoute, evidence: RetrievalEvidencePack
    ) -> RetrievalEvidencePack:
        if route.anchor_symbols:
            query_used, rows = ga.find_symbol_neighbors(
                self.ingestor,
                self.project_name,
                route.anchor_symbols[0],
                limit=self.budget.max_graph_rows,
            )
            evidence.graph_query_used = query_used
            evidence.graph_rows = rows
            evidence.snippets = await self._fetch_snippets_from_rows(rows)
            evidence.retrieval_summary = (
                f"Collected direct caller/callee neighbors for {route.anchor_symbols[0]}."
            )
            evidence.confidence = "high" if rows else "low"
            if not rows:
                evidence.gaps.append("No direct graph neighbors were found for the requested symbol.")
            return evidence
        evidence.gaps.append("No anchor symbol was detected for the structural query.")
        return await self._investigate_intent_search(route, evidence)

    async def _investigate_entrypoint_trace(
        self, route: RetrievalRoute, evidence: RetrievalEvidencePack
    ) -> RetrievalEvidencePack:
        query_used, rows = ga.find_entrypoint_candidates(
            self.ingestor,
            self.project_name,
            limit=self.budget.max_graph_rows,
        )
        semantic_results = semantic_code_search(query=evidence.question, top_k=self.budget.max_semantic_candidates)
        evidence.graph_query_used = query_used
        evidence.graph_rows = rows
        evidence.semantic_results = semantic_results
        evidence.snippets = await self._fetch_snippets_from_rows(rows) or await self._fetch_snippets_from_semantic(semantic_results)
        evidence.retrieval_summary = "Collected likely startup, app, route, and bootstrap anchors."
        evidence.confidence = "medium" if evidence.snippets or rows else "low"
        if not evidence.snippets and not rows:
            evidence.gaps.append("No strong entrypoint candidates were found in the graph.")
        return evidence

    async def _investigate_flow_trace(
        self, route: RetrievalRoute, evidence: RetrievalEvidencePack
    ) -> RetrievalEvidencePack:
        if route.anchor_symbols:
            query_used, rows = ga.find_symbol_neighbors(
                self.ingestor,
                self.project_name,
                route.anchor_symbols[0],
                limit=self.budget.max_graph_rows,
            )
            evidence.graph_query_used = query_used
            evidence.graph_rows = rows
            evidence.snippets = await self._fetch_snippets_from_rows(rows)
            evidence.retrieval_summary = (
                f"Collected immediate flow neighbors around {route.anchor_symbols[0]}."
            )
        else:
            semantic_results = semantic_code_search(
                query=evidence.question,
                top_k=self.budget.max_semantic_candidates,
            )
            evidence.semantic_results = semantic_results
            evidence.snippets = await self._fetch_snippets_from_semantic(semantic_results)
            evidence.retrieval_summary = "Used semantic search to anchor the requested flow before expanding context."
        evidence.confidence = "medium" if evidence.snippets else "low"
        if not evidence.snippets and route.allow_file_reads:
            await self._fallback_to_file_read(route, evidence)
        if not evidence.snippets and not evidence.graph_rows:
            evidence.gaps.append("The bounded retrieval pass could not anchor the flow strongly.")
        return evidence

    async def _investigate_architecture(
        self, route: RetrievalRoute, evidence: RetrievalEvidencePack
    ) -> RetrievalEvidencePack:
        query_used, rows = ga.find_architecture_overview(
            self.ingestor,
            self.project_name,
            limit=self.budget.max_graph_rows,
        )
        evidence.graph_query_used = query_used
        evidence.graph_rows = rows
        evidence.metadata["project_root"] = str(self.project_root)
        top_level_entries = self._list_top_level_entries()
        if top_level_entries:
            evidence.metadata["top_level_entries"] = ", ".join(top_level_entries)
        if "root directory" in evidence.question.lower() or "root folder" in evidence.question.lower():
            evidence.retrieval_summary = (
                f"Project root is {self.project_root}."
            )
            evidence.graph_summary = "Included project-root metadata and top-level entries."
            evidence.confidence = "high"
        else:
            evidence.retrieval_summary = (
                "Collected a graph-level overview of the project by dominant node types."
            )
            evidence.graph_summary = (
                "Architecture overview favors graph summaries plus project-root metadata over raw file reads."
            )
            evidence.confidence = "medium" if rows or top_level_entries else "low"
        if settings.RAG_COMMUNITIES_ENABLED:
            communities = self.community_index.find_relevant_communities(evidence.question)
            if communities:
                evidence.metadata["communities"] = len(communities)
        if not rows and not top_level_entries:
            evidence.gaps.append("No overview rows were returned for the project graph.")
        return evidence

    async def _investigate_edit_task(
        self, route: RetrievalRoute, evidence: RetrievalEvidencePack
    ) -> RetrievalEvidencePack:
        evidence = await self._investigate_intent_search(route, evidence)
        evidence.retrieval_summary = (
            evidence.retrieval_summary
            or "Collected edit-oriented evidence before allowing mutation tools."
        )
        if not evidence.snippets and route.allow_file_reads:
            await self._fallback_to_file_read(route, evidence)
        return evidence

    async def _investigate_intent_search(
        self, route: RetrievalRoute, evidence: RetrievalEvidencePack
    ) -> RetrievalEvidencePack:
        semantic_results = semantic_code_search(
            query=evidence.question,
            top_k=self.budget.max_semantic_candidates,
        )
        evidence.semantic_results = semantic_results
        evidence.snippets = await self._fetch_snippets_from_semantic(semantic_results)
        evidence.retrieval_summary = "Used semantic intent search and fetched only the top bounded snippets."
        evidence.confidence = "medium" if evidence.snippets else "low"
        if not evidence.snippets and route.allow_file_reads:
            await self._fallback_to_file_read(route, evidence, semantic_results=semantic_results)
        if not evidence.snippets:
            evidence.gaps.append("Semantic search did not yield a high-confidence snippet in the bounded pass.")
        return evidence

    async def _fetch_snippets_from_rows(self, rows: list[ResultRow]) -> list[CodeSnippet]:
        qualified_names = self._extract_qualified_names(rows)
        return await self._fetch_snippets(qualified_names)

    async def _fetch_snippets_from_semantic(
        self, rows: list[SemanticSearchResult]
    ) -> list[CodeSnippet]:
        qualified_names = [row["qualified_name"] for row in rows]
        return await self._fetch_snippets(qualified_names)

    async def _fetch_snippets(self, qualified_names: list[str]) -> list[CodeSnippet]:
        snippets: list[CodeSnippet] = []
        seen: set[str] = set()
        for qualified_name in qualified_names:
            if qualified_name in seen:
                continue
            seen.add(qualified_name)
            snippet = await self.code_retriever.find_code_snippet(qualified_name)
            if snippet.found:
                snippets.append(snippet)
            if len(snippets) >= self.budget.max_snippets:
                break
        return snippets

    async def _fallback_to_file_read(
        self,
        route: RetrievalRoute,
        evidence: RetrievalEvidencePack,
        *,
        semantic_results: list[SemanticSearchResult] | None = None,
    ) -> None:
        if not route.allow_file_reads:
            return
        candidate_paths: list[str] = []
        for result in semantic_results or []:
            path = result.get("payload", {}).get("path")
            if isinstance(path, str) and path and path not in candidate_paths:
                candidate_paths.append(path)

        for path in candidate_paths[:1]:
            read_result = await self.file_reader.read_file(path, offset=0, limit=40)
            if read_result.content:
                evidence.file_reads.append((path, read_result.content))
                evidence.metadata["used_file_read_fallback"] = True
                return
        evidence.gaps.append("File-read fallback was allowed but no suitable candidate path was available.")

    @staticmethod
    def _extract_qualified_names(rows: list[ResultRow]) -> list[str]:
        qualified_names: list[str] = []
        seen: set[str] = set()
        for row in rows:
            qualified_name = row.get("qualified_name")
            if isinstance(qualified_name, str) and qualified_name and qualified_name not in seen:
                seen.add(qualified_name)
                qualified_names.append(qualified_name)
        return qualified_names

    def _list_top_level_entries(self) -> list[str]:
        try:
            return sorted(path.name for path in self.project_root.iterdir())[:12]
        except Exception:
            return []
