Vernacular
==========

Internationalization components.
