import os
import re
import subprocess
from pathlib import Path

from colorama import Fore

from .templates import render_index_html


def _generate_web_ui_template(name: str, ui_dir: str, template: str):
    """Generate UI template for web apps (no QWebChannel)."""
    try:
        print(Fore.YELLOW + f"Setting up Vite in UI folder...")
        original_dir = os.getcwd()
        os.chdir(ui_dir)
        if template:
            subprocess.run(
                ["npm", "create", "vite@latest", ".", "--", "--template", template],
                check=True,
            )
        else:
            subprocess.run(
                ["npm", "create", "vite@latest", "."],
                check=True,
            )

        # Modify vite.config.js to add custom configuration
        vite_config_path = Path("vite.config.js")
        if vite_config_path.exists():
            print(Fore.YELLOW + f"Updating vite.config.js with custom settings...")
            config_content = vite_config_path.read_text()
            if "defineConfig" in config_content and "{" in config_content:
                if re.search(r"defineConfig\s*\(\s*{", config_content):
                    modified_content = re.sub(
                        r"(\s*}\s*\))(?!\s*[,;])",
                        r"""
  base: './',
  build: {
    outDir: 'templates',
  },
\1""",
                        config_content,
                        count=1,
                    )
                    vite_config_path.write_text(modified_content)
                    print(Fore.YELLOW + f"Updated vite.config.js with custom configuration")
        else:
            print(Fore.YELLOW + f"vite.config.js not found, creating it for vanilla template...")
            vite_config_path.write_text(
                """import { defineConfig } from 'vite'
// https://vitejs.dev/config/
export default defineConfig({
  base: './',
  build: {
    outDir: 'templates',
    emptyOutDir: true,
  },
})
"""
            )

        index_html_path = Path("index.html")
        index_html_path.write_text(render_index_html(template, "web"))
        print(Fore.YELLOW + f"Wrote Wysebee index.html for web ({template})")

        subprocess.run(["npm", "install"], check=True)
        subprocess.run(["npm", "run", "build"], check=True)
        os.chdir(original_dir)
        print(Fore.YELLOW + f"Successfully set up Vite in {name}/ui!")
        print(Fore.GREEN + f"Now you are ready!")
        print(Fore.GREEN + f" To run the app, use:")
        if name != ".":
            print(Fore.GREEN + f"   cd {name}")
        print(Fore.GREEN + f"   python main.py")
    except subprocess.CalledProcessError as e:
        print(Fore.RED + f"Error running npm create vite: {e}")
        os.chdir(original_dir)
    except Exception as e:
        print(Fore.RED + f"Unexpected error: {e}")
        os.chdir(original_dir)


def generate_server_app(name: str, app_dir: Path, ui_dir: Path, template: str) -> None:
    """Generate a FastAPI web app: main.py, requirements.txt, UI."""
    # Create main.py for FastAPI web app
    main_file = app_dir / "main.py"
    main_file.write_text(
        """import uvicorn
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
import os

app = FastAPI()

# Serve the built frontend
ui_path = os.path.join(os.path.dirname(__file__), "ui/templates")
app.mount("/", StaticFiles(directory=ui_path, html=True), name="static")

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
"""
    )
    print(Fore.YELLOW + f"Created main.py file in {name}")

    requirements_file = app_dir / "requirements.txt"
    requirements_file.write_text(
        """fastapi
uvicorn[standard]
Wysebee
"""
    )
    _generate_web_ui_template(name, ui_dir, template)
