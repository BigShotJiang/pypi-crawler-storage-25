import json
import os
import re
import subprocess
from pathlib import Path

from colorama import Fore

from .templates import render_index_html


def _generate_ui_template(name: str, ui_dir: str, template: str):
    # Change to UI directory and initialize vite
    try:
        print(Fore.YELLOW + f"Setting up Vite in UI folder...")
        original_dir = os.getcwd()
        os.chdir(ui_dir)
        if template:
            subprocess.run(
                ["npm", "create", "vite@latest", ".", "--", "--template", template],
                check=True,
            )
        else:
            subprocess.run(
                [
                    "npm",
                    "create",
                    "vite@latest",
                    ".",
                ],
                check=True,
            )

        # Modify vite.config.js to add custom configuration
        vite_config_path = Path("vite.config.js")
        if vite_config_path.exists():
            print(Fore.YELLOW + f"Updating vite.config.js with custom settings...")

            # Read the current content
            config_content = vite_config_path.read_text()

            # Find the defineConfig object
            if "defineConfig" in config_content and "{" in config_content:
                # Insert our custom config before the closing bracket of defineConfig
                # Find the last closing bracket
                if re.search(r"defineConfig\s*\(\s*{", config_content):
                    # Replace the closing parenthesis with our config options plus a closing parenthesis
                    modified_content = re.sub(
                        r"(\s*}\s*\))(?!\s*[,;])",
                        r"""
  base: './',
  build: {
    outDir: 'templates',
  },
\1""",
                        config_content,
                        count=1,
                    )

                    # Write the modified content back
                    vite_config_path.write_text(modified_content)
                    print(
                        Fore.YELLOW
                        + f"Updated vite.config.js with custom configuration"
                    )
        else:
            print(Fore.YELLOW + f"vite.config.js not found, creating it for vanilla template...")
            # Create a new vite.config.js file
            vite_config_path.write_text(
                """import { defineConfig } from 'vite'
// https://vitejs.dev/config/
export default defineConfig({
  base: './',
  build: {
    outDir: 'templates',
    emptyOutDir: true, // Optional: Clears the directory before building
  },
})
"""
            )

        index_html_path = Path("index.html")
        index_html_path.write_text(render_index_html(template, "desktop"))
        print(Fore.YELLOW + f"Wrote Wysebee index.html for desktop ({template})")

        subprocess.run(["npm", "install"], check=True)
        subprocess.run(["npm", "run", "build"], check=True)
        os.chdir(original_dir)
        print(Fore.YELLOW + f"Successfully set up Vite in {name}/ui!")
        print(Fore.GREEN + f"Now you are ready!")
        print(Fore.GREEN + f" To run the app, use:")
        if name != ".":
            print(Fore.GREEN + f"   cd {name}")
        print(Fore.GREEN + f"   python main.py")
    except subprocess.CalledProcessError as e:
        print(Fore.RED + f"Error running npm create vite: {e}")
        os.chdir(original_dir)
    except Exception as e:
        print(Fore.RED + f"Unexpected error: {e}")
        os.chdir(original_dir)


def _generate_app_menu_template(app_dir):
    """Create a menu folder with a sample menu.json."""
    menu_dir = Path(app_dir) / "menu"
    menu_dir.mkdir(exist_ok=True)
    menu_file = menu_dir / "menu.json"
    menu_file.write_text(
        json.dumps(
            [
                {
                    "label": "File",
                    "submenu": [
                        {"label": "Open", "action": "on_open"},
                        {"label": "Save", "action": "on_save"},
                        {"separator": True},
                        {"label": "Exit", "action": "on_exit"},
                    ],
                },
            ],
            indent=2,
        )
    )
    print(Fore.YELLOW + f"Created menu/menu.json in {app_dir}")


def generate_desktop_app(name: str, app_dir: Path, ui_dir: Path, template: str) -> None:
    """Generate a complete desktop app: src/, menu/, main.py, backend.py, requirements.txt, UI."""
    # Create the src subfolder
    src_dir = app_dir / "src"
    src_dir.mkdir(exist_ok=True)
    print(Fore.YELLOW + f"Created src folder in {name}")

    # Generate menu template
    _generate_app_menu_template(app_dir)

    # Create src/__init__.py
    init_file = src_dir / "__init__.py"
    init_file.write_text("")

    # Create src/backend.py
    backend_file = src_dir / "backend.py"
    backend_file.write_text(
        """import logging
from PySide6.QtWidgets import QApplication, QFileDialog
from PySide6.QtCore import Slot
from wysebee import WysebeeBackend

logger = logging.getLogger("wysebee")


class MyBackend(WysebeeBackend):
    def __init__(self, parent):
        super().__init__(parent)

    @Slot()
    def on_open(self):
        file_path, _ = QFileDialog.getOpenFileName(None, "Open File")
        if file_path:
            logger.info(f"Opened file: {file_path}")

    @Slot()
    def on_save(self):
        file_path, _ = QFileDialog.getSaveFileName(None, "Save File")
        if file_path:
            logger.info(f"Saved file: {file_path}")

    @Slot()
    def on_exit(self):
        logger.info("Exiting application")
        QApplication.quit()
"""
    )
    print(Fore.YELLOW + f"Created src/backend.py in {name}")

    # Create main.py file for desktop app
    main_file = app_dir / "main.py"
    main_file.write_text(
        """
import sys
import os
from PySide6.QtWidgets import QApplication
from wysebee import Wysebee, WysebeeAppMenu
from src.backend import MyBackend

def main():
    app = QApplication(sys.argv)
    wysebee = Wysebee(app)
    backend = MyBackend(app)
    browser = wysebee.initialize_window(width=1280, height=800, backend=backend)
    menu_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "menu/menu.json"))
    app_menu = WysebeeAppMenu(browser, backend, menu_path)
    html_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "ui/templates/index.html"))
    wysebee.launch(html_path)
    app_menu.show()

    sys.exit(app.exec())

if __name__ == "__main__":
    main()
"""
    )
    print(Fore.YELLOW + f"Created main.py file in {name}")

    requirements_file = app_dir / "requirements.txt"
    requirements_file.write_text(
        """
PySide6
Wysebee
"""
    )
    _generate_ui_template(name, ui_dir, template)
