import typer
from colorama import init as colorama_init, Fore
from pathlib import Path
import subprocess
import os

from .desktop import generate_desktop_app
from .server import generate_server_app

colorama_init(autoreset=True)
app = typer.Typer()


@app.command()
def init(
    name: str,
    template: str = typer.Option(
        "react", "--template", help="Template to use: react, react-ts, vanilla, vanilla-ts"
    )
):
    if not template in ["react", "react-ts", "vanilla", "vanilla-ts"]:
        print(
            Fore.RED
            + f"Invalid template '{template}'. Please choose from: react, react-ts, vanilla, vanilla-ts"
        )
        raise typer.Exit(code=1)

    app_type = typer.prompt(
        "What type of app would you like to create? (desktop/web)",
        default="desktop",
    ).strip().lower()
    if app_type not in ["desktop", "web"]:
        print(Fore.RED + f"Invalid app type '{app_type}'. Please choose 'desktop' or 'web'.")
        raise typer.Exit(code=1)

    print(Fore.YELLOW + f"Creating {app_type} app {name}")
    # Create the main app directory
    app_dir = Path(name)
    app_dir.mkdir(parents=True, exist_ok=True)

    # Create the ui subfolder
    ui_dir = app_dir / "ui"
    ui_dir.mkdir(exist_ok=True)
    print(Fore.YELLOW + f"Created ui folder in {name}")

    if app_type == "web":
        generate_server_app(name, app_dir, ui_dir, template)
    else:
        generate_desktop_app(name, app_dir, ui_dir, template)


def detect_app_type():
    """Auto-detect app type by checking main.py imports."""
    main_py = Path("main.py")
    if main_py.exists():
        content = main_py.read_text()
        if "fastapi" in content.lower():
            return "web"
    return "desktop"


@app.command()
def dev():
    build_ui()
    app_type = detect_app_type()
    if app_type == "web":
        print(Fore.YELLOW + "Starting FastAPI development server...")
        process = subprocess.Popen(
            ["uvicorn", "main:app", "--reload"],
        )
    else:
        process = subprocess.Popen(
            ["python", "main.py", "--dev"],
        )
    try:
        process.wait()
    except KeyboardInterrupt:
        print(Fore.YELLOW + "Stopping development server...")
        process.terminate()


def build_ui():
    original_dir = os.getcwd()
    app_dir = Path(original_dir)
    app_name = app_dir.name
    print(Fore.GREEN + f"Building UI for {app_name}!")

    ui_dir = app_dir / "ui"
    if ui_dir.exists():
        os.chdir(ui_dir)
        try:
            subprocess.run(["npm", "run", "build"], check=True)
            print(Fore.GREEN + f"Successfully built UI for {app_name}!")
        except subprocess.CalledProcessError as e:
            print(Fore.RED + f"Error building UI: {e}")
        finally:
            os.chdir(original_dir)
    else:
        print(
            Fore.RED
            + f"UI directory not found at {ui_dir}. Make sure you're in the correct project directory."
        )


@app.command()
def build(ui: bool = typer.Option(False, "--ui", help="Only build the UI portion")):
    if ui:
        build_ui()
    else:
        typer.echo(f"Building app!")
        # Add full build logic here


if __name__ == "__main__":
    app()
