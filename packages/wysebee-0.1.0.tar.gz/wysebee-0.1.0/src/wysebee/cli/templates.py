"""Shared HTML template helpers for generated apps."""

# Map each Vite template to its entry script path.
_ENTRY_POINTS = {
    "react": "/src/main.jsx",
    "react-ts": "/src/main.tsx",
    "vanilla": "/src/main.js",
    "vanilla-ts": "/src/main.ts",
}

_QWEBCHANNEL_HEAD = '<script src="qrc:///qtwebchannel/qwebchannel.js"></script>'

_QWEBCHANNEL_INIT = """<script>
      new QWebChannel(qt.webChannelTransport, function(channel) {
        console.log("✅ QWebChannel initialized");
        channel.objects.wysebee.sendMessage("Hello from the frontend!");
        window.wysebee = channel.objects.wysebee;
      });
    </script>"""


def render_index_html(template: str, platform: str) -> str:
    """Render the Wysebee-branded index.html.

    Args:
        template: Vite template ("react", "react-ts", "vanilla", "vanilla-ts").
        platform: "desktop" or "web". Desktop includes the QWebChannel bridge;
            web does not. This also switches the displayed runtime icon
            (PySide for desktop, FastAPI for web).
    """
    entry = _ENTRY_POINTS.get(template, "/src/main.js")
    if platform == "desktop":
        runtime_label = "PySide"
        runtime_emoji = "🖥️"
        qwebchannel_head = _QWEBCHANNEL_HEAD
        qwebchannel_init = _QWEBCHANNEL_INIT
    else:
        runtime_label = "FastAPI"
        runtime_emoji = "⚡"
        qwebchannel_head = ""
        qwebchannel_init = ""

    title = f"Wysebee.io + Vite + {runtime_label}"
    return f"""<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/svg+xml" href="/vite.svg" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>{title}</title>
    <style>
      body {{
        font-family: system-ui, -apple-system, sans-serif;
        text-align: center;
        padding: 2rem;
        color: #213547;
      }}
      .wysebee-stack {{
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 1rem;
        margin: 1.5rem 0;
        font-size: 2rem;
      }}
      .wysebee-stack .plus {{ color: #888; font-size: 1.5rem; }}
      .wysebee-stack .label {{ font-size: 0.85rem; display: block; color: #555; }}
      .wysebee-stack .item {{ display: flex; flex-direction: column; align-items: center; }}
      .wysebee-link a {{ color: #646cff; text-decoration: none; font-weight: 500; }}
      .wysebee-link a:hover {{ text-decoration: underline; }}
    </style>
    {qwebchannel_head}
  </head>
  <body>
    <div class="wysebee-stack">
      <span class="item">🐝<span class="label">Wysebee</span></span>
      <span class="plus">+</span>
      <span class="item">⚡<span class="label">Vite</span></span>
      <span class="plus">+</span>
      <span class="item">{runtime_emoji}<span class="label">{runtime_label}</span></span>
    </div>
    <p class="wysebee-link">Powered by <a href="https://wysebee.io" target="_blank" rel="noopener">wysebee.io</a></p>
    <div id="root"></div>
    {qwebchannel_init}
    <script type="module" src="{entry}"></script>
  </body>
</html>
"""
