# Install datasight

datasight is distributed as a Python CLI on PyPI. The recommended
installer is [uv](https://docs.astral.sh/uv/), which installs datasight
as a global tool without managing a virtual environment. If you already
have a Python toolchain you prefer, `pip` works too.

=== "uv (recommended)"

    ```bash
    # Install uv (one-time — see https://docs.astral.sh/uv/getting-started/installation/)
    curl -LsSf https://astral.sh/uv/install.sh | sh

    # Install datasight
    uv tool install datasight
    ```

=== "pip"

    ```bash
    pip install --user datasight
    ```

This includes DuckDB, SQLite, PostgreSQL, Anthropic, OpenAI, GitHub
Models, and Ollama support.

## Configure an LLM provider

Run `datasight config init` to create `~/.config/datasight/.env`, then add
your API key there — every project on this machine will pick it up.
Alternatively, paste the key into the project `.env` or export it in your
shell. Pick one of:

=== "Anthropic"

    ```bash
    ANTHROPIC_API_KEY=sk-ant-...
    ```

=== "OpenAI"

    ```bash
    LLM_PROVIDER=openai
    OPENAI_API_KEY=sk-...
    OPENAI_MODEL=gpt-4o-mini
    ```

    For Azure OpenAI or a corporate gateway, also set `OPENAI_BASE_URL`.

=== "GitHub Models"

    ```bash
    LLM_PROVIDER=github
    GITHUB_TOKEN=ghp_...
    GITHUB_MODELS_MODEL=gpt-4o
    ```

    `GITHUB_TOKEN` is a GitHub token with access to GitHub Models — it is
    *not* the same as a git push credential. Pick one source:

    - **GitHub CLI** — if you already use `gh`, run `gh auth token` and
      paste the output. This is the quickest path.
    - **Fine-grained PAT** — create one at
      [github.com/settings/personal-access-tokens](https://github.com/settings/personal-access-tokens)
      with the **`Models: read`** account permission. No repository access
      is needed. Classic PATs do not grant Models access.

=== "Ollama (local)"

    Install [Ollama](https://ollama.com/), pull a tool-calling model, then:

    ```bash
    ollama pull qwen2.5:7b

    LLM_PROVIDER=ollama
    OLLAMA_MODEL=qwen2.5:7b
    ```

    `qwen2.5:7b` is a good starting point for CLI queries (`datasight ask`).
    For the web UI with visualizations, `qwen2.5:14b` handles the more
    complex agent interactions better. For the best experience overall,
    consider [GitHub Models](https://github.com/marketplace/models) (free
    tier) — only use Ollama when cost or data-security requirements demand
    keeping inference local.

See the [Configuration reference](../../reference/configuration.md) for
every supported variable.

!!! note "PNG chart export"
    `datasight ask --chart-format png` needs the optional export extra.
    Reinstall with the extra — for example,
    `uv tool install "datasight[export]"` or
    `pip install --user "datasight[export]"`.
    The web UI does not need it.
