"""LLM models, tiers, system prompt, and UI examples.

Everything that defines Ockham as a product — which models to use,
how they're tiered for the UI, the system prompt, and example queries.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from functools import cache
from typing import Any

from parsimony_agents.agent.prompts import DEFAULT_DATA_ANALYSIS_PROMPT


@dataclass(frozen=True)
class Model:
    name: str
    litellm_id: str
    api_key_env: str
    temperature: float = 1.0
    reasoning_effort: str | None = None


@dataclass(frozen=True)
class Tier:
    name: str
    description: str
    model: str  # key in MODELS


@dataclass(frozen=True)
class Example:
    title: str
    text: str


MODELS: dict[str, Model] = {
    "gemini_30_flash": Model(
        name="Flash",
        litellm_id="gemini/gemini-3-flash-preview",
        api_key_env="GEMINI_API_KEY",
    ),
    "openrouter_claude_46_sonnet": Model(
        name="Claude Sonnet 4.6",
        litellm_id="openrouter/anthropic/claude-sonnet-4-6",
        api_key_env="OPENROUTER_API_KEY",
        reasoning_effort="low",
    ),
}

TIERS: dict[str, Tier] = {
    "mini": Tier(
        name="Mini",
        description="Balanced speed and quality",
        model="gemini_30_flash",
    ),
    "pro": Tier(
        name="Pro",
        description="For critical tasks",
        model="openrouter_claude_46_sonnet",
    ),
}

DEFAULT_TIER: str = "pro"


def agent_config(model_id: str) -> dict[str, Any]:
    """Build the dict that gets ``**spread`` into ``litellm.acompletion()``."""
    from server.api.utils.secrets import secret_store

    m = MODELS[model_id]
    api_key = secret_store.get_secret(m.api_key_env) or os.environ.get(m.api_key_env, "")
    cfg: dict[str, Any] = {
        "model": m.litellm_id,
        "api_key": api_key,
        "temperature": m.temperature,
    }
    if m.reasoning_effort is not None:
        cfg["reasoning_effort"] = m.reasoning_effort
    return cfg


# ---------------------------------------------------------------------------
# System prompt
# ---------------------------------------------------------------------------


@cache
def system_prompt() -> str:
    """Canonical data-analysis prompt.

    Single source of truth lives in
    :data:`parsimony_agents.agent.prompts.DEFAULT_DATA_ANALYSIS_PROMPT`
    so terminal and OSS quickstart cannot drift again.
    """
    return DEFAULT_DATA_ANALYSIS_PROMPT


# ---------------------------------------------------------------------------
# Curated demo prompts. No longer served by the API; consumed by
# ``scripts/export_landing_examples.py`` to regenerate landing-page
# galleries.
# ---------------------------------------------------------------------------

EXAMPLES: tuple[Example, ...] = (
    # Company analysis
    Example(
        "Amazon CapEx & CapEx-to-sales",
        "Make a bar chart showing Amazon's total capital expenditures over the last 5 years, and overlay a line chart showing the company's CapEx-to-sales ratio over the same period. Make it quarterly.",
    ),
    Example(
        "Buffet cash pile",
        "Plot the total cash (bars) and cash as % of total assets (line) of Berkshire last 20 years quarterly",
    ),
    Example(
        "Apple profitability trends",
        "Chart Apple's net profit margin, operating profit margin, and gross profit margin over the last 10 quarters. Highlight any quarters where margins compressed by more than 2 percentage points.",
    ),
    Example(
        "Nvidia ROE vs ROIC",
        "Compare Nvidia's quarterly return on equity (ROE) and return on invested capital (ROIC) over the last 5 years. Add a reference line at 15% for both metrics.",
    ),
    Example("MAG7 Valuation", "Plot the current (trailing) P/E ratios of all Magnificent 7 companies in a bar chart"),
    Example("Coca Cola vs Pepsi dividend", "Plot Coca Cola and Pepsi dividend yield per year last 25 years"),
    Example(
        "Nvidia size comparison",
        "Create a stacked bar chart comparing Nvidia's market capitalization to the combined market capitalization of 10 biggest pharma companies. Label Nvidia separately and group the big pharma firms",
    ),
    Example(
        "AI Capex",
        "Make a stacked bar chart showing quarterly capex data for Apple, Amazon, Meta and Alphabet since 2018",
    ),
    Example(
        "STOXX 600 dividend income",
        "If i invested 100k in STOXX 600 10 years ago, how much money would i make from dividends. Make a bar chart of income per year",
    ),
    # Cross-domain
    Example(
        "S&P 500 vs job openings",
        "Plot the S&P 500 index and total job openings from 2015 onward on the same axis, and highlight ChatGPT's launch date.",
    ),
    Example(
        "Truck sales leading indicator",
        "Plot number of heavy weight truck sales and s&p 500 price over the last 5 years",
    ),
    Example("Interest rates vs S&P", "Plot last 20 years S&P 500 movement and fed interest rate"),
    Example(
        "Yield curve inversion & market",
        "Plot 10Y-2Y US Treasury yield spread alongside S&P 500 over the last 30 years, highlighting periods of yield curve inversion",
    ),
    # Economic analysis
    Example(
        "Nonfarm payrolls + recession",
        "Plot the monthly change in Nonfarm Payrolls over the last 20 years prior covid. Gradient shade the periods based on the U.S. probability of recession.",
    ),
    Example(
        "US vs Germany bond rates",
        "Plot the U.S. and Germany government bond rates over the past 20 years, together with the interest rate spread. Fill the calculated spread area in green when positive and red when negative.",
    ),
    Example(
        "CPI vs Fed Funds pressure",
        "Plot the U.S. CPI YoY% and the effective Fed Funds rate on the same chart since 1990, and highlight the periods where inflation exceeded the policy rate.",
    ),
    Example(
        "WTI vs CPI correlation",
        "Chart WTI crude oil prices and U.S. CPI YoY% since 1990, and compute/annotate the correlation coefficient for each decade.",
    ),
    Example(
        "Household debt burden",
        "Plot U.S. household debt as a percentage of disposable personal income from 1990 onward.",
    ),
    Example(
        "Home price-to-income ratio", "Chart median U.S. home prices divided by median household income since 1990."
    ),
    Example(
        "GDP growth comparison",
        "Compare GDP growth for Germany, France, Italy, and Spain (1995-2024) and automatically highlight recession periods.",
    ),
    Example(
        "Spain inflation breakdown",
        "Break down inflation in Spain since 2000 and calculate component contributions to total inflation.",
    ),
    Example(
        "G20 inflation rate",
        "Retrieve the most recent inflation rate for G20 countries, rank them, and flag those above their 10-year average.",
    ),
    Example("Debt ratios", "Compare debt ratios since 2000 and flag countries breaching the 60% Maastricht threshold."),
    Example(
        "GDP per capita",
        "Retrieve GDP per capita for Spanish NUTS 2 regions (2010-latest) and create a sorted heatmap showing each region's wealth index relative to the national average",
    ),
    Example(
        "Yield curve inversion",
        "Compare short-term vs long-term government bond yields (US, Germany, UK) and detect yield curve inversions.",
    ),
    # Market analysis
    Example(
        "Bitcoin halving events",
        "Take a logarithmic chart of Bitcoin's price over the last 15 years, mark each halving event with a vertical line, and highlight (with a dashed outline) the start of a period 500 days before (buy) and 500 days after each halving (sell)",
    ),
    Example(
        "Bitcoin monthly seasonality",
        "Build a bar chart of Bitcoin's average monthly performance for every calendar month over the last 10 years.",
    ),
    Example(
        "Bitcoin death crosses",
        "Plot Bitcoin's price over the past 10 years and mark every death cross (50-day SMA falling below the 200-day SMA) directly on the chart.",
    ),
    Example(
        "MSFT price-volume spikes",
        "Plot Microsoft's price and volume for the current year, and flag any session where daily volume exceeded twice the trailing 30-day average.",
    ),
    Example(
        "S&P vs Magnificent 7 YTD",
        "Plot the percentage return of the S&P 500, an equally weighted basket of the Magnificent 7 stocks, and the S&P 500 excluding the Magnificent 7 since 2023.",
    ),
    Example(
        "Presidential terms market comp",
        "Compare the S&P 500's first 100 days performance during the first term of each of the last four U.S. presidents on a line chart including Trump's second term",
    ),
    Example(
        "Gold vs Bitcoin",
        "Make a line chart (using quarterly or annual data) showing how many hours of work were needed to buy 1 ounce of gold and 1 Bitcoin in the last 25 years. Make it on a same axis",
    ),
    Example(
        "S&P 500 currency effect",
        "Plot the S&P 500 index 2025 performance denominated in euros (EUR) and denominated in dollars (USD) on a line chart.",
    ),
    # Probability markets
    Example("Recession probability", "What is the probability of recession this year according to polymarket?"),
    Example("Next fed decision", "What is the most probable next Fed decision according to Polymarket?"),
    Example(
        "Bitcoin prediction",
        "Make a chart of bitcoin price last 12 months and add dotted lines for the predictions for its future movement according to Polymarket",
    ),
    Example(
        "S&P 500 prediction",
        "Make a chart of S&P 500 last 12 months and add dotted lines for the predictions for its future movement according to Polymarket",
    ),
)
