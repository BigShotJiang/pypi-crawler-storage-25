"""Single composition point for the agent runtime's connectors.

The runtime exposes one flat namespace to agent code: ``connectors``. Every
installed ``parsimony.providers`` plugin contributes its source-bound
connectors (``fred_search``, ``fred_fetch``, ``sdmx_fetch``, ``fmp_quotes``,
...). They share one keyed bundle, so user code always reads
``connectors["fred_search"](search_text="...")``.

Loader/enumerator connectors (catalog-build hooks tagged ``"loader"`` or
``"enumerator"``) are dropped here — they are not runtime tools.
"""

from __future__ import annotations

from collections.abc import Mapping

from parsimony.connector import Connectors
from parsimony.discover import load_all

_NON_RUNTIME_TAGS = frozenset({"loader", "enumerator"})


def build_agent_connectors(env: Mapping[str, str]) -> dict[str, Connectors]:
    """Build the single ``connectors`` bundle exposed to agent code.

    Source-bound providers come from :func:`parsimony.discover.load_all`
    (every installed ``parsimony.providers`` plugin) bound against ``env``
    via :meth:`Connectors.bind_env`. Catalog-build hooks are filtered out.

    Returned as a ``Mapping`` with one key so the agent executor exposes it
    in user code as ``connectors[...]`` (matches the system prompt). The
    Mapping path is the one documented by
    :func:`parsimony_agents.execution.helpers.normalize_connector_bundles`.
    """
    bundle = load_all().bind_env(env).filter(predicate=lambda c: not (_NON_RUNTIME_TAGS & set(c.tags)))
    return {"connectors": bundle}
