"""Console-script entrypoint for the `ockham` wheel.

Boots backend (FastAPI) and executor (sandbox) in a single process, configures
the workspace directory, serves the bundled SPA, and opens the browser when
ready. See `pyproject.toml`'s `[project.scripts]` for wiring.
"""

from __future__ import annotations

import argparse
import asyncio
import contextlib
import importlib.resources
import logging
import os
import signal
import socket
import sys
import webbrowser
from collections.abc import Generator, Sequence
from pathlib import Path

import httpx
import uvicorn

logger = logging.getLogger("ockham")

DEFAULT_PORT = 8000
DEFAULT_HOST = "127.0.0.1"
HEALTH_PATH = "/api/status"
HEALTH_TIMEOUT_S = 30.0
SHUTDOWN_DRAIN_S = 5.0


class _SharedSignalServer(uvicorn.Server):
    """uvicorn.Server with its own signal capture suppressed.

    Two uvicorn.Server instances running concurrently each install handlers
    via signal.signal(), and the second one overrides the first — so Ctrl-C
    only stops one server and the process hangs on the other. The CLI
    installs a single shared handler that signals both; this subclass keeps
    uvicorn from clobbering it.
    """

    @contextlib.contextmanager
    def capture_signals(self) -> Generator[None, None, None]:
        yield


def _parse_args(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="ockham",
        description="Launch the Ockham single-user analyst terminal.",
    )
    parser.add_argument(
        "--workspace",
        default=str(Path.home() / "ockham"),
        help="Workspace directory for all user data (default: ~/ockham).",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=DEFAULT_PORT,
        help=f"Backend port (default: {DEFAULT_PORT}; falls back to ephemeral if taken).",
    )
    parser.add_argument(
        "--host",
        default=DEFAULT_HOST,
        help=f"Backend host (default: {DEFAULT_HOST}).",
    )
    parser.add_argument(
        "--no-browser",
        action="store_true",
        help="Don't open a browser tab automatically.",
    )
    return parser.parse_args(argv)


def _bind_port(host: str, requested: int) -> int:
    """Pick a port: try `requested`, fall back to ephemeral on EADDRINUSE.

    Returns the actually-bound port (which is the kernel-assigned one when
    requested == 0, or when requested was busy and we fell back). The socket
    is closed before returning so uvicorn can re-bind. TOCTOU race exists
    but is acceptable for a single-user local launcher.
    """
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.bind((host, requested))
            return sock.getsockname()[1]
    except OSError:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.bind((host, 0))
            actual = sock.getsockname()[1]
            logger.warning("port %d in use; using ephemeral port %d", requested, actual)
            return actual


async def _wait_then_open(host: str, port: int, no_browser: bool) -> None:
    url = f"http://{host}:{port}"
    deadline = asyncio.get_running_loop().time() + HEALTH_TIMEOUT_S
    async with httpx.AsyncClient(timeout=1.0) as client:
        while asyncio.get_running_loop().time() < deadline:
            try:
                r = await client.get(f"{url}{HEALTH_PATH}")
            except httpx.HTTPError:
                pass
            else:
                if r.status_code == 200:
                    break
            await asyncio.sleep(0.25)
        else:
            logger.warning("backend did not become healthy within %ss; skipping browser-open", HEALTH_TIMEOUT_S)
            return

    print(f"\nOckham is running at {url}\n", flush=True)
    if no_browser:
        return
    try:
        webbrowser.open(url)
    except Exception as e:  # noqa: BLE001 — webbrowser raises diverse exceptions on headless systems
        logger.warning("could not open browser: %s", e)


def _make_config(app: object, host: str, port: int, *, log_level: str) -> uvicorn.Config:
    # timeout_keep_alive: drop idle keep-alive HTTP connections after 2s
    # (default 5s). timeout_graceful_shutdown: cancel in-flight requests after
    # 3s of trying to drain (default unlimited). Together these bound a
    # graceful Ctrl-C to ~3-5s. Second Ctrl-C escalates to force_exit.
    return uvicorn.Config(
        app,
        host=host,
        port=port,
        log_level=log_level,
        access_log=False,
        timeout_keep_alive=2,
        timeout_graceful_shutdown=3,
    )


async def _run(host: str, backend_port: int, executor_port: int, no_browser: bool) -> int:
    # Env vars (OCKHAM_DATA_DIR, EXECUTOR_URL, FRONTEND_DIR) must be set
    # before these modules' Config classes read them at import time.
    from sandbox.executor import app as executor_app
    from server.api.main import app as backend_app

    backend = _SharedSignalServer(_make_config(backend_app, host, backend_port, log_level="info"))
    executor = _SharedSignalServer(_make_config(executor_app, "127.0.0.1", executor_port, log_level="warning"))

    def _on_signal() -> None:
        # Second Ctrl-C escalates to force_exit so users aren't stuck waiting
        # on streaming responses or background tasks to drain.
        if backend.should_exit or executor.should_exit:
            backend.force_exit = True
            executor.force_exit = True
            print("\nForce-exit requested.", flush=True, file=sys.stderr)
            return
        print("\nShutting down (Ctrl-C again to force-exit)...", flush=True, file=sys.stderr)
        backend.should_exit = True
        executor.should_exit = True

    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, _on_signal)
        except NotImplementedError:
            # Windows: fall back to signal.signal (one handler per signal).
            signal.signal(sig, lambda *_: _on_signal())

    backend_task = asyncio.create_task(backend.serve(), name="backend")
    executor_task = asyncio.create_task(executor.serve(), name="executor")
    health_task = asyncio.create_task(_wait_then_open(host, backend_port, no_browser), name="health")

    try:
        # If either server exits unexpectedly, signal the other to wind down.
        done, pending = await asyncio.wait(
            {backend_task, executor_task},
            return_when=asyncio.FIRST_COMPLETED,
        )
        backend.should_exit = True
        executor.should_exit = True
        if pending:
            await asyncio.wait(pending, timeout=SHUTDOWN_DRAIN_S)
            for task in pending:
                task.cancel()
            await asyncio.gather(*pending, return_exceptions=True)
        # Surface exceptions from completed tasks (e.g. bind failure).
        for task in done:
            if (exc := task.exception()) is not None:
                raise exc
    finally:
        health_task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await health_task

    return 0


def main(argv: Sequence[str] | None = None) -> int:
    args = _parse_args(argv)

    workspace = Path(args.workspace).expanduser().resolve()
    workspace.mkdir(parents=True, exist_ok=True)
    os.environ["OCKHAM_DATA_DIR"] = str(workspace)

    # The bundled SPA only exists in installs that came from the wheel
    # (scripts/build-wheel.sh copies web/dist/ into server/web_dist/).
    # Editable dev installs without that step skip static-file serving.
    web_dist = importlib.resources.files("server") / "web_dist"
    if web_dist.is_dir():
        os.environ["FRONTEND_DIR"] = str(web_dist)

    backend_port = _bind_port(args.host, args.port)
    executor_port = _bind_port("127.0.0.1", 0)
    os.environ["EXECUTOR_URL"] = f"http://127.0.0.1:{executor_port}"

    print(
        f"Starting Ockham on http://{args.host}:{backend_port}\n"
        f"  workspace: {workspace}\n"
        f"  executor:  http://127.0.0.1:{executor_port}",
        flush=True,
    )

    try:
        return asyncio.run(_run(args.host, backend_port, executor_port, args.no_browser))
    except KeyboardInterrupt:
        return 0


if __name__ == "__main__":
    sys.exit(main())
