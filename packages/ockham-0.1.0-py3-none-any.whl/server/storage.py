"""User-data and cache paths for the Ockham terminal.

Two roots, each overridable via env var, defaulting to platformdirs:

* ``OCKHAM_DATA_DIR``  → durable user content. Default:
  ``platformdirs.user_data_dir("ockham")`` (e.g. ``~/.local/share/ockham`` on
  Linux, ``~/Library/Application Support/ockham`` on macOS).
* ``OCKHAM_CACHE_DIR`` → regeneratable state. Default:
  ``platformdirs.user_cache_dir("ockham")`` (e.g. ``~/.cache/ockham`` on
  Linux, ``~/Library/Caches/ockham`` on macOS).

Mirrors :mod:`parsimony.cache` — same env-override-then-platformdirs pattern.
Path helpers ensure their target exists before returning so callers can
construct paths without their own ``mkdir(parents=True, exist_ok=True)``.

The split matters: a ``~/.cache`` wipe must not destroy a user's notebooks.
``data_dir()`` holds workspaces (durable user content); ``cache_dir()``
holds sessions and derived artifacts (regeneratable).
"""

from __future__ import annotations

import os
from pathlib import Path

from platformdirs import user_cache_dir, user_data_dir

__all__ = [
    "artifacts_dir",
    "cache_dir",
    "data_dir",
    "sessions_dir",
    "workspaces_dir",
]

_DATA_ENV = "OCKHAM_DATA_DIR"
_CACHE_ENV = "OCKHAM_CACHE_DIR"


def _ensure(p: Path) -> Path:
    p.mkdir(parents=True, exist_ok=True)
    return p


def data_dir() -> Path:
    """Root for durable user content. Honors ``$OCKHAM_DATA_DIR``."""
    override = os.environ.get(_DATA_ENV)
    base = Path(override).expanduser() if override else Path(user_data_dir("ockham"))
    return _ensure(base)


def cache_dir() -> Path:
    """Root for regeneratable state. Honors ``$OCKHAM_CACHE_DIR``."""
    override = os.environ.get(_CACHE_ENV)
    base = Path(override).expanduser() if override else Path(user_cache_dir("ockham"))
    return _ensure(base)


def workspaces_dir() -> Path:
    """Per-user workspace trees (notebooks, files). Durable — under data_dir."""
    return _ensure(data_dir() / "workspaces")


def sessions_dir() -> Path:
    """Session-scoped state (RAG vector stores, dataframe cache). Regeneratable."""
    return _ensure(cache_dir() / "sessions")


def artifacts_dir() -> Path:
    """Derived artifact payloads. Regeneratable."""
    return _ensure(cache_dir() / "artifacts")
