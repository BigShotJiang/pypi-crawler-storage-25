"""
Assistant package for financial data analysis.
"""
