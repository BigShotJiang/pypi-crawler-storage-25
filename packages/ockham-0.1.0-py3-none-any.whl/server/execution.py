"""Code execution and kernel outputs; app wiring over parsimony_agents."""

from __future__ import annotations

import asyncio
import contextlib
import logging
from typing import Any

import httpx
import pandas as pd
from parsimony_agents.execution import (
    DataFrameObject,
    DatasetRefreshRecipe,
    ExceptionObject,
    FigureObject,
    KernelOutput,
    KernelOutputType,
    MetadataItem,
    PrimitiveObject,
    PrimitiveTypes,
    RefreshStatus,
    StringPaginator,
    TablePaginator,
    finalize_spec,
    generate_cell_id,
)
from parsimony_agents.execution.executor import BaseCodeExecutor
from parsimony_agents.execution.executor import CodeExecutor as _LibraryCodeExecutor
from parsimony_agents.execution.factory import OutputFactory as _LibOutputFactory
from parsimony_agents.execution.pagination import get_output_header
from parsimony_agents.execution.run_scope import VariableOrigin
from parsimony_agents.views import (
    DataFrameViewConfig,
    PrimitiveViewConfig,
    SearchViewConfig,
    get_llm_view_defaults,
)
from pydantic import TypeAdapter

pd.set_option("future.no_silent_downcasting", True)
pd.set_option("display.float_format", "{:.2f}".format)
pd.set_option("mode.chained_assignment", "raise")
pd.set_option("mode.copy_on_write", True)

_log = logging.getLogger(__name__)


def _serialize_seen_live_names(
    seen: set[tuple[str, str]] | None,
) -> list[list[str]] | None:
    """Encode the seen-set as JSON-friendly ``list[list[str]]``.

    JSON has no set or tuple; pairs are serialised as two-element lists.
    The sandbox endpoint rehydrates the same shape back into
    ``set[tuple[str, str]]`` before passing it into the in-process
    executor (see ``terminal/sandbox/executor.py``).
    """
    if seen is None:
        return None
    return [[kind, live_name] for (kind, live_name) in sorted(seen)]


_app_output_factory: _LibOutputFactory | None = None


def get_app_output_factory() -> _LibOutputFactory:
    """Lazily constructed output factory (session dir + optional S3 backend)."""
    global _app_output_factory
    if _app_output_factory is None:
        from server.storage import sessions_dir

        _app_output_factory = _LibOutputFactory(
            local_dir=str(sessions_dir()),
            backend=None,
        )
    return _app_output_factory


class RemoteCodeExecutor(BaseCodeExecutor):
    """Remote code executor that interacts with a sandbox server via HTTP (app-specific)."""

    def __init__(
        self,
        base_url: str,
        executor_id: str | None = None,
        *,
        request_timeout_s: float = 600.0,
    ):
        self.base_url = base_url.rstrip("/")
        self.executor_id = executor_id
        self.cwd: str | None = None
        self.session_id: str | None = None
        self.request_timeout_s = request_timeout_s
        self._client = httpx.AsyncClient(base_url=self.base_url, timeout=request_timeout_s)
        self._setup_snippets: list[str] = []
        self._has_connectors: bool = False
        # Serialize mutating/executing kernel work on this client (one remote kernel / id).
        self._kernel_gate = asyncio.Lock()

    def _request_timeout(self, timeout_seconds: float | None) -> float:
        return timeout_seconds if timeout_seconds is not None else self.request_timeout_s

    async def _ensure_executor_id(self) -> None:
        if self.executor_id is None:
            resp = await self._client.post("/executors")
            resp.raise_for_status()
            self.executor_id = resp.json()["id"]
            _log.info(
                "Remote kernel created",
                extra={"event": "remote_kernel_created", "executor_id": self.executor_id},
            )

    async def _post_set_cwd(self) -> None:
        """Set cwd on the sandbox. Caller must hold :attr:`_kernel_gate` and a valid id."""
        assert self.executor_id is not None
        assert self.cwd is not None
        resp = await self._client.post(
            f"/executors/{self.executor_id}/set_cwd",
            json={"cwd": self.cwd, "session_id": self.session_id},
        )
        resp.raise_for_status()

    async def set_cwd(self, cwd: str, session_id: str | None = None) -> None:
        async with self._kernel_gate:
            self.cwd = cwd
            self.session_id = session_id
            await self._ensure_executor_id()
            await self._post_set_cwd()

    async def set_connectors(self, connectors: Any) -> None:
        """Mark that connectors should be initialized on the sandbox.

        The sandbox builds its own connectors from environment variables
        via :func:`server.connectors.build_agent_connectors` (returns a
        single flat ``connectors`` bundle).
        """
        self._has_connectors = True
        async with self._kernel_gate:
            await self._apply_connectors()

    async def _apply_connectors(self) -> None:
        """Tell the sandbox to initialize connectors from its own env vars.

        Caller must hold :attr:`_kernel_gate` when this mutates a live executor.
        """
        if not self._has_connectors:
            return
        await self._ensure_executor_id()
        resp = await self._client.post(
            f"/executors/{self.executor_id}/set_connectors",
        )
        resp.raise_for_status()

    def add_setup_snippet(self, code: str) -> None:
        """Register code that will be re-executed after every ``clear_namespace``."""
        self._setup_snippets.append(code)

    async def _run_setup_snippets(self) -> None:
        assert self.executor_id is not None
        for snippet in self._setup_snippets:
            resp = await self._client.post(
                f"/executors/{self.executor_id}/execute",
                json={"code": snippet, "dry_run": False},
            )
            resp.raise_for_status()

    async def clear_namespace(self) -> None:
        async with self._kernel_gate:
            await self._ensure_executor_id()
            resp = await self._client.post(
                f"/executors/{self.executor_id}/clear_namespace",
            )
            if resp.status_code == 404:
                self.executor_id = None
                await self._ensure_executor_id()
                if self.cwd is not None:
                    await self._post_set_cwd()
                resp = await self._client.post(
                    f"/executors/{self.executor_id}/clear_namespace",
                )
            resp.raise_for_status()
            await self._apply_connectors()
            await self._run_setup_snippets()

    async def execute(
        self,
        code: str,
        dry_run: bool = False,
        timeout_seconds: float | None = None,
        producer_notebook_path: str | None = None,
        seen_live_names: set[tuple[str, str]] | None = None,
    ) -> KernelOutput:
        async with self._kernel_gate:
            await self._ensure_executor_id()
            payload = {
                "code": code,
                "dry_run": dry_run,
                "workspace_mode": False,
                "producer_notebook_path": producer_notebook_path,
                "seen_live_names": _serialize_seen_live_names(seen_live_names),
            }
            resp = await self._client.post(
                f"/executors/{self.executor_id}/execute",
                json=payload,
                timeout=self._request_timeout(timeout_seconds),
            )
            resp.raise_for_status()
            return KernelOutput.model_validate(resp.json())

    async def execute_workspace(
        self,
        code: str,
        dry_run: bool = False,
        timeout_seconds: float | None = None,
        producer_notebook_path: str | None = None,
        seen_live_names: set[tuple[str, str]] | None = None,
    ) -> KernelOutput:
        async with self._kernel_gate:
            await self._ensure_executor_id()
            payload = {
                "code": code,
                "dry_run": dry_run,
                "workspace_mode": True,
                "producer_notebook_path": producer_notebook_path,
                "seen_live_names": _serialize_seen_live_names(seen_live_names),
            }
            resp = await self._client.post(
                f"/executors/{self.executor_id}/execute",
                json=payload,
                timeout=self._request_timeout(timeout_seconds),
            )
            resp.raise_for_status()
            return KernelOutput.model_validate(resp.json())

    async def get_origin(self, name: str) -> VariableOrigin | None:
        """Fetch the sandbox's :class:`VariableOrigin` for *name*."""
        async with self._kernel_gate:
            if self.executor_id is None:
                return None
            resp = await self._client.get(
                f"/executors/{self.executor_id}/origin",
                params={"name": name},
            )
            resp.raise_for_status()
            data = resp.json()
        if data is None:
            return None
        return VariableOrigin.from_dict(data)

    async def read_workspace_file(self, path: str) -> bytes:
        async with self._kernel_gate:
            await self._ensure_executor_id()
            resp = await self._client.get(f"/executors/{self.executor_id}/files/{path}")
            if resp.status_code == 404:
                raise FileNotFoundError(path)
            resp.raise_for_status()
            return resp.content

    async def write_workspace_file(self, path: str, data: bytes) -> None:
        async with self._kernel_gate:
            await self._ensure_executor_id()
            resp = await self._client.post(
                f"/executors/{self.executor_id}/files/{path}",
                content=data,
            )
            resp.raise_for_status()

    async def delete_workspace_file(self, path: str) -> None:
        async with self._kernel_gate:
            await self._ensure_executor_id()
            resp = await self._client.delete(f"/executors/{self.executor_id}/files/{path}")
            resp.raise_for_status()

    async def list_workspace_files(self, prefix: str = "") -> list[tuple[str, int]]:
        async with self._kernel_gate:
            await self._ensure_executor_id()
            resp = await self._client.get(
                f"/executors/{self.executor_id}/files",
                params={"prefix": prefix},
            )
            resp.raise_for_status()
            rows = resp.json()
            return [(r["path"], r["size_bytes"]) for r in rows]

    async def eval(
        self,
        expr: str,
        dry_run: bool = False,
        timeout_seconds: float | None = None,
    ) -> KernelOutput:
        async with self._kernel_gate:
            await self._ensure_executor_id()
            payload = {"expr": expr, "dry_run": dry_run}
            resp = await self._client.post(
                f"/executors/{self.executor_id}/eval",
                json=payload,
                timeout=self._request_timeout(timeout_seconds),
            )
            resp.raise_for_status()
            return KernelOutput.model_validate(resp.json())

    async def execute_sql(self, sql_query: str) -> KernelOutput:
        """Sandbox HTTP API only; not part of ``BaseCodeExecutor``."""
        async with self._kernel_gate:
            await self._ensure_executor_id()
            resp = await self._client.post(
                f"/executors/{self.executor_id}/execute_sql",
                json={"sql_query": sql_query},
            )
            resp.raise_for_status()
            return KernelOutput.model_validate(resp.json())

    def fetch_kernel_summaries(self) -> list[dict[str, Any]]:
        """Return rich kernel variable summaries (JSON list) from the sandbox."""
        if self.executor_id is None:
            return []
        with httpx.Client(base_url=self.base_url, timeout=10.0) as client:
            resp = client.get(f"/executors/{self.executor_id}/locals")
            resp.raise_for_status()
            data = resp.json()
            if isinstance(data, list):
                return data
            if isinstance(data, dict):
                return [data]
            return []

    async def get(self, key: str) -> KernelOutputType | None:
        async with self._kernel_gate:
            await self._ensure_executor_id()
            resp = await self._client.get(f"/executors/{self.executor_id}/get", params={"key": key})
            resp.raise_for_status()
            return TypeAdapter(KernelOutputType).validate_python(resp.json())

    async def discard_and_close(self) -> None:
        """Delete the remote kernel (so it is not reused) and close the HTTP client."""
        eid = self.executor_id
        async with self._kernel_gate:
            if self.executor_id is not None:
                with contextlib.suppress(Exception):
                    await self._client.delete(f"/executors/{self.executor_id}")
            self.executor_id = None
        _log.info(
            "Remote kernel discarded and HTTP client closed",
            extra={"event": "remote_kernel_discarded", "executor_id": eid},
        )
        with contextlib.suppress(Exception):
            await self._client.aclose()

    async def close(self):
        """Close HTTP client only; remote executor is retained for session reuse (TTL reaper evicts)."""
        await self._client.aclose()


class CodeExecutor(_LibraryCodeExecutor):
    """In-process executor wired with the app's config-backed output factory.

    Used by tests; production paths use :class:`RemoteCodeExecutor`.
    """

    def __init__(
        self,
        cwd: str | None = None,
        *,
        session_files_dir: str | None = None,
        output_factory: _LibOutputFactory | None = None,
    ) -> None:
        from server.storage import sessions_dir

        sdir = session_files_dir or str(sessions_dir())
        factory = output_factory or get_app_output_factory()
        super().__init__(
            cwd=cwd or sdir,
            output_factory=factory,
        )


__all__ = [
    "BaseCodeExecutor",
    "CodeExecutor",
    "DataFrameObject",
    "DataFrameViewConfig",
    "DatasetRefreshRecipe",
    "ExceptionObject",
    "FigureObject",
    "KernelOutput",
    "KernelOutputType",
    "MetadataItem",
    "PrimitiveObject",
    "PrimitiveTypes",
    "PrimitiveViewConfig",
    "RefreshStatus",
    "RemoteCodeExecutor",
    "SearchViewConfig",
    "StringPaginator",
    "TablePaginator",
    "finalize_spec",
    "generate_cell_id",
    "get_app_output_factory",
    "get_llm_view_defaults",
    "get_output_header",
]
