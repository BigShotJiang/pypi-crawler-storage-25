"""Per-user model-tier metadata and quota tracking.

The single endpoint here, ``GET /api/meta/model-sets``, returns the
configured model tiers and (per user) which of them have exceeded their
daily quota. The same in-memory daily-quota counter is consumed by the
workspace message endpoint, so the increment/check helpers live alongside
the route to keep the cache key format in one place.
"""
