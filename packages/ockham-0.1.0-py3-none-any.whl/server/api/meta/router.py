"""Static product metadata endpoints."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter

from server import product

router = APIRouter(prefix="/api/meta", tags=["meta"])


# ---------------------------------------------------------------------------
# Static metadata endpoints
# ---------------------------------------------------------------------------


@router.get("/model-sets")
async def list_model_sets() -> dict[str, Any]:
    return {
        "model_sets": [{"id": k, "name": t.name, "description": t.description} for k, t in product.TIERS.items()],
        "default": product.DEFAULT_TIER,
    }
