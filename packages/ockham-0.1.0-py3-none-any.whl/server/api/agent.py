"""App wiring: build the workspace ``Agent`` for a given model."""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Any

from fastapi import Request as FastAPIRequest
from parsimony_agents.agent.agent import Agent
from parsimony_agents.agent.config import AgentGuardrails
from parsimony_agents.agent.outputs import ArtifactLlmResult, ArtifactNotFound
from parsimony_agents.execution.executor import BaseCodeExecutor, CodeExecutor

from server.api.config import config
from server.execution import RemoteCodeExecutor, get_app_output_factory
from server.product import agent_config, system_prompt

logger = logging.getLogger(__name__)


def _remote_sandbox_base_url() -> str:
    return (getattr(config, "SANDBOX_URL", None) or config.EXECUTOR_URL or "").strip()


async def _read_artifact_by_live_name(
    *,
    code_executor: BaseCodeExecutor,
    workspace_root: str,
    workspace_id: str,
    live_name: str,
    kind: str,
    options: dict[str, Any],
) -> ArtifactLlmResult:
    """Resolve ``(live_name, kind)`` to a canonical snapshot and read its bytes.

    The agent only ever types ``live_name`` + ``kind``. The host resolves
    that pair to one of:

    - ``notebooks/<live_name>.py`` for notebooks (then virtual-resolved
      to ``.ockham/notebooks/<lid>/<csha>.py`` if necessary), or
    - the latest content-addressed snapshot under
      ``.ockham/<kind>s/<lid>/<csha>.<ext>`` for dataset / chart / report.

    Failures collapse into :class:`ArtifactNotFound` with a kind tag that
    distinguishes "no curation matched" from "curation matched but the
    snapshot bytes are gone".
    """
    from server.api.workspace.artifact_llm import read_artifact_to_llm_result
    from server.api.workspace.service import (
        resolve_live_name_to_workspace_file_path,
    )

    canonical_path = await asyncio.to_thread(
        resolve_live_name_to_workspace_file_path,
        Path(workspace_root),
        kind,
        live_name,
    )
    if canonical_path is None:
        raise ArtifactNotFound(path=f"{kind}:{live_name}", kind="virtual_unresolved")

    try:
        raw = await code_executor.read_workspace_file(canonical_path)
    except FileNotFoundError as e:
        logger.warning(
            "ArtifactNotFound: %s live_name=%r resolved to %r but bytes are missing (workspace_id=%r)",
            kind,
            live_name,
            canonical_path,
            workspace_id,
        )
        raise ArtifactNotFound(path=f"{kind}:{live_name}", kind="canonical_missing") from e
    return read_artifact_to_llm_result(
        canonical_path,
        raw,
        options,
        live_name=live_name,
        artifact_kind=kind,
    )


async def get_workspace_agent(
    request: FastAPIRequest,
    model_id: str,
    workspace_id: str,
    terminal_id: str,
    *,
    workspace_root: str,
    session_cache_key: str,
    cached_executor_id: str | None = None,
) -> Agent:
    """Build the agent for one workspace terminal turn.

    The agent has no per-session file store — its ``cwd`` is the
    materialized workspace directory; the workspace tree is the source of truth.

    * If ``SANDBOX_URL`` / ``EXECUTOR_URL`` is set, use the HTTP sandbox executor
      (localhost, sidecar, or remote all share this boundary).
    * Otherwise, reuse a process-local :class:`CodeExecutor` per ``session_cache_key``.
    """
    of = get_app_output_factory()
    base = _remote_sandbox_base_url()
    code_executor: BaseCodeExecutor
    if base:
        code_executor = RemoteCodeExecutor(
            base,
            executor_id=cached_executor_id,
            request_timeout_s=config.EXECUTOR_REQUEST_TIMEOUT_S,
        )
    else:
        d: dict[str, CodeExecutor] = getattr(request.app.state, "in_process_code_executors", None)
        if d is None:
            d = {}
            request.app.state.in_process_code_executors = d
        ex = d.get(session_cache_key)
        if ex is None:
            ex = CodeExecutor(cwd=workspace_root, output_factory=of)
            d[session_cache_key] = ex
        else:
            await ex.set_cwd(workspace_root, f"ws-{workspace_id}-{terminal_id}")
        code_executor = ex

    async def _read_artifact_for_workspace(live_name: str, kind: str, options: dict[str, Any]) -> ArtifactLlmResult:
        return await _read_artifact_by_live_name(
            code_executor=code_executor,
            workspace_root=workspace_root,
            workspace_id=workspace_id,
            live_name=live_name,
            kind=kind,
            options=options,
        )

    async def _list_artifacts_for_workspace(query: str | None, kind: str | None, limit: int) -> list[dict[str, Any]]:
        # Lazy import: the service module pulls in heavy parquet/pyarrow deps
        # we do not need until the tool is actually invoked.
        from server.api.workspace.service import list_workspace_artifacts_in_tree

        return await list_workspace_artifacts_in_tree(
            Path(workspace_root),
            query=query,
            kind=kind,
            limit=limit,
        )

    agent = Agent(
        model_config=agent_config(model_id),
        instructions=system_prompt().strip(),
        connectors=getattr(request.app.state, "connectors", None),
        code_executor=code_executor,
        read_artifact_fn=_read_artifact_for_workspace,
        list_artifacts_fn=_list_artifacts_for_workspace,
        output_factory=of,
        guardrails=AgentGuardrails(
            max_iterations=config.OCKHAM_MAX_ITERATIONS,
            max_execution_time_s=config.OCKHAM_MAX_EXECUTION_TIME_S,
            llm_timeout_s=config.OCKHAM_LLM_TIMEOUT_S,
            llm_max_retries=config.OCKHAM_LLM_MAX_RETRIES,
            tool_timeout_s=config.OCKHAM_TOOL_TIMEOUT_S,
        ),
        session_id=f"ws-{workspace_id}-{terminal_id}",
        file_store=None,
    )
    return agent
