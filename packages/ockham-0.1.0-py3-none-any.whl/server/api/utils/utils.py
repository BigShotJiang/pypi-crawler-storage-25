"""Utility helpers for the API layer.

Model, prompt, and example configuration now lives in:
- ``server.llm`` — LLM models and model sets
- ``server.prompts`` — system prompts
- ``server.examples`` — UI examples
"""
