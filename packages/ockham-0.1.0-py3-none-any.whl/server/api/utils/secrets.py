import os
from abc import ABC, abstractmethod
from pathlib import Path

from dotenv import load_dotenv

from server.core.monitoring import get_logger

logger = get_logger("SYSTEM")


class SecretStore(ABC):
    @abstractmethod
    def get_secret(self, secret_name: str) -> str | None:
        """Get a secret by name. Returns None if not found."""


class EnvSecretStore(SecretStore):
    def __init__(self):
        load_dotenv(override=False)

    def get_secret(self, secret_name: str) -> str | None:
        return os.getenv(secret_name.upper())


class FileSecretStore(SecretStore):
    def __init__(self, base_path: str = "/usr/local/secrets"):
        self.base_path = Path(base_path)

    def get_secret(self, secret_name: str) -> str | None:
        """
        Get a secret from the file system.

        Note: Converts secret_name to lowercase for Snowflake compatibility.

        Returns:
            The secret string, or None if the secret doesn't exist
        """
        secret_path = self.base_path / secret_name.lower() / "secret_string"
        try:
            with open(secret_path) as f:
                return f.read().strip()
        except FileNotFoundError:
            logger.warning(f"Secret '{secret_name}' not found at {secret_path}")
            return None


def create_secret_store() -> SecretStore:
    """
    Create a secret store instance based on environment.

    Returns:
        SecretStore instance (FileSecretStore or EnvSecretStore)
    """
    env = os.getenv("SECRET_STORE", None)
    if env == "file":
        return FileSecretStore()
    else:
        return EnvSecretStore()


# Singleton secret store instance for simplicity across the app
secret_store = create_secret_store()
