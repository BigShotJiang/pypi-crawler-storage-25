"""Resolve a notebook working-copy path to its current ``logical_id``.

Notebooks have *slug-based* identity with a curation indirection:

- ``logical_id`` is allocated once at first creation, derived from the
  initial ``live_name`` (``notebooks/foo.py`` → ``"foo"``).
- ``live_name`` lives in curation and is freely editable. Renaming a
  notebook = updating ``curation.live_name``; ``logical_id`` stays put,
  storage stays at ``.ockham/notebooks/<original_slug>/``, and
  ``log.jsonl`` continues across the rename. Same property the other
  four kinds get from their hash-based logical_ids.

This module exists so the agent can look up the right ``logical_id``
when ``return_notebook("notebooks/<live_name>.py", ...)`` runs *after* a rename:
without the lookup, the agent would derive a fresh slug from the new
path and split history. With the lookup, the existing curation's
``logical_id`` wins.

No allocator, no flock — slug derivation is deterministic, so two
concurrent first-time persists for the same path produce the same
``logical_id`` and identical curation content (last-writer-wins is
safe). Collision handling kicks in only when the path-derived slug is
already taken by a *different* (renamed) curation; we suffix the slug
with a counter to keep ``logical_id`` unique. That's rare in practice
(would only happen if the user renames a notebook and then creates a
new one with the original name).
"""

from __future__ import annotations

import asyncio
import json

from parsimony_agents.identity import LiveNameCollisionError, notebook_logical_id

from server.api.workspace.storage import workspace_local_tree_path

__all__ = ("resolve_notebook_logical_id",)


async def resolve_notebook_logical_id(
    user_id: str,
    workspace_id: str,
    path: str,
    *,
    seen_live_names: set[tuple[str, str]] | None = None,
) -> str:
    """Return the ``logical_id`` for ``path`` honouring existing curations.

    1. Scan ``.ockham/notebooks/*/curation.json`` for one whose
       ``live_name`` matches the path's basename. Hit ⇒ either return its
       ``logical_id`` (post-rename continuation) or raise
       :class:`LiveNameCollisionError` if the calling terminal has not
       interacted with that artifact this conversation (see below).
    2. No live_name match: candidate slug is the path basename. If that
       slug is already taken by a different curation (rare collision),
       suffix with ``_2``, ``_3``, … until unique.

    Cross-terminal gate
    -------------------
    ``seen_live_names`` carries the ``(kind, live_name)`` pairs this
    terminal has touched in the current conversation. When the path's
    ``live_name`` matches an existing curation:

    - ``seen_live_names is None``: legacy mode. Skip the gate; return
      the existing ``logical_id`` (silent continuation). Used by host
      paths that run downstream of a tool that already gated.
    - Otherwise: check ``("notebook", live_name) in seen_live_names``.
      If yes ⇒ continuation. If no ⇒ raise
      :class:`LiveNameCollisionError` — a sibling terminal owns the
      live_name and the agent must explicitly ``read_artifact`` it
      before writing.

    O(N) in the number of notebooks per workspace; fine for N ≤ 200.
    """
    return await asyncio.to_thread(_resolve_sync, user_id, workspace_id, path, seen_live_names)


def _resolve_sync(
    user_id: str,
    workspace_id: str,
    path: str,
    seen_live_names: set[tuple[str, str]] | None,
) -> str:
    candidate = notebook_logical_id(path)  # raises ValueError if path malformed
    root = workspace_local_tree_path(user_id, workspace_id) / ".ockham" / "notebooks"
    if not root.is_dir():
        return candidate

    existing_lids: set[str] = set()
    for entry in root.iterdir():
        if not entry.is_dir():
            continue
        curation_file = entry / "curation.json"
        if not curation_file.is_file():
            continue
        try:
            data = json.loads(curation_file.read_bytes().decode("utf-8"))
        except (OSError, json.JSONDecodeError, UnicodeDecodeError):
            continue
        if data.get("kind") != "notebook":
            continue
        lid = entry.name
        existing_lids.add(lid)
        if data.get("live_name") == candidate:
            # Cross-terminal gate. ``None`` skips for legacy/persist callers.
            if seen_live_names is not None and ("notebook", candidate) not in seen_live_names:
                raise LiveNameCollisionError(
                    live_name=candidate,
                    existing_logical_id=lid,
                    kind="notebook",
                )
            return lid  # post-rename match — keep history continuous

    if candidate not in existing_lids:
        return candidate

    # Collision: candidate slug is taken by a different (renamed) curation.
    counter = 2
    while f"{candidate}_{counter}" in existing_lids:
        counter += 1
    return f"{candidate}_{counter}"
