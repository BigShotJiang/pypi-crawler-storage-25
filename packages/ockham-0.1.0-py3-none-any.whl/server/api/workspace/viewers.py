"""Viewer registry: the only ``kind`` dispatch in the server.

Each workspace artifact ``kind`` (``dataset``, ``chart``, ``notebook``,
``utility_output``, future ``report``, ``pdf``, ...) registers exactly
one entry here. The registry binds three things together:

* The wire ``kind`` discriminator on :class:`server.api.streaming.FileRefChunk`.
* The file extensions that map to this kind on disk.
* The pure ``(blob, rel) -> {kind, metadata, payload}`` function that
  the ``GET /workspaces/{wid}/view/{path}`` endpoint serves.

Adding a new kind is one :func:`register_viewer` call. The wire model
does not change. The streaming dispatcher does not change. Adding a
viewer that doesn't need a structured payload (e.g. raw markdown,
arbitrary text) is the same call with ``payload_fn=None`` — the
endpoint declines to materialize a structured payload and the frontend
viewer reads the raw bytes directly via the file endpoint.

Invariant: every ``kind`` emitted on the wire MUST appear in
:data:`VIEWER_REGISTRY` — :func:`require_kind` enforces this at
emission time so an unrendered chunk is unrepresentable.
"""

from __future__ import annotations

import ast as _ast
import io
import json
import logging
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from parsimony_agents.agent.outputs import UtilityToolOutput
from parsimony_agents.artifacts import Chart, Dataset
from parsimony_agents.chart_io import deserialize_chart
from parsimony_agents.dataset_io import deserialize_dataset
from parsimony_agents.execution import ExceptionObject, KernelOutput
from parsimony_agents.identity import ArtifactRef
from parsimony_agents.notebook import Script, ScriptStepPreview
from parsimony_agents.notebook_io import (
    decode_notebook_state,
    deserialize_notebook,
    load_notebook_state,
    notebook_state_cache_key,
)
from pydantic import ValidationError

from server.api.workspace.file_ref_path import encode_path_for_file_ref
from server.api.workspace.table_data import dataframe_rows

logger = logging.getLogger(__name__)

NotebookStateLoader = Callable[[Script], bytes | None]
ViewerFn = Callable[..., dict[str, Any]]
LlmSummaryFn = Callable[[bytes, str], str]
LlmReadFn = Callable[[bytes, str, str], str]
"""``llm_read_fn(blob, rel_path, mode)`` where *mode* is ``summary`` or ``full``."""


@dataclass(frozen=True)
class ViewerSpec:
    """One ``kind`` registration in the viewer registry."""

    kind: str
    extensions: tuple[str, ...]
    payload_fn: ViewerFn | None
    llm_summary_fn: LlmSummaryFn | None = None
    llm_read_fn: LlmReadFn | None = None


VIEWER_REGISTRY: dict[str, ViewerSpec] = {}


class UnknownArtifactExtension(ValueError):
    """Raised when ``viewer_payload_for_path`` has no registered viewer for ``path``."""


def register_viewer(
    *,
    kind: str,
    extensions: tuple[str, ...],
    payload_fn: ViewerFn | None,
    llm_summary_fn: LlmSummaryFn | None = None,
    llm_read_fn: LlmReadFn | None = None,
) -> None:
    """Register a viewer for ``kind``.

    Idempotent within a single registration call: re-registering the
    same kind raises ``ValueError`` so accidental shadowing is loud.
    """

    if kind in VIEWER_REGISTRY:
        raise ValueError(f"viewer already registered for kind {kind!r}")
    if not extensions:
        raise ValueError(f"viewer for {kind!r} must declare at least one extension")
    VIEWER_REGISTRY[kind] = ViewerSpec(
        kind=kind,
        extensions=tuple(extensions),
        payload_fn=payload_fn,
        llm_summary_fn=llm_summary_fn,
        llm_read_fn=llm_read_fn,
    )


def is_known_kind(kind: str) -> bool:
    return kind in VIEWER_REGISTRY


def require_kind(kind: str) -> None:
    """Validate ``kind`` is registered. Raises :class:`KeyError` otherwise.

    Called at the wire boundary (FileRefChunk emission) so an unrendered
    kind is unrepresentable on the stream.
    """

    if kind not in VIEWER_REGISTRY:
        raise KeyError(
            f"unknown FileRefChunk kind {kind!r}; register a viewer in "
            "server.api.workspace.viewers before emitting this kind."
        )


def viewer_for_kind(kind: str) -> ViewerSpec | None:
    return VIEWER_REGISTRY.get(kind)


def file_ref(path: str) -> str:
    """Encode a workspace-relative *path* as the canonical cross-reference string.

    All metadata fields that point at another workspace artifact MUST go
    through this helper so the frontend ``MetadataRenderer`` recognises them
    as navigation targets and renders ``FileRefPill``. The convention is
    value-shaped (``file://./<path>``), not key-name-shaped, so renames
    of metadata keys cannot silently break navigation. The path is
    percent-encoded (``/`` kept); spaces and special characters are safe
    in chat and metadata strings.
    """

    return f"file://./{encode_path_for_file_ref(path)}"


def viewer_for_path(rel: str) -> ViewerSpec | None:
    """Return the viewer spec whose extensions match ``rel`` (longest suffix wins)."""

    best: ViewerSpec | None = None
    best_len = -1
    for spec in VIEWER_REGISTRY.values():
        for ext in spec.extensions:
            if rel.endswith(ext) and len(ext) > best_len:
                best = spec
                best_len = len(ext)
    return best


# ---------------------------------------------------------------------------
# Built-in viewers
# ---------------------------------------------------------------------------


def _artifact_dict(artifact: Any, *, path: str | None = None) -> dict[str, Any]:
    """Serialize the artifact-level envelope (logical_id, content_sha, curation, refs).

    ``path`` is the snapshot's workspace path — when provided and
    canonical (``.ockham/<kind>s/<logical_id>/<content_sha>.<ext>``), the
    parsed ref overrides the artifact's in-memory ``logical_id`` /
    ``content_sha``. This patches the chicken-and-egg in
    :func:`persist_return_artifact` where the bytes are serialised
    *before* ``content_sha`` is set, leaving the embedded curation with
    an empty hash.

    The lineage refs are read directly off the artifact (Dataset has
    ``notebook_refs`` + ``source_refs``; Chart adds ``notebook_ref`` +
    ``source_dataset_refs``) — call sites no longer plumb them through
    explicit kwargs. The route handler enriches each typed ref with
    ``workspace_file_path`` and a best-effort ``display_name`` so the
    panel renders human pills instead of content-sha basenames.
    """
    parsed = ArtifactRef.from_workspace_file_path(path) if path else None
    logical_id = parsed.logical_id if parsed else getattr(artifact, "logical_id", "")
    content_sha = parsed.content_sha if parsed else getattr(artifact, "content_sha", "")
    out: dict[str, Any] = {
        "logical_id": logical_id,
        "content_sha": content_sha,
        "title": artifact.title,
        "description": artifact.description,
        "tags": list(artifact.tags),
        "notes": list(artifact.notes),
    }
    if isinstance(artifact, Dataset):
        out["notebook_refs"] = [r.to_dict() for r in artifact.notebook_refs]
        out["source_refs"] = [r.to_dict() for r in artifact.source_refs]
    elif isinstance(artifact, Chart):
        out["notebook_refs"] = []
        out["notebook_ref"] = artifact.notebook_ref.to_dict() if artifact.notebook_ref else None
        out["source_dataset_refs"] = [r.to_dict() for r in artifact.source_dataset_refs]
        out["source_refs"] = [r.to_dict() for r in artifact.source_refs]
    else:
        out["notebook_refs"] = []
        out["source_refs"] = []
    return out


def _source_dump(source: Any) -> dict[str, Any]:
    """Wire-safe Provenance projection.

    With the dual-identity refactor, the data_object pointer no longer
    lives on Provenance — it surfaces as a typed ``ArtifactRef`` on the
    fetch_log entry instead. Provenance carries only its declarative
    fields (source, params, fetched_at, properties); the ref-as-file
    decoration happens on the fetch_log path now.
    """
    return source.safe_dump()


def _dataset_payload(blob: bytes, _path: str, **_: Any) -> dict[str, Any]:
    """Render a parquet artifact: ``"dataset"`` when it has curation, ``"data_object"`` for raw fetch snapshots."""
    result, dataset = deserialize_dataset(blob)
    df = result.df
    payload = {
        "row_count": int(len(df)),
        "schema": [{"name": str(col), "dtype": str(df[col].dtype)} for col in df.columns],
        "rows": dataframe_rows(df),
    }
    if _looks_like_curated_dataset(dataset) or not getattr(result.provenance, "source", ""):
        return {"kind": "dataset", "artifact": _artifact_dict(dataset, path=_path), "payload": payload}
    return {"kind": "data_object", "provenance": _source_dump(result.provenance), "payload": payload}


def _looks_like_curated_dataset(dataset: Any) -> bool:
    """True iff *dataset* carries any curation field or non-empty refs."""
    return bool(
        getattr(dataset, "title", "")
        or getattr(dataset, "description", "")
        or list(getattr(dataset, "tags", []) or [])
        or list(getattr(dataset, "notes", []) or [])
        or list(getattr(dataset, "notebook_refs", []) or [])
        or list(getattr(dataset, "source_refs", []) or [])
    )


def _chart_payload(blob: bytes, _path: str, **_: Any) -> dict[str, Any]:
    chart, spec = deserialize_chart(blob)
    return {"kind": "chart", "artifact": _artifact_dict(chart, path=_path), "payload": {"spec": spec}}


def _wire_notebook_preview_steps(steps: list[ScriptStepPreview]) -> list[dict[str, Any]]:
    """``GET /view`` step tree for the notebook UI: text hierarchy only, no code."""

    return [
        {
            "text": s.text,
            "level": s.level,
            "children": _wire_notebook_preview_steps(s.children),
        }
        for s in steps
    ]


def _extract_module_docstring(code: str) -> str | None:
    """Return the module-level docstring from *code*, or ``None`` if absent."""
    try:
        return _ast.get_docstring(_ast.parse(code))
    except SyntaxError:
        return None


def _notebook_metadata(script: Script) -> dict[str, Any]:
    """Metadata for notebook ``GET /view``; includes sidecar path for path-local client invalidation."""
    return {
        "file_path": file_ref(script.path),
        "state_cache_relpath": f".ockham/{notebook_state_cache_key(script)}",
    }


def _notebook_payload(
    blob: bytes,
    path: str,
    *,
    notebook_state_root: Path | str | None = None,
    notebook_state_loader: NotebookStateLoader | None = None,
) -> dict[str, Any]:
    script = deserialize_notebook(blob, path=path)
    preview = script.to_preview()
    steps = _wire_notebook_preview_steps(preview.steps)
    cached_output = _load_cached_output(script, notebook_state_root, notebook_state_loader)
    outputs_payload: dict[str, Any] | None = None
    if cached_output is not None:
        outputs_payload = cached_output.to_frontend_dict()
        # Surface the captured exception (if any) at the top level so the
        # NotebookViewer's error banner can render it. KernelOutput.to_frontend_dict
        # only emits the raw outputs[]/fetch_log; it does not surface a summary.
        outputs_payload["error_message"] = _notebook_error_message(cached_output)
    return {
        "kind": "notebook",
        "metadata": _notebook_metadata(script),
        "payload": {
            "code": script.code,
            "docstring": _extract_module_docstring(script.code),
            "steps": steps,
            "outputs": outputs_payload,
        },
    }


def _notebook_error_message(output: KernelOutput) -> str | None:
    """First captured ExceptionObject value in *output*, or ``None`` if the run succeeded.

    Returns the full exception text (multi-line traceback included) so the viewer can
    render the complete failure context — clipping to a one-liner happens only at the
    ScriptPreview level, where the value is used as a label in higher-level summaries.
    """
    for o in output.outputs:
        if isinstance(o, ExceptionObject):
            return o.value
    return None


def _dataset_llm_summary(blob: bytes, path: str) -> str:
    result, dataset = deserialize_dataset(blob)
    n = len(result.df)
    title = dataset.title.strip() or path
    return f"{title} — {n} rows — {path}"


def _dataset_llm_read(blob: bytes, path: str, mode: str) -> str:
    from server.api.workspace.artifact_projection import ArtifactReadRequest
    from server.api.workspace.artifact_read_projections import dataset_read_projection

    m = (mode or "summary").strip().lower()
    view = "full" if m == "full" else "summary"
    return dataset_read_projection(blob, path, ArtifactReadRequest(path=path, view=view, locator=None)).text


def _chart_llm_summary(blob: bytes, path: str) -> str:
    chart, _spec = deserialize_chart(blob)
    title = chart.title.strip() or path
    nb = chart.notebook_ref.workspace_file_path if chart.notebook_ref else ""
    extra = f" — {file_ref(nb)}" if nb else ""
    return f"{title}{extra} — {path}"


def _chart_llm_read(blob: bytes, path: str, mode: str) -> str:
    from server.api.workspace.artifact_projection import ArtifactReadRequest
    from server.api.workspace.artifact_read_projections import chart_read_projection

    m = (mode or "summary").strip().lower()
    view = "full" if m == "full" else "summary"
    return chart_read_projection(blob, path, ArtifactReadRequest(path=path, view=view, locator=None)).text


def _notebook_llm_summary(blob: bytes, path: str) -> str:
    script = deserialize_notebook(blob, path=path)
    doc = (_extract_module_docstring(script.code) or "").strip()
    head = doc.split("\n", 1)[0][:220] if doc else "(no module docstring)"
    return f"{path} — {head}"


def _notebook_llm_read(blob: bytes, path: str, mode: str) -> str:
    from server.api.workspace.artifact_projection import ArtifactReadRequest
    from server.api.workspace.artifact_read_projections import notebook_read_projection

    m = (mode or "summary").strip().lower()
    view = "full" if m == "full" else "summary"
    return notebook_read_projection(blob, path, ArtifactReadRequest(path=path, view=view, locator=None)).text


def _utility_llm_summary(blob: bytes, path: str) -> str:
    text = blob.decode("utf-8")
    try:
        uo = UtilityToolOutput.model_validate_json(text)
        msg = (uo.ui_message_completed or uo.ui_message or "utility output").strip()
        return f"{path} — {msg[:200]}"
    except ValidationError:
        return f"{path} — utility output (legacy format)"


def _utility_llm_read(blob: bytes, path: str, mode: str) -> str:
    from server.api.workspace.artifact_projection import ArtifactReadRequest
    from server.api.workspace.artifact_read_projections import utility_read_projection

    m = (mode or "summary").strip().lower()
    view = "full" if m == "full" else "summary"
    return utility_read_projection(blob, path, ArtifactReadRequest(path=path, view=view, locator=None)).text


def _utility_output_payload(blob: bytes, _path: str, **_: Any) -> dict[str, Any]:
    """Structured payload for ``.output.json`` snapshots.

    Prefers the canonical on-disk body (round-trippable
    :class:`UtilityToolOutput` JSON). Legacy files written with
    :meth:`UtilityToolOutput.to_frontend_dict` (lossy nested shapes) are
    served with ``payload`` = parsed JSON and a best-effort ``metadata`` strip.
    """

    text = blob.decode("utf-8")
    try:
        uo = UtilityToolOutput.model_validate_json(text)
    except ValidationError:
        logger.warning("Legacy utility output JSON at %s; serving without full model round-trip", _path)
        document: Any = json.loads(text)
        return {
            "kind": "utility_output",
            "metadata": {
                "ui_message": document.get("ui_message", "") if isinstance(document, dict) else "",
                "ui_message_completed": document.get("ui_message_completed") if isinstance(document, dict) else None,
            },
            "payload": document,
        }
    return {
        "kind": "utility_output",
        "metadata": {
            "ui_message": uo.ui_message,
            "ui_message_completed": uo.ui_message_completed,
        },
        "payload": uo.model_dump(mode="json"),
    }


def _load_cached_output(
    script: Script,
    notebook_state_root: Path | str | None,
    notebook_state_loader: NotebookStateLoader | None,
):
    """Resolve runtime state for ``script`` from whichever source was supplied."""

    if notebook_state_loader is not None:
        blob = notebook_state_loader(script)
        if blob is None:
            return None
        return decode_notebook_state(blob, script=script)
    if notebook_state_root is not None:
        return load_notebook_state(script, notebook_state_root)
    return None


# --- PDF / image / text / no-preview (GET /view + read_artifact) ----------------


_TEXT_FILE_EXTENSIONS: frozenset[str] = frozenset(
    {
        ".txt",
        ".log",
        ".csv",
        ".tsv",
        ".json",
        ".yml",
        ".yaml",
        ".toml",
        ".xml",
        ".env",
        ".sh",
        ".bash",
        ".zsh",
        ".ini",
        ".cfg",
        ".conf",
        ".lock",
        ".css",
        ".scss",
        ".less",
        ".html",
        ".htm",
        ".rst",
        ".mdx",
        ".gitignore",
        ".gitattributes",
        ".dockerignore",
        ".editorconfig",
        ".sql",
        ".r",
        ".c",
        ".h",
        ".cpp",
        ".hpp",
        ".go",
        ".rs",
        ".kt",
        ".swift",
        ".vue",
        ".svelte",
        ".tsx",
        ".jsx",
        ".mjs",
        ".cjs",
        ".ts",
        ".java",
        ".ipynb",
    }
)

_NO_PREVIEW_EXTS: frozenset[str] = frozenset(
    {
        ".xlsx",
        ".xlsm",
        ".xlsb",
        ".xls",
        ".pptx",
        ".pptm",
        ".ppt",
        ".potx",
        ".odp",
        ".odt",
        ".ods",
        ".docx",
        ".docm",
        ".doc",
        ".dotx",
        ".zip",
        ".7z",
        ".rar",
        ".tar",
        ".gz",
        ".tgz",
        ".bz2",
        ".xz",
        ".zst",
        ".br",
        ".mp4",
        ".m4v",
        ".webm",
        ".mkv",
        ".avi",
        ".mov",
        ".wmv",
        ".flv",
        ".mp3",
        ".m4a",
        ".aac",
        ".flac",
        ".ogg",
        ".opus",
        ".wav",
        ".aiff",
        ".aif",
        ".bin",
        ".exe",
        ".dll",
        ".so",
        ".dylib",
        ".o",
        ".a",
        ".class",
        ".jar",
        ".war",
        ".iso",
        ".dmg",
        ".img",
        ".vmdk",
        ".qcow2",
        ".ttf",
        ".otf",
        ".woff",
        ".woff2",
        ".eot",
        ".psd",
        ".ai",
        ".eps",
        ".sqlite",
        ".db",
        # tarballs / compound (longest first via sort below)
        ".tar.gz",
        ".tar.bz2",
        ".tar.xz",
    }
)
NO_PREVIEW_EXTENSIONS: tuple[str, ...] = tuple(sorted(_NO_PREVIEW_EXTS, key=len, reverse=True))


def _text_payload(blob: bytes, path: str, **_: Any) -> dict[str, Any]:
    lines = 1 + blob.count(b"\n")
    return {
        "kind": "text",
        "metadata": {"path": file_ref(path), "line_count": lines},
        "payload": {},
    }


def _pdf_payload(blob: bytes, path: str, **_: Any) -> dict[str, Any]:
    from pypdf import PdfReader

    data = io.BytesIO(blob)
    reader = PdfReader(data)
    n = len(reader.pages)
    title = None
    try:
        meta = reader.metadata
        if meta is not None:
            title = meta.get("/Title")
            if title and isinstance(title, str):
                title = title.strip() or None
    except Exception:
        logger.debug("pdf metadata for %s", path, exc_info=True)
    return {
        "kind": "pdf",
        "metadata": {"path": file_ref(path), "page_count": n, "title": title},
        "payload": {},
    }


def _image_payload(blob: bytes, path: str, **_: Any) -> dict[str, Any]:
    return {
        "kind": "image",
        "metadata": {"path": file_ref(path), "size_bytes": len(blob)},
        "payload": {},
    }


def _no_preview_payload(
    blob: bytes,
    path: str,
    **_: Any,
) -> dict[str, Any]:
    p = Path(path)
    return {
        "kind": "no_preview",
        "metadata": {
            "path": file_ref(path),
            "suffix": p.suffix.lower() or None,
        },
        "payload": {"size_bytes": len(blob)},
    }


def _pdf_llm_summary(blob: bytes, path: str) -> str:
    from pypdf import PdfReader

    r = PdfReader(io.BytesIO(blob))
    t = f"{path} — {len(r.pages)} page(s)"
    if r.metadata and r.metadata.get("/Title"):
        t += f" — {r.metadata.get('/Title')}"
    return t


def _pdf_llm_read(blob: bytes, path: str, mode: str) -> str:
    from pypdf import PdfReader

    m = (mode or "summary").strip().lower()
    cap = 32_000 if m == "full" else 8_000
    r = PdfReader(io.BytesIO(blob))
    parts: list[str] = []
    for i, p in enumerate(r.pages):
        if i >= 20 and m != "full":
            break
        parts.append(p.extract_text() or "")
    text = "\n\n".join(parts)
    if len(text) > cap:
        return text[:cap] + "\n…\n[truncated]"
    return f"<pdf path={path}>\n{text}\n</pdf>"


def _image_llm_summary(blob: bytes, path: str) -> str:
    return f"{path} — image ({len(blob)} bytes) — not inlined as base64; use read_artifact or open in workspace"


def _image_llm_read(blob: bytes, path: str, mode: str) -> str:  # noqa: ARG001
    return _image_llm_summary(blob, path)


def _text_llm_summary(_blob: bytes, path: str) -> str:
    return f"{path} — text file"


def _text_llm_read(blob: bytes, path: str, mode: str) -> str:
    m = (mode or "summary").strip().lower()
    cap = 100_000 if m == "full" else 12_000
    try:
        text = blob.decode("utf-8")
    except UnicodeDecodeError:
        text = blob.decode("utf-8", errors="replace")
    if len(text) > cap:
        return text[:cap] + "\n…\n[truncated]"
    return f"<text path={path}>\n{text}\n</text>"


def _decode_report_source(blob: bytes, path: str) -> str:
    try:
        return blob.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise ValueError(f"report source at {path} is not valid UTF-8") from exc


def _report_projection(blob: bytes, path: str) -> tuple[str, str, list[str], list[dict[str, str]]]:
    """Pure projection over a report snapshot: (body, title, formats, refs).

    Title comes from the snapshot's ``parsimony:`` frontmatter (the
    body has no leading H1). Embedded refs come from the snapshot's
    frozen pin map (also in YAML frontmatter), not from re-walking body
    URIs — the pin map is the authoritative ``live_name → ArtifactRef``
    binding for this snapshot.
    """
    from parsimony_agents.report_format import parse_snapshot

    text = _decode_report_source(blob, path)
    snap = parse_snapshot(text)
    title = snap.title or Path(path).stem

    refs: list[dict[str, str]] = []
    seen: set[str] = set()
    for _live_name, ref in sorted(snap.pins.items()):
        rel = ref.workspace_file_path
        if rel in seen:
            continue
        seen.add(rel)
        refs.append({"path": rel, "kind": ref.kind, "file_ref": file_ref(rel)})
    return snap.body, title, snap.formats, refs


def _report_payload(blob: bytes, path: str, **_: Any) -> dict[str, Any]:
    """Wire payload for ``kind="report"``.

    Pure projection over the snapshot bytes. Exposes:

    - ``metadata`` — fast scalars the ViewerHeader / shell needs without
      a deep parse (title, byte count, available export formats, count
      of embedded refs).
    - ``artifact`` — the curation envelope (mirrors Dataset / Chart
      shape; ``embedded_refs`` carries the snapshot's frozen pin map as
      typed ref triplets so :func:`enrich_artifact_envelope` can decorate
      each one with ``workspace_file_path`` + ``display_name``).
    - ``payload`` — the renderable surface (body source + legacy refs
      list for backwards compat with consumers that read ``payload.refs``).

    Curation fields on ``artifact`` are placeholders here; the live
    overlay in :func:`enrich_artifact_envelope` reads
    ``curation.json`` and fills in the current title / description /
    tags / notes / live_name. This keeps curation edits visible without
    needing to republish the snapshot.
    """
    from parsimony_agents.identity import ArtifactRef
    from parsimony_agents.report_format import parse_snapshot

    text = _decode_report_source(blob, path)
    snap = parse_snapshot(text)
    title = snap.title or Path(path).stem

    # Legacy projection-style refs (path, kind, file_ref) — kept on
    # ``payload.refs`` for the existing summary consumer.
    refs: list[dict[str, str]] = []
    seen: set[str] = set()
    for _live_name, ref in sorted(snap.pins.items()):
        rel = ref.workspace_file_path
        if rel in seen:
            continue
        seen.add(rel)
        refs.append({"path": rel, "kind": ref.kind, "file_ref": file_ref(rel)})

    # Typed embedded refs for the metadata tab. Identity-only here;
    # enrichment adds workspace_file_path + display_name.
    embedded_refs = [ref.to_dict() for _live_name, ref in sorted(snap.pins.items())]

    parsed_path_ref = ArtifactRef.from_workspace_file_path(path)
    artifact_envelope: dict[str, Any] = {
        "logical_id": parsed_path_ref.logical_id if parsed_path_ref else "",
        "content_sha": parsed_path_ref.content_sha if parsed_path_ref else "",
        # Placeholders — enrich_artifact_envelope overlays live curation.
        "title": title,
        "subtitle": snap.subtitle,
        "description": "",
        "tags": [],
        "notes": [],
        # Report-specific envelope fields.
        "notebook_refs": [],
        "source_refs": [],
        "embedded_refs": embedded_refs,
    }

    return {
        "kind": "report",
        "metadata": {
            "path": file_ref(path),
            "title": title,
            "subtitle": snap.subtitle,
            "byte_count": len(blob),
            "ref_count": len(refs),
            "available_formats": snap.formats,
        },
        "artifact": artifact_envelope,
        "payload": {
            "source": snap.body,
            "refs": refs,
        },
    }


def _report_llm_summary(blob: bytes, path: str) -> str:
    _body, title, formats, refs = _report_projection(blob, path)
    if refs:
        counts: dict[str, int] = {}
        for r in refs:
            counts[r["kind"]] = counts.get(r["kind"], 0) + 1
        ref_phrase = ", ".join(f"{n} {k}{'s' if n != 1 else ''}" for k, n in sorted(counts.items()))
        return f"{title} — references {ref_phrase} — formats {','.join(formats)} — {path}"
    return f"{title} — formats {','.join(formats)} — {path}"


def _report_llm_read(blob: bytes, path: str, mode: str) -> str:
    body, _title, _formats, _refs = _report_projection(blob, path)
    m = (mode or "summary").strip().lower()
    if m == "full":
        cap = 100_000
        text = body if len(body) <= cap else body[:cap] + "\n…\n[truncated]"
        return f"<report path={path}>\n{text}\n</report>"
    summary = _report_llm_summary(blob, path)
    paragraphs = [p.strip() for p in body.split("\n\n") if p.strip() and not p.lstrip().startswith("#")]
    lead = paragraphs[0] if paragraphs else ""
    if len(lead) > 600:
        lead = lead[:600] + "…"
    return f"{summary}\n\n{lead}" if lead else summary


def _no_preview_llm_summary(_blob: bytes, path: str) -> str:
    p = Path(path)
    return f"{path} — no structured preview in the IDE (suffix {p.suffix!r})"


def _no_preview_llm_read(blob: bytes, path: str, mode: str) -> str:  # noqa: ARG001
    p = Path(path)
    if len(blob) < 1_200:
        return f"{path} — binary ({len(blob)} bytes); preview not available. Use the Python shell or a conversion tool."
    return (
        f"{path} — binary ({len(blob)} bytes), suffix {p.suffix!r}; "
        f"not expanded. Use read_artifact (summary) or load in the kernel."
    )


def viewer_payload_for_path(
    path: str,
    blob: bytes,
    *,
    notebook_state_root: Path | str | None = None,
    notebook_state_loader: NotebookStateLoader | None = None,
) -> dict[str, Any]:
    """Build the viewer payload for *path* from its raw *blob*.

    If no registered viewer matches, returns the same shape as
    :func:`_no_preview_payload` (so ``GET /view`` never 400s for an unknown
    extension).
    """

    if notebook_state_loader is not None and notebook_state_root is not None:
        raise ValueError("viewer_payload_for_path: pass at most one of notebook_state_loader / notebook_state_root")

    spec = viewer_for_path(path)
    if spec is not None and spec.payload_fn is not None:
        return spec.payload_fn(
            blob,
            path,
            notebook_state_root=notebook_state_root,
            notebook_state_loader=notebook_state_loader,
        )
    return _no_preview_payload(
        blob,
        path,
        notebook_state_root=notebook_state_root,
        notebook_state_loader=None,
    )


# ---------------------------------------------------------------------------
# Built-in registrations: order doesn't matter (longest-extension wins).
# ---------------------------------------------------------------------------


register_viewer(
    kind="dataset",
    extensions=(".parquet",),
    payload_fn=_dataset_payload,
    llm_summary_fn=_dataset_llm_summary,
    llm_read_fn=_dataset_llm_read,
)
register_viewer(
    kind="chart",
    extensions=(".vl.json",),
    payload_fn=_chart_payload,
    llm_summary_fn=_chart_llm_summary,
    llm_read_fn=_chart_llm_read,
)
register_viewer(
    kind="notebook",
    extensions=(".py",),
    payload_fn=_notebook_payload,
    llm_summary_fn=_notebook_llm_summary,
    llm_read_fn=_notebook_llm_read,
)
register_viewer(
    kind="utility_output",
    extensions=(".output.json",),
    payload_fn=_utility_output_payload,
    llm_summary_fn=_utility_llm_summary,
    llm_read_fn=_utility_llm_read,
)
register_viewer(
    kind="pdf",
    extensions=(".pdf",),
    payload_fn=_pdf_payload,
    llm_summary_fn=_pdf_llm_summary,
    llm_read_fn=_pdf_llm_read,
)
register_viewer(
    kind="image",
    extensions=(".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg", ".bmp", ".ico", ".avif", ".tiff", ".tif"),
    payload_fn=_image_payload,
    llm_summary_fn=_image_llm_summary,
    llm_read_fn=_image_llm_read,
)
register_viewer(
    kind="report",
    extensions=(".qmd",),
    payload_fn=_report_payload,
    llm_summary_fn=_report_llm_summary,
    llm_read_fn=_report_llm_read,
)
register_viewer(
    kind="text",
    extensions=tuple(sorted(_TEXT_FILE_EXTENSIONS, key=len, reverse=True)),
    payload_fn=_text_payload,
    llm_summary_fn=_text_llm_summary,
    llm_read_fn=_text_llm_read,
)
register_viewer(
    kind="no_preview",
    extensions=NO_PREVIEW_EXTENSIONS,
    payload_fn=_no_preview_payload,
    llm_summary_fn=_no_preview_llm_summary,
    llm_read_fn=_no_preview_llm_read,
)
