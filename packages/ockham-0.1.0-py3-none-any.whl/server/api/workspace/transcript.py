"""Typed subsets of the terminal JSONL transcript used at read boundaries.

The on-disk JSONL may contain many record shapes; only a narrow subset is
replayed into the LLM context. We validate *those* rows with Pydantic and
ignore everything else.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, field_validator

__all__ = [
    "KernelRestartTranscriptRow",
    "TextUserAssistantRow",
    "parse_kernel_restart",
    "parse_user_assistant_text",
]


class KernelRestartTranscriptRow(BaseModel):
    model_config = ConfigDict(extra="allow")

    type: Literal["kernel_restart"]
    at: str = "unknown"
    source: str | None = None


class _TextBlock(BaseModel):
    model_config = ConfigDict(extra="forbid")

    type: Literal["text"] = "text"
    content: str = ""

    @field_validator("content", mode="before")
    @classmethod
    def non_empty_str(cls, v: Any) -> str:
        if v is None:
            return ""
        if not isinstance(v, str):
            raise TypeError("content must be a string")
        return v


class TextUserAssistantRow(BaseModel):
    model_config = ConfigDict(extra="allow")

    role: Literal["user", "assistant"]
    content: _TextBlock


def parse_kernel_restart(row: dict[str, object]) -> KernelRestartTranscriptRow | None:
    if row.get("type") != "kernel_restart":
        return None
    try:
        return KernelRestartTranscriptRow.model_validate(row)
    except (ValueError, TypeError):
        return None


def parse_user_assistant_text(row: dict[str, object]) -> TextUserAssistantRow | None:
    if row.get("role") not in ("user", "assistant"):
        return None
    try:
        m = TextUserAssistantRow.model_validate(row)
    except (ValueError, TypeError):
        return None
    if not m.content.content.strip():
        return None
    return m
