"""In-process registry of the active analysis turn per workspace terminal.

Used for cooperative cancellation: ``POST /cancel`` (or a client disconnect
watcher) sets an :class:`asyncio.Event` the agent loop consults, so tool
call/output pairing stays well-formed and the remote kernel can be dropped.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import ClassVar, Literal, NamedTuple

# Key: (user_id, workspace_id, terminal_id) — not frozen so we can use tuple
ActiveRunKey = tuple[str, str, str]

Reason = Literal["user_request", "client_disconnect"]


class ActiveRunInProgressError(Exception):
    """Another streaming turn is already in progress for this terminal."""


class CancelResult(NamedTuple):
    """Outcome of a cancel attempt."""

    found: bool
    response_id: str | None


@dataclass
class ActiveRun:
    response_id: str
    cancel_event: asyncio.Event
    reason: Reason = "user_request"


class TerminalRunRegistry:
    """Holds the currently streaming turn per (user, workspace, terminal) session."""

    _lock: ClassVar[asyncio.Lock] = asyncio.Lock()
    _runs: ClassVar[dict[ActiveRunKey, ActiveRun]] = {}

    @classmethod
    async def register(
        cls,
        user_id: str,
        workspace_id: str,
        terminal_id: str,
        *,
        response_id: str,
        cancel_event: asyncio.Event,
    ) -> None:
        run = ActiveRun(response_id=response_id, cancel_event=cancel_event)
        async with cls._lock:
            key = (user_id, workspace_id, terminal_id)
            if key in cls._runs:
                raise ActiveRunInProgressError
            cls._runs[key] = run

    @classmethod
    async def unregister(cls, user_id: str, workspace_id: str, terminal_id: str, *, response_id: str) -> None:
        """Remove the active run only if it is still the given ``response_id`` turn."""
        async with cls._lock:
            key = (user_id, workspace_id, terminal_id)
            existing = cls._runs.get(key)
            if existing is not None and existing.response_id == response_id:
                del cls._runs[key]

    @classmethod
    async def request_cancel(cls, user_id: str, workspace_id: str, terminal_id: str, *, reason: Reason) -> CancelResult:
        """Signal cancellation for the active run, if any. Idempotent w.r.t. missing run."""
        key = (user_id, workspace_id, terminal_id)
        async with cls._lock:
            run = cls._runs.get(key)
            if run is None:
                return CancelResult(False, None)
            run.cancel_event.set()
            run.reason = reason
            return CancelResult(True, run.response_id)


# Module-level facades (tests and router)
async def register_active_run(
    user_id: str,
    workspace_id: str,
    terminal_id: str,
    *,
    response_id: str,
    cancel_event: asyncio.Event,
) -> None:
    await TerminalRunRegistry.register(
        user_id, workspace_id, terminal_id, response_id=response_id, cancel_event=cancel_event
    )


async def unregister_active_run(user_id: str, workspace_id: str, terminal_id: str, *, response_id: str) -> None:
    await TerminalRunRegistry.unregister(user_id, workspace_id, terminal_id, response_id=response_id)


async def request_terminal_cancel(user_id: str, workspace_id: str, terminal_id: str, *, reason: Reason) -> CancelResult:
    return await TerminalRunRegistry.request_cancel(user_id, workspace_id, terminal_id, reason=reason)
