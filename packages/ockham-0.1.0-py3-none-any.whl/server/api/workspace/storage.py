"""Workspace blob storage: local filesystem only.

The canonical store is ``LocalFileStorage`` over
:func:`server.storage.workspaces_dir`. Hosted deployments override the data
root via ``OCKHAM_DATA_DIR`` to point at a mounted volume.
"""

from __future__ import annotations

from pathlib import Path

from parsimony_agents.storage import FileStorage, LocalFileStorage

from server.storage import workspaces_dir


def workspace_local_tree_path(user_id: str, workspace_id: str) -> Path:
    """On-disk workspace tree root used for agent ``cwd`` and filesystem watches.

    This is ``<workspaces_dir>/{user_id}/{workspace_id}``. The directory is
    **not** created implicitly: materialize writes, workspace folder creation,
    and blob storage writes are responsible for making the tree.
    """
    return workspaces_dir() / user_id / workspace_id


def get_workspace_blob_storage() -> FileStorage:
    """Return filesystem storage rooted at :func:`server.storage.workspaces_dir`."""
    return LocalFileStorage(workspaces_dir())
