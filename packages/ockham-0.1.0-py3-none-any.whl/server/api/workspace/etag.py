"""Content-derived ETag for workspace files.

The ETag is the contract: a fingerprint of the bytes, deterministic, identical
across processes, indifferent to who wrote and when. It is *not* a sequence
number, a UUID, or a timestamp; it is the content's identity. Two writes of
identical bytes produce identical ETags. A reader that has the same ETag as the
store knows it is in sync with the store, regardless of any events received
or missed.

We use ``hashlib.blake2b`` (stdlib, no extra dependency) with an 8-byte digest:
- 64 bits of fingerprint is enough to make collisions astronomically unlikely
  for a single workspace's working set.
- BLAKE2 is fast (gigabytes/sec on commodity hardware); etag computation is
  never the bottleneck on a workspace write.

Etags travel as opaque strings prefixed with the algorithm tag (``b2-``). The
prefix lets us evolve the algorithm later without ambiguity at the wire.
"""

from __future__ import annotations

import hashlib

_ALGO_PREFIX = "b2-"


def compute_etag(data: bytes) -> str:
    """Return the content-derived ETag for *data*."""
    return _ALGO_PREFIX + hashlib.blake2b(data, digest_size=8).hexdigest()


def notebook_view_etag(*, script_py_bytes: bytes, state_cache_bytes: bytes | None) -> str:
    """ETag for ``GET /view`` of a ``.py`` notebook — same rule as the view router.

    Must match :func:`view_workspace_artifact` so ``If-None-Match`` and the
    client file-version map stay in sync with both the source file and
    ``.ockham/notebook-state`` sidecar.
    """
    return compute_etag(script_py_bytes + b"\x1e" + (state_cache_bytes or b""))


def parse_if_none_match(header: str | None) -> str | None:
    """Strip the optional surrounding double quotes used by HTTP ``If-None-Match``.

    The HTTP spec wraps ETags in quotes (``If-None-Match: "b2-abc123..."``).
    We accept either form and return the bare etag for comparison.
    """
    if not header:
        return None
    h = header.strip()
    if len(h) >= 2 and h.startswith('"') and h.endswith('"'):
        return h[1:-1]
    return h
