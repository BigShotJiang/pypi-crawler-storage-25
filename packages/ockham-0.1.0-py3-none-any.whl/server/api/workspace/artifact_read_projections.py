"""Registry-backed :class:`ArtifactReadProjection` builders per file kind.

Kept separate from :mod:`viewers` to avoid circular imports and to keep
``payload_fn`` (GET /view) separate from LLM read surfaces.
"""

from __future__ import annotations

import json

from parsimony_agents.agent.outputs import UtilityToolOutput
from parsimony_agents.chart_io import deserialize_chart
from parsimony_agents.dataset_io import deserialize_dataset
from parsimony_agents.execution.pagination import TablePaginator
from parsimony_agents.messages import blocks_to_text
from parsimony_agents.notebook import ScriptStepPreview
from parsimony_agents.notebook_io import deserialize_notebook
from pydantic import ValidationError

from server.api.workspace.artifact_projection import (
    ArtifactLocator,
    ArtifactReadProjection,
    ArtifactReadRequest,
    merge_warnings_to_text,
)
from server.api.workspace.viewers import _extract_module_docstring, file_ref

_LLM_DATASET_DEFAULT_LIMIT = 50
_NOTEBOOK_FULL_MAX_BYTES = 120_000
_DATASET_SUMMARY_MAX_CHARS = 4_000
_UTILITY_PAGE_MAX = 6_000


def flatten_script_steps(steps: list[ScriptStepPreview]) -> list[ScriptStepPreview]:
    out: list[ScriptStepPreview] = []
    for s in steps:
        out.append(s)
        out.extend(flatten_script_steps(s.children))
    return out


def _render_refs_outline(refs: list, indent: int = 2, *, name: str = "sources") -> list[str]:
    """Render artifact refs (typed ArtifactRefs) as XML lines for LLM outline projections."""
    pad = " " * indent
    if not refs:
        return [f"{pad}<{name} />"]
    lines = [f"{pad}<{name}>"]
    for r in refs:
        lines.append(f"{pad}  {r.to_self_closing_tag()}")
    lines.append(f"{pad}</{name}>")
    return lines


def dataset_read_projection(blob: bytes, path: str, req: ArtifactReadRequest) -> ArtifactReadProjection:
    result, dataset = deserialize_dataset(blob)
    df = result.df
    n = len(df)
    title = dataset.title.strip() or path
    view = req.view
    loc = req.locator

    if view == "summary":
        text = blocks_to_text(dataset.to_llm())
        if len(text) > _DATASET_SUMMARY_MAX_CHARS:
            text = text[:_DATASET_SUMMARY_MAX_CHARS] + "…"
        return ArtifactReadProjection(path=path, kind="dataset", view=view, text=text, warnings=[])

    if view == "outline":
        lines = [
            f'<dataset path="{path}">',
            f"  <title>{title}</title>",
            f"  <row_count>{n}</row_count>",
            f"  <column_count>{len(df.columns)}</column_count>",
            "  <schema>",
        ]
        for col in df.columns:
            lines.append(f"    <col name={col!r} dtype={str(df[col].dtype)!r} />")
        lines.extend(
            [
                "  </schema>",
                *_render_refs_outline(dataset.source_refs, indent=2, name="source_refs"),
            ]
        )
        if dataset.notes:
            lines.append("  <notes>" + " ".join(dataset.notes) + "</notes>")
        lines.append("</dataset>")
        return ArtifactReadProjection(path=path, kind="dataset", view=view, text="\n".join(lines), warnings=[])

    if view == "page":
        if loc is not None and loc.kind == "cell" and loc.row is not None and loc.column is not None:
            col = str(loc.column)
            if col not in df.columns:
                return ArtifactReadProjection(
                    path=path,
                    kind="dataset",
                    view=view,
                    text="",
                    warnings=[f"unknown column {col!r}"],
                )
            i = int(loc.row)
            if i < 0 or i >= n:
                return ArtifactReadProjection(
                    path=path,
                    kind="dataset",
                    view=view,
                    text="",
                    warnings=[f"row {i} out of range 0..{n - 1}"],
                )
            val = df.iloc[i][col]
            cell_text = str(val)
            w: list[str] = []
            if loc.limit is not None and int(loc.limit) > 0 and len(cell_text) > int(loc.limit):
                lim = int(loc.limit)
                cell_text = cell_text[:lim] + "…"
                w.append("cell value truncated; use char locator to page within cell")
            return ArtifactReadProjection(
                path=path,
                kind="dataset",
                view=view,
                text=merge_warnings_to_text(
                    f'<dataset_cell path="{path}" row={i} column={json.dumps(col)}>\n{cell_text}\n</dataset_cell>',
                    warnings=w,
                ),
            )

        if loc is not None and loc.kind == "cell":
            return ArtifactReadProjection(
                path=path,
                kind="dataset",
                view=view,
                text="",
                warnings=["cell locator requires row and column on the same locator object"],
            )

        if loc is None or loc.kind != "rows":
            loc = ArtifactLocator(kind="rows", offset=0, limit=_LLM_DATASET_DEFAULT_LIMIT)

        off = max(int(loc.offset or 0), 0)
        lim = int(loc.limit or _LLM_DATASET_DEFAULT_LIMIT)
        if lim < 1:
            lim = _LLM_DATASET_DEFAULT_LIMIT
        part = df.iloc[off : off + lim]
        if len(part) == 0:
            return ArtifactReadProjection(
                path=path,
                kind="dataset",
                view=view,
                text="(empty slice)",
                warnings=[f"offset {off} is past end (rows={n})"],
            )
        # TablePaginator for consistent CSV-style LLM text
        pag = TablePaginator(part, rows_per_page=max(len(part), 1), show_dtypes=True)
        pages = pag.get_pages([0], na_rep="<NULL>", max_cell_length=1000)
        body = "\n".join(pages) if pages else part.to_string()
        text = f'<dataset_rows path="{path}" offset={off} limit={lim} of_total={n}>\n{body}\n</dataset_rows>'
        next_l: ArtifactLocator | None = None
        if off + lim < n:
            next_l = ArtifactLocator(kind="rows", offset=off + lim, limit=lim, label="next page")
        return ArtifactReadProjection(
            path=path,
            kind="dataset",
            view=view,
            text=text,
            next_locator=next_l,
        )

    # full
    warn = "Full tabular data is not inlined; use view=page with a rows locator, or use read_artifact in outline."
    inner = dataset_read_projection(blob, path, ArtifactReadRequest(path=path, view="outline", locator=None))
    return ArtifactReadProjection(
        path=path,
        kind="dataset",
        view=view,
        text=inner.text,
        warnings=[warn],
    )


def chart_read_projection(blob: bytes, path: str, req: ArtifactReadRequest) -> ArtifactReadProjection:
    chart, spec = deserialize_chart(blob)
    title = chart.title.strip() or path
    view = req.view
    loc = req.locator

    if view == "summary":
        text = blocks_to_text(chart.to_llm())
        if len(text) > _DATASET_SUMMARY_MAX_CHARS:
            text = text[:_DATASET_SUMMARY_MAX_CHARS] + "…"
        return ArtifactReadProjection(path=path, kind="chart", view=view, text=text)

    if view == "outline":
        spec_title = (spec or {}).get("mark") or (spec or {}).get("layer")
        lines = [f'<chart path="{path}">', f"  <title>{title}</title>"]
        if spec_title is not None:
            lines.append(f"  <spec_hint>{json.dumps(spec_title, default=str)[:2000]}</spec_hint>")
        else:
            lines.append("  <spec_hint />")
        lines.extend(_render_refs_outline(chart.source_dataset_refs, indent=2, name="source_dataset_refs"))
        if chart.notebook_ref is not None:
            lines.append(
                f'  <notebook_ref kind="{chart.notebook_ref.kind}" '
                f'logical_id="{chart.notebook_ref.logical_id}" '
                f'content_sha="{chart.notebook_ref.content_sha}" />'
            )
        lines.extend(_render_refs_outline(chart.source_refs, indent=2, name="source_refs"))
        lines.append("</chart>")
        return ArtifactReadProjection(path=path, kind="chart", view=view, text="\n".join(lines))

    if view == "page":
        return chart_read_projection(blob, path, ArtifactReadRequest(path=path, view="outline", locator=loc))

    if view == "full" and loc is not None and loc.kind == "chart_spec":
        spec_str = json.dumps(spec, ensure_ascii=False, indent=2)
        w: list[str] = []
        if len(spec_str) > 80_000:
            spec_str = spec_str[:80_000] + "\n… [truncated]"
            w.append("Vega-Lite spec truncated; use read_file for raw bytes or smaller range.")
        return ArtifactReadProjection(
            path=path,
            kind="chart",
            view=view,
            text=f'<chart_spec path="{path}">\n{spec_str}\n</chart_spec>',
            warnings=w,
        )

    if view == "full":
        cap = "Rendered chart image is delivered as the tool multimodal result (see model blocks)."
        cap_lines = [cap, f"title: {title}", f"path: {path}"]
        if chart.source_dataset_refs:
            srcs = ", ".join(file_ref(r.workspace_file_path) for r in chart.source_dataset_refs)
            cap_lines.append(f"source_datasets: {srcs}")
        if chart.notebook_ref is not None:
            cap_lines.append(f"notebook: {file_ref(chart.notebook_ref.workspace_file_path)}")
        return ArtifactReadProjection(
            path=path,
            kind="chart",
            view=view,
            text="\n".join(cap_lines),
            warnings=["Vega-Lite JSON is not included; pass locator {kind: chart_spec} to inspect the spec."],
        )

    return chart_read_projection(blob, path, ArtifactReadRequest(path=path, view="summary"))


def notebook_read_projection(blob: bytes, path: str, req: ArtifactReadRequest) -> ArtifactReadProjection:
    script = deserialize_notebook(blob, path=path)
    preview = script.to_preview()
    steps = preview.steps
    view = req.view
    loc = req.locator
    doc = _extract_module_docstring(script.code) or ""

    if view == "summary":
        lines = [f'<notebook path="{path}">', "<docstring>", doc, "</docstring>", "<section_outline>"]
        for step in steps[:30]:
            if not step.text.strip():
                continue
            indent = "  " * max(step.level, 0)
            first = step.text.strip().split("\n", 1)[0][:200]
            lines.append(f"{indent}{first}")
        lines.extend(["</section_outline>", "</notebook>"])
        return ArtifactReadProjection(path=path, kind="notebook", view=view, text="\n".join(lines))

    if view == "outline":
        lines = [f'<notebook path="{path}">', "<docstring>", doc, "</docstring>", "<section_outline>"]
        for step in flatten_script_steps(steps):
            if not step.text.strip():
                continue
            indent = "  " * max(step.level, 0)
            first = step.text.strip().split("\n", 1)[0][:200]
            lines.append(f"{indent}{first}")
        lines.extend(["</section_outline>", "</notebook>"])
        return ArtifactReadProjection(path=path, kind="notebook", view=view, text="\n".join(lines))

    if view == "page":
        flat = flatten_script_steps(steps)
        idx = int(loc.section_index) if (loc and loc.section_index is not None) else 0
        if idx < 0 or idx >= len(flat):
            return ArtifactReadProjection(
                path=path,
                kind="notebook",
                view=view,
                text="",
                warnings=[f"section_index {idx} out of range (0..{len(flat) - 1})" if flat else "no sections"],
            )
        step = flat[idx]
        body = f"{step.text}\n# ---\n{step.code}\n" if step.code.strip() else step.text
        return ArtifactReadProjection(
            path=path,
            kind="notebook",
            view=view,
            text=f'<notebook_section path="{path}" index={idx}>\n{body}\n</notebook_section>',
        )

    if view == "full":
        raw = script.code
        w: list[str] = []
        if len(raw.encode("utf-8")) > _NOTEBOOK_FULL_MAX_BYTES:
            raw = raw[:_NOTEBOOK_FULL_MAX_BYTES]
            w.append("Notebook source truncated to byte cap; use read_file for the exact on-disk file.")
        return ArtifactReadProjection(
            path=path,
            kind="notebook",
            view=view,
            text=f'<notebook path="{path}">\n```python\n{raw}\n```\n</notebook>\n',
            warnings=w,
        )

    return notebook_read_projection(blob, path, ArtifactReadRequest(path=path, view="summary"))


def utility_read_projection(blob: bytes, path: str, req: ArtifactReadRequest) -> ArtifactReadProjection:
    text = blob.decode("utf-8")
    view = req.view
    try:
        uo = UtilityToolOutput.model_validate_json(text)
    except ValidationError:
        if view == "summary":
            t = text[:_UTILITY_PAGE_MAX] + ("…" if len(text) > _UTILITY_PAGE_MAX else "")
            return ArtifactReadProjection(
                path=path,
                kind="utility_output",
                view=view,
                text=f'<utility_output path="{path}" format="legacy">{t}</utility_output>',
            )
        return ArtifactReadProjection(
            path=path,
            kind="utility_output",
            view=view,
            text=f'<utility_output path="{path}" format="legacy">\n{text}\n</utility_output>',
            warnings=[],
        )

    if view == "summary":
        msg = (uo.ui_message_completed or uo.ui_message or "utility output").strip()
        s = f"{path} — {msg[:400]}"
        return ArtifactReadProjection(path=path, kind="utility_output", view=view, text=s)

    if view == "outline":
        lines = [f'<utility_output path="{path}">', f"  <ui_message>{uo.ui_message}</ui_message>"]
        if uo.ui_message_completed:
            lines.append(f"  <ui_message_completed>{uo.ui_message_completed}</ui_message_completed>")
        if uo.metadata:
            lines.append(f"  <metadata>{json.dumps(uo.metadata, default=str)[:2000]}</metadata>")
        ct = uo.content.to_llm() if uo.content is not None else []
        lines.append(f"  <content_blocks count={len(ct)} />")
        lines.append("</utility_output>")
        return ArtifactReadProjection(path=path, kind="utility_output", view=view, text="\n".join(lines))

    dumped = uo.model_dump_json(indent=2)
    if view == "page":
        if req.locator is not None:
            off = int(req.locator.offset or 0)
            lim = int(req.locator.limit) if req.locator.limit is not None else 4000
        else:
            off, lim = 0, 4000
        if off < 0:
            off = 0
        if lim < 1:
            lim = 4000
        if off >= len(dumped):
            return ArtifactReadProjection(
                path=path, kind="utility_output", view=view, text="", warnings=[f"char offset {off} past end"]
            )
        chunk = dumped[off : off + lim]
        next_l = None
        if off + lim < len(dumped):
            next_l = ArtifactLocator(
                kind="chars",
                offset=off + lim,
                limit=lim,
                label="next char page",
            )
        t = f'<utility_output path="{path}" char_range="{off}..{off + len(chunk)}">\n{chunk}\n</utility_output>'
        return ArtifactReadProjection(
            path=path,
            kind="utility_output",
            view=view,
            text=t,
            next_locator=next_l,
        )

    if view == "full":
        w: list[str] = []
        if len(dumped) > 80_000:
            w.append("JSON truncated to 80k characters.")
            dumped = dumped[:80_000] + "…"
        return ArtifactReadProjection(
            path=path,
            kind="utility_output",
            view=view,
            text=dumped,
            warnings=w,
        )

    return utility_read_projection(blob, path, ArtifactReadRequest(path=path, view="summary"))


def pdf_read_projection(blob: bytes, path: str, req: ArtifactReadRequest) -> ArtifactReadProjection:
    from server.api.workspace import viewers as workspace_viewers

    mode = "full" if req.view == "full" else "summary"
    text = workspace_viewers._pdf_llm_read(blob, path, mode)
    return ArtifactReadProjection(path=path, kind="pdf", view=req.view, text=text, warnings=[])


def image_read_projection(blob: bytes, path: str, req: ArtifactReadRequest) -> ArtifactReadProjection:
    from server.api.workspace import viewers as workspace_viewers

    mode = "full" if req.view == "full" else "summary"
    text = workspace_viewers._image_llm_read(blob, path, mode)
    return ArtifactReadProjection(path=path, kind="image", view=req.view, text=text, warnings=[])


def text_read_projection(blob: bytes, path: str, req: ArtifactReadRequest) -> ArtifactReadProjection:
    from server.api.workspace import viewers as workspace_viewers

    mode = "full" if req.view == "full" else "summary"
    text = workspace_viewers._text_llm_read(blob, path, mode)
    return ArtifactReadProjection(path=path, kind="text", view=req.view, text=text, warnings=[])


def no_preview_read_projection(blob: bytes, path: str, req: ArtifactReadRequest) -> ArtifactReadProjection:
    from server.api.workspace import viewers as workspace_viewers

    mode = "full" if req.view == "full" else "summary"
    text = workspace_viewers._no_preview_llm_read(blob, path, mode)
    return ArtifactReadProjection(path=path, kind="no_preview", view=req.view, text=text, warnings=[])


def read_projection_for_kind(
    kind: str,
    blob: bytes,
    path: str,
    req: ArtifactReadRequest,
) -> ArtifactReadProjection:
    if kind == "dataset":
        return dataset_read_projection(blob, path, req)
    if kind == "chart":
        return chart_read_projection(blob, path, req)
    if kind == "notebook":
        return notebook_read_projection(blob, path, req)
    if kind == "utility_output":
        return utility_read_projection(blob, path, req)
    if kind == "pdf":
        return pdf_read_projection(blob, path, req)
    if kind == "image":
        return image_read_projection(blob, path, req)
    if kind == "text":
        return text_read_projection(blob, path, req)
    if kind == "no_preview":
        return no_preview_read_projection(blob, path, req)
    return ArtifactReadProjection(
        path=path,
        kind=kind,
        view=req.view,
        text="",
        warnings=[f"no LLM read projection for kind {kind!r}"],
    )
