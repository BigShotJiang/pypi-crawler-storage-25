"""JSON-safe table helpers shared by viewers."""

from __future__ import annotations

import json
from typing import Any

import pandas as pd

DATASET_VIEW_ROW_LIMIT = 1000


def dataframe_rows(df: pd.DataFrame, *, max_rows: int = DATASET_VIEW_ROW_LIMIT) -> list[dict[str, Any]]:
    """Return the first ``max_rows`` rows of ``df`` as JSON-safe records."""

    return json.loads(df.head(max_rows).to_json(orient="records", date_format="iso"))
