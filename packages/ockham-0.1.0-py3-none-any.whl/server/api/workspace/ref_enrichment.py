"""Enrich typed :class:`ArtifactRef` triplets with human-readable display names.

The wire payload for a dataset/chart/report carries the typed
``(kind, logical_id, content_sha)`` lineage refs the agent passed in.
Without enrichment, the panel can only display the on-disk basename —
which for content-addressed paths is a 64-char hash and tells the user
nothing about *what* the ref points at.

This module reads each ref's curation sidecar — uniform across every
kind under the content-addressed layout — to derive a short human
label. ``data_object`` carries provenance fields (``source``,
``params``) on its sidecar; user-facing kinds carry editable metadata
(``title``, ``live_name``). One read path, two payload shapes
discriminated by ``kind``. It also reads ``log.jsonl`` (every kind has
one) to surface ``version`` — the workspace-local snapshot index
``v{N}`` — so the panel can render two pills with the same display
name but different ``content_sha`` as visually distinct (``v1`` vs
``v3``).

Failures are swallowed: the frontend already falls back to basename
when ``display_name`` is absent, and pills omit the ``v{N}`` badge
when ``version`` is ``None`` — a missing curation is a UX downgrade,
never a turn-breaking error.

Wire shape per ref::

    {
        "kind": "data_object",
        "logical_id": "…",
        "content_sha": "…",
        "workspace_file_path": ".ockham/data_objects/…/….parquet",
        "display_name": "fred_fetch(series_id=GDPC1)",  # may be None
        "version": 3,                                   # 1-based log position
    }
"""

from __future__ import annotations

from typing import Any

from parsimony_agents.identity import ArtifactRef

from server.api.workspace.snapshot_store import (
    Curation,
    DataObjectCuration,
    read_curation,
    read_log,
)

__all__ = (
    "enrich_ref_dict",
    "enrich_artifact_envelope",
    "format_data_object_label",
)

# Cap params projection so display labels stay one-line and readable.
_MAX_PARAM_VALUE_LEN = 40
_MAX_PARAMS_IN_LABEL = 3
_MAX_DISPLAY_NAME_LEN = 80


# ---------------------------------------------------------------------------
# Display-name derivation (single curation read, kind-aware projection)
# ---------------------------------------------------------------------------


def _curation_display_name(cur: Curation | DataObjectCuration) -> str | None:
    """Project a curation record to a one-line display label.

    ``data_object`` curation carries provenance (source + params) and
    renders as ``source(key=val, …)``. Every other kind carries
    user-facing metadata (title / live_name).
    """
    if isinstance(cur, DataObjectCuration):
        source = cur.source.strip()
        if not source:
            return None
        return format_data_object_label(source, cur.params or {})
    name = cur.title.strip() or (cur.live_name or "").strip()
    return name or None


# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------


def format_data_object_label(source: str, params: dict[str, Any]) -> str:
    """Format a data_object's connector call as a one-line human label.

    ``source`` is the connector name (e.g. ``fred_fetch``); ``params`` is
    the keyword-argument dict the connector was invoked with. The
    returned label looks like ``fred_fetch(series_id=GDPC1, …)`` with
    capped param count and per-value length so it fits a pill.

    Public so callers outside ``enrich_ref_dict`` (notebook viewer's
    Data-sources pills, future ref renderers) can produce the *same*
    label as the metadata-panel data_object pill — without re-reading
    the parquet when an in-memory provenance is already available.
    """
    if not params:
        return _truncate(source)
    items = list(params.items())[:_MAX_PARAMS_IN_LABEL]
    parts: list[str] = []
    for k, v in items:
        s = _stringify_param_value(v)
        if s is None:
            continue
        parts.append(f"{k}={s}")
    if len(params) > len(items):
        parts.append("…")
    if not parts:
        return _truncate(source)
    return _truncate(f"{source}({', '.join(parts)})")


def _stringify_param_value(v: Any) -> str | None:
    if v is None:
        return "null"
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, (int, float)):
        return str(v)
    if isinstance(v, str):
        s = v.strip()
        if not s:
            return None
        if len(s) > _MAX_PARAM_VALUE_LEN:
            return s[:_MAX_PARAM_VALUE_LEN] + "…"
        return s
    return None


def _truncate(s: str) -> str:
    if len(s) <= _MAX_DISPLAY_NAME_LEN:
        return s
    return s[: _MAX_DISPLAY_NAME_LEN - 1] + "…"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


async def _resolve_display_name(ref: ArtifactRef, *, user_id: str, workspace_id: str) -> str | None:
    """Read ``ref``'s curation sidecar and project it to a display label.

    One read path for every kind: :func:`read_curation` returns a
    :class:`Curation` for notebook/dataset/chart/report and a
    :class:`DataObjectCuration` for ``data_object``. Projection branches
    on the concrete type, not on a per-kind I/O strategy.

    Best-effort: any unexpected exception (filesystem race, malformed
    sidecar) collapses to ``None`` so the panel falls back to the path
    basename instead of failing the request.
    """
    try:
        cur = await read_curation(user_id, workspace_id, ref.kind, ref.logical_id)  # type: ignore[arg-type]
        if cur is None:
            return None
        return _curation_display_name(cur)
    except Exception:
        return None


async def _resolve_version(ref: ArtifactRef, *, user_id: str, workspace_id: str) -> int | None:
    """1-based position of ``ref.content_sha`` in ``log.jsonl``, or ``None``.

    Every kind has a per-logical_id log under the unified versioning
    model, so this function applies uniformly to all five kinds — no
    allowlist needed. Best-effort: any read/parse failure collapses
    to ``None`` (the pill simply omits the ``v{N}`` badge).
    """
    try:
        entries = await read_log(user_id, workspace_id, ref.kind, ref.logical_id)  # type: ignore[arg-type]
    except Exception:
        return None
    for index, entry in enumerate(entries, start=1):
        if entry.content_sha == ref.content_sha:
            return index
    return None


async def _overlay_live_curation(
    artifact: dict[str, Any],
    self_ref: ArtifactRef,
    *,
    user_id: str,
    workspace_id: str,
) -> None:
    """Overwrite ``artifact``'s display fields with the live curation sidecar.

    Embedded curation (the copy serialized into the snapshot bytes) is a
    frozen tombstone of how the artifact looked at persist time (§5.9).
    The detail tab needs the *current* title/description/tags/notes/
    live_name, which lives in ``curation.json`` and is updated by the
    PATCH endpoint without rewriting bytes.

    Best-effort: a missing sidecar or read failure leaves the embedded
    fields untouched, so the panel still renders something. ``data_object``
    is handled by :func:`_overlay_data_object_provenance` instead — its
    viewer payload uses ``provenance`` (not ``artifact``) and the parquet
    has ``fetched_at`` stripped for content-addressing.
    """
    if self_ref.kind == "data_object":
        return
    try:
        cur = await read_curation(
            user_id,
            workspace_id,
            self_ref.kind,
            self_ref.logical_id,  # type: ignore[arg-type]
        )
    except Exception:
        return
    if cur is None or isinstance(cur, DataObjectCuration):
        return
    artifact["title"] = cur.title
    artifact["description"] = cur.description
    artifact["tags"] = list(cur.tags)
    artifact["notes"] = list(cur.notes)
    artifact["live_name"] = cur.live_name


async def _overlay_data_object_provenance(
    payload: dict[str, Any],
    *,
    user_id: str,
    workspace_id: str,
    path: str | None,
) -> None:
    """Make :class:`DataObjectCuration` the canonical wire provenance.

    The dataset viewer builds ``payload['provenance']`` from the parquet's
    embedded ``Provenance``, but ``_canonicalize_arrow_table`` strips
    ``fetched_at`` from those bytes for content-addressing dedup
    (CONTENT_ADDRESSED_ARTIFACTS_PLAN §2.3). The connector persister
    writes the full record into the curation sidecar at fetch time; that
    sidecar is the canonical source of truth at read time. Symmetric with
    :func:`_overlay_live_curation` for the four user-editable kinds.

    Best-effort: missing ``path`` / non-canonical path / unreadable
    sidecar leave ``payload['provenance']`` as the parquet projection.
    """
    if path is None:
        return
    ref = ArtifactRef.from_workspace_file_path(path)
    if ref is None or ref.kind != "data_object":
        return
    try:
        cur = await read_curation(user_id, workspace_id, "data_object", ref.logical_id)
    except Exception:
        return
    if not isinstance(cur, DataObjectCuration):
        return
    prov = payload.get("provenance")
    if not isinstance(prov, dict):
        return
    prov["source"] = cur.source
    prov["source_description"] = cur.source_description
    prov["params"] = dict(cur.params)
    prov["fetched_at"] = cur.fetched_at
    prov["properties"] = dict(cur.properties)


async def enrich_ref_dict(ref_dict: dict[str, Any], *, user_id: str, workspace_id: str) -> dict[str, Any]:
    """Return ``ref_dict`` augmented with ``workspace_file_path``, ``display_name``, ``version``.

    Best-effort: failures to read the backing file leave the new fields
    as ``None``; the frontend falls back to the path basename and omits
    the ``v{N}`` badge.
    """
    try:
        ref = ArtifactRef.from_dict(ref_dict)
    except (KeyError, ValueError):
        return ref_dict
    return {
        **ref_dict,
        "workspace_file_path": ref.workspace_file_path,
        "display_name": await _resolve_display_name(ref, user_id=user_id, workspace_id=workspace_id),
        "version": await _resolve_version(ref, user_id=user_id, workspace_id=workspace_id),
    }


async def enrich_artifact_envelope(
    payload: dict[str, Any],
    *,
    user_id: str,
    workspace_id: str,
    path: str | None = None,
) -> dict[str, Any]:
    """Walk ``payload['artifact']`` and enrich every typed ref it carries.

    The payload may contain typed ref triplets in any of:
    - ``artifact.notebook_refs`` (datasets + reports; plural)
    - ``artifact.source_refs`` (datasets + charts)
    - ``artifact.notebook_ref`` (charts; singular)
    - ``artifact.source_dataset_refs`` (charts; plural)
    - ``artifact.embedded_refs`` (reports; plural — the snapshot's frozen
      pin map serialized as typed triplets)

    Each enriched ref gains ``workspace_file_path`` (so the pill knows
    where to link) and a best-effort ``display_name`` derived from its
    curation sidecar (title/live_name for notebook/dataset/chart/report;
    ``source(params)`` projected from the provenance fields for
    data_objects).

    The artifact ITSELF also gains a ``version`` field — the
    workspace-local snapshot index of the ``content_sha`` being viewed —
    so the user can see *which* version of the open artifact they're
    looking at without having to cross-reference the upstream ref pills.

    Live-curation overlay: ``title``, ``description``, ``tags``,
    ``notes``, and ``live_name`` are pulled from the on-disk curation
    sidecar and overwrite the embedded copy in ``payload['artifact']``.
    The embedded form is a frozen tombstone (§5.9) — without this
    overlay, every curation PATCH would leave the detail tab showing
    the old title until the next republish.

    For ``data_object`` payloads (which carry ``provenance`` instead of
    ``artifact``), the same canonical-sidecar principle applies: the
    parquet's embedded provenance is missing ``fetched_at`` (stripped
    for content-addressing), so we overlay ``payload['provenance']``
    from :class:`DataObjectCuration`. Requires ``path`` — the
    canonical workspace path being viewed — to resolve the ref.
    """
    kind = payload.get("kind")
    if kind == "data_object":
        await _overlay_data_object_provenance(payload, user_id=user_id, workspace_id=workspace_id, path=path)
        return payload

    artifact = payload.get("artifact")
    if not isinstance(artifact, dict):
        return payload

    # Resolve the artifact's own version + overlay live curation. Every
    # user-facing kind has a per-logical_id curation sidecar under the
    # unified model; ``data_object`` carries DataObjectCuration which
    # has no display fields and is intentionally ignored here.
    if isinstance(kind, str):
        try:
            self_ref = ArtifactRef(
                kind=kind,  # type: ignore[arg-type]
                logical_id=artifact["logical_id"],
                content_sha=artifact["content_sha"],
            )
        except (KeyError, ValueError):
            pass
        else:
            artifact["version"] = await _resolve_version(self_ref, user_id=user_id, workspace_id=workspace_id)
            await _overlay_live_curation(artifact, self_ref, user_id=user_id, workspace_id=workspace_id)

    async def _enrich_list(key: str) -> None:
        refs = artifact.get(key)
        if not isinstance(refs, list):
            return
        artifact[key] = [
            await enrich_ref_dict(r, user_id=user_id, workspace_id=workspace_id) if isinstance(r, dict) else r
            for r in refs
        ]

    async def _enrich_singular(key: str) -> None:
        ref = artifact.get(key)
        if isinstance(ref, dict):
            artifact[key] = await enrich_ref_dict(ref, user_id=user_id, workspace_id=workspace_id)

    await _enrich_list("notebook_refs")
    await _enrich_list("source_refs")
    await _enrich_list("source_dataset_refs")
    await _enrich_list("embedded_refs")
    await _enrich_singular("notebook_ref")
    return payload
