"""Typed LLM-facing contracts for registry-backed workspace artifact reads.

These are projections from on-disk file bytes, not viewer payloads. The file
remains canonical; :class:`ArtifactReadProjection` is what ``read_artifact`` surfaces.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class ArtifactLocator(BaseModel):
    """Stable locator the agent can pass back to ``read_artifact`` for pagination."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    kind: Literal["rows", "chars", "section", "cell", "chart_image", "chart_spec"] = "rows"
    label: str = ""
    offset: int = 0
    limit: int | None = None
    page: int | None = None
    section_id: str | None = None
    section_index: int | None = None
    row: int | None = None
    column: str | None = None

    @model_validator(mode="after")
    def _kind_defaults(self) -> ArtifactLocator:
        if self.kind == "rows" and self.limit is None:
            return self.model_copy(update={"limit": 50})
        return self


class ArtifactReadRequest(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    path: str
    view: Literal["summary", "outline", "page", "full"] = "summary"
    locator: ArtifactLocator | None = None


class ArtifactReadProjection(BaseModel):
    """Text-first projection; multimodal image transport is added in ``artifact_llm``."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    path: str
    kind: str
    view: str
    text: str
    next_locator: ArtifactLocator | None = None
    warnings: list[str] = Field(default_factory=list)


def merge_warnings_to_text(
    text: str,
    *,
    next_locator: ArtifactLocator | None = None,
    warnings: list[str] | None = None,
) -> str:
    """Append next-locator and warnings to *text* for a single LLM string."""

    parts: list[str] = [text]
    if next_locator is not None:
        parts.append(f"\n<next_locator>{next_locator.model_dump_json(ensure_ascii=False)}</next_locator>")
    if warnings:
        parts.append("\n<warnings>" + " \n".join(warnings) + "</warnings>")
    return "".join(parts)


__all__ = [
    "ArtifactLocator",
    "ArtifactReadProjection",
    "ArtifactReadRequest",
    "merge_warnings_to_text",
]
