"""Persistence for ``return_*`` artifacts (content-addressed layout).

Single boundary that turns a typed ``Dataset``/``Chart``/``Report``
artifact into a workspace file under the new content-addressed
namespace described in ``CONTENT_ADDRESSED_ARTIFACTS_PLAN.md`` §2.3:

::

    .ockham/<kind>s/<logical_id>/curation.json   # editable sidecar
    .ockham/<kind>s/<logical_id>/log.jsonl       # append-only history
    .ockham/<kind>s/<logical_id>/<content_sha>.<ext>   # immutable snapshot

The artifact's ``logical_id`` must be set by the caller (the framework
computes it from typed inputs in :mod:`parsimony_agents.identity`); the
registry computes ``content_sha`` from the rendered bytes and writes
all three pieces atomically:

1. Snapshot — idempotent (skipped if same path already on disk).
2. Curation — frozen at first persist, but always overwritten with the
   latest in-memory curation so a re-publish updates description/tags.
   The PATCH endpoint (Phase 8) is the editable side; this write is
   the "agent-authored canonical curation" path.
3. Log — appended only when ``content_sha`` changes from the latest
   entry (idempotent for repeat publishes).

The wire emits a single :class:`FileRefChunk` carrying
``(kind, logical_id, content_sha, workspace_file_path)``; nothing about
the card payload travels on the wire — renderers fetch metadata from
the file via ``GET /workspaces/{wid}/view/{path}``.
"""

from __future__ import annotations

__all__ = ("persist_return_artifact",)

from datetime import UTC, datetime

from parsimony_agents.artifacts import Chart, Dataset, Report, derive_live_name
from parsimony_agents.chart_io import write_chart_bytes
from parsimony_agents.dataset_io import write_dataset_bytes
from parsimony_agents.identity import ArtifactRef, SnapshotKind, content_sha

from server.api.workspace.snapshot_store import (
    Curation,
    LogEntry,
    append_log,
    write_curation,
    write_snapshot,
)


async def persist_return_artifact(
    *,
    user_id: str,
    workspace_id: str,
    artifact: Dataset | Chart | Report,
    kind: SnapshotKind,
) -> tuple[ArtifactRef, str, str, int]:
    """Persist ``artifact`` and return ``(ref, workspace_file_path, etag, version)``.

    The artifact's ``logical_id`` must be set by the caller. The
    registry computes ``content_sha``, freezes the curation embedded in
    the bytes (§5.9: never updated thereafter), then writes:

    - the snapshot (idempotent),
    - the curation sidecar (overwritten on every publish so the latest
      title/description/tags are visible in the live tree),
    - a new log line (deduped on content_sha).

    ``version`` is the artifact's workspace-local snapshot index — the
    1-based position of this ``content_sha`` in ``log.jsonl``. v1 is the
    first publish; identical-content republishes return the existing
    version. Not part of identity (lives on the wire alongside
    :class:`ArtifactRef`, never inside it).
    """
    if not artifact.logical_id:
        raise ValueError(
            f"{type(artifact).__name__}(logical_id='') — registry requires the "
            "framework to set logical_id before persistence."
        )

    blob, _embedded_curation = _render_bytes(artifact, kind)
    csha = content_sha(blob)
    artifact.content_sha = csha
    ref = ArtifactRef(kind=kind, logical_id=artifact.logical_id, content_sha=csha)

    # 1. Snapshot — idempotent, content-addressed.
    await write_snapshot(user_id, workspace_id, ref, blob)

    # 2. Curation sidecar — overwrite with latest in-memory curation.
    #    The PATCH endpoint (Phase 8) is the user-editable side; this
    #    write keeps the agent-authored canonical curation in sync.
    live_name = artifact.live_name if artifact.live_name is not None else derive_live_name(artifact.title or kind)
    # ``variable_name`` is a recipe field on Dataset/Chart only — Report
    # has no kernel-extraction step. Read it off the artifact when
    # present; the curation field stays ``None`` for kinds that don't
    # carry one.
    variable_name = getattr(artifact, "variable_name", None) or None
    cur = Curation(
        kind=kind,
        logical_id=artifact.logical_id,
        title=artifact.title,
        description=artifact.description,
        tags=list(artifact.tags),
        notes=list(artifact.notes),
        live_name=live_name,
        variable_name=variable_name,
    )
    await write_curation(user_id, workspace_id, kind, artifact.logical_id, cur)

    # 3. Log — dedup on content_sha; version is the entry's 1-based position.
    inputs = _log_inputs(artifact, kind)
    entry = LogEntry(
        ts=datetime.now(UTC).isoformat(timespec="seconds").replace("+00:00", "Z"),
        content_sha=csha,
        inputs=inputs,
    )
    version = await append_log(user_id, workspace_id, kind, artifact.logical_id, entry)

    return ref, ref.workspace_file_path, _etag(blob), version


def _render_bytes(artifact: Dataset | Chart | Report, kind: SnapshotKind) -> tuple[bytes, dict]:
    """Return rendered bytes for the artifact and the curation captured in them.

    The second tuple element is informational (the embedded curation
    dict): the registry doesn't act on it but it's useful for tests
    that assert the embedded form.
    """
    match artifact:
        case Dataset() as dataset:
            payload = dataset.payload
            if payload is None:
                raise ValueError(
                    f"Dataset(logical_id={dataset.logical_id!r}) is missing its live "
                    "``_payload``; return_dataset must attach it via .with_payload(...)."
                )
            return write_dataset_bytes(dataset, payload), dataset.model_dump(mode="json")
        case Chart() as chart:
            payload = chart.payload
            if payload is None:
                raise ValueError(
                    f"Chart(logical_id={chart.logical_id!r}) is missing its live "
                    "``_payload``; return_chart must attach it via .with_payload(...)."
                )
            if chart.notebook_ref is None:
                raise ValueError(
                    f"Chart(logical_id={chart.logical_id!r}) has no notebook_ref; "
                    "the framework requires a notebook ref at persist time."
                )
            return write_chart_bytes(chart, payload), chart.model_dump(mode="json")
        case Report() as report:
            if not report.markdown.strip():
                raise ValueError(
                    f"Report(logical_id={report.logical_id!r}) has empty markdown; "
                    "return_report must populate it at construction time."
                )
            # Validate at the trust boundary (BRIEF §3): executable
            # fences, raw HTML active content, shortcodes, foreign
            # fenced-div classes, and out-of-allowlist ref paths are
            # rejected here so the bytes that hit disk are safe to
            # render as-is.
            from server.api.workspace.report.validate import validate_report_body

            validate_report_body(report.markdown)
            return report.snapshot_bytes(), report.model_dump(mode="json")
        case _:
            raise ValueError(f"Unsupported artifact type for persistence: {type(artifact).__name__}")


def _log_inputs(artifact: Dataset | Chart | Report, kind: SnapshotKind) -> dict:
    """Build the per-kind ``inputs`` payload for the log line (§2.5)."""
    match artifact:
        case Dataset() as dataset:
            return {
                "notebooks": [r.content_sha for r in dataset.notebook_refs],
                "sources": [r.content_sha for r in dataset.source_refs],
            }
        case Chart() as chart:
            return {
                "notebook": chart.notebook_ref.content_sha,
                "source_datasets": [r.content_sha for r in chart.source_dataset_refs],
                "sources": [r.content_sha for r in chart.source_refs],
            }
        case Report() as report:
            return {
                "embedded": [r.content_sha for r in report.embedded_refs],
                "formats": list(report.formats),
            }
        case _:
            return {}


def _etag(blob: bytes) -> str:
    """Compute the same etag service.write_workspace_file_bytes returns.

    Imported lazily to avoid the circular dep tax at module load.
    """
    from server.api.workspace.etag import compute_etag

    return compute_etag(blob)
