"""Workspace IDE API: file-backed workspaces and terminal messages."""
