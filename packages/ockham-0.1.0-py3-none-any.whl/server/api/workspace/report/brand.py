"""Single source of truth for report theming.

A frozen dataclass of brand tokens. The same instance feeds every format
pipeline:

- SCSS — by string-splicing ``$brand-*`` placeholders in
  ``templates/theme.scss`` at render time.
- typst — emitted into the Quarto YAML for PDF as page geometry +
  font + size + branded accent rule (the typst preamble lives in
  :mod:`render`, but reads :data:`DEFAULT_BRAND.primary` etc.).
- pptx generator (``scripts/build_reference_pptx.py``) — retypesets the
  Quarto-default reference deck with :data:`DEFAULT_BRAND.font_body_primary`
  and :data:`DEFAULT_BRAND.font_mono_primary`.
- HTML/dashboard/revealjs head — Google Fonts ``<link>``s derived from
  :meth:`google_fonts_query` get injected via Quarto's ``header-includes``.

The SCSS-vs-Python gap is the known limitation called out in
``BRIEF-quarto-reporting-alternatives.md`` axis H — we splice tokens
into a single ``.scss`` file at render time rather than build SCSS
from Python at import time.
"""

from __future__ import annotations

__all__ = ["BrandTokens", "DEFAULT_BRAND", "apply_brand_to_scss"]

from dataclasses import dataclass


@dataclass(frozen=True)
class BrandTokens:
    """Brand identity, consumed by every format pipeline.

    The palette defaults to a dark, editorial look applied uniformly
    across HTML, dashboard, slides, and PDF — no per-format palette
    carve-outs. PDF print stylesheets still flip to light via the
    ``@media print`` block in ``theme.scss`` because a printed page
    in a dark palette wastes ink and reads poorly.
    """

    # Palette — dark by default.
    primary: str = "#3b82f6"  # accent: links, rules, callouts
    primary_dark: str = "#1d4ed8"  # link hover
    text: str = "#fafafa"  # body
    muted: str = "#b3b3b3"  # captions, secondary text
    background: str = "#080808"  # page bg
    surface: str = "#141414"  # cards, code blocks, table headers
    border: str = "#333333"  # borders, dividers
    code_color: str = "#e5a341"  # syntax-highlighted code fg

    # Typography. ``font_body`` / ``font_mono`` are full CSS stacks for
    # SCSS; the ``_primary`` fields are the family names alone, used by
    # typst (which wants a single registered name) and Google Fonts.
    font_body: str = "Inter, system-ui, -apple-system, 'Segoe UI', sans-serif"
    font_mono: str = "'JetBrains Mono', ui-monospace, Menlo, monospace"
    font_body_primary: str = "Inter"
    font_mono_primary: str = "JetBrains Mono"
    font_size_body_pt: int = 11
    # Reveal.js base font-size (root). Quarto's bundled default is 40px;
    # 36px is calmer for dense slides while staying readable at typical
    # projection distances. Heading scale (h1: 2.5em, h2: 1.6em, …) is
    # multiplicative on this root, so adjusting here scales the whole
    # slide hierarchy proportionally.
    font_size_slide_px: int = 36
    line_height: float = 1.55

    # Page geometry (typst PDF)
    page_width: str = "8.5in"
    page_height: str = "11in"
    page_margin: str = "0.75in"

    @property
    def google_fonts_query(self) -> str:
        """Query string for fonts.googleapis.com/css2.

        Used by the renderer to build the HTML ``<link>`` block injected
        via Quarto ``header-includes`` for HTML-like formats. Body family
        loads weights 400/500/600/700 (regular through bold); monospace
        loads 400/500.
        """
        body = self.font_body_primary.replace(" ", "+")
        mono = self.font_mono_primary.replace(" ", "+")
        return f"family={body}:wght@400;500;600;700&family={mono}:wght@400;500&display=swap"


DEFAULT_BRAND = BrandTokens()


def apply_brand_to_scss(scss_source: str, tokens: BrandTokens = DEFAULT_BRAND) -> str:
    """Splice brand tokens into an SCSS template.

    The SCSS file uses ``$brand-<field>`` placeholders that we replace
    here. Substitutes longer placeholder names first so partial-match
    overlap (``$brand-primary`` vs ``$brand-primary-dark``) doesn't
    corrupt the longer name. Trivial substitution beats a SASS build
    step for the scope of this subsystem (one file).
    """
    out = scss_source
    pairs = sorted(
        ((f"$brand-{field.replace('_', '-')}", str(value)) for field, value in tokens.__dict__.items()),
        key=lambda kv: len(kv[0]),
        reverse=True,
    )
    for placeholder, value in pairs:
        out = out.replace(placeholder, value)
    return out
