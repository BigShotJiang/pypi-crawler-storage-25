"""Quarto-backed report rendering subsystem.

Public surface (re-exported here):

- :func:`render`               — turn a snapshot blob + format into output bytes.
- :func:`validate_report_body` — pure validator the persistence path calls.
- :class:`RenderError`         — render-time failure (Quarto subprocess error).
- :class:`RenderTimeout`       — render-time wall-clock timeout.
- :class:`ValidationError`     — submission rejected by the validator.

Design notes are in PICKS.md / PLAN.md at the worktree root. The
top-level flow lives in :mod:`render`; everything else is supporting
material kept on its own screen.
"""

from __future__ import annotations

__all__ = [
    "QUARTO_VERSION",
    "RenderError",
    "RenderTimeout",
    "ValidationError",
    "render",
    "validate_report_body",
    "available_formats_for_snapshot",
]

from server.api.workspace.report.render import (
    QUARTO_VERSION,
    RenderError,
    RenderTimeout,
    available_formats_for_snapshot,
    render,
)
from server.api.workspace.report.validate import ValidationError, validate_report_body
