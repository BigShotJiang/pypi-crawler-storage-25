"""Threat-surface validator for agent-authored report bodies.

Pure function, no I/O, no rewriting. Runs at persist time (the trust
boundary). Failure raises :class:`ValidationError` carrying the
offending content; ``persist_return_artifact`` surfaces the message
through the agent tool result so the model can self-correct on the
next turn.

Rejections (BRIEF §3):

- Executable Quarto fences: ``{python}``, ``{r}``, ``{julia}``, ``{ojs}``
  and other ``{lang}``-form info strings. ``--no-execute`` renders these
  as styled code blocks but does not reject them.
- Raw HTML active content: ``<script>``, ``<iframe>``, ``<object>``,
  ``<embed>``, ``<style>``, ``<link>``.
- Quarto shortcodes: ``{{< ... >}}`` anywhere outside a fenced code block.
- File refs outside the live-tree embed surface. Bodies reference
  artifacts by their workspace slug (live_name) under ``charts/`` or
  ``data/``; any other ``file://`` path is rejected.
- Body live_names that don't appear in the snapshot's pin map (when the
  caller supplies one via ``pin_map_keys``).
- Fenced divs ``::: {.classname}`` whose class is not in a small
  allowlist (callouts, dashboard primitives, column system, tabsets,
  revealjs notes, asides).
"""

from __future__ import annotations

__all__ = ["ValidationError", "validate_report_body"]

import re

# Quarto info-string of the form ``{lang}`` or ``{lang, opts}`` — any
# brace-delimited info string is treated as executable. The Quarto docs
# enumerate {python}, {r}, {julia}, {ojs}; the generic form catches
# future / less-common langs (e.g. {sql}, {dot}).
_EXEC_FENCE_RE = re.compile(r"^```[ \t]*\{[^}\n]+\}", re.MULTILINE)

# Raw HTML elements we never want to render. Order doesn't matter; the
# regex is case-insensitive. We accept ``<details>`` and ``<summary>``
# (commonplace, inert); reject every active or styling-injection
# element below.
_HTML_BLACKLIST = ("script", "iframe", "object", "embed", "style", "link", "meta", "form")
_HTML_BAD_RE = re.compile(
    r"<\s*/?\s*(" + "|".join(_HTML_BLACKLIST) + r")\b",
    re.IGNORECASE,
)

# Quarto shortcodes — ``{{< something args >}}``. Outside a fenced code
# block these are templating directives we never want the LLM emitting.
_SHORTCODE_RE = re.compile(r"\{\{<.*?>\}\}", re.DOTALL)

# Fenced div headers — ``::: {.foo}`` or ``::: {.foo .bar #id}`` or the
# bare ``:::`` closing fence. We extract every ``.classname`` token from
# such headers and require each one to live in the allowlist.
_DIV_OPEN_RE = re.compile(r"^:::+\s*\{([^}]*)\}", re.MULTILINE)
_CLASS_TOKEN_RE = re.compile(r"\.([A-Za-z][\w-]*)")

# Allowlist sourced from Quarto's documented div semantics: callout
# blocks, dashboard layout primitives, the column system, tabsets,
# revealjs speaker notes, and asides. Anything else is rejected so the
# threat surface stays small.
_DIV_ALLOWLIST: frozenset[str] = frozenset(
    {
        # callouts
        "callout-note",
        "callout-tip",
        "callout-warning",
        "callout-caution",
        "callout-important",
        # dashboards
        "card",
        "valuebox",
        "toolbar",
        "sidebar",
        # column system / panel
        "column-screen",
        "column-screen-inset",
        "column-page",
        "column-body",
        "column-margin",
        # Quarto's side-by-side layout primitive — ``::: {.columns}``
        # wraps two or more ``::: {.column width="..."}`` blocks. Used
        # on slides to put a chart next to its bullets; in HTML it
        # falls back to a flex layout. The ``return_report`` tool
        # description teaches the agent to use these for slide layouts,
        # so they must be allowed at the validator boundary too.
        "columns",
        "column",
        "panel-tabset",
        "panel-input",
        "panel-sidebar",
        "panel-fill",
        # revealjs / asides
        "notes",
        "aside",
        "incremental",
        "fragment",
        # plain
        "grid",
    }
)

# Refs the agent may embed: charts under ``charts/<live_name>.vl.json``
# and datasets under ``data/<live_name>.parquet``. Body URIs name
# artifacts by live_name; the snapshot's pin map resolves each one to a
# frozen ``ArtifactRef`` at render time. Notebooks, data_objects, other
# reports, and any directory not in :data:`_ALLOWED_REF_DIRS` are
# rejected here.
_ALLOWED_REF_DIRS = ("charts", "data")
_REF_RE = re.compile(r"file://\./(?P<dir>[a-z_]+)/(?P<live_name>[A-Za-z0-9_-]+)\.(?P<ext>[A-Za-z0-9.]+)")

# Per-dir extension contract — mirrors the agent's tool description.
_EXPECTED_EXT_BY_DIR: dict[str, str] = {
    "charts": "vl.json",
    "data": "parquet",
}

# Any ``file://`` reference outside ``./charts/`` or ``./data/`` is
# suspicious — catches absolute paths, parent dirs, the legacy
# ``./.ockham/...`` content-addressed shape, and any other scheme.
_FOREIGN_FILE_RE = re.compile(r"file://(?!\./(?:charts|data)/)\S*")


class ValidationError(ValueError):
    """Raised when a report submission contains disallowed content."""


def validate_report_body(
    body: str,
    *,
    pin_map_keys: frozenset[str] | None = None,
) -> None:
    """Reject submissions whose content violates the threat-surface policy.

    Pure function. No I/O, no rewriting. Raises
    :class:`ValidationError` with a human-readable message on the first
    violation found.

    ``pin_map_keys`` is the set of ``live_name`` strings the snapshot's
    frozen pin map provides. When supplied, every ``file://./<dir>/<live_name>.<ext>``
    URI in the body must resolve to a key in this set — otherwise the
    body references an artifact the snapshot won't be able to render.
    Pass ``None`` (the default) to skip the subset check (used by the
    legacy/test paths that don't yet have a pin map handy).
    """
    if not isinstance(body, str):
        raise TypeError(f"body must be str, got {type(body).__name__}")
    if not body.strip():
        raise ValidationError("report body is empty")

    body_no_fences = _strip_fenced_code(body)

    m = _EXEC_FENCE_RE.search(body)
    if m:
        raise ValidationError(
            f"executable Quarto code fence is not allowed: {m.group(0)!r}. "
            "Reports embed pre-computed chart/dataset refs; live execution is out of scope."
        )

    m = _HTML_BAD_RE.search(body)
    if m:
        raise ValidationError(
            f"raw HTML element {m.group(1).lower()!r} is not allowed in report body. "
            f"Disallowed: {', '.join(_HTML_BLACKLIST)}."
        )

    m = _SHORTCODE_RE.search(body_no_fences)
    if m:
        raise ValidationError(
            f"Quarto shortcode is not allowed: {m.group(0)!r}. "
            "Shortcodes are a server-side templating feature outside the agent surface."
        )

    for m in _DIV_OPEN_RE.finditer(body):
        classes = _CLASS_TOKEN_RE.findall(m.group(1))
        for cls in classes:
            if cls not in _DIV_ALLOWLIST:
                raise ValidationError(
                    f"fenced div class {'.' + cls!r} is not in the allowlist. Allowed: {sorted(_DIV_ALLOWLIST)}."
                )

    for m in _FOREIGN_FILE_RE.finditer(body):
        raise ValidationError(
            f"foreign file URI not allowed: {m.group(0)!r}. "
            "Refs must be ``file://./charts/<live_name>.vl.json`` (chart) "
            "or ``file://./data/<live_name>.parquet`` (dataset)."
        )

    for m in _REF_RE.finditer(body):
        dir_name = m.group("dir")
        if dir_name not in _ALLOWED_REF_DIRS:
            raise ValidationError(
                f"embedded ref under {dir_name}/ is not allowed. "
                f"Embed only chart / dataset refs (dirs {_ALLOWED_REF_DIRS})."
            )
        ext = m.group("ext")
        expected_ext = _EXPECTED_EXT_BY_DIR[dir_name]
        if ext != expected_ext:
            raise ValidationError(
                f"embedded ref under {dir_name}/ has wrong extension {ext!r}; expected {expected_ext!r}."
            )
        if pin_map_keys is not None:
            live_name = m.group("live_name")
            if live_name not in pin_map_keys:
                raise ValidationError(
                    f"body references live_name {live_name!r} but the snapshot pin "
                    f"map has no entry for it. Rebuild via return_report so the "
                    f"framework can re-mint the pin map; edit_report cannot add "
                    f"new embeds to a frozen snapshot."
                )


def _strip_fenced_code(body: str) -> str:
    """Drop the *contents* of fenced code blocks for shortcode scanning.

    Shortcode-like ``{{< ... >}}`` strings inside a documentation fenced
    code block are inert. We strip them out here so the shortcode regex
    only catches the dangerous ones in prose.
    """
    out: list[str] = []
    in_fence = False
    fence_marker: str | None = None
    for line in body.splitlines(keepends=True):
        stripped = line.lstrip()
        if not in_fence and (stripped.startswith("```") or stripped.startswith("~~~")):
            in_fence = True
            fence_marker = stripped[:3]
            continue
        if in_fence and fence_marker and stripped.startswith(fence_marker):
            in_fence = False
            fence_marker = None
            continue
        if not in_fence:
            out.append(line)
    return "".join(out)
