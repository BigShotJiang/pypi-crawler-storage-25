"""Render a report snapshot to a chosen format via Quarto.

Top-level flow (one screen):

1. Parse snapshot bytes → ``(formats, body)``.
2. Pull each embedded ref's bytes via the workspace loader.
3. Stage refs into a per-render tempdir as SVG / markdown tables.
4. Rewrite ``file://./.ockham/...`` paths in the body to point at the
   staged files.
5. Compose Quarto YAML for the requested format and prepend it.
6. Write ``report.qmd``, invoke ``quarto render`` with a hardened
   environment (``--no-execute`` + wall-clock timeout + scrubbed env).
7. Read the produced output file from a private ``--output-dir`` and
   return the bytes.

The trust boundary (validation, refs allowlist) lives in
:mod:`validate`; it runs at *persist* time, before any of the above.
Renders are pure transformations over already-validated bytes.
"""

from __future__ import annotations

__all__ = [
    "QUARTO_VERSION",
    "RenderError",
    "RenderTimeout",
    "RenderInputs",
    "WorkspaceLoader",
    "available_formats_for_snapshot",
    "render",
    "templates_hash",
]

import asyncio
import base64
import hashlib
import io
import json
import re
import shutil
import subprocess
import tempfile
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml
from parsimony_agents.report_format import VALID_FORMATS, parse_snapshot

from server.api.workspace.report.brand import DEFAULT_BRAND, apply_brand_to_scss

# Bumped if/when we move Quarto. Participates in the cache key + ETag.
QUARTO_VERSION = "1.9.37"

_RENDER_TIMEOUT_SECONDS = 120.0
_TABLE_PREVIEW_ROWS = 50
_TEMPLATES_DIR = Path(__file__).parent / "templates"

# Formats whose output is a web document — get the Google Fonts
# ``<link>`` block injected via Quarto's ``header-includes``. PDF
# (typst) gets ``mainfont`` / ``monofont`` in its format YAML instead;
# PPTX gets fonts from the reference deck's master slides.
_HTML_LIKE_FORMATS: frozenset[str] = frozenset({"html", "dashboard", "revealjs"})

# Formats that paginate into fixed-size slides. The agent's tool description
# tells it to author H2-per-slide bodies for these, but the renderer also
# enforces a defensive budget: smaller tables, sized charts, ``.smaller`` on
# overflowing sections. Dashboard scrolls naturally and is excluded.
_SLIDE_FORMATS: frozenset[str] = frozenset({"revealjs", "pptx"})

# Per-slide content cap for tables — anything beyond this is truncated with
# a "Showing N of M" note. Tight enough to keep a 16:9 slide legible without
# shrinking the font to unreadable; the agent is expected to pre-size most
# tables to fit, this is the safety net.
_SLIDE_TABLE_MAX_ROWS = 6
_SLIDE_TABLE_MAX_COLS = 5

# Word-count threshold above which a slide section gets ``{.smaller}`` auto-
# attached to its H2. Counts words in prose + bullets, not in fenced div
# attributes or table cells (those have their own caps). 120 ≈ a screenful
# at the workspace 13px body density.
_SLIDE_SMALLER_WORD_THRESHOLD = 120

# Header-includes content injected into HTML-like renders via Quarto's
# ``header-includes`` YAML key. Why not in ``theme.scss``? Quarto
# 1.9.37's ``embed-resources: true`` pipeline silently drops custom
# theme.scss font-size declarations from the inlined stylesheet
# (verified empirically). ``header-includes`` is inlined verbatim, so
# it's the deterministic home for size + scrollbar rules.
#
# The block is split into three composable parts because the right
# answer for a slide deck is very different from the right answer for
# an HTML report. Revealjs gives slides a 40px base font (reveal.js's
# ``--r-main-font-size``); forcing the same 13px workspace density we
# use for the HTML iframe makes a deck illegible. Each format gets
# only the parts that apply to it — see :func:`_html_header_includes_for`.

# Universal — applied to every HTML-like format. Google Fonts so Inter
# / JetBrains Mono load even on hosts without them installed, plus
# scrollbar styling that mirrors ``web/src/index.css``. The iframe
# can't read the host shell's CSS custom properties, so we use fixed
# rgba values that read well on both light and dark themes.
# Inline ``@font-face`` declarations pointing at woff2 files staged
# into the per-render workdir from ``templates/fonts/``. We avoid the
# Google Fonts CDN because some networks (corporate proxies, captive
# portals, WSL2 setups) silently 404 the request, and Quarto's
# ``embed-resources: True`` then fails the whole render. With local
# files, ``embed-resources`` base64-inlines the woff2 bytes — the
# resulting HTML has no external font dependency.
_FONT_FACES: tuple[tuple[str, str, int], ...] = (
    ("Inter", "Inter-Regular.woff2", 400),
    ("Inter", "Inter-Medium.woff2", 500),
    ("Inter", "Inter-SemiBold.woff2", 600),
    ("Inter", "Inter-Bold.woff2", 700),
    ("JetBrains Mono", "JetBrainsMono-Regular.woff2", 400),
    ("JetBrains Mono", "JetBrainsMono-Medium.woff2", 500),
)

_HTML_FONT_LINKS: str = (
    "<style>\n"
    + "\n".join(
        "@font-face { "
        f"font-family: '{family}'; "
        f"font-weight: {weight}; "
        "font-style: normal; "
        "font-display: swap; "
        f"src: url('fonts/{filename}') format('woff2'); "
        "}"
        for family, filename, weight in _FONT_FACES
    )
    + "\n</style>"
)

_FONTS_DIR: Path = _TEMPLATES_DIR / "fonts"

_HTML_SCROLLBAR_CSS: str = (
    "<style>\n"
    "* { scrollbar-width: thin; "
    "scrollbar-color: rgba(127, 127, 127, 0.28) transparent; }\n"
    "*::-webkit-scrollbar { width: 3px; height: 3px; }\n"
    "*::-webkit-scrollbar-button { display: none; width: 0; height: 0; }\n"
    "*::-webkit-scrollbar-track { background: transparent; margin: 0; }\n"
    "*::-webkit-scrollbar-thumb { "
    "background-color: rgba(127, 127, 127, 0.3); "
    "border-radius: 0; border: none; }\n"
    "*::-webkit-scrollbar-thumb:hover { "
    "background-color: rgba(127, 127, 127, 0.55); }\n"
    "*::-webkit-scrollbar-corner { background: transparent; }\n"
    "</style>"
)

# Workspace-density typography — html + dashboard only. Anchors 1rem
# at 13px so every rem-derived Bootstrap size shrinks to match the
# workspace shell. NEVER applied to revealjs: slides use reveal.js's
# own 40px scale and its proportional heading hierarchy. Forcing 13px
# onto slides produces an unreadable deck.
_HTML_WORKSPACE_DENSITY: str = (
    "<style>\n"
    "html, body { font-size: 13px !important; line-height: 1.55 !important; }\n"
    # Heading scale — proportional, calm.
    "h1, .h1 { font-size: 1.4rem !important; margin-top: 1.4rem !important; "
    "margin-bottom: 0.5rem !important; line-height: 1.25 !important; }\n"
    "h2, .h2 { font-size: 1.2rem !important; margin-top: 1.15rem !important; "
    "margin-bottom: 0.4rem !important; line-height: 1.3 !important; }\n"
    "h3, .h3 { font-size: 1.075rem !important; margin-top: 0.9rem !important; "
    "margin-bottom: 0.35rem !important; }\n"
    "h4, .h4 { font-size: 1rem !important; margin-top: 0.75rem !important; "
    "margin-bottom: 0.3rem !important; }\n"
    "h5, .h5, h6, .h6 { font-size: 0.95rem !important; }\n"
    # Title block — proportional to the heading scale above.
    ".quarto-title-block { margin-bottom: 1.5rem !important; "
    "padding-bottom: 1rem !important; }\n"
    ".quarto-title-block .title { font-size: 1.5rem !important; "
    "font-weight: 700 !important; letter-spacing: -0.015em !important; "
    "line-height: 1.2 !important; }\n"
    ".quarto-title-block .subtitle { font-size: 0.95rem !important; "
    "font-weight: 400 !important; margin-top: 0.3rem !important; }\n"
    ".quarto-title-block .quarto-title-meta { font-size: 0.78rem !important; "
    "margin-top: 0.7rem !important; }\n"
    ".quarto-title-block .abstract { font-size: 0.85rem !important; "
    "margin-top: 1rem !important; max-width: 60ch; line-height: 1.55; }\n"
    # Body text — paragraphs, lists, tables locked to body density.
    "p, li, td, th { font-size: 1rem !important; }\n"
    "</style>"
)

# Slide-defense — revealjs only. Mirrored from theme.scss as insurance
# against Quarto's embed-resources pipeline dropping SCSS rules. Keeps
# overflowing content inside slide bounds, hooks up the ``.smaller``
# class the renderer auto-attaches to overflowing H2s, and the
# ``.scrollable`` opt-in. NO font-size rules here — those belong to
# reveal.js's own scale.
_HTML_SLIDE_DEFENSE: str = (
    "<style>\n"
    ".reveal .slides > section, .reveal .slides > section > section { "
    "overflow: hidden !important; max-height: 100% !important; }\n"
    ".reveal .slides > section.scrollable, "
    ".reveal .slides > section > section.scrollable { "
    "overflow-y: auto !important; }\n"
    ".reveal .slides > section.smaller, "
    ".reveal .slides > section > section.smaller { "
    "font-size: 75% !important; }\n"
    ".reveal .slides img, .reveal .slides svg { "
    "max-width: 100% !important; max-height: 70vh !important; "
    "object-fit: contain; }\n"
    "</style>"
)


def _html_header_includes_for(fmt: str) -> str:
    """Compose the right header-includes block for an HTML-like format.

    Every HTML-like format (html, dashboard, revealjs) gets the
    universal pieces — Google Fonts ``<link>``s + scrollbar styling.

    HTML + dashboard additionally get the workspace-density typography
    block (13px anchor + heading scale) so the iframe matches the host
    shell. Revealjs explicitly DOES NOT get that block — reveal.js
    drives slide typography from its own ``--r-main-font-size: 40px``
    and proportional heading scale, and the workspace-density
    ``!important`` rules would clobber both.

    Revealjs additionally gets the slide-defense block (overflow
    rules, ``.smaller`` / ``.scrollable`` class hooks) so an
    overflowing section is clipped or scrolled rather than escaping
    the slide box. Plain HTML / dashboard skip the slide-defense
    because the ``.reveal`` selectors are inert there.
    """
    parts = [_HTML_FONT_LINKS, _HTML_SCROLLBAR_CSS]
    if fmt in ("html", "dashboard"):
        parts.append(_HTML_WORKSPACE_DENSITY)
    if fmt == "revealjs":
        parts.append(_HTML_SLIDE_DEFENSE)
    return "\n".join(parts)


# Typst preamble prepended to every PDF render via ``header-includes``.
# Adds a quiet running footer with page count, a brand-accent rule under
# each H1, and tightens H2 spacing. The string is Typst source code that
# Quarto's typst format inlines verbatim.
_TYPST_PREAMBLE: str = f"""\
#set page(
  footer: context [
    #set text(size: 8pt, fill: rgb("#888888"))
    #set align(right)
    Page #counter(page).display() / #counter(page).final().last()
  ],
)

#show heading.where(level: 1): it => {{
  set text(weight: "bold")
  it.body
  v(-0.4em)
  line(length: 100%, stroke: 1.5pt + rgb("{DEFAULT_BRAND.primary}"))
  v(0.6em)
}}

#show heading.where(level: 2): it => {{
  set text(weight: "semibold")
  v(0.3em)
  it
  v(0.2em)
}}
"""

# Matches the full Markdown image syntax for a live-tree embed:
# ``![alt](file://./charts/<live_name>.vl.json)`` (chart) or
# ``![alt](file://./data/<live_name>.parquet)`` (dataset). The
# ``live_name`` resolves against the snapshot's frozen pin map to an
# ``ArtifactRef`` whose ``workspace_file_path`` keys the loader. Capturing
# the full token lets parquet refs be substituted with a markdown table
# (which would not survive being wrapped in ``![alt](...)``) and chart
# refs be substituted with a staged-asset image link plus a
# ``{#fig-rN .lightbox}`` attribute block for cross-references.
_REF_RE = re.compile(
    r"!\[(?P<alt>[^\]]*)\]\("
    r"file://\./(?P<dir>charts|data)/(?P<live_name>[A-Za-z0-9_-]+)\.(?P<ext>vl\.json|parquet)"
    r"\)"
)

# Body URI dir → canonical artifact kind. Used to assert the pin map's
# kind agrees with the URI's directory.
_DIR_TO_KIND: dict[str, str] = {"charts": "chart", "data": "dataset"}


WorkspaceLoader = Callable[[str], bytes | None]
"""Resolve a workspace-relative path to its raw bytes (or ``None``)."""


class RenderError(ValueError):
    """Quarto subprocess returned non-zero, or a ref couldn't be staged."""


class RenderTimeout(TimeoutError):
    """Quarto subprocess exceeded the wall-clock budget."""


@dataclass(frozen=True)
class RenderInputs:
    """The minimum the renderer needs to produce bytes for one format."""

    snapshot_bytes: bytes
    fmt: str
    workspace_loader: WorkspaceLoader


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


async def render(inputs: RenderInputs) -> bytes:
    """Render ``inputs`` to bytes (HTML/PDF/PPTX/Dashboard/Slides).

    Hands off the blocking subprocess to a worker thread so the event
    loop stays responsive.
    """
    if inputs.fmt not in VALID_FORMATS:
        raise RenderError(f"unknown format {inputs.fmt!r}; valid: {sorted(VALID_FORMATS)}")
    return await asyncio.to_thread(_render_sync, inputs)


def available_formats_for_snapshot(snapshot_bytes: bytes) -> list[str]:
    """Read the persisted ``formats`` list off snapshot bytes."""
    return parse_snapshot(snapshot_bytes.decode("utf-8")).formats


def templates_hash() -> str:
    """SHA-256 of every input that affects rendered output.

    Concatenates the on-disk templates (SCSS, reference.pptx, …), the
    brand-tokens repr, and every renderer-resident preamble string
    (the three composable HTML header-include parts + the typst PDF
    preamble). All of them end up baked into the output, so all of
    them must participate in the cache key — otherwise editing a
    ``<link>`` URL or a slide-defense rule would leave caches serving
    stale bytes.
    """
    h = hashlib.sha256()
    for fname in sorted(p.name for p in _TEMPLATES_DIR.iterdir() if p.is_file()):
        h.update(fname.encode("utf-8"))
        h.update((_TEMPLATES_DIR / fname).read_bytes())
    # Bundled fonts: any swap (new weight, format upgrade, replaced family)
    # changes byte-for-byte output, so font bytes participate in the key.
    for _family, filename, _weight in _FONT_FACES:
        h.update(filename.encode("utf-8"))
        h.update((_FONTS_DIR / filename).read_bytes())
    h.update(repr(DEFAULT_BRAND).encode("utf-8"))
    h.update(_HTML_FONT_LINKS.encode("utf-8"))
    h.update(_HTML_SCROLLBAR_CSS.encode("utf-8"))
    h.update(_HTML_WORKSPACE_DENSITY.encode("utf-8"))
    h.update(_HTML_SLIDE_DEFENSE.encode("utf-8"))
    h.update(_TYPST_PREAMBLE.encode("utf-8"))
    return h.hexdigest()


# ---------------------------------------------------------------------------
# The render itself — sync, runs on a thread
# ---------------------------------------------------------------------------


def _render_sync(inputs: RenderInputs) -> bytes:
    snap = parse_snapshot(inputs.snapshot_bytes.decode("utf-8"))
    if inputs.fmt not in snap.formats:
        raise RenderError(f"snapshot does not declare format {inputs.fmt!r}; declared: {snap.formats}")
    with tempfile.TemporaryDirectory(prefix="ockham-report-") as workdir_str:
        workdir = Path(workdir_str)
        staged_body = _stage_refs(snap.body, inputs.workspace_loader, workdir, fmt=inputs.fmt, pin_map=snap.pins)
        if inputs.fmt in _SLIDE_FORMATS:
            staged_body = _slide_safe_body(staged_body)
        yaml_header = _compose_yaml(inputs.fmt, workdir, title=snap.title, subtitle=snap.subtitle)
        qmd_text = yaml_header + "\n" + staged_body
        qmd_path = workdir / "report.qmd"
        qmd_path.write_text(qmd_text, encoding="utf-8")

        output_dir = workdir / "_out"
        output_dir.mkdir()

        _run_quarto(qmd_path, output_dir, workdir, fmt=inputs.fmt)

        out_path = _find_output(output_dir, fmt=inputs.fmt)
        if out_path is None:
            raise RenderError(
                f"Quarto succeeded but produced no output file for format {inputs.fmt!r}; check workdir layout"
            )
        return out_path.read_bytes()


# ---------------------------------------------------------------------------
# Ref staging — turn .ockham/... paths into local files
# ---------------------------------------------------------------------------


def _stage_refs(
    body: str,
    loader: WorkspaceLoader,
    workdir: Path,
    *,
    fmt: str,
    pin_map: dict[str, Any],
) -> str:
    """Inline-replace each ``![alt](file://./...)`` ref with a renderable form.

    Each ``file://./charts/<live_name>.vl.json`` or
    ``file://./data/<live_name>.parquet`` URI is resolved via
    ``pin_map`` (the snapshot's frozen ``live_name -> ArtifactRef`` map)
    to a canonical ``.ockham/...`` workspace path, which the loader
    reads. The pin map is the byte-stability anchor: renaming an
    embedded artifact after publication never changes what an old
    snapshot renders to, because the pin map travels with the bytes.

    Chart refs (vega-lite) become a staged SVG with the ``![alt](...)``
    image syntax preserved + a Quarto attribute block for cross-refs.
    Dataset refs are substituted wholesale with an inline markdown
    table (``alt`` becomes the caption when present).

    ``fmt`` selects the staging policy: slide formats get tight table
    caps and a width-constrained chart attribute (so a wide chart never
    eats the whole slide); HTML / PDF / dashboard keep the original
    behaviour.
    """
    assets_dir = workdir / "assets"
    assets_dir.mkdir(exist_ok=True)
    chart_idx = 0
    is_slide = fmt in _SLIDE_FORMATS

    def replace(match: re.Match[str]) -> str:
        nonlocal chart_idx
        dir_name = match.group("dir")
        live_name = match.group("live_name")
        ext = match.group("ext")
        alt = match.group("alt") or ""

        ref = pin_map.get(live_name)
        if ref is None:
            raise RenderError(
                f"body references live_name {live_name!r} but the snapshot pin "
                f"map has no entry for it; report bytes are inconsistent."
            )
        expected_kind = _DIR_TO_KIND[dir_name]
        if ref.kind != expected_kind:
            raise RenderError(
                f"body URI ./{dir_name}/{live_name}.{ext} implies kind={expected_kind!r} "
                f"but the pin map binds {live_name!r} to kind={ref.kind!r}; report "
                f"bytes are inconsistent."
            )
        rel = ref.workspace_file_path
        blob = loader(rel)
        if blob is None:
            raise RenderError(f"pinned artifact for live_name {live_name!r} not found on disk: {rel}")
        if rel.endswith(".vl.json"):
            svg_path = _stage_chart(rel, blob, assets_dir, is_slide=is_slide)
            # Cross-ref attribute block — idempotent and stable across
            # re-renders of the same body. ``@fig-r0`` works in prose.
            # Slide formats cap width so the chart leaves room for a
            # bullet column / caption / breathing space.
            width_attr = ' width="80%"' if is_slide else ""
            attrs = f'{{#fig-r{chart_idx} fig-align="center" .lightbox{width_attr}}}'
            chart_idx += 1
            return f"![{alt}]({svg_path}){attrs}"
        if rel.endswith(".parquet"):
            return _stage_parquet_as_table(rel, blob, caption=alt, is_slide=is_slide)
        raise RenderError(f"unsupported ref extension for staging: {rel}")

    return _REF_RE.sub(replace, body)


def _stage_chart(rel: str, blob: bytes, assets_dir: Path, *, is_slide: bool) -> str:
    """Render a vega-lite spec to SVG under ``assets/`` and return its rel-path.

    For slide formats the spec is normalized to slide-safe pixel
    dimensions (1280×720 viewport, leaving room for title + breathing
    space) only when the spec does not already pin ``width`` / ``height``.
    Charts the agent sized intentionally — small inset charts, square
    correlation matrices — are preserved as authored.
    """
    import vl_convert as vlc

    try:
        spec_text = blob.decode("utf-8")
        spec_obj = json.loads(spec_text)
        if is_slide:
            spec_obj = _normalize_vl_spec_for_slides(spec_obj)
            spec_text = json.dumps(spec_obj)
        svg = vlc.vegalite_to_svg(spec_text)
    except RenderError:
        raise
    except Exception as exc:  # noqa: BLE001
        raise RenderError(f"failed to render vega-lite chart {rel}: {exc}") from exc
    out = assets_dir / f"{Path(rel).stem}.svg"
    out.write_text(svg, encoding="utf-8")
    return f"assets/{out.name}"


def _normalize_vl_spec_for_slides(spec: object) -> object:
    """Add slide-safe default dimensions to a vega-lite spec.

    Mutates a copy of the top-level dict only when neither ``width`` nor
    ``height`` is set and the spec is not a layout container (those have
    their own sizing semantics that we should not override). 720×400 is
    a 9:5 box that fits inside the ``fig-width: 9`` / ``fig-height: 5``
    inch budget Quarto allocates per figure on a 16:9 slide.
    """
    if not isinstance(spec, dict):
        return spec
    # Layout containers — hconcat / vconcat / concat / facet / repeat — own
    # their child sizing; leave them alone.
    if any(k in spec for k in ("hconcat", "vconcat", "concat", "facet", "repeat")):
        return spec
    if "width" in spec or "height" in spec:
        return spec
    out = dict(spec)
    out["width"] = 720
    out["height"] = 400
    return out


def _stage_parquet_as_table(rel: str, blob: bytes, *, caption: str, is_slide: bool) -> str:
    """Read a parquet blob into a markdown pipe table.

    Pandoc converts pipe tables to native ``<a:tbl>`` for pptx and
    proper ``<table>`` for HTML — no format-family branching needed.
    The ``caption`` argument (from the surrounding ``![alt](...)``)
    becomes the table caption when present.

    Slide formats get a much tighter cap (``_SLIDE_TABLE_MAX_ROWS`` x
    ``_SLIDE_TABLE_MAX_COLS``) than flowing formats — a 50-row table on
    a 16:9 slide is unreadable.
    """
    try:
        import pandas as pd
    except ImportError as exc:  # pragma: no cover
        raise RenderError("pandas is required to stage dataset refs") from exc
    try:
        df = pd.read_parquet(io.BytesIO(blob))
    except Exception as exc:  # noqa: BLE001
        raise RenderError(f"failed to read parquet {rel}: {exc}") from exc
    if is_slide:
        return _markdown_table(
            df,
            caption=caption,
            max_rows=_SLIDE_TABLE_MAX_ROWS,
            max_cols=_SLIDE_TABLE_MAX_COLS,
        )
    return _markdown_table(df, caption=caption, max_rows=_TABLE_PREVIEW_ROWS, max_cols=None)


def _markdown_table(
    df,
    *,
    caption: str = "",
    max_rows: int,
    max_cols: int | None,
) -> str:
    """Render a DataFrame as a pipe-syntax markdown table (capped rows + cols).

    ``caption`` (from the surrounding ``![caption](...)``) becomes a
    Quarto-style table caption when non-empty. The output is wrapped in
    blank lines so it round-trips through pandoc's block parser as a
    table and not as text continuation of the preceding paragraph.

    Column truncation appends a single ``…`` column to signal the cut;
    row truncation appends a ``Showing first N of M rows`` note below
    the table (same convention pandoc figure captions use).
    """
    head = df.head(max_rows)
    all_cols = [str(c) for c in head.columns]
    truncated_cols = max_cols is not None and len(all_cols) > max_cols
    if truncated_cols:
        cols = all_cols[:max_cols] + ["…"]
        col_keys = head.columns[:max_cols]
    else:
        cols = all_cols
        col_keys = head.columns
    header = "| " + " | ".join(cols) + " |"
    sep = "| " + " | ".join("---" for _ in cols) + " |"
    rows: list[str] = []
    for row in head[col_keys].itertuples(index=False, name=None):
        cells = [_cell(v) for v in row]
        if truncated_cols:
            cells.append("…")
        rows.append("| " + " | ".join(cells) + " |")
    parts = [header, sep, *rows]
    if caption:
        parts.append(f": {caption}")
    table = "\n".join(parts)
    notes: list[str] = []
    if len(df) > max_rows:
        notes.append(f"Showing first {max_rows:,} of {len(df):,} rows.")
    if truncated_cols:
        notes.append(f"Showing first {max_cols} of {len(all_cols)} columns.")
    if notes:
        table = f"{table}\n\n*{' '.join(notes)}*"
    return f"\n\n{table}\n\n"


# ---------------------------------------------------------------------------
# Slide-safe body transform — defensive cap for misbehaving bodies
# ---------------------------------------------------------------------------


_H2_RE = re.compile(r"^(##)(\s+)(?P<rest>.+?)\s*$")
_H2_ATTR_RE = re.compile(r"\{[^}]*\}\s*$")


def _slide_safe_body(body: str) -> str:
    """Attach ``{.smaller}`` to H2 sections whose content overflows a slide.

    Walks the body H2 boundary by H2 boundary; for each section whose
    word count (prose + bullets + caption text — fenced-div markers and
    table separators excluded) exceeds
    :data:`_SLIDE_SMALLER_WORD_THRESHOLD`, and which does not already
    carry an attribute block, append ``{.smaller}`` to the H2 line.

    The transform is idempotent: a second pass over the same body
    produces identical output, because already-attributed H2 lines are
    skipped.

    Other styling controls (``{.scrollable}``, ``{.columns}`` fenced
    divs, ``::: {.notes}``) the agent authored are passed through
    untouched.
    """
    lines = body.split("\n")
    section_starts: list[int] = []
    for i, line in enumerate(lines):
        if _H2_RE.match(line):
            section_starts.append(i)
    if not section_starts:
        return body

    section_starts.append(len(lines))  # sentinel for last-section slice
    out_lines = list(lines)
    for start, end in zip(section_starts, section_starts[1:], strict=False):
        h2_line = out_lines[start]
        match = _H2_RE.match(h2_line)
        if match is None:
            continue
        if _H2_ATTR_RE.search(match.group("rest")):
            continue  # agent already attached an attribute block; respect it.
        section_body = "\n".join(out_lines[start + 1 : end])
        if _slide_section_word_count(section_body) > _SLIDE_SMALLER_WORD_THRESHOLD:
            out_lines[start] = f"{h2_line.rstrip()} {{.smaller}}"
    return "\n".join(out_lines)


def _slide_section_word_count(section: str) -> int:
    """Count words contributing to a slide's visual budget.

    Skips:
    - Table separator rows (``| --- |`` lines).
    - Fenced-div opener/closer lines (``:::`` ...).
    - Pipe-table column headers' separator dashes.
    - Image syntax (the rendered image, not the alt text, drives sizing).
    """
    total = 0
    in_speaker_notes = False
    for raw in section.split("\n"):
        line = raw.strip()
        if not line:
            continue
        if line.startswith(":::"):
            # ``::: {.notes}`` is presenter-only; its contents never
            # contribute to on-slide budget. Track the open/close.
            if ".notes" in line:
                in_speaker_notes = True
            elif in_speaker_notes and line == ":::":
                in_speaker_notes = False
            continue
        if in_speaker_notes:
            continue
        if line.startswith("|") and set(line.replace("|", "").strip()) <= {"-", " ", ":"}:
            continue  # table separator row
        if line.startswith("![") and "](" in line:
            continue  # image syntax — sized via fig-width, not word count
        total += len(line.split())
    return total


def _cell(value: object) -> str:
    if value is None:
        return ""
    try:
        import pandas as pd

        if isinstance(value, float):
            if pd.isna(value):
                return ""
            return f"{value:,.2f}"
        if isinstance(value, pd.Timestamp):
            return value.isoformat()
    except ImportError:  # pragma: no cover
        pass
    if isinstance(value, int):
        return f"{value:,}"
    text = str(value).replace("|", "\\|").replace("\n", " ")
    return text


# ---------------------------------------------------------------------------
# YAML composition — server-side, per format
# ---------------------------------------------------------------------------


def _compose_yaml(fmt: str, workdir: Path, *, title: str, subtitle: str) -> str:
    """Build the per-format Quarto YAML header at render time.

    Stages the SCSS theme (with brand tokens spliced) and — for PPTX —
    the reference deck into the per-render working dir. Composes the
    document-level metadata Quarto needs: ``title:``, optional
    ``subtitle:``, and a ``format: { <quarto_to>: <cfg> }`` dict
    (BRIEF §5: per-doc ``format:`` must be a dict; list shorthand is
    rejected). Adds a conditional ``header-includes`` block for fonts
    (HTML-like) or the typst preamble (PDF). Title and subtitle come
    from the snapshot's ``parsimony:`` frontmatter — body has no
    leading H1.
    """
    theme_scss = apply_brand_to_scss(
        (_TEMPLATES_DIR / "theme.scss").read_text(encoding="utf-8"),
        DEFAULT_BRAND,
    )
    (workdir / "theme.scss").write_text(theme_scss, encoding="utf-8")

    # Stage the woff2 font files alongside the qmd for HTML-like formats
    # so the ``@font-face url('fonts/<file>')`` declarations in
    # ``_HTML_FONT_LINKS`` resolve. ``embed-resources: True`` then
    # base64-inlines them into the output HTML; the rendered file has no
    # network dependency.
    if fmt in _HTML_LIKE_FORMATS:
        staged_fonts = workdir / "fonts"
        staged_fonts.mkdir(exist_ok=True)
        for _family, filename, _weight in _FONT_FACES:
            shutil.copy2(_FONTS_DIR / filename, staged_fonts / filename)

    # PPTX renders reference a server-resident deck via ``reference-doc``.
    # Stage it next to the qmd so Quarto's relative resolution finds it.
    if fmt == "pptx":
        ref = _TEMPLATES_DIR / "reference.pptx"
        if ref.is_file():
            shutil.copy2(ref, workdir / "reference.pptx")

    quarto_to = _QUARTO_TO_BY_FORMAT[fmt]
    payload: dict[str, object] = {"title": title}
    if subtitle:
        payload["subtitle"] = subtitle
    payload["format"] = {quarto_to: _format_block_for(fmt)}
    dumped = yaml.safe_dump(
        payload,
        sort_keys=False,
        allow_unicode=True,
        default_flow_style=False,
    ).rstrip("\n")

    # ``header-includes: |`` block scalar — hand-emitted so the multi-
    # line HTML / Typst source is preserved verbatim. yaml.safe_dump's
    # default folding turns newlines into spaces, which breaks both
    # injected payloads.
    includes: str | None = None
    if fmt in _HTML_LIKE_FORMATS:
        includes = _html_header_includes_for(fmt)
    elif fmt == "pdf":
        includes = _TYPST_PREAMBLE
    if includes is not None:
        block = "\n".join(f"  {line}" for line in includes.splitlines())
        dumped = f"{dumped}\nheader-includes: |\n{block}"

    return f"---\n{dumped}\n---"


def _format_block_for(fmt: str) -> dict[str, object]:
    """Return the per-format Quarto config dict.

    Single ``match`` keeps every format's choices on one screen — no
    registry, no per-format file, no strategy class. New formats land
    as a new arm; new knobs land as a new dict entry.
    """
    match fmt:
        case "html":
            return {
                # ``cosmo`` first gives a Bootstrap foundation; theme.scss
                # overrides via the ``!default`` cascade.
                "theme": ["cosmo", "theme.scss"],
                "embed-resources": True,
                "self-contained-math": True,
                # Navigation + readability.
                "toc": True,
                "toc-location": "right",
                "toc-depth": 3,
                "number-sections": True,
                "smooth-scroll": True,
                "back-to-top-navigation": True,
                "anchor-sections": True,
                # Figure / table polish.
                "lightbox": "auto",
                "fig-cap-location": "bottom",
                "tbl-cap-location": "top",
                # Link hygiene.
                "link-external-newwindow": True,
                "link-external-icon": True,
                # Code experience.
                "code-tools": False,
                "code-overflow": "scroll",
                "code-annotations": "hover",
            }
        case "pdf":
            # typst engine — bundled with Quarto, no external LaTeX.
            # Brand-driven typography lives here (mainfont/monofont
            # resolve to the names registered with the host typst
            # install; if missing, typst falls back silently). The
            # accent rule under H1 is in ``_TYPST_PREAMBLE``.
            return {
                "papersize": "us-letter",
                "margin": {
                    "x": DEFAULT_BRAND.page_margin,
                    "y": DEFAULT_BRAND.page_margin,
                },
                "mainfont": DEFAULT_BRAND.font_body_primary,
                "monofont": DEFAULT_BRAND.font_mono_primary,
                "fontsize": f"{DEFAULT_BRAND.font_size_body_pt}pt",
                "linestretch": DEFAULT_BRAND.line_height,
                "toc": True,
                "toc-depth": 2,
                "number-sections": True,
                "section-numbering": "1.1.a",
                "fig-cap-location": "bottom",
                "tbl-cap-location": "top",
            }
        case "pptx":
            return {
                # Reference deck staged into the workdir by _compose_yaml.
                # If absent (e.g. tests against an empty templates dir),
                # Quarto falls back to its bundled default.
                "reference-doc": "reference.pptx",
                "incremental": False,
                "slide-level": 2,
                # Figure budget — 9×5 inches fits inside a 16:9 slide
                # leaving room for title + caption. PPTX has no overflow
                # rescue (it just clips); the agent's H2-per-slide
                # authoring + this cap together keep figures legible.
                "fig-width": 9,
                "fig-height": 5,
            }
        case "dashboard":
            return {
                "theme": ["cosmo", "theme.scss"],
                "embed-resources": True,
                "orientation": "rows",
                "scrolling": True,
            }
        case "revealjs":
            # ``dark`` is reveal.js's built-in dark preset — gives us
            # slide geometry, transitions, and a dark surface to start
            # from. ``theme.scss`` then layers brand colors and the
            # structural rules (overflow: hidden, .scrollable opt-in,
            # H2 accent rule) on top. We do NOT use ``default`` here:
            # the previous version of this file forced slides to a
            # light palette regardless of brand; consolidating around
            # ``dark`` keeps slides visually consistent with the rest
            # of the workspace.
            return {
                "theme": ["dark", "theme.scss"],
                "embed-resources": True,
                "slide-level": 2,
                "transition": "slide",
                "transition-speed": "fast",
                "background-transition": "fade",
                "controls": True,
                "progress": True,
                "slide-number": "c/t",
                "history": True,
                # 16:9 viewport in pixels; ``fig-width`` / ``fig-height``
                # are inches at 96dpi (~864×480 in pixels) — enough
                # room for a chart + caption while leaving the title
                # bar visible. ``auto-stretch`` removed: it expanded
                # any figure to fill the slide, which is exactly the
                # overflow we want to prevent.
                "width": 1280,
                "height": 720,
                "fig-width": 9,
                "fig-height": 5,
                "code-line-numbers": False,
                "code-overflow": "scroll",
                "highlight-style": "github",
                "hash-type": "number",
                "fig-cap-location": "bottom",
            }
        case _:
            raise RenderError(f"no YAML block defined for format {fmt!r}")


# ---------------------------------------------------------------------------
# Subprocess invocation — hardened env, timeout, --no-execute
# ---------------------------------------------------------------------------


_QUARTO_BIN_CANDIDATES = ("quarto",)


def _quarto_executable() -> str:
    """Locate the Quarto binary on PATH, raising if missing."""
    for name in _QUARTO_BIN_CANDIDATES:
        path = shutil.which(name)
        if path:
            return path
    raise RenderError(
        "quarto binary not found on PATH. Install Quarto 1.9.37 (see terminal/Makefile target ``quarto-install``)."
    )


def _hardened_env(home: Path) -> dict[str, str]:
    """Build a minimal env for the Quarto subprocess (BRIEF §2).

    The parent process has API keys; the renderer must not. ``HOME``
    points at the per-render workdir so Quarto's ``$HOME`` pollution
    stays inside the tempdir, not the server's real home.
    """
    return {
        "HOME": str(home),
        "PATH": "/usr/local/bin:/usr/bin:/bin",
        "LANG": "C.UTF-8",
        "LC_ALL": "C.UTF-8",
        "TMPDIR": str(home),
        "XDG_CACHE_HOME": str(home / ".cache"),
        "XDG_DATA_HOME": str(home / ".local" / "share"),
        "XDG_CONFIG_HOME": str(home / ".config"),
    }


def _run_quarto(qmd_path: Path, output_dir: Path, home: Path, *, fmt: str) -> None:
    """Run ``quarto render`` with isolation + timeout.

    Maps the two failure modes the HTTP layer cares about:

    - :class:`RenderTimeout` — wall-clock budget exceeded.
    - :class:`RenderError` — non-zero exit; first stderr line attached.
    """
    cmd = [
        _quarto_executable(),
        "render",
        str(qmd_path),
        "--to",
        _QUARTO_TO_BY_FORMAT[fmt],
        "--no-execute",
        "--output-dir",
        str(output_dir),
    ]
    try:
        proc = subprocess.run(  # noqa: S603 — argv only, env scrubbed
            cmd,
            cwd=str(qmd_path.parent),
            env=_hardened_env(home),
            capture_output=True,
            text=True,
            timeout=_RENDER_TIMEOUT_SECONDS,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        raise RenderTimeout(f"Quarto render exceeded {_RENDER_TIMEOUT_SECONDS:.0f}s for format {fmt!r}") from exc
    if proc.returncode != 0:
        first_err = _first_error_line(proc.stderr) or _first_error_line(proc.stdout) or "(no stderr)"
        raise RenderError(f"Quarto render failed for format {fmt!r}: {first_err}")


def _first_error_line(stream: str) -> str:
    for line in (stream or "").splitlines():
        s = line.strip()
        if s and "error" in s.lower():
            return s
    for line in (stream or "").splitlines():
        s = line.strip()
        if s:
            return s
    return ""


# ---------------------------------------------------------------------------
# Output extraction
# ---------------------------------------------------------------------------


_OUTPUT_EXT_BY_FORMAT = {
    "html": ".html",
    "pdf": ".pdf",
    "pptx": ".pptx",
    "dashboard": ".html",
    "revealjs": ".html",
}

# Quarto's user-facing format names → the actual ``--to`` argument we
# pass. ``pdf`` maps to ``typst`` because Quarto's bundled typst engine
# is dependency-free and produces a PDF natively; the LaTeX path needs
# a separate TexLive install and is heavier than this subsystem needs.
_QUARTO_TO_BY_FORMAT = {
    "html": "html",
    "pdf": "typst",
    "pptx": "pptx",
    "dashboard": "dashboard",
    "revealjs": "revealjs",
}


def _find_output(output_dir: Path, *, fmt: str) -> Path | None:
    target_ext = _OUTPUT_EXT_BY_FORMAT[fmt]
    candidates = sorted(p for p in output_dir.rglob(f"*{target_ext}") if p.is_file())
    return candidates[0] if candidates else None


# ---------------------------------------------------------------------------
# Helpers re-exported for tests / debugging
# ---------------------------------------------------------------------------


def encode_for_etag(parts: tuple[str, ...]) -> str:
    """Build a stable ETag string from cache-key parts."""
    joined = ":".join(parts)
    return base64.urlsafe_b64encode(hashlib.sha256(joined.encode("utf-8")).digest()).decode("ascii").rstrip("=")
