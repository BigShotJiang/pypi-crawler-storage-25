"""In-process cache with in-flight coalescing for rendered reports.

The cache key is the render's full identity tuple — snapshot
``content_sha``, output format, Quarto version, and the hash of the
brand/templates inputs. Same key → same bytes, so the dict-level
``LRU`` is content-addressed and safe.

In-flight coalescing is the property that matters under refresh storms:
N concurrent requests for the same fresh ``(snapshot, format)`` block
on a single render's lock instead of firing N subprocesses. A naive
LRU doesn't help that — the entry only exists *after* the first render
completes.

Bounded by entry count. Lost on restart. Multi-worker coherence is a
future port to disk or Redis when we have the second caller.
"""

from __future__ import annotations

__all__ = ["RenderCache"]

import asyncio
from collections import OrderedDict
from collections.abc import Awaitable, Callable

CacheKey = tuple[str, str, str, str]
"""(content_sha, format, quarto_version, templates_hash)."""


class RenderCache:
    """Async LRU + in-flight coalescing keyed on render identity."""

    def __init__(self, *, capacity: int = 64) -> None:
        if capacity <= 0:
            raise ValueError("capacity must be positive")
        self._capacity = capacity
        self._entries: OrderedDict[CacheKey, bytes] = OrderedDict()
        self._inflight: dict[CacheKey, asyncio.Future[bytes]] = {}
        self._gate = asyncio.Lock()

    async def get_or_render(
        self,
        key: CacheKey,
        compute: Callable[[], Awaitable[bytes]],
    ) -> bytes:
        """Return cached bytes for ``key`` or run ``compute`` once.

        Concurrent callers with the same ``key`` rendezvous on a shared
        future instead of firing a parallel render. The first caller
        runs ``compute`` directly; later callers ``await`` the future.
        Cancellation of the first caller propagates through the future
        to all waiters.
        """
        async with self._gate:
            hit = self._entries.get(key)
            if hit is not None:
                self._entries.move_to_end(key)
                return hit
            running = self._inflight.get(key)
            if running is not None:
                # Release the lock before awaiting so other callers can
                # still hit the cache / register new inflight entries.
                fut = running
                owns = False
            else:
                fut = asyncio.get_running_loop().create_future()
                self._inflight[key] = fut
                owns = True

        if not owns:
            return await fut

        try:
            blob = await compute()
        except BaseException as exc:
            async with self._gate:
                self._inflight.pop(key, None)
            if not fut.done():
                fut.set_exception(exc)
            raise
        async with self._gate:
            self._entries[key] = blob
            self._entries.move_to_end(key)
            while len(self._entries) > self._capacity:
                self._entries.popitem(last=False)
            self._inflight.pop(key, None)
        if not fut.done():
            fut.set_result(blob)
        return blob

    def clear(self) -> None:
        self._entries.clear()
