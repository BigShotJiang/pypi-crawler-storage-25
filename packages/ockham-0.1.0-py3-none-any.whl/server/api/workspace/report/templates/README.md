# Report templates

Files in this directory are server-resident render assets. They are
copied into the per-render working directory by
`server.api.workspace.report.render._compose_yaml` and referenced from
the per-format Quarto YAML.

## Contract

- **Server-resident.** Snapshots intentionally do not bundle these
  files. The cost is portability (snapshots are not standalone-
  renderable); the win is automatic re-theming on next render after
  any template edit.
- **Hashed into the cache key.** `templates_hash()` in `../render.py`
  iterates this directory and includes every file's bytes in the
  digest. Bumping any template invalidates every cached render's ETag,
  forcing clients to re-fetch on next request. No manual cache flush
  needed.
- **One file per format family.**

| File | Used by | Notes |
|---|---|---|
| `theme.scss` | html, dashboard, revealjs | One SCSS file; `.reveal` selectors at the bottom force a light slide palette regardless of the rest of the brand. Uses `$brand-*` placeholders spliced by `report.brand.apply_brand_to_scss` at render time. |
| `reference.pptx` | pptx | PowerPoint master deck. Layouts come from Quarto's pandoc default; fonts are retypeset by the build script (see below). |

## Regenerating `reference.pptx`

The PPTX reference is a binary asset. Do not hand-edit. Regenerate
when brand tokens change or when Quarto/pandoc ships a new default
layout set:

```
make rebuild-pptx
```

The target does two things:

1. `quarto pandoc --print-default-data-file=reference.pptx` — pulls
   the unmodified default deck out of Quarto's bundled pandoc.
2. `uv run python scripts/build_reference_pptx.py` — walks every text
   frame in the slide master and layouts, rewriting `run.font.name`
   to `report.brand.DEFAULT_BRAND.font_body_primary` (mono runs route
   to `font_mono_primary`). Also patches the theme XML's `<a:latin>`
   so layouts that fall through to the theme also pick up brand
   typography.

The script is idempotent — running it twice produces the same bytes.
Git diffs on the binary file will be opaque; the build script is the
canonical regenerator.

## Adding a new template

If you add another file here, no changes to `render.py` are required
**unless** the file needs format-specific staging. `theme.scss` is
copied unconditionally; `reference.pptx` is staged only for `fmt ==
"pptx"`. New files should be added to the same staging branch in
`_compose_yaml`.

`templates_hash()` already iterates every file in the directory, so
new files automatically participate in cache invalidation.
