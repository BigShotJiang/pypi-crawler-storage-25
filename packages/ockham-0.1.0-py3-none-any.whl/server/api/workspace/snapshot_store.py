"""Storage primitives for content-addressed artifacts.

Kind-agnostic read/write over the namespace described in
``CONTENT_ADDRESSED_ARTIFACTS_PLAN.md`` §2.3:

::

    .ockham/<kind>s/<logical_id>/curation.json   # editable sidecar
    .ockham/<kind>s/<logical_id>/log.jsonl       # append-only history
    .ockham/<kind>s/<logical_id>/<content_sha>.<ext>  # immutable snapshots

Notebooks live in a flat namespace ``.ockham/notebooks/<sha>.py`` because
``logical_id == content_sha`` for them — there's only ever one snapshot
file per notebook source, so the directory layer is unnecessary.

All read/write addressing happens through :class:`ArtifactRef` (kind +
logical_id + content_sha) plus the (kind, logical_id) tuple for the
sidecars. The store does not interpret the bytes — that's the caller's
job (e.g. parquet codec for datasets, JSON for charts).

Concurrency: ``append_log`` takes a POSIX advisory lock on the log file
during read-modify-write so simultaneous writers don't interleave or
overwrite. Single-process locking is enough for the current
single-server deployment; multi-server deployments would need a
shared-FS or coordinated lock.
"""

from __future__ import annotations

__all__ = [
    "AnyCuration",
    "Curation",
    "DataObjectCuration",
    "LogEntry",
    "append_dedup_jsonl",
    "append_log",
    "curation_path",
    "latest_content_sha",
    "log_path",
    "read_curation",
    "read_log",
    "read_snapshot",
    "snapshot_dir",
    "write_curation",
    "write_snapshot",
]

import asyncio
import fcntl
import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Literal

from parsimony_agents.identity import ArtifactRef, SnapshotKind
from pydantic import BaseModel, ConfigDict, Field

from server.api.workspace.service import (
    normalize_workspace_file_path,
    read_workspace_file_bytes,
    write_workspace_file_bytes,
)
from server.api.workspace.storage import (
    get_workspace_blob_storage,
    workspace_local_tree_path,
)

# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------


class Curation(BaseModel):
    """Editable curation sidecar for notebook/dataset/chart/report (§2.4).

    User-facing identity: title, description, tags, notes, ``live_name``.
    ``variable_name`` is a *recipe* field on Dataset/Chart only — it
    participates in ``logical_id`` and is required for ``refresh`` to
    re-extract the kernel variable. The PATCH endpoint rejects edits to
    it (changing the variable name would invalidate identity); other
    kinds carry ``None``.

    The PATCH endpoint allowlists which kinds may edit which fields. The
    ``kind`` field is typed wide (:data:`SnapshotKind`) for callsite
    convenience; ``data_object`` writes go through
    :class:`DataObjectCuration` instead and never instantiate this model.
    """

    model_config = ConfigDict(extra="ignore")

    kind: SnapshotKind
    logical_id: str
    title: str = ""
    description: str = ""
    tags: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)
    live_name: str | None = None
    variable_name: str | None = None
    created_at: str = ""
    updated_at: str = ""


class DataObjectCuration(BaseModel):
    """Frozen provenance sidecar for ``data_object`` (§2.4).

    Mirrors :class:`parsimony.result.Provenance` — populated by the
    connector persister at fetch time, never user-edited (the PATCH
    endpoint rejects ``kind="data_object"``). Existing alongside the
    arrow metadata embedded in the parquet bytes: the parquet remains
    the canonical truth (travels with the file); this sidecar is a
    derived index that lets ref-enrichment and the detail tab read
    provenance with a sync JSON read instead of opening the parquet.
    """

    model_config = ConfigDict(extra="ignore")

    kind: Literal["data_object"] = "data_object"
    logical_id: str
    source: str = ""
    source_description: str = ""
    params: dict[str, Any] = Field(default_factory=dict)
    fetched_at: str | None = None
    properties: dict[str, Any] = Field(default_factory=dict)
    created_at: str = ""
    updated_at: str = ""


AnyCuration = Curation | DataObjectCuration


class LogEntry(BaseModel):
    """Single line of ``log.jsonl`` (§2.5).

    ``inputs`` carries the upstream ``content_sha`` values captured at
    the moment of this snapshot — walking back to a specific line
    reproduces the exact bytes that flowed in. Schema of ``inputs``
    varies by kind (see plan §2.5).
    """

    model_config = ConfigDict(extra="ignore")

    ts: str
    content_sha: str
    inputs: dict[str, Any] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# Path helpers
# ---------------------------------------------------------------------------


def snapshot_dir(kind: SnapshotKind, logical_id: str) -> str:
    """Workspace-relative directory for a logical artifact's snapshots.

    One layout for every kind: ``.ockham/<kind>s/<logical_id>/``. Inside
    it sit the immutable ``<content_sha>.<ext>`` snapshot files plus the
    sidecars (``log.jsonl`` always, ``curation.json`` for kinds that
    have a human-facing identity).
    """
    return f".ockham/{kind}s/{logical_id}"


def curation_path(kind: SnapshotKind, logical_id: str) -> str:
    """Workspace-relative path to ``curation.json`` for a logical artifact.

    Every kind has a curation sidecar under the unified model: notebook/
    dataset/chart/report carry user-editable metadata (:class:`Curation`)
    and ``data_object`` carries a frozen provenance record
    (:class:`DataObjectCuration`). The schema in the file differs by
    kind; the path layout is uniform.
    """
    return f"{snapshot_dir(kind, logical_id)}/curation.json"


def log_path(kind: SnapshotKind, logical_id: str) -> str:
    """Workspace-relative path to ``log.jsonl`` for a logical artifact.

    Every kind has a per-logical_id log: identical-content republishes
    return the existing version, distinct content appends a new line.
    """
    return f"{snapshot_dir(kind, logical_id)}/log.jsonl"


# ---------------------------------------------------------------------------
# Snapshot read/write
# ---------------------------------------------------------------------------


async def write_snapshot(user_id: str, workspace_id: str, ref: ArtifactRef, blob: bytes) -> None:
    """Idempotent write to ``ref.workspace_file_path``.

    If a file already exists at the target path with the same bytes, the
    write is a no-op. (We don't compare bytes — content_sha addressing
    means matching path implies matching bytes.) Callers must compute
    ``content_sha`` from the same bytes they pass here.
    """
    rel = ref.workspace_file_path
    storage = get_workspace_blob_storage()
    key = f"{user_id}/{workspace_id}/{rel}"
    if await storage.exists(key):
        return
    await write_workspace_file_bytes(user_id, workspace_id, rel, blob, allow_ockham=True)


async def read_snapshot(user_id: str, workspace_id: str, ref: ArtifactRef) -> bytes | None:
    """Read snapshot bytes; return ``None`` if missing."""
    return await read_workspace_file_bytes(user_id, workspace_id, ref.workspace_file_path, allow_ockham=True)


# ---------------------------------------------------------------------------
# Curation read/write
# ---------------------------------------------------------------------------


async def read_curation(user_id: str, workspace_id: str, kind: SnapshotKind, logical_id: str) -> AnyCuration | None:
    """Read curation sidecar; ``None`` if absent or malformed.

    Returns :class:`DataObjectCuration` for ``kind="data_object"``,
    :class:`Curation` for every other kind. Caller branches on the
    concrete type (or matches on ``kind``) when reading kind-specific
    fields.
    """
    rel = curation_path(kind, logical_id)
    raw = await read_workspace_file_bytes(user_id, workspace_id, rel, allow_ockham=True)
    if raw is None:
        return None
    try:
        data = json.loads(raw.decode("utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError):
        return None
    model: type[BaseModel] = DataObjectCuration if kind == "data_object" else Curation
    try:
        return model.model_validate(data)  # type: ignore[return-value]
    except Exception:
        return None


async def write_curation(
    user_id: str,
    workspace_id: str,
    kind: SnapshotKind,
    logical_id: str,
    curation: AnyCuration,
) -> None:
    """Write curation sidecar; bumps ``updated_at`` and preserves
    ``created_at`` from any existing record."""
    if curation.kind != kind or curation.logical_id != logical_id:
        raise ValueError("curation kind/logical_id must match arguments")
    if kind == "data_object" and not isinstance(curation, DataObjectCuration):
        raise ValueError("data_object curation must be a DataObjectCuration")
    if kind != "data_object" and not isinstance(curation, Curation):
        raise ValueError("non-data_object curation must be a Curation")
    now = datetime.now(UTC).isoformat(timespec="seconds").replace("+00:00", "Z")
    existing = await read_curation(user_id, workspace_id, kind, logical_id)
    created_at = existing.created_at if existing and existing.created_at else now
    out = curation.model_copy(update={"created_at": created_at, "updated_at": now})
    blob = json.dumps(out.model_dump(mode="json"), sort_keys=True).encode("utf-8")
    rel = curation_path(kind, logical_id)
    await write_workspace_file_bytes(user_id, workspace_id, rel, blob, allow_ockham=True)


# ---------------------------------------------------------------------------
# Log read/append
# ---------------------------------------------------------------------------


async def read_log(user_id: str, workspace_id: str, kind: SnapshotKind, logical_id: str) -> list[LogEntry]:
    """Read ``log.jsonl`` as a list of :class:`LogEntry` (oldest first).

    Missing or empty file → empty list. Malformed lines are skipped.
    """
    rel = log_path(kind, logical_id)
    raw = await read_workspace_file_bytes(user_id, workspace_id, rel, allow_ockham=True)
    if not raw:
        return []
    out: list[LogEntry] = []
    for line in raw.decode("utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            data = json.loads(line)
        except json.JSONDecodeError:
            continue
        try:
            out.append(LogEntry.model_validate(data))
        except Exception:
            continue
    return out


async def append_log(
    user_id: str,
    workspace_id: str,
    kind: SnapshotKind,
    logical_id: str,
    entry: LogEntry,
) -> int:
    """Append ``entry`` to ``log.jsonl`` and return its 1-indexed position.

    Same-content idempotence is the contract: any prior entry sharing
    ``entry.content_sha`` short-circuits the write and the function
    returns the existing entry's index. The returned int is the
    artifact's *version* — the position of this snapshot in the
    workspace-local history of its logical artifact. ``v1`` is the
    first publish; ``v2`` is the next distinct content_sha; an
    identical-content republish leaves the version unchanged.

    Atomic via :func:`fcntl.flock` on a sentinel sibling file (§2.5
    concurrency note).
    """
    rel = normalize_workspace_file_path(log_path(kind, logical_id), allow_ockham=True)
    fs_path = workspace_local_tree_path(user_id, workspace_id) / rel
    return await asyncio.to_thread(append_dedup_jsonl, fs_path, entry.content_sha, entry.model_dump(mode="json"))


def append_dedup_jsonl(fs_path: Path, content_sha: str, payload: dict[str, Any]) -> int:
    """Append a JSONL line keyed by ``content_sha`` with full dedup.

    The on-disk shape is one JSON object per line, each carrying a
    ``content_sha`` field. If any prior line already shares
    ``content_sha`` the function short-circuits and returns its
    1-indexed position. Otherwise it appends and returns the new
    1-indexed position.

    Atomic via :func:`fcntl.flock` on a sentinel sibling
    (``<file>.lock``); the data file is opened via fresh handles
    inside the lock so we never read past stale buffer-cache state
    from a previous writer. Used by :func:`append_log` (per-artifact
    snapshot history) and by
    :mod:`server.api.workspace.notebook_history` (per-working-copy
    notebook history) — both share the same flock+dedup contract,
    only the on-disk path and the line schema differ.
    """
    fs_path.parent.mkdir(parents=True, exist_ok=True)
    lock_path = fs_path.parent / (fs_path.name + ".lock")
    with open(lock_path, "ab") as lock_f:
        fcntl.flock(lock_f.fileno(), fcntl.LOCK_EX)
        try:
            existing = fs_path.read_bytes() if fs_path.exists() else b""
            shas = _content_shas_from_jsonl(existing.decode("utf-8"))
            if content_sha in shas:
                return shas.index(content_sha) + 1
            line = json.dumps(payload, sort_keys=True)
            with open(fs_path, "ab") as f:
                if existing and not existing.endswith(b"\n"):
                    f.write(b"\n")
                f.write(line.encode("utf-8"))
                f.write(b"\n")
                f.flush()
            return len(shas) + 1
        finally:
            fcntl.flock(lock_f.fileno(), fcntl.LOCK_UN)


def _content_shas_from_jsonl(jsonl_text: str) -> list[str]:
    """Extract ``content_sha`` values from JSONL, skipping malformed lines."""
    out: list[str] = []
    for line in jsonl_text.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        try:
            data = json.loads(stripped)
        except json.JSONDecodeError:
            continue
        sha = data.get("content_sha")
        if isinstance(sha, str):
            out.append(sha)
    return out


async def latest_content_sha(user_id: str, workspace_id: str, kind: SnapshotKind, logical_id: str) -> str | None:
    """Convenience: ``content_sha`` of the most recent log entry, or ``None``.

    Per §2.6, an artifact is "not yet persisted" when its log is missing
    or empty; this returns ``None`` in both cases.
    """
    entries = await read_log(user_id, workspace_id, kind, logical_id)
    if not entries:
        return None
    return entries[-1].content_sha
