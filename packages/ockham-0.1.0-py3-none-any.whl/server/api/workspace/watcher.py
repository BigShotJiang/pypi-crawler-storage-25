"""Per-workspace filesystem watcher.

A single :class:`WorkspaceWatcher` per active workspace observes the on-disk
tree (``WORKSPACE_ROOT/{user_id}/{workspace_id}/``) and fans out
``(path, etag, op)`` events to all current subscribers.

Why this exists
---------------

The filesystem is the source of truth. Anyone — agent, REST PUT, drag-drop
upload, future external editor in a desktop wrapper, MCP server — that writes
into the workspace tree produces the same observable: bytes change at a path.
The watcher is the universal source of file-change events; it has no opinion
about who wrote.

Lifecycle
---------

Watchers are reference-counted by SSE subscribers. The first subscriber starts
the watcher; the last subscriber's disconnect schedules a grace-period stop.
Idle workspaces consume no resources.

Coalescing
----------

A short coalescing window (``COALESCE_MS``) collapses sequential events for the
same path. This neutralizes atomic-rename two-phase writes (``foo.tmp`` →
``foo``) which would otherwise look like two events.

Filtering
---------

The framework's private ``.ockham/`` namespace is filtered by default.
``.tmp`` files (atomic-write scratch) are always filtered: subscribers should
never see them.
"""

from __future__ import annotations

import asyncio
import contextlib
import time
from collections.abc import AsyncIterator
from pathlib import Path
from typing import Literal

from watchfiles import Change, awatch

from server.api.workspace.etag import compute_etag
from server.api.workspace.storage import workspace_local_tree_path

RegistryKey = tuple[str, str]


def _read_etag_or_deleted(root: Path, rel: str) -> tuple[Literal["ok", "gone"], str | None]:
    """Read path bytes and return etag, or *gone* if the file disappeared."""
    try:
        return "ok", compute_etag((root / rel).read_bytes())
    except FileNotFoundError:
        return "gone", None
    except OSError:
        raise


Op = Literal["created", "modified", "deleted"]

COALESCE_MS = 50
GRACE_STOP_MS = 30_000
QUEUE_MAX = 256


class FileEvent(dict):
    """JSON-serializable event payload: ``{path, etag, op, at}``.

    ``etag`` is ``None`` for ``deleted`` events (no bytes to fingerprint).
    ``at`` is unix-epoch seconds (float).
    """


def _change_to_op(change: Change) -> Op:
    if change is Change.added:
        return "created"
    if change is Change.modified:
        return "modified"
    return "deleted"


def _is_filtered(rel: str, *, include_ockham: bool) -> bool:
    if rel.endswith(".tmp"):
        return True
    if rel.startswith(".ockham/notebook-state/"):
        return False
    return not include_ockham and (rel == ".ockham" or rel.startswith(".ockham/"))


class WorkspaceWatcher:
    """One watcher task per workspace, fanning out events to subscriber queues."""

    def __init__(
        self,
        root: Path,
        *,
        include_ockham: bool = False,
        registry_key: RegistryKey | None = None,
    ) -> None:
        self._root = root.resolve()
        self._include_ockham = include_ockham
        self._registry_key = registry_key
        self._subscribers: set[asyncio.Queue[FileEvent]] = set()
        self._task: asyncio.Task[None] | None = None
        self._stop_event = asyncio.Event()
        self._stop_handle: asyncio.TimerHandle | None = None
        self._coalesce: dict[str, tuple[Op, float]] = {}
        self._coalesce_task: asyncio.Task[None] | None = None

    @property
    def subscriber_count(self) -> int:
        return len(self._subscribers)

    def add_subscriber(self) -> asyncio.Queue[FileEvent]:
        q: asyncio.Queue[FileEvent] = asyncio.Queue(maxsize=QUEUE_MAX)
        self._subscribers.add(q)
        if self._stop_handle is not None:
            self._stop_handle.cancel()
            self._stop_handle = None
        if self._task is None or self._task.done():
            self._stop_event = asyncio.Event()
            self._task = asyncio.create_task(self._run(), name=f"watcher:{self._root.name}")
        return q

    def remove_subscriber(self, q: asyncio.Queue[FileEvent]) -> None:
        self._subscribers.discard(q)
        if not self._subscribers and self._stop_handle is None:
            loop = asyncio.get_running_loop()
            self._stop_handle = loop.call_later(GRACE_STOP_MS / 1000, self._schedule_stop)

    def _schedule_stop(self) -> None:
        self._stop_handle = None
        if self._subscribers:
            return
        self._stop_event.set()

    async def _run(self) -> None:
        # Do not create the workspace tree from a read-only subscription. Wait
        # until the directory exists (e.g. after first materialize / write).
        while not self._root.is_dir():
            if self._stop_event.is_set():
                return
            await asyncio.sleep(0.2)
        if self._coalesce_task is None or self._coalesce_task.done():
            self._coalesce_task = asyncio.create_task(self._flush_loop(), name=f"watcher-flush:{self._root.name}")
        try:
            async for changes in awatch(str(self._root), stop_event=self._stop_event, recursive=True):
                for change, abs_path in changes:
                    self._record(change, Path(abs_path))
        except asyncio.CancelledError:
            raise
        finally:
            if self._coalesce_task is not None and not self._coalesce_task.done():
                self._coalesce_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await self._coalesce_task
            if self._registry_key is not None:
                async with _REGISTRY_LOCK:
                    existing = _REGISTRY.get(self._registry_key)
                    if existing is self:
                        _REGISTRY.pop(self._registry_key, None)

    def _record(self, change: Change, abs_path: Path) -> None:
        try:
            rel = abs_path.relative_to(self._root).as_posix()
        except ValueError:
            return
        if not rel:
            return
        if _is_filtered(rel, include_ockham=self._include_ockham):
            return
        if abs_path.exists() and abs_path.is_dir():
            return
        self._coalesce[rel] = (_change_to_op(change), time.time())

    async def _flush_loop(self) -> None:
        try:
            while not self._stop_event.is_set():
                await asyncio.sleep(COALESCE_MS / 1000)
                if not self._coalesce:
                    continue
                pending = list(self._coalesce.items())
                self._coalesce.clear()
                for rel, (op, at) in pending:
                    await self._emit(rel, op, at)
        except asyncio.CancelledError:
            return

    async def _emit(self, rel: str, op: Op, at: float) -> None:
        etag: str | None = None
        if op != "deleted":
            try:
                st, tag = await asyncio.to_thread(_read_etag_or_deleted, self._root, rel)
            except OSError:
                return
            if st == "gone":
                op = "deleted"
            else:
                etag = tag
        event = FileEvent(path=rel, etag=etag, op=op, at=at)
        for q in list(self._subscribers):
            try:
                q.put_nowait(event)
            except asyncio.QueueFull:
                with contextlib.suppress(asyncio.QueueEmpty):
                    q.get_nowait()
                with contextlib.suppress(asyncio.QueueFull):
                    q.put_nowait(event)


_REGISTRY: dict[tuple[str, str], WorkspaceWatcher] = {}
_REGISTRY_LOCK = asyncio.Lock()


def _workspace_root(user_id: str, workspace_id: str) -> Path:
    """Same on-disk root the agent uses after ``materialize_workspace_to_disk``."""

    return workspace_local_tree_path(user_id, workspace_id)


async def _get_or_create(user_id: str, workspace_id: str) -> WorkspaceWatcher:
    key = (user_id, workspace_id)
    async with _REGISTRY_LOCK:
        watcher = _REGISTRY.get(key)
        if watcher is None:
            watcher = WorkspaceWatcher(_workspace_root(user_id, workspace_id), registry_key=key)
            _REGISTRY[key] = watcher
        return watcher


async def subscribe(user_id: str, workspace_id: str) -> AsyncIterator[FileEvent]:
    """Yield :class:`FileEvent` dicts for *workspace_id* until the consumer stops.

    Use as ``async for event in subscribe(user_id, workspace_id): ...``. The
    underlying watcher is started lazily on the first subscriber and stopped
    after the last subscriber disconnects (with a grace period).
    """
    watcher = await _get_or_create(user_id, workspace_id)
    q = watcher.add_subscriber()
    try:
        while True:
            event = await q.get()
            yield event
    finally:
        watcher.remove_subscriber(q)


async def reset_for_tests() -> None:
    """Test-only: stop and forget every watcher.

    Prefer cooperative ``stop_event``; cancel tasks so this cannot hang if
    ``awatch`` is slow to observe the stop (e.g. on some filesystems).
    """
    async with _REGISTRY_LOCK:
        to_stop: list[WorkspaceWatcher] = list(_REGISTRY.values())
        _REGISTRY.clear()
    for w in to_stop:
        w._stop_event.set()
        if w._coalesce_task is not None and not w._coalesce_task.done():
            w._coalesce_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await w._coalesce_task
        if w._task is not None and not w._task.done():
            w._task.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await w._task
