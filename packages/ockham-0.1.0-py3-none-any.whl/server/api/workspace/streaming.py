"""Stream workspace terminal messages through the agent + chunk pipeline.

Pipeline (one user turn):

    user_message  ─►  agent.run()  ─►  framework_event_to_stream_chunks  ─►  per-event handling

Per-event handling has three concerns, in this order:

    1. Side-effects: persist file-backed events (artifacts, notebooks,
       utility outputs) to the workspace tree.
    2. Wire emission: yield an SSE chunk to the live stream. Every
       file-backed event surfaces as exactly one
       :class:`server.api.streaming.FileRefChunk`; the wire never
       carries artifact payloads or large blobs.
    3. Persistence: append a record to the terminal's JSONL transcript
       so the conversation can be reloaded on a new tab/session.

File-backed model
-----------------

The workspace tree is the source of truth. Two namespaces coexist:

* **Visible (agent-owned).** Artifacts the user opens and reasons about
  (notebooks, datasets, charts) live at agent-chosen paths under the
  workspace root. Each artifact is a single live file; updates
  overwrite. No per-call snapshots.
* **Private (framework-owned).** ``.ockham/`` is the framework's
  namespace for plumbing (utility tool output snapshots, return-tool
  artifact snapshots, transcripts, workspace metadata). Hidden from
  the file tree by default.

Path safety is enforced once, at the storage boundary
(``service.write_workspace_file_bytes`` →
``service.normalize_workspace_file_path``).

Streaming invariants:

* Text/Reasoning ``delta=True`` chunks (incremental) → emitted to SSE,
  accumulated for the final transcript record. ``delta=False`` chunks
  (full assembled message from ``litellm.stream_chunk_builder``) are
  **never** re-emitted (the frontend already has the complete content)
  and are **never** persisted as their own record (would duplicate the
  text the LLM sees on the next turn via :func:`build_workspace_agent_context`).
* Utility-output snapshots are keyed by ``tool_call_id`` so the loading
  and completed events for one call overwrite the same private file.
"""

from __future__ import annotations

import contextlib
import hashlib
import time
import uuid
from collections.abc import AsyncGenerator, Awaitable, Callable
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from parsimony_agents import deserialize_notebook, notebook_state_cache_key, serialize_notebook
from parsimony_agents.agent.agent import Agent
from parsimony_agents.agent.cancellation import CancellationRequest
from parsimony_agents.agent.events import ToolEvent
from parsimony_agents.agent.models import AgentContext
from parsimony_agents.agent.outputs import UtilityToolOutput
from parsimony_agents.artifacts import Chart, Dataset, Report
from parsimony_agents.execution.outputs import KernelOutput
from parsimony_agents.identity import ArtifactRef
from parsimony_agents.messages import ContinueRequest, Reasoning, Text
from parsimony_agents.notebook import Script, ScriptPreview
from parsimony_agents.notebook_io import encode_notebook_state

from server.api.executor_cache import set_cached_executor_id
from server.api.streaming import (
    CancellationChunk,
    ContinueRequestChunk,
    ErrorChunk,
    FileRefChunk,
    FinalChunk,
    MessageMetadata,
    NotificationChunk,
    PendingFileRef,
    ReasoningDeltaChunk,
    SendMessageRequest,
    SystemToolChunk,
    TerminalMessage,
    TextDeltaChunk,
    framework_event_to_stream_chunks,
)
from server.api.workspace import service
from server.api.workspace.artifact_registry import persist_return_artifact
from server.api.workspace.etag import compute_etag, notebook_view_etag
from server.api.workspace.session_state_build import build_session_state
from server.api.workspace.terminal_runs import unregister_active_run
from server.api.workspace.viewers import file_ref, require_kind, viewer_payload_for_path
from server.core.cache import get_cache
from server.core.monitoring import get_logger
from server.execution import RemoteCodeExecutor

logger = get_logger("SYSTEM")


async def stream_workspace_conversation(
    request: SendMessageRequest,
    agent: Agent,
    ctx: AgentContext,
    *,
    user_id: str,
    workspace_id: str,
    terminal_id: str,
    local_dir: Path,
    cancellation: CancellationRequest | None = None,
    turn_response_id: str | None = None,
    on_discard_kernel: Callable[[], Awaitable[None]] | None = None,
    llm_message: str | None = None,
) -> AsyncGenerator[str, None]:
    """Run the agent with *ctx*; cwd is the materialized workspace tree."""
    _files: list[dict[str, Any]] | None = None
    if request.files is not None:
        _files = [f.model_dump(mode="json") for f in request.files]

    user_message = Text(
        content=llm_message if llm_message is not None else request.message,
        files=_files,
        wrap_in_tags="user_message",
    )
    response_id = turn_response_id or str(uuid.uuid4())
    start_time = time.time()
    is_continuation = request.message.strip().lower() == "continue"

    scoped_session_id = f"ws-{workspace_id}-{terminal_id}"
    await agent.code_executor.set_cwd(str(local_dir), session_id=scoped_session_id)
    ctx.session_state = await build_session_state(
        code_executor=agent.code_executor,
        local_dir=local_dir,
    )

    # Bind the notebook logical_id resolver so the agent's
    # ``return_notebook`` / ``edit_notebook`` tools honour user-side renames
    # AND fail loudly when a sibling terminal already owns the live_name.
    # The seen-set is reconstructed from the live conversation on each call
    # — cheap (regex over text) and always accurate, no extra state to keep
    # in sync.
    from parsimony_agents.agent.seen_refs import extract_seen_live_names

    from server.api.workspace.notebook_identity import resolve_notebook_logical_id

    async def _resolve_notebook_lid(path: str) -> str:
        seen = extract_seen_live_names(ctx.messages)
        return await resolve_notebook_logical_id(user_id, workspace_id, path, seen_live_names=seen)

    ctx.notebook_logical_id_resolver = _resolve_notebook_lid

    # Persist the user message FIRST so JSONL ordering matches conversation order:
    # user → intermediate (file_refs, reasoning) → final assistant text.
    if not is_continuation:
        msg_user = TerminalMessage(
            role="user",
            content=Text(content=request.message, files=_files),
            id=str(uuid.uuid4()),
        )
        user_record = msg_user.to_frontend_dict()
        user_record["type"] = "user_message"
        await service.append_terminal_jsonl(user_id, workspace_id, terminal_id, user_record)

    try:
        async for event in agent.run(user_message=user_message, ctx=ctx, cancellation=cancellation):
            # Record agent-initiated kernel restarts durably before any other processing
            # so they appear at the exact chronological position in the transcript.
            if isinstance(event, ToolEvent) and event.tool_name == "restart_kernel" and event.completed:
                await service.append_terminal_jsonl(
                    user_id,
                    workspace_id,
                    terminal_id,
                    {
                        "type": "kernel_restart",
                        "source": "agent_tool",
                        "at": datetime.now(UTC).isoformat(),
                    },
                )

            out = framework_event_to_stream_chunks(event, response_id=response_id)
            if out is None:
                continue

            persist_record: dict[str, object] | None = None

            if isinstance(out, PendingFileRef):
                if not out.completed and out.kind != "utility_output":
                    # Phase-1 code previews carry stale or empty notebook.code.
                    # Persisting them would clobber the live .py file before execution
                    # completes. Utility outputs are different: their phase-1 snapshot
                    # contains the exact tool args/code the UI should show immediately.
                    continue
                wire_chunk = await _persist_pending_file_ref(
                    user_id=user_id,
                    workspace_id=workspace_id,
                    pending=out,
                )
                yield wire_chunk.to_sse_chunk()
                persist_record = _file_ref_record(wire_chunk)

            elif isinstance(out, TextDeltaChunk):
                if out.delta:
                    yield out.to_sse_chunk()
                else:
                    # delta=False carries the full assembled text for ONE LLM
                    # iteration. Persisting it as its own JSONL record (keyed
                    # by messageId) preserves the chronological interleaving
                    # of text and tool/file events across multi-iteration
                    # turns — text emitted before iteration N's tool calls
                    # stays before iteration N's file_refs in history.
                    text = out.data.strip()
                    if text:
                        persist_record = TerminalMessage(
                            role="assistant",
                            content=Text(content=text),
                            id=out.messageId,
                            response_id=response_id,
                        ).to_frontend_dict()
                        persist_record["type"] = "text"

            elif isinstance(out, ReasoningDeltaChunk):
                if out.delta:
                    yield out.to_sse_chunk()
                else:
                    persist_record = TerminalMessage(
                        role="assistant",
                        content=Reasoning(content=out.data, title=out.title),
                        id=out.messageId,
                        response_id=response_id,
                    ).to_frontend_dict()
                    persist_record["type"] = "reasoning_delta"

            elif isinstance(out, SystemToolChunk):
                yield out.to_sse_chunk()
                persist_record = TerminalMessage(
                    role="assistant",
                    content=out.data,
                    id=out.messageId,
                    response_id=response_id,
                ).to_frontend_dict()
                persist_record["type"] = out.type

            elif isinstance(out, ContinueRequestChunk):
                yield out.to_sse_chunk()
                persist_record = TerminalMessage(
                    role="assistant",
                    content=ContinueRequest(message=out.data),
                    id=out.messageId,
                    response_id=response_id,
                ).to_frontend_dict()
                persist_record["type"] = out.type

            elif isinstance(out, (ErrorChunk, NotificationChunk)):
                yield out.to_sse_chunk()

            elif isinstance(out, CancellationChunk):
                yield out.to_sse_chunk()
                cancel_rec: dict[str, object] = {
                    "id": out.messageId,
                    "role": "system",
                    "timestamp": datetime.now(UTC).replace(microsecond=0).isoformat(),
                    "responseId": out.responseId,
                    "type": "cancelled",
                    "content": {
                        "type": "cancelled",
                        "reason": out.data.reason,
                        "message": out.data.message,
                    },
                }
                persist_record = cancel_rec

            else:
                raise TypeError(f"Unhandled stream event: {type(out)!r}")

            if persist_record is not None:
                await service.append_terminal_jsonl(user_id, workspace_id, terminal_id, persist_record)

        analysis_duration = time.time() - start_time
        yield FinalChunk(
            data=MessageMetadata(),
            responseId=response_id,
            analysis_duration=analysis_duration,
        ).to_sse_chunk()

        await service.persist_workspace_disk_to_blob_if_needed(user_id, workspace_id, local_dir)

    finally:
        await unregister_active_run(
            user_id,
            workspace_id,
            terminal_id,
            response_id=turn_response_id if turn_response_id is not None else response_id,
        )
        discard = bool(cancellation and cancellation.is_set())
        await _release_executor(
            agent,
            scoped_session_id,
            discard_kernel=discard,
            on_discard_kernel=on_discard_kernel,
        )


# ── Per-kind persistence dispatch ─────────────────────────────────────────────


def _return_artifact_line(*, rel: str, artifact: Dataset | Chart | Report) -> str:
    """``file://./… > description`` for return artifacts; description from artifact curation."""

    desc = artifact.description.strip()
    title = artifact.title.strip()
    sub = desc or title
    r = file_ref(rel)
    if sub:
        return f"{r} > {sub}"
    return r


def _notebook_artifact_line(*, rel: str, tool_name: str | None, also_executed: bool = False) -> str:
    """Verb + ``file://./`` ref only; no ``ui_message`` / LLM line on the wire."""

    r = file_ref(rel)
    match tool_name:
        case "return_notebook":
            if also_executed:
                return f"Published and executed {r}"
            return f"Published {r}"
        case "edit_notebook":
            if also_executed:
                return f"Edited and executed {r}"
            return f"Edited {r}"
        case _:
            return f"Updated {r}"


async def _persist_pending_file_ref(
    *,
    user_id: str,
    workspace_id: str,
    pending: PendingFileRef,
) -> FileRefChunk:
    """Write the pending event to the workspace and build the wire chunk.

    Single boundary that turns a typed in-process payload (Dataset,
    Chart, ScriptPreview, UtilityToolOutput) into a workspace file plus
    a :class:`FileRefChunk`. Validates the kind against the viewer
    registry so an unrendered kind cannot reach the wire.
    """

    require_kind(pending.kind)

    view_etag: str | None = None
    logical_id: str | None = None
    content_sha: str | None = None
    name: str | None = None
    version: int | None = None
    match pending.kind:
        case "dataset" | "chart" | "report":
            artifact = pending.payload
            expected: tuple[type, ...] = {
                "dataset": (Dataset,),
                "chart": (Chart,),
                "report": (Report,),
            }[pending.kind]
            if not isinstance(artifact, expected):
                raise TypeError(
                    f"PendingFileRef(kind={pending.kind!r}) expected "
                    f"{expected[0].__name__}, got {type(artifact).__name__}"
                )
            ref, rel, etag, version = await persist_return_artifact(
                user_id=user_id,
                workspace_id=workspace_id,
                artifact=artifact,
                kind=pending.kind,
            )
            logical_id = ref.logical_id
            content_sha = ref.content_sha
            name = artifact.title or None
            label = _return_artifact_line(rel=rel, artifact=artifact)

        case "notebook":
            preview = pending.payload
            if not isinstance(preview, ScriptPreview):
                raise TypeError(f"PendingFileRef(kind='notebook') expected ScriptPreview, got {type(preview).__name__}")
            # Notebooks follow the same persist shape as
            # dataset/chart/report:
            #   1. resolve logical_id from curation (slug from path on first call)
            #   2. write content-addressed snapshot
            #   3. append to log.jsonl → version
            #   4. update curation (live_name from path basename)
            # No working-copy cleanup — the agent's tools write nothing
            # at ``notebooks/<name>.py``; that path is purely a virtual
            # view synthesized from curation by ``service.py``.
            ref, etag, view_etag, version = await _persist_notebook(
                user_id=user_id,
                workspace_id=workspace_id,
                preview=preview,
            )
            rel = ref.workspace_file_path
            content_sha = ref.content_sha
            logical_id = ref.logical_id
            # Pill display name = curation live_name (basename without
            # ``.py``). Same source the tab strip uses, so the pill and
            # the tab show the same label.
            base = preview.path.rsplit("/", 1)[-1]
            name = base[:-3] if base.endswith(".py") else base
            # Label embeds a ``file://./`` token that the inline pill
            # renderer uses as its link target — must be the snapshot
            # path. Visual label is still ``us_macro_data v{N}`` via
            # ``displayName`` + ``version``. Same pattern as
            # ``_return_artifact_line`` for datasets/charts/reports.
            label = _notebook_artifact_line(
                rel=rel,
                tool_name=pending.tool_name,
                also_executed=pending.also_executed,
            )

        case "utility_output":
            output = pending.payload
            if not isinstance(output, UtilityToolOutput):
                raise TypeError(
                    f"PendingFileRef(kind='utility_output') expected UtilityToolOutput, got {type(output).__name__}"
                )
            rel, etag = await _persist_utility_output(
                user_id=user_id,
                workspace_id=workspace_id,
                tool_call_id=pending.message_id,
                output=output,
            )
            # User-facing label: LLM _ui_message on completion, else loading line (incl. dry_execute / temp code).
            label = (
                getattr(output, "ui_message_completed", None) or getattr(output, "ui_message", None) or "Tool output"
            )

        case _:
            raise NotImplementedError(
                f"PendingFileRef(kind={pending.kind!r}) has no registered persister; "
                "register one in server.api.workspace.streaming alongside the viewer."
            )

    await _assert_streamed_file_ref_ready(
        user_id=user_id,
        workspace_id=workspace_id,
        kind=pending.kind,
        rel=rel,
        etag=etag,
    )

    return FileRefChunk(
        kind=pending.kind,
        workspace_file_path=rel,
        logical_id=logical_id,
        content_sha=content_sha,
        name=name,
        version=version,
        etag=etag,
        view_etag=view_etag,
        label=label,
        responseId=pending.response_id,
        messageId=pending.message_id,
        completed=pending.completed,
    )


async def _persist_notebook(
    *,
    user_id: str,
    workspace_id: str,
    preview: ScriptPreview,
) -> tuple[ArtifactRef, str, str, int]:
    """Persist a notebook snapshot using the unified content-addressed flow.

    Mirrors :func:`server.api.workspace.artifact_registry.persist_return_artifact`'s
    shape — every kind that has a log goes through the same steps:

    1. **Derive logical_id** from the working-copy path
       (``notebooks/foo.py`` → ``"foo"``). Git-style: rename = new
       logical_id, history splits cleanly. No allocator, no UUID.
    2. **Write the snapshot** at
       ``.ockham/notebooks/<logical_id>/<content_sha>.py`` via the
       service layer (idempotent — :func:`write_snapshot` skips when
       the file already exists).
    3. **Ensure curation exists** so the file-list / live-name resolver
       picks up the notebook. Idempotent: existing curation is touched
       (so ``updated_at`` reflects the write); fresh notebook gets a
       minimal stub with just ``live_name``.
    4. **Append to log.jsonl**. The 1-based return is the user-facing
       ``v{N}`` shown on pills. Identical-content republishes return
       the existing version (full dedup).

    The user-visible ``notebooks/<live_name>.py`` is a virtual view
    synthesized from curation in ``service._virtual_live_entries_sync``
    — there is no transient working copy to delete. The agent's code
    tools write directly through this persist path; reads (across
    turns) come from the snapshot via
    :func:`parsimony_agents.notebook_io.read_latest_notebook`.

    Runtime state (``KernelOutput``, fetch log) is cached separately
    under ``.ockham/notebook-state/<content_sha>.json`` — keyed by
    ``content_sha`` so it survives across edit cycles.

    Returns ``(ref, etag, view_etag, version)``.
    """
    from datetime import UTC
    from datetime import datetime as _dt

    from parsimony_agents.identity import (
        ArtifactRef,
        notebook_content_sha,
        notebook_logical_id,
    )

    from server.api.workspace.notebook_identity import resolve_notebook_logical_id
    from server.api.workspace.snapshot_store import (
        Curation,
        LogEntry,
        append_log,
        read_curation,
        write_curation,
        write_snapshot,
    )

    path = (getattr(preview, "path", None) or "").strip()
    if not path:
        raise ValueError("notebook preview is missing 'path'; agent must pass a workspace path.")

    script = Script(path=path, code=preview.code)
    raw = serialize_notebook(script)

    # 1. Resolve logical_id — honours existing curations so a notebook
    # whose live_name was renamed in the UI keeps its original slug.
    logical_id = await resolve_notebook_logical_id(user_id, workspace_id, path)
    csha = notebook_content_sha(preview.code or "")
    ref = ArtifactRef(kind="notebook", logical_id=logical_id, content_sha=csha)

    # 2. Snapshot — content-addressed, idempotent.
    await write_snapshot(user_id, workspace_id, ref, raw)

    # 3. Curation — write stub on first encounter, touch on subsequent.
    # Two concurrent first-time persists for the same path produce the
    # same logical_id and identical stub content, so last-writer-wins is
    # safe (no allocator or flock needed).
    now = _dt.now(UTC).isoformat(timespec="seconds").replace("+00:00", "Z")
    existing = await read_curation(user_id, workspace_id, "notebook", logical_id)
    if existing is None:
        # First-time creation: ``live_name`` is the path basename. Note
        # this differs from ``logical_id`` whenever the resolver picked
        # a collision suffix (rare — a renamed notebook freed up the
        # original slug, then the user created another notebook by the
        # same name). The user-facing path stays clean; the on-disk
        # directory just gets a stable handle.
        stub = Curation(
            kind="notebook",
            logical_id=logical_id,
            title="",
            description="",
            tags=[],
            notes=[],
            live_name=notebook_logical_id(path),
            created_at=now,
            updated_at=now,
        )
        await write_curation(user_id, workspace_id, "notebook", logical_id, stub)
    else:
        await write_curation(user_id, workspace_id, "notebook", logical_id, existing)

    # 4. Log — full dedup; ``version`` is the 1-based position.
    entry = LogEntry(
        ts=now,
        content_sha=csha,
        inputs={"path": path},
    )
    version = await append_log(user_id, workspace_id, "notebook", logical_id, entry)

    state_cache_bytes = await _write_notebook_state_cache(user_id, workspace_id, preview, script)
    if state_cache_bytes is None:
        state_cache_bytes = await _read_notebook_state_cache(user_id, workspace_id, script)
    view_etag = notebook_view_etag(script_py_bytes=raw, state_cache_bytes=state_cache_bytes)
    etag = compute_etag(raw)
    return ref, etag, view_etag, version


def _notebook_state_cache_rel(script: Script) -> str:
    return f".ockham/{notebook_state_cache_key(script)}"


async def _read_notebook_state_cache(user_id: str, workspace_id: str, script: Script) -> bytes | None:
    try:
        return await service.read_workspace_file_bytes(
            user_id,
            workspace_id,
            _notebook_state_cache_rel(script),
            allow_ockham=True,
        )
    except Exception:
        logger.warning("Failed to read notebook state cache for %s", script.path, exc_info=True)
        return None


async def _write_notebook_state_cache(
    user_id: str,
    workspace_id: str,
    preview: ScriptPreview,
    script: Script,
) -> bytes | None:
    """Persist the full kernel output to the per-script content-addressed cache.

    Stored under ``.ockham/notebook-state/<sha>.json`` via the workspace
    storage layer so the cache works identically for local and remote
    backends. Best-effort: failures are logged but do not fail the SSE
    turn — the cache is regenerable from the live executor and is never
    authoritative.

    We store the full :class:`KernelOutput` (charts, DataFrames, print output,
    fetch log) rather than just the fetch log, so clicking on a notebook chip
    after a page reload renders the actual execution outputs — not just code.

    Returns the encoded state bytes on success, or ``None`` when there was
    nothing to write or the write was skipped.
    """

    if preview.output is None and not preview.data_objects:
        return None
    try:
        if preview.output is not None:
            script.output = preview.output
        else:
            # Backward-compatible path: no KernelOutput but there are fetch-log entries.
            script.output = KernelOutput(outputs=[], fetch_log=list(preview.data_objects))
        rel = _notebook_state_cache_rel(script)
        body = encode_notebook_state(script, script.output)
        await service.write_workspace_file_bytes(
            user_id,
            workspace_id,
            rel,
            body,
            allow_ockham=True,
        )
        return body
    except Exception:
        logger.warning("Failed to write notebook state cache for %s", script.path, exc_info=True)
    return None


async def _persist_utility_output(
    *,
    user_id: str,
    workspace_id: str,
    tool_call_id: str,
    output: UtilityToolOutput,
) -> tuple[str, str]:
    """Write the utility-tool output to ``.ockham/outputs/<hash>.output.json``.

    Bytes are the canonical Pydantic JSON for :class:`UtilityToolOutput`
    (``model_dump_json``), round-trippable like notebook state cache — not the
    slimmer :meth:`~UtilityToolOutput.to_frontend_dict` wire projection.

    The filename is a 16-char SHA-256 prefix of the provider's tool_call_id.
    Hashing isolates the filesystem layout from provider-specific id shapes
    (e.g. Gemini packs a base64 thought-signature into the id, which is too
    long and contains ``/`` and ``=``).
    """

    digest = hashlib.sha256(tool_call_id.encode("utf-8")).hexdigest()[:16]
    rel = f".ockham/outputs/{digest}.output.json"
    raw = output.model_dump_json().encode("utf-8")
    etag = await service.write_workspace_file_bytes(user_id, workspace_id, rel, raw, allow_ockham=True)
    return rel, etag


async def _assert_streamed_file_ref_ready(
    *,
    user_id: str,
    workspace_id: str,
    kind: str,
    rel: str,
    etag: str,
) -> None:
    """Fail before emitting a file ref unless the backing viewer can read it.

    The SSE ``file_ref`` is a promise to the client: once the chunk arrives,
    ``GET /view/{path}`` (or ``GET /files/{path}``) must be able to serve the
    just-written bytes. This read-after-write barrier keeps that promise at the
    server boundary instead of relying on the UI to retry around races.
    """

    result = await service.read_workspace_file_with_etag(
        user_id,
        workspace_id,
        rel,
        allow_ockham=rel.startswith(".ockham/"),
    )
    if result is None:
        raise RuntimeError(f"streamed {kind} file ref is not readable after write: {rel}")

    raw, observed_etag = result
    if observed_etag != etag:
        raise RuntimeError(
            f"streamed {kind} file ref read-after-write mismatch for {rel}: expected {etag!r}, got {observed_etag!r}"
        )

    if kind == "dataset":
        # Datasets can be large; the byte/etag barrier is enough to prevent
        # unavailable links without eagerly building a full table payload.
        return

    if rel.endswith(".py"):
        script = deserialize_notebook(raw, path=rel)
        cache_blob = await service.read_workspace_file_bytes(
            user_id,
            workspace_id,
            _notebook_state_cache_rel(script),
            allow_ockham=True,
        )

        def _notebook_state_loader(_script):  # noqa: ANN001
            return cache_blob

        viewer_payload_for_path(rel, raw, notebook_state_loader=_notebook_state_loader)
        return

    viewer_payload_for_path(rel, raw)


# ── Transcript record builder ─────────────────────────────────────────────────


def _file_ref_record(chunk: FileRefChunk) -> dict[str, object]:
    """Build the JSONL transcript record for a :class:`FileRefChunk`.

    The meaningful wire fields are preserved so reload-from-JSONL follows
    the same frontend path as live streams, without writing optional
    notebook-only keys on every non-notebook record.
    """

    content: dict[str, object] = {
        "type": "file_ref",
        "kind": chunk.kind,
        "workspace_file_path": chunk.workspace_file_path,
        "label": chunk.label,
        "etag": chunk.etag,
    }
    if chunk.name is not None:
        # Persisted so the inline pill shows the curation title (not the
        # content_sha basename) on transcript replay, matching live streams.
        content["name"] = chunk.name
    if chunk.version is not None:
        # Persisted so the v{N} badge survives transcript replay — the
        # historical pill correctly pins the version that existed at the
        # moment the chunk was emitted, even if newer snapshots have since
        # bumped the live version.
        content["version"] = chunk.version
    record: dict[str, object] = {
        "id": chunk.messageId,
        "role": "assistant",
        "timestamp": datetime.now(UTC).replace(microsecond=0).isoformat(),
        "responseId": chunk.responseId,
        "completed": chunk.completed,
        "type": "file_ref",
        "content": content,
        "workspace_file_path": chunk.workspace_file_path,
        "etag": chunk.etag,
    }
    if chunk.view_etag is not None:
        content["view_etag"] = chunk.view_etag
        record["view_etag"] = chunk.view_etag
    return record


# ── Cleanup ───────────────────────────────────────────────────────────────────


async def _release_executor(
    agent: Agent,
    scoped_session_id: str,
    *,
    discard_kernel: bool = False,
    on_discard_kernel: Callable[[], Awaitable[None]] | None = None,
) -> None:
    """Cache the executor id on success, or drop the sandbox/in-process kernel on cancel."""
    if discard_kernel and on_discard_kernel is not None:
        logger.info(
            "Discarding remote kernel after cancel or run end",
            extra={
                "event": "remote_kernel_released",
                "scoped_session_id": scoped_session_id,
                "action": "discard",
            },
        )
        with contextlib.suppress(Exception):
            await on_discard_kernel()
        return
    if isinstance(agent.code_executor, RemoteCodeExecutor) and agent.code_executor.executor_id:
        await set_cached_executor_id(get_cache(), scoped_session_id, agent.code_executor.executor_id)
    with contextlib.suppress(Exception):
        await agent.code_executor.close()
