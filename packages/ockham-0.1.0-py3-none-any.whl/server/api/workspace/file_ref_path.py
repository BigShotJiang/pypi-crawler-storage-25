"""Percent-encode workspace paths inside ``file://./`` ref tokens (``/`` preserved)."""

from __future__ import annotations

from urllib.parse import quote, unquote


def encode_path_for_file_ref(path: str) -> str:
    """Encode a workspace-relative path for use after the ``file://./`` prefix."""
    p = path.replace("\\", "/").lstrip("/")
    return quote(p, safe="/")


def decode_path_from_file_ref(path_token: str) -> str:
    """Decode the path segment of a ``file://./`` token (after the prefix, or a regex capture)."""
    return unquote(path_token)
