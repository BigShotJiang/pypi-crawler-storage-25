"""Pydantic models for workspace API."""

from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class WorkspaceSettings(BaseModel):
    """Typed workspace settings (fail fast on unknown keys)."""

    model_config = ConfigDict(extra="forbid")

    default_model_id: str | None = None


class WorkspaceMetadata(BaseModel):
    """Contents of ``.ockham/workspace.json``."""

    id: str
    title: str
    settings: WorkspaceSettings = Field(default_factory=WorkspaceSettings)
    created_at: datetime
    updated_at: datetime


class FileEntry(BaseModel):
    path: str
    size_bytes: int
    kind: Literal["file", "directory"] = "file"


class CopyWorkspaceFileRequest(BaseModel):
    """Copy a visible workspace file to another visible workspace path."""

    model_config = ConfigDict(extra="forbid")

    source_path: str
    destination_path: str


class MoveWorkspaceFileRequest(BaseModel):
    """Move a visible workspace file to another visible workspace path."""

    model_config = ConfigDict(extra="forbid")

    source_path: str
    destination_path: str


class CreateWorkspaceFolderRequest(BaseModel):
    """Create a visible workspace folder."""

    model_config = ConfigDict(extra="forbid")

    path: str


class MoveWorkspaceFolderRequest(BaseModel):
    """Move a visible workspace folder to another visible workspace path."""

    model_config = ConfigDict(extra="forbid")

    source_path: str
    destination_path: str


class CreateWorkspaceRequest(BaseModel):
    title: str = "Untitled workspace"


class UpdateWorkspaceRequest(BaseModel):
    """Partial update for ``PATCH /api/workspaces/{id}``."""

    model_config = ConfigDict(extra="forbid")

    title: str | None = None
    settings: WorkspaceSettings | None = None


class WorkspaceSummary(BaseModel):
    id: str
    title: str
    updated_at: datetime


class TerminalSessionMeta(BaseModel):
    """Metadata for one workspace terminal session."""

    id: str
    title: str
    created_at: datetime
    updated_at: datetime


class CreateTerminalRequest(BaseModel):
    title: str = "Untitled"


class UpdateTerminalRequest(BaseModel):
    """Partial update for ``PATCH /api/workspaces/{id}/terminals/{terminal_id}``."""

    model_config = ConfigDict(extra="forbid")

    title: str | None = None


class MaterializeWorkspaceFileRefRequest(BaseModel):
    """Copy bytes from a workspace file ref to a user-visible path.

    ``source`` accepts ``file://./<path>`` or a workspace-relative path.
    Use ``destination_folder`` for basename-preserving copy with server-side
    collision resolution; set ``destination_path`` for an exact destination (409 if it exists).
    """

    model_config = ConfigDict(extra="forbid")

    source: str
    """Workspace-relative file path, or ``file://./<path>`` (``file_ref``: percent-encoded path
    segments, ``/`` preserved)."""

    destination_folder: str = ""
    """Target folder; empty string = workspace root. Ignored if ``destination_path`` is set."""

    destination_path: str | None = None
    """If set, write exactly to this visible path. Otherwise server picks ``basename`` under ``destination_folder``."""

    source_etag: str | None = None
    """If set, materialize only when current source ETag matches (byte fingerprint)."""


class MaterializeWorkspaceFileRefResponse(BaseModel):
    """Path and ETag of the created visible workspace file."""

    model_config = ConfigDict(extra="forbid")

    path: str
    etag: str
