"""Registry-backed LLM projections for workspace files (summary vs read)."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from parsimony_agents.execution.outputs import FigureObject, KernelOutput

if TYPE_CHECKING:
    from parsimony_agents.agent.outputs import ArtifactLlmResult

from server.api.workspace.artifact_projection import (
    ArtifactReadProjection,
    ArtifactReadRequest,
    merge_warnings_to_text,
)
from server.api.workspace.artifact_read_projections import read_projection_for_kind
from server.api.workspace.viewers import viewer_for_path

logger = logging.getLogger(__name__)

_MAX_FALLBACK = 12_000


def _self_ref_tag(live_name: str | None, kind: str | None) -> str | None:
    """Build the seen-set marker tag prepended to ``read_artifact`` text.

    The agent's seen-set extractor scans for ``<artifact_ref kind=…
    live_name=…/>``; including it on a read result is what lets the next
    ``return_*`` / ``refresh`` / ``edit_*`` call against the same
    ``(kind, live_name)`` pair resolve without raising
    :class:`LiveNameCollisionError`. Returns ``None`` if either field is
    missing.
    """
    if not live_name or not kind:
        return None
    return f'<artifact_ref kind="{kind}" live_name="{live_name}"/>'


def read_artifact_projection(path: str, raw: bytes, request: ArtifactReadRequest) -> ArtifactReadProjection:
    """Return a typed :class:`ArtifactReadProjection` for a workspace-relative *path*."""
    spec = viewer_for_path(path)
    if spec is not None and spec.payload_fn is not None:
        return read_projection_for_kind(spec.kind, raw, path, request)
    return ArtifactReadProjection(
        path=path,
        kind="unknown",
        view=request.view,
        text=_fallback_text_preview(raw),
        warnings=[f"no registered structured viewer for path {path!r}"],
    )


def _parse_read_request(
    path: str,
    *,
    view: str | None = None,
    mode: str | None = None,
    locator: dict[str, Any] | None = None,
) -> ArtifactReadRequest:
    v = (view or "").strip().lower() if view is not None else None
    m = (mode or "summary").strip().lower() if mode is not None else None
    if v in {"", None}:
        v = m if m in {"summary", "full"} else "summary"
    if v not in ("summary", "outline", "page", "full"):
        raise ValueError("view (or mode) must be one of: summary, outline, page, full")
    from server.api.workspace.artifact_projection import ArtifactLocator

    loc_model = None
    if locator is not None:
        loc_model = ArtifactLocator.model_validate(locator)
    return ArtifactReadRequest(path=path, view=v, locator=loc_model)


def read_artifact_to_llm_result(
    path: str,
    raw: bytes,
    options: dict[str, Any],
    *,
    live_name: str | None = None,
    artifact_kind: str | None = None,
) -> ArtifactLlmResult:
    """Map file bytes to :class:`parsimony_agents.agent.outputs.ArtifactLlmResult` (terminal use).

    When the caller supplies ``live_name`` and ``artifact_kind`` (the
    pair the agent typed), prepend a ``<artifact_ref kind=… live_name=…/>``
    tag to the result text. The agent's seen-set extractor picks it up
    on the next turn, so a follow-up ``return_*`` / ``refresh`` call
    against the same artifact is treated as a continuation rather than a
    cross-terminal collision. Callers that read raw user-dropped files
    (no live_name available) leave both ``None`` and no tag is added.
    """
    from parsimony_agents.agent.outputs import ArtifactLlmResult

    request = _parse_read_request(
        path,
        view=options.get("view"),
        mode=options.get("mode"),
        locator=options.get("locator"),
    )
    pr = read_artifact_projection(path, raw, request)
    text = merge_warnings_to_text(pr.text, next_locator=pr.next_locator, warnings=pr.warnings)

    self_ref_tag = _self_ref_tag(live_name, artifact_kind)
    if self_ref_tag is not None:
        text = f"{self_ref_tag}\n{text}"

    if pr.kind == "chart" and pr.view == "full" and (request.locator is None or request.locator.kind != "chart_spec"):
        try:
            from parsimony_agents.chart_io import deserialize_chart

            _chart, spec = deserialize_chart(raw)
            fig = FigureObject(value=spec, name="chart")
            return ArtifactLlmResult(
                text=text,
                kernel_output=KernelOutput(outputs=[fig]),
            )
        except Exception as exc:
            logger.warning("chart render to FigureObject failed for %s: %s", path, exc)
            return ArtifactLlmResult(
                text=text + f"\n<warning>Could not render chart image: {exc!r}. Use read_artifact with "
                "locator {kind: chart_spec} for the Vega-Lite JSON.</warning>",
            )

    return ArtifactLlmResult(text=text)


def read_artifact_for_llm(
    path: str, raw: bytes, *, mode: str = "summary", view: str | None = None, locator: dict | None = None
) -> str:
    """Return text for the LLM for *path* (compat path for summaries / referenced file expansion).

    This path is string-only. Chart images are not inlined here—see :func:`read_artifact_to_llm_result`.
    """
    r = read_artifact_to_llm_result(path, raw, {"view": view, "mode": mode, "locator": locator})
    if r.kernel_output is not None:
        return (
            r.text
            + "\n<note>Rendered chart available via read_artifact; image blocks omitted in this text-only path.</note>"
        )
    return r.text


def artifact_summary_for_path(path: str, raw: bytes) -> str | None:
    """One-line blurb for session state, or None if the path has no ``llm_summary_fn``."""
    spec = viewer_for_path(path)
    if spec is None or spec.llm_summary_fn is None:
        return None
    return spec.llm_summary_fn(raw, path)


def _fallback_text_preview(raw: bytes) -> str:
    if len(raw) > _MAX_FALLBACK:
        raw = raw[:_MAX_FALLBACK]
        suffix = "\n... [truncated]"
    else:
        suffix = ""
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        return "<binary />"
    return f"<text>\n{text}{suffix}\n</text>"


__all__ = [
    "artifact_summary_for_path",
    "read_artifact_for_llm",
    "read_artifact_projection",
    "read_artifact_to_llm_result",
    "_parse_read_request",
]
