"""Workspace operations against a single ``FileStorage`` protocol.

This module is the only orchestration layer for workspace state. File bytes
flow through ``FileStorage``; directory operations use the mounted workspace
tree because folders are native filesystem objects in the IDE model.
"""

from __future__ import annotations

import asyncio
import json
import re
import shutil
from datetime import UTC, datetime
from io import BytesIO
from pathlib import Path, PurePosixPath
from typing import Any
from uuid import uuid4

import pyarrow.parquet as pq
from parsimony.result import Result
from parsimony_agents.agent.models import AgentContext, AgentMessage
from parsimony_agents.messages import Text

from server.api.workspace.artifact_llm import read_artifact_for_llm
from server.api.workspace.etag import compute_etag, parse_if_none_match
from server.api.workspace.file_ref_path import decode_path_from_file_ref
from server.api.workspace.models import (
    TerminalSessionMeta,
    WorkspaceMetadata,
    WorkspaceSettings,
    WorkspaceSummary,
)
from server.api.workspace.storage import get_workspace_blob_storage, workspace_local_tree_path
from server.api.workspace.transcript import parse_kernel_restart, parse_user_assistant_text


def _meta_key(user_id: str, workspace_id: str) -> str:
    return f"{user_id}/{workspace_id}/.ockham/workspace.json"


def _legacy_terminal_key(user_id: str, workspace_id: str) -> str:
    return f"{user_id}/{workspace_id}/.ockham/terminal.jsonl"


def _terminal_index_key(user_id: str, workspace_id: str) -> str:
    return f"{user_id}/{workspace_id}/.ockham/terminals.json"


def _terminal_transcript_key(user_id: str, workspace_id: str, terminal_id: str) -> str:
    return f"{user_id}/{workspace_id}/.ockham/terminals/{terminal_id}.jsonl"


def _workspace_tree_prefix(user_id: str, workspace_id: str) -> str:
    return f"{user_id}/{workspace_id}/"


_workspace_terminals_locks: dict[str, asyncio.Lock] = {}
_workspace_terminals_locks_guard = asyncio.Lock()


async def _workspace_terminals_lock(user_id: str, workspace_id: str) -> asyncio.Lock:
    """Serializes all terminal index + JSONL transcript mutations for one workspace."""
    k = f"{user_id}::{workspace_id}"
    async with _workspace_terminals_locks_guard:
        if k not in _workspace_terminals_locks:
            _workspace_terminals_locks[k] = asyncio.Lock()
        return _workspace_terminals_locks[k]


def normalize_workspace_file_path(path: str, *, allow_ockham: bool = False) -> str:
    """Return a relative workspace file key.

    Single boundary primitive for path safety. Rejects empty paths, absolute
    paths, and any path component of ``.`` or ``..``. ``.ockham`` is the
    framework's private namespace; access is gated by ``allow_ockham`` (callers
    from the user file API leave it ``False``; the streaming layer enables it
    for internal writes).

    Backslashes are normalized to ``/`` *before* parsing so inputs like
    ``..\\\\..\\\\x`` cannot bypass ``..`` checks.
    """
    s = path.strip()
    if not s:
        raise ValueError("path is empty")
    # Unify Windows-style separators first; ``PurePosixPath`` would let
    # ``a\\..\\b`` through as a single part without this step.
    s = s.replace("\\", "/").strip()
    if s.startswith("/"):
        raise ValueError("path must be relative (no leading slash)")
    s = s.strip("/")
    if not s:
        raise ValueError("path is empty")
    parts = PurePosixPath(s).parts
    for p in parts:
        if p == ".." or p == ".":
            raise ValueError("path must not contain '.' or '..' path components")
    if parts[0] == ".ockham" and not allow_ockham:
        raise ValueError("path under .ockham is not editable via the file API")
    return s


def _local_visible_path(user_id: str, workspace_id: str, relative_path: str) -> Path:
    rel = normalize_workspace_file_path(relative_path)
    root = workspace_local_tree_path(user_id, workspace_id).resolve()
    target = (root / rel).resolve()
    if root not in target.parents and target != root:
        raise ValueError("path escapes workspace root")
    return target


def _object_key_for_file(user_id: str, workspace_id: str, relative_path: str) -> str:
    return f"{user_id}/{workspace_id}/{relative_path}"


def parquet_bytes_to_json_view(data: bytes, *, offset: int, limit: int) -> dict[str, Any]:
    """Parse Parquet bytes into a JSON-serializable view.

    Uses the embedded ``parsimony.result`` schema when present (semantic roles,
    declared dtypes); otherwise derives columns from the Arrow schema so plain
    Parquet files (and schemaless ``Result`` saves) render correctly.
    """
    table = pq.read_table(BytesIO(data))
    result = Result.from_arrow(table)
    df = result.df
    total_rows = len(df)
    chunk = df.iloc[offset : offset + limit]
    records: list[dict[str, Any]] = json.loads(chunk.to_json(orient="records", date_format="iso"))
    if result.columns:
        columns_out = [{"name": c.name, "role": c.role.value, "dtype": c.dtype} for c in result.columns]
    else:
        columns_out = [
            {"name": str(name), "role": "data", "dtype": str(dtype)}
            for name, dtype in zip(df.columns, df.dtypes, strict=True)
        ]
    return {
        "data": records,
        "columns": columns_out,
        "provenance": result.provenance.model_dump(mode="json"),
        "total_rows": total_rows,
        "offset": offset,
        "limit": limit,
    }


def parquet_bytes_to_csv(data: bytes) -> bytes:
    """Convert a Parquet workspace dataset to UTF-8 CSV bytes."""
    table = pq.read_table(BytesIO(data))
    result = Result.from_arrow(table)
    return result.df.to_csv(index=False).encode("utf-8")


def parquet_bytes_to_xlsx(data: bytes) -> bytes:
    """Convert a Parquet workspace dataset to XLSX bytes."""
    table = pq.read_table(BytesIO(data))
    result = Result.from_arrow(table)
    out = BytesIO()
    result.df.to_excel(out, index=False, engine="openpyxl")
    return out.getvalue()


_WORKSPACE_META_SUFFIX = "/.ockham/workspace.json"
_FILE_REF_RE = re.compile(r"file://\./([^\s<>'\")]+)")
_MAX_REFERENCED_TEXT_BYTES = 24_000


# Source paths allowed for materialize-from-private (user promotion into visible tree).
# Generated from the kind registry (§5.8 H) so adding a new kind doesn't require a
# hardcoded list update. ``.ockham/outputs/`` survives as utility-tool plumbing
# (§10 — out of scope for the snapshot graph) and ``.ockham/notebook-state/`` is
# regenerable cache, never materialized.
def _materialize_ockham_prefixes() -> tuple[str, ...]:
    from parsimony_agents.identity import SNAPSHOT_KINDS

    by_kind = tuple(f".ockham/{'notebooks' if kind == 'notebook' else f'{kind}s'}/" for kind in SNAPSHOT_KINDS)
    return by_kind + (".ockham/outputs/",)


_MATERIALIZE_OCKHAM_PREFIXES: tuple[str, ...] = _materialize_ockham_prefixes()


class SourceEtagPreconditionFailed(Exception):
    """Raised when ``source_etag`` is set and does not match current source bytes."""

    def __init__(self, current_etag: str) -> None:
        self.current_etag = current_etag
        super().__init__(f"source ETag does not match; current is {current_etag!r}")


def parse_workspace_file_ref(source: str) -> str:
    """Strip ``file://./`` and return a normalized relative workspace file key."""
    s = source.strip()
    if s.startswith("file://./"):
        s = s[len("file://./") :]
    s = decode_path_from_file_ref(s)
    return normalize_workspace_file_path(s, allow_ockham=True)


def _is_allowed_materialize_source(relative_path: str) -> bool:
    rel = relative_path
    if not rel.startswith(".ockham/"):
        return True
    return any(rel.startswith(p) for p in _MATERIALIZE_OCKHAM_PREFIXES)


def _resolve_visible_copy_destination(source_path: str, destination_folder: str, existing_file_paths: set[str]) -> str:
    """Pick a non-colliding visible path under ``destination_folder`` (root if empty)."""
    raw_basename = source_path.rsplit("/", maxsplit=1)[-1] if source_path else source_path
    if not raw_basename:
        raise ValueError("source has no basename")
    folder = destination_folder.strip().strip("/")
    dot = raw_basename.rfind(".")
    has_ext = dot > 0 and dot < len(raw_basename) - 1
    stem = raw_basename[:dot] if has_ext else raw_basename
    ext = raw_basename[dot:] if has_ext else ""

    def join_name(name: str) -> str:
        return f"{folder}/{name}" if folder else name

    initial = join_name(raw_basename)
    if initial not in existing_file_paths:
        return initial

    index = 1
    while True:
        suffix = "-copy" if index == 1 else f"-copy-{index}"
        candidate = join_name(f"{stem}{suffix}{ext}")
        if candidate not in existing_file_paths:
            return candidate
        index += 1


async def _discover_workspace_ids(user_id: str) -> list[str]:
    """Discover workspaces by listing ``.ockham/workspace.json`` keys under *user_id*."""
    st = get_workspace_blob_storage()
    keys = await st.list_keys(f"{user_id}/")
    ids: set[str] = set()
    for k in keys:
        if not k.endswith(_WORKSPACE_META_SUFFIX):
            continue
        parts = k.split("/")
        if len(parts) >= 3 and parts[0] == user_id:
            ids.add(parts[1])
    return sorted(ids)


async def create_workspace(user_id: str, title: str) -> WorkspaceMetadata:
    wid = str(uuid4())
    now = datetime.now(UTC)
    meta = WorkspaceMetadata(
        id=wid,
        title=title,
        settings=WorkspaceSettings(),
        created_at=now,
        updated_at=now,
    )
    st = get_workspace_blob_storage()
    await st.write(_meta_key(user_id, wid), meta.model_dump_json().encode("utf-8"))
    return meta


async def list_workspaces(user_id: str) -> list[WorkspaceSummary]:
    st = get_workspace_blob_storage()
    out: list[WorkspaceSummary] = []
    for wid in await _discover_workspace_ids(user_id):
        raw = await st.read(_meta_key(user_id, wid))
        data = json.loads(raw.decode("utf-8"))
        m = WorkspaceMetadata.model_validate(data)
        out.append(WorkspaceSummary(id=m.id, title=m.title, updated_at=m.updated_at))
    return out


async def get_workspace(user_id: str, workspace_id: str) -> WorkspaceMetadata | None:
    st = get_workspace_blob_storage()
    key = _meta_key(user_id, workspace_id)
    if not await st.exists(key):
        return None
    raw = await st.read(key)
    return WorkspaceMetadata.model_validate_json(raw.decode("utf-8"))


async def update_workspace(
    user_id: str,
    workspace_id: str,
    *,
    title: str | None,
    settings: WorkspaceSettings | None,
) -> WorkspaceMetadata | None:
    """Update workspace metadata; returns ``None`` if the workspace does not exist."""
    meta = await get_workspace(user_id, workspace_id)
    if meta is None:
        return None
    if title is None and settings is None:
        return meta
    now = datetime.now(UTC)
    new_title = title if title is not None else meta.title
    new_settings = settings if settings is not None else meta.settings
    updated = WorkspaceMetadata(
        id=meta.id,
        title=new_title,
        settings=new_settings,
        created_at=meta.created_at,
        updated_at=now,
    )
    st = get_workspace_blob_storage()
    await st.write(_meta_key(user_id, workspace_id), updated.model_dump_json().encode("utf-8"))
    return updated


async def delete_workspace(user_id: str, workspace_id: str) -> bool:
    """Remove the workspace tree from storage. Returns ``False`` if it did not exist."""
    if await get_workspace(user_id, workspace_id) is None:
        return False
    st = get_workspace_blob_storage()
    await st.delete_prefix(_workspace_tree_prefix(user_id, workspace_id))
    return True


async def _bump_workspace_updated_at(user_id: str, workspace_id: str) -> None:
    meta = await get_workspace(user_id, workspace_id)
    if meta is None:
        return
    now = datetime.now(UTC)
    updated = WorkspaceMetadata(
        id=meta.id,
        title=meta.title,
        settings=meta.settings,
        created_at=meta.created_at,
        updated_at=now,
    )
    st = get_workspace_blob_storage()
    await st.write(_meta_key(user_id, workspace_id), updated.model_dump_json().encode("utf-8"))


async def read_workspace_file_bytes(
    user_id: str, workspace_id: str, relative_path: str, *, allow_ockham: bool = False
) -> bytes | None:
    rel = normalize_workspace_file_path(relative_path, allow_ockham=allow_ockham)
    st = get_workspace_blob_storage()
    key = _object_key_for_file(user_id, workspace_id, rel)
    if await st.exists(key):
        return await st.read(key)
    # Fallback: resolve through curation as a virtual live entry (§4.2).
    bytes_via_live = await asyncio.to_thread(_resolve_via_live_name_sync, user_id, workspace_id, rel)
    return bytes_via_live


def _resolve_virtual_entry_sync(user_id: str, workspace_id: str, rel: str) -> tuple[str, str] | None:
    """Return ``(kind, logical_id)`` for a virtual live entry, else ``None``.

    A path like ``data/foo.parquet`` resolves to a virtual entry when
    some logical artifact's curation has ``live_name = "foo"`` under the
    matching kind directory. Real blobs at the same path don't change
    this result — the caller decides which wins by checking
    ``storage.exists`` first.
    """
    root = workspace_local_tree_path(user_id, workspace_id)
    parts = rel.split("/", 1)
    if len(parts) != 2:
        return None
    user_dir, basename = parts
    for kind, _dirname, ext in _CURATED_KIND_DIRS:
        if user_dir != _kind_dir_for_live(kind) or not basename.endswith(ext):
            continue
        live_name = basename[: -len(ext)]
        if not live_name:
            return None
        kind_dir = root / f".ockham/{kind}s"
        if not kind_dir.is_dir():
            return None
        for lid_dir in kind_dir.iterdir():
            if not lid_dir.is_dir():
                continue
            cur = _read_curation_sync(root, kind, lid_dir.name)
            if cur is None or cur.get("live_name") != live_name:
                continue
            return (kind, lid_dir.name)
        return None
    return None


def _resolve_via_live_name_sync(user_id: str, workspace_id: str, rel: str) -> bytes | None:
    """Return latest snapshot bytes when ``rel`` matches a curation live_name."""
    virt = _resolve_virtual_entry_sync(user_id, workspace_id, rel)
    if virt is None:
        return None
    kind, logical_id = virt
    ext = next(e for k, _, e in _CURATED_KIND_DIRS if k == kind)
    root = workspace_local_tree_path(user_id, workspace_id)
    snap = _latest_snapshot_sync(root, kind, logical_id, ext)
    if snap is None:
        return None
    try:
        return snap[0].read_bytes()
    except OSError:
        return None


async def read_workspace_file_with_etag(
    user_id: str, workspace_id: str, relative_path: str, *, allow_ockham: bool = False
) -> tuple[bytes, str] | None:
    """Read a workspace file and return ``(bytes, etag)`` for HTTP cache validation.

    The etag is computed from the bytes (see :mod:`server.api.workspace.etag`),
    so it is stable across processes and identical for identical content. Callers
    that don't need the etag should keep using :func:`read_workspace_file_bytes`.
    """
    raw = await read_workspace_file_bytes(user_id, workspace_id, relative_path, allow_ockham=allow_ockham)
    if raw is None:
        return None
    return raw, compute_etag(raw)


async def write_workspace_file_bytes(
    user_id: str,
    workspace_id: str,
    relative_path: str,
    data: bytes,
    *,
    allow_ockham: bool = False,
) -> str:
    """Write *data* and return its ETag.

    The returned etag lets handlers echo it back to the client (so a writer
    can confirm what landed on disk without a round-trip read). Callers that
    don't care about the etag are free to ignore the return value.
    """
    rel = normalize_workspace_file_path(relative_path, allow_ockham=allow_ockham)
    st = get_workspace_blob_storage()
    key = _object_key_for_file(user_id, workspace_id, rel)
    await st.write(key, data)
    await _bump_workspace_updated_at(user_id, workspace_id)
    return compute_etag(data)


async def copy_workspace_file_object(
    user_id: str,
    workspace_id: str,
    source_path: str,
    destination_path: str,
) -> str:
    """Copy one visible workspace file and return the destination ETag."""
    src = normalize_workspace_file_path(source_path)
    dst = normalize_workspace_file_path(destination_path)
    if src == dst:
        raise ValueError("source and destination paths must differ")

    st = get_workspace_blob_storage()
    src_key = _object_key_for_file(user_id, workspace_id, src)
    dst_key = _object_key_for_file(user_id, workspace_id, dst)
    if not await st.exists(src_key):
        raise FileNotFoundError(src)
    if await st.exists(dst_key):
        raise FileExistsError(dst)
    data = await st.read(src_key)
    await st.write(dst_key, data)
    await _bump_workspace_updated_at(user_id, workspace_id)
    return compute_etag(data)


async def _content_addressed_destination_name(user_id: str, workspace_id: str, rel_src: str) -> tuple[str, str] | None:
    """For ``.ockham/<kind>s/<lid>/<csha><ext>`` sources, suggest ``(kind, <live_name>-<short_csha>.<ext>)``.

    Returns ``None`` for sources that aren't content-addressed snapshots
    (utility outputs, vanilla data_objects without curation).
    """
    parts = rel_src.split("/")
    # Expected: ['.ockham', '<kind>s', '<lid>', '<csha>.<ext>']
    if len(parts) != 4 or parts[0] != ".ockham":
        return None
    kind_dir = parts[1]
    lid = parts[2]
    basename = parts[3]
    kind: str | None
    ext: str | None
    if kind_dir == "datasets":
        kind, ext = "dataset", ".parquet"
    elif kind_dir == "charts":
        kind, ext = "chart", ".vl.json"
    elif kind_dir == "reports":
        kind, ext = "report", ".qmd"
    else:
        return None
    if not basename.endswith(ext):
        return None
    csha = basename[: -len(ext)]
    short = csha[:8] if len(csha) >= 8 else csha

    def _read_curation_blocking() -> dict | None:
        root = workspace_local_tree_path(user_id, workspace_id)
        return _read_curation_sync(root, kind, lid)

    cur = await asyncio.to_thread(_read_curation_blocking)
    live_name = cur.get("live_name") if isinstance(cur, dict) else None
    if not isinstance(live_name, str) or not live_name:
        # Without a curation live_name, fall back to default copy semantics.
        return None
    return kind, f"{live_name}-{short}{ext}"


async def materialize_workspace_file_ref(
    user_id: str,
    workspace_id: str,
    *,
    source: str,
    destination_folder: str,
    destination_path: str | None,
    source_etag: str | None,
) -> tuple[str, str]:
    """Copy bytes from an allowlisted private or any visible path to a visible file path.

    Returns ``(destination_relative_path, destination_etag)``.
    """
    rel_src = parse_workspace_file_ref(source)
    if not _is_allowed_materialize_source(rel_src):
        raise ValueError(f"source path is not allowed for materialization: {rel_src!r}")

    read_ockham = rel_src.startswith(".ockham/")
    result = await read_workspace_file_with_etag(user_id, workspace_id, rel_src, allow_ockham=read_ockham)
    if result is None:
        raise FileNotFoundError(rel_src)
    data, current_etag = result
    if source_etag is not None:
        expected = parse_if_none_match(source_etag) or source_etag.strip().strip('"')
        if expected != current_etag:
            raise SourceEtagPreconditionFailed(current_etag)

    if destination_path is not None:
        rel_dst = normalize_workspace_file_path(destination_path)
    else:
        rows = await list_workspace_files(user_id, workspace_id, include_hidden=False)
        existing = {p for p, _ in rows}
        # Content-addressed snapshots get a friendlier basename — derived
        # from the artifact's curation live_name + a short content_sha
        # suffix to avoid colliding with the live virtual entry (§4.4).
        suggested = await _content_addressed_destination_name(user_id, workspace_id, rel_src)
        if suggested is not None:
            kind, basename = suggested
            user_dir = _kind_dir_for_live(kind)
            preferred = (
                f"{destination_folder.strip().strip('/')}/{basename}"
                if destination_folder.strip().strip("/")
                else f"{user_dir}/{basename}"
            )
            if preferred not in existing:
                rel_dst = normalize_workspace_file_path(preferred)
            else:
                rel_dst = _resolve_visible_copy_destination(rel_src, destination_folder, existing)
        else:
            rel_dst = _resolve_visible_copy_destination(rel_src, destination_folder, existing)

    if rel_src == rel_dst:
        raise ValueError("source and destination paths must differ")

    st = get_workspace_blob_storage()
    dst_key = _object_key_for_file(user_id, workspace_id, rel_dst)
    if await st.exists(dst_key):
        raise FileExistsError(rel_dst)

    dest_etag = await write_workspace_file_bytes(user_id, workspace_id, rel_dst, data)
    return rel_dst, dest_etag


class LiveNameConflict(FileExistsError):
    """Raised when a virtual rename would shadow another artifact's live_name.

    Inherits from :class:`FileExistsError` so the existing 409 translation
    in the move route handler picks it up without a new branch.
    """


async def move_workspace_file_object(
    user_id: str,
    workspace_id: str,
    source_path: str,
    destination_path: str,
) -> str:
    """Move one visible workspace file and return the destination ETag.

    Polymorphic by source: when ``source_path`` resolves to a virtual
    live-tree entry (a curation ``live_name``), the move becomes a
    sidecar update — bytes are untouched and the snapshot ``content_sha``
    is preserved across the rename. Real blobs follow the legacy
    blob-move path. The single primitive keeps the wire shape simple
    ("workspace tree feels like a normal file tree") while honoring the
    content-addressed invariant on the back end.
    """
    src = normalize_workspace_file_path(source_path)
    dst = normalize_workspace_file_path(destination_path)
    if src == dst:
        raise ValueError("source and destination paths must differ")

    virt = await asyncio.to_thread(_resolve_virtual_entry_sync, user_id, workspace_id, src)
    if virt is not None:
        return await _rename_virtual_entry(user_id, workspace_id, virt, src, dst)

    st = get_workspace_blob_storage()
    src_key = _object_key_for_file(user_id, workspace_id, src)
    dst_key = _object_key_for_file(user_id, workspace_id, dst)
    if not await st.exists(src_key):
        raise FileNotFoundError(src)
    if await st.exists(dst_key):
        raise FileExistsError(dst)
    data = await st.read(src_key)
    await st.write(dst_key, data)
    await st.delete(src_key)
    await _bump_workspace_updated_at(user_id, workspace_id)
    return compute_etag(data)


async def _rename_virtual_entry(
    user_id: str,
    workspace_id: str,
    virt: tuple[str, str],
    src: str,
    dst: str,
) -> str:
    """Update ``curation.live_name`` to match ``dst``; preserves snapshot bytes.

    Constraints:
    - ``dst`` must live in the same kind directory as ``src``
      (``data/foo.parquet`` → ``data/bar.parquet``, never to ``charts/``).
    - ``dst`` basename must keep the kind's extension.
    - ``dst`` must not collide with another logical_id's live_name in
      the same kind (``LiveNameConflict``, → HTTP 409).
    """
    from server.api.workspace.snapshot_store import read_curation, write_curation

    kind, logical_id = virt
    src_user_dir = src.split("/", 1)[0]
    dst_parts = dst.split("/", 1)
    if len(dst_parts) != 2 or dst_parts[0] != src_user_dir:
        raise ValueError(
            f"cannot move virtual {kind} entry across directories "
            f"({src!r} → {dst!r}); rename within {src_user_dir}/ only"
        )
    ext = next(e for k, _, e in _CURATED_KIND_DIRS if k == kind)
    dst_basename = dst_parts[1]
    if not dst_basename.endswith(ext):
        raise ValueError(f"destination basename must end with {ext!r} for kind {kind!r}")
    new_live_name = dst_basename[: -len(ext)]
    if not new_live_name:
        raise ValueError("destination basename has no name before the extension")

    other = await asyncio.to_thread(_resolve_virtual_entry_sync, user_id, workspace_id, dst)
    if other is not None and other != virt:
        raise LiveNameConflict(f"live_name {new_live_name!r} is already used by another {kind}")
    # A real blob at ``dst`` would shadow the renamed virtual entry
    # (real-blob-wins per plan §4.1) — surface it as a collision so
    # the user knows the rename wouldn't be visible.
    st = get_workspace_blob_storage()
    if await st.exists(_object_key_for_file(user_id, workspace_id, dst)):
        raise LiveNameConflict(f"path {dst!r} is already used by a real file")

    cur = await read_curation(user_id, workspace_id, kind, logical_id)
    if cur is None:
        # We just resolved the entry from this curation; concurrent
        # delete is the only path here.
        raise FileNotFoundError(src)
    await write_curation(
        user_id,
        workspace_id,
        kind,
        logical_id,
        cur.model_copy(update={"live_name": new_live_name}),
    )
    await _bump_workspace_updated_at(user_id, workspace_id)
    body = await read_workspace_file_bytes(user_id, workspace_id, dst)
    return compute_etag(body or b"")


async def create_workspace_folder(user_id: str, workspace_id: str, relative_path: str) -> None:
    """Create one visible workspace folder."""

    target = _local_visible_path(user_id, workspace_id, relative_path)
    if target.exists():
        raise FileExistsError(relative_path)
    if target.parent.exists() and not target.parent.is_dir():
        raise ValueError("parent path is not a folder")
    target.mkdir(parents=True)
    await _bump_workspace_updated_at(user_id, workspace_id)


async def move_workspace_folder(
    user_id: str,
    workspace_id: str,
    source_path: str,
    destination_path: str,
) -> None:
    """Move one visible workspace folder."""

    src = _local_visible_path(user_id, workspace_id, source_path)
    dst = _local_visible_path(user_id, workspace_id, destination_path)
    if src == dst:
        raise ValueError("source and destination paths must differ")
    if not src.exists() or not src.is_dir():
        raise FileNotFoundError(source_path)
    if dst.exists():
        raise FileExistsError(destination_path)
    if src in dst.parents:
        raise ValueError("destination must not be inside source folder")
    if dst.parent.exists() and not dst.parent.is_dir():
        raise ValueError("parent path is not a folder")
    dst.parent.mkdir(parents=True, exist_ok=True)
    src.rename(dst)
    await _bump_workspace_updated_at(user_id, workspace_id)


async def delete_workspace_folder(user_id: str, workspace_id: str, relative_path: str) -> bool:
    """Delete one visible workspace folder recursively."""

    target = _local_visible_path(user_id, workspace_id, relative_path)
    if not target.exists() or not target.is_dir():
        return False
    shutil.rmtree(target)
    await _bump_workspace_updated_at(user_id, workspace_id)
    return True


async def delete_workspace_file_object(
    user_id: str, workspace_id: str, relative_path: str, *, allow_ockham: bool = False
) -> bool:
    """Delete a visible workspace file.

    Polymorphic by path (mirroring :func:`move_workspace_file_object`):
    if ``relative_path`` resolves to a virtual live-tree entry, the
    deletion is a soft-delete on the curation sidecar
    (``live_name = None``) — snapshots, log entries, and any embedded
    refs in chat history or reports stay intact and reachable. Real
    blobs are physically removed.
    """
    rel = normalize_workspace_file_path(relative_path, allow_ockham=allow_ockham)

    virt = await asyncio.to_thread(_resolve_virtual_entry_sync, user_id, workspace_id, rel)
    if virt is not None:
        return await _soft_delete_virtual_entry(user_id, workspace_id, virt)

    st = get_workspace_blob_storage()
    key = _object_key_for_file(user_id, workspace_id, rel)
    if not await st.exists(key):
        return False
    await st.delete(key)
    await _bump_workspace_updated_at(user_id, workspace_id)
    return True


async def _soft_delete_virtual_entry(user_id: str, workspace_id: str, virt: tuple[str, str]) -> bool:
    """Hide a virtual entry by clearing ``curation.live_name``.

    Reversible: re-publishing or PATCHing the live_name back restores
    the entry in the tree. Snapshot bytes and the log are untouched, so
    any frozen ref in chat history or a report continues to resolve.
    """
    from server.api.workspace.snapshot_store import read_curation, write_curation

    kind, logical_id = virt
    cur = await read_curation(user_id, workspace_id, kind, logical_id)
    if cur is None:
        return False
    await write_curation(
        user_id,
        workspace_id,
        kind,
        logical_id,
        cur.model_copy(update={"live_name": None}),
    )
    await _bump_workspace_updated_at(user_id, workspace_id)
    return True


async def list_workspace_files(
    user_id: str, workspace_id: str, *, include_hidden: bool = False
) -> list[tuple[str, int]]:
    """List files in the workspace tree.

    Hides the ``.ockham/`` private namespace by default. Set
    ``include_hidden=True`` to surface framework plumbing (utility outputs,
    transcripts, workspace metadata) for debugging.
    """
    entries = await list_workspace_entries(user_id, workspace_id, include_hidden=include_hidden)
    return [(path, size) for path, size, kind in entries if kind == "file"]


# ``.ockham/<kind>s`` directories where curation sidecars live (§2.4).
# Notebooks join the registry under the unified storage model: their
# snapshots live nested at ``.ockham/notebooks/<uuid>/<csha>.py`` and
# the user sees a virtual ``notebooks/<live_name>.py`` resolved from
# curation, exactly like ``data/<live_name>.parquet`` does for datasets.
_CURATED_KIND_DIRS: tuple[tuple[str, str, str], ...] = (
    ("notebook", ".ockham/notebooks", ".py"),
    ("dataset", ".ockham/datasets", ".parquet"),
    ("chart", ".ockham/charts", ".vl.json"),
    ("report", ".ockham/reports", ".qmd"),
)


def _kind_dir_for_live(rel: str) -> str:
    """Map an artifact kind to its user-visible directory in the live tree."""
    return {
        "notebook": "notebooks",
        "dataset": "data",
        "chart": "charts",
        "report": "reports",
    }[rel]


def _read_curation_sync(root: Path, kind: str, logical_id: str) -> dict | None:
    sidecar = root / f".ockham/{kind}s" / logical_id / "curation.json"
    if not sidecar.is_file():
        return None
    try:
        data = json.loads(sidecar.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return data if isinstance(data, dict) else None


def _latest_snapshot_sync(root: Path, kind: str, logical_id: str, ext: str) -> tuple[Path, str] | None:
    """Resolve the most-recent ``<content_sha><ext>`` snapshot for a logical artifact.

    Walks ``log.jsonl`` to find the latest entry's ``content_sha`` and
    returns ``(absolute_path, content_sha)`` when present on disk, else
    ``None``. §2.6 — an artifact whose log is missing or empty is "not
    yet persisted" and is invisible to readers.
    """
    log = root / f".ockham/{kind}s" / logical_id / "log.jsonl"
    if not log.is_file():
        return None
    try:
        text = log.read_text(encoding="utf-8")
    except OSError:
        return None
    last_sha: str | None = None
    for line in reversed(text.splitlines()):
        line = line.strip()
        if not line:
            continue
        try:
            entry = json.loads(line)
        except json.JSONDecodeError:
            continue
        sha = entry.get("content_sha")
        if isinstance(sha, str):
            last_sha = sha
            break
    if last_sha is None:
        return None
    snap = root / f".ockham/{kind}s" / logical_id / f"{last_sha}{ext}"
    if not snap.is_file():
        return None
    return snap, last_sha


def _virtual_live_entries_sync(root: Path) -> list[tuple[str, int, str]]:
    """Synthesize virtual entries from ``curation.live_name`` (§4.1)."""
    out: list[tuple[str, int, str]] = []
    for kind, dirname, ext in _CURATED_KIND_DIRS:
        kind_dir = root / dirname
        if not kind_dir.is_dir():
            continue
        for lid_dir in kind_dir.iterdir():
            if not lid_dir.is_dir():
                continue
            cur = _read_curation_sync(root, kind, lid_dir.name)
            if cur is None:
                continue
            live_name = cur.get("live_name")
            if not isinstance(live_name, str) or not live_name:
                continue
            snap = _latest_snapshot_sync(root, kind, lid_dir.name, ext)
            if snap is None:
                continue
            snap_path, _csha = snap
            user_dir = _kind_dir_for_live(kind)
            virtual_rel = f"{user_dir}/{live_name}{ext}"
            try:
                size = snap_path.stat().st_size
            except OSError:
                size = 0
            out.append((virtual_rel, size, "file"))
    return out


def _list_workspace_entries_sync(user_id: str, workspace_id: str, include_hidden: bool) -> list[tuple[str, int, str]]:
    """Blocking walk of the workspace tree; run via :func:`asyncio.to_thread`.

    Layered over the real blob walk: virtual entries derived from
    curation sidecars (§4.1) extend each artifact's live_name into the
    user-visible tree. Real blobs always win on path collision; the
    virtual layer is filtered to non-colliding live names.
    """
    root = workspace_local_tree_path(user_id, workspace_id)
    if not root.is_dir():
        return []
    out: list[tuple[str, int, str]] = []
    real_paths: set[str] = set()
    for item in root.rglob("*"):
        rel = item.relative_to(root).as_posix()
        if not include_hidden and (rel == ".ockham" or rel.startswith(".ockham/")):
            continue
        if item.is_dir():
            out.append((rel, 0, "directory"))
        elif item.is_file():
            out.append((rel, item.stat().st_size, "file"))
            real_paths.add(rel)
    for virtual in _virtual_live_entries_sync(root):
        if virtual[0] in real_paths:
            continue
        out.append(virtual)
    return sorted(out, key=lambda x: (x[0].count("/"), x[0]))


async def list_workspace_entries(
    user_id: str, workspace_id: str, *, include_hidden: bool = False
) -> list[tuple[str, int, str]]:
    """List visible files and directories in the workspace tree."""
    return await asyncio.to_thread(_list_workspace_entries_sync, user_id, workspace_id, include_hidden)


async def materialize_workspace_to_disk(user_id: str, workspace_id: str) -> Path:
    """Directory the sandbox executor should use as cwd."""
    st = get_workspace_blob_storage()
    return await st.materialize_prefix(_workspace_tree_prefix(user_id, workspace_id))


async def persist_workspace_disk_to_blob_if_needed(
    user_id: str,
    workspace_id: str,
    local_dir: Path,
) -> None:
    """After an agent turn, push materialized files back to remote storage (no-op locally)."""
    st = get_workspace_blob_storage()
    await st.sync_back(local_dir, _workspace_tree_prefix(user_id, workspace_id))


def extract_workspace_file_refs(message: str) -> list[str]:
    """Extract canonical visible workspace file refs from a user message."""

    refs: list[str] = []
    seen: set[str] = set()
    for match in _FILE_REF_RE.finditer(message):
        rel = normalize_workspace_file_path(decode_path_from_file_ref(match.group(1)))
        if rel in seen:
            continue
        seen.add(rel)
        refs.append(rel)
    return refs


# ---------------------------------------------------------------------------
# list_artifacts — discovery channel for the agent.
#
# The agent's <turn_artifacts> block carries only artifacts the calling
# terminal has interacted with this conversation. Anything else — including
# work done by sibling terminals in the same workspace — is reachable only
# through this active tool. Workspace-scoped (cross-terminal artifacts are
# intentionally visible); isolation is enforced by prompt + the resolver
# collision gate, not by hiding the listing.
# ---------------------------------------------------------------------------

_LIST_ARTIFACTS_KINDS: tuple[str, ...] = (
    "notebook",
    "dataset",
    "chart",
    "report",
    "data_object",
)

_SIDECAR_FILES = frozenset({"curation.json", "log.jsonl"})


def _latest_snapshot_file(logical_dir: Path) -> Path | None:
    """Return the most-recent content-addressed snapshot in ``logical_dir``.

    Sidecars (``curation.json``, ``log.jsonl``, ``*.lock``) are skipped;
    what remains is the immutable ``<content_sha>.<ext>`` snapshot files.
    Picks the newest by mtime so refreshed artifacts surface their latest
    revision. Returns ``None`` when no snapshot has been written yet.
    """
    candidates: list[tuple[float, Path]] = []
    try:
        for child in logical_dir.iterdir():
            if not child.is_file():
                continue
            if child.name in _SIDECAR_FILES:
                continue
            if child.name.endswith(".lock"):
                continue
            try:
                mtime = child.stat().st_mtime
            except OSError:
                continue
            candidates.append((mtime, child))
    except OSError:
        return None
    if not candidates:
        return None
    candidates.sort(key=lambda x: -x[0])
    return candidates[0][1]


def _list_workspace_artifacts_sync(
    local_dir: Path,
    query: str | None,
    kind: str | None,
    limit: int,
) -> list[dict[str, Any]]:
    """Walk ``<local_dir>/.ockham/<kind>s/<lid>/curation.json`` and return summaries.

    Matches ``query`` (case-insensitive substring) against ``live_name``,
    ``title``, ``description``, ``source`` (data_object) and ``tags``.
    Sorted by curation mtime descending. Returns up to ``limit`` items.

    Each row is ``{"live_name", "kind", "title", "summary", "logical_id"}`` —
    no on-disk path. The agent dereferences artifacts via
    ``read_artifact(live_name=…, kind=…)``; the host resolves to bytes
    internally. Artifacts whose curation has no ``live_name`` are
    skipped: the agent cannot reference them, so listing them is noise.
    """
    root = local_dir / ".ockham"
    if not root.is_dir():
        return []
    kinds: tuple[str, ...]
    if kind:
        if kind not in _LIST_ARTIFACTS_KINDS:
            return []
        kinds = (kind,)
    else:
        kinds = _LIST_ARTIFACTS_KINDS

    q = (query or "").strip().lower()
    items: list[tuple[float, dict[str, Any]]] = []
    for k in kinds:
        kind_dir = root / f"{k}s"
        if not kind_dir.is_dir():
            continue
        for logical_dir in kind_dir.iterdir():
            if not logical_dir.is_dir():
                continue
            curation_file = logical_dir / "curation.json"
            if not curation_file.is_file():
                continue
            try:
                data = json.loads(curation_file.read_bytes().decode("utf-8"))
            except (OSError, json.JSONDecodeError, UnicodeDecodeError):
                continue

            live_name = (data.get("live_name") or "").strip()
            if not live_name:
                # No slug ⇒ the agent has no handle. Skip.
                continue
            title = (data.get("title") or "").strip()
            description = (data.get("description") or "").strip()
            tags = data.get("tags") or []
            source = (data.get("source") or "").strip()  # data_object curation

            if q:
                haystack = " ".join(
                    [
                        live_name.lower(),
                        title.lower(),
                        description.lower(),
                        source.lower(),
                        " ".join(str(t).lower() for t in tags),
                        logical_dir.name.lower(),
                    ]
                )
                if q not in haystack:
                    continue

            # Non-notebook kinds need an actual snapshot on disk for the
            # host's read path to work. Skip if not yet written.
            if k != "notebook":
                snapshot_file = _latest_snapshot_file(logical_dir)
                if snapshot_file is None:
                    continue

            summary = title if title and title != live_name else ""
            if not summary and description:
                summary = description
            if not summary and tags:
                summary = "tags: " + ", ".join(str(t) for t in tags[:5])
            if len(summary) > 100:
                summary = summary[:97] + "..."

            try:
                mtime = curation_file.stat().st_mtime
            except OSError:
                mtime = 0.0

            items.append(
                (
                    mtime,
                    {
                        "live_name": live_name,
                        "kind": k,
                        "title": title,
                        "summary": summary,
                        "logical_id": logical_dir.name,
                    },
                )
            )

    items.sort(key=lambda x: -x[0])
    return [item[1] for item in items[: max(1, min(100, limit))]]


_LIVE_NAME_EXT_BY_KIND: dict[str, str] = {
    "notebook": ".py",
    "dataset": ".parquet",
    "chart": ".vl.json",
    "report": ".report.md",
}


def resolve_live_name_to_workspace_file_path(local_dir: Path, kind: str, live_name: str) -> str | None:
    """``(kind, live_name) → ".ockham/<kind>s/<lid>/<csha>.<ext>"`` or ``None``.

    Single host-side resolver for the agent's ``read_artifact`` tool. Walks
    ``.ockham/<kind>s/*/curation.json`` for a sidecar whose ``live_name``
    matches; once found, reads ``log.jsonl`` for the latest ``content_sha``
    and assembles the canonical snapshot path. Returns ``None`` when:

    - the kind dir does not exist
    - no curation has the requested ``live_name``
    - the matched curation has no ``log.jsonl`` or no usable entries
    - the resolved snapshot file does not exist on disk

    Notebooks fall through to the same machinery — the in-memory cwd is
    the materialised workspace, so the snapshot path is what the
    executor's ``read_workspace_file`` operates on (it does not need the
    virtual ``notebooks/<live_name>.py`` form).
    """
    ext = _LIVE_NAME_EXT_BY_KIND.get(kind)
    if ext is None:
        return None
    kind_dir = local_dir / ".ockham" / f"{kind}s"
    if not kind_dir.is_dir():
        return None
    for entry in kind_dir.iterdir():
        if not entry.is_dir():
            continue
        curation_file = entry / "curation.json"
        if not curation_file.is_file():
            continue
        try:
            data = json.loads(curation_file.read_bytes().decode("utf-8"))
        except (OSError, json.JSONDecodeError, UnicodeDecodeError):
            continue
        if not isinstance(data, dict):
            continue
        if data.get("kind") != kind:
            continue
        if data.get("live_name") != live_name:
            continue
        log = entry / "log.jsonl"
        if not log.is_file():
            return None
        last_csha: str | None = None
        try:
            for line in log.read_bytes().decode("utf-8").splitlines():
                stripped = line.strip()
                if not stripped:
                    continue
                try:
                    log_row = json.loads(stripped)
                except json.JSONDecodeError:
                    continue
                csha = log_row.get("content_sha") if isinstance(log_row, dict) else None
                if isinstance(csha, str) and csha:
                    last_csha = csha
        except (OSError, UnicodeDecodeError):
            return None
        if last_csha is None:
            return None
        snapshot = entry / f"{last_csha}{ext}"
        if not snapshot.is_file():
            return None
        return f".ockham/{kind}s/{entry.name}/{last_csha}{ext}"
    return None


async def list_workspace_artifacts_in_tree(
    local_dir: Path,
    *,
    query: str | None = None,
    kind: str | None = None,
    limit: int = 20,
) -> list[dict[str, Any]]:
    """Async wrapper for :func:`_list_workspace_artifacts_sync`.

    The agent calls this via its ``list_artifacts`` tool. Reads curations
    from the materialised workspace directory the executor already has on
    disk — no extra storage round-trip.
    """
    return await asyncio.to_thread(_list_workspace_artifacts_sync, local_dir, query, kind, limit)


async def render_referenced_files_for_llm(user_id: str, workspace_id: str, message: str) -> str:
    """Render user-mentioned ``file://./...`` refs as explicit LLM context.

    This keeps the wire/UI value file-centric while giving the current turn a
    typed, validated view of referenced artifacts. Hidden ``.ockham`` files are
    rejected by ``normalize_workspace_file_path`` because user refs are public
    workspace affordances.
    """

    refs = extract_workspace_file_refs(message)
    if not refs:
        return message

    sections: list[str] = []
    for rel in refs:
        raw = await read_workspace_file_bytes(user_id, workspace_id, rel)
        if raw is None:
            raise FileNotFoundError(rel)
        sections.append(_referenced_file_section(rel, raw))

    return f"{message}\n\n<referenced_files>\n{''.join(sections)}</referenced_files>"


def _referenced_file_section(path: str, raw: bytes) -> str:
    # Bounded projection: e.g. notebook docstring + section outline, not full code.
    body = read_artifact_for_llm(path, raw, mode="summary")
    return f'<file path="{path}">\n{body}\n</file>\n'


def _decode_text_preview(raw: bytes) -> str:
    if len(raw) > _MAX_REFERENCED_TEXT_BYTES:
        raw = raw[:_MAX_REFERENCED_TEXT_BYTES]
        suffix = "\n... [truncated]"
    else:
        suffix = ""
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        return "<binary />"
    return f"<text>\n{text}{suffix}\n</text>"


def _new_terminal_title(existing: list[TerminalSessionMeta]) -> str:
    return f"Terminal {len(existing) + 1}"


async def _write_terminal_index(user_id: str, workspace_id: str, sessions: list[TerminalSessionMeta]) -> None:
    st = get_workspace_blob_storage()
    key = _terminal_index_key(user_id, workspace_id)
    payload = json.dumps([s.model_dump(mode="json") for s in sessions], default=str).encode("utf-8")
    await st.write(key, payload)


async def _create_terminal_session_locked(
    user_id: str,
    workspace_id: str,
    sessions: list[TerminalSessionMeta],
    title: str,
) -> TerminalSessionMeta:
    now = datetime.now(UTC)
    session = TerminalSessionMeta(
        id=str(uuid4()),
        title=title,
        created_at=now,
        updated_at=now,
    )
    next_sessions = [*sessions, session]
    await _write_terminal_index(user_id, workspace_id, next_sessions)
    st = get_workspace_blob_storage()
    await st.write(_terminal_transcript_key(user_id, workspace_id, session.id), b"")
    return session


async def maybe_migrate_legacy_terminal(user_id: str, workspace_id: str) -> None:
    st = get_workspace_blob_storage()
    index_key = _terminal_index_key(user_id, workspace_id)
    legacy_key = _legacy_terminal_key(user_id, workspace_id)
    if await st.exists(index_key) or not await st.exists(legacy_key):
        return

    legacy_raw = await st.read(legacy_key)
    now = datetime.now(UTC)
    migrated = TerminalSessionMeta(
        id=str(uuid4()),
        title="Terminal 1",
        created_at=now,
        updated_at=now,
    )
    await _write_terminal_index(user_id, workspace_id, [migrated])
    await st.write(_terminal_transcript_key(user_id, workspace_id, migrated.id), legacy_raw)
    await st.delete(legacy_key)


async def _load_terminal_sessions_unlocked(user_id: str, workspace_id: str) -> list[TerminalSessionMeta]:
    """List terminal sessions. Caller must hold :func:`_workspace_terminals_lock`."""
    await maybe_migrate_legacy_terminal(user_id, workspace_id)
    st = get_workspace_blob_storage()
    key = _terminal_index_key(user_id, workspace_id)
    if not await st.exists(key):
        created = await _create_terminal_session_locked(user_id, workspace_id, [], "Terminal 1")
        return [created]
    raw = await st.read(key)
    parsed = json.loads(raw.decode("utf-8"))
    sessions = [TerminalSessionMeta.model_validate(row) for row in parsed]
    if sessions:
        return sessions
    created = await _create_terminal_session_locked(user_id, workspace_id, [], "Terminal 1")
    return [created]


async def load_terminal_sessions(user_id: str, workspace_id: str) -> list[TerminalSessionMeta]:
    lock = await _workspace_terminals_lock(user_id, workspace_id)
    async with lock:
        return await _load_terminal_sessions_unlocked(user_id, workspace_id)


async def get_terminal_session(user_id: str, workspace_id: str, terminal_id: str) -> TerminalSessionMeta | None:
    sessions = await load_terminal_sessions(user_id, workspace_id)
    for session in sessions:
        if session.id == terminal_id:
            return session
    return None


async def create_terminal_session(user_id: str, workspace_id: str, title: str | None = None) -> TerminalSessionMeta:
    lock = await _workspace_terminals_lock(user_id, workspace_id)
    async with lock:
        sessions = await _load_terminal_sessions_unlocked(user_id, workspace_id)
        next_title = title.strip() if title else ""
        if not next_title:
            next_title = _new_terminal_title(sessions)
        return await _create_terminal_session_locked(user_id, workspace_id, sessions, next_title)


async def update_terminal_session(
    user_id: str,
    workspace_id: str,
    terminal_id: str,
    *,
    title: str | None,
) -> TerminalSessionMeta | None:
    lock = await _workspace_terminals_lock(user_id, workspace_id)
    async with lock:
        sessions = await _load_terminal_sessions_unlocked(user_id, workspace_id)
        next_sessions: list[TerminalSessionMeta] = []
        updated: TerminalSessionMeta | None = None
        for session in sessions:
            if session.id != terminal_id:
                next_sessions.append(session)
                continue
            updated_title = title.strip() if title is not None else session.title
            next_session = TerminalSessionMeta(
                id=session.id,
                title=updated_title,
                created_at=session.created_at,
                updated_at=datetime.now(UTC),
            )
            next_sessions.append(next_session)
            updated = next_session
        if updated is None:
            return None
        await _write_terminal_index(user_id, workspace_id, next_sessions)
        return updated


async def delete_terminal_session(user_id: str, workspace_id: str, terminal_id: str) -> bool:
    lock = await _workspace_terminals_lock(user_id, workspace_id)
    async with lock:
        sessions = await _load_terminal_sessions_unlocked(user_id, workspace_id)
        next_sessions = [session for session in sessions if session.id != terminal_id]
        if len(next_sessions) == len(sessions):
            return False
        await _write_terminal_index(user_id, workspace_id, next_sessions)
        st = get_workspace_blob_storage()
        transcript_key = _terminal_transcript_key(user_id, workspace_id, terminal_id)
        if await st.exists(transcript_key):
            await st.delete(transcript_key)
        if not next_sessions:
            await _create_terminal_session_locked(user_id, workspace_id, next_sessions, "Terminal 1")
        return True


async def load_terminal_jsonl(user_id: str, workspace_id: str, terminal_id: str) -> list[dict[str, object]]:
    session = await get_terminal_session(user_id, workspace_id, terminal_id)
    if session is None:
        return []
    st = get_workspace_blob_storage()
    key = _terminal_transcript_key(user_id, workspace_id, terminal_id)
    if not await st.exists(key):
        return []
    raw = await st.read(key)
    lines: list[dict[str, object]] = []
    for line in raw.decode("utf-8").splitlines():
        line = line.strip()
        if line:
            lines.append(json.loads(line))
    return lines


async def append_terminal_jsonl(user_id: str, workspace_id: str, terminal_id: str, record: dict[str, object]) -> None:
    line = (json.dumps(record, default=str) + "\n").encode("utf-8")
    lock = await _workspace_terminals_lock(user_id, workspace_id)
    async with lock:
        sessions = await _load_terminal_sessions_unlocked(user_id, workspace_id)
        if not any(s.id == terminal_id for s in sessions):
            raise ValueError("Terminal session not found")

        st = get_workspace_blob_storage()
        key = _terminal_transcript_key(user_id, workspace_id, terminal_id)
        await st.append(key, line)

        next_sessions: list[TerminalSessionMeta] = []
        now = datetime.now(UTC)
        for row in sessions:
            if row.id == terminal_id:
                next_sessions.append(
                    TerminalSessionMeta(
                        id=row.id,
                        title=row.title,
                        created_at=row.created_at,
                        updated_at=now,
                    )
                )
            else:
                next_sessions.append(row)
        await _write_terminal_index(user_id, workspace_id, next_sessions)


def _extract_artifact_pair_from_file_ref(local_dir: Path, row: dict[str, object]) -> tuple[str, str] | None:
    """Return ``(kind, live_name)`` for a persisted ``file_ref`` row, or ``None``.

    Used during terminal history replay to recover the calling terminal's
    seen-set of artifacts it has previously published or read. The pair
    feeds the cross-terminal collision gate: without it, every new turn
    starts with an empty seen-set and the terminal cannot recognise its
    own past mints.
    """
    if row.get("type") != "file_ref":
        return None
    content = row.get("content")
    if not isinstance(content, dict):
        return None
    workspace_file_path = content.get("workspace_file_path")
    if not isinstance(workspace_file_path, str) or not workspace_file_path:
        return None

    # Virtual notebook path: basename IS the live_name.
    notebook_match = re.match(r"^notebooks/([^/]+)\.py$", workspace_file_path)
    if notebook_match is not None:
        return ("notebook", notebook_match.group(1))

    # Canonical content-addressed path: live_name lives in the curation
    # sibling. Reading curation here is one open() per replayed row.
    canonical_match = re.match(
        r"^\.ockham/(notebooks|datasets|charts|reports|data_objects)/([^/]+)/[^/]+\.",
        workspace_file_path,
    )
    if canonical_match is None:
        return None
    kind_dir, logical_id = canonical_match.group(1), canonical_match.group(2)
    kind_map = {
        "notebooks": "notebook",
        "datasets": "dataset",
        "charts": "chart",
        "reports": "report",
        "data_objects": "data_object",
    }
    kind = kind_map.get(kind_dir)
    if kind is None:
        return None
    curation_file = local_dir / ".ockham" / kind_dir / logical_id / "curation.json"
    try:
        data = json.loads(curation_file.read_bytes().decode("utf-8"))
    except (OSError, json.JSONDecodeError, UnicodeDecodeError):
        return None
    if not isinstance(data, dict):
        return None
    live_name = data.get("live_name")
    if not isinstance(live_name, str) or not live_name:
        return None
    return (kind, live_name)


def _extract_artifact_refs_from_text_payload(row: dict[str, object]) -> list[tuple[str, str]]:
    """Pull ``<artifact_ref/>`` tags out of any persisted text payload.

    Catches the tag that ``read_artifact_to_llm_result`` prepends to its
    result text. The tag survives the JSONL round-trip inside
    ``content.content.content`` (SystemToolOutput → Text → string), but
    the existing text-only replay path filters records whose ``content``
    is not a bare ``_TextBlock``. Walk the row dict via the same scanner
    the agent uses to compute its in-turn seen-set — it handles every
    nested shape and tolerates malformed structures silently.
    """
    from parsimony_agents.agent.seen_refs import extract_seen_live_names

    return list(extract_seen_live_names([row]))


def build_workspace_agent_context(
    workspace_id: str,
    history: list[dict[str, object]],
    *,
    local_dir: Path | None = None,
) -> AgentContext:
    """Build :class:`AgentContext` from persisted terminal history.

    Processes record shapes from the JSONL transcript:

    * ``{"role": ..., "content": {"type": "text", "content": "..."}}`` — user /
      assistant text turns, replayed into LLM context verbatim.
    * ``{"type": "kernel_restart", "at": "...", ...}`` — durable restart markers
      written by router (auto-detected) or streaming (agent-initiated). Each
      produces an inline system message so the agent sees restart events at their
      exact chronological position in the conversation.
    * ``{"type": "file_ref", "content": {"workspace_file_path": ...}}`` —
      framework events for ``return_*`` mints and ``edit_*`` advances.
      When ``local_dir`` is provided, each is collapsed into a synthetic
      ``<artifact_ref kind=… live_name=…/>`` system message so the agent's
      seen-set extractor recognises this terminal's prior work across
      turn boundaries. Without this, the cross-turn filter in
      ``<turn_artifacts>`` hides the terminal's own published artifacts.
    * Records whose persisted text payload contains
      ``<artifact_ref kind=… live_name=…/>`` (read_artifact results) —
      same treatment.
    """
    msgs: list[AgentMessage] = [
        AgentMessage(role="system", content=Text(content="placeholder")),
    ]

    # Collect the terminal's seen-set first, deduped, in order of first sighting.
    # This goes in once at the head of the message graph; the agent's snapshot
    # builder re-extracts the seen-set off this every iteration.
    seen_pairs: list[tuple[str, str]] = []
    seen_index: set[tuple[str, str]] = set()

    def _record_pair(pair: tuple[str, str] | None) -> None:
        if pair is None:
            return
        if pair in seen_index:
            return
        seen_index.add(pair)
        seen_pairs.append(pair)

    for row in history:
        if local_dir is not None:
            _record_pair(_extract_artifact_pair_from_file_ref(local_dir, row))
        for pair in _extract_artifact_refs_from_text_payload(row):
            _record_pair(pair)

    if seen_pairs:
        # Single synthetic system message — keeps the prompt clean and
        # lets the regex scanner pick everything up in one pass.
        tags_text = "\n".join(
            f'<artifact_ref kind="{kind}" live_name="{live_name}"/>' for kind, live_name in seen_pairs
        )
        msgs.append(AgentMessage(role="system", content=Text(content=tags_text)))

    for row in history:
        kr = parse_kernel_restart(row)
        if kr is not None:
            at = kr.at or "unknown time"
            msgs.append(
                AgentMessage(
                    role="system",
                    content=Text(
                        content=(
                            f"[KERNEL RESTARTED] The Python kernel was restarted at {at}. "
                            "All variables have been cleared. "
                            "Workspace files and notebooks are preserved."
                        )
                    ),
                )
            )
            continue

        turn = parse_user_assistant_text(row)
        if turn is None:
            continue
        text_content = turn.content.content
        if turn.role == "user":
            msgs.append(AgentMessage(role="user", content=Text(content=text_content)))
        else:
            msgs.append(AgentMessage(role="assistant", content=Text(content=text_content)))

    return AgentContext(session_id=workspace_id, messages=msgs)
