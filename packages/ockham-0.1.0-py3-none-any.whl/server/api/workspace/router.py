"""HTTP routes for workspace IDE."""

from __future__ import annotations

import asyncio
import contextlib
import mimetypes
import re
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Literal

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi import Request as FastAPIRequest
from fastapi.responses import JSONResponse, Response
from opentelemetry import context as otel_context
from parsimony_agents.agent.cancellation import CancellationRequest
from starlette.responses import StreamingResponse

from server import product
from server.api.agent import get_workspace_agent
from server.api.config import config
from server.api.executor_cache import delete_cached_executor_id, get_cached_executor_id
from server.api.middleware import get_current_user_id
from server.api.streaming import SendMessageRequest
from server.api.streaming.models import CancelTerminalRunResponse
from server.api.workspace import service, watcher
from server.api.workspace.etag import notebook_view_etag, parse_if_none_match
from server.api.workspace.models import (
    CopyWorkspaceFileRequest,
    CreateTerminalRequest,
    CreateWorkspaceFolderRequest,
    CreateWorkspaceRequest,
    FileEntry,
    MaterializeWorkspaceFileRefRequest,
    MaterializeWorkspaceFileRefResponse,
    MoveWorkspaceFileRequest,
    MoveWorkspaceFolderRequest,
    TerminalSessionMeta,
    UpdateTerminalRequest,
    UpdateWorkspaceRequest,
    WorkspaceMetadata,
    WorkspaceSummary,
)
from server.api.workspace.ref_enrichment import enrich_artifact_envelope
from server.api.workspace.streaming import stream_workspace_conversation
from server.api.workspace.terminal_runs import (
    ActiveRunInProgressError,
    register_active_run,
    request_terminal_cancel,
    unregister_active_run,
)
from server.api.workspace.viewers import NotebookStateLoader, viewer_payload_for_path
from server.core.cache import get_cache
from server.core.monitoring import create_session_context, get_logger, get_tracer, set_context
from server.execution import RemoteCodeExecutor

router = APIRouter(prefix="/api/workspaces", tags=["workspaces"])
logger = get_logger("SYSTEM")
logger_user = get_logger("USER")

# ETag is authoritative; do not let shared HTTP caches treat workspace bytes as static assets.
_ARTIFACT_CACHE_CONTROL = "private, no-cache"
tracer = get_tracer("server.api.workspace")


def _ping_executor_status_sync(base_url: str, executor_id: str) -> str:
    """Return ``'ok'``, ``'gone'`` (no such executor), or ``'error'`` (transient / unknown)."""
    import httpx

    try:
        with httpx.Client(timeout=5.0) as client:
            resp = client.get(f"{base_url}/executors/{executor_id}/ping")
            if resp.status_code == 200:
                return "ok"
            if resp.status_code == 404:
                return "gone"
            return "error"
    except Exception:
        return "error"


async def _ping_executor_resolved(base_url: str, executor_id: str) -> str:
    """Ping with a couple of retries; last result is one of ``ok``/``gone``/``error``."""
    import asyncio

    last = "error"
    for attempt in (0, 1, 2):
        if attempt:
            await asyncio.sleep(0.1 * attempt)
        last = await asyncio.to_thread(_ping_executor_status_sync, base_url, executor_id)
        if last == "ok":
            return "ok"
        if last == "gone":
            return "gone"
    return last


@router.post("", response_model=WorkspaceMetadata)
async def create_workspace(
    body: CreateWorkspaceRequest,
    user_id: str = Depends(get_current_user_id),
) -> WorkspaceMetadata:
    return await service.create_workspace(user_id, body.title)


@router.get("", response_model=list[WorkspaceSummary])
async def list_workspaces(user_id: str = Depends(get_current_user_id)) -> list[WorkspaceSummary]:
    return await service.list_workspaces(user_id)


@router.get("/{workspace_id}", response_model=WorkspaceMetadata)
async def get_workspace(
    workspace_id: str,
    user_id: str = Depends(get_current_user_id),
) -> WorkspaceMetadata:
    meta = await service.get_workspace(user_id, workspace_id)
    if meta is None:
        raise HTTPException(status_code=404, detail="Workspace not found")
    return meta


@router.patch("/{workspace_id}", response_model=WorkspaceMetadata)
async def patch_workspace(
    workspace_id: str,
    body: UpdateWorkspaceRequest,
    user_id: str = Depends(get_current_user_id),
) -> WorkspaceMetadata:
    updated = await service.update_workspace(
        user_id,
        workspace_id,
        title=body.title,
        settings=body.settings,
    )
    if updated is None:
        raise HTTPException(status_code=404, detail="Workspace not found")
    return updated


@router.delete("/{workspace_id}", status_code=204)
async def delete_workspace_route(
    workspace_id: str,
    user_id: str = Depends(get_current_user_id),
) -> Response:
    ok = await service.delete_workspace(user_id, workspace_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Workspace not found")
    return Response(status_code=204)


@router.get("/{workspace_id}/files", response_model=list[FileEntry])
async def list_files(
    workspace_id: str,
    user_id: str = Depends(get_current_user_id),
    include_hidden: bool = Query(False),
) -> list[FileEntry]:
    if await service.get_workspace(user_id, workspace_id) is None:
        raise HTTPException(status_code=404, detail="Workspace not found")
    rows = await service.list_workspace_entries(user_id, workspace_id, include_hidden=include_hidden)
    return [FileEntry(path=p, size_bytes=n, kind=k) for p, n, k in rows]


@router.post("/{workspace_id}/files:copy", status_code=204)
async def copy_workspace_file_route(
    workspace_id: str,
    body: CopyWorkspaceFileRequest,
    user_id: str = Depends(get_current_user_id),
) -> Response:
    if await service.get_workspace(user_id, workspace_id) is None:
        raise HTTPException(status_code=404, detail="Workspace not found")
    try:
        etag = await service.copy_workspace_file_object(
            user_id,
            workspace_id,
            body.source_path,
            body.destination_path,
        )
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=f"Source file not found: {e}") from e
    except FileExistsError as e:
        raise HTTPException(status_code=409, detail=f"Destination file already exists: {e}") from e
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
    return Response(status_code=204, headers={"ETag": f'"{etag}"'})


@router.post(
    "/{workspace_id}/files:materialize-ref",
    response_model=MaterializeWorkspaceFileRefResponse,
)
async def materialize_workspace_file_ref_route(
    workspace_id: str,
    body: MaterializeWorkspaceFileRefRequest,
    user_id: str = Depends(get_current_user_id),
) -> MaterializeWorkspaceFileRefResponse:
    """Copy bytes from a file ref (including allowlisted ``.ockham/`` sources) to a visible path."""
    if await service.get_workspace(user_id, workspace_id) is None:
        raise HTTPException(status_code=404, detail="Workspace not found")
    try:
        path, etag = await service.materialize_workspace_file_ref(
            user_id,
            workspace_id,
            source=body.source,
            destination_folder=body.destination_folder,
            destination_path=body.destination_path,
            source_etag=body.source_etag,
        )
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=f"Source file not found: {e}") from e
    except FileExistsError as e:
        raise HTTPException(status_code=409, detail=f"Destination file already exists: {e}") from e
    except service.SourceEtagPreconditionFailed as e:
        raise HTTPException(
            status_code=412,
            detail=f"Source ETag mismatch; current ETag is {e.current_etag!r}",
        ) from e
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
    return MaterializeWorkspaceFileRefResponse(path=path, etag=etag)


@router.post("/{workspace_id}/files:move", status_code=204)
async def move_workspace_file_route(
    workspace_id: str,
    body: MoveWorkspaceFileRequest,
    user_id: str = Depends(get_current_user_id),
) -> Response:
    if await service.get_workspace(user_id, workspace_id) is None:
        raise HTTPException(status_code=404, detail="Workspace not found")
    try:
        etag = await service.move_workspace_file_object(
            user_id,
            workspace_id,
            body.source_path,
            body.destination_path,
        )
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=f"Source file not found: {e}") from e
    except service.LiveNameConflict as e:
        raise HTTPException(status_code=409, detail=str(e)) from e
    except FileExistsError as e:
        raise HTTPException(status_code=409, detail=f"Destination file already exists: {e}") from e
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
    return Response(status_code=204, headers={"ETag": f'"{etag}"'})


@router.post("/{workspace_id}/folders", status_code=204)
async def create_workspace_folder_route(
    workspace_id: str,
    body: CreateWorkspaceFolderRequest,
    user_id: str = Depends(get_current_user_id),
) -> Response:
    if await service.get_workspace(user_id, workspace_id) is None:
        raise HTTPException(status_code=404, detail="Workspace not found")
    try:
        await service.create_workspace_folder(user_id, workspace_id, body.path)
    except FileExistsError as e:
        raise HTTPException(status_code=409, detail=f"Folder already exists: {e}") from e
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
    return Response(status_code=204)


@router.post("/{workspace_id}/folders:move", status_code=204)
async def move_workspace_folder_route(
    workspace_id: str,
    body: MoveWorkspaceFolderRequest,
    user_id: str = Depends(get_current_user_id),
) -> Response:
    if await service.get_workspace(user_id, workspace_id) is None:
        raise HTTPException(status_code=404, detail="Workspace not found")
    try:
        await service.move_workspace_folder(
            user_id,
            workspace_id,
            body.source_path,
            body.destination_path,
        )
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=f"Source folder not found: {e}") from e
    except FileExistsError as e:
        raise HTTPException(status_code=409, detail=f"Destination folder already exists: {e}") from e
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
    return Response(status_code=204)


_REPORT_FORMATS: tuple[str, ...] = ("html", "pdf", "pptx", "dashboard", "revealjs")
_REPORT_MEDIA_TYPES: dict[str, str] = {
    "html": "text/html; charset=utf-8",
    "pdf": "application/pdf",
    "pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    "dashboard": "text/html; charset=utf-8",
    "revealjs": "text/html; charset=utf-8",
}
_REPORT_DOWNLOAD_EXT: dict[str, str] = {
    "html": "html",
    "pdf": "pdf",
    "pptx": "pptx",
    "dashboard": "html",
    "revealjs": "html",
}

# One shared cache for the running process — bounded LRU + in-flight
# coalescing. Refresh storms render once per (snapshot, format) tuple.
_REPORT_CACHE: Any = None


def _get_report_cache():
    global _REPORT_CACHE
    if _REPORT_CACHE is None:
        from server.api.workspace.report.cache import RenderCache

        _REPORT_CACHE = RenderCache(capacity=64)
    return _REPORT_CACHE


@router.get("/{workspace_id}/exports/{path:path}")
async def export_workspace_file(
    workspace_id: str,
    path: str,
    request: FastAPIRequest,
    user_id: str = Depends(get_current_user_id),
    fmt: Literal["csv", "xlsx", "html", "pdf", "pptx", "dashboard", "revealjs"] = Query(..., alias="format"),
) -> Response:
    """Export a workspace file in a derived format.

    Source-extension dispatch:

    * ``.parquet``     → ``format=csv|xlsx``                              (dataset egress).
    * ``.qmd``  → ``format=html|pdf|pptx|dashboard|revealjs``      (Quarto-rendered report).

    Reports use a content-addressed render cache with in-flight
    coalescing — N concurrent requests for the same fresh snapshot
    render once. ETag participates so browsers/CDNs hit ``304 Not
    Modified`` on repeat requests.
    """
    if await service.get_workspace(user_id, workspace_id) is None:
        raise HTTPException(status_code=404, detail="Workspace not found")
    try:
        rel = service.normalize_workspace_file_path(path, allow_ockham=True)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e

    if rel.endswith(".qmd"):
        if fmt not in _REPORT_FORMATS:
            raise HTTPException(
                status_code=400,
                detail=f"Reports only support format in {list(_REPORT_FORMATS)}",
            )
        return await _export_report(
            user_id=user_id,
            workspace_id=workspace_id,
            rel=rel,
            fmt=fmt,
            if_none_match=request.headers.get("if-none-match"),
        )

    if rel.endswith(".parquet"):
        if fmt not in ("csv", "xlsx"):
            raise HTTPException(status_code=400, detail="Datasets only support format=csv or xlsx")
        raw = await service.read_workspace_file_bytes(user_id, workspace_id, rel, allow_ockham=True)
        if raw is None:
            raise HTTPException(status_code=404, detail="File not found")
        try:
            if fmt == "csv":
                body = service.parquet_bytes_to_csv(raw)
                media_type = "text/csv; charset=utf-8"
                extension = "csv"
            else:
                body = service.parquet_bytes_to_xlsx(raw)
                media_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                extension = "xlsx"
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e)) from e
        stem = Path(rel).name.removesuffix(".parquet")
        filename = f"{stem}.{extension}"
        return Response(
            content=body,
            media_type=media_type,
            headers={"Content-Disposition": f'attachment; filename="{filename}"'},
        )

    raise HTTPException(status_code=400, detail="Exports not supported for this file type")


async def _export_report(
    *,
    user_id: str,
    workspace_id: str,
    rel: str,
    fmt: str,
    if_none_match: str | None,
) -> Response:
    """Read a ``.qmd``, render via Quarto, return the bytes.

    Pulls refs from blob storage in parallel, hands a dict-backed
    loader to the renderer, caches the result. The persisted body is
    pre-validated at write-time so we trust it here; missing refs are
    a 404 surfacing an agent bug.
    """
    from parsimony_agents.report_format import parse_snapshot

    from server.api.workspace.report import (
        QUARTO_VERSION,
        RenderError,
        RenderTimeout,
        render,
    )
    from server.api.workspace.report.render import (
        RenderInputs,
        encode_for_etag,
        templates_hash,
    )

    raw = await service.read_workspace_file_bytes(user_id, workspace_id, rel, allow_ockham=True)
    if raw is None:
        raise HTTPException(status_code=404, detail="Report not found")
    try:
        snapshot_text = raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise HTTPException(status_code=400, detail=f"Report is not valid UTF-8: {exc}") from exc

    snap = parse_snapshot(snapshot_text)
    if fmt not in snap.formats:
        raise HTTPException(
            status_code=400,
            detail=f"Snapshot does not declare format {fmt!r}; declared: {snap.formats}",
        )

    # Pre-fetch every pinned artifact's bytes in parallel — the renderer
    # is sync once we have the blobs. The pin map (frozen at publish
    # time) is the source of truth for what to fetch; body URIs resolve
    # to these refs via the same map.
    rel_paths = sorted({ref.workspace_file_path for ref in snap.pins.values()})
    blob_results = await asyncio.gather(
        *[service.read_workspace_file_bytes(user_id, workspace_id, p, allow_ockham=True) for p in rel_paths]
    )
    blobs: dict[str, bytes] = {}
    for rp, blob in zip(rel_paths, blob_results, strict=True):
        if blob is None:
            raise HTTPException(status_code=404, detail=f"Report references missing workspace file: {rp}")
        blobs[rp] = blob

    # Cache key: snapshot content_sha + fmt + Quarto version + templates hash.
    # The on-disk path encodes content_sha already.
    csha = _extract_csha(rel)
    cache_key = (csha, fmt, QUARTO_VERSION, templates_hash())
    etag = f'W/"{encode_for_etag(cache_key)}"'

    if if_none_match and if_none_match.strip() == etag:
        return Response(status_code=304, headers={"ETag": etag, "Cache-Control": _ARTIFACT_CACHE_CONTROL})

    async def _compute() -> bytes:
        return await render(RenderInputs(snapshot_bytes=raw, fmt=fmt, workspace_loader=blobs.get))

    try:
        out_bytes = await _get_report_cache().get_or_render(cache_key, _compute)
    except RenderTimeout as exc:
        raise HTTPException(status_code=504, detail=str(exc)) from exc
    except RenderError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    stem = Path(rel).name.removesuffix(".qmd")
    display = snap.title or stem
    filename_ext = _REPORT_DOWNLOAD_EXT[fmt]
    filename = f"{_slugify_filename(display) or stem}.{filename_ext}"

    headers = {
        "ETag": etag,
        "Cache-Control": _ARTIFACT_CACHE_CONTROL,
    }
    # HTML-shaped previews are loaded inline (the iframe needs to render
    # them). Everything else is a download.
    if _REPORT_MEDIA_TYPES[fmt].startswith("text/html"):
        # The dashboard format embeds JS that requires same-origin to
        # run inside an iframe — frame-ancestors restricts to our SPA.
        headers["Content-Security-Policy"] = "frame-ancestors 'self'"
    else:
        headers["Content-Disposition"] = f'attachment; filename="{filename}"'

    return Response(content=out_bytes, media_type=_REPORT_MEDIA_TYPES[fmt], headers=headers)


def _extract_csha(rel: str) -> str:
    """Pull ``<csha>`` out of ``.ockham/reports/<lid>/<csha>.qmd``.

    Path-shape robustness: the snapshot lives at that one canonical
    layout. Anything else and we fall back to the basename, which
    still gives stable cache keys (the report is identified by its
    bytes anyway via the content_sha).
    """
    name = Path(rel).name
    return name.removesuffix(".qmd")


_FILENAME_SAFE_RE = re.compile(r"[^a-z0-9]+")


def _slugify_filename(text: str) -> str:
    """Lowercased, hyphen-separated, ASCII-safe slug for a download filename."""
    s = text.strip().lower()
    s = _FILENAME_SAFE_RE.sub("-", s).strip("-")
    return s[:80]


@router.get("/{workspace_id}/files/{path:path}")
async def get_workspace_file(
    workspace_id: str,
    path: str,
    fastapi_request: FastAPIRequest,
    user_id: str = Depends(get_current_user_id),
    fmt: Literal["raw", "json"] = Query("raw", alias="format"),
    offset: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=10_000),
):
    if await service.get_workspace(user_id, workspace_id) is None:
        raise HTTPException(status_code=404, detail="Workspace not found")
    try:
        rel = service.normalize_workspace_file_path(path, allow_ockham=True)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
    try:
        result = await service.read_workspace_file_with_etag(user_id, workspace_id, rel, allow_ockham=True)
    except OSError as e:
        raise HTTPException(status_code=400, detail=f"Invalid file path: {e}") from e
    if result is None:
        raise HTTPException(status_code=404, detail="File not found")
    raw, etag = result
    quoted_etag = f'"{etag}"'

    if_none_match = parse_if_none_match(fastapi_request.headers.get("if-none-match"))
    if if_none_match == etag:
        return Response(
            status_code=304,
            headers={"ETag": quoted_etag, "Cache-Control": _ARTIFACT_CACHE_CONTROL},
        )

    if fmt == "json":
        if not rel.endswith(".parquet"):
            raise HTTPException(
                status_code=400,
                detail="format=json is only supported for .parquet files",
            )
        try:
            payload = service.parquet_bytes_to_json_view(raw, offset=offset, limit=limit)
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e)) from e
        return JSONResponse(content=payload, headers={"ETag": quoted_etag, "Cache-Control": _ARTIFACT_CACHE_CONTROL})
    name = Path(rel).name
    media_type, _ = mimetypes.guess_type(name, strict=False)
    if not media_type:
        media_type = "application/octet-stream"
    return Response(
        content=raw,
        media_type=media_type,
        headers={"ETag": quoted_etag, "Cache-Control": _ARTIFACT_CACHE_CONTROL},
    )


@router.get("/{workspace_id}/view/{path:path}")
async def view_workspace_artifact(
    workspace_id: str,
    path: str,
    fastapi_request: FastAPIRequest,
    user_id: str = Depends(get_current_user_id),
):
    """Return the structured viewer payload for a parsimony-agents primitive artifact.

    Single endpoint for all primitive types — dispatch happens by extension
    inside :func:`viewer_payload_for_path`. The file's open-format bytes are
    parsed once, the embedded metadata is surfaced under ``metadata``, and a
    type-specific render payload sits under ``payload``. Frontend viewers
    read this directly; they don't (re)parse parquet/vega-lite themselves.

    Notebook state (cached cell outputs) is loaded out-of-band from
    ``.ockham/notebook-state/`` and returned alongside; absent state means
    "code-only render" without erroring.
    """

    if await service.get_workspace(user_id, workspace_id) is None:
        raise HTTPException(status_code=404, detail="Workspace not found")
    try:
        rel = service.normalize_workspace_file_path(path, allow_ockham=True)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
    try:
        result = await service.read_workspace_file_with_etag(user_id, workspace_id, rel, allow_ockham=True)
    except OSError as e:
        raise HTTPException(status_code=400, detail=f"Invalid file path: {e}") from e
    if result is None:
        raise HTTPException(status_code=404, detail="File not found")
    raw, file_etag = result

    # View payload for .py may include ``.ockham/notebook-state/<sha>.json`` which
    # does not change the notebook's file etag. A composite view etag (script
    # bytes + state bytes) is required or clients with (etag === lastViewEtag)
    # skip refetch and never see new ``data_objects`` when only the sidecar
    # updates. The client may also receive notebook-state file-change events;
    # the composite ETag is the server-side backstop.
    if rel.endswith(".py"):
        from parsimony_agents import deserialize_notebook, notebook_state_cache_key

        script = deserialize_notebook(raw, path=rel)
        cache_rel = f".ockham/{notebook_state_cache_key(script)}"
        cache_blob = await service.read_workspace_file_bytes(user_id, workspace_id, cache_rel, allow_ockham=True)
        view_etag = notebook_view_etag(script_py_bytes=raw, state_cache_bytes=cache_blob)

        def _notebook_state_loader(_script):  # noqa: ANN001
            return cache_blob

        state_loader: NotebookStateLoader | None = _notebook_state_loader
    else:
        view_etag = file_etag
        state_loader = None

    quoted_etag = f'"{view_etag}"'
    if_none_match = parse_if_none_match(fastapi_request.headers.get("if-none-match"))
    if if_none_match == view_etag:
        return Response(
            status_code=304,
            headers={"ETag": quoted_etag, "Cache-Control": _ARTIFACT_CACHE_CONTROL},
        )

    payload = viewer_payload_for_path(rel, raw, notebook_state_loader=state_loader)
    # Enrich typed refs in the artifact envelope with ``workspace_file_path``
    # and a best-effort ``display_name``. The viewer payload is sync and
    # works from in-memory bytes; enrichment reads sibling files (curation
    # sidecars, data_object provenance, notebook source) so the panel
    # renders human pills instead of content-sha basenames.
    payload = await enrich_artifact_envelope(payload, user_id=user_id, workspace_id=workspace_id, path=rel)
    return JSONResponse(content=payload, headers={"ETag": quoted_etag, "Cache-Control": _ARTIFACT_CACHE_CONTROL})


@router.put("/{workspace_id}/files/{path:path}")
async def put_workspace_file(
    workspace_id: str,
    path: str,
    fastapi_request: FastAPIRequest,
    user_id: str = Depends(get_current_user_id),
):
    if await service.get_workspace(user_id, workspace_id) is None:
        raise HTTPException(status_code=404, detail="Workspace not found")
    try:
        rel = service.normalize_workspace_file_path(path)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
    body = await fastapi_request.body()
    max_b = config.MAX_FILE_SIZE_MB * 1024 * 1024
    if len(body) > max_b:
        raise HTTPException(
            status_code=413,
            detail=f"File exceeds maximum size of {config.MAX_FILE_SIZE_MB} MB",
        )
    etag = await service.write_workspace_file_bytes(user_id, workspace_id, rel, body)
    return Response(status_code=204, headers={"ETag": f'"{etag}"'})


@router.get("/{workspace_id}/events")
async def workspace_events(
    workspace_id: str,
    fastapi_request: FastAPIRequest,
    user_id: str = Depends(get_current_user_id),
) -> StreamingResponse:
    """Server-sent events for filesystem-level file changes in this workspace.

    Carries ``{path, etag, op, at}`` for any write to the workspace tree, no
    matter who wrote (agent, REST PUT, drag-drop upload, external editor in
    the desktop wrapper). Frontend ``fileService`` consumes this single bus to
    keep its etag map in sync; viewers re-fetch on etag change.
    """
    if await service.get_workspace(user_id, workspace_id) is None:
        raise HTTPException(status_code=404, detail="Workspace not found")

    async def gen():
        import json

        # Initial comment lets clients (and proxies) confirm the stream is open.
        yield ": ok\n\n"
        try:
            async for event in watcher.subscribe(user_id, workspace_id):
                if await fastapi_request.is_disconnected():
                    break
                yield f"data: {json.dumps(event)}\n\n"
        except Exception:
            logger.exception("workspace events stream failed for workspace %s", workspace_id)
            return

    return StreamingResponse(
        gen(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache, no-transform",
            "X-Accel-Buffering": "no",
            "Connection": "keep-alive",
        },
    )


@router.delete("/{workspace_id}/files/{path:path}", status_code=204)
async def delete_workspace_file_route(
    workspace_id: str,
    path: str,
    user_id: str = Depends(get_current_user_id),
) -> Response:
    if await service.get_workspace(user_id, workspace_id) is None:
        raise HTTPException(status_code=404, detail="Workspace not found")
    try:
        rel = service.normalize_workspace_file_path(path)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
    ok = await service.delete_workspace_file_object(user_id, workspace_id, rel)
    if not ok:
        raise HTTPException(status_code=404, detail="File not found")
    return Response(status_code=204)


@router.delete("/{workspace_id}/folders/{path:path}", status_code=204)
async def delete_workspace_folder_route(
    workspace_id: str,
    path: str,
    user_id: str = Depends(get_current_user_id),
) -> Response:
    if await service.get_workspace(user_id, workspace_id) is None:
        raise HTTPException(status_code=404, detail="Workspace not found")
    try:
        ok = await service.delete_workspace_folder(user_id, workspace_id, path)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
    if not ok:
        raise HTTPException(status_code=404, detail="Folder not found")
    return Response(status_code=204)


_VALID_CURATION_KINDS = ("dataset", "chart", "report")


class CurationPatchBody(__import__("pydantic").BaseModel):
    """Body schema for the curation PATCH endpoint (§4.5).

    ``extra="forbid"`` makes recipe fields (notably ``variable_name``,
    which participates in ``logical_id``) un-PATCHable: any unknown
    field in the body produces a 422. This keeps identity intact —
    editing the variable name would invalidate the artifact.
    """

    model_config = __import__("pydantic").ConfigDict(extra="forbid")

    title: str | None = None
    description: str | None = None
    tags: list[str] | None = None
    notes: list[str] | None = None
    live_name: str | None = None


@router.patch(
    "/{workspace_id}/artifacts/{kind}/{logical_id}/curation",
    response_model=dict,
)
async def patch_artifact_curation(
    workspace_id: str,
    kind: str,
    logical_id: str,
    body: CurationPatchBody,
    user_id: str = Depends(get_current_user_id),
) -> dict:
    """Update an artifact's curation sidecar without touching snapshot bytes (§4.5).

    Only fields provided in the body are merged onto the existing
    sidecar. ``live_name`` may be set to an empty string to opt the
    artifact out of the live workspace tree.
    """
    if kind not in _VALID_CURATION_KINDS:
        raise HTTPException(
            status_code=400,
            detail=f"kind must be one of {_VALID_CURATION_KINDS!r}, got {kind!r}",
        )
    if await service.get_workspace(user_id, workspace_id) is None:
        raise HTTPException(status_code=404, detail="Workspace not found")

    from server.api.workspace.snapshot_store import (
        read_curation,
        write_curation,
    )

    existing = await read_curation(user_id, workspace_id, kind, logical_id)
    if existing is None:
        raise HTTPException(status_code=404, detail="Artifact not found")

    update: dict[str, Any] = {}
    if body.title is not None:
        update["title"] = body.title
    if body.description is not None:
        update["description"] = body.description
    if body.tags is not None:
        update["tags"] = list(body.tags)
    if body.notes is not None:
        update["notes"] = list(body.notes)
    if body.live_name is not None:
        # Empty string → null sentinel (hide from live tree).
        update["live_name"] = body.live_name if body.live_name != "" else None

    if not update:
        # Nothing to update — return the current sidecar unchanged.
        return existing.model_dump(mode="json")

    new_curation = existing.model_copy(update=update)
    await write_curation(user_id, workspace_id, kind, logical_id, new_curation)
    refreshed = await read_curation(user_id, workspace_id, kind, logical_id)
    assert refreshed is not None  # we just wrote it
    return refreshed.model_dump(mode="json")


@router.get("/{workspace_id}/terminals", response_model=list[TerminalSessionMeta])
async def list_workspace_terminals(
    workspace_id: str,
    user_id: str = Depends(get_current_user_id),
) -> list[TerminalSessionMeta]:
    if await service.get_workspace(user_id, workspace_id) is None:
        raise HTTPException(status_code=404, detail="Workspace not found")
    return await service.load_terminal_sessions(user_id, workspace_id)


@router.post("/{workspace_id}/terminals", response_model=TerminalSessionMeta)
async def create_workspace_terminal(
    workspace_id: str,
    body: CreateTerminalRequest,
    user_id: str = Depends(get_current_user_id),
) -> TerminalSessionMeta:
    if await service.get_workspace(user_id, workspace_id) is None:
        raise HTTPException(status_code=404, detail="Workspace not found")
    title = body.title.strip()
    if not title:
        raise HTTPException(status_code=400, detail="title is required")
    return await service.create_terminal_session(user_id, workspace_id, title)


@router.patch("/{workspace_id}/terminals/{terminal_id}", response_model=TerminalSessionMeta)
async def patch_workspace_terminal(
    workspace_id: str,
    terminal_id: str,
    body: UpdateTerminalRequest,
    user_id: str = Depends(get_current_user_id),
) -> TerminalSessionMeta:
    if await service.get_workspace(user_id, workspace_id) is None:
        raise HTTPException(status_code=404, detail="Workspace not found")
    if body.title is not None and not body.title.strip():
        raise HTTPException(status_code=400, detail="title must not be empty")
    updated = await service.update_terminal_session(
        user_id,
        workspace_id,
        terminal_id,
        title=body.title,
    )
    if updated is None:
        raise HTTPException(status_code=404, detail="Terminal session not found")
    return updated


@router.delete("/{workspace_id}/terminals/{terminal_id}", status_code=204)
async def delete_workspace_terminal(
    workspace_id: str,
    terminal_id: str,
    user_id: str = Depends(get_current_user_id),
) -> Response:
    if await service.get_workspace(user_id, workspace_id) is None:
        raise HTTPException(status_code=404, detail="Workspace not found")
    ok = await service.delete_terminal_session(user_id, workspace_id, terminal_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Terminal session not found")
    return Response(status_code=204)


@router.post(
    "/{workspace_id}/terminals/{terminal_id}/cancel",
    response_model=CancelTerminalRunResponse,
)
async def cancel_workspace_terminal_run(
    workspace_id: str,
    terminal_id: str,
    user_id: str = Depends(get_current_user_id),
) -> CancelTerminalRunResponse:
    if await service.get_workspace(user_id, workspace_id) is None:
        raise HTTPException(status_code=404, detail="Workspace not found")
    if await service.get_terminal_session(user_id, workspace_id, terminal_id) is None:
        raise HTTPException(status_code=404, detail="Terminal session not found")
    result = await request_terminal_cancel(user_id, workspace_id, terminal_id, reason="user_request")
    return CancelTerminalRunResponse(
        cancelled=result.found,
        response_id=result.response_id,
    )


@router.get("/{workspace_id}/terminals/{terminal_id}/messages")
async def get_workspace_terminal_messages(
    workspace_id: str,
    terminal_id: str,
    user_id: str = Depends(get_current_user_id),
) -> list[dict[str, object]]:
    if await service.get_workspace(user_id, workspace_id) is None:
        raise HTTPException(status_code=404, detail="Workspace not found")
    terminal = await service.get_terminal_session(user_id, workspace_id, terminal_id)
    if terminal is None:
        raise HTTPException(status_code=404, detail="Terminal session not found")
    return await service.load_terminal_jsonl(user_id, workspace_id, terminal_id)


async def _send_workspace_terminal_message(
    *,
    workspace_id: str,
    terminal_id: str,
    request_body: SendMessageRequest,
    fastapi_request: FastAPIRequest,
    user_id: str,
):
    if await service.get_workspace(user_id, workspace_id) is None:
        raise HTTPException(status_code=404, detail="Workspace not found")
    terminal = await service.get_terminal_session(user_id, workspace_id, terminal_id)
    if terminal is None:
        raise HTTPException(status_code=404, detail="Terminal session not found")
    if not request_body.message.strip():
        raise HTTPException(status_code=400, detail="message is required")

    tier_id = request_body.selected_model_set
    if tier_id not in product.TIERS:
        raise HTTPException(status_code=400, detail=f"Unknown tier '{tier_id}'")
    tier = product.TIERS[tier_id]
    model_id = tier.model

    request_id = str(uuid.uuid4())
    session_ctx = create_session_context(workspace_id)
    scoped_session_id = f"ws-{workspace_id}-{terminal_id}"
    session_ctx = set_context(
        ctx=session_ctx,
        user_id=user_id,
        session_id=scoped_session_id,
        model=model_id,
        request_id=request_id,
    )
    token = otel_context.attach(session_ctx)

    try:
        message_preview = (
            request_body.message[:1000] + "..." if len(request_body.message) > 1000 else request_body.message
        )
        with tracer.start_as_current_span(
            "workspace_agent_execution",
            attributes={
                "agent.prompt": message_preview,
                "agent.model": model_id,
                "workspace.id": workspace_id,
            },
        ):
            logger_user.info("Workspace message", extra={"workspace_id": workspace_id})

            turn_response_id = str(uuid.uuid4())
            cancellation_req = CancellationRequest()
            try:
                await register_active_run(
                    user_id,
                    workspace_id,
                    terminal_id,
                    response_id=turn_response_id,
                    cancel_event=cancellation_req.event,
                )
            except ActiveRunInProgressError:
                raise HTTPException(
                    status_code=409,
                    detail="A message is already being processed for this terminal",
                ) from None

            try:
                sandbox_url = (config.SANDBOX_URL or config.EXECUTOR_URL or "").strip()
                cache = get_cache()
                fastapi_request.app.state.executor_cache = cache
                cached_executor_id: str | None = None
                if sandbox_url:
                    cached_executor_id = await get_cached_executor_id(cache, scoped_session_id)

                history = await service.load_terminal_jsonl(user_id, workspace_id, terminal_id)

                # HTTP sandbox: append a kernel_restart line only if the remote executor id is
                # known and the sandbox reports it gone (404). Transient ping failures and an
                # empty in-process cache do not imply a restart.
                is_kernel_restart = False
                if len(history) > 0 and sandbox_url and cached_executor_id is not None:
                    status = await _ping_executor_resolved(sandbox_url, cached_executor_id)
                    if status == "gone":
                        is_kernel_restart = True
                        cached_executor_id = None
                    elif status == "error":
                        await delete_cached_executor_id(cache, scoped_session_id)
                        cached_executor_id = None

                if is_kernel_restart:
                    await service.append_terminal_jsonl(
                        user_id,
                        workspace_id,
                        terminal_id,
                        {
                            "type": "kernel_restart",
                            "source": "auto_detected",
                            "at": datetime.now(UTC).isoformat(),
                        },
                    )
                    history = await service.load_terminal_jsonl(user_id, workspace_id, terminal_id)

                local_dir = await service.materialize_workspace_to_disk(user_id, workspace_id)
                ctx = service.build_workspace_agent_context(workspace_id, history, local_dir=local_dir)
                try:
                    llm_message = await service.render_referenced_files_for_llm(
                        user_id, workspace_id, request_body.message
                    )
                except FileNotFoundError as e:
                    raise HTTPException(status_code=404, detail=f"Referenced file not found: {e}") from e
                except ValueError as e:
                    raise HTTPException(status_code=400, detail=str(e)) from e

                agent = await get_workspace_agent(
                    fastapi_request,
                    model_id,
                    workspace_id,
                    terminal_id,
                    workspace_root=str(local_dir),
                    session_cache_key=scoped_session_id,
                    cached_executor_id=cached_executor_id,
                )
            except Exception:
                await unregister_active_run(user_id, workspace_id, terminal_id, response_id=turn_response_id)
                raise

            async def on_discard_kernel() -> None:
                if sandbox_url:
                    await delete_cached_executor_id(get_cache(), scoped_session_id)
                if isinstance(agent.code_executor, RemoteCodeExecutor):
                    await agent.code_executor.discard_and_close()
                else:
                    d: dict[str, Any] = getattr(fastapi_request.app.state, "in_process_code_executors", None) or {}
                    ex = d.pop(scoped_session_id, None)
                    if ex is not None:
                        with contextlib.suppress(Exception):
                            await ex.close()

            async def stream_response():
                inner_token = otel_context.attach(session_ctx)

                async def _watch_disconnect() -> None:
                    try:
                        while True:
                            if await fastapi_request.is_disconnected():
                                cancellation_req.reason = "client_disconnect"
                                cancellation_req.set()
                                return
                            await asyncio.sleep(0.2)
                    except asyncio.CancelledError:
                        return

                wtask = asyncio.create_task(_watch_disconnect())
                try:
                    async with contextlib.aclosing(
                        stream_workspace_conversation(
                            request_body,
                            agent,
                            ctx,
                            user_id=user_id,
                            workspace_id=workspace_id,
                            terminal_id=terminal_id,
                            local_dir=local_dir,
                            cancellation=cancellation_req,
                            turn_response_id=turn_response_id,
                            on_discard_kernel=on_discard_kernel,
                            llm_message=llm_message,
                        )
                    ) as convo:
                        try:
                            async for chunk in convo:
                                yield chunk
                        finally:
                            wtask.cancel()
                            with contextlib.suppress(asyncio.CancelledError, Exception):
                                await wtask
                finally:
                    otel_context.detach(inner_token)

            return StreamingResponse(stream_response(), media_type="text/event-stream")
    finally:
        otel_context.detach(token)


@router.post("/{workspace_id}/terminals/{terminal_id}/messages")
async def send_workspace_terminal_message(
    workspace_id: str,
    terminal_id: str,
    request_body: SendMessageRequest,
    fastapi_request: FastAPIRequest,
    user_id: str = Depends(get_current_user_id),
):
    return await _send_workspace_terminal_message(
        workspace_id=workspace_id,
        terminal_id=terminal_id,
        request_body=request_body,
        fastapi_request=fastapi_request,
        user_id=user_id,
    )
