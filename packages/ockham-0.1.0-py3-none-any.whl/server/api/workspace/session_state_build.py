"""Build :class:`parsimony_agents.agent.session_state.SessionState` for workspace turns."""

from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path

from parsimony_agents.agent.session_state import (
    KernelVariableSummary,
    SessionState,
    WorkspaceArtifactLine,
    kernel_summaries_from_locals_map,
    parse_kernel_summaries_from_remote,
)
from parsimony_agents.execution.executor import BaseCodeExecutor, CodeExecutor
from parsimony_agents.identity import ArtifactRef

from server.api.workspace.artifact_llm import artifact_summary_for_path
from server.api.workspace.viewers import viewer_for_path
from server.execution import RemoteCodeExecutor

logger = logging.getLogger(__name__)

# Bound automatic artifact context: session_state is a hint surface, not a data dump.
_MAX_WORKSPACE_ARTIFACT_SUMMARY_CHARS = 12_000


async def collect_kernel_summaries(executor: BaseCodeExecutor) -> list[KernelVariableSummary]:
    """Summarise live kernel variables using the in-process map or sandbox JSON."""
    if isinstance(executor, CodeExecutor):
        return kernel_summaries_from_locals_map(executor.get_locals())
    if isinstance(executor, RemoteCodeExecutor):
        raw = await asyncio.to_thread(executor.fetch_kernel_summaries)
        return parse_kernel_summaries_from_remote(raw)
    return []


_VERSIONED_KIND_DIRS = (
    "datasets",
    "charts",
    "reports",
    "notebooks",
    "data_objects",
)
_PUBLISHABLE_TIER = 0
_NOTEBOOK_TIER = 1
_DATA_OBJECT_TIER = 2
_USER_DATA_TIER = 3


def _classify_path(rel: str) -> int | None:
    """Classify a workspace path into a session-state relevance tier.

    Returns the tier (lower = more relevant) or ``None`` to skip.
    """
    # All content-addressed snapshots live under the same nested layout
    # ``.ockham/<kind>s/<logical_id>/<content_sha>.<ext>`` — including
    # notebooks, post the unification refactor.
    for kind_dir in _VERSIONED_KIND_DIRS:
        prefix = f".ockham/{kind_dir}/"
        if rel.startswith(prefix):
            base = rel.rsplit("/", 1)[-1]
            # Skip per-logical_id sidecars; surface only snapshot files.
            if base in {"log.jsonl", "curation.json"}:
                return None
            if not rel.endswith((".parquet", ".vl.json", ".qmd", ".py")):
                return None
            if kind_dir == "notebooks":
                return _NOTEBOOK_TIER
            if kind_dir == "data_objects":
                return _DATA_OBJECT_TIER
            return _PUBLISHABLE_TIER
    if rel.startswith("data/") and rel.endswith(".parquet"):
        return _USER_DATA_TIER
    return None


def _ref_for_path(rel: str, raw: bytes) -> ArtifactRef | None:
    """Parse a canonical ``.ockham/<kind>s/<lid>/<csha>.<ext>`` path into an ArtifactRef.

    All five kinds use the same nested layout under the unified model,
    so :meth:`ArtifactRef.from_workspace_file_path` covers everything.
    Returns ``None`` for paths outside the canonical layout
    (visible-tree user data, etc.).

    The ``raw`` bytes are unused but kept in the signature for parity
    with caller patterns where a reader has already loaded the file.
    """
    del raw  # unused; bytes-derived hashing was a flat-notebook holdover
    return ArtifactRef.from_workspace_file_path(rel)


def _live_name_for_ref(local_dir: Path, ref: ArtifactRef | None) -> str | None:
    """Read the ``live_name`` from a typed artifact's curation sidecar.

    Returns ``None`` for refs without a curation file (data_objects use
    a different sidecar shape; unregistered files have none) or when
    the curation has no ``live_name``.
    """
    if ref is None or ref.kind == "data_object":
        return None
    cur = local_dir / ".ockham" / f"{ref.kind}s" / ref.logical_id / "curation.json"
    if not cur.is_file():
        return None
    try:
        data = json.loads(cur.read_bytes().decode("utf-8"))
    except (OSError, json.JSONDecodeError, UnicodeDecodeError):
        return None
    val = data.get("live_name") if isinstance(data, dict) else None
    return val if isinstance(val, str) and val else None


def collect_workspace_artifact_lines(local_dir: Path, *, max_items: int = 48) -> list[WorkspaceArtifactLine]:
    """Scan the materialised tree for notebook and Ockham artifact files; one line each.

    Walks the per-kind content-addressed namespaces under ``.ockham/`` so the agent
    sees returned dataset/chart/report pointers in :class:`SessionState`.

    Resilience: one corrupt file does not fail the turn (the path is skipped).
    Relevance: published artifacts and recently touched notebooks are surfaced first;
    total summary characters are capped.
    """
    scored: list[tuple[int, float, str]] = []
    for p in local_dir.rglob("*"):
        if not p.is_file():
            continue
        rel = p.relative_to(local_dir).as_posix()
        tier = _classify_path(rel)
        if tier is None:
            continue
        try:
            mtime = p.stat().st_mtime
        except OSError:
            mtime = 0.0
        scored.append((tier, -mtime, rel))
    # tier ascending (cards first), then most recently modified within tier, then path.
    scored.sort(key=lambda x: (x[0], x[1], x[2]))
    out: list[WorkspaceArtifactLine] = []
    skipped = 0
    total_summary_chars = 0
    for _, _, rel in scored:
        if len(out) >= max_items:
            break
        if total_summary_chars >= _MAX_WORKSPACE_ARTIFACT_SUMMARY_CHARS:
            break
        try:
            raw = (local_dir / rel).read_bytes()
            spec = viewer_for_path(rel)
            if spec is None:
                continue
            summary = artifact_summary_for_path(rel, raw)
            if summary is None:
                continue
        except Exception as exc:  # noqa: BLE001 — best-effort session hints; never fail the turn
            skipped += 1
            logger.info("session_state: skip unreadable or invalid artifact %s: %s", rel, exc)
            continue
        if total_summary_chars + len(summary) > _MAX_WORKSPACE_ARTIFACT_SUMMARY_CHARS:
            break
        total_summary_chars += len(summary)
        ref = _ref_for_path(rel, raw)
        live_name = _live_name_for_ref(local_dir, ref)
        out.append(
            WorkspaceArtifactLine(
                path=rel,
                kind=spec.kind,
                summary=summary,
                live_name=live_name,
                ref=ref,
            )
        )
    if skipped:
        logger.warning(
            "session_state: skipped %s workspace artifact file(s) due to read/parse errors",
            skipped,
        )
    return out


async def build_session_state(
    *,
    code_executor: BaseCodeExecutor,
    local_dir: Path,
) -> SessionState:
    kernel = await collect_kernel_summaries(code_executor)
    workspace_artifacts = collect_workspace_artifact_lines(local_dir)
    return SessionState(kernel=kernel, workspace_artifacts=workspace_artifacts)


__all__ = [
    "build_session_state",
    "collect_kernel_summaries",
    "collect_workspace_artifact_lines",
]
