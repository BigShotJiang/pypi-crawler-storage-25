"""Wire models for the workspace SSE stream.

One transport stream, one chunk taxonomy. Chunks discriminate on
``type``; the typed payload sits on ``data``. All chunks serialize via
:meth:`StreamChunk.to_sse_chunk`, which prefers ``to_frontend_dict()``
to keep large in-memory artifacts (DataFrames, figures) from leaking
into the wire payload.

The file is the artifact: ``return_*`` tools, notebooks, and utility
tool outputs all surface on the wire as a single :class:`FileRefChunk`
carrying ``(kind, workspace_file_path, etag)`` — the file holds the
metadata, the wire holds the pointer. The ``kind`` is an open
discriminator validated against the viewer registry, not enumerated in
the wire schema, so adding a new file kind never requires a chunk
schema change.

:class:`TerminalMessage` is the persisted shape of one transcript entry
in the workspace's ``.ockham/terminals/<id>.jsonl``. It mirrors the wire
shape of a chunk so reload-from-JSONL produces an identical UI to the
live stream.
"""

from __future__ import annotations

import json
from datetime import datetime
from typing import Any, Literal
from uuid import uuid4

from parsimony_agents.agent.outputs import SystemToolMessage
from parsimony_agents.messages import ContinueRequest, Message, MessageContent, Reasoning, Text
from pydantic import BaseModel, ConfigDict, Field, model_validator

# ---------------------------------------------------------------------------
# Persisted transcript record
# ---------------------------------------------------------------------------


class MessageMetadata(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid4()))
    timestamp: str = Field(default_factory=lambda: datetime.now().isoformat())


class TerminalMessage(Message):
    """One persisted entry in a terminal session's JSONL transcript.

    The content union is intentionally narrow: only the message kinds that
    end up in the transcript (user prompts, assistant text, reasoning,
    continue requests, system tool calls). Charts, datasets, notebooks, and
    utility tool outputs are persisted as ``file_ref`` records pointing at
    framework-managed files — never as ``TerminalMessage.content``.
    """

    id: str
    role: Literal["user", "assistant", "system", "tool"] = Field(...)
    timestamp: str = Field(default_factory=lambda: datetime.now().isoformat())
    content: Text | Reasoning | ContinueRequest | SystemToolMessage | None = Field(None)
    response_id: str | None = Field(None, alias="responseId")
    analysis_duration_seconds: float | None = Field(default=None, alias="analysisDurationSeconds")

    class Config:
        arbitrary_types_allowed = True
        populate_by_name = True

    @model_validator(mode="before")
    def validate_id(cls, values: dict[str, Any], **kwargs) -> dict[str, Any]:
        if "id" not in values or not values["id"]:
            values["id"] = str(uuid4())
        return values

    def to_frontend_dict(self) -> dict[str, Any]:
        # Avoid double serialization of content by excluding it from model_dump.
        data = self.model_dump(mode="json", by_alias=True, exclude={"content"})
        content = self.content
        if content is None:
            data["content"] = None
        elif isinstance(content, MessageContent):
            data["content"] = content.to_frontend_dict()
        elif isinstance(content, BaseModel):
            data["content"] = content.model_dump(mode="json")
        else:
            data["content"] = content
        data["completed"] = data.get("completed", True)
        return data


# ---------------------------------------------------------------------------
# Stream chunks
# ---------------------------------------------------------------------------


class StreamChunk(BaseModel):
    type: str
    source_agent: str | None = Field(default=None)
    messageId: str = Field(default_factory=lambda: str(uuid4()))
    responseId: str = Field(default_factory=lambda: str(uuid4()))
    sequence: int = 0
    data: Any

    def to_sse_chunk(self) -> str:
        """Serialize to the SSE wire format.

        Invariant: ``data`` payloads must match the canonical frontend
        contract (prefer ``to_frontend_dict()`` when available) so the wire
        payload never leaks large internal representations like raw
        DataFrames or figure objects.
        """
        payload: dict[str, Any] = self.model_dump(mode="json", exclude={"data"})

        data = self.data
        if isinstance(data, MessageContent):
            payload["data"] = data.to_frontend_dict()
        elif isinstance(data, BaseModel):
            payload["data"] = data.model_dump(mode="json")
        elif hasattr(data, "to_frontend_dict") and callable(data.to_frontend_dict):
            payload["data"] = data.to_frontend_dict()
        else:
            payload["data"] = data

        return f"data: {json.dumps(payload)}\n\n"


class TextDeltaChunk(StreamChunk):
    type: Literal["text_delta"] = "text_delta"
    data: str
    delta: bool = False


class ReasoningDeltaChunk(StreamChunk):
    type: Literal["reasoning_delta"] = "reasoning_delta"
    data: str
    title: str | None = None
    delta: bool = False


class ErrorChunk(StreamChunk):
    type: Literal["error"] = "error"
    data: str


class FinalChunk(StreamChunk):
    type: Literal["final"] = "final"
    data: MessageMetadata = MessageMetadata()
    analysis_duration: float = 0.0


class CancellationPayload(BaseModel):
    """Typed payload for terminal turn cancellation (wire + JSONL)."""

    reason: Literal["user_request", "client_disconnect"] = "user_request"
    message: str = "Execution was cancelled."


class CancellationChunk(StreamChunk):
    type: Literal["cancelled"] = "cancelled"
    data: CancellationPayload


class CancelTerminalRunResponse(BaseModel):
    """Response for ``POST .../terminals/{id}/cancel``."""

    model_config = ConfigDict(populate_by_name=True)

    cancelled: bool
    """True if an in-flight run existed and the cancel token was set."""

    response_id: str | None = Field(default=None, alias="responseId")
    """The ``responseId`` of the run that was cancelled, when *cancelled* is True."""


class FileRefChunk(StreamChunk):
    """Pointer to a workspace file the agent just wrote.

    The single chunk type for every file-backed event the wire carries:
    every artifact published via ``return_*`` / ``edit_*`` tools is a
    versioned snapshot under ``.ockham/<kind>s/<logical_id>/<content_sha>.<ext>``;
    utility tool outputs follow the same shape under ``.ockham/outputs/``.
    User-visible paths (e.g. ``notebooks/<live_name>.py``,
    ``data/<live_name>.parquet``) are virtual views resolved from
    curation — never the bytes-write target.

    Discrimination is by ``kind`` (``"dataset"``, ``"chart"``,
    ``"notebook"``, ``"utility_output"``, future kinds). ``kind`` is an
    open ``str`` validated at emission time against the viewer registry
    in :mod:`server.api.workspace.viewers` — not a closed ``Literal[...]``
    — so adding a new file kind is a registry plug-in, never a wire
    schema change.

    The chunk carries only what the renderer cannot derive from the
    file itself:

    * ``kind`` — selects the renderer in the viewer/card registry.
    * ``workspace_file_path`` — what the renderer fetches.
    * ``etag`` — content fingerprint of what was just written. Lets the
      frontend bump its per-file version map on chunk arrival, so any
      open viewer for the same path refetches on the same SSE turn
      (no need to wait for the filesystem watcher to round-trip).
    * ``view_etag`` (notebooks only) — fingerprint of ``.py`` bytes plus
      ``.ockham/notebook-state`` (same as ``GET /view``). When set, the
      client should use this (not just ``etag``) to track the view payload
      so data sources / outputs appear on the same ``file_ref`` turn.
    * ``label`` — optional single-line message for the terminal row, e.g.
      ``Created file://./data/x.parquet > …`` or ``Executed file://./n.py``.
      When absent, the client falls back to ``file://./`` + ``workspace_file_path``.

    The chunk does **not** carry artifact metadata (title, description,
    preview rows, vega-lite spec). That metadata lives in the file,
    embedded by the format-specific writer, fetched via
    ``GET /workspaces/{wid}/view/{path}`` when the renderer needs it.
    """

    type: Literal["file_ref"] = "file_ref"
    kind: str
    workspace_file_path: str
    #: Logical identity of the artifact (§2.2). For dataset/chart/report
    #: this stays stable across data refreshes. For notebooks, it's the
    #: working-copy basename (``notebooks/foo.py`` → ``"foo"``); rename
    #: starts a fresh logical_id, mirroring git's model. ``None`` for
    #: kinds that don't participate in the content-addressed graph
    #: (utility outputs).
    logical_id: str | None = None
    #: Hash of the bytes for this specific snapshot. Set whenever the
    #: pointer comes from a content-addressed write.
    content_sha: str | None = None
    #: Optional human label cached from curation (``title`` for
    #: dataset/chart/report; ``live_name`` for notebook). Used by the
    #: pill renderer to override the path basename.
    name: str | None = None
    #: Workspace-local snapshot index (``v{N}`` in the UI). 1-based
    #: position of this ``content_sha`` in the artifact's
    #: ``log.jsonl``; identical-content republishes return the same
    #: number. NOT part of identity — never copy onto
    #: :class:`parsimony_agents.identity.ArtifactRef`. Every snapshot
    #: kind has a per-logical_id log under the unified versioning
    #: model; ``None`` only for utility outputs.
    version: int | None = None
    etag: str | None = None
    view_etag: str | None = None
    label: str | None = None
    completed: bool = True
    data: None = None


class SystemToolChunk(StreamChunk):
    type: Literal["system_tool"] = "system_tool"
    data: SystemToolMessage
    completed: bool = False


class ContinueRequestChunk(StreamChunk):
    type: Literal["continue_request"] = "continue_request"
    data: str


class NotificationChunk(StreamChunk):
    type: Literal["notification"] = "notification"
    data: str
    dismiss: bool = False
    title: str | None = None


# ---------------------------------------------------------------------------
# Request payloads
# ---------------------------------------------------------------------------


class MessageAttachmentRef(BaseModel):
    """Client-side attachment metadata for a user message (names and sizes only)."""

    file_name: str = Field(..., min_length=1)
    size: int = Field(..., ge=0)


class SendMessageRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=10000)
    files: list[MessageAttachmentRef] | None = None
    selected_model_set: str
