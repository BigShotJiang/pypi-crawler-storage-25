"""Wire-format streaming primitives shared across all SSE endpoints.

The terminal server has exactly one streaming pipeline: the workspace
agent loop. It emits a stream of :class:`StreamChunk` instances over
Server-Sent Events. The chunk taxonomy (text deltas, reasoning,
file refs, etc.) and the :func:`framework_event_to_stream_chunks`
adapter live here, decoupled from any specific HTTP route.
"""

from server.api.streaming.framework_events import (
    PendingFileRef,
    framework_event_to_stream_chunks,
)
from server.api.streaming.models import (
    CancellationChunk,
    CancellationPayload,
    CancelTerminalRunResponse,
    ContinueRequestChunk,
    ErrorChunk,
    FileRefChunk,
    FinalChunk,
    MessageAttachmentRef,
    MessageMetadata,
    NotificationChunk,
    ReasoningDeltaChunk,
    SendMessageRequest,
    StreamChunk,
    SystemToolChunk,
    TerminalMessage,
    TextDeltaChunk,
)

__all__ = [
    "CancelTerminalRunResponse",
    "CancellationChunk",
    "CancellationPayload",
    "ContinueRequestChunk",
    "ErrorChunk",
    "FileRefChunk",
    "FinalChunk",
    "MessageAttachmentRef",
    "MessageMetadata",
    "NotificationChunk",
    "PendingFileRef",
    "ReasoningDeltaChunk",
    "SendMessageRequest",
    "StreamChunk",
    "SystemToolChunk",
    "TerminalMessage",
    "TextDeltaChunk",
    "framework_event_to_stream_chunks",
]
