"""Map ``parsimony_agents`` ``AgentEvent`` stream to API stream events.

The adapter yields two kinds of objects:

* :class:`server.api.streaming.models.StreamChunk` subclasses — pure
  deltas (text, reasoning, errors, system tool messages, continue
  requests). These travel directly to the SSE wire.
* :class:`PendingFileRef` — file-backed events (artifacts, notebooks,
  utility outputs). The streaming dispatcher persists each to a
  workspace file, then emits a single :class:`FileRefChunk` over the
  wire. Carries the typed in-process payload so the dispatcher can
  hand it to the appropriate writer without re-parsing.

The wire contract (``FileRefChunk``) does not appear in this module:
emission of the wire chunk is owned by the dispatcher because the
``etag`` and ``workspace_file_path`` are only known after persistence.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from parsimony_agents.agent.events import (
    AgentError,
    RunCancelled,
    StateSnapshot,
    ToolEvent,
)
from parsimony_agents.agent.events import (
    ReasoningDelta as ReasoningDeltaEvent,
)
from parsimony_agents.agent.events import (
    TextDelta as TextDeltaEvent,
)
from parsimony_agents.agent.outputs import SystemToolMessage, UtilityToolOutput
from parsimony_agents.artifacts import Chart, Dataset, Report
from parsimony_agents.notebook import Script, ScriptPreview

from server.api.streaming.models import (
    CancellationChunk,
    CancellationPayload,
    ContinueRequestChunk,
    ErrorChunk,
    ReasoningDeltaChunk,
    StreamChunk,
    SystemToolChunk,
    TextDeltaChunk,
)


@dataclass(frozen=True)
class PendingFileRef:
    """A framework event that needs persistence before reaching the wire.

    Represents the substrate behind every file-backed UI event: the agent
    produced bytes, the dispatcher will write them to a workspace path,
    the wire will carry only the resulting pointer.

    ``kind`` is the open viewer-registry discriminator. ``payload`` is
    whatever typed object the dispatcher's writer for that kind expects
    (``Dataset``, ``Chart``, ``ScriptPreview``, ``UtilityToolOutput``).

    ``tool_name`` (when set) disambiguates notebook tool verbs in the label.
    ``also_executed`` is true when ``return_notebook`` / ``edit_notebook`` ran the kernel in the same call.
    """

    kind: str
    payload: Any
    response_id: str
    message_id: str
    completed: bool = True
    tool_name: str | None = None
    also_executed: bool = False


def framework_event_to_stream_chunks(
    event: Any,
    *,
    response_id: str,
) -> StreamChunk | PendingFileRef | None:
    """Convert one framework event to a wire chunk or a pending file-ref.

    Returns ``None`` for events the workspace pipeline does not surface
    (full-notebook state snapshots, agent context snapshots) — workspace
    mode rebuilds context from JSONL on every turn, so those events are
    redundant on the wire.
    """

    if isinstance(event, StateSnapshot):
        # Workspace mode rebuilds AgentContext from JSONL on each request;
        # snapshotting it on the wire would only add noise.
        return None

    if isinstance(event, RunCancelled):
        return CancellationChunk(
            data=CancellationPayload(reason=event.reason, message=event.message),
            responseId=response_id,
            messageId=response_id,
        )

    if isinstance(event, TextDeltaEvent):
        return TextDeltaChunk(
            data=event.content,
            responseId=response_id,
            messageId=event.message_id,
            delta=event.delta,
        )

    if isinstance(event, ReasoningDeltaEvent):
        return ReasoningDeltaChunk(
            data=event.content,
            responseId=response_id,
            messageId=event.message_id,
            title=event.title,
            delta=event.delta,
        )

    if isinstance(event, AgentError):
        if event.recoverable and event.error_type in ("time_limit", "iteration_limit"):
            return ContinueRequestChunk(
                data=event.message,
                responseId=response_id,
            )
        return ErrorChunk(
            data=event.message,
            responseId=response_id,
        )

    if isinstance(event, ToolEvent):
        if event.tool_type == "utility":
            uo = event.result
            if not isinstance(uo, UtilityToolOutput):
                raise TypeError(f"utility ToolEvent expected UtilityToolOutput, got {type(uo)}")
            return PendingFileRef(
                kind="utility_output",
                payload=uo,
                response_id=response_id,
                message_id=event.tool_call_id,
                completed=event.completed,
                tool_name=event.tool_name,
            )

        if event.tool_type == "system":
            sm = event.result
            if not isinstance(sm, SystemToolMessage):
                raise TypeError(f"system ToolEvent expected SystemToolMessage, got {type(sm)}")
            return SystemToolChunk(
                data=sm,
                responseId=response_id,
                messageId=event.tool_call_id,
                completed=event.completed,
            )

        if event.tool_type == "code":
            res = event.result
            if isinstance(res, ScriptPreview):
                return PendingFileRef(
                    kind="notebook",
                    payload=res,
                    response_id=response_id,
                    message_id=event.tool_call_id,
                    completed=event.completed,
                    tool_name=event.tool_name,
                    also_executed=event.also_executed,
                )
            if isinstance(res, dict) and "notebook" in res and "preview" in res:
                nb = res["notebook"]
                prev = res["preview"]
                if isinstance(nb, Script) and isinstance(prev, ScriptPreview):
                    # Workspace mode persists only the preview; the full
                    # notebook state snapshot is rebuilt on demand from
                    # the .py file plus the cached fetch log.
                    return PendingFileRef(
                        kind="notebook",
                        payload=prev,
                        response_id=response_id,
                        message_id=event.tool_call_id,
                        completed=event.completed,
                        tool_name=event.tool_name,
                        also_executed=event.also_executed,
                    )
            raise TypeError(f"Unexpected code ToolEvent result: {type(res)}")

        if event.tool_type == "return":
            r = event.result
            if isinstance(r, Dataset):
                kind = "dataset"
            elif isinstance(r, Chart):
                kind = "chart"
            elif isinstance(r, Report):
                kind = "report"
            else:
                raise TypeError(f"Unexpected return ToolEvent result: {type(r)}")
            return PendingFileRef(
                kind=kind,
                payload=r,
                response_id=response_id,
                message_id=event.tool_call_id,
                completed=True,
                tool_name=event.tool_name,
            )

    raise TypeError(f"Unknown framework event type: {type(event)!r}")
