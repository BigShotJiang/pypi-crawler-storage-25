"""In-process cache of sandbox executor ids (ephemeral; reset on process restart)."""

from __future__ import annotations

import asyncio
import logging
from typing import Any

_log = logging.getLogger(__name__)

_lock = asyncio.Lock()
_executor_by_session: dict[str, str] = {}


async def get_cached_executor_id(_cache: Any, session_id: str) -> str | None:
    """``_cache`` is ignored; kept for call-site compatibility with older Redis wiring."""
    async with _lock:
        return _executor_by_session.get(session_id)


async def set_cached_executor_id(_cache: Any, session_id: str, executor_id: str) -> None:
    async with _lock:
        _executor_by_session[session_id] = executor_id
    _log.info(
        "Session ↔ executor mapping stored",
        extra={"event": "executor_cache_set", "session_id": session_id, "executor_id": executor_id},
    )


async def delete_cached_executor_id(_cache: Any, session_id: str) -> None:
    """Remove the cached remote executor id (e.g. after cooperative cancellation)."""
    async with _lock:
        _executor_by_session.pop(session_id, None)
    _log.info(
        "Session executor id removed from cache",
        extra={"event": "executor_cache_delete", "session_id": session_id},
    )
