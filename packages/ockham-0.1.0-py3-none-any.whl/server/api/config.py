"""
Infrastructure settings for the Ockham API.

Environment variables, timeouts, and feature flags. Filesystem paths
(workspaces, sessions, artifacts) live in :mod:`server.storage` —
platformdirs-based, override via ``OCKHAM_DATA_DIR`` and
``OCKHAM_CACHE_DIR``. Secrets are managed separately via
``server.api.utils.secrets.SecretStore``.

LLM model configuration lives in ``server.llm``.
System prompts live in ``server.prompts``.
UI examples live in ``server.examples``.
"""

from __future__ import annotations

from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


def _coerce_secret_value(raw_value: str, current_value: object) -> object:
    """Cast secret values to the field's runtime type."""
    if isinstance(current_value, bool):
        return raw_value.lower() in ("1", "true", "yes")
    if isinstance(current_value, int):
        return int(raw_value)
    if isinstance(current_value, float):
        return float(raw_value)
    if isinstance(current_value, list):
        import json

        return json.loads(raw_value)
    return raw_value


class Config(BaseSettings):
    """Configuration class for Ockham API."""

    @model_validator(mode="after")
    def _load_secrets_from_store(self):
        """Overwrite config values with secrets from secret store."""
        from server.api.utils.secrets import secret_store

        for field_name in self.__class__.model_fields:
            secret_value = secret_store.get_secret(field_name)
            if not secret_value:
                continue
            current = getattr(self, field_name)
            setattr(self, field_name, _coerce_secret_value(secret_value, current))
        return self

    SESSION_TIMEOUT: int = 86400  # 24 hours
    SESSION_NAMESPACE: str = "ockham"
    ADMIN_USER_ID: str | None = None
    MAX_SESSIONS: int = 100
    MAX_FILE_SIZE_MB: int = 10

    CACHE_TIMEOUT: int = 300  # 5 minutes

    # When true, require a valid Supabase-issued JWT on ``Authorization: Bearer`` (``sub`` = user id).
    # When false, every request is treated as :data:`server.api.middleware.LOCAL_USER_ID` (desktop / trusted local).
    AUTH_ENABLED: bool = False

    # Project JWT secret (Supabase dashboard → API → JWT Secret). Used to verify user access tokens when AUTH_ENABLED.
    SUPABASE_JWT_SECRET: str = ""

    # Optional override for the HTTP sandbox executor base URL.
    SANDBOX_URL: str = ""
    # Preferred executor boundary. Defaults to a local/sidecar sandbox service.
    EXECUTOR_URL: str = "http://localhost:8001"

    # Input Validation Configuration
    MAX_MESSAGE_LENGTH: int = 10000

    # API Configuration
    # Override via FASTAPI_ALLOWED_ORIGINS env var (JSON list) for production deployments
    FASTAPI_ALLOWED_ORIGINS: list[str] = [
        "http://localhost:8080",
        "http://localhost:8000",
        "http://localhost:8001",
    ]

    FASTAPI_ALLOWED_METHODS: list[str] = ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"]
    FASTAPI_ALLOWED_HEADERS: list[str] = ["Authorization", "Content-Type", "If-None-Match"]
    FASTAPI_EXPOSE_HEADERS: list[str] = ["X-Total-Count", "ETag", "Content-Disposition"]
    FASTAPI_MAX_AGE: int = 3600

    FRONTEND_DIR: str | None = None

    # Code Executor Configuration
    EXECUTOR_REQUEST_TIMEOUT_S: float = 600.0
    APP_BASE_URL: str = "http://localhost:8000"  # URL the sandbox uses to call back to the main app

    # Cache Sweeper Configuration
    CACHE_SWEEPER_ENABLED: bool = True
    CACHE_SWEEPER_INTERVAL_SECONDS: int = 900
    SESSION_CACHE_MAX_AGE_SECONDS: int = 604800
    SESSION_CACHE_MAX_BYTES: int = 5_000_000_000

    OCKHAM_MAX_DATA_ROWS: int = 1_000_000
    OCKHAM_MAX_DATA_MB: int = 200

    # Per-session RAG vector store embedding dimensionality (parsimony-agents).
    # See ``parsimony_agents.rag.embeddings.configure_embeddings``.
    RAG_EMBEDDING_DIM: int = 768
    RAG_EMBEDDING_MODEL: str = "gemini/gemini-embedding-2-preview"

    # Agent Guardrail Configuration
    OCKHAM_MAX_ITERATIONS: int = 50
    OCKHAM_MAX_EXECUTION_TIME_S: float = 300.0
    OCKHAM_LLM_TIMEOUT_S: float = 60.0
    OCKHAM_LLM_MAX_RETRIES: int = 3
    OCKHAM_TOOL_TIMEOUT_S: float = 600.0

    model_config = SettingsConfigDict(env_prefix="", case_sensitive=False, env_file=".env", extra="allow")


def get_config() -> Config:
    return Config()


# Singleton config instance
config = Config()
