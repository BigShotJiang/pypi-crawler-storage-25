"""HTTP middleware and request-scoped dependencies for the Ockham API.

* ``AUTH_ENABLED=false`` (default desktop): every request is :data:`LOCAL_USER_ID`.
* ``AUTH_ENABLED=true`` (hosted): require ``Authorization: Bearer <Supabase user JWT>``;
  ``get_current_user_id`` returns the JWT ``sub`` claim. Configure
  ``SUPABASE_JWT_SECRET`` to match the Supabase project's JWT secret.

We keep one HTTP-level guard:

* :func:`enforce_domain_middleware` — refuse non-loopback hosts so a
  misconfigured frontend can't address this process from the public internet.

There is no per-request rate limiter: the desktop app is not the API gateway,
and runaway-loop protection belongs in the agent loop rather than the HTTP
layer.
"""

from __future__ import annotations

import json
import os
import re

import jwt
from fastapi import HTTPException, Request
from jwt import PyJWTError
from starlette.responses import PlainTextResponse

from server.api.config import config
from server.api.utils.secrets import secret_store
from server.core.monitoring import get_logger

system_logger = get_logger("SYSTEM")


# Stable UUID: persisted on-disk user_id values from local-first builds.
LOCAL_USER_ID = "00000000-0000-0000-0000-000000000001"


def _supabase_jwt_secret() -> str:
    s = (config.SUPABASE_JWT_SECRET or "").strip()
    if s:
        return s
    return (secret_store.get_secret("SUPABASE_JWT_SECRET") or "").strip()


_DEFAULT_HOST_PATTERNS = [
    r"^localhost(?::\d+)?$",
    r"^127\.0\.0\.1(?::\d+)?$",
    r"^0\.0\.0\.0(?::\d+)?$",
]
_EXTRA_PATTERNS_RAW = os.getenv("ALLOWED_HOST_PATTERNS", "")
ALLOWED_HOST_PATTERNS = (
    _DEFAULT_HOST_PATTERNS + json.loads(_EXTRA_PATTERNS_RAW) if _EXTRA_PATTERNS_RAW else _DEFAULT_HOST_PATTERNS
)
_ALLOWED_HOST_COMPILED_PATTERNS = [re.compile(p) for p in ALLOWED_HOST_PATTERNS]


def get_real_ip(request: Request) -> str:
    """Best-effort client IP for diagnostics."""
    forwarded_for = request.headers.get("X-Forwarded-For", "").strip()
    if forwarded_for:
        first_ip = forwarded_for.split(",")[0].strip()
        if first_ip:
            return first_ip
    if request.client and request.client.host:
        return request.client.host
    return "unknown"


async def get_current_user_id(request: Request) -> str:
    """Resolves user id: local static id, or Supabase ``sub`` when ``AUTH_ENABLED``."""
    if not config.AUTH_ENABLED:
        return LOCAL_USER_ID
    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Not authenticated")
    token = auth[7:].strip()
    secret = _supabase_jwt_secret()
    if not secret:
        system_logger.error("AUTH_ENABLED but SUPABASE_JWT_SECRET is not set")
        raise HTTPException(status_code=500, detail="Auth not configured")
    try:
        payload = jwt.decode(
            token,
            secret,
            algorithms=["HS256"],
            audience="authenticated",
        )
    except PyJWTError:
        raise HTTPException(status_code=401, detail="Invalid token") from None
    sub = payload.get("sub")
    if not sub or not isinstance(sub, str):
        raise HTTPException(status_code=401, detail="Invalid token")
    return sub


async def enforce_domain_middleware(request: Request, call_next):
    """Refuse requests whose ``Host`` header isn't on the loopback allowlist."""
    if request.url.path == "/api/status":
        return await call_next(request)

    host = request.headers.get("host", "")

    if not host or not any(p.fullmatch(host) for p in _ALLOWED_HOST_COMPILED_PATTERNS):
        system_logger.warning("Rejected request with disallowed Host: %r path=%s", host, request.url.path)
        return PlainTextResponse(status_code=403, content="Forbidden")

    return await call_next(request)
