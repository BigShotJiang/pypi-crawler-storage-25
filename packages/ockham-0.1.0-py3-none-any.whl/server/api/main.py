import asyncio
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from parsimony.discover import load_all
from parsimony_agents.rag.embeddings import configure_embeddings
from starlette.responses import FileResponse

from server.api import middleware
from server.api.config import config
from server.api.meta.router import router as meta_router
from server.api.utils.secrets import secret_store
from server.api.workspace.router import router as workspace_router
from server.core.cache import configure_default_dataframe_storage, run_sweeper_forever
from server.core.monitoring import get_logger, setup_tracing

logger = get_logger("SYSTEM")
error_logger = get_logger("ERROR")

# ---------------- FastAPI App ----------------
app = FastAPI()

# ---------------- Domain Enforcement Middleware ----------------
app.middleware("http")(middleware.enforce_domain_middleware)

# ---------------- CORS Middleware ----------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=config.FASTAPI_ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=config.FASTAPI_ALLOWED_METHODS,
    allow_headers=config.FASTAPI_ALLOWED_HEADERS,
    expose_headers=config.FASTAPI_EXPOSE_HEADERS,
    max_age=config.FASTAPI_MAX_AGE,
)


@app.on_event("startup")
async def startup_event():
    """Initialize data sources and tools once on startup."""
    setup_tracing()
    logger.info("OpenTelemetry tracing initialized")

    configure_default_dataframe_storage()
    configure_embeddings(dimension=config.RAG_EMBEDDING_DIM)

    # Connectors: agent runtime exposes a single flat ``connectors`` bundle
    # (see :func:`server.connectors.build_agent_connectors`).
    from server.connectors import build_agent_connectors

    # Derive the secret allowlist from the installed connector plugins so
    # adding a connector to pyproject.toml is the only step needed to wire
    # its env vars. ``bind_env`` only consumes keys declared in each
    # connector's ``env_map``; anything else in ``secret_store`` is ignored.
    installed_connectors = list(load_all())
    required_env_vars = {ev for c in installed_connectors for ev in (c.env_map or {}).values()}
    env = {k: v for k in required_env_vars if (v := secret_store.get_secret(k))}
    app.state.connectors = build_agent_connectors(env=env)

    logger.info(
        "Connector runtime ready: %d installed connectors (incl. enumerators), "
        "%d runtime connectors, %d env vars resolved",
        len(installed_connectors),
        sum(len(b) for b in app.state.connectors.values()),
        len(env),
    )

    if config.CACHE_SWEEPER_ENABLED:
        app.state.cache_sweeper_stop_event = asyncio.Event()
        app.state.cache_sweeper_task = asyncio.create_task(run_sweeper_forever(app.state.cache_sweeper_stop_event))
        logger.info("Cache sweeper started")


@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup app-level state on shutdown."""
    stop_event = getattr(app.state, "cache_sweeper_stop_event", None)
    sweeper_task = getattr(app.state, "cache_sweeper_task", None)
    if stop_event is not None:
        stop_event.set()
    if sweeper_task is not None:
        await sweeper_task

    for attr in ("agent", "secret_store", "connectors"):
        if hasattr(app.state, attr):
            delattr(app.state, attr)

    logger.info("FastAPI shutdown complete")


# ---------------- Health Endpoint ----------------
@app.get("/api/status")
async def get_status():
    return {"status": "healthy"}


# ---------------- Auth Config Endpoint ----------------
@app.get("/api/auth_config")
async def get_auth_config():
    """Return public Supabase Auth config (``auth_enabled`` gate + URL + anon key)."""
    supabase_url = secret_store.get_secret("SUPABASE_URL")
    supabase_anon_key = secret_store.get_secret("SUPABASE_ANON_KEY")

    if not config.AUTH_ENABLED:
        return {
            "auth_enabled": False,
            "supabase_url": supabase_url or "https://placeholder.local",
            "supabase_anon_key": supabase_anon_key or "placeholder-local-dev",
        }

    if not supabase_url or not supabase_anon_key:
        raise HTTPException(status_code=500, detail="Supabase configuration not available")
    return {
        "auth_enabled": True,
        "supabase_url": supabase_url,
        "supabase_anon_key": supabase_anon_key,
    }


# ---------------- Routers ----------------
app.include_router(meta_router)
app.include_router(workspace_router)

# ---------------- Static Files ----------------
if config.FRONTEND_DIR and Path(config.FRONTEND_DIR).is_dir():
    logger.info(f"Frontend directory configured at: {config.FRONTEND_DIR}")
else:
    logger.warning("Static file serving disabled (FRONTEND_DIR not configured or doesn't exist)")


@app.get("/{full_path:path}", include_in_schema=False)
async def spa_fallback(full_path: str):
    """Serve the SPA entrypoint for non-API routes so client-side routing works."""
    if full_path.startswith("api/"):
        raise HTTPException(status_code=404, detail="Not found")

    if not config.FRONTEND_DIR:
        raise HTTPException(status_code=404, detail="Not found")

    frontend_dir = Path(config.FRONTEND_DIR)
    index_file = frontend_dir / "index.html"

    if not index_file.is_file():
        logger.error("SPA fallback requested but index.html missing", extra={"path": full_path})
        raise HTTPException(status_code=404, detail="Not found")

    requested_path = (frontend_dir / full_path).resolve()

    try:
        frontend_dir_resolved = frontend_dir.resolve()
    except FileNotFoundError as exc:
        logger.error("Configured frontend directory does not exist", extra={"directory": config.FRONTEND_DIR})
        raise HTTPException(status_code=404, detail="Not found") from exc

    if requested_path.is_file() and str(requested_path).startswith(str(frontend_dir_resolved)):
        return FileResponse(requested_path)

    return FileResponse(index_file)
