from asyncio import Queue
from contextvars import ContextVar

# Context variable to hold the notification queue
# Queue will hold strings (messages) or None (to signal end/dismiss, though currently we use string for message)
notification_queue_var: ContextVar[Queue | None] = ContextVar("notification_queue", default=None)


def set_notification_queue(queue: Queue):
    """Set the notification queue for the current context."""
    notification_queue_var.set(queue)


async def emit_notification(message: str, dismiss: bool = False):
    """
    Emit a notification message to the current context's queue.
    If dismiss is True, it signals to dismiss the notification.
    """
    queue = notification_queue_var.get()
    if queue:
        await queue.put({"message": message, "dismiss": dismiss})
