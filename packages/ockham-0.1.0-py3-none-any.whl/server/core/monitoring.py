"""
Structured logging configuration for Ockham.

This module provides a centralized logging setup with JSON formatting,
category-specific loggers, and stdout output for container-friendly deployments.

Logs are automatically enriched with OpenTelemetry trace context (trace_id, span_id)
and baggage (user_id, session_id, model, request_id) without manual injection.
"""

import json
import logging
import os
import sys
import traceback
from datetime import datetime
from typing import Any

from opentelemetry import baggage, context, trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor, ConsoleSpanExporter

try:
    from opentelemetry import baggage, trace

    OTEL_AVAILABLE = True
except ImportError:
    OTEL_AVAILABLE = False

# ====================
# LOGGING
# ====================

# Reserved fields that must not be in extra dict to avoid conflicts with LogRecord
RESERVED_FIELDS = {
    "name",
    "msg",
    "args",
    "created",
    "filename",
    "funcName",
    "levelname",
    "levelno",
    "lineno",
    "module",
    "msecs",
    "pathname",
    "process",
    "processName",
    "relativeCreated",
    "thread",
    "threadName",
    "taskName",
    "exc_info",
    "exc_text",
    "stack_info",
    "message",  # Added by LogRecord, causes KeyError if in extra
}


class JSONFormatter(logging.Formatter):
    """
    Custom JSON formatter for structured logging with OpenTelemetry integration.

    Outputs logs in JSON format with:
    - timestamp (ISO 8601)
    - level
    - category
    - message
    - trace_id, span_id (from OpenTelemetry active span)
    - user_id, session_id, model, request_id (from OpenTelemetry baggage)
    - context (nested object for additional data from log extra)
    """

    def format(self, record: logging.LogRecord) -> str:
        log_entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "level": record.levelname,
            "category": record.name,
            "message": record.getMessage(),
        }

        # Inject OpenTelemetry trace context automatically
        if OTEL_AVAILABLE:
            span = trace.get_current_span()
            if span and span.is_recording():
                span_context = span.get_span_context()
                log_entry["trace_id"] = format(span_context.trace_id, "032x")
                log_entry["span_id"] = format(span_context.span_id, "016x")
                parent_span_context = getattr(span, "parent", None)
                if parent_span_context and parent_span_context.span_id:
                    log_entry["parent_span_id"] = format(parent_span_context.span_id, "016x")

            # Inject OpenTelemetry baggage automatically
            for key in ["user_id", "session_id", "model", "request_id"]:
                value = baggage.get_baggage(key)
                if value:
                    log_entry[key] = value

        # Handle extra fields from log calls (goes to nested context object)
        context = {}
        for key, value in record.__dict__.items():
            if key not in RESERVED_FIELDS and key not in log_entry:
                context[key] = value

        # Add context object if it has data
        if context:
            log_entry["context"] = context

        # Add exception info at top level if present
        if record.exc_info:
            log_entry["exception"] = self.formatException(record.exc_info)

        return json.dumps(log_entry)


class LeakageFormatter(logging.Formatter):
    """
    Compact one-line formatter for diagnosing session continuity / leakage
    inside a single backend.

    Format:
        HH:MM:SS.mmm L T:<trace8> S:<sess8> R:<req8> sp:<span6> [category] message  k=v ...

    - L: single-char level (I/W/E/D/C)
    - T: last 8 chars of trace_id (== workspace_id in this app)
    - S: last 8 chars of session_id baggage (per-terminal scoped id)
    - R: last 8 chars of request_id baggage
    - sp: last 6 chars of span_id

    Missing IDs render as ``--------`` so absence is itself a visual signal:
    a log line with no ``S:`` means the emitter ran outside any session
    context, which can be useful to spot leaks (state held in module
    globals, background tasks emitting after a session has closed, etc.).

    Stream this with ``tail -f ignored/ockham_trace.log`` while reproducing
    a workspace flow — flips in ``S:`` between adjacent lines that should
    share state indicate cross-terminal contamination; lines without ``S:``
    indicate emissions from contextless paths.
    """

    _MAX_EXTRA_VALUE_LEN = 60
    _MAX_TOTAL_EXTRAS_LEN = 200

    @staticmethod
    def _tail(value, n: int) -> str:
        if not value:
            return "-" * n
        cleaned = str(value).replace("-", "")
        return cleaned[-n:] if len(cleaned) >= n else cleaned.rjust(n, "-")

    def format(self, record: logging.LogRecord) -> str:
        ts = datetime.utcnow().strftime("%H:%M:%S.%f")[:-3]
        lvl = record.levelname[0]

        trace_short = "-" * 8
        span_short = "-" * 6
        sess_short = "-" * 8
        req_short = "-" * 8

        if OTEL_AVAILABLE:
            span = trace.get_current_span()
            if span:
                ctx = span.get_span_context()
                # ``is_valid`` is set whenever there's a trace_id, even on
                # non-recording spans (e.g. created by
                # ``create_session_context`` before the operation span
                # starts). ``is_recording`` would miss those.
                if ctx.is_valid:
                    trace_short = format(ctx.trace_id, "032x")[-8:]
                    if ctx.span_id:
                        span_short = format(ctx.span_id, "016x")[-6:]

            sess = baggage.get_baggage("session_id")
            req = baggage.get_baggage("request_id")
            if sess:
                sess_short = self._tail(sess, 8)
            if req:
                req_short = self._tail(req, 8)

        category = record.name
        message = record.getMessage()

        extras = []
        total = 0
        for key, value in record.__dict__.items():
            if key in RESERVED_FIELDS:
                continue
            v_str = str(value)
            if len(v_str) > self._MAX_EXTRA_VALUE_LEN:
                v_str = v_str[: self._MAX_EXTRA_VALUE_LEN - 3] + "..."
            pair = f"{key}={v_str}"
            total += len(pair) + 1
            if total > self._MAX_TOTAL_EXTRAS_LEN:
                extras.append("…")
                break
            extras.append(pair)
        extras_str = (" " + " ".join(extras)) if extras else ""

        return (
            f"{ts} {lvl} "
            f"T:{trace_short} S:{sess_short} R:{req_short} sp:{span_short} "
            f"[{category}] {message}{extras_str}"
        )


class SimpleLogFormatter(logging.Formatter):
    """
    Formatter that outputs timestamp, level, category, and message in a single-line format.

    Format: [timestamp] [level] [category] message [context: key1=value1, key2=value2]

    Used for creating a simple, human-readable log file.
    """

    def format(self, record: logging.LogRecord) -> str:
        timestamp = datetime.utcnow().isoformat() + "Z"
        level = record.levelname
        category = record.name
        message = record.getMessage()

        # Format as: [timestamp] [level] [category] message
        log_line = f"[{timestamp}] [{level}] [{category}] {message}"

        # Extract extra fields from log calls (same logic as JSONFormatter context)
        context = {}
        for key, value in record.__dict__.items():
            if key not in RESERVED_FIELDS:
                context[key] = value

        # Add context if present
        if context:
            context_str = ", ".join(f"{k}={v}" for k, v in context.items())
            log_line += f" [context: {context_str}]"

        # Add exception info if present (on separate lines for readability)
        if record.exc_info:
            log_line += "\n" + self.formatException(record.exc_info)

        return log_line


def _log_fatal_json(message: str, error: Exception = None, exc_traceback: Any = None, context: dict = None):
    """
    Log a fatal error directly to stdout in JSON format.

    This bypasses the normal logging system to ensure crashes are always JSON.
    """
    log_entry = {
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "level": "CRITICAL",
        "category": "SYSTEM",
        "message": message,
    }

    if error:
        log_entry["error"] = str(error)
        log_entry["error_type"] = type(error).__name__
        if exc_traceback:
            log_entry["traceback"] = "".join(traceback.format_exception(type(error), error, exc_traceback))
        else:
            log_entry["traceback"] = traceback.format_exc()

    if context:
        log_entry.update(context)

    # Write directly to stdout as JSON
    print(json.dumps(log_entry), file=sys.stdout, flush=True)


def _setup_crash_handlers():
    """
    Set up handlers to catch uncaught exceptions and ensure they're logged as JSON.

    This prevents plaintext errors from being written to stderr during crashes,
    which would break log parsing in production.
    """

    def handle_exception(exc_type, exc_value, exc_traceback):
        """Handle uncaught exceptions with JSON logging."""
        # Allow keyboard interrupts to exit normally
        if exc_type is KeyboardInterrupt:
            sys.__excepthook__(exc_type, exc_value, exc_traceback)
            return

        _log_fatal_json(
            message="Uncaught exception - service crashed",
            error=exc_value,
            exc_traceback=exc_traceback,
            context={
                "exception_type": exc_type.__name__,
            },
        )

        # Exit with error code
        sys.exit(1)

    # Override the default exception handler
    sys.excepthook = handle_exception


def _resolve_log_level() -> int:
    """Resolve the global log level from the ``LOG_LEVEL`` env var (default INFO).

    Extracted so :func:`_setup_logging` and :func:`get_logger` share the same
    parsing — no risk of root and category loggers ending up at different
    levels because one defaulted INFO and the other DEBUG.
    """
    global_log_level = os.getenv("LOG_LEVEL", "INFO").upper()
    log_level_map = {
        "DEBUG": logging.DEBUG,
        "INFO": logging.INFO,
        "WARNING": logging.WARNING,
        "ERROR": logging.ERROR,
        "CRITICAL": logging.CRITICAL,
    }
    return log_level_map.get(global_log_level, logging.INFO)


def _setup_logging():
    """Configure the root logger with stdout + optional file handlers.

    All application and library loggers propagate to root; root owns the
    handlers, so adding a destination here applies uniformly to every
    category (SYSTEM, USER, ERROR, parsimony_agents, …). Previously each
    category attached its own handlers and turned propagation off, which
    duplicated handler state and made adding destinations (like the new
    leakage trace) error-prone.
    """
    log_level = _resolve_log_level()

    root_logger = logging.getLogger()
    root_logger.setLevel(log_level)

    # Remove existing handlers to avoid duplicates on re-init.
    root_logger.handlers.clear()

    # Setup crash handlers to ensure all errors (even crashes) are logged as JSON
    _setup_crash_handlers()

    # Suppress noisy third-party loggers
    SUPPRESSED_CATEGORIES = ["LiteLLM"]
    for category in SUPPRESSED_CATEGORIES:
        suppressed_logger = logging.getLogger(category)
        suppressed_logger.setLevel(logging.WARNING)
        suppressed_logger.propagate = False

    # stdout, JSON — the production destination.
    stdout_handler = logging.StreamHandler(sys.stdout)
    stdout_handler.setLevel(log_level)
    stdout_handler.setFormatter(JSONFormatter())
    root_logger.addHandler(stdout_handler)

    # File handlers, gated on a local ``ignored/`` directory existing.
    # Relative to CWD — uvicorn/honcho launch from ``terminal/`` so this
    # resolves to ``terminal/ignored/`` in dev. The trace log is the new
    # surface: stream it with ``tail -f`` while reproducing a multi-terminal
    # flow to spot cross-session contamination (see :class:`LeakageFormatter`).
    if os.path.exists("ignored"):
        file_handler = logging.FileHandler("ignored/ockham.log")
        file_handler.setLevel(log_level)
        file_handler.setFormatter(JSONFormatter())
        root_logger.addHandler(file_handler)

        simple_file_handler = logging.FileHandler("ignored/ockham_simple.log")
        simple_file_handler.setLevel(log_level)
        simple_file_handler.setFormatter(SimpleLogFormatter())
        root_logger.addHandler(simple_file_handler)

        trace_file_handler = logging.FileHandler("ignored/ockham_trace.log")
        trace_file_handler.setLevel(log_level)
        trace_file_handler.setFormatter(LeakageFormatter())
        root_logger.addHandler(trace_file_handler)

    return root_logger


def get_logger(category: str) -> logging.Logger:
    """
    Get a category-specific logger.

    Handlers live on the root logger (see :func:`_setup_logging`); this
    function just names the category, sets its level, and returns a wrapped
    logger. All emissions propagate up to root and reach every destination
    (stdout + files) uniformly.
    """
    # Setup logging on first call.
    if not logging.getLogger().handlers:
        _setup_logging()

    logger = logging.getLogger(category)

    if category == "ERROR":
        logger.setLevel(logging.ERROR)
    else:
        logger.setLevel(_resolve_log_level())

    # Wrap logger to filter reserved fields from extra dict
    return _SafeLogger(logger)


class _SafeLogger:
    """
    Wrapper around logging.Logger that filters out reserved fields from extra dict.
    """

    def __init__(self, logger: logging.Logger):
        self._logger = logger

    def info(self, msg, *args, extra=None, **kwargs):
        """Log at INFO level, filtering reserved fields from extra."""
        safe_extra = self._filter_extra(extra)
        return self._logger.info(msg, *args, extra=safe_extra, **kwargs)

    def debug(self, msg, *args, extra=None, **kwargs):
        """Log at DEBUG level, filtering reserved fields from extra."""
        safe_extra = self._filter_extra(extra)
        return self._logger.debug(msg, *args, extra=safe_extra, **kwargs)

    def warning(self, msg, *args, extra=None, **kwargs):
        """Log at WARNING level, filtering reserved fields from extra."""
        safe_extra = self._filter_extra(extra)
        return self._logger.warning(msg, *args, extra=safe_extra, **kwargs)

    def error(self, msg, *args, extra=None, exc_info=False, **kwargs):
        """Log at ERROR level, filtering reserved fields from extra."""
        safe_extra = self._filter_extra(extra)
        return self._logger.error(msg, *args, exc_info=exc_info, extra=safe_extra, **kwargs)

    def critical(self, msg, *args, extra=None, **kwargs):
        """Log at CRITICAL level, filtering reserved fields from extra."""
        safe_extra = self._filter_extra(extra)
        return self._logger.critical(msg, *args, extra=safe_extra, **kwargs)

    def _filter_extra(self, extra):
        """Filter out reserved fields from extra dict."""
        if extra is None:
            return None

        return {k: v for k, v in extra.items() if k not in RESERVED_FIELDS}


# ====================
# TRACING
# ====================


def setup_tracing():
    """
    Initialize OpenTelemetry with environment-based configuration.
    """

    # Create tracer provider
    provider = TracerProvider()

    # Add console exporter ONLY in development. In production, only JSON logs go to Quickwit (span exports disabled)
    if os.getenv("ENVIRONMENT", "production") == "development":
        console_exporter = ConsoleSpanExporter()
        provider.add_span_processor(BatchSpanProcessor(console_exporter))

    # Set global tracer provider
    trace.set_tracer_provider(provider)

    # TODO:Add OTLP exporter for production
    # if os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT"):
    #    otlp_exporter = OTLPSpanExporter()
    #     provider.add_span_processor(BatchSpanProcessor(otlp_exporter))

    # TODO:In a future we could enable LiteLLM OpenTelemetry callbacks for LLM observability
    # LiteLLM has built-in OpenTelemetry support via callbacks
    # Documentation: https://docs.litellm.ai/docs/observability/opentelemetry


def get_tracer(name: str):
    """
    Get a tracer for a specific component.
    """
    return trace.get_tracer(name)


def create_session_context(session_id: str) -> context.Context:
    """
    Create OpenTelemetry context using session_id as the trace_id.

    This creates a non-recording span context that provides trace_id continuity
    across all requests and operations within a session. The session_id (UUID)
    is converted to a 128-bit trace_id format required by OpenTelemetry.

    Args:
        session_id: UUID string (e.g., "a1b2c3d4-e5f6-7890-abcd-ef1234567890")

    Returns:
        OpenTelemetry context with session_id as trace_id
    """
    import random
    from uuid import UUID

    from opentelemetry.trace import NonRecordingSpan, SpanContext, TraceFlags

    # Convert UUID string to 128-bit integer for trace_id
    # OpenTelemetry trace_id is a 128-bit (16-byte) integer
    uuid_obj = UUID(session_id)
    trace_id = uuid_obj.int & ((1 << 128) - 1)  # Ensure it's exactly 128 bits

    # Generate a valid 64-bit span_id (cannot be 0)
    span_id = random.getrandbits(64) or 1  # Use 1 if we get 0

    # Create a span context with the session_id as trace_id
    span_context = SpanContext(
        trace_id=trace_id,
        span_id=span_id,
        is_remote=False,
        trace_flags=TraceFlags(0x01),  # Sampled
    )

    # Create non-recording span with this context
    non_recording_span = NonRecordingSpan(span_context)

    # Set it as the current span in a new context
    return trace.set_span_in_context(non_recording_span)


def set_context(ctx: context.Context = None, **kwargs) -> context.Context:
    """
    Set request context in OpenTelemetry baggage.
    Context propagates automatically through all async calls and child spans.

    Args:
        ctx: Optional base context to use. If None, uses current context.
        **kwargs: Key-value pairs to set in baggage

    Returns:
        New context with baggage values set
    """
    if ctx is None:
        ctx = context.get_current()
    for key, value in kwargs.items():
        if value is not None:
            ctx = baggage.set_baggage(key, str(value), context=ctx)
    return ctx


def get_context(key: str) -> str | None:
    """
    Get value from OpenTelemetry baggage.
    """
    return baggage.get_baggage(key)
