from __future__ import annotations

import asyncio
import time
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, TypedDict

import pandas as pd
from parsimony_agents.execution.dataframe_ref import (
    DataframeRef as _LibraryDataframeRef,
)
from parsimony_agents.execution.dataframe_ref import (
    set_default_backend,
    set_default_local_root,
)

from server.api.config import config
from server.core.monitoring import get_logger
from server.storage import sessions_dir

logger = get_logger("SYSTEM")


class Cache(ABC):
    """Abstract base class for temporary storage"""

    @abstractmethod
    async def get(self, key: str) -> Any:
        pass

    @abstractmethod
    async def set(self, key: str, value: Any, ttl: int) -> None:
        pass

    @abstractmethod
    async def delete(self, key: str) -> None:
        pass


class InMemoryCache(Cache):
    """Memory data store for caching. Implements the hash/incr/expire ops used for tier quotas and tests."""

    def __init__(self):
        self._data: dict[str, Any] = {}
        self._expires_at: dict[str, float] = {}
        self._lock = asyncio.Lock()
        self._save_task: asyncio.Task | None = None
        self._closed = False

    def _purge_if_expired_unlocked(self, key: str) -> None:
        expires_at = self._expires_at.get(key)
        if expires_at is None:
            return
        if expires_at > time.time():
            return
        self._data.pop(key, None)
        self._expires_at.pop(key, None)

    async def get(self, key: str) -> Any:
        async with self._lock:
            self._purge_if_expired_unlocked(key)
            return self._data.get(key)

    async def set(self, key: str, value: Any, ttl: int = 0) -> None:
        async with self._lock:
            self._data[key] = value
            if ttl and ttl > 0:
                self._expires_at[key] = time.time() + ttl
            else:
                self._expires_at.pop(key, None)

    async def delete(self, key: str) -> None:
        async with self._lock:
            self._data.pop(key, None)
            self._expires_at.pop(key, None)

    async def incr(self, key: str) -> int:
        """Atomically increment integer value stored at key."""
        async with self._lock:
            self._purge_if_expired_unlocked(key)
            val = self._data.get(key)
            n = int(val) if val is not None else 0
            n += 1
            self._data[key] = str(n)
            return n

    async def expire(self, key: str, ttl_seconds: int) -> None:
        """Set an expiry (in seconds) on a key."""
        async with self._lock:
            self._purge_if_expired_unlocked(key)
            if key not in self._data:
                return
            if ttl_seconds <= 0:
                self._data.pop(key, None)
                self._expires_at.pop(key, None)
                return
            self._expires_at[key] = time.time() + ttl_seconds

    async def hget(self, key: str, field: str) -> str | None:
        """Get a field from a hash."""
        async with self._lock:
            self._purge_if_expired_unlocked(key)
            h = self._data.get(key)
            if not isinstance(h, dict):
                return None
            return h.get(field)

    async def hmget(self, key: str, *fields: str) -> list[str | None]:
        """Get multiple fields from a hash in one round-trip."""
        async with self._lock:
            self._purge_if_expired_unlocked(key)
            h = self._data.get(key)
            if not isinstance(h, dict):
                return [None] * len(fields)
            return [h.get(f) for f in fields]

    async def hset(self, key: str, field: str, value: str) -> None:
        """Set a field in a hash."""
        async with self._lock:
            self._purge_if_expired_unlocked(key)
            h = self._data.get(key)
            if not isinstance(h, dict):
                h = {}
                self._data[key] = h
            h[field] = value

    async def hset_multi_expire(self, key: str, mapping: dict[str, str], ttl_seconds: int) -> None:
        """Set multiple hash fields and expire in one round-trip."""
        async with self._lock:
            self._data[key] = dict(mapping)
            if ttl_seconds > 0:
                self._expires_at[key] = time.time() + ttl_seconds
            else:
                self._expires_at.pop(key, None)

    async def hgetall(self, key: str) -> dict[str, str]:
        """Get all fields from a hash."""
        async with self._lock:
            self._purge_if_expired_unlocked(key)
            h = self._data.get(key)
            if not isinstance(h, dict):
                return {}
            return dict(h)

    async def hdel(self, key: str, *fields: str) -> None:
        """Delete fields from a hash."""
        if not fields:
            return
        async with self._lock:
            self._purge_if_expired_unlocked(key)
            h = self._data.get(key)
            if isinstance(h, dict):
                for f in fields:
                    h.pop(f, None)


_cache_instance: InMemoryCache | None = None


def get_cache() -> InMemoryCache:
    """Single process-local :class:`InMemoryCache` (replaces distributed Redis for single-tenant)."""
    global _cache_instance
    if _cache_instance is None:
        _cache_instance = InMemoryCache()
    return _cache_instance


def configure_default_dataframe_storage() -> None:
    """Wire session dir; ``DataframeRef`` materialization is local file only."""
    set_default_local_root(str(sessions_dir()))
    set_default_backend(None)


class DataframeRef(_LibraryDataframeRef):
    """
    Application `DataframeRef` with `from_pandas(..., persist=)` and `s3_key` compatibility.

    Parquet is always written under :func:`server.storage.sessions_dir`;
    `persist` and `bucket` are retained for call-site compatibility (no
    remote object store).
    """

    @property
    def s3_key(self) -> str | None:
        return self.remote_key

    @classmethod
    def from_pandas(
        cls,
        dataframe: pd.DataFrame | pd.Series,
        ref: str = "anonymous",
        *,
        persist: bool = True,
        bucket: str | None = None,
    ) -> DataframeRef:
        _ = persist, bucket
        inner = _LibraryDataframeRef.from_pandas(
            dataframe,
            ref=ref,
            local_dir=str(sessions_dir()),
            backend=None,
        )
        return cls(
            ref=inner.ref,
            local_path=inner.local_path,
            content_hash=inner.content_hash,
            remote_key=inner.remote_key,
        )


class SweepStats(TypedDict):
    target: str
    scanned_files: int
    scanned_bytes: int
    removed_files: int
    removed_bytes: int


def _iter_cache_files(root: Path) -> list[Path]:
    if not root.exists():
        return []
    return [p for p in root.rglob("*") if p.is_file() and not p.name.startswith(".")]


def _remove_file_and_prune(path: Path) -> bool:
    try:
        path.unlink(missing_ok=True)
    except Exception as exc:
        logger.warning("Failed to remove cache file", extra={"path": str(path), "error": str(exc)})
        return False

    parent = path.parent
    while parent != parent.parent and parent.exists():
        try:
            parent.rmdir()
        except OSError:
            break
        parent = parent.parent
    return True


def _sweep_target(target: str, root: Path, max_age_seconds: int, max_bytes: int) -> SweepStats:
    files = _iter_cache_files(root)
    now = time.time()

    scanned_bytes = 0
    removed_files = 0
    removed_bytes = 0
    remaining: list[tuple[Path, int, float]] = []

    # Pass 1: TTL eviction while scanning.
    for path in files:
        stat = path.stat()
        size = stat.st_size
        mtime = stat.st_mtime
        scanned_bytes += size

        if max_age_seconds > 0 and (now - mtime) > max_age_seconds:
            if _remove_file_and_prune(path):
                removed_files += 1
                removed_bytes += size
            continue
        remaining.append((path, size, mtime))

    # Pass 2: size-cap eviction by oldest mtime first.
    if max_bytes > 0:
        remaining_bytes = sum(size for _, size, _ in remaining)
        overflow = remaining_bytes - max_bytes
        if overflow > 0:
            for path, size, _ in sorted(remaining, key=lambda row: row[2]):
                if overflow <= 0:
                    break
                if _remove_file_and_prune(path):
                    removed_files += 1
                    removed_bytes += size
                    overflow -= size

    return {
        "target": target,
        "scanned_files": len(files),
        "scanned_bytes": scanned_bytes,
        "removed_files": removed_files,
        "removed_bytes": removed_bytes,
    }


def run_sweep_once() -> list[SweepStats]:
    targets = [
        (
            "sessions",
            sessions_dir(),
            config.SESSION_CACHE_MAX_AGE_SECONDS,
            config.SESSION_CACHE_MAX_BYTES,
        ),
    ]

    stats: list[SweepStats] = []
    for name, root, max_age, max_bytes in targets:
        root.mkdir(parents=True, exist_ok=True)
        stat = _sweep_target(name, root, max_age, max_bytes)
        logger.info("Cache sweep complete", extra=stat)
        stats.append(stat)
    return stats


async def run_sweeper_forever(stop_event: asyncio.Event) -> None:
    interval = max(int(config.CACHE_SWEEPER_INTERVAL_SECONDS), 30)
    while not stop_event.is_set():
        await asyncio.to_thread(run_sweep_once)
        try:
            await asyncio.wait_for(stop_event.wait(), timeout=interval)
        except TimeoutError:
            continue
