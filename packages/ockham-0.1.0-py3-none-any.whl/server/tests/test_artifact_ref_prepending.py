"""Tests for the ``read_artifact`` live_name-only round-trip.

The agent reads typed artifacts via ``read_artifact(live_name=, kind=)``.
The host resolves the pair into a canonical snapshot path, reads bytes,
and prepends ``<artifact_ref kind=… live_name=…/>`` to the LLM result so
the seen-set extractor recognises the artifact on the next turn.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from parsimony_agents.agent.seen_refs import extract_seen_live_names

from server.api.workspace.artifact_llm import (
    _self_ref_tag,
    read_artifact_to_llm_result,
)
from server.api.workspace.service import resolve_live_name_to_workspace_file_path


def _seed_dataset(root: Path, *, lid: str, live_name: str, csha: str = "abc123") -> Path:
    """Materialise a dataset curation + log + snapshot under root."""
    entry = root / ".ockham" / "datasets" / lid
    entry.mkdir(parents=True)
    (entry / "curation.json").write_text(json.dumps({"kind": "dataset", "logical_id": lid, "live_name": live_name}))
    (entry / "log.jsonl").write_text(json.dumps({"content_sha": csha}) + "\n")
    snap = entry / f"{csha}.parquet"
    snap.write_bytes(b"\0" * 8)
    return snap


def _seed_notebook(root: Path, *, lid: str, live_name: str, csha: str = "abc123") -> Path:
    """Materialise a notebook curation + log + snapshot under root."""
    entry = root / ".ockham" / "notebooks" / lid
    entry.mkdir(parents=True)
    (entry / "curation.json").write_text(json.dumps({"kind": "notebook", "logical_id": lid, "live_name": live_name}))
    (entry / "log.jsonl").write_text(json.dumps({"content_sha": csha}) + "\n")
    snap = entry / f"{csha}.py"
    snap.write_text("# python\n")
    return snap


# ---------------------------------------------------------------------------
# _self_ref_tag
# ---------------------------------------------------------------------------


def test_self_ref_tag_with_pair() -> None:
    assert _self_ref_tag("us_gdp", "dataset") == '<artifact_ref kind="dataset" live_name="us_gdp"/>'


def test_self_ref_tag_returns_none_when_live_name_missing() -> None:
    assert _self_ref_tag(None, "dataset") is None
    assert _self_ref_tag("", "dataset") is None


def test_self_ref_tag_returns_none_when_kind_missing() -> None:
    assert _self_ref_tag("us_gdp", None) is None
    assert _self_ref_tag("us_gdp", "") is None


# ---------------------------------------------------------------------------
# resolve_live_name_to_workspace_file_path
# ---------------------------------------------------------------------------


def test_resolve_dataset_returns_canonical_snapshot_path(tmp_path: Path) -> None:
    _seed_dataset(tmp_path, lid="ds1", live_name="us_gdp", csha="abc")
    resolved = resolve_live_name_to_workspace_file_path(tmp_path, "dataset", "us_gdp")
    assert resolved == ".ockham/datasets/ds1/abc.parquet"


def test_resolve_notebook_returns_canonical_snapshot_path(tmp_path: Path) -> None:
    _seed_notebook(tmp_path, lid="nb1", live_name="us_gdp", csha="def")
    resolved = resolve_live_name_to_workspace_file_path(tmp_path, "notebook", "us_gdp")
    assert resolved == ".ockham/notebooks/nb1/def.py"


def test_resolve_returns_none_when_no_live_name_match(tmp_path: Path) -> None:
    _seed_dataset(tmp_path, lid="ds1", live_name="other")
    assert resolve_live_name_to_workspace_file_path(tmp_path, "dataset", "us_gdp") is None


def test_resolve_returns_none_when_kind_dir_missing(tmp_path: Path) -> None:
    assert resolve_live_name_to_workspace_file_path(tmp_path, "dataset", "us_gdp") is None


def test_resolve_returns_none_when_snapshot_bytes_missing(tmp_path: Path) -> None:
    """Curation + log exist but the snapshot file is gone."""
    entry = tmp_path / ".ockham" / "datasets" / "ds1"
    entry.mkdir(parents=True)
    (entry / "curation.json").write_text(json.dumps({"kind": "dataset", "logical_id": "ds1", "live_name": "x"}))
    (entry / "log.jsonl").write_text(json.dumps({"content_sha": "ghost"}) + "\n")
    # snapshot intentionally not written
    assert resolve_live_name_to_workspace_file_path(tmp_path, "dataset", "x") is None


def test_resolve_returns_none_for_unknown_kind(tmp_path: Path) -> None:
    assert resolve_live_name_to_workspace_file_path(tmp_path, "data_object", "x") is None


def test_resolve_returns_none_when_log_jsonl_missing(tmp_path: Path) -> None:
    entry = tmp_path / ".ockham" / "datasets" / "ds1"
    entry.mkdir(parents=True)
    (entry / "curation.json").write_text(json.dumps({"kind": "dataset", "logical_id": "ds1", "live_name": "x"}))
    assert resolve_live_name_to_workspace_file_path(tmp_path, "dataset", "x") is None


def test_resolve_returns_none_when_log_jsonl_empty(tmp_path: Path) -> None:
    entry = tmp_path / ".ockham" / "datasets" / "ds1"
    entry.mkdir(parents=True)
    (entry / "curation.json").write_text(json.dumps({"kind": "dataset", "logical_id": "ds1", "live_name": "x"}))
    (entry / "log.jsonl").write_text("")
    assert resolve_live_name_to_workspace_file_path(tmp_path, "dataset", "x") is None


# ---------------------------------------------------------------------------
# read_artifact_to_llm_result prepend behaviour
# ---------------------------------------------------------------------------


def test_read_result_prepends_tag_when_live_name_and_kind_given(tmp_path: Path) -> None:
    raw = b"# python script\n"
    result = read_artifact_to_llm_result(
        ".ockham/notebooks/nb1/abc.py",
        raw,
        options={"view": "summary"},
        live_name="us_gdp",
        artifact_kind="notebook",
    )
    assert result.text.startswith('<artifact_ref kind="notebook" live_name="us_gdp"/>')


def test_read_result_omits_tag_when_pair_missing(tmp_path: Path) -> None:
    """Raw user-dropped files have no live_name — and no tag."""
    raw = b"col_a,col_b\n1,2\n"
    result = read_artifact_to_llm_result(
        "data/raw.csv",
        raw,
        options={"view": "summary"},
    )
    assert "<artifact_ref" not in result.text


def test_seen_set_grows_from_read_artifact_result(tmp_path: Path) -> None:
    """Round-trip: extractor must find the prepend tag in the result text."""
    result = read_artifact_to_llm_result(
        ".ockham/notebooks/nb1/abc.py",
        b"# python\n",
        options={"view": "summary"},
        live_name="us_gdp",
        artifact_kind="notebook",
    )
    seen = extract_seen_live_names([{"content": result.text}])
    assert ("notebook", "us_gdp") in seen


# ---------------------------------------------------------------------------
# Full collision-recovery round-trip
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_read_then_resolver_round_trip(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """T2 reads T1's curation via live_name; the next resolve no longer raises."""
    from parsimony_agents.identity import LiveNameCollisionError

    from server.api.workspace.notebook_identity import resolve_notebook_logical_id
    from server.api.workspace.storage import workspace_local_tree_path

    monkeypatch.setenv("OCKHAM_DATA_DIR", str(tmp_path))
    root = workspace_local_tree_path("u", "ws")
    root.mkdir(parents=True, exist_ok=True)
    _seed_notebook(root, lid="us_gdp", live_name="us_gdp", csha="abc")

    # Empty seen-set ⇒ raise. The recovery message must name the
    # ``live_name`` argument the agent actually types.
    with pytest.raises(LiveNameCollisionError) as info:
        await resolve_notebook_logical_id("u", "ws", "notebooks/us_gdp.py", seen_live_names=set())
    assert info.value.live_name == "us_gdp"
    assert info.value.kind == "notebook"
    assert "read_artifact(live_name='us_gdp', kind='notebook')" in str(info.value)

    # Read via the new live_name path ⇒ prepended tag.
    canonical_path = resolve_live_name_to_workspace_file_path(root, "notebook", "us_gdp")
    assert canonical_path is not None
    raw = (root / canonical_path).read_bytes()
    result = read_artifact_to_llm_result(
        canonical_path,
        raw,
        options={"view": "summary"},
        live_name="us_gdp",
        artifact_kind="notebook",
    )
    seen = extract_seen_live_names([{"content": result.text}])

    # Next resolver call with the grown seen-set returns the lid.
    lid = await resolve_notebook_logical_id("u", "ws", "notebooks/us_gdp.py", seen_live_names=seen)
    assert lid == "us_gdp"
