"""Integration tests for workspace file API (local FileStorage)."""

from __future__ import annotations

import os
import tempfile
from pathlib import Path

import pandas as pd
import pytest
from fastapi.testclient import TestClient
from parsimony.result import Column, ColumnRole, OutputConfig, Provenance, Result

from server.api.config import config
from server.api.main import app
from server.api.middleware import LOCAL_USER_ID
from server.api.workspace import service
from server.api.workspace.viewers import file_ref


def _headers() -> dict[str, str]:
    return {"Host": "localhost:8000"}


@pytest.fixture
def client(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> TestClient:
    monkeypatch.setattr(config, "AUTH_ENABLED", False)
    ws_root = tmp_path / "workspaces"
    ws_root.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("OCKHAM_DATA_DIR", str(tmp_path))
    return TestClient(app)


def test_put_get_delete_workspace_file(client: TestClient) -> None:
    h = _headers()
    r = client.post("/api/workspaces", json={"title": "Test"}, headers=h)
    assert r.status_code == 200
    wid = r.json()["id"]

    r = client.put(
        f"/api/workspaces/{wid}/files/sub/hi.txt",
        content=b"hello",
        headers={**h, "Content-Type": "application/octet-stream"},
    )
    assert r.status_code == 204

    r = client.get(f"/api/workspaces/{wid}/files/sub/hi.txt", headers=h)
    assert r.status_code == 200
    assert r.content == b"hello"

    r = client.delete(f"/api/workspaces/{wid}/files/sub/hi.txt", headers=h)
    assert r.status_code == 204

    r = client.get(f"/api/workspaces/{wid}/files/sub/hi.txt", headers=h)
    assert r.status_code == 404


def test_workspace_folder_create_rename_delete(client: TestClient) -> None:
    h = _headers()
    r = client.post("/api/workspaces", json={"title": "Folders"}, headers=h)
    assert r.status_code == 200
    wid = r.json()["id"]

    r = client.post(f"/api/workspaces/{wid}/folders", json={"path": "models"}, headers=h)
    assert r.status_code == 204

    r = client.get(f"/api/workspaces/{wid}/files", headers=h)
    assert r.status_code == 200
    assert {"path": "models", "size_bytes": 0, "kind": "directory"} in r.json()

    r = client.post(
        f"/api/workspaces/{wid}/folders:move",
        json={"source_path": "models", "destination_path": "research/models"},
        headers=h,
    )
    assert r.status_code == 204

    r = client.get(f"/api/workspaces/{wid}/files", headers=h)
    paths = {(entry["path"], entry["kind"]) for entry in r.json()}
    assert ("research", "directory") in paths
    assert ("research/models", "directory") in paths

    r = client.delete(f"/api/workspaces/{wid}/folders/research/models", headers=h)
    assert r.status_code == 204

    r = client.get(f"/api/workspaces/{wid}/files", headers=h)
    paths = {(entry["path"], entry["kind"]) for entry in r.json()}
    assert ("research/models", "directory") not in paths


def test_parquet_json_view(client: TestClient) -> None:
    df = pd.DataFrame({"x": [1.0, 2.0, 3.0]})
    schema = OutputConfig(columns=[Column(name="x", role=ColumnRole.DATA)])
    sem = Result(data=df, provenance=Provenance(source="unit_test", source_description="unit_test")).to_table(schema)
    fd, tmpp = tempfile.mkstemp(suffix=".parquet")
    os.close(fd)
    try:
        sem.to_parquet(tmpp)
        blob = Path(tmpp).read_bytes()
    finally:
        Path(tmpp).unlink(missing_ok=True)

    h = _headers()
    r = client.post("/api/workspaces", json={"title": "P"}, headers=h)
    wid = r.json()["id"]
    r = client.put(
        f"/api/workspaces/{wid}/files/data/x.parquet",
        content=blob,
        headers={**h, "Content-Type": "application/octet-stream"},
    )
    assert r.status_code == 204

    r = client.get(
        f"/api/workspaces/{wid}/files/data/x.parquet?format=json&offset=0&limit=2",
        headers=h,
    )
    assert r.status_code == 200
    body = r.json()
    assert body["total_rows"] == 3
    assert body["offset"] == 0
    assert body["limit"] == 2
    assert len(body["data"]) == 2
    assert body["provenance"]["source"] == "unit_test"


def test_parquet_json_view_schemaless(client: TestClient) -> None:
    """A schemaless ``Result.to_parquet`` (no ``output_schema``) must render as JSON.

    Regression: ``_persist_dataset`` writes ``Result.from_dataframe(df, ...)`` —
    no schema — and the JSON view used to crash on ``OutputConfig`` validation
    with ``columns: []``. Columns are now derived from the Arrow schema.
    """
    df = pd.DataFrame({"date": ["2020-01-01", "2020-02-01"], "value": [1.5, 2.5]})
    res = Result(data=df, provenance=Provenance(source="workspace-x", source_description="workspace-x"))
    fd, tmpp = tempfile.mkstemp(suffix=".parquet")
    os.close(fd)
    try:
        res.to_parquet(tmpp)
        blob = Path(tmpp).read_bytes()
    finally:
        Path(tmpp).unlink(missing_ok=True)

    h = _headers()
    r = client.post("/api/workspaces", json={"title": "S"}, headers=h)
    wid = r.json()["id"]
    r = client.put(
        f"/api/workspaces/{wid}/files/data/x.parquet",
        content=blob,
        headers={**h, "Content-Type": "application/octet-stream"},
    )
    assert r.status_code == 204

    r = client.get(
        f"/api/workspaces/{wid}/files/data/x.parquet?format=json&offset=0&limit=10",
        headers=h,
    )
    assert r.status_code == 200
    body = r.json()
    assert body["total_rows"] == 2
    names = [c["name"] for c in body["columns"]]
    assert names == ["date", "value"]
    assert all(c["role"] == "data" for c in body["columns"])
    assert body["provenance"]["source"] == "workspace-x"


async def test_hidden_parquet_export_round_trips_csv_and_xlsx(client: TestClient) -> None:
    df = pd.DataFrame({"date": ["2020-01-01", "2020-02-01"], "value": [1.5, 2.5]})
    res = Result(data=df, provenance=Provenance(source="workspace-x", source_description="workspace-x"))
    fd, tmpp = tempfile.mkstemp(suffix=".parquet")
    os.close(fd)
    try:
        res.to_parquet(tmpp)
        blob = Path(tmpp).read_bytes()
    finally:
        Path(tmpp).unlink(missing_ok=True)

    h = _headers()
    r = client.post("/api/workspaces", json={"title": "Exports"}, headers=h)
    wid = r.json()["id"]
    rel = ".ockham/cards/ds-1/v1/demo.parquet"
    etag = await service.write_workspace_file_bytes(
        LOCAL_USER_ID,
        wid,
        rel,
        blob,
        allow_ockham=True,
    )
    assert etag

    r = client.get(f"/api/workspaces/{wid}/exports/{rel}?format=csv", headers=h)
    assert r.status_code == 200
    assert r.headers["content-disposition"] == 'attachment; filename="demo.csv"'
    assert r.text == "date,value\n2020-01-01,1.5\n2020-02-01,2.5\n"

    r = client.get(f"/api/workspaces/{wid}/exports/{rel}?format=xlsx", headers=h)
    assert r.status_code == 200
    assert r.headers["content-disposition"] == 'attachment; filename="demo.xlsx"'
    assert r.content.startswith(b"PK")


def test_reserved_ockham_path_rejected(client: TestClient) -> None:
    h = _headers()
    r = client.post("/api/workspaces", json={"title": "R"}, headers=h)
    wid = r.json()["id"]
    r = client.put(
        f"/api/workspaces/{wid}/files/.ockham/nope.json",
        content=b"{}",
        headers={**h, "Content-Type": "application/octet-stream"},
    )
    assert r.status_code == 400


async def test_file_refs_render_visible_workspace_path_with_space(client: TestClient) -> None:
    h = _headers()
    r = client.post("/api/workspaces", json={"title": "S"}, headers=h)
    wid = r.json()["id"]

    rel = "data/spaced name.txt"
    await service.write_workspace_file_bytes(LOCAL_USER_ID, wid, rel, b"hello space")

    rendered = await service.render_referenced_files_for_llm(LOCAL_USER_ID, wid, f"Open {file_ref(rel)} please")
    assert "<referenced_files>" in rendered
    assert f'<file path="{rel}">' in rendered
    assert "hello space" in rendered


async def test_file_refs_render_visible_workspace_file_context(client: TestClient) -> None:
    h = _headers()
    r = client.post("/api/workspaces", json={"title": "Refs"}, headers=h)
    wid = r.json()["id"]

    await service.write_workspace_file_bytes(LOCAL_USER_ID, wid, "notes/thesis.txt", b"watch inflation")

    rendered = await service.render_referenced_files_for_llm(
        LOCAL_USER_ID,
        wid,
        "Use file://./notes/thesis.txt",
    )

    assert "<referenced_files>" in rendered
    assert '<file path="notes/thesis.txt">' in rendered
    assert "watch inflation" in rendered


async def test_file_refs_reject_private_workspace_files(client: TestClient) -> None:
    h = _headers()
    r = client.post("/api/workspaces", json={"title": "Private"}, headers=h)
    wid = r.json()["id"]

    await service.write_workspace_file_bytes(LOCAL_USER_ID, wid, ".ockham/private.txt", b"secret", allow_ockham=True)

    with pytest.raises(ValueError):
        await service.render_referenced_files_for_llm(
            LOCAL_USER_ID,
            wid,
            "Use file://./.ockham/private.txt",
        )


def test_patch_artifact_curation_rejects_unknown_fields(client: TestClient) -> None:
    """R2: ``variable_name`` is a recipe field — PATCH must reject it (422).

    ``CurationPatchBody`` uses ``extra="forbid"`` so any field outside
    the allowlist (title / description / tags / notes / live_name)
    fails validation. This guards artifact identity: editing the
    variable name would invalidate the dataset/chart's ``logical_id``.
    """
    h = _headers()
    r = client.post("/api/workspaces", json={"title": "vn-test"}, headers=h)
    wid = r.json()["id"]
    # The endpoint validates the body before checking the artifact
    # exists, so we don't need to set up a real curation sidecar.
    r = client.patch(
        f"/api/workspaces/{wid}/artifacts/dataset/some-lid/curation",
        json={"variable_name": "df"},
        headers=h,
    )
    assert r.status_code == 422
    assert "variable_name" in r.text


def test_patch_and_delete_workspace(client: TestClient) -> None:
    h = _headers()
    r = client.post("/api/workspaces", json={"title": "Old"}, headers=h)
    wid = r.json()["id"]

    r = client.patch(f"/api/workspaces/{wid}", json={"title": "New"}, headers=h)
    assert r.status_code == 200
    assert r.json()["title"] == "New"

    r = client.delete(f"/api/workspaces/{wid}", headers=h)
    assert r.status_code == 204

    r = client.get(f"/api/workspaces/{wid}", headers=h)
    assert r.status_code == 404


def test_view_for_parquet_with_result_provenance_renders_as_data_object(
    client: TestClient,
) -> None:
    """Vanilla parquet that carries ``Result.provenance`` (the
    ``parsimony.result`` schema metadata, written by ``Result.to_parquet``
    or by the connector data_object persister) renders as ``kind="data_object"``.

    The connector identity *is* the artifact's identity for these files
    — a data_object is the leaf of the lineage graph — so the wire
    surfaces ``provenance`` as the metadata block (no ``sources``
    section, no curation envelope). The dataset/curation viewer is
    reserved for parquet that came through ``return_dataset``.
    """
    df = pd.DataFrame({"date": ["2020-01-01"], "value": [1.5]})
    result = Result(
        data=df,
        provenance=Provenance(
            source="fred",
            source_description="Federal Reserve Economic Data",
            params={"series_id": "UNRATE"},
            properties={"provider": "fred"},
        ),
    )
    fd, tmpp = tempfile.mkstemp(suffix=".parquet")
    os.close(fd)
    try:
        result.to_parquet(tmpp)
        blob = Path(tmpp).read_bytes()
    finally:
        Path(tmpp).unlink(missing_ok=True)

    h = _headers()
    r = client.post("/api/workspaces", json={"title": "V"}, headers=h)
    wid = r.json()["id"]
    r = client.put(
        f"/api/workspaces/{wid}/files/data/x.parquet",
        content=blob,
        headers={**h, "Content-Type": "application/octet-stream"},
    )
    assert r.status_code == 204

    r = client.get(f"/api/workspaces/{wid}/view/data/x.parquet", headers=h)
    assert r.status_code == 200
    body = r.json()
    assert body["kind"] == "data_object"
    prov = body["provenance"]
    assert prov["source"] == "fred"
    assert prov["params"] == {"series_id": "UNRATE"}
    # data_object is the leaf — there is no ``sources`` section in the
    # wire shape (only curated datasets carry that field).
    assert "sources" not in body
    assert "artifact" not in body
