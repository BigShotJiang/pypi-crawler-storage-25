"""Transcript ``file_ref`` rows carry ``etag`` for JSONL replay parity with live SSE."""

from __future__ import annotations

from server.api.streaming.models import FileRefChunk
from server.api.workspace.streaming import _file_ref_record


def test_file_ref_transcript_record_includes_etag() -> None:
    chunk = FileRefChunk(
        kind="dataset",
        workspace_file_path="data/demo.parquet",
        etag="b2-deadbeef",
        label="Demo",
        messageId="msg-1",
        responseId="resp-1",
    )
    rec = _file_ref_record(chunk)
    assert rec["etag"] == "b2-deadbeef"
    content = rec["content"]
    assert isinstance(content, dict)
    assert content.get("etag") == "b2-deadbeef"
    assert content.get("workspace_file_path") == "data/demo.parquet"
    assert "view_etag" not in rec
    assert "view_etag" not in content


def test_file_ref_transcript_record_includes_notebook_view_etag() -> None:
    chunk = FileRefChunk(
        kind="notebook",
        workspace_file_path="notebooks/demo.py",
        etag="b2-script",
        view_etag="b2-view",
        label="Demo",
        messageId="msg-1",
        responseId="resp-1",
    )
    rec = _file_ref_record(chunk)
    assert rec["view_etag"] == "b2-view"
    content = rec["content"]
    assert isinstance(content, dict)
    assert content.get("view_etag") == "b2-view"
