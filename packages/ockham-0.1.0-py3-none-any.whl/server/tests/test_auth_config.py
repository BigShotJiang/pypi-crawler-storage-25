import pytest

from server.api.config import config
from server.api.main import get_auth_config
from server.api.utils.secrets import secret_store


@pytest.mark.asyncio
async def test_auth_config_local_payload(monkeypatch):
    monkeypatch.setattr(config, "AUTH_ENABLED", False)
    monkeypatch.setattr(secret_store, "get_secret", lambda _name: None)

    payload = await get_auth_config()
    assert payload["auth_enabled"] is False
    assert "supabase_url" in payload


@pytest.mark.asyncio
async def test_auth_config_hosted_payload(monkeypatch):
    monkeypatch.setattr(config, "AUTH_ENABLED", True)
    monkeypatch.setattr(secret_store, "get_secret", lambda _name: "value")

    payload = await get_auth_config()
    assert payload["auth_enabled"] is True
    assert payload["supabase_url"] == "value"
    assert payload["supabase_anon_key"] == "value"
