"""Workspace code tools: file writes do not execute the kernel."""

from __future__ import annotations

import pytest
from parsimony_agents.agent.agent import Agent
from parsimony_agents.agent.models import AgentContext
from parsimony_agents.notebook import Script
from parsimony_agents.notebook_io import serialize_notebook

from server.execution import KernelOutput


class _CodeSetExecutor:
    def __init__(self) -> None:
        self.writes: list[tuple[str, bytes]] = []
        self.executed: list[str] = []

    async def get(self, key: str) -> object:  # noqa: ARG002
        return None

    async def clear_namespace(self) -> None:
        return None

    async def set_cwd(self, path: str, session_id: str | None = None) -> None:  # noqa: ARG002
        return None

    async def set_connectors(self, _c) -> None:  # noqa: ANN001
        return None

    async def execute(  # noqa: ARG002
        self, code: str, dry_run: bool = False, timeout_seconds: float | None = None
    ) -> KernelOutput:
        self.executed.append(code)
        return KernelOutput(outputs=[])

    async def eval(  # noqa: ARG002
        self, expr: str, dry_run: bool = False, timeout_seconds: float | None = None
    ) -> KernelOutput:
        return KernelOutput(outputs=[])

    async def read_workspace_file(self, path: str) -> bytes:
        for p, data in self.writes:
            if p == path:
                return data
        raise FileNotFoundError(path)

    async def write_workspace_file(self, path: str, data: bytes) -> None:
        self.writes = [(p, d) for p, d in self.writes if p != path]
        self.writes.append((path, data))

    async def delete_workspace_file(self, path: str) -> None:  # noqa: ARG002
        return None

    async def list_workspace_files(self, prefix: str = "") -> list[tuple[str, int]]:  # noqa: ARG002
        return []

    async def execute_workspace(  # noqa: ARG002
        self, code: str, dry_run: bool = False, timeout_seconds: float | None = None
    ) -> KernelOutput:
        return KernelOutput(outputs=[])

    def get_locals(self) -> dict[str, object]:
        return {}


@pytest.mark.asyncio
async def test_return_notebook_writes_file_without_executing() -> None:
    """``return_notebook`` returns the notebook ref without running the kernel.

    Canonical persistence happens in the streaming layer's
    ``_persist_notebook`` (out of this test's scope) — the agent itself
    never writes a transient working copy via the executor.
    """
    agent = Agent(
        model_config={"model": "test-model"},
        instructions="test instructions",
        session_id="session-1",
    )
    ex = _CodeSetExecutor()
    agent.code_executor = ex
    context = AgentContext(session_id="session-1")
    tr = await agent.return_notebook(
        context=context,
        path="notebooks/pipeline.py",
        code="# step\nx = 1",
    )
    assert tr.success
    assert not ex.executed, "return_notebook must not run CodeExecutor.execute"
    assert ex.writes == [], "return_notebook must not write a transient working copy"
    # Under the no-refs model, the tool message is a plain confirmation
    # — no <notebook_ref/> tag.
    assert "<notebook_ref" not in tr.data  # type: ignore[arg-type]


@pytest.mark.asyncio
async def test_edit_notebook_does_not_execute() -> None:
    """``edit_notebook`` reads the latest snapshot, applies the edit, no kernel run."""
    from parsimony_agents.identity import notebook_content_sha

    agent = Agent(
        model_config={"model": "test-model"},
        instructions="test instructions",
        session_id="session-1",
    )
    ex = _CodeSetExecutor()
    # Seed the executor's FS with a content-addressed notebook snapshot
    # so the snapshot-store read path can resolve the latest revision.
    base_code = "a = 1\n"
    csha = notebook_content_sha(base_code)
    snap_bytes = serialize_notebook(Script(path="notebooks/n.py", code=base_code))
    ex.writes.append((f".ockham/notebooks/n/{csha}.py", snap_bytes))
    ex.writes.append(
        (
            ".ockham/notebooks/n/log.jsonl",
            (f'{{"ts": "t1", "content_sha": "{csha}"}}\n').encode(),
        )
    )
    agent.code_executor = ex
    context = AgentContext(session_id="session-1")
    tr = await agent.edit_notebook(
        context=context,
        path="notebooks/n.py",
        old_str="a = 1",
        new_str="a = 2",
    )
    assert tr.success
    assert not ex.executed
    # Under the no-refs model, the tool message is a plain confirmation
    # — no <notebook_ref/> tag.
    assert "<notebook_ref" not in tr.data  # type: ignore[arg-type]
