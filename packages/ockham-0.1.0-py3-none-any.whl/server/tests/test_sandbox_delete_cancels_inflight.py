"""Sandbox: tracked request tasks are cancelled when an executor is removed."""

from __future__ import annotations

import asyncio
import importlib.util
import os
import sys
from pathlib import Path

import pytest

_SANDBOX_ROOT = Path(__file__).resolve().parents[2] / "sandbox"
if str(_SANDBOX_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_SANDBOX_ROOT.parent))
_EXEC_PATH = _SANDBOX_ROOT / "executor.py"
_spec = importlib.util.spec_from_file_location("sandbox_executor_test_mod", _EXEC_PATH)
assert _spec and _spec.loader
_mod = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_mod)


@pytest.mark.asyncio
async def test_remove_executor_async_cancels_tracked_inflight_work() -> None:
    """``_remove_executor_async`` cancels tasks registered with ``_track_active_work``."""
    eid = "unit-test-executor"
    out = _mod._get_output_factory()
    sandbox_cwd = os.environ.get("SANDBOX_FILES_DIR", "/tmp/sandbox_sessions")
    _mod.executors[eid] = _mod.CodeExecutor(
        cwd=sandbox_cwd,
        output_factory=out,
    )
    _mod._touch(eid)
    mark: list[str] = []

    async def slow() -> None:
        async with _mod._track_active_work(eid):
            mark.append("in")
            await asyncio.sleep(120.0)
            mark.append("done")

    t = asyncio.create_task(slow())
    for _ in range(50):
        if eid in _mod.active_executor_tasks:
            break
        await asyncio.sleep(0.01)
    else:
        pytest.fail("expected handler to be tracked")

    await _mod._remove_executor_async(eid)

    with pytest.raises(asyncio.CancelledError):
        await t
    assert mark == ["in"], "sleep should be cancelled before completion"
