"""Tests for ``POST /api/workspaces/{id}/files:materialize-ref``."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from server.api.config import config
from server.api.main import app
from server.api.middleware import LOCAL_USER_ID
from server.api.workspace import service
from server.api.workspace.etag import compute_etag
from server.api.workspace.viewers import file_ref


def _headers() -> dict[str, str]:
    return {"Host": "localhost:8000"}


@pytest.fixture
def client(tmp_path, monkeypatch: pytest.MonkeyPatch) -> TestClient:
    monkeypatch.setattr(config, "AUTH_ENABLED", False)
    ws_root = tmp_path / "workspaces"
    ws_root.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("OCKHAM_DATA_DIR", str(tmp_path))
    return TestClient(app)


async def _seed_dataset_curation(wid: str, lid: str, live_name: str) -> None:
    """Helper: write a curation sidecar so the materialize naming logic kicks in."""
    cur = (
        '{"kind":"dataset","logical_id":"'
        + lid
        + '","live_name":"'
        + live_name
        + '","title":"'
        + live_name
        + '","description":"","tags":[],"notes":[],'
        '"created_at":"2026-01-01T00:00:00Z","updated_at":"2026-01-01T00:00:00Z"}'
    )
    await service.write_workspace_file_bytes(
        LOCAL_USER_ID,
        wid,
        f".ockham/datasets/{lid}/curation.json",
        cur.encode(),
        allow_ockham=True,
    )


async def test_materialize_ockham_cards_to_visible_folder(client: TestClient) -> None:
    h = _headers()
    r = client.post("/api/workspaces", json={"title": "M"}, headers=h)
    assert r.status_code == 200
    wid = r.json()["id"]
    rel = ".ockham/datasets/ds-1-lid/ds-1-cshaABCDEF12.parquet"
    blob = b"parquet-bytes"
    await service.write_workspace_file_bytes(LOCAL_USER_ID, wid, rel, blob, allow_ockham=True)
    await _seed_dataset_curation(wid, "ds-1-lid", "demo")

    r = client.post(
        f"/api/workspaces/{wid}/files:materialize-ref",
        json={
            "source": file_ref(rel),
            "destination_folder": "data",
            "destination_path": None,
            "source_etag": None,
        },
        headers=h,
    )
    assert r.status_code == 200
    body = r.json()
    # Default basename: <live_name>-<short_csha>.<ext>; short_csha = first 8 hex chars.
    assert body["path"] == "data/demo-ds-1-csh.parquet"
    assert body["etag"] == compute_etag(blob)

    r = client.get(f"/api/workspaces/{wid}/files/data/demo-ds-1-csh.parquet", headers=h)
    assert r.status_code == 200
    assert r.content == blob


async def test_materialize_collision_suffix(client: TestClient) -> None:
    h = _headers()
    r = client.post("/api/workspaces", json={"title": "C"}, headers=h)
    wid = r.json()["id"]
    rel = ".ockham/datasets/ds-1-lid/ds-1-cshaABCDEF12.parquet"
    blob = b"x"
    await service.write_workspace_file_bytes(LOCAL_USER_ID, wid, rel, blob, allow_ockham=True)
    await _seed_dataset_curation(wid, "ds-1-lid", "demo")
    # Pre-populate the suggested name to force collision-suffix behavior.
    await service.write_workspace_file_bytes(LOCAL_USER_ID, wid, "data/demo-ds-1-csh.parquet", b"old")

    r = client.post(
        f"/api/workspaces/{wid}/files:materialize-ref",
        json={
            "source": rel,
            "destination_folder": "data",
            "destination_path": None,
            "source_etag": None,
        },
        headers=h,
    )
    assert r.status_code == 200
    # When the suggested name collides, materialize falls back to
    # `_resolve_visible_copy_destination` against the SOURCE basename
    # (not the suggested name) — that source basename is the unique
    # csha-extended one, which doesn't collide with anything.
    assert r.json()["path"] == "data/ds-1-cshaABCDEF12.parquet"


async def test_materialize_rejects_ockham_destination(client: TestClient) -> None:
    h = _headers()
    r = client.post("/api/workspaces", json={"title": "D"}, headers=h)
    wid = r.json()["id"]
    rel = ".ockham/datasets/ds-1-lid/ds-1-csha.parquet"
    await service.write_workspace_file_bytes(LOCAL_USER_ID, wid, rel, b"a", allow_ockham=True)

    r = client.post(
        f"/api/workspaces/{wid}/files:materialize-ref",
        json={
            "source": rel,
            "destination_folder": ".ockham/nope",
            "destination_path": None,
            "source_etag": None,
        },
        headers=h,
    )
    assert r.status_code == 400


async def test_materialize_rejects_disallowed_ockham_source(client: TestClient) -> None:
    h = _headers()
    r = client.post("/api/workspaces", json={"title": "E"}, headers=h)
    wid = r.json()["id"]
    rel = ".ockham/terminals/s.jsonl"
    await service.write_workspace_file_bytes(LOCAL_USER_ID, wid, rel, b"{}", allow_ockham=True)

    r = client.post(
        f"/api/workspaces/{wid}/files:materialize-ref",
        json={
            "source": rel,
            "destination_folder": "data",
            "destination_path": None,
            "source_etag": None,
        },
        headers=h,
    )
    assert r.status_code == 400
    assert "materialization" in r.json()["detail"].lower()


def test_materialize_source_missing(client: TestClient) -> None:
    h = _headers()
    r = client.post("/api/workspaces", json={"title": "F"}, headers=h)
    wid = r.json()["id"]

    r = client.post(
        f"/api/workspaces/{wid}/files:materialize-ref",
        json={
            "source": "data/missing.txt",
            "destination_folder": "",
            "destination_path": None,
            "source_etag": None,
        },
        headers=h,
    )
    assert r.status_code == 404


async def test_materialize_explicit_destination_conflict(client: TestClient) -> None:
    h = _headers()
    r = client.post("/api/workspaces", json={"title": "G"}, headers=h)
    wid = r.json()["id"]
    src = ".ockham/outputs/abc123.output.json"
    await service.write_workspace_file_bytes(LOCAL_USER_ID, wid, src, b"{}", allow_ockham=True)
    await service.write_workspace_file_bytes(LOCAL_USER_ID, wid, "data/out.json", b"exists")

    r = client.post(
        f"/api/workspaces/{wid}/files:materialize-ref",
        json={
            "source": src,
            "destination_folder": "",
            "destination_path": "data/out.json",
            "source_etag": None,
        },
        headers=h,
    )
    assert r.status_code == 409


async def test_materialize_etag_precondition_fails(client: TestClient) -> None:
    h = _headers()
    r = client.post("/api/workspaces", json={"title": "H"}, headers=h)
    wid = r.json()["id"]
    rel = ".ockham/data_objects/sha1.parquet"
    blob = b"one"
    await service.write_workspace_file_bytes(LOCAL_USER_ID, wid, rel, blob, allow_ockham=True)
    good_etag = compute_etag(blob)
    await service.write_workspace_file_bytes(LOCAL_USER_ID, wid, rel, b"two", allow_ockham=True)

    r = client.post(
        f"/api/workspaces/{wid}/files:materialize-ref",
        json={
            "source": rel,
            "destination_folder": "data",
            "destination_path": None,
            "source_etag": f'"{good_etag}"',
        },
        headers=h,
    )
    assert r.status_code == 412


async def test_materialize_etag_precondition_succeeds(client: TestClient) -> None:
    h = _headers()
    r = client.post("/api/workspaces", json={"title": "I"}, headers=h)
    wid = r.json()["id"]
    rel = ".ockham/datasets/x-lid/x-csha.parquet"
    blob = b"stable"
    await service.write_workspace_file_bytes(LOCAL_USER_ID, wid, rel, blob, allow_ockham=True)
    etag = compute_etag(blob)

    r = client.post(
        f"/api/workspaces/{wid}/files:materialize-ref",
        json={
            "source": rel,
            "destination_folder": "data",
            "destination_path": None,
            "source_etag": etag,
        },
        headers=h,
    )
    assert r.status_code == 200
    # No curation seeded → falls back to source basename.
    assert r.json()["path"] == "data/x-csha.parquet"
