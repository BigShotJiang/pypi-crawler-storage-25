"""Unit tests for :mod:`server.api.workspace.terminal_runs` exclusive active runs."""

from __future__ import annotations

import asyncio

import pytest

from server.api.workspace.terminal_runs import (
    ActiveRunInProgressError,
    register_active_run,
    unregister_active_run,
)


@pytest.mark.asyncio
async def test_register_second_fails() -> None:
    uid, wid, tid = "u1", "w1", "t1"
    ev1, ev2 = asyncio.Event(), asyncio.Event()
    await register_active_run(uid, wid, tid, response_id="a", cancel_event=ev1)
    with pytest.raises(ActiveRunInProgressError):
        await register_active_run(uid, wid, tid, response_id="b", cancel_event=ev2)
    await unregister_active_run(uid, wid, tid, response_id="a")


@pytest.mark.asyncio
async def test_unregister_mismatched_response_id_keeps_run() -> None:
    uid, wid, tid = "u2", "w2", "t2"
    ev = asyncio.Event()
    await register_active_run(uid, wid, tid, response_id="x", cancel_event=ev)
    await unregister_active_run(uid, wid, tid, response_id="wrong")
    with pytest.raises(ActiveRunInProgressError):
        await register_active_run(uid, wid, tid, response_id="y", cancel_event=ev)
    await unregister_active_run(uid, wid, tid, response_id="x")


@pytest.mark.asyncio
async def test_unregister_correct_response_id_allows_re_register() -> None:
    uid, wid, tid = "u3", "w3", "t3"
    ev = asyncio.Event()
    await register_active_run(uid, wid, tid, response_id="r1", cancel_event=ev)
    await unregister_active_run(uid, wid, tid, response_id="r1")
    await register_active_run(uid, wid, tid, response_id="r2", cancel_event=ev)
    await unregister_active_run(uid, wid, tid, response_id="r2")
