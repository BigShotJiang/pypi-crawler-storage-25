from __future__ import annotations

import httpx
import pytest

from server.execution import RemoteCodeExecutor


class _StubClient:
    async def get(self, _url: str, params: dict[str, str] | None = None) -> httpx.Response:  # noqa: ARG002
        req = httpx.Request("GET", "http://sandbox/executors/eid/files/missing.py")
        return httpx.Response(status_code=404, request=req)

    async def aclose(self) -> None:
        return None


@pytest.mark.asyncio
async def test_remote_read_workspace_file_raises_filenotfound_on_404() -> None:
    ex = RemoteCodeExecutor(base_url="http://sandbox", executor_id="eid")
    ex._client = _StubClient()  # type: ignore[assignment]
    with pytest.raises(FileNotFoundError):
        await ex.read_workspace_file("missing.py")
