"""Session-state artifact collection."""

from __future__ import annotations

import pandas as pd
from parsimony.result import Provenance, Result

from server.api.workspace.session_state_build import collect_workspace_artifact_lines


def test_session_state_skips_corrupt_parquet(tmp_path) -> None:
    root = tmp_path / "ws"
    (root / "data").mkdir(parents=True)
    good = root / "data" / "ok.parquet"
    df = pd.DataFrame({"a": [1]})
    r = Result(data=df, provenance=Provenance(source="s", source_description="s"))
    r.to_parquet(str(good))
    bad = root / "data" / "bad.parquet"
    bad.write_bytes(b"not parquet")
    lines = collect_workspace_artifact_lines(root, max_items=10)
    paths = {x.path for x in lines}
    assert "data/ok.parquet" in paths
    assert "data/bad.parquet" not in paths


def test_notebook_artifact_classifies_canonical_nested_path(tmp_path) -> None:
    """Notebooks classify off their canonical ``.ockham/notebooks/<uuid>/<csha>.py``
    path under the unified storage model — same shape as datasets/charts/reports.
    The visible ``notebooks/<live_name>.py`` is virtual (resolved via curation
    on read) so it does not appear in raw FS scans.
    """
    root = tmp_path / "ws"
    lid = "uuid-demo-abcdef"
    csha = "c" * 64
    snap = root / ".ockham" / "notebooks" / lid / f"{csha}.py"
    snap.parent.mkdir(parents=True)
    snap.write_text("# build a tiny dataset\nx = 1\n")
    lines = collect_workspace_artifact_lines(root, max_items=10)
    nb = next(x for x in lines if x.path.startswith(".ockham/notebooks/"))
    assert nb.kind == "notebook"
    assert nb.ref is not None
    assert nb.ref.kind == "notebook"
    assert nb.ref.logical_id == lid
    assert nb.ref.content_sha == csha


def test_published_dataset_artifact_parses_ref_from_path(tmp_path) -> None:
    """Published artifacts encode the canonical address in the path itself."""
    root = tmp_path / "ws"
    lid = "a" * 64
    csha = "b" * 64
    parquet_path = root / ".ockham" / "datasets" / lid / f"{csha}.parquet"
    parquet_path.parent.mkdir(parents=True)
    df = pd.DataFrame({"a": [1, 2]})
    r = Result(data=df, provenance=Provenance(source="s", source_description="s"))
    r.to_parquet(str(parquet_path))
    lines = collect_workspace_artifact_lines(root, max_items=10)
    ds = next(x for x in lines if x.path.startswith(".ockham/datasets/"))
    assert ds.ref is not None
    assert ds.ref.kind == "dataset"
    assert ds.ref.logical_id == lid
    assert ds.ref.content_sha == csha
