import pandas as pd
from parsimony_agents.agent.models import AgentMessage
from parsimony_agents.execution.outputs import KernelOutput

from server.execution import get_app_output_factory


def test_agent_message_roundtrip_keeps_typed_kernel_output() -> None:
    """Tool messages can carry structured execution output (not Variable store)."""
    out = get_app_output_factory().from_value(
        pd.DataFrame(
            {
                "date": ["2026-01-01", "2026-02-01"],
                "value": [100.0, 101.0],
            }
        )
    )
    body = KernelOutput(outputs=[out])

    msg = AgentMessage(role="tool", content=body, name="fred_api_fetch", tool_call_id="call_1")
    serialized = msg.model_dump(mode="json")
    restored = AgentMessage.model_validate(serialized)

    assert isinstance(restored.content, KernelOutput)
    assert restored.content.outputs
    assert restored.to_llm(mode="default")
