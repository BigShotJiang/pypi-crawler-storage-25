"""Integration-ish tests for the Quarto-backed report renderer.

These tests invoke the real Quarto binary; they are skipped if
``quarto`` is not on PATH. The cost (~3s per render baseline) is the
reason there is only a handful of tests here — broad coverage lives
in the validator unit tests where the cost is zero.
"""

from __future__ import annotations

import asyncio
import io
import json
import shutil

import pandas as pd
import pytest
from parsimony_agents.identity import ArtifactRef
from parsimony_agents.report_format import compose_snapshot

from server.api.workspace.report import (
    RenderError,
    available_formats_for_snapshot,
    render,
)
from server.api.workspace.report.cache import RenderCache
from server.api.workspace.report.render import (
    RenderInputs,
    encode_for_etag,
    templates_hash,
)


def _chart_ref(lid: str = "c1", csha: str = "f" * 64) -> ArtifactRef:
    return ArtifactRef(kind="chart", logical_id=lid, content_sha=csha)


def _dataset_ref(lid: str = "d1", csha: str = "a" * 64) -> ArtifactRef:
    return ArtifactRef(kind="dataset", logical_id=lid, content_sha=csha)


quarto_available = pytest.mark.skipif(
    shutil.which("quarto") is None,
    reason="Quarto binary not installed; install via `make quarto-install` from terminal/.",
)


def _vega_blob() -> bytes:
    spec = {
        "$schema": "https://vega.github.io/schema/vega-lite/v5.json",
        "data": {"values": [{"x": 1, "y": 2}, {"x": 2, "y": 4}, {"x": 3, "y": 6}]},
        "mark": "line",
        "encoding": {
            "x": {"field": "x", "type": "quantitative"},
            "y": {"field": "y", "type": "quantitative"},
        },
    }
    return json.dumps(spec).encode("utf-8")


def _parquet_blob() -> bytes:
    df = pd.DataFrame({"country": ["US", "UK", "DE"], "gdp": [25.0, 3.1, 4.2]})
    buf = io.BytesIO()
    df.to_parquet(buf)
    return buf.getvalue()


def test_available_formats_round_trip() -> None:
    snapshot = compose_snapshot(["html", "pdf", "pptx"], {}, "body\n", title="T").encode("utf-8")
    assert available_formats_for_snapshot(snapshot) == ["html", "pdf", "pptx"]


def test_templates_hash_is_stable_within_a_process() -> None:
    h1 = templates_hash()
    h2 = templates_hash()
    assert h1 == h2 and len(h1) == 64


def test_encode_for_etag_is_deterministic() -> None:
    parts = ("csha", "html", "1.9.37", templates_hash())
    e1 = encode_for_etag(parts)
    e2 = encode_for_etag(parts)
    assert e1 == e2


@quarto_available
@pytest.mark.asyncio
async def test_render_html_returns_html_bytes() -> None:
    body = (
        "A short summary of the quarter.\n\n"
        "![Chart](file://./charts/trend.vl.json)\n\n"
        "![Table](file://./data/sales.parquet)\n"
    )
    chart_ref = _chart_ref()
    dataset_ref = _dataset_ref()
    pin_map = {"trend": chart_ref, "sales": dataset_ref}
    snapshot = compose_snapshot(["html"], pin_map, body, title="Quarterly review").encode("utf-8")

    blobs = {
        chart_ref.workspace_file_path: _vega_blob(),
        dataset_ref.workspace_file_path: _parquet_blob(),
    }
    out = await render(RenderInputs(snapshot_bytes=snapshot, fmt="html", workspace_loader=blobs.get))
    assert b"<!DOCTYPE" in out[:200].upper() or b"<html" in out.lower()[:1000]
    assert b"Quarterly review" in out
    # The dataset shows up as a markdown table → real <table> in HTML.
    assert b"<table" in out


@quarto_available
@pytest.mark.asyncio
async def test_render_pdf_starts_with_pdf_magic() -> None:
    body = "A tiny report.\n"
    snapshot = compose_snapshot(["pdf"], {}, body, title="Hello").encode("utf-8")
    out = await render(RenderInputs(snapshot_bytes=snapshot, fmt="pdf", workspace_loader={}.get))
    assert out.startswith(b"%PDF")


@quarto_available
@pytest.mark.asyncio
async def test_render_rejects_undeclared_format() -> None:
    body = "x\n"
    snapshot = compose_snapshot(["html"], {}, body, title="T").encode("utf-8")
    with pytest.raises(RenderError, match="does not declare"):
        await render(RenderInputs(snapshot_bytes=snapshot, fmt="pdf", workspace_loader={}.get))


@quarto_available
@pytest.mark.asyncio
async def test_render_missing_ref_raises_render_error() -> None:
    body = "![](file://./charts/trend.vl.json)\n"
    chart_ref = _chart_ref()
    snapshot = compose_snapshot(["html"], {"trend": chart_ref}, body, title="T").encode("utf-8")
    with pytest.raises(RenderError, match="not found"):
        await render(RenderInputs(snapshot_bytes=snapshot, fmt="html", workspace_loader={}.get))


@pytest.mark.asyncio
async def test_cache_coalesces_inflight_renders() -> None:
    """N concurrent requests for the same key trigger exactly one render."""
    cache = RenderCache(capacity=4)
    counter = {"n": 0}

    async def compute() -> bytes:
        counter["n"] += 1
        await asyncio.sleep(0.05)
        return b"OK"

    key = ("csha", "html", "v1", "th1")
    results = await asyncio.gather(*[cache.get_or_render(key, compute) for _ in range(8)])
    assert all(r == b"OK" for r in results)
    assert counter["n"] == 1


@pytest.mark.asyncio
async def test_cache_hits_on_second_call() -> None:
    cache = RenderCache(capacity=4)
    counter = {"n": 0}

    async def compute() -> bytes:
        counter["n"] += 1
        return b"X"

    key = ("csha", "html", "v1", "th1")
    await cache.get_or_render(key, compute)
    await cache.get_or_render(key, compute)
    assert counter["n"] == 1


@pytest.mark.asyncio
async def test_cache_evicts_lru() -> None:
    cache = RenderCache(capacity=2)
    n = {"v": 0}

    async def make(k: str):
        async def compute() -> bytes:
            n["v"] += 1
            return k.encode()

        return await cache.get_or_render((k, "f", "v", "h"), compute)

    await make("a")
    await make("b")
    await make("c")  # evicts "a"
    await make("a")  # re-renders
    assert n["v"] == 4


# ---------------------------------------------------------------------------
# Polish: Google Fonts injection + typst preamble + chart cross-refs
# ---------------------------------------------------------------------------


def test_compose_yaml_injects_local_font_face_for_html_like() -> None:
    """HTML / dashboard / revealjs YAML carries inline ``@font-face``
    declarations referencing locally-staged woff2 files. The Google
    Fonts CDN is intentionally NOT referenced — render-time network
    fetches were causing 4xx failures on some networks; bundling the
    woff2 files removes that fragility (``embed-resources: True`` then
    base64-inlines them into the output)."""
    import tempfile
    from pathlib import Path

    from server.api.workspace.report.render import _compose_yaml

    for fmt in ("html", "dashboard", "revealjs"):
        with tempfile.TemporaryDirectory() as td:
            yaml_text = _compose_yaml(fmt, Path(td), title="T", subtitle="")
            # Font files must be staged alongside the qmd so the
            # ``url('fonts/<file>')`` references resolve at render time.
            assert (Path(td) / "fonts" / "Inter-Regular.woff2").is_file(), fmt
            assert (Path(td) / "fonts" / "JetBrainsMono-Regular.woff2").is_file(), fmt
        assert "header-includes: |" in yaml_text, fmt
        assert "@font-face" in yaml_text, fmt
        assert "Inter-Regular.woff2" in yaml_text, fmt
        # Belt-and-suspenders: ensure we are NOT linking out to Google.
        assert "fonts.googleapis.com" not in yaml_text, fmt
        assert "fonts.gstatic.com" not in yaml_text, fmt


def test_compose_yaml_injects_workspace_density_for_html_and_dashboard() -> None:
    """HTML + dashboard YAML carries the 13px workspace-density block.

    Revealjs explicitly does NOT — see the negative test below. Slides
    use reveal.js's own 40px scale; forcing 13px makes a deck illegible.
    """
    import tempfile
    from pathlib import Path

    from server.api.workspace.report.render import _compose_yaml

    for fmt in ("html", "dashboard"):
        with tempfile.TemporaryDirectory() as td:
            yaml_text = _compose_yaml(fmt, Path(td), title="T", subtitle="")
        # Body density — anchors 1rem at 13px, matching the workspace shell.
        assert "font-size: 13px !important" in yaml_text, fmt


def test_compose_yaml_does_not_inject_workspace_density_for_revealjs() -> None:
    """Revealjs YAML must NOT carry the 13px workspace density — slides
    own their typography via reveal.js's ``--r-main-font-size: 40px`` and
    heading scale. Forcing 13px clobbers both via ``!important``."""
    import tempfile
    from pathlib import Path

    from server.api.workspace.report.render import _compose_yaml

    with tempfile.TemporaryDirectory() as td:
        yaml_text = _compose_yaml("revealjs", Path(td), title="T", subtitle="")
    assert "font-size: 13px" not in yaml_text
    # Heading-scale overrides are also out for the same reason.
    assert "1.4rem !important" not in yaml_text  # h1
    assert "1.2rem !important" not in yaml_text  # h2


def test_compose_yaml_injects_scrollbar_for_all_html_like() -> None:
    """Scrollbar styling is universal — matches workspace shell across
    HTML report, dashboard, and the iframe wrapping a slide deck."""
    import tempfile
    from pathlib import Path

    from server.api.workspace.report.render import _compose_yaml

    for fmt in ("html", "dashboard", "revealjs"):
        with tempfile.TemporaryDirectory() as td:
            yaml_text = _compose_yaml(fmt, Path(td), title="T", subtitle="")
        assert "::-webkit-scrollbar" in yaml_text, fmt
        assert "scrollbar-width: thin" in yaml_text, fmt


def test_compose_yaml_does_not_inject_html_fonts_for_pdf() -> None:
    """PDF gets the typst preamble instead of the HTML font face block.

    PDF rendering goes through typst, which uses system-installed fonts
    by name (``mainfont:``/``monofont:``). The woff2 staging path is
    HTML-only.
    """
    import tempfile
    from pathlib import Path

    from server.api.workspace.report.render import _compose_yaml

    with tempfile.TemporaryDirectory() as td:
        yaml_text = _compose_yaml("pdf", Path(td), title="T", subtitle="")
        # No staged fonts dir for PDF.
        assert not (Path(td) / "fonts").exists()
    assert "@font-face" not in yaml_text
    assert "header-includes: |" in yaml_text
    # The typst preamble's distinctive page-counter directive.
    assert "#counter(page)" in yaml_text


def test_compose_yaml_pdf_uses_brand_fonts() -> None:
    """PDF YAML names brand fonts (mainfont/monofont) by primary family."""
    import tempfile
    from pathlib import Path

    from server.api.workspace.report.brand import DEFAULT_BRAND
    from server.api.workspace.report.render import _compose_yaml

    with tempfile.TemporaryDirectory() as td:
        yaml_text = _compose_yaml("pdf", Path(td), title="T", subtitle="")
    assert f"mainfont: {DEFAULT_BRAND.font_body_primary}" in yaml_text
    assert f"monofont: {DEFAULT_BRAND.font_mono_primary}" in yaml_text


def test_compose_yaml_pptx_stages_reference_deck() -> None:
    """PPTX renders find ``reference.pptx`` staged into the workdir."""
    import tempfile
    from pathlib import Path

    from server.api.workspace.report.render import _compose_yaml

    with tempfile.TemporaryDirectory() as td:
        workdir = Path(td)
        _compose_yaml("pptx", workdir, title="T", subtitle="")
        assert (workdir / "reference.pptx").is_file()


def test_stage_refs_attaches_fig_id_to_charts() -> None:
    """Staged chart refs get ``{#fig-rN .lightbox}`` for Quarto cross-refs."""
    import tempfile
    from pathlib import Path

    from server.api.workspace.report.render import _stage_refs

    chart_ref = _chart_ref()
    body = "![Trend](file://./charts/trend.vl.json)\n"
    blobs = {chart_ref.workspace_file_path: _vega_blob()}
    with tempfile.TemporaryDirectory() as td:
        out = _stage_refs(body, blobs.get, Path(td), fmt="html", pin_map={"trend": chart_ref})
    assert "{#fig-r0" in out
    assert "fig-align=" in out
    assert ".lightbox}" in out
    # HTML format does NOT add a width attribute — only slide formats do.
    assert "width=" not in out


def test_stage_refs_adds_width_attr_for_slide_formats() -> None:
    """On revealjs / pptx, chart attrs include ``width="80%"`` so the chart
    leaves room for a bullet column / caption / breathing space."""
    import tempfile
    from pathlib import Path

    from server.api.workspace.report.render import _stage_refs

    chart_ref = _chart_ref()
    body = "![Trend](file://./charts/trend.vl.json)\n"
    blobs = {chart_ref.workspace_file_path: _vega_blob()}
    for fmt in ("revealjs", "pptx"):
        with tempfile.TemporaryDirectory() as td:
            out = _stage_refs(body, blobs.get, Path(td), fmt=fmt, pin_map={"trend": chart_ref})
        assert 'width="80%"' in out, fmt


def test_stage_refs_substitutes_parquet_with_table_block() -> None:
    """Parquet refs become standalone markdown tables, not broken images."""
    import tempfile
    from pathlib import Path

    from server.api.workspace.report.render import _stage_refs

    ds_ref = _dataset_ref()
    body = "![Sales by country](file://./data/sales.parquet)\n"
    df = pd.DataFrame({"country": ["US", "UK"], "rev": [10.0, 7.5]})
    buf = io.BytesIO()
    df.to_parquet(buf)
    blobs = {ds_ref.workspace_file_path: buf.getvalue()}
    with tempfile.TemporaryDirectory() as td:
        out = _stage_refs(body, blobs.get, Path(td), fmt="html", pin_map={"sales": ds_ref})
    # The image syntax is gone; a pipe table + caption is in.
    assert "![Sales by country]" not in out
    assert "| country | rev |" in out
    assert ": Sales by country" in out


def test_stage_refs_caps_parquet_table_on_slide_formats() -> None:
    """A 30-row × 8-col parquet ref renders to ≤6 rows × ≤5 cols on slides
    with a visible truncation note. On HTML the same ref keeps all columns
    and up to 50 rows."""
    import tempfile
    from pathlib import Path

    from server.api.workspace.report.render import _stage_refs

    ds_ref = _dataset_ref(lid="d-wide", csha="b" * 64)
    body = "![Wide](file://./data/wide.parquet)\n"
    df = pd.DataFrame({f"c{i}": list(range(30)) for i in range(8)})
    buf = io.BytesIO()
    df.to_parquet(buf)
    blobs = {ds_ref.workspace_file_path: buf.getvalue()}
    pin_map = {"wide": ds_ref}

    with tempfile.TemporaryDirectory() as td:
        slide_out = _stage_refs(body, blobs.get, Path(td), fmt="revealjs", pin_map=pin_map)
    # Slide path — 6 rows + header + sep = 8 table lines max; truncation note.
    table_rows = [ln for ln in slide_out.splitlines() if ln.startswith("|")]
    # 1 header + 1 separator + 6 data rows = 8 lines, with col cap producing
    # 5 real cols + 1 ellipsis column = 6 cells.
    assert len(table_rows) == 8
    assert "Showing first 6 of 30 rows" in slide_out
    assert "Showing first 5 of 8 columns" in slide_out
    # Ellipsis marker column is present once per header + separator + data row.
    assert slide_out.count("…") >= 7

    with tempfile.TemporaryDirectory() as td:
        html_out = _stage_refs(body, blobs.get, Path(td), fmt="html", pin_map=pin_map)
    # HTML path — no column truncation; all 8 columns survive.
    assert "c7" in html_out  # the last column made it through


def test_slide_safe_body_attaches_smaller_to_overflowing_h2() -> None:
    """A section with > 120 words gets ``{.smaller}`` added to its H2;
    a terse section does not."""
    from server.api.workspace.report.render import _slide_safe_body

    long_para = " ".join(["lorem"] * 150)
    body = f"# Title\n\n## Overflowing\n\n{long_para}\n\n## Terse\n\nShort content.\n"
    out = _slide_safe_body(body)
    assert "## Overflowing {.smaller}" in out
    assert "## Terse {.smaller}" not in out


def test_slide_safe_body_is_idempotent() -> None:
    """Running the transform twice produces the same output — already-
    attributed H2 lines are skipped."""
    from server.api.workspace.report.render import _slide_safe_body

    long_para = " ".join(["lorem"] * 150)
    body = f"## Section\n\n{long_para}\n"
    once = _slide_safe_body(body)
    twice = _slide_safe_body(once)
    assert once == twice
    assert once.count("{.smaller}") == 1


def test_slide_safe_body_respects_existing_h2_attrs() -> None:
    """If the agent already wrote ``## Title {.scrollable}`` the transform
    must not append ``{.smaller}`` (the existing attribute block is the
    agent's explicit override)."""
    from server.api.workspace.report.render import _slide_safe_body

    long_para = " ".join(["lorem"] * 150)
    body = f"## Already scrollable {{.scrollable}}\n\n{long_para}\n"
    out = _slide_safe_body(body)
    assert "{.scrollable}" in out
    assert "{.smaller}" not in out


def test_slide_safe_body_ignores_speaker_notes() -> None:
    """A section whose only content is in ``::: {.notes}`` does not count
    toward the on-slide budget."""
    from server.api.workspace.report.render import _slide_safe_body

    long_notes = " ".join(["lorem"] * 200)
    body = f"## Slide\n\nShort visible text.\n\n::: {{.notes}}\n{long_notes}\n:::\n"
    out = _slide_safe_body(body)
    assert "{.smaller}" not in out


def test_slide_yaml_revealjs_carries_fig_dimensions_and_viewport() -> None:
    """Revealjs YAML pins viewport (1280×720), fig budget (9×5 inches),
    and drops auto-stretch (which previously caused figures to fill the
    whole slide regardless of size)."""
    import tempfile
    from pathlib import Path

    from server.api.workspace.report.render import _compose_yaml

    with tempfile.TemporaryDirectory() as td:
        yaml_text = _compose_yaml("revealjs", Path(td), title="T", subtitle="")
    assert "width: 1280" in yaml_text
    assert "height: 720" in yaml_text
    assert "fig-width: 9" in yaml_text
    assert "fig-height: 5" in yaml_text
    assert "auto-stretch" not in yaml_text


def test_slide_yaml_pptx_carries_fig_dimensions() -> None:
    """PPTX gets fig-width/fig-height (PPTX has no overflow rescue, so
    sized figures are the only line of defense besides table caps)."""
    import tempfile
    from pathlib import Path

    from server.api.workspace.report.render import _compose_yaml

    with tempfile.TemporaryDirectory() as td:
        yaml_text = _compose_yaml("pptx", Path(td), title="T", subtitle="")
    assert "fig-width: 9" in yaml_text
    assert "fig-height: 5" in yaml_text


def test_slide_yaml_uses_dark_preset_not_default() -> None:
    """Slides inherit the dark brand palette — the previous ``default``
    preset forced a light slide carve-out that's now removed."""
    import tempfile
    from pathlib import Path

    from server.api.workspace.report.render import _compose_yaml

    with tempfile.TemporaryDirectory() as td:
        yaml_text = _compose_yaml("revealjs", Path(td), title="T", subtitle="")
    # ``dark`` first then theme.scss layers brand colors on top.
    assert "- dark" in yaml_text
    assert "theme.scss" in yaml_text


def test_slide_defense_block_is_revealjs_only() -> None:
    """The slide-defense block lives in its own constant and is only
    composed into the YAML for revealjs — html and dashboard skip it."""
    import tempfile
    from pathlib import Path

    from server.api.workspace.report.render import (
        _HTML_SLIDE_DEFENSE,
        _compose_yaml,
    )

    # Constant content is correct.
    assert ".reveal .slides > section" in _HTML_SLIDE_DEFENSE
    assert "overflow: hidden !important" in _HTML_SLIDE_DEFENSE
    assert ".scrollable" in _HTML_SLIDE_DEFENSE
    assert ".smaller" in _HTML_SLIDE_DEFENSE

    # Only revealjs YAML carries it.
    with tempfile.TemporaryDirectory() as td:
        rj = _compose_yaml("revealjs", Path(td), title="T", subtitle="")
    assert ".reveal .slides > section" in rj
    for fmt in ("html", "dashboard"):
        with tempfile.TemporaryDirectory() as td:
            y = _compose_yaml(fmt, Path(td), title="T", subtitle="")
        assert ".reveal .slides > section" not in y, fmt


def test_normalize_vl_spec_adds_dimensions_for_slides() -> None:
    """A bare vega-lite spec gets slide-safe 720×400 added; an already-
    sized spec is left alone; a layout container is left alone."""
    from server.api.workspace.report.render import _normalize_vl_spec_for_slides

    bare = {"mark": "line", "encoding": {}}
    out = _normalize_vl_spec_for_slides(bare)
    assert out == {**bare, "width": 720, "height": 400}

    sized = {"mark": "bar", "width": 300, "height": 200}
    assert _normalize_vl_spec_for_slides(sized) == sized

    container = {"hconcat": [{"mark": "line"}, {"mark": "bar"}]}
    assert _normalize_vl_spec_for_slides(container) == container


def test_apply_brand_to_scss_resolves_overlapping_placeholders() -> None:
    """Longer placeholders must be substituted before shorter prefixes."""
    from server.api.workspace.report.brand import (
        BrandTokens,
        apply_brand_to_scss,
    )

    tokens = BrandTokens()
    scss = "$accent: $brand-primary; $hover: $brand-primary-dark;"
    out = apply_brand_to_scss(scss, tokens)
    assert tokens.primary in out and tokens.primary_dark in out
    # No raw placeholders survive.
    assert "$brand-primary" not in out
    assert "$brand-primary-dark" not in out


def test_templates_hash_includes_preamble_constants() -> None:
    """Editing any header-include part invalidates the cache identity.

    Iterates each of the four header-include constants individually so
    a future split / merge can't silently drop one from the hash.
    """
    import sys

    # ``from .render import render`` in report/__init__.py shadows the
    # submodule name on the package, so we look up the module via
    # ``sys.modules`` (already imported by the top-of-file import).
    mod = sys.modules["server.api.workspace.report.render"]
    h_base = mod.templates_hash()
    for name in (
        "_HTML_FONT_LINKS",
        "_HTML_SCROLLBAR_CSS",
        "_HTML_WORKSPACE_DENSITY",
        "_HTML_SLIDE_DEFENSE",
    ):
        original = getattr(mod, name)
        try:
            setattr(mod, name, "<!-- mutated -->")
            h_mut = mod.templates_hash()
        finally:
            setattr(mod, name, original)
        assert h_base != h_mut, f"templates_hash did not fold in {name}"
