"""Detail-tab payload reads live curation, not the embedded tombstone.

The viewer payload functions (`_dataset_payload`, `_chart_payload`)
build the ``artifact`` envelope from the curation block embedded in
the snapshot bytes — captured at persist time and never updated
thereafter (§5.9). The PATCH curation endpoint writes to the sidecar
without rewriting bytes, so without an overlay step the detail tab
keeps showing the stale title indefinitely.

These tests pin the contract: ``enrich_artifact_envelope`` (which
already runs after every ``GET /view``) overlays the sidecar's
``title/description/tags/notes/live_name`` onto the embedded form.
"""

from __future__ import annotations

from io import BytesIO
from pathlib import Path

import pandas as pd
import pyarrow.parquet as pq
import pytest
from parsimony_agents.artifacts import Dataset
from parsimony_agents.dataset_io import CURATION_META_KEY
from parsimony_agents.execution.outputs import DataFrameObject
from parsimony_agents.identity import ArtifactRef, dataset_logical_id

from server.api.middleware import LOCAL_USER_ID
from server.api.workspace import service
from server.api.workspace.artifact_registry import persist_return_artifact
from server.api.workspace.ref_enrichment import enrich_artifact_envelope
from server.api.workspace.snapshot_store import (
    Curation,
    read_curation,
    write_curation,
)
from server.api.workspace.viewers import viewer_payload_for_path


@pytest.fixture
async def workspace_id(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> str:
    monkeypatch.setenv("OCKHAM_DATA_DIR", str(tmp_path))
    meta = await service.create_workspace(LOCAL_USER_ID, "overlay-tests")
    return meta.id


def _nb_ref(sha: str) -> ArtifactRef:
    return ArtifactRef(kind="notebook", logical_id=sha, content_sha=sha)


async def _persist_dataset(
    workspace_id: str, tmp_path: Path, *, title: str = "Original Title"
) -> tuple[ArtifactRef, str]:
    df = pd.DataFrame({"x": [1, 2, 3]})
    nb_ref = _nb_ref("nb-csha")
    artifact = Dataset(
        title=title,
        description="Original description",
        tags=["original"],
        notes=["Original note."],
        notebook_refs=[nb_ref],
        source_refs=[],
        logical_id=dataset_logical_id(notebook_refs=[nb_ref], variable_name="x", source_refs=[]),
    ).with_payload(DataFrameObject.from_pandas(df, local_dir=tmp_path / "_dfo"))

    ref, rel, _etag, _version = await persist_return_artifact(
        user_id=LOCAL_USER_ID,
        workspace_id=workspace_id,
        artifact=artifact,
        kind="dataset",
    )
    return ref, rel


async def test_overlay_replaces_embedded_title_with_curation_title(workspace_id: str, tmp_path: Path) -> None:
    """After PATCH-style curation edit, the detail tab reflects the new title."""
    ref, rel = await _persist_dataset(workspace_id, tmp_path, title="Original")

    # Sanity: the embedded blob still carries the original title (frozen).
    body = await service.read_workspace_file_bytes(LOCAL_USER_ID, workspace_id, rel, allow_ockham=True)
    assert body is not None
    schema_meta = pq.read_metadata(BytesIO(body)).schema.to_arrow_schema().metadata or {}
    assert CURATION_META_KEY in schema_meta

    # Edit curation sidecar (mimics the PATCH endpoint writing live state).
    cur = await read_curation(LOCAL_USER_ID, workspace_id, "dataset", ref.logical_id)
    assert cur is not None and isinstance(cur, Curation)
    edited = cur.model_copy(
        update={
            "title": "Renamed",
            "description": "New description",
            "tags": ["edited"],
            "notes": ["New note."],
            "live_name": "renamed",
        }
    )
    await write_curation(LOCAL_USER_ID, workspace_id, "dataset", ref.logical_id, edited)

    # GET /view-equivalent: viewer payload + envelope enrichment.
    payload = viewer_payload_for_path(rel, body)
    assert payload["kind"] == "dataset"
    # Pre-overlay: the embedded title is what the viewer surfaced.
    assert payload["artifact"]["title"] == "Original"

    enriched = await enrich_artifact_envelope(payload, user_id=LOCAL_USER_ID, workspace_id=workspace_id)
    artifact = enriched["artifact"]
    assert artifact["title"] == "Renamed"
    assert artifact["description"] == "New description"
    assert artifact["tags"] == ["edited"]
    assert artifact["notes"] == ["New note."]
    assert artifact["live_name"] == "renamed"


async def test_overlay_falls_back_to_embedded_when_sidecar_missing(workspace_id: str, tmp_path: Path) -> None:
    """Without a sidecar, the embedded form is preserved (no NoneType blanks)."""
    ref, rel = await _persist_dataset(workspace_id, tmp_path, title="Standalone")
    body = await service.read_workspace_file_bytes(LOCAL_USER_ID, workspace_id, rel, allow_ockham=True)
    assert body is not None

    # Wipe the curation sidecar — simulates an "out-of-workspace" file.
    sidecar = (
        service.workspace_local_tree_path(LOCAL_USER_ID, workspace_id)
        / f".ockham/datasets/{ref.logical_id}/curation.json"
    )
    sidecar.unlink()

    payload = viewer_payload_for_path(rel, body)
    enriched = await enrich_artifact_envelope(payload, user_id=LOCAL_USER_ID, workspace_id=workspace_id)
    artifact = enriched["artifact"]
    assert artifact["title"] == "Standalone"
    assert artifact["description"] == "Original description"
    assert artifact["tags"] == ["original"]


async def test_overlay_skips_data_object_payloads(workspace_id: str) -> None:
    """Raw fetch payloads carry ``provenance``, not ``artifact`` — overlay no-ops."""
    payload: dict = {
        "kind": "data_object",
        "provenance": {"source": "fred_fetch", "params": {}},
        "payload": {"row_count": 0, "schema": [], "rows": []},
    }
    enriched = await enrich_artifact_envelope(payload, user_id=LOCAL_USER_ID, workspace_id=workspace_id)
    # No artifact envelope → enrichment leaves payload untouched.
    assert enriched["kind"] == "data_object"
    assert enriched["provenance"]["source"] == "fred_fetch"
