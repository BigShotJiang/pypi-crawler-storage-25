"""Tests for ``persist_return_artifact`` (content-addressed layout).

The registry is the single boundary that turns a typed in-process
``Dataset``/``Chart``/``Report`` into:

* An immutable snapshot at
  ``.ockham/<kind>s/<logical_id>/<content_sha>.<ext>``.
* A curation sidecar at ``.ockham/<kind>s/<logical_id>/curation.json``.
* A new ``log.jsonl`` line keyed by ``content_sha`` (idempotent).

These tests pin the boundary behavior described in
``CONTENT_ADDRESSED_ARTIFACTS_PLAN.md`` §2.3, §2.4, §2.5, §5.9.
"""

from __future__ import annotations

import json
from io import BytesIO
from pathlib import Path

import pandas as pd
import pyarrow.parquet as pq
import pytest
from parsimony_agents.artifacts import Chart, Dataset, Report
from parsimony_agents.dataset_io import CURATION_META_KEY
from parsimony_agents.execution.outputs import DataFrameObject, FigureObject
from parsimony_agents.identity import (
    ArtifactRef,
    chart_logical_id,
    dataset_logical_id,
    report_logical_id,
)

from server.api.middleware import LOCAL_USER_ID
from server.api.workspace import service
from server.api.workspace.artifact_registry import persist_return_artifact
from server.api.workspace.snapshot_store import (
    read_curation,
    read_log,
)


@pytest.fixture
async def workspace_id(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> str:
    monkeypatch.setenv("OCKHAM_DATA_DIR", str(tmp_path))
    meta = await service.create_workspace(LOCAL_USER_ID, "registry-tests")
    return meta.id


def _nb_ref(sha: str) -> ArtifactRef:
    return ArtifactRef(kind="notebook", logical_id=sha, content_sha=sha)


def _do_ref(lid: str = "do-lid", csha: str = "do-csha") -> ArtifactRef:
    return ArtifactRef(kind="data_object", logical_id=lid, content_sha=csha)


def _ds_ref(lid: str = "ds-lid", csha: str = "ds-csha") -> ArtifactRef:
    return ArtifactRef(kind="dataset", logical_id=lid, content_sha=csha)


# ---------------------------------------------------------------------------
# Dataset
# ---------------------------------------------------------------------------


async def test_persist_dataset_writes_snapshot_curation_log(workspace_id: str, tmp_path: Path) -> None:
    df = pd.DataFrame({"x": [1, 2, 3]})
    nb_ref = _nb_ref("nb-csha")
    src_ref = _do_ref()
    artifact = Dataset(
        title="US CPI",
        description="Consumer Price Index",
        tags=["macro"],
        notebook_refs=[nb_ref],
        source_refs=[src_ref],
        logical_id=dataset_logical_id(notebook_refs=[nb_ref], variable_name="cpi", source_refs=[src_ref]),
    ).with_payload(DataFrameObject.from_pandas(df, local_dir=tmp_path / "_dfo"))

    ref, rel, etag, version = await persist_return_artifact(
        user_id=LOCAL_USER_ID,
        workspace_id=workspace_id,
        artifact=artifact,
        kind="dataset",
    )

    assert ref.kind == "dataset"
    assert ref.logical_id == artifact.logical_id
    assert rel == ref.workspace_file_path
    assert rel.startswith(".ockham/datasets/")
    assert rel.endswith(".parquet")

    # Snapshot bytes are valid parquet with embedded curation.
    body = await service.read_workspace_file_bytes(LOCAL_USER_ID, workspace_id, rel, allow_ockham=True)
    assert body is not None and body[:4] == b"PAR1"
    schema_meta = pq.read_metadata(BytesIO(body)).schema.to_arrow_schema().metadata or {}
    assert CURATION_META_KEY in schema_meta
    embedded = json.loads(schema_meta[CURATION_META_KEY].decode("utf-8"))
    assert embedded["title"] == "US CPI"
    assert embedded["tags"] == ["macro"]

    # Curation sidecar present and matches in-memory model.
    cur = await read_curation(LOCAL_USER_ID, workspace_id, "dataset", artifact.logical_id)
    assert cur is not None
    assert cur.title == "US CPI"
    assert cur.tags == ["macro"]
    # Default live_name derived from title slug.
    assert cur.live_name == "us_cpi"

    # Log has one line referencing the snapshot's content_sha.
    log = await read_log(LOCAL_USER_ID, workspace_id, "dataset", artifact.logical_id)
    assert len(log) == 1
    assert log[0].content_sha == ref.content_sha
    assert log[0].inputs["sources"] == [src_ref.content_sha]


async def test_dataset_repeat_publish_is_idempotent(workspace_id: str, tmp_path: Path) -> None:
    """Same logical_id + same bytes → one snapshot, one log entry, same version."""
    df = pd.DataFrame({"x": [1, 2, 3]})
    nb_ref = _nb_ref("nb-csha")
    lid = dataset_logical_id(notebook_refs=[nb_ref], variable_name="cpi", source_refs=[])
    a = Dataset(title="t", logical_id=lid, notebook_refs=[nb_ref]).with_payload(
        DataFrameObject.from_pandas(df, local_dir=tmp_path / "_a")
    )
    b = Dataset(title="t", logical_id=lid, notebook_refs=[nb_ref]).with_payload(
        DataFrameObject.from_pandas(df.copy(), local_dir=tmp_path / "_b")
    )

    ref_a, _, _, version_a = await persist_return_artifact(
        user_id=LOCAL_USER_ID, workspace_id=workspace_id, artifact=a, kind="dataset"
    )
    ref_b, _, _, version_b = await persist_return_artifact(
        user_id=LOCAL_USER_ID, workspace_id=workspace_id, artifact=b, kind="dataset"
    )
    assert ref_a == ref_b
    assert version_a == 1
    assert version_b == 1  # identical content → same version, no bump
    log = await read_log(LOCAL_USER_ID, workspace_id, "dataset", lid)
    assert len(log) == 1


async def test_dataset_distinct_content_bumps_version(workspace_id: str, tmp_path: Path) -> None:
    """A different content_sha (e.g. fresh data) under the same logical_id → v2."""
    nb_ref = _nb_ref("nb-csha")
    lid = dataset_logical_id(notebook_refs=[nb_ref], variable_name="cpi", source_refs=[])

    df_v1 = pd.DataFrame({"x": [1, 2, 3]})
    a = Dataset(title="t", logical_id=lid, notebook_refs=[nb_ref]).with_payload(
        DataFrameObject.from_pandas(df_v1, local_dir=tmp_path / "_a")
    )
    _, _, _, v1 = await persist_return_artifact(
        user_id=LOCAL_USER_ID, workspace_id=workspace_id, artifact=a, kind="dataset"
    )

    df_v2 = pd.DataFrame({"x": [10, 20, 30]})
    b = Dataset(title="t", logical_id=lid, notebook_refs=[nb_ref]).with_payload(
        DataFrameObject.from_pandas(df_v2, local_dir=tmp_path / "_b")
    )
    _, _, _, v2 = await persist_return_artifact(
        user_id=LOCAL_USER_ID, workspace_id=workspace_id, artifact=b, kind="dataset"
    )

    assert v1 == 1
    assert v2 == 2
    log = await read_log(LOCAL_USER_ID, workspace_id, "dataset", lid)
    assert len(log) == 2


async def test_persist_dataset_without_payload_raises(workspace_id: str) -> None:
    artifact = Dataset(title="t", logical_id="lid")
    with pytest.raises(ValueError, match="missing its live"):
        await persist_return_artifact(
            user_id=LOCAL_USER_ID,
            workspace_id=workspace_id,
            artifact=artifact,
            kind="dataset",
        )


async def test_persist_dataset_without_logical_id_raises(workspace_id: str, tmp_path: Path) -> None:
    df = pd.DataFrame({"x": [1]})
    artifact = Dataset(title="t").with_payload(DataFrameObject.from_pandas(df, local_dir=tmp_path / "_dfo"))
    with pytest.raises(ValueError, match="logical_id=''"):
        await persist_return_artifact(
            user_id=LOCAL_USER_ID,
            workspace_id=workspace_id,
            artifact=artifact,
            kind="dataset",
        )


# ---------------------------------------------------------------------------
# Chart
# ---------------------------------------------------------------------------


async def test_persist_chart_writes_snapshot_curation_log(workspace_id: str) -> None:
    spec: dict[str, object] = {
        "$schema": "https://vega.github.io/schema/vega-lite/v5.json",
        "mark": "line",
    }
    nb_ref = _nb_ref("nb-csha")
    ds_ref = _ds_ref()
    chart = Chart(
        title="CPI Trend",
        notebook_ref=nb_ref,
        source_dataset_refs=[ds_ref],
        logical_id=chart_logical_id(
            notebook_ref=nb_ref,
            chart_variable_name="cpi_chart",
            source_dataset_refs=[ds_ref],
            source_refs=[],
        ),
    ).with_payload(FigureObject(value=spec))

    ref, rel, etag, version = await persist_return_artifact(
        user_id=LOCAL_USER_ID,
        workspace_id=workspace_id,
        artifact=chart,
        kind="chart",
    )

    assert ref.kind == "chart"
    assert rel.startswith(".ockham/charts/")
    assert rel.endswith(".vl.json")

    body = await service.read_workspace_file_bytes(LOCAL_USER_ID, workspace_id, rel, allow_ockham=True)
    assert body is not None
    on_disk = json.loads(body.decode("utf-8"))
    assert on_disk["mark"] == "line"
    embedded = on_disk["usermeta"]["parsimony_agents"]
    assert embedded["title"] == "CPI Trend"
    assert embedded["notebook_ref"]["content_sha"] == "nb-csha"

    cur = await read_curation(LOCAL_USER_ID, workspace_id, "chart", chart.logical_id)
    assert cur is not None
    assert cur.title == "CPI Trend"

    log = await read_log(LOCAL_USER_ID, workspace_id, "chart", chart.logical_id)
    assert len(log) == 1
    assert log[0].inputs["notebook"] == "nb-csha"
    assert log[0].inputs["source_datasets"] == [ds_ref.content_sha]


# ---------------------------------------------------------------------------
# Report
# ---------------------------------------------------------------------------


async def test_persist_report_writes_under_ockham_reports(workspace_id: str) -> None:
    """Reports now live under ``.ockham/reports/<lid>/<csha>.qmd``,
    versioned alongside other primitives. The persisted bytes are the
    canonical snapshot shape: Quarto YAML frontmatter + agent body. The
    pin map travels in the frontmatter; :attr:`Report.embedded_refs`
    is derived from it + the body."""
    embedded = _ds_ref("emb-lid", "emb-csha")
    md = "# Q4 2025 review\n\nNarrative body.\n\n![](file://./data/sales.parquet)\n"
    report = Report(
        title="Q4 2025 review",
        description="Quarterly summary",
        tags=["q4-review"],
        markdown=md,
        live_name_pins={"sales": embedded},
        formats=["html", "pdf"],
        logical_id=report_logical_id(embedded_refs=[embedded], title="Q4 2025 review"),
    )

    ref, rel, etag, version = await persist_return_artifact(
        user_id=LOCAL_USER_ID,
        workspace_id=workspace_id,
        artifact=report,
        kind="report",
    )

    assert ref.kind == "report"
    assert rel.startswith(".ockham/reports/")
    assert rel.endswith(".qmd")

    body = await service.read_workspace_file_bytes(LOCAL_USER_ID, workspace_id, rel, allow_ockham=True)
    assert body is not None
    text = body.decode("utf-8")
    # YAML frontmatter under parsimony: namespace, then a blank line, then body.
    assert text.startswith("---\nparsimony:\n")
    # The persisted formats list survives the round-trip.
    assert "formats:" in text and "html" in text and "pdf" in text
    assert md in text

    cur = await read_curation(LOCAL_USER_ID, workspace_id, "report", report.logical_id)
    assert cur is not None
    assert cur.title == "Q4 2025 review"

    log = await read_log(LOCAL_USER_ID, workspace_id, "report", report.logical_id)
    assert len(log) == 1
    assert log[0].inputs["embedded"] == ["emb-csha"]
    assert log[0].inputs["formats"] == ["html", "pdf"]


async def test_persist_report_rejects_executable_fences(workspace_id: str) -> None:
    """The persist boundary runs the threat-surface validator (BRIEF §3)."""
    md = "# T\n\n```{python}\nimport os\nos.system('id')\n```\n"
    report = Report(
        title="bad",
        markdown=md,
        logical_id=report_logical_id(embedded_refs=[], title="bad"),
    )
    with pytest.raises(ValueError, match="executable Quarto"):
        await persist_return_artifact(
            user_id=LOCAL_USER_ID,
            workspace_id=workspace_id,
            artifact=report,
            kind="report",
        )


async def test_persist_report_format_list_in_log_inputs(workspace_id: str) -> None:
    """Format list participates in identity through ``content_sha`` and lands in log inputs."""
    report_html = Report(
        title="formats",
        markdown="# T\n\nx\n",
        formats=["html"],
        logical_id=report_logical_id(embedded_refs=[], title="formats"),
    )
    ref_html, _rel_html, _etag_html, _v_html = await persist_return_artifact(
        user_id=LOCAL_USER_ID,
        workspace_id=workspace_id,
        artifact=report_html,
        kind="report",
    )
    report_html_pdf = Report(
        title="formats",
        markdown="# T\n\nx\n",
        formats=["html", "pdf"],
        logical_id=report_logical_id(embedded_refs=[], title="formats"),
    )
    ref_html_pdf, _rel2, _etag2, _v2 = await persist_return_artifact(
        user_id=LOCAL_USER_ID,
        workspace_id=workspace_id,
        artifact=report_html_pdf,
        kind="report",
    )
    # Same logical_id (same title + embedded), but different content_sha
    # because the persisted formats line differs.
    assert ref_html.logical_id == ref_html_pdf.logical_id
    assert ref_html.content_sha != ref_html_pdf.content_sha

    log = await read_log(LOCAL_USER_ID, workspace_id, "report", report_html.logical_id)
    formats_in_log = [entry.inputs.get("formats") for entry in log]
    assert ["html"] in formats_in_log
    assert ["html", "pdf"] in formats_in_log


async def test_persist_dataset_records_variable_name_on_curation(workspace_id: str, tmp_path: Path) -> None:
    """R2: ``variable_name`` from the artifact lands on the curation sidecar."""
    df = pd.DataFrame({"x": [1]})
    nb_ref = _nb_ref("nb-csha")
    lid = dataset_logical_id(notebook_refs=[nb_ref], variable_name="gdp_df", source_refs=[])
    artifact = Dataset(
        title="GDP",
        notebook_refs=[nb_ref],
        logical_id=lid,
        variable_name="gdp_df",
    ).with_payload(DataFrameObject.from_pandas(df, local_dir=tmp_path / "_dfo"))

    await persist_return_artifact(
        user_id=LOCAL_USER_ID,
        workspace_id=workspace_id,
        artifact=artifact,
        kind="dataset",
    )
    cur = await read_curation(LOCAL_USER_ID, workspace_id, "dataset", lid)
    assert cur is not None
    assert cur.variable_name == "gdp_df"


async def test_persist_chart_records_variable_name_on_curation(
    workspace_id: str,
) -> None:
    """R2: chart curation carries ``variable_name`` after persist."""
    spec = {
        "$schema": "https://vega.github.io/schema/vega-lite/v5.json",
        "mark": "line",
    }
    nb_ref = _nb_ref("nb-csha")
    ds = _ds_ref()
    lid = chart_logical_id(
        notebook_ref=nb_ref,
        chart_variable_name="trend_chart",
        source_dataset_refs=[ds],
        source_refs=[],
    )
    chart = Chart(
        title="Trend",
        notebook_ref=nb_ref,
        source_dataset_refs=[ds],
        logical_id=lid,
        variable_name="trend_chart",
    ).with_payload(FigureObject(value=spec))

    await persist_return_artifact(
        user_id=LOCAL_USER_ID,
        workspace_id=workspace_id,
        artifact=chart,
        kind="chart",
    )
    cur = await read_curation(LOCAL_USER_ID, workspace_id, "chart", lid)
    assert cur is not None
    assert cur.variable_name == "trend_chart"


async def test_persist_report_curation_has_no_variable_name(
    workspace_id: str,
) -> None:
    """Reports don't carry ``variable_name`` (no kernel extraction step)."""
    md = "# r\n"
    report = Report(
        title="r",
        markdown=md,
        logical_id=report_logical_id(embedded_refs=[], title="r"),
    )
    await persist_return_artifact(
        user_id=LOCAL_USER_ID,
        workspace_id=workspace_id,
        artifact=report,
        kind="report",
    )
    cur = await read_curation(LOCAL_USER_ID, workspace_id, "report", report.logical_id)
    assert cur is not None
    assert cur.variable_name is None


async def test_persist_report_rejects_empty_markdown(workspace_id: str) -> None:
    report = Report(
        title="t",
        markdown="   \n",
        logical_id=report_logical_id(embedded_refs=[], title="t"),
    )
    with pytest.raises(ValueError, match="empty markdown"):
        await persist_return_artifact(
            user_id=LOCAL_USER_ID,
            workspace_id=workspace_id,
            artifact=report,
            kind="report",
        )
