"""Inline notebook pills must pin the immutable snapshot.

The historical bug: ``FileRefChunk.workspace_file_path`` used to be
the working-copy path (e.g. ``notebooks/foo.py``). Editing the notebook
later overwrote that path, so clicking a pill from message N opened
whatever content the notebook had at message N+M, destroying the chat's
record of which version that pill referred to.

This test pins the new contract: the chunk's ``workspace_file_path`` is
the content-addressed snapshot path under the notebook's live_name
(``.ockham/notebooks/<live_name>/<content_sha>.py``); ``name`` is the
``live_name`` used as the pill's human label; ``version`` is the
per-notebook ``v{N}``.
"""

from __future__ import annotations

from pathlib import Path

import pytest
from parsimony_agents.identity import notebook_content_sha
from parsimony_agents.notebook import ScriptPreview

from server.api.middleware import LOCAL_USER_ID
from server.api.streaming import PendingFileRef
from server.api.workspace import service
from server.api.workspace.streaming import _persist_pending_file_ref


@pytest.fixture
async def workspace_id(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> str:
    monkeypatch.setenv("OCKHAM_DATA_DIR", str(tmp_path))
    meta = await service.create_workspace(LOCAL_USER_ID, "streaming-notebook-pin")
    return meta.id


def _pending(*, code: str, working_copy: str = "notebooks/us_macro_data.py") -> PendingFileRef:
    return PendingFileRef(
        kind="notebook",
        payload=ScriptPreview(path=working_copy, code=code),
        message_id="msg-1",
        response_id="resp-1",
        completed=True,
        tool_name="return_notebook",
        also_executed=False,
    )


async def test_notebook_chunk_pins_snapshot_path(workspace_id: str) -> None:
    code = "import pandas as pd\nx = 1\n"
    csha = notebook_content_sha(code)
    chunk = await _persist_pending_file_ref(
        user_id=LOCAL_USER_ID,
        workspace_id=workspace_id,
        pending=_pending(code=code),
    )
    # The pill links to the immutable nested snapshot under the live_name.
    assert chunk.workspace_file_path == f".ockham/notebooks/us_macro_data/{csha}.py"
    # Display name comes from curation live_name (basename without ``.py``).
    assert chunk.name == "us_macro_data"
    # logical_id IS the live_name now (git-style, derived from path).
    assert chunk.logical_id == "us_macro_data"
    assert chunk.content_sha == csha


async def test_notebook_chunk_label_embeds_snapshot_path(workspace_id: str) -> None:
    """The label's ``file://./`` token is the inline pill's link target.

    If the token were the working copy path, clicking an old chat pill
    would open whatever the working copy is *now* — silently drifting
    to the latest edit. Pinning the label at the snapshot keeps history
    correct; the visual label stays human via ``displayName``/``version``
    on the pill itself.
    """
    code = "x = 1\n"
    chunk = await _persist_pending_file_ref(
        user_id=LOCAL_USER_ID,
        workspace_id=workspace_id,
        pending=_pending(code=code),
    )
    assert chunk.label is not None
    assert f"file://./{chunk.workspace_file_path}" in chunk.label
    # And critically: the working-copy path must NOT be embedded — that
    # would break history-correctness for the inline pill click target.
    assert "file://./notebooks/" not in chunk.label


async def test_notebook_chunk_carries_per_working_copy_version(workspace_id: str) -> None:
    """Editing the same working copy → v1 → v2; identical content → no bump."""
    c1 = await _persist_pending_file_ref(
        user_id=LOCAL_USER_ID,
        workspace_id=workspace_id,
        pending=_pending(code="x = 1\n"),
    )
    c2 = await _persist_pending_file_ref(
        user_id=LOCAL_USER_ID,
        workspace_id=workspace_id,
        pending=_pending(code="x = 2\n"),
    )
    c2_again = await _persist_pending_file_ref(
        user_id=LOCAL_USER_ID,
        workspace_id=workspace_id,
        pending=_pending(code="x = 2\n"),
    )
    assert c1.version == 1
    assert c2.version == 2
    assert c2_again.version == 2  # same content as c2 → same version


async def test_distinct_working_copies_have_independent_history(workspace_id: str) -> None:
    """Each working copy keeps its own version sequence."""
    a1 = await _persist_pending_file_ref(
        user_id=LOCAL_USER_ID,
        workspace_id=workspace_id,
        pending=_pending(code="x = 1\n", working_copy="notebooks/a.py"),
    )
    b1 = await _persist_pending_file_ref(
        user_id=LOCAL_USER_ID,
        workspace_id=workspace_id,
        pending=_pending(code="y = 2\n", working_copy="notebooks/b.py"),
    )
    assert a1.version == 1
    assert b1.version == 1


async def test_notebook_snapshot_is_readable_after_chunk_emission(workspace_id: str) -> None:
    """The snapshot the chunk points at must be reachable via the service layer."""
    code = "import x\n"
    chunk = await _persist_pending_file_ref(
        user_id=LOCAL_USER_ID,
        workspace_id=workspace_id,
        pending=_pending(code=code),
    )
    raw = await service.read_workspace_file_bytes(
        LOCAL_USER_ID, workspace_id, chunk.workspace_file_path, allow_ockham=True
    )
    assert raw is not None
    assert raw == b"import x\n"


async def test_rename_preserves_history_across_subsequent_edits(workspace_id: str) -> None:
    """Renaming a notebook via curation keeps the log continuous.

    The user's mental model: rename the file, history stays attached
    to the renamed file. This works because ``logical_id`` lives on
    the curation indirection layer — not on the on-disk path — so the
    next ``return_notebook`` under the new path resolves through curation
    back to the original ``logical_id`` and appends to the SAME log.
    """
    from server.api.workspace.snapshot_store import (
        Curation,
        read_curation,
        read_log,
        write_curation,
    )

    # 1. Initial creation under the original name → v1.
    c1 = await _persist_pending_file_ref(
        user_id=LOCAL_USER_ID,
        workspace_id=workspace_id,
        pending=_pending(code="x = 1\n", working_copy="notebooks/us_macro_data.py"),
    )
    assert c1.version == 1
    assert c1.logical_id == "us_macro_data"

    # 2. User renames via curation: live_name changes, logical_id stays.
    cur = await read_curation(LOCAL_USER_ID, workspace_id, "notebook", "us_macro_data")
    assert cur is not None
    renamed = Curation(
        kind="notebook",
        logical_id=cur.logical_id,
        title=cur.title,
        description=cur.description,
        tags=list(cur.tags),
        notes=list(cur.notes),
        live_name="consumer_prices",  # ← rename
    )
    await write_curation(LOCAL_USER_ID, workspace_id, "notebook", "us_macro_data", renamed)

    # 3. Agent edits the file under its new path → SAME logical_id,
    # next version (v2) on the same log.
    c2 = await _persist_pending_file_ref(
        user_id=LOCAL_USER_ID,
        workspace_id=workspace_id,
        pending=_pending(code="x = 2\n", working_copy="notebooks/consumer_prices.py"),
    )
    assert c2.logical_id == "us_macro_data"  # original slug preserved
    assert c2.version == 2  # log continues
    # Snapshot lives under the original directory.
    assert c2.workspace_file_path.startswith(".ockham/notebooks/us_macro_data/")

    # 4. The single shared log records both versions.
    entries = await read_log(LOCAL_USER_ID, workspace_id, "notebook", "us_macro_data")
    assert len(entries) == 2
