"""Pytest fixtures for server tests."""

from __future__ import annotations

from pathlib import Path

import pytest
from parsimony_agents.rag.embeddings import configure_embeddings


@pytest.fixture(autouse=True)
def _configure_embeddings() -> None:
    configure_embeddings(dimension=768)
    yield


@pytest.fixture(autouse=True)
def _isolate_ockham_dirs(tmp_path_factory: pytest.TempPathFactory, monkeypatch: pytest.MonkeyPatch):
    """Default OCKHAM_DATA_DIR/OCKHAM_CACHE_DIR to per-session tempdirs.

    Individual tests that override these env vars (via ``monkeypatch.setenv``)
    take precedence — pytest's monkeypatch undoes its own set first, so this
    autouse fixture's defaults reapply on tear-down. Prevents tests from
    leaking writes into ``~/.local/share/ockham`` or ``~/.cache/ockham`` on
    the developer's machine.
    """
    base: Path = tmp_path_factory.mktemp("ockham")
    monkeypatch.setenv("OCKHAM_DATA_DIR", str(base / "data"))
    monkeypatch.setenv("OCKHAM_CACHE_DIR", str(base / "cache"))
    yield
