"""Cross-terminal collision detection for ``resolve_notebook_logical_id``.

Strict mode (``seen_live_names`` provided) raises
:class:`LiveNameCollisionError` when the path's live_name matches a
curation the calling terminal has not interacted with. ``None`` skips
the gate to support host-side persist paths whose calling tool has
already validated.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from parsimony_agents.identity import LiveNameCollisionError

from server.api.workspace.notebook_identity import resolve_notebook_logical_id
from server.api.workspace.storage import workspace_local_tree_path


def _seed_notebook_curation(workspace_root: Path, *, lid: str, live_name: str) -> None:
    """Materialise ``.ockham/notebooks/<lid>/curation.json`` under root."""
    entry = workspace_root / ".ockham" / "notebooks" / lid
    entry.mkdir(parents=True)
    (entry / "curation.json").write_text(json.dumps({"kind": "notebook", "logical_id": lid, "live_name": live_name}))


@pytest.mark.asyncio
async def test_empty_seen_raises_on_existing_live_name(tmp_path, monkeypatch):
    monkeypatch.setenv("OCKHAM_DATA_DIR", str(tmp_path))
    root = workspace_local_tree_path("u", "ws")
    root.mkdir(parents=True, exist_ok=True)
    _seed_notebook_curation(root, lid="us_gdp", live_name="us_gdp")

    with pytest.raises(LiveNameCollisionError) as info:
        await resolve_notebook_logical_id("u", "ws", "notebooks/us_gdp.py", seen_live_names=set())
    assert info.value.existing_logical_id == "us_gdp"
    assert info.value.kind == "notebook"
    assert "read_artifact(live_name='us_gdp', kind='notebook')" in str(info.value)


@pytest.mark.asyncio
async def test_seen_includes_pair_returns_lid(tmp_path, monkeypatch):
    monkeypatch.setenv("OCKHAM_DATA_DIR", str(tmp_path))
    root = workspace_local_tree_path("u", "ws")
    root.mkdir(parents=True, exist_ok=True)
    _seed_notebook_curation(root, lid="us_gdp", live_name="us_gdp")

    lid = await resolve_notebook_logical_id(
        "u",
        "ws",
        "notebooks/us_gdp.py",
        seen_live_names={("notebook", "us_gdp")},
    )
    assert lid == "us_gdp"


@pytest.mark.asyncio
async def test_unrelated_seen_still_raises(tmp_path, monkeypatch):
    monkeypatch.setenv("OCKHAM_DATA_DIR", str(tmp_path))
    root = workspace_local_tree_path("u", "ws")
    root.mkdir(parents=True, exist_ok=True)
    _seed_notebook_curation(root, lid="us_gdp", live_name="us_gdp")

    with pytest.raises(LiveNameCollisionError):
        await resolve_notebook_logical_id(
            "u",
            "ws",
            "notebooks/us_gdp.py",
            seen_live_names={
                ("notebook", "other_nb"),
                ("dataset", "us_gdp"),
            },
        )


@pytest.mark.asyncio
async def test_fresh_path_returns_slug_with_empty_seen(tmp_path, monkeypatch):
    """No matching curation ⇒ resolver returns the fresh slug, no raise."""
    monkeypatch.setenv("OCKHAM_DATA_DIR", str(tmp_path))
    root = workspace_local_tree_path("u", "ws")
    root.mkdir(parents=True, exist_ok=True)

    lid = await resolve_notebook_logical_id("u", "ws", "notebooks/brand_new.py", seen_live_names=set())
    assert lid == "brand_new"


@pytest.mark.asyncio
async def test_none_seen_preserves_silent_merge(tmp_path, monkeypatch):
    """seen_live_names=None ⇒ legacy semantic: existing lid returned silently.

    This keeps host-side persist paths (which already validated upstream)
    working without re-running the gate.
    """
    monkeypatch.setenv("OCKHAM_DATA_DIR", str(tmp_path))
    root = workspace_local_tree_path("u", "ws")
    root.mkdir(parents=True, exist_ok=True)
    _seed_notebook_curation(root, lid="us_gdp", live_name="us_gdp")

    lid = await resolve_notebook_logical_id("u", "ws", "notebooks/us_gdp.py", seen_live_names=None)
    assert lid == "us_gdp"


@pytest.mark.asyncio
async def test_post_rename_collision_with_seen_set_works(tmp_path, monkeypatch):
    """Renaming a notebook should not be blocked by the gate.

    Curation's live_name was renamed to ``us_gdp_v2`` while ``logical_id``
    stays ``us_gdp``. The agent's next return_notebook at the new path
    should resolve to ``us_gdp`` as long as the seen-set carries the new
    pair.
    """
    monkeypatch.setenv("OCKHAM_DATA_DIR", str(tmp_path))
    root = workspace_local_tree_path("u", "ws")
    root.mkdir(parents=True, exist_ok=True)
    _seed_notebook_curation(root, lid="us_gdp", live_name="us_gdp_v2")

    lid = await resolve_notebook_logical_id(
        "u",
        "ws",
        "notebooks/us_gdp_v2.py",
        seen_live_names={("notebook", "us_gdp_v2")},
    )
    assert lid == "us_gdp"
