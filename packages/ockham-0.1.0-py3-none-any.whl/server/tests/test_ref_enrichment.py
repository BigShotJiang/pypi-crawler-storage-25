"""Tests for typed-ref enrichment with human display names."""

from __future__ import annotations

from pathlib import Path

import pytest
from parsimony_agents.identity import notebook_content_sha

from server.api.middleware import LOCAL_USER_ID
from server.api.workspace import service
from server.api.workspace.ref_enrichment import (
    enrich_artifact_envelope,
    enrich_ref_dict,
)
from server.api.workspace.snapshot_store import (
    Curation,
    DataObjectCuration,
    LogEntry,
    append_log,
    write_curation,
)


@pytest.fixture
async def workspace_id(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> str:
    monkeypatch.setenv("OCKHAM_DATA_DIR", str(tmp_path))
    meta = await service.create_workspace(LOCAL_USER_ID, "ref-enrichment")
    return meta.id


async def test_dataset_ref_display_name_from_curation(workspace_id: str) -> None:
    """dataset/chart/report refs surface ``curation.title`` as the display name."""
    lid = "ds-lid"
    await write_curation(
        LOCAL_USER_ID,
        workspace_id,
        "dataset",
        lid,
        Curation(kind="dataset", logical_id=lid, title="US CPI", live_name="us_cpi"),
    )
    enriched = await enrich_ref_dict(
        {"kind": "dataset", "logical_id": lid, "content_sha": "csha"},
        user_id=LOCAL_USER_ID,
        workspace_id=workspace_id,
    )
    assert enriched["display_name"] == "US CPI"
    assert enriched["workspace_file_path"] == f".ockham/datasets/{lid}/csha.parquet"


async def test_data_object_ref_display_name_from_curation(workspace_id: str) -> None:
    """data_object refs render as ``source(key=val, …)`` from the curation sidecar.

    The sidecar mirrors the provenance the connector embedded in arrow
    metadata — same fields, same label. Ref enrichment never opens the
    parquet under the unified curation model.
    """
    lid = "do-lid"
    csha = "do-csha"
    rel = f".ockham/data_objects/{lid}/{csha}.parquet"
    await write_curation(
        LOCAL_USER_ID,
        workspace_id,
        "data_object",
        lid,
        DataObjectCuration(
            logical_id=lid,
            source="fred_fetch",
            source_description="FRED",
            params={"series_id": "GDPC1", "observation_start": "2010-01-01"},
        ),
    )
    enriched = await enrich_ref_dict(
        {"kind": "data_object", "logical_id": lid, "content_sha": csha},
        user_id=LOCAL_USER_ID,
        workspace_id=workspace_id,
    )
    assert enriched["display_name"] is not None
    label = enriched["display_name"]
    assert label.startswith("fred_fetch(")
    assert "series_id=GDPC1" in label
    assert enriched["workspace_file_path"] == rel


async def test_data_object_ref_no_parquet_read_required(workspace_id: str, monkeypatch: pytest.MonkeyPatch) -> None:
    """Display-name resolution must not open the parquet — sidecar is the path.

    Regression guard: pre-unification, the resolver did an async parquet
    read on every ref enrichment. With the curation sidecar it's a sync
    JSON read. Patch ``read_workspace_file_bytes`` to fail loudly on any
    parquet path; if the sidecar path is the only one read, the test
    passes.
    """
    lid = "do-lid"
    csha = "do-csha"
    await write_curation(
        LOCAL_USER_ID,
        workspace_id,
        "data_object",
        lid,
        DataObjectCuration(logical_id=lid, source="fred_fetch", params={"x": "y"}),
    )

    from server.api.workspace import snapshot_store

    real = snapshot_store.read_workspace_file_bytes

    async def _no_parquet(user_id: str, workspace_id: str, rel: str, *, allow_ockham: bool = False) -> bytes | None:
        assert not rel.endswith(".parquet"), f"unexpected parquet read: {rel}"
        return await real(user_id, workspace_id, rel, allow_ockham=allow_ockham)

    monkeypatch.setattr(snapshot_store, "read_workspace_file_bytes", _no_parquet)

    enriched = await enrich_ref_dict(
        {"kind": "data_object", "logical_id": lid, "content_sha": csha},
        user_id=LOCAL_USER_ID,
        workspace_id=workspace_id,
    )
    assert enriched["display_name"] is not None
    assert enriched["display_name"].startswith("fred_fetch(")


async def test_notebook_ref_display_name_from_curation(workspace_id: str) -> None:
    """notebook refs surface ``curation.title`` (or ``live_name``) — same path as datasets/charts/reports."""
    lid = "uuid-fred"
    await write_curation(
        LOCAL_USER_ID,
        workspace_id,
        "notebook",
        lid,
        Curation(kind="notebook", logical_id=lid, live_name="us_macro_data"),
    )
    enriched = await enrich_ref_dict(
        {"kind": "notebook", "logical_id": lid, "content_sha": "csha"},
        user_id=LOCAL_USER_ID,
        workspace_id=workspace_id,
    )
    # No title set → falls back to live_name. Same behaviour as
    # dataset/chart/report when curation has no title yet.
    assert enriched["display_name"] == "us_macro_data"


async def test_notebook_ref_display_name_none_without_curation(workspace_id: str) -> None:
    """A notebook without curation gets display_name=None (frontend falls back to basename)."""
    enriched = await enrich_ref_dict(
        {"kind": "notebook", "logical_id": "no-curation-uuid", "content_sha": "csha"},
        user_id=LOCAL_USER_ID,
        workspace_id=workspace_id,
    )
    assert enriched["display_name"] is None


async def test_enrich_artifact_envelope_walks_all_ref_fields(workspace_id: str) -> None:
    """The walker enriches notebook_refs, source_refs, source_dataset_refs, notebook_ref."""
    nb_csha = notebook_content_sha("import pandas as pd\n")
    nb_lid = "uuid-macro"
    await write_curation(
        LOCAL_USER_ID,
        workspace_id,
        "notebook",
        nb_lid,
        Curation(kind="notebook", logical_id=nb_lid, live_name="us_macro"),
    )
    await write_curation(
        LOCAL_USER_ID,
        workspace_id,
        "dataset",
        "ds-lid",
        Curation(kind="dataset", logical_id="ds-lid", title="Upstream Dataset"),
    )
    payload = {
        "artifact": {
            "notebook_refs": [{"kind": "notebook", "logical_id": nb_lid, "content_sha": nb_csha}],
            "source_refs": [{"kind": "dataset", "logical_id": "ds-lid", "content_sha": "ds-csha"}],
            "notebook_ref": {
                "kind": "notebook",
                "logical_id": nb_lid,
                "content_sha": nb_csha,
            },
            "source_dataset_refs": [{"kind": "dataset", "logical_id": "ds-lid", "content_sha": "ds-csha"}],
        }
    }
    enriched = await enrich_artifact_envelope(payload, user_id=LOCAL_USER_ID, workspace_id=workspace_id)
    a = enriched["artifact"]
    assert a["notebook_refs"][0]["display_name"] == "us_macro"
    assert a["notebook_refs"][0]["workspace_file_path"] == f".ockham/notebooks/{nb_lid}/{nb_csha}.py"
    assert a["source_refs"][0]["display_name"] == "Upstream Dataset"
    assert a["notebook_ref"]["display_name"] == "us_macro"
    assert a["source_dataset_refs"][0]["display_name"] == "Upstream Dataset"


async def test_enrich_swallows_missing_files(workspace_id: str) -> None:
    """Refs whose backing files are missing get display_name=None, not an exception."""
    enriched = await enrich_ref_dict(
        {"kind": "data_object", "logical_id": "missing", "content_sha": "missing"},
        user_id=LOCAL_USER_ID,
        workspace_id=workspace_id,
    )
    assert enriched["display_name"] is None
    assert enriched["workspace_file_path"] == ".ockham/data_objects/missing/missing.parquet"


# ---------------------------------------------------------------------------
# version resolver
# ---------------------------------------------------------------------------


async def test_version_reflects_log_jsonl_position(workspace_id: str) -> None:
    """``version`` is the 1-based index of ``content_sha`` in ``log.jsonl``."""
    lid = "ds-versioned"
    await append_log(
        LOCAL_USER_ID,
        workspace_id,
        "dataset",
        lid,
        LogEntry(ts="2026-01-01T00:00:00Z", content_sha="cA"),
    )
    await append_log(
        LOCAL_USER_ID,
        workspace_id,
        "dataset",
        lid,
        LogEntry(ts="2026-02-01T00:00:00Z", content_sha="cB"),
    )
    await append_log(
        LOCAL_USER_ID,
        workspace_id,
        "dataset",
        lid,
        LogEntry(ts="2026-03-01T00:00:00Z", content_sha="cC"),
    )

    for csha, expected in [("cA", 1), ("cB", 2), ("cC", 3)]:
        enriched = await enrich_ref_dict(
            {"kind": "dataset", "logical_id": lid, "content_sha": csha},
            user_id=LOCAL_USER_ID,
            workspace_id=workspace_id,
        )
        assert enriched["version"] == expected, csha


async def test_version_none_when_log_missing(workspace_id: str) -> None:
    """No log on disk → version is None (graceful fallback, no exception)."""
    enriched = await enrich_ref_dict(
        {"kind": "dataset", "logical_id": "never-published", "content_sha": "csha"},
        user_id=LOCAL_USER_ID,
        workspace_id=workspace_id,
    )
    assert enriched["version"] is None


async def test_version_none_when_content_sha_not_in_log(workspace_id: str) -> None:
    """Querying a content_sha that isn't in the log returns None (mid-write race / pre-feature replay)."""
    lid = "ds"
    await append_log(
        LOCAL_USER_ID,
        workspace_id,
        "dataset",
        lid,
        LogEntry(ts="2026-01-01T00:00:00Z", content_sha="known"),
    )
    enriched = await enrich_ref_dict(
        {"kind": "dataset", "logical_id": lid, "content_sha": "unknown"},
        user_id=LOCAL_USER_ID,
        workspace_id=workspace_id,
    )
    assert enriched["version"] is None


async def test_data_object_and_notebook_refs_have_no_version(workspace_id: str) -> None:
    """Kinds without a per-logical_id log return version=None by design."""
    do = await enrich_ref_dict(
        {"kind": "data_object", "logical_id": "lid", "content_sha": "csha"},
        user_id=LOCAL_USER_ID,
        workspace_id=workspace_id,
    )
    nb = await enrich_ref_dict(
        {"kind": "notebook", "logical_id": "abc", "content_sha": "abc"},
        user_id=LOCAL_USER_ID,
        workspace_id=workspace_id,
    )
    assert do["version"] is None
    assert nb["version"] is None


async def test_envelope_carries_artifact_own_version(workspace_id: str) -> None:
    """The artifact being viewed must surface its own version, not just its refs.

    Most upstream refs in a typical dataset are notebooks / data_objects (no
    log → version=None); without this, the panel shows no version anywhere
    even though the dataset itself has a clean v{N} index.
    """
    lid = "ds-lid"
    csha_v1 = "csha-v1"
    csha_v2 = "csha-v2"
    await append_log(
        LOCAL_USER_ID,
        workspace_id,
        "dataset",
        lid,
        LogEntry(ts="2026-01-01T00:00:00Z", content_sha=csha_v1),
    )
    await append_log(
        LOCAL_USER_ID,
        workspace_id,
        "dataset",
        lid,
        LogEntry(ts="2026-02-01T00:00:00Z", content_sha=csha_v2),
    )

    payload = {
        "kind": "dataset",
        "artifact": {"logical_id": lid, "content_sha": csha_v2},
    }
    enriched = await enrich_artifact_envelope(payload, user_id=LOCAL_USER_ID, workspace_id=workspace_id)
    assert enriched["artifact"]["version"] == 2

    # Earlier snapshot of the same logical artifact resolves to v1.
    payload_v1 = {
        "kind": "dataset",
        "artifact": {"logical_id": lid, "content_sha": csha_v1},
    }
    enriched_v1 = await enrich_artifact_envelope(payload_v1, user_id=LOCAL_USER_ID, workspace_id=workspace_id)
    assert enriched_v1["artifact"]["version"] == 1


async def test_envelope_version_is_none_for_kinds_without_log() -> None:
    """data_object / non-curated payloads don't have an envelope version."""
    # data_object payloads carry ``provenance``, not ``artifact`` — no envelope to enrich.
    # Verify that the walker quietly does nothing rather than synthesizing a version.
    payload = {
        "kind": "data_object",
        "provenance": {"source": "fred_fetch", "params": {}},
    }
    out = await enrich_artifact_envelope(payload, user_id=LOCAL_USER_ID, workspace_id="any")
    assert "version" not in out  # untouched payload


async def test_data_object_envelope_overlays_fetched_at_from_curation(
    workspace_id: str,
) -> None:
    """data_object viewer wires ``fetched_at`` through from the curation sidecar.

    The connector persister strips ``fetched_at`` from the parquet for
    content-addressing dedup, so the parquet read leaves it ``None`` on
    the wire. The curation sidecar carries the canonical fetch time;
    ``enrich_artifact_envelope`` overlays it onto ``payload['provenance']``
    when the canonical path is supplied.
    """
    lid = "do-lid"
    csha = "do-csha"
    rel = f".ockham/data_objects/{lid}/{csha}.parquet"
    await write_curation(
        LOCAL_USER_ID,
        workspace_id,
        "data_object",
        lid,
        DataObjectCuration(
            logical_id=lid,
            source="fred_fetch",
            source_description="FRED",
            params={"series_id": "GDPC1"},
            fetched_at="2026-05-09T12:34:56Z",
            properties={"x": 1},
        ),
    )
    payload = {
        "kind": "data_object",
        "provenance": {
            "source": "fred_fetch",
            "source_description": "",
            "params": {"series_id": "GDPC1"},
            "fetched_at": None,  # stripped by _canonicalize_arrow_table
            "properties": {},
        },
        "payload": {"row_count": 0, "schema": [], "rows": []},
    }
    enriched = await enrich_artifact_envelope(payload, user_id=LOCAL_USER_ID, workspace_id=workspace_id, path=rel)
    prov = enriched["provenance"]
    assert prov["fetched_at"] == "2026-05-09T12:34:56Z"
    assert prov["source"] == "fred_fetch"
    assert prov["source_description"] == "FRED"
    assert prov["params"] == {"series_id": "GDPC1"}
    assert prov["properties"] == {"x": 1}


async def test_data_object_envelope_overlay_no_path_is_noop(
    workspace_id: str,
) -> None:
    """Without ``path``, the overlay can't resolve the ref; payload is unchanged."""
    payload = {
        "kind": "data_object",
        "provenance": {
            "source": "fred_fetch",
            "fetched_at": None,
            "params": {},
            "properties": {},
            "source_description": "",
        },
    }
    out = await enrich_artifact_envelope(payload, user_id=LOCAL_USER_ID, workspace_id=workspace_id)
    assert out["provenance"]["fetched_at"] is None


async def test_data_object_envelope_overlay_missing_sidecar_is_noop(
    workspace_id: str,
) -> None:
    """Path present but no sidecar on disk: leave the wire provenance as-is."""
    rel = ".ockham/data_objects/missing-lid/missing-csha.parquet"
    payload = {
        "kind": "data_object",
        "provenance": {
            "source": "fred_fetch",
            "fetched_at": None,
            "params": {},
            "properties": {},
            "source_description": "",
        },
    }
    out = await enrich_artifact_envelope(payload, user_id=LOCAL_USER_ID, workspace_id=workspace_id, path=rel)
    assert out["provenance"]["fetched_at"] is None
    assert out["provenance"]["source"] == "fred_fetch"
