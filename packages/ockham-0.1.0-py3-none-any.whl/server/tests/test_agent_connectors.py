"""Tests for the single ``connectors`` bundle exposed to agent code.

These are the regression tests that would have caught the FRED-missing
incident: with `parsimony-fred` not installed, `fred_fetch` would be
absent from the bundle and ``test_shipped_providers_are_actually_installed``
would fail loudly at CI time instead of silently in production.
"""

from __future__ import annotations

from parsimony.connector import Connectors

from server.connectors import build_agent_connectors

# Provide stubs for every env var declared by any installed connector so the
# build returns a non-trivial bundle without hitting the network. Connectors
# whose required env vars are missing simply skip binding; that's fine for
# these tests — we assert on connector *presence*, not on bound credentials.
_ENV = {
    "FRED_API_KEY": "stub",
    "FMP_API_KEY": "stub",
    "EODHD_API_KEY": "stub",
    "FINANCIAL_REPORTS_API_KEY": "stub",
    "TIINGO_API_KEY": "stub",
    "FINNHUB_API_KEY": "stub",
    "EIA_API_KEY": "stub",
}


# Names every shipped provider must contribute. Picked to cover each
# `parsimony-*` package in `pyproject.toml`; if a package gets removed or
# renamed, this list should be updated in the same change.
_EXPECTED_CONNECTORS = frozenset(
    {
        "fred_search",
        "fred_fetch",
        "sdmx_fetch",
        "fmp_search",
        "fmp_quotes",
        "eodhd_search",
        "fr_filings_search",
        "tiingo_search",
        "finnhub_search",
        "coingecko_search",
        "treasury_fetch",
        "eia_fetch",
        "sec_edgar_find_company",
    }
)


def test_build_agent_connectors_exposes_single_connectors_bundle() -> None:
    bundles = build_agent_connectors(env=_ENV)
    assert set(bundles) == {"connectors"}
    assert isinstance(bundles["connectors"], Connectors)


def test_shipped_providers_are_actually_installed() -> None:
    """Fails loudly if any `parsimony-*` package is missing from pyproject.toml.

    This is the test that would have caught the FRED regression: with FRED
    not installed, `fred_fetch` would not be in the bundle and this fails.
    """
    bundles = build_agent_connectors(env=_ENV)
    names = {c.name for c in bundles["connectors"]}
    missing = _EXPECTED_CONNECTORS - names
    assert not missing, f"Missing connectors (provider package not installed?): {sorted(missing)}"


def test_loaders_and_enumerators_are_filtered_out() -> None:
    """Catalog-build hooks are not runtime tools — they must not leak in."""
    bundles = build_agent_connectors(env=_ENV)
    for conn in bundles["connectors"]:
        assert "enumerator" not in conn.tags, f"{conn.name} (enumerator) leaked into the connectors bundle"
        assert "loader" not in conn.tags, f"{conn.name} (loader) leaked into the connectors bundle"
