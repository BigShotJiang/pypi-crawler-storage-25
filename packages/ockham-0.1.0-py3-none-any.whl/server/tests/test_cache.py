import asyncio
import os
from pathlib import Path

import pandas as pd
import pytest
from parsimony_agents.execution.dataframe_ref import set_default_backend, set_default_local_root

from server.core.cache import DataframeRef, InMemoryCache, configure_default_dataframe_storage
from server.storage import sessions_dir


@pytest.mark.asyncio
async def test_in_memory_cache_redis_interface():
    """Test InMemoryCache implements Redis-compatible hash ops and incr."""
    cache = InMemoryCache()

    n = await cache.incr("counter")
    assert n == 1
    n = await cache.incr("counter")
    assert n == 2
    await cache.expire("counter", 60)

    await cache.hset_multi_expire("h1", {"a": "1", "b": "2"}, ttl_seconds=60)
    assert await cache.hget("h1", "a") == "1"
    assert await cache.hmget("h1", "a", "b") == ["1", "2"]
    assert await cache.hgetall("h1") == {"a": "1", "b": "2"}

    await cache.hset("h1", "c", "3")
    assert await cache.hget("h1", "c") == "3"

    await cache.hdel("h1", "a")
    assert await cache.hget("h1", "a") is None
    assert await cache.hget("h1", "b") == "2"

    await cache.set("k", "v", ttl=0)
    assert await cache.get("k") == "v"
    await cache.delete("k")
    assert await cache.get("k") is None


@pytest.mark.asyncio
async def test_in_memory_cache_expiry_semantics():
    cache = InMemoryCache()

    await cache.set("ttl-key", "value", ttl=1)
    assert await cache.get("ttl-key") == "value"
    await asyncio.sleep(1.1)
    assert await cache.get("ttl-key") is None

    await cache.hset_multi_expire("ttl-hash", {"a": "1"}, ttl_seconds=1)
    assert await cache.hget("ttl-hash", "a") == "1"
    await asyncio.sleep(1.1)
    assert await cache.hget("ttl-hash", "a") is None


@pytest.fixture
def temp_session_dir(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    """Point the cache root at *tmp_path* so session files land in a tempdir."""
    monkeypatch.setenv("OCKHAM_CACHE_DIR", str(tmp_path))
    configure_default_dataframe_storage()
    yield sessions_dir()
    set_default_backend(None)
    set_default_local_root(None)


@pytest.mark.asyncio
async def test_dataframe_ref_lifecycle_local_only(temp_session_dir: Path):
    """DataframeRef writes parquet locally; no remote key when backend is not configured."""
    df = pd.DataFrame({"a": [1, 2, 3], "b": ["x", "y", "z"]})
    ref_name = "test_session"

    ref = DataframeRef.from_pandas(df, ref=ref_name, persist=True)
    local_path = Path(ref.local_path)

    assert ref.ref == ref_name
    assert ref.remote_key is None
    assert ref.s3_key is None
    assert ref.is_ephemeral
    assert local_path.exists()

    df_loaded = await ref.materialize()
    pd.testing.assert_frame_equal(df, df_loaded)

    os.remove(local_path)
    with pytest.raises(ValueError, match="Ephemeral dataframe .* missing from local cache"):
        await ref.materialize()


@pytest.mark.asyncio
async def test_ephemeral_dataframe(temp_session_dir: Path):
    """Non-persisted path still writes a local parquet (app uses backend=None always)."""
    df = pd.DataFrame({"data": [10, 20]})
    ref = DataframeRef.from_pandas(df, persist=False)
    local_path = Path(ref.local_path)

    assert ref.remote_key is None
    assert ref.is_ephemeral
    assert local_path.exists()

    df_loaded = await ref.materialize()
    pd.testing.assert_frame_equal(df, df_loaded)

    os.remove(local_path)
    with pytest.raises(ValueError, match="Ephemeral dataframe .* missing from local cache"):
        await ref.materialize()


@pytest.mark.asyncio
async def test_series_support(temp_session_dir: Path):
    series = pd.Series([1, 2, 3], name="my_series")
    ref = DataframeRef.from_pandas(series, persist=False)

    df_loaded = await ref.materialize()
    assert isinstance(df_loaded, pd.DataFrame)
    assert "my_series" in df_loaded.columns
    pd.testing.assert_series_equal(series, df_loaded["my_series"])


@pytest.mark.asyncio
async def test_stable_hashing(temp_session_dir: Path):
    df1 = pd.DataFrame({"a": [1, 2], "b": [3, 4]})
    df2 = pd.DataFrame({"a": [1, 2], "b": [3, 4]})
    df3 = pd.DataFrame({"a": [1, 2], "b": [3, 5]})

    ref1 = DataframeRef.from_pandas(df1, persist=False)
    ref2 = DataframeRef.from_pandas(df2, persist=False)
    ref3 = DataframeRef.from_pandas(df3, persist=False)

    assert ref1.content_hash == ref2.content_hash
    assert ref1.content_hash != ref3.content_hash


@pytest.mark.asyncio
async def test_corrupt_cache_no_remote_heal(temp_session_dir: Path):
    """Corrupt local file cannot be healed without a remote key and backend."""
    df = pd.DataFrame({"a": [1]})
    ref = DataframeRef.from_pandas(df, ref="s1", persist=True)
    local_path = Path(ref.local_path)

    local_path.write_text("not a parquet file", encoding="utf-8")
    with pytest.raises(ValueError, match="Ephemeral dataframe .* missing from local cache"):
        await ref.materialize()
