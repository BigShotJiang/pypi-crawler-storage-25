"""Tests for the kind-agnostic snapshot store primitives."""

from __future__ import annotations

import asyncio
from pathlib import Path

import pytest
from parsimony_agents.identity import ArtifactRef

from server.api.workspace import service
from server.api.workspace.snapshot_store import (
    Curation,
    DataObjectCuration,
    LogEntry,
    append_log,
    curation_path,
    latest_content_sha,
    log_path,
    read_curation,
    read_log,
    read_snapshot,
    snapshot_dir,
    write_curation,
    write_snapshot,
)

USER = "test-user"


@pytest.fixture
async def workspace_id(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> str:
    monkeypatch.setenv("OCKHAM_DATA_DIR", str(tmp_path))
    meta = await service.create_workspace(USER, "snapshot-store-tests")
    return meta.id


# ---------------------------------------------------------------------------
# Path helpers
# ---------------------------------------------------------------------------


def test_snapshot_dir_per_kind() -> None:
    """One nested layout for every kind (notebooks no longer special-case flat)."""
    assert snapshot_dir("notebook", "lid") == ".ockham/notebooks/lid"
    assert snapshot_dir("data_object", "lid") == ".ockham/data_objects/lid"
    assert snapshot_dir("dataset", "lid") == ".ockham/datasets/lid"
    assert snapshot_dir("chart", "lid") == ".ockham/charts/lid"
    assert snapshot_dir("report", "lid") == ".ockham/reports/lid"


def test_curation_path_uniform_across_kinds() -> None:
    """Every kind has a curation sidecar under the unified layout.

    Schema differs by kind: data_object carries a frozen provenance
    record (:class:`DataObjectCuration`); the other four kinds carry
    user-editable curation (:class:`Curation`). The on-disk path is
    the same shape regardless.
    """
    assert curation_path("notebook", "lid") == ".ockham/notebooks/lid/curation.json"
    assert curation_path("data_object", "lid") == ".ockham/data_objects/lid/curation.json"
    assert curation_path("dataset", "lid") == ".ockham/datasets/lid/curation.json"
    assert curation_path("chart", "lid") == ".ockham/charts/lid/curation.json"
    assert curation_path("report", "lid") == ".ockham/reports/lid/curation.json"


def test_log_path_uniform_across_kinds() -> None:
    """Every kind has a per-logical_id log now (notebook joins the rule)."""
    assert log_path("notebook", "lid") == ".ockham/notebooks/lid/log.jsonl"
    assert log_path("data_object", "lid") == ".ockham/data_objects/lid/log.jsonl"
    assert log_path("dataset", "lid") == ".ockham/datasets/lid/log.jsonl"
    assert log_path("chart", "lid") == ".ockham/charts/lid/log.jsonl"
    assert log_path("report", "lid") == ".ockham/reports/lid/log.jsonl"


# ---------------------------------------------------------------------------
# Snapshot bytes
# ---------------------------------------------------------------------------


async def test_write_snapshot_round_trip(workspace_id: str) -> None:
    ref = ArtifactRef(kind="dataset", logical_id="lid", content_sha="csha")
    await write_snapshot(USER, workspace_id, ref, b"hello")
    out = await read_snapshot(USER, workspace_id, ref)
    assert out == b"hello"


async def test_write_snapshot_idempotent(workspace_id: str) -> None:
    ref = ArtifactRef(kind="chart", logical_id="lid", content_sha="csha")
    await write_snapshot(USER, workspace_id, ref, b"first")
    # Second write with different bytes is a no-op (content-addressed:
    # same content_sha implies same bytes — caller error otherwise).
    await write_snapshot(USER, workspace_id, ref, b"second-ignored")
    assert await read_snapshot(USER, workspace_id, ref) == b"first"


async def test_read_snapshot_missing_returns_none(workspace_id: str) -> None:
    ref = ArtifactRef(kind="dataset", logical_id="missing", content_sha="csha")
    assert await read_snapshot(USER, workspace_id, ref) is None


# ---------------------------------------------------------------------------
# Curation
# ---------------------------------------------------------------------------


async def test_curation_round_trip_sets_timestamps(workspace_id: str) -> None:
    cur = Curation(kind="dataset", logical_id="lid", title="A title")
    await write_curation(USER, workspace_id, "dataset", "lid", cur)
    got = await read_curation(USER, workspace_id, "dataset", "lid")
    assert got is not None
    assert got.title == "A title"
    assert got.created_at != ""
    assert got.updated_at != ""


async def test_curation_update_preserves_created_at(workspace_id: str) -> None:
    cur = Curation(kind="dataset", logical_id="lid", title="v1")
    await write_curation(USER, workspace_id, "dataset", "lid", cur)
    first = await read_curation(USER, workspace_id, "dataset", "lid")
    await asyncio.sleep(0.01)  # ensure timestamps could differ at second resolution
    cur2 = Curation(kind="dataset", logical_id="lid", title="v2")
    await write_curation(USER, workspace_id, "dataset", "lid", cur2)
    second = await read_curation(USER, workspace_id, "dataset", "lid")
    assert first is not None and second is not None
    assert first.created_at == second.created_at
    assert second.title == "v2"


async def test_curation_mismatch_kind_raises(workspace_id: str) -> None:
    cur = Curation(kind="chart", logical_id="lid")
    with pytest.raises(ValueError):
        await write_curation(USER, workspace_id, "dataset", "lid", cur)


async def test_read_curation_missing_returns_none(workspace_id: str) -> None:
    got = await read_curation(USER, workspace_id, "dataset", "missing")
    assert got is None


async def test_data_object_curation_round_trip(workspace_id: str) -> None:
    """data_object curation carries provenance, not user-facing fields.

    Stored at the same path layout (``.ockham/data_objects/<lid>/curation.json``)
    but validated as :class:`DataObjectCuration` on load — never confused
    with a named-artifact :class:`Curation`.
    """
    cur = DataObjectCuration(
        logical_id="do-lid",
        source="fred_fetch",
        source_description="FRED",
        params={"series_id": "GDPC1"},
        properties={"row_count": 10},
    )
    await write_curation(USER, workspace_id, "data_object", "do-lid", cur)
    got = await read_curation(USER, workspace_id, "data_object", "do-lid")
    assert isinstance(got, DataObjectCuration)
    assert got.source == "fred_fetch"
    assert got.params == {"series_id": "GDPC1"}
    assert got.created_at != "" and got.updated_at != ""


async def test_write_curation_rejects_kind_mismatch(workspace_id: str) -> None:
    """Passing a Curation for data_object (or vice versa) is a hard error."""
    nb_cur = Curation(kind="dataset", logical_id="lid", title="x")
    with pytest.raises(ValueError):
        await write_curation(USER, workspace_id, "data_object", "lid", nb_cur)
    do_cur = DataObjectCuration(logical_id="lid", source="x")
    with pytest.raises(ValueError):
        await write_curation(USER, workspace_id, "dataset", "lid", do_cur)


# ---------------------------------------------------------------------------
# Log
# ---------------------------------------------------------------------------


async def test_log_dedupe_on_same_content_sha(workspace_id: str) -> None:
    """Same content_sha → no new entry; both calls return the same version."""
    e1 = LogEntry(ts="2026-01-01T00:00:00Z", content_sha="csha", inputs={})
    e2 = LogEntry(ts="2026-02-01T00:00:00Z", content_sha="csha", inputs={"foo": "bar"})
    v1 = await append_log(USER, workspace_id, "dataset", "lid", e1)
    v2 = await append_log(USER, workspace_id, "dataset", "lid", e2)
    assert v1 == 1
    assert v2 == 1  # identical content republish — version unchanged
    entries = await read_log(USER, workspace_id, "dataset", "lid")
    assert len(entries) == 1
    assert entries[0].content_sha == "csha"


async def test_log_returns_monotonic_version_for_distinct_content(workspace_id: str) -> None:
    """Each new content_sha gets the next integer (v1, v2, v3, …)."""
    e1 = LogEntry(ts="2026-01-01T00:00:00Z", content_sha="c1", inputs={})
    e2 = LogEntry(ts="2026-02-01T00:00:00Z", content_sha="c2", inputs={})
    e3 = LogEntry(ts="2026-03-01T00:00:00Z", content_sha="c3", inputs={})
    assert await append_log(USER, workspace_id, "dataset", "lid", e1) == 1
    assert await append_log(USER, workspace_id, "dataset", "lid", e2) == 2
    assert await append_log(USER, workspace_id, "dataset", "lid", e3) == 3
    entries = await read_log(USER, workspace_id, "dataset", "lid")
    assert [e.content_sha for e in entries] == ["c1", "c2", "c3"]


async def test_log_full_dedup_returns_existing_position(workspace_id: str) -> None:
    """Republishing an *earlier* content_sha returns its original version (no append)."""
    e1 = LogEntry(ts="2026-01-01T00:00:00Z", content_sha="c1", inputs={})
    e2 = LogEntry(ts="2026-02-01T00:00:00Z", content_sha="c2", inputs={})
    e1_again = LogEntry(ts="2026-03-01T00:00:00Z", content_sha="c1", inputs={"redo": True})
    assert await append_log(USER, workspace_id, "dataset", "lid", e1) == 1
    assert await append_log(USER, workspace_id, "dataset", "lid", e2) == 2
    # Republishing v1's content returns 1, NOT 3 — version is the position
    # of THIS content_sha in history, not a publish-attempt counter.
    assert await append_log(USER, workspace_id, "dataset", "lid", e1_again) == 1
    entries = await read_log(USER, workspace_id, "dataset", "lid")
    assert [e.content_sha for e in entries] == ["c1", "c2"]


async def test_latest_content_sha(workspace_id: str) -> None:
    assert await latest_content_sha(USER, workspace_id, "dataset", "lid") is None
    await append_log(
        USER,
        workspace_id,
        "dataset",
        "lid",
        LogEntry(ts="2026-01-01T00:00:00Z", content_sha="cA"),
    )
    assert await latest_content_sha(USER, workspace_id, "dataset", "lid") == "cA"
    await append_log(
        USER,
        workspace_id,
        "dataset",
        "lid",
        LogEntry(ts="2026-02-01T00:00:00Z", content_sha="cB"),
    )
    assert await latest_content_sha(USER, workspace_id, "dataset", "lid") == "cB"


async def test_log_skips_malformed_lines(workspace_id: str, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Garbage lines in log.jsonl don't crash the reader — they're skipped."""
    # Seed a malformed log.jsonl directly via the storage layer.
    rel = log_path("dataset", "lid")
    bad = b'{"ts": "x", "content_sha": "good"}\nNOT_JSON\n{"ts": "y", "content_sha": "good2"}\n'
    await service.write_workspace_file_bytes(USER, workspace_id, rel, bad, allow_ockham=True)
    entries = await read_log(USER, workspace_id, "dataset", "lid")
    assert [e.content_sha for e in entries] == ["good", "good2"]


async def test_concurrent_appends_preserve_ordering_and_no_interleave(workspace_id: str) -> None:
    """Many concurrent appends should produce a clean, well-formed JSONL file."""
    n = 20
    entries = [LogEntry(ts=f"2026-01-{i:02d}T00:00:00Z", content_sha=f"c{i:03d}") for i in range(1, n + 1)]
    # Run them all concurrently — flock keeps the file consistent.
    await asyncio.gather(*(append_log(USER, workspace_id, "dataset", "lid", e) for e in entries))
    got = await read_log(USER, workspace_id, "dataset", "lid")
    # All distinct content_shas, all from our set, no duplicates, no malformed lines.
    seen = {e.content_sha for e in got}
    assert seen == {e.content_sha for e in entries}
