"""Round-trip tests for path encoding in ``file://./`` ref tokens."""

from __future__ import annotations

import pytest

from server.api.workspace.file_ref_path import decode_path_from_file_ref, encode_path_for_file_ref
from server.api.workspace.viewers import file_ref


def test_encode_decode_ascii_unchanged() -> None:
    p = "notebooks/cpi.py"
    assert decode_path_from_file_ref(encode_path_for_file_ref(p)) == p


def test_space_newline_in_filename() -> None:
    p = "data/my report (2024).txt"
    enc = encode_path_for_file_ref(p)
    assert " " not in enc
    assert "%20" in enc
    assert decode_path_from_file_ref(enc) == p


def test_file_ref_helper_matches() -> None:
    p = "data/two word.csv"
    assert file_ref(p) == "file://./" + encode_path_for_file_ref(p)
    assert decode_path_from_file_ref(file_ref(p).removeprefix("file://./")) == p


@pytest.mark.parametrize("raw", [".ockham/cards/ds-1/v1/x.parquet", "notes/π.txt", "a/b#c/d"])
def test_encode_decode_roundtrip_param(raw: str) -> None:
    assert decode_path_from_file_ref(encode_path_for_file_ref(raw)) == raw
