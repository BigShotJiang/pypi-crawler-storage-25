"""Phase 1 boundary + private-namespace contract tests.

Asserts that:

* The single boundary primitive ``normalize_workspace_file_path`` rejects
  ``..`` and ``.ockham/`` for external callers, and accepts ``.ockham/`` only
  when the private flag is set.
* Utility tool outputs land in ``.ockham/outputs/<sha256(id)[:16]>.output.json``
  for any provider id shape, including Gemini ids that embed a base64
  thought signature (``call_<hex>__thought__<long-b64-with-/+=>``) which
  would otherwise overflow the OS filename limit.
* Notebook persistence is a single live file per notebook id; multiple
  ``return_notebook`` calls overwrite the same path, no per-call snapshots.
* The list endpoint hides ``.ockham/`` by default and surfaces it with
  ``include_hidden=true``.
"""

from __future__ import annotations

import hashlib
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from parsimony.result import Provenance
from parsimony_agents.agent.outputs import UtilityToolOutput
from parsimony_agents.execution.outputs import FetchLogEntry
from parsimony_agents.notebook import ScriptPreview

from server.api.main import app
from server.api.middleware import LOCAL_USER_ID
from server.api.workspace import service
from server.api.workspace.streaming import _persist_notebook, _persist_utility_output


def _headers() -> dict[str, str]:
    return {"Host": "localhost:8000"}


USER_ID = LOCAL_USER_ID


@pytest.fixture
def client(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> TestClient:
    ws_root = tmp_path / "workspaces"
    ws_root.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("OCKHAM_DATA_DIR", str(tmp_path))
    return TestClient(app)


def test_normalize_rejects_dotdot() -> None:
    with pytest.raises(ValueError, match="path component"):
        service.normalize_workspace_file_path("data/../etc/passwd")


def test_normalize_rejects_backslash_dotdot_bypass() -> None:
    """``..`` must be rejected after ``\\`` → ``/`` normalization, not only for ``/``."""
    with pytest.raises(ValueError, match="path component"):
        service.normalize_workspace_file_path("..\\..\\x")


def test_normalize_accepts_backslash_as_slash() -> None:
    assert service.normalize_workspace_file_path("data\\sub\\a.txt") == "data/sub/a.txt"


def test_normalize_rejects_ockham_by_default() -> None:
    with pytest.raises(ValueError, match=".ockham"):
        service.normalize_workspace_file_path(".ockham/outputs/x.json")


def test_normalize_allows_ockham_when_flagged() -> None:
    assert (
        service.normalize_workspace_file_path(".ockham/outputs/x.json", allow_ockham=True) == ".ockham/outputs/x.json"
    )


def test_normalize_rejects_empty() -> None:
    with pytest.raises(ValueError, match="empty"):
        service.normalize_workspace_file_path("")


def test_write_rejects_ockham_via_file_api(client: TestClient) -> None:
    h = _headers()
    r = client.post("/api/workspaces", json={"title": "A"}, headers=h)
    wid = r.json()["id"]
    r = client.put(
        f"/api/workspaces/{wid}/files/.ockham/outputs/x.json",
        content=b"{}",
        headers={**h, "Content-Type": "application/octet-stream"},
    )
    assert r.status_code == 400


def test_list_hides_ockham_by_default(client: TestClient) -> None:
    h = _headers()
    r = client.post("/api/workspaces", json={"title": "L"}, headers=h)
    wid = r.json()["id"]
    user_id = USER_ID

    import asyncio

    asyncio.get_event_loop().run_until_complete(
        service.write_workspace_file_bytes(
            user_id, wid, ".ockham/outputs/call_abc.output.json", b"{}", allow_ockham=True
        )
    )
    asyncio.get_event_loop().run_until_complete(
        service.write_workspace_file_bytes(user_id, wid, "notebooks/main.notebook.json", b"{}")
    )

    r = client.get(f"/api/workspaces/{wid}/files", headers=h)
    paths = {entry["path"] for entry in r.json()}
    assert "notebooks/main.notebook.json" in paths
    assert all(not p.startswith(".ockham/") for p in paths)

    r = client.get(f"/api/workspaces/{wid}/files?include_hidden=true", headers=h)
    paths = {entry["path"] for entry in r.json()}
    assert ".ockham/outputs/call_abc.output.json" in paths


@pytest.mark.parametrize(
    "tool_call_id",
    [
        "call_a1b2c3d4e5",  # OpenAI style
        "toolu_vrtx_01GPgq1RsBwosjvQzeXVscvi",  # Vertex / Anthropic-via-Vertex
        # Gemini 3: ``call_<hex>__thought__<base64>``. The base64 contains
        # ``/`` and ``=`` and the whole id is ~1 KB — must not leak into the
        # filesystem.
        "call_f421802a46bf4c1b8057eacd3f4e__thought__" + ("ABCDefgh+/01234567890=" * 50),
    ],
)
def test_utility_output_lands_in_ockham(client: TestClient, tool_call_id: str) -> None:
    h = _headers()
    r = client.post("/api/workspaces", json={"title": "U"}, headers=h)
    wid = r.json()["id"]
    user_id = USER_ID

    output = UtilityToolOutput(ui_message="ran")

    import asyncio

    rel, etag = asyncio.get_event_loop().run_until_complete(
        _persist_utility_output(
            user_id=user_id,
            workspace_id=wid,
            tool_call_id=tool_call_id,
            output=output,
        )
    )

    digest = hashlib.sha256(tool_call_id.encode("utf-8")).hexdigest()[:16]
    expected = f".ockham/outputs/{digest}.output.json"
    assert rel == expected
    leaf = expected.rsplit("/", 1)[-1]
    assert "/" not in leaf and "=" not in leaf and "+" not in leaf
    assert len(leaf) <= 255
    # The persisted chunk must echo the content etag; same SSE-turn refresh
    # contract as notebook persistence.
    assert etag and etag.startswith("b2-")

    raw = asyncio.get_event_loop().run_until_complete(
        service.read_workspace_file_bytes(user_id, wid, expected, allow_ockham=True)
    )
    assert raw is not None and raw.startswith(b"{")


def test_notebook_persists_under_uuid_with_versioned_log(client: TestClient) -> None:
    """Two ``return_notebook`` events for the same notebook share a UUID; each distinct
    content_sha gets its own snapshot at ``.ockham/notebooks/<uuid>/<csha>.py``,
    and the log accumulates ``v1`` → ``v2``. The visible ``notebooks/main.py``
    is a virtual live view that always resolves to the latest snapshot."""
    h = _headers()
    r = client.post("/api/workspaces", json={"title": "N"}, headers=h)
    wid = r.json()["id"]
    user_id = USER_ID

    def _preview(code: str) -> ScriptPreview:
        return ScriptPreview(path="notebooks/main.py", code=code, version=1)

    import asyncio

    ref1, etag1, _view1, v1 = asyncio.get_event_loop().run_until_complete(
        _persist_notebook(user_id=user_id, workspace_id=wid, preview=_preview("a = 1"))
    )
    ref2, etag2, _view2, v2 = asyncio.get_event_loop().run_until_complete(
        _persist_notebook(user_id=user_id, workspace_id=wid, preview=_preview("a = 2"))
    )

    # Both snapshots share the same UUID logical_id (rename-safe identity)…
    assert ref1.logical_id == ref2.logical_id
    # …but distinct content_shas.
    assert ref1.content_sha != ref2.content_sha
    # Etags reflect the bytes; two distinct writes → two distinct etags.
    assert etag1 != etag2
    # Versions accumulate monotonically.
    assert v1 == 1 and v2 == 2

    # The visible ``notebooks/main.py`` is virtual and resolves to v2.
    raw = asyncio.get_event_loop().run_until_complete(
        service.read_workspace_file_bytes(user_id, wid, "notebooks/main.py")
    )
    assert raw is not None
    assert b"a = 2" in raw

    # File listing surfaces the virtual entry exactly once.
    rows = asyncio.get_event_loop().run_until_complete(service.list_workspace_files(user_id, wid))
    notebook_files = [p for p, _ in rows if p.startswith("notebooks/")]
    assert notebook_files == ["notebooks/main.py"]


def test_notebook_persisted_view_etag_matches_view_route_with_existing_state(client: TestClient) -> None:
    """Streamed ``view_etag`` must match the exact bytes ``GET /view`` hashes."""
    h = _headers()
    r = client.post("/api/workspaces", json={"title": "N"}, headers=h)
    wid = r.json()["id"]
    code = "a = 1\n"
    fetch_entry = FetchLogEntry(
        source="demo",
        source_description="Demo",
        params={},
        row_count=1,
        column_names=["a"],
        columns=[{"name": "a", "dtype": "int64"}],
        provenance=Provenance(source="demo", source_description="Demo"),
    )

    import asyncio

    ref, _etag, view_etag, _v = asyncio.get_event_loop().run_until_complete(
        _persist_notebook(
            user_id=USER_ID,
            workspace_id=wid,
            preview=ScriptPreview(
                path="notebooks/main.py",
                code=code,
                version=1,
                data_objects=[fetch_entry],
            ),
        )
    )
    rel = ref.workspace_file_path
    view = client.get(f"/api/workspaces/{wid}/view/{rel}", headers=h)
    assert view.status_code == 200
    assert view.headers["etag"].strip('"') == view_etag

    # If the next preview has no fresh KernelOutput but the same script has a
    # cache sidecar, the streamed etag still has to match the route's loader.
    _ref2, _etag2, view_etag2, _v2 = asyncio.get_event_loop().run_until_complete(
        _persist_notebook(
            user_id=USER_ID,
            workspace_id=wid,
            preview=ScriptPreview(path="notebooks/main.py", code=code, version=2),
        )
    )
    view2 = client.get(f"/api/workspaces/{wid}/view/{rel}", headers=h)
    assert view2.status_code == 200
    assert view2.headers["etag"].strip('"') == view_etag2
