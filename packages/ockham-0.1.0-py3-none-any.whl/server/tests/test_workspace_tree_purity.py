"""GET list / events must not materialize an empty workspace directory on disk."""

from __future__ import annotations

from pathlib import Path

import pytest

from server.api.workspace import service
from server.api.workspace.storage import workspace_local_tree_path
from server.storage import workspaces_dir

USER = "00000000-0000-0000-0000-000000000001"


@pytest.mark.asyncio
async def test_list_workspace_entries_does_not_create_tree(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Listing an id with no on-disk materialization returns [] and does not mkdir."""
    monkeypatch.setenv("OCKHAM_DATA_DIR", str(tmp_path))
    (workspaces_dir() / USER).mkdir(parents=True, exist_ok=True)
    missing_id = "00000000-0000-0000-0000-00000000aaaa"
    root = workspace_local_tree_path(USER, missing_id)
    assert not root.exists()
    entries = await service.list_workspace_entries(USER, missing_id)
    assert entries == []
    assert not root.exists()


@pytest.mark.asyncio
async def test_workspace_local_tree_path_does_not_mkdir(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("OCKHAM_DATA_DIR", str(tmp_path))
    p = workspace_local_tree_path(USER, "some-ws-id")
    assert p == workspaces_dir() / USER / "some-ws-id"
    assert not p.exists()
