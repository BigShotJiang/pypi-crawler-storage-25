from litellm import Message as LitellmMessage
from parsimony_agents.agent.models import AgentMessage
from parsimony_agents.messages import Message


def _tool_call_payload() -> dict:
    return {
        "id": "call_1",
        "type": "function",
        "function": {"name": "foo_tool", "arguments": '{"x": 1}'},
    }


def test_from_litellm_preserves_typed_tool_calls() -> None:
    litellm_message = LitellmMessage(
        role="assistant",
        content=None,
        tool_calls=[_tool_call_payload()],
    )

    message = Message.from_litellm(litellm_message)

    assert message.tool_calls is not None
    assert message.tool_calls[0].function.name == "foo_tool"
    assert message.tool_calls[0].function.arguments == '{"x": 1}'


def test_agent_message_accepts_dict_tool_calls_with_dot_access() -> None:
    message = AgentMessage(
        role="assistant",
        content="ok",
        tool_calls=[_tool_call_payload()],
    )

    assert message.tool_calls is not None
    assert message.tool_calls[0].function.name == "foo_tool"
