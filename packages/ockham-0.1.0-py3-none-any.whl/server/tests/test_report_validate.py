"""Tests for the report threat-surface validator.

Each rejection branch in :mod:`server.api.workspace.report.validate`
gets one test. Acceptance cases (legitimate bodies with charts,
datasets, allowlisted callout divs) get tests too.
"""

from __future__ import annotations

import pytest

from server.api.workspace.report.validate import (
    ValidationError,
    validate_report_body,
)


def test_accepts_plain_markdown() -> None:
    validate_report_body("# Hi\n\nA paragraph.\n")


def test_accepts_chart_and_dataset_refs() -> None:
    body = "# Title\n\n![](file://./charts/trend.vl.json)\n\n![](file://./data/sales.parquet)\n"
    validate_report_body(body)


def test_rejects_data_object_ref() -> None:
    """data_objects are not in the live tree; reports cannot embed them."""
    with pytest.raises(ValidationError, match="not allowed"):
        validate_report_body("# T\n\n![](file://./data_objects/foo.parquet)\n")


def test_rejects_legacy_dot_ockham_path() -> None:
    """The old ``.ockham/<kind>s/<lid>/<csha>.<ext>`` shape is no longer
    a valid embed; the validator must reject it as a foreign URI."""
    with pytest.raises(ValidationError, match="foreign file URI"):
        validate_report_body("# T\n\n![](file://./.ockham/charts/abc/" + "f" * 64 + ".vl.json)\n")


def test_pin_map_subset_check_accepts_matching_live_names() -> None:
    body = "# Title\n\n![](file://./charts/trend.vl.json)\n\n![](file://./data/sales.parquet)\n"
    validate_report_body(body, pin_map_keys=frozenset({"trend", "sales"}))


def test_pin_map_subset_check_rejects_unpinned_live_name() -> None:
    """Body URIs whose live_name isn't in the snapshot pin map must be rejected —
    otherwise the renderer would resolve them against current curation, drifting
    away from byte-stability."""
    body = "# T\n\n![](file://./charts/trend.vl.json)\n"
    with pytest.raises(ValidationError, match="has no entry"):
        validate_report_body(body, pin_map_keys=frozenset({"some-other-name"}))


def test_accepts_callout_div() -> None:
    body = "# T\n\n::: {.callout-note}\nA note.\n:::\n"
    validate_report_body(body)


def test_rejects_executable_fence_python() -> None:
    with pytest.raises(ValidationError, match="executable Quarto"):
        validate_report_body("# T\n\n```{python}\nimport os\nos.system('rm -rf /')\n```\n")


def test_rejects_executable_fence_r() -> None:
    with pytest.raises(ValidationError, match="executable Quarto"):
        validate_report_body("# T\n\n```{r}\nsystem('id')\n```\n")


def test_rejects_executable_fence_ojs() -> None:
    with pytest.raises(ValidationError, match="executable Quarto"):
        validate_report_body("# T\n\n```{ojs}\nfetch('http://evil')\n```\n")


def test_rejects_raw_script_tag() -> None:
    with pytest.raises(ValidationError, match="script"):
        validate_report_body("# T\n\n<script>alert(1)</script>\n")


def test_rejects_iframe_tag() -> None:
    with pytest.raises(ValidationError, match="iframe"):
        validate_report_body("# T\n\n<iframe src='http://evil'></iframe>\n")


def test_rejects_style_tag() -> None:
    with pytest.raises(ValidationError, match="style"):
        validate_report_body("# T\n\n<style>body{display:none}</style>\n")


def test_rejects_shortcode() -> None:
    with pytest.raises(ValidationError, match="shortcode"):
        validate_report_body("# T\n\n{{< include 'secrets.qmd' >}}\n")


def test_allows_shortcode_inside_code_block() -> None:
    """Shortcode-like text inside a documentation fenced code block is inert."""
    body = "# T\n\nHere's a shortcode example:\n\n```\n{{< include 'foo.qmd' >}}\n```\n"
    validate_report_body(body)


def test_rejects_unknown_fenced_div() -> None:
    with pytest.raises(ValidationError, match="fenced div class"):
        validate_report_body("# T\n\n::: {.malicious-extension}\nbody\n:::\n")


def test_rejects_foreign_file_uri() -> None:
    with pytest.raises(ValidationError, match="foreign file URI"):
        validate_report_body("# T\n\n![](file:///etc/passwd)\n")


def test_rejects_notebook_ref() -> None:
    """Notebooks live under ``notebooks/`` but cannot be embedded in reports."""
    with pytest.raises(ValidationError, match="foreign file URI"):
        validate_report_body("# T\n\n![](file://./notebooks/foo.py)\n")


def test_rejects_report_ref() -> None:
    """Reports cannot embed other reports — would loop on refresh."""
    with pytest.raises(ValidationError, match="foreign file URI"):
        validate_report_body("# T\n\n![](file://./reports/foo.qmd)\n")


def test_rejects_empty_body() -> None:
    with pytest.raises(ValidationError, match="empty"):
        validate_report_body("")


def test_rejects_wrong_extension_for_kind() -> None:
    """Charts must end in .vl.json under charts/; datasets in .parquet under data/."""
    with pytest.raises(ValidationError, match="wrong extension"):
        validate_report_body("# T\n\n![](file://./charts/foo.parquet)\n")
    with pytest.raises(ValidationError, match="wrong extension"):
        validate_report_body("# T\n\n![](file://./data/foo.vl.json)\n")


def test_accepts_two_column_slide_layout() -> None:
    """The ``return_report`` tool description teaches the agent to use
    ``::: {.columns}`` / ``::: {.column width="..."}`` for two-column
    slide layouts. The validator must accept that exact pattern —
    otherwise valid slide bodies get rejected at persist time."""
    body = (
        "# T\n\n## Slide\n\n"
        "::: {.columns}\n"
        '::: {.column width="55%"}\n'
        "left\n"
        ":::\n"
        '::: {.column width="45%"}\n'
        "right\n"
        ":::\n"
        ":::\n"
    )
    validate_report_body(body)  # must not raise


def test_accepts_speaker_notes_fenced_div() -> None:
    """``::: {.notes}`` is the only way for the agent to author
    presenter-only slide content. Pinning it so a future cleanup
    doesn't accidentally remove it from the allowlist."""
    body = "# T\n\n## Slide\n\n::: {.notes}\nspeaker note.\n:::\n"
    validate_report_body(body)  # must not raise
