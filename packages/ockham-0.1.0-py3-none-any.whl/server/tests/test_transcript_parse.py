from __future__ import annotations

from server.api.workspace.transcript import (
    parse_kernel_restart,
    parse_user_assistant_text,
)


def test_parse_kernel_restart() -> None:
    row: dict[str, object] = {"type": "kernel_restart", "at": "2024-01-01T00:00:00Z", "source": "x"}
    k = parse_kernel_restart(row)
    assert k is not None
    assert k.at == "2024-01-01T00:00:00Z"


def test_parse_user_assistant_text() -> None:
    row: dict[str, object] = {
        "role": "user",
        "content": {"type": "text", "content": "hello"},
    }
    t = parse_user_assistant_text(row)
    assert t is not None
    assert t.role == "user"
    assert t.content.content == "hello"


def test_parse_user_assistant_skips_non_text() -> None:
    row: dict[str, object] = {"role": "user", "content": {"type": "other"}}
    assert parse_user_assistant_text(row) is None
