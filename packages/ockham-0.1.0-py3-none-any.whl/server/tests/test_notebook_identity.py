"""Tests for notebook logical_id resolution (slug + curation indirection).

The resolver answers "what logical_id should this path map to?" honouring
existing curations so renames preserve history. Three cases:

1. **Fresh notebook** — no curation matches; return path-derived slug.
2. **After rename** — a curation already binds a different ``live_name``
   to an older slug; ``return_notebook("notebooks/<new_name>.py")`` resolves
   to the OLD slug so history continues across the rename.
3. **Collision** — the path-slug is already taken by a different
   curation (rare: rename then create-with-original-name); resolver
   suffixes the slug with ``_2``, ``_3``, … until unique.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from server.api.middleware import LOCAL_USER_ID
from server.api.workspace import service
from server.api.workspace.notebook_identity import resolve_notebook_logical_id
from server.api.workspace.snapshot_store import Curation, write_curation

USER = LOCAL_USER_ID


@pytest.fixture
async def workspace_id(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> str:
    monkeypatch.setenv("OCKHAM_DATA_DIR", str(tmp_path))
    meta = await service.create_workspace(USER, "notebook-identity")
    return meta.id


async def test_fresh_notebook_returns_path_slug(workspace_id: str) -> None:
    """No existing curation → logical_id is the path basename."""
    lid = await resolve_notebook_logical_id(USER, workspace_id, "notebooks/us_cpi.py")
    assert lid == "us_cpi"


async def test_rename_keeps_logical_id_stable(workspace_id: str) -> None:
    """``return_notebook`` after a curation-driven rename resolves to the original slug.

    This is the property datasets/charts/reports already have for free
    (their logical_id is hash-of-inputs, not name); it's why notebooks
    need a curation indirection layer to behave the same way.
    """
    # Original notebook lives at .ockham/notebooks/us_cpi/...
    await write_curation(
        USER,
        workspace_id,
        "notebook",
        "us_cpi",
        Curation(
            kind="notebook",
            logical_id="us_cpi",
            live_name="consumer_prices",  # ← user renamed it
        ),
    )
    # Agent now ``return_notebook("notebooks/consumer_prices.py")``.
    lid = await resolve_notebook_logical_id(USER, workspace_id, "notebooks/consumer_prices.py")
    # Resolver finds curation with live_name="consumer_prices" → returns
    # the original logical_id, NOT a fresh slug. History continues.
    assert lid == "us_cpi"


async def test_collision_with_renamed_notebook_gets_suffix(workspace_id: str) -> None:
    """Original slug taken by a renamed curation → fresh slug gets ``_2``."""
    # Notebook originally created as "us_cpi", then renamed.
    await write_curation(
        USER,
        workspace_id,
        "notebook",
        "us_cpi",
        Curation(
            kind="notebook",
            logical_id="us_cpi",
            live_name="consumer_prices",
        ),
    )
    # User now creates a NEW notebook at notebooks/us_cpi.py. The
    # path-slug "us_cpi" is taken by the renamed curation, so resolver
    # picks "us_cpi_2" to keep logical_ids unique.
    lid = await resolve_notebook_logical_id(USER, workspace_id, "notebooks/us_cpi.py")
    assert lid == "us_cpi_2"


async def test_collision_chain_picks_next_free_suffix(workspace_id: str) -> None:
    """If ``_2`` and ``_3`` are also taken, picks ``_4``."""
    for slug, live in [
        ("us_cpi", "first_renamed"),
        ("us_cpi_2", "second_renamed"),
        ("us_cpi_3", "third_renamed"),
    ]:
        await write_curation(
            USER,
            workspace_id,
            "notebook",
            slug,
            Curation(kind="notebook", logical_id=slug, live_name=live),
        )
    lid = await resolve_notebook_logical_id(USER, workspace_id, "notebooks/us_cpi.py")
    assert lid == "us_cpi_4"


async def test_resubmission_for_same_path_returns_same_lid(workspace_id: str) -> None:
    """A curation whose ``live_name`` matches the path's basename always wins."""
    await write_curation(
        USER,
        workspace_id,
        "notebook",
        "us_cpi",
        Curation(kind="notebook", logical_id="us_cpi", live_name="us_cpi"),
    )
    lid = await resolve_notebook_logical_id(USER, workspace_id, "notebooks/us_cpi.py")
    assert lid == "us_cpi"


async def test_invalid_path_raises(workspace_id: str) -> None:
    """Paths outside ``notebooks/`` are caller errors, not silently coerced."""
    with pytest.raises(ValueError):
        await resolve_notebook_logical_id(USER, workspace_id, "data/foo.parquet")
