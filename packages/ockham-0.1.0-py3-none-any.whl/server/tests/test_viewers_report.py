"""Viewer-payload tests for the ``report`` kind."""

from __future__ import annotations

import pytest
from parsimony_agents.identity import ArtifactRef
from parsimony_agents.report_format import compose_snapshot

from server.api.workspace.viewers import VIEWER_REGISTRY, viewer_payload_for_path


def _chart_ref(lid: str = "c1", csha: str = "f" * 64) -> ArtifactRef:
    return ArtifactRef(kind="chart", logical_id=lid, content_sha=csha)


def _dataset_ref(lid: str = "d1", csha: str = "a" * 64) -> ArtifactRef:
    return ArtifactRef(kind="dataset", logical_id=lid, content_sha=csha)


def test_registered_extension() -> None:
    spec = VIEWER_REGISTRY["report"]
    assert spec.extensions == (".qmd",)


def test_payload_exposes_available_formats_and_refs() -> None:
    body = "Narrative paragraph.\n\n![](file://./charts/trend.vl.json)\n\n![](file://./data/sales.parquet)\n"
    chart_ref = _chart_ref()
    dataset_ref = _dataset_ref()
    blob = compose_snapshot(
        ["html", "pdf", "pptx"],
        {"trend": chart_ref, "sales": dataset_ref},
        body,
        title="Q4 Review",
        subtitle="Revenue notes",
    ).encode("utf-8")
    payload = viewer_payload_for_path("reports/q4.qmd", blob)
    assert payload["kind"] == "report"
    md = payload["metadata"]
    assert md["title"] == "Q4 Review"
    assert md["subtitle"] == "Revenue notes"
    assert md["available_formats"] == ["html", "pdf", "pptx"]
    assert md["ref_count"] == 2
    refs = payload["payload"]["refs"]
    kinds = sorted(r["kind"] for r in refs)
    assert kinds == ["chart", "dataset"]
    # Source payload returns the body, not the persisted frontmatter.
    assert payload["payload"]["source"].startswith("Narrative paragraph")
    # Body must not contain a leading `# Q4 Review` line — title lives in
    # the parsimony frontmatter, not in the body.
    assert "# Q4 Review" not in payload["payload"]["source"]


def test_payload_rejects_legacy_bodies_without_frontmatter() -> None:
    """Snapshots without YAML frontmatter aren't valid under the new model —
    the viewer surfaces this as a ValueError rather than silently rendering
    with default settings."""
    blob = b"# T\n\nx\n"
    with pytest.raises(ValueError, match="frontmatter"):
        viewer_payload_for_path("reports/x.qmd", blob)


def test_llm_summary_includes_formats() -> None:
    body = "body content\n"
    blob = compose_snapshot(["html", "pdf"], {}, body, title="Hi").encode("utf-8")
    spec = VIEWER_REGISTRY["report"]
    assert spec.llm_summary_fn is not None
    summary = spec.llm_summary_fn(blob, "reports/x.qmd")
    assert "Hi" in summary
    assert "html,pdf" in summary


def test_payload_emits_artifact_envelope_with_embedded_refs_and_subtitle() -> None:
    """The detail tab consumes ``payload.artifact`` — same shape as
    Dataset / Chart viewers. ``embedded_refs`` carries the snapshot's
    frozen pin map as typed ref triplets so :func:`enrich_artifact_envelope`
    can decorate each one with workspace_file_path + display_name. Subtitle
    is part of the envelope so the metadata tab can render it next to title.
    """
    body = "![](file://./charts/trend.vl.json)\n"
    chart_ref = _chart_ref()
    blob = compose_snapshot(["html"], {"trend": chart_ref}, body, title="Q4", subtitle="Notes").encode("utf-8")
    payload = viewer_payload_for_path("reports/q4.qmd", blob)

    artifact = payload["artifact"]
    # Curation placeholders (overlay happens at the route boundary).
    assert artifact["title"] == "Q4"
    assert artifact["subtitle"] == "Notes"
    assert artifact["description"] == ""
    assert artifact["tags"] == []
    assert artifact["notes"] == []
    # Empty containers for kinds the report doesn't have.
    assert artifact["notebook_refs"] == []
    assert artifact["source_refs"] == []
    # Embedded refs carry the typed ArtifactRef triplet for each pin.
    assert artifact["embedded_refs"] == [
        {"kind": "chart", "logical_id": chart_ref.logical_id, "content_sha": chart_ref.content_sha},
    ]


def test_payload_subtitle_empty_when_omitted() -> None:
    """A report without subtitle reports an empty string, not None."""
    blob = compose_snapshot(["html"], {}, "body\n", title="Plain").encode("utf-8")
    payload = viewer_payload_for_path("reports/x.qmd", blob)
    assert payload["metadata"]["subtitle"] == ""
    assert payload["artifact"]["subtitle"] == ""


def test_llm_read_full_returns_body() -> None:
    body = "The entire body.\n"
    blob = compose_snapshot(["html"], {}, body, title="Hi").encode("utf-8")
    spec = VIEWER_REGISTRY["report"]
    assert spec.llm_read_fn is not None
    out = spec.llm_read_fn(blob, "reports/x.qmd", "full")
    assert "The entire body" in out
    # The frontmatter is internal — the LLM sees only the body.
    assert "parsimony:" not in out
    assert "formats:" not in out
