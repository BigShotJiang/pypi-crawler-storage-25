"""Tests for ``list_workspace_artifacts_in_tree`` and its sync helper.

Cross-terminal awareness: this service IS workspace-scoped (sibling-terminal
curations are visible). Isolation is enforced via prompt rules and the
resolver collision gate — not by hiding the listing.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from server.api.workspace.service import (
    _latest_snapshot_file,
    _list_workspace_artifacts_sync,
    list_workspace_artifacts_in_tree,
)


def _write_curation(
    root: Path,
    *,
    kind: str,
    lid: str,
    live_name: str | None = None,
    title: str = "",
    description: str = "",
    tags: list[str] | None = None,
    source: str | None = None,
    snapshot_sha: str | None = None,
    snapshot_ext: str = ".parquet",
) -> None:
    """Write ``<root>/.ockham/<kind>s/<lid>/{curation.json,<sha>.<ext>}``."""
    entry = root / ".ockham" / f"{kind}s" / lid
    entry.mkdir(parents=True)
    body: dict = {"kind": kind, "logical_id": lid}
    if live_name is not None:
        body["live_name"] = live_name
    if title:
        body["title"] = title
    if description:
        body["description"] = description
    if tags:
        body["tags"] = tags
    if source is not None:
        body["source"] = source
    (entry / "curation.json").write_text(json.dumps(body))
    if snapshot_sha is not None:
        (entry / f"{snapshot_sha}{snapshot_ext}").write_bytes(b"\0" * 8)


@pytest.mark.asyncio
async def test_empty_workspace_returns_empty(tmp_path: Path) -> None:
    assert await list_workspace_artifacts_in_tree(tmp_path) == []


@pytest.mark.asyncio
async def test_lists_all_kinds_with_no_filter(tmp_path: Path) -> None:
    _write_curation(tmp_path, kind="notebook", lid="nb1", live_name="us_gdp")
    _write_curation(
        tmp_path,
        kind="dataset",
        lid="ds1",
        live_name="us_gdp",
        title="GDP",
        snapshot_sha="ds_csha",
    )
    rows = await list_workspace_artifacts_in_tree(tmp_path)
    kinds = sorted(r["kind"] for r in rows)
    assert kinds == ["dataset", "notebook"]


@pytest.mark.asyncio
async def test_kind_filter_isolates_one_kind(tmp_path: Path) -> None:
    _write_curation(tmp_path, kind="notebook", lid="nb1", live_name="us_gdp")
    _write_curation(
        tmp_path,
        kind="dataset",
        lid="ds1",
        live_name="us_gdp",
        snapshot_sha="ds_csha",
    )
    rows = await list_workspace_artifacts_in_tree(tmp_path, kind="dataset")
    assert len(rows) == 1
    assert rows[0]["kind"] == "dataset"


@pytest.mark.asyncio
async def test_unknown_kind_filter_returns_empty(tmp_path: Path) -> None:
    _write_curation(tmp_path, kind="notebook", lid="nb1", live_name="us_gdp")
    assert await list_workspace_artifacts_in_tree(tmp_path, kind="banana") == []


@pytest.mark.asyncio
async def test_query_matches_live_name(tmp_path: Path) -> None:
    _write_curation(tmp_path, kind="notebook", lid="nb1", live_name="us_gdp")
    _write_curation(tmp_path, kind="notebook", lid="nb2", live_name="canada_gdp")
    _write_curation(tmp_path, kind="notebook", lid="nb3", live_name="oil_prices")

    rows = await list_workspace_artifacts_in_tree(tmp_path, query="gdp")
    names = sorted(r["live_name"] for r in rows)
    assert names == ["canada_gdp", "us_gdp"]


@pytest.mark.asyncio
async def test_query_matches_title_case_insensitive(tmp_path: Path) -> None:
    _write_curation(
        tmp_path,
        kind="dataset",
        lid="ds1",
        live_name="x",
        title="Monthly Unemployment Rate",
        snapshot_sha="csha",
    )
    rows = await list_workspace_artifacts_in_tree(tmp_path, query="UNEMPLOYMENT")
    assert len(rows) == 1


@pytest.mark.asyncio
async def test_query_matches_tags(tmp_path: Path) -> None:
    _write_curation(
        tmp_path,
        kind="dataset",
        lid="ds1",
        live_name="x",
        tags=["macro", "fred"],
        snapshot_sha="csha",
    )
    rows = await list_workspace_artifacts_in_tree(tmp_path, query="fred")
    assert len(rows) == 1


@pytest.mark.asyncio
async def test_query_with_no_match_returns_empty(tmp_path: Path) -> None:
    _write_curation(tmp_path, kind="notebook", lid="nb1", live_name="us_gdp")
    rows = await list_workspace_artifacts_in_tree(tmp_path, query="bitcoin")
    assert rows == []


@pytest.mark.asyncio
async def test_limit_is_honoured(tmp_path: Path) -> None:
    for i in range(10):
        _write_curation(tmp_path, kind="notebook", lid=f"nb{i}", live_name=f"item_{i}")
    rows = await list_workspace_artifacts_in_tree(tmp_path, limit=3)
    assert len(rows) == 3


@pytest.mark.asyncio
async def test_row_carries_live_name_and_kind(tmp_path: Path) -> None:
    """Rows expose ``live_name`` + ``kind`` only — no path. The agent
    dereferences via ``read_artifact(live_name=…, kind=…)``."""
    _write_curation(tmp_path, kind="notebook", lid="nb1", live_name="us_gdp")
    rows = await list_workspace_artifacts_in_tree(tmp_path, kind="notebook")
    assert rows[0]["live_name"] == "us_gdp"
    assert rows[0]["kind"] == "notebook"
    assert "path" not in rows[0]


@pytest.mark.asyncio
async def test_non_notebook_row_also_only_has_live_name(tmp_path: Path) -> None:
    _write_curation(
        tmp_path,
        kind="dataset",
        lid="ds1",
        live_name="x",
        snapshot_sha="abc123",
    )
    rows = await list_workspace_artifacts_in_tree(tmp_path, kind="dataset")
    assert rows[0]["live_name"] == "x"
    assert rows[0]["kind"] == "dataset"
    assert "path" not in rows[0]


@pytest.mark.asyncio
async def test_non_notebook_without_snapshot_is_skipped(tmp_path: Path) -> None:
    """Curation persisted but no snapshot bytes ⇒ skip (executor would 500)."""
    _write_curation(
        tmp_path,
        kind="dataset",
        lid="ds1",
        live_name="x",
        snapshot_sha=None,
    )
    rows = await list_workspace_artifacts_in_tree(tmp_path, kind="dataset")
    assert rows == []


@pytest.mark.asyncio
async def test_non_notebook_with_snapshot_is_listed(tmp_path: Path) -> None:
    """Snapshot presence still gates inclusion (no snapshot ⇒ skip)."""
    import time

    entry = tmp_path / ".ockham" / "datasets" / "ds1"
    entry.mkdir(parents=True)
    (entry / "curation.json").write_text(json.dumps({"kind": "dataset", "logical_id": "ds1", "live_name": "x"}))
    older = entry / "older.parquet"
    newer = entry / "newer.parquet"
    older.write_bytes(b"old")
    time.sleep(0.01)
    newer.write_bytes(b"new")

    rows = await list_workspace_artifacts_in_tree(tmp_path, kind="dataset")
    assert len(rows) == 1
    assert rows[0]["live_name"] == "x"


@pytest.mark.asyncio
async def test_skips_malformed_curation(tmp_path: Path) -> None:
    """One bad curation does not break the whole listing."""
    _write_curation(tmp_path, kind="notebook", lid="ok", live_name="good")
    bad = tmp_path / ".ockham" / "notebooks" / "bad"
    bad.mkdir(parents=True)
    (bad / "curation.json").write_bytes(b"\xff\xfe not json \xab")

    rows = await list_workspace_artifacts_in_tree(tmp_path, kind="notebook")
    assert {r["live_name"] for r in rows} == {"good"}


@pytest.mark.asyncio
async def test_cross_terminal_artifacts_are_visible(tmp_path: Path) -> None:
    """Both terminals' curations show up. Isolation lives elsewhere."""
    _write_curation(
        tmp_path,
        kind="dataset",
        lid="t1_ds",
        live_name="us_gdp",
        snapshot_sha="csha1",
    )
    _write_curation(
        tmp_path,
        kind="dataset",
        lid="t2_ds",
        live_name="unemployment",
        snapshot_sha="csha2",
    )
    rows = await list_workspace_artifacts_in_tree(tmp_path, kind="dataset")
    names = sorted(r["live_name"] for r in rows)
    assert names == ["unemployment", "us_gdp"]


def test_latest_snapshot_file_skips_sidecars(tmp_path: Path) -> None:
    entry = tmp_path / "ds1"
    entry.mkdir()
    (entry / "curation.json").write_text("{}")
    (entry / "log.jsonl").write_text("")
    (entry / "lock.lock").write_text("")
    (entry / "data.parquet").write_bytes(b"x")

    snap = _latest_snapshot_file(entry)
    assert snap is not None
    assert snap.name == "data.parquet"


def test_latest_snapshot_file_no_snapshots_returns_none(tmp_path: Path) -> None:
    entry = tmp_path / "ds1"
    entry.mkdir()
    (entry / "curation.json").write_text("{}")
    assert _latest_snapshot_file(entry) is None


def test_sync_helper_matches_async_wrapper(tmp_path: Path) -> None:
    _write_curation(tmp_path, kind="notebook", lid="nb1", live_name="x")
    rows = _list_workspace_artifacts_sync(tmp_path, None, None, 20)
    assert len(rows) == 1
