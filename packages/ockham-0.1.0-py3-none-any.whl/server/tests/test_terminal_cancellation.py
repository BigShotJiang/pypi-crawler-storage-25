"""Cancellation wire contract and cancel API."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient
from parsimony_agents.agent.events import RunCancelled

from server.api.config import config
from server.api.main import app
from server.api.streaming.framework_events import framework_event_to_stream_chunks
from server.api.streaming.models import CancellationChunk, CancelTerminalRunResponse


def _headers() -> dict[str, str]:
    return {"Host": "localhost:8000"}


@pytest.fixture
def client(tmp_path, monkeypatch) -> TestClient:  # type: ignore[no-untyped-def]
    monkeypatch.setattr(config, "AUTH_ENABLED", False)
    ws_root = tmp_path / "workspaces"
    ws_root.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("OCKHAM_DATA_DIR", str(tmp_path))
    return TestClient(app)


def test_run_cancelled_maps_to_cancellation_chunk() -> None:
    ev = RunCancelled(
        message="Stopped",
        reason="user_request",
    )
    out = framework_event_to_stream_chunks(ev, response_id="resp-1")
    assert isinstance(out, CancellationChunk)
    assert out.data.message == "Stopped"
    assert out.data.reason == "user_request"
    assert out.type == "cancelled"


def test_cancel_terminal_idempotent_no_active_stream(client: TestClient) -> None:
    h = _headers()
    r = client.post("/api/workspaces", json={"title": "C"}, headers=h)
    assert r.status_code == 200
    wid = r.json()["id"]
    trows = client.get(f"/api/workspaces/{wid}/terminals", headers=h)
    tid = trows.json()[0]["id"]

    r2 = client.post(
        f"/api/workspaces/{wid}/terminals/{tid}/cancel",
        headers=h,
    )
    assert r2.status_code == 200
    data = r2.json()
    assert data["cancelled"] is False
    assert data["responseId"] is None


def test_cancel_terminal_response_model() -> None:
    m = CancelTerminalRunResponse(cancelled=True, response_id="rid-1")
    assert m.model_dump(mode="json", by_alias=True) == {
        "cancelled": True,
        "responseId": "rid-1",
    }
