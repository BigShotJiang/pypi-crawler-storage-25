"""Regression: viewer + terminal storage paths stay pure (no CodeExecutor in-process)."""

from __future__ import annotations

import tempfile
from pathlib import Path
from typing import Literal

import pandas as pd
import pytest
from fastapi.testclient import TestClient
from parsimony.result import Column, ColumnRole, OutputConfig, Provenance, Result
from parsimony_agents.agent.agent import _tool_batch_allows_concurrent
from parsimony_agents.tools import Tool, Tools

from server.api.config import config
from server.api.main import app
from server.execution import RemoteCodeExecutor


def _headers() -> dict[str, str]:
    return {"Host": "localhost:8000"}


def _schema() -> dict:
    return {"type": "object", "properties": {}}


def _make_tools() -> Tools:
    async def _t(*_a: object, **_k: object) -> str:
        return "ok"

    def _mkt(
        name: str,
        t: Literal["code", "utility", "return", "system"],
    ) -> Tool:
        return Tool(
            _t,
            name=name,
            description="d",
            parameters_schema=_schema(),
            tool_type=t,
        )

    return Tools(
        [
            _mkt("return_dataset", "return"),
            _mkt("read_file", "system"),
            _mkt("write_file", "system"),
        ],
    )


def test_tool_batch_allows_concurrent_rejects_mixed() -> None:
    tools = _make_tools()
    assert _tool_batch_allows_concurrent(["read_file", "read_file"], tools) is True
    assert _tool_batch_allows_concurrent(["return_dataset", "read_file"], tools) is False
    assert _tool_batch_allows_concurrent(["read_file", "write_file"], tools) is False


def test_get_view_artifact_does_not_construct_code_executor(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    from parsimony_agents.execution import executor as exec_mod

    called: list[object] = []
    _orig = exec_mod.CodeExecutor.__init__

    def _track(self, *a: object, **kw: object) -> None:
        called.append(True)
        return _orig(self, *a, **kw)

    monkeypatch.setattr(config, "AUTH_ENABLED", False)
    ws_root = tmp_path / "workspaces"
    ws_root.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("OCKHAM_DATA_DIR", str(tmp_path))
    monkeypatch.setattr(exec_mod.CodeExecutor, "__init__", _track)

    client = TestClient(app)
    h = _headers()
    r = client.post("/api/workspaces", json={"title": "V"}, headers=h)
    assert r.status_code == 200
    wid = r.json()["id"]
    df = pd.DataFrame({"a": [1.0, 2.0]})
    sem = Result(
        data=df,
        provenance=Provenance(source="t", source_description="t"),
    ).to_table(
        OutputConfig(
            columns=[Column(name="a", role=ColumnRole.DATA)],
        )
    )
    fd, path = tempfile.mkstemp(suffix=".parquet")
    import os

    os.close(fd)
    try:
        sem.to_parquet(path)
        blob = Path(path).read_bytes()
    finally:
        Path(path).unlink(missing_ok=True)

    r2 = client.put(
        f"/api/workspaces/{wid}/files/data/p.parquet",
        content=blob,
        headers={**h, "Content-Type": "application/octet-stream"},
    )
    assert r2.status_code == 204
    v = client.get(
        f"/api/workspaces/{wid}/view/data/p.parquet",
        headers=h,
    )
    assert v.status_code == 200
    assert not called, "GET /view should not require an in-process CodeExecutor"


@pytest.mark.asyncio
async def test_create_terminal_session_does_not_construct_remote_code_executor(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from server.api.middleware import LOCAL_USER_ID
    from server.api.workspace import service as wsvc

    ws_root = tmp_path / "workspaces"
    ws_root.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("OCKHAM_DATA_DIR", str(tmp_path))

    calls: list[str] = []
    real = RemoteCodeExecutor.__init__

    def _tr(self, *a: object, **k: object) -> None:  # noqa: ANN001
        calls.append("rce")
        return real(self, *a, **k)

    monkeypatch.setattr(RemoteCodeExecutor, "__init__", _tr)
    w = await wsvc.create_workspace(LOCAL_USER_ID, "Kernel purity")
    await wsvc.create_terminal_session(LOCAL_USER_ID, w.id, "T1")
    assert not calls
