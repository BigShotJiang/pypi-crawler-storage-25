"""Wire-shape contract for ``kind="dataset"`` payloads.

The agent passes typed lineage refs into ``return_dataset.source_refs``.
The viewer must surface those in the ``artifact`` envelope so the
ProvenancePanel renders them — historically the field was at top level
of the payload (next to ``artifact``), where the panel never read it,
and source lineage silently disappeared from the dataset metadata view.
"""

from __future__ import annotations

from io import BytesIO
from pathlib import Path

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from parsimony_agents.artifacts import Dataset
from parsimony_agents.dataset_io import CURATION_META_KEY, serialize_dataset
from parsimony_agents.execution.outputs import DataFrameObject
from parsimony_agents.identity import ArtifactRef, dataset_logical_id

from server.api.workspace.viewers import viewer_payload_for_path


def _curated_dataset_blob(tmp_path: Path) -> bytes:
    nb_ref = ArtifactRef(kind="notebook", logical_id="nb-csha", content_sha="nb-csha")
    src_ref = ArtifactRef(kind="data_object", logical_id="do-lid", content_sha="do-csha")
    ds_ref = ArtifactRef(kind="dataset", logical_id="ds-lid", content_sha="ds-csha")
    df = pd.DataFrame({"x": [1, 2, 3]})
    payload = DataFrameObject.from_pandas(df, local_dir=tmp_path / "_dfo")
    artifact = Dataset(
        title="US CPI",
        description="Consumer Price Index",
        tags=["macro"],
        notes=["Computed from FRED CPI series."],
        notebook_refs=[nb_ref],
        source_refs=[src_ref, ds_ref],
        logical_id=dataset_logical_id(
            notebook_refs=[nb_ref],
            variable_name="cpi",
            source_refs=[src_ref, ds_ref],
        ),
    )
    blob = serialize_dataset(artifact, payload)
    # Sanity: the blob round-trips via parquet metadata.
    schema_meta = pq.read_metadata(BytesIO(blob)).schema.to_arrow_schema().metadata or {}
    assert CURATION_META_KEY in schema_meta
    return blob


def test_dataset_payload_carries_source_refs_on_artifact_envelope(tmp_path: Path) -> None:
    blob = _curated_dataset_blob(tmp_path)
    payload = viewer_payload_for_path(".ockham/datasets/lid/csha.parquet", blob)
    assert payload["kind"] == "dataset"
    artifact = payload["artifact"]
    # Both kinds are surfaced together so the panel can split by kind.
    refs = artifact.get("source_refs")
    assert isinstance(refs, list)
    assert {(r["kind"], r["logical_id"], r["content_sha"]) for r in refs} == {
        ("data_object", "do-lid", "do-csha"),
        ("dataset", "ds-lid", "ds-csha"),
    }


def test_dataset_notebook_refs_emitted_as_typed_dicts(tmp_path: Path) -> None:
    """notebook_refs is a list of typed ref dicts, not decorated file:// strings.

    The frontend pill needs ``workspace_file_path`` (link target) and
    ``display_name`` (human label). The route handler enriches these
    fields after the viewer returns; the viewer just needs to surface
    the typed triplet, not the legacy decorated form.
    """
    blob = _curated_dataset_blob(tmp_path)
    payload = viewer_payload_for_path(".ockham/datasets/lid/csha.parquet", blob)
    nb_refs = payload["artifact"]["notebook_refs"]
    assert isinstance(nb_refs, list)
    assert nb_refs == [{"kind": "notebook", "logical_id": "nb-csha", "content_sha": "nb-csha"}]


def test_dataset_artifact_envelope_derives_content_sha_from_path(tmp_path: Path) -> None:
    """content_sha must come from the on-disk path, not the embedded curation.

    ``persist_return_artifact`` serialises the dataset bytes BEFORE setting
    ``Dataset.content_sha`` on the in-memory model, so the embedded curation
    block always carries an empty string. The viewer compensates by parsing
    ``logical_id`` and ``content_sha`` from the canonical path
    ``.ockham/<kind>s/<logical_id>/<content_sha>.<ext>``.
    """
    blob = _curated_dataset_blob(tmp_path)
    lid = "a" * 64
    csha = "b" * 64
    payload = viewer_payload_for_path(f".ockham/datasets/{lid}/{csha}.parquet", blob)
    artifact = payload["artifact"]
    assert artifact["logical_id"] == lid
    assert artifact["content_sha"] == csha


def test_data_object_payload_omits_artifact_envelope() -> None:
    """Raw fetch snapshots have no curation; they should not pretend to be datasets."""
    df = pd.DataFrame({"x": [1]})
    table = pa.Table.from_pandas(df)
    bio = BytesIO()
    pq.write_table(table, bio)
    blob = bio.getvalue()
    payload = viewer_payload_for_path(".ockham/data_objects/lid/csha.parquet", blob)
    # No curation → server returns kind="dataset" with empty refs (legacy path).
    # Only the ``data_object`` branch carries provenance; either way, the
    # contract is "no source_refs invented from nothing".
    if payload["kind"] == "dataset":
        assert payload["artifact"]["source_refs"] == []
