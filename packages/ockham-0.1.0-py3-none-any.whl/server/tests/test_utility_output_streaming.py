"""Utility tool output streaming behavior."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest
from parsimony_agents.agent.events import ToolEvent
from parsimony_agents.agent.models import AgentContext
from parsimony_agents.agent.outputs import UtilityToolOutput
from parsimony_agents.messages import Text

from server.api.middleware import LOCAL_USER_ID
from server.api.streaming.models import SendMessageRequest
from server.api.workspace import service
from server.api.workspace.streaming import stream_workspace_conversation
from server.api.workspace.viewers import viewer_payload_for_path


class _FakeExecutor:
    async def set_cwd(self, _cwd: str, *, session_id: str) -> None:
        self.session_id = session_id

    async def close(self) -> None:
        pass


class _FakeAgent:
    def __init__(self, events: list[ToolEvent]) -> None:
        self.code_executor = _FakeExecutor()
        self._events = events

    async def run(self, **_kwargs: Any) -> Any:
        for event in self._events:
            yield event


def _sse_payload(chunk: str) -> dict[str, Any]:
    assert chunk.startswith("data: ")
    return json.loads(chunk.removeprefix("data: ").strip())


@pytest.mark.asyncio
async def test_incomplete_utility_output_is_streamed_before_completion(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    ws_root = tmp_path / "workspaces"
    ws_root.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("OCKHAM_DATA_DIR", str(tmp_path))

    workspace = await service.create_workspace(LOCAL_USER_ID, "Utility streaming")
    terminal = await service.create_terminal_session(LOCAL_USER_ID, workspace.id)
    code = "print('hello')"
    tool_call_id = "call-dry-execute"
    events = [
        ToolEvent(
            tool_name="dry_execute_code",
            tool_call_id=tool_call_id,
            tool_type="utility",
            completed=False,
            result=UtilityToolOutput(
                ui_message="Running code",
                metadata={
                    "source_tool_name": "dry_execute_code",
                    "source_tool_args": {"code": code},
                },
            ),
        ),
        ToolEvent(
            tool_name="dry_execute_code",
            tool_call_id=tool_call_id,
            tool_type="utility",
            completed=True,
            result=UtilityToolOutput(
                ui_message="Running code",
                ui_message_completed="Ran code",
                metadata={
                    "source_tool_name": "dry_execute_code",
                    "source_tool_args": {"code": code},
                },
                content=Text(content="hello"),
            ),
        ),
    ]

    stream = stream_workspace_conversation(
        SendMessageRequest(message="run it", selected_model_set="test-model"),
        _FakeAgent(events),  # type: ignore[arg-type]
        AgentContext(session_id="test-session"),
        user_id=LOCAL_USER_ID,
        workspace_id=workspace.id,
        terminal_id=terminal.id,
        local_dir=tmp_path / "materialized",
        turn_response_id="response-1",
    )

    first = _sse_payload(await anext(stream))
    assert first["type"] == "file_ref"
    assert first["kind"] == "utility_output"
    assert first["messageId"] == tool_call_id
    assert first["completed"] is False

    raw = await service.read_workspace_file_bytes(
        LOCAL_USER_ID,
        workspace.id,
        first["workspace_file_path"],
        allow_ockham=True,
    )
    assert raw is not None
    pending_output = json.loads(raw.decode("utf-8"))
    assert pending_output["metadata"]["source_tool_args"]["code"] == code
    assert pending_output["content"] is None
    view = viewer_payload_for_path(first["workspace_file_path"], raw)
    assert view["kind"] == "utility_output"
    assert view["payload"]["metadata"]["source_tool_args"]["code"] == code

    second = _sse_payload(await anext(stream))
    assert second["type"] == "file_ref"
    assert second["messageId"] == tool_call_id
    assert second["completed"] is True
    assert second["workspace_file_path"] == first["workspace_file_path"]
    assert second["etag"] != first["etag"]

    await stream.aclose()
