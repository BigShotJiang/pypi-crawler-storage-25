"""Tests for the product-meta router (/api/meta/...)."""

from __future__ import annotations

from fastapi import FastAPI
from fastapi.testclient import TestClient

from server import product
from server.api.meta.router import router


def test_product_tiers_are_static_model_choices() -> None:
    assert product.DEFAULT_TIER in product.TIERS
    assert product.TIERS["pro"].model in product.MODELS


def test_list_model_sets_returns_static_metadata() -> None:
    app = FastAPI()
    app.include_router(router)

    client = TestClient(app)
    response = client.get("/api/meta/model-sets")
    assert response.status_code == 200
    payload = response.json()
    assert payload["default"] == product.DEFAULT_TIER
    assert "restricted_model_sets" not in payload
    assert {row["id"] for row in payload["model_sets"]} == set(product.TIERS)
