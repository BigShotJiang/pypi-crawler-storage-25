"""Registry-backed LLM file expansion for referenced paths."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from server.api.config import config
from server.api.main import app
from server.api.middleware import LOCAL_USER_ID
from server.api.workspace import service
from server.api.workspace.artifact_llm import artifact_summary_for_path, read_artifact_for_llm


def _headers() -> dict[str, str]:
    return {"Host": "localhost:8000"}


@pytest.fixture
def client(tmp_path, monkeypatch: pytest.MonkeyPatch) -> TestClient:
    monkeypatch.setattr(config, "AUTH_ENABLED", False)
    ws_root = tmp_path / "workspaces"
    ws_root.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("OCKHAM_DATA_DIR", str(tmp_path))
    return TestClient(app)


@pytest.mark.asyncio
async def test_render_referenced_notebook_uses_registry_not_raw_code_only(client: TestClient) -> None:
    h = _headers()
    r = client.post("/api/workspaces", json={"title": "NB"}, headers=h)
    assert r.status_code == 200
    wid = r.json()["id"]
    code = '"""One-liner for tests."""\n# section\nx = 1\n'
    await service.write_workspace_file_bytes(LOCAL_USER_ID, wid, "notebooks/tiny.py", code.encode("utf-8"))
    out = await service.render_referenced_files_for_llm(
        LOCAL_USER_ID,
        wid,
        "see file://./notebooks/tiny.py",
    )
    assert "<referenced_files>" in out
    assert "One-liner for tests" in out
    assert "<section_outline>" in out
    # Summary mode does not inline full notebook code.
    assert "x = 1" not in out


def test_read_artifact_for_llm_parquet_summary_smoke(tmp_path) -> None:
    import pandas as pd
    from parsimony_agents.artifacts import Dataset
    from parsimony_agents.execution.outputs import DataFrameObject

    df = pd.DataFrame({"a": [1, 2]})
    Dataset(title="T").with_payload(DataFrameObject.from_pandas(df, local_dir=tmp_path / "_dfo")).save(
        tmp_path / "t.parquet"
    )
    raw = (tmp_path / "t.parquet").read_bytes()
    text = read_artifact_for_llm("data/t.parquet", raw, mode="summary")
    assert "T" in text or "data/t.parquet" in text


def test_artifact_summary_for_path(tmp_path) -> None:
    import pandas as pd
    from parsimony_agents.artifacts import Dataset
    from parsimony_agents.execution.outputs import DataFrameObject

    df = pd.DataFrame({"z": [1]})
    Dataset(title="Hi").with_payload(DataFrameObject.from_pandas(df, local_dir=tmp_path / "_dfo")).save(
        tmp_path / "x.parquet"
    )
    raw = (tmp_path / "x.parquet").read_bytes()
    s = artifact_summary_for_path("d/x.parquet", raw)
    assert s is not None
    assert "Hi" in s
