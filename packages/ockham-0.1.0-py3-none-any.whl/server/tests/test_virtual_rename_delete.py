"""Rename and soft-delete on virtual live-tree entries route to curation.

The user-visible workspace tree exposes datasets/charts/reports as
virtual entries derived from each artifact's ``curation.live_name``
(plan §4.1). The brief: "the workspace tree should feel like a normal
file tree" — so right-click rename and right-click delete go through
the same ``files:move`` and ``DELETE /files/{path}`` endpoints the user
hits for any other file. The server detects virtuality and routes to a
curation update (sidecar only, no byte rewrites), preserving
``content_sha`` across the rename and any frozen refs across delete.

These tests pin the polymorphic boundary in ``service.py``.
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd
import pytest
from parsimony_agents.artifacts import Dataset
from parsimony_agents.execution.outputs import DataFrameObject
from parsimony_agents.identity import ArtifactRef, dataset_logical_id

from server.api.middleware import LOCAL_USER_ID
from server.api.workspace import service
from server.api.workspace.artifact_registry import persist_return_artifact
from server.api.workspace.snapshot_store import (
    latest_content_sha,
    read_curation,
)


@pytest.fixture
async def workspace_id(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> str:
    monkeypatch.setenv("OCKHAM_DATA_DIR", str(tmp_path))
    meta = await service.create_workspace(LOCAL_USER_ID, "virtual-rename-tests")
    return meta.id


def _nb_ref(sha: str) -> ArtifactRef:
    return ArtifactRef(kind="notebook", logical_id=sha, content_sha=sha)


async def _persist_dataset(workspace_id: str, tmp_path: Path, *, title: str, variable: str = "x") -> ArtifactRef:
    df = pd.DataFrame({variable: [1, 2, 3]})
    nb_ref = _nb_ref(f"nb-{variable}")
    artifact = Dataset(
        title=title,
        notebook_refs=[nb_ref],
        source_refs=[],
        logical_id=dataset_logical_id(notebook_refs=[nb_ref], variable_name=variable, source_refs=[]),
    ).with_payload(DataFrameObject.from_pandas(df, local_dir=tmp_path / f"_dfo_{variable}"))
    ref, _rel, _etag, _version = await persist_return_artifact(
        user_id=LOCAL_USER_ID,
        workspace_id=workspace_id,
        artifact=artifact,
        kind="dataset",
    )
    return ref


# ---------------------------------------------------------------------------
# Rename
# ---------------------------------------------------------------------------


async def test_rename_virtual_entry_updates_curation_only(workspace_id: str, tmp_path: Path) -> None:
    """Renaming a virtual ``data/<live_name>.parquet`` updates curation, not bytes."""
    ref = await _persist_dataset(workspace_id, tmp_path, title="Original")
    cur_before = await read_curation(LOCAL_USER_ID, workspace_id, "dataset", ref.logical_id)
    assert cur_before is not None
    src_path = f"data/{cur_before.live_name}.parquet"

    csha_before = await latest_content_sha(LOCAL_USER_ID, workspace_id, "dataset", ref.logical_id)

    etag = await service.move_workspace_file_object(LOCAL_USER_ID, workspace_id, src_path, "data/renamed.parquet")
    assert etag

    cur_after = await read_curation(LOCAL_USER_ID, workspace_id, "dataset", ref.logical_id)
    assert cur_after is not None
    assert cur_after.live_name == "renamed"
    # Title unchanged — only live_name moves under rename.
    assert cur_after.title == "Original"

    # Snapshot bytes preserved: same content_sha, same etag-able bytes.
    csha_after = await latest_content_sha(LOCAL_USER_ID, workspace_id, "dataset", ref.logical_id)
    assert csha_after == csha_before

    # Listing reflects the new name; old name is gone.
    paths = {p for p, _, _ in await service.list_workspace_entries(LOCAL_USER_ID, workspace_id)}
    assert "data/renamed.parquet" in paths
    assert src_path not in paths


async def test_rename_collision_with_other_virtual_raises_409_compatible(workspace_id: str, tmp_path: Path) -> None:
    """Two datasets, same kind: renaming into the other's live_name → LiveNameConflict."""
    ref_a = await _persist_dataset(workspace_id, tmp_path, title="Alpha", variable="a")
    _ref_b = await _persist_dataset(workspace_id, tmp_path, title="Beta", variable="b")
    cur_a = await read_curation(LOCAL_USER_ID, workspace_id, "dataset", ref_a.logical_id)
    assert cur_a is not None

    src = f"data/{cur_a.live_name}.parquet"
    dst = "data/beta.parquet"  # already taken by ref_b's live_name

    with pytest.raises(service.LiveNameConflict):
        await service.move_workspace_file_object(LOCAL_USER_ID, workspace_id, src, dst)
    # FileExistsError subclass → existing 409 translation in router applies.
    assert issubclass(service.LiveNameConflict, FileExistsError)


async def test_rename_cross_kind_directory_rejected(workspace_id: str, tmp_path: Path) -> None:
    """``data/foo.parquet`` → ``charts/foo.vl.json`` is meaningless; reject."""
    ref = await _persist_dataset(workspace_id, tmp_path, title="X")
    cur = await read_curation(LOCAL_USER_ID, workspace_id, "dataset", ref.logical_id)
    assert cur is not None
    src = f"data/{cur.live_name}.parquet"

    with pytest.raises(ValueError):
        await service.move_workspace_file_object(LOCAL_USER_ID, workspace_id, src, "charts/x.vl.json")


async def test_rename_drops_extension_change(workspace_id: str, tmp_path: Path) -> None:
    """``data/foo.parquet`` → ``data/foo.csv`` is meaningless; reject."""
    ref = await _persist_dataset(workspace_id, tmp_path, title="X")
    cur = await read_curation(LOCAL_USER_ID, workspace_id, "dataset", ref.logical_id)
    assert cur is not None
    src = f"data/{cur.live_name}.parquet"

    with pytest.raises(ValueError):
        await service.move_workspace_file_object(LOCAL_USER_ID, workspace_id, src, "data/foo.csv")


# ---------------------------------------------------------------------------
# Soft delete
# ---------------------------------------------------------------------------


async def test_delete_virtual_entry_clears_live_name_preserves_snapshots(workspace_id: str, tmp_path: Path) -> None:
    """Soft-delete: live_name → null, snapshots and log untouched."""
    ref = await _persist_dataset(workspace_id, tmp_path, title="Soft Delete Me")
    cur = await read_curation(LOCAL_USER_ID, workspace_id, "dataset", ref.logical_id)
    assert cur is not None
    src_path = f"data/{cur.live_name}.parquet"
    csha_before = await latest_content_sha(LOCAL_USER_ID, workspace_id, "dataset", ref.logical_id)

    ok = await service.delete_workspace_file_object(LOCAL_USER_ID, workspace_id, src_path)
    assert ok is True

    cur_after = await read_curation(LOCAL_USER_ID, workspace_id, "dataset", ref.logical_id)
    assert cur_after is not None
    assert cur_after.live_name is None
    # Snapshot bytes still on disk; embedded refs in chat history keep working.
    csha_after = await latest_content_sha(LOCAL_USER_ID, workspace_id, "dataset", ref.logical_id)
    assert csha_after == csha_before

    # Listing no longer surfaces the entry.
    paths = {p for p, _, _ in await service.list_workspace_entries(LOCAL_USER_ID, workspace_id)}
    assert src_path not in paths


async def test_real_blob_delete_unchanged(workspace_id: str, tmp_path: Path) -> None:
    """Real blobs (e.g. ``notebooks/foo.py``) follow the legacy hard-delete path."""
    await service.write_workspace_file_bytes(LOCAL_USER_ID, workspace_id, "notebooks/foo.py", b"# scratch\n")
    ok = await service.delete_workspace_file_object(LOCAL_USER_ID, workspace_id, "notebooks/foo.py")
    assert ok is True
    # Gone from storage.
    body = await service.read_workspace_file_bytes(LOCAL_USER_ID, workspace_id, "notebooks/foo.py")
    assert body is None


async def test_real_blob_rename_unchanged(workspace_id: str, tmp_path: Path) -> None:
    """Real blob rename routes through legacy blob-move (no curation involvement)."""
    await service.write_workspace_file_bytes(LOCAL_USER_ID, workspace_id, "scratch/a.txt", b"hello")
    etag = await service.move_workspace_file_object(LOCAL_USER_ID, workspace_id, "scratch/a.txt", "scratch/b.txt")
    assert etag
    body = await service.read_workspace_file_bytes(LOCAL_USER_ID, workspace_id, "scratch/b.txt")
    assert body == b"hello"
