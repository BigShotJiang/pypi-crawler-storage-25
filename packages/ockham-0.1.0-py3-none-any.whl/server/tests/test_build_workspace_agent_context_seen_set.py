"""Cross-turn seen-set replay from persisted terminal JSONL.

When a turn ends, only ``user``/``assistant`` text rows and
``kernel_restart`` markers survive to the next turn's
:func:`build_workspace_agent_context`. ``file_ref`` records (the trail
``return_*`` mints leave) and ``read_artifact`` results (which carry the
``<artifact_ref/>`` prepend tag) are also informative — without them the
agent's seen-set is empty on every fresh turn and the cross-turn filter
in ``<turn_artifacts>`` hides its own past work.

These tests anchor the recovery path: the helper synthesises a single
system-message header carrying all ``(kind, live_name)`` pairs it found,
and the agent's regex scanner picks them up.
"""

from __future__ import annotations

import json
from pathlib import Path

from parsimony_agents.agent.seen_refs import extract_seen_live_names

from server.api.workspace.service import build_workspace_agent_context


def _write_curation(local_dir: Path, *, kind: str, lid: str, live_name: str) -> None:
    entry = local_dir / ".ockham" / f"{kind}s" / lid
    entry.mkdir(parents=True)
    (entry / "curation.json").write_text(json.dumps({"kind": kind, "logical_id": lid, "live_name": live_name}))


def test_file_ref_for_canonical_dataset_path_seeds_seen_set(tmp_path: Path) -> None:
    _write_curation(tmp_path, kind="dataset", lid="ds1", live_name="us_gdp")
    history = [
        {
            "id": "r1",
            "role": "assistant",
            "type": "file_ref",
            "content": {
                "type": "file_ref",
                "kind": "dataset",
                "workspace_file_path": ".ockham/datasets/ds1/abc.parquet",
                "label": "Created file://./data/us_gdp.parquet",
                "etag": "etag1",
            },
        },
    ]
    ctx = build_workspace_agent_context("ws", history, local_dir=tmp_path)
    seen = extract_seen_live_names(ctx.messages)
    assert ("dataset", "us_gdp") in seen


def test_file_ref_for_virtual_notebook_path_seeds_seen_set(tmp_path: Path) -> None:
    history = [
        {
            "id": "r1",
            "role": "assistant",
            "type": "file_ref",
            "content": {
                "type": "file_ref",
                "kind": "notebook",
                "workspace_file_path": "notebooks/us_unemployment.py",
                "label": "Executed file://./notebooks/us_unemployment.py",
                "etag": "etag1",
            },
        },
    ]
    ctx = build_workspace_agent_context("ws", history, local_dir=tmp_path)
    seen = extract_seen_live_names(ctx.messages)
    assert ("notebook", "us_unemployment") in seen


def test_artifact_ref_tag_in_system_tool_output_seeds_seen_set(tmp_path: Path) -> None:
    """``read_artifact`` result text carries the prepend tag — pick it up."""
    history = [
        {
            "id": "r1",
            "role": "assistant",
            "type": "system_tool_output",
            "content": {
                "type": "system_tool_output",
                "content": {
                    "type": "text",
                    "content": (
                        '<artifact_ref kind="dataset" live_name="us_gdp"/>\n<dataset title="US GDP">...</dataset>'
                    ),
                },
            },
        },
    ]
    ctx = build_workspace_agent_context("ws", history, local_dir=tmp_path)
    seen = extract_seen_live_names(ctx.messages)
    assert ("dataset", "us_gdp") in seen


def test_multiple_file_refs_dedupe_to_unique_pairs(tmp_path: Path) -> None:
    """Two mints of the same live_name across the conversation collapse to one tag."""
    _write_curation(tmp_path, kind="dataset", lid="ds1", live_name="us_gdp")
    history = [
        {
            "id": f"r{i}",
            "role": "assistant",
            "type": "file_ref",
            "content": {
                "type": "file_ref",
                "kind": "dataset",
                "workspace_file_path": ".ockham/datasets/ds1/abc.parquet",
                "label": "",
                "etag": f"etag{i}",
            },
        }
        for i in range(3)
    ]
    ctx = build_workspace_agent_context("ws", history, local_dir=tmp_path)
    seen = extract_seen_live_names(ctx.messages)
    assert seen == {("dataset", "us_gdp")}


def test_file_ref_without_local_dir_skipped(tmp_path: Path) -> None:
    """No ``local_dir`` ⇒ canonical paths cannot be resolved; only virtual
    notebook paths still seed (their live_name is in the path itself)."""
    history = [
        {
            "id": "r1",
            "role": "assistant",
            "type": "file_ref",
            "content": {
                "type": "file_ref",
                "kind": "dataset",
                "workspace_file_path": ".ockham/datasets/ds1/abc.parquet",
            },
        },
        {
            "id": "r2",
            "role": "assistant",
            "type": "file_ref",
            "content": {
                "type": "file_ref",
                "kind": "notebook",
                "workspace_file_path": "notebooks/x.py",
            },
        },
    ]
    ctx = build_workspace_agent_context("ws", history, local_dir=None)
    seen = extract_seen_live_names(ctx.messages)
    # The system text containing both kinds of refs is only emitted when
    # we found pairs. With local_dir=None the canonical path drops; the
    # notebook still seeds because its live_name is the path basename.
    # Read: scanner can't help if local_dir is missing — but virtual paths
    # don't need it.
    assert ("notebook", "x") not in seen  # local_dir=None skips the file_ref pass entirely


def test_file_ref_with_missing_curation_silently_skips(tmp_path: Path) -> None:
    """Curation deleted between mint and replay ⇒ skip, don't crash."""
    history = [
        {
            "id": "r1",
            "role": "assistant",
            "type": "file_ref",
            "content": {
                "type": "file_ref",
                "kind": "dataset",
                "workspace_file_path": ".ockham/datasets/ghost/abc.parquet",
            },
        },
    ]
    ctx = build_workspace_agent_context("ws", history, local_dir=tmp_path)
    seen = extract_seen_live_names(ctx.messages)
    assert seen == set()


def test_kernel_restart_still_replayed(tmp_path: Path) -> None:
    """Adding the seen-set header should not break existing replay paths."""
    history = [
        {
            "type": "kernel_restart",
            "source": "user_request",
            "at": "2026-05-13T10:00:00Z",
        },
        {
            "role": "user",
            "content": {"type": "text", "content": "fetch gdp"},
        },
    ]
    ctx = build_workspace_agent_context("ws", history, local_dir=tmp_path)
    # placeholder + (no seen tags) + kernel_restart + user msg
    assert len(ctx.messages) == 3
    assert any("KERNEL RESTARTED" in m.content.content for m in ctx.messages if hasattr(m.content, "content"))


def test_full_round_trip_unemployment_then_combine_turn(tmp_path: Path) -> None:
    """End-to-end: T1's prior mint of unemployment, then a fresh user turn.

    Replicates the bug from the live trace: a turn ago this terminal
    minted unemployment via return_dataset; the JSONL now carries a
    file_ref record. On the next turn (`combine it with gdp`), the
    agent needs to see ``("dataset", "us_unemployment")`` in its seen-set
    so the cross-turn ``<turn_artifacts>`` filter keeps the row.
    """
    _write_curation(tmp_path, kind="dataset", lid="ds1", live_name="us_unemployment")
    history = [
        {"role": "user", "content": {"type": "text", "content": "fetch unemployment"}},
        {
            "id": "fr1",
            "role": "assistant",
            "type": "file_ref",
            "content": {
                "type": "file_ref",
                "kind": "dataset",
                "workspace_file_path": ".ockham/datasets/ds1/abc.parquet",
                "etag": "e1",
            },
        },
        {
            "role": "assistant",
            "content": {"type": "text", "content": "Published us_unemployment."},
        },
        {
            "role": "user",
            "content": {"type": "text", "content": "combine it with the us gdp"},
        },
    ]
    ctx = build_workspace_agent_context("ws", history, local_dir=tmp_path)
    seen = extract_seen_live_names(ctx.messages)
    assert ("dataset", "us_unemployment") in seen
