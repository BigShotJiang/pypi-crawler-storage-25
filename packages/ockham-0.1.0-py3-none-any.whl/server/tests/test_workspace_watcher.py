"""Workspace watcher + ETag substrate tests.

Covers the file-change substrate end-to-end:

* ``compute_etag`` is content-derived and stable: identical bytes → identical
  etag; different bytes → different etag.
* The ``watcher`` emits ``(path, etag, op)`` events for writes that land on
  disk via :mod:`server.api.workspace.service`, regardless of caller.
* Multiple subscribers see the same event (fanout).
* ``.ockham/`` writes are filtered by default.
* ``.tmp`` scratch files (atomic-rename two-phase write) never leak.
* The HTTP file GET returns ``ETag`` and honors ``If-None-Match`` with 304.
"""

from __future__ import annotations

import asyncio
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from server.api.main import app
from server.api.middleware import LOCAL_USER_ID
from server.api.workspace import service, watcher
from server.api.workspace.etag import compute_etag
from server.api.workspace.router import workspace_events


def _headers() -> dict[str, str]:
    return {"Host": "localhost:8000"}


USER_ID = LOCAL_USER_ID


@pytest.fixture
async def reset_watchers():
    yield
    await watcher.reset_for_tests()


@pytest.fixture
def client(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> TestClient:
    ws_root = tmp_path / "workspaces"
    ws_root.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("OCKHAM_DATA_DIR", str(tmp_path))
    return TestClient(app)


# ---------- ETag


def test_etag_is_content_derived_and_stable() -> None:
    a1 = compute_etag(b"hello")
    a2 = compute_etag(b"hello")
    b = compute_etag(b"world")
    assert a1 == a2
    assert a1 != b
    assert a1.startswith("b2-")


# ---------- Watcher


async def _drain(q: asyncio.Queue, n: int, timeout: float = 2.0) -> list[dict]:
    out: list[dict] = []
    deadline = asyncio.get_event_loop().time() + timeout
    while len(out) < n:
        remaining = deadline - asyncio.get_event_loop().time()
        if remaining <= 0:
            break
        try:
            event = await asyncio.wait_for(q.get(), timeout=remaining)
        except TimeoutError:
            break
        out.append(event)
    return out


async def test_watcher_emits_event_for_service_write(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    reset_watchers,
) -> None:
    ws_root = tmp_path / "workspaces"
    ws_root.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("OCKHAM_DATA_DIR", str(tmp_path))

    wid = "w1"
    (ws_root / USER_ID / wid).mkdir(parents=True, exist_ok=True)

    w = await watcher._get_or_create(USER_ID, wid)
    q = w.add_subscriber()
    try:
        await asyncio.sleep(0.05)
        body = b"hello world"
        await service.write_workspace_file_bytes(USER_ID, wid, "data/x.txt", body)
        events = await _drain(q, 1)
        assert events, "watcher emitted no event for the write"
        ev = events[-1]
        assert ev["path"] == "data/x.txt"
        assert ev["etag"] == compute_etag(body)
        assert ev["op"] in ("created", "modified")
    finally:
        w.remove_subscriber(q)


async def test_watcher_filters_ockham_by_default(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    reset_watchers,
) -> None:
    ws_root = tmp_path / "workspaces"
    ws_root.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("OCKHAM_DATA_DIR", str(tmp_path))

    wid = "w2"
    (ws_root / USER_ID / wid).mkdir(parents=True, exist_ok=True)

    w = await watcher._get_or_create(USER_ID, wid)
    q = w.add_subscriber()
    try:
        await asyncio.sleep(0.05)
        await service.write_workspace_file_bytes(USER_ID, wid, ".ockham/outputs/y.json", b"{}", allow_ockham=True)
        await service.write_workspace_file_bytes(USER_ID, wid, "visible.txt", b"v")
        events = await _drain(q, 2, timeout=1.0)
        paths = [e["path"] for e in events]
        assert "visible.txt" in paths
        assert all(not p.startswith(".ockham/") for p in paths)
    finally:
        w.remove_subscriber(q)


async def test_watcher_emits_notebook_state_cache_changes(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    reset_watchers,
) -> None:
    ws_root = tmp_path / "workspaces"
    ws_root.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("OCKHAM_DATA_DIR", str(tmp_path))

    wid = "w2b"
    (ws_root / USER_ID / wid).mkdir(parents=True, exist_ok=True)

    w = await watcher._get_or_create(USER_ID, wid)
    q = w.add_subscriber()
    try:
        await asyncio.sleep(0.05)
        await service.write_workspace_file_bytes(
            USER_ID,
            wid,
            ".ockham/notebook-state/abc.json",
            b"{}",
            allow_ockham=True,
        )
        events = await _drain(q, 1, timeout=1.0)
        assert events
        assert events[-1]["path"] == ".ockham/notebook-state/abc.json"
        assert events[-1]["etag"]
    finally:
        w.remove_subscriber(q)


async def test_watcher_no_tmp_leak(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    reset_watchers,
) -> None:
    ws_root = tmp_path / "workspaces"
    ws_root.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("OCKHAM_DATA_DIR", str(tmp_path))

    wid = "w3"
    (ws_root / USER_ID / wid).mkdir(parents=True, exist_ok=True)

    w = await watcher._get_or_create(USER_ID, wid)
    q = w.add_subscriber()
    try:
        await asyncio.sleep(0.05)
        await service.write_workspace_file_bytes(USER_ID, wid, "data/atomic.txt", b"abc")
        events = await _drain(q, 5, timeout=0.5)
        for e in events:
            assert not e["path"].endswith(".tmp")
    finally:
        w.remove_subscriber(q)


async def test_watcher_fans_out_to_multiple_subscribers(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    reset_watchers,
) -> None:
    ws_root = tmp_path / "workspaces"
    ws_root.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("OCKHAM_DATA_DIR", str(tmp_path))

    wid = "w4"
    (ws_root / USER_ID / wid).mkdir(parents=True, exist_ok=True)

    w = await watcher._get_or_create(USER_ID, wid)
    q1 = w.add_subscriber()
    q2 = w.add_subscriber()
    try:
        await asyncio.sleep(0.05)
        await service.write_workspace_file_bytes(USER_ID, wid, "k.txt", b"k")
        e1 = await _drain(q1, 1)
        e2 = await _drain(q2, 1)
        assert e1 and e2
        assert e1[-1]["path"] == e2[-1]["path"] == "k.txt"
        assert e1[-1]["etag"] == e2[-1]["etag"]
    finally:
        w.remove_subscriber(q1)
        w.remove_subscriber(q2)


async def test_watcher_subscriber_disconnect_keeps_others(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    reset_watchers,
) -> None:
    ws_root = tmp_path / "workspaces"
    ws_root.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("OCKHAM_DATA_DIR", str(tmp_path))

    wid = "w5"
    (ws_root / USER_ID / wid).mkdir(parents=True, exist_ok=True)

    w = await watcher._get_or_create(USER_ID, wid)
    q1 = w.add_subscriber()
    q2 = w.add_subscriber()
    w.remove_subscriber(q1)
    try:
        await asyncio.sleep(0.05)
        await service.write_workspace_file_bytes(USER_ID, wid, "after.txt", b"a")
        e2 = await _drain(q2, 1)
        assert e2 and e2[-1]["path"] == "after.txt"
        assert w.subscriber_count == 1
    finally:
        w.remove_subscriber(q2)


# ---------- HTTP ETag


def test_http_get_returns_etag_and_supports_304(client: TestClient) -> None:
    h = _headers()
    r = client.post("/api/workspaces", json={"title": "E"}, headers=h)
    wid = r.json()["id"]

    body = b"hello-etag"
    r = client.put(
        f"/api/workspaces/{wid}/files/data/x.txt",
        content=body,
        headers={**h, "Content-Type": "application/octet-stream"},
    )
    assert r.status_code == 204
    put_etag = r.headers.get("ETag")
    assert put_etag and put_etag.strip('"') == compute_etag(body)

    r = client.get(f"/api/workspaces/{wid}/files/data/x.txt", headers=h)
    assert r.status_code == 200
    get_etag = r.headers.get("ETag")
    assert get_etag == put_etag
    assert r.content == body

    r = client.get(
        f"/api/workspaces/{wid}/files/data/x.txt",
        headers={**h, "If-None-Match": put_etag},
    )
    assert r.status_code == 304
    assert r.headers.get("ETag") == put_etag


def test_http_get_etag_changes_on_overwrite(client: TestClient) -> None:
    h = _headers()
    r = client.post("/api/workspaces", json={"title": "F"}, headers=h)
    wid = r.json()["id"]

    r1 = client.put(
        f"/api/workspaces/{wid}/files/n.txt",
        content=b"v1",
        headers={**h, "Content-Type": "application/octet-stream"},
    )
    r2 = client.put(
        f"/api/workspaces/{wid}/files/n.txt",
        content=b"v2",
        headers={**h, "Content-Type": "application/octet-stream"},
    )
    assert r1.headers["ETag"] != r2.headers["ETag"]


async def test_http_events_route_opens_sse_stream(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    reset_watchers,
) -> None:
    ws_root = tmp_path / "workspaces"
    ws_root.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("OCKHAM_DATA_DIR", str(tmp_path))
    workspace = await service.create_workspace(USER_ID, "Events")
    (ws_root / USER_ID / workspace.id).mkdir(parents=True, exist_ok=True)

    class _Request:
        async def is_disconnected(self) -> bool:
            return False

    response = await workspace_events(workspace.id, _Request(), user_id=USER_ID)  # type: ignore[arg-type]
    try:
        assert response.media_type == "text/event-stream"
        assert response.headers["cache-control"] == "no-cache, no-transform"
        assert response.headers["x-accel-buffering"] == "no"
        assert await anext(response.body_iterator) in (": ok\n\n", b": ok\n\n")
    finally:
        await response.body_iterator.aclose()
