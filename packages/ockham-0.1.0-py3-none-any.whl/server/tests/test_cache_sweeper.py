import os
import time
from pathlib import Path

import pytest

from server.api.config import config
from server.core.cache import run_sweep_once


def _write_bytes(path: Path, size: int) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(b"x" * size)


def test_cache_sweeper_ttl_eviction(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setenv("OCKHAM_CACHE_DIR", str(tmp_path))
    sessions = tmp_path / "sessions"
    old_file = sessions / "s1" / "old.parquet"
    fresh_file = sessions / "s1" / "fresh.parquet"

    _write_bytes(old_file, 32)
    _write_bytes(fresh_file, 32)

    now = time.time()
    old_mtime = now - 7200
    fresh_mtime = now - 60
    os.utime(old_file, (old_mtime, old_mtime))
    os.utime(fresh_file, (fresh_mtime, fresh_mtime))

    original_session_age = config.SESSION_CACHE_MAX_AGE_SECONDS
    original_session_bytes = config.SESSION_CACHE_MAX_BYTES
    try:
        config.SESSION_CACHE_MAX_AGE_SECONDS = 3600
        config.SESSION_CACHE_MAX_BYTES = 10_000

        stats = run_sweep_once()
        assert len(stats) == 1
        assert not old_file.exists()
        assert fresh_file.exists()
    finally:
        config.SESSION_CACHE_MAX_AGE_SECONDS = original_session_age
        config.SESSION_CACHE_MAX_BYTES = original_session_bytes


def test_cache_sweeper_size_cap_eviction(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setenv("OCKHAM_CACHE_DIR", str(tmp_path))
    sessions = tmp_path / "sessions"

    oldest = sessions / "s1" / "oldest.parquet"
    middle = sessions / "s1" / "middle.parquet"
    newest = sessions / "s1" / "newest.parquet"
    _write_bytes(oldest, 50)
    _write_bytes(middle, 50)
    _write_bytes(newest, 50)

    now = time.time()
    os.utime(oldest, (now - 300, now - 300))
    os.utime(middle, (now - 200, now - 200))
    os.utime(newest, (now - 100, now - 100))

    original_session_age = config.SESSION_CACHE_MAX_AGE_SECONDS
    original_session_bytes = config.SESSION_CACHE_MAX_BYTES
    try:
        config.SESSION_CACHE_MAX_AGE_SECONDS = 10_000
        config.SESSION_CACHE_MAX_BYTES = 100

        run_sweep_once()
        assert not oldest.exists()
        assert middle.exists()
        assert newest.exists()
    finally:
        config.SESSION_CACHE_MAX_AGE_SECONDS = original_session_age
        config.SESSION_CACHE_MAX_BYTES = original_session_bytes
