"""Registry-backed read projections for `read_artifact` / `artifact_llm`."""

from __future__ import annotations

import pandas as pd
from parsimony.result import Provenance, Result

from server.api.workspace.artifact_llm import read_artifact_for_llm, read_artifact_to_llm_result
from server.api.workspace.artifact_projection import ArtifactReadRequest
from server.api.workspace.artifact_read_projections import dataset_read_projection, read_projection_for_kind


def _parquet_bytes(tmp_path, *, n: int = 5) -> bytes:
    df = pd.DataFrame({"a": list(range(n))})
    r = Result(
        data=df,
        provenance=Provenance(source="src", source_description="src"),
    )
    p = tmp_path / "d.parquet"
    r.to_parquet(str(p))
    return p.read_bytes()


def test_dataset_outline_is_schema_not_row_dump(tmp_path) -> None:
    raw = _parquet_bytes(tmp_path)
    pr = dataset_read_projection(raw, "data/d.parquet", ArtifactReadRequest(path="data/d.parquet", view="outline"))
    assert "row_count" in pr.text
    assert "<col " in pr.text
    # row dump is page-only
    assert "dataset_rows" not in pr.text


def test_dataset_page_has_next_locator(tmp_path) -> None:
    raw = _parquet_bytes(tmp_path, n=60)
    pr = read_projection_for_kind(
        "dataset",
        raw,
        "data/d.parquet",
        ArtifactReadRequest(path="data/d.parquet", view="page", locator=None),
    )
    assert "dataset_rows" in pr.text
    assert pr.next_locator is not None
    assert pr.next_locator.kind == "rows"


def test_read_artifact_for_llm_notebook_summary_not_full_code() -> None:
    code = '"""One-liner for tests."""\n# Section\n\ndef f():\n  return 1\n'
    raw = code.encode("utf-8")
    text = read_artifact_for_llm("notebooks/t.py", raw, mode="summary")
    assert "One-liner" in text
    assert "return 1" not in text


def test_read_artifact_to_llm_chart_spec_locator_is_text_not_image() -> None:
    from parsimony_agents.artifacts import Chart
    from parsimony_agents.chart_io import write_chart_bytes
    from parsimony_agents.execution.outputs import FigureObject

    spec: dict = {
        "$schema": "https://vega.github.io/schema/vega-lite/v5.json",
        "data": {"values": [{"a": 1}]},
        "mark": "point",
        "encoding": {"x": {"field": "a", "type": "quantitative"}},
    }
    ch = Chart(title="C", provenance=Provenance(source="s", source_description="s"))
    raw = write_chart_bytes(ch, FigureObject(value=spec, name="c"))
    res = read_artifact_to_llm_result(
        "c.vl.json",
        raw,
        {"view": "full", "mode": None, "locator": {"kind": "chart_spec", "offset": 0, "limit": 50}},
    )
    assert res.kernel_output is None
    assert "chart_spec" in res.text


def test_read_artifact_to_llm_chart_full_gives_figure() -> None:
    from parsimony_agents.artifacts import Chart
    from parsimony_agents.chart_io import write_chart_bytes
    from parsimony_agents.execution.outputs import FigureObject

    spec: dict = {
        "$schema": "https://vega.github.io/schema/vega-lite/v5.json",
        "data": {"values": [{"a": 1, "b": 2}]},
        "mark": "point",
        "encoding": {
            "x": {"field": "a", "type": "quantitative"},
            "y": {"field": "b", "type": "quantitative"},
        },
    }
    ch = Chart(title="C", provenance=Provenance(source="s", source_description="s"))
    raw = write_chart_bytes(ch, FigureObject(value=spec, name="c"))
    res = read_artifact_to_llm_result("c.vl.json", raw, {"view": "full", "mode": None, "locator": None})
    assert res.kernel_output is not None
    assert res.kernel_output.get_figures()
