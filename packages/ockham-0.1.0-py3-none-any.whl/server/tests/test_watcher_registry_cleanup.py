"""Watcher removes its registry key when the background task ends."""

from __future__ import annotations

import asyncio
from pathlib import Path

import pytest

from server.api.workspace import watcher
from server.api.workspace.storage import workspace_local_tree_path


@pytest.mark.asyncio
async def test_watcher_pops_registry_when_task_ends(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("OCKHAM_DATA_DIR", str(tmp_path))
    monkeypatch.setattr(watcher, "GRACE_STOP_MS", 1)
    try:
        uid, wsid = "u1", "ws1"
        root = workspace_local_tree_path(uid, wsid)
        root.mkdir(parents=True)
        w = await watcher._get_or_create(uid, wsid)
        assert (uid, wsid) in watcher._REGISTRY
        q = w.add_subscriber()
        w.remove_subscriber(q)
        await asyncio.sleep(0.35)
        assert (uid, wsid) not in watcher._REGISTRY
    finally:
        await watcher.reset_for_tests()
