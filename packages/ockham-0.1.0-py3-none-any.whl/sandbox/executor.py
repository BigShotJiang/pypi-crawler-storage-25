## a fastapi server that can execute code in a sandbox

import asyncio
import contextlib
import logging
import os
import time
import uuid
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Optional

from dotenv import load_dotenv
from fastapi import Body, FastAPI, HTTPException
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, Response
from pydantic import BaseModel

from parsimony_agents.agent.session_state import kernel_summaries_from_locals_map
from parsimony_agents.execution import KernelOutput
from parsimony_agents.execution.executor import CodeExecutor
from parsimony_agents.execution.factory import OutputFactory
logger = logging.getLogger(__name__)

# Load environment variables from .env file
# Priority: sandbox/.env then root .env
load_dotenv(override=False)

_SANDBOX_DIR = os.environ.get("SANDBOX_FILES_DIR", "/tmp/sandbox_sessions")

# Idle executors are removed after this many seconds without use.
EXECUTOR_IDLE_TTL_S = int(os.environ.get("EXECUTOR_IDLE_TTL_S", "300"))
_REAPER_INTERVAL_S = 60

executors: dict[str, CodeExecutor] = {}
executor_last_used: dict[str, float] = {}
# In-flight request tasks per executor; cancelled on delete / TTL so work does not outlive kernel removal.
active_executor_tasks: dict[str, set[asyncio.Task]] = {}

_output_factory: OutputFactory | None = None


def _get_output_factory() -> OutputFactory:
    global _output_factory
    if _output_factory is None:
        _output_factory = OutputFactory(local_dir=_SANDBOX_DIR)
    return _output_factory


def _touch(executor_id: str) -> None:
    executor_last_used[executor_id] = time.time()


@contextlib.asynccontextmanager
async def _track_active_work(executor_id: str) -> AsyncIterator[None]:
    task = asyncio.current_task()
    if task is not None:
        active_executor_tasks.setdefault(executor_id, set()).add(task)
    try:
        yield
    finally:
        if task is not None:
            st = active_executor_tasks.get(executor_id)
            if st and task in st:
                st.discard(task)
                if not st:
                    active_executor_tasks.pop(executor_id, None)


async def _remove_executor_async(executor_id: str) -> None:
    """Drop an executor: cancel in-flight work, then remove from registries."""
    to_cancel: list[asyncio.Task] = list(active_executor_tasks.get(executor_id, ()))
    for t in to_cancel:
        t.cancel()
    if to_cancel:
        await asyncio.gather(*to_cancel, return_exceptions=True)
    executors.pop(executor_id, None)
    executor_last_used.pop(executor_id, None)
    active_executor_tasks.pop(executor_id, None)
    logger.info(
        "Executor removed and in-flight work drained",
        extra={"executor_id": executor_id, "cancelled_count": len(to_cancel)},
    )


async def _reaper_loop() -> None:
    while True:
        await asyncio.sleep(_REAPER_INTERVAL_S)
        now = time.time()
        stale = [
            eid
            for eid, last in executor_last_used.items()
            if now - last > EXECUTOR_IDLE_TTL_S
        ]
        for eid in stale:
            await _remove_executor_async(eid)


@asynccontextmanager
async def _lifespan(app: FastAPI):
    task = asyncio.create_task(_reaper_loop())
    yield
    task.cancel()
    try:
        await task
    except asyncio.CancelledError:
        pass


app = FastAPI(lifespan=_lifespan)


class ExecuteRequest(BaseModel):
    code: str
    dry_run: bool = False
    workspace_mode: bool = False
    producer_notebook_path: Optional[str] = None
    #: Calling terminal's snapshot of ``(kind, live_name)`` pairs, serialised
    #: as ``[[kind, live_name], ...]`` because JSON has no set/tuple. The
    #: sandbox rehydrates it to ``set[tuple[str, str]]`` before passing into
    #: the in-process executor, where ``load_dataset`` consults it to gate
    #: cross-terminal slug resolution. ``None`` ⇒ no gate (legacy callers).
    seen_live_names: Optional[list[list[str]]] = None


class FileEntry(BaseModel):
    path: str
    size_bytes: int


class EvalRequest(BaseModel):
    expr: str
    dry_run: bool = False


class SqlRequest(BaseModel):
    sql_query: str


class SetCwdRequest(BaseModel):
    cwd: str
    session_id: Optional[str] = None


@app.post("/executors")
async def create_executor():
    eid = str(uuid.uuid4())
    executors[eid] = CodeExecutor(cwd=_SANDBOX_DIR, output_factory=_get_output_factory())
    _touch(eid)
    return {"id": eid}


@app.post("/executors/{id}/set_cwd")
async def set_cwd(id: str, req: SetCwdRequest):
    if id not in executors:
        raise HTTPException(status_code=404, detail="Executor not found")
    _touch(id)
    async with _track_active_work(id):
        await executors[id].set_cwd(req.cwd, req.session_id)
    return {"status": "ok"}


@app.post("/executors/{id}/execute")
async def execute(id: str, req: ExecuteRequest) -> KernelOutput:
    if id not in executors:
        raise HTTPException(status_code=404, detail="Executor not found")
    _touch(id)
    # Rehydrate the seen-set from JSON-friendly ``list[list[str]]`` into the
    # ``set[tuple[str, str]]`` shape the in-process executor expects.
    seen = (
        {(pair[0], pair[1]) for pair in req.seen_live_names if len(pair) == 2}
        if req.seen_live_names is not None
        else None
    )
    async with _track_active_work(id):
        if req.workspace_mode:
            return await executors[id].execute_workspace(
                req.code,
                dry_run=req.dry_run,
                producer_notebook_path=req.producer_notebook_path,
                seen_live_names=seen,
            )
        return await executors[id].execute(
            req.code,
            dry_run=req.dry_run,
            producer_notebook_path=req.producer_notebook_path,
            seen_live_names=seen,
        )


@app.post("/executors/{id}/eval")
async def eval_expr(id: str, req: EvalRequest) -> KernelOutput:
    if id not in executors:
        raise HTTPException(status_code=404, detail="Executor not found")
    _touch(id)
    async with _track_active_work(id):
        return await executors[id].eval(req.expr, dry_run=req.dry_run)


@app.post("/executors/{id}/set_connectors")
async def set_connectors(id: str):
    """Build connectors from environment variables and inject into the executor."""
    if id not in executors:
        raise HTTPException(status_code=404, detail="Executor not found")
    _touch(id)
    from server.connectors import build_agent_connectors

    async with _track_active_work(id):
        connectors = build_agent_connectors(env=dict(os.environ))
        await executors[id].set_connectors(connectors)
    return {"status": "ok"}


@app.get("/executors/{id}/files", response_model=list[FileEntry])
async def list_workspace_files(id: str, prefix: str = "") -> list[FileEntry]:
    if id not in executors:
        raise HTTPException(status_code=404, detail="Executor not found")
    _touch(id)
    async with _track_active_work(id):
        rows = await executors[id].list_workspace_files(prefix)
    return [FileEntry(path=p, size_bytes=s) for p, s in rows]


@app.post("/executors/{id}/files/{path:path}")
async def write_workspace_file(id: str, path: str, body: bytes = Body(...)) -> dict[str, str]:
    if id not in executors:
        raise HTTPException(status_code=404, detail="Executor not found")
    _touch(id)
    async with _track_active_work(id):
        await executors[id].write_workspace_file(path, body)
    return {"status": "ok"}


@app.get("/executors/{id}/files/{path:path}")
async def read_workspace_file(id: str, path: str) -> Response:
    if id not in executors:
        raise HTTPException(status_code=404, detail="Executor not found")
    _touch(id)
    async with _track_active_work(id):
        try:
            data = await executors[id].read_workspace_file(path)
        except FileNotFoundError:
            raise HTTPException(status_code=404, detail="File not found") from None
    return Response(content=data, media_type="application/octet-stream")


@app.delete("/executors/{id}/files/{path:path}")
async def delete_workspace_file(id: str, path: str) -> dict[str, str]:
    if id not in executors:
        raise HTTPException(status_code=404, detail="Executor not found")
    _touch(id)
    async with _track_active_work(id):
        await executors[id].delete_workspace_file(path)
    return {"status": "ok"}


@app.post("/executors/{id}/execute_sql")
async def execute_sql(id: str, req: SqlRequest) -> KernelOutput:
    if id not in executors:
        raise HTTPException(status_code=404, detail="Executor not found")
    _touch(id)
    async with _track_active_work(id):
        return await executors[id].execute_sql(req.sql_query)


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request, exc: RequestValidationError):
    """Custom handler to log validation errors with full details."""
    logger.error(f"Validation error on {request.url.path}: {exc.errors()}")
    return JSONResponse(status_code=422, content={"detail": exc.errors()})


@app.get("/executors/{id}/ping")
async def ping_executor(id: str) -> dict[str, bool]:
    """Lightweight liveness check for the workspace router cache."""
    if id not in executors:
        raise HTTPException(status_code=404, detail="Executor not found")
    _touch(id)
    async with _track_active_work(id):
        return {"ok": True}


@app.post("/executors/{id}/clear_namespace")
async def clear_namespace(id: str) -> dict[str, str]:
    if id not in executors:
        raise HTTPException(status_code=404, detail="Executor not found")
    _touch(id)
    async with _track_active_work(id):
        await executors[id].clear_namespace()
    return {"status": "ok"}


@app.get("/executors/{id}/origin")
async def get_origin(id: str, name: str):
    """Return the :class:`VariableOrigin` for *name*, or ``null``."""
    if id not in executors:
        raise HTTPException(status_code=404, detail="Executor not found")
    _touch(id)
    async with _track_active_work(id):
        origin = await executors[id].get_origin(name)
    return origin.to_dict() if origin is not None else None


@app.get("/executors/{id}/get")
async def get(id: str, key: str):
    if id not in executors:
        raise HTTPException(status_code=404, detail="Executor not found")
    _touch(id)
    async with _track_active_work(id):
        return await executors[id].get(key)


@app.get("/executors/{id}/locals")
async def get_locals(id: str):
    if id not in executors:
        raise HTTPException(status_code=404, detail="Executor not found")
    _touch(id)

    async with _track_active_work(id):
        l = executors[id].get_locals()

    rows = kernel_summaries_from_locals_map(l)
    return [r.model_dump(mode="json") for r in rows]


@app.delete("/executors/{id}")
async def delete_executor(id: str):
    await _remove_executor_async(id)
    return {"status": "ok"}


@app.get("/health")
async def health():
    """Health check endpoint for the sandbox executor."""
    return {"status": "ok"}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8001)
