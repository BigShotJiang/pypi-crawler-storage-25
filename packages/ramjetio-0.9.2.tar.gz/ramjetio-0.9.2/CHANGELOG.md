# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

> **Note.** v0.9.0 is the first publicly released version. Any pre-0.9 development history has been removed from this file because nothing before 0.9.0 was distributed to users.

## [Unreleased]

### Added
- **Per-run session view for cumulative metrics.** New "This run / All time" toggle on Cluster Detail page. Cumulative counters (hits/misses, bytes_local/peer/s3, single-flight totals) render `current − baseline` in This-run mode. Baselines are auto-snapshotted when `training_started_at` flips and persisted server-side (migration `011_add_session_baselines.sql`, 13 nullable columns on `nodes`). Frontend prefers server baseline, falls back to localStorage. Manual "↻ Reset" button re-snapshots on demand.

### Fixed
- **Heartbeat flicker on Cluster Detail.** `is_training` and DDP role flags now require an active training signal (`current_step > 0` or `epoch > 0`) within a 30 s grace window before the backend persists a new session-start, preventing brief offline→online transitions from spuriously toggling training state. Frontend `mergeNodeMetrics` mirrors the same gating so optimistic UI updates stay sticky.

## [0.9.2] - 2026-05-05

### Added
- **MultiGet batch endpoint (Phase Q.5).**  Cache server now exposes `POST /mget` when `RAMJET_MULTIGET=1` is set. `DistributedCache.multi_get(keys)` groups keys by ring owner and issues one HTTP request per peer instead of N serial GETs. Falls back to per-key `get()` on 501/404/error. `/stats` response includes `multiget_enabled`.
- **CRC32 integrity envelope (Phase Q.1).**  Every cache frame is now wrapped with a 4-byte CRC32 checksum. Corrupted frames are detected on read and trigger a cache-miss (re-fetch from S3) rather than silently returning bad data.
- **Exponential backoff for peer connects (Phase Q.2).**  Peer-to-peer cache connections retry with full-jitter exponential backoff (base 0.1 s, cap 30 s) instead of hammering on a down peer.
- **`RAMJET_BACKEND_HOST` live-read (Phase Q.3).**  SDK resolves the backend host from env at gRPC dial time, not at import time, so containers can override host without restart.
- **p50 / p99 latency tracking (Phase Q.4).**  Cache server `/stats` now reports `p50_ms` and `p99_ms` fetch latencies via a 1 000-sample rolling window. Dashboard surfaces these as `CacheMetrics` cards.

### Changed
- **Version bump 0.9.1 → 0.9.2** in `ramjetio/__init__.py` and `pyproject.toml`.
- **SEO sweep (Phase L).**  `frontend/index.html` title/description/OG tags updated ("RAMJET.IO Console — Distributed peer cache for ML training data"). `landing/index.html` updated to "Stop paying S3 egress for the same dataset twice". `mkdocs.yml` `site_description` synced. Private JSON-LD repo URL removed from landing page.
- **OG image** (`landing/public/og-image.png`) — 1 200 × 630 px, 153 KB.
- **Hero animation** (`landing/src/components/HeroAnimation.tsx`) — animated race-bar comparing cold S3 vs warm peer cache.

### Performance (validated on real hardware — fresh cluster, prod backend)
- 2× RTX A5000, YOLOv8n, 5315 samples, 3 epochs DDP world_size=2, `grpc.ramjet.io:443`, S3-compatible origin:
  - **Cold run (all S3):** export 173.0 s, total 300.8 s — 2658/2658 samples from S3.
  - **Warm run (local_fs cache):** export **0.074 s**, total **122.6 s** — 2658/2658 from local disk cache.
  - **Export speedup: 2338×. Total job speedup: 2.45×.**
  - **`RAMJET_MULTIGET=1` warm run:** export 0.095 s, total 123.4 s — parity with warm baseline; MultiGet overhead negligible when dataset is fully local-fs-cached (peer batching is beneficial in cross-node cache-miss scenarios).

### Tests
- SDK: **318 / 318** (↑ from 270 in 0.9.0).
- Backend: **183 / 183**.
- Frontend (vitest): **47 / 47**.
- TypeScript: clean (`tsc --noEmit`).

## [0.9.1] - 2026-04-28

### Fixed
- **Heartbeat re-register storm.** `_node_refresh_loop` previously called the module-level `get_cluster_nodes()` helper every 10 s, which spun up a fresh `BackendClient` and re-issued `RegisterNode` on each tick. Symptoms: ~21 spurious registrations per 3-minute run, dashboard cards flickering as the backend broadcast `node_updated` events on every refresh. Fixed by reusing the already-connected long-lived client's stub in `_discover_nodes` and by removing the silent auto-`connect()` from `BackendClient.get_cluster_nodes` (the instance method now returns `[]` if not connected; the module-level helper still creates a transient client for explicit one-shot lookups).
- **`[Rank 0]` in every node's logs.** `dataset.export_local()` defaulted to `rank=0, world_size=1` when called without args (as in `train.py`), so both DDP nodes processed the entire dataset and labelled their progress logs identically. `export_local` now auto-detects rank/world_size from the standard `RANK` / `WORLD_SIZE` env vars (set by torchrun, SLURM, DeepSpeed). Behaviour change: callers that relied on the implicit single-rank default still work — the env defaults to 0/1.
- **`Connection pool is full` warnings during cold S3 export.** Bumped boto3 `max_pool_connections` from urllib3's default (10) to 32 to match the parallel fetcher's `S3_WORKERS=16`.

### Performance (validated on real hardware)
- 2× RTX A5000, YOLOv8n, 5315 samples, 1 epoch DDP world_size=2, prod backend `grpc.ramjet.io:443`, MinIO via cloudflare tunnel:
  - **EXPORT phase 5.7× faster on warm cache**: 283.2 s (S3 only) → 49.4 s (warm distributed cache, 0 S3 calls).
  - **Total pipeline 2.2× faster**: 431.6 s → 194.5 s.
  - Cold-cache run (A2) already serves ~50% of fetches via peer cache during the first export; A3 confirms ring symmetry — rank 0 has 2567 local + 2748 peer, rank 1 has 2748 local + 2567 peer, perfectly mirrored.

## [0.9.0] - 2026-04-28

Initial public release.

### Added
- **Distributed peer cache** between any ML training job and any S3-compatible object store. PyTorch / TensorFlow / JAX / HuggingFace Datasets / Ultralytics — anything that pulls data from S3, MinIO, GCS, R2 or HTTP.
- **`UniversalDataset`** with format handlers: YOLO (detect / segment / pose / obb / classify), COCO, ImageFolder, semantic segmentation, text classification / NER / seq2seq, tabular regression / classification.
- **DDP-native** `export_local()` shards by `RANK` / `WORLD_SIZE` from torchrun / SLURM / DeepSpeed env. Multi-node verified on 2× A5000.
- **Graceful drain & decommission** — `DrainNode` / `CancelDrain` RPCs push a node's keys to its future ring owners before removal. Lifecycle reported via heartbeat (`drain_state`, `drain_total/done/errors`); SDK exposes `/drain`, `/drain/status`, `/drain/cancel` HTTP endpoints (auth-gated).
- **Per-source metrics** — `cache_hits_local` / `cache_hits_peer` / `cache_hits_s3`, singleflight leaders/waiters/wait-hits/wait-timeouts, `ddp_local_rank`, `ranks_reporting`. Surfaced in dashboard cards `SourcePathBreakdown` and `SingleflightHealth`.
- **Resilience primitives** — deterministic consistent-hash ring (`bisect.insort`), version-monotonic config propagation via heartbeat, origin circuit breaker (closed/open/half-open + `RAMJET_CIRCUIT_*` env), hardened `shutdown()` + `atexit`, exponential-backoff reconnect with jitter.
- **Security** — SSRF guards (SDK `url_validation.py` mirrored on backend), `RAMJET_API_KEY` enforced on every cache server endpoint.
- **Observability** — `/diagnostics` endpoint (server / singleflight / circuit / backend / drain buckets), `DegradedBanner`, `SingleflightHealth`.
- **Validation suite** — ~270 SDK tests (incl. E2E multinode, chaos, 24h soak, fork safety, cross-rank topology sync), 181 backend tests against real Postgres, 46 frontend tests.

### Released artifacts
- AWS EC2 prod stack (3.227.253.38) with RDS Postgres + nginx + envoy + grafana.
- Live odin DDP run on prod backend (cluster `4311937c-...`); cloudflare-tunneled MinIO.

[Unreleased]: https://github.com/jogrms/nxgeninc/compare/v0.9.2...HEAD
[0.9.2]: https://github.com/jogrms/nxgeninc/compare/v0.9.1...v0.9.2
[0.9.1]: https://github.com/jogrms/nxgeninc/compare/v0.9.0...v0.9.1
[0.9.0]: https://github.com/jogrms/nxgeninc/releases/tag/v0.9.0
