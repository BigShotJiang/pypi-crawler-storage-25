# Examples

Runnable scripts in [`ramjetio/examples/`](https://github.com/jogrms/nxgeninc/tree/main/ramjetio/examples) on GitHub.

## simple.py

Minimal end-to-end example: `ramjetio.init()` + a tiny training loop. Best starting point.

[View source](https://github.com/jogrms/nxgeninc/blob/main/ramjetio/examples/simple.py)

## torchrun_ddp.py

Multi-node distributed training with `torchrun`. RAMJET auto-detects ranks; no extra wiring needed.

```bash
torchrun --nnodes=2 --nproc_per_node=4 examples/torchrun_ddp.py
```

[View source](https://github.com/jogrms/nxgeninc/blob/main/ramjetio/examples/torchrun_ddp.py)

## accelerate_example.py

HuggingFace [Accelerate](https://huggingface.co/docs/accelerate/) integration. Drop-in compatible.

```bash
accelerate launch examples/accelerate_example.py
```

[View source](https://github.com/jogrms/nxgeninc/blob/main/ramjetio/examples/accelerate_example.py)

## deepspeed_example.py

DeepSpeed launcher with RAMJET. Useful for large-model training where memory is the constraint.

```bash
deepspeed examples/deepspeed_example.py
```

[View source](https://github.com/jogrms/nxgeninc/blob/main/ramjetio/examples/deepspeed_example.py)

## pytorch_imagenet.py

ImageFolder + ResNet18 with `CachedDataset` wrapping. DDP-aware (single-process if `RANK` is unset).

```bash
python examples/pytorch_imagenet.py --data-dir /mnt/imagenet --epochs 3
# or multi-GPU:
./examples/ddp_torchrun.sh examples/pytorch_imagenet.py --data-dir /mnt/imagenet
```

[View source](https://github.com/jogrms/nxgeninc/blob/main/ramjetio/examples/pytorch_imagenet.py)

## huggingface_datasets.py

`datasets.load_dataset(...)` wrapped in `CachedDataset` so subsequent epochs / nodes hit the peer ring instead of the HF Hub.

```bash
python examples/huggingface_datasets.py --dataset imdb --split train --epochs 2
```

[View source](https://github.com/jogrms/nxgeninc/blob/main/ramjetio/examples/huggingface_datasets.py)

## yolov8.py

Ultralytics YOLOv8 training fed by `UniversalDataset(format='yolo')`. This is the workload from our [benchmark](index.md#measured-impact) — 2× A5000, 5,315 samples × 5 epochs, 6.5× faster end-to-end.

```bash
python examples/yolov8.py --model yolov8n.pt --epochs 5
# multi-GPU:
./examples/ddp_torchrun.sh examples/yolov8.py --model yolov8n.pt --epochs 5
```

[View source](https://github.com/jogrms/nxgeninc/blob/main/ramjetio/examples/yolov8.py)

## ddp_torchrun.sh

One-liner `torchrun` wrapper that auto-detects per-node GPU count and accepts `NNODES` / `NODE_RANK` / `MASTER_ADDR` overrides for multi-node runs.

[View source](https://github.com/jogrms/nxgeninc/blob/main/ramjetio/examples/ddp_torchrun.sh)

## Coming in v0.10

- `video_mp4_streaming.py` — sharded video streaming with WAN-tier peering.
