# Deploying docs.ramjet.io

The docs site is served from the **same EC2 host as the backend, frontend
and landing**. No Cloudflare Pages, no separate hosting, no extra GitHub
workflow — `deploy_ec2_all.sh` builds the mkdocs site and syncs it to
nginx in the same pass as the rest of the stack.

```
ramjetio/docs/*.md  ──mkdocs build──▶  ramjetio/site/
                                            │
                                       rsync (deploy_ec2_all.sh)
                                            ▼
                              EC2:~/backend/docs-dist/
                                            │
                                       nginx :8084
                                            │
                                       ALB (Host: docs.ramjet.io)
                                            │
                                       Route 53 ALIAS
                                            ▼
                                     docs.ramjet.io
```

## Prerequisites on the build machine

```bash
python3 -m pip install --user mkdocs-material
```

`deploy_ec2_all.sh` will install it on the fly if it's missing, but
having it preinstalled keeps the deploy fast.

## Every deploy

```bash
./deploy_ec2_all.sh
```

The script:

1. Builds frontend, landing, and docs (`mkdocs build --strict`).
2. Rsyncs `frontend/dist`, `landing/dist`, and `ramjetio/site/` to
   `~/backend/{frontend-dist,landing-dist,docs-dist}/` on EC2.
3. Rsyncs `backend/nginx/nginx.conf` (single-file sync — does not
   touch any cert/state files in the remote `nginx/` directory).
4. `docker compose up -d --build` — nginx picks up the new listener
   on `:8084`.

That's it. No GitHub secrets, no Cloudflare token, no manual upload.

## One-time AWS infrastructure setup

These three things only need to be done **once per environment** —
they're not part of every deploy.

### 1. ALB target group for the docs listener

In the EC2 console → *Target Groups → Create*:

- **Name:** `ramjet-docs-tg`
- **Protocol/Port:** `HTTP / 8084`
- **Target type:** `Instances`
- **Health check path:** `/health`
- **Targets:** the same EC2 instance that already serves the frontend
  and landing target groups.

### 2. ALB listener rule

On the existing HTTPS:443 listener of the production ALB → *Rules →
Insert rule*:

- **Condition:** `Host header is docs.ramjet.io`
- **Action:** `Forward to ramjet-docs-tg`
- **Priority:** put it before the `ramjet.io` catch-all rule.

### 3. DNS

In Route 53 (or whichever provider hosts `ramjet.io`):

```
docs.ramjet.io   ALIAS   <production ALB DNS name>
```

If the zone is on Cloudflare DNS instead of Route 53, use a `CNAME`
to the ALB hostname with **Proxy status = DNS only** (grey cloud);
proxied/orange-cloud breaks the gRPC-Web path that the rest of the
stack uses — keep it consistent.

### 4. EC2 security group

The EC2 instance security group must allow TCP `8084` from the ALB
security group (it already allows 8082 and 8083 from the same source —
add 8084 the same way).

## Verifying

After the first deploy with the new infra in place:

```bash
# 1. Direct hit on the EC2 listener (from inside the VPC or via SSH
#    tunnel) — confirms nginx is serving the new vhost.
curl -H 'Host: docs.ramjet.io' http://<ec2-ip>:8084/ | head

# 2. Through the ALB
curl -I https://docs.ramjet.io
# HTTP/2 200
# content-type: text/html; charset=utf-8
# server: nginx/<version>
```

If you see `HTTP/2 502`, the listener rule is forwarding correctly but
the target is unhealthy — check the EC2 security group and that the
`frontend` container in `docker-compose.prod.yml` has the `8084:8084`
port mapping.

If you see `HTTP/2 404`, the ALB rule didn't match — verify the Host
header rule and that it has higher priority than the `ramjet.io`
catch-all.

## Local preview

```bash
cd ramjetio
python3 -m pip install --user mkdocs-material
mkdocs serve   # http://127.0.0.1:8000
```
