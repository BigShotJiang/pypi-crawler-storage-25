"""Phase 4 / Step 12: end-to-end multi-node integration test.

Spins up 3 real CacheServers on ephemeral 127.0.0.1 ports and drives them
with the SDK's ``DistributedCache`` client. Verifies:

  * ring is identical across all clients regardless of construction order
  * put/get round-trips work across all replicas
  * second read pass produces 100% hits (cache filled)
  * source-path classification ('local' vs 'peer') matches the ring routing
  * /diagnostics exposes consistent ring state and zero-error counters
  * graceful shutdown leaves no orphan threads
"""

from __future__ import annotations

import threading
import time
from pathlib import Path
from typing import List

import pytest
import requests

from ramjetio.cache import DistributedCache
from tests._multinode_harness import NodeHandle, start_cluster, stop_cluster


# --------------------------------------------------------------------------- #
# Fixtures
# --------------------------------------------------------------------------- #

@pytest.fixture
def cluster3(tmp_path, monkeypatch):
    monkeypatch.delenv("RAMJET_API_KEY", raising=False)
    nodes = start_cluster(tmp_path, n=3)
    try:
        yield nodes
    finally:
        stop_cluster(nodes)


def _addresses(nodes: List[NodeHandle]) -> List[str]:
    return [n.address for n in nodes]


# --------------------------------------------------------------------------- #
# Step 12.1: ring stability
# --------------------------------------------------------------------------- #

def test_ring_identical_across_clients(cluster3):
    addrs = _addresses(cluster3)
    # Different construction orders must produce the same routing.
    c1 = DistributedCache(nodes=addrs, replication_factor=1)
    c2 = DistributedCache(nodes=list(reversed(addrs)), replication_factor=1)
    assert c1.nodes == c2.nodes  # F-Ring1 deterministic ordering
    for k in [f"k{i}" for i in range(50)]:
        n1 = c1._active_ring().get_nodes(c1._ns(k), 1)
        n2 = c2._active_ring().get_nodes(c2._ns(k), 1)
        assert n1 == n2


def test_initial_diagnostics_report_zero_churn(cluster3):
    cache = DistributedCache(nodes=_addresses(cluster3), replication_factor=1)
    d = cache.diagnostics()
    assert d["node_count"] == 3
    assert d["ring_churn_total"] == 0
    assert d["ring_last_change_ts"] == 0.0
    assert d["replication_factor"] == 1


# --------------------------------------------------------------------------- #
# Step 12.2: put + get round-trip
# --------------------------------------------------------------------------- #

def test_put_get_roundtrip_across_nodes(cluster3):
    addrs = _addresses(cluster3)
    cache = DistributedCache(nodes=addrs, replication_factor=1)

    payload = {f"key{i}": f"value-{i}".encode() for i in range(60)}
    for k, v in payload.items():
        assert cache.set(k, v) is True

    # Every key resolves and decodes back.
    for k, v in payload.items():
        got = cache.get(k)
        assert got == v, f"mismatch for {k}"

    # Routing distributed keys across nodes (no single node has them all).
    routed = {a: 0 for a in addrs}
    for k in payload:
        target = cache._active_ring().get_nodes(cache._ns(k), 1)[0]
        routed[target] += 1
    assert all(c > 0 for c in routed.values()), \
        f"keys clumped on a subset of nodes: {routed}"


# --------------------------------------------------------------------------- #
# Step 12.3: hit-ratio growth (warm-up curve)
# --------------------------------------------------------------------------- #

def test_hit_ratio_grows_after_warmup(cluster3):
    addrs = _addresses(cluster3)
    cache = DistributedCache(nodes=addrs, replication_factor=1)

    keys = [f"hot{i}" for i in range(30)]

    # Pass 1 — cold reads, all should miss.
    cold_misses = sum(1 for k in keys if cache.get(k) is None)
    assert cold_misses == len(keys)

    # Fill cache.
    for k in keys:
        assert cache.set(k, f"v-{k}".encode()) is True

    # Pass 2 — all hits.
    warm_hits = sum(1 for k in keys if cache.get(k) is not None)
    assert warm_hits == len(keys)


# --------------------------------------------------------------------------- #
# Step 12.4: F5 source-path attribution
# --------------------------------------------------------------------------- #

def test_local_vs_peer_classification(cluster3):
    addrs = _addresses(cluster3)
    local = addrs[0]
    cache = DistributedCache(nodes=addrs, replication_factor=1, local_node=local)

    # Pre-fill.
    keys = [f"src{i}" for i in range(40)]
    for k in keys:
        cache.set(k, b"x")

    local_hits = peer_hits = 0
    for k in keys:
        v, src = cache.get_with_source(k)
        assert v == b"x"
        if src == "local":
            local_hits += 1
        elif src == "peer":
            peer_hits += 1

    # With 3 nodes and a uniform hash, ~1/3 should be local.
    assert local_hits > 0, "no local-classified hits"
    assert peer_hits > 0, "no peer-classified hits"
    assert local_hits + peer_hits == len(keys)


# --------------------------------------------------------------------------- #
# Step 12.5: /diagnostics exposes server-side state
# --------------------------------------------------------------------------- #

def test_diagnostics_endpoint_per_node(cluster3):
    for n in cluster3:
        r = requests.get(f"http://{n.address}/diagnostics", timeout=3)
        assert r.status_code == 200
        body = r.json()
        assert {"server", "singleflight", "circuit"} <= body.keys()
        assert body["circuit"]["state"] == "closed"
        assert body["circuit"]["opens_total"] == 0
        assert body["singleflight"]["wait_timeouts"] == 0


# --------------------------------------------------------------------------- #
# Step 12.6: concurrent writers don't corrupt ring or counters
# --------------------------------------------------------------------------- #

def test_concurrent_puts_no_corruption(cluster3):
    addrs = _addresses(cluster3)
    cache = DistributedCache(nodes=addrs, replication_factor=1)

    errors: list = []

    def worker(start: int, count: int) -> None:
        try:
            for i in range(start, start + count):
                cache.set(f"cc{i}", str(i).encode())
        except Exception as e:  # pragma: no cover
            errors.append(e)

    threads = [threading.Thread(target=worker, args=(i * 50, 50)) for i in range(4)]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=15)
        assert not t.is_alive(), "worker did not finish"

    assert not errors, f"worker exceptions: {errors}"

    # Sample-read 10 keys and ensure they round-trip correctly.
    for i in (0, 25, 50, 99, 100, 150, 175, 199):
        v = cache.get(f"cc{i}")
        assert v == str(i).encode()


# --------------------------------------------------------------------------- #
# Step 12.7: graceful teardown leaves no listening socket
# --------------------------------------------------------------------------- #

def test_node_stop_closes_socket(tmp_path, monkeypatch):
    monkeypatch.delenv("RAMJET_API_KEY", raising=False)
    nodes = start_cluster(tmp_path / "shut", n=2)
    a0 = nodes[0].address
    requests.get(f"http://{a0}/health", timeout=2).raise_for_status()
    stop_cluster(nodes)
    # After stop, connect should refuse.
    time.sleep(0.1)
    with pytest.raises(requests.exceptions.RequestException):
        requests.get(f"http://{a0}/health", timeout=1)
