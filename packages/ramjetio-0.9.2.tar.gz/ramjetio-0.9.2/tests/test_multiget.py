"""Tests for Phase Q.5 — batched ``/mget`` endpoint and SDK ``multi_get``.

Old behaviour: ``Dataset.__getitem__`` issued one ``/get`` per sample.
A 4-key prefetch fan-out paid 4× round-trip latency even when all 4
keys lived on the same peer.

New behaviour: an opt-in ``POST /mget`` endpoint takes a JSON ``{"keys":
[...]}`` body and returns a length-prefixed binary frame (one TCP RTT
per *peer* instead of one RTT per *key*). The SDK groups keys by
primary owner and falls back to per-key ``/get`` when a peer returns
HTTP 501 (older versions or ``RAMJET_MULTIGET`` unset).

These tests pin:
  * the wire frame round-trips (encoder/decoder symmetry)
  * server returns 501 when the flag is off (graceful degradation)
  * server returns 200 with hits and misses interleaved correctly
  * server rejects oversized batches (>1024) with 413
  * server rejects malformed bodies with 400
  * SDK ``multi_get`` falls back transparently when peer returns 501
"""

import struct

import pytest
import pytest_asyncio
from aiohttp.test_utils import TestClient, TestServer

from ramjetio.cache import (
    DistributedCache,
    _decode_mget_frame,
    _encode_value,
)
from ramjetio.server import CacheServer


# --------------------------------------------------------------------------- #
# Wire frame round-trip
# --------------------------------------------------------------------------- #


class TestFrameCodec:
    def test_empty_frame(self):
        buf = struct.pack(">I", 0)
        assert _decode_mget_frame(buf) == {}

    def test_single_hit(self):
        value = b"\x00\x01\x02"
        buf = (
            struct.pack(">I", 1)
            + struct.pack(">I", 3) + b"foo"
            + struct.pack(">I", len(value)) + value
        )
        assert _decode_mget_frame(buf) == {"foo": value}

    def test_miss_marker(self):
        buf = (
            struct.pack(">I", 1)
            + struct.pack(">I", 3) + b"bar"
            + struct.pack(">I", 0xFFFFFFFF)
        )
        assert _decode_mget_frame(buf) == {"bar": None}

    def test_truncated_frame_raises(self):
        # Announces 1 record but body is empty.
        buf = struct.pack(">I", 1)
        with pytest.raises(ValueError):
            _decode_mget_frame(buf)


# --------------------------------------------------------------------------- #
# Server endpoint
# --------------------------------------------------------------------------- #


@pytest_asyncio.fixture
async def mget_server(tmp_path, monkeypatch):
    monkeypatch.delenv("RAMJET_API_KEY", raising=False)
    monkeypatch.setenv("RAMJET_MULTIGET", "1")
    server = CacheServer(
        host="127.0.0.1",
        port=0,
        storage_path=str(tmp_path / "cache"),
        max_capacity=10 * 1024 * 1024,
    )
    app = server.create_app()
    async with TestClient(TestServer(app)) as client:
        yield client, server
    server.close()


@pytest_asyncio.fixture
async def mget_disabled_server(tmp_path, monkeypatch):
    monkeypatch.delenv("RAMJET_API_KEY", raising=False)
    monkeypatch.delenv("RAMJET_MULTIGET", raising=False)
    server = CacheServer(
        host="127.0.0.1",
        port=0,
        storage_path=str(tmp_path / "cache"),
        max_capacity=10 * 1024 * 1024,
    )
    app = server.create_app()
    async with TestClient(TestServer(app)) as client:
        yield client, server
    server.close()


@pytest.mark.asyncio
async def test_mget_disabled_returns_501(mget_disabled_server):
    client, _ = mget_disabled_server
    resp = await client.post("/mget", json={"keys": ["a"]})
    assert resp.status == 501


@pytest.mark.asyncio
async def test_mget_returns_hits_and_misses(mget_server):
    client, server = mget_server
    # Pre-populate the cache directly.
    server.cache.set("hit1", _encode_value(b"value-1"))
    server.cache.set("hit2", _encode_value(b"value-2"))

    resp = await client.post("/mget", json={"keys": ["hit1", "miss", "hit2"]})
    assert resp.status == 200
    assert resp.headers["Content-Type"].startswith("application/x-ramjet-mget-v1")
    parsed = _decode_mget_frame(await resp.read())
    assert set(parsed.keys()) == {"hit1", "miss", "hit2"}
    assert parsed["miss"] is None
    assert parsed["hit1"] is not None
    assert parsed["hit2"] is not None


@pytest.mark.asyncio
async def test_mget_rejects_too_many_keys(mget_server):
    client, _ = mget_server
    resp = await client.post("/mget", json={"keys": [f"k{i}" for i in range(1025)]})
    assert resp.status == 413


@pytest.mark.asyncio
async def test_mget_rejects_malformed_body(mget_server):
    client, _ = mget_server
    resp = await client.post("/mget", data=b"not json")
    assert resp.status == 400
    resp = await client.post("/mget", json={"keys": []})
    assert resp.status == 400
    resp = await client.post("/mget", json={"keys": [1, 2, 3]})
    assert resp.status == 400


@pytest.mark.asyncio
async def test_mget_charges_stats(mget_server):
    client, server = mget_server
    server.cache.set("h", _encode_value(b"v"))
    before_hits = server.stats_data["hits"]
    before_misses = server.stats_data["misses"]
    resp = await client.post("/mget", json={"keys": ["h", "absent"]})
    assert resp.status == 200
    assert server.stats_data["hits"] == before_hits + 1
    assert server.stats_data["misses"] == before_misses + 1


# --------------------------------------------------------------------------- #
# SDK fallback path
# --------------------------------------------------------------------------- #


def test_sdk_multi_get_empty_keys_returns_empty():
    cache = DistributedCache(["127.0.0.1:9999"])
    assert cache.multi_get([]) == {}


def test_sdk_multi_get_falls_back_on_501(monkeypatch):
    """When a peer returns 501 (older server / flag off), the SDK must
    transparently degrade to per-key ``get`` instead of erroring."""
    cache = DistributedCache(["127.0.0.1:9999"])

    class FakeResp:
        status_code = 501
        content = b""

    class FakeSession:
        def post(self, *a, **kw):
            return FakeResp()

    monkeypatch.setattr(type(cache), "session", property(lambda self: FakeSession()))
    calls = []

    def fake_get(key):
        calls.append(key)
        return f"value-{key}"

    monkeypatch.setattr(cache, "get", fake_get)
    out = cache.multi_get(["a", "b", "c"])
    assert out == {"a": "value-a", "b": "value-b", "c": "value-c"}
    assert sorted(calls) == ["a", "b", "c"]
