"""A1: sticky fallback for cache /stats fetch in _get_cache_metrics.

When the local cache server's /stats endpoint is slow or unreachable, the
SDK previously silently returned zero cache metrics, which caused dashboard
"flicker to zero". These tests verify that:

  1. A successful fetch refreshes a sticky snapshot.
  2. A failed fetch within sticky TTL reuses the last good snapshot.
  3. A failed fetch past sticky TTL falls through to zero metrics.
  4. The retry-once behaviour swallows a single transient error.
"""
from __future__ import annotations

import time
from unittest.mock import MagicMock, patch

import pytest

import ramjetio


@pytest.fixture(autouse=True)
def _reset_sticky(monkeypatch):
    """Isolate sticky state across tests."""
    ramjetio._stats_sticky_cache = {}
    ramjetio._stats_sticky_ts = 0.0
    ramjetio._stats_sticky_warn_count = 0
    # Short TTL so stale-path tests don't wait forever.
    monkeypatch.setenv("RAMJET_STATS_STICKY_TTL", "1.0")
    monkeypatch.setenv("RAMJET_STATS_TIMEOUT", "0.1")
    # Avoid psutil/pynvml noise from _get_cache_metrics on CI.
    yield
    ramjetio._stats_sticky_cache = {}
    ramjetio._stats_sticky_ts = 0.0


def _ok_response(hits=100, misses=20, cache_size=1024, items=5):
    resp = MagicMock()
    resp.status_code = 200
    resp.json.return_value = {
        "hits": hits,
        "misses": misses,
        "cache_size": cache_size,
        "items": items,
    }
    return resp


def test_successful_fetch_populates_sticky_snapshot():
    with patch("requests.get", return_value=_ok_response()) as mock_get:
        metrics = ramjetio._get_cache_metrics()
    assert mock_get.call_count == 1
    assert metrics["hits"] == 100
    assert metrics["misses"] == 20
    assert metrics["cache_size_bytes"] == 1024
    assert metrics["cache_items"] == 5
    assert ramjetio._stats_sticky_cache["hits"] == 100
    assert ramjetio._stats_sticky_ts > 0


def test_retry_once_swallows_single_transient_error():
    import requests

    call_results = [requests.ConnectionError("boom"), _ok_response(hits=7, misses=3)]

    def fake_get(*args, **kwargs):
        result = call_results.pop(0)
        if isinstance(result, Exception):
            raise result
        return result

    with patch("requests.get", side_effect=fake_get):
        metrics = ramjetio._get_cache_metrics()
    assert metrics["hits"] == 7
    assert metrics["misses"] == 3


def test_failed_fetch_within_ttl_uses_sticky(caplog):
    # Prime sticky with a good fetch.
    with patch("requests.get", return_value=_ok_response(hits=42, misses=8)):
        ramjetio._get_cache_metrics()
    assert ramjetio._stats_sticky_cache["hits"] == 42

    # Now both attempts fail — sticky is fresh (< 1s TTL).
    import requests

    with patch("requests.get", side_effect=requests.Timeout("slow")):
        with caplog.at_level("WARNING", logger="ramjetio"):
            metrics = ramjetio._get_cache_metrics()
    assert metrics["hits"] == 42
    assert metrics["misses"] == 8
    assert ramjetio._stats_sticky_warn_count == 1
    assert any("sticky snapshot" in rec.message for rec in caplog.records)


def test_failed_fetch_past_ttl_reports_zero(caplog):
    with patch("requests.get", return_value=_ok_response(hits=42, misses=8)):
        ramjetio._get_cache_metrics()

    # Force the sticky snapshot to look stale.
    ramjetio._stats_sticky_ts = time.time() - 10.0  # > TTL=1s

    import requests

    with patch("requests.get", side_effect=requests.Timeout("slow")):
        with caplog.at_level("WARNING", logger="ramjetio"):
            metrics = ramjetio._get_cache_metrics()
    # No hits/misses/cache_size in metrics — they simply aren't populated.
    assert "hits" not in metrics
    assert "cache_size_bytes" not in metrics
    assert ramjetio._stats_sticky_warn_count == 1
    assert any("no fresh" in rec.message for rec in caplog.records)
