"""F-Diag1: /diagnostics endpoint + DistributedCache.diagnostics() + BackendClient.diagnostics()."""
from __future__ import annotations

import time
import tempfile

import pytest
import pytest_asyncio

from ramjetio.cache import DistributedCache
from ramjetio.server import CacheServer


# --------------------------------------------------------------------------- #
# DistributedCache.diagnostics()
# --------------------------------------------------------------------------- #

class TestDistributedCacheDiagnostics:
    def test_initial_snapshot_has_zero_churn(self):
        c = DistributedCache(nodes=["a:1", "b:1"], replication_factor=2)
        d = c.diagnostics()
        assert d["node_count"] == 2
        assert d["nodes"] == ["a:1", "b:1"]
        assert d["config_version"] == 0
        assert d["ring_churn_total"] == 0
        assert d["ring_last_change_ts"] == 0.0
        assert d["ring_seconds_since_change"] is None
        assert d["replication_factor"] == 2

    def test_add_node_bumps_churn_and_version(self):
        c = DistributedCache(nodes=["a:1"])
        before = time.time()
        c.add_node("b:1")
        d = c.diagnostics()
        assert d["ring_churn_total"] == 1
        assert d["config_version"] == 1
        assert d["ring_last_change_ts"] >= before
        assert d["ring_seconds_since_change"] is not None

    def test_remove_node_bumps_churn(self):
        c = DistributedCache(nodes=["a:1", "b:1"])
        c.remove_node("b:1")
        assert c.diagnostics()["ring_churn_total"] == 1

    def test_replace_nodes_stale_does_not_bump_churn(self):
        c = DistributedCache(nodes=["a:1"])
        # Bump version once, churn=1
        assert c.replace_nodes(["a:1", "b:1"], version=5) is True
        # Stale call, must be no-op for both counters.
        assert c.replace_nodes(["a:1", "b:1", "c:1"], version=3) is False
        d = c.diagnostics()
        assert d["config_version"] == 5
        assert d["ring_churn_total"] == 1


# --------------------------------------------------------------------------- #
# BackendClient.diagnostics()
# --------------------------------------------------------------------------- #

class TestBackendClientDiagnostics:
    def test_unconnected_snapshot(self, monkeypatch):
        monkeypatch.setenv("RAMJET_API_KEY", "k")
        from ramjetio.backend_client import BackendClient
        bc = BackendClient(node_port=9000, api_key="k")
        d = bc.diagnostics()
        assert d["connected"] is False
        assert d["node_id"] is None
        assert d["heartbeat_failures_total"] == 0
        assert d["heartbeat_consecutive_failures"] == 0
        assert d["heartbeat_seconds_since_success"] is None
        assert d["heartbeat_last_error"] is None
        assert d["reconnect_attempts_total"] == 0

    def test_records_failure_state(self, monkeypatch):
        monkeypatch.setenv("RAMJET_API_KEY", "k")
        from ramjetio.backend_client import BackendClient
        bc = BackendClient(node_port=9000, api_key="k")
        bc.heartbeat_failures_total = 3
        bc.heartbeat_consecutive_failures = 2
        bc.heartbeat_last_error = "RpcError: UNAVAILABLE"
        bc.reconnect_attempts_total = 7
        d = bc.diagnostics()
        assert d["heartbeat_failures_total"] == 3
        assert d["heartbeat_consecutive_failures"] == 2
        assert d["heartbeat_last_error"] == "RpcError: UNAVAILABLE"
        assert d["reconnect_attempts_total"] == 7


# --------------------------------------------------------------------------- #
# /diagnostics HTTP endpoint
# --------------------------------------------------------------------------- #

@pytest_asyncio.fixture
async def diag_server(tmp_path, monkeypatch):
    from aiohttp.test_utils import TestClient, TestServer

    # No API key -> open server, simpler for this test.
    monkeypatch.delenv("RAMJET_API_KEY", raising=False)

    server = CacheServer(
        host="127.0.0.1",
        port=0,
        storage_path=str(tmp_path / "cache"),
        max_capacity=10 * 1024 * 1024,
    )
    app = server.create_app()
    async with TestClient(TestServer(app)) as client:
        yield client, server
    server.close()


@pytest.mark.asyncio
async def test_diagnostics_returns_json_with_buckets(diag_server):
    client, _ = diag_server
    resp = await client.get("/diagnostics")
    assert resp.status == 200
    body = await resp.json()
    assert set(body.keys()) >= {"server", "singleflight", "circuit"}


@pytest.mark.asyncio
async def test_diagnostics_circuit_state_closed_initially(diag_server):
    client, _ = diag_server
    resp = await client.get("/diagnostics")
    body = await resp.json()
    assert body["circuit"]["state"] == "closed"
    assert body["circuit"]["opens_total"] == 0
    assert body["circuit"]["short_circuited_total"] == 0


@pytest.mark.asyncio
async def test_diagnostics_circuit_state_open_after_threshold(diag_server):
    client, server = diag_server
    cb = server._origin_circuit
    for _ in range(cb.threshold):
        cb.record_timeout()

    resp = await client.get("/diagnostics")
    body = await resp.json()
    assert body["circuit"]["state"] == "open"
    assert body["circuit"]["opens_total"] == 1
    assert body["circuit"]["consecutive_timeouts"] >= cb.threshold
    assert body["circuit"]["opened_for_s"] >= 0


@pytest.mark.asyncio
async def test_diagnostics_singleflight_block_present(diag_server):
    client, _ = diag_server
    resp = await client.get("/diagnostics")
    body = await resp.json()
    sf = body["singleflight"]
    assert "enabled" in sf
    assert "timeout_s" in sf
    assert sf["wait_timeouts"] == 0


@pytest.mark.asyncio
async def test_diagnostics_no_backend_block_when_unregistered(diag_server):
    client, _ = diag_server
    resp = await client.get("/diagnostics")
    body = await resp.json()
    # Backend client not initialised in test fixture -> no 'backend' key.
    assert "backend" not in body


@pytest.mark.asyncio
async def test_diagnostics_uptime_advances(diag_server):
    client, _ = diag_server
    r1 = await (await client.get("/diagnostics")).json()
    time.sleep(0.05)
    r2 = await (await client.get("/diagnostics")).json()
    assert r2["server"]["uptime_s"] > r1["server"]["uptime_s"]
