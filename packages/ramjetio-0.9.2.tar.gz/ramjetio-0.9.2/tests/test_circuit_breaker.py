"""F-CB1: origin circuit breaker tests.

Pure unit tests against the ``_OriginCircuit`` class — no aiohttp / disk
involvement. Verifies state transitions and invariants:

  closed --(threshold timeouts)--> OPEN
  OPEN   --(cooldown elapsed)----> HALF-OPEN (one probe allowed)
  HALF-OPEN + success ----------> closed
  HALF-OPEN + timeout ----------> OPEN (re-armed)
"""

from __future__ import annotations

import time

import pytest

from ramjetio.server import _OriginCircuit


def test_closed_allows_traffic():
    cb = _OriginCircuit(threshold=3, cooldown_s=1.0)
    for _ in range(10):
        assert cb.allow_cold_miss() is True
    assert cb.opens == 0
    assert cb.short_circuited == 0


def test_threshold_opens_circuit():
    cb = _OriginCircuit(threshold=3, cooldown_s=1.0)
    cb.record_timeout()
    cb.record_timeout()
    # Below threshold — still closed.
    assert cb.allow_cold_miss() is True
    cb.record_timeout()
    # At threshold — now open.
    assert cb.allow_cold_miss() is False
    assert cb.opens == 1
    assert cb.short_circuited == 1


def test_success_resets_streak_below_threshold():
    cb = _OriginCircuit(threshold=3, cooldown_s=1.0)
    cb.record_timeout()
    cb.record_timeout()
    cb.record_success()
    cb.record_timeout()
    cb.record_timeout()
    # Streak was reset; still closed.
    assert cb.allow_cold_miss() is True
    assert cb.opens == 0


def test_half_open_after_cooldown_allows_one_probe():
    cb = _OriginCircuit(threshold=2, cooldown_s=0.05)
    cb.record_timeout(); cb.record_timeout()
    assert cb.allow_cold_miss() is False
    time.sleep(0.06)
    # First call after cooldown is the probe.
    assert cb.allow_cold_miss() is True
    # Second call is short-circuited until probe resolves.
    assert cb.allow_cold_miss() is False


def test_half_open_success_closes_circuit():
    cb = _OriginCircuit(threshold=2, cooldown_s=0.05)
    cb.record_timeout(); cb.record_timeout()
    time.sleep(0.06)
    assert cb.allow_cold_miss() is True   # probe
    cb.record_success()
    # Circuit fully closed: many requests pass freely.
    for _ in range(20):
        assert cb.allow_cold_miss() is True


def test_half_open_failure_re_opens():
    cb = _OriginCircuit(threshold=2, cooldown_s=0.05)
    cb.record_timeout(); cb.record_timeout()
    assert cb.opens == 1
    time.sleep(0.06)
    assert cb.allow_cold_miss() is True   # probe
    cb.record_timeout()                   # probe failed
    # No new traffic until next cooldown.
    assert cb.allow_cold_miss() is False
    # Re-opened (consecutive_timeouts now 3 >= threshold=2 again).
    assert cb.opens == 2


def test_threshold_must_be_positive():
    cb = _OriginCircuit(threshold=0, cooldown_s=1.0)
    # Implementation clamps to 1, so a single timeout opens.
    cb.record_timeout()
    assert cb.allow_cold_miss() is False


def test_short_circuited_counter_advances():
    cb = _OriginCircuit(threshold=1, cooldown_s=10.0)
    cb.record_timeout()
    for _ in range(7):
        cb.allow_cold_miss()
    assert cb.short_circuited == 7
