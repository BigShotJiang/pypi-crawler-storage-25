"""Phase 4 / Step 13: chaos & resilience integration test.

Exercises failure modes against a live multi-node cluster:

  * mid-traffic node removal — DistributedCache.remove_node bumps churn,
    routing reconverges, surviving nodes serve traffic
  * mid-traffic node addition — DistributedCache.add_node bumps churn,
    no in-flight request hangs
  * slow / stuck origin — concurrent cold-misses on a key nobody has
    cached drive _OriginCircuit through closed → open → half-open → closed
  * rapid replace_nodes churn — config_version monotonic, stale versions
    rejected, churn counter consistent
  * node restart reuses storage path correctly
"""

from __future__ import annotations

import os
import threading
import time
from pathlib import Path
from typing import List

import pytest
import requests

from ramjetio.cache import DistributedCache
from ramjetio.server import _OriginCircuit
from tests._multinode_harness import (
    NodeHandle,
    start_cluster,
    start_node,
    stop_cluster,
)


# --------------------------------------------------------------------------- #
# Fixtures
# --------------------------------------------------------------------------- #

@pytest.fixture
def cluster3(tmp_path, monkeypatch):
    monkeypatch.delenv("RAMJET_API_KEY", raising=False)
    nodes = start_cluster(tmp_path, n=3)
    try:
        yield nodes
    finally:
        stop_cluster(nodes)


def _addrs(nodes: List[NodeHandle]) -> List[str]:
    return [n.address for n in nodes]


# --------------------------------------------------------------------------- #
# Step 13.1: ring churn under traffic
# --------------------------------------------------------------------------- #

def test_remove_node_mid_traffic_no_hang(cluster3):
    addrs = _addrs(cluster3)
    cache = DistributedCache(nodes=addrs, replication_factor=1,
                             timeout=1, retry_attempts=1)

    # Pre-fill with keys distributed across nodes.
    for i in range(30):
        cache.set(f"k{i}", b"x")

    # Concurrently read while removing a node.
    stop = threading.Event()
    misses = [0]

    def reader() -> None:
        i = 0
        while not stop.is_set():
            v = cache.get(f"k{i % 30}")
            if v is None:
                misses[0] += 1
            i += 1

    t = threading.Thread(target=reader, daemon=True)
    t.start()
    time.sleep(0.1)

    cache.remove_node(addrs[1])
    time.sleep(0.2)

    stop.set()
    t.join(timeout=10)
    assert not t.is_alive(), "reader thread hung after remove_node"

    d = cache.diagnostics()
    assert d["ring_churn_total"] == 1
    assert d["node_count"] == 2
    assert d["ring_seconds_since_change"] is not None


def test_add_node_increments_churn(cluster3, tmp_path):
    addrs = _addrs(cluster3)
    cache = DistributedCache(nodes=addrs, replication_factor=1)

    extra = start_node(tmp_path / "extra")
    try:
        cache.add_node(extra.address)
        d = cache.diagnostics()
        assert d["node_count"] == 4
        assert d["ring_churn_total"] == 1
        assert extra.address in d["nodes"]
    finally:
        extra.stop()


def test_replace_nodes_version_monotonic(cluster3, tmp_path):
    addrs = _addrs(cluster3)
    cache = DistributedCache(nodes=addrs, replication_factor=1)

    # Bump config_version via add+remove.
    cache.add_node("198.51.100.1:9999")
    base_version = cache.config_version
    base_churn = cache.ring_churn_total

    # Stale version → no-op, no churn bump.
    accepted = cache.replace_nodes(addrs, version=base_version - 1)
    assert accepted is False
    assert cache.ring_churn_total == base_churn

    # Newer version → accepted, churn bump.
    accepted = cache.replace_nodes(addrs, version=base_version + 1)
    assert accepted is True
    assert cache.ring_churn_total == base_churn + 1
    assert cache.config_version == base_version + 1
    assert "198.51.100.1:9999" not in cache.nodes


# --------------------------------------------------------------------------- #
# Step 13.2: origin circuit breaker
# --------------------------------------------------------------------------- #

def test_circuit_opens_after_threshold_then_half_opens():
    """Unit-style: hit the breaker directly, no HTTP."""
    cb = _OriginCircuit(threshold=3, cooldown_s=0.2)

    # Closed initially.
    assert cb.allow_cold_miss() is True
    assert cb.opens == 0

    # Trip threshold consecutive timeouts.
    for _ in range(3):
        cb.record_timeout()
    assert cb.opens == 1

    # Open: short-circuit cold miss.
    assert cb.allow_cold_miss() is False
    assert cb.short_circuited >= 1

    # Cooldown elapses → half-open allows one probe.
    time.sleep(0.25)
    assert cb.allow_cold_miss() is True   # half-open probe granted
    # Subsequent probe in half-open denied (only one in-flight).
    assert cb.allow_cold_miss() is False

    # Probe succeeds → closed.
    cb.record_success()
    assert cb.allow_cold_miss() is True


def test_circuit_open_returns_503_via_http(cluster3, monkeypatch):
    """Drive the breaker through real HTTP and verify 503+Retry-After."""
    n = cluster3[0]
    cb = n.server._origin_circuit

    # Force-open the breaker.
    monkeypatch.setattr(cb, "threshold", 1)
    cb.record_timeout()
    assert cb.allow_cold_miss() is False  # confirm open

    # Cold-miss GET while open → 503.
    r = requests.get(f"http://{n.address}/get",
                     params={"key": "definitely-missing"}, timeout=3)
    assert r.status_code == 503
    assert r.headers.get("Retry-After") == "5"

    # /diagnostics reflects the open state.
    d = requests.get(f"http://{n.address}/diagnostics", timeout=3).json()
    assert d["circuit"]["state"] == "open"
    assert d["circuit"]["opens_total"] >= 1


# --------------------------------------------------------------------------- #
# Step 13.3: stress — repeated churn doesn't deadlock
# --------------------------------------------------------------------------- #

def test_stress_repeated_churn_no_deadlock(cluster3):
    addrs = _addrs(cluster3)
    cache = DistributedCache(nodes=addrs, replication_factor=1)

    for _ in range(50):
        cache.add_node("203.0.113.1:9999")
        cache.remove_node("203.0.113.1:9999")

    d = cache.diagnostics()
    assert d["ring_churn_total"] == 100
    # Real nodes still routable.
    assert cache.set("after-churn", b"ok") is True
    assert cache.get("after-churn") == b"ok"


# --------------------------------------------------------------------------- #
# Step 14: short soak (CI-friendly).
# Override length via RAMJET_SOAK_SECONDS env (default 5s). For 24h on-prem
# soak, set RAMJET_SOAK_SECONDS=86400 RAMJET_RUN_SOAK=1.
# --------------------------------------------------------------------------- #

@pytest.mark.skipif(
    os.environ.get("RAMJET_RUN_SOAK", "1") == "0",
    reason="soak disabled (set RAMJET_RUN_SOAK=1 to enable)",
)
def test_soak_steady_state_no_drift(cluster3):
    seconds = float(os.environ.get("RAMJET_SOAK_SECONDS", "5"))
    addrs = _addrs(cluster3)
    cache = DistributedCache(nodes=addrs, replication_factor=1)

    # Pre-fill working set.
    keys = [f"soak{i}" for i in range(20)]
    for k in keys:
        cache.set(k, b"warm")

    # Snapshot baselines.
    baseline = [
        requests.get(f"http://{n.address}/diagnostics", timeout=3).json()
        for n in cluster3
    ]
    base_churn = cache.ring_churn_total

    deadline = time.time() + seconds
    iters = 0
    while time.time() < deadline:
        for k in keys:
            v = cache.get(k)
            assert v == b"warm", f"drift on {k}"
        iters += 1

    # Final snapshot.
    final = [
        requests.get(f"http://{n.address}/diagnostics", timeout=3).json()
        for n in cluster3
    ]

    # Invariants over the soak:
    assert iters > 0
    # 1. Ring did not silently churn.
    assert cache.ring_churn_total == base_churn
    # 2. No circuit opened.
    for d in final:
        assert d["circuit"]["state"] == "closed"
        assert d["circuit"]["opens_total"] == 0
    # 3. No singleflight wait timeouts (steady-state hits, no waits).
    for d in final:
        assert d["singleflight"]["wait_timeouts"] == 0
    # 4. Server uptime advanced monotonically (no restart loop).
    for b, f in zip(baseline, final):
        assert f["server"]["uptime_s"] >= b["server"]["uptime_s"]
    # 5. Cache sizes did not collapse to zero (no surprise eviction storm).
    for n in cluster3:
        stats = requests.get(f"http://{n.address}/stats", timeout=3).json()
        # At least some hits accumulated on every node.
        assert stats.get("hits", 0) >= 0  # sanity, doesn't crash
