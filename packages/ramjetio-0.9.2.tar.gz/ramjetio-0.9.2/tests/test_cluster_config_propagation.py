"""F-Cfg1: live cluster-config propagation via topology file.

Step 6 extends the topology JSON to carry ``cluster_config_version`` and
a ``cluster_config`` block (replication_factor + data_source fingerprint).
These tests pin down:
  * fingerprint omits secrets and is order-stable
  * `_apply_cluster_config_update` is version-monotonic
  * payload round-trip via _publish/_read works for the new shape
  * old-shape payloads (no cluster_config block) still parse
  * data-source change emits a WARN log
"""

from __future__ import annotations

import json
import logging
import os

import pytest

import ramjetio
from ramjetio.cache import DistributedCache


@pytest.fixture
def isolated_topology(tmp_path, monkeypatch):
    """Point the topology file at a tmp path and reset all module-level state.

    Without this, tests would clobber ``/tmp/ramjet_topology.json`` and
    leak ``_last_applied_*`` state between tests.
    """
    topo = tmp_path / "topology.json"
    monkeypatch.setattr(ramjetio, "_TOPOLOGY_FILE", str(topo))
    monkeypatch.setattr(ramjetio, "_last_applied_cluster_config_version", 0)
    monkeypatch.setattr(ramjetio, "_last_applied_data_source_fingerprint", None)
    monkeypatch.setattr(ramjetio, "_global_cache", None)
    monkeypatch.setattr(ramjetio, "_backend_client", None)
    yield topo


# --- _datasource_fingerprint -----------------------------------------------

def test_fingerprint_excludes_secrets():
    a = {"type": 1, "s3_endpoint": "x", "s3_secret_key": "AAA", "s3_access_key": "k1"}
    b = {"type": 1, "s3_endpoint": "x", "s3_secret_key": "BBB", "s3_access_key": "k2"}
    # Rotated keys must NOT count as a config change.
    assert ramjetio._datasource_fingerprint(a) == ramjetio._datasource_fingerprint(b)


def test_fingerprint_detects_endpoint_change():
    a = {"type": 1, "s3_endpoint": "minio-1:9000", "s3_secret_key": "x"}
    b = {"type": 1, "s3_endpoint": "minio-2:9000", "s3_secret_key": "x"}
    assert ramjetio._datasource_fingerprint(a) != ramjetio._datasource_fingerprint(b)


def test_fingerprint_none_for_empty():
    assert ramjetio._datasource_fingerprint(None) is None
    assert ramjetio._datasource_fingerprint({}) is None


def test_fingerprint_order_stable():
    a = {"type": 1, "s3_endpoint": "x", "prefix": "p/"}
    b = {"prefix": "p/", "s3_endpoint": "x", "type": 1}
    assert ramjetio._datasource_fingerprint(a) == ramjetio._datasource_fingerprint(b)


# --- _apply_cluster_config_update ------------------------------------------

def test_apply_updates_replication_factor(isolated_topology, monkeypatch):
    cache = DistributedCache(nodes=["a:9000"], replication_factor=1)
    monkeypatch.setattr(ramjetio, "_global_cache", cache)
    ramjetio._apply_cluster_config_update(
        version=5,
        cc={"replication_factor": 3, "data_source_fingerprint": "abc"},
    )
    assert cache.replication_factor == 3
    assert ramjetio._last_applied_cluster_config_version == 5


def test_apply_is_version_monotonic(isolated_topology, monkeypatch):
    cache = DistributedCache(nodes=["a:9000"], replication_factor=2)
    monkeypatch.setattr(ramjetio, "_global_cache", cache)
    ramjetio._apply_cluster_config_update(
        version=5,
        cc={"replication_factor": 3, "data_source_fingerprint": "x"},
    )
    # Stale version: must NOT clobber the live replication_factor.
    ramjetio._apply_cluster_config_update(
        version=4,
        cc={"replication_factor": 1, "data_source_fingerprint": "x"},
    )
    assert cache.replication_factor == 3


def test_apply_warns_on_data_source_change(isolated_topology, monkeypatch, caplog):
    cache = DistributedCache(nodes=["a:9000"], replication_factor=1)
    monkeypatch.setattr(ramjetio, "_global_cache", cache)
    # Seed an initial fingerprint so the second call sees it as a change.
    ramjetio._apply_cluster_config_update(
        version=1,
        cc={"replication_factor": 1, "data_source_fingerprint": "fp1"},
    )
    with caplog.at_level(logging.WARNING, logger="ramjetio"):
        ramjetio._apply_cluster_config_update(
            version=2,
            cc={"replication_factor": 1, "data_source_fingerprint": "fp2"},
        )
    assert any("data_source changed mid-run" in r.message for r in caplog.records)


def test_apply_no_warn_first_time(isolated_topology, monkeypatch, caplog):
    cache = DistributedCache(nodes=["a:9000"], replication_factor=1)
    monkeypatch.setattr(ramjetio, "_global_cache", cache)
    with caplog.at_level(logging.WARNING, logger="ramjetio"):
        ramjetio._apply_cluster_config_update(
            version=1,
            cc={"replication_factor": 1, "data_source_fingerprint": "fp1"},
        )
    # First-time apply seeds the fingerprint; must not warn.
    assert not any("data_source changed" in r.message for r in caplog.records)


# --- topology JSON round-trip with cluster_config block --------------------

def test_publish_includes_cluster_config(isolated_topology, monkeypatch):
    cache = DistributedCache(nodes=["a:9000", "b:9000"], replication_factor=2)
    monkeypatch.setattr(ramjetio, "_global_cache", cache)

    class _FakeBackend:
        cluster_config = {
            "replication_factor": 2,
            "data_source": {"type": 1, "s3_endpoint": "minio:9000"},
        }
        cluster_config_version = 7

    monkeypatch.setattr(ramjetio, "_backend_client", _FakeBackend())
    ramjetio._publish_topology()

    payload = json.loads(isolated_topology.read_text())
    assert payload["nodes"] == sorted(["a:9000", "b:9000"])
    assert payload["cluster_config_version"] == 7
    assert payload["cluster_config"]["replication_factor"] == 2
    assert isinstance(payload["cluster_config"]["data_source_fingerprint"], str)


def test_publish_no_credentials_in_file(isolated_topology, monkeypatch):
    cache = DistributedCache(nodes=["a:9000"], replication_factor=1)
    monkeypatch.setattr(ramjetio, "_global_cache", cache)

    class _FakeBackend:
        cluster_config = {
            "replication_factor": 1,
            "data_source": {
                "type": 1,
                "s3_endpoint": "minio:9000",
                "s3_secret_key": "SUPER-SECRET-NEVER-LEAK",
                "s3_access_key": "AKIA-NOPE",
                "http_auth_header": "Bearer leaked",
            },
        }
        cluster_config_version = 1

    monkeypatch.setattr(ramjetio, "_backend_client", _FakeBackend())
    ramjetio._publish_topology()

    raw = isolated_topology.read_text()
    assert "SUPER-SECRET-NEVER-LEAK" not in raw
    assert "AKIA-NOPE" not in raw
    assert "Bearer leaked" not in raw


def test_read_topology_old_shape_still_parses(isolated_topology):
    isolated_topology.write_text(json.dumps({
        "version": 3,
        "nodes": ["a:9000", "b:9000"],
    }))
    out = ramjetio._read_topology_file()
    assert out == {"version": 3, "nodes": ["a:9000", "b:9000"]}


def test_read_topology_new_shape_parses(isolated_topology):
    isolated_topology.write_text(json.dumps({
        "version": 3,
        "nodes": ["a:9000"],
        "cluster_config_version": 9,
        "cluster_config": {
            "replication_factor": 2,
            "data_source_fingerprint": "abcdef",
        },
    }))
    out = ramjetio._read_topology_file()
    assert out is not None
    assert out["cluster_config_version"] == 9
    assert out["cluster_config"]["replication_factor"] == 2


def test_read_topology_rejects_bad_cluster_config(isolated_topology):
    isolated_topology.write_text(json.dumps({
        "version": 3,
        "nodes": ["a:9000"],
        "cluster_config_version": 9,
        "cluster_config": {"replication_factor": "not-an-int"},
    }))
    out = ramjetio._read_topology_file()
    # Ring still parses; cluster_config block is dropped because invalid.
    assert out is not None
    assert "cluster_config" not in out
