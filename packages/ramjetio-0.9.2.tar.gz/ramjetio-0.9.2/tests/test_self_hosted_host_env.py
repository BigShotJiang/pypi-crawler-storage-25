"""Tests for Phase Q.3 — RAMJET_BACKEND_HOST honoured on the production path.

Old behaviour: ``backend_client.py`` referenced the module-level constants
``RAMJET_BACKEND_URL`` / ``RAMJET_BACKEND_USE_SSL`` which were captured at
*import* time. Self-hosted operators who set ``RAMJET_BACKEND_HOST`` after
``import ramjetio`` (e.g. from a CLI flag parsed in ``main()``) silently
got the default ``grpc.ramjet.io:443`` and pushed metrics to the wrong
coordinator — the override was effectively dev-only because dev reloads
constantly.

New behaviour: ``ramjetio.config`` exposes ``get_backend_host()`` /
``get_backend_port()`` / ``get_backend_url()`` / ``get_backend_use_ssl()``
that re-read ``os.environ`` on every call. ``backend_client.connect()``
now uses those helpers, so an env override set any time before the first
heartbeat fires takes effect without a process restart.
"""

import os
from unittest.mock import patch

import pytest

import ramjetio
from ramjetio import config as config_mod


class TestLiveEnvAccessors:
    def test_default_when_env_unset(self):
        with patch.dict(os.environ, {}, clear=True):
            assert config_mod.get_backend_host() == "grpc.ramjet.io"
            assert config_mod.get_backend_port() == 443
            assert config_mod.get_backend_url() == "grpc.ramjet.io:443"
            assert config_mod.get_backend_use_ssl() is True

    def test_override_picked_up_after_import(self):
        """The whole point of Phase Q.3: env set *after* import wins."""
        with patch.dict(
            os.environ,
            {
                "RAMJET_BACKEND_HOST": "coordinator.acme.internal",
                "RAMJET_BACKEND_PORT": "50051",
            },
        ):
            assert config_mod.get_backend_host() == "coordinator.acme.internal"
            assert config_mod.get_backend_port() == 50051
            assert (
                config_mod.get_backend_url()
                == "coordinator.acme.internal:50051"
            )

    def test_use_ssl_override(self):
        with patch.dict(os.environ, {"RAMJET_BACKEND_USE_SSL": "false"}):
            assert config_mod.get_backend_use_ssl() is False
        with patch.dict(os.environ, {"RAMJET_BACKEND_USE_SSL": "TRUE"}):
            assert config_mod.get_backend_use_ssl() is True

    def test_helpers_exposed_on_top_level_package(self):
        """A self-hosted user does ``from ramjetio import get_backend_url``."""
        # Note: we compare by name/callable rather than ``is`` because
        # ``test_config.py`` reloads ``ramjetio.config`` and that breaks
        # identity equality across the package re-export.
        for name in (
            "get_backend_host",
            "get_backend_port",
            "get_backend_url",
            "get_backend_use_ssl",
        ):
            fn = getattr(ramjetio, name, None)
            assert callable(fn), f"ramjetio.{name} missing or not callable"
        # Functional sanity: top-level helper produces a sane host:port.
        with patch.dict(os.environ, {"RAMJET_BACKEND_HOST": "expose.test"}):
            assert ramjetio.get_backend_url().startswith("expose.test:")

    def test_each_call_rereads_env(self):
        """Sanity: changing env between two calls changes the result."""
        with patch.dict(os.environ, {"RAMJET_BACKEND_HOST": "first.host"}):
            first = config_mod.get_backend_url()
        with patch.dict(os.environ, {"RAMJET_BACKEND_HOST": "second.host"}):
            second = config_mod.get_backend_url()
        assert first != second
        assert first.startswith("first.host:")
        assert second.startswith("second.host:")


class TestBackendClientHonoursLiveEnv:
    def test_connect_uses_live_env_for_channel(self):
        """connect() must build the channel from the env at call time, not
        from the import-time constant."""
        from ramjetio.backend_client import BackendClient

        client = BackendClient(node_port=9000, api_key="test_clustername_secret")

        captured = {}

        def fake_insecure_channel(target, *args, **kwargs):
            captured["target"] = target

            class _Stub:
                def close(self):
                    pass

            return _Stub()

        # Force insecure path so we don't touch grpc.ssl_channel_credentials.
        with patch.dict(
            os.environ,
            {
                "RAMJET_BACKEND_HOST": "self-hosted.lan",
                "RAMJET_BACKEND_PORT": "50051",
                "RAMJET_BACKEND_USE_SSL": "false",
            },
        ), patch(
            "ramjetio.backend_client.grpc.insecure_channel",
            side_effect=fake_insecure_channel,
        ):
            # connect() may still fail later (no real proto stub on the
            # other end), but by then the channel target is already
            # captured. We only care about *which URL* it tried to dial.
            try:
                client.connect()
            except Exception:
                pass

        assert captured.get("target") == "self-hosted.lan:50051", (
            f"channel dialled wrong target: {captured!r}"
        )
