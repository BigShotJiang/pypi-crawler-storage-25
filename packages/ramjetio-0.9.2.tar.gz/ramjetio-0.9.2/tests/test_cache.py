"""
Tests for distributed cache client.
"""

import pytest
import torch
from unittest.mock import Mock, patch, MagicMock

from ramjetio.cache import DistributedCache


class TestDistributedCache:
    """Test cases for DistributedCache class."""
    
    def test_initialization(self):
        """Test cache initialization."""
        nodes = ["node1:9000", "node2:9000"]
        cache = DistributedCache(nodes=nodes)
        
        assert len(cache.nodes) == 2
        assert cache.timeout == 30
        assert cache.retry_attempts == 3
    
    def test_initialization_no_nodes(self):
        """Test that initialization fails with no nodes."""
        with pytest.raises(ValueError):
            DistributedCache(nodes=[])
    
    def test_set_success(self):
        """Test setting a value in cache."""
        mock_response = Mock()
        mock_response.status_code = 200
        
        cache = DistributedCache(nodes=["node1:9000"])
        import os
        cache._session = Mock()
        cache._session_pid = os.getpid()
        cache._session.post.return_value = mock_response
        
        success = cache.set("test_key", "test_value")
        
        assert success
        assert cache._session.post.called
    
    def test_get_success(self):
        """Test getting a value from cache.

        Post-F12: the on-wire payload MUST carry an envelope magic. Bare
        pickle bytes are no longer accepted (see test_hardening.py for the
        security rationale).
        """
        from ramjetio.cache import MAGIC_BYTES

        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.content = MAGIC_BYTES + b"test_value"

        cache = DistributedCache(nodes=["node1:9000"])
        import os
        cache._session = Mock()
        cache._session_pid = os.getpid()
        cache._session.get.return_value = mock_response

        value = cache.get("test_key")

        assert value == b"test_value"
        assert cache._session.get.called
    
    def test_get_not_found(self):
        """Test getting a non-existent key."""
        mock_response = Mock()
        mock_response.status_code = 404
        
        cache = DistributedCache(nodes=["node1:9000"])
        import os
        cache._session = Mock()
        cache._session_pid = os.getpid()
        cache._session.get.return_value = mock_response
        
        value = cache.get("nonexistent_key")
        
        assert value is None
    
    def test_delete_success(self):
        """Test deleting a value from cache."""
        mock_response = Mock()
        mock_response.status_code = 200
        
        cache = DistributedCache(nodes=["node1:9000"])
        import os
        cache._session = Mock()
        cache._session_pid = os.getpid()
        cache._session.delete.return_value = mock_response
        
        success = cache.delete("test_key")
        
        assert success
        assert cache._session.delete.called
    
    def test_add_node(self):
        """Test adding a node to the cache cluster."""
        cache = DistributedCache(nodes=["node1:9000"])
        cache.add_node("node2:9000")
        
        assert len(cache.nodes) == 2
        assert "node2:9000" in cache.nodes
    
    def test_remove_node(self):
        """Test removing a node from the cache cluster."""
        cache = DistributedCache(nodes=["node1:9000", "node2:9000"])
        cache.remove_node("node1:9000")
        
        assert len(cache.nodes) == 1
        assert "node1:9000" not in cache.nodes

    def test_session_pool_scales_with_cluster_and_env(self, monkeypatch):
        """P3.3 Step 3: pool_maxsize must be ≥32 even on small clusters,
        and honour RAMJET_HTTP_POOL_SIZE override."""
        # default: floor at 32 for 2-node cluster
        monkeypatch.delenv("RAMJET_HTTP_POOL_SIZE", raising=False)
        cache = DistributedCache(nodes=["n1:9000", "n2:9000"])
        session = cache.session
        adapter = session.get_adapter("http://example/")
        # urllib3 HTTPConnectionPool stores maxsize on the HTTPAdapter via
        # its _pool_maxsize private attr (requests>=2.28) or ._pool_kwargs.
        assert adapter._pool_maxsize >= 32
        assert adapter._pool_connections >= 2

        # env override wins
        monkeypatch.setenv("RAMJET_HTTP_POOL_SIZE", "64")
        cache2 = DistributedCache(nodes=["n1:9000"])
        adapter2 = cache2.session.get_adapter("http://example/")
        assert adapter2._pool_maxsize == 64
