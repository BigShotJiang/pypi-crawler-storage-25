"""Tests for Phase Q.2 — exponential backoff with jitter on _request().

Old behaviour: linear retry with no sleep at all → on a flapping peer the
client could fire ``retry_attempts`` requests inside a single millisecond
and amplify a transient outage into a synthetic DDoS.

New behaviour: between attempts we sleep
``min(1.0s, base * 2**attempt) * (1 ± jitter)``.

These tests pin the curve and the jitter envelope without hitting the
network — we monkey-patch ``time.sleep`` and ``requests.Session`` so the
loop runs synchronously and we can inspect every delay it produced.
"""

from unittest.mock import MagicMock, patch

import pytest
import requests

from ramjetio import cache as cache_module
from ramjetio.cache import (
    DistributedCache,
    _BACKOFF_BASE_SECONDS,
    _BACKOFF_JITTER,
)


def _make_cache(retry_attempts: int = 4) -> DistributedCache:
    # Single fake node so consistent-hash setup is happy; we never actually
    # hit it because the session is mocked.
    return DistributedCache(
        nodes=["fake-host:1"],
        retry_attempts=retry_attempts,
        timeout=0.1,
    )


class TestBackoffCurve:
    def test_no_sleep_on_success(self):
        """Happy path must not sleep at all."""
        cache = _make_cache()
        ok = MagicMock(status_code=200)
        cache._session = MagicMock(); cache._session_pid = __import__("os").getpid()
        cache.session.get.return_value = ok

        with patch.object(cache_module.time, "sleep") as mock_sleep:
            resp = cache._request("GET", "http://fake-host:1/x")

        assert resp is ok
        mock_sleep.assert_not_called()

    def test_sleeps_between_failed_attempts(self):
        """N failures → exactly N-1 sleeps (no sleep after the last try)."""
        cache = _make_cache(retry_attempts=4)
        cache._session = MagicMock(); cache._session_pid = __import__("os").getpid()
        cache.session.get.side_effect = requests.exceptions.ConnectionError("boom")

        with patch.object(cache_module.time, "sleep") as mock_sleep:
            resp = cache._request("GET", "http://fake-host:1/x")

        assert resp is None
        # 4 attempts → sleeps after attempts 0, 1, 2 (none after the final 3)
        assert mock_sleep.call_count == 3

    def test_curve_is_exponential_within_jitter(self):
        """Each delay must sit inside [base*2^a*(1-jitter), base*2^a*(1+jitter)]
        and be capped at 1s * (1+jitter)."""
        cache = _make_cache(retry_attempts=6)
        cache._session = MagicMock(); cache._session_pid = __import__("os").getpid()
        cache.session.get.side_effect = requests.exceptions.ConnectionError("boom")

        with patch.object(cache_module.time, "sleep") as mock_sleep:
            cache._request("GET", "http://fake-host:1/x")

        delays = [call.args[0] for call in mock_sleep.call_args_list]
        assert len(delays) == 5  # attempts 0..4 produce a sleep; attempt 5 does not

        for attempt, delay in enumerate(delays):
            base = min(1.0, _BACKOFF_BASE_SECONDS * (2 ** attempt))
            lo = base * (1.0 - _BACKOFF_JITTER)
            hi = base * (1.0 + _BACKOFF_JITTER)
            assert lo <= delay <= hi, (
                f"attempt {attempt}: delay {delay} outside [{lo}, {hi}]"
            )

    def test_delay_capped_at_one_second(self):
        """Even at attempt=20 the unjittered base must not exceed 1.0s."""
        # We don't actually loop 20 times — just assert the formula:
        for attempt in range(20):
            base = min(1.0, _BACKOFF_BASE_SECONDS * (2 ** attempt))
            assert base <= 1.0

    def test_jitter_actually_varies(self):
        """Across many runs the jittered delay must not be a constant."""
        cache = _make_cache(retry_attempts=2)
        cache._session = MagicMock(); cache._session_pid = __import__("os").getpid()
        cache.session.get.side_effect = requests.exceptions.ConnectionError("boom")

        observed = set()
        for _ in range(20):
            with patch.object(cache_module.time, "sleep") as mock_sleep:
                cache._request("GET", "http://fake-host:1/x")
            observed.add(round(mock_sleep.call_args_list[0].args[0], 6))

        # With ±20% jitter on a 50ms base we should easily see >1 distinct value.
        assert len(observed) > 1, f"jitter did not vary across runs: {observed}"

    def test_retries_stop_on_first_success(self):
        """Backoff must not run after a successful response."""
        cache = _make_cache(retry_attempts=4)
        ok = MagicMock(status_code=200)
        cache._session = MagicMock(); cache._session_pid = __import__("os").getpid()
        cache.session.get.side_effect = [
            requests.exceptions.ConnectionError("boom"),
            ok,
        ]

        with patch.object(cache_module.time, "sleep") as mock_sleep:
            resp = cache._request("GET", "http://fake-host:1/x")

        assert resp is ok
        # Exactly one sleep — between the failed attempt and the successful one.
        assert mock_sleep.call_count == 1
