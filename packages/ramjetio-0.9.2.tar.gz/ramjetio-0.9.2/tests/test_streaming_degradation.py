"""Graceful degradation tests for streaming path (P3.4 Step 9).

Covers two scenarios:
  1. DistributedCache down → streaming_load_image_bytes falls back to S3.
  2. S3 down → streaming_load_image_bytes returns (b'', 'failed') with a
     warning log, does NOT raise (training can continue on other samples).
"""
from __future__ import annotations

import logging

import pytest

from ramjetio.integrations.ultralytics_dataset import streaming_load_image_bytes


class _CacheDown:
    """Cache stub that raises on every operation."""

    def get_with_source(self, key):
        raise ConnectionError("simulated cache outage")

    def get(self, key):
        raise ConnectionError("simulated cache outage")

    def set(self, key, value):
        raise ConnectionError("simulated cache outage")


class _S3OK:
    def __init__(self, data: bytes = b"JPEGDATA"):
        self.data = data
        self.calls = 0

    def get_bytes(self, path):
        self.calls += 1
        return self.data


class _S3Down:
    def get_bytes(self, path):
        raise TimeoutError("simulated s3 timeout")


class _CacheMemory:
    """Minimal cache backed by a dict."""

    def __init__(self):
        self.store = {}
        self.sets = 0

    def get_with_source(self, key):
        if key in self.store:
            return self.store[key], "cache_local"
        return None, None

    def set(self, key, value):
        self.store[key] = value
        self.sets += 1


def test_cache_down_falls_back_to_s3(caplog):
    """When cache raises, S3 is still used and bytes flow through."""
    cache = _CacheDown()
    s3 = _S3OK(b"BYTES_FROM_S3")
    paths = ["s3://bucket/img0.jpg"]

    with caplog.at_level(logging.DEBUG, logger="ramjetio.integrations.ultralytics_dataset"):
        data, source = streaming_load_image_bytes(cache, s3, paths, "train", 0)

    assert data == b"BYTES_FROM_S3"
    assert source == "s3"
    assert s3.calls == 1


def test_s3_down_returns_failed_without_raising(caplog):
    """When S3 raises and key is uncached, we return ('', 'failed') + WARN."""
    cache = _CacheMemory()  # empty, so cache miss
    s3 = _S3Down()
    paths = ["s3://bucket/img1.jpg"]

    with caplog.at_level(logging.WARNING, logger="ramjetio.integrations.ultralytics_dataset"):
        data, source = streaming_load_image_bytes(cache, s3, paths, "train", 0)

    assert data == b""
    assert source == "failed"
    assert any("S3 fetch failed" in rec.message for rec in caplog.records)


def test_cache_hit_bypasses_s3():
    """Sanity: when cache has the key, S3 is not touched."""
    cache = _CacheMemory()
    cache.store["yolo_img_train_0"] = b"CACHED"
    s3 = _S3Down()  # would raise if called
    paths = ["s3://bucket/img0.jpg"]

    data, source = streaming_load_image_bytes(cache, s3, paths, "train", 0)

    assert data == b"CACHED"
    assert source == "cache_local"


def test_cache_miss_populates_on_s3_hit():
    """S3 miss-fill writes through to cache (best-effort)."""
    cache = _CacheMemory()
    s3 = _S3OK(b"FRESH")
    paths = [None] * 6
    paths[5] = "s3://bucket/img.jpg"

    data, source = streaming_load_image_bytes(cache, s3, paths, "val", 5)

    assert data == b"FRESH"
    assert source == "s3"
    assert cache.sets == 1
    assert cache.store["yolo_img_val_5"] == b"FRESH"


def test_cache_none_goes_straight_to_s3():
    """cache=None is the fork-safe child-worker path and must still work."""
    s3 = _S3OK(b"WORKER_BYTES")
    data, source = streaming_load_image_bytes(None, s3, ["s3://x/a.jpg"], "train", 0)
    assert data == b"WORKER_BYTES"
    assert source == "s3"
