"""Tests for UniversalDataset.export_labels_only (Phase P3.2).

Verifies the labels-only bootstrap writes labels + placeholders + data.yaml
in O(seconds) and does NOT materialise image bytes to disk.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Dict

import pytest

from ramjetio.datasets import UniversalDataset


class FakeClient:
    """Minimal client stand-in: dict-backed get_bytes / get_text."""

    def __init__(self, files: Dict[str, bytes]):
        self.files = files
        self.text_calls = []
        self.bytes_calls = []

    def get_bytes(self, path: str) -> bytes:
        self.bytes_calls.append(path)
        return self.files[path]

    def get_text(self, path: str) -> str:
        self.text_calls.append(path)
        return self.files[path].decode("utf-8")

    def list_files(self, prefix: str = "", suffix: str = ""):
        return [p for p in self.files if p.startswith(prefix) and p.endswith(suffix or "")]


def _make_dataset(tmp_path: Path, n_samples: int = 10):
    """Build a UniversalDataset with a fake client and n synthetic samples."""
    files = {}
    samples = []
    for i in range(n_samples):
        img_path = f"train/images/{i:04d}.jpg"
        lbl_path = f"train/labels/{i:04d}.txt"
        files[img_path] = b"\xff\xd8\xff" + b"x" * 100  # fake JPEG header
        files[lbl_path] = f"0 0.5 0.5 0.1 0.1\n".encode("utf-8")
        samples.append(img_path)

    ds = UniversalDataset.__new__(UniversalDataset)
    ds.split = "train"
    ds.img_size = 640
    ds.transform = None
    ds.format = "yolo"
    ds.samples = samples
    ds._client = FakeClient(files)
    ds._cache = None

    class _FH:
        pass
    fh = _FH()
    fh.class_names = {0: "object"}
    fh.num_classes = 1
    ds._format_handler = fh
    return ds


def test_export_labels_only_writes_labels_and_placeholders(tmp_path):
    ds = _make_dataset(tmp_path, n_samples=8)
    out = ds.export_labels_only(str(tmp_path / "export"), rank=0, world_size=1)

    assert out.endswith("data.yaml")
    assert os.path.exists(out)

    # Every sample has a .txt label...
    for i in range(8):
        lbl = tmp_path / "export" / "train" / "labels" / f"{i:06d}.txt"
        assert lbl.exists(), f"missing label {lbl}"
        assert lbl.read_text() == "0 0.5 0.5 0.1 0.1\n"

    # ...and an image file exists as a minimal-valid-JPEG placeholder
    # (Ultralytics verify_image_label rejects 0-byte files as corrupt,
    # so we write a tiny valid JPEG; load_image override supplies real bytes).
    for i in range(8):
        img = tmp_path / "export" / "train" / "images" / f"{i:06d}.jpg"
        assert img.exists(), f"missing placeholder {img}"
        size = img.stat().st_size
        assert 0 < size < 2000, f"placeholder must be a tiny JPEG ({img} is {size}B)"
        assert img.read_bytes().startswith(b'\xff\xd8\xff'), "must be valid JPEG header"


def test_export_labels_only_never_fetches_image_bytes(tmp_path):
    """Image bytes must NOT be touched — only labels are fetched."""
    ds = _make_dataset(tmp_path, n_samples=5)
    ds.export_labels_only(str(tmp_path / "export"), rank=0, world_size=1)
    assert ds._client.bytes_calls == [], (
        f"get_bytes must not be called during label-only export, "
        f"got: {ds._client.bytes_calls}"
    )
    # Labels WERE fetched
    assert len(ds._client.text_calls) == 5


def test_export_labels_only_shards_by_rank(tmp_path):
    """Rank N only writes REAL labels for its shard; other indices get placeholders."""
    ds = _make_dataset(tmp_path, n_samples=10)
    ds.export_labels_only(str(tmp_path / "export"), rank=1, world_size=2)

    # Rank 1 owns odd indices (1, 3, 5, 7, 9).
    labels_dir = tmp_path / "export" / "train" / "labels"
    images_dir = tmp_path / "export" / "train" / "images"

    for i in [1, 3, 5, 7, 9]:
        assert (labels_dir / f"{i:06d}.txt").exists()
        # Image placeholder also exists for owned indices.
        assert (images_dir / f"{i:06d}.jpg").exists()

    for i in [0, 2, 4, 6, 8]:
        # Non-owned: no label from this rank, but placeholder image exists
        # (so Ultralytics get_img_files sees the full directory).
        assert not (labels_dir / f"{i:06d}.txt").exists(), (
            f"rank 1 should not write labels for non-owned idx {i}"
        )
        assert (images_dir / f"{i:06d}.jpg").exists(), (
            f"placeholder for idx {i} must still be created"
        )


def test_export_labels_only_writes_valid_data_yaml(tmp_path):
    import yaml as yaml_mod
    ds = _make_dataset(tmp_path, n_samples=3)
    ds._format_handler.class_names = {0: "person", 1: "car"}
    out = ds.export_labels_only(str(tmp_path / "export"), rank=0, world_size=1)
    data = yaml_mod.safe_load(open(out))
    assert data["nc"] == 2
    assert data["names"] == {0: "person", 1: "car"}
    assert data["train"] == "train/images"
    assert data["val"] == "train/images"
    # Path must be absolute so Ultralytics can resolve it regardless of CWD.
    assert os.path.isabs(data["path"])


def test_export_labels_only_rejects_non_yolo_format(tmp_path):
    ds = _make_dataset(tmp_path, n_samples=1)
    ds.format = "coco"
    with pytest.raises(NotImplementedError, match="YOLO"):
        ds.export_labels_only(str(tmp_path / "export"))


def test_export_labels_only_is_fast(tmp_path):
    """Sanity: 500 samples should take << 1s with the thread pool."""
    import time
    ds = _make_dataset(tmp_path, n_samples=500)
    t0 = time.time()
    ds.export_labels_only(str(tmp_path / "export"), rank=0, world_size=1)
    elapsed = time.time() - t0
    assert elapsed < 5.0, f"label-only export took {elapsed:.2f}s for 500 samples (too slow)"
