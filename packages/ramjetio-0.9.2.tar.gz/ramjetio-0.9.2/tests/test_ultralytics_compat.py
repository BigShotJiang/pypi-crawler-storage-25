"""Ultralytics version-compat guard tests (P3.4 Step 7)."""
from __future__ import annotations

import logging
import sys
import types

import pytest


@pytest.fixture
def fake_ultralytics(monkeypatch):
    """Inject a stub `ultralytics` module with a controllable version."""
    mod = types.ModuleType("ultralytics")
    mod.__version__ = "8.4.37"
    monkeypatch.setitem(sys.modules, "ultralytics", mod)
    yield mod


def test_compat_accepts_supported_version(fake_ultralytics, caplog):
    from ramjetio.integrations.ultralytics_dataset import _assert_ultralytics_compat

    caplog.set_level(logging.WARNING)
    fake_ultralytics.__version__ = "8.4.37"
    _assert_ultralytics_compat()
    # No WARNING emitted for the tested version range.
    assert not any(
        r.levelno >= logging.WARNING and "ultralytics" in r.message.lower()
        for r in caplog.records
    )


def test_compat_warns_on_newer_version(fake_ultralytics, caplog, monkeypatch):
    from ramjetio.integrations.ultralytics_dataset import _assert_ultralytics_compat

    monkeypatch.delenv("RAMJET_ULTRALYTICS_STRICT", raising=False)
    fake_ultralytics.__version__ = "8.5.1"
    caplog.set_level(logging.WARNING)
    _assert_ultralytics_compat()
    assert any("8.5.1" in r.message for r in caplog.records)


def test_compat_raises_when_strict(fake_ultralytics, monkeypatch):
    from ramjetio.integrations.ultralytics_dataset import _assert_ultralytics_compat

    monkeypatch.setenv("RAMJET_ULTRALYTICS_STRICT", "1")
    fake_ultralytics.__version__ = "9.0.0"
    with pytest.raises(ImportError, match="9.0.0"):
        _assert_ultralytics_compat()


def test_compat_handles_unparseable_version(fake_ultralytics, caplog, monkeypatch):
    from ramjetio.integrations.ultralytics_dataset import _assert_ultralytics_compat

    monkeypatch.delenv("RAMJET_ULTRALYTICS_STRICT", raising=False)
    fake_ultralytics.__version__ = "not-a-version"
    caplog.set_level(logging.WARNING)
    _assert_ultralytics_compat()
    # Should warn rather than crash.
    assert any("not-a-version" in r.message for r in caplog.records)
