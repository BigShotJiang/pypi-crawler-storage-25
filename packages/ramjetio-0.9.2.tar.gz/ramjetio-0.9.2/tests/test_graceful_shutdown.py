"""F-Shut1 / F-Recon1: graceful shutdown + reconnect backoff tests.

Pure unit tests — no real subprocess, no real backend connection.
"""

from __future__ import annotations

import os
from unittest import mock

import pytest

import ramjetio
from ramjetio.backend_client import BackendClient
from ramjetio.config import RECONNECT_INTERVAL


# ---------------------------------------------------------------------------
# F-Recon1: exponential backoff with jitter
# ---------------------------------------------------------------------------

class TestReconnectBackoff:
    def test_first_attempt_is_about_one_second(self):
        # jitter_rand=0.5 -> jitter contribution = 0.2 * (2*0.5-1) = 0
        assert BackendClient._reconnect_backoff_seconds(1, 0.5) == pytest.approx(1.0)

    def test_doubles_until_cap(self):
        # 1, 2, 4, 8, 16 -> capped at RECONNECT_INTERVAL
        seqs = [BackendClient._reconnect_backoff_seconds(i, 0.5) for i in range(1, 8)]
        assert seqs[0] == pytest.approx(1.0)
        assert seqs[1] == pytest.approx(2.0)
        assert seqs[2] == pytest.approx(4.0)
        # All entries are <= cap.
        for v in seqs:
            assert v <= RECONNECT_INTERVAL + 1e-6

    def test_jitter_range_is_plus_minus_twenty_percent(self):
        # At a value below the cap, jitter spans ±20% of the raw exponential.
        low = BackendClient._reconnect_backoff_seconds(2, 0.0)   # min jitter
        mid = BackendClient._reconnect_backoff_seconds(2, 0.5)   # zero jitter
        high = BackendClient._reconnect_backoff_seconds(2, 1.0)  # max jitter
        # mid == 2.0, low ~= 1.6, high ~= 2.4 — strictly ordered.
        assert low < mid < high
        # Bounded within ±20%.
        assert mid * 0.8 <= low <= mid
        assert mid <= high <= mid * 1.2

    def test_minimum_floor_of_100ms(self):
        # Even pathological inputs never sleep less than 0.1s — protects
        # against tight retry loops in case of a math regression.
        for j in (0.0, 0.1, 0.5, 0.9, 1.0):
            v = BackendClient._reconnect_backoff_seconds(0, j)
            assert v >= 0.1

    def test_jitter_does_not_exceed_cap_meaningfully(self):
        # At the cap, +20% jitter takes us slightly above; that's acceptable
        # but we still shouldn't see runaway sleep values.
        for _ in range(50):
            v = BackendClient._reconnect_backoff_seconds(20, 0.999)
            assert v <= RECONNECT_INTERVAL * 1.2 + 0.1


# ---------------------------------------------------------------------------
# F-Shut1: shutdown() hardening
# ---------------------------------------------------------------------------

class _FakeProc:
    """subprocess.Popen stand-in."""
    def __init__(self, exits_within: float = 0.0):
        self._poll = None  # alive
        self._exits_within = exits_within
        self.terminate_calls = 0
        self.kill_calls = 0
        self.wait_calls: list[float] = []
        self.returncode = None

    def poll(self):
        return self._poll

    def terminate(self):
        self.terminate_calls += 1
        if self._exits_within == 0.0:
            self._poll = 0
            self.returncode = 0

    def kill(self):
        self.kill_calls += 1
        self._poll = -9
        self.returncode = -9

    def wait(self, timeout=None):
        self.wait_calls.append(timeout or 0.0)
        if self._poll is None:
            # Hadn't exited on terminate -> simulate timeout.
            import subprocess
            raise subprocess.TimeoutExpired(cmd="fake", timeout=timeout)
        return self.returncode


@pytest.fixture
def reset_state():
    """Reset module-level globals after each test."""
    yield
    ramjetio._server_process = None
    ramjetio._backend_client = None
    ramjetio._global_cache = None
    ramjetio._initialized = False
    ramjetio._shutdown_in_progress = False
    ramjetio._refresh_running = False
    ramjetio._topology_watch_running = False


class TestShutdown:
    def test_idempotent_when_uninitialised(self, reset_state):
        # Calling shutdown() twice on a clean state must not raise.
        ramjetio.shutdown()
        ramjetio.shutdown()

    def test_terminates_subprocess_then_waits(self, reset_state):
        proc = _FakeProc(exits_within=0.0)  # exits immediately on terminate
        ramjetio._server_process = proc
        ramjetio.shutdown()
        assert proc.terminate_calls == 1
        assert proc.kill_calls == 0
        assert proc.wait_calls  # wait() was called
        assert ramjetio._server_process is None

    def test_sigkill_on_grace_overrun(self, reset_state, monkeypatch):
        proc = _FakeProc(exits_within=999.0)  # never exits on its own
        ramjetio._server_process = proc
        # Shrink grace so the test runs fast.
        monkeypatch.setattr(ramjetio, "_SHUTDOWN_GRACE_S", 0.05)
        # After timeout, our fake's kill() flips _poll, so the second wait
        # returns the fake return code.
        ramjetio.shutdown()
        assert proc.terminate_calls == 1
        assert proc.kill_calls == 1, "expected SIGKILL after grace overrun"

    def test_calls_backend_stop(self, reset_state):
        client = mock.MagicMock()
        ramjetio._backend_client = client
        ramjetio.shutdown()
        client.stop.assert_called_once()
        assert ramjetio._backend_client is None

    def test_swallows_backend_stop_errors(self, reset_state):
        client = mock.MagicMock()
        client.stop.side_effect = RuntimeError("network gone")
        ramjetio._backend_client = client
        # Must not propagate.
        ramjetio.shutdown()
        assert ramjetio._backend_client is None

    def test_clears_running_flags(self, reset_state):
        ramjetio._refresh_running = True
        ramjetio._topology_watch_running = True
        ramjetio.shutdown()
        assert ramjetio._refresh_running is False
        assert ramjetio._topology_watch_running is False

    def test_atexit_hook_swallows_exceptions(self, reset_state, monkeypatch):
        # If shutdown() somehow raises, _atexit_shutdown must NOT propagate
        # — we don't want to break interpreter teardown.
        def boom():
            raise RuntimeError("boom")
        monkeypatch.setattr(ramjetio, "shutdown", boom)
        # Must complete without raising.
        ramjetio._atexit_shutdown()

    def test_unlinks_topology_file_on_local_main(self, reset_state, tmp_path, monkeypatch):
        topo = tmp_path / "topo.json"
        topo.write_text("{}")
        monkeypatch.setattr(ramjetio, "_TOPOLOGY_FILE", str(topo))
        # Simulate LOCAL_RANK=0 (default behaviour with no env vars).
        monkeypatch.delenv("LOCAL_RANK", raising=False)
        monkeypatch.delenv("SLURM_LOCALID", raising=False)
        ramjetio.shutdown()
        assert not topo.exists(), "publishing rank should clean up topology file"

    def test_keeps_topology_file_on_non_main_local(self, reset_state, tmp_path, monkeypatch):
        topo = tmp_path / "topo.json"
        topo.write_text("{}")
        monkeypatch.setattr(ramjetio, "_TOPOLOGY_FILE", str(topo))
        monkeypatch.setenv("LOCAL_RANK", "1")  # non-zero rank
        ramjetio.shutdown()
        assert topo.exists(), "non-publishing rank must not delete topology"
