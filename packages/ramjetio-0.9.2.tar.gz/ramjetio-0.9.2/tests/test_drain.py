"""Phase 6.A: graceful drain endpoints on CacheServer.

POST /drain        — start pushing local keys to future_nodes
GET  /drain/status — query progress
POST /drain/cancel — abort gracefully

Verifies:
  * full round-trip on a 3-node harness (keys land on future owners)
  * status state machine (idle → running → done)
  * 409 on concurrent drain
  * 400 on bad inputs
  * cancellation produces state="cancelled"
  * empty cache → state="done", total=0
  * keys whose new owner == self_address are skipped (no orphan push)
  * /diagnostics surfaces drain bucket
  * auth: 401 when expected key missing
  * partial network failure → state="done", errors > 0
"""

from __future__ import annotations

import os
import time
from pathlib import Path
from typing import Dict, List, Optional

import pytest
import requests

from ramjetio.cache import DistributedCache
from ramjetio.consistent_hash import ConsistentHash
from tests._multinode_harness import NodeHandle, start_cluster, start_node, stop_cluster


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #

def _put_via_set(node: NodeHandle, key: str, payload: bytes) -> None:
    r = requests.post(
        f"http://{node.address}/set",
        params={"key": key},
        data=payload,
        timeout=5,
    )
    assert r.status_code == 200, r.text


def _wait_drain(node: NodeHandle, expected_state: str, timeout: float = 10.0) -> Dict:
    deadline = time.time() + timeout
    last: Dict = {}
    while time.time() < deadline:
        r = requests.get(f"http://{node.address}/drain/status", timeout=2)
        assert r.status_code == 200
        last = r.json()
        if last["state"] == expected_state:
            return last
        time.sleep(0.05)
    raise AssertionError(f"drain did not reach {expected_state!r}; last={last}")


def _post_drain(node: NodeHandle, **body) -> requests.Response:
    return requests.post(f"http://{node.address}/drain", json=body, timeout=5)


def _envelope(s: str) -> bytes:
    # RJRB = raw bytes envelope magic (see server._ALLOWED_MAGICS).
    return b"RJRB" + s.encode("utf-8")


# --------------------------------------------------------------------------- #
# Fixtures
# --------------------------------------------------------------------------- #

@pytest.fixture
def cluster3(tmp_path, monkeypatch):
    monkeypatch.delenv("RAMJET_API_KEY", raising=False)
    nodes = start_cluster(tmp_path, n=3)
    try:
        yield nodes
    finally:
        stop_cluster(nodes)


# --------------------------------------------------------------------------- #
# 1. State machine basics
# --------------------------------------------------------------------------- #

def test_drain_status_idle_at_startup(cluster3):
    node = cluster3[0]
    r = requests.get(f"http://{node.address}/drain/status", timeout=2)
    assert r.status_code == 200
    body = r.json()
    assert body["state"] == "idle"
    assert body["total"] == 0
    assert body["done"] == 0
    assert body["errors"] == 0
    assert body["started_ts"] is None


def test_drain_empty_cache_completes_immediately(cluster3):
    leaving, peer_a, peer_b = cluster3
    future = [peer_a.address, peer_b.address]
    r = _post_drain(leaving, future_nodes=future, self_address=leaving.address)
    assert r.status_code == 202
    final = _wait_drain(leaving, "done")
    assert final["total"] == 0
    assert final["done"] == 0
    assert final["errors"] == 0


# --------------------------------------------------------------------------- #
# 2. Full round-trip
# --------------------------------------------------------------------------- #

def test_drain_pushes_keys_to_future_owners(cluster3):
    leaving, peer_a, peer_b = cluster3
    # Seed only the leaving node with 30 keys.
    keys = [f"obj-{i}" for i in range(30)]
    for k in keys:
        _put_via_set(leaving, k, _envelope(f"v-{k}"))

    future = [peer_a.address, peer_b.address]
    r = _post_drain(leaving, future_nodes=future, self_address=leaving.address)
    assert r.status_code == 202
    final = _wait_drain(leaving, "done")
    assert final["total"] == 30
    assert final["done"] == 30
    assert final["errors"] == 0

    # Every key should now be retrievable from its future owner.
    ring = ConsistentHash(future)
    found = 0
    for k in keys:
        owner = ring.get_node(k)
        peer = peer_a if owner == peer_a.address else peer_b
        r = requests.get(f"http://{peer.address}/get", params={"key": k}, timeout=2)
        if r.status_code == 200 and r.content == _envelope(f"v-{k}"):
            found += 1
    # At least 90% should land on the deterministic owner; harness routing
    # should be exact, so allow a small slack only for diskcache eviction edge.
    assert found >= 27, f"only {found}/30 keys reachable on future ring"


def test_drain_skips_keys_whose_future_owner_is_self(cluster3):
    """When this node is also in future_nodes (replication scenario), keys
    whose target == self_address must be skipped (no orphan/loop push)."""
    leaving, peer_a, peer_b = cluster3
    for i in range(20):
        _put_via_set(leaving, f"k{i}", _envelope(f"v{i}"))

    # Future ring INCLUDES the "leaving" node (e.g. config-version bump only).
    future = [leaving.address, peer_a.address, peer_b.address]
    r = _post_drain(leaving, future_nodes=future, self_address=leaving.address)
    assert r.status_code == 202
    final = _wait_drain(leaving, "done")
    # All keys counted as done; some may be skipped (errors=0).
    assert final["total"] == 20
    assert final["done"] == 20
    assert final["errors"] == 0


# --------------------------------------------------------------------------- #
# 3. Concurrency / errors / cancellation
# --------------------------------------------------------------------------- #

def test_drain_409_when_already_running(cluster3):
    """409 if a drain is already in flight. Bypass HTTP-timing flakiness by
    flipping the state flag directly on the server object — we are testing
    the handler's guard, not the worker's progress here."""
    leaving, a, b = cluster3
    # Force the server into the "running" state without launching a worker.
    with leaving.server._drain_lock:
        leaving.server._drain_state = "running"
        leaving.server._drain_total = 1
        leaving.server._drain_done = 0
        leaving.server._drain_errors = 0
        leaving.server._drain_started_ts = time.time()
        leaving.server._drain_completed_ts = None
    try:
        r = requests.post(
            f"http://{leaving.address}/drain",
            json={
                "future_nodes": [a.address, b.address],
                "self_address": leaving.address,
            },
            timeout=5,
        )
        assert r.status_code == 409
        body = r.json()
        assert body["state"] == "running"
        # /drain/status keeps working.
        s = requests.get(f"http://{leaving.address}/drain/status", timeout=2)
        assert s.json()["state"] == "running"
    finally:
        # Reset so cluster teardown is clean.
        with leaving.server._drain_lock:
            leaving.server._drain_state = "idle"


def test_drain_cancel(cluster3):
    """Cancellation aborts drain mid-flight. Many keys + replication=2 →
    drain takes long enough for the cancel to land before completion."""
    leaving, a, b = cluster3
    big = b"RJRB" + (b"x" * 4096)
    for i in range(500):
        _put_via_set(leaving, f"k{i}", big)
    r = _post_drain(
        leaving,
        future_nodes=[a.address, b.address],
        self_address=leaving.address,
        replication_factor=2,
    )
    assert r.status_code == 202
    # Cancel immediately — drain has 500 * 2 = 1000 pushes to make.
    rc = requests.post(f"http://{leaving.address}/drain/cancel", timeout=5)
    assert rc.status_code in (202, 409), rc.text
    # 409 here means drain already finished — accept that and skip.
    if rc.status_code == 409:
        final = requests.get(f"http://{leaving.address}/drain/status", timeout=2).json()
        assert final["state"] in ("done", "cancelled")
    else:
        final = _wait_drain(leaving, "cancelled", timeout=30)
        assert final["state"] == "cancelled"
        assert final["done"] <= final["total"]


def test_drain_cancel_when_idle_returns_409(cluster3):
    node = cluster3[0]
    rc = requests.post(f"http://{node.address}/drain/cancel", timeout=2)
    assert rc.status_code == 409


def test_drain_validation_errors(cluster3):
    node = cluster3[0]
    # Missing future_nodes.
    assert _post_drain(node, self_address=node.address).status_code == 400
    # Missing self_address.
    assert _post_drain(node, future_nodes=[node.address]).status_code == 400
    # Bad type for future_nodes.
    r = requests.post(
        f"http://{node.address}/drain",
        json={"future_nodes": "not-a-list", "self_address": node.address},
        timeout=2,
    )
    assert r.status_code == 400
    # Bad replication_factor.
    r = requests.post(
        f"http://{node.address}/drain",
        json={
            "future_nodes": [node.address],
            "self_address": node.address,
            "replication_factor": 0,
        },
        timeout=2,
    )
    assert r.status_code == 400


def test_drain_partial_failure_marks_errors(cluster3, tmp_path):
    """If some target nodes are unreachable, drain still completes (best-effort)
    but ``errors`` is > 0 and ``state`` becomes ``done``."""
    leaving, peer_a, _peer_b = cluster3
    for i in range(15):
        _put_via_set(leaving, f"k{i}", _envelope(f"v{i}"))

    # future_nodes includes a real peer + a black-hole address that nothing
    # listens on. Some keys will route to the dead address.
    dead = "127.0.0.1:1"  # port 1 — connection refused
    r = _post_drain(
        leaving,
        future_nodes=[peer_a.address, dead],
        self_address=leaving.address,
    )
    assert r.status_code == 202
    final = _wait_drain(leaving, "done", timeout=30)
    assert final["state"] == "done"
    assert final["total"] == 15
    assert final["done"] == 15
    assert final["errors"] >= 1
    assert final["last_error"] is not None


# --------------------------------------------------------------------------- #
# 4. /diagnostics integration
# --------------------------------------------------------------------------- #

def test_diagnostics_surfaces_drain_bucket(cluster3):
    node = cluster3[0]
    r = requests.get(f"http://{node.address}/diagnostics", timeout=2)
    assert r.status_code == 200
    body = r.json()
    assert "drain" in body
    assert body["drain"]["state"] == "idle"


# --------------------------------------------------------------------------- #
# 5. Auth
# --------------------------------------------------------------------------- #

def test_drain_endpoints_require_api_key(tmp_path, monkeypatch):
    monkeypatch.setenv("RAMJET_API_KEY", "secret-xyz")
    node = start_node(tmp_path / "n0")
    try:
        # No header → 401 on all three drain routes.
        assert requests.get(f"http://{node.address}/drain/status", timeout=2).status_code == 401
        assert requests.post(f"http://{node.address}/drain", json={
            "future_nodes": [node.address],
            "self_address": node.address,
        }, timeout=2).status_code == 401
        assert requests.post(f"http://{node.address}/drain/cancel", timeout=2).status_code == 401
        # With header → not 401 (idle status returns 200; cancel returns 409 since idle).
        h = {"X-RAMJET-API-Key": "secret-xyz"}
        assert requests.get(f"http://{node.address}/drain/status", headers=h, timeout=2).status_code == 200
        assert requests.post(f"http://{node.address}/drain/cancel", headers=h, timeout=2).status_code == 409
    finally:
        node.stop()
