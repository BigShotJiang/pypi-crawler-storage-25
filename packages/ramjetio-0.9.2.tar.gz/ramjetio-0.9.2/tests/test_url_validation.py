"""SSRF guard tests for the SDK url_validation module."""

from __future__ import annotations

import socket
from unittest.mock import patch

import pytest

from ramjetio.url_validation import UnsafeURLError, validate_datasource_url


def _fake_getaddrinfo(ip: str):
    """Build a getaddrinfo replacement that always returns a single IP."""
    family = socket.AF_INET6 if ":" in ip else socket.AF_INET

    def _impl(host, port, *args, **kwargs):
        return [(family, socket.SOCK_STREAM, 0, "", (ip, port or 0))]

    return _impl


# ------- literal-IP rejections (no DNS) --------------------------------------

@pytest.mark.parametrize("url,fragment", [
    ("http://127.0.0.1/", "loopback"),
    ("http://127.1.2.3/", "loopback"),
    ("http://[::1]/", "loopback"),
    ("http://169.254.169.254/", "cloud metadata"),
    ("http://169.254.10.10/", "link-local"),
    ("http://0.0.0.0/", "unspecified"),
    ("http://224.0.0.1/", "multicast"),
])
def test_literal_ip_blocked_by_default(url, fragment):
    with pytest.raises(UnsafeURLError) as exc:
        validate_datasource_url(url)
    assert fragment in str(exc.value)


def test_metadata_blocked_even_with_loopback_allow(monkeypatch):
    # ALLOW_LOOPBACK should not lift the metadata block.
    monkeypatch.setenv("RAMJET_SDK_ALLOW_LOOPBACK", "1")
    with pytest.raises(UnsafeURLError, match="cloud metadata"):
        validate_datasource_url("http://169.254.169.254/")


def test_loopback_allowed_with_env(monkeypatch):
    monkeypatch.setenv("RAMJET_SDK_ALLOW_LOOPBACK", "1")
    # Should not raise.
    validate_datasource_url("http://127.0.0.1:9000/")


# ------- private IPs: SDK default is *permissive* ----------------------------

def test_private_allowed_by_default():
    # SDK default: corporate MinIO on 10.x must work.
    validate_datasource_url("http://10.0.0.5:9000/")
    validate_datasource_url("http://192.168.1.10/")


def test_private_blocked_in_strict_mode(monkeypatch):
    monkeypatch.setenv("RAMJET_SDK_BLOCK_PRIVATE_DATASOURCES", "1")
    with pytest.raises(UnsafeURLError, match="private address"):
        validate_datasource_url("http://10.0.0.5/")


# ------- DNS path -----------------------------------------------------------

def test_hostname_resolving_to_loopback_blocked():
    with patch("ramjetio.url_validation.socket.getaddrinfo",
               side_effect=_fake_getaddrinfo("127.0.0.1")):
        with pytest.raises(UnsafeURLError, match="loopback"):
            validate_datasource_url("https://attacker.example/")


def test_hostname_resolving_to_metadata_blocked():
    with patch("ramjetio.url_validation.socket.getaddrinfo",
               side_effect=_fake_getaddrinfo("169.254.169.254")):
        with pytest.raises(UnsafeURLError, match="cloud metadata"):
            validate_datasource_url("https://innocent-looking.example/")


def test_hostname_resolving_to_public_ip_passes():
    with patch("ramjetio.url_validation.socket.getaddrinfo",
               side_effect=_fake_getaddrinfo("93.184.216.34")):  # example.com
        validate_datasource_url("https://example.com/")


def test_unresolvable_hostname_rejected():
    with patch("ramjetio.url_validation.socket.getaddrinfo",
               side_effect=socket.gaierror("nope")):
        with pytest.raises(UnsafeURLError, match="did not resolve"):
            validate_datasource_url("https://nx.invalid/")


# ------- syntactic validation ------------------------------------------------

@pytest.mark.parametrize("bad", [
    "",
    "ftp://example.com/",
    "file:///etc/passwd",
    "https:///",
])
def test_bad_syntax_rejected(bad):
    with pytest.raises(UnsafeURLError):
        validate_datasource_url(bad)


def test_bare_host_treated_as_https():
    with patch("ramjetio.url_validation.socket.getaddrinfo",
               side_effect=_fake_getaddrinfo("8.8.8.8")):
        # Backend stores S3 endpoints without a scheme; validator must
        # accept that form and add https:// internally.
        validate_datasource_url("minio.example.com")


# ------- integration with S3Client / HTTPClient constructors ---------------

def test_s3client_rejects_loopback_endpoint():
    boto3 = pytest.importorskip("boto3")  # noqa: F841
    from ramjetio.datasets import S3Client
    with pytest.raises(ValueError, match="S3 endpoint rejected"):
        S3Client({
            "s3_endpoint": "http://127.0.0.1:9000",
            "s3_bucket": "x",
            "s3_access_key": "a",
            "s3_secret_key": "b",
        })


def test_httpclient_rejects_metadata_url():
    requests = pytest.importorskip("requests")  # noqa: F841
    from ramjetio.datasets import HTTPClient
    with pytest.raises(ValueError, match="HTTP url rejected"):
        HTTPClient({"http_url": "http://169.254.169.254/"})
