"""Tests for P3.3 Step 1: val suppression in streaming_train.

``_attach_val_suppression_callbacks`` installs an ``on_train_start``
callback that stubs ``trainer.validate``, ``trainer.final_eval`` and
disables ``args.val`` / ``args.plots``. This avoids a ~200 s val loop
at end-of-training whose metrics would be meaningless anyway because
streaming path leaves 32×32 JPEG placeholders on disk.
"""
from __future__ import annotations

from types import SimpleNamespace

import pytest


class FakeModel:
    """Minimal stand-in for ultralytics.YOLO for callback registration."""

    def __init__(self):
        self.callbacks = {}

    def add_callback(self, event, fn):
        self.callbacks.setdefault(event, []).append(fn)


class FakeTrainer:
    def __init__(self):
        self.args = SimpleNamespace(val=True, plots=True)
        self.validate = lambda *a, **k: ({"map": 0.5}, 0.5)
        self.final_eval = lambda *a, **k: "would-run-gather_object"
        self.validator = object()


def _fire(model, event, trainer):
    for fn in model.callbacks.get(event, []):
        fn(trainer)


def test_val_suppression_stubs_methods_and_flags():
    from ramjetio.integrations.ultralytics import _attach_val_suppression_callbacks

    model = FakeModel()
    trainer = FakeTrainer()

    _attach_val_suppression_callbacks(model)
    _fire(model, "on_train_start", trainer)

    assert trainer.args.val is False
    assert trainer.args.plots is False
    assert trainer.validator is None
    # stubs must be callable and return safe values
    assert trainer.validate() == ({}, 0.0)
    assert trainer.validate(1, 2, foo="bar") == ({}, 0.0)
    assert trainer.final_eval() is None
    assert trainer.final_eval("x", y="z") is None


def test_val_suppression_is_idempotent_across_multiple_fires():
    from ramjetio.integrations.ultralytics import _attach_val_suppression_callbacks

    model = FakeModel()
    trainer = FakeTrainer()

    _attach_val_suppression_callbacks(model)
    _fire(model, "on_train_start", trainer)
    _fire(model, "on_train_start", trainer)

    assert trainer.args.val is False
    assert trainer.validate() == ({}, 0.0)


def test_val_suppression_swallows_missing_args_attr():
    """If trainer is a bare object with no .args, callback must not crash."""
    from ramjetio.integrations.ultralytics import _attach_val_suppression_callbacks

    model = FakeModel()
    bare = SimpleNamespace()  # no .args, no .validate, etc.

    _attach_val_suppression_callbacks(model)
    # Must not raise.
    _fire(model, "on_train_start", bare)

    # Stubs still installed on whatever attrs the trainer had (none here);
    # main contract is "no exception bubbles out".
    assert True


def test_streaming_train_attaches_val_suppression_callback():
    """streaming_train should register the val-suppression hook alongside
    freeze-ring and progress hooks."""
    from ramjetio.integrations import ultralytics as ult_mod

    model = FakeModel()
    # We can't actually call streaming_train() without ramjetio.init(),
    # but we can verify the helper wires the callback on its own.
    ult_mod._attach_val_suppression_callbacks(model)
    assert "on_train_start" in model.callbacks
    assert len(model.callbacks["on_train_start"]) >= 1
