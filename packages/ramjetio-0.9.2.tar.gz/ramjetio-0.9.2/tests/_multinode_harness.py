"""Shared harness for Phase 4 multi-node integration tests.

Spins up real ``CacheServer`` instances on ephemeral 127.0.0.1 ports inside
dedicated background threads (each with its own asyncio loop) so the
synchronous ``DistributedCache`` client can drive them with ``requests``
without deadlocking the test loop.

Used by:
  * test_e2e_multinode.py    — hit-ratio growth, ring stability, source split
  * test_chaos_resilience.py — slow origin, circuit breaker, ring churn
"""

from __future__ import annotations

import asyncio
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

from aiohttp import web

from ramjetio.server import CacheServer


@dataclass
class NodeHandle:
    server: CacheServer
    address: str   # "127.0.0.1:<port>"
    port: int
    storage_path: Path
    _thread: threading.Thread
    _loop: asyncio.AbstractEventLoop
    _runner: web.AppRunner
    _site: web.TCPSite

    def stop(self) -> None:
        async def _shutdown() -> None:
            await self._site.stop()
            await self._runner.cleanup()
        fut = asyncio.run_coroutine_threadsafe(_shutdown(), self._loop)
        try:
            fut.result(timeout=5)
        except Exception:
            pass
        self._loop.call_soon_threadsafe(self._loop.stop)
        self._thread.join(timeout=5)
        try:
            self.server.close()
        except Exception:
            pass


def start_node(storage_path: Path, port: int = 0,
               max_capacity: int = 10 * 1024 * 1024) -> NodeHandle:
    """Spin one CacheServer on its own thread+loop. Blocks until ready."""
    storage_path.mkdir(parents=True, exist_ok=True)
    srv = CacheServer(
        host="127.0.0.1",
        port=port,
        storage_path=str(storage_path),
        max_capacity=max_capacity,
    )
    app = srv.create_app()

    ready = threading.Event()
    holder: dict = {}

    def _run() -> None:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        runner = web.AppRunner(app)
        loop.run_until_complete(runner.setup())
        site = web.TCPSite(runner, "127.0.0.1", port)
        loop.run_until_complete(site.start())
        # Discover assigned port.
        sock = site._server.sockets[0]  # type: ignore[union-attr]
        bound_port = sock.getsockname()[1]
        holder["loop"] = loop
        holder["runner"] = runner
        holder["site"] = site
        holder["port"] = bound_port
        ready.set()
        loop.run_forever()

    thread = threading.Thread(target=_run, daemon=True, name=f"cache-node-{port}")
    thread.start()
    if not ready.wait(timeout=10):
        raise RuntimeError("CacheServer thread did not start in time")

    bound_port = holder["port"]
    return NodeHandle(
        server=srv,
        address=f"127.0.0.1:{bound_port}",
        port=bound_port,
        storage_path=storage_path,
        _thread=thread,
        _loop=holder["loop"],
        _runner=holder["runner"],
        _site=holder["site"],
    )


def start_cluster(tmp_path: Path, n: int = 3) -> List[NodeHandle]:
    return [start_node(tmp_path / f"node{i}") for i in range(n)]


def stop_cluster(nodes: List[NodeHandle]) -> None:
    for n in nodes:
        n.stop()
