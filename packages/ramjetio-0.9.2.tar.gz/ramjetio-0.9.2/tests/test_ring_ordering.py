"""F-Ring1: deterministic node ordering across processes/ranks.

Routing was already deterministic via MD5 hashing of virtual-node keys.
These tests pin down the *visible* membership order
(``cache.nodes``, ``hash_ring.get_all_nodes()``) so two ranks that
discover the same set in different orders still publish identical
JSON to the topology file and emit identical logs.
"""

from __future__ import annotations

import pytest

from ramjetio.cache import DistributedCache
from ramjetio.consistent_hash import ConsistentHash


NODES_A = ["a:9000", "b:9000", "c:9000"]
NODES_B = ["c:9000", "a:9000", "b:9000"]
NODES_C = ["b:9000", "c:9000", "a:9000"]


# --- ConsistentHash ----------------------------------------------------------

def test_consistent_hash_init_order_independent():
    """Same set, different argument order -> same get_all_nodes()."""
    ra = ConsistentHash(nodes=NODES_A).get_all_nodes()
    rb = ConsistentHash(nodes=NODES_B).get_all_nodes()
    rc = ConsistentHash(nodes=NODES_C).get_all_nodes()
    assert ra == rb == rc == sorted(NODES_A)


def test_consistent_hash_add_order_independent():
    ch1 = ConsistentHash()
    for n in NODES_A:
        ch1.add_node(n)
    ch2 = ConsistentHash()
    for n in NODES_C:
        ch2.add_node(n)
    assert ch1.get_all_nodes() == ch2.get_all_nodes()


def test_consistent_hash_routing_unchanged_after_sort():
    """Ring contents are the union of MD5(node:i) hashes; sorting nodes
    must not change which physical node a key maps to."""
    ch = ConsistentHash(nodes=NODES_A)
    keys = [f"img/{i}.jpg" for i in range(500)]
    mapping = {k: ch.get_node(k) for k in keys}
    # Recreate from a different insertion order; mapping must be identical.
    ch2 = ConsistentHash(nodes=NODES_C)
    for k in keys:
        assert ch2.get_node(k) == mapping[k]


# --- DistributedCache --------------------------------------------------------

def test_cache_init_sorts_nodes():
    c = DistributedCache(nodes=NODES_C)
    assert c.nodes == sorted(NODES_C)


def test_cache_replace_nodes_sorts():
    c = DistributedCache(nodes=NODES_A)
    c.replace_nodes(NODES_C, version=c.config_version + 1)
    assert c.nodes == sorted(NODES_C)


def test_cache_add_node_keeps_sorted():
    c = DistributedCache(nodes=["b:9000", "d:9000"])
    c.add_node("a:9000")
    c.add_node("c:9000")
    assert c.nodes == ["a:9000", "b:9000", "c:9000", "d:9000"]


def test_two_caches_with_different_insert_orders_match():
    """Simulate two DDP ranks discovering nodes via different add_node
    interleavings; their .nodes must be identical so that any code
    iterating ``cache.nodes`` (logs, topology JSON) is rank-independent."""
    c1 = DistributedCache(nodes=["a:9000"])
    for n in ["c:9000", "b:9000", "d:9000"]:
        c1.add_node(n)

    c2 = DistributedCache(nodes=["d:9000"])
    for n in ["a:9000", "b:9000", "c:9000"]:
        c2.add_node(n)

    assert c1.nodes == c2.nodes
    assert c1.nodes == sorted(c1.nodes)
