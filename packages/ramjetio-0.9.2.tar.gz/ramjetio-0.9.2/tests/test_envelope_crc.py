"""Tests for Phase Q.1 — CRC32 envelope wrapper.

The encode path now wraps every value in ``MAGIC_ENVELOPE_V2 + crc32(body)
+ body``. The decode path validates the CRC and rejects mismatches with a
typed ``ValueError``. Legacy payloads (no v2 prefix) are still accepted on
read for backward compatibility with caches written by older SDKs.
"""

import struct
import zlib

import pytest

from ramjetio.cache import (
    MAGIC_BYTES,
    MAGIC_ENVELOPE_V2,
    MAGIC_STR,
    _decode_value,
    _encode_value,
)


class TestEnvelopeV2:
    def test_encode_prepends_v2_envelope(self):
        encoded = _encode_value(b"hello")
        assert encoded[:4] == MAGIC_ENVELOPE_V2
        # next 4 bytes are big-endian crc32 of the inner body
        crc = struct.unpack(">I", encoded[4:8])[0]
        body = encoded[8:]
        assert body[:4] == MAGIC_BYTES
        assert body[4:] == b"hello"
        assert crc == zlib.crc32(body) & 0xFFFFFFFF

    def test_round_trip_bytes(self):
        encoded = _encode_value(b"payload")
        assert _decode_value(encoded) == b"payload"

    def test_round_trip_str(self):
        encoded = _encode_value("hello")
        assert _decode_value(encoded) == "hello"

    def test_round_trip_msgpack_dict(self):
        encoded = _encode_value({"a": 1, "b": [1, 2, 3]})
        assert _decode_value(encoded) == {"a": 1, "b": [1, 2, 3]}

    def test_corrupt_body_rejected(self):
        encoded = bytearray(_encode_value(b"hello"))
        # flip a byte inside the inner body
        encoded[-1] ^= 0xFF
        with pytest.raises(ValueError, match="CRC mismatch"):
            _decode_value(bytes(encoded))

    def test_corrupt_crc_rejected(self):
        encoded = bytearray(_encode_value(b"hello"))
        # flip a byte inside the CRC field itself
        encoded[5] ^= 0xFF
        with pytest.raises(ValueError, match="CRC mismatch"):
            _decode_value(bytes(encoded))

    def test_truncated_v2_envelope(self):
        encoded = _encode_value(b"hello")
        # Truncate so only magic + 3 bytes of CRC remain.
        with pytest.raises(ValueError, match="truncated v2 envelope"):
            _decode_value(encoded[:7])

    def test_legacy_payload_still_decodes(self):
        # Pre-Q.1 wire format: bare MAGIC_BYTES + body, no outer envelope.
        legacy = MAGIC_BYTES + b"legacy"
        assert _decode_value(legacy) == b"legacy"

    def test_legacy_str_payload_still_decodes(self):
        legacy = MAGIC_STR + "old".encode("utf-8")
        assert _decode_value(legacy) == "old"
