"""Test P3.4 Step 8 — singleflight timeout alert log in _get_metrics_for_backend."""
from __future__ import annotations

import logging
import os
import tempfile
from unittest.mock import MagicMock

import pytest

from ramjetio.server import CacheServer


def _make_server(alert_threshold: int = 10) -> CacheServer:
    """Minimal CacheServer with tmp storage. Backend connection is not started."""
    tmp = tempfile.mkdtemp(prefix="ramjet_alert_test_")
    os.environ["RAMJET_SINGLEFLIGHT_ALERT"] = str(alert_threshold)
    try:
        srv = CacheServer(storage_path=tmp, max_capacity=1_000_000)
    finally:
        os.environ.pop("RAMJET_SINGLEFLIGHT_ALERT", None)
    return srv


def test_singleflight_alert_threshold_parsed_from_env():
    srv = _make_server(alert_threshold=5)
    assert srv._singleflight_timeout_alert == 5
    assert srv._prev_wait_timeouts == 0


def test_singleflight_alert_fires_on_burst(caplog):
    srv = _make_server(alert_threshold=3)

    # Simulate 5 wait-timeouts since last heartbeat (> threshold=3).
    srv._inflight_wait_timeouts = 5

    with caplog.at_level(logging.WARNING, logger="ramjetio.server"):
        srv._get_metrics_for_backend()

    assert any(
        "singleflight:" in rec.message and "wait-timeouts" in rec.message
        for rec in caplog.records
    )
    # State is rolled forward so next heartbeat compares against 5.
    assert srv._prev_wait_timeouts == 5


def test_singleflight_alert_silent_below_threshold(caplog):
    srv = _make_server(alert_threshold=10)
    srv._inflight_wait_timeouts = 3

    with caplog.at_level(logging.WARNING, logger="ramjetio.server"):
        srv._get_metrics_for_backend()

    assert not any(
        "singleflight:" in rec.message for rec in caplog.records
    )
    assert srv._prev_wait_timeouts == 3


def test_singleflight_alert_uses_delta_not_absolute(caplog):
    srv = _make_server(alert_threshold=5)
    # First heartbeat: jump by 4, threshold=5 → silent.
    srv._inflight_wait_timeouts = 4
    with caplog.at_level(logging.WARNING, logger="ramjetio.server"):
        srv._get_metrics_for_backend()
    assert not any("singleflight:" in r.message for r in caplog.records)
    caplog.clear()

    # Second heartbeat: another +4 (total 8). Delta is 4, still < 5 → silent
    # even though the running total is now > threshold.
    srv._inflight_wait_timeouts = 8
    with caplog.at_level(logging.WARNING, logger="ramjetio.server"):
        srv._get_metrics_for_backend()
    assert not any("singleflight:" in r.message for r in caplog.records)

    # Third heartbeat: jump by 6 → fires.
    srv._inflight_wait_timeouts = 14
    with caplog.at_level(logging.WARNING, logger="ramjetio.server"):
        srv._get_metrics_for_backend()
    assert any("singleflight:" in r.message for r in caplog.records)
