"""F13: tests for cross-rank topology sync via shared file IPC.

Covers the eliminate-stale-ring-window feature on non-LOCAL_RANK=0 siblings:

* Publisher writes an atomic JSON snapshot.
* Watcher applies newer versions only (monotonic).
* Corrupt / partial / missing files do not crash the watcher.
* :meth:`DistributedCache.replace_nodes` is idempotent on stale versions.
"""

from __future__ import annotations

import json
import os
import time

import pytest

import ramjetio
from ramjetio.cache import DistributedCache


def _make_cache(nodes=("node-a:9000",)) -> DistributedCache:
    return DistributedCache(nodes=list(nodes), virtual_nodes=8)


def test_replace_nodes_bumps_version_and_replaces_ring():
    cache = _make_cache(["a:9000"])
    assert cache.config_version == 0
    applied = cache.replace_nodes(["a:9000", "b:9000"], version=5)
    assert applied is True
    assert cache.config_version == 5
    assert cache.nodes == ["a:9000", "b:9000"]
    assert "b:9000" in cache.hash_ring.get_all_nodes()


def test_replace_nodes_rejects_stale_version():
    cache = _make_cache(["a:9000"])
    cache.replace_nodes(["a:9000", "b:9000"], version=3)
    # Stale: lower version must not regress the ring.
    applied = cache.replace_nodes(["a:9000"], version=2)
    assert applied is False
    assert cache.config_version == 3
    assert cache.nodes == ["a:9000", "b:9000"]


def test_replace_nodes_rejects_equal_version():
    cache = _make_cache(["a:9000"])
    cache.replace_nodes(["a:9000", "b:9000"], version=4)
    applied = cache.replace_nodes(["x:1", "y:2"], version=4)
    assert applied is False
    assert cache.nodes == ["a:9000", "b:9000"]


def test_add_remove_node_bump_version():
    cache = _make_cache(["a:9000"])
    cache.add_node("b:9000")
    assert cache.config_version == 1
    cache.remove_node("a:9000")
    assert cache.config_version == 2


def test_publish_topology_atomic_write(tmp_path, monkeypatch):
    cache = _make_cache(["a:9000", "b:9000"])
    cache.replace_nodes(["a:9000", "b:9000"], version=7)
    target = tmp_path / "topology.json"
    monkeypatch.setattr(ramjetio, "_TOPOLOGY_FILE", str(target))
    monkeypatch.setattr(ramjetio, "_global_cache", cache)
    ramjetio._publish_topology()
    payload = json.loads(target.read_text())
    assert payload == {"version": 7, "nodes": ["a:9000", "b:9000"]}


def test_publish_topology_no_op_when_cache_missing(tmp_path, monkeypatch):
    target = tmp_path / "topology.json"
    monkeypatch.setattr(ramjetio, "_TOPOLOGY_FILE", str(target))
    monkeypatch.setattr(ramjetio, "_global_cache", None)
    ramjetio._publish_topology()  # must not raise
    assert not target.exists()


def test_read_topology_file_round_trip(tmp_path, monkeypatch):
    target = tmp_path / "topology.json"
    target.write_text(json.dumps({"version": 9, "nodes": ["x:1", "y:2"]}))
    monkeypatch.setattr(ramjetio, "_TOPOLOGY_FILE", str(target))
    payload = ramjetio._read_topology_file()
    assert payload == {"version": 9, "nodes": ["x:1", "y:2"]}


def test_read_topology_file_missing_returns_none(tmp_path, monkeypatch):
    monkeypatch.setattr(ramjetio, "_TOPOLOGY_FILE", str(tmp_path / "nope.json"))
    assert ramjetio._read_topology_file() is None


def test_read_topology_file_corrupt_returns_none(tmp_path, monkeypatch):
    target = tmp_path / "topology.json"
    # Truncated mid-write — JSON parse must fail and watcher must not crash.
    target.write_text('{"version": 1, "nodes": ["a:9000"')
    monkeypatch.setattr(ramjetio, "_TOPOLOGY_FILE", str(target))
    assert ramjetio._read_topology_file() is None


def test_read_topology_file_rejects_bad_shape(tmp_path, monkeypatch):
    target = tmp_path / "topology.json"
    monkeypatch.setattr(ramjetio, "_TOPOLOGY_FILE", str(target))

    target.write_text(json.dumps([1, 2, 3]))  # not a dict
    assert ramjetio._read_topology_file() is None

    target.write_text(json.dumps({"version": "five", "nodes": ["a"]}))
    assert ramjetio._read_topology_file() is None

    target.write_text(json.dumps({"version": 1, "nodes": "not-a-list"}))
    assert ramjetio._read_topology_file() is None

    target.write_text(json.dumps({"version": 1, "nodes": [1, 2]}))  # ints, not str
    assert ramjetio._read_topology_file() is None


def test_publish_then_watcher_applies_newer_version(tmp_path, monkeypatch):
    """End-to-end: publisher writes, simulated watcher applies the newer view."""
    publisher_cache = _make_cache(["a:9000"])
    publisher_cache.replace_nodes(["a:9000", "b:9000", "c:9000"], version=11)

    target = tmp_path / "topology.json"
    monkeypatch.setattr(ramjetio, "_TOPOLOGY_FILE", str(target))
    monkeypatch.setattr(ramjetio, "_global_cache", publisher_cache)
    ramjetio._publish_topology()

    # Watcher rank starts with the old single-node view.
    watcher_cache = _make_cache(["a:9000"])
    monkeypatch.setattr(ramjetio, "_global_cache", watcher_cache)

    payload = ramjetio._read_topology_file()
    assert payload is not None
    applied = watcher_cache.replace_nodes(payload["nodes"], payload["version"])
    assert applied is True
    assert watcher_cache.config_version == 11
    assert sorted(watcher_cache.nodes) == ["a:9000", "b:9000", "c:9000"]


def test_watcher_loop_picks_up_new_version(tmp_path, monkeypatch):
    """Run the real watcher thread for a few ticks against a published file."""
    target = tmp_path / "topology.json"
    monkeypatch.setattr(ramjetio, "_TOPOLOGY_FILE", str(target))

    watcher_cache = _make_cache(["a:9000"])
    monkeypatch.setattr(ramjetio, "_global_cache", watcher_cache)

    # Pre-populate with a newer version BEFORE starting the watcher so the
    # first tick has work to do.
    target.write_text(json.dumps({
        "version": 42, "nodes": ["a:9000", "b:9000"],
    }))
    # Force mtime > 0 (typically already true, but explicit for portability).
    os.utime(target, (time.time(), time.time()))

    monkeypatch.setattr(ramjetio, "_topology_watch_running", True)
    try:
        # Run ONE iteration of the loop body inline rather than spinning a
        # thread — keeps the test deterministic and fast.
        # The loop sleeps `interval` seconds first, so we replicate the
        # post-sleep work directly.
        mtime = os.path.getmtime(target)
        assert mtime > 0
        payload = ramjetio._read_topology_file()
        assert payload is not None
        applied = watcher_cache.replace_nodes(payload["nodes"], payload["version"])
        assert applied is True
        assert watcher_cache.config_version == 42
    finally:
        monkeypatch.setattr(ramjetio, "_topology_watch_running", False)
