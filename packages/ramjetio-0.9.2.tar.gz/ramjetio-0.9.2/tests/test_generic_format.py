"""Smoke tests for UniversalDataset(format='generic') (Phase F6).

The generic format lets the SDK serve arbitrary file types (mp4, parquet,
.npy, .pt, audio, ...) as opaque bytes, so frameworks that already know how
to decode their own files can still benefit from the peer cache. These
tests verify:

  - scan_files lists every file under {split}/ in deterministic order
  - __getitem__ returns {'key': str, 'data': bytes}
  - cache hit short-circuits the client fetch
  - cache miss falls back to client and primes the cache
  - suffix filter restricts the scan
"""
from __future__ import annotations

from typing import Dict, List, Tuple

import pytest

from ramjetio.datasets import UniversalDataset


class FakeClient:
    """list_files / get_bytes stand-in backed by a dict."""

    def __init__(self, files: Dict[str, bytes]):
        self.files = files
        self.bytes_calls: List[str] = []

    def list_files(self, prefix: str = "", suffix: str = "") -> List[str]:
        out = []
        for p in self.files:
            if not p.startswith(prefix):
                continue
            if suffix and not p.endswith(suffix):
                continue
            out.append(p)
        return out

    def get_bytes(self, key: str) -> bytes:
        self.bytes_calls.append(key)
        return self.files[key]


class FakeCache:
    """Minimal cache: dict + miss/hit counters."""

    def __init__(self):
        self.store: Dict[str, bytes] = {}
        self.gets = 0
        self.sets = 0

    def get(self, key):
        self.gets += 1
        return self.store.get(key)

    def set(self, key, value):
        self.sets += 1
        self.store[key] = value


def _make_dataset(files: Dict[str, bytes], suffix: str = "", cache=None) -> Tuple[UniversalDataset, FakeClient]:
    client = FakeClient(files)
    ds = UniversalDataset.__new__(UniversalDataset)
    ds.split = "train"
    ds.img_size = 0
    ds.transform = None
    ds.format = "generic"
    ds.suffix = suffix
    ds._client = client
    ds._cache = cache
    ds._format_handler = None
    ds.samples = []
    # Run the same scan path the real __init__ does.
    ds._scan_files()
    return ds, client


def test_generic_scan_lists_split_files_sorted():
    files = {
        "train/b.mp4": b"BBBB",
        "train/a.mp4": b"AAAA",
        "train/sub/c.mp4": b"CCCC",
        "valid/x.mp4": b"XXXX",  # other split, must be ignored
    }
    ds, _ = _make_dataset(files)
    assert ds.samples == ["train/a.mp4", "train/b.mp4", "train/sub/c.mp4"]


def test_generic_suffix_filter():
    files = {
        "train/clip.mp4": b"video",
        "train/notes.txt": b"text",
        "train/blob.npy": b"array",
    }
    ds, _ = _make_dataset(files, suffix=".mp4")
    assert ds.samples == ["train/clip.mp4"]


def test_generic_getitem_returns_key_and_bytes():
    files = {"train/a.bin": b"hello"}
    ds, client = _make_dataset(files)
    item = ds[0]
    assert item == {"key": "train/a.bin", "data": b"hello"}
    assert client.bytes_calls == ["train/a.bin"]


def test_generic_cache_miss_then_hit():
    files = {"train/a.bin": b"payload"}
    cache = FakeCache()
    ds, client = _make_dataset(files, cache=cache)

    # First read → cache miss → client fetched → cache primed
    item1 = ds[0]
    assert item1["data"] == b"payload"
    assert client.bytes_calls == ["train/a.bin"]
    assert cache.store == {"generic:train/a.bin": b"payload"}

    # Second read → cache hit → no extra client fetch
    item2 = ds[0]
    assert item2["data"] == b"payload"
    assert client.bytes_calls == ["train/a.bin"], (
        "cache hit must short-circuit get_bytes"
    )


def test_generic_rejects_client_without_list_files():
    """HTTPClient has no list_files() — generic must reject it cleanly."""

    class HttpLikeClient:
        def get_bytes(self, key):
            return b""

    ds = UniversalDataset.__new__(UniversalDataset)
    ds.split = "train"
    ds.img_size = 0
    ds.transform = None
    ds.format = "generic"
    ds.suffix = ""
    ds._client = HttpLikeClient()
    ds._cache = None
    ds._format_handler = None
    ds.samples = []

    with pytest.raises(ValueError, match="list_files"):
        ds._scan_files()


def test_generic_unknown_format_rejected():
    """Smoke check that the registry still rejects gibberish formats after
    the generic addition."""
    client = FakeClient({"train/a.bin": b"x"})
    ds = UniversalDataset.__new__(UniversalDataset)
    ds.split = "train"
    ds.img_size = 0
    ds.transform = None
    ds.format = "definitely-not-a-format"
    ds.suffix = ""
    ds._client = client
    ds._cache = None
    ds._format_handler = None
    ds.samples = []

    with pytest.raises(ValueError, match="Unknown format"):
        ds._scan_files()
