"""Phase 5.1 fix: ensure no spurious RegisterNode RPCs from the periodic
node-refresh loop. The bug was that ``_node_refresh_loop`` invoked the
module-level ``get_cluster_nodes()`` helper which spun up a fresh
``BackendClient`` on every tick, triggering a RegisterNode RPC. The fix
reuses the already-connected long-lived client's stub and makes the
instance ``get_cluster_nodes`` refuse to silently auto-connect.
"""
from __future__ import annotations

from unittest.mock import MagicMock

import ramjetio
from ramjetio.backend_client import BackendClient


def _make_connected_client_with_stub() -> BackendClient:
    """Build a BackendClient that *looks* connected without making any RPC.

    Mocks both the gRPC stub and the proto module so calls to RegisterNode
    or GetClusterNodes can be observed.
    """
    client = BackendClient(node_port=9000, api_key="test_secretsecret")
    client.node_id = "node-uuid"
    client.cluster_id = "cluster-uuid"
    client._connected = True

    # Mock proto module
    pb2 = MagicMock()
    request_cls = MagicMock(return_value=MagicMock())
    pb2.GetClusterNodesRequest = request_cls
    pb2.RegisterNodeRequest = MagicMock(return_value=MagicMock())
    client._pb2 = pb2

    # Mock stub: GetClusterNodes returns one fake node, RegisterNode is observed.
    fake_node = MagicMock(
        id="fake-id",
        hostname="172.18.0.3",
        port=9000,
        status=2,  # ONLINE
    )
    response = MagicMock(nodes=[fake_node])
    stub = MagicMock()
    stub.GetClusterNodes = MagicMock(return_value=response)
    stub.RegisterNode = MagicMock()
    client._stub = stub
    return client


def test_instance_get_cluster_nodes_does_not_register_when_unconnected():
    """An unconnected BackendClient must NOT attempt to register from
    ``get_cluster_nodes``; it returns an empty list and the caller decides.
    """
    client = BackendClient(node_port=9000, api_key="test_secretsecret")
    # Deliberately leave _stub / _pb2 as None (unconnected).

    nodes = client.get_cluster_nodes(online_only=True)

    assert nodes == []
    # The client should have made zero RPCs (nothing to call against).
    # If a regression silently calls connect(), _stub would become non-None.
    assert client._stub is None


def test_instance_get_cluster_nodes_uses_existing_stub():
    """When connected, ``get_cluster_nodes`` should call GetClusterNodes
    and NOT attempt to register.
    """
    client = _make_connected_client_with_stub()

    nodes = client.get_cluster_nodes(online_only=True)

    assert client._stub.GetClusterNodes.call_count == 1
    assert client._stub.RegisterNode.call_count == 0
    assert len(nodes) == 1
    assert nodes[0]["hostname"] == "172.18.0.3"


def test_discover_nodes_reuses_global_client_no_register(monkeypatch):
    """The hot path that fires every 10s from ``_node_refresh_loop`` must
    not trigger any RegisterNode RPCs. Previously this called the
    module-level ``get_cluster_nodes`` helper which built a fresh client
    and connected (= registered) on each tick.
    """
    client = _make_connected_client_with_stub()
    monkeypatch.setattr(ramjetio, "_backend_client", client)

    nodes = ramjetio._discover_nodes()

    assert nodes == ["172.18.0.3:9000"]
    assert client._stub.RegisterNode.call_count == 0
    assert client._stub.GetClusterNodes.call_count == 1
