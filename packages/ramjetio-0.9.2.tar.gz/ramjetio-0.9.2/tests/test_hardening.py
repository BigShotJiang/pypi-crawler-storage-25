"""Tests for P1 v0.7 hardening: F1 (ring determinism), F3 (peer auth),
F12 (no-pickle envelope).

These tests are deliberately self-contained — they do not require a running
cache server or backend. The auth + envelope server behaviour is exercised
via aiohttp's in-process test client.
"""

from __future__ import annotations

import os
import pickle
import random

import pytest
import torch

from ramjetio import cache as cache_mod
from ramjetio.cache import (
    AUTH_HEADER,
    DistributedCache,
    MAGIC_BYTES,
    MAGIC_ENVELOPE_V2,
    MAGIC_MSGPACK,
    MAGIC_STR,
    MAGIC_TENSOR,
    _decode_value,
    _encode_value,
)
from ramjetio.consistent_hash import ConsistentHash


# --------------------------------------------------------------------------- #
# F1 — Ring determinism
# --------------------------------------------------------------------------- #


def test_consistent_hash_ring_is_permutation_invariant():
    """Any permutation of the same node set must produce identical ownership
    for every key. This is the core invariant F1 protects.
    """
    nodes = [f"h{i}:9000" for i in range(5)]
    keys = [f"sample_{i}" for i in range(10_000)]

    base_ring = ConsistentHash(nodes=sorted(nodes))
    base_owners = [base_ring.get_node(k) for k in keys]

    rng = random.Random(0xC0FFEE)
    for _ in range(10):
        shuffled = nodes.copy()
        rng.shuffle(shuffled)
        ring = ConsistentHash(nodes=sorted(shuffled))
        assert [ring.get_node(k) for k in keys] == base_owners


def test_discover_nodes_sorts_env_fallback(monkeypatch):
    """F1: _discover_nodes must emit a sorted list even from RAMJET_NODES env."""
    import ramjetio

    # Ensure backend path is skipped
    monkeypatch.setattr(ramjetio, "_backend_client", None, raising=False)
    monkeypatch.setenv(
        "RAMJET_NODES",
        "zeta:9000,alpha:9000,mike:9000",
    )
    result = ramjetio._discover_nodes()
    assert result == ["alpha:9000", "mike:9000", "zeta:9000"]


# --------------------------------------------------------------------------- #
# F12 — Envelope codec
# --------------------------------------------------------------------------- #


def test_envelope_roundtrip_tensor():
    t = torch.arange(12, dtype=torch.float32).reshape(3, 4)
    blob = _encode_value(t)
    # Phase Q.1: outer v2 envelope (RJV2 + crc32) wraps the inner magic.
    assert blob[:4] == MAGIC_ENVELOPE_V2
    assert blob[8:12] == MAGIC_TENSOR
    out = _decode_value(blob)
    assert torch.equal(out, t)


def test_envelope_roundtrip_bytes():
    payload = os.urandom(256)
    blob = _encode_value(payload)
    assert blob[:4] == MAGIC_ENVELOPE_V2
    assert blob[8:12] == MAGIC_BYTES
    assert _decode_value(blob) == payload


def test_envelope_roundtrip_str():
    blob = _encode_value("привет")
    assert blob[:4] == MAGIC_ENVELOPE_V2
    assert blob[8:12] == MAGIC_STR
    assert _decode_value(blob) == "привет"


def test_envelope_rejects_unsupported_type():
    """Unsafe types (custom classes, callables) must still be rejected so we
    never fall back to pickle. dict/list/tuple/ndarray are supported via
    MAGIC_MSGPACK and covered by their own roundtrip tests below.
    """
    class _Custom:
        pass

    with pytest.raises(TypeError):
        _encode_value(_Custom())
    with pytest.raises(TypeError):
        _encode_value(lambda x: x)
    with pytest.raises(TypeError):
        _encode_value({1, 2, 3})  # set


def test_envelope_roundtrip_dict():
    payload = {"name": "yolo", "count": 42, "ratios": [0.1, 0.2, 0.3]}
    blob = _encode_value(payload)
    assert blob[:4] == MAGIC_ENVELOPE_V2
    assert blob[8:12] == MAGIC_MSGPACK
    assert _decode_value(blob) == payload


def test_envelope_roundtrip_list():
    payload = [1, 2.5, "x", b"raw", True, None]
    blob = _encode_value(payload)
    assert blob[:4] == MAGIC_ENVELOPE_V2
    assert blob[8:12] == MAGIC_MSGPACK
    assert _decode_value(blob) == payload


def test_envelope_roundtrip_tuple_preserves_type():
    payload = (1, "a", (2, 3))
    blob = _encode_value(payload)
    assert blob[:4] == MAGIC_ENVELOPE_V2
    assert blob[8:12] == MAGIC_MSGPACK
    decoded = _decode_value(blob)
    assert decoded == payload
    assert isinstance(decoded, tuple)
    assert isinstance(decoded[2], tuple)


def test_envelope_roundtrip_ndarray():
    np = pytest.importorskip("numpy")
    payload = np.arange(12, dtype=np.float32).reshape(3, 4)
    blob = _encode_value(payload)
    assert blob[:4] == MAGIC_ENVELOPE_V2
    assert blob[8:12] == MAGIC_MSGPACK
    decoded = _decode_value(blob)
    assert isinstance(decoded, np.ndarray)
    assert decoded.dtype == payload.dtype
    assert decoded.shape == payload.shape
    assert np.array_equal(decoded, payload)


def test_envelope_rejects_object_dtype_ndarray():
    """ndarray with dtype=object would force pickle on decode — must be
    rejected at encode time."""
    np = pytest.importorskip("numpy")
    arr = np.array([{"x": 1}, {"y": 2}], dtype=object)
    with pytest.raises(TypeError):
        _encode_value(arr)


def test_envelope_rejects_unsafe_nested_value():
    """A dict containing an unsafe leaf (e.g. set, custom class) must be
    rejected before we touch msgpack."""
    class _Custom:
        pass

    with pytest.raises(TypeError):
        _encode_value({"k": _Custom()})
    with pytest.raises(TypeError):
        _encode_value({"k": {1, 2}})


def test_decode_rejects_unknown_msgpack_ext_code():
    """Forged msgpack payload with unknown ext code must be rejected, not
    silently passed through as data."""
    import msgpack
    forged = MAGIC_MSGPACK + msgpack.packb(
        msgpack.ExtType(99, b"evil"), use_bin_type=True,
    )
    with pytest.raises(ValueError):
        _decode_value(forged)


def test_decode_rejects_bare_pickle():
    """G14 regression: a reader must not evaluate unmarked pickle bytes."""
    evil = pickle.dumps({"anything": 1})
    with pytest.raises(ValueError):
        _decode_value(evil)


def test_decode_rejects_empty_and_short():
    with pytest.raises(ValueError):
        _decode_value(b"")
    with pytest.raises(ValueError):
        _decode_value(b"RJB")  # 3 bytes, truncated


def test_decode_rejects_unknown_magic():
    with pytest.raises(ValueError):
        _decode_value(b"XXXX" + b"payload")


# --------------------------------------------------------------------------- #
# F3 + F12 — Server middleware + /set payload gate
# --------------------------------------------------------------------------- #


@pytest.fixture
async def auth_server(tmp_path, monkeypatch):
    """Spin up a CacheServer app in-process with a known API key."""
    from aiohttp.test_utils import TestClient, TestServer

    monkeypatch.setenv("RAMJET_API_KEY", "test-key-abc123")
    from ramjetio.server import CacheServer

    server = CacheServer(
        host="127.0.0.1",
        port=0,
        storage_path=str(tmp_path / "cache"),
        max_capacity=10 * 1024 * 1024,
    )
    app = server.create_app()
    async with TestClient(TestServer(app)) as client:
        yield client, server
    server.close()


@pytest.mark.asyncio
async def test_peer_request_without_key_is_401(auth_server):
    client, _ = auth_server
    resp = await client.get("/get", params={"key": "x"})
    assert resp.status == 401


@pytest.mark.asyncio
async def test_peer_request_with_wrong_key_is_401(auth_server):
    client, _ = auth_server
    resp = await client.get(
        "/get",
        params={"key": "x"},
        headers={AUTH_HEADER: "nope"},
    )
    assert resp.status == 401


@pytest.mark.asyncio
async def test_health_is_open(auth_server):
    client, _ = auth_server
    resp = await client.get("/health")
    assert resp.status == 200


@pytest.mark.asyncio
async def test_set_rejects_raw_pickle_payload(auth_server):
    """F12 server-side gate: an attacker-crafted pickle blob must be refused
    at /set even if the attacker stole a valid API key.
    """
    client, _ = auth_server
    evil = pickle.dumps({"rce": True})
    resp = await client.post(
        "/set",
        params={"key": "evil"},
        data=evil,
        headers={AUTH_HEADER: "test-key-abc123"},
    )
    assert resp.status == 400


@pytest.mark.asyncio
async def test_set_accepts_envelope_payload(auth_server):
    client, _ = auth_server
    data = MAGIC_BYTES + b"hello"
    resp = await client.post(
        "/set",
        params={"key": "k1"},
        data=data,
        headers={AUTH_HEADER: "test-key-abc123"},
    )
    assert resp.status == 200

    got = await client.get(
        "/get",
        params={"key": "k1"},
        headers={AUTH_HEADER: "test-key-abc123"},
    )
    assert got.status == 200
    body = await got.read()
    assert body == data


# --------------------------------------------------------------------------- #
# F9 — Key namespacing
# --------------------------------------------------------------------------- #


def test_namespace_isolates_routing():
    """Two caches with the same nodes but different namespaces must generate
    different wire keys, so the same user-key never collides across tenants.
    """
    from unittest.mock import Mock
    import os as _os

    nodes = ["a:9000", "b:9000", "c:9000"]

    def _capture(cache: DistributedCache):
        cache._session = Mock()
        cache._session_pid = _os.getpid()
        resp = Mock()
        resp.status_code = 200
        cache._session.post.return_value = resp
        cache.set("k", b"v")
        # The wire key is passed as params["key"] to session.post
        return cache._session.post.call_args.kwargs["params"]["key"]

    a = DistributedCache(nodes=nodes, key_namespace="cluster:A")
    b = DistributedCache(nodes=nodes, key_namespace="cluster:B")
    c = DistributedCache(nodes=nodes)  # no namespace

    ka = _capture(a)
    kb = _capture(b)
    kc = _capture(c)

    assert ka == "cluster:A|k"
    assert kb == "cluster:B|k"
    assert kc == "k"
    assert ka != kb


def test_set_key_namespace_updates_prefix():
    cache = DistributedCache(nodes=["a:9000"])
    assert cache.key_namespace is None
    assert cache._ns("k") == "k"
    cache.set_key_namespace("tenant:42")
    assert cache._ns("k") == "tenant:42|k"
    cache.set_key_namespace(None)
    assert cache._ns("k") == "k"


def test_namespace_rehashes_to_possibly_different_owner():
    """The namespace participates in ring routing: the same user-key under
    two namespaces must in general land on different owners for at least
    some keys (statistical sanity check — not a strict per-key guarantee).
    """
    nodes = [f"h{i}:9000" for i in range(4)]
    plain = DistributedCache(nodes=nodes)
    tenant = DistributedCache(nodes=nodes, key_namespace="tenant:X")

    diffs = 0
    for i in range(200):
        k = f"sample_{i}"
        p = plain.hash_ring.get_node(plain._ns(k))
        t = tenant.hash_ring.get_node(tenant._ns(k))
        if p != t:
            diffs += 1
    # Expect roughly (N-1)/N = 0.75 of keys to land on a different node.
    assert diffs > 50, f"namespace had no routing effect (diffs={diffs}/200)"


# --------------------------------------------------------------------------- #
# F2 — agree_on_nodes
# --------------------------------------------------------------------------- #


def test_agree_on_nodes_no_ddp_is_noop(monkeypatch):
    """Without torch.distributed initialised, agree_on_nodes returns the
    current node list unchanged and does not raise.
    """
    import ramjetio

    # Build a throwaway cache and install it as the global.
    cache = DistributedCache(nodes=sorted(["z:9000", "a:9000", "m:9000"]))
    monkeypatch.setattr(ramjetio, "_global_cache", cache, raising=False)

    result = ramjetio.agree_on_nodes()
    assert result == cache.nodes


def test_agree_on_nodes_rebuilds_ring_from_broadcast(monkeypatch):
    """Simulate DDP: rank 1 starts with a stale 1-node view and must adopt
    rank 0's 3-node view after the broadcast.
    """
    import ramjetio
    import torch.distributed as dist

    # Pretend to be rank 1 with only 1 node discovered (the bug we are fixing).
    cache = DistributedCache(nodes=["only-me:9000"])
    monkeypatch.setattr(ramjetio, "_global_cache", cache, raising=False)

    agreed = ["a:9000", "b:9000", "c:9000"]

    def _fake_broadcast(payload, src=0):
        payload[0] = agreed

    monkeypatch.setattr(dist, "is_available", lambda: True)
    monkeypatch.setattr(dist, "is_initialized", lambda: True)
    monkeypatch.setattr(dist, "get_world_size", lambda: 2)
    monkeypatch.setattr(dist, "get_rank", lambda: 1)
    monkeypatch.setattr(dist, "broadcast_object_list", _fake_broadcast)

    result = ramjetio.agree_on_nodes()
    assert result == agreed
    assert cache.nodes == agreed
    assert cache._node_count == 3
    # Ring was rebuilt — pick any key, owner must be one of the agreed nodes.
    owner = cache.hash_ring.get_node("some-key")
    assert owner in agreed


# --------------------------------------------------------------------------- #
# F4 — Hash ring freeze/snapshot
# --------------------------------------------------------------------------- #


def test_ring_snapshot_isolates_from_live_changes():
    """While a snapshot is active, mutating the live ring must not change
    routing decisions for set/get/delete/exists."""
    from unittest.mock import Mock
    import os as _os

    nodes = ["a:9000", "b:9000", "c:9000"]
    cache = DistributedCache(nodes=list(nodes))

    # Capture the wire-key that set() routes to.
    cache._session = Mock()
    cache._session_pid = _os.getpid()
    resp = Mock()
    resp.status_code = 200
    cache._session.post.return_value = resp

    # Record pre-snapshot node for a given key.
    key = "hotkey"
    pre_owner = cache.hash_ring.get_node(key)

    # Freeze the ring, then add/remove nodes on the live ring.
    cache.set_ring_snapshot(cache.snapshot_ring())
    cache.add_node("d:9000")
    cache.add_node("e:9000")
    cache.remove_node("a:9000")

    # Live ring has changed; the frozen snapshot must NOT have.
    frozen_owner = cache._frozen_ring.get_node(key)
    live_owner = cache.hash_ring.get_node(key)
    assert frozen_owner == pre_owner
    # Routing via set() must use the frozen snapshot.
    cache.set(key, b"v")
    call_url = cache._session.post.call_args.args[0]
    assert frozen_owner in call_url
    # The live ring may (and probably does) give a different owner after
    # add/remove — ensure our assertion above actually exercised the
    # freeze path rather than silently passing on a coincidence.
    # (This is a statistical check; with 3→4 nodes added, routing for
    # *some* keys differs. If both match we still accept.)
    _ = live_owner


def test_clear_ring_snapshot_restores_live_routing():
    cache = DistributedCache(nodes=["a:9000", "b:9000"])
    cache.set_ring_snapshot(cache.snapshot_ring())
    assert cache._frozen_ring is not None
    assert cache._active_ring() is cache._frozen_ring

    cache.clear_ring_snapshot()
    assert cache._frozen_ring is None
    assert cache._active_ring() is cache.hash_ring


def test_freeze_unfreeze_ring_module_helpers(monkeypatch):
    """Public ramjetio.freeze_ring / unfreeze_ring wire through _global_cache
    and are no-ops when the cache is not initialised."""
    import ramjetio

    # No cache yet → freeze returns False, unfreeze is a silent no-op.
    monkeypatch.setattr(ramjetio, "_global_cache", None, raising=False)
    assert ramjetio.freeze_ring() is False
    ramjetio.unfreeze_ring()  # must not raise

    cache = DistributedCache(nodes=["x:9000", "y:9000"])
    monkeypatch.setattr(ramjetio, "_global_cache", cache, raising=False)

    assert cache._frozen_ring is None
    assert ramjetio.freeze_ring() is True
    assert cache._frozen_ring is not None
    ramjetio.unfreeze_ring()
    assert cache._frozen_ring is None


# --------------------------------------------------------------------------- #
# F5 — Cache hit source attribution (local vs peer)
# --------------------------------------------------------------------------- #


def _mock_get_response(payload: bytes):
    """Build a Mock HTTP response carrying `payload` (already envelope-encoded)."""
    from unittest.mock import Mock
    resp = Mock()
    resp.status_code = 200
    resp.content = payload
    return resp


def test_get_with_source_classifies_local_hit():
    """When the owning node matches local_node, source must be 'local'."""
    from unittest.mock import Mock
    import os as _os

    nodes = ["a:9000", "b:9000", "c:9000"]
    cache = DistributedCache(nodes=list(nodes), local_node="a:9000")

    # Pick a key we know routes to 'a:9000' by asking the ring directly.
    owner = None
    for i in range(1000):
        k = f"k{i}"
        if cache.hash_ring.get_node(k) == "a:9000":
            owner = k
            break
    assert owner is not None

    cache._session = Mock()
    cache._session_pid = _os.getpid()
    cache._session.get.return_value = _mock_get_response(_encode_value(b"payload"))

    value, source = cache.get_with_source(owner)
    assert value == b"payload"
    assert source == "local"


def test_get_with_source_classifies_peer_hit():
    """When the owning node differs from local_node, source must be 'peer'."""
    from unittest.mock import Mock
    import os as _os

    nodes = ["a:9000", "b:9000", "c:9000"]
    cache = DistributedCache(nodes=list(nodes), local_node="z:9000")  # not in ring

    cache._session = Mock()
    cache._session_pid = _os.getpid()
    cache._session.get.return_value = _mock_get_response(_encode_value(b"payload"))

    value, source = cache.get_with_source("some-key")
    assert value == b"payload"
    assert source == "peer"


def test_get_with_source_returns_none_on_miss():
    """404 on all replicas → (None, None), no spurious classification."""
    from unittest.mock import Mock
    import os as _os

    cache = DistributedCache(nodes=["a:9000"], local_node="a:9000")
    cache._session = Mock()
    cache._session_pid = _os.getpid()

    miss = Mock()
    miss.status_code = 404
    miss.content = b""
    cache._session.get.return_value = miss

    value, source = cache.get_with_source("missing")
    assert value is None
    assert source is None


def test_set_local_node_updates_classification():
    """set_local_node() re-tags subsequent hits."""
    cache = DistributedCache(nodes=["a:9000", "b:9000"])
    assert cache.local_node is None
    assert cache._classify_source("a:9000") == "peer"

    cache.set_local_node("a:9000")
    assert cache.local_node == "a:9000"
    assert cache._classify_source("a:9000") == "local"
    assert cache._classify_source("b:9000") == "peer"

    cache.set_local_node(None)
    assert cache.local_node is None
    assert cache._classify_source("a:9000") == "peer"


# --------------------------------------------------------------------------- #
# F6 — Server-side single-flight coalescing on cold-miss GET
# --------------------------------------------------------------------------- #


def _make_server(tmp_path_str):
    """Build an unstarted CacheServer with a temp storage dir."""
    from ramjetio.server import CacheServer
    return CacheServer(
        host="127.0.0.1",
        port=0,
        storage_path=tmp_path_str,
        max_capacity=10 * 1024 * 1024,
    )


def test_singleflight_first_caller_becomes_leader(tmp_path):
    """First _singleflight_claim for a key returns None (leader signal)."""
    import asyncio

    server = _make_server(str(tmp_path / "sf1"))

    async def scenario():
        claim = await server._singleflight_claim("k")
        return claim

    result = asyncio.run(scenario())
    assert result is None
    assert "k" in server._inflight
    assert server._inflight_leader_count == 1
    assert server._inflight_waiter_count == 0
    server.close()


def test_singleflight_second_caller_waits_and_wakes_on_release(tmp_path):
    """A waiter's Event is set by _singleflight_release."""
    import asyncio

    server = _make_server(str(tmp_path / "sf2"))

    async def scenario():
        leader_claim = await server._singleflight_claim("k")
        assert leader_claim is None
        waiter_claim = await server._singleflight_claim("k")
        assert waiter_claim is not None
        assert not waiter_claim.is_set()

        async def release_soon():
            await asyncio.sleep(0.02)
            await server._singleflight_release("k")

        release_task = asyncio.create_task(release_soon())
        await asyncio.wait_for(waiter_claim.wait(), timeout=1.0)
        await release_task
        return waiter_claim.is_set(), "k" in server._inflight

    is_set, still_pending = asyncio.run(scenario())
    assert is_set is True
    assert still_pending is False
    assert server._inflight_waiter_count == 1
    server.close()


def test_singleflight_release_noop_when_no_entry(tmp_path):
    """_singleflight_release must not raise when the key has no inflight entry."""
    import asyncio

    server = _make_server(str(tmp_path / "sf3"))

    async def scenario():
        await server._singleflight_release("ghost")  # lock is None → noop
        await server._singleflight_claim("k")
        await server._singleflight_release("k")
        await server._singleflight_release("k")  # second release is noop

    asyncio.run(scenario())  # must not raise
    server.close()


def test_singleflight_disabled_via_env(tmp_path, monkeypatch):
    """RAMJET_SINGLEFLIGHT=0 disables coalescing at construction."""
    monkeypatch.setenv("RAMJET_SINGLEFLIGHT", "0")
    server = _make_server(str(tmp_path / "sf4"))
    assert server._singleflight_enabled is False
    server.close()


def test_singleflight_timeout_env_parsed(tmp_path, monkeypatch):
    """RAMJET_SINGLEFLIGHT_TIMEOUT_MS overrides the default 30s."""
    monkeypatch.setenv("RAMJET_SINGLEFLIGHT_TIMEOUT_MS", "1500")
    server = _make_server(str(tmp_path / "sf5"))
    assert abs(server._inflight_timeout - 1.5) < 1e-6
    server.close()


def test_singleflight_waiter_times_out_and_is_counted(tmp_path, monkeypatch):
    """When the leader never releases, waiters time out."""
    import asyncio

    monkeypatch.setenv("RAMJET_SINGLEFLIGHT_TIMEOUT_MS", "50")
    server = _make_server(str(tmp_path / "sf6"))

    async def scenario():
        assert await server._singleflight_claim("k") is None
        waiter = await server._singleflight_claim("k")
        assert waiter is not None
        try:
            await asyncio.wait_for(waiter.wait(), timeout=server._inflight_timeout)
            return False
        except asyncio.TimeoutError:
            server._inflight_wait_timeouts += 1
            return True

    timed_out = asyncio.run(scenario())
    assert timed_out is True
    assert server._inflight_wait_timeouts == 1
    server.close()


# --------------------------------------------------------------------------- #
# F8 — Per-rank labels + path-split counters on NodeMetrics
# --------------------------------------------------------------------------- #


def test_record_cache_path_accumulates_by_label():
    """F8: _record_cache_path maps source tags to the three split counters;
    'failed' and unknown labels are silently ignored."""
    import ramjetio

    # Reset counters to a known state.
    with ramjetio._cache_path_lock:
        for k in ramjetio._cache_path_stats:
            ramjetio._cache_path_stats[k] = 0

    for _ in range(3):
        ramjetio._record_cache_path('cache_local')
    for _ in range(2):
        ramjetio._record_cache_path('cache_peer')
    ramjetio._record_cache_path('s3')
    ramjetio._record_cache_path('failed')        # no-op
    ramjetio._record_cache_path('bogus_label')   # no-op

    snap = ramjetio._get_cache_path_stats()
    assert snap == {
        'cache_hits_local': 3,
        'cache_hits_peer': 2,
        'cache_hits_s3': 1,
        # Phase A (v0.9.2+): byte counters present and zero when nbytes=0.
        'ingress_bytes_local': 0,
        'ingress_bytes_peer': 0,
        'ingress_bytes_s3': 0,
    }
    # Snapshot must be a copy, not the live dict.
    snap['cache_hits_local'] = 9999
    assert ramjetio._get_cache_path_stats()['cache_hits_local'] == 3


def test_record_cache_path_accumulates_bytes():
    """Phase A (v0.9.2+): when nbytes is supplied, byte counters track the
    same source labels as hit counters, in lock-step."""
    import ramjetio

    with ramjetio._cache_path_lock:
        for k in ramjetio._cache_path_stats:
            ramjetio._cache_path_stats[k] = 0

    ramjetio._record_cache_path('cache_local', nbytes=1024)
    ramjetio._record_cache_path('cache_local', nbytes=512)
    ramjetio._record_cache_path('cache_peer', nbytes=4096)
    ramjetio._record_cache_path('s3', nbytes=8192)
    # nbytes=0 is the default; should not corrupt counters.
    ramjetio._record_cache_path('cache_local')
    # Unknown labels stay no-op even when nbytes is given.
    ramjetio._record_cache_path('bogus', nbytes=999)

    snap = ramjetio._get_cache_path_stats()
    assert snap['cache_hits_local'] == 3
    assert snap['cache_hits_peer'] == 1
    assert snap['cache_hits_s3'] == 1
    assert snap['ingress_bytes_local'] == 1024 + 512
    assert snap['ingress_bytes_peer'] == 4096
    assert snap['ingress_bytes_s3'] == 8192


def test_get_metrics_emits_local_rank_and_path_split(monkeypatch):
    """F8: _get_metrics surfaces LOCAL_RANK + per-path counters + zeroed
    singleflight counters when no in-process server is owned."""
    import ramjetio

    # Reset counters.
    with ramjetio._cache_path_lock:
        for k in ramjetio._cache_path_stats:
            ramjetio._cache_path_stats[k] = 0
    ramjetio._record_cache_path('cache_local')
    ramjetio._record_cache_path('s3')

    monkeypatch.setenv('LOCAL_RANK', '3')
    monkeypatch.setenv('RANK', '7')
    monkeypatch.setenv('WORLD_SIZE', '8')
    monkeypatch.setattr(ramjetio, '_server_process', None, raising=False)

    m = ramjetio._get_cache_metrics()
    assert m['ddp_local_rank'] == 3
    assert m['ddp_rank'] == 7
    assert m['ddp_world_size'] == 8
    assert m['cache_hits_local'] == 1
    assert m['cache_hits_peer'] == 0
    assert m['cache_hits_s3'] == 1
    # No local server owned → singleflight counters default to zero.
    assert m['singleflight_leaders'] == 0
    assert m['singleflight_waiters'] == 0
    assert m['singleflight_wait_hits'] == 0
    assert m['singleflight_wait_timeouts'] == 0


def test_node_metrics_proto_has_f8_fields():
    """F8: regenerated protobuf exposes the 8 new NodeMetrics fields."""
    from ramjetio.proto import ramjet_pb2

    nm = ramjet_pb2.NodeMetrics(
        ddp_local_rank=2,
        cache_hits_local=10,
        cache_hits_peer=5,
        cache_hits_s3=1,
        singleflight_leaders=3,
        singleflight_waiters=7,
        singleflight_wait_hits=6,
        singleflight_wait_timeouts=1,
        # Phase A (v0.9.2+): byte-level ingress fields 42–44.
        ingress_bytes_local=1024,
        ingress_bytes_peer=2048,
        ingress_bytes_s3=4096,
    )
    rt = ramjet_pb2.NodeMetrics.FromString(nm.SerializeToString())
    assert rt.ddp_local_rank == 2
    assert rt.cache_hits_local == 10
    assert rt.cache_hits_peer == 5
    assert rt.cache_hits_s3 == 1
    assert rt.singleflight_leaders == 3
    assert rt.singleflight_waiters == 7
    assert rt.singleflight_wait_hits == 6
    assert rt.singleflight_wait_timeouts == 1
    assert rt.ingress_bytes_local == 1024
    assert rt.ingress_bytes_peer == 2048
    assert rt.ingress_bytes_s3 == 4096
