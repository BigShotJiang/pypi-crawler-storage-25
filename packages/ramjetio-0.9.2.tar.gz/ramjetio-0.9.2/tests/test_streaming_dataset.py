"""Tests for Phase P3 streaming dataset scaffolding.

These tests cover the framework-independent parts of
``ramjetio.integrations.ultralytics_dataset``: the cache key schema and
the ``streaming_load_image_bytes`` helper. The full dataset / trainer
subclasses require Ultralytics installed and are exercised in
integration tests on odin (not in CI).
"""
from __future__ import annotations

from typing import Dict, Tuple

import pytest

from ramjetio.integrations.ultralytics_dataset import (
    _ramjet_image_key,
    streaming_load_image_bytes,
)


# ---------------------------------------------------------------------------
# Test doubles
# ---------------------------------------------------------------------------

class FakeCache:
    """Minimal DistributedCache stand-in with F5 `get_with_source`."""

    def __init__(self, preload: Dict[str, Tuple[bytes, str]] = None):
        self.store: Dict[str, bytes] = {}
        self.source_map: Dict[str, str] = {}
        if preload:
            for k, (v, src) in preload.items():
                self.store[k] = v
                self.source_map[k] = src
        self.get_calls = []
        self.set_calls = []

    def get_with_source(self, key: str):
        self.get_calls.append(key)
        if key in self.store:
            return self.store[key], self.source_map.get(key, "cache_local")
        return None, None

    def get(self, key: str):
        return self.store.get(key)

    def set(self, key: str, value: bytes):
        self.set_calls.append((key, value))
        self.store[key] = value
        self.source_map[key] = "cache_local"
        return True


class FakeS3:
    def __init__(self, contents: Dict[str, bytes], fail_on: set = None):
        self.contents = contents
        self.fail_on = fail_on or set()
        self.calls = []

    def get_bytes(self, path: str) -> bytes:
        self.calls.append(path)
        if path in self.fail_on:
            raise IOError(f"fake s3 fail for {path}")
        return self.contents[path]


# ---------------------------------------------------------------------------
# _ramjet_image_key
# ---------------------------------------------------------------------------

def test_ramjet_image_key_is_stable_and_split_scoped():
    assert _ramjet_image_key("train", 0) == "yolo_img_train_0"
    assert _ramjet_image_key("val", 42) == "yolo_img_val_42"
    # Determinism
    assert _ramjet_image_key("train", 100) == _ramjet_image_key("train", 100)
    # Split namespacing
    assert _ramjet_image_key("train", 7) != _ramjet_image_key("val", 7)


# ---------------------------------------------------------------------------
# streaming_load_image_bytes — hit / miss / set-through
# ---------------------------------------------------------------------------

def test_streaming_load_local_cache_hit_returns_bytes_and_source():
    key = _ramjet_image_key("train", 0)
    cache = FakeCache(preload={key: (b"IMAGE0", "cache_local")})
    s3 = FakeS3(contents={})
    data, source = streaming_load_image_bytes(
        cache=cache, s3_client=s3, image_paths=["s3://bucket/0.jpg"],
        split="train", idx=0,
    )
    assert data == b"IMAGE0"
    assert source == "cache_local"
    assert cache.set_calls == []  # no write-through on hit
    assert s3.calls == []  # S3 not touched on hit


def test_streaming_load_peer_cache_hit_preserves_source():
    key = _ramjet_image_key("train", 1)
    cache = FakeCache(preload={key: (b"PEER1", "cache_peer")})
    s3 = FakeS3(contents={})
    data, source = streaming_load_image_bytes(
        cache=cache, s3_client=s3, image_paths=["s3://bucket/1.jpg"],
        split="train", idx=1,
    )
    assert data == b"PEER1"
    assert source == "cache_peer"


def test_streaming_load_cache_miss_falls_back_to_s3_and_writes_through():
    cache = FakeCache()
    s3 = FakeS3(contents={"s3://bucket/2.jpg": b"S3-PAYLOAD"})
    data, source = streaming_load_image_bytes(
        cache=cache, s3_client=s3, image_paths=["s3://bucket/2.jpg"],
        split="train", idx=0,
    )
    assert data == b"S3-PAYLOAD"
    assert source == "s3"
    # Write-through populated the cache under the F9-namespaced key.
    assert cache.set_calls == [(_ramjet_image_key("train", 0), b"S3-PAYLOAD")]
    assert s3.calls == ["s3://bucket/2.jpg"]


def test_streaming_load_s3_failure_returns_failed_source():
    cache = FakeCache()
    s3 = FakeS3(
        contents={"s3://bucket/3.jpg": b""},
        fail_on={"s3://bucket/3.jpg"},
    )
    data, source = streaming_load_image_bytes(
        cache=cache, s3_client=s3, image_paths=["s3://bucket/3.jpg"],
        split="train", idx=0,
    )
    assert data == b""
    assert source == "failed"
    assert cache.set_calls == []  # no write-through of empty/failed data


def test_streaming_load_without_cache_uses_pure_s3():
    s3 = FakeS3(contents={"s3://bucket/4.jpg": b"NOCACHE"})
    data, source = streaming_load_image_bytes(
        cache=None, s3_client=s3, image_paths=["s3://bucket/4.jpg"],
        split="val", idx=0,
    )
    assert data == b"NOCACHE"
    assert source == "s3"


def test_streaming_load_second_call_is_served_from_cache():
    """Write-through on first call makes the second a local hit."""
    cache = FakeCache()
    s3 = FakeS3(contents={"s3://bucket/5.jpg": b"FIVE"})
    # Cold
    d1, s1 = streaming_load_image_bytes(
        cache=cache, s3_client=s3, image_paths=["s3://bucket/5.jpg"],
        split="train", idx=0,
    )
    # Warm
    d2, s2 = streaming_load_image_bytes(
        cache=cache, s3_client=s3, image_paths=["s3://bucket/5.jpg"],
        split="train", idx=0,
    )
    assert d1 == d2 == b"FIVE"
    assert s1 == "s3"
    assert s2 == "cache_local"
    assert s3.calls == ["s3://bucket/5.jpg"]  # S3 hit exactly once


def test_streaming_load_legacy_cache_without_get_with_source():
    """Back-compat: cache objects without F5 still work via plain .get()."""

    class LegacyCache:
        def __init__(self):
            self.store = {}
            self.set_calls = []

        def get(self, key):
            return self.store.get(key)

        def set(self, key, value):
            self.set_calls.append((key, value))
            self.store[key] = value
            return True

    cache = LegacyCache()
    cache.store[_ramjet_image_key("train", 0)] = b"LEGACY"
    s3 = FakeS3(contents={})
    data, source = streaming_load_image_bytes(
        cache=cache, s3_client=s3, image_paths=["x"],
        split="train", idx=0,
    )
    assert data == b"LEGACY"
    assert source == "cache_local"  # legacy cache defaults to local attribution


# ---------------------------------------------------------------------------
# Factory behaviour when Ultralytics is missing
# ---------------------------------------------------------------------------

def test_make_streaming_dataset_class_raises_clearly_without_ultralytics():
    """Factories should raise ImportError (not AttributeError) if ultralytics
    is unavailable. When it IS installed, importing succeeds; we only assert
    the error type in the unavailable case."""
    from ramjetio.integrations import ultralytics_dataset as uds

    try:
        import ultralytics  # noqa: F401
        ultralytics_available = True
    except ImportError:
        ultralytics_available = False

    if ultralytics_available:
        # Must not raise
        cls = uds.make_streaming_dataset_class()
        assert cls.__name__ == "RamjetStreamingYOLODataset"
    else:
        with pytest.raises(ImportError, match="ultralytics"):
            uds.make_streaming_dataset_class()
