"""Phase 6.B.2: BackendClient ↔ CacheServer drain wiring.

The backend never reaches the SDK over HTTP (it only stores a hashed API
key). Instead, drain orchestration uses the existing heartbeat channel:

  * SDK -> backend: every HeartbeatRequest carries the local /drain/status
    snapshot (state/total/done/errors/last_error).
  * backend -> SDK: HeartbeatResponse may carry a ``drain_command_id`` plus
    the future ring; the SDK dedupes on the id and launches its local
    drain task once.

This file exercises both directions in isolation (pure mocks) and the
end-to-end command dispatch on a real CacheServer instance running in
the multinode harness (so the on_startup loop-capture is exercised).
"""

from __future__ import annotations

import threading
import time
from typing import Any, Dict, List
from unittest.mock import MagicMock

import pytest
import requests

from ramjetio.backend_client import BackendClient
from tests._multinode_harness import start_cluster, stop_cluster


# --------------------------------------------------------------------------- #
# Helpers — fake gRPC pb2 / stub that record what the heartbeat builds.
# --------------------------------------------------------------------------- #

class _FakeNodeMetrics:
    def __init__(self, **kwargs: Any) -> None:
        self.__dict__.update(kwargs)


class _FakeHeartbeatRequest:
    def __init__(self, **kwargs: Any) -> None:
        self.__dict__.update(kwargs)


class _FakeHeartbeatResponse:
    def __init__(
        self,
        config_changed: bool = False,
        config: Any = None,
        drain_command_id: str = "",
        drain_mode: str = "",
        drain_future_nodes: List[str] | None = None,
        drain_self_address: str = "",
        drain_rate_limit_mbps: float = 0.0,
        drain_replication_factor: int = 1,
    ) -> None:
        self.config_changed = config_changed
        self.config = config
        self.drain_command_id = drain_command_id
        self.drain_mode = drain_mode
        self.drain_future_nodes = drain_future_nodes or []
        self.drain_self_address = drain_self_address
        self.drain_rate_limit_mbps = drain_rate_limit_mbps
        self.drain_replication_factor = drain_replication_factor


class _FakePb2:
    HeartbeatRequest = _FakeHeartbeatRequest
    NodeMetrics = _FakeNodeMetrics


def _make_client(response: _FakeHeartbeatResponse) -> BackendClient:
    """Build a BackendClient with mocked transport — no network."""
    client = BackendClient(node_port=9000, api_key="test-key")
    client.node_id = "node-1"
    client._connected = True
    client._running = True
    client._pb2 = _FakePb2  # type: ignore[assignment]
    stub = MagicMock()
    stub.Heartbeat = MagicMock(return_value=response)
    client._stub = stub
    client._get_metrics_fn = lambda: {}
    return client


def _drive_one_heartbeat(client: BackendClient) -> _FakeHeartbeatRequest:
    """Run the heartbeat loop body exactly once, then stop it."""
    # Trip the loop after one iteration.
    def _stop_after_one(*_a: Any, **_kw: Any) -> _FakeHeartbeatResponse:
        client._running = False
        return client._stub.Heartbeat.return_value
    client._stub.Heartbeat.side_effect = _stop_after_one
    client._heartbeat_loop(interval=0.0)
    return client._stub.Heartbeat.call_args.args[0]


# --------------------------------------------------------------------------- #
# 1. Heartbeat request carries drain progress
# --------------------------------------------------------------------------- #

def test_heartbeat_includes_drain_snapshot():
    client = _make_client(_FakeHeartbeatResponse())
    client.set_drain_callbacks(
        status_provider=lambda: {
            "state": "running",
            "total": 100,
            "done": 42,
            "errors": 1,
            "last_error": "boom",
        },
        command_handler=lambda _cmd: None,
    )

    req = _drive_one_heartbeat(client)

    assert req.drain_state == "running"
    assert req.drain_total == 100
    assert req.drain_done == 42
    assert req.drain_errors == 1
    assert req.drain_last_error == "boom"


def test_heartbeat_drain_fields_default_empty_when_no_provider():
    client = _make_client(_FakeHeartbeatResponse())
    # No set_drain_callbacks() — provider is None.

    req = _drive_one_heartbeat(client)

    assert req.drain_state == ""
    assert req.drain_total == 0
    assert req.drain_done == 0
    assert req.drain_errors == 0
    assert req.drain_last_error == ""


def test_heartbeat_swallows_provider_errors():
    """A buggy snapshot provider must not break heartbeats."""
    client = _make_client(_FakeHeartbeatResponse())

    def bad_provider() -> Dict[str, Any]:
        raise RuntimeError("provider blew up")

    client.set_drain_callbacks(status_provider=bad_provider, command_handler=None)

    req = _drive_one_heartbeat(client)
    assert req.drain_state == ""  # fell back to defaults; no exception bubbled


# --------------------------------------------------------------------------- #
# 2. Drain command dispatch
# --------------------------------------------------------------------------- #

def test_drain_command_dispatched_once_per_id():
    """Backend resends the same id every heartbeat; SDK must dedupe."""
    response = _FakeHeartbeatResponse(
        drain_command_id="node-1:1700000000",
        drain_mode="drain",
        drain_future_nodes=["b:9000", "c:9000"],
        drain_self_address="a:9000",
        drain_rate_limit_mbps=0.0,
        drain_replication_factor=2,
    )
    client = _make_client(response)
    invocations: List[Dict[str, Any]] = []
    client.set_drain_callbacks(
        status_provider=lambda: {},
        command_handler=lambda cmd: invocations.append(cmd),
    )

    # Drive 5 heartbeats, all returning the same command id.
    iters = {"n": 0}
    def _five(*_a: Any, **_kw: Any) -> _FakeHeartbeatResponse:
        iters["n"] += 1
        if iters["n"] >= 5:
            client._running = False
        return response
    client._stub.Heartbeat.side_effect = _five
    client._heartbeat_loop(interval=0.0)

    assert iters["n"] == 5
    assert len(invocations) == 1, "command_handler should be called exactly once"
    cmd = invocations[0]
    assert cmd["command_id"] == "node-1:1700000000"
    assert cmd["mode"] == "drain"
    assert cmd["future_nodes"] == ["b:9000", "c:9000"]
    assert cmd["self_address"] == "a:9000"
    assert cmd["replication_factor"] == 2


def test_new_command_id_dispatches_again():
    """A different ``drain_command_id`` (e.g. cancel after drain) re-fires."""
    client = _make_client(_FakeHeartbeatResponse())
    invocations: List[str] = []
    client.set_drain_callbacks(
        status_provider=lambda: {},
        command_handler=lambda cmd: invocations.append(cmd["command_id"]),
    )

    sequence = [
        _FakeHeartbeatResponse(
            drain_command_id="node-1:t1",
            drain_mode="drain",
            drain_future_nodes=["b:9000"],
            drain_self_address="a:9000",
        ),
        _FakeHeartbeatResponse(
            drain_command_id="node-1:t1",  # same — must dedupe
            drain_mode="drain",
        ),
        _FakeHeartbeatResponse(
            drain_command_id="node-1:cancel",  # new id — must fire
            drain_mode="cancel",
        ),
    ]
    iters = {"n": 0}

    def _drive(*_a: Any, **_kw: Any) -> _FakeHeartbeatResponse:
        i = iters["n"]
        iters["n"] += 1
        if i >= len(sequence) - 1:
            client._running = False
        return sequence[i]

    client._stub.Heartbeat.side_effect = _drive
    client._heartbeat_loop(interval=0.0)

    assert invocations == ["node-1:t1", "node-1:cancel"]


def test_handler_exception_does_not_break_loop():
    """A buggy handler must not bring down the heartbeat loop."""
    response = _FakeHeartbeatResponse(
        drain_command_id="x", drain_mode="drain",
        drain_future_nodes=["b:9000"], drain_self_address="a:9000",
    )
    client = _make_client(response)
    calls = {"n": 0}

    def bad_handler(_cmd: Dict[str, Any]) -> None:
        calls["n"] += 1
        raise RuntimeError("handler kaput")

    client.set_drain_callbacks(status_provider=lambda: {}, command_handler=bad_handler)

    # Run two heartbeats; exception on first must not stop the loop or
    # break the dedup bookkeeping.
    iters = {"n": 0}
    def _drive(*_a: Any, **_kw: Any) -> _FakeHeartbeatResponse:
        iters["n"] += 1
        if iters["n"] >= 2:
            client._running = False
        return response
    client._stub.Heartbeat.side_effect = _drive
    client._heartbeat_loop(interval=0.0)

    assert calls["n"] == 1  # second iteration deduped on same id
    # Heartbeat counters still healthy (no failure recorded).
    assert client.heartbeat_failures_total == 0


# --------------------------------------------------------------------------- #
# 3. End-to-end: CacheServer.on_startup captures loop and _on_drain_command
#    actually launches a drain on the running aiohttp app.
# --------------------------------------------------------------------------- #

@pytest.fixture
def cluster3(tmp_path, monkeypatch):
    monkeypatch.delenv("RAMJET_API_KEY", raising=False)
    nodes = start_cluster(tmp_path, n=3)
    try:
        yield nodes
    finally:
        stop_cluster(nodes)


def _envelope(s: str) -> bytes:
    return b"RJRB" + s.encode("utf-8")


def test_on_startup_captures_event_loop(cluster3):
    """The on_startup hook must populate ``_app_loop`` so cross-thread
    coroutine scheduling works."""
    for node in cluster3:
        assert node.server._app_loop is not None
        assert node.server._app_loop.is_running()


def test_on_drain_command_launches_drain(cluster3):
    """End-to-end: simulate a heartbeat-delivered command and verify the
    drain coroutine actually runs on the aiohttp loop."""
    leaving = cluster3[0]
    others = cluster3[1:]

    # Seed some keys so the drain has work to do.
    for i in range(20):
        r = requests.post(
            f"http://{leaving.address}/set",
            params={"key": f"k{i}"},
            data=_envelope(f"v{i}"),
            timeout=5,
        )
        assert r.status_code == 200

    cmd = {
        "command_id": "node-1:t1",
        "mode": "drain",
        "future_nodes": [n.address for n in others],
        "self_address": leaving.address,
        "rate_limit_mbps": 0.0,
        "replication_factor": 1,
    }
    leaving.server._on_drain_command(cmd)  # called from main thread (worker analogue)

    # Poll /drain/status until terminal.
    deadline = time.time() + 10
    last: Dict[str, Any] = {}
    while time.time() < deadline:
        r = requests.get(f"http://{leaving.address}/drain/status", timeout=2)
        last = r.json()
        if last["state"] in ("done", "failed", "cancelled"):
            break
        time.sleep(0.05)

    assert last["state"] == "done", f"unexpected final state: {last}"
    assert last["done"] >= 1


def test_on_drain_command_cancel_aborts_running_drain(cluster3):
    """A cancel command sets the cancel event on the in-flight drain."""
    leaving = cluster3[0]
    others = cluster3[1:]

    # Volume + replication so drain takes long enough to cancel.
    payload = b"RJRB" + (b"x" * 4096)
    for i in range(500):
        r = requests.post(
            f"http://{leaving.address}/set",
            params={"key": f"big{i}"},
            data=payload,
            timeout=5,
        )
        assert r.status_code == 200

    leaving.server._on_drain_command({
        "command_id": "node-1:t1",
        "mode": "drain",
        "future_nodes": [n.address for n in others],
        "self_address": leaving.address,
        "rate_limit_mbps": 0.0,
        "replication_factor": 2,  # forces 2× the work
    })

    # Wait until drain is actually running.
    deadline = time.time() + 5
    while time.time() < deadline:
        r = requests.get(f"http://{leaving.address}/drain/status", timeout=2)
        if r.json()["state"] == "running" and r.json()["done"] > 0:
            break
        time.sleep(0.02)
    else:
        pytest.fail("drain never started")

    # Now send the cancel command.
    leaving.server._on_drain_command({
        "command_id": "node-1:cancel",
        "mode": "cancel",
    })

    # Wait for terminal state.
    deadline = time.time() + 10
    last: Dict[str, Any] = {}
    while time.time() < deadline:
        r = requests.get(f"http://{leaving.address}/drain/status", timeout=2)
        last = r.json()
        if last["state"] in ("done", "failed", "cancelled"):
            break
        time.sleep(0.05)

    assert last["state"] == "cancelled", f"expected cancelled, got {last}"


def test_on_drain_command_idempotent_while_running(cluster3):
    """A second command_id while drain is running must not double-launch."""
    leaving = cluster3[0]
    others = cluster3[1:]

    # Enough volume so the first drain is still running when we issue the second.
    payload = b"RJRB" + (b"x" * 2048)
    for i in range(200):
        requests.post(
            f"http://{leaving.address}/set",
            params={"key": f"k{i}"},
            data=payload,
            timeout=5,
        )

    cmd1 = {
        "command_id": "id-1", "mode": "drain",
        "future_nodes": [n.address for n in others],
        "self_address": leaving.address, "rate_limit_mbps": 0.0,
        "replication_factor": 2,
    }
    leaving.server._on_drain_command(cmd1)

    # Wait until running. ``_on_drain_command`` schedules the launch via
    # run_coroutine_threadsafe so the state flip is asynchronous; under
    # full-suite load the loop can take a few hundred ms to pick it up.
    deadline = time.time() + 10
    while time.time() < deadline:
        if leaving.server._drain_state == "running":
            break
        time.sleep(0.02)
    assert leaving.server._drain_state == "running", \
        f"drain never started, state={leaving.server._drain_state}"
    first_started = leaving.server._drain_started_ts

    cmd2 = dict(cmd1, command_id="id-2")
    leaving.server._on_drain_command(cmd2)
    # Give the loop a chance to (incorrectly) re-launch if the guard is broken.
    time.sleep(0.2)
    # _drain_started_ts must not have been reset.
    assert leaving.server._drain_started_ts == first_started

    # Let it finish so cluster3 fixture can tear down cleanly.
    deadline = time.time() + 30
    while time.time() < deadline:
        if leaving.server._drain_state in ("done", "failed", "cancelled"):
            break
        time.sleep(0.1)
