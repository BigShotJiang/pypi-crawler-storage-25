"""Fork-safety tests for P3.3 Step 2 (enable DataLoader workers>0).

These tests validate that ``DistributedCache`` can be safely used from
forked child processes — the scenario we hit when Ultralytics' YOLO
dataset spawns DataLoader workers via ``multiprocessing`` fork context.

Contract under test:

1. ``DistributedCache.session`` is lazily (re)initialised per PID so a
   cached ``requests.Session`` from the parent process is discarded in
   the child. This avoids sharing TCP sockets across ``fork()``, which
   corrupts the connection pool and silently produces 0-length reads.

2. ``streaming_load_image_bytes`` does not crash when invoked from a
   fork-spawned worker against a real DistributedCache instance.

We use ``multiprocessing.get_context('fork')`` explicitly (rather than
the test runner's default) because PyTorch DataLoader uses fork on Linux
by default, and any fork-unsafe code that happens to "work" under spawn
will still break in production.
"""
from __future__ import annotations

import multiprocessing as mp
import os

import pytest

from ramjetio.cache import DistributedCache
from ramjetio.integrations.ultralytics_dataset import streaming_load_image_bytes


# Some platforms (macOS as of Py3.8+) default to 'spawn'. We force 'fork'
# because that is what triggers the bug class we're defending against.
# Skip the suite entirely if fork is unavailable (e.g. native Windows).
try:
    _FORK_CTX = mp.get_context("fork")
    _FORK_AVAILABLE = True
except (ValueError, AttributeError):
    _FORK_AVAILABLE = False

pytestmark = pytest.mark.skipif(
    not _FORK_AVAILABLE, reason="fork start method not available on this platform"
)


# ---------------------------------------------------------------------------
# worker-process targets (must be module-level so fork can pickle them)
# ---------------------------------------------------------------------------

def _child_session_pid(_idx: int) -> tuple[int, int]:
    """Return (os.getpid, id(cache.session)) from a child process.

    The ``cache`` is inherited across fork. ``cache.session`` in the child
    must be a freshly built object, not the parent's.
    """
    # NB: `_SHARED_CACHE` is populated in the parent before fork.
    cache = _SHARED_CACHE
    s = cache.session  # triggers lazy (re)init
    return (os.getpid(), id(s), cache._session_pid)


_IMAGE_PATHS = [f"img-{i}.jpg" for i in range(200)]


def _child_fetch(idx: int) -> tuple[int, str]:
    """Call streaming_load_image_bytes in a child process.

    We pass ``cache=None`` to exercise the pure-S3 path: the fork-safety
    of the cache's HTTP Session is covered by
    ``test_session_rebuilt_in_fork_child``, and mixing a real cache into
    this test would spend time on ECONNREFUSED retries to a fake peer.
    """
    s3_client = _SHARED_SOURCE
    data, src = streaming_load_image_bytes(
        cache=None,
        s3_client=s3_client,
        image_paths=_IMAGE_PATHS,
        split="train",
        idx=idx,
    )
    return (len(data), src)


class _InMemorySource:
    """Framework-independent fake S3 client: returns deterministic bytes."""

    def get_bytes(self, sample: str) -> bytes:
        # Use sample name hashed into a small blob.
        return f"payload:{sample}".encode()


# Module-level placeholders (set by fixtures before each test; read by
# fork-spawned children via copy-on-write).
_SHARED_CACHE: DistributedCache = None  # type: ignore[assignment]
_SHARED_SOURCE: _InMemorySource = None  # type: ignore[assignment]


@pytest.fixture
def shared_cache(monkeypatch):
    """Build a DistributedCache with no real peers, then expose it globally."""
    global _SHARED_CACHE, _SHARED_SOURCE
    # Single fake node; routing always hashes to it. We never actually
    # reach the network because get() will MISS and streaming_load_image_bytes
    # falls through to source.get_bytes().
    cache = DistributedCache(nodes=["127.0.0.1:1"], replication_factor=1)
    # Force a session in the parent, so we can verify the child gets a
    # distinct one.
    _ = cache.session
    _SHARED_CACHE = cache
    _SHARED_SOURCE = _InMemorySource()
    yield cache
    _SHARED_CACHE = None  # type: ignore[assignment]
    _SHARED_SOURCE = None  # type: ignore[assignment]


# ---------------------------------------------------------------------------
# tests
# ---------------------------------------------------------------------------

def test_session_rebuilt_in_fork_child(shared_cache):
    """Each forked worker must get its own Session, not inherit the parent's."""
    parent_session_id = id(shared_cache.session)
    parent_pid = os.getpid()

    with _FORK_CTX.Pool(4) as pool:
        results = pool.map(_child_session_pid, range(4))

    # All 4 children report different PIDs from the parent.
    child_pids = {r[0] for r in results}
    assert parent_pid not in child_pids, "children must not share parent's PID"

    # Every child's `_session_pid` matches its own PID.
    for child_pid, _, session_pid in results:
        assert session_pid == child_pid, "session was not re-bound in child"

    # At least one child produced a new id(session) distinct from the parent.
    # Strictly, every child will; we assert "not all identical" to be robust
    # against address-reuse across short-lived processes.
    child_session_ids = {r[1] for r in results}
    assert parent_session_id not in child_session_ids or len(child_session_ids) > 1


def test_streaming_load_image_bytes_from_fork_workers(shared_cache):
    """100 fetches × 4 workers must complete without deadlock or exception."""
    with _FORK_CTX.Pool(4) as pool:
        results = pool.map(_child_fetch, range(100))

    # All 100 calls returned a non-empty byte-string via the S3 fallback.
    assert len(results) == 100
    for size, src in results:
        assert size > 0
        assert src == "s3", f"expected source=s3 on miss, got {src}"
