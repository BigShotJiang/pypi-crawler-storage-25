"""A2: DDP rank fan-in — ranks >0 publish training counters via
``/tmp/ramjet_rank_{RANK}.json``; rank 0 aggregates them into the
single heartbeat payload so dashboards see cluster-wide throughput.
"""
from __future__ import annotations

import json
import os
import tempfile
import time

import pytest

import ramjetio


@pytest.fixture
def tmp_fanin_dir(monkeypatch):
    d = tempfile.mkdtemp(prefix="ramjet_fanin_")
    monkeypatch.setattr(ramjetio, "_RANK_FANIN_DIR", d)
    monkeypatch.setenv("RAMJET_DDP_RANK_FANIN", "1")
    yield d
    for fn in os.listdir(d):
        try:
            os.unlink(os.path.join(d, fn))
        except OSError:
            pass
    os.rmdir(d)


def _write_rank_file(dir_path: str, rank: int, sps: float, step: int, loss: float, ts: float | None = None):
    payload = {
        "rank": rank,
        "ts": ts if ts is not None else time.time(),
        "samples_per_second": sps,
        "current_step": step,
        "current_epoch": 1,
        "loss": loss,
        "is_training": True,
    }
    with open(os.path.join(dir_path, f"ramjet_rank_{rank}.json"), "w") as fh:
        json.dump(payload, fh)


def test_write_rank_fanin_sample_creates_atomic_file(tmp_fanin_dir, monkeypatch):
    monkeypatch.setenv("RANK", "2")
    status = {
        "samples_per_second": 123.4,
        "current_step": 50,
        "current_epoch": 3,
        "loss": 0.42,
        "is_training": True,
    }
    ramjetio._write_rank_fanin_sample(status)

    path = os.path.join(tmp_fanin_dir, "ramjet_rank_2.json")
    assert os.path.exists(path)
    assert not os.path.exists(path + ".tmp")
    with open(path) as fh:
        payload = json.load(fh)
    assert payload["rank"] == 2
    assert payload["samples_per_second"] == 123.4
    assert payload["current_step"] == 50


def test_write_rank_fanin_noop_when_disabled(tmp_fanin_dir, monkeypatch):
    monkeypatch.setenv("RAMJET_DDP_RANK_FANIN", "0")
    monkeypatch.setenv("RANK", "1")
    ramjetio._write_rank_fanin_sample({"samples_per_second": 99.0})
    assert not os.path.exists(os.path.join(tmp_fanin_dir, "ramjet_rank_1.json"))


def test_aggregate_sums_sps_across_ranks(tmp_fanin_dir):
    _write_rank_file(tmp_fanin_dir, 0, sps=10.0, step=100, loss=0.5)
    _write_rank_file(tmp_fanin_dir, 1, sps=12.0, step=105, loss=0.4)
    _write_rank_file(tmp_fanin_dir, 2, sps=11.0, step=103, loss=0.6)

    local = {"samples_per_second": 10.0, "current_step": 100, "loss": 0.5, "current_epoch": 1}
    merged = ramjetio._aggregate_rank_fanin(local)
    assert merged["samples_per_second"] == pytest.approx(33.0)
    assert merged["current_step"] == 105
    assert merged["ranks_reporting"] == 3
    assert merged["loss"] == pytest.approx((0.5 + 0.4 + 0.6) / 3)


def test_aggregate_ignores_stale_ranks(tmp_fanin_dir):
    # Rank 0 is fresh; rank 1 wrote its file long ago.
    _write_rank_file(tmp_fanin_dir, 0, sps=10.0, step=100, loss=0.5)
    _write_rank_file(tmp_fanin_dir, 1, sps=999.0, step=9999, loss=0.1,
                     ts=time.time() - 120.0)

    local = {"samples_per_second": 10.0, "current_step": 100, "loss": 0.5, "current_epoch": 1}
    merged = ramjetio._aggregate_rank_fanin(local)
    assert merged["samples_per_second"] == pytest.approx(10.0)
    assert merged["current_step"] == 100
    assert merged["ranks_reporting"] == 1


def test_aggregate_falls_back_to_local_when_no_files(tmp_fanin_dir):
    local = {"samples_per_second": 7.0, "current_step": 42, "loss": 0.9}
    merged = ramjetio._aggregate_rank_fanin(local)
    assert merged == local  # untouched copy of the local snapshot
