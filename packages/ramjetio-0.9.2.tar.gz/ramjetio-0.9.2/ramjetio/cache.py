"""
Distributed cache client implementation.

This module provides the main DistributedCache class that coordinates
caching operations across multiple cache servers using consistent hashing.
"""

import io
import logging
import os
import random
import struct
import threading
import time
import zlib
from typing import Any, List, Optional, Dict
import warnings

import msgpack
import requests
import torch

try:
    import numpy as np  # type: ignore
    _HAS_NUMPY = True
except ImportError:  # pragma: no cover - numpy is a transitive dep of torch
    np = None  # type: ignore
    _HAS_NUMPY = False

from ramjetio.consistent_hash import ConsistentHash
from ramjetio.serialization import serialize_tensor, deserialize_tensor
from ramjetio.config import get_api_key

logger = logging.getLogger(__name__)

# F3: Header name for peer auth. Must match server.AUTH_HEADER.
AUTH_HEADER = "X-RAMJET-API-Key"

# F12: On-wire envelope magic markers. The first 4 bytes of every value
# written to a peer identify the payload format. Readers refuse anything
# without a recognised marker (in particular, bare pickle streams).
MAGIC_TENSOR = b"RJBT"   # torch tensor via serialize_tensor/deserialize_tensor
MAGIC_BYTES = b"RJRB"    # raw bytes passthrough
MAGIC_STR = b"RJSB"      # UTF-8 string
MAGIC_MSGPACK = b"RJMS"  # msgpack-encoded structured value (dict/list/tuple/ndarray/scalars)

# Phase Q.1 (ramjetio v0.9.2): outer CRC32 envelope. New writes prepend
# ``RJV2 + 4-byte big-endian crc32(body)`` ahead of the inner format magic
# so a corrupt cache row (single-bit flip on disk, truncated peer transfer,
# overlong msgpack) is rejected with a typed error instead of silently
# returning garbage tensors. Legacy payloads (no RJV2 prefix) are still
# accepted on the read path; the next ``set()`` rewrites them in v2.
MAGIC_ENVELOPE_V2 = b"RJV2"
_ENVELOPE_V2_HEADER_LEN = 4 + 4  # 4-byte magic + 4-byte crc32

# Retry backoff tunables for DistributedCache._request().
# delay(attempt) = min(1.0s, _BACKOFF_BASE_SECONDS * 2**attempt) * (1 ± _BACKOFF_JITTER)
# Defaults give 50ms / 100ms / 200ms / 400ms / 800ms / 1000ms... with ±20% jitter,
# capped at 1.0s. Picked to be invisible on a single transient blip but still
# back off hard enough to avoid hammering a flapping peer.
_BACKOFF_BASE_SECONDS = 0.050
_BACKOFF_JITTER = 0.20

# msgpack ext type codes for our custom hooks. Values are arbitrary but stable
# across versions; bumping a code is a wire-format break.
_MP_EXT_NDARRAY = 1   # numpy ndarray: packed as [shape, dtype_str, raw_bytes]
_MP_EXT_TUPLE = 2     # tuple (preserves type vs list on round-trip)


def _msgpack_default(obj: Any) -> Any:
    """msgpack ``default`` hook for custom safe types.

    Only types we explicitly recognise are encoded; anything else raises
    TypeError and is rejected at :func:`_encode_value` boundary so we never
    fall back to pickle.
    """
    if _HAS_NUMPY and isinstance(obj, np.ndarray):
        # Reject object-dtype arrays — they would force pickle on decode.
        if obj.dtype == object:
            raise TypeError(
                "msgpack codec refuses numpy ndarray with dtype=object "
                "(would require pickle on decode)"
            )
        payload = msgpack.packb(
            [list(obj.shape), str(obj.dtype), obj.tobytes()],
            use_bin_type=True,
        )
        return msgpack.ExtType(_MP_EXT_NDARRAY, payload)
    if isinstance(obj, tuple):
        # Tuples become a length-prefixed list under ext code 2 to preserve
        # type on the wire (vanilla msgpack maps tuple -> list).
        payload = msgpack.packb(
            list(obj),
            use_bin_type=True,
            default=_msgpack_default,
            strict_types=True,
        )
        return msgpack.ExtType(_MP_EXT_TUPLE, payload)
    raise TypeError(
        f"msgpack codec cannot serialize object of type {type(obj).__name__}"
    )


def _msgpack_ext_hook(code: int, data: bytes) -> Any:
    """Decoder for custom msgpack ext types. Unknown codes are rejected."""
    if code == _MP_EXT_NDARRAY:
        if not _HAS_NUMPY:
            raise ValueError(
                "received numpy ndarray over the wire but numpy is not installed"
            )
        shape, dtype_str, raw = msgpack.unpackb(data, raw=False)
        # np.frombuffer + reshape avoids a copy and yields a writable view of
        # the decoded bytes.
        arr = np.frombuffer(raw, dtype=np.dtype(dtype_str)).reshape(shape)
        # Return a writable copy: frombuffer returns a read-only view of the
        # msgpack buffer, which dies with the unpacker.
        return arr.copy()
    if code == _MP_EXT_TUPLE:
        return tuple(
            msgpack.unpackb(data, raw=False, ext_hook=_msgpack_ext_hook)
        )
    raise ValueError(f"unsupported msgpack ext code: {code}")


def _is_msgpack_safe(value: Any) -> bool:
    """Best-effort whitelist for top-level msgpack-eligible values.

    Used to decide whether to route via :data:`MAGIC_MSGPACK`. Container
    membership is checked recursively; leaves must be primitives, ndarray,
    or empty containers.
    """
    if value is None or isinstance(value, (bool, int, float)):
        return True
    if isinstance(value, (bytes, bytearray, memoryview, str)):
        return True
    if _HAS_NUMPY and isinstance(value, np.ndarray):
        return value.dtype != object
    if isinstance(value, (list, tuple)):
        return all(_is_msgpack_safe(v) for v in value)
    if isinstance(value, dict):
        return all(
            isinstance(k, (str, int, float, bool)) and _is_msgpack_safe(v)
            for k, v in value.items()
        )
    return False


def _encode_value(value: Any, compress: bool = False) -> bytes:
    """Wrap a supported value in a signed envelope for on-wire storage.

    Supported types:
      * ``torch.Tensor`` — :data:`MAGIC_TENSOR`
      * ``bytes``        — :data:`MAGIC_BYTES`
      * ``str``          — :data:`MAGIC_STR`
      * ``dict`` / ``list`` / ``tuple`` / ``numpy.ndarray`` and primitives —
        :data:`MAGIC_MSGPACK` via a safe codec (no pickle).

    Anything else raises ``TypeError``; callers must pre-serialize unsafe
    types themselves rather than have us silently invoke pickle.

    Phase Q.1: the inner envelope is wrapped in :data:`MAGIC_ENVELOPE_V2`
    + CRC32 so corrupt rows are caught at decode time.
    """
    if isinstance(value, torch.Tensor):
        body = MAGIC_TENSOR + serialize_tensor(value, compress=compress)
    elif isinstance(value, (bytes, bytearray, memoryview)):
        body = MAGIC_BYTES + bytes(value)
    elif isinstance(value, str):
        body = MAGIC_STR + value.encode("utf-8")
    elif _is_msgpack_safe(value):
        try:
            packed = msgpack.packb(
                value,
                use_bin_type=True,
                default=_msgpack_default,
                strict_types=True,  # preserves tuple via ext hook above
            )
        except (TypeError, ValueError) as e:
            raise TypeError(
                f"DistributedCache cannot msgpack-encode value: {e}"
            ) from e
        body = MAGIC_MSGPACK + packed
    else:
        raise TypeError(
            f"DistributedCache refuses to store value of type {type(value).__name__}: "
            "supported types are torch.Tensor, bytes, str, and msgpack-safe "
            "dict/list/tuple/numpy.ndarray of primitives. "
            "Pre-serialize anything else with a safe codec before caching."
        )
    crc = zlib.crc32(body) & 0xFFFFFFFF
    return MAGIC_ENVELOPE_V2 + struct.pack(">I", crc) + body


def _decode_value(data: bytes) -> Any:
    """Inverse of :func:`_encode_value`. Rejects payloads lacking a magic prefix.

    This is the hardening for G14 (RCE via pickle.loads fallback): we never
    evaluate untrusted bytes with pickle, and we do not silently fall through
    to any other unsafe deserializer.

    Phase Q.1: if the payload starts with :data:`MAGIC_ENVELOPE_V2`, the
    next 4 bytes carry a big-endian CRC32 of the inner payload. A mismatch
    raises ``ValueError("cache payload CRC mismatch")``. Legacy payloads
    without the v2 wrapper are still decoded for read-back compatibility.
    """
    if not data or len(data) < 4:
        raise ValueError("empty or truncated cache payload")
    if data[:4] == MAGIC_ENVELOPE_V2:
        if len(data) < _ENVELOPE_V2_HEADER_LEN + 4:
            raise ValueError("truncated v2 envelope: missing CRC or inner magic")
        expected_crc = struct.unpack(">I", data[4:8])[0]
        body = data[_ENVELOPE_V2_HEADER_LEN:]
        actual_crc = zlib.crc32(body) & 0xFFFFFFFF
        if actual_crc != expected_crc:
            raise ValueError(
                f"cache payload CRC mismatch: expected {expected_crc:#010x}, "
                f"got {actual_crc:#010x} (corrupt row or wire truncation)"
            )
    else:
        body = data
    if len(body) < 4:
        raise ValueError("empty or truncated cache payload")
    magic = body[:4]
    inner = body[4:]
    if magic == MAGIC_TENSOR:
        return deserialize_tensor(inner)
    if magic == MAGIC_BYTES:
        return inner
    if magic == MAGIC_STR:
        return inner.decode("utf-8")
    if magic == MAGIC_MSGPACK:
        try:
            return msgpack.unpackb(
                inner,
                raw=False,
                ext_hook=_msgpack_ext_hook,
                strict_map_key=False,
            )
        except (ValueError, msgpack.exceptions.ExtraData,
                msgpack.exceptions.FormatError, msgpack.exceptions.StackError) as e:
            raise ValueError(f"corrupt msgpack cache payload: {e}") from e
    raise ValueError(f"unsupported cache payload format: {magic!r}")


def _decode_mget_frame(buf: bytes) -> Dict[str, Optional[bytes]]:
    """Phase Q.5: parse the binary multi-get response.

    Wire format (content-type ``application/x-ramjet-mget-v1``):

    ``uint32_be N`` followed by N records of
    ``uint32_be key_len | key utf-8 | uint32_be value_len | value bytes``.
    A ``value_len`` of ``0xFFFFFFFF`` indicates a miss (no value bytes follow).
    """
    if len(buf) < 4:
        raise ValueError("mget frame: missing header")
    (n,) = struct.unpack(">I", buf[:4])
    off = 4
    out: Dict[str, Optional[bytes]] = {}
    MISS = 0xFFFFFFFF
    for _ in range(n):
        if off + 4 > len(buf):
            raise ValueError("mget frame: truncated key_len")
        (klen,) = struct.unpack(">I", buf[off:off + 4]); off += 4
        if off + klen > len(buf):
            raise ValueError("mget frame: truncated key")
        key = buf[off:off + klen].decode("utf-8"); off += klen
        if off + 4 > len(buf):
            raise ValueError("mget frame: truncated value_len")
        (vlen,) = struct.unpack(">I", buf[off:off + 4]); off += 4
        if vlen == MISS:
            out[key] = None
            continue
        if off + vlen > len(buf):
            raise ValueError("mget frame: truncated value")
        out[key] = bytes(buf[off:off + vlen]); off += vlen
    return out


class DistributedCache:
    """
    Distributed cache client with consistent hashing.
    
    Distributes cached data across multiple cache servers using consistent
    hashing for efficient load balancing and minimal key redistribution.
    
    Args:
        nodes: List of cache server addresses (e.g., ["host1:9000", "host2:9000"])
        virtual_nodes: Number of virtual nodes per physical node (default: 150)
        timeout: Request timeout in seconds (default: 30)
        retry_attempts: Number of retry attempts for failed requests (default: 3)
        compression: Enable compression for cached data (default: False)
        replication_factor: Number of replicas for each key (default: 1, no replication)
    
    Example:
        >>> cache = DistributedCache(["node1:9000", "node2:9000"])
        >>> cache.set("key1", torch.randn(10, 10))
        >>> data = cache.get("key1")
        >>> cache.delete("key1")
    """
    
    def __init__(
        self,
        nodes: List[str],
        virtual_nodes: int = 150,
        timeout: int = 30,
        retry_attempts: int = 3,
        compression: bool = False,
        replication_factor: int = 1,
        key_namespace: Optional[str] = None,
        local_node: Optional[str] = None,
    ):
        """Initialize the distributed cache client.

        Args:
            key_namespace: Optional string prefix applied to every key before
                hashing/routing. Enables F9 multi-tenant isolation: two jobs
                running under the same API key but different ``key_namespace``
                values cannot collide on cache keys. The namespace is joined
                to the user-supplied key with ``|`` as a separator.
            local_node: Optional "host:port" string identifying which node
                in ``nodes`` is this process's co-located cache server. When
                set, :meth:`get_with_source` tags successful fetches as
                ``'local'`` or ``'peer'`` accordingly (F5 metric split).
                Has no effect on routing.
        """
        if not nodes:
            raise ValueError("At least one cache node must be provided")

        # F-Ring1: store nodes in a deterministic sorted order so that all
        # DDP ranks (and the topology watcher) observe an identical sequence
        # regardless of how add_node calls happened to interleave. Routing
        # was already deterministic via MD5 hashing; this makes the visible
        # node list, logs, and topology JSON stable across processes.
        self.nodes = sorted(nodes)
        self.timeout = timeout
        self.retry_attempts = retry_attempts
        self.compression = compression
        self.replication_factor = replication_factor
        self.key_namespace = key_namespace or None
        # F5: local node identity for hit attribution. Not used for routing.
        self.local_node: Optional[str] = local_node or None

        # Initialize consistent hash ring
        self.hash_ring = ConsistentHash(nodes=nodes, virtual_nodes=virtual_nodes)

        # F4: Optional frozen snapshot of the hash ring. While set, all routing
        # ops use this snapshot instead of ``self.hash_ring``. Used during
        # long-running operations (e.g. dataset export) to prevent mid-op
        # repartition when a node flaps or the backend returns a new list.
        self._frozen_ring: Optional[ConsistentHash] = None

        # Persistent HTTP session for connection pooling.
        # Lazy-initialized per process for fork-safety with DataLoader workers.
        self._session: Optional[requests.Session] = None
        self._session_pid: Optional[int] = None
        self._node_count = len(nodes)

        # F13: monotonic ring version, bumped on every topology mutation.
        # Used by sibling DDP ranks watching a shared topology file to ignore
        # stale updates and apply newer ones idempotently.
        self.config_version: int = 0
        # F-Diag1: ring-churn diagnostics. ``ring_churn_total`` increments on
        # every accepted topology mutation (add/remove/replace); divergent
        # from ``config_version`` only because failed/stale replace_nodes
        # calls don't count. ``ring_last_change_ts`` is wall-clock seconds.
        self.ring_churn_total: int = 0
        self.ring_last_change_ts: float = 0.0
        self._ring_lock = threading.Lock()

        logger.info(
            "Initialized DistributedCache with %d nodes (namespace=%s)",
            len(nodes), self.key_namespace,
        )

    def _ns(self, key: str) -> str:
        """F9: Apply the key namespace. Empty namespace is a no-op so existing
        on-disk cache entries remain addressable."""
        if self.key_namespace:
            return f"{self.key_namespace}|{key}"
        return key

    def set_key_namespace(self, namespace: Optional[str]) -> None:
        """Update the key namespace after construction.

        Useful when the cluster_id or dataset fingerprint only becomes known
        after backend registration completes.
        """
        self.key_namespace = namespace or None
        logger.info("Cache key namespace set to %r", self.key_namespace)

    def set_local_node(self, local_node: Optional[str]) -> None:
        """F5: set or update the ``local_node`` identity after construction.

        Typically called from :func:`ramjetio.init` once backend registration
        has assigned a routable ``host:port`` to this process's cache server.
        """
        self.local_node = local_node or None
        logger.info("Cache local_node set to %r", self.local_node)

    def _classify_source(self, node: str) -> str:
        """Return ``'local'`` if ``node`` matches ``self.local_node``, else
        ``'peer'``. When ``local_node`` is unset, every hit is labelled
        ``'peer'`` so callers get conservative attribution.
        """
        if self.local_node and node == self.local_node:
            return "local"
        return "peer"

    # ------------------------------------------------------------------
    # F4: ring snapshot / freeze helpers
    # ------------------------------------------------------------------
    def _active_ring(self) -> ConsistentHash:
        """Return the ring that should be used for routing right now.

        If a frozen snapshot is active it wins over ``self.hash_ring``. This
        is the single indirection point used by set/get/delete/exists so that
        ``add_node``/``remove_node`` mutations on the live ring cannot race
        with an in-flight export.
        """
        return self._frozen_ring if self._frozen_ring is not None else self.hash_ring

    def snapshot_ring(self) -> ConsistentHash:
        """Return an immutable copy of the current live hash ring.

        The returned object shares no state with ``self.hash_ring``: its
        ring dict, sorted key list, node list, and internal lock are all
        fresh. Subsequent ``add_node``/``remove_node`` calls on the cache
        do not affect the snapshot.
        """
        snap = ConsistentHash(virtual_nodes=self.hash_ring.virtual_nodes)
        # Take the live lock only long enough to copy internal state.
        with self.hash_ring._lock:
            snap.ring = dict(self.hash_ring.ring)
            snap.sorted_keys = list(self.hash_ring.sorted_keys)
            snap.nodes = list(self.hash_ring.nodes)
        return snap

    def set_ring_snapshot(self, snapshot: ConsistentHash) -> None:
        """Freeze routing on the supplied ring snapshot until cleared.

        While a snapshot is active, set/get/delete/exists route according to
        the snapshot rather than the live ring. ``add_node``/``remove_node``
        still mutate the live ring for subsequent unfrozen operations.
        """
        if snapshot is None:
            raise ValueError("snapshot must be a ConsistentHash instance")
        self._frozen_ring = snapshot
        logger.info(
            "Cache ring frozen on snapshot with %d nodes",
            len(snapshot.get_all_nodes()),
        )

    def clear_ring_snapshot(self) -> None:
        """Release any frozen ring and return to routing on the live ring."""
        if self._frozen_ring is not None:
            logger.info("Cache ring snapshot cleared; routing on live ring")
        self._frozen_ring = None

    @property
    def session(self) -> requests.Session:
        """Get or create a fork-safe requests.Session (one per process)."""
        import os
        pid = os.getpid()
        if self._session is None or self._session_pid != pid:
            self._session = requests.Session()
            # P3.3 Step 3: a larger connection pool lets DataLoader workers
            # (workers>0) saturate the peer node without constant TCP churn.
            # Allow env override for soak tests; defaults scale with cluster
            # size but floor high enough for fork-spawned DataLoader workers.
            pool_size_env = int(os.environ.get("RAMJET_HTTP_POOL_SIZE", "0") or 0)
            pool_maxsize = pool_size_env if pool_size_env > 0 else max(32, self._node_count * 8)
            pool_connections = max(self._node_count, 4)
            adapter = requests.adapters.HTTPAdapter(
                pool_connections=pool_connections,
                pool_maxsize=pool_maxsize,
                max_retries=0,
            )
            self._session.mount('http://', adapter)
            self._session_pid = pid
        return self._session

    def _auth_headers(self) -> Dict[str, str]:
        """F3: Build the auth header dict for peer requests.

        The key is read lazily per call so that an API key set after client
        construction (e.g. by a test harness) is still picked up.
        """
        key = get_api_key()
        return {AUTH_HEADER: key} if key else {}
    
    def _get_url(self, node: str, endpoint: str) -> str:
        """Construct full URL for a cache server endpoint."""
        return f"http://{node}/{endpoint}"
    
    def _request(
        self, 
        method: str, 
        url: str, 
        data: Optional[bytes] = None,
        params: Optional[Dict[str, Any]] = None
    ) -> Optional[requests.Response]:
        """
        Make HTTP request to cache server with retries.
        
        Args:
            method: HTTP method (GET, POST, DELETE, etc.)
            url: Full URL to request
            data: Binary data to send
            params: URL parameters
            
        Returns:
            Response object, or None if all attempts fail
        """
        for attempt in range(self.retry_attempts):
            try:
                headers = self._auth_headers()
                if method == "GET":
                    response = self.session.get(url, params=params, timeout=self.timeout, headers=headers)
                elif method == "HEAD":
                    response = self.session.head(url, params=params, timeout=self.timeout, headers=headers)
                elif method == "POST":
                    response = self.session.post(url, data=data, params=params, timeout=self.timeout, headers=headers)
                elif method == "DELETE":
                    response = self.session.delete(url, params=params, timeout=self.timeout, headers=headers)
                else:
                    raise ValueError(f"Unsupported HTTP method: {method}")
                
                if response.status_code == 200:
                    return response
                elif response.status_code == 404:
                    return None
                else:
                    logger.warning(f"Request failed with status {response.status_code}: {url}")
                    
            except requests.exceptions.RequestException as e:
                logger.warning(f"Request attempt {attempt + 1} failed: {e}")
                if attempt == self.retry_attempts - 1:
                    break

            # Exponential backoff with jitter before next attempt:
            # delay = min(1.0s, 2^attempt * 50ms) * (1 ± 20%)
            # Prevents retry-storm against a flapping peer while keeping
            # the happy-path fast (first retry ~50ms after the failure).
            if attempt < self.retry_attempts - 1:
                base = min(1.0, _BACKOFF_BASE_SECONDS * (2 ** attempt))
                jitter = 1.0 + random.uniform(-_BACKOFF_JITTER, _BACKOFF_JITTER)
                time.sleep(base * jitter)
            logger.error(f"All retry attempts failed for {url}")
        
        return None
    
    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> bool:
        """
        Store a value in the distributed cache.

        Args:
            key: Cache key
            value: Value to cache. Supported types: ``torch.Tensor``,
                ``bytes``, ``str``, and msgpack-safe ``dict`` / ``list`` /
                ``tuple`` / ``numpy.ndarray`` of primitives. Other types
                raise ``TypeError`` — pre-serialize with a safe codec
                before calling.
            ttl: Time-to-live in seconds (optional)

        Returns:
            True if successful, False otherwise
        """
        # F12: Build envelope. Raises TypeError for unsupported types rather
        # than silently falling back to pickle, which would re-open the RCE
        # surface that pickle.loads provided on the reader side.
        try:
            data = _encode_value(value, compress=self.compression)
        except TypeError as e:
            logger.error("DistributedCache.set rejected value: %s", e)
            return False

        # F9: namespace the key for routing, hashing, AND on-wire storage.
        wire_key = self._ns(key)

        # Get target nodes (primary + replicas). F4: honours active ring snapshot.
        target_nodes = self._active_ring().get_nodes(wire_key, self.replication_factor)

        if not target_nodes:
            logger.error("No nodes available for caching")
            return False

        success = False
        params = {"key": wire_key}
        if ttl:
            params["ttl"] = ttl

        # Try to store on all replica nodes
        for node in target_nodes:
            url = self._get_url(node, "set")
            response = self._request("POST", url, data=data, params=params)

            if response:
                success = True
                logger.debug(f"Stored key '{key}' on node {node}")
            else:
                logger.warning(f"Failed to store key '{key}' on node {node}")

        return success
    
    def get(self, key: str) -> Optional[Any]:
        """
        Retrieve a value from the distributed cache.

        Args:
            key: Cache key

        Returns:
            Cached value, or None if not found
        """
        value, _source = self.get_with_source(key)
        return value

    def get_with_source(self, key: str) -> "tuple[Optional[Any], Optional[str]]":
        """F5: retrieve a value *and* report which node served it.

        Returns a tuple ``(value, source)``. ``source`` is ``'local'`` when
        the responding node matches :attr:`local_node`, ``'peer'`` when it
        does not, and ``None`` when the key was not found. The returned
        ``value`` is ``None`` iff ``source`` is ``None``.
        """
        wire_key = self._ns(key)
        # Get target nodes (try replicas if primary fails). F4: honours snapshot.
        target_nodes = self._active_ring().get_nodes(wire_key, self.replication_factor)

        if not target_nodes:
            logger.error("No nodes available for cache lookup")
            return None, None

        # Try each replica node until we find the data
        for node in target_nodes:
            url = self._get_url(node, "get")
            response = self._request("GET", url, params={"key": wire_key})

            if response and response.content:
                try:
                    # F12: strict envelope-only decoding. No pickle fallback.
                    value = _decode_value(response.content)
                    logger.debug(f"Retrieved key '{key}' from node {node}")
                    return value, self._classify_source(node)
                except Exception as e:
                    logger.error(
                        "Failed to decode value for key '%s' from node %s: %s",
                        key, node, e,
                    )

        logger.debug(f"Key '{key}' not found in cache")
        return None, None
    
    def multi_get(self, keys: List[str]) -> Dict[str, Optional[Any]]:
        """Phase Q.5: batched lookup. Groups ``keys`` by primary owner via
        consistent hashing, fires one ``POST /mget`` per owner, and falls
        back to per-key :meth:`get` if the peer doesn't speak the
        ``application/x-ramjet-mget-v1`` protocol (returns 501) or fails.

        Returns a ``{key: value | None}`` dict in input order semantics
        (Python dicts preserve insertion order).

        Gating: this method is *always* available, but the SDK only calls
        it from the dataset hot path when ``RAMJET_MULTIGET=1`` is set on
        the *client* process (so a v0.9.2 SDK paired with a v0.9.1 server
        never sends a request the server can't answer). Per-peer fallback
        on 501 keeps mixed-version clusters honest.
        """
        if not keys:
            return {}
        # Group by primary owner using the active ring snapshot.
        ring = self._active_ring()
        groups: Dict[str, List[str]] = {}
        wire_to_user: Dict[str, str] = {}
        for k in keys:
            wire_key = self._ns(k)
            wire_to_user[wire_key] = k
            owners = ring.get_nodes(wire_key, 1)
            if not owners:
                continue
            groups.setdefault(owners[0], []).append(wire_key)

        results: Dict[str, Optional[Any]] = {k: None for k in keys}
        for node, wire_keys in groups.items():
            url = self._get_url(node, "mget")
            try:
                response = self.session.post(
                    url,
                    json={"keys": wire_keys},
                    timeout=self.timeout,
                    headers=self._auth_headers(),
                )
            except requests.exceptions.RequestException as e:
                logger.warning("multi_get peer %s failed: %s; falling back to /get", node, e)
                for wk in wire_keys:
                    results[wire_to_user[wk]] = self.get(wire_to_user[wk])
                continue

            if response.status_code == 501 or response.status_code == 404:
                # Peer doesn't support /mget — degrade gracefully.
                for wk in wire_keys:
                    results[wire_to_user[wk]] = self.get(wire_to_user[wk])
                continue
            if response.status_code != 200:
                logger.warning(
                    "multi_get peer %s returned %d; falling back",
                    node, response.status_code,
                )
                for wk in wire_keys:
                    results[wire_to_user[wk]] = self.get(wire_to_user[wk])
                continue

            try:
                parsed = _decode_mget_frame(response.content)
            except Exception as e:
                logger.error("multi_get failed to parse frame from %s: %s", node, e)
                for wk in wire_keys:
                    results[wire_to_user[wk]] = self.get(wire_to_user[wk])
                continue

            for wk, raw in parsed.items():
                user_key = wire_to_user.get(wk)
                if user_key is None:
                    continue
                if raw is None:
                    results[user_key] = None
                    continue
                try:
                    results[user_key] = _decode_value(raw)
                except Exception as e:
                    logger.error("multi_get decode failed for %s: %s", user_key, e)
                    results[user_key] = None
        return results

    def delete(self, key: str) -> bool:
        """
        Delete a value from the distributed cache.
        
        Args:
            key: Cache key
            
        Returns:
            True if successful, False otherwise
        """
        wire_key = self._ns(key)
        # Get target nodes (delete from all replicas). F4: honours snapshot.
        target_nodes = self._active_ring().get_nodes(wire_key, self.replication_factor)

        if not target_nodes:
            logger.error("No nodes available for cache deletion")
            return False

        success = False

        for node in target_nodes:
            url = self._get_url(node, "delete")
            response = self._request("DELETE", url, params={"key": wire_key})
            
            if response:
                success = True
                logger.debug(f"Deleted key '{key}' from node {node}")
        
        return success
    
    def exists(self, key: str) -> bool:
        """
        Check if a key exists in the cache using a lightweight HEAD request.
        
        Args:
            key: Cache key
            
        Returns:
            True if key exists, False otherwise
        """
        wire_key = self._ns(key)
        # F4: honours active ring snapshot.
        nodes = self._active_ring().get_nodes(wire_key, count=self.replication_factor)

        for node in nodes:
            url = self._get_url(node, "get")
            response = self._request("HEAD", url, params={"key": wire_key})
            if response is not None:
                return True

        return False
    
    def clear(self) -> bool:
        """
        Clear all data from all cache nodes.
        
        Warning: This operation clears ALL data from the cache cluster.
        
        Returns:
            True if successful on all nodes, False otherwise
        """
        success = True
        
        for node in self.hash_ring.get_all_nodes():
            url = self._get_url(node, "clear")
            response = self._request("POST", url)
            
            if response:
                logger.info(f"Cleared cache on node {node}")
            else:
                logger.error(f"Failed to clear cache on node {node}")
                success = False
        
        return success
    
    def stats(self) -> Dict[str, Any]:
        """
        Get statistics from all cache nodes.
        
        Returns:
            Dictionary with statistics from each node
        """
        stats = {}
        
        for node in self.hash_ring.get_all_nodes():
            url = self._get_url(node, "stats")
            response = self._request("GET", url)
            
            if response:
                try:
                    stats[node] = response.json()
                except Exception as e:
                    logger.error(f"Failed to parse stats from node {node}: {e}")
                    stats[node] = {"error": str(e)}
            else:
                stats[node] = {"error": "Failed to retrieve stats"}
        
        return stats
    
    def add_node(self, node: str) -> None:
        """
        Add a new cache node to the cluster.
        
        Args:
            node: Node address (e.g., "host:port")
        """
        import bisect
        with self._ring_lock:
            self.hash_ring.add_node(node)
            if node not in self.nodes:
                bisect.insort(self.nodes, node)
            self.config_version += 1
            self.ring_churn_total += 1
            self.ring_last_change_ts = time.time()
        logger.info(f"Added node {node} to cache cluster")
    
    def remove_node(self, node: str) -> None:
        """
        Remove a cache node from the cluster.
        
        Args:
            node: Node address to remove
        """
        with self._ring_lock:
            self.hash_ring.remove_node(node)
            if node in self.nodes:
                self.nodes.remove(node)
            self.config_version += 1
            self.ring_churn_total += 1
            self.ring_last_change_ts = time.time()
        logger.info(f"Removed node {node} from cache cluster")

    def replace_nodes(self, nodes: List[str], version: int) -> bool:
        """F13: atomically replace the node ring at a given version.

        Idempotent and version-monotonic: a stale (``version <=
        self.config_version``) call is a no-op, so concurrent publishers
        cannot regress the ring. Used by the topology watcher to apply a
        newer view without racing against the live refresh thread.

        Returns ``True`` if the ring was actually replaced, ``False`` if
        the call was ignored as stale.
        """
        with self._ring_lock:
            if version <= self.config_version:
                return False
            virtual = self.hash_ring.virtual_nodes
            # F-Ring1: enforce deterministic ordering at the point of replacement
            # so two ranks that received the same set in different order still
            # converge to the same self.nodes sequence.
            ordered = sorted(nodes)
            self.nodes = ordered
            self._node_count = len(ordered)
            self.hash_ring = ConsistentHash(nodes=ordered, virtual_nodes=virtual)
            self.config_version = version
            self.ring_churn_total += 1
            self.ring_last_change_ts = time.time()
        logger.info(
            "Ring replaced atomically: %d nodes, version=%d",
            len(nodes), version,
        )
        return True
    
    def diagnostics(self) -> Dict[str, Any]:
        """F-Diag1: client-side ring/topology snapshot for /diagnostics.

        Cheap (just reads counters under the ring lock); safe to call from
        any thread, including the metrics emitter and CLI.
        """
        with self._ring_lock:
            now = time.time()
            since = (now - self.ring_last_change_ts) if self.ring_last_change_ts else None
            return {
                "node_count": len(self.nodes),
                "nodes": list(self.nodes),
                "config_version": self.config_version,
                "ring_churn_total": self.ring_churn_total,
                "ring_last_change_ts": self.ring_last_change_ts,
                "ring_seconds_since_change": since,
                "replication_factor": self.replication_factor,
                "key_namespace": self.key_namespace,
                "local_node": self.local_node,
            }

    def close(self) -> None:
        """Close the HTTP session and release connection pool resources."""
        if self._session:
            self._session.close()
        logger.info("DistributedCache session closed")

    def __repr__(self) -> str:
        """String representation of the cache."""
        return f"DistributedCache(nodes={len(self.nodes)}, replication={self.replication_factor})"
