"""
RAMJET Backend Client

gRPC client for connecting to RAMJET backend.
Handles node registration, heartbeat, and metrics push.

Usage:
    # API key is read from environment: RAMJET_API_KEY
    from ramjetio.backend_client import BackendClient
    
    client = BackendClient(node_port=9000)
    if client.connect():
        client.start_heartbeat(get_metrics_fn)
"""

import os
import grpc
import time
import socket
import threading
import logging
from typing import Optional, Dict, Any, Callable

from ramjetio.config import (
    RAMJET_BACKEND_URL,
    RAMJET_BACKEND_USE_SSL,
    get_api_key,
    get_backend_url,
    get_backend_use_ssl,
    is_configured,
    HEARTBEAT_INTERVAL,
    RECONNECT_INTERVAL,
    MAX_RECONNECT_ATTEMPTS,
)

logger = logging.getLogger(__name__)


def mask_api_key(api_key: str) -> str:
    """Mask API key for safe logging."""
    if not api_key or len(api_key) < 12:
        return "***"
    return f"{api_key[:8]}...{api_key[-4:]}"


class BackendClient:
    """
    Client for communicating with RAMJET backend.
    
    Handles:
    - Node registration on startup
    - Periodic heartbeat with metrics
    - Configuration updates from backend
    
    The backend URL is hardcoded - users only need to set RAMJET_API_KEY.
    """
    
    def __init__(
        self,
        node_port: int = 9000,
        api_key: Optional[str] = None,
    ):
        """
        Initialize backend client.
        
        Args:
            node_port: Port this cache server is running on
            api_key: API key (if not provided, reads from RAMJET_API_KEY env var)
        """
        self.api_key = api_key or get_api_key()
        self.node_port = node_port
        # Use RAMJET_NODE_HOSTNAME env override, or resolve the IP address.
        # socket.gethostname() returns Docker container IDs which aren't
        # resolvable by other machines on the network.
        self.hostname = os.environ.get('RAMJET_NODE_HOSTNAME') or self._resolve_hostname()
        
        # Connection state
        self.node_id: Optional[str] = None
        self.cluster_id: Optional[str] = None
        self.cluster_config: Optional[Dict] = None
        # F-Cfg1: monotonic counter bumped every time the backend pushes a
        # new ClusterConfig (initial register + each ``config_changed=true``
        # heartbeat). Lets the topology watcher on sibling ranks decide
        # whether an update is genuinely newer than what they already have.
        self.cluster_config_version: int = 0
        self._connected = False

        # F-Diag1: heartbeat-loop diagnostics surfaced via /diagnostics so
        # operators can spot a node silently drifting from the backend.
        self.heartbeat_failures_total: int = 0       # cumulative RPC errors
        self.heartbeat_consecutive_failures: int = 0  # streak since last OK
        self.heartbeat_last_success_ts: float = 0.0   # wall-clock seconds
        self.heartbeat_last_error: Optional[str] = None
        self.reconnect_attempts_total: int = 0        # since process start
        
        # Background threads
        self._heartbeat_thread: Optional[threading.Thread] = None
        self._reconnect_thread: Optional[threading.Thread] = None
        self._running = False
        self._get_metrics_fn: Optional[Callable] = None
        
        # Config change callback (called when backend pushes new config)
        self._on_config_changed: Optional[Callable[[Dict[str, Any]], None]] = None

        # Phase 6.B.2: drain callbacks. The CacheServer registers these so the
        # heartbeat loop can (a) report local drain progress in every request,
        # (b) act on a fresh ``drain_command_id`` carried in the response.
        # Decoupled via callbacks because BackendClient lives in a worker
        # thread while the drain coroutine runs on the aiohttp event loop.
        self._drain_status_provider: Optional[Callable[[], Dict[str, Any]]] = None
        self._drain_command_handler: Optional[Callable[[Dict[str, Any]], None]] = None
        # Dedup: backend resends the same id every heartbeat until DB state
        # leaves ``requested``; we only want to launch ``_run_drain`` once.
        self._last_drain_command_id: str = ""

        # gRPC channel and stub
        self._channel: Optional[grpc.Channel] = None
        self._stub = None
        self._pb2 = None
    
    @staticmethod
    def _resolve_hostname() -> str:
        """Resolve a routable hostname/IP for this node."""
        # Try to get external-facing IP by connecting to a remote address
        s = None
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.settimeout(1)
            s.connect(('8.8.8.8', 80))
            return s.getsockname()[0]
        except (socket.error, OSError) as e:
            logger.debug(
                "_resolve_hostname: external probe failed (%s); falling back "
                "to gethostname()", e,
            )
        finally:
            if s is not None:
                try:
                    s.close()
                except OSError:
                    pass
        return socket.gethostname()
        
    @property
    def is_connected(self) -> bool:
        """Check if connected to backend."""
        return self._connected and self.node_id is not None
    
    def connect(self) -> bool:
        """
        Connect to backend and register this node.
        
        Returns:
            True if connected successfully, False otherwise
        """
        if not self.api_key:
            logger.warning(
                "RAMJET API key not configured. "
                "Set RAMJET_API_KEY environment variable. "
                "Metrics will not be sent to backend."
            )
            return False
        
        # API key format: {cluster_name}_{secret}
        if '_' not in self.api_key or len(self.api_key) < 10:
            logger.warning("Invalid API key format. API key should be in format: clustername_secret")
            return False
        
        try:
            # Read env at connect-time (Phase Q.3) so self-hosted operators
            # can point us at their own coordinator without a process restart.
            backend_url = get_backend_url()
            use_ssl = get_backend_use_ssl()
            if backend_url != RAMJET_BACKEND_URL:
                logger.info(
                    f"RAMJET_BACKEND_HOST/PORT override active: using {backend_url} "
                    f"(import-time default was {RAMJET_BACKEND_URL})"
                )

            # Create gRPC channel
            if use_ssl:
                credentials = grpc.ssl_channel_credentials()
                self._channel = grpc.secure_channel(backend_url, credentials)
            else:
                self._channel = grpc.insecure_channel(backend_url)
            
            # Import generated proto (will fail gracefully if not available)
            try:
                from ramjetio.proto import ramjet_pb2, ramjet_pb2_grpc
            except ImportError:
                logger.warning(
                    "Proto files not generated. Run 'python -m grpc_tools.protoc' to generate. "
                    "Backend connection disabled."
                )
                return False
            
            self._stub = ramjet_pb2_grpc.NodeServiceStub(self._channel)
            self._pb2 = ramjet_pb2
            
            # Register node (mask API key in logs)
            logger.info(
                f"Registering node {self.hostname}:{self.node_port} with backend "
                f"(key: {mask_api_key(self.api_key)})..."
            )
            
            response = self._stub.RegisterNode(ramjet_pb2.RegisterNodeRequest(
                api_key=self.api_key,
                hostname=self.hostname,
                port=self.node_port,
                version=self._get_version(),
            ), timeout=10)
            
            self.node_id = response.node_id
            self.cluster_id = response.cluster_id
            self.cluster_config = self._parse_config(response.config)
            self.cluster_config_version += 1
            self._connected = True
            
            logger.info(
                f"✓ Registered with backend: node_id={self.node_id}, "
                f"cluster_id={self.cluster_id}"
            )
            
            return True
            
        except grpc.RpcError as e:
            status_code = e.code()
            if status_code == grpc.StatusCode.UNAUTHENTICATED:
                logger.error(f"Invalid API key ({mask_api_key(self.api_key)}). Please check your RAMJET_API_KEY.")
            elif status_code == grpc.StatusCode.UNAVAILABLE:
                logger.error(f"Backend unavailable at {get_backend_url()}. Will retry...")
            else:
                logger.error(f"Failed to connect to backend: {e.details()}")
            return False
            
        except Exception as e:
            logger.error(f"Unexpected error connecting to backend: {e}")
            return False
    
    def start_heartbeat(
        self, 
        get_metrics_fn: Callable[[], Dict[str, Any]], 
        interval: float = HEARTBEAT_INTERVAL,
        auto_reconnect: bool = True,
        on_config_changed: Optional[Callable[[Dict[str, Any]], None]] = None,
    ) -> None:
        """
        Start background heartbeat thread.
        
        Args:
            get_metrics_fn: Function that returns current metrics dict
            interval: Seconds between heartbeats (default: 2.0)
            auto_reconnect: Whether to automatically reconnect on connection loss
            on_config_changed: Callback invoked when backend pushes new config
        """
        if self._running:
            logger.warning("Heartbeat already running")
            return
        
        self._get_metrics_fn = get_metrics_fn
        self._on_config_changed = on_config_changed
        self._running = True
        
        # Start heartbeat if already connected
        if self.is_connected:
            self._heartbeat_thread = threading.Thread(
                target=self._heartbeat_loop,
                args=(interval,),
                daemon=True,
                name="ramjet-heartbeat"
            )
            self._heartbeat_thread.start()
            logger.info(f"Started heartbeat (interval: {interval}s)")
        
        # Start reconnect loop if enabled
        if auto_reconnect:
            self._reconnect_thread = threading.Thread(
                target=self._reconnect_loop,
                args=(interval,),
                daemon=True,
                name="ramjet-reconnect"
            )
            self._reconnect_thread.start()

    def set_drain_callbacks(
        self,
        status_provider: Optional[Callable[[], Dict[str, Any]]],
        command_handler: Optional[Callable[[Dict[str, Any]], None]],
    ) -> None:
        """Phase 6.B.2: register drain hooks for the heartbeat channel.

        Args:
            status_provider: zero-arg callable returning a dict shaped like
                :py:meth:`CacheServer._drain_snapshot` (keys ``state``,
                ``total``, ``done``, ``errors``, ``last_error``). Invoked
                once per heartbeat to populate ``HeartbeatRequest``. May
                be ``None`` to clear.
            command_handler: callable invoked when the backend response
                carries a fresh ``drain_command_id`` (deduped against the
                last-seen id). Receives a dict with ``command_id``,
                ``mode``, ``future_nodes`` (list[str]), ``self_address``,
                ``rate_limit_mbps``, ``replication_factor``.
        """
        self._drain_status_provider = status_provider
        self._drain_command_handler = command_handler

    def stop(self) -> None:
        """Stop heartbeat and disconnect from backend."""
        self._running = False
        
        if self._channel:
            try:
                if self.is_connected and self._stub and self._pb2:
                    # Send a final heartbeat so dashboard has the latest state
                    # (e.g. is_training=False after end_training())
                    if self._get_metrics_fn:
                        try:
                            metrics = self._get_metrics_fn()
                            self._stub.Heartbeat(self._pb2.HeartbeatRequest(
                                api_key=self.api_key,
                                node_id=self.node_id,
                                metrics=self._pb2.NodeMetrics(
                                    cache_hit_ratio=metrics.get('hit_ratio', 0.0),
                                    cache_size_bytes=int(metrics.get('cache_size_bytes', 0)),
                                    cache_items_count=int(metrics.get('cache_items', 0)),
                                    total_hits=int(metrics.get('hits', 0)),
                                    total_misses=int(metrics.get('misses', 0)),
                                    total_sets=int(metrics.get('sets', 0)),
                                    throughput_mbps=metrics.get('throughput_mbps', 0.0),
                                    avg_latency_ms=metrics.get('avg_latency_ms', 0.0),
                                    p50_latency_ms=metrics.get('p50_latency_ms', 0.0),
                                    p99_latency_ms=metrics.get('p99_latency_ms', 0.0),
                                    disk_total_bytes=int(metrics.get('disk_total', 0)),
                                    disk_used_bytes=int(metrics.get('disk_used', 0)),
                                    disk_free_bytes=int(metrics.get('disk_free', 0)),
                                    ram_total_bytes=int(metrics.get('ram_total', 0)),
                                    ram_used_bytes=int(metrics.get('ram_used', 0)),
                                    ram_free_bytes=int(metrics.get('ram_free', 0)),
                                    gpu_memory_total_bytes=int(metrics.get('gpu_memory_total', 0)),
                                    gpu_memory_used_bytes=int(metrics.get('gpu_memory_used', 0)),
                                    gpu_memory_free_bytes=int(metrics.get('gpu_memory_free', 0)),
                                    gpu_name=metrics.get('gpu_name', ''),
                                    gpu_count=int(metrics.get('gpu_count', 0)),
                                    is_training=bool(metrics.get('is_training', False)),
                                    training_phase=metrics.get('training_phase', 'idle'),
                                    current_epoch=int(metrics.get('current_epoch', 0)),
                                    total_epochs=int(metrics.get('total_epochs', 0)),
                                    current_step=int(metrics.get('current_step', 0)),
                                    total_steps=int(metrics.get('total_steps', 0)),
                                    epoch_progress=float(metrics.get('epoch_progress', 0.0)),
                                    training_loss=float(metrics.get('training_loss', 0.0)),
                                    training_task=metrics.get('training_task', ''),
                                    training_started_at=int(metrics.get('training_started_at', 0)),
                                    samples_per_second=float(metrics.get('samples_per_second', 0.0)),
                                    ddp_world_size=int(metrics.get('ddp_world_size', 0)),
                                    ddp_rank=int(metrics.get('ddp_rank', 0)),
                                    ddp_local_rank=int(metrics.get('ddp_local_rank', 0)),
                                    cache_hits_local=int(metrics.get('cache_hits_local', 0)),
                                    cache_hits_peer=int(metrics.get('cache_hits_peer', 0)),
                                    cache_hits_s3=int(metrics.get('cache_hits_s3', 0)),
                                    singleflight_leaders=int(metrics.get('singleflight_leaders', 0)),
                                    singleflight_waiters=int(metrics.get('singleflight_waiters', 0)),
                                    singleflight_wait_hits=int(metrics.get('singleflight_wait_hits', 0)),
                                    singleflight_wait_timeouts=int(metrics.get('singleflight_wait_timeouts', 0)),
                                    ranks_reporting=int(metrics.get('ranks_reporting', 0)),
                                    ingress_bytes_local=int(metrics.get('ingress_bytes_local', 0)),
                                    ingress_bytes_peer=int(metrics.get('ingress_bytes_peer', 0)),
                                    ingress_bytes_s3=int(metrics.get('ingress_bytes_s3', 0)),
                                ),
                            ), timeout=5)
                        except Exception as e:
                            # Final-metrics push is best-effort during shutdown,
                            # but a silent swallow hid real backend issues.
                            logger.debug(
                                "Final SendHeartbeat on stop() failed: %s: %s",
                                type(e).__name__, e,
                            )
                    
                    # Unregister node
                    self._stub.UnregisterNode(self._pb2.UnregisterNodeRequest(
                        api_key=self.api_key,
                        node_id=self.node_id,
                    ), timeout=5)
                    logger.info("Unregistered from backend")
            except Exception as e:
                # WARN, not silent: a leaked registration leaves the dashboard
                # showing this node as alive long after the process is gone.
                logger.warning(
                    "Failed to cleanly unregister node %s: %s: %s",
                    self.node_id, type(e).__name__, e,
                )
            
            self._channel.close()
            self._channel = None
        
        self._connected = False
        self.node_id = None
        logger.info("Disconnected from backend")
    
    @staticmethod
    def _reconnect_backoff_seconds(attempt: int, jitter_rand: float = 0.5) -> float:
        """F-Recon1: exponential backoff (1s, 2s, 4s, ...) capped at
        ``RECONNECT_INTERVAL``, with ±20% jitter. ``jitter_rand`` is a
        deterministic [0, 1) for unit tests; production uses random.random().
        """
        base = float(min(1.0, RECONNECT_INTERVAL))
        raw = base * (2 ** max(0, attempt - 1))
        capped = min(raw, RECONNECT_INTERVAL)
        jitter = capped * 0.2 * (2 * jitter_rand - 1)
        return max(0.1, capped + jitter)

    def _reconnect_loop(self, heartbeat_interval: float) -> None:
        """Background loop attempting to reconnect if disconnected.

        F-Recon1: exponential backoff with ±20% jitter, capped at
        ``RECONNECT_INTERVAL``. Without this, a fleet of N nodes whose
        backend just rebooted would all hit the backend at exactly the
        same fixed-interval cadence, creating a synchronised retry storm
        that delays recovery. Backoff resets on a successful reconnect.
        """
        import random
        reconnect_attempts = 0

        while self._running:
            # Check if we need to reconnect
            if not self.is_connected and self.api_key:
                reconnect_attempts += 1
                self.reconnect_attempts_total += 1

                # Check max attempts (0 = unlimited)
                if MAX_RECONNECT_ATTEMPTS > 0 and reconnect_attempts > MAX_RECONNECT_ATTEMPTS:
                    logger.error(
                        f"Max reconnect attempts ({MAX_RECONNECT_ATTEMPTS}) reached. Giving up."
                    )
                    break

                logger.info(
                    f"Attempting to reconnect to backend (attempt {reconnect_attempts})..."
                )

                if self.connect():
                    reconnect_attempts = 0
                    # Start heartbeat thread if not running
                    if not self._heartbeat_thread or not self._heartbeat_thread.is_alive():
                        self._heartbeat_thread = threading.Thread(
                            target=self._heartbeat_loop,
                            args=(heartbeat_interval,),
                            daemon=True,
                            name="ramjet-heartbeat",
                        )
                        self._heartbeat_thread.start()
                        logger.info("Heartbeat thread restarted")
                    # On success, the next time we re-enter this branch
                    # (after another disconnect) we want to start fresh:
                    # no need to set sleep here, we just fall through.
                    sleep_s = RECONNECT_INTERVAL
                else:
                    # Exponential backoff: 1s, 2s, 4s, 8s, ... capped at
                    # RECONNECT_INTERVAL. ±20% jitter avoids fleet-wide
                    # synchronisation against a recovering backend.
                    sleep_s = self._reconnect_backoff_seconds(
                        reconnect_attempts, random.random(),
                    )
                    logger.warning(
                        f"Reconnect failed. Will retry in {sleep_s:.1f}s "
                        f"(attempt {reconnect_attempts})..."
                    )
            else:
                sleep_s = RECONNECT_INTERVAL

            # Use the event-style sleep so stop() can wake us promptly,
            # falling back to time.sleep() if the event isn't available.
            time.sleep(sleep_s)
    
    def _heartbeat_loop(self, interval: float) -> None:
        """Background loop sending heartbeats with metrics."""
        consecutive_failures = 0
        max_failures = 5
        
        while self._running and self.is_connected:
            try:
                metrics = self._get_metrics_fn() if self._get_metrics_fn else {}

                # Phase 6.B.2: pull current drain snapshot (may be all-empty
                # for nodes that have never been drained — backend treats
                # ``drain_state=''`` the same as ``'idle'`` and ignores it).
                drain_snap: Dict[str, Any] = {}
                if self._drain_status_provider:
                    try:
                        drain_snap = self._drain_status_provider() or {}
                    except Exception as ds_err:  # noqa: BLE001
                        logger.debug("drain_status_provider error: %s", ds_err)

                response = self._stub.Heartbeat(self._pb2.HeartbeatRequest(
                    api_key=self.api_key,
                    node_id=self.node_id,
                    drain_state=str(drain_snap.get('state', '') or ''),
                    drain_total=int(drain_snap.get('total', 0) or 0),
                    drain_done=int(drain_snap.get('done', 0) or 0),
                    drain_errors=int(drain_snap.get('errors', 0) or 0),
                    drain_last_error=str(drain_snap.get('last_error', '') or '')[:1024],
                    metrics=self._pb2.NodeMetrics(
                        cache_hit_ratio=metrics.get('hit_ratio', 0.0),
                        cache_size_bytes=int(metrics.get('cache_size_bytes', 0)),
                        cache_items_count=int(metrics.get('cache_items', 0)),
                        total_hits=int(metrics.get('hits', 0)),
                        total_misses=int(metrics.get('misses', 0)),
                        total_sets=int(metrics.get('sets', 0)),
                        throughput_mbps=metrics.get('throughput_mbps', 0.0),
                        avg_latency_ms=metrics.get('avg_latency_ms', 0.0),
                        p50_latency_ms=metrics.get('p50_latency_ms', 0.0),
                        p99_latency_ms=metrics.get('p99_latency_ms', 0.0),
                        disk_total_bytes=int(metrics.get('disk_total', 0)),
                        disk_used_bytes=int(metrics.get('disk_used', 0)),
                        disk_free_bytes=int(metrics.get('disk_free', 0)),
                        # Memory metrics
                        ram_total_bytes=int(metrics.get('ram_total', 0)),
                        ram_used_bytes=int(metrics.get('ram_used', 0)),
                        ram_free_bytes=int(metrics.get('ram_free', 0)),
                        # GPU metrics
                        gpu_memory_total_bytes=int(metrics.get('gpu_memory_total', 0)),
                        gpu_memory_used_bytes=int(metrics.get('gpu_memory_used', 0)),
                        gpu_memory_free_bytes=int(metrics.get('gpu_memory_free', 0)),
                        gpu_name=metrics.get('gpu_name', ''),
                        gpu_count=int(metrics.get('gpu_count', 0)),
                        # Training status
                        is_training=bool(metrics.get('is_training', False)),
                        training_phase=metrics.get('training_phase', 'idle'),
                        current_epoch=int(metrics.get('current_epoch', 0)),
                        total_epochs=int(metrics.get('total_epochs', 0)),
                        current_step=int(metrics.get('current_step', 0)),
                        total_steps=int(metrics.get('total_steps', 0)),
                        epoch_progress=float(metrics.get('epoch_progress', 0.0)),
                        training_loss=float(metrics.get('training_loss', 0.0)),
                        training_task=metrics.get('training_task', ''),
                        training_started_at=int(metrics.get('training_started_at', 0)),
                        samples_per_second=float(metrics.get('samples_per_second', 0.0)),
                        ddp_world_size=int(metrics.get('ddp_world_size', 0)),
                        ddp_rank=int(metrics.get('ddp_rank', 0)),
                        ddp_local_rank=int(metrics.get('ddp_local_rank', 0)),
                        cache_hits_local=int(metrics.get('cache_hits_local', 0)),
                        cache_hits_peer=int(metrics.get('cache_hits_peer', 0)),
                        cache_hits_s3=int(metrics.get('cache_hits_s3', 0)),
                        singleflight_leaders=int(metrics.get('singleflight_leaders', 0)),
                        singleflight_waiters=int(metrics.get('singleflight_waiters', 0)),
                        singleflight_wait_hits=int(metrics.get('singleflight_wait_hits', 0)),
                        singleflight_wait_timeouts=int(metrics.get('singleflight_wait_timeouts', 0)),
                        ranks_reporting=int(metrics.get('ranks_reporting', 0)),
                        ingress_bytes_local=int(metrics.get('ingress_bytes_local', 0)),
                        ingress_bytes_peer=int(metrics.get('ingress_bytes_peer', 0)),
                        ingress_bytes_s3=int(metrics.get('ingress_bytes_s3', 0)),
                    ),
                ), timeout=5)
                
                # Reset failure counter on success
                consecutive_failures = 0
                # F-Diag1: success bookkeeping for diagnostics.
                self.heartbeat_consecutive_failures = 0
                self.heartbeat_last_success_ts = time.time()
                self.heartbeat_last_error = None
                
                # Check if config changed
                if response.config_changed and response.config:
                    self.cluster_config = self._parse_config(response.config)
                    self.cluster_config_version += 1
                    logger.info("Received updated cluster config from backend")
                    # Notify callback so running server can hot-reload settings
                    if self._on_config_changed:
                        try:
                            self._on_config_changed(self.cluster_config)
                        except Exception as cb_err:
                            logger.warning(f"Config change callback error: {cb_err}")

                # Phase 6.B.2: drain command dispatch. The backend resends
                # the same ``drain_command_id`` on every heartbeat while DB
                # state == 'requested'; we dedupe via ``_last_drain_command_id``
                # so the local _run_drain task is only launched once.
                cmd_id = getattr(response, 'drain_command_id', '') or ''
                if cmd_id and cmd_id != self._last_drain_command_id and self._drain_command_handler:
                    self._last_drain_command_id = cmd_id
                    cmd = {
                        'command_id': cmd_id,
                        'mode': getattr(response, 'drain_mode', '') or 'drain',
                        'future_nodes': list(getattr(response, 'drain_future_nodes', []) or []),
                        'self_address': getattr(response, 'drain_self_address', '') or '',
                        'rate_limit_mbps': float(getattr(response, 'drain_rate_limit_mbps', 0.0) or 0.0),
                        'replication_factor': int(getattr(response, 'drain_replication_factor', 1) or 1),
                    }
                    try:
                        self._drain_command_handler(cmd)
                    except Exception as dh_err:  # noqa: BLE001
                        logger.warning("drain_command_handler error: %s", dh_err)

                
            except grpc.RpcError as e:
                consecutive_failures += 1
                self.heartbeat_failures_total += 1
                self.heartbeat_consecutive_failures = consecutive_failures
                self.heartbeat_last_error = f"{type(e).__name__}: {e.details()}"
                if consecutive_failures <= 3:
                    logger.warning(f"Heartbeat failed: {e.details()}")
                elif consecutive_failures == max_failures:
                    logger.error(
                        f"Heartbeat failed {max_failures} times. "
                        "Marking as disconnected for reconnect."
                    )
                    self._connected = False
                    break  # Exit loop, reconnect thread will handle reconnection
                    
            except Exception as e:
                consecutive_failures += 1
                self.heartbeat_failures_total += 1
                self.heartbeat_consecutive_failures = consecutive_failures
                self.heartbeat_last_error = f"{type(e).__name__}: {e}"
                logger.warning(f"Heartbeat error: {e}")
            
            time.sleep(interval)
        
        logger.debug("Heartbeat loop ended")
    
    def diagnostics(self) -> Dict[str, Any]:
        """F-Diag1: snapshot of backend-channel health.

        Useful for /diagnostics endpoints and ad-hoc debugging — surfaces
        the heartbeat streak, last error string, and reconnect counter
        without poking gRPC internals.
        """
        now = time.time()
        last_ok = self.heartbeat_last_success_ts
        return {
            "connected": bool(self._connected),
            "node_id": self.node_id,
            "cluster_id": self.cluster_id,
            "cluster_config_version": self.cluster_config_version,
            "heartbeat_failures_total": self.heartbeat_failures_total,
            "heartbeat_consecutive_failures": self.heartbeat_consecutive_failures,
            "heartbeat_last_success_ts": last_ok,
            "heartbeat_seconds_since_success": (now - last_ok) if last_ok else None,
            "heartbeat_last_error": self.heartbeat_last_error,
            "reconnect_attempts_total": self.reconnect_attempts_total,
        }

    def _get_version(self) -> str:
        """Get ramjet package version."""
        try:
            from ramjetio import __version__
            return __version__
        except ImportError as e:
            logger.debug("_get_version: package not importable: %s", e)
            return "unknown"
    
    def _parse_config(self, proto_config) -> Dict[str, Any]:
        """Parse protobuf config to dict."""
        if not proto_config:
            return {}
        
        config = {
            'replication_factor': proto_config.replication_factor,
            'max_cache_size_bytes': proto_config.max_cache_size_bytes,
            'ttl_seconds': proto_config.ttl_seconds,
            'auto_eviction': proto_config.auto_eviction,
        }
        
        # Parse data source if present
        if proto_config.data_source:
            ds = proto_config.data_source
            config['data_source'] = {
                'type': ds.type,
                's3_endpoint': ds.s3_endpoint,
                's3_access_key': ds.s3_access_key,
                's3_secret_key': ds.s3_secret_key,
                's3_bucket': ds.s3_bucket,
                's3_region': ds.s3_region,
                's3_use_ssl': ds.s3_use_ssl,
                's3_path_style': ds.s3_path_style,
                'local_path': ds.local_path,
                'http_url': ds.http_url,
                'http_auth_header': ds.http_auth_header,
                'prefix': ds.prefix,
            }
            logger.debug(f"[BackendClient] Parsed data_source config")
        
        return config
    
    def get_data_source(self) -> Optional[Dict[str, Any]]:
        """
        Get data source configuration from cluster config.
        
        Returns:
            Data source dict with type and connection parameters, or None
        """
        if not self.cluster_config:
            return None
        return self.cluster_config.get('data_source')
    
    def get_cluster_config(self) -> Optional[Dict[str, Any]]:
        """
        Get full cluster configuration.
        
        Returns:
            Cluster config dict, or None if not connected
        """
        return self.cluster_config
    
    def get_cluster_nodes(self, online_only: bool = True) -> list:
        """
        Get list of nodes in the cluster.
        
        Args:
            online_only: If True, return only online nodes (default: True)
            
        Returns:
            List of node dicts with hostname, port, status
        """
        if not self.api_key:
            logger.warning("[BackendClient] No API key, cannot get cluster nodes")
            return []

        # Phase 5.1 fix: never silently re-register from this path. Callers
        # that want a one-shot lookup should use the module-level helper
        # ``get_cluster_nodes`` which creates an explicit transient client.
        # Reusing the existing connected stub avoids a RegisterNode RPC on
        # every refresh tick (was firing every 10s from _node_refresh_loop).
        if self._stub is None or self._pb2 is None:
            logger.debug(
                "[BackendClient] get_cluster_nodes called before connect(); "
                "returning empty list"
            )
            return []

        try:
            request = self._pb2.GetClusterNodesRequest(
                api_key=self.api_key,
                online_only=online_only
            )
            response = self._stub.GetClusterNodes(request, timeout=10)
            
            nodes = []
            for node in response.nodes:
                nodes.append({
                    'id': node.id,
                    'hostname': node.hostname,
                    'port': node.port,
                    'status': 'online' if node.status == 2 else 'offline',
                })
            
            logger.info(f"[BackendClient] Got {len(nodes)} nodes from backend")
            return nodes
            
        except grpc.RpcError as e:
            logger.error(f"[BackendClient] Failed to get cluster nodes: {e.code()} - {e.details()}")
            return []
        except Exception as e:
            logger.error(f"[BackendClient] Error getting cluster nodes: {e}")
            return []


# Data source type constants (match proto enum)
DATA_SOURCE_TYPE_NONE = 0
DATA_SOURCE_TYPE_S3 = 1
DATA_SOURCE_TYPE_LOCAL = 2
DATA_SOURCE_TYPE_HTTP = 3


def get_data_source_config(api_key: Optional[str] = None, node_port: int = 9000) -> Optional[Dict[str, Any]]:
    """
    Convenience function to get data source configuration from backend.
    
    This connects to the backend, gets config, and disconnects.
    Useful for training scripts that just need the data source config.
    
    Args:
        api_key: API key (if not provided, reads from RAMJET_API_KEY env var)
        node_port: Port to use for registration (default: 9000)
        
    Returns:
        Data source config dict, or None if not available
        
    Example:
        >>> from ramjetio.backend_client import get_data_source_config
        >>> ds = get_data_source_config()
        >>> if ds and ds['type'] == DATA_SOURCE_TYPE_HTTP:
        ...     print(f"HTTP URL: {ds['http_url']}")
    """
    client = BackendClient(node_port=node_port, api_key=api_key)
    
    try:
        if not client.connect():
            return None
        
        data_source = client.get_data_source()
        return data_source
    finally:
        # Always clean up — close channel without unregistering node
        try:
            if client._channel:
                client._channel.close()
        except Exception as e:
            logger.debug(
                "Failed to close transient backend channel: %s: %s",
                type(e).__name__, e,
            )


# Singleton instance for convenience
_default_client: Optional[BackendClient] = None


def get_backend_client() -> Optional[BackendClient]:
    """Get the default backend client instance."""
    return _default_client


def init_backend(node_port: int = 9000) -> BackendClient:
    """
    Initialize and connect to backend.
    
    This is a convenience function that creates a singleton client.
    
    Args:
        node_port: Port this cache server is running on
        
    Returns:
        BackendClient instance (may not be connected if API key not set)
    """
    global _default_client
    
    if _default_client is None:
        _default_client = BackendClient(node_port=node_port)
        _default_client.connect()
    
    return _default_client


def get_cluster_nodes(api_key: Optional[str] = None, online_only: bool = True) -> list:
    """
    Convenience function to get list of cluster nodes from backend.
    
    This connects to the backend, gets nodes, and disconnects.
    Useful for training scripts to get cache server addresses.
    
    Args:
        api_key: API key (if not provided, reads from RAMJET_API_KEY env var)
        online_only: If True, return only online nodes (default: True)
        
    Returns:
        List of node dicts with hostname, port, status
        
    Example:
        >>> from ramjetio import get_cluster_nodes
        >>> nodes = get_cluster_nodes()
        >>> cache_servers = [(n['hostname'], n['port']) for n in nodes]
    """
    client = BackendClient(api_key=api_key)
    
    nodes = client.get_cluster_nodes(online_only=online_only)
    
    # Close channel
    if client._channel:
        client._channel.close()
    
    return nodes
