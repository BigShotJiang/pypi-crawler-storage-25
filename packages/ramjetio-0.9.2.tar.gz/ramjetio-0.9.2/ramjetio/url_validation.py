"""
SSRF guards for datasource URLs on the *training-node* side.

The SDK runs inside the user's own training cluster, so the threat
model is narrower than on the backend (no untrusted tenants here).
We still defend against:
  * DNS rebinding to 127.0.0.1 / ::1
  * Accidental fetch of cloud-metadata (169.254.169.254) when a
    misconfigured S3 endpoint resolves to it
  * Misconfigured "0.0.0.0" endpoints

Private networks (10/8, 172.16/12, 192.168/16) are *allowed* by
default because on-prem MinIO and corporate file servers live there.
Set RAMJET_SDK_BLOCK_PRIVATE_DATASOURCES=1 to enable strict mode.
"""

from __future__ import annotations

import ipaddress
import os
import socket
from urllib.parse import urlparse


_METADATA_IPS: frozenset[str] = frozenset({
    "169.254.169.254",
    "fd00:ec2::254",
    "100.100.100.200",
})


class UnsafeURLError(ValueError):
    """Raised when a datasource URL fails SSRF validation."""


def _block_private() -> bool:
    return os.environ.get("RAMJET_SDK_BLOCK_PRIVATE_DATASOURCES", "0") == "1"


def _allow_loopback() -> bool:
    """Test/dev environments need to point at localhost MinIO."""
    return os.environ.get("RAMJET_SDK_ALLOW_LOOPBACK", "0") == "1"


def _resolve_all(hostname: str) -> list[ipaddress._BaseAddress]:
    try:
        infos = socket.getaddrinfo(hostname, None, type=socket.SOCK_STREAM)
    except socket.gaierror:
        return []
    out: list[ipaddress._BaseAddress] = []
    for info in infos:
        try:
            out.append(ipaddress.ip_address(info[4][0]))
        except ValueError:
            continue
    return out


def _classify(ip: ipaddress._BaseAddress) -> str | None:
    if str(ip) in _METADATA_IPS:
        return f"cloud metadata address ({ip})"
    if ip.is_loopback and not _allow_loopback():
        return (
            f"loopback address ({ip}); set "
            "RAMJET_SDK_ALLOW_LOOPBACK=1 for local dev"
        )
    if ip.is_link_local:
        return f"link-local address ({ip})"
    if ip.is_unspecified:
        return f"unspecified address ({ip})"
    if ip.is_multicast:
        return f"multicast address ({ip})"
    if isinstance(ip, ipaddress.IPv4Address) and int(ip) >> 24 == 0:
        return f"this-network address ({ip})"
    if ip.is_private and _block_private():
        return f"private address ({ip}); blocked by SDK strict mode"
    return None


def validate_datasource_url(url: str) -> None:
    """Validate an S3 endpoint or HTTP origin used by SDK clients."""
    if not url or not isinstance(url, str):
        raise UnsafeURLError("URL is empty")

    candidate = url.strip()
    if "://" not in candidate:
        candidate = "https://" + candidate

    parsed = urlparse(candidate)
    scheme = (parsed.scheme or "").lower()
    if scheme not in ("http", "https"):
        raise UnsafeURLError(f"scheme {scheme!r} not allowed")
    host = (parsed.hostname or "").strip()
    if not host:
        raise UnsafeURLError("URL has no host component")
    if any(c in host for c in ("\x00", "\n", "\r", " ")):
        raise UnsafeURLError("host contains forbidden characters")

    try:
        literal = ipaddress.ip_address(host)
    except ValueError:
        literal = None

    if literal is not None:
        reason = _classify(literal)
        if reason:
            raise UnsafeURLError(f"host {host!r} rejected: {reason}")
        return

    resolved = _resolve_all(host)
    if not resolved:
        raise UnsafeURLError(f"host {host!r} did not resolve")
    for ip in resolved:
        reason = _classify(ip)
        if reason:
            raise UnsafeURLError(
                f"host {host!r} resolves to forbidden {reason}"
            )
