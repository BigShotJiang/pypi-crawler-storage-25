"""
RAMJET Ultralytics Integration

Automatically hooks into ultralytics YOLO training to report
progress (epoch, step, loss, samples/sec) to the RAMJET dashboard.

Usage (automatic via ramjetio.train()):
    import ramjetio
    from ultralytics import YOLO

    ramjetio.init()
    model = YOLO('yolov8n.pt')
    ramjetio.train(model, data='data.yaml', epochs=5)

Usage (manual):
    from ramjetio.integrations.ultralytics import attach
    attach(model)
    model.train(data='data.yaml', epochs=5)
"""

import time
import logging

logger = logging.getLogger(__name__)


def attach(model):
    """
    Attach RAMJET progress callbacks to an ultralytics YOLO model.

    Registers callbacks for:
    - on_train_start: marks training phase started
    - on_train_batch_end: reports step progress + loss
    - on_train_epoch_end: reports epoch completion
    - on_train_end: marks training completed

    Only rank 0 reports to the dashboard to avoid duplicate updates
    in DDP multi-GPU training.

    Args:
        model: ultralytics.YOLO instance
    """
    import os
    import ramjetio

    # Only rank 0 reports progress to dashboard
    rank = int(os.environ.get('RANK', 0))
    local_rank = int(os.environ.get('LOCAL_RANK', 0))
    world_size = int(os.environ.get('WORLD_SIZE', 1))
    is_main = (rank == 0)

    _state = {
        'epoch_start_time': 0.0,
        'epoch_samples': 0,
        'batch_step': 0,
    }

    def on_pretrain_routine_end(trainer):
        """Wrap model in DDP if existing process group is active.
        
        ultralytics sets trainer.world_size=1 when device=<int>, so it
        skips DDP wrapping.  We fix that here so gradient all-reduce works.
        
        DDP() is a collective operation — all ranks must call it together.
        We use a barrier to synchronize before wrapping.
        """
        import torch
        import torch.distributed as dist
        
        if not dist.is_initialized() or dist.get_world_size() <= 1:
            return
        
        real_ws = dist.get_world_size()
        from torch.nn.parallel import DistributedDataParallel as DDP
        if trainer.world_size == real_ws or isinstance(trainer.model, DDP):
            return
        
        try:
            logger.info(
                f"RAMJET: on_pretrain_routine_end enter rank={rank} local_rank={local_rank} "
                f"trainer.world_size={trainer.world_size} real_ws={real_ws}"
            )

            # Fix world_size so ultralytics loss scaling is correct
            trainer.world_size = real_ws
            
            # Ensure model is fully on the correct GPU for this rank.
            # ultralytics may leave some buffers on cuda:0 when device!=0.
            device = torch.device(f'cuda:{local_rank}')
            torch.cuda.set_device(local_rank)
            
            # Move ALL parameters and buffers to correct device
            trainer.model = trainer.model.to(device)
            
            # Also move the EMA model — ultralytics creates it on the
            # default CUDA device (cuda:0) which is wrong for rank != 0
            if hasattr(trainer, 'ema') and trainer.ema is not None:
                if hasattr(trainer.ema, 'ema'):
                    trainer.ema.ema = trainer.ema.ema.to(device)
            
            # Fix trainer.device so data loading uses the right GPU
            trainer.device = device

            logger.info(f"RAMJET: rank={rank} wrapping trainer.model in DDP on device={local_rank}")
            # find_unused_parameters=True is required for YOLOv8 heads when
            # workers>0 because the detection heads at different scales may
            # not all receive grads on every step (P3.3 Step 2 guard).
            trainer.model = DDP(
                trainer.model,
                device_ids=[local_rank],
                find_unused_parameters=True,
            )
            logger.info(f"RAMJET: Wrapped model in DDP (world_size={real_ws}, device={local_rank})")
        except Exception as e:
            logger.warning(f"RAMJET: DDP wrapping failed (rank={rank}): {e}", exc_info=True)

    def on_train_start(trainer):
        if not is_main:
            return
        try:
            ramjetio.start_training(
                task=f'YOLO {trainer.args.model or ""}',
                total_epochs=trainer.epochs,
            )
            logger.debug("RAMJET: training started callback fired")
        except Exception as e:
            logger.debug(f"RAMJET on_train_start error: {e}")

    def on_train_epoch_start(trainer):
        _state['epoch_start_time'] = time.time()
        _state['epoch_samples'] = 0
        _state['batch_step'] = 0

    def on_train_batch_end(trainer):
        if not is_main:
            return
        try:
            _state['batch_step'] += 1
            nb = len(trainer.train_loader) if hasattr(trainer, 'train_loader') else 0
            step = _state['batch_step']
            loss_val = None
            if hasattr(trainer, 'tloss') and trainer.tloss is not None:
                import torch
                tl = trainer.tloss
                if isinstance(tl, torch.Tensor):
                    loss_val = tl.mean().item()
                else:
                    loss_val = float(tl)

            # Calculate samples/sec (multiply by world_size for total throughput)
            batch_size = trainer.batch_size if hasattr(trainer, 'batch_size') else 0
            _state['epoch_samples'] += batch_size * world_size
            elapsed = time.time() - _state['epoch_start_time']
            sps = _state['epoch_samples'] / elapsed if elapsed > 0 else 0.0

            ramjetio.update_step(
                epoch=trainer.epoch + 1,
                step=step,
                total_steps=nb,
                loss=loss_val,
                samples_per_second=sps,
            )
        except Exception as e:
            logger.warning(f"RAMJET on_train_batch_end error: {e}")

    def on_train_epoch_end(trainer):
        if not is_main:
            return
        try:
            ramjetio.set_training_status(
                is_training=True,
                phase='training',
                current_epoch=trainer.epoch + 1,
                total_epochs=trainer.epochs,
            )
            logger.debug(f"RAMJET: epoch {trainer.epoch + 1}/{trainer.epochs} done")
        except Exception as e:
            logger.debug(f"RAMJET on_train_epoch_end error: {e}")

    def on_train_end(trainer):
        if not is_main:
            return
        try:
            # Send final epoch/loss before marking completed
            final_epoch = trainer.epoch + 1 if hasattr(trainer, 'epoch') else 0
            total_epochs = trainer.epochs if hasattr(trainer, 'epochs') else 0
            final_loss = None
            if hasattr(trainer, 'tloss') and trainer.tloss is not None:
                import torch
                tl = trainer.tloss
                if isinstance(tl, torch.Tensor):
                    final_loss = tl.mean().item()
                else:
                    final_loss = float(tl)
            
            # Update with final values so dashboard has accurate numbers
            if final_epoch > 0:
                ramjetio.set_training_status(
                    is_training=True,
                    phase='training',
                    current_epoch=final_epoch,
                    total_epochs=total_epochs,
                    loss=final_loss,
                )
            
            ramjetio.end_training()
            logger.info("RAMJET: training completed")
        except Exception as e:
            logger.debug(f"RAMJET on_train_end error: {e}")

    model.add_callback('on_pretrain_routine_end', on_pretrain_routine_end)
    model.add_callback('on_train_start', on_train_start)
    model.add_callback('on_train_epoch_start', on_train_epoch_start)
    model.add_callback('on_train_batch_end', on_train_batch_end)
    model.add_callback('on_train_epoch_end', on_train_epoch_end)
    model.add_callback('on_train_end', on_train_end)


def _attach_freeze_ring_callbacks(model):
    """Freeze ramjet consistent-hash ring for the duration of training (F4).

    Snapshots the ring at ``on_train_start`` and releases the snapshot at
    ``on_train_end``. This prevents mid-run node flap from re-routing
    in-flight cache reads, which would manifest as false cache misses.

    Public-API entry points (``ramjetio.freeze_ring`` / ``unfreeze_ring``)
    are no-ops when the cache is not initialised, so attaching these
    callbacks is always safe.
    """
    import ramjetio

    def on_train_start_freeze(trainer):
        try:
            ramjetio.freeze_ring()
        except Exception as e:
            logger.debug(f"RAMJET freeze_ring error: {e}")

    def on_train_end_unfreeze(trainer):
        try:
            ramjetio.unfreeze_ring()
        except Exception as e:
            logger.debug(f"RAMJET unfreeze_ring error: {e}")

    model.add_callback('on_train_start', on_train_start_freeze)
    model.add_callback('on_train_end', on_train_end_unfreeze)


def _attach_val_suppression_callbacks(model):
    """Suppress Ultralytics validation for streaming training (P3.3 Step 1).

    In the streaming path image files on disk are 32×32 JPEG placeholders
    (the real bytes live in the ramjet cache), so running ``BaseTrainer.validate``
    at end-of-training produces meaningless numbers and adds ~200 s of
    wall time because the val dataloader still does 167 iters × ~1.2 s
    even with ``val=False`` + ``plots=False``.

    We stub ``trainer.validate`` and ``trainer.final_eval`` to no-ops at
    ``on_train_start`` so no epoch-end or post-train val loop runs. This
    is idempotent and only affects the streaming trainer instance.
    """
    def on_train_start_suppress_val(trainer):
        try:
            # Belt-and-braces: flip the flag, stub the methods.
            if hasattr(trainer, "args"):
                trainer.args.val = False
                trainer.args.plots = False
            # validate() is expected to return (metrics_dict, fitness_float).
            trainer.validate = lambda *a, **k: ({}, 0.0)
            # final_eval() is called unconditionally at end of training and
            # internally invokes torch.distributed.gather_object which hangs
            # when DDP ranks exit asymmetrically.
            trainer.final_eval = lambda *a, **k: None
            # validator is consulted by some Ultralytics code paths for
            # best-model tracking; None is tolerated.
            trainer.validator = None
            logger.info("RAMJET streaming_train: validation suppressed")
        except Exception as e:
            logger.debug(f"RAMJET val suppression error: {e}")

    model.add_callback('on_train_start', on_train_start_suppress_val)


def streaming_train(model, data, source=None, samples=None, **train_kwargs):
    """Train a YOLO model with ramjet streaming cache on the data path (P3).

    This is the main Phase-P3 entry point. Unlike :func:`attach` +
    ``export_local()``, it does NOT materialise the dataset to local
    disk up front. Instead, a custom DetectionTrainer is passed to
    ``model.train(trainer=...)`` whose dataset class overrides
    ``load_image()`` to pull raw image bytes from the ramjet distributed
    cache on every call.

    On the cold first epoch, misses fall through to S3 and populate the
    cache (F6 server-side single-flight deduplicates concurrent misses
    on the same key, which is the common case under mosaic / mixup
    augmentation). On subsequent epochs reads are served from local or
    peer cache.

    Parameters
    ----------
    model : ultralytics.YOLO
        Loaded model instance (e.g. ``YOLO('yolov8n.pt')``).
    data : str
        Path to a standard Ultralytics ``data.yaml``. Labels are expected
        on disk; only image bytes are streamed in this first cut.
    source : object, optional
        Object with ``get_bytes(path) -> bytes`` to fetch image bytes on
        cache miss. Defaults to the S3/Local client of the active
        ramjet ``UniversalDataset`` (auto-resolved from
        ``ramjetio.get_data_source()``).
    **train_kwargs
        Forwarded to ``model.train()``. Must not include ``trainer`` —
        that slot is owned by ``streaming_train``.
    """
    import ramjetio
    from ramjetio.integrations.ultralytics_dataset import make_streaming_trainer_class

    if 'trainer' in train_kwargs:
        raise ValueError(
            "streaming_train() owns the 'trainer' kwarg; remove it from "
            "train_kwargs or use attach() + model.train() for a custom trainer."
        )

    cache = getattr(ramjetio, "_global_cache", None) or ramjetio.get_cache()
    if cache is None:
        raise RuntimeError(
            "streaming_train requires ramjetio.init() to have completed and "
            "a distributed cache to be available."
        )

    if source is None:
        # Auto-resolve a default S3/Local client from the configured source.
        try:
            from ramjetio.datasets import UniversalDataset
            ds = UniversalDataset(split='train')
            source = ds._client
            if samples is None:
                samples = list(ds.samples)
        except Exception as e:
            raise RuntimeError(
                "streaming_train could not auto-resolve a data source "
                f"(pass `source=` explicitly): {e}"
            ) from e

    attach(model)
    _attach_freeze_ring_callbacks(model)
    _attach_val_suppression_callbacks(model)

    TrainerCls = make_streaming_trainer_class(
        ramjet_cache=cache, ramjet_source=source, ramjet_samples=samples,
    )
    logger.info(
        "RAMJET streaming_train: using %s with ramjet cache=%s source=%s",
        TrainerCls.__name__, type(cache).__name__, type(source).__name__,
    )
    return model.train(data=data, trainer=TrainerCls, **train_kwargs)

    logger.info("RAMJET: ultralytics callbacks attached")
