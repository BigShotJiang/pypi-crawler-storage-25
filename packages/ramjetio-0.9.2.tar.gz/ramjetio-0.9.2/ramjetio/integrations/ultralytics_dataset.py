"""
RAMJET Streaming Dataset for Ultralytics YOLO (Phase P3)

Replaces the pre-export `export_local()` materialization with a
streaming cache-backed dataset: DataLoader workers fetch image bytes
directly from the ramjet distributed cache on every `load_image` call.

Design (see /memories/session/p3_design.md):

  Layer A: RamjetStreamingYOLODataset(YOLODataset)
      Overrides `load_image(i)` with cache.get -> S3 fallback -> cache.set.
      Mosaic / mixup / letterbox / augment pipeline stays in parent.

  Layer B: RamjetDetectionTrainer(DetectionTrainer)
      Overrides `build_dataset()` to return Layer A.

  Layer C: streaming_train() entry point (see ultralytics.py).

Cache key schema:
    yolo_img_{split}_{idx}   -- raw image bytes (MAGIC_BYTES envelope)

F-flag wiring:
    F4 freeze/unfreeze   : caller (streaming_train) via epoch callbacks
    F5 source attribution: cache.get_with_source() -> _record_cache_path
    F6 single-flight     : server-side, automatic under concurrent misses
    F8 per-rank labels   : _record_cache_path emits labels for heartbeat
    F9 namespace         : inherited via DistributedCache._ns()
    F12 envelope         : MAGIC_BYTES for raw image blobs
"""

from __future__ import annotations

import logging
import os
from typing import Any, List, Optional, Tuple

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Lazy / optional imports
# ---------------------------------------------------------------------------
#
# Ultralytics is an optional dependency of ramjetio. We import lazily so that
# the scaffolding file itself can be imported (and unit-tested) without it.
# When Ultralytics *is* available at call time we subclass the real classes;
# otherwise we raise a clear error from the factory functions.

def _import_ultralytics() -> Tuple[Any, Any]:
    """Return (YOLODataset, DetectionTrainer) or raise ImportError."""
    try:
        from ultralytics.data.dataset import YOLODataset  # type: ignore
        from ultralytics.models.yolo.detect import DetectionTrainer  # type: ignore
    except ImportError as e:
        raise ImportError(
            "ramjetio.integrations.ultralytics_dataset requires the "
            "'ultralytics' package. Install with: pip install ultralytics"
        ) from e
    return YOLODataset, DetectionTrainer


def _assert_ultralytics_compat() -> None:
    """P3.4 Step 7: verify installed Ultralytics is in the tested range.

    We currently target the 8.4.x series. The 8.5 line changed the
    ``BaseDataset.load_image`` signature and buffer-management contract,
    which our subclass mirrors exactly — a silent drift would manifest as
    crashes in mosaic augmentation or hard-to-diagnose data corruption.

    Behaviour:
      * in-range → log once at DEBUG, return silently.
      * out-of-range → log a loud WARNING. We do NOT raise, so users on
        cutting-edge ultralytics can still try (streaming_train will then
        likely fail at runtime with a clearer message). Set
        ``RAMJET_ULTRALYTICS_STRICT=1`` to promote the warning to an
        ``ImportError``.
    """
    import ultralytics  # type: ignore

    version = getattr(ultralytics, "__version__", "0.0.0")
    try:
        major, minor = [int(p) for p in version.split(".")[:2]]
    except Exception:
        major, minor = 0, 0

    supported = (major == 8 and minor == 4)
    if supported:
        logger.debug("ramjetio: verified ultralytics %s is in tested range", version)
        return

    msg = (
        f"ramjetio streaming integration is tested against ultralytics "
        f">=8.4,<8.5 but found {version}. Streaming training may fail "
        f"because load_image()/mosaic buffer contracts may have drifted. "
        f"Pin with: pip install 'ultralytics>=8.4,<8.5'."
    )
    if os.environ.get("RAMJET_ULTRALYTICS_STRICT", "").strip() in ("1", "true", "TRUE"):
        raise ImportError(msg)
    logger.warning(msg)


# ---------------------------------------------------------------------------
# Cache key helpers
# ---------------------------------------------------------------------------

def _ramjet_image_key(split: str, idx: int) -> str:
    """Stable, deterministic cache key for an image index.

    The ``cluster:{id}`` prefix is added automatically by
    ``DistributedCache._ns`` (F9), so callers should not embed it here.
    """
    return f"yolo_img_{split}_{idx}"


# ---------------------------------------------------------------------------
# Streaming load_image implementation (framework-independent, testable)
# ---------------------------------------------------------------------------

def streaming_load_image_bytes(
    cache,
    s3_client,
    image_paths: List[str],
    split: str,
    idx: int,
) -> Tuple[bytes, str]:
    """Fetch raw image bytes for sample ``idx`` via ramjet cache.

    Returns ``(image_bytes, source)`` where source is one of
    ``'cache_local' | 'cache_peer' | 's3' | 'failed'``.

    On cache miss, fetches from S3 and populates the cache (write-through).
    The cache.set call is best-effort — a failed set never breaks training.

    Parameters
    ----------
    cache
        A ``DistributedCache``-shaped object exposing ``get_with_source`` and
        ``set``. If ``None``, the function degrades to pure S3.
    s3_client
        Any object with ``get_bytes(path) -> bytes``. Used on cache miss.
    image_paths
        The list of image source paths indexed by ``idx``.
    split
        Dataset split name ('train' / 'val' / ...), used in cache key.
    idx
        Sample index into ``image_paths``.
    """
    key = _ramjet_image_key(split, idx)

    # --- cache.get_with_source (F5 attribution) -----------------------------
    if cache is not None:
        try:
            get_with_source = getattr(cache, "get_with_source", None)
            if get_with_source is not None:
                value, source = get_with_source(key)
            else:
                # Legacy cache without F5: treat any hit as 'cache_local'.
                value = cache.get(key)
                source = "cache_local" if value is not None else None
        except Exception as e:  # pragma: no cover - defensive
            logger.debug("ramjet cache.get failed for %s: %s", key, e)
            value, source = None, None

        if value is not None and isinstance(value, (bytes, bytearray)):
            return bytes(value), source or "cache_local"

    # --- S3 fallback --------------------------------------------------------
    path = image_paths[idx]
    try:
        data = s3_client.get_bytes(path)
    except Exception as e:
        logger.warning("ramjet streaming: S3 fetch failed for %s: %s", path, e)
        return b"", "failed"

    # --- write-through populate --------------------------------------------
    if cache is not None and data:
        try:
            cache.set(key, data)
        except Exception as e:  # pragma: no cover - defensive
            logger.debug("ramjet cache.set failed for %s: %s", key, e)

    return data, "s3"


# ---------------------------------------------------------------------------
# Factory: subclass Ultralytics YOLODataset at call time
# ---------------------------------------------------------------------------

def make_streaming_dataset_class():
    """Build ``RamjetStreamingYOLODataset`` lazily on first use.

    Returns a new class that subclasses Ultralytics' ``YOLODataset`` and
    overrides ``load_image`` to read image bytes from the ramjet cache.
    The class is built on demand so this module stays importable without
    ultralytics installed.
    """
    _assert_ultralytics_compat()
    YOLODataset, _ = _import_ultralytics()

    # Deferred cv2 import: required only at runtime to decode JPEG bytes.
    import cv2  # type: ignore
    import numpy as np  # type: ignore

    class RamjetStreamingYOLODataset(YOLODataset):  # type: ignore[misc, valid-type]
        """YOLODataset whose image bytes come from ramjet distributed cache.

        Additional ctor kwargs (consumed before delegating to YOLODataset):

        * ``ramjet_cache``  : DistributedCache instance (required).
        * ``ramjet_source`` : object with ``get_bytes(path)`` (S3Client or
          compatible). Required so cache misses can populate from origin.
        * ``ramjet_split``  : string used in cache key; defaults to
          ``self.prefix or 'train'``.
        """

        def __init__(self, *args, **kwargs):
            self._ramjet_cache = kwargs.pop("ramjet_cache", None)
            self._ramjet_source = kwargs.pop("ramjet_source", None)
            # ramjet_samples: list[str] of original S3 keys, indexed by
            # placeholder filename stem (e.g. 'images/000042.jpg' -> idx 42).
            # Required for cold-run S3 fallback; local paths from self.im_files
            # are just placeholders and MinIO rejects them.
            self._ramjet_samples = kwargs.pop("ramjet_samples", None)
            split = kwargs.pop("ramjet_split", None)
            super().__init__(*args, **kwargs)
            # Split name: explicit kwarg wins, else derive from prefix.
            self._ramjet_split = split or getattr(self, "prefix", "train") or "train"
            if self._ramjet_cache is None:
                logger.warning(
                    "RamjetStreamingYOLODataset created without ramjet_cache; "
                    "falling back to on-disk cv2.imread path."
                )

        def _sample_idx_from_im_file(self, i: int) -> int:
            """Parse the 6-digit filename stem from self.im_files[i]."""
            fn = os.path.basename(self.im_files[i])
            stem, _ = os.path.splitext(fn)
            try:
                return int(stem)
            except ValueError:
                return i

        # ------------------------------------------------------------------
        # Core override: replace local-file read with cache-backed fetch.
        # ------------------------------------------------------------------
        def load_image(self, i: int, rect_mode: bool = True):
            """Load image ``i`` from ramjet cache (fallback to parent on failure).

            Return shape matches Ultralytics contract:
                ``(im_uint8_hwc, (h0, w0), (h, w))``
            """
            # Fast path: already in RAM (ultralytics caches decoded images
            # in self.ims after first load when cache='ram').
            im = self.ims[i] if hasattr(self, "ims") else None
            if im is not None:
                return im, self.im_hw0[i], self.im_hw[i]

            if self._ramjet_cache is None or self._ramjet_source is None:
                # No streaming configured -> defer to parent (cv2.imread).
                return super().load_image(i, rect_mode=rect_mode)

            # The i passed by Ultralytics indexes self.im_files (a sorted
            # list of placeholders in our export dir). Our placeholders
            # are named {sample_idx:06d}.jpg so the filename stem is the
            # original sample index.
            sample_idx = self._sample_idx_from_im_file(i)
            s3_paths = self._ramjet_samples or self.im_files

            data, source = streaming_load_image_bytes(
                cache=self._ramjet_cache,
                s3_client=self._ramjet_source,
                image_paths=s3_paths,
                split=self._ramjet_split,
                idx=sample_idx,
            )

            # F8: record source (None / unknown labels ignored by recorder).
            try:
                import ramjetio  # local import to avoid circular at module load
                ramjetio._record_cache_path(source)
            except Exception:  # pragma: no cover
                pass

            if not data:
                # Streaming failed; fall back to disk path if present.
                return super().load_image(i, rect_mode=rect_mode)

            arr = np.frombuffer(data, dtype=np.uint8)
            im = cv2.imdecode(arr, cv2.IMREAD_COLOR)
            if im is None:
                logger.warning(
                    "ramjet streaming: cv2.imdecode returned None for idx=%d", i
                )
                return super().load_image(i, rect_mode=rect_mode)

            h0, w0 = im.shape[:2]

            # Replicate Ultralytics' resize-to-imgsz behaviour.
            r = self.imgsz / max(h0, w0)
            if r != 1:
                interp = (
                    cv2.INTER_LINEAR
                    if (self.augment or r > 1)
                    else cv2.INTER_AREA
                )
                new_w = min(int(w0 * r), self.imgsz) if rect_mode else int(w0 * r)
                new_h = min(int(h0 * r), self.imgsz) if rect_mode else int(h0 * r)
                im = cv2.resize(im, (new_w, new_h), interpolation=interp)
            if im.ndim == 2:
                im = im[..., None]

            # Mirror parent's buffer management for mosaic augmentation.
            if self.augment:
                self.ims[i], self.im_hw0[i], self.im_hw[i] = im, (h0, w0), im.shape[:2]
                self.buffer.append(i)
                if 1 < len(self.buffer) >= self.max_buffer_length:
                    j = self.buffer.pop(0)
                    if self.cache != "ram":
                        self.ims[j], self.im_hw0[j], self.im_hw[j] = None, None, None
            return im, (h0, w0), im.shape[:2]

    return RamjetStreamingYOLODataset


# ---------------------------------------------------------------------------
# Factory: subclass Ultralytics DetectionTrainer at call time
# ---------------------------------------------------------------------------

def make_streaming_trainer_class(ramjet_cache, ramjet_source, ramjet_samples=None):
    """Build a DetectionTrainer subclass bound to the given cache+source.

    The values are captured via class attributes (rather than instance
    kwargs) because Ultralytics constructs the trainer internally from
    ``model.train(trainer=...)`` without forwarding custom kwargs.

    Parameters
    ----------
    ramjet_cache
        DistributedCache instance.
    ramjet_source
        S3Client-compatible object.
    ramjet_samples
        Optional list[str] of original S3 keys indexed by sample index.
        Required for cold-run S3 fallback when placeholder filenames do
        not correspond to real S3 objects.
    """
    _, DetectionTrainer = _import_ultralytics()
    DatasetCls = make_streaming_dataset_class()

    class RamjetDetectionTrainer(DetectionTrainer):  # type: ignore[misc, valid-type]
        """DetectionTrainer that builds RamjetStreamingYOLODataset."""

        _ramjet_cache = ramjet_cache
        _ramjet_source = ramjet_source
        _ramjet_samples = ramjet_samples

        def build_dataset(self, img_path, mode: str = "train", batch: Optional[int] = None):
            # Replicate the stock DetectionTrainer.build_dataset kwargs but
            # route through our streaming dataset class.
            from ultralytics.utils import colorstr  # type: ignore
            gs = (
                max(int(self.model.stride.max() if self.model else 0), 32)
                if hasattr(self, "model") and self.model is not None
                else 32
            )
            return DatasetCls(
                img_path=img_path,
                imgsz=self.args.imgsz,
                batch_size=batch,
                augment=mode == "train",
                hyp=self.args,
                rect=self.args.rect or mode == "val",
                cache=self.args.cache or None,
                single_cls=self.args.single_cls or False,
                stride=int(gs),
                pad=0.0 if mode == "train" else 0.5,
                prefix=colorstr(f"{mode}: "),
                task=self.args.task,
                classes=self.args.classes,
                data=self.data,
                fraction=self.args.fraction if mode == "train" else 1.0,
                ramjet_cache=type(self)._ramjet_cache,
                ramjet_source=type(self)._ramjet_source,
                ramjet_samples=type(self)._ramjet_samples,
                ramjet_split=mode,
            )

    return RamjetDetectionTrainer


__all__ = [
    "streaming_load_image_bytes",
    "make_streaming_dataset_class",
    "make_streaming_trainer_class",
    "_ramjet_image_key",
]
