"""
Consistent hashing implementation for distributed cache.

This module implements a consistent hashing ring that distributes keys
across multiple nodes with minimal redistribution when nodes are added
or removed.
"""

import hashlib
import bisect
import threading
from typing import List, Optional, Dict, Any


class ConsistentHash:
    """
    Consistent hashing ring for distributed caching.
    
    Uses virtual nodes to ensure even distribution of keys across physical nodes.
    When a node is added or removed, only K/N keys need to be remapped (where K
    is the total number of keys and N is the number of nodes).
    
    Args:
        nodes: List of node identifiers (e.g., "host:port")
        virtual_nodes: Number of virtual nodes per physical node (default: 150)
    
    Example:
        >>> ch = ConsistentHash(["node1:9000", "node2:9000", "node3:9000"])
        >>> node = ch.get_node("my_key")
        >>> print(f"Key should be stored on: {node}")
    """
    
    def __init__(self, nodes: Optional[List[str]] = None, virtual_nodes: int = 150):
        """Initialize the consistent hash ring."""
        self.virtual_nodes = virtual_nodes
        self.ring: Dict[int, str] = {}
        self.sorted_keys: List[int] = []
        # F-Ring1: ``self.nodes`` is kept sorted so that every process that
        # observes the same membership produces an identical sequence,
        # independent of insertion order. Routing was already deterministic
        # via MD5; this makes ``get_all_nodes()`` and any downstream
        # iteration deterministic too.
        self.nodes: List[str] = []
        self._lock = threading.Lock()
        
        if nodes:
            for node in sorted(nodes):
                self.add_node(node)
    
    def _hash(self, key: str) -> int:
        """
        Hash a key to a position on the ring.
        
        Uses MD5 for consistent hashing across different platforms.
        
        Args:
            key: String to hash
            
        Returns:
            Integer hash value
        """
        return int(hashlib.md5(key.encode('utf-8')).hexdigest(), 16)
    
    def add_node(self, node: str) -> None:
        """
        Add a node to the hash ring.
        
        Creates multiple virtual nodes for better distribution.
        
        Args:
            node: Node identifier (e.g., "host:port")
        """
        with self._lock:
            if node in self.nodes:
                return
            
            # Keep nodes sorted (see __init__ note).
            bisect.insort(self.nodes, node)
            
            # Add virtual nodes
            for i in range(self.virtual_nodes):
                virtual_key = f"{node}:{i}"
                hash_value = self._hash(virtual_key)
                self.ring[hash_value] = node
                bisect.insort(self.sorted_keys, hash_value)
    
    def remove_node(self, node: str) -> None:
        """
        Remove a node from the hash ring.
        
        Removes all virtual nodes associated with the physical node.
        
        Args:
            node: Node identifier to remove
        """
        with self._lock:
            if node not in self.nodes:
                return
            
            self.nodes.remove(node)
            
            # Remove virtual nodes
            for i in range(self.virtual_nodes):
                virtual_key = f"{node}:{i}"
                hash_value = self._hash(virtual_key)
                
                if hash_value in self.ring:
                    del self.ring[hash_value]
                    self.sorted_keys.remove(hash_value)
    
    def get_node(self, key: str) -> Optional[str]:
        """
        Get the node responsible for a given key.
        
        Finds the first node clockwise from the key's position on the ring.
        
        Args:
            key: Key to look up
            
        Returns:
            Node identifier, or None if no nodes are available
        """
        if not self.ring:
            return None
        
        hash_value = self._hash(key)
        
        # Find the first node clockwise from the hash value
        with self._lock:
            index = bisect.bisect_right(self.sorted_keys, hash_value)
            
            # Wrap around if necessary
            if index == len(self.sorted_keys):
                index = 0
            
            return self.ring[self.sorted_keys[index]]
    
    def get_nodes(self, key: str, count: int = 1) -> List[str]:
        """
        Get multiple nodes for a key (for replication).
        
        Returns consecutive nodes on the ring, skipping duplicates.
        
        Args:
            key: Key to look up
            count: Number of nodes to return
            
        Returns:
            List of node identifiers
        """
        if not self.ring or count < 1:
            return []
        
        hash_value = self._hash(key)
        
        with self._lock:
            index = bisect.bisect_right(self.sorted_keys, hash_value)
            
            nodes = []
            seen = set()
            
            for _ in range(len(self.sorted_keys)):
                if index >= len(self.sorted_keys):
                    index = 0
                
                node = self.ring[self.sorted_keys[index]]
                
                if node not in seen:
                    nodes.append(node)
                    seen.add(node)
                    
                    if len(nodes) >= count:
                        break
                
                index += 1
        
        return nodes
    
    def get_all_nodes(self) -> List[str]:
        """
        Get all physical nodes in the ring.
        
        Returns:
            List of all node identifiers
        """
        return list(self.nodes)
    
    def get_distribution(self, num_keys: int = 10000) -> Dict[str, int]:
        """
        Analyze key distribution across nodes.
        
        Useful for testing and debugging the hash ring balance.
        
        Args:
            num_keys: Number of random keys to test
            
        Returns:
            Dictionary mapping node IDs to key counts
        """
        distribution = {node: 0 for node in self.nodes}
        
        for i in range(num_keys):
            key = f"test_key_{i}"
            node = self.get_node(key)
            if node:
                distribution[node] += 1
        
        return distribution
    
    def __len__(self) -> int:
        """Return the number of physical nodes."""
        return len(self.nodes)
    
    def __repr__(self) -> str:
        """String representation of the hash ring."""
        return f"ConsistentHash(nodes={len(self.nodes)}, virtual_nodes={self.virtual_nodes})"
