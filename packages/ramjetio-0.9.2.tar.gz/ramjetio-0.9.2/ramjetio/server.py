"""
Cache server implementation.

This module provides the HTTP server that handles cache storage and retrieval
on each node in the distributed cache cluster.

Metrics are:
1. Collected via Prometheus counters/gauges (in-memory)
2. Periodically written to a local file (Prometheus format)
3. Periodically pushed to central gRPC/Prometheus server
"""

import os
import logging
import shutil
import asyncio
import struct
import threading
from collections import deque
from pathlib import Path
from typing import Deque, Optional, Dict, Any, List
import time
import socket

from aiohttp import web
import diskcache

from ramjetio.serialization import serialize_object, deserialize_object

# F3: Header name carrying the shared API key on peer-to-peer cache traffic.
# Using a header (not a query param) keeps the key out of access logs.
AUTH_HEADER = "X-RAMJET-API-Key"

# F12: Magic prefixes identifying allowed on-wire payload formats. Any value
# written over the network MUST start with one of these markers; unknown or
# legacy (e.g. raw pickle) payloads are rejected to prevent RCE via
# pickle.loads on a reader node.
ENVELOPE_MAGIC_TENSOR = b"RJBT"  # torch.save / weights_only=True
ENVELOPE_MAGIC_BYTES = b"RJRB"   # raw bytes passthrough
ENVELOPE_MAGIC_STR = b"RJSB"     # UTF-8 string
ENVELOPE_MAGIC_MSGPACK = b"RJMS" # msgpack-encoded structured value
# Phase Q.1 (ramjetio v0.9.2): outer CRC32 envelope wrapper. New writes
# arrive as ``RJV2 + crc32(body) + body`` where body itself starts with one
# of the four legacy magics above. The server only checks the outermost
# magic — full CRC validation happens on the read path inside _decode_value.
ENVELOPE_MAGIC_V2 = b"RJV2"
_ALLOWED_MAGICS = (
    ENVELOPE_MAGIC_TENSOR,
    ENVELOPE_MAGIC_BYTES,
    ENVELOPE_MAGIC_STR,
    ENVELOPE_MAGIC_MSGPACK,
    ENVELOPE_MAGIC_V2,
)

# Prometheus metrics (optional - graceful fallback if not installed)
try:
    from prometheus_client import Counter, Gauge, Histogram, generate_latest
    PROMETHEUS_AVAILABLE = True
except ImportError:
    PROMETHEUS_AVAILABLE = False

logger = logging.getLogger(__name__)

# Initialize Prometheus metrics (if available)
if PROMETHEUS_AVAILABLE:
    # Get node name from environment or hostname
    NODE_NAME = os.environ.get('RAMJET_NODE_NAME', socket.gethostname())
    
    # Counters
    CACHE_HITS = Counter(
        'ramjet_cache_hits_total', 
        'Total number of cache hits',
        ['node']
    )
    CACHE_MISSES = Counter(
        'ramjet_cache_misses_total', 
        'Total number of cache misses',
        ['node']
    )
    CACHE_SETS = Counter(
        'ramjet_cache_sets_total', 
        'Total number of cache sets',
        ['node']
    )
    CACHE_DELETES = Counter(
        'ramjet_cache_deletes_total', 
        'Total number of cache deletes',
        ['node']
    )
    CACHE_ERRORS = Counter(
        'ramjet_cache_errors_total', 
        'Total number of cache errors',
        ['node']
    )
    
    # Gauges
    CACHE_SIZE_BYTES = Gauge(
        'ramjet_cache_size_bytes', 
        'Current cache size in bytes',
        ['node']
    )
    CACHE_FILES_COUNT = Gauge(
        'ramjet_cache_files_count', 
        'Number of files in cache',
        ['node']
    )
    CACHE_HIT_RATIO = Gauge(
        'ramjet_cache_hit_ratio', 
        'Cache hit ratio (hits / total requests)',
        ['node']
    )
    DISK_USAGE_BYTES = Gauge(
        'ramjet_disk_usage_bytes',
        'Disk usage in bytes',
        ['node', 'type']  # type: total, used, free
    )
    
    # Histogram for request latency
    REQUEST_LATENCY = Histogram(
        'ramjet_request_duration_seconds',
        'Request latency in seconds',
        ['node', 'operation'],  # operation: get, set, delete
        buckets=[.001, .005, .01, .025, .05, .1, .25, .5, 1.0, 2.5, 5.0]
    )


class MetricsExporter:
    """
    Background exporter for metrics.
    
    Periodically:
    1. Writes metrics to local file (Prometheus format)
    2. Pushes metrics to central server (gRPC or Prometheus Pushgateway)
    """
    
    def __init__(
        self,
        node_name: str,
        metrics_file: str = "/tmp/ramjet_metrics.prom",
        push_url: Optional[str] = None,
        push_interval: float = 2.0,
        file_interval: float = 2.0,
    ):
        """
        Initialize metrics exporter.
        
        Args:
            node_name: Name of this node (for labeling)
            metrics_file: Path to write Prometheus metrics file
            push_url: URL to push metrics (Prometheus Pushgateway or gRPC backend)
            push_interval: Interval in seconds between pushes to remote
            file_interval: Interval in seconds between file writes
        """
        self.node_name = node_name
        self.metrics_file = Path(metrics_file)
        self.push_url = push_url
        self.push_interval = push_interval
        self.file_interval = file_interval
        
        self._running = False
        self._file_thread: Optional[threading.Thread] = None
        self._push_thread: Optional[threading.Thread] = None
        
        logger.info(f"MetricsExporter initialized: file={metrics_file}, push_url={push_url}")
    
    def start(self) -> None:
        """Start background export threads."""
        if self._running:
            return
        
        self._running = True
        
        # Thread for writing to file
        self._file_thread = threading.Thread(target=self._file_write_loop, daemon=True)
        self._file_thread.start()
        
        # Thread for pushing to remote (if configured)
        if self.push_url:
            self._push_thread = threading.Thread(target=self._push_loop, daemon=True)
            self._push_thread.start()
        
        logger.info("MetricsExporter started")
    
    def stop(self) -> None:
        """Stop background export threads."""
        self._running = False
        logger.info("MetricsExporter stopped")
    
    def _file_write_loop(self) -> None:
        """Background loop to write metrics to file."""
        while self._running:
            try:
                self._write_metrics_to_file()
            except Exception as e:
                logger.warning(f"Failed to write metrics to file: {e}")
            time.sleep(self.file_interval)
    
    def _push_loop(self) -> None:
        """Background loop to push metrics to remote server."""
        while self._running:
            try:
                self._push_metrics()
            except Exception as e:
                logger.warning(f"Failed to push metrics: {e}")
            time.sleep(self.push_interval)
    
    def _write_metrics_to_file(self) -> None:
        """Write current metrics to file in Prometheus format."""
        if not PROMETHEUS_AVAILABLE:
            return
        
        metrics_data = generate_latest()
        
        # Write atomically (write to temp, then rename)
        temp_file = self.metrics_file.with_suffix('.tmp')
        temp_file.write_bytes(metrics_data)
        temp_file.rename(self.metrics_file)
        
        logger.debug(f"Metrics written to {self.metrics_file}")
    
    def _push_metrics(self) -> None:
        """Push metrics to remote server."""
        if not self.push_url:
            return
        
        if not PROMETHEUS_AVAILABLE:
            return
        
        metrics_data = generate_latest()
        
        # Determine push method based on URL
        if self.push_url.startswith("http"):
            self._push_to_pushgateway(metrics_data)
        elif self.push_url.startswith("grpc://"):
            self._push_to_grpc(metrics_data)
        else:
            logger.warning(f"Unknown push URL scheme: {self.push_url}")
    
    def _push_to_pushgateway(self, metrics_data: bytes) -> None:
        """Push metrics to Prometheus Pushgateway."""
        try:
            import urllib.request
            
            # Pushgateway expects POST to /metrics/job/<job_name>/instance/<instance>
            url = f"{self.push_url}/metrics/job/ramjet/instance/{self.node_name}"
            
            req = urllib.request.Request(
                url,
                data=metrics_data,
                method='POST',
                headers={'Content-Type': 'text/plain'}
            )
            
            with urllib.request.urlopen(req, timeout=5) as response:
                if response.status == 200:
                    logger.debug(f"Metrics pushed to {self.push_url}")
                else:
                    logger.warning(f"Pushgateway returned status {response.status}")
                    
        except Exception as e:
            logger.warning(f"Failed to push to Pushgateway: {e}")
    
    def _push_to_grpc(self, metrics_data: bytes) -> None:
        """Push metrics to gRPC backend."""
        # TODO: Implement gRPC push when backend is ready
        # For now, just log
        logger.debug(f"gRPC push not yet implemented (would send {len(metrics_data)} bytes)")


class _OriginCircuit:
    """F-CB1: lightweight circuit breaker for origin (S3/HTTP) outages.

    Watches the rate of single-flight wait timeouts as a proxy for "origin
    is unreachable / very slow". When ``threshold`` consecutive timeouts
    accumulate, the circuit *opens*: subsequent cold-miss GETs fast-fail
    with 503 instead of becoming new leaders that will also time out and
    cascade into more stalled DataLoader workers.

    After ``cooldown_s`` the circuit half-opens — exactly one cold-miss
    GET is allowed through as a probe. A successful leader PUT closes
    the circuit; another timeout re-opens it for the full cooldown.

    Threadsafe (single asyncio loop, but counters are touched from PUT
    handlers too — guarded by a plain Lock).
    """

    def __init__(self, threshold: int, cooldown_s: float) -> None:
        self.threshold = max(1, int(threshold))
        self.cooldown_s = max(0.01, float(cooldown_s))
        self._consecutive_timeouts = 0
        self._opened_at: Optional[float] = None
        self._half_open_inflight = False
        self._lock = threading.Lock()
        # Counters surfaced via /stats
        self.opens = 0
        self.short_circuited = 0  # GETs rejected while open

    def record_success(self) -> None:
        """Close the circuit; reset failure streak."""
        with self._lock:
            self._consecutive_timeouts = 0
            self._opened_at = None
            self._half_open_inflight = False

    def record_timeout(self) -> None:
        """Account for one wait-timeout; trip the breaker if at threshold."""
        with self._lock:
            self._consecutive_timeouts += 1
            was_half_open = (
                self._opened_at is not None
                and time.time() - self._opened_at >= self.cooldown_s
            )
            self._half_open_inflight = False
            if self._opened_at is None and self._consecutive_timeouts >= self.threshold:
                self._opened_at = time.time()
                self.opens += 1
                logger.warning(
                    "OriginCircuit OPEN: %d consecutive wait-timeouts; "
                    "fast-failing cold misses for %.1fs",
                    self._consecutive_timeouts, self.cooldown_s,
                )
            elif was_half_open:
                # Probe failed -> re-arm cooldown.
                self._opened_at = time.time()
                self.opens += 1
                logger.warning(
                    "OriginCircuit RE-OPEN: half-open probe failed; "
                    "fast-failing cold misses for another %.1fs",
                    self.cooldown_s,
                )

    def allow_cold_miss(self) -> bool:
        """Return False if the circuit is open and no probe slot is free."""
        with self._lock:
            if self._opened_at is None:
                return True
            if time.time() - self._opened_at < self.cooldown_s:
                self.short_circuited += 1
                return False
            # Cooldown elapsed -> half-open: allow exactly one probe.
            if self._half_open_inflight:
                self.short_circuited += 1
                return False
            self._half_open_inflight = True
            logger.info("OriginCircuit HALF-OPEN: probing one cold miss")
            return True


class CacheServer:
    """
    HTTP server for distributed cache node.
    
    Each cache server manages local disk storage and responds to HTTP requests
    for caching operations (get, set, delete, etc.).
    
    Automatically connects to RAMJET backend if RAMJET_API_KEY is set.
    
    Args:
        host: Server host address (default: "0.0.0.0")
        port: Server port (default: 9000)
        storage_path: Path to disk storage directory
        max_capacity: Maximum storage capacity in bytes (default: 10TB)
    """
    
    def __init__(
        self,
        host: str = "0.0.0.0",
        port: int = 9000,
        storage_path: str = "/tmp/ramjet_cache",
        max_capacity: int = 0,  # 0 = auto (80% of available disk)
        metrics_file: Optional[str] = None,
        metrics_push_url: Optional[str] = None,
        metrics_push_interval: float = 10.0,
    ):
        """Initialize the cache server."""
        self.host = host
        self.port = port
        self.storage_path = Path(storage_path)
        
        # Create storage directory
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        # Smart default: use 80% of available disk if not specified
        if max_capacity <= 0:
            try:
                usage = shutil.disk_usage(self.storage_path)
                max_capacity = int(usage.free * 0.8)
                logger.info(f"Auto-detected cache size limit: {max_capacity / (1024**3):.1f} GB (80% of free disk)")
            except Exception:
                max_capacity = 100 * 1024 * 1024 * 1024  # Fallback: 100GB
        
        self.max_capacity = max_capacity
        
        # Initialize disk cache
        self.cache = diskcache.Cache(
            str(self.storage_path),
            size_limit=max_capacity,
            eviction_policy='least-recently-used'
        )
        
        # Default TTL (seconds) — 0 means no expiry. Updated from cluster config.
        self._default_ttl: int = 0
        
        # Auto-eviction toggle — if False, diskcache size_limit is set to 0 (unlimited).
        # Updated from cluster config.
        self._auto_eviction: bool = True
        
        # Statistics (protected by _stats_lock for thread-safe access)
        self.stats_data = {
            "hits": 0,
            "misses": 0,
            "sets": 0,
            "deletes": 0,
            "errors": 0,
            "start_time": time.time(),
        }
        self._stats_lock = threading.Lock()
        
        # Throughput tracking with exponential moving average
        self._bytes_transferred = 0  # Total bytes in last interval
        self._bytes_lock = threading.Lock()
        self._last_throughput_calc = time.time()
        self._current_throughput_mbps = 0.0
        self._throughput_ema = 0.0  # Exponential moving average
        self._throughput_alpha = 0.3  # EMA smoothing factor (0.3 = moderate smoothing)
        self._avg_latency_samples: List[float] = []
        self._latency_ema = 0.0  # EMA for latency
        self._latency_lock = threading.Lock()
        # Phase Q.4: sliding window of recent per-request latencies (seconds)
        # used for p50/p99 percentile computation in /stats. Cap is large
        # enough to cover several heartbeat intervals on a chatty cache
        # without blowing memory (1024 floats ≈ 8 KB).
        self._latency_window: Deque[float] = deque(maxlen=1024)
        
        # Initialize metrics exporter (runs in background)
        node_name = os.environ.get('RAMJET_NODE_NAME', f"{socket.gethostname()}:{port}")
        default_metrics_file = f"/tmp/ramjet_metrics_{port}.prom"
        
        self.metrics_exporter = MetricsExporter(
            node_name=node_name,
            metrics_file=metrics_file or default_metrics_file,
            push_url=metrics_push_url or os.environ.get('RAMJET_METRICS_PUSH_URL'),
            push_interval=metrics_push_interval,
        )
        
        # Backend client for registration and heartbeat
        self._backend_client: Optional['BackendClient'] = None

        # F3: capture expected API key once at startup. Empty/None means
        # unauthenticated mode (legacy behaviour) — still supported for
        # local-only dev, but we log a loud warning.
        from ramjetio.config import get_api_key
        self._expected_api_key: Optional[str] = get_api_key()
        if not self._expected_api_key:
            logger.warning(
                "RAMJET_API_KEY not set: cache server will accept unauthenticated "
                "peer requests. This is INSECURE — do not expose port %d outside "
                "the local host without setting RAMJET_API_KEY.",
                self.port,
            )

        # F6: server-side single-flight coalescing of concurrent cold-miss GETs.
        # When a GET for key K misses and no in-flight entry exists, the caller
        # is elected "leader" and receives an immediate 404 — it is expected
        # to do the S3 fetch and PUT the result back. Subsequent GETs for K
        # that arrive while the leader is still fetching wait on an Event,
        # up to ``_inflight_timeout`` seconds. When the leader PUTs, the
        # Event is set and waiters retry the cache read (returning 200 on
        # success). This eliminates duplicate S3 traffic from multiple
        # DataLoader workers racing on the same augmentation source sample.
        self._inflight: Dict[str, "asyncio.Event"] = {}
        self._inflight_lock: Optional[asyncio.Lock] = None  # lazy, needs loop
        # Disabled via env (set RAMJET_SINGLEFLIGHT=0) — legacy fallback.
        self._singleflight_enabled: bool = (
            os.environ.get("RAMJET_SINGLEFLIGHT", "1") != "0"
        )
        # Phase Q.5: opt-in batched GET endpoint (/mget). Off by default in
        # v0.9.2 because the SDK callers don't probe yet; flip to "1" to
        # accept batched lookups from a peer running with RAMJET_MULTIGET=1.
        # Default-on planned for v0.9.3 after Phase D re-run validates the
        # speedup. Flag-name is the same on both sides for symmetry.
        self._multiget_enabled: bool = (
            os.environ.get("RAMJET_MULTIGET", "0") == "1"
        )
        try:
            self._inflight_timeout: float = float(
                os.environ.get("RAMJET_SINGLEFLIGHT_TIMEOUT_MS", "30000")
            ) / 1000.0
        except ValueError:
            self._inflight_timeout = 30.0
        # Counters surfaced via /stats for F5 observability on the server.
        self._inflight_leader_count = 0
        self._inflight_waiter_count = 0
        self._inflight_wait_hits = 0
        self._inflight_wait_timeouts = 0
        # P3.4 Step 8: alert threshold for single-flight wait timeouts.
        # A WARN is logged once per heartbeat whenever the delta since the
        # previous heartbeat exceeds this value. Override via env.
        try:
            self._singleflight_timeout_alert = int(os.environ.get(
                'RAMJET_SINGLEFLIGHT_ALERT', '10'))
        except ValueError:
            self._singleflight_timeout_alert = 10
        self._prev_wait_timeouts = 0

        # F-CB1: origin circuit breaker. Trips on a streak of leader-fetch
        # wait timeouts (origin slow/down) and fast-fails new cold misses
        # so DataLoader workers get a quick 503 instead of stalling 30s.
        try:
            cb_thresh = int(os.environ.get("RAMJET_CIRCUIT_THRESHOLD", "5"))
        except ValueError:
            cb_thresh = 5
        try:
            cb_cooldown = float(os.environ.get("RAMJET_CIRCUIT_COOLDOWN_S", "15"))
        except ValueError:
            cb_cooldown = 15.0
        self._origin_circuit = _OriginCircuit(threshold=cb_thresh, cooldown_s=cb_cooldown)

        # F-Drain1 (Phase 6.A): graceful drain state machine.
        # Operator triggers POST /drain with the future ring (after this node
        # leaves) and we push every locally-resident key to its new owner(s)
        # over HTTP (idempotent /set). Only one drain may run at a time;
        # status is queryable via GET /drain/status.
        self._drain_state: str = "idle"  # idle | running | done | failed | cancelled
        self._drain_total: int = 0
        self._drain_done: int = 0
        self._drain_errors: int = 0
        self._drain_started_ts: Optional[float] = None
        self._drain_completed_ts: Optional[float] = None
        self._drain_last_error: Optional[str] = None
        self._drain_lock = threading.RLock()
        self._drain_task: Optional[asyncio.Task] = None
        self._drain_cancel: Optional[asyncio.Event] = None
        # Phase 6.B.2: aiohttp event loop captured via on_startup; needed to
        # schedule _run_drain from BackendClient's worker thread.
        self._app_loop: Optional[asyncio.AbstractEventLoop] = None

        logger.info(f"Initialized CacheServer at {storage_path} with capacity {max_capacity / (1024**3):.1f} GB")
    
    def _init_backend_connection(self) -> None:
        """Initialize connection to RAMJET backend (if API key is configured)."""
        try:
            from ramjetio.backend_client import BackendClient
            from ramjetio.config import get_api_key
            
            api_key = get_api_key()
            if not api_key:
                logger.info(
                    "RAMJET_API_KEY not set. Running in standalone mode. "
                    "Set RAMJET_API_KEY to enable backend integration."
                )
                return
            
            self._backend_client = BackendClient(node_port=self.port)
            
            if self._backend_client.connect():
                # Apply cluster config (e.g. max_cache_size_bytes) if provided
                cluster_config = self._backend_client.get_cluster_config()
                if cluster_config:
                    self._apply_cluster_config(cluster_config)
                
                # Start heartbeat with metrics
                self._backend_client.start_heartbeat(
                    self._get_metrics_for_backend,
                    on_config_changed=self._apply_cluster_config,
                )
                # Phase 6.B.2: heartbeat now also carries drain progress and
                # delivers drain commands. The handler hops onto the aiohttp
                # event loop via run_coroutine_threadsafe.
                self._backend_client.set_drain_callbacks(
                    status_provider=self._drain_snapshot,
                    command_handler=self._on_drain_command,
                )
                logger.info("✓ Connected to RAMJET backend. Metrics will be reported.")
            else:
                logger.warning("Failed to connect to backend. Running in standalone mode.")
                self._backend_client = None
                
        except ImportError as e:
            logger.debug(f"Backend client not available: {e}")
        except Exception as e:
            logger.warning(f"Failed to initialize backend connection: {e}")
    
    def _apply_cluster_config(self, config: Dict[str, Any]) -> None:
        """Apply cluster configuration from backend to local cache settings."""
        # 1. Max cache size
        max_size = config.get('max_cache_size_bytes', 0)
        if max_size > 0:
            self.cache.reset('size_limit', max_size)
            self.max_capacity = max_size
            logger.info(f"Applied cluster cache size limit: {max_size / (1024**3):.1f} GB")
        
        # 2. Default TTL
        ttl = config.get('ttl_seconds', 0)
        if ttl > 0:
            self._default_ttl = ttl
            logger.info(f"Applied cluster default TTL: {ttl}s")
        
        # 3. Auto-eviction toggle
        auto_eviction = config.get('auto_eviction', True)
        if not auto_eviction and self._auto_eviction:
            # Disable eviction by setting size_limit to 0 (unlimited in diskcache)
            self.cache.reset('size_limit', 0)
            self._auto_eviction = False
            logger.info("Auto-eviction disabled by cluster config (size_limit set to unlimited)")
        elif auto_eviction and not self._auto_eviction:
            # Re-enable eviction with the configured max capacity
            self.cache.reset('size_limit', self.max_capacity)
            self._auto_eviction = True
            logger.info(f"Auto-eviction re-enabled (size_limit: {self.max_capacity / (1024**3):.1f} GB)")

    def _get_metrics_for_backend(self) -> Dict[str, Any]:
        """Get current metrics for backend heartbeat."""
        import shutil
        
        try:
            usage = shutil.disk_usage(self.storage_path)
            with self._stats_lock:
                stats_snapshot = dict(self.stats_data)
            total_requests = stats_snapshot["hits"] + stats_snapshot["misses"]
            hit_ratio = stats_snapshot["hits"] / total_requests if total_requests > 0 else 0.0
            
            # Calculate throughput (MB/s) since last call with EMA smoothing
            now = time.time()
            with self._bytes_lock:
                elapsed = now - self._last_throughput_calc
                if elapsed > 0.5:  # Only update if at least 0.5 sec passed
                    # Calculate instantaneous throughput (bytes to MB)
                    instant_throughput = (self._bytes_transferred / 1_000_000) / elapsed
                    
                    # Apply exponential moving average for smooth transitions
                    if self._bytes_transferred > 0:
                        # New data: blend with current EMA
                        self._throughput_ema = (self._throughput_alpha * instant_throughput + 
                                               (1 - self._throughput_alpha) * self._throughput_ema)
                    else:
                        # No new data: decay slowly (keep 90% of previous value)
                        self._throughput_ema *= 0.95
                        # Floor to zero when negligible (prevents 1.48e-302 artifacts)
                        if self._throughput_ema < 0.001:
                            self._throughput_ema = 0.0
                    
                    self._current_throughput_mbps = self._throughput_ema
                    self._bytes_transferred = 0
                    self._last_throughput_calc = now
            
            # Calculate average latency (ms) with EMA
            with self._latency_lock:
                if self._avg_latency_samples:
                    # Calculate current average from samples
                    current_avg = sum(self._avg_latency_samples) / len(self._avg_latency_samples) * 1000  # to ms
                    # Apply EMA
                    self._latency_ema = 0.3 * current_avg + 0.7 * self._latency_ema
                    # Phase Q.4: feed the same samples into the percentile
                    # window before clearing the avg buffer. The deque has
                    # a maxlen so old observations age out automatically.
                    self._latency_window.extend(self._avg_latency_samples)
                    self._avg_latency_samples = []  # Clear after processing
                else:
                    # No new samples: decay latency toward zero
                    self._latency_ema *= 0.95
                    if self._latency_ema < 0.001:
                        self._latency_ema = 0.0
                # Snapshot the percentile window under the lock so the
                # quantile computation below sees a consistent view even
                # if a request thread appends mid-flight.
                latency_window_snapshot = list(self._latency_window)
            avg_latency = self._latency_ema

            # Phase Q.4: compute p50/p99 in milliseconds. We use
            # nearest-rank (no interpolation) — adequate at 1024 samples
            # and matches what most operators expect in dashboards.
            if latency_window_snapshot:
                sorted_window = sorted(latency_window_snapshot)
                n = len(sorted_window)
                p50_idx = max(0, min(n - 1, int(n * 0.50)))
                p99_idx = max(0, min(n - 1, int(n * 0.99)))
                p50_latency_ms = sorted_window[p50_idx] * 1000.0
                p99_latency_ms = sorted_window[p99_idx] * 1000.0
            else:
                p50_latency_ms = 0.0
                p99_latency_ms = 0.0

            # Report 0 when cache is empty to avoid diskcache SQLite overhead noise
            cache_len = len(self.cache)
            cache_vol = self.cache.volume() if hasattr(self.cache, 'volume') else 0
            cache_size = cache_vol if cache_len > 0 else 0
            
            metrics = {
                "hit_ratio": hit_ratio,
                "cache_size_bytes": cache_size,
                "cache_items": cache_len,
                "hits": stats_snapshot["hits"],
                "misses": stats_snapshot["misses"],
                "sets": stats_snapshot["sets"],
                "throughput_mbps": self._current_throughput_mbps,
                "avg_latency_ms": avg_latency,
                "p50_latency_ms": p50_latency_ms,
                "p99_latency_ms": p99_latency_ms,
                "disk_total": usage.total,
                "disk_used": usage.used,
                "disk_free": usage.free,
                # F8: F6 single-flight observability in heartbeats.
                "singleflight_leaders": self._inflight_leader_count,
                "singleflight_waiters": self._inflight_waiter_count,
                "singleflight_wait_hits": self._inflight_wait_hits,
                "singleflight_wait_timeouts": self._inflight_wait_timeouts,
                # F-CB1: surface circuit-breaker activity to backend metrics.
                "circuit_opens": self._origin_circuit.opens,
                "circuit_short_circuited": self._origin_circuit.short_circuited,
            }

            # P3.4 Step 8: warn on burst of single-flight timeouts.
            delta_timeouts = self._inflight_wait_timeouts - self._prev_wait_timeouts
            if delta_timeouts >= self._singleflight_timeout_alert:
                logger.warning(
                    "singleflight: %d wait-timeouts in last heartbeat "
                    "(total=%d, threshold=%d). S3 path may be stalled.",
                    delta_timeouts,
                    self._inflight_wait_timeouts,
                    self._singleflight_timeout_alert,
                )
            self._prev_wait_timeouts = self._inflight_wait_timeouts
            
            # Add RAM metrics using psutil
            try:
                import psutil
                mem = psutil.virtual_memory()
                metrics["ram_total"] = mem.total
                metrics["ram_used"] = mem.used
                metrics["ram_free"] = mem.available
            except ImportError:
                pass
            
            # Add GPU metrics — try pynvml first (works without torch), fallback to torch.cuda
            gpu_detected = False
            try:
                import pynvml
                pynvml.nvmlInit()
                gpu_count = pynvml.nvmlDeviceGetCount()
                if gpu_count > 0:
                    metrics["gpu_count"] = gpu_count
                    handle = pynvml.nvmlDeviceGetHandleByIndex(0)
                    metrics["gpu_name"] = pynvml.nvmlDeviceGetName(handle)
                    if isinstance(metrics["gpu_name"], bytes):
                        metrics["gpu_name"] = metrics["gpu_name"].decode("utf-8")
                    # Aggregate memory across all GPUs
                    mem_total = 0
                    mem_used = 0
                    for i in range(gpu_count):
                        h = pynvml.nvmlDeviceGetHandleByIndex(i)
                        info = pynvml.nvmlDeviceGetMemoryInfo(h)
                        mem_total += info.total
                        mem_used += info.used
                    metrics["gpu_memory_total"] = mem_total
                    metrics["gpu_memory_used"] = mem_used
                    metrics["gpu_memory_free"] = mem_total - mem_used
                    gpu_detected = True
                pynvml.nvmlShutdown()
            except (ImportError, Exception):
                pass

            if not gpu_detected:
                try:
                    import torch
                    if torch.cuda.is_available():
                        metrics["gpu_count"] = torch.cuda.device_count()
                        if metrics["gpu_count"] > 0:
                            metrics["gpu_name"] = torch.cuda.get_device_name(0)
                            # Aggregate memory across all GPUs
                            mem_total = 0
                            mem_used = 0
                            for i in range(torch.cuda.device_count()):
                                props = torch.cuda.get_device_properties(i)
                                mem_total += props.total_memory
                                mem_used += torch.cuda.memory_reserved(i)
                            metrics["gpu_memory_total"] = mem_total
                            metrics["gpu_memory_used"] = mem_used
                            metrics["gpu_memory_free"] = mem_total - mem_used
                except ImportError:
                    pass
                except Exception as e:
                    logger.debug(f"Failed to get GPU metrics: {e}")
            
            return metrics
        except Exception as e:
            logger.warning(f"Failed to collect metrics: {e}")
            return {}
    
    async def _singleflight_claim(self, key: str) -> "Optional[asyncio.Event]":
        """F6: Atomically elect a leader for an in-flight cold-miss fetch.

        Returns ``None`` if the caller is the leader (no prior entry existed —
        caller must do the S3 fetch + PUT). Returns the ``asyncio.Event`` of
        the existing leader if the caller should wait.
        """
        # asyncio.Lock must be created inside a running loop; do it lazily.
        if self._inflight_lock is None:
            self._inflight_lock = asyncio.Lock()
        async with self._inflight_lock:
            ev = self._inflight.get(key)
            if ev is None:
                self._inflight[key] = asyncio.Event()
                self._inflight_leader_count += 1
                return None
            self._inflight_waiter_count += 1
            return ev

    async def _singleflight_release(self, key: str) -> None:
        """F6: Wake all waiters on ``key`` and drop the in-flight entry.

        Called after a successful SET so subsequent GET waiters can read the
        freshly stored value. Safe to call even if no entry exists.
        """
        if self._inflight_lock is None:
            return
        async with self._inflight_lock:
            ev = self._inflight.pop(key, None)
        if ev is not None:
            ev.set()

    async def handle_get(self, request: web.Request) -> web.Response:
        """Handle GET/HEAD request to retrieve cached data."""
        start_time = time.time()
        key = request.query.get("key")
        
        if not key:
            return web.Response(status=400, text="Missing 'key' parameter")
        
        # HEAD request: just check existence without returning body
        is_head = request.method == "HEAD"
        
        try:
            data = self.cache.get(key)

            if data is None:
                # F6: coalesce concurrent cold-misses so only one caller
                # fetches the origin. HEAD never waits (it's a probe).
                if self._singleflight_enabled and not is_head:
                    # F-CB1: if the origin circuit is open, short-circuit
                    # before electing yet another doomed leader. Returns
                    # 503 so the dataset client can decide to retry later
                    # or skip the sample, instead of stalling 30s on the
                    # wait Event.
                    if not self._origin_circuit.allow_cold_miss():
                        with self._stats_lock:
                            self.stats_data["misses"] += 1
                        latency = time.time() - start_time
                        with self._latency_lock:
                            self._avg_latency_samples.append(latency)
                        if PROMETHEUS_AVAILABLE:
                            CACHE_MISSES.labels(node=NODE_NAME).inc()
                            REQUEST_LATENCY.labels(
                                node=NODE_NAME, operation='get_circuit_open',
                            ).observe(latency)
                        return web.Response(
                            status=503,
                            text="Origin circuit open; retry later",
                            headers={"Retry-After": "5"},
                        )
                    claim = await self._singleflight_claim(key)
                    if claim is not None:
                        # Non-leader: wait for the leader's PUT or timeout.
                        try:
                            await asyncio.wait_for(
                                claim.wait(), timeout=self._inflight_timeout
                            )
                        except asyncio.TimeoutError:
                            self._inflight_wait_timeouts += 1
                            # F-CB1: account this timeout against the origin
                            # circuit so a cluster-wide outage trips the
                            # breaker quickly.
                            self._origin_circuit.record_timeout()
                            # Give up — caller will fetch origin itself.
                            with self._stats_lock:
                                self.stats_data["misses"] += 1
                            latency = time.time() - start_time
                            with self._latency_lock:
                                self._avg_latency_samples.append(latency)
                            if PROMETHEUS_AVAILABLE:
                                CACHE_MISSES.labels(node=NODE_NAME).inc()
                                REQUEST_LATENCY.labels(node=NODE_NAME, operation='get_miss').observe(latency)
                            return web.Response(status=404, text="Key not found")
                        # Leader PUT something — re-read and serve if present.
                        data = self.cache.get(key)
                        if data is not None:
                            self._inflight_wait_hits += 1
                            data_size = len(data) if data else 0
                            with self._bytes_lock:
                                self._bytes_transferred += data_size
                            with self._stats_lock:
                                self.stats_data["hits"] += 1
                            latency = time.time() - start_time
                            with self._latency_lock:
                                self._avg_latency_samples.append(latency)
                            if PROMETHEUS_AVAILABLE:
                                CACHE_HITS.labels(node=NODE_NAME).inc()
                                REQUEST_LATENCY.labels(node=NODE_NAME, operation='get_hit').observe(latency)
                                self._update_hit_ratio()
                            return web.Response(body=data, status=200)
                        # Woken but still missing (leader failed to PUT).
                        # Fall through to the standard miss response.

                with self._stats_lock:
                    self.stats_data["misses"] += 1
                # Track latency
                latency = time.time() - start_time
                with self._latency_lock:
                    self._avg_latency_samples.append(latency)
                if PROMETHEUS_AVAILABLE:
                    CACHE_MISSES.labels(node=NODE_NAME).inc()
                    REQUEST_LATENCY.labels(node=NODE_NAME, operation='get_miss').observe(latency)
                return web.Response(status=404, text="Key not found")
            
            # For HEAD requests, return 200 with Content-Length but no body
            if is_head:
                data_size = len(data) if data else 0
                return web.Response(
                    status=200,
                    headers={"Content-Length": str(data_size)}
                )
            
            # Track throughput (bytes transferred)
            data_size = len(data) if data else 0
            with self._bytes_lock:
                self._bytes_transferred += data_size
            
            with self._stats_lock:
                self.stats_data["hits"] += 1
            # Track latency
            latency = time.time() - start_time
            with self._latency_lock:
                self._avg_latency_samples.append(latency)
            if PROMETHEUS_AVAILABLE:
                CACHE_HITS.labels(node=NODE_NAME).inc()
                REQUEST_LATENCY.labels(node=NODE_NAME, operation='get_hit').observe(latency)
                self._update_hit_ratio()
            return web.Response(body=data, status=200)
            
        except Exception as e:
            with self._stats_lock:
                self.stats_data["errors"] += 1
            if PROMETHEUS_AVAILABLE:
                CACHE_ERRORS.labels(node=NODE_NAME).inc()
            logger.error(f"Error retrieving key '{key}': {e}")
            return web.Response(status=500, text=str(e))
    
    async def handle_mget(self, request: web.Request) -> web.Response:
        """Phase Q.5: batched GET. Accepts ``{"keys": ["k1", ...]}`` JSON
        body and returns a length-prefixed binary frame:

            uint32 N
            repeated:
              uint32 key_len, key utf-8
              uint32 value_len  (0xFFFFFFFF = miss)
              value_len bytes   (already-encoded v2 envelope, like /get)

        Why a binary frame instead of msgpack: stays on the same hot path
        as /get (we just stream the cache.get() bytes through), no double
        encode, and easy to parse from the SDK without a new dep.

        Disabled by default; set ``RAMJET_MULTIGET=1`` on the peer to
        enable. Disabled servers return 501 so the SDK can fall back to
        per-key /get without retry storms.
        """
        if not self._multiget_enabled:
            return web.Response(
                status=501,
                text="multiget disabled; start node with RAMJET_MULTIGET=1",
            )

        start_time = time.time()
        try:
            payload = await request.json()
        except Exception:
            return web.Response(status=400, text="invalid JSON body")
        keys = payload.get("keys") if isinstance(payload, dict) else None
        if not isinstance(keys, list) or not keys:
            return web.Response(status=400, text="missing or empty 'keys' list")
        if len(keys) > 1024:
            # Cap matches our latency-window deque; bigger batches should
            # be split client-side to keep tail latency bounded.
            return web.Response(status=413, text="too many keys (max 1024)")

        out = bytearray()
        out += struct.pack(">I", len(keys))
        hits = 0
        misses = 0
        bytes_served = 0
        for raw_key in keys:
            if not isinstance(raw_key, str):
                return web.Response(status=400, text="keys must be strings")
            key_bytes = raw_key.encode("utf-8")
            out += struct.pack(">I", len(key_bytes))
            out += key_bytes
            data = self.cache.get(raw_key)
            if data is None:
                out += struct.pack(">I", 0xFFFFFFFF)
                misses += 1
            else:
                out += struct.pack(">I", len(data))
                out += data
                hits += 1
                bytes_served += len(data)

        with self._stats_lock:
            self.stats_data["hits"] += hits
            self.stats_data["misses"] += misses
        with self._bytes_lock:
            self._bytes_transferred += bytes_served
        latency = time.time() - start_time
        with self._latency_lock:
            # Charge the whole batch as one observation; tail latency on a
            # batch matters more than per-key fairness for percentiles.
            self._avg_latency_samples.append(latency)
        if PROMETHEUS_AVAILABLE:
            if hits:
                CACHE_HITS.labels(node=NODE_NAME).inc(hits)
            if misses:
                CACHE_MISSES.labels(node=NODE_NAME).inc(misses)
            REQUEST_LATENCY.labels(node=NODE_NAME, operation='mget').observe(latency)
            self._update_hit_ratio()

        return web.Response(
            body=bytes(out),
            status=200,
            content_type="application/x-ramjet-mget-v1",
        )

    async def handle_set(self, request: web.Request) -> web.Response:
        """Handle POST request to store data in cache."""
        start_time = time.time()
        key = request.query.get("key")
        
        if not key:
            return web.Response(status=400, text="Missing 'key' parameter")
        
        try:
            # Read data from request body
            data = await request.read()

            # F12: Reject payloads that don't carry a recognised envelope magic.
            # This blocks pickle-poisoning attacks that rely on a reader
            # falling back to pickle.loads on arbitrary bytes.
            if not data or len(data) < 4 or data[:4] not in _ALLOWED_MAGICS:
                with self._stats_lock:
                    self.stats_data["errors"] += 1
                if PROMETHEUS_AVAILABLE:
                    CACHE_ERRORS.labels(node=NODE_NAME).inc()
                logger.warning(
                    "Rejected /set for key '%s': unknown or missing envelope magic",
                    key,
                )
                return web.Response(status=400, text="unsupported payload format")

            # Track throughput (bytes received)
            data_size = len(data) if data else 0
            with self._bytes_lock:
                self._bytes_transferred += data_size
            
            # Get TTL if provided, otherwise use default from cluster config
            ttl = request.query.get("ttl")
            if ttl:
                expire = int(ttl)
            elif self._default_ttl > 0:
                expire = self._default_ttl
            else:
                expire = None
            
            # Store in cache
            self.cache.set(key, data, expire=expire)

            # F6: wake any GETs waiting on this key from a cold-miss race.
            if self._singleflight_enabled:
                await self._singleflight_release(key)
            # F-CB1: a successful PUT means the origin is responsive again;
            # close the circuit immediately even if it was just half-open.
            self._origin_circuit.record_success()

            with self._stats_lock:
                self.stats_data["sets"] += 1
            # Track latency
            latency = time.time() - start_time
            with self._latency_lock:
                self._avg_latency_samples.append(latency)
            if PROMETHEUS_AVAILABLE:
                CACHE_SETS.labels(node=NODE_NAME).inc()
                REQUEST_LATENCY.labels(node=NODE_NAME, operation='set').observe(latency)
                self._update_cache_metrics()
            return web.Response(status=200, text="OK")
            
        except Exception as e:
            with self._stats_lock:
                self.stats_data["errors"] += 1
            if PROMETHEUS_AVAILABLE:
                CACHE_ERRORS.labels(node=NODE_NAME).inc()
            logger.error(f"Error storing key '{key}': {e}")
            return web.Response(status=500, text=str(e))
    
    async def handle_delete(self, request: web.Request) -> web.Response:
        """Handle DELETE request to remove cached data."""
        start_time = time.time()
        key = request.query.get("key")
        
        if not key:
            return web.Response(status=400, text="Missing 'key' parameter")
        
        try:
            deleted = self.cache.delete(key)
            
            if deleted:
                with self._stats_lock:
                    self.stats_data["deletes"] += 1
                if PROMETHEUS_AVAILABLE:
                    CACHE_DELETES.labels(node=NODE_NAME).inc()
                    REQUEST_LATENCY.labels(node=NODE_NAME, operation='delete').observe(time.time() - start_time)
                    self._update_cache_metrics()
                return web.Response(status=200, text="OK")
            else:
                return web.Response(status=404, text="Key not found")
                
        except Exception as e:
            with self._stats_lock:
                self.stats_data["errors"] += 1
            if PROMETHEUS_AVAILABLE:
                CACHE_ERRORS.labels(node=NODE_NAME).inc()
            logger.error(f"Error deleting key '{key}': {e}")
            return web.Response(status=500, text=str(e))
    
    async def handle_clear(self, request: web.Request) -> web.Response:
        """Handle POST request to clear all cached data."""
        try:
            self.cache.clear()
            return web.Response(status=200, text="OK")
            
        except Exception as e:
            with self._stats_lock:
                self.stats_data["errors"] += 1
            logger.error(f"Error clearing cache: {e}")
            return web.Response(status=500, text=str(e))
    
    async def handle_stats(self, request: web.Request) -> web.Response:
        """Handle GET request to retrieve server statistics."""
        try:
            # Get disk usage
            usage = shutil.disk_usage(self.storage_path)
            
            with self._stats_lock:
                stats_snapshot = dict(self.stats_data)
            
            stats = {
                **stats_snapshot,
                "uptime": time.time() - stats_snapshot["start_time"],
                "items": len(self.cache),
                "cache_size": self.cache.volume() if (hasattr(self.cache, 'volume') and len(self.cache) > 0) else 0,
                "disk_total": usage.total,
                "disk_used": usage.used,
                "disk_free": usage.free,
                "disk_percent": (usage.used / usage.total) * 100,
                # F6: single-flight observability — counts of races caught.
                "singleflight_enabled": self._singleflight_enabled,
                "singleflight_leaders": self._inflight_leader_count,
                "singleflight_waiters": self._inflight_waiter_count,
                "singleflight_wait_hits": self._inflight_wait_hits,
                "singleflight_wait_timeouts": self._inflight_wait_timeouts,
                "singleflight_pending": len(self._inflight),
                # F-CB1: origin circuit breaker counters.
                "circuit_opens": self._origin_circuit.opens,
                "circuit_short_circuited": self._origin_circuit.short_circuited,
                # Phase Q.5: capability bit so a peer SDK can probe whether
                # batched lookups will be honoured before sending /mget.
                "multiget_enabled": self._multiget_enabled,
            }
            
            return web.json_response(stats)
            
        except Exception as e:
            logger.error(f"Error retrieving stats: {e}")
            return web.Response(status=500, text=str(e))
    
    async def handle_health(self, request: web.Request) -> web.Response:
        """Handle GET request for health check."""
        return web.Response(status=200, text="OK")

    async def handle_diagnostics(self, request: web.Request) -> web.Response:
        """F-Diag1: structured operator-facing diagnostics endpoint.

        Bundles server-side counters into intent-named buckets so a UI or
        ``curl | jq`` workflow can spot the failure mode at a glance:

          - ``server`` : uptime, hits/misses, errors
          - ``singleflight`` : leader/waiter counts, wait timeouts
          - ``circuit`` : breaker open count, short-circuited GETs, current state
          - ``backend`` : heartbeat streak, reconnects (if connected)

        All numbers are cumulative since process start unless noted.
        """
        try:
            with self._stats_lock:
                stats_snapshot = dict(self.stats_data)

            now = time.time()
            cb = self._origin_circuit
            with cb._lock:
                if cb._opened_at is None:
                    cb_state = "closed"
                elif now - cb._opened_at < cb.cooldown_s:
                    cb_state = "open"
                else:
                    cb_state = "half-open" if cb._half_open_inflight else "half-open-ready"
                cb_opened_for = (now - cb._opened_at) if cb._opened_at else None

            payload: Dict[str, Any] = {
                "server": {
                    "uptime_s": now - stats_snapshot["start_time"],
                    "hits": stats_snapshot.get("hits", 0),
                    "misses": stats_snapshot.get("misses", 0),
                    "sets": stats_snapshot.get("sets", 0),
                    "errors": stats_snapshot.get("errors", 0),
                    "items": len(self.cache),
                },
                "singleflight": {
                    "enabled": self._singleflight_enabled,
                    "timeout_s": self._inflight_timeout,
                    "leaders": self._inflight_leader_count,
                    "waiters": self._inflight_waiter_count,
                    "wait_hits": self._inflight_wait_hits,
                    "wait_timeouts": self._inflight_wait_timeouts,
                    "pending": len(self._inflight),
                },
                "circuit": {
                    "state": cb_state,
                    "threshold": cb.threshold,
                    "cooldown_s": cb.cooldown_s,
                    "opens_total": cb.opens,
                    "short_circuited_total": cb.short_circuited,
                    "consecutive_timeouts": cb._consecutive_timeouts,
                    "opened_for_s": cb_opened_for,
                },
                "drain": self._drain_snapshot(),
            }

            # Backend channel diagnostics, if registered.
            bc = self._backend_client
            if bc is not None:
                try:
                    payload["backend"] = bc.diagnostics()
                except Exception as e:
                    payload["backend"] = {"error": f"{type(e).__name__}: {e}"}

            return web.json_response(payload)

        except Exception as e:
            logger.error("Error generating diagnostics: %s", e)
            return web.Response(status=500, text=str(e))

    # ------------------------------------------------------------------ #
    # F-Drain1 (Phase 6.A): graceful drain endpoints
    # ------------------------------------------------------------------ #
    def _drain_snapshot(self) -> Dict[str, Any]:
        with self._drain_lock:
            started = self._drain_started_ts
            completed = self._drain_completed_ts
            elapsed: Optional[float]
            if started is None:
                elapsed = None
            elif completed is not None:
                elapsed = completed - started
            else:
                elapsed = time.time() - started
            return {
                "state": self._drain_state,
                "total": self._drain_total,
                "done": self._drain_done,
                "errors": self._drain_errors,
                "started_ts": started,
                "completed_ts": completed,
                "elapsed_s": elapsed,
                "last_error": self._drain_last_error,
            }

    async def handle_drain(self, request: web.Request) -> web.Response:
        """POST /drain — start pushing local keys to their future owners.

        Body JSON:
          - ``future_nodes`` (required, list[str]): the ring this node should
            drain *into* (the cluster MINUS this node, sorted/unsorted both fine).
          - ``self_address`` (required, str): how this node appears on the ring;
            keys whose new owner == self_address are skipped (replication keeps
            them local). Required because ``self.host`` may be 0.0.0.0.
          - ``replication_factor`` (optional, int, default 1): push to top-N
            future owners.
          - ``rate_limit_mbps`` (optional, float, default 0 = unlimited):
            per-second outbound throttle.

        Returns 202 with the initial drain snapshot. 409 if already running.
        Best-effort: errors increment ``errors`` but do not abort the run.
        """
        try:
            body = await request.json()
        except Exception:
            return web.Response(status=400, text="invalid JSON body")

        future_nodes = body.get("future_nodes")
        self_address = body.get("self_address")
        if not isinstance(future_nodes, list) or not all(isinstance(n, str) for n in future_nodes):
            return web.Response(status=400, text="future_nodes must be list[str]")
        if not isinstance(self_address, str) or not self_address:
            return web.Response(status=400, text="self_address required")
        try:
            replication_factor = int(body.get("replication_factor", 1))
        except (TypeError, ValueError):
            return web.Response(status=400, text="replication_factor must be int")
        if replication_factor < 1:
            return web.Response(status=400, text="replication_factor must be >= 1")
        try:
            rate_limit_mbps = float(body.get("rate_limit_mbps", 0) or 0)
        except (TypeError, ValueError):
            return web.Response(status=400, text="rate_limit_mbps must be number")

        with self._drain_lock:
            if self._drain_state == "running":
                return web.json_response(
                    {"error": "drain already running", **self._drain_snapshot()},
                    status=409,
                )
            # Reset counters for a new run.
            self._drain_state = "running"
            self._drain_total = len(self.cache)
            self._drain_done = 0
            self._drain_errors = 0
            self._drain_started_ts = time.time()
            self._drain_completed_ts = None
            self._drain_last_error = None
            self._drain_cancel = asyncio.Event()

        self._drain_task = asyncio.create_task(
            self._run_drain(
                future_nodes=list(future_nodes),
                self_address=self_address,
                replication_factor=replication_factor,
                rate_limit_mbps=rate_limit_mbps,
            )
        )
        return web.json_response(self._drain_snapshot(), status=202)

    async def handle_drain_status(self, request: web.Request) -> web.Response:
        """GET /drain/status — return the current drain snapshot."""
        return web.json_response(self._drain_snapshot())

    async def handle_drain_cancel(self, request: web.Request) -> web.Response:
        """POST /drain/cancel — request graceful cancellation of in-flight drain."""
        with self._drain_lock:
            state = self._drain_state
            cancel = self._drain_cancel
        if state != "running" or cancel is None:
            return web.json_response(
                {"error": "no drain running", **self._drain_snapshot()},
                status=409,
            )
        cancel.set()
        return web.json_response(self._drain_snapshot(), status=202)

    def _on_drain_command(self, cmd: Dict[str, Any]) -> None:
        """Phase 6.B.2: invoked by BackendClient (worker thread) when the
        heartbeat response carries a fresh ``drain_command_id``.

        Two flavours, distinguished by ``mode``:

        * ``mode='cancel'`` — the operator clicked Cancel after the drain
          started. We set the cancel event from the worker thread; the
          drain coroutine picks it up at its next per-key checkpoint.
        * any other mode (``drain``/``rebalance``) — launch ``_run_drain``
          on the aiohttp loop. Idempotent: if a drain is already running
          we no-op (BackendClient already deduped on ``command_id``).
        """
        mode = cmd.get('mode', 'drain')
        if mode == 'cancel':
            with self._drain_lock:
                if self._drain_state == 'running' and self._drain_cancel is not None:
                    # Event.set() is thread-safe; loop wakeup not required
                    # because the drain coroutine polls the event between
                    # per-key pushes.
                    self._drain_cancel.set()
            return

        loop = self._app_loop
        if loop is None or not loop.is_running():
            logger.warning(
                "Received drain command but aiohttp loop is not running yet; "
                "command will be retried on next heartbeat."
            )
            # Reset dedup so the BackendClient retries on the next response.
            try:
                if self._backend_client is not None:
                    self._backend_client._last_drain_command_id = ""
            except AttributeError:
                pass
            return

        future_nodes = list(cmd.get('future_nodes') or [])
        self_address = str(cmd.get('self_address') or '')
        if not future_nodes or not self_address:
            logger.warning(
                "Drain command %s missing future_nodes or self_address; ignoring.",
                cmd.get('command_id'),
            )
            return

        with self._drain_lock:
            if self._drain_state == 'running':
                # Already running (e.g. operator restarted SDK while drain
                # was in flight and the command id has rotated). Skip.
                return

        async def _launch() -> None:
            # Re-check under the loop's thread to avoid double-launch.
            with self._drain_lock:
                if self._drain_state == 'running':
                    return
                self._drain_state = 'running'
                self._drain_total = len(self.cache)
                self._drain_done = 0
                self._drain_errors = 0
                self._drain_started_ts = time.time()
                self._drain_completed_ts = None
                self._drain_last_error = None
                self._drain_cancel = asyncio.Event()
            self._drain_task = asyncio.create_task(
                self._run_drain(
                    future_nodes=future_nodes,
                    self_address=self_address,
                    replication_factor=int(cmd.get('replication_factor') or 1),
                    rate_limit_mbps=float(cmd.get('rate_limit_mbps') or 0.0),
                )
            )

        asyncio.run_coroutine_threadsafe(_launch(), loop)

    async def _run_drain(
        self,
        future_nodes: List[str],
        self_address: str,
        replication_factor: int,
        rate_limit_mbps: float,
    ) -> None:
        """Background task: iterate keys and push each to its future owner(s)."""
        import aiohttp
        from ramjetio.consistent_hash import ConsistentHash

        cancel = self._drain_cancel
        try:
            if not future_nodes:
                # Nothing to push to — keys would be orphaned. Surface as error.
                with self._drain_lock:
                    self._drain_state = "failed"
                    self._drain_last_error = "future_nodes is empty"
                    self._drain_completed_ts = time.time()
                return

            ring = ConsistentHash(future_nodes)
            # Snapshot keys up-front; new sets after this point stay on this node
            # and are the operator's responsibility (caller usually pauses writes).
            try:
                keys = list(self.cache.iterkeys())
            except Exception as e:
                with self._drain_lock:
                    self._drain_state = "failed"
                    self._drain_last_error = f"iterkeys failed: {e}"
                    self._drain_completed_ts = time.time()
                return

            with self._drain_lock:
                self._drain_total = len(keys)

            headers = {}
            if self._expected_api_key:
                headers[AUTH_HEADER] = self._expected_api_key

            # Throttling: bytes/window. rate_limit_mbps == 0 → unlimited.
            window_start = time.monotonic()
            window_bytes = 0
            limit_bytes_per_s = int(rate_limit_mbps * 1024 * 1024) if rate_limit_mbps > 0 else 0

            timeout = aiohttp.ClientTimeout(total=30)
            async with aiohttp.ClientSession(timeout=timeout, headers=headers) as session:
                for key in keys:
                    if cancel is not None and cancel.is_set():
                        with self._drain_lock:
                            self._drain_state = "cancelled"
                            self._drain_completed_ts = time.time()
                        return

                    targets = ring.get_nodes(key, replication_factor)
                    targets = [t for t in targets if t != self_address]
                    if not targets:
                        # Key stays on this node (replication keeps it local).
                        with self._drain_lock:
                            self._drain_done += 1
                        continue

                    try:
                        data = self.cache.get(key, default=None, read=False)
                    except Exception as e:
                        with self._drain_lock:
                            self._drain_errors += 1
                            self._drain_done += 1
                            self._drain_last_error = f"read {key!r}: {e}"
                        continue

                    if data is None or not isinstance(data, (bytes, bytearray)):
                        # Already gone (TTL) or non-bytes legacy entry; skip.
                        with self._drain_lock:
                            self._drain_done += 1
                        continue

                    pushed_any = False
                    for target in targets:
                        if cancel is not None and cancel.is_set():
                            break
                        url = f"http://{target}/set"
                        try:
                            async with session.post(url, params={"key": key}, data=bytes(data)) as resp:
                                if resp.status == 200:
                                    pushed_any = True
                                else:
                                    with self._drain_lock:
                                        self._drain_errors += 1
                                        self._drain_last_error = (
                                            f"push {key!r}->{target}: HTTP {resp.status}"
                                        )
                        except Exception as e:
                            with self._drain_lock:
                                self._drain_errors += 1
                                self._drain_last_error = f"push {key!r}->{target}: {e}"

                        # Throttle.
                        if limit_bytes_per_s > 0:
                            window_bytes += len(data)
                            now = time.monotonic()
                            elapsed = now - window_start
                            allowed = limit_bytes_per_s * max(elapsed, 1e-3)
                            if window_bytes > allowed:
                                sleep_s = (window_bytes - allowed) / limit_bytes_per_s
                                await asyncio.sleep(min(sleep_s, 1.0))
                            if elapsed >= 1.0:
                                window_start = now
                                window_bytes = 0

                    with self._drain_lock:
                        self._drain_done += 1
                        if not pushed_any and replication_factor >= 1:
                            # All target pushes failed for this key; already
                            # counted in errors per-target above.
                            pass

            with self._drain_lock:
                if self._drain_state == "running":
                    self._drain_state = "done"
                    self._drain_completed_ts = time.time()
        except asyncio.CancelledError:
            with self._drain_lock:
                self._drain_state = "cancelled"
                self._drain_completed_ts = time.time()
            raise
        except Exception as e:
            logger.exception("drain task crashed")
            with self._drain_lock:
                self._drain_state = "failed"
                self._drain_last_error = f"{type(e).__name__}: {e}"
                self._drain_completed_ts = time.time()

    async def handle_metrics(self, request: web.Request) -> web.Response:
        """Handle GET request for Prometheus metrics."""
        if not PROMETHEUS_AVAILABLE:
            return web.Response(
                status=501, 
                text="Prometheus client not installed. Run: pip install prometheus-client"
            )
        
        try:
            # Update metrics before serving
            self._update_cache_metrics()
            self._update_hit_ratio()
            
            # Generate Prometheus format output
            output = generate_latest()
            # Use plain content type (aiohttp doesn't like charset in content_type)
            return web.Response(
                body=output,
                content_type="text/plain; version=0.0.4"
            )
        except Exception as e:
            logger.error(f"Error generating metrics: {e}")
            return web.Response(status=500, text=str(e))
    
    def _update_cache_metrics(self) -> None:
        """Update cache size and file count metrics."""
        if not PROMETHEUS_AVAILABLE:
            return
        
        try:
            # Get cache volume (total size of cached data)
            cache_volume = self.cache.volume()
            CACHE_SIZE_BYTES.labels(node=NODE_NAME).set(cache_volume)
            
            # Get number of items in cache
            cache_count = len(self.cache)
            CACHE_FILES_COUNT.labels(node=NODE_NAME).set(cache_count)
            
            # Update disk usage
            usage = shutil.disk_usage(self.storage_path)
            DISK_USAGE_BYTES.labels(node=NODE_NAME, type='total').set(usage.total)
            DISK_USAGE_BYTES.labels(node=NODE_NAME, type='used').set(usage.used)
            DISK_USAGE_BYTES.labels(node=NODE_NAME, type='free').set(usage.free)
            
        except Exception as e:
            logger.warning(f"Failed to update cache metrics: {e}")
    
    def _update_hit_ratio(self) -> None:
        """Update cache hit ratio metric."""
        if not PROMETHEUS_AVAILABLE:
            return
        
        try:
            with self._stats_lock:
                total = self.stats_data["hits"] + self.stats_data["misses"]
                hits = self.stats_data["hits"]
            if total > 0:
                ratio = hits / total
                CACHE_HIT_RATIO.labels(node=NODE_NAME).set(ratio)
        except Exception as e:
            logger.warning(f"Failed to update hit ratio: {e}")
    
    def create_app(self) -> web.Application:
        """Create the aiohttp web application."""
        # F3: Auth middleware — require X-RAMJET-API-Key on all cache data
        # endpoints. /health and /metrics stay open so that infra probes
        # (k8s liveness, Prometheus scrape) work without secrets.
        expected_key = self._expected_api_key
        open_paths = {"/health", "/metrics"}

        @web.middleware
        async def auth_middleware(request: web.Request, handler):
            if expected_key and request.path not in open_paths:
                presented = request.headers.get(AUTH_HEADER)
                if not presented or presented != expected_key:
                    return web.Response(status=401, text="unauthorized")
            return await handler(request)

        # Set max request size to 500MB to handle large tensors/checkpoints
        app = web.Application(
            client_max_size=500 * 1024 * 1024,
            middlewares=[auth_middleware],
        )

        # Phase 6.B.2: capture the running event loop so BackendClient
        # (worker thread) can schedule drain coroutines via
        # run_coroutine_threadsafe. Done as on_startup so it works for both
        # web.run_app() and aiohttp test harnesses.
        async def _capture_loop(_app: web.Application) -> None:
            self._app_loop = asyncio.get_running_loop()

        app.on_startup.append(_capture_loop)

        # Add routes (add_get auto-registers HEAD as well)
        app.router.add_get("/get", self.handle_get)
        app.router.add_post("/mget", self.handle_mget)
        app.router.add_post("/set", self.handle_set)
        app.router.add_delete("/delete", self.handle_delete)
        app.router.add_post("/clear", self.handle_clear)
        app.router.add_get("/stats", self.handle_stats)
        app.router.add_get("/health", self.handle_health)
        app.router.add_get("/metrics", self.handle_metrics)
        app.router.add_get("/diagnostics", self.handle_diagnostics)
        app.router.add_post("/drain", self.handle_drain)
        app.router.add_get("/drain/status", self.handle_drain_status)
        app.router.add_post("/drain/cancel", self.handle_drain_cancel)

        return app
    
    def run(self) -> None:
        """Start the cache server."""
        app = self.create_app()
        
        # Start metrics exporter (background threads)
        self.metrics_exporter.start()
        
        # Connect to backend (if RAMJET_API_KEY is set)
        self._init_backend_connection()
        
        logger.info(f"Starting cache server on {self.host}:{self.port}")
        web.run_app(app, host=self.host, port=self.port)
    
    def close(self) -> None:
        """Clean up resources."""
        self.metrics_exporter.stop()
        
        # Disconnect from backend
        if self._backend_client:
            self._backend_client.stop()
        
        self.cache.close()
