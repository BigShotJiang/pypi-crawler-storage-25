"""
Example: ImageNet training with a stock PyTorch DataLoader + RAMJET cache.

This is the "vanilla PyTorch" path: no Ultralytics, no HuggingFace, just
``torchvision.datasets.ImageFolder`` (or any other ``Dataset``) wrapped with
``ramjetio.CachedDataset``. The cache fronts S3 — first run pulls each
image once, every run after serves bytes peer-to-peer.

Run with:

    export RAMJET_API_KEY="your_key"
    python examples/pytorch_imagenet.py --data-dir /mnt/imagenet/train

Multi-GPU (single host):

    torchrun --nproc_per_node=N examples/pytorch_imagenet.py --data-dir ...

Multi-node:

    torchrun --nnodes=2 --node_rank=0 --nproc_per_node=4 \
        --master_addr=node0 examples/pytorch_imagenet.py --data-dir ...
"""

import argparse
import os
import time

import torch
import torch.distributed as dist
import torch.nn as nn
import torchvision
import torchvision.transforms as T
from torch.utils.data import DataLoader
from torch.utils.data.distributed import DistributedSampler

import ramjetio


def build_transform(img_size: int = 224):
    return T.Compose([
        T.Resize(256),
        T.CenterCrop(img_size),
        T.ToTensor(),
        T.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data-dir', required=True,
                        help='ImageFolder root (train split)')
    parser.add_argument('--epochs', type=int, default=3)
    parser.add_argument('--batch-size', type=int, default=64)
    parser.add_argument('--num-workers', type=int, default=8)
    args = parser.parse_args()

    # ---- DDP bring-up (optional — single-process if torchrun env vars absent)
    is_ddp = 'RANK' in os.environ
    if is_ddp:
        dist.init_process_group('nccl')
        rank = dist.get_rank()
        local_rank = int(os.environ['LOCAL_RANK'])
        torch.cuda.set_device(local_rank)
        device = torch.device(f'cuda:{local_rank}')
    else:
        rank = 0
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # ---- RAMJET init: starts the local cache server, registers with the
    #      backend, and joins the peer ring. Reads RAMJET_API_KEY from env.
    ramjetio.init()

    # ---- Plain torchvision dataset, then wrap it in CachedDataset.
    base = torchvision.datasets.ImageFolder(args.data_dir, transform=build_transform())
    dataset = ramjetio.CachedDataset(
        base,
        cache=ramjetio.get_cache(),
        dataset_name='imagenet_train',
    )

    sampler = DistributedSampler(dataset) if is_ddp else None
    loader = DataLoader(
        dataset,
        batch_size=args.batch_size,
        sampler=sampler,
        shuffle=sampler is None,
        num_workers=args.num_workers,
        pin_memory=True,
    )

    # ---- Tiny model just to drive the pipeline; replace with your own.
    model = torchvision.models.resnet18(num_classes=1000).to(device)
    if is_ddp:
        model = nn.parallel.DistributedDataParallel(model, device_ids=[local_rank])
    optimizer = torch.optim.SGD(model.parameters(), lr=0.1, momentum=0.9)
    criterion = nn.CrossEntropyLoss()

    for epoch in range(args.epochs):
        if sampler is not None:
            sampler.set_epoch(epoch)
        epoch_start = time.time()
        for images, labels in loader:
            images = images.to(device, non_blocking=True)
            labels = labels.to(device, non_blocking=True)
            optimizer.zero_grad()
            loss = criterion(model(images), labels)
            loss.backward()
            optimizer.step()

        if rank == 0:
            stats = dataset.get_cache_stats()
            print(f'epoch {epoch + 1}: {time.time() - epoch_start:.1f}s, '
                  f'hit_rate={stats["hit_rate"]:.1f}%, '
                  f'hits={stats["cache_hits"]} misses={stats["cache_misses"]}')

    ramjetio.shutdown()
    if is_ddp:
        dist.destroy_process_group()


if __name__ == '__main__':
    main()
