"""
Example: HuggingFace ``datasets`` flow wrapped with the RAMJET cache.

``datasets.load_dataset(...)`` already pulls files from the Hub or S3 and
caches them on local disk. RAMJET adds a *peer cache* on top: the first
node that downloads a shard becomes the source of truth for every other
node in the cluster, so re-runs and hyper-parameter sweeps stop hammering
the bucket.

Run with:

    export RAMJET_API_KEY="your_key"
    python examples/huggingface_datasets.py --dataset imdb --split train

Multi-GPU:

    torchrun --nproc_per_node=N examples/huggingface_datasets.py \
        --dataset imdb --split train
"""

import argparse
import os
import time

import torch
import torch.distributed as dist
from torch.utils.data import DataLoader

import ramjetio


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset', default='imdb',
                        help='HF dataset name (passed to datasets.load_dataset)')
    parser.add_argument('--split', default='train')
    parser.add_argument('--epochs', type=int, default=2)
    parser.add_argument('--batch-size', type=int, default=32)
    parser.add_argument('--num-workers', type=int, default=4)
    args = parser.parse_args()

    # Lazy import so the example itself can be browsed without the dep.
    from datasets import load_dataset

    is_ddp = 'RANK' in os.environ
    if is_ddp:
        dist.init_process_group('gloo')  # text-only, CPU is fine
        rank = dist.get_rank()
    else:
        rank = 0

    ramjetio.init()

    # ---- Plain HF dataset → wrap it. The HF `Dataset` object is already
    #      indexable, so CachedDataset can sit on top without changes.
    hf_split = load_dataset(args.dataset, split=args.split)
    cached = ramjetio.CachedDataset(
        hf_split,
        cache=ramjetio.get_cache(),
        dataset_name=f'{args.dataset}:{args.split}',
    )

    loader = DataLoader(
        cached,
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        # HF rows are dicts; default collate_fn handles dict-of-tensors fine
        # for this tiny example. For real training, write a collate_fn that
        # tokenises text into model_inputs.
    )

    for epoch in range(args.epochs):
        epoch_start = time.time()
        for _ in loader:
            pass  # plug in your model + optimizer here
        if rank == 0:
            stats = cached.get_cache_stats()
            print(f'epoch {epoch + 1}: {time.time() - epoch_start:.1f}s, '
                  f'hit_rate={stats["hit_rate"]:.1f}%, '
                  f'hits={stats["cache_hits"]} misses={stats["cache_misses"]}')

    ramjetio.shutdown()
    if is_ddp:
        dist.destroy_process_group()


if __name__ == '__main__':
    main()
