"""
Example: Ultralytics YOLOv8 training fronted by ``ramjetio.UniversalDataset``.

This is the workload measured in the Phase D benchmark
(2× A5000 odin, 5,315 samples × 5 epochs):

    Without RAMJET:  every epoch re-pulls the dataset from S3.
    With RAMJET:     epoch 1 hits S3 once, epochs 2–5 are peer-served.
                     Net 6.5× faster export, 0 S3 calls after epoch 1.

The configuration (S3 endpoint, bucket, prefix, region) is read from the
RAMJET dashboard at ``ramjetio.init()`` time — no YAML to maintain.

Run with:

    export RAMJET_API_KEY="your_key"
    python examples/yolov8.py --model yolov8n.pt --epochs 5

Multi-GPU on a single host:

    torchrun --nproc_per_node=2 examples/yolov8.py --model yolov8n.pt --epochs 5
"""

import argparse
import os

import ramjetio


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', default='yolov8n.pt',
                        help='Ultralytics YOLO checkpoint or model name')
    parser.add_argument('--epochs', type=int, default=5)
    parser.add_argument('--batch-size', type=int, default=16)
    parser.add_argument('--img-size', type=int, default=640)
    parser.add_argument('--export-dir', default='/tmp/ramjet_data',
                        help='Local SSD path the dataset is materialised to')
    args = parser.parse_args()

    rank = int(os.environ.get('RANK', '0'))

    # ---- RAMJET init: connects to the backend, joins the peer ring, and
    #      pulls the cluster's S3 data-source config (endpoint, bucket, ...).
    ramjetio.init()

    # ---- UniversalDataset reads the data-source config and the YOLO format
    #      handler from the cluster — no local YAML, no per-node setup.
    dataset = ramjetio.UniversalDataset(split='train', format='yolo',
                                        img_size=args.img_size)

    # ---- Materialise the S3-backed dataset onto this node's SSD. RAMJET
    #      serves any object already cached on a peer over a sub-ms peer
    #      fetch instead of going back to S3.
    data_yaml = dataset.export_local(args.export_dir)
    if rank == 0:
        print(f'dataset exported to {data_yaml}')

    # ---- Hand the .yaml off to Ultralytics and train as usual.
    from ultralytics import YOLO
    model = YOLO(args.model)
    model.train(
        data=data_yaml,
        epochs=args.epochs,
        batch=args.batch_size,
        imgsz=args.img_size,
    )

    ramjetio.shutdown()


if __name__ == '__main__':
    main()
