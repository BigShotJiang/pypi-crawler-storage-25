#!/usr/bin/env bash
# One-liner launcher for RAMJET examples under torchrun.
#
# Single-host (auto-detects GPU count):
#   ./ddp_torchrun.sh examples/pytorch_imagenet.py --data-dir /mnt/imagenet
#
# Multi-node (run on each node, NODE_RANK 0..N-1):
#   NNODES=2 NODE_RANK=0 MASTER_ADDR=node0 ./ddp_torchrun.sh examples/yolov8.py
#   NNODES=2 NODE_RANK=1 MASTER_ADDR=node0 ./ddp_torchrun.sh examples/yolov8.py
#
# Override per-node GPU count with NPROC=4.

set -euo pipefail

if command -v nvidia-smi >/dev/null 2>&1; then
    DEFAULT_NPROC=$(nvidia-smi -L | wc -l | tr -d ' ')
else
    DEFAULT_NPROC=1
fi

torchrun \
    --nnodes="${NNODES:-1}" \
    --node_rank="${NODE_RANK:-0}" \
    --nproc_per_node="${NPROC:-$DEFAULT_NPROC}" \
    --master_addr="${MASTER_ADDR:-localhost}" \
    --master_port="${MASTER_PORT:-29500}" \
    "$@"
