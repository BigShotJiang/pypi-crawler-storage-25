# Architecture

AutoLRC is organized into thin, independently testable layers. The CLI handles routing; the pipeline handles orchestration; each backend (aligner, separator, repair) is a swappable protocol.

## Modules

| Module | Responsibility |
|---|---|
| `cli.py` | Command surface, flag validation, batch routing, output formatting |
| `pipeline.py` | Single-run and batch orchestration, cache keying, report building |
| `aligner.py` | Lyric normalization, language resolution, fuzzy segment matching, alignment backends |
| `separator.py` | Passthrough and `audio-separator` vocal stem separation |
| `repair.py` | Post-alignment timing correction (default: `TimingRepairBackend`) |
| `lrc.py` | Standard and enhanced (karaoke) LRC rendering |
| `srt.py` / `vtt.py` | SubRip and WebVTT rendering |
| `models.py` | Shared dataclasses (`LineAlignment`, `WordAlignment`, `AlignmentResult`, ...) |

## Single-File Flow

```
AlignRequest
    │
    ├─ skip_existing check             → exit early if .lrc already exists
    │
    ├─ LyricsNormalizer.read()         strip brackets, emoji, normalize Unicode
    │
    ├─ SeparatorBackend.separate()     passthrough or vocal stem extraction
    │
    ├─ AlignerBackend.align()          stable-ts (default) or baseline
    │       ├─ resolve_alignment_language()
    │       │       1. explicit --lang
    │       │       2. script inference (Kana→ja, Hangul→ko, Han→zh)
    │       │       3. multi-window audio vote via ffprobe + stable-ts
    │       └─ _build_fuzzy_line_assignments()
    │               monotone-greedy fuzzy segment-to-line matching
    │
    ├─ RepairBackend.repair()          TimingRepairBackend (default)
    │
    └─ render .lrc / .srt / .vtt       always all three; --enhanced-lrc
                                       switches the LRC to karaoke format
```

Work files are staged under `.autolrc-cache/runs/<sha256-key>/` and removed on completion unless `--keep-temp` is set. The cache key covers audio path, file size, mtime, engine, model, device, and separator.

## Batch Flow

Batch mode is repeated single-file processing. `AutoLRCService.batch_align` discovers pairs and issues one `AlignRequest` per track.

**Discovery:**
- Non-recursive by default; `--recursive` walks subdirectories and processes each directory independently
- Matches `.wav`/`.flac`/`.mp3` with a sibling `.txt` in the same directory
- Priority when multiple audio formats share a stem: `.wav > .flac > .mp3`; lower-priority copies are recorded as skipped
- `--skip-existing` checks for an existing `song.lrc` before each track

**Rejected flags in batch mode:** `--lyrics`, `--output`, `--title`, `--lang`

## Alignment Backends

| Backend | How it works |
|---|---|
| `stable-ts` (default) | Loads a Whisper model, calls `model.align()` with `original_split=True, presplit=True`. Word-level probabilities are averaged into a per-line confidence score; word timestamps are captured for enhanced LRC. |
| `baseline` | Deterministic: assigns synthetic durations by token count (`min(7.5, max(1.8, tokens × 0.48))`). No audio or GPU required. Confidence fixed at `0.25`. |

### Fuzzy Segment Matching

After stable-ts produces segments, `_build_fuzzy_line_assignments` maps lyric lines to segments using `rapidfuzz.token_set_ratio` over a sliding window (up to 4 segments ahead of the cursor). The matching is monotone-greedy — the cursor never goes backward — so assignments cannot cross. When `rapidfuzz` is unavailable, it falls back to positional matching.

## Repair Backend

`TimingRepairBackend` runs four conservative passes on the aligned line list:

1. **Strict ordering** — if `line[i+1].start <= line[i].start`, nudge by 10 ms
2. **Min duration** — extend `end` to at least `start + 0.5 s`
3. **Overlap clamp** — shrink `end` to not exceed the next line's `start`
4. **Gap fill** — extend `end` to cover silent gaps ≤100 ms to the next line

## Separation Backends

| Backend | Trigger |
|---|---|
| `none` (passthrough) | Default; alignment runs directly on the input audio |
| `audio-separator` | `--separator-boost`; separates vocals with `model_bs_roformer_ep_317_sdr_12.9755.ckpt`, caches the model under `.autolrc-cache/models/` |

## Output Formats

**LRC** (`lrc.py`): timestamps as `[MM:SS.cc]`, metadata tags in `[key:value]` form. The `[la:]` tag reflects the resolved language (detected or explicit). `--enhanced-lrc` switches to karaoke-style inline word timestamps: `[MM:SS.cc]<MM:SS.cc>word1 <MM:SS.cc>word2 ...` — standard players ignore the `<>` markers and still render the line.

**SRT** (`srt.py`): standard SubRip blocks with `,` millisecond separator.

**VTT** (`vtt.py`): WebVTT blocks with `.` millisecond separator and a `WEBVTT` header, suitable for HTML5 `<video>` and web players.

For SRT and VTT, end time falls back to the next line's start, then to `start + 2.0 s` for the last line.

## Release Checklist

```bash
python -m pytest -q
python -m ruff check src tests
python -m pre_commit run --all-files
python -m build
python -m twine check dist/*
autolrc benchmark --manifest bench/manifest.yaml
```
