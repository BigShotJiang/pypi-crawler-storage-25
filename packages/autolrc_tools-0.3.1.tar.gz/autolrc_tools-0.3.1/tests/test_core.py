from __future__ import annotations

from autolrc.aligner import LyricsNormalizer, count_lyric_units
from autolrc.lrc import format_timestamp
from autolrc.models import LineAlignment
from autolrc.srt import format_srt_timestamp, render_srt


def test_normalizer_applies_nfkc_and_note_cleanup() -> None:
    normalizer = LyricsNormalizer()
    assert normalizer.normalize_line(" Don't   stop   [chorus] ") == "Don't stop"


def test_normalizer_removes_nested_bracketed_spans_and_emoji() -> None:
    normalizer = LyricsNormalizer()
    assert normalizer.preprocess_line("Verse [alt (take)] {demo} line 😄") == "Verse line"


def test_normalizer_read_drops_lines_emptied_by_cleanup(tmp_path) -> None:
    normalizer = LyricsNormalizer()
    lyrics_path = tmp_path / "lyrics.txt"
    lyrics_path.write_text(" \n[Intro]\nHello {demo}\n😀\nWorld [mix]\n", encoding="utf-8")

    document = normalizer.read(lyrics_path)

    assert [line.line_number for line in document.lines] == [3, 5]
    assert [line.original_text for line in document.lines] == ["Hello", "World"]


def test_count_lyric_units_uses_character_level_for_cjk() -> None:
    assert count_lyric_units("江水东流，再也不回头") == 9
    assert count_lyric_units("Don't stop now") == 3


def test_format_timestamp_renders_centiseconds() -> None:
    assert format_timestamp(62.34) == "01:02.34"


def test_format_srt_timestamp_renders_milliseconds() -> None:
    assert format_srt_timestamp(62.345) == "00:01:02,345"


def test_render_srt_numbers_resolved_lines_and_repairs_end_times() -> None:
    srt_text = render_srt(
        [
            LineAlignment(
                line_number=1,
                text="First line",
                start=0.5,
                end=None,
                coverage_ratio=1.0,
                confidence=1.0,
            ),
            LineAlignment(
                line_number=2,
                text="Skipped line",
                start=None,
                end=None,
                coverage_ratio=0.0,
                confidence=0.0,
            ),
            LineAlignment(
                line_number=3,
                text="Second line",
                start=4.0,
                end=3.0,
                coverage_ratio=1.0,
                confidence=1.0,
            ),
            LineAlignment(
                line_number=4,
                text="Third line",
                start=8.25,
                end=10.5,
                coverage_ratio=1.0,
                confidence=1.0,
            ),
        ]
    )

    assert srt_text == (
        "1\n"
        "00:00:00,500 --> 00:00:04,000\n"
        "First line\n"
        "\n"
        "2\n"
        "00:00:04,000 --> 00:00:08,250\n"
        "Second line\n"
        "\n"
        "3\n"
        "00:00:08,250 --> 00:00:10,500\n"
        "Third line\n"
    )


def test_render_srt_falls_back_to_two_seconds_for_last_line() -> None:
    srt_text = render_srt(
        [
            LineAlignment(
                line_number=1,
                text="Last line",
                start=7.0,
                end=None,
                coverage_ratio=1.0,
                confidence=1.0,
            )
        ]
    )

    assert "00:00:07,000 --> 00:00:09,000" in srt_text
