from __future__ import annotations

import importlib.util
import json
import os
import shutil
import uuid
from pathlib import Path
from types import SimpleNamespace

import pytest

from autolrc.aligner import (
    LanguageResolution,
    StableTsAligner,
    build_language_detection_clips,
    build_stable_ts_alignment_result,
    infer_language_from_lyrics,
    resolve_alignment_device,
    resolve_alignment_language,
)
from autolrc.models import LyricsDocument, LyricsLine
from autolrc.pipeline import AlignRequest, AutoLRCService

FIXTURES_DIR = Path(__file__).parent / "fixtures"
RUN_STABLE_TS = os.environ.get("AUTOLRC_RUN_STABLE_TS") == "1"
HAS_STABLE_TS = importlib.util.find_spec("stable_whisper") is not None
HAS_FFMPEG = shutil.which("ffmpeg") is not None
HAS_MAJOR_REVISION = (FIXTURES_DIR / "Major Revision.wav").exists() and (
    FIXTURES_DIR / "Major Revision.txt"
).exists()
TEST_TMP_ROOT = Path(".autolrc-cache") / "test-workdirs"


def _build_document(*lines: str) -> LyricsDocument:
    lyric_lines = [
        LyricsLine(
            line_number=index,
            original_text=text,
            normalized_text=text.replace("\uff0c", ","),
            token_count=max(1, len(text)),
        )
        for index, text in enumerate(lines, start=1)
    ]
    return LyricsDocument(
        source_path=Path("lyrics.txt"),
        raw_text="\n".join(lines),
        lines=lyric_lines,
    )


def _timestamp_to_seconds(line: str) -> float | None:
    if not line.startswith("[") or ":" not in line or "." not in line:
        return None
    close_index = line.find("]")
    if close_index == -1:
        return None
    stamp = line[1:close_index]
    try:
        minutes_text, remainder = stamp.split(":")
        seconds_text, centiseconds_text = remainder.split(".")
    except ValueError:
        return None
    return int(minutes_text) * 60 + int(seconds_text) + int(centiseconds_text) / 100


def _make_test_dir(prefix: str) -> Path:
    test_dir = TEST_TMP_ROOT / f"{prefix}-{uuid.uuid4().hex}"
    test_dir.mkdir(parents=True, exist_ok=False)
    return test_dir


def test_resolve_alignment_device_prefers_cuda_when_available() -> None:
    resolved_device, diagnostics = resolve_alignment_device(
        "auto",
        diagnostics={"cuda_available": True, "torch_available": True},
    )
    assert resolved_device == "cuda"
    assert diagnostics["cuda_available"] is True


def test_resolve_alignment_device_rejects_missing_cuda() -> None:
    with pytest.raises(RuntimeError):
        resolve_alignment_device(
            "cuda",
            diagnostics={"cuda_available": False, "torch_available": True},
        )


def test_build_stable_ts_alignment_result_maps_segments_by_index() -> None:
    lyrics = _build_document(
        "\u4e4c\u6c5f\u7684\u6c34\uff0c\u6d41\u4e0d\u8fdb\u67cf\u6cb9\u7684\u9a6c\u8def",
        "\u9713\u8679\u7684\u706f\uff0c\u7167\u4e0d\u4eae\u5f52\u4e61\u7684\u8ff7\u9014",
        "\u6c5f\u6c34\u4e1c\u6d41",
    )
    stable_result = SimpleNamespace(
        segments=[
            SimpleNamespace(
                start=12.5,
                end=15.0,
                text="\u4e4c\u6c5f\u7684\u6c34,\u6d41\u4e0d\u8fdb\u67cf\u6cb9\u7684\u9a6c\u8def",
                words=[SimpleNamespace(probability=0.9), SimpleNamespace(probability=0.8)],
            ),
            SimpleNamespace(
                start=16.2,
                end=18.7,
                text="\u9713\u8679\u7684\u706f,\u7167\u4e0d\u4eae\u5f52\u4e61\u7684\u8ff7\u9014",
                words=[SimpleNamespace(probability=0.75)],
            ),
        ]
    )

    alignment = build_stable_ts_alignment_result(
        lyrics,
        stable_result,
        model_name="medium",
        requested_device="auto",
        resolved_device="cuda",
        language_resolution=LanguageResolution("zh", "lyrics-script", ("zh",)),
        diagnostics={"cuda_available": True},
        runtime_seconds=1.23,
    )

    assert alignment.engine_name == "stable-ts"
    assert len(alignment.line_alignments) == 3
    assert alignment.line_alignments[0].start == 12.5
    assert alignment.line_alignments[0].coverage_ratio == 1.0
    assert alignment.line_alignments[0].confidence == 0.85
    assert alignment.line_alignments[1].end == 18.7
    assert alignment.line_alignments[2].start is None
    assert alignment.line_alignments[2].unaligned_tokens == tuple("\u6c5f\u6c34\u4e1c\u6d41")
    assert alignment.metadata["matched_line_count"] == 2
    assert alignment.metadata["segment_count"] == 2
    assert alignment.metadata["resolved_language"] == "zh"
    assert alignment.metadata["language_source"] == "lyrics-script"


def test_resolve_alignment_language_prefers_explicit_value() -> None:
    lyrics = _build_document("Just one line")
    resolution = resolve_alignment_language(
        lyrics,
        model=object(),
        audio_path=Path("song.wav"),
        requested_language="fr",
    )

    assert resolution == LanguageResolution("fr", "explicit", ("fr",))


def test_infer_language_from_lyrics_resolves_zh() -> None:
    resolution = infer_language_from_lyrics(
        _build_document("\u6c5f\u5c71\u5982\u753b", "\u98ce\u8d77\u4e91\u6d8c")
    )
    assert resolution == LanguageResolution("zh", "lyrics-script", ("zh",))


def test_infer_language_from_lyrics_resolves_ja_when_kana_present() -> None:
    resolution = infer_language_from_lyrics(
        _build_document("\u304b\u306a\u306e\u3046\u305f", "\u6f22\u5b57\u307e\u3058\u308a")
    )
    assert resolution == LanguageResolution("ja", "lyrics-script", ("ja",))


def test_infer_language_from_lyrics_resolves_ko() -> None:
    resolution = infer_language_from_lyrics(
        _build_document("\ud558\ub298 \uc544\ub798", "\uc6b0\ub9ac \ub178\ub798")
    )
    assert resolution == LanguageResolution("ko", "lyrics-script", ("ko",))


def test_infer_language_from_lyrics_marks_latin_text_as_ambiguous() -> None:
    assert infer_language_from_lyrics(_build_document("Only latin words here")) is None


def test_build_language_detection_clips_uses_three_windows_for_long_audio() -> None:
    assert build_language_detection_clips(120.0) == (
        "14.000,34.000",
        "50.000,70.000",
        "86.000,106.000",
    )


def test_resolve_alignment_language_uses_audio_vote(monkeypatch) -> None:
    clips_seen: list[str] = []

    class FakeModel:
        def transcribe(self, audio_path: str, **kwargs):
            del audio_path
            clips_seen.append(kwargs["clip_timestamps"])
            clip_to_language = {
                "14.000,34.000": "en",
                "50.000,70.000": "en",
                "86.000,106.000": "de",
            }
            return SimpleNamespace(language=clip_to_language[kwargs["clip_timestamps"]])

    monkeypatch.setattr("autolrc.aligner.get_audio_duration_seconds", lambda audio_path: 120.0)

    resolution = resolve_alignment_language(
        _build_document("Only latin words here"),
        model=FakeModel(),
        audio_path=Path("song.wav"),
        requested_language=None,
    )

    assert resolution == LanguageResolution("en", "audio-vote", ("en", "en", "de"))
    assert clips_seen == ["14.000,34.000", "50.000,70.000", "86.000,106.000"]


def test_resolve_alignment_language_rejects_tied_audio_vote(monkeypatch) -> None:
    class FakeModel:
        def __init__(self) -> None:
            self.languages = iter(["en", "de", ""])

        def transcribe(self, audio_path: str, **kwargs):
            del audio_path, kwargs
            return SimpleNamespace(language=next(self.languages))

    monkeypatch.setattr("autolrc.aligner.get_audio_duration_seconds", lambda audio_path: 120.0)

    with pytest.raises(RuntimeError, match="inconclusive"):
        resolve_alignment_language(
            _build_document("Only latin words here"),
            model=FakeModel(),
            audio_path=Path("song.wav"),
            requested_language=None,
        )


def test_resolve_alignment_language_rejects_empty_audio_vote(monkeypatch) -> None:
    class FakeModel:
        def transcribe(self, audio_path: str, **kwargs):
            del audio_path, kwargs
            return SimpleNamespace(language="")

    monkeypatch.setattr("autolrc.aligner.get_audio_duration_seconds", lambda audio_path: 120.0)

    with pytest.raises(RuntimeError, match="could not detect"):
        resolve_alignment_language(
            _build_document("Only latin words here"),
            model=FakeModel(),
            audio_path=Path("song.wav"),
            requested_language=None,
        )


def test_stable_ts_detects_language_when_not_provided(monkeypatch, tmp_path) -> None:
    align_calls: dict[str, object] = {}
    transcribe_calls: list[str] = []

    class FakeModel:
        def transcribe(self, audio_path: str, **kwargs):
            del audio_path
            transcribe_calls.append(kwargs["clip_timestamps"])
            return SimpleNamespace(language="en")

        def align(self, audio_path: str, text: str, **kwargs):
            align_calls["audio_path"] = audio_path
            align_calls["text"] = text
            align_calls["kwargs"] = kwargs
            return SimpleNamespace(segments=[])

    lyrics = _build_document("One line")
    audio_path = tmp_path / "song.wav"
    audio_path.write_bytes(b"RIFF")

    monkeypatch.setattr(
        "autolrc.aligner.get_runtime_diagnostics",
        lambda: {
            "ffmpeg_available": True,
            "stable_ts_available": True,
            "torch_available": True,
            "cuda_available": False,
        },
    )
    monkeypatch.setattr("autolrc.aligner.importlib.import_module", lambda name: object())
    monkeypatch.setattr("autolrc.aligner.load_stable_ts_model", lambda *args: FakeModel())
    monkeypatch.setattr("autolrc.aligner.get_audio_duration_seconds", lambda audio_path: 120.0)

    alignment = StableTsAligner().align(audio_path, lyrics)

    assert alignment.engine_name == "stable-ts"
    assert align_calls["audio_path"] == str(audio_path)
    assert align_calls["text"] == "One line"
    assert transcribe_calls == ["14.000,34.000", "50.000,70.000", "86.000,106.000"]
    assert align_calls["kwargs"] == {
        "language": "en",
        "original_split": True,
        "presplit": True,
        "gap_padding": " ...",
        "suppress_silence": True,
        "verbose": False,
    }


@pytest.mark.skipif(
    not RUN_STABLE_TS or not HAS_STABLE_TS or not HAS_FFMPEG or not HAS_MAJOR_REVISION,
    reason=(
        "Set AUTOLRC_RUN_STABLE_TS=1 with stable-ts, ffmpeg, and "
        "tests/fixtures/Major Revision.* available to run this test."
    ),
)
def test_major_revision_fixture_alignment_structure() -> None:
    test_dir = _make_test_dir("stable-ts")
    try:
        output_path = test_dir / "Major Revision.lrc"
        report_path = test_dir / "Major Revision.json"
        srt_path = output_path.with_suffix(".srt")

        run = AutoLRCService().align(
            AlignRequest(
                audio_path=FIXTURES_DIR / "Major Revision.wav",
                lyrics_path=FIXTURES_DIR / "Major Revision.txt",
                output_path=output_path,
                write_json_report=True,
            )
        )

        assert run.alignment.engine_name == "stable-ts"
        assert run.srt_output_path == srt_path.resolve()
        assert len(run.alignment.line_alignments) == 57
        resolved_lines = [line for line in run.alignment.line_alignments if line.start is not None]
        assert len(resolved_lines) == 57

        report = json.loads(report_path.read_text(encoding="utf-8"))
        assert report["line_count"] == 57
        assert report["resolved_line_count"] == 57
        assert report["resolved_device"] in {"cpu", "cuda"}
        assert report["resolved_language"] == "en"
        assert report["language_source"] == "audio-vote"
        assert report["srt_output_path"] == str(srt_path.resolve())
        assert report["low_confidence"] is False

        lrc_lines = output_path.read_text(encoding="utf-8").splitlines()
        timestamps = [
            seconds
            for seconds in (_timestamp_to_seconds(line) for line in lrc_lines)
            if seconds is not None
        ]
        assert timestamps == sorted(timestamps)
        assert len(timestamps) == 57
        assert 8 <= timestamps[0] <= 20
        assert timestamps[-1] > 180

        srt_text = srt_path.read_text(encoding="utf-8")
        assert srt_text.strip()
        assert " --> " in srt_text
    finally:
        shutil.rmtree(test_dir, ignore_errors=True)


@pytest.mark.skipif(
    not RUN_STABLE_TS or not HAS_STABLE_TS or not HAS_FFMPEG or not HAS_MAJOR_REVISION,
    reason=(
        "Set AUTOLRC_RUN_STABLE_TS=1 with stable-ts, ffmpeg, and "
        "tests/fixtures/Major Revision.* available to run this test."
    ),
)
def test_major_revision_defaults_to_audio_stem() -> None:
    test_dir = _make_test_dir("major-revision")
    try:
        audio_path = test_dir / "Major Revision.wav"
        lyrics_path = test_dir / "Major Revision.txt"
        shutil.copy2(FIXTURES_DIR / "Major Revision.wav", audio_path)
        shutil.copy2(FIXTURES_DIR / "Major Revision.txt", lyrics_path)

        run = AutoLRCService().align(
            AlignRequest(
                audio_path=audio_path,
                lyrics_path=lyrics_path,
            )
        )

        expected_lrc_path = audio_path.with_suffix(".lrc").resolve()
        expected_srt_path = audio_path.with_suffix(".srt").resolve()

        assert run.output_path == expected_lrc_path
        assert run.srt_output_path == expected_srt_path
        assert run.report_path is None
        assert expected_lrc_path.exists()
        assert expected_srt_path.exists()
        assert not audio_path.with_suffix(".json").exists()
    finally:
        shutil.rmtree(test_dir, ignore_errors=True)
