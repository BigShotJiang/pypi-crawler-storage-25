from __future__ import annotations

import json
import shutil
import uuid
import wave
from pathlib import Path

import pytest
from typer.testing import CliRunner

from autolrc.cli import _load_manifest, app
from autolrc.models import (
    AlignmentResult,
    AlignmentRun,
    BatchAlignmentRun,
    BatchItemResult,
    LineAlignment,
    SeparationResult,
)
from autolrc.separator import DependencyStatus

runner = CliRunner()
BENCH_MANIFEST = Path("bench/manifest.yaml")
TEST_TMP_ROOT = Path(".autolrc-cache") / "test-workdirs"


def _write_silent_wav(
    path: Path,
    *,
    sample_rate: int = 16000,
    duration_seconds: float = 1.0,
) -> None:
    frame_count = int(sample_rate * duration_seconds)
    with wave.open(str(path), "wb") as wav_file:
        wav_file.setnchannels(1)
        wav_file.setsampwidth(2)
        wav_file.setframerate(sample_rate)
        wav_file.writeframes(b"\x00\x00" * frame_count)


def _write_dummy_mp3(path: Path) -> None:
    path.write_bytes(b"ID3")


def _make_test_dir() -> Path:
    test_dir = TEST_TMP_ROOT / f"cli-{uuid.uuid4().hex}"
    test_dir.mkdir(parents=True, exist_ok=False)
    return test_dir


def test_help_smoke() -> None:
    root_result = runner.invoke(app, ["--help"])
    align_result = runner.invoke(app, ["align", "--help"])

    assert root_result.exit_code == 0
    assert "align" in root_result.stdout
    assert "doctor" in root_result.stdout
    assert align_result.exit_code == 0
    assert "--model" in align_result.stdout
    assert "--device" in align_result.stdout
    assert "--separator-boost" in align_result.stdout
    assert "--save-vocals" in align_result.stdout
    assert "--json-report" in align_result.stdout
    assert "--write-audio-metadata" not in align_result.stdout


def test_benchmark_manifest_primary_track_points_to_major_revision() -> None:
    tracks = _load_manifest(BENCH_MANIFEST)

    assert len(tracks) == 1
    track = tracks[0]
    assert track["track_id"] == "major_revision"
    assert track["audio_path"] == "tests/fixtures/Major Revision.wav"
    assert track["lyrics_path"] == "tests/fixtures/Major Revision.txt"
    assert track["languages"] == ["en"]
    assert track["is_mixed_language"] is False
    assert track["has_long_intro"] is True
    assert track["has_repeated_chorus"] is True
    assert Path(track["audio_path"]).exists()
    assert Path(track["lyrics_path"]).exists()


def test_benchmark_command_summarizes_primary_release_manifest() -> None:
    result = runner.invoke(app, ["benchmark", "--manifest", str(BENCH_MANIFEST)])

    assert result.exit_code == 0, result.stdout
    assert "Tracks: 1" in result.stdout
    assert "- major_revision [en]" in result.stdout


def test_align_command_defaults_outputs_to_audio_stem_with_baseline() -> None:
    test_dir = _make_test_dir()
    try:
        audio_path = test_dir / "tiny.wav"
        lyrics_path = test_dir / "lyrics.txt"
        lrc_path = test_dir / "tiny.lrc"
        srt_path = test_dir / "tiny.srt"
        report_path = test_dir / "tiny.json"

        _write_silent_wav(audio_path)
        lyrics_path.write_text(
            "Hello from AutoLRC\nWe can still test this\nEven without ML\n",
            encoding="utf-8",
        )

        result = runner.invoke(
            app,
            [
                "align",
                "--audio",
                str(audio_path),
                "--lyrics",
                str(lyrics_path),
                "--artist",
                "AutoLRC",
                "--title",
                "Sample Song",
                "--engine",
                "baseline",
            ],
        )

        assert result.exit_code == 0, result.stdout
        assert lrc_path.exists()
        assert srt_path.exists()
        assert f"Wrote LRC: {lrc_path.resolve()}" in result.stdout
        assert f"Wrote SRT: {srt_path.resolve()}" in result.stdout
        assert f"Report: {report_path.resolve()}" not in result.stdout

        lrc_output = lrc_path.read_text(encoding="utf-8")
        assert "[ar:AutoLRC]" in lrc_output
        assert "[ti:Sample Song]" in lrc_output
        assert "[00:00.50]Hello from AutoLRC" in lrc_output

        srt_output = srt_path.read_text(encoding="utf-8")
        assert "1\n00:00:00,500 --> 00:00:02,300\nHello from AutoLRC\n" in srt_output

        assert not report_path.exists()
    finally:
        shutil.rmtree(test_dir, ignore_errors=True)


def test_align_command_writes_sibling_json_report_when_enabled() -> None:
    test_dir = _make_test_dir()
    try:
        audio_path = test_dir / "tiny.wav"
        lyrics_path = test_dir / "lyrics.txt"
        output_path = test_dir / "song.lrc"
        srt_path = output_path.with_suffix(".srt")
        report_path = output_path.with_suffix(".json")

        _write_silent_wav(audio_path)
        lyrics_path.write_text("Hello from AutoLRC\n", encoding="utf-8")

        result = runner.invoke(
            app,
            [
                "align",
                "--audio",
                str(audio_path),
                "--lyrics",
                str(lyrics_path),
                "--output",
                str(output_path),
                "--json-report",
                "--engine",
                "baseline",
            ],
        )

        assert result.exit_code == 0, result.stdout
        assert output_path.exists()
        assert srt_path.exists()
        assert report_path.exists()
        assert f"Report: {report_path.resolve()}" in result.stdout

        report = json.loads(report_path.read_text(encoding="utf-8"))
        assert report["output_path"] == str(output_path.resolve())
        assert report["srt_output_path"] == str(srt_path.resolve())
    finally:
        shutil.rmtree(test_dir, ignore_errors=True)


def test_align_rejects_removed_write_audio_metadata_option() -> None:
    result = runner.invoke(
        app,
        [
            "align",
            "--write-audio-metadata",
        ],
    )

    combined_output = result.stdout + result.stderr
    assert result.exit_code != 0
    assert "No such option: --write-audio-metadata" in combined_output


def test_align_command_prints_low_confidence_separator_boost_guidance(monkeypatch) -> None:
    test_dir = _make_test_dir()
    try:
        audio_path = test_dir / "song with spaces.wav"
        lyrics_path = test_dir / "song lyrics.txt"
        output_path = test_dir / "song with spaces.lrc"
        srt_path = test_dir / "song with spaces.srt"

        _write_silent_wav(audio_path)
        lyrics_path.write_text("Hello from AutoLRC\n", encoding="utf-8")

        class FakeService:
            def align(self, request):
                del request
                return AlignmentRun(
                    audio_path=audio_path.resolve(),
                    lyrics_path=lyrics_path.resolve(),
                    output_path=output_path.resolve(),
                    srt_output_path=srt_path.resolve(),
                    saved_vocals_path=None,
                    separator=SeparationResult(
                        vocals_path=audio_path.resolve(),
                        instrumental_path=None,
                        backend_name="none",
                        runtime_seconds=0.0,
                    ),
                    alignment=AlignmentResult(
                        engine_name="stable-ts",
                        line_alignments=[
                            LineAlignment(
                                line_number=1,
                                text="Hello from AutoLRC",
                                start=0.5,
                                end=2.3,
                                coverage_ratio=1.0,
                                confidence=0.4,
                            )
                        ],
                        runtime_seconds=0.25,
                    ),
                    report={
                        "model": "medium",
                        "resolved_device": "cuda",
                        "resolved_language": "en",
                        "average_confidence": 0.4,
                        "low_confidence": True,
                        "low_confidence_threshold": 0.5,
                        "recommended_action": "inspect-output-and-rerun-with-separator-boost",
                    },
                    report_path=None,
                )

        monkeypatch.setattr("autolrc.cli._service", lambda cache_dir=Path(): FakeService())

        result = runner.invoke(
            app,
            [
                "align",
                "--audio",
                str(audio_path),
                "--lyrics",
                str(lyrics_path),
            ],
        )

        assert result.exit_code == 0, result.stdout
        assert "Warning: average confidence 0.4000 is below 0.5." in result.stdout
        assert "Inspect the generated files before using them downstream." in result.stdout
        assert "Separator boost may improve alignment quality for this track." in result.stdout
        assert "Suggested rerun:" in result.stdout
        assert "--separator-boost" in result.stdout
        assert str(audio_path) in result.stdout
        assert str(lyrics_path) in result.stdout
    finally:
        shutil.rmtree(test_dir, ignore_errors=True)


def test_batch_align_directory_mode_processes_pairs_and_prints_summary() -> None:
    test_dir = _make_test_dir()
    try:
        _write_silent_wav(test_dir / "alpha.wav")
        (test_dir / "alpha.txt").write_text("Alpha line\n", encoding="utf-8")
        _write_dummy_mp3(test_dir / "beta.mp3")
        (test_dir / "beta.txt").write_text("Beta line\n", encoding="utf-8")
        _write_silent_wav(test_dir / "orphan.wav")

        result = runner.invoke(
            app,
            [
                "align",
                "--audio",
                str(test_dir),
                "--engine",
                "baseline",
            ],
        )

        assert result.exit_code == 0, result.stdout
        assert "Batch directory:" in result.stdout
        assert "SUCCESS [alpha]" in result.stdout
        assert "SUCCESS [beta]" in result.stdout
        assert "SKIPPED [orphan.wav] No matching .txt lyrics file found." in result.stdout
        assert "Summary:" in result.stdout
        assert "Matched: 2" in result.stdout
        assert "Succeeded: 2" in result.stdout
        assert "Low confidence: 0" in result.stdout
        assert "Failed: 0" in result.stdout
        assert "Skipped: 1" in result.stdout
        assert (test_dir / "alpha.lrc").exists()
        assert (test_dir / "alpha.srt").exists()
        assert (test_dir / "beta.lrc").exists()
        assert (test_dir / "beta.srt").exists()
        assert not (test_dir / "alpha.json").exists()
        assert not (test_dir / "beta.json").exists()
    finally:
        shutil.rmtree(test_dir, ignore_errors=True)


def test_batch_align_directory_mode_writes_json_reports_when_enabled() -> None:
    test_dir = _make_test_dir()
    try:
        _write_silent_wav(test_dir / "alpha.wav")
        (test_dir / "alpha.txt").write_text("Alpha line\n", encoding="utf-8")
        _write_dummy_mp3(test_dir / "beta.mp3")
        (test_dir / "beta.txt").write_text("Beta line\n", encoding="utf-8")

        result = runner.invoke(
            app,
            [
                "align",
                "--audio",
                str(test_dir),
                "--engine",
                "baseline",
                "--json-report",
            ],
        )

        assert result.exit_code == 0, result.stdout
        assert (test_dir / "alpha.json").exists()
        assert (test_dir / "beta.json").exists()
    finally:
        shutil.rmtree(test_dir, ignore_errors=True)


def test_batch_align_directory_mode_writes_lrc_metadata_with_shared_artist() -> None:
    test_dir = _make_test_dir()
    try:
        _write_silent_wav(test_dir / "alpha.wav")
        (test_dir / "alpha.txt").write_text("Alpha line\n", encoding="utf-8")
        _write_dummy_mp3(test_dir / "beta.mp3")
        (test_dir / "beta.txt").write_text("Beta line\n", encoding="utf-8")

        result = runner.invoke(
            app,
            [
                "align",
                "--audio",
                str(test_dir),
                "--engine",
                "baseline",
                "--artist",
                "Batch Artist",
            ],
        )

        assert result.exit_code == 0, result.stdout
        assert "SUCCESS [alpha]" in result.stdout
        assert "SUCCESS [beta]" in result.stdout
        alpha_lrc = (test_dir / "alpha.lrc").read_text(encoding="utf-8")
        beta_lrc = (test_dir / "beta.lrc").read_text(encoding="utf-8")
        assert "[ar:Batch Artist]" in alpha_lrc
        assert "[ti:alpha]" in alpha_lrc
        assert "[ar:Batch Artist]" in beta_lrc
        assert "[ti:beta]" in beta_lrc
    finally:
        shutil.rmtree(test_dir, ignore_errors=True)


def test_batch_align_directory_mode_without_artist_keeps_lrc_metadata_free() -> None:
    test_dir = _make_test_dir()
    try:
        _write_silent_wav(test_dir / "alpha.wav")
        (test_dir / "alpha.txt").write_text("Alpha line\n", encoding="utf-8")

        result = runner.invoke(
            app,
            [
                "align",
                "--audio",
                str(test_dir),
                "--engine",
                "baseline",
            ],
        )

        assert result.exit_code == 0, result.stdout
        alpha_lrc = (test_dir / "alpha.lrc").read_text(encoding="utf-8")
        assert "[ar:" not in alpha_lrc
        assert "[ti:" not in alpha_lrc
    finally:
        shutil.rmtree(test_dir, ignore_errors=True)


def test_batch_align_directory_mode_prefers_wav_and_continues_after_failure() -> None:
    test_dir = _make_test_dir()
    try:
        _write_silent_wav(test_dir / "alpha.wav")
        (test_dir / "alpha.txt").write_text("Alpha line\n", encoding="utf-8")
        _write_silent_wav(test_dir / "broken.wav")
        (test_dir / "broken.txt").write_text("[]\n{}\n", encoding="utf-8")
        _write_silent_wav(test_dir / "duo.wav")
        _write_dummy_mp3(test_dir / "duo.mp3")
        (test_dir / "duo.txt").write_text("Duo line\n", encoding="utf-8")

        result = runner.invoke(
            app,
            [
                "align",
                "--audio",
                str(test_dir),
                "--engine",
                "baseline",
            ],
        )

        combined_output = result.stdout + result.stderr
        assert result.exit_code == 1, combined_output
        assert "SUCCESS [alpha]" in combined_output
        assert "FAILED [broken] No lyric lines remain after normalization." in combined_output
        assert "SUCCESS [duo]" in combined_output
        assert "SKIPPED [duo.mp3] Skipped because sibling duo.wav is preferred." in combined_output
        assert "Matched: 3" in combined_output
        assert "Succeeded: 2" in combined_output
        assert "Failed: 1" in combined_output
        assert "Skipped: 1" in combined_output
        assert (test_dir / "duo.lrc").exists()
        assert not (test_dir / "duo.mp3.lrc").exists()
    finally:
        shutil.rmtree(test_dir, ignore_errors=True)


@pytest.mark.parametrize(
    ("extra_args", "expected_message"),
    [
        (["--lyrics", "placeholder.txt"], "--lyrics is not supported in batch directory mode"),
        (["--output", "custom.lrc"], "--output is not supported in batch directory mode"),
        (["--title", "Batch Title"], "--title is not supported in batch directory mode"),
        (["--lang", "zh"], "--lang is not supported in batch directory mode"),
    ],
)
def test_batch_align_rejects_single_file_flags(
    extra_args: list[str],
    expected_message: str,
) -> None:
    test_dir = _make_test_dir()
    try:
        _write_silent_wav(test_dir / "alpha.wav")
        (test_dir / "alpha.txt").write_text("Alpha line\n", encoding="utf-8")
        placeholder_lyrics = test_dir / "placeholder.txt"
        placeholder_lyrics.write_text("Placeholder\n", encoding="utf-8")
        output_dir = test_dir / "custom"
        output_dir.mkdir()

        resolved_args: list[str] = []
        for value in extra_args:
            if value == "placeholder.txt":
                resolved_args.append(str(placeholder_lyrics))
            elif value == "custom.lrc":
                resolved_args.append(str(output_dir / value))
            else:
                resolved_args.append(value)

        result = runner.invoke(
            app,
            [
                "align",
                "--audio",
                str(test_dir),
                *resolved_args,
            ],
        )

        combined_output = result.stdout + result.stderr
        assert result.exit_code == 1
        assert expected_message in combined_output
    finally:
        shutil.rmtree(test_dir, ignore_errors=True)


def test_batch_align_zero_matches_exits_with_actionable_message() -> None:
    test_dir = _make_test_dir()
    try:
        _write_silent_wav(test_dir / "orphan.wav")
        result = runner.invoke(app, ["align", "--audio", str(test_dir), "--engine", "baseline"])

        combined_output = result.stdout + result.stderr
        assert result.exit_code == 1
        assert "No matching .wav/.mp3 and same-stem .txt pairs were found" in combined_output
    finally:
        shutil.rmtree(test_dir, ignore_errors=True)


def test_batch_align_low_confidence_output_reuses_separator_boost_guidance(monkeypatch) -> None:
    test_dir = _make_test_dir()
    try:
        audio_path = test_dir / "song.wav"
        lyrics_path = test_dir / "song.txt"
        output_path = test_dir / "song.lrc"
        report_path = test_dir / "song.json"
        _write_silent_wav(audio_path)
        lyrics_path.write_text("Hello from AutoLRC\n", encoding="utf-8")

        run = AlignmentRun(
            audio_path=audio_path.resolve(),
            lyrics_path=lyrics_path.resolve(),
            output_path=output_path.resolve(),
            srt_output_path=output_path.with_suffix(".srt").resolve(),
            saved_vocals_path=None,
            separator=SeparationResult(
                vocals_path=audio_path.resolve(),
                instrumental_path=None,
                backend_name="none",
                runtime_seconds=0.0,
            ),
            alignment=AlignmentResult(
                engine_name="stable-ts",
                line_alignments=[
                    LineAlignment(
                        line_number=1,
                        text="Hello from AutoLRC",
                        start=0.5,
                        end=2.3,
                        coverage_ratio=1.0,
                        confidence=0.4,
                    )
                ],
                runtime_seconds=0.25,
            ),
            report={
                "average_confidence": 0.4,
                "low_confidence": True,
                "low_confidence_threshold": 0.5,
                "recommended_action": "inspect-output-and-rerun-with-separator-boost",
            },
            report_path=report_path.resolve(),
        )

        class FakeService:
            def batch_align(self, request):
                del request
                return BatchAlignmentRun(
                    audio_dir=test_dir.resolve(),
                    items=[
                        BatchItemResult(
                            stem="song",
                            audio_path=audio_path.resolve(),
                            lyrics_path=lyrics_path.resolve(),
                            status="low-confidence",
                            run=run,
                        )
                    ],
                    matched_count=1,
                    succeeded_count=0,
                    low_confidence_count=1,
                    failed_count=0,
                    skipped_count=0,
                )

        monkeypatch.setattr("autolrc.cli._service", lambda cache_dir=Path(): FakeService())

        result = runner.invoke(app, ["align", "--audio", str(test_dir)])

        assert result.exit_code == 0, result.stdout
        assert "LOW CONFIDENCE [song]" in result.stdout
        assert "Separator boost may improve alignment quality for this track." in result.stdout
        assert "Suggested rerun:" in result.stdout
        assert "--separator-boost" in result.stdout
        assert str(audio_path) in result.stdout
        assert str(lyrics_path) in result.stdout
    finally:
        shutil.rmtree(test_dir, ignore_errors=True)


def test_doctor_reports_broken_audio_separator_runtime(monkeypatch) -> None:
    monkeypatch.setattr(
        "autolrc.cli.get_audio_separator_dependency_status",
        lambda: DependencyStatus(
            state="broken",
            message="broken (missing runtime dependency: onnxruntime. Refresh the environment.)",
        ),
    )

    result = runner.invoke(app, ["doctor"])

    assert result.exit_code == 0, result.stdout
    assert "- audio-separator: broken (missing runtime dependency: onnxruntime." in result.stdout


def test_separator_boost_runtime_error_mentions_environment_refresh(monkeypatch) -> None:
    test_dir = _make_test_dir()
    try:
        audio_path = test_dir / "tiny.wav"
        lyrics_path = test_dir / "lyrics.txt"
        _write_silent_wav(audio_path)
        lyrics_path.write_text("Hello from AutoLRC\n", encoding="utf-8")

        monkeypatch.setattr("autolrc.separator.importlib.util.find_spec", lambda name: object())

        def _fake_import_module(name: str):
            if name == "audio_separator.separator":
                raise ModuleNotFoundError("No module named 'onnxruntime'", name="onnxruntime")
            return __import__(name)

        monkeypatch.setattr("autolrc.separator.importlib.import_module", _fake_import_module)

        result = runner.invoke(
            app,
            [
                "align",
                "--audio",
                str(audio_path),
                "--lyrics",
                str(lyrics_path),
                "--engine",
                "baseline",
                "--separator-boost",
            ],
        )

        combined_output = result.stdout + result.stderr
        assert result.exit_code == 1
        assert "audio-separator is installed but not runnable." in combined_output
        assert (
            "Existing virtual environments do not automatically acquire newly added optional "
            "dependencies" in combined_output
        )
        assert "python -m pip install -e .[gpu,dev]" in combined_output
        assert "python -m pip install -e .[cpu,dev]" in combined_output
    finally:
        shutil.rmtree(test_dir, ignore_errors=True)
