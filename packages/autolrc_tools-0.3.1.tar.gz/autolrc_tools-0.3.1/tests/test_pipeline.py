from __future__ import annotations

import shutil
import uuid
import wave
from pathlib import Path

import pytest

from autolrc.models import AlignmentResult, LineAlignment, SeparationResult
from autolrc.pipeline import AlignRequest, AutoLRCService, BatchAlignRequest

TEST_TMP_ROOT = Path(".autolrc-cache") / "test-workdirs"


def _make_test_dir(prefix: str) -> Path:
    test_dir = TEST_TMP_ROOT / f"{prefix}-{uuid.uuid4().hex}"
    test_dir.mkdir(parents=True, exist_ok=False)
    return test_dir


def _write_silent_wav(
    path: Path,
    *,
    sample_rate: int = 16000,
    duration_seconds: float = 1.0,
) -> None:
    frame_count = int(sample_rate * duration_seconds)
    with wave.open(str(path), "wb") as wav_file:
        wav_file.setnchannels(1)
        wav_file.setsampwidth(2)
        wav_file.setframerate(sample_rate)
        wav_file.writeframes(b"\x00\x00" * frame_count)


def _write_text_fixture(path: Path) -> None:
    path.write_text("Hello from AutoLRC\n", encoding="utf-8")


def _write_dummy_mp3(path: Path) -> None:
    path.write_bytes(b"ID3")


def _build_alignment(
    *,
    engine_name: str,
    confidence: float,
    metadata: dict | None = None,
) -> AlignmentResult:
    return AlignmentResult(
        engine_name=engine_name,
        line_alignments=[
            LineAlignment(
                line_number=1,
                text="Hello from AutoLRC",
                start=0.5,
                end=2.3,
                coverage_ratio=1.0,
                confidence=confidence,
            )
        ],
        runtime_seconds=0.25,
        metadata=metadata or {},
    )


def test_separator_boost_uses_vocal_stem_and_saves_copy(monkeypatch) -> None:
    test_dir = _make_test_dir("pipeline-boost")
    try:
        audio_path = test_dir / "song.wav"
        lyrics_path = test_dir / "song.txt"
        _write_silent_wav(audio_path)
        _write_text_fixture(lyrics_path)
        expected_vocals_path = audio_path.with_suffix(".vocals.wav").resolve()

        class FakeSeparator:
            def separate(self, audio_file: Path, work_dir: Path) -> SeparationResult:
                del audio_file
                vocals_path = work_dir / "vocals.wav"
                instrumental_path = work_dir / "instrumental.wav"
                _write_silent_wav(vocals_path)
                _write_silent_wav(instrumental_path)
                return SeparationResult(
                    vocals_path=vocals_path,
                    instrumental_path=instrumental_path,
                    backend_name="audio-separator",
                    runtime_seconds=1.0,
                    metadata={},
                )

        class FakeAligner:
            def align(self, audio_file: Path, lyrics, **kwargs) -> AlignmentResult:
                del lyrics, kwargs
                assert audio_file.name == "vocals.wav"
                return _build_alignment(
                    engine_name="stable-ts",
                    confidence=0.8,
                    metadata={
                        "model_name": "medium",
                        "resolved_device": "cpu",
                        "resolved_language": "en",
                        "language_source": "audio-vote",
                        "language_candidates": ["en", "en", "de"],
                    },
                )

        monkeypatch.setattr(
            "autolrc.pipeline.get_separator",
            lambda name, cache_dir=None: FakeSeparator(),
        )
        monkeypatch.setattr("autolrc.pipeline.get_aligner", lambda name: FakeAligner())

        run = AutoLRCService().align(
            AlignRequest(
                audio_path=audio_path,
                lyrics_path=lyrics_path,
                separator_boost=True,
                save_vocals=True,
            )
        )

        assert run.saved_vocals_path == expected_vocals_path
        assert expected_vocals_path.exists()
        assert run.report["separator"] == "audio-separator"
        assert run.report["boost_mode"] is True
        assert run.report["saved_vocals_path"] == str(expected_vocals_path)
    finally:
        shutil.rmtree(test_dir, ignore_errors=True)


def test_save_vocals_requires_real_separation() -> None:
    test_dir = _make_test_dir("pipeline-save-vocals")
    try:
        audio_path = test_dir / "song.wav"
        lyrics_path = test_dir / "song.txt"
        _write_silent_wav(audio_path)
        _write_text_fixture(lyrics_path)

        with pytest.raises(ValueError, match="Saving vocals requires real separation"):
            AutoLRCService().align(
                AlignRequest(
                    audio_path=audio_path,
                    lyrics_path=lyrics_path,
                    save_vocals=True,
                )
            )
    finally:
        shutil.rmtree(test_dir, ignore_errors=True)


def test_single_file_lrc_metadata_leaves_audio_file_untouched() -> None:
    test_dir = _make_test_dir("pipeline-lrc-metadata")
    try:
        audio_path = test_dir / "song.wav"
        lyrics_path = test_dir / "song.txt"
        _write_silent_wav(audio_path)
        _write_text_fixture(lyrics_path)
        original_audio = audio_path.read_bytes()

        run = AutoLRCService().align(
            AlignRequest(
                audio_path=audio_path,
                lyrics_path=lyrics_path,
                title="Song Title",
                artist="AutoLRC",
                engine="baseline",
            )
        )

        assert run.output_path.exists()
        assert run.srt_output_path.exists()
        assert run.report_path is None
        assert audio_path.read_bytes() == original_audio
        assert run.report["output_path"] == str(run.output_path)
        assert run.report["srt_output_path"] == str(run.srt_output_path)
        assert not audio_path.with_suffix(".json").exists()

        lrc_output = run.output_path.read_text(encoding="utf-8")
        assert "[ar:AutoLRC]" in lrc_output
        assert "[ti:Song Title]" in lrc_output
    finally:
        shutil.rmtree(test_dir, ignore_errors=True)


def test_single_file_json_report_is_written_only_when_enabled() -> None:
    test_dir = _make_test_dir("pipeline-json-report")
    try:
        audio_path = test_dir / "song.wav"
        lyrics_path = test_dir / "song.txt"
        expected_report_path = audio_path.with_suffix(".json").resolve()
        _write_silent_wav(audio_path)
        _write_text_fixture(lyrics_path)

        run = AutoLRCService().align(
            AlignRequest(
                audio_path=audio_path,
                lyrics_path=lyrics_path,
                engine="baseline",
                write_json_report=True,
            )
        )

        assert run.report_path == expected_report_path
        assert expected_report_path.exists()
    finally:
        shutil.rmtree(test_dir, ignore_errors=True)


def test_separator_boost_rejects_explicit_none() -> None:
    test_dir = _make_test_dir("pipeline-explicit-none")
    try:
        audio_path = test_dir / "song.wav"
        lyrics_path = test_dir / "song.txt"
        _write_silent_wav(audio_path)
        _write_text_fixture(lyrics_path)

        with pytest.raises(ValueError, match="cannot be combined with --separator none"):
            AutoLRCService().align(
                AlignRequest(
                    audio_path=audio_path,
                    lyrics_path=lyrics_path,
                    separator="none",
                    separator_boost=True,
                )
            )
    finally:
        shutil.rmtree(test_dir, ignore_errors=True)


def test_low_confidence_report_suggests_separator_boost(monkeypatch) -> None:
    test_dir = _make_test_dir("pipeline-low-confidence")
    try:
        audio_path = test_dir / "song.wav"
        lyrics_path = test_dir / "song.txt"
        _write_silent_wav(audio_path)
        _write_text_fixture(lyrics_path)

        class FakeSeparator:
            def separate(self, audio_file: Path, work_dir: Path) -> SeparationResult:
                del work_dir
                return SeparationResult(
                    vocals_path=audio_file,
                    instrumental_path=None,
                    backend_name="none",
                    runtime_seconds=0.0,
                    metadata={},
                )

        class FakeAligner:
            def align(self, audio_file: Path, lyrics, **kwargs) -> AlignmentResult:
                del audio_file, lyrics, kwargs
                return _build_alignment(
                    engine_name="stable-ts",
                    confidence=0.4,
                    metadata={
                        "model_name": "medium",
                        "resolved_device": "cpu",
                        "resolved_language": "en",
                        "language_source": "audio-vote",
                        "language_candidates": ["en", "en", "de"],
                    },
                )

        monkeypatch.setattr(
            "autolrc.pipeline.get_separator",
            lambda name, cache_dir=None: FakeSeparator(),
        )
        monkeypatch.setattr("autolrc.pipeline.get_aligner", lambda name: FakeAligner())

        run = AutoLRCService().align(AlignRequest(audio_path=audio_path, lyrics_path=lyrics_path))

        assert run.report["low_confidence"] is True
        assert run.report["recommended_action"] == "inspect-output-and-rerun-with-separator-boost"
        assert run.report["low_confidence_threshold"] == 0.5
    finally:
        shutil.rmtree(test_dir, ignore_errors=True)


def test_low_confidence_report_with_existing_separation_does_not_suggest_boost(
    monkeypatch,
) -> None:
    test_dir = _make_test_dir("pipeline-separated-low-confidence")
    try:
        audio_path = test_dir / "song.wav"
        lyrics_path = test_dir / "song.txt"
        _write_silent_wav(audio_path)
        _write_text_fixture(lyrics_path)

        class FakeSeparator:
            def separate(self, audio_file: Path, work_dir: Path) -> SeparationResult:
                del audio_file
                vocals_path = work_dir / "vocals.wav"
                _write_silent_wav(vocals_path)
                return SeparationResult(
                    vocals_path=vocals_path,
                    instrumental_path=None,
                    backend_name="audio-separator",
                    runtime_seconds=1.0,
                    metadata={},
                )

        class FakeAligner:
            def align(self, audio_file: Path, lyrics, **kwargs) -> AlignmentResult:
                del audio_file, lyrics, kwargs
                return _build_alignment(
                    engine_name="stable-ts",
                    confidence=0.4,
                    metadata={
                        "model_name": "medium",
                        "resolved_device": "cpu",
                        "resolved_language": "en",
                        "language_source": "audio-vote",
                        "language_candidates": ["en", "en", "de"],
                    },
                )

        monkeypatch.setattr(
            "autolrc.pipeline.get_separator",
            lambda name, cache_dir=None: FakeSeparator(),
        )
        monkeypatch.setattr("autolrc.pipeline.get_aligner", lambda name: FakeAligner())

        run = AutoLRCService().align(
            AlignRequest(
                audio_path=audio_path,
                lyrics_path=lyrics_path,
                separator="audio-separator",
            )
        )

        assert run.report["low_confidence"] is True
        assert (
            run.report["recommended_action"]
            == "inspect-output-and-consider-explicit-lang-or-manual-review"
        )
    finally:
        shutil.rmtree(test_dir, ignore_errors=True)


def test_baseline_report_does_not_emit_low_confidence_guidance(monkeypatch) -> None:
    test_dir = _make_test_dir("pipeline-baseline")
    try:
        audio_path = test_dir / "song.wav"
        lyrics_path = test_dir / "song.txt"
        _write_silent_wav(audio_path)
        _write_text_fixture(lyrics_path)

        class FakeSeparator:
            def separate(self, audio_file: Path, work_dir: Path) -> SeparationResult:
                del work_dir
                return SeparationResult(
                    vocals_path=audio_file,
                    instrumental_path=None,
                    backend_name="none",
                    runtime_seconds=0.0,
                    metadata={},
                )

        class FakeAligner:
            def align(self, audio_file: Path, lyrics, **kwargs) -> AlignmentResult:
                del audio_file, lyrics, kwargs
                return _build_alignment(engine_name="baseline", confidence=0.25)

        monkeypatch.setattr(
            "autolrc.pipeline.get_separator",
            lambda name, cache_dir=None: FakeSeparator(),
        )
        monkeypatch.setattr("autolrc.pipeline.get_aligner", lambda name: FakeAligner())

        run = AutoLRCService().align(
            AlignRequest(audio_path=audio_path, lyrics_path=lyrics_path, engine="baseline")
        )

        assert run.report["low_confidence"] is False
        assert run.report["recommended_action"] is None
    finally:
        shutil.rmtree(test_dir, ignore_errors=True)


def test_batch_align_discovers_same_directory_pairs_and_skips_unmatched_audio() -> None:
    test_dir = _make_test_dir("pipeline-batch-discovery")
    try:
        _write_silent_wav(test_dir / "alpha.wav")
        _write_text_fixture(test_dir / "alpha.txt")
        _write_dummy_mp3(test_dir / "beta.mp3")
        _write_text_fixture(test_dir / "beta.txt")
        _write_silent_wav(test_dir / "duo.wav")
        _write_dummy_mp3(test_dir / "duo.mp3")
        _write_text_fixture(test_dir / "duo.txt")
        _write_silent_wav(test_dir / "orphan.wav")
        nested_dir = test_dir / "nested"
        nested_dir.mkdir()
        _write_silent_wav(nested_dir / "ignored.wav")
        _write_text_fixture(nested_dir / "ignored.txt")

        run = AutoLRCService().batch_align(BatchAlignRequest(audio_dir=test_dir, engine="baseline"))

        assert run.matched_count == 3
        assert run.succeeded_count == 3
        assert run.low_confidence_count == 0
        assert run.failed_count == 0
        assert run.skipped_count == 2
        assert [(item.stem, item.status, item.audio_path.name) for item in run.items] == [
            ("alpha", "success", "alpha.wav"),
            ("beta", "success", "beta.mp3"),
            ("duo", "success", "duo.wav"),
            ("duo", "skipped", "duo.mp3"),
            ("orphan", "skipped", "orphan.wav"),
        ]
    finally:
        shutil.rmtree(test_dir, ignore_errors=True)


def test_batch_align_writes_lrc_metadata_and_leaves_audio_untouched_when_artist_is_set() -> None:
    test_dir = _make_test_dir("pipeline-batch-lrc-metadata")
    try:
        audio_path = test_dir / "alpha.wav"
        lyrics_path = test_dir / "alpha.txt"
        _write_silent_wav(audio_path)
        _write_text_fixture(lyrics_path)
        original_audio = audio_path.read_bytes()

        run = AutoLRCService().batch_align(
            BatchAlignRequest(
                audio_dir=test_dir,
                artist="Batch Artist",
                engine="baseline",
            )
        )

        assert run.succeeded_count == 1
        item = run.items[0]
        assert item.status == "success"
        assert item.run is not None
        assert audio_path.read_bytes() == original_audio
        assert item.run.report_path is None

        lrc_output = item.run.output_path.read_text(encoding="utf-8")
        assert "[ar:Batch Artist]" in lrc_output
        assert "[ti:alpha]" in lrc_output
    finally:
        shutil.rmtree(test_dir, ignore_errors=True)


def test_batch_align_without_artist_keeps_lrc_metadata_free() -> None:
    test_dir = _make_test_dir("pipeline-batch-no-lrc-metadata")
    try:
        audio_path = test_dir / "alpha.wav"
        lyrics_path = test_dir / "alpha.txt"
        _write_silent_wav(audio_path)
        _write_text_fixture(lyrics_path)

        run = AutoLRCService().batch_align(BatchAlignRequest(audio_dir=test_dir, engine="baseline"))

        assert run.succeeded_count == 1
        item = run.items[0]
        assert item.run is not None
        lrc_output = item.run.output_path.read_text(encoding="utf-8")
        assert "[ar:" not in lrc_output
        assert "[ti:" not in lrc_output
    finally:
        shutil.rmtree(test_dir, ignore_errors=True)


def test_batch_align_writes_per_track_json_reports_when_enabled() -> None:
    test_dir = _make_test_dir("pipeline-batch-json-report")
    try:
        _write_silent_wav(test_dir / "alpha.wav")
        _write_text_fixture(test_dir / "alpha.txt")
        _write_dummy_mp3(test_dir / "beta.mp3")
        _write_text_fixture(test_dir / "beta.txt")

        run = AutoLRCService().batch_align(
            BatchAlignRequest(audio_dir=test_dir, engine="baseline", write_json_report=True)
        )

        assert run.succeeded_count == 2
        assert (test_dir / "alpha.json").exists()
        assert (test_dir / "beta.json").exists()
        assert all(item.run is None or item.run.report_path is not None for item in run.items)
    finally:
        shutil.rmtree(test_dir, ignore_errors=True)


def test_batch_align_continues_after_failure_and_keeps_later_tracks_running() -> None:
    test_dir = _make_test_dir("pipeline-batch-failure")
    try:
        _write_silent_wav(test_dir / "alpha.wav")
        _write_text_fixture(test_dir / "alpha.txt")
        _write_silent_wav(test_dir / "broken.wav")
        (test_dir / "broken.txt").write_text("[]\n{}\n", encoding="utf-8")
        _write_silent_wav(test_dir / "charlie.wav")
        _write_text_fixture(test_dir / "charlie.txt")

        run = AutoLRCService().batch_align(BatchAlignRequest(audio_dir=test_dir, engine="baseline"))

        assert run.matched_count == 3
        assert run.succeeded_count == 2
        assert run.low_confidence_count == 0
        assert run.failed_count == 1
        assert run.skipped_count == 0
        assert [(item.stem, item.status) for item in run.items] == [
            ("alpha", "success"),
            ("broken", "failure"),
            ("charlie", "success"),
        ]
        assert run.items[1].message == "No lyric lines remain after normalization."
    finally:
        shutil.rmtree(test_dir, ignore_errors=True)
