from __future__ import annotations

import collections
import contextlib
import importlib
import importlib.util
import re
import shutil
import subprocess
import time
import unicodedata
import warnings
from collections.abc import Iterator
from dataclasses import dataclass
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any, Protocol

from autolrc.models import AlignmentResult, LineAlignment, LyricsDocument, LyricsLine, WordAlignment

SPACE_RE = re.compile(r"\s+")
BRACKETED_SPAN_PATTERNS = (
    re.compile(r"\([^()]*\)"),
    re.compile(r"\{[^{}]*\}"),
    re.compile(r"\[[^[\]]*\]"),
)
EMOJI_RE = re.compile(
    "["
    "\U0001f1e6-\U0001f1ff"
    "\U0001f300-\U0001f5ff"
    "\U0001f600-\U0001f64f"
    "\U0001f680-\U0001f6ff"
    "\U0001f700-\U0001f77f"
    "\U0001f780-\U0001f7ff"
    "\U0001f800-\U0001f8ff"
    "\U0001f900-\U0001f9ff"
    "\U0001fa00-\U0001faff"
    "\U00002600-\U000026ff"
    "\U00002700-\U000027bf"
    "]",
    flags=re.UNICODE,
)
EMOJI_JOINER_RE = re.compile(r"[\u200d\u20e3\ufe0e\ufe0f]")
APOSTROPHE_TRANSLATION = str.maketrans(
    {
        "‘": "'",
        "’": "'",
        "＇": "'",
        "“": '"',
        "”": '"',
    }
)
DEFAULT_MODEL_NAME = "medium"
DEFAULT_ALIGNMENT_DEVICE = "auto"
SUPPORTED_ALIGNMENT_DEVICES = {"auto", "cpu", "cuda"}
LANGUAGE_DETECTION_WINDOW_SECONDS = 20.0
SHORT_LANGUAGE_DETECTION_WINDOW_SECONDS = 15.0
LANGUAGE_DETECTION_WINDOW_CENTERS = (0.2, 0.5, 0.8)
_MODEL_CACHE: dict[tuple[str, str], Any] = {}

# Fuzzy segment-to-line matching
FUZZY_MATCH_WINDOW = 4       # how many segments ahead of cursor to search
FUZZY_MATCH_MIN_SCORE = 25   # score below this uses the cursor segment anyway


@contextlib.contextmanager
def _silence_stable_ts_noise(*, enabled: bool) -> Iterator[None]:
    """Temporarily silence stable-ts's internal progress bars and warnings.

    stable-ts exposes a ``verbose`` flag that controls its top-level "Align"
    progress bar, but the "Adjustment" bar in ``stable_whisper.result`` is
    hardcoded with ``disable=not verbose`` where ``verbose`` is wired to a
    check that is always truthy. To silence it cleanly we swap in a forced-
    disabled tqdm inside ``stable_whisper.result`` for the duration of the
    call, and we also swallow the library's UserWarnings so the overall batch
    progress bar stays on a single line.
    """
    if not enabled:
        yield
        return

    try:
        sw_result = importlib.import_module("stable_whisper.result")
    except Exception:  # pragma: no cover - defensive; module should exist if we got here
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            yield
        return

    original_tqdm = sw_result.tqdm

    def _disabled_tqdm(*args: Any, **kwargs: Any):
        kwargs["disable"] = True
        return original_tqdm(*args, **kwargs)

    sw_result.tqdm = _disabled_tqdm
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            yield
    finally:
        sw_result.tqdm = original_tqdm


@dataclass(slots=True)
class LyricsNormalizer:
    strip_bracketed_notes: bool = True

    def preprocess_line(self, line: str) -> str:
        cleaned = unicodedata.normalize("NFKC", line).translate(APOSTROPHE_TRANSLATION).strip()
        if self.strip_bracketed_notes:
            cleaned = _strip_bracketed_spans(cleaned)
        cleaned = _strip_emoji(cleaned)
        return SPACE_RE.sub(" ", cleaned).strip()

    def normalize_line(self, line: str) -> str:
        return _normalize_alignment_text(self.preprocess_line(line))

    def read(self, path: Path) -> LyricsDocument:
        raw_text = path.read_text(encoding="utf-8-sig")
        lines: list[LyricsLine] = []
        for line_number, original in enumerate(raw_text.splitlines(), start=1):
            cleaned = self.preprocess_line(original)
            if not cleaned:
                continue
            normalized = _normalize_alignment_text(cleaned)
            token_count = count_lyric_units(normalized)
            lines.append(
                LyricsLine(
                    line_number=line_number,
                    original_text=cleaned,
                    normalized_text=normalized,
                    token_count=token_count,
                )
            )
        return LyricsDocument(source_path=path, raw_text=raw_text, lines=lines)


@dataclass(slots=True)
class LanguageResolution:
    language: str
    source: str
    candidates: tuple[str, ...] = ()


class AlignerBackend(Protocol):
    name: str

    def align(
        self,
        audio_path: Path,
        lyrics: LyricsDocument,
        *,
        language: str | None = None,
        model_name: str = DEFAULT_MODEL_NAME,
        device: str = DEFAULT_ALIGNMENT_DEVICE,
        quiet: bool = False,
    ) -> AlignmentResult: ...


class BaselineAligner:
    name = "baseline"

    def align(
        self,
        audio_path: Path,
        lyrics: LyricsDocument,
        *,
        language: str | None = None,
        model_name: str = DEFAULT_MODEL_NAME,
        device: str = DEFAULT_ALIGNMENT_DEVICE,
        quiet: bool = False,
    ) -> AlignmentResult:
        del audio_path, language, model_name, quiet
        started_at = time.perf_counter()
        cursor = 0.5
        alignments: list[LineAlignment] = []

        for line in lyrics.lines:
            duration = min(7.5, max(1.8, line.token_count * 0.48))
            start = round(cursor, 2)
            end = round(cursor + duration, 2)
            alignments.append(
                LineAlignment(
                    line_number=line.line_number,
                    text=line.original_text,
                    start=start,
                    end=end,
                    coverage_ratio=1.0,
                    confidence=0.25,
                )
            )
            cursor = end + 0.35

        runtime_seconds = time.perf_counter() - started_at
        return AlignmentResult(
            engine_name=self.name,
            line_alignments=alignments,
            runtime_seconds=runtime_seconds,
            metadata={
                "mode": "deterministic-baseline",
                "model_name": None,
                "requested_device": device,
                "resolved_device": None,
                "backend_diagnostics": {},
            },
        )


class StableTsAligner:
    name = "stable-ts"

    def align(
        self,
        audio_path: Path,
        lyrics: LyricsDocument,
        *,
        language: str | None = None,
        model_name: str = DEFAULT_MODEL_NAME,
        device: str = DEFAULT_ALIGNMENT_DEVICE,
        quiet: bool = False,
    ) -> AlignmentResult:
        diagnostics = get_runtime_diagnostics()
        if not diagnostics["ffmpeg_available"]:
            raise RuntimeError(
                "ffmpeg is required for stable-ts alignment but was not found in PATH."
            )
        if not diagnostics["stable_ts_available"]:
            raise RuntimeError(
                "stable-ts is not installed. Install the optional CPU or GPU dependencies first."
            )

        resolved_device, diagnostics = resolve_alignment_device(device, diagnostics=diagnostics)

        try:
            stable_whisper = importlib.import_module("stable_whisper")
        except Exception as exc:  # pragma: no cover - depends on optional runtime
            raise RuntimeError(
                "stable-ts could not be imported. "
                "Check that stable-ts and PyTorch are installed correctly."
            ) from exc

        try:
            model = load_stable_ts_model(stable_whisper, model_name, resolved_device)
        except Exception as exc:  # pragma: no cover - depends on optional runtime
            raise RuntimeError(
                f"Failed to load stable-ts model '{model_name}' on '{resolved_device}': {exc}"
            ) from exc

        language_resolution = resolve_alignment_language(
            lyrics,
            model=model,
            audio_path=audio_path,
            requested_language=language,
        )
        text = "\n".join(line.normalized_text for line in lyrics.lines)
        started_at = time.perf_counter()
        align_kwargs = {
            "original_split": True,
            "presplit": True,
            "gap_padding": " ...",
            "suppress_silence": True,
            # verbose=False: show progress bar only
            # verbose=None: show nothing (used for batch mode, where a single
            # overall progress bar wraps the whole run)
            "verbose": None if quiet else False,
        }
        align_kwargs["language"] = language_resolution.language
        try:
            with _silence_stable_ts_noise(enabled=quiet):
                stable_result = model.align(
                    str(audio_path),
                    text,
                    **align_kwargs,
                )
        except Exception as exc:  # pragma: no cover - depends on optional runtime
            raise RuntimeError(f"stable-ts alignment failed: {exc}") from exc

        if stable_result is None:
            raise RuntimeError("stable-ts returned no alignment result for the provided lyrics.")

        runtime_seconds = time.perf_counter() - started_at
        return build_stable_ts_alignment_result(
            lyrics,
            stable_result,
            model_name=model_name,
            requested_device=device,
            resolved_device=resolved_device,
            language_resolution=language_resolution,
            diagnostics=diagnostics,
            runtime_seconds=runtime_seconds,
        )


def contains_cjk(text: str) -> bool:
    for character in text:
        codepoint = ord(character)
        if (
            0x3400 <= codepoint <= 0x4DBF
            or 0x4E00 <= codepoint <= 0x9FFF
            or 0x3040 <= codepoint <= 0x30FF
            or 0xAC00 <= codepoint <= 0xD7AF
            or 0xF900 <= codepoint <= 0xFAFF
        ):
            return True
    return False


def tokenize_lyric_units(text: str) -> tuple[str, ...]:
    if contains_cjk(text):
        return tuple(character for character in text if _is_cjk_unit_character(character))
    return tuple(token for token in text.split() if token)


def count_lyric_units(text: str) -> int:
    return max(1, len(tokenize_lyric_units(text)))


def get_runtime_diagnostics() -> dict[str, Any]:
    ffmpeg_path = shutil.which("ffmpeg")
    diagnostics: dict[str, Any] = {
        "ffmpeg_available": ffmpeg_path is not None,
        "ffmpeg_path": ffmpeg_path,
        "stable_ts_available": importlib.util.find_spec("stable_whisper") is not None,
        "torch_available": importlib.util.find_spec("torch") is not None,
        "torch_version": None,
        "cuda_available": False,
    }

    if diagnostics["torch_available"]:
        try:
            torch = importlib.import_module("torch")
        except Exception as exc:  # pragma: no cover - depends on optional runtime
            diagnostics["torch_error"] = str(exc)
        else:
            diagnostics["torch_version"] = getattr(torch, "__version__", "installed")
            try:
                diagnostics["cuda_available"] = bool(torch.cuda.is_available())
            except Exception as exc:  # pragma: no cover - depends on optional runtime
                diagnostics["cuda_error"] = str(exc)

    return diagnostics


def resolve_alignment_device(
    requested_device: str,
    *,
    diagnostics: dict[str, Any] | None = None,
) -> tuple[str, dict[str, Any]]:
    normalized = requested_device.strip().lower()
    if normalized not in SUPPORTED_ALIGNMENT_DEVICES:
        expected_devices = ", ".join(sorted(SUPPORTED_ALIGNMENT_DEVICES))
        raise ValueError(
            f"Unsupported alignment device: {requested_device}. "
            f"Expected one of: {expected_devices}."
        )

    runtime_diagnostics = dict(diagnostics or get_runtime_diagnostics())
    cuda_available = bool(runtime_diagnostics.get("cuda_available"))

    if normalized == "auto":
        return ("cuda" if cuda_available else "cpu"), runtime_diagnostics
    if normalized == "cuda" and not cuda_available:
        raise RuntimeError(
            "CUDA was requested but is not available. Install a CUDA-enabled PyTorch build "
            "or run with --device cpu."
        )
    return normalized, runtime_diagnostics


def load_stable_ts_model(stable_whisper: Any, model_name: str, resolved_device: str) -> Any:
    key = (model_name, resolved_device)
    if key not in _MODEL_CACHE:
        _MODEL_CACHE[key] = stable_whisper.load_model(model_name, device=resolved_device)
    return _MODEL_CACHE[key]


def resolve_alignment_language(
    lyrics: LyricsDocument,
    *,
    model: Any,
    audio_path: Path,
    requested_language: str | None,
) -> LanguageResolution:
    if requested_language:
        return LanguageResolution(
            language=requested_language,
            source="explicit",
            candidates=(requested_language,),
        )

    script_resolution = infer_language_from_lyrics(lyrics)
    if script_resolution is not None:
        return script_resolution

    return detect_alignment_language_from_audio(model, audio_path)


def infer_language_from_lyrics(lyrics: LyricsDocument) -> LanguageResolution | None:
    han_count = 0
    hangul_count = 0
    kana_present = False
    counted_characters = 0

    for line in lyrics.lines:
        for character in line.original_text:
            if _should_ignore_language_character(character):
                continue
            counted_characters += 1
            if _is_kana(character):
                kana_present = True
            elif _is_hangul(character):
                hangul_count += 1
            elif _is_han(character):
                han_count += 1

    if kana_present:
        return LanguageResolution(language="ja", source="lyrics-script", candidates=("ja",))
    if counted_characters and hangul_count / counted_characters >= 0.5:
        return LanguageResolution(language="ko", source="lyrics-script", candidates=("ko",))
    if counted_characters and han_count / counted_characters >= 0.5:
        return LanguageResolution(language="zh", source="lyrics-script", candidates=("zh",))
    return None


def detect_alignment_language_from_audio(model: Any, audio_path: Path) -> LanguageResolution:
    duration_seconds = get_audio_duration_seconds(audio_path)
    candidates: list[str] = []

    for clip in build_language_detection_clips(duration_seconds):
        try:
            preview_result = model.transcribe(
                str(audio_path),
                clip_timestamps=clip,
                word_timestamps=False,
                verbose=None,
            )
        except Exception as exc:  # pragma: no cover - depends on optional runtime
            raise RuntimeError(
                "stable-ts could not detect the lyric language automatically. "
                "Re-run the command with --lang <language-code>."
            ) from exc

        detected_language = str(_get_value(preview_result, "language", default="") or "").strip()
        if detected_language:
            candidates.append(detected_language)

    if not candidates:
        raise RuntimeError(
            "stable-ts could not detect the lyric language automatically. "
            "Re-run the command with --lang <language-code>."
        )

    counts = collections.Counter(candidates).most_common()
    if len(counts) > 1 and counts[0][1] == counts[1][1]:
        raise RuntimeError(
            "stable-ts language detection was inconclusive across the sampled audio windows. "
            "Re-run the command with --lang <language-code>."
        )

    return LanguageResolution(
        language=counts[0][0],
        source="audio-vote",
        candidates=tuple(candidates),
    )


def get_audio_duration_seconds(audio_path: Path) -> float:
    ffprobe_path = shutil.which("ffprobe")
    if ffprobe_path is None:
        raise RuntimeError(
            "ffprobe is required for automatic language detection. "
            "Install ffmpeg or re-run the command with --lang <language-code>."
        )

    command = [
        ffprobe_path,
        "-v",
        "error",
        "-show_entries",
        "format=duration",
        "-of",
        "default=noprint_wrappers=1:nokey=1",
        str(audio_path),
    ]
    try:
        completed = subprocess.run(
            command,
            capture_output=True,
            check=True,
            text=True,
        )
    except (OSError, subprocess.CalledProcessError) as exc:
        raise RuntimeError(
            "ffprobe could not read the audio duration for automatic language detection. "
            "Re-run the command with --lang <language-code>."
        ) from exc

    try:
        duration_seconds = float(completed.stdout.strip())
    except ValueError as exc:
        raise RuntimeError(
            "ffprobe returned an invalid audio duration for automatic language detection. "
            "Re-run the command with --lang <language-code>."
        ) from exc

    if duration_seconds <= 0:
        raise RuntimeError(
            "ffprobe returned an invalid audio duration for automatic language detection. "
            "Re-run the command with --lang <language-code>."
        )
    return duration_seconds


def build_language_detection_clips(duration_seconds: float) -> tuple[str, ...]:
    window_seconds = (
        LANGUAGE_DETECTION_WINDOW_SECONDS
        if duration_seconds >= 90.0
        else SHORT_LANGUAGE_DETECTION_WINDOW_SECONDS
    )
    if duration_seconds <= window_seconds:
        return (f"0,{duration_seconds:.3f}",)

    clips: list[str] = []
    for center_ratio in LANGUAGE_DETECTION_WINDOW_CENTERS:
        center = duration_seconds * center_ratio
        start = max(0.0, center - (window_seconds / 2))
        end = min(duration_seconds, start + window_seconds)
        start = max(0.0, end - window_seconds)
        clip = f"{start:.3f},{end:.3f}"
        if clip not in clips:
            clips.append(clip)
    return tuple(clips)


def build_stable_ts_alignment_result(
    lyrics: LyricsDocument,
    stable_result: Any,
    *,
    model_name: str,
    requested_device: str,
    resolved_device: str,
    language_resolution: LanguageResolution,
    diagnostics: dict[str, Any],
    runtime_seconds: float,
) -> AlignmentResult:
    segments = list(_get_value(stable_result, "segments", default=()) or ())
    line_alignments: list[LineAlignment] = []

    assignments = _build_fuzzy_line_assignments(lyrics.lines, segments)
    matched_count = sum(1 for a in assignments if a is not None)

    for index, line in enumerate(lyrics.lines):
        seg_idx = assignments[index]
        if seg_idx is None:
            line_alignments.append(_unresolved_line(line))
            continue

        segment = segments[seg_idx]
        aligned_text = _normalize_alignment_text(str(_get_value(segment, "text", default="")))
        coverage_ratio, unaligned_tokens = _coverage_details(line.normalized_text, aligned_text)
        start = _coerce_float(_get_value(segment, "start"))
        end = _coerce_float(_get_value(segment, "end"))
        confidence = _segment_confidence(segment, coverage_ratio)
        words = _extract_word_alignments(segment)

        line_alignments.append(
            LineAlignment(
                line_number=line.line_number,
                text=line.original_text,
                start=start,
                end=end,
                coverage_ratio=coverage_ratio,
                confidence=confidence,
                unaligned_tokens=unaligned_tokens,
                words=words,
            )
        )

    return AlignmentResult(
        engine_name="stable-ts",
        line_alignments=line_alignments,
        runtime_seconds=runtime_seconds,
        metadata={
            "mode": "stable-ts",
            "model_name": model_name,
            "requested_device": requested_device,
            "resolved_device": resolved_device,
            "resolved_language": language_resolution.language,
            "language_source": language_resolution.source,
            "language_candidates": list(language_resolution.candidates),
            "backend_diagnostics": diagnostics,
            "segment_count": len(segments),
            "matched_line_count": matched_count,
        },
    )


def _build_fuzzy_line_assignments(
    lyrics_lines: list[LyricsLine],
    segments: list,
) -> list[int | None]:
    """Monotone greedy fuzzy assignment of whisper segments to lyric lines.

    For each line, searches up to FUZZY_MATCH_WINDOW segments ahead of the
    cursor for the best text similarity. Falls back to the cursor segment
    (positional) when all scores are below FUZZY_MATCH_MIN_SCORE, ensuring
    lines are never left unresolved due to a failed fuzzy search alone.
    """
    try:
        from rapidfuzz import fuzz as _fuzz
        _scorer = _fuzz.token_set_ratio
    except ImportError:
        _scorer = None

    assignments: list[int | None] = []
    cursor = 0

    for line in lyrics_lines:
        if cursor >= len(segments):
            assignments.append(None)
            continue

        end = min(cursor + FUZZY_MATCH_WINDOW + 1, len(segments))
        best_idx = cursor
        best_score = -1.0

        if _scorer is not None:
            for seg_idx in range(cursor, end):
                seg_text = _normalize_alignment_text(
                    str(_get_value(segments[seg_idx], "text", default=""))
                )
                score = float(_scorer(line.normalized_text, seg_text))
                if score > best_score:
                    best_score = score
                    best_idx = seg_idx

        assignments.append(best_idx)
        cursor = best_idx + 1

    return assignments


def _extract_word_alignments(segment: Any) -> tuple[WordAlignment, ...]:
    """Extract word-level timestamps from a stable-ts segment."""
    words_raw = _get_value(segment, "words", default=()) or ()
    result: list[WordAlignment] = []
    for word_obj in words_raw:
        word_text = str(_get_value(word_obj, "word", default="")).strip()
        if not word_text:
            continue
        start = _coerce_float(_get_value(word_obj, "start"))
        end = _coerce_float(_get_value(word_obj, "end"))
        if start is None or end is None:
            continue
        result.append(WordAlignment(word=word_text, start=start, end=end))
    return tuple(result)


def _is_cjk_unit_character(character: str) -> bool:
    category = unicodedata.category(character)
    return not character.isspace() and not category.startswith(("P", "S", "C"))


def _should_ignore_language_character(character: str) -> bool:
    category = unicodedata.category(character)
    return category.startswith(("P", "S", "N", "Z", "C"))


def _is_han(character: str) -> bool:
    codepoint = ord(character)
    return (
        0x3400 <= codepoint <= 0x4DBF
        or 0x4E00 <= codepoint <= 0x9FFF
        or 0xF900 <= codepoint <= 0xFAFF
    )


def _is_hangul(character: str) -> bool:
    codepoint = ord(character)
    return 0xAC00 <= codepoint <= 0xD7AF


def _is_kana(character: str) -> bool:
    codepoint = ord(character)
    return 0x3040 <= codepoint <= 0x30FF


def _strip_bracketed_spans(text: str) -> str:
    cleaned = text
    while True:
        previous = cleaned
        for pattern in BRACKETED_SPAN_PATTERNS:
            cleaned = pattern.sub(" ", cleaned)
        if cleaned == previous:
            return cleaned


def _strip_emoji(text: str) -> str:
    return EMOJI_JOINER_RE.sub("", EMOJI_RE.sub("", text))


def _normalize_alignment_text(text: str) -> str:
    normalized = unicodedata.normalize("NFKC", text).translate(APOSTROPHE_TRANSLATION)
    return SPACE_RE.sub(" ", normalized).strip()


def _coverage_details(expected_text: str, actual_text: str) -> tuple[float, tuple[str, ...]]:
    expected_units = tokenize_lyric_units(expected_text)
    actual_units = tokenize_lyric_units(actual_text)
    if not expected_units:
        return 0.0, ()

    matcher = SequenceMatcher(a=expected_units, b=actual_units)
    matched_units = sum(block.size for block in matcher.get_matching_blocks())
    unaligned: list[str] = []
    for tag, expected_start, expected_end, _actual_start, _actual_end in matcher.get_opcodes():
        if tag in {"delete", "replace"}:
            unaligned.extend(expected_units[expected_start:expected_end])
    coverage_ratio = round(min(1.0, matched_units / len(expected_units)), 4)
    return coverage_ratio, tuple(unaligned)


def _segment_confidence(segment: Any, coverage_ratio: float) -> float:
    words = _get_value(segment, "words", default=()) or ()
    probabilities = [
        probability
        for probability in (
            _coerce_probability(_get_value(word, "probability", "prob", "confidence"))
            for word in words
        )
        if probability is not None
    ]
    if probabilities:
        return round(sum(probabilities) / len(probabilities), 4)
    return round(coverage_ratio, 4)


def _coerce_probability(value: Any) -> float | None:
    coerced = _coerce_float(value)
    if coerced is None:
        return None
    return max(0.0, min(1.0, coerced))


def _coerce_float(value: Any) -> float | None:
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _get_value(container: Any, *names: str, default: Any = None) -> Any:
    if container is None:
        return default
    if isinstance(container, dict):
        for name in names:
            if name in container:
                return container[name]
        return default
    for name in names:
        if hasattr(container, name):
            return getattr(container, name)
    return default


def _unresolved_line(line: LyricsLine) -> LineAlignment:
    return LineAlignment(
        line_number=line.line_number,
        text=line.original_text,
        start=None,
        end=None,
        coverage_ratio=0.0,
        confidence=0.0,
        unaligned_tokens=tokenize_lyric_units(line.normalized_text),
    )


def get_aligner(name: str) -> AlignerBackend:
    normalized = name.strip().lower()
    if normalized == "baseline":
        return BaselineAligner()
    if normalized == "stable-ts":
        return StableTsAligner()
    raise ValueError(f"Unsupported alignment engine: {name}")
