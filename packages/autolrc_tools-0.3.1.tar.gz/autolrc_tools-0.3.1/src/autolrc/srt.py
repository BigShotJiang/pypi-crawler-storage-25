from __future__ import annotations

from collections.abc import Iterable

from autolrc.models import LineAlignment


def format_srt_timestamp(seconds: float) -> str:
    total_milliseconds = max(0, round(seconds * 1000))
    hours, remainder = divmod(total_milliseconds, 3_600_000)
    minutes, remainder = divmod(remainder, 60_000)
    whole_seconds, milliseconds = divmod(remainder, 1000)
    return f"{hours:02d}:{minutes:02d}:{whole_seconds:02d},{milliseconds:03d}"


def render_srt(alignments: Iterable[LineAlignment]) -> str:
    resolved_lines = [
        alignment
        for alignment in alignments
        if alignment.start is not None and alignment.text.strip()
    ]
    if not resolved_lines:
        return ""

    blocks: list[str] = []
    for index, alignment in enumerate(resolved_lines, start=1):
        start = alignment.start
        assert start is not None
        end = _resolve_end(index - 1, resolved_lines)
        blocks.extend(
            [
                str(index),
                f"{format_srt_timestamp(start)} --> {format_srt_timestamp(end)}",
                alignment.text,
                "",
            ]
        )

    return "\n".join(blocks)


def _resolve_end(index: int, resolved_lines: list[LineAlignment]) -> float:
    current = resolved_lines[index]
    assert current.start is not None

    if current.end is not None and current.end > current.start:
        return current.end

    if index + 1 < len(resolved_lines):
        next_line = resolved_lines[index + 1]
        if next_line.start is not None and next_line.start > current.start:
            return next_line.start

    return current.start + 2.0
