from __future__ import annotations

import importlib
import importlib.metadata
import importlib.util
import logging
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

from autolrc.models import SeparationResult

DEFAULT_AUDIO_SEPARATOR_MODEL = "model_bs_roformer_ep_317_sdr_12.9755.ckpt"
AUDIO_SEPARATOR_INSTALL_HINT = (
    "Refresh the environment with `python -m pip install -e .[gpu,dev]` or "
    "`python -m pip install -e .[cpu,dev]`."
)
AUDIO_SEPARATOR_ENVIRONMENT_NOTE = (
    "Existing virtual environments do not automatically acquire newly added optional "
    "dependencies after a `pyproject.toml` extras change. " + AUDIO_SEPARATOR_INSTALL_HINT
)


@dataclass(frozen=True, slots=True)
class DependencyStatus:
    state: str
    message: str


class SeparatorBackend(Protocol):
    name: str

    def separate(self, audio_path: Path, work_dir: Path) -> SeparationResult: ...


class PassthroughSeparatorBackend:
    name = "none"

    def separate(self, audio_path: Path, work_dir: Path) -> SeparationResult:
        return SeparationResult(
            vocals_path=audio_path,
            instrumental_path=None,
            backend_name=self.name,
            runtime_seconds=0.0,
            metadata={"mode": "passthrough", "work_dir": str(work_dir)},
        )


class AudioSeparatorBackend:
    name = "audio-separator"

    def __init__(self, *, model_file_dir: Path) -> None:
        self.model_file_dir = model_file_dir

    def separate(self, audio_path: Path, work_dir: Path) -> SeparationResult:
        separator_class = _load_audio_separator_class()
        started_at = time.perf_counter()
        custom_output_names = {"Vocals": "vocals", "Instrumental": "instrumental"}

        try:
            separator = separator_class(
                log_level=logging.WARNING,
                model_file_dir=str(self.model_file_dir),
                output_dir=str(work_dir),
                output_format="WAV",
            )
            separator.load_model(DEFAULT_AUDIO_SEPARATOR_MODEL)
            output_files = separator.separate(
                str(audio_path),
                custom_output_names=custom_output_names,
            )
        except Exception as exc:  # pragma: no cover - depends on optional runtime
            raise RuntimeError(f"audio-separator failed to split the track: {exc}") from exc

        vocals_path = _resolve_stem_path(
            output_files,
            work_dir,
            preferred_names=("vocals.wav",),
            required=True,
        )
        instrumental_path = _resolve_stem_path(
            output_files,
            work_dir,
            preferred_names=("instrumental.wav",),
            required=False,
        )

        runtime_seconds = time.perf_counter() - started_at
        return SeparationResult(
            vocals_path=vocals_path,
            instrumental_path=instrumental_path,
            backend_name=self.name,
            runtime_seconds=runtime_seconds,
            metadata={
                "mode": "audio-separator",
                "model_name": DEFAULT_AUDIO_SEPARATOR_MODEL,
                "model_file_dir": str(self.model_file_dir),
                "output_files": [
                    str(path) for path in _candidate_output_paths(output_files, work_dir)
                ],
                "work_dir": str(work_dir),
            },
        )


def get_audio_separator_dependency_status() -> DependencyStatus:
    if importlib.util.find_spec("audio_separator") is None:
        return DependencyStatus(state="missing", message="missing")

    try:
        importlib.import_module("audio_separator.separator")
    except ModuleNotFoundError as exc:  # pragma: no cover - depends on optional runtime
        if exc.name and exc.name not in {"audio_separator", "audio_separator.separator"}:
            return DependencyStatus(
                state="broken",
                message=(
                    "broken (missing runtime dependency: "
                    f"{exc.name}. {AUDIO_SEPARATOR_ENVIRONMENT_NOTE})"
                ),
            )
        return DependencyStatus(
            state="broken",
            message=(
                "broken (audio-separator could not be imported. "
                f"{AUDIO_SEPARATOR_ENVIRONMENT_NOTE})"
            ),
        )
    except Exception as exc:  # pragma: no cover - depends on optional runtime
        return DependencyStatus(
            state="broken",
            message=(
                "broken (audio-separator import failed: "
                f"{exc.__class__.__name__}. {AUDIO_SEPARATOR_ENVIRONMENT_NOTE})"
            ),
        )

    try:
        version = importlib.metadata.version("audio-separator")
    except importlib.metadata.PackageNotFoundError:
        version = "installed"
    return DependencyStatus(state="installed", message=version)


def _load_audio_separator_class():
    dependency_status = get_audio_separator_dependency_status()
    if dependency_status.state == "missing":
        raise RuntimeError(f"audio-separator is not installed. {AUDIO_SEPARATOR_INSTALL_HINT}")
    if dependency_status.state == "broken":
        raise RuntimeError(
            "audio-separator is installed but not runnable. "
            + dependency_status.message.removeprefix("broken ").strip()
        )

    try:
        module = importlib.import_module("audio_separator.separator")
    except ModuleNotFoundError as exc:  # pragma: no cover - depends on optional runtime
        if exc.name and exc.name not in {"audio_separator", "audio_separator.separator"}:
            raise RuntimeError(
                "audio-separator is installed but missing a runtime dependency "
                f"({exc.name}). {AUDIO_SEPARATOR_ENVIRONMENT_NOTE}"
            ) from exc
        raise RuntimeError(
            "audio-separator could not be imported. " + AUDIO_SEPARATOR_ENVIRONMENT_NOTE
        ) from exc
    except Exception as exc:  # pragma: no cover - depends on optional runtime
        raise RuntimeError(
            "audio-separator could not be imported. " + AUDIO_SEPARATOR_ENVIRONMENT_NOTE
        ) from exc

    return module.Separator


def _candidate_output_paths(output_files: object, work_dir: Path) -> list[Path]:
    paths: list[Path] = []
    for value in output_files or []:
        path = Path(value)
        if not path.is_absolute():
            path = work_dir / path
        paths.append(path)
    return paths


def _resolve_stem_path(
    output_files: object,
    work_dir: Path,
    *,
    preferred_names: tuple[str, ...],
    required: bool,
) -> Path | None:
    candidate_paths = _candidate_output_paths(output_files, work_dir)
    available = {path.name.lower(): path for path in candidate_paths if path.exists()}

    for preferred_name in preferred_names:
        preferred_path = work_dir / preferred_name
        if preferred_path.exists():
            return preferred_path
        if preferred_name.lower() in available:
            return available[preferred_name.lower()]

    if candidate_paths:
        for path in candidate_paths:
            lowered = path.name.lower()
            if "vocals" in preferred_names[0] and "vocal" in lowered:
                return path
            if "instrumental" in preferred_names[0] and (
                "instrumental" in lowered or "karaoke" in lowered or "no_vocals" in lowered
            ):
                return path

    if required:
        raise RuntimeError(
            "audio-separator did not produce the expected stem files. "
            "Inspect the separator output and model configuration."
        )
    return None


def get_separator(name: str, *, cache_dir: Path | None = None) -> SeparatorBackend:
    normalized = name.strip().lower()
    if normalized in {"none", "passthrough"}:
        return PassthroughSeparatorBackend()
    if normalized == "audio-separator":
        model_file_dir = (cache_dir or Path(".autolrc-cache")) / "models" / "audio-separator"
        return AudioSeparatorBackend(model_file_dir=model_file_dir)
    raise ValueError(f"Unsupported separator backend: {name}")
