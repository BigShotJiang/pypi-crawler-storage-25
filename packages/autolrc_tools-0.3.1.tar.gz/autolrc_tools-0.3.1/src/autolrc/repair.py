from __future__ import annotations

import dataclasses
from typing import Protocol

from autolrc.models import AlignmentResult


class RepairBackend(Protocol):
    name: str

    def repair(self, result: AlignmentResult) -> AlignmentResult: ...


class NoOpRepairBackend:
    name = "none"

    def repair(self, result: AlignmentResult) -> AlignmentResult:
        return result


class TimingRepairBackend:
    """
    Conservative timing repair applied after alignment:
    1. Enforce a minimum line duration (extend short end times).
    2. Clamp end times that overlap the next line's start.
    3. Fill small silent gaps (<= 100 ms) between consecutive lines.
    """

    name = "timing"
    _MIN_DURATION = 0.5      # seconds — shortest allowed line duration
    _GAP_FILL_MAX = 0.1      # seconds — gaps <= this are filled
    _START_NUDGE = 0.01      # seconds — nudge applied to de-duplicate identical starts

    def repair(self, result: AlignmentResult) -> AlignmentResult:
        lines = result.line_alignments
        resolved = [i for i, line in enumerate(lines) if line.start is not None]
        if not resolved:
            return result

        repaired = list(lines)

        # Pass 0: ensure start times are strictly increasing
        for j in range(len(resolved) - 1):
            i, k = resolved[j], resolved[j + 1]
            curr, nxt = repaired[i], repaired[k]
            if nxt.start is not None and curr.start is not None and nxt.start <= curr.start:
                new_start = curr.start + self._START_NUDGE
                repaired[k] = dataclasses.replace(nxt, start=new_start)

        # Pass 1: enforce minimum line duration
        for i in resolved:
            line = repaired[i]
            if line.end is not None and line.end - line.start < self._MIN_DURATION:
                repaired[i] = dataclasses.replace(line, end=line.start + self._MIN_DURATION)

        # Pass 2: clamp end time to prevent overlap with the next resolved line
        for j in range(len(resolved) - 1):
            i, k = resolved[j], resolved[j + 1]
            curr, nxt = repaired[i], repaired[k]
            if curr.end is not None and nxt.start is not None and curr.end > nxt.start:
                repaired[i] = dataclasses.replace(curr, end=nxt.start)

        # Pass 3: fill small gaps between consecutive resolved lines
        for j in range(len(resolved) - 1):
            i, k = resolved[j], resolved[j + 1]
            curr, nxt = repaired[i], repaired[k]
            if curr.end is not None and nxt.start is not None:
                gap = nxt.start - curr.end
                if 0 < gap <= self._GAP_FILL_MAX:
                    repaired[i] = dataclasses.replace(curr, end=nxt.start)

        return dataclasses.replace(result, line_alignments=repaired)
