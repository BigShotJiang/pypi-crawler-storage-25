from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass(slots=True)
class WordAlignment:
    word: str
    start: float
    end: float


@dataclass(slots=True)
class LyricsLine:
    line_number: int
    original_text: str
    normalized_text: str
    token_count: int


@dataclass(slots=True)
class LyricsDocument:
    source_path: Path
    raw_text: str
    lines: list[LyricsLine]


@dataclass(slots=True)
class LineAlignment:
    line_number: int
    text: str
    start: float | None
    end: float | None
    coverage_ratio: float
    confidence: float
    unaligned_tokens: tuple[str, ...] = ()
    words: tuple[WordAlignment, ...] = ()


@dataclass(slots=True)
class AlignmentResult:
    engine_name: str
    line_alignments: list[LineAlignment]
    runtime_seconds: float
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class SeparationResult:
    vocals_path: Path
    instrumental_path: Path | None
    backend_name: str
    runtime_seconds: float
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class AlignmentRun:
    audio_path: Path
    lyrics_path: Path
    output_path: Path
    srt_output_path: Path
    vtt_output_path: Path
    saved_vocals_path: Path | None
    separator: SeparationResult
    alignment: AlignmentResult
    report: dict[str, Any]
    report_path: Path | None
    work_dir: Path | None = None


@dataclass(slots=True)
class BatchItemResult:
    stem: str
    audio_path: Path
    lyrics_path: Path | None
    status: str
    run: AlignmentRun | None = None
    message: str | None = None


@dataclass(slots=True)
class BatchAlignmentRun:
    audio_dir: Path
    items: list[BatchItemResult]
    matched_count: int
    succeeded_count: int
    low_confidence_count: int
    failed_count: int
    skipped_count: int
