from importlib.metadata import PackageNotFoundError, version

from autolrc.pipeline import AlignRequest, AutoLRCService, BatchAlignRequest

try:
    __version__ = version("autolrc")
except PackageNotFoundError:
    __version__ = "0.1.1"

__all__ = ["AlignRequest", "BatchAlignRequest", "AutoLRCService", "__version__"]
