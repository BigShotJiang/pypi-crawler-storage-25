from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Final

from tqdm import tqdm

from autolrc.aligner import (
    DEFAULT_ALIGNMENT_DEVICE,
    DEFAULT_MODEL_NAME,
    LyricsNormalizer,
    get_aligner,
)
from autolrc.lrc import render_enhanced_lrc, render_lrc
from autolrc.models import AlignmentRun, BatchAlignmentRun, BatchItemResult
from autolrc.repair import RepairBackend, TimingRepairBackend
from autolrc.separator import get_separator
from autolrc.srt import render_srt
from autolrc.vtt import render_vtt

DEFAULT_CACHE_DIR = Path(".autolrc-cache")
LOW_CONFIDENCE_THRESHOLD = 0.5
BATCH_AUDIO_SUFFIXES: Final[tuple[str, ...]] = (".wav", ".flac", ".mp3")
# Priority order for audio format selection when multiple exist for one stem
_AUDIO_PRIORITY: Final[tuple[str, ...]] = (".wav", ".flac", ".mp3")


@dataclass(slots=True)
class AlignRequest:
    audio_path: Path
    lyrics_path: Path
    output_path: Path | None = None
    title: str | None = None
    artist: str | None = None
    language: str | None = None
    engine: str = "stable-ts"
    model: str = DEFAULT_MODEL_NAME
    device: str = DEFAULT_ALIGNMENT_DEVICE
    separator: str | None = None
    separator_boost: bool = False
    save_vocals: bool = False
    keep_temp: bool = False
    write_json_report: bool = False
    enhanced_lrc: bool = False
    skip_existing: bool = False
    quiet: bool = False


@dataclass(slots=True)
class BatchAlignRequest:
    audio_dir: Path
    artist: str | None = None
    engine: str = "stable-ts"
    model: str = DEFAULT_MODEL_NAME
    device: str = DEFAULT_ALIGNMENT_DEVICE
    separator: str | None = None
    separator_boost: bool = False
    save_vocals: bool = False
    keep_temp: bool = False
    write_json_report: bool = False
    enhanced_lrc: bool = False
    skip_existing: bool = False
    recursive: bool = False


@dataclass(slots=True)
class _DiscoveredBatchTrack:
    stem: str
    audio_path: Path
    lyrics_path: Path


class AutoLRCService:
    def __init__(
        self,
        *,
        cache_dir: Path = DEFAULT_CACHE_DIR,
        normalizer: LyricsNormalizer | None = None,
        repair_backend: RepairBackend | None = None,
    ) -> None:
        self.cache_dir = cache_dir
        self.normalizer = normalizer or LyricsNormalizer()
        self.repair_backend = repair_backend or TimingRepairBackend()

    def inspect_lyrics(self, lyrics_path: Path):
        return self.normalizer.read(lyrics_path)

    def align(self, request: AlignRequest) -> AlignmentRun:
        audio_path = request.audio_path.resolve()
        lyrics_path = request.lyrics_path.resolve()
        output_path = (request.output_path or audio_path.with_suffix(".lrc")).resolve()
        srt_output_path = output_path.with_suffix(".srt")
        vtt_output_path = output_path.with_suffix(".vtt")
        report_path = (
            output_path.with_suffix(".json").resolve() if request.write_json_report else None
        )
        resolved_separator_name = self._resolve_separator_name(request)
        saved_vocals_path = output_path.with_suffix(".vocals.wav") if request.save_vocals else None

        if request.save_vocals and resolved_separator_name == "none":
            raise ValueError(
                "Saving vocals requires real separation. Re-run with --separator-boost."
            )

        if request.skip_existing and output_path.exists():
            raise _SkipExistingError(output_path)

        output_path.parent.mkdir(parents=True, exist_ok=True)
        if report_path is not None:
            report_path.parent.mkdir(parents=True, exist_ok=True)
        if saved_vocals_path is not None:
            saved_vocals_path.parent.mkdir(parents=True, exist_ok=True)

        document = self.normalizer.read(lyrics_path)
        if not document.lines:
            raise ValueError("No lyric lines remain after normalization.")

        run_key = self._build_run_key(
            audio_path,
            lyrics_path,
            request.engine,
            request.model,
            request.device,
            resolved_separator_name,
        )
        work_dir = self.cache_dir / "runs" / run_key
        if work_dir.exists():
            shutil.rmtree(work_dir)
        work_dir.mkdir(parents=True, exist_ok=True)

        try:
            separator = get_separator(resolved_separator_name, cache_dir=self.cache_dir)
            separation = separator.separate(audio_path, work_dir)
            aligner = get_aligner(request.engine)
            alignment = aligner.align(
                separation.vocals_path,
                document,
                language=request.language,
                model_name=request.model,
                device=request.device,
                quiet=request.quiet,
            )
            alignment = self.repair_backend.repair(alignment)

            resolved_language = alignment.metadata.get("resolved_language") if alignment.metadata else None
            metadata_tags = self._metadata_tags(request, resolved_language=resolved_language)
            lrc_renderer = render_enhanced_lrc if request.enhanced_lrc else render_lrc
            lrc_text = lrc_renderer(alignment.line_alignments, metadata=metadata_tags)
            srt_text = render_srt(alignment.line_alignments)
            vtt_text = render_vtt(alignment.line_alignments)
            output_path.write_text(lrc_text, encoding="utf-8")
            srt_output_path.write_text(srt_text, encoding="utf-8")
            vtt_output_path.write_text(vtt_text, encoding="utf-8")

            if saved_vocals_path is not None:
                self._persist_saved_vocals(separation.vocals_path, saved_vocals_path)

            report = self._build_report(
                request=request,
                output_path=output_path,
                srt_output_path=srt_output_path,
                vtt_output_path=vtt_output_path,
                saved_vocals_path=saved_vocals_path,
                run_key=run_key,
                separation=separation,
                alignment=alignment,
                work_dir=work_dir,
            )

            if report_path is not None:
                report_path.write_text(
                    json.dumps(report, indent=2, ensure_ascii=False),
                    encoding="utf-8",
                )

            return AlignmentRun(
                audio_path=audio_path,
                lyrics_path=lyrics_path,
                output_path=output_path,
                srt_output_path=srt_output_path,
                vtt_output_path=vtt_output_path,
                saved_vocals_path=saved_vocals_path,
                separator=separation,
                alignment=alignment,
                report=report,
                report_path=report_path,
                work_dir=work_dir if request.keep_temp else None,
            )
        finally:
            if not request.keep_temp and work_dir.exists():
                shutil.rmtree(work_dir)

    def batch_align(self, request: BatchAlignRequest) -> BatchAlignmentRun:
        audio_dir = request.audio_dir.resolve()
        if not audio_dir.is_dir():
            raise ValueError(f"Batch mode requires a directory, but got: {audio_dir}")

        self._validate_batch_request(request)
        tracks, skipped_items = self._discover_batch_tracks(audio_dir, recursive=request.recursive)
        if not tracks:
            raise ValueError(
                f"No matching audio and same-stem .txt pairs were found in {audio_dir}."
            )

        items: list[BatchItemResult] = []
        succeeded_count = 0
        low_confidence_count = 0
        failed_count = 0

        progress = tqdm(
            tracks,
            total=len(tracks),
            desc="Batch",
            unit="track",
            file=sys.stderr,
            dynamic_ncols=True,
            leave=True,
        )
        try:
            for track in progress:
                progress.set_postfix_str(track.stem, refresh=False)

                # Skip-existing check before doing any work
                if request.skip_existing and track.audio_path.with_suffix(".lrc").exists():
                    skipped_items.append(
                        BatchItemResult(
                            stem=track.stem,
                            audio_path=track.audio_path,
                            lyrics_path=track.lyrics_path,
                            status="skipped",
                            message="Output already exists.",
                        )
                    )
                    continue

                track_title = track.stem if request.artist else None
                track_request = AlignRequest(
                    audio_path=track.audio_path,
                    lyrics_path=track.lyrics_path,
                    title=track_title,
                    artist=request.artist,
                    engine=request.engine,
                    model=request.model,
                    device=request.device,
                    separator=request.separator,
                    separator_boost=request.separator_boost,
                    save_vocals=request.save_vocals,
                    keep_temp=request.keep_temp,
                    write_json_report=request.write_json_report,
                    enhanced_lrc=request.enhanced_lrc,
                    quiet=True,
                )

                try:
                    run = self.align(track_request)
                except (RuntimeError, ValueError) as exc:
                    failed_count += 1
                    items.append(
                        BatchItemResult(
                            stem=track.stem,
                            audio_path=track.audio_path,
                            lyrics_path=track.lyrics_path,
                            status="failure",
                            message=str(exc),
                        )
                    )
                    continue

                if run.report.get("low_confidence"):
                    low_confidence_count += 1
                    status = "low-confidence"
                else:
                    succeeded_count += 1
                    status = "success"

                items.append(
                    BatchItemResult(
                        stem=track.stem,
                        audio_path=track.audio_path,
                        lyrics_path=track.lyrics_path,
                        status=status,
                        run=run,
                    )
                )
        finally:
            progress.close()

        items.extend(skipped_items)
        items.sort(key=self._batch_item_sort_key)
        return BatchAlignmentRun(
            audio_dir=audio_dir,
            items=items,
            matched_count=len(tracks),
            succeeded_count=succeeded_count,
            low_confidence_count=low_confidence_count,
            failed_count=failed_count,
            skipped_count=len(skipped_items),
        )

    def clear_cache(self) -> bool:
        if not self.cache_dir.exists():
            return False
        shutil.rmtree(self.cache_dir)
        return True

    def _build_report(
        self,
        *,
        request,
        output_path,
        srt_output_path,
        vtt_output_path,
        saved_vocals_path,
        run_key,
        separation,
        alignment,
        work_dir,
    ):
        coverages = [line.coverage_ratio for line in alignment.line_alignments]
        confidences = [line.confidence for line in alignment.line_alignments]
        unresolved_count = sum(1 for line in alignment.line_alignments if line.start is None)
        resolved_count = len(alignment.line_alignments) - unresolved_count
        average_coverage_ratio = sum(coverages) / len(coverages)
        average_confidence = sum(confidences) / len(confidences)
        alignment_metadata = alignment.metadata or {}
        low_confidence = (
            alignment.engine_name == "stable-ts" and average_confidence < LOW_CONFIDENCE_THRESHOLD
        )
        recommended_action = None
        if low_confidence and separation.backend_name == "none":
            recommended_action = "inspect-output-and-rerun-with-separator-boost"
        elif low_confidence:
            recommended_action = "inspect-output-and-consider-explicit-lang-or-manual-review"

        return {
            "run_key": run_key,
            "audio_path": str(request.audio_path),
            "lyrics_path": str(request.lyrics_path),
            "output_path": str(output_path),
            "srt_output_path": str(srt_output_path),
            "vtt_output_path": str(vtt_output_path),
            "saved_vocals_path": str(saved_vocals_path) if saved_vocals_path else None,
            "engine": alignment.engine_name,
            "model": alignment_metadata.get("model_name") or request.model,
            "requested_device": request.device,
            "resolved_device": alignment_metadata.get("resolved_device"),
            "requested_language": request.language,
            "resolved_language": alignment_metadata.get("resolved_language") or request.language,
            "language_source": alignment_metadata.get("language_source")
            or ("explicit" if request.language else None),
            "language_candidates": alignment_metadata.get("language_candidates")
            or ([request.language] if request.language else []),
            "separator": separation.backend_name,
            "boost_mode": request.separator_boost,
            "enhanced_lrc": request.enhanced_lrc,
            "line_count": len(alignment.line_alignments),
            "resolved_line_count": resolved_count,
            "average_coverage_ratio": round(average_coverage_ratio, 4),
            "average_confidence": round(average_confidence, 4),
            "low_confidence": low_confidence,
            "low_confidence_threshold": LOW_CONFIDENCE_THRESHOLD,
            "recommended_action": recommended_action,
            "unresolved_line_count": unresolved_count,
            "alignment_runtime_seconds": round(alignment.runtime_seconds, 6),
            "separator_runtime_seconds": round(separation.runtime_seconds, 6),
            "backend_diagnostics": alignment_metadata.get("backend_diagnostics", {}),
            "matched_line_count": alignment_metadata.get("matched_line_count"),
            "segment_count": alignment_metadata.get("segment_count"),
            "work_dir": str(work_dir),
        }

    def _discover_batch_tracks(
        self,
        audio_dir: Path,
        *,
        recursive: bool = False,
    ) -> tuple[list[_DiscoveredBatchTrack], list[BatchItemResult]]:
        if recursive:
            # Collect all leaf directories that contain at least one relevant file,
            # then apply the same flat-discovery logic per directory.
            dirs: set[Path] = {audio_dir}
            for path in audio_dir.rglob("*"):
                if path.is_file() and path.suffix.lower() in {*BATCH_AUDIO_SUFFIXES, ".txt"}:
                    dirs.add(path.parent)

            all_tracks: list[_DiscoveredBatchTrack] = []
            all_skipped: list[BatchItemResult] = []
            for subdir in sorted(dirs):
                tracks, skipped = self._discover_tracks_in_dir(subdir)
                all_tracks.extend(tracks)
                all_skipped.extend(skipped)
            return all_tracks, all_skipped

        return self._discover_tracks_in_dir(audio_dir)

    def _discover_tracks_in_dir(
        self,
        audio_dir: Path,
    ) -> tuple[list[_DiscoveredBatchTrack], list[BatchItemResult]]:
        grouped: dict[str, dict[str, Path]] = {}
        for path in sorted(
            audio_dir.iterdir(),
            key=lambda p: (p.stem.casefold(), p.suffix.lower(), p.name.casefold()),
        ):
            if not path.is_file():
                continue
            suffix = path.suffix.lower()
            if suffix not in {*BATCH_AUDIO_SUFFIXES, ".txt"}:
                continue
            bucket = grouped.setdefault(path.stem.casefold(), {})
            bucket.setdefault(suffix, path)

        tracks: list[_DiscoveredBatchTrack] = []
        skipped_items: list[BatchItemResult] = []

        for stem_key in sorted(grouped):
            bucket = grouped[stem_key]
            lyrics_path = bucket.get(".txt")

            # Pick best available audio in priority order
            audio_path: Path | None = None
            skipped_audio: list[Path] = []
            for suffix in _AUDIO_PRIORITY:
                candidate = bucket.get(suffix)
                if candidate is None:
                    continue
                if audio_path is None:
                    audio_path = candidate
                else:
                    skipped_audio.append(candidate)

            stem_source = audio_path or lyrics_path
            if stem_source is None:
                continue
            stem = stem_source.stem

            if lyrics_path is None:
                if audio_path is not None:
                    skipped_items.append(
                        BatchItemResult(
                            stem=stem,
                            audio_path=audio_path.resolve(),
                            lyrics_path=None,
                            status="skipped",
                            message="No matching .txt lyrics file found.",
                        )
                    )
                continue

            if audio_path is not None:
                tracks.append(
                    _DiscoveredBatchTrack(
                        stem=stem,
                        audio_path=audio_path.resolve(),
                        lyrics_path=lyrics_path.resolve(),
                    )
                )
                for lower_priority in skipped_audio:
                    skipped_items.append(
                        BatchItemResult(
                            stem=stem,
                            audio_path=lower_priority.resolve(),
                            lyrics_path=lyrics_path.resolve(),
                            status="skipped",
                            message=f"Skipped because sibling {audio_path.name} is preferred.",
                        )
                    )

        return tracks, skipped_items

    def _build_run_key(
        self,
        audio_path: Path,
        lyrics_path: Path,
        engine: str,
        model: str,
        device: str,
        separator: str,
    ) -> str:
        digest = hashlib.sha256()
        for path in (audio_path, lyrics_path):
            stat = path.stat()
            digest.update(str(path.resolve()).encode("utf-8"))
            digest.update(str(stat.st_size).encode("utf-8"))
            digest.update(str(stat.st_mtime_ns).encode("utf-8"))
        digest.update(engine.encode("utf-8"))
        digest.update(model.encode("utf-8"))
        digest.update(device.encode("utf-8"))
        digest.update(separator.encode("utf-8"))
        return digest.hexdigest()[:12]

    def _metadata_tags(self, request: AlignRequest, resolved_language: str | None = None) -> dict[str, str]:
        tags: dict[str, str] = {}
        if request.artist:
            tags["ar"] = request.artist
        if request.title:
            tags["ti"] = request.title
        lang = request.language or resolved_language
        if lang:
            tags["la"] = lang
        return tags

    def _resolve_separator_name(self, request: AlignRequest) -> str:
        requested_separator = request.separator.strip().lower() if request.separator else None
        if request.separator_boost:
            if requested_separator in {"none", "passthrough"}:
                raise ValueError(
                    "--separator-boost cannot be combined with --separator none. "
                    "Omit --separator or use --separator audio-separator."
                )
            return "audio-separator"
        return requested_separator or "none"

    def _validate_batch_request(self, request: BatchAlignRequest) -> None:
        preview_request = AlignRequest(
            audio_path=request.audio_dir,
            lyrics_path=request.audio_dir,
            separator=request.separator,
            separator_boost=request.separator_boost,
        )
        resolved_separator_name = self._resolve_separator_name(preview_request)
        if request.save_vocals and resolved_separator_name == "none":
            raise ValueError(
                "Saving vocals requires real separation. Re-run with --separator-boost."
            )

    @staticmethod
    def _batch_item_sort_key(item: BatchItemResult) -> tuple[str, int, str]:
        status_order = {
            "success": 0,
            "low-confidence": 1,
            "failure": 2,
            "skipped": 3,
        }
        return (
            item.stem.casefold(),
            status_order.get(item.status, 99),
            item.audio_path.name.casefold() if item.audio_path else "",
        )

    def _persist_saved_vocals(self, source_path: Path, saved_vocals_path: Path) -> None:
        if source_path.suffix.lower() == ".wav":
            shutil.copy2(source_path, saved_vocals_path)
            return

        ffmpeg_path = shutil.which("ffmpeg")
        if ffmpeg_path is None:
            raise RuntimeError("ffmpeg is required to save the separated vocal stem as WAV.")

        command = [
            ffmpeg_path,
            "-y",
            "-i",
            str(source_path),
            str(saved_vocals_path),
        ]
        try:
            subprocess.run(
                command,
                capture_output=True,
                check=True,
            )
        except (OSError, subprocess.CalledProcessError) as exc:
            raise RuntimeError(f"ffmpeg failed to write the saved vocal stem: {exc}") from exc


class _SkipExistingError(Exception):
    """Raised by align() when skip_existing=True and the output already exists."""

    def __init__(self, output_path: Path) -> None:
        super().__init__(f"Output already exists: {output_path}")
        self.output_path = output_path
