from __future__ import annotations

from collections.abc import Iterable

from autolrc.models import LineAlignment

METADATA_ORDER = ("ar", "ti", "la")


def format_timestamp(seconds: float) -> str:
    total_centiseconds = max(0, round(seconds * 100))
    minutes, remainder = divmod(total_centiseconds, 6000)
    whole_seconds, centiseconds = divmod(remainder, 100)
    return f"{minutes:02d}:{whole_seconds:02d}.{centiseconds:02d}"


def render_lrc(
    alignments: Iterable[LineAlignment],
    metadata: dict[str, str] | None = None,
) -> str:
    lines: list[str] = []
    safe_metadata = {key: value for key, value in (metadata or {}).items() if value}

    for key in METADATA_ORDER:
        value = safe_metadata.pop(key, None)
        if value:
            lines.append(f"[{key}:{value}]")

    for key in sorted(safe_metadata):
        lines.append(f"[{key}:{safe_metadata[key]}]")

    for alignment in alignments:
        if alignment.start is None or not alignment.text.strip():
            continue
        lines.append(f"[{format_timestamp(alignment.start)}]{alignment.text}")

    return "\n".join(lines) + ("\n" if lines else "")


def render_enhanced_lrc(
    alignments: Iterable[LineAlignment],
    metadata: dict[str, str] | None = None,
) -> str:
    """Render karaoke-style LRC with inline word timestamps (<mm:ss.cc>word).

    Falls back to standard line-level output for lines without word data.
    Compatible with standard LRC players (they ignore the <> markers).
    """
    lines: list[str] = []
    safe_metadata = {key: value for key, value in (metadata or {}).items() if value}

    for key in METADATA_ORDER:
        value = safe_metadata.pop(key, None)
        if value:
            lines.append(f"[{key}:{value}]")

    for key in sorted(safe_metadata):
        lines.append(f"[{key}:{safe_metadata[key]}]")

    for alignment in alignments:
        if alignment.start is None or not alignment.text.strip():
            continue
        if alignment.words:
            word_parts = " ".join(
                f"<{format_timestamp(w.start)}>{w.word}" for w in alignment.words
            ).strip()
            lines.append(f"[{format_timestamp(alignment.start)}]{word_parts}")
        else:
            lines.append(f"[{format_timestamp(alignment.start)}]{alignment.text}")

    return "\n".join(lines) + ("\n" if lines else "")
