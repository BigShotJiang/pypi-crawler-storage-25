from __future__ import annotations

import importlib.metadata
import importlib.util
import platform
import subprocess
import sys
from pathlib import Path
from typing import Annotated, Any

import typer
import yaml

from autolrc import __version__
from autolrc.aligner import (
    DEFAULT_ALIGNMENT_DEVICE,
    DEFAULT_MODEL_NAME,
    get_runtime_diagnostics,
)
from autolrc.models import AlignmentRun, BatchAlignmentRun
from autolrc.pipeline import (
    DEFAULT_CACHE_DIR,
    AlignRequest,
    AutoLRCService,
    BatchAlignRequest,
    _SkipExistingError,
)
from autolrc.separator import get_audio_separator_dependency_status

app = typer.Typer(
    add_completion=False,
    help="Generate line-level .lrc files from audio and reference lyrics.",
    no_args_is_help=True,
)
cache_app = typer.Typer(help="Manage local AutoLRC cache data.", no_args_is_help=True)
app.add_typer(cache_app, name="cache")


def _service(cache_dir: Path = DEFAULT_CACHE_DIR) -> AutoLRCService:
    return AutoLRCService(cache_dir=cache_dir)


def _distribution_status(distribution_name: str, module_name: str) -> str:
    if importlib.util.find_spec(module_name) is None:
        return "missing"
    try:
        version = importlib.metadata.version(distribution_name)
    except importlib.metadata.PackageNotFoundError:
        return "installed"
    return version


def _load_manifest(path: Path) -> list[dict[str, Any]]:
    payload = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    tracks = payload.get("tracks", [])
    if not isinstance(tracks, list):
        raise ValueError("Manifest field 'tracks' must be a list.")
    return tracks


@app.command()
def align(
    audio: Annotated[
        Path,
        typer.Option(
            "--audio",
            exists=True,
            file_okay=True,
            dir_okay=True,
            help="Input audio file, or a directory to enable batch mode.",
        ),
    ],
    lyrics: Annotated[
        Path | None,
        typer.Option(
            "--lyrics",
            exists=True,
            dir_okay=False,
            help="Lyrics text file. Required for single-file mode only.",
        ),
    ] = None,
    output: Annotated[
        Path | None,
        typer.Option("--output", dir_okay=False, help="Target .lrc output path."),
    ] = None,
    title: Annotated[
        str | None,
        typer.Option("--title", help="Optional song title tag for LRC output."),
    ] = None,
    artist: Annotated[
        str | None,
        typer.Option("--artist", help="Optional artist tag for LRC output."),
    ] = None,
    language: Annotated[
        str | None,
        typer.Option("--lang", help="Optional language tag or hint."),
    ] = None,
    engine: Annotated[
        str,
        typer.Option("--engine", help="Alignment engine to use: baseline or stable-ts."),
    ] = "stable-ts",
    model: Annotated[
        str,
        typer.Option(
            "--model",
            help=(
                "Whisper model name for stable-ts alignment, "
                "such as base, small, medium, or large-v3."
            ),
        ),
    ] = DEFAULT_MODEL_NAME,
    device: Annotated[
        str,
        typer.Option("--device", help="Alignment device to use: auto, cuda, or cpu."),
    ] = DEFAULT_ALIGNMENT_DEVICE,
    separator: Annotated[
        str | None,
        typer.Option("--separator", help="Separator backend to use: none or audio-separator."),
    ] = None,
    separator_boost: Annotated[
        bool,
        typer.Option(
            "--separator-boost",
            help="Re-run with vocal separation enabled before alignment.",
        ),
    ] = False,
    save_vocals: Annotated[
        bool,
        typer.Option(
            "--save-vocals",
            help="Save the separated vocal stem as a sibling .vocals.wav artifact.",
        ),
    ] = False,
    keep_temp: Annotated[
        bool,
        typer.Option("--keep-temp", help="Keep working files under the local cache directory."),
    ] = False,
    json_report: Annotated[
        bool,
        typer.Option(
            "--json-report",
            help="Write the default sibling .json report.",
        ),
    ] = False,
    enhanced_lrc: Annotated[
        bool,
        typer.Option(
            "--enhanced-lrc",
            help="Write karaoke-style LRC with inline word-level timestamps.",
        ),
    ] = False,
    skip_existing: Annotated[
        bool,
        typer.Option(
            "--skip-existing",
            help="Skip tracks whose .lrc output already exists.",
        ),
    ] = False,
    recursive: Annotated[
        bool,
        typer.Option(
            "--recursive",
            help="(Batch mode) Walk subdirectories recursively.",
        ),
    ] = False,
) -> None:
    service = _service()
    if audio.is_dir():
        batch_errors = _validate_batch_flags(
            lyrics=lyrics,
            output=output,
            title=title,
            language=language,
        )
        if batch_errors:
            typer.secho("; ".join(batch_errors), err=True, fg=typer.colors.RED)
            raise typer.Exit(code=1)

        request = BatchAlignRequest(
            audio_dir=audio,
            artist=artist,
            engine=engine,
            model=model,
            device=device,
            separator=separator,
            separator_boost=separator_boost,
            save_vocals=save_vocals,
            keep_temp=keep_temp,
            write_json_report=json_report,
            enhanced_lrc=enhanced_lrc,
            skip_existing=skip_existing,
            recursive=recursive,
        )
        try:
            batch_run = service.batch_align(request)
        except (RuntimeError, ValueError) as exc:
            typer.secho(str(exc), err=True, fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc

        _echo_batch_run(batch_run)
        if batch_run.failed_count:
            raise typer.Exit(code=1)
        return

    if lyrics is None:
        typer.secho(
            "--lyrics is required when --audio points to a file.",
            err=True,
            fg=typer.colors.RED,
        )
        raise typer.Exit(code=1)

    if skip_existing:
        expected_output = (output or audio).with_suffix(".lrc")
        if expected_output.exists():
            typer.echo(f"Skipped (output exists): {expected_output}")
            return

    request = AlignRequest(
        audio_path=audio,
        lyrics_path=lyrics,
        output_path=output,
        title=title,
        artist=artist,
        language=language,
        engine=engine,
        model=model,
        device=device,
        separator=separator,
        separator_boost=separator_boost,
        save_vocals=save_vocals,
        keep_temp=keep_temp,
        write_json_report=json_report,
        enhanced_lrc=enhanced_lrc,
    )

    try:
        run = service.align(request)
    except _SkipExistingError as exc:
        typer.echo(f"Skipped (output exists): {exc.output_path}")
        return
    except (RuntimeError, ValueError) as exc:
        typer.secho(str(exc), err=True, fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    typer.echo(f"Wrote LRC: {run.output_path}")
    typer.echo(f"Wrote SRT: {run.srt_output_path}")
    typer.echo(f"Wrote VTT: {run.vtt_output_path}")
    if run.saved_vocals_path is not None:
        typer.echo(f"Saved vocals: {run.saved_vocals_path}")
    typer.echo(f"Engine: {run.alignment.engine_name}")
    if run.report.get("model"):
        typer.echo(f"Model: {run.report['model']}")
    if run.report.get("resolved_device"):
        typer.echo(f"Device: {run.report['resolved_device']}")
    if run.report.get("resolved_language"):
        typer.echo(f"Language: {run.report['resolved_language']}")
    typer.echo(f"Lines: {len(run.alignment.line_alignments)}")
    if run.report_path is not None:
        typer.echo(f"Report: {run.report_path}")
    _echo_low_confidence_guidance(run, audio=audio, lyrics=lyrics, language=language)
    if run.work_dir is not None:
        typer.echo(f"Work dir: {run.work_dir}")


@app.command()
def inspect(
    lyrics: Annotated[
        Path,
        typer.Option("--lyrics", exists=True, dir_okay=False, help="Lyrics text file to inspect."),
    ],
) -> None:
    service = _service()
    document = service.inspect_lyrics(lyrics)
    typer.echo(f"Normalized lyric lines: {len(document.lines)}")
    for line in document.lines:
        typer.echo(f"{line.line_number:>3}: {line.original_text}")
        if line.original_text != line.normalized_text:
            typer.echo(f"     -> {line.normalized_text}")


@app.command()
def benchmark(
    manifest: Annotated[
        Path,
        typer.Option(
            "--manifest",
            exists=True,
            dir_okay=False,
            help="Benchmark manifest to validate and summarize.",
        ),
    ] = Path("bench/manifest.yaml"),
) -> None:
    try:
        tracks = _load_manifest(manifest)
    except ValueError as exc:
        typer.secho(str(exc), err=True, fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    typer.echo(f"Tracks: {len(tracks)}")
    for track in tracks:
        languages = ",".join(track.get("languages", []))
        typer.echo(f"- {track.get('track_id', '<unknown>')} [{languages}]")


@app.command()
def doctor() -> None:
    diagnostics = get_runtime_diagnostics()
    audio_separator_status = get_audio_separator_dependency_status()
    typer.echo(f"AutoLRC: {__version__}")
    typer.echo(f"Python: {platform.python_version()}")
    typer.echo(f"Platform: {platform.platform()}")
    typer.echo(f"Cache dir: {DEFAULT_CACHE_DIR.resolve()}")
    typer.echo("Runtime diagnostics:")
    typer.echo(
        f"ffmpeg: {diagnostics['ffmpeg_path'] if diagnostics['ffmpeg_available'] else 'missing'}"
    )
    typer.echo(f"stable-ts: {_distribution_status('stable-ts', 'stable_whisper')}")
    typer.echo(
        f"torch: {diagnostics['torch_version'] if diagnostics['torch_available'] else 'missing'}"
    )
    typer.echo(f"CUDA available: {diagnostics['cuda_available']}")
    typer.echo("Additional dependencies:")
    typer.echo(f"- audio-separator: {audio_separator_status.message}")
    typer.echo(f"- RapidFuzz: {_distribution_status('rapidfuzz', 'rapidfuzz')}")
    typer.echo(f"- PyYAML: {_distribution_status('PyYAML', 'yaml')}")


@cache_app.command("clear")
def cache_clear(
    cache_dir: Annotated[
        Path,
        typer.Option("--cache-dir", help="Cache directory to remove."),
    ] = DEFAULT_CACHE_DIR,
) -> None:
    cleared = _service(cache_dir=cache_dir).clear_cache()
    if cleared:
        typer.echo(f"Cleared cache: {cache_dir}")
        return
    typer.echo(f"No cache directory found at: {cache_dir}")


def _validate_batch_flags(
    *,
    lyrics: Path | None,
    output: Path | None,
    title: str | None,
    language: str | None,
) -> list[str]:
    errors: list[str] = []
    if lyrics is not None:
        errors.append("--lyrics is not supported in batch directory mode")
    if output is not None:
        errors.append("--output is not supported in batch directory mode")
    if title is not None:
        errors.append("--title is not supported in batch directory mode")
    if language is not None:
        errors.append("--lang is not supported in batch directory mode")
    return errors


def _echo_batch_run(batch_run: BatchAlignmentRun) -> None:
    typer.echo(f"Batch directory: {batch_run.audio_dir}")
    for item in batch_run.items:
        if item.status == "success":
            typer.echo(f"SUCCESS [{item.stem}] {item.run.output_path}")
            continue
        if item.status == "low-confidence":
            typer.secho(
                (
                    f"LOW CONFIDENCE [{item.stem}] {item.run.output_path} "
                    f"(average confidence {item.run.report['average_confidence']:.4f})"
                ),
                fg=typer.colors.YELLOW,
            )
            _echo_low_confidence_guidance(
                item.run,
                audio=item.audio_path,
                lyrics=item.lyrics_path,
                language=None,
            )
            continue
        if item.status == "failure":
            typer.secho(f"FAILED [{item.stem}] {item.message}", err=True, fg=typer.colors.RED)
            continue
        typer.echo(f"SKIPPED [{item.audio_path.name if item.audio_path else item.stem}] {item.message}")

    typer.echo("Summary:")
    typer.echo(f"Matched: {batch_run.matched_count}")
    typer.echo(f"Succeeded: {batch_run.succeeded_count}")
    typer.echo(f"Low confidence: {batch_run.low_confidence_count}")
    typer.echo(f"Failed: {batch_run.failed_count}")
    typer.echo(f"Skipped: {batch_run.skipped_count}")


def _echo_low_confidence_guidance(
    run: AlignmentRun,
    *,
    audio: Path,
    lyrics: Path | None,
    language: str | None,
) -> None:
    if not run.report.get("low_confidence"):
        return

    typer.secho(
        (
            f"Warning: average confidence {run.report['average_confidence']:.4f} "
            f"is below {run.report['low_confidence_threshold']:.1f}."
        ),
        fg=typer.colors.YELLOW,
    )
    typer.echo("Inspect the generated files before using them downstream.")
    if run.report.get("recommended_action") == "inspect-output-and-rerun-with-separator-boost":
        typer.echo("Separator boost may improve alignment quality for this track.")
        typer.echo(
            "Suggested rerun: "
            + _build_separator_boost_command(audio=audio, lyrics=lyrics, language=language)
        )
        typer.echo("If you also want the separated vocal stem, append --save-vocals.")
    elif run.report.get("recommended_action"):
        typer.echo("Consider rerunning with --lang or reviewing the output manually.")


def main() -> None:
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="replace")
    app()


def _build_separator_boost_command(
    *,
    audio: Path,
    lyrics: Path | None,
    language: str | None,
) -> str:
    command = [
        "autolrc",
        "align",
        "--audio",
        str(audio),
    ]
    if lyrics is not None:
        command.extend(["--lyrics", str(lyrics)])
    command.append("--separator-boost")
    if language:
        command.extend(["--lang", language])
    return subprocess.list2cmdline(command)
