from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Any

import yaml

REQUIRED_FIELDS = {
    "track_id",
    "audio_path",
    "lyrics_path",
    "languages",
    "is_mixed_language",
    "has_long_intro",
    "has_repeated_chorus",
    "notes",
}


def load_manifest(path: Path) -> list[dict[str, Any]]:
    payload = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    tracks = payload.get("tracks", [])
    if not isinstance(tracks, list):
        raise ValueError("Manifest field 'tracks' must be a list.")
    for entry in tracks:
        missing = REQUIRED_FIELDS.difference(entry)
        if missing:
            raise ValueError(
                "Manifest entry "
                f"{entry.get('track_id', '<unknown>')} is missing fields: {sorted(missing)}"
            )
    return tracks


def build_report_rows(entries: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for entry in entries:
        rows.append(
            {
                "track_id": entry["track_id"],
                "audio_path": entry["audio_path"],
                "lyrics_path": entry["lyrics_path"],
                "languages": ",".join(entry["languages"]),
                "status": "pending",
                "median_line_onset_error": None,
                "p90_line_onset_error": None,
                "dropped_line_rate": None,
                "early_highlight_rate": None,
                "unresolved_line_rate": None,
                "runtime_seconds": None,
                "peak_vram_mb": None,
                "manual_correction_minutes": None,
            }
        )
    return rows


def write_json(rows: list[dict[str, Any]], output_path: Path) -> None:
    output_path.write_text(json.dumps(rows, indent=2), encoding="utf-8")


def write_csv(rows: list[dict[str, Any]], output_path: Path) -> None:
    if not rows:
        output_path.write_text("", encoding="utf-8")
        return
    with output_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Validate a benchmark manifest and emit a stub report."
    )
    parser.add_argument("--manifest", type=Path, default=Path("bench/manifest.yaml"))
    parser.add_argument("--output", type=Path, default=Path("bench/report.json"))
    parser.add_argument("--format", choices=("json", "csv"), default="json")
    args = parser.parse_args()

    entries = load_manifest(args.manifest)
    rows = build_report_rows(entries)
    args.output.parent.mkdir(parents=True, exist_ok=True)

    if args.format == "json":
        write_json(rows, args.output)
    else:
        write_csv(rows, args.output)


if __name__ == "__main__":
    main()
