import logging
import os
import random
import sys
from pathlib import Path
from threading import Thread
import argparse

import pygame
from PIL import Image, ImageDraw, ImageFont, ImageOps
import uvicorn
from fastapi import FastAPI
from fastapi.responses import FileResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles

try:
    import pillow_heif
    pillow_heif.register_heif_opener()
except ImportError:
    pass

try:
    import piexif
    from geopy.geocoders import Nominatim
    from geopy.exc import GeocoderTimedOut
    GEOLOCATION_AVAILABLE = True
except ImportError:
    GEOLOCATION_AVAILABLE = False
    print("Geolocation features not available. Install required packages: pip install piexif geopy")

logger = logging.getLogger("slideshow")

_web_dir = Path(__file__).parent / "web"
_app_instance = None


def startfastapi(app):
    print('started app')
    uvicorn.run(app, host="0.0.0.0", port=8090)


class App:
    fontname = "arial.ttf" if os.name == "nt" else "FreeMono.ttf"
    NEXT_SLIDE = pygame.USEREVENT + 1

    def __init__(self, image_files, delay, show_names=False, show_location=False):
        pygame.init()
        pygame.mouse.set_visible(False)
        pygame.display.set_caption("Slideshow")

        info = pygame.display.Info()
        self.w = info.current_w
        self.h = info.current_h
        self.screen = pygame.display.set_mode((self.w, self.h), pygame.FULLSCREEN)

        self.delay = delay
        self.show_names = show_names
        self.show_location = show_location
        self.curr = ""

        self.pictures = list(image_files)
        random.shuffle(self.pictures)
        self.track_img_ndex = 0

        pygame.time.set_timer(self.NEXT_SLIDE, delay)

    def _pil_to_surface(self, pil_image):
        pil_image = pil_image.convert("RGB")
        return pygame.image.frombytes(pil_image.tobytes(), pil_image.size, "RGB")

    def _load_font(self, size):
        import pygame.font as _pf
        candidates = [
            self.fontname,
            "/usr/share/fonts/truetype/freefont/FreeMono.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
            os.path.join(os.path.dirname(_pf.__file__), _pf.get_default_font()),
        ]
        for path in candidates:
            try:
                return ImageFont.truetype(path, size=size)
            except (IOError, OSError):
                continue
        return ImageFont.load_default()

    def show_slide(self):
        try:
            self.track_img_ndex = self.track_img_ndex % len(self.pictures)
            x = self.pictures[self.track_img_ndex]
            self.track_img_ndex += 1

            img = Image.open(x)
            img = ImageOps.exif_transpose(img)
            img = ImageOps.fit(img, (self.w, self.h), Image.LANCZOS)

            draw = ImageDraw.Draw(img)

            if self.show_names:
                self._draw_filename(draw, img, x)

            if self.show_location and GEOLOCATION_AVAILABLE:
                self.add_location(img, draw, img.width)

            self.screen.blit(self._pil_to_surface(img), (0, 0))
            pygame.display.flip()
            self.curr = x
            logger.info(f"{self.track_img_ndex} {x}")

        except Exception as ex:
            logger.error(ex)

    def _draw_filename(self, draw, img, path):
        name = os.path.basename(path)
        font_size = int(self.w / 80)
        font = self._load_font(font_size)
        text_bbox = draw.textbbox((0, 0), name, font=font)
        text_width = text_bbox[2] - text_bbox[0]
        text_height = text_bbox[3] - text_bbox[1]
        x_pos = (img.width - text_width) // 2
        y_pos = img.height - text_height - 30
        draw.text((x_pos + 2, y_pos + 2), name, (0, 0, 0), font=font)
        draw.text((x_pos, y_pos), name, (255, 255, 0), font=font)

    def _reset_timer(self):
        pygame.time.set_timer(self.NEXT_SLIDE, self.delay)

    def run(self):
        self.show_slide()
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == self.NEXT_SLIDE:
                    self.show_slide()
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        pygame.quit()
                        sys.exit()
                    elif event.key in (pygame.K_SPACE, pygame.K_5):
                        self.show_names = not self.show_names
                        self.track_img_ndex -= 1
                        self.show_slide()
                        self._reset_timer()
                    elif event.key == pygame.K_LEFT:
                        self.track_img_ndex -= 2
                        self.show_slide()
                        self._reset_timer()
                    elif event.key == pygame.K_RIGHT:
                        self.show_slide()
                        self._reset_timer()
                    elif event.key == pygame.K_l:
                        self.show_location = not self.show_location
                        self.track_img_ndex -= 1
                        self.show_slide()
                        self._reset_timer()

    def add_location(self, original_image, image_editable, canvas_width=None):
        try:
            exif_data = original_image.info.get("exif")
            if not exif_data:
                return
            exif_dict = piexif.load(exif_data)
            if "GPS" in exif_dict and exif_dict["GPS"]:
                gps = exif_dict["GPS"]

                def get_gps_value(gps_data, key):
                    if key in gps_data:
                        value = gps_data[key]
                        if isinstance(value, tuple):
                            if len(value) == 2:
                                return float(value[0]) / float(value[1])
                            elif len(value) == 3:
                                d = float(value[0][0]) / float(value[0][1])
                                m = float(value[1][0]) / float(value[1][1])
                                s = float(value[2][0]) / float(value[2][1])
                                return d + (m / 60.0) + (s / 3600.0)
                            elif len(value) == 4:
                                d = float(value[0]) / float(value[1])
                                m = float(value[2]) / float(value[3])
                                return d + (m / 60.0)
                        elif isinstance(value, int):
                            return float(value)
                        return float(value)
                    return None

                def get_gps_ref(gps_data, key, default):
                    if key in gps_data:
                        value = gps_data[key]
                        if isinstance(value, bytes):
                            return value.decode('utf-8')
                        return str(value)
                    return default

                lat = None
                lon = None

                if lat is None and lon is None and 1 in gps and 2 in gps:
                    try:
                        lat_ref = get_gps_ref(gps, 1, 'N')
                        lon_ref = get_gps_ref(gps, 3, 'E')
                        lat = get_gps_value(gps, 2)
                        lon = get_gps_value(gps, 4)

                        logger.debug(f"Extracted coordinates: lat={lat}, lon={lon}, lat_ref={lat_ref}, lon_ref={lon_ref}")

                        if lat_ref == 'S':
                            lat = -lat
                        if lon_ref == 'W':
                            lon = -lon

                        if lat is not None and lon is not None:
                            geolocator = Nominatim(user_agent="my_slideshow")
                            try:
                                location = geolocator.reverse(f"{lat}, {lon}", language="he")
                                if location and location.raw.get('address'):
                                    address = location.raw['address']
                                    country = address.get('country', '')
                                    area = (address.get('city', '') or
                                            address.get('town', '') or
                                            address.get('village', '') or
                                            address.get('county', '') or
                                            address.get('state', '') or
                                            '')

                                    if country or area:
                                        font_size = int(self.w / 80)
                                        font = self._load_font(font_size)

                                        location_text = []
                                        if area:
                                            location_text.append(area)
                                        if country:
                                            location_text.append(country)
                                        location_text = ', '.join(location_text)

                                        parts = location_text.split(', ')
                                        reversed_parts = [''.join(reversed(p)) for p in parts]
                                        location_text = ' ,'.join(reversed_parts)

                                        text_bbox = image_editable.textbbox((0, 0), location_text, font=font)
                                        text_width = text_bbox[2] - text_bbox[0]
                                        w = canvas_width if canvas_width is not None else original_image.width
                                        x_pos = w - text_width
                                        y_pos = 0

                                        image_editable.text((x_pos + 2, y_pos + 2), location_text, (0, 0, 0), font=font)
                                        image_editable.text((x_pos, y_pos), location_text, (255, 255, 0), font=font)
                            except GeocoderTimedOut:
                                pass
                    except Exception as e:
                        logger.error(f"Error processing standard GPS tags: {e}")
                        logger.error(f"GPS data structure: {gps}")
        except Exception as e:
            logger.error(f"Error processing GPS data: {e}")


def main():
    global _app_instance

    parser = argparse.ArgumentParser(description='Image Slideshow')
    parser.add_argument('--names', action='store_true', help='Show image names')
    parser.add_argument('--no-location', action='store_true', help='Hide location information')
    parser.add_argument('--root', type=str, help='Root directory for images')
    args = parser.parse_args()

    delay = 6000
    extensions = (".jpg", ".jpeg", ".heic")
    root = args.root if args.root else os.path.expanduser("~/photos")
    if not os.path.isdir(root):
        root = os.getcwd()

    image_files = []
    for path in Path(root).rglob("*.*"):
        for e in extensions:
            if str(path).lower().endswith(e):
                image_files.append(str(path))

    if not image_files:
        print(f"No image files found in '{root}'. Supported formats: {', '.join(extensions)}")
        sys.exit(1)

    fmt = '%(asctime)s %(name)s  %(levelname)s:  %(message)s'
    dfmt = '%d-%b-%y %H:%M:%S'
    log_file = 'c:/temp/slideshow.log' if os.name == 'nt' else '/tmp/slideshow.log'
    logging.basicConfig(filename=log_file, filemode='a', level=logging.INFO,
                        format=fmt, datefmt=dfmt)
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter(fmt=fmt, datefmt=dfmt))
    handler.setLevel(logging.DEBUG)
    logging.getLogger().addHandler(handler)
    logging.info("started")

    fastapi_app = FastAPI()

    @fastapi_app.get("/filename")
    def filename():
        if _app_instance is not None:
            return PlainTextResponse(_app_instance.curr)
        return PlainTextResponse("")

    @fastapi_app.get("/")
    def index():
        return FileResponse(str(_web_dir / "index.html"))

    fastapi_app.mount("/", StaticFiles(directory=str(_web_dir)), name="static")

    thread = Thread(target=startfastapi, args=(fastapi_app,), daemon=True)
    thread.start()

    print(image_files)
    print(len(image_files))
    _app_instance = App(image_files, delay, show_names=args.names, show_location=not args.no_location)
    _app_instance.run()


if __name__ == '__main__':
    main()
