import subprocess
from pathlib import Path

import uvicorn
from fastapi import FastAPI, Form, Response
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pynput.keyboard import Key, Controller
from pynput import keyboard

_static_dir = Path(__file__).parent / "mediaweb"

app = FastAPI()


@app.post("/execute")
def execute(id: str = Form(None)):
    entry = methods.get(id)
    if entry is None:
        return Response(content='unknown action', status_code=400)
    m = entry[0]
    v = entry[1]
    m(v)
    return Response(content='ok')


@app.get("/")
def upload_file():
    return FileResponse(str(_static_dir / "index.html"))


app.mount("/", StaticFiles(directory=str(_static_dir)), name="static")

_keyboard_controller = Controller()


def media(k):
    _keyboard_controller.press(k)
    _keyboard_controller.release(k)


def on_press(key):
    if key == keyboard.Key.esc:
        return False  # stop listener
    try:
        k = key.char  # single-char keys
    except AttributeError:
        k = key.name  # other keys
    if k in ['8']:  # keys of interest
        print('Key pressed: ' + k)
        slides(True)
    if k in ['9']:  # keys of interest
        print('Key pressed: ' + k)
        slides(False)


def slides(run):
    script_dir = Path(__file__).parent.parent.parent
    script = "start.sh" if run else "stop.sh"
    subprocess.Popen(["bash", str(script_dir / script)])


methods = {"next": (media, Key.media_next),
           "prev": (media, Key.media_previous),
           "pause": (media, Key.media_play_pause),
           "runslides": (slides, True),
           "stopslides": (slides, False)
           }


def main():
    print('started app')
    listener = keyboard.Listener(on_press=on_press)
    listener.start()
    uvicorn.run(app, host="0.0.0.0", port=5000)


if __name__ == '__main__':
    main()
