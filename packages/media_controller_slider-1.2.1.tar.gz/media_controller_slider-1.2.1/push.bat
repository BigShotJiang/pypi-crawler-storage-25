git add .
git commit -a -m "updates" 
git push