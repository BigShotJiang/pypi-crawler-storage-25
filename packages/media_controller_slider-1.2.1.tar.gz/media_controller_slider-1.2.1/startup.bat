cd c:\views\slider
start start.bat
timeout 1
start /MIN runmedia.bat

