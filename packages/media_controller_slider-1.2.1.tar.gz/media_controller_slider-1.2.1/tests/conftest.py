"""Shared test configuration - configure headless display for pygame and mock pynput."""
import os
import sys
from unittest.mock import MagicMock

# Configure pygame for headless testing before any imports
os.environ.setdefault('SDL_VIDEODRIVER', 'dummy')
os.environ.setdefault('SDL_AUDIODRIVER', 'dummy')

# Mock pynput modules before any imports that depend on them
pynput_mock = MagicMock()
pynput_keyboard_mock = MagicMock()
sys.modules['pynput'] = pynput_mock
sys.modules['pynput.keyboard'] = pynput_keyboard_mock
sys.modules['pynput._util'] = MagicMock()

pynput_mock.keyboard = pynput_keyboard_mock
