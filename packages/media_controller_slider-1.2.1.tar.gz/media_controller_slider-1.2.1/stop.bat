cd c:\temp
taskkill /im python* /f
exit