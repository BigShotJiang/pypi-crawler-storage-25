#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
pkill -f "python.*main.py" 2>/dev/null
sleep 0.5
nohup python "$SCRIPT_DIR/main.py" >> /tmp/slideshow.log 2>&1 &
