echo first time installation
pip install gphotos-sync
mkdir C:\Users\eyal\Desktop\Frame\Albums
mkdir C:\Users\eyal\AppData\Local\gphotos-sync\gphotos-sync
