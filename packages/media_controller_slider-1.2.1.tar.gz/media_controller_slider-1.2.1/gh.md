# Installing GitHub CLI (gh)

## Download

Download the latest `.deb` package:

```bash
curl -L -o /tmp/gh.deb https://github.com/cli/cli/releases/download/v2.86.0/gh_2.86.0_linux_amd64.deb
sudo dpkg -i /tmp/gh.deb
```

## Authentication

```bash
# Option 1: Set a token
export GH_TOKEN=ghp_your_token_here

# Option 2: Interactive login
gh auth login
```

## Verify

```bash
gh version
gh auth status
```
