cd c:\temp\slider2
taskkill /im python* /f
call synced.bat 
start python main.py
exit
