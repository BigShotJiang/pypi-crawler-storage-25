#!/bin/bash
# Run once on the Pi to install the slideshow and media controller.
set -e

echo "=== Installing system packages ==="
sudo apt-get update -q
sudo apt-get install -y libheif-dev fonts-freefont-ttf \
    libsdl2-dev libsdl2-image-dev libsdl2-ttf-dev

echo "=== Installing uv ==="
curl -LsSf https://astral.sh/uv/install.sh | sh
export PATH="$HOME/.local/bin:$PATH"

echo "=== Installing slideshow and media controller ==="
uv tool install media-controller-slider

echo "=== Installing systemd services ==="
INSTALL_DIR="$(uv tool dir)/media-controller-slider"
BIN_DIR="$HOME/.local/bin"

sudo tee /etc/systemd/system/slideshow.service > /dev/null <<EOF
[Unit]
Description=Photo Slideshow
After=multi-user.target

[Service]
Type=simple
User=$USER
ExecStart=$BIN_DIR/slideshow
Restart=on-failure
RestartSec=5
Environment=SDL_VIDEODRIVER=kmsdrm
Environment=PATH=$HOME/.local/bin:/usr/local/bin:/usr/bin:/bin

[Install]
WantedBy=multi-user.target
EOF

sudo tee /etc/systemd/system/media-controller.service > /dev/null <<EOF
[Unit]
Description=Media Controller Web Server
After=network.target

[Service]
Type=simple
User=$USER
ExecStart=$BIN_DIR/media-controller
Restart=on-failure
RestartSec=5
Environment=PATH=$HOME/.local/bin:/usr/local/bin:/usr/bin:/bin

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable slideshow.service
sudo systemctl enable media-controller.service

echo "=== Creating photo directory ==="
mkdir -p ~/photos

echo ""
echo "Done. Copy photos to ~/photos/ then reboot."
echo "  Slideshow web UI:        http://$(hostname -I | awk '{print $1}'):8090"
echo "  Media controller web UI: http://$(hostname -I | awk '{print $1}'):5000"
echo ""
echo "To update in future: uv tool upgrade media-controller-slider"
