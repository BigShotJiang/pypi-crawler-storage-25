import os
import subprocess

import uvicorn
from fastapi import FastAPI, Form, Response
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pynput.keyboard import Key, Controller
from pynput import keyboard

app = FastAPI()


@app.post("/execute")
def execute(id: str = Form(None)):
    entry = methods.get(id)
    if entry is None:
        return Response(content='unknown action', status_code=400)
    m = entry[0]
    v = entry[1]
    m(v)
    return Response(content='ok')


@app.get("/")
def upload_file():
    return FileResponse(os.path.join("mediaweb", "index.html"))


app.mount("/", StaticFiles(directory="mediaweb"), name="static")

_keyboard_controller = Controller()


def media(k):
    _keyboard_controller.press(k)
    _keyboard_controller.release(k)


def on_press(key):
    if key == keyboard.Key.esc:
        return False  # stop listener
    try:
        k = key.char  # single-char keys
    except AttributeError:
        k = key.name  # other keys
    if k in ['8']:  # keys of interest
        # self.keys.append(k)  # store it in global-like variable
        print('Key pressed: ' + k)
        slides(True)
    if k in ['9']:  # keys of interest
        # self.keys.append(k)  # store it in global-like variable
        print('Key pressed: ' + k)
        slides(False)


def slides(run):
    if run:
        subprocess.run("start c:\\views\\slider\\start.bat", shell=True)
    else:
        subprocess.run("start c:\\views\\slider\\stop.bat", shell=True)


methods = {"next": (media, Key.media_next),
           "prev": (media, Key.media_previous),
           "pause": (media, Key.media_play_pause),
           "runslides": (slides, True),
           "stopslides": (slides, False)
           }

if __name__ == '__main__':
    print('started app')
    listener = keyboard.Listener(on_press=on_press)
    listener.start()  # start to listen on a separate thread
    uvicorn.run(app, host="0.0.0.0", port=5000)
