# langchain-x402

LangChain tools for 2,400+ x402 pay-per-call APIs. No wallet setup needed.

## Install

```bash
pip install langchain-x402
```

## Quick Start

```python
from langchain_x402 import X402Toolkit

tools = X402Toolkit().get_tools()
# 3 tools: x402_discover, x402_call, x402_balance
```

## With an Agent

```python
from langchain_openai import ChatOpenAI
from langgraph.prebuilt import create_react_agent
from langchain_x402 import X402Toolkit

agent = create_react_agent(ChatOpenAI(), X402Toolkit().get_tools())
result = agent.invoke({
    "messages": [("user", "Find DeFi security APIs and check if USDC on Base is safe")]
})
```

## Tools

### x402_discover

Search 2,400+ x402 APIs by keyword. Returns URLs, descriptions, prices.

```python
from langchain_x402 import DiscoverTool

tool = DiscoverTool()
result = tool.invoke({"query": "weather forecast", "limit": 5})
```

### x402_call

Call any x402 API. Payment handled automatically via broker ($0.01/call).

```python
from langchain_x402 import CallAPITool

tool = CallAPITool()
result = tool.invoke({"url": "https://weather.hugen.tokyo/weather/current?city=Tokyo"})
```

### x402_balance

Check remaining API key balance.

```python
from langchain_x402 import BalanceTool

tool = BalanceTool()
result = tool.invoke({})  # {"balance_usd": 0.04}
```

## How Billing Works

1. First use auto-creates an API key with $0.05 trial credit (5 broker calls)
2. Each `x402_call` deducts from balance
3. When balance runs out, top up via `POST https://discovery.hugen.tokyo/keys/topup` ($1.00)
4. Discovery search is free (no payment needed)

## License

MIT
