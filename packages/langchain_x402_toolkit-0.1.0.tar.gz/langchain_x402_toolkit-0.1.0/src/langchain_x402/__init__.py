"""LangChain tools for x402 pay-per-call APIs.

Discover, call, and manage 2,400+ x402 APIs directly from LangChain agents.
No wallet setup needed — auto-provisions an API key with $0.05 trial credit.

Usage::

    from langchain_x402 import X402Toolkit

    tools = X402Toolkit().get_tools()
    # Returns 3 tools: x402_discover, x402_call, x402_balance

With an agent::

    from langchain_openai import ChatOpenAI
    from langgraph.prebuilt import create_react_agent

    agent = create_react_agent(ChatOpenAI(), X402Toolkit().get_tools())
    result = agent.invoke({"messages": [("user", "Find weather APIs and get Tokyo weather")]})
"""

from x402_pay.integrations.langchain import (
    X402Toolkit,
    DiscoverTool,
    CallAPITool,
    BalanceTool,
)

__all__ = ["X402Toolkit", "DiscoverTool", "CallAPITool", "BalanceTool"]
__version__ = "0.1.0"
