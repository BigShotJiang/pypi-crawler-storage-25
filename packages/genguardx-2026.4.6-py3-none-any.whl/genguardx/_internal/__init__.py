"""
Internal API that should not be exposed outside to users.
Refrain from using this directly as there is no guarantee that this won't change
at any time.
"""

import builtins
import typing as t

import httpx


def init(api_key: str, *, api_url: t.Optional[str] = None) -> None:
    """Initialize SDK with provided authentication options.

    This function configures the SDK with the provided credentials
    After successful initialization, all service calls will be authenticated using this context.

    Parameters
    ----------
    api_key : str
        API key associated with the user account to initialize connection to the Platform
    api_url : str or None, optional
        Override the default API base URL
    """
    from genguardx._internal.util.networking import ApiAuth, api

    assert isinstance(api.client.auth, ApiAuth), (
        f"Unable to initialize corridor - Auth is being controlled by: {type(api.client.auth).__name__}"
    )

    api.client.auth.init_user(api_key)
    if api_url is not None:
        api.client.base_url = httpx.URL(api_url).copy_with(path="/api")
    whoami()  # Show the user who is logged in


def whoami() -> None:
    """Display current user information.

    Shows the authenticated user's name.
    If the session is not initialized, prompts the user to run :py:func:`genguardx.init`.
    """
    from genguardx._internal.util.constants import URLS
    from genguardx._internal.util.networking import ApiAuth, api, ujoin

    if isinstance(api.client.auth, ApiAuth) and api.client.auth.user_api_key is None:
        print(
            "Session not initialized.\n"
            "Fetch your API key from profile page and initialize session by running "
            "genguardx.init(api_key='your-api-key')"
        )
        return
    user_info: dict[t.Literal["visibleName", "name"], t.Any] = api.response(ujoin(URLS.USER_PATH.value, "/whoami"))[
        "result"
    ]

    if getattr(builtins, "__IPYTHON__", False) is True:
        from IPython import get_ipython

        ip = get_ipython()
        if ip.has_trait("kernel"):  # Need to differentiate between notebook environment and ipython shells
            # Handle environments where rich text formatting is supported by IPython. e.g. Jupyter Notebook
            from IPython.display import Markdown, display

            display(Markdown(f"Logged in as `{user_info['visibleName']}`."))
            display(
                Markdown(f"Any changes made in this session will be **tracked** under the user `{user_info['name']}`.")
            )
            return

    # Handle environments when rich text formatting is not supported: e.g.: IPython REPLs, Python REPL, Scripts etc
    print(f"Logged in as {user_info['visibleName']!r}.")
    print(f"Any changes made in this session will be tracked under the user {user_info['name']!r}.")
