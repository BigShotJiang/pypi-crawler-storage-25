import datetime
import typing as t
from dataclasses import dataclass
from functools import cached_property

from genguardx._internal.mixins.auditable import Auditable
from genguardx._internal.util.base_api import ApiBase
from genguardx._internal.util.constants import URLS


if t.TYPE_CHECKING:
    from genguardx._internal.pipelines import Pipeline


@dataclass(frozen=True)
class Activity:
    created_by: str
    created_date: t.Optional[datetime.datetime]
    rating: t.Optional[int]
    message: t.Optional[str]
    comment: t.Optional[str]


@dataclass(frozen=True)
class Interaction:
    role: t.Literal["system", "user", "assistant", "_internal"]
    content: str
    context: t.Optional[str]
    error_message: t.Optional[str]
    activity: list[Activity]
    rating: t.Optional[int]
    issue_type: t.Optional[str]
    time_taken: t.Optional[int]
    comment: t.Optional[str]
    # TODO: Handle interaction metrics


class TestRun(ApiBase, Auditable):
    _LIST_URL = URLS.TEST_RUN_PATH.value

    def __init__(self, id: int) -> None:
        super().__init__()
        self._data = self._get_data_item(id=id)

    @property
    def id(self) -> int:
        return self._data["id"]

    @property
    def name(self) -> str:
        return self._data["name"]

    @property
    def run_number(self) -> int:
        return self._data["runNumber"]

    @property
    def testing_notes(self) -> str:
        return self._data["testingNotes"]

    @property
    def person_name(self) -> str:
        return self._data["personName"]

    @property
    def person_description(self) -> str:
        return self._data["personDescription"]

    @property
    def is_old(self) -> bool:
        return self._data["isOld"]

    @property
    def has_ended(self) -> bool:
        return self._data["hasEnded"]

    @cached_property
    def pipeline(self) -> "Pipeline":
        from genguardx._internal.pipelines import Pipeline

        return Pipeline(id=self._data["pipelineVersionId"])

    @property
    def interactions(self) -> list[Interaction]:
        return [
            Interaction(
                role=interaction["role"],
                content=interaction["content"],
                context=interaction["context"],
                error_message=interaction.get("errorMessage"),
                activity=[
                    Activity(
                        created_by=item.get("createdBy"),
                        created_date=(
                            datetime.datetime.fromisoformat(item.get("createdDate"))
                            if item.get("createdDate")
                            else None
                        ),
                        rating=item.get("rating"),
                        comment=item.get("comment"),
                        message=item.get("message"),
                    )
                    for item in (interaction.get("feedbackHistory") or [])
                ],
                comment="\n".join(
                    f"{item.get('created_by')}: {item['comment']}"
                    for item in (interaction.get("feedbackHistory") or [])
                    if item.get("comment") is not None
                ),
                rating=interaction.get("rating"),
                issue_type=interaction.get("issueType"),
                time_taken=interaction.get("timeTaken"),
            )
            for interaction in (self._data.get("interactions") or [])
        ]

    @property
    def openai_messages(self) -> list[dict]:
        msg = []
        for interaction in self._data["interactions"]:
            if interaction["role"] == "_internal":
                continue

            if interaction["role"] in {"system", "user", "assistant"}:
                msg.append({"role": interaction["role"], "content": interaction["content"]})

            # TODO: Handle tool calls?
        return msg

    @property
    def collected_fields(self) -> dict[str, t.Any]:
        return self._data.get("collectedFields") or {}

    @property
    def closing_answers(self) -> dict[str, t.Any]:
        return self._data.get("closingAnswers") or {}

    def __str__(self) -> str:
        return f'<{type(self).__name__} name="{self.name}">'
