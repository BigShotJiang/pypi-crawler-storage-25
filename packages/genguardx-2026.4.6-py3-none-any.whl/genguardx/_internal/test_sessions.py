import typing as t
from functools import cached_property

from genguardx._internal.mixins.auditable import Auditable
from genguardx._internal.util.base_api import ApiBase
from genguardx._internal.util.constants import Objects, URLS


if t.TYPE_CHECKING:
    from genguardx._internal.feedback_portals import FeedbackPortal
    from genguardx._internal.pipelines import Pipeline
    from genguardx._internal.test_runs import TestRun


class TestSession(ApiBase, Auditable):
    _object_type = Objects.TEST_SESSION.value
    _LIST_URL = URLS.TEST_SESSION_PATH.value

    _available_filter_names = {"name", "group"}

    def __init__(self, id: int) -> None:
        self._data = TestSession._get_data_item(id=id)

    @property
    def id(self) -> int:
        return self._data["id"]

    @property
    def name(self) -> str:
        return self._data["name"]

    def __str__(self) -> str:
        return f'<{type(self).__name__} name="{self.name}">'

    @cached_property
    def pipeline(self) -> "Pipeline":
        from genguardx._internal.pipelines import Pipeline

        return Pipeline(id=self._data["pipelineVersionId"])

    @cached_property
    def feedback_portal(self) -> "FeedbackPortal":
        from genguardx._internal.feedback_portals import FeedbackPortal

        return FeedbackPortal(id=self._data["pipelineVersionId"])

    @cached_property
    def latest_closed_run(self) -> t.Optional["TestRun"]:
        from genguardx._internal.test_runs import TestRun

        if self._data.get("latestClosedRun", {}).get("id") is None:
            return None
        return TestRun(id=self._data["latestClosedRun"]["id"])

    @property
    def expected_outcome(self) -> dict[str, t.Any]:
        return self._data["expectedOutcome"]

    @property
    def runs(self) -> t.Iterator["TestRun"]:
        from genguardx._internal.test_runs import TestRun

        for run_data in TestRun._get_data_list(testSessionId=self._data["id"]):
            yield TestRun(id=run_data["id"])
