import datetime
import typing as t

import dateutil.parser

from genguardx._internal.mixins.auditable import Auditable
from genguardx._internal.mixins.searchable import Searchable
from genguardx._internal.util.base_api import ApiBase
from genguardx._internal.util.constants import Objects, URLS


class User(ApiBase, Auditable, Searchable):
    """Represents a User that is registered.

    :param username:             The username of the User to fetch.
    :param id:                   The ID of the User to fetch.
    """

    _object_type = Objects.USER.value
    _LIST_URL = URLS.USER_PATH.value
    _available_filter_names = {"username", "contains"}
    _str_filters = {"username", "alias", "contains"}
    FILTER_API_PARAMETER_MAPPING = {"contains": "keyword", "username": "name"}

    def __init__(self, username: t.Optional[str] = None, id: t.Optional[int] = None) -> None:
        filters: dict[str, t.Any] = {}
        if id is not None:
            filters["ids"] = id
        if username is not None:
            filters["name"] = username
        self._data = self._get_data(**filters)

    @property
    def id(self) -> int:
        """The ID that is unique to every User."""
        return self._data["id"]

    @property
    def email(self) -> str:
        """The email of the User as registered."""
        return self._data["email"]

    @property
    def first_name(self) -> str:
        """The first name of the User as registered."""
        return self._data["firstName"]

    @property
    def last_name(self) -> str:
        """The last name of the User as registered."""
        return self._data["lastName"]

    @property
    def is_active(self) -> bool:
        """The boolean indicating if the User is activated on the platform or not."""
        return self._data["isActive"]

    @property
    def department(self) -> str:
        """The department of the User as registered."""
        return self._data["department"]

    @property
    def user_roles(self) -> list[dict[str, str]]:
        """The roles assigned to this user."""
        return self._data["roleNames"]

    @property
    def username(self) -> str:
        """The username of the User as registered."""
        return self._data["name"]

    @property
    def last_login_date(self) -> datetime.datetime | None:
        """The date when the User had logged in last time."""
        last_login_date_data = self._data["lastLoginDate"]
        if last_login_date_data is not None:
            return dateutil.parser.parse(last_login_date_data)
        return None

    def __str__(self) -> str:
        return f'<{type(self).__name__} username="{self.username}">'


class PlatformSetting(ApiBase, Auditable):
    """Represents a Platform Setting object."""

    _object_type = Objects.PLATFORM_SETTING.value
    _LIST_URL = URLS.PLATFORM_SETTING_PATH.value

    def __init__(self) -> None:
        self._data = self._get_data()

    @property
    def id(self) -> int:
        """The ID of the Platform Setting"""
        return self._data["id"]

    @property
    def max_file_size(self) -> int:
        """The max file size that can be uploaded on the platform."""
        return self._data["maxContentLength"]

    @property
    def max_job_records(self) -> int:
        return self._data["maxJobRecords"]

    @property
    def allowed_file_extensions(self) -> list[str] | None:
        """The file extensions that are allowed on the platform for note and log attachments."""
        allowed_file_extensions = self._data["allowedFileExtensions"]
        if isinstance(allowed_file_extensions, str):
            return [ext.strip() for ext in allowed_file_extensions.split(",") if ext.strip() != ""]
        return None

    @property
    def allowed_python_imports(self) -> list[str] | None:
        """The python libraries and packages that are allowed in the definition of an object."""
        allowed_python_imports = self._data["allowedPythonImports"]
        if isinstance(allowed_python_imports, str):
            return [imp.strip() for imp in allowed_python_imports.split(",") if imp.strip() != ""]
        return None

    def __str__(self) -> str:
        return f"<{type(self).__name__}>"
