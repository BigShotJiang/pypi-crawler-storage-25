import typing as t

from genguardx._internal.mixins.auditable import Auditable
from genguardx._internal.util.base_api import ApiBase
from genguardx._internal.util.constants import Objects, URLS


if t.TYPE_CHECKING:
    from genguardx._internal.test_sessions import TestSession


class FeedbackPortal(ApiBase, Auditable):
    _object_type = Objects.FEEDBACK_PORTAL.value
    _LIST_URL = URLS.FEEDBACK_PORTAL_PATH.value

    def __init__(self, name: t.Optional[str] = None, id: t.Optional[int] = None) -> None:
        filters: dict[str, t.Any] = {}
        if id is not None:
            filters["ids"] = id
        if name is not None:
            filters["name"] = name
        self._data = self._get_data(**filters)

    @property
    def name(self) -> str:
        return self._data["name"]

    @property
    def description(self) -> str:
        return self._data["description"]

    @property
    def instructions(self) -> str:
        return self._data["instructions"]

    @property
    def test_sessions(self) -> t.Iterator["TestSession"]:
        from genguardx._internal.test_sessions import TestSession

        for session_data in TestSession._get_data_list(feedbackPortalId=self._data["id"]):
            yield TestSession(id=session_data["id"])
