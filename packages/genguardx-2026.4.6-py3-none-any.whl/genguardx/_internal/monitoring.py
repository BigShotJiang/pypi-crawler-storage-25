import typing as t

from genguardx._internal.mixins.auditable import Auditable
from genguardx._internal.mixins.searchable import Searchable
from genguardx._internal.mixins.simulatable import Simulatable
from genguardx._internal.util.base_api import ApiBase
from genguardx._internal.util.constants import Objects, URLS


class Monitoring(
    ApiBase,
    Auditable,
    Simulatable,
    Searchable,
):
    """Represents a registered Monitoring.

    :param name:    The name of the Monitoring to fetch.
    :param id:      The ID of the Monitoring to fetch. If provided, name is not used.
    """

    _object_type = Objects.MONITORING.value
    _LIST_URL = URLS.MONITORING_PATH.value
    _available_filter_names = {"alias", "name"}

    def __init__(self, name: t.Optional[str] = None, id: t.Optional[int] = None) -> None:
        filters: dict[str, t.Any] = {}
        if id is not None:
            filters["ids"] = id
        if name is not None:
            filters["name"] = name
        elif id is None:  # If ID is none, we need to get the "current" version
            filters["singleVersionOnly"] = True
        self._data = self._get_data(**filters)

    @property
    def id(self) -> int:
        """The ID that is unique to this Monitoring object."""
        return self._data["id"]

    @property
    def name(self) -> str:
        """The name of the Monitoring object as registered."""
        return self._data["name"]

    @property
    def description(self) -> str:
        """The description registered for the Monitoring object."""
        return self._data["description"]

    class Job(Simulatable.Job):
        _object_class = staticmethod(lambda: Monitoring)

    def __str__(self) -> str:
        return f'<{type(self).__name__} name="{self.name}">'
