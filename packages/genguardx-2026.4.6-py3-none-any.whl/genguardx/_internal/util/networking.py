import json
import os
import typing as t

import httpx
import importlib_metadata

from genguardx._internal import whoami


def ujoin(base: str, url: str) -> str:
    return str(base).rstrip("/") + "/" + str(url).lstrip("/")


class SessionConfig:
    """
    Note that this is only the configs set for the requests Session. So, for example: timeout, user, workspace
    are not kept here.
    - timeout is a request level config, can change for every API call
    - user, workspace is for auth in the request, can change for every API call
    """

    api_url: str

    @staticmethod
    def get_value(key: str, default: str) -> str:
        return os.environ.get(key, str(default))

    @property
    def api_url(self) -> str:
        # Earlier, we used to need the /api URL as we used to use corridor-api. Now, we just need the corridor
        # instance URL. So, add /api to the URL if it's not already there.
        url = self.get_value("CORRIDOR_API_URL", "http://localhost:5002")
        return url.rstrip("/") + "/api"

    @api_url.setter
    def api_url(self, val: str) -> None:
        os.environ["CORRIDOR_API_URL"] = val


class ApiAuth(httpx.Auth):
    user_api_key: str | None
    workspace: str | None

    def __init__(self, *args, **kwargs) -> None:
        self.user_api_key = None
        super().__init__(*args, **kwargs)

    def init_user(self, user_api_key: str) -> None:
        self.user_api_key = user_api_key

    def auth_flow(self, request: httpx.Request) -> t.Generator[httpx.Request, httpx.Response, None]:
        if self.user_api_key is None:
            whoami()  # Prints that the session is not initialised
            return
        request.headers["x-api-key"] = self.user_api_key
        yield request


class NetworkSession:
    client: httpx.Client

    def __init__(self) -> None:
        self.client = self._get_default_client()

    @staticmethod
    def _get_default_client(**kwargs) -> httpx.Client:
        config = SessionConfig()

        # Timeout
        timeout = SessionConfig.get_value("CORRIDOR_API_TIMEOUT", "300")
        try:
            timeout = int(timeout)
        except (TypeError, ValueError):
            timeout = 300

        # set default parameter for httpx.Client configuration
        defaults = {
            "base_url": config.api_url,
            "auth": ApiAuth(),
            "timeout": timeout,
            "headers": {"user-agent": f"genguardx/{importlib_metadata.version('genguardx')}"},
        }
        for key, val in defaults.items():
            kwargs.setdefault(key, val)

        return httpx.Client(**kwargs)

    @staticmethod
    def parse_json(resp: httpx.Response) -> dict:
        """Show a good error about the failure for the response"""
        try:
            return resp.json()
        except json.JSONDecodeError:
            msg = f"For {resp.request.method} at {resp.url}\n"
            if resp.is_error:  # Print Status if it is a error status-code
                msg += f"Got Status Code = {resp.status_code} (reason={resp.reason_phrase})\n"
            msg += "Got response:\n"
            try:  # Attempt to get the response as a JSON - FIXME: This will always fail ?
                msg += str(resp.json())
            except Exception:
                try:  # Get the text message from the body
                    n = 500
                    text = resp.text[:n]
                    hidden_n = len(resp.text) - n
                    msg += text + (f"... {hidden_n} more chars" if hidden_n > 0 else "")
                except Exception:  # Unable to get the response
                    msg += "\n"
            print(f"Failed to parse JSON from response: {msg}")
            raise

    @staticmethod
    def split_json_files(
        data: dict | list | tuple,
        path: str = "",  # path is an internal arg - Only used when calling this function recursively.
    ) -> tuple[dict[str, t.Any] | list[t.Any], dict[str, bytes | tuple]]:
        """
        Take a `data` dictionary which merged `json` and `files` and separate them out.
        A file needs to be defined as `bytes` or a `tuple` of `(filename, bytes)`.
        """
        newjson: dict[str, t.Any] | list[t.Any] = {}
        newfiles: dict[str, bytes | tuple] = {}
        if isinstance(data, (list, tuple)):
            newjson = []
            for iitem, item in enumerate(data):
                subpath = f"{path}[{iitem}]"
                if isinstance(item, bytes):
                    newfiles[subpath] = item
                else:
                    innerjson, innerfiles = NetworkSession.split_json_files(item, subpath)
                    newfiles = {**newfiles, **innerfiles}
                    newjson.append(innerjson)
        elif isinstance(data, dict):
            newjson = {}
            for key, val in data.items():
                subpath = f"{path}.{key}" if path else key
                if isinstance(val, (bytes, tuple)):
                    newfiles[subpath] = val
                else:
                    innerjson, innerfiles = NetworkSession.split_json_files(val, subpath)
                    newjson[key] = innerjson
                    newfiles = {**newfiles, **innerfiles}
        else:  # Should never occur, just added for safety
            newjson = data
        return newjson, newfiles

    def raw_response(
        self,
        url: str,
        *,
        params: t.Optional[dict] = None,
        data: t.Optional[dict] = None,  # A combination of JSON and Files
    ) -> httpx.Response:
        """
        :param url:    The URL to call
        :param params: The query params to use when making the API call
        :param data:   The data to be sent (A mix of files and json payloads)
        """
        json_data, files = None, None
        if data is not None:
            json_data, files = NetworkSession.split_json_files(data)

        return self.client.request(
            "POST" if files is not None else "GET",
            url=url,
            params=params,
            json=json_data if not files else None,  # JSON is used if no files are present
            data=(  # multipart-form-data is used if files are present
                {"json": json.dumps(json_data)} if files else None
            ),
            files=files,
            follow_redirects=False,
        )

    def response(
        self,
        url: str,
        *,
        params: t.Optional[dict] = None,
        data: t.Optional[dict] = None,  # A combination of JSON and Files
    ) -> dict:
        resp = self.raw_response(url, params=params, data=data)
        return self.parse_json(resp)


api = NetworkSession()
