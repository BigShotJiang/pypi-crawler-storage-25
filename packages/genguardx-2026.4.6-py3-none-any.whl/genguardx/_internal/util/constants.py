import dataclasses
import enum
import io
import typing as t


if t.TYPE_CHECKING:
    from genguardx._internal.util.base_api import ApiBase


URL_PREFIX = "/v1"


class URLS(enum.Enum):
    GLOBAL_FUNCTION_PATH = URL_PREFIX + "/global_functions"
    SCHEDULED_JOB_PATH = URL_PREFIX + "/scheduled_jobs"
    DATA_TABLE_PATH = URL_PREFIX + "/data_tables"
    QUALITY_PROFILE_PATH = URL_PREFIX + "/quality_profiles"
    ATTACHMENTS_PATH = URL_PREFIX + "/attachments"
    USER_PATH = URL_PREFIX + "/users"
    META_PATH = URL_PREFIX + "/meta"
    PERMISSIBLE_PURPOSE_PATH = URL_PREFIX + "/permissible_tags"
    APPROVAL_WORKFLOW_PATH = URL_PREFIX + "/approval_workflows"
    LINEAGE_PATH = URL_PREFIX + "/lineage"
    GROUP_PATH = URL_PREFIX + "/groups"
    REPORT_PATH = URL_PREFIX + "/reports"
    FIELD_PATH = URL_PREFIX + "/fields"
    PLATFORM_SETTING_PATH = URL_PREFIX + "/platform_settings"
    PROMPT_PATH = URL_PREFIX + "/prompts"
    FOUNDATION_MODEL_PATH = URL_PREFIX + "/foundation_models"
    RAG_PATH = URL_PREFIX + "/rags"
    PIPELINE_PATH = URL_PREFIX + "/pipelines"
    INPUTS_PATH = URL_PREFIX + "/inputs"
    MONITORING_PATH = URL_PREFIX + "/monitoring"
    ANNOTATION_QUEUE_PATH = URL_PREFIX + "/annotation_queues"
    TEST_SESSION_PATH = URL_PREFIX + "/test_sessions"
    TEST_RUN_PATH = URL_PREFIX + "/test_runs"
    FEEDBACK_PORTAL_PATH = URL_PREFIX + "/feedback_portals"
    SIMULATION_PATH = URL_PREFIX + "/simulations"


class WorkflowStatus(enum.Enum):
    DRAFT = "Draft"
    PENDING_APPROVAL = "Pending Approval"
    APPROVED = "Approved"
    REJECTED = "Rejected"


class AuditAction(enum.Enum):
    CREATED = "Created"
    STATUS_CHANGED = "Status Changed"
    CHANGED = "Changed"
    DELETED = "Deleted"
    EDITED = "Edited"


def get_key_values_of_struct_type(struct_type: str) -> dict:
    """
    Given STRUCT type with keys and their value type, convert type to python dictionary
    This function handles the cases where key values can be nested types like TypedDict[{'a':dict[x,y]}] having
    commas and colon inside them.

    "TypedDict[{'key1':val_type1,'key2':val_type2}]" -> {"key1":"val_type1", "key2":"val_type2"}

    Args:
        struct_type (str): valid STRUCT feature type.

    Returns:
        dict: with keys and their value type.
    """
    result = {}
    current_string = ""
    stack = []

    if not struct_type.startswith("TypedDict[{") or not struct_type.endswith("}]"):
        raise ValueError(f"Invalid TypedDict type '{struct_type}'")

    inner_string = struct_type[len("TypedDict[{") : -2]  # remove 'TypedDict[{' and '}]'
    for char in inner_string:
        if char == "[":
            stack.append("[")
        elif char == "]":
            stack.pop()
        elif char == "," and len(stack) == 0:
            try:
                key, value = current_string.split(":", 1)
            except ValueError:
                raise ValueError(f"Expected key and value-type separated by colon, got '{current_string}'")
            key, value = key.strip(), value.strip()
            if not (key.startswith('"') and key.endswith('"')) and not (key.startswith("'") and key.endswith("'")):
                raise ValueError(f"Key {key} should be enclosed in single or double quotes")
            key = key[1:-1].strip()  # Remove quotes
            if key in result:
                raise ValueError(f"Duplicate key '{key}' found in struct.")
            result[key] = value
            current_string = ""
            continue
        current_string += char

    if current_string:
        try:
            key, value = current_string.split(":", 1)
        except ValueError:
            raise ValueError(f"Expected key and value-type separated by colon, got '{current_string}'")
        key, value = key.strip(), value.strip()
        if not (key.startswith('"') and key.endswith('"')) and not (key.startswith("'") and key.endswith("'")):
            raise ValueError(f"Key {key} should be enclosed in single or double quotes")
        key = key[1:-1].strip()  # Remove quotes
        if key in result:
            raise ValueError(f"Duplicate key '{key}' found in struct.")
        result[key] = value

    return result


class DataType(enum.Enum):
    """
    Holds a list of possible types that we allow.
    If a type is a complex type (like Array<Int>)
    """

    NUMERICAL = "float"
    STRING = "str"
    BOOLEAN = "bool"

    ARRAY = "list"  # Needs a itemtype. Example: list[float]
    MAP = "dict"  # a.k.a dict. Needs a keytype, valtype. Example: dict[int, str]
    # dict with multiple valtypes. Needs keys and their valtype.
    # Example: TypedDict[{'key1': int, 'key2': str}]
    STRUCT = "TypedDict"

    @classmethod
    def get(
        cls, val: t.Union["DataType", str, list], orig_val: t.Union["DataType", str, list, None] = None
    ) -> t.Union["DataType", list]:
        if isinstance(val, cls):
            return val
        if isinstance(val, list):
            return [cls.get(i) for i in val]
        if isinstance(val, dict):
            return {k: cls.get(v) for k, v in val.items()}
        val = str(val).strip()
        if val == cls.NUMERICAL.value:
            return cls.NUMERICAL
        if val == cls.STRING.value:
            return cls.STRING
        if val == cls.BOOLEAN.value:
            return cls.BOOLEAN
        if val.startswith(cls.ARRAY.value):
            val = val[len(cls.ARRAY.value) :].strip()
            assert val[0] == "[" and val[-1] == "]"
            val = val[1:-1].strip()
            return [cls.ARRAY, cls.get(val, orig_val=val if orig_val is None else orig_val)]
        if val.startswith(cls.MAP.value):
            val = val[len(cls.MAP.value) :].strip()
            assert val[0] == "[" and val[-1] == "]"
            val = val[1:-1].strip()

            # Need to ensure split is at same level - so we don't get confused
            # by nested complex types like: 'map[string, map[int, string]]'
            bracket_depth = 0
            splitpoints = []
            for ic, c in enumerate(val):
                if c == "[":
                    bracket_depth += 1
                if c == "]":
                    bracket_depth -= 1
                if c == "," and bracket_depth == 0:
                    splitpoints.append(ic)
                    break

            if len(splitpoints) == 1:
                val1 = val[: splitpoints[0]].strip()
                val2 = val[splitpoints[0] + len(",") :].strip()
                return [
                    cls.MAP,
                    cls.get(val1.strip(), orig_val=val if orig_val is None else orig_val),
                    cls.get(val2.strip(), orig_val=val if orig_val is None else orig_val),
                ]
        if val.startswith(cls.STRUCT.value):
            return [
                cls.STRUCT,
                {
                    key: cls.get(val_type, orig_val=val if orig_val is None else orig_val)
                    for key, val_type in get_key_values_of_struct_type(val).items()
                },
            ]

        msg = f"Unknown value provided: {val}"
        if orig_val is not None:
            msg += f", got from parsing {orig_val}"
        raise ValueError(msg)

    @classmethod
    def to_python_type(cls, val: t.Union["DataType", list], *, allow_missing: bool = True) -> str:
        """
        Use the python typing library. Expects `import typing as t`
        """
        val = DataType.get(val)

        if val == DataType.NUMERICAL:  # Numerical is always float - so we use that here too
            annotation = "float"
        elif val == DataType.STRING:
            annotation = "str"
        elif val == DataType.BOOLEAN:
            annotation = "bool"
        elif isinstance(val, list) and val[0] == DataType.ARRAY:
            annotation = f"list[{cls.to_python_type(val[1])}]"
        elif isinstance(val, list) and val[0] == DataType.MAP:
            # Key cannot take in None values in pyspark
            key_type = cls.to_python_type(val[1], allow_missing=False)
            value_type = cls.to_python_type(val[2])
            annotation = f"dict[{key_type}, {value_type}]"
        elif isinstance(val, list) and val[0] == DataType.STRUCT:
            fields = "{" + ", ".join(f"{key!r}: {cls.to_python_type(value)}" for key, value in val[1].items()) + "}"
            annotation = f't.TypedDict("T", {fields}, total=False)'
        else:
            raise TypeError(f"Unknown data type: {val}")
        return f"t.Optional[{annotation}]" if allow_missing else annotation


# FIXME: In corridor_api, JobType is ExecutionType, inconsistency can potentially cause issues
class JobType(enum.Enum):
    SIMULATION = "Simulation"
    COMPARISON = "Comparison"
    HILL_CLIMBING = "HillClimbing"
    MONITORING = "Monitoring"


class Objects(enum.Enum):
    DATA_TABLE = "DataTable"
    QUALITY_CHECK = "QualityProfile"
    DATA_ELEMENT = "DataElement"
    FEATURE = "Feature"
    DATASET = "Dataset"
    EXPERIMENT = "Experiment"
    MODEL = "Model"
    REPORT = "Report"
    GLOBAL_FUNCTION = "GlobalFunction"
    APPROVAL_WORKFLOW = "ApprovalWorkflow"
    FIELD = "Field"
    Algorithm = "Algorithm"
    USER = "User"
    PLATFORM_SETTING = "PlatformSetting"
    PROMPT = "Prompt"
    FOUNDATION_MODEL = "FoundationModel"
    RAG = "Rag"
    PIPELINE = "Pipeline"
    MONITORING = "Monitoring"
    ANNOTATION_QUEUE = "AnnotationQueue"
    TEST_SESSION = "TestSession"
    FEEDBACK_PORTAL = "FeedbackPortal"

    @classmethod
    def name_mapping(cls) -> dict["Objects", str]:
        """Mapping for Object names as displayed on the UI"""
        return {
            cls.DATA_TABLE: "Data Table",
            cls.QUALITY_CHECK: "Quality Profile",
            cls.GLOBAL_FUNCTION: "Global Function",
            cls.APPROVAL_WORKFLOW: "Approval Workflow",
            cls.PLATFORM_SETTING: "Platform Settings",
            cls.PROMPT: "Prompt",
            cls.FOUNDATION_MODEL: "Foundation Model",
            cls.RAG: "Rag",
            cls.ANNOTATION_QUEUE: "Annotation Queue",
            cls.MONITORING: "Monitoring",
            cls.TEST_SESSION: "Test Session",
            cls.FEEDBACK_PORTAL: "Feedback Portal",
        }

    @classmethod
    def class_mapping(cls) -> dict["Objects", type["ApiBase"]]:
        from genguardx._internal.annotation_queue import AnnotationQueue
        from genguardx._internal.data_tables import DataTable
        from genguardx._internal.feedback_portals import FeedbackPortal
        from genguardx._internal.models import Model
        from genguardx._internal.monitoring import Monitoring
        from genguardx._internal.pipelines import Pipeline
        from genguardx._internal.prompts import Prompt
        from genguardx._internal.quality_check import QualityCheck
        from genguardx._internal.rags import Rag
        from genguardx._internal.resources import (
            GlobalFunction,
            Report,
        )
        from genguardx._internal.settings import PlatformSetting, User
        from genguardx._internal.test_sessions import TestSession

        """Mapping for corridor python class"""
        return {
            cls.DATA_TABLE: DataTable,
            cls.QUALITY_CHECK: QualityCheck,
            cls.GLOBAL_FUNCTION: GlobalFunction,
            cls.REPORT: Report,
            cls.USER: User,
            cls.PLATFORM_SETTING: PlatformSetting,
            cls.PROMPT: Prompt,
            cls.FOUNDATION_MODEL: Model,
            cls.RAG: Rag,
            cls.PIPELINE: Pipeline,
            cls.ANNOTATION_QUEUE: AnnotationQueue,
            cls.MONITORING: Monitoring,
            cls.TEST_SESSION: TestSession,
            cls.FEEDBACK_PORTAL: FeedbackPortal,
        }

    @classmethod
    def display_name(cls, obj: "str | Objects") -> str:
        """Display names for Objects"""
        return cls.name_mapping().get(Objects(obj), Objects(obj).value)


SIMULATABLE_OBJECTS = (
    Objects.QUALITY_CHECK,
    Objects.FOUNDATION_MODEL,
    Objects.PIPELINE,
    Objects.PROMPT,
    Objects.RAG,
    Objects.MONITORING,
    Objects.REPORT,
    Objects.GLOBAL_FUNCTION,
)


class ReportParameterType(enum.Enum):
    STRING = "String"
    NUMBER = "Number"
    # user can select any DE/Feature/Model registered on the platform as report inputs
    SINGLE_OBJECT = "SingleObject"
    # user can select any prompt, foundation model, rag, global function registered on the platform
    # as report inputs
    DYNAMIC_OBJECT = "DynamicObject"

    @classmethod
    def name_mapping(cls) -> dict["ReportParameterType", str]:
        return {cls.SINGLE_OBJECT: "Single Object"}

    @classmethod
    def display_name(cls, obj: "ReportParameterType | str") -> str:
        """Display names for Report Parameter Type"""
        return cls.name_mapping().get(ReportParameterType(obj), ReportParameterType(obj).value)


@dataclasses.dataclass(frozen=True)
class AttachmentFile:
    name: str
    content: io.BytesIO


class ReportOutputType(enum.Enum):
    FIGURE = "Figure"  # plotly figure
    METRIC = "Metric"  # dict of metric for different entity

    @classmethod
    def display_name(cls, obj: "ReportOutputType | str") -> str:
        """Display names for Report Output Type"""
        return ReportOutputType(obj).value
