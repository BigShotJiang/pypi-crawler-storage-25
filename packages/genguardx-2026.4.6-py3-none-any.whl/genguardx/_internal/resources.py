import dataclasses
import typing as t

from genguardx._internal.mixins.auditable import Auditable
from genguardx._internal.mixins.searchable import Searchable
from genguardx._internal.mixins.simulatable import Simulatable
from genguardx._internal.mixins.with_python_code import WithPythonCode
from genguardx._internal.mixins.workflowable import Workflowable
from genguardx._internal.util import utils
from genguardx._internal.util.base_api import ApiBase
from genguardx._internal.util.constants import Objects, ReportOutputType, ReportParameterType, SIMULATABLE_OBJECTS, URLS
from genguardx._internal.util.lang_utils import cast_value, parse_user_literal


if t.TYPE_CHECKING:
    from genguardx._internal.data_tables import DataTable
    from genguardx._internal.models import Model
    from genguardx._internal.pipelines import Pipeline
    from genguardx._internal.prompts import Prompt
    from genguardx._internal.rags import Rag


@dataclasses.dataclass(frozen=True)
class InputArgument:
    alias: str
    type: str
    is_mandatory: bool
    default_value: t.Any


@dataclasses.dataclass(frozen=True)
class Tab:
    name: str
    report_outputs: list["TabReportOutput"]


@dataclasses.dataclass(frozen=True)
class TabReportOutput:
    report_output: "ReportOutput"
    width: str
    height: str


class GlobalFunction(ApiBase, Auditable, Workflowable, Searchable, WithPythonCode):
    """Represents a GlobalFunction that is registered.

    :param alias:   The alias of the GlobalFunction to fetch.
    :param name:    The name of the GlobalFunction to fetch.
    :param id:      The ID of the GlobalFunction to fetch.
    """

    _object_type = Objects.GLOBAL_FUNCTION.value
    _LIST_URL = URLS.GLOBAL_FUNCTION_PATH.value
    _available_filter_names = {"status", "alias", "name", "type", "contains", "group"}

    class Job(Simulatable.Job):
        _object_class = staticmethod(lambda: GlobalFunction)

    def __init__(
        self,
        alias: t.Optional[str] = None,
        version: t.Optional[int] = None,
        id: t.Optional[int] = None,
    ) -> None:
        filters: dict[str, t.Any] = {}
        if id is not None:
            filters["ids"] = id
        if alias is not None:
            filters["alias"] = alias
        if version is not None:
            filters["version"] = version
        elif id is None:  # If ID is none, we need to get the "current" version
            filters["singleVersionOnly"] = True
        self._data = self._get_data(**filters)

    @property
    def id(self) -> int:
        """
        The ID that is unique to every GlobalFunction. (and is different for every version of the GlobalFunction too.)
        """
        return self._data["id"]

    @property
    def description(self) -> str:
        """The description registered for the GlobalFunction."""
        return self._data["description"]

    @property
    def note(self) -> str:
        """Any notes added during registration."""
        return self._data["note"]

    @property
    def group(self) -> str:
        """The group that this Function belongs to."""
        return self._data["group"]

    @property
    def type(self) -> str:
        """The return type of the GlobalFunction - float, str, etc."""
        return self._data["type"]

    @property
    def version(self) -> int:
        """The version of this GlobalFunction."""
        return self._data["version"]

    @property
    def current_status(self) -> str:
        """The current workflow status of the GlobalFunction."""
        return self._data["currentStatus"]

    @property
    def definition(self) -> str | None:
        """The definition for the GlobalFunction"""
        if self._data.get("definition"):
            return self._data["definition"].get("runLogic")
        return None

    @property
    def alias(self) -> str:
        """The alias of the GlobalFunction as registered.

        This is the alias used to refer to the GlobalFunction when creating definitions
        """
        return self._data["alias"]

    @property
    def name(self) -> None:
        """The name of the GlobalFunction as registered."""
        return self._data["name"]

    @property
    def arguments(self) -> list[InputArgument]:
        """The list of namedtuples containing alias, type and default_value for arguments of Global Function."""
        return [
            InputArgument(
                inp["alias"],
                inp["inputType"],
                inp["isMandatory"],
                cast_value(
                    parse_user_literal(
                        inp["defaultValue"],
                        inp["inputType"],
                    ),
                    inp["inputType"],
                )
                if inp["isMandatory"] is False
                else None,
            )
            for inp in self._data["functionInputs"]
        ]

    @property
    def inputs(self) -> list["GlobalFunction"]:
        """The list of input Global Function(s)/RTP(s) to the Global Function"""
        return [GlobalFunction(id=i) for i in self._data["featureVersionIds"]]

    def __str__(self) -> str:
        return f'<{type(self).__name__} alias="{self.alias}", version={self.version}>'

    @classmethod
    def declare(
        cls,
        *,
        name: t.Optional[str] = None,  # If not provided, use alias (function name)
        group: t.Optional[str] = None,  # Optional value
    ) -> t.Callable:
        def inner(func: t.Callable) -> t.Callable:
            func._corridor_metadata = {
                "cls": cls,
                "name": name,
                "group": group,
            }
            return func

        return inner


class Report(ApiBase, Auditable, Searchable, Workflowable):
    """Represents a Report that is registered.

    :param name:   The name of the Report to fetch.
    :param version: The version of the Report to fetch. If not provided, the latest approved version is used.
    :param id:      The ID of the Report to fetch. If provided, name and version are not used.

    Examples
    --------
    >>> report_1 = Report('report_1')
    >>> report_1.name
    'Report'
    >>> report_1.version
    1
    """

    _object_type = Objects.REPORT.value
    _LIST_URL = URLS.REPORT_PATH.value

    _available_filter_names = {
        "status",
        "keyword",
        "permissible_purpose",
        "name",
        "contains",
        "group",
        "object_types",
    }
    # Object_type is mapped to object_types API parameter while filtering Reports
    FILTER_API_PARAMETER_MAPPING = {
        "status": "statuses",
        "permissible_purpose": "permissibleTags",
        "group": "group",
        "contains": "keyword",
        "object_types": "objectTypes",
    }

    class Job(Simulatable.Job):
        _object_class = staticmethod(lambda: Report)

    def __init__(
        self, name: t.Optional[str] = None, version: t.Optional[int] = None, id: t.Optional[int] = None
    ) -> None:
        filters: dict[str, t.Any] = {}
        if id is not None:
            filters["ids"] = id
        if name is not None:
            filters["name"] = name
        if version is not None:
            filters["version"] = version
        elif id is None:  # If ID is none, we need to get the "current" version
            filters["singleVersionOnly"] = True
        self._data = self._get_data(**filters)

    @property
    def id(self) -> int:
        """The ID that is unique to every Report. (and is different for every version of the Report too.)"""
        return self._data["id"]

    @property
    def name(self) -> str:
        """The name of the Report as registered."""
        return self._data["name"]

    @property
    def version(self) -> int:
        """The version of this Report."""
        return self._data["version"]

    @property
    def description(self) -> str:
        """The description registered for the Report."""
        return self._data["description"]

    @property
    def note(self) -> str:
        return self._data["note"]

    @property
    def group(self) -> str:
        """The group that this Report belongs to."""
        return self._data["group"]

    @property
    def current_status(self) -> str:
        """The current workflow status of the Report."""
        return self._data["currentStatus"]

    @utils.classproperty
    def _possible_filter_values__object_type(cls) -> set[str]:
        return {Objects.display_name(obj) for obj in SIMULATABLE_OBJECTS}

    @property
    def definition(self) -> str | None:
        if self._data.get("definition"):
            return self._data["definition"].get("runLogic")
        return None

    @property
    def object_types(self) -> list[str]:
        """The list of objects for which the report is designed to run."""
        return [Objects.display_name(i["objectType"]) for i in self._data["objectTypes"]]

    @property
    def inputs(self) -> list[GlobalFunction]:
        return [GlobalFunction(id=i) for i in self._data["featureVersionIds"]]

    @property
    def parameters(self) -> list["ReportParameter"]:
        """The list of report input parameters for the report."""
        return [ReportParameter(self, param) for param in self._data["parameters"]]

    @property
    def outputs(self) -> list["ReportOutput"]:
        """The list of report outputs for this Report."""
        return [ReportOutput(self, output) for output in self._data["outputs"]]

    @property
    def data_logic_examples(self) -> list["DataLogicExample"]:
        """The list of data logic examples for this Report."""
        return [DataLogicExample(self, example) for example in self._data.get("dataLogicExamples", [])]

    @property
    def allow_human_annotation(self) -> bool:
        return self._data["hasHumanAnnotation"] is True

    @property
    def dataframe_key(self) -> str | None:
        return self._data["dataframeKey"]

    @property
    def editable_columns(self) -> list[str]:
        cols = self._data["columnInfo"].get("annotationColumns")
        return cols if cols is not None else []

    def __str__(self) -> str:
        return f'<{type(self).__name__} name="{self.name}", version={self.version}>'

    @classmethod
    def declare(
        cls,
        *,
        object_types: list[str],
        name: t.Optional[str] = None,  # If not provided, use alias (function name)
        group: t.Optional[str] = None,  # Optional value
        risk_type: t.Optional[t.Literal["Accuracy", "Stability", "Bias", "Vulnerability", "Toxicity", "Others"]] = None,
        task_type: t.Optional[
            t.Literal[
                "Classification",
                "Templated Responses",
                "Generative Responses",
                "Summarization",
                "Others",
            ]
        ] = None,
        risk_domain: t.Optional[
            t.Literal["Model Risk Management", "Fair Lending", "Technology", "Infosec", "Others"]
        ] = None,
        evaluation_methodology: t.Optional[
            t.Literal["LLM-as-a-Judge", "Rule-based", "NLP / ML Algorithms", "Others"]
        ] = None,
        parameters: t.Sequence[dict] = (),
    ) -> t.Callable:
        def inner(func: t.Callable) -> t.Callable:
            func._corridor_metadata = {
                "cls": cls,
                "name": name,
                "object_types": object_types,
                "group": group,
                "risk_type": risk_type,
                "task_type": task_type,
                "risk_domain": risk_domain,
                "evaluation_methodology": evaluation_methodology,
                "parameters": parameters,
            }
            return func

        return inner


class ReportOutput(ApiBase, Auditable):
    """
    Represents a Report Output that is registered.

    Examples
    --------
    >>> report_out_1 = Report('report').outputs[0]
    >>> report_out_1.name
    'Report Output 1'
    """

    def __init__(self, report: Report, data: dict[str, t.Any]) -> None:
        self._report = report
        self._data = data

    @property
    def id(self) -> int:
        """The ID that is unique to every Report Output."""
        return self._data["id"]

    @property
    def name(self) -> str:
        """The name of the Report Output as registered."""
        return self._data["name"]

    @property
    def type(self) -> str:
        """The type of report output."""
        return ReportOutputType.display_name(self._data["type"])

    @property
    def definition(self) -> str | None:
        """The definition for report output."""
        if self._data.get("definition"):
            return self._data["definition"].get("runLogic")
        return None

    @property
    def inputs(self) -> list[GlobalFunction]:
        """The list of input Features to the Report Output."""
        return [GlobalFunction(id=i) for i in self._data["featureVersionIds"]]

    @property
    def additional_figures(self) -> list["AdditionalReportFigure"]:
        return [AdditionalReportFigure(self, figure) for figure in self._data.get("additionalFigures", [])]

    @property
    def report(self) -> Report:
        return self._report

    def __str__(self) -> str:
        return f'<ReportOutput report="{self.report.name}" name="{self.name}">'

    @classmethod
    def declare(
        cls,
        *,
        report: str,
        name: t.Optional[str] = None,  # If not provided, use alias (function name)
        width: t.Literal["33%", "50%", "100%"] = "100%",
        height: t.Optional[str] = None,
        evaluation_methodology: t.Literal["LLM-as-a-Judge", "Rule-based", "NLP / ML Algorithms", "Others"],
        show_in_comparison_view: bool = True,
    ) -> t.Callable:
        def inner(func: t.Callable) -> t.Callable:
            func._corridor_metadata = {
                "cls": cls,
                "name": name,
                "report": report,
                "width": width,
                "height": height,
                "evaluation_methodology": evaluation_methodology,
                "is_visible_in_comparison": show_in_comparison_view,
            }
            return func

        return inner


class DataLogicExample(ApiBase, Auditable):
    """Represents a Data Logic Example for a Report that is registered."""

    def __init__(self, report: Report, data: dict[str, t.Any]) -> None:
        self._report = report
        self._data = data

    @property
    def id(self) -> int:
        """The ID that is unique to every Data Logic Example."""
        return self._data["id"]

    @property
    def name(self) -> str:
        """The name of the Data Logic Example as registered."""
        return self._data["name"]

    @property
    def description(self) -> str:
        """The description for the Data Logic Example."""
        return self._data["description"]

    @property
    def sort_order(self) -> int:
        """The sort order of this Data Logic Example."""
        return self._data["sortOrder"]

    @property
    def definition(self) -> str | None:
        """The definition for the Data Logic Example."""
        if self._data.get("definition"):
            return self._data["definition"].get("runLogic")
        return None

    @property
    def input_global_functions(self) -> list[GlobalFunction]:
        """The list of input Global Function(s) to the Data Logic Example."""
        return [GlobalFunction(id=i) for i in self._data.get("featureVersionIds", [])]

    @property
    def input_tables(self) -> list["DataTable"]:
        """The list of table associated with this Data Logic Example."""
        from genguardx._internal.data_tables import DataTable

        return [DataTable(id=i) for i in self._data.get("tableIds", [])]

    @property
    def input_prompts(self) -> list["Prompt"]:
        """The list of prompts associated with this Data Logic Example."""
        from genguardx._internal.prompts import Prompt

        return [Prompt(id=i) for i in self._data.get("promptVersionIds", [])]

    @property
    def input_models(self) -> list["Model"]:
        """The list of models associated with this Data Logic Example."""
        from genguardx._internal.models import Model

        return [Model(id=i) for i in self._data.get("foundationModelVersionIds", [])]

    @property
    def input_rags(self) -> list["Rag"]:
        """The list of RAGs associated with this Data Logic Example."""
        from genguardx._internal.rags import Rag

        return [Rag(id=i) for i in self._data.get("ragVersionIds", [])]

    @property
    def report(self) -> Report:
        return self._report

    def __str__(self) -> str:
        return f'<DataLogicExample report="{self.report.name}" name="{self.name}">'

    @classmethod
    def declare(
        cls,
        *,
        report: str,
        name: str,
        description: t.Optional[str] = None,
    ) -> t.Callable:
        def inner(func: t.Callable[..., t.Any]) -> t.Callable[..., t.Any]:
            func._corridor_metadata = {
                "cls": cls,
                "name": name,
                "report": report,
                "description": description,
            }
            return func

        return inner


class AdditionalReportFigure(ApiBase, Auditable):
    """Represents an Additional Report Figure for a Report Output that is registered."""

    def __init__(self, report_output: ReportOutput, data: dict[str, t.Any]) -> None:
        self._report_output = report_output
        self._data = data

    @property
    def id(self) -> int:
        """The ID that is unique to every Additional Report Figure."""
        return self._data["id"]

    @property
    def name(self) -> str:
        """The name of the Additional Report Figure as registered."""
        return self._data["name"]

    @property
    def icon(self) -> str:
        """The icon for the Additional Report Figure."""
        return self._data["icon"]

    @property
    def sort_order(self) -> int:
        """The sort order of this Additional Report Figure."""
        return self._data["sortOrder"]

    @property
    def definition(self) -> str | None:
        """The definition for the Additional Report Figure."""
        if self._data.get("definition"):
            return self._data["definition"].get("runLogic")
        return None

    @property
    def input_global_functions(self) -> list[GlobalFunction]:
        """The list of input Global Function(s) to the Additional Report Figure."""
        return [GlobalFunction(id=i) for i in self._data.get("featureVersionIds", [])]

    @property
    def input_prompts(self) -> list["Prompt"]:
        """The list of prompts associated with this Additional Report Figure."""
        from genguardx._internal.prompts import Prompt

        return [Prompt(id=i) for i in self._data.get("promptVersionIds", [])]

    @property
    def input_models(self) -> list["Model"]:
        """The list of models associated with this Additional Report Figure."""
        from genguardx._internal.models import Model

        return [Model(id=i) for i in self._data.get("foundationModelVersionIds", [])]

    @property
    def input_rags(self) -> list["Rag"]:
        """The list of RAGs associated with this Additional Report Figure."""
        from genguardx._internal.rags import Rag

        return [Rag(id=i) for i in self._data.get("ragVersionIds", [])]

    @property
    def input_pipelines(self) -> list["Pipeline"]:
        """The list of pipelines associated with this Additional Report Figure."""
        from genguardx._internal.pipelines import Pipeline

        return [Pipeline(id=i) for i in self._data.get("pipelineVersionIds", [])]

    @property
    def report_output(self) -> ReportOutput:
        return self._report_output

    def __str__(self) -> str:
        return f'<AdditionalReportFigure report_output="{self.report_output.name}" name="{self.name}">'

    @classmethod
    def declare(
        cls,
        *,
        report_output: str,
        name: t.Optional[str] = None,  # If not provided, use alias (function name)
        icon: t.Optional[str] = None,
    ) -> t.Callable:
        def inner(func: t.Callable) -> t.Callable:
            func._corridor_metadata = {
                "cls": cls,
                "name": name,
                "report_output": report_output,
                "icon": icon,
            }
            return func

        return inner


class ReportParameter(ApiBase, Auditable):
    """Represents a Report Parameter for a Report that is registered."""

    def __init__(self, report: Report, data: dict[str, t.Any]) -> None:
        self._report = report
        self._data = data

    @property
    def id(self) -> int:
        """The ID that is unique to every Report Parameter."""
        return self._data["id"]

    @property
    def alias(self) -> str:
        """The alias of the Report Parameter as registered."""
        return self._data["alias"]

    @property
    def name(self) -> str:
        """The name of the Report Parameter as registered."""
        return self._data["name"]

    @property
    def description(self) -> str:
        """The description for the Report Parameter"""
        return self._data["description"]

    @property
    def is_mandatory(self) -> bool:
        """The boolian represeting if the parameter is mandatory for the Report."""
        return self._data["isMandatory"]

    @property
    def type(self) -> str:
        """The type of Report Parameter."""
        return ReportParameterType.display_name(self._data["type"])

    @property
    def report(self) -> Report:
        return self._report

    def __str__(self) -> str:
        return f'<ReportParameter report="{self.report.name}" name="{self.name}">'
