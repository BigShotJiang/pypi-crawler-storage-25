# SPDX-License-Identifier: Apache-2.0
"""Substrate capability matrix.

Maps ``(adapter_name, capability_name) -> bool`` so callers can ask
"does the active substrate support post_tool_observe?" without trying
to call the method and catching ``NotImplementedError``.

Capabilities tracked here align with the SubstrateAdapter Protocol
methods plus the Plan §«Substrate b/a 雙路徑」 doctrine:

    * ``chat``                  — minimal LLMBackend chat surface
    * ``spawn_agent``           — fork sub-agent with parent tools
    * ``post_tool_observe``     — observation-channel deny / rewrite
    * ``state_persist``         — cross-session key→value store
    * ``subagent_fork``         — heavyweight true process fork
                                  (a-path / Sancio-equivalent)

The matrix is conservative: ``True`` only when the adapter is known to
implement the capability with the documented semantics. Missing
combinations default to ``False`` via ``capability_supported``.

This is a placeholder seed. T2.E integration test will refine each
row by actually calling each method on a constructed adapter and
recording behavior; the matrix is the cached form of that probe so
hot-path callers don't pay the introspection cost on every dispatch.
"""

from __future__ import annotations

CapabilityName = str
AdapterName = str

# Conservative seed; T2.E will harden each row with a live probe.
CAPABILITY_MATRIX: dict[tuple[AdapterName, CapabilityName], bool] = {
    # fork (vendored Concinno-King / Lyceum, MIT) ------------------------
    ("fork", "chat"): True,
    ("fork", "spawn_agent"): True,        # via fork.agent.loop_with_redblue
    ("fork", "post_tool_observe"): False, # CC L6 — fork inherits limit
    ("fork", "state_persist"): False,     # delegated to aiking_core later
    ("fork", "subagent_fork"): True,      # via fork.agent.redblue_dispatcher
    # hermes (externally installed `hermes_agent`) -----------------------
    ("hermes", "chat"): True,
    ("hermes", "spawn_agent"): True,
    ("hermes", "post_tool_observe"): False,
    ("hermes", "state_persist"): False,
    ("hermes", "subagent_fork"): True,
}


def capability_supported(adapter: str, capability: str) -> bool:
    """Return ``True`` iff ``adapter`` is known to support ``capability``.

    Unknown combinations return ``False`` (closed-world assumption).
    Callers needing a stricter signal (e.g. raising on unknown adapter)
    should look up the matrix directly.
    """
    return CAPABILITY_MATRIX.get((adapter.lower(), capability), False)


def adapter_capabilities(adapter: str) -> dict[str, bool]:
    """Return the full capability vector for ``adapter`` (lowercased).

    Capabilities not present in the matrix are reported as ``False`` so
    callers see a complete vector across the canonical capability set.
    """
    canonical = (
        "chat",
        "spawn_agent",
        "post_tool_observe",
        "state_persist",
        "subagent_fork",
    )
    name = adapter.lower()
    return {cap: CAPABILITY_MATRIX.get((name, cap), False) for cap in canonical}
