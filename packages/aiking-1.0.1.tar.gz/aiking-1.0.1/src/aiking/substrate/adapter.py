# SPDX-License-Identifier: Apache-2.0
"""SubstrateAdapter Protocol — uniform substrate surface for aiking.

This is the single seam aiking core uses to talk to whichever runtime
substrate is active (vendored fork / hermes / future). It extends the
minimal `LLMBackend` chat surface (copied from
``concinno.llm_runtime.base`` with attribution) with substrate-level
operations the cognitive layer cannot perform on its own:

    * ``spawn_agent`` — fork a sub-agent (CC L1 platform ceiling
      escapes).
    * ``post_tool_observe`` — observation-channel deny / rewrite of
      tool output (CC L6 physics constraint per GitHub
      anthropics/claude-code#32105).
    * ``state_persist`` — cross-session state store (CC has no native
      cross-session memory for tool-use traces).

Each method has a no-op / default fallback so partial adapters remain
usable; capability discovery happens through
``aiking.substrate.capabilities``.

License zoning: Apache 2.0. MUST NOT import `aiking_core` (AGPL) or
anything from ``aiking.substrate.fork`` (MIT) other than runtime
shims.
"""

from __future__ import annotations

from typing import Any, Protocol, TypedDict, runtime_checkable


class ChatMessage(TypedDict):
    """OpenAI-style chat message — copied from `concinno.llm_runtime.base`.

    Attribution: original definition lives at
    ``projects/concinno/src/concinno/llm_runtime/base.py:8-10``
    (Apache 2.0). Re-declared here to avoid an import-time dep from
    aiking → concinno during shadow migration.
    """

    role: str
    content: str


@runtime_checkable
class SubstrateAdapter(Protocol):
    """Structural protocol any aiking substrate must implement.

    Method semantics
    ----------------
    chat
        Original ``LLMBackend.chat`` contract — return assistant
        content (str) or empty string on transport error. Implementations
        MUST NOT raise for transport / provider errors; the empty-string
        sentinel drives caller-side retry.

    spawn_agent
        Fork a sub-agent that inherits the parent's tool surface.
        Returns an opaque handle the caller can use to read / cancel.
        Adapters lacking real fork support should raise
        ``NotImplementedError`` so capability discovery can mark it
        unsupported.

    post_tool_observe
        Inspect a tool result post hoc. Adapter may return a modified
        ``tool_output`` (e.g. with ``is_error=True`` rewrite to surface
        a Sancio-style observation-channel deny). Default: return
        ``tool_output`` unchanged. Adapters relying purely on the CC
        ``PostToolUse`` hook surface have NO physical deny capability
        per CC L6 constraint — they may only annotate.

    state_persist
        Persist a key→value pair to an adapter-managed cross-session
        store. ``ttl_seconds`` is best-effort. Default: no-op.
    """

    def chat(
        self,
        system: str,
        messages: list[ChatMessage],
        max_tokens: int = 2000,
        temperature: float = 0.3,
    ) -> str:
        """Return assistant content or empty string on failure."""
        ...

    def spawn_agent(
        self,
        prompt: str,
        *,
        tools: list[str] | None = None,
        model: str | None = None,
    ) -> Any:
        """Fork a sub-agent. Returns opaque handle / raises NotImplementedError."""
        ...

    def post_tool_observe(
        self,
        tool_name: str,
        tool_input: dict[str, Any],
        tool_output: Any,
    ) -> Any:
        """Post-tool observation channel; return possibly-rewritten output."""
        ...

    def state_persist(
        self,
        key: str,
        value: Any,
        *,
        ttl_seconds: int | None = None,
    ) -> None:
        """Persist key→value across sessions; best-effort TTL."""
        ...
