# SPDX-License-Identifier: Apache-2.0
"""HermesAdapter — substrate adapter that delegates to `hermes_agent`.

This is the b 路徑 (path B) substrate per the AI King single-distribution
plan: when the user installs the optional ``hermes_agent`` package, the
runtime can pivot from the vendored MIT `aiking.substrate.fork` to the
upstream Hermes Agent runtime without touching aiking core.

Three import-time checks are layered to give a sane failure mode at
each lifecycle stage:

1. Module-level lazy import inside ``HermesAdapter.__init__`` so just
   *loading* this file does not require ``hermes_agent`` to be present.
2. Class instantiation runs ``probe()`` once and stores the resolved
   module on ``self._hermes`` — a clear ImportError surfaces here.
3. ``probe()`` is also exposed publicly for capability discovery
   without instantiating the adapter.

This file is Apache 2.0 (new aiking shell code). It must NOT import
`aiking_core` (AGPL) or `aiking.substrate.fork` (MIT) at module top
level. Functional integration tests live in T2.E (next session).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from aiking.substrate.adapter import ChatMessage, SubstrateAdapter

if TYPE_CHECKING:  # pragma: no cover
    from types import ModuleType


def probe() -> bool:
    """Return True iff `hermes_agent` is importable in the current env."""
    try:
        import importlib

        importlib.import_module("hermes_agent")
        return True
    except ImportError:
        return False


class HermesAdapter(SubstrateAdapter):
    """Substrate adapter that proxies to an installed `hermes_agent`.

    Functional surface mirrors the canonical ``SubstrateAdapter`` Protocol.
    All operations are delegated to ``hermes_agent`` symbols that may not
    yet exist on every Hermes release; missing symbols raise
    ``NotImplementedError`` so the capabilities matrix can record the
    gap without taking down the whole adapter.
    """

    def __init__(self) -> None:
        try:
            import importlib

            self._hermes: ModuleType = importlib.import_module("hermes_agent")
        except ImportError as exc:  # pragma: no cover - environment-dependent
            raise ImportError(
                "HermesAdapter requires `hermes_agent` to be installed. "
                "Install via `pip install hermes-agent` or pick the "
                "vendored fork substrate via `get_substrate('fork')`."
            ) from exc

    # ------------------------------------------------------------------ chat
    def chat(
        self,
        system: str,
        messages: list[ChatMessage],
        max_tokens: int = 2000,
        temperature: float = 0.3,
    ) -> str:
        """Proxy to ``hermes_agent.chat`` if exposed; empty-string on error."""
        chat_fn = getattr(self._hermes, "chat", None)
        if chat_fn is None:
            return ""
        try:
            result = chat_fn(
                system=system,
                messages=messages,
                max_tokens=max_tokens,
                temperature=temperature,
            )
            return result if isinstance(result, str) else ""
        except Exception:  # noqa: BLE001 — empty-string sentinel by contract
            return ""

    # ----------------------------------------------------------- spawn_agent
    def spawn_agent(
        self,
        prompt: str,
        *,
        tools: list[str] | None = None,
        model: str | None = None,
    ) -> Any:
        """Delegate to ``hermes_agent.spawn_agent`` if exposed."""
        spawn = getattr(self._hermes, "spawn_agent", None)
        if spawn is None:
            raise NotImplementedError(
                "installed hermes_agent does not expose `spawn_agent`"
            )
        return spawn(prompt, tools=tools, model=model)

    # ---------------------------------------------------- post_tool_observe
    def post_tool_observe(
        self,
        tool_name: str,
        tool_input: dict[str, Any],
        tool_output: Any,
    ) -> Any:
        """Delegate to ``hermes_agent.post_tool_observe`` else passthrough."""
        observer = getattr(self._hermes, "post_tool_observe", None)
        if observer is None:
            return tool_output
        return observer(tool_name, tool_input, tool_output)

    # --------------------------------------------------------- state_persist
    def state_persist(
        self,
        key: str,
        value: Any,
        *,
        ttl_seconds: int | None = None,
    ) -> None:
        """Delegate to ``hermes_agent.state_persist``; silent no-op if missing."""
        persist = getattr(self._hermes, "state_persist", None)
        if persist is None:
            return
        persist(key, value, ttl_seconds=ttl_seconds)
