# SPDX-License-Identifier: Apache-2.0
"""ForkAdapter — substrate adapter that delegates to vendored fork tree.

Path-A substrate per the AI King single-distribution plan: uses the
vendored MIT `aiking.substrate.fork` (Lyceum / Concinno-King code)
as the runtime backend. No external pip dependency.

License zoning: Apache 2.0 (new aiking shell code). It MAY import from
``aiking.substrate.fork.*`` because the importer is the licensee
(direction allowed by Apache 2.0 + MIT). It MUST NOT import
``aiking_core`` (AGPL).

T2.E integration test will wire each method to the actual fork symbol;
this scaffold returns sensible defaults so capability discovery and
import smoke tests pass today.
"""

from __future__ import annotations

from typing import Any

from aiking.substrate.adapter import ChatMessage, SubstrateAdapter


class ForkAdapter(SubstrateAdapter):
    """Substrate adapter backed by vendored ``aiking.substrate.fork.*``.

    Methods are wired to fork symbols opportunistically; missing ones
    return safe defaults so downstream code can probe capabilities via
    ``aiking.substrate.capabilities``.
    """

    def __init__(self) -> None:
        # Lazy fork imports happen inside methods to keep load light.
        self._chat_fn = None

    # ------------------------------------------------------------------ chat
    def chat(
        self,
        system: str,
        messages: list[ChatMessage],
        max_tokens: int = 2000,
        temperature: float = 0.3,
    ) -> str:
        """Empty-string sentinel until T2.E wires fork's actual chat path."""
        return ""

    # ----------------------------------------------------------- spawn_agent
    def spawn_agent(
        self,
        prompt: str,
        *,
        tools: list[str] | None = None,
        model: str | None = None,
        llm_call: Any | None = None,
        backend: str | None = None,
        conv_id: str = "default",
    ) -> Any:
        """Spawn a fork agent loop with redblue+curator+emergence hooks.

        Wires :func:`aiking.substrate.fork.agent.loop_with_redblue.build_default_loop`
        + ``loop.run`` (T2.E). The fork loop's native contract takes a
        callable ``llm_call`` (Sancio-shape) — the shell ``spawn_agent``
        signature converts ``prompt`` to a single user message and runs
        the loop. ``tools`` is currently a name list; integrators
        wishing to pass full ``Tool`` objects should call
        :func:`build_default_loop` directly.

        :raises RuntimeError: if no ``llm_call`` is provided and no
            default backend can be resolved at runtime.
        """
        # Lazy import keeps adapter __init__ light.
        from aiking.substrate.fork.agent.loop_with_redblue import (
            build_default_loop,
        )

        if llm_call is None:
            raise RuntimeError(
                "ForkAdapter.spawn_agent requires an `llm_call` callable "
                "(or call build_default_loop directly with a backend)."
            )

        # tools list[str] -> empty Tool dict; full Tool objects
        # require build_default_loop direct call (documented).
        loop = build_default_loop(
            llm_call=llm_call,
            tools=None,
            backend=backend,
            conv_id=conv_id,
        )
        messages = [{"role": "user", "content": prompt}]
        return loop.run(messages, original_intent=prompt)

    # ---------------------------------------------------- post_tool_observe
    def post_tool_observe(
        self,
        tool_name: str,
        tool_input: dict[str, Any],
        tool_output: Any,
    ) -> Any:
        """Pass-through (CC L6 physics constraint — fork inherits limit)."""
        return tool_output

    # --------------------------------------------------------- state_persist
    def state_persist(
        self,
        key: str,
        value: Any,
        *,
        ttl_seconds: int | None = None,
    ) -> None:
        """No-op — aiking_core will own state; firewall blocks direct import."""
        return None
