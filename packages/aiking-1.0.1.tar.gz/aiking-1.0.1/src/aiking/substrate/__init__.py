# SPDX-License-Identifier: Apache-2.0
"""AI King substrate layer — pluggable agent runtime substrate.

Provides a uniform `SubstrateAdapter` Protocol that lets aiking choose
between (a) the vendored `fork/` substrate (Concinno-King / Lyceum, MIT)
and (b) an externally installed runtime such as `hermes_agent`.

License zoning:
    - This `__init__.py` and sibling `adapter.py` / `hermes.py` /
      `capabilities.py` are Apache 2.0 (new aiking shell code).
    - Subpackage `fork/` is MIT (Hermes-derived). MIT files MUST NOT
      import `aiking_core` (AGPL) — license firewall.

Public surface:
    get_substrate(name: str | None = None) -> SubstrateAdapter
        Factory that returns a configured adapter. Defaults to "fork"
        when no name is given. "hermes" lazily imports `hermes_agent`.
    SubstrateAdapter
        Structural Protocol any adapter must satisfy.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from aiking.substrate.adapter import SubstrateAdapter

if TYPE_CHECKING:
    pass

__all__ = ["SubstrateAdapter", "get_substrate"]


def get_substrate(name: str | None = None) -> SubstrateAdapter:
    """Return a configured `SubstrateAdapter`.

    Parameters
    ----------
    name:
        One of ``"fork"`` (default — vendored MIT Lyceum-derived
        substrate at `aiking.substrate.fork`) or ``"hermes"`` (lazy
        import of externally installed `hermes_agent`). Unknown names
        raise `ValueError`.
    """
    chosen = (name or "fork").lower()
    if chosen == "fork":
        # Lazy import to avoid pulling fork tree at module import time.
        from aiking.substrate.fork_adapter import ForkAdapter

        return ForkAdapter()
    if chosen == "hermes":
        from aiking.substrate.hermes import HermesAdapter

        return HermesAdapter()
    raise ValueError(
        f"unknown substrate {name!r}; expected 'fork' or 'hermes'"
    )
