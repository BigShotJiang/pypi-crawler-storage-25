# SPDX-License-Identifier: MIT
"""``concinno_king.evolution.gepa_skill`` — GEPA-driven skill rewriter.

This module **wires** Concinno's existing :mod:`concinno.evolution.gepa_adapter`
(MIT, GEPA upstream 0.1.x) into a per-Skill optimisation loop.  The
adapter alone is just a backbone — it knows how to run a Pareto search
over arbitrary text artefacts, but Concinno-King's curator needs three
specific surfaces:

1. ``optimize_skill_description`` — rewrite the SKILL.md description so
   future routing (``ziq_routing.skill_posterior``) hits more often.
2. ``optimize_skill_triggers`` — distil a trigger keyword set that
   discriminates true positives from a list of false-positive examples.
3. ``propose_consolidation_via_gepa`` — Hermes-style umbrella merge,
   but with the merge-prompt itself evolved by GEPA so consecutive
   curator passes converge instead of regenerating from scratch.

Persistent gradient state lives in :mod:`.gepa_state` so the optimiser
warm-starts from previous runs (FTRL-style on-line accumulation).

Wiring contract
---------------

``governance.curator.tick`` (the entry point A4 reserves) imports
:class:`SkillGEPAOptimizer` and calls
:meth:`SkillGEPAOptimizer.optimize_skill_description` on each merged
umbrella result.  Without that hook this module would be an island
(see ai-king MEMORY #4d).
"""

from __future__ import annotations

import logging
import re
from collections.abc import Callable, Iterable, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

# Re-use Concinno's adapter (the *one* place gepa is touched).
try:
    from concinno.evolution.gepa_adapter import (
        EvolutionExtraNotInstalled,
        GepaAdapter,
        is_available as gepa_is_available,
    )
except ImportError:  # pragma: no cover — concinno not on path during smoke

    class EvolutionExtraNotInstalled(ImportError):
        pass

    class GepaAdapter:  # type: ignore[no-redef]
        def __init__(self, **_: Any) -> None:
            raise EvolutionExtraNotInstalled("concinno not installed")

        def run(self, **_: Any) -> list[tuple[str, float]]:  # type: ignore[override]
            return []

    def gepa_is_available() -> bool:  # type: ignore[no-redef]
        return False


from .gepa_state import load_state, save_state

__all__ = [
    "ConsolidationProposal",
    "SkillGEPAOptimizer",
    "ToolCall",
]

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Light-weight value types — kept dataclass-only so callers can build
# them from arbitrary upstream telemetry without depending on Concinno's
# heavy ZIQ / handoff types.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ToolCall:
    """One observation row from the live tool-use stream."""

    skill_name: str
    matched: bool
    query: str = ""
    score: float = 0.0
    extras: dict[str, Any] = field(default_factory=dict)


@dataclass
class ConsolidationProposal:
    """Output of :meth:`propose_consolidation_via_gepa`."""

    umbrella_name: str
    merged_skills: list[str]
    new_description: str
    new_triggers: list[str]
    rationale: str
    score: float


# ---------------------------------------------------------------------------
# Utilities — rarely interesting on their own but explicit so a curator
# tick can be debugged without stepping into GEPA.
# ---------------------------------------------------------------------------


_TRIGGER_RE = re.compile(r"[A-Za-z一-鿿][A-Za-z一-鿿_-]{1,40}")


def _hit_rate(history: Iterable[ToolCall], skill_name: str) -> float:
    matched = total = 0
    for call in history:
        if call.skill_name != skill_name:
            continue
        total += 1
        if call.matched:
            matched += 1
    return matched / total if total else 0.0


def _extract_candidate_triggers(skill_md: str) -> list[str]:
    """Pull plausible trigger tokens out of an existing SKILL.md."""
    return list(dict.fromkeys(_TRIGGER_RE.findall(skill_md or "")))[:32]


# ---------------------------------------------------------------------------
# The optimiser itself.
# ---------------------------------------------------------------------------


class SkillGEPAOptimizer:
    """Wraps :class:`GepaAdapter` for Skill-level evolutionary rewrites.

    The optimiser is intentionally narrow: it never imports ``gepa``
    directly (that's the adapter's job), it never speaks LLM protocol
    (caller passes a ``reflection_llm`` callable), and it never writes
    SKILL.md back to disk (that's the curator's job).
    """

    def __init__(
        self,
        *,
        reflection_llm: Callable[[str], str],
        budget: int = 6,
        state_dir: Path | None = None,
    ) -> None:
        if not callable(reflection_llm):
            raise TypeError("reflection_llm must be callable")
        if not isinstance(budget, int) or budget <= 0:
            raise ValueError("budget must be a positive int")
        self._reflection_llm = reflection_llm
        self._budget = budget
        self._state_dir = state_dir

    # ------------------------------------------------------------------
    # Surface 1 — description rewriter
    # ------------------------------------------------------------------

    def optimize_skill_description(
        self,
        skill_md: str,
        usage_history: Sequence[ToolCall],
        *,
        skill_name: str | None = None,
    ) -> str:
        """Return an optimised description.  Falls back to ``skill_md``.

        The evaluator rewards candidate descriptions whose *implied*
        hit-rate (computed from queries that historically hit ``skill_name``)
        improves over the current baseline.  Because we cannot run real
        LLM reflection inside a unit test, the score function is
        deterministic and inspectable.
        """
        if not isinstance(skill_md, str) or not skill_md:
            raise ValueError("skill_md must be a non-empty string")
        name = skill_name or _infer_skill_name(skill_md)
        baseline = _hit_rate(usage_history, name)
        state = load_state(name, root=self._state_dir)

        def evaluate(candidate: str) -> float:
            # Toy but consistent: longer overlap with historical
            # *matched* queries → higher score; penalise raw length so
            # GEPA does not just grow the description forever.
            matched_terms = {
                tok
                for call in usage_history
                if call.matched and call.skill_name == name
                for tok in _TRIGGER_RE.findall(call.query or "")
            }
            cand_terms = set(_TRIGGER_RE.findall(candidate))
            overlap = len(matched_terms & cand_terms)
            length_penalty = max(0.0, (len(candidate) - 600) / 1000.0)
            return baseline + 0.05 * overlap - length_penalty

        adapter = GepaAdapter(
            seed_artefact=skill_md,
            reflection_llm=self._reflection_llm,
            budget=self._budget,
        )
        try:
            frontier = adapter.run(evaluate=evaluate)
        except EvolutionExtraNotInstalled:
            logger.info(
                "GEPA upstream missing; returning seed unchanged for %s",
                name,
            )
            return skill_md
        except (RuntimeError, AttributeError, TypeError) as exc:
            # Upstream gepa version mismatch / API drift — treat as
            # soft fallback so a curator pass does not crash a host.
            logger.info(
                "GEPA upstream incompatible (%s); seed-fallback for %s",
                exc,
                name,
            )
            frontier = [(skill_md, evaluate(skill_md))]
        if not frontier:
            return skill_md
        best_candidate, best_score = frontier[0]
        state.record(
            candidate_id=f"desc-{state.iterations + 1}",
            score=best_score,
            artefact=best_candidate,
        )
        save_state(state, root=self._state_dir)
        return best_candidate

    # ------------------------------------------------------------------
    # Surface 2 — trigger-set distiller
    # ------------------------------------------------------------------

    def optimize_skill_triggers(
        self,
        skill_md: str,
        false_positive_examples: Sequence[str],
        *,
        skill_name: str | None = None,
    ) -> list[str]:
        """Return a refined trigger keyword set.

        Each candidate trigger is scored by how many FP examples it
        *avoids* matching while still appearing in the source SKILL.md
        (so we never invent triggers out of thin air).
        """
        if not isinstance(skill_md, str) or not skill_md:
            raise ValueError("skill_md must be a non-empty string")
        name = skill_name or _infer_skill_name(skill_md)
        candidates = _extract_candidate_triggers(skill_md)
        kept: list[tuple[str, float]] = []
        for trigger in candidates:
            fp_hits = sum(
                1
                for fp in false_positive_examples
                if trigger and trigger.lower() in (fp or "").lower()
            )
            # Lower fp_hits = better; convert to positive score in [0,1].
            denom = max(1, len(false_positive_examples))
            score = 1.0 - (fp_hits / denom)
            kept.append((trigger, score))
        kept.sort(key=lambda x: x[1], reverse=True)
        top = [t for t, s in kept if s >= 0.5][:16]

        # Persist gradient — the curator can inspect & ZIQ FTRL can read.
        state = load_state(name, root=self._state_dir)
        state.ftrl_gradient["trigger_keyword_weights"] = {
            t: round(s, 4) for t, s in kept[:32]
        }
        state.record(
            candidate_id=f"triggers-{state.iterations + 1}",
            score=(sum(s for _, s in kept[: len(top)]) / max(1, len(top))),
            artefact=", ".join(top),
        )
        save_state(state, root=self._state_dir)
        return top

    # ------------------------------------------------------------------
    # Surface 3 — consolidation proposal (Hermes umbrella merge + GEPA)
    # ------------------------------------------------------------------

    def propose_consolidation_via_gepa(
        self,
        cluster: Sequence[dict[str, Any]],
        *,
        umbrella_name: str | None = None,
    ) -> ConsolidationProposal:
        """Evolve an umbrella description for ``cluster``.

        Each entry in ``cluster`` is a ``{"name": str, "description":
        str, "triggers": list[str]}`` dict — exactly the shape the
        curator already holds in memory after its initial scan.
        """
        if not cluster:
            raise ValueError("cluster must contain at least one skill")
        names = [entry.get("name", "") for entry in cluster]
        umbrella = umbrella_name or _pick_umbrella_name(names)
        seed = _seed_umbrella_description(cluster, umbrella)

        def evaluate(candidate: str) -> float:
            # Reward candidates that mention every cluster member at
            # least once (so no skill is silently dropped) and stay
            # within a sensible length envelope.
            mentioned = sum(
                1 for n in names if n and n.lower() in candidate.lower()
            )
            coverage = mentioned / max(1, len(names))
            envelope = 1.0 if 80 <= len(candidate) <= 600 else 0.5
            return coverage * envelope

        adapter = GepaAdapter(
            seed_artefact=seed,
            reflection_llm=self._reflection_llm,
            budget=self._budget,
        )
        try:
            frontier = adapter.run(evaluate=evaluate)
        except EvolutionExtraNotInstalled:
            frontier = [(seed, evaluate(seed))]
        except (RuntimeError, AttributeError, TypeError):
            frontier = [(seed, evaluate(seed))]
        best_candidate, best_score = (frontier or [(seed, 0.0)])[0]
        merged_triggers = sorted(
            {
                trig
                for entry in cluster
                for trig in (entry.get("triggers") or [])
            }
        )[:16]
        return ConsolidationProposal(
            umbrella_name=umbrella,
            merged_skills=list(names),
            new_description=best_candidate,
            new_triggers=merged_triggers,
            rationale=(
                f"GEPA-evolved umbrella over {len(names)} skills; "
                f"coverage*envelope={best_score:.2f}"
            ),
            score=float(best_score),
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _infer_skill_name(skill_md: str) -> str:
    for line in skill_md.splitlines():
        s = line.strip()
        if s.lower().startswith("name:"):
            return s.split(":", 1)[1].strip().strip("\"'")
        if s.startswith("# "):
            return s[2:].strip().split()[0] or "unnamed"
    return "unnamed"


def _pick_umbrella_name(names: Sequence[str]) -> str:
    real = [n for n in names if n]
    if not real:
        return "umbrella"
    # Shortest non-empty name is the most generic in practice.
    return sorted(real, key=len)[0]


def _seed_umbrella_description(
    cluster: Sequence[dict[str, Any]],
    umbrella: str,
) -> str:
    parts = [f"# {umbrella}", "", "Umbrella skill consolidating:"]
    for entry in cluster:
        name = entry.get("name", "?")
        desc = (entry.get("description") or "").strip().splitlines()
        first = desc[0] if desc else ""
        parts.append(f"- **{name}** — {first}")
    parts.append("")
    parts.append(
        "Use this skill when any of the listed sub-topics applies; the "
        "specific section for each is preserved as a support file under "
        "the umbrella's references/ directory."
    )
    return "\n".join(parts)
