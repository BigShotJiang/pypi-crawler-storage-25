# SPDX-License-Identifier: MIT
"""``concinno_king.evolution.gepa_state`` — persistent GEPA gradient state.

Each Skill that goes through GEPA optimisation accumulates a small
trail of reflection / score history.  We persist that trail under
``~/.concinno-king/gepa_state/<skill_name>.json`` so consecutive
``optimize_skill_*`` calls can warm-start from the previous Pareto
frontier instead of starting from a cold seed every time.

Schema (v1)::

    {
        "schema_version": 1,
        "skill_name": "kb_handoff",
        "updated_at": "2026-05-02T13:30:00Z",
        "iterations": 4,
        "best_score": 0.71,
        "best_artefact": "<optimised description text>",
        "history": [
            {
                "ts": "2026-05-02T13:00:00Z",
                "candidate_id": "v3",
                "score": 0.69,
                "artefact_preview": "first 200 chars …",
            },
            ...
        ],
        "ftrl_gradient": {
            "trigger_keyword_weights": {"handoff": 0.42, "交接": 0.41},
        },
    }

The file is intentionally JSON-flat (not pickle / not sqlite) so an
operator can ``cat`` it during incident response and a future GEPA
upstream change does not silently invalidate state.
"""

from __future__ import annotations

import json
import os
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

__all__ = [
    "GepaSkillState",
    "default_state_dir",
    "load_state",
    "save_state",
    "state_path",
]

_SCHEMA_VERSION = 1
_HISTORY_CAP = 50  # keep last N reflections; older trimmed FIFO
_PREVIEW_CHARS = 200
_SAFE_NAME_RE = re.compile(r"[^a-zA-Z0-9_.-]+")


def default_state_dir() -> Path:
    """Resolve the on-disk state root.

    Honours ``CONCINNO_KING_STATE_DIR`` for tests / sandboxed runs and
    falls back to ``~/.concinno-king/gepa_state``.  Never raises if the
    directory is missing — :func:`save_state` mkdirs lazily.
    """
    override = os.environ.get("CONCINNO_KING_STATE_DIR")
    if override:
        return Path(override).expanduser() / "gepa_state"
    return Path.home() / ".concinno-king" / "gepa_state"


def _safe_name(skill_name: str) -> str:
    """Sanitise a skill name into a filesystem-safe basename."""
    if not skill_name or not isinstance(skill_name, str):
        raise ValueError("skill_name must be a non-empty string")
    cleaned = _SAFE_NAME_RE.sub("_", skill_name).strip("_")
    if not cleaned:
        raise ValueError(f"skill_name {skill_name!r} sanitises to empty")
    return cleaned


def state_path(skill_name: str, *, root: Path | None = None) -> Path:
    """Resolve the JSON path for a given skill."""
    base = root or default_state_dir()
    return base / f"{_safe_name(skill_name)}.json"


@dataclass
class GepaSkillState:
    """In-memory shape of a per-skill GEPA gradient trail."""

    skill_name: str
    iterations: int = 0
    best_score: float = float("-inf")
    best_artefact: str = ""
    history: list[dict[str, Any]] = field(default_factory=list)
    ftrl_gradient: dict[str, Any] = field(default_factory=dict)
    updated_at: str = ""

    def record(
        self,
        *,
        candidate_id: str,
        score: float,
        artefact: str,
    ) -> None:
        """Append an entry, bump iterations, refresh ``best_*``."""
        if not isinstance(score, (int, float)):
            raise TypeError("score must be numeric")
        self.iterations += 1
        self.history.append(
            {
                "ts": _utc_now(),
                "candidate_id": str(candidate_id),
                "score": float(score),
                "artefact_preview": (artefact or "")[:_PREVIEW_CHARS],
            }
        )
        # FIFO trim — keep the recent tail.
        if len(self.history) > _HISTORY_CAP:
            self.history = self.history[-_HISTORY_CAP:]
        if float(score) > self.best_score:
            self.best_score = float(score)
            self.best_artefact = artefact
        self.updated_at = _utc_now()

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": _SCHEMA_VERSION,
            "skill_name": self.skill_name,
            "updated_at": self.updated_at or _utc_now(),
            "iterations": self.iterations,
            "best_score": (
                None if self.best_score == float("-inf") else self.best_score
            ),
            "best_artefact": self.best_artefact,
            "history": list(self.history),
            "ftrl_gradient": dict(self.ftrl_gradient),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> GepaSkillState:
        version = data.get("schema_version")
        if version not in (None, _SCHEMA_VERSION):
            raise ValueError(
                f"unsupported gepa_state schema_version={version!r}; "
                f"expected {_SCHEMA_VERSION}"
            )
        best = data.get("best_score")
        return cls(
            skill_name=str(data.get("skill_name") or ""),
            iterations=int(data.get("iterations", 0)),
            best_score=float("-inf") if best is None else float(best),
            best_artefact=str(data.get("best_artefact") or ""),
            history=list(data.get("history") or []),
            ftrl_gradient=dict(data.get("ftrl_gradient") or {}),
            updated_at=str(data.get("updated_at") or ""),
        )


def load_state(skill_name: str, *, root: Path | None = None) -> GepaSkillState:
    """Load state for a skill.  Returns a fresh empty state if absent."""
    path = state_path(skill_name, root=root)
    if not path.is_file():
        return GepaSkillState(skill_name=skill_name)
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        # Belt-and-suspenders: a corrupt file should not crash a curator
        # tick.  Surface via stderr (caller's logger picks it up) and
        # treat as cold start.
        import sys

        print(
            f"[gepa_state] corrupt file at {path}: {exc!r} — cold start",
            file=sys.stderr,
        )
        return GepaSkillState(skill_name=skill_name)
    return GepaSkillState.from_dict(raw)


def save_state(state: GepaSkillState, *, root: Path | None = None) -> Path:
    """Persist ``state`` atomically.  Returns the resolved path."""
    if not isinstance(state, GepaSkillState):
        raise TypeError("save_state requires a GepaSkillState instance")
    path = state_path(state.skill_name, root=root)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    payload = json.dumps(state.to_dict(), ensure_ascii=False, indent=2)
    tmp.write_text(payload, encoding="utf-8")
    os.replace(tmp, path)
    return path


def _utc_now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
