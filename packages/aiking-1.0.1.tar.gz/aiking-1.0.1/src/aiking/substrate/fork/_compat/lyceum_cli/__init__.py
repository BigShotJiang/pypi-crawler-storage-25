# SPDX-License-Identifier: MIT
"""Lyceum CLI compatibility shim — minimal surface for messaging imports.

The forked gateway modules import from ``lyceum_cli.{config,plugins,
runtime_provider,...}``. This package re-exposes a tiny subset that the
``messaging`` adapters touch at *import time* — runtime calls into
unimplemented surfaces will raise ``NotImplementedError`` so callers
fail loudly rather than silently degrading.
"""

__all__: list[str] = []
