# SPDX-License-Identifier: MIT
"""Compatibility shims for upstream Lyceum/Hermes modules.

The forked messaging adapters reach into Lyceum runtime helpers
(``lyceum_cli.config``, ``lyceum_constants``, ``utils``, ...). Until the
full Lyceum runtime is ported, these shims provide a minimal surface so
``concinno_king.messaging.*`` modules can be imported without pulling
the whole 7000-line agent runner into concinno-king.

Each shim is a stub by design: enough to satisfy ``import`` resolution
plus ``list_platforms()`` / ``concinno-king messaging list``. Full
runtime wiring lands in a later phase.
"""
