# SPDX-License-Identifier: MIT
"""concinno_king.skills.emergence_state — Persistent state for SkillEmergenceGuard.

@module skills.emergence_state
@responsibility Per-conversation persistent state for the 5-trigger
    SkillEmergenceGuard: tool fingerprint counters, failure chains,
    user-correction flags, time-decay tracking. Uses one JSON sidecar
    per conversation under ``~/.concinno-king/emergence_state/<conv_id>.json``
    so multiple parallel agent loops do not race on a single global file.
@exports EmergenceState, load_state, save_state, state_path

Why this is separate from emergence.py
--------------------------------------
The original 5.0.0 backup co-located state with the guard, which made
unit testing painful (every test had to monkeypatch ``_state_path``)
and silently leaked state between conversation IDs in an agent loop.
Splitting persistence out lets the guard stay pure and lets tests
construct an :class:`EmergenceState` in-memory without touching disk.
"""

from __future__ import annotations

import json
import os
import threading
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

__all__ = [
    "EmergenceState",
    "load_state",
    "save_state",
    "state_path",
    "state_root",
]


_STATE_LOCK = threading.RLock()
_RECENT_EVENT_CAP = 50
_EVENT_RING_CAP = 64


def state_root() -> Path:
    """Return the per-user state root.

    Override via env ``CONCINNO_KING_EMERGENCE_STATE_DIR`` for tests.
    Default ``~/.concinno-king/emergence_state``.
    """
    override = os.environ.get("CONCINNO_KING_EMERGENCE_STATE_DIR", "").strip()
    if override:
        return Path(override)
    return Path.home() / ".concinno-king" / "emergence_state"


def state_path(conv_id: str) -> Path:
    """Return the JSON sidecar path for a single conversation."""
    raw = conv_id or "default"
    safe = "".join(c for c in raw if c.isalnum() or c in "-_") or "default"
    return state_root() / f"{safe}.json"


@dataclass
class EmergenceState:
    """In-memory snapshot of one conversation's emergence-detector state.

    Attributes
    ----------
    conv_id:
        Conversation identifier. ``"default"`` if the caller has no
        better identifier — works fine for single-process testing.
    occurrence_counts:
        Map of ``"<tool>|<shape>"`` fingerprint to count for trigger T1.
    last_proposed_at:
        Map of fingerprint to UNIX seconds of last proposal — used by
        the cooldown check inside the guard.
    daily_count:
        Map of ``"YYYY-MM-DD"`` to draft-count-that-day (cap enforcement).
    recent_events:
        Ring buffer of the last ``_EVENT_RING_CAP`` events, each
        ``{ts, sig, ok, correction}`` — feeds T2 chain detection.
    drafts_index:
        Map of ``slug`` to dataclass-asdict of the SkillDraft. Survives
        process restart so ``concinno-king skills emergence list`` can
        show drafts queued in a previous turn.
    tool_calls_in_conversation:
        Cumulative tool-call count this conversation — feeds T4.
    successes_in_conversation:
        Cumulative successful tool-call count — feeds T4 "useful work
        is happening" gate.
    last_invoked_at:
        Map of skill-slug to UNIX seconds last call. Feeds T5.
    last_query_match_at:
        Map of skill-slug to UNIX seconds of most recent matched user
        query. Feeds T5 "30 day stale + recent matches" pattern.
    query_match_history:
        Map of skill-slug to list of recent match timestamps (capped).
    """

    conv_id: str = "default"
    occurrence_counts: dict[str, int] = field(default_factory=dict)
    last_proposed_at: dict[str, float] = field(default_factory=dict)
    daily_count: dict[str, int] = field(default_factory=dict)
    recent_events: list[dict[str, Any]] = field(default_factory=list)
    drafts_index: dict[str, dict[str, Any]] = field(default_factory=dict)
    tool_calls_in_conversation: int = 0
    successes_in_conversation: int = 0
    last_invoked_at: dict[str, float] = field(default_factory=dict)
    last_query_match_at: dict[str, float] = field(default_factory=dict)
    query_match_history: dict[str, list[float]] = field(default_factory=dict)

    def push_event(
        self,
        sig: str,
        ok: bool,
        correction: bool,
        ts: float | None = None,
    ) -> None:
        """Append an event to the ring buffer, trimming to cap."""
        self.recent_events.append({
            "ts": float(ts if ts is not None else time.time()),
            "sig": sig,
            "ok": bool(ok),
            "correction": bool(correction),
        })
        if len(self.recent_events) > _EVENT_RING_CAP:
            self.recent_events = self.recent_events[-_EVENT_RING_CAP:]

    def bump_count(self, sig: str) -> int:
        """Increment fingerprint counter, return new value."""
        self.occurrence_counts[sig] = self.occurrence_counts.get(sig, 0) + 1
        return self.occurrence_counts[sig]

    def record_query_match(self, slug: str, ts: float | None = None) -> None:
        """Record that a user query matched a skill's keywords (T5 input)."""
        now = float(ts if ts is not None else time.time())
        self.last_query_match_at[slug] = now
        history = self.query_match_history.setdefault(slug, [])
        history.append(now)
        # Cap per-slug history to last 32 matches
        if len(history) > 32:
            self.query_match_history[slug] = history[-32:]


def load_state(conv_id: str = "default") -> EmergenceState:
    """Load (or fresh-create) state for a conversation.

    Best-effort — returns a fresh state on any I/O or JSON error.
    """
    p = state_path(conv_id)
    if not p.exists():
        return EmergenceState(conv_id=conv_id)
    with _STATE_LOCK:
        try:
            raw = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return EmergenceState(conv_id=conv_id)
    if not isinstance(raw, dict):
        return EmergenceState(conv_id=conv_id)
    return EmergenceState(
        conv_id=conv_id,
        occurrence_counts=dict(raw.get("occurrence_counts") or {}),
        last_proposed_at=dict(raw.get("last_proposed_at") or {}),
        daily_count=dict(raw.get("daily_count") or {}),
        recent_events=list(raw.get("recent_events") or [])[-_EVENT_RING_CAP:],
        drafts_index=dict(raw.get("drafts_index") or {}),
        tool_calls_in_conversation=int(raw.get("tool_calls_in_conversation") or 0),
        successes_in_conversation=int(raw.get("successes_in_conversation") or 0),
        last_invoked_at=dict(raw.get("last_invoked_at") or {}),
        last_query_match_at=dict(raw.get("last_query_match_at") or {}),
        query_match_history={
            k: list(v) for k, v in (raw.get("query_match_history") or {}).items()
        },
    )


def save_state(state: EmergenceState) -> Path:
    """Persist state via atomic-replace tmp file. Returns the file path."""
    p = state_path(state.conv_id)
    p.parent.mkdir(parents=True, exist_ok=True)
    payload = asdict(state)
    payload["recent_events"] = state.recent_events[-_EVENT_RING_CAP:]
    with _STATE_LOCK:
        tmp = p.with_suffix(p.suffix + ".tmp")
        tmp.write_text(
            json.dumps(payload, indent=2, sort_keys=True),
            encoding="utf-8",
        )
        os.replace(tmp, p)
    return p
