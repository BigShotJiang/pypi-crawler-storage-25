# SPDX-License-Identifier: MIT
# ruff: noqa: N999
"""concinno_king.skills — Skill emergence + management.

Public exports per MEMORY #4d island check: every new module must wire
to ≥ 1 production caller. The canonical caller for emergence is
``concinno_king.agent.loop_with_redblue`` (B3 sub-agent's PostToolUse
chain) which resolves the entry point ``skills.emergence.observe`` via
``importlib`` at agent start-up.
"""

from __future__ import annotations

from .emergence import (
    EmergenceHook,
    EmergenceSignal,
    SkillDraft,
    accept_draft,
    draft_root,
    list_drafts,
    live_skill_root,
    observe,
    propose_draft,
    reject_draft,
)
from .emergence_state import (
    EmergenceState,
    load_state,
    save_state,
    state_path,
    state_root,
)

# N999 silenced: package directory is hyphenated by design (concinno-king
# matches PyPI/repo name); imports use the underscore form via path-based
# loading rather than `import concinno-king`.
__all__ = [
    "EmergenceHook",
    "EmergenceSignal",
    "EmergenceState",
    "SkillDraft",
    "accept_draft",
    "draft_root",
    "list_drafts",
    "live_skill_root",
    "load_state",
    "observe",
    "propose_draft",
    "reject_draft",
    "save_state",
    "state_path",
    "state_root",
]
