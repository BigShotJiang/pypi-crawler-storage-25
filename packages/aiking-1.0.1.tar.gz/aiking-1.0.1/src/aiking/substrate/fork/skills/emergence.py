# SPDX-License-Identifier: MIT
"""concinno_king.skills.emergence — 5-trigger Skill emergence detector.

@module skills.emergence
@responsibility Observe a stream of ``EmergenceSignal`` per tool call
    and emit ``SkillDraft`` proposals to disk under
    ``~/.concinno-king/skill_drafts/<slug>.md``. Never auto-installs into
    ``~/.claude/skills/`` — proposal is an action, install is a separate
    explicit ``concinno-king skills emergence accept <slug>`` command.
@dependencies skills.emergence_state, agent.loop_with_redblue (caller)
@exports EmergenceSignal, SkillDraft, EmergenceHook, observe, propose_draft

5 triggers
----------
Recovery + extension of the 5.0.0 default-on baseline (3 triggers in
backup ``20260501_092436_2d7d15``) with two new behaviours T4 and T5.

* **T1 tool_pattern_repeat** — same canonical fingerprint observed
  ``min_pattern_occurrences`` times within a conversation window.
  Canonical = ``(tool_name, command_head|file_extension)``.
* **T2 error_to_working** — ≥ 2 consecutive failures on the same
  fingerprint terminating in a success on the same fingerprint.
  Encodes the recovery itself as the candidate Skill.
* **T3 user_correction** — the most-recent user prompt carries a
  structural correction marker (set by an upstream prompt hook).
  Surrounding tool calls are the candidate workflow.
* **T4 token_threshold (NEW 5.0.0)** — when one conversation accrues
  ``≥ T4_TOOL_CALL_THRESHOLD`` tool calls AND the success rate is
  reasonable (``≥ 0.5``), propose a draft consolidating the most-used
  fingerprint into a Skill.
* **T5 time_decay (NEW 5.0.0)** — when an installed Skill has not
  been invoked for ``≥ T5_STALE_DAYS`` AND its keywords have been
  matched by recent user queries (``≥ T5_MIN_RECENT_MATCHES`` in the
  last ``T5_RECENT_DAYS`` days), propose **rewriting** the Skill's
  description / fold-in target. The actual rewrite is a stub —
  T5 emits a draft pointing at the candidate slug; an LLM-rewrite
  step happens out of band.

Caps
----
* ``max_auto_skills_per_day`` hard ceiling (default 5)
* ``min_pattern_occurrences`` floor for T1 (default 3)
* ``cooldown_hours`` per fingerprint (default 2.0)
* ``draft_retention_days`` (default 30)
* ``T4_TOOL_CALL_THRESHOLD`` (default 10)
* ``T5_STALE_DAYS`` (default 30)
* ``T5_RECENT_DAYS`` window for "frequent recent queries" (default 7)
* ``T5_MIN_RECENT_MATCHES`` minimum match count (default 3)

Wiring (MEMORY #4d island check)
--------------------------------
The agent loop ``concinno_king.agent.loop_with_redblue`` is expected to
call :func:`observe` (or instantiate :class:`EmergenceHook` and call
its ``observe`` method) once per PostToolUse event. The hook entry
point name is ``skills.emergence.observe`` — exported in
``concinno_king.skills.__init__`` so a B3 sub-agent can resolve it via
``importlib.import_module`` without a hard dependency on this module's
internals.
"""

from __future__ import annotations

import contextlib
import os
import threading
import time
import uuid
from collections.abc import Callable
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .emergence_state import EmergenceState, load_state, save_state

__all__ = [
    "EmergenceHook",
    "EmergenceSignal",
    "SkillDraft",
    "accept_draft",
    "draft_root",
    "list_drafts",
    "live_skill_root",
    "observe",
    "propose_draft",
    "reject_draft",
]


# ── Defaults ──────────────────────────────────────────────

_DEFAULT_MAX_PER_DAY = 5
_DEFAULT_MIN_OCCURRENCES = 3
_DEFAULT_COOLDOWN_HOURS = 2.0
_DEFAULT_RETENTION_DAYS = 30

_HARD_CEILING_PER_DAY = 20
_FAIL_CHAIN_WINDOW = 8

# T4 — token / tool-call threshold
T4_TOOL_CALL_THRESHOLD = 10
T4_MIN_SUCCESS_RATE = 0.5

# T5 — time-decay rewrite
T5_STALE_DAYS = 30
T5_RECENT_DAYS = 7
T5_MIN_RECENT_MATCHES = 3

_OBSERVATIONAL_ONLY_TOOLS = frozenset({
    "Read", "Glob", "TodoWrite", "WebSearch",
})


# ── Data types ────────────────────────────────────────────


@dataclass(frozen=True)
class EmergenceSignal:
    """One observation fed to the detector.

    Attributes
    ----------
    tool_name:
        Name of the tool that just ran (``"Bash"`` / ``"Edit"`` / …).
    canonical_shape:
        Fingerprint after argument stripping. For ``Bash`` this is
        ``"<head>"`` (e.g. ``"ruff check"``); for ``Edit/Write`` it is
        the file extension (``".py"``).
    success:
        Whether the call succeeded. Drives T2.
    timestamp:
        Unix seconds. Defaults to ``time.time()``.
    had_user_correction:
        Whether the user prompt that opened this turn carried a
        correction marker (set by upstream prompt hook). T3 input.
    skill_slug_invoked:
        If this tool call was triggered by a Skill, the slug of that
        Skill. Updates T5 freshness — invoked Skills don't decay.
    user_query_text:
        Optional raw user prompt for the current turn. T5 cross-check
        feature: if a query lexically matches a stale Skill's keywords
        we record it, regardless of whether the Skill actually fired.
    """

    tool_name: str
    canonical_shape: str
    success: bool = True
    timestamp: float = field(default_factory=time.time)
    had_user_correction: bool = False
    skill_slug_invoked: str | None = None
    user_query_text: str | None = None


@dataclass
class SkillDraft:
    """A proposed Skill awaiting user acceptance."""

    slug: str
    name: str
    description: str
    trigger_keywords: list[str]
    pattern_signature: str
    proposed_at: float
    # One of: tool_pattern_repeat, error_to_working, user_correction,
    # token_threshold, time_decay
    trigger_kind: str
    occurrences: int
    sample_canonical_shapes: list[str]
    rewrite_target_slug: str | None = None  # set for T5

    def to_markdown(self) -> str:
        triggers = ", ".join(self.trigger_keywords) if self.trigger_keywords else ""
        proposed_iso = datetime.fromtimestamp(
            self.proposed_at, tz=timezone.utc,
        ).isoformat()
        rewrite_note = ""
        if self.rewrite_target_slug:
            rewrite_note = (
                f"\n**Rewrite target:** `{self.rewrite_target_slug}` "
                f"(stale ≥{T5_STALE_DAYS}d, recent query matches detected)\n"
                "_This draft proposes refactoring the existing Skill's "
                "description / fold-in. LLM rewrite happens at acceptance "
                "time — the draft itself only stores the rewrite-target slug._\n"
            )
        body = (
            "---\n"
            f"name: {self.name}\n"
            f"description: {self.description}\n"
            f"triggers: [{triggers}]\n"
            "---\n\n"
            f"# {self.name}\n\n"
            f"_Auto-proposed by concinno_king at {proposed_iso}._\n\n"
            f"**Trigger kind:** `{self.trigger_kind}`\n\n"
            f"**Pattern signature:** `{self.pattern_signature}`\n\n"
            f"**Observed occurrences:** {self.occurrences}\n"
            f"{rewrite_note}\n"
            "## Observed shapes\n\n"
        )
        for shape in self.sample_canonical_shapes:
            body += f"- `{shape}`\n"
        body += (
            "\n## Suggested workflow\n\n"
            "_Edit this section to describe the workflow this Skill should "
            "encode before accepting._\n\n"
            "## Acceptance\n\n"
            f"- Run `concinno-king skills emergence accept {self.slug}` to "
            f"install at `~/.claude/skills/{self.slug}/SKILL.md`.\n"
            f"- Run `concinno-king skills emergence reject {self.slug}` to "
            "discard the draft.\n"
            f"- `concinno-king skills emergence list` shows pending drafts.\n"
        )
        return body


# ── Path helpers ──────────────────────────────────────────


def draft_root() -> Path:
    override = os.environ.get("CONCINNO_KING_SKILL_DRAFT_DIR", "").strip()
    if override:
        return Path(override)
    return Path.home() / ".concinno-king" / "skill_drafts"


def live_skill_root() -> Path:
    override = os.environ.get("CONCINNO_KING_LIVE_SKILL_ROOT", "").strip()
    if override:
        return Path(override)
    return Path.home() / ".claude" / "skills"


# ── Slug helpers ──────────────────────────────────────────

_SAFE_SLUG_CHARS = "abcdefghijklmnopqrstuvwxyz0123456789-_"


def _slugify(text: str, *, max_len: int = 40) -> str:
    norm = (text or "").lower().strip()
    out: list[str] = []
    for ch in norm:
        if ch in _SAFE_SLUG_CHARS:
            out.append(ch)
        elif ch in " /\\.:,;|()[]{}<>'\"`":
            out.append("-")
    cleaned = "".join(out).strip("-_")
    while "--" in cleaned:
        cleaned = cleaned.replace("--", "-")
    if not cleaned:
        cleaned = "skill"
    return cleaned[:max_len].rstrip("-_")


def _compose_name_and_description(
    *, kind: str, signature: str, occurrences: int, shapes: list[str],
    rewrite_target: str | None = None,
) -> tuple[str, str, list[str]]:
    head = signature.split("|", 1)[0].strip() or "workflow"
    _ = shapes
    if kind == "error_to_working":
        name = f"recover-{head}"
        description = (
            f"Auto-proposed recovery workflow for repeated failure→success on "
            f"`{head}` (observed {occurrences}x this conversation)."
        )
        triggers = [head, "recover", "fix", "error"]
    elif kind == "user_correction":
        name = f"correct-{head}"
        description = (
            f"Auto-proposed correction workflow following user feedback on "
            f"`{head}` patterns."
        )
        triggers = [head, "correct", "redo"]
    elif kind == "token_threshold":
        name = f"consolidate-{head}"
        description = (
            f"Auto-proposed consolidation Skill for high-volume `{head}` "
            f"workflow (≥{T4_TOOL_CALL_THRESHOLD} tool calls this "
            "conversation, success rate above threshold)."
        )
        triggers = [head, "consolidate", "workflow"]
    elif kind == "time_decay":
        target = rewrite_target or head
        name = f"refresh-{target}"
        description = (
            f"Auto-proposed rewrite of stale Skill `{target}` "
            f"(idle ≥{T5_STALE_DAYS}d, recent query matches detected)."
        )
        triggers = [target, "refresh", "rewrite"]
    else:  # tool_pattern_repeat
        name = f"workflow-{head}"
        description = (
            f"Auto-proposed workflow for repeated `{head}` calls "
            f"(observed {occurrences}x this conversation)."
        )
        triggers = [head, "workflow", "repeat"]

    seen: set[str] = set()
    final: list[str] = []
    for t in triggers:
        t = t.strip()
        if t and t not in seen:
            seen.add(t)
            final.append(t)
    return name, description, final[:6]


# ── Public propose helper ─────────────────────────────────


def propose_draft(draft: SkillDraft, *, conv_id: str = "default") -> Path:
    """Write a draft to disk + index it. Returns the markdown path."""
    root = draft_root()
    root.mkdir(parents=True, exist_ok=True)
    md = root / f"{draft.slug}.md"
    md.write_text(draft.to_markdown(), encoding="utf-8")
    state = load_state(conv_id)
    state.drafts_index[draft.slug] = asdict(draft)
    save_state(state)
    return md


def list_drafts(*, conv_id: str = "default") -> list[dict[str, Any]]:
    """Return the current drafts_index for CLI listing."""
    state = load_state(conv_id)
    return [
        {"slug": slug, **payload}
        for slug, payload in sorted(state.drafts_index.items())
    ]


def accept_draft(slug: str, *, conv_id: str = "default") -> bool:
    """Move a draft into the live skill root. Returns True on success.

    Real install does not happen here in this 5-trigger build — we only
    move the draft markdown into a per-slug directory; downstream LLM
    rewrite of the body (especially for T5) is out of band.
    """
    state = load_state(conv_id)
    if slug not in state.drafts_index:
        return False
    src = draft_root() / f"{slug}.md"
    if not src.exists():
        return False
    dest_dir = live_skill_root() / slug
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / "SKILL.md"
    dest.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
    state.drafts_index[slug]["resolution"] = "accepted"
    state.drafts_index[slug]["resolved_at"] = time.time()
    save_state(state)
    return True


def reject_draft(slug: str, *, conv_id: str = "default") -> bool:
    state = load_state(conv_id)
    if slug not in state.drafts_index:
        return False
    src = draft_root() / f"{slug}.md"
    try:
        if src.exists():
            src.unlink()
    except OSError:
        pass
    state.drafts_index[slug]["resolution"] = "rejected"
    state.drafts_index[slug]["resolved_at"] = time.time()
    save_state(state)
    return True


# ── EmergenceHook ─────────────────────────────────────────


class EmergenceHook:
    """Stateful hook that observes signals + emits drafts.

    The agent loop instantiates one of these per conversation. Per
    MEMORY #4d every new module must wire to ≥ 1 production caller —
    the canonical caller is ``concinno_king.agent.loop_with_redblue``
    via the ``PostToolUse`` chain. This class is the entry point
    exported as ``skills.emergence.observe`` (the module-level
    function below) — instances retain conversation-scoped state across
    calls.

    Threading: a single RLock guards observe(); the underlying
    ``emergence_state`` module also locks at the file layer, so two
    concurrent observe() calls on the same conv_id will not corrupt
    state — the later writer wins on the JSON file but the in-memory
    instance state stays consistent.
    """

    name = "skill_emergence_hook"

    def __init__(
        self,
        *,
        conv_id: str = "default",
        max_auto_skills_per_day: int | None = None,
        min_pattern_occurrences: int | None = None,
        cooldown_hours: float | None = None,
        draft_retention_days: int | None = None,
        stderr_emit: Callable[[str], None] | None = None,
        enabled: bool = True,
    ) -> None:
        self._lock = threading.RLock()
        self._conv_id = conv_id
        self._max_per_day = (
            min(int(max_auto_skills_per_day), _HARD_CEILING_PER_DAY)
            if max_auto_skills_per_day is not None
            else _DEFAULT_MAX_PER_DAY
        )
        self._min_occurrences = max(1, int(
            min_pattern_occurrences if min_pattern_occurrences is not None
            else _DEFAULT_MIN_OCCURRENCES
        ))
        self._cooldown_s = max(0.0, float(
            cooldown_hours if cooldown_hours is not None
            else _DEFAULT_COOLDOWN_HOURS
        )) * 3600.0
        self._retention_s = max(0.0, float(
            draft_retention_days if draft_retention_days is not None
            else _DEFAULT_RETENTION_DAYS
        )) * 86400.0
        self._stderr_emit = stderr_emit
        self._enabled = enabled

    # ── Top-level observe ───────────────────────────────

    def observe(self, signal: EmergenceSignal) -> SkillDraft | None:
        """Record one observation. Return a draft if one was just proposed."""
        if not self._enabled:
            return None
        if signal.tool_name in _OBSERVATIONAL_ONLY_TOOLS:
            return None
        with self._lock:
            try:
                state = load_state(self._conv_id)
                if self._prune_old_drafts(state):
                    save_state(state)
                signature = self._fingerprint(signal)
                state.tool_calls_in_conversation += 1
                if signal.success:
                    state.successes_in_conversation += 1
                state.push_event(
                    signature,
                    signal.success,
                    signal.had_user_correction,
                    signal.timestamp,
                )
                state.bump_count(signature)

                # T5 freshness updates
                if signal.skill_slug_invoked:
                    state.last_invoked_at[signal.skill_slug_invoked] = signal.timestamp
                if signal.user_query_text:
                    self._record_query_matches(
                        state,
                        signal.user_query_text,
                        signal.timestamp,
                    )

                draft = self._evaluate_triggers(state, signal, signature)
                save_state(state)
                return draft
            except Exception:
                return None

    # ── Trigger pipeline ────────────────────────────────

    def _evaluate_triggers(
        self,
        state: EmergenceState,
        signal: EmergenceSignal,
        signature: str,
    ) -> SkillDraft | None:
        if self._daily_cap_reached(state):
            return None

        # T5 first — operates on a different state field (skill staleness)
        # so cooldown_active(signature) does not block it.
        t5 = self._check_time_decay(state, signal.timestamp)
        if t5 is not None:
            return t5

        if self._cooldown_active(state, signature):
            return None

        # T1 tool_pattern_repeat
        if state.occurrence_counts.get(signature, 0) >= self._min_occurrences:
            return self._fire_draft(
                state, signature,
                kind="tool_pattern_repeat",
                shapes=self._sample_shapes(state, signature),
            )

        # T2 error_to_working
        if signal.success and self._has_recent_failure_chain(state, signature):
            return self._fire_draft(
                state, signature,
                kind="error_to_working",
                shapes=self._sample_shapes(state, signature),
            )

        # T3 user_correction
        if signal.had_user_correction:
            return self._fire_draft(
                state, signature,
                kind="user_correction",
                shapes=self._sample_shapes(state, signature),
            )

        # T4 token_threshold
        if state.tool_calls_in_conversation >= T4_TOOL_CALL_THRESHOLD:
            success_rate = (
                state.successes_in_conversation / state.tool_calls_in_conversation
                if state.tool_calls_in_conversation > 0 else 0.0
            )
            if success_rate >= T4_MIN_SUCCESS_RATE:
                # Pick the most-frequent fingerprint as the consolidation candidate
                top_sig = self._top_fingerprint(state)
                if top_sig:
                    return self._fire_draft(
                        state, top_sig,
                        kind="token_threshold",
                        shapes=self._sample_shapes(state, top_sig),
                    )

        return None

    def _check_time_decay(
        self, state: EmergenceState, now: float,
    ) -> SkillDraft | None:
        """T5 — propose rewrite for stale Skill with recent query matches."""
        stale_cutoff = now - T5_STALE_DAYS * 86400.0
        recent_cutoff = now - T5_RECENT_DAYS * 86400.0
        for slug, history in state.query_match_history.items():
            last_invoked = state.last_invoked_at.get(slug, 0.0)
            if last_invoked >= stale_cutoff:
                continue  # not stale
            recent_matches = [t for t in history if t >= recent_cutoff]
            if len(recent_matches) < T5_MIN_RECENT_MATCHES:
                continue
            sig = f"skill|{slug}"
            if self._cooldown_active(state, sig):
                continue
            return self._fire_draft(
                state, sig,
                kind="time_decay",
                shapes=[sig],
                rewrite_target=slug,
            )
        return None

    # ── Helpers ─────────────────────────────────────────

    def _fingerprint(self, signal: EmergenceSignal) -> str:
        shape = (signal.canonical_shape or "").strip()
        return f"{signal.tool_name}|{shape}"

    def _has_recent_failure_chain(
        self, state: EmergenceState, signature: str,
    ) -> bool:
        recent = [
            e for e in state.recent_events[-_FAIL_CHAIN_WINDOW:]
            if e.get("sig") == signature
        ]
        if len(recent) < 3:
            return False
        prior = recent[:-1]
        fail_streak = 0
        for ev in reversed(prior):
            if not ev.get("ok"):
                fail_streak += 1
            else:
                break
        return fail_streak >= 2

    def _sample_shapes(
        self, state: EmergenceState, signature: str, *, n: int = 5,
    ) -> list[str]:
        seen: list[str] = []
        for ev in state.recent_events:
            if ev.get("sig") != signature:
                continue
            shape = ev.get("sig", "")
            if shape and shape not in seen:
                seen.append(shape)
            if len(seen) >= n:
                break
        return seen or [signature]

    def _top_fingerprint(self, state: EmergenceState) -> str | None:
        if not state.occurrence_counts:
            return None
        return max(state.occurrence_counts.items(), key=lambda kv: kv[1])[0]

    def _record_query_matches(
        self, state: EmergenceState, query: str, ts: float,
    ) -> None:
        """Update T5 query_match_history for any installed Skill whose
        slug appears in the user query (cheap substring check).
        """
        q = (query or "").lower()
        if not q:
            return
        # We use drafts_index slugs as the universe of "installed-ish"
        # Skills here. The agent loop is expected to also feed in the
        # real ~/.claude/skills/ slugs via observe()'s skill_slug_invoked.
        slugs = set(state.drafts_index.keys()) | set(state.last_invoked_at.keys())
        for slug in slugs:
            if slug in q:
                state.record_query_match(slug, ts)

    def _cooldown_active(self, state: EmergenceState, signature: str) -> bool:
        last = state.last_proposed_at.get(signature)
        if last is None:
            return False
        return (time.time() - float(last)) < self._cooldown_s

    def _daily_cap_reached(self, state: EmergenceState) -> bool:
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        return state.daily_count.get(today, 0) >= self._max_per_day

    def _fire_draft(
        self,
        state: EmergenceState,
        signature: str,
        *,
        kind: str,
        shapes: list[str],
        rewrite_target: str | None = None,
    ) -> SkillDraft | None:
        occurrences = state.occurrence_counts.get(signature, 1)
        name, description, triggers = _compose_name_and_description(
            kind=kind,
            signature=signature,
            occurrences=occurrences,
            shapes=shapes,
            rewrite_target=rewrite_target,
        )
        slug = self._unique_slug(state, name)
        draft = SkillDraft(
            slug=slug,
            name=name,
            description=description,
            trigger_keywords=triggers,
            pattern_signature=signature,
            proposed_at=time.time(),
            trigger_kind=kind,
            occurrences=int(occurrences),
            sample_canonical_shapes=list(shapes),
            rewrite_target_slug=rewrite_target,
        )
        try:
            md_path = propose_draft(draft, conv_id=self._conv_id)
        except OSError:
            return None
        # propose_draft modifies disk state; reconcile + bump counters
        fresh = load_state(self._conv_id)
        fresh.last_proposed_at[signature] = draft.proposed_at
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        fresh.daily_count[today] = fresh.daily_count.get(today, 0) + 1
        fresh.occurrence_counts.update(state.occurrence_counts)
        fresh.tool_calls_in_conversation = state.tool_calls_in_conversation
        fresh.successes_in_conversation = state.successes_in_conversation
        fresh.recent_events = state.recent_events
        save_state(fresh)
        # Mirror back so caller's outer save does not clobber
        state.last_proposed_at[signature] = draft.proposed_at
        state.daily_count[today] = fresh.daily_count[today]
        state.drafts_index = fresh.drafts_index
        self._announce(draft, md_path)
        return draft

    def _unique_slug(self, state: EmergenceState, name: str) -> str:
        base = _slugify(name)
        if base not in state.drafts_index:
            return base
        return f"{base}-{uuid.uuid4().hex[:6]}"

    def _announce(self, draft: SkillDraft, md_path: Path) -> None:
        if self._stderr_emit is None:
            return
        msg = (
            f"concinno-king: SkillEmergenceHook proposed draft '{draft.name}' "
            f"({draft.trigger_kind}) at {md_path}. Run "
            f"`concinno-king skills emergence accept {draft.slug}` to install."
        )
        with contextlib.suppress(Exception):
            self._stderr_emit(msg)

    def _prune_old_drafts(self, state: EmergenceState) -> bool:
        if self._retention_s <= 0:
            return False
        cutoff = time.time() - self._retention_s
        drop = [
            slug for slug, payload in state.drafts_index.items()
            if float(payload.get("proposed_at") or 0.0) < cutoff
        ]
        for slug in drop:
            md = draft_root() / f"{slug}.md"
            try:
                if md.exists():
                    md.unlink()
            except OSError:
                pass
            state.drafts_index.pop(slug, None)
        return bool(drop)


# ── Module-level observe (B3 entry point) ─────────────────

# Process-local default hook used by the module-level ``observe`` shim.
# B3 sub-agent's agent.loop_with_redblue can either call observe()
# directly or instantiate its own EmergenceHook for a custom conv_id.
_DEFAULT_HOOK: EmergenceHook | None = None
_DEFAULT_HOOK_LOCK = threading.Lock()


def observe(
    signal: EmergenceSignal,
    *,
    conv_id: str = "default",
) -> SkillDraft | None:
    """Module-level observe — entry point for ``skills.emergence.observe``.

    Maintains a process-local hook keyed by conv_id behind the scenes
    so callers don't need to track their own EmergenceHook instances.
    """
    global _DEFAULT_HOOK
    with _DEFAULT_HOOK_LOCK:
        if _DEFAULT_HOOK is None or _DEFAULT_HOOK._conv_id != conv_id:
            _DEFAULT_HOOK = EmergenceHook(conv_id=conv_id)
    return _DEFAULT_HOOK.observe(signal)
