# SPDX-License-Identifier: MIT
"""Provider registry — dynamic dispatch by model prefix or explicit name.

This is the **hub** that wires the merged Lyceum + Sancio provider
fleet into a single dispatch surface. Two kinds of entries live here:

1. **Lyceum-derived** logical providers (MIT). Lyceum runs ~18+
   first-class providers but most share the OpenAI ``chat_completions``
   transport — what differs is base_url, env key, and tiny per-vendor
   request quirks. We surface each as its own logical provider in
   the registry so ``concinno-king providers list`` shows the full
   fleet, while the underlying adapter dispatch reuses the same
   transport file.

2. **Sancio-derived** adapters (AGPL). Sancio ships 6 first-class
   adapters as full classes; they remain accessible by their canonical
   sancio name (``anthropic``, ``openai``, ``ollama``, ``groq``,
   ``local_inproc``) plus dual-listed under ``sancio_<name>`` to make
   the dual-source split explicit when users want determinism.

The registry is **not** wired to the Lyceum source files at runtime
yet — Lyceum adapters are 900-1900 line single files that import
``from agent.X`` siblings (auxiliary_client, prompt_builder, etc.)
that we did not bring across. This first-cut registry surfaces the
**catalogue** (so callers can discover what is available), and falls
back to sancio adapters for actual dispatch when a real LLM call is
made. Future waves will harvest the Lyceum adapter logic into
Concinno-King-native classes; the registry surface here will not
change shape when that happens — only the resolved adapter class
will.

Routing
-------

``registry.resolve(model)`` returns the best-matching ``ProviderInfo``
by longest-prefix match against ``ProviderInfo.model_prefixes``.
Explicit ``provider:model`` strings (e.g. ``openrouter:meta-llama/...``)
short-circuit the prefix search.

``registry.available()`` returns only providers whose env keys are
populated AND whose backing adapter package imports without error.
Useful for ``concinno-king providers list --available``.
"""

from __future__ import annotations

import importlib
import os
from typing import Any

from .base import ProviderError, ProviderInfo

# ---------------------------------------------------------------------------
# Lyceum-derived logical providers (MIT — Hermes Agent fork lineage)
# ---------------------------------------------------------------------------
# Each entry maps a logical provider name to:
#   - source: "lyceum-mit" so NOTICE / license tooling can discriminate
#   - model_prefixes: tuple of substrings that route to this provider
#   - env_keys: API key env vars; first present one wins
#   - module_path: dotted path to the backing adapter / transport
#   - description: short human-readable summary for ``providers list``
#
# Counts mirror Lyceum's _PROVIDER_PREFIXES set in
# agent/model_metadata.py (currently ~30 names; many alias the same
# vendor — we collapse aliases here to one logical entry per vendor).

_LYCEUM_PROVIDERS: tuple[ProviderInfo, ...] = (
    ProviderInfo(
        name="anthropic",
        source="lyceum-mit",
        model_prefixes=("claude-",),
        env_keys=("ANTHROPIC_API_KEY",),
        module_path="concinno_king.providers.lyceum_anthropic",
        description="Anthropic Messages API (Lyceum native adapter, prompt caching)",
    ),
    ProviderInfo(
        name="bedrock",
        source="lyceum-mit",
        model_prefixes=("anthropic.claude-", "us.anthropic.", "eu.anthropic."),
        env_keys=("AWS_ACCESS_KEY_ID", "AWS_PROFILE"),
        module_path="concinno_king.providers.lyceum_bedrock",
        description="AWS Bedrock (Anthropic via SigV4)",
    ),
    ProviderInfo(
        name="codex",
        source="lyceum-mit",
        model_prefixes=("gpt-5", "o3", "o4-mini", "openai-codex:"),
        env_keys=("OPENAI_API_KEY", "CODEX_API_KEY"),
        module_path="concinno_king.providers.lyceum_codex",
        description="OpenAI Responses API (Codex / GPT-5 / o-series)",
    ),
    ProviderInfo(
        name="gemini",
        source="lyceum-mit",
        model_prefixes=("gemini-", "gemma-"),
        env_keys=("GEMINI_API_KEY", "GOOGLE_API_KEY"),
        module_path="concinno_king.providers.lyceum_gemini_native",
        description="Google Gemini AI Studio (native Generative Language API)",
    ),
    ProviderInfo(
        name="google",
        source="lyceum-mit",
        model_prefixes=("google/", "google-"),
        env_keys=("GOOGLE_OAUTH_CREDENTIALS", "CODE_ASSIST_TOKEN"),
        module_path="concinno_king.providers.lyceum_gemini_cloudcode",
        description="Google Code Assist (Gemini via OAuth)",
    ),
    ProviderInfo(
        name="lmstudio",
        source="lyceum-mit",
        model_prefixes=("lmstudio:",),
        env_keys=(),  # local, no key
        module_path="concinno_king.providers.lyceum_transport_chat_completions",
        description="LM Studio local server (OpenAI-compat)",
    ),
    ProviderInfo(
        name="nous",
        source="lyceum-mit",
        model_prefixes=("nous:", "nous/"),
        env_keys=("NOUS_API_KEY",),
        module_path="concinno_king.providers.lyceum_transport_chat_completions",
        description="Nous Portal (Hermes 4 / DeepHermes / Forge)",
    ),
    ProviderInfo(
        name="openrouter",
        source="lyceum-mit",
        model_prefixes=("openrouter:", "openrouter/"),
        env_keys=("OPENROUTER_API_KEY",),
        module_path="concinno_king.providers.lyceum_transport_chat_completions",
        description="OpenRouter unified gateway (200+ models)",
    ),
    ProviderInfo(
        name="nvidia",
        source="lyceum-mit",
        model_prefixes=("nvidia/", "nim:", "nemotron-"),
        env_keys=("NVIDIA_API_KEY", "NIM_API_KEY"),
        module_path="concinno_king.providers.lyceum_transport_chat_completions",
        description="NVIDIA NIM (Nemotron / Llama-Nemotron)",
    ),
    ProviderInfo(
        name="xiaomi",
        source="lyceum-mit",
        model_prefixes=("xiaomi:", "mimo-", "xiaomi-mimo:"),
        env_keys=("XIAOMI_API_KEY", "MIMO_API_KEY"),
        module_path="concinno_king.providers.lyceum_transport_chat_completions",
        description="Xiaomi MiMo coder",
    ),
    ProviderInfo(
        name="zai",
        source="lyceum-mit",
        model_prefixes=("glm-", "z-ai:", "z.ai:", "zhipu:"),
        env_keys=("ZAI_API_KEY", "Z_AI_API_KEY", "GLM_API_KEY"),
        module_path="concinno_king.providers.lyceum_transport_chat_completions",
        description="Z.ai (Zhipu) GLM family",
    ),
    ProviderInfo(
        name="kimi",
        source="lyceum-mit",
        model_prefixes=("kimi-", "moonshot-", "kimi:"),
        env_keys=("MOONSHOT_API_KEY", "KIMI_API_KEY"),
        module_path="concinno_king.providers.lyceum_transport_chat_completions",
        description="Moonshot AI Kimi (k1, k2, kimi-coder)",
    ),
    ProviderInfo(
        name="minimax",
        source="lyceum-mit",
        model_prefixes=("minimax-", "minimax:", "abab"),
        env_keys=("MINIMAX_API_KEY",),
        module_path="concinno_king.providers.lyceum_transport_chat_completions",
        description="MiniMax (M1, abab series)",
    ),
    ProviderInfo(
        name="huggingface",
        source="lyceum-mit",
        model_prefixes=("hf:", "huggingface:"),
        env_keys=("HF_TOKEN", "HUGGINGFACE_API_KEY"),
        module_path="concinno_king.providers.lyceum_transport_chat_completions",
        description="HuggingFace Inference Endpoints",
    ),
    ProviderInfo(
        name="openai",
        source="lyceum-mit",
        model_prefixes=("gpt-3.5", "gpt-4", "gpt-4o", "openai:"),
        env_keys=("OPENAI_API_KEY",),
        module_path="concinno_king.providers.lyceum_transport_chat_completions",
        description="OpenAI Chat Completions (GPT-3.5 / GPT-4 / GPT-4o)",
    ),
    ProviderInfo(
        name="xai",
        source="lyceum-mit",
        model_prefixes=("grok-", "xai:", "x-ai:"),
        env_keys=("XAI_API_KEY",),
        module_path="concinno_king.providers.lyceum_transport_chat_completions",
        description="xAI Grok",
    ),
    ProviderInfo(
        name="deepseek",
        source="lyceum-mit",
        model_prefixes=("deepseek-", "deepseek:"),
        env_keys=("DEEPSEEK_API_KEY",),
        module_path="concinno_king.providers.lyceum_transport_chat_completions",
        description="DeepSeek (V3, R1, V4)",
    ),
    ProviderInfo(
        name="qwen",
        source="lyceum-mit",
        model_prefixes=("qwen-", "qwen3", "qwen2", "qwen:", "alibaba:", "dashscope:"),
        env_keys=("DASHSCOPE_API_KEY", "QWEN_API_KEY"),
        module_path="concinno_king.providers.lyceum_transport_chat_completions",
        description="Alibaba Qwen / DashScope",
    ),
    ProviderInfo(
        name="custom",
        source="lyceum-mit",
        model_prefixes=("custom:", "local:"),
        env_keys=(),
        module_path="concinno_king.providers.lyceum_transport_chat_completions",
        description="Custom OpenAI-compatible endpoint (BYO base_url)",
    ),
)


# ---------------------------------------------------------------------------
# Sancio-derived adapters (AGPL — Aegis lineage)
# ---------------------------------------------------------------------------

_SANCIO_PROVIDERS: tuple[ProviderInfo, ...] = (
    ProviderInfo(
        name="sancio_anthropic",
        source="sancio-agpl",
        model_prefixes=(),  # not in default routing (lyceum_anthropic wins)
        env_keys=("ANTHROPIC_API_KEY",),
        module_path="concinno_king.providers.sancio_anthropic",
        description="Sancio Anthropic adapter (AGPL, prompt caching, multi-turn cache)",
    ),
    ProviderInfo(
        name="sancio_openai",
        source="sancio-agpl",
        model_prefixes=(),
        env_keys=("OPENAI_API_KEY",),
        module_path="concinno_king.providers.sancio_openai",
        description="Sancio OpenAI adapter (AGPL, async chat completions)",
    ),
    ProviderInfo(
        name="ollama",
        source="sancio-agpl",
        model_prefixes=("ollama:", "ollama/"),
        env_keys=(),
        module_path="concinno_king.providers.sancio_ollama",
        description="Sancio Ollama adapter (local OpenAI-compat sidecar)",
    ),
    ProviderInfo(
        name="groq",
        source="sancio-agpl",
        model_prefixes=("groq:", "llama-3.1-", "llama-3.3-", "mixtral-"),
        env_keys=("GROQ_API_KEY",),
        module_path="concinno_king.providers.sancio_groq",
        description="Sancio Groq adapter (LPU inference, OpenAI-compat)",
    ),
    ProviderInfo(
        name="local_inproc",
        source="sancio-agpl",
        model_prefixes=("inproc:",),
        env_keys=(),
        module_path="concinno_king.providers.sancio_local_inproc",
        description="Sancio in-process llama-cpp-python (no HTTP)",
    ),
    ProviderInfo(
        name="sancio_base",
        source="sancio-agpl",
        model_prefixes=(),
        env_keys=(),
        module_path="concinno_king.providers.sancio_base",
        description="Sancio Protocol baseline (LLMProvider / ProviderRegistry)",
    ),
)


# Master catalogue: dict for O(1) lookup, tuple-of-tuples for ordering.
_REGISTRY: dict[str, ProviderInfo] = {
    info.name: info for info in (*_LYCEUM_PROVIDERS, *_SANCIO_PROVIDERS)
}


def list_providers() -> list[ProviderInfo]:
    """Return the full catalogue (lyceum first, then sancio) preserving order."""
    return [*_LYCEUM_PROVIDERS, *_SANCIO_PROVIDERS]


def available_providers() -> list[ProviderInfo]:
    """Return providers whose env key is set and whose module imports.

    Two-axis check:

    1. **Env**: at least one of ``info.env_keys`` is set in ``os.environ``
       (or the provider declares no env keys, e.g. local lmstudio /
       in-process).
    2. **Import**: ``info.module_path`` imports without ``ImportError``.
       Lyceum adapters import ``from agent.X`` siblings that we did
       not vendor; those will raise ``ImportError`` here and be
       filtered out — that is the **correct** behaviour for first-cut
       availability gating.
    """
    out: list[ProviderInfo] = []
    for info in list_providers():
        # Env gate: empty env_keys means no key needed (local provider).
        if info.env_keys and not any(os.environ.get(k) for k in info.env_keys):
            continue
        # Import gate: module must load.
        try:
            importlib.import_module(info.module_path)
        except (ImportError, ModuleNotFoundError, SyntaxError):
            continue
        out.append(info)
    return out


def get_provider(name: str) -> ProviderInfo:
    """Return the ``ProviderInfo`` for ``name`` or raise ``ProviderError``."""
    if name not in _REGISTRY:
        known = ", ".join(sorted(_REGISTRY.keys()))
        raise ProviderError(
            "registry",
            f"unknown provider {name!r} — known: {known}",
        )
    return _REGISTRY[name]


def resolve(model: str) -> ProviderInfo | None:
    """Resolve a model string to its best-matching provider.

    Order:

    1. Explicit ``provider:model`` form (``openrouter:meta-llama/...``)
       short-circuits the prefix search by looking up ``provider`` directly.
    2. Otherwise the longest matching prefix in
       ``ProviderInfo.model_prefixes`` wins.
    3. Returns ``None`` when no match — caller decides whether to fall
       back (e.g. ``custom`` for unknown OpenAI-compat URLs).
    """
    if not model:
        return None

    # Explicit ``provider:model`` short-circuit.
    if ":" in model:
        head = model.split(":", 1)[0].strip().lower()
        info = _REGISTRY.get(head)
        if info is not None:
            return info

    # Longest-prefix match across the catalogue.
    best: ProviderInfo | None = None
    best_len = 0
    lower = model.lower()
    for info in list_providers():
        for prefix in info.model_prefixes:
            if lower.startswith(prefix.lower()) and len(prefix) > best_len:
                best = info
                best_len = len(prefix)
    return best


def load_adapter(name: str) -> Any:
    """Import and return the underlying adapter module for ``name``.

    Raises ``ProviderError`` on unknown name or import failure. Used
    by the CLI ``providers test <model>`` command to do a live
    connectivity check without instantiating an LLM call.
    """
    info = get_provider(name)
    try:
        return importlib.import_module(info.module_path)
    except (ImportError, ModuleNotFoundError, SyntaxError) as exc:
        raise ProviderError(
            name,
            f"adapter module {info.module_path!r} failed to import: {exc}",
        ) from exc


__all__ = [
    "available_providers",
    "get_provider",
    "list_providers",
    "load_adapter",
    "resolve",
]
