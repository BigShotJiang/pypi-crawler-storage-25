# SPDX-License-Identifier: MIT
"""Unified LLM provider Protocol for the Concinno-King monorepo.

This module is the merge surface between two upstream provider layers:

- **Sancio** (AGPL): a 6-adapter Protocol layer (anthropic / openai /
  ollama / groq / local_inproc / base) under
  ``sancio.persona.providers``. Sancio's Protocol is the structural
  baseline for this file because it already defines async ``generate``
  / ``generate_with_tools`` / ``generate_stream`` plus a dataclass
  envelope (``ProviderResponse`` / ``ToolCallRequest`` / ``UsageStats``
  / ``ModelPolicy``) that the agent loop downstream consumes.
- **Lyceum** (MIT): a transport-layer architecture (4 transports +
  5 dedicated adapters covering Anthropic native / Bedrock / Codex
  Responses / Gemini Cloud Code / Gemini native) where the
  ``chat_completions`` transport multiplexes ~16 OpenAI-compatible
  providers (OpenRouter, Nous, NVIDIA NIM, xAI Grok, Z.ai GLM, Kimi /
  Moonshot, MiniMax, HuggingFace, Xiaomi MiMo, GMI Cloud, Tencent
  TokenHub, Alibaba Qwen / DashScope, custom OpenAI-compat, and
  more).

The unified surface here is intentionally Sancio-shaped: every
adapter speaks ``async def chat(messages, model, **kwargs) ->
ChatResponse`` (the new aliased entrypoint) which delegates to the
underlying SDK / transport. Lyceum's transports are reused at the
data-conversion layer (message / tool format normalisation), Sancio
adapters provide the dispatch baseline.

Why we re-declare the Protocol instead of importing
``sancio_base.LLMProvider`` directly: registry-side adapters need a
namespace that is independent of the upstream packages so consumers
of ``concinno_king.providers`` do not get a hard dep on either
``sancio`` or ``lyceum`` source trees being importable as siblings.
The two upstream files (``sancio_base.py`` and
``lyceum_transport_base.py``) ship verbatim alongside this module
for downstream callers that want the original surfaces.
"""

from __future__ import annotations

import json
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

SSE_DONE = "\x00__SSE_DONE__\x00"
"""Sentinel emitted when an OpenAI-compat SSE stream writes ``data: [DONE]``.

Mirrors :data:`sancio_base.SSE_DONE` so call sites that consume the
sancio surface keep the same identity.
"""


def parse_openai_sse_line(line: str) -> str | None:
    """Parse one OpenAI-style SSE line into a text delta.

    Re-export of the sancio helper; the implementation here is
    a structural copy so the unified Protocol module has zero
    runtime dependency on either upstream package import path.
    """
    if not line or not line.startswith("data:"):
        return None
    body = line[len("data:"):].strip()
    if not body:
        return None
    if body == "[DONE]":
        return SSE_DONE
    try:
        obj = json.loads(body)
    except ValueError:
        return None
    try:
        delta = obj["choices"][0].get("delta") or {}
    except (KeyError, IndexError, TypeError):
        return None
    content = delta.get("content") or ""
    if content:
        return str(content)
    reasoning = delta.get("reasoning") or ""
    return str(reasoning)


class ProviderError(RuntimeError):
    """Unified failure type carrying the provider name + detail."""

    def __init__(self, provider: str, detail: str) -> None:
        super().__init__(f"[{provider}] {detail}")
        self.provider = provider
        self.detail = detail


@dataclass(frozen=True)
class UsageStats:
    """Optional usage + cache telemetry from a provider response."""

    input_tokens: int | None = None
    output_tokens: int | None = None
    cache_creation_input_tokens: int | None = None
    cache_read_input_tokens: int | None = None


@dataclass
class ModelPolicy:
    """Declarative selection of provider + model + generation knobs.

    ``cache_breakpoints`` is Anthropic-specific. ``extra`` carries
    provider-specific overrides (e.g. Anthropic ``cache_strategy``,
    Lyceum ``reasoning_config``, OpenAI-compat ``base_url``).
    """

    provider: str
    model: str
    temperature: float = 0.7
    max_tokens: int = 4096
    cache_breakpoints: list[int] | None = None
    extra: dict[str, object] = field(default_factory=dict)


@dataclass(frozen=True)
class ToolSpec:
    """Provider-agnostic tool advertisement (JSON Schema)."""

    name: str
    description: str
    input_schema: dict[str, Any]


@dataclass(frozen=True)
class ToolCallRequest:
    """One tool invocation emitted by the LLM."""

    id: str
    name: str
    input: dict[str, Any]


@dataclass
class ChatResponse:
    """Unified tool-aware response envelope.

    Shape-compatible with sancio's ``ProviderResponse`` so existing
    sancio-side call sites can rewire to this Protocol with no code
    change beyond the import path.
    """

    text: str | None = None
    tool_calls: list[ToolCallRequest] = field(default_factory=list)
    stop_reason: str = ""
    usage: dict[str, Any] = field(default_factory=dict)


# Backwards-compat alias so sancio call sites keep working.
ProviderResponse = ChatResponse


@runtime_checkable
class LLMProvider(Protocol):
    """Protocol every concrete adapter must satisfy.

    The canonical entrypoint is ``async def chat(messages, model,
    **kwargs) -> ChatResponse``. ``generate`` / ``generate_stream`` /
    ``generate_with_tools`` are kept for sancio-shape compatibility
    so existing code in ``sancio.persona.engine`` can dispatch
    through this Protocol unchanged.
    """

    name: str
    last_usage: UsageStats | None

    async def chat(
        self,
        messages: list[dict[str, Any]],
        model: str,
        **kwargs: Any,
    ) -> ChatResponse:
        """Run one completion. ``kwargs`` accepts ``temperature``,
        ``max_tokens``, ``tools``, ``policy`` (full ``ModelPolicy``),
        plus provider-specific extras forwarded as ``policy.extra``.
        """
        ...

    async def generate(
        self,
        messages: list[dict[str, str]],
        policy: ModelPolicy,
    ) -> str:
        """Sancio-shape: run one completion, return assistant text."""
        ...

    async def generate_with_tools(
        self,
        messages: list[dict[str, Any]],
        policy: ModelPolicy,
        tools: list[ToolSpec],
    ) -> ChatResponse:
        """Sancio-shape: tool-aware completion."""
        ...

    def generate_stream(
        self,
        messages: list[dict[str, str]],
        policy: ModelPolicy,
    ) -> AsyncIterator[str]:
        """Sancio-shape: stream text deltas."""
        ...


class ProviderInfo:
    """Static metadata describing one logical provider in the registry.

    A logical provider is the smallest unit users dispatch to by name
    (e.g. ``openrouter``, ``nous``, ``xai``). Multiple logical providers
    may share one underlying transport (Lyceum's ``chat_completions``
    transport drives ~16 logical providers) — that detail is hidden
    from callers; the registry just resolves a name to an adapter.
    """

    __slots__ = (
        "name",
        "source",
        "model_prefixes",
        "env_keys",
        "module_path",
        "description",
    )

    def __init__(
        self,
        name: str,
        source: str,
        model_prefixes: tuple[str, ...],
        env_keys: tuple[str, ...],
        module_path: str,
        description: str,
    ) -> None:
        self.name = name
        self.source = source  # "lyceum-mit" | "sancio-agpl"
        self.model_prefixes = model_prefixes
        self.env_keys = env_keys
        self.module_path = module_path
        self.description = description

    def __repr__(self) -> str:  # pragma: no cover - debug helper
        return f"ProviderInfo(name={self.name!r}, source={self.source!r})"


__all__ = [
    "ChatResponse",
    "LLMProvider",
    "ModelPolicy",
    "ProviderError",
    "ProviderInfo",
    "ProviderResponse",  # alias of ChatResponse
    "SSE_DONE",
    "ToolCallRequest",
    "ToolSpec",
    "UsageStats",
    "parse_openai_sse_line",
]
