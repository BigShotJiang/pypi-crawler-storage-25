# SPDX-License-Identifier: MIT
"""OpenAI-compatible local LLM provider — speaks to Ollama / llama-cpp-python
/ vLLM / LM Studio. The legacy name ``OllamaProvider`` survives as an alias.

Canonical class: ``OpenAICompatProvider``. Prefer this name in new code.
Ollama is just the default ``vendor`` kwarg — the provider works against
any service that exposes OpenAI's ``/v1/chat/completions`` surface.

Why the rename (2026-04-23): the module is no longer Ollama-centric since
Concinno 2.20.0 shipped ``llm_runtime.LlamaCppBackend`` to bypass the
Ollama Gemma4-Q4_K_M degenerate loop (3/3 synth probes correct at 0.2s vs
Ollama 2/3 + 120s timeout on the identical GGUF). Keeping the filename
``ollama.py`` to avoid mass-import churn; import via the new canonical
name and any future file rename is a pure-path refactor.

Gemma 4 occasionally splits the answer across ``reasoning`` and
``content``; we fall back to ``reasoning`` when ``content`` is empty,
preserving the legacy engine behaviour.
"""

from __future__ import annotations

import json
import logging
import os
from collections.abc import AsyncIterator
from typing import Any

import httpx

from .base import (
    SSE_DONE,
    LLMProvider,
    ModelPolicy,
    ProviderError,
    ProviderResponse,
    ToolCallRequest,
    ToolSpec,
    UsageStats,
    parse_openai_sse_line,
)
from .openai import _OAI_STOP_MAP, _openai_messages_with_tools

_log = logging.getLogger(__name__)

_DEFAULT_URL = os.environ.get("GEMMA_URL", "http://localhost:8400/v1")


def _parse_backend_map(raw: str) -> dict[str, str]:
    """Parse JSON env var into model → base URL map.

    Format: ``{"gemma4-nsfw": "http://h:8401/v1", "qwen3-3b-nsfw":
    "http://h:8402/v1"}``. Trailing slashes stripped. Non-string keys/
    values silently dropped. Parse failure logs a stderr WARN and falls
    back to single-backend mode (legacy ``GEMMA_URL`` behaviour).

    The WARN-on-fail is deliberate (Wave D Step 4a red-team FATAL-3
    fix): silent JSON-parse-fail led to N+1 debugging when sysadmin
    typoed the env (shell escape / trailing comma) and ``qwen3-3b-nsfw``
    requests fell through to ``:8401`` which only knows ``gemma4-nsfw``,
    surfacing as 404 with no log explaining why.
    """
    if not raw or not raw.strip():
        return {}
    try:
        d = json.loads(raw)
    except (json.JSONDecodeError, TypeError, ValueError) as exc:
        _log.warning(
            "GEMMA_BACKEND_MAP parse failed (%s); falling back to "
            "single-backend mode. Raw value first 80 chars: %r",
            exc, raw[:80],
        )
        return {}
    if not isinstance(d, dict):
        _log.warning(
            "GEMMA_BACKEND_MAP parsed but is not a dict (got %s); "
            "falling back to single-backend mode.",
            type(d).__name__,
        )
        return {}
    out: dict[str, str] = {}
    for k, v in d.items():
        if isinstance(k, str) and isinstance(v, str) and v.strip():
            out[k] = v.rstrip("/")
        else:
            _log.warning(
                "GEMMA_BACKEND_MAP entry skipped (key=%r value=%r): "
                "both must be non-empty strings.",
                k, v,
            )
    return out

# Local LLM context-window default. Gemma 4 natively supports up to
# 256K but the GGUF deployment on RTX 5090 (32 GB VRAM) only fits
# 12288 with flash_attn=True (see scripts/pod/llamacpp_wrap.py
# history block, 04-27j calibration). This value MUST match the
# ``N_CTX`` configured in the wrap server — when they diverge,
# sancio's context_budget guard sizes the sliding window for the
# wrong ceiling and the request reaches llama already over budget.
# Tuned at this default 04-27j, override per call via
# ``ModelPolicy.extra["num_ctx"]`` only when the wrap is also
# reconfigured.
_DEFAULT_NUM_CTX = 24576


def _ollama_options(policy: ModelPolicy) -> dict[str, Any] | None:
    """Build the Ollama-specific ``options`` dict from a ModelPolicy.

    Ollama's OpenAI-compat endpoint accepts vendor extensions inside
    a top-level ``options`` key (or an ``extra_body.options`` via the
    openai SDK). Today we wire two keys:

    * ``num_ctx`` — context window cap. Absent the caller-supplied
      value we inject :data:`_DEFAULT_NUM_CTX` so long GAIA prompts
      don't silently truncate.
    * ``seed`` — deterministic sampler seed. Passed through only when
      the caller set ``ModelPolicy.extra["seed"]`` to an int;
      otherwise omitted so Ollama uses its own stochastic default.
      Benchmark runners set a seed for paired-seed McNemar analyses
      where comparing runs at fixed randomness is critical.

    Returns ``None`` when neither key produced a value, preserving
    the legacy wire shape (no ``options`` key) for contract tests.
    """
    extra = policy.extra or {}
    out: dict[str, Any] = {}

    num_ctx = extra.get("num_ctx", _DEFAULT_NUM_CTX)
    if num_ctx is not None:
        try:
            out["num_ctx"] = int(num_ctx)
        except (TypeError, ValueError):
            pass

    seed = extra.get("seed")
    if seed is not None:
        try:
            out["seed"] = int(seed)
        except (TypeError, ValueError):
            pass

    return out or None


class OpenAICompatProvider(LLMProvider):
    """Adapter for any OpenAI-compatible chat endpoint.

    Speaks the ``/v1/chat/completions`` dialect shared by Ollama,
    llama-cpp-python (``python -m llama_cpp.server``), vLLM, and LM Studio.

    Ollama (and most local OpenAI-compat shims: vLLM, llama.cpp,
    LM Studio) does not expose usage telemetry through the
    ``/v1/chat/completions`` surface, and has no prompt-cache
    semantics to report even if it did. :attr:`last_usage` therefore
    stays at ``None`` after every call — downstream telemetry
    consumers (engine.py ``llm_call_end`` event) must handle
    ``None`` gracefully.

    Vendor switch
    -------------
    The OpenAI-compat family is NOT uniform on unknown JSON keys:

    - Ollama accepts + forwards the top-level ``options`` bag (our
      ``num_ctx`` / ``seed`` lands in the native llama.cpp runtime).
    - llama-cpp-python's ``python -m llama_cpp.server`` uses strict
      Pydantic validation on the OpenAI schema and returns **400** on
      any unknown field (``options`` included).
    - vLLM / LM Studio fall somewhere between; safest is to treat
      them the same as llama.cpp.

    Pass ``vendor="llamacpp"`` (or ``"vllm"`` / ``"lmstudio"``) to
    suppress the Ollama-only ``options`` key. The default stays
    ``"ollama"`` for backwards compat.
    """

    name = "ollama"

    def __init__(
        self,
        base_url: str | None = None,
        api_key: str | None = None,
        client: httpx.AsyncClient | None = None,
        vendor: str = "ollama",
        *,
        backend_map: dict[str, str] | None = None,
    ) -> None:
        self._base_url = (base_url or _DEFAULT_URL).rstrip("/")
        self._api_key = api_key or os.environ.get("GEMMA_API_KEY", "")
        self._client = client or httpx.AsyncClient(timeout=600.0)
        # Env override so ops can flip the deployed provider between
        # Ollama and llama-cpp-python / vLLM without a code change:
        # ``GEMMA_VENDOR=llamacpp systemctl restart persona-api`` is the
        # one-line swap that gates the Ollama-only ``options`` bag.
        env_vendor = os.environ.get("GEMMA_VENDOR")
        if env_vendor:
            vendor = env_vendor
        self._vendor = vendor
        # Preserve per-instance distinguishability for telemetry /
        # logging: keep class name "ollama" for Protocol conformance
        # but expose the effective wire dialect via .name.
        if vendor != "ollama":
            self.name = vendor
        # See class docstring: Ollama has no cache / usage surface,
        # so this never gets populated and we keep the attribute
        # purely for Protocol conformance.
        self.last_usage: UsageStats | None = None

        # 2026-05-02 Wave D Step 4a — per-model backend routing.
        # Default empty (legacy single-backend behaviour preserved).
        # Env GEMMA_BACKEND_MAP wins over kwarg so ops can flip
        # routing without a code redeploy — same precedence pattern as
        # GEMMA_VENDOR (line 144-146). Models not in the map (or no
        # map at all) fall through to the legacy ``_base_url`` resolved
        # from base_url kwarg / GEMMA_URL.
        env_map = _parse_backend_map(os.environ.get("GEMMA_BACKEND_MAP", ""))
        self._backend_map: dict[str, str] = {
            **(backend_map or {}),
            **env_map,
        }

    def _resolve_base_url(self, model: str | None) -> str:
        """Pick upstream base URL for ``model``, fall back to ``_base_url``.

        Returns the value verbatim from ``self._backend_map`` (already
        trailing-slash-stripped at parse time). When ``model`` is
        ``None`` or missing from the map, returns the legacy single-
        backend ``_base_url``. The caller appends ``/chat/completions``
        — never include that suffix in the map values.
        """
        if model and model in self._backend_map:
            return self._backend_map[model]
        return self._base_url

    async def generate(
        self,
        messages: list[dict[str, str]],
        policy: ModelPolicy,
    ) -> str:
        headers: dict[str, str] = {"Content-Type": "application/json"}
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"
        payload: dict[str, Any] = {
            "model": policy.model,
            "messages": messages,
            "temperature": policy.temperature,
            "max_tokens": policy.max_tokens,
        }
        if self._vendor == "ollama":
            options = _ollama_options(policy)
            if options:
                payload["options"] = options
        # 2026-04-30 Phase E — forward sampling-time constraint fields
        # from policy.extra (set by /v1/messages endpoint when caller
        # supplies grammar / response_format). Lifts into payload top-
        # level so llama-cpp-python wrap & vLLM / LM Studio honour them.
        # Ollama path historically ignores these; pass-through is safe
        # because Ollama drops unknown top-level keys silently.
        extra = policy.extra or {}
        grammar = extra.get("grammar")
        if isinstance(grammar, str) and grammar.strip():
            payload["grammar"] = grammar
        response_format = extra.get("response_format")
        if isinstance(response_format, dict):
            payload["response_format"] = response_format
        url = self._resolve_base_url(policy.model)
        try:
            resp = await self._client.post(
                f"{url}/chat/completions",
                json=payload,
                headers=headers,
            )
            resp.raise_for_status()
            data = resp.json()
        except httpx.HTTPError as exc:
            raise ProviderError(self.name, f"http: {exc}") from exc
        except ValueError as exc:
            raise ProviderError(self.name, f"bad json: {exc}") from exc

        try:
            msg = data["choices"][0]["message"]
        except (KeyError, IndexError, TypeError) as exc:
            raise ProviderError(self.name, f"parse: {exc}") from exc

        content = (msg.get("content") or "").strip()
        if content:
            return content
        reasoning = (msg.get("reasoning") or "").strip()
        if reasoning:
            return reasoning
        raise ProviderError(self.name, "empty response")

    async def generate_with_tools(
        self,
        messages: list[dict[str, Any]],
        policy: ModelPolicy,
        tools: list[ToolSpec],
    ) -> ProviderResponse:
        """Ollama v0.4+ OpenAI-compat tool calling.

        Ollama ≥0.4 supports the OpenAI ``tools`` parameter on
        ``/v1/chat/completions``. Models that understand function
        calling (qwen2.5-coder, llama3.1+, gemma4) emit
        ``message.tool_calls`` identical to OpenAI's shape. Older
        Ollama or unsupported models respond without ``tool_calls``
        and we surface text only — no exception (the agent loop
        will just treat it as ``end_turn``).
        """
        headers: dict[str, str] = {"Content-Type": "application/json"}
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"
        payload: dict[str, Any] = {
            "model": policy.model,
            "messages": _openai_messages_with_tools(messages),
            "temperature": policy.temperature,
            "max_tokens": policy.max_tokens,
        }
        if self._vendor == "ollama":
            options = _ollama_options(policy)
            if options:
                payload["options"] = options
        if tools:
            payload["tools"] = [
                {
                    "type": "function",
                    "function": {
                        "name": t.name,
                        "description": t.description,
                        "parameters": t.input_schema,
                    },
                }
                for t in tools
            ]
        url = self._resolve_base_url(policy.model)
        try:
            resp = await self._client.post(
                f"{url}/chat/completions",
                json=payload,
                headers=headers,
            )
            resp.raise_for_status()
            data = resp.json()
        except httpx.HTTPError as exc:
            raise ProviderError(self.name, f"http: {exc}") from exc
        except ValueError as exc:
            raise ProviderError(self.name, f"bad json: {exc}") from exc

        try:
            choice = data["choices"][0]
            msg = choice["message"]
        except (KeyError, IndexError, TypeError) as exc:
            raise ProviderError(self.name, f"parse: {exc}") from exc

        raw_content = msg.get("content")
        text = raw_content.strip() if isinstance(raw_content, str) else None
        if not text:
            reasoning = (msg.get("reasoning") or "").strip()
            text = reasoning or None

        tool_calls: list[ToolCallRequest] = []
        for tc in msg.get("tool_calls") or []:
            fn = tc.get("function") or {}
            raw_args = fn.get("arguments", "{}")
            if isinstance(raw_args, str):
                try:
                    parsed = json.loads(raw_args)
                except ValueError:
                    parsed = {"_raw": raw_args}
            else:
                parsed = raw_args or {}
            tool_calls.append(ToolCallRequest(
                id=tc.get("id") or f"call_{len(tool_calls)}",
                name=fn.get("name", ""),
                input=parsed if isinstance(parsed, dict) else {"_value": parsed},
            ))

        raw_stop = choice.get("finish_reason") or ""
        return ProviderResponse(
            text=text,
            tool_calls=tool_calls,
            stop_reason=_OAI_STOP_MAP.get(raw_stop, raw_stop),
            usage={},
        )

    async def generate_stream(
        self,
        messages: list[dict[str, str]],
        policy: ModelPolicy,
    ) -> AsyncIterator[str]:
        """Stream OpenAI-compatible SSE deltas as plain chunks.

        Ollama's ``/v1/chat/completions`` endpoint (which is what we
        point at — not the native ``/api/chat``) speaks OpenAI SSE
        when ``stream: true`` is set. Each event line starts with
        ``data: `` followed by a JSON object; we yield
        ``choices[0].delta.content`` for each. ``data: [DONE]``
        terminates the stream.

        We buffer nothing on error — the first exception terminates
        the iterator before any partial/error text leaks out.
        """
        headers: dict[str, str] = {"Content-Type": "application/json"}
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"
        payload: dict[str, Any] = {
            "model": policy.model,
            "messages": messages,
            "temperature": policy.temperature,
            "max_tokens": policy.max_tokens,
            "stream": True,
        }
        if self._vendor == "ollama":
            options = _ollama_options(policy)
            if options:
                payload["options"] = options
        url = self._resolve_base_url(policy.model)
        try:
            async with self._client.stream(
                "POST",
                f"{url}/chat/completions",
                json=payload,
                headers=headers,
            ) as resp:
                resp.raise_for_status()
                async for line in resp.aiter_lines():
                    chunk = parse_openai_sse_line(line)
                    if chunk is None:
                        continue
                    if chunk == SSE_DONE:
                        return
                    if chunk:
                        yield chunk
        except httpx.HTTPError as exc:
            raise ProviderError(self.name, f"http: {exc}") from exc
        except ValueError as exc:
            raise ProviderError(self.name, f"bad json: {exc}") from exc


# Backwards-compat alias. Prefer ``OpenAICompatProvider`` in new code.
# The filename + legacy class name stay for import stability across the
# 7 downstream files (providers/__init__ + tests + live smokes); a future
# dedicated PR can rename the file + drop this alias once every import
# site migrates.
OllamaProvider = OpenAICompatProvider
