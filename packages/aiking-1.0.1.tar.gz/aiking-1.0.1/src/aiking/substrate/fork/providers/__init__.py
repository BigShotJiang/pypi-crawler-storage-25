# SPDX-License-Identifier: MIT
"""Concinno-King provider fleet — Lyceum (MIT) + Sancio (AGPL) merge.

Public surface:

- :class:`LLMProvider` — Protocol every adapter satisfies.
- :class:`ChatResponse` — unified tool-aware response envelope
  (alias of sancio's ``ProviderResponse`` for backwards compat).
- :class:`ModelPolicy` / :class:`ToolSpec` / :class:`ToolCallRequest` /
  :class:`UsageStats` — the dataclass envelope shared by all adapters.
- :class:`ProviderError` — unified failure type.
- :class:`ProviderInfo` — registry metadata for one logical provider.
- :func:`list_providers` / :func:`available_providers` /
  :func:`get_provider` / :func:`resolve` / :func:`load_adapter` —
  registry surface.

Dual-source notice: this package merges code from two upstream
repositories under different licenses. See the ``NOTICE`` file
adjacent to this module for full attribution.
"""

from __future__ import annotations

from .base import (
    SSE_DONE,
    ChatResponse,
    LLMProvider,
    ModelPolicy,
    ProviderError,
    ProviderInfo,
    ProviderResponse,  # alias of ChatResponse
    ToolCallRequest,
    ToolSpec,
    UsageStats,
    parse_openai_sse_line,
)
from .registry import (
    available_providers,
    get_provider,
    list_providers,
    load_adapter,
    resolve,
)

__all__ = [
    "ChatResponse",
    "LLMProvider",
    "ModelPolicy",
    "ProviderError",
    "ProviderInfo",
    "ProviderResponse",
    "SSE_DONE",
    "ToolCallRequest",
    "ToolSpec",
    "UsageStats",
    "available_providers",
    "get_provider",
    "list_providers",
    "load_adapter",
    "parse_openai_sse_line",
    "resolve",
]
