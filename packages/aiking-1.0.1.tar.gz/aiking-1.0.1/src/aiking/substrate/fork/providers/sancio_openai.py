# SPDX-License-Identifier: MIT
"""OpenAI-compatible provider (GPT-5, o1-mini, OpenRouter-backed Kimi).

Uses raw ``httpx`` rather than the openai SDK so we stay lightweight
and don't pull another optional dependency. Any endpoint that speaks
the ``POST /chat/completions`` contract works — point ``base_url`` at
``https://openrouter.ai/api/v1`` to route Kimi via OpenRouter.

Format assumption (unverified against live API in this session):
response payload shaped as ``{"choices": [{"message": {"content":
...}}]}``. This matches the public OpenAI reference for chat
completions (docs read 2026-04-14). Mark as "expected, untested"
in the contract tests.
"""

from __future__ import annotations

import os
from collections.abc import AsyncIterator

import httpx

import json
from typing import Any

from .base import (
    SSE_DONE,
    LLMProvider,
    ModelPolicy,
    ProviderError,
    ProviderResponse,
    ToolCallRequest,
    ToolSpec,
    UsageStats,
    parse_openai_sse_line,
    parse_openai_sse_usage,
)


def _openai_messages_with_tools(
    messages: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Translate agent-loop history into OpenAI-compat chat shape.

    Key transformations:

    - ``role=tool`` + ``tool_call_id`` passes through unchanged
      (OpenAI chat spec already speaks this).
    - ``role=assistant`` with ``tool_calls`` on the loop side maps
      onto OpenAI ``tool_calls`` with ``function.{name,arguments}``
      where ``arguments`` is a JSON-encoded string.
    - ``content=[...]`` lists (Anthropic block shape) are flattened
      to a single string by concatenating ``text`` parts; tool_use
      blocks there are expanded as separate ``tool_calls`` entries
      so cross-provider histories survive a round-trip.
    - Concinno ``fetch_image`` marker strings are upgraded into OpenAI
      multimodal content blocks (``{type:"image_url", ...}``) so a
      vision-capable model (Gemma 4, GPT-4o, Claude 3+) actually
      sees the image on the next inference turn. ``tool``-role
      messages carrying an image marker are split into a text-only
      tool confirmation + a synthetic ``user`` message carrying the
      image, because the OpenAI chat spec forbids multimodal content
      under the ``tool`` role.
    """
    # Deferred import keeps openai.py free of a hard concinno dep
    # at module import time (it's already a runtime dep via other
    # code paths, so the lazy import is cost-free in practice).
    try:
        from concinno.tools.builtin.fetch_image import (
            IMAGE_MARKER_START,
            parse_image_marker,
        )
    except ImportError:
        IMAGE_MARKER_START = "__CONCINNO_IMAGE_B64__"

        def parse_image_marker(_content: str) -> None:  # type: ignore[misc]
            return None

    out: list[dict[str, Any]] = []
    for m in messages:
        role = m.get("role", "user")
        content = m.get("content", "")
        if role == "tool":
            content_str = (
                content if isinstance(content, str)
                else json.dumps(content, ensure_ascii=False, default=str)
            )
            if IMAGE_MARKER_START in content_str:
                blocks = parse_image_marker(content_str)
                if blocks:
                    # Tool role keeps a short text ack (per OpenAI
                    # spec requiring str content for tool messages),
                    # and we synthesize a user message carrying the
                    # image right after so the model can actually
                    # see it on the next turn.
                    out.append({
                        "role": "tool",
                        "tool_call_id": m.get("tool_call_id", ""),
                        "content": (
                            "(Image fetched — see following user "
                            "message for inline image content.)"
                        ),
                    })
                    out.append({"role": "user", "content": blocks})
                    continue
            out.append({
                "role": "tool",
                "tool_call_id": m.get("tool_call_id", ""),
                "content": content_str,
            })
            continue
        if role == "assistant" and m.get("tool_calls"):
            tcs = [
                {
                    "id": tc.get("id", ""),
                    "type": "function",
                    "function": {
                        "name": tc.get("name", ""),
                        "arguments": json.dumps(
                            tc.get("args") or tc.get("input") or {},
                            ensure_ascii=False,
                        ),
                    },
                }
                for tc in m["tool_calls"]
            ]
            out.append({
                "role": "assistant",
                "content": content if isinstance(content, str) else "",
                "tool_calls": tcs,
            })
            continue
        if isinstance(content, list):
            content = " ".join(
                str(p.get("text", "")) for p in content
                if isinstance(p, dict) and p.get("type") == "text"
            )
        if isinstance(content, str) and IMAGE_MARKER_START in content:
            blocks = parse_image_marker(content)
            if blocks:
                out.append({"role": role, "content": blocks})
                continue
        out.append({"role": role, "content": content})
    return out


_OAI_STOP_MAP = {
    "stop": "end_turn",
    "tool_calls": "tool_use",
    "length": "max_tokens",
}

_DEFAULT_URL = os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1")


class OpenAIProvider(LLMProvider):
    """Adapter for OpenAI chat completions (and compatible gateways)."""

    name = "openai"

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self._api_key = api_key or os.environ.get("OPENAI_API_KEY", "")
        self._base_url = (base_url or _DEFAULT_URL).rstrip("/")
        self._client = client or httpx.AsyncClient(timeout=120)
        self.last_usage: UsageStats | None = None

    async def generate(
        self,
        messages: list[dict[str, str]],
        policy: ModelPolicy,
    ) -> str:
        if not self._api_key:
            raise ProviderError(self.name, "OPENAI_API_KEY not set")
        payload: dict[str, object] = {
            "model": policy.model,
            "messages": messages,
            "temperature": policy.temperature,
            "max_tokens": policy.max_tokens,
        }
        payload.update(policy.extra)
        try:
            resp = await self._client.post(
                f"{self._base_url}/chat/completions",
                json=payload,
                headers={
                    "Authorization": f"Bearer {self._api_key}",
                    "Content-Type": "application/json",
                },
            )
            resp.raise_for_status()
            data = resp.json()
        except httpx.HTTPError as exc:
            raise ProviderError(self.name, f"http: {exc}") from exc
        except ValueError as exc:
            raise ProviderError(self.name, f"bad json: {exc}") from exc

        try:
            content = data["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as exc:
            raise ProviderError(self.name, f"parse: {exc}") from exc
        # Capture usage BEFORE validating content so an empty
        # response still records the billed tokens.
        try:
            usage = data.get("usage") if isinstance(data, dict) else None
            if isinstance(usage, dict):
                self.last_usage = UsageStats(
                    input_tokens=usage.get("prompt_tokens"),
                    output_tokens=usage.get("completion_tokens"),
                    cache_creation_input_tokens=None,
                    cache_read_input_tokens=None,
                )
            else:
                self.last_usage = None
        except Exception:  # noqa: BLE001 — telemetry never fatal
            self.last_usage = None
        text = (content or "").strip()
        if not text:
            raise ProviderError(self.name, "empty content")
        return text

    async def generate_with_tools(
        self,
        messages: list[dict[str, Any]],
        policy: ModelPolicy,
        tools: list[ToolSpec],
    ) -> ProviderResponse:
        """OpenAI chat-completions with native ``tools`` + ``tool_calls``.

        Converts :class:`ToolSpec` to ``{"type":"function","function":
        {"name","description","parameters"}}`` and parses
        ``choices[0].message.tool_calls`` back into
        :class:`ToolCallRequest`.

        ``function.arguments`` on the wire is a JSON-encoded string —
        we decode it here so the agent loop always sees a dict.
        """
        if not self._api_key:
            raise ProviderError(self.name, "OPENAI_API_KEY not set")
        payload: dict[str, Any] = {
            "model": policy.model,
            "messages": _openai_messages_with_tools(messages),
            "temperature": policy.temperature,
            "max_tokens": policy.max_tokens,
        }
        payload.update(policy.extra or {})
        if tools:
            payload["tools"] = [
                {
                    "type": "function",
                    "function": {
                        "name": t.name,
                        "description": t.description,
                        "parameters": t.input_schema,
                    },
                }
                for t in tools
            ]
        try:
            resp = await self._client.post(
                f"{self._base_url}/chat/completions",
                json=payload,
                headers={
                    "Authorization": f"Bearer {self._api_key}",
                    "Content-Type": "application/json",
                },
            )
            resp.raise_for_status()
            data = resp.json()
        except httpx.HTTPError as exc:
            raise ProviderError(self.name, f"http: {exc}") from exc
        except ValueError as exc:
            raise ProviderError(self.name, f"bad json: {exc}") from exc

        try:
            choice = data["choices"][0]
            msg = choice["message"]
        except (KeyError, IndexError, TypeError) as exc:
            raise ProviderError(self.name, f"parse: {exc}") from exc

        raw_content = msg.get("content")
        text = raw_content.strip() if isinstance(raw_content, str) else None
        if text == "":
            text = None

        tool_calls: list[ToolCallRequest] = []
        for tc in msg.get("tool_calls") or []:
            fn = tc.get("function") or {}
            raw_args = fn.get("arguments", "{}")
            try:
                parsed = json.loads(raw_args) if isinstance(raw_args, str) \
                    else (raw_args or {})
            except ValueError:
                parsed = {"_raw": raw_args}
            tool_calls.append(ToolCallRequest(
                id=tc.get("id", ""),
                name=fn.get("name", ""),
                input=parsed if isinstance(parsed, dict) else {"_value": parsed},
            ))

        usage = data.get("usage") if isinstance(data, dict) else None
        if isinstance(usage, dict):
            self.last_usage = UsageStats(
                input_tokens=usage.get("prompt_tokens"),
                output_tokens=usage.get("completion_tokens"),
                cache_creation_input_tokens=None,
                cache_read_input_tokens=None,
            )
        else:
            self.last_usage = None

        raw_stop = choice.get("finish_reason") or ""
        return ProviderResponse(
            text=text,
            tool_calls=tool_calls,
            stop_reason=_OAI_STOP_MAP.get(raw_stop, raw_stop),
            usage=dict(usage) if isinstance(usage, dict) else {},
        )

    async def generate_stream(
        self,
        messages: list[dict[str, str]],
        policy: ModelPolicy,
    ) -> AsyncIterator[str]:
        """Stream chat-completions deltas as plain chunks.

        Uses the same httpx client the non-streaming path uses so
        the adapter stays a single HTTP surface. ``policy.extra`` is
        merged into the request payload (same as :meth:`generate`),
        but ``stream`` is force-set to ``True``.

        Yields ``choices[0].delta.content`` for each frame until
        ``data: [DONE]``. Empty delta frames (role-only openers) are
        silently skipped to keep the token shape sensible downstream.
        """
        if not self._api_key:
            raise ProviderError(self.name, "OPENAI_API_KEY not set")
        payload: dict[str, object] = {
            "model": policy.model,
            "messages": messages,
            "temperature": policy.temperature,
            "max_tokens": policy.max_tokens,
        }
        payload.update(policy.extra)
        payload["stream"] = True
        # Opt into final-frame usage telemetry. OpenAI-compatible
        # gateways that don't know this flag simply ignore it (Ollama
        # drops unknown keys, Groq supports it natively). The final
        # ``data:`` frame then carries ``choices == []`` with a
        # fully-populated ``usage`` block which we harvest into
        # ``last_usage`` below.
        payload.setdefault("stream_options", {"include_usage": True})
        # Reset telemetry for this call. Populated on the final
        # usage frame; if none arrives it stays None (defensive
        # degrade).
        self.last_usage = None
        try:
            async with self._client.stream(
                "POST",
                f"{self._base_url}/chat/completions",
                json=payload,
                headers={
                    "Authorization": f"Bearer {self._api_key}",
                    "Content-Type": "application/json",
                },
            ) as resp:
                resp.raise_for_status()
                async for line in resp.aiter_lines():
                    # Usage frames have empty ``choices`` + populated
                    # ``usage``; ``parse_openai_sse_line`` would see
                    # no delta and return None, so we probe for usage
                    # on every line independently.
                    try:
                        maybe_usage = parse_openai_sse_usage(line)
                        if maybe_usage is not None:
                            self.last_usage = maybe_usage
                    except Exception:  # noqa: BLE001 — never fatal
                        pass
                    chunk = parse_openai_sse_line(line)
                    if chunk is None:
                        continue
                    if chunk == SSE_DONE:
                        return
                    if chunk:
                        yield chunk
        except httpx.HTTPError as exc:
            raise ProviderError(self.name, f"http: {exc}") from exc
