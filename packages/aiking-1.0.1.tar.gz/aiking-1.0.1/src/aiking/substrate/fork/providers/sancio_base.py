# SPDX-License-Identifier: MIT
"""LLM provider Protocol + shared types for Aegis self-contained router.

Why this module exists
----------------------
Aegis used to hard-code two LLM paths inside ``engine.py``
(the old ``_llm_anthropic`` and the Gemma OpenAI-compatible client).
Both have since been removed; this provider layer is now the single
canonical dispatch path.

``engine.py`` holds a ``ProviderRegistry`` instance and dispatches by
``ModelPolicy``; each concrete provider is a thin async adapter that
speaks one HTTP API.

Design rules (enforced by tests, not convention)
-------------------------------------------------
1. Every provider implements the :class:`LLMProvider` Protocol.
2. No provider imports anything from ``concinno``. The provider
   layer must stay runnable in environments where concinno is not
   installed — this is Aegis' independence lever.
3. Failures raise :class:`ProviderError` with the provider name,
   never ``return "[anthropic error] ..."`` sentinel strings.
4. ``generate`` is always async. FastAPI/Starlette friendly.
"""

from __future__ import annotations

import json
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

# Sentinel emitted by :func:`parse_openai_sse_line` when the upstream
# writes ``data: [DONE]`` — shared across Ollama/OpenAI/Groq adapters
# so the SSE dialect lives in one place.
SSE_DONE = "\x00__SSE_DONE__\x00"


def parse_openai_sse_line(line: str) -> str | None:
    """Parse one OpenAI-style SSE line into the text delta.

    The OpenAI chat-completions streaming wire format is a sequence
    of ``data: {json}`` frames separated by blank lines, terminated
    by ``data: [DONE]``. This helper collapses one line to one of:

    - ``None``: blank / keepalive / non-``data:`` frame (skip it).
    - :data:`SSE_DONE` sentinel: terminator, caller stops iterating.
    - ``str``: the ``choices[0].delta.content`` delta (possibly
      empty — Ollama sometimes emits empty role-only frames before
      the first content token; callers skip empties themselves).

    Reasoning-model fallback
    ------------------------
    Some reasoning models routed through Ollama's OpenAI-compat
    ``/v1/chat/completions`` (qwen3, deepseek-r1, etc.) stream their
    thinking trace in ``delta.reasoning`` and leave ``delta.content``
    empty until the final answer tokens. The non-streaming path in
    :class:`persona.providers.ollama.OllamaProvider` already falls
    back to ``message.reasoning`` when ``message.content`` is empty;
    we mirror that here so ``generate_stream`` does not silently
    yield zero chunks on those models. Content wins when both are
    present; reasoning is the fallback.
    """
    if not line or not line.startswith("data:"):
        return None
    body = line[len("data:"):].strip()
    if not body:
        return None
    if body == "[DONE]":
        return SSE_DONE
    try:
        obj = json.loads(body)
    except ValueError:
        return None
    try:
        delta = obj["choices"][0].get("delta") or {}
    except (KeyError, IndexError, TypeError):
        return None
    content = delta.get("content") or ""
    if content:
        return str(content)
    reasoning = delta.get("reasoning") or ""
    return str(reasoning)


def parse_openai_sse_usage(line: str) -> "UsageStats | None":
    """Extract a :class:`UsageStats` from an OpenAI-style SSE line.

    OpenAI / Groq streaming speaks the ``stream_options.include_usage``
    extension: the final pre-``[DONE]`` frame carries
    ``choices == []`` and a fully-populated ``usage`` block shaped
    ``{"prompt_tokens": N, "completion_tokens": M, "total_tokens":
    N+M}``. We map it onto :class:`UsageStats` with the cache fields
    left at ``None`` (the OpenAI-compat layer does not expose cache
    telemetry — that's Anthropic-specific).

    Returns ``None`` for any frame that is not a usage frame (blank,
    keepalive, content delta, ``[DONE]``, malformed JSON, missing
    ``usage`` key). Never raises — telemetry is second-class.
    """
    if not line or not line.startswith("data:"):
        return None
    body = line[len("data:"):].strip()
    if not body or body == "[DONE]":
        return None
    try:
        obj = json.loads(body)
    except ValueError:
        return None
    usage = obj.get("usage") if isinstance(obj, dict) else None
    if not isinstance(usage, dict):
        return None
    try:
        return UsageStats(
            input_tokens=usage.get("prompt_tokens"),
            output_tokens=usage.get("completion_tokens"),
            cache_creation_input_tokens=None,
            cache_read_input_tokens=None,
        )
    except Exception:  # noqa: BLE001 — telemetry never fatal
        return None


class ProviderError(RuntimeError):
    """Unified error raised by any :class:`LLMProvider` call.

    Carries the provider name alongside the underlying detail so the
    caller can route fallback logic (e.g. escalate to a different
    provider) without string-matching error messages.
    """

    def __init__(self, provider: str, detail: str) -> None:
        super().__init__(f"[{provider}] {detail}")
        self.provider = provider
        self.detail = detail


@dataclass(frozen=True)
class UsageStats:
    """Optional usage + cache telemetry from a provider response.

    Fields that the provider cannot populate stay at ``None`` (not
    ``0``) so the distinction between "no data" and "zero tokens" is
    preserved on downstream consumers.

    - ``input_tokens`` / ``output_tokens``: plain Anthropic /
      OpenAI-style token counts.
    - ``cache_creation_input_tokens``: tokens written into cache on
      this call (Anthropic-specific, counts cost in cache WRITE band
      which is 1.25x).
    - ``cache_read_input_tokens``: tokens served FROM cache
      (Anthropic-specific, 0.1x the normal input cost).

    We collect raw counts only; applying cost multipliers (1.25x
    write, 0.1x read) is a downstream concern so this struct stays
    billing-agnostic and works across future price changes.
    """

    input_tokens: int | None = None
    output_tokens: int | None = None
    cache_creation_input_tokens: int | None = None
    cache_read_input_tokens: int | None = None


@dataclass
class ModelPolicy:
    """Declarative selection of provider + model + generation knobs.

    ``cache_breakpoints`` is Anthropic-specific and is ignored by
    other providers. A value of ``None`` means "use the provider's
    default caching strategy" (Anthropic provider caches the system
    block + first user turn, matching the legacy engine behaviour).
    """

    provider: str
    model: str
    temperature: float = 0.7
    max_tokens: int = 4096
    cache_breakpoints: list[int] | None = None
    extra: dict[str, object] = field(default_factory=dict)


@dataclass(frozen=True)
class ToolSpec:
    """Provider-agnostic tool advertisement.

    Each provider converts this into the native wire shape inside
    :meth:`LLMProvider.generate_with_tools`. ``input_schema`` is a
    plain JSON Schema dict (``type: object`` with ``properties``/
    ``required``) — identical to OpenAI function-calling and
    Anthropic ``tools[].input_schema``, so the conversion is a
    shallow re-nesting per provider rather than a translation.
    """

    name: str
    description: str
    input_schema: dict[str, Any]


@dataclass(frozen=True)
class ToolCallRequest:
    """One tool invocation emitted by the LLM.

    Mirrors :class:`persona.engine.agent_loop.ToolCall` but lives at
    the provider layer — the agent loop converts between the two at
    the adapter boundary so provider code stays independent of the
    loop's mutable state machine.
    """

    id: str
    name: str
    input: dict[str, Any]


@dataclass
class ProviderResponse:
    """Unified tool-aware response envelope.

    Every provider's :meth:`LLMProvider.generate_with_tools` normalises
    its native shape (Anthropic ``content`` blocks, OpenAI ``message.
    tool_calls``, Ollama/Groq OpenAI-compat) into this struct so the
    agent loop has exactly one code path regardless of backend.

    Fields
    ------
    text:
        Assistant text. ``None`` when the model emitted only
        ``tool_use`` blocks (Anthropic) or only ``tool_calls``
        (OpenAI-compat) — distinguishes "no text produced" from
        "empty string produced" for downstream SSE framing.
    tool_calls:
        Ordered list of tool requests. Empty when the model is done
        thinking. Each entry is a :class:`ToolCallRequest`.
    stop_reason:
        Provider-native termination reason, normalised to the
        Anthropic vocabulary where possible: ``end_turn`` /
        ``tool_use`` / ``max_tokens`` / ``stop_sequence``. Passed
        through verbatim when the provider reports something we
        don't know how to map.
    usage:
        Loose dict carrying ``input_tokens`` / ``output_tokens`` /
        cache fields if the provider exposes them. Callers that
        want structured telemetry should read ``provider.last_usage``.
    """

    text: str | None = None
    tool_calls: list[ToolCallRequest] = field(default_factory=list)
    stop_reason: str = ""
    usage: dict[str, Any] = field(default_factory=dict)


@runtime_checkable
class LLMProvider(Protocol):
    """Protocol every concrete provider adapter must satisfy.

    Implementations are expected to be small (≤60 LOC) and to contain
    only the HTTP/SDK glue code needed to go from
    ``(messages, policy)`` to a plain assistant string. Persona logic,
    RAG injection, retry policy and fallback all live in ``engine.py``
    and the caller — not here.

    Usage telemetry sidechannel
    ---------------------------
    Every adapter exposes an instance-scoped :attr:`last_usage`
    attribute (initialised to ``None`` in ``__init__``). After a
    successful :meth:`generate` returns, or after a
    :meth:`generate_stream` iterator has been fully drained, the
    adapter populates ``last_usage`` with a :class:`UsageStats`
    snapshot for the call that just finished. Providers that cannot
    produce usage data (Ollama, OpenAI-compat gateways that suppress
    it) leave ``last_usage`` at ``None`` indefinitely.

    Telemetry extraction is always wrapped in ``try``/``except``;
    failure to parse usage must NEVER fail the underlying LLM call.
    On error the attribute stays at whatever the previous call left
    it (adapters do not clear it to avoid racing with concurrent
    readers). Consumers that care about per-call ordering should
    read ``last_usage`` immediately after :meth:`generate` returns
    or after :meth:`generate_stream` exits.
    """

    name: str
    last_usage: UsageStats | None

    async def generate(
        self,
        messages: list[dict[str, str]],
        policy: ModelPolicy,
    ) -> str:
        """Run one completion and return the assistant text.

        Raises
        ------
        ProviderError
            On any failure (missing API key, network error, non-2xx
            response, empty payload, parse error).
        """
        ...

    async def generate_with_tools(
        self,
        messages: list[dict[str, Any]],
        policy: ModelPolicy,
        tools: list[ToolSpec],
    ) -> ProviderResponse:
        """Run one completion that may emit native tool_calls.

        Contract:

        - ``tools=[]`` is equivalent to :meth:`generate` wrapped in
          a :class:`ProviderResponse` — providers SHOULD still call
          the tool-aware SDK path so that a provider's ``stop_reason``
          is reported consistently; they MAY degrade to the text-only
          path on older SDK versions.
        - ``messages`` may carry Anthropic-style ``tool_result``
          blocks (``role=tool``, ``content=[{"type":"tool_result",
          ...}]``) when the agent loop is on round ≥2; providers
          translate to their native history shape.

        Raises
        ------
        ProviderError
            On any failure (same contract as :meth:`generate`).
        """
        ...

    def generate_stream(
        self,
        messages: list[dict[str, str]],
        policy: ModelPolicy,
    ) -> AsyncIterator[str]:
        """Stream token-sized assistant text chunks.

        Yields plain ``str`` chunks (not SSE wire format, not dicts).
        The last chunk is the final tail; no sentinel. Consumers that
        want a final string concatenate all chunks.

        Declared as a regular method returning ``AsyncIterator[str]``
        (not ``async def``) so both ``async def`` async-generators
        and explicit ``AsyncIterator`` return types satisfy the
        Protocol without Protocol-variance complaints.

        Raises
        ------
        ProviderError
            On any failure — the iterator terminates on the first
            failure and does not emit partial error text.
        """
        ...
