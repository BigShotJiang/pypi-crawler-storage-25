# SPDX-License-Identifier: MIT
"""In-process local LLM provider — zero HTTP, zero subprocess.

This adapter is the persona-api side of the Sancio runtime directive
(MEMORY #98 + handoff 跑分5 §∞ rule #2): load GGUF weights directly
inside the FastAPI process so tool_call → tool_exec → tool_response
round-trips stay in local Python memory instead of transiting a
loopback HTTP split to an Ollama / llama-cpp-server sidecar.

Why this exists
---------------
Gemma 4 thinking-mode emits a ``<|tool_response>`` body block that
the HTTP split (persona-api :8500 ↔ llama-cpp server :9000) eats on
the SSE / chat-template boundary — the model sees the tool output
but loses it before the next reasoning turn, so it hallucinates.
Observed on GAIA task 7dd30055 (2026-04-23): three HTTP-path retries
gave 1.261 / 1.389 / 1.428 vs truth 1.456 — plausible paraphrases
built from the *first* partial tool response only.

Concinno 2.21.0 ships ``concinno.llm_runtime.InProcessLlamaCppBackend``
which owns the ``llama_cpp.Llama`` object in the same process. We
wrap it here in the ``LLMProvider`` async protocol so ``engine.py``
+ benchmark / agent_api / api endpoints can dispatch to it via the
unified :class:`persona.providers.ProviderRegistry` without learning a
new call shape.

Optional multimodal
-------------------
When ``CONCINNO_LLM_VISION_GGUF_PATH`` is set we put a
:class:`concinno.llm_runtime.MultimodalRouter` in front of the text
backend; image / audio messages transparently route to a vision- or
audio-capable backend co-resident in the same process. Tool-call
support is text-only (no vision model we ship emits ``tool_calls``),
so :meth:`generate_with_tools` always targets the text backend
directly.
"""

from __future__ import annotations

import asyncio
import json
import os
from collections.abc import AsyncIterator
from typing import Any

from .base import (
    LLMProvider,
    ModelPolicy,
    ProviderError,
    ProviderResponse,
    ToolCallRequest,
    ToolSpec,
    UsageStats,
)
from .openai import _OAI_STOP_MAP, _openai_messages_with_tools


def _split_system(
    messages: list[dict[str, Any]],
) -> tuple[str, list[dict[str, Any]]]:
    """Peel the leading ``role=system`` turn off a chat history.

    The in-process backend signature takes ``system`` + ``messages``
    as separate args (mirroring llama-cpp's own chat template
    contract), whereas the persona providers pass a merged list with
    the system block at index 0. If no system message is present the
    system string is empty and the full list rides through unchanged.
    """
    if messages and messages[0].get("role") == "system":
        raw = messages[0].get("content", "")
        system = raw if isinstance(raw, str) else json.dumps(raw, default=str)
        return system, list(messages[1:])
    return "", list(messages)


class LocalInProcessProvider(LLMProvider):
    """Async ``LLMProvider`` wrapping :class:`InProcessLlamaCppBackend`.

    The backend is sync (``llama_cpp.Llama.create_chat_completion``
    holds the GIL through generation and takes a per-instance lock to
    serialise concurrent generates). We bridge to async via
    :meth:`asyncio.loop.run_in_executor` — one OS thread per concurrent
    request, with the backend's own ``_generate_lock`` naturally
    throttling to one in-flight generate. Throughput under load is
    capped at the single-model-per-process ceiling; shards across
    multiple GPUs need multiple provider instances.

    ``last_usage`` stays ``None`` — llama-cpp does expose token counts
    in its response dict but the shape diverges from the OpenAI usage
    envelope and we have no downstream consumer for it yet (Ollama
    path also leaves last_usage None). Telemetry upgrade is a
    follow-up, not a blocker.
    """

    name = "local_inproc"

    def __init__(
        self,
        backend: Any = None,
        *,
        router: Any = None,
        model_path: str | None = None,
        n_ctx: int | None = None,
        n_gpu_layers: int | None = None,
        flash_attn: bool | None = None,
        chat_format: str | None = None,
        clip_model_path: str | None = None,
    ) -> None:
        # Two-backend construction modes:
        #   1. Injected ``backend`` / ``router`` (tests pass fakes).
        #   2. Lazy construct from kwargs + env on first call.
        self._backend = backend
        self._router = router
        self._init_kwargs = {
            "model_path": model_path,
            "n_ctx": n_ctx,
            "n_gpu_layers": n_gpu_layers,
            "flash_attn": flash_attn,
            "chat_format": chat_format,
            "clip_model_path": clip_model_path,
        }
        self.last_usage: UsageStats | None = None

    def _ensure_backend(self) -> Any:
        """Return the text backend, lazy-constructing on first call."""
        if self._backend is not None:
            return self._backend
        if self._router is not None:
            return self._router._text  # type: ignore[attr-defined]
        try:
            from concinno.llm_runtime.in_process import (
                InProcessLlamaCppBackend,
            )
        except ImportError as exc:
            raise ProviderError(
                self.name,
                "concinno.llm_runtime unavailable — "
                "pip install concinno>=2.21.0",
            ) from exc
        kwargs = {k: v for k, v in self._init_kwargs.items() if v is not None}
        self._backend = InProcessLlamaCppBackend(**kwargs)
        return self._backend

    def _ensure_router(self) -> Any | None:
        """Return the multimodal router if vision is configured, else None.

        We only instantiate when ``CONCINNO_LLM_VISION_GGUF_PATH`` is
        set — a text-only deploy does not pay the router construction
        cost. The router itself lazy-loads vision weights, so even
        with the env var set the vision GGUF does not hit VRAM until
        an image message actually arrives.
        """
        if self._router is not None:
            return self._router
        if not os.environ.get("CONCINNO_LLM_VISION_GGUF_PATH"):
            return None
        try:
            from concinno.llm_runtime.multimodal_router import (
                MultimodalRouter,
            )
        except ImportError:
            return None
        text = self._ensure_backend()
        self._router = MultimodalRouter(text_backend=text)
        return self._router

    async def generate(
        self,
        messages: list[dict[str, str]],
        policy: ModelPolicy,
    ) -> str:
        """Run one text completion. Image content routes through
        :class:`MultimodalRouter` when vision is configured; tool
        calls are NOT produced on this path (use
        :meth:`generate_with_tools`)."""
        router = self._ensure_router()
        backend = router if router is not None else self._ensure_backend()
        system, rest = _split_system(list(messages))

        def _call() -> str:
            return backend.chat(
                system=system,
                messages=rest,
                max_tokens=policy.max_tokens,
                temperature=policy.temperature,
            )

        try:
            result = await asyncio.get_running_loop().run_in_executor(
                None, _call,
            )
        except Exception as exc:  # noqa: BLE001 — normalise to ProviderError
            raise ProviderError(self.name, f"backend: {exc}") from exc
        text = (result or "").strip()
        if not text:
            raise ProviderError(self.name, "empty response")
        return text

    async def generate_with_tools(
        self,
        messages: list[dict[str, Any]],
        policy: ModelPolicy,
        tools: list[ToolSpec],
    ) -> ProviderResponse:
        """Tool-aware completion via ``backend.chat_with_tools``.

        The backend returns the raw ``choices[0]`` dict — we pick it
        apart the same way :class:`OpenAICompatProvider` does so the
        agent loop sees identical :class:`ProviderResponse` shape
        regardless of whether Ollama HTTP or local in-process is on
        the wire. The critical difference: ``tool_calls`` content
        never transits JSON-over-HTTP, so the Gemma 4 thinking-mode
        ``<|tool_response>`` strip that kills 7dd30055 on HTTP stays
        out of the picture entirely.
        """
        backend = self._ensure_backend()
        # Translate Anthropic-shaped / fetch_image-tagged history into
        # OpenAI-compat wire shape — same contract as OpenAI /
        # OpenAICompat providers so a benchmark switching ``provider``
        # keyword alone gets identical message framing.
        oai_messages = _openai_messages_with_tools(messages)
        system, rest = _split_system(oai_messages)
        oai_tools = [
            {
                "type": "function",
                "function": {
                    "name": t.name,
                    "description": t.description,
                    "parameters": t.input_schema,
                },
            }
            for t in tools
        ] if tools else None

        def _call() -> dict[str, Any]:
            return backend.chat_with_tools(
                system=system,
                messages=rest,
                tools=oai_tools,
                max_tokens=policy.max_tokens,
                temperature=policy.temperature,
            )

        try:
            choice = await asyncio.get_running_loop().run_in_executor(
                None, _call,
            )
        except Exception as exc:  # noqa: BLE001 — normalise
            raise ProviderError(self.name, f"backend: {exc}") from exc

        try:
            msg = choice["message"]
        except (KeyError, TypeError) as exc:
            raise ProviderError(self.name, f"parse: {exc}") from exc

        raw_content = msg.get("content")
        text = raw_content.strip() if isinstance(raw_content, str) else None
        if text == "":
            text = None

        tool_calls: list[ToolCallRequest] = []
        for tc in msg.get("tool_calls") or []:
            fn = tc.get("function") or {}
            raw_args = fn.get("arguments", "{}")
            if isinstance(raw_args, str):
                try:
                    parsed = json.loads(raw_args)
                except ValueError:
                    parsed = {"_raw": raw_args}
            else:
                parsed = raw_args or {}
            tool_calls.append(
                ToolCallRequest(
                    id=tc.get("id") or f"call_{len(tool_calls)}",
                    name=fn.get("name", ""),
                    input=parsed if isinstance(parsed, dict) else {
                        "_value": parsed,
                    },
                ),
            )

        raw_stop = choice.get("finish_reason") or ""
        return ProviderResponse(
            text=text,
            tool_calls=tool_calls,
            stop_reason=_OAI_STOP_MAP.get(raw_stop, raw_stop),
            usage={},
        )

    async def generate_stream(
        self,
        messages: list[dict[str, str]],
        policy: ModelPolicy,
    ) -> AsyncIterator[str]:
        """Pseudo-stream: run the full completion then yield it as one chunk.

        ``llama_cpp.Llama.create_chat_completion`` supports
        ``stream=True`` but that surface is sync-generator and threads
        poorly through ``run_in_executor``. Until a proper
        async-generator bridge lands we give the caller a single chunk
        containing the full text — preserves the :meth:`chat_stream`
        contract (yields ``str``, terminates on full response) without
        lying about intermediate deltas.
        """
        text = await self.generate(messages, policy)
        if text:
            yield text
