# SPDX-License-Identifier: MIT
"""Concinno King messaging registry — single dispatcher for 20+ platforms.

Each :class:`PlatformInfo` describes a platform adapter forked from
Lyceum / Hermes Agent. The registry is **import-free** at module load:
``list_platforms()`` returns metadata only and never imports adapter
modules, so listing the messaging surface works even if optional
dependencies (``python-telegram-bot``, ``discord.py``, ``slack-sdk`` …)
are not installed.

Active platforms can be filtered via the env var
``CONCINNO_KING_MESSAGING_PLATFORMS=telegram,discord`` (comma-separated)
so a deployment loads only the adapters it actually needs.

The full upstream :class:`gateway.platform_registry.PlatformRegistry`
(re-exported from :mod:`concinno_king.messaging.platform_registry`)
remains the canonical runtime registry once adapters are loaded; this
module is the **lightweight catalogue** layered on top.
"""

from __future__ import annotations

import importlib
import os
from dataclasses import dataclass, field
from typing import Callable, Optional


@dataclass(frozen=True)
class PlatformInfo:
    """Static metadata for a forked Lyceum messaging platform.

    Attributes:
        name: Stable identifier used in config / env (lowercase snake).
        label: Human-readable display name.
        emoji: Display emoji for CLI / dashboard.
        module: Dotted import path of the adapter module (lazily imported).
        adapter_class: Adapter class name inside ``module``.
        check_fn: Name of the ``check_<platform>_requirements`` function
            in ``module``. Empty string means the platform skips deps
            preflight (e.g. ``api_server`` runs purely on stdlib).
        env_vars: Required environment variable names for setup.
        install_hint: Pip install hint for missing optional deps.
        upstream: Provenance — always ``"lyceum/hermes"`` for the
            initial port. Future native platforms set their own value.
    """

    name: str
    label: str
    emoji: str
    module: str
    adapter_class: str
    check_fn: str = ""
    env_vars: tuple[str, ...] = field(default_factory=tuple)
    install_hint: str = ""
    upstream: str = "lyceum/hermes"


# ─── Platform catalogue ───────────────────────────────────────────────────────
# Source-of-truth for which 20 platforms shipped in this monorepo. Entries
# are sorted alphabetically by ``name`` for stable diffs.
_PLATFORMS: tuple[PlatformInfo, ...] = (
    PlatformInfo(
        name="api_server",
        label="Generic HTTP API",
        emoji="🌐",
        module="concinno_king.messaging.platforms.api_server",
        adapter_class="APIServerAdapter",
        check_fn="check_api_server_requirements",
        env_vars=("API_SERVER_PORT", "API_SERVER_TOKEN"),
    ),
    PlatformInfo(
        name="bluebubbles",
        label="BlueBubbles (iMessage relay)",
        emoji="💬",
        module="concinno_king.messaging.platforms.bluebubbles",
        adapter_class="BlueBubblesAdapter",
        check_fn="check_bluebubbles_requirements",
        env_vars=("BLUEBUBBLES_URL", "BLUEBUBBLES_PASSWORD"),
        install_hint="pip install httpx websockets",
    ),
    PlatformInfo(
        name="dingtalk",
        label="DingTalk (钉钉)",
        emoji="📞",
        module="concinno_king.messaging.platforms.dingtalk",
        adapter_class="DingTalkAdapter",
        check_fn="check_dingtalk_requirements",
        env_vars=("DINGTALK_APP_KEY", "DINGTALK_APP_SECRET"),
    ),
    PlatformInfo(
        name="discord",
        label="Discord",
        emoji="🎮",
        module="concinno_king.messaging.platforms.discord",
        adapter_class="DiscordAdapter",
        check_fn="check_discord_requirements",
        env_vars=("DISCORD_BOT_TOKEN",),
        install_hint="pip install discord.py",
    ),
    PlatformInfo(
        name="email",
        label="Email (IMAP/SMTP)",
        emoji="📧",
        module="concinno_king.messaging.platforms.email",
        adapter_class="EmailAdapter",
        check_fn="check_email_requirements",
        env_vars=("EMAIL_IMAP_HOST", "EMAIL_SMTP_HOST", "EMAIL_USER", "EMAIL_PASSWORD"),
    ),
    PlatformInfo(
        name="feishu",
        label="Feishu / Lark (飞书)",
        emoji="📨",
        module="concinno_king.messaging.platforms.feishu",
        adapter_class="FeishuAdapter",
        check_fn="check_feishu_requirements",
        env_vars=("FEISHU_APP_ID", "FEISHU_APP_SECRET"),
    ),
    PlatformInfo(
        name="homeassistant",
        label="Home Assistant",
        emoji="🏠",
        module="concinno_king.messaging.platforms.homeassistant",
        adapter_class="HomeAssistantAdapter",
        check_fn="check_ha_requirements",
        env_vars=("HA_URL", "HA_TOKEN"),
    ),
    PlatformInfo(
        name="matrix",
        label="Matrix",
        emoji="🔷",
        module="concinno_king.messaging.platforms.matrix",
        adapter_class="MatrixAdapter",
        check_fn="check_matrix_requirements",
        env_vars=("MATRIX_HOMESERVER", "MATRIX_USER", "MATRIX_PASSWORD"),
        install_hint="pip install matrix-nio",
    ),
    PlatformInfo(
        name="mattermost",
        label="Mattermost",
        emoji="💼",
        module="concinno_king.messaging.platforms.mattermost",
        adapter_class="MattermostAdapter",
        check_fn="check_mattermost_requirements",
        env_vars=("MATTERMOST_URL", "MATTERMOST_TOKEN"),
    ),
    PlatformInfo(
        name="qqbot",
        label="QQ Bot",
        emoji="🐧",
        module="concinno_king.messaging.platforms.qqbot.adapter",
        adapter_class="QQAdapter",
        check_fn="check_qq_requirements",
        env_vars=("QQ_APP_ID", "QQ_APP_SECRET"),
    ),
    PlatformInfo(
        name="signal",
        label="Signal",
        emoji="🔒",
        module="concinno_king.messaging.platforms.signal",
        adapter_class="SignalAdapter",
        check_fn="check_signal_requirements",
        env_vars=("SIGNAL_PHONE_NUMBER",),
        install_hint="install signal-cli",
    ),
    PlatformInfo(
        name="slack",
        label="Slack",
        emoji="💬",
        module="concinno_king.messaging.platforms.slack",
        adapter_class="SlackAdapter",
        check_fn="check_slack_requirements",
        env_vars=("SLACK_BOT_TOKEN", "SLACK_APP_TOKEN"),
        install_hint="pip install slack-sdk",
    ),
    PlatformInfo(
        name="sms",
        label="SMS (Twilio / generic)",
        emoji="📱",
        module="concinno_king.messaging.platforms.sms",
        adapter_class="SmsAdapter",
        check_fn="check_sms_requirements",
        env_vars=("TWILIO_ACCOUNT_SID", "TWILIO_AUTH_TOKEN", "TWILIO_PHONE_NUMBER"),
        install_hint="pip install twilio",
    ),
    PlatformInfo(
        name="telegram",
        label="Telegram",
        emoji="✈️",
        module="concinno_king.messaging.platforms.telegram",
        adapter_class="TelegramAdapter",
        check_fn="check_telegram_requirements",
        env_vars=("TELEGRAM_BOT_TOKEN",),
        install_hint="pip install python-telegram-bot",
    ),
    PlatformInfo(
        name="webhook",
        label="Generic Webhook",
        emoji="🪝",
        module="concinno_king.messaging.platforms.webhook",
        adapter_class="WebhookAdapter",
        check_fn="check_webhook_requirements",
        env_vars=("WEBHOOK_URL", "WEBHOOK_SECRET"),
    ),
    PlatformInfo(
        name="wecom",
        label="WeCom (企业微信)",
        emoji="🏢",
        module="concinno_king.messaging.platforms.wecom",
        adapter_class="WeComAdapter",
        check_fn="check_wecom_requirements",
        env_vars=("WECOM_CORP_ID", "WECOM_CORP_SECRET", "WECOM_AGENT_ID"),
    ),
    PlatformInfo(
        name="wecom_callback",
        label="WeCom Callback (企业微信回调)",
        emoji="🏢",
        module="concinno_king.messaging.platforms.wecom_callback",
        adapter_class="WecomCallbackAdapter",
        check_fn="check_wecom_callback_requirements",
        env_vars=(
            "WECOM_CALLBACK_TOKEN",
            "WECOM_CALLBACK_AES_KEY",
            "WECOM_CALLBACK_CORP_ID",
        ),
    ),
    PlatformInfo(
        name="weixin",
        label="WeChat Official Account (微信公众号)",
        emoji="💚",
        module="concinno_king.messaging.platforms.weixin",
        adapter_class="WeixinAdapter",
        check_fn="check_weixin_requirements",
        env_vars=("WEIXIN_APPID", "WEIXIN_APPSECRET", "WEIXIN_TOKEN"),
    ),
    PlatformInfo(
        name="whatsapp",
        label="WhatsApp",
        emoji="🟢",
        module="concinno_king.messaging.platforms.whatsapp",
        adapter_class="WhatsAppAdapter",
        check_fn="check_whatsapp_requirements",
        env_vars=("WHATSAPP_TOKEN", "WHATSAPP_PHONE_NUMBER_ID"),
    ),
    PlatformInfo(
        name="yuanbao",
        label="Yuanbao (腾讯元宝)",
        emoji="💎",
        module="concinno_king.messaging.platforms.yuanbao",
        adapter_class="YuanbaoAdapter",
        check_fn="",
        env_vars=("YUANBAO_COOKIE",),
    ),
)


# ─── Public API ───────────────────────────────────────────────────────────────


def list_platforms() -> list[PlatformInfo]:
    """Return all known platforms (no import side effects)."""
    return list(_PLATFORMS)


def list_platform_names() -> list[str]:
    """Return platform names sorted alphabetically."""
    return sorted(p.name for p in _PLATFORMS)


def active_platform_names() -> list[str]:
    """Return platforms enabled by env ``CONCINNO_KING_MESSAGING_PLATFORMS``.

    When the env var is unset or empty, **all** platforms are considered
    active (turnkey default, matching Hermes Agent ergonomics). Otherwise
    only the comma-separated subset is returned, intersected with known
    platform names so typos do not silently widen the surface.
    """
    raw = os.environ.get("CONCINNO_KING_MESSAGING_PLATFORMS", "").strip()
    if not raw:
        return list_platform_names()
    requested = {p.strip().lower() for p in raw.split(",") if p.strip()}
    known = {p.name for p in _PLATFORMS}
    return sorted(requested & known)


def get_platform(name: str) -> Optional[PlatformInfo]:
    """Return metadata for ``name`` or ``None`` if unknown."""
    name = (name or "").lower().strip()
    for p in _PLATFORMS:
        if p.name == name:
            return p
    return None


def load_adapter_class(name: str) -> Optional[type]:
    """Lazy-import the adapter class for ``name``.

    Returns ``None`` when the platform is unknown. Raises the underlying
    ``ImportError`` when the module exists but optional deps are missing
    — callers that want a soft check should use :func:`check_platform`.
    """
    info = get_platform(name)
    if info is None:
        return None
    mod = importlib.import_module(info.module)
    return getattr(mod, info.adapter_class)


def check_platform(name: str) -> tuple[bool, str]:
    """Run the platform's ``check_*_requirements`` and return ``(ok, hint)``.

    A platform whose ``check_fn`` is unset is reported as available
    (``ok=True``) since it has no optional dependency to verify.
    """
    info = get_platform(name)
    if info is None:
        return False, f"unknown platform '{name}'"
    if not info.check_fn:
        return True, ""
    try:
        mod = importlib.import_module(info.module)
        fn: Callable[[], bool] = getattr(mod, info.check_fn)
    except Exception as exc:
        return False, f"import failed: {exc}"
    try:
        ok = bool(fn())
    except Exception as exc:
        return False, f"check raised: {exc}"
    return ok, ("" if ok else info.install_hint)


__all__ = [
    "PlatformInfo",
    "list_platforms",
    "list_platform_names",
    "active_platform_names",
    "get_platform",
    "load_adapter_class",
    "check_platform",
]
