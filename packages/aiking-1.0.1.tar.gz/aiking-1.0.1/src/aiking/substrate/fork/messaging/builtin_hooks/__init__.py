# SPDX-License-Identifier: MIT
"""Built-in gateway hooks that are always registered."""
