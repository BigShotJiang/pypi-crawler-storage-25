# SPDX-License-Identifier: MIT
"""Concinno King messaging gateway — 20 forked platform adapters.

This package wraps the Lyceum / Hermes messaging gateway with a thin
Concinno King-specific surface. The runtime classes (``GatewayConfig``,
``SessionStore``, ``DeliveryRouter``) are re-exported from the original
modules; the new :mod:`concinno_king.messaging.registry` module is the
**catalogue layer** that lets callers enumerate / filter platforms
without paying the import cost of every adapter.

Provenance: see ``NOTICE`` next to this file. Upstream licence is MIT
(``../LICENSE-MIT-Hermes``).
"""

from __future__ import annotations

# ─── New catalogue layer (no import side effects) ─────────────────────────────
from .registry import (
    PlatformInfo,
    active_platform_names,
    check_platform,
    get_platform,
    list_platform_names,
    list_platforms,
    load_adapter_class,
)

# ─── Upstream runtime registry (re-export) ────────────────────────────────────
# This is the runtime registry that adapters self-register against once
# imported. Keep the singleton accessible at the top of the package so
# callers using the upstream Lyceum API ergonomics still work.
from .platform_registry import PlatformEntry, PlatformRegistry, platform_registry

# ─── Upstream typed surfaces — imported lazily on attribute access ───────────
# We avoid importing config / session / delivery at module load because
# they pull lyceum_cli.config which currently lives behind a compat shim.
# Callers that need them can ``from aiking.substrate.fork.messaging import
# GatewayConfig`` and ``__getattr__`` will resolve it on demand.
_LAZY_EXPORTS: dict[str, tuple[str, str]] = {
    "GatewayConfig": (".config", "GatewayConfig"),
    "PlatformConfig": (".config", "PlatformConfig"),
    "HomeChannel": (".config", "HomeChannel"),
    "load_gateway_config": (".config", "load_gateway_config"),
    "SessionContext": (".session", "SessionContext"),
    "SessionStore": (".session", "SessionStore"),
    "SessionResetPolicy": (".session", "SessionResetPolicy"),
    "build_session_context_prompt": (".session", "build_session_context_prompt"),
    "DeliveryRouter": (".delivery", "DeliveryRouter"),
    "DeliveryTarget": (".delivery", "DeliveryTarget"),
}


def __getattr__(name: str):
    """Lazy import for upstream runtime symbols.

    Keeps ``concinno-king messaging list`` cheap (no adapter imports)
    while still allowing ``from aiking.substrate.fork.messaging import
    GatewayConfig`` for full runtime callers.
    """
    if name in _LAZY_EXPORTS:
        import importlib

        modpath, attr = _LAZY_EXPORTS[name]
        mod = importlib.import_module(modpath, __name__)
        value = getattr(mod, attr)
        globals()[name] = value  # cache for subsequent lookups
        return value
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    # New catalogue layer
    "PlatformInfo",
    "list_platforms",
    "list_platform_names",
    "active_platform_names",
    "get_platform",
    "load_adapter_class",
    "check_platform",
    # Upstream runtime registry
    "PlatformEntry",
    "PlatformRegistry",
    "platform_registry",
    # Lazy upstream surfaces (resolved via __getattr__)
    "GatewayConfig",
    "PlatformConfig",
    "HomeChannel",
    "load_gateway_config",
    "SessionContext",
    "SessionStore",
    "SessionResetPolicy",
    "build_session_context_prompt",
    "DeliveryRouter",
    "DeliveryTarget",
]
