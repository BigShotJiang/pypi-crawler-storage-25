# SPDX-License-Identifier: MIT
"""Concinno King shared constants — ported from Lyceum ``lyceum_constants``.

This module preserves the original public function names
(``get_lyceum_home``, ``get_lyceum_dir``, ``display_lyceum_home``, ...)
because the forked messaging adapters reference them by name. The
underlying environment variable is renamed to ``CONCINNO_KING_HOME``
(falling back to legacy ``LYCEUM_HOME`` for migration), and the default
home directory becomes ``~/.concinno-king`` instead of ``~/.lyceum``.

Import-safe — no dependencies beyond stdlib.
"""

from __future__ import annotations

import os
from pathlib import Path


# ─── Home directory resolution ────────────────────────────────────────────────

_DEFAULT_HOME_DIRNAME = ".concinno-king"
_LEGACY_HOME_DIRNAME = ".lyceum"


def _read_home_env() -> str:
    """Return the configured home dir env override, or ''.

    Honors ``CONCINNO_KING_HOME`` first, then falls back to ``LYCEUM_HOME``
    so existing Lyceum installs migrate without re-configuring.
    """
    val = os.environ.get("CONCINNO_KING_HOME", "").strip()
    if val:
        return val
    return os.environ.get("LYCEUM_HOME", "").strip()


def get_lyceum_home() -> Path:
    """Return the Concinno King home directory.

    Default: ``~/.concinno-king``. Override with ``CONCINNO_KING_HOME``
    or legacy ``LYCEUM_HOME`` env vars.

    Function name kept as ``get_lyceum_home`` to match the upstream
    forked-adapter call sites; consider this the canonical accessor.
    """
    val = _read_home_env()
    return Path(val) if val else Path.home() / _DEFAULT_HOME_DIRNAME


def get_default_lyceum_root() -> Path:
    """Return the root profile directory (analogue of upstream behaviour)."""
    native_home = Path.home() / _DEFAULT_HOME_DIRNAME
    env_home = _read_home_env()
    if not env_home:
        return native_home
    env_path = Path(env_home)
    try:
        env_path.resolve().relative_to(native_home.resolve())
        return native_home
    except ValueError:
        pass
    if env_path.parent.name == "profiles":
        return env_path.parent.parent
    return env_path


def get_optional_skills_dir(default: Path | None = None) -> Path:
    override = os.getenv("CONCINNO_KING_OPTIONAL_SKILLS", "").strip() or os.getenv(
        "LYCEUM_OPTIONAL_SKILLS", ""
    ).strip()
    if override:
        return Path(override)
    if default is not None:
        return default
    return get_lyceum_home() / "optional-skills"


def get_lyceum_dir(new_subpath: str, old_name: str) -> Path:
    home = get_lyceum_home()
    old_path = home / old_name
    if old_path.exists():
        return old_path
    return home / new_subpath


def display_lyceum_home() -> str:
    home = get_lyceum_home()
    try:
        return "~/" + str(home.relative_to(Path.home()))
    except ValueError:
        return str(home)


def get_subprocess_home() -> str | None:
    home = _read_home_env()
    if not home:
        return None
    profile_home = os.path.join(home, "home")
    if os.path.isdir(profile_home):
        return profile_home
    return None


# ─── Reasoning effort ─────────────────────────────────────────────────────────

VALID_REASONING_EFFORTS = ("minimal", "low", "medium", "high", "xhigh")


def parse_reasoning_effort(effort: str) -> dict | None:
    if not effort or not effort.strip():
        return None
    effort = effort.strip().lower()
    if effort == "none":
        return {"enabled": False}
    if effort in VALID_REASONING_EFFORTS:
        return {"enabled": True, "effort": effort}
    return None


# ─── Environment detection ────────────────────────────────────────────────────


def is_termux() -> bool:
    prefix = os.getenv("PREFIX", "")
    return bool(os.getenv("TERMUX_VERSION") or "com.termux/files/usr" in prefix)


_wsl_detected: bool | None = None


def is_wsl() -> bool:
    global _wsl_detected
    if _wsl_detected is not None:
        return _wsl_detected
    try:
        with open("/proc/version", "r") as f:
            _wsl_detected = "microsoft" in f.read().lower()
    except Exception:
        _wsl_detected = False
    return _wsl_detected


_container_detected: bool | None = None


def is_container() -> bool:
    global _container_detected
    if _container_detected is not None:
        return _container_detected
    if os.path.exists("/.dockerenv"):
        _container_detected = True
        return True
    if os.path.exists("/run/.containerenv"):
        _container_detected = True
        return True
    try:
        with open("/proc/1/cgroup", "r") as f:
            cgroup = f.read()
            if "docker" in cgroup or "podman" in cgroup or "/lxc/" in cgroup:
                _container_detected = True
                return True
    except OSError:
        pass
    _container_detected = False
    return False


# ─── Well-known paths ─────────────────────────────────────────────────────────


def get_config_path() -> Path:
    return get_lyceum_home() / "config.yaml"


def get_skills_dir() -> Path:
    return get_lyceum_home() / "skills"


def get_env_path() -> Path:
    return get_lyceum_home() / ".env"


# ─── Network preferences ──────────────────────────────────────────────────────


def apply_ipv4_preference(force: bool = False) -> None:
    if not force:
        return
    import socket

    if getattr(socket.getaddrinfo, "_concinno_king_ipv4_patched", False):
        return

    _original_getaddrinfo = socket.getaddrinfo

    def _ipv4_getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
        if family == 0:
            try:
                return _original_getaddrinfo(
                    host, port, socket.AF_INET, type, proto, flags
                )
            except socket.gaierror:
                return _original_getaddrinfo(host, port, family, type, proto, flags)
        return _original_getaddrinfo(host, port, family, type, proto, flags)

    _ipv4_getaddrinfo._concinno_king_ipv4_patched = True  # type: ignore[attr-defined]
    socket.getaddrinfo = _ipv4_getaddrinfo  # type: ignore[assignment]


# ─── External provider URLs (kept for compat) ─────────────────────────────────

OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"
OPENROUTER_MODELS_URL = f"{OPENROUTER_BASE_URL}/models"
AI_GATEWAY_BASE_URL = "https://ai-gateway.vercel.sh/v1"
