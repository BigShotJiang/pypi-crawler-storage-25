# SPDX-License-Identifier: MIT
"""concinno-king.governance.curator — skill curator (Hermes-derived + ZIQ).

@module governance.curator
@responsibility Run a periodic background pass that maintains the
    skill collection at the agent-created skills layer:

    1. **Phase 1 — automatic transitions** (pure, no LLM, transcribed
       from Hermes/Lyceum ``agent/curator.py``): walk every
       agent-created skill and move ``active → stale`` after 30 days
       of inactivity, ``stale → archived`` after 90, and reactivate
       previously-stale skills that just got used again.
    2. **Phase 2 — LLM umbrella merge** (Hermes UMBRELLA-BUILDING
       prompt, transcribed verbatim modulo product naming): a fork of
       the configured aux model reviews the survivors and proposes
       merges into class-level umbrellas with ``references/`` /
       ``templates/`` / ``scripts/`` demotion paths.
    3. **Phase 3 — ZIQ posterior pass** (Concinno-novel improvement):
       after the LLM pass settles, score every survivor against a
       pool of historic queries via :func:`compute_skill_route` and
       persist the routing weights to
       ``~/.concinno-king/ziq_curator_state/`` so the next agent loop
       reads posterior-tuned routing instead of unbiased SPS.

    Triggers (any of):

    * idle ≥ ``min_idle_hours`` AND last run ≥ ``interval_hours`` ago
      — the Hermes legacy gate.
    * **new in concinno-king**: ``new-add ≥ 3`` agent-created skills
      since last run, regardless of interval — keeps the umbrella
      pass close to the moment new clusters form.

@dependencies
    * :mod:`governance.ziq_routing` for the ZIQ posterior layer.
    * Optional: ``concinno.ziq_persist`` (live FTRL state).
    * Optional: an LLM-call adapter passed in by the caller — this
      module exposes a hook (``llm_runner`` callable) but does not
      hard-import any LLM client. The default runner is a no-op that
      returns an empty review, which keeps Phase 1 + Phase 3 fully
      functional in CI / smoke contexts without API keys.

@exports apply_automatic_transitions, run_curator_review,
    maybe_run_curator, should_run_now, tick, load_state, save_state,
    set_paused, is_paused, is_enabled, CURATOR_REVIEW_PROMPT,
    SkillRow, register_skill_provider

NOTICE
------
* Phase 1 staleness algorithm + ``CURATOR_REVIEW_PROMPT`` body
  transcribed from Hermes/Lyceum ``agent/curator.py`` (MIT licence,
  © 2026 Hermes Labs / Lyceum). Functional copy with product names
  rewritten to ``concinno-king`` and the Lyceum-specific ``skill_usage``
  / ``run_agent.AIAgent`` plumbing replaced with a pluggable
  ``SkillProvider`` / ``llm_runner`` callable so the file is
  vendor-neutral.
* Phase 3 ZIQ posterior layer is Concinno AGPL/commercial dual,
  © 2026 AI King. Salvaged from the deleted
  ``concinno.skills.disclosure`` module.
"""

from __future__ import annotations

import json
import logging
import os
import tempfile
import threading
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Optional

from .ziq_routing import (
    DEFAULT_FTRL_FEATURE,
    DEFAULT_MIN_ROUTE_SCORE,
    DEFAULT_TOP_K,
    FtrlReader,
    SkillCandidate,
    compute_skill_route,
    write_routing_weights,
)

# GEPA skill optimiser — wires Concinno-novel evolution layer on top of
# the Hermes-derived Phase 2 umbrella merge. Optional: a minimal install
# without the evolution package silently skips the GEPA refine step.
# Fixes ai-king MEMORY #4d (no production caller = arch island).
try:  # pragma: no cover - import guard
    from aiking.substrate.fork.evolution.gepa_skill import (  # type: ignore[import-not-found]
        SkillGEPAOptimizer,
    )
    from aiking.substrate.fork.evolution.gepa_skill import (
        ToolCall as _GepaToolCall,  # type: ignore[import-not-found]
    )

    _GEPA_AVAILABLE = True
except ImportError:  # pragma: no cover - degraded mode
    SkillGEPAOptimizer = None  # type: ignore[assignment,misc]
    _GepaToolCall = None  # type: ignore[assignment,misc]
    _GEPA_AVAILABLE = False

logger = logging.getLogger(__name__)

__all__ = [
    "CURATOR_REVIEW_PROMPT",
    "DEFAULT_ARCHIVE_AFTER_DAYS",
    "DEFAULT_INTERVAL_HOURS",
    "DEFAULT_MIN_IDLE_HOURS",
    "DEFAULT_NEW_ADD_TRIGGER",
    "DEFAULT_STALE_AFTER_DAYS",
    "STATE_ACTIVE",
    "STATE_ARCHIVED",
    "STATE_STALE",
    "SkillRow",
    "apply_automatic_transitions",
    "is_enabled",
    "is_paused",
    "load_state",
    "maybe_run_curator",
    "register_skill_provider",
    "run_curator_review",
    "save_state",
    "set_paused",
    "should_run_now",
    "tick",
]

# ── defaults (mirror Hermes Lyceum + adds new-add trigger) ────────────────

DEFAULT_INTERVAL_HOURS = 24 * 7
DEFAULT_MIN_IDLE_HOURS = 2.0
DEFAULT_STALE_AFTER_DAYS = 30
DEFAULT_ARCHIVE_AFTER_DAYS = 90
DEFAULT_NEW_ADD_TRIGGER = 3  # new-add since last run → run regardless of interval

STATE_ACTIVE = "active"
STATE_STALE = "stale"
STATE_ARCHIVED = "archived"


# ── home / state file ─────────────────────────────────────────────────────


def _state_root() -> Path:
    override = os.environ.get("CONCINNO_KING_STATE_DIR", "").strip()
    if override:
        return Path(override).expanduser()
    return Path.home() / ".concinno-king"


def _state_file() -> Path:
    return _state_root() / "curator_state.json"


def _default_state() -> dict[str, Any]:
    return {
        "last_run_at": None,
        "last_run_duration_seconds": None,
        "last_run_summary": None,
        "last_report_path": None,
        "paused": False,
        "run_count": 0,
        "skill_count_at_last_run": 0,
    }


def load_state() -> dict[str, Any]:
    """Read the curator's persistent scheduler state.

    Falls back to the default state on missing file / parse error so a
    corrupt state file never blocks a run; the next save will replace it.
    """
    path = _state_file()
    if not path.exists():
        return _default_state()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            base = _default_state()
            base.update({k: v for k, v in data.items() if k in base or k.startswith("_")})
            return base
    except (OSError, json.JSONDecodeError) as e:
        logger.debug("Failed to read curator state: %s", e)
    return _default_state()


def save_state(data: dict[str, Any]) -> None:
    """Atomically persist curator state (temp + ``os.replace``)."""
    path = _state_file()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(
            dir=str(path.parent), prefix=".curator_state_", suffix=".tmp"
        )
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, sort_keys=True, ensure_ascii=False)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, path)
        except BaseException:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise
    except Exception as e:  # noqa: BLE001 - defensive
        logger.debug("Failed to save curator state: %s", e, exc_info=True)


def set_paused(paused: bool) -> None:
    state = load_state()
    state["paused"] = bool(paused)
    save_state(state)


def is_paused() -> bool:
    return bool(load_state().get("paused"))


def is_enabled() -> bool:
    """Default ON; env ``CONCINNO_KING_CURATOR_DISABLED=1`` opts out."""
    raw = os.environ.get("CONCINNO_KING_CURATOR_DISABLED", "").strip().lower()
    if raw in {"1", "true", "yes", "on"}:
        return False
    return True


# ── skill-provider plug ───────────────────────────────────────────────────


@dataclass
class SkillRow:
    """Row schema returned by a registered :data:`SkillProvider`.

    Mirrors the Hermes ``skill_usage.agent_created_report()`` contract
    so the Phase 1 transition logic is line-for-line equivalent. Fields
    we don't actively use (``activity_count`` etc.) are kept so the
    curator can pass them through to the LLM candidate list.
    """

    name: str
    state: str = STATE_ACTIVE
    pinned: bool = False
    description: str = ""
    triggers: tuple[str, ...] = field(default_factory=tuple)
    last_activity_at: Optional[str] = None
    created_at: Optional[str] = None
    activity_count: int = 0
    use_count: int = 0
    view_count: int = 0
    patch_count: int = 0
    path: Optional[str] = None


SkillProvider = Callable[[], list[SkillRow]]
SkillStateSetter = Callable[[str, str], bool]
SkillArchiver = Callable[[str], bool]
LLMRunner = Callable[[str], dict[str, Any]]

_provider_lock = threading.RLock()
_skill_provider: Optional[SkillProvider] = None
_state_setter: Optional[SkillStateSetter] = None
_archiver: Optional[SkillArchiver] = None
_llm_runner: Optional[LLMRunner] = None


def register_skill_provider(
    provider: SkillProvider,
    *,
    state_setter: Optional[SkillStateSetter] = None,
    archiver: Optional[SkillArchiver] = None,
    llm_runner: Optional[LLMRunner] = None,
) -> None:
    """Wire the curator to a host's skill registry / LLM client.

    Concinno-king ships a default no-op provider so that
    ``governance.curator.tick()`` is safe to call without a registry —
    the function returns ``"no candidates"`` and exits clean. Hosts
    that want a real curation pass call this once at startup with:

    * ``provider`` — returns the current agent-created skill set.
    * ``state_setter(name, state)`` — flip ``stale``/``active`` state.
      Returns ``True`` on success.
    * ``archiver(name)`` — move a skill to ``.archive/``. Returns
      ``True`` on success.
    * ``llm_runner(prompt)`` — execute the umbrella-merge prompt.
      Returns ``{"final": str, "summary": str, "tool_calls": list}``.
      Pass ``None`` to leave Phase 2 disabled (Phase 1 + Phase 3 still
      run).
    """
    global _skill_provider, _state_setter, _archiver, _llm_runner
    with _provider_lock:
        _skill_provider = provider
        _state_setter = state_setter
        _archiver = archiver
        _llm_runner = llm_runner


def _get_provider() -> SkillProvider:
    with _provider_lock:
        return _skill_provider or _empty_provider


def _empty_provider() -> list[SkillRow]:
    return []


def _no_op_state_setter(name: str, state: str) -> bool:
    logger.debug("curator: no state_setter wired; skipping %s -> %s", name, state)
    return False


def _no_op_archiver(name: str) -> bool:
    logger.debug("curator: no archiver wired; skipping archive of %s", name)
    return False


# ── timestamp helpers ─────────────────────────────────────────────────────


def _parse_iso(ts: Optional[str]) -> Optional[datetime]:
    if not ts:
        return None
    try:
        return datetime.fromisoformat(ts)
    except (TypeError, ValueError):
        return None


# ── interval / idle gates ─────────────────────────────────────────────────


def should_run_now(
    *,
    now: Optional[datetime] = None,
    skill_count_now: Optional[int] = None,
) -> bool:
    """Return ``True`` if the curator should run immediately.

    Gates (transcribed from Hermes Lyceum + the new-add trigger):

    * ``is_enabled()`` is True.
    * not paused.
    * **new-add trigger (concinno-king-novel)**: when
      ``skill_count_now`` is provided and exceeds
      ``state['skill_count_at_last_run']`` by ``DEFAULT_NEW_ADD_TRIGGER``
      or more, the interval gate is bypassed.
    * otherwise interval gate: ``last_run_at`` missing OR older than
      ``DEFAULT_INTERVAL_HOURS``.

    Idle gating is enforced at the call site (we don't measure
    user-idle here).
    """
    if not is_enabled():
        return False
    if is_paused():
        return False

    state = load_state()

    if skill_count_now is not None:
        prev = int(state.get("skill_count_at_last_run") or 0)
        delta = int(skill_count_now) - prev
        if delta >= DEFAULT_NEW_ADD_TRIGGER:
            return True

    last = _parse_iso(state.get("last_run_at"))
    if last is None:
        return True

    if now is None:
        now = datetime.now(timezone.utc)
    if last.tzinfo is None:
        last = last.replace(tzinfo=timezone.utc)

    interval = timedelta(hours=DEFAULT_INTERVAL_HOURS)
    return (now - last) >= interval


# ── Phase 1: pure auto-transitions ────────────────────────────────────────


def apply_automatic_transitions(
    *,
    now: Optional[datetime] = None,
    rows: Optional[list[SkillRow]] = None,
    state_setter: Optional[SkillStateSetter] = None,
    archiver: Optional[SkillArchiver] = None,
    stale_after_days: int = DEFAULT_STALE_AFTER_DAYS,
    archive_after_days: int = DEFAULT_ARCHIVE_AFTER_DAYS,
) -> dict[str, int]:
    """Walk every skill and move ``active``/``stale``/``archived`` based
    on the latest real activity timestamp.

    Pinned skills are never touched. New skills that have never been
    used anchor on ``created_at`` so they don't immediately archive.
    Returns a counter dict ``{"checked", "marked_stale", "archived",
    "reactivated"}`` for the report.
    """
    if now is None:
        now = datetime.now(timezone.utc)
    stale_cutoff = now - timedelta(days=int(stale_after_days))
    archive_cutoff = now - timedelta(days=int(archive_after_days))

    setter = state_setter or _state_setter or _no_op_state_setter
    arch = archiver or _archiver or _no_op_archiver
    rows = rows if rows is not None else _get_provider()()

    counts = {"marked_stale": 0, "archived": 0, "reactivated": 0, "checked": 0}

    for row in rows:
        if not isinstance(row, SkillRow):
            continue
        counts["checked"] += 1
        if row.pinned:
            continue

        last_activity = _parse_iso(row.last_activity_at)
        anchor = last_activity or _parse_iso(row.created_at) or now
        if anchor.tzinfo is None:
            anchor = anchor.replace(tzinfo=timezone.utc)

        current = row.state or STATE_ACTIVE

        if anchor <= archive_cutoff and current != STATE_ARCHIVED:
            if arch(row.name):
                counts["archived"] += 1
        elif anchor <= stale_cutoff and current == STATE_ACTIVE:
            if setter(row.name, STATE_STALE):
                counts["marked_stale"] += 1
        elif anchor > stale_cutoff and current == STATE_STALE:
            if setter(row.name, STATE_ACTIVE):
                counts["reactivated"] += 1

    return counts


# ── Phase 2: Hermes umbrella prompt (transcribed verbatim) ────────────────


CURATOR_REVIEW_PROMPT = (
    "You are running as concinno-king's background skill CURATOR. This "
    "is an UMBRELLA-BUILDING consolidation pass, not a passive audit "
    "and not a duplicate-finder.\n\n"
    "The goal of the skill collection is a LIBRARY OF CLASS-LEVEL "
    "INSTRUCTIONS AND EXPERIENTIAL KNOWLEDGE. A collection of hundreds of "
    "narrow skills where each one captures one session's specific bug is "
    "a FAILURE of the library — not a feature. An agent searching skills "
    "matches on descriptions, not on exact names; one broad umbrella "
    "skill with labeled subsections beats five narrow siblings for "
    "discoverability, not the other way around.\n\n"
    "The right target shape is CLASS-LEVEL skills with rich SKILL.md "
    "bodies + `references/`, `templates/`, and `scripts/` subfiles for "
    "session-specific detail — not one-session-one-skill micro-entries.\n\n"
    "Hard rules — do not violate:\n"
    "1. DO NOT touch bundled or hub-installed skills. The candidate list "
    "below is already filtered to agent-created skills only.\n"
    "2. DO NOT delete any skill. Archiving is the maximum destructive "
    "action. Archives are recoverable; deletion is not.\n"
    "3. DO NOT touch skills shown as pinned=yes. Skip them entirely.\n"
    "4. DO NOT use usage counters as a reason to skip consolidation. The "
    "counters are new and often mostly zero. Judge overlap on CONTENT, "
    "not on use_count. 'use=0' is not evidence a skill is valuable; it's "
    "absence of evidence either way.\n"
    "5. DO NOT reject consolidation on the grounds that 'each skill has "
    "a distinct trigger'. Pairwise distinctness is the wrong bar. The "
    "right bar is: 'would a human maintainer write this as N separate "
    "skills, or as one skill with N labeled subsections?' When the "
    "answer is the latter, merge.\n\n"
    "How to work — not optional:\n"
    "1. Scan the full candidate list. Identify PREFIX CLUSTERS (skills "
    "sharing a first word or domain keyword). Expect 10-25 clusters.\n"
    "2. For each cluster with 2+ members, do NOT ask 'are these pairs "
    "overlapping?' — ask 'what is the UMBRELLA CLASS these skills all "
    "serve? Would a maintainer name that class and write one skill for "
    "it?' If yes, pick (or create) the umbrella and absorb the siblings "
    "into it.\n"
    "3. Three ways to consolidate — use the right one per cluster:\n"
    "   a. MERGE INTO EXISTING UMBRELLA — patch a sufficiently broad "
    "skill to add a labeled section for each sibling's unique insight, "
    "then archive the siblings.\n"
    "   b. CREATE A NEW UMBRELLA SKILL.md — no existing member is broad "
    "enough. Write a new class-level skill whose SKILL.md covers the "
    "shared workflow and has short labeled subsections. Archive the "
    "absorbed narrow siblings.\n"
    "   c. DEMOTE TO REFERENCES/TEMPLATES/SCRIPTS — narrow but valuable "
    "session-specific content goes under the umbrella's appropriate "
    "support directory.\n"
    "4. Iterate. After one consolidation round, scan the remaining set "
    "and look for the NEXT umbrella opportunity.\n\n"
    "When done, write a human summary AND a structured machine-readable "
    "block. Format EXACTLY:\n\n"
    "## Structured summary (required)\n"
    "```yaml\n"
    "consolidations:\n"
    "  - from: <old-skill-name>\n"
    "    into: <umbrella-skill-name>\n"
    "    reason: <one short sentence>\n"
    "prunings:\n"
    "  - name: <skill-name>\n"
    "    reason: <one short sentence>\n"
    "```\n\n"
    "Every skill you moved to .archive/ MUST appear in exactly one of "
    "the two lists. Leave a list empty (`consolidations: []`) if none. "
    "Do not omit the block."
)


def _render_candidate_list(rows: list[SkillRow]) -> str:
    """Human/agent-readable list of agent-created skills with usage stats."""
    if not rows:
        return "No agent-created skills to review."
    lines = [f"Agent-created skills ({len(rows)}):\n"]
    for r in rows:
        lines.append(
            f"- {r.name}  "
            f"state={r.state}  "
            f"pinned={'yes' if r.pinned else 'no'}  "
            f"activity={r.activity_count}  "
            f"use={r.use_count}  "
            f"view={r.view_count}  "
            f"patches={r.patch_count}  "
            f"last_activity={r.last_activity_at or 'never'}"
        )
    return "\n".join(lines)


# ── Phase 3: ZIQ posterior pass (Concinno-novel) ──────────────────────────


def _query_pool() -> list[str]:
    """Historic queries to score posterior weights against.

    Loads a JSONL file at ``$CONCINNO_KING_STATE_DIR/query_pool.jsonl``
    when present; one ``{"query": "..."}`` per line. Falls back to a
    minimal seed pool so cold-start curator passes still produce a
    non-trivial posterior table.
    """
    path = _state_root() / "query_pool.jsonl"
    if path.is_file():
        try:
            with path.open("r", encoding="utf-8") as fh:
                out: list[str] = []
                for line in fh:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        row = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if isinstance(row, dict):
                        q = row.get("query")
                        if isinstance(q, str) and q.strip():
                            out.append(q.strip())
                if out:
                    return out
        except OSError:
            pass
    # Cold-start seed pool. Keeps Phase 3 useful without a live history.
    return [
        "skill",
        "agent governance review",
        "code review",
    ]


def _run_ziq_posterior_pass(
    rows: list[SkillRow],
    *,
    state_dir_override: Optional[Path] = None,
    ftrl_feature: str = DEFAULT_FTRL_FEATURE,
) -> dict[str, Any]:
    """Score every survivor with the ZIQ posterior and persist weights.

    Returns a small audit dict; never raises (a bad write degrades the
    curator pass to "Phase 1 + Phase 2 only" — it does not fail the run).
    """
    if not rows:
        return {"queries": 0, "candidates": 0, "files_written": 0}

    candidates = [
        SkillCandidate(
            name=r.name,
            description=r.description,
            triggers=tuple(r.triggers or ()),
            path=Path(r.path) if r.path else None,
        )
        for r in rows
        if isinstance(r, SkillRow)
    ]
    if not candidates:
        return {"queries": 0, "candidates": 0, "files_written": 0}

    reader = FtrlReader(feature=ftrl_feature)
    pool = _query_pool()
    written_total = 0
    for q in pool:
        try:
            routes = compute_skill_route(
                q,
                candidates,
                top_k=DEFAULT_TOP_K,
                min_score=DEFAULT_MIN_ROUTE_SCORE,
                ftrl_reader=reader,
            )
        except Exception as e:  # noqa: BLE001 - defensive
            logger.debug("ZIQ route failed for query '%s': %s", q, e)
            continue
        if not routes:
            continue
        try:
            written_total += write_routing_weights(
                routes,
                query=q,
                state_dir=state_dir_override,
            )
        except Exception as e:  # noqa: BLE001 - defensive
            logger.debug("ZIQ write failed for query '%s': %s", q, e)

    return {
        "queries": len(pool),
        "candidates": len(candidates),
        "files_written": written_total,
    }


# ── Phase 2.5: GEPA refine ───────────────────────────────────────────────


def _gepa_refine_after_phase2(
    *,
    llm_meta: dict[str, Any],
    rows_after_phase1: list[Any],
) -> dict[str, Any]:
    """Run a GEPA description-rewrite pass on the merged umbrella(s).

    Best-effort by design: if the evolution package is missing, the
    LLM did not actually run, or the runner did not register a
    reflection callable, we return a structured "skipped" record
    rather than raising — matching how Phase 2 itself degrades.

    The hook expects the LLM runner to optionally attach a
    ``reflection_llm`` callable on its returned dict (via
    ``llm_meta["reflection_llm"]``). When absent we use a no-op
    reflector that just echoes the candidate — GEPA still runs but
    the search collapses to a single seed candidate, which is the
    correct behaviour when no LLM budget is available.
    """
    summary = "skipped"
    optimised_count = 0
    error: str | None = None
    skill_names: list[str] = []
    if not _GEPA_AVAILABLE or SkillGEPAOptimizer is None:
        return {
            "summary": "skipped (evolution package missing)",
            "optimised": 0,
            "skills": [],
            "error": None,
        }
    final_text = str(llm_meta.get("final") or "")
    if not final_text:
        return {
            "summary": "skipped (Phase 2 produced no final text)",
            "optimised": 0,
            "skills": [],
            "error": None,
        }
    # Pull umbrella names from the structured `consolidations:` block —
    # we only refine skills that the LLM actually merged into.
    umbrella_names = _extract_umbrella_names_from_summary(final_text)
    if not umbrella_names:
        return {
            "summary": "skipped (no consolidations in Phase 2 output)",
            "optimised": 0,
            "skills": [],
            "error": None,
        }
    reflector = llm_meta.get("reflection_llm")
    if not callable(reflector):
        reflector = lambda prompt: prompt  # noqa: E731 - degenerate reflector
    try:
        optimiser = SkillGEPAOptimizer(
            reflection_llm=reflector,
            budget=int(llm_meta.get("gepa_budget", 4) or 4),
        )
        for umbrella in umbrella_names[:8]:
            row = _find_skill_row(rows_after_phase1, umbrella)
            if row is None:
                continue
            seed_md = getattr(row, "description", "") or umbrella
            history = list(llm_meta.get("tool_calls") or [])
            usage_history = [
                _GepaToolCall(  # type: ignore[misc]
                    skill_name=umbrella,
                    matched=bool(call.get("matched", False))
                    if isinstance(call, dict)
                    else False,
                    query=str(call.get("query", "") or "")
                    if isinstance(call, dict)
                    else "",
                )
                for call in history
            ]
            optimiser.optimize_skill_description(
                skill_md=seed_md,
                usage_history=usage_history,
                skill_name=umbrella,
            )
            optimised_count += 1
            skill_names.append(umbrella)
        summary = f"optimised {optimised_count} umbrella(s)"
    except Exception as exc:  # noqa: BLE001 - never raise from curator
        error = str(exc)
        summary = f"error ({exc})"
    return {
        "summary": summary,
        "optimised": optimised_count,
        "skills": skill_names,
        "error": error,
    }


def _extract_umbrella_names_from_summary(text: str) -> list[str]:
    """Pull ``into:`` umbrella names from the YAML structured block."""
    names: list[str] = []
    for line in text.splitlines():
        s = line.strip()
        if s.startswith("into:"):
            value = s.split(":", 1)[1].strip().strip("\"'")
            if value and value not in names:
                names.append(value)
    return names


def _find_skill_row(rows: list[Any], name: str) -> Any | None:
    for row in rows:
        if getattr(row, "name", None) == name:
            return row
    return None


# ── orchestrator ──────────────────────────────────────────────────────────


def run_curator_review(
    *,
    on_summary: Optional[Callable[[str], None]] = None,
    synchronous: bool = True,
    state_dir_override: Optional[Path] = None,
) -> dict[str, Any]:
    """Execute one curator review pass and persist state.

    Phases:
        1. Apply automatic state transitions (pure, no LLM).
        2. If wired, run the LLM umbrella merge prompt.
        3. Run the ZIQ posterior pass and write
           ``~/.concinno-king/ziq_curator_state/<skill>.json``.
        4. Update the persistent state with the run summary.

    ``synchronous`` defaults to True (the host can call this from a
    background thread of its choosing). When False, Phase 2's LLM
    pass is dispatched to a daemon thread and Phase 3 runs there too;
    Phase 1 is always synchronous because it must complete before the
    LLM sees the candidate list.
    """
    start = datetime.now(timezone.utc)
    rows_before = list(_get_provider()())
    skill_count_before = len(rows_before)

    counts = apply_automatic_transitions(now=start, rows=rows_before)

    auto_summary_parts: list[str] = []
    if counts["marked_stale"]:
        auto_summary_parts.append(f"{counts['marked_stale']} marked stale")
    if counts["archived"]:
        auto_summary_parts.append(f"{counts['archived']} archived")
    if counts["reactivated"]:
        auto_summary_parts.append(f"{counts['reactivated']} reactivated")
    auto_summary = ", ".join(auto_summary_parts) if auto_summary_parts else "no changes"

    state = load_state()
    state["last_run_at"] = start.isoformat()
    state["run_count"] = int(state.get("run_count", 0)) + 1
    state["last_run_summary"] = f"auto: {auto_summary}"
    state["skill_count_at_last_run"] = skill_count_before
    save_state(state)

    def _llm_and_ziq() -> dict[str, Any]:
        # Phase 2 — LLM umbrella merge (best-effort).
        rows_after_phase1 = list(_get_provider()())
        candidate_list = _render_candidate_list(rows_after_phase1)
        llm_meta: dict[str, Any] = {
            "final": "",
            "summary": "skipped (no candidates)",
            "tool_calls": [],
            "error": None,
        }
        if "No agent-created skills" not in candidate_list:
            runner = _llm_runner
            if runner is not None:
                prompt = f"{CURATOR_REVIEW_PROMPT}\n\n{candidate_list}"
                try:
                    raw = runner(prompt)
                    if isinstance(raw, dict):
                        llm_meta.update(raw)
                except Exception as e:  # noqa: BLE001 - defensive
                    llm_meta["error"] = str(e)
                    llm_meta["summary"] = f"error ({e})"
            else:
                llm_meta["summary"] = "skipped (no llm_runner wired)"

        # Phase 2.5 — GEPA refine (Concinno-novel; best-effort).
        # The LLM umbrella merge produced (or skipped) a `final` text;
        # we optimise the merged-skill description via GEPA so future
        # routing-hit rate climbs over consecutive curator passes.
        # Hook is opt-in via env / runner-attached state — never raises.
        gepa_meta = _gepa_refine_after_phase2(
            llm_meta=llm_meta,
            rows_after_phase1=rows_after_phase1,
        )
        llm_meta["gepa"] = gepa_meta

        # Phase 3 — ZIQ posterior pass.
        rows_after = list(_get_provider()())
        ziq_audit = _run_ziq_posterior_pass(
            rows_after, state_dir_override=state_dir_override
        )

        elapsed = (datetime.now(timezone.utc) - start).total_seconds()
        final_summary = (
            f"auto: {auto_summary}; "
            f"llm: {llm_meta.get('summary', 'no change')}; "
            f"ziq: q={ziq_audit['queries']} c={ziq_audit['candidates']} "
            f"files={ziq_audit['files_written']}"
        )

        state2 = load_state()
        state2["last_run_duration_seconds"] = elapsed
        state2["last_run_summary"] = final_summary
        save_state(state2)

        if on_summary:
            try:
                on_summary(f"curator: {final_summary}")
            except Exception:  # noqa: BLE001 - defensive
                pass

        return {
            "auto_summary": auto_summary,
            "auto_counts": counts,
            "llm": llm_meta,
            "ziq": ziq_audit,
            "elapsed_seconds": elapsed,
            "final_summary": final_summary,
        }

    if synchronous:
        result = _llm_and_ziq()
    else:
        result = {
            "auto_summary": auto_summary,
            "auto_counts": counts,
            "llm": {"summary": "running async"},
            "ziq": {"summary": "running async"},
            "elapsed_seconds": 0.0,
            "final_summary": f"auto: {auto_summary}; llm+ziq: pending",
        }
        t = threading.Thread(target=_llm_and_ziq, daemon=True, name="curator-review")
        t.start()

    return {
        "started_at": start.isoformat(),
        "auto_transitions": counts,
        "summary_so_far": auto_summary,
        **result,
    }


def maybe_run_curator(
    *,
    idle_for_seconds: Optional[float] = None,
    on_summary: Optional[Callable[[str], None]] = None,
    skill_count_now: Optional[int] = None,
) -> Optional[dict[str, Any]]:
    """Best-effort wrapper: run a pass if all gates pass. Never raises.

    The ``skill_count_now`` argument lets the host bypass the interval
    gate on the new-add trigger (≥3 new skills since last run).
    """
    try:
        if not should_run_now(skill_count_now=skill_count_now):
            return None
        if idle_for_seconds is not None:
            min_idle_s = DEFAULT_MIN_IDLE_HOURS * 3600.0
            if idle_for_seconds < min_idle_s:
                return None
        return run_curator_review(on_summary=on_summary)
    except Exception as e:  # noqa: BLE001 - defensive
        logger.debug("maybe_run_curator failed: %s", e, exc_info=True)
        return None


# ── public hook entry-point ───────────────────────────────────────────────


def tick(
    *,
    idle_for_seconds: Optional[float] = None,
    skill_count_now: Optional[int] = None,
    on_summary: Optional[Callable[[str], None]] = None,
) -> Optional[dict[str, Any]]:
    """Public entry-point that the agent loop and CLI both call.

    Wired by:

    * ``concinno-king/cli/main.py`` — the ``concinno-king curator run``
      command calls ``governance.curator.tick(...)`` directly.
    * ``concinno-king/agent/loop_with_redblue.py`` (B3 sub-agent) —
      called once per agent loop turn-end at low priority.

    This is the *only* function callers outside this module should use
    for triggering a pass. Internal callers may still reach for
    :func:`run_curator_review` when they need to bypass gating
    (e.g. tests, migrations).
    """
    return maybe_run_curator(
        idle_for_seconds=idle_for_seconds,
        on_summary=on_summary,
        skill_count_now=skill_count_now,
    )
