# SPDX-License-Identifier: MIT
"""concinno-king.governance.ziq_routing — ZIQ posterior router for skills.

@module governance.ziq_routing
@responsibility Score every L1 candidate skill against a query using the
    Concinno-canonical ZIQ posterior

        P(skill | query) ∝ SPS(description, query) × FTRL_weight(skill)

    salvaged from the pre-K5 ``concinno.skills.disclosure`` module
    (deleted 2026-05-01) and rewired to read live FTRL state from
    :mod:`concinno.ziq_persist`. The routing weight written back to
    ``~/.concinno-king/ziq_curator_state/<skill>.json`` is what
    downstream components (CLI ``concinno-king curator route`` /
    governance hook in agent loop) consume to surface the most
    posterior-relevant skill for a given user query.

@dependencies stdlib only when ``concinno.ziq_persist`` is unavailable
    (the import is best-effort — falls back to in-memory FTRL = 1.0
    so an isolated install of this package still routes by SPS alone).

@exports compute_skill_route, skill_posterior, FtrlReader

NOTICE
------
* SPS scorer (token-cosine over description+triggers) — derived from
  Concinno ``concinno.skills.disclosure`` (AGPL or commercial dual,
  © AI King 2026).
* FTRL state schema (snapshot.json + .jsonl append log) — Concinno
  AGPL/commercial dual, salvaged from ``concinno.ziq_persist``.
* No upstream Hermes / Lyceum code touches this file.
"""

from __future__ import annotations

import json
import math
import os
import re
import threading
import time
from collections.abc import Callable, Iterable, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

__all__ = [
    "DEFAULT_FTRL_FEATURE",
    "DEFAULT_MIN_ROUTE_SCORE",
    "DEFAULT_TOP_K",
    "FtrlReader",
    "RouteResult",
    "SkillCandidate",
    "compute_skill_route",
    "concinno_king_state_dir",
    "skill_posterior",
    "write_routing_weights",
]


# ── tunables ──────────────────────────────────────────────────────────────

DEFAULT_TOP_K = 5
DEFAULT_MIN_ROUTE_SCORE = 0.05
DEFAULT_FTRL_FEATURE = "concinno_king_skill_router"

_TOKEN_RE = re.compile(
    r"[A-Za-z][A-Za-z0-9_\-]*"
    r"|[一-鿿]"
    r"|[가-힯]+"
    r"|[぀-ヿ]+",
)


# ── data classes ──────────────────────────────────────────────────────────


@dataclass(frozen=True)
class SkillCandidate:
    """Minimal candidate row passed into :func:`compute_skill_route`.

    Designed to plug into both the curator (which holds richer rows) and
    a Skill-disclosure-style scanner without forcing either side to
    import the other.
    """

    name: str
    description: str = ""
    triggers: tuple[str, ...] = field(default_factory=tuple)
    path: Optional[Path] = None


@dataclass(frozen=True)
class RouteResult:
    """One ranked candidate from :func:`compute_skill_route`.

    ``score`` is the posterior weight already normalised against the
    candidate set (sums to 1.0 across the survivors). ``sps`` and
    ``ftrl`` are the unnormalised inputs so callers can audit why the
    posterior landed where it did.
    """

    name: str
    score: float
    sps: float
    ftrl: float


# ── tokeniser / SPS ───────────────────────────────────────────────────────


def _tokenise(text: str) -> list[str]:
    """Lower-case Latin words + per-CJK char + Hangul / Kana chunks."""
    if not text:
        return []
    return [m.group(0).lower() for m in _TOKEN_RE.finditer(text)]


def _cosine_overlap(a: Sequence[str], b: Sequence[str]) -> float:
    """Token-overlap cosine in ``[0, 1]``. Empty side = 0.0."""
    if not a or not b:
        return 0.0
    set_a = set(a)
    set_b = set(b)
    inter = len(set_a & set_b)
    if inter == 0:
        return 0.0
    return inter / math.sqrt(len(set_a) * len(set_b))


def _default_sps(query: str, candidate: SkillCandidate) -> float:
    """Default SPS scorer: token cosine over description + triggers."""
    q = _tokenise(query)
    if not q:
        return 0.0
    body = candidate.description + " " + " ".join(candidate.triggers)
    return _cosine_overlap(q, _tokenise(body))


# ── FTRL bridge to concinno.ziq_persist ───────────────────────────────────


class FtrlReader:
    """Thin adapter over :mod:`concinno.ziq_persist` with safe fallback.

    The package may be installed standalone (without concinno on the
    same PYTHONPATH) — in that case we silently fall back to in-memory
    weights initialised at 1.0 per key, which keeps SPS the dominant
    factor and the router degrades gracefully rather than crashing.
    """

    def __init__(
        self,
        feature: str = DEFAULT_FTRL_FEATURE,
        *,
        loader: Optional[Callable[[str], dict[str, float]]] = None,
    ) -> None:
        self._feature = feature
        self._loader = loader
        self._cache: dict[str, float] = {}
        self._cache_loaded = False
        self._lock = threading.RLock()

    def _load(self) -> dict[str, float]:
        if self._loader is not None:
            try:
                return dict(self._loader(self._feature))
            except Exception:  # noqa: BLE001 - defensive
                return {}
        try:
            from concinno.ziq_persist import load_ftrl_state  # type: ignore

            return dict(load_ftrl_state(self._feature))
        except Exception:  # noqa: BLE001 - degrade silently
            return {}

    def weight(self, name: str, *, default: float = 1.0) -> float:
        with self._lock:
            if not self._cache_loaded:
                self._cache = self._load()
                self._cache_loaded = True
            v = self._cache.get(name)
            if v is None or v <= 0.0:
                return default
            return float(v)

    def refresh(self) -> None:
        with self._lock:
            self._cache = self._load()
            self._cache_loaded = True


# ── posterior ─────────────────────────────────────────────────────────────


def skill_posterior(
    query: str,
    candidate: SkillCandidate,
    ftrl_reader: FtrlReader,
    *,
    sps_scorer: Optional[Callable[[str, SkillCandidate], float]] = None,
) -> tuple[float, float, float]:
    """Return ``(unnormalised_posterior, sps, ftrl_weight)``.

    The product ``SPS × FTRL`` matches the formula salvaged from the
    deleted ``concinno.skills.disclosure`` module — patent-novel as a
    governance-layer routing primitive (see Cigito v3 patent axes #1).
    Normalisation is left to the batch caller (:func:`compute_skill_route`)
    so single-skill scoring remains O(1) without re-summing the universe.
    """
    scorer = sps_scorer or _default_sps
    sps = max(0.0, float(scorer(query, candidate)))
    ftrl = max(0.0, float(ftrl_reader.weight(candidate.name)))
    return sps * ftrl, sps, ftrl


# ── batch route ───────────────────────────────────────────────────────────


def compute_skill_route(
    query: str,
    candidates: Iterable[SkillCandidate],
    *,
    top_k: int = DEFAULT_TOP_K,
    min_score: float = DEFAULT_MIN_ROUTE_SCORE,
    ftrl_reader: Optional[FtrlReader] = None,
    sps_scorer: Optional[Callable[[str, SkillCandidate], float]] = None,
) -> list[RouteResult]:
    """Rank ``candidates`` for ``query`` by ZIQ posterior.

    1. Compute ``SPS × FTRL`` per candidate.
    2. Drop candidates whose unnormalised score is ``<= 0``.
    3. Normalise the survivors so their scores sum to 1.0.
    4. Return the top ``top_k`` survivors with score ``>= min_score``,
       sorted descending. Empty list when no candidate clears the gate
       — caller should fall back to alphabetical / unbiased.

    The signature is intentionally a pure function: the only side
    effect is reading FTRL state, which is itself a cached read.
    Writing routing weights back to disk is a separate function
    (:func:`write_routing_weights`) so callers can decide whether the
    pass should be observable or read-only.
    """
    reader = ftrl_reader or FtrlReader()
    rows: list[tuple[SkillCandidate, float, float, float]] = []
    for c in candidates:
        if not isinstance(c, SkillCandidate):
            continue
        score, sps, ftrl = skill_posterior(
            query, c, reader, sps_scorer=sps_scorer
        )
        if score <= 0.0:
            continue
        rows.append((c, score, sps, ftrl))

    if not rows:
        return []

    total = sum(r[1] for r in rows)
    if total <= 0.0:
        return []

    out = [
        RouteResult(
            name=c.name,
            score=score / total,
            sps=sps,
            ftrl=ftrl,
        )
        for (c, score, sps, ftrl) in rows
    ]
    out.sort(key=lambda r: r.score, reverse=True)
    out = [r for r in out if r.score >= max(0.0, float(min_score))]
    if top_k and top_k > 0:
        out = out[: int(top_k)]
    return out


# ── ziq_curator_state writer ──────────────────────────────────────────────


def concinno_king_state_dir() -> Path:
    """Resolve ``~/.concinno-king/ziq_curator_state/`` (env-overridable).

    Env precedence:
        1. ``$CONCINNO_KING_STATE_DIR`` — full override (dir contains
           the ``ziq_curator_state`` subdir).
        2. ``$HOME/.concinno-king/`` (default).
    """
    override = os.environ.get("CONCINNO_KING_STATE_DIR", "").strip()
    base = Path(override).expanduser() if override else (
        Path.home() / ".concinno-king"
    )
    return base / "ziq_curator_state"


def _safe_name(name: str) -> str:
    """Restrict skill names to filesystem-safe chars."""
    if not name:
        return "_"
    out: list[str] = []
    for ch in name:
        if ch.isalnum() or ch in {".", "_", "-"}:
            out.append(ch)
        else:
            out.append("_")
    return "".join(out) or "_"


def write_routing_weights(
    routes: Sequence[RouteResult],
    *,
    query: str = "",
    state_dir: Optional[Path] = None,
) -> int:
    """Persist a curator pass's routing decisions for offline audit.

    Writes one ``<skill_name>.json`` per route under
    ``~/.concinno-king/ziq_curator_state/`` capturing the posterior at
    pass time. Best-effort: any IO error is swallowed so a curator
    pass is never blocked on a write.

    Returns the number of files actually written.
    """
    target = state_dir or concinno_king_state_dir()
    try:
        target.mkdir(parents=True, exist_ok=True)
    except OSError:
        return 0
    written = 0
    ts = time.time()
    for r in routes:
        if not isinstance(r, RouteResult):
            continue
        path = target / f"{_safe_name(r.name)}.json"
        payload: dict[str, Any] = {
            "skill": r.name,
            "score": r.score,
            "sps": r.sps,
            "ftrl": r.ftrl,
            "query": query,
            "ts": ts,
            "schema": 1,
        }
        try:
            tmp = path.with_suffix(path.suffix + ".tmp")
            tmp.write_text(
                json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True),
                encoding="utf-8",
            )
            os.replace(tmp, path)
            written += 1
        except OSError:
            continue
    return written
