# SPDX-License-Identifier: MIT
"""concinno-king.governance — skill curator + ZIQ-driven routing.

Two-module package:

* :mod:`governance.curator`   — auto stale/archive transitions + LLM
  umbrella-merge pass (transcribed from Hermes/Lyceum
  ``agent/curator.py``, MIT 1.0).
* :mod:`governance.ziq_routing` — Concinno-novel ZIQ posterior layer
  ``P(skill|query) ∝ SPS × FTRL`` consuming live FTRL state from
  :mod:`concinno.ziq_persist`.

The combined surface bridges Hermes's prompt-layer self-evolution with
Concinno's patent-novel ZIQ posterior so curator passes also tune the
skill router weights every run.
"""

from __future__ import annotations

from .curator import (
    apply_automatic_transitions,
    is_enabled,
    is_paused,
    load_state,
    maybe_run_curator,
    run_curator_review,
    save_state,
    set_paused,
    should_run_now,
    tick,
)
from .ziq_routing import (
    compute_skill_route,
    skill_posterior,
)

__all__ = [
    "apply_automatic_transitions",
    "compute_skill_route",
    "is_enabled",
    "is_paused",
    "load_state",
    "maybe_run_curator",
    "run_curator_review",
    "save_state",
    "set_paused",
    "should_run_now",
    "skill_posterior",
    "tick",
]
