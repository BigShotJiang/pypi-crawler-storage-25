# SPDX-License-Identifier: MIT
"""concinno-king.agent — main agent loop + dispatchers + invariants.

This package houses the public-facing agent loop wired with the
Concinno red-blue-green CBUA review layer (the layer Hermes does not
have). It composes:

* :mod:`agent.loop_with_redblue` — the main loop (Sancio-derived state
  machine + RedBlueGreenHook + Curator hook + Skill emergence hook).
* :mod:`agent.redblue_dispatcher` — abstract Opus dispatcher Protocol
  (Anthropic / OpenAI / mock).
* :mod:`agent.invariants` — pre/post step invariants ported from B4
  sub-agent (placeholder if B4 has not landed yet).
"""

from __future__ import annotations
