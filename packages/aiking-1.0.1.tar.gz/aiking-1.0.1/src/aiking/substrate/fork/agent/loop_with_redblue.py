# SPDX-License-Identifier: MIT
"""concinno-king.agent.loop_with_redblue — main agent loop wired with the
red-blue-green CBUA review layer.

@module agent.loop_with_redblue
@responsibility Drive a multi-round LLM + tool execution loop (Sancio-
    derived state machine) with three Concinno-novel governance hooks
    that Hermes / Lyceum upstream do NOT have:

    1. **RedBlueGreenHook** — when an iteration's planned action
       crosses a configurable complexity threshold, the hook dispatches
       a red+blue (or red+blue+green at Chaotic radius) Opus review
       and applies the 5-state verdict to the iteration before any
       side effect happens.
    2. **CuratorHook** — wraps :func:`governance.curator.tick`. If the
       curator wants to archive >5 skills or merge a cluster ≥3 it
       does NOT commit; it routes through the redblue dispatch first.
    3. **EmergenceHook** — every successful tool call observes via
       :func:`skills.emergence.observe`, which may stage a skill draft
       under ``~/.concinno-king/skill_drafts/``.

@dependencies
    concinno.guards.redblue_green_dispatch_guard (5-axis verdict),
    governance.curator (skill lifecycle),
    skills.emergence (auto-draft observer),
    agent.invariants (pre/post step assertions),
    agent.redblue_dispatcher (Opus dispatcher abstraction).
@exports AgentLoopWithRedBlue, AgentState, ToolCall, LLMResponse,
    Tool, PreToolUseHook, PostToolUseHook, PermissionDenied,
    RedBlueGreenHook, CuratorHook, EmergenceHook,
    HookDecision, HookOutcome, run_iteration, build_default_loop

Design
------
The loop intentionally re-implements the Sancio agent_loop shape
verbatim (Tool / ToolCall / LLMResponse / AgentState dataclasses,
pre/post hook chain) instead of importing Sancio. concinno-king is
a standalone harness — it must run without sancio installed.

The three hooks slot in at distinct phases so they compose cleanly:

* **RedBlueGreenHook** runs in :meth:`AgentLoopWithRedBlue.before_step`
  (BEFORE tool execution) so the verdict can ABORT a step (REJECT /
  HOLD) before any side effect.
* **CuratorHook** runs in :meth:`AgentLoopWithRedBlue.after_step`
  (AFTER tool execution) since curator passes don't gate tool calls;
  they observe the system between iterations.
* **EmergenceHook** runs in the post-tool-use chain on every
  successful call.

Invariants from :mod:`agent.invariants` wrap every iteration in BOTH
``pre_step_check`` and ``post_step_check`` form (B4 contract).
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable, Optional, Protocol

from aiking.substrate.fork.agent.invariants import (
    InvariantViolation,
    post_step_check,
    pre_step_check,
)
from aiking.substrate.fork.agent.redblue_dispatcher import (
    DEFAULT_OPUS_MODEL,
    NullDispatcher,
    build_dispatcher,
)

logger = logging.getLogger(__name__)

__all__ = [
    "AgentLoopWithRedBlue",
    "AgentState",
    "CuratorHook",
    "EmergenceHook",
    "HookDecision",
    "HookOutcome",
    "LLMResponse",
    "PermissionDenied",
    "PostToolUseHook",
    "PreToolUseHook",
    "RedBlueGreenHook",
    "Tool",
    "ToolCall",
    "build_default_loop",
    "run_iteration",
]


# ── tool / message shapes ──────────────────────────────────────────


class Tool(Protocol):
    """Minimal tool contract (mirrors Sancio's contract)."""

    name: str

    def schema(self) -> dict[str, Any]:
        """Return an OpenAI function-calling spec dict."""

    def execute(self, args: dict[str, Any]) -> Any:
        """Run the tool synchronously and return its result."""


@dataclass
class ToolCall:
    """One LLM-issued tool invocation."""

    id: str
    name: str
    args: dict[str, Any] = field(default_factory=dict)


@dataclass
class LLMResponse:
    """One LLM reply: text + optional tool_calls."""

    content: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)
    # ZIQ-style complexity signal — propagated into the redblue hook
    # to decide whether to dispatch. 0.0 = trivial, 1.0 = chaotic.
    complexity: float = 0.0


LLMCall = Callable[
    [list[dict[str, Any]], list[dict[str, Any]]],
    LLMResponse,
]
"""Provider-agnostic LLM invocation signature."""


PreToolUseHook = Callable[[str, dict[str, Any]], None]
PostToolUseHook = Callable[[str, dict[str, Any], Any], Any]


class PermissionDenied(Exception):
    """Raised inside a Pre-hook to abort one tool call."""


# ── decision shapes for the RedBlueGreen hook ──────────────────────


@dataclass(frozen=True)
class HookOutcome:
    """Structured result returned by :meth:`RedBlueGreenHook.on_step`."""

    decision: str   # "accept" | "abort" | "downgrade" | "hold"
    rationale: str = ""
    spawn_count: int = 0
    elapsed_ms: int = 0
    radius: str = "simple"


@dataclass(frozen=True)
class HookDecision:
    """Decision passed back into the loop to gate a step."""

    proceed: bool
    abort_message: Optional[str] = None
    downgrade_note: Optional[str] = None


# ── RedBlueGreen hook ──────────────────────────────────────────────


@dataclass
class RedBlueGreenHook:
    """Per-iteration CBUA review hook.

    Calls into the Concinno
    :class:`concinno.guards.redblue_green_dispatch_guard.RedBlueGreenDispatchGuard`
    when the planned step's complexity / radius warrants it.

    Attributes
    ----------
    dispatcher:
        Implements ``dispatch(prompt, model, role) -> str``. Defaults
        to the null dispatcher so the loop is importable without
        Anthropic/OpenAI SDKs.
    chaotic_threshold:
        complexity ≥ this → Chaotic radius (3R+1B+1G).
    high_threshold:
        complexity ≥ this → High radius (1R+1B).
    medium_threshold:
        complexity ≥ this → Medium radius (1R, blue is main agent).
    enabled:
        Master switch — when False the hook short-circuits to ACCEPT.
    """

    dispatcher: Any = field(default_factory=NullDispatcher)
    chaotic_threshold: float = 0.90
    high_threshold: float = 0.55
    medium_threshold: float = 0.20
    enabled: bool = True
    _outcomes: list[HookOutcome] = field(default_factory=list)

    def classify_radius(self, complexity: float) -> str:
        """Map a 0..1 complexity score to a radius string."""
        if complexity >= self.chaotic_threshold:
            return "chaotic"
        if complexity >= self.high_threshold:
            return "high"
        if complexity >= self.medium_threshold:
            return "medium"
        return "simple"

    def on_step(
        self,
        decision_context: str,
        complexity: float,
        *,
        original_intent: str = "",
    ) -> HookDecision:
        """Run the redblue review and convert verdict → loop decision."""
        if not self.enabled:
            return HookDecision(proceed=True, downgrade_note="hook disabled")

        radius = self.classify_radius(complexity)
        if radius == "simple":
            self._outcomes.append(
                HookOutcome(
                    decision="accept",
                    rationale="Simple radius — review skipped",
                    radius=radius,
                ),
            )
            return HookDecision(proceed=True)

        # Lazy import — concinno is the package under reuse but might
        # not be installed in the dev shell where the loop is imported
        # for tests. The dispatcher is mocked in tests anyway.
        try:
            from concinno.guards.redblue_green_dispatch_guard import (
                RedBlueGreenDispatchGuard,
                Radius,
                Verdict,
            )
        except ImportError:
            logger.debug(
                "concinno guard not importable — accepting step by default",
            )
            outcome = HookOutcome(
                decision="accept",
                rationale="concinno guard unavailable",
                radius=radius,
            )
            self._outcomes.append(outcome)
            return HookDecision(proceed=True)

        radius_enum = {
            "medium": Radius.MEDIUM,
            "high": Radius.HIGH,
            "chaotic": Radius.CHAOTIC,
        }.get(radius, Radius.SIMPLE)

        guard = RedBlueGreenDispatchGuard()
        verdict = guard.review(
            decision_context=decision_context,
            radius=radius_enum,
            dispatcher=self.dispatcher,
            original_intent=original_intent,
        )

        decision_map = {
            Verdict.ACCEPT: ("accept", True, None, None),
            Verdict.ACCEPT_DOWNGRADE: (
                "downgrade", True, None, "verdict downgrade — soften wording",
            ),
            Verdict.HOLD: ("hold", False, "hold — pending further evidence", None),
            Verdict.REJECT: (
                "abort", False, "redblue REJECT — step aborted", None,
            ),
            Verdict.REQUERY: (
                "hold", False, "redblue REQUERY — need scoped re-attack", None,
            ),
        }
        kind, proceed, abort_msg, downgrade = decision_map[verdict.verdict]
        self._outcomes.append(
            HookOutcome(
                decision=kind,
                rationale=verdict.rationale,
                spawn_count=verdict.spawn_count,
                elapsed_ms=verdict.elapsed_ms,
                radius=radius,
            ),
        )
        return HookDecision(
            proceed=proceed,
            abort_message=abort_msg,
            downgrade_note=downgrade,
        )

    def history(self) -> list[HookOutcome]:
        """Return the per-step outcome history (for tests / audit)."""
        return list(self._outcomes)


# ── Curator hook ───────────────────────────────────────────────────


@dataclass
class CuratorHook:
    """Wrap ``governance.curator.tick`` and route big plans through redblue.

    Triggered from :meth:`AgentLoopWithRedBlue.after_step`. When the
    curator's tick wants to archive >threshold skills or merge a
    cluster ≥3 wide, the hook fires a Chaotic-radius redblue review
    and only commits the plan if the verdict is ACCEPT or
    ACCEPT_DOWNGRADE.
    """

    redblue_hook: RedBlueGreenHook
    archive_threshold: int = 5
    cluster_threshold: int = 3
    enabled: bool = True
    _ticks: list[dict[str, Any]] = field(default_factory=list)

    def maybe_run(self, original_intent: str = "") -> dict[str, Any]:
        """Run a curator tick, possibly gated through redblue review.

        Returns a dict describing what happened (keys ``ran_review``,
        ``archive_count``, ``merge_count``, ``redblue_decision``).
        """
        if not self.enabled:
            return {
                "ran_review": False,
                "archive_count": 0,
                "merge_count": 0,
                "redblue_decision": "skipped",
            }

        # Lazy-import — keeps test import surface narrow. Both the real
        # A4-curator schema (dict from ``tick()``) and the legacy stub
        # schema (``TickResult`` dataclass) are accepted via duck-typing
        # so this hook does not break when either side is swapped.
        try:
            from aiking.substrate.fork.governance.curator import tick as curator_tick
        except ImportError as exc:
            logger.warning("curator unavailable: %r", exc)
            return {
                "ran_review": False,
                "archive_count": 0,
                "merge_count": 0,
                "redblue_decision": "curator-import-failed",
            }

        try:
            plan = curator_tick()
        except TypeError:
            # Legacy stub signature: tick(archive_threshold=...).
            plan = curator_tick(archive_threshold=self.archive_threshold)

        archive_n, merge_n = _coerce_curator_plan(plan, self.cluster_threshold)

        record: dict[str, Any] = {
            "ran_review": False,
            "archive_count": archive_n,
            "merge_count": merge_n,
            "redblue_decision": "no-review-needed",
            "planned_at": time.time(),
        }

        if archive_n > self.archive_threshold or merge_n >= 1:
            # Big plan — route through redblue at Chaotic radius.
            decision_ctx = (
                f"curator plan: archive {archive_n} skills, merge "
                f"{merge_n} clusters (≥{self.cluster_threshold}-wide)"
            )
            decision = self.redblue_hook.on_step(
                decision_context=decision_ctx,
                complexity=0.95,  # force chaotic radius
                original_intent=original_intent,
            )
            record["ran_review"] = True
            record["redblue_decision"] = (
                "accept" if decision.proceed else "abort"
            )

        self._ticks.append(record)
        return record

    def ticks(self) -> list[dict[str, Any]]:
        """Return tick history (for tests / audit)."""
        return list(self._ticks)


# ── Emergence hook ─────────────────────────────────────────────────


@dataclass
class EmergenceHook:
    """PostToolUse hook that observes tool calls into the emergence layer.

    Each successful call passes through :func:`skills.emergence.observe`
    which may stage a SkillDraft. Failures (``is_error=True`` /
    permission denied / tool error string) are still recorded so the
    T2 chain detector can see them.
    """

    conv_id: str = "default"
    enabled: bool = True
    _observed: list[dict[str, Any]] = field(default_factory=list)

    def __call__(
        self,
        tool_name: str,
        args: dict[str, Any],
        result: Any,
    ) -> Any:
        """Observe and pass result through unchanged.

        Builds an :class:`skills.emergence.EmergenceSignal` from the
        ``(tool_name, args, result)`` triple and routes it through the
        B1-shipped ``observe()`` entry point. Tolerant of an absent or
        legacy emergence module — the loop never crashes here.
        """
        if not self.enabled:
            return result
        try:
            from aiking.substrate.fork.skills.emergence import (
                EmergenceSignal,
                observe,
            )
        except ImportError:
            return result

        # Heuristic success detection — same shape used by the wrapper
        # logic inside skills.emergence.observe but applied here so we
        # capture the success bit BEFORE we hand off the signal.
        is_error = (
            isinstance(result, str)
            and result.startswith(
                ("tool error", "permission denied", "post-hook deny"),
            )
        ) or (isinstance(result, dict) and result.get("is_error"))
        success = not is_error

        # Canonical shape: Bash → first token, Edit/Write → file ext,
        # everything else → tool_name itself. Mirrors B1's shape rules.
        canonical_shape = _canonical_shape_for(tool_name, args)

        signal = EmergenceSignal(
            tool_name=tool_name,
            canonical_shape=canonical_shape,
            success=success,
        )
        try:
            staged = observe(signal, conv_id=self.conv_id)
            self._observed.append(
                {
                    "tool": tool_name,
                    "staged": str(staged) if staged else None,
                    "ts": time.time(),
                },
            )
        except Exception as exc:  # noqa: BLE001 — never crash the loop
            logger.debug("EmergenceHook swallowed: %r", exc)
        return result

    def observed(self) -> list[dict[str, Any]]:
        """Return observation history."""
        return list(self._observed)


# ── agent state ────────────────────────────────────────────────────


@dataclass
class AgentState:
    """Mutable loop state."""

    messages: list[dict[str, Any]]
    iterations: int = 0
    done: bool = False
    final_text: str = ""
    stop_reason: str = ""
    aborted_steps: list[str] = field(default_factory=list)
    _max_iterations_hint: int = 25


# ── main loop ──────────────────────────────────────────────────────


@dataclass
class AgentLoopWithRedBlue:
    """Concinno-King agent loop with red-blue-green CBUA review.

    Composes:

    * Sancio-style state machine (iteration / pre-hooks / tool exec /
      post-hooks).
    * :class:`RedBlueGreenHook` BEFORE every non-trivial step.
    * :class:`CuratorHook` AFTER every iteration.
    * :class:`EmergenceHook` in the post-tool-use chain.
    * :func:`agent.invariants.pre_step_check` /
      :func:`agent.invariants.post_step_check` wrapping each
      iteration.
    """

    llm_call: LLMCall
    tools: dict[str, Tool] = field(default_factory=dict)
    pre_hooks: list[PreToolUseHook] = field(default_factory=list)
    post_hooks: list[PostToolUseHook] = field(default_factory=list)
    redblue_hook: Optional[RedBlueGreenHook] = None
    curator_hook: Optional[CuratorHook] = None
    emergence_hook: Optional[EmergenceHook] = None
    max_iterations: int = 25

    def __post_init__(self) -> None:
        """Wire defaults and ensure the post-tool-use chain runs the
        emergence hook last so the LLM sees an unmutated result."""
        if self.redblue_hook is None:
            self.redblue_hook = RedBlueGreenHook()
        if self.curator_hook is None:
            self.curator_hook = CuratorHook(redblue_hook=self.redblue_hook)
        if self.emergence_hook is None:
            self.emergence_hook = EmergenceHook()
        # Append emergence hook to the post-hook chain (idempotent).
        if self.emergence_hook not in self.post_hooks:
            self.post_hooks.append(self.emergence_hook)

    def run(
        self,
        messages: list[dict[str, Any]],
        *,
        original_intent: str = "",
    ) -> AgentState:
        """Drive the loop until completion or cap.

        Each iteration runs:

        1. ``pre_step_check`` — invariant pre-conditions.
        2. ``llm_call`` — get next response.
        3. ``redblue_hook.on_step`` — review the planned action.
        4. tool execution (pre/post hook chain) IF redblue accepted.
        5. ``curator_hook.maybe_run`` — observe between-iteration.
        6. ``post_step_check`` — invariant post-conditions.
        """
        state = AgentState(
            messages=list(messages),
            _max_iterations_hint=self.max_iterations,
        )
        schemas = [t.schema() for t in self.tools.values()]

        while not state.done:
            if state.iterations >= self.max_iterations:
                state.stop_reason = "max_iterations"
                state.done = True
                break

            # --- pre-step invariants
            try:
                pre_step_check(state)
            except InvariantViolation as exc:
                logger.error("pre_step invariant: %s", exc)
                state.stop_reason = f"invariant_pre: {exc}"
                state.done = True
                break

            state.iterations += 1
            resp = self.llm_call(state.messages, schemas)

            assistant_msg: dict[str, Any] = {
                "role": "assistant",
                "content": resp.content,
            }
            if resp.tool_calls:
                assistant_msg["tool_calls"] = [
                    {"id": c.id, "name": c.name, "args": c.args}
                    for c in resp.tool_calls
                ]
            state.messages.append(assistant_msg)

            if not resp.tool_calls:
                state.done = True
                state.final_text = resp.content
                state.stop_reason = "completed"
                # final post-step invariant before exit
                try:
                    post_step_check(state)
                except InvariantViolation as exc:
                    logger.error("post_step invariant: %s", exc)
                    state.stop_reason = f"invariant_post: {exc}"
                break

            # --- redblue review (BEFORE side effects)
            decision_ctx = json.dumps(
                {
                    "iteration": state.iterations,
                    "tool_calls": [
                        {"name": c.name, "args": c.args}
                        for c in resp.tool_calls
                    ],
                    "summary": resp.content[:500],
                },
                ensure_ascii=False,
            )
            assert self.redblue_hook is not None  # __post_init__ guarantees
            verdict = self.redblue_hook.on_step(
                decision_context=decision_ctx,
                complexity=resp.complexity,
                original_intent=original_intent,
            )
            if not verdict.proceed:
                msg = verdict.abort_message or "step aborted by redblue review"
                state.aborted_steps.append(msg)
                state.messages.append(
                    {
                        "role": "tool",
                        "name": "_redblue",
                        "content": msg,
                        "is_error": True,
                    },
                )
                # Curator + invariants still run after an abort so we
                # don't silently skip tail logic.
                self._after_step(state, original_intent)
                continue

            # --- tool execution
            for call in resp.tool_calls:
                self._run_one_tool(state, call)

            # --- after-step (curator + invariants)
            self._after_step(state, original_intent)

        return state

    # ── helpers ─────────────────────────────────────────────────────

    def _after_step(
        self,
        state: AgentState,
        original_intent: str,
    ) -> None:
        """Run curator + post-step invariants after a step.

        Curator failures are warnings, not crashes, so a flaky
        curator state file never breaks the loop. Invariant failures
        DO stop the loop (they signal a real bug).
        """
        try:
            assert self.curator_hook is not None
            self.curator_hook.maybe_run(original_intent=original_intent)
        except Exception as exc:  # noqa: BLE001 — observational
            logger.warning("curator_hook failed: %r", exc)

        try:
            post_step_check(state)
        except InvariantViolation as exc:
            logger.error("post_step invariant: %s", exc)
            state.stop_reason = f"invariant_post: {exc}"
            state.done = True

    def _run_one_tool(
        self,
        state: AgentState,
        call: ToolCall,
    ) -> None:
        """Execute a single tool call through the hook chain."""
        tool = self.tools.get(call.name)
        if tool is None:
            state.messages.append(
                _tool_msg(call.id, f"unknown tool: {call.name}", is_error=True),
            )
            return

        # pre-hooks
        try:
            for hook in self.pre_hooks:
                hook(call.name, call.args)
        except PermissionDenied as exc:
            state.messages.append(
                _tool_msg(
                    call.id, f"permission denied: {exc}", is_error=True,
                ),
            )
            return

        # execute
        try:
            result: Any = tool.execute(call.args)
            is_error = False
        except Exception as exc:  # noqa: BLE001
            result = f"tool error: {exc}"
            is_error = True

        # post-hooks (emergence is in this chain)
        for hook in self.post_hooks:
            try:
                rewritten = hook(call.name, call.args, result)
                if rewritten is not None:
                    result = rewritten
            except Exception as exc:  # noqa: BLE001 — observational
                logger.debug("post_hook %s raised: %r", hook, exc)

        state.messages.append(
            _tool_msg(call.id, result, is_error=is_error),
        )


# ── helpers ────────────────────────────────────────────────────────


def _canonical_shape_for(tool_name: str, args: dict[str, Any]) -> str:
    """Canonical shape extraction matching B1's emergence rules.

    Rules ported from ``skills.emergence`` (B1 sub-agent):

    * ``Bash`` / ``bash`` → first whitespace-delimited token of the
      ``command`` arg (e.g. ``"ruff check ..."`` → ``"ruff"``).
    * ``Edit`` / ``Write`` / ``Read`` → file extension of ``file_path``
      including the leading dot (e.g. ``".py"``).
    * Anything else → the tool name itself, so the fingerprint at
      least groups by tool.
    """
    name = (tool_name or "").lower()
    if name == "bash":
        cmd = str(args.get("command") or "").strip()
        head = cmd.split(None, 1)[0] if cmd else ""
        return head or "bash"
    if name in {"edit", "write", "read"}:
        path = str(args.get("file_path") or "")
        if "." in path:
            return "." + path.rsplit(".", 1)[1]
        return name
    return tool_name or "unknown"


def _coerce_curator_plan(
    plan: Any,
    cluster_threshold: int,
) -> tuple[int, int]:
    """Extract ``(archive_count, merge_count)`` from any curator plan shape.

    Real A4 curator returns a dict like
    ``{"auto_transitions": {"marked_stale": N, "archived": M, ...}, ...}``.
    Legacy stub returns a ``TickResult`` dataclass with
    ``archive_candidates`` / ``cluster_merges``. Both shapes are
    duck-typed here so the wiring contract survives either side
    being swapped without coordinating a release.
    """
    if plan is None:
        return 0, 0

    # Legacy stub dataclass shape.
    archive_candidates = getattr(plan, "archive_candidates", None)
    cluster_merges = getattr(plan, "cluster_merges", None)
    if archive_candidates is not None or cluster_merges is not None:
        archive_n = len(archive_candidates or [])
        merges = cluster_merges or []
        merge_n = len(
            [c for c in merges if hasattr(c, "__len__") and len(c) >= cluster_threshold],
        )
        return archive_n, merge_n

    # Real A4 dict shape.
    if isinstance(plan, dict):
        transitions = plan.get("auto_transitions") or plan.get("auto_counts") or {}
        archive_n = int(transitions.get("archived", 0)) + int(
            transitions.get("marked_stale", 0),
        )
        # No cluster-merge field in the A4 schema — surface 0 for now;
        # the umbrella merge count lives under llm.tool_calls if any.
        llm_meta = plan.get("llm") or {}
        merge_n = len(llm_meta.get("tool_calls") or [])
        return archive_n, merge_n

    return 0, 0


def _tool_msg(tool_call_id: str, content: Any, *, is_error: bool) -> dict[str, Any]:
    """Build a tool-result message in the same shape Sancio uses."""
    if not isinstance(content, str):
        try:
            content = json.dumps(content, ensure_ascii=False, default=str)
        except (TypeError, ValueError):
            content = str(content)
    return {
        "role": "tool",
        "tool_call_id": tool_call_id,
        "content": content,
        "is_error": is_error,
    }


def run_iteration(
    loop: AgentLoopWithRedBlue,
    messages: list[dict[str, Any]],
    *,
    original_intent: str = "",
) -> AgentState:
    """Convenience wrapper for callers that just want a one-shot run."""
    return loop.run(messages, original_intent=original_intent)


def build_default_loop(
    llm_call: LLMCall,
    *,
    tools: Optional[Iterable[Tool]] = None,
    backend: Optional[str] = None,
    conv_id: str = "default",
) -> AgentLoopWithRedBlue:
    """Wire a default loop with sane production defaults.

    * Real Anthropic dispatcher (or whatever ``backend`` resolves to)
      via :func:`build_dispatcher`.
    * RedBlueGreenHook + CuratorHook + EmergenceHook all wired.
    * No pre-hooks (caller adds Aegis-style policy hooks if desired).
    """
    dispatcher = build_dispatcher(backend=backend)
    redblue = RedBlueGreenHook(dispatcher=dispatcher)
    curator = CuratorHook(redblue_hook=redblue)
    emergence = EmergenceHook(conv_id=conv_id)
    tool_dict = {t.name: t for t in (tools or [])}
    loop = AgentLoopWithRedBlue(
        llm_call=llm_call,
        tools=tool_dict,
        redblue_hook=redblue,
        curator_hook=curator,
        emergence_hook=emergence,
    )
    logger.info(
        "concinno-king loop built: backend=%s model=%s tools=%d",
        backend or "default",
        DEFAULT_OPUS_MODEL,
        len(tool_dict),
    )
    return loop
