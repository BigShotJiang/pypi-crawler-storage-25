# SPDX-License-Identifier: MIT
"""concinno-king.agent.invariants — three-invariant contract + loop checks.

@module agent.invariants
@responsibility Two layers of invariant enforcement on every agent loop
    iteration:

    1. **Architectural three-invariant contract** (separation / fusion /
       autonomy) — ported from Lyceum (MEMORY #4l, patent-verified
       novel under 2026-only filter). Failures are *signals*: they
       record a negative FTRL outcome via :mod:`concinno.ziq_persist`
       and append to a date-partitioned jsonl trail under
       ``~/.concinno-king/invariant_violations/``, but the loop
       continues. Only ``severity="fatal"`` raises
       :class:`InvariantViolation`.

    2. **Loop-mechanics baseline** (B3-stub registry) — message list
       monotonicity, iteration bound, done implies stop reason. These
       guard against off-by-one / silent-zombie regressions and DO
       raise immediately on violation (the loop catches and surfaces
       as a tool error so one bad iteration doesn't kill the run).

    The two layers compose: ``pre_step_check`` runs the registry first
    (raise-fast), then runs the architectural checks (record + return
    list of results). ``post_step_check`` does the same plus fusion +
    autonomy.

@dependencies
    Standard library only. ``concinno.ziq_persist`` import is
    best-effort — fail-open fallback writes a stderr breadcrumb so
    the agent loop keeps running when concinno is not installed.

@exports
    InvariantName, InvariantResult, AgentState, SubAgentCtx,
    InvariantProtocol (Protocol B3 imports), check_separation,
    check_fusion, check_autonomy, pre_step_check, post_step_check,
    record_violation, get_recent_violations, InvariantViolation,
    register_check, list_checks, default_checks, CheckFn.

Why this file is the strategic anchor
-------------------------------------
This is the substrate that makes the "輸他的就照抄改良" user directive
concrete (per ``feedback_lyceum_concinno_governance_strategy``,
MEMORY #4t). We kept Lyceum's invariant skeleton but rewired the
recorder to Concinno's ZIQ FTRL store (real online learning) instead
of Lyceum's standalone outcome_store. That bridge — invariant
violations becoming negative posterior signals — is what no current
OSS agent framework ships, including Hermes Agent (MIT, 68.6k★,
audited 2026-05-01: zero invariant coverage).
"""
from __future__ import annotations

import logging
import sys
from dataclasses import dataclass, field
from enum import Enum
from typing import (
    Any,
    Callable,
    Iterable,
    List,
    Mapping,
    Optional,
    Protocol,
    Sequence,
    runtime_checkable,
)

from aiking.substrate.fork.agent.invariants_state import (
    append_violation_record,
    list_recent_violations,
)


logger = logging.getLogger(__name__)


__all__ = [
    # Architectural contract surface (the new B4 layer)
    "InvariantName",
    "InvariantResult",
    "AgentState",
    "SubAgentCtx",
    "InvariantProtocol",
    "InvariantViolation",
    "check_separation",
    "check_fusion",
    "check_autonomy",
    "pre_step_check",
    "post_step_check",
    "record_violation",
    "get_recent_violations",
    # Loop-mechanics registry (preserved from B3 stub)
    "CheckFn",
    "register_check",
    "list_checks",
    "default_checks",
]


# ─── Enum + exception ──────────────────────────────────────────


class InvariantName(str, Enum):
    """Canonical names of the three architectural invariants."""

    SEPARATION = "separation"
    FUSION = "fusion"
    AUTONOMY = "autonomy"


class InvariantViolation(AssertionError):
    """Raised when an invariant fails fatally.

    Subclass of :class:`AssertionError` so callers that already catch
    AssertionError don't have to special-case invariants while
    migrating from B3-stub to B4-full. Carries the invariant kind +
    structured detail.
    """

    def __init__(
        self,
        invariant: InvariantName | str | None = None,
        message: str = "",
        detail: Optional[Mapping[str, Any]] = None,
    ) -> None:
        prefix = ""
        if isinstance(invariant, InvariantName):
            prefix = f"[{invariant.value}] "
        elif isinstance(invariant, str) and invariant:
            prefix = f"[{invariant}] "
        super().__init__(f"{prefix}{message}" if message else prefix or "invariant violation")
        self.invariant = invariant
        self.detail = dict(detail or {})


# ─── Result + state dataclasses ─────────────────────────────────


@dataclass(frozen=True)
class InvariantResult:
    """Outcome of one architectural invariant check."""

    invariant: InvariantName
    passed: bool
    message: str = ""
    severity: str = "warn"  # "warn" | "fatal"
    detail: Mapping[str, Any] = field(default_factory=dict)


@dataclass
class SubAgentCtx:
    """Context bundle handed to a sub-agent at spawn time.

    Attributes:
        agent_id: child agent identifier.
        parent_agent_id: parent agent identifier.
        bundle: the data payload — should be a deep copy / value type.
        leaks_parent_secrets: when True the autonomy invariant fails
            (the bundle exposes parent-only state to the child).
        aliased_state_keys: names of mutable handles aliased between
            parent and child (any non-empty tuple fails autonomy).
    """

    agent_id: str
    parent_agent_id: str
    bundle: Mapping[str, Any] = field(default_factory=dict)
    leaks_parent_secrets: bool = False
    aliased_state_keys: tuple[str, ...] = ()


@dataclass
class AgentState:
    """Snapshot of agent-loop state checked at every step boundary.

    Attributes:
        agent_id: stable identifier of the running agent.
        step_kind: ``"pre"`` / ``"post"`` — picks the axis to check.
        governance_writes: paths governance modules touched this step
            (must not start with substrate prefixes for separation).
        parallel_branches: list of sibling-agent outcomes when fusion
            is in flight (each must carry the ``"normaliser"`` key).
        sub_agents: list of recently spawned :class:`SubAgentCtx`
            objects pending autonomy verification.
        runtime_state: free-form bag for future-proofing.

    The dataclass is intentionally separate from B3's loop-state — the
    loop state passed to the registry checks is duck-typed
    (``getattr(state, "messages", ...)``); the architectural checks
    operate on this richer dataclass.
    """

    agent_id: str
    step_kind: str = "pre"
    governance_writes: tuple[str, ...] = ()
    parallel_branches: tuple[Mapping[str, Any], ...] = ()
    sub_agents: tuple[SubAgentCtx, ...] = ()
    runtime_state: Mapping[str, Any] = field(default_factory=dict)


# ─── Protocol (the surface B3 imports) ──────────────────────────


@runtime_checkable
class InvariantProtocol(Protocol):
    """The surface ``agent.loop_with_redblue`` imports.

    Stable signature contract:

    .. code-block:: python

        def pre_step_check(state) -> list[InvariantResult]: ...
        def post_step_check(
            state,
            step_result: Mapping[str, Any] | None = None,
        ) -> list[InvariantResult]: ...

    ``state`` may be either:

    * an :class:`AgentState` (for the architectural-contract checks), or
    * a duck-typed loop state with ``.messages`` / ``.iterations`` /
      ``.done`` / ``.stop_reason`` (for the registry baseline checks).

    The implementation handles both — registry checks use ``getattr``
    with safe defaults, architectural checks short-circuit when the
    state lacks the needed attributes.
    """

    def pre_step_check(
        self, state: Any
    ) -> List[InvariantResult]: ...

    def post_step_check(
        self,
        state: Any,
        step_result: Optional[Mapping[str, Any]] = None,
    ) -> List[InvariantResult]: ...


# ─── Architectural invariant checks (separation / fusion / autonomy) ──


# Substrate path prefixes governance is *not* allowed to write to.
# Mirrors Lyceum's lyceum.runtime / lyceum.sandbox / lyceum.memory /
# lyceum.skills layering, mapped onto concinno-king's flat package
# layout: governance must not import messaging / providers / sandbox /
# skills directly — only via documented adapter Protocols.
_SUBSTRATE_PATH_PREFIXES: tuple[str, ...] = (
    "concinno_king.messaging.",
    "concinno_king.providers.",
    "concinno_king.sandbox.",
    "concinno_king.skills.",
    "messaging.",
    "providers.",
    "sandbox.",
    "skills.",
)


def check_separation(state: AgentState) -> InvariantResult:
    """Verify governance writes do not reach into substrate runtime.

    Governance modules are allowed to *read* anything but may not
    mutate substrate state directly. Cross-boundary mutations go
    through documented adapter Protocols (see
    ``concinno-skills-lyceum-adapter``).
    """
    writes = tuple(getattr(state, "governance_writes", ()) or ())
    breaches = sorted(
        path
        for path in writes
        if isinstance(path, str)
        and path.startswith(_SUBSTRATE_PATH_PREFIXES)
    )
    if breaches:
        return InvariantResult(
            invariant=InvariantName.SEPARATION,
            passed=False,
            severity="warn",
            message=f"governance reached into substrate: {breaches}",
            detail={
                "breaches": breaches,
                "agent_id": getattr(state, "agent_id", "<unknown>"),
            },
        )
    return InvariantResult(
        invariant=InvariantName.SEPARATION, passed=True
    )


def check_fusion(
    state: AgentState,
    parallel_branches: Optional[Sequence[Mapping[str, Any]]] = None,
) -> InvariantResult:
    """Verify parallel branch outcomes funnel through the normaliser.

    When multiple sub-agents run in parallel, each branch outcome MUST
    carry a ``"normaliser"`` key proving it routed through the merge
    funnel. Bare dicts / non-mapping outcomes bypass the funnel and
    therefore violate fusion (state diverges across branches).
    """
    branches: list[Any] = (
        list(parallel_branches)
        if parallel_branches is not None
        else list(getattr(state, "parallel_branches", ()) or ())
    )
    if not branches:
        return InvariantResult(
            invariant=InvariantName.FUSION, passed=True
        )

    bypassed: list[int] = []
    for idx, outcome in enumerate(branches):
        if outcome is None:
            continue
        if not isinstance(outcome, Mapping):
            bypassed.append(idx)
            continue
        if "normaliser" not in outcome:
            bypassed.append(idx)

    if bypassed:
        return InvariantResult(
            invariant=InvariantName.FUSION,
            passed=False,
            severity="warn",
            message=(
                f"{len(bypassed)} branch(es) bypassed normaliser "
                f"(positions {bypassed})"
            ),
            detail={
                "bypassed": bypassed,
                "total": len(branches),
                "agent_id": getattr(state, "agent_id", "<unknown>"),
            },
        )
    return InvariantResult(
        invariant=InvariantName.FUSION, passed=True
    )


def check_autonomy(
    state: AgentState,
    sub_agent_ctx: Optional[SubAgentCtx] = None,
) -> InvariantResult:
    """Verify sub-agent ctx is independent of parent mutable state.

    Two ways to fail:

    * ``leaks_parent_secrets`` — the bundle exposes parent-only data
      (e.g. user credentials, API keys, internal-only governance
      cursor) to the child.
    * ``aliased_state_keys`` non-empty — the bundle shares a mutable
      handle (list, dict, set) with the parent so the child can
      clobber the parent's run history.
    """
    candidates: list[SubAgentCtx] = []
    if sub_agent_ctx is not None:
        candidates.append(sub_agent_ctx)
    candidates.extend(getattr(state, "sub_agents", ()) or ())

    if not candidates:
        return InvariantResult(
            invariant=InvariantName.AUTONOMY, passed=True
        )

    failed: list[dict[str, Any]] = []
    for ctx in candidates:
        reasons: list[str] = []
        if getattr(ctx, "leaks_parent_secrets", False):
            reasons.append("leaks_parent_secrets")
        aliased = tuple(getattr(ctx, "aliased_state_keys", ()) or ())
        if aliased:
            reasons.append(f"aliased_state_keys={list(aliased)}")
        if reasons:
            failed.append(
                {
                    "child": getattr(ctx, "agent_id", "<unknown>"),
                    "parent": getattr(
                        ctx, "parent_agent_id", "<unknown>"
                    ),
                    "reasons": reasons,
                }
            )
    if failed:
        return InvariantResult(
            invariant=InvariantName.AUTONOMY,
            passed=False,
            severity="warn",
            message=(
                f"{len(failed)} sub-agent ctx(s) violate autonomy"
            ),
            detail={
                "violations": failed,
                "agent_id": getattr(state, "agent_id", "<unknown>"),
            },
        )
    return InvariantResult(
        invariant=InvariantName.AUTONOMY, passed=True
    )


# ─── ZIQ outcome recorder ───────────────────────────────────────


def _ftrl_recorder() -> Optional[Callable[..., None]]:
    """Resolve ``concinno.ziq_persist.record_ftrl_update`` lazily.

    Best-effort import — when concinno is not installed the recorder
    is None and the violation is still persisted to the local jsonl
    trail (the FTRL signal is the *Concinno-novel* layer; the local
    trail works without it).
    """
    try:
        from concinno.ziq_persist import record_ftrl_update

        return record_ftrl_update
    except Exception:  # pragma: no cover — concinno not installed
        return None


def record_violation(
    invariant_name: str,
    details: Mapping[str, Any],
) -> None:
    """Persist one invariant violation.

    Two sinks (best-effort, both fail-open):

    * Append to the date-partitioned jsonl trail under
      ``~/.concinno-king/invariant_violations/<YYYY-MM-DD>.jsonl``
      (via :mod:`agent.invariants_state`).
    * Negative FTRL signal (-1.0) to
      ``concinno.ziq_persist.record_ftrl_update`` with feature
      ``"agent_invariants"`` and key = the invariant name. The
      recorder reads/writes the snapshot atomically so concurrent
      agents do not race.
    """
    name = str(invariant_name)
    detail_dict = dict(details or {})

    # Sink 1 — local jsonl trail.
    try:
        append_violation_record(name, detail_dict)
    except Exception as exc:  # pragma: no cover
        sys.stderr.write(
            f"[invariants] persist failed: {exc!r}\n"
        )

    # Sink 2 — ZIQ FTRL negative signal.
    recorder = _ftrl_recorder()
    if recorder is None:
        return
    try:
        # We don't have a real FTRL weight in scope; the row is
        # purely an outcome marker. Pass identical before/after so
        # downstream auditors can still see the negative signal.
        recorder(
            feature="agent_invariants",
            key=name,
            weight_before=1.0,
            weight_after=1.0,
            signal=-1.0,
            posterior_components={
                "violation_detail": detail_dict,
            },
        )
    except Exception as exc:  # pragma: no cover
        sys.stderr.write(
            f"[invariants] ZIQ recorder failed: {exc!r}\n"
        )


def _route_failures(results: Iterable[InvariantResult]) -> None:
    """Route any failed result to the persistent recorder."""
    for r in results:
        if r.passed:
            continue
        record_violation(r.invariant.value, r.detail)


def get_recent_violations(limit: int = 50) -> list[dict[str, Any]]:
    """Return the most-recent ``limit`` violation records.

    Re-export from :mod:`agent.invariants_state` so the CLI can
    ``from agent.invariants import get_recent_violations`` without
    knowing about the state-module layout.
    """
    return list_recent_violations(limit=limit)


# ─── Loop-mechanics registry (preserved from B3-stub) ──────────


CheckFn = Callable[[Any, str], None]
"""Signature: ``check(state, phase) -> None`` raising on violation.

``phase`` is ``"pre"`` or ``"post"`` so the same callable can decide
whether to run on entry, exit, or both.
"""


@dataclass
class _Registry:
    """Module-level registry of loop-mechanics callables.

    Plain dataclass (not module globals) so tests can swap the
    registry via :func:`register_check` without leaking into other
    tests.
    """

    pre: list[CheckFn] = field(default_factory=list)
    post: list[CheckFn] = field(default_factory=list)


_REGISTRY = _Registry()


def _check_message_monotonic(state: Any, phase: str) -> None:
    """Message list never shrinks across the loop.

    Reads ``state._invariant_last_msg_count`` (set by us) so we don't
    lean on dataclass-private fields. First call records baseline.
    """
    msgs = getattr(state, "messages", None)
    if msgs is None:
        return
    n = len(msgs)
    last_attr = "_invariant_last_msg_count"
    last = getattr(state, last_attr, None)
    if last is None:
        try:
            setattr(state, last_attr, n)
        except (AttributeError, TypeError):
            pass
        return
    if n < last:
        raise InvariantViolation(
            None,
            f"message list shrank: was {last}, now {n} (phase={phase})",
        )
    if phase == "post":
        try:
            setattr(state, last_attr, n)
        except (AttributeError, TypeError):
            pass


def _check_iteration_bounded(state: Any, phase: str) -> None:
    """Iteration counter is sane.

    Refuses negatives; refuses values exceeding ``max_iterations`` if
    the loop exposes that attribute (it does in our implementation).
    """
    iters = getattr(state, "iterations", 0)
    if iters < 0:
        raise InvariantViolation(
            None,
            f"iterations went negative: {iters} (phase={phase})",
        )
    cap = getattr(state, "_max_iterations_hint", None)
    if cap is not None and iters > cap + 1:
        raise InvariantViolation(
            None,
            f"iterations {iters} exceeds cap {cap} (phase={phase})",
        )


def _check_done_implies_stop(state: Any, phase: str) -> None:
    """Once ``done`` is True, a stop reason must be set."""
    if getattr(state, "done", False) and not getattr(
        state, "stop_reason", ""
    ):
        raise InvariantViolation(
            None,
            f"state.done=True but stop_reason is empty (phase={phase})",
        )


def default_checks() -> list[CheckFn]:
    """Return the canonical 3-check baseline used at module load."""
    return [
        _check_message_monotonic,
        _check_iteration_bounded,
        _check_done_implies_stop,
    ]


# Pre/post split — all three baseline checks run in BOTH phases since
# they're cheap. B4-full may split for finer control.
for _check in default_checks():
    _REGISTRY.pre.append(_check)
    _REGISTRY.post.append(_check)


def register_check(
    fn: CheckFn,
    *,
    phase: str = "both",
) -> CheckFn:
    """Add ``fn`` to the registry. Returns ``fn`` for use as decorator.

    ``phase`` ∈ {``"pre"``, ``"post"``, ``"both"``}.
    """
    if phase in {"pre", "both"}:
        _REGISTRY.pre.append(fn)
    if phase in {"post", "both"}:
        _REGISTRY.post.append(fn)
    if phase not in {"pre", "post", "both"}:
        logger.warning(
            "register_check: unknown phase %r — ignoring", phase,
        )
    return fn


def list_checks(phase: str = "pre") -> list[CheckFn]:
    """Return the registered check list for ``phase`` (snapshot)."""
    if phase == "pre":
        return list(_REGISTRY.pre)
    if phase == "post":
        return list(_REGISTRY.post)
    raise ValueError(f"phase must be pre|post, got {phase!r}")


# ─── Public step-boundary entry points ─────────────────────────


def _run_registry(state: Any, phase: str) -> None:
    """Run the loop-mechanics registry for ``phase`` (raise-fast)."""
    checks = _REGISTRY.pre if phase == "pre" else _REGISTRY.post
    for check in checks:
        check(state, phase)


def _is_agent_state(state: Any) -> bool:
    """Heuristic: state has architectural attrs we can check."""
    return (
        hasattr(state, "governance_writes")
        or hasattr(state, "parallel_branches")
        or hasattr(state, "sub_agents")
    )


def pre_step_check(state: Any) -> List[InvariantResult]:
    """Run all pre-step invariants.

    1. Loop-mechanics registry (B3-stub: msg monotonic, iter bounded,
       done implies stop) — raises :class:`InvariantViolation` on
       failure (the loop catches and surfaces as a tool error).
    2. Architectural separation invariant (only when state is an
       :class:`AgentState`) — failures recorded as negative ZIQ FTRL
       signal and returned as :class:`InvariantResult` list. Fatal
       severity also raises.

    Returns the list of architectural results so the caller can
    log/aggregate. Old B3-stub callers can ignore the return value.
    """
    _run_registry(state, "pre")

    if not _is_agent_state(state):
        return []

    results: List[InvariantResult] = [check_separation(state)]
    _route_failures(results)
    for r in results:
        if not r.passed and r.severity == "fatal":
            raise InvariantViolation(
                r.invariant, r.message, r.detail
            )
    return results


def post_step_check(
    state: Any,
    step_result: Optional[Mapping[str, Any]] = None,
) -> List[InvariantResult]:
    """Run all post-step invariants (registry + arch contract).

    Architectural layer runs separation + fusion + autonomy. ``step_result``
    is currently unused by the architectural checks — it's accepted
    for forward-compatibility (B5+ may inspect step output to detect
    fusion bypasses dynamically).
    """
    _ = step_result  # reserved for future use; silence unused-arg lint
    _run_registry(state, "post")

    if not _is_agent_state(state):
        return []

    results: List[InvariantResult] = [
        check_separation(state),
        check_fusion(state),
        check_autonomy(state),
    ]
    _route_failures(results)
    for r in results:
        if not r.passed and r.severity == "fatal":
            raise InvariantViolation(
                r.invariant, r.message, r.detail
            )
    return results
