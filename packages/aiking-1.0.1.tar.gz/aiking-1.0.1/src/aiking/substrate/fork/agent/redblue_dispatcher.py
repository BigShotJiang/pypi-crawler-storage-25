# SPDX-License-Identifier: MIT
"""concinno-king.agent.redblue_dispatcher — Opus dispatcher abstraction.

@module agent.redblue_dispatcher
@responsibility Provide an :class:`AgentDispatcher`-conforming dispatcher
    that the red-blue-green CBUA review layer can use to call Opus
    Max (or any sufficiently capable model) WITHOUT binding the agent
    loop to a specific SDK. Tests pass an in-process mock; the
    real CLI passes an Anthropic-backed dispatcher; Sancio runtime
    can swap in its own.
@dependencies
    concinno.guards.redblue_green_dispatch_guard.AgentDispatcher
        (Protocol target — not imported at module load to keep the
        loop importable when concinno is absent in dev environments).
@exports DispatchResult, MockDispatcher, AnthropicDispatcher,
    OpenAIDispatcher, build_dispatcher, NullDispatcher

Design notes
------------
* The Concinno guard's :class:`AgentDispatcher` Protocol expects a
  single method ``dispatch(prompt, *, model, role) -> str``. Anything
  matching the structural type works; we don't subclass it directly
  to keep this file standalone-importable.
* Default model is Opus Max (the strongest available 1M-ctx model) —
  Concinno red-team rule (``rules/L1/redteam.md`` ⛔ Model pin) is
  explicit: do not downgrade to Sonnet/Haiku for cost — that returns
  the layer to 45/100 effective capability per the 2026-04 ablation.
* :func:`build_dispatcher` is a one-liner factory that picks an
  implementation by env var so callers don't have to ``isinstance``
  on backend names.
"""

from __future__ import annotations

import json
import logging
import os
import time
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)


# ── canonical model name (Concinno red-team rule) ────────────────────

DEFAULT_OPUS_MODEL: str = os.environ.get(
    "CONCINNO_KING_OPUS_MODEL",
    "claude-opus-4-7-20260301",
)
"""Pinned to Opus Max per ``rules/L1/redteam.md`` ⛔ Model pin.

The L1 rule is explicit: red-team / blue-team / green-team dispatches
MUST use the strongest Anthropic model available. Override via the
env var **only** when ablating the layer itself — never to save cost
on real reviews. Cost-saving downgrades drop layer effective IQ from
~88 to ~45 per the 2026-04 measurement.
"""


# ── result + base class ─────────────────────────────────────────────


@dataclass(frozen=True)
class DispatchResult:
    """Captured result of one dispatcher call. Diagnostic only.

    The Concinno guard's Protocol only asks for the raw string back;
    this dataclass exists so callers (and tests) can audit *what*
    actually went out without re-instrumenting every dispatcher.
    """

    prompt: str
    response: str
    role: str
    model: str
    latency_ms: int
    error: Optional[str] = None


class _DispatcherBase:
    """Common timing + logging skeleton.

    Subclasses override :meth:`_call`. All dispatchers share the same
    ``dispatch`` outer wrapper so latency / logging is uniform.
    """

    name: str = "base"

    def dispatch(
        self,
        prompt: str,
        *,
        model: str = DEFAULT_OPUS_MODEL,
        role: str = "red",
    ) -> str:
        start = time.monotonic()
        err: Optional[str] = None
        response: str = ""
        try:
            response = self._call(prompt, model=model, role=role)
        except Exception as exc:  # noqa: BLE001 — surface as JSON, not crash
            err = repr(exc)
            response = json.dumps(
                {"summary": f"(dispatch error: {err})", "findings": []},
            )
            logger.warning(
                "redblue dispatcher %s raised: %s", self.name, err,
            )

        elapsed = int((time.monotonic() - start) * 1000)
        logger.debug(
            "redblue.%s role=%s model=%s elapsed_ms=%d err=%s",
            self.name,
            role,
            model,
            elapsed,
            err,
        )
        return response

    def _call(self, prompt: str, *, model: str, role: str) -> str:
        raise NotImplementedError


# ── mock (offline tests) ────────────────────────────────────────────


@dataclass
class MockDispatcher(_DispatcherBase):
    """Scripted dispatcher for offline tests.

    Pass a ``responses`` mapping role -> json-string. Calls accumulate
    into ``calls`` for assertion. Default response is the empty-but-
    valid red/blue JSON shape so the parsing path inside the guard
    treats them as benign.
    """

    name: str = "mock"
    responses: dict[str, str] = field(default_factory=dict)
    calls: list[DispatchResult] = field(default_factory=list)

    def _call(self, prompt: str, *, model: str, role: str) -> str:
        canned = self.responses.get(
            role,
            json.dumps({"summary": f"(mock {role})", "findings": []}),
        )
        self.calls.append(
            DispatchResult(
                prompt=prompt,
                response=canned,
                role=role,
                model=model,
                latency_ms=0,
            ),
        )
        return canned


# ── null (production fail-safe) ─────────────────────────────────────


class NullDispatcher(_DispatcherBase):
    """Dispatcher that returns empty findings.

    Used when the user explicitly opted out of redblue review at
    config time but the loop still wants a callable to plug in
    without ``None``-checks in hot paths. Always returns the
    ACCEPT-equivalent empty findings JSON.
    """

    name: str = "null"

    def _call(self, prompt: str, *, model: str, role: str) -> str:
        return json.dumps(
            {"summary": f"(null {role} — review disabled)", "findings": []},
        )


# ── anthropic-backed (real production) ──────────────────────────────


@dataclass
class AnthropicDispatcher(_DispatcherBase):
    """Anthropic-backed dispatcher.

    Lazy-imports ``anthropic`` so this module stays importable in
    environments without the SDK (CI, headless test runners). Falls
    back to NullDispatcher behaviour with a warning if the SDK or the
    API key is missing — never crashes the agent loop.
    """

    name: str = "anthropic"
    api_key: Optional[str] = None
    max_tokens: int = 4096

    def _call(self, prompt: str, *, model: str, role: str) -> str:
        try:
            import anthropic  # type: ignore
        except ImportError:
            logger.warning(
                "anthropic SDK not installed — falling back to empty review",
            )
            return json.dumps(
                {"summary": f"(no anthropic SDK — {role})", "findings": []},
            )

        key = self.api_key or os.environ.get("ANTHROPIC_API_KEY")
        if not key:
            logger.warning(
                "ANTHROPIC_API_KEY missing — falling back to empty review",
            )
            return json.dumps(
                {"summary": f"(no API key — {role})", "findings": []},
            )

        client = anthropic.Anthropic(api_key=key)
        msg = client.messages.create(
            model=model,
            max_tokens=self.max_tokens,
            messages=[{"role": "user", "content": prompt}],
        )
        # Anthropic returns a list of content blocks; concatenate text.
        if hasattr(msg, "content") and isinstance(msg.content, list):
            parts = [
                getattr(b, "text", "")
                for b in msg.content
                if getattr(b, "type", None) == "text"
            ]
            return "\n".join(p for p in parts if p)
        return getattr(msg, "content", "") or ""


# ── openai-backed (compat for shops on OpenAI) ──────────────────────


@dataclass
class OpenAIDispatcher(_DispatcherBase):
    """OpenAI-backed dispatcher (for environments without Anthropic).

    Same lazy-import + fail-safe pattern as :class:`AnthropicDispatcher`.
    Used when the operator wants to run reviews on GPT-class models
    (downgrade vs the Concinno pin, but better than nothing in air-
    gapped or compliance-restricted setups).
    """

    name: str = "openai"
    api_key: Optional[str] = None
    base_url: Optional[str] = None
    max_tokens: int = 4096

    def _call(self, prompt: str, *, model: str, role: str) -> str:
        try:
            from openai import OpenAI  # type: ignore
        except ImportError:
            logger.warning(
                "openai SDK not installed — falling back to empty review",
            )
            return json.dumps(
                {"summary": f"(no openai SDK — {role})", "findings": []},
            )

        key = self.api_key or os.environ.get("OPENAI_API_KEY")
        if not key:
            logger.warning(
                "OPENAI_API_KEY missing — falling back to empty review",
            )
            return json.dumps(
                {"summary": f"(no API key — {role})", "findings": []},
            )

        client = OpenAI(api_key=key, base_url=self.base_url)
        resp = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=self.max_tokens,
        )
        try:
            return resp.choices[0].message.content or ""
        except (AttributeError, IndexError):
            return ""


# ── factory ─────────────────────────────────────────────────────────


def build_dispatcher(
    backend: Optional[str] = None,
    *,
    api_key: Optional[str] = None,
) -> _DispatcherBase:
    """Pick a dispatcher implementation by name (env-overridable).

    Resolution order:
        1. ``backend`` arg if given.
        2. env ``CONCINNO_KING_REDBLUE_BACKEND`` if set.
        3. fallback: ``"anthropic"``.

    Recognised values: ``anthropic``, ``openai``, ``mock``, ``null``,
    ``disabled`` (alias for ``null``). Unknown values fall through to
    ``null`` with a warning so a typo never crashes the loop.
    """
    chosen = (
        backend
        or os.environ.get("CONCINNO_KING_REDBLUE_BACKEND", "")
        or "anthropic"
    ).strip().lower()

    if chosen in {"null", "disabled", "off"}:
        return NullDispatcher()
    if chosen == "mock":
        return MockDispatcher()
    if chosen == "openai":
        return OpenAIDispatcher(api_key=api_key)
    if chosen == "anthropic":
        return AnthropicDispatcher(api_key=api_key)

    logger.warning(
        "unknown redblue backend %r — falling back to null", chosen,
    )
    return NullDispatcher()


__all__ = [
    "DEFAULT_OPUS_MODEL",
    "AnthropicDispatcher",
    "DispatchResult",
    "MockDispatcher",
    "NullDispatcher",
    "OpenAIDispatcher",
    "build_dispatcher",
]
