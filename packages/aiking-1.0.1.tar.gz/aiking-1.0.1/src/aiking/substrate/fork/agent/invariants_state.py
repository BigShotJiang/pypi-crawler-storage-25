# SPDX-License-Identifier: MIT
"""concinno-king.agent.invariants_state — disk persistence for violations.

@module agent.invariants_state
@responsibility Date-partitioned jsonl trail for invariant violations
    raised by :mod:`agent.invariants`. Sister-file pattern mirrors
    :mod:`concinno.ziq_persist` so the per-week ``scavenger`` reflexion
    loop (per L1 ``cbua.md`` § Timescale Governance, axis B) can scan
    these files alongside ZIQ outcomes.

@dependencies stdlib only.

@exports
    state_dir, jsonl_path, append_violation_record,
    list_recent_violations.

Layout
------
::

    ~/.concinno-king/invariant_violations/
        2026-05-02.jsonl
        2026-05-03.jsonl
        ...

Each row is one JSON object::

    {"ts": "<ISO-8601>",
     "invariant": "<separation|fusion|autonomy>",
     "detail": {<arbitrary>}}

Failure mode
------------
Best-effort. Permission errors / disk full / corrupt JSON return cold-
start defaults (empty list on read; silent skip on write). The agent
loop never sees an exception from this module — invariant accounting
must not be the reason the agent crashed.

Switchability
-------------
Honours ``CONCINNO_KING_INVARIANT_PERSIST_DISABLED=1|true|yes|on`` —
collapses every public function to a fail-open no-op. State dir
override via ``CONCINNO_KING_INVARIANT_STATE_DIR=<path>`` (used by
tests).
"""
from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


__all__ = [
    "state_dir",
    "jsonl_path",
    "append_violation_record",
    "list_recent_violations",
    "is_disabled",
]


_DISABLE_VALUES = frozenset({"1", "true", "yes", "on"})


def is_disabled() -> bool:
    """Return True when the kill-switch env is set."""
    raw = os.environ.get(
        "CONCINNO_KING_INVARIANT_PERSIST_DISABLED", ""
    )
    return raw.strip().lower() in _DISABLE_VALUES


def state_dir() -> Path:
    """Resolve the directory for invariant violation jsonl files."""
    override = os.environ.get("CONCINNO_KING_INVARIANT_STATE_DIR")
    if override:
        return Path(override).expanduser()
    return Path.home() / ".concinno-king" / "invariant_violations"


def jsonl_path(date: str | None = None) -> Path:
    """Path to the date-partitioned jsonl file (UTC date by default)."""
    if date is None:
        date = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    return state_dir() / f"{date}.jsonl"


def _utc_iso() -> str:
    return (
        datetime.now(timezone.utc)
        .replace(microsecond=0)
        .isoformat()
        .replace("+00:00", "Z")
    )


def append_violation_record(
    invariant: str,
    detail: dict[str, Any],
) -> None:
    """Append one violation row to today's jsonl (best-effort)."""
    if is_disabled() or not invariant:
        return
    row: dict[str, Any] = {
        "ts": _utc_iso(),
        "invariant": str(invariant),
    }
    try:
        row["detail"] = dict(detail or {})
    except (TypeError, ValueError):
        row["detail"] = {}
    try:
        encoded = json.dumps(row, ensure_ascii=False, sort_keys=True)
    except (TypeError, ValueError):
        return
    path = jsonl_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as fh:
            fh.write(encoded + "\n")
    except OSError:
        return


def _iter_jsonl_files() -> Iterable[Path]:
    """Yield jsonl files in the state dir, newest first."""
    root = state_dir()
    if not root.exists():
        return
    try:
        files = sorted(
            root.glob("*.jsonl"),
            key=lambda p: p.name,
            reverse=True,
        )
    except OSError:
        return
    for path in files:
        yield path


def list_recent_violations(
    *, limit: int = 50
) -> list[dict[str, Any]]:
    """Return up to ``limit`` most-recent violation rows.

    Reads jsonl files newest-first; within a file rows are appended
    chronologically so reverse-iterate the lines for newest-first.
    Corrupt rows are skipped silently.
    """
    if is_disabled() or limit <= 0:
        return []
    out: list[dict[str, Any]] = []
    for path in _iter_jsonl_files():
        try:
            with path.open("r", encoding="utf-8") as fh:
                lines = fh.readlines()
        except OSError:
            continue
        for line in reversed(lines):
            line = line.strip()
            if not line:
                continue
            try:
                row = json.loads(line)
            except (TypeError, ValueError):
                continue
            if not isinstance(row, dict):
                continue
            out.append(row)
            if len(out) >= limit:
                return out
    return out
