# SPDX-License-Identifier: MIT
"""AI King substrate.fork — vendored Concinno-King / Lyceum Agent code.

Hermes-derived substrate (MIT licensed). License firewall: this layer
is MIT and MUST NOT import aiking_core (AGPL). New aiking shell code
(adapter.py / hermes.py / capabilities.py at substrate/ root) is
Apache 2.0; only the vendored fork content here is MIT.

See LICENSE-MIT-Hermes for upstream attribution.
"""

__all__ = [
    "agent",
    "governance",
    "evolution",
    "messaging",
    "sandbox",
    "providers",
    "skills",
    "cli",
    "_compat",
    "constants",
]
