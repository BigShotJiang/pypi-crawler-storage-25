# SPDX-License-Identifier: MIT
"""Unified spawn API for the sandbox backends.

Eight backends are exposed:

  - ``local``         — ``LocalEnvironment``         (host shell, no SDK)
  - ``docker``        — ``DockerEnvironment``        (needs docker CLI)
  - ``ssh``           — ``SSHEnvironment``           (needs ssh client)
  - ``singularity``   — ``SingularityEnvironment``   (needs apptainer / singularity)
  - ``daytona``       — ``DaytonaEnvironment``       (needs ``daytona`` PyPI pkg)
  - ``modal``         — ``ModalEnvironment``         (needs ``modal`` PyPI pkg)
  - ``managed_modal`` — ``ManagedModalEnvironment``  (needs gateway URL + token)
  - ``vercel``        — ``VercelSandboxEnvironment`` (needs ``vercel-sdk`` + ``httpx``)

The registry uses **lazy imports** for every backend so listing
``KNOWN_BACKENDS`` and inspecting available ones never forces an import
of an unavailable SDK.  ``list_backends()`` returns the subset that can
be imported in the current environment; ``spawn(name, **kwargs)``
constructs an instance and surfaces a clear
:class:`BackendNotAvailableError` when the SDK is missing.
"""

from __future__ import annotations

import importlib
from typing import Any, Callable

# Re-export BaseEnvironment for type hints in callers.
from .base import BaseEnvironment

__all__ = [
    "KNOWN_BACKENDS",
    "BackendNotAvailableError",
    "UnknownBackendError",
    "list_backends",
    "list_known_backends",
    "register_backend",
    "spawn",
]


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class UnknownBackendError(ValueError):
    """Raised when ``spawn(name, ...)`` receives an unrecognised backend name."""


class BackendNotAvailableError(RuntimeError):
    """Raised when a backend's SDK / runtime is not installed.

    Carries the underlying :class:`ImportError` (if any) as ``__cause__``
    so callers can introspect what was missing.
    """


# ---------------------------------------------------------------------------
# Backend registry
# ---------------------------------------------------------------------------
#
# Each entry maps the backend's public name to ``(module_name, class_name)``.
# Lazy imports keep startup fast and let callers list backends without
# triggering ``ImportError`` for SDKs they don't have installed.

_BACKEND_REGISTRY: dict[str, tuple[str, str]] = {
    "local": ("concinno_king.sandbox.local", "LocalEnvironment"),
    "docker": ("concinno_king.sandbox.docker", "DockerEnvironment"),
    "ssh": ("concinno_king.sandbox.ssh", "SSHEnvironment"),
    "singularity": (
        "concinno_king.sandbox.singularity",
        "SingularityEnvironment",
    ),
    "daytona": ("concinno_king.sandbox.daytona", "DaytonaEnvironment"),
    "modal": ("concinno_king.sandbox.modal", "ModalEnvironment"),
    "managed_modal": (
        "concinno_king.sandbox.managed_modal",
        "ManagedModalEnvironment",
    ),
    "vercel": (
        "concinno_king.sandbox.vercel_sandbox",
        "VercelSandboxEnvironment",
    ),
}

# Public read-only view (frozenset of names) so external code can't mutate.
KNOWN_BACKENDS: frozenset[str] = frozenset(_BACKEND_REGISTRY)

# Custom factories registered via :func:`register_backend`.  Keyed by
# backend name, value is a callable returning a ``BaseEnvironment``.
_CUSTOM_FACTORIES: dict[str, Callable[..., BaseEnvironment]] = {}


# ---------------------------------------------------------------------------
# Resolver
# ---------------------------------------------------------------------------
#
# In an installed package the modules live at ``concinno_king.sandbox.X``,
# but during local development the project uses a flat layout where
# ``sandbox`` is its own top-level package (no outer ``concinno_king``
# package on the import path).  We therefore try the full dotted name
# first, then fall back to the relative form.


def _import_backend_class(module_name: str, class_name: str) -> type:
    """Import *class_name* from *module_name*, with flat-layout fallback."""
    candidates = [module_name]
    if module_name.startswith("concinno_king.sandbox."):
        # Fall back to flat layout: ``concinno_king.sandbox.local`` →
        # ``sandbox.local`` (when ``concinno_king`` is not on sys.path).
        candidates.append(module_name.split(".", 1)[1])

    last_err: Exception | None = None
    for name in candidates:
        try:
            module = importlib.import_module(name)
            return getattr(module, class_name)
        except ImportError as exc:
            last_err = exc
            continue
        except AttributeError as exc:
            raise BackendNotAvailableError(
                f"backend module '{name}' loaded but does not expose "
                f"'{class_name}'"
            ) from exc

    raise BackendNotAvailableError(
        f"backend '{class_name}' could not be imported from any of "
        f"{candidates}: {last_err}"
    ) from last_err


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def list_known_backends() -> list[str]:
    """Return all backend names this build knows about, sorted.

    Includes backends whose SDK is not installed — see
    :func:`list_backends` for the importable subset.
    """
    return sorted(set(_BACKEND_REGISTRY) | set(_CUSTOM_FACTORIES))


def list_backends() -> list[str]:
    """Return the backends that can actually be imported in this env.

    Performs a lazy import probe for each registered backend and returns
    the names of the ones that load cleanly.  ``local`` is always
    available because it has no third-party dependencies.

    Custom backends registered via :func:`register_backend` are always
    listed because the caller already proved the factory works.
    """
    available: list[str] = []
    for name, (mod, cls) in _BACKEND_REGISTRY.items():
        try:
            _import_backend_class(mod, cls)
        except BackendNotAvailableError:
            continue
        available.append(name)
    available.extend(_CUSTOM_FACTORIES)
    return sorted(set(available))


def register_backend(
    name: str,
    factory: Callable[..., BaseEnvironment],
    *,
    overwrite: bool = False,
) -> None:
    """Plug a custom backend factory into the registry.

    ``factory(**kwargs)`` must return a :class:`BaseEnvironment`.

    ``overwrite=False`` (default) refuses to clobber an existing name —
    callers must opt in via ``overwrite=True`` so the failure mode of
    name collisions is loud.
    """
    if not name or not isinstance(name, str):
        raise ValueError(f"backend name must be a non-empty string, got {name!r}")
    if not callable(factory):
        raise TypeError(f"backend factory must be callable, got {type(factory)!r}")

    name_lower = name.lower()
    if (
        not overwrite
        and (name_lower in _BACKEND_REGISTRY or name_lower in _CUSTOM_FACTORIES)
    ):
        raise ValueError(
            f"backend '{name_lower}' already registered "
            f"(pass overwrite=True to replace)"
        )
    _CUSTOM_FACTORIES[name_lower] = factory


def spawn(backend: str, **kwargs: Any) -> BaseEnvironment:
    """Construct a sandbox environment by name.

    Parameters
    ----------
    backend
        One of :data:`KNOWN_BACKENDS` (or a name registered via
        :func:`register_backend`).  Case-insensitive.
    **kwargs
        Forwarded to the backend constructor.  Each backend has its own
        signature — see the per-backend module for details.

    Returns
    -------
    BaseEnvironment
        Initialised, ready for ``.execute(...)`` calls.

    Raises
    ------
    UnknownBackendError
        If *backend* is not in :data:`KNOWN_BACKENDS` and no custom
        factory of that name was registered.
    BackendNotAvailableError
        If the backend exists but its underlying SDK / runtime is not
        installed (e.g. the ``daytona`` package is missing, or
        ``docker`` is not on PATH).
    """
    if not isinstance(backend, str) or not backend:
        raise UnknownBackendError(
            f"backend name must be a non-empty string, got {backend!r}"
        )

    name = backend.lower()

    # Custom factories win (they were explicitly registered by the caller).
    factory = _CUSTOM_FACTORIES.get(name)
    if factory is not None:
        return factory(**kwargs)

    entry = _BACKEND_REGISTRY.get(name)
    if entry is None:
        raise UnknownBackendError(
            f"unknown backend '{backend}'; "
            f"known: {sorted(_BACKEND_REGISTRY)}"
        )

    module_name, class_name = entry
    cls = _import_backend_class(module_name, class_name)
    return cls(**kwargs)
