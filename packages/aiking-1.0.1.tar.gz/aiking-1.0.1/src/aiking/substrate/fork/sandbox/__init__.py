# SPDX-License-Identifier: MIT
"""concinno-king sandbox execution backends.

Each backend provides the same interface (:class:`BaseEnvironment`) for
running shell commands in a specific execution context: local, Docker,
Singularity, SSH, Modal (direct + managed), Daytona, or Vercel Sandbox.

The :func:`registry.spawn` factory selects the backend by name; see
``concinno_king.sandbox.registry`` for the unified API.

This subpackage was ported verbatim from Lyceum's
``tools/environments/`` (Hermes Agent / Lyceum, MIT-licensed — see
``NOTICE`` in this directory).  Lyceum-internal modules referenced by
the backends (``lyceum_constants``, ``tools.interrupt``,
``tools.terminal_tool``, ``tools.env_passthrough``,
``tools.credential_files``, ``tools.managed_tool_gateway``,
``lyceum_cli.*``) are stubbed via :mod:`._compat`, which registers the
shim modules in :data:`sys.modules` at import time.  Real Lyceum
deployments that already have those modules installed bypass the shim
layer (Python's import system finds the real package first).
"""

# IMPORTANT: ``_compat`` MUST be imported before any backend module so its
# ``sys.modules`` shim registration runs before the backends try to import
# ``lyceum_constants`` / ``tools.interrupt`` etc.
from . import _compat  # noqa: F401  — side-effect: registers sys.modules shims

from .base import BaseEnvironment
from .registry import (
    KNOWN_BACKENDS,
    BackendNotAvailableError,
    UnknownBackendError,
    list_backends,
    list_known_backends,
    register_backend,
    spawn,
)

__all__ = [
    "BaseEnvironment",
    "KNOWN_BACKENDS",
    "BackendNotAvailableError",
    "UnknownBackendError",
    "list_backends",
    "list_known_backends",
    "register_backend",
    "spawn",
]
