# SPDX-License-Identifier: MIT
"""Compatibility shims for symbols that were imported from Lyceum-internal
modules (``lyceum_constants``, ``tools.interrupt``, ``tools.terminal_tool``,
``tools.env_passthrough``, ``tools.credential_files``,
``tools.managed_tool_gateway``, ``lyceum_cli.*``) in the upstream source.

The sandbox subpackage was ported verbatim from
``lyceum/tools/environments/``.  Rather than copy across the entire Lyceum
runtime (CLI, config, credential vault, gateway resolver, …) we provide
narrow no-op shims here that match the call signatures the backends rely
on.  Each shim is documented with the upstream module it came from so the
porting trail stays auditable.

Behavioural notes
-----------------
* :func:`get_lyceum_home` returns ``~/.concinno-king/`` instead of
  ``~/.lyceum/`` — the data root is renamed, but the layout under it
  (``sandboxes/``, ``home/``) matches.
* :func:`is_interrupted` always returns ``False``.  In Lyceum this is set
  by the gateway when the user cancels a tool call; concinno-king runs
  outside that gateway by default.  Callers can install their own
  implementation by overwriting :data:`_interrupt_check`.
* The credential / env-passthrough / managed-gateway shims all return
  empty / disabled values.  Backends that need those features (Docker
  credential mounts, managed-Modal, Lyceum env passthrough) will silently
  fall back to no-op behaviour, which matches what the upstream code
  already does in their try/except guards.
"""

from __future__ import annotations

import os
import sys
import types
from pathlib import Path
from typing import Callable

# ---------------------------------------------------------------------------
# Storage roots (was: lyceum_constants)
# ---------------------------------------------------------------------------


def get_lyceum_home() -> Path:
    """Return the concinno-king data root directory.

    Override location: set ``CONCINNO_KING_HOME`` (preferred) or fall back
    to the legacy ``LYCEUM_HOME`` for users migrating from upstream.
    """
    custom = os.getenv("CONCINNO_KING_HOME") or os.getenv("LYCEUM_HOME")
    if custom:
        path = Path(custom).expanduser()
    else:
        path = Path.home() / ".concinno-king"
    path.mkdir(parents=True, exist_ok=True)
    return path


def get_subprocess_home() -> str | None:
    """Return the per-profile HOME override used for spawned subprocesses.

    Lyceum uses this for tool-config isolation (git/ssh/gh/npm).  We expose
    the same hook via ``CONCINNO_KING_SUBPROCESS_HOME``; when unset, return
    ``None`` so callers fall through to the real ``$HOME``.
    """
    override = os.getenv("CONCINNO_KING_SUBPROCESS_HOME")
    if override:
        return override
    home_override = get_lyceum_home() / "home"
    if home_override.is_dir():
        return str(home_override)
    return None


# ---------------------------------------------------------------------------
# Interrupt protocol (was: tools.interrupt)
# ---------------------------------------------------------------------------


def _default_interrupt_check() -> bool:
    """Default interrupt predicate — never interrupted."""
    return False


_interrupt_check: Callable[[], bool] = _default_interrupt_check


def is_interrupted() -> bool:
    """Return True if the host gateway requested cancellation.

    Default implementation always returns False.  Replace
    ``concinno_king.sandbox._compat._interrupt_check`` if you want to wire
    this into your own cancellation protocol.
    """
    try:
        return bool(_interrupt_check())
    except Exception:
        return False


def set_interrupt_check(fn: Callable[[], bool]) -> None:
    """Install a custom interrupt predicate (called from the polling loop)."""
    global _interrupt_check
    _interrupt_check = fn


# ---------------------------------------------------------------------------
# Terminal tool helpers (was: tools.terminal_tool)
# ---------------------------------------------------------------------------


def _rewrite_compound_background(command: str) -> str:
    """Rewrite ``A && B &`` to ``A && { B & }`` to avoid the subshell-wait trap.

    Identity passthrough by default — a precise rewrite needs a bash AST and
    the upstream implementation is non-trivial.  Callers who need the
    subshell-wait fix should install the upstream version into
    ``sys.modules['tools.terminal_tool']`` before importing the backends.
    """
    return command


def _transform_sudo_command(command: str) -> tuple[str, str | None]:
    """Optionally rewrite ``sudo`` invocations to read SUDO_PASSWORD from stdin.

    Identity passthrough — concinno-king does not ship Lyceum's
    ``SUDO_PASSWORD`` lifecycle.  Returns ``(command, None)`` so the
    backends keep working without password injection.
    """
    return command, None


# ---------------------------------------------------------------------------
# Env passthrough (was: tools.env_passthrough)
# ---------------------------------------------------------------------------


def is_env_passthrough(_name: str) -> bool:
    """Whether the named env var should bypass the secret blocklist."""
    return False


def get_all_passthrough() -> set[str]:
    """Return the set of env-var names declared as passthrough."""
    return set()


# ---------------------------------------------------------------------------
# Credential files (was: tools.credential_files)
# ---------------------------------------------------------------------------


def get_credential_file_mounts() -> list[dict]:
    """Return ``[{"host_path": ..., "container_path": ...}, ...]`` for Docker."""
    return []


def get_skills_directory_mount() -> list[dict]:
    """Return mount specs for skill directories."""
    return []


def get_cache_directory_mounts() -> list[dict]:
    """Return mount specs for media cache directories (uploads, screenshots)."""
    return []


# ---------------------------------------------------------------------------
# Managed tool gateway (was: tools.managed_tool_gateway)
# ---------------------------------------------------------------------------


def resolve_managed_tool_gateway(*_args, **_kwargs):
    """Return a managed-tool-gateway client; raise if not configured.

    The managed-Modal backend uses this to look up a remote tool gateway.
    Default behaviour: raise so callers know to wire their own resolver.
    """
    raise RuntimeError(
        "concinno_king.sandbox does not bundle a managed_tool_gateway; "
        "install your own resolver into "
        "sys.modules['tools.managed_tool_gateway'] before importing the "
        "managed-Modal backend."
    )


# ---------------------------------------------------------------------------
# CLI config shims (was: lyceum_cli.config / lyceum_cli.auth)
# ---------------------------------------------------------------------------


def load_config() -> dict:
    """Return the user's terminal config dict."""
    return {}


def load_env() -> dict:
    """Return the user's ``~/.lyceum/.env`` map."""
    return {}


OPTIONAL_ENV_VARS: dict = {}
PROVIDER_REGISTRY: dict = {}


# ---------------------------------------------------------------------------
# sys.modules registration
# ---------------------------------------------------------------------------
#
# The verbatim-ported backends still contain ``from lyceum_constants import
# get_lyceum_home`` etc.  Rather than rewrite every line, register fake
# modules in ``sys.modules`` that re-export the shims above.  Anyone who
# wants the real Lyceum behaviour can install the real packages first and
# this shim layer is bypassed by Python's normal import resolution.


def _register_shim(name: str, attrs: dict) -> None:
    """Inject *attrs* into ``sys.modules[name]`` if not already present."""
    if name in sys.modules:
        return  # real package already loaded — never shadow it
    mod = types.ModuleType(name)
    for k, v in attrs.items():
        setattr(mod, k, v)
    sys.modules[name] = mod


# Register the parent packages first so attribute access works
# (``tools.interrupt.is_interrupted`` requires ``tools`` to exist).
_register_shim("tools", {})
_register_shim("lyceum_cli", {})

_register_shim(
    "lyceum_constants",
    {
        "get_lyceum_home": get_lyceum_home,
        "get_subprocess_home": get_subprocess_home,
    },
)
_register_shim("tools.interrupt", {"is_interrupted": is_interrupted})
_register_shim(
    "tools.terminal_tool",
    {
        "_rewrite_compound_background": _rewrite_compound_background,
        "_transform_sudo_command": _transform_sudo_command,
    },
)
_register_shim(
    "tools.env_passthrough",
    {
        "is_env_passthrough": is_env_passthrough,
        "get_all_passthrough": get_all_passthrough,
    },
)
_register_shim(
    "tools.credential_files",
    {
        "get_credential_file_mounts": get_credential_file_mounts,
        "get_skills_directory_mount": get_skills_directory_mount,
        "get_cache_directory_mounts": get_cache_directory_mounts,
    },
)
_register_shim(
    "tools.managed_tool_gateway",
    {"resolve_managed_tool_gateway": resolve_managed_tool_gateway},
)
_register_shim(
    "lyceum_cli.config",
    {
        "load_config": load_config,
        "load_env": load_env,
        "OPTIONAL_ENV_VARS": OPTIONAL_ENV_VARS,
    },
)
_register_shim(
    "lyceum_cli.auth",
    {"PROVIDER_REGISTRY": PROVIDER_REGISTRY},
)
