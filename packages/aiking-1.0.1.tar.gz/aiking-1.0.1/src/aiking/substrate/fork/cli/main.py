# SPDX-License-Identifier: MIT
"""Concinno-King CLI entrypoint.

This is the **first wired surface** for the merged provider fleet
(MEMORY #4d island check — registry.py must have ≥1 production caller
in the same wave as the registry lands). The two commands here are
intentionally tiny:

- ``concinno-king providers list [--available]`` — prints the
  catalogue (24+ logical providers across Lyceum / Sancio sources).
- ``concinno-king providers test <model>`` — resolves ``<model>`` to
  a provider via ``registry.resolve``, attempts to import the backing
  adapter module, and reports the result. No live LLM call is made
  — the test verifies wiring (env keys + module loadable), not API
  reachability.

Future waves will add `agent run`, `messaging serve`, etc. — those
should each call into the registry the same way (`registry.resolve`
or `registry.get_provider` + `registry.load_adapter`) so the wire-up
contract stays uniform.
"""

from __future__ import annotations

import argparse
import os
import sys
from typing import Sequence

# When run as `python -m concinno_king.cli.main` the parent package
# resolves correctly; when run via `python cli/main.py` directly we
# fall back to the sibling-import path so the smoke test does not
# need a sys.path massage.
try:
    from aiking.substrate.fork.providers import (  # type: ignore[import-not-found]
        ProviderError,
        available_providers,
        get_provider,
        list_providers,
        load_adapter,
        resolve,
    )
except ImportError:
    # Direct invocation: prepend the repo's `providers/` parent so
    # the package import works without an editable install.
    _here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if _here not in sys.path:
        sys.path.insert(0, _here)
    from aiking.substrate.fork.providers import (  # type: ignore[import-not-found]
        ProviderError,
        available_providers,
        get_provider,
        list_providers,
        load_adapter,
        resolve,
    )


def _cmd_providers_list(args: argparse.Namespace) -> int:
    """`concinno-king providers list` — print the provider catalogue."""
    catalogue = available_providers() if args.available else list_providers()
    if args.format == "json":
        import json

        payload = [
            {
                "name": info.name,
                "source": info.source,
                "model_prefixes": list(info.model_prefixes),
                "env_keys": list(info.env_keys),
                "module_path": info.module_path,
                "description": info.description,
            }
            for info in catalogue
        ]
        print(json.dumps(payload, indent=2, ensure_ascii=False))
        return 0

    # Plain-text table.
    name_w = max(len(info.name) for info in catalogue) if catalogue else 4
    src_w = max(len(info.source) for info in catalogue) if catalogue else 6
    print(f"{'NAME':<{name_w}}  {'SOURCE':<{src_w}}  DESCRIPTION")
    print(f"{'-' * name_w}  {'-' * src_w}  {'-' * 40}")
    for info in catalogue:
        print(f"{info.name:<{name_w}}  {info.source:<{src_w}}  {info.description}")
    print()
    print(f"Total: {len(catalogue)} provider(s)")
    if not args.available:
        print(
            "(use --available to filter to providers with env keys "
            "+ importable modules)"
        )
    return 0


def _cmd_providers_test(args: argparse.Namespace) -> int:
    """`concinno-king providers test <model>` — resolve + import-check."""
    model = args.model
    info = resolve(model)
    if info is None:
        # Allow explicit name lookup (e.g. `providers test ollama`).
        try:
            info = get_provider(model)
        except ProviderError as exc:
            print(f"FAIL: {exc}", file=sys.stderr)
            return 2
    print(f"Model:        {model}")
    print(f"Provider:     {info.name}")
    print(f"Source:       {info.source}")
    print(f"Module:       {info.module_path}")
    env_label = ", ".join(info.env_keys) if info.env_keys else "(none — local)"
    print(f"Env keys:     {env_label}")
    env_set = [k for k in info.env_keys if os.environ.get(k)]
    print(f"Env present:  {', '.join(env_set) if env_set else '(none)'}")
    try:
        load_adapter(info.name)
        print("Import:       OK")
    except ProviderError as exc:
        print(f"Import:       FAIL — {exc.detail}")
        return 1
    return 0


def _cmd_evolution_gepa_optimize(args: argparse.Namespace) -> int:
    """`concinno-king evolution gepa optimize <skill_name>` — run GEPA."""
    try:
        from aiking.substrate.fork.evolution.gepa_skill import (  # type: ignore[import-not-found]
            SkillGEPAOptimizer,
        )
    except ImportError as exc:
        print(f"FAIL: evolution package not importable — {exc}", file=sys.stderr)
        return 2
    skill_md_path = args.skill_md
    if not skill_md_path or not os.path.isfile(skill_md_path):
        print(f"FAIL: skill_md path not found: {skill_md_path}", file=sys.stderr)
        return 2
    with open(skill_md_path, encoding="utf-8") as fh:
        skill_md = fh.read()

    def _echo_reflector(prompt: str) -> str:
        return prompt

    optimiser = SkillGEPAOptimizer(reflection_llm=_echo_reflector, budget=args.budget)
    result = optimiser.optimize_skill_description(
        skill_md=skill_md,
        usage_history=[],
        skill_name=args.skill,
    )
    if args.output:
        with open(args.output, "w", encoding="utf-8") as fh:
            fh.write(result)
        print(f"Wrote optimised description to {args.output}")
    else:
        print(result)
    return 0


def _cmd_invariants_check(args: argparse.Namespace) -> int:
    """`concinno-king invariants check <state_file>` — run pre+post checks.

    Reads a JSON file describing an :class:`agent.invariants.AgentState`
    (only the fields that exist; missing fields default to empty). Runs
    pre-step + post-step checks and prints results. Exit code:

    * ``0`` — all invariants passed.
    * ``1`` — at least one invariant failed (still recorded to ZIQ +
      jsonl trail).
    * ``2`` — argument / import error.
    """
    try:
        from aiking.substrate.fork.agent.invariants import (  # type: ignore[import-not-found]
            AgentState,
            SubAgentCtx,
            post_step_check,
            pre_step_check,
        )
    except ImportError as exc:
        print(f"FAIL: agent.invariants not importable — {exc}", file=sys.stderr)
        return 2

    import json as _json

    if not os.path.isfile(args.state_file):
        print(f"FAIL: state file not found: {args.state_file}", file=sys.stderr)
        return 2
    try:
        with open(args.state_file, encoding="utf-8") as fh:
            payload = _json.load(fh)
    except (OSError, ValueError) as exc:
        print(f"FAIL: cannot read state file — {exc}", file=sys.stderr)
        return 2
    if not isinstance(payload, dict):
        print("FAIL: state file must contain a JSON object", file=sys.stderr)
        return 2

    sub_agents = tuple(
        SubAgentCtx(
            agent_id=sa.get("agent_id", "<child>"),
            parent_agent_id=sa.get(
                "parent_agent_id", payload.get("agent_id", "<parent>")
            ),
            bundle=sa.get("bundle", {}),
            leaks_parent_secrets=bool(sa.get("leaks_parent_secrets", False)),
            aliased_state_keys=tuple(sa.get("aliased_state_keys", ())),
        )
        for sa in payload.get("sub_agents", [])
    )
    state = AgentState(
        agent_id=payload.get("agent_id", "<unknown>"),
        step_kind=payload.get("step_kind", "pre"),
        governance_writes=tuple(payload.get("governance_writes", ())),
        parallel_branches=tuple(payload.get("parallel_branches", ())),
        sub_agents=sub_agents,
        runtime_state=dict(payload.get("runtime_state", {})),
    )

    pre_results = pre_step_check(state)
    post_results = post_step_check(state)
    all_results = list(pre_results) + list(post_results)

    if args.format == "json":
        print(
            _json.dumps(
                [
                    {
                        "invariant": r.invariant.value,
                        "passed": r.passed,
                        "severity": r.severity,
                        "message": r.message,
                        "detail": dict(r.detail or {}),
                    }
                    for r in all_results
                ],
                indent=2,
                ensure_ascii=False,
            )
        )
    else:
        print(f"State:        {args.state_file}")
        print(f"Agent:        {state.agent_id}")
        print()
        print(f"{'INVARIANT':<12}  {'PASS':<5}  MESSAGE")
        print(f"{'-' * 12}  {'-' * 5}  {'-' * 40}")
        for r in all_results:
            mark = "✔" if r.passed else "✖"
            print(
                f"{r.invariant.value:<12}  {mark:<5}  "
                f"{r.message or '(passed)'}"
            )

    return 0 if all(r.passed for r in all_results) else 1


def _cmd_invariants_violations(args: argparse.Namespace) -> int:
    """`concinno-king invariants violations` — list recent violations."""
    try:
        from aiking.substrate.fork.agent.invariants import (  # type: ignore[import-not-found]
            get_recent_violations,
        )
    except ImportError as exc:
        print(f"FAIL: agent.invariants not importable — {exc}", file=sys.stderr)
        return 2

    rows = get_recent_violations(limit=max(1, args.limit))
    if args.format == "json":
        import json as _json

        print(_json.dumps(rows, indent=2, ensure_ascii=False))
        return 0

    if not rows:
        print("(no violations recorded)")
        return 0
    print(f"{'TS':<22}  {'INVARIANT':<12}  DETAIL")
    print(f"{'-' * 22}  {'-' * 12}  {'-' * 40}")
    for row in rows:
        ts = row.get("ts", "")
        name = row.get("invariant", "")
        detail = row.get("detail", {})
        snippet = str(detail)[:60]
        print(f"{ts:<22}  {name:<12}  {snippet}")
    print()
    print(f"Total: {len(rows)} violation(s)")
    return 0


def _cmd_evolution_gepa_state(args: argparse.Namespace) -> int:
    """`concinno-king evolution gepa state <skill_name>` — dump JSON state."""
    try:
        from aiking.substrate.fork.evolution.gepa_state import (  # type: ignore[import-not-found]
            load_state,
            state_path,
        )
    except ImportError as exc:
        print(f"FAIL: evolution package not importable — {exc}", file=sys.stderr)
        return 2
    state = load_state(args.skill)
    path = state_path(args.skill)
    print(f"Path:        {path}")
    print(f"Iterations:  {state.iterations}")
    print(
        "Best score:  "
        f"{state.best_score if state.best_score != float('-inf') else '(none)'}"
    )
    print(f"History:     {len(state.history)} entries")
    print(f"FTRL keys:   {list(state.ftrl_gradient.keys()) or '(none)'}")
    return 0


# ─── messaging sub-command (forked Lyceum / Hermes platform adapters) ─────────
# Wires concinno_king.messaging.registry into the user-facing CLI surface
# (MEMORY #4d island check — registry must have ≥1 production caller in
# the same wave as the registry lands).


def _cmd_messaging_list(args: argparse.Namespace) -> int:
    """`concinno-king messaging list` — enumerate platform catalogue."""
    from aiking.substrate.fork.messaging.registry import (  # noqa: PLC0415
        active_platform_names,
        list_platforms,
    )

    platforms = list_platforms()
    if args.active:
        active = set(active_platform_names())
        platforms = [p for p in platforms if p.name in active]

    if args.format == "json":
        import json  # noqa: PLC0415

        payload = [
            {
                "name": p.name,
                "label": p.label,
                "emoji": p.emoji,
                "module": p.module,
                "adapter_class": p.adapter_class,
                "env_vars": list(p.env_vars),
                "install_hint": p.install_hint,
                "upstream": p.upstream,
            }
            for p in platforms
        ]
        print(json.dumps(payload, indent=2, ensure_ascii=False))
        return 0

    name_w = max((len(p.name) for p in platforms), default=4)
    print(f"{'NAME':<{name_w}}  EMOJI  LABEL")
    print(f"{'-' * name_w}  -----  {'-' * 40}")
    for p in platforms:
        print(f"{p.name:<{name_w}}  {p.emoji:<5}  {p.label}")
    print()
    print(f"Total: {len(platforms)} platform(s)")
    if not args.active:
        env_label = os.environ.get("CONCINNO_KING_MESSAGING_PLATFORMS", "")
        if env_label:
            print(
                f"Active subset (CONCINNO_KING_MESSAGING_PLATFORMS={env_label!r}): "
                f"{len(active_platform_names())}"
            )
    return 0


def _cmd_messaging_check(args: argparse.Namespace) -> int:
    """`concinno-king messaging check <name>` — preflight a platform."""
    from aiking.substrate.fork.messaging.registry import (  # noqa: PLC0415
        check_platform,
        get_platform,
    )

    info = get_platform(args.platform)
    if info is None:
        print(f"unknown platform: {args.platform!r}", file=sys.stderr)
        return 2
    ok, hint = check_platform(args.platform)
    status = "OK" if ok else "MISSING"
    print(f"{info.emoji}  {info.name}: {status}")
    if not ok and hint:
        print(f"  install hint: {hint}")
    return 0 if ok else 1


def _cmd_messaging_info(args: argparse.Namespace) -> int:
    """`concinno-king messaging info <name>` — show metadata."""
    from aiking.substrate.fork.messaging.registry import get_platform  # noqa: PLC0415

    info = get_platform(args.platform)
    if info is None:
        print(f"unknown platform: {args.platform!r}", file=sys.stderr)
        return 2
    print(f"name:          {info.name}")
    print(f"label:         {info.label}")
    print(f"emoji:         {info.emoji}")
    print(f"module:        {info.module}")
    print(f"adapter_class: {info.adapter_class}")
    print(f"check_fn:      {info.check_fn or '(none)'}")
    print(f"env_vars:      {', '.join(info.env_vars) if info.env_vars else '(none)'}")
    print(f"install_hint:  {info.install_hint or '(none)'}")
    print(f"upstream:      {info.upstream}")
    return 0


# ─── sandbox sub-command (forked Lyceum sandbox backends) ──────────────────
# Wires concinno_king.sandbox.registry into the user-facing CLI surface
# (MEMORY #4d island check — registry must have ≥1 production caller in
# the same wave as the registry lands). Backends are local / docker /
# ssh / singularity / daytona / modal / managed_modal / vercel.


def _cmd_sandbox_list(args: argparse.Namespace) -> int:
    """`concinno-king sandbox list` — enumerate sandbox backends."""
    try:
        from aiking.substrate.fork.sandbox import (  # noqa: PLC0415
            KNOWN_BACKENDS,
            list_backends,
            list_known_backends,
        )
    except ImportError:
        from aiking.substrate.fork.sandbox import (  # type: ignore[import-not-found]  # noqa: PLC0415
            KNOWN_BACKENDS,
            list_backends,
            list_known_backends,
        )

    importable = set(list_backends())
    rows = list_known_backends() if args.all else list_backends()

    if args.format == "json":
        import json  # noqa: PLC0415

        payload = [
            {
                "name": name,
                "importable": name in importable,
                "builtin": name in KNOWN_BACKENDS,
            }
            for name in rows
        ]
        print(json.dumps(payload, indent=2, ensure_ascii=False))
        return 0

    name_w = max((len(n) for n in rows), default=4)
    print(f"{'NAME':<{name_w}}  STATUS  TYPE")
    print(f"{'-' * name_w}  ------  -------")
    for name in rows:
        marker = "OK" if name in importable else "miss"
        kind = "builtin" if name in KNOWN_BACKENDS else "custom"
        print(f"{name:<{name_w}}  {marker:<6}  {kind}")
    print()
    if args.all:
        print(f"Total: {len(rows)} backend(s) (builtin + custom)")
    else:
        print(f"Total importable: {len(rows)} of {len(KNOWN_BACKENDS)} builtin(s)")
    return 0


def _cmd_sandbox_test(args: argparse.Namespace) -> int:
    """`concinno-king sandbox test <backend>` — try to construct a backend."""
    try:
        from aiking.substrate.fork.sandbox import (  # noqa: PLC0415
            BackendNotAvailableError,
            UnknownBackendError,
            spawn,
        )
    except ImportError:
        from aiking.substrate.fork.sandbox import (  # type: ignore[import-not-found]  # noqa: PLC0415
            BackendNotAvailableError,
            UnknownBackendError,
            spawn,
        )

    name = args.backend
    try:
        env = spawn(name)
    except UnknownBackendError as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        return 2
    except BackendNotAvailableError as exc:
        print(f"FAIL: backend '{name}' not available — {exc}", file=sys.stderr)
        return 3
    except Exception as exc:  # noqa: BLE001 — surface any constructor failure
        print(
            f"FAIL: backend '{name}' constructor raised "
            f"{type(exc).__name__}: {exc}",
            file=sys.stderr,
        )
        return 4

    cls_name = type(env).__name__
    cwd = getattr(env, "cwd", "<unknown>")
    print(f"OK: {name} -> {cls_name} (cwd={cwd})")
    try:
        env.cleanup()
    except Exception as exc:  # noqa: BLE001 — cleanup is best-effort
        print(f"WARN: cleanup raised {type(exc).__name__}: {exc}", file=sys.stderr)
    return 0


def _add_sandbox_subparser(sub: argparse._SubParsersAction) -> None:
    """Wire ``concinno-king sandbox {list,test}`` onto ``sub``.

    Extracted from ``build_parser`` so the parent stays under the
    structural-lint length cap (matches ``_add_messaging_subparser`` pattern).
    """
    sandbox = sub.add_parser(
        "sandbox",
        help="sandbox execution backends (local / docker / ssh / modal / …)",
    )
    sbsub = sandbox.add_subparsers(dest="subcmd", required=True)

    s_list = sbsub.add_parser(
        "list",
        help="list sandbox backends (importable in this env by default)",
    )
    s_list.add_argument(
        "--all",
        action="store_true",
        help="include backends whose SDK is not installed",
    )
    s_list.add_argument(
        "--format",
        choices=("text", "json"),
        default="text",
        help="output format",
    )
    s_list.set_defaults(func=_cmd_sandbox_list)

    s_test = sbsub.add_parser(
        "test",
        help="construct a backend and report success / failure",
    )
    s_test.add_argument(
        "backend",
        help="backend name (e.g. local, docker, ssh, modal)",
    )
    s_test.set_defaults(func=_cmd_sandbox_test)


def _add_messaging_subparser(sub: argparse._SubParsersAction) -> None:
    """Wire ``concinno-king messaging {list,check,info}`` onto ``sub``.

    Extracted from ``build_parser`` so the parent stays under the
    structural-lint length cap.
    """
    messaging = sub.add_parser(
        "messaging",
        help="multi-platform messaging gateway (20 platforms)",
    )
    msub = messaging.add_subparsers(dest="subcmd", required=True)

    m_list = msub.add_parser("list", help="list known messaging platforms")
    m_list.add_argument(
        "--active",
        action="store_true",
        help="only show platforms in CONCINNO_KING_MESSAGING_PLATFORMS",
    )
    m_list.add_argument(
        "--format",
        choices=("text", "json"),
        default="text",
        help="output format",
    )
    m_list.set_defaults(func=_cmd_messaging_list)

    m_check = msub.add_parser("check", help="run dependency preflight")
    m_check.add_argument("platform", help="platform name (e.g. telegram)")
    m_check.set_defaults(func=_cmd_messaging_check)

    m_info = msub.add_parser("info", help="show platform metadata")
    m_info.add_argument("platform", help="platform name (e.g. telegram)")
    m_info.set_defaults(func=_cmd_messaging_info)


def build_parser() -> argparse.ArgumentParser:
    """Build the top-level argparse parser."""
    parser = argparse.ArgumentParser(
        prog="concinno-king",
        description="Concinno-King CLI (Lyceum + Sancio merged ecosystem)",
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    # ---- evolution gepa optimize / state ----
    evolution = sub.add_parser(
        "evolution",
        help="evolution / GEPA commands",
    )
    esub = evolution.add_subparsers(dest="subcmd", required=True)
    gepa = esub.add_parser("gepa", help="GEPA-driven skill optimiser")
    gsub = gepa.add_subparsers(dest="gepa_cmd", required=True)

    g_opt = gsub.add_parser("optimize", help="optimise a skill's SKILL.md description")
    g_opt.add_argument("skill", help="skill name (used as state key)")
    g_opt.add_argument("--skill-md", required=True, help="path to the SKILL.md to read")
    g_opt.add_argument("--budget", type=int, default=4, help="GEPA evolution budget")
    g_opt.add_argument(
        "--output",
        default=None,
        help="write the optimised description here (default stdout)",
    )
    g_opt.set_defaults(func=_cmd_evolution_gepa_optimize)

    g_state = gsub.add_parser("state", help="dump persisted GEPA state for a skill")
    g_state.add_argument("skill", help="skill name")
    g_state.set_defaults(func=_cmd_evolution_gepa_state)

    providers = sub.add_parser(
        "providers",
        help="provider registry commands (list / test)",
    )
    psub = providers.add_subparsers(dest="subcmd", required=True)

    p_list = psub.add_parser("list", help="list registered providers")
    p_list.add_argument(
        "--available",
        action="store_true",
        help="filter to providers whose env keys are set and module imports",
    )
    p_list.add_argument(
        "--format",
        choices=("text", "json"),
        default="text",
        help="output format",
    )
    p_list.set_defaults(func=_cmd_providers_list)

    p_test = psub.add_parser(
        "test",
        help="resolve a model to its provider and verify adapter imports",
    )
    p_test.add_argument(
        "model",
        help=(
            "model id or `provider:model` "
            "(e.g. claude-opus-4-7, openrouter:meta-llama/...)"
        ),
    )
    p_test.set_defaults(func=_cmd_providers_test)

    # ── invariants subcommand (B4: three-invariant contract) ──
    invariants = sub.add_parser(
        "invariants",
        help="three-invariant contract commands (check / violations)",
    )
    isub = invariants.add_subparsers(dest="subcmd", required=True)

    i_check = isub.add_parser(
        "check",
        help="run pre+post invariants on a state JSON file",
    )
    i_check.add_argument(
        "state_file",
        help="path to JSON file describing AgentState",
    )
    i_check.add_argument(
        "--format",
        choices=("text", "json"),
        default="text",
        help="output format",
    )
    i_check.set_defaults(func=_cmd_invariants_check)

    i_violations = isub.add_parser(
        "violations",
        help="list recent invariant violations from the local jsonl trail",
    )
    i_violations.add_argument(
        "--limit",
        type=int,
        default=20,
        help="max violations to display (default 20)",
    )
    i_violations.add_argument(
        "--format",
        choices=("text", "json"),
        default="text",
        help="output format",
    )
    i_violations.set_defaults(func=_cmd_invariants_violations)

    _add_messaging_subparser(sub)
    _add_sandbox_subparser(sub)

    # ── curator subcommand (Hermes-derived + ZIQ-improved governance) ──
    # Wires governance.curator.tick() so MEMORY #4d island check passes
    # — this CLI is the production caller for the curator module.
    # Defensive try/except: another sub-agent owns ``cli/curator_cli.py``
    # and may not have shipped yet (B4 invariants wave precedes it).
    try:
        from aiking.substrate.fork.cli.curator_cli import (  # type: ignore[import-not-found]
            add_curator_subparser as _add_curator_subparser,
        )

        _add_curator_subparser(sub)
    except ImportError:
        # Curator module not yet shipped — skip wiring. Other CLI
        # subcommands (providers / evolution / invariants / messaging)
        # still register fine.
        pass

    # ── run subcommand (B3 sub-agent — agent loop with redblue/curator/emergence) ──
    # Wires concinno-king/agent/loop_with_redblue.py into the top-level CLI
    # so MEMORY #4d island check passes — this CLI is the production
    # caller for the agent loop module. Defensive try/except so a
    # rewrite of the run module never blocks the rest of the CLI.
    try:
        from aiking.substrate.fork.cli.run_cli import add_run_subparser as _add_run_subparser

        _add_run_subparser(sub)
    except ImportError:
        pass

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    """CLI entrypoint. Returns process exit code."""
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
