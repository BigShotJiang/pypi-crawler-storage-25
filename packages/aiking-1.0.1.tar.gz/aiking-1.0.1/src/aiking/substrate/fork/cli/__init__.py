# SPDX-License-Identifier: MIT
"""Concinno-King CLI package."""
