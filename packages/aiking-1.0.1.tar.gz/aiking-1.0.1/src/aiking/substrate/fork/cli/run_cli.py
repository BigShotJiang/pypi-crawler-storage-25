# SPDX-License-Identifier: MIT
"""concinno-king.cli.run_cli — ``concinno-king run`` subparser.

@module cli.run_cli
@responsibility Plug the agent loop with redblue+curator+emergence
    wiring into the top-level :mod:`cli.main` argparse tree. Mirrors
    the ``add_curator_subparser`` / ``_add_messaging_subparser``
    pattern used by sibling sub-agents so each wave can land its own
    subcommand without merging into one mega-parser.
@exports add_run_subparser

Usage
-----
::

    concinno-king run --prompt "hello" --backend mock
    concinno-king run --dry-run                 # build loop, print wiring
    concinno-king run --backend null            # offline-safe smoke

The actual loop and dispatcher live in
:mod:`agent.loop_with_redblue` / :mod:`agent.redblue_dispatcher`. This
module is purely the argparse glue.
"""

from __future__ import annotations

import argparse
import json
import logging
from typing import Any

logger = logging.getLogger(__name__)

__all__ = ["add_run_subparser"]


def _cmd_run(args: argparse.Namespace) -> int:
    """Build the agent loop and (optionally) execute one stub turn.

    The CLI ``run`` is meant for smoke-testing the wiring contract:

    * ``--dry-run`` builds the loop and prints the JSON wiring summary
      (which hooks were attached, which dispatcher backend resolved)
      without firing a real LLM call. Useful for CI.
    * Without ``--dry-run`` the loop runs once with a stub LLM that
      returns no tool_calls, so callers without a wired provider see
      the loop terminate cleanly with ``stop_reason="completed"``.

    Real provider wiring lives in Python (``build_default_loop`` +
    your own ``llm_call``) — the CLI ``run`` subcommand intentionally
    does not gain the providers' ``--api-key`` / ``--model`` matrix.
    """
    # Lazy imports — keeps ``--help`` snappy and means the CLI tree
    # still loads when the agent loop is mid-rewrite.
    from aiking.substrate.fork.agent.loop_with_redblue import LLMResponse, build_default_loop

    def stub_llm(messages, schemas):  # noqa: ARG001 — stub
        """Stub LLM that emits a benign reply with no tool_calls."""
        return LLMResponse(
            content="(stub LLM — no provider wired)",
            complexity=0.0,
        )

    loop = build_default_loop(
        llm_call=stub_llm,
        backend=args.backend,
        conv_id=args.conv_id,
    )
    loop.max_iterations = args.max_iterations

    summary: dict[str, Any] = {
        "backend": args.backend or "default",
        "tools": list(loop.tools.keys()),
        "max_iterations": loop.max_iterations,
        "redblue_enabled": getattr(loop.redblue_hook, "enabled", False),
        "curator_enabled": getattr(loop.curator_hook, "enabled", False),
        "emergence_enabled": getattr(loop.emergence_hook, "enabled", False),
    }

    if args.dry_run:
        print(json.dumps({"event": "loop_built", **summary}, indent=2))
        return 0

    state = loop.run(
        [{"role": "user", "content": args.prompt}],
        original_intent=args.prompt,
    )
    print(
        json.dumps(
            {
                "event": "loop_complete",
                "iterations": state.iterations,
                "stop_reason": state.stop_reason,
                "final_text": state.final_text,
                "aborted": state.aborted_steps,
                **summary,
            },
            indent=2,
        ),
    )
    return 0


def add_run_subparser(
    sub: argparse._SubParsersAction,
) -> None:
    """Attach the ``run`` subcommand to the top-level CLI parser.

    Called from :func:`cli.main.build_parser` via the same defensive
    ``try/except ImportError`` pattern used by ``add_curator_subparser``.
    Each call wires exactly one subcommand into ``sub``.
    """
    p_run = sub.add_parser(
        "run",
        help=(
            "start the agent loop with redblue+curator+emergence wiring "
            "(B3 sub-agent entrypoint)"
        ),
    )
    p_run.add_argument(
        "--prompt", "-p",
        default="hello",
        help="initial user prompt fed to the stub LLM",
    )
    p_run.add_argument(
        "--backend",
        default=None,
        help=(
            "redblue dispatcher backend "
            "(anthropic|openai|mock|null|disabled)"
        ),
    )
    p_run.add_argument(
        "--max-iterations",
        type=int,
        default=25,
        help="loop iteration cap (soft — invariants can stop earlier)",
    )
    p_run.add_argument(
        "--conv-id",
        default="default",
        help="conversation id for emergence state sidecar",
    )
    p_run.add_argument(
        "--dry-run",
        action="store_true",
        help="build the loop, print wiring summary, exit before LLM call",
    )
    p_run.set_defaults(func=_cmd_run)
