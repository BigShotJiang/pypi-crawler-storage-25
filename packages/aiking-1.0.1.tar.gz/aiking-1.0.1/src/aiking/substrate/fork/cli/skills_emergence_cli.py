# SPDX-License-Identifier: MIT
"""concinno_king.cli.skills_emergence_cli — CLI for SkillEmergenceGuard drafts.

Usage
-----

::

    concinno-king skills emergence list
    concinno-king skills emergence accept <slug>
    concinno-king skills emergence reject <slug>

This is the canonical surface a user runs after the agent loop has
written a draft to ``~/.concinno-king/skill_drafts/<slug>.md``.

Per MEMORY #4d island check, this module wires the
:mod:`concinno_king.skills.emergence` library to ≥ 1 production caller
(this argparse dispatcher) so the emergence module is not an
unreachable island. The agent loop itself is the second wired caller
(see :func:`concinno_king.skills.observe`).
"""

from __future__ import annotations

import argparse
import sys
from collections.abc import Sequence

from aiking.substrate.fork.skills import (
    accept_draft,
    list_drafts,
    reject_draft,
)


def _cmd_list(args: argparse.Namespace) -> int:
    drafts = list_drafts(conv_id=args.conv_id)
    if not drafts:
        print("(no pending drafts)")
        return 0
    print(f"{len(drafts)} draft(s) pending:")
    for d in drafts:
        slug = d.get("slug", "?")
        kind = d.get("trigger_kind", "?")
        name = d.get("name", "?")
        occ = d.get("occurrences", "?")
        resolution = d.get("resolution", "pending")
        print(f"  - {slug}  [{kind}]  {name}  (occurrences={occ}, {resolution})")
    return 0


def _cmd_accept(args: argparse.Namespace) -> int:
    ok = accept_draft(args.slug, conv_id=args.conv_id)
    if not ok:
        print(f"error: no draft with slug '{args.slug}'", file=sys.stderr)
        return 2
    print(f"accepted: {args.slug}")
    return 0


def _cmd_reject(args: argparse.Namespace) -> int:
    ok = reject_draft(args.slug, conv_id=args.conv_id)
    if not ok:
        print(f"error: no draft with slug '{args.slug}'", file=sys.stderr)
        return 2
    print(f"rejected: {args.slug}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    """Build the ``concinno-king skills emergence`` argparse tree."""
    p = argparse.ArgumentParser(
        prog="concinno-king skills emergence",
        description="Manage Skill drafts proposed by SkillEmergenceGuard.",
    )
    p.add_argument(
        "--conv-id",
        dest="conv_id",
        default="default",
        help="Conversation identifier (default: 'default').",
    )
    sub = p.add_subparsers(dest="command", required=True)

    p_list = sub.add_parser("list", help="List pending drafts.")
    p_list.set_defaults(func=_cmd_list)

    p_accept = sub.add_parser("accept", help="Accept a draft and install.")
    p_accept.add_argument("slug")
    p_accept.set_defaults(func=_cmd_accept)

    p_reject = sub.add_parser("reject", help="Reject and discard a draft.")
    p_reject.add_argument("slug")
    p_reject.set_defaults(func=_cmd_reject)

    return p


def main(argv: Sequence[str] | None = None) -> int:
    """Entry point. Returns process exit code."""
    parser = build_parser()
    ns = parser.parse_args(list(argv) if argv is not None else None)
    return int(ns.func(ns))


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
