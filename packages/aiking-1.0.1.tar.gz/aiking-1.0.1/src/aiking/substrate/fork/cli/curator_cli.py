# SPDX-License-Identifier: MIT
"""concinno-king curator CLI subcommand.

Module-isolated so the main parser stays under control even when several
sub-agents edit ``cli/main.py`` concurrently. ``cli/main.py`` calls
:func:`add_curator_subparser` once during ``build_parser`` setup.

Wires :mod:`governance.curator.tick` so MEMORY #4d island check passes:
this CLI is the production caller for the curator module.
"""

from __future__ import annotations

import argparse
import json
import sys

__all__ = ["add_curator_subparser"]


def _cmd_curator_status(_args: argparse.Namespace) -> int:
    """`concinno-king curator status` — print persistent curator state."""
    from aiking.substrate.fork.governance.curator import is_paused, load_state

    state = load_state()
    state["paused"] = is_paused()
    sys.stdout.write(json.dumps(state, indent=2, ensure_ascii=False) + "\n")
    return 0


def _cmd_curator_pause(args: argparse.Namespace) -> int:
    """`concinno-king curator pause [--paused on|off]`."""
    from aiking.substrate.fork.governance.curator import set_paused

    set_paused(bool(args.paused))
    sys.stdout.write(f"curator paused={bool(args.paused)}\n")
    return 0


def _cmd_curator_run(args: argparse.Namespace) -> int:
    """`concinno-king curator run [--force]` — execute one curator pass."""
    from aiking.substrate.fork.governance.curator import (
        register_skill_provider,
        run_curator_review,
        tick,
    )

    register_skill_provider(lambda: [])
    if args.force:
        result = run_curator_review(synchronous=True)
    else:
        result = tick() or {"summary": "gates closed", "skipped": True}
    sys.stdout.write(
        json.dumps(result, indent=2, ensure_ascii=False, default=str) + "\n"
    )
    return 0


def _cmd_curator_route(args: argparse.Namespace) -> int:
    """`concinno-king curator route <query>` — ZIQ posterior on demo set."""
    from aiking.substrate.fork.governance.ziq_routing import (
        DEFAULT_TOP_K,
        SkillCandidate,
        compute_skill_route,
    )

    candidates = [
        SkillCandidate(
            name="kb_cognition",
            description="Cognitive architecture, CBUA, six laws",
            triggers=("CBUA", "認知", "thinking"),
        ),
        SkillCandidate(
            name="kb_handoff",
            description="Handoff document hygiene, three-tier index",
            triggers=("交接", "handoff", "ship"),
        ),
        SkillCandidate(
            name="kb_runpod",
            description="RunPod GPU pod lifecycle, network volume",
            triggers=("pod", "GPU", "RunPod"),
        ),
    ]
    top_k = int(getattr(args, "top_k", DEFAULT_TOP_K) or DEFAULT_TOP_K)
    routes = compute_skill_route(args.query, candidates, top_k=top_k)
    payload = {
        "query": args.query,
        "routes": [
            {
                "name": r.name,
                "score": round(r.score, 4),
                "sps": round(r.sps, 4),
                "ftrl": round(r.ftrl, 4),
            }
            for r in routes
        ],
    }
    sys.stdout.write(json.dumps(payload, indent=2, ensure_ascii=False) + "\n")
    return 0


def add_curator_subparser(sub: argparse._SubParsersAction) -> None:
    """Register the ``curator`` subcommand on the parent subparser."""
    curator = sub.add_parser(
        "curator",
        help="skill curator (auto stale/archive + LLM umbrella + ZIQ posterior)",
    )
    csub = curator.add_subparsers(dest="curator_cmd", required=True)

    c_status = csub.add_parser("status", help="print curator state JSON")
    c_status.set_defaults(func=_cmd_curator_status)

    c_pause = csub.add_parser("pause", help="pause/unpause the curator")
    c_pause.add_argument(
        "--paused",
        type=lambda v: v.lower() in {"1", "true", "yes", "on"},
        default=True,
        help="set paused=true (default) or false",
    )
    c_pause.set_defaults(func=_cmd_curator_pause)

    c_run = csub.add_parser("run", help="run one curator pass (Phase 1/2/3)")
    c_run.add_argument(
        "--force",
        action="store_true",
        help="bypass interval/idle gate and run synchronously",
    )
    c_run.set_defaults(func=_cmd_curator_run)

    c_route = csub.add_parser(
        "route",
        help="ZIQ posterior route for a query against a demo skill set",
    )
    c_route.add_argument("query", help="user query to score")
    c_route.add_argument(
        "--top-k",
        type=int,
        default=5,
        dest="top_k",
        help="max number of candidates to return",
    )
    c_route.set_defaults(func=_cmd_curator_route)
