# SPDX-License-Identifier: Apache-2.0
"""concinno CLI entry point."""

from .main import main

__all__ = ["main"]
