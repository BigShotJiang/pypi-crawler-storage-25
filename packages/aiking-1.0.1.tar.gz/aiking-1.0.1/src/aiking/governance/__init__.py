# SPDX-License-Identifier: Apache-2.0
"""aiking.governance — guard / hook / CLI / cognitive-router subsurface.

Migrated from concinno 5.x as part of the AI King single-distribution
consolidation. License: Apache-2.0. License firewall: this package MUST
NOT import aiking_core (AGPL).
"""

__all__ = ["guards", "hooks", "cli", "c0_router"]
