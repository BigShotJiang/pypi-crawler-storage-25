# SPDX-License-Identifier: Apache-2.0
"""concinno hook templates — installed to ~/.claude/hooks/ by `concinno init`."""
