# SPDX-License-Identifier: Apache-2.0
"""aiking command-line interface.

Minimal stdlib-only CLI exposed via ``[project.scripts] aiking = aiking.cli:main``.
Subcommands:

    aiking --version       Print package version.
    aiking info            Show installed substrate adapter, aiking-core
                           availability, and discovered ``aiking.core_engine``
                           entry points.
    aiking layers          List the four AI King layers and whether each is
                           importable in the current environment.

The CLI uses only the standard library (``argparse``, ``importlib``,
``importlib.metadata``) so the base ``pip install aiking`` stays light. It is
intentionally read-only: no destructive side effects, no network calls.
"""

from __future__ import annotations

import argparse
import importlib
import importlib.metadata as _md
import sys
from typing import Sequence

from aiking import __version__ as _AIKING_VERSION


def _pkg_version(name: str) -> str:
    """Return installed distribution version, or ``"not installed"``."""

    try:
        return _md.version(name)
    except _md.PackageNotFoundError:
        return "not installed"


def _try_import(modname: str) -> tuple[bool, str]:
    """Attempt to import ``modname``; return ``(ok, info)``."""

    try:
        mod = importlib.import_module(modname)
    except Exception as exc:  # pragma: no cover - diagnostic surface
        return False, f"{type(exc).__name__}: {exc}"
    location = getattr(mod, "__file__", "<namespace>") or "<namespace>"
    return True, location


def _entry_points(group: str) -> list[tuple[str, str]]:
    """Return ``[(name, value), ...]`` for an entry-point group."""

    try:
        eps = _md.entry_points(group=group)
    except TypeError:
        # Python <3.10 selectable API fallback (we require >=3.10 but
        # tolerate odd back-compat shims).
        eps = _md.entry_points().get(group, [])  # type: ignore[assignment]
    return [(ep.name, ep.value) for ep in eps]


def _cmd_info(_args: argparse.Namespace) -> int:
    print(f"aiking            {_AIKING_VERSION}")
    print(f"aiking (dist)     {_pkg_version('aiking')}")
    print(f"aiking-core       {_pkg_version('aiking-core')}")
    print(f"python            {sys.version.split()[0]}")
    print(f"platform          {sys.platform}")
    print()

    print("substrate adapter")
    try:
        from aiking.substrate import get_substrate

        adapter = get_substrate()
        print(f"  default         {type(adapter).__name__} "
              f"({type(adapter).__module__})")
    except Exception as exc:  # pragma: no cover - diagnostic surface
        print(f"  default         <unavailable: {type(exc).__name__}: {exc}>")
    print()

    print("aiking.core_engine entry points")
    eps = _entry_points("aiking.core_engine")
    if not eps:
        print("  (none discovered — install aiking-core to populate)")
    for name, value in eps:
        print(f"  {name:<14}  {value}")
    return 0


def _cmd_layers(_args: argparse.Namespace) -> int:
    layers: list[tuple[str, str, str]] = [
        ("governance", "aiking.governance", "Apache-2.0"),
        ("body", "aiking.body", "Apache-2.0"),
        ("substrate", "aiking.substrate", "Apache-2.0"),
        ("core (engine)", "aiking_core", "AGPL-3.0-or-later / Commercial"),
    ]
    width_layer = max(len(layer) for layer, _, _ in layers)
    width_module = max(len(mod) for _, mod, _ in layers)
    header = (
        f"{'layer':<{width_layer}}  "
        f"{'module':<{width_module}}  "
        f"{'license':<35}  status"
    )
    print(header)
    print("-" * len(header))
    rc = 0
    for layer, modname, license_ in layers:
        ok, info = _try_import(modname)
        status = "OK" if ok else f"MISSING ({info})"
        if not ok and modname != "aiking_core":
            # aiking_core is optional (AGPL); only mandatory layers
            # contribute to non-zero exit.
            rc = 2
        print(
            f"{layer:<{width_layer}}  "
            f"{modname:<{width_module}}  "
            f"{license_:<35}  {status}"
        )
    return rc


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="aiking",
        description=(
            "AI King — single-distribution agent platform. "
            "Use `aiking info` to inspect the installed engine and "
            "`aiking layers` to verify each layer imports."
        ),
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"aiking {_AIKING_VERSION}",
    )
    sub = parser.add_subparsers(dest="command", metavar="<command>")

    p_info = sub.add_parser("info", help="show installed engine + entry points")
    p_info.set_defaults(func=_cmd_info)

    p_layers = sub.add_parser("layers", help="list AI King layers + import status")
    p_layers.set_defaults(func=_cmd_layers)

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    func = getattr(args, "func", None)
    if func is None:
        parser.print_help()
        return 0
    return int(func(args) or 0)


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
