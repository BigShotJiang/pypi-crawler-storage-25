# SPDX-License-Identifier: Apache-2.0
"""AI King body sub-package — Sancio runtime hooks/engine/policy/middleware/event_dispatcher.

Migrated from persona 2.x as part of the AI King single-distribution
consolidation. License: Apache-2.0. License firewall: this package MUST
NOT import aiking_core (AGPL).
"""

__all__ = ['hooks', 'engine', 'policy', 'middleware', 'event_dispatcher']
