# SPDX-License-Identifier: Apache-2.0
"""persona.event_dispatcher.dispatcher — Core EventDispatcher class.

@module event_dispatcher.dispatcher
@responsibility Validate SKILL.md ``event_bindings`` via concinno,
    intern them, and fan out ``fire(event, payload)`` calls to all
    matching bindings with predicate evaluation, priority ordering,
    cooldown throttling, re-entrancy guarding, and OutcomeRecord
    persistence.
@dependencies concinno.skills.schema, concinno.core.state_store,
    persona.event_dispatcher.{predicate,throttle,outcome,adapters}
@exports EventDispatcher
"""

from __future__ import annotations

import hashlib
import logging
import time
from dataclasses import dataclass
from pathlib import Path

from concinno.skills.schema import EventBinding, parse_event_bindings

from .adapters import RESOLVER_NOT_FOUND, resolve_invoke
from .outcome import OutcomeRecord, OutcomeStore, now_epoch
from .predicate import PredicateError, evaluate
from .throttle import Throttle

_LOG = logging.getLogger("persona.event_dispatcher")

# Maximum depth of nested ``fire()`` calls within a single outer event.
# Binding A fires event X → binding B fires event Y → binding C fires
# event Z → ... a short loop burns budget silently, a long loop hangs.
# Spec §6 pins the cap at 8.
_MAX_REENTRANCY_DEPTH = 8


def _compute_binding_id(skill_name: str, event: str, invoke: str) -> str:
    """Stable 16-hex-char id for a binding.

    Includes ``skill_name`` so two skills that happen to declare the
    same (event, invoke) pair do not collide in OutcomeRecords.
    """
    key = f"{skill_name}\x1f{event}\x1f{invoke}".encode()
    return hashlib.blake2s(key, digest_size=8).hexdigest()


@dataclass(frozen=True)
class _InternedBinding:
    """Read-only runtime record for an interned binding."""

    binding_id: str
    skill_name: str
    source_path: Path
    binding: EventBinding


class EventDispatcher:
    """Active-trigger router for SKILL.md ``event_bindings``.

    Single-instance per session; the Sancio runtime owns the handle and
    calls :meth:`fire` from its hook entrypoints.
    """

    def __init__(self, *, cache_dir: str, session_id: str) -> None:
        self._cache_dir = cache_dir
        self._session_id = session_id
        # event -> [_InternedBinding, ...], kept sorted by priority desc
        # then by lexical invoke (stable insertion-order fallback on tie).
        self._by_event: dict[str, list[_InternedBinding]] = {}
        # binding_id -> _InternedBinding (flat lookup).
        self._by_id: dict[str, _InternedBinding] = {}
        self._throttle = Throttle()
        self._store = OutcomeStore(
            cache_dir=cache_dir, session_id=session_id,
        )
        # Re-entrancy counter. Not thread-local because the spec pins
        # dispatch to a single-threaded loop per session (§6).
        self._depth = 0
        # Track which bindings already emitted a ``skill_not_found``
        # record this session. Spec §6 says subsequent fires are
        # silently dropped to avoid log spam.
        self._seen_not_found: set[str] = set()

    # ──────────────────── registration ────────────────────

    def register_skill(
        self,
        skill_meta: dict,
        source_path: Path,
    ) -> int:
        """Validate + intern bindings from a parsed SKILL.md.

        Delegates validation to
        :func:`concinno.skills.schema.parse_event_bindings` — malformed
        entries are already filtered there, so this method only handles
        dedup + storage.

        Returns:
            Count of bindings actually registered after filtering.
        """
        bindings = parse_event_bindings(skill_meta)
        if not bindings:
            return 0
        skill_name = str(skill_meta.get("name") or source_path.stem)
        registered = 0
        for binding in bindings:
            binding_id = _compute_binding_id(
                skill_name, binding.event, binding.invoke,
            )
            if binding_id in self._by_id:
                # Re-registration from the same source is idempotent.
                continue
            interned = _InternedBinding(
                binding_id=binding_id,
                skill_name=skill_name,
                source_path=source_path,
                binding=binding,
            )
            self._by_id[binding_id] = interned
            bucket = self._by_event.setdefault(binding.event, [])
            bucket.append(interned)
            # Re-sort: priority desc, then lexical invoke, then stable
            # insertion order (list.sort is stable).
            bucket.sort(
                key=lambda b: (-b.binding.priority, b.binding.invoke),
            )
            registered += 1
        return registered

    # ──────────────────── dispatch ────────────────────

    def fire(
        self,
        event: str,
        payload: dict,
    ) -> list[OutcomeRecord]:
        """Run every binding matching *event*.

        Records one :class:`OutcomeRecord` per matched binding, including
        skipped / throttled / error paths. The dispatcher never raises to
        the caller — host hooks must stay unblockable.
        """
        if self._depth >= _MAX_REENTRANCY_DEPTH:
            _LOG.warning(
                "event_dispatcher: dropped fire(%r) — re-entrancy depth "
                "cap %d reached",
                event,
                _MAX_REENTRANCY_DEPTH,
            )
            return []

        matches = list(self._by_event.get(event, ()))
        if not matches:
            return []

        out: list[OutcomeRecord] = []
        self._depth += 1
        try:
            for interned in matches:
                record = self._run_one(interned, event, payload)
                if record is None:
                    continue
                out.append(record)
                self._store.append(record)
        finally:
            self._depth -= 1
        return out

    def _run_one(
        self,
        interned: _InternedBinding,
        event: str,
        payload: dict,
    ) -> OutcomeRecord | None:
        """Evaluate gates + invoke a single binding.

        Returns ``None`` to signal "silently skip, do not record"; this
        is used for repeat ``skill_not_found`` events after the first
        one in the session.
        """
        binding = interned.binding
        skill_name = interned.skill_name
        invoke = binding.invoke
        binding_id = interned.binding_id
        fired_at = now_epoch()

        def make(
            outcome: str,
            *,
            latency_ms: float = 0.0,
            error_summary: str = "",
            payload_keys: list[str] | None = None,
        ) -> OutcomeRecord:
            return OutcomeRecord(
                binding_id=binding_id,
                skill_name=skill_name,
                event=event,
                invoke=invoke,
                fired_at=fired_at,
                outcome=outcome,  # type: ignore[arg-type]
                latency_ms=latency_ms,
                error_summary=error_summary,
                payload_keys=list(payload_keys or ()),
            )

        # 1. Predicate (if any).
        read_keys: set[str] = set()
        if binding.when:
            try:
                passed = evaluate(binding.when, payload, read_keys=read_keys)
            except PredicateError as exc:
                return make(
                    "predicate_error",
                    error_summary=str(exc),
                    payload_keys=sorted(read_keys),
                )
            if not passed:
                return make("skipped", payload_keys=sorted(read_keys))

        # 2. Throttle.
        if not self._throttle.try_acquire(
            binding_id, binding.cooldown_seconds,
        ):
            return make("throttled", payload_keys=sorted(read_keys))

        # 3. Resolve + invoke.
        callable_ = resolve_invoke(invoke)
        t0 = time.perf_counter()
        try:
            rc = callable_(payload)
        except Exception as exc:  # noqa: BLE001 — adapters are 3rd-party-shaped
            latency_ms = (time.perf_counter() - t0) * 1000.0
            return make(
                "error",
                latency_ms=latency_ms,
                error_summary=f"{type(exc).__name__}: {exc}",
                payload_keys=sorted(read_keys),
            )
        latency_ms = (time.perf_counter() - t0) * 1000.0

        if rc == RESOLVER_NOT_FOUND:
            if binding_id in self._seen_not_found:
                # Silently skip repeat fires — spec §6.
                return None
            self._seen_not_found.add(binding_id)
            return make(
                "skill_not_found",
                latency_ms=latency_ms,
                payload_keys=sorted(read_keys),
            )
        if rc == 0:
            return make(
                "ok",
                latency_ms=latency_ms,
                payload_keys=sorted(read_keys),
            )
        return make(
            "error",
            latency_ms=latency_ms,
            error_summary=f"returncode={rc}",
            payload_keys=sorted(read_keys),
        )

    # ──────────────────── replay ────────────────────

    def outcomes(
        self,
        *,
        binding_id: str | None = None,
        since: float | None = None,
    ) -> list[OutcomeRecord]:
        """Replay window of dispatch history from StateStore."""
        return self._store.filter(binding_id=binding_id, since=since)

    # ──────────────────── introspection (test aids) ────────────────────

    def binding_ids(self) -> list[str]:
        """Every registered binding id. Test-only helper."""
        return list(self._by_id.keys())

    def reset_throttle(self) -> None:
        """Clear in-memory throttle state. Test-only helper."""
        self._throttle.reset()
