# SPDX-License-Identifier: Apache-2.0
"""persona.event_dispatcher.throttle — Per-binding cooldown enforcement.

@module event_dispatcher.throttle
@responsibility Enforce ``EventBinding.cooldown_seconds`` with a
    token-bucket-of-1 per binding_id. Reset across sessions (in-memory
    only) — short cooldowns are by-session noise filters per spec §3.4.
@dependencies stdlib ``time`` only
@exports Throttle
"""

from __future__ import annotations

import time


class Throttle:
    """Per-binding token-bucket-of-1 throttle.

    Args:
        now_fn: Clock source. Default :func:`time.monotonic`. Overridable
            for deterministic tests.
    """

    def __init__(self, *, now_fn=time.monotonic) -> None:
        self._now = now_fn
        # binding_id -> last-fire monotonic timestamp
        self._last: dict[str, float] = {}

    def try_acquire(self, binding_id: str, cooldown_seconds: float) -> bool:
        """Return True if the binding may fire now; False if throttled.

        ``cooldown_seconds <= 0`` short-circuits to always-allow (no
        state written), so "no throttle" is the no-overhead path.
        """
        if cooldown_seconds <= 0:
            return True
        now = self._now()
        last = self._last.get(binding_id)
        if last is not None and (now - last) < cooldown_seconds:
            return False
        self._last[binding_id] = now
        return True

    def reset(self) -> None:
        """Clear all throttle state. Used between test runs."""
        self._last.clear()
