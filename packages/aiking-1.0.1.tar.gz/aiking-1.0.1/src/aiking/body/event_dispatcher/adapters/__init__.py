# SPDX-License-Identifier: Apache-2.0
"""persona.event_dispatcher.adapters — Resolve ``invoke`` strings to callables.

@module event_dispatcher.adapters
@responsibility Turn the ``invoke`` field of an :class:`EventBinding`
    into a callable the dispatcher can run. Returns ``None`` from the
    callable's integer contract by using ``-1`` as the
    "resolver gave up" sentinel and ``0`` as success, mirroring typical
    shell exit codes.
@dependencies persona.event_dispatcher.adapters.slash_command
@exports InvokeCallable, RESOLVER_NOT_FOUND, resolve_invoke
"""

from __future__ import annotations

from typing import Callable

from .slash_command import slash_command_resolver

# Type alias: all adapter callables take the payload dict and return an
# integer exit code. 0 = ok, anything else = error.
InvokeCallable = Callable[[dict], int]

# Sentinel exit code emitted by the stub resolvers until the Sancio
# runtime wires an actual skill registry. Distinct from a real
# error exit so the dispatcher can record ``outcome="skill_not_found"``
# rather than a generic ``error``.
RESOLVER_NOT_FOUND = -1


def _bare_name_resolver(invoke: str) -> InvokeCallable:
    """Stub resolver for bare-name ``invoke`` strings.

    TODO (Sancio 0.6.x K-extension): look up the skill in the runtime
    registry (``persona.runtime.Runtime.skills``) and return a callable
    that actually invokes it. Until then we surface
    ``outcome="skill_not_found"`` so the binding is visible in the
    outcome log but produces no side effects.
    """

    def _stub(_payload: dict) -> int:  # noqa: ARG001 — stub signature
        return RESOLVER_NOT_FOUND

    _stub.__name__ = f"bare_name_stub::{invoke}"
    return _stub


def resolve_invoke(invoke: str) -> InvokeCallable:
    """Return a callable for the given ``invoke`` string.

    Order:
        1. ``invoke`` starting with ``/`` → slash-command resolver (stub).
        2. Otherwise → bare-name registry resolver (stub).

    Both paths are stubs until the Sancio runtime wires the skill
    registry. They return :data:`RESOLVER_NOT_FOUND` so the dispatcher
    can emit an ``OutcomeRecord`` with ``outcome="skill_not_found"``.
    """
    if invoke.startswith("/"):
        return slash_command_resolver(invoke)
    return _bare_name_resolver(invoke)
