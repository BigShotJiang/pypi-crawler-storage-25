# SPDX-License-Identifier: Apache-2.0
"""persona.event_dispatcher — Sancio 0.6 active-trigger skill router.

@module event_dispatcher
@responsibility Route SKILL.md ``event_bindings`` declarations to skill
    invocations at runtime. Concinno owns the schema
    (:class:`concinno.skills.schema.EventBinding`); this package owns
    the dispatch loop — predicate evaluation, priority ordering, cooldown
    throttling, and per-session outcome recording.
@dependencies concinno.core.state_store, concinno.skills.schema,
    concinno.core.subprocess_safe
@exports EventDispatcher, OutcomeRecord
"""

from __future__ import annotations

from .dispatcher import EventDispatcher
from .outcome import OutcomeRecord

__all__ = ["EventDispatcher", "OutcomeRecord"]
