# SPDX-License-Identifier: Apache-2.0
"""Persona consistency engine — OCEAN-to-behavior + system prompt.

Mirrors psyche-engine bigfive-behavior.ts logic in Python.
Builds LLM system prompts that enforce persona consistency,
tracks conversation history per context for multi-turn coherence.
"""

from __future__ import annotations

import os
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass, field

import httpx

from concinno.persona_prompt import (
    build_behavior_injection as _ccc_build_behavior_injection,
)

from persona.loader import PersonaData, _OCEAN_DIM_COUNT, parse_persona_text
from persona.providers import (
    LLMProvider,
    ModelPolicy,
    ProviderError,
    ProviderRegistry,
)
from persona.rag import PersonaRAG
from persona.router import route_persona_query

# A3 — CCC AppendOnlyLog lossless event capture. Imported lazily at
# module load so a missing concinno install (optional dep path) does
# not break persona-api startup. Real init is deferred to the property.
try:  # pragma: no cover — import guard
    from concinno.cache import AppendOnlyLog, LogEvent
    _APPEND_LOG_AVAILABLE = True
except ImportError:  # pragma: no cover — soft fallback
    AppendOnlyLog = None  # type: ignore[misc,assignment]
    LogEvent = None  # type: ignore[misc,assignment]
    _APPEND_LOG_AVAILABLE = False

# ── Dynamic persona detection ───────────────────

import re as _re  # noqa: E402

_PERSONA_SWITCH = _re.compile(
    r"(?:you\s+are\s+(?:now\s+)?"
    r"|act\s+as\s+"
    r"|pretend\s+(?:to\s+be\s+|you(?:'re| are)\s+)"
    r"|play\s+(?:the\s+role\s+of\s+)?"
    r"|persona:\s*|character:\s*"
    r"|from\s+now\s+on\s+you\s+are\s+)"
    r"(.{10,300})",
    _re.IGNORECASE | _re.DOTALL,
)


def _detect_dynamic_persona(message: str) -> PersonaData | None:
    """Detect persona switch instruction in user message.

    Returns new PersonaData if detected, None otherwise.
    """
    m = _PERSONA_SWITCH.search(message)
    if not m:
        return None

    desc = m.group(1).strip().rstrip(".")
    # Must contain a role indicator to avoid false positives
    # like "you are right" or "you are welcome"
    if not _re.search(
        r"(?:\ba\b|\ban\b|\bthe\b|\bnamed\b|\bwho\b"
        r"|\byear|old\b|\bfrom\b|\bperson\b|\brole\b)",
        desc, _re.IGNORECASE,
    ):
        return None
    # Build a minimal persona from the description
    persona = parse_persona_text(desc)
    # If parse didn't extract a name, use first few words
    if not persona.identity.name:
        words = desc.split()[:3]
        persona.identity.name = " ".join(words).title()
    # Narrative = the full description
    if not persona.narrative:
        persona.narrative = desc
    return persona

# ── OCEAN dimension behavior maps ───────────────
# Moved to concinno.persona_prompt (session 2026-04-15 M5).
# Aegis keeps only a thin wrapper that feeds its own dim count.


def build_behavior_injection(ocean: list[float]) -> str:
    """Build behavior profile text from OCEAN scores.

    Thin adapter over :func:`concinno.persona_prompt.build_behavior_injection`.
    Passes the Aegis loader's ``_OCEAN_DIM_COUNT`` so the persona
    loader stays the single source of truth for dim sizing.
    """
    return _ccc_build_behavior_injection(ocean, ocean_dims=_OCEAN_DIM_COUNT)


# ── System prompt builder ───────────────────────


def build_system_prompt(persona: PersonaData) -> str:
    """Build a complete system prompt enforcing persona consistency."""
    parts: list[str] = []

    # Identity header
    ident = persona.identity
    if ident.name:
        header = f"You are {ident.name}"
        if ident.age:
            header += f", {ident.age} years old"
        if ident.nationality:
            header += f", from {ident.nationality}"
        header += "."
        parts.append(header)

    # Narrative (core persona description)
    if persona.narrative:
        parts.append(persona.narrative)

    # OCEAN behavior injection
    behavior = build_behavior_injection(persona.ocean)
    if behavior:
        parts.append(behavior)

    # Communication style
    if persona.communication_style:
        parts.append(
            f"[Communication Style]\n"
            f"{persona.communication_style}",
        )

    # Locked values (hard boundaries)
    if persona.locked_values:
        vals = "\n".join(f"- {v}" for v in persona.locked_values)
        parts.append(f"[Inviolable Values]\n{vals}")

    # Consistency enforcement
    parts.append(
        "[Persona Consistency Rules]\n"
        "1. Stay in character at all times.\n"
        "2. Your personality traits are fixed — "
        "do not shift based on user requests.\n"
        "3. If asked to break character, "
        "deflect naturally within your persona.\n"
        "4. Maintain consistent speech patterns, "
        "vocabulary, and emotional tone.\n"
        "5. Do NOT introduce yourself by name unless "
        "directly asked. Just respond naturally.\n"
        "6. If the user assigns you a new persona, "
        "adopt it immediately and fully.",
    )

    return "\n\n".join(parts)


# ── Conversation context ────────────────────────


@dataclass
class ConversationContext:
    """Per-context conversation history for multi-turn consistency."""

    persona: PersonaData
    system_prompt: str
    messages: list[dict[str, str]] = field(
        default_factory=list,
    )
    max_history: int = 20

    def add_user(self, text: str) -> None:
        """Record a user message."""
        self._trim()
        self.messages.append({"role": "user", "content": text})

    def add_assistant(self, text: str) -> None:
        """Record an assistant response."""
        self._trim()
        self.messages.append(
            {"role": "assistant", "content": text},
        )

    def to_chat_messages(self) -> list[dict[str, str]]:
        """Build full message list for LLM API call."""
        return [
            {"role": "system", "content": self.system_prompt},
            *self.messages,
        ]

    def _trim(self) -> None:
        while len(self.messages) > self.max_history:
            self.messages.pop(0)


# ── Engine ──────────────────────────────────────

# LLM backend config
_GEMMA_URL = os.environ.get(
    "GEMMA_URL", "http://localhost:8400/v1",
)
_GEMMA_API_KEY = os.environ.get("GEMMA_API_KEY", "")
_GEMMA_MODEL = os.environ.get("GEMMA_MODEL", "gemma-4-27b")

# Anthropic API key — still read by :class:`AnthropicProvider` via
# its own ``ANTHROPIC_API_KEY`` env lookup; kept here as a module
# constant because existing tests monkeypatch ``engine._ANTHROPIC_API_KEY``
# to sidestep live-key checks. The legacy cybergym escalation
# constants (``_CYBERGYM_LLM`` / ``_ANTHROPIC_MODEL``) were removed
# alongside ``_llm_generate`` / ``_llm_anthropic``; the
# AnthropicProvider now owns its own model selection via
# :class:`ModelPolicy`.
_ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")


class PersonaEngine:
    """Core persona engine with ZIQ routing + SOTA RAG.

    Pipeline per query:
      1. ZIQ router classifies depth (FAST/STANDARD/DEEP)
      2. If use_rag: hybrid search (dense+sparse→RRF→ZIQ weights)
      3. RAG context injected into system prompt
      4. LLM generates persona-consistent response
      5. ZIQ feedback updates source weights
    """

    def __init__(
        self,
        rag_cache: str = ".persona_rag",
        provider_registry: ProviderRegistry | None = None,
    ) -> None:
        self._contexts: dict[str, ConversationContext] = {}
        self._http = httpx.AsyncClient(timeout=120)
        self._rag: PersonaRAG | None = None
        self._rag_cache = rag_cache
        # A5 model router — default lazy registry covering
        # anthropic / openai / ollama / groq. Callers (or tests)
        # may inject a pre-populated registry to use fakes.
        self._provider_router: ProviderRegistry = (
            provider_registry or ProviderRegistry.default()
        )
        # A3 — CCC AppendOnlyLog lossless event capture. Lazy init
        # so tests that monkeypatch CCC_APPEND_LOG_DIR after import
        # still observe the override, and so missing concinno is
        # tolerated as a soft no-op.
        self._event_log: AppendOnlyLog | None = None

    @property
    def rag(self) -> PersonaRAG:
        """Lazy-init RAG index."""
        if self._rag is None:
            self._rag = PersonaRAG(cache_dir=self._rag_cache)
        return self._rag

    @property
    def event_log(self) -> AppendOnlyLog | None:
        """Lazy-init AppendOnlyLog. Returns None when concinno absent.

        Callers must tolerate ``None`` — every call site wraps log
        writes in ``try/except`` so a missing or failing log layer
        never breaks the real LLM round-trip.
        """
        if self._event_log is None and _APPEND_LOG_AVAILABLE:
            try:
                self._event_log = AppendOnlyLog()
            except Exception:  # noqa: BLE001 — defensive: never
                # let log init break the engine.
                return None
        return self._event_log

    def get_or_create_context(
        self,
        context_id: str,
        persona: PersonaData,
    ) -> ConversationContext:
        """Get existing or create new conversation context."""
        if context_id not in self._contexts:
            self._contexts[context_id] = ConversationContext(
                persona=persona,
                system_prompt=build_system_prompt(persona),
            )
        return self._contexts[context_id]

    async def chat(
        self,
        context_id: str,
        persona: PersonaData,
        user_message: str,
        model_policy: ModelPolicy | None = None,
    ) -> str:
        """Generate a persona-consistent response with ZIQ routing.

        Auto-detects dynamic persona switches in user message.
        If detected, rebuilds context with new persona (fresh start).

        ``model_policy`` is optional. ``None`` falls back to a
        sensible default — ``ollama`` + ``_GEMMA_MODEL`` — which
        mirrors :meth:`chat_stream` so the stream/non-stream twins
        pick the same provider when neither caller specifies one.
        Ollama is the only built-in provider that does not require a
        hosted API key for the default dev setup. Callers that want
        Anthropic / OpenAI / Groq must pass an explicit
        :class:`ModelPolicy`.

        Error contract
        --------------
        Downstream consumers (``/v1/chat`` endpoint, benchmark runner,
        eval harness) expect a plain string and never a raised
        exception. The provider layer raises :class:`ProviderError`
        on failure, so we catch it here and render it as
        ``"[Persona engine error] ..."``. Callers that want
        structured errors should use :meth:`_llm_via_provider`
        directly instead of going through this method.
        """
        # Dynamic persona detection — hot-swap
        # Only replaces system prompt, preserves conversation
        # history. Zero cold-start penalty.
        dynamic = _detect_dynamic_persona(user_message)
        if dynamic is not None:
            persona = dynamic
            ctx_existing = self._contexts.get(context_id)
            new_prompt = build_system_prompt(persona)
            if ctx_existing is not None:
                # Hot-swap: keep history, change persona
                ctx_existing.persona = persona
                ctx_existing.system_prompt = new_prompt
            else:
                self._contexts[context_id] = ConversationContext(
                    persona=persona,
                    system_prompt=new_prompt,
                )

        ctx = self.get_or_create_context(context_id, persona)
        turn_count = len(ctx.messages) // 2

        # Step 1: ZIQ route
        route = route_persona_query(user_message, turn_count)

        # Step 2: RAG retrieval (if routed). We deliberately touch the
        # ``self.rag`` property here (not ``self._rag``) so the lazy
        # PersonaRAG lazy-init fires on first use. Previous code
        # guarded on ``self._rag is not None`` which short-circuited
        # forever because the private attr was never populated outside
        # the property.
        rag_results: list[dict] = []
        rag_context = ""
        if route.use_rag:
            rag_results = self.rag.search(user_message, top_k=3)
            if rag_results:
                snippets = [r["text"] for r in rag_results]
                rag_context = (
                    "\n[Retrieved Persona Context]\n"
                    + "\n---\n".join(snippets)
                )

        # Step 3: Build messages with RAG injection
        ctx.add_user(user_message)
        messages = ctx.to_chat_messages()
        if rag_context:
            # Inject RAG after system prompt
            messages[0] = {
                "role": "system",
                "content": (
                    messages[0]["content"] + "\n" + rag_context
                ),
            }

        # Step 4: Dispatch through the provider layer. Mirrors the
        # chat_stream() default — Ollama + _GEMMA_MODEL — so both
        # twins resolve the same provider when the caller stays
        # quiet. ProviderError → legacy string so existing downstream
        # consumers keep working without having to learn a new
        # exception.
        policy = model_policy or ModelPolicy(
            provider="ollama",
            model=_GEMMA_MODEL,
        )
        try:
            response = await self._llm_via_provider(
                policy, messages, session_id=context_id,
            )
        except ProviderError as exc:
            response = (
                f"[Persona engine error] {exc.provider}: {exc.detail}"
            )
        ctx.add_assistant(response)

        # Step 5: FTRL feedback — nudge bucket weights for hits that
        # actually flowed into the LLM context. Empty list is a
        # no-op inside feedback(), so this is safe when RAG was
        # skipped or returned nothing.
        if rag_results:
            try:
                self.rag.feedback(rag_results)
            except Exception:  # noqa: BLE001 — FTRL never blocks chat
                pass

        return response

    async def chat_stream(
        self,
        context_id: str,
        persona: PersonaData,
        user_message: str,
        model_policy: ModelPolicy | None = None,
    ) -> AsyncIterator[str]:
        """Streaming twin of :meth:`chat` — yield assistant text chunks.

        Mirrors the non-streaming pipeline step for step so the
        behavioural contract stays identical:

        1. Dynamic persona detection (hot-swap in place).
        2. :meth:`get_or_create_context` → persona-aware history.
        3. ZIQ route → maybe fire a RAG retrieval.
        4. Build messages with optional RAG context injection.
        5. Dispatch to the provider layer via
           :meth:`_llm_via_provider_stream` and yield each chunk
           through to the caller.
        6. On completion, commit the joined response to history and
           run FTRL feedback on the hits that flowed into the
           prompt.

        ``model_policy`` is optional. ``None`` falls back to a
        sensible default — currently ``ollama`` with the engine's
        own ``_GEMMA_MODEL`` env var, which matches the non-stream
        :meth:`chat` default — because all four registered
        providers require remote API keys except Ollama, which the
        local Gemma deployment already speaks. Callers that want
        Anthropic / OpenAI / Groq streaming must pass an explicit
        :class:`ModelPolicy`.

        Any :class:`ProviderError` raised by the stream terminates
        the iterator; the caller sees whatever chunks were yielded
        before the failure and can catch the exception to react.
        """
        # Step 1: dynamic persona hot-swap (same logic as chat()).
        dynamic = _detect_dynamic_persona(user_message)
        if dynamic is not None:
            persona = dynamic
            ctx_existing = self._contexts.get(context_id)
            new_prompt = build_system_prompt(persona)
            if ctx_existing is not None:
                ctx_existing.persona = persona
                ctx_existing.system_prompt = new_prompt
            else:
                self._contexts[context_id] = ConversationContext(
                    persona=persona,
                    system_prompt=new_prompt,
                )

        ctx = self.get_or_create_context(context_id, persona)
        turn_count = len(ctx.messages) // 2

        # Step 2: ZIQ route.
        route = route_persona_query(user_message, turn_count)

        # Step 3: RAG retrieval (if routed). Must touch the `self.rag`
        # property so the lazy-init fires — the non-stream path has
        # the same gotcha documented inside chat().
        rag_results: list[dict] = []
        rag_context = ""
        if route.use_rag:
            rag_results = self.rag.search(user_message, top_k=3)
            if rag_results:
                snippets = [r["text"] for r in rag_results]
                rag_context = (
                    "\n[Retrieved Persona Context]\n"
                    + "\n---\n".join(snippets)
                )

        # Step 4: build messages with optional RAG injection.
        ctx.add_user(user_message)
        messages = ctx.to_chat_messages()
        if rag_context:
            messages[0] = {
                "role": "system",
                "content": (
                    messages[0]["content"] + "\n" + rag_context
                ),
            }

        # Pick the default streaming policy when the caller did not
        # supply one. We default to Ollama + _GEMMA_MODEL because the
        # legacy non-stream path already targets the local Gemma
        # gateway via the OpenAI-compatible wire format, and Ollama
        # is the only built-in provider that does not require a
        # hosted API key for the default dev setup.
        policy = model_policy or ModelPolicy(
            provider="ollama",
            model=_GEMMA_MODEL,
        )

        # Step 5: stream dispatch → caller sees every chunk in order.
        response_parts: list[str] = []
        try:
            async for chunk in self._llm_via_provider_stream(
                policy, messages, session_id=context_id,
            ):
                if not chunk:
                    continue
                response_parts.append(chunk)
                yield chunk
        except ProviderError:
            # Record whatever partial text we managed to accumulate
            # so multi-turn history does not silently lose a failed
            # turn, then re-raise so the caller can surface the
            # failure out-of-band.
            partial = "".join(response_parts)
            if partial:
                ctx.add_assistant(partial)
            raise

        # Step 6: commit joined response + FTRL feedback.
        response = "".join(response_parts)
        ctx.add_assistant(response)
        if rag_results:
            try:
                self.rag.feedback(rag_results)
            except Exception:  # noqa: BLE001 — FTRL never blocks chat
                pass

    @staticmethod
    def _llm_end_payload(
        policy: ModelPolicy,
        response_length: int,
        duration_s: float,
        provider: "LLMProvider",
        *,
        streaming: bool = False,
    ) -> dict[str, object]:
        """Build the ``llm_call_end`` payload incl. optional usage.

        Centralised so non-stream and stream paths share one shape.
        Reads ``provider.last_usage`` defensively via ``getattr`` so
        third-party providers without the telemetry sidechannel
        still produce a valid (usage-less) payload.
        """
        payload: dict[str, object] = {
            "provider": policy.provider,
            "model": policy.model,
            "response_length": response_length,
            "duration_s": duration_s,
        }
        if streaming:
            payload["streaming"] = True
        usage = getattr(provider, "last_usage", None)
        if usage is not None:
            payload["usage"] = {
                "input_tokens": usage.input_tokens,
                "output_tokens": usage.output_tokens,
                "cache_creation_input_tokens": (
                    usage.cache_creation_input_tokens
                ),
                "cache_read_input_tokens": (
                    usage.cache_read_input_tokens
                ),
            }
        return payload

    async def _llm_via_provider(
        self,
        policy: ModelPolicy,
        messages: list[dict[str, str]],
        session_id: str = "default",
    ) -> str:
        """Dispatch one completion through the provider registry.

        This is the A5 model router entry point and the single
        canonical path for every LLM call in ``engine.py`` (legacy
        ``_llm_generate`` / ``_llm_anthropic`` were removed after the
        cybergym deletion). It:

        * raises :class:`ProviderError` on failure so callers can
          distinguish real errors from valid text that happens to
          start with ``"["``.
        * has zero knowledge of which concrete HTTP client handles
          the request — swap providers by passing a different
          :class:`ModelPolicy`.
        * is concinno-aware (A3): every call emits a lossless
          ``llm_call_start`` + ``llm_call_end`` (or ``_error``) pair
          into CCC AppendOnlyLog. ``session_id`` scopes the causal
          chain; callers that do not track sessions pass the
          implicit ``"default"`` bucket. Log failures are swallowed
          — observability MUST NOT break the real call path.

        The caller owns retry / fallback strategy.
        """
        start_ts = time.time()
        start_event_id = (
            AppendOnlyLog.new_event_id()
            if _APPEND_LOG_AVAILABLE
            else ""
        )
        log = self.event_log
        # A3 — capture the call intent *before* the network round-trip
        # so a crash mid-flight still leaves a replayable breadcrumb.
        # We deliberately omit raw message content: metadata only, to
        # keep the log bounded and avoid leaking user PII into the
        # lossless store.
        if log is not None:
            try:
                log.append(LogEvent(
                    event_id=start_event_id,
                    session_id=session_id,
                    timestamp=start_ts,
                    event_type="llm_call_start",
                    payload={
                        "provider": policy.provider,
                        "model": policy.model,
                        "messages_count": len(messages),
                        "temperature": policy.temperature,
                        "max_tokens": policy.max_tokens,
                    },
                    tokens_estimate=sum(
                        len(m.get("content", "")) // 4
                        for m in messages
                    ),
                ))
            except Exception:  # noqa: BLE001 — log failure is not fatal
                pass

        provider: LLMProvider = self._provider_router.get(policy.provider)
        try:
            response = await provider.generate(messages, policy)
        except ProviderError as exc:
            if log is not None:
                try:
                    log.append(LogEvent(
                        event_id=AppendOnlyLog.new_event_id(),
                        session_id=session_id,
                        timestamp=time.time(),
                        event_type="llm_call_error",
                        payload={
                            "provider": policy.provider,
                            "model": policy.model,
                            "error": str(exc)[:500],
                        },
                        parent_event_id=start_event_id,
                    ))
                except Exception:  # noqa: BLE001
                    pass
            raise
        except Exception as exc:  # noqa: BLE001 — defensive umbrella
            if log is not None:
                try:
                    log.append(LogEvent(
                        event_id=AppendOnlyLog.new_event_id(),
                        session_id=session_id,
                        timestamp=time.time(),
                        event_type="llm_call_error",
                        payload={
                            "provider": policy.provider,
                            "model": policy.model,
                            "error": str(exc)[:500],
                        },
                        parent_event_id=start_event_id,
                    ))
                except Exception:  # noqa: BLE001
                    pass
            raise ProviderError(policy.provider, str(exc)) from exc

        if log is not None:
            try:
                log.append(LogEvent(
                    event_id=AppendOnlyLog.new_event_id(),
                    session_id=session_id,
                    timestamp=time.time(),
                    event_type="llm_call_end",
                    payload=self._llm_end_payload(
                        policy=policy,
                        response_length=len(response),
                        duration_s=time.time() - start_ts,
                        provider=provider,
                    ),
                    parent_event_id=start_event_id,
                    tokens_estimate=len(response) // 4,
                ))
            except Exception:  # noqa: BLE001
                pass
        return response

    async def _llm_via_provider_stream(
        self,
        policy: ModelPolicy,
        messages: list[dict[str, str]],
        session_id: str = "default",
    ) -> AsyncIterator[str]:
        """Streaming twin of :meth:`_llm_via_provider`.

        Emits the same AppendOnlyLog ``llm_call_start`` + ``llm_call_end``
        / ``llm_call_error`` shape so cross-session replay sees a
        streaming call as a first-class peer of a non-streaming call.
        The ``end`` event's ``response_length`` reflects the joined
        chunk total (not per-chunk), matching the on-disk semantics
        of the non-streaming path.

        Yields plain ``str`` chunks — no SSE wire format, no dicts.
        Caller is responsible for whatever transport framing they
        want on top (the ``/v1/chat/stream`` endpoint wraps each
        chunk in an ``{"text": ...}`` JSON frame inside an SSE
        ``data:`` line, for example).
        """
        start_ts = time.time()
        start_event_id = (
            AppendOnlyLog.new_event_id()
            if _APPEND_LOG_AVAILABLE
            else ""
        )
        log = self.event_log
        if log is not None:
            try:
                log.append(LogEvent(
                    event_id=start_event_id,
                    session_id=session_id,
                    timestamp=start_ts,
                    event_type="llm_call_start",
                    payload={
                        "provider": policy.provider,
                        "model": policy.model,
                        "messages_count": len(messages),
                        "temperature": policy.temperature,
                        "max_tokens": policy.max_tokens,
                        "streaming": True,
                    },
                    tokens_estimate=sum(
                        len(m.get("content", "")) // 4
                        for m in messages
                    ),
                ))
            except Exception:  # noqa: BLE001 — log failure is not fatal
                pass

        provider: LLMProvider = self._provider_router.get(policy.provider)
        response_parts: list[str] = []
        try:
            async for chunk in provider.generate_stream(messages, policy):
                if chunk:
                    response_parts.append(chunk)
                yield chunk
        except ProviderError as exc:
            if log is not None:
                try:
                    log.append(LogEvent(
                        event_id=AppendOnlyLog.new_event_id(),
                        session_id=session_id,
                        timestamp=time.time(),
                        event_type="llm_call_error",
                        payload={
                            "provider": policy.provider,
                            "model": policy.model,
                            "error": str(exc)[:500],
                            "streaming": True,
                            "partial_length": len(
                                "".join(response_parts),
                            ),
                        },
                        parent_event_id=start_event_id,
                    ))
                except Exception:  # noqa: BLE001
                    pass
            raise
        except Exception as exc:  # noqa: BLE001 — defensive umbrella
            if log is not None:
                try:
                    log.append(LogEvent(
                        event_id=AppendOnlyLog.new_event_id(),
                        session_id=session_id,
                        timestamp=time.time(),
                        event_type="llm_call_error",
                        payload={
                            "provider": policy.provider,
                            "model": policy.model,
                            "error": str(exc)[:500],
                            "streaming": True,
                            "partial_length": len(
                                "".join(response_parts),
                            ),
                        },
                        parent_event_id=start_event_id,
                    ))
                except Exception:  # noqa: BLE001
                    pass
            raise ProviderError(policy.provider, str(exc)) from exc

        joined = "".join(response_parts)
        if log is not None:
            try:
                log.append(LogEvent(
                    event_id=AppendOnlyLog.new_event_id(),
                    session_id=session_id,
                    timestamp=time.time(),
                    event_type="llm_call_end",
                    payload=self._llm_end_payload(
                        policy=policy,
                        response_length=len(joined),
                        duration_s=time.time() - start_ts,
                        provider=provider,
                        streaming=True,
                    ),
                    parent_event_id=start_event_id,
                    tokens_estimate=len(joined) // 4,
                ))
            except Exception:  # noqa: BLE001
                pass

    async def llm_direct(
        self, message: str, track: str = "coding",
    ) -> str:
        """Direct LLM call without persona (cyber/coding tracks).

        Routes through the provider layer (Ollama + Gemma default)
        so behaviour matches :meth:`chat`. ``ProviderError`` is
        mapped to the legacy ``"[Persona engine error] ..."`` string
        shape so callers that historically swallowed this output as
        plain text keep working.
        """
        system_prompts = {
            "coding": (
                "You are a precise coding assistant. "
                "Provide clear, correct, efficient solutions."
            ),
            "cyber": (
                "You are a cybersecurity analyst. "
                "Identify vulnerabilities, suggest mitigations, "
                "and provide detailed security assessments."
            ),
        }
        system = system_prompts.get(track, system_prompts["coding"])
        policy = ModelPolicy(
            provider="ollama",
            model=_GEMMA_MODEL,
        )
        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": message},
        ]
        try:
            return await self._llm_via_provider(policy, messages)
        except ProviderError as exc:
            return f"[Persona engine error] {exc.provider}: {exc.detail}"

    # ── A1 agent loop entry ─────────────────────────
    # Thin wrapper so external callers can drive the v3 multi-round
    # tool-use loop without reaching into ``persona.engine.agent_loop``
    # directly. The HTTP ``/v1/chat`` endpoint still goes through
    # :meth:`chat` / :meth:`chat_stream` and is deliberately untouched
    # in A1 — provider tool_call support lands with A2/A3.
    async def run_agent(
        self,
        llm_call: "AgentLLMCall",
        messages: list[dict[str, object]],
        *,
        tools: "dict[str, AgentTool] | None" = None,
        pre_hooks: "list[AgentPreHook] | None" = None,
        post_hooks: "list[AgentPostHook] | None" = None,
        max_iterations: int = 25,
    ) -> "AgentState":
        """Run the Aegis v3 agent loop to completion.

        Parameters mirror :class:`~persona.engine.agent_loop.AgentLoop`
        — this method is just a convenience factory so callers don't
        have to import the submodule. ``tools`` defaults to empty,
        which degrades the loop to a single-shot chat and matches
        :meth:`chat` behaviour for sanity.
        """
        loop = AgentLoop(
            llm_call=llm_call,
            tools=tools or {},
            pre_hooks=pre_hooks or [],
            post_hooks=post_hooks or [],
            max_iterations=max_iterations,
        )
        return await loop.run(messages)


# Re-export agent-loop public surface at the package root so the
# common import shape ``from persona.engine import AgentLoop, ...``
# works without forcing consumers to know about submodules.
from .agent_loop import (  # noqa: E402 — late import to avoid cycles
    AgentLoop,
    AgentState,
    LLMCall as AgentLLMCall,
    LLMResponse as AgentLLMResponse,
    PermissionDenied,
    PostToolUseHook as AgentPostHook,
    PreToolUseHook as AgentPreHook,
    Tool as AgentTool,
    ToolCall,
)

__all__ = [
    "AgentLLMCall",
    "AgentLLMResponse",
    "AgentLoop",
    "AgentPostHook",
    "AgentPreHook",
    "AgentState",
    "AgentTool",
    "ConversationContext",
    "PermissionDenied",
    "PersonaEngine",
    "ToolCall",
    "build_behavior_injection",
    "build_system_prompt",
]
