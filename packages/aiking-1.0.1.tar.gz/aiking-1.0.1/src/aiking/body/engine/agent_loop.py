# SPDX-License-Identifier: Apache-2.0
"""Agent loop — multi-round LLM + tool execution (A1, v3 roadmap).

Structure extracted from Claude Code source (``query.ts`` ``queryLoop``
— ``E:/Cursor/src/src(CC源碼)/query.ts:307``). Claude Code's
conservative policies are deliberately **not** ported:

* No L1-L8 subagent fork caps
* No autocompact three-strike circuit breaker
* No hidden token budget kill-switch

Aegis's strength layer lives in the ``pre_hooks`` / ``post_hooks``
slots: Guards attach to :data:`PreToolUseHook` (A3), Cerno attaches
to :data:`PostToolUseHook` (A3). This file keeps the bare state
machine so A2 (tool registry) and A3 (hooks) can snap in without
rewriting the loop.

**Sancio 2.0.0 — PostToolUse contract (Option C reframe)**: the
post-hook signature returns
``Awaitable[PostToolUseDecision | None]`` so hooks can rewrite the
tool result, append context, or raise to block the LLM-visible
output. Side effects of the tool still happen (CC physics constraint
per GitHub anthropics/claude-code#32105) — what is denied is the
**observation channel** feeding the next LLM iteration. See
:mod:`persona.hooks.post_decision` for the contract.

A 1.x compat shim is honoured: hooks returning ``None`` (legacy
``Awaitable[None]``) work unchanged, with a one-shot
``DeprecationWarning`` per hook. The shim is dropped in 2.1.
"""

from __future__ import annotations

import json
import logging
import time
import warnings
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any, Protocol
from weakref import WeakSet

from ..hooks.post_decision import (
    PostToolDeny,
    PostToolUseBlocked,
    PostToolUseDecision,
)

logger = logging.getLogger(__name__)


class Tool(Protocol):
    """Minimal tool contract. A2 will ship concrete implementations."""

    name: str

    def schema(self) -> dict[str, Any]:
        """Return an OpenAI function-calling spec dict."""

    async def execute(self, args: dict[str, Any]) -> Any:
        """Run the tool and return a JSON-serialisable result."""


PreToolUseHook = Callable[[str, dict[str, Any]], Awaitable[None]]
PostToolUseHook = Callable[
    [str, dict[str, Any], Any],
    Awaitable[PostToolUseDecision | None],
]
"""Post-hook contract (Sancio 2.0.0).

A hook may return:

* ``None`` — legacy 1.x observational mode. Loop continues with the
  unmutated tool result. A ``DeprecationWarning`` is emitted **once
  per hook callable** so plugin authors notice; the legacy signature
  is dropped in 2.1.
* :class:`PostToolUseDecision` — structured rewrite/append/block.
  See :mod:`persona.hooks.post_decision`.

A hook may also raise:

* :class:`PostToolDeny` — observation-channel deny (Cerno style).
  Loop replaces ``result`` with ``f"post-hook deny: {exc}"`` and sets
  ``is_error=True``.
* :class:`PostToolUseBlocked` — equivalent to returning
  ``decision="block"``; loop emits ``f"blocked: {reason}"`` with
  ``is_error=True``.
* Any other ``Exception`` — fail-open per legacy behaviour: warning
  logged, original output preserved.
"""

PostToolUseFailureHook = Callable[
    [str, dict[str, Any], Exception, float],
    Awaitable[None],
]
"""Tool-execution failure hook (CC SDK April 2026 ``PostToolUseFailure`` parity).

Called when ``tool.execute()`` raises. Receives ``(tool_name, args,
exception, duration_ms)``. Observational only — the loop still
synthesises the failure tool message regardless of what this hook
does, mirroring CC's ``PostToolUseFailure`` (which fires *after* the
failure has already been recorded).
"""


# Hooks that have already received a one-shot DeprecationWarning. Keyed by
# WeakSet so hook callables can be GC'd without leaking entries here.
_LEGACY_HOOK_WARNED: WeakSet[Any] = WeakSet()


def _warn_legacy_hook_once(hook: PostToolUseHook) -> None:
    """Emit a one-shot DeprecationWarning per hook for legacy ``None`` return.

    Uses :class:`weakref.WeakSet` so we do not keep dead hooks alive.
    Bound methods cannot be weakref'd directly; for those we just emit
    the warning every time (harmless, and bound-method hooks are rare
    in practice — most plugins ship plain async functions).
    """
    try:
        if hook in _LEGACY_HOOK_WARNED:
            return
        _LEGACY_HOOK_WARNED.add(hook)
    except TypeError:
        # Bound method or other unhashable/un-weakreferable callable —
        # warn each time (still cheap, and rare in practice).
        pass
    warnings.warn(
        "PostToolUseHook returned None (legacy 1.x observational signature). "
        "Sancio 2.0 hooks should return PostToolUseDecision | None. "
        "Legacy compat shim will be removed in 2.1.",
        DeprecationWarning,
        stacklevel=3,
    )


class PermissionDenied(Exception):
    """Raised inside a Pre-hook to abort one tool call.

    The loop records the denial as a ``tool`` message with
    ``is_error=True`` and keeps going — the LLM decides whether to
    retry with different args or give up. Mirrors CC's
    ``hook_blocking_error`` attachment shape without the hard lock.
    """


@dataclass
class ToolCall:
    """One LLM-issued tool invocation."""

    id: str
    name: str
    args: dict[str, Any] = field(default_factory=dict)


@dataclass
class LLMResponse:
    """One LLM reply. Either text, tool_calls, or both."""

    content: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)


LLMCall = Callable[
    [list[dict[str, Any]], list[dict[str, Any]]],
    Awaitable[LLMResponse],
]
"""Provider-agnostic LLM invocation: (messages, tool_schemas) -> reply."""


@dataclass
class AgentState:
    """Mutable loop state. Mirrors CC ``QueryEngine.mutableMessages``."""

    messages: list[dict[str, Any]]
    iterations: int = 0
    done: bool = False
    final_text: str = ""
    stop_reason: str = ""  # completed | max_iterations


@dataclass
class AgentLoop:
    """Multi-round tool-use loop.

    Parameters
    ----------
    llm_call:
        Async callable that takes ``(messages, tool_schemas)`` and
        returns an :class:`LLMResponse`. Providers plug in here — tests
        pass a scripted fake to drive the state machine deterministically.
    tools:
        Name → :class:`Tool` registry. A2 will populate; A1 accepts an
        empty dict so the loop degrades to a single-shot chat.
    pre_hooks / post_hooks:
        Ordered lists. Pre-hooks can raise :class:`PermissionDenied` to
        block a call. Post-hooks support observation-channel deny + Pre-hook
        escalation per Option C reframe — see
        :mod:`persona.hooks.post_decision`.
    post_failure_hooks:
        Optional list of :data:`PostToolUseFailureHook` invoked when
        ``tool.execute()`` raises. CC SDK April 2026
        ``PostToolUseFailure`` parity — observational, fires *after*
        the failure is recorded.
    max_iterations:
        Soft cap to prevent runaway loops in tests and broken providers.
        **Not** a security boundary — Aegis policy DSL (A4) is the
        authoritative limit.
    """

    llm_call: LLMCall
    tools: dict[str, Tool] = field(default_factory=dict)
    pre_hooks: list[PreToolUseHook] = field(default_factory=list)
    post_hooks: list[PostToolUseHook] = field(default_factory=list)
    post_failure_hooks: list[PostToolUseFailureHook] = field(default_factory=list)
    max_iterations: int = 25

    async def run(
        self,
        messages: list[dict[str, Any]],
    ) -> AgentState:
        """Drive the loop until the LLM emits no tool_calls or the cap hits."""
        state = AgentState(messages=list(messages))
        schemas = [t.schema() for t in self.tools.values()]

        while not state.done:
            if state.iterations >= self.max_iterations:
                state.stop_reason = "max_iterations"
                break
            state.iterations += 1

            resp = await self.llm_call(state.messages, schemas)

            assistant_msg: dict[str, Any] = {
                "role": "assistant",
                "content": resp.content,
            }
            if resp.tool_calls:
                assistant_msg["tool_calls"] = [
                    {"id": c.id, "name": c.name, "args": c.args}
                    for c in resp.tool_calls
                ]
            state.messages.append(assistant_msg)

            if not resp.tool_calls:
                state.done = True
                state.final_text = resp.content
                state.stop_reason = "completed"
                break

            # Serial execution. CC's isConcurrencySafe-based 10-way
            # partitioner (toolOrchestration.ts:19) lands with A2 once
            # real tools expose the concurrency hint.
            for call in resp.tool_calls:
                await self._run_one_tool(state, call)

        return state

    async def _run_one_tool(
        self,
        state: AgentState,
        call: ToolCall,
    ) -> None:
        tool = self.tools.get(call.name)
        if tool is None:
            state.messages.append(
                self._tool_msg(
                    call.id,
                    f"unknown tool: {call.name}",
                    is_error=True,
                ),
            )
            return

        try:
            for hook in self.pre_hooks:
                await hook(call.name, call.args)
        except PermissionDenied as exc:
            state.messages.append(
                self._tool_msg(
                    call.id,
                    f"permission denied: {exc}",
                    is_error=True,
                ),
            )
            return

        # Execute the tool and time it (duration_ms feeds the
        # PostToolUseFailure hook on the failure path, matching CC SDK
        # April 2026's sibling-field shape).
        exec_start = time.perf_counter()
        try:
            result: Any = await tool.execute(call.args)
            is_error = False
        except Exception as exc:  # noqa: BLE001 — surface to LLM, not a crash
            duration_ms = (time.perf_counter() - exec_start) * 1000.0
            # CC PostToolUseFailure parity — observational, fires *after*
            # the failure is recorded. Hook exceptions are swallowed so
            # one bad subscriber cannot poison the loop.
            for failure_hook in self.post_failure_hooks:
                try:
                    await failure_hook(call.name, call.args, exc, duration_ms)
                except Exception:  # noqa: BLE001 — observational only
                    logger.warning(
                        "post_failure_hook raised; swallowed",
                        exc_info=True,
                    )
            result = f"tool error: {exc}"
            is_error = True
            # Append directly — failed tools skip the post-hook chain
            # since there is no real output to mutate (CC parity:
            # PostToolUse fires only on success; PostToolUseFailure
            # fires only on failure).
            state.messages.append(
                self._tool_msg(call.id, result, is_error=is_error),
            )
            return

        # Success path — run post-hooks. Each may rewrite, append, or
        # block. First non-None updated_output wins; subsequent hooks
        # see the rewritten value as their `result` argument.
        try:
            result, is_error = await self._apply_post_hooks(call, result)
        except PostToolDeny as exc:
            result = f"post-hook deny: {exc}"
            is_error = True
        except PostToolUseBlocked as exc:
            reason = str(exc) if str(exc) else (exc.args[0] if exc.args else "")
            result = f"blocked: {reason}"
            is_error = True

        state.messages.append(
            self._tool_msg(call.id, result, is_error=is_error),
        )

    async def _apply_post_hooks(
        self,
        call: ToolCall,
        result: Any,
    ) -> tuple[Any, bool]:
        """Run the post-hook chain over a successful tool result.

        First non-None ``updated_output`` wins (subsequent hooks see
        the rewritten value as their ``result`` argument).
        ``additional_context`` strings append in registration order.
        ``decision="block"`` raises :class:`PostToolUseBlocked` (caught
        in :meth:`_run_one_tool`).

        Hooks raising arbitrary exceptions are fail-open per R6:
        warning logged, original (or already-rewritten) result
        preserved.
        """
        is_error = False
        for hook in self.post_hooks:
            try:
                decision = await hook(call.name, call.args, result)
            except (PostToolDeny, PostToolUseBlocked):
                # Re-raise so _run_one_tool's outer handler synthesises
                # the right error shape.
                raise
            except Exception:  # noqa: BLE001 — fail-open per R6
                logger.warning(
                    "post_hook raised; swallowed and original output preserved",
                    exc_info=True,
                )
                continue

            if decision is None:
                # Legacy 1.x observational hook — emit one-shot warning
                # and continue with unmutated result.
                _warn_legacy_hook_once(hook)
                continue

            if not isinstance(decision, PostToolUseDecision):
                # Defensive: hook returned something truthy but wrong
                # shape. Treat as observational + warn so the plugin
                # author notices.
                logger.warning(
                    "post_hook returned non-PostToolUseDecision value %r; ignored",
                    type(decision).__name__,
                )
                continue

            if decision.decision == "block":
                raise PostToolUseBlocked(decision.reason or "post-hook block")

            if decision.updated_output is not None:
                # First non-None wins: subsequent hooks see the
                # rewritten value as `result`. We do *not* track a
                # "locked" flag — instead, this assignment makes the
                # rewrite visible to the next iteration's hook call,
                # which is the documented "first non-None wins" path
                # (a later hook can re-rewrite, but per spec the first
                # rewrite already mutated the value the chain operates
                # on).
                result = decision.updated_output

            if decision.additional_context is not None:
                # Append to the result. Type preservation for the hook
                # chain (RED Opus HIGH-5, 2026-05-01):
                #
                # * str   → concatenate (cheap, preserves observability)
                # * dict  → wrap as {"output": <orig>, "additional_context": ctx}
                #           so a subsequent hook still sees structured
                #           data, not a stringified blob. Final
                #           ``_tool_msg`` JSON-serialises whatever the
                #           chain ends with.
                # * list  → wrap identically to dict (preserves the
                #           sequence + adds the context field).
                # * other → stringify-then-append (CC permissive
                #           contract; matches CC SDK April 2026
                #           ``additionalContext`` shape).
                if isinstance(result, str):
                    result = result + decision.additional_context
                elif isinstance(result, (dict, list)):
                    result = {
                        "output": result,
                        "additional_context": decision.additional_context,
                    }
                else:
                    result = (
                        json.dumps(result, default=str, ensure_ascii=False)
                        + decision.additional_context
                    )

        return result, is_error

    @staticmethod
    def _tool_msg(
        call_id: str,
        result: Any,
        *,
        is_error: bool,
    ) -> dict[str, Any]:
        content = (
            result
            if isinstance(result, str)
            else json.dumps(result, default=str, ensure_ascii=False)
        )
        return {
            "role": "tool",
            "tool_call_id": call_id,
            "content": content,
            "is_error": is_error,
        }


__all__ = [
    "AgentLoop",
    "AgentState",
    "LLMCall",
    "LLMResponse",
    "PermissionDenied",
    "PostToolDeny",
    "PostToolUseBlocked",
    "PostToolUseDecision",
    "PostToolUseFailureHook",
    "PostToolUseHook",
    "PreToolUseHook",
    "Tool",
    "ToolCall",
]
