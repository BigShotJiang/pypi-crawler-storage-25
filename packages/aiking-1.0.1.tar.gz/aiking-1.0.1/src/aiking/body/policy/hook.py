# SPDX-License-Identifier: Apache-2.0
"""Policy → :data:`PreToolUseHook` adapter (A4).

The hook runs **before** the guard hook in the recommended
ordering: cheap deterministic rules first, expensive semantic
classification second.
"""

from __future__ import annotations

from typing import Any

from ..engine.agent_loop import PermissionDenied, PreToolUseHook
from .dsl import PermissionAsk, Policy


def make_policy_pre_hook(policy: Policy) -> PreToolUseHook:
    """Build a PreToolUseHook that enforces ``policy``.

    Decisions
    ---------
    * ``"allow"`` → return silently (hook is a no-op).
    * ``"deny"`` → raise :class:`PermissionDenied`. The agent loop
      records it as an ``is_error`` tool message and lets the LLM
      continue.
    * ``"ask"`` → raise :class:`PermissionAsk`. Same loop recovery
      mechanism, but the outer caller can detect the exception type
      and route to a human-in-the-loop channel.
    """

    async def _hook(tool_name: str, args: dict[str, Any]) -> None:
        decision, reason, rule = policy.evaluate(tool_name, args)
        if decision == "allow":
            return
        message = reason or (
            f"policy {decision} on {tool_name}"
            + (f" (rule: {rule.tool}/{rule.arg_patterns})" if rule else "")
        )
        if decision == "ask":
            raise PermissionAsk(message)
        raise PermissionDenied(message)

    return _hook


__all__ = ["make_policy_pre_hook"]
