# SPDX-License-Identifier: Apache-2.0
"""persona.hooks.builtins -- Default in-tree subscribers for the Sancio fanout.

This module ships at least one default subscriber per fanout group so the
``sancio.hooks.session_start`` / ``sancio.hooks.session_stop`` entry-point
groups are non-empty after a fresh ``pip install persona-api``.

Why ship a default subscriber
-----------------------------
The fanout registry in :mod:`persona.hooks.fanout` resolves out-of-process
subscribers via setuptools entry-points. If the project ships zero entries
for a group, ``importlib.metadata.entry_points(group=...)`` returns an empty
selection and the registry path is effectively dead code on a fresh install
— the only subscribers the runtime ever sees are in-process registrations
made by host code or tests.

Shipping a tiny ``LoggingSubscriber`` as the default does three things:

1. Verifies the entry-point wiring round-trips through the wheel
   (``unzip -p persona_api-*.whl '*entry_points.txt'`` shows the group).
2. Gives operators a zero-config audit trail of session lifecycle events
   on stderr — useful when triaging "did the SessionStart hook fire?"
   in production without attaching a debugger.
3. Acts as a smoke-test fixture for the entry-point loader (see
   ``tests/test_fanout_entry_points.py``).

The subscriber is intentionally fail-open and side-effect-free beyond a
``logging.getLogger(__name__).info`` call — the fanout itself swallows
exceptions, but a default subscriber that crashes on every session would
spam stderr and obscure real subscriber failures.

Switchability
-------------
Operators who want a silent runtime can:

* Set the ``persona.hooks.builtins`` logger level to ``WARNING`` or higher
  (``logging.getLogger("persona.hooks.builtins").setLevel(logging.WARNING)``).
* Or unregister the entry-point at the host layer if a downstream
  distribution repackages the wheel without the default group entries.

The subscriber does not consult any feature flag because the cost of a
single ``logger.info`` call per session boundary is trivially small and
the toggle is already available via standard logging configuration.

@module persona.hooks.builtins
@responsibility Provide cost-free default subscribers for the Sancio
    fanout entry-point groups so the wired surface is non-empty out of
    the box.
@dependencies stdlib only (logging).
@exports LoggingSubscriber, on_session_start, on_session_stop.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from aiking.body.hooks.fanout import SessionEvent

logger = logging.getLogger(__name__)


class LoggingSubscriber:
    """Default fanout subscriber that emits a single ``INFO`` log per event.

    The class form is preferred over a bare module-level function because
    the entry-point spec lets us keep both the start and stop callables
    co-located under one symbol — host code can construct one instance
    and register both methods with the in-process API if it ever needs
    to bypass the entry-point path. The fanout loader treats any callable
    as a subscriber, so binding methods on a class is sufficient.

    The instance is stateless; concurrent fanouts are safe because the
    ``logging`` module guarantees thread-safe handler dispatch.
    """

    def __call__(self, event: SessionEvent) -> None:
        """Dispatch by ``event.phase`` so a single instance can serve both groups."""
        if event.phase == "start":
            self.on_session_start(event)
        else:
            self.on_session_stop(event)

    def on_session_start(self, event: SessionEvent) -> None:
        """Emit a SessionStart audit line. Fail-open by design."""
        logger.info(
            "sancio.session_start session_id=%s started_at=%s extra=%s",
            event.session_id,
            event.started_at,
            event.extra,
        )

    def on_session_stop(self, event: SessionEvent) -> None:
        """Emit a SessionStop audit line. Fail-open by design."""
        logger.info(
            "sancio.session_stop session_id=%s started_at=%s extra=%s",
            event.session_id,
            event.started_at,
            event.extra,
        )


# Module-level singletons for entry-point resolution. Setuptools loads
# the symbol named in ``pyproject.toml`` directly; pointing entries at
# these bound methods avoids forcing every plugin host to instantiate
# ``LoggingSubscriber()`` themselves.
_default_subscriber = LoggingSubscriber()


def on_session_start(event: SessionEvent) -> None:
    """Module-level alias for the default SessionStart subscriber.

    Kept as a free function so the entry-point can reference
    ``persona.hooks.builtins:on_session_start`` without forcing the
    fanout loader to know about the class. Both shapes are tested.
    """
    _default_subscriber.on_session_start(event)


def on_session_stop(event: SessionEvent) -> None:
    """Module-level alias for the default SessionStop subscriber."""
    _default_subscriber.on_session_stop(event)


__all__ = [
    "LoggingSubscriber",
    "on_session_start",
    "on_session_stop",
]
