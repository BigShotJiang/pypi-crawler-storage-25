# SPDX-License-Identifier: Apache-2.0
"""UserPromptSubmit hook adapter for proactive Skill discovery.

Wires :class:`persona.skills_proactive.SkillDiscovery` into Sancio's
:class:`persona.engine.agent_loop.AgentLoop` user-prompt slot. The hook
is intentionally **advisory only** — it injects a single line
``[skill_proactive] Consider using /<name> — <reason>`` per match into
the agent's stderr / system reminder channel and never blocks the LLM
turn.

Why this lives in Sancio not Concinno (per CLAUDE.md boundary): the
proactive surface depends on cross-session reward feedback (did the
user actually invoke the suggested skill?) which Concinno cannot
observe — only Sancio's agent loop sees the subsequent tool calls.
When CC ships a runtime that exposes the same observation hook,
this module migrates back into Concinno (ceiling retraction rule).

Usage::

    from aiking.body.hooks.skill_proactive_hook import (
        make_skill_proactive_hook,
    )

    hook = make_skill_proactive_hook()
    # ... wire into AgentLoop user-prompt callbacks ...
"""

from __future__ import annotations

import sys
from collections.abc import Awaitable, Callable
from typing import Any

from persona.skills_proactive import Match, SkillDiscovery, is_disabled

__all__ = [
    "format_hint_lines",
    "make_skill_proactive_hook",
]

# Hook signature: (user_prompt) -> str | None. Returning None signals
# "no advisory output"; returning a non-empty string is the system
# reminder to inject. Async to match other Sancio hooks
# (cerno_hook / guard_hook).
SkillProactiveHook = Callable[[str], Awaitable[str | None]]


def format_hint_lines(matches: list[Match]) -> str:
    """Format matches as ``[skill_proactive] Consider using /<name> — <reason>``.

    Returns the empty string when ``matches`` is empty so callers can
    treat the result as a single advisory blob.
    """
    if not matches:
        return ""
    lines = [
        f"[skill_proactive] Consider using /{m.skill_name} — {m.reason}"
        for m in matches
    ]
    return "\n".join(lines)


def make_skill_proactive_hook(
    discovery: SkillDiscovery | None = None,
    *,
    k: int = 3,
    write_stderr: bool = True,
) -> SkillProactiveHook:
    """Build a UserPromptSubmit hook bound to ``discovery``.

    Parameters
    ----------
    discovery:
        Optional pre-built :class:`SkillDiscovery`. Tests inject a fake
        with a ``judge_fn`` to avoid the Anthropic call. Default = a
        fresh instance scanning ``~/.claude/skills``.
    k:
        Top-K matches to surface. Default 3 — beyond that the hint
        becomes noise.
    write_stderr:
        When True (default) the formatted hint is also echoed to
        ``sys.stderr`` so the cc-cortex hook surface picks it up. The
        return value is the same string in both modes — callers can
        choose to inject directly into a system reminder instead.
    """
    inst = discovery or SkillDiscovery()

    async def _hook(user_prompt: str) -> str | None:
        if is_disabled():
            return None
        try:
            matches = inst.discover(user_prompt, k=k)
        except Exception as exc:  # pragma: no cover - defensive
            # Advisory hook must never break the user prompt flow.
            print(
                f"[skill_proactive] discovery raised {exc!r} — skipping",
                file=sys.stderr,
            )
            return None
        text = format_hint_lines(matches)
        if not text:
            return None
        if write_stderr:
            print(text, file=sys.stderr)
        return text

    return _hook


# Convenience for unit tests that want to call discover() synchronously
# without spawning the asyncio glue.
def discover_sync(prompt: str, k: int = 3, **kwargs: Any) -> list[Match]:
    """Synchronous discover — testing/CLI shortcut."""
    inst = SkillDiscovery(**kwargs)
    return inst.discover(prompt, k=k)
