# SPDX-License-Identifier: Apache-2.0
"""Cerno → :data:`PostToolUseHook` adapter (A3).

**Sancio 2.0.0 — Option C reframe** (see
``_AI_BRAIN/05_Planning/2026-05-01-l6-posttooluse-design-conflict-options.md``):
post-hooks now support **observation-channel deny** + **Pre-hook
escalation**. CC physics still hold (post-hook cannot block side
effects per GitHub anthropics/claude-code#32105) — what Cerno owns is
the LLM-visible channel and the cross-iteration policy state.

Legacy default (no ``redact_fn`` / ``deny_on_action``) remains
**observational**: returns ``None``, listeners fire, no rewrite, no
deny. Plugins that depend on the 1.x telemetry-only contract see no
behaviour change.

New optional kwargs:

* ``redact_fn`` — when supplied, the hook returns a
  :class:`PostToolUseDecision` with ``updated_output`` set to the
  callable's return value. This is the "Cerno actually rewrites tool
  output" path (e.g. strip leaked credentials before Claude sees them).
* ``deny_on_action`` — predicate over the Cerno cycle's
  :class:`CernoAction`. When it returns ``True``, the hook raises
  :class:`PostToolDeny` with the action's reason — agent loop
  catches this and replaces the tool result with an ``is_error=True``
  message before the LLM iterates.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from persona.cerno import Cerno, CernoAction
from .post_decision import PostToolDeny, PostToolUseDecision

if TYPE_CHECKING:
    # Type-only import — avoids the circular load order:
    # agent_loop.py -> hooks.post_decision (triggers hooks/__init__.py)
    # -> cerno_hook -> agent_loop.PostToolUseHook (not yet defined).
    from ..engine.agent_loop import PostToolUseHook


@dataclass
class CernoHookEvent:
    """One Cerno review result. Passed to each subscribed listener."""

    tool_name: str
    tool_args: dict[str, Any]
    tool_result: Any
    action: CernoAction


Listener = Callable[[CernoHookEvent], None]
RedactFn = Callable[[str, dict[str, Any], Any], Any | None]
"""Optional output rewriter. Return None to leave output unchanged."""

DenyPredicate = Callable[[CernoAction], bool]
"""Optional deny predicate. Return True to raise :class:`PostToolDeny`."""


def _stringify(value: Any) -> str:
    if isinstance(value, str):
        return value
    try:
        return str(value)
    except Exception:  # noqa: BLE001 — stringification must never raise
        return "<unstringifiable>"


def _action_reason(action: CernoAction) -> str:
    """Best-effort reason extraction across Cerno action variants."""
    reason = getattr(action, "reason", None)
    if reason:
        return str(reason)
    return f"cerno {getattr(action, 'type', 'deny')} verdict"


def make_cerno_post_hook(
    cerno: Cerno,
    *,
    user_input_provider: Callable[[], str] | None = None,
    listeners: list[Listener] | None = None,
    redact_fn: RedactFn | None = None,
    deny_on_action: DenyPredicate | None = None,
) -> PostToolUseHook:
    """Build a PostToolUseHook that feeds tool output through Cerno.cycle.

    Parameters
    ----------
    cerno:
        A live :class:`Cerno` instance. Multi-tenant setups use one
        cerno per child_id; :class:`persona.cerno_registry.
        CernoRegistry` is the canonical store.
    user_input_provider:
        Zero-arg callable returning the current ``user_input`` string
        for this turn. When ``None``, the hook synthesises one from
        the tool name/args — good enough for telemetry but loses the
        mother-agent's independent judgment signal, so provide a real
        one when integrating into :meth:`persona.engine.PersonaEngine
        .run_agent`.
    listeners:
        Optional list of callbacks invoked with an
        :class:`CernoHookEvent`. Listener exceptions are swallowed
        (matches :meth:`Cerno._emit` semantics) so one bad listener
        cannot poison the loop.
    redact_fn:
        Optional ``(tool_name, args, result) -> rewritten | None``
        callable. When it returns a non-None value, the hook returns
        ``PostToolUseDecision(updated_output=...)`` so the agent loop
        replaces the LLM-visible output. CC SDK April 2026
        ``updatedToolOutput`` parity, plus Sancio's unique
        ``is_error`` flag on the synthesised replacement (see
        :mod:`persona.hooks.post_decision`).
    deny_on_action:
        Optional ``(CernoAction) -> bool`` predicate. When it returns
        ``True`` for the cycle's verdict, the hook raises
        :class:`PostToolDeny` with the action's reason. Agent loop
        catches and replaces the tool result with an ``is_error=True``
        message before the next LLM iteration. This is the Option C
        observation-channel deny path Cerno's deny verdicts wire into
        — they are no longer silently swallowed.

    Backwards-compat: default (both ``redact_fn`` and
    ``deny_on_action`` ``None``) is identical to the 1.x observational
    contract — returns ``None``, listeners fire, no rewrite, no deny.
    Existing telemetry-only consumers see zero behaviour change.
    """
    subs = listeners or []

    async def _hook(
        tool_name: str,
        args: dict[str, Any],
        result: Any,
    ) -> PostToolUseDecision | None:
        child_output = _stringify(result)
        user_input = (
            user_input_provider()
            if user_input_provider is not None
            else f"{tool_name} {args}"
        )
        action = cerno.cycle(user_input, child_output)

        event = CernoHookEvent(
            tool_name=tool_name,
            tool_args=args,
            tool_result=result,
            action=action,
        )
        for listener in subs:
            try:
                listener(event)
            except Exception:  # noqa: BLE001 — observational only
                pass

        # Option C — observation-channel deny. Raised exception is
        # caught by AgentLoop._run_one_tool and synthesised into an
        # is_error=True tool message. Side effects of the tool already
        # happened (CC physics); only the LLM-visible channel is
        # denied.
        if deny_on_action is not None and deny_on_action(action):
            raise PostToolDeny(_action_reason(action))

        # CC SDK April 2026 updatedToolOutput parity — when redact_fn
        # supplies a non-None rewrite, surface it as a structured
        # PostToolUseDecision so the loop knows to replace the
        # LLM-visible output.
        if redact_fn is not None:
            rewritten = redact_fn(tool_name, args, result)
            if rewritten is not None:
                return PostToolUseDecision(updated_output=rewritten)

        # Default observational mode — return zero-field decision (NOT
        # None) so the agent loop's legacy-hook DeprecationWarning shim
        # does not fire on every Sancio production tool call. Sancio's
        # own default ships warning against itself = log spam (RED Opus
        # FATAL-3, 2026-05-01). A zero-field PostToolUseDecision is
        # semantically identical to None (no rewrite, no append, no
        # block) but signals "I'm a 2.0+ aware hook".
        return PostToolUseDecision()

    return _hook


__all__ = [
    "CernoHookEvent",
    "DenyPredicate",
    "Listener",
    "RedactFn",
    "make_cerno_post_hook",
]
