# SPDX-License-Identifier: Apache-2.0
"""Geographic export-control middleware.

U.S. Export Administration Regulations (EAR) + Anthropic's own
terms of service make a short list of jurisdictions off-limits for
Sancio even if Cloudflare's WAF misses a request. This middleware
is the **defense-in-depth** layer: Cloudflare's WAF firewall rule
is the primary gate (see ``docs/export-control.md``), and this
ASGI middleware is the local backstop that reads the
``Cf-IPCountry`` header (Cloudflare enrichment) and returns HTTP
451 Unavailable For Legal Reasons for any blocked country.

Blocked list defaults to the U.S. EAR embargoed + sanctioned set
that intersects with Anthropic's "Unsupported" region list. The
``SANCIO_GEO_BLOCK_COUNTRIES`` env var can override (comma-separated
ISO 3166-1 alpha-2 codes). Setting it to an empty string disables
the middleware (the AuthMiddleware still guards auth-protected
paths — this is purely about refusing service to the region).

Design notes
------------

* The middleware runs on every HTTP / WebSocket request, ahead of
  the router, so a 451 takes precedence over 401 / 404 / 405.
* ``Cf-IPCountry`` is set by Cloudflare (``XX`` when unknown,
  ``T1`` for Tor). Unknown/missing is ALLOWED — we do not want to
  block a cold-booted VPS request from the VPS itself where no
  Cloudflare header is present.
* Headers are compared case-insensitively; ISO codes are always
  uppercase.
* The 451 body is a JSON envelope that mirrors our other error
  responses so clients can surface it without a special parser.
"""

from __future__ import annotations

import logging
import os

from starlette.responses import JSONResponse
from starlette.types import ASGIApp, Receive, Scope, Send

_LOG = logging.getLogger("persona.geo_block")


# Default list is U.S. EAR embargoed set overlapping Anthropic's
# Unsupported Regions — these four are the conservative core. The
# env override can add more (for example, sub-national rules added
# after ship).
DEFAULT_BLOCKED_COUNTRIES: frozenset[str] = frozenset({
    "CN",  # PRC mainland (China)
    "IR",  # Iran
    "KP",  # North Korea
    "SY",  # Syria
    "CU",  # Cuba
})


def _parse_env_countries(raw: str) -> frozenset[str]:
    """Parse a comma-separated ISO-alpha-2 list into a frozenset."""
    codes = {
        part.strip().upper()
        for part in raw.split(",")
        if part.strip()
    }
    # Defensive — drop anything that isn't 2 letters.
    return frozenset(c for c in codes if len(c) == 2 and c.isalpha())


def _blocked_countries() -> frozenset[str]:
    """Resolve the live blocked list.

    * ``SANCIO_GEO_BLOCK_COUNTRIES`` unset → DEFAULT_BLOCKED_COUNTRIES.
    * ``SANCIO_GEO_BLOCK_COUNTRIES=""`` → empty (middleware is a no-op).
    * ``SANCIO_GEO_BLOCK_COUNTRIES="CN,IR,BY"`` → that exact list.
    """
    raw = os.environ.get("SANCIO_GEO_BLOCK_COUNTRIES")
    if raw is None:
        return DEFAULT_BLOCKED_COUNTRIES
    return _parse_env_countries(raw)


def _extract_country(scope: Scope) -> str:
    """Pull ``Cf-IPCountry`` from the ASGI headers list.

    Returns uppercase 2-letter code, or empty string if the header
    is missing / malformed / Cloudflare emitted ``XX`` (unknown).
    """
    for name, value in scope.get("headers") or []:
        if name == b"cf-ipcountry":
            code = value.decode("ascii", errors="ignore").strip().upper()
            if len(code) == 2 and code.isalpha():
                return code
            return ""
    return ""


class GeoBlockMiddleware:
    """ASGI middleware that returns 451 for export-controlled countries.

    Placed *before* :class:`persona.auth.AuthMiddleware` in the
    factory so a blocked-region request never consumes auth cycles.
    """

    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(
        self, scope: Scope, receive: Receive, send: Send,
    ) -> None:
        scope_type = scope.get("type")
        if scope_type not in ("http", "websocket"):
            await self.app(scope, receive, send)
            return

        blocked = _blocked_countries()
        if not blocked:
            # Middleware disabled — short-circuit for the cheapest path.
            await self.app(scope, receive, send)
            return

        country = _extract_country(scope)
        if country and country in blocked:
            _LOG.warning(
                "geo_block: refusing request from %s (path=%s)",
                country, scope.get("path", ""),
            )
            if scope_type == "websocket":
                # 4451 is a private WebSocket close code (4000-4999
                # range reserved for application use). Mirrors the
                # HTTP 451 semantics for WS clients.
                await send({"type": "websocket.close", "code": 4451})
                return
            response = JSONResponse(
                {
                    "error": "unavailable_for_legal_reasons",
                    "detail": (
                        "This service is not available in your "
                        "jurisdiction due to U.S. export control "
                        "regulations. See "
                        "GET /v1/privacy for details."
                    ),
                    "country": country,
                },
                status_code=451,
            )
            await response(scope, receive, send)
            return

        await self.app(scope, receive, send)
