"""aiking — public CLI + thin SDK (Apache-2.0).

The substantive engine lives in ``aiking_core``. This package is the
permissively-licensed adopter-facing surface and re-exports a curated
subset of the engine API.

Phase 1 Foundation: skeleton only. Public surface is wired up in
subsequent phases per
``C:/Users/zerox/.claude/plans/serene-skipping-creek.md``.
"""

__version__ = "1.0.1"
