# AI King

Single-distribution AI agent platform stack — governance, body, substrate, and
optional engine in one `pip install`.

## Install

    pip install aiking          # shell + transitive engine + concinno migration deps
    pip install "aiking[body]"  # add aiking.body.engine adapters (persona-api)
    pip install "aiking[memoria]"  # Windows-only RAM cleanup tray (concinno-skills-memoria)
    pip install "aiking[skills]"   # full opt-in skill suite

## Quick check

    aiking --version
    aiking info
    aiking layers

`aiking info` prints the installed substrate adapter (defaults to the
vendored MIT `fork` substrate) and any `aiking.core_engine` entry points
discovered from `aiking-core`.

## What you get

| Layer       | Module                | License                        |
| ----------- | --------------------- | ------------------------------ |
| Governance  | `aiking.governance`   | Apache-2.0                     |
| Body        | `aiking.body`         | Apache-2.0                     |
| Substrate   | `aiking.substrate`    | Apache-2.0                     |
| Engine      | `aiking_core`         | AGPL-3.0-or-later / Commercial |

The `aiking` shell is permissively Apache-2.0 licensed. The substantive
engine (ZIQ, FieldRead, Cerno, guards, runtime, PSYCHE) lives in
`aiking-core` (AGPL-3.0-or-later, commercial dual). They are wired
together via the `aiking.core_engine` entry-point group — the shell does
not `import aiking_core` directly, preserving the AGPL boundary.

## Migrating from concinno / persona-api

The 5.3.0 release of `concinno` and the 2.1.0 release of `persona-api`
emit `DeprecationWarning` and forward to `aiking` modules. Removal is
scheduled for `concinno 6.0.0` / `persona-api 3.0.0` (~2026-11-01).

Update imports:

    from concinno.guards.X      → from aiking.governance.guards.X
    from concinno.cognitive.Y   → from aiking.governance.c0_router (re-export)
    from concinno.ziq           → from aiking_core.ziq
    from concinno.field_read    → from aiking_core.fieldread
    from persona.engine         → from aiking.body.engine
    from persona.cerno          → from aiking_core.cerno

## Known caveat (1.0.1)

`from aiking.body import engine` requires `pip install "aiking[body]"` to
pull `persona-api`. As of `persona-api 2.1.0` the package has an
upstream `from .engine import PersonaEngine` self-import bug that
prevents `import persona` from succeeding even when installed. Wait for
`persona-api 2.1.1` for that path to work end-to-end. Everything else —
`aiking info`, `aiking layers`, `from aiking_core import ziq`,
`from aiking_core import fieldread`, `from aiking_core import cerno`,
`from aiking.governance import guards`,
`from aiking.substrate import get_substrate` — is verified working from
a clean `pip install aiking` on Python 3.10–3.13.

## License

Apache License, Version 2.0. See [`LICENSE`](./LICENSE). The optional
`aiking-core` engine is AGPL-3.0-or-later (commercial dual; see
[`COMMERCIAL_LICENSE.md`](../aiking-core/COMMERCIAL_LICENSE.md)).

## Source

<https://github.com/aiking931931/ai-king>
