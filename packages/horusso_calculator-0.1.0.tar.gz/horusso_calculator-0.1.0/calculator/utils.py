#!/usr/bin/env python3


def sum(x, y):

    return x + y


def res(x, y):

    return x - y


def mult(x, y):

    return x * y

def div(x, y)
    
    if y != 0:

        return x / y
    
    else:
        
        return None

