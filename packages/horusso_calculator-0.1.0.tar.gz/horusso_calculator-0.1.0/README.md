# Math Operations Script

This script provides basic arithmetic functions for addition, subtraction, multiplication, and division.

## Implementation

```python
#!/usr/bin/env python3

def sum(x, y):
    """Returns the sum of x and y."""
    return x + y

def res(x, y):
    """Returns the difference of x and y."""
    return x - y

def mult(x, y):
    """Returns the product of x and y."""
    return x * y

def div(x, y):
    """
    Returns the division of x by y. 
    Returns None if y is 0 to avoid ZeroDivisionError.
    """
    if y != 0:
        return x / y
    else:
        return None
