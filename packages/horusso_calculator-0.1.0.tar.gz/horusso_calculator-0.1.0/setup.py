from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="horusso_calculator",                 
    version="0.1.0",
    author="Horusso",
    description="Packages just for learning purposes related to a calculator",
    long_description=long_description,
    long_description_content_type="text/markdown",
    
    packages=find_packages(),

    python_requires=">=3.8",

    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
