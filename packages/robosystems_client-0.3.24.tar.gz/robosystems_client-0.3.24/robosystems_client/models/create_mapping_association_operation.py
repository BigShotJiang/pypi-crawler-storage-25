from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.create_mapping_association_operation_association_type import (
  CreateMappingAssociationOperationAssociationType,
)
from ..types import UNSET, Unset

T = TypeVar("T", bound="CreateMappingAssociationOperation")


@_attrs_define
class CreateMappingAssociationOperation:
  """Create one CoA → reporting-concept mapping edge.

  This is the iterative, AI-assisted craft path. Each call adds a single
  association to the target mapping structure. Use `auto-map-elements`
  to create many at once via the MappingAgent. Reject duplicates: if
  the (from, to, type) tuple already exists, the call returns 409.

      Attributes:
          from_element_id (str): Source element (typically a CoA element).
          to_element_id (str): Target element (typically a US GAAP reporting concept).
          mapping_id (str): Target mapping structure ID.
          association_type (CreateMappingAssociationOperationAssociationType | Unset): Edge semantics. `mapping` rolls up
              CoA elements into reporting concepts; `presentation` orders concepts in a structure; `calculation` carries
              debit/credit weights; `equivalence` is a synonym link. Default:
              CreateMappingAssociationOperationAssociationType.MAPPING.
          order_value (float | None | Unset): Display order within the structure (lower = earlier).
          weight (float | None | Unset): Calculation weight (typically +1.0 or -1.0). Used by calculation linkbases to
              express signed roll-ups.
          confidence (float | None | Unset): Confidence score (0–1). For AI-suggested mappings: ≥0.90 auto-approved,
              0.70–0.89 flagged for review, <0.70 skipped.
          suggested_by (None | str | Unset): Source of the suggestion (e.g., 'mapping_agent', 'user'). Captured for audit;
              not used by the runtime.
  """

  from_element_id: str
  to_element_id: str
  mapping_id: str
  association_type: CreateMappingAssociationOperationAssociationType | Unset = (
    CreateMappingAssociationOperationAssociationType.MAPPING
  )
  order_value: float | None | Unset = UNSET
  weight: float | None | Unset = UNSET
  confidence: float | None | Unset = UNSET
  suggested_by: None | str | Unset = UNSET
  additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

  def to_dict(self) -> dict[str, Any]:
    from_element_id = self.from_element_id

    to_element_id = self.to_element_id

    mapping_id = self.mapping_id

    association_type: str | Unset = UNSET
    if not isinstance(self.association_type, Unset):
      association_type = self.association_type.value

    order_value: float | None | Unset
    if isinstance(self.order_value, Unset):
      order_value = UNSET
    else:
      order_value = self.order_value

    weight: float | None | Unset
    if isinstance(self.weight, Unset):
      weight = UNSET
    else:
      weight = self.weight

    confidence: float | None | Unset
    if isinstance(self.confidence, Unset):
      confidence = UNSET
    else:
      confidence = self.confidence

    suggested_by: None | str | Unset
    if isinstance(self.suggested_by, Unset):
      suggested_by = UNSET
    else:
      suggested_by = self.suggested_by

    field_dict: dict[str, Any] = {}
    field_dict.update(self.additional_properties)
    field_dict.update(
      {
        "from_element_id": from_element_id,
        "to_element_id": to_element_id,
        "mapping_id": mapping_id,
      }
    )
    if association_type is not UNSET:
      field_dict["association_type"] = association_type
    if order_value is not UNSET:
      field_dict["order_value"] = order_value
    if weight is not UNSET:
      field_dict["weight"] = weight
    if confidence is not UNSET:
      field_dict["confidence"] = confidence
    if suggested_by is not UNSET:
      field_dict["suggested_by"] = suggested_by

    return field_dict

  @classmethod
  def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
    d = dict(src_dict)
    from_element_id = d.pop("from_element_id")

    to_element_id = d.pop("to_element_id")

    mapping_id = d.pop("mapping_id")

    _association_type = d.pop("association_type", UNSET)
    association_type: CreateMappingAssociationOperationAssociationType | Unset
    if isinstance(_association_type, Unset):
      association_type = UNSET
    else:
      association_type = CreateMappingAssociationOperationAssociationType(
        _association_type
      )

    def _parse_order_value(data: object) -> float | None | Unset:
      if data is None:
        return data
      if isinstance(data, Unset):
        return data
      return cast(float | None | Unset, data)

    order_value = _parse_order_value(d.pop("order_value", UNSET))

    def _parse_weight(data: object) -> float | None | Unset:
      if data is None:
        return data
      if isinstance(data, Unset):
        return data
      return cast(float | None | Unset, data)

    weight = _parse_weight(d.pop("weight", UNSET))

    def _parse_confidence(data: object) -> float | None | Unset:
      if data is None:
        return data
      if isinstance(data, Unset):
        return data
      return cast(float | None | Unset, data)

    confidence = _parse_confidence(d.pop("confidence", UNSET))

    def _parse_suggested_by(data: object) -> None | str | Unset:
      if data is None:
        return data
      if isinstance(data, Unset):
        return data
      return cast(None | str | Unset, data)

    suggested_by = _parse_suggested_by(d.pop("suggested_by", UNSET))

    create_mapping_association_operation = cls(
      from_element_id=from_element_id,
      to_element_id=to_element_id,
      mapping_id=mapping_id,
      association_type=association_type,
      order_value=order_value,
      weight=weight,
      confidence=confidence,
      suggested_by=suggested_by,
    )

    create_mapping_association_operation.additional_properties = d
    return create_mapping_association_operation

  @property
  def additional_keys(self) -> list[str]:
    return list(self.additional_properties.keys())

  def __getitem__(self, key: str) -> Any:
    return self.additional_properties[key]

  def __setitem__(self, key: str, value: Any) -> None:
    self.additional_properties[key] = value

  def __delitem__(self, key: str) -> None:
    del self.additional_properties[key]

  def __contains__(self, key: str) -> bool:
    return key in self.additional_properties
