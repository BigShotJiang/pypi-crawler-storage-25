import typer

from caliper.commands.run import run_cmd
from caliper.commands.new import new_cmd
from caliper.commands.report import report_cmd
from caliper.commands.list_cmd import list_cmd_fn
from caliper.commands.validate import validate_cmd
from caliper.commands.install_skill import install_skill_cmd

app = typer.Typer(
    name="caliper",
    help="[bold cyan]caliper[/bold cyan] — evaluate AI skills with confidence",
    rich_markup_mode="rich",
    no_args_is_help=True,
)

app.command("run", help="Run an evaluation spec")(run_cmd)
app.command("new", help="Create a new evaluation spec (interactive wizard)")(new_cmd)
app.command("report", help="Render saved evaluation results")(report_cmd)
app.command("list", help="List evaluation specs and past runs")(list_cmd_fn)
app.command("validate", help="Validate an evaluation spec file")(validate_cmd)
app.command("install-skill", help="Install the bundled evaluate-skill agent skill")(install_skill_cmd)


def main() -> None:
    app()


if __name__ == "__main__":
    main()
