# Changelog

All notable changes to this project will be documented in this file.

This project loosely follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and uses semantic versioning where practical.
## [0.1.4] - 2026-05-03
### Added
- Make the Textual REPL UI the default chat interface, with multiline input, subdued colors, visual speaker separators, step-end markers, and cleaner tool-call rendering.
- Add assistant turn and assistant step lifecycle events for UI and runtime integrations.
- Add a `/voice` command to show, toggle, or select the configured voice mode.

### Changed
- Remove the legacy prompt-toolkit chat UI and the temporary `--textual` CLI flag.

### Tests
- Add CLI coverage for starting the default chat UI and update chat status formatting tests.


## [0.1.3] - 2026-05-03
### Added
- Send the current session id as `prompt_cache_key` to the Codex backend, enabling server-side prompt cache reuse across calls from the same session.

### Tests
- Add regression coverage for prompt cache key propagation through agent response calls and Codex stream parameters.


## [0.1.2] - 2026-05-03
### Added
- Add a `/clear` terminal chat command that clears the screen without touching session history.

### Tests
- Add regression coverage ensuring terminal screen clearing does not append session messages.


## [0.1.1] - 2026-05-03
### Fixed
- Validate `ImageMessage` content before adding it to session state.
- Prevent invalid or inaccessible observed images from polluting a session and breaking later SDK calls.

### Tests
- Add regression coverage for valid and invalid `ImageMessage` validation.
- Verify `Agent.add_image()` rejects invalid images without appending a broken session message.


## [0.1.0] - 2026-05-03

### Added

- Initial package metadata and console entry point.
- Event-driven agent runtime, session persistence, tools, providers, commands, voice, image, and document extraction modules.
- Test suite for core agent behavior, events, messages, image messages, utilities, and workers.
