from codex_agent import __main__


class FakeAgent:
    instances = []

    def __init__(self, **kwargs):
        self.kwargs = kwargs
        self.interacted = False
        FakeAgent.instances.append(self)

    def interact(self):
        self.interacted = True


def test_cli_starts_default_textual_chat(monkeypatch):
    FakeAgent.instances.clear()
    monkeypatch.setattr(__main__, "Agent", FakeAgent)

    __main__.main([])

    assert FakeAgent.instances[-1].interacted is True
