import json
from typing import Literal

import codex_agent.utils as utils
from codex_agent import Agent, AgentInterrupted, AgentInterruptedEvent, CompactionMessage, ImageGenerationTool, ResponseContentDeltaEvent, ServerToolCallEvent, WebSearchTool, get_agent
from codex_agent.agent import AgentSession
from codex_agent.message import AssistantMessage, DeveloperMessage, MessageChunk, ProviderMessage, ServerToolResponseMessage, ToolResultWrapper
from codex_agent.tool import Tool
from codex_backend_sdk import OutputItem
import pytest


class FakeAI:
    def __init__(self, agent):
        self.agent = agent
        self.params = None

    def run(self, **params):
        self.params = params
        message = AssistantMessage(name="assistant")
        chunk = MessageChunk(content="hi")
        message.add_chunk(chunk)
        self.agent.emit(
            ResponseContentDeltaEvent,
            delta="hi",
            content="hi",
            chunk=chunk,
            message=message,
        )
        return message


class SequencedAI:
    def __init__(self, messages):
        self.messages = list(messages)
        self.params = []

    def run(self, **params):
        self.params.append(params)
        return self.messages.pop(0)


class FakeImageAI:
    def __init__(self, agent, item=None):
        self.agent = agent
        self.params = None
        self.item = item or {
            "type": "image_generation_call",
            "id": "ig_123",
            "result": "Zm9v",
        }

    def run(self, **params):
        self.params = params
        message = AssistantMessage(name="assistant")
        message.add_chunk(MessageChunk(output_items=[self.item]))
        return message


class FakeCodexClient:
    def __init__(self, events):
        self.events = events
        self.args = None
        self.kwargs = None

    def stream(self, *args, **kwargs):
        self.args = args
        self.kwargs = kwargs
        return iter(self.events)


class InterruptingAI:
    def __init__(self, agent):
        self.agent = agent

    def run(self, **_params):
        self.agent.interrupt("test")
        raise AgentInterrupted()

    def abort(self):
        pass


class AbortableAI:
    def __init__(self):
        self.aborted = False

    def abort(self):
        self.aborted = True


class FakeCompactionResult:
    response_id = "resp_123"
    output_items = [{"type": "compaction_summary", "id": "cs_123", "encrypted_content": "opaque"}]


class FakeCompactionClient:
    def __init__(self):
        self.history = None
        self.params = None

    def compact(self, history, **params):
        self.history = history
        self.params = params
        return FakeCompactionResult()


def test_agent_session_as_string_concatenates_message_strings():
    assistant = AssistantMessage(content="I will inspect it.")
    assistant.tool_calls = [{
        "call_id": "call_1",
        "name": "read",
        "arguments": '{"path": "codex_agent/agent.py"}',
    }]
    session = AgentSession(messages=[
        ProviderMessage(name="cwd", content="/home/baptiste/dev/codex-agent"),
        assistant,
    ])

    text = session.as_string()

    assert "<ProviderMessage " in text
    assert "/home/baptiste/dev/codex-agent" in text
    assert "\n\n<AssistantMessage " in text
    assert "I will inspect it." in text
    assert "<tool_call type='function_call' name='read' call_id='call_1'>" in text
    assert '{"path": "codex_agent/agent.py"}' in text


def test_agent_session_compact_inserts_compaction_before_remainder(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    user = DeveloperMessage(content="old session marker")
    done = AssistantMessage(content="done")
    current = DeveloperMessage(content="current unfinished turn")
    session = AgentSession(messages=[user, done, current])
    client = FakeCompactionClient()

    message = session.compact(client=client)

    assert isinstance(message, CompactionMessage)
    assert session.messages == [user, done, message, current]
    assert message.output_items == FakeCompactionResult.output_items
    assert message.compacted_message_count == 2
    assert client.history == [
        {
            "type": "message",
            "role": "developer",
            "content": [{"type": "input_text", "text": "old session marker"}],
        },
        {
            "type": "message",
            "role": "assistant",
            "content": [{"type": "output_text", "text": "done"}],
        },
    ]


def test_agent_session_compact_starts_at_latest_compaction(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    old_user = DeveloperMessage(content="very old")
    old_done = AssistantMessage(content="very old done")
    previous = CompactionMessage(output_items=[{"type": "compaction_summary", "id": "old"}])
    new_user = DeveloperMessage(content="new")
    new_done = AssistantMessage(content="new done")
    session = AgentSession(messages=[old_user, old_done, previous, new_user, new_done])
    client = FakeCompactionClient()

    message = session.compact(client=client)

    assert session.messages == [old_user, old_done, previous, new_user, new_done, message]
    assert client.history[0] == {"type": "compaction_summary", "id": "old"}
    assert "very old" not in json.dumps(client.history)
    assert "new done" in json.dumps(client.history)


def test_agent_get_context_starts_at_latest_compaction():
    agent = Agent(session="new", voice_enabled=False)
    old = DeveloperMessage(content="old hidden context")
    previous = CompactionMessage(output_items=[{"type": "compaction_summary", "id": "cs_123"}])
    current = DeveloperMessage(content="current visible context")
    agent.session.messages = [old, previous, current]

    context = agent.get_context()
    context_text = "\n".join(str(message.get("content", "")) for message in context)

    assert previous in context
    assert current in context
    assert old not in context
    assert "old hidden context" not in context_text


def test_agent_get_context_filters_expired_messages():
    agent = Agent(session="new", voice_enabled=False)
    expired = DeveloperMessage(content="expired hidden context", turns_left=0)
    visible = DeveloperMessage(content="visible context", turns_left=1)
    agent.session.messages = [expired, visible]

    context = agent.get_context()
    context_text = "\n".join(str(message.get("content", "")) for message in context)

    assert visible in context
    assert expired not in context
    assert "expired hidden context" not in context_text


def test_agent_ages_context_messages_once_per_process_loop():
    agent = Agent(session="new", voice_enabled=False, auto_proceed=True)
    expiring = DeveloperMessage(content="still visible", turns_left=2)
    agent.session.messages = [expiring]

    @agent.add_tool
    def echo(value):
        return value

    tool_call = AssistantMessage()
    tool_call.tool_calls = [{
        "type": "function_call",
        "call_id": "call_1",
        "name": "echo",
        "arguments": '{"value": "ok"}',
    }]
    final = AssistantMessage(content="done")
    agent.ai = SequencedAI([tool_call, final])

    assert agent.process() is True

    assert expiring.turns_left == 1


def test_agent_initializes_new_session(isolated_runtime_dir):
    agent = Agent(session="new", voice_enabled=False)

    assert agent.session is not None
    assert agent.current_session_id == agent.session.session_id
    assert " " not in agent.current_session_id
    assert agent.session.session_file.startswith(str(isolated_runtime_dir))
    assert (isolated_runtime_dir / "sessions" / f"{agent.current_session_id}.json").is_file()
    assert agent.session.messages[-1].type == "developer_message"
    assert agent.config.input_token_limit == 128000
    assert agent.config.auto_compact is True
    assert "token_limit" not in agent.config
    assert set(agent.server_tools) == {"web_search", "image_generation"}
    assert agent.shell.silent is True


def test_agent_can_resume_session_from_file():
    agent = Agent(session="new", voice_enabled=False)
    session_file = agent.session.session_file
    message_count = len(agent.session.messages)

    resumed = Agent(session=session_file, voice_enabled=False)

    assert resumed.current_session_id == agent.current_session_id
    assert len(resumed.session.messages) == message_count + 1
    assert resumed.session.messages[-1].type == "developer_message"


def test_agent_can_resume_latest_session(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    older = AgentSession(session_id="20260101_100000", messages=[DeveloperMessage(content="older")])
    newer = AgentSession(session_id="20260102_100000", messages=[DeveloperMessage(content="newer")])
    older.save()
    newer.save()

    agent = Agent(session="latest", voice_enabled=False)

    assert agent.current_session_id == newer.session_id
    assert any(message.content == "newer" for message in agent.session.messages)


def test_agent_defaults_to_latest_session(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    older = AgentSession(session_id="20260101_100000", messages=[DeveloperMessage(content="older")])
    newer = AgentSession(session_id="20260102_100000", messages=[DeveloperMessage(content="newer")])
    older.save()
    newer.save()

    agent = Agent(voice_enabled=False)

    assert agent.current_session_id == newer.session_id
    assert any(message.content == "newer" for message in agent.session.messages)


def test_agent_get_response_emits_events_and_persists_assistant_message():
    agent = Agent(session="new", voice_enabled=False)
    agent.ai = FakeAI(agent)
    seen = []
    agent.on(ResponseContentDeltaEvent, lambda event: seen.append(event.delta))

    message = agent.get_response()

    assert message.content == "hi"
    assert seen == ["hi"]
    assert agent.session.messages[-1] is message
    assert json.loads(json.dumps(message))["type"] == "assistant_message"
    assert agent.ai.params["verbosity"] == agent.config.verbosity
    assert agent.ai.params["prompt_cache_key"] == agent.current_session_id
    assert any(tool["type"] == "custom" and tool["name"] == "python" for tool in agent.ai.params["tools"])
    assert any(tool["type"] == "custom" and tool["name"] == "bash" for tool in agent.ai.params["tools"])
    assert any(tool["type"] == "function" and tool["name"] == "read" for tool in agent.ai.params["tools"])
    assert any(tool["type"] == "function" and tool["name"] == "show" for tool in agent.ai.params["tools"])
    assert {"type": "web_search"} in agent.ai.params["tools"]
    assert {"type": "image_generation", "output_format": "png"} in agent.ai.params["tools"]


def test_agent_should_auto_compact_uses_ninety_percent_threshold(monkeypatch):
    agent = Agent(session="new", voice_enabled=False, input_token_limit=100)
    messages = [DeveloperMessage(content="context")]

    monkeypatch.setattr("codex_agent.agent.total_tokens", lambda _: 90)
    assert agent.should_auto_compact(messages) is False

    monkeypatch.setattr("codex_agent.agent.total_tokens", lambda _: 91)
    assert agent.should_auto_compact(messages) is True

    agent.config.auto_compact = False
    assert agent.should_auto_compact(messages) is False


def test_agent_get_response_auto_compacts_before_backend_call(monkeypatch):
    agent = Agent(session="new", voice_enabled=False)
    agent.ai = FakeAI(agent)
    calls = []

    def compact(session, **params):
        calls.append(params)
        message = CompactionMessage(output_items=[{"type": "compaction_summary", "id": "cs_123"}])
        session.messages.append(message)
        return message

    agent.should_auto_compact = lambda _messages: True
    monkeypatch.setattr(AgentSession, "compact", compact)

    agent.get_response()

    assert calls == [{
        "model": agent.config.model,
        "instructions": agent.get_system_message().content,
    }]
    assert any(isinstance(message, CompactionMessage) for message in agent.ai.params["messages"])


def test_agent_interrupt_emits_event_once():
    agent = Agent(session="new", voice_enabled=False)
    abortable = AbortableAI()
    agent.ai = abortable
    seen = []

    agent.on(AgentInterruptedEvent, lambda event: seen.append(event.reason))

    assert agent.interrupt("test") is True
    assert agent.interrupt("again") is True
    assert agent.is_interrupted() is True
    assert abortable.aborted is True
    assert seen == ["test"]

    agent.clear_interrupt()
    assert agent.is_interrupted() is False


def test_agent_process_stops_on_interruption():
    agent = Agent(session="new", voice_enabled=False)
    agent.ai = InterruptingAI(agent)
    before = len(agent.session.messages)

    assert agent.process() is False
    assert len(agent.session.messages) == before + 1
    assert agent.session.messages[-1].type == "developer_message"
    assert "interrupted by the user" in agent.session.messages[-1].content


def test_agent_combines_local_and_server_tools_for_response():
    agent = Agent(session="new", voice_enabled=False)
    agent.ai = FakeAI(agent)
    agent.add_server_tool(WebSearchTool())
    agent.add_server_tool(ImageGenerationTool())

    agent.get_response()

    tools = agent.ai.params["tools"]
    assert any(tool["type"] == "function" and tool["name"] == "read" for tool in tools)
    assert any(tool["type"] == "custom" and tool["name"] == "python" for tool in tools)
    assert any(tool["type"] == "custom" and tool["name"] == "bash" for tool in tools)
    assert any(tool["type"] == "function" and tool["name"] == "show" for tool in tools)
    assert any(tool["type"] == "function" and tool["name"] == "edit" for tool in tools)
    assert {"type": "web_search"} in tools
    assert {"type": "image_generation", "output_format": "png"} in tools


def test_builtin_read_tool_survives_get_text_submodule_shadowing():
    import codex_agent.get_text.get_text

    agent = Agent(session="new", voice_enabled=False)
    message = AssistantMessage()
    message.tool_calls = [{
        "type": "function_call",
        "call_id": "call_1",
        "name": "read",
        "arguments": '{"source": "codex_agent/builtin_tools.py"}',
    }]

    assert agent.call_tools(message) is True
    assert "success: call_id=call_1" in agent.session.messages[-1].content
    assert isinstance(agent.pending[-1], ToolResultWrapper)
    assert "'module' object is not callable" not in agent.pending[-1].content
    assert "def read(" in agent.pending[-1].content


def test_agent_applies_image_generation_tool_config():
    agent = Agent(
        session="new",
        voice_enabled=False,
        image_generation_size="1024x1024",
        image_generation_quality="low",
        image_generation_background="opaque",
        image_generation_moderation="low",
    )
    agent.ai = FakeAI(agent)

    agent.get_response()

    assert {
        "type": "image_generation",
        "output_format": "png",
        "size": "1024x1024",
        "quality": "low",
        "background": "opaque",
        "moderation": "low",
    } in agent.ai.params["tools"]


def test_agent_create_image_generates_without_touching_session(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", voice_enabled=False)
    agent.ai = FakeImageAI(agent)
    before = len(agent.session.messages)

    path = agent.create_image("draw a red square", size="1024x1024")

    assert path.startswith(str(tmp_path / "images"))
    assert len(agent.session.messages) == before
    assert agent.ai.params["messages"][0].type == "system_message"
    assert "specialized image creation assistant" in agent.ai.params["messages"][0].content
    assert agent.ai.params["messages"][-1].content == [{"type": "text", "text": "draw a red square"}]
    assert agent.ai.params["model"] == "gpt-5.4"
    assert agent.ai.params["reasoning_effort"] == "medium"
    assert agent.ai.params["verbosity"] == "medium"
    assert agent.ai.params["tools"] == [{
        "type": "image_generation",
        "output_format": "png",
        "size": "1024x1024",
    }]


def test_agent_create_image_accepts_input_images(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", voice_enabled=False)
    agent.ai = FakeImageAI(agent)
    source = b"source image bytes"

    path = agent.create_image("make a variation", input_images=[source])
    content = agent.ai.params["messages"][-1].content

    assert path.startswith(str(tmp_path / "images"))
    assert content[0] == {"type": "text", "text": "make a variation"}
    assert any(part.get("type") == "input_image" for part in content)


def test_agent_create_image_allows_llm_parameter_overrides(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", voice_enabled=False)
    agent.ai = FakeImageAI(agent)

    agent.create_image(
        "draw a red square",
        model="gpt-test",
        reasoning_effort="low",
        verbosity="high",
    )

    assert agent.ai.params["model"] == "gpt-test"
    assert agent.ai.params["reasoning_effort"] == "low"
    assert agent.ai.params["verbosity"] == "high"


def test_agent_create_image_uses_explicit_generation_parameters(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(
        session="new",
        voice_enabled=False,
        image_generation_size="should-not-leak",
        image_generation_quality="should-not-leak",
    )
    agent.ai = FakeImageAI(agent)

    agent.create_image(
        "draw a red square",
        output_format="png",
        size="1024x1024",
        quality="low",
        background="opaque",
        moderation="low",
    )

    assert agent.ai.params["tools"] == [{
        "type": "image_generation",
        "output_format": "png",
        "size": "1024x1024",
        "quality": "low",
        "background": "opaque",
        "moderation": "low",
    }]


def test_agent_emits_server_tool_call_event_from_output_items():
    agent = Agent(session="new", voice_enabled=False)
    item = {
        "type": "web_search_call",
        "id": "ws_123",
        "status": "completed",
    }
    agent.ai._codex_client = FakeCodexClient([OutputItem.from_dict(item)])
    seen = []

    agent.on(ServerToolCallEvent, lambda event: seen.append((event.name, event.call_id, event.status)))
    agent.ai.run(
        messages=[],
        tools=agent.get_response_tools(),
        **agent.config.extract("model", "reasoning_effort", "verbosity"),
    )

    assert seen == [("web_search", "ws_123", "completed")]
    assert agent.ai._codex_client.kwargs["prompt_cache_key"] is None


def test_agent_persists_server_tool_output_items_as_messages():
    agent = Agent(session="new", voice_enabled=False)
    item = {
        "type": "web_search_call",
        "id": "ws_123",
        "status": "completed",
    }
    agent.ai._codex_client = FakeCodexClient([OutputItem.from_dict(item)])

    message = agent.get_response()
    server_message = agent.session.messages[-1]

    assert message.output_items[0].type == "web_search_call"
    assert "output_items" not in message
    assert isinstance(server_message, ServerToolResponseMessage)
    assert server_message.item == item
    assert server_message.to_response_format() == item


def test_agent_persists_generated_images_as_observable_files(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", voice_enabled=False)
    item = {
        "type": "image_generation_call",
        "id": "ig_123",
        "result": "Zm9v",
    }
    agent.ai._codex_client = FakeCodexClient([OutputItem.from_dict(item)])

    message = agent.get_response()
    server_message = agent.session.messages[-1]
    assistant_payload = json.loads(json.dumps(message))
    payload = json.loads(json.dumps(server_message))

    assert "output_items" not in assistant_payload
    assert "Zm9v" not in json.dumps(assistant_payload)
    assert isinstance(server_message, ServerToolResponseMessage)
    assert server_message.item == {"type": "image_generation_call", "id": "ig_123"}
    assert server_message.content.startswith(str(tmp_path / "images"))
    assert "Zm9v" not in json.dumps(payload)
    assert server_message.as_image_message().content == server_message.content


def test_agent_creates_runtime_tools_folder(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))

    Agent(session="new", voice_enabled=False)

    assert (tmp_path / "tools").is_dir()
    assert (tmp_path / "providers").is_dir()


def test_agent_loads_decorated_runtime_tools(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    tools_dir = tmp_path / "tools"
    tools_dir.mkdir()
    (tools_dir / "custom_tools.py").write_text(
        """
from codex_agent import get_agent, tool

@tool
def shout(text: str):
    \"\"\"Uppercases text.\"\"\"
    return text.upper()

@tool(type="custom", description="Runs raw text.")
def raw(payload):
    return payload[::-1]

@tool
def current_agent_name():
    \"\"\"Returns the current agent name.\"\"\"
    return get_agent().config.name
""",
        encoding="utf-8",
    )

    agent = Agent(session="new", voice_enabled=False)

    assert set(["shout", "raw", "current_agent_name"]).issubset(agent.tools)
    assert agent.tools.shout.to_response_tool() == {
        "type": "function",
        "name": "shout",
        "description": "Uppercases text.",
        "parameters": {
            "type": "object",
            "properties": {"text": {"type": "string"}},
            "required": ["text"],
        },
    }
    assert agent.tools.raw.to_response_tool() == {
        "type": "custom",
        "name": "raw",
        "description": "Runs raw text.",
    }


def test_builtin_edit_tool_applies_single_exact_replacement(tmp_path):
    agent = Agent(session="new", voice_enabled=False)
    path = tmp_path / "note.txt"
    path.write_text("hello world\n", encoding="utf-8")

    result = agent.tools.edit({
        "file_path": str(path),
        "old_string": "hello",
        "new_string": "bonjour",
    })

    assert "1. success: replaced 1 match" in result
    assert path.read_text(encoding="utf-8") == "bonjour world\n"


def test_builtin_python_tool_runs_in_persistent_shell():
    agent = Agent(session="new", voice_enabled=False)
    message = AssistantMessage()
    message.tool_calls = [{
        "type": "custom_tool_call",
        "call_id": "call_1",
        "name": "python",
        "input": "x = 40\nx + 2",
    }]

    assert agent.call_tools(message) is True

    assert "success: call_id=call_1" in agent.session.messages[-1].content
    assert "result:\n42" in agent.pending[-1].content


def test_builtin_bash_tool_runs_shell_commands():
    agent = Agent(session="new", voice_enabled=False)

    result = agent.tools.bash("printf hello")

    assert result == "stdout:\nhello"


def test_builtin_bash_tool_reports_stderr_and_exit_code():
    agent = Agent(session="new", voice_enabled=False)

    result = agent.tools.bash("echo problem >&2; exit 7")

    assert "stderr:\nproblem\n" in result
    assert "exit_code: 7" in result


def test_builtin_write_tool_writes_complete_file(tmp_path):
    agent = Agent(session="new", voice_enabled=False)
    path = tmp_path / "notes" / "note.txt"

    result = agent.tools.write({"file_path": str(path), "content": "hello\nworld\n"})

    assert "1. success: wrote 12 characters" in result
    assert path.read_text(encoding="utf-8") == "hello\nworld\n"


def test_builtin_write_tool_overwrites_existing_file(tmp_path):
    agent = Agent(session="new", voice_enabled=False)
    path = tmp_path / "note.txt"
    path.write_text("old\ncontent\n", encoding="utf-8")

    result = agent.tools.write({"file_path": str(path), "content": "new\n"})

    assert "1. success: wrote 4 characters" in result
    assert path.read_text(encoding="utf-8") == "new\n"


def test_builtin_write_tool_writes_multiple_files(tmp_path):
    agent = Agent(session="new", voice_enabled=False)
    first = tmp_path / "one.txt"
    second = tmp_path / "nested" / "two.txt"

    result = agent.tools.write(writes=[
        {"file_path": str(first), "content": "one\n"},
        {"file_path": str(second), "content": "two\n"},
    ])

    assert "1. success: wrote 4 characters" in result
    assert "2. success: wrote 4 characters" in result
    assert first.read_text(encoding="utf-8") == "one\n"
    assert second.read_text(encoding="utf-8") == "two\n"


def test_builtin_write_tool_schema_is_structured_function_tool():
    agent = Agent(session="new", voice_enabled=False)

    assert agent.tools.write.to_response_tool() == {
        "type": "function",
        "name": "write",
        "description": "Write or overwrite one or more complete UTF-8 text files.\nUse this when creating new text files or replacing entire files is clearer than targeted edits.\nParent directories are created automatically.\nPass either a single write object or a list of write objects.\n",
        "parameters": {
            "type": "object",
            "properties": {
                "writes": {
                    "description": "A single write object or a list of write objects.\nEach object must contain file_path and content.\n",
                    "anyOf": [
                        {
                            "type": "object",
                            "properties": {
                                "file_path": {"type": "string"},
                                "content": {"type": "string"},
                            },
                            "required": ["file_path", "content"],
                        },
                        {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "file_path": {"type": "string"},
                                    "content": {"type": "string"},
                                },
                                "required": ["file_path", "content"],
                            },
                        },
                    ],
                },
            },
            "required": ["writes"],
        },
    }


def test_builtin_edit_tool_requires_single_match_unless_replace_all(tmp_path):
    agent = Agent(session="new", voice_enabled=False)
    path = tmp_path / "note.txt"
    path.write_text("x x x", encoding="utf-8")

    failed = agent.tools.edit({
        "file_path": str(path),
        "old_string": "x",
        "new_string": "y",
    })
    assert "failed: old_string matched 3 times" in failed
    assert path.read_text(encoding="utf-8") == "x x x"

    succeeded = agent.tools.edit({
        "file_path": str(path),
        "old_string": "x",
        "new_string": "y",
        "replace_all": True,
    })
    assert "success: replaced 3 matches" in succeeded
    assert path.read_text(encoding="utf-8") == "y y y"


def test_builtin_edit_tool_applies_multiple_edits_in_sequence(tmp_path):
    agent = Agent(session="new", voice_enabled=False)
    path = tmp_path / "note.txt"
    path.write_text("alpha beta gamma", encoding="utf-8")

    result = agent.tools.edit([
        {
            "file_path": str(path),
            "old_string": "alpha",
            "new_string": "one",
        },
        {
            "file_path": str(path),
            "old_string": "one beta",
            "new_string": "two",
        },
        {
            "file_path": str(path),
            "old_string": "missing",
            "new_string": "nope",
        },
    ])

    assert "1. success" in result
    assert "2. success" in result
    assert "3. failed: old_string not found" in result
    assert path.read_text(encoding="utf-8") == "two gamma"


def test_agent_add_image_rejects_invalid_image_without_polluting_session():
    agent = Agent(session="new", voice_enabled=False)
    initial_count = len(agent.session.messages)
    with pytest.raises(ValueError, match="Invalid or inaccessible image source"):
        agent.add_image("/tmp/definitely-missing-image.png")
    assert len(agent.session.messages) == initial_count

def test_agent_loads_decorated_runtime_providers(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    providers_dir = tmp_path / "providers"
    providers_dir.mkdir()
    (providers_dir / "context.py").write_text(
        """
from codex_agent import provider

@provider
def plain_context():
    return "plain provider context"

@provider(name="structured_context")
def structured():
    return "structured provider context"
""",
        encoding="utf-8",
    )

    agent = Agent(session="new", voice_enabled=False)
    messages = agent.get_providers_messages()

    assert set(["plain_context", "structured_context"]).issubset(agent.providers)
    contents = [message.content for message in messages]
    assert "plain provider context" in contents
    assert "structured provider context" in contents
    assert all(isinstance(message, ProviderMessage) for message in messages)


def test_tool_can_describe_freeform_custom_tool():
    def code_exec(source):
        """Executes Python source code."""
        return source

    tool = Tool(code_exec, type="custom")

    assert tool.to_response_tool() == {
        "type": "custom",
        "name": "code_exec",
        "description": "Executes Python source code.",
    }


def test_tool_parses_yaml_docstring():
    def lookup(query):
        """
        description: Finds a value.
        parameters:
          query:
            type: string
            description: Search query.
        required:
          - query
        """
        return query

    assert Tool(lookup).to_response_tool() == {
        "type": "function",
        "name": "lookup",
        "description": "Finds a value.",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search query.",
                },
            },
            "required": ["query"],
        },
    }


def test_tool_infers_parameters_from_signature_annotations():
    def search(query: str, limit: int = 5, exact: bool = False):
        """Searches things."""
        return query

    assert Tool(search).to_response_tool() == {
        "type": "function",
        "name": "search",
        "description": "Searches things.",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {"type": "string"},
                "limit": {"type": "integer", "default": 5},
                "exact": {"type": "boolean", "default": False},
            },
            "required": ["query"],
        },
    }


def test_tool_infers_literal_and_array_annotations():
    def filter_items(tags: list[str], mode: Literal["all", "any"] = "all"):
        return tags

    assert Tool(filter_items).to_response_tool()["parameters"] == {
        "type": "object",
        "properties": {
            "tags": {
                "type": "array",
                "items": {"type": "string"},
            },
            "mode": {
                "enum": ["all", "any"],
                "type": "string",
                "default": "all",
            },
        },
        "required": ["tags"],
    }


def test_tool_docstring_parameter_schema_overrides_inference():
    def lookup(query: str):
        """
        description: Finds a value.
        parameters:
          query:
            type: string
            description: Search query.
        """
        return query

    assert Tool(lookup).to_response_tool()["parameters"]["properties"]["query"] == {
        "type": "string",
        "description": "Search query.",
    }


def test_tool_can_describe_grammar_constrained_custom_tool():
    def math_exp(source):
        return source

    tool = Tool(
        math_exp,
        type="custom",
        description="Creates a math expression.",
        format={
            "type": "grammar",
            "syntax": "lark",
            "definition": "start: /[0-9]+/",
        },
    )

    assert tool.to_response_tool() == {
        "type": "custom",
        "name": "math_exp",
        "description": "Creates a math expression.",
        "format": {
            "type": "grammar",
            "syntax": "lark",
            "definition": "start: /[0-9]+/",
        },
    }


def test_agent_calls_custom_tool_with_raw_input():
    agent = Agent(session="new", voice_enabled=False, auto_proceed=False)
    seen = []

    @agent.add_tool(type="custom", description="Echoes raw text.")
    def echo_raw(text):
        seen.append(text)
        return text.upper()

    message = AssistantMessage()
    message.tool_calls = [{
        "type": "custom_tool_call",
        "call_id": "call_1",
        "name": "echo_raw",
        "input": "hello",
    }]

    assert agent.call_tools(message) is True
    assert seen == ["hello"]
    assert agent.session.messages[-1].to_response_format() == {
        "type": "custom_tool_call_output",
        "call_id": "call_1",
        "output": f"success: call_id=call_1; full output in ToolResultWrapper id={agent.pending[-1].id}.",
    }
    assert agent.pending[-1].content == "HELLO"


def test_agent_keeps_tool_outputs_contiguous_and_wrappers_pending():
    agent = Agent(session="new", voice_enabled=False, auto_proceed=False)

    @agent.add_tool
    def echo(value):
        return value

    message = AssistantMessage()
    message.tool_calls = [
        {
            "type": "function_call",
            "call_id": "call_1",
            "name": "echo",
            "arguments": '{"value": "one"}',
        },
        {
            "type": "function_call",
            "call_id": "call_2",
            "name": "echo",
            "arguments": '{"value": "two"}',
        },
    ]

    assert agent.call_tools(message) is True

    outputs = agent.session.messages[-2:]
    assert [output.call_id for output in outputs] == ["call_1", "call_2"]
    assert [output.type for output in outputs] == ["tool_result_message", "tool_result_message"]
    assert [wrapper.call_id for wrapper in agent.pending[-2:]] == ["call_1", "call_2"]
    assert [wrapper.content for wrapper in agent.pending[-2:]] == ["one", "two"]
    assert [wrapper.turns_left for wrapper in agent.pending[-2:]] == [3, 3]


def test_tool_can_access_current_agent_context():
    agent = Agent(session="new", voice_enabled=False, auto_proceed=False)

    @agent.add_tool
    def agent_name():
        """Gets the current agent name."""
        return get_agent().config.name

    message = AssistantMessage()
    message.tool_calls = [{
        "type": "function_call",
        "call_id": "call_1",
        "name": "agent_name",
        "arguments": "{}",
    }]

    assert agent.call_tools(message) is True
    assert "success: call_id=call_1" in agent.session.messages[-1].content
    assert agent.pending[-1].content == agent.config.name


def test_agent_can_enable_builtin_server_tools_from_config():
    agent = Agent(
        session="new",
        voice_enabled=False,
        web_search_enabled=True,
        image_generation_enabled=True,
    )

    assert set(agent.server_tools) == {"web_search", "image_generation"}


def test_codex_stream_params_forward_verbosity_and_prompt_cache_key():
    agent = Agent(session="new", voice_enabled=False, verbosity="low")

    params = agent.ai._to_codex_stream_params({
        "messages": agent.get_context(),
        "verbosity": agent.config.verbosity,
        "prompt_cache_key": agent.current_session_id,
    })

    assert params["verbosity"] == "low"
    assert params["prompt_cache_key"] == agent.current_session_id


def test_agent_provider_messages_are_ephemeral():
    agent = Agent(session="new", voice_enabled=False)
    initial_count = len(agent.session.messages)

    @agent.add_provider
    def context_provider():
        return "plain"

    messages = agent.get_providers_messages()

    assert "plain" in [message.content for message in messages]
    assert all(isinstance(message, ProviderMessage) for message in messages)
    assert len(agent.session.messages) == initial_count


def test_agent_add_command_decorator_handles_slash_command():
    agent = Agent(session="new", voice_enabled=False)
    initial_count = len(agent.session.messages)

    @agent.add_command
    def echo(args):
        return f"echo:{args}:{get_agent().config.name}"

    result = agent("/echo hello")

    assert result == f"echo:hello:{agent.config.name}"
    assert len(agent.session.messages) == initial_count


def test_agent_command_can_be_registered_without_args():
    agent = Agent(session="new", voice_enabled=False)

    @agent.add_command
    def ping():
        return "pong"

    assert agent("/ping") == "pong"


def test_agent_command_maps_parsed_arguments_to_signature():
    agent = Agent(session="new", voice_enabled=False)

    @agent.add_command
    def greet(name, greeting="hello", loud=False):
        text = f"{greeting}, {name}"
        return text.upper() if loud else text

    assert agent('/greet Ada greeting=salut --loud') == "SALUT, ADA"


def test_agent_command_supports_varargs_and_kwargs():
    agent = Agent(session="new", voice_enabled=False)

    @agent.add_command
    def collect(*items, **options):
        return f"items={list(items)!r}; options={options!r}"

    assert agent('/collect one "two words" mode=fast --dry-run') == (
        "items=['one', 'two words']; options={'mode': 'fast', 'dry_run': True}"
    )


def test_agent_loads_builtin_commands():
    agent = Agent(session="new", voice_enabled=False)

    assert {"help", "compact", "config", "model", "reasoning", "verbosity", "voice"}.issubset(agent.commands)
    assert "/help" in agent("/help")
    assert "/compact" in agent("/help")


def test_builtin_model_config_commands_update_and_persist(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", voice_enabled=False)

    assert agent("/model gpt-test") == "Updated config: model='gpt-test'"
    assert agent.config.model == "gpt-test"
    assert json.loads((tmp_path / "agent_config.json").read_text())["model"] == "gpt-test"

    assert agent("/reasoning low") == "Updated config: reasoning_effort='low'"
    assert agent("/verbosity high") == "Updated config: verbosity='high'"
    assert agent.config.reasoning_effort == "low"
    assert agent.config.verbosity == "high"


def test_builtin_voice_command_shows_toggles_and_selects_voice(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", voice_enabled=False, voice="nova")

    assert agent("/voice") == "voice: off; voice='nova'"
    assert agent("/voice on") == "Updated config: voice_enabled=True"
    assert agent.config.voice_enabled is True
    assert agent("/voice off") == "Updated config: voice_enabled=False"
    assert agent.config.voice_enabled is False
    assert agent("/voice shimmer") == "Updated config: voice='shimmer', voice_enabled=True"
    assert agent.config.voice == "shimmer"
    assert agent.config.voice_enabled is True

    saved = json.loads((tmp_path / "agent_config.json").read_text())
    assert saved["voice"] == "shimmer"
    assert saved["voice_enabled"] is True


def test_builtin_config_command_shows_and_updates_multiple_model_fields(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", voice_enabled=False)

    display = agent("/config")
    assert "model:" in display
    assert "reasoning_effort:" in display
    assert "verbosity:" in display

    result = agent("/config model=gpt-next input_token_limit=64000 auto_compact=false")

    assert "model='gpt-next'" in result
    assert "input_token_limit=64000" in result
    assert "auto_compact=False" in result
    assert agent.config.model == "gpt-next"
    assert agent.config.input_token_limit == 64000
    assert agent.config.auto_compact is False


def test_builtin_config_command_rejects_unknown_keys():
    agent = Agent(session="new", voice_enabled=False)

    try:
        agent("/config temperature=1")
    except ValueError as exc:
        assert "Unknown model config keys: temperature" in str(exc)
    else:
        raise AssertionError("Expected ValueError for unknown config key")


def test_builtin_session_commands_list_create_load_delete_and_navigate(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    first = AgentSession(session_id="20260101_100000", messages=[DeveloperMessage(content="first")])
    second = AgentSession(session_id="20260102_100000", messages=[DeveloperMessage(content="second")])
    first.save()
    second.save()

    agent = Agent(session="latest", voice_enabled=False)

    listing = agent("/sessions")
    assert "* 20260102_100000" in listing
    assert "  20260101_100000" in listing

    assert agent("/previous_session") == "Loaded session: 20260101_100000"
    assert agent.current_session_id == "20260101_100000"
    assert agent("/next_session") == "Loaded session: 20260102_100000"

    assert agent("/load_session 20260101_100000") == "Loaded session: 20260101_100000"
    assert agent.current_session_id == "20260101_100000"

    created = agent("/new_session")
    assert created.startswith("Created session: ")
    assert " " not in agent.current_session_id

    assert agent("/delete_session 20260101_100000") == "Deleted session: 20260101_100000"
    assert "20260101_100000" not in agent.get_sessions()


def test_agent_loads_runtime_commands(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    commands_folder = tmp_path / "commands"
    commands_folder.mkdir()
    (commands_folder / "hello.py").write_text(
        "from codex_agent import command\n"
        "from codex_agent import get_agent\n\n"
        "@command(name='hello')\n"
        "def hello(args):\n"
        "    return get_agent().config.name + ':' + args\n",
        encoding="utf-8",
    )

    agent = Agent(session="new", voice_enabled=False, name="Ada")

    assert agent("/hello world") == "Ada:world"


def test_unknown_command_raises_value_error():
    agent = Agent(session="new", voice_enabled=False)

    try:
        agent("/missing")
    except ValueError as exc:
        assert "Unknown command: /missing" in str(exc)
    else:
        raise AssertionError("Expected ValueError for unknown command")


def test_provider_message_wraps_content_for_api():
    message = ProviderMessage(name="clock", content="It is noon.")

    assert message.to_response_format() == {
        "type": "message",
        "role": "developer",
        "content": [{
            "type": "input_text",
            "text": '<context_provider name="clock">\nIt is noon.\n</context_provider>',
        }],
    }


def test_provider_must_return_string_or_none():
    agent = Agent(session="new", voice_enabled=False)

    @agent.add_provider
    def bad_provider():
        return {"not": "allowed"}

    try:
        agent.get_providers_messages()
    except TypeError as exc:
        assert "must return str or None" in str(exc)
    else:
        raise AssertionError("Expected provider contract TypeError")


def test_agent_loads_builtin_date_and_time_provider():
    agent = Agent(session="new", voice_enabled=False)

    assert "date_and_time" in agent.providers
    assert any(
        message.content.startswith("Current date and time:")
        for message in agent.get_providers_messages()
    )


def test_agent_loads_builtin_cwd_provider():
    agent = Agent(session="new", voice_enabled=False)

    assert "cwd" in agent.providers
    assert any(
        message.content.startswith("Current working directory:")
        for message in agent.get_providers_messages()
    )


def test_agent_config_exposes_stable_system_prompt_infos():
    agent = Agent(session="new", voice_enabled=False)

    assert agent.config.runtime_dir
    assert agent.config.source_dir.endswith("codex-agent")
    assert "Python" in agent.config.platform


def test_agent_config_helpers_persist_in_runtime_dir(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))

    agent = Agent(session="new", voice_enabled=False)
    agent.update_config(name="Ada", model="gpt-test")

    config_file = tmp_path / "agent_config.json"
    assert config_file.is_file()
    assert json.loads(config_file.read_text())["name"] == "Ada"

    loaded = Agent(session="new", voice_enabled=False)
    assert loaded.config.name == "Ada"
    assert loaded.config.model == "gpt-test"

    loaded.update_config({"name": "Pandora"}, save=False)
    assert json.loads(config_file.read_text())["name"] == "Ada"

    loaded.save_config()
    assert json.loads(config_file.read_text())["name"] == "Pandora"
