from codex_agent import Agent
from codex_agent.chat import Chat
from codex_agent.message import DeveloperMessage


def test_agent_context_status_is_lightweight_and_does_not_call_providers():
    agent = Agent(session="new", voice_enabled=False, input_token_limit=10_000)
    agent.session.messages.append(DeveloperMessage(content="hello context"))
    called = []

    @agent.add_provider
    def expensive_provider():
        called.append(True)
        return "expensive"

    status = agent.context_status()

    assert called == []
    assert status.used_tokens > 0
    assert status.input_token_limit == 10_000
    assert 0 <= status.percent <= 100
    assert status.total_session_messages == len(agent.session.messages)
    assert status.visible_history_messages <= status.total_history_messages
    assert status.memory_entries == len(agent.memory.messages)


def test_chat_status_bar_formats_context_summary():
    agent = Agent(session="new", voice_enabled=False, input_token_limit=10_000)
    status = agent.context_status()

    output = Chat.format_status(status).plain

    assert "ctx" in output
    assert "%" in output
    assert "tok" in output
    assert "hist" in output
    assert "msgs" in output
    assert "mem" in output
