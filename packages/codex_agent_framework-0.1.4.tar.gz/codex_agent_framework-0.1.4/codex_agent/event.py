from modict import modict
from .utils import snake_case_type, timestamp


class AgentInterrupted(Exception):
    """Raised internally when the current agent turn is interrupted."""


class Event(modict):
    """Base runtime event."""

    timestamp = modict.factory(lambda: timestamp())

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self['type'] = snake_case_type(type(self))


class AssistantTurnStartEvent(Event):
    message = None


class AssistantTurnEndEvent(Event):
    message = None


class AssistantStepStartEvent(Event):
    message = None


class AssistantStepEndEvent(Event):
    message = None
    called_tools = False


class ResponseStartEvent(Event):
    message = None


class ResponseContentDeltaEvent(Event):
    delta = ''
    content = ''
    chunk = None
    message = None


class ResponseReasoningDeltaEvent(Event):
    delta = ''
    reasoning = ''
    chunk = None
    message = None


class ResponseToolCallsDeltaEvent(Event):
    tool_calls = None
    chunk = None
    message = None


class ResponseOutputItemEvent(Event):
    item = None
    chunk = None
    message = None


class ResponseMessageDeltaEvent(Event):
    chunk = None
    message = None


class ResponseDoneEvent(Event):
    message = None


class MessageAddedEvent(Event):
    message = None


class ToolCallStartEvent(Event):
    tool_call = None
    tool = None


class ToolCallDoneEvent(Event):
    tool_call = None
    tool = None
    content = ''


class ServerToolCallEvent(Event):
    item = None
    tool = None
    name = ''
    call_id = ''
    status = ''


class AgentInterruptedEvent(Event):
    reason = ''


class AudioPlaybackEvent(Event):
    audio = None


class EventBus:
    """Small synchronous event bus with decorator registration."""

    def __init__(self):
        self.handlers = {}

    def event_type(self, event):
        if event == '*':
            return event
        if isinstance(event, type) and issubclass(event, Event):
            return snake_case_type(event)
        if isinstance(event, Event):
            return event.type
        raise TypeError(f"Expected Event subclass, Event instance, or '*', got {type(event).__name__}")

    def on(self, event, handler=None):
        event_type = self.event_type(event)
        if handler is None:
            def decorator(func):
                self.handlers.setdefault(event_type, []).append(func)
                return func
            return decorator

        self.handlers.setdefault(event_type, []).append(handler)
        return handler

    def off(self, event, handler):
        handlers = self.handlers.get(self.event_type(event))
        if handlers and handler in handlers:
            handlers.remove(handler)
        return handler

    def has_handlers(self, event):
        event_type = self.event_type(event)
        return bool(self.handlers.get(event_type) or self.handlers.get('*'))

    def emit(self, event, **data):
        if isinstance(event, type) and issubclass(event, Event):
            event = event(**data)
        elif not isinstance(event, Event):
            raise TypeError(f"Expected Event subclass or Event instance, got {type(event).__name__}")

        event_type = event.type
        for handler in self.handlers.get(event_type, ()):
            handler(event)
        for handler in self.handlers.get('*', ()):
            handler(event)
        return event
