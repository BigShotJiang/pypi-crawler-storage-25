from rich.text import Text

from .event import (
    AssistantStepEndEvent,
    AssistantStepStartEvent,
    AssistantTurnEndEvent,
    AssistantTurnStartEvent,
    ResponseContentDeltaEvent,
    ServerToolCallEvent,
    ToolCallStartEvent,
)

class Chat:
    """Textual-based chat UI styled as a quiet modern REPL."""

    CSS = """
    Screen {
        background: #171a1f;
        color: #c6c8c4;
    }

    #main {
        height: 100%;
        padding: 0 1;
        background: #171a1f;
    }

    #conversation {
        height: 1fr;
        padding: 1 1;
        background: #171a1f;
    }

    #status {
        height: 1;
        color: #7d8590;
        background: #171a1f;
    }

    #input {
        height: 5;
        margin-top: 0;
        padding: 0 1;
        background: #1f242c;
        color: #c6c8c4;
        border: blank #1f242c;
    }

    TextArea > .text-area--cursor {
        background: #6f98bd;
        color: #0d1117;
    }

    Footer {
        background: #171a1f;
        color: #7d8590;
    }
    """

    def __init__(self, agent):
        self.agent = agent
        self.app = None
        self._seen_tool_calls = set()
        self._agent_buffer = ""
        self._pending_tools = []
        self._transcript = []

    def attach(self):
        self.agent.on(AssistantTurnStartEvent, self._on_assistant_turn_start)
        self.agent.on(AssistantStepStartEvent, self._on_assistant_step_start)
        self.agent.on(AssistantStepEndEvent, self._on_assistant_step_end)
        self.agent.on(AssistantTurnEndEvent, self._on_assistant_turn_end)
        self.agent.on(ResponseContentDeltaEvent, self._on_content_delta)
        self.agent.on(ToolCallStartEvent, self._on_tool_call_start)
        self.agent.on(ServerToolCallEvent, self._on_server_tool_call)
        return self

    def run(self):
        from textual.app import App, ComposeResult
        from textual.containers import Vertical
        from textual.widgets import Footer, RichLog, Static, TextArea

        chat = self

        class AgentTextualApp(App):
            CSS = chat.CSS
            TITLE = "Codex Agent"
            BINDINGS = [
                ("ctrl+c", "interrupt", "Interrupt"),
                ("ctrl+l", "clear", "Clear"),
                ("ctrl+q", "quit", "Quit"),
                ("ctrl+s", "submit", "Submit"),
                ("alt+enter", "submit", "Submit"),
                ("ctrl+enter", "submit", "Submit"),
                ("f2", "submit", "Submit"),
            ]

            def compose(self) -> ComposeResult:
                with Vertical(id="main"):
                    yield RichLog(id="conversation", wrap=True, highlight=False, markup=True)
                    yield Static("", id="status")
                    yield TextArea(
                        "",
                        placeholder="› message  ·  Entrée = newline  ·  Ctrl+S/F2 = envoyer  ·  Ctrl+Q = quitter",
                        id="input",
                        show_line_numbers=False,
                        soft_wrap=True,
                    )
                yield Footer()

            def on_mount(self):
                chat.app = self
                chat.attach()
                self.refresh_status()
                self.query_one("#input", TextArea).focus()
                self.write_info("Codex Agent prêt.")

            def action_quit(self):
                self.exit()

            def action_submit(self):
                input_widget = self.query_one("#input", TextArea)
                prompt = input_widget.text
                input_widget.load_text("")
                command = prompt.strip().lower()
                if not command:
                    return
                if command in ["exit", "quit", "/exit", "/quit"]:
                    self.exit()
                    return
                if command == "/clear":
                    self.action_clear()
                    return

                self.write_user(prompt)
                self.refresh_status()
                self.run_worker(lambda: self._run_agent(prompt), thread=True)

            def _run_agent(self, prompt):
                try:
                    result = chat.agent(prompt)
                    if isinstance(result, str) and result:
                        self.call_from_thread(self.write_info, result)
                except Exception as exc:
                    self.call_from_thread(self.write_error, str(exc))
                finally:
                    self.call_from_thread(self.refresh_status)

            def action_clear(self):
                chat._transcript.clear()
                self.query_one("#conversation", RichLog).clear()
                self.write_info("écran nettoyé · historique conservé")
                self.refresh_status()

            def action_interrupt(self):
                chat.agent.interrupt("keyboard_interrupt")
                self.write_error("interruption demandée")

            def log_width(self):
                # Keep visual separators a few columns narrower than the RichLog
                # viewport: Textual reserves space for padding/scrollbar.
                raw_width = self.query_one("#conversation", RichLog).size.width or 80
                return max(32, raw_width - 6)

            def speaker_rule(self, name, style):
                width = self.log_width()
                label = f" {name} "
                available = max(2, width - len(label))
                left = available // 2
                right = available - left
                line = "─" * left + label + "─" * right
                return Text(line, style=style)

            def qed_marker(self, style="#6f98bd"):
                return Text(" " * max(0, self.log_width() - 1) + "▪", style=style)

            def render_transcript(self):
                log = self.query_one("#conversation", RichLog)
                log.clear()
                for entry in chat._transcript:
                    kind = entry[0]
                    if kind == "speaker":
                        _, name, style = entry
                        log.write(self.speaker_rule(name, style))
                        log.write("")
                    elif kind == "user":
                        log.write(Text(entry[1], style="#c6c8c4"))
                    elif kind == "agent":
                        log.write(Text(entry[1], style="#c6c8c4"))
                    elif kind == "tool":
                        _, name, call_id, status = entry
                        suffix = f" · {status}" if status else ""
                        call = f" · {call_id}" if call_id else ""
                        log.write(
                            Text("tool › ", style="bold #6f98bd")
                            + Text(name or "tool", style="#c6c8c4")
                            + Text(f"{call}{suffix}", style="#7d8590")
                        )
                    elif kind == "step_end":
                        log.write(self.qed_marker())
                    elif kind == "user_end":
                        log.write(self.qed_marker("#88b38a"))
                    elif kind == "info":
                        log.write(Text("info › ", style="bold #7d8590") + Text(str(entry[1]), style="#8b949e"))
                    elif kind == "error":
                        log.write(Text("error › ", style="bold #ff7b72") + Text(str(entry[1]), style="#ff7b72"))

            def write_user(self, prompt):
                username = chat.agent.config.get("username") or "Vous"
                chat._transcript.append(("speaker", username, "#88b38a"))
                chat._transcript.append(("user", prompt))
                chat._transcript.append(("user_end",))
                self.render_transcript()

            def write_agent_start(self, name):
                chat._agent_buffer = ""
                chat._pending_tools.clear()
                chat._seen_tool_calls.clear()
                agent_name = name or chat.agent.config.get("name") or "Pandora"
                chat._transcript.append(("speaker", agent_name, "#789fbe"))
                self.render_transcript()

            def start_agent_step(self):
                self.render_transcript()

            def write_agent_delta(self, delta):
                chat._agent_buffer += delta
                if chat._transcript and chat._transcript[-1][0] == "agent":
                    chat._transcript[-1] = ("agent", chat._agent_buffer)
                else:
                    chat._transcript.append(("agent", chat._agent_buffer))
                self.render_transcript()

            def write_tool(self, name, call_id=None, status=None):
                chat._pending_tools.append(("tool", name, call_id, status))

            def end_agent_step(self):
                had_content = bool(chat._agent_buffer or chat._pending_tools)
                if chat._transcript and chat._transcript[-1][0] == "agent":
                    if chat._agent_buffer:
                        chat._transcript[-1] = ("agent", chat._agent_buffer)
                    else:
                        chat._transcript.pop()
                if chat._pending_tools:
                    chat._transcript.extend(chat._pending_tools)
                    chat._pending_tools.clear()
                if had_content and (not chat._transcript or chat._transcript[-1][0] != "step_end"):
                    chat._transcript.append(("step_end",))
                self.render_transcript()

            def write_info(self, text):
                chat._transcript.append(("info", str(text)))
                self.render_transcript()

            def write_error(self, text):
                chat._transcript.append(("error", str(text)))
                self.render_transcript()

            def refresh_status(self):
                try:
                    status = chat.agent.context_status()
                    text = chat.format_status(status).plain
                except Exception as exc:
                    text = f"status unavailable: {exc}"
                self.query_one("#status", Static).update(text)

        AgentTextualApp().run()


    @classmethod
    def format_status(cls, status):
        percent = status.percent
        style = "green"
        if percent >= 90:
            style = "bold red"
        elif percent >= 75:
            style = "yellow"
        elif percent >= 50:
            style = "cyan"

        used = cls._format_int(status.used_tokens)
        limit = cls._format_int(status.input_token_limit)
        session = str(status.session_id or "-")[-15:]
        compact_hint = " auto-compact:on" if status.auto_compact else " auto-compact:off"
        if status.auto_compact and status.used_tokens >= status.auto_compact_threshold:
            compact_hint = " auto-compact:due"

        return Text.assemble(
            ("ctx ", "dim"),
            (f"{percent:.1f}%", style),
            (f" {used}/{limit} tok", "dim"),
            (f" · hist {status.visible_history_messages}/{status.total_history_messages}", "dim"),
            (f" · msgs {status.total_session_messages}", "dim"),
            (f" · img {status.image_messages}", "dim"),
            (f" · mem {status.memory_entries}", "dim"),
            (f" · pending {status.pending_messages}", "dim"),
            (f" · {session}", "dim"),
            (compact_hint, "dim"),
        )

    @staticmethod
    def _format_int(value):
        try:
            return f"{int(value):,}".replace(",", " ")
        except Exception:
            return str(value)

    def _call_app(self, method, *args):
        if self.app is None:
            return
        callback = getattr(self.app, method)
        try:
            self.app.call_from_thread(callback, *args)
        except RuntimeError:
            callback(*args)

    def _on_assistant_turn_start(self, event):
        name = self.agent.config.get("name") or "Pandora"
        self._call_app("write_agent_start", name)

    def _on_assistant_step_start(self, event):
        self._agent_buffer = ""
        self._call_app("start_agent_step")

    def _on_assistant_step_end(self, event):
        self._call_app("end_agent_step")
        self._call_app("refresh_status")

    def _on_assistant_turn_end(self, event):
        self._call_app("refresh_status")

    def _on_content_delta(self, event):
        self._call_app("write_agent_delta", event.delta)

    def _on_tool_call_start(self, event):
        tool_call = event.get("tool_call") or {}
        name = tool_call.get("name") or "unknown"
        call_id = tool_call.get("call_id") or name
        self._print_tool_call(name, call_id)

    def _on_server_tool_call(self, event):
        name = event.get("name") or "unknown"
        call_id = event.get("call_id") or name
        status = event.get("status") or ""
        self._print_tool_call(name, call_id, status=status)

    def _print_tool_call(self, name, call_id, status=None):
        if call_id in self._seen_tool_calls:
            return
        self._seen_tool_calls.add(call_id)
        self._call_app("write_tool", name, call_id, status)

    def _on_response_done(self, event):
        # Tool call lines are flushed at assistant-turn end, not after each
        # backend response, to keep agentic loops visually contiguous.
        pass
