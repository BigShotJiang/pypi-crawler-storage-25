"""Provider-agnostic LLM adapter.

The :class:`LLMClient` Protocol is the contract surface; the rest of the
agent code depends only on it. :class:`MockLLMClient` is a deterministic
recorder/replay client used in tests and the notebook by default.
:class:`AnthropicClient` (in ``anthropic.py``) is the v0.1 concrete impl
and requires the optional ``[llm]`` extra.
"""

from typing import TYPE_CHECKING

from .base import LLMClient, LLMResponse, Message
from .mock import MockLLMClient

if TYPE_CHECKING:
    # Imported eagerly at type-check time so ty sees AnthropicClient's real
    # type. At runtime the import stays lazy via __getattr__ so importing
    # ml4t.agent.llm doesn't require the optional [llm] extra.
    from .anthropic import AnthropicClient as AnthropicClient

__all__ = [
    "Message",
    "LLMClient",
    "LLMResponse",
    "MockLLMClient",
    "AnthropicClient",
]


def __getattr__(name: str) -> object:
    if name == "AnthropicClient":
        from .anthropic import AnthropicClient

        return AnthropicClient
    raise AttributeError(f"module 'ml4t.agent.llm' has no attribute {name!r}")
