# llm/ — Provider-agnostic LLM adapter

Provider-neutral Protocol with a deterministic mock client for CI and an
opt-in Anthropic implementation behind the `[llm]` extra. New provider
clients (OpenAI, Bedrock, Vertex) land in v0.3 — the Protocol is the
stable contract.

## Files

| File | Lines | Purpose |
|------|-------|---------|
| `base.py` | 66 | `LLMClient` Protocol, `Message`, `LLMResponse` — the surface every provider implements |
| `mock.py` | 135 | `MockLLMClient` (record/replay), `compute_cache_key`, `save_recording`, `load_recording` |
| `anthropic.py` | 147 | `AnthropicClient` — lazy import (raises a clear error if `[llm]` extra is missing); prompt-caching enabled |

## Protocol

Every client has one method: `complete_with_schema(messages, json_schema,
*, max_tokens, temperature) -> LLMResponse`. `temperature` is `float | None`;
`None` maps to the provider's "not given" sentinel. Extended-thinking
models (Opus 4.7) reject `temperature`; pass `None` for those.

## Mock client

`MockLLMClient` is deterministic by hash of input. Recordings serialise
to JSON via `save_recording` / `load_recording` and are how the chapter
notebook stays reproducible in CI without an API key.

## Anthropic client

Default model is `claude-opus-4-7`. Prompt caching is enabled via
`anthropic.types.CacheControl(type="ephemeral")` on the system message
and tool schema. Cost of one `propose_experiments` call: ~$0.04 at Opus,
~$0.008 at Sonnet 4.6 (with caching warm).
