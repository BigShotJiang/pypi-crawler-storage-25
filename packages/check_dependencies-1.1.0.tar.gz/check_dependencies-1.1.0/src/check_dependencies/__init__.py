"""Check dependencies tool."""
