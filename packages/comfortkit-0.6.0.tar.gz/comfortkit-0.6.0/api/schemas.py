"""Pydantic v2 request/response schemas for the REST API.

Kept separate from comfortkit.models so the API layer can evolve its
wire format independently of the core data model.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class PredictRequest(BaseModel):
    """Request body for POST /v1/predict."""

    ta: float = Field(..., description="Air temperature (°C)")
    tr: float = Field(..., description="Mean radiant temperature (°C)")
    vel: float = Field(..., ge=0, description="Air velocity (m/s)")
    rh: float = Field(..., ge=0, le=100, description="Relative humidity (%)")
    met: float = Field(..., gt=0, description="Metabolic rate (met)")
    clo: float = Field(..., ge=0, description="Clothing insulation (clo)")
    standard: Literal["ashrae", "iso"] = "ashrae"
    include_ci: bool = Field(False, description="Include 95 % bootstrap CI on PMV")


class PredictResponse(BaseModel):
    """Response body for POST /v1/predict."""

    pmv: float | None
    ppd: float | None
    sensation: str
    compliant: bool
    model: str
    ci_95: tuple[float, float] | None = None
    warnings: list[str] = Field(default_factory=list)


class BatchPredictRequest(BaseModel):
    """Request body for POST /v1/predict/batch."""

    inputs: list[PredictRequest] = Field(..., min_length=1)


class BatchPredictResponse(BaseModel):
    """Response body for POST /v1/predict/batch."""

    results: list[PredictResponse]


class ModelInfo(BaseModel):
    """Single model descriptor for GET /v1/models."""

    id: str
    description: str


class ListModelsResponse(BaseModel):
    """Response body for GET /v1/models."""

    models: list[ModelInfo]


# ---------------------------------------------------------------------------
# Personalised comfort — v0.3
# ---------------------------------------------------------------------------


class FeedbackRequest(BaseModel):
    """Request body for POST /v1/feedback."""

    user_id: str = Field(..., description="Opaque user identifier")
    vote: int = Field(
        ...,
        ge=-1,
        le=1,
        description=(
            " 1 = Warm preference (feels warm, wants it cooler). "
            " 0 = Neutral / No change (comfortable). "
            "-1 = Cool preference (feels cool, wants it warmer). "
            "Deprecated binary interface: 1 (Cooler) and 0 (Not Cooler) "
            "are still accepted and map to Warm and Neutral respectively."
        ),
    )
    heart_rate: float | None = Field(None, description="Heart rate at time of vote (bpm)")
    t_net: float | None = Field(None, description="Indoor air temperature — Netatmo (°C)")
    rh_net: float | None = Field(None, description="Indoor relative humidity — Netatmo (%)")
    clothing: str | None = Field(None, description="Clothing level (e.g. 'Light', 'Medium')")
    met: str | None = Field(None, description="Activity level (e.g. 'sitting', 'standing')")
    gender: Literal["M", "F"] | None = Field(
        None,
        description=(
            "Biological sex (M or F). Used only on the first vote to select the "
            "demographic warm-start prior; ignored for returning users. Optional — "
            "omit to use the gender-neutral ASHRAE cooling-season baseline."
        ),
    )
    hvac_mode: Literal["cooling", "heating", "neutral"] | None = Field(
        None,
        description=(
            "Current HVAC operating mode. Conditions the warm-start prior for new "
            "users: female + cooling activates the overcooling-corrected prior. "
            "Ignored for returning users. Omit if unknown."
        ),
    )


class FeedbackResponse(BaseModel):
    """Response body for POST /v1/feedback."""

    user_id: str
    n_votes: int
    p_warm: float
    p_neutral: float
    p_cool: float
    p_cooler: float = Field(..., description="Alias for p_warm — retained for v0.3 compatibility")
    prediction: int = Field(..., description="MAP class: 1=Warm, 0=Neutral, -1=Cool")
    prediction_label: str = Field(..., description="'Warm', 'Neutral', or 'Cool'")


class PersonalComfortResponse(BaseModel):
    """Response body for GET /v1/comfort/{user_id}."""

    user_id: str
    p_warm: float
    p_neutral: float
    p_cool: float
    p_cooler: float = Field(..., description="Alias for p_warm — retained for v0.3 compatibility")
    prediction: int = Field(..., description="MAP class: 1=Warm, 0=Neutral, -1=Cool")
    prediction_label: str = Field(..., description="'Warm', 'Neutral', or 'Cool'")
    n_votes: int
    confidence: Literal["prior", "low", "medium", "high"]


# ---------------------------------------------------------------------------
# Zone aggregation — v0.4
# ---------------------------------------------------------------------------


class ZoneUserSummaryResponse(BaseModel):
    """Per-user breakdown within a zone prediction response."""

    p_warm: float
    p_cool: float
    prediction_label: str
    n_votes: int


class ZonePredictRequest(BaseModel):
    """Request body for POST /v1/zone/predict."""

    user_ids: list[str] = Field(..., min_length=1, description="IDs of occupants currently present in the zone")
    strategy: Literal["mean_p_warm", "majority_vote", "any_discomfort"] = Field(
        "mean_p_warm",
        description=(
            "mean_p_warm: act when average P(Warm) crosses a threshold; "
            "majority_vote: tally MAP labels; "
            "any_discomfort: flag if any user P(Warm) > 0.7"
        ),
    )
    zone_temp: float | None = Field(None, description="Current zone air temperature (°C) — stored for traceability")
    space_id: str | None = Field(None, description="Optional space identifier for logging")


class ZonePredictResponse(BaseModel):
    """Response body for POST /v1/zone/predict."""

    action: Literal["lower_setpoint", "raise_setpoint", "maintain"]
    strategy: str
    mean_p_warm: float
    mean_p_cool: float
    fraction_warm: float
    n_users: int
    per_user: dict[str, ZoneUserSummaryResponse]
    confidence: Literal["low", "medium", "high"]
    warnings: list[str] = Field(default_factory=list)
