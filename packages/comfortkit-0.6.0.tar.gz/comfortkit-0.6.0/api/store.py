"""UserStore interface and SQLite implementation for per-user posteriors.

The storage layer is intentionally thin and abstracted behind UserStore so that
swapping to Postgres (or Redis) for production does not touch the model or API
logic — only this file changes.

Schema migration
----------------
v0.5 changed the user_posteriors table from two columns (alpha_cooler,
alpha_not_cooler) to three (alpha_warm, alpha_neutral, alpha_cool).
_init_db() detects the old schema and migrates automatically on first use.
"""

from __future__ import annotations

import os
import pathlib
import sqlite3
from abc import ABC, abstractmethod
from datetime import datetime, timezone

from comfortkit.models.personal import PersonalPosterior

# Default DB path — override via COMFORTKIT_DB environment variable.
_DEFAULT_DB = pathlib.Path(
    os.getenv(
        "COMFORTKIT_DB",
        str(pathlib.Path(__file__).parent / "comfortkit_personal.db"),
    )
)

# Forgetting half-life in days (0 = disabled). Override via COMFORTKIT_HALF_LIFE_DAYS.
_DEFAULT_HALF_LIFE: float = float(os.getenv("COMFORTKIT_HALF_LIFE_DAYS", "180"))


class UserStore(ABC):
    """Abstract storage contract for per-user personalised comfort posteriors."""

    @abstractmethod
    def get_posterior(
        self,
        user_id: str,
        gender: str | None = None,
        hvac_mode: str | None = None,
    ) -> PersonalPosterior:
        """Return the current posterior for *user_id*.

        Creates a fresh prior-initialised posterior when the user is unknown.
        *gender* and *hvac_mode* are used only for new users to select the
        appropriate warm-start prior; they are ignored for existing users
        whose demographic group is already stored.
        """

    @abstractmethod
    def save_posterior(self, user_id: str, posterior: PersonalPosterior) -> None:
        """Persist the updated posterior for *user_id*."""

    @abstractmethod
    def log_vote(
        self,
        user_id: str,
        vote: int,
        heart_rate: float | None,
        t_net: float | None,
        rh_net: float | None,
        clothing: str | None,
        met: str | None,
    ) -> None:
        """Append a vote + contextual features to the audit log."""


class SQLiteUserStore(UserStore):
    """SQLite-backed UserStore.  Single-file, zero infrastructure.

    Each public method opens and closes its own connection so that multiple
    threads (FastAPI's default thread pool) can call safely.  SQLite WAL mode
    is enabled for better concurrent read performance.

    Replace with a Postgres implementation for production deployments.
    """

    def __init__(
        self,
        db_path: pathlib.Path | str = _DEFAULT_DB,
        half_life_days: float = _DEFAULT_HALF_LIFE,
    ) -> None:
        self._db = str(db_path)
        self._half_life_days = half_life_days
        self._init_db()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self._db, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        return conn

    def _init_db(self) -> None:
        with self._conn() as conn:
            # Check existing schema to handle v0.3 -> v0.5 migration
            existing_cols = {
                r[1] for r in conn.execute("PRAGMA table_info(user_posteriors)")
            }
            if existing_cols and "alpha_warm" not in existing_cols:
                # Migrate from v0.3 binary schema (alpha_cooler, alpha_not_cooler)
                conn.execute(
                    "ALTER TABLE user_posteriors RENAME COLUMN alpha_cooler TO alpha_warm"
                )
                conn.execute(
                    "ALTER TABLE user_posteriors RENAME COLUMN alpha_not_cooler TO alpha_neutral"
                )
                conn.execute(
                    "ALTER TABLE user_posteriors ADD COLUMN alpha_cool REAL NOT NULL DEFAULT 0"
                )
            if existing_cols and "demographic_group" not in existing_cols:
                conn.execute(
                    "ALTER TABLE user_posteriors "
                    "ADD COLUMN demographic_group TEXT NOT NULL DEFAULT 'default'"
                )
            elif not existing_cols:
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS user_posteriors (
                        user_id           TEXT    PRIMARY KEY,
                        alpha_warm        REAL    NOT NULL,
                        alpha_neutral     REAL    NOT NULL,
                        alpha_cool        REAL    NOT NULL DEFAULT 0,
                        n_votes           INTEGER NOT NULL DEFAULT 0,
                        updated_at        TEXT    NOT NULL,
                        demographic_group TEXT    NOT NULL DEFAULT 'default'
                    )
                """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS vote_log (
                    id           INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id      TEXT    NOT NULL,
                    vote         INTEGER NOT NULL,
                    heart_rate   REAL,
                    t_net        REAL,
                    rh_net       REAL,
                    clothing     TEXT,
                    met          TEXT,
                    created_at   TEXT    NOT NULL
                )
            """)

    # ------------------------------------------------------------------
    # UserStore implementation
    # ------------------------------------------------------------------

    def get_posterior(
        self,
        user_id: str,
        gender: str | None = None,
        hvac_mode: str | None = None,
        _now: datetime | None = None,
    ) -> PersonalPosterior:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT alpha_warm, alpha_neutral, alpha_cool, n_votes, "
                "updated_at, demographic_group "
                "FROM user_posteriors WHERE user_id = ?",
                (user_id,),
            ).fetchone()
        if row is None:
            return PersonalPosterior.from_prior(gender=gender, hvac_mode=hvac_mode)
        posterior = PersonalPosterior(
            alpha_warm=row["alpha_warm"],
            alpha_neutral=row["alpha_neutral"],
            alpha_cool=row["alpha_cool"],
            n_votes=row["n_votes"],
            demographic_group=row["demographic_group"] or "default",
        )
        if self._half_life_days > 0 and row["updated_at"]:
            now = _now if _now is not None else datetime.now(timezone.utc)
            updated_at = datetime.fromisoformat(row["updated_at"])
            days_elapsed = (now - updated_at).total_seconds() / 86400
            posterior.decay(days_elapsed, self._half_life_days)
        return posterior

    def save_posterior(self, user_id: str, posterior: PersonalPosterior) -> None:
        now = datetime.now(timezone.utc).isoformat()
        with self._conn() as conn:
            conn.execute(
                """
                INSERT INTO user_posteriors
                    (user_id, alpha_warm, alpha_neutral, alpha_cool, n_votes,
                     updated_at, demographic_group)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(user_id) DO UPDATE SET
                    alpha_warm    = excluded.alpha_warm,
                    alpha_neutral = excluded.alpha_neutral,
                    alpha_cool    = excluded.alpha_cool,
                    n_votes       = excluded.n_votes,
                    updated_at    = excluded.updated_at
                """,
                (
                    user_id,
                    posterior.alpha_warm,
                    posterior.alpha_neutral,
                    posterior.alpha_cool,
                    posterior.n_votes,
                    now,
                    posterior.demographic_group,
                ),
            )

    def log_vote(
        self,
        user_id: str,
        vote: int,
        heart_rate: float | None,
        t_net: float | None,
        rh_net: float | None,
        clothing: str | None,
        met: str | None,
    ) -> None:
        now = datetime.now(timezone.utc).isoformat()
        with self._conn() as conn:
            conn.execute(
                """
                INSERT INTO vote_log
                    (user_id, vote, heart_rate, t_net, rh_net, clothing, met, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (user_id, vote, heart_rate, t_net, rh_net, clothing, met, now),
            )
