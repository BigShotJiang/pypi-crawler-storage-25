"""FastAPI application factory."""

from __future__ import annotations

from fastapi import FastAPI

from api.routers.feedback import router as feedback_router
from api.routers.predict import router as predict_router
from api.routers.zone import router as zone_router


def create_app() -> FastAPI:
    """Create and configure the FastAPI application."""
    app = FastAPI(
        title="comfortkit",
        description="Thermal comfort prediction API — PMV, adaptive ASHRAE 55, SET — with uncertainty bounds, personalised comfort, and zone aggregation.",
        version="0.5.1",
        docs_url="/docs",
        redoc_url="/redoc",
    )
    app.include_router(predict_router)
    app.include_router(feedback_router)
    app.include_router(zone_router)
    return app


app = create_app()
