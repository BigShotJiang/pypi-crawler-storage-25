"""POST /v1/zone/predict — zone-level comfort aggregation."""

from __future__ import annotations

from fastapi import APIRouter, Depends

from api.routers.feedback import get_store
from api.schemas import ZonePredictRequest, ZonePredictResponse, ZoneUserSummaryResponse
from api.store import UserStore
from comfortkit.models.zone import ZoneAggregator

router = APIRouter(prefix="/v1/zone", tags=["zone-comfort"])


@router.post("/predict", response_model=ZonePredictResponse)
def predict_zone(
    req: ZonePredictRequest,
    store: UserStore = Depends(get_store),
) -> ZonePredictResponse:
    """Predict a zone-level HVAC action from co-present occupants' comfort posteriors.

    Looks up the personal posterior for each user_id in the request, then
    applies the requested aggregation strategy.  Users not yet in the store
    return the global aggregate prior (confidence reflects this via low/medium/high).
    """
    posteriors = {uid: store.get_posterior(uid) for uid in req.user_ids}
    aggregator = ZoneAggregator(strategy=req.strategy)
    result = aggregator.predict(posteriors, zone_temp=req.zone_temp)

    return ZonePredictResponse(
        action=result.action,
        strategy=result.strategy,
        mean_p_warm=result.mean_p_warm,
        mean_p_cool=result.mean_p_cool,
        fraction_warm=result.fraction_warm,
        n_users=result.n_users,
        per_user={
            uid: ZoneUserSummaryResponse(
                p_warm=s.p_warm,
                p_cool=s.p_cool,
                prediction_label=s.prediction_label,
                n_votes=s.n_votes,
            )
            for uid, s in result.per_user.items()
        },
        confidence=result.confidence,
        warnings=result.warnings,
    )
