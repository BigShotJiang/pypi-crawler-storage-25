"""POST /v1/feedback  and  GET /v1/comfort/{user_id}."""

from __future__ import annotations

import os
import pathlib

from fastapi import APIRouter, Depends

from api.schemas import FeedbackRequest, FeedbackResponse, PersonalComfortResponse
from api.store import SQLiteUserStore, UserStore

router = APIRouter(prefix="/v1", tags=["personal-comfort"])

_DEFAULT_DB = pathlib.Path(
    os.getenv(
        "COMFORTKIT_DB",
        str(pathlib.Path(__file__).parent.parent / "comfortkit_personal.db"),
    )
)

_LABEL = {1: "Warm", 0: "Neutral", -1: "Cool"}


def get_store() -> UserStore:
    """FastAPI dependency — returns a UserStore backed by the configured DB path."""
    return SQLiteUserStore(_DEFAULT_DB)


def _confidence(n_votes: int) -> str:
    if n_votes == 0:
        return "prior"
    if n_votes < 20:
        return "low"
    if n_votes < 100:
        return "medium"
    return "high"


@router.post("/feedback", response_model=FeedbackResponse)
def submit_feedback(
    req: FeedbackRequest,
    store: UserStore = Depends(get_store),
) -> FeedbackResponse:
    """Accept an occupant thermal preference vote and update the per-user posterior.

    The vote updates a Dirichlet-Multinomial (K=3) posterior warm-started from
    the aggregate dorn study prior.  Accepts the three-class interface
    (-1=Cool, 0=Neutral, 1=Warm) as well as the legacy binary interface
    (0=Not Cooler, 1=Cooler) for backwards compatibility.
    """
    posterior = store.get_posterior(
        req.user_id, gender=req.gender, hvac_mode=req.hvac_mode
    )
    posterior.update(req.vote)
    store.save_posterior(req.user_id, posterior)
    store.log_vote(
        req.user_id,
        req.vote,
        req.heart_rate,
        req.t_net,
        req.rh_net,
        req.clothing,
        req.met,
    )
    pred = posterior.predict()
    return FeedbackResponse(
        user_id=req.user_id,
        n_votes=posterior.n_votes,
        p_warm=round(posterior.p_warm, 4),
        p_neutral=round(posterior.p_neutral, 4),
        p_cool=round(posterior.p_cool, 4),
        p_cooler=round(posterior.p_warm, 4),
        prediction=pred,
        prediction_label=_LABEL[pred],
    )


@router.get("/comfort/{user_id}", response_model=PersonalComfortResponse)
def get_comfort(
    user_id: str,
    store: UserStore = Depends(get_store),
) -> PersonalComfortResponse:
    """Return the personalised comfort prediction for a user.

    A new user returns the aggregate prior (confidence="prior").  Confidence
    increases with vote count: low (<20), medium (<100), high (>=100).
    """
    posterior = store.get_posterior(user_id)
    pred = posterior.predict()
    return PersonalComfortResponse(
        user_id=user_id,
        p_warm=round(posterior.p_warm, 4),
        p_neutral=round(posterior.p_neutral, 4),
        p_cool=round(posterior.p_cool, 4),
        p_cooler=round(posterior.p_warm, 4),
        prediction=pred,
        prediction_label=_LABEL[pred],
        n_votes=posterior.n_votes,
        confidence=_confidence(posterior.n_votes),
    )
