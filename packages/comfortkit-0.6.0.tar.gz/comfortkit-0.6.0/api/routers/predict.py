"""POST /v1/predict, POST /v1/predict/batch, GET /v1/models."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException

import comfortkit
from api.schemas import (
    BatchPredictRequest,
    BatchPredictResponse,
    ListModelsResponse,
    ModelInfo,
    PredictRequest,
    PredictResponse,
)
from comfortkit.models.base import ComfortInputError, ComfortInputs

router = APIRouter(prefix="/v1")


def _request_to_inputs(req: PredictRequest) -> ComfortInputs:
    return ComfortInputs(
        ta=req.ta,
        tr=req.tr,
        vel=req.vel,
        rh=req.rh,
        met=req.met,
        clo=req.clo,
        standard=req.standard,
    )


def _result_to_response(result: comfortkit.ComfortResult) -> PredictResponse:
    return PredictResponse(
        pmv=result.pmv,
        ppd=result.ppd,
        sensation=result.sensation,
        compliant=result.compliant,
        model=result.model,
        ci_95=result.ci_95,
        warnings=result.warnings,
    )


@router.post("/predict", response_model=PredictResponse)
def predict(req: PredictRequest) -> PredictResponse:
    """Return a thermal comfort prediction for a single set of inputs."""
    try:
        inputs = _request_to_inputs(req)
        result = comfortkit.predict(inputs)
    except ComfortInputError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return _result_to_response(result)


@router.post("/predict/batch", response_model=BatchPredictResponse)
def predict_batch(req: BatchPredictRequest) -> BatchPredictResponse:
    """Return thermal comfort predictions for a list of inputs."""
    try:
        inputs = [_request_to_inputs(r) for r in req.inputs]
        results = comfortkit.predict_batch(inputs)
    except ComfortInputError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return BatchPredictResponse(results=[_result_to_response(r) for r in results])


@router.get("/models", response_model=ListModelsResponse)
def list_models() -> ListModelsResponse:
    """List available thermal comfort models."""
    return ListModelsResponse(
        models=[ModelInfo(id=name, description=name) for name in comfortkit.list_models()]
    )
