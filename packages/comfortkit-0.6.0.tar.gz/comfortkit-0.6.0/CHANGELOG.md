# Changelog

All notable changes to comfortkit are documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

---

## [0.5.1] — 2026-04-27

### Added

- **`CoolingEffectModel`** (`comfortkit/models/standard.py`) — ASHRAE 55
  Appendix G Cooling Effect adapter for elevated air speed and ceiling fans.
  - Model ID: `"cooling_effect"` (accessible via `predict(model="cooling_effect", ...)`)
  - Wraps `pythermalcomfort.models.cooling_effect` to compute CE (°C) —
    the equivalent still-air temperature reduction provided by elevated air
    speed.  A positive CE means the fan allows raising the cooling setpoint
    by CE °C while maintaining equivalent thermal comfort.
  - PMV/PPD/sensation/compliance are computed at the actual (elevated-air-speed)
    conditions using `pmv_ppd_ashrae`; the CE is stored in the new
    `ComfortResult.cooling_effect` field.
  - `vel` is interpreted as the relative air speed (vr).  Use
    `pythermalcomfort.utilities.v_relative(v, met)` to convert from a
    sensor-measured speed when needed.
  - CE is zero for `vel ≤ 0.1 m/s`; a warning is appended in that case.

- **`ComfortResult.cooling_effect: float | None`** — new optional field
  (defaults to `None`); populated only by `CoolingEffectModel`.

- **34 new tests** in `tests/test_cooling_effect.py`: model identity,
  numerical parity with pythermalcomfort, reference values, threshold
  boundary behaviour, warnings, batch prediction, public API integration.
  Total: **283 tests, 283 passed**.

---

## [0.5.0] — 2026-04-26

### Changed — breaking

- **`PersonalPosterior`** (`comfortkit/models/personal.py`) upgraded from
  Beta-Bernoulli (K=2) to **Dirichlet-Multinomial (K=3)**.
  - Fields renamed: `alpha_cooler → alpha_warm`, `alpha_not_cooler → alpha_neutral`;
    new field `alpha_cool` added.
  - `update(vote)` now accepts `vote ∈ {-1, 0, 1}`:
    `1 = Warm` (wants cooling), `0 = Neutral` (comfortable),
    `-1 = Cool` (wants heating).
  - New properties: `p_warm`, `p_neutral`, `p_cool`.
  - `predict()` returns `1 / 0 / -1`; ties broken toward `0` (Neutral).
  - `p_cooler` retained as an alias for `p_warm` for v0.3 backwards compatibility.
  - `from_dict()` handles the legacy v0.3 binary format
    (`alpha_cooler` / `alpha_not_cooler`).

- **Prior updated** (`comfortkit/models/personal_prior.json`) to three-class
  Dorn indoor vote distribution (20 users, 20,235 votes, Singapore Apr–Nov 2020):
  `P(Warm)=0.3693`, `P(Neutral)=0.5663`, `P(Cool)=0.0644`.  Concentration
  unchanged at 5 pseudo-counts.

- **`POST /v1/feedback`**: `vote` field now accepts `-1` in addition to `0` and
  `1`.  Response body adds `p_warm`, `p_neutral`, `p_cool`; `p_cooler` is
  retained as an alias for `p_warm`.  `prediction_label` is now `"Warm"`,
  `"Neutral"`, or `"Cool"` (was `"Cooler"` / `"Not Cooler"`).

- **`GET /v1/comfort/{user_id}`**: same response body changes as
  `POST /v1/feedback`.

- **`SQLiteUserStore`** (`api/store.py`): schema migrated from two columns
  (`alpha_cooler`, `alpha_not_cooler`) to three (`alpha_warm`, `alpha_neutral`,
  `alpha_cool`).  `_init_db()` detects the old schema and migrates
  automatically on first use — no manual migration required.

- **`ZoneAggregator`** (`comfortkit/models/zone.py`) updated for three-class
  posteriors:
  - `ZoneUserSummary` gains `p_cool` field; `prediction_label` is now
    `"Warm" / "Neutral" / "Cool"` (was `"Warm" / "Not Warm"`).
  - `ZoneComfortResult` gains `mean_p_cool` field.
  - **Strategy A (`mean_p_warm`)**: `raise_setpoint` trigger changed from
    `mean_p_warm < 0.35` to `mean_p_cool > 0.35`.  This is the root-cause fix:
    neutral-heavy users no longer suppress P(Warm) into the heating range.
  - **Strategy B (`majority_vote`)**: counts three classes; strict majority of
    Cool predictions triggers `raise_setpoint` (was: majority of non-Warm).
  - **Strategy C (`any_discomfort`)**: now symmetric — `raise_setpoint` when
    any user's `P(Cool) > 0.7` (was warm-only).

- **`POST /v1/zone/predict`** response body gains `mean_p_cool` and per-user
  `p_cool`.

### Root cause fixed

**Before (v0.4 binary model):** `vote = 0` incremented `alpha_not_cooler` for
both `thermal=10` (neutral/comfortable) and `thermal=9` (cold preference).
Occupants with many neutral votes — like enth01 (16 neutral votes) — accumulated
`P(Warm) ≈ 0.09`, pulling zone means below the 0.35 raise-setpoint threshold
even when the observed majority were voting warm.  The `any_discomfort` strategy
was the recommended workaround.

**After (v0.5 three-class model):** enth01's 16 neutral votes increment
`alpha_neutral` only.  Their posterior converges to `P(Warm) ≈ 0.37`,
`P(Neutral) ≈ 0.60`, `P(Cool) ≈ 0.03` — correctly excluded from both heating
and cooling signals.  `mean_p_warm` and `majority_vote` are now reliable without
requiring the `any_discomfort` workaround.

### Tests

- `tests/test_personal.py` rewritten for three-class model (51 tests).
- `tests/test_zone.py` updated: three-class `_posterior` / `_cold_posterior`
  helpers; symmetric `any_discomfort` tests; `p_cool` field coverage (49 tests).
- Total: **249 tests, 249 passed**.

---

## [0.4.0] — 2026-04-26

### Added
- **`ZoneAggregator`** (`comfortkit/models/zone.py`) — combines per-user
  Beta-Bernoulli posteriors into a zone-level HVAC action recommendation.
  Three aggregation strategies:
  - `mean_p_warm` — acts when the mean P(Warm) crosses a threshold
    (>0.5 → lower_setpoint, <0.35 → raise_setpoint, else maintain).
  - `majority_vote` — tallies each user's MAP label; strict majority wins.
  - `any_discomfort` — flags lower_setpoint if any user's P(Warm) > 0.7.
- **`ZoneComfortResult`** dataclass — action, strategy, mean_p_warm,
  fraction_warm, n_users, per_user breakdown, confidence, warnings.
- **`ZoneUserSummary`** dataclass — p_warm, prediction_label, n_votes
  per occupant; included in every ZoneComfortResult.
- **`POST /v1/zone/predict`** — accepts a list of user_ids and an optional
  aggregation strategy; looks up personal posteriors from the store and
  returns a ZoneComfortResult.
- **`ZonePredictRequest`, `ZonePredictResponse`, `ZoneUserSummaryResponse`**
  schemas in `api/schemas.py`.
- **`ml/validate_zone.py`** — proof-of-concept validation script on the ENTH
  longitudinal dataset (NUS, Mar–Apr 2021).  Builds leave-future-out personal
  posteriors, runs all three strategies on the 3 known 3-user co-occupancy
  configurations (spaces 206 and 130), and compares against majority-rule
  ground truth and single-user baseline.  Includes 15/30/60 min window
  sensitivity analysis.  Output clearly documents the sample-size limitations.
- 37 new tests in `tests/test_zone.py` covering ZoneAggregator unit behaviour
  (all three strategies, edge cases, confidence, warnings) and the
  POST /v1/zone/predict endpoint.

### Changed
- API version string bumped to `0.4.0` in `api/main.py`.

### Notes
- The `any_discomfort` strategy is intentionally asymmetric: it only detects
  warm-side discomfort.  Cold-side detection requires a future three-class
  extension of the personal model.
- `zone_temp` in the request is accepted and stored for traceability but not
  yet used in the aggregation calculation.

---

## [0.3.0] — 2026-04-26

### Added
- **Personalised comfort model** (`comfortkit/models/personal.py`) — Beta-Bernoulli
  per-user posterior (Dirichlet-Multinomial, K=2).  Each occupant vote increments
  the relevant pseudo-count; posterior mean gives P(Cooler) for that user.
- **Warm-start prior** (`comfortkit/models/personal_prior.json`) — derived from
  aggregate vote distribution across 20 users in the Dorn longitudinal study
  (Singapore, 2020): P(Cooler)=0.379, concentration=5 pseudo-counts.
- **`UserStore` interface** (`api/store.py`) — abstract storage contract for
  per-user posteriors; `SQLiteUserStore` implements it with WAL-mode SQLite.
  Override `COMFORTKIT_DB` env var to change the DB path.  Swap to Postgres for
  production.
- **`POST /v1/feedback`** — accepts an occupant vote (1=Cooler, 0=Not Cooler)
  plus optional contextual features (heart_rate, t_net, rh_net, clothing, met);
  updates the Beta-Bernoulli posterior; returns updated p_cooler and prediction.
- **`GET /v1/comfort/{user_id}`** — returns personalised P(Cooler), MAP
  prediction, and confidence level (prior / low / medium / high).
- **`FeedbackRequest`, `FeedbackResponse`, `PersonalComfortResponse`** schemas
  in `api/schemas.py`.
- **`ml/validate_personal.py`** — validation script that replays dorn study votes
  sequentially per user and compares personalised accuracy vs. global majority
  baseline at checkpoints (10 / 50 / 100 / 200 / 500 votes).
- 38 new tests in `tests/test_personal.py` covering model, store, and endpoints.

### Changed
- API version string bumped to `0.3.0` in `api/main.py`.

---

## [0.2.2] — 2026-04-25

### Added
- `ComfortResult.conformal_ci_95: tuple[float, float] | None` — split conformal
  prediction interval on PMV; calibrated on the ASHRAE Global Thermal Comfort
  Database II against real TSV votes (Földváry Ličina et al., 2018).
  The interval half-width q=2.77 was calibrated at α=0.04 (conservative to
  account for study-level distribution shift); empirical test-set coverage 95.3 %.
- `conformal_ci(pmv)` in `comfortkit/uncertainty.py` — symmetric ±q interval
  loaded at module import from the bundled calibration file; returns `None` when
  the calibration file is absent (graceful degradation).
- `ml/calibrate_conformal.py` — calibration script using MAPIE 1.3
  `SplitConformalRegressor` (prefit mode); wraps the standard PMV predictor;
  nonconformity score = |TSV − PMV|; requires `comfortkit[ml-train]`.
- `comfortkit/models/conformal_calibration.json` — bundled calibration artefact
  (q, α, n_calibration, empirical_coverage_test).
- `mapie>=1.3` and `scikit-learn>=1.4` added to `ml-train` optional dep group.
- 18 new tests in `tests/test_conformal.py`.

### Changed
- `StandardComfortModel.predict()` now populates `conformal_ci_95` alongside
  the existing bootstrap `ci_95`.  SET and Adaptive models return `None`.

---

## [0.2.1] — 2026-04-25

### Added
- `SetComfortModel` (`model="set"`) — adapter over pythermalcomfort's
  `set_tmp()`.  Returns SET value in `result.set_tmp`; `pmv`/`ppd` are `None`.
  Sensation mapped via ASHRAE 55 Table B-1 thresholds; compliance based on
  ASHRAE 55 comfort zone (22.2–25.6 °C SET).
- `AdaptiveASHRAEComfortModel` (`model="adaptive_ashrae"`, alias `"adaptive"`)
  — adapter over pythermalcomfort's `adaptive_ashrae()`.  Requires
  `t_running_mean` on `ComfortInputs`; raises `ComfortInputError` with a clear
  message if absent.  Compliance = 80 % acceptability; warns when
  `t_running_mean` is outside the ASHRAE 55 applicability range (10–33.5 °C).
- `"adaptive"` short alias in `predict(model="adaptive", ...)`.
- `ComfortResult.set_tmp: float | None` — new optional field for SET
  temperature; defaults to `None` for all other models (backward-compatible).
- `ComfortInputs.t_running_mean: float | None` — new optional field for
  prevailing mean outdoor temperature; ignored by PMV/SET/ML models.
- `SET_COMFORT_ZONE` and `SET_SENSATION_THRESHOLDS` constants in
  `comfortkit/_constants.py`.
- 42 new tests in `tests/test_set_adaptive.py`; total 123/123 green.

---

## [0.2.0] — 2026-04-22

### Added
- **ML correction layer** (`model="ml"` / `model="ml_pmv"`): LightGBM residual
  model trained on the ASHRAE Global Thermal Comfort Database II (~78 k field
  observations, 41 studies; Földváry Ličina et al., Building and Environment,
  2018, https://doi.org/10.1016/j.buildenv.2018.06.022).  Predicts the TSV − PMV residual and applies it on
  top of the standard physics estimate.  9% RMSE improvement over plain PMV.
- `MLComfortModel` in `comfortkit/models/ml.py` — implements the `ComfortModel`
  ABC; calls `StandardComfortModel` for the physics baseline then applies ONNX
  Runtime inference for the correction.
- `comfortkit/models/pmv_correction.onnx` and `pmv_correction_meta.json` —
  bundled with the package; no LightGBM dependency at inference time.
- Optional `ComfortInputs` fields: `t_out`, `cooling_strategy`, `building_type`
  — capture adaptive-comfort effects; improve ML correction accuracy when
  available; ignored by the standard model.
- `"ml"` short alias in `predict(model="ml", ...)`.
- `ml` and `ml-train` optional dependency groups in `pyproject.toml`.
- `ml/data/ashrae_db2_prep.py` — data cleaning, imputation, study-level 80/20
  split, Parquet output.
- `ml/train.py` — LightGBM training, ONNX export, smoke-test.
- `list_models()` now only includes `ml_pmv` when `onnxruntime` is installed;
  missing-model `KeyError` includes a `pip install comfortkit[ml]` hint.

### Changed
- `README.md`: ML correction layer section, roadmap rows marked shipped,
  comparison table updated, CBE Thermal Comfort Tool acknowledgement added,
  ISO vs ASHRAE divergence note added.
- Version bumped to `0.2.0`.

---

## [0.1.0] — 2026-03-01

### Added
- `StandardComfortModel` — thin adapter over
  [pythermalcomfort](https://github.com/CenterForTheBuiltEnvironment/pythermalcomfort)
  for PMV/PPD via both ISO 7730 (`standard="iso"`) and ASHRAE 55
  (`standard="ashrae"`).
- `ComfortInputs` — Pydantic v2 model with field validation; raises
  `ComfortInputError` for physically impossible inputs (`vel < 0`, `rh > 100`,
  `met ≤ 0`, `clo < 0`).
- `ComfortResult` — dataclass with `pmv`, `ppd`, `sensation`, `compliant`,
  `ci_95`, `model`, `warnings`.
- `bootstrap_ci` — parametric bootstrap confidence interval on PMV using a
  vectorised pure-NumPy ISO 7730 kernel; wired into every `predict()` call.
- `monte_carlo_propagate` — caller-supplied sigma Monte Carlo propagation.
- `predict()` — dual calling style: keyword arguments and `ComfortInputs` object.
- `predict_batch()` — batch predictions over a list of inputs.
- `list_models()` — returns registered model identifiers.
- FastAPI REST API (`api/`) with `POST /v1/predict`, `POST /v1/predict/batch`,
  `GET /v1/models`; Dockerfile and `docker-compose.yml`.
- Applicability warnings (non-fatal) for out-of-range inputs per ASHRAE 55 and
  ISO 7730 limits.
- `tests/` — 56 tests covering adapter parity with pythermalcomfort, ISO 7730
  Annex D reference cases, CI correctness, API endpoints.
- `pyproject.toml` with `api`, `dev`, `docs` optional dep groups.
