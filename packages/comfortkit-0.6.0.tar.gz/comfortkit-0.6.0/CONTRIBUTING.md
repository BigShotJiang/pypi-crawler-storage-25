# Contributing to comfortkit

Thank you for your interest in contributing. comfortkit is an open project
welcoming contributions from building scientists, ML practitioners, and
software engineers.

---

## Quick start

```bash
git clone https://github.com/K2alyan/comfortkit
cd comfortkit
pip install -e ".[dev]"
pre-commit install
pytest
```

---

## What we're looking for

Good first issues are labelled [`good-first-issue`](https://github.com/K2alyan/comfortkit/labels/good-first-issue).
We especially welcome:

- **New model adapters** — exposing pythermalcomfort models not yet wrapped
  (e.g. UTCI, two-node Gagge, EN 16798-1 adaptive) through the `ComfortModel`
  interface
- **Uncertainty improvements** — better CI methods, calibration on larger
  datasets, propagation for adaptive and SET models
- **Personalised comfort backends** — alternative `UserStore` implementations
  (Postgres, Redis, cloud key-value stores) and richer per-user feature models
- **BMS/sensor platform integrations** — connectors for common building data
  sources (Niagara, Haystack, BRICK schema)
- **Occupant feedback datasets** — real-world longitudinal comfort survey data
  with matched sensor readings, for improving the ML correction layer and
  personalised comfort models
- **Language bindings** — R wrapper, Julia package consuming the REST API

---

## Development workflow

1. Fork the repo and create a branch: `git checkout -b feat/your-feature`
2. Write tests first — see `tests/` for patterns
3. Run the full check suite before opening a PR:

```bash
ruff check . && ruff format . && mypy comfortkit/ && pytest
```

4. Open a PR against `develop`. The project targets Python 3.10, 3.11, and 3.12.

---

## Adding a new model adapter

comfortkit wraps `pythermalcomfort` as its computational backend. To expose a
new model:

1. Check whether `pythermalcomfort` already implements it — see the
   [pythermalcomfort documentation](https://pythermalcomfort.readthedocs.io).

2. If yes — add an adapter in `comfortkit/models/standard.py`:
   - Translate `ComfortInputs` → pythermalcomfort arguments
   - Call the pythermalcomfort function
   - Translate the result → `ComfortResult`
   - Add applicability warnings via `validation.py`

3. If no — implement from scratch as a new `ComfortModel` subclass.
   Include a reference (paper/standard) in the docstring and add
   validation fixtures in `tests/fixtures/`.

4. Register the model in `comfortkit/models/registry.py`. The
   `GET /v1/models` API endpoint picks up registrations automatically.

5. Add tests in a dedicated `tests/test_<model_name>.py` file.

---

## Code style

- Python 3.10+, type hints on all public functions
- NumPy-format docstrings
- Ruff for linting and formatting (config in `pyproject.toml`)
- Never raise on out-of-applicability inputs — append to `result.warnings`
- Raise `ComfortInputError` only for physically impossible inputs
- Import `pythermalcomfort` only in `comfortkit/models/standard.py`

---

## Commit messages

[Conventional Commits](https://www.conventionalcommits.org/):

```
feat: expose UTCI adapter in standard model
fix: correct adaptive ASHRAE 55 applicability limit check
docs: add uncertainty quantification explainer to README
test: add ISO 7730 Annex D case C fixture
```

---

## Production deployment

The personalised comfort model stores per-user posteriors in SQLite by default.
SQLite is suitable for development and small single-server deployments, but
should be replaced before running at scale.

**Switching to Postgres:**

1. Set the environment variable:
   ```bash
   export COMFORTKIT_DB=postgresql://user:pass@host/db
   ```

2. Add a Postgres service to `docker-compose.yml`:
   ```yaml
   services:
     db:
       image: postgres:16
       environment:
         POSTGRES_USER: comfortkit
         POSTGRES_PASSWORD: secret
         POSTGRES_DB: comfortkit
       volumes:
         - pgdata:/var/lib/postgresql/data
     api:
       depends_on: [db]
       environment:
         COMFORTKIT_DB: postgresql://comfortkit:secret@db/comfortkit
   volumes:
     pgdata:
   ```

3. Implement `PostgresUserStore(UserStore)` in `api/store.py` — the `UserStore`
   interface is the only file that needs to change. The model and API logic are
   storage-agnostic.

SQLite remains the default for zero-infrastructure local development.

---

## Questions?

Open a [Discussion](https://github.com/K2alyan/comfortkit/discussions).
Don't open an issue for questions.
