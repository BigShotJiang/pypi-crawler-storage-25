"""Tests for uncertainty quantification — bootstrap CI and Monte Carlo propagation."""

from __future__ import annotations

import numpy as np
import pytest
from pythermalcomfort.models import pmv_ppd_iso  # type: ignore[import-untyped]

from comfortkit.models.base import ComfortInputs
from comfortkit.models.standard import StandardComfortModel
from comfortkit.uncertainty import _pmv_samples, bootstrap_ci, monte_carlo_propagate


@pytest.fixture
def typical_inputs() -> ComfortInputs:
    return ComfortInputs(ta=22, tr=22, vel=0.1, rh=50, met=1.2, clo=0.5)


# ---------------------------------------------------------------------------
# _pmv_samples parity with pythermalcomfort ISO kernel
# ---------------------------------------------------------------------------

class TestPmvSamples:
    """_pmv_samples must agree with pythermalcomfort's ISO PMV to within ±0.05."""

    _CASES = [
        (22.0, 22.0, 0.1, 60.0, 1.2, 0.5),   # ISO 7730 Annex D — case A
        (27.0, 27.0, 0.1, 60.0, 1.2, 0.5),   # ISO 7730 Annex D — case B
        (27.0, 27.0, 0.3, 60.0, 1.2, 0.5),   # ISO 7730 Annex D — case C
        (22.0, 22.0, 0.1, 50.0, 1.2, 0.5),   # typical office
        (26.0, 28.0, 0.2, 40.0, 1.0, 1.0),   # warm, dressed
    ]

    def test_parity_with_pythermalcomfort(self) -> None:
        arr = np.array(self._CASES, dtype=np.float64)
        pmv_kit = _pmv_samples(arr)
        for i, (ta, tr, vr, rh, met, clo) in enumerate(self._CASES):
            ref = pmv_ppd_iso(tdb=ta, tr=tr, vr=vr, rh=rh, met=met, clo=clo, limit_inputs=False)
            assert abs(pmv_kit[i] - ref.pmv) <= 0.05, (
                f"row {i}: _pmv_samples={pmv_kit[i]:.4f}, pythermalcomfort={ref.pmv:.4f}"
            )

    def test_batch_shape(self) -> None:
        arr = np.array(self._CASES, dtype=np.float64)
        out = _pmv_samples(arr)
        assert out.shape == (len(self._CASES),)

    def test_single_row(self) -> None:
        arr = np.array([[22.0, 22.0, 0.1, 60.0, 1.2, 0.5]], dtype=np.float64)
        out = _pmv_samples(arr)
        assert out.shape == (1,)
        ref = pmv_ppd_iso(tdb=22, tr=22, vr=0.1, rh=60, met=1.2, clo=0.5, limit_inputs=False)
        assert abs(out[0] - ref.pmv) <= 0.05


# ---------------------------------------------------------------------------
# bootstrap_ci
# ---------------------------------------------------------------------------

class TestBootstrapCI:
    def test_returns_two_floats(self, typical_inputs: ComfortInputs) -> None:
        lo, hi = bootstrap_ci(typical_inputs, seed=42)
        assert isinstance(lo, float)
        assert isinstance(hi, float)

    def test_lower_le_upper(self, typical_inputs: ComfortInputs) -> None:
        lo, hi = bootstrap_ci(typical_inputs, seed=42)
        assert lo <= hi

    def test_central_pmv_within_ci(self, typical_inputs: ComfortInputs) -> None:
        pmv_central = StandardComfortModel().predict(typical_inputs).pmv
        assert pmv_central is not None
        lo, hi = bootstrap_ci(typical_inputs, n_samples=5000, seed=42)
        assert lo <= pmv_central <= hi

    def test_reproducible_with_seed(self, typical_inputs: ComfortInputs) -> None:
        r1 = bootstrap_ci(typical_inputs, seed=42)
        r2 = bootstrap_ci(typical_inputs, seed=42)
        assert r1 == r2

    def test_different_seeds_differ(self, typical_inputs: ComfortInputs) -> None:
        r1 = bootstrap_ci(typical_inputs, seed=1)
        r2 = bootstrap_ci(typical_inputs, seed=2)
        assert r1 != r2

    def test_rounded_to_2dp(self, typical_inputs: ComfortInputs) -> None:
        lo, hi = bootstrap_ci(typical_inputs, seed=42)
        assert lo == round(lo, 2)
        assert hi == round(hi, 2)


# ---------------------------------------------------------------------------
# monte_carlo_propagate
# ---------------------------------------------------------------------------

class TestMonteCarloPropagate:
    def test_zero_sigma_collapses_to_point(self, typical_inputs: ComfortInputs) -> None:
        lo, hi = monte_carlo_propagate(typical_inputs, sigma={}, seed=42)
        assert lo == hi

    def test_wider_sigma_gives_wider_ci(self, typical_inputs: ComfortInputs) -> None:
        lo1, hi1 = monte_carlo_propagate(
            typical_inputs, sigma={"ta": 0.5}, n_samples=2000, seed=42
        )
        lo2, hi2 = monte_carlo_propagate(
            typical_inputs, sigma={"ta": 5.0}, n_samples=2000, seed=42
        )
        assert (hi2 - lo2) > (hi1 - lo1)

    def test_reproducible_with_seed(self, typical_inputs: ComfortInputs) -> None:
        r1 = monte_carlo_propagate(typical_inputs, sigma={"ta": 0.5}, seed=42)
        r2 = monte_carlo_propagate(typical_inputs, sigma={"ta": 0.5}, seed=42)
        assert r1 == r2

    def test_returns_lower_le_upper(self, typical_inputs: ComfortInputs) -> None:
        lo, hi = monte_carlo_propagate(
            typical_inputs, sigma={"ta": 1.0, "tr": 2.0}, seed=42
        )
        assert lo <= hi

    def test_rounded_to_2dp(self, typical_inputs: ComfortInputs) -> None:
        lo, hi = monte_carlo_propagate(typical_inputs, sigma={"ta": 0.5}, seed=42)
        assert lo == round(lo, 2)
        assert hi == round(hi, 2)

    def test_multi_field_sigma(self, typical_inputs: ComfortInputs) -> None:
        lo, hi = monte_carlo_propagate(
            typical_inputs,
            sigma={"ta": 0.5, "tr": 1.0, "vel": 0.05, "rh": 3.0},
            n_samples=5000,
            seed=99,
        )
        assert lo <= hi
