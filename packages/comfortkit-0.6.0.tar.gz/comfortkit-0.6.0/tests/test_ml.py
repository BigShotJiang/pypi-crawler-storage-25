"""Tests for MLComfortModel (v0.2 residual correction layer)."""

from __future__ import annotations

import pytest

import comfortkit
from comfortkit.models.base import ComfortInputs
from comfortkit.models.ml import MLComfortModel
from comfortkit.models.standard import StandardComfortModel

_BASE_KWARGS = dict(ta=22.0, tr=22.0, vel=0.1, rh=60.0, met=1.2, clo=0.5)
_BASE_INPUTS = ComfortInputs(**_BASE_KWARGS)


@pytest.fixture(scope="module")
def ml_model() -> MLComfortModel:
    return MLComfortModel()


class TestMLModelLoads:
    def test_model_instantiates(self) -> None:
        model = MLComfortModel()
        assert model is not None

    def test_model_id(self, ml_model: MLComfortModel) -> None:
        assert MLComfortModel.MODEL_ID == "ml_pmv"

    def test_registered_in_registry(self) -> None:
        from comfortkit.models.registry import list_models
        assert "ml_pmv" in list_models()


class TestMLPredict:
    def test_returns_comfort_result(self, ml_model: MLComfortModel) -> None:
        result = ml_model.predict(_BASE_INPUTS)
        assert result is not None

    def test_pmv_is_float(self, ml_model: MLComfortModel) -> None:
        result = ml_model.predict(_BASE_INPUTS)
        assert result.pmv is not None
        assert isinstance(result.pmv, float)

    def test_ppd_is_float(self, ml_model: MLComfortModel) -> None:
        result = ml_model.predict(_BASE_INPUTS)
        assert result.ppd is not None
        assert isinstance(result.ppd, float)

    def test_ppd_range(self, ml_model: MLComfortModel) -> None:
        result = ml_model.predict(_BASE_INPUTS)
        assert result.ppd is not None
        assert 5.0 <= result.ppd <= 100.0

    def test_model_field(self, ml_model: MLComfortModel) -> None:
        result = ml_model.predict(_BASE_INPUTS)
        assert result.model == "ml_pmv"

    def test_ci95_populated(self, ml_model: MLComfortModel) -> None:
        result = ml_model.predict(_BASE_INPUTS)
        assert result.ci_95 is not None
        lo, hi = result.ci_95
        assert isinstance(lo, float) and isinstance(hi, float)
        assert lo <= hi

    def test_warnings_list(self, ml_model: MLComfortModel) -> None:
        result = ml_model.predict(_BASE_INPUTS)
        assert isinstance(result.warnings, list)

    def test_sensation_is_string(self, ml_model: MLComfortModel) -> None:
        result = ml_model.predict(_BASE_INPUTS)
        assert isinstance(result.sensation, str)
        assert len(result.sensation) > 0

    def test_pmv_close_to_standard(self, ml_model: MLComfortModel) -> None:
        std_model = StandardComfortModel()
        ml_result = ml_model.predict(_BASE_INPUTS)
        std_result = std_model.predict(_BASE_INPUTS)
        # Corrected PMV should be within ±2 PMV units of standard physics
        assert ml_result.pmv is not None and std_result.pmv is not None
        assert abs(ml_result.pmv - std_result.pmv) < 2.0


class TestMLOptionalFields:
    def test_with_t_out(self, ml_model: MLComfortModel) -> None:
        inputs = ComfortInputs(**_BASE_KWARGS, t_out=15.0)
        result = ml_model.predict(inputs)
        assert result.pmv is not None

    def test_with_cooling_strategy(self, ml_model: MLComfortModel) -> None:
        inputs = ComfortInputs(**_BASE_KWARGS, cooling_strategy="Air Conditioned")
        result = ml_model.predict(inputs)
        assert result.pmv is not None

    def test_with_building_type(self, ml_model: MLComfortModel) -> None:
        inputs = ComfortInputs(**_BASE_KWARGS, building_type="Office")
        result = ml_model.predict(inputs)
        assert result.pmv is not None

    def test_with_all_optional_fields(self, ml_model: MLComfortModel) -> None:
        inputs = ComfortInputs(
            **_BASE_KWARGS,
            t_out=10.0,
            cooling_strategy="Naturally Ventilated",
            building_type="Classroom",
        )
        result = ml_model.predict(inputs)
        assert result.pmv is not None

    def test_unknown_cooling_strategy(self, ml_model: MLComfortModel) -> None:
        inputs = ComfortInputs(**_BASE_KWARGS, cooling_strategy="SomethingNew")
        result = ml_model.predict(inputs)
        assert result.pmv is not None

    def test_unknown_building_type(self, ml_model: MLComfortModel) -> None:
        inputs = ComfortInputs(**_BASE_KWARGS, building_type="Spaceship")
        result = ml_model.predict(inputs)
        assert result.pmv is not None


class TestMLBatchPredict:
    def test_batch_returns_correct_count(self, ml_model: MLComfortModel) -> None:
        inputs = [
            ComfortInputs(**_BASE_KWARGS),
            ComfortInputs(ta=26.0, tr=26.0, vel=0.2, rh=50.0, met=1.0, clo=0.5),
        ]
        results = ml_model.predict_batch(inputs)
        assert len(results) == 2

    def test_batch_matches_individual(self, ml_model: MLComfortModel) -> None:
        inputs = [
            ComfortInputs(**_BASE_KWARGS),
            ComfortInputs(ta=26.0, tr=26.0, vel=0.2, rh=50.0, met=1.0, clo=0.5),
        ]
        batch = ml_model.predict_batch(inputs)
        individual = [ml_model.predict(inp) for inp in inputs]
        for b, i in zip(batch, individual):
            assert b.pmv == i.pmv
            assert b.ppd == i.ppd
            assert b.model == i.model

    def test_batch_model_field(self, ml_model: MLComfortModel) -> None:
        inputs = [ComfortInputs(**_BASE_KWARGS)]
        results = ml_model.predict_batch(inputs)
        assert all(r.model == "ml_pmv" for r in results)


class TestPublicAPIMLAlias:
    def test_ml_alias_resolves(self) -> None:
        result = comfortkit.predict(model="ml", **_BASE_KWARGS)
        assert result.model == "ml_pmv"

    def test_ml_pmv_resolves(self) -> None:
        result = comfortkit.predict(model="ml_pmv", **_BASE_KWARGS)
        assert result.model == "ml_pmv"

    def test_ml_returns_pmv(self) -> None:
        result = comfortkit.predict(model="ml", **_BASE_KWARGS)
        assert result.pmv is not None

    def test_ml_batch_via_public_api(self) -> None:
        inputs = [ComfortInputs(**_BASE_KWARGS), ComfortInputs(**_BASE_KWARGS)]
        results = comfortkit.predict_batch(inputs, model="ml")
        assert len(results) == 2
        assert all(r.model == "ml_pmv" for r in results)
