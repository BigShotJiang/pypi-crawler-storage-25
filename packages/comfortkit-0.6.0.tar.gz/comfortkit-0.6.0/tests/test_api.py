"""API integration tests using httpx.AsyncClient (no live server)."""

from __future__ import annotations

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient

from api.main import app

BASE_URL = "http://testserver"


@pytest_asyncio.fixture
async def client() -> AsyncClient:
    async with AsyncClient(transport=ASGITransport(app=app), base_url=BASE_URL) as c:
        yield c


TYPICAL_PAYLOAD = {
    "ta": 22.0,
    "tr": 22.0,
    "vel": 0.1,
    "rh": 60.0,
    "met": 1.2,
    "clo": 0.5,
    "standard": "ashrae",
}


class TestPredictEndpoint:
    async def test_returns_200(self, client: AsyncClient) -> None:
        resp = await client.post("/v1/predict", json=TYPICAL_PAYLOAD)
        assert resp.status_code == 200

    async def test_response_schema(self, client: AsyncClient) -> None:
        resp = await client.post("/v1/predict", json=TYPICAL_PAYLOAD)
        data = resp.json()
        assert "pmv" in data
        assert "ppd" in data
        assert "sensation" in data
        assert "compliant" in data
        assert "model" in data
        assert "warnings" in data
        assert "ci_95" in data

    async def test_ci95_is_populated(self, client: AsyncClient) -> None:
        resp = await client.post("/v1/predict", json=TYPICAL_PAYLOAD)
        data = resp.json()
        assert data["ci_95"] is not None
        assert len(data["ci_95"]) == 2
        assert data["ci_95"][0] <= data["ci_95"][1]

    async def test_invalid_rh_returns_422(self, client: AsyncClient) -> None:
        payload = {**TYPICAL_PAYLOAD, "rh": 150}
        resp = await client.post("/v1/predict", json=payload)
        assert resp.status_code == 422

    async def test_negative_vel_returns_422(self, client: AsyncClient) -> None:
        payload = {**TYPICAL_PAYLOAD, "vel": -1.0}
        resp = await client.post("/v1/predict", json=payload)
        assert resp.status_code == 422


class TestBatchPredictEndpoint:
    async def test_returns_200(self, client: AsyncClient) -> None:
        payload = {"inputs": [TYPICAL_PAYLOAD, TYPICAL_PAYLOAD]}
        resp = await client.post("/v1/predict/batch", json=payload)
        assert resp.status_code == 200

    async def test_result_count_matches_input(self, client: AsyncClient) -> None:
        payload = {"inputs": [TYPICAL_PAYLOAD, TYPICAL_PAYLOAD, TYPICAL_PAYLOAD]}
        resp = await client.post("/v1/predict/batch", json=payload)
        assert len(resp.json()["results"]) == 3

    async def test_empty_batch_returns_422(self, client: AsyncClient) -> None:
        resp = await client.post("/v1/predict/batch", json={"inputs": []})
        assert resp.status_code == 422


class TestListModelsEndpoint:
    async def test_returns_200(self, client: AsyncClient) -> None:
        resp = await client.get("/v1/models")
        assert resp.status_code == 200

    async def test_contains_standard_model(self, client: AsyncClient) -> None:
        resp = await client.get("/v1/models")
        ids = [m["id"] for m in resp.json()["models"]]
        assert "standard_pmv" in ids
