"""Tests for conformal prediction CI in comfortkit."""

from __future__ import annotations

import pytest

import comfortkit
from comfortkit.models.base import ComfortInputs, ComfortResult
from comfortkit.models.standard import StandardComfortModel, SetComfortModel
from comfortkit.uncertainty import conformal_ci, _CONFORMAL_Q

_PMV_KWARGS = dict(ta=25.0, tr=25.0, vel=0.1, rh=50.0, met=1.2, clo=0.5)


# ---------------------------------------------------------------------------
# conformal_ci() function
# ---------------------------------------------------------------------------


class TestConformalCiFunction:
    def test_returns_tuple(self) -> None:
        result = conformal_ci(0.0)
        assert isinstance(result, tuple) or result is None

    def test_returns_two_floats(self) -> None:
        result = conformal_ci(0.5)
        if result is not None:
            lo, hi = result
            assert isinstance(lo, float)
            assert isinstance(hi, float)

    def test_lower_less_than_upper(self) -> None:
        result = conformal_ci(0.5)
        if result is not None:
            assert result[0] < result[1]

    def test_symmetric_around_pmv(self) -> None:
        pmv = 0.5
        result = conformal_ci(pmv)
        if result is not None:
            lo, hi = result
            assert abs((hi - pmv) - (pmv - lo)) < 1e-9

    def test_constant_width(self) -> None:
        r1 = conformal_ci(0.0)
        r2 = conformal_ci(1.5)
        if r1 is not None and r2 is not None:
            w1 = r1[1] - r1[0]
            w2 = r2[1] - r2[0]
            assert abs(w1 - w2) < 1e-9

    def test_width_reasonable(self) -> None:
        result = conformal_ci(0.0)
        if result is not None:
            width = result[1] - result[0]
            assert 1.0 < width < 8.0

    def test_rounded_to_two_decimal_places(self) -> None:
        result = conformal_ci(0.333)
        if result is not None:
            lo, hi = result
            assert round(lo, 2) == lo
            assert round(hi, 2) == hi

    def test_negative_pmv(self) -> None:
        result = conformal_ci(-1.5)
        if result is not None:
            lo, hi = result
            assert lo < -1.5 < hi

    def test_q_value_reasonable(self) -> None:
        if _CONFORMAL_Q is not None:
            assert 1.0 < _CONFORMAL_Q < 5.0


# ---------------------------------------------------------------------------
# ComfortResult integration
# ---------------------------------------------------------------------------


class TestConformalCiOnComfortResult:
    def test_conformal_ci_95_present(self) -> None:
        model = StandardComfortModel()
        result = model.predict(ComfortInputs(**_PMV_KWARGS))
        assert hasattr(result, "conformal_ci_95")

    def test_conformal_ci_95_is_tuple_or_none(self) -> None:
        model = StandardComfortModel()
        result = model.predict(ComfortInputs(**_PMV_KWARGS))
        assert result.conformal_ci_95 is None or isinstance(result.conformal_ci_95, tuple)

    def test_conformal_ci_95_straddles_pmv(self) -> None:
        model = StandardComfortModel()
        result = model.predict(ComfortInputs(**_PMV_KWARGS))
        if result.conformal_ci_95 is not None and result.pmv is not None:
            lo, hi = result.conformal_ci_95
            assert lo <= result.pmv <= hi

    def test_conformal_ci_95_two_elements(self) -> None:
        model = StandardComfortModel()
        result = model.predict(ComfortInputs(**_PMV_KWARGS))
        if result.conformal_ci_95 is not None:
            assert len(result.conformal_ci_95) == 2

    def test_conformal_ci_95_lower_lt_upper(self) -> None:
        model = StandardComfortModel()
        result = model.predict(ComfortInputs(**_PMV_KWARGS))
        if result.conformal_ci_95 is not None:
            lo, hi = result.conformal_ci_95
            assert lo < hi


# ---------------------------------------------------------------------------
# Non-PMV models: conformal_ci_95 is None
# ---------------------------------------------------------------------------


class TestConformalCiNoneForNonPmvModels:
    def test_set_model_no_conformal_ci(self) -> None:
        model = SetComfortModel()
        result = model.predict(ComfortInputs(**_PMV_KWARGS))
        assert result.conformal_ci_95 is None

    def test_adaptive_model_no_conformal_ci(self) -> None:
        from comfortkit.models.standard import AdaptiveASHRAEComfortModel
        model = AdaptiveASHRAEComfortModel()
        result = model.predict(ComfortInputs(**_PMV_KWARGS, t_running_mean=20.0))
        assert result.conformal_ci_95 is None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


class TestConformalCiPublicAPI:
    def test_predict_returns_conformal_ci_95(self) -> None:
        result = comfortkit.predict(model="pmv", **_PMV_KWARGS)
        assert hasattr(result, "conformal_ci_95")

    def test_iso_standard_also_has_conformal_ci(self) -> None:
        result = comfortkit.predict(
            model="pmv", standard="iso", **_PMV_KWARGS
        )
        assert hasattr(result, "conformal_ci_95")

    def test_batch_all_have_conformal_ci_95(self) -> None:
        inputs = [
            ComfortInputs(**_PMV_KWARGS),
            ComfortInputs(ta=22.0, tr=22.0, vel=0.1, rh=60.0, met=1.2, clo=0.5),
        ]
        results = comfortkit.predict_batch(inputs, model="pmv")
        for r in results:
            assert hasattr(r, "conformal_ci_95")


# ---------------------------------------------------------------------------
# Coverage validation (lightweight — no parquet dependency)
# ---------------------------------------------------------------------------


class TestConformalCiCoverage:
    """Validate that q gives correct interval structure."""

    def test_conformal_ci_95_wider_than_bootstrap_ci(self) -> None:
        model = StandardComfortModel()
        result = model.predict(ComfortInputs(**_PMV_KWARGS))
        if result.conformal_ci_95 is not None and result.ci_95 is not None:
            conformal_width = result.conformal_ci_95[1] - result.conformal_ci_95[0]
            bootstrap_width = result.ci_95[1] - result.ci_95[0]
            assert conformal_width > bootstrap_width

    def test_neutral_inputs_conformal_ci_near_zero(self) -> None:
        # ta=tr=25, comfortable conditions → PMV near 0
        model = StandardComfortModel()
        result = model.predict(ComfortInputs(**_PMV_KWARGS))
        if result.conformal_ci_95 is not None and result.pmv is not None:
            assert abs(result.pmv) < 1.0
            lo, hi = result.conformal_ci_95
            assert lo < 0 < hi  # CI straddles zero for near-neutral PMV
