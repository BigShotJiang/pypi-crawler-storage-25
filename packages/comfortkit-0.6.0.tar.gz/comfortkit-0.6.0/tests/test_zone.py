"""Tests for ZoneAggregator and POST /v1/zone/predict."""

from __future__ import annotations

import pathlib

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient

from api.routers.feedback import get_store
from api.store import SQLiteUserStore
from comfortkit.models.personal import PersonalPosterior
from comfortkit.models.zone import ZoneAggregator, ZoneComfortResult

BASE_URL = "http://testserver"


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _posterior(p_warm: float, p_cool: float = 0.0, n_votes: int = 20) -> PersonalPosterior:
    """Build a PersonalPosterior with specific P(Warm) and P(Cool) via direct alpha assignment."""
    total = 10.0
    alpha_warm = p_warm * total
    alpha_cool = p_cool * total
    alpha_neutral = max(0.001, total - alpha_warm - alpha_cool)
    return PersonalPosterior(alpha_warm=alpha_warm, alpha_neutral=alpha_neutral, alpha_cool=alpha_cool, n_votes=n_votes)


def _cold_posterior(p_cool: float = 0.8, n_votes: int = 20) -> PersonalPosterior:
    """Build a posterior dominated by P(Cool) — MAP prediction is -1 (Cool)."""
    return _posterior(p_warm=0.05, p_cool=p_cool, n_votes=n_votes)


def _prior_only() -> PersonalPosterior:
    return PersonalPosterior.from_prior()


@pytest_asyncio.fixture
async def zone_client(tmp_path: pathlib.Path) -> AsyncClient:
    from api.main import app

    test_store = SQLiteUserStore(tmp_path / "zone_test.db")
    app.dependency_overrides[get_store] = lambda: test_store
    async with AsyncClient(transport=ASGITransport(app=app), base_url=BASE_URL) as c:
        yield c
    app.dependency_overrides.clear()


@pytest_asyncio.fixture
async def zone_client_with_users(tmp_path: pathlib.Path) -> AsyncClient:
    """Client pre-seeded with alice (warm) and bob (neutral)."""
    from api.main import app

    store = SQLiteUserStore(tmp_path / "zone_seeded.db")
    # alice: strongly warm (20 warm votes)
    p_alice = PersonalPosterior.from_prior()
    for _ in range(20):
        p_alice.update(1)
    store.save_posterior("alice", p_alice)
    # bob: strongly neutral (20 neutral votes) — not cool-preferring
    p_bob = PersonalPosterior.from_prior()
    for _ in range(20):
        p_bob.update(0)
    store.save_posterior("bob", p_bob)

    app.dependency_overrides[get_store] = lambda: store
    async with AsyncClient(transport=ASGITransport(app=app), base_url=BASE_URL) as c:
        yield c
    app.dependency_overrides.clear()


# ===========================================================================
# ZoneAggregator — unit tests
# ===========================================================================


class TestZoneAggregatorInput:
    def test_empty_users_raises(self) -> None:
        agg = ZoneAggregator()
        with pytest.raises(ValueError, match="empty"):
            agg.predict({})

    def test_single_user_returns_result(self) -> None:
        agg = ZoneAggregator()
        result = agg.predict({"u1": _posterior(0.8)})
        assert isinstance(result, ZoneComfortResult)

    def test_single_user_warns(self) -> None:
        agg = ZoneAggregator()
        result = agg.predict({"u1": _posterior(0.8)})
        assert any("one user" in w.lower() for w in result.warnings)

    def test_n_users_matches_input(self) -> None:
        users = {f"u{i}": _posterior(0.5) for i in range(4)}
        result = ZoneAggregator().predict(users)
        assert result.n_users == 4

    def test_per_user_keys_match_input(self) -> None:
        users = {"alice": _posterior(0.7), "bob": _posterior(0.3)}
        result = ZoneAggregator().predict(users)
        assert set(result.per_user.keys()) == {"alice", "bob"}


class TestStrategyMeanPWarm:
    def test_majority_warm_lowers_setpoint(self) -> None:
        users = {"a": _posterior(0.8), "b": _posterior(0.7), "c": _posterior(0.6)}
        result = ZoneAggregator(strategy="mean_p_warm").predict(users)
        assert result.action == "lower_setpoint"

    def test_high_mean_p_cool_raises_setpoint(self) -> None:
        # mean_p_cool > 0.35 → raise_setpoint (three-class fix)
        users = {
            "a": _cold_posterior(0.7),
            "b": _cold_posterior(0.7),
            "c": _cold_posterior(0.7),
        }
        result = ZoneAggregator(strategy="mean_p_warm").predict(users)
        assert result.action == "raise_setpoint"

    def test_neutral_users_do_not_raise_setpoint(self) -> None:
        # Users with low p_warm but also low p_cool (neutral) → maintain
        # Key v0.5 correctness: neutral-heavy users must not trigger raise_setpoint
        users = {"a": _posterior(0.1), "b": _posterior(0.2), "c": _posterior(0.15)}
        result = ZoneAggregator(strategy="mean_p_warm").predict(users)
        assert result.action == "maintain"

    def test_balanced_maintains(self) -> None:
        users = {"a": _posterior(0.42), "b": _posterior(0.44)}
        result = ZoneAggregator(strategy="mean_p_warm").predict(users)
        assert result.action == "maintain"

    def test_mean_p_warm_is_average(self) -> None:
        users = {"a": _posterior(0.2), "b": _posterior(0.8)}
        result = ZoneAggregator(strategy="mean_p_warm").predict(users)
        assert result.mean_p_warm == pytest.approx(0.5, abs=0.01)

    def test_mean_p_cool_present(self) -> None:
        users = {"a": _cold_posterior(0.6), "b": _posterior(0.4)}
        result = ZoneAggregator(strategy="mean_p_warm").predict(users)
        assert result.mean_p_cool >= 0.0

    def test_strategy_field_is_correct(self) -> None:
        result = ZoneAggregator(strategy="mean_p_warm").predict({"u": _posterior(0.6)})
        assert result.strategy == "mean_p_warm"


class TestStrategyMajorityVote:
    def test_two_warm_one_neutral_lowers(self) -> None:
        # 2 warm, 1 neutral → n_warm=2 > 3/2 → lower_setpoint
        users = {"a": _posterior(0.8), "b": _posterior(0.7), "c": _posterior(0.1)}
        result = ZoneAggregator(strategy="majority_vote").predict(users)
        assert result.action == "lower_setpoint"

    def test_two_cool_one_warm_raises(self) -> None:
        # 2 cold-preferring users + 1 warm → n_cool=2 > 3/2 → raise_setpoint
        users = {
            "a": _cold_posterior(0.7),
            "b": _cold_posterior(0.7),
            "c": _posterior(0.9),
        }
        result = ZoneAggregator(strategy="majority_vote").predict(users)
        assert result.action == "raise_setpoint"

    def test_even_split_maintains(self) -> None:
        # 1 warm, 1 neutral: neither > 2/2 → maintain
        users = {"a": _posterior(0.8), "b": _posterior(0.1)}
        result = ZoneAggregator(strategy="majority_vote").predict(users)
        assert result.action == "maintain"

    def test_fraction_warm_reflects_majority(self) -> None:
        users = {"a": _posterior(0.9), "b": _posterior(0.9), "c": _posterior(0.1)}
        result = ZoneAggregator(strategy="majority_vote").predict(users)
        assert result.fraction_warm == pytest.approx(2 / 3, abs=0.01)


class TestStrategyAnyDiscomfort:
    def test_one_very_warm_triggers_lower(self) -> None:
        users = {"a": _posterior(0.75), "b": _posterior(0.3)}
        result = ZoneAggregator(strategy="any_discomfort").predict(users)
        assert result.action == "lower_setpoint"

    def test_one_very_cold_triggers_raise(self) -> None:
        users = {"a": _cold_posterior(0.75), "b": _posterior(0.3)}
        result = ZoneAggregator(strategy="any_discomfort").predict(users)
        assert result.action == "raise_setpoint"

    def test_all_below_threshold_maintains(self) -> None:
        users = {"a": _posterior(0.6), "b": _posterior(0.5)}
        result = ZoneAggregator(strategy="any_discomfort").predict(users)
        assert result.action == "maintain"

    def test_custom_threshold(self) -> None:
        users = {"a": _posterior(0.65)}
        result = ZoneAggregator(strategy="any_discomfort", any_discomfort_threshold=0.6).predict(users)
        assert result.action == "lower_setpoint"

    def test_neutral_users_do_not_raise_setpoint(self) -> None:
        # Neutral users have low p_warm AND low p_cool → neither threshold crossed
        users = {"a": _posterior(0.05), "b": _posterior(0.05)}
        result = ZoneAggregator(strategy="any_discomfort").predict(users)
        assert result.action == "maintain"

    def test_warm_beats_cold_when_both_exceed_threshold(self) -> None:
        # When both warm and cold users are present, warm signal takes priority
        users = {
            "a": _posterior(0.75),
            "b": _cold_posterior(0.75),
        }
        result = ZoneAggregator(strategy="any_discomfort").predict(users)
        assert result.action == "lower_setpoint"


class TestPerUserSummary:
    def test_warm_user_labelled_warm(self) -> None:
        result = ZoneAggregator().predict({"u": _posterior(0.9)})
        assert result.per_user["u"].prediction_label == "Warm"

    def test_neutral_user_labelled_neutral(self) -> None:
        # p_warm=0.1, p_cool=0 → predict=Neutral
        result = ZoneAggregator().predict({"u": _posterior(0.1)})
        assert result.per_user["u"].prediction_label == "Neutral"

    def test_cool_user_labelled_cool(self) -> None:
        result = ZoneAggregator().predict({"u": _cold_posterior(0.8)})
        assert result.per_user["u"].prediction_label == "Cool"

    def test_p_warm_rounded_to_4dp(self) -> None:
        result = ZoneAggregator().predict({"u": _posterior(1 / 3)})
        assert result.per_user["u"].p_warm == round(1 / 3, 4)

    def test_p_cool_present_in_summary(self) -> None:
        result = ZoneAggregator().predict({"u": _cold_posterior(0.6)})
        assert result.per_user["u"].p_cool > 0

    def test_n_votes_propagated(self) -> None:
        p = PersonalPosterior.from_prior()
        for _ in range(7):
            p.update(1)
        result = ZoneAggregator().predict({"u": p})
        assert result.per_user["u"].n_votes == 7


class TestConfidence:
    def test_low_confidence_below_10_votes(self) -> None:
        users = {"a": _posterior(0.6, n_votes=5), "b": _posterior(0.7, n_votes=8)}
        result = ZoneAggregator().predict(users)
        assert result.confidence == "low"

    def test_medium_confidence_10_to_49(self) -> None:
        users = {"a": _posterior(0.6, n_votes=15), "b": _posterior(0.7, n_votes=20)}
        result = ZoneAggregator().predict(users)
        assert result.confidence == "medium"

    def test_high_confidence_50_plus(self) -> None:
        users = {"a": _posterior(0.6, n_votes=60), "b": _posterior(0.7, n_votes=55)}
        result = ZoneAggregator().predict(users)
        assert result.confidence == "high"

    def test_all_prior_warns(self) -> None:
        users = {
            "a": PersonalPosterior.from_prior(),
            "b": PersonalPosterior.from_prior(),
        }
        result = ZoneAggregator().predict(users)
        assert any("prior" in w.lower() for w in result.warnings)


# ===========================================================================
# API endpoint — POST /v1/zone/predict
# ===========================================================================


class TestZonePredictEndpointBasic:
    async def test_unknown_users_return_200(self, zone_client: AsyncClient) -> None:
        resp = await zone_client.post(
            "/v1/zone/predict",
            json={"user_ids": ["unknown1", "unknown2"]},
        )
        assert resp.status_code == 200

    async def test_response_has_required_fields(self, zone_client: AsyncClient) -> None:
        resp = await zone_client.post(
            "/v1/zone/predict",
            json={"user_ids": ["u1", "u2"]},
        )
        body = resp.json()
        for field in ("action", "strategy", "mean_p_warm", "mean_p_cool",
                      "fraction_warm", "n_users", "per_user", "confidence"):
            assert field in body, f"missing field: {field}"

    async def test_n_users_matches_request(self, zone_client: AsyncClient) -> None:
        resp = await zone_client.post(
            "/v1/zone/predict",
            json={"user_ids": ["u1", "u2", "u3"]},
        )
        assert resp.json()["n_users"] == 3

    async def test_per_user_keys_match_request(self, zone_client: AsyncClient) -> None:
        resp = await zone_client.post(
            "/v1/zone/predict",
            json={"user_ids": ["alice", "bob"]},
        )
        body = resp.json()
        assert set(body["per_user"].keys()) == {"alice", "bob"}

    async def test_per_user_has_p_cool(self, zone_client: AsyncClient) -> None:
        resp = await zone_client.post(
            "/v1/zone/predict",
            json={"user_ids": ["u1"]},
        )
        assert "p_cool" in resp.json()["per_user"]["u1"]

    async def test_default_strategy_is_mean_p_warm(self, zone_client: AsyncClient) -> None:
        resp = await zone_client.post("/v1/zone/predict", json={"user_ids": ["u"]})
        assert resp.json()["strategy"] == "mean_p_warm"

    async def test_empty_user_ids_returns_422(self, zone_client: AsyncClient) -> None:
        resp = await zone_client.post("/v1/zone/predict", json={"user_ids": []})
        assert resp.status_code == 422

    async def test_invalid_strategy_returns_422(self, zone_client: AsyncClient) -> None:
        resp = await zone_client.post(
            "/v1/zone/predict",
            json={"user_ids": ["u"], "strategy": "bad_strategy"},
        )
        assert resp.status_code == 422


class TestZonePredictEndpointWithHistory:
    async def test_warm_user_lowers_setpoint(self, zone_client_with_users: AsyncClient) -> None:
        resp = await zone_client_with_users.post(
            "/v1/zone/predict",
            json={"user_ids": ["alice"]},
        )
        # alice has 20 warm votes → P(Warm) well above 0.5 → lower_setpoint
        assert resp.status_code == 200
        assert resp.json()["action"] == "lower_setpoint"

    async def test_mixed_zone_strategies_differ(self, zone_client_with_users: AsyncClient) -> None:
        # alice = warm, bob = neutral: strategies may disagree
        for strategy in ("mean_p_warm", "majority_vote", "any_discomfort"):
            resp = await zone_client_with_users.post(
                "/v1/zone/predict",
                json={"user_ids": ["alice", "bob"], "strategy": strategy},
            )
            assert resp.status_code == 200
            assert resp.json()["action"] in ("lower_setpoint", "raise_setpoint", "maintain")

    async def test_zone_temp_accepted(self, zone_client_with_users: AsyncClient) -> None:
        resp = await zone_client_with_users.post(
            "/v1/zone/predict",
            json={"user_ids": ["alice"], "zone_temp": 24.5},
        )
        assert resp.status_code == 200

    async def test_per_user_n_votes_propagated(self, zone_client_with_users: AsyncClient) -> None:
        resp = await zone_client_with_users.post(
            "/v1/zone/predict",
            json={"user_ids": ["alice"]},
        )
        assert resp.json()["per_user"]["alice"]["n_votes"] == 20
