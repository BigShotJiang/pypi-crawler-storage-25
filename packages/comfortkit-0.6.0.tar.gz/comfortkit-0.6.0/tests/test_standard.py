"""Adapter correctness tests: comfortkit vs pythermalcomfort + ISO 7730 reference cases."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from pythermalcomfort.models import pmv_ppd_ashrae  # type: ignore[import-untyped]

import comfortkit
from comfortkit.models.base import ComfortInputError, ComfortInputs
from comfortkit.models.standard import StandardComfortModel

FIXTURES = Path(__file__).parent / "fixtures"
PMV_TOL = 0.05
PPD_TOL = 1.0


@pytest.fixture(scope="module")
def model() -> StandardComfortModel:
    return StandardComfortModel()


@pytest.fixture(scope="module")
def iso_cases() -> list[dict]:  # type: ignore[type-arg]
    data = json.loads((FIXTURES / "iso_7730_reference.json").read_text())
    return data["cases"]


class TestParity:
    """comfortkit PMV/PPD must match pythermalcomfort to 2 decimal places."""

    @pytest.mark.parametrize(
        "ta,tr,vel,rh,met,clo",
        [
            (22.0, 22.0, 0.1, 60.0, 1.2, 0.5),
            (26.0, 26.0, 0.1, 50.0, 1.0, 0.5),
            (20.0, 20.0, 0.2, 40.0, 1.4, 1.0),
        ],
    )
    def test_pmv_matches_pythermalcomfort(
        self,
        model: StandardComfortModel,
        ta: float,
        tr: float,
        vel: float,
        rh: float,
        met: float,
        clo: float,
    ) -> None:
        inputs = ComfortInputs(ta=ta, tr=tr, vel=vel, rh=rh, met=met, clo=clo)
        result = model.predict(inputs)

        reference = pmv_ppd_ashrae(tdb=ta, tr=tr, vr=vel, rh=rh, met=met, clo=clo, limit_inputs=False)

        assert result.pmv is not None
        assert abs(result.pmv - round(float(reference.pmv), 2)) <= 0.01

    @pytest.mark.parametrize(
        "ta,tr,vel,rh,met,clo",
        [
            (22.0, 22.0, 0.1, 60.0, 1.2, 0.5),
            (26.0, 26.0, 0.1, 50.0, 1.0, 0.5),
        ],
    )
    def test_ppd_matches_pythermalcomfort(
        self,
        model: StandardComfortModel,
        ta: float,
        tr: float,
        vel: float,
        rh: float,
        met: float,
        clo: float,
    ) -> None:
        inputs = ComfortInputs(ta=ta, tr=tr, vel=vel, rh=rh, met=met, clo=clo)
        result = model.predict(inputs)

        reference = pmv_ppd_ashrae(tdb=ta, tr=tr, vr=vel, rh=rh, met=met, clo=clo, limit_inputs=False)

        assert result.ppd is not None
        assert abs(result.ppd - round(float(reference.ppd), 2)) <= 0.01


class TestISO7730ReferenceCase:
    """End-to-end sanity check against ISO 7730:2005 Annex D."""

    def test_all_reference_cases(
        self, model: StandardComfortModel, iso_cases: list[dict]  # type: ignore[type-arg]
    ) -> None:
        for case in iso_cases:
            inputs = ComfortInputs(**case["inputs"])
            result = model.predict(inputs)

            assert result.pmv is not None, f"Case {case['id']}: PMV is None"
            assert result.ppd is not None, f"Case {case['id']}: PPD is None"
            assert abs(result.pmv - case["expected"]["pmv"]) <= PMV_TOL, (
                f"Case {case['id']}: PMV {result.pmv} vs expected {case['expected']['pmv']}"
            )
            assert abs(result.ppd - case["expected"]["ppd"]) <= PPD_TOL, (
                f"Case {case['id']}: PPD {result.ppd} vs expected {case['expected']['ppd']}"
            )


class TestValidation:
    """ComfortInputError raised for physically impossible inputs."""

    def test_negative_velocity_raises(self) -> None:
        with pytest.raises(Exception):  # pydantic ValidationError wraps ComfortInputError
            ComfortInputs(ta=22, tr=22, vel=-0.1, rh=60, met=1.2, clo=0.5)

    def test_rh_over_100_raises(self) -> None:
        with pytest.raises(Exception):
            ComfortInputs(ta=22, tr=22, vel=0.1, rh=101, met=1.2, clo=0.5)

    def test_zero_met_raises(self) -> None:
        with pytest.raises(Exception):
            ComfortInputs(ta=22, tr=22, vel=0.1, rh=60, met=0, clo=0.5)

    def test_negative_clo_raises(self) -> None:
        with pytest.raises(Exception):
            ComfortInputs(ta=22, tr=22, vel=0.1, rh=60, met=1.2, clo=-0.1)


class TestApplicabilityWarnings:
    """Out-of-range inputs produce warnings, not exceptions."""

    def test_high_temp_produces_warning(self, model: StandardComfortModel) -> None:
        inputs = ComfortInputs(ta=45, tr=45, vel=0.1, rh=60, met=1.2, clo=0.5)
        result = model.predict(inputs)
        assert any("ta" in w for w in result.warnings)

    def test_in_range_inputs_no_warnings(self, model: StandardComfortModel) -> None:
        inputs = ComfortInputs(ta=22, tr=22, vel=0.1, rh=50, met=1.2, clo=0.5)
        result = model.predict(inputs)
        assert result.warnings == []


class TestCI95:
    """ci_95 is populated on every predict() and predict_batch() call."""

    def test_ci95_is_tuple_of_two_floats(self, model: StandardComfortModel) -> None:
        inputs = ComfortInputs(ta=22, tr=22, vel=0.1, rh=50, met=1.2, clo=0.5)
        result = model.predict(inputs)
        assert result.ci_95 is not None
        lo, hi = result.ci_95
        assert isinstance(lo, float) and isinstance(hi, float)

    def test_ci95_lower_le_upper(self, model: StandardComfortModel) -> None:
        inputs = ComfortInputs(ta=22, tr=22, vel=0.1, rh=50, met=1.2, clo=0.5)
        result = model.predict(inputs)
        assert result.ci_95 is not None
        assert result.ci_95[0] <= result.ci_95[1]

    def test_ci95_brackets_pmv(self, model: StandardComfortModel) -> None:
        inputs = ComfortInputs(ta=22, tr=22, vel=0.1, rh=50, met=1.2, clo=0.5)
        result = model.predict(inputs)
        assert result.pmv is not None and result.ci_95 is not None
        lo, hi = result.ci_95
        assert lo <= result.pmv <= hi

    def test_ci95_populated_in_batch(self, model: StandardComfortModel) -> None:
        inputs = [
            ComfortInputs(ta=22, tr=22, vel=0.1, rh=60, met=1.2, clo=0.5),
            ComfortInputs(ta=26, tr=26, vel=0.2, rh=50, met=1.0, clo=0.5),
        ]
        for result in model.predict_batch(inputs):
            assert result.ci_95 is not None
            assert result.ci_95[0] <= result.ci_95[1]


class TestBatchPredict:
    def test_batch_returns_correct_count(self, model: StandardComfortModel) -> None:
        inputs = [
            ComfortInputs(ta=22, tr=22, vel=0.1, rh=60, met=1.2, clo=0.5),
            ComfortInputs(ta=26, tr=26, vel=0.2, rh=50, met=1.0, clo=0.5),
        ]
        results = model.predict_batch(inputs)
        assert len(results) == 2

    def test_batch_matches_individual(self, model: StandardComfortModel) -> None:
        inputs = [
            ComfortInputs(ta=22, tr=22, vel=0.1, rh=60, met=1.2, clo=0.5),
            ComfortInputs(ta=26, tr=26, vel=0.2, rh=50, met=1.0, clo=0.5),
        ]
        batch = model.predict_batch(inputs)
        individual = [model.predict(inp) for inp in inputs]
        for b, i in zip(batch, individual):
            assert b.pmv == i.pmv
            assert b.ppd == i.ppd


class TestPublicPredict:
    """comfortkit.predict() supports both calling styles."""

    _KWARGS = dict(ta=22.0, tr=22.0, vel=0.1, rh=60.0, met=1.2, clo=0.5)

    # --- style 1: keyword arguments ---

    def test_kwargs_style_returns_result(self) -> None:
        result = comfortkit.predict(model="pmv", **self._KWARGS)
        assert result.pmv is not None
        assert result.ppd is not None

    def test_kwargs_style_default_model(self) -> None:
        result = comfortkit.predict(**self._KWARGS)
        assert result.model == "standard_pmv"

    def test_kwargs_style_pmv_value(self) -> None:
        result = comfortkit.predict(**self._KWARGS)
        assert result.pmv is not None
        assert abs(result.pmv - (-0.75)) <= 0.05

    def test_kwargs_style_ci95_populated(self) -> None:
        result = comfortkit.predict(**self._KWARGS)
        assert result.ci_95 is not None
        assert result.ci_95[0] <= result.ci_95[1]

    def test_kwargs_style_standard_iso(self) -> None:
        result = comfortkit.predict(standard="iso", **self._KWARGS)
        assert result.pmv is not None

    def test_kwargs_missing_field_raises_type_error(self) -> None:
        with pytest.raises(TypeError, match="missing required keyword argument"):
            comfortkit.predict(ta=22.0, tr=22.0)  # vel, rh, met, clo missing

    # --- style 2: ComfortInputs object ---

    def test_object_style_returns_result(self) -> None:
        inputs = ComfortInputs(**self._KWARGS)
        result = comfortkit.predict(inputs, model="pmv")
        assert result.pmv is not None

    def test_object_style_default_model(self) -> None:
        inputs = ComfortInputs(**self._KWARGS)
        result = comfortkit.predict(inputs)
        assert result.model == "standard_pmv"

    def test_object_style_ci95_populated(self) -> None:
        inputs = ComfortInputs(**self._KWARGS)
        result = comfortkit.predict(inputs)
        assert result.ci_95 is not None
        assert result.ci_95[0] <= result.ci_95[1]

    # --- both styles agree on pmv/ppd ---

    def test_both_styles_same_pmv(self) -> None:
        r_kwargs = comfortkit.predict(**self._KWARGS)
        r_object = comfortkit.predict(ComfortInputs(**self._KWARGS))
        assert r_kwargs.pmv == r_object.pmv
        assert r_kwargs.ppd == r_object.ppd

    # --- model alias ---

    def test_pmv_alias_resolves(self) -> None:
        result = comfortkit.predict(model="pmv", **self._KWARGS)
        assert result.model == "standard_pmv"

    def test_unknown_model_raises(self) -> None:
        with pytest.raises(KeyError):
            comfortkit.predict(model="nonexistent", **self._KWARGS)

    # --- predict_batch with model kwarg ---

    def test_predict_batch_model_kwarg(self) -> None:
        inputs = [ComfortInputs(**self._KWARGS), ComfortInputs(**self._KWARGS)]
        results = comfortkit.predict_batch(inputs, model="pmv")
        assert len(results) == 2
        assert all(r.pmv is not None for r in results)
