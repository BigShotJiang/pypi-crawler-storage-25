"""Tests for SetComfortModel and AdaptiveASHRAEComfortModel."""

from __future__ import annotations

import pytest
from pythermalcomfort.models import adaptive_ashrae  # type: ignore[import-untyped]
from pythermalcomfort.models import set_tmp  # type: ignore[import-untyped]

import comfortkit
from comfortkit.models.base import ComfortInputError, ComfortInputs, ComfortResult
from comfortkit.models.standard import AdaptiveASHRAEComfortModel, SetComfortModel

# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------

_PMV_KWARGS = dict(ta=25.0, tr=25.0, vel=0.1, rh=50.0, met=1.2, clo=0.5)


@pytest.fixture(scope="module")
def set_model() -> SetComfortModel:
    return SetComfortModel()


@pytest.fixture(scope="module")
def adaptive_model() -> AdaptiveASHRAEComfortModel:
    return AdaptiveASHRAEComfortModel()


# ===========================================================================
# SET — SetComfortModel
# ===========================================================================


class TestSetModelBasics:
    def test_model_id(self) -> None:
        assert SetComfortModel.MODEL_ID == "set"

    def test_registered(self) -> None:
        assert "set" in comfortkit.list_models()

    def test_returns_comfort_result(self, set_model: SetComfortModel) -> None:
        result = set_model.predict(ComfortInputs(**_PMV_KWARGS))
        assert isinstance(result, ComfortResult)

    def test_model_field(self, set_model: SetComfortModel) -> None:
        result = set_model.predict(ComfortInputs(**_PMV_KWARGS))
        assert result.model == "set"

    def test_pmv_ppd_are_none(self, set_model: SetComfortModel) -> None:
        result = set_model.predict(ComfortInputs(**_PMV_KWARGS))
        assert result.pmv is None
        assert result.ppd is None

    def test_set_tmp_is_float(self, set_model: SetComfortModel) -> None:
        result = set_model.predict(ComfortInputs(**_PMV_KWARGS))
        assert result.set_tmp is not None
        assert isinstance(result.set_tmp, float)

    def test_ci95_is_none(self, set_model: SetComfortModel) -> None:
        result = set_model.predict(ComfortInputs(**_PMV_KWARGS))
        assert result.ci_95 is None

    def test_sensation_is_string(self, set_model: SetComfortModel) -> None:
        result = set_model.predict(ComfortInputs(**_PMV_KWARGS))
        assert isinstance(result.sensation, str)
        assert len(result.sensation) > 0

    def test_warnings_list(self, set_model: SetComfortModel) -> None:
        result = set_model.predict(ComfortInputs(**_PMV_KWARGS))
        assert isinstance(result.warnings, list)


class TestSetParity:
    """SET value must match pythermalcomfort to 2 decimal places."""

    @pytest.mark.parametrize(
        "ta,tr,vel,rh,met,clo,expected_set",
        [
            (25.0, 25.0, 0.1, 50.0, 1.2, 0.5, 24.3),
            (22.0, 22.0, 0.1, 60.0, 1.2, 0.5, 21.4),
            (30.0, 30.0, 0.2, 60.0, 1.2, 0.5, 30.2),
        ],
    )
    def test_set_matches_pythermalcomfort(
        self,
        set_model: SetComfortModel,
        ta: float,
        tr: float,
        vel: float,
        rh: float,
        met: float,
        clo: float,
        expected_set: float,
    ) -> None:
        result = set_model.predict(
            ComfortInputs(ta=ta, tr=tr, vel=vel, rh=rh, met=met, clo=clo)
        )
        assert result.set_tmp is not None
        assert abs(result.set_tmp - expected_set) <= 0.01


class TestSetSensationAndCompliance:
    def test_comfortable_inputs_neutral(self, set_model: SetComfortModel) -> None:
        # SET=24.3 → neutral, compliant
        result = set_model.predict(ComfortInputs(**_PMV_KWARGS))
        assert result.sensation == "neutral"
        assert result.compliant is True

    def test_cool_inputs_sensation(self, set_model: SetComfortModel) -> None:
        # ta=22 → SET=21.4 → slightly cool, not compliant
        result = set_model.predict(
            ComfortInputs(ta=22.0, tr=22.0, vel=0.1, rh=60.0, met=1.2, clo=0.5)
        )
        assert result.sensation == "slightly cool"
        assert result.compliant is False

    def test_hot_inputs_sensation(self, set_model: SetComfortModel) -> None:
        # ta=30 → SET=30.2 → warm/hot, not compliant
        result = set_model.predict(
            ComfortInputs(ta=30.0, tr=30.0, vel=0.2, rh=60.0, met=1.2, clo=0.5)
        )
        assert result.sensation in ("slightly warm", "warm", "hot")
        assert result.compliant is False

    def test_out_of_range_produces_warning(self, set_model: SetComfortModel) -> None:
        result = set_model.predict(
            ComfortInputs(ta=45.0, tr=45.0, vel=0.1, rh=50.0, met=1.2, clo=0.5)
        )
        assert any("ta" in w for w in result.warnings)

    def test_in_range_no_warnings(self, set_model: SetComfortModel) -> None:
        result = set_model.predict(ComfortInputs(**_PMV_KWARGS))
        assert result.warnings == []


class TestSetBatch:
    def test_batch_count(self, set_model: SetComfortModel) -> None:
        inputs = [ComfortInputs(**_PMV_KWARGS), ComfortInputs(**_PMV_KWARGS)]
        assert len(set_model.predict_batch(inputs)) == 2

    def test_batch_matches_individual(self, set_model: SetComfortModel) -> None:
        inputs = [
            ComfortInputs(**_PMV_KWARGS),
            ComfortInputs(ta=22.0, tr=22.0, vel=0.1, rh=60.0, met=1.2, clo=0.5),
        ]
        batch = set_model.predict_batch(inputs)
        individual = [set_model.predict(i) for i in inputs]
        for b, ind in zip(batch, individual):
            assert b.set_tmp == ind.set_tmp
            assert b.sensation == ind.sensation


class TestSetPublicAPI:
    def test_predict_model_set(self) -> None:
        result = comfortkit.predict(model="set", **_PMV_KWARGS)
        assert result.model == "set"
        assert result.set_tmp is not None

    def test_predict_batch_model_set(self) -> None:
        inputs = [ComfortInputs(**_PMV_KWARGS)]
        results = comfortkit.predict_batch(inputs, model="set")
        assert len(results) == 1
        assert results[0].model == "set"


# ===========================================================================
# Adaptive ASHRAE 55 — AdaptiveASHRAEComfortModel
# ===========================================================================


class TestAdaptiveModelBasics:
    def test_model_id(self) -> None:
        assert AdaptiveASHRAEComfortModel.MODEL_ID == "adaptive_ashrae"

    def test_registered(self) -> None:
        assert "adaptive_ashrae" in comfortkit.list_models()

    def test_returns_comfort_result(
        self, adaptive_model: AdaptiveASHRAEComfortModel
    ) -> None:
        inputs = ComfortInputs(**_PMV_KWARGS, t_running_mean=20.0)
        assert isinstance(adaptive_model.predict(inputs), ComfortResult)

    def test_model_field(self, adaptive_model: AdaptiveASHRAEComfortModel) -> None:
        inputs = ComfortInputs(**_PMV_KWARGS, t_running_mean=20.0)
        assert adaptive_model.predict(inputs).model == "adaptive_ashrae"

    def test_pmv_ppd_are_none(self, adaptive_model: AdaptiveASHRAEComfortModel) -> None:
        inputs = ComfortInputs(**_PMV_KWARGS, t_running_mean=20.0)
        result = adaptive_model.predict(inputs)
        assert result.pmv is None
        assert result.ppd is None

    def test_ci95_is_none(self, adaptive_model: AdaptiveASHRAEComfortModel) -> None:
        inputs = ComfortInputs(**_PMV_KWARGS, t_running_mean=20.0)
        assert adaptive_model.predict(inputs).ci_95 is None

    def test_set_tmp_is_none(self, adaptive_model: AdaptiveASHRAEComfortModel) -> None:
        inputs = ComfortInputs(**_PMV_KWARGS, t_running_mean=20.0)
        assert adaptive_model.predict(inputs).set_tmp is None


class TestAdaptiveMissingTRunningMean:
    def test_missing_t_running_mean_raises(
        self, adaptive_model: AdaptiveASHRAEComfortModel
    ) -> None:
        inputs = ComfortInputs(**_PMV_KWARGS)  # t_running_mean=None
        with pytest.raises(ComfortInputError, match="t_running_mean"):
            adaptive_model.predict(inputs)

    def test_error_message_is_helpful(
        self, adaptive_model: AdaptiveASHRAEComfortModel
    ) -> None:
        inputs = ComfortInputs(**_PMV_KWARGS)
        with pytest.raises(ComfortInputError, match="adaptive_ashrae"):
            adaptive_model.predict(inputs)


class TestAdaptiveCompliance:
    def test_comfortable_is_compliant(
        self, adaptive_model: AdaptiveASHRAEComfortModel
    ) -> None:
        # tdb=25, t_rm=20 → within 80% zone
        inputs = ComfortInputs(ta=25.0, tr=25.0, vel=0.1, rh=50.0,
                               met=1.2, clo=0.5, t_running_mean=20.0)
        result = adaptive_model.predict(inputs)
        assert result.compliant is True
        assert result.sensation == "neutral"

    def test_cold_outdoor_acceptability(
        self, adaptive_model: AdaptiveASHRAEComfortModel
    ) -> None:
        # tdb=16, t_rm=12 → likely outside zone, cool sensation
        inputs = ComfortInputs(ta=16.0, tr=16.0, vel=0.1, rh=50.0,
                               met=1.2, clo=0.5, t_running_mean=12.0)
        result = adaptive_model.predict(inputs)
        assert result.sensation in ("cool", "neutral")

    def test_t_running_mean_out_of_range_warning(
        self, adaptive_model: AdaptiveASHRAEComfortModel
    ) -> None:
        inputs = ComfortInputs(**_PMV_KWARGS, t_running_mean=5.0)
        result = adaptive_model.predict(inputs)
        assert any("t_running_mean" in w for w in result.warnings)

    def test_t_running_mean_in_range_no_warning(
        self, adaptive_model: AdaptiveASHRAEComfortModel
    ) -> None:
        inputs = ComfortInputs(**_PMV_KWARGS, t_running_mean=20.0)
        result = adaptive_model.predict(inputs)
        assert result.warnings == []


class TestAdaptiveParity:
    """Compliance flag matches pythermalcomfort when CE is correctly applied."""

    @pytest.mark.parametrize(
        "ta,tr,t_rm,vel,expected_compliant",
        [
            (25.0, 25.0, 20.0, 0.1, True),   # still air, base_upper=24.0 >= ... wait: t_cmf=24.0, base_upper=27.5 > 25
            (30.0, 30.0, 28.0, 0.1, True),
            (35.0, 35.0, 20.0, 0.1, False),
        ],
    )
    def test_compliance_matches_pythermalcomfort_low_vel(
        self,
        adaptive_model: AdaptiveASHRAEComfortModel,
        ta: float,
        tr: float,
        t_rm: float,
        vel: float,
        expected_compliant: bool,
    ) -> None:
        ref = adaptive_ashrae(tdb=ta, tr=tr, t_running_mean=t_rm,
                              v=vel, limit_inputs=False)
        inputs = ComfortInputs(ta=ta, tr=tr, vel=vel, rh=50.0,
                               met=1.2, clo=0.5, t_running_mean=t_rm)
        result = adaptive_model.predict(inputs)
        assert result.compliant == bool(ref.acceptability_80)


class TestAdaptiveCEFix:
    """CE correction: cooling effect suppressed when base upper boundary < 25 °C."""

    def test_ce_not_applied_when_base_upper_below_25(
        self, adaptive_model: AdaptiveASHRAEComfortModel
    ) -> None:
        # t_rm=10 → t_cmf=20.9, base_upper_80=24.4 < 25
        # v=0.8 → pythermalcomfort would apply CE; comfortkit should not
        inputs = ComfortInputs(ta=25.0, tr=25.0, vel=0.8, rh=50.0,
                               met=1.2, clo=0.5, t_running_mean=10.0)
        result = adaptive_model.predict(inputs)
        assert result.compliant is False
        assert any("suppressed" in w for w in result.warnings)

    def test_pythermalcomfort_gives_wrong_result_for_same_inputs(self) -> None:
        # Document the divergence: pythermalcomfort says True, corrected says False.
        ref = adaptive_ashrae(tdb=25, tr=25, t_running_mean=10, v=0.8,
                              limit_inputs=False)
        assert bool(ref.acceptability_80) is True  # pythermalcomfort bug

    def test_ce_applied_when_base_upper_equals_25(
        self, adaptive_model: AdaptiveASHRAEComfortModel
    ) -> None:
        # t_rm=12 → t_cmf=21.5, base_upper_80=25.0 == 25 → CE should apply
        inputs = ComfortInputs(ta=26.0, tr=26.0, vel=0.8, rh=50.0,
                               met=1.2, clo=0.5, t_running_mean=12.0)
        result = adaptive_model.predict(inputs)
        assert not any("suppressed" in w for w in result.warnings)

    def test_ce_applied_when_base_upper_above_25(
        self, adaptive_model: AdaptiveASHRAEComfortModel
    ) -> None:
        # t_rm=14 → t_cmf=22.1, base_upper_80=25.6 > 25 → CE should apply
        inputs = ComfortInputs(ta=26.0, tr=26.0, vel=0.8, rh=50.0,
                               met=1.2, clo=0.5, t_running_mean=14.0)
        result = adaptive_model.predict(inputs)
        assert not any("suppressed" in w for w in result.warnings)

    def test_still_air_no_ce_no_warning(
        self, adaptive_model: AdaptiveASHRAEComfortModel
    ) -> None:
        # v=0.1 → no CE regardless of boundary
        inputs = ComfortInputs(ta=25.0, tr=25.0, vel=0.1, rh=50.0,
                               met=1.2, clo=0.5, t_running_mean=10.0)
        result = adaptive_model.predict(inputs)
        assert not any("suppressed" in w for w in result.warnings)


class TestAdaptiveBatch:
    def test_batch_count(self, adaptive_model: AdaptiveASHRAEComfortModel) -> None:
        inputs = [
            ComfortInputs(**_PMV_KWARGS, t_running_mean=20.0),
            ComfortInputs(**_PMV_KWARGS, t_running_mean=25.0),
        ]
        assert len(adaptive_model.predict_batch(inputs)) == 2

    def test_batch_matches_individual(
        self, adaptive_model: AdaptiveASHRAEComfortModel
    ) -> None:
        inputs = [
            ComfortInputs(**_PMV_KWARGS, t_running_mean=20.0),
            ComfortInputs(ta=28.0, tr=28.0, vel=0.1, rh=50.0,
                          met=1.2, clo=0.5, t_running_mean=25.0),
        ]
        batch = adaptive_model.predict_batch(inputs)
        individual = [adaptive_model.predict(i) for i in inputs]
        for b, ind in zip(batch, individual):
            assert b.compliant == ind.compliant
            assert b.sensation == ind.sensation


class TestAdaptivePublicAPI:
    def test_predict_model_adaptive_ashrae(self) -> None:
        inputs = ComfortInputs(**_PMV_KWARGS, t_running_mean=20.0)
        result = comfortkit.predict(inputs, model="adaptive_ashrae")
        assert result.model == "adaptive_ashrae"

    def test_predict_model_adaptive_alias(self) -> None:
        inputs = ComfortInputs(**_PMV_KWARGS, t_running_mean=20.0)
        result = comfortkit.predict(inputs, model="adaptive")
        assert result.model == "adaptive_ashrae"

    def test_predict_batch_adaptive(self) -> None:
        inputs = [
            ComfortInputs(**_PMV_KWARGS, t_running_mean=20.0),
            ComfortInputs(**_PMV_KWARGS, t_running_mean=25.0),
        ]
        results = comfortkit.predict_batch(inputs, model="adaptive")
        assert len(results) == 2
        assert all(r.model == "adaptive_ashrae" for r in results)
