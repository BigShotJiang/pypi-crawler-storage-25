"""Tests for CoolingEffectModel (ASHRAE 55 Appendix G elevated air speed)."""

from __future__ import annotations

import pytest
from pythermalcomfort.models import cooling_effect as _ptc_ce  # type: ignore[import-untyped]
from pythermalcomfort.models import pmv_ppd_ashrae  # type: ignore[import-untyped]

import comfortkit
from comfortkit.models.base import ComfortInputs, ComfortResult
from comfortkit.models.standard import CoolingEffectModel

# ---------------------------------------------------------------------------
# Shared fixtures / constants
# ---------------------------------------------------------------------------

# Warm room with ceiling fan at vr=0.6 m/s — CE=3.05, PMV=0.14
_WARM_FAN = dict(ta=28.0, tr=28.0, vel=0.6, rh=60.0, met=1.2, clo=0.5)

# Comfortable room with gentle fan at vr=0.3 m/s — CE=1.73, PMV=-0.13
_MILD_FAN = dict(ta=26.0, tr=26.0, vel=0.3, rh=50.0, met=1.2, clo=0.5)

# Still air — vel at threshold, CE=0.0
_STILL_AIR = dict(ta=24.0, tr=24.0, vel=0.1, rh=50.0, met=1.2, clo=0.5)

# Hot room with strong fan at vr=1.0 m/s — CE=3.89, PMV=0.49
_HOT_FAN = dict(ta=30.0, tr=30.0, vel=1.0, rh=60.0, met=1.2, clo=0.5)


@pytest.fixture(scope="module")
def model() -> CoolingEffectModel:
    return CoolingEffectModel()


# ===========================================================================
# Identity and registration
# ===========================================================================


class TestModelIdentity:
    def test_model_id(self) -> None:
        assert CoolingEffectModel.MODEL_ID == "cooling_effect"

    def test_registered(self) -> None:
        assert "cooling_effect" in comfortkit.list_models()

    def test_predict_returns_comfort_result(self, model: CoolingEffectModel) -> None:
        result = model.predict(ComfortInputs(**_WARM_FAN))
        assert isinstance(result, ComfortResult)

    def test_model_field(self, model: CoolingEffectModel) -> None:
        result = model.predict(ComfortInputs(**_WARM_FAN))
        assert result.model == "cooling_effect"


# ===========================================================================
# Cooling Effect value
# ===========================================================================


class TestCoolingEffectValue:
    def test_ce_is_float(self, model: CoolingEffectModel) -> None:
        result = model.predict(ComfortInputs(**_WARM_FAN))
        assert result.cooling_effect is not None
        assert isinstance(result.cooling_effect, float)

    def test_ce_positive_above_threshold(self, model: CoolingEffectModel) -> None:
        result = model.predict(ComfortInputs(**_WARM_FAN))
        assert result.cooling_effect > 0.0

    def test_ce_zero_at_threshold(self, model: CoolingEffectModel) -> None:
        result = model.predict(ComfortInputs(**_STILL_AIR))
        assert result.cooling_effect == 0.0

    def test_ce_zero_below_threshold(self, model: CoolingEffectModel) -> None:
        inputs = {**_STILL_AIR, "vel": 0.05}
        result = model.predict(ComfortInputs(**inputs))
        assert result.cooling_effect == 0.0

    def test_ce_increases_with_air_speed(self, model: CoolingEffectModel) -> None:
        r_low = model.predict(ComfortInputs(**dict(_WARM_FAN, vel=0.3)))
        r_high = model.predict(ComfortInputs(**dict(_WARM_FAN, vel=0.9)))
        assert r_high.cooling_effect > r_low.cooling_effect

    def test_ce_parity_with_pythermalcomfort(self, model: CoolingEffectModel) -> None:
        """CE value must match pythermalcomfort.models.cooling_effect directly."""
        inputs = ComfortInputs(**_WARM_FAN)
        expected = round(
            float(_ptc_ce(tdb=inputs.ta, tr=inputs.tr, vr=inputs.vel,
                          rh=inputs.rh, met=inputs.met, clo=inputs.clo).ce),
            2,
        )
        assert model.predict(inputs).cooling_effect == pytest.approx(expected)

    def test_ce_warm_fan_reference(self, model: CoolingEffectModel) -> None:
        result = model.predict(ComfortInputs(**_WARM_FAN))
        assert result.cooling_effect == pytest.approx(3.05, abs=0.05)

    def test_ce_mild_fan_reference(self, model: CoolingEffectModel) -> None:
        result = model.predict(ComfortInputs(**_MILD_FAN))
        assert result.cooling_effect == pytest.approx(1.73, abs=0.05)

    def test_ce_hot_fan_reference(self, model: CoolingEffectModel) -> None:
        result = model.predict(ComfortInputs(**_HOT_FAN))
        assert result.cooling_effect == pytest.approx(3.89, abs=0.05)


# ===========================================================================
# PMV / PPD — parity with pythermalcomfort
# ===========================================================================


class TestPMVParity:
    def test_pmv_is_float(self, model: CoolingEffectModel) -> None:
        result = model.predict(ComfortInputs(**_WARM_FAN))
        assert result.pmv is not None
        assert isinstance(result.pmv, float)

    def test_ppd_is_float(self, model: CoolingEffectModel) -> None:
        result = model.predict(ComfortInputs(**_WARM_FAN))
        assert result.ppd is not None
        assert isinstance(result.ppd, float)

    def test_pmv_parity_with_pythermalcomfort(self, model: CoolingEffectModel) -> None:
        inputs = ComfortInputs(**_WARM_FAN)
        expected_pmv = round(
            float(pmv_ppd_ashrae(tdb=inputs.ta, tr=inputs.tr, vr=inputs.vel,
                                 rh=inputs.rh, met=inputs.met, clo=inputs.clo,
                                 limit_inputs=False).pmv),
            2,
        )
        assert model.predict(inputs).pmv == pytest.approx(expected_pmv)

    def test_ppd_parity_with_pythermalcomfort(self, model: CoolingEffectModel) -> None:
        inputs = ComfortInputs(**_WARM_FAN)
        expected_ppd = round(
            float(pmv_ppd_ashrae(tdb=inputs.ta, tr=inputs.tr, vr=inputs.vel,
                                 rh=inputs.rh, met=inputs.met, clo=inputs.clo,
                                 limit_inputs=False).ppd),
            2,
        )
        assert model.predict(inputs).ppd == pytest.approx(expected_ppd)

    def test_pmv_warm_fan_reference(self, model: CoolingEffectModel) -> None:
        result = model.predict(ComfortInputs(**_WARM_FAN))
        assert result.pmv == pytest.approx(0.14, abs=0.05)

    def test_pmv_hot_fan_reference(self, model: CoolingEffectModel) -> None:
        result = model.predict(ComfortInputs(**_HOT_FAN))
        assert result.pmv == pytest.approx(0.49, abs=0.05)


# ===========================================================================
# Sensation, compliance, CI
# ===========================================================================


class TestSensationCompliance:
    def test_sensation_is_string(self, model: CoolingEffectModel) -> None:
        result = model.predict(ComfortInputs(**_WARM_FAN))
        assert isinstance(result.sensation, str)
        assert len(result.sensation) > 0

    def test_warm_fan_sensation_neutral(self, model: CoolingEffectModel) -> None:
        result = model.predict(ComfortInputs(**_WARM_FAN))
        assert result.sensation == "neutral"

    def test_compliant_within_comfort_zone(self, model: CoolingEffectModel) -> None:
        result = model.predict(ComfortInputs(**_WARM_FAN))
        assert result.compliant is True

    def test_compliant_hot_room(self, model: CoolingEffectModel) -> None:
        # ta=30, vr=1.0 → PMV=0.49 — still within ±0.5
        result = model.predict(ComfortInputs(**_HOT_FAN))
        assert result.compliant is True

    def test_ci95_is_populated(self, model: CoolingEffectModel) -> None:
        result = model.predict(ComfortInputs(**_WARM_FAN))
        assert result.ci_95 is not None
        lo, hi = result.ci_95
        assert lo < hi

    def test_set_tmp_is_none(self, model: CoolingEffectModel) -> None:
        result = model.predict(ComfortInputs(**_WARM_FAN))
        assert result.set_tmp is None


# ===========================================================================
# Warnings
# ===========================================================================


class TestWarnings:
    def test_no_warning_above_threshold(self, model: CoolingEffectModel) -> None:
        result = model.predict(ComfortInputs(**_WARM_FAN))
        assert not any("threshold" in w for w in result.warnings)

    def test_warning_at_threshold(self, model: CoolingEffectModel) -> None:
        result = model.predict(ComfortInputs(**_STILL_AIR))
        assert any("threshold" in w for w in result.warnings)

    def test_warning_below_threshold(self, model: CoolingEffectModel) -> None:
        result = model.predict(ComfortInputs(ta=24, tr=24, vel=0.05, rh=50, met=1.2, clo=0.5))
        assert any("threshold" in w for w in result.warnings)

    def test_warnings_is_list(self, model: CoolingEffectModel) -> None:
        result = model.predict(ComfortInputs(**_WARM_FAN))
        assert isinstance(result.warnings, list)


# ===========================================================================
# Batch prediction
# ===========================================================================


class TestBatchPrediction:
    def test_batch_returns_list(self, model: CoolingEffectModel) -> None:
        inputs = [ComfortInputs(**_WARM_FAN), ComfortInputs(**_MILD_FAN)]
        results = model.predict_batch(inputs)
        assert isinstance(results, list)
        assert len(results) == 2

    def test_batch_matches_single(self, model: CoolingEffectModel) -> None:
        cases = [_WARM_FAN, _MILD_FAN, _HOT_FAN]
        inputs = [ComfortInputs(**c) for c in cases]
        batch = model.predict_batch(inputs)
        single = [model.predict(inp) for inp in inputs]
        for b, s in zip(batch, single):
            assert b.pmv == s.pmv
            assert b.cooling_effect == s.cooling_effect

    def test_batch_ce_varies_with_air_speed(self, model: CoolingEffectModel) -> None:
        speeds = [0.2, 0.4, 0.6, 0.8]
        inputs = [ComfortInputs(ta=28, tr=28, vel=v, rh=60, met=1.2, clo=0.5) for v in speeds]
        results = model.predict_batch(inputs)
        ce_values = [r.cooling_effect for r in results]
        assert ce_values == sorted(ce_values)


# ===========================================================================
# Public API integration
# ===========================================================================


class TestPublicAPI:
    def test_predict_via_comfortkit_module(self) -> None:
        result = comfortkit.predict(model="cooling_effect", **_WARM_FAN)
        assert isinstance(result, ComfortResult)
        assert result.cooling_effect is not None

    def test_predict_batch_via_comfortkit_module(self) -> None:
        results = comfortkit.predict_batch(
            [ComfortInputs(**_WARM_FAN), ComfortInputs(**_MILD_FAN)],
            model="cooling_effect",
        )
        assert len(results) == 2
        assert all(r.cooling_effect is not None for r in results)
