"""Tests for PersonalPosterior, SQLiteUserStore, and the v0.3/v0.5 API endpoints."""

from __future__ import annotations

import pathlib
from datetime import datetime, timedelta, timezone

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient

from api.routers.feedback import get_store
from api.store import SQLiteUserStore, UserStore
from comfortkit.models.personal import PersonalPosterior, _PRIOR_DATA

BASE_URL = "http://testserver"


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def store(tmp_path: pathlib.Path) -> SQLiteUserStore:
    return SQLiteUserStore(tmp_path / "test.db")


@pytest_asyncio.fixture
async def client(tmp_path: pathlib.Path) -> AsyncClient:
    """AsyncClient with the feedback router wired to a fresh in-test SQLite DB."""
    from api.main import app

    test_store = SQLiteUserStore(tmp_path / "api_test.db")
    app.dependency_overrides[get_store] = lambda: test_store
    async with AsyncClient(transport=ASGITransport(app=app), base_url=BASE_URL) as c:
        yield c
    app.dependency_overrides.clear()


# ===========================================================================
# PersonalPosterior — unit tests
# ===========================================================================


class TestPersonalPosteriorConstruction:
    def test_from_prior_returns_instance(self) -> None:
        p = PersonalPosterior.from_prior()
        assert isinstance(p, PersonalPosterior)

    def test_from_prior_uses_prior_data(self) -> None:
        p = PersonalPosterior.from_prior()
        assert p.alpha_warm == pytest.approx(float(_PRIOR_DATA["default"]["alpha_warm"]))
        assert p.alpha_neutral == pytest.approx(float(_PRIOR_DATA["default"]["alpha_neutral"]))
        assert p.alpha_cool == pytest.approx(float(_PRIOR_DATA["default"]["alpha_cool"]))

    def test_initial_n_votes_is_zero(self) -> None:
        assert PersonalPosterior.from_prior().n_votes == 0

    def test_prior_predicts_neutral(self) -> None:
        # global P(Neutral) ≈ 0.57 dominates; prior MAP is Neutral
        assert PersonalPosterior.from_prior().predict() == 0

    def test_prior_p_warm_near_aggregate(self) -> None:
        p = PersonalPosterior.from_prior()
        assert 0.35 < p.p_warm < 0.42

    def test_prior_p_cool_reflects_ashrae_baseline(self) -> None:
        # ASHRAE DB II cooling-season baseline: P(Cool) ≈ 0.21, replacing old Dorn prior (0.064)
        p = PersonalPosterior.from_prior()
        assert 0.18 < p.p_cool < 0.26

    def test_p_cooler_alias_equals_p_warm(self) -> None:
        p = PersonalPosterior.from_prior()
        assert p.p_cooler == p.p_warm

    def test_p_warm_plus_neutral_plus_cool_sums_to_one(self) -> None:
        p = PersonalPosterior.from_prior()
        assert p.p_warm + p.p_neutral + p.p_cool == pytest.approx(1.0)


class TestPersonalPosteriorUpdate:
    def test_warm_vote_increments_alpha_warm(self) -> None:
        p = PersonalPosterior.from_prior()
        before = p.alpha_warm
        p.update(1)
        assert p.alpha_warm == pytest.approx(before + 1.0)

    def test_neutral_vote_increments_alpha_neutral(self) -> None:
        p = PersonalPosterior.from_prior()
        before = p.alpha_neutral
        p.update(0)
        assert p.alpha_neutral == pytest.approx(before + 1.0)

    def test_cool_vote_increments_alpha_cool(self) -> None:
        p = PersonalPosterior.from_prior()
        before = p.alpha_cool
        p.update(-1)
        assert p.alpha_cool == pytest.approx(before + 1.0)

    def test_n_votes_increments_on_each_update(self) -> None:
        p = PersonalPosterior.from_prior()
        p.update(1)
        p.update(0)
        p.update(-1)
        assert p.n_votes == 3

    def test_invalid_vote_raises(self) -> None:
        p = PersonalPosterior.from_prior()
        with pytest.raises(ValueError, match="vote must be -1, 0, or 1"):
            p.update(2)

    def test_p_warm_increases_after_warm_votes(self) -> None:
        p = PersonalPosterior.from_prior()
        before = p.p_warm
        for _ in range(20):
            p.update(1)
        assert p.p_warm > before

    def test_p_warm_decreases_after_neutral_votes(self) -> None:
        p = PersonalPosterior.from_prior()
        before = p.p_warm
        for _ in range(20):
            p.update(0)
        assert p.p_warm < before

    def test_p_cool_increases_after_cool_votes(self) -> None:
        p = PersonalPosterior.from_prior()
        before = p.p_cool
        for _ in range(20):
            p.update(-1)
        assert p.p_cool > before

    def test_p_cooler_alias_tracks_p_warm(self) -> None:
        p = PersonalPosterior.from_prior()
        for _ in range(10):
            p.update(1)
        assert p.p_cooler == pytest.approx(p.p_warm)


class TestPersonalPosteriorConvergence:
    def test_warm_heavy_user_converges_to_warm(self) -> None:
        p = PersonalPosterior.from_prior()
        for _ in range(50):
            p.update(1)
        assert p.predict() == 1
        assert p.p_warm > 0.9

    def test_neutral_heavy_user_stays_neutral(self) -> None:
        # User who consistently reports comfort; predict stays 0, p_warm stays low
        p = PersonalPosterior.from_prior()
        for _ in range(50):
            p.update(0)
        assert p.predict() == 0
        assert p.p_warm < 0.15

    def test_cool_heavy_user_converges_to_cool(self) -> None:
        p = PersonalPosterior.from_prior()
        for _ in range(50):
            p.update(-1)
        assert p.predict() == -1
        assert p.p_cool > 0.9

    def test_balanced_warm_neutral_user_reflects_true_rate(self) -> None:
        p = PersonalPosterior.from_prior()
        for _ in range(200):
            p.update(1)
        for _ in range(200):
            p.update(0)
        assert 0.45 < p.p_warm < 0.55

    def test_prior_overridden_within_10_strong_votes(self) -> None:
        # Prior has concentration=5; 10 votes in one direction should dominate
        p = PersonalPosterior.from_prior()
        for _ in range(10):
            p.update(1)
        assert p.predict() == 1

    def test_neutral_heavy_user_p_cool_stays_near_prior(self) -> None:
        # Neutral votes must not inflate p_cool above prior level
        p = PersonalPosterior.from_prior()
        for _ in range(16):
            p.update(0)
        assert p.p_cool < 0.07


class TestPersonalPosteriorSerialisation:
    def test_to_dict_keys(self) -> None:
        d = PersonalPosterior.from_prior().to_dict()
        assert set(d) == {"alpha_warm", "alpha_neutral", "alpha_cool", "n_votes", "demographic_group"}

    def test_roundtrip(self) -> None:
        p = PersonalPosterior.from_prior()
        p.update(1)
        p.update(0)
        p.update(-1)
        p2 = PersonalPosterior.from_dict(p.to_dict())
        assert p2.alpha_warm == pytest.approx(p.alpha_warm)
        assert p2.alpha_neutral == pytest.approx(p.alpha_neutral)
        assert p2.alpha_cool == pytest.approx(p.alpha_cool)
        assert p2.n_votes == p.n_votes

    def test_p_warm_preserved_through_roundtrip(self) -> None:
        p = PersonalPosterior.from_prior()
        for _ in range(30):
            p.update(1)
        p2 = PersonalPosterior.from_dict(p.to_dict())
        assert p2.p_warm == pytest.approx(p.p_warm)

    def test_legacy_v03_from_dict(self) -> None:
        # Ensure backwards compatibility with v0.3 binary serialisation format
        legacy = {
            "alpha_cooler": 5.0,
            "alpha_not_cooler": 3.0,
            "n_votes": 7,
        }
        p = PersonalPosterior.from_dict(legacy)
        assert p.alpha_warm == pytest.approx(5.0)
        assert p.alpha_neutral == pytest.approx(3.0)
        assert p.n_votes == 7


# ===========================================================================
# SQLiteUserStore — unit tests
# ===========================================================================


class TestSQLiteUserStoreNewUser:
    def test_new_user_returns_prior(self, store: SQLiteUserStore) -> None:
        p = store.get_posterior("alice")
        assert p.n_votes == 0
        assert p.alpha_warm == pytest.approx(float(_PRIOR_DATA["default"]["alpha_warm"]))

    def test_two_new_users_independent(self, store: SQLiteUserStore) -> None:
        p1 = store.get_posterior("alice")
        p2 = store.get_posterior("bob")
        assert p1.p_warm == pytest.approx(p2.p_warm)


class TestSQLiteUserStorePersistence:
    def test_save_and_reload(self, store: SQLiteUserStore) -> None:
        p = store.get_posterior("alice")
        p.update(1)
        p.update(1)
        store.save_posterior("alice", p)
        reloaded = store.get_posterior("alice")
        assert reloaded.n_votes == 2
        assert reloaded.alpha_warm == pytest.approx(p.alpha_warm)

    def test_upsert_overwrites(self, store: SQLiteUserStore) -> None:
        p = store.get_posterior("alice")
        p.update(1)
        store.save_posterior("alice", p)
        p.update(1)
        store.save_posterior("alice", p)
        reloaded = store.get_posterior("alice")
        assert reloaded.n_votes == 2

    def test_multiple_users_isolated(self, store: SQLiteUserStore) -> None:
        pa = store.get_posterior("alice")
        for _ in range(20):
            pa.update(1)
        store.save_posterior("alice", pa)

        pb = store.get_posterior("bob")
        assert pb.n_votes == 0

    def test_vote_log_written(self, store: SQLiteUserStore) -> None:
        store.log_vote("alice", 1, 72.0, 27.5, 65.0, "Light", "sitting")
        import sqlite3
        conn = sqlite3.connect(store._db)
        row = conn.execute("SELECT * FROM vote_log WHERE user_id='alice'").fetchone()
        conn.close()
        assert row is not None
        assert row[2] == 1  # vote column

    def test_vote_log_accepts_nulls(self, store: SQLiteUserStore) -> None:
        store.log_vote("bob", 0, None, None, None, None, None)

    def test_cool_vote_persisted(self, store: SQLiteUserStore) -> None:
        p = store.get_posterior("carol")
        p.update(-1)
        store.save_posterior("carol", p)
        reloaded = store.get_posterior("carol")
        assert reloaded.alpha_cool > float(_PRIOR_DATA["default"]["alpha_cool"])


# ===========================================================================
# API endpoints — POST /v1/feedback and GET /v1/comfort/{user_id}
# ===========================================================================


class TestFeedbackEndpoint:
    async def test_returns_200(self, client: AsyncClient) -> None:
        resp = await client.post(
            "/v1/feedback", json={"user_id": "u1", "vote": 1}
        )
        assert resp.status_code == 200

    async def test_cool_vote_accepted(self, client: AsyncClient) -> None:
        resp = await client.post(
            "/v1/feedback", json={"user_id": "u_cool", "vote": -1}
        )
        assert resp.status_code == 200

    async def test_response_schema(self, client: AsyncClient) -> None:
        resp = await client.post(
            "/v1/feedback", json={"user_id": "u1", "vote": 0}
        )
        data = resp.json()
        assert "user_id" in data
        assert "n_votes" in data
        assert "p_warm" in data
        assert "p_neutral" in data
        assert "p_cool" in data
        assert "p_cooler" in data
        assert "prediction" in data
        assert "prediction_label" in data

    async def test_n_votes_increments(self, client: AsyncClient) -> None:
        for _ in range(3):
            await client.post("/v1/feedback", json={"user_id": "u2", "vote": 1})
        resp = await client.post("/v1/feedback", json={"user_id": "u2", "vote": 1})
        assert resp.json()["n_votes"] == 4

    async def test_warm_votes_increase_p_warm(self, client: AsyncClient) -> None:
        r0 = await client.post("/v1/feedback", json={"user_id": "u3", "vote": 1})
        p0 = r0.json()["p_warm"]
        for _ in range(30):
            await client.post("/v1/feedback", json={"user_id": "u3", "vote": 1})
        r1 = await client.post("/v1/feedback", json={"user_id": "u3", "vote": 1})
        assert r1.json()["p_warm"] > p0

    async def test_p_cooler_equals_p_warm(self, client: AsyncClient) -> None:
        resp = await client.post("/v1/feedback", json={"user_id": "u_alias", "vote": 1})
        data = resp.json()
        assert data["p_cooler"] == pytest.approx(data["p_warm"])

    async def test_invalid_vote_returns_422(self, client: AsyncClient) -> None:
        resp = await client.post(
            "/v1/feedback", json={"user_id": "u4", "vote": 5}
        )
        assert resp.status_code == 422

    async def test_out_of_range_negative_vote_returns_422(self, client: AsyncClient) -> None:
        resp = await client.post(
            "/v1/feedback", json={"user_id": "u4", "vote": -2}
        )
        assert resp.status_code == 422

    async def test_optional_features_accepted(self, client: AsyncClient) -> None:
        resp = await client.post(
            "/v1/feedback",
            json={
                "user_id": "u5",
                "vote": 1,
                "heart_rate": 78.0,
                "t_net": 27.5,
                "rh_net": 65.0,
                "clothing": "Light",
                "met": "sitting",
            },
        )
        assert resp.status_code == 200

    async def test_prediction_label_is_string(self, client: AsyncClient) -> None:
        resp = await client.post("/v1/feedback", json={"user_id": "u6", "vote": 0})
        label = resp.json()["prediction_label"]
        assert label in ("Warm", "Neutral", "Cool")

    async def test_missing_user_id_returns_422(self, client: AsyncClient) -> None:
        resp = await client.post("/v1/feedback", json={"vote": 1})
        assert resp.status_code == 422


class TestComfortEndpoint:
    async def test_new_user_returns_200(self, client: AsyncClient) -> None:
        resp = await client.get("/v1/comfort/brand_new_user")
        assert resp.status_code == 200

    async def test_new_user_confidence_is_prior(self, client: AsyncClient) -> None:
        resp = await client.get("/v1/comfort/never_seen")
        assert resp.json()["confidence"] == "prior"

    async def test_new_user_n_votes_is_zero(self, client: AsyncClient) -> None:
        resp = await client.get("/v1/comfort/also_new")
        assert resp.json()["n_votes"] == 0

    async def test_response_schema(self, client: AsyncClient) -> None:
        resp = await client.get("/v1/comfort/schema_check")
        data = resp.json()
        for key in ("user_id", "p_warm", "p_neutral", "p_cool", "p_cooler",
                    "prediction", "prediction_label", "n_votes", "confidence"):
            assert key in data

    async def test_confidence_low_after_few_votes(self, client: AsyncClient) -> None:
        for _ in range(5):
            await client.post("/v1/feedback", json={"user_id": "conf_low", "vote": 1})
        resp = await client.get("/v1/comfort/conf_low")
        assert resp.json()["confidence"] == "low"

    async def test_confidence_medium_after_20_to_99_votes(
        self, client: AsyncClient
    ) -> None:
        for _ in range(25):
            await client.post(
                "/v1/feedback", json={"user_id": "conf_med", "vote": 1}
            )
        resp = await client.get("/v1/comfort/conf_med")
        assert resp.json()["confidence"] == "medium"

    async def test_confidence_high_after_100_votes(self, client: AsyncClient) -> None:
        for _ in range(100):
            await client.post(
                "/v1/feedback", json={"user_id": "conf_high", "vote": 0}
            )
        resp = await client.get("/v1/comfort/conf_high")
        assert resp.json()["confidence"] == "high"

    async def test_posterior_reflected_in_comfort(self, client: AsyncClient) -> None:
        # After many Warm votes, GET /v1/comfort should reflect that
        for _ in range(50):
            await client.post(
                "/v1/feedback", json={"user_id": "warm_user", "vote": 1}
            )
        resp = await client.get("/v1/comfort/warm_user")
        data = resp.json()
        assert data["prediction"] == 1
        assert data["prediction_label"] == "Warm"
        assert data["p_warm"] > 0.8

    async def test_user_id_in_response(self, client: AsyncClient) -> None:
        resp = await client.get("/v1/comfort/specific_user_42")
        assert resp.json()["user_id"] == "specific_user_42"

    async def test_neutral_user_prediction_label(self, client: AsyncClient) -> None:
        # 50 neutral votes → predict=Neutral
        for _ in range(50):
            await client.post(
                "/v1/feedback", json={"user_id": "neutral_user", "vote": 0}
            )
        resp = await client.get("/v1/comfort/neutral_user")
        data = resp.json()
        assert data["prediction"] == 0
        assert data["prediction_label"] == "Neutral"


# ===========================================================================
# PersonalPosterior.decay — unit tests
# ===========================================================================


class TestPersonalPosteriorDecay:
    def test_zero_elapsed_is_no_op(self) -> None:
        p = PersonalPosterior.from_prior()
        for _ in range(20):
            p.update(1)
        warm_before = p.alpha_warm
        p.decay(0, 180)
        assert p.alpha_warm == pytest.approx(warm_before)

    def test_zero_half_life_is_no_op(self) -> None:
        p = PersonalPosterior.from_prior()
        for _ in range(20):
            p.update(1)
        warm_before = p.alpha_warm
        p.decay(365, 0)
        assert p.alpha_warm == pytest.approx(warm_before)

    def test_at_one_half_life_excess_is_halved(self) -> None:
        p = PersonalPosterior.from_prior()
        excess = 20.0
        p.alpha_warm += excess
        prior_warm = float(_PRIOR_DATA["default"]["alpha_warm"])
        p.decay(180, 180)
        assert p.alpha_warm == pytest.approx(prior_warm + excess * 0.5, rel=1e-6)

    def test_alpha_approaches_prior_not_zero(self) -> None:
        # Extreme elapsed time — posterior should converge to prior, not below it
        p = PersonalPosterior.from_prior()
        for _ in range(100):
            p.update(1)
        p.decay(100_000, 180)
        assert p.alpha_warm == pytest.approx(float(_PRIOR_DATA["default"]["alpha_warm"]), abs=1e-6)
        assert p.alpha_neutral == pytest.approx(float(_PRIOR_DATA["default"]["alpha_neutral"]), abs=1e-6)
        assert p.alpha_cool == pytest.approx(float(_PRIOR_DATA["default"]["alpha_cool"]), abs=1e-6)

    def test_n_votes_decayed_at_half_life(self) -> None:
        p = PersonalPosterior.from_prior()
        p.n_votes = 100
        p.decay(180, 180)
        assert p.n_votes == 50

    def test_n_votes_rounds_to_int(self) -> None:
        p = PersonalPosterior.from_prior()
        p.n_votes = 3
        p.decay(180, 180)  # factor=0.5 → 1.5 → rounds to 2
        assert isinstance(p.n_votes, int)

    def test_probabilities_sum_to_one_after_decay(self) -> None:
        p = PersonalPosterior.from_prior()
        for _ in range(30):
            p.update(1)
        p.decay(90, 180)
        assert p.p_warm + p.p_neutral + p.p_cool == pytest.approx(1.0)

    def test_warm_user_decays_toward_prior(self) -> None:
        p = PersonalPosterior.from_prior()
        for _ in range(50):
            p.update(1)
        p_warm_before = p.p_warm
        p.decay(180, 180)
        # p_warm moves toward the prior aggregate (~0.37), away from the peak
        assert p.p_warm < p_warm_before

    def test_neutral_user_decay_does_not_inflate_p_cool(self) -> None:
        # Neutral-heavy user should not develop elevated p_cool after decay
        p = PersonalPosterior.from_prior()
        for _ in range(50):
            p.update(0)
        p.decay(180, 180)
        assert p.p_cool < 0.10


# ===========================================================================
# SQLiteUserStore with decay — integration tests
# ===========================================================================


class TestSQLiteUserStoreDecay:
    def test_recent_user_barely_decayed(self, store: SQLiteUserStore) -> None:
        p = store.get_posterior("alice")
        for _ in range(50):
            p.update(1)
        store.save_posterior("alice", p)
        warm_saved = p.alpha_warm
        one_minute_later = datetime.now(timezone.utc) + timedelta(minutes=1)
        reloaded = store.get_posterior("alice", _now=one_minute_later)
        assert reloaded.alpha_warm == pytest.approx(warm_saved, rel=1e-3)

    def test_at_one_half_life_excess_is_halved(self, store: SQLiteUserStore) -> None:
        p = store.get_posterior("bob")
        for _ in range(50):
            p.update(1)
        store.save_posterior("bob", p)
        warm_saved = p.alpha_warm
        prior_warm = float(_PRIOR_DATA["default"]["alpha_warm"])
        half_life_later = datetime.now(timezone.utc) + timedelta(days=180)
        decayed = store.get_posterior("bob", _now=half_life_later)
        assert decayed.alpha_warm == pytest.approx(
            prior_warm + (warm_saved - prior_warm) * 0.5, rel=1e-4
        )

    def test_dormant_user_n_votes_decays(self, store: SQLiteUserStore) -> None:
        p = store.get_posterior("carol")
        for _ in range(100):
            p.update(1)
        store.save_posterior("carol", p)
        half_life_later = datetime.now(timezone.utc) + timedelta(days=180)
        decayed = store.get_posterior("carol", _now=half_life_later)
        assert decayed.n_votes == 50

    def test_new_user_no_decay_applied(self, store: SQLiteUserStore) -> None:
        # No row in DB → fresh prior, no decay
        p = store.get_posterior("never_seen")
        assert p.alpha_warm == pytest.approx(float(_PRIOR_DATA["default"]["alpha_warm"]))
        assert p.n_votes == 0

    def test_disabled_half_life_returns_full_posterior(
        self, tmp_path: pathlib.Path
    ) -> None:
        no_decay_store = SQLiteUserStore(tmp_path / "no_decay.db", half_life_days=0)
        p = no_decay_store.get_posterior("dave")
        for _ in range(50):
            p.update(1)
        no_decay_store.save_posterior("dave", p)
        warm_saved = p.alpha_warm
        one_year_later = datetime.now(timezone.utc) + timedelta(days=365)
        reloaded = no_decay_store.get_posterior("dave", _now=one_year_later)
        assert reloaded.alpha_warm == pytest.approx(warm_saved)

    def test_decay_is_idempotent_on_repeated_reads(self, store: SQLiteUserStore) -> None:
        # Reading without writing should not compound decay across reads
        p = store.get_posterior("eve")
        for _ in range(50):
            p.update(1)
        store.save_posterior("eve", p)
        future = datetime.now(timezone.utc) + timedelta(days=180)
        first_read = store.get_posterior("eve", _now=future)
        second_read = store.get_posterior("eve", _now=future)
        assert first_read.alpha_warm == pytest.approx(second_read.alpha_warm)


# ===========================================================================
# Demographic priors — PersonalPosterior.from_prior with gender/hvac_mode
# ===========================================================================


class TestDemographicPrior:
    def test_default_prior_uses_ashrae_cooling_baseline(self) -> None:
        p = PersonalPosterior.from_prior()
        assert p.alpha_cool == pytest.approx(float(_PRIOR_DATA["default"]["alpha_cool"]))
        assert p.demographic_group == "default"

    def test_female_cooling_group_label(self) -> None:
        p = PersonalPosterior.from_prior(gender="F", hvac_mode="cooling")
        assert p.demographic_group == "female_cooling"

    def test_female_cooling_uses_female_cooling_alphas(self) -> None:
        p = PersonalPosterior.from_prior(gender="F", hvac_mode="cooling")
        assert p.alpha_cool == pytest.approx(float(_PRIOR_DATA["female_cooling"]["alpha_cool"]))

    def test_female_cooling_p_cool_higher_than_default(self) -> None:
        female = PersonalPosterior.from_prior(gender="F", hvac_mode="cooling")
        default = PersonalPosterior.from_prior()
        assert female.p_cool > default.p_cool

    def test_female_heating_falls_back_to_default(self) -> None:
        p = PersonalPosterior.from_prior(gender="F", hvac_mode="heating")
        assert p.demographic_group == "default"

    def test_male_cooling_falls_back_to_default(self) -> None:
        p = PersonalPosterior.from_prior(gender="M", hvac_mode="cooling")
        assert p.demographic_group == "default"

    def test_no_demographics_gives_default(self) -> None:
        p = PersonalPosterior.from_prior()
        assert p.demographic_group == "default"

    def test_probabilities_sum_to_one_for_all_groups(self) -> None:
        for g, m in [("F", "cooling"), ("M", "cooling"), ("F", "heating"), (None, None)]:
            p = PersonalPosterior.from_prior(gender=g, hvac_mode=m)
            assert p.p_warm + p.p_neutral + p.p_cool == pytest.approx(1.0)

    def test_roundtrip_preserves_demographic_group(self) -> None:
        p = PersonalPosterior.from_prior(gender="F", hvac_mode="cooling")
        p.update(1)
        p2 = PersonalPosterior.from_dict(p.to_dict())
        assert p2.demographic_group == "female_cooling"


class TestDecayWithDemographicGroup:
    def test_female_cooling_decays_toward_female_cooling_prior(self) -> None:
        p = PersonalPosterior.from_prior(gender="F", hvac_mode="cooling")
        for _ in range(50):
            p.update(0)
        p.decay(100_000, 180)
        assert p.alpha_cool == pytest.approx(
            float(_PRIOR_DATA["female_cooling"]["alpha_cool"]), abs=1e-6
        )

    def test_default_user_decays_toward_default_prior(self) -> None:
        p = PersonalPosterior.from_prior()
        for _ in range(50):
            p.update(1)
        p.decay(100_000, 180)
        assert p.alpha_warm == pytest.approx(
            float(_PRIOR_DATA["default"]["alpha_warm"]), abs=1e-6
        )


# ===========================================================================
# SQLiteUserStore — demographic group persistence
# ===========================================================================


class TestSQLiteUserStoreDemographicGroup:
    def test_new_female_cooling_user_gets_demographic_prior(
        self, store: SQLiteUserStore
    ) -> None:
        p = store.get_posterior("alice", gender="F", hvac_mode="cooling")
        assert p.demographic_group == "female_cooling"
        assert p.alpha_cool == pytest.approx(
            float(_PRIOR_DATA["female_cooling"]["alpha_cool"])
        )

    def test_demographic_group_persisted_after_first_save(
        self, store: SQLiteUserStore
    ) -> None:
        p = store.get_posterior("alice", gender="F", hvac_mode="cooling")
        p.update(1)
        store.save_posterior("alice", p)
        reloaded = store.get_posterior("alice")
        assert reloaded.demographic_group == "female_cooling"

    def test_demographic_group_not_overridden_on_subsequent_calls(
        self, store: SQLiteUserStore
    ) -> None:
        p = store.get_posterior("alice", gender="F", hvac_mode="cooling")
        p.update(1)
        store.save_posterior("alice", p)
        reloaded = store.get_posterior("alice", gender="M", hvac_mode="heating")
        assert reloaded.demographic_group == "female_cooling"

    def test_no_demographics_gives_default_group(
        self, store: SQLiteUserStore
    ) -> None:
        p = store.get_posterior("bob")
        assert p.demographic_group == "default"

    def test_female_cooling_decay_reverts_to_female_prior(
        self, store: SQLiteUserStore
    ) -> None:
        p = store.get_posterior("alice", gender="F", hvac_mode="cooling")
        for _ in range(50):
            p.update(0)
        store.save_posterior("alice", p)
        far_future = datetime.now(timezone.utc) + timedelta(days=100_000)
        decayed = store.get_posterior("alice", _now=far_future)
        assert decayed.alpha_cool == pytest.approx(
            float(_PRIOR_DATA["female_cooling"]["alpha_cool"]), abs=1e-4
        )


# ===========================================================================
# API — demographic fields on POST /v1/feedback
# ===========================================================================


class TestFeedbackEndpointDemographics:
    async def test_gender_and_hvac_mode_accepted(self, client: AsyncClient) -> None:
        resp = await client.post(
            "/v1/feedback",
            json={"user_id": "u_demo", "vote": 0, "gender": "F", "hvac_mode": "cooling"},
        )
        assert resp.status_code == 200

    async def test_female_cooling_p_cool_higher_than_generic_cooling(
        self, client: AsyncClient
    ) -> None:
        resp_female = await client.post(
            "/v1/feedback",
            json={"user_id": "u_f", "vote": 0, "gender": "F", "hvac_mode": "cooling"},
        )
        resp_default = await client.post(
            "/v1/feedback",
            json={"user_id": "u_d", "vote": 0, "hvac_mode": "cooling"},
        )
        assert resp_female.json()["p_cool"] > resp_default.json()["p_cool"]

    async def test_invalid_gender_returns_422(self, client: AsyncClient) -> None:
        resp = await client.post(
            "/v1/feedback",
            json={"user_id": "u_bad", "vote": 0, "gender": "X"},
        )
        assert resp.status_code == 422

    async def test_invalid_hvac_mode_returns_422(self, client: AsyncClient) -> None:
        resp = await client.post(
            "/v1/feedback",
            json={"user_id": "u_bad", "vote": 0, "hvac_mode": "blasting"},
        )
        assert resp.status_code == 422

    async def test_omitting_demographics_still_works(self, client: AsyncClient) -> None:
        resp = await client.post("/v1/feedback", json={"user_id": "u_anon", "vote": 1})
        assert resp.status_code == 200
