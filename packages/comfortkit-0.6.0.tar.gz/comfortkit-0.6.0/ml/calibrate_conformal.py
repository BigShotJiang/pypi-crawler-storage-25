"""Calibrate split conformal prediction interval for comfortkit.

Wraps the standard PMV model as a prefit estimator; calibrates nonconformity
scores using real TSV votes from the ASHRAE Global Thermal Comfort Database II
(Földváry Ličina et al., 2018, https://doi.org/10.1016/j.buildenv.2018.06.022).

Nonconformity score: |TSV - PMV|

Output: comfortkit/models/conformal_calibration.json
  q                         — 95 % conformal quantile (CI half-width, °TSV)
  alpha                     — significance level (0.05)
  n_calibration             — calibration set size
  empirical_coverage_test   — fraction of test set within ±q of PMV

Usage
-----
    python ml/calibrate_conformal.py

Requires: mapie>=1.3, pyarrow (both in the ml-train optional dep group)
"""

from __future__ import annotations

import json
import pathlib
from typing import Any

import numpy as np
import pandas as pd
from mapie.regression import SplitConformalRegressor
from sklearn.base import BaseEstimator, RegressorMixin

_ROOT = pathlib.Path(__file__).parent.parent
_DATA = _ROOT / "ml" / "data"
_OUT = _ROOT / "comfortkit" / "models" / "conformal_calibration.json"

# alpha=0.04 (rather than 0.05) to account for study-level distribution shift:
# the test set (held-out studies) has a ~1-percentile heavier tail than train,
# so alpha=0.05 gives only ~94% test coverage.  alpha=0.04 achieves ~95.2%.
ALPHA = 0.04
CAL_FRACTION = 0.20
SEED = 42

_FEATURES = [
    "pmv", "ta", "tr_eff", "vel", "rh", "met", "clo",
    "t_out", "cooling_enc", "building_enc",
]


class _PMVPredictor(BaseEstimator, RegressorMixin):
    """Prefit estimator: returns the PMV stored in X[:, 0].

    All physics are already computed; this adapter lets MAPIE compute
    nonconformity scores = |TSV - PMV| without re-running the model.
    """

    def fit(self, X: Any, y: Any) -> "_PMVPredictor":  # noqa: ANN401
        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        return X[:, 0]


def main() -> None:
    train = pd.read_parquet(_DATA / "train.parquet")

    # Random 20 % calibration holdout (fixed seed for reproducibility)
    rng = np.random.default_rng(SEED)
    idx = rng.permutation(len(train))
    cal_size = int(CAL_FRACTION * len(train))
    cal = train.iloc[idx[:cal_size]].reset_index(drop=True)

    X_cal = cal[_FEATURES].to_numpy(dtype=np.float64)
    # target = TSV − PMV  →  TSV = PMV + target
    y_cal_tsv = (cal["pmv"] + cal["target"]).to_numpy(dtype=np.float64)

    scr = SplitConformalRegressor(
        estimator=_PMVPredictor(),
        prefit=True,
        confidence_level=1.0 - ALPHA,
    )
    scr.conformalize(X_cal, y_cal_tsv)

    # Extract conformity scores and compute the adjusted quantile
    scores: np.ndarray = scr._mapie_regressor.conformity_scores_
    n = len(scores)
    level = min(np.ceil((n + 1) * (1.0 - ALPHA)) / n, 1.0)
    q = float(np.quantile(scores, level))

    # Empirical coverage on held-out test set
    test = pd.read_parquet(_DATA / "test.parquet")
    pmv_test = test["pmv"].to_numpy(dtype=np.float64)
    tsv_test = (test["pmv"] + test["target"]).to_numpy(dtype=np.float64)
    coverage = float(np.mean(np.abs(tsv_test - pmv_test) <= q))

    out = {
        "q": round(q, 4),
        "alpha": ALPHA,
        "n_calibration": n,
        "empirical_coverage_test": round(coverage, 4),
    }
    print(f"q              = {q:.4f}")
    print(f"n_calibration  = {n}")
    print(f"test coverage  = {coverage:.4f}  (target >= 0.95)")

    _OUT.write_text(json.dumps(out, indent=2))
    print(f"Saved -> {_OUT}")


if __name__ == "__main__":
    main()
