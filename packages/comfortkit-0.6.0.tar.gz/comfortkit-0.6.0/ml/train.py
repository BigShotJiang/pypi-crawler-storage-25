"""Training script for the PMV residual correction model (v0.2).

Trains a LightGBM regressor to predict (TSV − PMV) — the residual between
observed thermal sensation votes and physics-predicted PMV.  Exports to ONNX
for deployment in comfortkit/models/ml.py via onnxruntime.

Training data:
    Földváry Ličina, V., Cheung, T., Zhang, H., de Dear, R., Parkinson, T.,
    Arens, E., & Schiavon, S. (2018). Development of the ASHRAE Global Thermal
    Comfort Database II. Building and Environment, 142, 502-512.
    https://doi.org/10.1016/j.buildenv.2018.06.022

Run directly (not imported by the package):

    python ml/train.py

Outputs:
    comfortkit/models/pmv_correction.onnx
    comfortkit/models/pmv_correction_meta.json
"""

from __future__ import annotations

import json
import sys
import warnings
from pathlib import Path

import lightgbm as lgb
import numpy as np
import pandas as pd

_HERE = Path(__file__).parent
_DATA = _HERE / "data"
_MODEL_OUT = Path(__file__).parent.parent / "comfortkit" / "models"

_FEATURE_COLS = ["pmv", "ta", "tr_eff", "vel", "rh", "met", "clo",
                 "t_out", "cooling_enc", "building_enc"]
_TARGET_COL = "target"

# Clip extreme residuals: anything beyond ±6 PMV units is a data-quality artefact
_RESIDUAL_CLIP = 6.0


def _load(split: str) -> tuple[np.ndarray, np.ndarray]:
    df = pd.read_parquet(_DATA / f"{split}.parquet")
    # Filter extreme residuals (bad votes or data entry errors)
    mask = df[_TARGET_COL].abs() <= _RESIDUAL_CLIP
    df = df.loc[mask]
    X = df[_FEATURE_COLS].to_numpy(dtype=np.float32)
    y = df[_TARGET_COL].to_numpy(dtype=np.float32)
    return X, y


def _rmse(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(np.sqrt(np.mean((y_true - y_pred) ** 2)))


def _mae(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(np.mean(np.abs(y_true - y_pred)))


def main() -> None:
    print("Loading data ...", flush=True)
    X_train, y_train = _load("train")
    X_test, y_test = _load("test")
    print(f"  Train: {X_train.shape[0]} rows")
    print(f"  Test:  {X_test.shape[0]} rows")

    # Baseline: predict zero residual (plain PMV)
    baseline_rmse = _rmse(y_test, np.zeros_like(y_test))
    baseline_mae = _mae(y_test, np.zeros_like(y_test))
    print(f"\nBaseline (PMV only)  — RMSE: {baseline_rmse:.4f}  MAE: {baseline_mae:.4f}")

    print("\nTraining LightGBM ...", flush=True)
    params = {
        "objective": "regression",
        "metric": "rmse",
        "num_leaves": 63,
        "learning_rate": 0.05,
        "n_estimators": 500,
        "min_child_samples": 20,
        "subsample": 0.8,
        "colsample_bytree": 0.8,
        "reg_alpha": 0.1,
        "reg_lambda": 0.1,
        "verbose": -1,
        "n_jobs": -1,
        "random_state": 42,
    }

    model = lgb.LGBMRegressor(**params)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        model.fit(
            X_train, y_train,
            eval_set=[(X_test, y_test)],
            callbacks=[lgb.early_stopping(50, verbose=False),
                       lgb.log_evaluation(period=100)],
        )

    y_pred = model.predict(X_test).astype(np.float32)
    ml_rmse = _rmse(y_test, y_pred)
    ml_mae = _mae(y_test, y_pred)
    print(f"\nML correction model  — RMSE: {ml_rmse:.4f}  MAE: {ml_mae:.4f}")
    print(f"RMSE improvement over baseline: {(baseline_rmse - ml_rmse) / baseline_rmse * 100:.1f}%")

    # Feature importance
    importances = sorted(
        zip(_FEATURE_COLS, model.feature_importances_),
        key=lambda x: x[1], reverse=True,
    )
    print("\nFeature importances:")
    for feat, imp in importances:
        print(f"  {feat:<15} {imp}")

    # Export to ONNX
    print("\nExporting to ONNX ...", flush=True)
    try:
        from onnxmltools import convert_lightgbm
        from onnxmltools.utils import save_model
        from skl2onnx.common.data_types import FloatTensorType

        initial_types = [("float_input", FloatTensorType([None, len(_FEATURE_COLS)]))]
        onnx_model = convert_lightgbm(
            model.booster_,
            initial_types=initial_types,
            target_opset=15,
        )
        _MODEL_OUT.mkdir(parents=True, exist_ok=True)
        onnx_path = _MODEL_OUT / "pmv_correction.onnx"
        save_model(onnx_model, str(onnx_path))
        print(f"  Written: {onnx_path}")

        # Smoke-test ONNX inference
        import onnxruntime as ort
        sess = ort.InferenceSession(str(onnx_path))
        sample = X_test[:5]
        ort_pred = sess.run(None, {"float_input": sample})[0].flatten()
        lgb_pred = model.predict(sample).astype(np.float32)
        max_diff = float(np.max(np.abs(ort_pred - lgb_pred)))
        print(f"  ONNX vs LightGBM max diff (5 samples): {max_diff:.6f}")
        assert max_diff < 0.01, f"ONNX export mismatch: {max_diff}"
        print("  ONNX smoke-test passed.")

    except Exception as exc:
        print(f"  WARNING: ONNX export failed — {exc}", file=sys.stderr)
        print("  Install: pip install onnxmltools skl2onnx onnxruntime", file=sys.stderr)
        sys.exit(1)

    # Load feature encoding maps from data prep output
    feat_meta = json.loads((_DATA / "feature_meta.json").read_text())

    # Save metadata (includes encoding maps so the model dir is self-contained)
    meta = {
        "features": _FEATURE_COLS,
        "n_features": len(_FEATURE_COLS),
        "test_rmse": round(ml_rmse, 4),
        "test_mae": round(ml_mae, 4),
        "baseline_rmse": round(baseline_rmse, 4),
        "n_train": int(X_train.shape[0]),
        "n_test": int(X_test.shape[0]),
        "lgbm_params": params,
        "cooling_map": feat_meta["cooling_map"],
        "building_map": feat_meta["building_map"],
        "t_out_fill": feat_meta["t_out_fill"],
    }
    meta_path = _MODEL_OUT / "pmv_correction_meta.json"
    meta_path.write_text(json.dumps(meta, indent=2))
    print(f"  Written: {meta_path}")

    print("\nDone.")


if __name__ == "__main__":
    main()
    sys.exit(0)
