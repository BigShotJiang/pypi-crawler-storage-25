"""Data preparation for the ASHRAE Global Thermal Comfort Database II.

Data source:
    Földváry Ličina, V., Cheung, T., Zhang, H., de Dear, R., Parkinson, T.,
    Arens, E., & Schiavon, S. (2018). Development of the ASHRAE Global Thermal
    Comfort Database II. Building and Environment, 142, 502-512.
    https://doi.org/10.1016/j.buildenv.2018.06.022

Loads the raw CSV, cleans and imputes key fields, recomputes PMV using the
vectorised ISO 7730 kernel (for consistency with comfortkit's own physics),
constructs the residual target (TSV − PMV), encodes categorical features,
performs a study-level 80/20 train/test split, and writes Parquet artefacts.

Run directly (not imported by the package):

    python ml/data/ashrae_db2_prep.py

Outputs:
    ml/data/train.parquet
    ml/data/test.parquet
    ml/data/feature_meta.json   — label encodings and t_out fill value
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

_HERE = Path(__file__).parent
_CSV = _HERE / "ashrae_db2.01.csv"
_TRAIN_OUT = _HERE / "train.parquet"
_TEST_OUT = _HERE / "test.parquet"
_META_OUT = _HERE / "feature_meta.json"

# ---------------------------------------------------------------------------
# Column aliases (raw CSV name → friendly name)
# ---------------------------------------------------------------------------

_COL_MAP = {
    "Thermal sensation": "tsv",
    "PMV": "pmv_db",
    "Air temperature (C)": "ta",
    "Radiant temperature (C)": "tr",
    "Operative temperature (C)": "top",
    "Air velocity (m/s)": "vel",
    "Relative humidity (%)": "rh",
    "Met": "met",
    "Clo": "clo",
    "Outdoor monthly air temperature (C)": "t_out",
    "Cooling startegy_building level": "cooling_strategy",
    "Building type": "building_type",
    "Publication (Citation)": "study",
}

# Required raw features — rows with any NaN in these are dropped
_REQUIRED = ["ta", "vel", "rh", "met", "clo", "tsv"]

# ---------------------------------------------------------------------------
# Pure-NumPy PMV kernel (mirrors comfortkit/uncertainty.py — no import cycle)
# ---------------------------------------------------------------------------

_MET_TO_W = 58.15


def _pmv_array(arr: np.ndarray) -> np.ndarray:
    """Vectorised ISO 7730 PMV over (N, 6) array [ta, tr, vel, rh, met, clo]."""
    ta = arr[:, 0]
    tr = arr[:, 1]
    vr = arr[:, 2]
    rh = arr[:, 3]
    met = arr[:, 4]
    clo = arr[:, 5]

    pa = rh * 10.0 * np.exp(16.6536 - 4030.183 / (ta + 235.0))
    icl = 0.155 * clo
    m = met * _MET_TO_W
    mw = m

    f_cl = np.where(icl <= 0.078, 1.0 + 1.29 * icl, 1.05 + 0.645 * icl)
    hcf = 12.1 * np.sqrt(np.maximum(vr, 0.0))
    taa = ta + 273.0
    tra = tr + 273.0

    p1 = icl * f_cl
    p2 = p1 * 3.96
    p3 = p1 * 100.0
    p4 = p1 * taa
    p5 = (308.7 - 0.028 * mw) + p2 * (tra / 100.0) ** 4

    xn = (taa + (35.5 - ta) / (3.5 * icl + 0.1)) / 100.0
    xf = xn * 2.0
    hc = hcf.copy()

    for _ in range(150):
        xf = (xf + xn) / 2.0
        hcn = 2.38 * np.abs(100.0 * xf - taa) ** 0.25
        hc = np.maximum(hcn, hcf)
        xn = (p5 + p4 * hc - p2 * xf ** 4) / (100.0 + p3 * hc)
        if np.max(np.abs(xn - xf)) < 0.00015:
            break

    tcl = 100.0 * xn - 273.0

    hl1 = 3.05e-3 * (5733.0 - 6.99 * mw - pa)
    hl2 = np.where(mw > _MET_TO_W, 0.42 * (mw - _MET_TO_W), 0.0)
    hl3 = 1.7e-5 * m * (5867.0 - pa)
    hl4 = 0.0014 * m * (34.0 - ta)
    hl5 = 3.96 * f_cl * (xn ** 4 - (tra / 100.0) ** 4)
    hl6 = f_cl * hc * (tcl - ta)

    ts = 0.303 * np.exp(-0.036 * m) + 0.028
    return ts * (mw - hl1 - hl2 - hl3 - hl4 - hl5 - hl6)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    print(f"Loading {_CSV} ...", flush=True)
    df = pd.read_csv(_CSV, low_memory=False)
    print(f"  Raw shape: {df.shape}")

    # Rename to friendly names
    df = df.rename(columns=_COL_MAP)

    # Coerce numeric columns
    numeric_cols = ["tsv", "pmv_db", "ta", "tr", "top", "vel", "rh",
                    "met", "clo", "t_out"]
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    # Impute radiant temperature: tr → operative temp → air temp
    df["tr_eff"] = df["tr"].fillna(df["top"]).fillna(df["ta"])

    # Drop rows missing any required field
    before = len(df)
    df = df.dropna(subset=_REQUIRED + ["tr_eff"])
    print(f"  After dropping rows missing required fields: {len(df)} ({before - len(df)} dropped)")

    # Clip physical bounds
    df["vel"] = df["vel"].clip(lower=0.0)
    df["rh"] = df["rh"].clip(lower=0.0, upper=100.0)
    df["met"] = df["met"].clip(lower=0.01)
    df["clo"] = df["clo"].clip(lower=0.0)

    # Recompute PMV using our vectorised kernel for full coverage and consistency
    feat_mat = df[["ta", "tr_eff", "vel", "rh", "met", "clo"]].to_numpy(dtype=np.float64)
    df["pmv"] = np.round(_pmv_array(feat_mat), 2)

    # Target: TSV − PMV residual
    df["target"] = df["tsv"] - df["pmv"]

    # Encode categorical features
    cooling_order = ["Naturally Ventilated", "Mixed Mode",
                     "Mechanically Ventilated", "Air Conditioned"]
    df["cooling_strategy"] = df["cooling_strategy"].fillna("Unknown")
    cooling_cats = [c for c in cooling_order if c in df["cooling_strategy"].unique()]
    cooling_cats += [c for c in df["cooling_strategy"].unique() if c not in cooling_cats]
    cooling_map = {v: i for i, v in enumerate(cooling_cats)}
    df["cooling_enc"] = df["cooling_strategy"].map(cooling_map).fillna(len(cooling_map)).astype(int)

    df["building_type"] = df["building_type"].fillna("Unknown")
    building_cats = sorted(df["building_type"].unique())
    building_map = {v: i for i, v in enumerate(building_cats)}
    df["building_enc"] = df["building_type"].map(building_map).astype(int)

    # Fill t_out with median (keep column; model learns seasonal effect where available)
    t_out_median = float(df["t_out"].median())
    df["t_out"] = df["t_out"].fillna(t_out_median)

    # Study-level 80/20 split on Publication
    df["study"] = df["study"].fillna("Unknown")
    studies = df["study"].unique()
    rng = np.random.default_rng(42)
    rng.shuffle(studies)
    n_train = int(len(studies) * 0.8)
    train_studies = set(studies[:n_train])
    test_studies = set(studies[n_train:])

    train_mask = df["study"].isin(train_studies)
    test_mask = df["study"].isin(test_studies)

    feature_cols = ["pmv", "ta", "tr_eff", "vel", "rh", "met", "clo",
                    "t_out", "cooling_enc", "building_enc", "target"]

    train_df = df.loc[train_mask, feature_cols].reset_index(drop=True)
    test_df = df.loc[test_mask, feature_cols].reset_index(drop=True)

    print(f"  Train: {len(train_df)} rows ({len(train_studies)} studies)")
    print(f"  Test:  {len(test_df)} rows ({len(test_studies)} studies)")

    train_df.to_parquet(_TRAIN_OUT, index=False)
    test_df.to_parquet(_TEST_OUT, index=False)
    print(f"  Written: {_TRAIN_OUT}")
    print(f"  Written: {_TEST_OUT}")

    # Save metadata for inference-time encoding
    meta = {
        "cooling_map": cooling_map,
        "building_map": building_map,
        "t_out_fill": t_out_median,
        "features": ["pmv", "ta", "tr_eff", "vel", "rh", "met", "clo",
                     "t_out", "cooling_enc", "building_enc"],
    }
    _META_OUT.write_text(json.dumps(meta, indent=2))
    print(f"  Written: {_META_OUT}")

    # Quick residual stats
    print(f"\nResidual (target) stats:")
    print(f"  mean  = {df['target'].mean():.3f}")
    print(f"  std   = {df['target'].std():.3f}")
    print(f"  range = [{df['target'].min():.2f}, {df['target'].max():.2f}]")


if __name__ == "__main__":
    main()
    sys.exit(0)
