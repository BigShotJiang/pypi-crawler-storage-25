"""ML correction model — stub for v0.2.

Will be a ComfortModel subclass that calls StandardComfortModel internally
for the physics baseline and applies a learned residual correction.
Training code lives in ml/train.py; this module is never imported by the
comfortkit package itself.
"""

from __future__ import annotations

raise NotImplementedError("ml.model is a v0.2 stub and is not yet implemented")
