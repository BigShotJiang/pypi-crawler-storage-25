"""Zone aggregation proof-of-concept validation on the ENTH longitudinal dataset.

DATASET
-------
ENTH tabular merged — 17 participants, 3 buildings (SDE4, SDE2, SDE1),
March-April 2021.  Votes prompted by smartwatch EMA (~15-25 min median interval).

THERMAL ENCODING
----------------
  9  = Cool preference (occupant feels cool / wants it warmer)
  10 = Neutral
  11 = Warm preference (occupant feels warm / wants it cooler)

THREE-CLASS MAPPING TO PERSONAL MODEL (v0.5)
---------------------------------------------
  thermal == 11  ->  vote =  1  (Warm preference)
  thermal == 10  ->  vote =  0  (Neutral / comfortable)
  thermal ==  9  ->  vote = -1  (Cool preference)

CO-OCCUPANCY DETECTION
----------------------
For each space_id, a sliding window of +/-W minutes around each vote is used
to find all distinct users simultaneously present.  Only indoor spaces
(indoor/outdoor == 11, space_id >= 1) are included.

TARGET SPACES
-------------
  206 (SDE2) -- 9 ever-users, 2 distinct 3-user configurations, 58 vote-rows
  130 (SDE1) -- 4 ever-users, 1 distinct 3-user configuration, 23 vote-rows

POSTERIOR CONSTRUCTION
----------------------
For each user involved in a co-occupancy event, the posterior is built from
all their votes BEFORE the first timestamp of that event (leave-future-out).
This simulates the real deployment scenario where the system has accumulated
prior individual feedback before the group occupancy event occurs.

LIMITATIONS  <-- read before interpreting the results
--------------
  * Only 3 distinct 3-user co-occupancy configurations exist in the entire dataset.
  * All events fall on 3 calendar days (Mar 18, Mar 22, Apr 5 2021).
  * Group sizes never exceed 3 (data was not collected as a co-occupancy study).
  * No statistical significance testing is possible -- sample is too small.
  * This script is a plausibility check and existence proof, not a benchmark.
    Claim: the aggregator produces a sensible directional signal.
    Not claimed: error rates, generalisability, superiority over alternatives.
"""

from __future__ import annotations

import argparse
import pathlib
import sys

import numpy as np
import pandas as pd

# Allow running from repo root without installing
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

from comfortkit.models.personal import PersonalPosterior
from comfortkit.models.zone import ZoneAggregator


class _V4ZoneAggregator(ZoneAggregator):
    """Emulates v0.4 binary zone logic for before/after comparison.

    Only difference: Strategy A raise_setpoint triggers when mean_p_warm < lower_threshold
    (old behaviour), not when mean_p_cool > lower_threshold (v0.5 behaviour).
    """

    def _action_from_mean(self, mean_p_warm: float, mean_p_cool: float) -> str:  # type: ignore[override]
        if mean_p_warm > self.mean_upper_threshold:
            return "lower_setpoint"
        if mean_p_warm < self.mean_lower_threshold:  # v0.4: P(Warm) floor
            return "raise_setpoint"
        return "maintain"

    def _action_from_any(self, p_warms: list[float], p_cools: list[float]) -> str:  # type: ignore[override]
        if any(p > self.any_discomfort_threshold for p in p_warms):
            return "lower_setpoint"
        return "maintain"  # v0.4: warm-only, no cold detection


DATA_PATH = pathlib.Path(
    "C:/Users/kalya/longitudinal-personal-thermal-comfort/data/raw/enth_tabular_merged.csv"
)
TARGET_SPACES = [206, 130]
STRATEGIES = ["mean_p_warm", "majority_vote", "any_discomfort"]


# ---------------------------------------------------------------------------
# Data loading and preprocessing
# ---------------------------------------------------------------------------

def _map_vote_threeclass(thermal: float) -> int:
    """Map ENTH thermal encoding to three-class vote (-1/0/1)."""
    if thermal == 11.0:
        return 1   # Warm preference
    if thermal == 9.0:
        return -1  # Cool preference
    return 0       # Neutral (thermal==10) or unknown


def load_enth(path: pathlib.Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    df["time"] = pd.to_datetime(df["time"], format="mixed", utc=True)
    # three-class vote: thermal=11->1, thermal=10->0, thermal=9->-1
    df["vote"] = df["thermal"].apply(_map_vote_threeclass)
    # binary vote retained for before/after comparison
    df["vote_binary"] = (df["thermal"] == 11.0).astype(int)
    # keep indoor, known spaces only
    df = df[(df["indoor/outdoor"] == 11.0) & (df["space_id"] >= 1)].copy()
    df = df.sort_values("time").reset_index(drop=True)
    return df


# ---------------------------------------------------------------------------
# Co-occupancy detection
# ---------------------------------------------------------------------------

def find_cooccupancy_events(
    df: pd.DataFrame,
    space_id: int,
    window_min: int,
    min_users: int = 3,
) -> list[dict]:
    """Return unique co-occupancy configurations for a given space and window."""
    grp = df[df["space_id"] == space_id].sort_values("time").reset_index(drop=True)
    if grp.empty:
        return []

    ts = grp["time"].astype(np.int64) // int(1e9)
    window_sec = window_min * 60
    seen: set[frozenset] = set()
    events = []

    for i in range(len(grp)):
        t = ts.iloc[i]
        mask = (ts >= t - window_sec) & (ts <= t + window_sec)
        co_users = frozenset(grp.loc[mask, "user_id"])
        if len(co_users) < min_users or co_users in seen:
            continue
        seen.add(co_users)
        # collect all rows belonging to this configuration
        rows = grp[grp["user_id"].isin(co_users) & mask]
        events.append({
            "space_id": space_id,
            "user_set": co_users,
            "event_start": rows["time"].min(),
            "rows": rows,
        })

    return events


# ---------------------------------------------------------------------------
# Posterior construction (leave-future-out)
# ---------------------------------------------------------------------------

def build_prior_posteriors(
    df: pd.DataFrame,
    user_ids: set[str],
    cutoff_time: pd.Timestamp,
    vote_col: str = "vote",
) -> dict[str, PersonalPosterior]:
    """Build posteriors from each user's votes strictly before cutoff_time."""
    posteriors: dict[str, PersonalPosterior] = {}
    for uid in user_ids:
        posterior = PersonalPosterior.from_prior()
        user_votes = df[(df["user_id"] == uid) & (df["time"] < cutoff_time)]
        for vote in user_votes[vote_col]:
            posterior.update(int(vote))
        posteriors[uid] = posterior
    return posteriors


# ---------------------------------------------------------------------------
# Ground truth
# ---------------------------------------------------------------------------

def ground_truth_action(rows: pd.DataFrame) -> str:
    """Majority-rule ground truth from observed thermal votes.

    thermal == 11 (Warm) -> wants cooling -> lower_setpoint
    thermal == 9  (Cool) -> wants heating -> raise_setpoint
    thermal == 10 (Neutral) -> maintain

    Returns the action that matches the plurality vote.
    """
    counts = rows["thermal"].value_counts()
    n = len(rows)
    n_warm = counts.get(11.0, 0)
    n_cool = counts.get(9.0, 0)
    if n_warm > n / 2:
        return "lower_setpoint"
    if n_cool > n / 2:
        return "raise_setpoint"
    return "maintain"


def single_user_baseline(rows: pd.DataFrame) -> float:
    """Expected accuracy of picking one random user and using their vote as zone action.

    Returns the fraction of time a random single-user draw matches the
    majority-rule ground truth.
    """
    gt = ground_truth_action(rows)
    user_ids = rows["user_id"].unique()
    matches = 0
    for uid in user_ids:
        user_rows = rows[rows["user_id"] == uid]
        # user's majority vote
        counts = user_rows["thermal"].value_counts()
        n = len(user_rows)
        n_warm = counts.get(11.0, 0)
        n_cool = counts.get(9.0, 0)
        if n_warm > n / 2:
            user_action = "lower_setpoint"
        elif n_cool > n / 2:
            user_action = "raise_setpoint"
        else:
            user_action = "maintain"
        if user_action == gt:
            matches += 1
    return matches / len(user_ids) if user_ids.size > 0 else 0.0


# ---------------------------------------------------------------------------
# Validation runner
# ---------------------------------------------------------------------------

def run_validation(df: pd.DataFrame, window_min: int) -> list[dict]:
    results = []
    for space_id in TARGET_SPACES:
        events = find_cooccupancy_events(df, space_id, window_min, min_users=3)
        for event in events:
            rows = event["rows"]
            # v0.5 three-class posteriors (current)
            posteriors = build_prior_posteriors(df, event["user_set"], event["event_start"], vote_col="vote")
            # v0.4 binary posteriors (for before/after comparison)
            posteriors_v4 = build_prior_posteriors(df, event["user_set"], event["event_start"], vote_col="vote_binary")

            gt = ground_truth_action(rows)
            solo_baseline = single_user_baseline(rows)

            n_warm_obs = (rows["thermal"] == 11.0).sum()
            n_total_obs = len(rows)

            strategy_actions: dict[str, str] = {}
            strategy_actions_v4: dict[str, str] = {}
            for strategy in STRATEGIES:
                agg = ZoneAggregator(strategy=strategy)  # type: ignore[arg-type]
                strategy_actions[strategy] = agg.predict(posteriors).action
                # v0.4 simulation: override _action_from_mean to use old p_warm < threshold logic
                agg_v4 = _V4ZoneAggregator(strategy=strategy)  # type: ignore[arg-type]
                strategy_actions_v4[strategy] = agg_v4.predict(posteriors_v4).action

            row: dict = {
                "space_id": space_id,
                "window_min": window_min,
                "users": sorted(event["user_set"]),
                "n_users": len(event["user_set"]),
                "n_votes_in_event": n_total_obs,
                "pct_warm_obs": round(n_warm_obs / n_total_obs, 2),
                "ground_truth": gt,
                "solo_baseline_acc": round(solo_baseline, 2),
            }
            for strategy in STRATEGIES:
                row[f"action_{strategy}"] = strategy_actions[strategy]
                row[f"correct_{strategy}"] = strategy_actions[strategy] == gt
                row[f"action_v4_{strategy}"] = strategy_actions_v4[strategy]
                row[f"correct_v4_{strategy}"] = strategy_actions_v4[strategy] == gt
            # per-user posterior state at event time
            for uid in sorted(event["user_set"]):
                p = posteriors[uid]
                row[f"prior_votes_{uid}"] = p.n_votes
                row[f"p_warm_{uid}"] = round(p.p_warm, 3)
                row[f"p_neutral_{uid}"] = round(p.p_neutral, 3)
                row[f"p_cool_{uid}"] = round(p.p_cool, 3)
                # fraction of pre-event votes that were warm (thermal==11)
                pre = df[(df["user_id"] == uid) & (df["time"] < event["event_start"])]
                n_pre = len(pre)
                row[f"warm_frac_{uid}"] = round((pre["vote_binary"] == 1).sum() / n_pre, 2) if n_pre else None

            results.append(row)

    return results


# ---------------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------------

COL_WIDTH = 20


def _pad(s: str, w: int = COL_WIDTH) -> str:
    return str(s).ljust(w)


def _fmt_action(action: str) -> str:
    return {"lower_setpoint": "lower", "raise_setpoint": "RAISE", "maintain": "maint"}.get(action, action)


def print_summary(all_results: list[dict]) -> None:
    W = 80
    print()
    print("=" * W)
    print("ENTH Zone Aggregation Validation  --  proof-of-concept, not a benchmark")
    print("=" * W)
    print()
    print(
        "SCOPE: 3 distinct 3-user co-occupancy configurations from the ENTH\n"
        "longitudinal dataset (NUS SDE buildings, Mar-Apr 2021).  All events fall\n"
        "on 3 calendar days.  No statistical inference is possible from this sample.\n"
    )

    # ------------------------------------------------------------------
    # Per-window accuracy table
    # ------------------------------------------------------------------
    for window_min in sorted({r["window_min"] for r in all_results}):
        subset = [r for r in all_results if r["window_min"] == window_min]
        print(f"--- Window: {window_min} min --- ({len(subset)} event(s))")
        print()

        header = (
            _pad("space/users", 26)
            + _pad("gt", 16)
            + _pad("obs_warm%", 10)
            + _pad("solo_base", 10)
            + _pad("mean_p_warm", 12)
            + _pad("majority", 10)
            + _pad("any_disc", 10)
        )
        print(header)
        print("-" * len(header))

        for r in subset:
            users_str = f"{r['space_id']}:{','.join(u.replace('enth', '') for u in r['users'])}"
            mean_ok = "OK" if r["correct_mean_p_warm"] else "MISS"
            maj_ok  = "OK" if r["correct_majority_vote"] else "MISS"
            any_ok  = "OK" if r["correct_any_discomfort"] else "MISS"
            mean_cell = f"{mean_ok}({_fmt_action(r['action_mean_p_warm'])})"
            print(
                _pad(users_str, 26)
                + _pad(r["ground_truth"], 16)
                + _pad(f"{r['pct_warm_obs']:.0%}", 10)
                + _pad(f"{r['solo_baseline_acc']:.0%}", 10)
                + _pad(mean_cell, 12)
                + _pad(maj_ok, 10)
                + _pad(any_ok, 10)
            )

        print()
        for strategy in STRATEGIES:
            n_correct = sum(r[f"correct_{strategy}"] for r in subset)
            print(
                f"  {strategy:<22} {n_correct}/{len(subset)} correct  "
                f"(solo_baseline avg {np.mean([r['solo_baseline_acc'] for r in subset]):.0%})"
            )
        print()

    # ------------------------------------------------------------------
    # Before/after diagnosis — printed once, using the 30-min window data
    # ------------------------------------------------------------------
    ref_window = 30
    ref = [r for r in all_results if r["window_min"] == ref_window]
    if not ref:
        ref = [r for r in all_results if r["window_min"] == sorted({x["window_min"] for x in all_results})[0]]

    print("=" * W)
    print("BEFORE/AFTER: v0.4 binary  vs  v0.5 three-class  (30-min window)")
    print("=" * W)
    print("""
Root cause (v0.4): binary "Not Cooler" conflated neutral with cold preference.
  thermal=10 (neutral) and thermal=9 (cold) both incremented alpha_not_cooler,
  driving P(Warm) down identically. Neutral-heavy users accumulated P(Warm)
  below 0.35, triggering spurious raise_setpoint even when the zone was warm.

Fix (v0.5): three-class Dirichlet-Multinomial separates P(Warm)/P(Neutral)/P(Cool).
  raise_setpoint now requires mean_p_cool > 0.35, not mean_p_warm < 0.35.
  Neutral-heavy users keep P(Cool) near-prior (~0.06), correctly excluded
  from both signals.
""")

    # Per-configuration before/after table
    hdr = (
        _pad("space/users", 26)
        + _pad("gt", 16)
        + _pad("v0.4 mean_p", 14)
        + _pad("v0.5 mean_p", 14)
        + "verdict"
    )
    print(hdr)
    print("-" * len(hdr))
    for r in ref:
        users_str = f"{r['space_id']}:{','.join(u.replace('enth', '') for u in r['users'])}"
        v4_act = _fmt_action(r["action_v4_mean_p_warm"])
        v5_act = _fmt_action(r["action_mean_p_warm"])
        v4_ok = "OK" if r["correct_v4_mean_p_warm"] else "MISS"
        v5_ok = "OK" if r["correct_mean_p_warm"] else "MISS"
        changed = " << FIXED" if not r["correct_v4_mean_p_warm"] and r["correct_mean_p_warm"] else \
                  " >> broken" if r["correct_v4_mean_p_warm"] and not r["correct_mean_p_warm"] else ""
        print(
            _pad(users_str, 26)
            + _pad(r["ground_truth"], 16)
            + _pad(f"{v4_ok}({v4_act})", 14)
            + _pad(f"{v5_ok}({v5_act})", 14)
            + changed
        )
    print()

    # Per-user three-class breakdown
    print("Per-user posterior at event time (v0.5 three-class):")
    print()
    for r in ref:
        users_str = f"space {r['space_id']} [{','.join(r['users'])}]"
        print(f"  {users_str}  obs_warm={r['pct_warm_obs']:.0%}  gt={r['ground_truth']}")
        p_warms, p_cools = [], []
        for uid in r["users"]:
            nv  = r.get(f"prior_votes_{uid}", "?")
            pw  = r.get(f"p_warm_{uid}", "?")
            pn  = r.get(f"p_neutral_{uid}", "?")
            pc  = r.get(f"p_cool_{uid}", "?")
            wf  = r.get(f"warm_frac_{uid}")
            wf_s = f"{wf:.0%}" if wf is not None else "n/a"
            note = ""
            if isinstance(pw, float) and pw < 0.35 and isinstance(pc, float) and pc < 0.10:
                note = "  -- neutral-heavy (P(Neutral) dominates, correctly excluded)"
            elif isinstance(pw, float) and pw > 0.70:
                note = "  -- strong warm signal"
            elif isinstance(pc, float) and pc > 0.35:
                note = "  -- strong cold signal"
            print(f"    {uid}: n={nv}  warm_frac={wf_s}  "
                  f"P(W)={pw}  P(N)={pn}  P(C)={pc}{note}")
            if isinstance(pw, float):
                p_warms.append(pw)
            if isinstance(pc, float):
                p_cools.append(pc)
        if p_warms:
            mw = np.mean(p_warms)
            mc = np.mean(p_cools) if p_cools else 0.0
            v4_would = "RAISE" if mw < 0.35 else ("lower" if mw > 0.5 else "maint")
            v5_says  = _fmt_action(r["action_mean_p_warm"])
            print(f"    zone mean P(Warm)={mw:.3f}  P(Cool)={mc:.3f}")
            print(f"    v0.4 would say: {v4_would}   v0.5 says: {v5_says}  gt={r['ground_truth']}")
        print()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(description="Zone aggregation PoC validation on ENTH data")
    parser.add_argument("--data", type=pathlib.Path, default=DATA_PATH)
    parser.add_argument(
        "--windows",
        nargs="+",
        type=int,
        default=[15, 30, 60],
        metavar="MIN",
        help="Co-occupancy window sizes in minutes (default: 15 30 60)",
    )
    args = parser.parse_args()

    if not args.data.exists():
        print(f"ERROR: data file not found: {args.data}")
        print("Download ENTH data and update DATA_PATH or pass --data <path>")
        sys.exit(1)

    print(f"Loading ENTH data from {args.data} ...")
    df = load_enth(args.data)
    print(f"  {len(df)} indoor rows, {df['user_id'].nunique()} users, {df['space_id'].nunique()} spaces")

    all_results: list[dict] = []
    for w in args.windows:
        all_results.extend(run_validation(df, w))

    if not all_results:
        print("No co-occupancy events found with the given settings.")
        sys.exit(0)

    print_summary(all_results)


if __name__ == "__main__":
    main()
