"""Validation script for the v0.3 personalised comfort model.

Simulates sequential Bayesian updates for each of the 20 dorn study participants
and measures accuracy at checkpoints (10, 50, 100, 200, 500 votes), comparing:

  - Global majority baseline  : always predict "Not Cooler" (majority class)
  - Personalised Bayesian     : Beta-Bernoulli posterior, warm-started from
                                the aggregate prior, updated one vote at a time

The personalised model is expected to overtake the global baseline for users
with atypical preferences (notably users who vote "Cooler" >70% of the time).

Data: dorn-longitudinal-tc-study (Tartarini et al., 2022)
      20 participants, Singapore, Apr–Nov 2020
      df_cozie_env.csv (21,681 thermal preference votes)

Usage
-----
    python ml/validate_personal.py
    python ml/validate_personal.py --data /path/to/df_cozie_env.csv
"""

from __future__ import annotations

import argparse
import pathlib
import sys

import numpy as np
import pandas as pd

# Allow running from repo root without installing
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

from comfortkit.models.personal import PersonalPosterior

_DEFAULT_DATA = (
    pathlib.Path(__file__).parent.parent.parent
    / "dorn-longitudinal-tc-study"
    / "data"
    / "df_cozie_env.csv"
)

CHECKPOINTS = [10, 50, 100, 200, 500]


# ---------------------------------------------------------------------------
# Simulation helpers
# ---------------------------------------------------------------------------


def _simulate_user(
    votes: list[int],
) -> dict[int, dict[str, float]]:
    """For each checkpoint N, train on first N votes; evaluate on the rest.

    Returns
    -------
    dict mapping checkpoint → {"personalised": accuracy, "baseline": accuracy}
    """
    results: dict[int, dict[str, float]] = {}

    # Global majority baseline: always predict 0 (Not Cooler)
    global_baseline_pred = 0

    for n in CHECKPOINTS:
        if n >= len(votes):
            break

        # Build posterior from the first n votes
        posterior = PersonalPosterior.from_prior()
        for v in votes[:n]:
            posterior.update(v)

        test_votes = votes[n:]
        if not test_votes:
            break

        personal_pred = posterior.predict()
        personal_acc = float(np.mean([int(v == personal_pred) for v in test_votes]))
        baseline_acc = float(np.mean([int(v == global_baseline_pred) for v in test_votes]))

        results[n] = {"personalised": personal_acc, "baseline": baseline_acc}

    return results


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main(data_path: pathlib.Path) -> None:
    if not data_path.exists():
        print(f"ERROR: data file not found at {data_path}")
        print("Pass --data /path/to/df_cozie_env.csv to override.")
        sys.exit(1)

    df = pd.read_csv(data_path)
    df["cooler"] = (df["thermal"] == "Cooler").astype(int)
    df["time"] = pd.to_datetime(df["time"], format="mixed", utc=True)
    df = df.dropna(subset=["cooler"]).sort_values(["userid", "time"])

    n_users = df["userid"].nunique()
    n_votes_total = len(df)
    p_cooler_global = df["cooler"].mean()
    global_baseline_acc = 1.0 - p_cooler_global  # predict 0 always

    print("=" * 72)
    print("comfortkit v0.3 - Personalised Bayesian comfort model validation")
    print("=" * 72)
    print(f"Users: {n_users}  |  Total votes: {n_votes_total}  "
          f"|  P(Cooler) global: {p_cooler_global:.3f}")
    print(f"Global majority baseline accuracy (predict Not Cooler always): "
          f"{global_baseline_acc:.3f}\n")

    # Per-user simulation
    user_results: dict[int, dict[int, dict[str, float]]] = {}
    for uid, group in df.groupby("userid"):
        votes = group["cooler"].tolist()
        user_results[int(uid)] = _simulate_user(votes)  # type: ignore[arg-type]

    # Summary table
    header_cps = [str(n) for n in CHECKPOINTS]
    col_w = 10
    uid_w = 6

    def row_fmt(label: str, values: list[str]) -> str:
        return label.ljust(uid_w) + "".join(v.rjust(col_w) for v in values)

    # Header
    print(row_fmt("User", [f"n_votes", "P(Cool)"] + [f"N={n}" for n in CHECKPOINTS]))
    print(row_fmt("", ["", ""] + ["pers/base"] * len(CHECKPOINTS)))
    print("-" * (uid_w + col_w * (2 + len(CHECKPOINTS))))

    delta_sums: dict[int, list[float]] = {n: [] for n in CHECKPOINTS}

    for uid in sorted(user_results):
        user_df = df[df["userid"] == uid]
        n_v = len(user_df)
        p_c = user_df["cooler"].mean()
        row_vals = [str(n_v), f"{p_c:.2f}"]
        for n in CHECKPOINTS:
            if n not in user_results[uid]:
                row_vals.append("  --/-- ")
            else:
                pa = user_results[uid][n]["personalised"]
                ba = user_results[uid][n]["baseline"]
                row_vals.append(f"{pa:.2f}/{ba:.2f}")
                delta_sums[n].append(pa - ba)
        print(row_fmt(str(uid), row_vals))

    # Mean delta row
    print("-" * (uid_w + col_w * (2 + len(CHECKPOINTS))))
    delta_vals = ["", ""]
    for n in CHECKPOINTS:
        if delta_sums[n]:
            mean_delta = np.mean(delta_sums[n])
            delta_vals.append(f"d={mean_delta:+.3f}")
        else:
            delta_vals.append("  --   ")
    print(row_fmt("delta", delta_vals))
    print()

    # Highlight atypical users where personalised model wins most
    print("Users where personalised model wins most at N=50:")
    gains = []
    for uid in sorted(user_results):
        if 50 in user_results[uid]:
            pa = user_results[uid][50]["personalised"]
            ba = user_results[uid][50]["baseline"]
            gains.append((uid, pa - ba, pa, ba))
    gains.sort(key=lambda x: -x[1])
    for uid, delta, pa, ba in gains[:5]:
        p_c = df[df["userid"] == uid]["cooler"].mean()
        print(f"  User {uid:2d}  P(Cooler)={p_c:.2f}  "
              f"personalised={pa:.3f}  baseline={ba:.3f}  delta={delta:+.3f}")

    print()
    print("Interpretation:")
    print("  pers = accuracy of personalised Bayesian model on held-out votes")
    print("  base = accuracy of global majority baseline (always predict Not Cooler)")
    print("  delta = mean(pers - base) across users with enough votes")
    print()
    print("Users with P(Cooler) >> 0.5 show the largest gains: the global")
    print("baseline fails them; the personalised model converges within ~50 votes.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Validate personalised comfort model")
    parser.add_argument(
        "--data",
        type=pathlib.Path,
        default=_DEFAULT_DATA,
        help="Path to df_cozie_env.csv",
    )
    args = parser.parse_args()
    main(args.data)
