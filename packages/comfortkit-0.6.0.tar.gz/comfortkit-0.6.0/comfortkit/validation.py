"""Applicability guards and structured warning messages.

ComfortInputError is defined in comfortkit.models.base (where ComfortInputs
validators need it) and re-exported here for convenience.
"""

from __future__ import annotations

from comfortkit._constants import APPLICABILITY_LIMITS
from comfortkit.models.base import ComfortInputError, ComfortInputs

__all__ = ["ComfortInputError", "check_applicability"]


def check_applicability(inputs: ComfortInputs) -> list[str]:
    """Return a list of applicability-limit warning strings.

    Does NOT raise — out-of-range inputs are flagged, not rejected.
    Raise :class:`ComfortInputError` upstream for physically impossible values.

    Parameters
    ----------
    inputs : ComfortInputs
        Validated input conditions.

    Returns
    -------
    list[str]
        Warning messages for each parameter outside its standard's limits.
        Empty list when all inputs are within range.
    """
    limits = APPLICABILITY_LIMITS[inputs.standard]
    warnings: list[str] = []

    field_map = {
        "ta": inputs.ta,
        "tr": inputs.tr,
        "vel": inputs.vel,
        "rh": inputs.rh,
        "met": inputs.met,
        "clo": inputs.clo,
    }

    for param, value in field_map.items():
        lo, hi = limits[param]
        if not (lo <= value <= hi):
            warnings.append(
                f"{param}={value} is outside the {inputs.standard.upper()} "
                f"applicability range [{lo}, {hi}]; result may be unreliable."
            )

    return warnings
