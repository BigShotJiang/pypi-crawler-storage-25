"""Uncertainty quantification: bootstrap CI, conformal CI, Monte Carlo propagation.

Vectorised via NumPy; avoid Python loops in hot paths.
The t_cl convergence loop is O(150) iterations over the full sample array —
it is a fixed-point solver loop, not a per-sample loop.
"""

from __future__ import annotations

import json
import pathlib
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from comfortkit.models.base import ComfortInputs

# ---------------------------------------------------------------------------
# Conformal CI — loaded once at import time from the bundled calibration file
# ---------------------------------------------------------------------------

_CAL_PATH = pathlib.Path(__file__).parent / "models" / "conformal_calibration.json"

_CONFORMAL_Q: float | None = None
try:
    _CONFORMAL_Q = float(json.loads(_CAL_PATH.read_text())["q"])
except Exception:  # noqa: BLE001  # missing file, bad JSON, wrong key — all degrade
    pass

_MET_TO_W_M2: float = 58.15  # 1 met = 58.15 W/m²

# Column order used throughout this module
_FIELDS = ("ta", "tr", "vel", "rh", "met", "clo")

# Parametric noise defaults for bootstrap_ci (representative sensor tolerances)
_DEFAULT_SIGMA: dict[str, float] = {
    "ta": 0.5,    # air temperature sensor (°C)
    "tr": 2.0,    # MRT probe (°C)
    "vel": 0.05,  # air velocity sensor (m/s)
    "rh": 5.0,    # humidity sensor (%)
    "met": 0.0,   # user-specified, not a sensor
    "clo": 0.0,   # user-specified, not a sensor
}


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _inputs_to_row(inputs: ComfortInputs) -> np.ndarray:
    """Pack a ComfortInputs into a (1, 6) float64 array."""
    return np.array(
        [[inputs.ta, inputs.tr, inputs.vel, inputs.rh, inputs.met, inputs.clo]],
        dtype=np.float64,
    )


def _perturb(
    central: np.ndarray,
    sigma: dict[str, float],
    n_samples: int,
    rng: np.random.Generator,
) -> np.ndarray:
    """Return (n_samples, 6) array perturbed by zero-mean Gaussian noise.

    Physical constraints are enforced after sampling:
    vel >= 0, rh in [0, 100], met > 0, clo >= 0.
    """
    sig = np.array([sigma.get(k, 0.0) for k in _FIELDS], dtype=np.float64)
    samples = central + rng.standard_normal((n_samples, 6)) * sig
    samples[:, 2] = np.clip(samples[:, 2], 0.0, None)    # vel >= 0
    samples[:, 3] = np.clip(samples[:, 3], 0.0, 100.0)   # rh in [0, 100]
    samples[:, 4] = np.clip(samples[:, 4], 1e-6, None)   # met > 0
    samples[:, 5] = np.clip(samples[:, 5], 0.0, None)    # clo >= 0
    return samples


def _ci_from_pmv(pmv_arr: np.ndarray, confidence: float) -> tuple[float, float]:
    """Percentile CI from an array of PMV samples."""
    alpha = (1.0 - confidence) / 2.0
    lo = float(np.percentile(pmv_arr, alpha * 100.0))
    hi = float(np.percentile(pmv_arr, (1.0 - alpha) * 100.0))
    return round(lo, 2), round(hi, 2)


def _pmv_samples(arr: np.ndarray) -> np.ndarray:
    """Vectorised ISO 7730 PMV over an (N, 6) array [ta, tr, vel, rh, met, clo].

    Mirrors the scalar kernel in pythermalcomfort._pmv_ppd_optimized, translated
    to operate on entire columns at once.  The inner while-loop is replaced by a
    fixed-iteration NumPy loop that exits early once all samples converge.

    Parameters
    ----------
    arr : np.ndarray, shape (N, 6)
        Input matrix, columns in order: ta, tr, vel, rh, met, clo.

    Returns
    -------
    np.ndarray, shape (N,)
        PMV value for each row.
    """
    ta  = arr[:, 0]
    tr  = arr[:, 1]
    vr  = arr[:, 2]
    rh  = arr[:, 3]
    met = arr[:, 4]
    clo = arr[:, 5]

    # Water vapour partial pressure (Pa) — same formula as pythermalcomfort
    pa = rh * 10.0 * np.exp(16.6536 - 4030.183 / (ta + 235.0))

    icl = 0.155 * clo                          # clothing thermal resistance (m²K/W)
    m   = met * _MET_TO_W_M2                   # metabolic rate (W/m²)
    mw  = m                                    # internal heat production (external work = 0)

    f_cl = np.where(icl <= 0.078, 1.0 + 1.29 * icl, 1.05 + 0.645 * icl)
    hcf  = 12.1 * np.sqrt(vr)                 # forced convection coefficient
    taa  = ta + 273.0
    tra  = tr + 273.0

    # Precomputed constants for the t_cl fixed-point loop
    p1 = icl * f_cl
    p2 = p1 * 3.96
    p3 = p1 * 100.0
    p4 = p1 * taa
    p5 = (308.7 - 0.028 * mw) + p2 * (tra / 100.0) ** 4

    # Initial guess for clothing surface temperature (matches pythermalcomfort)
    t_cla = taa + (35.5 - ta) / (3.5 * icl + 0.1)
    xn = t_cla / 100.0
    xf = t_cla / 50.0   # bisection bracket start
    eps = 0.00015        # convergence tolerance (same as pythermalcomfort)

    hc = hcf.copy()
    for _ in range(150):
        xf = (xf + xn) / 2.0
        hcn = 2.38 * np.abs(100.0 * xf - taa) ** 0.25
        hc  = np.maximum(hcn, hcf)
        xn  = (p5 + p4 * hc - p2 * xf ** 4) / (100.0 + p3 * hc)
        if np.max(np.abs(xn - xf)) < eps:
            break

    tcl = 100.0 * xn - 273.0   # clothing surface temperature (°C)

    hl1 = 3.05e-3  * (5733.0 - 6.99 * mw - pa)                      # skin diffusion
    hl2 = np.where(mw > _MET_TO_W_M2, 0.42 * (mw - _MET_TO_W_M2), 0.0)  # sweating
    hl3 = 1.7e-5   * m * (5867.0 - pa)                               # latent respiration
    hl4 = 0.0014   * m * (34.0 - ta)                                 # dry respiration
    hl5 = 3.96     * f_cl * (xn ** 4 - (tra / 100.0) ** 4)          # radiation
    hl6 = f_cl     * hc  * (tcl - ta)                                # convection

    ts = 0.303 * np.exp(-0.036 * m) + 0.028
    return ts * (mw - hl1 - hl2 - hl3 - hl4 - hl5 - hl6)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def bootstrap_ci(
    inputs: ComfortInputs,
    n_samples: int = 1000,
    confidence: float = 0.95,
    seed: int | None = None,
) -> tuple[float, float]:
    """Estimate a bootstrap confidence interval on PMV.

    Uses a parametric bootstrap with fixed sensor-noise defaults
    (:data:`_DEFAULT_SIGMA`).  Draws *n_samples* inputs from a Gaussian
    distribution centred on *inputs*, computes PMV for all samples
    simultaneously via :func:`_pmv_samples`, then returns the percentile CI.

    Parameters
    ----------
    inputs : ComfortInputs
        Central-estimate input conditions.
    n_samples : int
        Number of bootstrap draws.
    confidence : float
        Confidence level, e.g. 0.95 for a 95 % CI.
    seed : int or None
        Random seed for reproducibility.

    Returns
    -------
    tuple[float, float]
        (lower, upper) bound on PMV, rounded to 2 decimal places.
    """
    rng = np.random.default_rng(seed)
    central = _inputs_to_row(inputs)
    samples = _perturb(central, _DEFAULT_SIGMA, n_samples, rng)
    return _ci_from_pmv(_pmv_samples(samples), confidence)


def conformal_ci(pmv: float) -> tuple[float, float] | None:
    """Return a split conformal prediction interval on PMV.

    The half-width *q* is calibrated on the ASHRAE Global Thermal Comfort
    Database II (Földváry Ličina et al., 2018) against real TSV votes, so the
    interval has an *empirically grounded* 95 % coverage guarantee rather than
    a sensor-noise-only bootstrap estimate.  Returns ``None`` when the
    calibration file is absent (graceful degradation).

    Parameters
    ----------
    pmv : float
        Point-estimate PMV value.

    Returns
    -------
    tuple[float, float] or None
        (pmv - q, pmv + q), rounded to 2 decimal places, or ``None`` when
        the calibration data are unavailable.
    """
    if _CONFORMAL_Q is None:
        return None
    q = _CONFORMAL_Q
    return round(pmv - q, 2), round(pmv + q, 2)


def monte_carlo_propagate(
    inputs: ComfortInputs,
    sigma: dict[str, float],
    n_samples: int = 10_000,
    confidence: float = 0.95,
    seed: int | None = None,
) -> tuple[float, float]:
    """Propagate input uncertainties to a PMV confidence interval via Monte Carlo.

    Parameters
    ----------
    inputs : ComfortInputs
        Central-estimate input conditions.
    sigma : dict[str, float]
        Standard deviation for each input parameter, e.g.
        ``{"ta": 0.5, "tr": 1.0, "vel": 0.1}``.  Missing keys default to 0.
    n_samples : int
        Number of Monte Carlo draws.
    confidence : float
        Confidence level, e.g. 0.95 for a 95 % CI.
    seed : int or None
        Random seed for reproducibility.

    Returns
    -------
    tuple[float, float]
        (lower, upper) bound on PMV, rounded to 2 decimal places.
    """
    rng = np.random.default_rng(seed)
    central = _inputs_to_row(inputs)
    samples = _perturb(central, sigma, n_samples, rng)
    return _ci_from_pmv(_pmv_samples(samples), confidence)
