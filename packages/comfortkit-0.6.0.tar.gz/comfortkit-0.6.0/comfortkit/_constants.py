"""Package-wide constants: sensation scale, met/clo lookup tables."""

from __future__ import annotations

# ASHRAE 55 / ISO 7730 7-point thermal sensation scale
SENSATION_SCALE: dict[int, str] = {
    -3: "cold",
    -2: "cool",
    -1: "slightly cool",
    0: "neutral",
    1: "slightly warm",
    2: "warm",
    3: "hot",
}

# Typical metabolic rates from ISO 8996 / ASHRAE 55 Table C1 (met)
MET_VALUES: dict[str, float] = {
    "sleeping": 0.7,
    "reclining": 0.8,
    "seated_quiet": 1.0,
    "standing_relaxed": 1.2,
    "walking_slow": 1.7,
    "walking_medium": 2.0,
    "walking_fast": 2.6,
    "light_bench_work": 2.0,
    "heavy_work": 4.0,
}

# Typical clothing insulation values from ASHRAE 55 Table C2 (clo)
CLO_VALUES: dict[str, float] = {
    "naked": 0.0,
    "shorts_only": 0.1,
    "light_summer": 0.5,
    "light_work": 0.6,
    "typical_western": 1.0,
    "heavy_suit": 1.5,
    "heavy_winter": 2.0,
}

# PMV thresholds for ASHRAE 55 acceptability (80 % and 90 % satisfaction)
ASHRAE_ACCEPTABLE_80: tuple[float, float] = (-0.5, 0.5)
ASHRAE_ACCEPTABLE_90: tuple[float, float] = (-0.5, 0.5)  # same limits, stricter PPD

# SET comfort zone per ASHRAE 55 (°C) — approximately 72–78 °F
SET_COMFORT_ZONE: tuple[float, float] = (22.2, 25.6)

# SET → 7-point sensation mapping (upper-bound exclusive thresholds, °C)
# Derived from ASHRAE 55 Table B-1 thermal sensation / SET equivalences.
SET_SENSATION_THRESHOLDS: list[tuple[float, str]] = [
    (17.5, "cold"),
    (20.0, "cool"),
    (22.5, "slightly cool"),
    (25.6, "neutral"),
    (28.0, "slightly warm"),
    (30.5, "warm"),
]  # values at or above 30.5 °C → "hot"

# Applicability limits by standard
APPLICABILITY_LIMITS: dict[str, dict[str, tuple[float, float]]] = {
    "ashrae": {
        "ta": (10.0, 40.0),
        "tr": (10.0, 40.0),
        "vel": (0.0, 2.0),
        "rh": (0.0, 100.0),
        "met": (1.0, 4.0),
        "clo": (0.0, 1.5),
    },
    "iso": {
        "ta": (10.0, 30.0),
        "tr": (10.0, 40.0),
        "vel": (0.0, 1.0),
        "rh": (30.0, 70.0),
        "met": (0.8, 4.0),
        "clo": (0.0, 2.0),
    },
}
