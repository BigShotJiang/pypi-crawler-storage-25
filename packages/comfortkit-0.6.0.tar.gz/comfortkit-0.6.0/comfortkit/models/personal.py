"""Personalised thermal comfort model — Dirichlet-Multinomial (K=3).

Three-class target: 1 = Warm (feels warm, prefers cooling),
                    0 = Neutral (comfortable),
                   -1 = Cool (feels cool, prefers heating).

The model maintains a per-user Dirichlet-Multinomial posterior with three
alpha pseudo-counts (alpha_warm, alpha_neutral, alpha_cool).  Each occupant
vote increments the relevant count; posterior means give P(Warm), P(Neutral),
and P(Cool) for that user.

Warm-start prior is derived from the aggregate indoor vote distribution across
20 users in the Dorn longitudinal study (Tartarini et al., 2022; Singapore,
Apr-Nov 2020):
  P(Warm)=0.3693  P(Neutral)=0.5663  P(Cool)=0.0644
  concentration = 5 pseudo-counts.

The small concentration means the prior is weak -- 10-20 real votes already
pull the posterior toward the individual's own preference.

Backwards compatibility
-----------------------
The v0.3 binary interface (vote=0 "Not Cooler", vote=1 "Cooler") is still
accepted.  Old vote=1 maps to the new vote=1 (Warm); old vote=0 maps to the
new vote=0 (Neutral).  This is the best-effort mapping -- old "Not Cooler"
votes cannot be retrospectively split between Neutral and Cool.  New callers
should use the full three-class interface (-1 / 0 / 1).

The p_cooler property is retained as an alias for p_warm so that existing
code that reads the binary posterior continues to work unchanged.
"""

from __future__ import annotations

import json
import pathlib
from dataclasses import dataclass

_PRIOR_PATH = pathlib.Path(__file__).parent / "personal_prior.json"

# Loaded once at import; falls back to hardcoded values if file is absent.
# Format: nested dict keyed by demographic group ("default", "female_cooling", …).
_HARDCODED_PRIORS: dict[str, dict] = {
    "default": {
        "alpha_warm": 1.8090, "alpha_neutral": 2.1310, "alpha_cool": 1.0600
    },
    "female_cooling": {
        "alpha_warm": 1.8563, "alpha_neutral": 2.0303, "alpha_cool": 1.1134
    },
}
try:
    _raw = json.loads(_PRIOR_PATH.read_text())
    # New nested format has a "default" key; old flat format (Dorn) does not.
    _PRIOR_DATA: dict[str, dict] = _raw if "default" in _raw else {"default": _raw}
except Exception:  # noqa: BLE001
    _PRIOR_DATA = _HARDCODED_PRIORS


@dataclass
class PersonalPosterior:
    """Per-user Dirichlet-Multinomial (K=3) posterior for thermal comfort preference.

    Parameters
    ----------
    alpha_warm : float
        Dirichlet pseudo-count for the Warm outcome (feels warm, prefers cooling).
    alpha_neutral : float
        Dirichlet pseudo-count for the Neutral outcome (comfortable).
    alpha_cool : float
        Dirichlet pseudo-count for the Cool outcome (feels cool, prefers heating).
    n_votes : int
        Number of real votes observed (excludes prior pseudo-counts).
    """

    alpha_warm: float
    alpha_neutral: float
    alpha_cool: float
    n_votes: int = 0
    demographic_group: str = "default"

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    @classmethod
    def from_prior(
        cls,
        gender: str | None = None,
        hvac_mode: str | None = None,
    ) -> "PersonalPosterior":
        """Return a fresh posterior initialised from the appropriate demographic prior.

        Parameters
        ----------
        gender : str | None
            "F" or "M". Only "F" triggers a demographic override; all other
            values (including None) use the gender-neutral baseline.
        hvac_mode : str | None
            "cooling", "heating", or "neutral". Only "cooling" triggers an
            override; other values use the seasonal-neutral baseline.

        The only active override is female + cooling, which initialises with a
        higher P(Cool) reflecting measured overcooling sensitivity (ASHRAE DB II).
        All other combinations use the all-gender cooling-season baseline.
        """
        group = (
            "female_cooling"
            if gender == "F" and hvac_mode == "cooling"
            else "default"
        )
        prior = _PRIOR_DATA.get(group, _PRIOR_DATA["default"])
        return cls(
            alpha_warm=float(prior["alpha_warm"]),
            alpha_neutral=float(prior["alpha_neutral"]),
            alpha_cool=float(prior["alpha_cool"]),
            demographic_group=group,
        )

    # ------------------------------------------------------------------
    # Bayesian update
    # ------------------------------------------------------------------

    def update(self, vote: int) -> None:
        """Update the posterior with one new occupant vote.

        Parameters
        ----------
        vote : int
             1 = Warm preference (feels warm, wants it cooler).
             0 = Neutral / No change (comfortable).
            -1 = Cool preference (feels cool, wants it warmer).

            For backwards compatibility with the v0.3 binary interface, vote=1
            maps to Warm and vote=0 maps to Neutral.
        """
        if vote not in (-1, 0, 1):
            raise ValueError(f"vote must be -1, 0, or 1, got {vote!r}")
        if vote == 1:
            self.alpha_warm += 1.0
        elif vote == 0:
            self.alpha_neutral += 1.0
        else:
            self.alpha_cool += 1.0
        self.n_votes += 1

    def decay(self, days_elapsed: float, half_life_days: float) -> None:
        """Mean-reverting exponential decay toward the aggregate prior.

        Each alpha decays as: α_i(t) = α_prior_i + (α_i − α_prior_i) · 0.5^(Δt/T½).
        A dormant user's posterior drifts back to the population baseline rather
        than to zero, so fully-inactive users look like new users, not degenerate ones.
        n_votes is decayed by the same factor so confidence degrades proportionally.

        Parameters
        ----------
        days_elapsed : float
            Days since the posterior was last updated.
        half_life_days : float
            Days after which accumulated evidence counts for half as much.
            Pass 0 to disable decay entirely.
        """
        if days_elapsed <= 0 or half_life_days <= 0:
            return
        factor = 0.5 ** (days_elapsed / half_life_days)
        prior = _PRIOR_DATA.get(self.demographic_group, _PRIOR_DATA["default"])
        self.alpha_warm = (
            prior["alpha_warm"]
            + (self.alpha_warm - prior["alpha_warm"]) * factor
        )
        self.alpha_neutral = (
            prior["alpha_neutral"]
            + (self.alpha_neutral - prior["alpha_neutral"]) * factor
        )
        self.alpha_cool = (
            prior["alpha_cool"]
            + (self.alpha_cool - prior["alpha_cool"]) * factor
        )
        self.n_votes = round(self.n_votes * factor)

    # ------------------------------------------------------------------
    # Inference
    # ------------------------------------------------------------------

    @property
    def _total(self) -> float:
        return self.alpha_warm + self.alpha_neutral + self.alpha_cool

    @property
    def p_warm(self) -> float:
        """Posterior mean probability that the user feels warm (prefers cooling)."""
        return self.alpha_warm / self._total

    @property
    def p_neutral(self) -> float:
        """Posterior mean probability that the user is comfortable."""
        return self.alpha_neutral / self._total

    @property
    def p_cool(self) -> float:
        """Posterior mean probability that the user feels cool (prefers heating)."""
        return self.alpha_cool / self._total

    @property
    def p_cooler(self) -> float:
        """Alias for p_warm — retained for v0.3 backwards compatibility."""
        return self.p_warm

    def predict(self) -> int:
        """MAP class label.

        Returns
        -------
        int
             1 when the user most likely feels Warm.
             0 when the user most likely is Neutral.
            -1 when the user most likely feels Cool.

            Ties between the two non-neutral classes are broken toward 0
            (Neutral) to avoid spurious HVAC actions.
        """
        if self.p_warm > self.p_neutral and self.p_warm > self.p_cool:
            return 1
        if self.p_cool > self.p_warm and self.p_cool > self.p_neutral:
            return -1
        return 0

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """Serialise to a plain dict (for JSON storage)."""
        return {
            "alpha_warm": self.alpha_warm,
            "alpha_neutral": self.alpha_neutral,
            "alpha_cool": self.alpha_cool,
            "n_votes": self.n_votes,
            "demographic_group": self.demographic_group,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "PersonalPosterior":
        """Deserialise from a plain dict.

        Handles both the v0.5 three-class format and the legacy v0.3 binary
        format (alpha_cooler / alpha_not_cooler).
        """
        if "alpha_warm" in d:
            return cls(
                alpha_warm=float(d["alpha_warm"]),
                alpha_neutral=float(d["alpha_neutral"]),
                alpha_cool=float(d["alpha_cool"]),
                n_votes=int(d["n_votes"]),
                demographic_group=d.get("demographic_group", "default"),
            )
        # Legacy v0.3 binary: alpha_cooler -> alpha_warm, alpha_not_cooler -> alpha_neutral
        return cls(
            alpha_warm=float(d["alpha_cooler"]),
            alpha_neutral=float(d["alpha_not_cooler"]),
            alpha_cool=float(_PRIOR_DATA["default"]["alpha_cool"]),
            n_votes=int(d["n_votes"]),
        )
