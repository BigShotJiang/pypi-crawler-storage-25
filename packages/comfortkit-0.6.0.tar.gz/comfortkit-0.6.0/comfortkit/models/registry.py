"""Model registry: name → class mapping and list_models()."""

from __future__ import annotations

from comfortkit.models.base import ComfortModel
from comfortkit.models.standard import (
    AdaptiveASHRAEComfortModel,
    CoolingEffectModel,
    SetComfortModel,
    StandardComfortModel,
)

# MLComfortModel is imported lazily so that onnxruntime is not a hard dependency
# for users who only need the standard physics model.
_REGISTRY: dict[str, type[ComfortModel]] = {
    StandardComfortModel.MODEL_ID: StandardComfortModel,
    SetComfortModel.MODEL_ID: SetComfortModel,
    AdaptiveASHRAEComfortModel.MODEL_ID: AdaptiveASHRAEComfortModel,
    CoolingEffectModel.MODEL_ID: CoolingEffectModel,
}


def _register_ml() -> None:
    """Register MLComfortModel only when onnxruntime and the ONNX file are available."""
    try:
        import onnxruntime  # noqa: F401 — probe before registering

        from comfortkit.models.ml import MLComfortModel  # noqa: PLC0415

        _REGISTRY[MLComfortModel.MODEL_ID] = MLComfortModel
    except (ImportError, FileNotFoundError):
        pass


_register_ml()


def list_models() -> list[str]:
    """Return the names of all registered comfort models.

    Returns
    -------
    list[str]
        Sorted list of model identifiers.
    """
    return sorted(_REGISTRY)


def get_model(name: str) -> ComfortModel:
    """Instantiate a registered model by name.

    Parameters
    ----------
    name : str
        Model identifier as returned by :func:`list_models`.

    Returns
    -------
    ComfortModel
        A fresh instance of the requested model.

    Raises
    ------
    KeyError
        When *name* is not in the registry.
    """
    if name not in _REGISTRY:
        msg = f"Unknown model {name!r}. Available: {list_models()}"
        if name in ("ml", "ml_pmv"):
            msg += " (hint: pip install comfortkit[ml] to enable the ML correction model)"
        raise KeyError(msg)
    return _REGISTRY[name]()
