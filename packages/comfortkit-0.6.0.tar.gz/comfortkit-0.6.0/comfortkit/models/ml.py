"""ML correction layer: LightGBM residual model loaded via ONNX Runtime.

Uses :class:`StandardComfortModel` for the physics baseline, then applies a
learned (TSV − PMV) residual correction derived from the ASHRAE Global Thermal
Comfort Database II.

The ONNX model and its feature-encoding metadata live in the same directory as
this file (``pmv_correction.onnx`` and ``pmv_correction_meta.json``), produced
by ``ml/train.py``.
"""

from __future__ import annotations

import json
from dataclasses import replace
from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np

from comfortkit.models.base import ComfortInputs, ComfortModel, ComfortResult
from comfortkit.models.standard import StandardComfortModel

if TYPE_CHECKING:
    import onnxruntime as ort  # type: ignore[import-untyped]

_MODEL_DIR = Path(__file__).parent
_ONNX_PATH = _MODEL_DIR / "pmv_correction.onnx"
_META_PATH = _MODEL_DIR / "pmv_correction_meta.json"


def _load_meta() -> dict:  # type: ignore[type-arg]
    return json.loads(_META_PATH.read_text())


def _encode_cooling(strategy: str | None, cooling_map: dict[str, int]) -> int:
    if strategy is None:
        return len(cooling_map)  # "Unknown" bucket
    return cooling_map.get(strategy, len(cooling_map))


def _encode_building(building: str | None, building_map: dict[str, int]) -> int:
    if building is None:
        return building_map.get("Unknown", len(building_map))
    return building_map.get(building, building_map.get("Unknown", len(building_map)))


class MLComfortModel(ComfortModel):
    """PMV + learned residual correction (v0.2).

    Loads a pre-trained LightGBM model (serialised as ONNX) and a feature-
    encoding metadata file.  On each :meth:`predict` call it:

    1. Runs :class:`~comfortkit.models.standard.StandardComfortModel` for the
       physics baseline (PMV, PPD, CI, warnings).
    2. Builds a 10-feature vector and queries the ONNX model for the residual.
    3. Adds the residual to PMV and recomputes PPD and the sensation label.

    Parameters
    ----------
    onnx_path : Path or None
        Override path to the ``.onnx`` file.  Defaults to the bundled model.
    meta_path : Path or None
        Override path to the ``_meta.json`` file.
    """

    MODEL_ID = "ml_pmv"

    def __init__(
        self,
        onnx_path: Path | None = None,
        meta_path: Path | None = None,
    ) -> None:
        try:
            import onnxruntime as ort  # type: ignore[import-untyped]
        except ImportError as exc:
            raise ImportError(
                "onnxruntime is required for the ML correction model. "
                "Install it with: pip install comfortkit[ml]"
            ) from exc

        onnx_path = onnx_path or _ONNX_PATH
        meta_path = meta_path or _META_PATH

        if not onnx_path.exists():
            raise FileNotFoundError(
                f"ONNX model not found at {onnx_path}. "
                "Run ml/train.py to generate it."
            )

        self._session: ort.InferenceSession = ort.InferenceSession(str(onnx_path))
        self._input_name: str = self._session.get_inputs()[0].name
        self._meta = _load_meta()
        self._cooling_map: dict[str, int] = self._meta["cooling_map"]
        self._building_map: dict[str, int] = self._meta["building_map"]
        self._t_out_fill: float = float(self._meta["t_out_fill"])
        self._standard_model = StandardComfortModel()

    def _build_feature_row(
        self,
        inputs: ComfortInputs,
        pmv: float,
    ) -> np.ndarray:
        """Build the 10-feature input vector for the ONNX model."""
        tr_eff = inputs.tr  # tr is always present
        t_out = inputs.t_out if inputs.t_out is not None else self._t_out_fill
        cooling_enc = _encode_cooling(inputs.cooling_strategy, self._cooling_map)
        building_enc = _encode_building(inputs.building_type, self._building_map)

        return np.array(
            [[pmv, inputs.ta, tr_eff, inputs.vel, inputs.rh,
              inputs.met, inputs.clo, t_out, cooling_enc, building_enc]],
            dtype=np.float32,
        )

    def _ppd_from_pmv(self, pmv: float) -> float:
        """ISO 7730 PPD formula: 100 − 95·exp(−0.03353·pmv⁴ − 0.2179·pmv²)."""
        val = 100.0 - 95.0 * np.exp(-0.03353 * pmv ** 4 - 0.2179 * pmv ** 2)
        return round(float(np.clip(val, 5.0, 100.0)), 2)

    def predict(self, inputs: ComfortInputs) -> ComfortResult:
        """Predict corrected PMV/PPD for a single set of inputs.

        Parameters
        ----------
        inputs : ComfortInputs
            Validated input conditions. Optional fields ``t_out``,
            ``cooling_strategy``, and ``building_type`` improve accuracy.

        Returns
        -------
        ComfortResult
            ML-corrected PMV/PPD with CI and warnings from the standard model.
        """
        base = self._standard_model.predict(inputs)

        if base.pmv is None:
            return replace(base, model=self.MODEL_ID)

        feat = self._build_feature_row(inputs, base.pmv)
        residual = float(self._session.run(None, {self._input_name: feat})[0].flat[0])

        corrected_pmv = round(base.pmv + residual, 2)
        corrected_ppd = self._ppd_from_pmv(corrected_pmv)

        from comfortkit.models.standard import _is_compliant, _pmv_to_sensation  # noqa: PLC0415

        return ComfortResult(
            pmv=corrected_pmv,
            ppd=corrected_ppd,
            sensation=_pmv_to_sensation(corrected_pmv),
            compliant=_is_compliant(corrected_pmv),
            model=self.MODEL_ID,
            ci_95=base.ci_95,
            warnings=base.warnings,
        )

    def predict_batch(self, inputs: list[ComfortInputs]) -> list[ComfortResult]:
        """Predict corrected PMV/PPD for a list of inputs.

        Parameters
        ----------
        inputs : list[ComfortInputs]
            List of validated input conditions.

        Returns
        -------
        list[ComfortResult]
            One corrected result per input, in the same order.
        """
        base_results = self._standard_model.predict_batch(inputs)

        rows = []
        valid_idx = []
        for i, (inp, base) in enumerate(zip(inputs, base_results)):
            if base.pmv is not None:
                rows.append(self._build_feature_row(inp, base.pmv)[0])
                valid_idx.append(i)

        results = list(base_results)

        if rows:
            batch = np.stack(rows, axis=0).astype(np.float32)
            residuals = self._session.run(None, {self._input_name: batch})[0].flatten()

            from comfortkit.models.standard import _is_compliant, _pmv_to_sensation  # noqa: PLC0415

            for j, i in enumerate(valid_idx):
                base = base_results[i]
                corrected_pmv = round(base.pmv + float(residuals[j]), 2)  # type: ignore[operator]
                corrected_ppd = self._ppd_from_pmv(corrected_pmv)
                results[i] = ComfortResult(
                    pmv=corrected_pmv,
                    ppd=corrected_ppd,
                    sensation=_pmv_to_sensation(corrected_pmv),
                    compliant=_is_compliant(corrected_pmv),
                    model=self.MODEL_ID,
                    ci_95=base.ci_95,
                    warnings=base.warnings,
                )

        return results
