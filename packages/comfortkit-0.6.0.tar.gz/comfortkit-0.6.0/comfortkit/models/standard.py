"""Adapter over pythermalcomfort for PMV/PPD, SET, and adaptive models."""

from __future__ import annotations

from pythermalcomfort.models import (  # type: ignore[import-untyped]
    adaptive_ashrae,
    cooling_effect as _cooling_effect,
    pmv_ppd_ashrae,
    pmv_ppd_iso,
    set_tmp,
)
from pythermalcomfort.utilities import operative_tmp  # type: ignore[import-untyped]

from comfortkit._constants import (
    SENSATION_SCALE,
    SET_COMFORT_ZONE,
    SET_SENSATION_THRESHOLDS,
)
from comfortkit.models.base import (
    ComfortInputError,
    ComfortInputs,
    ComfortModel,
    ComfortResult,
)
from comfortkit.uncertainty import bootstrap_ci, conformal_ci
from comfortkit.validation import check_applicability


def _pmv_to_sensation(pmv: float) -> str:
    """Map a continuous PMV value to the nearest 7-point scale label."""
    rounded = max(-3, min(3, round(pmv)))
    return SENSATION_SCALE[int(rounded)]


def _is_compliant(pmv: float | None) -> bool:
    """Return True when PMV is within the standard's acceptable comfort band (±0.5)."""
    if pmv is None:
        return False
    return abs(pmv) <= 0.5


class StandardComfortModel(ComfortModel):
    """Thin adapter over pythermalcomfort.

    Translates :class:`~comfortkit.models.base.ComfortInputs` →
    pythermalcomfort arguments, calls the appropriate function, and translates
    the output back to :class:`~comfortkit.models.base.ComfortResult`.

    Does not reimplement PMV/PPD maths — pythermalcomfort owns the physics.
    """

    MODEL_ID = "standard_pmv"

    def predict(self, inputs: ComfortInputs) -> ComfortResult:
        """Predict PMV/PPD for a single set of inputs.

        Parameters
        ----------
        inputs : ComfortInputs
            Validated input conditions.

        Returns
        -------
        ComfortResult
            PMV, PPD, sensation label, compliance flag, and applicability warnings.
        """
        warnings = check_applicability(inputs)

        # limit_inputs=False: applicability is our responsibility (we append warnings
        # rather than returning NaN). pythermalcomfort 3.9 split the old pmv_ppd()
        # into two standard-specific functions.
        kwargs = dict(
            tdb=inputs.ta,
            tr=inputs.tr,
            vr=inputs.vel,
            rh=inputs.rh,
            met=inputs.met,
            clo=inputs.clo,
            limit_inputs=False,
        )
        raw = pmv_ppd_iso(**kwargs) if inputs.standard == "iso" else pmv_ppd_ashrae(**kwargs)

        pmv = round(float(raw.pmv), 2)
        ppd = round(float(raw.ppd), 2)

        return ComfortResult(
            pmv=pmv,
            ppd=ppd,
            sensation=_pmv_to_sensation(pmv),
            compliant=_is_compliant(pmv),
            model=self.MODEL_ID,
            ci_95=bootstrap_ci(inputs),
            conformal_ci_95=conformal_ci(pmv),
            warnings=warnings,
        )

    def predict_batch(self, inputs: list[ComfortInputs]) -> list[ComfortResult]:
        """Predict PMV/PPD for a list of inputs.

        Parameters
        ----------
        inputs : list[ComfortInputs]
            List of validated input conditions.

        Returns
        -------
        list[ComfortResult]
            One result per input, in the same order.
        """
        return [self.predict(inp) for inp in inputs]


# ---------------------------------------------------------------------------
# SET helpers
# ---------------------------------------------------------------------------

def _set_to_sensation(set_val: float) -> str:
    """Map a SET temperature (°C) to the nearest 7-point sensation label."""
    for threshold, label in SET_SENSATION_THRESHOLDS:
        if set_val < threshold:
            return label
    return "hot"


def _set_is_compliant(set_val: float) -> bool:
    """Return True when SET is within the ASHRAE 55 comfort zone (22.2–25.6 °C)."""
    lo, hi = SET_COMFORT_ZONE
    return lo <= set_val <= hi


class SetComfortModel(ComfortModel):
    """Standard Effective Temperature adapter over pythermalcomfort.

    Calls :func:`~pythermalcomfort.models.set_tmp` and translates the result
    into a :class:`~comfortkit.models.base.ComfortResult`.  PMV and PPD are
    ``None`` (SET is a temperature, not a vote scale); the SET value is stored
    in ``result.set_tmp``.  The 95 % CI is not yet implemented for SET.
    """

    MODEL_ID = "set"

    def predict(self, inputs: ComfortInputs) -> ComfortResult:
        """Predict Standard Effective Temperature for a single set of inputs.

        Parameters
        ----------
        inputs : ComfortInputs
            Validated input conditions.

        Returns
        -------
        ComfortResult
            SET value in ``result.set_tmp``, sensation label, compliance flag,
            and applicability warnings.
        """
        warnings = check_applicability(inputs)

        raw = set_tmp(
            tdb=inputs.ta,
            tr=inputs.tr,
            v=inputs.vel,
            rh=inputs.rh,
            met=inputs.met,
            clo=inputs.clo,
            limit_inputs=False,
        )
        set_val = round(float(raw.set), 2)

        return ComfortResult(
            pmv=None,
            ppd=None,
            sensation=_set_to_sensation(set_val),
            compliant=_set_is_compliant(set_val),
            model=self.MODEL_ID,
            set_tmp=set_val,
            ci_95=None,
            warnings=warnings,
        )

    def predict_batch(self, inputs: list[ComfortInputs]) -> list[ComfortResult]:
        """Predict SET for a list of inputs.

        Parameters
        ----------
        inputs : list[ComfortInputs]
            List of validated input conditions.

        Returns
        -------
        list[ComfortResult]
            One result per input, in the same order.
        """
        return [self.predict(inp) for inp in inputs]


# ---------------------------------------------------------------------------
# Adaptive ASHRAE 55 helpers
# ---------------------------------------------------------------------------

def _adaptive_sensation(top: float, lo_80: float, hi_80: float) -> str:
    """Map operative temperature vs. 80 % comfort band to a sensation label."""
    if top < lo_80:
        return "cool"
    if top > hi_80:
        return "warm"
    return "neutral"


class AdaptiveASHRAEComfortModel(ComfortModel):
    """Adaptive thermal comfort adapter (ASHRAE 55) over pythermalcomfort.

    Calls :func:`~pythermalcomfort.models.adaptive_ashrae` and translates the
    result into a :class:`~comfortkit.models.base.ComfortResult`.  PMV and PPD
    are ``None`` (the adaptive model does not produce them); compliance is
    based on the 80 % acceptability criterion.

    Requires :attr:`~comfortkit.models.base.ComfortInputs.t_running_mean` to
    be set on the input object.
    """

    MODEL_ID = "adaptive_ashrae"

    # ASHRAE 55 applicability limit for running-mean outdoor temperature
    _T_RM_RANGE: tuple[float, float] = (10.0, 33.5)

    def predict(self, inputs: ComfortInputs) -> ComfortResult:
        """Predict adaptive thermal comfort for a single set of inputs.

        Parameters
        ----------
        inputs : ComfortInputs
            Validated input conditions.  ``t_running_mean`` must not be
            ``None``.

        Returns
        -------
        ComfortResult
            Compliance flag (80 % acceptability), sensation label, and
            applicability warnings.

        Raises
        ------
        ComfortInputError
            When ``inputs.t_running_mean`` is ``None``.
        """
        if inputs.t_running_mean is None:
            raise ComfortInputError(
                "t_running_mean is required for the adaptive_ashrae model. "
                "Pass the prevailing mean outdoor temperature (°C) via "
                "ComfortInputs(t_running_mean=...)."
            )

        warnings: list[str] = []
        lo, hi = self._T_RM_RANGE
        if not (lo <= inputs.t_running_mean <= hi):
            warnings.append(
                f"t_running_mean={inputs.t_running_mean} is outside the ASHRAE 55 "
                f"applicability range [{lo}, {hi}]; result may be unreliable."
            )

        raw = adaptive_ashrae(
            tdb=inputs.ta,
            tr=inputs.tr,
            t_running_mean=inputs.t_running_mean,
            v=inputs.vel,
            limit_inputs=False,
        )

        t_cmf = float(raw.tmp_cmf)
        base_upper_80 = round(t_cmf + 3.5, 1)
        base_upper_90 = round(t_cmf + 2.5, 1)
        lo_80 = float(raw.tmp_cmf_80_low)
        lo_90 = float(raw.tmp_cmf_90_low)

        # Cooling-effect (CE) correction: pythermalcomfort 3.9.2 applies CE
        # whenever to >= 25 °C, but ASHRAE 55 only permits CE when the base
        # upper comfort boundary is already >= 25 °C.  When the base boundary
        # is below 25 °C we strip the CE and recompute acceptability.
        # (Mirrors the fix in CBE comfort_tool PR #91.)
        ce_applied = float(raw.tmp_cmf_80_up) > base_upper_80
        if ce_applied and base_upper_80 < 25.0:
            hi_80 = base_upper_80
            hi_90 = base_upper_90
            to = float(
                operative_tmp(inputs.ta, inputs.tr, inputs.vel, standard="ashrae")
            )
            compliant = bool(lo_80 <= to <= hi_80)
            warnings.append(
                f"Cooling effect from elevated air speed (v={inputs.vel} m/s) "
                f"suppressed: base upper comfort boundary ({base_upper_80:.1f} °C) "
                f"is below 25 °C (ASHRAE 55; pythermalcomfort CE fix)."
            )
        else:
            hi_80 = float(raw.tmp_cmf_80_up)
            hi_90 = float(raw.tmp_cmf_90_up)
            compliant = bool(raw.acceptability_80)
            to = float(
                operative_tmp(inputs.ta, inputs.tr, inputs.vel, standard="ashrae")
            )

        return ComfortResult(
            pmv=None,
            ppd=None,
            sensation=_adaptive_sensation(to, lo_80, hi_80),
            compliant=compliant,
            model=self.MODEL_ID,
            ci_95=None,
            warnings=warnings,
        )

    def predict_batch(self, inputs: list[ComfortInputs]) -> list[ComfortResult]:
        """Predict adaptive thermal comfort for a list of inputs.

        Parameters
        ----------
        inputs : list[ComfortInputs]
            List of validated input conditions.

        Returns
        -------
        list[ComfortResult]
            One result per input, in the same order.
        """
        return [self.predict(inp) for inp in inputs]


# ---------------------------------------------------------------------------
# Cooling Effect (ASHRAE 55 Appendix G) — elevated air speed / ceiling fans
# ---------------------------------------------------------------------------


class CoolingEffectModel(ComfortModel):
    """ASHRAE 55 Cooling Effect adapter for elevated air speed and ceiling fans.

    Computes the Cooling Effect (CE) — the equivalent still-air temperature
    reduction provided by elevated air speed per ASHRAE 55 Appendix G — and
    returns it alongside a standard PMV/PPD prediction at the actual
    (elevated-air-speed) conditions.

    A positive CE means the fan allows raising the cooling setpoint by CE °C
    while maintaining equivalent thermal comfort.  CE is zero for
    ``vel`` ≤ 0.1 m/s (pythermalcomfort threshold).

    Parameters passed to ``ComfortInputs.vel`` should be the *relative* air
    speed (vr): sensor-measured speed plus the activity-generated component.
    Use ``pythermalcomfort.utilities.v_relative(v, met)`` to convert from
    measured speed when needed.
    """

    MODEL_ID = "cooling_effect"

    # ASHRAE 55 / pythermalcomfort: CE is 0 at or below this threshold
    _VEL_THRESHOLD: float = 0.1

    def predict(self, inputs: ComfortInputs) -> ComfortResult:
        """Predict PMV/PPD and Cooling Effect for a single set of inputs.

        Parameters
        ----------
        inputs : ComfortInputs
            Validated input conditions.  ``vel`` is interpreted as the
            relative air speed (vr) per ASHRAE 55 Appendix G.

        Returns
        -------
        ComfortResult
            PMV, PPD, sensation, compliance, and ``cooling_effect`` (°C).
            A warning is appended when ``vel`` ≤ 0.1 m/s.
        """
        warnings = check_applicability(inputs)

        if inputs.vel <= self._VEL_THRESHOLD:
            warnings.append(
                f"vel={inputs.vel} m/s is at or below the 0.1 m/s threshold; "
                "cooling effect is zero (no elevated air speed benefit)."
            )

        ce_raw = _cooling_effect(
            tdb=inputs.ta,
            tr=inputs.tr,
            vr=inputs.vel,
            rh=inputs.rh,
            met=inputs.met,
            clo=inputs.clo,
        )
        ce = round(float(ce_raw.ce), 2)

        raw = pmv_ppd_ashrae(
            tdb=inputs.ta,
            tr=inputs.tr,
            vr=inputs.vel,
            rh=inputs.rh,
            met=inputs.met,
            clo=inputs.clo,
            limit_inputs=False,
        )
        pmv = round(float(raw.pmv), 2)
        ppd = round(float(raw.ppd), 2)

        return ComfortResult(
            pmv=pmv,
            ppd=ppd,
            sensation=_pmv_to_sensation(pmv),
            compliant=_is_compliant(pmv),
            model=self.MODEL_ID,
            cooling_effect=ce,
            ci_95=bootstrap_ci(inputs),
            warnings=warnings,
        )

    def predict_batch(self, inputs: list[ComfortInputs]) -> list[ComfortResult]:
        """Predict PMV/PPD and Cooling Effect for a list of inputs.

        Parameters
        ----------
        inputs : list[ComfortInputs]
            List of validated input conditions.

        Returns
        -------
        list[ComfortResult]
            One result per input, in the same order.
        """
        return [self.predict(inp) for inp in inputs]
