"""Zone-level thermal comfort aggregation across co-present occupants.

Each occupant has a Dirichlet-Multinomial (K=3) posterior over their three-class
preference (1 = Warm / feels warm, 0 = Neutral / comfortable, -1 = Cool / feels
cool).  The ZoneAggregator combines individual posteriors into a single zone-level
HVAC action recommendation using one of three strategies.

Strategy semantics
------------------
mean_p_warm     Average P(Warm) across co-present users; acts when the warm mean
                exceeds an upper threshold (>0.5 → lower_setpoint) or the cool
                mean exceeds a lower threshold (mean_p_cool >0.35 →
                raise_setpoint), else maintain.
majority_vote   Each user's MAP label (Warm / Neutral / Cool) is tallied; a
                strict majority of Warm → lower_setpoint, strict majority of
                Cool → raise_setpoint, else maintain.
any_discomfort  Symmetric: flags lower_setpoint if any user's P(Warm) exceeds
                the configured threshold (default 0.7); flags raise_setpoint if
                any user's P(Cool) exceeds the same threshold.

Three-class model (v0.5)
------------------------
Prior to v0.5, the personal model was binary (Warm / Not Warm), which conflated
neutral comfort with cold preference.  A user with many neutral votes accumulated
a low P(Warm), making them indistinguishable from a user who genuinely preferred
heating.  Validated on ENTH data: enth01 (16 neutral votes) pulled zone mean
P(Warm) to ~0.26, triggering spurious raise_setpoint recommendations even when
the majority of observed votes were warm.

The Dirichlet-Multinomial (K=3) model (v0.5) estimates P(Warm), P(Neutral), and
P(Cool) independently.  Neutral-heavy users have high P(Neutral), near-prior
P(Warm) (~0.37) and near-prior P(Cool) (~0.06) — correctly excluded from both
the lower- and raise-setpoint signals.  mean_p_warm and majority_vote are now
reliable without requiring the any_discomfort workaround.

Validation scope
----------------
ZoneAggregator was validated on 3 distinct 3-user co-occupancy configurations
from the ENTH longitudinal dataset (NUS, Mar–Apr 2021).  All events fall on
3 calendar days in one building cluster.  Results are a plausibility check
and existence proof only — no statistical inference is possible from this
sample.  See ml/validate_zone.py for the full validation protocol.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

from comfortkit.models.personal import PersonalPosterior

Strategy = Literal["mean_p_warm", "majority_vote", "any_discomfort"]
Action = Literal["lower_setpoint", "raise_setpoint", "maintain"]

_LABEL = {1: "Warm", 0: "Neutral", -1: "Cool"}


@dataclass
class ZoneUserSummary:
    """Per-user breakdown included in every ZoneComfortResult.

    Parameters
    ----------
    p_warm : float
        P(Warm) from the user's personal posterior.
    p_cool : float
        P(Cool) from the user's personal posterior.
    prediction_label : str
        "Warm", "Neutral", or "Cool" from the MAP prediction.
    n_votes : int
        Number of real votes that shaped this posterior (0 = prior only).
    """

    p_warm: float
    p_cool: float
    prediction_label: str
    n_votes: int


@dataclass
class ZoneComfortResult:
    """Aggregated zone comfort prediction.

    Parameters
    ----------
    action : {"lower_setpoint", "raise_setpoint", "maintain"}
        Recommended HVAC action.
    strategy : str
        Strategy that produced this result.
    mean_p_warm : float
        Mean P(Warm) across all co-present users.
    mean_p_cool : float
        Mean P(Cool) across all co-present users.
    fraction_warm : float
        Fraction of users whose MAP prediction is "Warm".
    n_users : int
        Number of users in the aggregation.
    per_user : dict[str, ZoneUserSummary]
        Per-user p_warm, p_cool, label, and vote count.
    confidence : {"low", "medium", "high"}
        Based on average votes per user (low <10, medium <50, high >=50).
    warnings : list[str]
        Non-fatal notices about data quality or edge cases.
    """

    action: Action
    strategy: Strategy
    mean_p_warm: float
    mean_p_cool: float
    fraction_warm: float
    n_users: int
    per_user: dict[str, ZoneUserSummary]
    confidence: Literal["low", "medium", "high"]
    warnings: list[str] = field(default_factory=list)


class ZoneAggregator:
    """Aggregate per-user comfort posteriors into a zone-level HVAC recommendation.

    Parameters
    ----------
    strategy : {"mean_p_warm", "majority_vote", "any_discomfort"}
        Aggregation rule.  See module docstring for semantics.
    any_discomfort_threshold : float
        P threshold for the any_discomfort strategy.  A user whose P(Warm) or
        P(Cool) exceeds this value triggers lower_setpoint or raise_setpoint
        respectively.  Default 0.7.
    mean_upper_threshold : float
        Mean P(Warm) above which mean_p_warm strategy recommends lower_setpoint.
        Default 0.5 (strict majority feel warm).
    mean_lower_threshold : float
        Mean P(Cool) above which mean_p_warm strategy recommends raise_setpoint.
        Default 0.35 (substantially above the prior P(Cool) ≈ 0.06).
    """

    def __init__(
        self,
        strategy: Strategy = "mean_p_warm",
        any_discomfort_threshold: float = 0.7,
        mean_upper_threshold: float = 0.5,
        mean_lower_threshold: float = 0.35,
    ) -> None:
        self.strategy = strategy
        self.any_discomfort_threshold = any_discomfort_threshold
        self.mean_upper_threshold = mean_upper_threshold
        self.mean_lower_threshold = mean_lower_threshold

    def predict(
        self,
        users: dict[str, PersonalPosterior],
        zone_temp: float | None = None,  # noqa: ARG002 — reserved for future physics coupling
    ) -> ZoneComfortResult:
        """Predict the zone-level comfort action.

        Parameters
        ----------
        users : dict[str, PersonalPosterior]
            Mapping of user_id → current personal posterior for every occupant
            currently present in the zone.
        zone_temp : float or None
            Current zone air temperature (°C).  Stored for traceability; not
            yet used in the aggregation calculation.

        Returns
        -------
        ZoneComfortResult
            Zone-level recommendation with per-user breakdown.

        Raises
        ------
        ValueError
            When *users* is empty.
        """
        if not users:
            raise ValueError("users dict must not be empty")

        per_user: dict[str, ZoneUserSummary] = {}
        p_warms: list[float] = []
        p_cools: list[float] = []
        n_warm = 0
        n_cool = 0

        for uid, posterior in users.items():
            p_warm = posterior.p_warm
            p_cool = posterior.p_cool
            pred = posterior.predict()
            per_user[uid] = ZoneUserSummary(
                p_warm=round(p_warm, 4),
                p_cool=round(p_cool, 4),
                prediction_label=_LABEL[pred],
                n_votes=posterior.n_votes,
            )
            p_warms.append(p_warm)
            p_cools.append(p_cool)
            if pred == 1:
                n_warm += 1
            elif pred == -1:
                n_cool += 1

        n = len(users)
        mean_p_warm = sum(p_warms) / n
        mean_p_cool = sum(p_cools) / n
        fraction_warm = n_warm / n

        match self.strategy:
            case "mean_p_warm":
                action = self._action_from_mean(mean_p_warm, mean_p_cool)
            case "majority_vote":
                action = self._action_from_majority(n_warm, n_cool, n)
            case "any_discomfort":
                action = self._action_from_any(p_warms, p_cools)

        avg_votes = sum(p.n_votes for p in users.values()) / n
        confidence: Literal["low", "medium", "high"]
        if avg_votes >= 50:
            confidence = "high"
        elif avg_votes >= 10:
            confidence = "medium"
        else:
            confidence = "low"

        warnings: list[str] = []
        if n < 2:
            warnings.append(
                "Only one user in zone; aggregation is equivalent to single-user prediction."
            )
        if all(p.n_votes == 0 for p in users.values()):
            warnings.append(
                "All posteriors are at the global prior; predictions reflect aggregate "
                "population preference, not individual comfort histories."
            )

        return ZoneComfortResult(
            action=action,
            strategy=self.strategy,
            mean_p_warm=round(mean_p_warm, 4),
            mean_p_cool=round(mean_p_cool, 4),
            fraction_warm=round(fraction_warm, 4),
            n_users=n,
            per_user=per_user,
            confidence=confidence,
            warnings=warnings,
        )

    # ------------------------------------------------------------------
    # Private action helpers
    # ------------------------------------------------------------------

    def _action_from_mean(self, mean_p_warm: float, mean_p_cool: float) -> Action:
        if mean_p_warm > self.mean_upper_threshold:
            return "lower_setpoint"
        if mean_p_cool > self.mean_lower_threshold:
            return "raise_setpoint"
        return "maintain"

    def _action_from_majority(self, n_warm: int, n_cool: int, n: int) -> Action:
        if n_warm > n / 2:
            return "lower_setpoint"
        if n_cool > n / 2:
            return "raise_setpoint"
        return "maintain"

    def _action_from_any(self, p_warms: list[float], p_cools: list[float]) -> Action:
        if any(p > self.any_discomfort_threshold for p in p_warms):
            return "lower_setpoint"
        if any(p > self.any_discomfort_threshold for p in p_cools):
            return "raise_setpoint"
        return "maintain"
