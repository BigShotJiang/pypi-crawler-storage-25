"""Core abstractions: ComfortModel ABC, ComfortInputs, ComfortResult."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Literal

from pydantic import BaseModel, field_validator


class ComfortInputError(ValueError):
    """Raised for physically impossible input values (e.g. rh > 100, vel < 0)."""


class ComfortInputs(BaseModel):
    """Typed inputs for a thermal comfort prediction.

    Parameters
    ----------
    ta : float
        Air temperature (°C).
    tr : float
        Mean radiant temperature (°C).
    vel : float
        Air velocity (m/s). Must be >= 0.
    rh : float
        Relative humidity (%). Must be in [0, 100].
    met : float
        Metabolic rate (met). Must be > 0.
    clo : float
        Clothing insulation (clo). Must be >= 0.
    standard : {"ashrae", "iso"}
        Which standard's applicability limits to apply. Defaults to "ashrae".
    t_out : float or None
        Outdoor monthly mean air temperature (°C). Used by the ML correction
        model to capture adaptive-comfort effects; ignored by the standard model.
    cooling_strategy : str or None
        Building-level cooling strategy (e.g. "Naturally Ventilated",
        "Air Conditioned", "Mixed Mode", "Mechanically Ventilated").
        Used by the ML correction model; ignored by the standard model.
    building_type : str or None
        Building use type (e.g. "Office", "Classroom"). Used by the ML
        correction model; ignored by the standard model.
    """

    ta: float
    tr: float
    vel: float
    rh: float
    met: float
    clo: float
    standard: Literal["ashrae", "iso"] = "ashrae"
    t_out: float | None = None
    cooling_strategy: str | None = None
    building_type: str | None = None
    t_running_mean: float | None = None

    @field_validator("vel")
    @classmethod
    def _vel_non_negative(cls, v: float) -> float:
        if v < 0:
            raise ComfortInputError(f"vel must be >= 0, got {v}")
        return v

    @field_validator("rh")
    @classmethod
    def _rh_in_range(cls, v: float) -> float:
        if not (0 <= v <= 100):
            raise ComfortInputError(f"rh must be in [0, 100], got {v}")
        return v

    @field_validator("met")
    @classmethod
    def _met_positive(cls, v: float) -> float:
        if v <= 0:
            raise ComfortInputError(f"met must be > 0, got {v}")
        return v

    @field_validator("clo")
    @classmethod
    def _clo_non_negative(cls, v: float) -> float:
        if v < 0:
            raise ComfortInputError(f"clo must be >= 0, got {v}")
        return v


@dataclass
class ComfortResult:
    """Result of a thermal comfort prediction.

    Parameters
    ----------
    pmv : float or None
        Predicted Mean Vote (-3 to +3). None when the model does not produce PMV.
    ppd : float or None
        Predicted Percentage Dissatisfied (%). None when not produced.
    sensation : str
        Human-readable label on the 7-point ASHRAE sensation scale
        ("cold", "cool", "slightly cool", "neutral", "slightly warm", "warm", "hot").
    compliant : bool
        True when the prediction falls within the standard's acceptable comfort range.
    model : str
        Identifier of the model that produced this result.
    ci_95 : tuple[float, float] or None
        95 % bootstrap confidence interval on PMV (lower, upper).
        None when uncertainty was not requested.
    warnings : list[str]
        Non-fatal applicability-limit violations. Prediction is still returned.
    """

    pmv: float | None
    ppd: float | None
    sensation: str
    compliant: bool
    model: str
    ci_95: tuple[float, float] | None = None
    set_tmp: float | None = None
    conformal_ci_95: tuple[float, float] | None = None
    cooling_effect: float | None = None
    warnings: list[str] = field(default_factory=list)


class ComfortModel(ABC):
    """Abstract base class for all thermal comfort models.

    Both the physics adapter (StandardComfortModel) and the v0.2 ML model
    implement this interface.  The ABC must not change between versions.
    """

    @abstractmethod
    def predict(self, inputs: ComfortInputs) -> ComfortResult:
        """Return a comfort prediction for a single set of inputs.

        Parameters
        ----------
        inputs : ComfortInputs
            Validated input conditions.

        Returns
        -------
        ComfortResult
            Prediction with optional uncertainty bounds and warnings.
        """
        ...

    @abstractmethod
    def predict_batch(self, inputs: list[ComfortInputs]) -> list[ComfortResult]:
        """Return comfort predictions for a list of inputs.

        Parameters
        ----------
        inputs : list[ComfortInputs]
            List of validated input conditions.

        Returns
        -------
        list[ComfortResult]
            One result per input, in the same order.
        """
        ...
