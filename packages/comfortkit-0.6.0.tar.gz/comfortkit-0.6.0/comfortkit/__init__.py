"""comfortkit — thermal comfort prediction with uncertainty bounds.

Public API
----------
predict(inputs, *, model, ...)      → ComfortResult
predict_batch(inputs, *, model)     → list[ComfortResult]
list_models()                       → list[str]

Two calling styles are supported for predict():

    # keyword-argument style (README quick-start)
    predict(model="pmv", ta=22.0, tr=22.0, vel=0.1, rh=60.0, met=1.2, clo=0.5)

    # ComfortInputs object style
    predict(ComfortInputs(ta=22.0, ...), model="pmv")
"""

from __future__ import annotations

from typing import Literal

from comfortkit.models.base import ComfortInputError, ComfortInputs, ComfortResult
from comfortkit.models.registry import get_model, list_models
from comfortkit.models.standard import StandardComfortModel

__version__ = "0.5.1"

# Short alias → canonical MODEL_ID.  Kept here so list_models() stays clean.
_MODEL_ALIASES: dict[str, str] = {
    "pmv": StandardComfortModel.MODEL_ID,
    "ml": "ml_pmv",
    "adaptive": "adaptive_ashrae",
}


def _resolve_model(name: str) -> str:
    return _MODEL_ALIASES.get(name, name)


def predict(
    inputs: ComfortInputs | None = None,
    /,
    *,
    model: str = "pmv",
    ta: float | None = None,
    tr: float | None = None,
    vel: float | None = None,
    rh: float | None = None,
    met: float | None = None,
    clo: float | None = None,
    standard: Literal["ashrae", "iso"] = "ashrae",
) -> ComfortResult:
    """Predict thermal comfort for a single set of inputs.

    Two calling styles are supported:

    **Keyword-argument style** (README quick-start)::

        result = predict(model="pmv", ta=22.0, tr=22.0, vel=0.1,
                         rh=60.0, met=1.2, clo=0.5)

    **ComfortInputs object style**::

        result = predict(ComfortInputs(ta=22.0, ...), model="pmv")

    Parameters
    ----------
    inputs : ComfortInputs, optional
        Pre-constructed inputs object.  When supplied, the ``ta``/``tr``/
        ``vel``/``rh``/``met``/``clo``/``standard`` keyword arguments are
        ignored.
    model : str
        Model identifier.  ``"pmv"`` (alias for ``"standard_pmv"``) is the
        only option in v0.1.  Use :func:`list_models` to see all available.
    ta, tr, vel, rh, met, clo : float
        Input conditions.  Required when *inputs* is not supplied.
    standard : {"ashrae", "iso"}
        Applicability limits.  Only used in the keyword-argument style.

    Returns
    -------
    ComfortResult
        PMV, PPD, sensation, compliance flag, 95 % CI, and warnings.

    Raises
    ------
    TypeError
        When called in kwargs style with one or more fields missing.
    KeyError
        When *model* is not a recognised identifier.
    """
    if inputs is None:
        missing = [
            k for k, v in
            dict(ta=ta, tr=tr, vel=vel, rh=rh, met=met, clo=clo).items()
            if v is None
        ]
        if missing:
            raise TypeError(
                f"predict() missing required keyword argument(s): {missing}"
            )
        inputs = ComfortInputs(  # type: ignore[arg-type]
            ta=ta, tr=tr, vel=vel, rh=rh, met=met, clo=clo, standard=standard,
        )
    return get_model(_resolve_model(model)).predict(inputs)


def predict_batch(
    inputs: list[ComfortInputs],
    *,
    model: str = "pmv",
) -> list[ComfortResult]:
    """Predict thermal comfort for a list of inputs.

    Parameters
    ----------
    inputs : list[ComfortInputs]
        List of validated input conditions.
    model : str
        Model identifier.  Defaults to ``"pmv"``.

    Returns
    -------
    list[ComfortResult]
        One result per input, in the same order.
    """
    return get_model(_resolve_model(model)).predict_batch(inputs)


__all__ = [
    "ComfortInputError",
    "ComfortInputs",
    "ComfortResult",
    "predict",
    "predict_batch",
    "list_models",
    "__version__",
]
