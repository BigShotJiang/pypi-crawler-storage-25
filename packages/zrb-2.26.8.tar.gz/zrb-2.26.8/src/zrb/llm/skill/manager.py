import os
import uuid
from collections.abc import Callable
from pathlib import Path

import yaml

from zrb.config.config import CFG
from zrb.llm.hook.manager import hook_manager
from zrb.util.load import load_module_from_path

_IGNORE_DIRS = [
    ".git",
    "node_modules",
    "__pycache__",
    "venv",
    "dist",
    "build",
    "htmlcov",
]


class Skill:
    """
    Represents a skill loaded from a SKILL.md or SKILL.py file.

    Skills can be invoked by users via /slash-commands or automatically by the model.

    Frontmatter fields (Claude Code spec):
        name: Display name (max 64 chars), becomes /slash-command
        description: Helps Claude decide when to use
        argument-hint: Shown in autocomplete (e.g., "[filename]")
        disable-model-invocation: Prevent auto-loading (true/false)
        user-invocable: Hide from / menu (true/false, default: true)
        allowed-tools: Tools usable without permission during skill (e.g., "Read, Grep")
        model: Model override for this skill
        context: Run in subagent (e.g., "fork")
        agent: Agent type for forked context (e.g., "Explore")
    """

    def __init__(
        self,
        name: str,
        path: str,
        description: str,
        model_invocable: bool = True,
        user_invocable: bool = True,
        argument_hint: str | None = None,
        allowed_tools: list[str] | None = None,
        model: str | None = None,
        context: str | None = None,
        agent: str | None = None,
        content: str | None = None,
        content_factory: Callable[[], str] | None = None,
    ):
        self.name = name
        self.path = path
        self.description = description
        self.model_invocable = model_invocable
        self.user_invocable = user_invocable
        self.argument_hint = argument_hint
        self.allowed_tools = allowed_tools or []
        self.model = model
        self.context = context
        self.agent = agent
        self.content = content
        self.content_factory = content_factory


class SkillManager:
    def __init__(
        self,
        root_dir: str = ".",
        search_dirs: list[str | Path] | None = None,
        max_depth: int = 2,
        ignore_dirs: list[str] | None = None,
    ):
        self._root_dir = root_dir
        self._search_dirs = search_dirs
        self._max_depth = max_depth
        self._skills: dict[str, Skill] = {}
        self._ignore_dirs = _IGNORE_DIRS if ignore_dirs is None else ignore_dirs
        self._scanned = False

    def _ensure_scanned(self):
        """Auto-scan on first access if not already scanned."""
        if not self._scanned:
            self.scan()

    def reload(self):
        """Force re-scan skills. Use after CFG changes or skill file updates."""
        self._scanned = False
        self._skills = {}
        self._ensure_scanned()

    def scan(self, search_dirs: list[str | Path] | None = None) -> list[Skill]:
        self._skills = {}
        target_search_dirs = search_dirs
        if target_search_dirs is None:
            target_search_dirs = (
                self._search_dirs
                if self._search_dirs is not None
                else self.get_search_directories()
            )
        # Scan in order of precedence: global -> project
        # We iterate in normal order to allow later skills (project) to override earlier ones (global)
        for search_dir in target_search_dirs:
            self._scan_dir(search_dir, max_depth=self._max_depth)
        self._scanned = True
        return list(self._skills.values())

    def get_search_directories(self) -> list[str | Path]:
        """
        Get all skill search directories in priority order.

        Priority (high → low):
        1. User home (~/.claude/, ~/.zrb/)
        2. Project traversal (filesystem root → cwd for each config dir name)
        3. Plugins from configured plugin dirs
        4. Base search directories
        5. Extra direct skill directories
        6. Builtin (always included, lowest priority)
        """
        search_dirs: list[str | Path] = []
        home = Path.home()

        # 1. USER HOME
        if CFG.LLM_SEARCH_HOME:
            for pattern in CFG.LLM_CONFIG_DIR_NAMES:
                root = home / pattern
                if root.exists() and root.is_dir():
                    skill_path = root / "skills"
                    if skill_path.exists() and skill_path.is_dir():
                        search_dirs.append(skill_path)

                    # Plugins within home root
                    plugins_dir = root / "plugins"
                    if plugins_dir.exists() and plugins_dir.is_dir():
                        for plugin_dir in self._scan_plugin_dirs(plugins_dir):
                            skill_path = plugin_dir / "skills"
                            if skill_path.exists() and skill_path.is_dir():
                                search_dirs.append(skill_path)

        # 2. PROJECT TRAVERSAL (filesystem root → cwd for each config dir name)
        if CFG.LLM_SEARCH_PROJECT:
            for project_dir in self._get_upward_dirs():
                for pattern in CFG.LLM_CONFIG_DIR_NAMES:
                    root = project_dir / pattern
                    if root.exists() and root.is_dir():
                        skill_path = root / "skills"
                        if skill_path.exists() and skill_path.is_dir():
                            search_dirs.append(skill_path)

                        plugins_dir = root / "plugins"
                        if plugins_dir.exists() and plugins_dir.is_dir():
                            for plugin_dir in self._scan_plugin_dirs(plugins_dir):
                                skill_path = plugin_dir / "skills"
                                if skill_path.exists() and skill_path.is_dir():
                                    search_dirs.append(skill_path)

        # 3. PLUGINS from configured directories
        for plugin_path_str in CFG.LLM_PLUGIN_DIRS:
            plugin_path = Path(plugin_path_str)
            if plugin_path.exists() and plugin_path.is_dir():
                for plugin_dir in self._scan_plugin_dirs(plugin_path):
                    skill_path = plugin_dir / "skills"
                    if skill_path.exists() and skill_path.is_dir():
                        search_dirs.append(skill_path)

        # 4. BASE SEARCH DIRECTORIES
        for root_str in CFG.LLM_BASE_SEARCH_DIRS:
            root = Path(root_str)
            if root.exists() and root.is_dir():
                skill_path = root / "skills"
                if skill_path.exists() and skill_path.is_dir():
                    search_dirs.append(skill_path)

                plugins_dir = root / "plugins"
                if plugins_dir.exists() and plugins_dir.is_dir():
                    for plugin_dir in self._scan_plugin_dirs(plugins_dir):
                        skill_path = plugin_dir / "skills"
                        if skill_path.exists() and skill_path.is_dir():
                            search_dirs.append(skill_path)

        # 5. EXTRA DIRECT SKILL DIRECTORIES
        for dir_str in CFG.LLM_EXTRA_SKILL_DIRS:
            dir_path = Path(dir_str)
            if dir_path.exists() and dir_path.is_dir():
                search_dirs.append(dir_path)

        # 7. BUILTIN (always included, lowest priority)
        builtin_path = Path(__file__).parent.parent.parent / "llm_plugin" / "skills"
        if builtin_path.exists() and builtin_path.is_dir():
            search_dirs.append(builtin_path)

        # 8. root_dir itself (recursive scan target)
        search_dirs.append(Path(self._root_dir))

        return search_dirs

    def _get_upward_dirs(self) -> list[Path]:
        """
        Get directories from root to cwd for upward traversal.
        Returns paths in root → cwd order.
        """
        try:
            cwd = Path(self._root_dir).resolve()
            # parents[0] is parent of cwd, parents[-1] is filesystem root
            # We reverse to get root → ... → cwd order
            return list(cwd.parents)[::-1] + [cwd]
        except Exception:
            return []

    def _scan_plugin_dirs(self, plugins_root: Path) -> list[Path]:
        """
        Scan plugin directories within a plugins root.
        Returns paths to plugin directories (not the skills/ subdirectory).
        """
        plugin_dirs: list[Path] = []
        try:
            for item in plugins_root.iterdir():
                if item.is_dir() and not item.name.startswith("."):
                    # Check for plugin manifest
                    manifest = item / ".claude-plugin" / "plugin.json"
                    if manifest.exists():
                        plugin_dirs.append(item)
        except Exception:
            pass
        return plugin_dirs

    def _scan_dir(self, directory: Path, max_depth: int):
        try:
            search_path = Path(directory).resolve()
            self._scan_dir_recursive(search_path, search_path, max_depth, 0)
        except Exception:
            pass

    def _scan_dir_recursive(
        self, base_dir: Path, current_dir: Path, max_depth: int, current_depth: int
    ):
        """Recursively scan directories with explicit depth control."""
        if current_depth > max_depth:
            return

        try:
            # List directory contents
            for item in current_dir.iterdir():
                if item.is_dir():
                    # Skip ignored directories
                    if item.name in self._ignore_dirs or item.name.startswith("."):
                        continue
                    # Recursively scan subdirectory
                    self._scan_dir_recursive(
                        base_dir, item, max_depth, current_depth + 1
                    )
                elif item.is_file():
                    full_path = str(item)
                    rel_path = os.path.relpath(full_path, self._root_dir)

                    # Check for Python skill files
                    if item.name == "SKILL.py" or item.name.endswith(".skill.py"):
                        self._load_skill_from_python(rel_path, full_path)
                    # Check for Markdown skill files
                    elif item.name == "SKILL.md" or item.name.endswith(".skill.md"):
                        self._load_skill_from_markdown(rel_path, full_path)
        except (PermissionError, OSError):
            # Skip directories we can't access
            pass

    def _load_skill_from_python(self, rel_path: str, full_path: str):
        try:
            module_name = f"zrb_skill_{uuid.uuid4().hex}"
            module = load_module_from_path(module_name, full_path)
            if not module:
                return

            skill_obj = None
            # Look for 'skill' or 'SKILL' variable
            if hasattr(module, "skill"):
                skill_obj = getattr(module, "skill")
            elif hasattr(module, "SKILL"):
                skill_obj = getattr(module, "SKILL")

            if isinstance(skill_obj, Skill):
                self._skills[skill_obj.name] = skill_obj
            elif hasattr(module, "get_skill") and callable(module.get_skill):
                # Factory function that returns a Skill
                skill_obj = module.get_skill()
                if isinstance(skill_obj, Skill):
                    self._skills[skill_obj.name] = skill_obj

        except Exception as e:
            CFG.LOGGER.warning(f"Failed to load Python skill from {full_path}: {e}")

    def _load_skill_from_markdown(self, rel_path: str, full_path: str):
        try:
            with open(full_path, "r", encoding="utf-8") as f:
                content = f.read()

            default_name = os.path.basename(os.path.dirname(full_path))
            name = default_name
            description = "No description"
            model_invocable = True
            user_invocable = (
                True  # Default: skills are user-invocable (visible in / menu)
            )
            argument_hint = None
            allowed_tools: list[str] = []
            model = None
            context = None
            agent = None
            is_name_resolved = False

            # 1. Parse YAML Frontmatter
            if content.startswith("---"):
                try:
                    parts = content.split("---", 2)
                    if len(parts) >= 3:
                        frontmatter = yaml.safe_load(parts[1])
                        if frontmatter:
                            # Basic fields
                            if "name" in frontmatter:
                                name = frontmatter["name"]
                                is_name_resolved = True
                            description = frontmatter.get("description", description)
                            model_invocable = not frontmatter.get(
                                "disable-model-invocation", False
                            )
                            # user-invocable: false hides from / menu (for background knowledge)
                            # Default is True (skills are visible in / menu)
                            user_invocable = frontmatter.get("user-invocable", True)

                            # Claude Code spec fields
                            argument_hint = frontmatter.get("argument-hint")

                            # allowed-tools: comma-separated string or list
                            allowed_tools_raw = frontmatter.get("allowed-tools")
                            if allowed_tools_raw:
                                if isinstance(allowed_tools_raw, str):
                                    allowed_tools = [
                                        t.strip() for t in allowed_tools_raw.split(",")
                                    ]
                                elif isinstance(allowed_tools_raw, list):
                                    allowed_tools = allowed_tools_raw

                            model = frontmatter.get("model")
                            context = frontmatter.get("context")
                            agent = frontmatter.get("agent")

                            # Parse hooks if present
                            hooks_data = frontmatter.get("hooks")
                            if hooks_data:
                                if isinstance(hooks_data, dict):
                                    # Claude nested format
                                    hook_manager._parse_claude_format(
                                        {"hooks": hooks_data}, full_path
                                    )
                                elif isinstance(hooks_data, list):
                                    # Zrb flat format
                                    for hook_item in hooks_data:
                                        hook_manager._parse_and_register(
                                            hook_item, full_path
                                        )

                except Exception:
                    pass

            # 2. Fallback: Parse Markdown for Header 1
            if not is_name_resolved:
                for line in content.splitlines():
                    stripped = line.strip()
                    if stripped.startswith("# "):
                        name = stripped[2:].strip()
                        is_name_resolved = True
                        break

            # Use name as key, handle duplicates by overriding (precedence handled by scan order)
            self._skills[name] = Skill(
                name=name,
                path=full_path,
                description=description,
                model_invocable=model_invocable,
                user_invocable=user_invocable,
                argument_hint=argument_hint,
                allowed_tools=allowed_tools,
                model=model,
                context=context,
                agent=agent,
                content=content,  # Persist content to avoid re-reading
            )
        except Exception as e:
            CFG.LOGGER.warning(f"Failed to load Markdown skill from {full_path}: {e}")

    def _load_skill(self, rel_path: str, full_path: str):
        # Backward compatibility / internal helper alias
        self._load_skill_from_markdown(rel_path, full_path)

    def add_skill(self, skill: Skill):
        """
        Manually register a skill.
        """
        self._skills[skill.name] = skill

    def get_skills(self) -> list[Skill]:
        """Return all scanned skills, scanning lazily on first call."""
        self._ensure_scanned()
        return list(self._skills.values())

    def get_skill(self, name: str) -> Skill | None:
        self._ensure_scanned()
        skill = self._skills.get(name)
        if not skill:
            # Try partial match or path match
            for s in self._skills.values():
                if s.name == name or s.path == name:
                    skill = s
                    break
        return skill

    def get_skill_content(self, name: str) -> str | None:
        self._ensure_scanned()
        skill = self.get_skill(name)
        if not skill:
            return None

        if skill.content:
            return skill.content

        if skill.content_factory:
            try:
                return skill.content_factory()
            except Exception as e:
                return f"Error executing skill factory: {e}"

        try:
            with open(skill.path, "r", encoding="utf-8") as f:
                return f.read()
        except Exception as e:
            return f"Error reading skill file: {e}"


skill_manager = SkillManager()
