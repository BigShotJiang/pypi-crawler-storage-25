"""Spatial analysis AI analyzers — Tier 2 GPU-based safe zone and layout checks."""

from lintpdf.ai.analyzers.spatial_analysis import safe_zone_violations  # noqa: F401
