from setuptools import setup, find_packages

setup(
    name='docgen-emperor',
    version='1.0.0',
    description='Emperor Test Generator - يولّد ويصلح الاختبارات تلقائياً',
    author='DocGen',
    packages=find_packages(),
    install_requires=['pytest>=7.0'],
    entry_points={
        'console_scripts': [
            'docgen-test=emperor.cli:main',
        ],
    },
    python_requires='>=3.11',
)
