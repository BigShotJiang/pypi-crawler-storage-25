"""DocGen Emperor - Intelligent Test Generator"""
__version__ = '1.0.0'
