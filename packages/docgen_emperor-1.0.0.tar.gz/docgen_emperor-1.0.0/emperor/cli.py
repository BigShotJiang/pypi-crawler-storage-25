#!/usr/bin/env python3
"""Emperor CLI - مدخل الأوامر الموحد"""

import sys, os
from pathlib import Path

# إضافة مسار الحزمة
sys.path.insert(0, str(Path(__file__).parent))

from .brain import DeepAnalyzer
from .hand import TestGenerator, TestFileWriter
from .healer import TestRunner, Healer
from .eye import ProjectScanner
from .decree import Decree
from .memory import ImperialMemory

def main():
    if len(sys.argv) < 2:
        print("""
╔══════════════════════════════════════════════╗
║      👑 Emperor Test Generator v1.0.0        ║
║    يولّد ويصلح الاختبارات تلقائياً            ║
╚══════════════════════════════════════════════╝

Usage:
  docgen-test <path>       تحليل + توليد + إصلاح
  docgen-test -f <path>    إصلاح اختبارات
  docgen-test -w <path>    مراقبة مستمرة
  docgen-test -r           تقرير
  docgen-test -i <a> <b>   اختبارات تكامل

Examples:
  docgen-test src/
  docgen-test src/auth.py
  docgen-test -f tests/
  docgen-test -w src/
  docgen-test -r
  docgen-test -i src/auth.py src/db.py
""")
        return
    
    cmd = sys.argv[1]
    decree = Decree()
    memory = ImperialMemory(os.path.expanduser('~/.docgen_emperor_memory.json'))
    
    if cmd == '--login':

        if len(sys.argv) < 3:
            print("Usage: docgen-test --login <API_KEY>")
            print("Get your API key from: /me-page")
            return
        from .auth import login
        success, msg = login(sys.argv[2])
        print(f"{'✅' if success else '❌'} {msg}")
        return

    # التحقق من الاشتراك
    from .auth import check_subscription
    sub = check_subscription()
    if not sub['allowed']:
        print(f"❌ {sub['reason']}")
        return

    if cmd == '-f':

        target = sys.argv[2] if len(sys.argv) > 2 else 'tests'
        healer = Healer(memory=memory, decree=decree)
        test_files = list(Path(target).rglob('test_*.py'))
        for tf in test_files:
            runner = TestRunner()
            success, output = runner.run_test(str(tf))
            if not success:
                result = healer.heal(str(tf), output)
                print(f"  {'✅' if result.success else '📜'} {tf.name}")
    
    elif cmd == '-w':

        target = sys.argv[2] if len(sys.argv) > 2 else '.'
        from .guard import FileWatcher
        print(f"👁️ Watching {target}/ (Ctrl+C to stop)")
        watcher = FileWatcher(target)
        watcher.start()
    
    elif cmd == '-r':

        stats = memory.get_statistics()
        print(f"📊 Sessions: {stats['total_runs']} | Tests: {stats['total_tests_generated']}")
        print(f"🔧 Fixes: {stats['total_fixes_applied']} | ❌ Failed: {stats['total_fixes_failed']}")
        print(f"📈 Rate: {stats['success_rate']}%")
    
    elif cmd == '-i':

        if len(sys.argv) < 4:
            print("Usage: docgen-test -i <file1> <file2>")
            return
        a1 = DeepAnalyzer().analyze_file(sys.argv[2])
        a2 = DeepAnalyzer().analyze_file(sys.argv[3])
        if a1 and a2:
            print(f"🔗 {a1.filepath} ↔ {a2.filepath}")
            # توليد اختبارات تكامل
            gen = TestGenerator(a1, str(Path(sys.argv[2]).parent))
            code = gen.generate()
            TestFileWriter().write_test_file(code, sys.argv[2])
            print(f"🤲 Integration tests generated")
    
    else:
        target = sys.argv[1]
        scanner = ProjectScanner()
        # GitHub URL support
    if 'github.com' in target:
        import tempfile, subprocess
        repo_name = target.rstrip('/').split('/')[-1].replace('.git', '')
        tmp = tempfile.mkdtemp()
        import shlex
        token = None
        for a in sys.argv:
            if a.startswith("--token="):
                token = a.split("=", 1)[1]
        clone_url = target
        if token and "github.com" in target:
            clone_url = f"https://oauth2:{token}@github.com/" + "/".join(target.split("/")[-2:])
        subprocess.run(["git", "clone", "--depth", "1", clone_url, tmp], capture_output=True, timeout=60)
        target = tmp
    pm = scanner.scan(target)
    decree.startup(pm.source_dir)
    decree.scan_report(pm.total_files, len(pm.source_files), len(pm.test_files), 0)
    
    brain = DeepAnalyzer()
    total_funcs = 0
    total_classes = 0
    total_tests = 0
    
    for sf in pm.source_files[:50]:
            analysis = brain.analyze_file(sf.path)
            if analysis and (analysis.functions or analysis.classes):
                funcs = len(analysis.functions)
                classes = len(analysis.classes)
                total_funcs += funcs
                total_classes += classes
                print(f"   🧠 {sf.name}: {funcs} functions, {classes} classes")
                
                gen = TestGenerator(analysis, str(Path(sf.path).parent))
                code = gen.generate()
                count = gen.get_test_count()
                if count > 0:
                    TestFileWriter().write_test_file(code, sf.path, target)
                    total_tests += count
                    print(f"   🤲 test_{Path(sf.path).stem}.py: {count} tests")
    
    decree.test_run_report(total_tests, 0, total_tests)
    memory.increment_tests_generated(total_tests)
    memory.save()
    print(f"\n✅ {total_tests} tests generated")

if __name__ == '__main__':
    main()
