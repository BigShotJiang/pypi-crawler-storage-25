###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration          #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".  #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""Unit tests for production handlers."""

from pathlib import PurePosixPath

import pytest

from LbAPLocal.handlers import get_handler
from LbAPLocal.handlers.anaprod import APHandler
from LbAPLocal.handlers.mc_request import MCHandler, parse_job_id, parse_mc_filename
from LbAPLocal.models import RepoType


def test_get_handler_anaprod():
    handler = get_handler(RepoType.ANA_PROD)
    assert isinstance(handler, APHandler)


def test_get_handler_mc():
    handler = get_handler(RepoType.MC)
    assert isinstance(handler, MCHandler)


def test_get_handler_unknown():
    with pytest.raises(KeyError):
        get_handler(RepoType.RAD)


class TestAPHandler:
    def test_check_directory(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "AnalysisProductions.xenv").touch()
        handler = APHandler()
        handler.check_directory()  # should not raise

    def test_check_directory_wrong_dir(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        handler = APHandler()
        with pytest.raises(Exception, match="wrong directory"):
            handler.check_directory()

    def test_list_productions(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "MyProd" / "info.yaml").parent.mkdir()
        (tmp_path / "MyProd" / "info.yaml").touch()
        (tmp_path / "OtherProd").mkdir()  # no info.yaml
        handler = APHandler()
        result = handler.list_productions()
        assert result == ["MyProd"]

    def test_list_jobs(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        prod_dir = tmp_path / "MyProd"
        prod_dir.mkdir()
        (prod_dir / "info.yaml").write_text(
            "jobs:\n  myjob:\n    application: DaVinci/v1\n"
        )
        monkeypatch.setattr("LbAPCommon.render_yaml", lambda raw: raw)
        monkeypatch.setattr(
            "LbAPCommon.parse_yaml",
            lambda rendered, prod, _: {"myjob": {}, "otherjob": {}},
        )
        handler = APHandler()
        result = handler.list_jobs("MyProd")
        assert "myjob" in result
        assert "otherjob" in result


class TestParseMCFilename:
    """Test the filename parser (mirrors LbAPI's _parse_filename convention)."""

    def test_plain_yaml(self):
        name, stage = parse_mc_filename(PurePosixPath("charm.yaml"))
        assert name == "charm"
        assert stage == 0

    def test_stage0_yaml(self):
        name, stage = parse_mc_filename(PurePosixPath("charm.stage0.yaml"))
        assert name == "charm"
        assert stage == 0

    def test_stage6_yaml(self):
        name, stage = parse_mc_filename(PurePosixPath("D2hh0.stage6.yaml"))
        assert name == "D2hh0"
        assert stage == 6

    def test_stage3_yaml(self):
        name, stage = parse_mc_filename(PurePosixPath("request.stage3.yaml"))
        assert name == "request"
        assert stage == 3

    def test_invalid_suffix(self):
        with pytest.raises(ValueError):
            parse_mc_filename(PurePosixPath("readme.txt"))


class TestParseJobId:
    def test_simple(self):
        filename, name, evt_id = parse_job_id(
            "charm.yaml:charm-D2hh0 2025 pp MagDown:21123203"
        )
        assert filename == "charm.yaml"
        assert name == "charm-D2hh0 2025 pp MagDown"
        assert evt_id == "21123203"

    def test_colon_in_production_name(self):
        filename, name, evt_id = parse_job_id("charm.yaml:prod:with:colons:21123203")
        assert filename == "charm.yaml"
        assert name == "prod:with:colons"
        assert evt_id == "21123203"

    def test_no_colons(self):
        with pytest.raises(ValueError):
            parse_job_id("no-colons-here")

    def test_single_colon(self):
        with pytest.raises(ValueError):
            parse_job_id("file.yaml:rest")


class TestMCHandler:
    def test_check_directory(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / ".git").mkdir()
        handler = MCHandler()
        handler.check_directory()  # should not raise

    def test_check_directory_wrong_dir(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        handler = MCHandler()
        with pytest.raises(Exception, match="wrong directory"):
            handler.check_directory()

    def test_list_productions(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "D2hh0").mkdir()
        (tmp_path / "D2hh0" / "charm.yaml").touch()
        (tmp_path / "D2hh0" / "beauty.stage3.yaml").touch()
        (tmp_path / "EmptyDir").mkdir()  # no yaml files
        (tmp_path / ".hidden").mkdir()  # hidden dir
        (tmp_path / ".hidden" / "foo.yaml").touch()
        handler = MCHandler()
        result = handler.list_productions()
        assert result == ["D2hh0"]

    def test_list_jobs(self, tmp_path, monkeypatch):
        """Test job listing with mocked lb-mc subprocess."""
        monkeypatch.chdir(tmp_path)
        prod_dir = tmp_path / "D2hh0"
        prod_dir.mkdir()
        (prod_dir / "charm.yaml").write_text("sim-version: '09'\n")

        stage6_output = [
            {
                "type": "Simulation",
                "name": "charm-D2hh0 2025 pp MagDown",
                "event_types": [
                    {"id": "21123203", "num_events": 100},
                    {"id": "21123204", "num_events": 200},
                ],
                "steps": [],
            },
            {
                "type": "Simulation",
                "name": "charm-D2hh0 2025 pp MagUp",
                "event_types": [{"id": "21123203", "num_events": 100}],
                "steps": [],
            },
        ]

        monkeypatch.setattr(
            "LbAPLocal.handlers.mc_request.run_lb_mc",
            lambda input_path, in_stage: stage6_output,
        )

        handler = MCHandler()
        jobs = handler.list_jobs("D2hh0")
        assert "charm.yaml:charm-D2hh0 2025 pp MagDown:21123203" in jobs
        assert "charm.yaml:charm-D2hh0 2025 pp MagDown:21123204" in jobs
        assert "charm.yaml:charm-D2hh0 2025 pp MagUp:21123203" in jobs
        assert len(jobs) == 3

    def test_generate_request_yaml(self, tmp_path, monkeypatch):
        """Test YAML generation with mocked lb-mc subprocess."""
        monkeypatch.chdir(tmp_path)
        prod_dir = tmp_path / "D2hh0"
        prod_dir.mkdir()
        (prod_dir / "charm.yaml").write_text("sim-version: '09'\n")
        output_dir = tmp_path / "output"
        output_dir.mkdir()

        target_production = {
            "type": "Simulation",
            "name": "charm-D2hh0 2025 pp MagDown",
            "event_types": [
                {"id": "21123203", "num_events": 100},
                {"id": "21123204", "num_events": 200},
            ],
            "steps": [{"name": "Gauss"}],
        }
        stage6_output = [
            target_production,
            {
                "type": "Simulation",
                "name": "charm-D2hh0 2025 pp MagUp",
                "event_types": [{"id": "21123203", "num_events": 100}],
                "steps": [{"name": "Gauss"}],
            },
        ]

        monkeypatch.setattr(
            "LbAPLocal.handlers.mc_request.run_lb_mc",
            lambda input_path, in_stage: stage6_output,
        )

        handler = MCHandler()
        job_id = "charm.yaml:charm-D2hh0 2025 pp MagDown:21123203"
        result_path = handler.generate_request_yaml("D2hh0", job_id, output_dir)

        assert result_path.exists()
        import yaml as pyyaml

        with open(result_path) as f:
            written = pyyaml.safe_load(f)
        assert isinstance(written, list)
        assert len(written) == 1
        assert written[0]["name"] == "charm-D2hh0 2025 pp MagDown"
        assert len(written[0]["event_types"]) == 1
        assert written[0]["event_types"][0]["id"] == "21123203"
