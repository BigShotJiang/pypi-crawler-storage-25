###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
from unittest.mock import MagicMock

import click
from typer.testing import CliRunner

from LbAPLocal.cli.main import app

runner = CliRunner()


def test_generate_success(tmp_path, monkeypatch):
    """Test the full generate workflow by mocking the interactive wizards."""
    monkeypatch.chdir(tmp_path)

    monkeypatch.setattr(
        "LbAPLocal.cli.main.inside_ap_datapkg",
        MagicMock(side_effect=click.ClickException("Not inside a datapkg")),
    )

    monkeypatch.setattr(
        "LbAPLocal.cli.main.generate_pre_wizard", MagicMock(return_value="master")
    )

    monkeypatch.setattr("LbAPLocal.cli.main.clone", lambda **_: None)

    fake_wizard_data = {
        "wg": "BandQ",
        "username": "jconnaug",
        "line": "Hlt2BandQ_BBbarToPhiPhi",
        "sample": "test",
        "selected_dict": {"2024": ["s24c2a MagUp"], "2026": ["s26c1 MagDown"]},
    }
    monkeypatch.setattr(
        "LbAPLocal.cli.main.generate_wizard", MagicMock(return_value=fake_wizard_data)
    )

    result = runner.invoke(app, ["generate"])

    assert result.exit_code == 0, result.output
    assert "Successfully generated configuration at:" in result.output
    assert "info.yaml" in result.output
    assert "options.py" in result.output

    sample_dir = tmp_path / "test"
    assert sample_dir.exists()
    assert (sample_dir / "info.yaml").exists()
    assert (sample_dir / "options.py").exists()


def test_generate_available_campaigns(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)

    monkeypatch.setattr(
        "LbAPLocal.cli.main.inside_ap_datapkg",
        MagicMock(side_effect=click.ClickException("Not inside a datapkg")),
    )

    monkeypatch.setattr(
        "LbAPLocal.cli.main.generate_pre_wizard", MagicMock(return_value="master")
    )

    monkeypatch.setattr("LbAPLocal.cli.main.clone", lambda **_: None)

    fake_wizard_data = {
        "wg": "RD",
        "username": "jconnaug",
        "line": "Hlt2RD_LbToPpPimMuMu_MVA",
        "sample": "test",
        "selected_dict": {"2024": ["s24c2a MagUp"], "2026": ["s26c1 MagDown"]},
    }
    monkeypatch.setattr(
        "LbAPLocal.cli.main.generate_wizard", MagicMock(return_value=fake_wizard_data)
    )

    result = runner.invoke(app, ["generate"])

    assert result.exit_code != 0

    assert isinstance(result.exception, KeyError)

    assert "s24c2a" in str(result.exception)


def test_generate_change_stream(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)

    monkeypatch.setattr(
        "LbAPLocal.cli.main.inside_ap_datapkg",
        MagicMock(side_effect=click.ClickException("Not inside a datapkg")),
    )

    monkeypatch.setattr(
        "LbAPLocal.cli.main.generate_pre_wizard", MagicMock(return_value="master")
    )

    monkeypatch.setattr("LbAPLocal.cli.main.clone", lambda **_: None)

    fake_wizard_data = {
        "wg": "QEE",
        "username": "jconnaug",
        "line": "Hlt2QEE_DiMuon_DrellYan_LowMass_SS_Displaced",
        "sample": "test",
        "selected_dict": {"2025": ["s25c4 MagDown"], "2026": ["s26c1 MagDown"]},
    }
    monkeypatch.setattr(
        "LbAPLocal.cli.main.generate_wizard", MagicMock(return_value=fake_wizard_data)
    )

    result = runner.invoke(app, ["generate"])

    assert result.exit_code == 0, result.output

    yaml_text = (tmp_path / "test" / "info.yaml").read_text()

    s25c4_string = "('Collision25', '25c4', 'MagDown', 'qeelow', 'QEELOW', 'run3/2025-v00.01', 'master'),"
    s26c1_string = "('Collision26', '26c1', 'MagDown', 'qee'   , 'QEE'   , 'run3/2026-v00.00', 'master'),"

    assert s25c4_string in yaml_text
    assert s26c1_string in yaml_text
