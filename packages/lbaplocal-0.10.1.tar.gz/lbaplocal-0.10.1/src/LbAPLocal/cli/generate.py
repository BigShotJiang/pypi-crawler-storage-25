###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
import json
import re
from collections import defaultdict
from fnmatch import fnmatch
from pathlib import Path
from string import Template
from textwrap import dedent

import yaml

SPRUCINGCONFIG_BASE = Path("/cvmfs/lhcb.cern.ch/lib/lhcb/DBASE/SprucingConfig")
VERSION_PATTERN = re.compile(r"v(\d+)r(\d+)(?:p(\d+))?")

# Lazily-populated registries (filled by _ensure_loaded())
line_registry: dict = {}
campaigns_registry: dict = {}
all_lines: list[str] = []
_loaded = False


def latest_available(path: Path, pattern: str = "v*"):
    matches = {}
    for version_path in path.iterdir():
        if not version_path.is_dir():
            continue
        version = version_path.name
        if match := VERSION_PATTERN.fullmatch(version):
            if not fnmatch(version, pattern):
                continue
            version_segments = tuple(0 if x is None else int(x) for x in match.groups())
            matches[version_segments] = version
    return max(matches.items())[1]


def _ensure_loaded():
    """Load line and campaign registries from CVMFS on first use."""
    global line_registry, campaigns_registry, all_lines, _loaded
    if _loaded:
        return

    config_base = (
        SPRUCINGCONFIG_BASE / latest_available(SPRUCINGCONFIG_BASE) / "line_configs"
    )

    _line_registry = defaultdict(dict)
    _campaigns_registry = {}

    for process_path in config_base.iterdir():
        if not process_path.is_dir():
            continue
        _campaigns_registry[process_path.stem] = {}
        for year_path in process_path.iterdir():
            _campaigns_registry[process_path.stem][year_path.stem] = {}
            for config_path in sorted(year_path.glob("*.json")):
                with config_path.open() as file:
                    stream_to_line_map = json.load(file)
                line_to_stream_map = {
                    line: stream
                    for stream, lines in stream_to_line_map.items()
                    for line in lines
                }
                for line, stream in line_to_stream_map.items():
                    _line_registry[line] |= {config_path.stem: {"stream": stream}}
            _campaigns_registry[process_path.stem][year_path.stem] = {}
            for config_path in year_path.glob("*.yaml"):
                with config_path.open() as file:
                    campaign_info = yaml.safe_load(file)
                _campaigns_registry[process_path.stem][year_path.stem][
                    config_path.stem
                ] = campaign_info

    line_registry = dict(_line_registry)
    campaigns_registry = _campaigns_registry
    all_lines = list(line_registry.keys())
    _loaded = True


def generate_yaml(wg, username, line, sample, selected_dict):
    _ensure_loaded()
    if line.startswith("Hlt2"):
        process = "turbo"
    elif line.startswith("Spruce"):
        process = "full"
    else:
        raise RuntimeError(f"Line must begin with HLT2 or Spruce: {line}")

    latest_davinci = get_app_versions("DaVinci")[-1]

    dataset_lines = []

    line_data = line_registry.get(line, {})

    raw_rows = []
    for year, combos in selected_dict.items():
        data_str = f"Collision{year[-2:]}"

        for combo in combos:
            campaign, polarity = combo.split()
            # Remove the leading s from campaign
            bkk_campaign = campaign[1:]
            campaign_info = campaigns_registry[process][year][campaign]
            geom_str = campaign_info["geometry_version"]
            cond_str = campaign_info["conditions_version"]
            eventtype = str(campaign_info["eventtype"])
            input_process = campaign_info["input_process"]
            stream = line_data[campaign].get("stream", "placeholder")

            raw_rows.append(
                (
                    data_str,
                    bkk_campaign,
                    polarity,
                    stream,
                    stream.upper(),
                    geom_str,
                    cond_str,
                )
            )

    num_columns = len(raw_rows[0])
    max_lens = [
        max(len(str(row[i])) for row in raw_rows) + 2 for i in range(num_columns)
    ]

    for row in raw_rows:
        formatted_items = [f"{item!r:<{length}}" for item, length in zip(row, max_lens)]

        dataset_lines.append(f"  ({', '.join(formatted_items)}),")

    dataset_list_str = "\n".join(dataset_lines)

    query_path = (
        "/LHCb/{{data}}/Beam6800GeV-VeloClosed-{{polarity}}/"
        "Real Data/Sprucing{{campaign}}/" + eventtype + "/{{stream_upper}}.DST"
    )

    yaml_template = Template(dedent("""\
    defaults:
      wg: $wg
      inform:
        - $username
      application: $application

    {%- set datasets = [
    $dataset_list
    ] %}

    {%- for data, campaign, polarity, stream, stream_upper, geom, cond in datasets %}
    ${sample}_{{campaign}}_{{polarity}}:
      input:
        bk_query: $query_path
      output: $output_file
      options:
        entrypoint: $entrypoint
        extra_options:
          input_raw_format: 0.5
          input_type: ROOT
          geometry_version: {{geom}}
          conditions_version: {{cond}}
          input_process: $input_process
          input_stream: {{stream}}
          simulation: false
    {%- endfor %}
    """))

    rendered_yaml = yaml_template.substitute(
        wg=wg,
        username=username,
        application=f"DaVinci/{latest_davinci}",
        dataset_list=dataset_list_str,
        sample=sample,
        query_path=query_path,
        output_file="TUPLE.ROOT",
        entrypoint=f"{sample}.options:main",
        input_process=input_process,
    )

    return rendered_yaml


def generate_options(line: str, selected_dict: dict) -> str:
    """Generates a boilerplate DaVinci options.py script."""
    _ensure_loaded()

    if line.startswith("Hlt2"):
        process = "turbo"
    elif line.startswith("Spruce"):
        process = "full"
    else:
        raise RuntimeError(f"Line must begin with HLT2 or Spruce: {line}")
    tes_location = None
    for year, combos in selected_dict.items():
        for combo in combos:
            campaign, _ = combo.split()
            if not tes_location:
                tes_location = campaigns_registry[process][year][campaign][
                    "tes_location"
                ]
            else:
                if (
                    tes_location
                    != campaigns_registry[process][year][campaign]["tes_location"]
                ):
                    raise RuntimeError("Different TES locations for the same line!")

    options_template = Template(dedent("""\
    import Functors as F
    from PyConf.reading import get_particles
    from FunTuple import FunTuple_Particles as Funtuple
    from FunTuple import FunctorCollection
    import FunTuple.functorcollections as FC
    from FunTuple.common_util import descriptor_fields
    from DaVinci.algorithms import create_lines_filter
    from DaVinci import Options, make_config


    def main(options: Options):
        line = "$line"

        particles = get_particles(f"/Event/$tes_location/{line}/Particles")

        line_prefilter = create_lines_filter(name=f"PreFilter_{line}", lines=[line])

        # An example descriptor template is
        # descriptor_template = "$${Jpsi} J/psi(1S) -> $${mup}mu+ $${mum}mu-"
        # This will create fields Jpsi, mup, mum

        ##############################
        ######## FILL ME IN ##########
        descriptor_template = ""
        ##############################

        fields = descriptor_fields(descriptor_template)

        variables = {}
        variables["ALL"] = FC.Kinematics()

        # Add variables to specific particles e.g.
        # variables["Jpsi"] = FunctorCollection({
        #     "OWNPVIPCHI2": F.OWNPVIPCHI2,
        # })

        evt_vars = FC.EventInfo()
        evt_vars += FC.RecSummary()

        funtuple = Funtuple(
            name="Tuple",
            tuple_name="DecayTree",
            fields=fields,
            variables=variables,
            event_variables=evt_vars,
            inputs=particles,
        )

        return make_config(options, [line_prefilter, funtuple])
    """))

    return options_template.substitute(line=line, tes_location=tes_location)


def get_app_versions(app: str) -> list[str]:
    """Get all available versions for an application from projects-info.json.

    Args:
        app: Application name (e.g., "DaVinci").

    Returns:
        List of version strings (e.g. "v64r0") sorted by version number.

    Raises:
        RuntimeError: If projects-info.json cannot be read (e.g., CVMFS not mounted).
    """
    projects_info = "/cvmfs/lhcb.cern.ch/lib/var/lib/softmetadata/projects-info.json"
    """
    Structure of projects-info.json:
    {
        "DAVINCI": {
            "v0r0": {
                ...
                "platforms": [
                    ...
                ],
            },
            "v0r0p1": {
                ...
            },
            ...
        },
        ...
    }
    """

    try:
        with open(projects_info, "r") as f:
            projects_data = json.load(f)
    except FileNotFoundError:
        raise RuntimeError(
            f"Cannot read {projects_info}. "
            "CVMFS may not be mounted or the file does not exist. "
            "Version validation checks cannot proceed without this file."
        ) from None
    except Exception as e:
        raise RuntimeError(
            f"Error reading {projects_info}: {e}. Version validation checks cannot proceed."
        ) from e

    # Collect parsed versions as (sort_key, original_string) pairs, then
    # return just the original strings sorted by version for correct ordering.
    versioned = []
    for project, versions_dict in projects_data.items():
        if project.upper() == app.upper():
            for version_str in versions_dict.keys():
                if match := VERSION_PATTERN.fullmatch(version_str):
                    segments = tuple(0 if x is None else int(x) for x in match.groups())
                    versioned.append((segments, version_str))

    versioned.sort()
    return [v for _, v in versioned]
