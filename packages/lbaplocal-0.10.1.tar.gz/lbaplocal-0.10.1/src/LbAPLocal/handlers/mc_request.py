###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration          #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".  #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""MC Request handler.

Handles MC simulation request repositories (e.g. lhcb-simulation/mc-requests).
Uses lb-mc (LbMCSubmit) to transform Stage 0 YAML into Stage 6 DIRAC production
requests. Job identifiers follow the LbAPI convention:
    {filename}:{production_name}:{event_type_id}
"""

from __future__ import annotations

import glob
import re
import subprocess
from copy import deepcopy
from pathlib import Path, PurePosixPath
from tempfile import TemporaryDirectory

import yaml

from LbAPLocal.utils import inside_ap_datapkg

_FILENAME_RE = re.compile(r"(.+?)(?:\.stage(\d))?\.yaml")


def parse_mc_filename(path: PurePosixPath) -> tuple[str, int]:
    """Parse the name and input stage from an MC request filename.

    Follows the LbAPI convention (LbAPI/ci/actions/mc_request.py:_parse_filename):
        charm.yaml        -> ("charm", 0)
        charm.stage0.yaml -> ("charm", 0)
        charm.stage3.yaml -> ("charm", 3)
        D2hh0.stage6.yaml -> ("D2hh0", 6)
    """
    match = _FILENAME_RE.fullmatch(path.name)
    if not match:
        raise ValueError(f"{path.name} does not match MC filename pattern")
    name, stage = match.groups()
    return name, 0 if stage is None else int(stage)


def run_lb_mc(input_path: Path, in_stage: int) -> list[dict]:
    """Run lb-mc to transform a YAML file to Stage 6.

    Shells out to the lb-mc CLI (LbMCSubmit) and returns the parsed Stage 6
    output as a list of production request dicts.
    """
    with TemporaryDirectory() as tmpdir:
        output_path = Path(tmpdir) / "output.yaml"
        cmd = [
            "lb-mc",
            f"--in-stage={in_stage}",
            str(input_path),
            str(output_path),
        ]
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=600,
        )
        if result.returncode != 0:
            raise RuntimeError(
                f"lb-mc failed (exit {result.returncode}):\n{result.stderr}"
            )
        data = yaml.safe_load(output_path.read_text())
        if not isinstance(data, list):
            raise RuntimeError(
                f"lb-mc produced unexpected output type: {type(data).__name__}"
            )
        return data


def parse_job_id(job_id: str) -> tuple[str, str, str]:
    """Parse an MC job ID into (filename, production_name, event_type_id).

    Job ID format: {filename}:{production_name}:{event_type_id}
    Example: "charm.yaml:charm-D2hh0 2025 pp MagDown:21123203"
    """
    first_colon = job_id.find(":")
    last_colon = job_id.rfind(":")
    if first_colon == -1 or first_colon == last_colon:
        raise ValueError(
            f"Invalid MC job ID format: {job_id!r}. "
            f"Expected '{{filename}}:{{production_name}}:{{event_type_id}}'"
        )
    return (
        job_id[:first_colon],
        job_id[first_colon + 1 : last_colon],
        job_id[last_colon + 1 :],
    )


class MCHandler:
    """Handler for MC simulation request repositories."""

    def check_directory(self) -> None:
        inside_ap_datapkg(None)

    def list_productions(self) -> list[str]:
        dirs = set()
        for path in glob.glob("*/*.yaml"):
            parts = PurePosixPath(path).parts
            if not parts[0].startswith("."):
                dirs.add(parts[0])
        return sorted(dirs)

    def list_jobs(self, production: str) -> list[str]:
        jobs = []
        for yaml_path in sorted(glob.glob(f"{production}/*.yaml")):
            path = PurePosixPath(yaml_path)
            _, in_stage = parse_mc_filename(path)
            stage6_data = run_lb_mc(Path(yaml_path), in_stage)
            for prod in stage6_data:
                for evt in prod["event_types"]:
                    job_id = f"{path.name}:{prod['name']}:{evt['id']}"
                    jobs.append(job_id)
        return jobs

    def generate_request_yaml(
        self, production: str, job: str, output_dir: Path
    ) -> Path:
        filename, prod_name, event_type_id = parse_job_id(job)
        source_path = Path(production) / filename

        if not source_path.exists():
            raise FileNotFoundError(f"MC request file not found: {source_path}")

        _, in_stage = parse_mc_filename(PurePosixPath(source_path))
        stage6_data = run_lb_mc(source_path, in_stage)

        # Find matching production and filter to the requested event type
        for prod in stage6_data:
            if prod["name"] == prod_name:
                matched = deepcopy(prod)
                matched["event_types"] = [
                    evt
                    for evt in matched["event_types"]
                    if str(evt["id"]) == event_type_id
                ]
                if not matched["event_types"]:
                    raise ValueError(
                        f"Event type {event_type_id} not found in "
                        f"production '{prod_name}'"
                    )
                break
        else:
            available = [p["name"] for p in stage6_data]
            raise ValueError(
                f"Production '{prod_name}' not found. "
                f"Available: {', '.join(available)}"
            )

        output_path = output_dir / f"{prod_name}.yaml"
        with open(output_path, "w") as f:
            yaml.dump([matched], f, default_flow_style=False, sort_keys=False)
        return output_path
