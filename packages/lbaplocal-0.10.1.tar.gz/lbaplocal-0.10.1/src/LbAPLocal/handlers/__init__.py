###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration          #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".  #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""Production handler protocol and registry.

Different production types (AnalysisProductions, MC Requests, RadProductions)
have different repository layouts, config formats, and parsing pipelines.
Handlers encapsulate these differences behind a common interface so the CLI
can work with any production type.
"""

from __future__ import annotations

from pathlib import Path
from typing import Protocol

from LbAPLocal.models import RepoType

from .anaprod import APHandler
from .mc_request import MCHandler


class ProductionHandler(Protocol):
    """Interface for production-type-specific logic."""

    def check_directory(self) -> None:
        """Verify CWD is the correct repo type. Raises on failure."""
        ...

    def list_productions(self) -> list[str]:
        """Return available production/directory names."""
        ...

    def list_jobs(self, production: str) -> list[str]:
        """Return job identifiers within a production."""
        ...

    def generate_request_yaml(
        self, production: str, job: str, output_dir: Path
    ) -> Path:
        """Generate a Stage 6 DIRAC production request YAML.

        Returns the path to the generated file in output_dir.
        """
        ...


_HANDLERS: dict[RepoType, ProductionHandler] = {
    RepoType.ANA_PROD: APHandler(),
    RepoType.MC: MCHandler(),
}


def get_handler(repo_type: RepoType) -> ProductionHandler:
    """Return the handler for the given repo type."""
    return _HANDLERS[repo_type]
