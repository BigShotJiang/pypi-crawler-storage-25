###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration          #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".  #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""AnalysisProductions handler.

Extracts AP-specific logic from cli/main.py: directory validation, production
discovery via info.yaml, job listing via LbAPCommon parse_yaml, and DIRAC
production request generation via LbAPCommon.__main__.main().
"""

from __future__ import annotations

import asyncio
import glob
import json
import shutil
from os.path import dirname
from pathlib import Path

import yaml

from LbAPLocal.utils import inside_ap_datapkg


class APHandler:
    """Handler for AnalysisProductions repositories."""

    def __init__(self, xenv_file: str = "AnalysisProductions.xenv"):
        self.xenv_file = xenv_file

    def check_directory(self) -> None:
        inside_ap_datapkg(self.xenv_file)

    def list_productions(self) -> list[str]:
        folders = glob.glob("*/info.yaml")
        return [dirname(f) for f in folders]

    def list_jobs(self, production: str) -> list[str]:
        from LbAPCommon import parse_yaml, render_yaml

        info_yaml = Path(production) / "info.yaml"
        raw = info_yaml.read_text()
        rendered = render_yaml(raw)
        jobs = parse_yaml(rendered, production, None)
        return list(jobs.keys())

    def generate_request_yaml(
        self, production: str, job: str, output_dir: Path
    ) -> Path:
        from LbAPCommon.__main__ import main as lbapcommon_main

        info_yaml_path = Path(production) / "info.yaml"
        metadata_path = output_dir / "dirac_metadata.json"

        asyncio.run(
            lbapcommon_main(
                production_name=production,
                ap_pkg_version="v999999999999",
                input_file=info_yaml_path,
                output_file=metadata_path,
                server_credentials=None,
                only_include=job,
                dump_requests=True,
            )
        )

        with open(metadata_path) as f:
            metadata = json.load(f)

        productions = metadata.get("productions", {})
        if not productions:
            raise RuntimeError("No productions generated")

        prod_key = list(productions.keys())[0]
        production_data = productions[prod_key]

        request_yaml_path = metadata_path.with_name(prod_key).with_suffix(".yaml")

        if not request_yaml_path.exists():
            request_yaml_path = output_dir / f"{prod_key}.yaml"
            with open(request_yaml_path, "w") as f:
                yaml.dump(
                    production_data["request"],
                    f,
                    default_flow_style=False,
                    sort_keys=False,
                )
        elif request_yaml_path.parent != output_dir:
            final_path = output_dir / f"{prod_key}.yaml"
            shutil.move(str(request_yaml_path), str(final_path))
            request_yaml_path = final_path

        return request_yaml_path
