# LbAPLocal

LbAPLocal is the Python library and CLI for running offline tests for the LHCb AnalysisProductions framework.

## Installation

LbAPLocal is installed by default with the LHCb environment on lxplus. For users on external clusters, source the LHCb environment from CVMFS:

```bash
source /cvmfs/lhcb.cern.ch/lib/LbEnv
```

## Usage

```
Usage: lb-ap [OPTIONS] COMMAND [ARGS]...

  CLI for LHCb AnalysisProductions

Options:
  -C, --change-dir PATH  Change to this directory before running
  -b, --branch TEXT      Branch or tag to use
  -v, --verbose          Enable verbose output
  --version              Show version and exit
  --help                 Show this message and exit

Commands:
  versions        List available tags of the Analysis Productions repository
  clone           Clone the AnalysisProductions repository
  checkout        Check out a branch or tag
  list            List available productions and jobs
  test            Test a job using CWL workflow
  parse-log       Analyse a Gaudi log file and show a summary with advice
  make-reproducer Create a minimal reproducer from a failed grid job
  cwl             CWL-based workflow commands (generate, run, validate, test)
```

### Testing a job

The primary command. Generates a CWL workflow from the production configuration and executes it locally:

```bash
lb-ap test MyAnalysis My2016MagDownJob
```

Key options:

```bash
lb-ap test MyAnalysis MyJob -i /path/to/input.dst   # Use a specific input file
lb-ap test MyAnalysis MyJob -n 100                   # Slice input to 100 events
lb-ap test MyAnalysis MyJob --n-lfns 5               # Test with 5 input LFNs
lb-ap test MyAnalysis MyJob --pick-smallest-lfn      # Use smallest LFN for speed
lb-ap test MyAnalysis MyJob --download               # Download input files locally
lb-ap test MyAnalysis MyJob --pretty                 # Real-time TUI monitoring
lb-ap test MyAnalysis MyJob --dry-run                # Validate without executing
lb-ap test MyAnalysis MyJob -o ./output              # Custom output directory
```

If arguments are omitted, an interactive wizard guides you through the setup.

The `-n <N>` flag slices the input file to N events using `GaudiConf.mergeDST:dst` (remote read, local write). After slicing, a reuse hint is printed so subsequent runs can skip the slicing step by passing the sliced file with `-i`.

### Custom input files

When testing a job that depends on another job, pass the upstream output with `-i`:

```bash
lb-ap test MyAnalysis MyDownstreamJob -i /path/to/upstream_output.dst
```

The input can be a local file path or an LFN (`LFN:/lhcb/...`).

### Analysing log files

Parse a Gaudi log file for FATAL, ERROR, and WARNING messages with contextual advice:

```bash
lb-ap parse-log DaVinci_00012345_00006789_1.log
```

Log analysis is also integrated into `lb-ap test` — after a test completes (success or failure), any Gaudi log files in the output are automatically analysed and a summary is displayed.

### Listing productions and jobs

```bash
lb-ap list                    # List available productions
lb-ap list MyAnalysis         # List jobs in a production
lb-ap list --tree             # Tree view of all productions and jobs
```

### Repository management

```bash
lb-ap clone --protocol ssh    # Clone AnalysisProductions
lb-ap checkout v1r4315        # Check out a version
lb-ap versions MyAnalysis     # List available versions
```

### Creating a minimal reproducer

From a failed grid job, create a self-contained reproducer package:

```bash
lb-ap make-reproducer 12345678                        # From DIRAC job ID
lb-ap make-reproducer --job-dir ./downloaded_job_dir   # From local job directory
```

## Development

**Platform:** pixi targets `linux-64` only (requires CERN CVMFS and DIRAC).

```bash
# On linux-64 (lxplus or CI):
pixi install
pixi run pytest              # Run tests
pixi run lb-ap               # Run the CLI

# Linting (any platform):
ruff check src/ tests/       # Lint
ruff check --fix src/        # Auto-fix
ruff format src/ tests/      # Format
```

## Legacy CLI

The original Click-based CLI is still available as `lb-ap-legacy` for backward compatibility but is deprecated.
