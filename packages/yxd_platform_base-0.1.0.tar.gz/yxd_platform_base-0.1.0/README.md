# yxd_platform_base

**平台脚本基类库**：提供 `BasePlatformScript`（`run()` / 浏览器 / 目录 / 保存 HTML / 附件下载），以及 Playwright CDP + Drission、文档导出等依赖，打在一个包里。

与 HTTP 小工具库 **`yxd_get_requests`**、其它名为 **`yxd_get_request`** 的包无关，避免命名冲突。

## 用法（子类）

```python
from pathlib import Path
import sys

_REPO = Path(__file__).resolve().parent.parent.parent  # 按你脚本所在层级调整
_LIB = _REPO / "my_packages" / "source_code" / "yxd_platform_base"
sys.path.insert(0, str(_LIB))

from yxd_platform_base import BasePlatformScript

class MySite(BasePlatformScript):
    def start_main(self):
        ...
```

或 `pip install -e` 本目录后直接 `from yxd_platform_base import BasePlatformScript`。

## 目录结构（与 ``yxd_get_requests`` 一致，便于 GUI/脚本识别可打包项目）

```text
yxd_platform_base/              ← 项目根（须选这一层；内含 pyproject.toml）
  pyproject.toml
  yxd_platform_base/            ← Python 包
    __init__.py
    __main__.py                 ← 支持 python -m yxd_platform_base
    VERSION
    ...
```

## 安装

```bash
pip install -e "E:\project\yxd_aotu_site\my_packages\source_code\yxd_platform_base"
```

需已执行：`playwright install chromium`。

## 仓库镜像

与 `E:\my_packages\source_code\yxd_platform_base` 保持同步时，对其中一方 `robocopy` 到另一方即可。
