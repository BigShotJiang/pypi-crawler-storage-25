# -*- coding: utf-8 -*-
"""
Playwright 子进程拉起 Chromium（CDP）→ DrissionPage 接管。

与完整抓包会话解耦，供统一启动器等轻量场景使用。
"""
from __future__ import annotations

import threading
import time
from typing import Any, Callable, Dict, Optional
from urllib.request import urlopen

from DrissionPage import ChromiumOptions, WebPage

from .browser_preflight import find_playwright_chromium_executable
from .chromium_spawn import (
    _spawn_playwright_chromium_cdp,
    _wait_chromium_cdp_http,
    _wait_chromium_cdp_target_page_tab,
)
from .yxd_fingerprint import apply_fingerprint_cdp, chromium_extra_args

LogFn = Callable[[str], None]


def _log_default(msg: str) -> None:
    print(msg)


def _ensure_blank_page(port: int) -> None:
    try:
        with urlopen("http://127.0.0.1:%d/json/new" % int(port), timeout=8.0) as r:
            r.read(4096)
    except Exception:
        pass


class BrowserSession:
    """持有 Chromium 子进程与 Drission WebPage，便于 GUI 关闭时清理。"""

    def __init__(self) -> None:
        self.chromium_proc: Any = None
        self.user_data_dir: Optional[str] = None
        self.page: Any = None

    def close(self, log: LogFn = _log_default) -> None:
        if self.page is not None:
            try:
                self.page.quit(force=True, del_data=False)
            except Exception:
                pass
            self.page = None
        if self.chromium_proc is not None:
            try:
                if self.chromium_proc.poll() is None:
                    self.chromium_proc.kill()
            except Exception:
                pass
            self.chromium_proc = None
        if self.user_data_dir:
            try:
                import shutil

                shutil.rmtree(self.user_data_dir, ignore_errors=True)
            except Exception:
                pass
            self.user_data_dir = None
        log("浏览器会话已结束。")


def start_playwright_then_drission(
    *,
    port: int,
    headless: bool,
    fingerprint: Dict[str, Any],
    join_delay_sec: float = 0.45,
    log: LogFn = _log_default,
) -> BrowserSession:
    """Playwright 的 Chromium 可执行文件起进程（CDP）→ Drission existing_only 接管。"""
    exe = find_playwright_chromium_executable()
    if not exe:
        raise RuntimeError("未找到 Playwright Chromium，请执行: playwright install chromium")

    extra = chromium_extra_args(fingerprint)
    sess = BrowserSession()
    sess.chromium_proc, sess.user_data_dir = _spawn_playwright_chromium_cdp(
        exe, int(port), headless, extra_args=extra
    )
    if not _wait_chromium_cdp_http(int(port)):
        sess.close(log)
        raise RuntimeError("CDP HTTP 在端口 %s 上未就绪" % port)
    time.sleep(max(0.0, float(join_delay_sec)))
    _ensure_blank_page(int(port))
    if not _wait_chromium_cdp_target_page_tab(int(port), timeout_sec=22.0):
        sess.close(log)
        raise RuntimeError("CDP /json 上无 page 目标，无法接入")

    co = ChromiumOptions(read_file=False)
    co.set_local_port(int(port))
    co.existing_only(True)
    co.set_argument("--remote-allow-origins=*")
    if headless:
        co.headless(True)
        co.set_argument("--headless", "new")
    else:
        co.headless(False)
        for a in ("--headless", "--headless=new", "--headless=old"):
            try:
                co.remove_argument(a)
            except Exception:
                pass
    log("DrissionPage 正在接入端口 %s …（无头=%s）" % (port, bool(headless)))
    sess.page = WebPage(chromium_options=co)
    tab = sess.page.latest_tab
    try:
        apply_fingerprint_cdp(tab, fingerprint)
        log("已应用指纹（CDP 覆盖）。")
    except Exception as ex:
        log("指纹 CDP 部分未生效: %s" % ex)
    return sess


def start_session_in_thread(
    *,
    port: int,
    headless: bool,
    fingerprint: Dict[str, Any],
    join_delay_sec: float = 0.45,
    on_ready: Callable[[BrowserSession], None],
    on_error: Callable[[BaseException], None],
    log: LogFn = _log_default,
) -> threading.Thread:
    def _run() -> None:
        try:
            sess = start_playwright_then_drission(
                port=port,
                headless=headless,
                fingerprint=fingerprint,
                join_delay_sec=join_delay_sec,
                log=log,
            )
            on_ready(sess)
        except BaseException as ex:
            on_error(ex)

    t = threading.Thread(target=_run, daemon=True)
    t.start()
    return t
