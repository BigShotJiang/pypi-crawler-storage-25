# -*- coding: utf-8 -*-
"""平台基类：仅封装页面保存与附件下载。"""
from __future__ import annotations

from abc import ABC, abstractmethod
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple
from urllib.parse import urljoin

from .yxd_doc_export import extract_attachment_pairs, save_download
from .yxd_browser_session import BrowserSession, start_playwright_then_drission


@dataclass
class SelectorSpec:
    """通用元素选择器：支持多种 by，并允许直接传原始查询表达式。"""

    by: str
    value: str


@dataclass
class TraverseLevel:
    """一层栏目遍历配置（父元素下遍历子元素）。"""

    parent: SelectorSpec
    children: SelectorSpec
    name: str = ""


@dataclass
class DetailListSpec:
    """详情列表配置。"""

    parent: SelectorSpec
    items: SelectorSpec
    name: str = "详情列表"


class BasePlatformScript(ABC):
    """基类仅保留通用能力：保存页面、解析附件、下载附件。"""

    def __init__(self) -> None:
        self.browser: Optional[BrowserSession] = None
        self.page: Optional[Any] = None
        self.tab: Optional[Any] = None
        # 新路线默认配置：子类可按需覆盖，但无需在 main 显式注入。
        self.entry_url: str = ""
        self.doc_root: Path = Path(".")
        self.sleep_sec: float = 0.35
        self.max_details: int = 0
        self.port: int = 15555
        self.headless: bool = False
        self.join_delay_sec: float = 0.45
        self.fingerprint: Dict[str, Any] = {}
        self._current_html: str = ""
        self._current_tab: Optional[Any] = None
        self._current_base_url: str = ""
        self._attachment_pairs: List[Tuple[str, Optional[str]]] = []
        self._attachment_out_dir: Optional[Path] = None
        self._attachment_sleep_sec: float = 0.35
        self._attachment_log: Optional[Callable[[str], None]] = None

    def ensure_output_dir(self, path: Path) -> Path:
        """统一目录创建入口：传入路径，存在则复用，不存在则创建。"""
        p = Path(path)
        p.mkdir(parents=True, exist_ok=True)
        return p

    def mackdir(self, path: Path | str) -> Tuple[Optional[Path], str]:
        """
        创建目录并清洗非法字符（统一替换为 ``_``）。
        仅需传入目标路径，返回 ``(目录Path, 错误原因)``：
        - 成功: ``(Path, "")``
        - 失败: ``(None, "失败原因")``
        """
        try:
            raw = str(path or "").strip()
            if not raw:
                p = self.ensure_output_dir(Path("."))
                return p, ""

            src = Path(raw)
            anchor = src.anchor  # 例如 "E:\\" 或 "/"
            cleaned: List[str] = []
            for seg in src.parts:
                if not seg:
                    continue
                # 保留根锚点/盘符，不参与非法字符替换
                if anchor and seg == anchor:
                    continue
                s = re.sub(r'[<>:"/\\|?*\x00-\x1f]+', "_", seg)
                s = re.sub(r"_+", "_", s).strip(" ._") or "untitled"
                cleaned.append(s)

            if anchor:
                p = Path(anchor, *cleaned)
            else:
                p = Path(*cleaned) if cleaned else Path(".")

            p = self.ensure_output_dir(p)
            return p, ""
        except Exception as ex:
            return None, str(ex)

    def mackdir_or_raise(self, path: Path | str) -> Path:
        """
        基类统一失败处理：目录创建失败时抛出带原因的异常。
        子类无需再自己判断错误字符串。
        """
        p, err = self.mackdir(path)
        if p is None:
            raise RuntimeError("创建目录失败: %s | %s" % (path, err))
        return p

    def start_browser(
        self,
        *,
        port: int,
        headless: bool,
        fingerprint: Dict[str, Any],
        join_delay_sec: float = 0.45,
        log: Optional[Callable[[str], None]] = None,
    ) -> None:
        """
        统一浏览器调起：启动 Chromium(CDP) 并接管，初始化 ``self.page`` / ``self.tab``。
        """
        if self.browser is not None:
            self.stop_browser(log=log)
        writer = log or (lambda m: print(m))
        sess = start_playwright_then_drission(
            port=int(port),
            headless=bool(headless),
            fingerprint=dict(fingerprint),
            join_delay_sec=float(join_delay_sec),
            log=writer,
        )
        self.browser = sess
        self.page = sess.page
        self.tab = sess.page.latest_tab if sess.page is not None else None
        self._current_tab = self.tab

    def stop_browser(self, *, log: Optional[Callable[[str], None]] = None) -> None:
        """统一浏览器关闭：清理进程与会话句柄。"""
        writer = log or (lambda m: print(m))
        if self.browser is not None:
            self.browser.close(writer)
        self.browser = None
        self.page = None
        self.tab = None
        self._current_tab = None

    def refresh_tab(self) -> Optional[Any]:
        """
        同步到当前最新标签页：``self.tab`` 始终指向 ``self.page.latest_tab``（若可用）。
        """
        if self.page is None:
            return self.tab
        try:
            latest = self.page.latest_tab
            if latest is not None:
                self.tab = latest
                self._current_tab = latest
        except Exception:
            pass
        return self.tab

    def open_url(self, url: str) -> None:
        """使用当前 ``tab`` 打开 URL。"""
        self.refresh_tab()
        if self.tab is None:
            raise RuntimeError("tab 未就绪，请先调用 start_browser(...)")
        self._tab_get(self.tab, url)
        self.refresh_tab()
        self._current_tab = self.tab

    def save_current_page(
        self,
        out_dir: Path,
        html: str,
        *,
        page_name: str = "index",
        log: Optional[Callable[[str], None]] = None,
    ) -> Path:
        out_dir.mkdir(parents=True, exist_ok=True)
        name = (page_name or "index").strip() or "index"
        path = out_dir / (name + ".html")
        path.write_text(html or "", encoding="utf-8")
        if log:
            log("写入 %s" % path)
        return path

    def set_current_page(self, *, html: str = "", tab: Optional[Any] = None, base_url: str = "") -> None:
        """设置当前页面上下文（供无参保存/下载使用）。"""
        if html:
            self._current_html = html
        if tab is not None:
            self._current_tab = tab
        if base_url:
            self._current_base_url = base_url

    def save_current_html(self, save_path: Path) -> Path:
        """
        保存当前 HTML（仅需传入完整文件路径）。
        例如：``save_path=Path('doc/xx/index.html')``。
        """
        p = Path(save_path)
        self.ensure_output_dir(p.parent)
        text = (self._current_html or "").strip()
        if not text and self._current_tab is not None:
            text = self._read_tab_html(self._current_tab).strip()
        if not text:
            text = self._current_html
        p.write_text(text or "", encoding="utf-8")
        self._current_html = text or ""
        return p

    def _set_attachment_context(self, out_path: Path) -> None:
        """
        附件上下文仅传保存路径。
        附件列表来自 ``set_current_page(base_url=...)`` + 当前 html 自动解析。
        """
        base_url = (self._current_base_url or "").strip()
        if not base_url:
            raise RuntimeError("未设置 base_url，请先调用 set_current_page(base_url=...)")
        self._attachment_pairs = extract_attachment_pairs(self._current_html or "", base_url)
        self._attachment_out_dir = self.ensure_output_dir(Path(out_path))

    def _download_attachments(self) -> None:
        """
        无参附件下载入口。
        必须先完成 ``_set_attachment_context(...)``。
        """
        if self._attachment_out_dir is None:
            raise RuntimeError("附件下载上下文未设置，请先完成 _set_attachment_context(...)")
        for i, (u, hint) in enumerate(self._attachment_pairs):
            save_download(
                u,
                self._attachment_out_dir,
                i,
                page_filename_hint=hint,
                log=self._attachment_log,
            )
            if self._attachment_sleep_sec > 0:
                time.sleep(self._attachment_sleep_sec)

    def _download_attachments_to_path(self, save_path: Path) -> None:
        """
        下载附件到指定路径。
        - ``save_path``: 附件保存目录（只需传路径）
        """
        out_dir = self.ensure_output_dir(Path(save_path))
        for i, (u, hint) in enumerate(self._attachment_pairs):
            save_download(
                u,
                out_dir,
                i,
                page_filename_hint=None,  # 始终优先保持线上文件名
                log=self._attachment_log,
            )
            if self._attachment_sleep_sec > 0:
                time.sleep(self._attachment_sleep_sec)

    def download_attachments_now(self, save_path: Path) -> int:
        """
        一步下载（自动准备 + 去重 + 下载）。
        返回实际下载任务数（去重后）。
        """
        self._set_attachment_context(save_path)
        uniq: List[Tuple[str, Optional[str]]] = []
        seen: set[str] = set()
        for u, hint in self._attachment_pairs:
            key = (u or "").strip()
            if not key or key in seen:
                continue
            seen.add(key)
            uniq.append((key, hint))
        self._attachment_pairs = uniq
        self._download_attachments_to_path(save_path)
        return len(uniq)

    @abstractmethod
    def start_main(self) -> Optional[int]:
        """
        子类统一实现的主流程入口。
        继承后只需在该函数里编排站点操作。
        """
        raise NotImplementedError

    def run(self) -> int:
        """
        统一执行入口：调用子类 ``start_main()``，并在此处统一回收资源。
        子类只关注页面操作，不需要负责浏览器回收。
        """
        rc: Optional[int] = 0
        try:
            # 统一初始化：进入 start_main 前确保 browser/page/tab 就绪。
            if self.browser is None or self.page is None or self.tab is None:
                self.start_browser(
                    port=self.port,
                    headless=self.headless,
                    fingerprint=self.fingerprint,
                    join_delay_sec=self.join_delay_sec,
                    log=print,
                )
            val = self.start_main()
            if val is None:
                rc = 0
            else:
                try:
                    rc = int(val)
                except (TypeError, ValueError):
                    rc = 0
        except Exception as ex:
            print("执行失败: %s" % ex)
            rc = 1
        finally:
            # 统一兜底回收：即使子类遗漏 stop_browser，也能在这里清理。
            self.stop_browser()
        return int(rc)

    def save_page_and_prepare_attachments(
        self,
        out_dir: Path,
        html: str,
        base_url: str,
        *,
        page_name: str = "index",
        sleep_sec: float = 0.35,
        log: Optional[Callable[[str], None]] = None,
    ) -> None:
        self.ensure_output_dir(out_dir)
        self._attachment_sleep_sec = max(0.0, float(sleep_sec))
        self._attachment_log = log
        self.set_current_page(html=html or "", base_url=base_url or "")
        self.save_current_html(out_dir / (page_name + ".html"))
        self._set_attachment_context(out_dir)

    def run_with_manual_config(
        self,
        *,
        tab: Any,
        out_root: Path,
        entry_url: str,
        main_level: Optional[TraverseLevel],
        sub_levels: Sequence[TraverseLevel],
        detail_lists: Sequence[DetailListSpec],
        sleep_sec: float = 0.35,
        max_details: int = 0,
        log: Optional[Callable[[str], None]] = None,
    ) -> int:
        """
        配置驱动执行：
        - 人工输入入口 URL
        - 指定主栏目及多级子栏目遍历规则
        - 指定详情列表规则
        """
        if entry_url.strip():
            self._tab_get(tab, entry_url.strip())
        out_root.mkdir(parents=True, exist_ok=True)
        if log:
            log("入口: %s" % (entry_url or "(当前页)"))

        level_paths = [out_root]
        all_levels = []
        if main_level is not None:
            all_levels.append(main_level)
        all_levels.extend(list(sub_levels))

        for lv_idx, lv in enumerate(all_levels):
            next_paths: List[Path] = []
            for base in level_paths:
                parents = self._select_elements(tab, lv.parent)
                if not parents:
                    continue
                for p in parents:
                    children = self._select_elements(p, lv.children)
                    if not children:
                        continue
                    for c_idx, c in enumerate(children):
                        label = self._element_label(c, fallback="L%d_%d" % (lv_idx + 1, c_idx + 1))
                        d = base / self._safe_name(label)
                        d.mkdir(parents=True, exist_ok=True)
                        self._click_element(c)
                        next_paths.append(d)
                        if log:
                            t = lv.name or ("层级%d" % (lv_idx + 1))
                            log("[%s] %s" % (t, label))
            if next_paths:
                level_paths = next_paths

        done = 0
        for base in level_paths:
            for ds in detail_lists:
                parents = self._select_elements(tab, ds.parent)
                for p in parents:
                    items = self._select_elements(p, ds.items)
                    for i_idx, item in enumerate(items):
                        if max_details and done >= max_details:
                            return done
                        title = self._element_label(item, fallback="detail_%d" % (i_idx + 1))
                        detail_dir = base / self._safe_name(title)
                        detail_dir.mkdir(parents=True, exist_ok=True)
                        href = self._element_attr(item, "href")
                        self._click_element(item)
                        html = self._read_tab_html(tab)
                        page_url = self._make_page_url(href, entry_url)
                        self.save_page_and_prepare_attachments(
                            detail_dir,
                            html,
                            page_url,
                            page_name="index",
                            sleep_sec=sleep_sec,
                            log=log,
                        )
                        self.download_attachments_now(detail_dir)
                        done += 1
                        if log:
                            log("[详情] %s" % title)
        return done

    def _make_page_url(self, href: str, entry_url: str) -> str:
        h = (href or "").strip()
        if not h:
            return entry_url
        if h.startswith(("http://", "https://")):
            return h
        return urljoin(entry_url, h)

    def _safe_name(self, text: str) -> str:
        s = (text or "").strip()
        if not s:
            return "untitled"
        s = re.sub(r'[<>:"/\\|?*\x00-\x1f]+', "_", s)
        s = re.sub(r"\s+", "_", s)
        s = re.sub(r"_+", "_", s).strip("._") or "untitled"
        return s[:120]

    def _tab_get(self, tab: Any, url: str) -> None:
        for fn in (lambda t, u: t.get(u), lambda t, u: t.open(u)):
            try:
                fn(tab, url)
                return
            except Exception:
                continue

    def _select_elements(self, ctx: Any, selector: SelectorSpec) -> List[Any]:
        self.refresh_tab()
        by = (selector.by or "auto").strip().lower()
        value = (selector.value or "").strip()
        if not value:
            return []
        # DrissionPage 风格
        try:
            if by in {"auto", "raw"}:
                return list(ctx.eles(value))
            if by == "xpath":
                return list(ctx.eles("xpath:%s" % value))
            if by == "id":
                return list(ctx.eles("#%s" % value))
            if by in {"css", "css_selector"}:
                return list(ctx.eles(value))
            if by == "class_name":
                return list(ctx.eles("." + value.lstrip(".")))
            if by == "name":
                return list(ctx.eles('[name="%s"]' % value))
            if by == "tag":
                return list(ctx.eles(value))
            if by == "link_text":
                return list(ctx.eles('xpath://a[normalize-space(text())="%s"]' % value))
            if by == "partial_link_text":
                return list(ctx.eles('xpath://a[contains(normalize-space(text()), "%s")]' % value))
            if by == "text":
                return list(ctx.eles('xpath://*[contains(normalize-space(text()), "%s")]' % value))
            return list(ctx.eles(value))
        except Exception:
            pass
        # Selenium 风格
        try:
            from selenium.webdriver.common.by import By  # type: ignore

            if by in {"auto", "raw"}:
                if value.startswith("/") or value.startswith("("):
                    return list(ctx.find_elements(By.XPATH, value))
                return list(ctx.find_elements(By.CSS_SELECTOR, value))
            if by == "xpath":
                return list(ctx.find_elements(By.XPATH, value))
            if by == "id":
                return list(ctx.find_elements(By.ID, value))
            if by in {"css", "css_selector"}:
                return list(ctx.find_elements(By.CSS_SELECTOR, value))
            if by == "class_name":
                return list(ctx.find_elements(By.CLASS_NAME, value))
            if by == "name":
                return list(ctx.find_elements(By.NAME, value))
            if by == "tag":
                return list(ctx.find_elements(By.TAG_NAME, value))
            if by == "link_text":
                return list(ctx.find_elements(By.LINK_TEXT, value))
            if by == "partial_link_text":
                return list(ctx.find_elements(By.PARTIAL_LINK_TEXT, value))
            return list(ctx.find_elements(By.CSS_SELECTOR, value))
        except Exception:
            return []

    def _click_element(self, ele: Any) -> None:
        for fn in (
            lambda e: e.click(),
            lambda e: e.click(by_js=True),
            lambda e: e.run_js("this.click()"),
        ):
            try:
                fn(ele)
                return
            except Exception:
                continue

    def _element_attr(self, ele: Any, name: str) -> str:
        for fn in (
            lambda e: e.attr(name),
            lambda e: e.get_attribute(name),
            lambda e: e.attrs.get(name, ""),
        ):
            try:
                v = fn(ele)
                if isinstance(v, str):
                    return v.strip()
            except Exception:
                continue
        return ""

    def _element_label(self, ele: Any, *, fallback: str) -> str:
        for fn in (
            lambda e: e.text,
            lambda e: e.texts()[0] if e.texts() else "",
            lambda e: e.get_attribute("title"),
            lambda e: e.attr("title"),
        ):
            try:
                v = fn(ele)
                if isinstance(v, str) and v.strip():
                    return v.strip()
            except Exception:
                continue
        href = self._element_attr(ele, "href")
        return href or fallback

    def _read_tab_html(self, tab: Any) -> str:
        self.refresh_tab()
        for getter in (
            lambda t: t.run_js("return document.documentElement.outerHTML"),
            lambda t: getattr(t, "html", ""),
            lambda t: getattr(t, "page_source", ""),
        ):
            try:
                v = getter(tab)
                if isinstance(v, str) and v.strip():
                    return v
            except Exception:
                continue
        return ""
