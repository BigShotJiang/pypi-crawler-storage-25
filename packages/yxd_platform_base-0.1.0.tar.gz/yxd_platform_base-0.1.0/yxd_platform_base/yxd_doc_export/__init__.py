# -*- coding: utf-8 -*-
"""
独立库：从 yxd_site_auto_out 下各平台采集目录导出详情 HTML 与附件到仓库根目录 doc/。
与 ``yxd_site_capture``（抓包）无导入依赖，可分开维护。

**统一的是导出管线**（``run_platform_cli`` / ``export_detail_to_doc`` 等），
**不统一的是各站在抓包里的目录树**：省/市/平台名、栏目、详情文件夹名均由抓包按 URL/标题落盘，站点之间可以完全不同。

**两种用法**（抓包数据均用于「发现平台下有哪些详情目录结构」）：

1. **默认**：读已抓下的 ``document/*.html``（跳过 ``resource.html``），再写 ``doc/`` 并下附件。
2. **``--dynamic``**：仍遍历同一棵采集目录树，但对含 ``document`` 的详情文件夹，若其目录名可还原 ``__https_…`` 页面 URL，则 **在线 GET 该 URL** 得到 HTML 再导出；抓包不必含正文 HTML，目录结构即可驱动现拉。（无可用 URL 时该节点仍回退尝试本地非 resource 的 .html。）

每个平台薄脚本里 **``PLATFORM_REL``** 须与 ``yxd_site_auto_out/<PLATFORM_REL>/`` 真实路径一致；``BASE_ORIGIN`` 作相对链接兜底。新平台：复制脚本 → 改常量 → ``launcher_platform_map.json`` 加映射。

目录规则：doc/<省>/<市>/<平台>/<与采集一致的栏目相对路径>/<详情文件夹名>/index.html + 附件文件
详情文件夹名为采集目录中「含 document 子目录」的那一层文件夹名（与抓包落盘约定一致）。
附件保存文件名优先级：HTTP ``Content-Disposition`` > 详情页链接文案或 ``title``（须带合法扩展名）> URL 路径 basename。

模块名前缀 ``yxd_`` 表示本库为 yxd 站点导出配套工具。
"""
from __future__ import annotations

import argparse
import os
import re
import shutil
import ssl
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Callable, Iterator, List, Optional, Sequence, Set, Tuple

from bs4 import BeautifulSoup


def yxd_anchor_root() -> Path:
    """
    工作区根目录：优先环境变量 ``YXD_ANCHOR_ROOT`` / ``YXD_REPO_ROOT``，否则为当前工作目录。
    （随 ``yxd_platform_base`` 打包后不再假设「包上一级即仓库根」。）
    """
    r = (os.environ.get("YXD_ANCHOR_ROOT") or os.environ.get("YXD_REPO_ROOT") or "").strip()
    if r:
        return Path(r).resolve()
    return Path.cwd().resolve()


def yxd_default_capture_root() -> Path:
    return yxd_anchor_root() / "yxd_site_auto_out"


def yxd_default_doc_root() -> Path:
    return yxd_anchor_root() / "doc"


# 常见附件后缀（含大小写）
ATTACHMENT_SUFFIXES: Tuple[str, ...] = (
    ".pdf",
    ".zip",
    ".rar",
    ".7z",
    ".doc",
    ".docx",
    ".xls",
    ".xlsx",
    ".ppt",
    ".pptx",
    ".wps",
    ".et",
    ".dwt",
    ".dwg",
    ".csv",
)

DEFAULT_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)


def safe_segment(name: str, max_len: int = 120) -> str:
    s = (name or "").strip()
    if not s:
        return "untitled"
    s = re.sub(r'[<>:"/\\|?*\x00-\x1f]+', "_", s)
    s = re.sub(r"_+", "_", s).strip("._") or "untitled"
    return s[:max_len]


def _suffix_lower(url: str) -> str:
    try:
        path = urllib.parse.urlparse(url).path
    except Exception:
        return ""
    _, ext = os.path.splitext(path.split("?")[0])
    return ext.lower()


def is_probable_attachment_url(url: str) -> bool:
    if not url or url.startswith("javascript:") or url.startswith("#"):
        return False
    low = url.lower()
    if "download" in low and any(low.endswith(s) or s in low for s in (".pdf", ".zip", ".doc", ".xls")):
        return True
    suf = _suffix_lower(url)
    return bool(suf and suf in ATTACHMENT_SUFFIXES)


def _hint_to_filename(hint: Optional[str]) -> Optional[str]:
    """详情页上链接文字 / title 等，若能识别为带扩展名的文件名则采用。"""
    if not hint:
        return None
    t = str(hint).strip()
    t = re.sub(r"[\r\n\t]+", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    if len(t) < 2 or len(t) > 220:
        return None
    if "/" in t or "\\" in t:
        t = os.path.basename(t.replace("\\", "/"))
    low = t.lower()
    if not any(low.endswith(s) for s in ATTACHMENT_SUFFIXES):
        return None
    return safe_segment(t, max_len=180)


def _anchor_page_filename_hint(tag: Any) -> Optional[str]:
    """从 ``<a>`` / ``<area>`` 的可见文案、``title`` 或内嵌 ``img@alt`` 推断附件展示名。"""
    try:
        text = tag.get_text(" ", strip=True)
    except Exception:
        text = ""
    h = _hint_to_filename(text)
    if h:
        return h
    title = tag.get("title")
    if title:
        h = _hint_to_filename(str(title).strip())
        if h:
            return h
    try:
        for img in tag.find_all("img", limit=6):
            h = _hint_to_filename(img.get("alt"))
            if h:
                return h
    except Exception:
        pass
    return None


def extract_attachment_pairs(html: str, base_url: str) -> List[Tuple[str, Optional[str]]]:
    """
    从详情 HTML 收集附件链接及页面上对应的「展示文件名」提示（去重、保序；同 URL 保留首次出现的提示）。
    下载时优先级：HTTP Content-Disposition > 页内提示 > URL 路径。
    """
    out: List[Tuple[str, Optional[str]]] = []
    seen: Set[str] = set()
    soup = BeautifulSoup(html, "html.parser")
    for tag in soup.find_all(["a", "area"]):
        href = tag.get("href")
        if not href:
            continue
        full = urllib.parse.urljoin(base_url, href.strip())
        if not is_probable_attachment_url(full):
            continue
        if full in seen:
            continue
        seen.add(full)
        out.append((full, _anchor_page_filename_hint(tag)))
    return out


def extract_attachment_urls(html: str, base_url: str) -> List[str]:
    """从详情 HTML 中收集附件链接（去重、保序）；等价于 ``[u for u, _ in extract_attachment_pairs(...)]``。"""
    return [u for u, _ in extract_attachment_pairs(html, base_url)]


def _request(
    url: str,
    *,
    timeout: float = 60.0,
    opener: Optional[urllib.request.OpenerDirector] = None,
) -> Tuple[bytes, Optional[str]]:
    req = urllib.request.Request(
        url,
        headers={"User-Agent": DEFAULT_UA, "Accept": "*/*"},
        method="GET",
    )

    def _open(op: urllib.request.OpenerDirector) -> Tuple[bytes, Optional[str]]:
        with op.open(req, timeout=timeout) as resp:
            data = resp.read()
            disp = resp.headers.get("Content-Disposition")
            return data, disp

    if opener is not None:
        return _open(opener)
    try:
        return _open(urllib.request.build_opener())
    except (urllib.error.URLError, OSError) as e:
        err = str(e).upper()
        if "SSL" in err or "CERTIFICATE" in err or "ECPOINT" in err:
            unverified = ssl._create_unverified_context()
            insecure = urllib.request.build_opener(
                urllib.request.HTTPSHandler(context=unverified)
            )
            return _open(insecure)
        raise


def fetch_url_text(url: str, *, timeout: float = 60.0) -> str:
    """GET 指定 URL，返回解码后的 HTML 文本（SSL 等与 ``_request`` 一致）。"""
    data, _ = _request(url, timeout=timeout)
    return data.decode("utf-8", errors="replace")


def filename_from_url(url: str, index: int) -> str:
    path = urllib.parse.urlparse(url).path
    base = os.path.basename(path.split("?")[0])
    if base and "." in base:
        return safe_segment(base, max_len=180)
    return "attachment_%d" % (index + 1)


def _filename_from_content_disposition(disp: Optional[str]) -> Optional[str]:
    """从 Content-Disposition 解析服务端文件名（尽量保留原名）。"""
    if not disp:
        return None
    if "filename=" not in disp.lower():
        return None
    m = re.search(r"filename\*=(?:UTF-8'')?([^;\s]+)", disp, re.I)
    if m:
        raw = urllib.parse.unquote(m.group(1).strip().strip('"'))
        return safe_segment(raw, max_len=180) if raw else None
    m = re.search(r'filename\s*=\s*"((?:\\.|[^"\\])*)"', disp, re.I)
    if m:
        raw = m.group(1).replace("\\\"", '"').replace("\\\\", "\\")
        return safe_segment(raw, max_len=180) if raw else None
    m = re.search(r"filename\s*=\s*([^;\s]+)", disp, re.I)
    if m:
        raw = urllib.parse.unquote(m.group(1).strip().strip('"'))
        return safe_segment(raw, max_len=180) if raw else None
    return None


def _curl_download_to_dir(
    url: str,
    dest_dir: Path,
    index: int,
    *,
    timeout: float = 120.0,
    page_filename_hint: Optional[str] = None,
    log: Optional[Callable[[str], None]] = None,
) -> Optional[Path]:
    """curl 下载到临时目录，从响应头取 Content-Disposition 定名，再移到 dest_dir（避免中文路径 -o 失败）。"""
    curl = shutil.which("curl")
    if not curl:
        return None
    dest_dir.mkdir(parents=True, exist_ok=True)
    td = Path(tempfile.mkdtemp(prefix="yxd_dl_"))
    body = td / "body.bin"
    hdr = td / "_headers.txt"
    try:
        r = subprocess.run(
            [
                curl,
                "-fsSL",
                "--connect-timeout",
                "30",
                "-m",
                str(int(timeout)),
                "-k",
                "-D",
                str(hdr),
                "-o",
                str(body),
                url,
            ],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        if r.returncode != 0 or not body.is_file() or body.stat().st_size == 0:
            return None
        hdr_text = hdr.read_text(encoding="utf-8", errors="replace")
        disp: Optional[str] = None
        for line in hdr_text.splitlines():
            if line.lower().startswith("content-disposition:"):
                disp = line.split(":", 1)[1].strip()
                break
        name = (
            _filename_from_content_disposition(disp)
            or _hint_to_filename(page_filename_hint)
            or filename_from_url(url, index)
        )
        dest = dest_dir / name
        if dest.exists():
            stem, suf = os.path.splitext(name)
            dest = dest_dir / ("%s_%d%s" % (stem, index, suf))
        if dest.exists():
            try:
                dest.unlink()
            except OSError:
                pass
        shutil.move(str(body), str(dest))
        if dest.is_file() and dest.stat().st_size > 0:
            return dest
        return None
    finally:
        try:
            shutil.rmtree(td, ignore_errors=True)
        except Exception:
            pass


def save_download(
    url: str,
    dest_dir: Path,
    index: int,
    *,
    page_filename_hint: Optional[str] = None,
    log: Optional[Callable[[str], None]] = None,
) -> Optional[Path]:
    try:
        data, disp = _request(url)
    except (urllib.error.URLError, OSError, TimeoutError) as e:
        dest = _curl_download_to_dir(
            url, dest_dir, index, timeout=120.0, page_filename_hint=page_filename_hint, log=log
        )
        if dest:
            if log:
                log("已保存(curl) %s" % dest.name)
            return dest
        if log:
            log("下载失败 %s — %s" % (url, e))
        return None

    name = (
        _filename_from_content_disposition(disp)
        or _hint_to_filename(page_filename_hint)
        or filename_from_url(url, index)
    )
    dest = dest_dir / name
    if dest.exists():
        stem, suf = os.path.splitext(name)
        dest = dest_dir / ("%s_%d%s" % (stem, index, suf))
    dest.write_bytes(data)
    if log:
        log("已保存 %s" % dest.name)
    return dest


def _folder_token_to_page_url(token: str) -> Optional[str]:
    """
    将落盘文件夹名中的 __https_ 后段还原为 https URL（下划线扁平域名 + 路径）。
    例: ggzyfw_beijing_gov_cn_jyxxzbgg_20260417_5500027 -> https://ggzyfw.beijing.gov.cn/jyxxzbgg/20260417/5500027
    """
    if "__https_" not in token:
        return None
    _, rest = token.split("__https_", 1)
    rest = rest.replace(".html", "").strip("_")
    parts = [p for p in rest.split("_") if p]
    if len(parts) < 4:
        return None
    cut = None
    for i in range(len(parts) - 1):
        if parts[i] == "gov" and parts[i + 1] == "cn":
            cut = i + 2
            break
        if parts[i] == "com" and parts[i + 1] == "cn":
            cut = i + 2
            break
        if parts[i] == "net" and parts[i + 1] == "cn":
            cut = i + 2
            break
    if cut is None or cut < 3:
        return None
    host = ".".join(parts[:cut])
    tail = parts[cut:]
    # 抓包目录里常把站点根落为 *_root；还原 URL 时应视为根路径。
    while tail and tail[-1].lower() in {"root", "index", "default"}:
        tail = tail[:-1]
    if not tail:
        return "https://%s/" % host
    return "https://%s/%s" % (host, "/".join(tail))


def infer_base_url_from_capture(detail_html: Path, fallback_origin: str) -> str:
    """
    优先从父级文件夹名中的 __https_... 片段还原页面 URL；否则用 fallback_origin。
    文件夹命名规则与抓包侧 ``capture_page_folder_name`` 约定一致（见 yxd_site_capture.core）。
    """
    parent = detail_html.parent.parent.name  # document 的上一级
    u = _folder_token_to_page_url(parent)
    if u:
        return u
    return fallback_origin.rstrip("/") + "/"


def diagnose_zero_detail_exports(platform_dir: Path) -> str:
    """
    当 ``run_platform_cli`` 处理 0 个详情页时，说明采集树与导出条件（便于区分「路径错了」与「只有壳层页」）。
    """
    if not platform_dir.is_dir():
        return "平台目录不存在: %s" % platform_dir
    rows: List[str] = []
    only_resource_everywhere = True
    for dirpath, dirnames, _ in os.walk(platform_dir):
        if "document" not in dirnames:
            continue
        dd = Path(dirpath) / "document"
        n_html = 0
        n_non_resource = 0
        try:
            for fn in os.listdir(dd):
                if not fn.lower().endswith(".html"):
                    continue
                n_html += 1
                if fn.lower() != "resource.html":
                    n_non_resource += 1
        except OSError:
            continue
        if n_html == 0:
            continue
        if n_non_resource > 0:
            only_resource_everywhere = False
        try:
            rel_dd = dd.relative_to(platform_dir)
        except ValueError:
            rel_dd = dd
        rows.append("  - %s：共 %d 个 .html，其中非 resource 共 %d 个" % (rel_dd, n_html, n_non_resource))
    if not rows:
        return (
            "采集树中未发现任何含 .html 的 document 目录。"
            "导出需要形如「…/某栏目/某详情文件夹/document/某页.html」；请用站点自动监听打开详情页后再导出。"
        )
    head = (
        "未导出任何详情页：默认跳过 document/resource.html（合并壳层），只导出同目录下其它 .html。\n"
        if only_resource_everywhere
        else "未导出任何详情页：存在非 resource 的 .html 但仍未进入任务（路径或过滤异常，可检查采集目录结构）。\n"
    )
    tail = "\n".join(rows[:15])
    if len(rows) > 15:
        tail += "\n  …（其余 %d 个 document 目录已省略）" % (len(rows) - 15)
    return head + tail


def iter_detail_tasks(
    platform_dir: Path,
    *,
    skip_resource: bool = True,
) -> Iterator[Tuple[Path, Tuple[str, ...]]]:
    """
    遍历平台目录下所有 document/*.html。
    返回 (html_path, relative_parts)：relative_parts 为 platform_dir 到「详情文件夹」的相对路径段。
    """
    if not platform_dir.is_dir():
        return
    for dirpath, dirnames, filenames in os.walk(platform_dir):
        if "document" not in dirnames:
            continue
        doc_dir = Path(dirpath) / "document"
        for fn in sorted(os.listdir(doc_dir)):
            if not fn.lower().endswith(".html"):
                continue
            if skip_resource and fn.lower() == "resource.html":
                continue
            html_path = doc_dir / fn
            detail_folder = html_path.parent.parent
            try:
                rel = detail_folder.relative_to(platform_dir)
            except ValueError:
                continue
            parts = tuple(str(p) for p in rel.parts)
            yield html_path, parts


def iter_export_tasks(
    platform_dir: Path,
    *,
    dynamic_fetch: bool = False,
    skip_resource: bool = True,
) -> Iterator[Tuple[str, Tuple[str, ...], Optional[Path], Optional[str]]]:
    """
    按抓包目录树生成导出任务（``platform_dir`` 下递归含 ``document`` 的节点为「详情位」）。

    每项为 ``(mode, rel_parts, html_path, page_url)``：

    - ``mode == "fetch"``：``page_url`` 非空，应对详情文件夹名中的 ``__https_…`` 现拉页面（``html_path`` 为 ``None``）。
    - ``mode == "local"``：从 ``html_path`` 读本地 ``document/*.html``（``page_url`` 为 ``None``）。

    ``dynamic_fetch=True`` 时：若某详情位可还原 ``page_url``，则只产出 ``fetch`` 任务（不再读该位下本地 HTML，避免重复）；
    否则仍产出 ``local`` 任务（与 ``iter_detail_tasks`` 一致）。
    """
    if not platform_dir.is_dir():
        return
    seen_fetch_urls: Set[str] = set()
    for dirpath, dirnames, _ in os.walk(platform_dir):
        if "document" not in dirnames:
            continue
        detail_folder = Path(dirpath)
        try:
            rel = detail_folder.relative_to(platform_dir)
        except ValueError:
            continue
        rel_parts = tuple(str(p) for p in rel.parts)
        page_url = _folder_token_to_page_url(detail_folder.name)
        if dynamic_fetch and page_url:
            if page_url in seen_fetch_urls:
                continue
            seen_fetch_urls.add(page_url)
            yield ("fetch", rel_parts, None, page_url)
            continue
        doc_dir = detail_folder / "document"
        try:
            fns = sorted(os.listdir(doc_dir))
        except OSError:
            continue
        for fn in fns:
            if not fn.lower().endswith(".html"):
                continue
            if skip_resource and fn.lower() == "resource.html":
                continue
            yield ("local", rel_parts, doc_dir / fn, None)


def export_detail_to_doc(
    detail_html: Path,
    platform_subpath: Tuple[str, ...],
    rel_under_platform: Tuple[str, ...],
    base_origin: str,
    *,
    doc_root: Optional[Path] = None,
    log: Optional[Callable[[str], None]] = None,
    sleep_sec: float = 0.35,
) -> None:
    """将单个详情页导出到 doc_root（默认仓库下 doc/）。"""
    root = doc_root if doc_root is not None else yxd_default_doc_root()
    text = detail_html.read_text(encoding="utf-8", errors="replace")
    base = infer_base_url_from_capture(detail_html, base_origin)
    pairs = extract_attachment_pairs(text, base)

    out_dir = root.joinpath(*platform_subpath, *rel_under_platform)
    out_dir.mkdir(parents=True, exist_ok=True)
    index_path = out_dir / "index.html"
    index_path.write_text(text, encoding="utf-8")
    if log:
        log("写入 %s" % index_path)

    for i, (u, hint) in enumerate(pairs):
        save_download(u, out_dir, i, page_filename_hint=hint, log=log)
        if sleep_sec > 0:
            time.sleep(sleep_sec)


def export_detail_from_fetched_html(
    html: str,
    platform_subpath: Tuple[str, ...],
    rel_under_platform: Tuple[str, ...],
    page_url: str,
    *,
    doc_root: Optional[Path] = None,
    log: Optional[Callable[[str], None]] = None,
    sleep_sec: float = 0.35,
) -> None:
    """将在线拉取的详情 HTML 写入 ``doc/`` 并解析附件（``page_url`` 用作相对链接基址）。"""
    root = doc_root if doc_root is not None else yxd_default_doc_root()
    base = page_url if page_url.endswith("/") else (page_url.rstrip("/") + "/")
    pairs = extract_attachment_pairs(html, base)

    out_dir = root.joinpath(*platform_subpath, *rel_under_platform)
    out_dir.mkdir(parents=True, exist_ok=True)
    index_path = out_dir / "index.html"
    index_path.write_text(html, encoding="utf-8")
    if log:
        log("写入(动态) %s" % index_path)

    for i, (u, hint) in enumerate(pairs):
        save_download(u, out_dir, i, page_filename_hint=hint, log=log)
        if sleep_sec > 0:
            time.sleep(sleep_sec)


def run_platform_cli(
    platform_rel: str,
    base_origin: str,
    *,
    description: str = "",
    dynamic_url_candidates: Optional[Callable[[str, Tuple[str, ...]], Sequence[str]]] = None,
) -> None:
    parser = argparse.ArgumentParser(description=description or ("导出: " + platform_rel))
    parser.add_argument(
        "--capture-root",
        type=str,
        default=str(yxd_default_capture_root()),
        help="采集根目录，默认仓库下 yxd_site_auto_out",
    )
    parser.add_argument(
        "--doc-root",
        type=str,
        default=str(yxd_default_doc_root()),
        help="导出根目录，默认仓库下 doc",
    )
    parser.add_argument("--sleep", type=float, default=0.35, help="附件下载间隔（秒）")
    parser.add_argument("--max", type=int, default=0, help="最多处理条数（0 表示不限制，用于试跑）")
    parser.add_argument(
        "--dynamic",
        action="store_true",
        help="按抓包目录结构在线拉取详情（详情文件夹名可还原 __https_ URL 时）；不依赖已保存的正文 HTML",
    )
    args = parser.parse_args()

    cap_root = Path(args.capture_root)
    doc_root = Path(args.doc_root)
    platform_rel_norm = platform_rel.replace("\\", "/")
    platform_dir = cap_root / platform_rel_norm
    parts = tuple(platform_rel_norm.split("/"))

    if not platform_dir.is_dir():
        print("未找到平台目录: %s" % platform_dir, file=sys.stderr)
        sys.exit(1)

    doc_root.mkdir(parents=True, exist_ok=True)

    n = 0
    log_print: Callable[[str], None] = lambda m: print(m)
    for mode, rel_parts, html_path, page_url in iter_export_tasks(
        platform_dir, dynamic_fetch=bool(args.dynamic), skip_resource=True
    ):
        if mode == "fetch" and page_url:
            urls = [page_url]
            if dynamic_url_candidates is not None:
                try:
                    extra = [u for u in dynamic_url_candidates(page_url, rel_parts) if str(u).strip()]
                    if extra:
                        urls = extra
                except Exception:
                    urls = [page_url]
            seen_u: Set[str] = set()
            ordered_urls: List[str] = []
            for u in urls:
                us = str(u).strip()
                if not us or us in seen_u:
                    continue
                seen_u.add(us)
                ordered_urls.append(us)
            text: Optional[str] = None
            used_url = page_url
            last_ex: Optional[BaseException] = None
            for u in ordered_urls:
                try:
                    text = fetch_url_text(u)
                    used_url = u
                    break
                except (urllib.error.URLError, OSError, TimeoutError) as ex:
                    last_ex = ex
                    continue
            if text is None:
                if last_ex is not None:
                    print("动态拉取失败 %s — %s" % (page_url, last_ex), file=sys.stderr)
                # 在线拉取失败时，若该详情位本地存在非 resource 的 html，回退本地导出。
                detail_dir = platform_dir.joinpath(*rel_parts)
                doc_dir = detail_dir / "document"
                fallback_html: Optional[Path] = None
                try:
                    for fn in sorted(os.listdir(doc_dir)):
                        if not fn.lower().endswith(".html"):
                            continue
                        if fn.lower() == "resource.html":
                            continue
                        fallback_html = doc_dir / fn
                        break
                except OSError:
                    fallback_html = None
                if fallback_html is None:
                    continue
                export_detail_to_doc(
                    fallback_html,
                    parts,
                    rel_parts,
                    base_origin,
                    doc_root=doc_root,
                    log=log_print,
                    sleep_sec=args.sleep,
                )
                n += 1
                if args.max and n >= args.max:
                    break
                continue
            export_detail_from_fetched_html(
                text,
                parts,
                rel_parts,
                used_url,
                doc_root=doc_root,
                log=log_print,
                sleep_sec=args.sleep,
            )
            n += 1
        elif mode == "local" and html_path is not None:
            rel_parts_local = rel_parts
            # 同一详情目录下若落了多份非 resource html，按文件名分子目录，避免反复覆盖同一个 index.html。
            stem = html_path.stem.strip()
            if stem and stem.lower() not in {"index", "default", "document"}:
                rel_parts_local = rel_parts + (stem,)
            export_detail_to_doc(
                html_path,
                parts,
                rel_parts_local,
                base_origin,
                doc_root=doc_root,
                log=log_print,
                sleep_sec=args.sleep,
            )
            n += 1
        if args.max and n >= args.max:
            break

    print("完成，共处理 %d 个详情页，输出根: %s" % (n, doc_root))
    if n == 0:
        print(diagnose_zero_detail_exports(platform_dir))
        if not args.dynamic:
            print(
                "若详情文件夹名含 __https_ 且可还原为页面 URL，可尝试加参数 --dynamic 按目录结构在线拉取正文。"
            )


def platform_docstring_header(
    title: str,
    structure_notes: str,
    base_origin: str,
    capture_rel: str,
) -> str:
    return (
        "%s\n\n站点根: %s\n采集相对路径: %s\n\n结构说明（来自 yxd_site_auto_out 与合并页分析）:\n%s\n"
        % (title, base_origin, capture_rel, structure_notes)
    )
