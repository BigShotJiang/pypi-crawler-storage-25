# yxd_platform_base/yxd_platform_base/__main__.py
"""支持 ``python -m yxd_platform_base``，与 ``yxd_get_requests`` 包结构一致。"""
from __future__ import annotations

from pathlib import Path


def main() -> None:
    pkg = Path(__file__).resolve().parent
    ver = (pkg / "VERSION").read_text(encoding="utf-8").strip()
    print("yxd_platform_base", ver)


if __name__ == "__main__":
    main()
