# yxd_platform_base/yxd_platform_base/__init__.py
# -*- coding: utf-8 -*-
"""
平台脚本基类库：``BasePlatformScript``、浏览器会话、doc 导出、附件下载。
"""
from __future__ import annotations

from pathlib import Path

_PKG_DIR = Path(__file__).resolve().parent
__version__ = (_PKG_DIR / "VERSION").read_text(encoding="utf-8").strip()

from .platform_base import BasePlatformScript
from .yxd_browser_session import BrowserSession, start_playwright_then_drission, start_session_in_thread
from .yxd_doc_export import extract_attachment_pairs, save_download

__all__ = [
    "__version__",
    "BasePlatformScript",
    "BrowserSession",
    "start_playwright_then_drission",
    "start_session_in_thread",
    "extract_attachment_pairs",
    "save_download",
]
