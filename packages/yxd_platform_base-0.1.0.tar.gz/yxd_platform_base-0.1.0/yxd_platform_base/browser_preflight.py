"""抓包会话前的浏览器环境：Playwright Chromium、DrissionPage 所用系统浏览器。

说明（无 Python 的目标机）：

- **DrissionPage**：Python 库已随 PyInstaller 打进 exe，目标机**不能**也**无需**再 pip 安装。
- **Playwright**：同上；**Chromium 可执行文件**不是 pip 的一部分。
- **方式 A（默认，exe 较小）**：首次抓包时用包内 ``node.exe`` + ``cli.js`` 执行 ``install chromium``；在 **frozen** 下会设置
  ``PLAYWRIGHT_BROWSERS_PATH=0``，把浏览器装到解压目录旁的 ``.local-browsers``（与 Playwright 驱动约定一致），**需联网**。
- **方式 B（离线）**：在打包机上执行 ``pack_gui_embed_chromium.bat``（先 ``PLAYWRIGHT_BROWSERS_PATH=0 playwright install chromium``），
  再把 Chromium 一并打进 exe，目标机无需再下载。
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Callable, List, Optional, Tuple

LogFn = Optional[Callable[[str], None]]

_WIN_CHROME = (
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
)
_WIN_EDGE = (
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
)


def _emit(log: LogFn, msg: str) -> None:
    if log:
        try:
            log(msg)
        except Exception:
            pass
    else:
        try:
            print(msg, flush=True)
        except Exception:
            pass


def apply_frozen_playwright_runtime_hints() -> None:
    """单文件/冻结环境下避免误删包内浏览器缓存目录。"""
    if getattr(sys, "frozen", False):
        os.environ.setdefault("PLAYWRIGHT_SKIP_BROWSER_GC", "1")


def _subprocess_no_window_kwargs() -> dict:
    if os.name != "nt":
        return {}
    cf = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    return {"creationflags": cf} if cf else {}


def _playwright_browser_roots() -> List[Path]:
    roots: List[Path] = []
    bp = (os.environ.get("PLAYWRIGHT_BROWSERS_PATH") or "").strip()
    if bp and bp != "0":
        roots.append(Path(bp))
    if sys.platform == "win32":
        la = (os.environ.get("LOCALAPPDATA") or "").strip()
        if la:
            roots.append(Path(la) / "ms-playwright")
    elif sys.platform == "darwin":
        roots.append(Path.home() / "Library" / "Caches" / "ms-playwright")
    else:
        roots.append(Path.home() / ".cache" / "ms-playwright")
    return roots


def _local_browsers_dir() -> Optional[Path]:
    """PLAYWRIGHT_BROWSERS_PATH=0 时 Chromium 所在目录（与驱动同包）。"""
    try:
        import playwright as pw  # noqa: WPS433
    except ImportError:
        return None
    d = Path(pw.__file__).resolve().parent / "driver" / "package" / ".local-browsers"
    return d if d.is_dir() else None


def _playwright_chromium_search_roots() -> List[Path]:
    """按 Playwright 查找顺序：自定义目录 → 包内 .local-browsers → 系统默认缓存。"""
    out: List[Path] = []
    seen: set[str] = set()

    def add(p: Path) -> None:
        if not p:
            return
        try:
            key = str(p.resolve())
        except OSError:
            key = str(p)
        if key in seen:
            return
        seen.add(key)
        out.append(p)

    bp = (os.environ.get("PLAYWRIGHT_BROWSERS_PATH") or "").strip()
    if bp and bp != "0":
        add(Path(bp))

    lb = _local_browsers_dir()
    if lb:
        add(lb)

    for p in _playwright_browser_roots():
        add(p)
    return out


def _chromium_glob_patterns() -> Tuple[str, ...]:
    if sys.platform == "win32":
        return (
            "chromium-*/chrome-win64/chrome.exe",
            "chromium-*/chrome-win/chrome.exe",
        )
    if sys.platform == "darwin":
        return ("chromium-*/chrome-mac/Chromium.app/Contents/MacOS/Chromium",)
    return ("chromium-*/chrome-linux/chrome",)


def _glob_playwright_chromium_exes(root: Path) -> List[Path]:
    if not root.is_dir():
        return []
    found: List[Path] = []
    for pat in _chromium_glob_patterns():
        found.extend(p for p in root.glob(pat) if p.is_file())
    found.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return found


def find_playwright_chromium_executable() -> Optional[str]:
    for root in _playwright_chromium_search_roots():
        xs = _glob_playwright_chromium_exes(root)
        if xs:
            return str(xs[0])
    return None


def _playwright_driver_node_and_cli() -> Tuple[Optional[Path], Optional[Path]]:
    try:
        import playwright as pw  # noqa: WPS433
    except ImportError:
        return None, None
    driver = Path(pw.__file__).resolve().parent / "driver"
    node = driver / ("node.exe" if sys.platform == "win32" else "node")
    cli = driver / "package" / "cli.js"
    if not node.is_file() or not cli.is_file():
        return None, None
    return node, cli


def ensure_playwright_python_package(log: LogFn) -> bool:
    try:
        import playwright  # noqa: F401, WPS433

        return True
    except ImportError:
        pass
    if getattr(sys, "frozen", False):
        _emit(
            log,
            "缺少 Python 包 playwright（打包环境无法 pip）。请使用完整依赖重新打包或安装带 Playwright 的发行版。",
        )
        return False
    exe = sys.executable
    try:
        _emit(log, "未检测到 playwright，正在执行: %s -m pip install playwright" % exe)
        subprocess.run(
            [exe, "-m", "pip", "install", "playwright"],
            check=True,
            timeout=900,
            stdin=subprocess.DEVNULL,
            **_subprocess_no_window_kwargs(),
        )
    except Exception as ex:
        _emit(log, "pip install playwright 失败: %s" % ex)
        return False
    try:
        import playwright  # noqa: F401, WPS433

        return True
    except ImportError:
        return False


def _run_playwright_install_chromium(log: LogFn) -> int:
    pair = _playwright_driver_node_and_cli()
    if not pair[0] or not pair[1]:
        _emit(log, "Playwright 驱动不完整（缺少 driver/node 或 cli.js），无法自动安装 Chromium。")
        return 1
    node, cli = pair
    _emit(log, "正在下载 Playwright Chromium（首次可能较慢，请保持网络畅通）…")
    cmd = [str(node), str(cli), "install", "chromium"]
    env = os.environ.copy()
    # 与 Playwright 在 frozen 下默认行为一致，否则浏览器会进 ms-playwright 而驱动仍找包内 .local-browsers
    if getattr(sys, "frozen", False):
        env["PLAYWRIGHT_BROWSERS_PATH"] = "0"
    try:
        proc = subprocess.run(
            cmd,
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=1200,
            **_subprocess_no_window_kwargs(),
        )
    except Exception as ex:
        _emit(log, "playwright install chromium 执行异常: %s" % ex)
        return 1
    if proc.returncode != 0:
        out = proc.stdout or ""
        if isinstance(out, str) and out.strip():
            lines = out.strip().splitlines()
            tail = "\n".join(lines[-12:])
            _emit(log, "playwright install chromium 退出码 %s，输出末尾:\n%s" % (proc.returncode, tail))
        else:
            _emit(log, "playwright install chromium 失败（退出码 %s）。" % proc.returncode)
        return int(proc.returncode or 1)
    _emit(log, "Playwright Chromium 已就绪。")
    return 0


def ensure_capture_browser_environment(log: LogFn) -> None:
    """
    会话开始前：保证 playwright 包存在（非 frozen 时可 pip）、Chromium 已下载到 Playwright 能识别的目录；
    供 Listen 双路起子进程与 Drission 备选路径共用。
    """
    apply_frozen_playwright_runtime_hints()
    if not ensure_playwright_python_package(log):
        return
    if find_playwright_chromium_executable():
        _emit(log, "Playwright Chromium 已就绪（包内或本机缓存），跳过下载。")
        return
    if _run_playwright_install_chromium(log) != 0:
        return
    time.sleep(0.25)
    if not find_playwright_chromium_executable():
        _emit(log, "Chromium 安装命令已执行，但仍未找到 chrome.exe，请检查网络、权限或换用「嵌入 Chromium」打包脚本。")


def _which_chrome_like() -> Optional[str]:
    for name in ("google-chrome", "chromium", "chromium-browser", "chrome"):
        w = shutil.which(name)
        if w and os.path.isfile(w):
            return w
    return None


def pick_chromium_executable_for_drission() -> Optional[str]:
    """优先 Playwright 的 Chromium，其次系统 Chrome / Edge（Windows）。"""
    pw = find_playwright_chromium_executable()
    if pw and os.path.isfile(pw):
        return pw
    if sys.platform == "win32":
        for p in _WIN_CHROME + _WIN_EDGE:
            if os.path.isfile(p):
                return p
    if sys.platform == "darwin":
        mac = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
        if os.path.isfile(mac):
            return mac
    return _which_chrome_like()


def apply_drission_chromium_executable_option(co: Any, log: LogFn) -> None:
    """在由 Drission 自行拉起浏览器时，尽量指定可执行文件，避免「未找到浏览器」。"""
    path = pick_chromium_executable_for_drission()
    if not path:
        _emit(log, "未找到本机 Chrome/Edge 或 Playwright Chromium，Drission 将尝试默认探测（可能失败）。")
        return
    try:
        co.set_browser_path(path)
        _emit(log, "Drission 将使用浏览器: %s" % path)
    except Exception as ex:
        _emit(log, "set_browser_path 失败（%s），仍尝试默认探测。" % ex)
