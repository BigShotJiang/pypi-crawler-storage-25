# -*- coding: utf-8 -*-
"""从 yxd_site_capture.core 抽出的 CDP 子进程启动与就绪探测（供浏览器会话复用）。"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import time
from typing import List, Optional, Sequence, Tuple
from urllib.error import URLError
from urllib.request import urlopen


def _wait_chromium_cdp_http(port: int, timeout_sec: float = 20.0) -> bool:
    """轮询 ``http://127.0.0.1:<port>/json/version``，直到 Chromium CDP HTTP 可访问或超时。"""
    url = "http://127.0.0.1:%d/json/version" % int(port)
    deadline = time.time() + float(timeout_sec)
    while time.time() < deadline:
        try:
            with urlopen(url, timeout=1.2) as resp:
                if resp.read(16):
                    return True
        except (URLError, OSError, ValueError):
            pass
        time.sleep(0.12)
    return False


def _wait_chromium_cdp_target_page_tab(port: int, timeout_sec: float = 22.0) -> bool:
    """
    DrissionPage ``existing_only`` 时会请求 ``/json``，且要求至少存在 ``type`` 为 ``page`` 或 ``webview`` 的目标。
    """
    addr = "http://127.0.0.1:%d/json" % int(port)
    deadline = time.time() + float(timeout_sec)
    while time.time() < deadline:
        try:
            with urlopen(addr, timeout=2.0) as resp:
                raw = resp.read()
            tabs = json.loads(raw.decode("utf-8", errors="replace"))
            if isinstance(tabs, list):
                for tab in tabs:
                    if isinstance(tab, dict) and tab.get("type") in ("page", "webview"):
                        return True
        except Exception:
            pass
        time.sleep(0.12)
    return False


_CHROMIUM_UI_QUIET_ARGS: Tuple[str, ...] = (
    "--disable-infobars",
    "--disable-blink-features=AutomationControlled",
    "--disable-features=ChromeForTestingInfoBar,HttpsUpgrades,HttpsFirstModeV2,HttpsFirstBalancedModeAutoEnable",
    "--disable-logging",
    "--log-level=3",
)


def _chromium_ui_quiet_args_for_cmdline() -> List[str]:
    out = list(_CHROMIUM_UI_QUIET_ARGS)
    if sys.platform.startswith("linux"):
        out.append("--no-sandbox")
    return out


def _spawn_playwright_chromium_cdp(
    chromium_executable: str,
    port: int,
    headless: bool,
    *,
    extra_args: Optional[Sequence[str]] = None,
) -> Tuple[subprocess.Popen, str]:
    """
    用 Playwright 自带的 Chromium 可执行文件单独起子进程，并显式打开 HTTP CDP。
    """
    user_data = tempfile.mkdtemp(prefix="yxd_chromium_")
    cmd: List[str] = [
        str(chromium_executable),
        "--remote-allow-origins=*",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-background-networking",
        "--user-data-dir=%s" % user_data,
        "--remote-debugging-port=%d" % int(port),
        "--remote-debugging-address=127.0.0.1",
    ]
    cmd.extend(_chromium_ui_quiet_args_for_cmdline())
    if extra_args:
        cmd.extend([str(x) for x in extra_args if str(x).strip()])
    if headless:
        cmd.append("--disable-gpu")
        cmd.append("--headless=new")
    else:
        cmd.append("--start-maximized")
    proc = subprocess.Popen(
        cmd,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        close_fds=os.name != "nt",
    )
    time.sleep(0.1)
    if proc.poll() is not None:
        raise RuntimeError(
            "Chromium 子进程已退出（退出码 %s）。请确认已执行: playwright install chromium"
            % proc.returncode
        )
    return proc, user_data
