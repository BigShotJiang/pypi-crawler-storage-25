# -*- coding: utf-8 -*-
"""
浏览器指纹：随机池来自 **JSON 预设**（``yxd_fingerprint_presets.json`` 或自定义路径），
单次会话字段来自随机 + 可选覆盖 JSON；CDP + 首屏脚本应用。

- **``fingerprint_presets``**：随机池（UA 列表、时区、分辨率档位、WebGL vendor/renderer 列表等）。
  可由 ``load_fingerprint_presets(path)`` 单独加载，或在指纹覆盖 JSON 里嵌套 ``fingerprint_presets`` 与磁盘预设浅合并。
- **``canvas_webgl_noise``**：噪声开关与覆盖；未填 vendor/renderer 时在池内 ``webgl_vendor_renderer_presets`` 中按 seed 选取。
- **``device_scale_factor`` / ``emulation_mobile``**：``Emulation.setDeviceMetricsOverride``。
- **``extra_chromium_args``**：字符串列表，追加到 Chromium 启动参数。

纯 CDP/注入无法替代真实 GPU；WebGL/Canvas 见模块内注释说明。
"""
from __future__ import annotations

import copy
import json
import random
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

_PRESET_DEFAULT_RELATIVE = "yxd_fingerprint_presets.json"


def default_fingerprint_presets_path() -> Path:
    """与 ``yxd_fingerprint.py`` 同目录的默认预设文件名。"""
    return Path(__file__).resolve().with_name(_PRESET_DEFAULT_RELATIVE)


_BUILTIN_PRESET_DEFAULTS: Dict[str, Any] = {
    "user_agents": [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36 Edg/119.0.0.0",
    ],
    "timezones": [
        "Asia/Shanghai",
        "Asia/Chongqing",
        "Asia/Urumqi",
        "Asia/Hong_Kong",
        "Asia/Tokyo",
        "America/New_York",
        "Europe/London",
    ],
    "locales": ["zh-CN", "zh-TW", "en-US", "en-GB"],
    "accept_language_zh": "zh-CN,zh;q=0.9",
    "accept_language_default": "en-US,en;q=0.9",
    "window_widths": [1280, 1366, 1440, 1536, 1920],
    "window_heights": [720, 768, 900, 864, 1080],
    "screen_width_jitter_max": 240,
    "screen_height_jitter_max": 160,
    "hardware_concurrency": [4, 6, 8, 12, 16],
    "device_memory_gb": [4, 8],
    "max_touch_points_options": [0],
    "navigator_platform_if_ua_contains": "Windows",
    "navigator_platform_win": "Win32",
    "navigator_platform_nonwin": "MacIntel",
    "webgl_vendor_renderer_presets": [
        {
            "vendor": "Google Inc. (NVIDIA)",
            "renderer": "ANGLE (NVIDIA, NVIDIA GeForce GTX 1660 SUPER Direct3D11 vs_5_0 ps_5_0, D3D11)",
        },
        {
            "vendor": "Google Inc. (NVIDIA)",
            "renderer": "ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Laptop GPU Direct3D11 vs_5_0 ps_5_0, D3D11)",
        },
        {
            "vendor": "Google Inc. (AMD)",
            "renderer": "ANGLE (AMD, AMD Radeon RX 6600 XT Direct3D11 vs_5_0 ps_5_0, D3D11)",
        },
        {
            "vendor": "Google Inc. (Intel)",
            "renderer": "ANGLE (Intel, Intel(R) UHD Graphics 770 Direct3D11 vs_5_0 ps_5_0, D3D11)",
        },
        {
            "vendor": "Google Inc. (Microsoft)",
            "renderer": "ANGLE (Microsoft, Microsoft Basic Render Driver Direct3D11 vs_5_0 ps_5_0, D3D11)",
        },
    ],
    "canvas_webgl_noise_defaults": {
        "default_canvas_touch_pixels": 32,
        "webgl_vendor_enum": 37445,
        "webgl_renderer_enum": 37446,
    },
}


def merge_fingerprint_presets(base: Dict[str, Any], overlay: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """浅合并：``overlay`` 中非 None 键覆盖 ``base``；``canvas_webgl_noise_defaults`` 为字典时做一层深度合并。"""
    out = dict(base)
    if not overlay:
        return out
    for k, v in overlay.items():
        if v is None:
            continue
        if k == "canvas_webgl_noise_defaults" and isinstance(v, dict):
            prev = out.get("canvas_webgl_noise_defaults")
            merged: Dict[str, Any] = dict(prev) if isinstance(prev, dict) else {}
            merged.update(v)
            out[k] = merged
        else:
            out[k] = v
    return out


def load_fingerprint_presets(path: str | Path | None) -> Dict[str, Any]:
    """
    加载随机池。``path`` 非空且文件存在时以该文件为准并与内置默认合并；
    否则若存在 ``default_fingerprint_presets_path()`` 则读取并合并；否则仅返回内置默认的拷贝。
    """
    raw: Dict[str, Any] = {}
    p = Path(path) if path else None
    if p and p.is_file():
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                raw = data
        except (json.JSONDecodeError, OSError):
            raw = {}
    elif not p:
        d0 = default_fingerprint_presets_path()
        if d0.is_file():
            try:
                data = json.loads(d0.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    raw = data
            except (json.JSONDecodeError, OSError):
                raw = {}
    return merge_fingerprint_presets(copy.deepcopy(_BUILTIN_PRESET_DEFAULTS), raw)


def resolve_session_fingerprint_presets(
    fp: Dict[str, Any],
    *,
    disk_presets_path: str | Path | None = None,
) -> Dict[str, Any]:
    """磁盘预设 + ``fp['fingerprint_presets']`` 浅合并，供随机与噪声解析。"""
    disk = load_fingerprint_presets((str(disk_presets_path).strip() or None) if disk_presets_path else None)
    nested = fp.get("fingerprint_presets")
    if isinstance(nested, dict):
        return merge_fingerprint_presets(disk, nested)
    return disk


def _pick_list(presets: Dict[str, Any], key: str, fallback: List[Any]) -> Any:
    xs = presets.get(key)
    if isinstance(xs, list) and xs:
        return random.choice(xs)
    return random.choice(fallback) if fallback else None


def _int_from(obj: Any, default: int) -> int:
    try:
        return int(obj)
    except (TypeError, ValueError):
        return default


def _normalized_webgl_pairs(presets: Dict[str, Any]) -> List[Tuple[str, str]]:
    raw = presets.get("webgl_vendor_renderer_presets")
    out: List[Tuple[str, str]] = []
    if isinstance(raw, list):
        for item in raw:
            if isinstance(item, dict):
                v = str(item.get("vendor") or "").strip()
                r = str(item.get("renderer") or "").strip()
                if v and r:
                    out.append((v, r))
            elif isinstance(item, (list, tuple)) and len(item) >= 2:
                v = str(item[0] or "").strip()
                r = str(item[1] or "").strip()
                if v and r:
                    out.append((v, r))
    if not out:
        for item in _BUILTIN_PRESET_DEFAULTS.get("webgl_vendor_renderer_presets") or []:
            if isinstance(item, dict):
                v = str(item.get("vendor") or "").strip()
                r = str(item.get("renderer") or "").strip()
                if v and r:
                    out.append((v, r))
    return out


def random_fingerprint(presets: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """按已合并的预设字典随机一条会话指纹（不含 ``fingerprint_presets`` 键）。"""
    p = presets if presets is not None else load_fingerprint_presets(None)
    ua = _pick_list(p, "user_agents", _BUILTIN_PRESET_DEFAULTS["user_agents"])
    loc = _pick_list(p, "locales", _BUILTIN_PRESET_DEFAULTS["locales"])
    if not isinstance(loc, str):
        loc = "zh-CN"
    al_zh = str(p.get("accept_language_zh") or "zh-CN,zh;q=0.9")
    al_def = str(p.get("accept_language_default") or "en-US,en;q=0.9")
    al = al_zh if loc.startswith("zh") else al_def
    tz = _pick_list(p, "timezones", _BUILTIN_PRESET_DEFAULTS["timezones"])
    w = _pick_list(p, "window_widths", _BUILTIN_PRESET_DEFAULTS["window_widths"])
    h = _pick_list(p, "window_heights", _BUILTIN_PRESET_DEFAULTS["window_heights"])
    try:
        wi, he = int(w), int(h)
    except (TypeError, ValueError):
        wi, he = 1366, 768
    jx = max(0, _int_from(p.get("screen_width_jitter_max"), 240))
    jy = max(0, _int_from(p.get("screen_height_jitter_max"), 160))
    hc = _pick_list(p, "hardware_concurrency", _BUILTIN_PRESET_DEFAULTS["hardware_concurrency"])
    dm = _pick_list(p, "device_memory_gb", _BUILTIN_PRESET_DEFAULTS["device_memory_gb"])
    try:
        hc_i = int(hc)
    except (TypeError, ValueError):
        hc_i = 8
    try:
        dm_f = float(dm)
    except (TypeError, ValueError):
        dm_f = 8.0
    mtp = _pick_list(p, "max_touch_points_options", _BUILTIN_PRESET_DEFAULTS["max_touch_points_options"])
    try:
        mtp_i = int(mtp)
    except (TypeError, ValueError):
        mtp_i = 0
    substr = str(p.get("navigator_platform_if_ua_contains") or "Windows")
    plat_win = str(p.get("navigator_platform_win") or "Win32")
    plat_other = str(p.get("navigator_platform_nonwin") or "MacIntel")
    ua_s = str(ua or "")
    plat = plat_win if substr in ua_s else plat_other
    return {
        "user_agent": ua_s,
        "locale": loc,
        "accept_language": al,
        "timezone_id": str(tz or "Asia/Shanghai"),
        "window_width": wi,
        "window_height": he,
        "screen_width": wi + random.randint(0, jx),
        "screen_height": he + random.randint(0, jy),
        "hardware_concurrency": hc_i,
        "device_memory": dm_f,
        "navigator_platform": plat,
        "max_touch_points": mtp_i,
    }


def load_fingerprint_json(path: str | Path) -> Dict[str, Any]:
    p = Path(path)
    raw = p.read_text(encoding="utf-8")
    data = json.loads(raw)
    if not isinstance(data, dict):
        raise ValueError("指纹配置须为 JSON 对象")
    return data


def merge_fingerprint(base: Dict[str, Any], overlay: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    if not overlay:
        return dict(base)
    out = dict(base)
    for k, v in overlay.items():
        if v is not None and v != "":
            out[k] = v
    return out


def chromium_extra_args(fp: Dict[str, Any]) -> List[str]:
    """追加到 Chromium 启动命令行的参数（不含端口与 user-data-dir）。"""
    args: List[str] = []
    ua = str(fp.get("user_agent") or "").strip()
    if ua:
        args.append("--user-agent=%s" % ua)
    loc = str(fp.get("locale") or "").strip()
    if loc:
        args.append("--lang=%s" % loc)
    w = fp.get("window_width")
    h = fp.get("window_height")
    try:
        wi, he = int(w), int(h)
        if wi >= 320 and he >= 240:
            args.append("--window-size=%d,%d" % (wi, he))
    except (TypeError, ValueError):
        pass
    for a in fp.get("extra_chromium_args") or []:
        s = str(a).strip()
        if s:
            args.append(s)
    return args


def _canvas_webgl_noise_enabled(block: Any) -> bool:
    if not isinstance(block, dict):
        return False
    v = block.get("enabled")
    if v is True:
        return True
    if isinstance(v, str) and v.strip().lower() in ("1", "true", "yes", "on"):
        return True
    return False


def _webgl_canvas_noise_inject_source(fp: Dict[str, Any]) -> Optional[str]:
    block = fp.get("canvas_webgl_noise")
    if not _canvas_webgl_noise_enabled(block):
        return None
    assert isinstance(block, dict)
    presets = fp.get("fingerprint_presets")
    if not isinstance(presets, dict):
        presets = {}
    nd = presets.get("canvas_webgl_noise_defaults")
    if not isinstance(nd, dict):
        nd = {}
    try:
        seed = int(block["seed"]) if block.get("seed") is not None else random.randint(1, 2**31 - 1)
    except (TypeError, ValueError):
        seed = random.randint(1, 2**31 - 1)
    vendor = str(block.get("webgl_vendor") or "").strip()
    renderer = str(block.get("webgl_renderer") or "").strip()
    pairs = _normalized_webgl_pairs(presets)
    if not vendor or not renderer:
        if pairs:
            pv, pr = pairs[abs(seed) % len(pairs)]
            vendor = vendor or pv
            renderer = renderer or pr
    try:
        pixels = int(block.get("canvas_touch_pixels"))
    except (TypeError, ValueError):
        try:
            pixels = int(nd.get("default_canvas_touch_pixels"))
        except (TypeError, ValueError):
            pixels = 32
    pixels = max(0, pixels)
    try:
        U = int(block.get("webgl_vendor_enum") or nd.get("webgl_vendor_enum") or 37445)
    except (TypeError, ValueError):
        U = 37445
    try:
        R = int(block.get("webgl_renderer_enum") or nd.get("webgl_renderer_enum") or 37446)
    except (TypeError, ValueError):
        R = 37446
    cfg = json.dumps(
        {
            "seed": abs(seed) % (2**32),
            "vendor": vendor,
            "renderer": renderer,
            "pixels": pixels,
            "U": U,
            "R": R,
        },
        ensure_ascii=False,
    )
    return (
        "(function(){var C=%s;var st=C.seed>>>0;"
        "function rng(){st=Math.imul(st^st>>>15,1|st);st^=st+Math.imul(st^st>>>7,61|st);"
        "return ((st^st>>>14)>>>0)/4294967296;}"
        "function patch(proto){var o=proto.getParameter;"
        "proto.getParameter=function(p){if(p===C.U)return C.vendor;if(p===C.R)return C.renderer;"
        "return o.apply(this,arguments);};}"
        "if(typeof WebGLRenderingContext!=='undefined')patch(WebGLRenderingContext.prototype);"
        "if(typeof WebGL2RenderingContext!=='undefined')patch(WebGL2RenderingContext.prototype);"
        "var once=new WeakSet();"
        "function touch(cv){if(!C.pixels||once.has(cv))return;var x=cv.getContext('2d');"
        "if(!x||!cv.width||!cv.height)return;try{var w=cv.width,h=cv.height,im=x.getImageData(0,0,w,h),"
        "d=im.data,n=C.pixels,i,p,b;for(i=0;i<n;i++){p=((rng()*w*h)|0)*4;b=(Math.floor(rng()*3)|0);"
        "d[p+b]=(d[p+b]^1)&255;}x.putImageData(im,0,0);once.add(cv);}catch(e){}}"
        "var d1=HTMLCanvasElement.prototype.toDataURL;"
        "HTMLCanvasElement.prototype.toDataURL=function(){try{touch(this);}catch(e){}"
        "return d1.apply(this,arguments);};"
        "var b1=HTMLCanvasElement.prototype.toBlob;"
        "if(b1)HTMLCanvasElement.prototype.toBlob=function(){try{touch(this);}catch(e){}"
        "return b1.apply(this,arguments);};})();"
    ) % cfg


def _navigator_hook_config(fp: Dict[str, Any]) -> Dict[str, Any]:
    """从指纹字典提取需注入的 Navigator / 硬件可读字段。"""
    out: Dict[str, Any] = {}
    if fp.get("hardware_concurrency") is not None:
        try:
            out["hardwareConcurrency"] = int(fp["hardware_concurrency"])
        except (TypeError, ValueError):
            pass
    if fp.get("device_memory") is not None:
        try:
            out["deviceMemory"] = float(fp["device_memory"])
        except (TypeError, ValueError):
            pass
    plat = str(fp.get("navigator_platform") or "").strip()
    if plat:
        out["platform"] = plat
    if fp.get("max_touch_points") is not None:
        try:
            out["maxTouchPoints"] = int(fp["max_touch_points"])
        except (TypeError, ValueError):
            pass
    return out


def _navigator_inject_source(hook: Dict[str, Any]) -> str:
    cfg = json.dumps(hook, ensure_ascii=False)
    return (
        "(function(){var C=%s;"
        "function def(obj,key,get){try{Object.defineProperty(obj,key,{get:get,configurable:true});}catch(e){}}"
        "if(C.hardwareConcurrency!=null)def(navigator,'hardwareConcurrency',function(){return C.hardwareConcurrency;});"
        "if(C.deviceMemory!=null)def(navigator,'deviceMemory',function(){return C.deviceMemory;});"
        "if(C.platform!=null)def(navigator,'platform',function(){return C.platform;});"
        "if(C.maxTouchPoints!=null)def(navigator,'maxTouchPoints',function(){return C.maxTouchPoints;});"
        "})();"
        % cfg
    )


def apply_fingerprint_cdp(tab: Any, fp: Dict[str, Any]) -> None:
    """在 DrissionPage 已连接的标签上应用 UA / 时区 / 语言 / 视口与屏幕 / Navigator / UA-CH / 可选 WebGL+Canvas 注入（失败则忽略）。"""
    ua = str(fp.get("user_agent") or "").strip()
    al = str(fp.get("accept_language") or "").strip()
    if ua:
        try:
            tab.run_cdp("Network.enable")
        except Exception:
            pass
        try:
            kwargs: Dict[str, Any] = {"userAgent": ua}
            if al:
                kwargs["acceptLanguage"] = al
            tab.run_cdp("Network.setUserAgentOverride", **kwargs)
        except Exception:
            pass
    tz = str(fp.get("timezone_id") or "").strip()
    if tz:
        try:
            tab.run_cdp("Emulation.setTimezoneOverride", timezoneId=tz)
        except Exception:
            pass
    loc = str(fp.get("locale") or "").strip()
    if loc:
        try:
            tab.run_cdp("Emulation.setLocaleOverride", locale=loc)
        except Exception:
            pass

    meta = fp.get("ua_metadata")
    if isinstance(meta, dict) and meta:
        try:
            tab.run_cdp("Emulation.setUserAgentMetadata", userAgentMetadata=meta)
        except Exception:
            try:
                tab.run_cdp("Emulation.setUserAgentMetadata", **meta)
            except Exception:
                pass

    ww = fp.get("window_width")
    wh = fp.get("window_height")
    sw = fp.get("screen_width")
    sh = fp.get("screen_height")
    try:
        dsf = float(fp.get("device_scale_factor", 1))
    except (TypeError, ValueError):
        dsf = 1.0
    if dsf <= 0:
        dsf = 1.0
    mobile = bool(fp.get("emulation_mobile", fp.get("device_mobile", False)))
    try:
        wi = int(ww) if ww is not None else 0
        he = int(wh) if wh is not None else 0
        if wi >= 320 and he >= 240:
            scr_w = int(sw) if sw is not None else wi
            scr_h = int(sh) if sh is not None else he
            scr_w = max(scr_w, wi)
            scr_h = max(scr_h, he)
            tab.run_cdp(
                "Emulation.setDeviceMetricsOverride",
                width=wi,
                height=he,
                deviceScaleFactor=dsf,
                mobile=mobile,
                screenWidth=scr_w,
                screenHeight=scr_h,
            )
    except (TypeError, ValueError):
        pass

    hook = _navigator_hook_config(fp)
    if hook:
        try:
            src = _navigator_inject_source(hook)
            tab.run_cdp("Page.addScriptToEvaluateOnNewDocument", source=src)
        except Exception:
            pass

    noise_src = _webgl_canvas_noise_inject_source(fp)
    if noise_src:
        try:
            tab.run_cdp("Page.addScriptToEvaluateOnNewDocument", source=noise_src)
        except Exception:
            pass
