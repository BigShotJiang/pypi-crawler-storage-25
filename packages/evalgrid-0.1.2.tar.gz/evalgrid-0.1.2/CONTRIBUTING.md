# Contributing to evalgrid

Thank you for your interest in contributing to evalgrid.

## Prerequisites

- Python 3.11 or newer
- Node.js 18+ (only if working on the dashboard)
- Git

## Dev Setup

```bash
git clone https://github.com/naman006-rai/evalgrid.git
cd evalgrid
pip install -e ".[dev]"
```

This installs evalgrid in editable mode along with test dependencies (pytest, ruff, mypy).

## Running Tests

```bash
pytest tests/ -v
```

All tests must pass before submitting a pull request. The CI workflow runs the full suite automatically.

To run a specific test file:

```bash
pytest tests/test_api.py -v
```

## Dashboard (optional)

If you are modifying the React dashboard:

```bash
cd dashboard
npm install
npm run dev      # dev server at localhost:5173
npm run build    # production build
```

After building, copy the output to the static directory:

```bash
# Windows (PowerShell)
Copy-Item -Recurse -Force dashboard\dist\* evalgrid\static\

# macOS / Linux
cp -r dashboard/dist/* evalgrid/static/
```

## Code Style

Python code is linted with `ruff` and type-checked with `mypy`:

```bash
ruff check evalgrid/
mypy evalgrid/
```

## PR Guidelines

1. Fork the repo and create a branch: `git checkout -b feat/my-feature`
2. Write tests for your change (keep coverage above 80%)
3. Run the full suite: `pytest tests/ -v`
4. Run linting: `ruff check evalgrid/`
5. Open a pull request against `main` with a clear description of what changes and why
6. CI will run evals and tests automatically — fix any failures before requesting review

## Reporting Issues

Open a GitHub issue at <https://github.com/naman006-rai/evalgrid/issues>.

Include:
- evalgrid version (`pip show evalgrid`)
- Python version (`python --version`)
- Steps to reproduce
- Expected vs actual behavior
