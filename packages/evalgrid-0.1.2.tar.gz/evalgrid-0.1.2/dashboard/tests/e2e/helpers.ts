import { Page } from "@playwright/test";
import { MOCK_RUNS, MOCK_RUN_DETAIL, MOCK_SCENARIOS, MOCK_RUN_POST } from "./fixtures";

export async function mockApi(page: Page, overrides: {
  runs?: object[];
  runDetail?: object;
  scenarios?: object[];
} = {}) {
  const runs = overrides.runs ?? MOCK_RUNS;
  const detail = overrides.runDetail ?? MOCK_RUN_DETAIL;
  const scenarios = overrides.scenarios ?? MOCK_SCENARIOS;

  await page.route("**/api/runs", async (route) => {
    if (route.request().method() === "GET") {
      await route.fulfill({ json: runs });
    } else {
      await route.fulfill({ json: MOCK_RUN_POST });
    }
  });

  await page.route("**/api/runs/**", async (route) => {
    await route.fulfill({ json: detail });
  });

  await page.route("**/api/scenarios**", async (route) => {
    if (route.request().method() === "GET") {
      await route.fulfill({ json: scenarios });
    } else {
      await route.fulfill({ json: { id: "new-scenario", name: "New Scenario", step_count: 1 } });
    }
  });
}

export async function goto(page: Page) {
  await page.goto("/");
  await page.waitForLoadState("domcontentloaded");
}

export async function openModal(page: Page) {
  await page.getByRole("button", { name: /run new eval/i }).first().click();
  await page.waitForSelector("text=Run new eval", { state: "visible" });
}
