export const MOCK_RUNS = [
  {
    run_id: "run-aaa-111",
    started_at: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
    finished_at: new Date(Date.now() - 4 * 60 * 1000 + 28000).toISOString(),
    pass_rate: 1.0,
    passed: 3,
    total: 3,
    status: "completed",
    scenario_names: ["Fix Off-By-One Error", "Fix Mutable Default", "Fix Missing Await"],
  },
  {
    run_id: "run-bbb-222",
    started_at: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
    finished_at: new Date(Date.now() - 29 * 60 * 1000 + 15000).toISOString(),
    pass_rate: 0.5,
    passed: 1,
    total: 2,
    status: "completed",
    scenario_names: ["Hello World", "SDR Lead Qualification"],
  },
  {
    run_id: "run-ccc-333",
    started_at: new Date(Date.now() - 2 * 60 * 1000).toISOString(),
    finished_at: null,
    pass_rate: 0,
    passed: 0,
    total: 1,
    status: "running",
    scenario_names: ["Fix Late-Binding Closure"],
  },
];

export const MOCK_RUN_DETAIL = {
  run_id: "run-aaa-111",
  started_at: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
  finished_at: new Date(Date.now() - 4 * 60 * 1000 + 28000).toISOString(),
  pass_rate: 1.0,
  passed: 3,
  total: 3,
  status: "completed",
  scenario_results: [
    {
      scenario_id: "fix-off-by-one",
      scenario_name: "Fix Off-By-One Error",
      agent_type: "coding",
      status: "pass",
      overall_score: 1.0,
      pass_rate: 1.0,
      reasoning: "Perfect identification and fix of range(len(arr)) off-by-one.",
      error: null,
      steps: [
        { step_index: 0, action: "identify_bug_location", status: "pass", score: 1.0, reasoning: "Pinpointed range(len(arr)) as the source." },
        { step_index: 1, action: "explain_root_cause",    status: "pass", score: 1.0, reasoning: "Clear explanation with concrete example." },
        { step_index: 2, action: "propose_fix",           status: "pass", score: 1.0, reasoning: "Correct fix using range(len(arr)-1)." },
        { step_index: 3, action: "verify_edge_cases",     status: "pass", score: 1.0, reasoning: "All edge cases verified in a table." },
      ],
    },
  ],
};

export const MOCK_SCENARIOS = [
  { id: "fix-off-by-one",    name: "Fix Off-By-One Error",         agent_type: "coding",  step_count: 4, tags: ["python", "bug-fix"], suite: "python-bug-fixer" },
  { id: "fix-mutable-default", name: "Fix Mutable Default Argument", agent_type: "coding",  step_count: 4, tags: ["python", "gotcha"],  suite: "python-bug-fixer" },
  { id: "fix-async-missing-await", name: "Fix Missing Await",       agent_type: "coding",  step_count: 4, tags: ["python", "async"],   suite: "python-bug-fixer" },
  { id: "fix-closure-loop",  name: "Fix Late-Binding Closure",      agent_type: "coding",  step_count: 4, tags: ["python", "closures"], suite: "python-bug-fixer" },
  { id: "example-hello-world", name: "Hello World",                 agent_type: "generic", step_count: 3, tags: ["basic"],             suite: "default" },
  { id: "sdr-qualify-lead",  name: "SDR Lead Qualification",        agent_type: "sdr",     step_count: 5, tags: ["sdr", "bant"],       suite: "default" },
];

export const MOCK_RUN_POST = {
  run_id: "run-new-999",
  started_at: new Date().toISOString(),
  finished_at: null,
  pass_rate: 0,
  passed: 0,
  total: 1,
  status: "running",
  scenario_names: [],
};
