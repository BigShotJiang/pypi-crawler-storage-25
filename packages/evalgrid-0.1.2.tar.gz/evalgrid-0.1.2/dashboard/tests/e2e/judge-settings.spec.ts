import { test, expect } from "@playwright/test";
import { mockApi, goto, openModal } from "./helpers";

test.describe("Judge Settings — Existing Scenarios Tab", () => {
  test.beforeEach(async ({ page }) => {
    await mockApi(page);
    await goto(page);
    await openModal(page);
  });

  test("shows Judge model dropdown with default selection", async ({ page }) => {
    const select = page.getByLabel("Judge model");
    await expect(select).toBeVisible();
    await expect(select).toHaveValue("claude-sonnet-4-6");
  });

  test("shows API key input for default (Anthropic) model", async ({ page }) => {
    await expect(page.getByPlaceholder(/ANTHROPIC_API_KEY/i)).toBeVisible();
  });

  test("switching to OpenAI model updates key hint placeholder", async ({ page }) => {
    await page.getByLabel("Judge model").selectOption("gpt-4o");
    await expect(page.getByPlaceholder(/OPENAI_API_KEY/i)).toBeVisible();
  });

  test("switching to Google model updates key hint placeholder", async ({ page }) => {
    await page.getByLabel("Judge model").selectOption("gemini/gemini-2.0-flash");
    await expect(page.getByPlaceholder(/GEMINI_API_KEY/i)).toBeVisible();
  });

  test("Ollama model hides API key input", async ({ page }) => {
    await page.getByLabel("Judge model").selectOption("ollama/llama3.1:70b");
    await expect(page.getByPlaceholder(/api key/i)).not.toBeVisible();
  });

  test("API key input shows dots by default (password type)", async ({ page }) => {
    const keyInput = page.getByPlaceholder(/ANTHROPIC_API_KEY/i);
    await expect(keyInput).toHaveAttribute("type", "password");
  });

  test("Show/Hide toggle reveals API key text", async ({ page }) => {
    const keyInput = page.getByPlaceholder(/ANTHROPIC_API_KEY/i);
    await keyInput.fill("sk-test-key-123");
    await page.getByRole("button", { name: /show/i }).click();
    await expect(keyInput).toHaveAttribute("type", "text");
  });

  test("Show/Hide toggle hides API key after second click", async ({ page }) => {
    const keyInput = page.getByPlaceholder(/ANTHROPIC_API_KEY/i);
    await keyInput.fill("sk-test-key-123");
    await page.getByRole("button", { name: /show/i }).click();
    await page.getByRole("button", { name: /hide/i }).click();
    await expect(keyInput).toHaveAttribute("type", "password");
  });

  test("judge_model sent in POST when changed", async ({ page }) => {
    const postRequest = page.waitForRequest((req) =>
      req.url().includes("/api/runs") && req.method() === "POST"
    );
    await page.getByLabel("Judge model").selectOption("gpt-4o");
    await page.getByText("Fix Off-By-One Error").click();
    await page.getByRole("button", { name: /run eval/i }).click();
    const req = await postRequest;
    const body = JSON.parse(req.postData() ?? "{}");
    expect(body.judge_model).toBe("gpt-4o");
  });

  test("api_key sent in POST when provided", async ({ page }) => {
    const postRequest = page.waitForRequest((req) =>
      req.url().includes("/api/runs") && req.method() === "POST"
    );
    await page.getByPlaceholder(/ANTHROPIC_API_KEY/i).fill("sk-my-key");
    await page.getByText("Fix Off-By-One Error").click();
    await page.getByRole("button", { name: /run eval/i }).click();
    const req = await postRequest;
    const body = JSON.parse(req.postData() ?? "{}");
    expect(body.api_key).toBe("sk-my-key");
  });
});

test.describe("Judge Settings — New Scenario Tab", () => {
  test.beforeEach(async ({ page }) => {
    await mockApi(page);
    await goto(page);
    await openModal(page);
    await page.getByRole("button", { name: "New scenario" }).click();
  });

  test("judge settings visible on New Scenario tab", async ({ page }) => {
    await expect(page.getByLabel("Judge model")).toBeVisible();
  });

  test("Ollama model hides API key on New Scenario tab", async ({ page }) => {
    await page.getByLabel("Judge model").selectOption("ollama/llama3.1:70b");
    await expect(page.getByPlaceholder(/api key/i)).not.toBeVisible();
  });

  test("judge_model included in run POST from New Scenario tab", async ({ page }) => {
    const runPost = page.waitForRequest((req) =>
      req.url().includes("/api/runs") && req.method() === "POST"
    );
    await page.getByLabel("Name").fill("Judge test");
    await page.getByLabel("System prompt").fill("Be helpful.");
    await page.getByLabel("Test input").fill("Hello!");
    await page.getByLabel("Judge model").selectOption("gpt-4o-mini");
    await page.getByRole("button", { name: /create.*run/i }).click();
    const req = await runPost;
    const body = JSON.parse(req.postData() ?? "{}");
    expect(body.judge_model).toBe("gpt-4o-mini");
  });
});
