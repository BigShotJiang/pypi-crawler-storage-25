import { test, expect } from "@playwright/test";
import { mockApi, goto } from "./helpers";
import { MOCK_RUNS } from "./fixtures";

test.describe("Runs Tab", () => {
  test.beforeEach(async ({ page }) => {
    await mockApi(page);
    await goto(page);
  });

  test("displays run list after API load", async ({ page }) => {
    await expect(page.getByText("Fix Off-By-One Error")).toBeVisible();
    await expect(page.getByText("Hello World")).toBeVisible();
  });

  test("shows pass/fail/running badges", async ({ page }) => {
    const passed = page.locator("text=Passed").first();
    const failed = page.locator("text=Failed").first();
    await expect(passed).toBeVisible();
    await expect(failed).toBeVisible();
  });

  test("shows run count in filter pills", async ({ page }) => {
    await expect(page.getByText("All")).toBeVisible();
    await expect(page.getByText("Pass")).toBeVisible();
    await expect(page.getByText("Fail")).toBeVisible();
    await expect(page.getByText("Running")).toBeVisible();
  });

  test("filter by Pass shows only passing runs", async ({ page }) => {
    await page.getByRole("button", { name: /^Pass/ }).click();
    await expect(page.getByText("Fix Off-By-One Error")).toBeVisible();
    await expect(page.getByText("Fix Late-Binding Closure")).not.toBeVisible();
  });

  test("filter by Running shows only running runs", async ({ page }) => {
    await page.getByRole("button", { name: /^Running/ }).click();
    await expect(page.getByText("Fix Late-Binding Closure")).toBeVisible();
    await expect(page.getByText("Fix Off-By-One Error")).not.toBeVisible();
  });

  test("filter by Fail shows nothing-passing message", async ({ page }) => {
    await mockApi(page, { runs: MOCK_RUNS.filter((r) => r.pass_rate === 1.0) });
    await page.reload();
    await page.getByRole("button", { name: /^Fail/ }).click();
    await expect(page.getByText(/everything is passing/i)).toBeVisible();
  });

  test("search filters runs by name", async ({ page }) => {
    await page.getByPlaceholder(/search/i).fill("off-by");
    await expect(page.getByText("Fix Off-By-One Error")).toBeVisible();
    await expect(page.getByText("Hello World")).not.toBeVisible();
  });

  test("search with no match shows no results", async ({ page }) => {
    await page.getByPlaceholder(/search/i).fill("zzznomatch");
    await expect(page.getByText(/no runs match/i)).toBeVisible();
  });

  test("clears filter back to All", async ({ page }) => {
    await page.getByRole("button", { name: /^Pass/ }).click();
    await page.getByRole("button", { name: /^All/ }).click();
    await expect(page.getByText("Fix Off-By-One Error")).toBeVisible();
    await expect(page.getByText("Fix Late-Binding Closure")).toBeVisible();
  });

  test("expands run to show step breakdown", async ({ page }) => {
    await page.getByText("Fix Off-By-One Error").first().click();
    await expect(page.getByText("identify_bug_location")).toBeVisible();
    await expect(page.getByText("Step breakdown")).toBeVisible();
  });

  test("collapsed run shows no step detail", async ({ page }) => {
    await expect(page.getByText("identify_bug_location")).not.toBeVisible();
  });

  test("expanding a run fetches /api/runs/:id", async ({ page }) => {
    const detailRequest = page.waitForRequest((req) =>
      req.url().includes("/api/runs/run-aaa-111") && req.method() === "GET"
    );
    await page.getByText("Fix Off-By-One Error").first().click();
    await detailRequest;
  });

  test("step scores are shown as percentages", async ({ page }) => {
    await page.getByText("Fix Off-By-One Error").first().click();
    await expect(page.getByText("100%").first()).toBeVisible();
  });

  test("run duration is displayed", async ({ page }) => {
    await expect(page.getByText(/\d+\.\d+s/).first()).toBeVisible();
  });

  test("shows run ID in monospace", async ({ page }) => {
    await expect(page.getByText("run-aaa")).toBeVisible();
  });

  test("shows scenario count label", async ({ page }) => {
    await expect(page.getByText("3 scenarios").first()).toBeVisible();
  });
});
