import { test, expect } from "@playwright/test";
import { mockApi, goto } from "./helpers";

test.describe("Scenarios Tab", () => {
  test.beforeEach(async ({ page }) => {
    await mockApi(page);
    await goto(page);
    await page.getByRole("button", { name: "Scenarios", exact: true }).click();
  });

  test("shows Scenarios heading", async ({ page }) => {
    await expect(page.getByRole("heading", { name: /^scenarios$/i })).toBeVisible();
  });

  test("shows scenario count badge", async ({ page }) => {
    await expect(page.getByText("6")).toBeVisible();
  });

  test("shows suite groups", async ({ page }) => {
    await expect(page.getByText("python-bug-fixer")).toBeVisible();
    await expect(page.getByText("default")).toBeVisible();
  });

  test("shows scenario count per suite", async ({ page }) => {
    await expect(page.getByText("4 scenarios").first()).toBeVisible();
    await expect(page.getByText("2 scenarios").first()).toBeVisible();
  });

  test("expands suite to show scenarios", async ({ page }) => {
    await page.getByText("python-bug-fixer").click();
    await expect(page.getByText("Fix Off-By-One Error")).toBeVisible();
    await expect(page.getByText("Fix Mutable Default Argument")).toBeVisible();
  });

  test("shows agent type badge inside expanded suite", async ({ page }) => {
    await page.getByText("python-bug-fixer").click();
    await expect(page.getByText("coding").first()).toBeVisible();
  });

  test("shows step count inside expanded suite", async ({ page }) => {
    await page.getByText("python-bug-fixer").click();
    await expect(page.getByText("4 steps").first()).toBeVisible();
  });

  test("shows tags inside expanded suite", async ({ page }) => {
    await page.getByText("python-bug-fixer").click();
    await expect(page.getByText("python").first()).toBeVisible();
    await expect(page.getByText("bug-fix").first()).toBeVisible();
  });

  test("collapses suite after second click", async ({ page }) => {
    await page.getByText("python-bug-fixer").click();
    await expect(page.getByText("Fix Off-By-One Error")).toBeVisible();
    await page.getByText("python-bug-fixer").click();
    await expect(page.getByText("Fix Off-By-One Error")).not.toBeVisible();
  });

  test("multiple suites can be expanded simultaneously", async ({ page }) => {
    await page.getByText("python-bug-fixer").click();
    await page.getByText("default").click();
    await expect(page.getByText("Fix Off-By-One Error")).toBeVisible();
    await expect(page.getByText("Hello World")).toBeVisible();
  });

  test("scenario description is shown", async ({ page }) => {
    await page.getByText("python-bug-fixer").click();
  });

  test("empty state shown when no scenarios", async ({ page }) => {
    await mockApi(page, { scenarios: [] });
    await page.reload();
    await page.getByRole("button", { name: "Scenarios", exact: true }).click();
    await expect(page.getByText(/no scenarios found/i)).toBeVisible();
  });
});
