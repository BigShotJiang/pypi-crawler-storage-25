import { test, expect } from "@playwright/test";
import { mockApi, goto } from "./helpers";

test.describe("Dashboard Tab", () => {
  test.beforeEach(async ({ page }) => {
    await mockApi(page);
    await goto(page);
    await page.getByRole("button", { name: "Dashboard" }).click();
  });

  test("shows pass rate card", async ({ page }) => {
    await expect(page.getByText("Pass rate")).toBeVisible();
  });

  test("shows numeric pass rate", async ({ page }) => {
    await expect(page.getByText(/\d+\.\d+/).first()).toBeVisible();
  });

  test("shows ring chart with total/pass/fail/live counts", async ({ page }) => {
    await expect(page.getByText("total")).toBeVisible();
    await expect(page.getByText("pass")).toBeVisible();
    await expect(page.getByText("fail")).toBeVisible();
    await expect(page.getByText("live")).toBeVisible();
  });

  test("shows avg latency card", async ({ page }) => {
    await expect(page.getByText("Avg latency")).toBeVisible();
  });

  test("shows latency in seconds", async ({ page }) => {
    await expect(page.getByText("s").first()).toBeVisible();
  });

  test("shows Recent runs heading", async ({ page }) => {
    await expect(page.getByRole("heading", { name: /recent runs/i })).toBeVisible();
  });

  test("lists up to 5 recent runs", async ({ page }) => {
    const runCards = page.locator(".ae-root [style*='border-radius']").filter({ hasText: /passed|failed|running/i });
    const count = await runCards.count();
    expect(count).toBeGreaterThan(0);
    expect(count).toBeLessThanOrEqual(5);
  });

  test("View all link navigates to Runs tab", async ({ page }) => {
    await page.getByRole("button", { name: /view all/i }).click();
    await expect(page.getByRole("heading", { name: /eval runs/i })).toBeVisible();
  });

  test("Run new eval button opens modal", async ({ page }) => {
    await page.getByRole("button", { name: /run new eval/i }).first().click();
    await expect(page.getByText("Pick a scenario to evaluate")).toBeVisible();
  });

  test("shows run count in subtitle", async ({ page }) => {
    await expect(page.getByText(/\d+ runs/)).toBeVisible();
  });
});
