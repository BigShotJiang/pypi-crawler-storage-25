import { test, expect } from "@playwright/test";
import { mockApi, goto } from "./helpers";

test.describe("Navigation", () => {
  test.beforeEach(async ({ page }) => {
    await mockApi(page);
    await goto(page);
  });

  test("loads on Runs tab by default", async ({ page }) => {
    await expect(page.getByText("Eval Runs")).toBeVisible();
  });

  test("switches to Dashboard tab", async ({ page }) => {
    await page.getByRole("button", { name: "Dashboard", exact: true }).click();
    await expect(page.getByText("Pass rate")).toBeVisible();
  });

  test("switches to Scenarios tab", async ({ page }) => {
    await page.getByRole("button", { name: "Scenarios", exact: true }).click();
    await expect(page.getByRole("heading", { name: /scenarios/i })).toBeVisible();
  });

  test("switches back to Runs tab from Dashboard", async ({ page }) => {
    await page.getByRole("button", { name: "Dashboard", exact: true }).click();
    await page.getByRole("button", { name: "Runs", exact: true }).click();
    await expect(page.getByText("Eval Runs")).toBeVisible();
  });

  test("theme toggle switches to dark mode", async ({ page }) => {
    const root = page.locator(".ae-root");
    await expect(root).toHaveAttribute("data-theme", "light");
    await page.getByTestId("theme-toggle").click();
    await expect(root).toHaveAttribute("data-theme", "dark");
  });

  test("theme toggle cycles back to light", async ({ page }) => {
    const root = page.locator(".ae-root");
    await page.getByTestId("theme-toggle").click();
    await expect(root).toHaveAttribute("data-theme", "dark");
    await page.getByTestId("theme-toggle").click();
    await expect(root).toHaveAttribute("data-theme", "light");
  });
});
