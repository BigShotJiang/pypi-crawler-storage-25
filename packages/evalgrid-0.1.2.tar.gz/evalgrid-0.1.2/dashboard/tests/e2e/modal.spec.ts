import { test, expect } from "@playwright/test";
import { mockApi, goto, openModal } from "./helpers";

test.describe("Run New Eval Modal — Existing Scenarios", () => {
  test.beforeEach(async ({ page }) => {
    await mockApi(page);
    await goto(page);
    await openModal(page);
  });

  test("opens modal with correct title", async ({ page }) => {
    await expect(page.getByText("Run new eval")).toBeVisible();
    await expect(page.getByText("Pick a scenario to evaluate")).toBeVisible();
  });

  test("shows two tabs: Existing and New scenario", async ({ page }) => {
    await expect(page.getByRole("button", { name: "Existing scenarios" })).toBeVisible();
    await expect(page.getByRole("button", { name: "New scenario" })).toBeVisible();
  });

  test("lists available scenarios", async ({ page }) => {
    await expect(page.getByText("Fix Off-By-One Error")).toBeVisible();
    await expect(page.getByText("Hello World")).toBeVisible();
  });

  test("shows agent type and step count per scenario", async ({ page }) => {
    await expect(page.getByText(/coding.*4 steps/)).toBeVisible();
  });

  test("selecting a scenario highlights it", async ({ page }) => {
    await page.getByText("Fix Off-By-One Error").click();
    const selected = page.locator("button").filter({ hasText: "Fix Off-By-One Error" });
    await expect(selected).toHaveCSS("border-color", /rgb/);
  });

  test("Run eval button disabled until scenario selected", async ({ page }) => {
    const runBtn = page.getByRole("button", { name: /run eval/i });
    await expect(runBtn).toBeDisabled();
  });

  test("Run eval button enabled after selecting scenario", async ({ page }) => {
    await page.getByText("Fix Off-By-One Error").click();
    const runBtn = page.getByRole("button", { name: /run eval/i });
    await expect(runBtn).toBeEnabled();
  });

  test("deselects scenario on second click", async ({ page }) => {
    await page.getByText("Fix Off-By-One Error").click();
    await page.getByText("Fix Off-By-One Error").click();
    const runBtn = page.getByRole("button", { name: /run eval/i });
    await expect(runBtn).toBeDisabled();
  });

  test("closes modal with X button", async ({ page }) => {
    await page.getByRole("button", { name: "" }).filter({ hasText: "" }).last().click();
    // Find the X close button - it's a small circular button in the modal header
    const closeBtn = page.locator("button[style*='border-radius: \"50%\"']").or(
      page.locator("button").filter({ has: page.locator("svg") }).last()
    );
    // Use the simpler approach: click outside the modal
    await page.keyboard.press("Escape");
  });

  test("closes modal by clicking backdrop", async ({ page }) => {
    await page.mouse.click(50, 400);
    await expect(page.getByText("Pick a scenario to evaluate")).not.toBeVisible();
  });

  test("posts correct body when running eval", async ({ page }) => {
    const postRequest = page.waitForRequest((req) =>
      req.url().includes("/api/runs") && req.method() === "POST"
    );
    await page.getByText("Fix Off-By-One Error").click();
    await page.getByRole("button", { name: /run eval/i }).click();
    const req = await postRequest;
    const body = JSON.parse(req.postData() ?? "{}");
    expect(body.scenario_ids).toContain("fix-off-by-one");
    expect(body.mock).toBe(false);
  });

  test("shows toast after starting eval", async ({ page }) => {
    await page.getByText("Fix Off-By-One Error").click();
    await page.getByRole("button", { name: /run eval/i }).click();
    await expect(page.getByText("Eval started")).toBeVisible();
  });
});


test.describe("Run New Eval Modal — New Scenario Tab", () => {
  test.beforeEach(async ({ page }) => {
    await mockApi(page);
    await goto(page);
    await openModal(page);
    await page.getByRole("button", { name: "New scenario" }).click();
  });

  test("shows form with Name, Agent type, System prompt, Test input", async ({ page }) => {
    await expect(page.getByLabel("Name")).toBeVisible();
    await expect(page.getByLabel("Agent type")).toBeVisible();
    await expect(page.getByLabel("System prompt")).toBeVisible();
    await expect(page.getByLabel("Test input")).toBeVisible();
  });

  test("Create & run button disabled when fields empty", async ({ page }) => {
    await expect(page.getByRole("button", { name: /create.*run/i })).toBeDisabled();
  });

  test("Create & run button enabled when all required fields filled", async ({ page }) => {
    await page.getByLabel("Name").fill("My new scenario");
    await page.getByLabel("System prompt").fill("You are a helpful assistant.");
    await page.getByLabel("Test input").fill("What is 2+2?");
    await expect(page.getByRole("button", { name: /create.*run/i })).toBeEnabled();
  });

  test("agent type dropdown has expected options", async ({ page }) => {
    const select = page.getByLabel("Agent type");
    await expect(select.locator("option[value='generic']")).toHaveCount(1);
    await expect(select.locator("option[value='coding']")).toHaveCount(1);
    await expect(select.locator("option[value='sdr']")).toHaveCount(1);
    await expect(select.locator("option[value='support']")).toHaveCount(1);
  });

  test("posts to /api/scenarios then /api/runs on create", async ({ page }) => {
    const scenarioPost = page.waitForRequest((req) =>
      req.url().includes("/api/scenarios") && req.method() === "POST"
    );
    await page.getByLabel("Name").fill("Quick test");
    await page.getByLabel("System prompt").fill("Be helpful.");
    await page.getByLabel("Test input").fill("Hello!");
    await page.getByRole("button", { name: /create.*run/i }).click();
    const req = await scenarioPost;
    const body = JSON.parse(req.postData() ?? "{}");
    expect(body.name).toBe("Quick test");
  });

  test("includes judge_model and api_key in run POST", async ({ page }) => {
    const runPost = page.waitForRequest((req) =>
      req.url().includes("/api/runs") && req.method() === "POST"
    );
    await page.getByLabel("Name").fill("Quick test");
    await page.getByLabel("System prompt").fill("Be helpful.");
    await page.getByLabel("Test input").fill("Hello!");
    // Set a custom API key in judge settings
    await page.getByPlaceholder(/api key/i).fill("sk-test-key");
    await page.getByRole("button", { name: /create.*run/i }).click();
    const req = await runPost;
    const body = JSON.parse(req.postData() ?? "{}");
    expect(body.judge_model).toBeDefined();
    expect(body.api_key).toBe("sk-test-key");
  });
});
