import { Search, Sun, Moon } from "lucide-react";

const NAV_TABS = ["Dashboard", "Runs", "Scenarios"];

interface HeaderProps {
  theme: string;
  onToggleTheme: () => void;
  activeNav: string;
  onNavChange: (tab: string) => void;
  search: string;
  onSearchChange: (value: string) => void;
  isMobile: boolean;
  isTablet: boolean;
  isDesktop: boolean;
}

export function Header({
  theme,
  onToggleTheme,
  activeNav,
  onNavChange,
  search,
  onSearchChange,
  isMobile,
  isTablet,
  isDesktop,
}: HeaderProps) {
  return (
    <>
      <div
        className="flex items-center"
        style={{
          gap: isMobile ? 10 : isTablet ? 12 : 16,
          flexWrap: isTablet ? "wrap" : "nowrap",
        }}
      >
        {/* Logo */}
        <div className="flex items-center" style={{ gap: 9, flexShrink: 0 }}>
          <svg
            width={isMobile ? 28 : 32}
            height={isMobile ? 28 : 32}
            viewBox="0 0 36 36"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <rect x="2" y="2" width="14" height="14" rx="3" fill="#5b5ef4" />
            <rect x="20" y="2" width="14" height="14" rx="3" fill="#5b5ef4" fillOpacity="0.4" />
            <rect x="2" y="20" width="14" height="14" rx="3" fill="#5b5ef4" fillOpacity="0.4" />
            <rect
              x="20"
              y="20"
              width="14"
              height="14"
              rx="3"
              fill="#5b5ef4"
              fillOpacity="0.15"
            />
            <path
              d="M8 9 L11 12 L16 6"
              stroke="white"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
              fill="none"
            />
          </svg>
          {!isMobile && (
            <div className="flex flex-col" style={{ gap: 0 }}>
              <span
                style={{
                  fontSize: 15,
                  fontWeight: 600,
                  letterSpacing: "-0.03em",
                  color: "var(--ink-1)",
                  lineHeight: 1.1,
                }}
              >
                eval<span style={{ color: "#5b5ef4" }}>grid</span>
              </span>
              <span
                style={{
                  fontSize: 10.5,
                  color: "var(--ink-3)",
                  letterSpacing: "-0.005em",
                  lineHeight: 1.2,
                }}
              >
                agent evaluation
              </span>
            </div>
          )}
        </div>

        <div style={{ flex: 1 }} />

        {/* Desktop nav pills */}
        {isDesktop && (
          <nav className="flex items-center" style={{ gap: 4 }}>
            {NAV_TABS.map((tab) => {
              const active = activeNav === tab;
              return (
                <button
                  key={tab}
                  onClick={() => onNavChange(tab)}
                  style={{
                    height: 38,
                    padding: "0 16px",
                    borderRadius: 99,
                    background: active ? "var(--brand)" : "transparent",
                    color: active ? "var(--brand-text)" : "var(--ink-2)",
                    border: 0,
                    cursor: "pointer",
                    fontSize: 13,
                    fontWeight: active ? 590 : 510,
                    letterSpacing: "-0.008em",
                    transition: "all 150ms ease",
                  }}
                >
                  {tab}
                </button>
              );
            })}
          </nav>
        )}

        {/* Search */}
        <div
          className="relative flex items-center"
          style={{
            width: isMobile ? "100%" : isTablet ? 220 : 220,
            height: 40,
            borderRadius: 99,
            background: "var(--paper)",
            boxShadow: "var(--shadow-card)",
            paddingLeft: 14,
            paddingRight: 6,
            gap: 8,
            flex: isMobile ? 1 : "0 0 auto",
            minWidth: 0,
          }}
        >
          <Search size={14} strokeWidth={2} style={{ color: "var(--ink-3)", flexShrink: 0 }} />
          <input
            value={search}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder={isMobile ? "Search…" : "Start searching…"}
            style={{
              flex: 1,
              minWidth: 0,
              height: "100%",
              border: 0,
              background: "transparent",
              fontSize: 13,
              color: "var(--ink-1)",
              fontFamily: "var(--font-sans)",
              letterSpacing: "-0.005em",
            }}
          />
        </div>

        {/* Theme toggle */}
        <button
          data-testid="theme-toggle"
          onClick={onToggleTheme}
          style={{
            width: 40,
            height: 40,
            borderRadius: "50%",
            background: "var(--brand)",
            color: "var(--brand-text)",
            border: 0,
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            boxShadow: "var(--shadow-card)",
            flexShrink: 0,
          }}
        >
          {theme === "light" ? (
            <Moon size={14} strokeWidth={2} />
          ) : (
            <Sun size={14} strokeWidth={2} />
          )}
        </button>
      </div>

      {/* Tablet: nav pills on second row */}
      {isTablet && (
        <div
          className="flex items-center"
          style={{ gap: 4, overflowX: "auto", paddingBottom: 4, marginRight: -14 }}
        >
          {NAV_TABS.map((tab) => {
            const active = activeNav === tab;
            return (
              <button
                key={tab}
                onClick={() => onNavChange(tab)}
                style={{
                  height: 36,
                  padding: "0 14px",
                  borderRadius: 99,
                  background: active ? "var(--brand)" : "var(--paper)",
                  color: active ? "var(--paper)" : "var(--ink-2)",
                  border: 0,
                  cursor: "pointer",
                  fontSize: 12.5,
                  fontWeight: active ? 590 : 510,
                  letterSpacing: "-0.005em",
                  boxShadow: active ? "none" : "var(--shadow-card)",
                  flexShrink: 0,
                }}
              >
                {tab}
              </button>
            );
          })}
        </div>
      )}
    </>
  );
}

export { NAV_TABS };
