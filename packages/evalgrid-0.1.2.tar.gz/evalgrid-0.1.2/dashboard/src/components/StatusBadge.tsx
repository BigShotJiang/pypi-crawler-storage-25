import { CheckCheck, CircleX, Loader2 } from "lucide-react";

interface StatusBadgeProps {
  status: string;
  compact?: boolean;
}

export function StatusBadge({ status, compact = false }: StatusBadgeProps) {
  const config =
    status === "pass"
      ? { bg: "var(--ok-soft)", color: "var(--ok-ink)", icon: CheckCheck, label: "Passed" }
      : status === "fail"
      ? { bg: "var(--bad-soft)", color: "var(--bad-ink)", icon: CircleX, label: "Failed" }
      : {
          bg: "var(--brand-soft)",
          color: "var(--brand-ink)",
          icon: Loader2,
          label: "Running",
          spin: true,
        };
  const Icon = config.icon;
  return (
    <span
      className="inline-flex items-center"
      style={{
        gap: 4,
        height: compact ? 20 : 24,
        padding: compact ? "0 7px" : "0 10px",
        borderRadius: 99,
        background: config.bg,
        color: config.color,
        fontSize: compact ? 10.5 : 11.5,
        fontWeight: 510,
        letterSpacing: "-0.005em",
        flexShrink: 0,
      }}
    >
      <Icon
        size={compact ? 9 : 11}
        strokeWidth={2.5}
        className={"spin" in config && config.spin ? "ae-spin" : ""}
      />
      {config.label}
    </span>
  );
}
