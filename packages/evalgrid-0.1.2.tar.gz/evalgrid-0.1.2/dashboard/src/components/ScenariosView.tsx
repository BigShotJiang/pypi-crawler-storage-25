import { useState, useMemo } from "react";
import { ChevronRight, Loader2 } from "lucide-react";
import type { Scenario, Run } from "../types";

interface ScenariosViewProps {
  scenarios: Scenario[];
  scenariosLoading: boolean;
  runs: Run[];
  isMobile: boolean;
  setActiveNav: (nav: string) => void;
}

export function ScenariosView({
  scenarios,
  scenariosLoading,
  runs,
  isMobile,
  setActiveNav,
}: ScenariosViewProps) {
  const [openSuites, setOpenSuites] = useState<Set<string>>(() => new Set());

  const suiteGroups = useMemo(() => {
    const map = new Map<string, Scenario[]>();
    for (const s of scenarios) {
      const suite = s.suite ?? "default";
      if (!map.has(suite)) map.set(suite, []);
      map.get(suite)!.push(s);
    }
    return Array.from(map.entries()).sort(([a], [b]) => a.localeCompare(b));
  }, [scenarios]);

  function toggleSuite(suite: string) {
    setOpenSuites((prev) => {
      const next = new Set(prev);
      if (next.has(suite)) next.delete(suite);
      else next.add(suite);
      return next;
    });
  }

  return (
    <div className="flex flex-col" style={{ gap: isMobile ? 8 : 10 }}>
      <div className="flex items-center" style={{ gap: 12, paddingTop: 4 }}>
        <h2
          style={{
            fontSize: isMobile ? 18 : 20,
            fontWeight: 590,
            letterSpacing: "-0.022em",
            color: "var(--ink-1)",
          }}
        >
          Scenarios
        </h2>
        {!scenariosLoading && (
          <span
            style={{
              fontSize: 12,
              color: "var(--ink-3)",
              fontFamily: "var(--font-mono)",
              fontVariantNumeric: "tabular-nums",
            }}
          >
            {scenarios.length}
          </span>
        )}
      </div>
      {scenariosLoading ? (
        <div
          style={{
            padding: "60px 0",
            textAlign: "center",
            background: "var(--paper)",
            borderRadius: 22,
            boxShadow: "var(--shadow-card)",
          }}
        >
          <Loader2
            size={20}
            strokeWidth={2}
            className="ae-spin"
            style={{ color: "var(--ink-3)", margin: "0 auto", display: "block" }}
          />
        </div>
      ) : scenarios.length === 0 ? (
        <div
          style={{
            padding: "60px 0",
            textAlign: "center",
            color: "var(--ink-3)",
            fontSize: 13.5,
            background: "var(--paper)",
            borderRadius: 22,
            boxShadow: "var(--shadow-card)",
          }}
        >
          No scenarios found. Create one to get started.
        </div>
      ) : (
        suiteGroups.map(([suite, items]) => {
          const isOpen = openSuites.has(suite);
          const usedInRuns = runs.filter((r) =>
            r.scenario_names?.some((n) => items.some((s) => s.name === n))
          ).length;
          return (
            <div
              key={suite}
              style={{
                background: "var(--paper)",
                borderRadius: isMobile ? 18 : 22,
                boxShadow: "var(--shadow-card)",
                overflow: "hidden",
              }}
            >
              <button
                onClick={() => toggleSuite(suite)}
                className="flex items-center w-full text-left"
                style={{
                  padding: isMobile ? "14px 16px" : "16px 22px",
                  gap: 12,
                  background: "transparent",
                  border: 0,
                  cursor: "pointer",
                }}
              >
                <div
                  style={{
                    width: 22,
                    height: 22,
                    borderRadius: 6,
                    background: "var(--surface-2)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    color: "var(--ink-3)",
                    flexShrink: 0,
                    transform: isOpen ? "rotate(90deg)" : "rotate(0)",
                    transition: "transform 200ms ease",
                  }}
                >
                  <ChevronRight size={12} strokeWidth={2.5} />
                </div>
                <span
                  style={{
                    fontSize: isMobile ? 13.5 : 14.5,
                    fontWeight: 590,
                    color: "var(--ink-1)",
                    letterSpacing: "-0.012em",
                    flex: 1,
                    textAlign: "left",
                  }}
                >
                  {suite}
                </span>
                <div className="flex items-center" style={{ gap: 8 }}>
                  <span
                    style={{
                      fontSize: 11.5,
                      color: "var(--ink-3)",
                      fontFamily: "var(--font-mono)",
                      fontVariantNumeric: "tabular-nums",
                    }}
                  >
                    {items.length} scenario{items.length !== 1 ? "s" : ""}
                  </span>
                  {usedInRuns > 0 && (
                    <span
                      style={{
                        height: 20,
                        padding: "0 8px",
                        borderRadius: 99,
                        background: "var(--brand-soft)",
                        color: "var(--brand-ink)",
                        fontSize: 10.5,
                        fontWeight: 590,
                        display: "flex",
                        alignItems: "center",
                      }}
                    >
                      {usedInRuns} run{usedInRuns !== 1 ? "s" : ""}
                    </span>
                  )}
                </div>
              </button>
              <div
                style={{
                  maxHeight: isOpen ? items.length * 200 : 0,
                  opacity: isOpen ? 1 : 0,
                  overflow: "hidden",
                  transition:
                    "max-height 280ms cubic-bezier(0.2,0.8,0.2,1), opacity 200ms ease",
                }}
              >
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    gap: 1,
                    padding: isMobile ? "0 8px 10px 8px" : "0 12px 12px 12px",
                  }}
                >
                  {items.map((s) => {
                    const runCount = runs.filter((r) =>
                      r.scenario_names?.includes(s.name)
                    ).length;
                    return (
                      <div
                        key={s.id}
                        style={{
                          borderRadius: isMobile ? 14 : 16,
                          padding: isMobile ? "12px 14px" : "14px 16px",
                          background: "var(--surface-2)",
                        }}
                      >
                        <div
                          className="flex items-start justify-between"
                          style={{ gap: 10 }}
                        >
                          <div style={{ flex: 1, minWidth: 0 }}>
                            <span
                              style={{
                                fontSize: isMobile ? 13 : 14,
                                fontWeight: 590,
                                color: "var(--ink-1)",
                                letterSpacing: "-0.01em",
                                display: "block",
                                wordBreak: "break-word",
                              }}
                            >
                              {s.name}
                            </span>
                            {s.description && (
                              <span
                                style={{
                                  fontSize: 12,
                                  color: "var(--ink-3)",
                                  display: "block",
                                  marginTop: 2,
                                  lineHeight: 1.45,
                                }}
                              >
                                {s.description}
                              </span>
                            )}
                          </div>
                          <div
                            className="flex flex-col items-end"
                            style={{ gap: 4, flexShrink: 0 }}
                          >
                            <span
                              style={{
                                height: 20,
                                padding: "0 8px",
                                borderRadius: 99,
                                background: "var(--surface-3)",
                                color: "var(--ink-2)",
                                fontSize: 11,
                                fontWeight: 590,
                                display: "flex",
                                alignItems: "center",
                              }}
                            >
                              {s.agent_type}
                            </span>
                            <span
                              style={{
                                fontSize: 11,
                                color: "var(--ink-3)",
                                fontFamily: "var(--font-mono)",
                                fontVariantNumeric: "tabular-nums",
                              }}
                            >
                              {s.step_count} steps
                            </span>
                          </div>
                        </div>
                        <div
                          className="flex items-center justify-between"
                          style={{ marginTop: 8, gap: 8, flexWrap: "wrap" }}
                        >
                          {s.tags?.length > 0 && (
                            <div
                              className="flex items-center"
                              style={{ gap: 5, flexWrap: "wrap" }}
                            >
                              {s.tags.map((tag) => (
                                <span
                                  key={tag}
                                  style={{
                                    height: 18,
                                    padding: "0 7px",
                                    borderRadius: 99,
                                    background: "var(--surface-3)",
                                    color: "var(--ink-3)",
                                    fontSize: 10,
                                    fontWeight: 510,
                                    display: "inline-flex",
                                    alignItems: "center",
                                  }}
                                >
                                  {tag}
                                </span>
                              ))}
                            </div>
                          )}
                          {runCount > 0 && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setActiveNav("Runs");
                              }}
                              style={{
                                fontSize: 11,
                                color: "var(--brand)",
                                background: "transparent",
                                border: 0,
                                cursor: "pointer",
                                padding: 0,
                                fontWeight: 590,
                                flexShrink: 0,
                              }}
                            >
                              Used in {runCount} run{runCount !== 1 ? "s" : ""}
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          );
        })
      )}
    </div>
  );
}
