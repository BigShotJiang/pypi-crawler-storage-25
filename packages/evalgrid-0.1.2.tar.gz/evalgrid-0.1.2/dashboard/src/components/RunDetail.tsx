import { Loader2 } from "lucide-react";
import type { Run, RunDetail as RunDetailType, ScenarioResult } from "../types";

function scoreColor(score: number | null, status?: string): string {
  if (status === "running") return "var(--ink-3)";
  if (score === null) return "var(--ink-3)";
  if (score >= 0.85) return "var(--ok)";
  if (score >= 0.6) return "var(--warn)";
  return "var(--bad)";
}

interface RunDetailProps {
  run: Run;
  detail: RunDetailType | undefined;
  detailLoading: boolean;
  isMobile: boolean;
}

export function RunDetailPanel({ run, detail, detailLoading, isMobile }: RunDetailProps) {
  const steps = detail?.scenario_results
    ? detail.scenario_results.flatMap((sr: ScenarioResult) =>
        (sr.steps || []).map((s) => ({
          idx: String((s.step_index ?? 0) + 1).padStart(2, "0"),
          name: s.action || `step_${s.step_index}`,
          score: typeof s.score === "number" ? s.score : s.status === "pass" ? 1.0 : 0.0,
          verdict: s.reasoning || s.actual_output || "",
        }))
      )
    : run.steps;

  const failureDetails: ScenarioResult[] = (detail?.scenario_results ?? []).filter(
    (sr: ScenarioResult) => sr.error || sr.reasoning
  );

  if (detailLoading) {
    return (
      <div
        className="flex items-center justify-center"
        style={{
          gap: 10,
          padding: isMobile ? "20px 14px" : "24px 18px",
          borderRadius: 16,
          background: "var(--surface-2)",
        }}
      >
        <Loader2
          size={14}
          strokeWidth={2.25}
          className="ae-spin"
          style={{ color: "var(--ink-3)" }}
        />
        <span style={{ fontSize: 13, color: "var(--ink-3)", letterSpacing: "-0.005em" }}>
          Loading step details…
        </span>
      </div>
    );
  }

  if (run.status === "running") {
    return (
      <div
        className="flex items-center"
        style={{
          gap: 10,
          padding: isMobile ? "12px 14px" : "16px 18px",
          borderRadius: 16,
          background: "var(--surface-2)",
          flexWrap: "wrap",
        }}
      >
        <Loader2
          size={14}
          strokeWidth={2.25}
          className="ae-spin"
          style={{ color: "var(--brand)" }}
        />
        <span
          style={{
            fontSize: isMobile ? 12 : 13,
            color: "var(--brand)",
            fontWeight: 510,
            letterSpacing: "-0.005em",
          }}
        >
          Eval in progress · {run.stepsDone} / {run.stepsTotal} steps
        </span>
        {!isMobile && (
          <span style={{ flex: 1, height: 1, background: "var(--ink-4)", opacity: 0.4 }} />
        )}
        <span
          style={{
            fontSize: 11,
            color: "var(--ink-3)",
            fontFamily: "var(--font-mono)",
          }}
        >
          {run.tokens} tokens
        </span>
      </div>
    );
  }

  if (steps.length === 0 && failureDetails.length === 0) {
    return (
      <div
        style={{
          padding: isMobile ? "12px 14px" : "16px 18px",
          borderRadius: 16,
          background: "var(--surface-2)",
          fontSize: 12.5,
          color: "var(--ink-3)",
        }}
      >
        No step details available · {run.stepsDone}/{run.stepsTotal} scenarios passed · score{" "}
        {Math.round((run.score ?? 0) * 100)}%
      </div>
    );
  }

  if (steps.length === 0) {
    return (
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {failureDetails.map((sr: ScenarioResult, i: number) => (
          <div
            key={i}
            style={{
              borderRadius: 16,
              background: "var(--surface-2)",
              padding: isMobile ? "12px 14px" : "16px 18px",
            }}
          >
            <div style={{ marginBottom: sr.error || sr.reasoning ? 8 : 0 }}>
              <span
                style={{
                  fontSize: 13,
                  fontWeight: 590,
                  color: sr.status === "pass" ? "var(--ok)" : "var(--bad)",
                  letterSpacing: "-0.01em",
                }}
              >
                {sr.scenario_name}
              </span>
              <span
                style={{
                  marginLeft: 8,
                  fontSize: 11,
                  color: "var(--ink-4)",
                  fontFamily: "var(--font-mono)",
                  letterSpacing: "0.04em",
                  textTransform: "uppercase" as const,
                }}
              >
                {sr.status}
              </span>
            </div>
            {sr.error && (
              <div
                style={{
                  borderRadius: 10,
                  background: "rgba(226,75,74,0.08)",
                  border: "1px solid rgba(226,75,74,0.25)",
                  padding: "10px 12px",
                  marginBottom: sr.reasoning ? 8 : 0,
                }}
              >
                <div
                  style={{
                    fontSize: 11,
                    fontWeight: 590,
                    color: "var(--bad)",
                    letterSpacing: "0.04em",
                    textTransform: "uppercase" as const,
                    marginBottom: 4,
                  }}
                >
                  Error
                </div>
                <div
                  style={{
                    fontSize: 12.5,
                    color: "var(--bad)",
                    fontFamily: "var(--font-mono)",
                    wordBreak: "break-word",
                    lineHeight: 1.5,
                  }}
                >
                  {sr.error}
                </div>
              </div>
            )}
            {sr.reasoning && (
              <div
                style={{
                  fontSize: 12.5,
                  color: "var(--ink-2)",
                  lineHeight: 1.5,
                  letterSpacing: "-0.003em",
                  fontStyle: "italic",
                }}
              >
                {sr.reasoning}
              </div>
            )}
          </div>
        ))}
      </div>
    );
  }

  return (
    <div
      style={{
        background: "var(--surface-2)",
        borderRadius: 18,
        padding: isMobile ? "12px 14px" : "16px 18px",
      }}
    >
      <div
        className="flex items-center justify-between"
        style={{ marginBottom: 12, gap: 8, flexWrap: "wrap" }}
      >
        <span
          style={{
            fontSize: 11,
            color: "var(--ink-3)",
            fontWeight: 590,
            letterSpacing: "0.04em",
            textTransform: "uppercase",
          }}
        >
          Step breakdown · {steps.length}
        </span>
        <span style={{ fontSize: 11, color: "var(--ink-3)", fontFamily: "var(--font-mono)" }}>
          {run.duration} · {run.tokens}
        </span>
      </div>
      <div className="flex flex-col" style={{ gap: 0 }}>
        {steps.map((s, i) => {
          const c = scoreColor(s.score);
          return (
            <div
              key={s.idx + i}
              className="flex items-start"
              style={{
                gap: isMobile ? 10 : 14,
                padding: "12px 0",
                borderTop: i === 0 ? "none" : "1px solid var(--surface-3)",
              }}
            >
              <span
                style={{
                  width: 8,
                  height: 8,
                  borderRadius: "50%",
                  background: c,
                  flexShrink: 0,
                  marginTop: 6,
                }}
              />
              {!isMobile && (
                <span
                  style={{
                    fontFamily: "var(--font-mono)",
                    fontSize: 11,
                    color: "var(--ink-3)",
                    width: 22,
                    flexShrink: 0,
                    paddingTop: 3,
                  }}
                >
                  {s.idx}
                </span>
              )}
              <div className="flex-1 min-w-0 flex flex-col" style={{ gap: 3 }}>
                <div className="flex items-center justify-between" style={{ gap: 8 }}>
                  <span
                    style={{
                      fontSize: isMobile ? 12 : 13,
                      fontFamily: "var(--font-mono)",
                      color: "var(--ink-1)",
                      fontWeight: 510,
                      wordBreak: "break-word",
                    }}
                  >
                    {s.name}
                  </span>
                  {isMobile && (
                    <span
                      style={{
                        fontSize: 12,
                        color: c,
                        fontFamily: "var(--font-mono)",
                        fontWeight: 590,
                        fontVariantNumeric: "tabular-nums",
                        flexShrink: 0,
                      }}
                    >
                      {Math.round(s.score * 100)}%
                    </span>
                  )}
                </div>
                <div
                  style={{
                    fontSize: isMobile ? 12 : 12.5,
                    color: "var(--ink-2)",
                    lineHeight: 1.5,
                    letterSpacing: "-0.003em",
                  }}
                >
                  {s.verdict}
                </div>
              </div>
              {!isMobile && (
                <div
                  className="flex flex-col items-end"
                  style={{ gap: 4, minWidth: 80, paddingTop: 2 }}
                >
                  <span
                    style={{
                      fontSize: 13,
                      color: c,
                      fontFamily: "var(--font-mono)",
                      fontVariantNumeric: "tabular-nums",
                      fontWeight: 590,
                    }}
                  >
                    {Math.round(s.score * 100)}%
                  </span>
                  <div
                    style={{
                      width: 64,
                      height: 3,
                      borderRadius: 99,
                      background: "var(--surface-3)",
                      overflow: "hidden",
                    }}
                  >
                    <div
                      style={{
                        width: `${s.score * 100}%`,
                        height: "100%",
                        background: c,
                        borderRadius: 99,
                      }}
                    />
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
