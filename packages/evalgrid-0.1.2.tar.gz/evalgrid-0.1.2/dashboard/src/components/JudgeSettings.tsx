const MODEL_PRESETS = [
  {
    label: "claude-sonnet-4-6 · Anthropic (default)",
    value: "claude-sonnet-4-6",
    keyHint: "ANTHROPIC_API_KEY",
    needsKey: true,
  },
  {
    label: "claude-opus-4-7 · Anthropic",
    value: "claude-opus-4-7",
    keyHint: "ANTHROPIC_API_KEY",
    needsKey: true,
  },
  {
    label: "gpt-4o · OpenAI",
    value: "gpt-4o",
    keyHint: "OPENAI_API_KEY",
    needsKey: true,
  },
  {
    label: "gpt-4o-mini · OpenAI",
    value: "gpt-4o-mini",
    keyHint: "OPENAI_API_KEY",
    needsKey: true,
  },
  {
    label: "gemini/gemini-2.0-flash · Google",
    value: "gemini/gemini-2.0-flash",
    keyHint: "GEMINI_API_KEY",
    needsKey: true,
  },
  {
    label: "ollama/llama3.1:70b · Local (no key)",
    value: "ollama/llama3.1:70b",
    keyHint: "",
    needsKey: false,
  },
];

interface JudgeSettingsProps {
  model: string;
  onModelChange: (model: string) => void;
}

export function JudgeSettings({ model, onModelChange }: JudgeSettingsProps) {
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        gap: 8,
        padding: "12px 14px",
        borderRadius: 12,
        background: "var(--surface-2)",
        border: "1px solid var(--surface-3)",
      }}
    >
      <label
        htmlFor="judge-model-select"
        style={{
          fontSize: 10.5,
          fontWeight: 590,
          color: "var(--ink-3)",
          letterSpacing: "0.05em",
          textTransform: "uppercase" as const,
        }}
      >
        Judge model
      </label>

      <div style={{ position: "relative" }}>
        <select
          id="judge-model-select"
          aria-label="Judge model"
          value={model}
          onChange={(e) => onModelChange(e.target.value)}
          style={{
            width: "100%",
            height: 34,
            borderRadius: 8,
            border: "1px solid var(--ink-4)",
            background: "var(--paper)",
            color: "var(--ink-1)",
            padding: "0 10px",
            fontSize: 12.5,
            fontFamily: "var(--font-sans)",
            cursor: "pointer",
          }}
        >
          {MODEL_PRESETS.map((p) => (
            <option key={p.value} value={p.value}>
              {p.label}
            </option>
          ))}
        </select>
      </div>

      <span style={{ fontSize: 11.5, color: "var(--ink-3)", letterSpacing: "-0.003em" }}>
        API keys are read from server environment variables (e.g.{" "}
        <code>ANTHROPIC_API_KEY</code>)
      </span>
    </div>
  );
}
