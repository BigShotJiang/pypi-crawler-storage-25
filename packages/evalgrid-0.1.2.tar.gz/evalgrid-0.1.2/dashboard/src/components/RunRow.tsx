import { useState } from "react";
import { ChevronRight } from "lucide-react";
import { StatusBadge } from "./StatusBadge";
import { RunDetailPanel } from "./RunDetail";
import type { Run, RunDetail } from "../types";

function scoreColor(score: number | null, status?: string): string {
  if (status === "running") return "var(--ink-3)";
  if (score === null) return "var(--ink-3)";
  if (score >= 0.85) return "var(--ok)";
  if (score >= 0.6) return "var(--warn)";
  return "var(--bad)";
}

interface RunRowProps {
  run: Run;
  isOpen: boolean;
  onToggle: () => void;
  isMobile: boolean;
  detail: RunDetail | undefined;
  detailLoading: boolean;
}

export function RunRow({ run, isOpen, onToggle, isMobile, detail, detailLoading }: RunRowProps) {
  const [showSkippedDetails, setShowSkippedDetails] = useState(false);
  const pct = run.score !== null ? Math.round(run.score * 100) : null;
  const sColor = scoreColor(run.score, run.status);
  const dotColor =
    run.status === "pass"
      ? "var(--ok)"
      : run.status === "fail"
      ? "var(--bad)"
      : "var(--brand)";

  const scenarioNames: string[] =
    detail?.scenario_results?.map((sr) => sr.scenario_name) ?? [];
  const displayName =
    scenarioNames.length > 0
      ? scenarioNames.length === 1
        ? scenarioNames[0]
        : scenarioNames.length <= 3
        ? scenarioNames.join(", ")
        : `${scenarioNames.length} scenarios: ${scenarioNames[0]} + ${
            scenarioNames.length - 1
          } more`
      : run.name;
  const scenarioLabel = run.scenario;

  return (
    <div
      style={{
        background: "var(--paper)",
        borderRadius: isMobile ? 18 : 22,
        boxShadow: isOpen ? "var(--shadow-card-strong)" : "var(--shadow-card)",
        overflow: "hidden",
        transition: "box-shadow 200ms ease",
      }}
    >
      <button
        onClick={onToggle}
        className="flex items-start w-full text-left"
        style={{
          padding: isMobile ? "14px 14px" : "16px 20px",
          gap: isMobile ? 12 : 16,
          background: "transparent",
          border: 0,
          cursor: "pointer",
          alignItems: isMobile ? "flex-start" : "center",
        }}
      >
        <div
          className="flex items-center justify-center"
          style={{
            width: isMobile ? 38 : 44,
            height: isMobile ? 38 : 44,
            borderRadius: "50%",
            background: "var(--surface-2)",
            color: "var(--ink-1)",
            fontSize: isMobile ? 13 : 14,
            fontWeight: 600,
            fontFamily: "var(--font-mono)",
            flexShrink: 0,
            position: "relative",
            letterSpacing: "-0.02em",
          }}
        >
          {displayName.charAt(0).toUpperCase()}
          <span
            style={{
              position: "absolute",
              top: -1,
              right: -1,
              width: 11,
              height: 11,
              borderRadius: "50%",
              background: dotColor,
              border: "2.5px solid var(--paper)",
              animation:
                run.status === "running"
                  ? "ae-pulse-soft 1.6s ease-in-out infinite"
                  : "none",
            }}
          />
        </div>

        <div className="flex-1 min-w-0 flex flex-col" style={{ gap: 4 }}>
          <div className="flex items-center" style={{ gap: 8, flexWrap: "wrap" }}>
            <span
              style={{
                fontSize: isMobile ? 13.5 : 14.5,
                fontWeight: 590,
                color: "var(--ink-1)",
                letterSpacing: "-0.012em",
                whiteSpace: isMobile ? "normal" : "nowrap",
                overflow: isMobile ? "visible" : "hidden",
                textOverflow: "ellipsis",
                lineHeight: 1.3,
                wordBreak: "break-word",
              }}
            >
              {displayName}
            </span>
            <StatusBadge status={run.status} compact={isMobile} />
          </div>
          <div
            className="flex items-center"
            style={{
              gap: isMobile ? 6 : 10,
              fontSize: isMobile ? 11 : 12,
              color: "var(--ink-3)",
              flexWrap: "wrap",
            }}
          >
            <span
              style={{
                fontFamily: "var(--font-mono)",
                fontVariantNumeric: "tabular-nums",
              }}
            >
              {run.id}
            </span>
            <span
              style={{
                width: 3,
                height: 3,
                borderRadius: "50%",
                background: "var(--ink-4)",
              }}
            />
            <span style={{ letterSpacing: "-0.005em" }}>{scenarioLabel}</span>
            {!isMobile && (
              <>
                <span
                  style={{
                    width: 3,
                    height: 3,
                    borderRadius: "50%",
                    background: "var(--ink-4)",
                  }}
                />
                <span style={{ letterSpacing: "-0.005em" }}>{run.ts}</span>
              </>
            )}
          </div>
          {isMobile && (
            <div
              className="flex items-center justify-between"
              style={{ marginTop: 8, gap: 12 }}
            >
              {run.status === "running" ? (
                <span style={{ fontSize: 11, color: "var(--ink-2)", fontWeight: 510 }}>
                  In progress · {run.stepsDone}/{run.stepsTotal}
                </span>
              ) : (
                <div className="flex items-center" style={{ gap: 10 }}>
                  <span
                    style={{
                      fontSize: 22,
                      lineHeight: 1,
                      fontWeight: 510,
                      color: sColor,
                      fontVariantNumeric: "tabular-nums",
                      letterSpacing: "-0.022em",
                    }}
                  >
                    {pct}
                    <span
                      style={{ fontSize: 12, color: "var(--ink-3)", fontWeight: 400 }}
                    >
                      %
                    </span>
                  </span>
                  <div
                    style={{
                      width: 60,
                      height: 3,
                      borderRadius: 99,
                      background: "var(--surface-2)",
                    }}
                  >
                    <div
                      style={{
                        width: `${pct}%`,
                        height: "100%",
                        background: sColor,
                        borderRadius: 99,
                      }}
                    />
                  </div>
                  <span
                    style={{
                      fontFamily: "var(--font-mono)",
                      fontSize: 10.5,
                      color: "var(--ink-3)",
                    }}
                  >
                    {run.stepsDone}/{run.stepsTotal}
                  </span>
                </div>
              )}
              <span style={{ fontSize: 11, color: "var(--ink-3)" }}>{run.ts}</span>
            </div>
          )}
        </div>

        {!isMobile && (
          <>
            {run.status === "running" ? (
              <div className="flex flex-col items-end" style={{ gap: 4, minWidth: 110 }}>
                <span style={{ fontSize: 12, color: "var(--ink-2)", fontWeight: 510 }}>
                  In progress
                </span>
                <span
                  style={{
                    fontFamily: "var(--font-mono)",
                    fontSize: 11.5,
                    color: "var(--ink-3)",
                  }}
                >
                  {run.stepsDone} / {run.stepsTotal} steps
                </span>
              </div>
            ) : (
              <div className="flex items-center" style={{ gap: 18 }}>
                <div className="flex flex-col items-end" style={{ gap: 6 }}>
                  <span
                    style={{
                      fontSize: 32,
                      lineHeight: 0.95,
                      letterSpacing: "-0.025em",
                      fontWeight: 510,
                      color: sColor,
                      fontVariantNumeric: "tabular-nums",
                    }}
                  >
                    {pct}
                    <span
                      style={{
                        fontSize: 16,
                        color: "var(--ink-3)",
                        fontWeight: 400,
                        marginLeft: 1,
                      }}
                    >
                      %
                    </span>
                  </span>
                  <div
                    style={{
                      width: 84,
                      height: 4,
                      borderRadius: 99,
                      background: "var(--surface-2)",
                      overflow: "hidden",
                    }}
                  >
                    <div
                      style={{
                        width: `${pct}%`,
                        height: "100%",
                        background: sColor,
                        borderRadius: 99,
                      }}
                    />
                  </div>
                </div>
                <div
                  className="flex flex-col items-end"
                  style={{ gap: 3, minWidth: 56 }}
                >
                  <span
                    style={{
                      fontFamily: "var(--font-mono)",
                      fontSize: 12,
                      color: "var(--ink-2)",
                      fontVariantNumeric: "tabular-nums",
                    }}
                  >
                    {run.stepsDone}/{run.stepsTotal}
                  </span>
                  <span
                    style={{
                      fontFamily: "var(--font-mono)",
                      fontSize: 11,
                      color: "var(--ink-3)",
                    }}
                  >
                    {run.duration}
                  </span>
                </div>
              </div>
            )}

            <div className="flex items-center" style={{ gap: 8 }}>
              <div
                className="flex items-center justify-center"
                style={{
                  width: 36,
                  height: 36,
                  borderRadius: "50%",
                  background: "var(--surface-2)",
                  color: "var(--ink-2)",
                  transform: isOpen ? "rotate(90deg)" : "rotate(0)",
                  transition: "transform 220ms cubic-bezier(0.2, 0.8, 0.2, 1)",
                }}
              >
                <ChevronRight size={14} strokeWidth={2} />
              </div>
            </div>
          </>
        )}

        {isMobile && (
          <div
            className="flex items-center justify-center"
            style={{
              width: 28,
              height: 28,
              borderRadius: "50%",
              background: "var(--surface-2)",
              color: "var(--ink-2)",
              transform: isOpen ? "rotate(90deg)" : "rotate(0)",
              transition: "transform 220ms cubic-bezier(0.2, 0.8, 0.2, 1)",
              flexShrink: 0,
              marginTop: 4,
            }}
          >
            <ChevronRight size={13} strokeWidth={2} />
          </div>
        )}
      </button>

      <div
        style={{
          maxHeight: isOpen ? 1500 : 0,
          opacity: isOpen ? 1 : 0,
          transition:
            "max-height 280ms cubic-bezier(0.2, 0.8, 0.2, 1), opacity 220ms ease",
          overflow: "hidden",
        }}
      >
        <div
          style={{ padding: isMobile ? "0 12px 14px 12px" : "4px 20px 20px 20px" }}
        >
          {(run.skippedCount ?? 0) > 0 && (
            <div style={{ marginBottom: 12, padding: "10px 14px", borderRadius: 10, background: "rgba(240,160,58,0.12)", border: "1px solid rgba(240,160,58,0.3)" }}>
              <div className="flex items-center justify-between">
                <span style={{ fontSize: 12.5, color: "var(--warn)", fontWeight: 590 }}>
                  ⚠ {run.skippedCount} scenario(s) skipped due to validation errors
                </span>
                <button
                  onClick={(e) => { e.stopPropagation(); setShowSkippedDetails((p) => !p); }}
                  style={{ fontSize: 11.5, color: "var(--warn)", background: "none", border: "none", cursor: "pointer", fontWeight: 510, textDecoration: "underline" }}
                >
                  {showSkippedDetails ? "Hide" : "Show details"}
                </button>
              </div>
              {showSkippedDetails && (
                <div style={{ marginTop: 8, display: "flex", flexDirection: "column", gap: 4 }}>
                  {(run.skippedScenarios ?? []).map((s, i) => (
                    <div key={i} style={{ fontSize: 11.5, color: "var(--ink-2)", fontFamily: "var(--font-mono)" }}>
                      <span style={{ color: "var(--warn)", fontWeight: 590 }}>{s.file}</span>: {s.reason}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
          <RunDetailPanel
            run={run}
            detail={detail}
            detailLoading={detailLoading}
            isMobile={isMobile}
          />
        </div>
      </div>
    </div>
  );
}
