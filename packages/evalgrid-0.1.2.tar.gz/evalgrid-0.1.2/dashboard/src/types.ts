// Shared TypeScript types for evalgrid dashboard

export interface StepResult {
  step_index: number;
  action: string;
  score: number;
  status: string;
  reasoning: string;
  actual_output: string;
}

export interface ScenarioResult {
  scenario_id: string;
  scenario_name: string;
  agent_type: string;
  status: string;
  overall_score: number;
  pass_rate: number;
  reasoning: string;
  error: string | null;
  steps: StepResult[];
}

export interface RunDetail {
  run_id: string;
  started_at: string;
  finished_at: string | null;
  pass_rate: number;
  passed: number;
  total: number;
  status: string;
  scenario_results: ScenarioResult[];
}

export interface Scenario {
  id: string;
  name: string;
  description: string;
  agent_type: string;
  tags: string[];
  step_count: number;
  suite: string;
}

export interface Run {
  id: string;
  fullRunId: string;
  status: "pass" | "fail" | "running";
  name: string;
  scenario: string;
  score: number;
  stepsDone: number;
  stepsTotal: number;
  ts: string;
  rawStartedAt: string;
  duration: string;
  latencyS: number | null;
  tokens: string;
  steps: MappedStep[];
  scenario_names?: string[];
  skippedCount?: number;
  skippedScenarios?: Array<{ file: string; reason: string }>;
}

export interface MappedStep {
  idx: string;
  name: string;
  score: number;
  verdict: string;
}

export interface RunCounts {
  all: number;
  pass: number;
  fail: number;
  running: number;
}
