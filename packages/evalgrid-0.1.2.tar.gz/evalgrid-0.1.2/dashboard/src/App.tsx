import { useState, useMemo, useEffect } from "react";
import {
  ArrowUpRight, Zap, CheckCheck, Loader2, X,
} from "lucide-react";
import { LineChart, Line, ResponsiveContainer, Tooltip } from "recharts";

import { useRuns } from "./hooks/useRuns";
import { useScenarios } from "./hooks/useScenarios";
import { useConfigStatus } from "./hooks/useConfigStatus";
import { Header, NAV_TABS } from "./components/Header";
import { RunRow } from "./components/RunRow";
import { ScenariosView } from "./components/ScenariosView";
import { JudgeSettings } from "./components/JudgeSettings";

const DEFAULT_JUDGE_MODEL = "claude-sonnet-4-6";
const SCENARIOS_DIR = "";

function postHeaders(): Record<string, string> {
  return { "Content-Type": "application/json" };
}

function timeAgo(isoStr: string) {
  const diff = Date.now() - new Date(isoStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs} hr${hrs > 1 ? "s" : ""} ago`;
  return `${Math.floor(hrs / 24)} days ago`;
}

function useViewport() {
  const [w, setW] = useState(typeof window !== "undefined" ? window.innerWidth : 1280);
  useEffect(() => {
    const onResize = () => setW(window.innerWidth);
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);
  return { w, isMobile: w < 720, isTablet: w >= 720 && w < 1100, isDesktop: w >= 1100 };
}

export default function App() {
  const [theme, setTheme] = useState("light");
  const [activeNav, setActiveNav] = useState("Runs");
  const [openId, setOpenId] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("All");
  const [showRunModal, setShowRunModal] = useState(false);
  const [modalTab, setModalTab] = useState<"existing" | "new">("existing");
  const [selectedScenarioId, setSelectedScenarioId] = useState<string | null>(null);
  const [runLoading, setRunLoading] = useState(false);
  const [newScenario, setNewScenario] = useState({ name: "", agent_type: "generic", prompt: "", test_input: "", description: "" });
  const [judgeModel, setJudgeModel] = useState(DEFAULT_JUDGE_MODEL);
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [toastType, setToastType] = useState<"success" | "error">("success");
  const [bannerDismissed, setBannerDismissed] = useState(false);
  const [howExpanded, setHowExpanded] = useState(false);

  const { runs, counts, passRate, fetchedAt, runDetails, runDetailsLoading, fetchRuns, fetchRunDetail } = useRuns();
  const { scenarios, scenariosLoading, fetchScenarios } = useScenarios();
  const { isMobile, isTablet, isDesktop } = useViewport();
  const anyKeySet = useConfigStatus();
  const showBanner = anyKeySet === false && !bannerDismissed;

  useEffect(() => {
    document.body.style.margin = "0";
    document.body.style.padding = "0";
    document.body.style.background = theme === "dark" ? "#0D0C1E" : "#F2F1FF";
  }, [theme]);

  useEffect(() => { fetchScenarios(); }, []);
  useEffect(() => { if (activeNav === "Scenarios") fetchScenarios(); }, [activeNav]);

  function showToast(msg: string, type: "success" | "error" = "success") {
    setToastMsg(msg);
    setToastType(type);
    setTimeout(() => setToastMsg(null), 3000);
  }

  const filtered = useMemo(() => runs.filter((r) => {
    if (filter !== "All" && r.status !== filter.toLowerCase()) return false;
    if (search && !r.name.toLowerCase().includes(search.toLowerCase()) && !r.id.includes(search)) return false;
    return true;
  }), [filter, search, runs]);

  const latencyData = useMemo(() => runs
    .filter((r) => r.latencyS !== null && r.latencyS !== undefined && r.status !== "running")
    .slice(0, 10).reverse()
    .map((r, i) => ({ i: i + 1, v: parseFloat((r.latencyS as number).toFixed(1)) })), [runs]);

  const avgLatency = useMemo(() => {
    if (latencyData.length === 0) return null;
    return (latencyData.reduce((s, d) => s + d.v, 0) / latencyData.length).toFixed(1);
  }, [latencyData]);

  const latencyTrend = useMemo(() => {
    if (latencyData.length < 2) return null;
    const first = latencyData[0].v, last = latencyData[latencyData.length - 1].v;
    return last < first ? "↓" : last > first ? "↑" : "→";
  }, [latencyData]);

  async function handleRunNewEval() {
    if (!selectedScenarioId || runLoading) return;
    setRunLoading(true);
    try {
      const response = await fetch("/api/runs", { method: "POST", headers: postHeaders(), body: JSON.stringify({ scenarios_dir: SCENARIOS_DIR, scenario_ids: [selectedScenarioId], mock: false, judge_model: judgeModel || undefined }) });
      if (!response.ok) {
        const errorBody = await response.json().catch(() => ({}));
        showToast((errorBody as { detail?: string }).detail || `Failed: HTTP ${response.status}`, "error");
        return;
      }
      setShowRunModal(false); setSelectedScenarioId(null); showToast("Eval started", "success");
      setTimeout(fetchRuns, 1500);
    } catch { showToast("Failed to start eval", "error"); } finally { setRunLoading(false); }
  }

  async function handleCreateAndRun() {
    if (!newScenario.name.trim() || !newScenario.prompt.trim() || !newScenario.test_input.trim() || runLoading) return;
    setRunLoading(true);
    try {
      const scenResp = await fetch("/api/scenarios", { method: "POST", headers: postHeaders(), body: JSON.stringify(newScenario) });
      if (!scenResp.ok) {
        const errorBody = await scenResp.json().catch(() => ({}));
        showToast((errorBody as { detail?: string }).detail || `Failed to create scenario: HTTP ${scenResp.status}`, "error");
        return;
      }
      const created = await scenResp.json() as { id?: string };
      if (!created.id) {
        showToast("Server returned invalid response", "error");
        return;
      }
      const runResp = await fetch("/api/runs", { method: "POST", headers: postHeaders(), body: JSON.stringify({ scenarios_dir: SCENARIOS_DIR, scenario_ids: [created.id], mock: false, judge_model: judgeModel || undefined }) });
      if (!runResp.ok) {
        const errorBody = await runResp.json().catch(() => ({}));
        showToast((errorBody as { detail?: string }).detail || `Failed to start run: HTTP ${runResp.status}`, "error");
        return;
      }
      setShowRunModal(false); setNewScenario({ name: "", agent_type: "generic", prompt: "", test_input: "", description: "" });
      fetchScenarios(true); showToast("Eval started", "success"); setTimeout(fetchRuns, 1500);
    } catch { showToast("Failed to create scenario", "error"); } finally { setRunLoading(false); }
  }

  const runEvalBtn = (label: string) => (
    <button className="flex items-center" onClick={() => { setShowRunModal(true); setModalTab("existing"); fetchScenarios(true); }}
      style={{ height: 40, padding: "0 6px 0 16px", borderRadius: 99, background: "var(--brand)", color: "var(--brand-text)", border: 0, cursor: "pointer", gap: 10, fontSize: 13, fontWeight: 590, letterSpacing: "-0.008em", flexShrink: 0 }}>
      {label}
      <span className="flex items-center justify-center" style={{ width: 28, height: 28, borderRadius: "50%", background: "rgba(255,255,255,0.2)", color: "var(--brand-text)", flexShrink: 0 }}><ArrowUpRight size={13} strokeWidth={2.25} /></span>
    </button>
  );

  return (
    <>
      <style>{`
        :root { --font-sans: -apple-system, BlinkMacSystemFont, "SF Pro Display", "Inter", system-ui, sans-serif; --font-mono: "SF Mono", ui-monospace, "JetBrains Mono", Menlo, monospace; }
        .ae-root[data-theme="light"] { --canvas:#F2F1FF;--paper:#FFFFFF;--surface-2:#ECEAFF;--surface-3:#E3E1FF;--ink-1:#1E1C58;--ink-2:#4A4890;--ink-3:#8E8CB8;--ink-4:#C4C2E0;--ok:#22c070;--ok-soft:#e4f7ee;--ok-ink:#1e6641;--warn:#F0A03A;--bad:#E24B4A;--bad-soft:#fceaea;--bad-ink:#9e2020;--brand:#5b5ef4;--brand-soft:#eeeeff;--brand-ink:#3739c4;--brand-text:#ffffff;--shadow-card:0 1px 2px rgba(91,94,244,0.04),0 4px 12px -2px rgba(91,94,244,0.07),0 12px 32px -8px rgba(91,94,244,0.10);--shadow-card-strong:0 2px 4px rgba(91,94,244,0.08),0 8px 24px -4px rgba(91,94,244,0.13),0 24px 48px -12px rgba(91,94,244,0.18); }
        .ae-root[data-theme="dark"] { --canvas:#0D0C1E;--paper:#16152E;--surface-2:#1F1E3C;--surface-3:#282750;--ink-1:#EEEEFF;--ink-2:#AEACD8;--ink-3:#7270A0;--ink-4:#46456E;--ok:#22c070;--ok-soft:rgba(34,192,112,0.15);--ok-ink:#5dd49a;--warn:#F0A03A;--bad:#e24b4a;--bad-soft:rgba(226,75,74,0.15);--bad-ink:#f07878;--brand:#7678f6;--brand-soft:rgba(118,120,246,0.18);--brand-ink:#c8c9fb;--brand-text:#ffffff;--shadow-card:0 1px 2px rgba(0,0,0,0.3),0 4px 12px -2px rgba(0,0,0,0.4);--shadow-card-strong:0 4px 8px rgba(0,0,0,0.35),0 12px 32px -4px rgba(0,0,0,0.5); }
        .ae-root { font-family:var(--font-sans);background:var(--canvas);color:var(--ink-1);font-size:14px;line-height:1.5;min-height:100vh;-webkit-font-smoothing:antialiased; }
        .ae-root *::selection { background:var(--brand);color:#fff; }
        .ae-root input:focus { outline:none; }
        .ae-root input::placeholder,.ae-root textarea::placeholder { color:var(--ink-4); }
        .ae-root select { appearance:none; }
        @keyframes ae-spin { to { transform:rotate(360deg); } } .ae-spin { animation:ae-spin 1s linear infinite; }
        @keyframes ae-pulse-soft { 0%,100%{transform:scale(1)}50%{transform:scale(1.18)} }
        @keyframes ae-toast-in { from{opacity:0;transform:translateX(-50%) translateY(12px)}to{opacity:1;transform:translateX(-50%) translateY(0)} }
      `}</style>

      <div className="ae-root" data-theme={theme}>
        <div className="flex" style={{ minHeight: "100vh", padding: isMobile ? 12 : isTablet ? 14 : 18, gap: isMobile ? 0 : isTablet ? 12 : 16, paddingBottom: isMobile ? 88 : 18 }}>
          <div className="flex-1 flex flex-col" style={{ minWidth: 0, gap: isMobile ? 12 : 16 }}>
            <Header theme={theme} onToggleTheme={() => setTheme(t => t === "light" ? "dark" : "light")} activeNav={activeNav} onNavChange={setActiveNav} search={search} onSearchChange={setSearch} isMobile={isMobile} isTablet={isTablet} isDesktop={isDesktop} />

            {showBanner && (
              <div style={{ borderRadius: 14, padding: "12px 16px", background: "rgba(240,160,58,0.12)", border: "1px solid rgba(240,160,58,0.3)" }}>
                <div className="flex items-center justify-between" style={{ gap: 12 }}>
                  <span style={{ fontSize: 13, color: "var(--warn)", fontWeight: 510, flex: 1 }}>
                    No provider API key detected. Set <code style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}>ANTHROPIC_API_KEY</code> or <code style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}>OPENAI_API_KEY</code> in your environment, or use mock mode for testing.
                  </span>
                  <div className="flex items-center" style={{ gap: 8, flexShrink: 0 }}>
                    <button onClick={() => setHowExpanded((p) => !p)} style={{ fontSize: 12, color: "var(--warn)", background: "none", border: "none", cursor: "pointer", fontWeight: 590, textDecoration: "underline" }}>
                      How?
                    </button>
                    <button onClick={() => setBannerDismissed(true)} style={{ fontSize: 20, lineHeight: 1, color: "var(--ink-3)", background: "none", border: "none", cursor: "pointer", padding: "0 2px" }}>
                      ×
                    </button>
                  </div>
                </div>
                {howExpanded && (
                  <div style={{ marginTop: 10, padding: "8px 12px", borderRadius: 8, background: "var(--surface-2)", fontFamily: "var(--font-mono)", fontSize: 12, color: "var(--ink-2)", lineHeight: 1.8 }}>
                    <div>PowerShell: $env:ANTHROPIC_API_KEY='sk-ant-...'</div>
                    <div>Bash:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; export ANTHROPIC_API_KEY='sk-ant-...'</div>
                    <div style={{ marginTop: 6, fontFamily: "var(--font-sans)", fontSize: 11.5, color: "var(--ink-3)" }}>Then restart the server.</div>
                  </div>
                )}
              </div>
            )}

            {activeNav === "Scenarios" && <ScenariosView scenarios={scenarios} scenariosLoading={scenariosLoading} runs={runs} isMobile={isMobile} setActiveNav={setActiveNav} />}

            {activeNav === "Dashboard" && (<>
              <div className="flex items-center justify-between" style={{ gap: 12 }}>
                <div>
                  <div style={{ fontSize: isMobile ? 20 : 24, fontWeight: 590, color: "var(--ink-1)", letterSpacing: "-0.022em", lineHeight: 1.15 }}>Dashboard</div>
                  <div style={{ fontSize: 12, color: "var(--ink-3)", marginTop: 2 }}>{counts.all} runs{fetchedAt ? ` · last updated ${timeAgo(fetchedAt)}` : ""}</div>
                </div>
                {runEvalBtn(isMobile ? "New eval" : "Run new eval")}
              </div>
              <div className="grid" style={{ gridTemplateColumns: isMobile ? "1fr" : "1fr 1fr", gap: isMobile ? 12 : 14 }}>
                <div style={{ background: "var(--paper)", borderRadius: isMobile ? 20 : 24, padding: isMobile ? "18px 18px" : "20px 22px", boxShadow: "var(--shadow-card)" }}>
                  <span style={{ fontSize: 11.5, color: "var(--ink-3)", fontWeight: 510 }}>Pass rate</span>
                  <div className="flex items-baseline" style={{ gap: 4, marginTop: 6 }}>
                    <span style={{ fontSize: isMobile ? 44 : 48, fontWeight: 510, letterSpacing: "-0.03em", color: "var(--ink-1)", fontVariantNumeric: "tabular-nums", lineHeight: 0.95 }}>{passRate.toFixed(1)}</span>
                    <span style={{ fontSize: 18, color: "var(--ink-3)", fontWeight: 400 }}>%</span>
                  </div>
                  <div className="relative flex items-center justify-center" style={{ width: "100%", height: isMobile ? 130 : 144, marginTop: 10 }}>
                    <svg viewBox="0 0 200 200" style={{ width: isMobile ? 130 : 144, height: isMobile ? 130 : 144 }}>
                      {[86, 66, 46, 26].map((r, i) => (<circle key={i} cx="100" cy="100" r={r} fill="none" stroke="var(--brand)" strokeWidth="2" opacity={1 - i * 0.18} />))}
                    </svg>
                    {[{ label: String(counts.all), sub: "total", top: "8%" }, { label: String(counts.pass), sub: "pass", top: "21%" }, { label: String(counts.fail), sub: "fail", top: "34%" }, { label: String(counts.running), sub: "live", top: "48%" }].map((l, i) => (
                      <div key={i} style={{ position: "absolute", top: l.top, left: "50%", transform: "translate(-50%,-50%)", background: "var(--paper)", padding: "1px 6px", borderRadius: 4, whiteSpace: "nowrap" }}>
                        <span style={{ fontSize: 10.5, fontWeight: 590, color: "var(--ink-1)", fontFamily: "var(--font-mono)", fontVariantNumeric: "tabular-nums" }}>{l.label}</span>
                        <span style={{ fontSize: 9.5, color: "var(--ink-3)", marginLeft: 4 }}>{l.sub}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div style={{ background: "var(--brand)", color: "var(--brand-text)", borderRadius: isMobile ? 20 : 24, padding: isMobile ? "18px 18px" : "18px 22px", boxShadow: "var(--shadow-card-strong)", display: "flex", flexDirection: "column" }}>
                  <div className="flex items-center justify-between" style={{ marginBottom: 6 }}>
                    <span style={{ fontSize: 11.5, color: "rgba(255,255,255,0.55)", fontWeight: 510 }}>Avg latency</span>
                    <Zap size={12} strokeWidth={2} style={{ color: "rgba(255,255,255,0.55)" }} />
                  </div>
                  <div className="flex items-baseline" style={{ gap: 4 }}>
                    <span style={{ fontSize: isMobile ? 36 : 32, fontWeight: 510, letterSpacing: "-0.025em", fontVariantNumeric: "tabular-nums", lineHeight: 1 }}>{avgLatency ?? "—"}</span>
                    {avgLatency !== null && <span style={{ fontSize: 14, color: "rgba(255,255,255,0.55)", fontWeight: 400 }}>s</span>}
                  </div>
                  <div style={{ fontSize: 11, color: "rgba(255,255,255,0.55)", marginTop: 4, fontFamily: "var(--font-mono)" }}>{latencyData.length > 0 ? `last ${latencyData.length} run${latencyData.length > 1 ? "s" : ""}${latencyTrend ? ` · trend ${latencyTrend}` : ""}` : "no completed runs yet"}</div>
                  {latencyData.length >= 2 && (<div style={{ marginTop: 14, height: 52 }}><ResponsiveContainer width="100%" height="100%"><LineChart data={latencyData} margin={{ top: 4, right: 4, bottom: 4, left: 4 }}><Tooltip contentStyle={{ background: "rgba(255,255,255,0.12)", border: "none", borderRadius: 8, fontSize: 11, color: "#fff", padding: "4px 10px" }} itemStyle={{ color: "#fff" }} formatter={(v: number) => [`${v}s`, "latency"]} labelFormatter={() => ""} /><Line type="monotone" dataKey="v" stroke="rgba(255,255,255,0.7)" strokeWidth={1.5} dot={{ r: 2, fill: "rgba(255,255,255,0.7)", strokeWidth: 0 }} activeDot={{ r: 3, fill: "#fff", strokeWidth: 0 }} isAnimationActive={false} /></LineChart></ResponsiveContainer></div>)}
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between" style={{ paddingTop: 4, marginBottom: isMobile ? 10 : 12, gap: 8 }}>
                  <h2 style={{ fontSize: isMobile ? 18 : 20, fontWeight: 590, letterSpacing: "-0.022em", color: "var(--ink-1)" }}>Recent runs</h2>
                  <button onClick={() => setActiveNav("Runs")} className="flex items-center" style={{ gap: 4, background: "transparent", border: 0, cursor: "pointer", fontSize: 12.5, color: "var(--ink-3)", fontWeight: 510 }}>View all <ArrowUpRight size={12} strokeWidth={2} /></button>
                </div>
                <div className="flex flex-col" style={{ gap: isMobile ? 8 : 10 }}>
                  {runs.slice(0, 5).map((r) => (<RunRow key={r.fullRunId} run={r} isOpen={openId === r.fullRunId} onToggle={() => { const opening = openId !== r.fullRunId; setOpenId(opening ? r.fullRunId : null); if (opening && !runDetails[r.fullRunId] && !runDetailsLoading.has(r.fullRunId)) fetchRunDetail(r.fullRunId); }} isMobile={isMobile} detail={runDetails[r.fullRunId]} detailLoading={runDetailsLoading.has(r.fullRunId)} />))}
                </div>
              </div>
            </>)}

            {activeNav === "Runs" && (<>
              <div className="flex items-center justify-between" style={{ gap: 12 }}>
                <div>
                  <div style={{ fontSize: isMobile ? 20 : 24, fontWeight: 590, color: "var(--ink-1)", letterSpacing: "-0.022em", lineHeight: 1.15 }}>Eval Runs</div>
                  <div style={{ fontSize: 12, color: "var(--ink-3)", marginTop: 2 }}>{counts.all} runs{fetchedAt ? ` · last updated ${timeAgo(fetchedAt)}` : ""}</div>
                </div>
                {runEvalBtn(isMobile ? "New eval" : "Run new eval")}
              </div>
              <div className="flex items-center justify-between" style={{ paddingTop: 4, gap: 8, flexWrap: "wrap" }}>
                <div className="flex items-center" style={{ gap: 12 }}>
                  <h2 style={{ fontSize: isMobile ? 18 : 20, fontWeight: 590, letterSpacing: "-0.022em", color: "var(--ink-1)" }}>All runs</h2>
                  <span style={{ fontSize: 12, color: "var(--ink-3)", fontFamily: "var(--font-mono)", fontVariantNumeric: "tabular-nums" }}>{filtered.length} of {counts.all}</span>
                </div>
                <div className="flex items-center" style={{ gap: 6, overflowX: "auto", maxWidth: "100%" }}>
                  {[{ k: "All", n: counts.all }, { k: "Pass", n: counts.pass, dot: "var(--ok)" }, { k: "Fail", n: counts.fail, dot: "var(--bad)" }, { k: "Running", n: counts.running, dot: "var(--brand)" }].map(({ k, n, dot }: { k: string; n: number; dot?: string }) => {
                    const active = filter === k;
                    return (<button key={k} onClick={() => setFilter(k)} className="flex items-center" style={{ gap: 6, height: isMobile ? 32 : 36, padding: isMobile ? "0 12px" : "0 14px", borderRadius: 99, background: active ? "var(--brand)" : "var(--paper)", color: active ? "var(--brand-text)" : "var(--ink-2)", border: 0, cursor: "pointer", fontSize: 12.5, fontWeight: active ? 590 : 510, boxShadow: active ? "none" : "var(--shadow-card)", flexShrink: 0 }}>
                      {dot && <span style={{ width: 6, height: 6, borderRadius: "50%", background: active ? "var(--paper)" : dot, opacity: active ? 0.7 : 1 }} />}
                      {k} <span style={{ fontFamily: "var(--font-mono)", fontSize: 11, opacity: 0.6, fontVariantNumeric: "tabular-nums" }}>{n}</span>
                    </button>);
                  })}
                </div>
              </div>
              <div className="flex flex-col" style={{ gap: isMobile ? 8 : 10 }}>
                {filtered.length === 0 ? (
                  <div style={{ padding: "52px 24px", textAlign: "center", background: "var(--paper)", borderRadius: 22, boxShadow: "var(--shadow-card)", display: "flex", flexDirection: "column", alignItems: "center", gap: 12 }}>
                    {filter === "Fail" ? (<><CheckCheck size={24} style={{ color: "var(--ok)" }} /><span style={{ fontSize: 14, color: "var(--ok)", fontWeight: 590 }}>Everything is passing — no failures.</span></>) : <span style={{ fontSize: 13.5, color: "var(--ink-3)" }}>{filter === "Running" ? "No runs in progress right now." : search ? `No runs match "${search}"` : "No eval runs yet."}</span>}
                  </div>
                ) : filtered.map((r) => (<RunRow key={r.fullRunId} run={r} isOpen={openId === r.fullRunId} onToggle={() => { const opening = openId !== r.fullRunId; setOpenId(opening ? r.fullRunId : null); if (opening && !runDetails[r.fullRunId] && !runDetailsLoading.has(r.fullRunId)) fetchRunDetail(r.fullRunId); }} isMobile={isMobile} detail={runDetails[r.fullRunId]} detailLoading={runDetailsLoading.has(r.fullRunId)} />))}
              </div>
            </>)}
          </div>
        </div>

        {isMobile && (
          <nav style={{ position: "fixed", bottom: 12, left: 12, right: 12, height: 64, background: "var(--paper)", borderRadius: 99, boxShadow: "var(--shadow-card-strong)", display: "flex", alignItems: "center", justifyContent: "space-around", padding: "0 8px", zIndex: 50 }}>
            {NAV_TABS.map((tab) => { const active = activeNav === tab; return (<button key={tab} onClick={() => setActiveNav(tab)} className="flex flex-col items-center justify-center" style={{ flex: 1, height: 48, borderRadius: 99, background: active ? "var(--brand)" : "transparent", color: active ? "var(--brand-text)" : "var(--ink-2)", border: 0, cursor: "pointer", gap: 2, fontSize: 10.5, fontWeight: active ? 590 : 510, margin: "0 2px" }}><span style={{ fontSize: active ? 11 : 10.5 }}>{tab}</span></button>); })}
          </nav>
        )}

        {showRunModal && (
          <div style={{ position: "fixed", inset: 0, background: "rgba(14,12,35,0.65)", zIndex: 100, display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }} onClick={(e) => { if (e.target === e.currentTarget) setShowRunModal(false); }}>
            <div style={{ background: "var(--paper)", borderRadius: 24, padding: isMobile ? 20 : 28, width: "100%", maxWidth: 480, boxShadow: "var(--shadow-card-strong)", display: "flex", flexDirection: "column", gap: 16 }}>
              <div className="flex items-center justify-between">
                <div><span style={{ fontSize: 17, fontWeight: 590, color: "var(--ink-1)", letterSpacing: "-0.015em" }}>Run new eval</span><div style={{ fontSize: 12, color: "var(--ink-3)", marginTop: 2 }}>{modalTab === "existing" ? "Pick a scenario to evaluate" : "Define a new scenario and run it"}</div></div>
                <button onClick={() => { setShowRunModal(false); setSelectedScenarioId(null); }} style={{ width: 32, height: 32, borderRadius: "50%", background: "var(--surface-2)", color: "var(--ink-2)", border: 0, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}><X size={14} strokeWidth={2} /></button>
              </div>
              <div className="flex" style={{ gap: 4, background: "var(--surface-2)", borderRadius: 10, padding: 3 }}>
                {(["existing", "new"] as const).map((tab) => (<button key={tab} onClick={() => setModalTab(tab)} style={{ flex: 1, height: 30, borderRadius: 8, border: 0, cursor: "pointer", fontSize: 12.5, fontWeight: 510, background: modalTab === tab ? "var(--paper)" : "transparent", color: modalTab === tab ? "var(--ink-1)" : "var(--ink-3)" }}>{tab === "existing" ? "Existing scenarios" : "New scenario"}</button>))}
              </div>
              {modalTab === "existing" && (<>
                <div style={{ display: "flex", flexDirection: "column", gap: 6, maxHeight: 280, overflowY: "auto" }}>
                  {scenariosLoading ? <div style={{ padding: "32px 0", textAlign: "center" }}><Loader2 size={18} strokeWidth={2} className="ae-spin" style={{ color: "var(--ink-3)", margin: "0 auto", display: "block" }} /></div>
                    : scenarios.length === 0 ? <div style={{ padding: "24px 0", textAlign: "center", fontSize: 13, color: "var(--ink-3)" }}>No scenarios found — create one in the New scenario tab</div>
                    : scenarios.map((s) => { const isSel = selectedScenarioId === s.id; return (<button key={s.id} onClick={() => setSelectedScenarioId(isSel ? null : s.id)} style={{ padding: "11px 14px", borderRadius: 12, background: isSel ? "var(--brand-soft)" : "var(--surface-2)", color: isSel ? "var(--brand-ink)" : "var(--ink-1)", border: isSel ? "1px solid var(--brand)" : "1px solid transparent", cursor: "pointer", textAlign: "left" }}><div style={{ fontSize: 13, fontWeight: 590 }}>{s.name}</div><div style={{ fontSize: 11.5, marginTop: 2, color: isSel ? "var(--brand-ink)" : "var(--ink-3)", opacity: 0.85 }}>{s.agent_type} · {s.step_count} steps{s.tags?.length > 0 && " · " + s.tags.join(", ")}</div></button>); })}
                </div>
                <JudgeSettings model={judgeModel} onModelChange={setJudgeModel} />
                <button onClick={handleRunNewEval} disabled={!selectedScenarioId || runLoading} style={{ height: 44, borderRadius: 99, border: 0, background: selectedScenarioId ? "var(--brand)" : "var(--surface-2)", color: selectedScenarioId ? "var(--brand-text)" : "var(--ink-4)", cursor: selectedScenarioId ? "pointer" : "not-allowed", fontSize: 13.5, fontWeight: 590, display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
                  {runLoading ? <><Loader2 size={14} strokeWidth={2} className="ae-spin" />Starting…</> : <><ArrowUpRight size={14} strokeWidth={2.25} />Run eval</>}
                </button>
              </>)}
              {modalTab === "new" && (<>
                <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                  <div className="flex" style={{ gap: 8 }}>
                    <div style={{ flex: 2, display: "flex", flexDirection: "column", gap: 4 }}><label htmlFor="ns-name" style={{ fontSize: 11, color: "var(--ink-3)", fontWeight: 510 }}>Name</label><input id="ns-name" value={newScenario.name} onChange={(e) => setNewScenario((p) => ({ ...p, name: e.target.value }))} placeholder="e.g. Qualify SDR lead" style={{ height: 36, borderRadius: 8, border: "1px solid var(--ink-4)", background: "var(--surface-2)", color: "var(--ink-1)", padding: "0 10px", fontSize: 13, width: "100%", boxSizing: "border-box" }} /></div>
                    <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 4 }}><label htmlFor="ns-agent-type" style={{ fontSize: 11, color: "var(--ink-3)", fontWeight: 510 }}>Agent type</label><select id="ns-agent-type" value={newScenario.agent_type} onChange={(e) => setNewScenario((p) => ({ ...p, agent_type: e.target.value }))} style={{ height: 36, borderRadius: 8, border: "1px solid var(--ink-4)", background: "var(--surface-2)", color: "var(--ink-1)", padding: "0 8px", fontSize: 13, width: "100%" }}>{["generic", "sdr", "coding", "support", "research", "finance", "legal"].map((t) => <option key={t} value={t}>{t}</option>)}</select></div>
                  </div>
                  <div style={{ display: "flex", flexDirection: "column", gap: 4 }}><label htmlFor="ns-prompt" style={{ fontSize: 11, color: "var(--ink-3)", fontWeight: 510 }}>System prompt</label><textarea id="ns-prompt" value={newScenario.prompt} onChange={(e) => setNewScenario((p) => ({ ...p, prompt: e.target.value }))} placeholder="You are an expert SDR..." rows={3} style={{ borderRadius: 8, border: "1px solid var(--ink-4)", background: "var(--surface-2)", color: "var(--ink-1)", padding: "8px 10px", fontSize: 12.5, resize: "vertical", fontFamily: "var(--font-sans)", width: "100%", boxSizing: "border-box" }} /></div>
                  <div style={{ display: "flex", flexDirection: "column", gap: 4 }}><label htmlFor="ns-test-input" style={{ fontSize: 11, color: "var(--ink-3)", fontWeight: 510 }}>Test input</label><textarea id="ns-test-input" value={newScenario.test_input} onChange={(e) => setNewScenario((p) => ({ ...p, test_input: e.target.value }))} placeholder="Prospect: Sarah Chen..." rows={3} style={{ borderRadius: 8, border: "1px solid var(--ink-4)", background: "var(--surface-2)", color: "var(--ink-1)", padding: "8px 10px", fontSize: 12.5, resize: "vertical", fontFamily: "var(--font-sans)", width: "100%", boxSizing: "border-box" }} /></div>
                </div>
                <JudgeSettings model={judgeModel} onModelChange={setJudgeModel} />
                <button onClick={handleCreateAndRun} disabled={!newScenario.name.trim() || !newScenario.prompt.trim() || !newScenario.test_input.trim() || runLoading} style={{ height: 44, borderRadius: 99, border: 0, background: (newScenario.name && newScenario.prompt && newScenario.test_input) ? "var(--brand)" : "var(--surface-2)", color: (newScenario.name && newScenario.prompt && newScenario.test_input) ? "var(--brand-text)" : "var(--ink-4)", cursor: (newScenario.name && newScenario.prompt && newScenario.test_input) ? "pointer" : "not-allowed", fontSize: 13.5, fontWeight: 590, display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
                  {runLoading ? <><Loader2 size={14} strokeWidth={2} className="ae-spin" />Creating…</> : <><ArrowUpRight size={14} strokeWidth={2.25} />Create &amp; run</>}
                </button>
              </>)}
            </div>
          </div>
        )}

        {toastMsg && (<div style={{ position: "fixed", bottom: isMobile ? 90 : 28, left: "50%", transform: "translateX(-50%)", background: toastType === "error" ? "var(--bad)" : "var(--brand)", color: "#fff", padding: "10px 20px", borderRadius: 99, fontSize: 13, zIndex: 200, boxShadow: "var(--shadow-card-strong)", whiteSpace: "nowrap", animation: "ae-toast-in 200ms ease" }}>{toastMsg}</div>)}
      </div>
    </>
  );
}
