import { useState, useEffect } from "react";

export function useConfigStatus(): boolean | null {
  const [anyKeySet, setAnyKeySet] = useState<boolean | null>(null);
  useEffect(() => {
    fetch("/api/config-status")
      .then((r) => r.json())
      .then((d: { any_key_set: boolean }) => setAnyKeySet(d.any_key_set))
      .catch(() => setAnyKeySet(null));
  }, []);
  return anyKeySet;
}
