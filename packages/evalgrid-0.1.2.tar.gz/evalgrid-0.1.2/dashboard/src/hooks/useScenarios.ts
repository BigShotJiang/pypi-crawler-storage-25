import { useState, useCallback } from "react";
import type { Scenario } from "../types";

export function useScenarios() {
  const [scenarios, setScenarios] = useState<Scenario[]>([]);
  const [scenariosLoading, setScenariosLoading] = useState(false);

  const fetchScenarios = useCallback((force = false) => {
    if (!force && (scenarios.length > 0 || scenariosLoading)) return;
    setScenariosLoading(true);
    fetch("/api/scenarios")
      .then((r) => r.json())
      .then((data: unknown) => setScenarios(Array.isArray(data) ? (data as Scenario[]) : []))
      .catch((err) => console.error("evalgrid: failed to fetch scenarios", err))
      .finally(() => setScenariosLoading(false));
  }, [scenarios.length, scenariosLoading]);

  return { scenarios, scenariosLoading, fetchScenarios };
}
