import { useState, useEffect, useCallback } from "react";
import type { Run, RunCounts, RunDetail } from "../types";

function timeAgo(isoStr: string): string {
  const diff = Date.now() - new Date(isoStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs} hr${hrs > 1 ? "s" : ""} ago`;
  return `${Math.floor(hrs / 24)} days ago`;
}

function mapApiRun(r: {
  run_id: string;
  status: string;
  passed: number;
  total: number;
  finished_at: string | null;
  started_at: string;
  pass_rate: number;
  scenario_names?: string[];
  skipped_count?: number;
  skipped_scenarios?: Array<{ file: string; reason: string }>;
}): Run {
  const isRunning = r.status === "running";
  const status: "pass" | "fail" | "running" = isRunning
    ? "running"
    : r.passed === r.total && r.total > 0
    ? "pass"
    : "fail";
  const latencyS =
    r.finished_at && r.started_at
      ? (new Date(r.finished_at).getTime() - new Date(r.started_at).getTime()) / 1000
      : null;
  const names: string[] = r.scenario_names ?? [];
  const name =
    names.length === 1
      ? names[0]
      : names.length > 1 && names.length <= 3
      ? names.join(", ")
      : names.length > 3
      ? `${names[0]} +${names.length - 1} more`
      : r.run_id.substring(0, 8);
  return {
    id: r.run_id.substring(0, 8),
    fullRunId: r.run_id,
    status,
    name,
    scenario:
      names.length > 0
        ? names.length === 1
          ? "1 scenario"
          : `${names.length} scenarios`
        : r.total === 1
        ? "1 scenario"
        : `${r.total} scenarios`,
    score: r.pass_rate,
    stepsDone: r.passed,
    stepsTotal: r.total,
    ts: timeAgo(r.started_at),
    rawStartedAt: r.started_at,
    duration: latencyS !== null ? `${latencyS.toFixed(1)}s` : "—",
    latencyS,
    tokens: "—",
    steps: [],
    scenario_names: names,
    skippedCount: r.skipped_count ?? 0,
    skippedScenarios: r.skipped_scenarios ?? [],
  };
}

export function useRuns() {
  const [runs, setRuns] = useState<Run[]>([]);
  const [counts, setCounts] = useState<RunCounts>({ all: 0, pass: 0, fail: 0, running: 0 });
  const [passRate, setPassRate] = useState(0);
  const [fetchedAt, setFetchedAt] = useState<string | null>(null);
  const [runDetails, setRunDetails] = useState<Record<string, RunDetail>>({});
  const [runDetailsLoading, setRunDetailsLoading] = useState<Set<string>>(new Set());

  const fetchRuns = useCallback(() => {
    fetch("/api/runs")
      .then((r) => r.json())
      .then((data: unknown[]) => {
        if (!Array.isArray(data) || data.length === 0) return;
        const mapped = (data as Parameters<typeof mapApiRun>[0][])
          .map(mapApiRun)
          .sort(
            (a, b) =>
              new Date(b.rawStartedAt).getTime() - new Date(a.rawStartedAt).getTime()
          );
        setRuns(mapped);
        const pass = mapped.filter((r) => r.status === "pass").length;
        const fail = mapped.filter((r) => r.status === "fail").length;
        const running = mapped.filter((r) => r.status === "running").length;
        setCounts({ all: mapped.length, pass, fail, running });
        const completed = mapped.filter((r) => r.status !== "running");
        setPassRate(completed.length ? (pass / completed.length) * 100 : 0);
        setFetchedAt(new Date().toISOString());
      })
      .catch((err) => console.error("evalgrid: failed to fetch runs", err));
  }, []);

  const fetchRunDetail = useCallback((fullRunId: string) => {
    setRunDetailsLoading((prev) => new Set(prev).add(fullRunId));
    fetch(`/api/runs/${fullRunId}`)
      .then((r) => r.json())
      .then((data: RunDetail) => {
        setRunDetails((prev) => ({ ...prev, [fullRunId]: data }));
      })
      .catch((err) => console.error("evalgrid: failed to fetch run detail", err))
      .finally(() => {
        setRunDetailsLoading((prev) => {
          const next = new Set(prev);
          next.delete(fullRunId);
          return next;
        });
      });
  }, []);

  useEffect(() => {
    fetchRuns();
    const pollId = setInterval(fetchRuns, 10000);
    return () => clearInterval(pollId);
  }, [fetchRuns]);

  return {
    runs,
    counts,
    passRate,
    fetchedAt,
    runDetails,
    runDetailsLoading,
    fetchRuns,
    fetchRunDetail,
  };
}
