# Changelog

All notable changes to evalgrid are documented in this file.

Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/). This project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.2]

### Added
- Per-run cost tracking: `ScenarioResult` now carries `prompt_tokens`, `completion_tokens`, and `cost_usd` summed across the agent and judge LiteLLM calls. CLI run table gains a "Cost" column; total cost prints in the summary. Mock-mode runs report zero cost. Cost is `0.0` for models LiteLLM has no pricing data for (local Ollama or new model names) — token counts are still reported.

### Tests
- 29 new tests for the deterministic assertion layer (`core/assertions.py`), backfilling all 8 check types (valid_json, no_markdown, required_fields, enum, forbidden_regex, contains, max_length, json_schema), plus unknown-check-type, invalid-regex, and hard/soft-fail flag propagation.
- 9 new tests for cost tracking covering token extraction, pricing-lookup defensiveness, judge-cost propagation, agent+judge summing in the runner, and hard-fail short-circuit accounting.

### Internal
- Extracted dashboard `useConfigStatus` hook into `dashboard/src/hooks/useConfigStatus.ts`.

## [0.1.1]

### Fixed
- Agent calls now resolve provider API keys from environment based on model prefix. Previously, all agent calls used the judge's API key, breaking advertised multi-provider configurations (e.g., GPT-4o agent with Claude judge).
- `evalgrid run` and `--fail-fast` now correctly exit non-zero on PassFail.ERROR (auth failures, invalid judge JSON, rate limits). Previously, ERROR results were treated as successes.
- Stale test in tests/test_cli.py now asserts the correct exit code 2 for hard failures.
- CLI help text uses ASCII hyphens instead of em-dashes for Windows console compatibility.

### Added
- `evalgrid init --force` and `--yes` / `-y` flags for non-interactive CI usage.

## [0.1.0]

### Added
- First public release.
- YAML scenario format with per-step verdicts.
- LLM-as-judge scoring via LiteLLM (Anthropic, OpenAI, Google, local Ollama, any LiteLLM provider).
- React dashboard for run history at localhost:8000.
- CLI: init, run, server, scenario.
- Mock mode for testing without API keys.
- 8 deterministic check types: valid_json, no_markdown, required_fields, enum, forbidden_regex, contains, max_length, json_schema.
- Benchmark suites with 4-rate scoring.
- HTML and Markdown reports via --report flag.
- Scenario YAML validation via `evalgrid scenario validate`.
- Flakiness detection: CLI + API + dashboard view.
- Granular CI exit codes (0 = pass, 1 = soft failure, 2 = hard failure).
- MIT licensed. Published to PyPI via OIDC trusted publishing.
