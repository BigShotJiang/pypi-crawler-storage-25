"""FastAPI application — eval runner + results API."""

from __future__ import annotations

import asyncio
import logging
import os
import re
import uuid
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import yaml
from fastapi import BackgroundTasks, Depends, FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from evalgrid.core import EvalConfig, ScenarioLoader
from evalgrid.core.models import PassFail
from evalgrid.core.runner import ScenarioRunner

from .database import RunRecord, ScenarioResultRecord, SuiteResultRecord, get_db, init_db

logger = logging.getLogger("evalgrid")

SCENARIOS_BASE_DIR = Path.home() / ".evalgrid" / "scenarios"

_API_KEY_RE = re.compile(
    r"(?:sk-ant-|sk-|pypi-)[A-Za-z0-9\-_]{6,}"
    r"|AIza[A-Za-z0-9\-_]{30,}"
)


def _sanitize_error(msg: str) -> str:
    return _API_KEY_RE.sub("[REDACTED]", msg)


def _iso(dt: datetime | None) -> str | None:
    """Return ISO-8601 string with explicit UTC offset so browsers parse it correctly."""
    if dt is None:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    return dt.isoformat()


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:  # noqa: ARG001
    await init_db()

    # Mark any runs that were left running (server restart) as failed
    from .database import SessionLocal
    try:
        async with SessionLocal() as db:
            stale_rows = await db.execute(
                select(RunRecord).where(RunRecord.finished_at.is_(None))
            )
            stale = stale_rows.scalars().all()
            for record in stale:
                record.finished_at = datetime.now(UTC)
                record.total = record.total or 0
                record.passed = record.passed or 0
                record.pass_rate = 0.0
                record.results = [{"error": "Server restarted"}]
                logger.warning("Marked stale run %s as failed (server restart)", record.run_id)
            if stale:
                await db.commit()
    except Exception as exc:
        logger.warning("Stale run cleanup skipped: %s", exc)

    yield


app = FastAPI(title="evalgrid API", version="0.1.0", lifespan=lifespan)


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    logger.error("Unhandled exception on %s: %s", request.url.path, exc)
    sanitized = _sanitize_error(str(exc))
    return JSONResponse(status_code=500, content={"detail": f"Internal server error: {sanitized}"})


app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://localhost:8000",
        "http://127.0.0.1:5173",
        "http://127.0.0.1:8000",
    ],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Schema ────────────────────────────────────────────────────────────────────

class RunRequest(BaseModel):
    scenarios_dir: str = ""
    tags: list[str] = []
    scenario_ids: list[str] = []
    mock: bool = False
    judge_model: str | None = None
    api_key: str | None = None


class RunSummary(BaseModel):
    run_id: str
    started_at: str
    finished_at: str | None = None
    pass_rate: float
    passed: int
    total: int
    status: str
    scenario_names: list[str] = []
    skipped_count: int = 0
    skipped_scenarios: list[dict[str, str]] = []


class ScenarioCreate(BaseModel):
    name: str = Field(..., max_length=200)
    description: str = Field(default="", max_length=1000)
    agent_type: str = "generic"
    prompt: str = Field(..., max_length=16000)
    test_input: str = Field(..., max_length=8000)
    expected_actions: list[dict[str, Any]] = []
    tags: list[str] = []
    scenarios_dir: str = ""


def _validate_path(scenarios_dir: str) -> Path:
    """Resolve and validate that the path stays within SCENARIOS_BASE_DIR."""
    _base = SCENARIOS_BASE_DIR.resolve()
    # Belt-and-suspenders: reject obvious traversal attempts
    if ".." in scenarios_dir:
        raise HTTPException(status_code=400, detail="Path outside allowed scenarios directory")
    resolved = (_base / scenarios_dir).resolve()
    if not resolved.is_relative_to(_base):
        raise HTTPException(status_code=400, detail="Path outside allowed scenarios directory")
    return resolved


# ── Routes ────────────────────────────────────────────────────────────────────

@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/api/flakiness")
async def get_flakiness(
    window: int = 10,
    db: AsyncSession = Depends(get_db),
) -> list[dict[str, Any]]:
    """Scenario stability across the last `window` runs per scenario."""
    from sqlalchemy import distinct, text as sa_text

    from .database import ScenarioResultRecord

    # Distinct scenario IDs
    id_rows = await db.execute(
        select(
            ScenarioResultRecord.scenario_id,
            ScenarioResultRecord.scenario_name,
        ).distinct()
    )
    scenarios = id_rows.all()

    result = []
    for sid, sname in scenarios:
        hist = await db.execute(
            select(ScenarioResultRecord.status)
            .where(ScenarioResultRecord.scenario_id == sid)
            .order_by(ScenarioResultRecord.id.desc())
            .limit(window)
        )
        statuses = [r[0] for r in hist.all()]
        if not statuses:
            continue
        run_count = len(statuses)
        pass_count = sum(1 for s in statuses if s == "pass")
        fail_count = sum(1 for s in statuses if s == "fail")
        error_count = sum(1 for s in statuses if s == "error")
        pass_rate = pass_count / run_count if run_count else 0.0
        flakiness_score = 1.0 - abs(2 * pass_rate - 1.0)
        result.append({
            "scenario_id": sid,
            "scenario_name": sname,
            "run_count": run_count,
            "pass_count": pass_count,
            "fail_count": fail_count,
            "error_count": error_count,
            "pass_rate": pass_rate,
            "flakiness_score": flakiness_score,
            "is_flaky": 0.0 < pass_rate < 1.0,
            "last_status": statuses[0],
        })

    result.sort(key=lambda x: -x["flakiness_score"])
    return result


@app.get("/api/config-status")
async def config_status() -> dict[str, Any]:
    anthropic_set = bool(os.environ.get("ANTHROPIC_API_KEY"))
    openai_set = bool(os.environ.get("OPENAI_API_KEY"))
    return {
        "anthropic_key_set": anthropic_set,
        "openai_key_set": openai_set,
        "any_key_set": anthropic_set or openai_set,
        "mock_available": True,
    }


@app.post("/api/runs", response_model=RunSummary)
async def create_run(
    req: RunRequest,
    background: BackgroundTasks,
    db: AsyncSession = Depends(get_db),
) -> RunSummary:
    _validate_path(req.scenarios_dir)

    if not req.mock and not req.api_key and not any(os.environ.get(k) for k in ("ANTHROPIC_API_KEY", "OPENAI_API_KEY")):
        raise HTTPException(
            status_code=400,
            detail=(
                "No provider API key found in environment "
                "(set ANTHROPIC_API_KEY or OPENAI_API_KEY)"
            ),
        )

    run_id = str(uuid.uuid4())
    record = RunRecord(
        run_id=run_id,
        started_at=datetime.now(UTC),
        results=[],
    )
    db.add(record)
    await db.commit()

    background.add_task(_execute_run, run_id, req)

    return RunSummary(
        run_id=run_id,
        started_at=_iso(record.started_at) or "",
        pass_rate=0.0,
        passed=0,
        total=0,
        status="running",
    )


@app.get("/api/runs", response_model=list[RunSummary])
async def list_runs(db: AsyncSession = Depends(get_db)) -> list[RunSummary]:
    rows = await db.execute(select(RunRecord).order_by(RunRecord.started_at.desc()).limit(100))
    records = rows.scalars().all()

    run_ids = [r.run_id for r in records]
    name_rows = await db.execute(
        select(ScenarioResultRecord.run_id, ScenarioResultRecord.scenario_name)
        .where(ScenarioResultRecord.run_id.in_(run_ids))
    )
    names_by_run: dict[str, list[str]] = {}
    for run_id, scenario_name in name_rows:
        names_by_run.setdefault(run_id, []).append(scenario_name)

    return [
        RunSummary(
            run_id=r.run_id,
            started_at=_iso(r.started_at) or "",
            finished_at=_iso(r.finished_at),
            pass_rate=r.pass_rate or 0.0,
            passed=r.passed or 0,
            total=r.total or 0,
            status="completed" if r.finished_at else "running",
            scenario_names=names_by_run.get(r.run_id, []),
            skipped_count=len(r.skipped_scenarios or []),
            skipped_scenarios=r.skipped_scenarios or [],
        )
        for r in records
    ]


@app.get("/api/runs/{run_id}")
async def get_run(run_id: str, db: AsyncSession = Depends(get_db)) -> dict[str, Any]:
    row = await db.execute(select(RunRecord).where(RunRecord.run_id == run_id))
    record = row.scalar_one_or_none()
    if not record:
        raise HTTPException(status_code=404, detail="Run not found")

    result_rows = await db.execute(
        select(ScenarioResultRecord).where(ScenarioResultRecord.run_id == run_id)
    )
    scenario_results = result_rows.scalars().all()

    return {
        "run_id": record.run_id,
        "started_at": _iso(record.started_at),
        "finished_at": _iso(record.finished_at),
        "pass_rate": record.pass_rate,
        "passed": record.passed,
        "total": record.total,
        "status": "completed" if record.finished_at else "running",
        "scenario_results": [
            {
                "scenario_id": r.scenario_id,
                "scenario_name": r.scenario_name,
                "agent_type": r.agent_type,
                "status": r.status,
                "overall_score": r.overall_score,
                "pass_rate": r.pass_rate,
                "reasoning": r.reasoning,
                "error": r.error,
                "steps": r.steps,
                "check_results": r.check_results or [],
                "hard_failed": bool(r.hard_failed),
                "prompt_tokens": r.prompt_tokens or 0,
                "completion_tokens": r.completion_tokens or 0,
                "cost_usd": r.cost_usd or 0.0,
            }
            for r in scenario_results
        ],
    }


@app.post("/api/scenarios")
async def create_scenario(
    req: ScenarioCreate,
) -> dict[str, Any]:
    scenario_id = re.sub(r"[^a-z0-9]+", "-", req.name.lower()).strip("-")

    actions = req.expected_actions or [
        {"action": "complete_task", "required": True,
         "description": "Agent completes the task correctly"}
    ]

    scenario_data = {
        "id": scenario_id,
        "name": req.name,
        "description": req.description,
        "agent_type": req.agent_type,
        "prompt": req.prompt,
        "test_input": req.test_input,
        "expected_actions": actions,
        "tags": req.tags,
    }

    scen_dir = _validate_path(req.scenarios_dir)
    scen_dir.mkdir(parents=True, exist_ok=True)

    path = scen_dir / f"{scenario_id}.yml"
    if path.exists():
        raise HTTPException(
            status_code=409, detail=f"Scenario with id '{scenario_id}' already exists"
        )
    with open(path, "w") as f:
        yaml.dump(scenario_data, f, default_flow_style=False, allow_unicode=True, sort_keys=False)

    return {
        "id": scenario_id,
        "name": req.name,
        "description": req.description,
        "agent_type": req.agent_type,
        "tags": req.tags,
        "step_count": len(actions),
    }


@app.get("/api/scenarios")
async def list_scenarios(scenarios_dir: str = "") -> list[dict[str, Any]]:
    scen_dir = _validate_path(scenarios_dir)
    if not scen_dir.exists():
        return []
    loader = ScenarioLoader()
    result = []
    for path in sorted(scen_dir.rglob("*.yml")) + sorted(scen_dir.rglob("*.yaml")):
        if path.name.startswith("_"):
            continue
        try:
            s = loader.load_file(path)
            rel = path.relative_to(scen_dir)
            suite = rel.parts[0] if len(rel.parts) > 1 else "default"
            result.append({
                "id": s.id,
                "name": s.name,
                "description": s.description,
                "agent_type": s.agent_type.value,
                "tags": s.tags,
                "step_count": len(s.expected_actions),
                "suite": suite,
            })
        except Exception as e:
            logger.warning("Failed to load scenario %s: %s", path, e)
    return result


@app.get("/api/runs/compare")
async def compare_runs(
    base: str,
    head: str,
    db: AsyncSession = Depends(get_db),
) -> dict[str, Any]:
    """Diff two runs at scenario level. Returns per-scenario verdicts and a summary."""
    base_rows = await db.execute(
        select(ScenarioResultRecord).where(ScenarioResultRecord.run_id == base)
    )
    head_rows = await db.execute(
        select(ScenarioResultRecord).where(ScenarioResultRecord.run_id == head)
    )
    base_results = {r.scenario_id: r for r in base_rows.scalars().all()}
    head_results = {r.scenario_id: r for r in head_rows.scalars().all()}

    if not base_results and not head_results:
        raise HTTPException(status_code=404, detail="No scenario results found for one or both runs")

    # Fetch run metadata for timestamps
    base_run_row = await db.execute(select(RunRecord).where(RunRecord.run_id == base))
    head_run_row = await db.execute(select(RunRecord).where(RunRecord.run_id == head))
    base_run = base_run_row.scalar_one_or_none()
    head_run = head_run_row.scalar_one_or_none()

    all_ids = set(base_results) | set(head_results)
    scenarios = []
    for sid in all_ids:
        b = base_results.get(sid)
        h = head_results.get(sid)
        b_status = b.status if b else None
        h_status = h.status if h else None
        b_score = b.overall_score if b else None
        h_score = h.overall_score if h else None
        delta = (h_score - b_score) if (h_score is not None and b_score is not None) else None

        if b is None:
            verdict = "new"
        elif h is None:
            verdict = "removed"
        elif b_status == "pass" and h_status != "pass":
            verdict = "new_fail"
        elif b_status != "pass" and h_status == "pass":
            verdict = "resolved"
        elif b_status == "pass" and h_status == "pass":
            verdict = "regressed" if (delta is not None and delta < -0.15) else "stable_pass"
        else:
            verdict = "stable_fail"

        scenarios.append({
            "scenario_id": sid,
            "scenario_name": (h or b).scenario_name,  # type: ignore[union-attr]
            "base_status": b_status,
            "head_status": h_status,
            "base_score": b_score,
            "head_score": h_score,
            "score_delta": delta,
            "verdict": verdict,
        })

    _verdict_order = {"new_fail": 0, "stable_fail": 1, "regressed": 2, "resolved": 3, "stable_pass": 4, "new": 5, "removed": 6}
    scenarios.sort(key=lambda s: (_verdict_order.get(s["verdict"], 9), s["scenario_name"]))

    summary = {
        "new_failures": sum(1 for s in scenarios if s["verdict"] == "new_fail"),
        "resolved": sum(1 for s in scenarios if s["verdict"] == "resolved"),
        "regressions": sum(1 for s in scenarios if s["verdict"] == "regressed"),
        "stable_pass": sum(1 for s in scenarios if s["verdict"] == "stable_pass"),
        "stable_fail": sum(1 for s in scenarios if s["verdict"] == "stable_fail"),
        "new_scenarios": sum(1 for s in scenarios if s["verdict"] == "new"),
        "removed_scenarios": sum(1 for s in scenarios if s["verdict"] == "removed"),
    }

    return {
        "base_run_id": base,
        "head_run_id": head,
        "base_started_at": _iso(base_run.started_at) if base_run else None,
        "head_started_at": _iso(head_run.started_at) if head_run else None,
        "summary": summary,
        "scenarios": scenarios,
    }


@app.get("/api/suites")
async def list_suites(db: AsyncSession = Depends(get_db)) -> list[dict[str, Any]]:
    """Return distinct benchmark suites with latest run status."""
    from sqlalchemy import func

    rows = await db.execute(
        select(
            SuiteResultRecord.suite_id,
            SuiteResultRecord.suite_name,
            func.count(SuiteResultRecord.id).label("run_count"),
            func.max(SuiteResultRecord.created_at).label("latest_run"),
        )
        .group_by(SuiteResultRecord.suite_id, SuiteResultRecord.suite_name)
        .order_by(func.max(SuiteResultRecord.created_at).desc())
    )
    result = []
    for suite_id, suite_name, run_count, latest_run in rows.all():
        latest_row = await db.execute(
            select(SuiteResultRecord.passed)
            .where(SuiteResultRecord.suite_id == suite_id)
            .order_by(SuiteResultRecord.created_at.desc())
            .limit(1)
        )
        latest_passed = latest_row.scalar_one_or_none()
        result.append({
            "suite_id": suite_id,
            "suite_name": suite_name,
            "run_count": run_count,
            "latest_run": _iso(latest_run),
            "latest_passed": bool(latest_passed) if latest_passed is not None else None,
        })
    return result


@app.get("/api/suites/{suite_id}/history")
async def suite_history(suite_id: str, db: AsyncSession = Depends(get_db)) -> list[dict[str, Any]]:
    """Return benchmark history for a suite — all runs, ordered newest first."""
    rows = await db.execute(
        select(SuiteResultRecord)
        .where(SuiteResultRecord.suite_id == suite_id)
        .order_by(SuiteResultRecord.created_at.desc())
        .limit(200)
    )
    records = rows.scalars().all()
    return [
        {
            "run_id": r.run_id,
            "suite_id": r.suite_id,
            "suite_name": r.suite_name,
            "suite_version": r.suite_version,
            "pass_threshold": r.pass_threshold,
            "total": r.total,
            "semantic_pass_rate": r.semantic_pass_rate,
            "hard_fail_rate": r.hard_fail_rate,
            "soft_fail_rate": r.soft_fail_rate,
            "error_rate": r.error_rate,
            "weighted_score": r.weighted_score,
            "passed": bool(r.passed),
            "created_at": _iso(r.created_at),
        }
        for r in records
    ]


# ── Background task ────────────────────────────────────────────────────────────

async def _mark_run_failed(run_id: str, error_message: str) -> None:
    from .database import SessionLocal
    async with SessionLocal() as db:
        row = await db.execute(select(RunRecord).where(RunRecord.run_id == run_id))
        record = row.scalar_one_or_none()
        if record:
            record.finished_at = datetime.now(UTC)
            record.total = 0
            record.passed = 0
            record.pass_rate = 0.0
            record.results = [{"error": error_message}]
            await db.commit()


async def _execute_run(run_id: str, req: RunRequest) -> None:
    from .database import SessionLocal

    config = EvalConfig()
    if req.judge_model:
        config.model = req.judge_model
        config.judge.model = req.judge_model
    if req.api_key:
        config.judge.api_key = req.api_key
    loader = ScenarioLoader()
    scen_dir = (SCENARIOS_BASE_DIR.resolve() / req.scenarios_dir).resolve()

    if not scen_dir.exists():
        await _mark_run_failed(run_id, f"Scenarios directory not found: {scen_dir}")
        return

    async def _run_with_timeout() -> None:
        scenarios = loader.load_dir(scen_dir)

        if loader.skipped:
            async with SessionLocal() as db:
                row = await db.execute(select(RunRecord).where(RunRecord.run_id == run_id))
                record = row.scalar_one_or_none()
                if record:
                    record.skipped_scenarios = loader.skipped
                    await db.commit()

        if req.tags:
            scenarios = [s for s in scenarios if any(t in s.tags for t in req.tags)]
        if req.scenario_ids:
            scenarios = [s for s in scenarios if s.id in req.scenario_ids]

        if req.mock:
            from evalgrid.core.scorer import MockScorer
            runner = ScenarioRunner(
                config,
                scorer=MockScorer(),
                agent_fn=lambda s: ("[mock agent output]", 0),
                mock=True,
            )
        else:
            runner = ScenarioRunner(config)

        loop = asyncio.get_running_loop()
        results = []
        for scenario in scenarios:
            result = await loop.run_in_executor(None, runner.run_scenario, scenario)
            results.append(result)

            async with SessionLocal() as db:
                sr = ScenarioResultRecord(
                    run_id=run_id,
                    scenario_id=result.scenario_id,
                    scenario_name=result.scenario_name,
                    agent_type=result.agent_type.value,
                    status=result.status.value,
                    overall_score=result.overall_score,
                    pass_rate=result.pass_rate,
                    reasoning=result.reasoning,
                    error=result.error,
                    steps=[s.model_dump(mode="json") for s in result.steps],
                    check_results=[c.model_dump(mode="json") for c in result.check_results],
                    hard_failed=result.hard_failed,
                    prompt_tokens=result.prompt_tokens,
                    completion_tokens=result.completion_tokens,
                    cost_usd=result.cost_usd,
                    started_at=result.started_at,
                    finished_at=result.finished_at,
                )
                db.add(sr)
                await db.commit()

        passed = sum(1 for r in results if r.status == PassFail.PASS)
        total = len(results)

        async with SessionLocal() as db:
            row = await db.execute(select(RunRecord).where(RunRecord.run_id == run_id))
            record = row.scalar_one_or_none()
            if record:
                record.finished_at = datetime.now(UTC)
                record.passed = passed
                record.total = total
                record.pass_rate = passed / total if total else 0.0
                await db.commit()

    try:
        await asyncio.wait_for(_run_with_timeout(), timeout=1800)
    except TimeoutError:
        logger.error("Run %s timed out after 1800s", run_id)
        await _mark_run_failed(run_id, "Run timed out (30 minute limit exceeded)")
    except Exception as exc:
        await _mark_run_failed(run_id, _sanitize_error(str(exc)))


# Serve React dashboard — EVALGRID_DASHBOARD_DIR (override) or evalgrid/static/ (wheel) or dashboard/dist/ (dev)
_dashboard_override = os.environ.get("EVALGRID_DASHBOARD_DIR")
if _dashboard_override:
    _dashboard = Path(_dashboard_override)
else:
    _dashboard = Path(__file__).parent.parent / "static"
    if not _dashboard.exists():
        _dashboard = Path(__file__).parent.parent.parent / "dashboard" / "dist"
if _dashboard.exists():
    app.mount("/", StaticFiles(directory=_dashboard, html=True), name="static")
