"""Shared filesystem path helpers — single source of truth for default paths."""

from __future__ import annotations

import logging
import os
from pathlib import Path

logger = logging.getLogger("evalgrid")

_VALID_DB_PREFIXES = ("sqlite+aiosqlite://",)


def default_database_url() -> str:
    """Return the canonical async SQLite URL, honoring DATABASE_URL env var."""
    env = os.environ.get("DATABASE_URL")
    if env:
        if not any(env.startswith(prefix) for prefix in _VALID_DB_PREFIXES):
            logger.warning(
                "DATABASE_URL '%s...' does not start with a supported prefix %s. "
                "Only sqlite+aiosqlite:// is validated; other backends may not work correctly.",
                env[:30],
                _VALID_DB_PREFIXES,
            )
        return env
    db_path = (Path.home() / ".evalgrid" / "results.db").as_posix()
    return f"sqlite+aiosqlite:///{db_path}"
