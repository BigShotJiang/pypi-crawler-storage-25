"""Tests for ScenarioRunner using mocks."""

import pytest

from evalgrid.core.models import AgentType, EvalConfig, ExpectedAction, PassFail, Scenario
from evalgrid.core.runner import ScenarioRunner
from evalgrid.core.scorer import MockScorer


@pytest.fixture
def config():
    return EvalConfig()


@pytest.fixture
def sample_scenario():
    return Scenario(
        id="runner-test",
        name="Runner Test",
        agent_type=AgentType.CODING,
        prompt="You are a coding assistant.",
        test_input="Write a hello world in Python.",
        expected_actions=[
            ExpectedAction(action="write_code", required=True),
        ],
    )


def _mock_runner(config: EvalConfig, output: str = 'print("Hello, World!")') -> ScenarioRunner:
    return ScenarioRunner(
        config,
        scorer=MockScorer(),
        agent_fn=lambda s: (output, 42),
    )


def test_run_scenario_with_mock(config, sample_scenario):
    runner = _mock_runner(config)
    result = runner.run_scenario(sample_scenario)
    assert result.status == PassFail.PASS
    assert result.scenario_id == "runner-test"


def test_run_scenario_handles_agent_error(config, sample_scenario):
    def failing_agent(s):
        raise RuntimeError("API error")

    runner = ScenarioRunner(config, scorer=MockScorer(), agent_fn=failing_agent)
    result = runner.run_scenario(sample_scenario)
    assert result.status == PassFail.ERROR
    assert result.error is not None
    assert "API error" in result.error


def test_run_all_collects_results(config):
    scenarios = [
        Scenario(id=f"s{i}", name=f"S{i}", prompt="p", test_input="i")
        for i in range(3)
    ]
    runner = _mock_runner(config, "response")
    results = runner.run_all(scenarios)
    assert len(results) == 3


def test_run_all_calls_on_result_callback(config):
    scenarios = [
        Scenario(id=f"s{i}", name=f"S{i}", prompt="p", test_input="i")
        for i in range(2)
    ]
    runner = _mock_runner(config, "response")
    callback_results = []
    runner.run_all(scenarios, on_result=callback_results.append)
    assert len(callback_results) == 2


# ── API background task ───────────────────────────────────────────────────────

import uuid  # noqa: E402
from datetime import UTC, datetime  # noqa: E402

from sqlalchemy import select  # noqa: E402

from evalgrid.api.database import RunRecord  # noqa: E402


@pytest.mark.asyncio
async def test_runner_marks_run_failed_on_missing_dir(tmp_path, test_db, monkeypatch):
    import evalgrid.api.app as app_module
    import evalgrid.api.database as db_module

    monkeypatch.setattr(db_module, "SessionLocal", test_db)
    monkeypatch.setattr(app_module, "SCENARIOS_BASE_DIR", tmp_path / "scenarios")

    from evalgrid.api.app import RunRequest, _execute_run

    run_id = str(uuid.uuid4())
    async with test_db() as db:
        db.add(RunRecord(run_id=run_id, started_at=datetime.now(UTC), results=[]))
        await db.commit()

    await _execute_run(run_id, RunRequest(scenarios_dir="nonexistent", mock=True))

    async with test_db() as db:
        row = await db.execute(select(RunRecord).where(RunRecord.run_id == run_id))
        record = row.scalar_one()

    assert record.finished_at is not None
    assert record.results and record.results[0].get("error")
