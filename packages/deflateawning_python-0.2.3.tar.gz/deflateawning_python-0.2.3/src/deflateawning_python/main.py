"""`dapython` main."""

import ast
import dataclasses
import io
import math
import random
import re
import string
import sys
import time
import typing
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, date, datetime, timedelta
from pathlib import Path
from random import randint
from types import ModuleType
from typing import Any

import bs4
import IPython
import numpy as np
import orjson
import pandas as pd
import pint
import polars as pl
import pydash
import requests
import satkit
import sympy
import sympy.physics.units
import sympy.physics.units.definitions
from bs4 import BeautifulSoup
from loguru import logger
from pygments import highlight
from pygments.formatters import TerminalTrueColorFormatter
from pygments.lexers import PythonLexer
from sympy import Eq, init_session, solve, symbols
from sympy.physics.units import convert_to
from sympy.physics.units.systems import SI
from sympy.physics.units.util import quantity_simplify

from deflateawning_python.sympy_addons import sympy_solve

# Init the "pint" unit registry for unit-of-measurement support.
ureg = pint.UnitRegistry()

# Another math example: https://discuss.python.org/t/algebraic-manipulation-in-python/105392/6


def dapython_code() -> None:
    """Print the code for this package, showing the imports."""
    self_python = Path(__file__).read_text()

    print(
        highlight(
            self_python, PythonLexer(), TerminalTrueColorFormatter(style="monokai")
        )
    )


def dapython_main() -> None:
    """Run `dapython` interactive."""
    user_ns = pydash.omit(globals(), "dapython_main")

    # For info, count what we're importing.
    fn_name_list = [
        fn_name for fn_name, fn_def in user_ns.items() if isinstance(fn_def, Callable)
    ]
    module_name_list = [
        obj_name
        for obj_name, obj_inst in user_ns.items()
        if isinstance(obj_inst, ModuleType)
    ]
    fn_count = len(fn_name_list)
    var_count = len(set(user_ns.keys()) - set(fn_name_list) - set(module_name_list))

    logger.info(
        f"Starting IPython with {fn_count} functions/classes, "
        f"{len(module_name_list)} modules and {var_count} variables "
        "ready-to-use."
    )

    # Init Sympy session.
    logger.debug("""Helpful commands:

        - init_session()       # Init sympy.
        - dapython_code()      # Print out this file to see available imports.
    """)

    IPython.start_ipython(
        argv=sys.argv[1:],  # Pass CLI arguments directly through to IPython.
        user_ns=user_ns,
    )


# Math example (basic units):
"""
from sympy.physics.units import *
result = 3.2e9 * hertz * 6.3 * meter
simplify(convert_to(result, [meter / second]))
"""

# Math example (solving equations with units):
"""
V = symbols('V', positive=True)

equation = Eq((100*watts), V**2 / (50* ohms))
sympy_solve(equation, V)
"""


if __name__ == "__main__":
    dapython_main()
