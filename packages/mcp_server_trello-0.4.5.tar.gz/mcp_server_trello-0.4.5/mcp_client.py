#!/usr/bin/env python3
"""Console entrypoint for the Trello MCP server."""

from trello_mcp.tools import main, mcp


__all__ = ["main", "mcp"]


if __name__ == "__main__":
    main()
