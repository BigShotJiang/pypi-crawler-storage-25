"""Per-tool input specs and validator. Pure functions, no I/O."""

from __future__ import annotations

from typing import Any, ClassVar


class InputSpec:
    """Base class. Subclasses declare canonical/aliases/required/mutable_fields as class vars."""

    canonical: ClassVar[tuple[str, ...]] = ()
    aliases: ClassVar[dict[str, str]] = {}
    required: ClassVar[tuple[str, ...]] = ()
    # Optional: subset of canonical fields whose presence counts as "a change".
    # When empty, all canonical fields count toward `applied`.
    mutable_fields: ClassVar[tuple[str, ...]] = ()

    @classmethod
    def extra_validate(cls, clean: dict[str, Any]) -> list[str]:
        """Return list of extra missing-field names. Override per spec."""
        return []


def validate(
    spec_cls: type[InputSpec],
    raw: dict[str, Any],
) -> tuple[dict[str, Any] | None, dict[str, Any]]:
    """Validate raw input against a spec. Returns (clean | None, report).

    Decision rules (per spec §5.3):
    - missing required -> clean=None, report.missing populated.
    - applied empty    -> clean=None (caller should emit no_changes_requested).
    - alias collision  -> canonical wins, alias goes to ignored.
    - unknown field    -> ignored with reason=unknown_field, non-blocking.
    """
    canonical_set = set(spec_cls.canonical)
    aliases = spec_cls.aliases
    required_set = set(spec_cls.required)

    clean: dict[str, Any] = {}
    aliased: dict[str, str] = {}
    ignored: list[dict[str, str]] = []

    # Two-pass validation. Order-independent.
    # Pass 1: canonical fields win unconditionally.
    for key, value in raw.items():
        if key in canonical_set:
            clean[key] = value

    # Pass 2: aliases fill in canonical targets that were not set in pass 1.
    # Aliases for already-set canonicals collide.
    for key, value in raw.items():
        if key in canonical_set:
            continue
        if key in aliases:
            target = aliases[key]
            if target in clean:
                ignored.append({"field": key, "reason": "alias_collision"})
            else:
                clean[target] = value
                aliased[key] = target
        else:
            ignored.append({"field": key, "reason": "unknown_field"})

    def _is_set(v: Any) -> bool:
        # None, "", [], {} count as not-set. False/0 count as set.
        if v is None:
            return False
        if isinstance(v, (list, dict, str)) and len(v) == 0:
            return False
        return True

    if spec_cls.mutable_fields:
        applied = sorted(k for k, v in clean.items() if k in spec_cls.mutable_fields and _is_set(v))
    else:
        applied = sorted(k for k, v in clean.items() if _is_set(v))
    missing = sorted(k for k in required_set if not _is_set(clean.get(k)))

    extra_missing = spec_cls.extra_validate(clean)
    missing = sorted(set(missing) | set(extra_missing))

    report = {
        "applied": applied,
        "aliased": aliased,
        "ignored": ignored,
        "missing": missing,
    }

    if missing:
        return None, report
    if not applied:
        return None, report
    return clean, report


class MoveCardSpec(InputSpec):
    canonical = ("card", "to_list", "pos")
    aliases = {
        "list": "to_list",
        "target_list": "to_list",
        "destination": "to_list",
        "move_to": "to_list",
        "list_name": "to_list",
        "target": "to_list",
    }
    required = ("card", "to_list")


class UpdateCardSpec(InputSpec):
    canonical = (
        "card", "name", "desc", "due", "due_complete",
        "closed", "pos", "id_list", "id_members",
    )
    aliases = {
        "description": "desc",
        "title": "name",
        "archived": "closed",
        "archive": "closed",
        "is_closed": "closed",
        "due_date": "due",
        "dueComplete": "due_complete",
        "idList": "id_list",
        "idMembers": "id_members",
    }
    required = ("card",)
    mutable_fields = (
        "name", "desc", "due", "due_complete",
        "closed", "pos", "id_list", "id_members",
    )


class LabelCardOp(InputSpec):
    canonical = ("card_refs", "query", "add", "remove")
    aliases = {
        "labels": "add",
        "add_labels": "add",
        "remove_labels": "remove",
        "label": "add",
    }
    required = ()
    mutable_fields = ("add", "remove")

    @classmethod
    def extra_validate(cls, clean):
        if not (clean.get("card_refs") or clean.get("query")):
            return ["card_refs"]
        return []


class CreateCardSpec(InputSpec):
    canonical = ("name", "desc", "due", "pos", "labels")
    aliases = {"description": "desc", "title": "name"}
    required = ("name",)
