"""Guarded raw Trello tool helpers."""

from __future__ import annotations

from typing import Any

from .models import envelope, error
from .trello_client import TrelloAPIError, TrelloClient


def trello_get(
    endpoint: str,
    params: dict[str, Any] | None = None,
    compact: bool = True,
    client: TrelloClient | None = None,
) -> dict[str, Any]:
    """Run a guarded raw Trello GET request."""
    return _raw_tool(
        "trello_get",
        endpoint,
        method="GET",
        params=params,
        compact=compact,
        client=client,
    )


def trello_post(
    endpoint: str,
    data: dict[str, Any] | None = None,
    compact: bool = True,
    client: TrelloClient | None = None,
) -> dict[str, Any]:
    """Run a guarded raw Trello POST request."""
    return _raw_tool(
        "trello_post",
        endpoint,
        method="POST",
        data=data,
        compact=compact,
        client=client,
    )


def trello_put(
    endpoint: str,
    data: dict[str, Any] | None = None,
    compact: bool = True,
    client: TrelloClient | None = None,
) -> dict[str, Any]:
    """Run a guarded raw Trello PUT request."""
    return _raw_tool(
        "trello_put",
        endpoint,
        method="PUT",
        data=data,
        compact=compact,
        client=client,
    )


def trello_delete(
    endpoint: str,
    data: dict[str, Any] | None = None,
    confirm: bool = False,
    client: TrelloClient | None = None,
) -> dict[str, Any]:
    """Run a guarded raw Trello DELETE request."""
    return _raw_tool(
        "trello_delete",
        endpoint,
        method="DELETE",
        data=data,
        compact=False,
        confirm=confirm,
        client=client,
    )


def _raw_tool(
    tool: str,
    endpoint: str,
    method: str,
    data: dict[str, Any] | None = None,
    params: dict[str, Any] | None = None,
    compact: bool = True,
    confirm: bool = False,
    client: TrelloClient | None = None,
) -> dict[str, Any]:
    trello = client or TrelloClient()
    try:
        response = trello.raw_request(
            endpoint,
            method=method,
            data=data,
            params=params,
            compact=compact,
            confirm=confirm,
        )
    except TrelloAPIError as exc:
        return envelope(
            tool,
            errors=[
                error(
                    exc.code,
                    exc.message,
                    input_ref=endpoint,
                    retryable=exc.retryable,
                )
            ],
        )
    result_key = "compact" if compact else "raw"
    return envelope(tool, result={result_key: response})
