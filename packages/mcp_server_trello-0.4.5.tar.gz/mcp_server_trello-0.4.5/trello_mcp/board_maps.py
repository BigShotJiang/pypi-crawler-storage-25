"""Board map persistence and inference helpers."""

from __future__ import annotations

import json
import os
import re
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .models import warning


SCHEMA_VERSION = 1
BOARD_ID_PATTERN = re.compile(r"[A-Za-z0-9]+")


def board_map_dir() -> Path:
    """Return the configured board-map storage directory."""
    override = os.getenv("TRELLO_MCP_BOARD_MAP_DIR")
    if override:
        return Path(override).expanduser()
    return Path.home() / ".config" / "mcp-server-trello" / "boards"


def board_map_path(board_id: str) -> Path:
    """Return the board-map path for a Trello board ID."""
    if not BOARD_ID_PATTERN.fullmatch(board_id):
        raise ValueError("board_id must contain only letters and numbers")
    return board_map_dir() / f"{board_id}.json"


def normalize_alias(name: str) -> str:
    """Normalize a Trello name into a stable board-local alias."""
    return re.sub(r"[^a-z0-9]+", "_", name.strip().lower()).strip("_")


def infer_board_map(
    board: dict[str, Any],
    lists: list[dict[str, Any]],
    labels: list[dict[str, Any]],
    existing: dict[str, Any] | None = None,
) -> tuple[dict[str, Any], str, list[dict[str, Any]]]:
    """Infer or merge a board map from compact Trello board metadata."""
    warnings: list[dict[str, Any]] = []
    status = "auto_saved"
    existing = existing if _is_supported_map(existing) else None

    list_entries, list_conflicts = _entries_from_objects(lists, "list", existing)
    label_entries, label_conflicts = _entries_from_objects(labels, "label", existing)
    if list_conflicts or label_conflicts:
        status = "inferred_unsaved"
        warnings.append(
            warning(
                "using_inferred_unsaved_map",
                "Generated aliases are not unique; inferred map was not saved",
            )
        )

    if existing:
        stale_warnings, rename_warnings = _merge_existing_state(
            existing, list_entries, label_entries
        )
        if stale_warnings:
            status = "stale"
            warnings.extend(stale_warnings)
        warnings.extend(rename_warnings)

    board_map = {
        "schema_version": SCHEMA_VERSION,
        "board": {
            "id": board.get("id"),
            "name": board.get("name"),
            "url": board.get("url") or board.get("shortUrl"),
            "last_seen_at": _utc_now(),
        },
        "lists": list_entries,
        "labels": label_entries,
        "inference": {
            "source": "auto",
            "confidence": "high" if status == "auto_saved" else "medium",
            "saved_by": "open_board",
            "saved_at": _utc_now(),
        },
    }
    return board_map, status, warnings


def load_board_map(board_id: str) -> tuple[dict[str, Any] | None, list[dict[str, Any]]]:
    """Load a stored board map, returning warnings for corrupt data."""
    path = board_map_path(board_id)
    if not path.exists():
        return None, []
    try:
        loaded = json.loads(path.read_text())
    except (OSError, json.JSONDecodeError):
        return None, [
            warning("board_map_corrupt", "Stored board map is not valid JSON", board_id)
        ]
    if not _is_supported_map(loaded):
        return None, [
            warning("board_map_corrupt", "Stored board map schema is unsupported", board_id)
        ]
    return loaded, []


def save_board_map(board_map: dict[str, Any]) -> None:
    """Atomically write a board map to disk."""
    board_id = board_map["board"]["id"]
    path = board_map_path(board_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(
        prefix=f".{board_id}.", suffix=".tmp", dir=str(path.parent), text=True
    )
    try:
        with os.fdopen(fd, "w") as tmp:
            json.dump(board_map, tmp, indent=2, sort_keys=True)
            tmp.write("\n")
        os.replace(tmp_name, path)
    except Exception:
        try:
            os.unlink(tmp_name)
        except FileNotFoundError:
            pass
        raise


def refresh_board_map(
    board: dict[str, Any],
    lists: list[dict[str, Any]],
    labels: list[dict[str, Any]],
    auto_save: bool = True,
) -> tuple[dict[str, Any], str, list[dict[str, Any]]]:
    """Load, refresh, and optionally save a board map."""
    existing, load_warnings = load_board_map(board["id"])
    board_map, status, infer_warnings = infer_board_map(board, lists, labels, existing)
    warnings = load_warnings + infer_warnings
    if load_warnings and not existing:
        status = "inferred_unsaved"
    if auto_save and status == "auto_saved":
        save_board_map(board_map)
    return board_map, status, warnings


def _entries_from_objects(
    objects: list[dict[str, Any]],
    kind: str,
    existing: dict[str, Any] | None,
) -> tuple[list[dict[str, Any]], bool]:
    aliases_by_id = _aliases_by_id(existing, f"{kind}s")
    entries: list[dict[str, Any]] = []
    generated: list[str] = []
    for obj in objects:
        alias = normalize_alias(obj.get("name", ""))
        aliases = aliases_by_id.get(obj.get("id"), [alias] if alias else [])
        entry = {
            "id": obj.get("id"),
            "name": obj.get("name"),
            "aliases": aliases,
        }
        if kind == "list":
            entry["closed"] = obj.get("closed", False)
            entry["pos"] = obj.get("pos")
        else:
            entry["color"] = obj.get("color")
        entries.append(entry)
        if alias:
            generated.append(alias)
    return entries, len(generated) != len(set(generated))


def _aliases_by_id(
    existing: dict[str, Any] | None, collection_name: str
) -> dict[str, list[str]]:
    if not existing:
        return {}
    return {
        entry.get("id"): list(entry.get("aliases", []))
        for entry in existing.get(collection_name, [])
    }


def _merge_existing_state(
    existing: dict[str, Any],
    list_entries: list[dict[str, Any]],
    label_entries: list[dict[str, Any]],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    stale_warnings: list[dict[str, Any]] = []
    rename_warnings: list[dict[str, Any]] = []
    for collection_name, current_entries in (
        ("lists", list_entries),
        ("labels", label_entries),
    ):
        current_by_id = {entry["id"]: entry for entry in current_entries}
        for stored in existing.get(collection_name, []):
            stored_id = stored.get("id")
            current = current_by_id.get(stored_id)
            if current is None:
                stale_warnings.append(
                    warning(
                        "board_map_stale_object",
                        f"Stored {collection_name[:-1]} no longer exists",
                        stored.get("name") or stored_id,
                    )
                )
                continue
            if current.get("name") != stored.get("name"):
                current["aliases"] = list(stored.get("aliases", []))
                rename_warnings.append(
                    warning(
                        "board_map_name_changed",
                        f"{collection_name[:-1].title()} name changed from {stored.get('name')} to {current.get('name')}",
                        stored.get("name"),
                    )
                )
    return stale_warnings, rename_warnings


def _is_supported_map(board_map: dict[str, Any] | None) -> bool:
    return bool(board_map and board_map.get("schema_version") == SCHEMA_VERSION)


def _utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
