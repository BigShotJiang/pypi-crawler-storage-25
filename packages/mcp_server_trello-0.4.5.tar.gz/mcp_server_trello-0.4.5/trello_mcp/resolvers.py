"""Reference resolution helpers for Trello objects."""

from __future__ import annotations

import re
from typing import Any

from .models import error


def resolve_one(
    candidates: list[dict[str, Any]], ref: str, kind: str
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    """Resolve one object by ID, exact name, or unique partial name."""
    return _resolve(candidates, ref, kind)


def resolve_board(
    ref: str, boards: list[dict[str, Any]]
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    """Resolve a board by ID, URL, exact name, or unique partial name."""
    return _resolve(boards, ref, "board", allow_url=True)


def resolve_list(
    ref: str,
    lists: list[dict[str, Any]],
    board_map: dict[str, Any] | None = None,
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    """Resolve a list by ID, exact name, board-map alias, or partial name."""
    return _resolve(lists, ref, "list", board_map=board_map, map_collection="lists")


def resolve_label(
    ref: str,
    labels: list[dict[str, Any]],
    board_map: dict[str, Any] | None = None,
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    """Resolve a label by ID, exact name, board-map alias, or partial name."""
    return _resolve(labels, ref, "label", board_map=board_map, map_collection="labels")


def resolve_card(
    ref: str, cards: list[dict[str, Any]]
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    """Resolve a card by ID, URL, exact name, or unique partial name."""
    return _resolve(cards, ref, "card", allow_url=True)


def _resolve(
    candidates: list[dict[str, Any]],
    ref: str,
    kind: str,
    allow_url: bool = False,
    board_map: dict[str, Any] | None = None,
    map_collection: str | None = None,
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    ref_text = str(ref).strip()
    if not ref_text:
        return None, error("not_found", f"No {kind} matched empty reference", ref)

    id_matches = [item for item in candidates if item.get("id") == ref_text]
    if id_matches:
        return _single_or_ambiguous(id_matches, ref_text, kind)

    if allow_url:
        url_matches = [
            item
            for item in candidates
            if ref_text in {item.get("url"), item.get("shortUrl"), item.get("short_url")}
        ]
        if url_matches:
            return _single_or_ambiguous(url_matches, ref_text, kind)

    # 8-char base62 shortLinks: Trello uses them for both cards and boards
    # (e.g. "RIQCFJBW" for a card, "TJYrvblV" for a board).
    if kind in ("card", "board") and len(ref_text) == 8 and ref_text.isalnum():
        short_matches = [
            item
            for item in candidates
            if item.get("shortLink") == ref_text
        ]
        if short_matches:
            return _single_or_ambiguous(short_matches, ref_text, kind)

    ref_lower = ref_text.lower()
    exact_matches = [
        item for item in candidates if str(item.get("name", "")).lower() == ref_lower
    ]
    if exact_matches:
        return _single_or_ambiguous(exact_matches, ref_text, kind)

    if board_map and map_collection:
        alias_matches = _alias_matches(ref_lower, candidates, board_map, map_collection)
        if alias_matches:
            return _single_or_ambiguous(alias_matches, ref_text, kind)

    partial_matches = [
        item
        for item in candidates
        if ref_lower in str(item.get("name", "")).lower()
    ]
    if partial_matches:
        return _single_or_ambiguous(partial_matches, ref_text, kind)

    return None, error("not_found", f"No {kind} matched '{ref_text}'", ref_text)


def _alias_matches(
    ref_lower: str,
    candidates: list[dict[str, Any]],
    board_map: dict[str, Any],
    collection_name: str,
) -> list[dict[str, Any]]:
    candidate_by_id = {item.get("id"): item for item in candidates}
    matches = []
    for entry in board_map.get(collection_name, []):
        aliases = [str(alias).lower() for alias in entry.get("aliases", [])]
        if ref_lower in aliases and entry.get("id") in candidate_by_id:
            matches.append(candidate_by_id[entry["id"]])
    return matches


def _single_or_ambiguous(
    matches: list[dict[str, Any]], ref: str, kind: str
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    if len(matches) == 1:
        return matches[0], None
    return None, error(
        "ambiguous_ref",
        f"Multiple {kind}s matched '{ref}'",
        input_ref=ref,
        candidates=[_candidate(item) for item in matches],
    )


def _candidate(item: dict[str, Any]) -> dict[str, Any]:
    return {
        key: value
        for key, value in {
            "id": item.get("id"),
            "name": item.get("name"),
            "url": item.get("url") or item.get("shortUrl"),
        }.items()
        if value is not None
    }


_HEX24 = re.compile(r"^[0-9a-fA-F]{24}$")
_SHORTLINK = re.compile(r"^[A-Za-z0-9]{8}$")
_CARD_URL = re.compile(r"^https?://trello\.com/c/[A-Za-z0-9]+", re.IGNORECASE)
_BOARD_URL = re.compile(r"^https?://trello\.com/b/[A-Za-z0-9]+", re.IGNORECASE)


def classify_ref(ref: str) -> str:
    """Classify a reference string. Pure, no I/O.

    Returns one of: card_id, card_short_link, card_url, board_url, unknown.

    Note: a 24-char hex string can be either a Trello card ID or board ID;
    classify_ref returns "card_id" for any 24-char hex because the only
    consumer in this milestone is open_board, which calls classify_ref
    after a board lookup has already failed. Disambiguating card vs board
    IDs requires an API lookup (out of scope for a pure helper).
    Spec §8.2's broader enum (board_id, board_name, list_alias) is not
    implementable from shape alone; the spec is narrowed to this
    contract for v0.3.0.
    """
    text = (ref or "").strip()
    if not text:
        return "unknown"
    if _HEX24.match(text):
        return "card_id"
    if _CARD_URL.match(text):
        return "card_url"
    if _BOARD_URL.match(text):
        return "board_url"
    if _SHORTLINK.match(text):
        return "card_short_link"
    return "unknown"
