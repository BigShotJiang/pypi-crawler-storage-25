"""Shared context and resolution helpers for grouped Trello tools."""

from __future__ import annotations

import re
from typing import Any
from urllib.parse import urlsplit

from .board_maps import refresh_board_map
from .models import envelope, error
from .resolvers import resolve_board
from .trello_client import TrelloAPIError, TrelloClient


def open_board_data(name_or_id: str, trello: TrelloClient) -> dict[str, Any]:
    """Open a board and load compact board context."""
    boards = _candidate_boards(name_or_id, trello)
    board, err = resolve_board(name_or_id, boards)
    if err:
        return {"error": err}
    lists = trello.request(f"/boards/{board['id']}/lists")
    labels = trello.request(f"/boards/{board['id']}/labels")
    board_map, status, warnings = refresh_board_map(board, lists, labels)
    return {
        "board": board,
        "lists": lists,
        "labels": labels,
        "board_map": board_map,
        "board_map_status": status,
        "warnings": warnings,
    }


def board_cards(trello: TrelloClient, board_id: str) -> list[dict[str, Any]]:
    """Fetch open cards for a board."""
    return trello.request(f"/boards/{board_id}/cards", params={"filter": "open"})


def resolve_member(
    ref: str, members: list[dict[str, Any]]
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    """Resolve a member by id, username, full name, or unique partial name."""
    return _resolve_by_fields(ref, members, "member", ["username", "fullName"])


def resolve_checklist(
    ref: str, checklists: list[dict[str, Any]]
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    """Resolve a checklist by id or name."""
    return _resolve_by_fields(ref, checklists, "checklist", ["name"])


def resolve_check_item(
    ref: str,
    checklists: list[dict[str, Any]],
    checklist_ref: str | None = None,
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    """Resolve a check item by id or name, optionally within one checklist."""
    scoped = checklists
    if checklist_ref is not None:
        checklist, checklist_error = resolve_checklist(checklist_ref, checklists)
        if checklist_error:
            return None, checklist_error
        scoped = [checklist]
    items: list[dict[str, Any]] = []
    for checklist in scoped:
        for item in checklist.get("checkItems", []):
            item_with_parent = dict(item)
            item_with_parent.setdefault("idChecklist", checklist.get("id"))
            items.append(item_with_parent)
    return _resolve_by_fields(ref, items, "check item", ["name"])


def resolve_custom_field(
    ref: str, fields: list[dict[str, Any]]
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    """Resolve a custom field by id, field name, or display name."""
    candidates = []
    for field in fields:
        candidate = dict(field)
        display = field.get("display", {})
        if display.get("name") is not None:
            candidate.setdefault("name", display.get("name"))
        candidates.append(candidate)
    return _resolve_by_fields(ref, candidates, "custom field", ["name"])


def resolve_custom_field_option(
    ref: str, field: dict[str, Any]
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    """Resolve a custom-field dropdown option by id or display text."""
    options = field.get("display", {}).get("options") or field.get("options") or []
    candidates = []
    for option in options:
        candidate = dict(option)
        value = option.get("value") or {}
        if value.get("text") is not None:
            candidate.setdefault("name", value.get("text"))
        candidates.append(candidate)
    return _resolve_by_fields(ref, candidates, "custom field option", ["name"])


def validate_batch_urls(
    urls: list[str],
) -> tuple[list[str] | None, dict[str, Any] | None]:
    """Validate Trello batch URL paths."""
    if len(urls) > 10:
        return None, error(
            "invalid_input",
            "Trello batch API supports at most 10 URLs",
            input_ref=str(len(urls)),
        )
    for url in urls:
        parsed = urlsplit(url)
        if parsed.scheme or parsed.netloc or not url.startswith("/"):
            return None, error(
                "unsafe_operation",
                "Batch URLs must be relative Trello paths beginning with /",
                input_ref=url,
            )
        lowered = url.lower()
        if "key=" in lowered or "token=" in lowered:
            return None, error(
                "unsafe_operation",
                "Batch URLs must not include Trello credentials",
                input_ref=url,
            )
    return list(urls), None


def error_envelope(tool: str, exc: TrelloAPIError, input_ref: str) -> dict[str, Any]:
    """Convert a Trello client error into a standard envelope."""
    return envelope(
        tool,
        errors=[
            error(
                exc.code,
                exc.message,
                input_ref=input_ref,
                retryable=exc.retryable,
            )
        ],
    )


def _resolve_by_fields(
    ref: str,
    candidates: list[dict[str, Any]],
    kind: str,
    name_fields: list[str],
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    ref_text = str(ref).strip()
    if not ref_text:
        return None, error("not_found", f"No {kind} matched empty reference", ref)
    id_matches = [item for item in candidates if item.get("id") == ref_text]
    if id_matches:
        return _single_or_ambiguous(id_matches, ref_text, kind)
    ref_lower = ref_text.lower()
    exact_matches = [
        item
        for item in candidates
        if any(str(item.get(field, "")).lower() == ref_lower for field in name_fields)
    ]
    if exact_matches:
        return _single_or_ambiguous(exact_matches, ref_text, kind)
    partial_matches = [
        item
        for item in candidates
        if any(ref_lower in str(item.get(field, "")).lower() for field in name_fields)
    ]
    if partial_matches:
        return _single_or_ambiguous(partial_matches, ref_text, kind)
    return None, error("not_found", f"No {kind} matched '{ref_text}'", ref_text)


def _single_or_ambiguous(
    matches: list[dict[str, Any]], ref: str, kind: str
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    if len(matches) == 1:
        return matches[0], None
    return None, error(
        "ambiguous_ref",
        f"Multiple {kind}s matched '{ref}'",
        input_ref=ref,
        candidates=[_candidate(item) for item in matches],
    )


def _candidate(item: dict[str, Any]) -> dict[str, Any]:
    return {
        key: value
        for key, value in {
            "id": item.get("id"),
            "name": item.get("name") or item.get("username") or item.get("fullName"),
        }.items()
        if value is not None
    }


def _candidate_boards(name_or_id: str, trello: TrelloClient) -> list[dict[str, Any]]:
    if name_or_id.startswith("http"):
        return trello.request("/members/me/boards")
    if _looks_like_trello_id(name_or_id):
        try:
            return [trello.request(f"/boards/{name_or_id}")]
        except TrelloAPIError as exc:
            if exc.code != "not_found":
                raise
    try:
        result = trello.request(
            "/search",
            params={"query": name_or_id, "modelTypes": "boards", "boards_limit": 10},
        )
        boards = result.get("boards", []) if isinstance(result, dict) else []
        if boards:
            return boards
    except TrelloAPIError as exc:
        if exc.code != "trello_bad_request":
            raise
    return trello.request("/members/me/boards")


def _looks_like_trello_id(value: str) -> bool:
    return bool(re.fullmatch(r"[0-9a-fA-F]{8,}", value))
