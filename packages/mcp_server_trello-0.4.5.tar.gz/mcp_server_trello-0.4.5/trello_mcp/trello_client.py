"""Low-level Trello HTTP client with filtering, retries, and guardrails."""

from __future__ import annotations

import os
import time
from typing import Any
from urllib.parse import urlsplit

import requests


DEFAULT_FIELDS = {
    "cards": "id,name,idBoard,idList,idLabels,idMembers,due,start,dueComplete,closed,dateLastActivity,shortUrl,url",
    "lists": "id,name,closed,pos,idBoard",
    "labels": "id,name,color",
    "actions": "id,type,date,data",
}


class TrelloAPIError(Exception):
    """Stable Trello API error surfaced to tool wrappers."""

    def __init__(
        self,
        code: str,
        message: str,
        status_code: int | None = None,
        retryable: bool = False,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.status_code = status_code
        self.retryable = retryable


class TrelloClient:
    """Authenticated Trello request helper."""

    def __init__(
        self,
        api_key: str | None = None,
        api_token: str | None = None,
        base_url: str = "https://api.trello.com/1",
        max_retries: int = 3,
    ) -> None:
        self.api_key = api_key if api_key is not None else os.getenv("TRELLO_API_KEY")
        self.api_token = api_token if api_token is not None else os.getenv("TRELLO_API_TOKEN")
        self.base_url = base_url.rstrip("/")
        self.max_retries = max_retries

    def request(
        self,
        endpoint: str,
        method: str = "GET",
        data: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        files: dict[str, Any] | None = None,
    ) -> Any:
        """Make an authenticated Trello request."""
        self._validate_endpoint(endpoint)
        self._require_credentials()
        request_params = dict(params or {})
        self._inject_default_fields(endpoint, method, request_params)
        request_params["key"] = self.api_key
        request_params["token"] = self.api_token

        method = method.upper()
        attempts = self.max_retries + 1
        last_response = None
        for attempt in range(attempts):
            payload = {"data": data, "files": files} if files is not None else {"json": data}
            response = requests.request(
                method,
                f"{self.base_url}{endpoint}",
                params=request_params,
                **payload,
            )
            last_response = response
            if response.status_code < 400:
                return response.json()
            if not self._should_retry(response.status_code) or attempt == attempts - 1:
                raise self._api_error(response)
            self._sleep_before_retry(response, attempt)
        raise self._api_error(last_response)

    def raw_request(
        self,
        endpoint: str,
        method: str = "GET",
        data: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        files: dict[str, Any] | None = None,
        compact: bool = True,
        confirm: bool = False,
    ) -> Any:
        """Make a guarded raw Trello request."""
        method = method.upper()
        if method == "DELETE":
            if not confirm:
                raise TrelloAPIError(
                    "unsafe_operation",
                    "Raw DELETE requires confirm=True",
                    retryable=False,
                )
            if self._is_high_blast_radius_delete(endpoint):
                raise TrelloAPIError(
                    "unsafe_operation",
                    "Raw board deletion is not allowed",
                    retryable=False,
                )
        return self.request(endpoint, method=method, data=data, params=params, files=files)

    def _require_credentials(self) -> None:
        if not self.api_key or not self.api_token:
            raise TrelloAPIError(
                "trello_auth_error",
                "Trello API key and token are required",
                retryable=False,
            )

    def _validate_endpoint(self, endpoint: str) -> None:
        parsed = urlsplit(endpoint)
        if parsed.scheme or parsed.netloc or not endpoint.startswith("/"):
            raise TrelloAPIError(
                "invalid_input",
                "Trello endpoint must be a relative path beginning with /",
                retryable=False,
            )
        lowered = endpoint.lower()
        if "key=" in lowered or "token=" in lowered:
            raise TrelloAPIError(
                "unsafe_operation",
                "Trello credentials must not be included in endpoints",
                retryable=False,
            )

    def _inject_default_fields(
        self, endpoint: str, method: str, params: dict[str, Any]
    ) -> None:
        if method.upper() != "GET" or "fields" in params:
            return
        path = urlsplit(endpoint).path.strip("/")
        resource = path.split("/")[-1] if path else ""
        if resource in DEFAULT_FIELDS:
            params["fields"] = DEFAULT_FIELDS[resource]

    def _should_retry(self, status_code: int) -> bool:
        return status_code == 429 or status_code >= 500

    def _sleep_before_retry(self, response: requests.Response, attempt: int) -> None:
        retry_after = response.headers.get("Retry-After")
        if retry_after is not None:
            try:
                delay = float(retry_after)
            except ValueError:
                delay = 0
        else:
            delay = min(2**attempt, 8)
        time.sleep(delay)

    def _api_error(self, response: requests.Response | None) -> TrelloAPIError:
        if response is None:
            return TrelloAPIError("trello_unavailable", "Trello request failed", retryable=True)
        code = self._error_code_for_status(response.status_code)
        retryable = self._should_retry(response.status_code)
        message = self._response_message(response)
        return TrelloAPIError(
            code,
            message,
            status_code=response.status_code,
            retryable=retryable,
        )

    def _response_message(self, response: requests.Response) -> str:
        text = getattr(response, "text", "") or ""
        return text or f"Trello API returned HTTP {response.status_code}"

    def _error_code_for_status(self, status_code: int) -> str:
        if status_code == 400:
            return "trello_bad_request"
        if status_code in {401, 403}:
            return "trello_auth_error"
        if status_code == 404:
            return "not_found"
        if status_code == 429:
            return "trello_rate_limited"
        if status_code >= 500:
            return "trello_unavailable"
        return "trello_bad_request"

    def _is_high_blast_radius_delete(self, endpoint: str) -> bool:
        path_parts = [part for part in urlsplit(endpoint).path.split("/") if part]
        return len(path_parts) == 2 and path_parts[0] == "boards"
