"""Compact helpers for extended Trello domains."""

from __future__ import annotations

from typing import Any


def simplify_check_item(item: dict[str, Any]) -> dict[str, Any]:
    return _without_none(
        {
            "id": item.get("id"),
            "name": item.get("name"),
            "state": item.get("state"),
            "pos": item.get("pos"),
            "due": item.get("due"),
            "member_id": item.get("idMember"),
        }
    )


def simplify_checklist(checklist: dict[str, Any]) -> dict[str, Any]:
    return _without_none(
        {
            "id": checklist.get("id"),
            "name": checklist.get("name"),
            "card_id": checklist.get("idCard"),
            "pos": checklist.get("pos"),
            "items": [
                simplify_check_item(item)
                for item in checklist.get("checkItems", [])
            ],
        }
    )


def simplify_attachment(attachment: dict[str, Any]) -> dict[str, Any]:
    return _without_none(
        {
            "id": attachment.get("id"),
            "name": attachment.get("name"),
            "url": attachment.get("url"),
            "bytes": attachment.get("bytes"),
            "date": attachment.get("date"),
            "edge_color": attachment.get("edgeColor"),
        }
    )


def simplify_custom_field(field: dict[str, Any]) -> dict[str, Any]:
    display = field.get("display", {})
    options = display.get("options") or field.get("options") or []
    display_name = display.get("name")
    display_pos = display.get("pos")
    return _without_none(
        {
            "id": field.get("id"),
            "board_id": field.get("idModel"),
            "name": field.get("name") if display_name is None else display_name,
            "type": field.get("type"),
            "card_front": display.get("cardFront"),
            "pos": field.get("pos") if display_pos is None else display_pos,
            "options": [
                simplify_custom_field_option(option) for option in options
            ],
        }
    )


def simplify_custom_field_option(option: dict[str, Any]) -> dict[str, Any]:
    value = option.get("value") or {}
    return _without_none(
        {
            "id": option.get("id"),
            "custom_field_id": option.get("idCustomField"),
            "name": value.get("text"),
            "color": option.get("color"),
            "pos": option.get("pos"),
        }
    )


def simplify_custom_field_item(item: dict[str, Any]) -> dict[str, Any]:
    return _without_none(
        {
            "id": item.get("id"),
            "custom_field_id": item.get("idCustomField"),
            "card_id": item.get("idModel"),
            "value": item.get("value"),
            "option_id": item.get("idValue"),
        }
    )


def simplify_member(member: dict[str, Any]) -> dict[str, Any]:
    return _without_none(
        {
            "id": member.get("id"),
            "username": member.get("username"),
            "full_name": member.get("fullName"),
            "initials": member.get("initials"),
        }
    )


def operation_receipt(
    operation: str,
    input_ref: str | None,
    item_id: str | None,
    status: str,
    name: str | None = None,
) -> dict[str, Any]:
    return {
        "operation": operation,
        "input_ref": input_ref,
        "id": item_id,
        "name": input_ref if name is None else name,
        "status": status,
    }


def _without_none(values: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in values.items() if value is not None}
