"""
Base classes for Phlo plugins.

These abstract base classes define the interfaces that plugins must implement.
"""

from __future__ import annotations

from phlo.plugins.base.catalog import CatalogPlugin
from phlo.plugins.base.cli import CliCommandPlugin
from phlo.plugins.base.governance import GovernancePlugin
from phlo.plugins.base.ingestion_provider import IngestionProviderPlugin
from phlo.plugins.base.orchestrator import OrchestratorAdapterPlugin
from phlo.plugins.base.plugin import Plugin, PluginMetadata
from phlo.plugins.base.providers import AssetProviderPlugin, ResourceProviderPlugin
from phlo.plugins.base.quality import QualityCheckPlugin
from phlo.plugins.base.quality_provider import QualityProviderPlugin
from phlo.plugins.base.service import ServicePlugin
from phlo.plugins.base.source import SourceConnectorPlugin
from phlo.plugins.base.transform import TransformationPlugin
from phlo.plugins.base.transformation_provider import TransformationProviderPlugin

__all__ = [
    "Plugin",
    "PluginMetadata",
    "CliCommandPlugin",
    "SourceConnectorPlugin",
    "QualityCheckPlugin",
    "QualityProviderPlugin",
    "IngestionProviderPlugin",
    "TransformationPlugin",
    "TransformationProviderPlugin",
    "ServicePlugin",
    "CatalogPlugin",
    "GovernancePlugin",
    "AssetProviderPlugin",
    "ResourceProviderPlugin",
    "OrchestratorAdapterPlugin",
]
