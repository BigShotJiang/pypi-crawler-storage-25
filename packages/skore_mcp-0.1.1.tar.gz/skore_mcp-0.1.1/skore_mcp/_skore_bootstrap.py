"""Import skore only after diskcache patch and matplotlib config."""

from __future__ import annotations

import os
import tempfile

from skore_mcp.diskcache_fix import apply as _apply_diskcache_fix


def configure_runtime() -> None:
    _apply_diskcache_fix()
    mpl = os.path.join(tempfile.gettempdir(), "skore_mcp_mplconfig")
    os.makedirs(mpl, exist_ok=True)
    os.environ.setdefault("MPLCONFIGDIR", mpl)


configure_runtime()

import skore  # noqa: E402
from skore import (  # noqa: E402
    ComparisonReport,
    CrossValidationReport,
    EstimatorReport,
    Project,
    compare,
    configuration,
    evaluate,
    login,
    show_versions,
    train_test_split,
)

__all__ = [
    "skore",
    "ComparisonReport",
    "CrossValidationReport",
    "EstimatorReport",
    "Project",
    "compare",
    "configuration",
    "evaluate",
    "login",
    "show_versions",
    "train_test_split",
]
