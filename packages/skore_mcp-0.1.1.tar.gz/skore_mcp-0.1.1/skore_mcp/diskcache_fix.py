"""Work around diskcache triggers on SQLite 3.41+ (double-quoted string literals)."""

from __future__ import annotations

import diskcache.core as _dc


def apply() -> None:
    """Patch Cache._sql_retry so CREATE TRIGGER uses valid string literals."""
    if getattr(_dc.Cache, "_skore_mcp_diskcache_patched", False):
        return

    _orig_getter = _dc.Cache._sql_retry.fget

    def _patched_sql_retry_fget(self):
        inner = _orig_getter(self)

        def _execute_with_retry(statement, *args, **kwargs):
            if isinstance(statement, str):
                statement = statement.replace(
                    'WHERE key = "count"', "WHERE key = 'count'"
                )
                statement = statement.replace('WHERE key = "size"', "WHERE key = 'size'")
            return inner(statement, *args, **kwargs)

        return _execute_with_retry

    _dc.Cache._sql_retry = property(_patched_sql_retry_fget)
    _dc.Cache._skore_mcp_diskcache_patched = True  # type: ignore[attr-defined]
