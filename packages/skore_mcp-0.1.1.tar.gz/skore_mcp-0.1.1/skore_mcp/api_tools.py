"""Extended Skore API: utilities, compare, train_test_split, report method dispatch."""

from __future__ import annotations

import json
import logging
import uuid
from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path
from typing import Any, Literal

from rich.console import Console

from skore_mcp._skore_bootstrap import (
    EstimatorReport,
    compare,
    configuration,
    show_versions,
    skore,
    train_test_split,
)
from skore_mcp.estimators import build_estimator
from skore_mcp.project_util import open_project
from skore_mcp.serialize import _predictions_to_json, skore_result_to_jsonable

_LOG = logging.getLogger("skore_mcp.api")

_SESSION_REPORTS: dict[str, Any] = {}

REPORT_METHODS = frozenset(
    {"help", "get_predictions", "cache_predictions", "clear_cache", "create_estimator_report"}
)
METRICS_METHODS = frozenset(
    {
        "help",
        "summarize",
        "timings",
        "accuracy",
        "precision",
        "recall",
        "brier_score",
        "roc_auc",
        "log_loss",
        "rmse",
        "r2",
        "custom_metric",
        "roc",
        "precision_recall",
        "prediction_error",
        "confusion_matrix",
    }
)
INSPECTION_METHODS = frozenset({"help", "coefficients", "impurity_decrease", "permutation_importance"})
DATA_METHODS = frozenset({"help", "analyze"})


def _catalog() -> dict[str, Any]:
    return {
        "skore_version": getattr(skore, "__version__", "unknown"),
        "docs": "https://docs.skore.probabl.ai/stable/",
        "session_reports_cached": len(_SESSION_REPORTS),
        "accessors": {
            "report": sorted(REPORT_METHODS),
            "metrics": sorted(METRICS_METHODS),
            "inspection": sorted(INSPECTION_METHODS),
            "data": sorted(DATA_METHODS),
        },
        "tools": [
            "skore_api_catalog",
            "skore_show_versions",
            "skore_configuration_get",
            "skore_configuration_set",
            "skore_train_test_split_csv",
            "skore_estimator_report_from_split_csv",
            "skore_compare_persisted_reports",
            "skore_compare_session_reports",
            "skore_report_call",
            "skore_session_release",
        ],
        "notes": [
            "skore_report_call: use project_name+report_id OR session_report_key (from skore_evaluate_csv or compare).",
            "create_estimator_report kwargs_json may include x_test_csv_path, y_test_csv_path, y_test_column, feature_columns; ComparisonReport also needs report_key.",
 ],
    }


def register_session_report(report: Any) -> str:
    key = uuid.uuid4().hex
    _SESSION_REPORTS[key] = report
    return key


def release_session_report(key: str) -> bool:
    return _SESSION_REPORTS.pop(key, None) is not None


def _resolve_report(
    *,
    project_name: str | None,
    report_id: str | None,
    session_report_key: str | None,
    mode: Literal["local", "hub", "mlflow"],
    workspace: str | None,
    tracking_uri: str | None,
) -> Any:
    if session_report_key is not None:
        if session_report_key not in _SESSION_REPORTS:
            raise KeyError(f"Unknown session_report_key: {session_report_key}")
        return _SESSION_REPORTS[session_report_key]
    if not project_name or not report_id:
        raise ValueError("Provide session_report_key or both project_name and report_id")
    proj = open_project(project_name, mode, workspace, tracking_uri)
    return proj.get(report_id)


def _help_as_text(fn: Any) -> str:
    buf = StringIO()
    console = Console(file=buf, width=100, force_terminal=False)
    try:
        result = fn()
        if result is not None:
            console.print(result)
    except TypeError:
        try:
            fn()
        except Exception as exc:
            return f"(help raised {exc})"
    except Exception as exc:
        return f"(help failed: {exc})"
    return buf.getvalue() or "(empty help)"


def _prepare_create_estimator_kwargs(report: Any, kwargs: dict[str, Any]) -> dict[str, Any]:
    kw = dict(kwargs)
    x_path = kw.pop("x_test_csv_path", None)
    y_path = kw.pop("y_test_csv_path", None)
    y_col = kw.pop("y_test_column", None)
    feature_columns = kw.pop("feature_columns", None)

    if x_path is None and y_path is None:
        return kw

    import pandas as pd

    if x_path is None or y_path is None:
        raise ValueError(
            "create_estimator_report with CSV requires both x_test_csv_path and y_test_csv_path"
        )

    x_df = pd.read_csv(Path(x_path).expanduser().resolve())
    y_df = pd.read_csv(Path(y_path).expanduser().resolve())
    if y_col is None:
        if y_df.shape[1] != 1:
            raise ValueError("y_test CSV must have one column or pass y_test_column")
        y_test = y_df.iloc[:, 0].to_numpy()
    else:
        if y_col not in y_df.columns:
            raise ValueError(f"y_test_column {y_col!r} not in y CSV")
        y_test = y_df[y_col].to_numpy()

    if feature_columns is not None:
        missing = [c for c in feature_columns if c not in x_df.columns]
        if missing:
            raise ValueError(f"Missing feature columns in X CSV: {missing}")
        X_test = x_df[feature_columns]
    else:
        X_test = x_df

    kw["X_test"] = X_test
    kw["y_test"] = y_test
    return kw


def _train_test_split_csv_impl(
    csv_path: str,
    target_column: str,
    test_size: float | None = None,
    train_size: float | None = None,
    random_state: int | None = None,
    shuffle: bool = True,
    feature_columns: list[str] | None = None,
) -> str:
    import pandas as pd

    path = Path(csv_path).expanduser().resolve()
    if not path.is_file():
        return json.dumps({"ok": False, "error": f"File not found: {path}"})

    df = pd.read_csv(path)
    if target_column not in df.columns:
        return json.dumps({"ok": False, "error": f"Missing target column {target_column!r}"})

    y = df[target_column]
    if feature_columns:
        missing = [c for c in feature_columns if c not in df.columns]
        if missing:
            return json.dumps({"ok": False, "error": f"Missing columns: {missing}"})
        X = df[feature_columns]
    else:
        X = df.drop(columns=[target_column])

    kw: dict[str, Any] = {"X": X, "y": y, "as_dict": True, "shuffle": shuffle}
    if test_size is not None:
        kw["test_size"] = test_size
    if train_size is not None:
        kw["train_size"] = train_size
    if random_state is not None:
        kw["random_state"] = random_state

    split_data = train_test_split(**kw)
    out: dict[str, Any] = {"ok": True}
    for key in ("X_train", "X_test", "y_train", "y_test"):
        buf = StringIO()
        split_data[key].to_csv(buf, index=False)
        out[key + "_csv"] = buf.getvalue()
    out["n_features"] = split_data["X_train"].shape[1]
    out["n_train"] = int(split_data["X_train"].shape[0])
    out["n_test"] = int(split_data["X_test"].shape[0])
    return json.dumps(out)


def register_api_tools(mcp: Any) -> None:
    @mcp.tool()
    def skore_api_catalog() -> str:
        """List accessors and allowed method names (use with skore_report_call). Full Skore docs: https://docs.skore.probabl.ai/stable/"""
        return json.dumps(_catalog(), indent=2)

    @mcp.tool()
    def skore_show_versions() -> str:
        """Run skore.show_versions() and return captured stdout."""
        buf = StringIO()
        with redirect_stdout(buf):
            show_versions()
        return buf.getvalue()

    @mcp.tool()
    def skore_configuration_get() -> str:
        """Read skore.configuration (show_progress, plot_backend)."""
        return json.dumps(
            {
                "show_progress": configuration.show_progress,
                "plot_backend": configuration.plot_backend,
            },
            indent=2,
        )

    @mcp.tool()
    def skore_configuration_set(
        show_progress: bool | None = None,
        plot_backend: str | None = None,
    ) -> str:
        """Set skore.configuration for the current process."""
        if show_progress is not None:
            configuration.show_progress = show_progress
        if plot_backend is not None:
            configuration.plot_backend = plot_backend
        return json.dumps(
            {
                "show_progress": configuration.show_progress,
                "plot_backend": configuration.plot_backend,
            },
            indent=2,
        )

    @mcp.tool()
    def skore_train_test_split_csv(
        csv_path: str,
        target_column: str,
        test_size: float | None = None,
        train_size: float | None = None,
        random_state: int | None = None,
        shuffle: bool = True,
        feature_columns: list[str] | None = None,
    ) -> str:
        """
        skore.train_test_split on a CSV. Returns X_train, X_test, y_train, y_test as CSV strings.
        """
        return _train_test_split_csv_impl(
            csv_path,
            target_column,
            test_size=test_size,
            train_size=train_size,
            random_state=random_state,
            shuffle=shuffle,
            feature_columns=feature_columns,
        )

    @mcp.tool()
    def skore_estimator_report_from_split_csv(
        csv_path: str,
        target_column: str,
        estimator: str,
        test_size: float | None = 0.2,
        train_size: float | None = None,
        random_state: int = 0,
        shuffle: bool = True,
        feature_columns: list[str] | None = None,
        pos_label: str | int | float | bool | None = None,
    ) -> str:
        """
        Build skore.EstimatorReport from CSV (single train/test split). Returns session_report_key for skore_report_call.
        """
        raw = _train_test_split_csv_impl(
            csv_path,
            target_column,
            test_size=test_size,
            train_size=train_size,
            random_state=random_state,
            shuffle=shuffle,
            feature_columns=feature_columns,
        )
        payload = json.loads(raw)
        if not payload.get("ok"):
            return raw

        import pandas as pd

        X_train = pd.read_csv(StringIO(payload["X_train_csv"]))
        X_test = pd.read_csv(StringIO(payload["X_test_csv"]))
        y_train = pd.read_csv(StringIO(payload["y_train_csv"])).iloc[:, 0].to_numpy()
        y_test = pd.read_csv(StringIO(payload["y_test_csv"])).iloc[:, 0].to_numpy()

        model = build_estimator(estimator)  # type: ignore[arg-type]
        est_kw: dict[str, Any] = {
            "fit": True,
            "X_train": X_train,
            "y_train": y_train,
            "X_test": X_test,
            "y_test": y_test,
        }
        if pos_label is not None:
            est_kw["pos_label"] = pos_label
        report = EstimatorReport(model, **est_kw)
        key = register_session_report(report)
        return json.dumps(
            {
                "ok": True,
                "session_report_key": key,
                "report_type": type(report).__name__,
            }
        )

    @mcp.tool()
    def skore_compare_persisted_reports(
        project_name: str,
        report_ids: list[str],
        mode: Literal["local", "hub", "mlflow"] = "local",
        workspace: str | None = None,
        tracking_uri: str | None = None,
        n_jobs: int | None = None,
    ) -> str:
        """skore.compare on two or more reports loaded from the same Project (by report id from summarize)."""
        if len(report_ids) < 2:
            return json.dumps({"ok": False, "error": "Need at least two report_ids"})
        proj = open_project(project_name, mode, workspace, tracking_uri)
        reports = [proj.get(rid) for rid in report_ids]
        comp = compare(reports, n_jobs=n_jobs)
        key = register_session_report(comp)
        return json.dumps(
            {
                "ok": True,
                "session_report_key": key,
                "report_type": "ComparisonReport",
                "compared_keys": list(comp.reports_.keys()),
            }
        )

    @mcp.tool()
    def skore_compare_session_reports(
        session_report_keys: list[str],
        n_jobs: int | None = None,
    ) -> str:
        """skore.compare on in-memory reports (session keys from skore_evaluate_csv or other tools)."""
        if len(session_report_keys) < 2:
            return json.dumps({"ok": False, "error": "Need at least two session_report_keys"})
        reports = []
        for k in session_report_keys:
            if k not in _SESSION_REPORTS:
                return json.dumps({"ok": False, "error": f"Unknown session_report_key: {k}"})
            reports.append(_SESSION_REPORTS[k])
        comp = compare(reports, n_jobs=n_jobs)
        key = register_session_report(comp)
        return json.dumps(
            {
                "ok": True,
                "session_report_key": key,
                "report_type": "ComparisonReport",
                "compared_keys": list(comp.reports_.keys()),
            }
        )

    @mcp.tool()
    def skore_session_release(session_report_key: str) -> str:
        """Remove a session-cached report from memory."""
        ok = release_session_report(session_report_key)
        return json.dumps({"ok": ok})

    @mcp.tool()
    def skore_report_call(
        accessor: Literal["report", "metrics", "inspection", "data"],
        method: str,
        kwargs_json: str = "{}",
        project_name: str | None = None,
        report_id: str | None = None,
        session_report_key: str | None = None,
        mode: Literal["local", "hub", "mlflow"] = "local",
        workspace: str | None = None,
        tracking_uri: str | None = None,
    ) -> str:
        """
        Invoke a Skore report API: get_predictions, cache_predictions, metrics.*, inspection.*, data.analyze, etc.
        See skore_api_catalog for allowed method names per accessor.
        Provide either session_report_key OR (project_name and report_id).
        """
        allowed = {
            "report": REPORT_METHODS,
            "metrics": METRICS_METHODS,
            "inspection": INSPECTION_METHODS,
            "data": DATA_METHODS,
        }[accessor]
        if method not in allowed:
            return json.dumps(
                {
                    "ok": False,
                    "error": f"Method {method!r} not allowed for accessor {accessor!r}",
                    "allowed": sorted(allowed),
                }
            )

        try:
            kwargs = json.loads(kwargs_json) if kwargs_json.strip() else {}
            if not isinstance(kwargs, dict):
                raise ValueError("kwargs_json must decode to an object")
        except json.JSONDecodeError as exc:
            return json.dumps({"ok": False, "error": f"Invalid kwargs_json: {exc}"})

        try:
            report = _resolve_report(
                project_name=project_name,
                report_id=report_id,
                session_report_key=session_report_key,
                mode=mode,
                workspace=workspace,
                tracking_uri=tracking_uri,
            )
        except Exception as exc:
            _LOG.exception("resolve report")
            return json.dumps({"ok": False, "error": str(exc)})

        try:
            if accessor == "report":
                target = report
            elif accessor == "metrics":
                target = report.metrics
            elif accessor == "inspection":
                target = report.inspection
            else:
                target = report.data
        except AttributeError:
            return json.dumps(
                {
                    "ok": False,
                    "error": f"Report type {type(report).__name__} has no {accessor!r} accessor",
                }
            )

        fn = getattr(target, method, None)
        if not callable(fn):
            return json.dumps({"ok": False, "error": f"Not callable: {accessor}.{method}"})

        if method == "help":
            text = _help_as_text(fn)
            return json.dumps({"ok": True, "help_text": text})

        if method == "create_estimator_report":
            try:
                kwargs = _prepare_create_estimator_kwargs(report, kwargs)
            except Exception as exc:
                return json.dumps({"ok": False, "error": str(exc)})

        try:
            result = fn(**kwargs)
        except TypeError:
            try:
                result = fn()
            except Exception as exc:
                return json.dumps({"ok": False, "error": str(exc)})
        except Exception as exc:
            _LOG.exception("report call %s.%s", accessor, method)
            return json.dumps({"ok": False, "error": str(exc)})

        if method == "get_predictions":
            return json.dumps({"ok": True, "result": _predictions_to_json(result)})

        if method == "clear_cache" and result is None:
            return json.dumps({"ok": True, "result": None})

        try:
            payload = skore_result_to_jsonable(result)
            return json.dumps({"ok": True, "result": payload}, default=str)
        except Exception:
            return json.dumps(
                {"ok": True, "result": {"repr": repr(result)[:12000]}},
                default=str,
            )
