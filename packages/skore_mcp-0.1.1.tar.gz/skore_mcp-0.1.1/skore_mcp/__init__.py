"""MCP server bridging AI assistants to Skore."""

__version__ = "0.1.1"
