"""Shared helpers for skore.Project access."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Literal

from skore_mcp._skore_bootstrap import Project


def project_kwargs(
    mode: Literal["local", "hub", "mlflow"],
    workspace: str | None,
    tracking_uri: str | None,
) -> dict[str, Any]:
    kw: dict[str, Any] = {}
    if mode == "local" and workspace:
        kw["workspace"] = Path(workspace).expanduser().resolve()
    if mode == "mlflow" and tracking_uri:
        kw["tracking_uri"] = tracking_uri
    return kw


def open_project(
    project_name: str,
    mode: Literal["local", "hub", "mlflow"],
    workspace: str | None = None,
    tracking_uri: str | None = None,
) -> Any:
    return Project(project_name, mode=mode, **project_kwargs(mode, workspace, tracking_uri))


def report_id_from_summarize_row(idx: Any) -> str:
    if isinstance(idx, tuple):
        return str(idx[-1])
    return str(idx)
