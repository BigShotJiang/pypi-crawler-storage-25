"""Named sklearn estimators for CSV-based workflows."""

from __future__ import annotations

from typing import Any, Literal, get_args

from sklearn.ensemble import (
    GradientBoostingClassifier,
    GradientBoostingRegressor,
    RandomForestClassifier,
    RandomForestRegressor,
)
from sklearn.linear_model import LinearRegression, LogisticRegression, Ridge

EstimatorName = Literal[
    "linear_regression",
    "ridge",
    "logistic_regression",
    "random_forest_regressor",
    "random_forest_classifier",
    "gradient_boosting_regressor",
    "gradient_boosting_classifier",
]


def build_estimator(name: EstimatorName) -> Any:
    est_map = {
        "linear_regression": LinearRegression(),
        "ridge": Ridge(),
        "logistic_regression": LogisticRegression(max_iter=1000),
        "random_forest_regressor": RandomForestRegressor(random_state=0),
        "random_forest_classifier": RandomForestClassifier(random_state=0),
        "gradient_boosting_regressor": GradientBoostingRegressor(random_state=0),
        "gradient_boosting_classifier": GradientBoostingClassifier(random_state=0),
    }
    return est_map[name]


def estimator_names() -> list[str]:
    return list(get_args(EstimatorName))
