from skore_mcp.server import main

main()
