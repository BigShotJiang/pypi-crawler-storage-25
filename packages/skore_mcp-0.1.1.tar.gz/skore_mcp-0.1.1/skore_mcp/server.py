"""Skore MCP server (stdio)."""

from __future__ import annotations

import io
import json
import logging
import sys
from pathlib import Path
from typing import Any, Literal

from mcp.server.fastmcp import FastMCP

from skore_mcp._skore_bootstrap import Project, evaluate, login, skore
from skore_mcp.api_tools import register_api_tools, register_session_report
from skore_mcp.estimators import build_estimator
from skore_mcp.project_util import open_project, project_kwargs, report_id_from_summarize_row

mcp = FastMCP(
    "skore",
    instructions=(
        "Skore MCP: Project CRUD, skore.evaluate on CSV, skore.compare, train_test_split, "
        "configuration, show_versions, and skore_report_call for report/metrics/inspection/data APIs "
        "(e.g. get_predictions). Use skore_api_catalog for allowed method names. "
        "Docs: https://docs.skore.probabl.ai/stable/"
    ),
)

_LOG = logging.getLogger("skore_mcp")
if not _LOG.handlers:
    _h = logging.StreamHandler(sys.stderr)
    _h.setFormatter(logging.Formatter("%(levelname)s %(name)s: %(message)s"))
    _LOG.addHandler(_h)
    _LOG.setLevel(logging.INFO)


def _df_to_csv_string(df: Any) -> str:
    buf = io.StringIO()
    df = df.reset_index() if hasattr(df, "reset_index") else df
    df.to_csv(buf, index=False)
    return buf.getvalue()


@mcp.tool()
def skore_info() -> str:
    """Return installed skore version and Python hints for Project modes."""
    return json.dumps(
        {
            "skore_version": getattr(skore, "__version__", "unknown"),
            "docs": "https://docs.skore.probabl.ai/stable/",
            "hub": "https://skore.probabl.ai/",
            "catalog_tool": "Call skore_api_catalog for report/metrics/inspection/data method allowlists.",
            "modes": {
                "local": "Persist under SKORE_WORKSPACE or the workspace path you pass.",
                "hub": 'Use project_name like "workspace_slug/project_slug"; call skore_hub_login first.',
                "mlflow": "Set tracking_uri; project_name is the MLflow experiment name.",
            },
        },
        indent=2,
    )


@mcp.tool()
def skore_hub_login(api_key: str | None = None, timeout: int = 600) -> str:
    """
    Authenticate to Skore Hub for the current process (in-memory only).
    Install the hub extra/plugin for your Skore version, create an API key at
    https://skore.probabl.ai/account when applicable, and pass credentials your
    plugin documents (often ``api_key`` or environment variables).
    """
    kwargs: dict[str, Any] = {"timeout": timeout}
    if api_key:
        kwargs["api_key"] = api_key
    try:
        login(mode="hub", **kwargs)
    except Exception as exc:
        _LOG.exception("skore.login failed")
        return json.dumps({"ok": False, "error": str(exc)})
    return json.dumps({"ok": True})


@mcp.tool()
def skore_project_summarize(
    project_name: str,
    mode: Literal["local", "hub", "mlflow"] = "local",
    workspace: str | None = None,
    tracking_uri: str | None = None,
) -> str:
    """
    Return a CSV table of all reports in a skore.Project (same metadata as Project.summarize).
    For each report, use the `id` column with skore_report_metrics / skore_report_call.
    """
    proj = open_project(project_name, mode, workspace, tracking_uri)
    summary = proj.summarize()
    return _df_to_csv_string(summary)


@mcp.tool()
def skore_report_metrics(
    project_name: str,
    report_id: str,
    mode: Literal["local", "hub", "mlflow"] = "local",
    workspace: str | None = None,
    tracking_uri: str | None = None,
    aggregate: Literal["mean", "std"] | None = None,
) -> str:
    """
    Load one report by id (hex string from summarize) and export metrics summary as CSV.
    aggregate: None lists per-split values; \"mean\" or \"std\" aggregates across splits.
    """
    proj = open_project(project_name, mode, workspace, tracking_uri)
    report = proj.get(report_id)
    metrics = report.metrics.summarize()
    frame = metrics.frame(aggregate=aggregate)
    return _df_to_csv_string(frame)


@mcp.tool()
def skore_evaluate_csv(
    csv_path: str,
    target_column: str,
    estimator: Literal[
        "linear_regression",
        "ridge",
        "logistic_regression",
        "random_forest_regressor",
        "random_forest_classifier",
        "gradient_boosting_regressor",
        "gradient_boosting_classifier",
    ],
    splitter: float | int = 0.2,
    feature_columns: list[str] | None = None,
    pos_label: str | int | float | bool | None = None,
    n_jobs: int | None = None,
    project_name: str | None = None,
    put_key: str | None = None,
    project_mode: Literal["local", "hub", "mlflow"] = "local",
    workspace: str | None = None,
    tracking_uri: str | None = None,
) -> str:
    """
    Run skore.evaluate on a CSV file (pandas-readable). splitter: float train fraction, int = CV folds.
    If project_name and put_key are set, the report is stored with Project.put(put_key, report).
    Always returns session_report_key so you can call skore_report_call without persisting.
    """
    import pandas as pd

    path = Path(csv_path).expanduser().resolve()
    if not path.is_file():
        return json.dumps({"ok": False, "error": f"File not found: {path}"})

    df = pd.read_csv(path)
    if target_column not in df.columns:
        return json.dumps(
            {"ok": False, "error": f"target_column {target_column!r} not in columns"}
        )

    y = df[target_column].to_numpy()
    if feature_columns:
        missing = [c for c in feature_columns if c not in df.columns]
        if missing:
            return json.dumps({"ok": False, "error": f"Missing feature columns: {missing}"})
        X = df[feature_columns]
    else:
        X = df.drop(columns=[target_column])

    model = build_estimator(estimator)

    if not isinstance(splitter, (float, int)):
        return json.dumps({"ok": False, "error": "splitter must be float or int"})

    ev_kw: dict[str, Any] = {}
    if pos_label is not None:
        ev_kw["pos_label"] = pos_label
    if n_jobs is not None:
        ev_kw["n_jobs"] = n_jobs

    report = evaluate(model, X, y, splitter=splitter, **ev_kw)
    result: dict[str, Any] = {
        "ok": True,
        "report_type": type(report).__name__,
        "session_report_key": register_session_report(report),
    }

    metrics = report.metrics.summarize().frame(aggregate=None)
    result["metrics_csv"] = _df_to_csv_string(metrics)

    if project_name and put_key:
        proj = open_project(project_name, project_mode, workspace, tracking_uri)
        proj.put(put_key, report)
        summary = proj.summarize()
        matches = summary[summary["key"] == put_key]
        if len(matches.index):
            rid = report_id_from_summarize_row(matches.index[-1])
        else:
            rid = report_id_from_summarize_row(summary.index[-1])
        result["stored"] = True
        result["report_id"] = rid
        result["put_key"] = put_key

    return json.dumps(result, default=str)


@mcp.tool()
def skore_project_delete(
    project_name: str,
    mode: Literal["local", "hub", "mlflow"] = "local",
    workspace: str | None = None,
) -> str:
    """Delete a local or hub project (not supported for MLflow)."""
    try:
        Project.delete(project_name, mode=mode, **project_kwargs(mode, workspace, None))
    except Exception as exc:
        return json.dumps({"ok": False, "error": str(exc)})
    return json.dumps({"ok": True})


register_api_tools(mcp)


def main() -> None:
    mcp.run()


if __name__ == "__main__":
    main()
