"""Serialize Skore / sklearn / numpy return values for MCP JSON responses."""

from __future__ import annotations

import base64
import io
import json
import warnings
from typing import Any

import numpy as np

# Headless-safe plotting when serializing Display objects
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

MAX_ARRAY_ELEMENTS = 500_000

def _figure_from_display(obj: Any):
    if hasattr(obj, "figure_") and obj.figure_ is not None:
        return obj.figure_
    if hasattr(obj, "figure") and obj.figure is not None:
        return obj.figure
    if hasattr(obj, "ax_") and obj.ax_ is not None:
        try:
            return obj.ax_.get_figure()
        except Exception:
            return None
    return None


def _json_default(o: Any) -> Any:
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, np.bool_):
        return bool(o)
    if isinstance(o, np.ndarray):
        return _serialize_ndarray(o)
    raise TypeError(f"Object of type {type(o).__name__} is not JSON serializable")


def _serialize_ndarray(arr: np.ndarray) -> dict[str, Any]:
    if arr.size > MAX_ARRAY_ELEMENTS:
        return {
            "_type": "ndarray",
            "shape": list(arr.shape),
            "dtype": str(arr.dtype),
            "error": f"Array exceeds limit of {MAX_ARRAY_ELEMENTS} elements; request smaller data or aggregate.",
        }
    return {
        "_type": "ndarray",
        "shape": list(arr.shape),
        "dtype": str(arr.dtype),
        "data": arr.tolist(),
    }


def _predictions_to_json(pred: Any) -> Any:
    if isinstance(pred, np.ndarray):
        return _serialize_ndarray(pred)
    if isinstance(pred, list):
        return [_predictions_to_json(p) for p in pred]
    return pred


def _display_to_payload(obj: Any) -> dict[str, Any]:
    """Turn a Display / figure-like object into frame CSV and/or PNG."""
    out: dict[str, Any] = {"_skore_type": type(obj).__name__}

    if hasattr(obj, "frame") and callable(obj.frame):
        try:
            fr = obj.frame()
            if hasattr(fr, "to_csv"):
                buf = io.StringIO()
                fr.reset_index(drop=False).to_csv(buf, index=False)
                out["frame_csv"] = buf.getvalue()
        except Exception as exc:
            out["frame_error"] = str(exc)

    fig = _figure_from_display(obj)
    if fig is not None:
        try:
            buf = io.BytesIO()
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                fig.savefig(buf, format="png", bbox_inches="tight")
            out["plot_png_base64"] = base64.b64encode(buf.getvalue()).decode("ascii")
        except Exception as exc:
            out["plot_error"] = str(exc)
        finally:
            try:
                plt.close(fig)
            except Exception:
                pass

    if len(out) == 1:
        out["repr"] = repr(obj)[:8000]
    return out


def skore_result_to_jsonable(result: Any, depth: int = 0) -> Any:
    """Convert a Skore call result to JSON-serializable structure."""
    if depth > 12:
        return {"error": "max depth exceeded"}

    if result is None:
        return None
    if isinstance(result, (bool, str, int, float)):
        return result
    if isinstance(result, np.ndarray):
        return _serialize_ndarray(result)
    if isinstance(result, np.generic):
        return result.item()

    mod = type(result).__module__
    name = type(result).__name__

    if "pandas" in mod and hasattr(result, "to_csv"):
        buf = io.StringIO()
        try:
            result.reset_index(drop=False).to_csv(buf, index=False)
            return {"_type": "pandas", "class": name, "csv": buf.getvalue()}
        except Exception:
            return {"_type": "pandas", "class": name, "repr": repr(result)[:4000]}

    if isinstance(result, (list, tuple)):
        return [skore_result_to_jsonable(x, depth + 1) for x in result]

    if isinstance(result, dict):
        return {str(k): skore_result_to_jsonable(v, depth + 1) for k, v in result.items()}

    # Likely a Display from skore/sklearn
    if "skore" in mod or "sklearn" in mod or "Display" in name:
        return _display_to_payload(result)

    return {"_type": name, "repr": repr(result)[:8000]}


def dumps_result(result: Any) -> str:
    payload = skore_result_to_jsonable(result)
    return json.dumps(payload, default=_json_default, indent=2)
