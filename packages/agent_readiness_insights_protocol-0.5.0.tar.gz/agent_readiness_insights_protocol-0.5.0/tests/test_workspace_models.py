"""Tests for the 7 workspace-starter manifest models added in spec §6."""
from __future__ import annotations

import pytest
from pydantic import ValidationError

from agent_readiness_insights_protocol.models import (
    ArchRule,
    Boundaries,
    Glossary,
    Migration,
    Repository,
    Session,
    WorkspaceManifest,
)


def test_workspace_manifest_minimal_roundtrip() -> None:
    m = WorkspaceManifest.model_validate({
        "apiVersion": "agent-readiness.io/v1",
        "kind": "WorkspaceManifest",
        "metadata": {"name": "example", "version": "1.0.0",
                     "compatibleScanner": ">=0.5.0,<1.0.0"},
        "spec": {"exemplar": "hello-service", "repos": [],
                 "answers": [
                     {"key": "org", "prompt": "Org name", "required": True}
                 ]},
    })
    assert m.metadata.name == "example"
    assert m.spec.exemplar == "hello-service"
    assert m.spec.answers[0].required is True
    dumped = m.model_dump(mode="json", by_alias=True)
    again = WorkspaceManifest.model_validate(dumped)
    assert again == m


def test_workspace_manifest_rejects_wrong_apiversion() -> None:
    with pytest.raises(ValidationError):
        WorkspaceManifest.model_validate({
            "apiVersion": "wrong.io/v1",
            "kind": "WorkspaceManifest",
            "metadata": {"name": "x", "version": "1.0.0",
                         "compatibleScanner": ">=0.5.0"},
            "spec": {"exemplar": "x", "repos": [], "answers": []},
        })


def test_glossary_minimal_roundtrip() -> None:
    g = Glossary.model_validate({
        "apiVersion": "agent-readiness.io/v1",
        "kind": "Glossary",
        "spec": {"terms": [
            {"canonical": "scanner",
             "forbidden": ["checker", "validator", "linter"],
             "scope": ["**/*.md"]}
        ], "exceptions": [{"file": "CHANGELOG.md"}]},
    })
    assert g.spec.terms[0].canonical == "scanner"
    assert g.spec.exceptions[0].file == "CHANGELOG.md"


def test_boundaries_with_three_rule_effects() -> None:
    b = Boundaries.model_validate({
        "apiVersion": "agent-readiness.io/v1",
        "kind": "Boundaries",
        "spec": {
            "tagAxes": {"tier": ["edge", "internal", "core"],
                        "scope": ["protocol", "service", "consumer"]},
            "rules": [
                {"name": "deny-edge-internal",
                 "from": {"tier": "edge"}, "to": {"tier": "internal"},
                 "effect": "deny"},
                {"name": "allow-exclusive",
                 "from": {"scope": "consumer"}, "to": {"scope": "protocol"},
                 "effect": "allow-exclusive"},
                {"name": "default", "effect": "allow"},
            ],
        },
    })
    assert b.spec.rules[0].effect == "deny"
    assert b.spec.rules[1].effect == "allow-exclusive"
    assert b.spec.rules[2].effect == "allow"
    assert b.spec.rules[2].from_ is None
    assert b.spec.rules[2].to is None


def test_boundaries_rejects_unknown_effect() -> None:
    with pytest.raises(ValidationError):
        Boundaries.model_validate({
            "apiVersion": "agent-readiness.io/v1",
            "kind": "Boundaries",
            "spec": {"tagAxes": {"t": ["a"]},
                     "rules": [{"name": "x", "effect": "purple"}]},
        })


def test_arch_rule_file_exists_predicate() -> None:
    r = ArchRule.model_validate({
        "apiVersion": "agent-readiness.io/v1",
        "kind": "ArchRule",
        "metadata": {"id": "001-test", "severity": "error"},
        "spec": {"description": "test",
                 "selector": {"kind": "service"},
                 "assert": {"file_exists": ".github/workflows/deploy.yml"}},
    })
    assert r.metadata.severity == "error"
    assert r.spec.assert_.file_exists == ".github/workflows/deploy.yml"


def test_arch_rule_command_exit_zero_with_sandbox_override() -> None:
    r = ArchRule.model_validate({
        "apiVersion": "agent-readiness.io/v1",
        "kind": "ArchRule",
        "metadata": {"id": "002-test", "severity": "warn"},
        "spec": {"description": "test",
                 "selector": {},
                 "assert": {"command_exit_zero": "make test",
                            "sandbox": {"image": "ghcr.io/example/img:1"}}},
    })
    assert r.spec.assert_.command_exit_zero == "make test"
    assert r.spec.assert_.sandbox.image == "ghcr.io/example/img:1"


def test_arch_rule_requires_exactly_one_predicate() -> None:
    with pytest.raises(ValidationError):
        ArchRule.model_validate({
            "apiVersion": "agent-readiness.io/v1",
            "kind": "ArchRule",
            "metadata": {"id": "x", "severity": "error"},
            "spec": {"description": "x", "selector": {},
                     "assert": {"file_exists": "a", "file_not_exists": "b"}},
        })


def test_repository_minimal() -> None:
    r = Repository.model_validate({
        "apiVersion": "agent-readiness.io/v1",
        "kind": "Repository",
        "metadata": {"name": "hello-service", "owner": "platform"},
        "spec": {"kind": "service", "lifecycle": "experimental",
                 "visibility": "public",
                 "tags": ["scope:protocol", "tier:internal"],
                 "dependencies": [], "entrypoints": {},
                 "commands": {"test": "make test"},
                 "skills": {"workspace": [], "repo": []}},
    })
    assert r.spec.kind == "service"
    assert "tier:internal" in r.spec.tags


def test_repository_rejects_unknown_kind() -> None:
    with pytest.raises(ValidationError):
        Repository.model_validate({
            "apiVersion": "agent-readiness.io/v1",
            "kind": "Repository",
            "metadata": {"name": "x", "owner": "x"},
            "spec": {"kind": "nonsense", "lifecycle": "experimental",
                     "visibility": "public", "tags": [], "dependencies": [],
                     "entrypoints": {}, "commands": {}, "skills": {}},
        })


def test_session_minimal() -> None:
    s = Session.model_validate({
        "apiVersion": "agent-readiness.io/v1",
        "kind": "Session",
        "metadata": {"id": "2026-05-22-claude-abc",
                     "agent": "claude-opus-4-7",
                     "started": "2026-05-22T14:23:00Z",
                     "ttl": "4h"},
        "spec": {"intent": "test", "repos": [
            {"name": "a", "mode": "write"}], "branches": {},
                 "manifest_artifacts": []},
    })
    assert s.metadata.agent == "claude-opus-4-7"
    assert s.spec.repos[0].mode == "write"


def test_session_rejects_invalid_mode() -> None:
    with pytest.raises(ValidationError):
        Session.model_validate({
            "apiVersion": "agent-readiness.io/v1",
            "kind": "Session",
            "metadata": {"id": "x", "agent": "x",
                         "started": "2026-05-22T00:00:00Z", "ttl": "1h"},
            "spec": {"intent": "x",
                     "repos": [{"name": "a", "mode": "delete"}],
                     "branches": {}, "manifest_artifacts": []},
        })


def test_migration_minimal() -> None:
    m = Migration.model_validate({
        "apiVersion": "agent-readiness.io/v1",
        "kind": "Migration",
        "spec": {"steps": [
            {"rename_field": {"from": "spec.kind", "to": "spec.repoKind",
                              "in": "**/agents.yaml"}},
            {"move_file": {"from": ".old", "to": ".new"}},
            {"set_default": {"field": "spec.visibility", "value": "public",
                             "in": "**/agents.yaml"}},
        ]},
    })
    assert m.spec.steps[0].rename_field.from_ == "spec.kind"
    assert m.spec.steps[1].move_file.to == ".new"
