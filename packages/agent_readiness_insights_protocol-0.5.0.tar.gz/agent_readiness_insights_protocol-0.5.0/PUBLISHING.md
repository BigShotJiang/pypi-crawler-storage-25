# Publishing

Releases ship via `.github/workflows/release.yml` on a `v*` tag push.
The workflow:

1. Builds wheel + sdist with `python -m build`.
2. Publishes to PyPI via **OIDC trusted publishing** (no API token).
3. Creates a GitHub Release with auto-generated notes + the
   wheel/sdist as assets.
4. Smoke-tests the published wheel by `pip install`ing it and
   asserting `__version__`, `fix_prompt` on `Rule`/`Finding`.

## Tagging a release

```bash
# 1. Bump version in pyproject.toml and src/.../__init__.py.
# 2. Commit + PR + merge to main.
# 3. From main:
git tag -a vX.Y.Z -m "vX.Y.Z — short description"
git push origin vX.Y.Z
```

That's it — the workflow fires on the tag push and runs the four
steps above end-to-end.

## One-time PyPI trusted publisher setup

For the publish step to succeed, PyPI must have a *pending publisher*
registered for this project. Configure it once at:

  https://pypi.org/manage/account/publishing/

with:

  - PyPI project name:  `agent-readiness-insights-protocol`
  - Owner:              `harrydaihaolin`
  - Repository name:    `agent-readiness-insights-protocol`
  - Workflow filename:  `release.yml`
  - Environment name:   `pypi`

A matching GitHub Environment named `pypi` must exist in this repo
(GitHub → Settings → Environments). The workflow declares
`environment: name: pypi` so the OIDC token GitHub mints is scoped
to that environment.

## Fallback: manual upload

If trusted publishing isn't configured yet, you can still ship a
release by uploading manually from your local machine:

```bash
make build
twine upload dist/*
```

This requires a PyPI API token in `~/.pypirc`:

```ini
[pypi]
username = __token__
password = pypi-AgENd...
```

This is a hatch for emergencies; the trusted-publisher path is the
canonical one going forward.

## Coordinating bumps

Before bumping `PROTOCOL_VERSION` or `RULES_VERSION`, open a tracking issue
in:

- `harrydaihaolin/agent-readiness` (consumer of `RULES_VERSION`)
- `harrydaihaolin/agent-readiness-rules` (declares `protocol_compat`)
- `harrydaihaolin/agent-readiness-pro` (consumer of `PROTOCOL_VERSION`)
- `harrydaihaolin/agent-readiness-insights` (engine; consumer of both)

Land the bump here last; downstream PRs widen their compat ranges first.
