"""Export JSON schemas for the 7 workspace-starter models."""
from __future__ import annotations

import json
from pathlib import Path

from agent_readiness_insights_protocol.models import (
    ArchRule,
    Boundaries,
    Glossary,
    Migration,
    Repository,
    Session,
    WorkspaceManifest,
)

OUTPUT_DIR = Path(__file__).resolve().parent.parent / "schemas"

EXPORTS = {
    "workspace-manifest": WorkspaceManifest,
    "glossary":           Glossary,
    "boundaries":         Boundaries,
    "arch-rule":          ArchRule,
    "repository":         Repository,
    "session":            Session,
    "migration":          Migration,
}


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    for name, cls in EXPORTS.items():
        schema = cls.model_json_schema(by_alias=True)
        out = OUTPUT_DIR / f"{name}.schema.json"
        out.write_text(json.dumps(schema, indent=2, sort_keys=True) + "\n")
        print(f"wrote {out.relative_to(OUTPUT_DIR.parent)}")


if __name__ == "__main__":
    main()
