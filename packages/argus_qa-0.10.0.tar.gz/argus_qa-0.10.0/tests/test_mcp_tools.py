#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 ARGUS — Tests unitaires des outils MCP (Sprint 1 — Fiabilité)

 Couverture :
   1. query_memory       — Toutes les sections, erreurs, données malformées
   2. get_risk_analysis  — Pattern matching, limites, signaux techniques
   3. get_testing_strategy — Heuristiques, profils, types de changement
   4. record_analysis    — Écriture, limites, rate limiting, concurrence
   5. _file_lock         — Verrou fichier cross-platform
   6. _get_technical_signals — Regex de détection par pattern
═══════════════════════════════════════════════════════════════════════════════
"""

import json
import re
import threading
import time
from pathlib import Path

import pytest
import yaml


# ═══════════════════════════════════════════════════════════════════════════════
#  HELPERS
# ═══════════════════════════════════════════════════════════════════════════════


def _write_yaml(path: Path, data: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        yaml.dump(data, default_flow_style=False, allow_unicode=True, sort_keys=False),
        encoding="utf-8",
    )


def _parse_result(result: str) -> dict:
    """Parse le JSON retourné par un tool MCP."""
    return json.loads(result)


# ═══════════════════════════════════════════════════════════════════════════════
#  FIXTURE — Mémoire MCP isolée
# ═══════════════════════════════════════════════════════════════════════════════


@pytest.fixture
def mcp_env(tmp_path, monkeypatch):
    """Crée un environnement MCP isolé avec mémoire minimale réaliste.

    Redirige ARGUS_DATA_DIR vers un dossier temporaire et retourne
    le chemin racine de la mémoire + les modules serveur importés.
    """
    memory = tmp_path / "memory"
    for sub in [
        "semantic",
        "episodic/analyses",
        "episodic/decisions",
        "episodic/incidents",
        "episodic/executions",
        "projects",
        "relational",
        "working",
    ]:
        (memory / sub).mkdir(parents=True, exist_ok=True)

    # Persona
    (tmp_path / "argus.persona.yaml").write_text(
        "version: '0.10.0'\nlast_updated: '2026-03-01'\n",
        encoding="utf-8",
    )

    # _index.yaml
    _write_yaml(
        memory / "_index.yaml",
        {
            "version": "1.0.0",
            "last_updated": "2026-03-01",
            "episodic": {
                "analyses": {"count": 0, "latest": None, "path": "memory/episodic/analyses/"},
                "decisions": {"count": 0, "latest": None, "path": "memory/episodic/decisions/"},
                "incidents": {"count": 0, "latest": None, "path": "memory/episodic/incidents/"},
                "executions": {"count": 0, "latest": None, "path": "memory/episodic/executions/"},
            },
            "semantic": {
                "defect_patterns": {"count": 5, "path": "memory/semantic/defect_patterns.yaml"},
                "testing_heuristics": {
                    "count": 4,
                    "path": "memory/semantic/testing_heuristics.yaml",
                },
            },
            "projects": {"count": 1, "path": "memory/projects/"},
            "relational": {"path": "memory/relational/associations.yaml"},
            "statistics": {
                "totals": {"episodes": 0, "patterns": 5, "heuristics": 4, "projects": 1},
            },
            "sequences": {
                "analysis": 0,
                "decision": 0,
                "incident": 0,
                "execution": 0,
                "pattern": 5,
                "heuristic": 4,
            },
        },
    )

    # Patterns (5 patterns couvrant security, async, null_safety, xss)
    _write_yaml(
        memory / "semantic" / "defect_patterns.yaml",
        {
            "metadata": {"total_patterns": 5},
            "patterns": [
                {
                    "id": "PAT-SEC-001",
                    "name": "SQL Injection",
                    "category": "security",
                    "severity_typical": "critical",
                    "confidence": 0.95,
                    "signature": {
                        "description": "SQL injection via string concatenation or f-strings",
                        "indicators": ["user input in SQL query", "string concatenation in query"],
                        "code_patterns": ["f-string with select", "format with insert"],
                    },
                    "detection_strategy": {"tools": ["sqlfluff", "bandit"]},
                    "prevention_strategy": ["Use parameterized queries", "Use ORM"],
                },
                {
                    "id": "PAT-SEC-002",
                    "name": "Sensitive Data Exposure",
                    "category": "security",
                    "severity_typical": "critical",
                    "confidence": 0.90,
                    "signature": {
                        "description": "Sensitive data exposed in code or logs",
                        "indicators": ["hardcoded password", "api key in source code"],
                        "code_patterns": [
                            "password assignment in source",
                            "api_key variable with literal",
                        ],
                    },
                    "detection_strategy": {"tools": ["gitleaks", "trufflehog"]},
                    "prevention_strategy": ["Use environment variables", "Use secret manager"],
                },
                {
                    "id": "PAT-SEC-003",
                    "name": "Cross-Site Scripting (XSS)",
                    "category": "security",
                    "severity_typical": "high",
                    "confidence": 0.88,
                    "signature": {
                        "description": "XSS via innerHTML or dangerouslySetInnerHTML",
                        "indicators": ["user input in innerHTML", "unescaped HTML output"],
                        "code_patterns": ["innerHTML assignment", "dangerouslySetInnerHTML usage"],
                    },
                    "detection_strategy": {"tools": ["eslint-plugin-security", "semgrep"]},
                    "prevention_strategy": [
                        "Use textContent instead of innerHTML",
                        "Sanitize HTML input",
                    ],
                },
                {
                    "id": "PAT-ASYNC-001",
                    "name": "Race Condition",
                    "category": "async",
                    "severity_typical": "high",
                    "confidence": 0.92,
                    "signature": {
                        "description": "Race condition on shared mutable state",
                        "indicators": ["shared state modified by multiple threads"],
                        "code_patterns": ["global variable access without lock"],
                    },
                    "detection_strategy": {"tools": ["pyright"]},
                    "prevention_strategy": ["Use locks", "Use immutable data"],
                },
                {
                    "id": "PAT-NULL-001",
                    "name": "Null Reference",
                    "category": "null_safety",
                    "severity_typical": "medium",
                    "confidence": 0.99,
                    "signature": {
                        "description": "Accessing optional field without null check",
                        "indicators": ["optional field access", "deep property chaining"],
                        "code_patterns": ["result.data.items accessing nested"],
                    },
                    "detection_strategy": {"tools": ["pyright", "mypy"]},
                    "prevention_strategy": ["Optional chaining", "Default values"],
                },
            ],
        },
    )

    # Heuristics (4 heuristiques)
    _write_yaml(
        memory / "semantic" / "testing_heuristics.yaml",
        {
            "metadata": {"total_heuristics": 4},
            "test_selection": [
                {
                    "id": "HEU-SEL-001",
                    "name": "Test What Changed",
                    "category": "selection",
                    "condition": "code changed in feature or bugfix",
                    "action": "Run tests for changed modules first",
                    "rationale": "Most defects are near recent changes",
                    "priority": "P0",
                    "confidence": 0.95,
                },
                {
                    "id": "HEU-SEL-003",
                    "name": "Critical Path Always",
                    "category": "selection",
                    "condition": "auth, payment, or data component affected",
                    "action": "Always run full test suite for critical components",
                    "rationale": "Critical paths have highest business impact",
                    "priority": "P0",
                    "confidence": 0.90,
                },
            ],
            "coverage": [
                {
                    "id": "HEU-COV-001",
                    "name": "Boundary Value Testing",
                    "category": "coverage",
                    "condition": "complex logic with numeric ranges",
                    "action": "Test min, max, and boundary-adjacent values",
                    "rationale": "Off-by-one errors are common",
                    "priority": "P1",
                    "confidence": 0.88,
                },
            ],
            "automation": [
                {
                    "id": "HEU-AUT-001",
                    "name": "Automate Regression",
                    "category": "automation",
                    "condition": "bugfix on previously tested feature",
                    "action": "Add regression test for the specific bug",
                    "rationale": "Prevent bug reintroduction",
                    "priority": "P0",
                    "confidence": 0.93,
                },
            ],
        },
    )

    # Context profiles
    _write_yaml(
        memory / "semantic" / "context_profiles.yaml",
        {
            "profiles": [
                {
                    "id": "CTX-GENERIC",
                    "name": "Contexte générique",
                    "risk_multipliers": {},
                    "mandatory_checks": [],
                    "recommended_heuristics": [],
                    "priority_patterns": [],
                },
                {
                    "id": "CTX-FINTECH",
                    "name": "Contexte Fintech",
                    "risk_multipliers": {"data_integrity": 3.0, "security": 2.5},
                    "mandatory_checks": ["PCI-DSS compliance", "Audit trail verification"],
                    "recommended_heuristics": ["HEU-SEL-003"],
                    "priority_patterns": ["PAT-SEC-001"],
                },
            ],
        },
    )

    # Technology knowledge
    _write_yaml(
        memory / "semantic" / "technology_knowledge.yaml",
        {
            "languages": ["Python", "JavaScript"],
        },
    )

    # ISTQB knowledge
    _write_yaml(
        memory / "semantic" / "istqb_knowledge.yaml",
        {
            "source": "ISTQB Foundation Level v4.0",
        },
    )

    # Project
    _write_yaml(
        memory / "projects" / "testproj.yaml",
        {
            "identity": {"project_id": "testproj", "name": "Test Project"},
        },
    )

    # Associations
    _write_yaml(memory / "relational" / "associations.yaml", {"associations": []})

    # Rediriger ARGUS_DATA_DIR
    monkeypatch.setenv("ARGUS_DATA_DIR", str(memory))

    # Import les modules après avoir configuré l'env
    from mcp_server import memory_reader as mem_mod
    from mcp_server import server as srv_mod

    return {
        "memory": memory,
        "root": tmp_path,
        "server": srv_mod,
        "mem": mem_mod,
    }


# ═══════════════════════════════════════════════════════════════════════════════
#  TESTS — query_memory
# ═══════════════════════════════════════════════════════════════════════════════


class TestQueryMemory:
    """Tests pour le tool query_memory."""

    def test_query_patterns_returns_all(self, mcp_env):
        result = _parse_result(mcp_env["server"].query_memory("patterns"))
        assert result["section"] == "patterns"
        assert result["result_count"] == 5

    def test_query_patterns_by_category(self, mcp_env):
        result = _parse_result(mcp_env["server"].query_memory("patterns", category="security"))
        assert result["result_count"] == 3
        ids = [p["id"] for p in result["results"]]
        assert "PAT-SEC-001" in ids

    def test_query_patterns_by_confidence(self, mcp_env):
        result = _parse_result(mcp_env["server"].query_memory("patterns", min_confidence=0.95))
        assert (
            result["result_count"] == 2
        )  # PAT-SEC-001 (0.95) + PAT-NULL-001 (0.99), PAT-SEC-002 is 0.90

    def test_query_patterns_by_text(self, mcp_env):
        result = _parse_result(mcp_env["server"].query_memory("patterns", query="injection"))
        assert result["result_count"] == 1

    def test_query_heuristics_returns_all(self, mcp_env):
        result = _parse_result(mcp_env["server"].query_memory("heuristics"))
        assert result["result_count"] == 4

    def test_query_heuristics_by_category(self, mcp_env):
        result = _parse_result(mcp_env["server"].query_memory("heuristics", category="selection"))
        assert result["result_count"] == 2

    def test_query_analyses_empty(self, mcp_env):
        result = _parse_result(mcp_env["server"].query_memory("analyses"))
        assert result["result_count"] == 0

    def test_query_projects(self, mcp_env):
        result = _parse_result(mcp_env["server"].query_memory("projects"))
        assert result["result_count"] == 1

    def test_query_profiles(self, mcp_env):
        result = _parse_result(mcp_env["server"].query_memory("profiles"))
        assert result["result_count"] == 2

    def test_query_associations(self, mcp_env):
        result = _parse_result(mcp_env["server"].query_memory("associations"))
        assert "associations" in result["results"]

    def test_query_stats(self, mcp_env):
        result = _parse_result(mcp_env["server"].query_memory("stats"))
        assert result["results"]["counts"]["patterns"] == 5

    def test_query_index(self, mcp_env):
        result = _parse_result(mcp_env["server"].query_memory("index"))
        assert result["results"]["version"] == "1.0.0"

    def test_query_unknown_section(self, mcp_env):
        result = _parse_result(mcp_env["server"].query_memory("nonexistent"))
        assert "error" in result
        assert "available_sections" in result

    def test_query_section_case_insensitive(self, mcp_env):
        result = _parse_result(mcp_env["server"].query_memory("PATTERNS"))
        assert result["section"] == "patterns"
        assert result["result_count"] == 5

    def test_query_section_with_whitespace(self, mcp_env):
        result = _parse_result(mcp_env["server"].query_memory("  patterns  "))
        assert result["section"] == "patterns"

    def test_query_memory_handles_corrupted_yaml(self, mcp_env):
        """Vérifie que query_memory retourne une erreur JSON quand le YAML est corrompu."""
        # Corrompre le fichier patterns
        patterns_path = mcp_env["memory"] / "semantic" / "defect_patterns.yaml"
        patterns_path.write_text(": : : invalid yaml {{[", encoding="utf-8")

        result = _parse_result(mcp_env["server"].query_memory("patterns"))
        # Doit retourner un résultat vide ou une erreur, pas crasher
        assert "result_count" in result or "error" in result

    def test_query_memory_handles_missing_file(self, mcp_env):
        """Vérifie le comportement quand un fichier mémoire est absent."""
        (mcp_env["memory"] / "semantic" / "defect_patterns.yaml").unlink()

        result = _parse_result(mcp_env["server"].query_memory("patterns"))
        assert result["result_count"] == 0


# ═══════════════════════════════════════════════════════════════════════════════
#  TESTS — get_risk_analysis
# ═══════════════════════════════════════════════════════════════════════════════


class TestGetRiskAnalysis:
    """Tests pour le tool get_risk_analysis."""

    def test_detects_sql_injection(self, mcp_env):
        code = """
def get_user(user_id):
    query = f"select * from users where id = {user_id}"
    return db.execute(query)
"""
        result = _parse_result(mcp_env["server"].get_risk_analysis(code))
        assert result["risk_level"] in ("critical", "high")
        assert result["patterns_matched"] >= 1
        # Vérifier que PAT-SEC-001 est dans les findings
        pattern_ids = [f["pattern_id"] for f in result["findings"]]
        assert "PAT-SEC-001" in pattern_ids

    def test_detects_sensitive_data(self, mcp_env):
        code = """
password = "super_secret_123"
api_key = "sk-1234567890"
"""
        result = _parse_result(mcp_env["server"].get_risk_analysis(code))
        assert result["patterns_matched"] >= 1

    def test_detects_xss_innerhtml(self, mcp_env):
        """Vérifie la détection de XSS via innerHTML."""
        code = """
element.innerHTML = userInput;
document.write(unsafeData);
"""
        result = _parse_result(mcp_env["server"].get_risk_analysis(code))
        assert result["patterns_matched"] >= 1
        pattern_ids = [f["pattern_id"] for f in result["findings"]]
        assert "PAT-SEC-003" in pattern_ids

    def test_clean_code_low_risk(self, mcp_env):
        code = """
def add(a: int, b: int) -> int:
    return a + b
"""
        result = _parse_result(mcp_env["server"].get_risk_analysis(code))
        assert result["risk_level"] == "low"
        assert result["patterns_matched"] == 0

    def test_context_profile_fintech_higher_risk(self, mcp_env):
        code = """
def get_user(user_id):
    query = f"select * from users where id = {user_id}"
    return db.execute(query)
"""
        result_generic = _parse_result(
            mcp_env["server"].get_risk_analysis(code, context_profile="CTX-GENERIC")
        )
        result_fintech = _parse_result(
            mcp_env["server"].get_risk_analysis(code, context_profile="CTX-FINTECH")
        )
        # Fintech devrait avoir un risk_score plus élevé pour security
        generic_max = result_generic["max_risk_score"]
        fintech_max = result_fintech["max_risk_score"]
        assert fintech_max >= generic_max

    def test_unknown_profile_falls_back_to_generic(self, mcp_env):
        code = "x = 1"
        result = _parse_result(
            mcp_env["server"].get_risk_analysis(code, context_profile="CTX-UNKNOWN")
        )
        assert result["context_profile"] == "CTX-UNKNOWN"
        assert result["risk_level"] == "low"

    def test_input_too_large_rejected(self, mcp_env):
        huge_input = "x" * 500_001
        result = _parse_result(mcp_env["server"].get_risk_analysis(huge_input))
        assert "error" in result
        assert "500000" in result["error"] or "volumineux" in result["error"]

    def test_input_at_limit_accepted(self, mcp_env):
        code = "x = 1\n" * 50_000  # Under 500KB
        result = _parse_result(mcp_env["server"].get_risk_analysis(code))
        assert "error" not in result
        assert result["analysis_type"] == "risk_analysis"

    def test_file_path_included(self, mcp_env):
        result = _parse_result(
            mcp_env["server"].get_risk_analysis("x = 1", file_path="src/main.py")
        )
        assert result["file_path"] == "src/main.py"

    def test_findings_sorted_by_risk_score(self, mcp_env):
        """Les findings doivent être triés par risk_score décroissant."""
        code = """
query = f"select * from users where id = {user_id}"
shared_state = global_counter
result.data.items.name.value
"""
        result = _parse_result(mcp_env["server"].get_risk_analysis(code))
        scores = [f["risk_score"] for f in result["findings"]]
        assert scores == sorted(scores, reverse=True)

    def test_mandatory_checks_from_profile(self, mcp_env):
        result = _parse_result(
            mcp_env["server"].get_risk_analysis("x = 1", context_profile="CTX-FINTECH")
        )
        assert "PCI-DSS compliance" in result["mandatory_checks"]

    def test_handles_corrupted_patterns(self, mcp_env):
        """Vérifie la résilience quand les patterns sont corrompus."""
        patterns_path = mcp_env["memory"] / "semantic" / "defect_patterns.yaml"
        patterns_path.write_text("{{invalid", encoding="utf-8")

        result = _parse_result(mcp_env["server"].get_risk_analysis("x = 1"))
        assert "error" in result


# ═══════════════════════════════════════════════════════════════════════════════
#  TESTS — get_testing_strategy
# ═══════════════════════════════════════════════════════════════════════════════


class TestGetTestingStrategy:
    """Tests pour le tool get_testing_strategy."""

    def test_feature_returns_unit_integration_e2e(self, mcp_env):
        result = _parse_result(
            mcp_env["server"].get_testing_strategy(
                "Ajout d'un formulaire de login",
                change_type="feature",
            )
        )
        test_types = [t["type"] for t in result["test_types_recommended"]]
        assert "unit" in test_types
        assert "integration" in test_types

    def test_bugfix_includes_regression(self, mcp_env):
        result = _parse_result(
            mcp_env["server"].get_testing_strategy(
                "Fix du bug de calcul de prix",
                change_type="bugfix",
            )
        )
        test_types = [t["type"] for t in result["test_types_recommended"]]
        assert "regression" in test_types

    def test_security_change_includes_security_tests(self, mcp_env):
        result = _parse_result(
            mcp_env["server"].get_testing_strategy(
                "Renforcement de l'authentification JWT",
                change_type="security",
            )
        )
        test_types = [t["type"] for t in result["test_types_recommended"]]
        assert "security" in test_types

    def test_critical_component_adds_security(self, mcp_env):
        result = _parse_result(
            mcp_env["server"].get_testing_strategy(
                "Modification du module d'authentification",
                change_type="feature",
                components_affected=["auth"],
            )
        )
        test_types = [t["type"] for t in result["test_types_recommended"]]
        assert "security" in test_types

    def test_fintech_profile_includes_mandatory_checks(self, mcp_env):
        result = _parse_result(
            mcp_env["server"].get_testing_strategy(
                "Modification du calcul des frais",
                context_profile="CTX-FINTECH",
            )
        )
        assert "PCI-DSS compliance" in result["mandatory_checks"]

    def test_heuristics_matched_by_change_type(self, mcp_env):
        result = _parse_result(
            mcp_env["server"].get_testing_strategy(
                "Feature de recherche avancée",
                change_type="feature",
            )
        )
        # HEU-SEL-001 a condition "code changed in feature or bugfix"
        heuristic_ids = [h["id"] for h in result["applicable_heuristics"]]
        assert "HEU-SEL-001" in heuristic_ids

    def test_heuristics_limited_to_10(self, mcp_env):
        result = _parse_result(
            mcp_env["server"].get_testing_strategy(
                "Grosse refonte avec auth payment data",
                change_type="feature",
                components_affected=["auth", "payment", "data", "api"],
            )
        )
        assert len(result["applicable_heuristics"]) <= 10

    def test_risk_patterns_limited_to_10(self, mcp_env):
        result = _parse_result(
            mcp_env["server"].get_testing_strategy(
                "Modification SQL et injection de données",
            )
        )
        assert len(result["risk_patterns"]) <= 10

    def test_unknown_change_type_uses_feature_default(self, mcp_env):
        result = _parse_result(
            mcp_env["server"].get_testing_strategy(
                "Random change",
                change_type="unknown_type",
            )
        )
        # Devrait fallback vers "feature"
        test_types = [t["type"] for t in result["test_types_recommended"]]
        assert "unit" in test_types

    def test_handles_corrupted_memory(self, mcp_env):
        """Vérifie la résilience quand la mémoire est corrompue."""
        (mcp_env["memory"] / "semantic" / "testing_heuristics.yaml").write_text(
            "{{bad", encoding="utf-8"
        )
        result = _parse_result(mcp_env["server"].get_testing_strategy("test"))
        assert "error" in result

    def test_components_match_in_heuristics(self, mcp_env):
        """Vérifie que les composants affectés augmentent la pertinence des heuristiques."""
        result = _parse_result(
            mcp_env["server"].get_testing_strategy(
                "Modification des permissions",
                components_affected=["auth"],
            )
        )
        # HEU-SEL-003 a condition "auth, payment, or data component affected"
        heuristic_ids = [h["id"] for h in result["applicable_heuristics"]]
        assert "HEU-SEL-003" in heuristic_ids


# ═══════════════════════════════════════════════════════════════════════════════
#  TESTS — record_analysis
# ═══════════════════════════════════════════════════════════════════════════════


class TestRecordAnalysis:
    """Tests pour le tool record_analysis."""

    def test_record_basic_analysis(self, mcp_env):
        result = _parse_result(
            mcp_env["server"].record_analysis(
                title="Test Analysis",
                findings=[
                    {
                        "title": "Bug found",
                        "risk_level": "medium",
                        "category": "bug",
                        "description": "A bug was found",
                        "recommendation": "Fix it",
                    }
                ],
            )
        )
        assert result["status"] == "success"
        assert result["analysis_id"].startswith("ANL-")
        assert result["findings_count"] == 1

    def test_record_creates_yaml_file(self, mcp_env):
        mcp_env["server"].record_analysis(
            title="File Test",
            findings=[{"title": "F1", "risk_level": "low"}],
        )
        analyses_dir = mcp_env["memory"] / "episodic" / "analyses"
        yaml_files = list(analyses_dir.glob("*.yaml"))
        assert len(yaml_files) == 1

    def test_record_updates_index(self, mcp_env):
        mcp_env["server"].record_analysis(
            title="Index Test",
            findings=[{"title": "F1", "risk_level": "low"}],
        )
        index = yaml.safe_load((mcp_env["memory"] / "_index.yaml").read_text(encoding="utf-8"))
        assert index["episodic"]["analyses"]["count"] == 1
        assert index["episodic"]["analyses"]["latest"].startswith("ANL-")

    def test_record_sequential_ids(self, mcp_env):
        r1 = _parse_result(
            mcp_env["server"].record_analysis(
                title="First",
                findings=[{"title": "F1"}],
            )
        )
        r2 = _parse_result(
            mcp_env["server"].record_analysis(
                title="Second",
                findings=[{"title": "F2"}],
            )
        )
        # Les IDs doivent être séquentiels
        assert r1["analysis_id"].endswith("-001")
        assert r2["analysis_id"].endswith("-002")

    def test_record_with_all_parameters(self, mcp_env):
        result = _parse_result(
            mcp_env["server"].record_analysis(
                title="Full Test",
                findings=[
                    {
                        "title": "Critical Bug",
                        "risk_level": "critical",
                        "category": "security",
                        "description": "SQL injection found",
                        "recommendation": "Use parameterized queries",
                        "related_patterns": ["PAT-SEC-001"],
                        "related_heuristics": ["HEU-SEL-001"],
                        "confidence": 0.95,
                    }
                ],
                project="myproject",
                trigger="PR_merge",
                scope_type="PR",
                scope_reference="PR-123",
                verdict="rejected",
            )
        )
        assert result["status"] == "success"

        # Vérifier le contenu du fichier YAML
        analyses_dir = mcp_env["memory"] / "episodic" / "analyses"
        yaml_file = list(analyses_dir.glob("*.yaml"))[0]
        analysis = yaml.safe_load(yaml_file.read_text(encoding="utf-8"))
        assert analysis["project"] == "myproject"
        assert analysis["trigger"] == "PR_merge"
        assert analysis["scope"]["type"] == "PR"
        assert analysis["verdict"]["status"] == "rejected"
        assert analysis["findings"][0]["confidence"] == 0.95

    def test_record_too_many_findings_rejected(self, mcp_env):
        findings = [{"title": f"F{i}", "risk_level": "low"} for i in range(51)]
        result = _parse_result(
            mcp_env["server"].record_analysis(
                title="Too Many",
                findings=findings,
            )
        )
        assert "error" in result
        assert "50" in result["error"]

    def test_record_max_findings_accepted(self, mcp_env):
        findings = [{"title": f"F{i}", "risk_level": "low"} for i in range(50)]
        result = _parse_result(
            mcp_env["server"].record_analysis(
                title="Max Findings",
                findings=findings,
            )
        )
        assert result["status"] == "success"
        assert result["findings_count"] == 50

    def test_record_daily_rate_limit(self, mcp_env):
        """Vérifie la limite de 100 analyses par jour."""
        analyses_dir = mcp_env["memory"] / "episodic" / "analyses"
        # Créer 100 fichiers simulant des analyses d'aujourd'hui
        from datetime import datetime, timezone

        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        for i in range(100):
            (analyses_dir / f"{today}_fake_{i:03d}.yaml").write_text("id: fake", encoding="utf-8")

        result = _parse_result(
            mcp_env["server"].record_analysis(
                title="Over Limit",
                findings=[{"title": "F1"}],
            )
        )
        assert "error" in result
        assert "100" in result["error"] or "journalière" in result["error"]

    def test_record_empty_findings(self, mcp_env):
        result = _parse_result(
            mcp_env["server"].record_analysis(
                title="No Findings",
                findings=[],
            )
        )
        assert result["status"] == "success"
        assert result["findings_count"] == 0

    def test_record_default_field_values(self, mcp_env):
        """Vérifie que les findings ont des valeurs par défaut correctes."""
        mcp_env["server"].record_analysis(
            title="Defaults Test",
            findings=[{"title": "Minimal finding"}],
        )
        analyses_dir = mcp_env["memory"] / "episodic" / "analyses"
        yaml_file = list(analyses_dir.glob("*.yaml"))[0]
        analysis = yaml.safe_load(yaml_file.read_text(encoding="utf-8"))
        finding = analysis["findings"][0]
        assert finding["risk_level"] == "medium"  # default
        assert finding["category"] == "finding"  # default
        assert finding["confidence"] == 0.7  # default


# ═══════════════════════════════════════════════════════════════════════════════
#  TESTS — _file_lock (concurrence)
# ═══════════════════════════════════════════════════════════════════════════════


class TestFileLock:
    """Tests pour le mécanisme de verrou fichier."""

    def test_lock_creates_and_removes_lock_file(self, mcp_env):
        target = mcp_env["memory"] / "_index.yaml"
        lock_file = target.with_suffix(".yaml.lock")

        with mcp_env["server"]._file_lock(target):
            assert lock_file.exists()

        assert not lock_file.exists()

    def test_lock_released_on_exception(self, mcp_env):
        target = mcp_env["memory"] / "_index.yaml"
        lock_file = target.with_suffix(".yaml.lock")

        with pytest.raises(ValueError):
            with mcp_env["server"]._file_lock(target):
                raise ValueError("test error")

        assert not lock_file.exists()

    def test_concurrent_locks_serialize(self, mcp_env):
        """Vérifie que deux threads ne peuvent pas écrire simultanément."""
        target = mcp_env["memory"] / "_index.yaml"
        results = []
        barrier = threading.Barrier(2)

        def writer(value):
            barrier.wait()
            with mcp_env["server"]._file_lock(target):
                # Simuler une écriture
                time.sleep(0.05)
                results.append(value)

        t1 = threading.Thread(target=writer, args=(1,))
        t2 = threading.Thread(target=writer, args=(2,))
        t1.start()
        t2.start()
        t1.join(timeout=15)
        t2.join(timeout=15)
        assert not t1.is_alive(), "Thread 1 deadlocked"
        assert not t2.is_alive(), "Thread 2 deadlocked"

        assert sorted(results) == [1, 2]
        # Le lock file doit être nettoyé
        assert not target.with_suffix(".yaml.lock").exists()

    def test_concurrent_record_analysis_no_id_collision(self, mcp_env):
        """Vérifie que deux record_analysis concurrents ont des IDs différents."""
        results = []
        barrier = threading.Barrier(2)

        def record(idx):
            barrier.wait()
            r = _parse_result(
                mcp_env["server"].record_analysis(
                    title=f"Concurrent Analysis {idx}",
                    findings=[{"title": f"Finding {idx}"}],
                )
            )
            results.append(r)

        t1 = threading.Thread(target=record, args=(1,))
        t2 = threading.Thread(target=record, args=(2,))
        t1.start()
        t2.start()
        t1.join(timeout=15)
        t2.join(timeout=15)
        assert not t1.is_alive(), "Thread 1 deadlocked"
        assert not t2.is_alive(), "Thread 2 deadlocked"

        assert all(r["status"] == "success" for r in results)
        ids = [r["analysis_id"] for r in results]
        assert len(set(ids)) == 2, f"IDs should be unique but got: {ids}"


# ═══════════════════════════════════════════════════════════════════════════════
#  TESTS — _get_technical_signals (regex)
# ═══════════════════════════════════════════════════════════════════════════════


class TestTechnicalSignals:
    """Tests pour les regex de détection de signaux techniques."""

    def test_sql_injection_fstring_select(self, mcp_env):
        signals = mcp_env["server"]._get_technical_signals("PAT-SEC-001", "security")
        code = 'f"select * from users where id = {user_id}"'
        matched = [s for s, w in signals if re.search(s, code.lower())]
        assert len(matched) >= 1

    def test_sql_injection_fstring_insert(self, mcp_env):
        signals = mcp_env["server"]._get_technical_signals("PAT-SEC-001", "security")
        code = 'f"insert into logs values ({data})"'
        matched = [s for s, w in signals if re.search(s, code.lower())]
        assert len(matched) >= 1

    def test_sql_injection_format(self, mcp_env):
        signals = mcp_env["server"]._get_technical_signals("PAT-SEC-001", "security")
        code = '"select * from users where id = {}".format(user_id)'
        matched = [s for s, w in signals if re.search(s, code.lower())]
        assert len(matched) >= 1

    def test_sql_injection_execute_concat(self, mcp_env):
        signals = mcp_env["server"]._get_technical_signals("PAT-SEC-001", "security")
        code = 'cursor.execute("select * from t where id = " + user_id)'
        matched = [s for s, w in signals if re.search(s, code.lower())]
        assert len(matched) >= 1

    def test_sensitive_data_password(self, mcp_env):
        signals = mcp_env["server"]._get_technical_signals("PAT-SEC-002", "security")
        code = 'password = "hunter2"'
        matched = [s for s, w in signals if re.search(s, code.lower())]
        assert len(matched) >= 1

    def test_sensitive_data_api_key(self, mcp_env):
        signals = mcp_env["server"]._get_technical_signals("PAT-SEC-002", "security")
        code = 'api_key = "sk-1234567890abcdef"'
        matched = [s for s, w in signals if re.search(s, code.lower())]
        assert len(matched) >= 1

    def test_xss_innerhtml(self, mcp_env):
        signals = mcp_env["server"]._get_technical_signals("PAT-SEC-003", "security")
        code = "element.innerHTML = userInput"
        matched = [s for s, w in signals if re.search(s, code.lower())]
        assert len(matched) >= 1

    def test_xss_dangerously_set(self, mcp_env):
        signals = mcp_env["server"]._get_technical_signals("PAT-SEC-003", "security")
        code = "<div dangerouslySetInnerHTML={{__html: data}} />"
        matched = [s for s, w in signals if re.search(s, code.lower())]
        assert len(matched) >= 1

    def test_race_condition_signals(self, mcp_env):
        signals = mcp_env["server"]._get_technical_signals("PAT-ASYNC-001", "async")
        code = "global counter\ncounter += 1"
        matched = [s for s, w in signals if re.search(s, code.lower())]
        assert len(matched) >= 1

    def test_null_safety_deep_chaining(self, mcp_env):
        signals = mcp_env["server"]._get_technical_signals("PAT-NULL-001", "null_safety")
        code = "result.data.items.name"
        matched = [s for s, w in signals if re.search(s, code.lower())]
        assert len(matched) >= 1

    def test_security_eval_exec(self, mcp_env):
        signals = mcp_env["server"]._get_technical_signals("", "security")
        code = "eval(user_input)"
        matched = [s for s, w in signals if re.search(s, code.lower())]
        assert len(matched) >= 1

    def test_security_subprocess_shell(self, mcp_env):
        signals = mcp_env["server"]._get_technical_signals("", "security")
        code = "subprocess.run(cmd, shell=True)"
        matched = [s for s, w in signals if re.search(s, code.lower())]
        assert len(matched) >= 1

    def test_performance_nested_loops(self, mcp_env):
        signals = mcp_env["server"]._get_technical_signals("", "performance")
        code = "for x in items:\n    for y in other:"
        matched = [s for s, w in signals if re.search(s, code.lower(), re.DOTALL)]
        assert len(matched) >= 1

    def test_performance_select_star(self, mcp_env):
        signals = mcp_env["server"]._get_technical_signals("", "performance")
        code = "SELECT * FROM users"
        matched = [s for s, w in signals if re.search(s, code.lower())]
        assert len(matched) >= 1

    def test_unknown_pattern_returns_category_signals(self, mcp_env):
        signals = mcp_env["server"]._get_technical_signals("PAT-UNKNOWN-999", "security")
        # Doit retourner les signaux génériques de la catégorie security
        assert len(signals) >= 1

    def test_unknown_category_returns_empty(self, mcp_env):
        signals = mcp_env["server"]._get_technical_signals("PAT-UNKNOWN-999", "unknown_cat")
        assert len(signals) == 0

    def test_no_false_positive_on_clean_code(self, mcp_env):
        """Du code propre ne doit pas déclencher de signaux SEC-001."""
        signals = mcp_env["server"]._get_technical_signals("PAT-SEC-001", "security")
        code = '''
def add(a: int, b: int) -> int:
    """Simple addition."""
    return a + b
'''
        matched = [s for s, w in signals if re.search(s, code.lower())]
        assert len(matched) == 0

    def test_no_false_positive_comment_contains_select(self, mcp_env):
        """Un commentaire contenant 'select' ne doit pas matcher comme injection SQL."""
        signals = mcp_env["server"]._get_technical_signals("PAT-SEC-001", "security")
        code = "# This function helps select the right option\nx = 42"
        # f"select" pattern ne doit pas matcher un simple commentaire
        fstring_signals = [(s, w) for s, w in signals if "f[\"']select" in s]
        matched = [s for s, w in fstring_signals if re.search(s, code.lower())]
        assert len(matched) == 0


# ═══════════════════════════════════════════════════════════════════════════════
#  TESTS — _severity_to_score
# ═══════════════════════════════════════════════════════════════════════════════


class TestSeverityToScore:
    """Tests pour la conversion sévérité → score."""

    def test_critical(self, mcp_env):
        assert mcp_env["server"]._severity_to_score("critical") == 10

    def test_high(self, mcp_env):
        assert mcp_env["server"]._severity_to_score("high") == 7

    def test_medium(self, mcp_env):
        assert mcp_env["server"]._severity_to_score("medium") == 5

    def test_low(self, mcp_env):
        assert mcp_env["server"]._severity_to_score("low") == 2

    def test_unknown_defaults_to_medium(self, mcp_env):
        assert mcp_env["server"]._severity_to_score("unknown") == 5
