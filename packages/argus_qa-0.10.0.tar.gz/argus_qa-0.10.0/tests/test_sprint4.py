#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 ARGUS — Tests Sprint 4 (Robustesse & Scalabilité)

 Couverture :
   1. Cycle detection     — Détection de dépendances circulaires (reflection)
   2. Adaptive decay      — Taux de decay par catégorie (decay engine)
   3. Pagination          — Limite et offset sur query_memory (MCP)
═══════════════════════════════════════════════════════════════════════════════
"""

import json
import threading
from pathlib import Path

import pytest
import yaml

from conftest import REFERENCE_DATE, days_ago
from reflection import ReflectionEngine
from decay import DecayEngine
from config import (
    DECAY_RATE,
    DECAY_RATE_REINFORCED,
    CATEGORY_DECAY_RATES,
)


# ═══════════════════════════════════════════════════════════════════════════════
#  HELPERS
# ═══════════════════════════════════════════════════════════════════════════════


def _write_yaml(path: Path, data: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        yaml.dump(data, default_flow_style=False, allow_unicode=True, sort_keys=False),
        encoding="utf-8",
    )


def _parse_result(result: str) -> dict:
    return json.loads(result)


# ═══════════════════════════════════════════════════════════════════════════════
#  FIXTURE — Projet avec associations pour les tests de connectivité
# ═══════════════════════════════════════════════════════════════════════════════


def _make_project(tmp_path, couplings: list):
    """Creates a minimal Argus project with given couplings."""
    root = tmp_path / "argus"
    root.mkdir()
    memory = root / "memory"

    _write_yaml(
        memory / "_index.yaml",
        {
            "version": "1.0.0",
            "statistics": {
                "totals": {"episodes": 1, "patterns": 1, "heuristics": 1, "projects": 1},
                "activity": {"last_consolidation": "2026-02-28"},
            },
            "sequences": {"analysis": 1, "decision": 0, "incident": 0, "execution": 0},
        },
    )

    _write_yaml(
        memory / "semantic" / "defect_patterns.yaml",
        {
            "patterns": [
                {
                    "id": "PAT-001",
                    "category": "null_safety",
                    "confidence": 0.90,
                    "occurrences": 1,
                    "last_seen": days_ago(1),
                    "source_episodes": ["ANL-20260228-001"],
                },
            ],
        },
    )

    _write_yaml(
        memory / "semantic" / "testing_heuristics.yaml",
        {
            "test_selection": [{"id": "HEU-001", "confidence": 0.95}],
        },
    )

    analyses = memory / "episodic" / "analyses"
    analyses.mkdir(parents=True, exist_ok=True)
    _write_yaml(
        analyses / "2026-02-28_analysis_ANL-20260228-001.yaml",
        {
            "id": "ANL-20260228-001",
            "quick_summary": {"one_liner": "test", "status": "COMPLETED", "next_action": "none"},
            "consolidation": {"consolidated": True, "consolidated_at": "2026-02-28T12:00:00"},
        },
    )

    for sub in ["decisions", "incidents", "executions"]:
        (memory / "episodic" / sub).mkdir(parents=True, exist_ok=True)

    _write_yaml(
        memory / "relational" / "associations.yaml",
        {
            "component_coupling": {"couplings": couplings},
        },
    )

    _write_yaml(
        memory / "projects" / "argus.yaml",
        {
            "identity": {"project_id": "argus", "name": "Argus"},
        },
    )

    return root


# ═══════════════════════════════════════════════════════════════════════════════
#  FIXTURE — Projet avec patterns multi-catégories pour le decay adaptatif
# ═══════════════════════════════════════════════════════════════════════════════


@pytest.fixture
def decay_categories_project(tmp_path):
    """Creates a project with patterns in different categories for adaptive decay testing."""
    root = tmp_path / "argus_decay"
    root.mkdir()
    memory = root / "memory"

    _write_yaml(
        memory / "_index.yaml",
        {
            "version": "1.0.0",
            "statistics": {
                "totals": {"episodes": 0, "patterns": 5, "heuristics": 0},
            },
        },
    )

    _write_yaml(
        memory / "semantic" / "defect_patterns.yaml",
        {
            "patterns": [
                {
                    "id": "PAT-PERF-001",
                    "name": "Performance pattern",
                    "category": "performance",
                    "confidence": 0.80,
                    "occurrences": 0,
                    "last_seen": days_ago(180),  # 6 months old
                    "source_episodes": [],
                },
                {
                    "id": "PAT-UI-001",
                    "name": "UI pattern",
                    "category": "ui",
                    "confidence": 0.80,
                    "occurrences": 0,
                    "last_seen": days_ago(180),
                    "source_episodes": [],
                },
                {
                    "id": "PAT-SEC-001",
                    "name": "Security pattern",
                    "category": "security",
                    "confidence": 0.80,
                    "occurrences": 0,
                    "last_seen": days_ago(180),
                    "source_episodes": [],
                },
                {
                    "id": "PAT-UNKNOWN-001",
                    "name": "Unknown category pattern",
                    "category": "unknown_category",
                    "confidence": 0.80,
                    "occurrences": 0,
                    "last_seen": days_ago(180),
                    "source_episodes": [],
                },
                {
                    "id": "PAT-REINF-001",
                    "name": "Reinforced performance pattern",
                    "category": "performance",
                    "confidence": 0.80,
                    "occurrences": 5,
                    "last_seen": days_ago(180),
                    "source_episodes": ["INC-001"],
                },
            ],
        },
    )

    _write_yaml(
        memory / "semantic" / "testing_heuristics.yaml",
        {
            "test_selection": [],
        },
    )

    for sub in [
        "episodic/analyses",
        "episodic/decisions",
        "episodic/incidents",
        "episodic/executions",
        "relational",
        "projects",
    ]:
        (memory / sub).mkdir(parents=True, exist_ok=True)

    _write_yaml(
        memory / "relational" / "associations.yaml", {"component_coupling": {"couplings": []}}
    )

    return root


# ═══════════════════════════════════════════════════════════════════════════════
#  FIXTURE — Environnement MCP isolé pour les tests de pagination
# ═══════════════════════════════════════════════════════════════════════════════

_IMPORT_LOCK = threading.Lock()


@pytest.fixture
def mcp_env(tmp_path, monkeypatch):
    """Creates an isolated MCP environment for pagination tests."""
    memory = tmp_path / "memory"
    for sub in [
        "semantic",
        "episodic/analyses",
        "episodic/decisions",
        "episodic/incidents",
        "episodic/executions",
        "projects",
        "relational",
        "working",
    ]:
        (memory / sub).mkdir(parents=True, exist_ok=True)

    # 15 patterns for pagination tests
    patterns = [
        {
            "id": f"PAT-PAGE-{i:03d}",
            "name": f"Pagination pattern {i}",
            "category": "functional",
            "confidence": 0.90,
            "occurrences": 1,
            "last_seen": days_ago(i),
            "source_episodes": [],
        }
        for i in range(1, 16)
    ]
    _write_yaml(memory / "semantic" / "defect_patterns.yaml", {"patterns": patterns})

    _write_yaml(
        memory / "semantic" / "testing_heuristics.yaml",
        {
            "test_selection": [
                {"id": f"HEU-PAGE-{i:03d}", "confidence": 0.90} for i in range(1, 11)
            ],
        },
    )

    _write_yaml(
        memory / "_index.yaml",
        {
            "version": "1.0.0",
            "statistics": {
                "totals": {"episodes": 0, "patterns": 15, "heuristics": 10, "projects": 0},
                "activity": {"last_consolidation": "2026-02-28"},
            },
            "sequences": {"analysis": 0, "decision": 0, "incident": 0, "execution": 0},
        },
    )

    _write_yaml(
        memory / "relational" / "associations.yaml",
        {
            "component_coupling": {"couplings": []},
        },
    )

    monkeypatch.setenv("ARGUS_DATA_DIR", str(memory))

    with _IMPORT_LOCK:
        import importlib
        import mcp_server.server as srv_mod
        import mcp_server.memory_reader as mr_mod

        importlib.reload(mr_mod)
        importlib.reload(srv_mod)

    return srv_mod


# ═══════════════════════════════════════════════════════════════════════════════
#  TEST: CYCLE DETECTION (Reflection Engine)
# ═══════════════════════════════════════════════════════════════════════════════


class TestCycleDetection:
    """Tests for _check_connectivity cycle detection in reflection."""

    def test_no_cycles_simple_graph(self, tmp_path):
        """Linear graph (A-B, B-C) should not report cycles."""
        root = _make_project(
            tmp_path,
            [
                {"component_a": "A", "component_b": "B"},
                {"component_a": "B", "component_b": "C"},
            ],
        )
        engine = ReflectionEngine(str(root), verbose=False)
        report = engine.reflect()
        cycle_check = next(c for c in report.checks if c.name == "association_cycles")
        assert cycle_check.status == "ok"
        assert "No circular" in cycle_check.message

    def test_detects_simple_cycle(self, tmp_path):
        """Triangle A-B, B-C, C-A should detect a cycle."""
        root = _make_project(
            tmp_path,
            [
                {"component_a": "A", "component_b": "B"},
                {"component_a": "B", "component_b": "C"},
                {"component_a": "C", "component_b": "A"},
            ],
        )
        engine = ReflectionEngine(str(root), verbose=False)
        report = engine.reflect()
        cycle_check = next(c for c in report.checks if c.name == "association_cycles")
        assert cycle_check.status == "warning"
        assert "circular dependency" in cycle_check.message.lower()
        assert cycle_check.details is not None
        assert len(cycle_check.details) >= 1

    def test_empty_couplings_ok(self, tmp_path):
        """No couplings should report ok."""
        root = _make_project(tmp_path, [])
        engine = ReflectionEngine(str(root), verbose=False)
        report = engine.reflect()
        cycle_check = next(c for c in report.checks if c.name == "association_cycles")
        assert cycle_check.status == "ok"
        assert "No component couplings" in cycle_check.message

    def test_disconnected_components_no_cycle(self, tmp_path):
        """Two disconnected edges should not report cycles."""
        root = _make_project(
            tmp_path,
            [
                {"component_a": "A", "component_b": "B"},
                {"component_a": "C", "component_b": "D"},
            ],
        )
        engine = ReflectionEngine(str(root), verbose=False)
        report = engine.reflect()
        cycle_check = next(c for c in report.checks if c.name == "association_cycles")
        assert cycle_check.status == "ok"

    def test_cycle_details_contain_arrows(self, tmp_path):
        """Cycle details should contain arrow-separated component names."""
        root = _make_project(
            tmp_path,
            [
                {"component_a": "X", "component_b": "Y"},
                {"component_a": "Y", "component_b": "Z"},
                {"component_a": "Z", "component_b": "X"},
            ],
        )
        engine = ReflectionEngine(str(root), verbose=False)
        report = engine.reflect()
        cycle_check = next(c for c in report.checks if c.name == "association_cycles")
        assert cycle_check.details is not None
        # Each detail entry should have the arrow separator
        for detail in cycle_check.details:
            assert " → " in detail

    def test_cycle_has_recommendation(self, tmp_path):
        """Detected cycles should include a recommendation."""
        root = _make_project(
            tmp_path,
            [
                {"component_a": "A", "component_b": "B"},
                {"component_a": "B", "component_b": "C"},
                {"component_a": "C", "component_b": "A"},
            ],
        )
        engine = ReflectionEngine(str(root), verbose=False)
        report = engine.reflect()
        cycle_check = next(c for c in report.checks if c.name == "association_cycles")
        assert cycle_check.recommendation != ""

    def test_invalid_coupling_entries_skipped(self, tmp_path):
        """Malformed coupling entries should be skipped gracefully."""
        root = _make_project(
            tmp_path,
            [
                "not_a_dict",
                {"component_a": "A"},  # missing component_b
                {"component_a": "A", "component_b": "B"},
            ],
        )
        engine = ReflectionEngine(str(root), verbose=False)
        report = engine.reflect()
        cycle_check = next(c for c in report.checks if c.name == "association_cycles")
        assert cycle_check.status == "ok"

    def test_connectivity_check_present_in_reflect(self, tmp_path):
        """reflect() should always produce an association_cycles check."""
        root = _make_project(tmp_path, [])
        engine = ReflectionEngine(str(root), verbose=False)
        report = engine.reflect()
        check_names = [c.name for c in report.checks]
        assert "association_cycles" in check_names


# ═══════════════════════════════════════════════════════════════════════════════
#  TEST: ADAPTIVE DECAY (Decay Engine)
# ═══════════════════════════════════════════════════════════════════════════════


class TestAdaptiveDecay:
    """Tests for category-based adaptive decay rates."""

    def test_performance_rate_applied(self, decay_categories_project):
        """Performance patterns should decay at 0.03/month."""
        engine = DecayEngine(
            str(decay_categories_project), verbose=False, reference_date=REFERENCE_DATE
        )
        report = engine.scan()
        perf = next(a for a in report.actions if a.target_id == "PAT-PERF-001")
        months = perf.days_since_activity / 30.0
        expected = CATEGORY_DECAY_RATES["performance"] * months
        assert abs(perf.decay_amount - expected) < 0.01

    def test_ui_rate_applied(self, decay_categories_project):
        """UI patterns should decay at 0.07/month (faster than default)."""
        engine = DecayEngine(
            str(decay_categories_project), verbose=False, reference_date=REFERENCE_DATE
        )
        report = engine.scan()
        ui = next(a for a in report.actions if a.target_id == "PAT-UI-001")
        months = ui.days_since_activity / 30.0
        expected = CATEGORY_DECAY_RATES["ui"] * months
        assert abs(ui.decay_amount - expected) < 0.01

    def test_ui_decays_faster_than_performance(self, decay_categories_project):
        """UI should lose more confidence than performance given same age."""
        engine = DecayEngine(
            str(decay_categories_project), verbose=False, reference_date=REFERENCE_DATE
        )
        report = engine.scan()
        perf = next(a for a in report.actions if a.target_id == "PAT-PERF-001")
        ui = next(a for a in report.actions if a.target_id == "PAT-UI-001")
        assert ui.decay_amount > perf.decay_amount

    def test_unknown_category_uses_default_rate(self, decay_categories_project):
        """Unknown categories should fall back to DECAY_RATE."""
        engine = DecayEngine(
            str(decay_categories_project), verbose=False, reference_date=REFERENCE_DATE
        )
        report = engine.scan()
        unknown = next(a for a in report.actions if a.target_id == "PAT-UNKNOWN-001")
        months = unknown.days_since_activity / 30.0
        expected = DECAY_RATE * months
        assert abs(unknown.decay_amount - expected) < 0.01

    def test_security_still_protected(self, decay_categories_project):
        """Security patterns should remain protected regardless of rates."""
        engine = DecayEngine(
            str(decay_categories_project), verbose=False, reference_date=REFERENCE_DATE
        )
        report = engine.scan()
        sec = next(a for a in report.actions if a.target_id == "PAT-SEC-001")
        assert sec.protected is True
        assert sec.decay_amount == 0.0

    def test_reinforced_uses_min_rate(self, decay_categories_project):
        """Reinforced items should use min(category_rate, DECAY_RATE_REINFORCED)."""
        engine = DecayEngine(
            str(decay_categories_project), verbose=False, reference_date=REFERENCE_DATE
        )
        report = engine.scan()
        reinf = next(a for a in report.actions if a.target_id == "PAT-REINF-001")
        months = reinf.days_since_activity / 30.0
        # performance rate = 0.03, reinforced rate = 0.02 → min = 0.02
        expected = min(CATEGORY_DECAY_RATES["performance"], DECAY_RATE_REINFORCED) * months
        assert abs(reinf.decay_amount - expected) < 0.01

    def test_category_decay_rates_config_complete(self):
        """CATEGORY_DECAY_RATES should cover all known non-protected categories."""
        expected = {
            "performance",
            "data_integrity",
            "error_handling",
            "api",
            "accessibility",
            "concurrency",
            "null_safety",
            "regression",
            "ui",
            "seo",
            "functional",
            "requirements",
            "async",
        }
        assert set(CATEGORY_DECAY_RATES.keys()) == expected

    def test_all_category_rates_positive(self):
        """All category rates must be positive floats."""
        for cat, rate in CATEGORY_DECAY_RATES.items():
            assert isinstance(rate, float), f"{cat} rate is not float"
            assert rate > 0, f"{cat} rate must be positive"

    def test_decay_reason_contains_rate(self, decay_categories_project):
        """Decay reason string should include the applied rate."""
        engine = DecayEngine(
            str(decay_categories_project), verbose=False, reference_date=REFERENCE_DATE
        )
        report = engine.scan()
        perf = next(a for a in report.actions if a.target_id == "PAT-PERF-001")
        assert "rate=" in perf.reason


# ═══════════════════════════════════════════════════════════════════════════════
#  TEST: PAGINATION (query_memory MCP tool)
# ═══════════════════════════════════════════════════════════════════════════════


class TestPagination:
    """Tests for limit/offset pagination in query_memory."""

    def test_default_pagination(self, mcp_env):
        """Default call (no limit/offset) should return all results with pagination metadata."""
        result = _parse_result(mcp_env.query_memory(section="patterns"))
        assert result["limit"] == 100
        assert result["offset"] == 0
        assert result["total_count"] == 15
        assert result["has_more"] is False
        assert result["result_count"] == 15

    def test_custom_limit(self, mcp_env):
        """Setting limit=5 should return only 5 results."""
        result = _parse_result(mcp_env.query_memory(section="patterns", limit=5))
        assert result["result_count"] == 5
        assert result["total_count"] == 15
        assert result["has_more"] is True
        assert result["limit"] == 5

    def test_custom_offset(self, mcp_env):
        """Setting offset=10 should skip first 10 results."""
        result = _parse_result(mcp_env.query_memory(section="patterns", offset=10))
        assert result["result_count"] == 5  # 15 total - 10 offset = 5 remaining
        assert result["offset"] == 10
        assert result["has_more"] is False

    def test_limit_and_offset(self, mcp_env):
        """Combined limit and offset should paginate correctly."""
        result = _parse_result(mcp_env.query_memory(section="patterns", limit=5, offset=5))
        assert result["result_count"] == 5
        assert result["total_count"] == 15
        assert result["has_more"] is True  # still 5 more after offset+limit=10

    def test_offset_beyond_results(self, mcp_env):
        """Offset beyond total should return empty results."""
        result = _parse_result(mcp_env.query_memory(section="patterns", offset=100))
        assert result["result_count"] == 0
        assert result["total_count"] == 15
        assert result["has_more"] is False
        assert result["results"] == []

    def test_last_page_has_more_false(self, mcp_env):
        """Last page should have has_more=False."""
        result = _parse_result(mcp_env.query_memory(section="patterns", limit=5, offset=10))
        assert result["result_count"] == 5
        assert result["has_more"] is False

    def test_limit_clamped_to_max(self, mcp_env):
        """Limit above 1000 should be clamped to 1000."""
        result = _parse_result(mcp_env.query_memory(section="patterns", limit=5000))
        assert result["limit"] == 1000

    def test_limit_clamped_to_min(self, mcp_env):
        """Limit below 1 should be clamped to 1."""
        result = _parse_result(mcp_env.query_memory(section="patterns", limit=0))
        assert result["limit"] == 1
        assert result["result_count"] == 1

    def test_negative_offset_clamped(self, mcp_env):
        """Negative offset should be clamped to 0."""
        result = _parse_result(mcp_env.query_memory(section="patterns", offset=-10))
        assert result["offset"] == 0
        assert result["result_count"] == 15

    def test_dict_section_not_paginated(self, mcp_env):
        """Non-list sections (stats, index) should not be paginated."""
        result = _parse_result(mcp_env.query_memory(section="index"))
        assert result["total_count"] == 1
        assert result["has_more"] is False

    def test_total_count_reflects_full_data(self, mcp_env):
        """total_count should always reflect the unsliced data length."""
        result = _parse_result(mcp_env.query_memory(section="patterns", limit=3, offset=0))
        assert result["total_count"] == 15
        assert result["result_count"] == 3

    def test_pagination_preserves_order(self, mcp_env):
        """Paginated results should maintain the same order."""
        full = _parse_result(mcp_env.query_memory(section="patterns"))
        page1 = _parse_result(mcp_env.query_memory(section="patterns", limit=5, offset=0))
        page2 = _parse_result(mcp_env.query_memory(section="patterns", limit=5, offset=5))
        page3 = _parse_result(mcp_env.query_memory(section="patterns", limit=5, offset=10))
        reassembled = page1["results"] + page2["results"] + page3["results"]
        assert reassembled == full["results"]
