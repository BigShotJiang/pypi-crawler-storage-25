#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 ARGUS — Tests Sprint 3 (Autonomie)

 Couverture :
   1. record_pattern     — Ajout de defect patterns via MCP
   2. record_heuristic   — Ajout d'heuristiques de test via MCP
   3. Schema validation  — Validation automatique au chargement YAML
   4. Structured logging — Configuration et format du logging
═══════════════════════════════════════════════════════════════════════════════
"""

import json
import logging
import threading
from pathlib import Path

import pytest
import yaml


# ═══════════════════════════════════════════════════════════════════════════════
#  HELPERS
# ═══════════════════════════════════════════════════════════════════════════════


def _write_yaml(path: Path, data: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        yaml.dump(data, default_flow_style=False, allow_unicode=True, sort_keys=False),
        encoding="utf-8",
    )


def _parse_result(result: str) -> dict:
    return json.loads(result)


# ═══════════════════════════════════════════════════════════════════════════════
#  FIXTURE — Mémoire MCP isolée (réutilise le pattern de test_mcp_tools.py)
# ═══════════════════════════════════════════════════════════════════════════════


@pytest.fixture
def mcp_env(tmp_path, monkeypatch):
    """Crée un environnement MCP isolé pour les tests Sprint 3."""
    memory = tmp_path / "memory"
    for sub in [
        "semantic",
        "episodic/analyses",
        "episodic/decisions",
        "episodic/incidents",
        "episodic/executions",
        "projects",
        "relational",
        "working",
    ]:
        (memory / sub).mkdir(parents=True, exist_ok=True)

    # Persona
    (tmp_path / "argus.persona.yaml").write_text(
        "version: '0.10.0'\nlast_updated: '2026-03-01'\n",
        encoding="utf-8",
    )

    # _index.yaml
    _write_yaml(
        memory / "_index.yaml",
        {
            "version": "1.0.0",
            "last_updated": "2026-03-01",
            "episodic": {
                "analyses": {"count": 0, "latest": None, "path": "memory/episodic/analyses/"},
                "decisions": {"count": 0, "latest": None, "path": "memory/episodic/decisions/"},
                "incidents": {"count": 0, "latest": None, "path": "memory/episodic/incidents/"},
                "executions": {"count": 0, "latest": None, "path": "memory/episodic/executions/"},
            },
            "semantic": {
                "defect_patterns": {"count": 2, "path": "memory/semantic/defect_patterns.yaml"},
                "testing_heuristics": {
                    "count": 2,
                    "path": "memory/semantic/testing_heuristics.yaml",
                },
            },
            "projects": {"count": 0, "path": "memory/projects/"},
            "relational": {"path": "memory/relational/associations.yaml"},
            "statistics": {
                "totals": {"episodes": 0, "patterns": 2, "heuristics": 2, "projects": 0},
            },
            "sequences": {
                "analysis": 0,
                "decision": 0,
                "incident": 0,
                "execution": 0,
                "pattern": 2,
                "heuristic": 2,
            },
        },
    )

    # Patterns (2 existants)
    _write_yaml(
        memory / "semantic" / "defect_patterns.yaml",
        {
            "version": "2.0.0",
            "last_updated": "2026-03-01",
            "metadata": {"total_patterns": 2},
            "patterns": [
                {
                    "id": "PAT-SEC-001",
                    "name": "SQL Injection",
                    "category": "security",
                    "severity_typical": "critical",
                    "confidence": 0.95,
                    "signature": {
                        "description": "SQL injection via string concatenation",
                        "indicators": ["user input in SQL"],
                        "code_patterns": ["f-string with select"],
                    },
                    "prevention_strategy": ["Use parameterized queries"],
                    "occurrences": 3,
                    "last_seen": "2026-03-01",
                    "source_episodes": [],
                },
                {
                    "id": "PAT-PERF-001",
                    "name": "N+1 Query",
                    "category": "performance",
                    "severity_typical": "high",
                    "confidence": 0.88,
                    "signature": {
                        "description": "N+1 database query in loop",
                        "indicators": ["query inside loop"],
                        "code_patterns": ["for item in items: db.query(item)"],
                    },
                    "prevention_strategy": ["Use eager loading", "Batch queries"],
                    "occurrences": 1,
                    "last_seen": "2026-03-01",
                    "source_episodes": [],
                },
            ],
        },
    )

    # Heuristics (2 existantes)
    _write_yaml(
        memory / "semantic" / "testing_heuristics.yaml",
        {
            "version": "2.0.0",
            "last_updated": "2026-03-01",
            "metadata": {"total_heuristics": 2},
            "test_selection": [
                {
                    "id": "HEU-SEL-001",
                    "name": "Test What Changed",
                    "category": "selection",
                    "condition": "code changed in feature or bugfix",
                    "action": "Run tests for changed modules first",
                    "rationale": "Most defects are near recent changes",
                    "priority": "always",
                    "confidence": 0.95,
                },
            ],
            "coverage": [
                {
                    "id": "HEU-COV-001",
                    "name": "Boundary Value Testing",
                    "category": "coverage",
                    "condition": "complex logic with numeric ranges",
                    "action": "Test min, max, and boundary-adjacent values",
                    "rationale": "Off-by-one errors are common",
                    "priority": "high_priority",
                    "confidence": 0.88,
                },
            ],
        },
    )

    # Context profiles
    _write_yaml(
        memory / "semantic" / "context_profiles.yaml",
        {"profiles": [{"id": "CTX-GENERIC", "name": "Generic", "risk_multipliers": {}}]},
    )

    # Technology knowledge
    _write_yaml(memory / "semantic" / "technology_knowledge.yaml", {"languages": ["Python"]})

    # ISTQB knowledge
    _write_yaml(memory / "semantic" / "istqb_knowledge.yaml", {"source": "ISTQB v4.0"})

    # Associations
    _write_yaml(memory / "relational" / "associations.yaml", {"associations": []})

    monkeypatch.setenv("ARGUS_DATA_DIR", str(memory))

    from mcp_server import memory_reader as mem_mod
    from mcp_server import server as srv_mod

    return {
        "memory": memory,
        "root": tmp_path,
        "server": srv_mod,
        "mem": mem_mod,
    }


# ═══════════════════════════════════════════════════════════════════════════════
#  TESTS — record_pattern
# ═══════════════════════════════════════════════════════════════════════════════


class TestRecordPattern:
    """Tests pour le tool record_pattern."""

    def test_record_basic_pattern(self, mcp_env):
        result = _parse_result(
            mcp_env["server"].record_pattern(
                name="XSS via innerHTML",
                category="security",
                severity_typical="high",
                description="Cross-site scripting via innerHTML assignment",
            )
        )
        assert result["status"] == "success"
        assert result["pattern_id"] == "PAT-SEC-002"
        assert result["category"] == "security"

    def test_record_pattern_creates_entry_in_yaml(self, mcp_env):
        mcp_env["server"].record_pattern(
            name="Race Condition",
            category="concurrency",
            severity_typical="high",
            description="Shared state without synchronization",
        )
        data = yaml.safe_load(
            (mcp_env["memory"] / "semantic" / "defect_patterns.yaml").read_text(encoding="utf-8")
        )
        assert len(data["patterns"]) == 3
        new_pat = data["patterns"][-1]
        assert new_pat["id"] == "PAT-CONC-001"
        assert new_pat["name"] == "Race Condition"
        assert new_pat["confidence"] == 0.7

    def test_record_pattern_with_all_fields(self, mcp_env):
        result = _parse_result(
            mcp_env["server"].record_pattern(
                name="CSRF Token Bypass",
                category="security",
                severity_typical="critical",
                description="Missing or weak CSRF token validation",
                confidence=0.85,
                indicators=["no csrf token in form", "GET request for state change"],
                code_patterns=["form without csrf_token", "action=POST without token"],
                prevention_strategy=["Use framework CSRF protection", "Validate origin header"],
                related_owasp="A01:2021",
                related_cwe="CWE-352",
            )
        )
        assert result["status"] == "success"
        assert result["pattern_id"] == "PAT-SEC-002"

        # Vérifier le contenu YAML
        data = yaml.safe_load(
            (mcp_env["memory"] / "semantic" / "defect_patterns.yaml").read_text(encoding="utf-8")
        )
        new_pat = data["patterns"][-1]
        assert new_pat["confidence"] == 0.85
        assert len(new_pat["signature"]["indicators"]) == 2
        assert new_pat["related_owasp"] == "A01:2021"
        assert new_pat["related_cwe"] == "CWE-352"

    def test_record_pattern_updates_index(self, mcp_env):
        mcp_env["server"].record_pattern(
            name="Test Pattern",
            category="api",
            severity_typical="medium",
            description="Test description",
        )
        index = yaml.safe_load((mcp_env["memory"] / "_index.yaml").read_text(encoding="utf-8"))
        assert index["semantic"]["defect_patterns"]["count"] == 3
        assert index["statistics"]["totals"]["patterns"] == 3

    def test_record_pattern_sequential_ids_same_category(self, mcp_env):
        r1 = _parse_result(
            mcp_env["server"].record_pattern(
                name="XSS 1",
                category="security",
                severity_typical="high",
                description="XSS variant 1",
            )
        )
        r2 = _parse_result(
            mcp_env["server"].record_pattern(
                name="XSS 2",
                category="security",
                severity_typical="high",
                description="XSS variant 2",
            )
        )
        assert r1["pattern_id"] == "PAT-SEC-002"
        assert r2["pattern_id"] == "PAT-SEC-003"

    def test_record_pattern_different_categories_independent_ids(self, mcp_env):
        r1 = _parse_result(
            mcp_env["server"].record_pattern(
                name="API Error",
                category="api",
                severity_typical="medium",
                description="API error pattern",
            )
        )
        r2 = _parse_result(
            mcp_env["server"].record_pattern(
                name="UI Glitch",
                category="ui",
                severity_typical="low",
                description="UI rendering issue",
            )
        )
        assert r1["pattern_id"] == "PAT-API-001"
        assert r2["pattern_id"] == "PAT-UI-001"

    def test_record_pattern_invalid_category(self, mcp_env):
        result = _parse_result(
            mcp_env["server"].record_pattern(
                name="Test",
                category="invalid_cat",
                severity_typical="high",
                description="Test",
            )
        )
        assert "error" in result
        assert "valid_categories" in result

    def test_record_pattern_invalid_severity(self, mcp_env):
        result = _parse_result(
            mcp_env["server"].record_pattern(
                name="Test",
                category="security",
                severity_typical="super_critical",
                description="Test",
            )
        )
        assert "error" in result
        assert "valid_severities" in result

    def test_record_pattern_invalid_confidence(self, mcp_env):
        result = _parse_result(
            mcp_env["server"].record_pattern(
                name="Test",
                category="security",
                severity_typical="high",
                description="Test",
                confidence=1.5,
            )
        )
        assert "error" in result
        assert "confidence" in result["error"].lower()

    def test_record_pattern_empty_name(self, mcp_env):
        result = _parse_result(
            mcp_env["server"].record_pattern(
                name="",
                category="security",
                severity_typical="high",
                description="Test",
            )
        )
        assert "error" in result

    def test_record_pattern_whitespace_name(self, mcp_env):
        result = _parse_result(
            mcp_env["server"].record_pattern(
                name="   ",
                category="security",
                severity_typical="high",
                description="Test",
            )
        )
        assert "error" in result

    def test_record_pattern_concurrent_no_collision(self, mcp_env):
        """Deux record_pattern concurrents doivent avoir des IDs différents."""
        results = []
        barrier = threading.Barrier(2)

        def record(idx):
            barrier.wait()
            r = _parse_result(
                mcp_env["server"].record_pattern(
                    name=f"Concurrent Pattern {idx}",
                    category="security",
                    severity_typical="medium",
                    description=f"Description {idx}",
                )
            )
            results.append(r)

        t1 = threading.Thread(target=record, args=(1,))
        t2 = threading.Thread(target=record, args=(2,))
        t1.start()
        t2.start()
        t1.join(timeout=15)
        t2.join(timeout=15)
        assert not t1.is_alive(), "Thread 1 deadlocked"
        assert not t2.is_alive(), "Thread 2 deadlocked"

        assert all(r["status"] == "success" for r in results)
        ids = {r["pattern_id"] for r in results}
        assert len(ids) == 2, f"IDs should be unique but got: {ids}"

    def test_record_pattern_preserves_existing(self, mcp_env):
        """L'ajout d'un pattern ne doit pas corrompre les patterns existants."""
        mcp_env["server"].record_pattern(
            name="New Pattern",
            category="security",
            severity_typical="low",
            description="New",
        )
        data = yaml.safe_load(
            (mcp_env["memory"] / "semantic" / "defect_patterns.yaml").read_text(encoding="utf-8")
        )
        existing = [p for p in data["patterns"] if p["id"] == "PAT-SEC-001"]
        assert len(existing) == 1
        assert existing[0]["name"] == "SQL Injection"
        assert existing[0]["confidence"] == 0.95


# ═══════════════════════════════════════════════════════════════════════════════
#  TESTS — record_heuristic
# ═══════════════════════════════════════════════════════════════════════════════


class TestRecordHeuristic:
    """Tests pour le tool record_heuristic."""

    def test_record_basic_heuristic(self, mcp_env):
        result = _parse_result(
            mcp_env["server"].record_heuristic(
                name="Test Error Paths",
                category="coverage",
                action="Always test error/exception paths, not just happy path",
            )
        )
        assert result["status"] == "success"
        assert result["heuristic_id"] == "HEU-COV-002"
        assert result["yaml_section"] == "coverage"

    def test_record_heuristic_creates_entry_in_yaml(self, mcp_env):
        mcp_env["server"].record_heuristic(
            name="Automate Smoke Tests",
            category="automation",
            action="Automate basic smoke tests for every deploy",
            condition="New deployment pipeline",
            rationale="Catch critical failures early",
        )
        data = yaml.safe_load(
            (mcp_env["memory"] / "semantic" / "testing_heuristics.yaml").read_text(encoding="utf-8")
        )
        assert "automation" in data
        new_heu = data["automation"][-1]
        assert new_heu["id"] == "HEU-AUT-001"
        assert new_heu["name"] == "Automate Smoke Tests"
        assert new_heu["condition"] == "New deployment pipeline"

    def test_record_heuristic_with_all_fields(self, mcp_env):
        result = _parse_result(
            mcp_env["server"].record_heuristic(
                name="Security Scan on Auth Changes",
                category="security_testing",
                action="Run SAST/DAST scan when auth module changes",
                condition="Auth component modified",
                confidence=0.92,
                priority="always",
                rationale="Auth is a critical attack surface",
                related_patterns=["PAT-SEC-001"],
            )
        )
        assert result["status"] == "success"
        assert result["heuristic_id"] == "HEU-SEC-001"

    def test_record_heuristic_updates_index(self, mcp_env):
        mcp_env["server"].record_heuristic(
            name="Test",
            category="coverage",
            action="Test action",
        )
        index = yaml.safe_load((mcp_env["memory"] / "_index.yaml").read_text(encoding="utf-8"))
        assert index["semantic"]["testing_heuristics"]["count"] == 3
        assert index["statistics"]["totals"]["heuristics"] == 3

    def test_record_heuristic_sequential_ids(self, mcp_env):
        r1 = _parse_result(
            mcp_env["server"].record_heuristic(
                name="Coverage 1",
                category="coverage",
                action="Action 1",
            )
        )
        r2 = _parse_result(
            mcp_env["server"].record_heuristic(
                name="Coverage 2",
                category="coverage",
                action="Action 2",
            )
        )
        assert r1["heuristic_id"] == "HEU-COV-002"
        assert r2["heuristic_id"] == "HEU-COV-003"

    def test_record_heuristic_selection_goes_to_test_selection(self, mcp_env):
        """La catégorie 'selection' doit être stockée sous la clé 'test_selection'."""
        result = _parse_result(
            mcp_env["server"].record_heuristic(
                name="New Selection",
                category="selection",
                action="Do this",
            )
        )
        assert result["yaml_section"] == "test_selection"

        data = yaml.safe_load(
            (mcp_env["memory"] / "semantic" / "testing_heuristics.yaml").read_text(encoding="utf-8")
        )
        ids = [h["id"] for h in data["test_selection"]]
        assert result["heuristic_id"] in ids

    def test_record_heuristic_invalid_category(self, mcp_env):
        result = _parse_result(
            mcp_env["server"].record_heuristic(
                name="Test",
                category="invalid_cat",
                action="Action",
            )
        )
        assert "error" in result
        assert "valid_categories" in result

    def test_record_heuristic_invalid_priority(self, mcp_env):
        result = _parse_result(
            mcp_env["server"].record_heuristic(
                name="Test",
                category="coverage",
                action="Action",
                priority="urgent",
            )
        )
        assert "error" in result
        assert "valid_priorities" in result

    def test_record_heuristic_invalid_confidence(self, mcp_env):
        result = _parse_result(
            mcp_env["server"].record_heuristic(
                name="Test",
                category="coverage",
                action="Action",
                confidence=-0.1,
            )
        )
        assert "error" in result

    def test_record_heuristic_empty_name(self, mcp_env):
        result = _parse_result(
            mcp_env["server"].record_heuristic(
                name="",
                category="coverage",
                action="Action",
            )
        )
        assert "error" in result

    def test_record_heuristic_empty_action(self, mcp_env):
        result = _parse_result(
            mcp_env["server"].record_heuristic(
                name="Test",
                category="coverage",
                action="",
            )
        )
        assert "error" in result

    def test_record_heuristic_concurrent_no_collision(self, mcp_env):
        """Deux record_heuristic concurrents doivent avoir des IDs différents."""
        results = []
        barrier = threading.Barrier(2)

        def record(idx):
            barrier.wait()
            r = _parse_result(
                mcp_env["server"].record_heuristic(
                    name=f"Concurrent Heuristic {idx}",
                    category="coverage",
                    action=f"Action {idx}",
                )
            )
            results.append(r)

        t1 = threading.Thread(target=record, args=(1,))
        t2 = threading.Thread(target=record, args=(2,))
        t1.start()
        t2.start()
        t1.join(timeout=15)
        t2.join(timeout=15)
        assert not t1.is_alive(), "Thread 1 deadlocked"
        assert not t2.is_alive(), "Thread 2 deadlocked"

        assert all(r["status"] == "success" for r in results)
        ids = {r["heuristic_id"] for r in results}
        assert len(ids) == 2, f"IDs should be unique but got: {ids}"

    def test_record_heuristic_preserves_existing(self, mcp_env):
        """L'ajout ne doit pas corrompre les heuristiques existantes."""
        mcp_env["server"].record_heuristic(
            name="New",
            category="coverage",
            action="New action",
        )
        data = yaml.safe_load(
            (mcp_env["memory"] / "semantic" / "testing_heuristics.yaml").read_text(encoding="utf-8")
        )
        sel = [h for h in data["test_selection"] if h["id"] == "HEU-SEL-001"]
        assert len(sel) == 1
        assert sel[0]["name"] == "Test What Changed"

    def test_record_heuristic_creates_new_section(self, mcp_env):
        """Enregistrer dans une catégorie sans section existante doit la créer."""
        result = _parse_result(
            mcp_env["server"].record_heuristic(
                name="API Contract Test",
                category="api_testing",
                action="Validate API response schema against OpenAPI spec",
            )
        )
        assert result["status"] == "success"
        assert result["yaml_section"] == "api_testing"

        data = yaml.safe_load(
            (mcp_env["memory"] / "semantic" / "testing_heuristics.yaml").read_text(encoding="utf-8")
        )
        assert "api_testing" in data
        assert len(data["api_testing"]) == 1


# ═══════════════════════════════════════════════════════════════════════════════
#  TESTS — Schema validation au chargement
# ═══════════════════════════════════════════════════════════════════════════════


class TestSchemaValidation:
    """Tests pour la validation de schema au chargement mémoire."""

    def test_valid_yaml_no_warning(self, mcp_env, caplog):
        """Un fichier YAML valide ne doit pas générer de warning."""
        with caplog.at_level(logging.WARNING, logger="argus.mcp.memory"):
            mcp_env["mem"].load_patterns()
        schema_warnings = [r for r in caplog.records if "Schema validation failed" in r.message]
        assert len(schema_warnings) == 0

    def test_schema_cache_works(self, mcp_env):
        """Le cache de schemas doit retourner le même objet."""
        from mcp_server.memory_reader import _load_schema, _schemas_cache

        _schemas_cache.clear()
        s1 = _load_schema("defect_patterns.schema.json")
        s2 = _load_schema("defect_patterns.schema.json")
        # S'il existe, il vient du cache
        if s1 is not None:
            assert s1 is s2

    def test_missing_schema_returns_none(self, mcp_env):
        """Un schema inexistant retourne None sans erreur."""
        from mcp_server.memory_reader import _load_schema

        result = _load_schema("nonexistent.schema.json")
        assert result is None

    def test_load_works_without_jsonschema(self, mcp_env, monkeypatch):
        """Le chargement fonctionne même si jsonschema n'est pas installé."""
        import mcp_server.memory_reader as mem_mod

        def mock_validate(data, schema_name, file_path):
            # Simuler l'absence de jsonschema
            pass

        monkeypatch.setattr(mem_mod, "_validate_yaml", mock_validate)
        patterns = mcp_env["mem"].load_patterns()
        assert len(patterns) == 2


# ═══════════════════════════════════════════════════════════════════════════════
#  TESTS — Structured logging
# ═══════════════════════════════════════════════════════════════════════════════


class TestStructuredLogging:
    """Tests pour la configuration du logging structuré."""

    def test_configure_logging_sets_handler(self, mcp_env):
        """_configure_logging doit configurer un handler sur stderr."""
        mcp_env["server"]._configure_logging()
        root_logger = logging.getLogger("argus")
        assert root_logger.level <= logging.INFO
        assert len(root_logger.handlers) >= 1

    def test_configure_logging_idempotent(self, mcp_env):
        """Appeler _configure_logging deux fois ne doit pas dupliquer les handlers."""
        mcp_env["server"]._configure_logging()
        count_before = len(logging.getLogger("argus").handlers)
        mcp_env["server"]._configure_logging()
        count_after = len(logging.getLogger("argus").handlers)
        assert count_after == count_before

    def test_record_pattern_logs_info(self, mcp_env, caplog):
        """record_pattern doit logger un message INFO."""
        with caplog.at_level(logging.INFO, logger="argus.mcp"):
            mcp_env["server"].record_pattern(
                name="Log Test Pattern",
                category="security",
                severity_typical="high",
                description="Test logging",
            )
        info_msgs = [r for r in caplog.records if "PAT-SEC-002" in r.message]
        assert len(info_msgs) >= 1

    def test_record_heuristic_logs_info(self, mcp_env, caplog):
        """record_heuristic doit logger un message INFO."""
        with caplog.at_level(logging.INFO, logger="argus.mcp"):
            mcp_env["server"].record_heuristic(
                name="Log Test Heuristic",
                category="coverage",
                action="Test logging action",
            )
        info_msgs = [r for r in caplog.records if "HEU-COV-002" in r.message]
        assert len(info_msgs) >= 1

    def test_record_analysis_logs_info(self, mcp_env, caplog):
        """record_analysis doit logger un message INFO."""
        with caplog.at_level(logging.INFO, logger="argus.mcp"):
            mcp_env["server"].record_analysis(
                title="Log Test Analysis",
                findings=[{"title": "F1"}],
            )
        info_msgs = [r for r in caplog.records if "ANL-" in r.message]
        assert len(info_msgs) >= 1

    def test_error_logs_on_corrupted_memory(self, mcp_env, caplog):
        """Une erreur de chargement doit générer un log ERROR."""
        (mcp_env["memory"] / "semantic" / "defect_patterns.yaml").write_text(
            "{{invalid", encoding="utf-8"
        )
        with caplog.at_level(logging.ERROR, logger="argus.mcp"):
            mcp_env["server"].get_risk_analysis("x = 1")
        error_msgs = [r for r in caplog.records if r.levelno >= logging.ERROR]
        assert len(error_msgs) >= 1


# ═══════════════════════════════════════════════════════════════════════════════
#  TESTS — _category_to_prefix / _heuristic_category_to_prefix
# ═══════════════════════════════════════════════════════════════════════════════


class TestCategoryPrefixes:
    """Tests pour les fonctions de mapping catégorie → préfixe."""

    def test_pattern_category_prefixes(self, mcp_env):
        srv = mcp_env["server"]
        assert srv._category_to_prefix("security") == "SEC"
        assert srv._category_to_prefix("null_safety") == "NULL"
        assert srv._category_to_prefix("performance") == "PERF"
        assert srv._category_to_prefix("api") == "API"
        assert srv._category_to_prefix("accessibility") == "A11Y"
        assert srv._category_to_prefix("data_integrity") == "DATA"

    def test_heuristic_category_prefixes(self, mcp_env):
        srv = mcp_env["server"]
        assert srv._heuristic_category_to_prefix("selection") == "SEL"
        assert srv._heuristic_category_to_prefix("coverage") == "COV"
        assert srv._heuristic_category_to_prefix("automation") == "AUT"
        assert srv._heuristic_category_to_prefix("api_testing") == "API"
        assert srv._heuristic_category_to_prefix("security_testing") == "SEC"

    def test_unknown_category_uses_truncation(self, mcp_env):
        srv = mcp_env["server"]
        result = srv._category_to_prefix("some_new_category")
        assert len(result) <= 4
        assert result == result.upper()
