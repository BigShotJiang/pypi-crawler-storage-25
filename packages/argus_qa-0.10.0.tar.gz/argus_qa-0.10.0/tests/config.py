#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 ARGUS — Configuration centralisée
 Constantes partagées par les moteurs et scripts de validation
═══════════════════════════════════════════════════════════════════════════════

Engine constants are defined in mcp_server.engines.config and re-exported
here for backward compatibility with tests/ and CLI scripts.
"""

from pathlib import Path

# ═══════════════════════════════════════════════════════════════════════════════
#  PATHS
# ═══════════════════════════════════════════════════════════════════════════════

PROJECT_ROOT = Path(__file__).resolve().parent.parent
MEMORY_DIR = PROJECT_ROOT / "memory"

# ═══════════════════════════════════════════════════════════════════════════════
#  ENGINE CONSTANTS — re-exported from mcp_server.engines.config
# ═══════════════════════════════════════════════════════════════════════════════

from mcp_server.engines.config import (  # noqa: E402, F401
    CATEGORY_DECAY_RATES,
    CONFIDENCE_BOOST,
    CONSOLIDATION_LAG_THRESHOLD,
    DECAY_GRACE_DAYS,
    DECAY_RATE,
    DECAY_RATE_REINFORCED,
    DECAY_THRESHOLD,
    LOW_CONFIDENCE,
    PROTECTED_CATEGORIES,
)

# ═══════════════════════════════════════════════════════════════════════════════
#  RISK SCORING
# ═══════════════════════════════════════════════════════════════════════════════

VALID_MULTIPLIER_SOURCES = {"data_integrity", "security", "performance", "regression", "api"}
CRITICAL_THRESHOLD = 15.0
HIGH_THRESHOLD = 8.0
SCORE_TOLERANCE = 0.01
