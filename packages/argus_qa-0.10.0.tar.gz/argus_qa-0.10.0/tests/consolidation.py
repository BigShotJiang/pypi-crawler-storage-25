#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ARGUS - Moteur de Consolidation Memoire (re-exporter + CLI)

Engine code lives in mcp_server.engines.consolidation.
This module re-exports for backward compatibility and provides CLI.
"""

import sys
import argparse
import json
import logging
from pathlib import Path
from datetime import datetime

from mcp_server.engines.consolidation import (  # noqa: F401
    ConsolidationEngine,
    ConsolidationReport,
    Reinforcement,
    NewPatternCandidate,
)
from mcp_server.engines.config import CONFIDENCE_BOOST  # noqa: F401

logger = logging.getLogger(__name__)


def main():
    logging.basicConfig(level=logging.INFO, format='%(message)s')
    parser = argparse.ArgumentParser(
        description="Argus - Memory Consolidation Engine"
    )
    parser.add_argument(
        "--apply", action="store_true",
        help="Apply consolidations (default: detect only)"
    )
    parser.add_argument(
        "--quiet", action="store_true",
        help="Suppress output (exit code only)"
    )
    parser.add_argument(
        "--json", action="store_true",
        help="Output JSON report"
    )
    parser.add_argument(
        "--base-dir", type=str, default=None,
        help="Project root directory (default: auto-detect)"
    )
    args = parser.parse_args()

    base_dir = args.base_dir or str(Path(__file__).parent.parent)
    verbose = not args.quiet and not args.json

    engine = ConsolidationEngine(base_dir, verbose=verbose)

    try:
        if args.apply:
            report = engine.apply()
        else:
            report = engine.scan()
    except Exception as e:
        if args.json:
            print(json.dumps({"error": str(e)}, indent=2))
        elif not args.quiet:
            print(f"\n  x Error: {e}", file=sys.stderr)
        sys.exit(2)

    if args.json:
        print(json.dumps(report.to_dict(), indent=2, ensure_ascii=False))

    sys.exit(1 if report.has_actions else 0)


if __name__ == "__main__":
    main()
