#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ARGUS - Orchestrateur de Cycle Cognitif (re-exporter + CLI)

Engine code lives in mcp_server.engines.cognitive_cycle.
This module re-exports for backward compatibility and provides CLI.
"""

import sys
import argparse
import json
import logging
from pathlib import Path
from datetime import datetime

from mcp_server.engines.cognitive_cycle import (  # noqa: F401
    CognitiveCycle,
    CycleReport,
    PhaseResult,
    VALID_PHASES,
)

logger = logging.getLogger(__name__)


def main():
    logging.basicConfig(level=logging.INFO, format='%(message)s')
    parser = argparse.ArgumentParser(
        description="Argus - Cognitive Cycle Orchestrator"
    )
    parser.add_argument(
        "--apply", action="store_true",
        help="Apply consolidation and decay (default: scan/dry-run)"
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Scan only, do not apply (same as no --apply)"
    )
    parser.add_argument(
        "--phase", type=str, default=None,
        choices=VALID_PHASES,
        help="Run a single phase instead of full cycle"
    )
    parser.add_argument(
        "--quiet", action="store_true",
        help="Suppress output (exit code only)"
    )
    parser.add_argument(
        "--json", action="store_true",
        help="Output JSON report"
    )
    parser.add_argument(
        "--save-session", action="store_true",
        help="Save a working session record after the cycle"
    )
    parser.add_argument(
        "--base-dir", type=str, default=None,
        help="Project root directory (default: auto-detect)"
    )
    parser.add_argument(
        "--reference-date", type=str, default=None,
        help="Reference date for decay/reflection (YYYY-MM-DD). Default: today"
    )
    args = parser.parse_args()

    base_dir = args.base_dir or str(Path(__file__).parent.parent)
    verbose = not args.quiet and not args.json

    ref_date = None
    if args.reference_date:
        ref_date = datetime.strptime(args.reference_date, "%Y-%m-%d")

    phases = [args.phase] if args.phase else None
    apply = args.apply and not args.dry_run

    cycle = CognitiveCycle(base_dir, verbose=verbose, reference_date=ref_date)

    try:
        report = cycle.run(phases=phases, apply=apply)
    except Exception as e:
        if args.json:
            print(json.dumps({"error": str(e)}, indent=2))
        elif not args.quiet:
            print(f"\n  x Error: {e}", file=sys.stderr)
        sys.exit(2)

    if args.save_session:
        try:
            cycle.save_session()
        except Exception as e:
            if not args.quiet:
                print(f"\n  Warning: Session save failed: {e}", file=sys.stderr)

    if args.json:
        print(json.dumps(report.to_dict(), indent=2, ensure_ascii=False))

    sys.exit(1 if report.has_actions else 0)


if __name__ == "__main__":
    main()
