# Agents par défaut embarqués dans le package Argus MCP
