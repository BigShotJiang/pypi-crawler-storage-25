#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 ARGUS MCP — File Locking
 Protection des écritures concurrentes (SEC-007)
═══════════════════════════════════════════════════════════════════════════════
"""

import contextlib
import logging
import os
import time
from pathlib import Path

logger = logging.getLogger("argus.mcp")

_LOCK_TIMEOUT = 10  # secondes
_LOCK_RETRY_INTERVAL = 0.1  # secondes entre tentatives


@contextlib.contextmanager
def file_lock(lock_path: Path):
    """Verrou fichier cross-platform pour protéger les écritures concurrentes.

    Utilise un fichier .lock dédié (pas le fichier cible) pour éviter
    toute corruption. Le verrou est automatiquement libéré en sortie.
    """
    lock_file = lock_path.with_suffix(lock_path.suffix + ".lock")
    deadline = time.monotonic() + _LOCK_TIMEOUT
    fd = None
    try:
        while True:
            try:
                # O_CREAT | O_EXCL : création atomique, échoue si existant
                fd = os.open(str(lock_file), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                break
            except FileExistsError:
                if time.monotonic() >= deadline:
                    # Verrou périmé ? Nettoyage forcé (stale lock)
                    _cleanup_stale_lock(lock_file)
                    if time.monotonic() >= deadline + _LOCK_RETRY_INTERVAL:
                        raise TimeoutError(
                            f"Impossible d'acquérir le verrou {lock_file} après {_LOCK_TIMEOUT}s"
                        )
                time.sleep(_LOCK_RETRY_INTERVAL)
        yield
    finally:
        if fd is not None:
            os.close(fd)
        with contextlib.suppress(FileNotFoundError):
            lock_file.unlink()


def _cleanup_stale_lock(lock_file: Path) -> None:
    """Supprime un fichier lock périmé (> 2× le timeout)."""
    try:
        age = time.time() - lock_file.stat().st_mtime
        if age > _LOCK_TIMEOUT * 2:
            logger.warning("Removing stale lock file: %s (age: %.1fs)", lock_file, age)
            lock_file.unlink()
    except FileNotFoundError:
        pass
