"""
═══════════════════════════════════════════════════════════════════════════════
 ARGUS — Cognitive Engines
 Consolidation, Decay, Reflection & Cognitive Cycle
═══════════════════════════════════════════════════════════════════════════════
"""

from .config import (
    CATEGORY_DECAY_RATES,
    CONFIDENCE_BOOST,
    CONSOLIDATION_LAG_THRESHOLD,
    DECAY_GRACE_DAYS,
    DECAY_RATE,
    DECAY_RATE_REINFORCED,
    DECAY_THRESHOLD,
    LOW_CONFIDENCE,
    PROTECTED_CATEGORIES,
)
from .consolidation import (
    ConsolidationEngine,
    ConsolidationReport,
    NewPatternCandidate,
    Reinforcement,
)
from .decay import DecayAction, DecayEngine, DecayReport
from .reflection import (
    HealthCheck,
    MemoryStats,
    ReflectionEngine,
    ReflectionReport,
)
from .cognitive_cycle import (
    CognitiveCycle,
    CycleReport,
    PhaseResult,
    VALID_PHASES,
)

__all__ = [
    # Config
    "DECAY_RATE",
    "DECAY_RATE_REINFORCED",
    "DECAY_THRESHOLD",
    "DECAY_GRACE_DAYS",
    "PROTECTED_CATEGORIES",
    "CATEGORY_DECAY_RATES",
    "CONFIDENCE_BOOST",
    "LOW_CONFIDENCE",
    "CONSOLIDATION_LAG_THRESHOLD",
    # Consolidation
    "ConsolidationEngine",
    "ConsolidationReport",
    "Reinforcement",
    "NewPatternCandidate",
    # Decay
    "DecayEngine",
    "DecayReport",
    "DecayAction",
    # Reflection
    "ReflectionEngine",
    "ReflectionReport",
    "HealthCheck",
    "MemoryStats",
    # Cognitive Cycle
    "CognitiveCycle",
    "CycleReport",
    "PhaseResult",
    "VALID_PHASES",
]
