"""
═══════════════════════════════════════════════════════════════════════════════
 ARGUS — Engine Configuration
 Constantes partagées par les moteurs cognitifs
═══════════════════════════════════════════════════════════════════════════════
"""

# ═══════════════════════════════════════════════════════════════════════════════
#  DECAY ENGINE
#  Règles d'oubli contrôlé (persona: memory.operations.forgetting)
# ═══════════════════════════════════════════════════════════════════════════════

DECAY_RATE = 0.05
DECAY_RATE_REINFORCED = 0.02
DECAY_THRESHOLD = 0.20
DECAY_GRACE_DAYS = 60
PROTECTED_CATEGORIES = {"security", "critical"}

CATEGORY_DECAY_RATES: dict[str, float] = {
    "performance": 0.03,
    "data_integrity": 0.03,
    "error_handling": 0.04,
    "api": 0.04,
    "accessibility": 0.03,
    "concurrency": 0.03,
    "null_safety": 0.04,
    "regression": 0.06,
    "ui": 0.07,
    "seo": 0.06,
    "functional": 0.05,
    "requirements": 0.05,
    "async": 0.04,
}

# ═══════════════════════════════════════════════════════════════════════════════
#  CONSOLIDATION ENGINE
# ═══════════════════════════════════════════════════════════════════════════════

CONFIDENCE_BOOST = {
    "incident_match": 0.03,
    "analysis_finding": 0.02,
    "heuristic_applied": 0.01,
}

# ═══════════════════════════════════════════════════════════════════════════════
#  REFLECTION ENGINE
# ═══════════════════════════════════════════════════════════════════════════════

LOW_CONFIDENCE = 0.40
CONSOLIDATION_LAG_THRESHOLD = 5

# ═══════════════════════════════════════════════════════════════════════════════
#  RISK SCORING
# ═══════════════════════════════════════════════════════════════════════════════

VALID_MULTIPLIER_SOURCES = {"data_integrity", "security", "performance", "regression", "api"}
CRITICAL_THRESHOLD = 15.0
HIGH_THRESHOLD = 8.0
SCORE_TOLERANCE = 0.01
