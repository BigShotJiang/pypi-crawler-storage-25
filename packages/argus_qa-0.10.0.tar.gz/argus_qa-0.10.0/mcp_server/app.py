#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 ARGUS MCP — Application Instance
 Instance FastMCP partagée entre les modules de tools
═══════════════════════════════════════════════════════════════════════════════
"""

from mcp.server.fastmcp import FastMCP

mcp = FastMCP(
    "Argus QA Orchestrator",
    instructions=(
        "Argus est un orchestrateur QA spécialisé en test et qualité logicielle. "
        "Il maintient une mémoire structurée (patterns de défauts, heuristiques de test, "
        "analyses épisodiques, profils de contexte) et fournit des recommandations "
        "actionnables basées sur cette knowledge base."
    ),
)

# ═══════════════════════════════════════════════════════════════════════════════
#  SECURITY LIMITS
# ═══════════════════════════════════════════════════════════════════════════════

MAX_CODE_INPUT_SIZE = 500_000  # 500 KB max pour code_or_diff
MAX_FINDINGS_COUNT = 50  # Max findings par analyse
MAX_DAILY_ANALYSES = 100  # Max analyses enregistrées par jour
MAX_DAILY_RECORDS = 200  # Max record_pattern + record_heuristic par jour
MAX_DAILY_EPISODES = 100  # Max episodic records (decisions + incidents + executions) per day
