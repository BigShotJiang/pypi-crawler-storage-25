#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 ARGUS MCP SERVER
 "Celui aux cent yeux qui voit ce que d'autres ne voient pas"

 Expose la mémoire et les capacités d'analyse d'Argus via le
 Model Context Protocol (MCP). Compatible VS Code, Claude Desktop,
 Cursor, et tout client MCP.

 Transport : stdio (standard pour les intégrations IDE)

 Tools exposés :
   1. query_memory     — Interrogation de la mémoire sémantique/épisodique
   2. get_risk_analysis — Analyse de risque sur un diff ou fichier
   3. get_testing_strategy — Recommandation de stratégie de test
   4. record_analysis   — Enregistrement d'une analyse en mémoire épisodique
   5. record_pattern    — Ajout d'un defect pattern en mémoire sémantique
   6. record_heuristic  — Ajout d'une heuristique de test en mémoire sémantique
   7. record_decision   — Enregistrement d'une décision en mémoire épisodique
   8. record_incident   — Enregistrement d'un incident en mémoire épisodique
   9. record_execution  — Enregistrement d'une exécution de tests
  10. run_cognitive_cycle — Cycle cognitif (consolidation/decay/reflection)
  11. get_memory_health  — Diagnostic de santé de la mémoire
  12. generate_test_scaffold — Génération de squelette de fichier de test
  13. get_test_cases     — Recommandation de cas de test à écrire
  14. audit_code_security — Audit de sécurité statique multi-domaine
  15. audit_code_performance — Audit de performance statique multi-domaine

 Lancement :
   python -m mcp_server.server
═══════════════════════════════════════════════════════════════════════════════
"""

import json
import logging
import sys

from . import data_dir
from . import memory_reader as mem

# ═══════════════════════════════════════════════════════════════════════════════
#  Shared MCP instance (created in app.py, tools registered by tools package)
# ═══════════════════════════════════════════════════════════════════════════════
from .app import (  # noqa: F401
    MAX_CODE_INPUT_SIZE,
    MAX_DAILY_ANALYSES,
    MAX_DAILY_RECORDS,
    MAX_FINDINGS_COUNT,
    mcp,
)

# Importing the tools package triggers @mcp.tool() registration for all tools
from . import tools  # noqa: F401

# ═══════════════════════════════════════════════════════════════════════════════
#  Backward-compatible re-exports — tests & external code import from here
# ═══════════════════════════════════════════════════════════════════════════════
from .app import MAX_DAILY_EPISODES  # noqa: F401
from .locking import file_lock as _file_lock  # noqa: F401
from .tools.query import query_memory  # noqa: F401
from .tools.analysis import (  # noqa: F401
    get_risk_analysis,
    get_testing_strategy,
    _get_technical_signals,
    _severity_to_score,
    _recommend_test_types,
)
from .tools.recording import (  # noqa: F401
    record_analysis,
    record_pattern,
    record_heuristic,
    record_decision,
    record_incident,
    record_execution,
    _category_to_prefix,
    _heuristic_category_to_prefix,
    _count_today_analyses,
    _count_today_semantic_records,
    _count_today_episodic_records,
    _update_index_after_analysis,
    _update_index_semantic,
    _update_index_after_episodic,
    _VALID_PATTERN_CATEGORIES,
    _VALID_SEVERITIES,
    _VALID_HEURISTIC_CATEGORIES,
    _VALID_PRIORITIES,
    _VALID_INCIDENT_SEVERITIES,
    _CATEGORY_TO_YAML_KEY,
)
from .tools.cognitive import (  # noqa: F401
    run_cognitive_cycle,
    get_memory_health,
)
from .tools.testing import (  # noqa: F401
    generate_test_scaffold,
    get_test_cases,
)
from .tools.security import (  # noqa: F401
    audit_code_security,
)
from .tools.performance import (  # noqa: F401
    audit_code_performance,
)

logger = logging.getLogger("argus.mcp")


# ═══════════════════════════════════════════════════════════════════════════════
#  RESOURCES — Expose key files as MCP resources
# ═══════════════════════════════════════════════════════════════════════════════


@mcp.resource("argus://persona")
def get_persona() -> str:
    """La persona complète d'Argus (CRAFT/TOON framework)."""
    persona_path = mem.get_project_root() / "argus.persona.yaml"
    return persona_path.read_text(encoding="utf-8")


@mcp.resource("argus://memory/stats")
def get_stats_resource() -> str:
    """Statistiques globales de la mémoire."""
    return json.dumps(mem.get_memory_stats(), ensure_ascii=False, indent=2, default=str)


# ═══════════════════════════════════════════════════════════════════════════════
#  ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════════


def main():
    """Point d'entrée principal — lance le serveur MCP en mode stdio."""
    # Configure structured logging
    _configure_logging()

    # Ensure data directory is initialized (first-run setup for pip users)
    resolved = data_dir.get_data_dir()
    logger.info(
        "Argus MCP server starting",
        extra={
            "data_dir": str(resolved),
            "version": "0.10.0",
        },
    )
    print(f"Argus data: {resolved}", file=sys.stderr)
    mcp.run(transport="stdio")


def _configure_logging() -> None:
    """Configure le logging structuré pour Argus MCP.

    Format : [ISO timestamp] LEVEL argus.mcp — message (clé=valeur, ...)
    Écrit sur stderr pour ne pas interférer avec le transport stdio.
    """
    root_logger = logging.getLogger("argus")
    if root_logger.handlers:
        return  # Déjà configuré (ex: tests)

    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(
        logging.Formatter(
            fmt="[%(asctime)s] %(levelname)-7s %(name)s — %(message)s",
            datefmt="%Y-%m-%dT%H:%M:%S",
        )
    )
    root_logger.addHandler(handler)
    root_logger.setLevel(logging.INFO)


if __name__ == "__main__":
    main()
