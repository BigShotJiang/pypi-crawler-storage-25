#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 ARGUS MCP — Memory Reader
 Accès en lecture à la mémoire YAML d'Argus
═══════════════════════════════════════════════════════════════════════════════
"""

import json
import logging
from pathlib import Path
from typing import Any

import yaml

from . import data_dir

logger = logging.getLogger("argus.mcp.memory")

# ═══════════════════════════════════════════════════════════════════════════════
#  SCHEMA VALIDATION
# ═══════════════════════════════════════════════════════════════════════════════

_schemas_cache: dict[str, dict] = {}


def _get_schema_dir() -> Path:
    """Retourne le dossier schemas/ du projet."""
    return get_project_root() / "schemas"


def _load_schema(schema_name: str) -> dict | None:
    """Charge un JSON Schema depuis le dossier schemas/. Retourne None si indisponible."""
    if schema_name in _schemas_cache:
        return _schemas_cache[schema_name]
    schema_path = _get_schema_dir() / schema_name
    if not schema_path.exists():
        return None
    try:
        with open(schema_path, "r", encoding="utf-8") as f:
            schema = json.load(f)
        _schemas_cache[schema_name] = schema
        return schema
    except Exception as exc:
        logger.warning("Failed to load schema %s: %s", schema_name, exc)
        return None


def _validate_yaml(data: Any, schema_name: str, file_path: Path) -> None:
    """Valide un document YAML contre son JSON Schema. Log un warning si invalide.

    Ne lève jamais d'exception — la validation est advisory, pas bloquante.
    """
    schema = _load_schema(schema_name)
    if schema is None:
        return
    try:
        import jsonschema

        jsonschema.validate(instance=data, schema=schema)
        logger.debug("Schema validation OK: %s", file_path.name)
    except ImportError:
        # jsonschema est optionnel (dev dependency)
        pass
    except jsonschema.ValidationError as exc:
        logger.warning(
            "Schema validation failed for %s: %s (path: %s)",
            file_path.name,
            exc.message,
            list(exc.absolute_path),
        )
    except Exception as exc:
        logger.warning("Schema validation error for %s: %s", file_path.name, exc)


# Mapping fichiers → schemas pour la validation automatique
_FILE_SCHEMA_MAP: dict[str, str] = {
    "_index.yaml": "memory_index.schema.json",
    "defect_patterns.yaml": "defect_patterns.schema.json",
    "testing_heuristics.yaml": "testing_heuristics.schema.json",
    "context_profiles.yaml": "context_profiles.schema.json",
    "technology_knowledge.yaml": "technology_knowledge.schema.json",
    "istqb_knowledge.yaml": "istqb_knowledge.schema.json",
    "associations.yaml": "associations.schema.json",
    "evolution_log.yaml": "evolution_log.schema.json",
    "argus.persona.yaml": "persona.schema.json",
}


def get_memory_root() -> Path:
    """Retourne le chemin racine de la mémoire Argus."""
    return data_dir.get_data_dir()


def get_project_root() -> Path:
    """Retourne le chemin racine du projet Argus."""
    return data_dir.get_project_root()


def _as_dict(raw: dict[str, Any] | list | None) -> dict[str, Any]:
    """Convertit un résultat _load_yaml en dict (fallback {} si list ou None)."""
    return raw if isinstance(raw, dict) else {}


def _load_yaml(path: Path) -> dict[str, Any] | list | None:
    """Charge un fichier YAML. Retourne None si le fichier n'existe pas.

    Valide automatiquement le contenu contre le JSON Schema correspondant
    si disponible (validation advisory — log warning, ne bloque pas).
    """
    if not path.exists():
        return None
    # SEC-006 — Validation que le chemin reste dans le périmètre du projet
    resolved = path.resolve()
    allowed_root = get_project_root().resolve()
    if not resolved.is_relative_to(allowed_root):
        return None
    with open(path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    # Validation schema automatique
    schema_name = _FILE_SCHEMA_MAP.get(path.name)
    if schema_name and data is not None:
        _validate_yaml(data, schema_name, path)
    return data


# ═══════════════════════════════════════════════════════════════════════════════
#  INDEX
# ═══════════════════════════════════════════════════════════════════════════════


def load_index() -> dict[str, Any]:
    """Charge l'index mémoire principal."""
    return _as_dict(_load_yaml(get_memory_root() / "_index.yaml"))


# ═══════════════════════════════════════════════════════════════════════════════
#  SEMANTIC MEMORY
# ═══════════════════════════════════════════════════════════════════════════════


def load_patterns() -> list[dict]:
    """Charge tous les defect patterns."""
    data = _as_dict(_load_yaml(get_memory_root() / "semantic" / "defect_patterns.yaml"))
    return data.get("patterns", [])


def load_heuristics() -> list[dict]:
    """Charge toutes les heuristics de test."""
    data = _as_dict(_load_yaml(get_memory_root() / "semantic" / "testing_heuristics.yaml"))
    heuristics = []
    if not data:
        return heuristics
    # Les heuristiques sont regroupées par catégorie (test_selection, prioritization, etc.)
    for key, value in data.items():
        if isinstance(value, list):
            for item in value:
                if isinstance(item, dict) and "id" in item:
                    heuristics.append(item)
    return heuristics


def load_context_profiles() -> list[dict]:
    """Charge les profils de contexte applicatif."""
    data = _as_dict(_load_yaml(get_memory_root() / "semantic" / "context_profiles.yaml"))
    return data.get("profiles", [])


def load_technology_knowledge() -> dict[str, Any]:
    """Charge les connaissances technologiques."""
    return _as_dict(_load_yaml(get_memory_root() / "semantic" / "technology_knowledge.yaml"))


def load_istqb_knowledge() -> dict[str, Any]:
    """Charge les connaissances ISTQB."""
    return _as_dict(_load_yaml(get_memory_root() / "semantic" / "istqb_knowledge.yaml"))


# ═══════════════════════════════════════════════════════════════════════════════
#  EPISODIC MEMORY
# ═══════════════════════════════════════════════════════════════════════════════


def _load_episodic_dir(subdir: str) -> list[dict]:
    """Charge tous les fichiers YAML d'un sous-dossier épisodique (hors templates)."""
    directory = get_memory_root() / "episodic" / subdir
    if not directory.exists():
        return []
    # Schema correspondant (ex: "analyses" → "analysis.schema.json")
    _episodic_schema_map = {
        "analyses": "analysis.schema.json",
        "decisions": "decision.schema.json",
        "incidents": "incident.schema.json",
        "executions": "execution.schema.json",
    }
    schema_name = _episodic_schema_map.get(subdir)
    entries = []
    for f in sorted(directory.glob("*.yaml")):
        if f.name.startswith("_template"):
            continue
        data = _load_yaml(f)
        if data:
            if schema_name:
                _validate_yaml(data, schema_name, f)
            entries.append(data)
    return entries


def load_analyses() -> list[dict]:
    """Charge toutes les analyses épisodiques."""
    return _load_episodic_dir("analyses")


def load_decisions() -> list[dict]:
    """Charge toutes les décisions."""
    return _load_episodic_dir("decisions")


def load_incidents() -> list[dict]:
    """Charge tous les incidents."""
    return _load_episodic_dir("incidents")


def load_executions() -> list[dict]:
    """Charge toutes les exécutions de tests."""
    return _load_episodic_dir("executions")


# ═══════════════════════════════════════════════════════════════════════════════
#  PROJECT MEMORY
# ═══════════════════════════════════════════════════════════════════════════════


def load_projects() -> list[dict]:
    """Charge tous les profils projet (hors templates)."""
    directory = get_memory_root() / "projects"
    if not directory.exists():
        return []
    projects = []
    for f in sorted(directory.glob("*.yaml")):
        if f.name.startswith("_template"):
            continue
        data = _load_yaml(f)
        if data:
            projects.append(data)
    return projects


# ═══════════════════════════════════════════════════════════════════════════════
#  RELATIONAL MEMORY
# ═══════════════════════════════════════════════════════════════════════════════


def load_associations() -> dict[str, Any]:
    """Charge le graphe d'associations."""
    return _as_dict(_load_yaml(get_memory_root() / "relational" / "associations.yaml"))


# ═══════════════════════════════════════════════════════════════════════════════
#  PERSONA
# ═══════════════════════════════════════════════════════════════════════════════


def load_persona() -> dict[str, Any]:
    """Charge la persona Argus."""
    return _as_dict(_load_yaml(get_project_root() / "argus.persona.yaml"))


# ═══════════════════════════════════════════════════════════════════════════════
#  SEARCH UTILITIES
# ═══════════════════════════════════════════════════════════════════════════════


def search_patterns(
    query: str | None = None,
    category: str | None = None,
    min_confidence: float | None = None,
) -> list[dict]:
    """Recherche des patterns par texte, catégorie, ou seuil de confidence."""
    patterns = load_patterns()
    results = patterns

    if category:
        results = [p for p in results if p.get("category") == category]

    if min_confidence is not None:
        results = [p for p in results if p.get("confidence", 0) >= min_confidence]

    if query:
        q = query.lower()
        results = [
            p
            for p in results
            if q in p.get("name", "").lower()
            or q in p.get("id", "").lower()
            or q in str(p.get("signature", {}).get("description", "")).lower()
            or q in p.get("category", "").lower()
        ]

    return results


def search_heuristics(
    query: str | None = None,
    category: str | None = None,
    min_confidence: float | None = None,
) -> list[dict]:
    """Recherche des heuristics par texte, catégorie, ou seuil de confidence."""
    heuristics = load_heuristics()
    results = heuristics

    if category:
        results = [h for h in results if h.get("category") == category]

    if min_confidence is not None:
        results = [h for h in results if h.get("confidence", 0) >= min_confidence]

    if query:
        q = query.lower()
        results = [
            h
            for h in results
            if q in h.get("name", "").lower()
            or q in h.get("id", "").lower()
            or q in str(h.get("condition", "")).lower()
            or q in str(h.get("action", "")).lower()
            or q in h.get("category", "").lower()
        ]

    return results


def get_memory_stats() -> dict[str, Any]:
    """Retourne un résumé statistique de la mémoire."""
    index = load_index()
    patterns = load_patterns()
    heuristics = load_heuristics()

    return {
        "version": index.get("version"),
        "last_updated": index.get("last_updated"),
        "counts": {
            "patterns": len(patterns),
            "heuristics": len(heuristics),
            "analyses": index.get("episodic", {}).get("analyses", {}).get("count", 0),
            "decisions": index.get("episodic", {}).get("decisions", {}).get("count", 0),
            "incidents": index.get("episodic", {}).get("incidents", {}).get("count", 0),
            "executions": index.get("episodic", {}).get("executions", {}).get("count", 0),
        },
        "pattern_categories": list({p.get("category") for p in patterns if p.get("category")}),
        "avg_pattern_confidence": (
            round(sum(p.get("confidence", 0) for p in patterns) / len(patterns), 3)
            if patterns
            else 0
        ),
        "avg_heuristic_confidence": (
            round(sum(h.get("confidence", 0) for h in heuristics) / len(heuristics), 3)
            if heuristics
            else 0
        ),
    }
