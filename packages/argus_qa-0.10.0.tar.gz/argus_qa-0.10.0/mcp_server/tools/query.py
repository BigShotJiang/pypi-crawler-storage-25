#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 ARGUS MCP — Tool: query_memory
 Interrogation de la mémoire sémantique/épisodique
═══════════════════════════════════════════════════════════════════════════════
"""

import json
import logging
from typing import Any

from ..app import mcp
from .. import memory_reader as mem

logger = logging.getLogger("argus.mcp")


@mcp.tool()
def query_memory(
    section: str,
    query: str | None = None,
    category: str | None = None,
    min_confidence: float | None = None,
    limit: int = 100,
    offset: int = 0,
) -> str:
    """Interroge la mémoire d'Argus (patterns, heuristiques, analyses, projets, stats).

    Args:
        section: Section à interroger. Valeurs possibles :
            - "patterns" : Defect patterns (46 patterns, 12 catégories)
            - "heuristics" : Heuristiques de test (62 heuristiques)
            - "analyses" : Historique des analyses réalisées
            - "decisions" : Décisions architecturales documentées
            - "incidents" : Incidents et échappés enregistrés
            - "executions" : Résultats d'exécutions de tests
            - "projects" : Profils de projets analysés
            - "profiles" : Profils de contexte applicatif (fintech, e-commerce, etc.)
            - "associations" : Graphe relationnel entre entités
            - "stats" : Résumé statistique global de la mémoire
            - "index" : Index de la mémoire complète
        query: Texte de recherche (filtre par nom, description, catégorie). Optionnel.
        category: Filtre par catégorie (ex: "security", "api", "performance"). Optionnel.
        min_confidence: Seuil minimum de confidence (0.0 - 1.0). Optionnel.
        limit: Nombre maximum de résultats à retourner (1-1000). Par défaut 100.
        offset: Index de début pour la pagination (0-based). Par défaut 0.

    Returns:
        Résultats au format JSON avec métadonnées de pagination.
    """
    section = section.lower().strip()

    # Clamp pagination values
    limit = max(1, min(1000, limit))
    offset = max(0, offset)

    loaders: dict[str, Any] = {
        "patterns": lambda: mem.search_patterns(query, category, min_confidence),
        "heuristics": lambda: mem.search_heuristics(query, category, min_confidence),
        "analyses": mem.load_analyses,
        "decisions": mem.load_decisions,
        "incidents": mem.load_incidents,
        "executions": mem.load_executions,
        "projects": mem.load_projects,
        "profiles": mem.load_context_profiles,
        "associations": mem.load_associations,
        "stats": mem.get_memory_stats,
        "index": mem.load_index,
    }

    if section not in loaders:
        return json.dumps(
            {
                "error": f"Section '{section}' inconnue.",
                "available_sections": list(loaders.keys()),
            },
            ensure_ascii=False,
            indent=2,
        )

    try:
        data = loaders[section]()
    except Exception as exc:
        logger.error("query_memory(%s) failed: %s", section, exc)
        return json.dumps(
            {
                "error": f"Erreur lors du chargement de la section '{section}'.",
                "detail": str(exc),
            },
            ensure_ascii=False,
            indent=2,
        )

    result_count = len(data) if isinstance(data, list) else 1

    # Apply pagination to list results
    total_count = result_count
    has_more = False
    if isinstance(data, list):
        data = data[offset : offset + limit]
        has_more = (offset + limit) < total_count

    return json.dumps(
        {
            "section": section,
            "query": query,
            "category": category,
            "min_confidence": min_confidence,
            "result_count": len(data) if isinstance(data, list) else 1,
            "total_count": total_count,
            "limit": limit,
            "offset": offset,
            "has_more": has_more,
            "results": data,
        },
        ensure_ascii=False,
        indent=2,
        default=str,
    )
