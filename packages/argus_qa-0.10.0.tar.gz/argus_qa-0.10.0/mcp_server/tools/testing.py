#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 ARGUS MCP — Tools: generate_test_scaffold, get_test_cases
 Aide à la création de tests unitaires et de composants
═══════════════════════════════════════════════════════════════════════════════
"""

import json
import logging
import re

from ..app import mcp, MAX_CODE_INPUT_SIZE
from .. import memory_reader as mem

logger = logging.getLogger("argus.mcp")


# ═══════════════════════════════════════════════════════════════════════════════
#  Helpers
# ═══════════════════════════════════════════════════════════════════════════════


def _detect_language(code: str, language: str | None) -> str:
    """Détecte le langage à partir du code si non spécifié."""
    if language:
        return language.lower().strip()
    # Heuristiques de détection simples
    if re.search(r"\bdef\b.*:\s*$", code, re.MULTILINE):
        return "python"
    if re.search(r"\b(?:function|const|let|var)\b.*=>|import\s+.*from\s+['\"]", code):
        if re.search(r":\s*(?:string|number|boolean|interface|type)\b", code):
            return "typescript"
        return "javascript"
    if re.search(r"\bclass\b.*\bextends\b.*\bComponent\b", code):
        return "typescript"
    if re.search(r"\bpackage\b.*;\s*$", code, re.MULTILINE):
        return "java"
    if re.search(r"\bnamespace\b.*\{", code):
        return "csharp"
    return "unknown"


def _detect_framework(language: str, test_framework: str | None) -> str:
    """Renvoie le framework de test par défaut si non spécifié."""
    if test_framework:
        return test_framework.lower().strip()
    defaults = {
        "python": "pytest",
        "javascript": "vitest",
        "typescript": "vitest",
        "java": "junit5",
        "csharp": "xunit",
        "go": "testing",
    }
    return defaults.get(language, "unknown")


def _extract_functions(code: str, language: str) -> list[dict]:
    """Extrait les signatures de fonctions/méthodes depuis le code source."""
    functions: list[dict] = []

    if language == "python":
        for m in re.finditer(
            r"(?:^|\n)([ \t]*)(?:async\s+)?def\s+(\w+)\s*\(([^)]*)\)(?:\s*->\s*([^\n:]+))?",
            code,
        ):
            indent, name, params, return_type = m.groups()
            is_method = len(indent) > 0
            functions.append(
                {
                    "name": name,
                    "params": [
                        p.strip().split(":")[0].strip().split("=")[0].strip()
                        for p in params.split(",")
                        if p.strip() and p.strip() != "self" and p.strip() != "cls"
                    ],
                    "return_type": (return_type or "").strip(),
                    "is_method": is_method,
                    "is_private": name.startswith("_") and not name.startswith("__"),
                    "is_async": "async" in (m.group(0) or ""),
                }
            )

    elif language in ("javascript", "typescript"):
        # function declarations
        for m in re.finditer(
            r"(?:export\s+)?(?:async\s+)?function\s+(\w+)\s*\(([^)]*)\)",
            code,
        ):
            name, params = m.groups()
            functions.append(
                {
                    "name": name,
                    "params": [
                        p.strip().split(":")[0].strip().split("=")[0].strip()
                        for p in params.split(",")
                        if p.strip()
                    ],
                    "return_type": "",
                    "is_method": False,
                    "is_private": name.startswith("_"),
                    "is_async": "async" in (m.group(0) or ""),
                }
            )
        # arrow functions assigned to const/let
        for m in re.finditer(
            r"(?:export\s+)?(?:const|let)\s+(\w+)\s*=\s*(?:async\s+)?\(?([^)=]*)\)?\s*=>",
            code,
        ):
            name, params = m.groups()
            functions.append(
                {
                    "name": name,
                    "params": [
                        p.strip().split(":")[0].strip().split("=")[0].strip()
                        for p in params.split(",")
                        if p.strip()
                    ],
                    "return_type": "",
                    "is_method": False,
                    "is_private": name.startswith("_"),
                    "is_async": "async" in (m.group(0) or ""),
                }
            )
        # class methods
        for m in re.finditer(
            r"(?:async\s+)?(\w+)\s*\(([^)]*)\)\s*(?::\s*\w+)?\s*\{",
            code,
        ):
            name, params = m.groups()
            if name not in ("if", "for", "while", "switch", "catch", "function"):
                functions.append(
                    {
                        "name": name,
                        "params": [
                            p.strip().split(":")[0].strip().split("=")[0].strip()
                            for p in params.split(",")
                            if p.strip()
                        ],
                        "return_type": "",
                        "is_method": True,
                        "is_private": name.startswith("_") or name.startswith("#"),
                        "is_async": "async" in (m.group(0) or ""),
                    }
                )

    return functions


def _extract_classes(code: str, language: str) -> list[dict]:
    """Extrait les noms de classes depuis le code source."""
    classes: list[dict] = []

    if language == "python":
        for m in re.finditer(r"class\s+(\w+)\s*(?:\(([^)]*)\))?:", code):
            name, bases = m.groups()
            classes.append(
                {
                    "name": name,
                    "bases": [b.strip() for b in (bases or "").split(",") if b.strip()],
                }
            )

    elif language in ("javascript", "typescript"):
        for m in re.finditer(r"class\s+(\w+)(?:\s+extends\s+(\w+))?", code):
            name, base = m.groups()
            classes.append(
                {
                    "name": name,
                    "bases": [base] if base else [],
                }
            )

    return classes


def _detect_dependencies(code: str, language: str) -> list[str]:
    """Détecte les dépendances externes à mocker."""
    deps: list[str] = []

    # Appels réseau / DB / filesystem
    network_patterns = [
        (r"fetch\s*\(", "HTTP client (fetch)"),
        (r"axios\b", "HTTP client (axios)"),
        (r"requests\.\w+\s*\(", "HTTP client (requests)"),
        (r"httpx\.\w+", "HTTP client (httpx)"),
    ]
    db_patterns = [
        (r"\.query\s*\(", "database query"),
        (r"\.execute\s*\(", "database execute"),
        (r"Session\s*\(", "database session"),
        (r"\.find(?:One|Many)?\s*\(", "database query (ORM)"),
        (r"\.save\s*\(", "database save (ORM)"),
    ]
    fs_patterns = [
        (r"(?:open|readFile|writeFile|readdir)\s*\(", "filesystem I/O"),
        (r"Path\(", "filesystem path"),
        (r"fs\.\w+\s*\(", "filesystem (fs)"),
    ]
    time_patterns = [
        (r"datetime\.now|time\.time|Date\.now|new Date", "clock/time"),
    ]
    external_patterns = [
        (r"\.send(?:_email|_mail|_message)?\s*\(", "email/messaging"),
        (r"stripe\b|paypal\b|payment", "payment service"),
        (r"redis\b|cache\.\w+", "cache"),
    ]

    all_patterns = network_patterns + db_patterns + fs_patterns + time_patterns + external_patterns
    for pattern, label in all_patterns:
        if re.search(pattern, code, re.IGNORECASE):
            deps.append(label)

    return list(dict.fromkeys(deps))  # deduplicate preserving order


def _generate_edge_cases(functions: list[dict], patterns: list[dict]) -> list[dict]:
    """Génère des cas limites basés sur les paramètres et les patterns Argus."""
    edge_cases: list[dict] = []

    for func in functions:
        func_name = func["name"]
        params = func["params"]

        # Cas limites universels
        if params:
            edge_cases.append(
                {
                    "function": func_name,
                    "case": "Paramètres manquants / None / undefined",
                    "category": "boundary",
                    "priority": "P0",
                }
            )

        # Détection par nom de paramètre
        for param in params:
            param_lower = param.lower()
            if any(kw in param_lower for kw in ("list", "items", "array", "data", "collection")):
                edge_cases.extend(
                    [
                        {
                            "function": func_name,
                            "case": f"{param}: liste vide",
                            "category": "boundary",
                            "priority": "P0",
                        },
                        {
                            "function": func_name,
                            "case": f"{param}: un seul élément",
                            "category": "boundary",
                            "priority": "P1",
                        },
                        {
                            "function": func_name,
                            "case": f"{param}: très grande liste",
                            "category": "boundary",
                            "priority": "P2",
                        },
                    ]
                )
            if any(kw in param_lower for kw in ("name", "title", "text", "str", "string", "query")):
                edge_cases.extend(
                    [
                        {
                            "function": func_name,
                            "case": f"{param}: chaîne vide",
                            "category": "boundary",
                            "priority": "P0",
                        },
                        {
                            "function": func_name,
                            "case": f"{param}: caractères spéciaux / unicode",
                            "category": "boundary",
                            "priority": "P1",
                        },
                        {
                            "function": func_name,
                            "case": f"{param}: chaîne très longue",
                            "category": "boundary",
                            "priority": "P2",
                        },
                    ]
                )
            if any(
                kw in param_lower
                for kw in (
                    "id",
                    "count",
                    "amount",
                    "price",
                    "quantity",
                    "num",
                    "size",
                    "limit",
                    "offset",
                    "age",
                )
            ):
                edge_cases.extend(
                    [
                        {
                            "function": func_name,
                            "case": f"{param}: valeur 0",
                            "category": "boundary",
                            "priority": "P0",
                        },
                        {
                            "function": func_name,
                            "case": f"{param}: valeur négative",
                            "category": "boundary",
                            "priority": "P0",
                        },
                        {
                            "function": func_name,
                            "case": f"{param}: valeur maximale",
                            "category": "boundary",
                            "priority": "P1",
                        },
                    ]
                )
            if any(kw in param_lower for kw in ("email", "url", "path", "phone", "date")):
                edge_cases.extend(
                    [
                        {
                            "function": func_name,
                            "case": f"{param}: format invalide",
                            "category": "validation",
                            "priority": "P0",
                        },
                        {
                            "function": func_name,
                            "case": f"{param}: format valide",
                            "category": "happy_path",
                            "priority": "P0",
                        },
                    ]
                )

        # Cas async
        if func.get("is_async"):
            edge_cases.extend(
                [
                    {
                        "function": func_name,
                        "case": "Rejet / exception async",
                        "category": "error",
                        "priority": "P0",
                    },
                    {
                        "function": func_name,
                        "case": "Timeout de l'opération async",
                        "category": "error",
                        "priority": "P1",
                    },
                ]
            )

    return edge_cases


def _build_scaffold_python(
    functions: list[dict],
    classes: list[dict],
    deps: list[str],
    edge_cases: list[dict],
    test_framework: str,
    file_path: str | None,
) -> str:
    """Génère un scaffold de tests Python."""
    lines: list[str] = []

    # Imports
    if test_framework == "pytest":
        lines.append("import pytest")
        if any(f.get("is_async") for f in functions):
            lines.append("import pytest_asyncio")
    else:
        lines.append("import unittest")

    if deps:
        if test_framework == "pytest":
            lines.append("from unittest.mock import MagicMock, patch, AsyncMock")
        else:
            lines.append("from unittest.mock import MagicMock, patch, AsyncMock")

    lines.append("")

    # Import du module testé (placeholder)
    if file_path:
        module_name = file_path.replace("/", ".").replace("\\", ".").removesuffix(".py")
        imports = ", ".join(f["name"] for f in functions if not f["is_private"])
        if classes:
            imports = ", ".join(c["name"] for c in classes) + (", " + imports if imports else "")
        if imports:
            lines.append(f"from {module_name} import {imports}")
    else:
        lines.append("# from <module> import <classes_and_functions>")

    lines.append("")
    lines.append("")

    # Mocking fixtures
    if deps and test_framework == "pytest":
        lines.append("# ─── Fixtures ──────────────────────────────────────────────")
        lines.append("")
        for dep in deps:
            fixture_name = dep.replace(" ", "_").replace("(", "").replace(")", "").replace("/", "_")
            lines.append("@pytest.fixture")
            lines.append(f"def mock_{fixture_name}():")
            lines.append(f'    """Mock pour {dep}."""')
            lines.append(f"    with patch('<target.{fixture_name}>') as mock:")
            lines.append("        yield mock")
            lines.append("")
        lines.append("")

    # Tests par classe
    for cls in classes:
        cls_name = cls["name"]

        if test_framework == "pytest":
            lines.append(f"class Test{cls_name}:")
            lines.append(f'    """Tests unitaires pour {cls_name}."""')
            lines.append("")
            lines.append("    def test_instantiation(self):")
            lines.append(f'        """Vérifie que {cls_name} peut être instancié."""')
            lines.append("        # Arrange")
            lines.append("        # Act")
            lines.append(f"        instance = {cls_name}()")
            lines.append("        # Assert")
            lines.append("        assert instance is not None")
            lines.append("")
        else:
            lines.append(f"class Test{cls_name}(unittest.TestCase):")
            lines.append(f'    """Tests unitaires pour {cls_name}."""')
            lines.append("")

    # Tests par fonction
    for func in functions:
        if func["is_private"]:
            continue
        func_name = func["name"]
        func_edge_cases = [ec for ec in edge_cases if ec["function"] == func_name]

        if test_framework == "pytest":
            # Happy path
            if func.get("is_async"):
                lines.append("@pytest.mark.asyncio")
                lines.append(f"async def test_{func_name}_happy_path():")
            else:
                lines.append(f"def test_{func_name}_happy_path():")
            lines.append(f'    """Vérifie le comportement nominal de {func_name}."""')
            lines.append("    # Arrange")
            lines.append("    # TODO: préparer les données d'entrée")
            lines.append("    # Act")
            lines.append(f"    # result = {func_name}(...)")
            lines.append("    # Assert")
            lines.append("    # assert result == expected")
            lines.append("    raise NotImplementedError")
            lines.append("")

            # Edge cases
            for ec in func_edge_cases:
                case_slug = re.sub(r"[^a-z0-9]+", "_", ec["case"].lower()).strip("_")
                if func.get("is_async"):
                    lines.append("@pytest.mark.asyncio")
                    lines.append(f"async def test_{func_name}_{case_slug}():")
                else:
                    lines.append(f"def test_{func_name}_{case_slug}():")
                lines.append(f'    """{ec["case"]}."""')
                lines.append("    # Arrange / Act / Assert")
                lines.append("    raise NotImplementedError")
                lines.append("")

            # Error case
            if func.get("is_async"):
                lines.append("@pytest.mark.asyncio")
                lines.append(f"async def test_{func_name}_error_case():")
            else:
                lines.append(f"def test_{func_name}_error_case():")
            lines.append(f'    """Vérifie la gestion d\'erreur de {func_name}."""')
            lines.append("    # Arrange : conditions provoquant une erreur")
            lines.append("    # Act & Assert")
            lines.append("    # with pytest.raises(ExpectedException):")
            lines.append(f"    #     {func_name}(...)")
            lines.append("    raise NotImplementedError")
            lines.append("")

    return "\n".join(lines)


def _build_scaffold_js(
    functions: list[dict],
    classes: list[dict],
    deps: list[str],
    edge_cases: list[dict],
    test_framework: str,
    file_path: str | None,
) -> str:
    """Génère un scaffold de tests JavaScript/TypeScript."""
    lines: list[str] = []

    # Imports
    if test_framework in ("vitest", "jest"):
        lines.append(f"import {{ describe, it, expect, vi, beforeEach }} from '{test_framework}';")
    lines.append("")

    # Import du module testé (placeholder)
    if file_path:
        module_path = "./" + file_path.removesuffix(".ts").removesuffix(".js").removesuffix(
            ".tsx"
        ).removesuffix(".jsx")
        imports = ", ".join(f["name"] for f in functions if not f["is_private"])
        if classes:
            imports = ", ".join(c["name"] for c in classes) + (", " + imports if imports else "")
        if imports:
            lines.append(f"import {{ {imports} }} from '{module_path}';")
    else:
        lines.append("// import { ... } from '<module>';")

    lines.append("")

    # Mocks
    if deps:
        lines.append("// ─── Mocks ──────────────────────────────────────────────")
        for dep in deps:
            mock_fn = "vi.fn" if test_framework == "vitest" else "jest.fn"
            lines.append(f"// {mock_fn}() pour {dep}")
        lines.append("")

    # Tests par classe
    for cls in classes:
        cls_name = cls["name"]
        lines.append(f"describe('{cls_name}', () => {{")
        lines.append(f"  let instance: {cls_name};")
        lines.append("")
        lines.append("  beforeEach(() => {{")
        lines.append(f"    instance = new {cls_name}();")
        lines.append("  }});")
        lines.append("")
        lines.append("  it('should be instantiated', () => {{")
        lines.append("    expect(instance).toBeDefined();")
        lines.append("  }});")
        lines.append("")

        # Méthodes de la classe
        class_funcs = [f for f in functions if f["is_method"] and not f["is_private"]]
        for func in class_funcs:
            func_name = func["name"]
            func_edge_cases = [ec for ec in edge_cases if ec["function"] == func_name]

            lines.append(f"  describe('{func_name}', () => {{")
            lines.append(f"    it('should handle the nominal case', {_async_kw(func)}() => {{")
            lines.append("      // Arrange")
            lines.append("      // Act")
            lines.append(f"      // const result = {_await_kw(func)}instance.{func_name}();")
            lines.append("      // Assert")
            lines.append("      // expect(result).toBe(expected);")
            lines.append("      throw new Error('Not implemented');")
            lines.append("    }});")
            lines.append("")

            for ec in func_edge_cases:
                lines.append(f"    it('should handle: {ec['case']}', {_async_kw(func)}() => {{")
                lines.append("      // Arrange / Act / Assert")
                lines.append("      throw new Error('Not implemented');")
                lines.append("    }});")
                lines.append("")

            lines.append("  }});")
            lines.append("")

        lines.append("}});")
        lines.append("")

    # Tests de fonctions standalone
    standalone_funcs = [f for f in functions if not f["is_method"] and not f["is_private"]]
    for func in standalone_funcs:
        func_name = func["name"]
        func_edge_cases = [ec for ec in edge_cases if ec["function"] == func_name]

        lines.append(f"describe('{func_name}', () => {{")

        # Happy path
        lines.append(f"  it('should handle the nominal case', {_async_kw(func)}() => {{")
        lines.append("    // Arrange")
        lines.append("    // Act")
        lines.append(f"    // const result = {_await_kw(func)}{func_name}();")
        lines.append("    // Assert")
        lines.append("    // expect(result).toBe(expected);")
        lines.append("    throw new Error('Not implemented');")
        lines.append("  }});")
        lines.append("")

        # Edge cases
        for ec in func_edge_cases:
            lines.append(f"  it('should handle: {ec['case']}', {_async_kw(func)}() => {{")
            lines.append("    // Arrange / Act / Assert")
            lines.append("    throw new Error('Not implemented');")
            lines.append("  }});")
            lines.append("")

        # Error case
        lines.append(f"  it('should throw on invalid input', {_async_kw(func)}() => {{")
        lines.append("    // Arrange & Act & Assert")
        if func.get("is_async"):
            lines.append(f"    // await expect({func_name}()).rejects.toThrow();")
        else:
            lines.append(f"    // expect(() => {func_name}()).toThrow();")
        lines.append("    throw new Error('Not implemented');")
        lines.append("  }});")

        lines.append("}});")

    return "\n".join(lines)


def _async_kw(func: dict) -> str:
    return "async " if func.get("is_async") else ""


def _await_kw(func: dict) -> str:
    return "await " if func.get("is_async") else ""


# ═══════════════════════════════════════════════════════════════════════════════
#  TOOL — generate_test_scaffold
# ═══════════════════════════════════════════════════════════════════════════════


@mcp.tool()
def generate_test_scaffold(
    code: str,
    language: str | None = None,
    test_framework: str | None = None,
    file_path: str | None = None,
) -> str:
    """Génère un squelette de fichier de test pour le code source fourni.

    Analyse le code pour extraire les fonctions, classes et dépendances,
    puis génère un scaffold de test complet avec :
    - Les imports nécessaires
    - Des fixtures/mocks pour les dépendances externes
    - Des tests pour chaque fonction publique (happy path, edge cases, erreurs)
    - La bonne structure selon le framework (Arrange/Act/Assert, describe/it)

    Les cas limites sont déduits des paramètres et des patterns de défauts Argus.

    Args:
        code: Code source à tester (fonction, classe, module).
        language: Langage de programmation (python, javascript, typescript).
            Auto-détecté si non spécifié.
        test_framework: Framework de test (pytest, unittest, vitest, jest, junit5).
            Par défaut selon le langage.
        file_path: Chemin du fichier source (pour générer les imports). Optionnel.

    Returns:
        JSON contenant le scaffold de test et les métadonnées d'analyse.
    """
    if len(code) > MAX_CODE_INPUT_SIZE:
        return json.dumps(
            {
                "error": f"Code trop volumineux ({len(code)} caractères). Maximum : {MAX_CODE_INPUT_SIZE}."
            },
            ensure_ascii=False,
            indent=2,
        )

    lang = _detect_language(code, language)
    framework = _detect_framework(lang, test_framework)

    functions = _extract_functions(code, lang)
    classes = _extract_classes(code, lang)
    deps = _detect_dependencies(code, lang)

    # Charger les patterns Argus pour enrichir les edge cases
    try:
        patterns = mem.load_patterns()
    except Exception:
        patterns = []

    edge_cases = _generate_edge_cases(functions, patterns)

    # Générer le scaffold selon le langage
    if lang == "python":
        scaffold = _build_scaffold_python(
            functions, classes, deps, edge_cases, framework, file_path
        )
    elif lang in ("javascript", "typescript"):
        scaffold = _build_scaffold_js(functions, classes, deps, edge_cases, framework, file_path)
    else:
        scaffold = f"# TODO: scaffold generation non supportée pour '{lang}'\n# Fonctions détectées : {[f['name'] for f in functions]}"

    return json.dumps(
        {
            "scaffold": scaffold,
            "metadata": {
                "language": lang,
                "test_framework": framework,
                "source_file": file_path,
                "functions_detected": len(functions),
                "classes_detected": len(classes),
                "dependencies_to_mock": deps,
                "edge_cases_generated": len(edge_cases),
                "functions": [
                    {"name": f["name"], "params": f["params"], "is_async": f["is_async"]}
                    for f in functions
                    if not f["is_private"]
                ],
                "classes": [c["name"] for c in classes],
            },
        },
        ensure_ascii=False,
        indent=2,
    )


# ═══════════════════════════════════════════════════════════════════════════════
#  TOOL — get_test_cases
# ═══════════════════════════════════════════════════════════════════════════════


@mcp.tool()
def get_test_cases(
    description: str,
    code: str | None = None,
    context_profile: str = "CTX-GENERIC",
    component_type: str = "function",
) -> str:
    """Recommande les cas de test à écrire pour un composant ou une fonctionnalité.

    Croise la description du comportement avec les heuristiques de test,
    les patterns de défauts et le profil de contexte Argus pour produire
    une liste priorisée de cas de test couvrant :
    - Happy path (cas nominal)
    - Cas limites (boundary value analysis)
    - Cas d'erreur et exceptions
    - Cas de sécurité (si pertinent au contexte)

    Args:
        description: Description du comportement à tester (ex: "Fonction de calcul
            de réduction qui applique un pourcentage au prix total du panier").
        code: Code source du composant (optionnel, enrichit l'analyse).
        context_profile: Profil de contexte applicatif (CTX-GENERIC, CTX-FINTECH,
            CTX-ECOMMERCE, etc.). Par défaut CTX-GENERIC.
        component_type: Type de composant parmi : "function", "class", "api_endpoint",
            "ui_component", "hook", "middleware". Par défaut "function".

    Returns:
        Liste structurée de cas de test recommandés au format JSON.
    """
    if code and len(code) > MAX_CODE_INPUT_SIZE:
        return json.dumps(
            {
                "error": f"Code trop volumineux ({len(code)} caractères). Maximum : {MAX_CODE_INPUT_SIZE}."
            },
            ensure_ascii=False,
            indent=2,
        )

    try:
        patterns = mem.load_patterns()
        _heuristics = mem.load_heuristics()  # noqa: F841
        profiles = mem.load_context_profiles()
    except Exception as exc:
        logger.error("get_test_cases: memory load failed: %s", exc)
        return json.dumps(
            {"error": "Erreur lors du chargement de la mémoire sémantique.", "detail": str(exc)},
            ensure_ascii=False,
            indent=2,
        )

    profile = next(
        (p for p in profiles if p.get("id") == context_profile),
        next((p for p in profiles if p.get("id") == "CTX-GENERIC"), {}),
    )

    desc_lower = description.lower()
    test_cases: list[dict] = []
    case_id = 0

    # ── 1. Happy path ─────────────────────────────────────────────────────
    case_id += 1
    test_cases.append(
        {
            "id": f"TC-{case_id:03d}",
            "category": "happy_path",
            "priority": "P0",
            "title": "Cas nominal — comportement attendu avec des données valides",
            "description": f"Vérifier que {description.rstrip('.')} fonctionne correctement avec des entrées valides.",
            "technique": "Specification-based",
        }
    )

    # ── 2. Cas limites basés sur les heuristiques EP/BVA ──────────────────
    boundary_keywords = {
        "vide": ("liste vide", "chaîne vide", "aucun élément"),
        "zéro": ("valeur 0", "quantité 0", "montant 0"),
        "négatif": ("valeur négative", "montant négatif"),
        "maximum": ("valeur maximale", "limite supérieure"),
        "null": ("valeur null / None / undefined",),
        "doublon": ("éléments en double", "entrée dupliquée"),
    }
    for concept, examples in boundary_keywords.items():
        for example in examples:
            if any(kw in desc_lower for kw in (concept, example.split()[0])):
                case_id += 1
                test_cases.append(
                    {
                        "id": f"TC-{case_id:03d}",
                        "category": "boundary",
                        "priority": "P0",
                        "title": f"Cas limite — {example}",
                        "description": f"Vérifier le comportement quand l'entrée est : {example}.",
                        "technique": "BVA (Boundary Value Analysis)",
                    }
                )
                break  # One case per concept

    # Cas limites universels toujours pertinents
    universal_boundaries = [
        ("Entrée vide / nulle", "Vérifier le comportement avec une entrée absente, nulle ou vide."),
        ("Valeurs aux limites", "Tester avec les valeurs min et max acceptables."),
    ]
    for title, desc in universal_boundaries:
        case_id += 1
        test_cases.append(
            {
                "id": f"TC-{case_id:03d}",
                "category": "boundary",
                "priority": "P0",
                "title": f"Cas limite — {title}",
                "description": desc,
                "technique": "BVA / Equivalence Partitioning",
            }
        )

    # ── 3. Cas d'erreur ───────────────────────────────────────────────────
    error_cases = [
        ("Entrée invalide (type incorrect)", "Vérifier la gestion des types inattendus."),
        ("Entrée invalide (format incorrect)", "Vérifier la gestion des formats non conformes."),
    ]
    if component_type == "api_endpoint":
        error_cases.extend(
            [
                ("Requête non authentifiée", "Vérifier le rejet des requêtes sans auth."),
                ("Requête non autorisée", "Vérifier le rejet pour permissions insuffisantes."),
                ("Payload malformé", "Vérifier la gestion d'un body JSON invalide."),
            ]
        )
    if component_type == "ui_component":
        error_cases.extend(
            [
                (
                    "Props requises manquantes",
                    "Vérifier le comportement sans les props obligatoires.",
                ),
                ("Rendu sans données", "Vérifier l'affichage avec un état de chargement ou vide."),
            ]
        )

    for title, desc in error_cases:
        case_id += 1
        test_cases.append(
            {
                "id": f"TC-{case_id:03d}",
                "category": "error",
                "priority": "P0",
                "title": f"Erreur — {title}",
                "description": desc,
                "technique": "Error Guessing",
            }
        )

    # ── 4. Cas déduits des patterns de défauts Argus ──────────────────────
    relevant_patterns = []
    for p in patterns:
        sig_desc = str(p.get("signature", {}).get("description", "")).lower()
        cat = p.get("category", "").lower()
        indicators = [
            str(i).lower()
            for i in p.get("signature", {}).get("indicators", [])
            if isinstance(i, str)
        ]

        relevance = 0
        for word in desc_lower.split():
            if len(word) > 3:
                if word in sig_desc:
                    relevance += 2
                if word in cat:
                    relevance += 1
                if any(word in ind for ind in indicators):
                    relevance += 1

        # Aussi vérifier le code si fourni
        if code and relevance == 0:
            code_lower = code.lower()
            for indicator in indicators:
                keywords = [w for w in re.findall(r"[a-z_]+", indicator) if len(w) > 4]
                if sum(1 for kw in keywords if kw in code_lower) >= 2:
                    relevance += 2
                    break

        if relevance >= 2:
            relevant_patterns.append(
                {
                    "pattern": p,
                    "relevance": relevance,
                }
            )

    relevant_patterns.sort(key=lambda x: x["relevance"], reverse=True)

    for rp in relevant_patterns[:5]:
        p = rp["pattern"]
        case_id += 1
        prevention = p.get("prevention_strategy", [])
        test_cases.append(
            {
                "id": f"TC-{case_id:03d}",
                "category": "defect_pattern",
                "priority": "P1",
                "title": f"Pattern {p.get('id')} — {p.get('name')}",
                "description": str(p.get("signature", {}).get("description", "")),
                "technique": "Defect-based testing (Argus pattern)",
                "pattern_id": p.get("id"),
                "severity": p.get("severity_typical"),
                "prevention_hints": prevention[:3] if isinstance(prevention, list) else [],
            }
        )

    # ── 5. Cas spécifiques au type de composant ───────────────────────────
    component_cases: dict[str, list[tuple[str, str, str]]] = {
        "api_endpoint": [
            (
                "Idempotence",
                "Vérifier que des appels identiques successifs produisent le même résultat.",
                "P1",
            ),
            ("Rate limiting / throttling", "Vérifier le comportement sous charge rapide.", "P2"),
            ("Réponse de timeout", "Vérifier la gestion du timeout backend.", "P1"),
        ],
        "ui_component": [
            (
                "Rendu initial",
                "Vérifier le rendu correct au montage avec les props par défaut.",
                "P0",
            ),
            ("Interaction utilisateur", "Vérifier la réaction aux clicks, inputs, hovers.", "P0"),
            (
                "Mise à jour des props",
                "Vérifier le re-rendu correct après changement de props.",
                "P1",
            ),
            ("Accessibilité", "Vérifier les rôles ARIA, la navigation clavier, les labels.", "P1"),
        ],
        "hook": [
            ("Valeur initiale", "Vérifier la valeur retournée au premier rendu.", "P0"),
            ("Mise à jour d'état", "Vérifier le changement d'état après action.", "P0"),
            ("Cleanup", "Vérifier le nettoyage à l'unmount (effect cleanup).", "P1"),
            (
                "Re-render avec deps changées",
                "Vérifier la ré-exécution quand les dépendances changent.",
                "P1",
            ),
        ],
        "middleware": [
            (
                "Pass-through",
                "Vérifier que le middleware passe au suivant pour les cas valides.",
                "P0",
            ),
            ("Blocage", "Vérifier que le middleware bloque les cas invalides.", "P0"),
            ("Modification de requête/réponse", "Vérifier les transformations appliquées.", "P1"),
        ],
    }

    for title, desc, prio in component_cases.get(component_type, []):
        case_id += 1
        test_cases.append(
            {
                "id": f"TC-{case_id:03d}",
                "category": "component_specific",
                "priority": prio,
                "title": f"{component_type} — {title}",
                "description": desc,
                "technique": "Component testing",
            }
        )

    # ── 6. Cas de sécurité selon le profil de contexte ────────────────────
    mandatory_checks = profile.get("mandatory_checks", [])
    security_keywords = (
        "auth",
        "security",
        "payment",
        "password",
        "token",
        "session",
        "login",
        "injection",
        "xss",
        "csrf",
        "sanitiz",
        "encrypt",
        "hash",
    )
    if any(kw in desc_lower for kw in security_keywords) or "security" in mandatory_checks:
        security_cases = [
            ("Injection", "Vérifier la résistance aux injections (SQL, XSS, commandes).", "P0"),
            ("Données sensibles", "Vérifier que les données sensibles ne sont pas exposées.", "P0"),
        ]
        for title, desc, prio in security_cases:
            case_id += 1
            test_cases.append(
                {
                    "id": f"TC-{case_id:03d}",
                    "category": "security",
                    "priority": prio,
                    "title": f"Sécurité — {title}",
                    "description": desc,
                    "technique": "Security testing (OWASP)",
                }
            )

    # ── Analyse du code source si fourni ──────────────────────────────────
    code_analysis = None
    if code:
        lang = _detect_language(code, None)
        functions = _extract_functions(code, lang)
        deps = _detect_dependencies(code, lang)
        code_edge_cases = _generate_edge_cases(functions, patterns)

        # Ajouter les edge cases spécifiques au code
        for ec in code_edge_cases:
            case_id += 1
            test_cases.append(
                {
                    "id": f"TC-{case_id:03d}",
                    "category": ec["category"],
                    "priority": ec["priority"],
                    "title": f"{ec['function']}() — {ec['case']}",
                    "description": f"Vérifier le comportement de {ec['function']} quand : {ec['case']}.",
                    "technique": "Code analysis + BVA",
                }
            )

        code_analysis = {
            "language": lang,
            "functions_detected": [f["name"] for f in functions if not f["is_private"]],
            "dependencies_to_mock": deps,
            "code_edge_cases": len(code_edge_cases),
        }

    # Déduplier par titre
    seen_titles: set[str] = set()
    unique_cases: list[dict] = []
    for tc in test_cases:
        if tc["title"] not in seen_titles:
            seen_titles.add(tc["title"])
            unique_cases.append(tc)

    # Trier : P0 > P1 > P2
    priority_order = {"P0": 0, "P1": 1, "P2": 2}
    unique_cases.sort(key=lambda tc: priority_order.get(tc["priority"], 9))

    return json.dumps(
        {
            "component_type": component_type,
            "context_profile": context_profile,
            "description": description,
            "total_test_cases": len(unique_cases),
            "by_category": {
                cat: len([tc for tc in unique_cases if tc["category"] == cat])
                for cat in dict.fromkeys(tc["category"] for tc in unique_cases)
            },
            "test_cases": unique_cases,
            "patterns_matched": [
                {"id": rp["pattern"].get("id"), "name": rp["pattern"].get("name")}
                for rp in relevant_patterns[:5]
            ],
            "code_analysis": code_analysis,
            "mandatory_checks_from_profile": mandatory_checks,
        },
        ensure_ascii=False,
        indent=2,
        default=str,
    )
