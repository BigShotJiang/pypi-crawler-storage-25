#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 ARGUS MCP — Tools Package
 Importe les sous-modules pour déclencher l'enregistrement des tools MCP
═══════════════════════════════════════════════════════════════════════════════
"""

from . import query  # noqa: F401
from . import analysis  # noqa: F401
from . import recording  # noqa: F401
from . import cognitive  # noqa: F401
from . import testing  # noqa: F401
from . import security  # noqa: F401
from . import performance  # noqa: F401
