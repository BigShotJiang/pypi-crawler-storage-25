#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 ARGUS MCP — Tools: record_*
 Enregistrement en mémoire (analyses, patterns, heuristiques, décisions,
 incidents, exécutions)
═══════════════════════════════════════════════════════════════════════════════
"""

import json
import logging
from datetime import datetime, timezone
from typing import Any

import yaml

from ..app import (
    mcp,
    MAX_DAILY_ANALYSES,
    MAX_DAILY_EPISODES,
    MAX_DAILY_RECORDS,
    MAX_FINDINGS_COUNT,
)
from ..locking import file_lock
from .. import memory_reader as mem

logger = logging.getLogger("argus.mcp")


# ═══════════════════════════════════════════════════════════════════════════════
#  VALIDATION CONSTANTS
# ═══════════════════════════════════════════════════════════════════════════════

_VALID_PATTERN_CATEGORIES = {
    "null_safety",
    "concurrency",
    "async",
    "security",
    "performance",
    "regression",
    "api",
    "data_integrity",
    "error_handling",
    "requirements",
    "functional",
    "accessibility",
    "seo",
    "ui",
}
_VALID_SEVERITIES = {"critical", "high", "medium", "low"}

_VALID_HEURISTIC_CATEGORIES = {
    "acceptance",
    "acceptance_testing",
    "api",
    "api_testing",
    "automation",
    "coverage",
    "flaky_detection",
    "istqb_black_box",
    "istqb_experience",
    "istqb_levels",
    "istqb_risk",
    "istqb_risk_based",
    "istqb_techniques",
    "istqb_test_levels",
    "istqb_white_box",
    "manual_testing",
    "prioritization",
    "requirements",
    "requirements_analysis",
    "security_testing",
    "accessibility_testing",
    "seo_testing",
    "web_testing",
    "selection",
    "test_selection",
}
_VALID_PRIORITIES = {"always", "high_priority", "when_applicable", "optional"}

_VALID_INCIDENT_SEVERITIES = {"P0", "P1", "P2", "P3", "P4"}

_CATEGORY_TO_YAML_KEY = {
    "selection": "test_selection",
    "test_selection": "test_selection",
    "prioritization": "prioritization",
    "coverage": "coverage",
    "flaky_detection": "flaky_detection",
    "automation": "automation",
    "istqb_black_box": "istqb_black_box",
    "istqb_white_box": "istqb_white_box",
    "istqb_experience": "istqb_experience",
    "istqb_levels": "istqb_levels",
    "istqb_test_levels": "istqb_levels",
    "istqb_risk": "istqb_risk",
    "istqb_risk_based": "istqb_risk",
    "istqb_techniques": "istqb_black_box",
    "api": "api_testing",
    "api_testing": "api_testing",
    "acceptance": "test_selection",
    "acceptance_testing": "test_selection",
    "manual_testing": "test_selection",
    "requirements": "test_selection",
    "requirements_analysis": "test_selection",
    "security_testing": "test_selection",
    "accessibility_testing": "test_selection",
    "seo_testing": "test_selection",
    "web_testing": "test_selection",
}


# ═══════════════════════════════════════════════════════════════════════════════
#  SHARED HELPERS
# ═══════════════════════════════════════════════════════════════════════════════


def _count_today_analyses(date_str: str) -> int:
    """Compte le nombre d'analyses enregistrées aujourd'hui."""
    analyses_dir = mem.get_memory_root() / "episodic" / "analyses"
    if not analyses_dir.exists():
        return 0
    return sum(
        1 for f in analyses_dir.glob(f"{date_str}_*.yaml") if not f.name.startswith("_template")
    )


def _count_today_episodic_records(date_str: str, subdir: str) -> int:
    """Compte le nombre d'épisodes d'un type enregistrés aujourd'hui."""
    ep_dir = mem.get_memory_root() / "episodic" / subdir
    if not ep_dir.exists():
        return 0
    return sum(1 for f in ep_dir.glob(f"{date_str}_*.yaml") if not f.name.startswith("_template"))


def _count_today_semantic_records(date_str: str) -> int:
    """Compte les enregistrements sémantiques du jour (via le log d'évolution)."""
    analyses_count = _count_today_analyses(date_str)
    return analyses_count


def _update_index_after_analysis(analysis_id: str, new_count: int) -> None:
    """Met à jour _index.yaml après l'enregistrement d'une analyse."""
    index_path = mem.get_memory_root() / "_index.yaml"
    index = mem.load_index()

    if "episodic" not in index:
        index["episodic"] = {}
    if "analyses" not in index["episodic"]:
        index["episodic"]["analyses"] = {}

    index["episodic"]["analyses"]["count"] = new_count
    index["episodic"]["analyses"]["latest"] = analysis_id
    index["last_updated"] = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    if "statistics" in index and "totals" in index["statistics"]:
        index["statistics"]["totals"]["episodes"] = (
            index["statistics"]["totals"].get("episodes", 0) + 1
        )
    if "sequences" in index:
        index["sequences"]["analysis"] = new_count

    with open(index_path, "w", encoding="utf-8") as fp:
        yaml.dump(index, fp, allow_unicode=True, default_flow_style=False, sort_keys=False)


def _update_index_semantic(section: str, total_count: int, new_seq: int) -> None:
    """Met à jour _index.yaml après l'ajout d'un pattern ou d'une heuristique."""
    index_path = mem.get_memory_root() / "_index.yaml"
    index = mem.load_index()

    if "semantic" not in index:
        index["semantic"] = {}

    key = "defect_patterns" if section == "patterns" else "testing_heuristics"
    if key not in index["semantic"]:
        index["semantic"][key] = {}
    index["semantic"][key]["count"] = total_count

    index["last_updated"] = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    if "statistics" in index and "totals" in index["statistics"]:
        index["statistics"]["totals"][section] = total_count

    seq_key = "pattern" if section == "patterns" else "heuristic"
    if "sequences" in index:
        index["sequences"][seq_key] = max(index["sequences"].get(seq_key, 0), new_seq)

    with open(index_path, "w", encoding="utf-8") as fp:
        yaml.dump(index, fp, allow_unicode=True, default_flow_style=False, sort_keys=False)


def _update_index_after_episodic(ep_type: str, ep_id: str, new_count: int) -> None:
    """Met à jour _index.yaml après l'enregistrement d'un épisode."""
    index_path = mem.get_memory_root() / "_index.yaml"
    index = mem.load_index()

    subdir_map = {"decision": "decisions", "incident": "incidents", "execution": "executions"}
    subdir = subdir_map[ep_type]

    if "episodic" not in index:
        index["episodic"] = {}
    if subdir not in index["episodic"]:
        index["episodic"][subdir] = {}

    index["episodic"][subdir]["count"] = new_count
    index["episodic"][subdir]["latest"] = ep_id
    index["last_updated"] = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    if "statistics" in index and "totals" in index["statistics"]:
        index["statistics"]["totals"]["episodes"] = (
            index["statistics"]["totals"].get("episodes", 0) + 1
        )
    if "sequences" in index:
        index["sequences"][ep_type] = new_count

    with open(index_path, "w", encoding="utf-8") as fp:
        yaml.dump(index, fp, allow_unicode=True, default_flow_style=False, sort_keys=False)


def _category_to_prefix(category: str) -> str:
    """Convertit un nom de catégorie en préfixe d'ID court."""
    prefixes = {
        "null_safety": "NULL",
        "concurrency": "CONC",
        "async": "ASYNC",
        "security": "SEC",
        "performance": "PERF",
        "regression": "REG",
        "api": "API",
        "data_integrity": "DATA",
        "error_handling": "ERR",
        "requirements": "REQ",
        "functional": "FUNC",
        "accessibility": "A11Y",
        "seo": "SEO",
        "ui": "UI",
    }
    return prefixes.get(category, category.upper()[:4])


def _heuristic_category_to_prefix(category: str) -> str:
    """Convertit un nom de catégorie d'heuristique en préfixe d'ID court."""
    prefixes = {
        "selection": "SEL",
        "test_selection": "SEL",
        "prioritization": "PRI",
        "coverage": "COV",
        "automation": "AUT",
        "flaky_detection": "FLK",
        "api": "API",
        "api_testing": "API",
        "istqb_black_box": "IBB",
        "istqb_white_box": "IWB",
        "istqb_experience": "IEX",
        "istqb_levels": "ILV",
        "istqb_test_levels": "ILV",
        "istqb_risk": "IRK",
        "istqb_risk_based": "IRK",
        "istqb_techniques": "IBB",
        "acceptance": "SEL",
        "acceptance_testing": "SEL",
        "manual_testing": "SEL",
        "requirements": "SEL",
        "requirements_analysis": "SEL",
        "security_testing": "SEC",
        "accessibility_testing": "A11",
        "seo_testing": "SEO",
        "web_testing": "WEB",
    }
    return prefixes.get(category, category.upper()[:3])


# ═══════════════════════════════════════════════════════════════════════════════
#  TOOL — record_analysis
# ═══════════════════════════════════════════════════════════════════════════════


@mcp.tool()
def record_analysis(
    title: str,
    findings: list[dict],
    project: str = "external",
    trigger: str = "manual_request",
    scope_type: str = "file",
    scope_reference: str = "",
    verdict: str = "approved_with_caveats",
) -> str:
    """Enregistre une analyse en mémoire épisodique.

    Crée un fichier YAML structuré dans memory/episodic/analyses/ avec un
    identifiant unique et met à jour l'index.

    Args:
        title: Titre court de l'analyse (ex: "Audit sécurité module auth").
        findings: Liste de findings, chacun avec :
            - title (str): Titre du finding
            - risk_level (str): "critical", "high", "medium", "low"
            - category (str): "regression", "bug", "code_smell", "security", "performance", "test_gap"
            - description (str): Description détaillée
            - recommendation (str): Action recommandée
        project: Identifiant du projet analysé. Par défaut "external".
        trigger: Déclencheur de l'analyse ("manual_request", "PR_merge", "incident_response").
        scope_type: Type de scope ("file", "PR", "directory", "full_project").
        scope_reference: Référence du scope (chemin, numéro de PR, etc.).
        verdict: Verdict global ("approved", "approved_with_caveats", "rejected").

    Returns:
        Confirmation avec l'identifiant de l'analyse créée.
    """
    # Validation taille findings (SEC-004 — fichiers YAML géants)
    if len(findings) > MAX_FINDINGS_COUNT:
        return json.dumps(
            {
                "error": f"Trop de findings ({len(findings)}). Maximum autorisé : {MAX_FINDINGS_COUNT}.",
            },
            ensure_ascii=False,
            indent=2,
        )

    # Rate limiting journalier (SEC-003 — écritures disque illimitées)
    now = datetime.now(timezone.utc)
    date_str = now.strftime("%Y-%m-%d")
    today_count = _count_today_analyses(date_str)
    if today_count >= MAX_DAILY_ANALYSES:
        return json.dumps(
            {
                "error": f"Limite journalière atteinte ({MAX_DAILY_ANALYSES} analyses/jour).",
            },
            ensure_ascii=False,
            indent=2,
        )

    timestamp_str = now.isoformat()

    # Construire les findings structurés (avant le lock pour minimiser le temps verrouillé)
    structured_findings = []
    for i, f in enumerate(findings, 1):
        structured_findings.append(
            {
                "id": f"F{i:03d}",
                "risk_level": f.get("risk_level", "medium"),
                "category": f.get("category", "finding"),
                "title": f.get("title", ""),
                "description": f.get("description", ""),
                "recommendation": f.get("recommendation", ""),
                "related_patterns": f.get("related_patterns", []),
                "related_heuristics": f.get("related_heuristics", []),
                "confidence": f.get("confidence", 0.7),
            }
        )

    # Construire le document d'analyse (template, ID sera injecté sous verrou)
    analysis = {
        "quick_summary": {
            "one_liner": title,
            "key_numbers": [
                f"{len(structured_findings)} findings identifiés",
                f"Profil: {project}",
            ],
            "status": "✅ COMPLETED",
            "key_deliverables": [],  # Rempli sous verrou
            "next_action": "Revue des findings et actions correctives",
        },
        "id": None,  # Rempli sous verrou
        "timestamp": timestamp_str,
        "duration_minutes": 0,
        "project": project,
        "trigger": trigger,
        "triggered_by": "mcp_server",
        "scope": {
            "type": scope_type,
            "reference": scope_reference,
            "files_analyzed": [],
            "components_affected": [],
        },
        "findings": structured_findings,
        "api_analysis": {"applicable": False},
        "recommendations": [
            {
                "priority": "P1",
                "action": f.get("recommendation", ""),
                "rationale": f.get("title", ""),
                "effort": "medium",
            }
            for f in structured_findings
            if f.get("recommendation")
        ],
        "metrics": {
            "coverage_before": None,
            "coverage_after": None,
            "complexity_delta": 0,
            "lines_changed": 0,
            "tests_affected": 0,
        },
        "testing": {
            "tests_executed": [],
            "tests_recommended": [],
        },
        "verdict": {
            "status": verdict,
            "summary": title,
            "conditions": [],
        },
        "outcome": {
            "recorded_at": None,
            "what_happened": None,
            "incidents_related": [],
            "feedback_received": None,
        },
        "consolidation": {
            "consolidated": False,
            "consolidated_at": None,
            "patterns_extracted": [],
            "reinforcements_generated": 0,
        },
        "tags": ["mcp-recorded", project],
    }

    # Écrire le fichier (SEC-007 — verrou pour écritures concurrentes)
    index_path = mem.get_memory_root() / "_index.yaml"
    output_path = None  # Défini sous verrou

    try:
        with file_lock(index_path):
            # Calculer l'ID sous verrou pour éviter les doublons concurrents
            index = mem.load_index()
            current_count = index.get("episodic", {}).get("analyses", {}).get("count", 0)
            seq = current_count + 1
            analysis_id = f"ANL-{now.strftime('%Y%m%d')}-{seq:03d}"

            # Injecter l'ID dans le document
            analysis["id"] = analysis_id
            analysis["quick_summary"]["key_deliverables"] = [f"Analyse {analysis_id} enregistrée"]

            filename = f"{date_str}_analysis_{analysis_id}.yaml"
            output_path = mem.get_memory_root() / "episodic" / "analyses" / filename

            with open(output_path, "w", encoding="utf-8") as fp:
                yaml.dump(
                    analysis, fp, allow_unicode=True, default_flow_style=False, sort_keys=False
                )

            # Mettre à jour l'index
            _update_index_after_analysis(analysis_id, seq)
    except TimeoutError:
        logger.error("record_analysis: lock timeout for %s", index_path)
        return json.dumps(
            {
                "error": "Écriture concurrente détectée. Réessayez dans quelques secondes.",
            },
            ensure_ascii=False,
            indent=2,
        )
    except Exception as exc:
        logger.error("record_analysis: write failed: %s", exc)
        # Nettoyage : supprimer le fichier partiel si créé
        if output_path and output_path.exists():
            output_path.unlink()
        return json.dumps(
            {
                "error": "Erreur lors de l'écriture de l'analyse.",
                "detail": str(exc),
            },
            ensure_ascii=False,
            indent=2,
        )

    logger.info(
        "Analysis %s recorded: %s (%d findings)", analysis_id, title, len(structured_findings)
    )
    return json.dumps(
        {
            "status": "success",
            "analysis_id": analysis_id,
            "file_path": str(output_path),
            "findings_count": len(structured_findings),
            "message": f"Analyse {analysis_id} enregistrée avec succès.",
        },
        ensure_ascii=False,
        indent=2,
    )


# ═══════════════════════════════════════════════════════════════════════════════
#  TOOL — record_pattern
# ═══════════════════════════════════════════════════════════════════════════════


@mcp.tool()
def record_pattern(
    name: str,
    category: str,
    severity_typical: str,
    description: str,
    confidence: float = 0.7,
    indicators: list[str] | None = None,
    code_patterns: list[str] | None = None,
    prevention_strategy: list[str] | None = None,
    related_owasp: str | None = None,
    related_cwe: str | None = None,
) -> str:
    """Enregistre un nouveau defect pattern en mémoire sémantique.

    Ajoute un pattern au fichier defect_patterns.yaml avec un identifiant
    unique auto-incrémenté et met à jour l'index.

    Args:
        name: Nom du pattern (ex: "SQL Injection via f-string").
        category: Catégorie du pattern. Valeurs possibles :
            "null_safety", "concurrency", "async", "security", "performance",
            "regression", "api", "data_integrity", "error_handling",
            "requirements", "functional", "accessibility", "seo", "ui".
        severity_typical: Sévérité typique : "critical", "high", "medium", "low".
        description: Description de la signature du pattern.
        confidence: Niveau de confiance (0.0 - 1.0). Par défaut 0.7.
        indicators: Liste d'indicateurs textuels pour détecter le pattern. Optionnel.
        code_patterns: Exemples de code patterns associés. Optionnel.
        prevention_strategy: Stratégies de prévention. Optionnel.
        related_owasp: Référence OWASP associée (ex: "A03:2021"). Optionnel.
        related_cwe: Référence CWE associée (ex: "CWE-89"). Optionnel.

    Returns:
        Confirmation avec l'identifiant du pattern créé.
    """
    # Validation des entrées
    if category not in _VALID_PATTERN_CATEGORIES:
        return json.dumps(
            {
                "error": f"Catégorie '{category}' invalide.",
                "valid_categories": sorted(_VALID_PATTERN_CATEGORIES),
            },
            ensure_ascii=False,
            indent=2,
        )

    if severity_typical not in _VALID_SEVERITIES:
        return json.dumps(
            {
                "error": f"Sévérité '{severity_typical}' invalide.",
                "valid_severities": sorted(_VALID_SEVERITIES),
            },
            ensure_ascii=False,
            indent=2,
        )

    if not 0.0 <= confidence <= 1.0:
        return json.dumps(
            {
                "error": f"Confidence {confidence} hors limites (0.0 - 1.0).",
            },
            ensure_ascii=False,
            indent=2,
        )

    if not name.strip():
        return json.dumps(
            {"error": "Le nom du pattern est obligatoire."}, ensure_ascii=False, indent=2
        )

    # Rate limiting
    now = datetime.now(timezone.utc)
    date_str = now.strftime("%Y-%m-%d")
    if _count_today_semantic_records(date_str) >= MAX_DAILY_RECORDS:
        return json.dumps(
            {
                "error": f"Limite journalière atteinte ({MAX_DAILY_RECORDS} enregistrements/jour).",
            },
            ensure_ascii=False,
            indent=2,
        )

    # Construire le nouveau pattern (hors verrou)
    new_pattern = {
        "id": None,  # Rempli sous verrou
        "name": name.strip(),
        "category": category,
        "severity_typical": severity_typical,
        "signature": {
            "description": description.strip(),
            "indicators": indicators or [],
            "code_patterns": code_patterns or [],
        },
        "prevention_strategy": prevention_strategy or [],
        "related_owasp": related_owasp,
        "related_cwe": related_cwe,
        "confidence": confidence,
        "occurrences": 0,
        "last_seen": date_str,
        "source_episodes": [],
    }

    patterns_path = mem.get_memory_root() / "semantic" / "defect_patterns.yaml"
    index_path = mem.get_memory_root() / "_index.yaml"

    try:
        with file_lock(index_path):
            # Charger les patterns existants
            raw = mem._load_yaml(patterns_path)
            data: dict[str, Any] = raw if isinstance(raw, dict) else {"patterns": []}
            patterns_list = data.get("patterns", [])

            # Calculer le prochain ID : PAT-<CAT_PREFIX>-<SEQ>
            cat_prefix = _category_to_prefix(category)
            existing_ids = [
                p["id"]
                for p in patterns_list
                if isinstance(p, dict) and p.get("id", "").startswith(f"PAT-{cat_prefix}-")
            ]
            max_seq = 0
            for pid in existing_ids:
                try:
                    max_seq = max(max_seq, int(pid.rsplit("-", 1)[1]))
                except (ValueError, IndexError):
                    pass
            new_seq = max_seq + 1
            pattern_id = f"PAT-{cat_prefix}-{new_seq:03d}"
            new_pattern["id"] = pattern_id

            # Ajouter et sauvegarder
            patterns_list.append(new_pattern)
            data["patterns"] = patterns_list
            if "metadata" in data:
                data["metadata"]["total_patterns"] = len(patterns_list)
            data["last_updated"] = date_str
            if "version" not in data:
                data["version"] = "2.0.0"

            with open(patterns_path, "w", encoding="utf-8") as fp:
                yaml.dump(data, fp, allow_unicode=True, default_flow_style=False, sort_keys=False)

            # Mettre à jour l'index
            _update_index_semantic("patterns", len(patterns_list), new_seq)

    except TimeoutError:
        logger.error("record_pattern: lock timeout")
        return json.dumps(
            {
                "error": "Écriture concurrente détectée. Réessayez dans quelques secondes.",
            },
            ensure_ascii=False,
            indent=2,
        )
    except Exception as exc:
        logger.error("record_pattern: write failed: %s", exc)
        return json.dumps(
            {
                "error": "Erreur lors de l'écriture du pattern.",
                "detail": str(exc),
            },
            ensure_ascii=False,
            indent=2,
        )

    logger.info("Pattern %s recorded: %s", pattern_id, name)
    return json.dumps(
        {
            "status": "success",
            "pattern_id": pattern_id,
            "name": name,
            "category": category,
            "message": f"Pattern {pattern_id} enregistré avec succès.",
        },
        ensure_ascii=False,
        indent=2,
    )


# ═══════════════════════════════════════════════════════════════════════════════
#  TOOL — record_heuristic
# ═══════════════════════════════════════════════════════════════════════════════


@mcp.tool()
def record_heuristic(
    name: str,
    category: str,
    action: str,
    condition: str = "",
    confidence: float = 0.7,
    priority: str = "when_applicable",
    rationale: str = "",
    related_patterns: list[str] | None = None,
) -> str:
    """Enregistre une nouvelle heuristique de test en mémoire sémantique.

    Ajoute une heuristique au fichier testing_heuristics.yaml avec un
    identifiant unique auto-incrémenté et met à jour l'index.

    Args:
        name: Nom de l'heuristique (ex: "Test Boundary Values").
        category: Catégorie de l'heuristique. Valeurs possibles :
            "selection", "prioritization", "coverage", "automation",
            "flaky_detection", "api_testing", "security_testing",
            "istqb_black_box", "istqb_white_box", "istqb_experience", etc.
        action: Action recommandée par l'heuristique.
        condition: Condition d'applicabilité de l'heuristique. Optionnel.
        confidence: Niveau de confiance (0.0 - 1.0). Par défaut 0.7.
        priority: Priorité : "always", "high_priority", "when_applicable", "optional".
        rationale: Justification / explication de l'heuristique. Optionnel.
        related_patterns: Liste d'IDs de patterns liés (ex: ["PAT-SEC-001"]). Optionnel.

    Returns:
        Confirmation avec l'identifiant de l'heuristique créée.
    """
    # Validation des entrées
    if category not in _VALID_HEURISTIC_CATEGORIES:
        return json.dumps(
            {
                "error": f"Catégorie '{category}' invalide.",
                "valid_categories": sorted(_VALID_HEURISTIC_CATEGORIES),
            },
            ensure_ascii=False,
            indent=2,
        )

    if priority not in _VALID_PRIORITIES:
        return json.dumps(
            {
                "error": f"Priorité '{priority}' invalide.",
                "valid_priorities": sorted(_VALID_PRIORITIES),
            },
            ensure_ascii=False,
            indent=2,
        )

    if not 0.0 <= confidence <= 1.0:
        return json.dumps(
            {
                "error": f"Confidence {confidence} hors limites (0.0 - 1.0).",
            },
            ensure_ascii=False,
            indent=2,
        )

    if not name.strip():
        return json.dumps(
            {"error": "Le nom de l'heuristique est obligatoire."}, ensure_ascii=False, indent=2
        )

    if not action.strip():
        return json.dumps(
            {"error": "L'action de l'heuristique est obligatoire."}, ensure_ascii=False, indent=2
        )

    # Rate limiting
    now = datetime.now(timezone.utc)
    date_str = now.strftime("%Y-%m-%d")
    if _count_today_semantic_records(date_str) >= MAX_DAILY_RECORDS:
        return json.dumps(
            {
                "error": f"Limite journalière atteinte ({MAX_DAILY_RECORDS} enregistrements/jour).",
            },
            ensure_ascii=False,
            indent=2,
        )

    # Construire la nouvelle heuristique (hors verrou)
    new_heuristic = {
        "id": None,  # Rempli sous verrou
        "name": name.strip(),
        "category": category,
        "condition": condition.strip(),
        "action": action.strip(),
        "rationale": rationale.strip(),
        "priority": priority,
        "confidence": confidence,
        "related_patterns": related_patterns or [],
        "last_seen": date_str,
    }

    heuristics_path = mem.get_memory_root() / "semantic" / "testing_heuristics.yaml"
    index_path = mem.get_memory_root() / "_index.yaml"

    try:
        with file_lock(index_path):
            # Charger les heuristiques existantes
            raw = mem._load_yaml(heuristics_path)
            data: dict[str, Any] = raw if isinstance(raw, dict) else {}

            # Calculer le prochain ID : HEU-<PREFIX>-<SEQ>
            heu_prefix = _heuristic_category_to_prefix(category)
            all_heuristics = []
            for key, value in data.items():
                if isinstance(value, list):
                    all_heuristics.extend(h for h in value if isinstance(h, dict) and "id" in h)

            existing_ids = [
                h["id"] for h in all_heuristics if h["id"].startswith(f"HEU-{heu_prefix}-")
            ]
            max_seq = 0
            for hid in existing_ids:
                try:
                    max_seq = max(max_seq, int(hid.rsplit("-", 1)[1]))
                except (ValueError, IndexError):
                    pass
            new_seq = max_seq + 1
            heuristic_id = f"HEU-{heu_prefix}-{new_seq:03d}"
            new_heuristic["id"] = heuristic_id

            # Déterminer la clé YAML pour cette catégorie
            yaml_key = _CATEGORY_TO_YAML_KEY.get(category, "test_selection")
            if yaml_key not in data:
                data[yaml_key] = []
            data[yaml_key].append(new_heuristic)

            # Mettre à jour les métadonnées
            total = sum(
                len(v)
                for v in data.values()
                if isinstance(v, list) and v and isinstance(v[0], dict) and "id" in v[0]
            )
            if "metadata" in data:
                data["metadata"]["total_heuristics"] = total
            data["last_updated"] = date_str
            if "version" not in data:
                data["version"] = "2.0.0"

            with open(heuristics_path, "w", encoding="utf-8") as fp:
                yaml.dump(data, fp, allow_unicode=True, default_flow_style=False, sort_keys=False)

            # Mettre à jour l'index
            _update_index_semantic("heuristics", total, new_seq)

    except TimeoutError:
        logger.error("record_heuristic: lock timeout")
        return json.dumps(
            {
                "error": "Écriture concurrente détectée. Réessayez dans quelques secondes.",
            },
            ensure_ascii=False,
            indent=2,
        )
    except Exception as exc:
        logger.error("record_heuristic: write failed: %s", exc)
        return json.dumps(
            {
                "error": "Erreur lors de l'écriture de l'heuristique.",
                "detail": str(exc),
            },
            ensure_ascii=False,
            indent=2,
        )

    logger.info("Heuristic %s recorded: %s", heuristic_id, name)
    return json.dumps(
        {
            "status": "success",
            "heuristic_id": heuristic_id,
            "name": name,
            "category": category,
            "yaml_section": yaml_key,
            "message": f"Heuristique {heuristic_id} enregistrée avec succès.",
        },
        ensure_ascii=False,
        indent=2,
    )


# ═══════════════════════════════════════════════════════════════════════════════
#  TOOL — record_decision
# ═══════════════════════════════════════════════════════════════════════════════


@mcp.tool()
def record_decision(
    title: str,
    context: str,
    decision: str,
    rationale: str,
    project: str = "external",
    alternatives: list[str] | None = None,
    risks: list[str] | None = None,
    tags: list[str] | None = None,
) -> str:
    """Enregistre une décision en mémoire épisodique.

    Les décisions documentent les choix architecturaux, techniques ou processuels
    et leurs justifications. Elles sont ensuite consolidées avec les patterns.

    Args:
        title: Titre court de la décision (ex: "Choix de PostgreSQL pour le cache").
        context: Contexte qui a mené à cette décision.
        decision: La décision prise.
        rationale: Justification de la décision.
        project: Identifiant du projet. Par défaut "external".
        alternatives: Alternatives considérées mais non retenues.
        risks: Risques identifiés liés à cette décision.
        tags: Tags libres pour catégorisation.

    Returns:
        Confirmation avec l'identifiant de la décision créée.
    """
    now = datetime.now(timezone.utc)
    date_str = now.strftime("%Y-%m-%d")

    if _count_today_episodic_records(date_str, "decisions") >= MAX_DAILY_EPISODES:
        return json.dumps(
            {"error": f"Limite journalière atteinte ({MAX_DAILY_EPISODES} épisodes/jour)."},
            ensure_ascii=False,
            indent=2,
        )

    decision_doc = {
        "id": None,
        "metadata": {"type": "decision", "title": title},
        "timestamp": now.isoformat(),
        "project": project,
        "context": context,
        "decision": decision,
        "rationale": rationale,
        "alternatives_considered": alternatives or [],
        "risks": risks or [],
        "status": "active",
        "consolidation": {
            "consolidated": False,
            "consolidated_at": None,
            "patterns_extracted": [],
            "reinforcements_generated": 0,
        },
        "tags": ["mcp-recorded", project] + (tags or []),
    }

    index_path = mem.get_memory_root() / "_index.yaml"
    output_path = None

    try:
        with file_lock(index_path):
            index = mem.load_index()
            current_count = index.get("episodic", {}).get("decisions", {}).get("count", 0)
            seq = current_count + 1
            dec_id = f"DEC-{now.strftime('%Y%m%d')}-{seq:03d}"

            decision_doc["id"] = dec_id
            decision_doc["metadata"]["id"] = dec_id

            filename = f"{date_str}_decision_{dec_id}.yaml"
            output_path = mem.get_memory_root() / "episodic" / "decisions" / filename
            output_path.parent.mkdir(parents=True, exist_ok=True)

            with open(output_path, "w", encoding="utf-8") as fp:
                yaml.dump(
                    decision_doc, fp, allow_unicode=True, default_flow_style=False, sort_keys=False
                )

            _update_index_after_episodic("decision", dec_id, seq)
    except TimeoutError:
        logger.error("record_decision: lock timeout for %s", index_path)
        return json.dumps(
            {"error": "Écriture concurrente détectée. Réessayez dans quelques secondes."},
            ensure_ascii=False,
            indent=2,
        )
    except Exception as exc:
        logger.error("record_decision: write failed: %s", exc)
        if output_path and output_path.exists():
            output_path.unlink()
        return json.dumps(
            {"error": "Erreur lors de l'écriture.", "detail": str(exc)},
            ensure_ascii=False,
            indent=2,
        )

    logger.info("Decision %s recorded: %s", dec_id, title)
    return json.dumps(
        {
            "status": "success",
            "decision_id": dec_id,
            "file_path": str(output_path),
            "message": f"Décision {dec_id} enregistrée avec succès.",
        },
        ensure_ascii=False,
        indent=2,
    )


# ═══════════════════════════════════════════════════════════════════════════════
#  TOOL — record_incident
# ═══════════════════════════════════════════════════════════════════════════════


@mcp.tool()
def record_incident(
    title: str,
    severity: str,
    description: str,
    project: str = "external",
    root_cause: str = "",
    matched_patterns: list[str] | None = None,
    resolution: str = "",
    tags: list[str] | None = None,
) -> str:
    """Enregistre un incident en mémoire épisodique.

    Les incidents documentent les bugs, défaillances et problèmes rencontrés.
    Ils alimentent le cycle de consolidation pour renforcer les patterns.

    Args:
        title: Titre court de l'incident (ex: "Fuite mémoire module auth").
        severity: Sévérité (P0 critique, P1 haute, P2 moyenne, P3 basse, P4 info).
        description: Description détaillée de l'incident.
        project: Identifiant du projet. Par défaut "external".
        root_cause: Cause racine identifiée.
        matched_patterns: IDs de patterns Argus correspondants (ex: ["PAT-SEC-001"]).
        resolution: Résolution appliquée ou prévue.
        tags: Tags libres pour catégorisation.

    Returns:
        Confirmation avec l'identifiant de l'incident créé.
    """
    if severity not in _VALID_INCIDENT_SEVERITIES:
        return json.dumps(
            {
                "error": f"Sévérité invalide '{severity}'. Valeurs acceptées : {sorted(_VALID_INCIDENT_SEVERITIES)}"
            },
            ensure_ascii=False,
            indent=2,
        )

    now = datetime.now(timezone.utc)
    date_str = now.strftime("%Y-%m-%d")

    if _count_today_episodic_records(date_str, "incidents") >= MAX_DAILY_EPISODES:
        return json.dumps(
            {"error": f"Limite journalière atteinte ({MAX_DAILY_EPISODES} épisodes/jour)."},
            ensure_ascii=False,
            indent=2,
        )

    incident_doc = {
        "id": None,
        "metadata": {"type": "incident", "title": title},
        "timestamp": now.isoformat(),
        "project": project,
        "severity": severity,
        "description": description,
        "root_cause": root_cause,
        "matched_patterns": matched_patterns or [],
        "resolution": resolution,
        "status": "recorded",
        "consolidation": {
            "consolidated": False,
            "consolidated_at": None,
            "patterns_extracted": [],
            "reinforcements_generated": 0,
        },
        "tags": ["mcp-recorded", project] + (tags or []),
    }

    index_path = mem.get_memory_root() / "_index.yaml"
    output_path = None

    try:
        with file_lock(index_path):
            index = mem.load_index()
            current_count = index.get("episodic", {}).get("incidents", {}).get("count", 0)
            seq = current_count + 1
            inc_id = f"INC-{now.strftime('%Y%m%d')}-{seq:03d}"

            incident_doc["id"] = inc_id
            incident_doc["metadata"]["id"] = inc_id

            filename = f"{date_str}_incident_{inc_id}.yaml"
            output_path = mem.get_memory_root() / "episodic" / "incidents" / filename
            output_path.parent.mkdir(parents=True, exist_ok=True)

            with open(output_path, "w", encoding="utf-8") as fp:
                yaml.dump(
                    incident_doc, fp, allow_unicode=True, default_flow_style=False, sort_keys=False
                )

            _update_index_after_episodic("incident", inc_id, seq)
    except TimeoutError:
        logger.error("record_incident: lock timeout for %s", index_path)
        return json.dumps(
            {"error": "Écriture concurrente détectée. Réessayez dans quelques secondes."},
            ensure_ascii=False,
            indent=2,
        )
    except Exception as exc:
        logger.error("record_incident: write failed: %s", exc)
        if output_path and output_path.exists():
            output_path.unlink()
        return json.dumps(
            {"error": "Erreur lors de l'écriture.", "detail": str(exc)},
            ensure_ascii=False,
            indent=2,
        )

    logger.info("Incident %s recorded: %s (severity: %s)", inc_id, title, severity)
    return json.dumps(
        {
            "status": "success",
            "incident_id": inc_id,
            "file_path": str(output_path),
            "severity": severity,
            "message": f"Incident {inc_id} enregistré avec succès.",
        },
        ensure_ascii=False,
        indent=2,
    )


# ═══════════════════════════════════════════════════════════════════════════════
#  TOOL — record_execution
# ═══════════════════════════════════════════════════════════════════════════════


@mcp.tool()
def record_execution(
    suite: str,
    total: int,
    passed: int,
    failed: int,
    project: str = "external",
    skipped: int = 0,
    duration_seconds: float = 0.0,
    failures: list[dict] | None = None,
    tags: list[str] | None = None,
) -> str:
    """Enregistre une exécution de tests en mémoire épisodique.

    Les exécutions documentent les résultats de campagnes de tests, alimentant
    les associations test-défaut et le cycle de consolidation.

    Args:
        suite: Nom de la suite de tests (ex: "unit-tests", "e2e-checkout").
        total: Nombre total de tests exécutés.
        passed: Nombre de tests réussis.
        failed: Nombre de tests échoués.
        project: Identifiant du projet. Par défaut "external".
        skipped: Nombre de tests ignorés.
        duration_seconds: Durée totale de l'exécution en secondes.
        failures: Détails des échecs, chacun avec :
            - test_name (str): Nom du test
            - error (str): Message d'erreur
            - matched_patterns (list[str], optionnel): IDs de patterns correspondants
        tags: Tags libres pour catégorisation.

    Returns:
        Confirmation avec l'identifiant de l'exécution créée.
    """
    now = datetime.now(timezone.utc)
    date_str = now.strftime("%Y-%m-%d")

    if _count_today_episodic_records(date_str, "executions") >= MAX_DAILY_EPISODES:
        return json.dumps(
            {"error": f"Limite journalière atteinte ({MAX_DAILY_EPISODES} épisodes/jour)."},
            ensure_ascii=False,
            indent=2,
        )

    structured_failures = []
    for f in failures or []:
        structured_failures.append(
            {
                "test_name": f.get("test_name", ""),
                "error": f.get("error", ""),
                "matched_patterns": f.get("matched_patterns", []),
            }
        )

    execution_doc = {
        "id": None,
        "metadata": {"type": "execution", "title": f"Test execution: {suite}"},
        "timestamp": now.isoformat(),
        "project": project,
        "suite": suite,
        "results": {
            "total": total,
            "passed": passed,
            "failed": failed,
            "skipped": skipped,
            "pass_rate": round(passed / total, 4) if total > 0 else 0.0,
        },
        "duration_seconds": duration_seconds,
        "failures": structured_failures,
        "consolidation": {
            "consolidated": False,
            "consolidated_at": None,
            "patterns_extracted": [],
            "reinforcements_generated": 0,
        },
        "tags": ["mcp-recorded", project] + (tags or []),
    }

    index_path = mem.get_memory_root() / "_index.yaml"
    output_path = None

    try:
        with file_lock(index_path):
            index = mem.load_index()
            current_count = index.get("episodic", {}).get("executions", {}).get("count", 0)
            seq = current_count + 1
            exec_id = f"EXC-{now.strftime('%Y%m%d')}-{seq:03d}"

            execution_doc["id"] = exec_id
            execution_doc["metadata"]["id"] = exec_id

            filename = f"{date_str}_execution_{exec_id}.yaml"
            output_path = mem.get_memory_root() / "episodic" / "executions" / filename
            output_path.parent.mkdir(parents=True, exist_ok=True)

            with open(output_path, "w", encoding="utf-8") as fp:
                yaml.dump(
                    execution_doc, fp, allow_unicode=True, default_flow_style=False, sort_keys=False
                )

            _update_index_after_episodic("execution", exec_id, seq)
    except TimeoutError:
        logger.error("record_execution: lock timeout for %s", index_path)
        return json.dumps(
            {"error": "Écriture concurrente détectée. Réessayez dans quelques secondes."},
            ensure_ascii=False,
            indent=2,
        )
    except Exception as exc:
        logger.error("record_execution: write failed: %s", exc)
        if output_path and output_path.exists():
            output_path.unlink()
        return json.dumps(
            {"error": "Erreur lors de l'écriture.", "detail": str(exc)},
            ensure_ascii=False,
            indent=2,
        )

    logger.info("Execution %s recorded: %s (%d/%d passed)", exec_id, suite, passed, total)
    return json.dumps(
        {
            "status": "success",
            "execution_id": exec_id,
            "file_path": str(output_path),
            "pass_rate": execution_doc["results"]["pass_rate"],
            "message": f"Exécution {exec_id} enregistrée avec succès.",
        },
        ensure_ascii=False,
        indent=2,
    )
