#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 ARGUS MCP — Tools: run_cognitive_cycle, get_memory_health
 Cycle cognitif et diagnostic de santé mémoire
═══════════════════════════════════════════════════════════════════════════════
"""

import json
import logging

from ..app import mcp
from .. import data_dir

logger = logging.getLogger("argus.mcp")


# ═══════════════════════════════════════════════════════════════════════════════
#  TOOL — run_cognitive_cycle
# ═══════════════════════════════════════════════════════════════════════════════


@mcp.tool()
def run_cognitive_cycle(
    phase: str = "all",
    apply: bool = False,
) -> str:
    """Exécute le cycle cognitif d'Argus sur la mémoire.

    Le cycle cognitif maintient la qualité de la mémoire à travers 3 phases :
    - consolidation : renforce les patterns observés dans les épisodes récents
    - decay : oubli contrôlé des connaissances non renforcées
    - reflection : auto-diagnostic de la santé mémoire

    L'ordre est critique : consolidation → decay → reflection.

    Args:
        phase: Phase à exécuter. "all" pour le cycle complet, ou une phase
            individuelle parmi "consolidation", "decay", "reflection".
        apply: Si True, applique les modifications (consolidation + decay).
            Si False (défaut), mode scan uniquement (diagnostic sans modification).

    Returns:
        Rapport JSON détaillé du cycle avec les résultats de chaque phase.
    """
    from ..engines.cognitive_cycle import CognitiveCycle, VALID_PHASES

    if phase != "all" and phase not in VALID_PHASES:
        return json.dumps(
            {"error": f"Phase invalide '{phase}'. Valeurs acceptées : 'all', {list(VALID_PHASES)}"},
            ensure_ascii=False,
            indent=2,
        )

    base_dir = str(data_dir.get_project_root())
    phases = None if phase == "all" else [phase]

    cycle = CognitiveCycle(base_dir, verbose=False)

    try:
        report = cycle.run(phases=phases, apply=apply)
    except Exception as exc:
        logger.error("run_cognitive_cycle: %s", exc)
        return json.dumps(
            {"error": "Erreur lors de l'exécution du cycle cognitif.", "detail": str(exc)},
            ensure_ascii=False,
            indent=2,
        )

    logger.info("Cognitive cycle completed: %s (mode=%s)", report.overall_status, report.mode)
    return json.dumps(report.to_dict(), ensure_ascii=False, indent=2)


# ═══════════════════════════════════════════════════════════════════════════════
#  TOOL — get_memory_health
# ═══════════════════════════════════════════════════════════════════════════════


@mcp.tool()
def get_memory_health() -> str:
    """Diagnostique la santé de la mémoire d'Argus.

    Exécute une réflexion complète qui vérifie :
    - Cohérence : compteurs d'index vs fichiers réels, références croisées
    - Complétude : couverture des types d'épisodes, mémoire relationnelle
    - Fraîcheur : consolidation récente, backlog d'épisodes, confiance basse
    - Équilibre : diversité des catégories, ratio connaissance/expérience
    - Connectivité : cycles dans les associations de composants

    Returns:
        Rapport JSON avec statistiques, checks de santé et recommandations.
    """
    from ..engines.reflection import ReflectionEngine

    base_dir = str(data_dir.get_project_root())
    engine = ReflectionEngine(base_dir, verbose=False)

    try:
        report = engine.reflect()
    except Exception as exc:
        logger.error("get_memory_health: %s", exc)
        return json.dumps(
            {"error": "Erreur lors du diagnostic mémoire.", "detail": str(exc)},
            ensure_ascii=False,
            indent=2,
        )

    logger.info(
        "Memory health check: %s (%d checks)",
        "HEALTHY" if not report.has_issues else "ISSUES",
        len(report.checks),
    )
    return json.dumps(report.to_dict(), ensure_ascii=False, indent=2)
