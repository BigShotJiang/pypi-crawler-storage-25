#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 ARGUS MCP — Tool: audit_code_performance
 Audit de performance statique du code source — multi-langage, multi-domaine
═══════════════════════════════════════════════════════════════════════════════
"""

import json
import logging
import re

from ..app import mcp, MAX_CODE_INPUT_SIZE
from .. import memory_reader as mem

logger = logging.getLogger("argus.mcp")


# ═══════════════════════════════════════════════════════════════════════════════
#  Performance rules — universal, not web-specific
# ═══════════════════════════════════════════════════════════════════════════════

# Each rule: id, domain, impact, title, description, patterns, refactoring, why_expensive
# impact = "high" / "medium" / "low" — resource impact level
# why_expensive = explication de POURQUOI c'est coûteux
# refactoring = suggestion de code optimisé

_PERFORMANCE_RULES: list[dict] = [
    # ─── 1. ALGORITHMIC COMPLEXITY ────────────────────────────────────────
    {
        "id": "PERF-ALGO-001",
        "domain": "algorithmic_complexity",
        "impact": "high",
        "title": "Nested loops — potential O(n²) or worse",
        "description": (
            "Boucles imbriquées itérant sur des collections. La complexité peut être "
            "quadratique ou pire, ce qui dégrade rapidement avec la taille des données."
        ),
        "patterns": [
            (r"for\s+\w+\s+in\s+\w+\s*:[^}]{0,300}for\s+\w+\s+in\s+\w+\s*:", re.DOTALL),
            (r"for\s*\([^)]+\)\s*\{[^}]{0,500}for\s*\([^)]+\)\s*\{", re.DOTALL),
            (r"\.forEach\s*\([^)]+\)\s*\{[^}]{0,500}\.forEach\s*\(", re.DOTALL),
            (r"for\s+\w+\s*,\s*\w+\s+in\s+enumerate\([^)]+\)\s*:[^}]{0,300}for\s+", re.DOTALL),
        ],
        "why_expensive": (
            "O(n²) signifie que doubler les données quadruple le temps. "
            "Pour 10 000 éléments ≈ 100M itérations."
        ),
        "refactoring": (
            "Construire un index (dict/set/Map) du inner loop avant la boucle externe. "
            "Remplacer le nested search par un lookup O(1).\n"
            "Avant: for x in a: for y in b: if x == y ...\n"
            "Après: b_set = set(b); for x in a: if x in b_set ..."
        ),
        "resource": "cpu",
        "argus_pattern": None,
    },
    {
        "id": "PERF-ALGO-002",
        "domain": "algorithmic_complexity",
        "impact": "medium",
        "title": "Repeated sorting of the same collection",
        "description": (
            "Collection triée plusieurs fois dans un même scope. Chaque sort est O(n log n)."
        ),
        "patterns": [
            (r"\.sort\s*\([^)]*\)[^}]{0,500}\.sort\s*\(", re.DOTALL),
            (r"sorted\s*\([^)]+\)[^}]{0,500}sorted\s*\(", re.DOTALL),
            (r"Arrays\.sort\s*\([^)]+\)[^}]{0,500}Arrays\.sort\s*\(", re.DOTALL),
        ],
        "why_expensive": "Chaque tri coûte O(n log n). Deux tris = coût doublé inutilement.",
        "refactoring": (
            "Trier une seule fois et réutiliser le résultat. Si deux ordres sont nécessaires, "
            "utiliser un index secondaire (dict par clé de tri)."
        ),
        "resource": "cpu",
        "argus_pattern": None,
    },
    {
        "id": "PERF-ALGO-003",
        "domain": "algorithmic_complexity",
        "impact": "medium",
        "title": "Linear search where hash lookup works",
        "description": (
            "Recherche linéaire (in list, indexOf, find) dans une collection qui pourrait "
            "être un set ou un dict pour un lookup O(1)."
        ),
        "patterns": [
            (r"if\s+\w+\s+in\s+\[", 0),
            (r"\.index(?:of|Of)\s*\([^)]+\)\s*(?:!=|>=|>|==)\s*-?\d", 0),
            (r"\.find\s*\([^)]+\)\s*(?:!=|is not)\s*(?:None|-1)", 0),
            (r"for\s+\w+\s+in\s+\w+\s*:\s*\n\s+if\s+\w+\s*==", 0),
            (r"\.contains\s*\([^)]+\)", 0),
        ],
        "why_expensive": (
            "Recherche dans une list/array = O(n) par appel. "
            "Si appelé dans une boucle, devient O(n×m)."
        ),
        "refactoring": (
            "Convertir la collection en set/frozenset (Python), Set (JS/Java), "
            "ou HashSet pour les recherches fréquentes.\n"
            "Avant: if item in large_list\n"
            "Après: lookup = set(large_list); if item in lookup"
        ),
        "resource": "cpu",
        "argus_pattern": None,
    },
    {
        "id": "PERF-ALGO-004",
        "domain": "algorithmic_complexity",
        "impact": "medium",
        "title": "Redundant computation inside loop",
        "description": (
            "Calcul invariant répété à chaque itération d'une boucle. Le résultat "
            "pourrait être calculé une seule fois avant la boucle."
        ),
        "patterns": [
            (r"for\s+\w+\s+in\s+\w+\s*:[^}]{0,200}len\s*\(\s*\w+\s*\)", re.DOTALL),
            (r"for\s*\([^)]+\)\s*\{[^}]{0,200}\.length\b", re.DOTALL),
            (r"for\s+\w+\s+in\s+\w+\s*:[^}]{0,200}re\.compile\s*\(", re.DOTALL),
            (r"while\b[^:]{0,100}:[^}]{0,200}re\.compile\s*\(", re.DOTALL),
        ],
        "why_expensive": (
            "Recalculer une valeur constante dans chaque itération multiplie inutilement "
            "le temps CPU. re.compile() parsant une regex à chaque tour est particulièrement coûteux."
        ),
        "refactoring": (
            "Extraire le calcul invariant avant la boucle :\n"
            "Avant: for x in data: if len(data) > threshold: ...\n"
            "Après: n = len(data); for x in data: if n > threshold: ...\n"
            "Pour les regex : compiler une seule fois au niveau module."
        ),
        "resource": "cpu",
        "argus_pattern": None,
    },
    # ─── 2. MEMORY EFFICIENCY ─────────────────────────────────────────────
    {
        "id": "PERF-MEM-001",
        "domain": "memory_efficiency",
        "impact": "high",
        "title": "String concatenation in loop",
        "description": (
            "Construction de chaîne par concaténation (+= ou +) dans une boucle. "
            "Chaque concaténation crée un nouvel objet string et copie le contenu."
        ),
        "patterns": [
            (r"for\s+\w+\s+in\s+\w+\s*:[^}]{0,300}\w+\s*\+=\s*(?:str|['\"])", re.DOTALL),
            (r"for\s+\w+\s+in\s+\w+\s*:[^}]{0,300}\w+\s*=\s*\w+\s*\+\s*(?:str|['\"])", re.DOTALL),
            (r"for\s*\([^)]+\)\s*\{[^}]{0,300}\w+\s*\+=\s*['\"]", re.DOTALL),
            (r"while\b[^:]{0,100}:[^}]{0,300}\w+\s*\+=\s*(?:str|['\"])", re.DOTALL),
        ],
        "why_expensive": (
            "En Python/Java/C#, les strings sont immutables. Concaténer n strings = O(n²) "
            "en mémoire car chaque += copie tout le contenu existant."
        ),
        "refactoring": (
            "Utiliser une liste puis join (Python), StringBuilder (Java/C#), "
            "ou template literals (JS).\n"
            "Avant: result = ''; for s in items: result += s\n"
            "Après: parts = []; for s in items: parts.append(s); result = ''.join(parts)\n"
            "Ou mieux: result = ''.join(items)"
        ),
        "resource": "memory",
        "argus_pattern": None,
    },
    {
        "id": "PERF-MEM-002",
        "domain": "memory_efficiency",
        "impact": "high",
        "title": "Loading entire file/dataset into memory",
        "description": (
            "Lecture complète d'un fichier ou dataset en mémoire (readlines, read(), fetchall). "
            "Pour de gros volumes, cela peut provoquer un OOM."
        ),
        "patterns": [
            (r"\.readlines\s*\(\s*\)", 0),
            (r"\.read\s*\(\s*\)\s*$", re.MULTILINE),
            (r"json\.load\s*\(\s*open\s*\(", 0),
            (r"\.fetchall\s*\(\s*\)", 0),
            (r"list\s*\(\s*\w+\.(?:query|execute|find|select)", 0),
            (r"pd\.read_csv\s*\([^)]{0,200}(?!chunksize|nrows|usecols)", 0),
        ],
        "why_expensive": (
            "Un fichier de 1 Go lu avec read() consomme 1 Go+ de RAM d'un coup. "
            "fetchall() sur 1M de lignes crée 1M d'objets Python en mémoire."
        ),
        "refactoring": (
            "Utiliser le streaming/itération :\n"
            "- Fichier : for line in f: au lieu de f.readlines()\n"
            "- DB : cursor itérable ou fetchmany(batch_size)\n"
            "- CSV : pd.read_csv(chunksize=10000)\n"
            "- JSON : ijson pour le streaming JSON"
        ),
        "resource": "memory",
        "argus_pattern": None,
    },
    {
        "id": "PERF-MEM-003",
        "domain": "memory_efficiency",
        "impact": "medium",
        "title": "Unnecessary copy of large data structure",
        "description": (
            "Copie explicite d'une grande structure (deepcopy, list(), dict(), [:]) "
            "alors qu'une référence ou une copie partielle suffirait."
        ),
        "patterns": [
            (r"copy\.deepcopy\s*\(", 0),
            (r"(?:list|dict)\s*\(\s*\w+\s*\)", 0),
            (r"\w+\[:\]\s*$", re.MULTILINE),
            (r"\.copy\s*\(\s*\)", 0),
            (r"json\.loads\s*\(\s*json\.dumps\s*\(", 0),
        ],
        "why_expensive": (
            "deepcopy parcourt récursivement toute la structure. "
            "json.loads(json.dumps(x)) sérialise+désérialise pour un simple clone — très lent."
        ),
        "refactoring": (
            "Évaluer si la copie est vraiment nécessaire :\n"
            "- Si lecture seule : passer une référence ou un frozenset/tuple\n"
            "- Si copie partielle : copy.copy() (shallow) au lieu de deepcopy\n"
            "- Si sérialisation : utiliser copy.deepcopy() plutôt que json round-trip"
        ),
        "resource": "memory",
        "argus_pattern": None,
    },
    {
        "id": "PERF-MEM-004",
        "domain": "memory_efficiency",
        "impact": "medium",
        "title": "List comprehension where generator suffices",
        "description": (
            "List comprehension utilisée comme argument d'une fonction qui accepte "
            "un itérable (sum, any, all, join, max, min). Un generator expression "
            "éviterait de matérialiser la liste en mémoire."
        ),
        "patterns": [
            (r"(?:sum|any|all|min|max|set|tuple|frozenset)\s*\(\s*\[", 0),
            (r"['\"].*['\"]\.join\s*\(\s*\[", 0),
        ],
        "why_expensive": (
            "La list comprehension crée la liste entière en mémoire avant le traitement. "
            "Un generator produit les éléments un par un — O(1) mémoire additionnelle."
        ),
        "refactoring": (
            "Remplacer les crochets par des parenthèses :\n"
            "Avant: sum([x*x for x in range(n)])\n"
            "Après: sum(x*x for x in range(n))\n"
            "Avant: ','.join([str(x) for x in items])\n"
            "Après: ','.join(str(x) for x in items)"
        ),
        "resource": "memory",
        "argus_pattern": None,
    },
    {
        "id": "PERF-MEM-005",
        "domain": "memory_efficiency",
        "impact": "medium",
        "title": "Unbounded cache / memoization without eviction",
        "description": (
            "Cache (dict, @cache, @lru_cache sans maxsize) qui croît indéfiniment. "
            "Peut causer un épuisement mémoire en production longue durée."
        ),
        "patterns": [
            (r"@cache\b(?!\s*\()", 0),
            (r"@lru_cache\s*\(\s*\)", 0),
            (r"@lru_cache\s*\(\s*maxsize\s*=\s*None\s*\)", 0),
            (r"_cache\s*=\s*\{\}", 0),
            (r"memo\s*=\s*\{\}", 0),
            (r"@functools\.cache\b", 0),
        ],
        "why_expensive": (
            "Un cache sans limite de taille croît en O(n) avec le nombre d'entrées uniques. "
            "En production longue durée, cela mène à un OOM progressif."
        ),
        "refactoring": (
            "Ajouter une limite de taille et/ou un TTL :\n"
            "Avant: @lru_cache(maxsize=None)\n"
            "Après: @lru_cache(maxsize=256)\n"
            "Ou utiliser cachetools.TTLCache(maxsize=256, ttl=300)"
        ),
        "resource": "memory",
        "argus_pattern": None,
    },
    # ─── 3. I/O EFFICIENCY ────────────────────────────────────────────────
    {
        "id": "PERF-IO-001",
        "domain": "io_efficiency",
        "impact": "high",
        "title": "N+1 query pattern",
        "description": (
            "Requête DB exécutée dans une boucle — 1 requête pour la liste, puis "
            "N requêtes pour les détails de chaque élément."
        ),
        "patterns": [
            (
                r"for\s+\w+\s+in\s+\w+\s*:[^}]{0,400}(?:\.execute|\.query|\.find|\.get|\.fetch)\s*\(",
                re.DOTALL,
            ),
            (
                r"for\s*\([^)]+\)\s*\{[^}]{0,400}(?:\.execute|\.query|\.findOne|\.findById)\s*\(",
                re.DOTALL,
            ),
            (
                r"\.map\s*\([^)]+\)\s*(?:=>|\{)[^}]{0,300}(?:await|\.then)[^}]{0,200}(?:\.find|\.get|fetch)\s*\(",
                re.DOTALL,
            ),
        ],
        "why_expensive": (
            "Chaque requête a un coût fixe (réseau + parsing). 1 000 éléments = 1 001 requêtes "
            "au lieu d'une seule avec JOIN ou WHERE IN."
        ),
        "refactoring": (
            "Batch les requêtes :\n"
            "- SQL : JOIN ou WHERE id IN (...)\n"
            "- ORM : select_related/prefetch_related (Django), eager loading (SQLAlchemy)\n"
            "- NoSQL : $in operator, populate()\n"
            "Avant: for user in users: orders = db.query(f'SELECT * FROM orders WHERE user_id={user.id}')\n"
            "Après: orders = db.query('SELECT * FROM orders WHERE user_id IN (:ids)', ids=[u.id for u in users])"
        ),
        "resource": "io",
        "argus_pattern": "PAT-PERF-001",
    },
    {
        "id": "PERF-IO-002",
        "domain": "io_efficiency",
        "impact": "high",
        "title": "Synchronous I/O in async context",
        "description": (
            "Opération I/O bloquante (file read, HTTP request, DB query synchrone) "
            "dans un contexte async. Bloque l'event loop et tous les autres handlers."
        ),
        "patterns": [
            (
                r"async\s+def\s+\w+[^}]{0,500}(?:open\s*\(|\.read\s*\(|\.write\s*\((?!.*aio))",
                re.DOTALL,
            ),
            (r"async\s+def\s+\w+[^}]{0,500}requests\.(?:get|post|put|delete)\s*\(", re.DOTALL),
            (r"async\s+def\s+\w+[^}]{0,500}time\.sleep\s*\(", re.DOTALL),
            (r"async\s+def\s+\w+[^}]{0,500}os\.(?:listdir|walk|stat|path)", re.DOTALL),
            (r"async\s+def\s+\w+[^}]{0,500}subprocess\.(?:run|call|check_output)\s*\(", re.DOTALL),
        ],
        "why_expensive": (
            "L'event loop est mono-thread. Une opération bloquante de 100ms gèle "
            "TOUTES les coroutines pendant ce temps. Avec 100 connexions concurrentes, "
            "le débit chute à celui d'un serveur synchrone."
        ),
        "refactoring": (
            "Utiliser les alternatives async :\n"
            "- Fichiers : aiofiles.open()\n"
            "- HTTP : aiohttp / httpx.AsyncClient\n"
            "- Sleep : asyncio.sleep()\n"
            "- Subprocess : asyncio.create_subprocess_exec()\n"
            "- FS ops : asyncio.to_thread(os.listdir, path)\n"
            "- DB : utiliser un driver async (asyncpg, motor, aiosqlite)"
        ),
        "resource": "cpu",
        "argus_pattern": None,
    },
    {
        "id": "PERF-IO-003",
        "domain": "io_efficiency",
        "impact": "medium",
        "title": "Missing pagination on data retrieval",
        "description": (
            "Requête DB ou API sans LIMIT, pagination ou streaming. "
            "Récupère potentiellement des millions de lignes."
        ),
        "patterns": [
            (
                r"select\s+\*\s+from\s+\w+(?!.*(?:limit|top\s+\d|fetch\s+first|rownum|offset))",
                re.IGNORECASE,
            ),
            (r"\.find\s*\(\s*(?:\{\s*\}|\)\s*$)", re.MULTILINE),
            (r"\.all\s*\(\s*\)(?!.*(?:limit|paginate|slice|offset|batch))", 0),
        ],
        "why_expensive": (
            "Sans LIMIT, une table de 10M de lignes renvoie 10M de lignes. "
            "Coût réseau, mémoire côté app, et lock sur la DB pendant le scan."
        ),
        "refactoring": (
            "Ajouter une pagination :\n"
            "- SQL : LIMIT/OFFSET ou keyset pagination\n"
            "- ORM : .limit(100).offset(page*100) ou Paginator\n"
            "- NoSQL : .limit(100).skip(offset) ou cursor-based\n"
            "- API : pagination par curseur ou page/size"
        ),
        "resource": "io",
        "argus_pattern": "PAT-API-001",
    },
    {
        "id": "PERF-IO-004",
        "domain": "io_efficiency",
        "impact": "medium",
        "title": "File opened repeatedly in loop",
        "description": (
            "Fichier ouvert et fermé à chaque itération d'une boucle. "
            "Chaque open() a un coût système (syscall, allocation de file descriptor)."
        ),
        "patterns": [
            (r"for\s+\w+\s+in\s+\w+\s*:[^}]{0,300}(?:open|with\s+open)\s*\(", re.DOTALL),
            (
                r"for\s*\([^)]+\)\s*\{[^}]{0,300}(?:fs\.(?:readFile|writeFile|appendFile))\s*\(",
                re.DOTALL,
            ),
        ],
        "why_expensive": (
            "Chaque open() implique un appel système, allocation de buffer I/O et "
            "file descriptor. Sur 10 000 itérations = 10 000 syscalls au lieu d'un seul."
        ),
        "refactoring": (
            "Ouvrir le fichier une seule fois avant la boucle :\n"
            "Avant: for item in items: with open('log.txt', 'a') as f: f.write(item)\n"
            "Après: with open('log.txt', 'a') as f: for item in items: f.write(item)"
        ),
        "resource": "io",
        "argus_pattern": None,
    },
    {
        "id": "PERF-IO-005",
        "domain": "io_efficiency",
        "impact": "medium",
        "title": "Missing connection pooling",
        "description": (
            "Nouvelle connexion DB/HTTP créée à chaque requête au lieu de réutiliser "
            "un pool de connexions."
        ),
        "patterns": [
            (
                r"def\s+\w+[^}]{0,200}(?:create_connection|connect|create_engine)\s*\((?!.*pool)",
                re.DOTALL,
            ),
            (
                r"for\s+\w+\s+in\s+\w+[^}]{0,300}(?:connect|create_connection|open_connection)\s*\(",
                re.DOTALL,
            ),
            (r"requests\.(?:get|post|put|delete)\s*\((?!.*session)", 0),
            (r"new\s+HttpClient\s*\(", 0),
        ],
        "why_expensive": (
            "Établir une connexion TCP/SSL prend 1-50ms. Pour une DB, comptez "
            "l'authentification en plus. Sans pooling, ce coût est payé à chaque requête."
        ),
        "refactoring": (
            "Utiliser un pool de connexions :\n"
            "- DB : psycopg2.pool / SQLAlchemy pool / HikariCP\n"
            "- HTTP : requests.Session() / httpx.Client() / aiohttp.ClientSession()\n"
            "- Redis : redis.ConnectionPool()"
        ),
        "resource": "io",
        "argus_pattern": None,
    },
    # ─── 4. CPU EFFICIENCY ────────────────────────────────────────────────
    {
        "id": "PERF-CPU-001",
        "domain": "cpu_efficiency",
        "impact": "high",
        "title": "Regex compiled inside loop or hot path",
        "description": (
            "Compilation de regex (re.compile ou regex inline) à chaque appel "
            "dans une boucle ou une fonction fréquemment appelée."
        ),
        "patterns": [
            (
                r"for\s+\w+\s+in\s+\w+\s*:[^}]{0,300}re\.(?:compile|match|search|findall|sub)\s*\(",
                re.DOTALL,
            ),
            (
                r"while\b[^:]{0,100}:[^}]{0,300}re\.(?:compile|match|search|findall|sub)\s*\(",
                re.DOTALL,
            ),
            (r"def\s+\w+[^}]{0,100}:\s*\n(?:\s+[^\n]+\n){0,5}\s+re\.compile\s*\(", re.DOTALL),
        ],
        "why_expensive": (
            "re.compile() parse et optimise la regex à chaque appel. "
            "Même si Python cache les 512 dernières, ce cache est limité et le lookup coûte."
        ),
        "refactoring": (
            "Compiler les regex comme constantes au niveau module :\n"
            "Avant: def process(text): m = re.search(r'pattern', text)\n"
            "Après: _PATTERN = re.compile(r'pattern')\n"
            "       def process(text): m = _PATTERN.search(text)"
        ),
        "resource": "cpu",
        "argus_pattern": None,
    },
    {
        "id": "PERF-CPU-002",
        "domain": "cpu_efficiency",
        "impact": "medium",
        "title": "Missing memoization on pure function",
        "description": (
            "Fonction appelée plusieurs fois avec les mêmes arguments sans cache. "
            "Si le calcul est coûteux et la fonction pure, le résultat devrait être mis en cache."
        ),
        "patterns": [
            (
                r"def\s+(?:compute|calculate|get|parse|convert|transform|generate)\w*\s*\([^)]+\)[^}]{0,200}return\b[^}]{0,500}(?:compute|calculate|get|parse|convert|transform|generate)\w*\s*\(",
                re.DOTALL,
            ),
            (
                r"(?:fibonacci|fib|factorial|fact|combination|permutation)\s*\(\s*\w+\s*(?:-|/|\+)\s*\d+\s*\)",
                0,
            ),
        ],
        "why_expensive": (
            "Les fonctions récursives sans mémoïsation recalculent les mêmes sous-problèmes. "
            "fibonacci(40) sans cache = ~2^40 appels, avec cache = 40 appels."
        ),
        "refactoring": (
            "Ajouter @functools.lru_cache(maxsize=N) pour les fonctions pures :\n"
            "Avant: def fib(n): return fib(n-1) + fib(n-2) if n > 1 else n\n"
            "Après: @lru_cache(maxsize=128)\n"
            "       def fib(n): return fib(n-1) + fib(n-2) if n > 1 else n"
        ),
        "resource": "cpu",
        "argus_pattern": None,
    },
    {
        "id": "PERF-CPU-003",
        "domain": "cpu_efficiency",
        "impact": "medium",
        "title": "Busy-waiting / polling loop",
        "description": (
            "Boucle active qui vérifie continuellement une condition au lieu d'attendre "
            "un signal/événement. Consomme du CPU pour ne rien faire."
        ),
        "patterns": [
            (
                r"while\s+(?:True|true|1)\s*:[^}]{0,200}(?:time\.sleep|sleep)\s*\(\s*(?:0\.0[0-5]|0\.1|0)\s*\)",
                re.DOTALL,
            ),
            (
                r"while\s*\([^)]+\)\s*\{[^}]{0,200}(?:Thread\.sleep|sleep)\s*\(\s*(?:1[0-9]{0,2}|[0-9]{1,2})\s*\)",
                re.DOTALL,
            ),
            (r"while\s+not\s+\w+\s*:[^}]{0,200}(?:pass|continue)\s*$", re.MULTILINE),
            (r"setInterval\s*\([^)]+,\s*(?:[0-9]{1,3})\s*\)", 0),
        ],
        "why_expensive": (
            "Un polling à 100ms utilise ~1% CPU per thread en permanence. "
            "Avec de courts intervalles (<10ms), la consommation explose."
        ),
        "refactoring": (
            "Utiliser des mécanismes événementiels :\n"
            "- threading.Event().wait() ou asyncio.Event()\n"
            "- queue.Queue().get(timeout=N)\n"
            "- select/poll/epoll pour I/O\n"
            "- Observer/callback pattern\n"
            "- Condition variables"
        ),
        "resource": "cpu",
        "argus_pattern": None,
    },
    {
        "id": "PERF-CPU-004",
        "domain": "cpu_efficiency",
        "impact": "low",
        "title": "Inefficient string operations",
        "description": (
            "Opérations string coûteuses : conversion type répétée, format complexe "
            "dans une boucle, ou parsing/encoding redondant."
        ),
        "patterns": [
            (r"for\s+\w+\s+in\s+\w+\s*:[^}]{0,300}str\s*\(\s*\w+\s*\)", re.DOTALL),
            (r"for\s+\w+\s+in\s+\w+\s*:[^}]{0,300}\.encode\s*\([^)]*\)\.decode\s*\(", re.DOTALL),
            (r"for\s+\w+\s+in\s+\w+\s*:[^}]{0,300}json\.dumps\s*\(", re.DOTALL),
        ],
        "why_expensive": (
            "Les conversions de type créent de nouveaux objets. "
            "json.dumps() dans une boucle sérialise/alloue à chaque itération."
        ),
        "refactoring": (
            "Batch les conversions ou utiliser des formats natifs :\n"
            "- Encoder/sérialiser une seule fois après la boucle\n"
            "- Utiliser map(str, items) au lieu de str() dans une boucle\n"
            "- Accumuler dans une structure puis sérialiser en bloc"
        ),
        "resource": "cpu",
        "argus_pattern": None,
    },
    # ─── 5. DATA STRUCTURES ───────────────────────────────────────────────
    {
        "id": "PERF-DS-001",
        "domain": "data_structures",
        "impact": "medium",
        "title": "List used as queue (pop(0) / insert(0, x))",
        "description": (
            "Liste Python utilisée comme file (FIFO) avec pop(0) ou insert(0, x). "
            "Ces opérations sont O(n) car elles décalent tous les éléments."
        ),
        "patterns": [
            (r"\.pop\s*\(\s*0\s*\)", 0),
            (r"\.insert\s*\(\s*0\s*,", 0),
            (r"\w+\s*=\s*\w+\[1:\]", 0),
            (r"del\s+\w+\[0\]", 0),
        ],
        "why_expensive": (
            "list.pop(0) est O(n) car tous les éléments sont décalés en mémoire. "
            "Pour 100 000 éléments, chaque pop(0) copie ~100 000 pointeurs."
        ),
        "refactoring": (
            "Utiliser collections.deque pour les files FIFO :\n"
            "Avant: queue = []; queue.append(x); item = queue.pop(0)\n"
            "Après: from collections import deque; queue = deque(); queue.append(x); item = queue.popleft()\n"
            "deque.popleft() et deque.appendleft() sont O(1)."
        ),
        "resource": "cpu",
        "argus_pattern": None,
    },
    {
        "id": "PERF-DS-002",
        "domain": "data_structures",
        "impact": "medium",
        "title": "Repeated dict/object creation for lookup",
        "description": (
            "Création répétée d'un dict/map à partir des mêmes données pour "
            "effectuer des lookups. Le mapping devrait être construit une seule fois."
        ),
        "patterns": [
            (r"for\s+\w+\s+in\s+\w+\s*:[^}]{0,300}\{[^}]{0,200}for\s+\w+\s+in\s+\w+", re.DOTALL),
            (r"for\s+\w+\s+in\s+\w+\s*:[^}]{0,300}dict\s*\(\s*\w+\s*\)", re.DOTALL),
        ],
        "why_expensive": (
            "Reconstruire un dict de N éléments à chaque itération coûte O(N) par itération, "
            "soit O(M×N) total au lieu de O(N) une seule fois."
        ),
        "refactoring": (
            "Construire le mapping une seule fois avant la boucle :\n"
            "Avant: for x in items: lookup = {y['id']: y for y in others}; result = lookup[x]\n"
            "Après: lookup = {y['id']: y for y in others}; for x in items: result = lookup[x]"
        ),
        "resource": "cpu",
        "argus_pattern": None,
    },
    {
        "id": "PERF-DS-003",
        "domain": "data_structures",
        "impact": "low",
        "title": "Large tuple/namedtuple unpacking waste",
        "description": (
            "Déstructuration d'un large tuple/objet pour n'utiliser qu'un ou deux éléments. "
            "Les éléments inutilisés sont quand même alloués."
        ),
        "patterns": [
            (r"\w+\s*,\s*_\s*,\s*_\s*,\s*_\s*(?:,\s*_\s*)+\s*=", 0),
            (r"\w+\s*,\s*\*_\s*=", 0),
        ],
        "why_expensive": (
            "Mineur, mais l'unpacking force l'évaluation de tous les éléments. "
            "Pour de très gros tuples, accéder directement par index est plus efficace."
        ),
        "refactoring": (
            "Accéder directement par index ou utiliser operator.itemgetter() :\n"
            "Avant: name, _, _, _, _, age = record\n"
            "Après: name, age = record[0], record[5]\n"
            "Ou: from operator import itemgetter; get = itemgetter(0, 5); name, age = get(record)"
        ),
        "resource": "cpu",
        "argus_pattern": None,
    },
    # ─── 6. CONCURRENCY & PARALLELISM ─────────────────────────────────────
    {
        "id": "PERF-CONC-001",
        "domain": "concurrency",
        "impact": "high",
        "title": "GIL-bound CPU work in threads",
        "description": (
            "Travail CPU-intensif (calcul, parsing, transformation) réparti sur "
            "des threads Python. Le GIL empêche le parallélisme réel."
        ),
        "patterns": [
            (
                r"(?:ThreadPoolExecutor|threading\.Thread)\s*\([^)]{0,300}(?:compute|calculate|parse|transform|process|encode|compress|hash|sort)",
                re.DOTALL,
            ),
            (
                r"threading\.Thread\s*\([^)]{0,200}target\s*=\s*(?:compute|calculate|parse|transform|process)",
                0,
            ),
        ],
        "why_expensive": (
            "Le GIL de CPython ne permet qu'un seul thread Python à la fois pour le code CPU. "
            "N threads CPU = aucun gain de vitesse + overhead du context switching."
        ),
        "refactoring": (
            "Utiliser multiprocessing / ProcessPoolExecutor pour le CPU-bound :\n"
            "Avant: with ThreadPoolExecutor() as pool: results = pool.map(compute, data)\n"
            "Après: with ProcessPoolExecutor() as pool: results = pool.map(compute, data)\n"
            "Garder ThreadPoolExecutor pour l'I/O-bound uniquement."
        ),
        "resource": "cpu",
        "argus_pattern": None,
    },
    {
        "id": "PERF-CONC-002",
        "domain": "concurrency",
        "impact": "high",
        "title": "Sequential await in loop (missing gather/batch)",
        "description": (
            "Appels async/await séquentiels dans une boucle alors qu'ils pourraient "
            "être lancés en parallèle avec asyncio.gather ou Promise.all."
        ),
        "patterns": [
            (r"for\s+\w+\s+in\s+\w+\s*:[^}]{0,200}await\s+", re.DOTALL),
            (r"for\s*\([^)]+\)\s*\{[^}]{0,200}await\s+", re.DOTALL),
            (r"for\s+\w+\s+in\s+\w+\s*:\s*\n\s+\w+\s*=\s*await\s+", 0),
        ],
        "why_expensive": (
            "N awaits séquentiels prennent N × latence. Avec 100 appels API de 100ms, "
            "le total est 10 secondes au lieu de ~100ms en parallèle."
        ),
        "refactoring": (
            "Lancer les appels en parallèle :\n"
            "Avant: for url in urls: data = await fetch(url)\n"
            "Après: tasks = [fetch(url) for url in urls]; results = await asyncio.gather(*tasks)\n"
            "JS: const results = await Promise.all(urls.map(url => fetch(url)))\n"
            "Ajouter un semaphore si le nombre de requêtes concurrentes doit être limité."
        ),
        "resource": "io",
        "argus_pattern": None,
    },
    {
        "id": "PERF-CONC-003",
        "domain": "concurrency",
        "impact": "medium",
        "title": "Excessive lock granularity",
        "description": (
            "Lock tenu pendant des opérations longues (I/O, calcul) au lieu d'être "
            "limité à la section critique minimale."
        ),
        "patterns": [
            (
                r"with\s+\w*lock\w*\s*:[^}]{0,500}(?:open|read|write|request|query|sleep|time)",
                re.DOTALL,
            ),
            (
                r"lock\.acquire\s*\(\s*\)[^}]{0,500}(?:open|read|write|request|query|sleep)",
                re.DOTALL,
            ),
            (
                r"synchronized\s*(?:\([^)]*\))?\s*\{[^}]{0,500}(?:read|write|request|query|sleep)",
                re.DOTALL,
            ),
        ],
        "why_expensive": (
            "Un lock maintenu pendant une I/O bloque tous les autres threads en attente. "
            "Le parallélisme effectif tombe à 1 thread pendant le lock."
        ),
        "refactoring": (
            "Réduire la section critique au minimum :\n"
            "Avant: with lock: data = fetch_from_db(); process(data); shared_state.update(data)\n"
            "Après: data = fetch_from_db(); processed = process(data); with lock: shared_state.update(processed)"
        ),
        "resource": "cpu",
        "argus_pattern": "PAT-ASYNC-001",
    },
    # ─── 7. RESOURCE MANAGEMENT ───────────────────────────────────────────
    {
        "id": "PERF-RES-001",
        "domain": "resource_management",
        "impact": "medium",
        "title": "Excessive logging in hot path",
        "description": (
            "Logging avec formatage dans un chemin chaud (boucle, handler fréquent). "
            "Le formatage du message est exécuté même si le niveau de log n'est pas actif."
        ),
        "patterns": [
            (r"for\s+\w+\s+in\s+\w+\s*:[^}]{0,300}(?:logger|logging)\.\w+\s*\(", re.DOTALL),
            (r"for\s+\w+\s+in\s+\w+\s*:[^}]{0,300}print\s*\(", re.DOTALL),
            (r"while\b[^:]{0,100}:[^}]{0,300}(?:logger|logging)\.\w+\s*\(", re.DOTALL),
        ],
        "why_expensive": (
            "Le formatage du message (f-string, .format(), %) est évalué à chaque appel, "
            "même si le log est désactivé. En boucle, cela inclut la sérialisation d'objets."
        ),
        "refactoring": (
            "Utiliser le lazy formatting de logging ou un guard :\n"
            "Avant: for x in items: logger.debug(f'Processing {x.to_dict()}')\n"
            "Après: for x in items: logger.debug('Processing %s', x.id)\n"
            "Ou: if logger.isEnabledFor(logging.DEBUG): logger.debug(...)\n"
            "Supprimer les print() de debug en production."
        ),
        "resource": "cpu",
        "argus_pattern": None,
    },
    {
        "id": "PERF-RES-002",
        "domain": "resource_management",
        "impact": "medium",
        "title": "Missing cleanup / resource leak",
        "description": (
            "Ressource (connexion, fichier, thread pool, cursor) non fermée après usage. "
            "Les fuites accumulées mènent à l'épuisement des descripteurs/connexions."
        ),
        "patterns": [
            (
                r"(?:connect|create_connection|open)\s*\([^)]+\)\s*$(?!\s*\.close|\s*as\b)",
                re.MULTILINE,
            ),
            (
                r"(?:ThreadPoolExecutor|ProcessPoolExecutor)\s*\([^)]*\)\s*$(?!\s*\.shutdown|\s*as\b)",
                re.MULTILINE,
            ),
            (r"cursor\s*\(\s*\)\s*$(?!\s*\.close|\s*as\b)", re.MULTILINE),
        ],
        "why_expensive": (
            "Chaque connexion/fd non fermé consomme de la mémoire et un slot limité. "
            "Avec le temps, le système atteint les limites (ulimit, max_connections) et refuse les nouvelles."
        ),
        "refactoring": (
            "Toujours utiliser un context manager :\n"
            "Avant: conn = db.connect(); cursor = conn.cursor(); ...\n"
            "Après: with db.connect() as conn, conn.cursor() as cursor: ...\n"
            "En Java : try-with-resources. En Go : defer."
        ),
        "resource": "memory",
        "argus_pattern": None,
    },
    {
        "id": "PERF-RES-003",
        "domain": "resource_management",
        "impact": "low",
        "title": "Unnecessary import at function level",
        "description": (
            "Import effectué à chaque appel de fonction au lieu du niveau module. "
            "L'import implique un lookup dans sys.modules + éventuel re-parsing."
        ),
        "patterns": [
            (r"def\s+\w+[^}]{0,100}:\s*\n\s+import\s+\w+", re.DOTALL),
            (r"def\s+\w+[^}]{0,100}:\s*\n\s+from\s+\w+\s+import\s+", re.DOTALL),
        ],
        "why_expensive": (
            "Bien que Python cache les imports dans sys.modules, le mécanisme de résolution "
            "a un coût non nul. En hot path, cela s'accumule."
        ),
        "refactoring": (
            "Déplacer l'import au niveau module sauf si :\n"
            "- L'import est optionnel (dépendance facultative)\n"
            "- L'import crée une dépendance circulaire\n"
            "- L'import est très lourd et rarement utilisé"
        ),
        "resource": "cpu",
        "argus_pattern": None,
    },
    # ─── 8. SERIALIZATION & ENCODING ──────────────────────────────────────
    {
        "id": "PERF-SER-001",
        "domain": "serialization",
        "impact": "medium",
        "title": "Repeated serialization/deserialization",
        "description": (
            "JSON.parse/dumps, pickle load/dump, ou encoding/decoding effectué "
            "plusieurs fois sur les mêmes données dans un même flux."
        ),
        "patterns": [
            (r"json\.dumps\s*\([^)]+\)[^}]{0,500}json\.loads\s*\(", re.DOTALL),
            (r"json\.loads\s*\([^)]+\)[^}]{0,500}json\.dumps\s*\(", re.DOTALL),
            (r"for\s+\w+\s+in\s+\w+\s*:[^}]{0,300}json\.(?:dumps|loads)\s*\(", re.DOTALL),
            (r"JSON\.stringify\s*\([^)]+\)[^}]{0,500}JSON\.parse\s*\(", re.DOTALL),
        ],
        "why_expensive": (
            "Chaque sérialisation parcourt toute la structure. Un round-trip JSON "
            "dumps→loads crée un intermédiaire string inutile et re-parse tout."
        ),
        "refactoring": (
            "Éviter les round-trips inutiles :\n"
            "- Pour cloner : copy.deepcopy() au lieu de json.loads(json.dumps(x))\n"
            "- Sérialiser une seule fois à la sortie du pipeline\n"
            "- Stocker le résultat sérialisé si réutilisé"
        ),
        "resource": "cpu",
        "argus_pattern": None,
    },
    # ─── 9. STARTUP & INITIALIZATION ──────────────────────────────────────
    {
        "id": "PERF-INIT-001",
        "domain": "initialization",
        "impact": "medium",
        "title": "Heavy computation at import time",
        "description": (
            "Calcul lourd, I/O ou requête réseau exécuté au niveau module (hors fonction). "
            "Ralentit l'import et donc le démarrage de l'application."
        ),
        "patterns": [
            (r"^(?:requests|urllib|http)\.\w+\s*\(", re.MULTILINE),
            (r"^(?:pd\.read|open|json\.load|yaml\.safe_load)\s*\(", re.MULTILINE),
            (r"^\w+\s*=\s*\[.{200,}\]$", re.MULTILINE),
            (r"^(?:connect|create_engine)\s*\(", re.MULTILINE),
        ],
        "why_expensive": (
            "Le code au niveau module est exécuté à l'import. Un appel réseau ou une "
            "lecture de fichier peut bloquer le démarrage pendant plusieurs secondes."
        ),
        "refactoring": (
            "Utiliser lazy initialization :\n"
            "Avant: DATA = load_from_file('big.json')  # top level\n"
            "Après: _DATA = None\n"
            "       def get_data():\n"
            "           global _DATA\n"
            "           if _DATA is None: _DATA = load_from_file('big.json')\n"
            "           return _DATA"
        ),
        "resource": "io",
        "argus_pattern": None,
    },
    # ─── 10. EXCEPTION HANDLING OVERHEAD ──────────────────────────────────
    {
        "id": "PERF-EXC-001",
        "domain": "exception_overhead",
        "impact": "medium",
        "title": "Exception used for control flow",
        "description": (
            "Exception levée et attrapée comme mécanisme de contrôle de flux normal "
            "(ex: StopIteration en boucle manuelle, KeyError pour vérifier une clé). "
            "Le mécanisme d'exception a un overhead significatif."
        ),
        "patterns": [
            (r"try\s*:\s*\n\s+\w+\s*=\s*\w+\[\w+\]\s*\n\s*except\s+(?:KeyError|IndexError)", 0),
            (r"for\s+\w+\s+in\s+\w+\s*:[^}]{0,200}try\s*:[^}]{0,100}except\s+", re.DOTALL),
            (r"while\s+True\s*:\s*\n\s+try\s*:[^}]{0,200}except\s+StopIteration", re.DOTALL),
        ],
        "why_expensive": (
            "En Python, lever une exception crée un traceback object et unwind la stack. "
            "C'est ~10× plus lent qu'un test conditionnel (if key in dict)."
        ),
        "refactoring": (
            "Utiliser LBYL (Look Before You Leap) dans les hot paths :\n"
            "Avant: try: v = d[key] except KeyError: v = default\n"
            "Après: v = d.get(key, default)\n"
            "Avant: try: v = lst[i] except IndexError: v = None\n"
            "Après: v = lst[i] if i < len(lst) else None"
        ),
        "resource": "cpu",
        "argus_pattern": None,
    },
]


# ═══════════════════════════════════════════════════════════════════════════════
#  Helpers
# ═══════════════════════════════════════════════════════════════════════════════


def _find_line_number(code: str, match_start: int) -> int:
    """Retourne le numéro de ligne (1-based) d'un match position."""
    return code[:match_start].count("\n") + 1


def _extract_context(code: str, match_start: int, match_end: int, context_lines: int = 2) -> str:
    """Extrait quelques lignes de contexte autour du match."""
    lines = code.split("\n")
    match_line = code[:match_start].count("\n")
    start = max(0, match_line - context_lines)
    end = min(len(lines), match_line + context_lines + 1)
    return "\n".join(lines[start:end])


def _estimate_savings(impact: str, occurrences: int) -> dict:
    """Estime le gain potentiel en ressources."""
    multipliers = {"high": 3, "medium": 2, "low": 1}
    m = multipliers.get(impact, 1)
    return {
        "effort": "low" if occurrences <= 2 else "medium" if occurrences <= 5 else "high",
        "potential_gain": impact,
        "priority_score": m * min(occurrences, 10),
    }


def _scan_code(code: str) -> list[dict]:
    """Exécute toutes les règles de performance sur le code."""
    findings: list[dict] = []
    code_lower = code.lower()

    for rule in _PERFORMANCE_RULES:
        rule_matches = []
        for pattern, flags in rule["patterns"]:
            try:
                for m in re.finditer(pattern, code_lower, flags):
                    line_no = _find_line_number(code, m.start())
                    if line_no not in [rm["line"] for rm in rule_matches]:
                        rule_matches.append(
                            {
                                "line": line_no,
                                "match": code[m.start() : m.end()][:120],
                                "context": _extract_context(code, m.start(), m.end()),
                            }
                        )
            except re.error:
                continue

        if rule_matches:
            savings = _estimate_savings(rule["impact"], len(rule_matches))
            findings.append(
                {
                    "rule_id": rule["id"],
                    "domain": rule["domain"],
                    "impact": rule["impact"],
                    "resource": rule["resource"],
                    "title": rule["title"],
                    "description": rule["description"],
                    "why_expensive": rule["why_expensive"],
                    "refactoring": rule["refactoring"],
                    "argus_pattern": rule.get("argus_pattern"),
                    "occurrences": len(rule_matches),
                    "locations": rule_matches[:10],
                    "estimated_savings": savings,
                }
            )

    return findings


def _enrich_with_argus_patterns(findings: list[dict], patterns: list[dict]) -> list[dict]:
    """Enrichit les findings avec les données des patterns Argus liés."""
    pattern_map = {p.get("id"): p for p in patterns}
    for finding in findings:
        argus_id = finding.get("argus_pattern")
        if argus_id and argus_id in pattern_map:
            p = pattern_map[argus_id]
            finding["argus_detail"] = {
                "pattern_id": argus_id,
                "pattern_name": p.get("name"),
                "confidence": p.get("confidence"),
                "occurrences_in_memory": p.get("occurrences"),
                "prevention_strategy": p.get("prevention_strategy", [])[:3],
            }
    return findings


# ═══════════════════════════════════════════════════════════════════════════════
#  TOOL — audit_code_performance
# ═══════════════════════════════════════════════════════════════════════════════


@mcp.tool()
def audit_code_performance(
    code: str,
    file_path: str | None = None,
    impact_threshold: str = "low",
    domains: list[str] | None = None,
    resources: list[str] | None = None,
) -> str:
    """Audit de performance statique du code source — multi-langage, multi-domaine.

    Analyse le code fourni pour détecter les anti-patterns de performance,
    proposer des refactorisations optimisées et identifier les gaspillages
    de ressources (CPU, mémoire, I/O) sans nuire à l'efficacité fonctionnelle.

    Domaines couverts :
    - algorithmic_complexity : boucles imbriquées O(n²), tris redondants, recherches linéaires
    - memory_efficiency : concaténation en boucle, chargement complet en RAM, copies inutiles, generators
    - io_efficiency : N+1 queries, I/O sync en async, pagination manquante, connection pooling
    - cpu_efficiency : regex en boucle, memoization manquante, busy-waiting, opérations string
    - data_structures : list as queue, lookups répétés, unpacking inutile
    - concurrency : GIL + threads CPU, await séquentiel, locks trop larges
    - resource_management : logging excessif, fuites de ressources, imports dans les fonctions
    - serialization : round-trips JSON/pickle redondants
    - initialization : calculs lourds à l'import
    - exception_overhead : exceptions pour le contrôle de flux

    Chaque finding inclut :
    - POURQUOI c'est coûteux (explication pédagogique)
    - Refactoring concret avec exemples avant/après
    - Ressource impactée (cpu, memory, io)
    - Estimation du gain et de la priorité

    Args:
        code: Code source à auditer.
        file_path: Chemin du fichier analysé (pour contexte). Optionnel.
        impact_threshold: Seuil minimum d'impact à rapporter.
            "high", "medium" ou "low" (défaut).
        domains: Liste des domaines à auditer (ex: ["memory_efficiency", "io_efficiency"]).
            Par défaut tous les domaines.
        resources: Filtrer par type de ressource impactée : "cpu", "memory", "io".
            Par défaut toutes les ressources.

    Returns:
        Rapport d'audit structuré au format JSON avec findings, refactorings et estimations.
    """
    if len(code) > MAX_CODE_INPUT_SIZE:
        return json.dumps(
            {
                "error": f"Code trop volumineux ({len(code)} caractères). Maximum : {MAX_CODE_INPUT_SIZE}."
            },
            ensure_ascii=False,
            indent=2,
        )

    # Valider impact_threshold
    impact_order = {"high": 2, "medium": 1, "low": 0}
    if impact_threshold not in impact_order:
        return json.dumps(
            {
                "error": f"impact_threshold invalide : '{impact_threshold}'. Valeurs acceptées : {list(impact_order.keys())}"
            },
            ensure_ascii=False,
            indent=2,
        )

    # Scanner le code
    findings = _scan_code(code)

    # Filtrer par domaines si spécifié
    if domains:
        domains_lower = [d.lower() for d in domains]
        findings = [f for f in findings if f["domain"] in domains_lower]

    # Filtrer par type de ressource si spécifié
    if resources:
        resources_lower = [r.lower() for r in resources]
        findings = [f for f in findings if f["resource"] in resources_lower]

    # Filtrer par seuil d'impact
    threshold = impact_order[impact_threshold]
    findings = [f for f in findings if impact_order.get(f["impact"], 0) >= threshold]

    # Enrichir avec les patterns Argus
    try:
        argus_patterns = mem.load_patterns()
    except Exception:
        argus_patterns = []

    findings = _enrich_with_argus_patterns(findings, argus_patterns)

    # Trier par priorité décroissante (impact × occurrences)
    findings.sort(
        key=lambda f: f.get("estimated_savings", {}).get("priority_score", 0),
        reverse=True,
    )

    # Statistiques
    stats_by_impact = {}
    stats_by_domain = {}
    stats_by_resource = {}
    for f in findings:
        imp = f["impact"]
        dom = f["domain"]
        res = f["resource"]
        stats_by_impact[imp] = stats_by_impact.get(imp, 0) + 1
        stats_by_domain[dom] = stats_by_domain.get(dom, 0) + 1
        stats_by_resource[res] = stats_by_resource.get(res, 0) + 1

    total_occurrences = sum(f["occurrences"] for f in findings)

    # Déterminer le niveau d'optimisation global
    optimization_level = "optimized"
    if stats_by_impact.get("low", 0) > 0:
        optimization_level = "minor_issues"
    if stats_by_impact.get("medium", 0) > 0:
        optimization_level = "needs_optimization"
    if stats_by_impact.get("high", 0) > 0:
        optimization_level = "critical_bottlenecks"

    # Top 3 recommandations prioritaires
    top_recommendations = []
    for f in findings[:3]:
        top_recommendations.append(
            {
                "rule_id": f["rule_id"],
                "title": f["title"],
                "resource": f["resource"],
                "refactoring": f["refactoring"],
                "estimated_savings": f["estimated_savings"],
            }
        )

    return json.dumps(
        {
            "audit_type": "code_performance",
            "file_path": file_path,
            "optimization_level": optimization_level,
            "summary": {
                "total_rules_checked": len(_PERFORMANCE_RULES),
                "total_findings": len(findings),
                "total_occurrences": total_occurrences,
                "by_impact": stats_by_impact,
                "by_domain": stats_by_domain,
                "by_resource": stats_by_resource,
                "domains_scanned": domains or list({r["domain"] for r in _PERFORMANCE_RULES}),
            },
            "top_recommendations": top_recommendations,
            "findings": findings,
        },
        ensure_ascii=False,
        indent=2,
        default=str,
    )
