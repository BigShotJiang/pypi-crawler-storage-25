#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 ARGUS MCP — Tool: audit_code_security
 Audit de sécurité statique du code source — multi-langage, multi-domaine
═══════════════════════════════════════════════════════════════════════════════
"""

import json
import logging
import re

from ..app import mcp, MAX_CODE_INPUT_SIZE
from .. import memory_reader as mem

logger = logging.getLogger("argus.mcp")


# ═══════════════════════════════════════════════════════════════════════════════
#  Security rules — universal, not web-specific
# ═══════════════════════════════════════════════════════════════════════════════

# Each rule: (id, domain, severity, title, description, patterns, fix_hint, cwe)
# patterns = list of (regex, flags) tuples applied on lowercased code
# CWE = Common Weakness Enumeration ID

_SECURITY_RULES: list[dict] = [
    # ─── 1. INJECTION ─────────────────────────────────────────────────────
    {
        "id": "SEC-INJ-001",
        "domain": "injection",
        "severity": "critical",
        "title": "SQL injection via string formatting",
        "description": (
            "Requête SQL construite par concaténation ou f-string avec des données "
            "potentiellement contrôlées par l'utilisateur. Un attaquant peut injecter "
            "du SQL arbitraire."
        ),
        "patterns": [
            (r'f["\'](?:select|insert|update|delete|drop|alter|create)\b', 0),
            (r"(?:select|insert|update|delete)\b[^;]{0,200}\.format\s*\(", 0),
            (r"(?:select|insert|update|delete)\b[^;]{0,200}%\s*\(", 0),
            (r"execute\s*\(\s*[^)]{0,200}[+%]", 0),
            (r'cursor\.\w+\s*\(\s*f["\']', 0),
            (r'raw\s*\(\s*f["\']', 0),
        ],
        "fix": "Utiliser des requêtes paramétrées (placeholders) ou un ORM.",
        "cwe": "CWE-89",
        "argus_pattern": "PAT-SEC-001",
    },
    {
        "id": "SEC-INJ-002",
        "domain": "injection",
        "severity": "critical",
        "title": "OS command injection",
        "description": (
            "Exécution de commande système avec des données non validées. "
            "Permet l'exécution arbitraire de commandes sur le serveur."
        ),
        "patterns": [
            (r"subprocess\.\w+\s*\([^)]{0,300}shell\s*=\s*true", 0),
            (r"os\.system\s*\(", 0),
            (r"os\.popen\s*\(", 0),
            (r"exec\s*\(\s*[^)]{0,100}(?:input|request|argv|args|param)", 0),
            (r"child_process\.\w+\s*\(", 0),
            (r"runtime\.exec\s*\(", 0),
            (r"processbuilder\s*\(", 0),
        ],
        "fix": "Utiliser des listes d'arguments (pas shell=True), valider les entrées, utiliser shlex.quote().",
        "cwe": "CWE-78",
        "argus_pattern": None,
    },
    {
        "id": "SEC-INJ-003",
        "domain": "injection",
        "severity": "critical",
        "title": "Code injection via eval/exec",
        "description": (
            "Exécution dynamique de code avec eval(), exec() ou Function(). "
            "Si les données proviennent d'une source non fiable, cela permet "
            "l'exécution de code arbitraire."
        ),
        "patterns": [
            (r"\beval\s*\(", 0),
            (r"\bexec\s*\([^)]{0,200}(?!compile)", 0),
            (r"\bFunction\s*\([^)]{0,100}(?:input|request|param|user|data)", 0),
            (r"compile\s*\([^)]{0,200}(?:input|request|param|user)", 0),
        ],
        "fix": "Éviter eval/exec. Utiliser des parsers dédiés (ast.literal_eval, JSON.parse).",
        "cwe": "CWE-94",
        "argus_pattern": None,
    },
    {
        "id": "SEC-INJ-004",
        "domain": "injection",
        "severity": "high",
        "title": "NoSQL injection",
        "description": (
            "Opérateurs MongoDB ($where, $regex, $gt, etc.) combinés avec des "
            "données utilisateur non validées."
        ),
        "patterns": [
            (r"\$where\b", 0),
            (r"\$regex\b[^}]{0,200}(?:req\.|request\.|input|param|body)", 0),
            (r"find\s*\(\s*\{[^}]{0,200}(?:req\.|request\.|input|body)", 0),
        ],
        "fix": "Valider et typer strictement les entrées. Ne jamais passer d'opérateurs MongoDB depuis l'utilisateur.",
        "cwe": "CWE-943",
        "argus_pattern": "PAT-SEC-001",
    },
    {
        "id": "SEC-INJ-005",
        "domain": "injection",
        "severity": "high",
        "title": "LDAP injection",
        "description": "Requête LDAP construite avec des entrées non sanitizées.",
        "patterns": [
            (r"ldap\.\w+\s*\([^)]{0,300}(?:format|%s|\+\s*\w)", 0),
            (r"search_s\s*\([^)]{0,300}(?:format|%s|\+\s*\w)", 0),
        ],
        "fix": "Échapper les caractères spéciaux LDAP ou utiliser des requêtes paramétrées.",
        "cwe": "CWE-90",
        "argus_pattern": None,
    },
    {
        "id": "SEC-INJ-006",
        "domain": "injection",
        "severity": "high",
        "title": "Path traversal",
        "description": (
            "Construction de chemin fichier avec des données utilisateur sans validation. "
            "Un attaquant peut accéder à des fichiers arbitraires via ../ ."
        ),
        "patterns": [
            (r"open\s*\([^)]{0,200}(?:request|input|param|user|argv|args)", 0),
            (r"(?:path\.join|os\.path\.join)\s*\([^)]{0,200}(?:request|input|param|user)", 0),
            (r"readfile\s*\([^)]{0,200}(?:req\.|request\.|input|param)", 0),
            (r"\.\./", 0),
        ],
        "fix": "Valider et normaliser les chemins (Path.resolve()), vérifier qu'ils restent dans le répertoire autorisé.",
        "cwe": "CWE-22",
        "argus_pattern": None,
    },
    {
        "id": "SEC-INJ-007",
        "domain": "injection",
        "severity": "high",
        "title": "Template injection (SSTI)",
        "description": (
            "Moteur de template exécuté avec des données utilisateur non échappées. "
            "Peut mener à l'exécution de code côté serveur."
        ),
        "patterns": [
            (r"render_template_string\s*\([^)]{0,200}(?:request|input|param)", 0),
            (r"jinja2\.Template\s*\([^)]{0,200}(?:request|input|param|user)", 0),
            (r"template\.render\s*\([^)]{0,200}(?:request|input|param)", 0),
            (r"nunjucks\.renderString\s*\(", 0),
        ],
        "fix": "Ne jamais passer de données utilisateur comme template. Utiliser render_template() avec des variables contextuelles.",
        "cwe": "CWE-1336",
        "argus_pattern": None,
    },
    # ─── 2. SECRETS & CREDENTIALS ─────────────────────────────────────────
    {
        "id": "SEC-SEC-001",
        "domain": "secrets",
        "severity": "critical",
        "title": "Hardcoded password or secret",
        "description": (
            "Mot de passe, clé API, token ou secret codé en dur dans le source. "
            "Tout développeur ou attaquant ayant accès au code obtient les credentials."
        ),
        "patterns": [
            (r'(?:password|passwd|pwd)\s*=\s*["\'][^"\']{4,}["\']', 0),
            (r'(?:api[_-]?key|apikey)\s*=\s*["\'][^"\']{8,}["\']', 0),
            (r'(?:secret|secret[_-]?key)\s*=\s*["\'][^"\']{8,}["\']', 0),
            (r'(?:access[_-]?token|auth[_-]?token)\s*=\s*["\'][^"\']{8,}["\']', 0),
            (r'(?:private[_-]?key)\s*=\s*["\'][^"\']{8,}["\']', 0),
            (r'(?:aws[_-]?secret|aws[_-]?key)\s*=\s*["\'][^"\']{8,}["\']', 0),
            (r"-----BEGIN\s+(?:RSA\s+)?PRIVATE\s+KEY", 0),
            (r"(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9_]{20,}", 0),
            (r"sk-[A-Za-z0-9]{20,}", 0),
        ],
        "fix": "Stocker les secrets dans des variables d'environnement ou un gestionnaire de secrets (Vault, AWS SSM, Azure Key Vault).",
        "cwe": "CWE-798",
        "argus_pattern": "PAT-SEC-002",
    },
    {
        "id": "SEC-SEC-002",
        "domain": "secrets",
        "severity": "high",
        "title": "Sensitive data in logs",
        "description": "Données sensibles (passwords, tokens, PII) écrites dans les logs.",
        "patterns": [
            (
                r"(?:print|log(?:ger)?\.(?:info|debug|warn|error)|console\.log)\s*\([^)]{0,300}(?:password|token|secret|credit.?card|ssn|api.?key)",
                0,
            ),
            (
                r"logging\.(?:info|debug|warning|error)\s*\([^)]{0,300}(?:password|token|secret|api.?key)",
                0,
            ),
        ],
        "fix": "Masquer les données sensibles dans les logs. Utiliser un log sanitizer ou redacter les champs sensibles.",
        "cwe": "CWE-532",
        "argus_pattern": "PAT-SEC-002",
    },
    {
        "id": "SEC-SEC-003",
        "domain": "secrets",
        "severity": "medium",
        "title": "Debug/verbose mode in production code",
        "description": (
            "Mode debug activé en dur ou flag verbose non conditionné. "
            "Peut exposer des informations internes (stack traces, config, variables)."
        ),
        "patterns": [
            (r"debug\s*=\s*true", 0),
            (r"app\.run\s*\([^)]{0,200}debug\s*=\s*true", 0),
            (r"flask\.run.*debug.*true", 0),
            (r"verbose\s*=\s*true", 0),
        ],
        "fix": "Conditionner le mode debug sur une variable d'environnement. Toujours désactiver en production.",
        "cwe": "CWE-215",
        "argus_pattern": None,
    },
    # ─── 3. UNSAFE DESERIALIZATION ────────────────────────────────────────
    {
        "id": "SEC-DES-001",
        "domain": "deserialization",
        "severity": "critical",
        "title": "Unsafe deserialization",
        "description": (
            "Désérialisation de données non fiables sans validation. "
            "Permet l'exécution de code arbitraire via des objets malveillants."
        ),
        "patterns": [
            (r"pickle\.loads?\s*\(", 0),
            (r"marshal\.loads?\s*\(", 0),
            (r"shelve\.open\s*\(", 0),
            (r"yaml\.load\s*\([^)]{0,200}(?!.*Loader\s*=\s*(?:Safe|Base))", 0),
            (r"yaml\.unsafe_load\s*\(", 0),
            (r"jsonpickle\.decode\s*\(", 0),
            (r"objectinputstream", 0),
            (r"java\.io\.serializable", 0),
            (r"unserialize\s*\(", 0),
            (r"php://input.*unserialize", 0),
        ],
        "fix": "Utiliser yaml.safe_load(), JSON, ou protobuf. Éviter pickle/marshal avec des données externes.",
        "cwe": "CWE-502",
        "argus_pattern": None,
    },
    # ─── 4. CRYPTOGRAPHY ──────────────────────────────────────────────────
    {
        "id": "SEC-CRY-001",
        "domain": "cryptography",
        "severity": "high",
        "title": "Weak hashing algorithm",
        "description": (
            "Utilisation de MD5 ou SHA1 pour du hashing de mots de passe ou de données "
            "sensibles. Ces algorithmes sont cassés pour cet usage."
        ),
        "patterns": [
            (r"(?:hashlib\.)?md5\s*\(", 0),
            (r"(?:hashlib\.)?sha1\s*\(", 0),
            (r'createhash\s*\(\s*["\'](?:md5|sha1)["\']', 0),
            (r'messagedigest\.getinstance\s*\(\s*["\'](?:md5|sha-?1)["\']', 0),
            (r"digest::(?:md5|sha1)", 0),
        ],
        "fix": "Utiliser bcrypt, argon2 ou scrypt pour les mots de passe. SHA-256+ pour l'intégrité.",
        "cwe": "CWE-328",
        "argus_pattern": None,
    },
    {
        "id": "SEC-CRY-002",
        "domain": "cryptography",
        "severity": "high",
        "title": "Insecure random number generation",
        "description": (
            "Utilisation de générateurs pseudo-aléatoires non cryptographiques "
            "(random, Math.random) pour des usages de sécurité (tokens, IDs, keys)."
        ),
        "patterns": [
            (
                r"random\.(?:random|randint|choice|randrange)\s*\([^)]{0,100}(?:token|secret|key|password|session|nonce|salt|otp|code)",
                0,
            ),
            (r"math\.random\s*\(\s*\)[^;]{0,100}(?:token|secret|key|password|session|nonce)", 0),
            (r"random\.(?:random|randint|choice)\s*\(\s*\)\s*$", re.MULTILINE),
        ],
        "fix": "Utiliser secrets (Python), crypto.randomBytes (Node.js) ou SecureRandom (Java) pour la crypto.",
        "cwe": "CWE-330",
        "argus_pattern": None,
    },
    {
        "id": "SEC-CRY-003",
        "domain": "cryptography",
        "severity": "high",
        "title": "Hardcoded cryptographic key/IV",
        "description": "Clé ou vecteur d'initialisation cryptographique codé en dur dans le source.",
        "patterns": [
            (r'(?:aes|cipher|encrypt)\w*\s*\([^)]{0,200}["\'][0-9a-f]{16,}["\']', 0),
            (r'(?:iv|nonce|salt)\s*=\s*["\'][0-9a-f]{8,}["\']', 0),
            (r'(?:iv|nonce|salt)\s*=\s*b["\'][^"\']{8,}["\']', 0),
            (r'secretkeyspec\s*\([^)]{0,200}["\']', 0),
        ],
        "fix": "Générer les clés/IV dynamiquement. Stocker dans un key management system.",
        "cwe": "CWE-321",
        "argus_pattern": None,
    },
    {
        "id": "SEC-CRY-004",
        "domain": "cryptography",
        "severity": "medium",
        "title": "Disabled TLS certificate verification",
        "description": (
            "Vérification des certificats TLS/SSL désactivée. "
            "Expose les communications à des attaques man-in-the-middle."
        ),
        "patterns": [
            (r"verify\s*=\s*false", 0),
            (r"ssl[_.]verify\s*=\s*false", 0),
            (r"node_tls_reject_unauthorized.*0", 0),
            (r"rejectunauthorized\s*:\s*false", 0),
            (r"insecurerequestwarning", 0),
            (r"ssl\._create_unverified_context", 0),
            (r"sslcontext\s*\([^)]*\)\s*$", re.MULTILINE),
        ],
        "fix": "Toujours vérifier les certificats. Utiliser des CA bundles officiels.",
        "cwe": "CWE-295",
        "argus_pattern": None,
    },
    # ─── 5. ACCESS CONTROL & AUTH ─────────────────────────────────────────
    {
        "id": "SEC-ACL-001",
        "domain": "access_control",
        "severity": "high",
        "title": "Permissive file permissions",
        "description": "Fichiers créés avec des permissions trop larges (777, 666, world-writable).",
        "patterns": [
            (r"chmod\s*\(\s*[^,]{0,100},\s*0?o?777", 0),
            (r"chmod\s*\(\s*[^,]{0,100},\s*0?o?666", 0),
            (r"os\.chmod\s*\([^)]{0,100}0o?777", 0),
            (r"umask\s*\(\s*0+\s*\)", 0),
            (r'mode\s*[=:]\s*["\']?0?o?777', 0),
        ],
        "fix": "Appliquer le principe du moindre privilège. Utiliser 644 (fichiers) ou 755 (exécutables).",
        "cwe": "CWE-732",
        "argus_pattern": None,
    },
    {
        "id": "SEC-ACL-002",
        "domain": "access_control",
        "severity": "high",
        "title": "Missing authentication check",
        "description": "Route, endpoint ou fonction sensible sans vérification d'authentification.",
        "patterns": [
            (
                r"@app\.route\s*\([^)]{0,100}(?:admin|delete|config|upload|export)[^)]*\)\s*\n\s*def\s+\w+\s*\([^)]*\)(?:(?!login_required|auth|permission|jwt|token|protect|guard).){0,300}:",
                re.DOTALL,
            ),
            (
                r"router\.(?:post|put|delete|patch)\s*\([^)]{0,100}(?:admin|config|user)[^)]*,\s*(?!auth|protect|guard|middleware)",
                0,
            ),
        ],
        "fix": "Ajouter un décorateur/middleware d'authentification sur toutes les routes sensibles.",
        "cwe": "CWE-306",
        "argus_pattern": None,
    },
    # ─── 6. ERROR HANDLING & INFO LEAK ────────────────────────────────────
    {
        "id": "SEC-ERR-001",
        "domain": "error_handling",
        "severity": "medium",
        "title": "Broad exception catch hiding errors",
        "description": (
            "Clause except/catch trop large qui avale toutes les exceptions. "
            "Peut masquer des erreurs de sécurité critiques, des corruptions de données, "
            "ou des failles d'authentification."
        ),
        "patterns": [
            (r"except\s*:", 0),
            (r"except\s+exception\s*(?:as\s+\w+)?\s*:\s*\n\s*(?:pass|\.\.\.)", 0),
            (r"catch\s*\(\s*(?:err|e|error|ex)?\s*\)\s*\{[^}]{0,50}\}", 0),
        ],
        "fix": "Attraper des exceptions spécifiques. Logger les exceptions inattendues. Ne jamais les ignorer silencieusement.",
        "cwe": "CWE-396",
        "argus_pattern": None,
    },
    {
        "id": "SEC-ERR-002",
        "domain": "error_handling",
        "severity": "medium",
        "title": "Stack trace / internal details exposed",
        "description": (
            "Stack traces ou détails internes (chemins, versions, config) renvoyés "
            "à l'utilisateur final. Aide un attaquant à cartographier le système."
        ),
        "patterns": [
            (r"traceback\.format_exc\s*\(", 0),
            (r"traceback\.print_exc\s*\(", 0),
            (r"str\s*\(\s*(?:exc|exception|err|error)\s*\)", 0),
            (r"\.stack\b[^;]{0,50}(?:res\.|response\.|send|json)", 0),
            (r"err\.message[^;]{0,50}(?:res\.|response)", 0),
        ],
        "fix": "Renvoyer des messages génériques à l'utilisateur. Logger les détails côté serveur uniquement.",
        "cwe": "CWE-209",
        "argus_pattern": None,
    },
    # ─── 7. DATA VALIDATION ───────────────────────────────────────────────
    {
        "id": "SEC-VAL-001",
        "domain": "data_validation",
        "severity": "high",
        "title": "Missing input validation",
        "description": (
            "Données externes utilisées directement sans validation de type, "
            "de format ou de bornes. S'applique à tout : CLI, API, fichiers, pipes."
        ),
        "patterns": [
            (r"(?:argv|args)\[\d+\][^;]{0,50}(?:open|exec|system|query|execute)", 0),
            (r"(?:stdin|input)\s*\(\s*\)[^;]{0,100}(?:int|float|eval)", 0),
            (r'(?:req\.body|request\.(?:form|json|data)|request\.get_json)\s*\[["\']', 0),
            (r'environ\s*\[["\']', 0),
        ],
        "fix": "Valider, typer et borner toutes les entrées externes avant utilisation.",
        "cwe": "CWE-20",
        "argus_pattern": None,
    },
    {
        "id": "SEC-VAL-002",
        "domain": "data_validation",
        "severity": "high",
        "title": "Regex denial of service (ReDoS)",
        "description": (
            "Expressions régulières avec des quantificateurs imbriqués qui peuvent être "
            "exploitées pour causer un déni de service via des entrées malveillantes."
        ),
        "patterns": [
            (r"re\.(?:match|search|findall|sub)\s*\([^)]{0,200}(?:\([^)]+\)\+){2}", 0),
            (r"re\.(?:match|search|findall|sub)\s*\([^)]{0,200}\.\*.*\.\*", 0),
            (r"new\s+regexp\s*\([^)]{0,200}(?:input|param|user|request)", 0),
            (r"pattern\.compile\s*\([^)]{0,200}(?:input|param|user|request)", 0),
        ],
        "fix": "Utiliser des regex linéaires, un timeout regex, ou valider la longueur de l'entrée avant le match.",
        "cwe": "CWE-1333",
        "argus_pattern": None,
    },
    # ─── 8. MEMORY & RESOURCE SAFETY ──────────────────────────────────────
    {
        "id": "SEC-MEM-001",
        "domain": "resource_safety",
        "severity": "medium",
        "title": "Unclosed resource (file, connection, socket)",
        "description": (
            "Ressource ouverte (fichier, connexion DB, socket) sans fermeture garantie. "
            "Peut causer des fuites de ressources et un déni de service."
        ),
        "patterns": [
            (r"open\s*\([^)]+\)\s*$(?!\s*\.close|\s*as\b)", re.MULTILINE),
            (r"=\s*open\s*\([^)]+\)(?!.*\bwith\b)", 0),
            (r"socket\.socket\s*\([^)]*\)\s*$", re.MULTILINE),
            (r"(?:connect|create_connection)\s*\([^)]+\)\s*$", re.MULTILINE),
        ],
        "fix": "Utiliser with/context manager (Python), try-with-resources (Java), using (C#), ou defer (Go).",
        "cwe": "CWE-404",
        "argus_pattern": None,
    },
    {
        "id": "SEC-MEM-002",
        "domain": "resource_safety",
        "severity": "medium",
        "title": "Unbounded data structure (potential DoS)",
        "description": (
            "Cache, queue ou liste sans limite de taille. Un attaquant peut provoquer "
            "un épuisement mémoire (OOM) en alimentant massivement la structure."
        ),
        "patterns": [
            (r"cache\s*=\s*\{\}", 0),
            (r"cache\s*=\s*dict\s*\(\s*\)", 0),
            (r"(?:queue|buffer|pool)\s*=\s*\[\s*\]", 0),
            (r"\.append\s*\([^)]+\)(?!.*\bmax|limit|size|bound)", 0),
            (r"new\s+map\s*\(\s*\)(?!.*\bmax|limit|size)", 0),
        ],
        "fix": "Utiliser functools.lru_cache / cachetools.TTLCache / collections.deque(maxlen=N) avec une limite.",
        "cwe": "CWE-400",
        "argus_pattern": None,
    },
    # ─── 9. CONCURRENCY ───────────────────────────────────────────────────
    {
        "id": "SEC-CONC-001",
        "domain": "concurrency",
        "severity": "high",
        "title": "Race condition / TOCTOU",
        "description": (
            "Vérification (ex: if file exists) suivie d'une action (ex: open) sans "
            "atomicité. L'état peut changer entre la vérification et l'action."
        ),
        "patterns": [
            (
                r"(?:os\.path\.exists|path\.exists|isfile|isdir)\s*\([^)]+\)[^{;]{0,100}(?:open|remove|unlink|rename|mkdir)",
                0,
            ),
            (r"if\s+.*exists\s*\([^)]+\)[^}]{0,200}(?:open|write|delete|remove)", re.DOTALL),
        ],
        "fix": "Utiliser des opérations atomiques (O_CREAT|O_EXCL, renameat2) ou des verrous fichier.",
        "cwe": "CWE-367",
        "argus_pattern": "PAT-ASYNC-001",
    },
    {
        "id": "SEC-CONC-002",
        "domain": "concurrency",
        "severity": "medium",
        "title": "Shared mutable state without synchronization",
        "description": (
            "Variable globale mutable accédée depuis plusieurs threads/tasks "
            "sans mécanisme de synchronisation."
        ),
        "patterns": [
            (
                r"(?:global\s+\w+|threading\.Thread)\b[^}]{0,500}(?:\.append|\.update|\[.+\]\s*=)",
                re.DOTALL,
            ),
            (r"(?:shared|global)\s*(?:dict|list|set|counter|state)", 0),
        ],
        "fix": "Utiliser threading.Lock, asyncio.Lock, ou des structures thread-safe (queue.Queue, concurrent collections).",
        "cwe": "CWE-362",
        "argus_pattern": "PAT-ASYNC-001",
    },
    # ─── 10. DEPENDENCY & SUPPLY CHAIN ────────────────────────────────────
    {
        "id": "SEC-DEP-001",
        "domain": "supply_chain",
        "severity": "medium",
        "title": "Dependency with known insecure import pattern",
        "description": (
            "Import de module avec des usages connus comme dangereux "
            "(pickle, telnetlib, ftplib sans TLS, xml.etree avec external entities)."
        ),
        "patterns": [
            (r"import\s+(?:telnetlib|ftplib)\b", 0),
            (r"import\s+(?:cgi)\b", 0),
            (r"from\s+xml\.etree.*import.*parse(?!.*defused)", 0),
            (r"(?:xml\.sax|xml\.dom)\.(?:parse|parseString)", 0),
            (r"import\s+(?:cPickle|shelve)\b", 0),
        ],
        "fix": "Utiliser defusedxml au lieu de xml.etree, paramiko/sftp au lieu de ftplib/telnetlib.",
        "cwe": "CWE-1104",
        "argus_pattern": None,
    },
    {
        "id": "SEC-DEP-002",
        "domain": "supply_chain",
        "severity": "medium",
        "title": "Pinned dependency with no integrity check",
        "description": "Installation de packages via pip/npm avec des URLs non vérifiées ou des --trusted-host.",
        "patterns": [
            (r"pip\s+install\s+[^-]{0,200}--trusted-host", 0),
            (r"--index-url\s+http://", 0),
            (r"npm\s+install\s+(?:--force|--legacy-peer-deps)", 0),
            (r"pip\s+install\s+--no-verify", 0),
        ],
        "fix": "Utiliser uniquement des sources HTTPS. Vérifier les hashes (pip --require-hashes, npm integrity).",
        "cwe": "CWE-494",
        "argus_pattern": None,
    },
    # ─── 11. TEMPORARY FILES & CLEANUP ────────────────────────────────────
    {
        "id": "SEC-TMP-001",
        "domain": "resource_safety",
        "severity": "medium",
        "title": "Insecure temporary file creation",
        "description": (
            "Fichier temporaire créé avec un nom prédictible ou dans un répertoire "
            "partagé sans permissions restrictives."
        ),
        "patterns": [
            (r"(?:tempfile\.)?mktemp\s*\(", 0),
            (r'open\s*\(\s*["\'](?:/tmp|/var/tmp|C:\\\\temp|%TEMP%)', 0),
            (r"tmpnam\s*\(", 0),
        ],
        "fix": "Utiliser tempfile.mkstemp() ou tempfile.NamedTemporaryFile() qui créent des fichiers avec des permissions sûres.",
        "cwe": "CWE-377",
        "argus_pattern": None,
    },
]


# ═══════════════════════════════════════════════════════════════════════════════
#  Helpers
# ═══════════════════════════════════════════════════════════════════════════════


def _find_line_number(code: str, match_start: int) -> int:
    """Retourne le numéro de ligne (1-based) d'un match position."""
    return code[:match_start].count("\n") + 1


def _extract_context(code: str, match_start: int, match_end: int, context_lines: int = 1) -> str:
    """Extrait quelques lignes de contexte autour du match."""
    lines = code.split("\n")
    match_line = code[:match_start].count("\n")
    start = max(0, match_line - context_lines)
    end = min(len(lines), match_line + context_lines + 1)
    return "\n".join(lines[start:end])


def _scan_code(code: str) -> list[dict]:
    """Exécute toutes les règles de sécurité sur le code."""
    findings: list[dict] = []
    code_lower = code.lower()

    for rule in _SECURITY_RULES:
        rule_matches = []
        for pattern, flags in rule["patterns"]:
            try:
                for m in re.finditer(pattern, code_lower, flags):
                    line_no = _find_line_number(code, m.start())
                    # Éviter les doublons sur la même ligne pour la même règle
                    if line_no not in [rm["line"] for rm in rule_matches]:
                        rule_matches.append(
                            {
                                "line": line_no,
                                "match": code[m.start() : m.end()][:120],
                                "context": _extract_context(code, m.start(), m.end()),
                            }
                        )
            except re.error:
                continue

        if rule_matches:
            findings.append(
                {
                    "rule_id": rule["id"],
                    "domain": rule["domain"],
                    "severity": rule["severity"],
                    "title": rule["title"],
                    "description": rule["description"],
                    "cwe": rule["cwe"],
                    "fix": rule["fix"],
                    "argus_pattern": rule.get("argus_pattern"),
                    "occurrences": len(rule_matches),
                    "locations": rule_matches[:10],  # Cap à 10 occurrences par règle
                }
            )

    return findings


def _enrich_with_argus_patterns(findings: list[dict], patterns: list[dict]) -> list[dict]:
    """Enrichit les findings avec les données des patterns Argus liés."""
    pattern_map = {p.get("id"): p for p in patterns}
    for finding in findings:
        argus_id = finding.get("argus_pattern")
        if argus_id and argus_id in pattern_map:
            p = pattern_map[argus_id]
            finding["argus_detail"] = {
                "pattern_id": argus_id,
                "pattern_name": p.get("name"),
                "confidence": p.get("confidence"),
                "occurrences_in_memory": p.get("occurrences"),
                "prevention_strategy": p.get("prevention_strategy", [])[:3],
                "detection_strategy": p.get("detection_strategy", {}),
            }
    return findings


# ═══════════════════════════════════════════════════════════════════════════════
#  TOOL — audit_code_security
# ═══════════════════════════════════════════════════════════════════════════════


@mcp.tool()
def audit_code_security(
    code: str,
    file_path: str | None = None,
    severity_threshold: str = "low",
    domains: list[str] | None = None,
) -> str:
    """Audit de sécurité statique du code source — multi-langage, multi-domaine.

    Analyse le code fourni avec 25+ règles couvrant 11 domaines de sécurité
    applicables à tout type de projet (backend, CLI, bibliothèque, API, desktop,
    mobile, IoT, scripts), pas uniquement le web.

    Domaines couverts :
    - injection : SQL, OS command, code eval, NoSQL, LDAP, path traversal, SSTI
    - secrets : credentials hardcodés, données sensibles dans les logs, mode debug
    - deserialization : pickle, yaml.load, marshal, unserialize
    - cryptography : hashing faible, random non-crypto, clés/IV hardcodés, TLS
    - access_control : permissions fichiers, authentification manquante
    - error_handling : exceptions larges, stack traces exposées
    - data_validation : entrées non validées, ReDoS
    - resource_safety : ressources non fermées, structures non bornées, tmp files
    - concurrency : race conditions, TOCTOU, état mutable partagé
    - supply_chain : imports dangereux, dépendances non vérifiées

    Chaque finding est lié à un CWE et, quand applicable, au defect pattern Argus
    correspondant avec sa stratégie de prévention.

    Args:
        code: Code source à auditer.
        file_path: Chemin du fichier analysé (pour contexte). Optionnel.
        severity_threshold: Seuil minimum de sévérité à rapporter.
            "critical", "high", "medium" ou "low" (défaut).
        domains: Liste des domaines à auditer (ex: ["injection", "secrets"]).
            Par défaut tous les domaines.

    Returns:
        Rapport d'audit structuré au format JSON avec findings, stats et remediations.
    """
    if len(code) > MAX_CODE_INPUT_SIZE:
        return json.dumps(
            {
                "error": f"Code trop volumineux ({len(code)} caractères). Maximum : {MAX_CODE_INPUT_SIZE}."
            },
            ensure_ascii=False,
            indent=2,
        )

    # Valider severity_threshold
    severity_order = {"critical": 3, "high": 2, "medium": 1, "low": 0}
    if severity_threshold not in severity_order:
        return json.dumps(
            {
                "error": f"severity_threshold invalide : '{severity_threshold}'. Valeurs acceptées : {list(severity_order.keys())}"
            },
            ensure_ascii=False,
            indent=2,
        )

    # Scanner le code
    findings = _scan_code(code)

    # Filtrer par domaines si spécifié
    if domains:
        domains_lower = [d.lower() for d in domains]
        findings = [f for f in findings if f["domain"] in domains_lower]

    # Filtrer par seuil de sévérité
    threshold = severity_order[severity_threshold]
    findings = [f for f in findings if severity_order.get(f["severity"], 0) >= threshold]

    # Enrichir avec les patterns Argus
    try:
        argus_patterns = mem.load_patterns()
    except Exception:
        argus_patterns = []

    findings = _enrich_with_argus_patterns(findings, argus_patterns)

    # Trier par sévérité décroissante
    findings.sort(key=lambda f: severity_order.get(f["severity"], 0), reverse=True)

    # Statistiques
    stats_by_severity = {}
    stats_by_domain = {}
    for f in findings:
        sev = f["severity"]
        dom = f["domain"]
        stats_by_severity[sev] = stats_by_severity.get(sev, 0) + 1
        stats_by_domain[dom] = stats_by_domain.get(dom, 0) + 1

    total_occurrences = sum(f["occurrences"] for f in findings)

    # Déterminer le niveau de risque global
    risk_level = "clean"
    if stats_by_severity.get("medium", 0) > 0:
        risk_level = "medium"
    if stats_by_severity.get("high", 0) > 0:
        risk_level = "high"
    if stats_by_severity.get("critical", 0) > 0:
        risk_level = "critical"

    return json.dumps(
        {
            "audit_type": "code_security",
            "file_path": file_path,
            "risk_level": risk_level,
            "summary": {
                "total_rules_checked": len(_SECURITY_RULES),
                "total_findings": len(findings),
                "total_occurrences": total_occurrences,
                "by_severity": stats_by_severity,
                "by_domain": stats_by_domain,
                "domains_scanned": domains or [r["domain"] for r in _SECURITY_RULES],
            },
            "findings": findings,
        },
        ensure_ascii=False,
        indent=2,
        default=str,
    )
