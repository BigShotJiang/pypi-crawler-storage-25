#!/usr/bin/env python3
"""
依赖管理模块
用于自动检测和安装缺失的依赖库
"""

import subprocess
import sys
from github_shell.utils.language import _

def get_system_type():
    """获取当前系统类型
    
    Returns:
        str: 系统类型 (windows, macos, linux)
    """
    import platform
    system = platform.system().lower()
    if system == "windows":
        return "windows"
    elif system == "darwin":
        return "macos"
    elif system == "linux":
        return "linux"
    else:
        return "unknown"

def download_git():
    """根据系统类型下载Git
    
    Returns:
        bool: 是否下载成功
    """
    import os
    import urllib.request
    import tempfile
    import shutil
    
    system = get_system_type()
    
    # 根据系统类型确定下载URL
    if system == "windows":
        # Windows 64位版本
        url = "https://github.com/git-for-windows/git/releases/download/v2.43.0.windows.1/Git-2.43.0-64-bit.exe"
        installer_name = "Git-installer.exe"
    elif system == "macos":
        # macOS版本
        url = "https://sourceforge.net/projects/git-osx-installer/files/git-2.43.0-intel-universal-mavericks.dmg/download"
        installer_name = "Git-installer.dmg"
    elif system == "linux":
        # Linux系统使用包管理器安装
        print("For Linux systems, please install Git using your package manager:")
        print("  Ubuntu/Debian: sudo apt install git")
        print("  Fedora/CentOS: sudo dnf install git")
        print("  Arch Linux: sudo pacman -S git")
        return False
    else:
        print(f"Unknown system type: {system}")
        return False
    
    print(f"Downloading Git for {system}...")
    
    try:
        # 创建临时目录
        with tempfile.TemporaryDirectory() as temp_dir:
            installer_path = os.path.join(temp_dir, installer_name)
            
            # 下载安装程序
            print(f"Downloading from: {url}")
            urllib.request.urlretrieve(url, installer_path)
            print(f"Download completed: {installer_path}")
            
            # 执行安装程序
            print("Starting Git installation...")
            if system == "windows":
                # Windows系统执行安装程序
                subprocess.run([installer_path, "/SILENT", "/NORESTART"], check=True)
            elif system == "macos":
                # macOS系统挂载DMG并安装
                print("Please manually install Git from the downloaded DMG file.")
                # 打开DMG文件
                subprocess.run(["open", installer_path], check=True)
            
            print("Git installation completed successfully!")
            return True
    except Exception as e:
        print(f"Failed to download or install Git: {e}")
        return False

def check_wsl():
    """检查WSL是否安装（仅Windows）
    
    Returns:
        bool: WSL是否安装
    """
    import platform
    if platform.system() != "Windows":
        print("SKIP: WSL is only available on Windows")
        return False
    
    try:
        # 尝试执行wsl --version命令
        subprocess.check_output(["wsl", "--version"], stderr=subprocess.DEVNULL)
        print("OK: wsl is installed")
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        print("ERR: wsl is not installed")
        return False

def check_git():
    """检查Git是否安装
    
    Returns:
        bool: Git是否安装
    """
    try:
        # 尝试执行git --version命令
        subprocess.check_output(["git", "--version"], stderr=subprocess.DEVNULL)
        print("OK: git is installed")
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        print("ERR: git is not installed")
        return False

def check_and_install_dependencies():
    """检查并安装缺失的依赖库
    
    Returns:
        bool: 是否成功安装所有依赖
    """
    # 使用ASCII字符避免Windows编码问题
    print("Checking dependencies...")
    
    # 定义所需的依赖库
    required_dependencies = [
        "requests>=2.25.0",
        "cryptography>=38.0.0"
    ]
    
    missing_dependencies = []
    
    # 检查每个依赖库
    for dep in required_dependencies:
        # 提取库名（忽略版本要求）
        lib_name = dep.split('>=')[0].split('<=')[0].split('==')[0].strip()
        
        try:
            # 尝试导入库
            __import__(lib_name)
            print(f"OK: {lib_name} is installed")
        except ImportError:
            # 库未安装，添加到缺失列表
            missing_dependencies.append(dep)
            print(f"ERR: {lib_name} is not installed")
    
    # 检查Git是否安装
    git_installed = check_git()
    
    # 如果Git未安装，尝试自动下载和安装
    if not git_installed:
        print("\nGit is not installed. Trying to download and install Git automatically...")
        git_installed = download_git()
        
        # 安装完成后重新检查
        if git_installed:
            print("\nRechecking Git installation...")
            git_installed = check_git()
    
    # 检查Linux命令执行环境
    import platform
    system = platform.system()
    
    if system == "Windows":
        # Windows系统检查WSL
        wsl_installed = check_wsl()
        
        # 如果WSL未安装，提示用户
        if not wsl_installed:
            print("\nWARNING: WSL (Windows Subsystem for Linux) is not installed.")
            print("You can install WSL using: wsl --install")
            print("For more information, visit: https://learn.microsoft.com/en-us/windows/wsl/install")
            print("'linux' command will not work without WSL on Windows.")
    elif system == "Darwin":
        # Mac系统提示
        print("\nINFO: 'linux' command is available on Mac. It will execute Unix commands directly.")
    elif system == "Linux":
        # Linux系统提示
        print("\nINFO: 'linux' command is available on Linux. It will execute commands directly.")
    else:
        # 其他系统提示
        print("\nINFO: 'linux' command may not be available on this system.")
    
    # 如果有缺失的依赖，尝试安装
    if missing_dependencies:
        print(f"Found {len(missing_dependencies)} missing dependencies, trying to install...")
        
        try:
            # 使用pip安装所有缺失的依赖
            subprocess.check_call([
                sys.executable, "-m", "pip", "install"
            ] + missing_dependencies, 
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL)
            print("All dependencies installed successfully!")
        except subprocess.CalledProcessError:
            print("Failed to install dependencies, please install manually:")
            for dep in missing_dependencies:
                print(f"  pip install {dep}")
            return False
    
    # 如果Git仍然未安装，提示用户
    if not git_installed:
        print("\nWARNING: Git installation failed. Please install Git manually to use git commands in GitHub Shell.")
        print("You can download Git from: https://git-scm.com/downloads")
    
    print("All dependencies are already installed")
    return True

def check_module(module_name):
    """检查单个模块是否存在
    
    Args:
        module_name: 模块名称
        
    Returns:
        bool: 模块是否存在
    """
    try:
        __import__(module_name)
        return True
    except ImportError:
        return False

def install_module(module_name):
    """安装单个模块
    
    Args:
        module_name: 模块名称
        
    Returns:
        bool: 是否安装成功
    """
    try:
        subprocess.check_call([
            sys.executable, "-m", "pip", "install", module_name
        ], 
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL)
        return True
    except subprocess.CalledProcessError:
        return False
