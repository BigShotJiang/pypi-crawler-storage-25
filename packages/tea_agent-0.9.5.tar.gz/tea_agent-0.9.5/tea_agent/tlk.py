import ast
from typing import Dict, cast, Callable, Tuple, List, Optional
import json
import os
import os.path as osp
import time
import logging

from tea_agent.toolkit.toolkit_set_topic_title import (
    toolkit_set_topic_title,
    meta_toolkit_set_topic_title,
)

logger = logging.getLogger("tookit")


def meta_toolkit_save() -> dict:
    """
    Meta toolkit save — 统一版本管理

    Returns:
        dict: Description.
    """
    return {
        "type": "function",
        "function": {
            "name": "toolkit_save",
            "description": (
                "统一工具版本管理。action=save 保存新工具, reload 重载所有工具, "
                "rollback 回滚到指定版本, versions 列出历史版本。"
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "action": {
                        "type": "string",
                        "enum": ["save", "reload", "rollback", "versions"],
                        "description": "save=保存工具, reload=重载, rollback=回滚, versions=列出版本"
                    },
                    "name": {"type": "string", "description": "[save/rollback/versions] 工具函数名"},
                    "meta": {"type": "object", "description": "[save] 工具元描述，符合 OpenAI tool func schema"},
                    "pycode": {"type": "string", "description": "[save] 工具函数的 Python 实现代码"},
                    "version": {"type": "string", "description": "[save/rollback] 版本号，save时可选自动递增"},
                },
                "required": ["action"],
            },
        },
    }

def toolkit_save_impl(action: str, name: str = "", meta: dict = None, pycode: str = "", version: str = "") -> str:
    """
    统一工具版本管理入口。

    Args:
        action (str): Description.
        name (str): Description.
        meta (dict): Description.
        pycode (str): Description.
        version (str): Description.

    Returns:
        str: Description.
    """
    tlk = cast(Toolkit, globals().get("_toolkit_", None))
    try:
        if action == "save":
            status, msg = tlk.save(name, meta, pycode, version)
            return f"✅ {msg}" if status == 0 else f"❌ {msg}"
        elif action == "reload":
            result = tlk.reload()
            return f"✅ 已重载 {len(result)} 个工具" if isinstance(result, dict) else str(result)
        elif action == "rollback":
            status, msg = tlk.rollback(name, version)
            return f"✅ {msg}" if status == 0 else f"❌ {msg}"
        elif action == "versions":
            status, versions = tlk.list_versions(name)
            if status == 0:
                if not versions:
                    return f"工具 {name} 没有历史版本。"
                return f"工具 {name} 的版本：\n" + "\n".join(f"  - v{v}" for v in versions)
            return f"❌ {versions}"
        else:
            return f"❌ 未知 action: {action}，可选: save/reload/rollback/versions"
    except Exception as e:
        return f"❌ {e}"



class Toolkit:
    """Toolkit class."""
    _CACHE_TTL = 30
    _CACHE_BLACKLIST = {
        'toolkit_exec', 'toolkit_self_evolve', 'toolkit_save',
        'toolkit_release_version',
        'toolkit_pkg', 'toolkit_memory', 'toolkit_kb', 'toolkit_reflection',
        'toolkit_proactive', 'toolkit_subconscious', 'toolkit_dump_topic',
        'toolkit_mode', 'toolkit_prompt_evolve',
        'toolkit_notify',        'toolkit_run_tests', 'toolkit_toggle_reasoning', 'toolkit_skill',
        'toolkit_set_topic_title',
        'toolkit_plan',
        'toolkit_git_push_all_remotes',
    }

    def __init__(self, tool_dir=None):
        
        """Initialize  .
        
        Args:
            tool_dir: Description.
        """
        self.func_map: Dict[str, Callable] = {}
        self.meta_map: Dict[str, dict] = {}
        self._cache: Dict[tuple, tuple] = {}

        self.user_dir = osp.join(
            os.path.expanduser("~"), ".tea_agent", "toolkit")
        os.makedirs(self.user_dir, exist_ok=True)

        self.builtin_dir = osp.join(osp.dirname(__file__), "toolkit")

        self.tool_dir = tool_dir if tool_dir else self.user_dir
        os.makedirs(self.tool_dir, exist_ok=True)

        self.reload()
        logger.info(f"Loaded {len(self.func_map)} toolkit functions from {self.tool_dir}")

    def call_tool(self, func_name: str, **kwargs):
        """带缓存的工具调用代理。
        
        对非黑名单工具缓存结果，TTL 默认 30 秒。
        相同工具+相同参数在 TTL 内重复调用直接返回缓存结果。

        Args:
            func_name: 工具函数名
            **kwargs: 工具参数

        Returns:
            工具函数返回值
        """
        import json as _json

        if func_name in self._CACHE_BLACKLIST:
            if func_name not in self.func_map:
                raise KeyError(f"Unknown tool: {func_name}")
            return self.func_map[func_name](**kwargs)

        if func_name == 'toolkit_file' and kwargs.get('action') == 'write':
            return self.func_map[func_name](**kwargs)

        now = time.time()
        cache_key = (func_name, _json.dumps(kwargs, sort_keys=True, default=str))

        if cache_key in self._cache:
            result, expire_at = self._cache[cache_key]
            if now < expire_at:
                logger.debug(f"Cache HIT: {func_name} (TTL {expire_at - now:.0f}s)")
                return result
            else:
                del self._cache[cache_key]

        if func_name not in self.func_map:
            raise KeyError(f"Unknown tool: {func_name}")
        result = self.func_map[func_name](**kwargs)

        expire_at = now + self._CACHE_TTL
        self._cache[cache_key] = (result, expire_at)

        if len(self._cache) > 500 or (self._cache and hash(cache_key) % 20 == 0):
            self._purge_cache()

        return result

    def _purge_cache(self):
        """清理过期缓存条目"""
        now = time.time()
        expired = [k for k, (_, exp) in self._cache.items() if now >= exp]
        for k in expired:
            del self._cache[k]
        if expired:
            logger.debug(f"Cache purge: removed {len(expired)} expired entries, {len(self._cache)} remaining")

    def _check_dependencies(self, pycode: str) -> str:
        """
        自动检测 pycode 中的 import 并安装缺失依赖

        Args:
            pycode (str): Description.

        Returns:
            str: Description.
        """
        import ast as _ast
        import importlib.util as _importlib
        import subprocess
        import sys
        
        MODULE_MAP = {
            'PIL': 'Pillow', 'cv2': 'opencv-python', 'sklearn': 'scikit-learn',
            'yaml': 'PyYAML', 'bs4': 'beautifulsoup4', 'dateutil': 'python-dateutil',
            'jwt': 'PyJWT', 'Crypto': 'pycryptodome', 'Image': 'Pillow'
        }
        
        try:
            tree = _ast.parse(pycode)
        except SyntaxError:
            return ""

        imports = set()
        for node in _ast.walk(tree):
            if isinstance(node, _ast.Import):
                for alias in node.names:
                    imports.add(alias.name.split('.')[0])
            elif isinstance(node, _ast.ImportFrom):
                if node.module:
                    imports.add(node.module.split('.')[0])
        
        std_libs = getattr(sys, 'stdlib_module_names', set())
        
        missing = []
        for mod in imports:
            if mod in std_libs:
                continue
            if _importlib.find_spec(mod) is None:
                pkg_name = MODULE_MAP.get(mod, mod)
                missing.append(pkg_name)
        
        if not missing:
            return "✅ 依赖已就绪"

        installed = []
        errors = []
        for pkg in missing:
            try:
                result = subprocess.run(
                    [sys.executable, "-m", "pip", "install", pkg],
                    capture_output=True, text=True, timeout=120
                )
                if result.returncode == 0:
                    installed.append(pkg)
                else:
                    errors.append(f"{pkg}: {result.stderr[:100]}")
            except Exception as e:
                errors.append(f"{pkg}: {str(e)}")
        
        msg = f"📦 自动安装依赖: {', '.join(installed)}"
        if errors:
            msg += f" | ❌ 安装失败: {', '.join(errors)}"
        return msg

    def reload(self) -> Dict:
        """
        扫描 builtin/ + user/ 目录，动态加载所有 toolkit_*.py 工具。

        Returns:
            Dict: Description.
        """
        from tea_agent.toolkit.tool_loader import ToolLoader

        loader = ToolLoader(self.builtin_dir, self.user_dir)
        loaded = loader.reload_all()

        result = {
            "valid_tool": {},
            "invalid_tool": loaded["invalid"],
        }

        self.func_map.clear()
        self.meta_map.clear()
        for name, func in loaded["funcs"].items():
            self.func_map[name] = func
            self.meta_map[name] = loaded["metas"][name]

        self.func_map["toolkit_save"] = toolkit_save_impl
        self.meta_map["toolkit_save"] = meta_toolkit_save()

        self.func_map["toolkit_set_topic_title"] = toolkit_set_topic_title
        self.meta_map["toolkit_set_topic_title"] = meta_toolkit_set_topic_title()

        result["valid_tool"] = {
            k: {"func": v, "meta": self.meta_map[k]}
            for k, v in self.func_map.items()
            if k not in ("toolkit_save", "toolkit_set_topic_title")
        }
        return result

    def save(self, name: str, meta: dict, pycode: str, version: str = "") -> Tuple[int, str]:
        """
        保存工具函数到文件，支持版本管理。
        
        Args:
            name: 工具函数名
            meta: 工具元数据
            pycode: 工具函数代码
            version: 版本号（可选），格式如 "1.0.0"。如果不提供，自动递增
            
        Returns:
            Tuple[int, str]: (状态码, 消息)
        """
        meta_exam = {
            "type": "function",
            "function": {
                "name": "<工具函数名>",
                "description": "<工具函数简介>",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "param1": {
                            "type": "string",
                            "description": "参数1的说明",
                        },
                        "param2": {
                            "type": "number",
                            "description": "参数2的说明",
                        }
                    },
                    "required": ["param1"],
                }
            }
        }

        meta_exam_str = json.dumps(meta_exam, ensure_ascii=False)
        is_my_tool = name.endswith("_my")
        if is_my_tool:
            toolkit_path = self.user_dir
            os.makedirs(toolkit_path, exist_ok=True)
        else:
            toolkit_path = self.tool_dir
        filename = osp.join(toolkit_path, f"{name}.py")

        if not isinstance(meta, dict):
            return (2, "meta must be a dict")

        if meta.get("type") != "function":
            return (2, f"meta.type must be 'function', 完整的 meta 参考：{meta_exam_str}")

        if "function" not in meta:
            return (2, f"meta.function is required, 完整的 meta 参考：{meta_exam_str}")

        func = meta["function"]

        if "name" not in func:
            return (2, f"meta.function.name is required, 完整的 meta 参考：{meta_exam_str}")

        if func["name"] != name:
            return (2, f"meta.function.name '{func['name']}' does not match tool name '{name}'")

        if not name.startswith("toolkit_"):
            return (2, "tool name must start with 'toolkit_' prefix for security")

        try:
            tree = ast.parse(pycode)
        except SyntaxError as e:
            return (3, f"Syntax error in pycode: {e}")

        dep_msg = self._check_dependencies(pycode)
        if dep_msg and "❌" in dep_msg:
            logger.warning(f"Dependency check warning: {dep_msg}")
        elif dep_msg:
            logger.info(f"Dependency check: {dep_msg}")

        func_def = None
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and node.name == name:
                func_def = node
                break

        if func_def is None:
            return (3, f"Function '{name}' not found in pycode")

        if osp.exists(filename):
            with open(filename, "r", encoding="utf-8") as f:
                old_content = f.read()
            
            if not version:
                import re
                version_match = re.search(r'# version:\s*([\d.]+)', old_content)
                if version_match:
                    old_version = version_match.group(1)
                    parts = old_version.split('.')
                    parts[-1] = str(int(parts[-1]) + 1)
                    version = '.'.join(parts)
                else:
                    version = "1.0.0"
            
            pass
        
        if not version:
            version = "1.0.0"

        with open(filename, "w", encoding="utf-8") as f:
            f.write(f"## llm generated tool func, created {time.asctime()}\n")
            f.write(f"# version: {version}\n\n")
            f.write(pycode)
            f.write("\n\n")
            f.write(f"def meta_{name}() -> dict:\n")
            f.write(f"    return {json.dumps(meta, ensure_ascii=False)}\n")

        logger.warning(f"save toolkit function: {name}, version:{version}\n==> meta:\n{json.dumps(meta, indent=4)}\n==> pycode:\n{pycode}\n")

        return (0, f"ok (v{version})")
    
    def rollback(self, name: str, version: str) -> Tuple[int, str]:
        """
        回滚工具到指定版本。
        
        Args:
            name: 工具函数名
            version: 要回滚到的版本号
            
        Returns:
            Tuple[int, str]: (状态码, 消息)
        """
        toolkit_path = self.tool_dir
        backup_name = f"{name}.v{version}.bak.py"
        backup_path = osp.join(toolkit_path, backup_name)
        filename = osp.join(toolkit_path, f"{name}.py")
        
        if not osp.exists(backup_path):
            return (1, f"Version {version} backup not found for {name}")
        
        import shutil
        if osp.exists(filename):
            current_backup = f"{name}.current.bak.py"
            current_backup_path = osp.join(toolkit_path, current_backup)
            shutil.copy2(filename, current_backup_path)
        
        shutil.copy2(backup_path, filename)
        
        return (0, f"Rolled back {name} to v{version}")
    
    def list_versions(self, name: str) -> Tuple[int, List[str]]:
        """
        列出工具的所有可用版本。
        
        Args:
            name: 工具函数名
            
        Returns:
            Tuple[int, List[str]]: (状态码, 版本列表)
        """
        toolkit_path = self.tool_dir
        versions = []
        
        pattern = f"{name}.v"
        for filename in os.listdir(toolkit_path):
            if filename.startswith(pattern) and filename.endswith(".bak.py"):
                version = filename[len(pattern):-len(".bak.py")]
                versions.append(version)
        
        versions.sort(key=lambda v: [int(x) for x in v.split('.')])
        
        return (0, versions)


def toolkit_reload():
    """桥接方法：调用全局 Toolkit 实例的 reload。"""
    tlk = cast(Toolkit, globals().get("_toolkit_", None))
    if tlk:
        return tlk.reload()
    return "❌ _toolkit_ 未初始化"

