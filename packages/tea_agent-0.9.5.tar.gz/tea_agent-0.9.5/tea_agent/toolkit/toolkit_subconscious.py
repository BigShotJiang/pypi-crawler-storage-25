
import logging

logger = logging.getLogger("toolkit")

def toolkit_subconscious(action: str, focus: str = None):
    """Toolkit subconscious.
    
    Args:
        action: Description.
        focus: Description.
    """
    logger.info(f"toolkit_subconscious called: action={action!r}, focus={focus!r}")

    import os, json, time, sqlite3, threading, random, re, subprocess
    from datetime import datetime
    from pathlib import Path
    from collections import Counter

    try:
        from tea_agent.config import get_config
        STATE_FILE = os.path.join(get_config().paths.data_dir_abs, "subconscious_state.json")
        KB_DIR = get_config().paths.kb_dir_abs
    except Exception:
        STATE_FILE = os.path.expanduser("~/.tea_agent/subconscious_state.json")
        KB_DIR = os.path.expanduser("~/.tea_agent/kb")
    DEFAULT_DB = "chat_history.db"
    CYCLE_INTERVAL = 3600
    CHECK_INTERVAL = 30

    def _is_tea_agent_cwd():
        """Internal: check if tea agent cwd"""
        cwd = os.getcwd()
        pyproj = os.path.join(cwd, "pyproject.toml")
        if os.path.exists(pyproj):
            try:
                with open(pyproj, 'r') as f:
                    if 'name = "tea_agent"' in f.read() or "name = 'tea_agent'" in f.read():
                        return True
            except: pass
        if os.path.isdir(os.path.join(cwd, "tea_agent")):
            return True
        return False

    _jieba = None
    try:
        import jieba
        import jieba.analyse
        jieba.setLogLevel(20)
        _jieba = jieba
    except ImportError:
        pass

    def _ensure_dir(path):
        """Internal: ensure dir.
        
        Args:
            path: Description.
        """
        os.makedirs(path, exist_ok=True)

    def _read_state():
        """Internal: read state"""
        if os.path.exists(STATE_FILE):
            try:
                with open(STATE_FILE, 'r') as f:
                    return json.load(f)
            except: pass
        return {"running":False,"pid":os.getpid(),"started_at":None,"last_cycle_at":None,
                "cycles_completed":0,"insights":[],"goals":[],"last_focus":"mixed",
                "stats":{"memories_digested":0,"conversations_digested":0,"insights_generated":0,
                         "goals_set":0,"auto_memories":0,"llm_adjustments":0}}

    def _write_state(state):
        """Internal: write state.
        
        Args:
            state: Description.
        """
        _ensure_dir(os.path.dirname(STATE_FILE))
        state["_updated"] = datetime.now().isoformat()
        with open(STATE_FILE, 'w') as f:
            json.dump(state, f, indent=2, ensure_ascii=False)

    def _has_conversations(db_path=None):
        """Internal: check if there are any conversations in the database.
        
        Args:
            db_path: Description.
        """
        try:
            p = db_path or _get_db_path()
            if os.path.exists(p):
                conn = sqlite3.connect(p)
                cur = conn.cursor()
                cur.execute("SELECT COUNT(*) FROM conversations")
                cnt = cur.fetchone()[0]
                conn.close()
                return cnt > 0
        except: pass
        return False

    def _get_db_path():
        """Internal: get the db path"""
        if os.path.exists(DEFAULT_DB):
            return os.path.abspath(DEFAULT_DB)
        for c in [os.path.join(os.path.dirname(os.path.abspath(__file__)),"..","..","chat_history.db"),
                  os.path.expanduser(f"~/.tea_agent/{DEFAULT_DB}")]:
            if os.path.exists(c): return c
        return os.path.abspath(DEFAULT_DB)

    def _extract_keywords(text, topn=20):
        """Internal: extract keywords.
        
        Args:
            text: Description.
            topn: Description.
        """
        sw = {'the','and','for','with','this','that','from','have','are','was','has','been','not','but',
              '的','了','是','在','和','也','就','都','而','及','与','或','一个','可以','这个',
              '如果','因为','所以','但是','然后','之后','之前','已经','还是','没有','什么','怎么',
              '要','会','能','被','把','让','给','对','向','从','到','用','以','为','着','呢','吗','啊','吧','么'}
        if _jieba:
            try:
                kw = _jieba.analyse.extract_tags(text, topK=topn, withWeight=True)
                return [(w, round(s*100)) for w, s in kw if w not in sw and len(w)>=2]
            except: pass
        ch = re.findall(r'[\u4e00-\u9fff]{2,4}', text)
        en = re.findall(r'[a-zA-Z]{3,}', text.lower())
        c = Counter(ch+en)
        return [(w,n) for w,n in c.most_common(topn*2) if w.lower() not in sw and n>=2][:topn]

    def _is_jieba_available():
        """Internal: check if jieba available"""
        return _jieba is not None

    def _digest_memories(storage):
        """Internal: digest memories.
        
        Args:
            storage: Description.
        """
        if not storage or not storage.conn: return None
        cur = storage.conn.cursor()
        cur.execute("SELECT * FROM memories WHERE is_active=1 ORDER BY priority ASC, updated_at DESC LIMIT 200")
        mems = [dict(r) for r in cur.fetchall()]
        cur.execute("SELECT * FROM reflections WHERE is_applied=0 ORDER BY created_at DESC LIMIT 20")
        refs = [dict(r) for r in cur.fetchall()]
        if not mems: return None
        r = {"total_memories":len(mems),"by_category":dict(Counter(m["category"] for m in mems)),
             "by_priority":dict(Counter(m["priority"] for m in mems)),
             "untagged":sum(1 for m in mems if not (m.get("tags") or "").strip()),
             "stale_memories":[],"top_keywords":[],"unapplied_reflections":len(refs),
             "jieba_available":_is_jieba_available()}
        now = datetime.now()
        for m in mems:
            last = m.get("last_accessed_at")
            if last:
                try:
                    ld = datetime.fromisoformat(str(last).replace("Z","+00:00").replace(" ","T")[:19])
                    if (now-ld).days>7: r["stale_memories"].append(str(m["content"])[:80])
                except: pass
        all_txt = " ".join(str(m["content"]) for m in mems if m.get("content"))
        r["top_keywords"] = _extract_keywords(all_txt, 20)
        r["focus"] = _detect_focus(mems, r["top_keywords"])
        return r

    def _detect_focus(mems, keywords):
        """
        自动检测当前场景是创意期还是修复期

        Args:
            mems: Description.
            keywords: Description.
        """
        all_text = " ".join(str(m["content"]) for m in mems if m.get("content"))
        kw_str = " ".join(w for w,_ in keywords)

        bug_kw = ['bug','错误','修复','fix','问题','异常','crash','崩溃','超时','失败',
                   '不兼容','兼容','黑屏','报错','400','500','error','Exception','defect']
        creative_kw = ['创意','设计','架构','想象','如果','进化','改进','新增','feat',
                        '优化','增强','梦想','未来','可能','探索','实验']

        bug_score = sum(all_text.lower().count(kw.lower()) for kw in bug_kw)
        creative_score = sum(all_text.lower().count(kw.lower()) for kw in creative_kw)
        bug_score += sum(n for w,n in keywords if any(bk in w.lower() for bk in bug_kw))
        creative_score += sum(n for w,n in keywords if any(ck in w.lower() for ck in creative_kw))

        if bug_score > creative_score * 1.5:
            return "pragmatic"
        elif creative_score > bug_score * 1.5:
            return "creative"
        else:
            return "mixed"

    def _digest_conversations(storage, state, mm=None):
        """Internal: digest conversations.
        
        Args:
            storage: Description.
            state: Description.
            mm: Description.
        """
        if not storage or not storage.conn: return {"processed":0,"extracted":[]}
        cur = storage.conn.cursor()
        last_id = state.get("last_conversation_id", 0)
        cur.execute(
            "SELECT id, topic_id, user_msg, ai_msg, stamp FROM conversations WHERE id > ? ORDER BY id ASC LIMIT 50",
            (last_id,)
        )
        convs = [dict(r) for r in cur.fetchall()]
        extracted = []
        max_id = last_id
        candidates_list = []
        for conv in convs:
            max_id = max(max_id, conv["id"])
            user_msg = str(conv.get("user_msg",""))
            ai_msg = str(conv.get("ai_msg",""))
            candidates = _extract_memory_candidates(user_msg, ai_msg)
            for c in candidates:
                c.setdefault("tags", "auto-extracted")
                candidates_list.append(c)
        
        if mm and candidates_list:
            count = mm.ingest_extracted(candidates_list)
            extracted = [c["content"][:60] for c in candidates_list if c.get("content")][:20]
        else:
            for cand in candidates_list:
                if not _is_duplicate_memory(cur, cand.get("content","")):
                    try:
                        import uuid
                        mid = str(uuid.uuid4())[:8]
                        cur.execute(
                            "INSERT INTO memories (id, content, category, priority, importance, tags, source_topic_id, created_at, updated_at) "
                            "VALUES (?,?,?,?,?,?,?,datetime('now','localtime'),datetime('now','localtime'))",
                            (mid, cand.get("content",""), cand.get("category","general"),
                             cand.get("priority",3), cand.get("importance",2),
                             cand.get("tags","auto-extracted"), conv.get("topic_id"))
                        )
                        storage.conn.commit()
                        extracted.append(cand["content"][:60])
                    except Exception as e:
                        logger.debug(f"Failed to insert auto-extracted memory: {e}")
        return {"processed":len(convs),"extracted":extracted,"last_id":max_id}

    def _extract_memory_candidates(user_msg, ai_msg):
        """Internal: extract memory candidates.
        
        Args:
            user_msg: Description.
            ai_msg: Description.
        """
        candidates = []
        text = user_msg
        
        # Explicit memory commands
        for pat in [r'记住[：:]\s*(.+?)(?:[。！\n]|$)',
                     r'以后\s*(.+?)(?:[。！\n]|$)',
                     r'偏好[：:]\s*(.+?)(?:[。！\n]|$)',
                     r'记录[：:]\s*(.+?)(?:[。！\n]|$)',
                     r'备忘[：:]\s*(.+?)(?:[。！\n]|$)']:
            m = re.search(pat, text)
            if m and len(m.group(1))>5:
                candidates.append({"content":m.group(1).strip(),"category":"preference","priority":1,"importance":4})
        
        # Behavioral patterns / instructions
        for pat in [r'(?:总是|一直|经常|每次)\s*(.+?)(?:[。！\n]|$)',
                     r'(?:不要|别|禁止|避免|千万别)\s*(.+?)(?:[。！\n]|$)',
                     r'(?:必须|一定要|务必|确保)\s*(.+?)(?:[。！\n]|$)']:
            for m in re.finditer(pat, text):
                if len(m.group(1).strip())>5:
                    candidates.append({"content":m.group(1).strip(),"category":"instruction","priority":0,"importance":5})
        
        # Discoveries and facts
        for pat in [r'(?:发现|注意到|观察到)\s*(.+?)(?:[。！\n]|$)',
                     r'问题[：:]\s*(.+?)(?:[。！\n]|$)',
                     r'(?:确认|验证了?|证实)\s*(.+?)(?:[。！\n]|$)',
                     r'原因[：:是]\s*(.+?)(?:[。！\n]|$)',
                     r'(?:结论|总结)[：:]\s*(.+?)(?:[。！\n]|$)']:
            m = re.search(pat, text)
            if m and len(m.group(1))>10:
                candidates.append({"content":m.group(1).strip(),"category":"fact","priority":2,"importance":3})
        
        # Todos and reminders
        for pat in [r'(?:需要|还得|还要|接下来)\s*(?:做|干|处理|弄)\s*(.+?)(?:[。！\n]|$)',
                     r'(?:TODO|FIXME|HACK)[：:]\s*(.+?)(?:[。！\n]|$)',
                     r'(?:待办|计划)[：:]\s*(.+?)(?:[。！\n]|$)']:
            m = re.search(pat, text)
            if m and len(m.group(1))>5:
                candidates.append({"content":m.group(1).strip(),"category":"reminder","priority":1,"importance":3})
        
        # Technology-related facts extracted from longer sentences
        tech_kw = ['工具','toolkit','agent','python','sqlite','截屏','ocr','self_evolve',
                    '记忆','memory','反思','reflection','配置','config','进化','evolve',
                    'skill','mixin','session','token','上下文','context','数据库','database',
                    'API','cli','gui','桌面','通知','notification','截图','screenshot',
                    '压缩','compress','stream','流式','chat','对话','模型','model',
                    'LLM','GPT','Claude','DeepSeek','潜意识','subconscious','dream']
        for sent in re.split(r'[。！\n;；]', text):
            sent = sent.strip()
            if len(sent)>20 and any(kw.lower() in sent.lower() for kw in tech_kw):
                if not any(c["content"]==sent for c in candidates):
                    candidates.append({"content":sent,"category":"fact","priority":2,"importance":2})
        
        # Also extract from AI responses for technical facts
        if ai_msg:
            ai_text = str(ai_msg)
            # Extract important conclusions from AI responses
            for pat in [r'(?:总结|结论|概括)[：:]\s*(.+?)(?:[。！\n]|$)',
                         r'(?:关键|核心|重要)[：:是]\s*(.+?)(?:[。！\n]|$)',
                         r'(?:注意|⚠️|⚡|🔴)[：:]\s*(.+?)(?:[。！\n]|$)']:
                m = re.search(pat, ai_text)
                if m and len(m.group(1))>15:
                    # Avoid too many AI-generated memories; cap at 2
                    ai_candidates = [c for c in candidates if c.get("_source") == "ai_response"]
                    if len(ai_candidates) < 2:
                        candidates.append({"content":m.group(1).strip(),"category":"fact",
                                           "priority":2,"importance":2,"_source":"ai_response"})
        
        return candidates[:10]

    def _is_duplicate_memory(cur, content):
        """Internal: check if duplicate memory.
        
        Args:
            cur: Description.
            content: Description.
        """
        cur.execute("SELECT content FROM memories WHERE is_active=1")
        for (existing,) in cur.fetchall():
            if existing and content:
                sa, sb = set(existing), set(content)
                if len(sa|sb)>0 and len(sa&sb)/len(sa|sb) > 0.8:
                    return True
        return False

    def _detect_stagnation(state):
        """Internal: detect if the engine is stuck in a loop.
        
        Args:
            state: Description.
        """
        stats = state.get("stats", {})
        cycles = state.get("cycles_completed", 0)
        auto_mem = stats.get("auto_memories", 0)
        conv_dig = stats.get("conversations_digested", 0)
        # If we've completed > 5 cycles but generated 0 auto memories and digested 0 conversations
        if cycles >= 5 and auto_mem == 0 and conv_dig == 0:
            return {"stagnant": True, "reason": f"{cycles}周期无新数据注入",
                    "cycles_no_change": cycles, "action": "synthesize_or_deep_scan"}
        # Track consecutive cycles with no changes
        last_auto = state.get("_last_auto_memories", -1)
        last_conv = state.get("_last_conversations_digested", -1)
        if last_auto >= 0 and last_conv >= 0:
            if auto_mem == last_auto and conv_dig == last_conv:
                no_change_cycles = state.get("_no_change_cycles", 0) + 1
                state["_no_change_cycles"] = no_change_cycles
                if no_change_cycles >= 10:
                    return {"stagnant": True, "reason": f"连续{no_change_cycles}轮无变化",
                            "cycles_no_change": no_change_cycles, "action": "deep_analyze"}
            else:
                state["_no_change_cycles"] = 0
        state["_last_auto_memories"] = auto_mem
        state["_last_conversations_digested"] = conv_dig
        return {"stagnant": False}

    def _synthesize_memories(storage, state):
        """Internal: use cheap LLM to synthesize new memories from existing ones.
        Only called when the engine detects stagnation.
        
        Args:
            storage: Description.
            state: Description.
        """
        if not storage or not storage.conn: return 0
        cur = storage.conn.cursor()
        cur.execute("SELECT * FROM memories WHERE is_active=1 ORDER BY priority ASC, updated_at DESC LIMIT 30")
        mems = [dict(r) for r in cur.fetchall()]
        if len(mems) < 2: return 0

        # Avoid synthesizing too frequently
        last_synth = state.get("_last_synthesis_at")
        if last_synth:
            try:
                lst = datetime.fromisoformat(str(last_synth).replace("Z","+00:00")[:19])
                if (datetime.now() - lst).total_seconds() < CYCLE_INTERVAL * 2:
                    return 0
            except: pass

        try:
            from tea_agent.config import get_config
            from openai import OpenAI
            cfg = get_config()
            cheap = cfg.cheap_model
            if not (cheap.api_key and cheap.api_url and cheap.model_name):
                return 0
            client = OpenAI(api_key=cheap.api_key, base_url=cheap.api_url)

            mem_summaries = []
            for m in mems:
                mem_summaries.append(
                    f"[{m['id']}] P{m['priority']} [{m['category']}] {str(m['content'])[:120]}"
                )
            mem_text = "\n".join(mem_summaries)

            prompt = (
                "你是一个知识合成器。分析以下记忆列表，生成 2-4 条新的合成记忆。\n"
                "规则：\n"
                "1. 跨记忆关联：找出两条或多条记忆之间的隐含联系\n"
                "2. 抽象提升：从具体事实中提炼出通用原则或模式\n"
                "3. 矛盾发现：找出记忆之间可能的矛盾或紧张关系\n"
                "4. 盲点推断：基于现有记忆，推断可能缺失的关键知识\n\n"
                f"现有记忆：\n{mem_text}\n\n"
                "输出 JSON 数组，每条含：content(≤100字)、category(fact/preference/general)、"
                "priority(1-3)、importance(2-5)、tags(逗号分隔)。\n"
                "不要重复现有记忆。如果无法生成有价值的合成记忆，输出空数组 []。\n"
                "只输出 JSON 数组："
            )

            r = client.chat.completions.create(
                model=cheap.model_name,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7, max_tokens=800,
            )
            raw = (r.choices[0].message.content or "").strip() if r.choices else ""
            if raw:
                json_start = raw.find("[")
                json_end = raw.rfind("]") + 1
                if json_start >= 0 and json_end > json_start:
                    import json as _json2
                    synthesized = _json2.loads(raw[json_start:json_end])
                    added = 0
                    for item in synthesized:
                        if isinstance(item, dict) and item.get("content"):
                            content = item["content"].strip()
                            if not content or len(content) < 10:
                                continue
                            # Check for duplicates with existing memories
                            if _is_duplicate_memory(cur, content):
                                continue
                            try:
                                import uuid
                                mid = str(uuid.uuid4())[:8]
                                cur.execute(
                                    "INSERT INTO memories (id, content, category, priority, importance, tags, created_at, updated_at) "
                                    "VALUES (?,?,?,?,?,?,datetime('now','localtime'),datetime('now','localtime'))",
                                    (mid, content, item.get("category", "fact"),
                                     item.get("priority", 2), item.get("importance", 3),
                                     item.get("tags", "synthesized"))
                                )
                                storage.conn.commit()
                                added += 1
                                logger.info(f"Subconscious synthesized memory: {content[:60]}")
                            except Exception as e:
                                logger.debug(f"Failed to insert synthesized memory: {e}")
                    if added:
                        state["_last_synthesis_at"] = datetime.now().isoformat()
                    return added
        except Exception as e:
            logger.debug(f"Memory synthesis skipped: {e}")
        return 0

    def _cross_link(storage, kb_dir, state):
        """Internal: cross link.
        
        Args:
            storage: Description.
            kb_dir: Description.
            state: Description.
        """
        finds = []
        if not storage or not storage.conn: return finds
        cur = storage.conn.cursor()
        cur.execute("SELECT * FROM reflections WHERE is_applied=0 ORDER BY created_at DESC LIMIT 10")
        refs = [dict(r) for r in cur.fetchall()]
        for ref in refs:
            sugs = ref.get("suggestions","[]")
            if isinstance(sugs,str):
                try: sugs = json.loads(sugs)
                except: sugs = []
            for s in (sugs if isinstance(sugs,list) else [])[:3]:
                finds.append({"type":"unapplied_suggestion","reflection_id":ref["id"],
                              "content":str(s)[:200],"created_at":str(ref.get("created_at",""))})
        cur.execute("SELECT * FROM config_history ORDER BY created_at DESC LIMIT 10")
        cfgs = [dict(r) for r in cur.fetchall()]
        if len(cfgs)>=5:
            finds.append({"type":"frequent_config_changes",
                          "content":f"最近有{len(cfgs)}次配置变更，建议回顾是否需要固化某些配置",
                          "detail":[f"{c['key']}={c['new_value']}" for c in cfgs[:5]]})
        if os.path.exists(kb_dir):
            now = datetime.now()
            old = []
            for f in Path(kb_dir).glob("*.md"):
                days = (now - datetime.fromtimestamp(f.stat().st_mtime)).days
                if days>7: old.append((f.stem, days))
            if old:
                finds.append({"type":"stale_kb","content":f"{len(old)}个KB文档超过7天未更新",
                              "detail":[f"{n}({d}天)" for n,d in old[:5]]})
        try:
            proj_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        except NameError:
            proj_dir = os.getcwd()
        prompt_files = [
            os.path.join(proj_dir, "session_prompts.py"),
            os.path.join(proj_dir, "session_summarizer.py"),
        ]
        now = datetime.now()
        stale_prompts = []
        for pf in prompt_files:
            if os.path.exists(pf):
                days = (now - datetime.fromtimestamp(os.path.getmtime(pf))).days
                if days > 30:
                    stale_prompts.append((os.path.basename(pf), days))
        if stale_prompts:
            finds.append({"type":"stale_prompts",
                          "content":f"{len(stale_prompts)}个Prompt文件超过30天未更新",
                          "detail":[f"{n}({d}天)" for n,d in stale_prompts]})
        try:
            cur.execute("SELECT created_at FROM system_prompts WHERE is_active=1 ORDER BY created_at DESC LIMIT 1")
            row = cur.fetchone()
            if row:
                latest = row[0]
                if latest:
                    try:
                        ld = datetime.fromisoformat(str(latest).replace("Z","+00:00").replace(" ","T")[:19])
                        days = (now - ld).days
                        if days > 30:
                            finds.append({"type":"stale_system_prompt",
                                          "content":f"系统提示词 {days} 天未更新",
                                          "detail":[f"最后版本时间: {latest}"]})
                    except: pass
        except: pass
        return finds

    def _generate_insights(digest, links, conv_digest, kb_dir, state):
        """
        增强：规则洞察 + cheap LLM 深度分析

        Args:
            digest: Description.
            links: Description.
            conv_digest: Description.
            kb_dir: Description.
            state: Description.
        """
        ins = []
        if not digest: return ins
        unapp = digest.get("unapplied_reflections",0)
        if unapp>=3:
            ins.append({"level":"important","content":f"有{unapp}条未应用的反思建议等待处理","action":"review_reflections"})
        elif unapp>0:
            ins.append({"level":"info","content":f"有{unapp}条未应用的反思建议","action":"review_reflections"})
        bycat = digest.get("by_category",{})
        if bycat.get("instruction",0) > bycat.get("fact",0)*2:
            ins.append({"level":"info","content":"指令级记忆多于事实记忆，可能存在过度约束","action":"rebalance_memories"})
        stale = digest.get("stale_memories",[])
        if len(stale)>=5:
            ins.append({"level":"info","content":f"有{len(stale)}条记忆超过7天未访问，建议清理","action":"cleanup_memories"})
        for lk in links:
            if lk["type"]=="stale_kb":
                ins.append({"level":"info","content":lk["content"],"action":"update_kb"})
            elif lk["type"]=="stale_prompts":
                ins.append({"level":"warning","content":lk["content"],"action":"update_prompts"})
            elif lk["type"]=="stale_system_prompt":
                ins.append({"level":"warning","content":lk["content"],"action":"evolve_prompt"})
        top = digest.get("top_keywords",[])[:5]
        if top:
            kw = ", ".join(f"{w}({n})" for w,n in top)
            ins.append({"level":"info","content":f"记忆高频主题: {kw} | 场景: {digest.get('focus','mixed')}","action":"deep_dive"})
        if conv_digest.get("extracted"):
            n = len(conv_digest["extracted"])
            ins.append({"level":"info","content":f"从{n}条新对话中自动提取了记忆","action":"review_auto_memories"})
        if conv_digest.get("synthesized", 0):
            n = conv_digest["synthesized"]
            ins.append({"level":"info","content":f"系统停滞期间合成了{n}条新记忆","action":"review_synthesized_memories"})
        if conv_digest.get("note") == "no_conversations_in_db":
            ins.append({"level":"warning","content":"数据库中没有对话记录，引擎缺乏新数据来源","action":"synthesize_or_deep_scan"})

        try:
            from tea_agent.config import get_config
            from openai import OpenAI
            import json as _json2

            cfg = get_config()
            cheap = cfg.cheap_model
            if cheap.api_key and cheap.api_url and cheap.model_name:
                client = OpenAI(api_key=cheap.api_key, base_url=cheap.api_url)

                ctx = {
                    "total_memories": digest.get("total_memories", 0),
                    "by_category": {k: v for k, v in digest.get("by_category", {}).items()},
                    "by_priority": {str(k): v for k, v in digest.get("by_priority", {}).items()},
                    "top_keywords": [(w, n) for w, n in digest.get("top_keywords", [])[:10]],
                    "focus": digest.get("focus", "mixed"),
                    "stale_memories_count": len(digest.get("stale_memories", [])),
                    "unapplied_reflections": digest.get("unapplied_reflections", 0),
                    "rule_insights": [i["content"] for i in ins],
                    "conversations_extracted": len(conv_digest.get("extracted", [])),
                    "cross_link_count": len(links),
                    "cycles_completed": state.get("cycles_completed", 0),
                }

                deep_prompt = (
                    "你是 Tea Agent 的潜意识深度分析引擎。基于以下数据，生成 1-3 条深层洞察。\n"
                    f"数据: {_json2.dumps(ctx, ensure_ascii=False)}\n\n"
                    "规则（严格遵守）：\n"
                    "1. 不要重复规则已发现的问题\n"
                    "2. 寻找跨域关联（记忆分布→行为模式 / 关键词演变→兴趣漂移 / 场景切换频率→任务效率）\n"
                    "3. 做反事实推演：如果某个模式不存在，系统会怎样？\n"
                    "4. 输出 JSON 数组，每条含 content(≤60字中文)、action(1个具体工具调用建议)、level(info/warning)\n"
                    "5. 如果数据不足以产生新洞察，输出空数组 []\n"
                    "只输出 JSON 数组，不要额外文本："
                )

                r = client.chat.completions.create(
                    model=cheap.model_name,
                    messages=[{"role": "user", "content": deep_prompt}],
                    temperature=0.5, max_tokens=512,
                )
                raw = (r.choices[0].message.content or "").strip() if r.choices else ""
                if raw:
                    json_start = raw.find("[")
                    json_end = raw.rfind("]") + 1
                    if json_start >= 0 and json_end > json_start:
                        deep_insights = _json2.loads(raw[json_start:json_end])
                        for di in deep_insights:
                            if isinstance(di, dict) and di.get("content"):
                                di["source"] = "deep_llm"
                                ins.append(di)
                                logger.info(f"Subconscious deep insight: {di['content'][:60]}")
        except Exception as e:
            logger.debug(f"Subconscious deep insight skipped: {e}")

        for insight in ins:
            if insight["level"] == "important":
                _send_notification("🧠 潜意识洞察", insight["content"][:80])
        if ins:
            _ensure_dir(kb_dir)
            fpath = os.path.join(kb_dir,"潜意识洞察.md")
            ts = datetime.now().strftime("%Y-%m-%d %H:%M")
            txt = f"# 潜意识洞察\n\n> 更新: {ts} | 循环: {state.get('cycles_completed',0)} | 间隔: 1小时\n> 分词: {'jieba' if digest.get('jieba_available') else 'bigram'} | 场景: {digest.get('focus','mixed')}\n\n## 最新洞察\n\n"
            for i,insight in enumerate(ins[-10:],1):
                icon = {"important":"🔴","warning":"🟡","info":"🔵"}.get(insight["level"],"⚪")
                suffix = " 🤖" if insight.get("source") == "deep_llm" else ""
                txt += f"{i}. {icon} **{insight['content']}**{suffix}\n"
                if insight.get("action"): txt += f"   → 建议: `{insight['action']}`\n"
            txt += "\n---\n*由潜意识引擎自动生成*\n"
            with open(fpath,'w') as f: f.write(txt)
        return ins

    def _set_goals(digest, links, insights, conv_digest, state, db_path):
        """Internal: set the goals.
        
        Args:
            digest: Description.
            links: Description.
            insights: Description.
            conv_digest: Description.
            state: Description.
            db_path: Description.
        """
        goals = []
        unapp = digest.get("unapplied_reflections",0) if digest else 0
        if unapp>=3:
            goals.append({"priority":1,"goal":f"回顾并应用{unapp}条未处理的反思建议","action":"toolkit_reflection(action='list')"})
        elif unapp>0:
            goals.append({"priority":2,"goal":f"回顾并应用{unapp}条未处理的反思建议","action":"toolkit_reflection(action='list')"})
        for lk in links:
            if lk["type"]=="stale_kb":
                goals.append({"priority":2,"goal":"更新过期KB文档","action":"toolkit_kb(action='list')"})
                break
            elif lk["type"]=="stale_prompts":
                goals.append({"priority":2,"goal":"更新过时的Prompt文件","action":"检查 session_prompts.py 和 session_summarizer.py"})
                break
            elif lk["type"]=="stale_system_prompt":
                goals.append({"priority":1,"goal":"进化系统提示词(超过30天未更新)","action":"toolkit_prompt_evolve(action='evolve')"})
                break
        for ins in insights:
            if ins.get("action")=="cleanup_memories":
                goals.append({"priority":3,"goal":"清理超过7天未访问的记忆","action":"toolkit_memory(action='search')"})
            elif ins.get("action")=="review_auto_memories":
                goals.append({"priority":2,"goal":"审查自动提取的记忆","action":"toolkit_memory(action='list')"})
            elif ins.get("action")=="synthesize_or_deep_scan":
                goals.append({"priority":1,"goal":"系统停滞：需要新数据注入或深度扫描","action":"手动进行对话或运行toolkit_subconscious(action='dream')"})
        # Only add self-report every 10 cycles to avoid repetition
        if state.get("cycles_completed", 0) % 10 == 0:
            goals.append({"priority":3,"goal":"运行自检: toolkit_self_report()","action":"toolkit_self_report()"})
        seen=set(); uniq=[]
        for g in sorted(goals,key=lambda x:x["priority"]):
            if g["goal"] not in seen: seen.add(g["goal"]); uniq.append(g)
        return uniq[:7]

    def _send_notification(title, msg, expire_ms=5000):
        """
        跨平台桌面通知：Windows/macOS/Linux。

        Args:
            title: Description.
            msg: Description.
            expire_ms: Description.
        """
        import sys as _sys
        try:
            if _sys.platform == 'win32':
                import tempfile, os as _os
                ps_script = f'''
Add-Type -AssemblyName System.Windows.Forms
[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
$tpl = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText02)
$texts = @($tpl.GetElementsByTagName("text"))
$null = $texts[0].AppendChild($tpl.CreateTextNode("{title}"))
$null = $texts[1].AppendChild($tpl.CreateTextNode("{msg}"))
$toast = [Windows.UI.Notifications.ToastNotification]::new($tpl)
[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("TeaAgent.TeaAgent.TeaAgent").Show($toast)
'''
                tmp = tempfile.NamedTemporaryFile(mode='w', suffix='.ps1', delete=False, encoding='utf-8')
                try:
                    tmp.write(ps_script)
                    tmp.close()
                    subprocess.run(['powershell', '-NoProfile', '-File', tmp.name],
                        capture_output=True, timeout=10)
                finally:
                    try: _os.unlink(tmp.name)
                    except: pass
            elif _sys.platform == 'darwin':
                subprocess.run(['osascript', '-e',
                    f'display notification "{msg}" with title "{title}"'],
                    capture_output=True, timeout=5)
            else:
                _linux_notify_fallback(title, msg, expire_ms)
        except: pass

    def _linux_notify_fallback(title, msg, expire_ms=5000):
        """
        Linux 通知级联回退：DBus 直连 → GI Notify → notify-send → kdialog。

        Args:
            title: Description.
            msg: Description.
            expire_ms: Description.
        """
        import shutil as _sh

        try:
            import dbus
            from dbus.mainloop.glib import DBusGMainLoop
            DBusGMainLoop(set_as_default=True)
            bus = dbus.SessionBus()
            proxy = bus.get_object('org.freedesktop.Notifications', '/org/freedesktop/Notifications')
            iface = dbus.Interface(proxy, 'org.freedesktop.Notifications')
            iface.Notify(
                'TeaAgent',
                dbus.UInt32(0),
                '',
                title,
                msg,
                [],
                {
                    'urgency': dbus.Byte(2),
                    'transient': dbus.Boolean(False),
                    'desktop-entry': dbus.String('teaagent'),
                },
                dbus.Int32(expire_ms)
            )
            return
        except Exception:
            pass

        try:
            import gi
            gi.require_version('Notify', '0.7')
            from gi.repository import Notify, GLib
            if not Notify.is_initted():
                Notify.init('TeaAgent')
            notification = Notify.Notification.new(title, msg, '')
            notification.set_urgency(Notify.Urgency.CRITICAL)
            notification.set_timeout(expire_ms)
            notification.set_hint('transient', GLib.Variant('b', False))
            notification.set_hint('desktop-entry', GLib.Variant('s', 'teaagent'))
            notification.show()
            return
        except Exception:
            pass

        if _sh.which('notify-send'):
            subprocess.run(['notify-send', '--app-name=TeaAgent',
                '--hint=boolean:transient:false',
                title, msg, '--expire-time=' + str(expire_ms)],
                capture_output=True, timeout=3)
            return

        if _sh.which('kdialog'):
            subprocess.run(['kdialog', '--passivepopup', msg,
                '--title', title, str(expire_ms // 1000)],
                capture_output=True, timeout=5)
            return

    def _send_cycle_summary(result, state, first_run=False):
        """
        每轮循环后发送摘要通知，让用户感知后台运行结果

        Args:
            result: Description.
            state: Description.
            first_run: Description.
        """
        digest = result.get("digest") or {}
        insights = result.get("insights") or []
        goals = result.get("goals") or []
        conv = result.get("conv_digest") or {}
        n_insights = len(insights)
        n_goals = len(goals)
        n_auto = len(conv.get("extracted", []))
        focus = digest.get("focus", "mixed") if digest else "mixed"
        mode_label = {"pragmatic":"🔧务实", "creative":"🎨创意", "mixed":"🔀混合"}.get(focus, focus)
        cycle_n = state.get("cycles_completed", 0)
        prefix = "首轮" if first_run else f"第{cycle_n}轮"

        lines = [f"🧠 潜意识 {prefix}完成 [{mode_label}]"]
        if digest:
            lines.append(f"记忆: {digest.get('total_memories',0)}条活跃")
            kw = digest.get("top_keywords", [])[:3]
            if kw:
                lines.append(f"主题: {', '.join(w for w,_ in kw)}")
        if n_auto:
            lines.append(f"新提取: {n_auto}条记忆")
        if n_insights:
            lines.append(f"洞察: {n_insights}条")
            for ins in insights:
                if ins.get("level") == "important":
                    lines.append(f"  ⚠️ {ins['content'][:60]}")
        if n_goals:
            lines.append(f"目标: {n_goals}个待办")
        lines.append(f"📁 详情: ~/.tea_agent/kb/潜意识洞察.md")

        msg = "\n".join(lines)
        _send_notification("🧠 潜意识引擎", msg, expire_ms=8000)

    def _run_cycle(state):
        """Internal: run cycle.
        
        Args:
            state: Description.
        """
        from tea_agent.memory import MemoryManager
        from tea_agent.store import Storage
        
        db_path = _get_db_path()
        kb_dir = KB_DIR
        storage = None
        try:
            storage = Storage(db_path)
            mm = MemoryManager(storage)

            digest = _digest_memories(storage)
            has_conv = _has_conversations(db_path)
            
            # Check for stagnation before processing conversations
            stagnation = _detect_stagnation(state) if not has_conv else {"stagnant": False}
            
            if has_conv:
                conv_digest = _digest_conversations(storage, state, mm=mm)
            else:
                # No conversations at all - skip digestion and note the state
                conv_digest = {"processed": 0, "extracted": [], "last_id": 0,
                               "note": "no_conversations_in_db"}
                # Trigger memory synthesis when stagnant to create new data
                if stagnation.get("stagnant"):
                    n = _synthesize_memories(storage, state)
                    if n:
                        conv_digest["synthesized"] = n
                        stagnation = {"stagnant": False}  # Reset stagnation after synthesis
                        # Re-digest memories after synthesis
                        digest = _digest_memories(storage)

            # LLM priority adjustment (skip if no conversations)
            if has_conv or state.get("cycles_completed", 0) % 10 == 0:
                try:
                    from tea_agent.config import get_config
                    from openai import OpenAI
                    cfg = get_config()
                    cheap = cfg.cheap_model
                    if cheap.api_key and cheap.api_url and cheap.model_name:
                        client = OpenAI(api_key=cheap.api_key, base_url=cheap.api_url)
                        topics_text = conv_digest.get("topics_summary", "")
                        if not topics_text:
                            kw = digest.get("top_keywords", []) if digest else []
                            topics_text = ", ".join(w for w, _ in kw[:10]) if kw else ""
                        if topics_text:
                            n = mm.llm_adjust_priorities(topics_text, client=client, model=cheap.model_name)
                            if n:
                                state["stats"]["llm_adjustments"] = state["stats"].get("llm_adjustments", 0) + n
                except Exception:
                    pass

            links = _cross_link(storage, kb_dir, state)
            insights = _generate_insights(digest, links, conv_digest, kb_dir, state)
            
            # If stagnant, add a specific insight
            if stagnation.get("stagnant"):
                insights.append({
                    "level": "warning",
                    "content": stagnation.get("reason", "系统循环停滞"),
                    "action": stagnation.get("action", "synthesize_or_deep_scan"),
                    "source": "stagnation_detector"
                })
            
            goals = _set_goals(digest, links, insights, conv_digest, state, db_path)
            state["last_cycle_at"] = datetime.now().isoformat()
            state["cycles_completed"] = state.get("cycles_completed", 0) + 1
            state["insights"] = [i["content"] for i in insights[-5:]]
            state["goals"] = [g["goal"] for g in goals[:7]]
            state["last_focus"] = digest.get("focus", "mixed") if digest else "mixed"
            if conv_digest.get("last_id", 0) > state.get("last_conversation_id", 0):
                state["last_conversation_id"] = conv_digest["last_id"]
            if digest:
                state["stats"]["memories_digested"] = state["stats"].get("memories_digested", 0) + digest["total_memories"]
            state["stats"]["conversations_digested"] = state["stats"].get("conversations_digested", 0) + conv_digest.get("processed", 0)
            state["stats"]["insights_generated"] = state["stats"].get("insights_generated", 0) + len(insights)
            state["stats"]["goals_set"] = state["stats"].get("goals_set", 0) + len(goals)
            state["stats"]["auto_memories"] = state["stats"].get("auto_memories", 0) + len(conv_digest.get("extracted", []))
            # Track synthesized memories
            if conv_digest.get("synthesized", 0):
                state["stats"]["auto_memories"] = state["stats"].get("auto_memories", 0) + conv_digest["synthesized"]
            _write_state(state)
            return {"digest": digest, "insights": insights, "goals": goals, "conv_digest": conv_digest}
        finally:
            if storage:
                try: storage.close()
                except: pass

    def _subconscious_loop():
        """Internal: subconscious loop"""
        state = _read_state()
        _ensure_dir(os.path.dirname(STATE_FILE))
        state["running"] = True
        state["pid"] = os.getpid()
        state["started_at"] = datetime.now().isoformat()
        _write_state(state)
        _send_notification("🧠 潜意识引擎 v2.1", "已启动！场景自适应：修bug收敛分析，做创意发散联想")

        try:
            result = _run_cycle(state)
            _send_cycle_summary(result, state, first_run=True)
        except Exception as e:
            state = _read_state()
            state["_last_error"] = str(e)[:200]
            _write_state(state)

        checks_per_cycle = CYCLE_INTERVAL // CHECK_INTERVAL
        while True:
            for _ in range(checks_per_cycle):
                time.sleep(CHECK_INTERVAL)
                state = _read_state()
                if not state.get("running") or state.get("pid") != os.getpid():
                    state["running"] = False
                    _write_state(state)
                    return
            state = _read_state()
            try:
                result = _run_cycle(state)
                _send_cycle_summary(result, state)
            except Exception as e:
                state = _read_state()
                state["_last_error"] = str(e)[:200]
                _write_state(state)

    def _dream(focus_override=None):
        """Internal: dream.
        
        Args:
            focus_override: Description.
        """
        db_path = _get_db_path()
        kb_dir = KB_DIR
        if not os.path.exists(db_path): return {"error":"数据库不存在"}
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        cur.execute("SELECT content, category, tags FROM memories WHERE is_active=1 ORDER BY RANDOM() LIMIT 30")
        mems = [dict(r) for r in cur.fetchall()]
        
        cur.execute("SELECT user_msg, ai_msg FROM conversations ORDER BY id DESC LIMIT 30")
        recent = [dict(r) for r in cur.fetchall()]
        conn.close()

        if len(mems) < 2: return {"dream":"记忆不足","sparks":[]}

        all_text = " ".join(str(m["content"]) for m in mems)
        keywords = _extract_keywords(all_text, 20) if all_text else []
        detected_focus = _detect_focus(mems, keywords)
        effective_focus = focus_override or detected_focus

        results = []

        if effective_focus in ("pragmatic", "mixed"):
            prag = _pragmatic_analysis(mems, recent, keywords)
            results.extend(prag)

        if effective_focus in ("creative", "mixed"):
            creative = _creative_dream(mems)
            results.extend(creative)

        if not results:
            creative = _creative_dream(mems)
            results = creative

        random.shuffle(results)

        _ensure_dir(kb_dir)
        fpath = os.path.join(kb_dir, "创意火花.md")
        ts = datetime.now().strftime("%Y-%m-%d %H:%M")
        mode_label = {"pragmatic":"🔧 务实分析","creative":"🎨 创意发散","mixed":"🔀 混合模式"}.get(effective_focus, "🔀 混合")
        txt = f"# 💫 创意火花\n\n> 生成: {ts} | Dream v2.1 | 场景: {mode_label}\n> 修bug时收敛分析 · 做创意时发散联想\n\n"
        for i, s in enumerate(results[:12], 1):
            txt += f"## 火花 {i}: {s['mode']}\n\n**{s.get('combination', '')}**\n\n💡 {s.get('creative_prompt', '')}\n\n---\n"
        txt += "\n*由潜意识引擎 v2.1 自动生成 — 场景自适应*\n"
        with open(fpath, 'w') as f: f.write(txt)

        return {"dream":f"产生了{len(results)}个火花", "focus": effective_focus,
                "mode_label": mode_label, "sparks": results[:12], "saved_to": fpath}

    def _pragmatic_analysis(mems, recent_convs, keywords):
        """
        务实分析：模式识别、根因分析、修复建议

        Args:
            mems: Description.
            recent_convs: Description.
            keywords: Description.
        """
        sparks = []
        mem_texts = [str(m["content"]) for m in mems]

        error_patterns = []
        error_kw = ['超时','timeout','失败','fail','错误','error','异常','exception',
                     '不兼容','incompatible','黑屏','黑','崩溃','crash','400','401','403','404','500',
                     '未找到','not found','None','null','undefined']
        for mt in mem_texts:
            for kw in error_kw:
                if kw.lower() in mt.lower():
                    error_patterns.append((kw, mt))
                    break

        err_counter = Counter(ep[0] for ep in error_patterns)
        if err_counter:
            top_errors = err_counter.most_common(3)
            err_list = ", ".join(f"{k}({v}次)" for k,v in top_errors)
            sparks.append({
                "mode": "🔧 错误模式",
                "combination": f"记忆中出现 {len(error_patterns)} 个问题信号",
                "creative_prompt": f"高频错误: {err_list}。建议逐一排查：① 检查是否有共同的底层原因 ② 优先修复出现次数最多的 ③ 考虑添加针对性的错误处理/重试机制"
            })

        compat_issues = [mt for mt in mem_texts if any(k in mt.lower() for k in ['wayland','x11','kde','gnome','兼容','compatible'])]
        if len(compat_issues) >= 2:
            sparks.append({
                "mode": "🔧 兼容性链",
                "combination": f"发现 {len(compat_issues)} 条环境兼容性相关记忆",
                "creative_prompt": f"这些兼容性问题可能共享同一个根因：环境检测不够全面。建议：创建统一的环境适配层（Adapter Pattern），集中管理平台差异，而不是在每个工具中各自处理。"
            })

        tool_issues = [mt for mt in mem_texts if any(k in mt.lower() for k in ['toolkit','工具','安装','install','import','缺失','module'])]
        if tool_issues:
            sparks.append({
                "mode": "🔧 依赖分析",
                "combination": f"发现 {len(tool_issues)} 条工具/依赖相关记忆",
                "creative_prompt": f"建议运行 toolkit_pkg(action='ensure') 确保所有依赖就绪。考虑在启动时自动检查核心依赖，减少运行时发现缺失模块的绕路。"
            })

        fix_intents = []
        for conv in recent_convs:
            user = str(conv.get("user_msg", ""))
            if any(k in user.lower() for k in ['修复','fix','修','改','bug','问题','错误']):
                fix_intents.append(user[:80])
        if fix_intents:
            sparks.append({
                "mode": "🔧 修复意向",
                "combination": f"最近对话中有 {len(fix_intents)} 条修复意图",
                "creative_prompt": f"待修复问题预览: {'; '.join(fix_intents[:3])}。建议将这些修复任务添加到记忆系统并标记优先级。"
            })

        priorities = []
        if err_counter:
            priorities.append(f"修复高频错误: {err_counter.most_common(1)[0][0]}")
        if compat_issues:
            priorities.append("创建统一环境适配层")
        if len(mems) > 10:
            priorities.append("清理冗余/过期记忆")
        if priorities:
            sparks.append({
                "mode": "🔧 优先级建议",
                "combination": "基于记忆分析的行动建议",
                "creative_prompt": " → ".join([f"① {p}" for p in priorities[:3]])
            })

        return sparks

    def _creative_dream(mems):
        """
        创意发散：跨域碰撞、反向思维、极端假设、隐喻映射

        Args:
            mems: Description.
        """
        random.shuffle(mems)
        sparks = []

        for i in range(0, len(mems)-1, 2):
            a, b = mems[i], mems[i+1]
            if a["category"] != b["category"]:
                sparks.append({
                    "mode": "🌐 跨域碰撞",
                    "combination": f"「{str(a['content'])[:50]}...」 × 「{str(b['content'])[:50]}...」",
                    "categories": f"{a['category']} × {b['category']}",
                    "creative_prompt": f"如果将'{str(a['content'])[:40]}'的思想应用到'{str(b['content'])[:40]}'领域会怎样？"
                })

        for m in mems[:4]:
            rev = _reverse_thinking(str(m["content"]))
            if rev:
                sparks.append({"mode":"🔄 反向思维", "combination": f"原始: 「{str(m['content'])[:60]}...」",
                               "categories": m['category'], "creative_prompt": rev})

        for m in mems[4:8]:
            ext = _extreme_scenario(str(m["content"]))
            if ext:
                sparks.append({"mode":"🔬 极端假设", "combination": f"原始: 「{str(m['content'])[:60]}...」",
                               "categories": m['category'], "creative_prompt": ext})

        domains = ["生物学/生态系统","物理学/量子力学","建筑学/城市设计","音乐/作曲","烹饪/美食",
                    "游戏设计","军事战略","心理学/认知科学","经济学/市场","天文学/宇宙"]
        for i, m in enumerate(mems[:4]):
            domain = domains[i % len(domains)]
            sparks.append({
                "mode": "🎭 隐喻映射",
                "combination": f"「{str(m['content'])[:60]}...」 → {domain}",
                "categories": m['category'],
                "creative_prompt": f"如果把'{str(m['content'])[:40]}'比作{domain}中的现象，会有什么惊人的洞察？"
            })

        return sparks

    def _reverse_thinking(text):
        """Internal: reverse thinking.
        
        Args:
            text: Description.
        """
        reversals = [("删除","创建"),("启动","停止"),("增加","减少"),("加速","减慢"),
                     ("自动","手动"),("集中","分散"),("保存","丢弃"),("优化","简化"),
                     ("记住","遗忘"),("优先","延后"),("公开","隐藏"),("永久","临时")]
        for a,b in reversals:
            if a in text:
                return f"反过来想：如果'{text[:50]}'被反转，即'{b}'而不是'{a}'，系统会变成什么样？"
            if b in text:
                return f"反过来想：如果'{text[:50]}'被反转，即'{a}'而不是'{b}'，系统会变成什么样？"
        return f"如果完全忽略'{text[:40]}'这个约束，会释放什么新的可能性？"

    def _extreme_scenario(text):
        """Internal: extreme scenario.
        
        Args:
            text: Description.
        """
        scenarios = [
            f"假设'{text[:40]}'放大100倍——如果有100倍的数据量/规模/频率，会发生什么？",
            f"假设'{text[:40]}'完全归零——如果这个条件突然消失，系统如何应对？",
            f"假设'{text[:40]}'在极端环境下运行——没有网络、没有内存、没有用户输入，还能工作吗？",
            f"假设'{text[:40]}'是唯一的约束——如果所有其他规则都删除，只保留这一个，系统会怎样简化？",
        ]
        return random.choice(scenarios)

    state = _read_state()

    if action == "start":
        if not _is_tea_agent_cwd():
            return {"status":"rejected", "reason":"当前目录非 tea_agent 项目，为防止意外修改拒绝启动",
                    "cwd": os.getcwd(), "hint": "请在 tea_agent 项目根目录下启动 Dream 线程"}
        if state.get("running") and state.get("pid") == os.getpid():
            return {"status":"already_running","started_at":state.get("started_at"),
                    "cycles_completed":state.get("cycles_completed",0)}
        if state.get("running") and state.get("pid") != os.getpid():
            state["running"]=False; _write_state(state)
        t = threading.Thread(target=_subconscious_loop, daemon=True)
        t.start()
        time.sleep(0.5)
        state = _read_state()
        return {"status":"started","pid":os.getpid(),"started_at":state.get("started_at"),
                "version":"v2.2","cycle_interval":"1小时","first_run_immediate":True,
                "adaptive_focus":True,"cwd_mode":"full",
                "message":"🧠 潜意识引擎 v2.1 — 场景自适应 Dream。修bug→收敛分析，做创意→发散联想"}

    elif action == "stop":
        state["running"]=False; state["stopped_at"]=datetime.now().isoformat()
        _write_state(state)
        return {"status":"stopped","cycles_completed":state.get("cycles_completed",0)}

    elif action == "status":
        running = state.get("running") and state.get("pid")==os.getpid()
        return {"running":running,"pid":state.get("pid"),"started_at":state.get("started_at"),
                "last_cycle_at":state.get("last_cycle_at"),"cycles_completed":state.get("cycles_completed",0),
                "cycle_interval":"1小时","last_focus":state.get("last_focus","mixed"),
                "stats":state.get("stats",{}),"goals_count":len(state.get("goals",[])),
                "insights_count":len(state.get("insights",[])),"jieba":_is_jieba_available(),
                "last_conversation_id":state.get("last_conversation_id",0)}

    elif action == "dream":
        result = _run_cycle(state)
        dream_result = _dream(focus_override=focus)
        _send_cycle_summary(result, state)
        state = _read_state()
        state["insights"]=[i["content"] for i in result["insights"][-5:]]
        state["goals"]=[g["goal"] for g in result["goals"][:7]]
        state["last_dream_at"]=datetime.now().isoformat()
        _write_state(state)
        return {"digest":{"total_memories":result["digest"]["total_memories"] if result["digest"] else 0,
                          "focus":result["digest"].get("focus","mixed") if result["digest"] else "mixed"},
                "conversations":{"processed":result["conv_digest"].get("processed",0),
                                 "auto_extracted":len(result["conv_digest"].get("extracted",[])),
                                 "synthesized":result["conv_digest"].get("synthesized",0),
                                 "note":result["conv_digest"].get("note","")},
                "insights":[i["content"] for i in result["insights"]],
                "goals":[g["goal"] for g in result["goals"][:5]],
                "dream":dream_result}

    elif action == "goals":
        return {"goals":state.get("goals",[]),"last_updated":state.get("last_cycle_at"),
                "total_cycles":state.get("cycles_completed",0)}

    elif action == "insights":
        return {"insights":state.get("insights",[]),"last_updated":state.get("last_cycle_at"),
                "focus":state.get("last_focus","mixed"),
                "kb_file":os.path.join(KB_DIR,"潜意识洞察.md")}

    else:
        return {"error":f"未知action: {action}","supported":["start","stop","status","dream","goals","insights"],
                "dream_focus":"dream支持focus参数: pragmatic(务实)/creative(创意)/mixed(混合)"}

def meta_toolkit_subconscious() -> dict:
    """
    Meta toolkit subconscious

    Returns:
        dict: Description.
    """
    return {"type": "function", "function": {"name": "toolkit_subconscious", "description": "潜意识引擎 v2.1 — 场景自适应Dream。自动检测场景（修bug→收敛务实分析/做创意→发散联想），dream支持focus参数手动指定。start启动后每1小时循环。", "parameters": {"type": "object", "properties": {"action": {"type": "string", "enum": ["start", "stop", "status", "dream", "goals", "insights"], "description": "start=启动, stop=停止, status=状态, dream=深度消化(支持focus参数: pragmatic/creative/mixed), goals=目标, insights=洞察"}, "focus": {"type": "string", "enum": ["pragmatic", "creative", "mixed"], "description": "[dream] 手动指定Dream模式: pragmatic=务实分析(bug模式识别/根因分析), creative=创意发散(跨域/反向/极端/隐喻), mixed=混合(自动)"}}, "required": ["action"]}}}
