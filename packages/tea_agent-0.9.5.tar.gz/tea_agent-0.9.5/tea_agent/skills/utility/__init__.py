"""Skill: 通用工具 — 时间日期、农历转换（始终激活）"""
SKILL_MANIFEST = {
    "name": "utility",
    "version": "1.0.0",
    "description": "通用工具：获取当前时间、计算日期差、公历农历互转 — 默认激活",
    "tools": [
        "toolkit_gettime",
        "toolkit_date_diff",
        "toolkit_lunar",
    ],
    "activation": "auto",
    "dependencies": [],
    "trigger_words": [
        "时间", "日期", "几号", "星期", "天数",
        "多少天", "今天", "明天", "昨天",
        "农历", "阴历", "公历", "阳历", "天干地支",
        "生肖", "属相", "节气",
    ],
}
