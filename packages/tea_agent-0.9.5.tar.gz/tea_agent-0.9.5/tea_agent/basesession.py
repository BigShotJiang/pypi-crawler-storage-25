"""
会话模块 - 基类
提供统一的聊天会话接口抽象基类
"""

from abc import ABC, abstractmethod
from typing import List, Dict, Callable, Tuple
import logging
import os
import sys

logger = logging.getLogger("basesession")

class BaseChatSession(ABC):
    """
    聊天会话抽象基类
    定义公共接口和共享功能
    """

    _KB_THRESHOLD: int = 65536
    _DEFAULT_TOOL_THRESHOLD: int = 2048
    _TEXT_FILE_THRESHOLD: int = 16384
    _SOURCE_EXTENSIONS = {'.py', '.java', '.c', '.cpp', '.h', '.hpp', '.rs', '.go',
                          '.ts', '.js', '.jsx', '.tsx', '.vue', '.swift', '.kt',
                          '.scala', '.rb', '.php', '.cs', '.sql', '.sh', '.bash',
                          '.ps1', '.bat', '.cmd', '.xml', '.yaml', '.yml', '.toml',
                          '.json', '.cfg', '.ini', '.conf', '.cmake', '.mk',
                          '.r', '.jl', '.lua', '.ex', '.exs', '.erl', '.hrl',
                          '.elm', '.dart', '.nim', '.zig', '.v', '.sv', '.vhdl'}
    _TEXT_EXTENSIONS = {'.txt', '.log', '.md', '.rst', '.csv', '.tsv', '.text',
                        '.out', '.err', '.stdout', '.stderr', '.nohup'}

    def __init__(
        self,
        model: str,
        max_history: int = 10,
        system_prompt: str = "你是一个智能助手，可以调用工具函数来帮助用户解决问题。"
    ):
        """
        初始化基类

        Args:
            model: 模型名称
            max_history: 最大历史消息数
            system_prompt: 系统提示词
        """
        self.model = model
        self.max_history = max_history
        self.system_prompt = system_prompt
        self._history_summary = ""

        self.messages: List[Dict] = []
        self.messages.append({"role": "system", "content": self.system_prompt})

        self.interrupted = False

    @abstractmethod
    def chat_stream(self, msg: str, callback: Callable[[str], None]) -> Tuple[str, bool]:
        """
        流式对话（抽象方法，子类必须实现）

        Args:
            msg: 用户消息
            callback: 流式输出回调函数

        Returns:
            Tuple[str, bool]: (助手完整回复, 是否使用了工具调用)
        """
        pass

    def add_user_message(self, msg):
        """
        添加用户消息，支持纯文本或含图片的结构化输入

        Args:
            msg: Description.
        """
        if isinstance(msg, str):
            self.messages.append({"role": "user", "content": msg})
        elif isinstance(msg, dict):
            entry = {"role": "user", "content": msg.get("text", "")}
            images = msg.get("images", [])
            if images:
                entry["images"] = images
            self.messages.append(entry)
        else:
            self.messages.append({"role": "user", "content": str(msg)})

    def add_assistant_message(self, msg: str):
        """
        添加助手消息

        Args:
            msg (str): Description.
        """
        self.messages.append({"role": "assistant", "content": msg})

    def add_tool_result(self, tool_call_id: str, content: str):
        """
        添加工具执行结果

        Args:
            tool_call_id (str): Description.
            content (str): Description.
        """
        self.messages.append({
            "role": "tool",
            "tool_call_id": tool_call_id,
            "content": content
        })

    def get_recent_messages(self) -> List[Dict]:
        """
        获取最近的消息（排除系统消息）

        Returns:
            List[Dict]: Description.
        """
        return [m for m in self.messages if m["role"] != "system"]

    @staticmethod
    def _strip_reasoning_content(messages: List[Dict]) -> None:
        """
        原地清除消息列表中的 reasoning_content 字段。

        Args:
            messages (List[Dict]): Description.

        Returns:
            None: Description.
        """
        for msg in messages:
            if msg.get("role") == "assistant":
                continue
            msg.pop("reasoning_content", None)

    @staticmethod
    def _compress_tool_content(content: str, max_chars: int = 2048) -> str:
        """
        L1 工具输出压缩：首尾各 max_chars//2 字节，按换行对齐。

        策略：
        - 短输出（≤max_chars 字节）：原样保留
        - max_chars >= sys.maxsize：不截断，完整返回
        - 长输出：保留首尾各 half 字节，按换行边界对齐避免截断半行

        Args:
            content: 原始工具输出
            max_chars: 阈值字节数，超过则触发首尾截断

        Returns:
            压缩后的输出摘要
        """
        if not content:
            return content

        if max_chars >= sys.maxsize:
            return content

        raw = content.encode("utf-8")
        total_bytes = len(raw)

        if total_bytes <= max_chars:
            return content

        half = max_chars // 2

        head_end = half
        if head_end > 0:
            nl = raw.find(b'\n', head_end)
            if nl != -1 and nl < half + 256:
                head_end = nl
            else:
                nl = raw.rfind(b'\n', 0, head_end)
                if nl != -1 and nl > half - 256:
                    head_end = nl

        head_bytes = raw[:head_end]

        tail_start = total_bytes - half
        if tail_start > 0:
            nl = raw.rfind(b'\n', tail_start, total_bytes)
            if nl != -1 and nl > tail_start - 256:
                tail_start = nl + 1
            else:
                nl = raw.find(b'\n', tail_start)
                if nl != -1 and nl < tail_start + 256:
                    tail_start = nl + 1

        tail_bytes = raw[tail_start:]

        head_text = head_bytes.decode("utf-8", errors="replace")
        tail_text = tail_bytes.decode("utf-8", errors="replace")
        skipped_bytes = total_bytes - len(head_bytes) - len(tail_bytes)

        return (
            f"[工具输出压缩: {total_bytes}B 原始, 保留 {len(head_bytes) + len(tail_bytes)}B]\n"
            f"{head_text}\n"
            f"... [{skipped_bytes} 字节省略] ...\n"
            f"{tail_text}"
        )

    @staticmethod
    def _compress_json_args(args_str: str, args_bytes: int, max_bytes: int = 2048) -> str:
        """
        JSON 感知截断 tool_calls 参数。
        
        策略：
        1. 尝试 json.loads 解析 → 成功则递归压缩超长 string value
        2. 解析失败 → 回退到字节截断（首尾各1024B，按换行对齐）
        
        递归压缩规则（对 dict 和 list 中的值）：
        - string > 1024 字节：截为首512B+尾512B，标记 [截断]
        - 其他类型（number/bool/null）：原样保留
        - 嵌套 dict/list：递归处理
        
        Args:
            args_str: 原始 arguments JSON 字符串
            args_bytes: 原始字节数（用于截断标记）
            max_bytes: 触发压缩的阈值
        
        Returns:
            压缩后的合法 JSON 字符串
        """
        import json as _json
        
        try:
            obj = _json.loads(args_str)
        except (_json.JSONDecodeError, ValueError):
            half = max_bytes // 2
            raw = args_str.encode("utf-8")
            head_end = half
            nl = raw.find(b'\n', head_end)
            if nl != -1 and nl < half + 256:
                head_end = nl
            else:
                nl = raw.rfind(b'\n', 0, head_end)
                if nl != -1 and nl > half - 256:
                    head_end = nl
            tail_start = len(raw) - half
            nl = raw.rfind(b'\n', tail_start, len(raw))
            if nl != -1 and nl > tail_start - 256:
                tail_start = nl + 1
            
            head_text = raw[:head_end].decode("utf-8", errors="replace")
            tail_text = raw[tail_start:].decode("utf-8", errors="replace")
            return (
                head_text +
                f"\n... [L1截断: {args_bytes}B 参数] ...\n" +
                tail_text
            )
        
        HALF = 512
        
        def _compress_value(val, path=""):
            """
            递归压缩值，返回 (compressed_val, truncated_count)

            Args:
                val: Description.
                path: Description.
            """
            if isinstance(val, str):
                vbytes = len(val.encode("utf-8"))
                if vbytes > 1024:
                    raw = val.encode("utf-8")
                    head_end = HALF
                    nl = raw.find(b'\n', head_end)
                    if nl != -1 and nl < head_end + 128:
                        head_end = nl
                    tail_start = len(raw) - HALF
                    nl = raw.rfind(b'\n', tail_start, len(raw))
                    if nl != -1 and nl > tail_start - 128:
                        tail_start = nl + 1
                    head_t = raw[:head_end].decode("utf-8", errors="replace")
                    tail_t = raw[tail_start:].decode("utf-8", errors="replace")
                    return (
                        head_t +
                        f"\n... [截断 {vbytes}B→{len(head_t.encode('utf-8')) + len(tail_t.encode('utf-8'))}B] ...\n" +
                        tail_t,
                        1
                    )
                return (val, 0)
            elif isinstance(val, dict):
                new_d = {}
                total_trunc = 0
                for k, v in val.items():
                    cv, ct = _compress_value(v, f"{path}.{k}" if path else k)
                    new_d[k] = cv
                    total_trunc += ct
                return (new_d, total_trunc)
            elif isinstance(val, list):
                new_l = []
                total_trunc = 0
                for i, v in enumerate(val):
                    cv, ct = _compress_value(v, f"{path}[{i}]")
                    new_l.append(cv)
                    total_trunc += ct
                return (new_l, total_trunc)
            else:
                return (val, 0)
        
        compressed_obj, truncated = _compress_value(obj)
        
        if truncated == 0:
            return args_str
        
        result = _json.dumps(compressed_obj, ensure_ascii=False)
        return result

    @staticmethod
    def _guess_tool_threshold(tool_name: str, arguments: str) -> int:
        """
        根据工具名称和参数推断合适的输出截断阈值。

        Args:
            tool_name (str): Description.
            arguments (str): Description.

        Returns:
            int: Description.
        """
        import json as _json_gt
        
        if tool_name == 'toolkit_kb':
            return BaseChatSession._KB_THRESHOLD
        
        try:
            args = _json_gt.loads(arguments) if isinstance(arguments, str) else (arguments or {})
        except Exception:
            return BaseChatSession._DEFAULT_TOOL_THRESHOLD
        
        if not isinstance(args, dict):
            return BaseChatSession._DEFAULT_TOOL_THRESHOLD
        
        filepath = None
        for key in ('filename', 'path', 'file', 'file_path', 'target'):
            val = args.get(key, '')
            if isinstance(val, str) and val:
                filepath = val
                break
        
        if not filepath:
            return BaseChatSession._DEFAULT_TOOL_THRESHOLD
        
        ext = os.path.splitext(filepath)[1].lower()
        basename = os.path.basename(filepath).lower()
        
        if ext in BaseChatSession._SOURCE_EXTENSIONS:
            return sys.maxsize
        if ext in BaseChatSession._TEXT_EXTENSIONS:
            return BaseChatSession._TEXT_FILE_THRESHOLD
        if basename in ('makefile', 'dockerfile', 'license', 'changelog', 'readme', 'authors'):
            return BaseChatSession._TEXT_FILE_THRESHOLD
        
        return BaseChatSession._DEFAULT_TOOL_THRESHOLD

    @staticmethod
    def _compress_tool_rounds(rounds: List[Dict]) -> List[Dict]:
        """
        对 rounds 中的工具调用链进行 L1 智能压缩。

        Args:
            rounds (List[Dict]): Description.

        Returns:
            List[Dict]: Description.
        """
        if not rounds:
            return rounds

        import json as _json_cr

        tc_map: Dict[str, tuple] = {}
        for rd in rounds:
            if rd.get("role") == "assistant" and rd.get("tool_calls"):
                for tc in rd["tool_calls"]:
                    tc_id = tc.get("id", "")
                    func = tc.get("function", {})
                    if tc_id and isinstance(func, dict):
                        tc_map[tc_id] = (
                            func.get("name", ""),
                            func.get("arguments", "")
                        )

        n = len(rounds)
        result = []

        for i, rd in enumerate(rounds):
            role = rd.get("role", "")
            is_last = (i == n - 1)

            if role == "user":
                result.append(dict(rd))

            elif role == "assistant":
                if rd.get("tool_calls") and not is_last:
                    compressed = dict(rd)
                    tc_list = compressed.get("tool_calls", [])
                    new_tc = []
                    for tc in tc_list:
                        tc_copy = dict(tc)
                        func = tc_copy.get("function", {})
                        if isinstance(func, dict):
                            args_str = func.get("arguments", "")
                            if isinstance(args_str, str):
                                args_bytes = len(args_str.encode("utf-8"))
                                if args_bytes > 2048:
                                    func["arguments"] = BaseChatSession._compress_json_args(
                                        args_str, args_bytes
                                    )
                            tc_copy["function"] = func
                        new_tc.append(tc_copy)
                    compressed["tool_calls"] = new_tc
                    result.append(compressed)
                else:
                    result.append(dict(rd))

            elif role == "tool":
                compressed = dict(rd)
                tc_id = rd.get("tool_call_id", "")
                tool_name, args_str = tc_map.get(tc_id, ("", ""))
                threshold = BaseChatSession._guess_tool_threshold(tool_name, args_str)
                compressed["content"] = BaseChatSession._compress_tool_content(
                    rd.get("content", ""), max_chars=threshold
                )
                result.append(compressed)

            else:
                result.append(dict(rd))

        return result

    @staticmethod
    def _repair_incomplete_tool_chains(rounds: List[Dict]) -> List[Dict]:
        """
        修复中断导致的不完整工具调用链。

        规则：
          - 每个带有 tool_calls 的 assistant 消息，其后必须有对应的 tool 消息
            回应每一个 tool_call_id，否则该 assistant 及其后续消息被截断。
          - 孤立的 tool 消息（无对应 assistant tool_calls）也被移除。

        Args:
            rounds: 原始 rounds 列表（可能包含不完整链）

        Returns:
            修复后的 rounds 列表
        """
        if not rounds:
            return rounds

        result: List[Dict] = []
        pending: Dict[str, int] = {}
        last_safe_len = 0

        for i, rd in enumerate(rounds):
            role = rd.get("role", "")

            if role == "assistant" and rd.get("tool_calls"):
                if pending:
                    result = result[:last_safe_len]
                    pending.clear()

                tc_list = rd["tool_calls"]
                if isinstance(tc_list, list):
                    tc_ids = [tc.get("id", "") for tc in tc_list if tc.get("id")]
                else:
                    tc_ids = []

                if not tc_ids:
                    result.append(dict(rd))
                    last_safe_len = len(result)
                    continue

                start_idx = len(result)
                result.append(dict(rd))
                for tid in tc_ids:
                    pending[tid] = start_idx

            elif role == "tool":
                tid = rd.get("tool_call_id", "")
                if tid and tid in pending:
                    result.append(dict(rd))
                    del pending[tid]
                    if not pending:
                        last_safe_len = len(result)
                else:
                    logger.debug(f"_repair: 跳过孤立 tool 消息 tool_call_id={tid}")
                    continue

            elif role == "assistant":
                if pending:
                    result = result[:last_safe_len]
                    pending.clear()
                result.append(dict(rd))
                last_safe_len = len(result)

            else:
                result.append(dict(rd))

        if pending:
            result = result[:last_safe_len]
            logger.warning(
                f"_repair: 截断不完整工具调用链，移除 {len(pending)} 个未匹配的 tool_call_id: "
                f"{list(pending.keys())}"
            )

        BaseChatSession._strip_reasoning_content(result)

        return result

    def load_history(self, conversations: List[Dict], summary: str = "", recent_turns: int = 10):
        """
        纯数据加载：将所有 conversations 加载到 self.messages，不做任何过滤/分级。

        2026-05-23 gen by Tea Agent, 职责分离：
        - 本函数只做纯数据加载，不区分 L1/L2/L3，不对 conversation 做差异化处理
        - L2/L3 数据（level2, semantic_summary, tool_chain_summary）由调用方直接设置到 session 属性
        - L1/L2/L3 的分级筛选完全由 OnlineToolSession._build_api_messages() 负责

        Args:
            conversations: 对话记录列表（时间正序），每条含 user_msg, ai_msg,
                           rounds_json_parsed, is_func_calling 等
            summary: 兼容旧字段的摘要（存入 _history_summary）
            recent_turns: 兼容旧参数（不再强制使用）
        """
        self.messages = [{"role": "system", "content": self.system_prompt}]
        self._history_summary = summary or ""

        total = len(conversations)
        if total == 0:
            logger.info("加载历史 0条 (新主题)")
            return

        for conv in conversations:
            raw_user_msg = conv["user_msg"]
            user_entry = {"role": "user"}
            if isinstance(raw_user_msg, str) and raw_user_msg.startswith('{'):
                try:
                    import json as _json_lh
                    parsed = _json_lh.loads(raw_user_msg)
                    if isinstance(parsed, dict):
                        user_entry["content"] = parsed.get("text", "")
                        imgs = parsed.get("images", [])
                        if imgs:
                            user_entry["images"] = imgs
                    else:
                        user_entry["content"] = raw_user_msg
                except Exception:
                    user_entry["content"] = raw_user_msg
            else:
                user_entry["content"] = str(raw_user_msg) if raw_user_msg else ""
            self.messages.append(user_entry)

            rounds = conv.get("rounds_json_parsed")
            if rounds and conv.get("is_func_calling"):
                repaired = BaseChatSession._repair_incomplete_tool_chains(rounds)
                compressed = BaseChatSession._compress_tool_rounds(repaired)
                for rd in compressed:
                    self.messages.append(rd)
            else:
                self.messages.append({"role": "assistant", "content": conv.get("ai_msg", "")})

        logger.info(f"加载历史: {total}轮对话, 共{len(self.messages)-1}条消息 (L1/L2/L3分级由_build_api_messages负责)")
    def interrupt(self):
        """打断当前生成"""
        self.interrupted = True

    def reset_interrupt(self):
        """重置打断标志"""
        self.interrupted = False

    def _trim_messages(self):
        """[DISABLED: 2026-05-20] no references — trimming now via L3 summary"""
        pass
