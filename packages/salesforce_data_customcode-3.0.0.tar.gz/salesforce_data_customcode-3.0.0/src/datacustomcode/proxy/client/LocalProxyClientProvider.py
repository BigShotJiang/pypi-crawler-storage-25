# Copyright (c) 2025, Salesforce, Inc.
# SPDX-License-Identifier: Apache-2
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from __future__ import annotations

from datacustomcode.proxy.client.base import BaseProxyClient


class LocalProxyClientProvider(BaseProxyClient):
    """Default proxy client provider."""

    CONFIG_NAME = "LocalProxyClientProvider"

    def __init__(self, **kwargs: object) -> None:
        pass

    def call_llm_gateway(self, llmModelId: str, prompt: str, maxTokens: int) -> str:
        return f"Hello, thanks for using {llmModelId}. So many tokens: {maxTokens}"

    def llm_gateway_generate_text(
        self, template, values, llmModelId: str, maxTokens: int
    ):
        return f"Using Generate Text with {llmModelId} and maxTokens: {maxTokens}"
