from __future__ import annotations

from collections.abc import Iterable
from typing import TypeVar

from wexample_helpers.decorator.base_class import base_class
from wexample_helpers.helpers.retryable_callback_manager import (
    RetryableCallbackManager,
)

T = TypeVar("T")


@base_class
class GitRetryableCallbackManager(RetryableCallbackManager):
    transient_markers: Iterable[str] | None = None

    def __attrs_post_init__(self) -> None:
        if self.transient_markers is None:
            self.transient_markers = self._get_transient_markers()
        if self.should_retry_callback is None:
            self.should_retry_callback = self._should_retry_git

    def _get_transient_markers(self) -> list[str]:
        return [
            "internal api error",
            "pre_receive endpoint",
            "http 500",
            "http 502",
            "http 503",
            "http 504",
            "service unavailable",
            "gateway timeout",
            "connection reset",
            "connection timed out",
            "temporary failure",
            "rpc failed",
        ]

    def _should_retry_git(
        self,
        exc: Exception,
        message: str,
        attempt: int,
        max_attempts: int,
    ) -> bool:
        if not message:
            return False
        lower = message.lower()
        markers = [marker.lower() for marker in (self.transient_markers or [])]
        return any(marker in lower for marker in markers)
