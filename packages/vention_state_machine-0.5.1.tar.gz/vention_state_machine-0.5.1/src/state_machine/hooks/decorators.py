"""Hook-authoring decorators.

The eight decorators record into the module-level `HookRegistry` at import
time and don't validate the handler's shape, async-ness, or target existence.
Failures surface out of `load_hooks(...)`:

- **Validate-time:** unknown states/triggers, async guards, sync background
  tasks, and bad signatures are collected by `validate_registry` and raised
  together as `HookValidationError`.
- **Decorator-time, fail-fast:** a duplicate `(decorator, target)` registration
  raises `DuplicateHookError` on the second import — not aggregated, because
  it fires before validation runs.

**Async dispatch (read this once, applies everywhere):**

- State-entry / state-exit hooks may be sync or async. Async handlers are
  scheduled on the running event loop via `machine.spawn(...)` and do not
  block the transition. If no event loop is running, the coroutine is closed
  and a warning is logged.
- `@on_runtime_start` is awaited if async.
- `@register_background_task` must be `async def` and is scheduled on the
  loop; sync functions are rejected at boot.
- Guard hooks are sync only — pytransitions doesn't await condition callables.

See `state_machine.hooks.registry.HookRegistry` for the registration model.
"""

from __future__ import annotations

import inspect
from typing import Callable, TypeVar, Union

from state_machine.hooks.registry import HookRegistration, get_registry
from state_machine.utils import resolve_state_name, resolve_trigger_name

HookFunction = TypeVar("HookFunction", bound=Callable[..., object])
TargetNode = TypeVar("TargetNode")


def _build_registration(
    decorator_name: str,
    target: Union[str, None],
    hook_function: Callable[..., object],
) -> HookRegistration:
    return HookRegistration(
        decorator=decorator_name,
        target=target,
        handler=hook_function,
        is_async=inspect.iscoroutinefunction(hook_function),
        module=getattr(hook_function, "__module__", "<unknown>"),
        qualname=getattr(hook_function, "__qualname__", getattr(hook_function, "__name__", "<unknown>")),
    )


def _make_target_decorator(
    decorator_name: str,
    resolve_target: Callable[[TargetNode], str],
    docstring: str,
) -> Callable[[TargetNode], Callable[[HookFunction], HookFunction]]:
    def factory(target_node: TargetNode) -> Callable[[HookFunction], HookFunction]:
        target_name = resolve_target(target_node)

        def decorator(hook_function: HookFunction) -> HookFunction:
            registration = _build_registration(decorator_name, target_name, hook_function)
            get_registry().add_target_hook(registration)
            return hook_function

        return decorator

    factory.__doc__ = docstring
    return factory


replace_guard = _make_target_decorator(
    "replace_guard",
    resolve_trigger_name,
    """Run the hook instead of every class-level `@guard` for `trigger`.

    Sync only — async guards are rejected at boot because pytransitions does not
    await condition callables. Handler must return `bool`.""",
)
add_guard = _make_target_decorator(
    "add_guard",
    resolve_trigger_name,
    """Compose the hook with class-level `@guard`s for `trigger`.

    Class-level guards run first; if all pass, the hook runs. All must return
    `True` for the transition to fire. Sync only — async guards are rejected at
    boot.""",
)
replace_on_enter_state = _make_target_decorator(
    "replace_on_enter_state",
    resolve_state_name,
    """Run the hook instead of the class-level `@on_enter_state` binding for `state`.

    Sync or async; see the module docstring for async dispatch semantics.""",
)
add_on_enter_state = _make_target_decorator(
    "add_on_enter_state",
    resolve_state_name,
    """Run the hook before the class-level `@on_enter_state` binding for `state`.

    Sync or async; see the module docstring for async dispatch semantics.""",
)
replace_on_exit_state = _make_target_decorator(
    "replace_on_exit_state",
    resolve_state_name,
    """Run the hook instead of the class-level `@on_exit_state` binding for `state`.

    Sync or async; see the module docstring for async dispatch semantics.""",
)
add_on_exit_state = _make_target_decorator(
    "add_on_exit_state",
    resolve_state_name,
    """Run the hook before the class-level `@on_exit_state` binding for `state`.

    Sync or async; see the module docstring for async dispatch semantics.""",
)


def on_runtime_start(hook_function: HookFunction) -> HookFunction:
    """Run `hook_function` on `state_machine.start()` in registration order.

    Sync or async (awaited if async). Multiple handlers may register; each runs
    in turn before the initial state transition fires. Any failure aborts
    startup and propagates from `start()`.
    """
    registration = _build_registration("on_runtime_start", None, hook_function)
    get_registry().add_runtime_start(registration)
    return hook_function


def register_background_task(hook_function: HookFunction) -> HookFunction:
    """Schedule `hook_function` as a background task on the runtime loop.

    Runs after `@on_runtime_start` handlers complete. Must be `async def`; sync
    functions are rejected at boot. Cancelled only by `stop_background_tasks()`
    — background tasks survive `to_fault` so MQTT subscribers, telemetry
    loggers, and tower-light renderers keep running to observe and report the
    fault. Unhandled exceptions are logged and the machine continues.
    """
    registration = _build_registration("register_background_task", None, hook_function)
    get_registry().add_background_task(registration)
    return hook_function
