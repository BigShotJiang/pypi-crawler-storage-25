from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, TypeVar

if TYPE_CHECKING:
    from state_machine.core import StateMachine


@dataclass(frozen=True)
class HookContext:
    """Argument passed to every hook handler.

    Consumers extend this with a frozen subclass that adds their integration
    root (services, config, model accessors, runtime helpers). The extended
    type is wired in via `load_hooks(..., context_factory=...)`; the library
    itself only knows about the base type.

    A fresh context is built per hook invocation so handlers see consistent
    live state. The factory typically closes over a shared `app` instance the
    consumer constructs once at startup.
    """

    state_machine: StateMachine


HookContextT = TypeVar("HookContextT", bound=HookContext)


def build_context(machine: "StateMachine") -> HookContext:
    base = HookContext(state_machine=machine)
    factory = machine._context_factory
    return factory(base) if factory is not None else base
