"""Tests for `@on_runtime_start` and `@register_background_task` dispatch.

Covers the contract from the design doc + ticket MA-2082:
- `@on_runtime_start` handlers run in registration order on `start()`, sync/async,
  awaited if async, failure aborts startup and cancels anything scheduled in the
  same `start()` call.
- `@register_background_task` coroutines run after `@on_runtime_start` completes,
  are cancelled by `stop_background_tasks()`, survive `to_fault`, and exceptions
  are logged without bringing down the machine.
"""

import asyncio
import logging
import sys
import tempfile
import unittest
from pathlib import Path
from typing import Any, List

from state_machine.core import StateMachine
from state_machine.hooks import get_registry
from state_machine_tests.test_load_hooks import reset_handlers_imports, write_handlers_package


class LifecycleTestMachine(StateMachine):
    def __init__(self, **kw: Any) -> None:
        super().__init__(
            states=[{"name": "working"}, {"name": "idle"}],
            transitions=[
                {"trigger": "start", "source": "ready", "dest": "working"},
                {"trigger": "stop", "source": "working", "dest": "idle"},
                {"trigger": "again", "source": "idle", "dest": "ready"},
                {"trigger": "recover__idle", "source": "ready", "dest": "idle"},
            ],
            **kw,
        )
        self.calls: List[Any] = []


class LifecycleHooksTestBase(unittest.IsolatedAsyncioTestCase):
    def setUp(self) -> None:
        get_registry().clear()
        reset_handlers_imports()
        self._tempdir = tempfile.TemporaryDirectory()
        self.addCleanup(self._tempdir.cleanup)
        self.tmp_path: Path = Path(self._tempdir.name)

    def tearDown(self) -> None:
        if str(self.tmp_path) in sys.path:
            sys.path.remove(str(self.tmp_path))
        reset_handlers_imports()
        get_registry().clear()


class TestRuntimeStartRegistrationOrder(LifecycleHooksTestBase):
    async def test_handlers_run_in_registration_order(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "h.py": """
                from state_machine.hooks import on_runtime_start

                @on_runtime_start
                def first(context):
                    context.state_machine.calls.append("first")

                @on_runtime_start
                def second(context):
                    context.state_machine.calls.append("second")

                @on_runtime_start
                def third(context):
                    context.state_machine.calls.append("third")
                """,
            },
        )
        machine = LifecycleTestMachine()
        machine.load_hooks(self.tmp_path)
        await machine.start()
        self.assertEqual(machine.calls[:3], ["first", "second", "third"])


class TestRuntimeStartAsyncAwaited(LifecycleHooksTestBase):
    async def test_async_handler_completes_before_next_runs(self) -> None:
        # Fire-and-forget dispatch would put "sync" before "async" because the
        # sync handler doesn't yield to the loop. Awaiting in order keeps them
        # in source order even when the async one yields.
        write_handlers_package(
            self.tmp_path,
            files={
                "h.py": """
                import asyncio
                from state_machine.hooks import on_runtime_start

                @on_runtime_start
                async def first_async(context):
                    await asyncio.sleep(0.05)
                    context.state_machine.calls.append("async")

                @on_runtime_start
                def second_sync(context):
                    context.state_machine.calls.append("sync")
                """,
            },
        )
        machine = LifecycleTestMachine()
        machine.load_hooks(self.tmp_path)
        await machine.start()
        self.assertEqual(machine.calls[:2], ["async", "sync"])


class TestRuntimeStartSyncAsyncMix(LifecycleHooksTestBase):
    async def test_sync_and_async_handlers_both_execute(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "h.py": """
                from state_machine.hooks import on_runtime_start

                @on_runtime_start
                def sync_handler(context):
                    context.state_machine.calls.append("sync")

                @on_runtime_start
                async def async_handler(context):
                    context.state_machine.calls.append("async")
                """,
            },
        )
        machine = LifecycleTestMachine()
        machine.load_hooks(self.tmp_path)
        await machine.start()
        self.assertIn("sync", machine.calls)
        self.assertIn("async", machine.calls)


class TestRuntimeStartFailureAborts(LifecycleHooksTestBase):
    async def test_handler_exception_propagates_from_start(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "h.py": """
                from state_machine.hooks import on_runtime_start

                @on_runtime_start
                def boom(context):
                    raise RuntimeError("boom from runtime start")
                """,
            },
        )
        machine = LifecycleTestMachine()
        machine.load_hooks(self.tmp_path)
        with self.assertRaises(RuntimeError) as exc:
            await machine.start()
        self.assertIn("boom from runtime start", str(exc.exception))
        self.assertEqual(machine.state, "ready")


class TestRuntimeStartFailureCancelsLaterHandlersAndBgTasks(LifecycleHooksTestBase):
    async def test_subsequent_handlers_and_bg_tasks_do_not_run(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "h.py": """
                from state_machine.hooks import on_runtime_start, register_background_task

                @on_runtime_start
                def failing(context):
                    context.state_machine.calls.append("failing_ran")
                    raise RuntimeError("abort")

                @on_runtime_start
                def never_runs(context):
                    context.state_machine.calls.append("should_not_appear")

                @register_background_task
                async def never_scheduled(context):
                    context.state_machine.calls.append("bg_should_not_appear")
                """,
            },
        )
        machine = LifecycleTestMachine()
        machine.load_hooks(self.tmp_path)
        with self.assertRaises(RuntimeError):
            await machine.start()
        await asyncio.sleep(0.05)
        self.assertIn("failing_ran", machine.calls)
        self.assertNotIn("should_not_appear", machine.calls)
        self.assertNotIn("bg_should_not_appear", machine.calls)
        self.assertEqual(len(machine._lifecycle_background_tasks), 0)


class TestBgTasksScheduledAfterRuntimeStart(LifecycleHooksTestBase):
    async def test_bg_task_runs_only_after_runtime_start_completes(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "h.py": """
                import asyncio
                from state_machine.hooks import on_runtime_start, register_background_task

                @on_runtime_start
                async def slow_runtime(context):
                    await asyncio.sleep(0.05)
                    context.state_machine.calls.append("runtime_done")

                @register_background_task
                async def bg(context):
                    context.state_machine.calls.append("bg_started")
                """,
            },
        )
        machine = LifecycleTestMachine()
        machine.load_hooks(self.tmp_path)
        await machine.start()
        await asyncio.sleep(0.05)
        self.assertEqual(
            machine.calls.index("runtime_done"),
            0,
            f"runtime_done should be first, got {machine.calls}",
        )
        self.assertIn("bg_started", machine.calls)
        self.assertLess(machine.calls.index("runtime_done"), machine.calls.index("bg_started"))


class TestBackgroundTaskRuns(LifecycleHooksTestBase):
    async def test_bg_task_actually_executes(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "h.py": """
                from state_machine.hooks import register_background_task

                @register_background_task
                async def task(context):
                    context.state_machine.bg_event.set()
                """,
            },
        )
        machine = LifecycleTestMachine()
        machine.bg_event = asyncio.Event()
        machine.load_hooks(self.tmp_path)
        await machine.start()
        await asyncio.wait_for(machine.bg_event.wait(), timeout=1.0)


class TestStopBackgroundTasksCancelsRunningBgTasks(LifecycleHooksTestBase):
    async def test_stop_background_tasks_cancels_running_bg_task(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "h.py": """
                import asyncio
                from state_machine.hooks import register_background_task

                @register_background_task
                async def long_runner(context):
                    await asyncio.sleep(10)
                """,
            },
        )
        machine = LifecycleTestMachine()
        machine.load_hooks(self.tmp_path)
        await machine.start()
        self.assertEqual(len(machine._lifecycle_background_tasks), 1)
        task = next(iter(machine._lifecycle_background_tasks))

        await machine.stop_background_tasks()

        self.assertTrue(task.cancelled())


class TestBackgroundTaskExceptionLogged(LifecycleHooksTestBase):
    async def test_bg_task_exception_logged_machine_continues(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "h.py": """
                from state_machine.hooks import register_background_task

                @register_background_task
                async def crash(context):
                    raise RuntimeError("background boom")
                """,
            },
        )
        machine = LifecycleTestMachine()
        machine.load_hooks(self.tmp_path)
        with self.assertLogs("state_machine.hooks.lifecycle", level=logging.ERROR) as cap:
            await machine.start()
            for _ in range(5):
                await asyncio.sleep(0)
        joined = "\n".join(cap.output)
        self.assertIn("background boom", joined)
        self.assertIn("the state machine continues", joined)
        self.assertEqual(machine.state, "working")


class TestToFaultDoesNotCancelBgTasks(LifecycleHooksTestBase):
    async def test_bg_task_survives_to_fault(self) -> None:
        # Encodes the palletizer convention: MQTT subscribers, telemetry
        # loggers, and tower-light renderers must keep running through fault
        # so the fault state itself can be observed and reported.
        write_handlers_package(
            self.tmp_path,
            files={
                "h.py": """
                import asyncio
                from state_machine.hooks import register_background_task

                @register_background_task
                async def long_runner(context):
                    await asyncio.sleep(10)
                """,
            },
        )
        machine = LifecycleTestMachine()
        machine.load_hooks(self.tmp_path)
        await machine.start()
        task = next(iter(machine._lifecycle_background_tasks))

        machine.trigger("to_fault")
        await asyncio.sleep(0)

        self.assertFalse(task.cancelled(), "Background task should survive to_fault")
        self.assertFalse(task.done(), "Background task should still be running")
        await machine.stop_background_tasks()


class TestStopBackgroundTasksSafeBeforeStart(LifecycleHooksTestBase):
    async def test_stop_background_tasks_on_fresh_machine_is_noop(self) -> None:
        machine = LifecycleTestMachine()
        await machine.stop_background_tasks()  # must not raise
        self.assertEqual(len(machine._lifecycle_background_tasks), 0)


class TestStopTriggerDoesNotCollide(LifecycleHooksTestBase):
    async def test_machine_with_stop_trigger_fires_transition(self) -> None:
        # Regression: the library used to expose `stop()` as the lifecycle
        # cancellation method, which shadowed any `"stop"` trigger bound by
        # pytransitions. The cancellation method is `stop_background_tasks()`
        # now, so `machine.stop()` falls through to the trigger as expected.
        machine = LifecycleTestMachine()
        await machine.start()
        self.assertEqual(machine.state, "working")
        machine.stop()
        self.assertEqual(machine.state, "idle")


class TestStartWorksWithoutLoadHooks(LifecycleHooksTestBase):
    async def test_start_without_hooks_behaves_like_legacy(self) -> None:
        machine = LifecycleTestMachine()
        await machine.start()
        self.assertEqual(machine.state, "working")
        self.assertEqual(len(machine._lifecycle_background_tasks), 0)


class TestStartWithRecovery(LifecycleHooksTestBase):
    async def test_start_recovers_to_last_state(self) -> None:
        machine = LifecycleTestMachine()
        machine._enable_recovery = True
        machine._last_state = "idle"
        await machine.start()
        self.assertEqual(machine.state, "idle")


class TestRegistryHandlersIgnoredWithoutLoadHooks(LifecycleHooksTestBase):
    async def test_decorated_handlers_without_load_hooks_do_not_run(self) -> None:
        from state_machine.hooks import on_runtime_start, register_background_task

        ran = {"runtime": False, "bg": False}

        @on_runtime_start
        def runtime(context):  # type: ignore[no-untyped-def]
            ran["runtime"] = True

        @register_background_task
        async def bg(context):  # type: ignore[no-untyped-def]
            ran["bg"] = True

        self.assertEqual(len(get_registry().runtime_start_handlers), 1)
        self.assertEqual(len(get_registry().background_tasks), 1)

        machine = LifecycleTestMachine()
        await machine.start()
        await asyncio.sleep(0.05)

        self.assertFalse(ran["runtime"])
        self.assertFalse(ran["bg"])


class TestMultipleBgTasksAllScheduled(LifecycleHooksTestBase):
    async def test_two_bg_tasks_both_run(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "h.py": """
                from state_machine.hooks import register_background_task

                @register_background_task
                async def a(context):
                    context.state_machine.calls.append("a")

                @register_background_task
                async def b(context):
                    context.state_machine.calls.append("b")
                """,
            },
        )
        machine = LifecycleTestMachine()
        machine.load_hooks(self.tmp_path)
        await machine.start()
        await asyncio.sleep(0.05)
        self.assertIn("a", machine.calls)
        self.assertIn("b", machine.calls)


class TestRuntimeStartRunsBeforeStateTransition(LifecycleHooksTestBase):
    async def test_handler_sees_machine_still_in_ready(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "h.py": """
                from state_machine.hooks import on_runtime_start

                @on_runtime_start
                def assert_ready(context):
                    context.state_machine.calls.append(("state_when_runtime_start", context.state_machine.state))
                """,
            },
        )
        machine = LifecycleTestMachine()
        machine.load_hooks(self.tmp_path)
        await machine.start()
        observations = [c for c in machine.calls if isinstance(c, tuple) and c[0] == "state_when_runtime_start"]
        self.assertEqual(observations, [("state_when_runtime_start", "ready")])
        self.assertEqual(machine.state, "working")


if __name__ == "__main__":
    unittest.main()
