import unittest
from typing import Any

from state_machine.core import StateMachine
from state_machine.hooks import HookValidationError, get_registry
from state_machine_tests.test_load_hooks import (
    HookTestMachine,
    LoadHooksTestBase,
    write_handlers_package,
)


class HierarchicalHookTestMachine(StateMachine):
    def __init__(self, **kw: Any) -> None:
        super().__init__(
            states=[
                {
                    "name": "running",
                    "children": [{"name": "picking"}, {"name": "placing"}],
                },
                {"name": "idle"},
            ],
            transitions=[
                {"trigger": "start_run", "source": "ready", "dest": "running_picking"},
                {"trigger": "next", "source": "running_picking", "dest": "running_placing"},
                {"trigger": "stop", "source": "running_placing", "dest": "idle"},
                {"trigger": "go_again", "source": "idle", "dest": "ready"},
            ],
            **kw,
        )


class TestTargetExistence(LoadHooksTestBase):
    def test_unknown_state_in_add_on_enter_raises(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "bad_state.py": """
                    from state_machine.hooks import add_on_enter_state

                    @add_on_enter_state("notastate")
                    def handler(context):
                        return None
                """
            },
        )
        machine = HookTestMachine()
        with self.assertRaises(HookValidationError) as cm:
            machine.load_hooks(self.tmp_path)
        message = str(cm.exception)
        self.assertIn("unknown state 'notastate'", message)
        self.assertIn("handlers.bad_state.handler", message)
        self.assertIn("@add_on_enter_state", message)

    def test_unknown_state_in_replace_on_exit_raises(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "bad_state.py": """
                    from state_machine.hooks import replace_on_exit_state

                    @replace_on_exit_state("typo")
                    def handler(context):
                        return None
                """
            },
        )
        machine = HookTestMachine()
        with self.assertRaises(HookValidationError) as cm:
            machine.load_hooks(self.tmp_path)
        self.assertIn("unknown state 'typo'", str(cm.exception))

    def test_unknown_trigger_in_add_guard_raises(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "bad_trigger.py": """
                    from state_machine.hooks import add_guard

                    @add_guard("notatrigger")
                    def handler(context):
                        return True
                """
            },
        )
        machine = HookTestMachine()
        with self.assertRaises(HookValidationError) as cm:
            machine.load_hooks(self.tmp_path)
        message = str(cm.exception)
        self.assertIn("unknown trigger 'notatrigger'", message)
        self.assertIn("@add_guard", message)

    def test_unknown_trigger_in_replace_guard_raises(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "bad_trigger.py": """
                    from state_machine.hooks import replace_guard

                    @replace_guard("nope")
                    def handler(context):
                        return True
                """
            },
        )
        machine = HookTestMachine()
        with self.assertRaises(HookValidationError) as cm:
            machine.load_hooks(self.tmp_path)
        self.assertIn("unknown trigger 'nope'", str(cm.exception))

    def test_error_lists_known_states_for_unknown_state(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "bad.py": """
                    from state_machine.hooks import add_on_enter_state

                    @add_on_enter_state("typo")
                    def handler(context):
                        return None
                """
            },
        )
        machine = HookTestMachine()
        with self.assertRaises(HookValidationError) as cm:
            machine.load_hooks(self.tmp_path)
        message = str(cm.exception)
        for state in ("fault", "idle", "ready", "working"):
            self.assertIn(state, message)

    def test_error_lists_known_triggers_for_unknown_trigger(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "bad.py": """
                    from state_machine.hooks import add_guard

                    @add_guard("typo")
                    def handler(context):
                        return True
                """
            },
        )
        machine = HookTestMachine()
        with self.assertRaises(HookValidationError) as cm:
            machine.load_hooks(self.tmp_path)
        message = str(cm.exception)
        for trigger in ("begin", "stop", "again"):
            self.assertIn(trigger, message)


class TestAsyncShape(LoadHooksTestBase):
    def test_async_add_guard_raises(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "async_guard.py": """
                    from state_machine.hooks import add_guard

                    @add_guard("again")
                    async def handler(context):
                        return True
                """
            },
        )
        machine = HookTestMachine()
        with self.assertRaises(HookValidationError) as cm:
            machine.load_hooks(self.tmp_path)
        message = str(cm.exception)
        self.assertIn("must be sync", message)
        self.assertIn("@add_guard", message)
        self.assertIn("handlers.async_guard.handler", message)

    def test_async_replace_guard_raises(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "async_guard.py": """
                    from state_machine.hooks import replace_guard

                    @replace_guard("again")
                    async def handler(context):
                        return True
                """
            },
        )
        machine = HookTestMachine()
        with self.assertRaises(HookValidationError) as cm:
            machine.load_hooks(self.tmp_path)
        self.assertIn("must be sync", str(cm.exception))
        self.assertIn("@replace_guard", str(cm.exception))

    def test_sync_register_background_task_raises(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "bad_task.py": """
                    from state_machine.hooks import register_background_task

                    @register_background_task
                    def handler(context):
                        return None
                """
            },
        )
        machine = HookTestMachine()
        with self.assertRaises(HookValidationError) as cm:
            machine.load_hooks(self.tmp_path)
        message = str(cm.exception)
        self.assertIn("must be a coroutine function", message)
        self.assertIn("@register_background_task", message)
        self.assertIn("async def", message)

    def test_async_state_hooks_are_allowed(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "async_state.py": """
                    from state_machine.hooks import add_on_enter_state

                    @add_on_enter_state("working")
                    async def handler(context):
                        return None
                """
            },
        )
        machine = HookTestMachine()
        machine.load_hooks(self.tmp_path)
        self.assertEqual(len(get_registry().target_hooks), 1)


class TestSignatureAcceptsContext(LoadHooksTestBase):
    def test_handler_with_no_arguments_raises(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "bad_sig.py": """
                    from state_machine.hooks import add_on_enter_state

                    @add_on_enter_state("working")
                    def handler():
                        return None
                """
            },
        )
        machine = HookTestMachine()
        with self.assertRaises(HookValidationError) as cm:
            machine.load_hooks(self.tmp_path)
        self.assertIn("does not accept the hook context argument", str(cm.exception))

    def test_handler_with_two_required_arguments_raises(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "bad_sig.py": """
                    from state_machine.hooks import add_on_enter_state

                    @add_on_enter_state("working")
                    def handler(context, extra):
                        return None
                """
            },
        )
        machine = HookTestMachine()
        with self.assertRaises(HookValidationError) as cm:
            machine.load_hooks(self.tmp_path)
        self.assertIn("does not accept the hook context argument", str(cm.exception))

    def test_handler_with_keyword_only_context_raises(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "bad_sig.py": """
                    from state_machine.hooks import add_on_enter_state

                    @add_on_enter_state("working")
                    def handler(*, context):
                        return None
                """
            },
        )
        machine = HookTestMachine()
        with self.assertRaises(HookValidationError) as cm:
            machine.load_hooks(self.tmp_path)
        self.assertIn("does not accept the hook context argument", str(cm.exception))

    def test_handler_with_one_positional_argument_is_valid(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "good_sig.py": """
                    from state_machine.hooks import add_on_enter_state

                    @add_on_enter_state("working")
                    def handler(context):
                        return None
                """
            },
        )
        machine = HookTestMachine()
        machine.load_hooks(self.tmp_path)
        self.assertEqual(len(get_registry().target_hooks), 1)

    def test_handler_with_var_positional_argument_is_valid(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "good_sig.py": """
                    from state_machine.hooks import add_on_enter_state

                    @add_on_enter_state("working")
                    def handler(*args):
                        return None
                """
            },
        )
        machine = HookTestMachine()
        machine.load_hooks(self.tmp_path)
        self.assertEqual(len(get_registry().target_hooks), 1)

    def test_handler_with_default_context_is_valid(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "good_sig.py": """
                    from state_machine.hooks import add_on_enter_state

                    @add_on_enter_state("working")
                    def handler(context=None):
                        return None
                """
            },
        )
        machine = HookTestMachine()
        machine.load_hooks(self.tmp_path)
        self.assertEqual(len(get_registry().target_hooks), 1)


class TestErrorAggregation(LoadHooksTestBase):
    def test_multiple_violations_listed_in_single_exception(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "bad_guard.py": """
                    from state_machine.hooks import add_guard

                    @add_guard("again")
                    async def async_guard(context):
                        return True
                """,
                "bad_state.py": """
                    from state_machine.hooks import add_on_enter_state

                    @add_on_enter_state("notastate")
                    def state_hook(context):
                        return None
                """,
                "bad_sig.py": """
                    from state_machine.hooks import on_runtime_start

                    @on_runtime_start
                    def runtime_hook():
                        return None
                """,
            },
        )
        machine = HookTestMachine()
        with self.assertRaises(HookValidationError) as cm:
            machine.load_hooks(self.tmp_path)
        message = str(cm.exception)
        self.assertEqual(len(cm.exception.errors), 3)
        self.assertIn("must be sync", message)
        self.assertIn("unknown state 'notastate'", message)
        self.assertIn("does not accept the hook context argument", message)
        self.assertIn("handlers.bad_guard.async_guard", message)
        self.assertIn("handlers.bad_state.state_hook", message)
        self.assertIn("handlers.bad_sig.runtime_hook", message)


class TestHappyPath(LoadHooksTestBase):
    def test_all_valid_hooks_register_without_error(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "all_good.py": """
                    from state_machine.hooks import (
                        add_guard,
                        add_on_enter_state,
                        on_runtime_start,
                        register_background_task,
                        replace_on_exit_state,
                    )

                    @add_on_enter_state("working")
                    def enter(context):
                        return None

                    @replace_on_exit_state("working")
                    async def exit_async(context):
                        return None

                    @add_guard("again")
                    def guard_sync(context):
                        return True

                    @on_runtime_start
                    def boot(context):
                        return None

                    @register_background_task
                    async def background(context):
                        return None
                """
            },
        )
        machine = HookTestMachine()
        machine.load_hooks(self.tmp_path)
        self.assertEqual(len(get_registry().target_hooks), 3)
        self.assertEqual(len(get_registry().runtime_start_handlers), 1)
        self.assertEqual(len(get_registry().background_tasks), 1)


class TestNestedStateTargets(LoadHooksTestBase):
    def test_nested_state_target_passes_validation(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "nested.py": """
                    from state_machine.hooks import add_on_enter_state

                    @add_on_enter_state("running_picking")
                    def handler(context):
                        return None
                """
            },
        )
        machine = HierarchicalHookTestMachine()
        machine.load_hooks(self.tmp_path)
        self.assertEqual(len(get_registry().target_hooks), 1)

    def test_nested_state_in_replace_on_exit_passes_validation(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "nested.py": """
                    from state_machine.hooks import replace_on_exit_state

                    @replace_on_exit_state("running_placing")
                    async def handler(context):
                        return None
                """
            },
        )
        machine = HierarchicalHookTestMachine()
        machine.load_hooks(self.tmp_path)
        self.assertEqual(len(get_registry().target_hooks), 1)

    def test_unknown_nested_leaf_lists_real_leaves_in_error(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "nested.py": """
                    from state_machine.hooks import add_on_enter_state

                    @add_on_enter_state("running_unknown")
                    def handler(context):
                        return None
                """
            },
        )
        machine = HierarchicalHookTestMachine()
        with self.assertRaises(HookValidationError) as cm:
            machine.load_hooks(self.tmp_path)
        message = str(cm.exception)
        self.assertIn("unknown state 'running_unknown'", message)
        for leaf in ("running_picking", "running_placing", "idle"):
            self.assertIn(leaf, message)


if __name__ == "__main__":
    unittest.main()
