"""
Sample handler module used by the self-registration test.

Importing this module must populate the hook registry as a side effect of
decorator evaluation. The module covers every decorator at least once,
mixing sync and async where applicable.
"""

from state_machine.hooks import (
    HookContext,
    add_guard,
    add_on_enter_state,
    add_on_exit_state,
    on_runtime_start,
    register_background_task,
    replace_guard,
    replace_on_enter_state,
    replace_on_exit_state,
)


@replace_guard("trigger_replace_guard")
def replace_guard_handler(context: HookContext) -> bool:
    return True


@add_guard("trigger_add_guard")
def add_guard_handler(context: HookContext) -> bool:
    return True


@replace_on_enter_state("state_replace_enter")
def replace_on_enter_handler(context: HookContext) -> None:
    return None


@add_on_enter_state("state_add_enter")
async def add_on_enter_handler(context: HookContext) -> None:
    return None


@replace_on_exit_state("state_replace_exit")
def replace_on_exit_handler(context: HookContext) -> None:
    return None


@add_on_exit_state("state_add_exit")
async def add_on_exit_handler(context: HookContext) -> None:
    return None


@on_runtime_start
def runtime_start_sync(context: HookContext) -> None:
    return None


@on_runtime_start
async def runtime_start_async(context: HookContext) -> None:
    return None


@register_background_task
async def background_task(context: HookContext) -> None:
    return None
