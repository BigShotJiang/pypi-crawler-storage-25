import unittest
from dataclasses import FrozenInstanceError

from state_machine.hooks.registry import (
    DuplicateHookError,
    HookRegistration,
    HookRegistry,
    HookTargetKey,
)


def _registration(decorator: str, target: object, name: str = "handler") -> HookRegistration:
    def handler() -> None:
        return None

    return HookRegistration(
        decorator=decorator,
        target=target if isinstance(target, str) or target is None else None,
        handler=handler,
        is_async=False,
        module="tests.module",
        qualname=name,
    )


class TestHookRegistry(unittest.TestCase):
    def test_fresh_registry_is_empty(self) -> None:
        registry = HookRegistry()
        self.assertEqual(registry.target_hooks, {})
        self.assertEqual(registry.runtime_start_handlers, ())
        self.assertEqual(registry.background_tasks, ())
        self.assertEqual(registry.all_registrations(), ())

    def test_add_and_get_target_hook(self) -> None:
        registry = HookRegistry()
        reg = _registration("add_guard", "trigger_x", "guard_x")
        registry.add_target_hook(reg)

        self.assertIs(registry.get_target_hook("add_guard", "trigger_x"), reg)
        self.assertEqual(
            registry.target_hooks,
            {HookTargetKey(decorator="add_guard", target="trigger_x"): reg},
        )

    def test_get_target_hook_returns_none_for_missing(self) -> None:
        registry = HookRegistry()
        self.assertIsNone(registry.get_target_hook("add_guard", "missing"))

    def test_duplicate_target_registration_raises(self) -> None:
        registry = HookRegistry()
        first = _registration("add_guard", "trigger_x", "first")
        second = _registration("add_guard", "trigger_x", "second")

        registry.add_target_hook(first)
        with self.assertRaises(DuplicateHookError) as exc:
            registry.add_target_hook(second)

        message = str(exc.exception)
        self.assertIn("add_guard", message)
        self.assertIn("trigger_x", message)
        self.assertIn("first", message)
        self.assertIn("second", message)

    def test_replace_and_add_coexist_for_same_target(self) -> None:
        registry = HookRegistry()
        replace_reg = _registration("replace_guard", "trigger_x", "replace_handler")
        add_reg = _registration("add_guard", "trigger_x", "add_handler")

        registry.add_target_hook(replace_reg)
        registry.add_target_hook(add_reg)

        self.assertIs(registry.get_target_hook("replace_guard", "trigger_x"), replace_reg)
        self.assertIs(registry.get_target_hook("add_guard", "trigger_x"), add_reg)

    def test_target_hook_with_none_target_raises(self) -> None:
        registry = HookRegistry()
        bad = HookRegistration(
            decorator="add_guard",
            target=None,
            handler=lambda: None,
            is_async=False,
            module="tests.module",
            qualname="bad",
        )
        with self.assertRaises(ValueError):
            registry.add_target_hook(bad)

    def test_runtime_start_handlers_preserve_order(self) -> None:
        registry = HookRegistry()
        first = _registration("on_runtime_start", None, "first")
        second = _registration("on_runtime_start", None, "second")

        registry.add_runtime_start(first)
        registry.add_runtime_start(second)

        self.assertEqual(registry.runtime_start_handlers, (first, second))

    def test_background_tasks_preserve_order(self) -> None:
        registry = HookRegistry()
        first = _registration("register_background_task", None, "first")
        second = _registration("register_background_task", None, "second")

        registry.add_background_task(first)
        registry.add_background_task(second)

        self.assertEqual(registry.background_tasks, (first, second))

    def test_target_hooks_returns_copy(self) -> None:
        registry = HookRegistry()
        registry.add_target_hook(_registration("add_guard", "trigger_x"))

        snapshot = registry.target_hooks
        snapshot.clear()

        self.assertEqual(len(registry.target_hooks), 1)

    def test_all_registrations_combines_collections(self) -> None:
        registry = HookRegistry()
        target_reg = _registration("add_guard", "trigger_x", "target")
        runtime_reg = _registration("on_runtime_start", None, "runtime")
        background_reg = _registration("register_background_task", None, "background")

        registry.add_target_hook(target_reg)
        registry.add_runtime_start(runtime_reg)
        registry.add_background_task(background_reg)

        self.assertEqual(
            set(registry.all_registrations()),
            {target_reg, runtime_reg, background_reg},
        )

    def test_clear_empties_all_collections(self) -> None:
        registry = HookRegistry()
        registry.add_target_hook(_registration("add_guard", "trigger_x"))
        registry.add_runtime_start(_registration("on_runtime_start", None))
        registry.add_background_task(_registration("register_background_task", None))

        registry.clear()

        self.assertEqual(registry.target_hooks, {})
        self.assertEqual(registry.runtime_start_handlers, ())
        self.assertEqual(registry.background_tasks, ())

    def test_all_registrations_excludes_nothing_extra(self) -> None:
        """`all_registrations` must return exactly what was registered — no extras,
        no drops. Catches future changes that accidentally omit a collection."""
        registry = HookRegistry()
        target_reg = _registration("add_guard", "trigger_x", "target")
        runtime_reg = _registration("on_runtime_start", None, "runtime")
        background_reg = _registration("register_background_task", None, "background")

        registry.add_target_hook(target_reg)
        registry.add_runtime_start(runtime_reg)
        registry.add_background_task(background_reg)

        self.assertEqual(len(registry.all_registrations()), 3)


class TestHookRegistration(unittest.TestCase):
    def test_is_frozen(self) -> None:
        """Registrations must be immutable once stored — the registry holds them by
        identity and assumes their metadata won't shift underneath it."""
        registration = _registration("add_guard", "trigger_x")
        with self.assertRaises(FrozenInstanceError):
            setattr(registration, "decorator", "different")


class TestHookTargetKey(unittest.TestCase):
    def test_equal_keys_compare_equal_and_hash_equal(self) -> None:
        """Equality and hashability are the dict-key contract; without both,
        duplicate detection silently breaks."""
        first = HookTargetKey(decorator="add_guard", target="trigger_x")
        second = HookTargetKey(decorator="add_guard", target="trigger_x")

        self.assertEqual(first, second)
        self.assertEqual(hash(first), hash(second))

    def test_different_keys_compare_unequal(self) -> None:
        decorator_differs = HookTargetKey(decorator="add_guard", target="trigger_x")
        target_differs = HookTargetKey(decorator="replace_guard", target="trigger_x")
        both_differ = HookTargetKey(decorator="replace_guard", target="trigger_y")

        self.assertNotEqual(decorator_differs, target_differs)
        self.assertNotEqual(decorator_differs, both_differ)


if __name__ == "__main__":
    unittest.main()
