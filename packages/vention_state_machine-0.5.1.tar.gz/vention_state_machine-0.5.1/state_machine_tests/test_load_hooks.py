import asyncio
import gc
import logging
import sys
import tempfile
import textwrap
import unittest
import warnings
from dataclasses import dataclass
from pathlib import Path
from typing import Any, List, Optional

from transitions.core import EventData

from state_machine.core import StateMachine
from state_machine.decorators import guard, on_enter_state, on_exit_state
from state_machine.hooks import HookContext, get_registry


def write_handlers_package(tmp_path: Path, files: dict[str, str]) -> Path:
    handlers_dir = tmp_path / "handlers"
    handlers_dir.mkdir()
    (handlers_dir / "__init__.py").write_text("")
    for filename, source in files.items():
        (handlers_dir / filename).write_text(textwrap.dedent(source))
    return tmp_path


def reset_handlers_imports() -> None:
    # Python caches imports by module name in sys.modules. Without this, a second
    # test importing a fresh `handlers` package re-uses the first test's module
    # objects and the decorators never re-fire to repopulate the cleared registry.
    for module_name in list(sys.modules):
        if module_name == "handlers" or module_name.startswith("handlers."):
            del sys.modules[module_name]


class HookTestMachine(StateMachine):
    def __init__(self, **kw: Any) -> None:
        super().__init__(
            states=[{"name": "working"}, {"name": "idle"}],
            transitions=[
                {"trigger": "begin", "source": "ready", "dest": "working"},
                {"trigger": "stop", "source": "working", "dest": "idle"},
                {"trigger": "again", "source": "idle", "dest": "ready"},
            ],
            **kw,
        )
        self.calls: List[str] = []
        self.allow_again: bool = True
        self.hook_allow: bool = True

    @on_enter_state("working")
    def class_enter_working(self, _: Optional[EventData]) -> None:
        self.calls.append("class_enter_working")

    @on_exit_state("working")
    def class_exit_working(self, _: Optional[EventData]) -> None:
        self.calls.append("class_exit_working")

    @guard("again")
    def class_guard_again(self) -> bool:
        self.calls.append("class_guard_again")
        return self.allow_again


class LoadHooksTestBase(unittest.TestCase):
    def setUp(self) -> None:
        get_registry().clear()
        reset_handlers_imports()
        self._tempdir = tempfile.TemporaryDirectory()
        self.addCleanup(self._tempdir.cleanup)
        self.tmp_path = Path(self._tempdir.name)

    def tearDown(self) -> None:
        if str(self.tmp_path) in sys.path:
            sys.path.remove(str(self.tmp_path))
        reset_handlers_imports()
        get_registry().clear()


class TestMissingAndEmptyDirectories(LoadHooksTestBase):
    def test_nonexistent_directory_logs_and_registers_nothing(self) -> None:
        machine = HookTestMachine()
        nonexistent = self.tmp_path / "does_not_exist"
        with self.assertLogs("state_machine.hooks.loader", level=logging.INFO) as captured:
            machine.load_hooks(nonexistent)
        self.assertEqual(get_registry().target_hooks, {})
        self.assertIn(f"Hooks directory {nonexistent} does not exist", "\n".join(captured.output))

    def test_empty_handlers_package_logs_no_hooks_registered(self) -> None:
        write_handlers_package(self.tmp_path, files={})
        machine = HookTestMachine()
        with self.assertLogs("state_machine.hooks.loader", level=logging.INFO) as captured:
            machine.load_hooks(self.tmp_path)
        self.assertEqual(get_registry().target_hooks, {})
        self.assertIn("No hooks registered after importing handlers/", "\n".join(captured.output))

    def test_handlers_without_decorators_logs_no_hooks_registered(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "noop.py": """
                def helper():
                    return 42
                """,
            },
        )
        machine = HookTestMachine()
        with self.assertLogs("state_machine.hooks.loader", level=logging.INFO) as captured:
            machine.load_hooks(self.tmp_path)
        self.assertEqual(get_registry().target_hooks, {})
        self.assertIn("No hooks registered after importing handlers/", "\n".join(captured.output))


class TestAddOnEnterState(LoadHooksTestBase):
    def test_add_on_enter_runs_before_class_level_callback(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "h.py": """
                from state_machine.hooks import add_on_enter_state

                @add_on_enter_state("working")
                def hook(context):
                    context.state_machine.calls.append("hook_add_enter")
                """,
            },
        )
        machine = HookTestMachine()
        machine.load_hooks(self.tmp_path)
        machine.trigger("begin")
        self.assertEqual(machine.calls, ["hook_add_enter", "class_enter_working"])


class TestReplaceOnEnterState(LoadHooksTestBase):
    def test_replace_on_enter_supplants_class_level_callback(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "h.py": """
                from state_machine.hooks import replace_on_enter_state

                @replace_on_enter_state("working")
                def hook(context):
                    context.state_machine.calls.append("hook_replace_enter")
                """,
            },
        )
        machine = HookTestMachine()
        machine.load_hooks(self.tmp_path)
        machine.trigger("begin")
        self.assertEqual(machine.calls, ["hook_replace_enter"])


class TestAddPlusReplaceCoexistence(LoadHooksTestBase):
    def test_add_runs_first_then_replace_takes_class_slot(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "h.py": """
                from state_machine.hooks import add_on_enter_state, replace_on_enter_state

                @add_on_enter_state("working")
                def add_hook(context):
                    context.state_machine.calls.append("hook_add")

                @replace_on_enter_state("working")
                def replace_hook(context):
                    context.state_machine.calls.append("hook_replace")
                """,
            },
        )
        machine = HookTestMachine()
        machine.load_hooks(self.tmp_path)
        machine.trigger("begin")
        self.assertEqual(machine.calls, ["hook_add", "hook_replace"])


class TestStateExitHooks(LoadHooksTestBase):
    def test_add_on_exit_runs_before_class_level_exit(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "h.py": """
                from state_machine.hooks import add_on_exit_state

                @add_on_exit_state("working")
                def hook(context):
                    context.state_machine.calls.append("hook_add_exit")
                """,
            },
        )
        machine = HookTestMachine()
        machine.load_hooks(self.tmp_path)
        machine.trigger("begin")
        machine.calls.clear()
        machine.trigger("stop")
        self.assertEqual(machine.calls, ["hook_add_exit", "class_exit_working"])

    def test_replace_on_exit_supplants_class_level_exit(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "h.py": """
                from state_machine.hooks import replace_on_exit_state

                @replace_on_exit_state("working")
                def hook(context):
                    context.state_machine.calls.append("hook_replace_exit")
                """,
            },
        )
        machine = HookTestMachine()
        machine.load_hooks(self.tmp_path)
        machine.trigger("begin")
        machine.calls.clear()
        machine.trigger("stop")
        self.assertEqual(machine.calls, ["hook_replace_exit"])


class TestAddGuard(LoadHooksTestBase):
    def test_add_guard_composes_with_class_level_guard(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "h.py": """
                from state_machine.hooks import add_guard

                @add_guard("again")
                def hook(context):
                    context.state_machine.calls.append("hook_add_guard")
                    return context.state_machine.hook_allow
                """,
            },
        )
        machine = HookTestMachine()
        machine.load_hooks(self.tmp_path)
        machine.trigger("begin")
        machine.trigger("stop")
        machine.calls.clear()

        machine.hook_allow = False
        result = machine.trigger("again")
        self.assertFalse(result)
        self.assertIn("hook_add_guard", machine.calls)
        self.assertIn("class_guard_again", machine.calls)
        self.assertEqual(machine.state, "idle")

        machine.calls.clear()
        machine.hook_allow = True
        result = machine.trigger("again")
        self.assertTrue(result)
        self.assertEqual(machine.state, "ready")


class TestReplaceGuard(LoadHooksTestBase):
    def test_replace_guard_skips_class_level_guard(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "h.py": """
                from state_machine.hooks import replace_guard

                @replace_guard("again")
                def hook(context):
                    context.state_machine.calls.append("hook_replace_guard")
                    return context.state_machine.hook_allow
                """,
            },
        )
        machine = HookTestMachine()
        machine.hook_allow = False
        machine.allow_again = True
        machine.load_hooks(self.tmp_path)
        machine.trigger("begin")
        machine.trigger("stop")
        machine.calls.clear()

        result = machine.trigger("again")
        self.assertFalse(result)
        self.assertEqual(machine.state, "idle")
        self.assertNotIn("class_guard_again", machine.calls)
        self.assertIn("hook_replace_guard", machine.calls)


class TestMultipleHandlerModules(LoadHooksTestBase):
    def test_decorators_from_separate_modules_all_register(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "a.py": """
                from state_machine.hooks import add_on_enter_state

                @add_on_enter_state("working")
                def from_a(context):
                    context.state_machine.calls.append("from_a")
                """,
                "b.py": """
                from state_machine.hooks import add_on_exit_state

                @add_on_exit_state("working")
                def from_b(context):
                    context.state_machine.calls.append("from_b")
                """,
            },
        )
        machine = HookTestMachine()
        machine.load_hooks(self.tmp_path)
        machine.trigger("begin")
        machine.trigger("stop")
        self.assertIn("from_a", machine.calls)
        self.assertIn("from_b", machine.calls)


class TestContextFactory(LoadHooksTestBase):
    def test_context_factory_invoked_each_dispatch_with_consumer_context(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "h.py": """
                from state_machine.hooks import add_on_enter_state

                @add_on_enter_state("working")
                def hook(context):
                    context.state_machine.calls.append(("payload", context.payload))
                """,
            },
        )

        @dataclass(frozen=True)
        class ConsumerContext(HookContext):
            payload: str

        machine = HookTestMachine()
        call_count = {"n": 0}

        def factory(base: HookContext) -> HookContext:
            call_count["n"] += 1
            return ConsumerContext(state_machine=base.state_machine, payload=f"call_{call_count['n']}")

        machine.load_hooks(self.tmp_path, context_factory=factory)
        machine.trigger("begin")
        machine.trigger("stop")
        machine.trigger("again")
        machine.trigger("begin")

        payloads = [entry for entry in machine.calls if isinstance(entry, tuple) and entry[0] == "payload"]
        self.assertEqual(payloads, [("payload", "call_1"), ("payload", "call_2")])
        self.assertEqual(call_count["n"], 2)


class TestAsyncStateHook(unittest.IsolatedAsyncioTestCase):
    # Uses IsolatedAsyncioTestCase because `machine.spawn(coro)` calls
    # `asyncio.create_task`, which requires a running event loop.

    def setUp(self) -> None:
        get_registry().clear()
        reset_handlers_imports()
        self._tempdir = tempfile.TemporaryDirectory()
        self.addCleanup(self._tempdir.cleanup)
        self.tmp_path = Path(self._tempdir.name)

    def tearDown(self) -> None:
        if str(self.tmp_path) in sys.path:
            sys.path.remove(str(self.tmp_path))
        reset_handlers_imports()
        get_registry().clear()

    async def test_async_state_hook_runs_via_spawn(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "h.py": """
                from state_machine.hooks import add_on_enter_state

                @add_on_enter_state("working")
                async def hook(context):
                    context.state_machine.calls.append("async_hook_ran")
                """,
            },
        )
        machine = HookTestMachine()
        machine.load_hooks(self.tmp_path)
        machine.trigger("begin")
        await asyncio.sleep(0)  # let the spawned task run
        self.assertIn("async_hook_ran", machine.calls)


class TestBootLogging(LoadHooksTestBase):
    def test_each_registration_emits_info_log_with_replace_flag(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "h.py": """
                from state_machine.hooks import add_on_enter_state, replace_on_enter_state

                @add_on_enter_state("working")
                def add_hook(context):
                    pass

                @replace_on_enter_state("idle")
                def replace_hook(context):
                    pass
                """,
            },
        )
        machine = HookTestMachine()
        with self.assertLogs("state_machine.hooks.loader", level=logging.INFO) as captured:
            machine.load_hooks(self.tmp_path)

        joined = "\n".join(captured.output)
        self.assertIn("@add_on_enter_state on working", joined)
        self.assertIn("[REPLACE] Registered hook @replace_on_enter_state on idle", joined)


class TestIdempotency(LoadHooksTestBase):
    def test_second_load_hooks_call_raises(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "h.py": """
                from state_machine.hooks import add_on_enter_state

                @add_on_enter_state("working")
                def hook(context):
                    context.state_machine.calls.append("hook")
                """,
            },
        )
        machine = HookTestMachine()
        machine.load_hooks(self.tmp_path)

        with self.assertRaises(RuntimeError) as exc:
            machine.load_hooks(self.tmp_path)
        self.assertIn("already been called", str(exc.exception))

        machine.trigger("begin")
        self.assertEqual(machine.calls.count("hook"), 1)

    def test_second_call_raises_even_when_first_loaded_no_hooks(self) -> None:
        machine = HookTestMachine()
        machine.load_hooks(self.tmp_path / "does_not_exist")

        write_handlers_package(self.tmp_path, files={})
        with self.assertRaises(RuntimeError):
            machine.load_hooks(self.tmp_path)


class TestAsyncHookWithoutRunningLoop(LoadHooksTestBase):
    def test_async_hook_in_sync_context_closes_coroutine_and_warns(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "h.py": """
                from state_machine.hooks import add_on_enter_state

                @add_on_enter_state("working")
                async def hook(context):
                    return None
                """,
            },
        )
        machine = HookTestMachine()
        machine.load_hooks(self.tmp_path)

        with (
            warnings.catch_warnings(record=True) as recorded,
            self.assertLogs("state_machine.hooks.loader", level=logging.WARNING) as captured,
        ):
            warnings.simplefilter("always")
            machine.trigger("begin")
            # Force GC so any lingering coroutine objects emit their unawaited warnings.
            gc.collect()

        unawaited = [w for w in recorded if "coroutine" in str(w.message).lower() and "never awaited" in str(w.message).lower()]
        self.assertEqual(unawaited, [], f"Coroutine leaked: {[str(w.message) for w in unawaited]}")
        self.assertIn("could not be scheduled: no running event loop", "\n".join(captured.output))


class TestLifecycleHooksSnapshotted(LoadHooksTestBase):
    def test_lifecycle_handlers_snapshotted_onto_machine(self) -> None:
        write_handlers_package(
            self.tmp_path,
            files={
                "h.py": """
                from state_machine.hooks import on_runtime_start, register_background_task

                @on_runtime_start
                def runtime_handler(context):
                    pass

                @register_background_task
                async def task_handler(context):
                    pass
                """,
            },
        )
        machine = HookTestMachine()
        machine.load_hooks(self.tmp_path)
        registry = get_registry()
        self.assertEqual(len(registry.runtime_start_handlers), 1)
        self.assertEqual(len(registry.background_tasks), 1)
        self.assertEqual(len(machine._runtime_start_handlers), 1)
        self.assertEqual(len(machine._background_task_handlers), 1)
        self.assertEqual(machine._runtime_start_handlers[0].qualname, "runtime_handler")
        self.assertEqual(machine._background_task_handlers[0].qualname, "task_handler")


if __name__ == "__main__":
    unittest.main()
