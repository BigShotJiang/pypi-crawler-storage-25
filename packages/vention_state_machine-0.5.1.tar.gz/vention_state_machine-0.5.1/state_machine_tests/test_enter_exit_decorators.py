import unittest
from typing import Any, List

from state_machine.core import StateMachine
from state_machine.defs import State, StateGroup
from state_machine.decorators import on_enter_state, on_exit_state


class TestEnterExitDecorators(unittest.IsolatedAsyncioTestCase):
    async def test_on_enter_exit_decorators_are_bound_and_invoked(self) -> None:
        """@on_enter_state and @on_exit_state bind and fire correctly."""
        hits: List[str] = []

        class DecoratedMachine(StateMachine):
            def __init__(self) -> None:
                super().__init__(
                    states=[{"name": "go"}, {"name": "stop"}],
                    transitions=[
                        {"trigger": "start", "source": "ready", "dest": "go"},
                        {"trigger": "flip", "source": "go", "dest": "stop"},
                    ],
                )

            @on_enter_state("go")
            def enter_go(self, _: Any) -> None:
                hits.append("entered_go")

            @on_exit_state("go")
            def exit_go(self, _: Any) -> None:
                hits.append("exited_go")

        sm = DecoratedMachine()
        await sm.start()
        sm.trigger("flip")
        self.assertEqual(hits, ["entered_go", "exited_go"])


class TestDecoratorWithStateObject(unittest.IsolatedAsyncioTestCase):
    async def test_decorator_accepts_state_descriptor_object(self) -> None:
        """@on_enter_state accepts State descriptor (e.g., Group.a)."""
        hits: List[str] = []

        class Group(StateGroup):
            a: State = State()

        class Container:
            g = Group()

        class MachineWithStateObj(StateMachine):
            def __init__(self) -> None:
                super().__init__(
                    states=Container,
                    transitions=[{"trigger": "start", "source": "ready", "dest": "Group_a"}],
                )

            @on_enter_state(Group.a)
            def on_enter_a(self, _: Any) -> None:
                hits.append("entered_Group_a")

        sm = MachineWithStateObj()
        await sm.start()
        self.assertEqual(sm.state, "Group_a")
        self.assertEqual(hits, ["entered_Group_a"])


class TestDecoratorFactories(unittest.IsolatedAsyncioTestCase):
    def test_on_enter_state_invalid_type_raises(self) -> None:
        """@on_enter_state with invalid arg type raises TypeError."""
        with self.assertRaises(TypeError):

            @on_enter_state(123)  # type: ignore[arg-type]
            def _bad(_evt: Any) -> None:
                pass

    def test_on_exit_state_invalid_type_raises(self) -> None:
        """@on_exit_state with invalid arg type raises TypeError."""
        with self.assertRaises(TypeError):

            @on_exit_state(3.14159)  # type: ignore[arg-type]
            def _bad2(_evt: Any) -> None:
                pass

    async def test_on_exit_state_hasattr_name_branch(self) -> None:
        """Covers hasattr(state_node, "name") branch in @on_exit_state."""

        class Pair(StateGroup):
            a: State = State()
            b: State = State()

        class GroupContainer:
            g = Pair()

        transitions = [
            {"trigger": "start", "source": "ready", "dest": "Pair_a"},
            {"trigger": "go", "source": "Pair_a", "dest": "Pair_b"},
        ]

        class SM(StateMachine):
            def __init__(self, *args: Any, **kwargs: Any) -> None:
                kwargs.setdefault("states", GroupContainer)
                kwargs.setdefault("transitions", transitions)
                kwargs.setdefault("enable_last_state_recovery", False)
                super().__init__(*args, **kwargs)
                self.exited_a = False

            @on_exit_state(Pair.a)
            def exit_a(self, _evt: Any) -> None:
                self.exited_a = True

        sm = SM()
        await sm.start()
        self.assertEqual(sm.state, "Pair_a")
        sm.trigger("go")
        self.assertTrue(sm.exited_a)
        self.assertEqual(sm.state, "Pair_b")
