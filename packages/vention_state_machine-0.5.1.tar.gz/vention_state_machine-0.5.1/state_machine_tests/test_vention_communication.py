import asyncio
import unittest
from datetime import datetime
from typing import Any, Optional, cast
from communication.entries import ActionEntry, RpcBundle
from communication.errors import ConnectError
from state_machine.core import StateMachine, BaseStates
from state_machine.vention_communication import build_state_machine_rpc_bundle
from state_machine.defs import StateGroup, State, Trigger
from state_machine.utils import StateResponse, HistoryResponse, TriggerResponse


class RunningStates(StateGroup):
    idle: State = State()
    active: State = State()


class TestStates:
    running = RunningStates()


class Triggers:
    activate = Trigger("activate")
    start = Trigger("start")
    reset = Trigger("reset")


TRANSITIONS = [
    Triggers.activate.transition(TestStates.running.idle, TestStates.running.active),
    Triggers.start.transition(BaseStates.READY.value, TestStates.running.idle),
    Triggers.reset.transition("*", BaseStates.READY.value),
]


class VentionCommunicationTestCase(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self) -> None:
        self.machine = StateMachine(states=TestStates, transitions=TRANSITIONS)

        async def async_activate() -> None:
            await asyncio.sleep(0.01)
            self.machine.trigger(Triggers.activate.name)

        self.machine.activate = async_activate  # override with coroutine
        await self.machine.start()

    def _find_action(self, bundle: RpcBundle, name: str) -> Optional[ActionEntry]:
        """Helper to find an action by name in the bundle."""
        for action in bundle.actions:
            if action.name == name:
                return action
        return None

    async def test_bundle_contains_get_state(self) -> None:
        """Bundle includes GetState action when include_state_actions=True."""
        bundle = build_state_machine_rpc_bundle(self.machine, include_state_actions=True)
        action = self._find_action(bundle, "GetState")
        self.assertIsNotNone(action)
        assert action is not None  # Type narrowing for mypy
        self.assertEqual(action.input_type, None)
        self.assertEqual(action.output_type, StateResponse)

    async def test_bundle_excludes_get_state(self) -> None:
        """Bundle excludes GetState action when include_state_actions=False."""
        bundle = build_state_machine_rpc_bundle(self.machine, include_state_actions=False)
        action = self._find_action(bundle, "GetState")
        self.assertIsNone(action)

    async def test_bundle_contains_get_history(self) -> None:
        """Bundle includes GetHistory action when include_history_action=True."""
        bundle = build_state_machine_rpc_bundle(self.machine, include_history_action=True)
        action = self._find_action(bundle, "GetHistory")
        self.assertIsNotNone(action)
        assert action is not None  # Type narrowing for mypy
        self.assertEqual(action.input_type, None)
        self.assertEqual(action.output_type, HistoryResponse)

    async def test_bundle_excludes_get_history(self) -> None:
        """Bundle excludes GetHistory action when include_history_action=False."""
        bundle = build_state_machine_rpc_bundle(self.machine, include_history_action=False)
        action = self._find_action(bundle, "GetHistory")
        self.assertIsNone(action)

    async def test_get_state_returns_current_and_last_state(self) -> None:
        """GetState action returns current and last known state."""
        bundle = build_state_machine_rpc_bundle(self.machine)
        action = self._find_action(bundle, "GetState")
        self.assertIsNotNone(action)
        assert action is not None  # Type narrowing for mypy

        result = await action.func()
        self.assertIsInstance(result, StateResponse)
        self.assertIn("state", result.model_dump())
        self.assertIn("last_state", result.model_dump())
        self.assertEqual(result.state, self.machine.state)

    async def test_get_state_without_get_last_state_method(self) -> None:
        """GetState handles state machine without get_last_state method."""

        # Create a simple mock object without get_last_state to test fallback
        class MockStateMachine:
            def __init__(self) -> None:
                self.state = "ready"
                self.events: dict[str, Any] = {}  # Required for bundle building
                # Intentionally no get_last_state method

        mock_machine = MockStateMachine()
        # Use cast to allow the mock to be passed to build_state_machine_rpc_bundle
        bundle = build_state_machine_rpc_bundle(cast(StateMachine, mock_machine), triggers=[])
        action = self._find_action(bundle, "GetState")
        self.assertIsNotNone(action)
        assert action is not None  # Type narrowing for mypy

        result = await action.func()
        self.assertIsInstance(result, StateResponse)
        self.assertEqual(result.state, "ready")
        # last_state should be None when method doesn't exist (fallback lambda)
        self.assertIsNone(result.last_state)

    async def test_get_history_returns_history(self) -> None:
        """GetHistory action returns transition history."""
        # Trigger a transition to create history
        self.machine.trigger(Triggers.activate.name)

        bundle = build_state_machine_rpc_bundle(self.machine)
        action = self._find_action(bundle, "GetHistory")
        self.assertIsNotNone(action)
        assert action is not None  # Type narrowing for mypy

        result = await action.func()
        self.assertIsInstance(result, HistoryResponse)
        self.assertIn("history", result.model_dump())
        self.assertIn("buffer_size", result.model_dump())
        self.assertIsInstance(result.history, list)
        self.assertGreater(len(result.history), 0)

    async def test_get_history_handles_dict_items(self) -> None:
        """GetHistory correctly handles dict items from history."""
        # The machine's history contains dict items with state, timestamp, duration_ms
        self.machine.trigger(Triggers.activate.name)

        bundle = build_state_machine_rpc_bundle(self.machine)
        action = self._find_action(bundle, "GetHistory")
        self.assertIsNotNone(action)
        assert action is not None  # Type narrowing for mypy

        result = await action.func()
        self.assertIsInstance(result, HistoryResponse)
        for entry in result.history:
            self.assertIsInstance(entry.state, str)
            self.assertIsInstance(entry.timestamp, datetime)

    async def test_get_history_handles_string_items(self) -> None:
        """GetHistory correctly handles string items from history."""
        # Manually add string items to history to test that path
        # Note: _history is typed as deque[dict], but we test string handling by appending a string
        # The code handles both dict and string items, so we use type: ignore to test the string path
        self.machine._history.append("test_state")  # type: ignore[arg-type]

        bundle = build_state_machine_rpc_bundle(self.machine)
        action = self._find_action(bundle, "GetHistory")
        self.assertIsNotNone(action)
        assert action is not None  # Type narrowing for mypy

        result = await action.func()
        self.assertIsInstance(result, HistoryResponse)
        # Should have converted string to HistoryEntry
        self.assertGreater(len(result.history), 0)

    async def test_bundle_contains_trigger_actions(self) -> None:
        """Bundle includes Trigger_<Name> actions for each trigger."""
        bundle = build_state_machine_rpc_bundle(self.machine)

        # Check for PascalCase trigger names
        activate_action = self._find_action(bundle, "Trigger_Activate")
        self.assertIsNotNone(activate_action)
        assert activate_action is not None  # Type narrowing for mypy
        self.assertEqual(activate_action.input_type, None)
        self.assertEqual(activate_action.output_type, TriggerResponse)

        start_action = self._find_action(bundle, "Trigger_Start")
        self.assertIsNotNone(start_action)

    async def test_trigger_action_valid_transition(self) -> None:
        """Trigger action executes valid trigger and returns response."""
        bundle = build_state_machine_rpc_bundle(self.machine)
        action = self._find_action(bundle, "Trigger_Activate")
        self.assertIsNotNone(action)
        assert action is not None  # Type narrowing for mypy

        previous_state = self.machine.state
        result = await action.func()

        self.assertIsInstance(result, TriggerResponse)
        self.assertEqual(result.result, "activate")
        self.assertEqual(result.previous_state, previous_state)
        self.assertEqual(result.new_state, self.machine.state)
        self.assertEqual(self.machine.state, str(TestStates.running.active))

    async def test_trigger_action_invalid_from_current_state(self) -> None:
        """Trigger action raises ConnectError for invalid trigger from current state."""
        # Move to a state where activate is not allowed
        self.machine.trigger("reset")
        self.assertEqual(self.machine.state, str(BaseStates.READY.value))

        bundle = build_state_machine_rpc_bundle(self.machine)
        action = self._find_action(bundle, "Trigger_Activate")
        self.assertIsNotNone(action)
        assert action is not None  # Type narrowing for mypy

        with self.assertRaises(ConnectError) as context:
            await action.func()

        error = context.exception
        self.assertEqual(error.code, "failed_precondition")
        self.assertIn("Trigger 'activate' cannot run", error.message)
        self.assertIn("ready", error.message)

    async def test_trigger_action_missing_method(self) -> None:
        """Trigger action raises ConnectError when trigger method is missing."""
        # Remove the activate method
        del self.machine.activate

        bundle = build_state_machine_rpc_bundle(self.machine)
        action = self._find_action(bundle, "Trigger_Activate")
        self.assertIsNotNone(action)
        assert action is not None  # Type narrowing for mypy

        with self.assertRaises(ConnectError) as context:
            await action.func()

        error = context.exception
        self.assertEqual(error.code, "internal")
        self.assertIn("StateMachine missing trigger 'activate'", error.message)

    async def test_trigger_action_raises_exception(self) -> None:
        """Trigger action raises ConnectError when trigger raises exception."""

        def bad_trigger() -> None:
            raise RuntimeError("oh no!")

        self.machine.activate = bad_trigger

        bundle = build_state_machine_rpc_bundle(self.machine)
        action = self._find_action(bundle, "Trigger_Activate")
        self.assertIsNotNone(action)
        assert action is not None  # Type narrowing for mypy

        with self.assertRaises(ConnectError) as context:
            await action.func()

        error = context.exception
        self.assertEqual(error.code, "internal")
        self.assertIn("Trigger 'activate' failed", error.message)

    async def test_trigger_action_with_async_trigger(self) -> None:
        """Trigger action handles async trigger methods."""
        bundle = build_state_machine_rpc_bundle(self.machine)
        action = self._find_action(bundle, "Trigger_Activate")
        self.assertIsNotNone(action)
        assert action is not None

        result = await action.func()

        self.assertIsInstance(result, TriggerResponse)
        self.assertEqual(result.result, "activate")
        self.assertEqual(self.machine.state, str(TestStates.running.active))

    async def test_custom_trigger_list(self) -> None:
        """Bundle only includes specified triggers when triggers parameter is provided."""
        bundle = build_state_machine_rpc_bundle(self.machine, triggers=["activate"])

        activate_action = self._find_action(bundle, "Trigger_Activate")
        self.assertIsNotNone(activate_action)

        # start and reset should not be included
        start_action = self._find_action(bundle, "Trigger_Start")
        self.assertIsNone(start_action)

    async def test_custom_trigger_list_execution(self) -> None:
        """Custom trigger list still allows execution of included triggers."""
        bundle = build_state_machine_rpc_bundle(self.machine, triggers=["activate"])
        action = self._find_action(bundle, "Trigger_Activate")
        self.assertIsNotNone(action)
        assert action is not None  # Type narrowing for mypy

        result = await action.func()
        self.assertIsInstance(result, TriggerResponse)
        self.assertEqual(result.result, "activate")

    async def test_all_triggers_included_when_none_specified(self) -> None:
        """All triggers are included when triggers=None."""
        bundle = build_state_machine_rpc_bundle(self.machine, triggers=None)

        # Should include all triggers from the machine
        all_trigger_names = sorted(self.machine.events.keys())
        for trigger_name in all_trigger_names:
            rpc_name = f"Trigger_{trigger_name[0].upper()}{trigger_name[1:]}"
            action = self._find_action(bundle, rpc_name)
            self.assertIsNotNone(action, f"Expected trigger action '{rpc_name}' not found in bundle")

    async def test_trigger_pascal_case_naming(self) -> None:
        """Trigger RPC names use PascalCase (Trigger_Activate not Trigger_activate)."""
        bundle = build_state_machine_rpc_bundle(self.machine)

        # Should be PascalCase
        activate_action = self._find_action(bundle, "Trigger_Activate")
        self.assertIsNotNone(activate_action)

        # Should NOT be lowercase
        lowercase_action = self._find_action(bundle, "Trigger_activate")
        self.assertIsNone(lowercase_action)

    async def test_bundle_default_includes_all_actions(self) -> None:
        """Default bundle includes GetState, GetHistory, and all triggers."""
        bundle = build_state_machine_rpc_bundle(self.machine)

        self.assertIsNotNone(self._find_action(bundle, "GetState"))
        self.assertIsNotNone(self._find_action(bundle, "GetHistory"))
        self.assertIsNotNone(self._find_action(bundle, "Trigger_Activate"))

    async def test_bundle_excludes_both_optional_actions(self) -> None:
        """Bundle can exclude both GetState and GetHistory."""
        bundle = build_state_machine_rpc_bundle(
            self.machine,
            include_state_actions=False,
            include_history_action=False,
        )

        self.assertIsNone(self._find_action(bundle, "GetState"))
        self.assertIsNone(self._find_action(bundle, "GetHistory"))
        # Triggers should still be included
        self.assertIsNotNone(self._find_action(bundle, "Trigger_Activate"))
