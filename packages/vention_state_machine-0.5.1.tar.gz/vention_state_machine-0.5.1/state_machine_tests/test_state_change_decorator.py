import unittest
from typing import List, Dict
from state_machine.core import StateMachine
from state_machine.defs import State, StateGroup, Trigger
from state_machine.decorators import on_state_change


class TestStates(StateGroup):
    idle: State = State()
    working: State = State()


class States:
    test = TestStates()


class Triggers:
    start = Trigger("start")
    reset = Trigger("reset")
    work = Trigger("work")


TRANSITIONS = [
    Triggers.start.transition("ready", States.test.idle),
    Triggers.work.transition(States.test.idle, States.test.working),
    Triggers.reset.transition("fault", "ready"),
]


class TestStateChangeDecorator(unittest.TestCase):
    def test_on_state_change_decorator(self) -> None:
        """Test that state change callbacks are called on transitions."""

        class TestMachine(StateMachine):
            def __init__(self) -> None:
                super().__init__(states=States, transitions=TRANSITIONS)
                self.state_changes: List[Dict[str, str]] = []

            @on_state_change
            def log_state_change(self, old_state: str, new_state: str, trigger: str) -> None:
                self.state_changes.append({"old_state": old_state, "new_state": new_state, "trigger": trigger})

        machine = TestMachine()

        # Trigger a transition
        machine.trigger(Triggers.start())

        # Check that callback was called
        self.assertEqual(len(machine.state_changes), 1)
        self.assertEqual(machine.state_changes[0]["old_state"], "ready")
        self.assertEqual(machine.state_changes[0]["new_state"], "TestStates_idle")
        self.assertEqual(machine.state_changes[0]["trigger"], "start")

    def test_multiple_state_change_callbacks(self) -> None:
        """Test that multiple state change callbacks are all called."""

        class TestMachine(StateMachine):
            def __init__(self) -> None:
                super().__init__(states=States, transitions=TRANSITIONS)
                self.callback1_calls: List[str] = []
                self.callback2_calls: List[str] = []

            @on_state_change
            def log_callback1(self, old_state: str, new_state: str, trigger: str) -> None:
                self.callback1_calls.append(f"{old_state}->{new_state}")

            @on_state_change
            def log_callback2(self, old_state: str, new_state: str, trigger: str) -> None:
                self.callback2_calls.append(trigger)

        machine = TestMachine()
        machine.trigger(Triggers.start())

        # Both callbacks should have been called
        self.assertEqual(len(machine.callback1_calls), 1)
        self.assertEqual(len(machine.callback2_calls), 1)
        self.assertEqual(machine.callback1_calls[0], "ready->TestStates_idle")
        self.assertEqual(machine.callback2_calls[0], "start")

    def test_state_change_callback_exception_handling(self) -> None:
        """Test that exceptions in state change callbacks don't break the state machine."""

        class TestMachine(StateMachine):
            def __init__(self) -> None:
                super().__init__(states=States, transitions=TRANSITIONS)
                self.successful_callback_called: bool = False

            @on_state_change
            def failing_callback(self, old_state: str, new_state: str, trigger: str) -> None:
                raise ValueError("Test exception")

            @on_state_change
            def successful_callback(self, old_state: str, new_state: str, trigger: str) -> None:
                self.successful_callback_called = True

        machine = TestMachine()

        # Transition should succeed despite the failing callback
        result = machine.trigger(Triggers.start())
        self.assertTrue(result)
        self.assertEqual(machine.state, "TestStates_idle")
        self.assertTrue(machine.successful_callback_called)

    def test_state_change_callbacks_on_multiple_transitions(self) -> None:
        """Test that state change callbacks are called on multiple transitions."""

        class TestMachine(StateMachine):
            def __init__(self) -> None:
                super().__init__(states=States, transitions=TRANSITIONS)
                self.transitions_logged: List[str] = []

            @on_state_change
            def log_transitions(self, old_state: str, new_state: str, trigger: str) -> None:
                self.transitions_logged.append(f"{trigger}: {old_state} -> {new_state}")

        machine = TestMachine()

        # First transition
        machine.trigger(Triggers.start())
        self.assertEqual(len(machine.transitions_logged), 1)
        self.assertEqual(machine.transitions_logged[0], "start: ready -> TestStates_idle")

        # Second transition
        machine.trigger(Triggers.work())
        self.assertEqual(len(machine.transitions_logged), 2)
        self.assertEqual(machine.transitions_logged[1], "work: TestStates_idle -> TestStates_working")

        # Third transition (to fault)
        machine.trigger("to_fault")
        self.assertEqual(len(machine.transitions_logged), 3)
        self.assertEqual(machine.transitions_logged[2], "to_fault: TestStates -> fault")
