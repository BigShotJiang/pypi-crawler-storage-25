import importlib
import sys
import unittest
from typing import Callable

from state_machine.defs import State, StateGroup, Trigger
from state_machine.hooks import (
    HookContext,
    add_guard,
    add_on_enter_state,
    add_on_exit_state,
    DuplicateHookError,
    get_registry,
    on_runtime_start,
    register_background_task,
    replace_guard,
    replace_on_enter_state,
    replace_on_exit_state,
)


class _StateContainer(StateGroup):
    sample: State = State()


class _States:
    group = _StateContainer()


_SAMPLE_TRIGGER = Trigger("sample_trigger")


class _HookDecoratorTestCase(unittest.TestCase):
    """Clears the global registry between tests so each one runs in isolation."""

    def setUp(self) -> None:
        get_registry().clear()

    def tearDown(self) -> None:
        get_registry().clear()


class TestReplaceGuard(_HookDecoratorTestCase):
    def test_registers_sync_handler(self) -> None:
        @replace_guard("trigger_x")
        def handler(context: HookContext) -> bool:
            return True

        registration = get_registry().get_target_hook("replace_guard", "trigger_x")
        self.assertIsNotNone(registration)
        assert registration is not None
        self.assertEqual(registration.decorator, "replace_guard")
        self.assertEqual(registration.target, "trigger_x")
        self.assertIs(registration.handler, handler)
        self.assertFalse(registration.is_async)

    def test_records_async_handler(self) -> None:
        @replace_guard("trigger_async")
        async def handler(context: HookContext) -> bool:
            return True

        registration = get_registry().get_target_hook("replace_guard", "trigger_async")
        assert registration is not None
        self.assertTrue(registration.is_async)

    def test_duplicate_registration_raises(self) -> None:
        @replace_guard("trigger_dup")
        def first(context: HookContext) -> bool:
            return True

        with self.assertRaises(DuplicateHookError):

            @replace_guard("trigger_dup")
            def second(context: HookContext) -> bool:
                return True

    def test_accepts_trigger_descriptor(self) -> None:
        @replace_guard(_SAMPLE_TRIGGER)
        def handler(context: HookContext) -> bool:
            return True

        self.assertIsNotNone(get_registry().get_target_hook("replace_guard", _SAMPLE_TRIGGER.name))

    def test_rejects_invalid_target_type(self) -> None:
        with self.assertRaises(TypeError):
            # Mypy rejects this call because the signature advertises
            # Union[str, Trigger]; the runtime TypeError from
            # resolve_trigger_name is what proves the fallback for callers
            # that bypass static checking. `unused-ignore` is appended so
            # the directive is also fine in pre-commit's restricted mypy
            # view where imports resolve to Any and no static error fires.
            replace_guard(123)  # type: ignore[arg-type, unused-ignore]


class TestAddGuard(_HookDecoratorTestCase):
    def test_registers_sync_handler(self) -> None:
        @add_guard("trigger_x")
        def handler(context: HookContext) -> bool:
            return True

        registration = get_registry().get_target_hook("add_guard", "trigger_x")
        assert registration is not None
        self.assertIs(registration.handler, handler)
        self.assertFalse(registration.is_async)

    def test_records_async_handler(self) -> None:
        @add_guard("trigger_async")
        async def handler(context: HookContext) -> bool:
            return True

        registration = get_registry().get_target_hook("add_guard", "trigger_async")
        assert registration is not None
        self.assertTrue(registration.is_async)

    def test_duplicate_registration_raises(self) -> None:
        @add_guard("trigger_dup")
        def first(context: HookContext) -> bool:
            return True

        with self.assertRaises(DuplicateHookError):

            @add_guard("trigger_dup")
            def second(context: HookContext) -> bool:
                return True

    def test_replace_and_add_coexist_for_same_trigger(self) -> None:
        @replace_guard("trigger_shared")
        def replace_handler(context: HookContext) -> bool:
            return True

        @add_guard("trigger_shared")
        def add_handler(context: HookContext) -> bool:
            return True

        registry = get_registry()
        self.assertIsNotNone(registry.get_target_hook("replace_guard", "trigger_shared"))
        self.assertIsNotNone(registry.get_target_hook("add_guard", "trigger_shared"))


class TestReplaceOnEnterState(_HookDecoratorTestCase):
    def test_registers_sync_handler(self) -> None:
        @replace_on_enter_state("state_x")
        def handler(context: HookContext) -> None:
            return None

        registration = get_registry().get_target_hook("replace_on_enter_state", "state_x")
        assert registration is not None
        self.assertFalse(registration.is_async)

    def test_registers_async_handler(self) -> None:
        @replace_on_enter_state("state_async")
        async def handler(context: HookContext) -> None:
            return None

        registration = get_registry().get_target_hook("replace_on_enter_state", "state_async")
        assert registration is not None
        self.assertTrue(registration.is_async)

    def test_accepts_state_descriptor(self) -> None:
        @replace_on_enter_state(_States.group.sample)
        def handler(context: HookContext) -> None:
            return None

        self.assertIsNotNone(get_registry().get_target_hook("replace_on_enter_state", _States.group.sample.name))

    def test_rejects_invalid_target_type(self) -> None:
        with self.assertRaises(TypeError):
            # Same rationale as TestReplaceGuard above: deliberately pass a
            # float to verify the runtime TypeError from resolve_state_name
            # for callers that bypass static checking. `unused-ignore`
            # keeps pre-commit's restricted mypy view (where imports are
            # Any) happy too.
            replace_on_enter_state(3.14)  # type: ignore[arg-type, unused-ignore]

    def test_duplicate_registration_raises(self) -> None:
        @replace_on_enter_state("state_dup")
        def first(context: HookContext) -> None:
            return None

        with self.assertRaises(DuplicateHookError):

            @replace_on_enter_state("state_dup")
            def second(context: HookContext) -> None:
                return None


class TestAddOnEnterState(_HookDecoratorTestCase):
    def test_registers_sync_handler(self) -> None:
        @add_on_enter_state("state_x")
        def handler(context: HookContext) -> None:
            return None

        registration = get_registry().get_target_hook("add_on_enter_state", "state_x")
        assert registration is not None
        self.assertFalse(registration.is_async)

    def test_registers_async_handler(self) -> None:
        @add_on_enter_state("state_async")
        async def handler(context: HookContext) -> None:
            return None

        registration = get_registry().get_target_hook("add_on_enter_state", "state_async")
        assert registration is not None
        self.assertTrue(registration.is_async)

    def test_duplicate_registration_raises(self) -> None:
        @add_on_enter_state("state_dup")
        def first(context: HookContext) -> None:
            return None

        with self.assertRaises(DuplicateHookError):

            @add_on_enter_state("state_dup")
            def second(context: HookContext) -> None:
                return None


class TestReplaceOnExitState(_HookDecoratorTestCase):
    def test_registers_sync_handler(self) -> None:
        @replace_on_exit_state("state_x")
        def handler(context: HookContext) -> None:
            return None

        registration = get_registry().get_target_hook("replace_on_exit_state", "state_x")
        assert registration is not None
        self.assertFalse(registration.is_async)

    def test_registers_async_handler(self) -> None:
        @replace_on_exit_state("state_async")
        async def handler(context: HookContext) -> None:
            return None

        registration = get_registry().get_target_hook("replace_on_exit_state", "state_async")
        assert registration is not None
        self.assertTrue(registration.is_async)

    def test_duplicate_registration_raises(self) -> None:
        @replace_on_exit_state("state_dup")
        def first(context: HookContext) -> None:
            return None

        with self.assertRaises(DuplicateHookError):

            @replace_on_exit_state("state_dup")
            def second(context: HookContext) -> None:
                return None


class TestAddOnExitState(_HookDecoratorTestCase):
    def test_registers_sync_handler(self) -> None:
        @add_on_exit_state("state_x")
        def handler(context: HookContext) -> None:
            return None

        registration = get_registry().get_target_hook("add_on_exit_state", "state_x")
        assert registration is not None
        self.assertFalse(registration.is_async)

    def test_registers_async_handler(self) -> None:
        @add_on_exit_state("state_async")
        async def handler(context: HookContext) -> None:
            return None

        registration = get_registry().get_target_hook("add_on_exit_state", "state_async")
        assert registration is not None
        self.assertTrue(registration.is_async)

    def test_duplicate_registration_raises(self) -> None:
        @add_on_exit_state("state_dup")
        def first(context: HookContext) -> None:
            return None

        with self.assertRaises(DuplicateHookError):

            @add_on_exit_state("state_dup")
            def second(context: HookContext) -> None:
                return None


class TestOnRuntimeStart(_HookDecoratorTestCase):
    def test_registers_sync_handler(self) -> None:
        @on_runtime_start
        def handler(context: HookContext) -> None:
            return None

        handlers = get_registry().runtime_start_handlers
        self.assertEqual(len(handlers), 1)
        self.assertIs(handlers[0].handler, handler)
        self.assertFalse(handlers[0].is_async)
        self.assertIsNone(handlers[0].target)

    def test_registers_async_handler(self) -> None:
        @on_runtime_start
        async def handler(context: HookContext) -> None:
            return None

        handlers = get_registry().runtime_start_handlers
        self.assertEqual(len(handlers), 1)
        self.assertTrue(handlers[0].is_async)

    def test_multiple_handlers_preserve_order(self) -> None:
        @on_runtime_start
        def first(context: HookContext) -> None:
            return None

        @on_runtime_start
        def second(context: HookContext) -> None:
            return None

        handlers = get_registry().runtime_start_handlers
        self.assertEqual([reg.handler for reg in handlers], [first, second])


class TestRegisterBackgroundTask(_HookDecoratorTestCase):
    def test_registers_sync_handler(self) -> None:
        @register_background_task
        def handler(context: HookContext) -> None:
            return None

        tasks = get_registry().background_tasks
        self.assertEqual(len(tasks), 1)
        self.assertFalse(tasks[0].is_async)

    def test_registers_async_handler(self) -> None:
        @register_background_task
        async def handler(context: HookContext) -> None:
            return None

        tasks = get_registry().background_tasks
        self.assertEqual(len(tasks), 1)
        self.assertTrue(tasks[0].is_async)

    def test_multiple_tasks_preserve_order(self) -> None:
        @register_background_task
        async def first(context: HookContext) -> None:
            return None

        @register_background_task
        async def second(context: HookContext) -> None:
            return None

        tasks = get_registry().background_tasks
        self.assertEqual([reg.handler for reg in tasks], [first, second])


class TestTargetDecoratorsAcceptDescriptors(_HookDecoratorTestCase):
    """
    Cross-check: each of the six target-keyed decorators must accept its
    descriptor type (`State` for the four state-hook variants, `Trigger`
    for the two guard variants). Catches wiring bugs like accidentally
    pairing a state decorator with `resolve_trigger_name` — that would
    still pass the per-decorator string tests because strings are accepted
    by both resolvers.
    """

    def test_state_decorators_accept_state_descriptor(self) -> None:
        descriptor = _States.group.sample
        cases: list[tuple[str, Callable[[State], Callable[[Callable[..., object]], Callable[..., object]]]]] = [
            ("replace_on_enter_state", replace_on_enter_state),
            ("add_on_enter_state", add_on_enter_state),
            ("replace_on_exit_state", replace_on_exit_state),
            ("add_on_exit_state", add_on_exit_state),
        ]

        for decorator_name, decorator_factory in cases:
            with self.subTest(decorator=decorator_name):
                get_registry().clear()

                @decorator_factory(descriptor)
                def handler(context: HookContext) -> object:
                    return None

                registration = get_registry().get_target_hook(decorator_name, descriptor.name)
                self.assertIsNotNone(
                    registration,
                    f"{decorator_name} did not register for State descriptor target {descriptor.name!r}",
                )

    def test_guard_decorators_accept_trigger_descriptor(self) -> None:
        descriptor = _SAMPLE_TRIGGER
        cases: list[tuple[str, Callable[[Trigger], Callable[[Callable[..., object]], Callable[..., object]]]]] = [
            ("replace_guard", replace_guard),
            ("add_guard", add_guard),
        ]

        for decorator_name, decorator_factory in cases:
            with self.subTest(decorator=decorator_name):
                get_registry().clear()

                @decorator_factory(descriptor)
                def handler(context: HookContext) -> object:
                    return None

                registration = get_registry().get_target_hook(decorator_name, descriptor.name)
                self.assertIsNotNone(
                    registration,
                    f"{decorator_name} did not register for Trigger descriptor target {descriptor.name!r}",
                )


class TestLambdaHandler(_HookDecoratorTestCase):
    """
    Hook authors commonly reach for lambdas for trivial bodies. The registry
    captures `__qualname__` (`<lambda>`) and `__module__`, so the registration
    should still succeed cleanly.
    """

    def test_lambda_handler_registers(self) -> None:
        on_runtime_start(lambda context: None)

        handlers = get_registry().runtime_start_handlers
        self.assertEqual(len(handlers), 1)
        self.assertIn("<lambda>", handlers[0].qualname)
        self.assertFalse(handlers[0].is_async)


class TestStackingDecoratorsOnSameHandler(_HookDecoratorTestCase):
    """
    A handler can have more than one decorator applied — e.g., a function
    that both enters one state and exits another. Each registration is
    independent.
    """

    def test_two_target_decorators_stack_independently(self) -> None:
        @add_on_enter_state("state_a")
        @add_on_exit_state("state_b")
        def handler(context: HookContext) -> None:
            return None

        enter = get_registry().get_target_hook("add_on_enter_state", "state_a")
        exit_ = get_registry().get_target_hook("add_on_exit_state", "state_b")
        self.assertIsNotNone(enter)
        self.assertIsNotNone(exit_)
        assert enter is not None and exit_ is not None
        self.assertIs(enter.handler, handler)
        self.assertIs(exit_.handler, handler)


class TestEmptyStringTargetRejected(_HookDecoratorTestCase):
    """
    An empty target string can't match any real state or trigger; reject at
    the decoration site so the failure is local to the buggy hook module,
    not surfaced later as a boot-time mismatch.
    """

    def test_state_decorators_reject_empty_string(self) -> None:
        state_decorators = [
            ("replace_on_enter_state", replace_on_enter_state),
            ("add_on_enter_state", add_on_enter_state),
            ("replace_on_exit_state", replace_on_exit_state),
            ("add_on_exit_state", add_on_exit_state),
        ]
        for decorator_name, decorator_factory in state_decorators:
            with self.subTest(decorator=decorator_name):
                get_registry().clear()
                with self.assertRaises(ValueError):
                    decorator_factory("")

    def test_guard_decorators_reject_empty_string(self) -> None:
        guard_decorators = [
            ("replace_guard", replace_guard),
            ("add_guard", add_guard),
        ]
        for decorator_name, decorator_factory in guard_decorators:
            with self.subTest(decorator=decorator_name):
                get_registry().clear()
                with self.assertRaises(ValueError):
                    decorator_factory("")


class TestSelfRegistrationOnImport(_HookDecoratorTestCase):
    FIXTURE_MODULE = "state_machine_tests.hook_fixtures.sample_handlers"

    def test_importing_handler_module_populates_registry(self) -> None:
        sys.modules.pop(self.FIXTURE_MODULE, None)
        importlib.import_module(self.FIXTURE_MODULE)

        registry = get_registry()

        self.assertIsNotNone(registry.get_target_hook("replace_guard", "trigger_replace_guard"))
        self.assertIsNotNone(registry.get_target_hook("add_guard", "trigger_add_guard"))
        self.assertIsNotNone(registry.get_target_hook("replace_on_enter_state", "state_replace_enter"))
        self.assertIsNotNone(registry.get_target_hook("add_on_enter_state", "state_add_enter"))
        self.assertIsNotNone(registry.get_target_hook("replace_on_exit_state", "state_replace_exit"))
        self.assertIsNotNone(registry.get_target_hook("add_on_exit_state", "state_add_exit"))

        add_enter_reg = registry.get_target_hook("add_on_enter_state", "state_add_enter")
        assert add_enter_reg is not None
        self.assertTrue(add_enter_reg.is_async)

        runtime_start = registry.runtime_start_handlers
        self.assertEqual(len(runtime_start), 2)
        self.assertFalse(runtime_start[0].is_async)
        self.assertTrue(runtime_start[1].is_async)

        background_tasks = registry.background_tasks
        self.assertEqual(len(background_tasks), 1)
        self.assertTrue(background_tasks[0].is_async)


if __name__ == "__main__":
    unittest.main()
