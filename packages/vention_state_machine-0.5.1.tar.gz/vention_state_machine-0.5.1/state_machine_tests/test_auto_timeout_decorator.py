# mypy: disable-error-code=misc
# mypy: disable-error-code=untyped-decorator

import asyncio
import unittest
from typing import Any

from state_machine.core import StateMachine, BaseStates
from state_machine.defs import Trigger
from state_machine.decorators import on_enter_state, auto_timeout


# ---------- Helpers ---------------------------------------------------------


def make_single_leaf_state_machine(*, trig: Any) -> StateMachine:
    """
    Build a machine with one leaf 'wait'; on-enter(wait) schedules auto-timeout
    using the provided 'trig' (can be callable Trigger or invalid object).

    Uses a modest timeout duration; tests wait with polling so CI schedulers
    can pass reliably.
    """
    transitions = [{"trigger": "start", "source": "ready", "dest": "wait"}]

    class SM(StateMachine):
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            kwargs.setdefault("states", [{"name": "wait"}])
            kwargs.setdefault("transitions", transitions)
            kwargs.setdefault("enable_last_state_recovery", False)
            super().__init__(*args, **kwargs)

        @on_enter_state("wait")
        @auto_timeout(0.5, trig)
        def enter_wait(self, _evt: Any) -> None:
            pass

    return SM()


async def _wait_until_model_state(
    sm: StateMachine,
    expected: str,
    *,
    poll_s: float = 0.02,
) -> None:
    """Poll until `sm.state == expected` (for async tests with real timers)."""
    while sm.state != expected:
        await asyncio.sleep(poll_s)


# ---------- Tests: _bind_decorated_handlers trigger resolution --------------


class TestBindDecoratedHandlers(unittest.IsolatedAsyncioTestCase):
    async def test_callable_trigger_branch(self) -> None:
        """Callable trigger (e.g., Trigger) is accepted and fires timeout."""
        callable_trig = Trigger("to_fault")
        sm = make_single_leaf_state_machine(trig=callable_trig)

        await sm.start()
        self.assertEqual(sm.state, "wait")

        try:
            await asyncio.wait_for(
                _wait_until_model_state(sm, BaseStates.FAULT.value),
                timeout=5.0,
            )
        except asyncio.TimeoutError:
            self.fail(f"Timed out waiting for auto_timeout(Trigger('to_fault')); state is still {sm.state!r}")

    def test_invalid_trigger_raises_typeerror(self) -> None:
        """Invalid trigger type in @auto_timeout raises TypeError."""
        with self.assertRaises(TypeError):
            make_single_leaf_state_machine(trig=object())


class TestAutoTimeoutDecorator(unittest.IsolatedAsyncioTestCase):
    async def test_auto_timeout_triggers_when_state_persists(self) -> None:
        """@auto_timeout triggers transition if state persists past timeout."""

        class TimeoutMachine(StateMachine):
            def __init__(self) -> None:
                super().__init__(
                    states=[{"name": "wait"}, {"name": "done"}],
                    transitions=[
                        {"trigger": "start", "source": "ready", "dest": "wait"},
                        {"trigger": "finish", "source": "wait", "dest": "done"},
                    ],
                )

            @on_enter_state("wait")
            @auto_timeout(seconds=0.1, trigger="finish")
            def handle_wait_timeout(self, _: Any) -> None:
                pass

        sm = TimeoutMachine()
        await sm.start()
        try:
            await asyncio.wait_for(_wait_until_model_state(sm, "done"), timeout=5.0)
        except asyncio.TimeoutError:
            self.fail(f"Timed out waiting for finish transition; state is still {sm.state!r}")
