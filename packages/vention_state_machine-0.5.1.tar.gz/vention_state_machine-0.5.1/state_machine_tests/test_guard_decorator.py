import unittest
from typing import List
from state_machine.core import StateMachine
from state_machine.defs import State, StateGroup, Trigger
from state_machine.decorators import guard, on_state_change


class TestStates(StateGroup):
    idle: State = State()
    working: State = State()


class States:
    test = TestStates()


class Triggers:
    start = Trigger("start")
    reset = Trigger("reset")
    work = Trigger("work")


TRANSITIONS = [
    Triggers.start.transition("ready", States.test.idle),
    Triggers.work.transition(States.test.idle, States.test.working),
    Triggers.reset.transition("fault", "ready"),
]


class TestGuardDecorator(unittest.TestCase):
    def test_guard_decorator_with_trigger_object(self) -> None:
        """Test that guard decorator prevents transitions when condition is False."""

        class TestMachine(StateMachine):
            def __init__(self) -> None:
                super().__init__(states=States, transitions=TRANSITIONS)
                self.estop_pressed: bool = True  # Simulate estop condition

            @guard(Triggers.reset)
            def check_safety_conditions(self) -> bool:
                return not self.estop_pressed  # Reset only allowed when estop is not pressed

        machine = TestMachine()
        machine.state = "fault"

        # Should not transition because estop is pressed
        result = machine.trigger(Triggers.reset())
        self.assertFalse(result)
        self.assertEqual(machine.state, "fault")

        # Should transition when estop is released
        machine.estop_pressed = False
        result = machine.trigger(Triggers.reset())
        self.assertTrue(result)
        self.assertEqual(machine.state, "ready")

    def test_guard_decorator_with_string_trigger(self) -> None:
        """Test that guard decorator works with string trigger names."""

        class TestMachine(StateMachine):
            def __init__(self) -> None:
                super().__init__(states=States, transitions=TRANSITIONS)
                self.allow_reset: bool = False

            @guard("reset")
            def check_reset_allowed(self) -> bool:
                return self.allow_reset

        machine = TestMachine()
        machine.state = "fault"

        # Should not transition
        result = machine.trigger("reset")
        self.assertFalse(result)
        self.assertEqual(machine.state, "fault")

        # Should transition when allowed
        machine.allow_reset = True
        result = machine.trigger("reset")
        self.assertTrue(result)
        self.assertEqual(machine.state, "ready")

    def test_guard_decorator_invalid_trigger_type(self) -> None:
        """Test that guard decorator raises TypeError for invalid trigger types."""

        with self.assertRaises(TypeError):

            class TestMachine(StateMachine):
                def __init__(self) -> None:
                    super().__init__(states=States, transitions=TRANSITIONS)

                @guard(123)  # type: ignore[arg-type]  # Invalid trigger type - testing error handling
                def invalid_guard(self) -> bool:
                    return True

            TestMachine()

    def test_guard_blocks_state_change_callback(self) -> None:
        """Test that blocked transitions don't trigger state change callbacks."""

        class TestMachine(StateMachine):
            def __init__(self) -> None:
                super().__init__(states=States, transitions=TRANSITIONS)
                self.state_changes: List[str] = []
                self.allow_transition: bool = False

            @guard(Triggers.start)
            def check_start_allowed(self) -> bool:
                return self.allow_transition

            @on_state_change
            def log_state_change(self, old_state: str, new_state: str, trigger: str) -> None:
                self.state_changes.append(trigger)

        machine = TestMachine()

        # Should not transition due to guard
        result = machine.trigger(Triggers.start())
        self.assertFalse(result)
        self.assertEqual(machine.state, "ready")
        self.assertEqual(len(machine.state_changes), 0)

        # Should transition when guard allows it
        machine.allow_transition = True
        result = machine.trigger(Triggers.start())
        self.assertTrue(result)
        self.assertEqual(machine.state, "TestStates_idle")
        self.assertEqual(len(machine.state_changes), 1)

    def test_guard_decorator_multiple_triggers(self) -> None:
        """Test that guard decorator works with multiple triggers."""

        class TestMachine(StateMachine):
            def __init__(self) -> None:
                super().__init__(states=States, transitions=TRANSITIONS)
                self.safety_ok: bool = True
                self.estop_ok: bool = True

            @guard(Triggers.reset, Triggers.start)
            def check_safety_conditions(self) -> bool:
                """Check both safety and estop conditions for multiple triggers."""
                return self.safety_ok and self.estop_ok

        machine = TestMachine()

        # Test reset from fault state
        machine.state = "fault"

        # Should not transition because safety conditions are not met
        machine.safety_ok = False
        result = machine.trigger(Triggers.reset())
        self.assertFalse(result)
        self.assertEqual(machine.state, "fault")

        # Should transition when all conditions are met
        machine.safety_ok = True
        result = machine.trigger(Triggers.reset())
        self.assertTrue(result)
        self.assertEqual(machine.state, "ready")

        # Test start from ready state
        machine.safety_ok = False
        result = machine.trigger(Triggers.start())
        self.assertFalse(result)
        self.assertEqual(machine.state, "ready")

        # Should transition when all conditions are met
        machine.safety_ok = True
        result = machine.trigger(Triggers.start())
        self.assertTrue(result)
        self.assertEqual(machine.state, "TestStates_idle")

    def test_multiple_guard_functions_same_trigger(self) -> None:
        """Test that multiple guard functions can be applied to the same trigger."""

        class TestMachine(StateMachine):
            def __init__(self) -> None:
                super().__init__(states=States, transitions=TRANSITIONS)
                self.safety_ok: bool = True
                self.estop_ok: bool = True

            @guard(Triggers.reset)
            def check_safety_conditions(self) -> bool:
                return self.safety_ok

            @guard(Triggers.reset)
            def check_estop_conditions(self) -> bool:
                return self.estop_ok

        machine = TestMachine()
        machine.state = "fault"

        # Both conditions must pass
        machine.safety_ok = False
        result = machine.trigger(Triggers.reset())
        self.assertFalse(result)

        machine.safety_ok = True
        machine.estop_ok = False
        result = machine.trigger(Triggers.reset())
        self.assertFalse(result)

        # Both conditions pass
        machine.estop_ok = True
        result = machine.trigger(Triggers.reset())
        self.assertTrue(result)

    def test_combined_guard_and_state_change(self) -> None:
        """Test that guard and state change decorators work together."""

        class TestMachine(StateMachine):
            def __init__(self) -> None:
                super().__init__(states=States, transitions=TRANSITIONS)
                self.safety_ok: bool = True
                self.transitions_logged: List[str] = []

            @guard(Triggers.start)
            def safety_check(self) -> bool:
                return self.safety_ok

            @on_state_change
            def log_transitions(self, old_state: str, new_state: str, trigger: str) -> None:
                self.transitions_logged.append(f"{trigger}: {old_state} -> {new_state}")

        machine = TestMachine()

        # Test successful transition
        result = machine.trigger(Triggers.start())
        self.assertTrue(result)
        self.assertEqual(len(machine.transitions_logged), 1)
        self.assertEqual(machine.transitions_logged[0], "start: ready -> TestStates_idle")

        # Test blocked transition
        machine.state = "ready"  # Reset state
        machine.safety_ok = False
        result = machine.trigger(Triggers.start())
        self.assertFalse(result)
        self.assertEqual(machine.state, "ready")
        # Should still only have 1 logged transition (the successful one)
        self.assertEqual(len(machine.transitions_logged), 1)

    def test_guard_for_nonexistent_trigger(self) -> None:
        """Test that guard conditions for non-existent triggers are handled gracefully."""

        # Create a trigger that won't be in the transitions
        nonexistent_trigger = Trigger("nonexistent")

        class TestMachine(StateMachine):
            def __init__(self) -> None:
                super().__init__(states=States, transitions=TRANSITIONS)
                self.guard_called: bool = False

            @guard(nonexistent_trigger)
            def guard_for_nonexistent(self) -> bool:
                self.guard_called = True
                return True

        # This should not raise an error and should handle the missing trigger gracefully
        machine = TestMachine()

        # The machine should initialize successfully even with a guard for a non-existent trigger
        self.assertIsNotNone(machine)

        # The guard should not be called since the trigger doesn't exist
        self.assertFalse(machine.guard_called)

        # The machine should still work normally with existing triggers
        result = machine.trigger(Triggers.start())
        self.assertTrue(result)
        self.assertEqual(machine.state, "TestStates_idle")
