#!/usr/bin/env python3
"""Acceptance tests for backward hook compatibility between TransformerBridge and HookedTransformer."""

import pytest
import torch


class TestBackwardHookCompatibility:
    """Test backward hook compatibility between TransformerBridge and HookedTransformer."""

    @pytest.mark.skip(
        reason="hook_mlp_out has known gradient differences due to architectural bridging (0.875 diff, but forward pass matches perfectly)"
    )
    def test_backward_hook_gradients_match_hooked_transformer(
        self, gpt2_hooked_unprocessed, gpt2_bridge_compat_no_processing
    ):
        """Test that backward hook gradients match between TransformerBridge and HookedTransformer.

        This test ensures that backward hooks see identical gradient values in both
        TransformerBridge and HookedTransformer when using no_processing mode.
        """
        hooked_model = gpt2_hooked_unprocessed
        bridge_model = gpt2_bridge_compat_no_processing

        test_input = torch.tensor([[1, 2, 3]])

        hooked_grad_sum = torch.zeros(1)
        bridge_grad_sum = torch.zeros(1)

        def sum_hooked_grads(grad, hook=None):
            nonlocal hooked_grad_sum
            hooked_grad_sum = grad.sum()
            return None

        def sum_bridge_grads(grad, hook=None):
            nonlocal bridge_grad_sum
            bridge_grad_sum = grad.sum()
            return None

        hooked_model.zero_grad()
        with hooked_model.hooks(bwd_hooks=[("blocks.0.hook_mlp_out", sum_hooked_grads)]):
            out = hooked_model(test_input)
            out.sum().backward()

        bridge_model.zero_grad()
        with bridge_model.hooks(bwd_hooks=[("blocks.0.hook_mlp_out", sum_bridge_grads)]):
            out = bridge_model(test_input)
            out.sum().backward()

        assert torch.allclose(hooked_grad_sum, bridge_grad_sum, atol=1e-2, rtol=1e-2), (
            f"Gradient sums should be identical but differ by "
            f"{abs(hooked_grad_sum - bridge_grad_sum).item():.6f}"
        )
