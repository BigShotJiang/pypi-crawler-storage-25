"""Comprehensive component benchmarking utility for TransformerBridge.

This module provides utilities to benchmark all standard components in a TransformerBridge
model against their HuggingFace equivalents, ensuring output parity.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple, cast

import torch
from torch import nn

from transformer_lens.config import TransformerBridgeConfig
from transformer_lens.model_bridge.architecture_adapter import ArchitectureAdapter
from transformer_lens.model_bridge.generalized_components.base import (
    GeneralizedComponent,
)


@dataclass
class ComponentTestResult:
    """Result of testing a single component."""

    component_path: str
    component_type: str
    passed: bool
    max_diff: float
    mean_diff: float
    output_shape: Tuple[int, ...]
    error_message: Optional[str] = None
    percentile_diffs: Optional[Dict[str, float]] = None  # 50th, 90th, 99th percentile diffs

    def get_failure_severity(self) -> str:
        """Categorize the severity of a failure.

        Returns:
            Severity level: "critical", "high", "medium", "low", or "pass"
        """
        if self.passed:
            return "pass"
        if self.error_message:
            return "critical"
        if self.max_diff > 1e-1:
            return "critical"
        elif self.max_diff > 1e-3:
            return "high"
        elif self.max_diff > 1e-4:
            return "medium"
        else:
            return "low"


@dataclass
class BenchmarkReport:
    """Complete benchmark report for all components."""

    model_name: str
    total_components: int
    passed_components: int
    failed_components: int
    component_results: List[ComponentTestResult] = field(default_factory=list)

    @property
    def pass_rate(self) -> float:
        """Calculate the pass rate as a percentage."""
        if self.total_components == 0:
            return 0.0
        return (self.passed_components / self.total_components) * 100

    def print_summary(self, verbose: bool = False) -> None:
        """Print a summary of the benchmark results.

        Args:
            verbose: If True, print details for all components. If False, only print failures.
        """
        print("\n" + "=" * 80)
        print(f"Component Benchmark Report: {self.model_name}")
        print("=" * 80)
        print(f"Total components tested: {self.total_components}")
        print(f"Passed: {self.passed_components} ({self.pass_rate:.1f}%)")
        print(f"Failed: {self.failed_components}")
        print("=" * 80)

        if verbose:
            print("\nAll Component Results:")
            print("-" * 80)
            for result in self.component_results:
                self._print_component_result(result)
        elif self.failed_components > 0:
            print("\nFailed Components:")
            print("-" * 80)
            for result in self.component_results:
                if not result.passed:
                    self._print_component_result(result)

        print("=" * 80 + "\n")

    def _print_component_result(self, result: ComponentTestResult) -> None:
        """Print details of a single component result."""
        status = "✓ PASS" if result.passed else "✗ FAIL"
        severity = result.get_failure_severity()

        # Add severity indicator for failures
        if not result.passed and severity != "critical":
            status = f"{status} [{severity.upper()}]"

        print(f"{status} | {result.component_path}")
        print(f"  Type: {result.component_type}")
        print(f"  Shape: {result.output_shape}")
        print(f"  Max diff: {result.max_diff:.6e}")
        print(f"  Mean diff: {result.mean_diff:.6e}")

        if result.percentile_diffs:
            print(f"  Percentile diffs:")
            for percentile, diff in sorted(result.percentile_diffs.items()):
                print(f"    {percentile}: {diff:.6e}")

        if result.error_message:
            print(f"  Error: {result.error_message}")
        print()

    def get_component_type_summary(self) -> Dict[str, Dict[str, int]]:
        """Get a summary of results grouped by component type.

        Returns:
            Dictionary mapping component types to their pass/fail counts
        """
        summary: Dict[str, Dict[str, int]] = {}

        for result in self.component_results:
            comp_type = result.component_type
            if comp_type not in summary:
                summary[comp_type] = {"passed": 0, "failed": 0, "total": 0}

            summary[comp_type]["total"] += 1
            if result.passed:
                summary[comp_type]["passed"] += 1
            else:
                summary[comp_type]["failed"] += 1

        return summary

    def get_failure_by_severity(self) -> Dict[str, List[ComponentTestResult]]:
        """Group failures by severity level.

        Returns:
            Dictionary mapping severity levels to lists of failed components
        """
        failures: Dict[str, List[ComponentTestResult]] = {
            "critical": [],
            "high": [],
            "medium": [],
            "low": [],
        }

        for result in self.component_results:
            if not result.passed:
                severity = result.get_failure_severity()
                if severity in failures:
                    failures[severity].append(result)

        return failures

    def print_detailed_analysis(self) -> None:
        """Print detailed analysis of benchmark results."""
        print("\n" + "=" * 80)
        print("Detailed Benchmark Analysis")
        print("=" * 80)

        # Component type summary
        print("\nResults by Component Type:")
        print("-" * 80)
        type_summary = self.get_component_type_summary()
        for comp_type, stats in sorted(type_summary.items()):
            pass_rate = (stats["passed"] / stats["total"]) * 100 if stats["total"] > 0 else 0
            print(
                f"{comp_type:30s}: {stats['passed']:3d}/{stats['total']:3d} passed ({pass_rate:5.1f}%)"
            )

        # Failure severity analysis
        if self.failed_components > 0:
            print("\nFailures by Severity:")
            print("-" * 80)
            failures_by_severity = self.get_failure_by_severity()
            for severity in ["critical", "high", "medium", "low"]:
                count = len(failures_by_severity[severity])
                if count > 0:
                    print(f"{severity.upper():10s}: {count} component(s)")
                    for result in failures_by_severity[severity][:3]:  # Show first 3
                        print(f"  - {result.component_path} (max_diff: {result.max_diff:.2e})")
                    if count > 3:
                        print(f"  ... and {count - 3} more")

        print("=" * 80 + "\n")


class ComponentBenchmarker:
    """Benchmarking utility for testing TransformerBridge components against HuggingFace."""

    def __init__(
        self,
        bridge_model: nn.Module,
        hf_model: nn.Module,
        adapter: ArchitectureAdapter,
        cfg: TransformerBridgeConfig,
        atol: float = 1e-4,
        rtol: float = 1e-4,
    ):
        """Initialize the component benchmarker.

        Args:
            bridge_model: The TransformerBridge model
            hf_model: The HuggingFace model
            adapter: The architecture adapter for mapping components
            cfg: The model configuration
            atol: Absolute tolerance for comparing outputs
            rtol: Relative tolerance for comparing outputs
        """
        self.bridge_model = bridge_model
        self.hf_model = hf_model
        self.adapter = adapter
        self.cfg = cfg

        # Reconcile dtypes: upcast both models to the higher-precision dtype.
        self._bridge_was_upcast = False
        self._bridge_original_dtype: Optional[torch.dtype] = None
        try:
            hf_dtype = next(hf_model.parameters()).dtype
        except StopIteration:
            hf_dtype = torch.float32
        try:
            bridge_dtype = next(bridge_model.parameters()).dtype
        except StopIteration:
            bridge_dtype = torch.float32
        if hf_dtype != bridge_dtype:
            # Upcast to the higher-precision dtype
            target = hf_dtype if hf_dtype.itemsize >= bridge_dtype.itemsize else bridge_dtype
            if bridge_dtype != target:
                self._bridge_original_dtype = bridge_dtype
                bridge_model.to(target)
                self._bridge_was_upcast = True
            if hf_dtype != target:
                hf_model.to(target)
        self.test_dtype = hf_dtype if hf_dtype.itemsize >= bridge_dtype.itemsize else bridge_dtype

        # Adjust tolerances based on dtype for reduced precision formats
        model_dtype = getattr(cfg, "dtype", torch.float32)
        if model_dtype == torch.bfloat16:
            # bfloat16 has ~7 bits of precision (3 decimal digits)
            # Use more lenient tolerance
            # Normalization layers (RMSNorm/LayerNorm) can have larger errors due to
            # square roots and divisions, so use 0.3 tolerance
            self.atol = max(atol, 0.3)
            self.rtol = max(rtol, 0.3)
        elif model_dtype == torch.float16:
            # float16 has ~10 bits of precision (3-4 decimal digits)
            self.atol = max(atol, 5e-3)
            self.rtol = max(rtol, 5e-3)
        else:
            # float32 or float64 - use provided tolerances
            self.atol = atol
            self.rtol = rtol

    def benchmark_all_components(
        self,
        test_inputs: Optional[Dict[str, torch.Tensor]] = None,
        skip_components: Optional[List[str]] = None,
    ) -> BenchmarkReport:
        """Benchmark all components in the model.

        Args:
            test_inputs: Optional dictionary of pre-generated test inputs.
                        If None, will generate default inputs.
            skip_components: Optional list of component paths to skip

        Returns:
            BenchmarkReport with results for all tested components
        """
        skip_components = skip_components or []
        component_mapping = self.adapter.get_component_mapping()

        # Generate test inputs if not provided
        if test_inputs is None:
            test_inputs = self._generate_test_inputs()

        results: List[ComponentTestResult] = []

        # Block-type components that need to be tested recursively by layer
        # (they are ModuleLists that don't have direct forward methods)
        block_components = {"blocks", "encoder_blocks", "decoder_blocks"}

        # Test top-level components (embed, pos_embed, ln_final, unembed)
        for comp_name, component in component_mapping.items():
            if comp_name in skip_components:
                continue

            if comp_name in block_components:
                # Handle blocks separately - test their subcomponents by layer
                continue

            result = self._test_component(comp_name, component, test_inputs)
            if result is not None:
                results.append(result)

        # Test block components recursively
        for block_type in block_components:
            if block_type in component_mapping and block_type not in skip_components:
                blocks_component = component_mapping[block_type]
                n_layers = self.cfg.n_layers

                for layer_idx in range(n_layers):
                    # Get the actual block to check which submodules were bound
                    actual_block = getattr(self.bridge_model, block_type)[layer_idx]
                    for subcomp_name, subcomponent in blocks_component.submodules.items():
                        # Skip optional submodules absent on this layer (hybrid architectures)
                        if subcomp_name not in actual_block._modules:
                            continue
                        comp_path = f"{block_type}.{layer_idx}.{subcomp_name}"
                        self._test_component_recursive(
                            comp_path, subcomponent, test_inputs, results, skip_components
                        )

        # Clean up test inputs to free memory
        if test_inputs is not None:
            for key in list(test_inputs.keys()):
                tensor = test_inputs[key]
                if tensor is not None and isinstance(tensor, torch.Tensor):
                    del tensor
            test_inputs.clear()

        # Create report
        passed = sum(1 for r in results if r.passed)
        failed = sum(1 for r in results if not r.passed)

        report = BenchmarkReport(
            model_name=getattr(self.cfg, "model_name", "unknown"),
            total_components=len(results),
            passed_components=passed,
            failed_components=failed,
            component_results=results,
        )

        # Restore bridge to its original dtype if we upcast it
        if self._bridge_was_upcast and self._bridge_original_dtype is not None:
            self.bridge_model.to(self._bridge_original_dtype)

        return report

    def _test_component_recursive(
        self,
        component_path: str,
        component: GeneralizedComponent,
        test_inputs: Dict[str, torch.Tensor],
        results: List[ComponentTestResult],
        skip_components: Optional[List[str]] = None,
    ) -> None:
        """Recursively test a component and all its subcomponents.

        This method tests the given component and then recursively tests all its
        nested subcomponents (e.g., attn.q, attn.k, mlp.gate, etc.).

        Note: We skip testing q/k/v subcomponents when the parent attention module
        uses joint QKV projection (JointQKVAttentionBridge), as these are virtual
        components that don't exist as separate modules in HuggingFace.

        Args:
            component_path: Path to the component (e.g., "blocks.0.attn")
            component: The generalized component bridge
            test_inputs: Dictionary of test inputs
            results: List to append results to
            skip_components: Optional list of component paths to skip
        """
        skip_components = skip_components or []

        # Skip if in skip list
        if component_path in skip_components:
            return

        # Skip MLP components that don't exist as separate modules in HF (name=None)
        # These are virtual components where fc1/fc2 are directly on the layer
        # Component testing doesn't work for these because get_component returns the parent layer
        if "mlp" in component_path and hasattr(component, "name") and component.name is None:
            return

        # Skip MLP components with custom forward signatures (e.g., BLOOM requires residual)
        # These can't be tested in isolation without full model context
        if "mlp" in component_path and hasattr(component, "hf_component"):
            import inspect

            try:
                sig = inspect.signature(component.hf_component.forward)
                params = list(sig.parameters.keys())
                # Standard MLP only needs hidden_states (or self + hidden_states)
                # If there are more required params, skip testing
                if len(params) > 2:  # self + hidden_states + other required params
                    return
            except Exception:
                # If we can't inspect, proceed with testing
                pass

        # Skip attention components that require position embeddings in Phase 3
        # These can't be tested in isolation without full model context for position embeddings
        if (
            "attn" in component_path
            and hasattr(component, "requires_position_embeddings")
            and component.requires_position_embeddings
        ):
            return

        # Skip attention components that use native HF attention (maintain_native_attention=True)
        # These have custom forward signatures (e.g., BLOOM requires residual, alibi, attention_mask)
        # and can't be tested in isolation without full model context
        if (
            "attn" in component_path
            and hasattr(component, "maintain_native_attention")
            and component.maintain_native_attention
        ):
            return

        # Skip models whose MLP/attn forward signatures require extra context from the block:
        # - BLOOM: MLP requires residual and alibi bias
        # - T5: requires cache_position for relative position embeddings
        # - MPT: MLP.forward(hidden_states, residual) performs the residual addition internally
        if "attn" in component_path or "mlp" in component_path:
            hf_model_config = getattr(self.hf_model, "config", None)
            if hf_model_config and hasattr(hf_model_config, "model_type"):
                if hf_model_config.model_type in ["bloom", "t5", "mpt"]:
                    return

        # Skip components that require specific shaped inputs from their parent modules
        # These components expect intermediate outputs from their parent attention/MLP
        # modules and can't be tested with generic hidden state inputs
        path_parts = component_path.split(".")
        if len(path_parts) >= 3:  # e.g., "blocks.0.attn.o" or "blocks.0.mlp.out"
            last_part = path_parts[-1]

            # Skip attention output projection (expects concatenated attn output)
            # Skip MLP output projection (expects MLP intermediate activations)
            # Note: q_norm/k_norm are handled specially in _run_component
            if last_part in ["o", "out"]:
                return

            # Skip MLA intermediates (expect compressed-dim inputs, not hidden_states)
            if last_part in [
                "q_a_proj",
                "q_a_layernorm",
                "q_b_proj",
                "kv_a_proj_with_mqa",
                "kv_a_layernorm",
                "kv_b_proj",
            ]:
                return

            # Skip virtual splits from fused projections (no standalone HF equivalent)
            if last_part in ["q", "k", "v", "gate", "in"]:
                parent_path = ".".join(path_parts[:-1])
                try:
                    parent_component = self.adapter.get_component(self.bridge_model, parent_path)
                    if hasattr(parent_component, "submodules"):
                        parent_bridge = cast(GeneralizedComponent, parent_component)
                        subs = parent_bridge.submodules
                        # Joint QKV: q/k/v are splits from fused qkv_proj/c_attn
                        if last_part in ["q", "k", "v"] and ("qkv" in subs or "c_attn" in subs):
                            return
                        # Joint gate+up: gate/in are splits from fused gate_up_proj
                        if last_part in ["gate", "in"] and (
                            "gate_up" in subs
                            or type(parent_bridge).__name__ == "JointGateUpMLPBridge"
                        ):
                            return
                except Exception:
                    pass

        # Skip components not wired on this layer (per-layer or per-config variation).
        # Only report as failure if the HF model has it but the bridge doesn't.
        try:
            self.adapter.get_component(self.bridge_model, component_path)
        except (AttributeError, ValueError):
            parts = component_path.split(".")
            if len(parts) >= 3 and parts[1].isdigit():
                subpath = ".".join([parts[0]] + ["{layer}"] + parts[2:])
                # Per-layer variation: exists on some other layer (e.g., MoE vs dense)
                for probe_layer in range(self.cfg.n_layers):
                    probe_path = subpath.replace("{layer}", str(probe_layer))
                    try:
                        self.adapter.get_component(self.bridge_model, probe_path)
                        return  # Found on another layer — skip this one
                    except (AttributeError, ValueError):
                        continue
                # Per-config absence: HF model also lacks it (e.g., q_lora_rank=None)
                try:
                    self.adapter.get_component(self.hf_model, component_path)
                except (AttributeError, ValueError):
                    return
            # Bridge is missing a component that HF has — likely misconfiguration

        # Test this component
        result = self._test_component(component_path, component, test_inputs)
        if result is not None:
            results.append(result)

        # Recursively test subcomponents
        if hasattr(component, "submodules") and component.submodules:
            for subcomp_name, subcomponent in component.submodules.items():
                sub_path = f"{component_path}.{subcomp_name}"
                self._test_component_recursive(
                    sub_path, subcomponent, test_inputs, results, skip_components
                )

    def _test_component(
        self,
        component_path: str,
        component: GeneralizedComponent,
        test_inputs: Dict[str, torch.Tensor],
    ) -> Optional[ComponentTestResult]:
        """Test a single component.

        Args:
            component_path: Path to the component (e.g., "embed", "blocks.0.attn")
            component: The generalized component bridge
            test_inputs: Dictionary of test inputs

        Returns:
            ComponentTestResult or None if the component cannot be tested
        """
        try:
            # Get bridge component
            # The adapter returns nn.Module, but for bridge models it's actually GeneralizedComponent
            bridge_component = cast(
                GeneralizedComponent, self.adapter.get_component(self.bridge_model, component_path)
            )

            # Get HuggingFace component
            hf_component = self.adapter.get_component(self.hf_model, component_path)

            # Determine appropriate test input based on component type
            test_input = self._get_test_input_for_component(component_path, test_inputs)
            if test_input is None:
                return None

            # Get input args/kwargs from the Bridge component
            # All bridge components inherit from GeneralizedComponent and have get_dummy_inputs()
            batch, seq_len, _ = test_input.shape
            pos_indices = (
                torch.arange(seq_len, device=test_input.device).unsqueeze(0).expand(batch, -1)
            )

            # For embedding components, generate token indices once
            shared_token_indices = None
            if component_path == "embed":
                batch, seq_len, _ = test_input.shape
                shared_token_indices = torch.randint(
                    0, self.cfg.d_vocab, (batch, seq_len), device=test_input.device
                )

            # Generate shared inputs for attention/MLP/rotary components that have get_random_inputs()
            # This is needed for model-specific inputs like position_embeddings or attention_mask
            shared_inputs = None
            if (
                ("attn" in component_path or "mlp" in component_path or "rotary" in component_path)
                and hasattr(bridge_component, "get_random_inputs")
                and callable(getattr(bridge_component, "get_random_inputs"))
            ):
                batch_size, seq_len = test_input.shape[:2]
                # Cast to callable to satisfy mypy - we've already verified it exists and is callable
                get_random_inputs_fn = cast(
                    Callable[..., Dict[str, Any]], bridge_component.get_random_inputs
                )
                shared_inputs = get_random_inputs_fn(
                    batch_size=batch_size,
                    seq_len=seq_len,
                    device=test_input.device,
                    dtype=test_input.dtype,
                )

                # Override position_embeddings with correct values from HF model's rotary_emb
                # This is needed for models with partial RoPE or non-standard rotary dims
                if (
                    "attn" in component_path
                    and "position_embeddings" in shared_inputs
                    and hasattr(self.hf_model, "model")
                ):
                    rotary_attr = getattr(self.hf_model.model, "rotary_emb", None)
                    if callable(rotary_attr):
                        try:
                            position_ids = (
                                torch.arange(seq_len, device=test_input.device)
                                .unsqueeze(0)
                                .expand(batch_size, -1)
                            )
                            position_embeddings = rotary_attr(test_input, position_ids)
                            shared_inputs["position_embeddings"] = position_embeddings
                        except Exception:
                            # If rotary_emb fails, keep the fallback position_embeddings from get_random_inputs()
                            pass

            # Run through both components with shared inputs (for attention) or standard inputs (for others)
            bridge_output = self._run_component(
                bridge_component, test_input, component_path, shared_token_indices, shared_inputs
            )
            hf_output = self._run_component(
                hf_component, test_input, component_path, shared_token_indices, shared_inputs
            )

            # Extract tensors if outputs are tuples
            bridge_tensor = bridge_output[0] if isinstance(bridge_output, tuple) else bridge_output
            hf_tensor = hf_output[0] if isinstance(hf_output, tuple) else hf_output

            # Ensure both are tensors
            if not isinstance(bridge_tensor, torch.Tensor) or not isinstance(
                hf_tensor, torch.Tensor
            ):
                return ComponentTestResult(
                    component_path=component_path,
                    component_type=type(component).__name__,
                    passed=False,
                    max_diff=float("inf"),
                    mean_diff=float("inf"),
                    output_shape=(),
                    error_message=f"Outputs are not tensors: bridge={type(bridge_tensor)}, hf={type(hf_tensor)}",
                )

            # Compare outputs
            passed, max_diff, mean_diff, percentile_diffs = self._compare_outputs(
                bridge_tensor, hf_tensor
            )

            # Get output shape before deleting tensors
            output_shape = tuple(bridge_tensor.shape)

            # Clean up output tensors immediately to free memory
            del bridge_output, hf_output, bridge_tensor, hf_tensor
            if shared_inputs is not None:
                # Clean up shared inputs
                for key in list(shared_inputs.keys()):
                    val = shared_inputs[key]
                    if val is not None and isinstance(val, torch.Tensor):
                        del val
                    shared_inputs[key] = None
            if shared_token_indices is not None:
                del shared_token_indices

            return ComponentTestResult(
                component_path=component_path,
                component_type=type(component).__name__,
                passed=passed,
                max_diff=max_diff,
                mean_diff=mean_diff,
                output_shape=output_shape,
                percentile_diffs=percentile_diffs,
            )

        except Exception as e:
            return ComponentTestResult(
                component_path=component_path,
                component_type=type(component).__name__,
                passed=False,
                max_diff=float("inf"),
                mean_diff=float("inf"),
                output_shape=(),
                error_message=str(e),
            )

    def _run_component(
        self,
        component: nn.Module,
        test_input: torch.Tensor,
        component_path: str,
        shared_token_indices: Optional[torch.Tensor] = None,
        shared_inputs: Optional[dict] = None,
    ) -> Any:
        """Run a component with appropriate arguments.

        Args:
            component: The component to run
            test_input: The test input tensor
            component_path: Path to the component for debugging
            shared_token_indices: Pre-generated token indices for embedding components
            shared_inputs: Pre-generated inputs from get_random_inputs() to use for both bridge and HF components

        Returns:
            The component output
        """
        # q_norm/k_norm expect d_head, not d_model
        if component_path.endswith(".q_norm") or component_path.endswith(".k_norm"):
            # Reshape test_input from (batch, seq, d_model) to (batch, seq, d_head)
            batch, seq, d_model = test_input.shape
            d_head = self.cfg.d_head
            # Use just d_head dimensions as test input
            test_input_reshaped = test_input[..., :d_head]
            return component(test_input_reshaped)

        # Use shared inputs if provided (generated from bridge component's get_random_inputs())
        if shared_inputs is not None:
            # Check if shared_inputs contains positional args
            if "args" in shared_inputs:
                # Call with positional args (e.g., for rotary embeddings)
                return component(*shared_inputs["args"])
            else:
                # Call with keyword args (e.g., for attention)
                return component(**shared_inputs)

        # Fallback: Use legacy calling conventions for components without get_random_inputs()
        if "attn" in component_path and "attn" == component_path.split(".")[-1]:
            # Attention components (legacy fallback)
            try:
                # Try TransformerLens-style attention
                return component(
                    query_input=test_input,
                    key_input=test_input,
                    value_input=test_input,
                    past_kv_cache_entry=None,
                    attention_mask=None,
                )
            except TypeError:
                try:
                    # Try HuggingFace-style attention
                    return component(hidden_states=test_input)
                except TypeError:
                    # Try simple call
                    return component(test_input)
        elif component_path == "embed":
            # Main embedding component expects integer indices
            # Use shared token indices if provided, otherwise generate new ones
            if shared_token_indices is not None:
                token_indices = shared_token_indices
            else:
                batch, seq_len, _ = test_input.shape
                token_indices = torch.randint(
                    0, self.cfg.d_vocab, (batch, seq_len), device=test_input.device
                )
            return component(token_indices)
        elif component_path == "pos_embed" or "pos_embed" in component_path:
            # Position embedding expects integer position indices
            batch, seq_len, _ = test_input.shape
            # For positional embeddings, we need position indices
            pos_indices = (
                torch.arange(seq_len, device=test_input.device).unsqueeze(0).expand(batch, -1)
            )
            try:
                return component(pos_indices)
            except (TypeError, IndexError):
                # Some pos embeds just return their embeddings directly
                # or may not take inputs
                try:
                    if hasattr(component, "weight") and isinstance(component.weight, torch.Tensor):
                        return component.weight[:seq_len]
                    else:
                        raise AttributeError("Component has no weight attribute")
                except AttributeError:
                    # Skip this component
                    raise ValueError("Cannot test pos_embed - unclear interface")
        elif component_path == "project_in":
            # project_in expects word_embed_proj_dim, not d_model.
            word_embed_proj_dim = getattr(self.cfg, "word_embed_proj_dim", None)
            if word_embed_proj_dim is not None and word_embed_proj_dim != self.cfg.d_model:
                test_input = test_input[..., :word_embed_proj_dim]
            return component(test_input)
        elif (
            component_path == "unembed"
            or "unembed" in component_path
            or "lm_head" in component_path
        ):
            # Unembed may expect word_embed_proj_dim (e.g., OPT-350m project_out).
            word_embed_proj_dim = getattr(self.cfg, "word_embed_proj_dim", None)
            if (
                word_embed_proj_dim is not None
                and word_embed_proj_dim != self.cfg.d_model
                and test_input.shape[-1] != word_embed_proj_dim
            ):
                test_input = test_input[..., :word_embed_proj_dim]
            return component(test_input)
        else:
            # Standard components (MLP, LayerNorm, etc.)
            try:
                return component(test_input)
            except TypeError:
                # Try with hidden_states kwarg
                return component(hidden_states=test_input)

    def _get_test_input_for_component(
        self, component_path: str, test_inputs: Dict[str, torch.Tensor]
    ) -> Optional[torch.Tensor]:
        """Get the appropriate test input for a component.

        Args:
            component_path: Path to the component
            test_inputs: Dictionary of available test inputs

        Returns:
            The appropriate test input tensor, or None if not applicable
        """
        # Use standard hidden state input for most components
        return test_inputs.get("hidden_states")

    def _generate_test_inputs(self) -> Dict[str, torch.Tensor]:
        """Generate default test inputs for benchmarking.

        Returns:
            Dictionary of test input tensors
        """
        batch_size = 2
        seq_len = 8
        d_model = self.cfg.d_model

        # Use the reconciled dtype from __init__.
        dtype = self.test_dtype
        try:
            device = next(self.hf_model.parameters()).device
        except StopIteration:
            device = torch.device("cpu")

        return {
            "hidden_states": torch.randn(batch_size, seq_len, d_model, dtype=dtype, device=device),
            "token_ids": torch.randint(0, self.cfg.d_vocab, (batch_size, seq_len), device=device),
        }

    def _compare_outputs(
        self, bridge_output: torch.Tensor, hf_output: torch.Tensor
    ) -> Tuple[bool, float, float, Dict[str, float]]:
        """Compare two output tensors.

        Args:
            bridge_output: Output from TransformerBridge component
            hf_output: Output from HuggingFace component

        Returns:
            Tuple of (passed, max_diff, mean_diff, percentile_diffs)
        """
        # Check shapes match
        if bridge_output.shape != hf_output.shape:
            return False, float("inf"), float("inf"), {}

        # Compute differences (upcast to float32 for safety)
        bo = bridge_output.float()
        ho = hf_output.float()
        diff = torch.abs(bo - ho)
        max_diff = diff.max().item()
        mean_diff = diff.mean().item()

        # Compute percentile differences
        flat_diff = diff.flatten()
        percentile_diffs = {
            "50th": torch.quantile(flat_diff, 0.5).item(),
            "90th": torch.quantile(flat_diff, 0.9).item(),
            "99th": torch.quantile(flat_diff, 0.99).item(),
        }

        # Check if within tolerance
        passed = torch.allclose(bo, ho, atol=self.atol, rtol=self.rtol)

        return passed, max_diff, mean_diff, percentile_diffs


def benchmark_model(
    model_name: str,
    device: str = "cpu",
    atol: float = 1e-4,
    rtol: float = 1e-4,
    skip_components: Optional[List[str]] = None,
    verbose: bool = False,
) -> BenchmarkReport:
    """Benchmark all components in a model.

    Args:
        model_name: Name of the HuggingFace model to benchmark
        device: Device to run on
        atol: Absolute tolerance for comparisons
        rtol: Relative tolerance for comparisons
        skip_components: Optional list of component paths to skip
        verbose: If True, print detailed results for all components

    Returns:
        BenchmarkReport with results for all components
    """
    from transformers import AutoModelForCausalLM

    from transformer_lens.model_bridge import TransformerBridge

    # Load models
    print(f"Loading models: {model_name}")
    bridge_model = TransformerBridge.boot_transformers(model_name, device=device)  # type: ignore[attr-defined]

    # Load HF model with same attn_implementation as bridge model (if specified)
    # This ensures numerical consistency between bridge and HF models
    hf_kwargs = {"device_map": device}
    if (
        hasattr(bridge_model.adapter.cfg, "attn_implementation")
        and bridge_model.adapter.cfg.attn_implementation is not None
    ):
        hf_kwargs["attn_implementation"] = bridge_model.adapter.cfg.attn_implementation

    hf_model = AutoModelForCausalLM.from_pretrained(model_name, **hf_kwargs)

    # Set models to eval mode (disable dropout, etc.)
    bridge_model.eval()
    hf_model.eval()

    # Get adapter
    adapter = bridge_model.adapter

    # Set up component testing (e.g., sync rotary_emb references for Gemma-3)
    # Pass bridge_model so adapter can set up actual bridge instances, not just templates
    adapter.setup_component_testing(hf_model, bridge_model=bridge_model)

    # Create benchmarker
    benchmarker = ComponentBenchmarker(
        bridge_model=bridge_model,
        hf_model=hf_model,
        adapter=adapter,
        cfg=bridge_model.cfg,
        atol=atol,
        rtol=rtol,
    )

    # Run benchmark
    print("Running component benchmark...")
    report = benchmarker.benchmark_all_components(skip_components=skip_components)

    # Print report
    report.print_summary(verbose=verbose)

    return report
