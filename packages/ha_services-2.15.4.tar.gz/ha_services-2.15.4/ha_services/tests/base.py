from ha_services.mqtt4homeassistant.device import BaseMqttDevice


class ComponentTestMixin:
    """
    Clear components to avoid side effects in other tests
    """

    def setUp(self):
        super().setUp()
        BaseMqttDevice.clear()

    def tearDown(self):
        super().tearDown()
        BaseMqttDevice.clear()
