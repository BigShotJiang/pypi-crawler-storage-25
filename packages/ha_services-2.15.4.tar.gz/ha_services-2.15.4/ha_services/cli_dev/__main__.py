"""
    Allow ha_services to be executable
    through `python -m ha_services.cli_dev`.
"""

from ha_services.cli_dev import main


if __name__ == '__main__':
    main()
