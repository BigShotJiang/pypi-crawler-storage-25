"""Tests for auto-updater post-update restart logic."""

from __future__ import annotations

from unittest.mock import patch

from meeting_helper import auto_updater


def test_resolve_cli_prefers_sys_executable_neighbor(tmp_path):
    cli_path = tmp_path / "meeting-helper"
    cli_path.write_text("#!/bin/sh\n")
    cli_path.chmod(0o755)
    fake_executable = tmp_path / "python3"
    fake_executable.write_text("")

    with patch("meeting_helper.auto_updater.sys") as fake_sys:
        fake_sys.executable = str(fake_executable)
        assert auto_updater._resolve_cli() == str(cli_path)


def test_resolve_cli_falls_back_to_path_lookup(tmp_path):
    fake_executable = tmp_path / "python3"
    fake_executable.write_text("")

    with patch("meeting_helper.auto_updater.sys") as fake_sys, \
         patch("meeting_helper.auto_updater.shutil.which", return_value="/usr/local/bin/meeting-helper"):
        fake_sys.executable = str(fake_executable)
        assert auto_updater._resolve_cli() == "/usr/local/bin/meeting-helper"


def test_trigger_post_update_restart_skips_when_cli_unresolved(tmp_path):
    """If CLI can't be resolved we must NOT self-SIGTERM (would leave no daemon)."""
    from meeting_helper import config as cfg_module
    fake_pid_file = tmp_path / "menubar.pid"  # does not exist
    with patch("meeting_helper.auto_updater._resolve_cli", return_value=None), \
         patch("meeting_helper.auto_updater.os.kill") as fake_kill, \
         patch("meeting_helper.auto_updater.subprocess.Popen") as fake_popen, \
         patch("meeting_helper.auto_updater.time.sleep"), \
         patch.object(cfg_module, "MENUBAR_PID_FILE", fake_pid_file):
        auto_updater._trigger_post_update_restart("9.9.9")
        fake_popen.assert_not_called()
        fake_kill.assert_not_called()


def test_trigger_post_update_restart_does_not_kill_self_when_daemon_spawn_fails(tmp_path):
    """If spawning the new daemon fails, do NOT self-SIGTERM."""
    from meeting_helper import config as cfg_module
    fake_pid_file = tmp_path / "menubar.pid"  # does not exist
    with patch("meeting_helper.auto_updater._resolve_cli", return_value="/fake/cli"), \
         patch("meeting_helper.auto_updater.subprocess.Popen", side_effect=OSError("nope")), \
         patch("meeting_helper.auto_updater.time.sleep"), \
         patch("meeting_helper.auto_updater.os.kill") as fake_kill, \
         patch("meeting_helper.auto_updater.os.getpid", return_value=12345), \
         patch.object(cfg_module, "MENUBAR_PID_FILE", fake_pid_file):
        auto_updater._trigger_post_update_restart("9.9.9")
    # Self-SIGTERM (12345) must NOT have fired. Menubar kill might have
    # — that's fine; assert only on the self-kill not happening.
    assert (12345, 15) not in [c.args for c in fake_kill.call_args_list]


def test_trigger_post_update_restart_happy_path_spawns_then_kills(tmp_path):
    from meeting_helper import config as cfg_module
    fake_pid_file = tmp_path / "menubar.pid"  # does not exist
    with patch("meeting_helper.auto_updater._resolve_cli", return_value="/fake/cli"), \
         patch("meeting_helper.auto_updater.subprocess.Popen") as fake_popen, \
         patch("meeting_helper.auto_updater.time.sleep"), \
         patch("meeting_helper.auto_updater.os.kill") as fake_kill, \
         patch("meeting_helper.auto_updater.os.getpid", return_value=12345), \
         patch.object(cfg_module, "MENUBAR_PID_FILE", fake_pid_file):
        auto_updater._trigger_post_update_restart("9.9.9")
        # Two Popen calls: `start` and `gui`
        assert fake_popen.call_count == 2
        cmds = [call.args[0] for call in fake_popen.call_args_list]
        assert ["/fake/cli", "start"] in cmds
        assert ["/fake/cli", "gui"] in cmds
        fake_kill.assert_called_once_with(12345, 15)  # SIGTERM = 15


def test_trigger_post_update_restart_kills_old_menubar_and_spawns_gui(tmp_path):
    """Happy path: menubar is killed, new daemon + GUI both spawned, self-SIGTERM fires."""
    from meeting_helper import config as cfg_module
    fake_pid_file = tmp_path / "menubar.pid"
    fake_pid_file.write_text("99999")

    with patch("meeting_helper.auto_updater._resolve_cli", return_value="/fake/cli"), \
         patch("meeting_helper.auto_updater.subprocess.Popen") as fake_popen, \
         patch("meeting_helper.auto_updater.time.sleep"), \
         patch("meeting_helper.auto_updater.os.kill") as fake_kill, \
         patch("meeting_helper.auto_updater.os.getpid", return_value=12345), \
         patch.object(cfg_module, "MENUBAR_PID_FILE", fake_pid_file):
        auto_updater._trigger_post_update_restart("9.9.9")

    # Two Popen calls: `start` and `gui`
    assert fake_popen.call_count == 2
    cmds = [call.args[0] for call in fake_popen.call_args_list]
    assert ["/fake/cli", "start"] in cmds
    assert ["/fake/cli", "gui"] in cmds

    # os.kill called twice: once for the old menubar (99999, SIGTERM=15)
    # and once for self (12345, SIGTERM=15).
    kill_calls = [call.args for call in fake_kill.call_args_list]
    assert (99999, 15) in kill_calls
    assert (12345, 15) in kill_calls

    # PID file should be wiped.
    assert not fake_pid_file.exists()
