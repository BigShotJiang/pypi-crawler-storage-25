"""Tests for CopilotScreen._dispatch_ws_event handlers.

These exercise the WS message → UI state path without a real Page or daemon.
The _dispatch_ws_event method is async; we run each handler under
asyncio.run with mocked dependencies.
"""

from __future__ import annotations

import asyncio
from unittest.mock import MagicMock

import pytest


@pytest.fixture
def screen():
    from meeting_helper.flet_gui.screens.copilot import CopilotScreen

    page = MagicMock()
    page.run_thread = MagicMock()
    page.run_task = MagicMock()
    page.update = MagicMock()
    cfg = MagicMock()
    cfg.port = 7891
    cfg.local_todo_configured = True
    cfg.provider_configured = True
    return CopilotScreen(page, cfg)


def test_transcriber_dead_event_marks_pill(screen):
    """The transcriber_dead listener must annotate the pill so the user
    sees the failure (this is the A1 self-inflicted gap from 9c03d13)."""
    asyncio.run(
        screen._dispatch_ws_event({
            "type": "transcriber_dead",
            "role": "self",
            "reason": "reconnect_exhausted",
        })
    )
    assert "⚠" in screen._transcriber_pill.label
    assert "self" in screen._transcriber_pill.label.lower()


def test_transcriber_dead_event_idempotent(screen):
    """Repeated transcriber_dead events shouldn't keep appending warning
    markers ('Deepgram ⚠ self ⚠ self ⚠ self...')."""
    asyncio.run(screen._dispatch_ws_event({"type": "transcriber_dead", "role": "self"}))
    label_after_first = screen._transcriber_pill.label
    asyncio.run(screen._dispatch_ws_event({"type": "transcriber_dead", "role": "self"}))
    assert screen._transcriber_pill.label == label_after_first


def test_interim_transcript_appears_in_caption_bar(screen):
    """Phase 1 fix: interim transcripts are NOT silently dropped — they
    render into the live caption bar so users see words within ~200 ms
    instead of waiting 1–3 s for finals.

    Bar visibility is now gated on session_active via update_status; the
    dispatch handler doesn't toggle it. We simulate a meeting being active
    before checking the visible flag."""
    screen.update_status(daemon_running=True, session_active=True, meeting_name="Test")
    asyncio.run(
        screen._dispatch_ws_event({
            "type": "transcript",
            "role": "self",
            "text": "hello there",
            "interim": True,
        })
    )
    assert "hello there" in screen._self_interim_text.value
    # And the bar is visible because update_status set it (session active).
    assert screen._live_caption_bar.visible is True


def test_final_transcript_clears_role_interim(screen):
    """When a final lands the corresponding role's interim must clear,
    so the caption bar doesn't keep the half-typed sentence forever."""
    # Set up an interim first.
    asyncio.run(screen._dispatch_ws_event({
        "type": "transcript", "role": "self",
        "text": "half-typed", "interim": True,
    }))
    assert screen._self_interim_text.value
    # Now a final.
    asyncio.run(screen._dispatch_ws_event({
        "type": "transcript", "role": "self",
        "text": "Final sentence.", "interim": False,
    }))
    assert screen._self_interim_text.value == ""


def test_other_role_interim_independent_from_self(screen):
    """Self and other interim slots are independent; an interim from one
    must not clear the other."""
    asyncio.run(screen._dispatch_ws_event({
        "type": "transcript", "role": "self",
        "text": "I'm talking", "interim": True,
    }))
    asyncio.run(screen._dispatch_ws_event({
        "type": "transcript", "role": "other",
        "text": "they're talking", "interim": True,
    }))
    assert screen._self_interim_text.value
    assert screen._other_interim_text.value
    # Final on `self` must not clear `other`.
    asyncio.run(screen._dispatch_ws_event({
        "type": "transcript", "role": "self",
        "text": "self final", "interim": False,
    }))
    assert screen._self_interim_text.value == ""
    assert screen._other_interim_text.value  # still set


def test_unknown_role_is_ignored(screen):
    """Bogus role values shouldn't blow up the dispatcher."""
    asyncio.run(screen._dispatch_ws_event({
        "type": "transcript", "role": "bystander",
        "text": "x", "interim": True,
    }))
    assert screen._self_interim_text.value == ""
    assert screen._other_interim_text.value == ""
