"""Auto-update logic: poll PyPI and pipx-upgrade in place when idle.

Runs as a background asyncio task in the daemon. Wakes every 30 minutes
or at the next midnight (whichever comes first), and only runs the
upgrade when no meeting session is active.

The current Python process keeps its imported modules in memory, so the
new code only takes effect on the next daemon restart — by design, to
avoid yanking the rug while a meeting is being set up.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import shutil
import signal
import ssl
import subprocess
import sys
import time
import urllib.request
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

from meeting_helper import __version__

logger = logging.getLogger(__name__)


PYPI_URL = "https://pypi.org/pypi/meeting-helper/json"
CHECK_INTERVAL_SEC = 30 * 60


def is_editable_install() -> tuple[bool, Optional[str]]:
    """Return (editable, source_path) via PEP 610 direct_url.json."""
    try:
        from importlib.metadata import distribution
        raw = distribution("meeting-helper").read_text("direct_url.json")
        if not raw:
            return False, None
        info = json.loads(raw)
        if info.get("dir_info", {}).get("editable"):
            url = info.get("url", "")
            return True, url[7:] if url.startswith("file://") else url
    except Exception:
        pass
    return False, None


def fetch_latest_version() -> Optional[str]:
    """Return the latest published version on PyPI, or None on any error."""
    ssl_ctx = ssl._create_unverified_context()
    try:
        req = urllib.request.Request(PYPI_URL, headers={"User-Agent": "meeting-helper"})
        with urllib.request.urlopen(req, timeout=8, context=ssl_ctx) as resp:
            return json.loads(resp.read())["info"]["version"]
    except Exception as exc:
        logger.warning("PyPI version check failed: %s", exc)
        return None


def run_pipx_upgrade() -> tuple[bool, str]:
    """Run `pipx upgrade`, falling back to `pipx install --force`."""
    upgrade_cmd = ["pipx", "upgrade", "--pip-args=--no-cache-dir", "meeting-helper"]
    install_cmd = ["pipx", "install", "--force", "--pip-args=--no-cache-dir", "meeting-helper"]

    result = subprocess.run(upgrade_cmd, capture_output=True, text=True)
    if result.returncode == 0:
        return True, "pipx upgrade succeeded"

    logger.warning("pipx upgrade failed (rc=%d): %s", result.returncode, result.stderr.strip())
    result = subprocess.run(install_cmd, capture_output=True, text=True)
    if result.returncode == 0:
        return True, "pipx install --force succeeded"

    return False, f"pipx install --force failed: {result.stderr.strip()}"


def attempt_update() -> Optional[str]:
    """One-shot update attempt. Returns the newly-installed version, or None.

    None covers: editable install, PyPI unreachable, already on latest,
    or pipx command failure. Failures are logged, never raised — the
    background loop must keep running across transient errors.
    """
    editable, src_path = is_editable_install()
    if editable:
        logger.info("Auto-update skipped: editable install at %s", src_path)
        return None

    latest = fetch_latest_version()
    if latest is None:
        return None
    if latest == __version__:
        logger.debug("Auto-update: already on latest v%s", __version__)
        return None

    logger.info("Auto-update: %s -> %s, running pipx upgrade", __version__, latest)
    ok, msg = run_pipx_upgrade()
    if not ok:
        logger.warning("Auto-update failed: %s", msg)
        return None

    logger.info("Auto-update: installed v%s (was v%s) — broadcasting restart", latest, __version__)
    _trigger_post_update_restart(latest)
    return latest


def _resolve_cli() -> Optional[str]:
    """Find the `meeting-helper` CLI binary path.

    Mirrors the pattern in app.py's _cli_path: prefer the binary next to
    sys.executable (pipx layout), fall back to PATH lookup.
    """
    candidate = Path(sys.executable).parent / "meeting-helper"
    if candidate.exists():
        return str(candidate)
    return shutil.which("meeting-helper")


def _trigger_post_update_restart(new_version: str) -> None:
    """After a successful pipx upgrade, replace daemon + menubar + GUI with
    fresh processes that load the new on-disk binary.

    Order:
    1. Broadcast `app_updated` WS event so the running GUI shows a snackbar
       and closes itself (its WS handler is the friendliest exit path).
    2. Brief pause so the snackbar is visible before we kill the old GUI.
    3. SIGTERM the old menubar (PID-file based). Without this step,
       `_ensure_menubar()` would short-circuit on the next `meeting-helper
       gui` because the old menubar's PID is still alive.
    4. Spawn a fresh `meeting-helper start` — the new daemon binds the port
       once we exit (step 7).
    5. Spawn `meeting-helper gui` — its `_ensure_menubar()` brings up a
       fresh menubar (the old one was killed in step 3), and it spawns a
       fresh GUI window.
    6. Brief pause so the new daemon owns the port before we let go.
    7. SIGTERM ourselves so the new daemon's bind succeeds.

    Failures are logged, never raised. If we can't spawn the new daemon we
    leave the old one running rather than killing the only working process.
    """
    # Step 1: broadcast over WS so the GUI exits via its own friendly path.
    try:
        from meeting_helper.state import state as _state
        from meeting_helper.server.websocket import broadcast as _broadcast
        loop = _state.asyncio_loop
        if loop is not None and loop.is_running():
            asyncio.run_coroutine_threadsafe(
                _broadcast({"type": "app_updated", "version": new_version}),
                loop,
            )
    except Exception as exc:
        logger.warning("auto-update: WS broadcast failed (continuing): %s", exc)

    # Step 2: give the GUI ~3 s to show its snackbar and close cleanly.
    # The GUI's WS handler self-closes after a 3 s delay; if we kill the
    # menubar before that, the user might never see the snackbar.
    time.sleep(3.5)

    # Step 3: SIGTERM the old menubar. Without this, _ensure_menubar()
    # below short-circuits on the still-alive PID and we get an old
    # menubar talking to the new daemon.
    try:
        from meeting_helper.config import MENUBAR_PID_FILE
        if MENUBAR_PID_FILE.exists():
            try:
                old_menubar_pid = int(MENUBAR_PID_FILE.read_text().strip())
                if old_menubar_pid > 0 and old_menubar_pid != os.getpid():
                    logger.info(
                        "auto-update: SIGTERM old menubar pid=%d",
                        old_menubar_pid,
                    )
                    try:
                        os.kill(old_menubar_pid, signal.SIGTERM)
                    except ProcessLookupError:
                        pass
                    except Exception as exc:
                        logger.warning(
                            "auto-update: kill old menubar failed: %s", exc
                        )
            except (ValueError, OSError) as exc:
                logger.warning(
                    "auto-update: read MENUBAR_PID_FILE failed: %s", exc
                )
            # Wipe the PID file regardless; _ensure_menubar reads it.
            try:
                MENUBAR_PID_FILE.unlink(missing_ok=True)
            except Exception:
                pass
    except Exception as exc:
        logger.warning("auto-update: menubar cleanup error: %s", exc)

    # Step 4: spawn the fresh daemon.
    cli = _resolve_cli()
    if cli is None:
        logger.warning(
            "auto-update: could not resolve meeting-helper CLI; skipping restart"
        )
        return

    try:
        subprocess.Popen(
            [cli, "start"],
            start_new_session=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
        )
        logger.info("auto-update: spawned new daemon via %s start", cli)
    except Exception as exc:
        logger.warning("auto-update: spawn new daemon failed: %s", exc)
        return  # Don't kill ourselves if spawn failed.

    # Step 5: spawn fresh menubar + GUI via `meeting-helper gui`. The CLI's
    # _ensure_menubar() spawns a fresh menubar (old one was killed in step 3),
    # then spawns a GUI. Detached so we don't inherit them.
    try:
        subprocess.Popen(
            [cli, "gui"],
            start_new_session=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
        )
        logger.info("auto-update: spawned new menubar + GUI via %s gui", cli)
    except Exception as exc:
        logger.warning("auto-update: spawn new GUI failed: %s", exc)
        # Continue anyway — daemon is the critical piece.

    # Step 6: ~2 s for the new daemon to bind before we exit.
    time.sleep(2.0)

    # Step 7: terminate ourselves so the new daemon's bind succeeds.
    logger.info("auto-update: SIGTERM self after spawning new processes")
    try:
        os.kill(os.getpid(), signal.SIGTERM)
    except Exception as exc:
        logger.warning("auto-update: self-SIGTERM failed: %s", exc)


def _seconds_until_next_midnight(now: datetime) -> float:
    tomorrow = (now + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
    return (tomorrow - now).total_seconds()


def _next_wakeup_seconds() -> float:
    now = datetime.now()
    return min(float(CHECK_INTERVAL_SEC), _seconds_until_next_midnight(now))


async def auto_update_loop() -> None:
    """Periodically attempt an in-place upgrade while the daemon is idle.

    Wakes every 30 minutes or at the next midnight, whichever comes first.
    Skips the attempt if a meeting session is active.
    """
    from meeting_helper.state import state

    logger.info("Auto-updater started (interval=%ds, also at midnight)", CHECK_INTERVAL_SEC)
    while True:
        try:
            await asyncio.sleep(_next_wakeup_seconds())
        except asyncio.CancelledError:
            return

        if state.session_active:
            logger.debug("Auto-update skipped: meeting session active")
            continue

        try:
            await asyncio.to_thread(attempt_update)
        except asyncio.CancelledError:
            return
        except Exception as exc:
            logger.warning("Auto-update tick error: %s", exc)
