"""Settings screen — API keys, provider, transcriber, preferences."""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import TYPE_CHECKING

import flet as ft

if TYPE_CHECKING:
    from meeting_helper.config import Config

TEAL = "#4ec9b0"
MUTED = "#8b949e"
SZ = 13


def _section(title: str) -> ft.Text:
    return ft.Text(title, size=12, weight=ft.FontWeight.W_600, color=MUTED)


_MODEL_SPEED_KEY = {
    "qwen2.5-coder:3b": "fastest",
    "qwen2.5-coder:7b": "fast",
    "qwen2.5-coder:14b": "balanced",
    "qwen2.5-coder:32b": "slow",
    "deepseek-coder-v2:16b": "balanced",
    "codellama:7b": "fast",
    "codellama:13b": "balanced",
}


def _model_speed(model: str) -> str:
    """Return a speed description for a model based on its size."""
    key = _MODEL_SPEED_KEY.get(model)
    if not key:
        import re
        m = re.search(r"(\d+)b", model.lower())
        if m:
            params = int(m.group(1))
            if params <= 3:
                key = "fastest"
            elif params <= 7:
                key = "fast"
            elif params <= 16:
                key = "balanced"
            else:
                key = "slow"
    return key or ""


class SettingsScreen(ft.Column):
    """API keys, AI provider, transcription, model selection, and other preferences."""

    def __init__(self, page: ft.Page, config: "Config"):
        super().__init__(
            expand=True,
            scroll=ft.ScrollMode.AUTO,
            spacing=20,
            horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
        )
        self._page = page
        self._config = config

        # --- API Keys ---
        self._anthropic_key = ft.TextField(
            label="Anthropic API Key", password=True, can_reveal_password=True,
            hint_text="sk-ant-...", value=config.anthropic_api_key,
            border_radius=8, text_size=SZ, expand=True, on_blur=lambda _: self._autosave(),
        )
        self._google_key = ft.TextField(
            label="Google API Key", password=True, can_reveal_password=True,
            hint_text="Optional — for Gemini provider",
            value=config.google_api_key,
            border_radius=8, text_size=SZ, expand=True, on_blur=lambda _: self._autosave(),
        )
        self._deepgram_key = ft.TextField(
            label="Deepgram API Key", password=True, can_reveal_password=True,
            hint_text="Optional — falls back to local Whisper",
            value=config.deepgram_api_key,
            border_radius=8, text_size=SZ, expand=True, on_blur=lambda _: self._autosave(),
        )

        api_card = ft.Card(
            content=ft.Container(
                content=ft.Column([
                    _section("API Keys"),
                    self._anthropic_key,
                    self._google_key,
                    self._deepgram_key,
                ], spacing=10),
                padding=20,
            ),
        )

        # --- AI Provider ---
        self._provider_dropdown = ft.Dropdown(
            label="AI Provider",
            value=config._data.get("preferred_provider", "") or "claude",
            options=[
                ft.dropdown.Option("local", "Ollama (Free)"),
                ft.dropdown.Option("claude", "Claude"),
                ft.dropdown.Option("gemini", "Gemini"),
            ],
            border_radius=8, text_size=SZ, expand=True,
            on_select=self._on_provider_change,
        )
        self._claude_model = ft.Dropdown(
            label="Claude Model",
            value=config._data.get("claude_model", "sonnet"),
            options=[ft.dropdown.Option(m) for m in ["sonnet", "opus", "haiku"]],
            border_radius=8, text_size=SZ, expand=True,
            on_select=lambda _: self._autosave(),
        )
        self._gemini_model = ft.Dropdown(
            label="Gemini Model",
            value=config._data.get("gemini_model", "flash"),
            options=[ft.dropdown.Option(m) for m in ["flash", "pro"]],
            border_radius=8, text_size=SZ, expand=True,
            on_select=lambda _: self._autosave(),
        )
        self._all_local_models = [
            "qwen2.5-coder:3b", "qwen2.5-coder:7b", "qwen2.5-coder:14b", "qwen2.5-coder:32b",
            "deepseek-coder-v2:16b", "codellama:7b", "codellama:13b",
        ]
        self._local_model = ft.Dropdown(
            label="Local Model",
            value=config._data.get("local_model", "qwen2.5-coder:3b"),
            options=[ft.dropdown.Option(key=m, text=f"{m} ({s})") if (s := _model_speed(m)) else ft.dropdown.Option(key=m, text=m) for m in self._all_local_models],
            border_radius=8, text_size=SZ, expand=True,
            on_select=self._on_local_model_change,
        )
        self._ollama_host = ft.TextField(
            label="Ollama Server",
            hint_text="http://localhost:11434 or http://<remote-ip>:11434",
            value=config._data.get("ollama_host", "http://localhost:11434"),
            border_radius=8, text_size=SZ, expand=True,
            on_blur=self._on_ollama_host_change,
        )
        self._download_btn = ft.OutlinedButton(
            "Download", icon=ft.Icons.DOWNLOAD,
            on_click=self._download_model,
        )
        self._download_status = ft.Text("", size=11, color=MUTED)
        self._ollama_status = ft.Text("", size=11, color=MUTED)
        self._model_row = ft.Row([self._provider_dropdown, self._claude_model, self._gemini_model, self._local_model, self._download_btn], spacing=12)
        self._ollama_host_row = ft.Row([self._ollama_host], spacing=12)
        self._installed_models: set[str] = set()
        self._downloading_model = None
        self._refresh_installed_models()
        self._check_active_downloads()
        self._update_model_visibility()
        self._check_ollama_connection()

        provider_card = ft.Card(
            content=ft.Container(
                content=ft.Column([
                    _section("AI Provider"),
                    self._model_row,
                    self._ollama_host_row,
                    self._ollama_status,
                    self._download_status,
                ], spacing=10),
                padding=20,
            ),
        )

        # --- Transcription ---
        self._all_trans_langs = ["en", "es", "pt", "fr", "de", "it", "ja", "ko", "zh", "auto"]
        self._transcriber_dropdown = ft.Dropdown(
            label="Transcriber",
            value=config._data.get("preferred_transcriber", "whisper") or "whisper",
            options=[
                ft.dropdown.Option("whisper", "Whisper (Free)"),
                ft.dropdown.Option("deepgram", "Deepgram"),
            ],
            border_radius=8, text_size=SZ, expand=True,
            on_select=self._on_transcriber_change,
        )
        self._trans_lang_dropdown = ft.Dropdown(
            label="Transcription Language",
            value=config.transcription_language,
            options=[ft.dropdown.Option(lang) for lang in self._all_trans_langs],
            border_radius=8, text_size=SZ, expand=True,
            on_select=lambda _: self._autosave(),
        )
        self._whisper_host = ft.TextField(
            label="Whisper Server",
            hint_text="Empty = local, or http://<remote-ip>:8000",
            value=config._data.get("whisper_host", "") or "http://localhost:8000",
            border_radius=8, text_size=SZ, expand=True,
            on_blur=self._on_whisper_host_change,
        )
        self._whisper_host_row = ft.Row([self._whisper_host], spacing=12)
        self._whisper_status = ft.Text("", size=11, color=MUTED)
        self._update_trans_lang_options()
        self._update_whisper_host_visibility()
        self._check_whisper_connection()

        transcription_card = ft.Card(
            content=ft.Container(
                content=ft.Column([
                    _section("Transcription"),
                    ft.Row([self._transcriber_dropdown, self._trans_lang_dropdown], spacing=12),
                    self._whisper_host_row,
                    self._whisper_status,
                ], spacing=10),
                padding=20,
            ),
        )

        # --- Preferences ---
        self._theme_dropdown = ft.Dropdown(
            label="Theme",
            value=config._data.get("gui_theme", "system"),
            options=[ft.dropdown.Option(t) for t in ["system", "dark", "light"]],
            border_radius=8, text_size=SZ, expand=True,
            on_select=self._on_theme_change,
        )

        self._hm_label = ft.Text(str(int(config.hot_moment_window_minutes)), size=SZ, width=40)
        self._hm_slider = ft.Slider(
            min=1, max=60, divisions=59,
            value=config.hot_moment_window_minutes,
            label="{value}",
            active_color=TEAL,
            on_change=lambda e: self._update_slider_label(e, self._hm_label),
            on_change_end=lambda _: self._autosave(),
            width=250,
        )

        # Auto Start Record
        self._auto_record_check = ft.Checkbox(
            label="Auto Start Record",
            value=config.auto_start_record,
            tooltip="Auto-detect mic usage and start recording",
            on_change=lambda _: self._autosave(),
        )

        # Auto-summarize on meeting end (defaults off)
        self._auto_summarize_check = ft.Checkbox(
            label="Auto-summarize meetings on end",
            value=config.auto_summarize_on_end,
            tooltip="Run an LLM summary on the live transcript when each meeting ends. Costs one model call per meeting.",
            on_change=lambda _: self._autosave(),
        )

        # File picker for recordings dir
        self._file_picker = ft.FilePicker()
        page.services.append(self._file_picker)

        self._rec_input = ft.TextField(
            label="Recordings Directory",
            value=str(config.recordings_dir),
            border_radius=8, text_size=SZ, expand=True,
            on_blur=lambda _: self._autosave(),
        )
        self._rec_warning = ft.Text("", size=11, color=ft.Colors.AMBER_700)

        def _on_rec_dir_change(_e):
            value = (self._rec_input.value or "").strip()
            collision = self._check_recordings_dir_collision(value)
            self._rec_warning.value = (
                f"Already used by workspace '{collision}'. Recordings will mix together."
                if collision else ""
            )
            try:
                self._rec_warning.update()
            except Exception:
                pass

        self._rec_input.on_change = _on_rec_dir_change
        browse_btn = ft.OutlinedButton(
            "Browse", icon=ft.Icons.FOLDER_OPEN,
            on_click=self._browse_recordings,
        )

        prefs_card = ft.Card(
            content=ft.Container(
                content=ft.Column([
                    _section("Preferences"),
                    self._auto_record_check,
                    ft.Text("Auto-detect mic usage and start recording when a meeting is detected",
                            size=11, color=ft.Colors.ON_SURFACE_VARIANT),
                    self._auto_summarize_check,
                    ft.Text("When a meeting ends, run an LLM summary on the live transcript (one model call per meeting)",
                            size=11, color=ft.Colors.ON_SURFACE_VARIANT),
                    ft.Row([self._theme_dropdown], spacing=12),
                    ft.Row([
                        ft.Text("Hot Moment Window (min)", size=SZ, width=180),
                        self._hm_slider,
                        self._hm_label,
                    ], vertical_alignment=ft.CrossAxisAlignment.CENTER),
                    ft.Text(
                        "How long after your last engagement (speech, query, brief) "
                        "TopicWorker keeps consuming the other party's speech.",
                        size=11, color=ft.Colors.ON_SURFACE_VARIANT,
                    ),
                    ft.Row([self._rec_input, browse_btn], spacing=10),
                    self._rec_warning,
                ], spacing=14),
                padding=20,
            ),
        )

        # --- Menubar ---
        self._menubar_check = ft.Checkbox(
            label="Show Menubar Icon",
            value=config._data.get("show_menubar_icon", True),
            on_change=lambda _: self._autosave(),
        )
        self._menubar_icon_dd = ft.Dropdown(
            label="Icon",
            value=config._data.get("menubar_icon", "MH"),
            options=[ft.dropdown.Option(k) for k in ["MH", "◆", "⚡", "●", "▶", "☰"]],
            border_radius=8, text_size=SZ, width=100,
            on_select=lambda _: self._autosave(),
        )
        self._menubar_plist_path = Path.home() / "Library" / "LaunchAgents" / "com.meeting-helper.menubar.plist"
        self._autostart_check = ft.Checkbox(
            label="Autostart on Login",
            value=self._menubar_plist_path.exists(),
            on_change=lambda _: self._autosave(),
        )
        self._prev_menubar_enabled = config._data.get("show_menubar_icon", True)
        self._prev_menubar_icon = config._data.get("menubar_icon", "MH")

        menubar_card = ft.Card(
            content=ft.Container(
                content=ft.Column([
                    _section("Menubar"),
                    ft.Row([self._menubar_check, self._menubar_icon_dd], spacing=12),
                    self._autostart_check,
                    ft.Text("Launch the menubar icon on login for quick access",
                            size=11, color=ft.Colors.ON_SURFACE_VARIANT),
                ], spacing=10),
                padding=20,
            ),
        )

        # --- MCP Servers ---
        current_mcp = config.local_todo_mcp

        self._mcp_type = ft.Dropdown(
            label="Transport",
            value=current_mcp.get("type", "stdio"),
            options=[
                ft.dropdown.Option(key="stdio", text="Stdio (subprocess)"),
                ft.dropdown.Option(key="http", text="HTTP (remote URL)"),
            ],
            border_radius=8, text_size=SZ, width=220,
            on_select=lambda _: self._on_mcp_type_change(),
        )

        # Stdio fields
        self._mcp_command = ft.TextField(
            label="Command",
            hint_text="e.g. npx",
            value=current_mcp.get("command", ""),
            border_radius=8, text_size=SZ, expand=True,
            on_blur=lambda _: self._autosave(),
        )
        self._mcp_args = ft.TextField(
            label="Args (space-separated)",
            hint_text="e.g. @local-todo/mcp",
            value=" ".join(current_mcp.get("args", [])),
            border_radius=8, text_size=SZ, expand=True,
            on_blur=lambda _: self._autosave(),
        )
        env_lines = "\n".join(f"{k}={v}" for k, v in (current_mcp.get("env") or {}).items())
        self._mcp_env = ft.TextField(
            label="Environment (KEY=value, one per line)",
            hint_text="e.g. LOCAL_TODO_DB=/path/to/db",
            value=env_lines,
            multiline=True, min_lines=2, max_lines=6,
            border_radius=8, text_size=SZ, expand=True,
            on_blur=lambda _: self._autosave(),
        )
        self._mcp_stdio_col = ft.Column([
            self._mcp_command, self._mcp_args, self._mcp_env,
        ], spacing=10)

        # HTTP fields
        self._mcp_url = ft.TextField(
            label="URL",
            hint_text="http://host/path/mcp",
            value=current_mcp.get("url", ""),
            border_radius=8, text_size=SZ, expand=True,
            on_blur=lambda _: self._autosave(),
        )
        header_lines = "\n".join(f"{k}={v}" for k, v in (current_mcp.get("headers") or {}).items())
        self._mcp_headers = ft.TextField(
            label="Headers (KEY=value, one per line)",
            hint_text="e.g. Authorization=Bearer ltb_xxxx",
            value=header_lines,
            multiline=True, min_lines=2, max_lines=6,
            border_radius=8, text_size=SZ, expand=True,
            on_blur=lambda _: self._autosave(),
        )
        self._mcp_http_col = ft.Column([
            self._mcp_url, self._mcp_headers,
        ], spacing=10)

        # Initial visibility
        is_http = current_mcp.get("type") == "http"
        self._mcp_stdio_col.visible = not is_http
        self._mcp_http_col.visible = is_http

        mcp_card = ft.Card(
            content=ft.Container(
                content=ft.Column([
                    _section("MCP Servers"),
                    ft.Text("Used by Generate Standup Brief and 2× Cmd hotkey grounding.",
                            size=11, color=ft.Colors.ON_SURFACE_VARIANT),
                    self._mcp_type,
                    self._mcp_stdio_col,
                    self._mcp_http_col,
                ], spacing=10),
                padding=20,
            ),
        )

        # --- Save ---
        self._save_status = ft.Text("", size=11, color=MUTED)

        self.controls = [
            ft.Container(
                content=ft.Column([
                    ft.Text("Settings", size=22, weight=ft.FontWeight.W_600),
                    api_card,
                    provider_card,
                    transcription_card,
                    prefs_card,
                    menubar_card,
                    mcp_card,
                    self._save_status,
                ], spacing=14, horizontal_alignment=ft.CrossAxisAlignment.STRETCH),
                padding=30,
            ),
        ]

    # ----- Provider visibility -----

    def _update_model_visibility(self):
        prov = self._provider_dropdown.value
        self._claude_model.visible = prov == "claude"
        self._gemini_model.visible = prov == "gemini"
        self._local_model.visible = prov == "local"
        self._ollama_host_row.visible = prov == "local"
        self._ollama_status.visible = prov == "local"
        self._update_download_btn()

    def _on_provider_change(self, e):
        self._update_model_visibility()
        self._autosave()
        self._page.update()

    # ----- Ollama connection & models -----

    def _on_ollama_host_change(self, e):
        self._autosave()
        self._check_ollama_connection()
        self._refresh_installed_models()
        # Update dropdown options with models from the (possibly remote) server
        remote_models = list(self._installed_models)
        if remote_models:
            combined = list(dict.fromkeys(self._all_local_models + remote_models))
            self._local_model.options = [ft.dropdown.Option(key=m, text=f"{m} ({s})") if (s := _model_speed(m)) else ft.dropdown.Option(key=m, text=m) for m in combined]
        self._update_download_btn()
        self._page.update()

    def _check_ollama_connection(self):
        host = (self._ollama_host.value or "http://localhost:11434").strip()
        try:
            import urllib.request
            url = f"{host.rstrip('/')}/api/tags"
            urllib.request.urlopen(url, timeout=3)
            self._ollama_status.value = f"● Connected — {host}"
            self._ollama_status.color = TEAL
        except Exception:
            self._ollama_status.value = f"● Not reachable — {host}"
            self._ollama_status.color = "#f14c4c"

    def _refresh_installed_models(self):
        from meeting_helper.ai.ollama_utils import get_installed_models
        host = getattr(self, "_ollama_host", None)
        host_val = host.value if host else "http://localhost:11434"
        self._installed_models = set(get_installed_models(host=host_val))

    def _is_model_installed(self, model: str) -> bool:
        return model in self._installed_models

    def _is_remote_host(self) -> bool:
        host = (self._ollama_host.value or "").strip()
        return bool(host) and "localhost" not in host and "127.0.0.1" not in host and host != "http://localhost:11434"

    def _update_download_btn(self):
        model = self._local_model.value or ""
        # Don't overwrite if a download is in progress
        if self._downloading_model:
            self._download_btn.visible = False
            self._download_status.visible = self._local_model.visible
            return
        installed = self._is_model_installed(model)
        self._download_btn.visible = self._local_model.visible and not installed
        self._download_btn.disabled = False
        if installed:
            self._download_status.value = f"{model} — ready"
            self._download_status.color = TEAL
        else:
            self._download_status.value = f"{model} — not downloaded"
            self._download_status.color = "#d29922"
        self._download_status.visible = self._local_model.visible

    def _on_local_model_change(self, e):
        self._update_download_btn()
        self._autosave()
        self._page.update()

    def _check_active_downloads(self):
        """If an ollama pull is running, show status and start polling."""
        try:
            import subprocess as _sp
            r = _sp.run(["pgrep", "-af", "ollama pull"], capture_output=True, text=True, timeout=3)
            if r.returncode == 0 and r.stdout.strip():
                for line in r.stdout.strip().split("\n"):
                    parts = line.split("ollama pull ")
                    if len(parts) > 1:
                        downloading = parts[1].strip()
                        self._downloading_model = downloading
                        self._download_status.value = f"{downloading} — downloading..."
                        self._download_status.color = TEAL
                        self._download_status.visible = True
                        self._download_btn.visible = False
                        self._download_btn.disabled = True
                        self._page.run_thread(self._poll_download, downloading)
                        break
        except Exception:
            pass

    def _poll_download(self, model: str):
        """Poll until model appears in ollama list."""
        import subprocess as _sp
        import time
        for _ in range(360):
            time.sleep(3)
            try:
                r = _sp.run(["ollama", "list"], capture_output=True, text=True, timeout=5)
                if model in r.stdout:
                    self._downloading_model = None
                    self._refresh_installed_models()
                    self._update_download_btn()
                    try:
                        self._page.update()
                    except Exception:
                        pass
                    return
                r2 = _sp.run(["pgrep", "-f", f"ollama pull {model}"], capture_output=True, text=True)
                if r2.returncode != 0:
                    self._downloading_model = None
                    self._download_status.value = f"{model} — download failed"
                    self._download_status.color = "#f14c4c"
                    self._download_btn.disabled = False
                    try:
                        self._page.update()
                    except Exception:
                        pass
                    return
            except Exception:
                pass

    # ----- Model download -----

    def _download_model(self, e):
        model = self._local_model.value or "qwen2.5-coder:3b"
        self._download_btn.disabled = True
        self._download_status.value = f"Downloading {model}..."
        self._download_status.color = TEAL
        self._page.update()

        if self._is_remote_host():
            self._page.run_thread(lambda: self._do_download_remote(model))
        else:
            self._page.run_thread(lambda: self._do_download_local(model))

    def _do_download_remote(self, model: str):
        """Pull model on a remote Ollama server via POST /api/pull."""
        import json
        import urllib.request

        host = (self._ollama_host.value or "").strip().rstrip("/")
        try:
            body = json.dumps({"name": model, "stream": True}).encode()
            req = urllib.request.Request(
                f"{host}/api/pull", data=body,
                headers={"Content-Type": "application/json"},
            )
            self._downloading_model = model
            self._download_status.value = f"{model} — downloading..."
            self._download_btn.visible = False
            try:
                self._page.update()
            except Exception:
                pass

            with urllib.request.urlopen(req, timeout=1800) as resp:
                for line in resp:
                    if not line.strip():
                        continue
                    try:
                        chunk = json.loads(line)
                        status = chunk.get("status", "")
                        total = chunk.get("total", 0)
                        completed = chunk.get("completed", 0)
                        if total and completed:
                            pct = int(completed / total * 100)
                            self._download_status.value = f"{model} — {status} {pct}%"
                        elif status:
                            self._download_status.value = f"{model} — {status}"
                        try:
                            self._page.update()
                        except Exception:
                            pass
                    except json.JSONDecodeError:
                        pass

            self._downloading_model = None
            self._refresh_installed_models()
            self._update_download_btn()
            try:
                self._page.update()
            except Exception:
                pass

        except Exception as exc:
            self._downloading_model = None
            self._download_status.value = f"Error: {exc}"
            self._download_status.color = "#f14c4c"
            self._download_btn.disabled = False
            try:
                self._page.update()
            except Exception:
                pass

    def _do_download_local(self, model: str):
        """Pull model on local Ollama via subprocess."""
        import subprocess as _sp

        try:
            from meeting_helper.ai.ollama_utils import is_ollama_installed, start_ollama
            if not is_ollama_installed():
                self._download_status.value = "Ollama not installed. Run: brew install ollama"
                self._download_status.color = "#f14c4c"
                self._download_btn.disabled = False
                try:
                    self._page.update()
                except Exception:
                    pass
                return

            start_ollama()

            _sp.Popen(["ollama", "pull", model], start_new_session=True,
                       stdout=_sp.DEVNULL, stderr=_sp.DEVNULL)

            self._downloading_model = model
            self._download_status.value = f"{model} — downloading..."
            self._download_btn.visible = False
            try:
                self._page.update()
            except Exception:
                pass

            self._poll_download(model)

        except Exception as exc:
            self._download_status.value = f"Error: {exc}"
            self._download_status.color = "#f14c4c"
            self._download_btn.disabled = False
            try:
                self._page.update()
            except Exception:
                pass

    # ----- Transcription -----

    def _update_trans_lang_options(self):
        """Hide 'auto' language when Deepgram is selected (requires explicit language)."""
        is_deepgram = self._transcriber_dropdown.value == "deepgram"
        langs = [l for l in self._all_trans_langs if l != "auto"] if is_deepgram else self._all_trans_langs
        self._trans_lang_dropdown.options = [ft.dropdown.Option(l) for l in langs]
        if is_deepgram and self._trans_lang_dropdown.value == "auto":
            self._trans_lang_dropdown.value = "en"

    def _on_transcriber_change(self, e):
        self._update_trans_lang_options()
        self._update_whisper_host_visibility()
        self._autosave()
        self._page.update()

    def _on_mcp_type_change(self):
        is_http = (self._mcp_type.value or "stdio") == "http"
        self._mcp_stdio_col.visible = not is_http
        self._mcp_http_col.visible = is_http
        self._page.update()
        self._autosave()

    def _on_whisper_host_change(self, e):
        self._autosave()
        self._check_whisper_connection()
        self._page.update()

    def _update_whisper_host_visibility(self):
        """Show whisper host field only when Whisper is selected."""
        is_whisper = self._transcriber_dropdown.value == "whisper"
        self._whisper_host_row.visible = is_whisper
        self._whisper_status.visible = is_whisper

    def _check_whisper_connection(self):
        host = (self._whisper_host.value or "http://localhost:8000").strip()
        try:
            import urllib.request
            urllib.request.urlopen(f"{host.rstrip('/')}/health", timeout=3)
            self._whisper_status.value = f"● Connected — {host}"
            self._whisper_status.color = TEAL
        except Exception:
            self._whisper_status.value = f"● Not reachable — {host}"
            self._whisper_status.color = "#f14c4c"

    # ----- Theme / sliders / browse -----

    def _on_theme_change(self, e):
        theme_map = {"dark": ft.ThemeMode.DARK, "light": ft.ThemeMode.LIGHT, "system": ft.ThemeMode.SYSTEM}
        self._page.theme_mode = theme_map.get(e.control.value, ft.ThemeMode.SYSTEM)
        self._autosave()
        self._page.update()

    def _update_slider_label(self, e, label: ft.Text, step: int = 1):
        val = int(round(e.control.value / step) * step) if step > 1 else int(e.control.value)
        label.value = str(val)
        self._autosave()
        self._page.update()

    async def _browse_recordings(self, e):
        path = await self._file_picker.get_directory_path(
            dialog_title="Select Recordings Directory"
        )
        if path:
            self._rec_input.value = path
            self._autosave()
            self._page.update()

    def _check_recordings_dir_collision(self, path: str) -> str | None:
        """Return name of another workspace using the same recordings_dir, or None."""
        from meeting_helper.config import (
            list_workspaces, load_state, get_config,
        )
        if not path:
            return None
        active = load_state()["active_workspace"]
        for name in list_workspaces():
            if name == active:
                continue
            try:
                other_dir = str(get_config(workspace=name).recordings_dir)
            except Exception:
                continue
            if other_dir == path:
                return name
        return None

    # ----- Auto-save -----

    def _autosave(self):
        """Save all settings to config immediately.

        Refuses to write if the form's bound workspace no longer matches the
        currently active workspace — prevents stale form state from
        overwriting another workspace's JSON during/after a workspace switch.
        """
        from meeting_helper.config import load_state, workspace_path
        try:
            active = load_state()["active_workspace"]
            if self._config.config_path != workspace_path(active):
                return  # workspace switched; let on_workspace_changed sync first
        except Exception:
            return

        self._config.anthropic_api_key = (self._anthropic_key.value or "").strip()
        self._config.google_api_key = (self._google_key.value or "").strip()
        self._config.deepgram_api_key = (self._deepgram_key.value or "").strip()
        self._config._data["gui_theme"] = self._theme_dropdown.value or "system"

        # AI Provider
        prov = self._provider_dropdown.value
        self._config.preferred_provider = prov if prov != "claude" else ""
        self._config.claude_model = self._claude_model.value or "sonnet"
        self._config.gemini_model = self._gemini_model.value or "flash"
        self._config.local_model = self._local_model.value or "qwen2.5-coder:3b"
        self._config.ollama_host = (self._ollama_host.value or "http://localhost:11434").strip()

        # Transcription
        trans = self._transcriber_dropdown.value
        self._config.preferred_transcriber = trans if trans != "auto" else ""
        self._config.whisper_host = (self._whisper_host.value or "").strip()
        self._config.transcription_language = self._trans_lang_dropdown.value or "auto"

        # Preferences
        self._config.auto_start_record = self._auto_record_check.value
        self._config.auto_summarize_on_end = bool(self._auto_summarize_check.value)
        self._config.hot_moment_window_minutes = float(self._hm_slider.value)
        self._config.recordings_dir = (self._rec_input.value or "").strip()

        # Menubar
        new_menubar_enabled = self._menubar_check.value
        new_menubar_icon = self._menubar_icon_dd.value or "MH"
        self._config._data["show_menubar_icon"] = new_menubar_enabled
        self._config._data["menubar_icon"] = new_menubar_icon

        # MCP Servers
        mcp_type = (self._mcp_type.value or "stdio").strip().lower()
        if mcp_type not in ("stdio", "http"):
            mcp_type = "stdio"

        env_text = (self._mcp_env.value or "").strip()
        env_dict: dict[str, str] = {}
        if env_text:
            for line in env_text.splitlines():
                line = line.strip()
                if "=" in line:
                    k, v = line.split("=", 1)
                    env_dict[k.strip()] = v.strip()

        header_text = (self._mcp_headers.value or "").strip()
        header_dict: dict[str, str] = {}
        if header_text:
            for line in header_text.splitlines():
                line = line.strip()
                if "=" in line:
                    k, v = line.split("=", 1)
                    header_dict[k.strip()] = v.strip()

        args_str = (self._mcp_args.value or "").strip()
        self._config.local_todo_mcp = {
            "type": mcp_type,
            "command": (self._mcp_command.value or "").strip(),
            "args": args_str.split() if args_str else [],
            "env": env_dict,
            "url": (self._mcp_url.value or "").strip(),
            "headers": header_dict,
        }

        self._config.setup_complete = True
        self._config.save()

        # Push live tunables to the running daemon (fire-and-forget).
        # The daemon holds its own in-memory Config; without this POST it
        # keeps reading the value it had at startup, even after we wrote the
        # new value to disk.
        self._page.run_thread(self._push_live_config_to_daemon)

        # Restart menubar only when its settings changed
        if (new_menubar_enabled != self._prev_menubar_enabled
                or new_menubar_icon != self._prev_menubar_icon):
            self._prev_menubar_enabled = new_menubar_enabled
            self._prev_menubar_icon = new_menubar_icon
            self._restart_menubar()

        # Force-disable autostart if menubar is disabled
        if not new_menubar_enabled:
            self._autostart_check.value = False
        self._update_autostart()

        self._save_status.value = "Saved"
        try:
            self._page.update()
        except Exception:
            pass

    def _push_live_config_to_daemon(self) -> None:
        """POST live tunables to the daemon's in-memory config.

        The daemon and the GUI are separate processes — disk writes alone
        don't update the daemon. Fields here are ones the daemon reads on
        every event (TopicWorker, brief, query) where staleness is visible.
        """
        import json as _json
        import urllib.request as _urlreq
        body = _json.dumps({
            "hot_moment_window_minutes": float(self._hm_slider.value),
            "local_todo_mcp": dict(self._config.local_todo_mcp),
        }).encode()
        try:
            req = _urlreq.Request(
                f"http://127.0.0.1:{self._config.port}/config",
                data=body,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            _urlreq.urlopen(req, timeout=5)
        except Exception:
            pass

    def _restart_menubar(self):
        import signal as _sig
        import subprocess as _sp
        from meeting_helper.config import MENUBAR_PID_FILE
        if MENUBAR_PID_FILE.exists():
            try:
                pid = int(MENUBAR_PID_FILE.read_text().strip())
                os.kill(pid, _sig.SIGTERM)
            except Exception:
                pass
            MENUBAR_PID_FILE.unlink(missing_ok=True)
            import time; time.sleep(0.3)
        if self._config._data.get("show_menubar_icon", True):
            _sp.Popen(
                [sys.executable, "-m", "meeting_helper.menubar"],
                start_new_session=True,
                stdout=_sp.DEVNULL, stderr=_sp.DEVNULL, stdin=_sp.DEVNULL,
            )

    def _update_autostart(self):
        import shutil
        import subprocess as _sp
        if self._autostart_check.value:
            cli = shutil.which("meeting-helper") or str(Path(sys.executable).parent / "meeting-helper")
            plist_content = f"""\
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.meeting-helper.menubar</string>
    <key>ProgramArguments</key>
    <array>
        <string>{cli}</string>
        <string>menubar</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <false/>
</dict>
</plist>"""
            self._menubar_plist_path.parent.mkdir(parents=True, exist_ok=True)
            self._menubar_plist_path.write_text(plist_content)
            _sp.run(["launchctl", "load", str(self._menubar_plist_path)], capture_output=True)
        else:
            if self._menubar_plist_path.exists():
                _sp.run(["launchctl", "unload", str(self._menubar_plist_path)], capture_output=True)
                self._menubar_plist_path.unlink(missing_ok=True)

    def on_workspace_changed(self) -> None:
        from meeting_helper.config import get_config
        self._config = get_config()
        cfg = self._config
        # Re-sync all visible widget values from the new workspace's config.
        # Using getattr+try wrappers keeps this resilient if a widget is missing.
        def _set(attr: str, value):
            widget = getattr(self, attr, None)
            if widget is None:
                return
            try:
                widget.value = value
            except Exception:
                pass

        _set("_anthropic_key", cfg.anthropic_api_key)
        _set("_google_key", cfg.google_api_key)
        _set("_deepgram_key", cfg.deepgram_api_key)
        _set("_provider_dropdown", cfg._data.get("preferred_provider", ""))
        _set("_claude_model", cfg._data.get("claude_model", "sonnet"))
        _set("_gemini_model", cfg._data.get("gemini_model", "flash"))
        _set("_local_model", cfg.local_model)
        _set("_ollama_host", cfg.ollama_host)
        _set("_transcriber_dropdown", cfg._data.get("preferred_transcriber", ""))
        _set("_trans_lang_dropdown", cfg.transcription_language)
        _set("_whisper_host", cfg.whisper_host)
        _set("_theme_dropdown", cfg._data.get("gui_theme", "system"))
        _set("_hm_slider", cfg.hot_moment_window_minutes)
        _set("_hm_label", str(int(cfg.hot_moment_window_minutes)))
        _set("_auto_record_check", cfg.auto_start_record)
        _set("_auto_summarize_check", cfg.auto_summarize_on_end)
        _set("_rec_input", str(cfg.recordings_dir))
        _set("_menubar_check", cfg.show_menubar_icon)
        _set("_menubar_icon_dd", cfg.menubar_icon)

        # MCP Servers
        mcp = cfg.local_todo_mcp
        _set("_mcp_type", mcp.get("type", "stdio"))
        _set("_mcp_command", mcp.get("command", ""))
        _set("_mcp_args", " ".join(mcp.get("args", [])))
        _set("_mcp_env", "\n".join(f"{k}={v}" for k, v in (mcp.get("env") or {}).items()))
        _set("_mcp_url", mcp.get("url", ""))
        _set("_mcp_headers", "\n".join(f"{k}={v}" for k, v in (mcp.get("headers") or {}).items()))
        is_http = mcp.get("type") == "http"
        for attr, visible in (("_mcp_stdio_col", not is_http), ("_mcp_http_col", is_http)):
            col = getattr(self, attr, None)
            if col is not None:
                col.visible = visible

        try:
            self.update()
        except Exception:
            pass
