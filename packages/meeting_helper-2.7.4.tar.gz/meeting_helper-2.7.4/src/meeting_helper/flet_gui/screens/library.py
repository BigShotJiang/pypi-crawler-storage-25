"""Library screen — unified list of meeting summaries and notes the agent can learn from.

Replaces the previous Recordings screen. List on the left, detail panel on
the right. Per-row 📚 / ⭐ toggles and kind chip; detail panel handles
play/transcribe/summarize for meetings and an in-place markdown editor
for notes.
"""

from __future__ import annotations

import subprocess
from datetime import date as _date
from pathlib import Path
from typing import TYPE_CHECKING

import flet as ft

from meeting_helper.flet_gui.components.audio_player import AudioPlayer
from meeting_helper.library_retrieval import LibraryItem, list_artifacts

if TYPE_CHECKING:
    from meeting_helper.config import Config

TEAL = "#4ec9b0"
ERROR_RED = "#f14c4c"
KB_ACTIVE = "#9cdcfe"


def _relative_date(date_str: str) -> str:
    """Return a short relative-ish form: 'Today', 'Yesterday', 'May 8', or '2024-12-30'.

    The ISO date stays for entries older than ~6 months — once people stop
    recognizing the relative reference, the absolute date is the cleaner read.
    """
    if not date_str:
        return ""
    try:
        d = _date.fromisoformat(date_str)
    except ValueError:
        return date_str
    today = _date.today()
    delta = (today - d).days
    if delta == 0:
        return "Today"
    if delta == 1:
        return "Yesterday"
    if 0 <= delta < 7:
        return d.strftime("%a")  # 'Mon', 'Tue', ...
    if 0 <= delta < 180 and d.year == today.year:
        return d.strftime("%b %-d")  # 'May 8'
    return date_str  # full ISO for old / future entries


def _time_from_meeting_id(item_id: str) -> str:
    """Extract HH:MM from a meeting id stem like '2026-05-08_193029_Daily'.

    Returns '' for ids that don't match the expected timestamp shape.
    """
    if not item_id:
        return ""
    parts = item_id.split("_", 2)
    if len(parts) < 2:
        return ""
    time_part = parts[1]
    if len(time_part) < 4 or not time_part[:4].isdigit():
        return ""
    return f"{time_part[0:2]}:{time_part[2:4]}"


def _status_pill(label: str, color: str) -> ft.Control:
    """Compact text pill ('TXT', 'SUM', 'KB') for row status indicators."""
    return ft.Container(
        content=ft.Text(
            label,
            size=9,
            weight=ft.FontWeight.W_700,
            color=color,
        ),
        padding=ft.Padding.symmetric(horizontal=6, vertical=2),
        bgcolor=ft.Colors.with_opacity(0.15, color),
        border_radius=8,
    )


def _format_duration(mp3: Path) -> str:
    """Return a unit-suffixed duration ('35s', '4m 23s', '1h 12m').

    Units (rather than the older H:MM:SS shape) keep the duration visually
    distinct from the time-of-day in the row metadata — `00:08` (time)
    next to `4:23` (duration) was confusing.
    """
    try:
        result = subprocess.run(
            ["ffprobe", "-v", "quiet", "-show_entries", "format=duration",
             "-of", "default=noprint_wrappers=1:nokey=1", str(mp3)],
            capture_output=True, text=True, timeout=3,
        )
        if result.returncode == 0:
            secs = int(float(result.stdout.strip()))
            mins, s = divmod(secs, 60)
            hrs, mins = divmod(mins, 60)
            if hrs:
                return f"{hrs}h {mins}m"
            if mins:
                return f"{mins}m {s:02d}s"
            return f"{s}s"
    except Exception:
        pass
    return "—"


def _timestamp_prefix(stem: str) -> str:
    """Return '2026-05-08_193029_' if stem starts with that pattern, else ''."""
    parts = stem.split("_", 2)
    if len(parts) >= 2 and len(parts[0]) == 10 and "-" in parts[0]:
        return f"{parts[0]}_{parts[1]}_"
    return ""


class LibraryScreen(ft.Column):
    """Unified Meetings + Notes library. Filter chips + list + detail panel."""

    def __init__(self, page: ft.Page, config: "Config"):
        super().__init__(expand=True)
        self._page = page
        self._raw_config = config
        self._recordings_dir = Path(config.recordings_dir)
        self._filter = "all"  # "all" | "meetings" | "notes"
        self._selected_id: str | None = None
        self._items: list[LibraryItem] = []
        self._duration_cache: dict[str, str] = {}
        self._row_by_id: dict[str, ft.Container] = {}
        # Source of truth for in-flight transcribe/summarize work so the
        # buttons render correctly across detail rebuilds (re-entry).
        self._transcribing_ids: set[str] = set()
        self._summarizing_ids: set[str] = set()

        # --- Header ---
        self._all_chip = ft.FilledTonalButton(
            "All", on_click=lambda e: self._set_filter("all"),
        )
        self._meet_chip = ft.FilledTonalButton(
            "Meetings", on_click=lambda e: self._set_filter("meetings"),
        )
        self._notes_chip = ft.FilledTonalButton(
            "Notes", on_click=lambda e: self._set_filter("notes"),
        )
        self._kb_count_label = ft.Text("📚 in KB: 0", size=13)
        self._add_note_btn = ft.ElevatedButton(
            "+ Add Note",
            icon=ft.Icons.NOTE_ADD,
            on_click=self._on_add_note_click,
        )
        header = ft.Row(
            [
                self._all_chip,
                self._meet_chip,
                self._notes_chip,
                ft.Container(expand=True),
                self._kb_count_label,
                self._add_note_btn,
            ],
            spacing=8,
        )

        # --- List + detail layout ---
        self._list_view = ft.ListView(expand=True, spacing=4, padding=8)
        self._detail_view = ft.Container(
            content=ft.Text("Select an item to view details", italic=True),
            padding=20,
            expand=True,
        )
        self._player = AudioPlayer(page)

        body = ft.Row(
            [
                ft.Container(content=self._list_view, expand=2),
                ft.VerticalDivider(width=1),
                ft.Container(content=self._detail_view, expand=3),
            ],
            expand=True,
        )

        self.controls = [header, body]
        self._sync_chip_styling()

    def did_mount(self) -> None:
        self._refresh()

    def _sync_chip_styling(self) -> None:
        active = ft.ButtonStyle(
            bgcolor=ft.Colors.PRIMARY_CONTAINER,
            color=ft.Colors.ON_PRIMARY_CONTAINER,
        )
        inactive = ft.ButtonStyle(
            bgcolor=ft.Colors.SURFACE_CONTAINER_HIGH,
            color=ft.Colors.ON_SURFACE_VARIANT,
        )
        self._all_chip.style = active if self._filter == "all" else inactive
        self._meet_chip.style = active if self._filter == "meetings" else inactive
        self._notes_chip.style = active if self._filter == "notes" else inactive

    # --- Data refresh ---
    def _refresh(self) -> None:
        self._items = list_artifacts(recordings_dir=self._recordings_dir)
        kb_count = sum(1 for i in self._items if self._is_kb(i))
        self._kb_count_label.value = f"📚 in KB: {kb_count}"
        self._render_list()
        try:
            self.update()
        except (RuntimeError, AssertionError):
            pass

    def _duration_for(self, item: LibraryItem) -> str:
        if item.kind != "meeting":
            return ""
        if item.id in self._duration_cache:
            return self._duration_cache[item.id]
        # Don't ffprobe synchronously during list render — that blocks the UI.
        # Return empty for now; a background pre-warm runs after _select fires.
        return ""

    def _is_kb(self, item: LibraryItem) -> bool:
        if item.kind == "meeting":
            kb_filename = f"{item.id}.summary.txt"
        else:
            kb_filename = item.note_filename
        if not kb_filename:
            return False
        return self._raw_config.is_kb(kb_filename)

    def _is_fav(self, item: LibraryItem) -> bool:
        # Favorites are keyed by mp3 filename for meetings, note filename for notes.
        if item.kind == "meeting":
            mp3_name = f"{item.id}.mp3"
            return self._raw_config.is_favorite(mp3_name)
        return self._raw_config.is_favorite(item.note_filename)

    # --- Rendering ---
    def _render_list(self) -> None:
        self._row_by_id = {}
        rows = []
        for item in self._filtered_items():
            row = self._build_row(item)
            self._row_by_id[item.id] = row
            rows.append(row)
        self._list_view.controls = rows

    def _refresh_row(self, item_id: str) -> None:
        """Rebuild and swap the single row for `item_id` if it's in the list."""
        if item_id not in self._row_by_id:
            return
        item = next((i for i in self._items if i.id == item_id), None)
        if item is None:
            return
        new_row = self._build_row(item)
        # Highlight if currently selected
        if self._selected_id == item_id:
            new_row.bgcolor = ft.Colors.PRIMARY_CONTAINER
        # Find index in the listview and swap
        try:
            idx = self._list_view.controls.index(self._row_by_id[item_id])
            self._list_view.controls[idx] = new_row
            self._row_by_id[item_id] = new_row
            self._list_view.update()
        except Exception:
            pass
        # Refresh KB count label (cheap)
        kb_count = sum(1 for i in self._items if self._is_kb(i))
        self._kb_count_label.value = f"📚 in KB: {kb_count}"
        try:
            self._kb_count_label.update()
        except Exception:
            pass

    def _filtered_items(self) -> list[LibraryItem]:
        if self._filter == "meetings":
            return [i for i in self._items if i.kind == "meeting"]
        if self._filter == "notes":
            return [i for i in self._items if i.kind == "note"]
        return self._items

    def _build_row(self, item: LibraryItem) -> ft.Control:
        # Status pills (replaces emoji glyphs). Audio existence dropped —
        # every meeting has an mp3, so the pill carried no info.
        pills: list[ft.Control] = []
        if item.kind == "meeting":
            if item.has_transcript or item.has_live:
                pills.append(_status_pill("TXT", ft.Colors.OUTLINE))
            if item.has_summary:
                pills.append(_status_pill("SUM", "#f6c06b"))
        if self._is_kb(item):
            pills.append(_status_pill("KB", KB_ACTIVE))

        is_fav = self._is_fav(item)
        is_kb = self._is_kb(item)

        star_icon = ft.IconButton(
            icon=ft.Icons.STAR if is_fav else ft.Icons.STAR_OUTLINE,
            icon_color="#f6c06b" if is_fav else ft.Colors.ON_SURFACE_VARIANT,
            tooltip="Favorite",
            icon_size=18,
            on_click=lambda e, it=item: self._toggle_favorite(it),
        )
        kb_icon = ft.IconButton(
            icon=ft.Icons.BOOKMARK if is_kb else ft.Icons.BOOKMARK_OUTLINE,
            icon_color=KB_ACTIVE if is_kb else ft.Colors.ON_SURFACE_VARIANT,
            tooltip="Include in agent knowledge base",
            icon_size=18,
            on_click=lambda e, it=item: self._toggle_kb(it),
        )

        # Title row: title text on the left (expanding), pills on the right.
        title_text = ft.Text(
            item.title,
            size=14,
            weight=ft.FontWeight.W_500,
            expand=True,
            no_wrap=True,
            overflow=ft.TextOverflow.ELLIPSIS,
        )
        pills_row = ft.Row(pills, spacing=4, tight=True)

        # Metadata row (date · time · duration · kind for note kind only).
        meta_parts: list[str] = []
        if item.kind == "meeting":
            rel = _relative_date(item.date)
            if rel:
                meta_parts.append(rel)
            tod = _time_from_meeting_id(item.id)
            if tod:
                meta_parts.append(tod)
            dur = self._duration_for(item)
            if dur:
                meta_parts.append(dur)
        else:
            # Notes don't have glyphs to imply kind, so a tiny "Note" tag
            # sits in the metadata line.
            meta_parts.append("Note")
        meta_text = ft.Text(
            "  ·  ".join(meta_parts),
            size=11,
            color=ft.Colors.ON_SURFACE_VARIANT,
        )

        return ft.Container(
            content=ft.Column(
                [
                    ft.Row(
                        [star_icon, kb_icon, title_text, pills_row],
                        spacing=4,
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    ),
                    ft.Container(
                        content=meta_text,
                        # Indent metadata to align with the title (past the
                        # two leading icons).
                        padding=ft.Padding.only(left=80, bottom=2),
                    ),
                ],
                spacing=2,
                tight=True,
            ),
            padding=ft.Padding.symmetric(horizontal=8, vertical=4),
            on_click=lambda e, it=item: self._select(it),
            bgcolor=(
                ft.Colors.PRIMARY_CONTAINER
                if self._selected_id == item.id else None
            ),
            border_radius=4,
        )

    # --- Filter handling ---
    def _set_filter(self, name: str) -> None:
        if self._filter == name:
            return
        self._filter = name
        self._selected_id = None
        try:
            self._player.load(None)
        except Exception:
            pass
        self._detail_view.content = ft.Text(
            "Select an item to view details", italic=True,
        )
        self._sync_chip_styling()
        self._render_list()
        try:
            self.update()
        except (RuntimeError, AssertionError):
            pass

    # --- Actions (stubs filled in Tasks 12–15) ---
    def _select(self, item: LibraryItem) -> None:
        old_id = self._selected_id
        self._selected_id = item.id

        # Immediate visual feedback in the detail pane.
        self._detail_view.content = ft.Row(
            [ft.ProgressRing(width=20, height=20, stroke_width=2),
             ft.Text("Loading…", italic=True)],
            spacing=8,
        )
        try:
            self._detail_view.update()
        except Exception:
            pass

        # Build the real detail. Player is unloaded for notes.
        if item.kind == "meeting":
            self._detail_view.content = self._build_meeting_detail(item)
        else:
            try:
                self._player.load(None)
            except Exception:
                pass
            self._detail_view.content = self._build_note_detail(item)

        # Targeted highlight update — only the two rows that changed,
        # not a full list re-render.
        old_row = self._row_by_id.get(old_id) if old_id else None
        new_row = self._row_by_id.get(item.id)
        if old_row is not None:
            old_row.bgcolor = None
            try:
                old_row.update()
            except Exception:
                pass
        if new_row is not None:
            new_row.bgcolor = ft.Colors.PRIMARY_CONTAINER
            try:
                new_row.update()
            except Exception:
                pass

        try:
            self._detail_view.update()
        except (RuntimeError, AssertionError):
            pass

        # Pre-warm duration for this meeting if missing.
        if item.kind == "meeting" and item.id not in self._duration_cache:
            try:
                self._page.run_thread(lambda: self._prefetch_duration(item.id))
            except Exception:
                pass

    def _prefetch_duration(self, item_id: str) -> None:
        mp3 = self._recordings_dir / f"{item_id}.mp3"
        if not mp3.is_file():
            self._duration_cache[item_id] = ""
            return
        self._duration_cache[item_id] = _format_duration(mp3)
        self._refresh_row(item_id)

    def _build_meeting_detail(self, item: LibraryItem) -> ft.Control:
        mp3 = self._recordings_dir / f"{item.id}.mp3"
        live = mp3.with_suffix(".live.txt")
        transcript = mp3.with_suffix(".transcript.txt")
        summary = mp3.with_suffix(".summary.txt")

        # Load this meeting's mp3 into the shared player.
        try:
            self._player.load(mp3 if mp3.is_file() else None)
        except Exception:
            import logging
            logging.getLogger(__name__).exception("AudioPlayer.load failed")

        header = ft.Row([
            ft.Text(item.title, size=18, weight=ft.FontWeight.BOLD, expand=True),
            self._build_kb_badge(item),
            self._build_kb_toggle(item),
            self._build_fav_toggle(item),
        ])
        meta = ft.Text(
            f"{item.date or '—'} · Meeting",
            size=12, color="#888",
        )

        # Hold references so we can mutate state during background work.
        # Initial state reflects any in-flight work for this item so a
        # detail re-entry (user navigated away mid-work and came back)
        # doesn't show a re-enabled button that fires a duplicate op.
        transcribe_btn = ft.ElevatedButton(
            "Transcribing…" if item.id in self._transcribing_ids else "Transcribe",
            icon=ft.Icons.TEXT_SNIPPET,
            disabled=item.id in self._transcribing_ids,
        )
        summarize_btn = ft.ElevatedButton(
            "Summarizing…" if item.id in self._summarizing_ids else "Summarize",
            icon=ft.Icons.AUTO_AWESOME,
            disabled=item.id in self._summarizing_ids,
        )
        rename_btn = ft.ElevatedButton("Rename", icon=ft.Icons.EDIT)
        delete_btn = ft.ElevatedButton("Delete", icon=ft.Icons.DELETE)
        transcribe_btn.on_click = lambda e: self._do_transcribe(item, transcribe_btn)
        summarize_btn.on_click = lambda e: self._do_summarize(item, summarize_btn)
        rename_btn.on_click = lambda e: self._do_rename(item)
        delete_btn.on_click = lambda e: self._do_delete(item)
        action_row = ft.Row(
            [transcribe_btn, summarize_btn, rename_btn, delete_btn],
            spacing=8,
        )

        # Three text tabs
        summary_field = ft.TextField(
            value=summary.read_text(errors="ignore") if summary.is_file() else "",
            hint_text="(no summary yet)",
            multiline=True, expand=True, min_lines=20,
            text_style=ft.TextStyle(font_family="monospace"),
        )
        save_summary_btn = ft.IconButton(
            icon=ft.Icons.SAVE, tooltip="Save summary",
            on_click=lambda e: self._save_text(summary, summary_field.value),
        )

        transcript_field = ft.TextField(
            value=transcript.read_text(errors="ignore") if transcript.is_file() else "",
            hint_text="(not transcribed)",
            multiline=True, expand=True, min_lines=20,
            text_style=ft.TextStyle(font_family="monospace"),
        )
        save_transcript_btn = ft.IconButton(
            icon=ft.Icons.SAVE, tooltip="Save transcript",
            on_click=lambda e: self._save_text(transcript, transcript_field.value),
        )

        live_field = ft.TextField(
            value=live.read_text(errors="ignore") if live.is_file() else "",
            hint_text="(no live transcript)",
            multiline=True, expand=True, min_lines=20,
            text_style=ft.TextStyle(font_family="monospace"),
        )
        save_live_btn = ft.IconButton(
            icon=ft.Icons.SAVE, tooltip="Save live transcript",
            on_click=lambda e: self._save_text(live, live_field.value),
        )

        def _refresh_live(_e):
            try:
                live_field.value = (
                    live.read_text(errors="ignore") if live.is_file() else ""
                )
                live_field.update()
            except Exception:
                pass

        live_refresh_btn = ft.IconButton(
            icon=ft.Icons.REFRESH,
            tooltip="Reload live transcript from disk",
            on_click=_refresh_live,
        )

        # Manual tab strip — Flet 0.80+ ft.Tabs API split into TabBar/TabBarView,
        # overkill here. Three text buttons swap visibility of three content
        # containers. Mirrors the pattern in copilot.py.
        summary_pane = ft.Column([
            summary_field,
            ft.Row([save_summary_btn], alignment=ft.MainAxisAlignment.END),
        ], expand=True)
        transcript_pane = ft.Column([
            transcript_field,
            ft.Row([save_transcript_btn], alignment=ft.MainAxisAlignment.END),
        ], expand=True, visible=False)
        live_pane = ft.Column([
            live_field,
            ft.Row([live_refresh_btn, save_live_btn],
                   alignment=ft.MainAxisAlignment.END),
        ], expand=True, visible=False)

        panes_by_key = {"summary": summary_pane, "transcript": transcript_pane, "live": live_pane}
        active_key = {"v": "summary"}

        def _make_tab_btn(label: str, key: str) -> ft.Container:
            return ft.Container(
                content=ft.Text(label, size=13, weight=ft.FontWeight.W_600),
                padding=ft.Padding.symmetric(horizontal=14, vertical=8),
                ink=True,
                data=key,
            )

        tab_buttons = {
            "summary": _make_tab_btn("Summary", "summary"),
            "transcript": _make_tab_btn("Transcript", "transcript"),
            "live": _make_tab_btn("Live", "live"),
        }

        def _sync_tab_styling() -> None:
            for key, btn in tab_buttons.items():
                is_active = (key == active_key["v"])
                btn.bgcolor = ft.Colors.SURFACE_CONTAINER_HIGH if is_active else None
                btn.border = (
                    ft.Border.only(bottom=ft.BorderSide(2, TEAL))
                    if is_active else None
                )
                try:
                    btn.content.color = TEAL if is_active else ft.Colors.ON_SURFACE_VARIANT
                except Exception:
                    pass

        def _on_tab_click(key: str) -> None:
            if key not in panes_by_key or key == active_key["v"]:
                return
            active_key["v"] = key
            for k, pane in panes_by_key.items():
                pane.visible = (k == key)
            _sync_tab_styling()
            try:
                self._page.update()
            except Exception:
                pass

        for key, btn in tab_buttons.items():
            btn.on_click = lambda _e, k=key: _on_tab_click(k)

        _sync_tab_styling()

        tab_strip = ft.Container(
            content=ft.Row(
                list(tab_buttons.values()),
                spacing=0, tight=True,
            ),
            border=ft.Border.only(bottom=ft.BorderSide(1, ft.Colors.OUTLINE_VARIANT)),
        )
        tabs_block = ft.Column(
            [tab_strip, ft.Stack(list(panes_by_key.values()), expand=True)],
            spacing=0, expand=True,
        )

        return ft.Column(
            [header, meta, action_row, self._player, tabs_block],
            spacing=12, expand=True,
        )

    def _build_kb_badge(self, item: LibraryItem) -> ft.Control:
        """Visible badge that says '📚 In knowledge base' when the item is flagged."""
        if not self._is_kb(item):
            return ft.Container()  # placeholder, takes no space
        return ft.Container(
            content=ft.Text(
                "📚 In knowledge base",
                size=11,
                color=ft.Colors.ON_PRIMARY_CONTAINER,
                weight=ft.FontWeight.W_600,
            ),
            padding=ft.Padding.symmetric(horizontal=8, vertical=3),
            bgcolor=ft.Colors.PRIMARY_CONTAINER,
            border_radius=10,
        )

    def _build_kb_toggle(self, item: LibraryItem) -> ft.Control:
        return ft.IconButton(
            icon=ft.Icons.BOOKMARK if self._is_kb(item) else ft.Icons.BOOKMARK_OUTLINE,
            icon_color=KB_ACTIVE if self._is_kb(item) else ft.Colors.ON_SURFACE_VARIANT,
            tooltip="In agent knowledge base (📚)",
            on_click=lambda e: self._toggle_kb(item),
        )

    def _build_fav_toggle(self, item: LibraryItem) -> ft.Control:
        return ft.IconButton(
            icon=ft.Icons.STAR if self._is_fav(item) else ft.Icons.STAR_OUTLINE,
            icon_color="#f6c06b" if self._is_fav(item) else ft.Colors.ON_SURFACE_VARIANT,
            tooltip="Favorite (⭐)",
            on_click=lambda e: self._toggle_favorite(item),
        )

    def _save_text(self, path: Path, text: str) -> bool:
        """Write text to disk and surface a SnackBar with the result.

        Returns True on success, False on failure. Failures are also
        logged at warning level for diagnostics.
        """
        try:
            path.write_text(text)
        except OSError as exc:
            import logging
            logging.getLogger(__name__).warning("Failed to save %s: %s", path, exc)
            self._show_snackbar(f"Save failed: {exc}", is_error=True)
            return False
        self._show_snackbar("Saved")
        return True

    def _show_snackbar(self, message: str, *, is_error: bool = False) -> None:
        """Append a transient SnackBar to the page overlay and open it."""
        try:
            sb = ft.SnackBar(
                content=ft.Text(
                    message,
                    color=ft.Colors.ON_ERROR if is_error else None,
                ),
                bgcolor=ft.Colors.ERROR if is_error else None,
                duration=2500,
            )
            if sb not in self._page.overlay:
                self._page.overlay.append(sb)
            sb.open = True
            self._page.update()
        except Exception:
            # SnackBar is best-effort UX — never let it break a save flow.
            pass

    def _slug_for_note(self, title: str) -> str:
        """Sanitize title to a kebab-case slug. Append a numeric suffix on collision."""
        import re as _re
        base = _re.sub(r"[^a-zA-Z0-9]+", "-", title.strip().lower()).strip("-") or "note"
        candidate = base
        n = 2
        while (self._recordings_dir / f"{candidate}.note.md").exists():
            candidate = f"{base}-{n}"
            n += 1
        return candidate

    def _rebuild_detail_if_selected(self, item_id: str) -> None:
        """If the user is still viewing this item, rebuild the detail pane.

        Called after long-running work (transcribe, summarize) completes so
        the Summary / Transcript / Live tabs reload from disk and the action
        buttons reflect the current in-flight state.
        """
        if self._selected_id != item_id:
            return
        item = next((i for i in self._items if i.id == item_id), None)
        if item is None:
            return
        if item.kind == "meeting":
            self._detail_view.content = self._build_meeting_detail(item)
        else:
            self._detail_view.content = self._build_note_detail(item)
        try:
            self._detail_view.update()
        except Exception:
            pass

    def _do_transcribe(self, item: LibraryItem, button: ft.ElevatedButton | None = None) -> None:
        mp3 = self._recordings_dir / f"{item.id}.mp3"
        if not mp3.is_file():
            return
        if item.id in self._transcribing_ids:
            # Already running for this item; ignore the click.
            return

        self._transcribing_ids.add(item.id)
        if button is not None:
            button.content = "Transcribing…"
            button.disabled = True
            try:
                button.update()
            except Exception:
                pass

        def _work():
            try:
                from meeting_helper.ai.client import transcribe_audio_file
                transcribe_audio_file(str(mp3), self._raw_config)
            except Exception:
                import logging
                logging.getLogger(__name__).exception("Transcribe failed")
            finally:
                self._transcribing_ids.discard(item.id)
                # NOTE: button reference is now stale if the detail was rebuilt;
                # rebuilding the detail below covers it. Keep this for the
                # still-on-the-item case where button.update() would have worked.
                if button is not None and self._selected_id == item.id:
                    button.content = "Transcribe"
                    button.disabled = False
                    try:
                        button.update()
                    except Exception:
                        pass
                self._refresh()
                self._rebuild_detail_if_selected(item.id)

        self._page.run_thread(_work)

    def _do_summarize(self, item: LibraryItem, button: ft.ElevatedButton | None = None) -> None:
        mp3 = self._recordings_dir / f"{item.id}.mp3"
        # Prefer .transcript.txt; fall back to .live.txt (matches prior screen).
        transcript_path = mp3.with_suffix(".transcript.txt")
        if not transcript_path.is_file():
            live_path = mp3.with_suffix(".live.txt")
            if live_path.is_file():
                transcript_path = live_path
            else:
                return
        if item.id in self._summarizing_ids:
            # Already running for this item; ignore the click.
            return

        self._summarizing_ids.add(item.id)
        if button is not None:
            button.content = "Summarizing…"
            button.disabled = True
            try:
                button.update()
            except Exception:
                pass

        def _work():
            try:
                import asyncio
                from meeting_helper.ai.client import summarize_transcript
                asyncio.run(summarize_transcript(str(transcript_path), self._raw_config))
            except Exception:
                import logging
                logging.getLogger(__name__).exception("Summarize failed")
            finally:
                self._summarizing_ids.discard(item.id)
                if button is not None and self._selected_id == item.id:
                    button.content = "Summarize"
                    button.disabled = False
                    try:
                        button.update()
                    except Exception:
                        pass
                self._refresh()
                self._rebuild_detail_if_selected(item.id)

        self._page.run_thread(_work)

    def _do_delete(self, item: LibraryItem) -> None:
        """Show a confirmation dialog before deleting the artifact."""
        if item.kind == "meeting":
            files = [
                self._recordings_dir / f"{item.id}{suffix}"
                for suffix in (".mp3", ".live.txt", ".transcript.txt", ".summary.txt")
            ]
            existing = [f for f in files if f.is_file()]
            msg = (
                f"Delete '{item.title}'?\n\n"
                f"This will permanently remove {len(existing)} file(s)."
            )
        else:
            existing = [self._recordings_dir / item.note_filename]
            msg = f"Delete note '{item.title}'?"

        dlg = ft.AlertDialog(
            modal=True,
            title=ft.Text("Confirm delete"),
            content=ft.Text(msg),
            actions=[
                ft.TextButton("Cancel"),
                ft.ElevatedButton("Delete", bgcolor=ERROR_RED, color="white"),
            ],
        )

        def _close():
            dlg.open = False
            self._page.update()

        def _confirm():
            _close()
            self._actually_delete(item)

        dlg.actions[0].on_click = lambda _e: _close()
        dlg.actions[1].on_click = lambda _e: _confirm()

        if dlg not in self._page.overlay:
            self._page.overlay.append(dlg)
        dlg.open = True
        self._page.update()

    def _actually_delete(self, item: LibraryItem) -> None:
        """Move existing _do_delete body here — runs after user confirms."""
        import os
        if item.kind == "meeting":
            try:
                self._player.load(None)
            except Exception:
                pass
            mp3 = self._recordings_dir / f"{item.id}.mp3"
            summary_name = mp3.with_suffix(".summary.txt").name
            for suffix in (".mp3", ".live.txt", ".transcript.txt", ".summary.txt"):
                p = mp3.with_suffix(suffix)
                if p.is_file():
                    try:
                        os.unlink(p)
                    except OSError:
                        pass
            self._raw_config.remove_kb(summary_name)
            self._raw_config.remove_favorite(mp3.name)
        else:
            note = self._recordings_dir / item.note_filename
            if note.is_file():
                try:
                    os.unlink(note)
                except OSError:
                    pass
            self._raw_config.remove_kb(item.note_filename)
            self._raw_config.remove_favorite(item.note_filename)
        self._selected_id = None
        self._detail_view.content = ft.Text("Select an item to view details", italic=True)
        self._show_snackbar("Deleted")
        self._refresh()

    def _do_rename(self, item: LibraryItem) -> None:
        """Open a dialog to rename this artifact (mp3 + adjacent files / note file)."""
        if item.kind == "meeting":
            prefix = _timestamp_prefix(item.id)
            suggested = item.title  # already de-underscored
        else:
            prefix = ""
            suggested = item.title

        field = ft.TextField(label="New name", value=suggested, autofocus=True)
        dlg = ft.AlertDialog(
            modal=True,
            title=ft.Text("Rename"),
            content=field,
            actions=[
                ft.TextButton("Cancel"),
                ft.ElevatedButton("Rename"),
            ],
        )

        def _close():
            dlg.open = False
            self._page.update()

        def _do_rename_confirm():
            new_name = (field.value or "").strip()
            if not new_name:
                field.error_text = "Name required"
                self._page.update()
                return
            try:
                if item.kind == "meeting":
                    # Sanitize: spaces → underscores so the filename is shell-safe
                    new_label = new_name.replace(" ", "_")
                    new_stem = f"{prefix}{new_label}" if prefix else new_label
                    old_mp3 = self._recordings_dir / f"{item.id}.mp3"
                    new_mp3 = old_mp3.with_name(f"{new_stem}.mp3")
                    if new_mp3.exists() and new_mp3 != old_mp3:
                        field.error_text = "A file with that name already exists"
                        self._page.update()
                        return
                    # Stop player before moving the file under it
                    try:
                        self._player.load(None)
                    except Exception:
                        pass
                    for suffix in (".mp3", ".live.txt", ".transcript.txt", ".summary.txt"):
                        old = old_mp3.with_suffix(suffix)
                        if old.is_file():
                            old.rename(old.with_name(f"{new_stem}{suffix}"))
                    # Migrate config flags
                    old_summary = f"{item.id}.summary.txt"
                    new_summary = f"{new_stem}.summary.txt"
                    if self._raw_config.is_kb(old_summary):
                        self._raw_config.remove_kb(old_summary)
                        self._raw_config.add_kb(new_summary)
                    old_mp3_name = f"{item.id}.mp3"
                    new_mp3_name = f"{new_stem}.mp3"
                    if self._raw_config.is_favorite(old_mp3_name):
                        self._raw_config.remove_favorite(old_mp3_name)
                        self._raw_config.add_favorite(new_mp3_name)
                    self._selected_id = new_stem
                else:
                    old_path = self._recordings_dir / item.note_filename
                    slug = self._slug_for_note(new_name)
                    new_filename = f"{slug}.note.md"
                    new_path = self._recordings_dir / new_filename
                    if new_path.exists() and new_path != old_path:
                        field.error_text = "A note with that name already exists"
                        self._page.update()
                        return
                    old_path.rename(new_path)
                    if self._raw_config.is_kb(item.note_filename):
                        self._raw_config.remove_kb(item.note_filename)
                        self._raw_config.add_kb(new_filename)
                    if self._raw_config.is_favorite(item.note_filename):
                        self._raw_config.remove_favorite(item.note_filename)
                        self._raw_config.add_favorite(new_filename)
                    self._selected_id = new_filename
            except OSError as exc:
                field.error_text = f"Rename failed: {exc}"
                self._page.update()
                return
            # Cache invalidation: the old id no longer exists
            self._duration_cache.pop(item.id, None)
            _close()
            self._show_snackbar("Renamed")
            self._refresh()
            # Re-select the renamed item so the detail header / tabs reflect
            # the new title and file paths immediately.
            new_id = self._selected_id  # set just above for both meeting/note paths
            new_item = next((i for i in self._items if i.id == new_id), None)
            if new_item is not None:
                self._select(new_item)

        dlg.actions[0].on_click = lambda _e: _close()
        dlg.actions[1].on_click = lambda _e: _do_rename_confirm()

        if dlg not in self._page.overlay:
            self._page.overlay.append(dlg)
        dlg.open = True
        self._page.update()

    def _build_note_detail(self, item: LibraryItem) -> ft.Control:
        note_path = self._recordings_dir / item.note_filename
        body = note_path.read_text(errors="ignore") if note_path.is_file() else ""

        title_field = ft.Text(item.title, size=18, weight=ft.FontWeight.BOLD)
        meta = ft.Text(f"Note · {item.note_filename}", size=12, color="#888")
        body_field = ft.TextField(
            value=body, multiline=True, expand=True, min_lines=20,
            text_style=ft.TextStyle(font_family="monospace"),
        )

        def _save(_e):
            self._save_text(note_path, body_field.value or "")

        def _delete(_e):
            self._do_delete(item)

        def _rename(_e):
            self._do_rename(item)

        action_row = ft.Row([
            ft.ElevatedButton("Save", icon=ft.Icons.SAVE, on_click=_save),
            ft.ElevatedButton("Rename", icon=ft.Icons.EDIT, on_click=_rename),
            ft.ElevatedButton("Delete", icon=ft.Icons.DELETE, on_click=_delete),
        ], spacing=8)

        header = ft.Row([
            title_field,
            ft.Container(expand=True),
            self._build_kb_badge(item),
            self._build_kb_toggle(item),
            self._build_fav_toggle(item),
        ])

        return ft.Column([header, meta, action_row, body_field], spacing=12, expand=True)

    def _toggle_favorite(self, item: LibraryItem) -> None:
        # Re-uses existing favorites system. Implemented fully in Task 15.
        if item.kind == "meeting":
            mp3_name = f"{item.id}.mp3"
            if self._raw_config.is_favorite(mp3_name):
                self._raw_config.remove_favorite(mp3_name)
            else:
                self._raw_config.add_favorite(mp3_name)
        else:
            if self._raw_config.is_favorite(item.note_filename):
                self._raw_config.remove_favorite(item.note_filename)
            else:
                self._raw_config.add_favorite(item.note_filename)
        self._refresh_row(item.id)

    def _toggle_kb(self, item: LibraryItem) -> None:
        # Note path: instant.
        if item.kind == "note":
            if self._raw_config.is_kb(item.note_filename):
                self._raw_config.remove_kb(item.note_filename)
            else:
                self._raw_config.add_kb(item.note_filename)
            self._refresh_row(item.id)
            return

        # Meeting path:
        mp3 = self._recordings_dir / f"{item.id}.mp3"
        summary_path = mp3.with_suffix(".summary.txt")

        if summary_path.is_file():
            if self._raw_config.is_kb(summary_path.name):
                self._raw_config.remove_kb(summary_path.name)
                self._show_snackbar("Removed from knowledge base")
            else:
                self._raw_config.add_kb(summary_path.name)
                self._show_snackbar("Added to knowledge base")
            self._refresh_row(item.id)
            return

        # No summary yet. Look for an input we can summarize.
        transcript_path = mp3.with_suffix(".transcript.txt")
        live_path = mp3.with_suffix(".live.txt")
        if transcript_path.is_file():
            input_path = transcript_path
        elif live_path.is_file():
            input_path = live_path
        else:
            self._show_snackbar(
                "Cannot include in KB — no transcript yet. Click Transcribe first.",
                is_error=True,
            )
            return

        # Optimistic flag + summarize.
        if item.id in self._summarizing_ids:
            # Already summarizing; just flip the flag and let the existing
            # work finish — no need to spawn a second thread.
            if not self._raw_config.is_kb(summary_path.name):
                self._raw_config.add_kb(summary_path.name)
            self._refresh_row(item.id)
            return
        self._raw_config.add_kb(summary_path.name)
        self._show_snackbar("Generating summary for KB…")
        self._summarizing_ids.add(item.id)
        self._refresh()

        def _run():
            try:
                import asyncio
                from meeting_helper.ai.client import summarize_transcript
                asyncio.run(summarize_transcript(str(input_path), self._raw_config))
                self._show_snackbar("Summary ready — added to KB")
            except Exception as exc:
                import logging
                logging.getLogger(__name__).exception("Auto-summarize on KB toggle failed")
                self._raw_config.remove_kb(summary_path.name)
                self._show_snackbar(f"Summary failed: {exc}", is_error=True)
            finally:
                self._summarizing_ids.discard(item.id)
                self._refresh()
                self._rebuild_detail_if_selected(item.id)

        self._page.run_thread(_run)

    def _on_add_note_click(self, e) -> None:
        title_input = ft.TextField(label="Title", autofocus=True)
        body_input = ft.TextField(
            label="Body (Markdown)",
            multiline=True,
            expand=True,
            text_style=ft.TextStyle(font_family="monospace"),
        )
        kb_check = ft.Checkbox(
            label="Include in agent knowledge base (📚)", value=True,
        )

        # Size dialog to most of the page so the body editor can breathe.
        try:
            page_w = float(self._page.width or 0)
            page_h = float(self._page.height or 0)
        except (TypeError, ValueError):
            page_w = page_h = 0
        dialog_w = max(600, int(page_w * 0.85)) if page_w else 900
        dialog_h = max(480, int(page_h * 0.80)) if page_h else 700

        content_box = ft.Container(
            content=ft.Column(
                [title_input, body_input, kb_check],
                spacing=12,
                expand=True,
            ),
            width=dialog_w,
            height=dialog_h,
        )

        dlg = ft.AlertDialog(
            modal=True,
            title=ft.Text("Add Note"),
            content=content_box,
            actions=[
                ft.TextButton("Cancel"),
                ft.ElevatedButton("Save Note"),
            ],
        )

        def _close_dialog():
            dlg.open = False
            self._page.update()

        def _do_save():
            title = (title_input.value or "").strip()
            if not title:
                title_input.error_text = "Title required"
                self._page.update()
                return
            save_btn = dlg.actions[1]
            original_label = save_btn.content
            save_btn.content = "Saving…"
            save_btn.disabled = True
            try:
                save_btn.update()
            except Exception:
                pass
            try:
                slug = self._slug_for_note(title)
                note_path = self._recordings_dir / f"{slug}.note.md"
                try:
                    note_path.write_text(body_input.value or "")
                except OSError as exc:
                    import logging
                    logging.getLogger(__name__).exception("Note write failed")
                    title_input.error_text = f"Could not save: {exc}"
                    try:
                        title_input.update()
                    except Exception:
                        pass
                    return
                if kb_check.value:
                    self._raw_config.add_kb(note_path.name)
                _close_dialog()
                self._refresh()
            finally:
                save_btn.content = original_label
                save_btn.disabled = False
                try:
                    save_btn.update()
                except Exception:
                    pass

        # Wire actions AFTER dlg exists so the lambdas can reference it.
        dlg.actions[0].on_click = lambda _e: _close_dialog()
        dlg.actions[1].on_click = lambda _e: _do_save()

        if dlg not in self._page.overlay:
            self._page.overlay.append(dlg)
        dlg.open = True
        self._page.update()

    def on_workspace_changed(self) -> None:
        """Re-target this screen at the new active workspace.

        Called by app.py whenever the user switches workspaces. Re-reads
        the config, updates `_recordings_dir`, stops any audio playback,
        clears the selected detail, and re-renders the list.
        """
        from meeting_helper.config import get_config
        new_config = get_config()
        self._raw_config = new_config
        self._recordings_dir = Path(new_config.recordings_dir)
        # Stop any in-progress playback against the previous workspace's mp3.
        try:
            self._player.stop()
        except Exception:
            pass
        # Clear the detail panel and selection — what was selected belongs
        # to a different workspace now.
        self._selected_id = None
        self._detail_view.content = ft.Text(
            "Select an item to view details", italic=True,
        )
        self._refresh()

    def cleanup(self) -> None:
        """Stop audio playback — called on app exit / nav-away."""
        try:
            self._player.stop()
        except Exception:
            pass
