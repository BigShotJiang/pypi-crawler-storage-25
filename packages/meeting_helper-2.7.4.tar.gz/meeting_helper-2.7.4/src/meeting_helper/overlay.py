"""Native macOS overlay window — always-on-top, frameless, dark panel.

Launched as a separate process by the daemon.
Connects to the daemon WebSocket and renders live transcript + AI responses.

Usage (internal):  python -m meeting_helper.overlay <port>
"""

from __future__ import annotations

import json
import sys
import threading
from dataclasses import dataclass, field

from PySide6.QtCore import (
    QMetaObject,
    QObject,
    QPoint,
    Qt,
    QThread,
    QTimer,
    Signal,
    Slot,
    Q_ARG,
)
from PySide6.QtGui import QFont
from PySide6.QtWebSockets import QWebSocket
from PySide6.QtWidgets import (
    QApplication,
    QComboBox,
    QDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMenu,
    QPushButton,
    QScrollArea,
    QSizeGrip,
    QTextBrowser,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

# ---------------------------------------------------------------------------
# Markdown -> HTML renderer
# ---------------------------------------------------------------------------

def _md_to_html(text: str, font_size: int = 14) -> str:
    """Convert markdown to styled HTML for QTextBrowser."""
    try:
        import markdown
        from pygments.formatters import HtmlFormatter

        formatter = HtmlFormatter(style="github-dark", noclasses=True)
        pygments_css = formatter.get_style_defs(".codehilite")

        extensions = ["fenced_code", "codehilite", "tables", "nl2br"]
        body = markdown.markdown(text, extensions=extensions)

        code_size = max(8, font_size - 2)
        return f"""<style>
body {{ color: #e6edf3; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
        font-size: {font_size}px; line-height: 1.65; margin: 0; padding: 0; background: transparent; }}
h1, h2, h3 {{ color: #ffffff; margin: 14px 0 6px; }}
h1 {{ font-size: {font_size + 2}px; }}
h2 {{ font-size: {font_size + 1}px; }}
h3 {{ font-size: {font_size}px; }}
p {{ margin: 6px 0; }}
code {{ background: #1c2128; border: 1px solid #30363d; border-radius: 3px;
        padding: 1px 5px; font-family: Menlo, monospace; font-size: {code_size}px; color: #79c0ff; }}
pre {{ background: #1c2128; border: 1px solid #30363d; border-radius: 6px;
       padding: 12px; margin: 8px 0; overflow-x: auto; }}
pre code {{ background: none; border: none; padding: 0; color: #e6edf3; font-size: {code_size}px; }}
ul, ol {{ padding-left: 18px; margin: 6px 0; }}
li {{ margin: 3px 0; }}
strong {{ color: #ffffff; }}
em {{ color: #d2a8ff; }}
blockquote {{ border-left: 3px solid #30363d; margin: 6px 0; padding-left: 10px; color: #8b949e; }}
table {{ border-collapse: collapse; width: 100%; margin: 8px 0; font-size: {font_size - 1}px; }}
th, td {{ border: 1px solid #30363d; padding: 5px 10px; }}
th {{ background: #1c2128; }}
{pygments_css}
</style>
{body}"""
    except Exception:
        escaped = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        return f'<pre style="color:#e6edf3;white-space:pre-wrap">{escaped}</pre>'


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _sanitize(name: str) -> str:
    """'crypto_implementation_plan' → 'Crypto Implementation Plan'"""
    return name.replace("_", " ").replace("-", " ").title()


def _hide_all_windows_from_capture() -> None:
    """Set NSWindowSharingNone on every window this app owns.

    Called on every showEvent (main overlay + dialogs) and periodically, so
    newly-created windows like the conversation picker dialog can't leak into
    a screen share.
    """
    try:
        from AppKit import NSApp
        for window in NSApp.windows():
            try:
                window.setSharingType_(0)
            except Exception:
                pass
    except Exception:
        pass


# ---------------------------------------------------------------------------
# WebSocket worker
# ---------------------------------------------------------------------------

class WSWorker(QObject):
    message = Signal(dict)
    connected = Signal()
    disconnected = Signal()

    def __init__(self, port: int) -> None:
        super().__init__()
        self._port = port
        self._ws: QWebSocket | None = None

    def start(self) -> None:
        self._ws = QWebSocket()
        self._ws.connected.connect(self._on_connected)
        self._ws.disconnected.connect(self._on_disconnected)
        self._ws.textMessageReceived.connect(self._on_message)
        self._connect()

    def _connect(self) -> None:
        from PySide6.QtCore import QUrl
        self._ws.open(QUrl(f"ws://127.0.0.1:{self._port}/ws"))

    @Slot()
    def _on_connected(self) -> None:
        self.connected.emit()

    @Slot()
    def _on_disconnected(self) -> None:
        self.disconnected.emit()
        QTimer.singleShot(2000, self._connect)

    @Slot(str)
    def _on_message(self, raw: str) -> None:
        try:
            self.message.emit(json.loads(raw))
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Context panel (collapsible right panel)
# ---------------------------------------------------------------------------

class _TasksOverlayPanel(QWidget):
    """Collapsible right panel listing extracted tasks with copy buttons."""

    WIDTH = 230

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._tasks: list[dict] = []
        self.setFixedWidth(self.WIDTH)
        self.setStyleSheet("background: transparent;")

        self._root = QVBoxLayout(self)
        self._root.setContentsMargins(10, 10, 10, 10)
        self._root.setSpacing(8)
        self._root.setAlignment(Qt.AlignTop)

        header_row = QHBoxLayout()
        header_row.setContentsMargins(0, 0, 0, 0)
        header_lbl = QLabel("Extracted Tasks")
        header_lbl.setStyleSheet(
            "color: #e6edf3; font-size: 12px; font-weight: 600;"
        )
        header_row.addWidget(header_lbl, 1)

        self._copy_all_btn = QPushButton("Copy all")
        self._copy_all_btn.setCursor(Qt.PointingHandCursor)
        self._copy_all_btn.setStyleSheet(
            "QPushButton { background: transparent; color: #4ec9b0; border: none; "
            "font-size: 10px; padding: 2px 4px; }"
            "QPushButton:hover { color: #79c0ff; }"
            "QPushButton:disabled { color: #5a5a5a; }"
        )
        self._copy_all_btn.setEnabled(False)
        self._copy_all_btn.clicked.connect(self._copy_all)
        header_row.addWidget(self._copy_all_btn)
        self._root.addLayout(header_row)

        self._empty_label = QLabel(
            "No tasks yet — click Extract Task to capture action items."
        )
        self._empty_label.setWordWrap(True)
        self._empty_label.setStyleSheet(
            "color: #6e7681; font-size: 11px; font-style: italic; padding: 8px 0;"
        )
        self._root.addWidget(self._empty_label)

        self._items_container = QWidget()
        self._items_container.setStyleSheet("background: transparent;")
        self._items_layout = QVBoxLayout(self._items_container)
        self._items_layout.setContentsMargins(0, 0, 0, 0)
        self._items_layout.setSpacing(6)
        self._items_layout.setAlignment(Qt.AlignTop)
        self._root.addWidget(self._items_container)
        self._root.addStretch()

    def set_tasks(self, tasks: list[dict]) -> None:
        self._tasks = list(tasks)
        # Clear existing rows
        while self._items_layout.count():
            item = self._items_layout.takeAt(0)
            w = item.widget()
            if w is not None:
                w.deleteLater()
        self._empty_label.setVisible(not self._tasks)
        self._copy_all_btn.setEnabled(bool(self._tasks))
        for task in self._tasks:
            self._items_layout.addWidget(self._make_row(task))

    def _make_row(self, task: dict) -> QWidget:
        title = task.get("title") or task.get("text", "")
        description = task.get("description", "")
        quote = task.get("source_quote", "")

        row = QFrame()
        row.setStyleSheet(
            "QFrame { background: #161b22; border: 1px solid #30363d; "
            "border-radius: 6px; }"
        )
        rlay = QVBoxLayout(row)
        rlay.setContentsMargins(8, 6, 8, 8)
        rlay.setSpacing(3)

        title_row = QHBoxLayout()
        title_row.setContentsMargins(0, 0, 0, 0)
        title_lbl = QLabel(title)
        title_lbl.setWordWrap(True)
        title_lbl.setStyleSheet(
            "color: #e6edf3; font-size: 12px; font-weight: 600; background: transparent;"
        )
        title_row.addWidget(title_lbl, 1)

        copy_btn = QToolButton()
        copy_btn.setText("⎘")  # copy-like glyph
        copy_btn.setToolTip("Copy task")
        copy_btn.setCursor(Qt.PointingHandCursor)
        copy_btn.setStyleSheet(
            "QToolButton { color: #8b949e; border: none; background: transparent; "
            "font-size: 14px; padding: 0 2px; }"
            "QToolButton:hover { color: #4ec9b0; }"
        )
        payload = (f"{title}\n{description}".strip() if description else title)
        copy_btn.clicked.connect(
            lambda _=False, p=payload: QApplication.clipboard().setText(p)
        )
        title_row.addWidget(copy_btn)
        rlay.addLayout(title_row)

        if description:
            desc_lbl = QLabel(description)
            desc_lbl.setWordWrap(True)
            desc_lbl.setStyleSheet(
                "color: #c9d1d9; font-size: 11px; background: transparent;"
            )
            rlay.addWidget(desc_lbl)

        if quote:
            quote_lbl = QLabel(f"“{quote}”")
            quote_lbl.setWordWrap(True)
            quote_lbl.setStyleSheet(
                "color: #6e7681; font-size: 10px; font-style: italic; "
                "background: transparent;"
            )
            rlay.addWidget(quote_lbl)

        return row

    def _copy_all(self) -> None:
        lines = []
        for t in self._tasks:
            title = t.get("title") or t.get("text", "")
            desc = t.get("description", "")
            if not title:
                continue
            lines.append(f"- {title}" + (f" — {desc}" if desc else ""))
        QApplication.clipboard().setText("\n".join(lines))


class _ContextPanel(QWidget):
    """Collapsible right panel for selecting repos + knowledge folders."""

    WIDTH = 230

    def __init__(self, port: int, parent=None) -> None:
        super().__init__(parent)
        self._port = port
        self._knowledge_paths: list[str] = []
        self._knowledge_path = ""  # compat
        self._repos_workspaces: list[str] = []
        self._repos_workspace = ""  # compat
        self._repos: list[dict] = []  # [{name, path, sanitized_name}]
        self._ignored_repos: list[str] = []
        self._ignored_knowledge: list[str] = []
        self._session_active = False
        self._setup_ui()
        self.setFixedWidth(self.WIDTH)

    def _setup_ui(self) -> None:
        self.setStyleSheet("""
            QWidget {
                background: transparent;
                color: #d4d4d4;
            }
        """)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        # Header
        header = QLabel("Context")
        header.setStyleSheet("font-size: 11px; font-weight: 600; color: #808080; background: transparent;")
        layout.addWidget(header)

        # Disabled overlay label
        self._disabled_label = QLabel("Start a meeting\nto select context")
        self._disabled_label.setAlignment(Qt.AlignCenter)
        self._disabled_label.setStyleSheet(
            "font-size: 10px; color: #5a5a5a; background: transparent; padding: 8px 0;"
        )
        layout.addWidget(self._disabled_label)

        # Search field (filters both repos and knowledge folders)
        self._search_input = QLineEdit()
        self._search_input.setPlaceholderText("Search...")
        self._search_input.setStyleSheet("""
            QLineEdit {
                background: #161b22; border: 1px solid #30363d; border-radius: 5px;
                color: #e6edf3; padding: 4px 8px; font-size: 10px;
            }
            QLineEdit:focus { border-color: #58a6ff; }
        """)
        self._search_input.textChanged.connect(self._apply_search)
        layout.addWidget(self._search_input)

        # --- Repos section ---
        self._repos_label = QLabel("Repositories")
        self._repos_label.setStyleSheet("font-size: 10px; color: #808080; background: transparent;")
        layout.addWidget(self._repos_label)

        self._chips_widget = QWidget()
        self._chips_widget.setStyleSheet("background: transparent;")
        self._chips_layout = QVBoxLayout(self._chips_widget)
        self._chips_layout.setContentsMargins(0, 0, 0, 0)
        self._chips_layout.setSpacing(3)
        layout.addWidget(self._chips_widget)

        self._no_repos_label = QLabel("No repos configured")
        self._no_repos_label.setStyleSheet("font-size: 10px; color: #5a5a5a; background: transparent;")
        layout.addWidget(self._no_repos_label)

        # --- Knowledge section ---
        self._kb_label = QLabel("Knowledge Base")
        self._kb_label.setStyleSheet("font-size: 10px; color: #808080; background: transparent; margin-top: 4px;")
        layout.addWidget(self._kb_label)

        self._kb_chips_widget = QWidget()
        self._kb_chips_widget.setStyleSheet("background: transparent;")
        self._kb_chips_layout = QVBoxLayout(self._kb_chips_widget)
        self._kb_chips_layout.setContentsMargins(0, 0, 0, 0)
        self._kb_chips_layout.setSpacing(3)
        layout.addWidget(self._kb_chips_widget)

        self._no_kb_label = QLabel("No knowledge folder\nconfigured")
        self._no_kb_label.setStyleSheet("font-size: 10px; color: #5a5a5a; background: transparent;")
        layout.addWidget(self._no_kb_label)

        # Load button
        self._load_btn = QPushButton("Load Context")
        self._load_btn.setCursor(Qt.PointingHandCursor)
        self._load_btn.setStyleSheet("""
            QPushButton {
                background: #238636; color: white; border: none; border-radius: 5px;
                padding: 5px 8px; font-size: 10px; font-weight: 600;
            }
            QPushButton:hover { background: #2ea043; }
            QPushButton:disabled { background: #1a2a1a; color: #5a5a5a; }
        """)
        self._load_btn.clicked.connect(self._load_context)
        layout.addWidget(self._load_btn)

        # Status label
        self._status_label = QLabel("")
        self._status_label.setWordWrap(True)
        self._status_label.setStyleSheet("font-size: 9px; color: #808080; background: transparent;")
        layout.addWidget(self._status_label)

        # --- Past Conversations section ---
        self._conv_label = QLabel("Past Conversations")
        self._conv_label.setStyleSheet(
            "font-size: 10px; color: #808080; background: transparent; margin-top: 8px;"
        )
        layout.addWidget(self._conv_label)

        self._browse_conv_btn = QPushButton("Browse past conversations…")
        self._browse_conv_btn.setCursor(Qt.PointingHandCursor)
        self._browse_conv_btn.setStyleSheet("""
            QPushButton {
                background: #1f6feb; color: white; border: none; border-radius: 5px;
                padding: 5px 8px; font-size: 10px; font-weight: 600;
            }
            QPushButton:hover { background: #388bfd; }
            QPushButton:disabled { background: #1a2438; color: #5a5a5a; }
        """)
        self._browse_conv_btn.clicked.connect(self._open_conversation_picker)
        layout.addWidget(self._browse_conv_btn)

        self._attached_label = QLabel("Attached: none")
        self._attached_label.setWordWrap(True)
        self._attached_label.setStyleSheet(
            "font-size: 9px; color: #808080; background: transparent;"
        )
        layout.addWidget(self._attached_label)

        self._detach_btn = QPushButton("Detach")
        self._detach_btn.setCursor(Qt.PointingHandCursor)
        self._detach_btn.setStyleSheet("""
            QPushButton {
                background: transparent; color: #f85149; border: 1px solid #f85149;
                border-radius: 5px; padding: 3px 8px; font-size: 9px;
            }
            QPushButton:hover { background: #f85149; color: white; }
        """)
        self._detach_btn.clicked.connect(self._detach_conversation)
        self._detach_btn.hide()
        layout.addWidget(self._detach_btn)

        # Tracks the currently attached conversation, if any.
        self._attached: dict | None = None

        layout.addStretch()

        # Initial state: disabled
        self._set_controls_enabled(False)

    def set_session_active(self, active: bool) -> None:
        self._session_active = active
        self._set_controls_enabled(active)
        if active:
            self._disabled_label.hide()
            self._load_config()  # always reload — picks up ignored changes
        else:
            self._disabled_label.show()
            self._status_label.setText("")
            self._search_input.clear()
            # Reset so next meeting loads fresh config
            self._repos = []
            self._repos_workspaces = []
            self._repos_workspace = ""
            self._knowledge_paths = []
            self._knowledge_path = ""
            # Server already cleared state.attached_conversation in the session
            # teardown; clear the local mirror so a new meeting starts clean.
            self._attached = None
            self._attached_label.setText("Attached: none")
            self._attached_label.setStyleSheet(
                "font-size: 9px; color: #808080; background: transparent;"
            )
            self._detach_btn.hide()

    def _set_controls_enabled(self, enabled: bool) -> None:
        self._search_input.setVisible(enabled)
        self._repos_label.setVisible(enabled)
        self._chips_widget.setVisible(enabled)
        self._kb_label.setVisible(enabled)
        self._kb_chips_widget.setVisible(enabled)
        self._load_btn.setVisible(enabled)
        self._status_label.setVisible(enabled)
        self._conv_label.setVisible(enabled)
        self._browse_conv_btn.setVisible(enabled)
        self._attached_label.setVisible(enabled)
        self._detach_btn.setVisible(enabled and self._attached is not None)

    def refresh(self) -> None:
        """Reload config from daemon (always — picks up ignored changes)."""
        if self._session_active:
            self._load_config()

    def _load_config(self) -> None:
        """Fetch repos + knowledge_path from daemon in background."""
        threading.Thread(target=self._do_load_config, daemon=True).start()

    def _do_load_config(self) -> None:
        import urllib.request
        try:
            req = urllib.request.Request(f"http://127.0.0.1:{self._port}/config")
            with urllib.request.urlopen(req, timeout=3) as resp:
                data = json.loads(resp.read().decode())
            QMetaObject.invokeMethod(
                self, "_on_config_loaded",
                Qt.ConnectionType.QueuedConnection,
                Q_ARG(str, json.dumps(data)),
            )
        except Exception:
            pass

    @Slot(str)
    def _on_config_loaded(self, data_json: str) -> None:
        data = json.loads(data_json)
        new_workspaces = data.get("repos_workspaces") or ([data["repos_workspace"]] if data.get("repos_workspace") else [])
        new_knowledge_paths = data.get("knowledge_paths") or ([data["knowledge_path"]] if data.get("knowledge_path") else [])
        new_ignored_repos = data.get("ignored_repos", [])
        new_ignored_knowledge = data.get("ignored_knowledge", [])

        ignored_changed = (new_ignored_repos != self._ignored_repos or
                           new_ignored_knowledge != self._ignored_knowledge)
        self._ignored_repos = new_ignored_repos
        self._ignored_knowledge = new_ignored_knowledge

        if (new_workspaces != self._repos_workspaces or
                new_knowledge_paths != self._knowledge_paths or ignored_changed):
            self._repos_workspaces = new_workspaces
            self._repos_workspace = new_workspaces[0] if new_workspaces else ""
            self._knowledge_paths = new_knowledge_paths
            self._knowledge_path = new_knowledge_paths[0] if new_knowledge_paths else ""
            # Repos workspaces selector was removed in Phase 2 of "Learn From
            # Conversations" — context_loader is gone, so the chip list is
            # always empty. Kept the field so the rest of the panel still
            # initialises cleanly in case anything downstream still reads it.
            self._repos = []
            self._populate_chips()
            self._populate_kb_chips()

    def _populate_chips(self) -> None:
        # Save current selections
        prev = {self._chips_layout.itemAt(i).widget().property("repo_path")
                for i in range(self._chips_layout.count())
                if self._chips_layout.itemAt(i).widget() and
                   self._chips_layout.itemAt(i).widget().isChecked()}
        for i in reversed(range(self._chips_layout.count())):
            w = self._chips_layout.itemAt(i).widget()
            if w:
                w.deleteLater()

        if not self._repos:
            self._no_repos_label.show()
            return

        self._no_repos_label.hide()
        chip_style = """
            QPushButton {
                background: #1a1a1a; color: #808080; border: 1px solid #2a2a2a;
                border-radius: 10px; padding: 3px 8px; font-size: 10px; text-align: left;
            }
            QPushButton:checked { background: #238636; color: #ffffff; border: 1px solid #238636; }
            QPushButton:hover { border-color: #4ec9b0; }
        """
        for repo in self._repos:
            btn = QPushButton(repo["sanitized_name"])
            btn.setCheckable(True)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setProperty("repo_path", repo["path"])
            btn.setProperty("repo_name", repo["name"])
            btn.setChecked(repo["path"] in prev)
            btn.setStyleSheet(chip_style)
            self._chips_layout.addWidget(btn)
        self._apply_search(self._search_input.text())

    def _populate_kb_chips(self) -> None:
        # Save current selections
        prev = {self._kb_chips_layout.itemAt(i).widget().property("folder_path")
                for i in range(self._kb_chips_layout.count())
                if self._kb_chips_layout.itemAt(i).widget() and
                   self._kb_chips_layout.itemAt(i).widget().isChecked()}
        for i in reversed(range(self._kb_chips_layout.count())):
            w = self._kb_chips_layout.itemAt(i).widget()
            if w:
                w.deleteLater()

        if not self._knowledge_paths:
            self._no_kb_label.show()
            return

        # Knowledge folders selector was removed in Phase 2 of "Learn From
        # Conversations" — context_loader is gone. Tree is always empty.
        tree_data: list = []

        # Flatten tree into chips
        folders: list[dict] = []
        def _flatten(nodes, prefix=""):
            for node in nodes:
                folders.append({"name": node["path"], "label": _sanitize(node["name"])})
                if node.get("children"):
                    _flatten(node["children"])
        _flatten(tree_data)

        if not folders:
            self._no_kb_label.show()
            return

        self._no_kb_label.hide()
        chip_style = """
            QPushButton {
                background: #1a1a1a; color: #808080; border: 1px solid #2a2a2a;
                border-radius: 10px; padding: 3px 8px; font-size: 10px; text-align: left;
            }
            QPushButton:checked { background: #238636; color: #ffffff; border: 1px solid #238636; }
            QPushButton:hover { border-color: #4ec9b0; }
        """
        for folder in folders:
            btn = QPushButton(folder["label"])
            btn.setCheckable(True)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setProperty("folder_path", folder["name"])
            btn.setChecked(folder["name"] in prev)
            btn.setStyleSheet(chip_style)
            self._kb_chips_layout.addWidget(btn)
        self._apply_search(self._search_input.text())

    def _apply_search(self, text: str) -> None:
        terms = [t.strip().lower() for t in text.split(",") if t.strip()]
        for layout in (self._chips_layout, self._kb_chips_layout):
            for i in range(layout.count()):
                w = layout.itemAt(i).widget()
                if w:
                    name = w.text().lower()
                    visible = not terms or any(t in name for t in terms)
                    w.setVisible(visible)

    @staticmethod
    def _resize_scroll(scroll, widget, max_h: int) -> None:
        from PySide6.QtCore import QTimer
        def _do():
            widget.adjustSize()
            h = widget.sizeHint().height()
            scroll.setFixedHeight(min(h, max_h))
        QTimer.singleShot(0, _do)

    def _get_selected_repos(self) -> list[str]:
        result = []
        for i in range(self._chips_layout.count()):
            w = self._chips_layout.itemAt(i).widget()
            if w and isinstance(w, QPushButton) and w.isChecked():
                result.append(w.property("repo_path"))
        return result

    def _get_selected_folders(self) -> list[str]:
        result = []
        for i in range(self._kb_chips_layout.count()):
            w = self._kb_chips_layout.itemAt(i).widget()
            if w and isinstance(w, QPushButton) and w.isChecked():
                result.append(w.property("folder_path"))
        return result

    def sync_selection(self, repos: list[str], knowledge_relpaths: list[str]) -> None:
        """Check chips matching the given repo names / knowledge paths (never unchecks)."""
        for i in range(self._chips_layout.count()):
            w = self._chips_layout.itemAt(i).widget()
            if w and isinstance(w, QPushButton):
                from pathlib import Path
                repo_name = Path(w.property("repo_path") or "").name
                if repo_name in repos:
                    w.setChecked(True)

        for i in range(self._kb_chips_layout.count()):
            w = self._kb_chips_layout.itemAt(i).widget()
            if w and isinstance(w, QPushButton):
                if w.property("folder_path") in knowledge_relpaths:
                    w.setChecked(True)

    def _load_context(self) -> None:
        repos = self._get_selected_repos()
        folders = self._get_selected_folders()

        if not repos and not folders:
            self._status_label.setText("Select at least one repo or folder")
            self._status_label.setStyleSheet("font-size: 9px; color: #f14c4c; background: transparent;")
            return

        self._load_btn.setEnabled(False)
        self._status_label.setText("Loading...")
        self._status_label.setStyleSheet("font-size: 9px; color: #808080; background: transparent;")

        threading.Thread(
            target=self._do_load_context,
            args=(repos, folders),
            daemon=True,
        ).start()

    def _do_load_context(self, repos: list[str], folders: list[str]) -> None:
        import urllib.request
        try:
            body = json.dumps({
                "repos": repos,
                "knowledge_path": self._knowledge_path,
                "knowledge_paths": self._knowledge_paths,
                "knowledge_folders": folders,
            }).encode()
            req = urllib.request.Request(
                f"http://127.0.0.1:{self._port}/config",
                data=body,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=15) as resp:
                json.loads(resp.read().decode())

            r, f = len(repos), len(folders)
            parts = []
            if r:
                parts.append(f"{r} repo{'s' if r != 1 else ''}")
            if f:
                parts.append(f"{f} folder{'s' if f != 1 else ''}")
            msg = f"✓ Loaded {', '.join(parts)}"
            style = "font-size: 9px; color: #4ec9b0; background: transparent;"
        except Exception as exc:
            msg = f"Error: {exc}"
            style = "font-size: 9px; color: #f14c4c; background: transparent;"

        QMetaObject.invokeMethod(
            self._status_label, "setText",
            Qt.ConnectionType.QueuedConnection,
            Q_ARG(str, msg),
        )
        QMetaObject.invokeMethod(
            self._status_label, "setStyleSheet",
            Qt.ConnectionType.QueuedConnection,
            Q_ARG(str, style),
        )
        QMetaObject.invokeMethod(
            self._load_btn, "setEnabled",
            Qt.ConnectionType.QueuedConnection,
            Q_ARG(bool, True),
        )

    # ---- Past Conversations ----

    def _open_conversation_picker(self) -> None:
        """Open the modal picker for past Claude Code conversations."""
        # Default repo for the dropdown: first checked chip, else first known repo.
        checked = self._get_selected_repos()
        default_repo = checked[0] if checked else (self._repos[0]["path"] if self._repos else "")
        # Pull all known repos so the dropdown can switch between them.
        repos = list(self._repos)
        # Workspace roots also have their own Claude Code conversations.
        workspaces = list(self._repos_workspaces)
        dlg = _ConversationPickerDialog(
            port=self._port,
            repos=repos,
            workspaces=workspaces,
            default_repo=default_repo,
            parent=self,
        )
        # Apply sharing=none to everything now, and again right after the
        # dialog paints, so the picker never leaks into a screen share.
        _hide_all_windows_from_capture()
        QTimer.singleShot(0, _hide_all_windows_from_capture)
        QTimer.singleShot(50, _hide_all_windows_from_capture)
        dlg.exec()

    def _detach_conversation(self) -> None:
        # Optimistic local update: hide the button and update the label
        # immediately so the user sees feedback even before the POST lands.
        # If the POST fails, _do_detach_conversation restores the UI.
        prev = self._attached
        self.set_attached_conversation("null")
        self._status_label.setText("Detaching…")
        self._status_label.setStyleSheet(
            "font-size: 9px; color: #808080; background: transparent;"
        )
        threading.Thread(
            target=self._do_detach_conversation, args=(prev,), daemon=True
        ).start()

    def _do_detach_conversation(self, prev: dict | None) -> None:
        import urllib.request
        try:
            # aiohttp rejects some malformed empty POSTs on certain versions;
            # send an explicit JSON object body to stay compatible.
            req = urllib.request.Request(
                f"http://127.0.0.1:{self._port}/conversation/detach",
                data=b"{}",
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                resp.read()
            # Success path: broadcast will confirm and refresh the UI.
            QMetaObject.invokeMethod(
                self._status_label, "setText",
                Qt.ConnectionType.QueuedConnection,
                Q_ARG(str, "✓ Detached"),
            )
            QMetaObject.invokeMethod(
                self._status_label, "setStyleSheet",
                Qt.ConnectionType.QueuedConnection,
                Q_ARG(str, "font-size: 9px; color: #4ec9b0; background: transparent;"),
            )
        except Exception as exc:
            # Restore the UI — detach did NOT happen.
            sys.stderr.write(f"[overlay] detach failed: {exc}\n")
            sys.stderr.flush()
            if prev is not None:
                QMetaObject.invokeMethod(
                    self, "set_attached_conversation",
                    Qt.ConnectionType.QueuedConnection,
                    Q_ARG(str, json.dumps(prev)),
                )
            QMetaObject.invokeMethod(
                self._status_label, "setText",
                Qt.ConnectionType.QueuedConnection,
                Q_ARG(str, f"Detach failed: {exc}"),
            )
            QMetaObject.invokeMethod(
                self._status_label, "setStyleSheet",
                Qt.ConnectionType.QueuedConnection,
                Q_ARG(str, "font-size: 9px; color: #f14c4c; background: transparent;"),
            )

    @Slot(str)
    def set_attached_conversation(self, info_json: str) -> None:
        """Update the 'Attached:' label and Detach button visibility.

        info_json is either a JSON dict (attached) or the string 'null' (detached).
        Called via QMetaObject.invokeMethod from the WS message handler.
        """
        try:
            info = json.loads(info_json) if info_json and info_json != "null" else None
        except Exception:
            info = None
        self._attached = info
        if info:
            title = info.get("title", "Untitled")
            display = title if len(title) <= 60 else title[:57] + "…"
            extra = []
            if info.get("turn_count"):
                extra.append(f"{info['turn_count']} turns")
            if info.get("truncated"):
                extra.append("truncated")
            suffix = f" ({', '.join(extra)})" if extra else ""
            self._attached_label.setText(f"Attached: {display}{suffix}")
            self._attached_label.setStyleSheet(
                "font-size: 9px; color: #4ec9b0; background: transparent;"
            )
            self._detach_btn.show()
        else:
            self._attached_label.setText("Attached: none")
            self._attached_label.setStyleSheet(
                "font-size: 9px; color: #808080; background: transparent;"
            )
            self._detach_btn.hide()


# ---------------------------------------------------------------------------
# Conversation picker dialog
# ---------------------------------------------------------------------------

class _ConversationPickerDialog(QDialog):
    """Modal picker for past Claude Code conversations.

    Top: repo dropdown (lets user switch which repo to filter by).
    Middle: list of conversations for the chosen repo (title + relative time + msg count).
    Bottom: Cancel / Attach.
    """

    def __init__(
        self,
        port: int,
        repos: list[dict],
        default_repo: str,
        workspaces: list[str] | None = None,
        parent=None,
    ) -> None:
        super().__init__(parent)
        self._port = port
        self._repos = repos  # [{name, path, sanitized_name}, ...]
        self._workspaces = workspaces or []
        self._default_repo = default_repo
        self._fetch_gen = 0  # generation counter to discard stale fetch responses
        self._setup_ui()
        # Auto-load the default repo's conversations on open.
        if self._repo_combo.count():
            self._on_repo_changed(self._repo_combo.currentIndex())

    def showEvent(self, event) -> None:
        """Hide the dialog's NSWindow from screen capture."""
        super().showEvent(event)
        _hide_all_windows_from_capture()
        # Re-apply shortly after — the first call can land before NSApp.windows()
        # reflects the newly-created dialog NSWindow.
        QTimer.singleShot(0, _hide_all_windows_from_capture)
        QTimer.singleShot(50, _hide_all_windows_from_capture)

    def _setup_ui(self) -> None:
        self.setWindowTitle("Attach past Claude Code conversation")
        self.setModal(True)
        self.resize(540, 620)
        self.setStyleSheet("""
            QDialog { background: #0d1117; color: #e6edf3; }
            QLabel { color: #8b949e; background: transparent; font-size: 11px; }
            QComboBox {
                background: #161b22; border: 1px solid #30363d; border-radius: 5px;
                color: #e6edf3; padding: 4px 8px; font-size: 11px;
            }
            QComboBox QAbstractItemView {
                background: #161b22; color: #e6edf3; border: 1px solid #30363d;
                selection-background-color: #1f6feb;
            }
            QListWidget {
                background: #161b22; border: 1px solid #30363d; border-radius: 6px;
                color: #e6edf3; font-size: 12px; padding: 4px;
            }
            QListWidget::item { padding: 6px 8px; border-radius: 4px; }
            QListWidget::item:selected { background: #1f6feb; color: white; }
            QListWidget::item:hover { background: #21262d; }
            QPushButton {
                background: #21262d; color: #e6edf3; border: 1px solid #30363d;
                border-radius: 5px; padding: 6px 14px; font-size: 11px;
            }
            QPushButton:hover { border-color: #4ec9b0; }
            QPushButton#primary {
                background: #238636; border-color: #238636; color: white; font-weight: 600;
            }
            QPushButton#primary:hover { background: #2ea043; }
            QPushButton#primary:disabled { background: #1a2a1a; color: #5a5a5a; border-color: #1a2a1a; }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(10)

        # Repo dropdown
        repo_label = QLabel("Repository")
        layout.addWidget(repo_label)

        self._repo_combo = QComboBox()
        default_idx = 0
        idx = 0
        # Workspace roots first (parent folders of repos)
        for ws in self._workspaces:
            from pathlib import Path as _P
            label = f"Workspace · {_P(ws).name}"
            self._repo_combo.addItem(label, ws)
            if ws == self._default_repo:
                default_idx = idx
            idx += 1
        # Visual separator between workspaces and repos
        if self._workspaces and self._repos:
            self._repo_combo.insertSeparator(idx)
            idx += 1  # separator occupies a slot
        # Individual repos
        for r in self._repos:
            name = r.get("sanitized_name") or r.get("name", "")
            self._repo_combo.addItem(name, r["path"])
            if r["path"] == self._default_repo:
                default_idx = idx
            idx += 1
        if idx > 0:
            self._repo_combo.setCurrentIndex(default_idx)
        self._repo_combo.currentIndexChanged.connect(self._on_repo_changed)
        layout.addWidget(self._repo_combo)

        # List
        list_label = QLabel("Conversations (most recent first)")
        layout.addWidget(list_label)

        self._list = QListWidget()
        self._list.itemDoubleClicked.connect(lambda _: self._attach_selected())
        self._list.itemSelectionChanged.connect(self._update_attach_btn)
        layout.addWidget(self._list, 1)

        self._status = QLabel("")
        self._status.setStyleSheet("color: #8b949e; background: transparent; font-size: 10px;")
        layout.addWidget(self._status)

        # Buttons
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        self._cancel_btn = QPushButton("Cancel")
        self._cancel_btn.clicked.connect(self.reject)
        btn_row.addWidget(self._cancel_btn)
        self._attach_btn = QPushButton("Attach")
        self._attach_btn.setObjectName("primary")
        self._attach_btn.setEnabled(False)
        self._attach_btn.clicked.connect(self._attach_selected)
        btn_row.addWidget(self._attach_btn)
        layout.addLayout(btn_row)

    def _on_repo_changed(self, _idx: int) -> None:
        path = self._repo_combo.currentData()
        if not path:
            return
        self._fetch_gen += 1
        self._list.clear()
        self._status.setText("Loading…")
        self._update_attach_btn()
        threading.Thread(
            target=self._do_fetch, args=(path, self._fetch_gen), daemon=True
        ).start()

    def _do_fetch(self, repo_path: str, gen: int) -> None:
        import urllib.request
        import urllib.parse
        try:
            qs = urllib.parse.urlencode({"repo": repo_path})
            req = urllib.request.Request(
                f"http://127.0.0.1:{self._port}/conversations?{qs}"
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode())
            convs = data.get("conversations", [])
        except Exception as exc:
            if gen != self._fetch_gen:
                return  # stale response — user already switched repos
            QMetaObject.invokeMethod(
                self, "_on_fetch_error",
                Qt.ConnectionType.QueuedConnection,
                Q_ARG(str, str(exc)),
            )
            return
        if gen != self._fetch_gen:
            return  # stale response — user already switched repos
        QMetaObject.invokeMethod(
            self, "_on_fetch_loaded",
            Qt.ConnectionType.QueuedConnection,
            Q_ARG(str, json.dumps(convs)),
        )

    @Slot(str)
    def _on_fetch_loaded(self, convs_json: str) -> None:
        try:
            convs = json.loads(convs_json)
        except Exception:
            convs = []
        self._list.clear()
        if not convs:
            self._status.setText("No Claude Code conversations found for this repo.")
            self._update_attach_btn()
            return
        from meeting_helper.claude_history import relative_time
        for c in convs:
            title = c.get("title") or "Untitled"
            rel = relative_time(c.get("mtime") or 0)
            n = c.get("msg_count", 0)
            label = f"{title}\n    {rel} · {n} msgs"
            item = QListWidgetItem(label)
            item.setData(Qt.UserRole, c.get("session_id", ""))
            self._list.addItem(item)
        self._status.setText(f"{len(convs)} conversation{'s' if len(convs) != 1 else ''}")
        self._update_attach_btn()

    @Slot(str)
    def _on_fetch_error(self, err: str) -> None:
        self._list.clear()
        self._status.setText(f"Error: {err}")
        self._update_attach_btn()

    def _update_attach_btn(self) -> None:
        self._attach_btn.setEnabled(self._list.currentItem() is not None)

    def _attach_selected(self) -> None:
        item = self._list.currentItem()
        if not item:
            return
        session_id = item.data(Qt.UserRole)
        repo_path = self._repo_combo.currentData()
        if not session_id or not repo_path:
            return
        self._attach_btn.setEnabled(False)
        self._status.setText("Attaching…")
        threading.Thread(
            target=self._do_attach, args=(repo_path, session_id), daemon=True
        ).start()

    def _do_attach(self, repo_path: str, session_id: str) -> None:
        import urllib.request
        try:
            body = json.dumps({"repo": repo_path, "session_id": session_id}).encode()
            req = urllib.request.Request(
                f"http://127.0.0.1:{self._port}/conversation/attach",
                data=body,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=30) as resp:
                json.loads(resp.read().decode())
        except Exception as exc:
            QMetaObject.invokeMethod(
                self, "_on_fetch_error",
                Qt.ConnectionType.QueuedConnection,
                Q_ARG(str, f"attach failed: {exc}"),
            )
            return
        # Close dialog on success — overlay updates via WS broadcast.
        QMetaObject.invokeMethod(self, "accept", Qt.ConnectionType.QueuedConnection)


# ---------------------------------------------------------------------------
# Overlay window
# ---------------------------------------------------------------------------

BG_COLOR = "#0d1117"
BG_ALPHA = 230
PANEL_WIDTH = _ContextPanel.WIDTH


@dataclass
class OverlayState:
    """Pure-data state for OverlayWindow.

    Qt widgets, timers, threads, and the WS client stay as direct instance
    attributes on OverlayWindow — only data-only state lives here.
    """
    # Streaming / response state
    raw_md: str = ""
    current_html: str = ""
    history: list = field(default_factory=list)  # list[dict]
    nav_index: int = -1
    max_history: int = 3
    thinking: bool = False

    # Display preferences
    font_size: int = 14

    # Panel toggles
    panel_open: bool = False
    tasks_panel_open: bool = False

    # Per-segment transcript accumulation per role (for fade/clear logic)
    self_finals: str = ""
    other_finals: str = ""

    # Meeting metadata
    meeting_name: str = ""

    # UI interaction state
    drag_pos: object = None  # QPoint | None — typed loosely to keep dataclass import-light

    # Last 3 distinct topics seen during this overlay session (most recent first)
    topic_history: list = field(default_factory=list)  # list[dict] {topic, ticket_ids, full}


class OverlayWindow(QWidget):
    def __init__(self, port: int) -> None:
        super().__init__()
        self._port = port
        self.state = OverlayState()
        self._current_topic_text: str = ""
        # Coalesces fast AI chunk arrivals into one full re-render every
        # ~120 ms instead of rebuilding the entire HTML/Pygments tree on
        # every token. _md_to_html cost grows with content length, so
        # without throttling streaming chunks block the Qt main thread
        # progressively harder as the response grows.
        self._chunk_render_pending = False
        self._setup_window()
        self._build_ui()
        self._start_ws()
        # Re-apply sharing=none after 500ms — some MDM policies reset it on first paint
        QTimer.singleShot(500, self._apply_sharing_none)
        # Periodic re-apply so any newly-created child window (dialogs, menus)
        # inherits NSWindowSharingNone even if its own showEvent fires before
        # NSApp.windows() returns it.
        self._sharing_timer = QTimer(self)
        self._sharing_timer.setInterval(1500)
        self._sharing_timer.timeout.connect(self._apply_sharing_none)
        self._sharing_timer.start()

    def _setup_window(self) -> None:
        self.setWindowFlags(
            Qt.FramelessWindowHint
            | Qt.WindowStaysOnTopHint
        )
        self.setAttribute(Qt.WA_TranslucentBackground)

        screen = QApplication.primaryScreen().availableGeometry()
        # Roomier defaults — was 820x700; bumped so toolbar pills, transcript,
        # answer area, and side panels all have breathing room.
        width = min(screen.width() - 32, 960)
        height = min(screen.height() - 32, 780)
        self.resize(width, height)
        self.move(
            screen.right() - width - 90,
            screen.bottom() - height - 16,
        )

    def showEvent(self, event) -> None:
        """Hide window from screen capture/screen share."""
        super().showEvent(event)
        self._apply_sharing_none()

    def _apply_sharing_none(self) -> None:
        """Set NSWindowSharingNone on all app windows (main + any dialogs)."""
        _hide_all_windows_from_capture()

    def _build_ui(self) -> None:
        # Root: transparent outer, then the card which uses HBoxLayout
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        self._card = QWidget()
        self._card.setObjectName("card")
        self._card.setStyleSheet(f"""
            QWidget#card {{
                background: rgba(13,17,23,{BG_ALPHA});
                border: 1px solid #30363d;
                border-radius: 12px;
            }}
        """)
        outer.addWidget(self._card)

        # Card uses HBoxLayout: main column + context panel
        card_layout = QHBoxLayout(self._card)
        card_layout.setContentsMargins(0, 0, 0, 0)
        card_layout.setSpacing(0)

        # ---- Main column ----
        main_col = QWidget()
        main_col.setStyleSheet("background: transparent;")
        main_layout = QVBoxLayout(main_col)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # Title bar
        title_bar = QWidget()
        title_bar.setFixedHeight(32)
        title_bar.setStyleSheet("background: transparent;")
        tb_layout = QHBoxLayout(title_bar)
        tb_layout.setContentsMargins(12, 0, 8, 0)

        self._status_dot = QLabel()
        self._status_dot.setText("\u25cf")
        self._status_dot.setStyleSheet("color: #555; font-size: 10px;")
        tb_layout.addWidget(self._status_dot)

        self._title_label = QLabel("Meeting Helper")
        self._title_label.setStyleSheet("color: #8b949e; font-size: 11px;")
        tb_layout.addWidget(self._title_label)
        tb_layout.addStretch()

        # Generate Brief button
        self._brief_btn = QPushButton("📋 Brief")
        self._brief_btn.setCursor(Qt.PointingHandCursor)
        self._brief_btn.setToolTip("Generate Standup Brief from local-todo")
        self._brief_btn.setStyleSheet("""
            QPushButton {
                background: rgba(30,111,235,0.18); color: #79b8ff;
                border: 1px solid #1f6feb; border-radius: 8px;
                padding: 4px 12px; font-size: 11px;
                font-weight: 500;
            }
            QPushButton:hover { background: rgba(30,111,235,0.28); color: #c8e1ff; }
            QPushButton:disabled { color: #555; border-color: #333; background: transparent; }
        """)
        self._brief_btn.setMinimumHeight(28)
        self._brief_btn.clicked.connect(self._on_brief_clicked)
        tb_layout.addWidget(self._brief_btn)

        # Topic indicator pill — populated by 'topic' WS messages.
        self._topic_label = QLabel("")
        self._topic_label.setStyleSheet(
            "QLabel { background: rgba(78,201,176,0.10); color: #4ec9b0; "
            "border: 1px solid #2d6f5f; border-radius: 8px; "
            "padding: 4px 10px; font-size: 11px; }"
        )
        self._topic_label.setTextFormat(Qt.TextFormat.PlainText)
        self._topic_label.setMaximumWidth(280)
        self._topic_label.setMinimumHeight(28)
        self._topic_label.hide()
        tb_layout.addWidget(self._topic_label)

        # Explain-more (follow-up) button — only shown when there's a topic.
        self._explain_btn = QPushButton("💬 Explain")
        self._explain_btn.setCursor(Qt.PointingHandCursor)
        self._explain_btn.setToolTip("Ask AI to explain more about the current topic")
        self._explain_btn.setStyleSheet("""
            QPushButton {
                background: transparent; color: #4ec9b0;
                border: 1px solid #2d6f5f; border-radius: 8px;
                padding: 4px 10px; font-size: 11px;
            }
            QPushButton:hover { background: rgba(78,201,176,0.18); color: #79f0d2; }
            QPushButton:disabled { color: #555; border-color: #333; }
        """)
        self._explain_btn.setMinimumHeight(28)
        self._explain_btn.hide()
        self._explain_btn.clicked.connect(self._on_explain_clicked)
        tb_layout.addWidget(self._explain_btn)

        tb_layout.addSpacing(8)

        # Info pills — right side of title bar
        _pill_label_css = (
            "QLabel { background: rgba(30,37,46,0.9); border: 1px solid #30363d; "
            "border-radius: 8px; padding: 1px 7px; font-size: 10px; font-family: Menlo, monospace; }"
        )
        _pill_btn_css = (
            "QPushButton { background: rgba(30,37,46,0.9); border: 1px solid #30363d; "
            "border-radius: 8px; padding: 1px 7px; font-size: 10px; font-family: Menlo, monospace; "
            "color: #8b949e; }"
            "QPushButton:hover { border-color: #4ec9b0; color: #e6edf3; }"
        )

        self._pill_transcriber = QPushButton("\u2014")
        self._pill_transcriber.setStyleSheet(_pill_btn_css)
        self._pill_transcriber.setCursor(Qt.PointingHandCursor)
        self._pill_transcriber.setToolTip("Switch transcriber")
        self._pill_transcriber.clicked.connect(self._show_transcriber_menu)
        tb_layout.addWidget(self._pill_transcriber)

        self._pill_model = QPushButton("\u2014")
        self._pill_model.setStyleSheet(_pill_btn_css)
        self._pill_model.setCursor(Qt.PointingHandCursor)
        self._pill_model.setToolTip("Switch AI provider / model")
        self._pill_model.clicked.connect(self._show_model_menu)
        tb_layout.addWidget(self._pill_model)

        self._pill_cpu = QLabel("CPU \u2014")
        self._pill_cpu.setStyleSheet(_pill_label_css + "QLabel { color: #8b949e; }")
        tb_layout.addWidget(self._pill_cpu)

        tb_layout.addSpacing(4)

        # Clear transcript button
        self._clear_btn = QPushButton("🗑")
        self._clear_btn.setFixedSize(28, 28)
        self._clear_btn.setCursor(Qt.PointingHandCursor)
        self._clear_btn.setToolTip("Clear transcript buffer")
        self._clear_btn.setStyleSheet("""
            QPushButton {
                background: transparent; color: #555; border: 1px solid #333;
                border-radius: 4px; font-size: 11px;
            }
            QPushButton:hover { color: #f85149; border-color: #f85149; }
        """)
        self._clear_btn.clicked.connect(self._clear_transcript)
        tb_layout.addWidget(self._clear_btn)

        # Proactive toggle button
        self._proactive_btn = QPushButton("⚡")
        self._proactive_btn.setFixedSize(28, 28)
        self._proactive_btn.setCheckable(True)
        self._proactive_btn.setChecked(False)
        self._proactive_btn.setCursor(Qt.PointingHandCursor)
        self._proactive_btn.setToolTip("Toggle AI assistant (proactive answers + auto-context)")
        self._proactive_btn.setStyleSheet("""
            QPushButton {
                background: transparent; color: #555; border: 1px solid #333;
                border-radius: 4px; font-size: 11px;
            }
            QPushButton:checked { color: #f0c040; border-color: #f0c040; }
            QPushButton:hover { border-color: #4ec9b0; }
        """)
        self._proactive_btn.clicked.connect(self._toggle_proactive)
        tb_layout.addWidget(self._proactive_btn)

        # Context panel toggle button
        self._toggle_btn = QPushButton("◀")
        self._toggle_btn.setFixedSize(28, 28)
        self._toggle_btn.setCursor(Qt.PointingHandCursor)
        self._toggle_btn.setToolTip("Toggle context panel")
        self._toggle_btn.setStyleSheet("""
            QPushButton {
                background: transparent; color: #555; border: 1px solid #333;
                border-radius: 4px; font-size: 11px;
            }
            QPushButton:hover { color: #4ec9b0; border-color: #4ec9b0; }
        """)
        self._toggle_btn.clicked.connect(self._toggle_panel)
        tb_layout.addWidget(self._toggle_btn)

        close_btn = QPushButton("\u2715")
        close_btn.setFixedSize(28, 28)
        close_btn.setCursor(Qt.PointingHandCursor)
        close_btn.setStyleSheet("""
            QPushButton { background: transparent; color: #555; border: none; font-size: 14px; }
            QPushButton:hover { color: #f85149; }
        """)
        close_btn.clicked.connect(self.close)
        tb_layout.addWidget(close_btn)

        main_layout.addWidget(title_bar)

        # Divider
        divider = QWidget()
        divider.setFixedHeight(1)
        divider.setStyleSheet("background: #21262d;")
        main_layout.addWidget(divider)

        # Topic history strip — last 3 distinct topics as clickable chips.
        # Hidden until the second topic appears (no point showing one chip while it's
        # already on the toolbar pill).
        self._topic_history_row = QWidget()
        self._topic_history_row.setStyleSheet("background: transparent;")
        self._topic_history_layout = QHBoxLayout(self._topic_history_row)
        self._topic_history_layout.setContentsMargins(12, 4, 12, 4)
        self._topic_history_layout.setSpacing(6)

        # Leading label
        self._topic_history_label = QLabel("Recent:")
        self._topic_history_label.setStyleSheet("color: #555; font-size: 10px;")
        self._topic_history_layout.addWidget(self._topic_history_label)
        self._topic_history_layout.addStretch()

        self._topic_history_row.hide()
        main_layout.addWidget(self._topic_history_row)

        # Thinking label
        self._thinking_label = QLabel("  Thinking...")
        self._thinking_label.setStyleSheet("color: #8b949e; font-size: 12px; padding: 8px 12px;")
        self._thinking_label.hide()
        main_layout.addWidget(self._thinking_label)

        # Scroll area + text browser for AI response
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(scroll.Shape.NoFrame)
        scroll.setStyleSheet("""
            QScrollArea { background: transparent; border: none; }
            QScrollBar:vertical { width: 5px; background: transparent; }
            QScrollBar::handle:vertical { background: #30363d; border-radius: 2px; }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0px; }
        """)

        self._browser = QTextBrowser()
        self._browser.setOpenExternalLinks(True)
        self._browser.setStyleSheet("background: transparent; border: none; color: #e6edf3;")
        self._browser.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        font = QFont("Helvetica Neue", self.state.font_size)
        self._browser.setFont(font)
        scroll.setWidget(self._browser)
        main_layout.addWidget(scroll)

        self._scroll = scroll

        # Cards label — sources from local-todo, populated by 'cards' WS messages.
        # RichText so we can render clickable <a href> links to ticket URLs.
        self._cards_label = QLabel("")
        self._cards_label.setWordWrap(True)
        self._cards_label.setStyleSheet(
            "color: #8b949e; font-size: 11px; padding: 4px 12px 4px; background: transparent;"
        )
        self._cards_label.setTextFormat(Qt.TextFormat.RichText)
        self._cards_label.setOpenExternalLinks(False)  # we open via linkActivated
        self._cards_label.linkActivated.connect(self._open_external_url)
        self._cards_label.hide()
        main_layout.addWidget(self._cards_label)

        # Two-row transcript display (self + other) — each row hides individually.
        # SELF row: your microphone speech.
        self._transcript_self_label = QLabel()
        self._transcript_self_label.setWordWrap(True)
        self._transcript_self_label.setTextFormat(Qt.TextFormat.PlainText)
        self._transcript_self_label.setStyleSheet(
            "color: #8b949e; font-size: 11px; padding: 4px 12px 0; background: transparent;"
        )
        self._transcript_self_label.hide()
        main_layout.addWidget(self._transcript_self_label)

        # OTHER row: system audio (other meeting participants).
        self._transcript_other_label = QLabel()
        self._transcript_other_label.setWordWrap(True)
        self._transcript_other_label.setTextFormat(Qt.TextFormat.PlainText)
        self._transcript_other_label.setStyleSheet(
            "color: #8b949e; font-size: 11px; padding: 0 12px 4px; background: transparent;"
        )
        self._transcript_other_label.hide()
        main_layout.addWidget(self._transcript_other_label)

        # Manual query input row
        input_row = QWidget()
        input_row.setStyleSheet("background: transparent;")
        ir_layout = QHBoxLayout(input_row)
        ir_layout.setContentsMargins(8, 4, 8, 4)
        ir_layout.setSpacing(6)

        self._input = QLineEdit()
        self._input.setPlaceholderText("Ask Claude something... (Enter to send)")
        self._input.setStyleSheet("""
            QLineEdit {
                background: #161b22; border: 1px solid #30363d; border-radius: 6px;
                color: #e6edf3; padding: 6px 10px; font-size: 14px;
            }
            QLineEdit:focus { border-color: #58a6ff; }
        """)
        self._input.returnPressed.connect(self._send_manual_query)
        ir_layout.addWidget(self._input)

        send_btn = QPushButton("\u27a4")
        send_btn.setFixedSize(28, 28)
        send_btn.setCursor(Qt.PointingHandCursor)
        send_btn.setStyleSheet("""
            QPushButton { background: #238636; color: white; border: none; border-radius: 6px; font-size: 14px; }
            QPushButton:hover { background: #2ea043; }
        """)
        send_btn.clicked.connect(self._send_manual_query)
        ir_layout.addWidget(send_btn)

        self._extract_task_btn = QPushButton("Extract Task")
        self._extract_task_btn.setCursor(Qt.PointingHandCursor)
        self._extract_task_btn.setMinimumHeight(28)
        self._extract_task_btn.setStyleSheet("""
            QPushButton { background: #1f6feb; color: white; border: none; border-radius: 6px;
                          padding: 6px 12px; font-size: 12px; }
            QPushButton:hover { background: #388bfd; }
            QPushButton:disabled { background: #1a2438; color: #5a5a5a; }
        """)
        self._extract_task_btn.setEnabled(False)
        self._extract_task_btn.clicked.connect(self._on_extract_task_clicked)
        ir_layout.addWidget(self._extract_task_btn)

        self._tasks_toggle_btn = QPushButton("Tasks")
        self._tasks_toggle_btn.setCursor(Qt.PointingHandCursor)
        self._tasks_toggle_btn.setMinimumHeight(28)
        self._tasks_toggle_btn.setStyleSheet("""
            QPushButton { background: transparent; color: #8b949e; border: 1px solid #30363d;
                          border-radius: 6px; padding: 6px 12px; font-size: 12px; }
            QPushButton:hover { color: #4ec9b0; border-color: #4ec9b0; }
        """)
        self._tasks_toggle_btn.clicked.connect(self._toggle_tasks_panel)
        ir_layout.addWidget(self._tasks_toggle_btn)

        main_layout.addWidget(input_row)

        # Resize grip
        grip_row = QWidget()
        grip_row.setStyleSheet("background: transparent;")
        grip_layout = QHBoxLayout(grip_row)
        grip_layout.setContentsMargins(0, 0, 4, 4)
        grip_layout.addStretch()
        grip = QSizeGrip(self)
        grip.setStyleSheet("background: transparent;")
        grip_layout.addWidget(grip)
        main_layout.addWidget(grip_row)

        card_layout.addWidget(main_col, 1)

        # ---- Context panel (hidden by default) ----
        # Vertical separator
        self._panel_sep = QWidget()
        self._panel_sep.setFixedWidth(1)
        self._panel_sep.setStyleSheet("background: #21262d;")
        self._panel_sep.hide()
        card_layout.addWidget(self._panel_sep)

        # Scroll area wrapping the panel for overflow
        self._panel_scroll = QScrollArea()
        self._panel_scroll.setWidgetResizable(True)
        self._panel_scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        self._panel_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._panel_scroll.setStyleSheet("""
            QScrollArea { background: transparent; border: none; }
            QScrollBar:vertical { width: 4px; background: transparent; }
            QScrollBar::handle:vertical { background: #30363d; border-radius: 2px; }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0px; }
        """)
        self._panel_scroll.setFixedWidth(PANEL_WIDTH)

        self._panel = _ContextPanel(port=self._port)
        self._panel_scroll.setWidget(self._panel)
        # Hidden by default — toggle button at top-right opens it.
        self._panel_sep.hide()
        self._panel_scroll.hide()
        self._toggle_btn.setText("◀")
        card_layout.addWidget(self._panel_scroll)

        # ---- Tasks panel (collapsible, hidden by default) ----
        self._tasks_panel_sep = QWidget()
        self._tasks_panel_sep.setFixedWidth(1)
        self._tasks_panel_sep.setStyleSheet("background: #21262d;")
        self._tasks_panel_sep.hide()
        card_layout.addWidget(self._tasks_panel_sep)

        self._tasks_panel_scroll = QScrollArea()
        self._tasks_panel_scroll.setWidgetResizable(True)
        self._tasks_panel_scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        self._tasks_panel_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._tasks_panel_scroll.setStyleSheet("""
            QScrollArea { background: transparent; border: none; }
            QScrollBar:vertical { width: 4px; background: transparent; }
            QScrollBar::handle:vertical { background: #30363d; border-radius: 2px; }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0px; }
        """)
        self._tasks_panel_scroll.setFixedWidth(_TasksOverlayPanel.WIDTH)

        self._tasks_overlay_panel = _TasksOverlayPanel()
        self._tasks_panel_scroll.setWidget(self._tasks_overlay_panel)
        self._tasks_panel_scroll.hide()
        self.state.tasks_panel_open = False
        card_layout.addWidget(self._tasks_panel_scroll)

    def _resize_clamped(self, target_w: int, target_h: int) -> None:
        """Resize the overlay, clamped to the available screen width."""
        screen = QApplication.primaryScreen().availableGeometry()
        max_w = screen.width() - 32
        self.resize(max(400, min(target_w, max_w)), target_h)

    def _toggle_tasks_panel(self) -> None:
        w = _TasksOverlayPanel.WIDTH + 1
        if self.state.tasks_panel_open:
            self._tasks_panel_sep.hide()
            self._tasks_panel_scroll.hide()
            self.state.tasks_panel_open = False
            self._resize_clamped(self.width() - w, self.height())
        else:
            # Close the context panel first so we never stack both
            if self.state.panel_open:
                self._panel_sep.hide()
                self._panel_scroll.hide()
                self._toggle_btn.setText("◀")
                self.state.panel_open = False
                self._resize_clamped(self.width() - PANEL_WIDTH - 1, self.height())
            self._tasks_panel_sep.show()
            self._tasks_panel_scroll.show()
            self.state.tasks_panel_open = True
            self._resize_clamped(self.width() + w, self.height())

    def _toggle_panel(self) -> None:
        if self.state.panel_open:
            self._panel_sep.hide()
            self._panel_scroll.hide()
            self._toggle_btn.setText("◀")
            self.state.panel_open = False
            self._resize_clamped(self.width() - PANEL_WIDTH - 1, self.height())
        else:
            # Close the tasks panel first so we never stack both
            if self.state.tasks_panel_open:
                self._tasks_panel_sep.hide()
                self._tasks_panel_scroll.hide()
                self.state.tasks_panel_open = False
                self._resize_clamped(self.width() - _TasksOverlayPanel.WIDTH - 1, self.height())
            self._panel_sep.show()
            self._panel_scroll.show()
            self._toggle_btn.setText("▶")
            self.state.panel_open = True
            self._resize_clamped(self.width() + PANEL_WIDTH + 1, self.height())
            self._panel.refresh()

    def _clear_transcript(self) -> None:
        import urllib.request as _ur
        try:
            req = _ur.Request(
                f"http://127.0.0.1:{self._port}/transcript/clear",
                data=b"{}",
                headers={"Content-Type": "application/json"},
            )
            _ur.urlopen(req, timeout=2)
        except Exception:
            pass
        self._transcript_self_label.setText("")
        self._transcript_self_label.hide()
        self._transcript_other_label.setText("")
        self._transcript_other_label.hide()
        self.state.self_finals = ""
        self.state.other_finals = ""

    def _toggle_proactive(self) -> None:
        enabled = self._proactive_btn.isChecked()
        import urllib.request as _ur
        try:
            data = json.dumps({"enabled": enabled}).encode()
            req = _ur.Request(
                f"http://127.0.0.1:{self._port}/proactive",
                data=data,
                headers={"Content-Type": "application/json"},
            )
            _ur.urlopen(req, timeout=2)
        except Exception:
            pass

    # ---- Provider / transcriber menus ----

    def _show_transcriber_menu(self) -> None:
        menu = QMenu(self)
        menu.setStyleSheet(
            "QMenu { background: #161b22; border: 1px solid #30363d; color: #e6edf3; font-size: 12px; }"
            "QMenu::item:selected { background: #30363d; }"
        )
        for key, label in [("whisper", "Whisper"), ("deepgram", "Deepgram")]:
            action = menu.addAction(label)
            action.setData(key)
        chosen = menu.exec(self._pill_transcriber.mapToGlobal(
            QPoint(0, self._pill_transcriber.height())
        ))
        if chosen:
            self._post_provider({"transcriber": chosen.data()})

    def _show_model_menu(self) -> None:
        menu = QMenu(self)
        menu.setStyleSheet(
            "QMenu { background: #161b22; border: 1px solid #30363d; color: #e6edf3; font-size: 12px; }"
            "QMenu::item:selected { background: #30363d; }"
            "QMenu::item:disabled { color: #484f58; }"
        )
        # Claude section
        claude_header = menu.addAction("Claude")
        claude_header.setEnabled(False)
        for alias, label in [("sonnet", "  Sonnet"), ("opus", "  Opus"), ("haiku", "  Haiku")]:
            action = menu.addAction(label)
            action.setData(("claude", "claude_model", alias))
        menu.addSeparator()
        # Gemini section
        gemini_header = menu.addAction("Gemini")
        gemini_header.setEnabled(False)
        for alias, label in [("flash", "  Flash"), ("pro", "  Pro")]:
            action = menu.addAction(label)
            action.setData(("gemini", "gemini_model", alias))
        menu.addSeparator()
        # Ollama section
        ollama_header = menu.addAction("Ollama")
        ollama_header.setEnabled(False)
        cur_local = self._pill_model.text() or "qwen2.5-coder:3b"
        action = menu.addAction(f"  {cur_local}")
        action.setData(("local", "local_model", cur_local))

        chosen = menu.exec(self._pill_model.mapToGlobal(
            QPoint(0, self._pill_model.height())
        ))
        if chosen and chosen.data():
            provider, model_key, model_val = chosen.data()
            self._post_provider({"provider": provider, model_key: model_val})

    def _post_provider(self, body: dict) -> None:
        """POST provider change to daemon in a background thread."""
        import urllib.request as _ur
        def _do():
            try:
                data = json.dumps(body).encode()
                req = _ur.Request(
                    f"http://127.0.0.1:{self._port}/provider",
                    data=data,
                    headers={"Content-Type": "application/json"},
                )
                _ur.urlopen(req, timeout=5)
            except Exception:
                pass
        threading.Thread(target=_do, daemon=True).start()

    def _start_ws(self) -> None:
        self._ws_thread = QThread()
        self._ws_worker = WSWorker(self._port)
        self._ws_worker.moveToThread(self._ws_thread)
        self._ws_thread.started.connect(self._ws_worker.start)
        self._ws_worker.message.connect(self._on_message)
        self._ws_worker.connected.connect(self._on_connected)
        self._ws_worker.disconnected.connect(self._on_disconnected)
        self._ws_thread.start()

    # ---- Manual query ----

    def _send_manual_query(self) -> None:
        text = self._input.text().strip()
        if not text:
            return
        self._input.clear()
        threading.Thread(target=self._post_query, args=(text,), daemon=True).start()

    def _post_query(self, text: str) -> None:
        import urllib.request
        try:
            body = json.dumps({"text": text}).encode()
            req = urllib.request.Request(
                f"http://127.0.0.1:{self._port}/query",
                data=body,
                headers={"Content-Type": "application/json"},
            )
            urllib.request.urlopen(req, timeout=60)
        except Exception:
            pass

    def _render_cards(self, items: list) -> None:
        """Render local-todo source cards into the cards label as clickable links.

        Used by both the `cards` WS branch and the `brief` WS branch.
        """
        if not items:
            self._cards_label.hide()
            return
        from html import escape
        lines: list[str] = []
        for c in items[:3]:
            cid = str(c.get("id", "?"))
            title = str(c.get("title", ""))
            meta_parts: list[str] = []
            if c.get("status"):
                meta_parts.append(str(c["status"]))
            if c.get("due"):
                meta_parts.append(f"Due {c['due']}")
            meta = "  ·  ".join(meta_parts)
            url = str(c.get("url", "")).strip()
            head_html = escape(f"[{cid}] {title}")
            if url:
                head_html = f'<a href="{escape(url)}" style="color: #4ec9b0; text-decoration: none;">{head_html}</a>'
            line = head_html
            if meta:
                line += f"  ·  <span style='color:#8b949e;'>{escape(meta)}</span>"
            lines.append(line)
        self._cards_label.setText("<br>".join(lines))
        self._cards_label.show()

    @staticmethod
    def _open_external_url(url: str) -> None:
        """Open a local-todo / external URL in the user's default browser."""
        if not url:
            return
        try:
            import webbrowser
            webbrowser.open(url, new=2)
        except Exception:
            pass

    # ---- Brief / explain-more actions ----

    def _on_brief_clicked(self) -> None:
        self._brief_btn.setEnabled(False)
        self._brief_btn.setText("📋 Brief…")
        threading.Thread(target=self._post_brief, daemon=True).start()

    def _post_brief(self) -> None:
        import urllib.request
        try:
            req = urllib.request.Request(
                f"http://127.0.0.1:{self._port}/brief",
                data=b"{}",
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            urllib.request.urlopen(req, timeout=30)
        except Exception:
            pass
        finally:
            # Re-enable on the GUI thread via a single-shot
            QTimer.singleShot(0, self._restore_brief_btn)

    def _restore_brief_btn(self) -> None:
        try:
            self._brief_btn.setEnabled(True)
            self._brief_btn.setText("📋 Brief")
        except Exception:
            pass

    def _on_explain_clicked(self) -> None:
        topic = self._current_topic_text or ""
        if not topic.strip():
            return
        prompt = f"Explain more about {topic}."
        threading.Thread(target=self._post_query, args=(prompt,), daemon=True).start()

    def _render_topic_history(self) -> None:
        """Render the topic_history strip — clears existing chips, rebuilds.

        Each chip is a small QPushButton; click triggers an Explain follow-up.
        """
        layout = self._topic_history_layout
        # Remove old chip widgets — keep the leading label and the trailing stretch.
        # The layout has: [label, <chips...>, stretch]. We rebuild everything
        # except the leading label by clearing items[1:].
        # Iterate backwards to safely remove.
        while layout.count() > 1:
            item = layout.takeAt(1)
            w = item.widget()
            if w is not None:
                w.setParent(None)
                w.deleteLater()

        history = self.state.topic_history
        if not history:
            self._topic_history_row.hide()
            return

        # Skip the most recent — it's already on the toolbar pill.
        chips = history[1:] if len(history) >= 2 else []
        if not chips:
            self._topic_history_row.hide()
            return

        for entry in chips:
            text = entry.get("topic", "")
            full = entry.get("full") or text
            if not text:
                continue
            display = text if len(text) <= 28 else text[:25] + "…"
            chip = QPushButton(display)
            chip.setCursor(Qt.PointingHandCursor)
            chip.setToolTip(f"Explain more about {full}")
            chip.setStyleSheet("""
                QPushButton {
                    background: transparent; color: #79b8ff;
                    border: 1px solid #1f6feb44; border-radius: 8px;
                    padding: 3px 10px; font-size: 11px;
                }
                QPushButton:hover { background: rgba(31,111,235,0.18); color: #c8e1ff; border-color: #1f6feb; }
            """)
            # Capture full topic via default arg
            chip.clicked.connect(lambda _checked=False, t=full: self._on_history_chip_clicked(t))
            layout.addWidget(chip)

        # Add a trailing stretch so chips align left
        layout.addStretch()
        self._topic_history_row.show()

    def _on_history_chip_clicked(self, full_topic: str) -> None:
        if not full_topic.strip():
            return
        prompt = f"Explain more about {full_topic}."
        threading.Thread(target=self._post_query, args=(prompt,), daemon=True).start()

    # ---- Extract Task ----

    def _on_extract_task_clicked(self) -> None:
        self._extract_task_btn.setEnabled(False)
        threading.Thread(target=self._post_extract_task, daemon=True).start()

    def _post_extract_task(self) -> None:
        import urllib.request
        try:
            req = urllib.request.Request(
                f"http://127.0.0.1:{self._port}/extract-task",
                data=b"",
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            urllib.request.urlopen(req, timeout=120)
        except Exception:
            QTimer.singleShot(0, lambda: self._extract_task_btn.setEnabled(True))

    def _show_status_toast(self, text: str, duration_ms: int = 2500) -> None:
        self._thinking_label.setText(f"  {text}")
        self._thinking_label.show()
        QTimer.singleShot(duration_ms, self._thinking_label.hide)

    def _render_chunk(self) -> None:
        """Render the current accumulated AI response into the browser.

        Called via a debounced QTimer to coalesce rapid chunk arrivals.
        Preserves scroll-following behavior: stays pinned to bottom if the
        user was at the bottom; otherwise restores their scroll position.
        """
        self._chunk_render_pending = False
        sb = self._scroll.verticalScrollBar()
        was_at_bottom = sb.maximum() == 0 or (sb.maximum() - sb.value()) < 60
        old_pos = sb.value()
        self._browser.setHtml(_md_to_html(self.state.raw_md, self.state.font_size))
        self.state.current_html = self.state.raw_md
        if was_at_bottom:
            QTimer.singleShot(0, lambda: self._scroll.verticalScrollBar().setValue(
                self._scroll.verticalScrollBar().maximum()
            ))
        else:
            QTimer.singleShot(0, lambda p=old_pos: self._scroll.verticalScrollBar().setValue(p))

    # ---- Message handling ----

    @Slot(dict)
    def _on_message(self, msg: dict) -> None:
        t = msg.get("type")

        if t == "status":
            val = msg.get("value", "idle")
            if val == "processing":
                self._status_dot.setStyleSheet("color: #f85149; font-size: 10px;")
                self._panel.set_session_active(True)
            elif val == "listening":
                self._status_dot.setStyleSheet("color: #3fb950; font-size: 10px;")
                self._panel.set_session_active(True)
            else:
                self._status_dot.setStyleSheet("color: #555; font-size: 10px;")

        elif t == "cpu":
            pct = msg.get("process")
            rss = msg.get("proc_rss_mb")
            if pct is not None:
                mem_str = f"  {rss} MB" if rss is not None else ""
                self._pill_cpu.setText(f"CPU {pct}%{mem_str}")
                color = "#f85149" if pct >= 60 else "#d29922" if pct >= 30 else "#3fb950"
                self._pill_cpu.setStyleSheet(
                    "QLabel { background: rgba(30,37,46,0.9); border: 1px solid #30363d; "
                    f"border-radius: 8px; padding: 1px 7px; font-size: 10px; "
                    f"font-family: Menlo, monospace; color: {color}; }}"
                )

        elif t == "info":
            # Transcriber pill
            t_name = msg.get("transcriber", "") or "\u2014"
            if t_name.startswith("Deepgram"):
                dot, color = "\u25cf ", "#3fb950"
            elif t_name.startswith("Whisper"):
                dot, color = "\u25cf ", "#d29922"
            else:
                dot, color = "", "#555"
            short_t = "DG" if t_name.startswith("Deepgram") else t_name.replace(" (local)", "")
            self._pill_transcriber.setText(dot + short_t)
            self._pill_transcriber.setStyleSheet(
                "QPushButton { background: rgba(30,37,46,0.9); border: 1px solid #30363d; "
                f"border-radius: 8px; padding: 1px 7px; font-size: 10px; "
                f"font-family: Menlo, monospace; color: {color}; }}"
                "QPushButton:hover { border-color: #4ec9b0; color: #e6edf3; }"
            )

            # Model pill \u2014 hidden when no AI provider is configured (no key
            # for Claude/Gemini and not opted into local). Default True for
            # backwards compat with older daemons that don't send the flag.
            provider_ready = bool(msg.get("provider_configured", True))
            model = msg.get("model", "") or "\u2014"
            short_m = model.replace("claude-", "").replace("-latest", "")
            self._pill_model.setText(short_m)
            self._pill_model.setVisible(provider_ready)

            # Brief button is hidden when local-todo MCP isn't set up \u2014 there
            # are no tasks to summarize so the button would only error.
            self._brief_btn.setVisible(bool(msg.get("local_todo_configured", True)))

        elif t == "meeting_status":
            if msg.get("active"):
                app_name = msg.get("app", "")
                meeting_name = msg.get("meeting_name", "")
                parts = ["Meeting Helper"]
                if app_name:
                    parts.append(app_name)
                if meeting_name:
                    parts.append(f'"{meeting_name}"')
                self.state.meeting_name = meeting_name or app_name
                self._title_label.setText("  \u00b7  ".join(parts))
                self._title_label.setStyleSheet("color: #3fb950; font-size: 11px;")
                self._panel.set_session_active(True)
                self._extract_task_btn.setEnabled(True)
            else:
                self.state.meeting_name = ""
                self._title_label.setText("Meeting Helper  \u00b7  idle")
                self._title_label.setStyleSheet("color: #8b949e; font-size: 11px;")
                self._extract_task_btn.setEnabled(False)

        elif t == "tasks_extracted":
            added = msg.get("added", 0)
            if added > 0:
                self._show_status_toast(
                    f"+{added} task" + ("s" if added != 1 else "")
                )
                if not self.state.tasks_panel_open:
                    self._toggle_tasks_panel()
            else:
                self._show_status_toast("no new tasks")
            self._extract_task_btn.setEnabled(True)

        elif t == "tasks":
            self._tasks_overlay_panel.set_tasks(msg.get("tasks", []) or [])

        elif t == "topic":
            topic = (msg.get("topic") or "").strip()
            ticket_ids = msg.get("ticket_ids") or []
            # `cards` was deprecated from the topic broadcast (oversized JSON
            # was disconnecting WS clients). Use the count field instead and
            # fall back to the legacy list for older daemons.
            cards = msg.get("cards") or []
            warm_cards_count = msg.get("warm_cards_count")
            if warm_cards_count is None:
                warm_cards_count = len(cards)
            if not topic and not ticket_ids:
                self._current_topic_text = ""
                self._topic_label.hide()
                self._explain_btn.hide()
                return
            parts: list[str] = []
            if topic:
                parts.append(topic)
            if ticket_ids:
                parts.append(f"({', '.join(ticket_ids)})")
            if warm_cards_count:
                parts.append(f"· {warm_cards_count} warm")
            display = " ".join(parts)
            # Truncate display to keep the toolbar tidy; full topic still used for the Explain prompt
            if len(display) > 56:
                display = display[:53] + "…"
            self._topic_label.setText("Topic: " + display)
            self._topic_label.setToolTip(topic + (f" ({', '.join(ticket_ids)})" if ticket_ids else ""))
            self._topic_label.show()
            # Build the canonical text used for follow-up prompts
            base = topic or (", ".join(ticket_ids) if ticket_ids else "")
            self._current_topic_text = base
            self._explain_btn.show()

            # Update topic history (deduped by topic; max 3, most recent first).
            full = topic + (f" ({', '.join(ticket_ids)})" if ticket_ids else "")
            if topic:
                hist = self.state.topic_history
                # Dedupe — drop any prior entry with the same topic (case-insensitive)
                hist = [h for h in hist if h.get("topic", "").lower() != topic.lower()]
                hist.insert(0, {
                    "topic": topic,
                    "ticket_ids": list(ticket_ids),
                    "full": full,
                })
                self.state.topic_history = hist[:3]
                self._render_topic_history()

        elif t == "cards":
            self._render_cards(msg.get("items") or [])

        elif t == "meeting_ended":
            self.state.raw_md = ""
            self.state.current_html = ""
            self.state.history.clear()
            self.state.nav_index = -1
            self.state.meeting_name = ""
            self._browser.setHtml("")
            self._thinking_label.hide()
            self._transcript_self_label.hide()
            self._transcript_self_label.setText("")
            self._transcript_other_label.hide()
            self._transcript_other_label.setText("")
            self.state.self_finals = ""
            self.state.other_finals = ""
            self._title_label.setText("Meeting Helper  \u00b7  idle")
            self._title_label.setStyleSheet("color: #8b949e; font-size: 11px;")
            self._status_dot.setStyleSheet("color: #555; font-size: 10px;")
            self._panel.set_session_active(False)
            self._extract_task_btn.setEnabled(False)
            self._tasks_overlay_panel.set_tasks([])

        elif t == "config_changed":
            # Ignored lists updated — reload chips immediately
            new_ignored_repos = msg.get("ignored_repos", [])
            new_ignored_knowledge = msg.get("ignored_knowledge", [])
            if (new_ignored_repos != self._panel._ignored_repos or
                    new_ignored_knowledge != self._panel._ignored_knowledge):
                self._panel._ignored_repos = new_ignored_repos
                self._panel._ignored_knowledge = new_ignored_knowledge
                # Repos chips removed alongside context_loader.
                self._panel._repos = []
                self._panel._populate_chips()
                self._panel._populate_kb_chips()

        elif t == "conversation_attached":
            info = {
                "session_id": msg.get("session_id"),
                "title": msg.get("title"),
                "repo": msg.get("repo"),
                "chars": msg.get("chars", 0),
                "truncated": msg.get("truncated", False),
                "turn_count": msg.get("turn_count", 0),
            }
            self._panel.set_attached_conversation(json.dumps(info))

        elif t == "conversation_detached":
            self._panel.set_attached_conversation("null")

        elif t == "context_updated":
            repos = msg.get("repos", [])
            knowledge = msg.get("knowledge", [])
            added_repos = msg.get("added_repos", [])
            added_knowledge = [k.split("/")[-1] for k in msg.get("added_knowledge", [])]
            # Sync chips to reflect loaded state (never uncheck)
            self._panel.sync_selection(repos, knowledge)
            # Update the panel status label with cumulative loaded counts
            r_count = len(repos)
            k_count = len(knowledge)
            parts = []
            if r_count:
                parts.append(f"{r_count} repo{'s' if r_count != 1 else ''}")
            if k_count:
                parts.append(f"{k_count} folder{'s' if k_count != 1 else ''}")
            if parts:
                self._panel._status_label.setText("⚡ Auto-loaded: " + ", ".join(parts))
                self._panel._status_label.setStyleSheet(
                    "font-size: 9px; color: #4ec9b0; background: transparent;"
                )

        elif t == "transcript":
            text = msg.get("text", "") or ""
            role = (msg.get("role") or "self").strip().lower()
            if role not in ("self", "other"):
                role = "self"

            # Pick the right label + accumulator + accent color per role
            if role == "self":
                label = self._transcript_self_label
                tag = "\U0001f3a4"  # \ud83c\udfa4
                accent = "#3fb950"  # green
                muted = "#8b949e"
            else:
                label = self._transcript_other_label
                tag = "\U0001f50a"  # \ud83d\udd0a
                accent = "#79b8ff"  # blue
                muted = "#8b949e"

            if msg.get("interim"):
                accum = getattr(self.state, f"{role}_finals", "")
                combined = (accum + " " + text).strip()
                if len(combined) > 160:
                    combined = "\u2026" + combined[-157:]
                display = f"{tag} {combined}"
                label.setStyleSheet(
                    f"color: {muted}; font-size: 11px; padding: 4px 12px 2px; background: transparent;"
                )
            else:
                accum = getattr(self.state, f"{role}_finals", "")
                accum = (accum + " " + text).strip()
                if len(accum) > 300:
                    accum = "\u2026" + accum[-297:]
                setattr(self.state, f"{role}_finals", accum)
                display = f"{tag} {accum}"
                label.setStyleSheet(
                    f"color: {accent}; font-size: 11px; padding: 4px 12px 2px; background: transparent;"
                )
                # Fade the bright color back to muted after a beat
                _label_ref = label  # captured by lambda
                QTimer.singleShot(800, lambda lbl=_label_ref, mc=muted: lbl.setStyleSheet(
                    f"color: {mc}; font-size: 11px; padding: 4px 12px 2px; background: transparent;"
                ))
            label.setText(display)
            label.show()

        elif t == "start":
            if self.state.raw_md:
                self.state.history.insert(0, {"md": self.state.raw_md, "html": self.state.current_html})
                if len(self.state.history) > self.state.max_history:
                    self.state.history.pop()
            self.state.raw_md = ""
            self.state.current_html = ""
            self.state.nav_index = -1
            self._browser.setHtml("")
            self._transcript_self_label.hide()
            self._transcript_self_label.setText("")
            self._transcript_other_label.hide()
            self._transcript_other_label.setText("")
            self._cards_label.setText("")
            self._cards_label.hide()
            self.state.self_finals = ""
            self.state.other_finals = ""
            if msg.get("proactive"):
                question = msg.get("question", "")
                label = f"  ⚡ Auto · {question[:60]}{'…' if len(question) > 60 else ''}"
                self._thinking_label.setStyleSheet("color: #4ec9b0; font-size: 11px; padding: 8px 12px;")
            else:
                label = "  Thinking..."
                self._thinking_label.setStyleSheet("color: #8b949e; font-size: 12px; padding: 8px 12px;")
            self._thinking_label.setText(label)
            self._thinking_label.show()

        elif t == "chunk":
            self._thinking_label.hide()
            self._thinking_label.setStyleSheet("color: #8b949e; font-size: 12px; padding: 8px 12px;")
            self.state.raw_md += msg.get("text", "")
            # Debounce — coalesce rapid token arrivals into one render every
            # ~120 ms. Without this, every chunk runs Pygments + setHtml on
            # the entire growing buffer, which gets quadratically expensive
            # and visibly stutters during long responses.
            if not self._chunk_render_pending:
                self._chunk_render_pending = True
                QTimer.singleShot(120, self._render_chunk)

        elif t == "done":
            self._thinking_label.hide()
            full = msg.get("full_text", "")
            if full and not self.state.raw_md:
                self.state.raw_md = full
                self._browser.setHtml(_md_to_html(self.state.raw_md, self.state.font_size))
                self.state.current_html = self.state.raw_md
            elif self.state.raw_md:
                # Force a final render so the last few tokens don't sit in the
                # 120 ms debounce window unrendered.
                self._render_chunk()

        elif t == "brief":
            # Brief script renders in the answer browser so the user can read it aloud.
            # We deliberately DO NOT show source cards under the brief — the script
            # is meant to be spoken, and ticket-id boxes underneath just clutter it.
            script = msg.get("script", "") or ""
            if not script.strip():
                return
            self._thinking_label.hide()
            # Save any in-flight answer to history before overwriting
            if self.state.raw_md:
                self.state.history.insert(0, {
                    "md": self.state.raw_md, "html": self.state.current_html,
                })
                if len(self.state.history) > self.state.max_history:
                    self.state.history.pop()
            self.state.raw_md = script
            self.state.current_html = script
            self.state.nav_index = -1
            self._browser.setHtml(_md_to_html(script, self.state.font_size))
            self._cards_label.hide()

        elif t == "error":
            self._thinking_label.hide()
            err_html = f'<p style="color:#f85149">Warning: {msg.get("message", "Unknown error")}</p>'
            self._browser.setHtml(err_html)

        elif t == "transcriber_dead":
            # See copilot.py for the same handler. This makes the overlay's
            # transcript area show a one-shot warning so the user sees the
            # transcriber giving up instead of guessing why captions stopped.
            role = (msg.get("role") or "?").lower()
            reason = msg.get("reason") or "unknown"
            warning_html = (
                f'<p style="color:#f85149">⚠ Transcriber dead '
                f'({role}, reason={reason}). Health monitor will retry.</p>'
            )
            self._browser.setHtml(warning_html)

        elif t == "scroll":
            sb = self._browser.verticalScrollBar()
            delta = 150 if msg.get("direction") == "down" else -150
            sb.setValue(sb.value() + delta)

        elif t == "nav":
            total = 1 + len(self.state.history)
            if total < 2:
                return
            if msg.get("direction") == "prev":
                self.state.nav_index = min(self.state.nav_index + 1, len(self.state.history) - 1)
            else:
                self.state.nav_index = max(self.state.nav_index - 1, -1)
            md = self.state.raw_md if self.state.nav_index == -1 else self.state.history[self.state.nav_index].get("md", "")
            self._browser.setHtml(_md_to_html(md, self.state.font_size))
            label = "current" if self.state.nav_index == -1 else f"{self.state.nav_index + 1} of {len(self.state.history)} ago"
            self._thinking_label.setText(f"  {label}")
            self._thinking_label.show()
            QTimer.singleShot(1500, lambda: self._thinking_label.hide() if not self.state.thinking else None)

        elif t == "overlay_toggle":
            if msg.get("visible"):
                self.show()
            else:
                self.hide()

        elif t == "font_size":
            self.state.font_size += 1 if msg.get("direction") == "up" else -1
            self.state.font_size = max(8, min(32, self.state.font_size))
            font = self._browser.font()
            font.setPointSize(self.state.font_size)
            self._browser.setFont(font)
            md = self.state.raw_md if self.state.nav_index == -1 else self.state.history[self.state.nav_index].get("md", "")
            if md:
                self._browser.setHtml(_md_to_html(md, self.state.font_size))

    @Slot()
    def _on_connected(self) -> None:
        title = "Meeting Helper  \u00b7  connected"
        if self.state.meeting_name:
            title = f"Meeting Helper  \u00b7  {self.state.meeting_name}"
        self._title_label.setText(title)
        self._title_label.setStyleSheet("color: #3fb950; font-size: 11px;")

    @Slot()
    def _on_disconnected(self) -> None:
        self._title_label.setText("Meeting Helper  \u00b7  reconnecting...")
        self._title_label.setStyleSheet("color: #d29922; font-size: 11px;")

    # ---- Cleanup ----

    def closeEvent(self, event) -> None:
        if hasattr(self, "_ws_thread") and self._ws_thread.isRunning():
            self._ws_thread.quit()
            self._ws_thread.wait(2000)
        super().closeEvent(event)

    # ---- Drag to move ----

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.state.drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()

    def mouseMoveEvent(self, event):
        if self.state.drag_pos and event.buttons() & Qt.LeftButton:
            self.move(event.globalPosition().toPoint() - self.state.drag_pos)

    def mouseReleaseEvent(self, event):
        self.state.drag_pos = None


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    import os
    try:
        os.setsid()
    except OSError:
        pass

    port = int(sys.argv[1]) if len(sys.argv) > 1 else 7891

    app = QApplication(sys.argv)
    app.setApplicationName("Meeting Helper")

    # Hide from Dock on macOS
    try:
        from AppKit import NSApplication, NSApplicationActivationPolicyAccessory
        NSApplication.sharedApplication().setActivationPolicy_(
            NSApplicationActivationPolicyAccessory
        )
    except Exception:
        pass

    window = OverlayWindow(port)
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
