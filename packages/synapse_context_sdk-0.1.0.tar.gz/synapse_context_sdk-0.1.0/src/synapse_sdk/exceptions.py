class SynapseError(Exception):
    """Base exception for all Synapse errors."""


class SecretDetectedError(SynapseError):
    """Raised when a secret is detected in a file during scanning."""

    def __init__(self, file_path: str, secret_type: str) -> None:
        self.file_path = file_path
        self.secret_type = secret_type
        super().__init__(f"Secret '{secret_type}' detected in {file_path}. File rejected.")


class AuthorizationError(SynapseError):
    """Raised when a user is not authorized to access a resource."""


class QdrantError(SynapseError):
    """Raised when Qdrant operations fail."""


class ParserError(SynapseError):
    """Raised when Tree-sitter parsing fails."""
