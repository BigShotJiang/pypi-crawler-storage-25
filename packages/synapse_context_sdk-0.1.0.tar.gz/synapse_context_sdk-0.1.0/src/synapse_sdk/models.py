from __future__ import annotations

import uuid
from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field


class Chunk(BaseModel):
    chunk_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    org_id: str
    repo: str
    branch: str
    namespace: str  # "global", "wip", or "feature/{branch_name}"
    file_path: str
    language: str
    chunk_type: Literal["function", "class", "import", "module"]
    symbol_name: str | None = None
    start_line: int
    end_line: int
    text: str
    commit_sha: str | None = None
    indexed_at: datetime = Field(default_factory=datetime.utcnow)
    ttl_expires_at: datetime | None = None
    allowed_users: list[str] = Field(default_factory=list)
    parse_error: bool = False


class SearchRequest(BaseModel):
    query: str
    repo: str | None = None
    branch: str | None = None
    language: str | None = None
    chunk_type: str | None = None
    limit: int = Field(default=10, ge=1, le=50)


class SearchResult(BaseModel):
    chunk_id: str
    file_path: str
    symbol: str | None
    lines: str
    repo: str
    branch: str
    tier: str  # "wip", "global", or "feature/{branch_name}"
    relevance_score: float
    text: str


class SearchResponse(BaseModel):
    results: list[SearchResult]
    context_used_tokens: int


class TokenPayload(BaseModel):
    user_id: str
    github_login: str
    org_id: str
    github_installation_id: int
    exp: int


class SecretScanResult(BaseModel):
    is_rejected: bool
    secret_type: str | None = None
    file_path: str
    details: str | None = None


class WIPFile(BaseModel):
    file_path: str
    chunks: list[Chunk]
    embeddings: list[list[float]]


class WIPSyncRequest(BaseModel):
    files: list[WIPFile]
    session_id: str


class WIPSyncResponse(BaseModel):
    synced: int
    files: list[str]


class IngestRequest(BaseModel):
    """Payload passed from the webhook to the IngestFileBatch Temporal workflow."""
    org_id: str
    repo: str
    branch: str
    file_paths: list[str]
    commit_sha: str
    installation_id: int
