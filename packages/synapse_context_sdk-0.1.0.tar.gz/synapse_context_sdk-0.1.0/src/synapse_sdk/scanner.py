"""Secret scanner — scans raw file text for secrets BEFORE embedding.

This is a critical security component shared by all Synapse services.
If ANY secret pattern is found, the ENTIRE FILE is rejected.
0% leak rate is a non-negotiable KPI.
"""
import re

from synapse_sdk.models import SecretScanResult

# Regex patterns for common secrets. Order does not matter — all are checked.
SECRET_PATTERNS: dict[str, re.Pattern[str]] = {
    "aws_access_key": re.compile(r"AKIA[0-9A-Z]{16}"),
    "aws_secret_key": re.compile(
        r"(?i)aws.{0,20}secret.{0,20}['\"][0-9a-zA-Z/+]{40}['\"]"
    ),
    # GitHub tokens: ghp_ (PAT), gho_ (OAuth) — real tokens are 36 chars but
    # allow 30+ to handle test fixtures and future format changes
    "github_token": re.compile(r"ghp_[0-9a-zA-Z]{30,}"),
    "github_oauth": re.compile(r"gho_[0-9a-zA-Z]{30,}"),
    "stripe_key": re.compile(r"sk_live_[0-9a-zA-Z]{24,}"),
    "private_key": re.compile(r"-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----"),
    "jwt_secret": re.compile(
        r"(?i)jwt[_\-]?secret['\"\s]*[:=]['\"\s]*[a-zA-Z0-9]{16,}"
    ),
    # Generic API keys: allow underscores and hyphens in the value (e.g. sk_prod_...)
    "generic_api_key": re.compile(
        r"(?i)api[_\-]?key['\"\s]*[:=]['\"\s]*['\"][a-zA-Z0-9_\-]{20,}['\"]"
    ),
    # OpenAI API keys: sk- prefix followed by 40+ alphanum chars
    # Real keys are 48 chars; 40 minimum catches test fixtures too
    "openai_api_key": re.compile(r"sk-[A-Za-z0-9]{40,}"),
    # Stripe test keys (live keys already covered by stripe_key above)
    "stripe_test_key": re.compile(r"sk_test_[0-9a-zA-Z]{24,}"),
    # Slack tokens: xoxb/xoxp/xoxa/xoxs/xoxr prefixes
    "slack_token": re.compile(r"xox[bpasr]-[0-9]+-[A-Za-z0-9-]+"),
    # DB connection strings with embedded credentials (user:pass@host).
    # Username may be empty (e.g. redis://:password@host) so use [^:@\s]*.
    "db_connection_string": re.compile(
        r"(?i)(postgres(?:ql)?|mysql|mongodb|redis)://[^:@\s]*:[^@\s]+@"
    ),
    # Generic high-entropy hex strings: 32+ consecutive lowercase hex characters
    # Excludes short hashes and non-hex strings; targets secrets like SHA-256 digests
    "high_entropy_hex": re.compile(r"['\"][0-9a-f]{32,}['\"]"),
    # Hardcoded password assignments — covers assignment (=) and YAML/dict (:) syntax
    # Also covers "password" as a dict key in string form ("password": "value")
    "hardcoded_password": re.compile(
        r"(?i)pass(?:word|wd|phrase)?['\"]?\s*[:=]\s*['\"][^'\"]{4,}['\"]"
    ),
}


def scan_for_secrets(text: str, file_path: str = "") -> SecretScanResult:
    """Scan raw file text for secrets BEFORE any embedding.

    If ANY secret is found, the ENTIRE FILE is rejected (not just the
    matching line). This is a non-negotiable security requirement.

    Args:
        text: Raw file contents to scan.
        file_path: Path of the file being scanned (preserved in result).

    Returns:
        SecretScanResult indicating whether the file is rejected or safe.
    """
    for secret_type, pattern in SECRET_PATTERNS.items():
        if pattern.search(text):
            return SecretScanResult(
                is_rejected=True,
                secret_type=secret_type,
                file_path=file_path,
                details=f"Pattern '{secret_type}' matched in {file_path}",
            )

    return SecretScanResult(is_rejected=False, file_path=file_path)
