"""Synapse SDK — shared data models and API client."""

__version__ = "0.1.0"
