# synapse-sdk

Shared Python building blocks for [Synapse](https://synapse.abhinavaditya.com) —
a Universal Memory Layer for AI coding tools.

This package is the dependency surface that the Synapse API server, the
Temporal workers, and the developer CLI all share:

- **`synapse_sdk.models`** — pydantic models for `Chunk`, `SearchRequest`,
  `SearchResult`, `TokenPayload`, `SecretScanResult`.
- **`synapse_sdk.scanner`** — pre-flight secret scanner. Files containing
  AWS keys, GitHub tokens, private keys, etc. are rejected wholesale before
  embedding. 0% leak rate is a non-negotiable Synapse KPI.
- **`synapse_sdk.exceptions`** — shared exception types.

## Install

```bash
pip install synapse-context-sdk
```

The Python import name stays `synapse_sdk`:

```python
from synapse_sdk.scanner import scan_for_secrets
from synapse_sdk.models import SearchRequest
```

## Usage — secret scanner

```python
from synapse_sdk.scanner import scan_for_secrets

result = scan_for_secrets(file_text, file_path="src/auth.py")
if result.is_rejected:
    print(f"Skipped: secret of type {result.secret_type}")
```

## Usage — models

```python
from synapse_sdk.models import SearchRequest

req = SearchRequest(query="how does JWT auth work", limit=10)
```

See [the main repo](https://github.com/abhinav162/synapse) for the full
service architecture.
