"""TDD tests for synapse-sdk Pydantic models.

Written FIRST per TDD discipline. These validate model construction,
default values, field constraints, and rejection of invalid data.
"""
import uuid

import pytest
from pydantic import ValidationError

from synapse_sdk.models import (
    Chunk,
    SearchRequest,
    SearchResponse,
    SearchResult,
    SecretScanResult,
    TokenPayload,
    WIPFile,
    WIPSyncRequest,
    WIPSyncResponse,
)


class TestChunkModel:
    """Verify Chunk model defaults, auto-generation, and validation."""

    def test_chunk_creates_with_required_fields_only(self) -> None:
        chunk = Chunk(
            org_id="org-1",
            repo="acme/backend",
            branch="main",
            namespace="global",
            file_path="src/main.py",
            language="python",
            chunk_type="function",
            start_line=1,
            end_line=10,
            text="def hello(): pass",
        )
        assert chunk.org_id == "org-1"
        assert chunk.repo == "acme/backend"
        assert chunk.branch == "main"
        assert chunk.namespace == "global"
        assert chunk.file_path == "src/main.py"
        assert chunk.language == "python"
        assert chunk.chunk_type == "function"
        assert chunk.start_line == 1
        assert chunk.end_line == 10
        assert chunk.text == "def hello(): pass"

    def test_chunk_id_auto_generated_as_uuid(self) -> None:
        chunk = Chunk(
            org_id="org-1",
            repo="r",
            branch="main",
            namespace="global",
            file_path="f.py",
            language="python",
            chunk_type="function",
            start_line=1,
            end_line=2,
            text="x",
        )
        # Should be a valid UUID string
        parsed = uuid.UUID(chunk.chunk_id)
        assert str(parsed) == chunk.chunk_id

    def test_chunk_id_is_unique_per_instance(self) -> None:
        kwargs = dict(
            org_id="org-1",
            repo="r",
            branch="main",
            namespace="global",
            file_path="f.py",
            language="python",
            chunk_type="function",
            start_line=1,
            end_line=2,
            text="x",
        )
        chunk_a = Chunk(**kwargs)
        chunk_b = Chunk(**kwargs)
        assert chunk_a.chunk_id != chunk_b.chunk_id

    def test_chunk_accepts_all_namespace_patterns(self) -> None:
        """Namespace is a free-form str: global, wip, or feature/{branch}."""
        for ns in ("global", "wip", "feature/hir-63/auth", "feature/release/v2"):
            chunk = Chunk(
                org_id="org-1",
                repo="r",
                branch="main",
                namespace=ns,
                file_path="f.py",
                language="python",
                chunk_type="function",
                start_line=1,
                end_line=2,
                text="x",
            )
            assert chunk.namespace == ns

    def test_chunk_rejects_invalid_chunk_type(self) -> None:
        with pytest.raises(ValidationError) as exc_info:
            Chunk(
                org_id="org-1",
                repo="r",
                branch="main",
                namespace="global",
                file_path="f.py",
                language="python",
                chunk_type="snippet",  # type: ignore[arg-type]
                start_line=1,
                end_line=2,
                text="x",
            )
        assert "chunk_type" in str(exc_info.value)

    def test_chunk_optional_fields_default_to_none_or_empty(self) -> None:
        chunk = Chunk(
            org_id="org-1",
            repo="r",
            branch="main",
            namespace="global",
            file_path="f.py",
            language="python",
            chunk_type="function",
            start_line=1,
            end_line=2,
            text="x",
        )
        assert chunk.symbol_name is None
        assert chunk.commit_sha is None
        assert chunk.ttl_expires_at is None
        assert chunk.allowed_users == []
        assert chunk.parse_error is False

    def test_chunk_indexed_at_auto_set(self) -> None:
        from datetime import datetime

        chunk = Chunk(
            org_id="org-1",
            repo="r",
            branch="main",
            namespace="global",
            file_path="f.py",
            language="python",
            chunk_type="function",
            start_line=1,
            end_line=2,
            text="x",
        )
        assert isinstance(chunk.indexed_at, datetime)


class TestSearchRequestModel:
    """Verify SearchRequest field constraints."""

    def test_search_request_with_defaults(self) -> None:
        req = SearchRequest(query="find auth handler")
        assert req.query == "find auth handler"
        assert req.repo is None
        assert req.branch is None
        assert req.language is None
        assert req.chunk_type is None
        assert req.limit == 10

    def test_search_request_limit_minimum_is_1(self) -> None:
        with pytest.raises(ValidationError) as exc_info:
            SearchRequest(query="test", limit=0)
        assert "limit" in str(exc_info.value)

    def test_search_request_limit_maximum_is_50(self) -> None:
        with pytest.raises(ValidationError) as exc_info:
            SearchRequest(query="test", limit=51)
        assert "limit" in str(exc_info.value)

    def test_search_request_limit_at_boundaries(self) -> None:
        req_min = SearchRequest(query="test", limit=1)
        assert req_min.limit == 1
        req_max = SearchRequest(query="test", limit=50)
        assert req_max.limit == 50

    def test_search_request_with_all_filters(self) -> None:
        req = SearchRequest(
            query="auth",
            repo="acme/api",
            language="python",
            chunk_type="function",
            limit=25,
        )
        assert req.repo == "acme/api"
        assert req.language == "python"
        assert req.chunk_type == "function"
        assert req.limit == 25


class TestSearchResultModel:
    """Verify SearchResult and SearchResponse."""

    def test_search_result_stores_all_fields(self) -> None:
        result = SearchResult(
            chunk_id="abc-123",
            file_path="src/auth.py",
            symbol="validate_token",
            lines="10-25",
            repo="acme/api",
            branch="main",
            tier="global",
            relevance_score=0.95,
            text="def validate_token(): ...",
        )
        assert result.chunk_id == "abc-123"
        assert result.relevance_score == 0.95
        assert result.tier == "global"

    def test_search_result_accepts_feature_branch_tier(self) -> None:
        """Tier is a free-form str to support feature/{branch} namespaces."""
        result = SearchResult(
            chunk_id="abc",
            file_path="f.py",
            symbol=None,
            lines="1-2",
            repo="r",
            branch="dev",
            tier="feature/dev",
            relevance_score=0.5,
            text="x",
        )
        assert result.tier == "feature/dev"

    def test_search_response_wraps_results(self) -> None:
        resp = SearchResponse(results=[], context_used_tokens=0)
        assert resp.results == []
        assert resp.context_used_tokens == 0


class TestSecretScanResultModel:
    """Verify SecretScanResult representation."""

    def test_rejected_scan_result(self) -> None:
        result = SecretScanResult(
            is_rejected=True,
            secret_type="aws_access_key",
            file_path="config.py",
            details="Found AWS key",
        )
        assert result.is_rejected is True
        assert result.secret_type == "aws_access_key"
        assert result.file_path == "config.py"

    def test_safe_scan_result(self) -> None:
        result = SecretScanResult(
            is_rejected=False,
            file_path="utils.py",
        )
        assert result.is_rejected is False
        assert result.secret_type is None
        assert result.details is None


class TestTokenPayloadModel:
    """Verify TokenPayload stores all required fields."""

    def test_token_payload_stores_all_fields(self) -> None:
        payload = TokenPayload(
            user_id="user-42",
            github_login="octocat",
            org_id="org-1",
            github_installation_id=12345,
            exp=1700000000,
        )
        assert payload.user_id == "user-42"
        assert payload.github_login == "octocat"
        assert payload.org_id == "org-1"
        assert payload.github_installation_id == 12345
        assert payload.exp == 1700000000

    def test_token_payload_rejects_missing_fields(self) -> None:
        with pytest.raises(ValidationError):
            TokenPayload(  # type: ignore[call-arg]
                user_id="user-42",
                # missing github_login, org_id, etc.
            )


class TestWIPModels:
    """Verify WIP sync request/response models."""

    def test_wip_sync_request_with_files(self) -> None:
        chunk = Chunk(
            org_id="org-1",
            repo="r",
            branch="wip/dev",
            namespace="wip",
            file_path="f.py",
            language="python",
            chunk_type="function",
            start_line=1,
            end_line=5,
            text="def foo(): pass",
        )
        wip_file = WIPFile(
            file_path="f.py",
            chunks=[chunk],
            embeddings=[[0.1, 0.2, 0.3]],
        )
        req = WIPSyncRequest(files=[wip_file], session_id="sess-1")
        assert len(req.files) == 1
        assert req.session_id == "sess-1"

    def test_wip_sync_response(self) -> None:
        resp = WIPSyncResponse(synced=3, files=["a.py", "b.py", "c.py"])
        assert resp.synced == 3
        assert len(resp.files) == 3
