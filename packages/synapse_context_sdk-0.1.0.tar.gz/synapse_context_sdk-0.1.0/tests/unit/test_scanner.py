"""Unit tests for the secret scanner.

Covers every pattern in SECRET_PATTERNS. The scanner must:
  - Reject any file containing a recognised secret pattern.
  - Never reject clean code (zero false positives on the reference set).
"""
from __future__ import annotations

from synapse_sdk.scanner import scan_for_secrets


class TestAwsPatterns:
    def test_detects_aws_access_key(self) -> None:
        result = scan_for_secrets('AWS_KEY = "AKIAIOSFODNN7EXAMPLE"')
        assert result.is_rejected is True
        assert result.secret_type == "aws_access_key"

    def test_detects_aws_access_key_in_code(self) -> None:
        result = scan_for_secrets(
            'client = boto3.client(aws_access_key_id="AKIAIOSFODNN7EXAMPLE")'
        )
        assert result.is_rejected is True

    def test_clean_file_passes(self) -> None:
        result = scan_for_secrets("def add(a, b):\n    return a + b")
        assert result.is_rejected is False

    def test_rejects_entire_file_not_just_matching_line(self) -> None:
        """When a secret appears on one line, the whole file is rejected."""
        code = "# config.py\nhost = 'localhost'\nAWS_KEY = 'AKIAIOSFODNN7EXAMPLE'\nport = 5432"
        result = scan_for_secrets(code)
        assert result.is_rejected is True


class TestGithubTokenPatterns:
    def test_detects_github_pat(self) -> None:
        result = scan_for_secrets('GITHUB_TOKEN = "ghp_aBcDeFgHiJkLmNoPqRsTuVwXyZ012345"')
        assert result.is_rejected is True
        assert result.secret_type == "github_token"

    def test_detects_github_oauth_token(self) -> None:
        result = scan_for_secrets('token = "gho_aBcDeFgHiJkLmNoPqRsTuVwXyZ012345"')
        assert result.is_rejected is True
        assert result.secret_type == "github_oauth"

    def test_short_token_not_rejected(self) -> None:
        """Token-like strings under 30 chars should not trigger false positives."""
        result = scan_for_secrets('prefix = "ghp_short"')
        assert result.is_rejected is False


class TestPrivateKeyPatterns:
    def test_detects_rsa_private_key(self) -> None:
        result = scan_for_secrets("-----BEGIN RSA PRIVATE KEY-----\nMIIE\n-----END RSA PRIVATE KEY-----")
        assert result.is_rejected is True
        assert result.secret_type == "private_key"

    def test_detects_ec_private_key(self) -> None:
        result = scan_for_secrets("-----BEGIN EC PRIVATE KEY-----\nMHQ\n-----END EC PRIVATE KEY-----")
        assert result.is_rejected is True

    def test_detects_generic_private_key(self) -> None:
        result = scan_for_secrets("-----BEGIN PRIVATE KEY-----\nMIIE\n-----END PRIVATE KEY-----")
        assert result.is_rejected is True

    def test_detects_openssh_private_key(self) -> None:
        result = scan_for_secrets(
            "-----BEGIN OPENSSH PRIVATE KEY-----\nb3BlbnNzaC1rZ\n-----END OPENSSH PRIVATE KEY-----"
        )
        assert result.is_rejected is True


class TestJwtSecretPattern:
    def test_detects_jwt_secret_assignment(self) -> None:
        result = scan_for_secrets('jwt_secret = "thisisaverylongsecretkeyabcdef1234"')
        assert result.is_rejected is True
        assert result.secret_type == "jwt_secret"

    def test_detects_jwt_secret_with_dash(self) -> None:
        result = scan_for_secrets('JWT-SECRET: "abcdefghijklmnopqrstuvwx1234"')
        assert result.is_rejected is True


class TestOpenAIKeyPattern:
    def test_detects_openai_api_key(self) -> None:
        # Variable name contains "api_key" so generic_api_key may fire first —
        # either pattern correctly rejects the file.
        result = scan_for_secrets(
            'OPENAI_API_KEY = "sk-aBcDeFgHiJkLmNoPqRsTuVwXyZaBcDeFgHiJkLmNoPqRs"'
        )
        assert result.is_rejected is True

    def test_detects_openai_key_by_prefix_alone(self) -> None:
        """sk- prefix detected even without api_key in the variable name."""
        result = scan_for_secrets(
            '// openai: sk-aBcDeFgHiJkLmNoPqRsTuVwXyZaBcDeFgHiJkLmNoPqRs'
        )
        assert result.is_rejected is True
        assert result.secret_type == "openai_api_key"

    def test_detects_openai_key_in_function_call(self) -> None:
        result = scan_for_secrets(
            'api = OpenAI(api_key="sk-aBcDeFgHiJkLmNoPqRsTuVwXyZaBcDeFgHiJkLmNoPqRs")'
        )
        assert result.is_rejected is True

    def test_short_sk_prefix_not_rejected(self) -> None:
        """sk- with fewer than 40 chars must not trigger."""
        result = scan_for_secrets('prefix = "sk-short"')
        assert result.is_rejected is False


class TestStripeKeyPatterns:
    def test_detects_stripe_live_key(self) -> None:
        result = scan_for_secrets('STRIPE_KEY = "sk_live_aBcDeFgHiJkLmNoPqRsTuVwXy"')
        assert result.is_rejected is True
        assert result.secret_type == "stripe_key"

    def test_detects_stripe_test_key(self) -> None:
        result = scan_for_secrets('stripe_key = "sk_test_aBcDeFgHiJkLmNoPqRsTuVwXy"')
        assert result.is_rejected is True
        assert result.secret_type == "stripe_test_key"


class TestSlackTokenPattern:
    def test_detects_xoxb_token(self) -> None:
        result = scan_for_secrets(
            'SLACK_TOKEN = "xoxb-1234-5678-aBcDeFgHiJkLmNoPqRsTuVwXyZ"'
        )
        assert result.is_rejected is True
        assert result.secret_type == "slack_token"

    def test_detects_xoxp_token(self) -> None:
        result = scan_for_secrets(
            'config.slack_token = "xoxp-1234-5678-aBcDeFgHiJkLmNoPqRsTuVwXyZ"'
        )
        assert result.is_rejected is True

    def test_detects_xoxs_token(self) -> None:
        result = scan_for_secrets(
            "token = 'xoxs-1234-5678-aBcDeFgHiJkLmNoPqRsTuVwXyZ'"
        )
        assert result.is_rejected is True


class TestDbConnectionStringPattern:
    def test_detects_postgresql_with_credentials(self) -> None:
        result = scan_for_secrets(
            'DATABASE_URL = "postgresql://admin:p@ssw0rd123@prod.db.example.com:5432/app"'
        )
        assert result.is_rejected is True
        assert result.secret_type == "db_connection_string"

    def test_detects_mysql_url(self) -> None:
        result = scan_for_secrets('CONN = "mysql://user:hunter2@localhost/db"')
        assert result.is_rejected is True

    def test_detects_mongodb_url(self) -> None:
        result = scan_for_secrets(
            'mongo_uri = "mongodb://admin:sup3rSecret@cluster.mongodb.net/db"'
        )
        assert result.is_rejected is True

    def test_detects_redis_url_empty_username(self) -> None:
        """Redis URLs often have no username: redis://:password@host."""
        result = scan_for_secrets('redis_url = "redis://:authPassword123@redis.prod:6379"')
        assert result.is_rejected is True

    def test_localhost_without_credentials_not_rejected(self) -> None:
        """Connection strings without a password must not be rejected."""
        result = scan_for_secrets(
            "config = {'host': 'localhost', 'port': 5432, 'dbname': 'test'}"
        )
        assert result.is_rejected is False


class TestHighEntropyHexPattern:
    def test_detects_32_char_hex_in_quotes(self) -> None:
        result = scan_for_secrets('app_secret: "8c7dd922ad47494fc02c388e12c00eac"')
        assert result.is_rejected is True
        assert result.secret_type == "high_entropy_hex"

    def test_detects_64_char_hex_in_quotes(self) -> None:
        result = scan_for_secrets(
            'SECRET_KEY = "a9f3b2c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1"'
        )
        assert result.is_rejected is True

    def test_uppercase_hex_not_caught(self) -> None:
        """Pattern targets lowercase hex only — uppercase (like git SHAs in comments) are excluded."""
        result = scan_for_secrets('# commit: DEADBEEF1234567890ABCDEF1234567890ABCDEF')
        assert result.is_rejected is False

    def test_short_hex_in_quotes_not_rejected(self) -> None:
        """Hex strings under 32 chars (e.g. short IDs) must not trigger."""
        result = scan_for_secrets('color = "#ff5733"')
        assert result.is_rejected is False


class TestHardcodedPasswordPattern:
    def test_detects_password_assignment(self) -> None:
        result = scan_for_secrets('password = "Str0ng!Password123"')
        assert result.is_rejected is True
        assert result.secret_type == "hardcoded_password"

    def test_detects_passwd_assignment(self) -> None:
        result = scan_for_secrets('passwd = "p@ssw0rd"')
        assert result.is_rejected is True

    def test_detects_password_yaml_style(self) -> None:
        result = scan_for_secrets('admin_password: "admin123"')
        assert result.is_rejected is True

    def test_detects_password_dict_key(self) -> None:
        result = scan_for_secrets('credentials = {"password": "S3cr3t!Pass"}')
        assert result.is_rejected is True

    def test_env_var_lookup_not_rejected(self) -> None:
        """Loading from environment must not be a false positive."""
        result = scan_for_secrets("secret_key = os.getenv('SECRET_KEY')  # loaded from env")
        assert result.is_rejected is False

    def test_placeholder_not_rejected(self) -> None:
        result = scan_for_secrets("API_KEY_PLACEHOLDER = 'your-key-here'")
        assert result.is_rejected is False


class TestGenericApiKeyPattern:
    def test_detects_api_key_with_long_value(self) -> None:
        result = scan_for_secrets('api_key = "abcdefghijklmnopqrstuvwxyz1234567890abcd"')
        assert result.is_rejected is True
        assert result.secret_type == "generic_api_key"

    def test_short_api_key_value_not_rejected(self) -> None:
        """api_key values under 20 chars must not trigger."""
        result = scan_for_secrets("API_KEY_PLACEHOLDER = 'your-key-here'")
        assert result.is_rejected is False


class TestFileLevelMetadata:
    def test_result_includes_file_path(self) -> None:
        result = scan_for_secrets('AWS_KEY = "AKIAIOSFODNN7EXAMPLE"', file_path="src/config.py")
        assert result.file_path == "src/config.py"
        assert result.is_rejected is True

    def test_safe_result_includes_file_path(self) -> None:
        result = scan_for_secrets("x = 1", file_path="src/math.py")
        assert result.file_path == "src/math.py"
        assert result.is_rejected is False
