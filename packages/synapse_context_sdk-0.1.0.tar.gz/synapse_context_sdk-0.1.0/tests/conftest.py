"""Shared fixtures for synapse-sdk tests."""
