# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Faraway Realms is a Python-based roguelike RPG using the [tcod](https://python-tcod.readthedocs.io/) library. Real-time tick-based gameplay (not turn-based), open overworld exploration, melee combat, and a working client/server multiplayer architecture.

## Development Commands

```bash
# Install dependencies
uv sync --extra dev

# Run tests
uv run pytest

# Run a single test
uv run pytest tests/path/to/test_file.py::test_name

# Type checking
uv run mypy faraway_realms

# Linting
uv run ruff check .
uv run ruff format .
uv run pylint faraway_realms

# Pre-commit
pre-commit install
pre-commit run --all-files

# Run the game (single-player — always uses an embedded server)
uv run python -m faraway_realms

# Dedicated server (headless) + separate client window
uv run python -m faraway_realms --serve 0.0.0.0:9999 --headless &
uv run python -m faraway_realms --connect localhost:9999

# Syntax checking — use uv run python, NOT bare python3
# (bare python3 is 3.13; project requires 3.14 for PEP 758 except syntax)
uv run python -m py_compile faraway_realms/net/client.py
```

## Linting Rules (Cannot Be Changed)

Ruff is configured with strict rules (A, B, C, D, E, F, I, W, S). Key constraints:
- Max line length: 88 characters
- Max McCabe complexity: 4
- Docstring convention: numpy style
- Ruff excludes: `docs/`, `__init__.py`, `tests/`
- Pylint minimum score: 8.0

**If you need a `# noqa` suppression, notify loudly and always include the reason as a comment.**

## Architecture

### Command / Event Pipeline

The core data flow is: **UI input → Command → Game.tick() → System → Event → System**.

1. UI key bindings and chat input produce `Command` objects via `CommandParser`.
2. NPC behaviours also produce `Command` objects each tick via `NpcIntentSystem.gather()`.
3. `Game.tick()` drains the command queue, dispatching each to a `_dispatch_*` shim.
4. Shims resolve actor/target IDs and delegate to the appropriate `System`.
5. Systems return `Event` objects (e.g. CONTACT, DEATH); `Game` emits them to the event queue.
6. After all commands are processed, `Game._drain_events()` dispatches events to their handlers.
7. Event handlers may enqueue further commands (e.g. CONTACT → ATTACK) — bounded by `_MAX_EVENT_DEPTH = 10`.

### Systems (`faraway_realms/systems/`)

Each system holds only shared references (same dict/list objects as `Game`) and communicates back via return values — no `Game` reference, no side-channel mutation.

| System | Input | Output | Owns |
|---|---|---|---|
| `NpcIntentSystem` | `abs_tick` | `list[Command]` | — |
| `MovementSystem` | `actor_id, direction, abs_tick` | `list[Event]` | — |
| `CombatSystem` | `attacker_id, target_id, abs_tick` | `CombatResult` | `_last_attack_tick` dict |
| `TargetingSystem` | `entity_id, new_target_id` | `None` (mutates entity) | — |
| `ContactResolutionSystem` | `Event(CONTACT)` | `list[Command]` | — |
| `DeathSystem` | `Event(DEATH)` | `None` (mutates map/entities) | — |

`DeathSystem` uses `npcs[:] = [...]` (slice assignment) so the `NpcIntentSystem` sees the updated list on the same object reference.

### Entities

- `GameEntity` (abstract) — base for everything on the map. Key fields: `entity_id`, `char`, `fg_color`, `faction`, `stats`, `target_id`, `death_stat`, `attack_every`, `components`.
- `CharacterEntity(GameEntity)` — player characters and named NPCs; has a `name`.
- `NonPlayerEntity(GameEntity)` — autonomous entities; has `move_every` and a `Behaviour`.
- `Player` — account metadata wrapper that holds a reference to a `CharacterEntity`. Has `is_game_master: bool` for GM command access.

### Stats (`faraway_realms/stats.py`, `faraway_realms/stat_definitions.py`)

- `Stat(base, bonus, abbreviation, bar_filled, bar_empty)` — flat attribute; effective `value = base + bonus`.
- `Pool(Stat)` — depletable resource; `current` starts at `value` (max), modified via `pool.modify(delta)`. `is_empty` triggers death.
- `abbreviation`, `bar_filled`, `bar_empty` travel with the instance so the UI can read them directly.

**`StatDefinition`** — frozen dataclass in `stat_definitions.py` that stores the display metadata (kind, abbreviation, bar colours, regen) for a named stat key. `STAT_DEF_REGISTRY: dict[str, StatDefinition]` is populated at startup from `faraway_realms/data/stats/definitions.yaml`.

`StatDefinition.make(base) -> Stat | Pool` constructs the right type with correct metadata. Entities declare stat values as plain ints (`stats: {health: 30, strength: 5}`) and `to_npc()` resolves each key via the registry. Adding a new stat requires only a new entry in `definitions.yaml` — no Python changes.

### Behaviours (`faraway_realms/behaviour.py`)

`Behaviour` is an ABC with two methods: `act(npc_id, ctx) -> list[Command]` and `current_move_every(base) -> int`.

`StateMachineBehaviour(initial_state)` is the concrete implementation. It delegates to a `BehaviourState` object each tick:

```
transition() returns next_state?
  yes → call next_state.on_enter(); switch state; return enter_cmds (e.g. PRIME_COOLDOWN)
  no  → call state.act(); return its commands
```

**Built-in states:**

| State | Movement | Transitions |
|---|---|---|
| `WanderState(sight_range, speed_factor=2.0)` | Random cardinal; 2× slower than base `move_every` | → `ChaseState` when hostile enters FOV |
| `ChaseState(sight_range, target_id)` | A* toward target; emits ATTACK when adjacent | → `WanderState` when target leaves LoS |

`ChaseState.on_enter()` emits a `PRIME_COOLDOWN` command so the NPC's attack cooldown starts as soon as it spots a target — preventing fully-charged arrival.

`current_move_every(base)` is pulled from the active state each tick by `NpcIntentSystem` — no push needed.

`BehaviourContext` is a frozen snapshot passed each tick: map reference, all positions, target IDs, occupied tiles, `abs_tick`.

**Adding a new state** — subclass `BehaviourState`, implement `act()`, `transition()`, and optionally `on_enter()` / `current_move_every()`. Wire it into an existing state's `transition()` method.

### Combat

- `CombatSystem` gates attacks by cooldown (`attack_every` ticks, reduced by optional `"attack_speed"` stat).
- Damage formula: `max(1, round((strength − armor) × type_multiplier))`. On a crit the result is doubled.
- `armor` stat on the target reduces raw damage. `damage_type` (attacker) and `armor_type` (target) are plain string fields on `GameEntity` — not Stats — that look up a float multiplier in `faraway_realms/damage_types.py`. The `EFFECTIVENESS` dict is populated at startup from `data/damage_types/core.yaml` (top-level key `damage_effectiveness:`; nested `damage_type → armor_type → multiplier`). Unknown pairs default to `1.0` and emit a one-time `logging.WARNING` per pair.
- `crit_chance` stat (0–100): each attack rolls `random.randint(1, 100)`; ≤ `crit_chance` is a crit. `CombatResult.crit` propagates to `Game`, which increments `_crit_dealt_seq` and logs `"Critical! ..."`.
- **Stagger**: WoW-style pushback. `_apply_stagger` checks whether the target is mid-cooldown (`elapsed < effective_attack_every`). If yes, it advances `_last_attack_tick[target_id]` by `max(1, strength // 2)` ticks (capped at `abs_tick`), extending the remaining wait. If the target is already fully ready, no stagger applies — a balanced entity can't be flinched. Stagger is encoded directly into `_last_attack_tick`; `effective_last_attack(entity_id)` is a simple getter.
- **Cooldown bar** starts empty (`cooldown_fraction = 0.0`) for any entity not yet in `_last_attack_tick`. Attack behaviour is unchanged (untracked entities are still considered ready); only the display differs.
- Applies to target's `death_stat` Pool (default `"health"`); emits DEATH event when depleted.
- **PRIME_COOLDOWN command**: emitted by `ChaseState.on_enter()` (and by `_dispatch_target` when a player acquires a new target). Processed by `CombatSystem.prime(entity_id, abs_tick)`, which sets `_last_attack_tick[entity_id] = abs_tick`. This starts the cooldown clock without an actual attack — initiative is determined by *when* the entity committed to a target, not by target bookkeeping at contact time.
- **Targeting primes cooldown**: issuing a TARGET command to a new (different, non-None) target immediately calls `prime()`. This rewards pre-committing to a target before engaging and penalises mid-fight target switches.
- `ContactResolutionSystem` queues an attack for the mover and auto-sets `target_id` on **both** parties if not already set. There is no initiative check — timing is governed entirely by the cooldown system. Opportunity attacks: when an entity moves away from an adjacent hostile that has it as `target_id`, CONTACT fires with the hostile as source before the move completes.

### Ability System (`faraway_realms/abilities.py`, `faraway_realms/content_parsers/abilities.py`)

Abilities are **data-driven**: defined in YAML files, loaded at startup, stored in `ABILITY_REGISTRY: dict[str, Ability]`.

**`Ability`** — frozen dataclass: `name`, `cooldown`, `cast_time`, `range_tiles`, `gcd`, `channel_interval`, `effects`, `description`, `abbreviation`, `resource_cost`.

**Effect types** (all frozen dataclasses in `abilities.py`):

| Class | Fields |
|---|---|
| `DamageEffect` | `base`, `damage_type` |
| `KnockbackEffect` | `distance` |
| `BackstepEffect` | `distance` |
| `ApplyStatusEffect` | `status_name`, `duration`, `tick_damage`, `tick_heal`, `dot_interval`, `immobilize`, `stun`, `haste`, `show_message` |
| `ProjectileEffect` | `base`, `damage_type`, `speed`, `color`, `visual_type`, `trail_length`, `trail_char`, `on_hit_statuses`, `components` |

`ABILITY_REGISTRY` starts empty; the content loader populates it before any entity construction.

### Content Loader (`faraway_realms/content.py`, `faraway_realms/content_parsers/`)

Generic YAML loading system. `ContentLoader(dirs=[game_dir, user_dir])` scans `*.yaml` files recursively in each directory (sorted, last-dir-wins). Merging is at the **entry name level** within each top-level key — a user file with only `kick:` overrides just that ability, not the whole file.

**Registering a parser:** `loader.register_parser("abilities", parse_abilities)`. Unknown top-level YAML keys are silently ignored (forward-compatible).

**Shipped data directories:**

| Key | Directory | Registry |
|---|---|---|
| `stat_definitions` | `faraway_realms/data/stats/` | `STAT_DEF_REGISTRY` |
| `abilities` | `faraway_realms/data/abilities/` | `ABILITY_REGISTRY` |
| `creatures` | `faraway_realms/data/creatures/` | `CREATURE_REGISTRY` |
| `character_types` | `faraway_realms/data/characters/` | `CHARACTER_REGISTRY` |
| `static_objects` | `faraway_realms/data/static_objects/` | `STATIC_OBJECT_REGISTRY` |
| `damage_effectiveness` | `faraway_realms/data/damage_types/` | `damage_types.EFFECTIVENESS` |
| `factions` | `faraway_realms/data/factions/` | `factions.FACTION_RELATIONS` |
| `tiles` | `faraway_realms/data/tiles/` | `TILE_REGISTRY` |
| `tile_overlays` | `faraway_realms/data/tiles/` | `TILE_OVERLAY_REGISTRY` |
| `tile_type_patches` | `faraway_realms/data/tiles/` | `TILE_TYPE_PATCH_REGISTRY` |

All ten are loaded by a single `ContentLoader` instance in `_load_content()`. The `data/` directory is in `.gitignore` except for YAML files (`*.db` excluded, YAML tracked).

**User overrides:** `~/.faraway_realms/{stats,abilities,creatures,characters,static_objects,damage_types,factions,tiles}/` — any `*.yaml` file here overrides game data at the entry-name level.

**Adding a new ability:** drop a YAML file in `faraway_realms/data/abilities/` (shipped) or `~/.faraway_realms/abilities/` (user). Top-level key must be `abilities:`. Each entry's key is the ability name used in `/cast` commands and the creature `abilities` field.

**Adding a new loadable type** (e.g. behaviours): write `content_parsers/behaviours.py` with a `parse_behaviours(entries: dict)` function, then `loader.register_parser("behaviours", parse_behaviours)` in `__main__.py`.

**YAML ability schema (key fields):**
```yaml
abilities:
  kick:
    abbreviation: "KI"
    cooldown: 300          # ticks at 10 Hz
    cast_time: 0           # 0 = instant
    range_tiles: 1
    gcd: true
    resource_cost: [mana, 15]   # optional
    effects:
      - kind: damage
        base: 10
        damage_type: slashing
      - kind: knockback
        distance: 1
      - kind: backstep
        distance: 2
      - kind: status
        status_name: bleed
        duration: 30
        tick_damage: 1
      - kind: projectile
        base: 20
        damage_type: fire
        speed: 1.5
        color: [255, 100, 0]
        trail_length: 4
        trail_char: "+"
        components:
          light_emitter: {radius: 3, intensity: 0.9, color: [255, 100, 0]}
        on_hit_statuses:
          - status_name: burn
            duration: 20
            tick_damage: 3
```

**Test isolation:** `tests/conftest.py` loads all shipped YAML at import time (stat_definitions, abilities, creatures, static_objects, tiles) so all registries are populated before any test module runs. Tests that need to override registry state save and restore the dict in a per-test fixture.

### Blood System (`faraway_realms/blood.py`)

Split across server (authoritative state) and client (animations):

**Server side** — `BloodMap` owns permanent per-tile stain data. On every hit, `Game._record_blood_splat()` calls `BloodMap.splat(tx, ty, ax, ay, color)`, which:
1. Computes 3 drop landing positions (1–3 tiles in the away-from-attacker direction, ±1 lateral spread).
2. Accumulates a soft pool around each landing: Manhattan distance 0–3 from centre, alpha weights `{0:55, 1:28, 2:12, 3:4}`, capped at `_POOL_ALPHA_MAX = 180`.
3. Returns the landing positions as a `BloodEvent` placed in `Game._blood_events`.

`Game.drain_blood_events()` is called by the UI each frame; `blood_map` property exposes the tile map for rendering.

**Client side** — `BloodParticle` (in `effects.py`) animates each drop: CP437 `*` (glyph 42) while in flight, `☼` (glyph 15) on landing, then gone. `MapView._render_blood_map()` composites permanent stains onto the map using `BKGND_ALPH` alpha blending; stains in explored-but-not-visible tiles are dimmed.

**Per-creature blood colours** are stored in the entity's `CombatProfile.blood_color` component. `None` = no blood (Skeleton, Rock Golem). In YAML, omitting `blood_color` under `components.combat_profile` defaults to `(180, 0, 0)`; `blood_color: null` disables blood.

### UI (`faraway_realms/ui/`)

`ui.py` has been split into a package. Three-pane TCOD layout at 30 FPS, decoupled from game tick rate (default 10 Hz):

- **Map pane** (top-left, 57×40): viewport centred on the player, clamped to map bounds.
- **Chat pane** (bottom-left): scrolling `ChatMessage` history with per-message RGB colour and scrollback. Enter focuses the input; Enter with text submits and unfocuses; Escape/empty-Enter unfocuses.
- **Details pane** (right strip): hosts a list of `Panel` objects cycled with `]` (reverse with `[` — not yet bound).

**Package modules:**

| Module | Responsibility |
|---|---|
| `layout.py` | All layout/colour constants and `_dim()` |
| `scroll_view.py` | `ScrollView` — reusable scrollable content area with `▲▼█│` scrollbar |
| `map_view.py` | `MapView` — tile/entity rendering, camera, FOV |
| `chat_view.py` | `ChatView` — input buffer, command history, chat scrollback |
| `status_bar.py` | `StatusBar` — attack cooldown bars |
| `overlays.py` | `Overlay` ABC + `HelpOverlay` rendered over the map pane |
| `game_ui.py` | `GameUI` — thin coordinator |
| `__init__.py` | Re-exports `GameUI` and all constants for backward compatibility |

**Overlay system**: `GameUI._overlay: Overlay | None`. When set, key events are routed to `overlay.handle_key(event)` first; returning `False` closes the overlay. `_render_frame` draws the overlay last (on top). ESC closes the overlay (or unfocuses chat) but **never exits the game** — only the window close / `Quit` event exits.

**Chat shortcuts** (when unfocused): `/` opens chat with `/` pre-filled; `?` opens `HelpOverlay`; `PageUp`/`PageDown` scroll chat history.

**Chat shortcuts** (when focused): `↑`/`↓` navigate command history (readline-style). `/help [command]` is intercepted in the UI layer and opens `HelpOverlay` instead of being sent to the game.

**`ScrollView`**: generic scrollable area used by both `ChatView` and `HelpOverlay`. Scrollbar column occupies the rightmost column of `width`. Scrollbar characters: `▲` (top), `▼` (bottom), `█` (thumb), `│` (track).

**Rendering order matters**: `_render_borders` must be called first in `_render_frame` because `draw_frame` clears interior cell characters — content is drawn on top of the frame.

### Panels (`faraway_realms/panels.py`)

`Panel` ABC: `title: str` + `render(console, x, y, width) -> int`.

`StatsPanel`: iterates `entity.stats`; renders `Pool` as `"HP: x/max"` text + colour bar (2 rows + spacer), `Stat` as `"STR: x"` text (1 row + spacer). Bar colours come from `stat.bar_filled` / `stat.bar_empty`; label from `stat.abbreviation`. Content width is `panel_width - 1` to preserve visual symmetry with the frame border.

### Chat (`faraway_realms/chat.py`)

`ChatMessage(text, color)` — frozen dataclass. Colour constants: `NPC_HIT_COLOR` (dark red), `PLAYER_HIT_COLOR` (yellow), `DEFAULT_COLOR` (light grey). `Game.add_chat_message(text, color)` appends; `get_chat_history(last_n)` slices.

### Commands

Slash-command syntax: `/verb actor [args...]`. `CommandParser` builds typed `Command` objects.

| Command | Syntax | Notes |
|---|---|---|
| MOVE | `/move <actor> <direction>` | direction: left/right/up/down |
| ATTACK | `/attack <actor> <target>` | target may be `@target` (resolves to actor's `target_id`) |
| TARGET | `/target <actor> [id\|next]` | omit id to clear; `next` cycles to nearest visible hostile |
| SPAWN | `/spawn <actor> <type> <x,y\|random>` | GM only; `random` picks a visible walkable tile |
| PRIME_COOLDOWN | internal | emitted by `ChaseState.on_enter()` and `_dispatch_target`; not user-facing |

`"me"` resolves to the first registered player's entity. Numeric strings resolve directly to entity IDs.

**Default key bindings** (`faraway_realms/ui/layout.py` `BINDINGS`):

| Key | Command |
|---|---|
| `hjkl` / arrow keys | Move |
| `f` | Attack `@target` |
| `t` / Tab | Cycle target |
| `]` | Cycle detail panel |

### GM Commands

`Player.is_game_master = True` enables spawn. Creature types must be registered via `game.register_creature(name, factory)` before `/spawn` can use them. In `__main__.py` this is done by iterating `CREATURE_REGISTRY` and registering a `ct.to_npc` factory for each. Spawned entities receive IDs from `Game._next_entity_id` (starts at 1000 to avoid conflicts with map-generated IDs).

The `random` position mode computes FOV from the actor's position and picks a random visible, walkable, unoccupied tile. The GM check resolves the actor entity ID back to a `Player` object to read `is_game_master` — a reverse lookup that works for now but is noted in the backlog for cleanup.

### Map Generation (`faraway_realms/mapgen/`)

Map generation is a pipeline of passes applied to a `MapGenResult`.

**`CaveGenerator`** — carves rooms from solid rock and connects them with 2-wide corridors. Returns a `MapGenResult` with `map`, `rooms` (ordered by creation; `rooms[0]` is always the player start room), `player_start`, and an empty `creature_placements` list.

**`PopulationPass`** — ABC for any post-generation step. Each pass receives `(result, rng)` and mutates the result in place. Built-in passes:

| Pass | Effect |
|---|---|
| `NoiseTexturePass` | Varies tile colours with Simplex noise; composable `TileTypePatch` and `TileOverlay` layers |
| `CreaturePopulationPass` | Filters `CREATURE_REGISTRY` by labels and appends `(CreatureType, x, y)` to `result.creature_placements` |
| `StaticObjectPopulationPass` | Filters `STATIC_OBJECT_REGISTRY` by labels and appends `(StaticObjectType, x, y)` to `result.static_object_placements` |

**Adding a new pass** — subclass `PopulationPass`, implement `apply`, and append it to the pipeline in `__main__.py` between `CaveGenerator.generate()` and reading `gen_result.map`.

**`TileTypePatch`** — noise-driven *tile type replacement*. Tiles in matching noise regions are swapped wholesale for named types from `TILE_REGISTRY` (e.g. gray rock seams). Semantically correct: the replaced tile knows what material it is, enabling descriptions and future per-type behaviour. Populated at startup from `data/tiles/` into `TILE_TYPE_PATCH_REGISTRY`. Fields: `floor` / `wall` (registry keys), `threshold`, `noise_offset`.

**`TileOverlay`** — noise-driven *colour compositing* on top of existing tiles. For environmental modifiers that sit on a tile rather than replace it (e.g. moss — still a cave floor, just mossy). Fields: `threshold`, `noise_offset`, `blend` (fade at edges when `True`), `description` (modifier string for a future inspect system, e.g. `"mossy"`), `char` (optional glyph override). Populated at startup from `data/tiles/` into `TILE_OVERLAY_REGISTRY`.

**Rendering order in `NoiseTexturePass`**: patches (base material) → non-blended overlays → colour shift (untouched tiles) → blended overlays (composited on top). Both `patches` and `overlays` args default to `None` (use registry); pass explicit tuples including `()` to bypass registries in tests.

### Lighting System (`faraway_realms/light.py`, `faraway_realms/components.py`)

`LightSource(radius, intensity, color)` — frozen dataclass; the value type consumed by `LightMap`.

`LightEmitter(LightSource, Component)` — subclass of both `LightSource` and `Component`. Attach to any object via `obj.components["light_emitter"] = LightEmitter(radius=5, intensity=0.8, color=(255,200,120))`. Because `LightEmitter` IS-A `LightSource` it passes directly to `LightMap.compute()` with no conversion. `game.light_sources()` collects from static objects, entities, and in-flight projectiles — all via the same `components` dict.

`LightMap` — per-tile RGB float32 arrays. `compute(sources)` resets to `AMBIENT = 0.35` then accumulates each source via vectorised numpy ops (no Python loop). `rgb_at(x, y)` returns per-channel brightness factors consumed by `MapView._tile_light_factor()`.

### Component System (`faraway_realms/components.py`)

`Component` — plain marker base class. Components are frozen dataclasses stored in a `components: dict[str, Component]` field present on `GameEntity`, `StaticObject`, `StaticObjectType`, and `ProjectileEffect`.

`LightEmitter(LightSource, Component)` — the first built-in component. Subclasses both `LightSource` and `Component` so it satisfies `LightMap.compute()` directly. Attach in Python: `entity.components["light_emitter"] = LightEmitter(radius=5, intensity=0.8, color=(255,200,120))`. Declare in YAML under a `components:` key (see static objects and projectile effect schemas).

**Adding a new component** — define a frozen dataclass in `components.py` that subclasses `Component`. Add a parser branch in whichever content parsers need to emit it. Systems read it via `obj.components.get("my_component")`. No dedicated field or class hierarchy change needed on any entity type.

### Static Objects (`faraway_realms/static_object.py`)

`StaticObject(x, y, char, fg_color, components)` — non-entity map decoration. Rendered between the blood layer and entities; does not block movement.

`StaticObjectType` — frozen dataclass template loaded from YAML into `STATIC_OBJECT_REGISTRY`. `to_static_object(x, y)` instantiates a `StaticObject`. Components are declared inline in YAML:

```yaml
static_objects:
  torch:
    char: "!"
    fg_color: [240, 160, 30]
    labels: [torch, cave]
    components:
      light_emitter:
        radius: 7
        intensity: 0.95
        color: [255, 150, 60]
```

Built-in types: `torch` and `glowing_mushroom` in `faraway_realms/data/static_objects/cave.yaml`.

`StaticObjectPopulationPass(labels, density)` — places one object per non-player room (at most), weighted by `density` (0–1). Player start room is always skipped.

### Creature Types (`faraway_realms/creature_type.py`, `faraway_realms/character_type.py`)

**`CreatureType`** — frozen dataclass; the authoritative template for an NPC or player entity. `to_entity(entity_id)` (aliased as `to_npc`) returns a plain `Entity` with `CombatProfile` and (when `behaviour_kind` is not `None`) `BehaviourComponent` attached as components.

Key fields:
- `stats: dict[str, int]` — resolved via `STAT_DEF_REGISTRY` at spawn time; no flat health/strength fields.
- `combat_profile: CombatProfile` — attack rate, armor/damage types, blood colour.
- `behaviour_kind: str | None` — `"wander_chase"` for AI; `None` = player-controlled (no `BehaviourComponent` added).
- `preferred_ability: str | None` — passed to the initial behaviour state.
- `labels: frozenset[str]` — free-form tags (`"cave"`, `"undead"`, `"uncommon"`, …) for map-gen filtering.

`CREATURE_REGISTRY: dict[str, CreatureType]` — populated by `parse_creatures` from `faraway_realms/data/creatures/`.
`CHARACTER_REGISTRY: dict[str, CreatureType]` — populated by `parse_character_types` from `faraway_realms/data/characters/`. Same type, `behaviour_kind=None`. The player entity is built via `CHARACTER_REGISTRY["hero"].to_entity(1)` in `__main__.py`.

**YAML schema for creatures** (`components:` block holds combat and behaviour config):
```yaml
creatures:
  zombie:
    char: "Z"
    fg_color: [60, 160, 60]
    stats: {health: 30, strength: 5, armor: 1}
    move_every: 8
    abilities: [bite]
    labels: [undead, cave, common]
    components:
      combat_profile:
        attack_every: 30
        armor_type: flesh
        damage_type: bludgeoning
        blood_color: [180, 0, 0]   # omit = default red; null = no blood
      behaviour:
        kind: wander_chase
        preferred_ability: bite    # omit if none
```

Absence of `components.behaviour` in YAML → `behaviour_kind=None` → player-controlled (used in `hero.yaml`).

`CreaturePopulationPass(labels=("undead",))` restricts placement to types tagged with at least one matching label — the hook for dungeon theming.

**Adding a new creature** — add an entry to `faraway_realms/data/creatures/cave.yaml` (or a new file in that directory). Required fields: `char`, `fg_color`. Add labels to control which map zones it spawns in.

**Adding a new behaviour** — add a new `elif` branch to `_make_behaviour()` in `creature_type.py` returning a `StateMachineBehaviour` with your custom initial state, then use the new `kind` string in `components.behaviour.kind` in YAML.

### Tile Types (`faraway_realms/tile.py`)

`Tile(walkable, bg_color, fg_color, char)` — mutable single map cell; may be modified by `NoiseTexturePass`.

`TileType` — frozen dataclass template. `TILE_REGISTRY: dict[str, TileType]` is populated at startup from `faraway_realms/data/tiles/cave.yaml`. `TileType.make()` returns a fresh `Tile` instance (callers must not reuse the registry object directly since tiles are mutable).

The factory functions (`cave_floor_tile()`, `cave_wall_tile()`, etc.) delegate to the registry when it's loaded and fall back to hardcoded values in test contexts where content hasn't been loaded.

**Adding a new tile type** — add an entry to `faraway_realms/data/tiles/cave.yaml` (or a new file). Required fields: `walkable`, `bg_color`, `fg_color`. The map generator references tiles by registry key.

### Map (`faraway_realms/map.py`)

`Map` holds a 2D grid of `Tile` objects and an `_entity_positions` dict (`entity_id → (x, y)`). `make_bordered_map` creates a rectangular map with impassable border walls.

### Multiplayer / Client-Server (`faraway_realms/net/`, `faraway_realms/client_game.py`)

**Single-player is always networked.** Launching without flags spins up an embedded `GameServer` on `localhost:0` (OS picks a free port) then connects to it as a client. There is exactly one code path. See `docs/network-architecture.md` for full detail.

**Launch modes:**

| Flag | Behaviour |
|---|---|
| *(none)* | Embedded server on `localhost:0`, then connect to self |
| `--serve HOST:PORT` | Dedicated server; also opens a local window unless `--headless` |
| `--connect HOST:PORT` | Pure client; no server started |

**Threading model** — two concurrency systems coexist:

- **Main OS thread**: TCOD render loop (synchronous, 30 FPS). Calls `latest_snapshot()` and `enqueue_command()`.
- **Daemon thread (`NetworkClient`)**: asyncio event loop. Receives tick snapshots; drains outbox every 20 ms.

Shared state is protected by a single `threading.Lock` inside `NetworkClient` covering `_snapshot`, `_welcome`, and `_outbox`. The server side is pure asyncio (single-threaded) — no locking needed.

**`GameProtocol`** (`faraway_realms/game_protocol.py`) — `@runtime_checkable` `typing.Protocol`. Both `Game` and `ClientGame` satisfy it structurally. All UI components are typed against `GameProtocol`, never `Game` directly.

**Wire protocol** (`faraway_realms/net/protocol.py`) — every message is a 4-byte big-endian length prefix followed by a msgpack body. `send_message` / `recv_message` are the only entry points. msgpack gives ~3× smaller payloads than JSON with faster encode/decode.

**`TickSnapshot`** (`faraway_realms/net/serialization.py`) — one complete frame of state sent to each client every tick. Contains FOV-filtered entities, blood tile deltas, attack/blood events (drained once in `serialize_shared`, broadcast to all), projectiles, light sources, chat history, cooldown fractions pre-computed for the client's player entity + its current target, `tile_reveals` (newly-explored tiles), and `static_object_reveals` (static objects on newly-explored tiles).

**`GameServer`** (`faraway_realms/net/server.py`) — asyncio server. `_tick_loop` advances `game.tick()` and broadcasts to all clients. Each client gets a `_ClientSession` (keyed by UUID from `~/.faraway_realms/client.uuid`). Disconnected sessions are held for 30 seconds before being reaped, keeping the player entity in-world during brief disconnects. Per-client visibility culling: the server computes FOV (`_PLAYER_SIGHT_RANGE = 12`) each tick, sends only entities within the player's FOV, and tracks `explored_tiles` per session for incremental tile/static-object delivery. The welcome message is culled to explored tiles (anti-maphack).

**`NetworkClient`** (`faraway_realms/net/client.py`) — runs in a daemon thread. Reconnects with exponential backoff (1 s → 2 → 4 … ≤ 30 s). `_recv_loop` updates `_snapshot` under the lock; `_send_loop` drains `_outbox` at 50 Hz.

**`ClientGame`** (`faraway_realms/client_game.py`) — implements `GameProtocol` from snapshots. Zero game logic; all methods read from `NetworkClient.latest_snapshot()`. `enqueue_command()` calls `NetworkClient.send_command()`. Entity objects are cached in `_entities_cache` and updated in-place each frame to avoid allocations.

**Serialization split** — `serialize_shared(game)` drains events once per tick (attack anims, blood, projectiles, lights, chat). `serialize_per_client(game, entity_id, ...)` adds FOV-filtered entities, `removed_entity_ids`, `tile_reveals`, `static_object_reveals`, and cooldown fractions for the player + its target. The shared dict is merged into each client's payload via `shared | per_client`.

**Bandwidth strategy** — three layers, no delta compression: (1) **FOV culling** — only entities/tiles within the player's sight range are sent; (2) **msgpack** — binary encoding, ~3× smaller than JSON; (3) **entity catalogue** (planned) — static entity data (char, colors, name, stat defs, abilities) sent once on connect, per-tick snapshots carry only dynamic state (position, current values, statuses). Current bandwidth: ~2.5 KB/tick (~25 KB/s) per client at 10 Hz.

## Key Design Decisions

- Real-time tick-based: the game loop advances at `tick_rate` Hz, processing all queued commands from players and NPCs each tick.
- Systems own no game reference — they receive only the shared state they need and return values. This keeps them independently testable.
- Single-player is always networked — there is no offline shortcut. Serialization bugs surface during normal play.
- Server-authoritative: the client runs zero game logic. All cooldown/cast/GCD fractions are pre-computed server-side per client.
- `@target` is resolved in `Game._resolve_target`; it expands to the actor's current `target_id`. A proper target resolution layer is in the backlog.

## Notes

- Always write tests.
- Run pre-commit before committing.
- `faraway_realms/assets/terminal16x16_gs_ro.png` is the CP437 tileset; referenced relative to `__file__` in `__main__.py`.
