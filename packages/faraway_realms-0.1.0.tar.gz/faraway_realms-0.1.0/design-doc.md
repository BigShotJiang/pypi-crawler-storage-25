# Faraway Realms

Faraway realms is a tcod based RPG with an oldschool roguelike/nethack like style. The game is focused on exploring an open overworld with dungeons, keeps, fortresses and forests to explore. It offers multiple combat styles like ranged, melee and magic and basis itself in a high fantasy setting. What distinguishes Faraway Realms is the realmtime tick based component which allows other game entities like monsters and npcs to move on a semi real-time basis instead of a turn based approach like usual rogue-likes (the ones like nethack and rogue). It offers multiplayer through a client/server approach.

## Features

* Python TCOD interface
* Animated tiles or tile backgrounds like bubbling lava or shimmering water
* Lighting based on tile color blending mode
* Game masters can add monsters, tiles, and game elements like spells, weapons and items through commands
* Client/server architecture allows for loading maps dynamically through the server which can send maps and map updates

## Approach

* Modular design. Different modules for the main tcod interface, the client/server, the map, game, and game entities like items, spells, static objects like trees, tables, chests.
* The main screen should consist of a map screen top left. This is the game world where the players move throughout. At the bottom is a chat window which players and npc's can use to communicate and which displays to combat log. messages prepended with a slash (/) indicate commands. So we will need a CommandParser, for example move commands, creating game instances for a game master, targeting things in the game, casting spells, think of a "/cast <spellname> <target>" or a "/target <entity-name>". These commands should also in some way be bindable to keys, so pressing the movement key for going left should fire a Move command (like /move <me> left) in which the me is the players character which can be implicitly filled in by the game. On the right should be a side panel in which we can display target information, or equipment/inventory/spellbook.
* A Game class, which processes Command instances, which manipulate game state in some way (Like a move command for a monster or player controlled character)
* The Game class updates based on a set tick rate, at whichn it processes commands, manipulates game and map state and sends out game updates.
* A Map class which is displayed in the map window, which displays instances of a Tile class, which have background color and optional foreground text character to display. A Tile needs to have fields for if it blocks movement or not (so if it's walkable).
* GameEntity class (which can be a monster or a playable game character, an item as seen in the game world, these examples can be subclasses of GameEntities).
* The Map, Entities, Commands and such need to be serializable or otherwise be able to be sent over the network to and from the server and clients.
* A Player class which holds player details, and a reference to their character (Which is a GameEntity Subclass).
* The interface should probably run on its own 30 FPS refresh rate to update tile animations.

## Things to find out

* Suitable tickrate
* Targeting enemies for combat effectively given we are on a 2d grid.
* Generating maps procedurally or generating map elements like rooms (by a game master)

## First Steps

### Project boilerplate

* Firstly we create a pyenv environment. we have pyenv available, use a new python version like 3.14.
* install the python tcod library through uv (use uv for dependency management.)
* Modify the contact information and clean up artifacts in the pyproject.toml (it is copied from another unrelated work project but has the correct linting options).
* install dev dependencies, run a pre-commit install.
* run a precommit update (or upgrade or whatever its called).
* Set up directory structure for tests and a correct python package. Make sure there is a place to store assets like the games character map (image of a font). For now I placed the intial font in the root directory. Move it where required.

### First implementation

* Create the tcod interface with the three elements Map view, chat window (with the chat input line) and the details view to the side.
* Create a Game class (holds the map and chat history)
* Create a Map class (holds tiles, location of game items)
* Create a Tile class (for now have a tile be walkable or not, and the background color, foreground color, optional character to display)
* Create a Player class (which holds reference to the GameEntity that actually moves in the world)
* Create a Game entity (also needs a character to display)
* Create a Command class and CommandParser class which can interpret commands and pass them to the game.
* Client and server architecure can be abstracted away in the initial implementation

For the first test a Map with a square of walkable tiles, surrounded by non walkable tiles is good. The player being able to send /move commands to walk around. Being able to focus the chat input with enter and send the command with enter are required.

## Notes

* Always write tests
* run pre-commit as you wish
* linting options cannot be changed
* Notify loudly if you want to place # noqa and always provide reason in the comment
