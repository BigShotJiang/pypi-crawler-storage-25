"""Session-wide setup — load YAML content before any test module is imported."""

from pathlib import Path

from faraway_realms.content import ContentLoader
from faraway_realms.content_parsers.abilities import parse_abilities
from faraway_realms.content_parsers.character_types import parse_character_types
from faraway_realms.content_parsers.creatures import parse_creatures
from faraway_realms.content_parsers.damage_types import parse_damage_effectiveness
from faraway_realms.content_parsers.factions import parse_factions
from faraway_realms.content_parsers.stat_definitions import parse_stat_definitions
from faraway_realms.content_parsers.static_objects import parse_static_objects
from faraway_realms.content_parsers.status_effects import parse_status_effects
from faraway_realms.content_parsers.tiles import (
    parse_tile_overlays,
    parse_tile_type_patches,
    parse_tiles,
)

_DATA = Path(__file__).parent.parent / "faraway_realms" / "data"
_STATS_DIR = _DATA / "stats"
_ABILITIES_DIR = _DATA / "abilities"
_CREATURES_DIR = _DATA / "creatures"
_CHARACTERS_DIR = _DATA / "characters"
_STATIC_OBJECTS_DIR = _DATA / "static_objects"
_DAMAGE_TYPES_DIR = _DATA / "damage_types"
_FACTIONS_DIR = _DATA / "factions"
_TILES_DIR = _DATA / "tiles"
_STATUS_EFFECTS_DIR = _DATA / "status_effects"

# Load at conftest import time so registries are populated before any
# test module's module-level code runs.
_loader = ContentLoader(
    dirs=[
        _STATS_DIR,
        _ABILITIES_DIR,
        _CREATURES_DIR,
        _CHARACTERS_DIR,
        _STATIC_OBJECTS_DIR,
        _DAMAGE_TYPES_DIR,
        _FACTIONS_DIR,
        _TILES_DIR,
        _STATUS_EFFECTS_DIR,
    ]
)
_loader.register_parser("stat_definitions", parse_stat_definitions)
_loader.register_parser("abilities", parse_abilities)
_loader.register_parser("creatures", parse_creatures)
_loader.register_parser("character_types", parse_character_types)
_loader.register_parser("static_objects", parse_static_objects)
_loader.register_parser("damage_effectiveness", parse_damage_effectiveness)
_loader.register_parser("factions", parse_factions)
_loader.register_parser("tiles", parse_tiles)
_loader.register_parser("tile_overlays", parse_tile_overlays)
_loader.register_parser("tile_type_patches", parse_tile_type_patches)
_loader.register_parser("status_effects", parse_status_effects)
_loader.load()
