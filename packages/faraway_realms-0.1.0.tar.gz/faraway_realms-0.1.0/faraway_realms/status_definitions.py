"""Status effect display definitions — pip colour and icon per status name."""

from __future__ import annotations

from dataclasses import dataclass


_DEFAULT_FG: tuple[int, int, int] = (230, 230, 230)


@dataclass(frozen=True)
class StatusDefinition:
    """Display metadata for a named status effect.

    Parameters
    ----------
    name : str
        Registry key; must match the ``status_name`` used in ability YAML.
    bg_color : tuple[int, int, int]
        Background RGB colour for the HUD pip.
    glyph : int
        Unicode codepoint rendered inside the pip (use ``ord("B")`` for ASCII
        or ``URIZEN_BASE + N`` for a Urizen sprite).
    fg_color : tuple[int, int, int]
        Foreground RGB colour for the glyph; defaults to near-white.
    """

    name: str
    bg_color: tuple[int, int, int]
    glyph: int
    fg_color: tuple[int, int, int] = _DEFAULT_FG


STATUS_DEF_REGISTRY: dict[str, StatusDefinition] = {}
