# Command Resolution

Notes on how the command queue works and the reasoning behind its design.

## The tick structure

```python
def tick(self) -> None:
    self._tick_count = (self._tick_count + 1) % self._tick_period()
    self._gather_npc_commands()             # NPCs enqueue intentions
    queue, self._command_queue = self._command_queue, []  # atomic swap
    for command in queue:
        self._process_command(command)      # map state updated after each
```

Three phases in order: **gather → swap → drain**.

## Why gather comes before the swap

The swap replaces `self._command_queue` with a fresh empty list. Anything
enqueued *after* the swap lands in the new list and is invisible to the
current drain loop — it waits until the next tick.

If NPC behaviour ran *inside* the drain (e.g. a command that spawned more
commands as a side effect), those child commands would miss the swap and
incur a one-tick delay. By gathering NPC intentions *before* the swap, all
commands — player and NPC — are captured together in `queue` and processed
in the same tick.

## Why the queue is the contention resolver

Map state is updated after every command, not at the end of the drain.
By the time a conflicting command runs, `is_occupied` already reflects the
move that just happened. The blocked command simply fails its collision
check and does nothing. No special contention logic is needed.

## Player vs NPC priority

Player commands arrive from external input between ticks — they are already
sitting in `self._command_queue` when the tick starts. NPC commands are
appended during `_gather_npc_commands`, which runs at the top of the tick.
This means player commands are always ahead of NPC commands in the queue,
giving players implicit priority over NPCs for free.

Two players contending for the same tile: whoever submitted their command
first (i.e. earlier in the queue) wins. Two NPCs: same rule. The queue
order is the priority system.

## Simultaneity

Because all entities form their intentions against the same game state
snapshot (the state at the start of the tick, before the drain), the model
is conceptually simultaneous — consistent with how tick-based games like
RuneScape resolve actions. NPCs react to where the player *was* at the
start of the tick, not where they moved to. At 10 ticks/second this lag
is imperceptible.

## What to watch out for

- **Commands that enqueue commands**: any handler that calls
  `game.enqueue_command()` as a side effect will push to the *new*
  `self._command_queue` (post-swap), so the child command is deferred to
  the next tick. This is usually fine (e.g. a spell that triggers a
  follow-up effect one tick later) but needs to be a conscious choice, not
  an accident.
- **Snapshot staleness in BehaviourContext**: `all_positions` and
  `occupied` are built once at the start of `_gather_npc_commands`. If
  multiple NPCs move in the same tick, later NPCs in the gather phase do
  not see the updated positions of earlier ones. Contention between NPCs is
  still resolved correctly at drain time via `is_occupied`, but the
  *intentions* of two NPCs could target the same tile — only the first one
  through the drain succeeds.
