# ECS Roadmap

Tracks the planned progression toward a fully declarative, component-driven
architecture.  Steps are ordered by impact and dependency.

---

## Core design principle

A player is an NPC whose commands are issued by a human over the network
rather than by the AI.  There is no fundamental difference between the two
at the entity level — the distinction lives entirely in whether the entity
carries a `BehaviourComponent`.

```
entity with BehaviourComponent  →  AI issues commands via NpcIntentSystem
entity without BehaviourComponent  →  Player session issues commands via network
```

This means `CharacterEntity` and `NonPlayerEntity` collapse into a single
`Entity` class.  The `Player` wrapper (username, session, explored tiles,
GM flag) continues to exist as *account metadata* — it just wraps `Entity`
instead of `CharacterEntity`.

---

## Step 1 — Entity unification + CombatProfile component

### What changes

**`faraway_realms/entity.py`**

Remove `CharacterEntity` and `NonPlayerEntity`.  Replace with a single
concrete class:

```python
@dataclass
class Entity(GameEntity):
    name: str
    move_every: int = 1   # 1 = no throttle (player); >1 = AI speed
```

`move_every` stays as a plain field — it is meaningful for every entity
that moves, and `1` is the natural "no throttle" default for players.

**`faraway_realms/components.py`** — two new components:

```python
@dataclass(frozen=True)
class CombatProfile(Component):
    attack_every: int = 5
    armor_type: str = "none"
    damage_type: str = "bludgeoning"
    death_stat: str = "health"
    blood_color: tuple[int, int, int] | None = (180, 0, 0)

@dataclass(frozen=True)
class BehaviourComponent(Component):
    behaviour: Behaviour   # non-optional; presence = AI-controlled
```

Fields removed from `GameEntity`: `attack_every`, `armor_type`,
`damage_type`, `blood_color`, `death_stat`.
Field removed from `NonPlayerEntity`: `behaviour`.

**Absence of `BehaviourComponent` signals player-controlled.** No flag
needed. `NpcIntentSystem` iterates entities that have this component;
everything else is driven by player input.

**`faraway_realms/game.py`**

- `_npcs: list[NonPlayerEntity]` → `list[Entity]`
- `all_npcs()` returns entities whose `components` contains `"behaviour"`
- `add_npc()` accepts `Entity`
- `Player.entity` type annotation: `CharacterEntity` → `Entity`

**`faraway_realms/systems/npc_intent.py`**

- All `NonPlayerEntity` type hints → `Entity`
- `npc.behaviour.act(...)` → `npc.components["behaviour"].behaviour.act(...)`
- `npc.move_every` — unchanged (field stays on `Entity`)

**`faraway_realms/systems/combat.py`**

- Read `attack_every`, `armor_type`, `damage_type`, `blood_color`,
  `death_stat` from `entity.components.get("combat_profile")` with sane
  defaults if the component is absent (e.g. non-combat entities can't die)

**`faraway_realms/creature_type.py`**

- `to_npc()` renamed `to_entity()`, returns `Entity`
- Constructs `BehaviourComponent` and `CombatProfile` and places them in
  `components`
- `armor_type`, `damage_type`, `blood_color`, `death_stat`, `attack_every`
  fields on `CreatureType` remain for now as sources for `CombatProfile`
  construction; they are removed in Step 2 when the YAML schema migrates to
  `components: combat_profile:`

### YAML impact (Step 1 only)

None yet — `CreatureType` still carries flat fields that `to_entity()`
reads to build the components.  The YAML migration happens in Step 2.

---

## Step 2 — Unified entity templates + player archetype YAML

### What changes

**Creature YAML** migrated to declare combat properties under
`components: combat_profile:` instead of flat top-level fields:

```yaml
creatures:
  zombie:
    char: "Z"
    fg_color: [60, 160, 60]
    move_every: 8
    stats:
      health: 30
      strength: 5
    abilities: [bite]
    labels: [undead, cave, common]
    components:
      combat_profile:
        attack_every: 30
        armor_type: flesh
        damage_type: bludgeoning
        blood_color: [180, 0, 0]
```

`preferred_ability` and `behaviour` also move under `components`:

```yaml
    components:
      combat_profile: ...
      behaviour:
        kind: wander_chase
        preferred_ability: bite
```

**`faraway_realms/data/characters/hero.yaml`** — player archetype, same
schema as creatures but without a `behaviour` component:

```yaml
character_types:
  hero:
    char: "@"
    fg_color: [255, 255, 0]
    name: Hero
    faction: player
    stats:
      health: 100
      mana: 50
      strength: 5
      constitution: 10
      armor: 2
      crit_chance: 10
    abilities:
      - kick
      - backstep
      - haste
      - parry
      - second_wind
      - firebolt
      - frostbolt
    components:
      combat_profile:
        attack_every: 10
        armor_type: leather
        damage_type: slashing
```

The absence of a `behaviour` component is what makes this entity
player-controlled — no flag, no special class, no branch in the game loop.

**`faraway_realms/creature_type.py`**

Flat fields `armor_type`, `damage_type`, `blood_color`, `death_stat`,
`attack_every`, `preferred_ability` removed; `CreatureType.components`
(already present) carries a `CombatProfile` and optionally a
`BehaviourComponent` instead.  `to_entity()` just copies `self.components`.

**`faraway_realms/__main__.py`**

`_build_game()` becomes a registry lookup:

```python
from faraway_realms.character_type import CHARACTER_REGISTRY
archetype = CHARACTER_REGISTRY["hero"]
entity = archetype.to_entity(entity_id=1)
player = Player(username="player1", entity=entity, is_game_master=True)
```

`_PLAYER_ABILITY_NAMES` list deleted — it lives in the YAML.

**New files**

- `faraway_realms/character_type.py` — `CharacterType` + `CHARACTER_REGISTRY`
  (same shape as `CreatureType` but no behaviour; or just reuse `CreatureType`
  with an optional behaviour component)
- `faraway_realms/content_parsers/character_types.py`
- `faraway_realms/data/characters/hero.yaml`

---

## Step 3 — Damage type matrix YAML

`damage_types.py` EFFECTIVENESS dict → `data/damage_types/core.yaml`.
Adds validation (unknown type strings warn at load time instead of silently
defaulting to 1.0).  New damage/armor type pairs require no Python changes.

```yaml
damage_effectiveness:
  bludgeoning:
    flesh: 1.0
    bone: 1.3
    chitin: 1.1
    stone: 1.5
  slashing:
    flesh: 1.2
    bone: 0.7
    ...
```

---

## Step 4 — Faction relations YAML

Initial hostility configuration extracted from `_build_game()` into
`data/factions/core.yaml`:

```yaml
factions:
  hostile_pairs:
    - [player, hostile]
```

Loaded into `FactionRelations` at startup.  The runtime object is unchanged;
only the initial seed is data-driven.

---

## Step 5 — TileOverlay presets YAML

`MOSS_OVERLAY` and `GRAY_ROCK_OVERLAY` module constants in `texture.py`
moved to `data/tiles/cave.yaml` under a `tile_overlays:` key.
`NoiseTexturePass` reads its default overlays from `TILE_OVERLAY_REGISTRY`
instead of hardcoded Python objects.  New biome textures require no Python
changes.

---

## Step 6 — Declarative behaviour config

`_make_behaviour()` if/elif chain replaced by a config-dict parser.
Behaviour states declared in YAML via `Condition` objects (see
`feedback_engine_design_direction.md`).  This is the largest design effort
and has its own design document when the time comes.

---

## Dependency graph

```
Step 1 (entity unification) ──► Step 2 (template YAML)
                                      │
           ┌──────────────────────────┤
           ▼                          ▼
      Step 3 (damage types)    Step 4 (factions)
      Step 5 (overlays)        Step 6 (behaviours)
```

Steps 3–5 are independent of each other and of Step 2.
Step 6 depends on Step 2 (needs unified entity templates to wire into).
