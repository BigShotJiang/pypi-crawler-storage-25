# Game Master Guide

This guide covers everything a GM needs to manage a Faraway Realms session: in-game commands, creature management, map generation, and the content database.

---

## In-Game Commands

All commands are entered in the chat bar (press `/` to focus it). Commands follow the pattern `/verb actor [args...]`. In single-player, `me` always refers to the player character.

| Command | Example | Effect |
|---|---|---|
| `/target me <id>` | `/target me 5` | Set your current target to entity 5 |
| `/target me` | `/target me` | Clear your current target |
| `/attack me @target` | `/attack me @target` | Attack your current target |
| `/attack me <id>` | `/attack me 5` | Attack entity 5 directly |
| `/spawn me <type> random` | `/spawn me Zombie random` | Spawn a creature at a random visible tile |
| `/spawn me <type> <x,y>` | `/spawn me Bat 30,15` | Spawn a creature at a specific tile |

`/spawn` requires GM privileges (`Player.is_game_master = True`). Spawnable creature types are those registered with the game at startup — see [Managing Creatures](#managing-creatures).

**Tip:** Press `↑` / `↓` in the chat input to cycle through your command history.

---

## Map Generation

Maps are generated fresh each run using a cave generator that carves rooms from solid rock. Every room except the first (where the player spawns) gets one creature placed at its centre. Which creatures appear is controlled entirely by the creature database and optional label filters.

### Dungeon Themes with Labels

Every creature type carries a set of labels. The map generator can be restricted to creatures matching a given theme by passing `labels=` to `CreaturePopulationPass`:

```python
# In __main__.py — only undead creatures in every room
CreaturePopulationPass(db=db, labels=("undead",))

# Mix two themes
CreaturePopulationPass(db=db, labels=("undead", "cave"))
```

Matching is **any**: a creature is eligible if it has at least one of the listed labels.

Built-in labels:

| Label | Creatures |
|---|---|
| `cave` | All built-in creatures |
| `undead` | Zombie, Skeleton |
| `creature` | Slime, Bat, Giant Spider |
| `common` | Zombie, Slime, Bat |
| `uncommon` | Skeleton, Giant Spider |

You can define any label you like on a creature type. Labels are created automatically when a creature type is saved.

---

## Managing Creatures

The game content lives in a SQLite database at `faraway_realms/data/gamedata.db`. It is created and seeded automatically on first run. You interact with it via Python scripts or directly with any SQLite client (e.g. DB Browser for SQLite, the `sqlite3` CLI).

### Built-in Creature Types

The game runs at **10 ticks/second**. Attack and move periods are in seconds for readability.

| Name | Glyph | HP | STR | Armor | Armor type | Dmg type | Move | Attack | Sight | Labels |
|---|---|---|---|---|---|---|---|---|---|---|
| Zombie | `Z` | 30 | 5 | 1 | flesh | bludgeoning | 0.8 s | 3 s | 8 | undead, cave, common |
| Slime | `s` | 15 | 2 | 0 | flesh | bludgeoning | 1.2 s | 4.5 s | 5 | creature, cave, common |
| Skeleton | `S` | 20 | 6 | 2 | bone | slashing | 0.5 s | 1.8 s | 10 | undead, cave, uncommon |
| Bat | `b` | 8 | 2 | 0 | flesh | piercing | 0.3 s | 2.5 s | 12 | creature, cave, common |
| Giant Spider | `x` | 25 | 7 | 3 | chitin | piercing | 0.4 s | 2 s | 9 | creature, cave, uncommon |
| Rock Golem | `G` | 60 | 10 | 8 | stone | bludgeoning | 1 s | 5 s | 6 | creature, cave, uncommon |

The hero attacks every **1 s** (`attack_every = 10`), making them noticeably snappier than any creature.

**Design notes:**
- Skeletons are the most aggressive (1.8 s attack) and weak to bludgeoning.
- Giant Spiders close distance fast but their chitin deflects piercing — their own damage type.
- Rock Golems telegraph every hit with a 5 s wind-up; the hero's slashing deals only 0.3× — bring a hammer.

### Adding a New Creature Type

Run this from the project root:

```python
from faraway_realms.gamedb import GameDatabase
from faraway_realms.creature_type import CreatureType

db = GameDatabase()
db.save_creature_type(CreatureType(
    name="Troll",
    char="T",
    fg_color=(120, 80, 40),      # RGB
    health=60,
    strength=10,
    move_every=4,                # moves every 4 ticks (slow)
    attack_every=6,              # attacks every 6 ticks
    sight_range=6,
    armor=4,                     # flat damage reduction
    armor_type="flesh",          # "none", "flesh", "bone", "chitin", "stone"
    damage_type="bludgeoning",   # "bludgeoning", "slashing", "piercing"
    labels=frozenset({"cave", "uncommon"}),
))
```

The creature is immediately available to `/spawn` and map generation on the next run.

### Editing an Existing Creature

`save_creature_type` is an upsert — call it with the same `name` to overwrite:

```python
from faraway_realms.gamedb import GameDatabase
from faraway_realms.creature_type import CreatureType

db = GameDatabase()
zombie = db.creature_type("Zombie")

# Make zombies faster and rarer
db.save_creature_type(CreatureType(
    **{**vars(zombie), "move_every": 1, "labels": frozenset({"undead", "cave", "uncommon"})}
))
```

### Querying the Database

```python
db = GameDatabase()

# All creatures
all_types = db.creature_types()

# Only undead
undead = db.creature_types(labels=["undead"])

# Single lookup
troll = db.creature_type("Troll")   # None if not found
```

### Direct SQLite Access

The database file is at `faraway_realms/data/gamedata.db`. You can open it with any SQLite tool:

```bash
sqlite3 faraway_realms/data/gamedata.db

# List all creatures with their labels
SELECT ct.name, ct.char, ct.health, ct.strength, GROUP_CONCAT(l.name) as labels
FROM creature_types ct
LEFT JOIN creature_type_labels ctl ON ct.id = ctl.creature_type_id
LEFT JOIN labels l ON ctl.label_id = l.id
GROUP BY ct.id
ORDER BY ct.name;
```

### Resetting to Defaults

Delete the database file — it will be recreated with the built-in seed data on next startup:

```bash
rm faraway_realms/data/gamedata.db
```

---

## Creature Stats Reference

| Field | Effect |
|---|---|
| `health` | Maximum health pool; death triggers when it reaches 0 |
| `strength` | Base damage per attack; also determines stagger duration |
| `armor` | Flat damage reduction applied before type multiplier; `0` = no armor stat shown |
| `armor_type` | Categorical armor material; affects incoming damage multiplier |
| `damage_type` | Categorical attack style; affects outgoing damage multiplier |
| `move_every` | Ticks between moves (lower = faster) |
| `attack_every` | Ticks between attacks (lower = faster) |
| `sight_range` | Circular detection radius in tiles |
| `faction` | `"hostile"` attacks the player on sight; other values do not |
| `behaviour` | AI strategy; currently only `"wander_chase"` is supported |
| `death_stat` | Which stat pool triggers death when empty; almost always `"health"` |

### Behaviour: `wander_chase`

The only built-in behaviour. The creature wanders randomly until it spots a hostile target within `sight_range` tiles (circular, blocked by walls), then chases using A* pathfinding and attacks when adjacent.

---

## Damage Type Matrix

The damage formula is `max(1, round((strength − armor) × multiplier))`. The
multiplier depends on the attacker's `damage_type` versus the defender's
`armor_type`:

| | `none` | `flesh` | `bone` | `chitin` | `stone` |
|---|---|---|---|---|---|
| **`bludgeoning`** | 1.0× | 1.0× | **1.3×** | 1.1× | **1.5×** |
| **`slashing`** | 1.0× | **1.2×** | 0.7× | 0.8× | 0.3× |
| **`piercing`** | 1.0× | 1.1× | 0.9× | 0.6× | 0.2× |

Any pair not listed defaults to 1.0×. `"none"` always gives 1.0× against all
damage types.

**Rules of thumb:**
- Bludgeoning beats bone and stone (hammers crack hard things).
- Slashing excels vs flesh but bounces off stone.
- Piercing sinks into flesh but is deflected by hard shells and stone.

When adding a new creature, pick `armor_type` to hint at counters: a heavily
armored creature with `"bone"` armor is a natural challenge for slashing heroes
but vulnerable to the right bludgeoning weapon in someone else's hands.

---

## Player Stats Reference

The hero's starting stats (from `__main__.py`):

| Stat key | Abbreviation | Starting value | Effect |
|---|---|---|---|
| `health` | HP | 100 | Maximum health pool |
| `mana` | MP | 50 | Mana pool (no mechanics yet) |
| `strength` | STR | 5 | Damage per attack and stagger duration |
| `constitution` | CON | 10 | Display only (no mechanics yet) |
| `armor` | ARM | 2 | Flat incoming damage reduction |
| `crit_chance` | CRIT | 10 | % chance to deal double damage |

The `armor_type` for the hero is `"leather"` and `damage_type` is `"slashing"`.
These are fields on the entity, not displayed stats.
