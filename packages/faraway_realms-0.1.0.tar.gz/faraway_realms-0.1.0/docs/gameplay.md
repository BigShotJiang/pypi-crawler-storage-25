# Gameplay Systems

This document describes the systems the player can interact with, the rules
governing them, and the reasoning behind non-obvious mechanics.

---

## Controls

| Key | Action |
|---|---|
| `H` / `←` | Move left |
| `J` / `↓` | Move down |
| `K` / `↑` | Move up |
| `L` / `→` | Move right |
| `T` | Cycle target |
| `F` | Attack current target |
| `Enter` | Open chat / command input |
| `/` | Open chat and begin a slash command |
| `Escape` | Close chat input |
| `Tab` | Cycle details panel |

**While chat is open:**

| Key | Action |
|---|---|
| `↑` | Recall previous command (scroll older) |
| `↓` | Scroll to newer command (or restore current draft) |
| `Enter` | Submit (if buffer non-empty) and close |
| `Escape` | Discard and close |

Movement is **cardinal only** (no diagonals). A move is blocked silently if the
destination tile is a wall or currently occupied by another entity.

Chat input accepts free text (logged to the combat log) or slash commands
(`/move`, `/attack`, `/target`). All key bindings send the equivalent slash
command internally, so `/attack <id> <target_id>` typed in chat is identical
to pressing `F`.

### Command history

Previously submitted slash commands are saved in a per-session history. With
chat open, `↑` scrolls toward older commands and `↓` scrolls toward newer
ones, filling the input with the selected command. Pressing `↓` past the most
recent entry restores whatever you were typing before you started browsing.
Typing any character exits history mode and keeps the current buffer.

---

## Targeting

### Cycling (`T`)

Pressing `T` sends `/target me next`. The targeting system:

1. Computes the player's field of view (default radius: 15 tiles).
2. Collects all visible entities hostile to the player's faction.
3. Sorts them by **Chebyshev distance** (nearest first).
4. Advances `target_id` to the one after the current target, wrapping around
   to the nearest when the end of the list is reached.
5. If no hostiles are visible, clears `target_id`.

### Visual indicator

The targeted entity's glyph **blinks** between its own color and yellow
(`#FFDC00`) on a 1-second cycle (0.5 s yellow, 0.5 s normal). The entity's
original color is always visible on the off phase, preserving visual identity.

### Automatic target loss

At the end of every game tick, after all commands and events have resolved, the
engine checks whether the player's current target is still visible. If the
target has died, moved out of the player's FOV, or is otherwise no longer on
the map, `target_id` is silently cleared. The player must cycle again to
re-acquire.

### Auto-retaliation on contact

When a hostile entity moves adjacent to the player and triggers a **contact**
event (see below), the player's `target_id` is automatically set to that
entity **if it was previously unset**. An existing target is never overwritten
by contact — the player's current focus is preserved.

---

## Combat

### Attacking (`F`)

Pressing `F` sends `/attack <player_id> @target`. The `@target` token resolves
to the player's current `target_id`. If no target is set, the command is a
no-op.

### Attack cooldown (`attack_every`)

Every entity has an `attack_every` field (ticks between allowed attacks).
The player's hero has `attack_every = 10`. At the default tick rate of 10
ticks/second this equals **one attack per second** — faster than any creature
in the game, giving the player an inherent timing advantage.

The `CombatSystem` gates each attack attempt:

```
ready = abs_tick - last_attack_tick >= effective_attack_every
```

where `effective_attack_every = max(1, attack_every - stats["attack_speed"].value)`
(the optional `attack_speed` stat can reduce the cooldown, e.g. from equipment).

### What happens when the player spams `F`

Each keypress enqueues one ATTACK command. Within a single tick, all queued
commands drain in order. If the cooldown has not elapsed:

- `CombatSystem` returns `CombatResult(damage_dealt=0, events=[])`.
- No damage is applied. No chat message is logged.
- The command is silently discarded.

At most **one attack lands per `attack_every` ticks**, regardless of how many
times `F` is pressed. The cooldown bar at the bottom of the map pane shows
when the player is ready to attack again.

### Damage formula

```
effective = max(1, round((strength − armor) × type_multiplier))
damage    = effective × 2   if critical hit
damage    = effective       otherwise
```

**Strength** — base damage per hit (the attacker's `strength` stat).

**Armor** — flat damage reduction (the defender's `armor` stat). Armor is
subtracted from strength before applying the type multiplier. The minimum
damage after armor and type multiplier is always 1.

**Type multiplier** — determined by the attacker's `damage_type` versus the
defender's `armor_type`. See [Damage Types](#damage-types) below.

The hit is logged in the chat pane. Player hits appear in yellow; NPC hits in
dark red. Critical hits are prefixed with `"Critical! "`.

### Damage types

The attacker's `damage_type` and the defender's `armor_type` together
determine a multiplier applied to the post-armor damage. Common types:

| Damage type | vs flesh | vs bone | vs chitin | vs stone |
|---|---|---|---|---|
| `bludgeoning` | 1.0× | 1.3× | 1.1× | **1.5×** |
| `slashing` | **1.2×** | 0.7× | 0.8× | 0.3× |
| `piercing` | 1.1× | 0.9× | 0.6× | 0.2× |

Any unlisted pair (e.g. your damage type against `"none"` armor) defaults to
1.0×. The player hero uses `damage_type = "slashing"` and `armor_type =
"leather"` by default.

### Critical hits

When an attacker has a `crit_chance` stat (0–100), each attack rolls a d100.
If the roll is ≤ `crit_chance`, the hit is a critical hit:

- Damage is **doubled** (applied after armor and type modifier).
- A **bright yellow vignette** flashes at the edges of the map pane.

The hero starts with `crit_chance = 10` (10% per swing).

### Attack cooldown bar

The thin bar at the bottom of the map pane shows how far through the attack
cooldown the player is. It fills from left to right; when full the player can
swing again. Stagger (see below) extends the bar beyond its normal reset point.

### Stagger

Being hit mid-swing pushes the target's attack bar back by
`max(1, attacker_strength ÷ 2)` ticks — like WoW spell pushback.

- A strength-5 attacker pushes back 2 ticks.
- A strength-10 attacker pushes back 5 ticks (capped so the bar never
  goes below zero).

**Key rule:** stagger only applies when the target is **mid-cooldown**. If
they have fully recovered from their last swing (cooldown bar full), the hit
lands but their next attack is unimpeded — a balanced fighter can't be
flinched. This means disabling the counter-attack of an enemy who just swung
at you is possible, but trading blows with a fresh opponent is not penalised
by stagger.

### Death

When a target's `health` pool reaches zero, a `DEATH` event is emitted that
tick. On resolution: the entity is removed from the map and entity registry,
and all entities that had it as their `target_id` have that field cleared.

---

## Contact and Initiative

A **CONTACT** event fires whenever an entity moves into a tile adjacent
(including diagonals, Chebyshev distance = 1) to a hostile entity. This
happens **before** the move is committed.

### Initiative

The `ContactResolutionSystem` determines who strikes first:

| Condition | Result |
|---|---|
| Defender already had the mover as their `target_id` | **Defender wins** — they were prepared |
| Defender's `target_id` was anything else | **Mover wins** — they attacked by approaching |

The winner's ATTACK command is enqueued for the current tick.

### Opportunity attacks

An opportunity attack fires when a **targeted entity tries to move away** from
an adjacent hostile. The sequence:

1. Player presses a movement key.
2. `MovementSystem` checks, before executing the move, whether any adjacent
   hostile entity has `target_id == player_entity_id`.
3. For each such entity, a CONTACT event is emitted with that hostile as the
   source.
4. The CONTACT event resolves via `ContactResolutionSystem`, which queues an
   ATTACK command from the hostile.
5. The hostile strikes **this tick**.
6. The player's move still completes — the attack does not interrupt movement.

**Key implication:** disengaging from a melee fight is not free. If an NPC has
locked onto the player (its `target_id` is set), moving away will trigger a
parting blow. Cycling to a new target and running while the NPC's `target_id`
is still set will also trigger this.

Opportunity attacks only fire when the hostile is **currently targeting the
player**. An NPC that is merely adjacent but focused elsewhere will not strike
on a player retreat.

---

## Field of View

The player can see tiles within a radius of 15 tiles (or the value of their
`sight` stat if set). Tiles outside the FOV are hidden. Previously seen tiles
are rendered at 35% brightness (fog of war / explored memory). Entities are
only visible and targetable when inside the current FOV — they do not appear
in explored-but-not-visible areas.

The FOV shape is currently based on Chebyshev distance (square). A circular
Euclidean mask is planned but deferred until map geometry (rooms, corridors)
makes the distinction meaningful.

---

## Game Master Commands

Players with `is_game_master = True` have access to additional commands for
testing and debugging. In the default single-player setup, the hero is always
a GM.

### Spawning creatures (`/spawn`)

```
/spawn me <creature_type> <x,y>
/spawn me <creature_type> random
```

Spawns a creature at the given position. The `random` argument places the
creature on a randomly chosen visible, walkable, unoccupied tile within the
player's current field of view.

| Creature type | Glyph | HP | Strength | Speed |
|---|---|---|---|---|
| `zombie` | `Z` | 30 | 5 | every 3 ticks |
| `slime` | `s` | 15 | 2 | every 5 ticks |

A confirmation message is logged to the chat pane on success. The command is
silently ignored if the creature type is unknown, the position is outside the
map or on a wall, or the actor is not a GM.
