# Network Architecture Audit

Analysis of the current client-server implementation: what we send, how much,
why it is the way it is, and what to improve.

---

## Why do we re-serialize for every client?

**This has been fixed.** `serialize_tick` was split into two functions:

- `serialize_shared(game)` — called **once** per tick; builds entities, blood
  tiles, drained events, projectiles, light sources, static objects, chat.
- `serialize_per_client(game, player_entity_id)` — called once per connected
  client; returns only cooldown/cast/GCD fractions specific to that player plus
  their current target's fractions.

`GameServer._broadcast_tick` merges them with `shared | per_client` before
sending.

**About 95 % of the payload is identical** across all connected clients; the
per-client portion is only:

```python
attack_cooldown_fraction, gcd_fraction, cast_fraction,
ability_cooldowns, target_entity_id, target_attack_fraction,
target_cast_fraction, target_gcd_fraction
```

The drain bug (`drain_attack_anim_events()` and `drain_blood_events()`
consuming queues during the first client's serialization so clients 2–4 got
empty event lists) is fixed as a side-effect: events are drained once inside
`serialize_shared`, before the broadcast loop.

---

## Packet size estimate

Reference scenario: 4 players, 20 NPCs, 50 static objects (torches/mushrooms),
moderate blood accumulation.

### Per-field breakdown

**Entities** — each JSON entity looks roughly like:

```json
{
  "entity_id": 1, "x": 42, "y": 17, "char": "@",
  "fg_color": [255, 100, 100], "display_name": "Roel",
  "faction": "player", "target_id": null,
  "blood_color": [200, 0, 0], "is_player": true,
  "stats": {
    "health": {"base": 100, "bonus": 0, "abbreviation": "HP",
               "current": 85, "is_pool": true},
    "strength": {"base": 10, "bonus": 0, "abbreviation": "STR",
                 "is_pool": false}
  },
  "abilities": ["kick", "fireball"],
  "status_effects": []
}
```

~350–500 bytes per entity. 24 entities ≈ **10 KB**.

**Blood tiles** — each entry:

```json
"42,17": {"color": [200, 0, 0], "alpha": 128}
```

~45 bytes each. Blood accumulates without bound over a session:

| Tiles | Size |
|---|---|
| 50 (early) | ~2 KB |
| 300 (mid session) | ~14 KB |
| 1 000+ (long session) | 45 KB+ |

**Static objects** — re-sent *every tick* even though they never change (known
bug). `{"x": 10, "y": 15, "char": "T", "fg_color": [255, 200, 0]}` × 50
objects ≈ **2.5 KB wasted every tick**.

**Light sources** — `[x, y, radius, intensity, [r, g, b]]` × ~20 sources ≈
**~1 KB**.

**Chat, cooldowns, misc** — **~1 KB**.

### Totals

| Component | Early session | Late session |
|---|---|---|
| Entities | ~10 KB | ~10 KB |
| Blood tiles | ~2 KB | ~45 KB+ |
| Static objects | ~2.5 KB | ~2.5 KB |
| Light + misc | ~2 KB | ~2 KB |
| **Per-client total** | **~17 KB** | **~60 KB+** |

At 10 Hz × 4 clients:

- Early session: 4 × 10 × 17 KB = **~680 KB/s** server outbound
- Late session: 4 × 10 × 60 KB = **~2.4 MB/s** server outbound

**For LAN play with ≤ 8 players: entirely fine.** The late-session blood
accumulation is the only real concern for internet play.

---

## Comparison to best practices

| Technique | Industry standard | Us |
|---|---|---|
| **Wire format** | Binary (msgpack, protobuf, custom bitstream) | JSON — human-readable but ~3–5× larger |
| **Delta compression** | Send only what changed since last acknowledged state | Full state every tick |
| **Interest management** | Only send entities within the player's view radius | All entities to all clients |
| **Shared serialization** | Serialize common parts once; stamp per-client fields | ✅ Done — `serialize_shared` + `serialize_per_client`; drain bug fixed |
| **Static data** | Sent once in the welcome message | Static objects re-sent every tick (bug) |
| **Tick rate** | 20–128 Hz for FPS; 10–30 Hz for strategy/RPG | 10 Hz — appropriate for roguelike pace |
| **Client-side prediction** | Client predicts own movement; server corrects | No prediction — client renders latest snapshot |
| **Snapshot interpolation** | Interpolate between snapshots to smooth motion | None — raw latest snapshot rendered directly |

For a **roguelike at 10 Hz on LAN with ≤ 8 players** the current approach is
entirely adequate. No prediction or interpolation is needed at 10 Hz; 100 ms
input latency is imperceptible when nothing moves faster than 10 tiles/second.

---

## Backlog items (ordered by impact)

### 1. Blood tile delta encoding — HIGH IMPACT, LOW EFFORT

Instead of sending all N blood tiles every tick, track a `_dirty_blood` set on
the server and send only tiles modified since the last broadcast. Late-joiners
and reconnects still need the full snapshot (send it once in the welcome or on
first tick).

Expected saving: cuts blood-tile payload from O(total tiles) to O(new hits per
tick) — typically 0–3 entries instead of hundreds.

### 2. Static objects sent once — HIGH IMPACT, LOW EFFORT

Static objects never change after map generation. Send them in the welcome
message alongside the map tiles and remove them from `serialize_tick`. Saves
~2.5 KB per client per tick unconditionally.

### ~~3. Shared serialization~~ — ✅ DONE

Implemented in `faraway_realms/net/serialization.py` (`serialize_shared` /
`serialize_per_client`) and wired in `GameServer._broadcast_tick`. Events are
drained once; per-client fractions now include target cooldown data for the
enemy status bar. Drain bug eliminated.

### 4. Switch from JSON to msgpack — MEDIUM IMPACT, MEDIUM EFFORT

msgpack is a drop-in binary replacement: same schema, ~60 % smaller on the
wire, faster to encode/decode. Only `faraway_realms/net/protocol.py` needs
changing (`json.dumps` → `msgpack.packb`, `json.loads` → `msgpack.unpackb`).
The 4-byte length-prefix framing is unchanged. Requires adding `msgpack` as a
dependency.

### 5. Entity relevance filtering — LOW IMPACT FOR 4 PLAYERS

Only send entities within each player's FOV radius (or a slightly larger
interest radius). At 4 players with ~24 entities total the saving is small, but
it would matter at higher player/NPC counts and is the right architectural
direction.

### 6. Client-side prediction — NOT NEEDED YET

At 10 Hz on a LAN the round-trip is well under one tick. Worth revisiting if
tick rate increases or internet play is targeted.
