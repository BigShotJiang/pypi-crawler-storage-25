# Network Architecture

This document explains how Faraway Realms handles client-server multiplayer,
including the single-player case. It covers the full data path from user
keypress to rendered frame, and explains each module in detail.

---

## The core principle: single-player is always networked

There is only one code path for running the game. When you launch without any
flags, the process:

1. Builds a `Game` instance (the authoritative server-side state).
2. Spins up a `GameServer` bound to `127.0.0.1:0` (port 0 = OS picks a free
   loopback port).
3. Reads the bound port back from the server socket.
4. Connects to itself as a `NetworkClient`.
5. Opens the TCOD window backed by a `ClientGame`.

This means serialization bugs are caught during normal single-player use, and
there is no "offline shortcut" that could drift from the networked path.

---

## Launch modes

```
python -m faraway_realms                       # single-player (embedded server)
python -m faraway_realms --serve 0.0.0.0:9999  # dedicated server + local UI
python -m faraway_realms --serve 0.0.0.0:9999 --headless  # server only, no window
python -m faraway_realms --connect host:9999   # pure client
```

The `main()` function in `__main__.py` dispatches to one of three helpers:

| Flag | Helper | What it does |
|---|---|---|
| *(none)* | `_run_singleplayer` | Builds game, starts server on port 0, then calls `_run_as_client` |
| `--serve HOST:PORT` | `_run_as_server` | Builds game, starts server on given address; if not `--headless`, also calls `_run_as_client` locally |
| `--connect HOST:PORT` | `_run_as_client` | Skips game build entirely; only connects |

---

## Threading model

The biggest source of confusion in this code is that two different concurrency
systems are active at the same time and must not step on each other.

```
Main OS thread                    Daemon thread ("NetworkClient")
─────────────────────────────     ───────────────────────────────
tcod event loop (synchronous)     asyncio event loop
  └─ renders frames at 30 fps       └─ recv: reads tick snapshots from server
  └─ reads latest_snapshot()        └─ send: drains outbox every 20 ms
  └─ calls enqueue_command()
```

The two threads share exactly three things, all protected by a single
`threading.Lock` inside `NetworkClient`:

| Shared datum | Written by | Read by |
|---|---|---|
| `_snapshot` | Network thread (on each tick received) | Main thread (every frame) |
| `_welcome` | Network thread (once, on connect) | Main thread (during startup) |
| `_outbox` | Main thread (on key press) | Network thread (every 20 ms) |

The main thread **never blocks** — `latest_snapshot()` acquires the lock and
returns immediately. If no snapshot has arrived yet, it returns `None` and the
UI simply renders nothing until the first tick arrives.

The server side is pure asyncio (single-threaded). `GameServer.run()` starts
two concurrent tasks in its event loop:

- `_tick_loop`: advances the game state and broadcasts to all clients.
- The `asyncio.Server` accept loop: handles new connections.

Because these run in the same asyncio event loop there is **no locking** on the
server side — only one of them can run at a time.

---

## Module walkthrough

### `faraway_realms/net/protocol.py` — wire framing

Every message on the wire is a JSON object preceded by a 4-byte big-endian
unsigned integer that gives the byte length of the JSON body:

```
┌──────────────────┬───────────────────────────────────┐
│  length (4 bytes)│  JSON body (length bytes, UTF-8)  │
└──────────────────┴───────────────────────────────────┘
```

Two coroutines handle this:

```python
send_message(writer, payload)   # pack → write → drain
recv_message(reader) → dict     # readexactly(4) → unpack → readexactly(n) → loads
```

`readexactly` raises `asyncio.IncompleteReadError` when the connection closes
mid-message; this propagates up and the caller treats it as a normal disconnect.

**Why JSON?** Human-readable, zero extra dependencies, easy to debug with
`tcpdump`. The 4-byte header makes it trivially re-parseable to msgpack later
without changing any callers — only this file needs changing.

---

### `faraway_realms/net/serialization.py` — snapshot data model

#### `EntitySnapshot` (frozen dataclass)

A snapshot of a single entity sufficient for rendering:

| Field | Source |
|---|---|
| `entity_id`, `char`, `fg_color`, `display_name` | `GameEntity` fields |
| `x`, `y` | `game_map.get_entity_position(entity_id)` |
| `faction`, `target_id`, `blood_color` | `GameEntity` fields |
| `is_player` | `True` for player entities, `False` for NPCs |
| `stats` | Each stat serialized as `{base, bonus, abbreviation, current?, is_pool}` |
| `abilities` | Just the ability names (keys of `entity.abilities`) |
| `status_effects` | `{name, expires_at, immobilize, stun, haste}` per active status |

#### `TickSnapshot` (mutable dataclass)

One complete frame of game state as received by the client:

| Field | Type | Notes |
|---|---|---|
| `entities` | `list[EntitySnapshot]` | All players then all NPCs |
| `blood_tiles` | `dict[str, {color, alpha}]` | Key is `"x,y"` string; full map, not delta |
| `attack_anim_events` | `list[[from, to, color]]` | Melee swing animations since last tick |
| `blood_events` | `list[dict]` | Blood splat particle sources since last tick |
| `projectiles` | `list[{x, y, char, color}]` | In-flight projectiles |
| `light_sources` | `list[[x, y, radius, intensity, color]]` | All active lights |
| `static_objects` | `list[{x, y, char, fg_color}]` | Torches, mushrooms, etc. |
| `chat_messages` | `list[{text, color}]` | Last 20 chat messages |
| `attack_cooldown_fraction` | `float` | Pre-computed for the **local** player only |
| `gcd_fraction` | `float \| None` | Pre-computed for local player |
| `cast_fraction` | `float \| None` | Pre-computed for local player |
| `ability_cooldowns` | `dict[str, float]` | Per-ability fractions for local player |

**Player-specific fractions**: cooldown/cast/GCD fractions are computed
server-side for the player whose `entity_id` matches the session, and sent
only to that client. Other clients cannot observe each other's cooldown state
(they don't need to).

**Drain semantics**: `attack_anim_events`, `blood_events`, and `static_objects`
are *consumed* by `ClientGame` after each render by calling `.clear()` on the
list. This means they are one-shot events — the UI processes them once and they
are gone. The next tick snapshot will contain any new events. Blood tiles, by
contrast, are the full authoritative state every tick (not a delta), so the
client replaces its local blood map wholesale each frame.

#### `serialize_tick(game, player_entity_id) → dict`

Called by the server **once per tick per connected client**. It:

1. Serializes all entities (players first, then NPCs).
2. Serializes all non-empty blood tiles.
3. **Drains** `game.drain_attack_anim_events()` and `game.drain_blood_events()`.
   These methods consume the queued events on the `Game` object, so after the
   first client is serialized those queues are empty. This means **only the
   first client** in the broadcast loop receives anim/blood events per tick.
   This is a known limitation (see backlog).
4. Snapshots projectiles and light sources.
5. Computes cooldown fractions specifically for `player_entity_id`.

#### `serialize_map(game) → list[list[dict]]`

Serializes the complete tile grid as a 2D list (rows × cols). Sent once in the
`welcome` message. Tiles are static — they never change during a session.

---

### `faraway_realms/net/server.py` — `GameServer`

#### Session lifecycle

Each connected client is tracked by a `_ClientSession`:

```
                       connect
                          │
                     auth message
                          │
              ┌───────────▼──────────┐
              │  _auth_session()     │
              │  - look up username  │
              │  - create/reuse slot │
              └───────────┬──────────┘
                          │  welcome + map tiles
                          │
                    ┌─────▼─────┐
                    │  attached │◄─── tick broadcasts
                    └─────┬─────┘
                          │  disconnect
                    ┌─────▼─────┐
                    │ detached  │◄─── 30 s grace period
                    └─────┬─────┘
                          │  grace expires
                    ┌─────▼─────┐
                    │  reaped   │ (session removed)
                    └───────────┘
```

`_sessions` is a `dict[uuid → _ClientSession]`. The UUID comes from the client
(stored in `~/.faraway_realms/client.uuid`). On reconnect within 30 seconds
the same session slot is reused — the player entity stays in the world.

#### Tick loop

```python
async def _tick_loop(self):
    interval = 1.0 / self._game.tick_rate   # e.g. 0.1 s at 10 Hz
    while True:
        self._game.tick()                    # advance game state
        await self._broadcast_tick()         # serialize and send to all clients
        self._reap_expired_sessions()        # clean up disconnected players
        await asyncio.sleep(interval)
```

`asyncio.sleep` yields to the event loop, allowing incoming command messages to
be processed between ticks. The game state is only mutated inside `tick()` and
the `_recv_loop` (which calls `game.enqueue_command()`). Because both run in
the same asyncio event loop they cannot interleave — this is safe without any
locking.

#### Command reception

Each connected client has a dedicated `_recv_loop` coroutine that reads
messages from the client's TCP stream. When a `command` message arrives:

```python
{"type": "command", "raw": "/move me left"}
```

The raw string is parsed by `CommandParser` and placed on
`game._command_queue`. It will be processed by `game.tick()` on the next tick.

---

### `faraway_realms/net/client.py` — `NetworkClient`

The client runs a full asyncio event loop in a **daemon background thread**.
The main thread (which drives the TCOD render loop) communicates with it only
through the three thread-safe attributes described in the threading section.

#### Connection lifecycle

```
_connect_loop (infinite):
  └─ _run_session:
       1. open TCP connection
       2. send auth {type, uuid, username}
       3. recv welcome {type, entity_id, map_width, map_height, map_tiles}
       4. store welcome in _welcome (under lock)
       5. launch _recv_loop and _send_loop as concurrent tasks
       6. wait for either to finish (means connection dropped)
       7. cancel the other task
       8. close writer
  └─ on OSError/IncompleteReadError: wait backoff seconds, then retry
       backoff: 1s → 2s → 4s → … → capped at 30s, reset to 1s on success
```

#### `_recv_loop`

Reads tick messages in a tight loop. For each `{"type": "tick", ...}` message
it calls `deserialize_snapshot()` and atomically replaces `_snapshot` under the
lock. The main thread will read this new snapshot on its next frame render.

#### `_send_loop`

Runs at 50 Hz (sleeps 20 ms between iterations). Each iteration:

1. Acquires the lock.
2. Swaps `_outbox` with an empty list (grab-and-clear).
3. Releases the lock.
4. Sends each queued raw command string as `{"type": "command", "raw": "..."}`.

The grab-and-clear pattern means the lock is held for the minimum possible
time — only long enough to swap a list reference.

---

### `faraway_realms/client_game.py` — `ClientGame`

`ClientGame` implements `GameProtocol` without any game logic. It is a
**read-only view** of the latest tick snapshot. The UI interacts with it
exactly as it would with `Game`, but every method just reads from
`_client.latest_snapshot()`.

#### `_SnapshotEntity`

The UI renders entities by calling rendering methods that take `GameEntity`
objects. `_SnapshotEntity` is a concrete subclass of the abstract `GameEntity`
dataclass, holding the fields the renderer needs (`char`, `fg_color`,
`target_id`, `display_name`, etc.) populated from snapshot data.

A local cache `_entities_cache: dict[int, _SnapshotEntity]` avoids
reconstructing entity objects every frame. On each access the mutable fields
(`target_id`, `display_name`, status effects) are updated in place; immutable
fields (color, char) are left alone.

#### Lazy sync pattern

Several properties call a `_sync_*` helper before returning their value:

- `game_map` → `_sync_entity_positions()`: clears all entity positions from the
  map and re-places them from the snapshot. The map tile data itself never
  changes.
- `blood_map` → `_sync_blood_map()`: replaces the local `BloodMap._tiles` dict
  wholesale from `snap.blood_tiles`.
- `static_objects` → `_sync_static_objects()`: rebuilds `StaticObject` list from
  snapshot (only when the snapshot contains non-empty static objects).

These are called lazily (on property access) rather than eagerly (on snapshot
arrival) to avoid doing work if the UI never reads that property in a given
frame.

#### Drain methods

`drain_attack_anim_events()` and `drain_blood_events()` consume from the
snapshot's lists by calling `.clear()` after reading. This matches the
behaviour of the real `Game` (which also clears its internal queues on drain)
and ensures the UI only processes each event once.

#### `enqueue_command()`

Instead of placing a command on a local queue, `ClientGame.enqueue_command()`
calls `NetworkClient.send_command()`, which appends the raw command string to
`_outbox`. The network thread will pick it up within 20 ms.

---

### `faraway_realms/game_protocol.py` — `GameProtocol`

A `@runtime_checkable` `Protocol` that lists every method the UI layer needs
from the game object. Both `Game` and `ClientGame` satisfy it structurally
(duck typing — no explicit inheritance required).

The `@runtime_checkable` decorator means `isinstance(game, GameProtocol)` works
at runtime. This is used in `tests/test_game_protocol.py` to assert that
`Game` satisfies the interface.

All UI components (`MapView`, `ChatView`, `StatusBar`, `NameBar`, `AbilityBar`,
`GameUI`) are typed against `GameProtocol` rather than `Game`, so they work
unchanged when handed a `ClientGame`.

---

## Full data flow (single frame, single-player)

```
User presses arrow key
        │
        ▼
GameUI._handle_bound_key()
  └─ parser.parse("/move me left") → Command
  └─ ClientGame.enqueue_command(cmd)
        │
        ▼
NetworkClient.send_command()
  └─ appends "/move me left" to _outbox  (under lock)
        │
        ▼  (within 20 ms, network thread)
NetworkClient._send_loop()
  └─ sends {"type":"command","raw":"/move me left"} over TCP
        │
        ▼  (server receives, in _recv_loop coroutine)
GameServer._handle_command_msg()
  └─ parser.parse("/move me left") → Command
  └─ game.enqueue_command(cmd)
        │
        ▼  (next server tick, ~100 ms at 10 Hz)
Game.tick()
  └─ drains command queue → _dispatch_move() → MovementSystem.handle()
  └─ entity moves on the map
        │
        ▼
GameServer._broadcast_tick()
  └─ serialize_tick(game, player_entity_id)
  └─ send_message(writer, payload)   (4-byte header + JSON over TCP)
        │
        ▼  (client receives, in _recv_loop coroutine)
NetworkClient._recv_loop()
  └─ deserialize_snapshot(msg) → TickSnapshot
  └─ _snapshot = snap  (under lock)
        │
        ▼  (next render frame, ~33 ms at 30 fps, main thread)
GameUI._render_frame()
  └─ ClientGame.game_map → _sync_entity_positions()
        └─ entities placed at new positions
  └─ MapView.render() → draws updated entity positions
```

---

## Known limitations and future work

| Issue | Notes |
|---|---|
| Drain events only reach first client | `drain_attack_anim_events()` and `drain_blood_events()` consume the server queues during serialization of the first client. Subsequent clients in the broadcast loop receive empty lists. Fix: snapshot the events before the broadcast loop, then clear. |
| `static_objects` send every tick with clear | `_sync_static_objects` clears `snap.static_objects` after building the cache, so accessing the property twice in a frame would return an empty list the second time. Static objects never change, so they could be cached once from the welcome message and not sent again. |
| All-or-nothing cooldown fractions | Each tick snapshot carries cooldown fractions for exactly one player entity. In co-op, player B cannot see player A's cooldown bar correctly. Fix: send all player cooldown fractions; let each client pick theirs by entity ID. |
| Projectiles not rendered client-side | `ClientGame.active_projectiles` returns `[]`. The serialization path serializes projectile positions but the client-side rendering for them is not yet wired. |
| No message authentication | The `uuid` in the auth message is read from a local file. Any process that knows a UUID can impersonate that player. Fine for LAN; not for internet play. |
| Chat goes server → client only | `ClientGame.add_chat_message()` is a no-op. Typed chat is sent as a command, echoed server-side. The server adds it to its history and it arrives back on the next tick snapshot. This adds one tick of latency to chat echo. |

---

## Phase 2: Production-Ready Protocol

This section describes the target architecture for the network layer. None of
this is implemented yet. It is written to reason about before building, not as
a retrospective.

The central ideas are:

1. **Three-channel model** — separate concerns by update frequency and
   ownership so the tick stream stays lean.
2. **Visibility culling** — only send state the client can actually perceive.
   This is both a performance and a security requirement.
3. **Version-gated entity deltas** — send full entity data only when something
   changed; otherwise send a position-only stub.
4. **Request-response for UI data** — inventory, character sheets, and anything
   that only matters when a specific panel is open.

---

### The three-channel model

```
┌─────────────────────────────────────────────────────────┐
│  Channel 1: Tick stream          (10 Hz, push)           │
│  Positions, combat fractions, events, status pips,       │
│  new chat lines, projectiles, dynamic light sources      │
│  — visibility-culled per client —                        │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│  Channel 2: Delta push           (on change, push)       │
│  Full entity data when version advances,                 │
│  static object mutations, tile changes,                  │
│  map tile reveals (exploration fog-of-war)               │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│  Channel 3: Request-response     (on demand, pull)       │
│  Character sheet stats, inventory, ability metadata,     │
│  chat scrollback beyond the ring buffer                  │
└─────────────────────────────────────────────────────────┘
```

All three channels ride the same TCP connection and the same 4-byte-framed
JSON wire format. They are logical channels distinguished by `"type"`.

---

### Channel 1: The tick stream

The tick stream carries only what needs to refresh at game speed. The guiding
question: *would a one-tick-stale value visibly break the game?* If yes, it
belongs here. If not, it belongs in a delta push or request-response.

**Stays in the tick stream:**

| Data | Reason |
|---|---|
| Entity positions (x, y, char) | Changes every move tick |
| Combat fractions (attack CD, cast, GCD) | Changes continuously |
| Status effect names + expiry | Drives status bar pips |
| Attack animation events | One-shot; must arrive this frame |
| Blood splat events | One-shot; must arrive this frame |
| In-flight projectile positions | Changes every tick |
| New chat lines (delta only) | Player expects near-instant echo |
| Dynamic light sources | Projectiles, ability effects move each tick |

**Removed from tick stream:**

| Data | Where instead | Reason |
|---|---|---|
| Full stat dict (STR, CON, ARM…) | Channel 2 (version-gated) | Changes only on level-up or equip |
| Ability names list | Welcome + Channel 2 on change | Static today; will be invalidated when equip/talent exists |
| Blood tile full map | Channel 2 (dirty tiles only) | Resending the whole map every tick was a placeholder |
| Static objects | Welcome + Channel 2 on change | Not truly immutable; torches can be destroyed |
| Static light source positions | Welcome + Channel 2 on change | Only move if the object moves |
| Last-20 chat window | Channel 3 (scrollback resource) | Only new lines needed in the tick stream |

**Revised tick message structure:**

```python
{
    "type": "tick",
    "seq": 12345,               # monotonic tick counter; used for ack/delta gating

    # Visibility-culled entity list (see Channel 2 for full/stub split)
    "entities": [
        # Full snapshot — sent when entity first enters FOV or version advanced
        {"entity_id": 3, "full": True, "version": 7,
         "x": 10, "y": 5, "char": "Z", "fg_color": [180, 0, 0],
         "display_name": "Zombie", "stats": {...}, "status_effects": [...], ...},

        # Position stub — sent every tick for visible, unchanged entities
        {"entity_id": 3, "full": False,
         "x": 10, "y": 5, "attack_cd": 0.6, "cast_fraction": None},

        # Removal signal — entity just left this client's FOV
        {"entity_id": 9, "remove": True},
    ],

    # One-shot events (drain-on-read; visibility-culled)
    "attack_anim_events": [...],
    "blood_events":        [...],
    "projectiles":         [...],

    # New chat lines since session.last_chat_seq (not the full window)
    "chat_lines": [{"seq": 201, "text": "...", "color": [...]}],

    # Dynamic lights only (static lights live in welcome / Channel 2)
    "dynamic_light_sources": [[x, y, radius, intensity, color], ...],

    # Per-client combat fractions (unchanged from current design)
    "attack_cooldown_fraction": 0.4,
    "gcd_fraction": None,
    "cast_fraction": None,
    "ability_cooldowns": {"kick": 0.0, "firebolt": 0.7},
    "target_entity_id": 3,
    "target_attack_fraction": 0.9,
}
```

---

### Channel 2: Visibility culling and entity deltas

This is the most significant change from the current design, and addresses both
**bandwidth** and **security**.

#### Why broadcasting everything is wrong

Currently `serialize_shared()` builds a single entity list containing all
players and all NPCs, then sends it to every connected client unchanged. A
client therefore learns:

- The positions of NPCs on the other side of the map it has never seen.
- Map tiles it has never explored.
- Which rooms other players are in.

This is a **maphack vulnerability**: a modified client can render all entity
positions regardless of FOV, giving the player full omniscient map awareness
without any cheating on the server. The fix is server-side: never send
information the client hasn't earned by moving there.

#### Explored vs visible — two distinct states

```
unexplored          explored, not visible    visible (current FOV)
──────────────────  ───────────────────────  ──────────────────────
nothing sent ever   tile colours dimmed,     full rendering;
                    no entities shown,        entities sent this tick
                    blood/objects visible
```

The server is authoritative on both states per client (needed for reconnection
and anti-cheat). The client mirrors them locally for rendering.

- **Map tiles** are sent once the first time a tile enters the player's FOV
  (`tile_reveal` delta). Never re-sent unless the tile itself changes.
- **Entities** are sent only while they are in the current tick's FOV. When
  an entity leaves FOV the client receives a `remove` signal and drops the
  cached object. The entity may as well not exist from the client's perspective.
- **Blood tiles** are filtered to explored positions only.
- **Static objects** are sent once when their tile is first explored, then
  updated via delta push on mutation.

#### Per-client visibility pass (pseudo-code)

```python
# Replaces serialize_shared() + serialize_per_client() merge.
# Called once per tick per connected session.

def build_tick_payload(game, session, shared_events):
    """
    session carries:
      entity_id           : int
      last_sent_version   : dict[entity_id → int]
      explored_tiles      : set[tuple[int,int]]
      last_chat_seq       : int
    shared_events is pre-snapshotted before the broadcast loop (attack anims,
    blood events, etc.) so all clients receive the same one-shot events.
    """

    player_pos   = game.map.get_entity_position(session.entity_id)
    visible_tiles = compute_fov(game.map, player_pos, radius=FOV_RADIUS)

    # --- Entity updates ---
    entity_updates = []
    for entity_id, entity in game.entities.items():
        pos = game.map.get_entity_position(entity_id)
        if pos not in visible_tiles:
            if entity_id in session.last_sent_version:
                entity_updates.append({"entity_id": entity_id, "remove": True})
                del session.last_sent_version[entity_id]
            continue  # not visible; don't reveal existence

        last_ver = session.last_sent_version.get(entity_id, -1)
        if entity.version != last_ver:
            # Full snapshot: first sight or something changed
            entity_updates.append(serialize_entity_full(game, entity))
            session.last_sent_version[entity_id] = entity.version
        else:
            # Stub: position + combat fractions only
            entity_updates.append(serialize_entity_stub(game, entity))

    # --- Map tile reveals ---
    newly_explored = visible_tiles - session.explored_tiles
    session.explored_tiles |= visible_tiles
    tile_reveals = [serialize_tile(game.map, x, y) for (x, y) in newly_explored]

    # --- Blood tiles: explored positions only ---
    dirty_blood = {
        key: val
        for key, val in shared_events["dirty_blood"].items()
        if _parse_pos(key) in session.explored_tiles
    }

    # --- Chat delta ---
    new_chat = [m for m in game.chat_history if m.seq > session.last_chat_seq]
    if new_chat:
        session.last_chat_seq = new_chat[-1].seq

    return {
        "type": "tick",
        "seq": game.abs_tick,
        "entities": entity_updates,
        "tile_reveals": tile_reveals,
        "blood_tiles": dirty_blood,
        "attack_anim_events": [
            ev for ev in shared_events["attack_anims"]
            if ev["from_pos"] in visible_tiles or ev["to_pos"] in visible_tiles
        ],
        "blood_events": [
            ev for ev in shared_events["blood_events"]
            if ev["target_pos"] in visible_tiles
        ],
        "projectiles": [
            p for p in game.active_projectiles if (p.x, p.y) in visible_tiles
        ],
        "dynamic_light_sources": [
            ls for ls in game.dynamic_light_sources()
            if ls.pos in visible_tiles
        ],
        "chat_lines": [serialize_chat(m) for m in new_chat],
        **serialize_per_client_fractions(game, session.entity_id),
    }
```

#### Performance: per-client pass vs shared serialization

The current design serializes entities once and broadcasts the same payload to
all clients. Per-client culling serializes a different list per client.

| | Current | With culling |
|---|---|---|
| Entity serializations per tick | `E` (once for all) | `N × M` (N clients, M visible each) |
| Bytes sent per client per tick | `E × ~200 B` | `M × ~200 B + (E−M) × ~20 B stub` |

For typical values (8 clients, 50 total entities, 15 visible per client):

| Metric | Current | With culling |
|---|---|---|
| Serializations/tick | 50 | ~120 (+140% CPU) |
| Bytes/tick/client | ~10 KB | ~3.4 KB (−66%) |
| Total bytes/tick all clients | ~80 KB | ~27 KB (−66%) |

The CPU increase is mitigated by **entity serialization caching**:

```python
# Keyed by entity_id; rebuilt only when entity.version advances
_entity_full_cache: dict[int, tuple[int, dict]] = {}
#                                 ↑ version  ↑ serialized dict

def serialize_entity_full(game, entity):
    cached_ver, cached_dict = _entity_full_cache.get(entity.id, (-1, None))
    if entity.version == cached_ver:
        return cached_dict          # reuse; no re-serialization
    result = _build_entity_dict(game, entity)
    _entity_full_cache[entity.id] = (entity.version, result)
    return result
```

With the cache, re-serialization happens only when `entity.version` advances —
which is rare (stat damage, status change) rather than every tick. The
per-client pass becomes O(M) dict lookups + O(M) list construction, not O(M)
full serializations.

#### What increments entity.version

```python
# entity.version increments on any observable state change:
#   stats current values change (HP/mana damage or regen)
#   status_effects list changes (effect added, removed, or expired)
#   target_id changes
#   abilities dict changes (future: equip / talent changes)
#   fg_color or char changes (future: transformation abilities)
#
# Does NOT increment:
#   position (x, y) — sent unconditionally in the stub
#   combat fractions — pre-computed server-side, not stored on entity
```

---

### Channel 3: Request-response for UI data

Some data is only relevant when a specific UI panel is open. Pushing it every
tick wastes bandwidth and clutters the tick stream with low-frequency data.

#### New message types

```python
# Client → server: open the inventory panel
{"type": "request", "id": "req_001", "resource": "inventory", "entity_id": 1}

# Client → server: open the character sheet
{"type": "request", "id": "req_002", "resource": "character_sheet",
 "entity_id": 1}

# Client → server: scroll back in chat history
{"type": "request", "id": "req_003", "resource": "chat_history",
 "from_seq": 0, "count": 100}

# Server → client: response
{"type": "response", "id": "req_001", "resource": "inventory",
 "data": {"items": [...]}}

# Server → client: proactive invalidation (server-initiated)
# Sent when the resource changes and this client has previously fetched it.
# Client re-requests on receipt.
{"type": "invalidate", "resource": "inventory", "entity_id": 1}
```

#### Resource catalogue

| Resource | Content | Invalidated when |
|---|---|---|
| `"character_sheet"` | Base stats (STR, CON, ARM…), full ability list with descriptions, equipment slots | Level-up, equip change, stat bonus change |
| `"inventory"` | Item list with positions, quantities, descriptions | Any item added, removed, or moved |
| `"ability_details"` | Full ability definitions (cooldown, range, description, effects) | Never during a session (data, not state) |
| `"chat_history"` | Full scrollback from `from_seq` | Never; history is append-only |
| `"entity_inspect"` | Lore, full stat sheet of any entity the player examines | Entity death or significant state change |

#### Server-side invalidation tracking (pseudo-code)

```python
# Added to _ClientSession:
session.requested_resources: dict[str, set[int]]
# resource_name → set of entity_ids this client has fetched
# e.g. {"character_sheet": {1}, "inventory": {1}}

# Called by game logic when a resource changes:
def push_invalidations(game_server, resource, entity_id):
    for session in game_server.sessions.values():
        if entity_id in session.requested_resources.get(resource, set()):
            session.outbox.append({
                "type": "invalidate",
                "resource": resource,
                "entity_id": entity_id,
            })
    # Client re-fetches when it receives the invalidate message.
    # Server does not need to track whether the re-fetch happened.
```

#### ClientGame integration (pseudo-code)

```python
class ClientGame:
    _snapshot: TickSnapshot | None      # tick stream (existing)
    _resource_cache: dict[str, Any]     # keyed by "resource/entity_id"

    def request_resource(self, resource: str, **kwargs) -> None:
        """Send a request; UI polls get_cached_resource() each frame."""
        self._client.send_request({"type": "request", "resource": resource,
                                   **kwargs})

    def get_cached_resource(self, resource: str, entity_id: int = 0) -> Any | None:
        return self._resource_cache.get(f"{resource}/{entity_id}")

    # Called by NetworkClient when a response/invalidate arrives (under lock):
    def _on_response(self, msg: dict) -> None:
        key = f"{msg['resource']}/{msg.get('entity_id', 0)}"
        self._resource_cache[key] = msg["data"]

    def _on_invalidate(self, msg: dict) -> None:
        key = f"{msg['resource']}/{msg.get('entity_id', 0)}"
        self._resource_cache.pop(key, None)
        # UI panels detect None on next frame poll and re-request
```

---

### Static objects, light sources, and map tiles: the invalidation model

These were previously treated as fully static (sent once in welcome, never
updated). That assumption will break:

- Torches can be extinguished or destroyed.
- Harvestable objects (glowing mushrooms) can be removed.
- Map tiles can change (cave-ins, destructible walls, door states).
- A light source attached to a static object changes when the object does.

The correct model: **send on welcome for the explored area, then delta-push
changes as they happen**.

```python
# Server maintains a dirty tracker, drained once per broadcast loop:
class WorldDirtyTracker:
    _dirty_static_objects: dict[int, StaticObject | None]
    # object_id → new state, or None if destroyed

    _dirty_tiles: dict[tuple[int, int], Tile]
    # (x, y) → new tile state

    def mark_static_object_changed(self, obj_id, new_state_or_none): ...
    def mark_tile_changed(self, x, y, new_tile): ...

    def drain(self):
        result = (dict(self._dirty_static_objects), dict(self._dirty_tiles))
        self._dirty_static_objects.clear()
        self._dirty_tiles.clear()
        return result
```

During the per-client broadcast the dirty drain is filtered by
`session.explored_tiles` before sending — a client that hasn't seen a corridor
doesn't learn that its torch was destroyed. The client applies these deltas to
its local world cache.

Static light sources travel with their parent static object: when the object
changes or is destroyed, the light source update is bundled in the same delta.
Dynamic lights (projectiles, active abilities) remain in the tick stream since
they change position every tick.

---

### Welcome message with the new model

```python
{
    "type": "welcome",
    "entity_id": 1,
    "map_width": 100,
    "map_height": 60,

    # Explored tiles from a previous session.
    # New character: empty. Returning character: full prior exploration.
    # Format: [[x, y, {tile_data}], ...]
    "explored_tiles": [...],

    # Static objects in the explored area only.
    # Each carries a stable "id" used to match future delta pushes.
    "static_objects": [
        {"id": 5, "x": 10, "y": 3, "char": "T", "fg_color": [...],
         "light_source": {"radius": 7, "intensity": 0.9, "color": [...]}}
    ],

    # Blood tiles in explored area (persistent stains from last session)
    "blood_tiles": {"10,3": {"color": [...], "alpha": 80}},

    # Full ability metadata (static during a session; never re-sent in ticks)
    "ability_registry": {
        "kick": {"abbreviation": "KI", "cooldown": 300, "cast_time": 0,
                 "range_tiles": 1, "description": "..."},
    },
}
```

---

### Migration path

Three independent phases. The wire protocol is additive — old fields remain
until the new paths are stable and the old ones can be removed.

**Phase A — Quick wins, no schema break:**
- Drain events fix: snapshot `attack_anim_events` and `blood_events` before the
  broadcast loop so all clients receive the same one-shot events.
- Chat delta: add `seq` to `ChatMessage`; server sends only messages where
  `seq > session.last_chat_seq`. Remove the "last-20 resend" from the shared
  payload.
- Static objects: remove from tick stream entirely; they are already sent in
  the welcome message.

**Phase B — Entity version counters + per-client culling:**
- Add `version: int` to `GameEntity`; increment in any mutating method.
- Add `_entity_full_cache` in `serialization.py`.
- Move entity serialization fully into per-client path; add `remove` signal.
- Add `explored_tiles` and `last_sent_version` to `_ClientSession`.
- `serialize_shared()` becomes `snapshot_shared_events()` (only one-shot
  events); the entity list moves to the per-client function.
- Add `tile_reveal` deltas on welcome + per tick.
- Add `WorldDirtyTracker` for static objects and tiles.

**Phase C — Request-response channel:**
- Add `"request"` / `"response"` / `"invalidate"` message types.
- `NetworkClient._recv_loop` routes these to `ClientGame._on_response` /
  `_on_invalidate`.
- `GameServer._dispatch_client_msg` gains a `"request"` branch that calls
  resource-specific handlers.
- UI panels call `ClientGame.request_resource()` on open; poll
  `get_cached_resource()` each frame until non-None.
- Remove full stat dict and ability list from `EntitySnapshot`; these fields
  are now only available via the `"character_sheet"` resource.
