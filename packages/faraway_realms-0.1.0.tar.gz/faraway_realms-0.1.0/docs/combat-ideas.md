  Low effort, high feel:
  - Armor/damage reduction — armor Stat, damage = max(1, strength - armor). Trivially fits the existing Stat system, visible immediately in the status bars.
  - Critical hits — crit_chance Stat (0–100), roll on each attack; double damage + yellow ScreenFlash instead of red. CombatResult already carries damage dealt, just needs a crit: bool flag.
  - Lifesteal — lifesteal Stat (% of damage healed). After a hit lands, attacker.health.modify(+N). A green flash on the attacker would sell it visually.

  Medium effort, changes the rhythm:
  - Stagger — being hit temporarily doubles the target's effective attack_every. Visible as the cooldown bar draining slower. Fits as a timed bonus on the entity.
  - Opportunity attack refine — currently fires when you move away; could also fire when you try to move through an adjacent enemy (makes positioning matter more).
  - Knockback — a hit with high strength pushes the target 1 tile away. Needs a wall/occupied check but no new system.

  Higher effort, new dimension:
  - Bleed (DoT) — a hit applies a "bleeding" status that ticks damage each game tick for N ticks. Needs a lightweight status-effect system, but the tick loop is already there.
  - Wound thresholds — when health drops below 50%/25%, the entity gets a penalty (reduced attack speed, slower movement). No new system, just checks in existing stats.
