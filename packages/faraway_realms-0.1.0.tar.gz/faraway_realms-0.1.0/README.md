# Faraway Realms

A real-time tick-based roguelike RPG built with [tcod](https://python-tcod.readthedocs.io/).

## Install & run

```bash
uv tool install faraway-realms
faraway-realms
```

## Multiplayer

```bash
# Server (headless)
faraway-realms --serve 0.0.0.0:9999 --headless

# Client on another machine
faraway-realms --connect HOST:9999
```
