"""Unified tileset viewer — browse all CP437 + Urizen sprites interactively.

Controls
--------
Arrow keys          : move cursor one sprite
Page Up / Page Down : jump one full screen
Home / End          : first / last sprite
c                   : jump to CP437 section (index 0)
u                   : jump to Urizen section (index 256)
Mouse hover / click : highlight sprite under pointer
Mouse wheel         : scroll
q / Escape          : quit

The status bar shows the codepoint, decimal value, and the ready-to-paste
game-code snippet for the highlighted sprite.

Run with::

    uv run python tools/show_tileset.py
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

import tcod.console
import tcod.context
import tcod.event
import tcod.tileset

_TILESET_PATH = (
    Path(__file__).parent.parent / "faraway_realms" / "assets" / "unified_12x12.png"
)

# ── grid layout ───────────────────────────────────────────────────────────────
# Tiles are rendered at 2× scale (24 px/tile) for readability on HiDPI displays.
# Target window ≈ 1440 × 960 px (comfortable on a 1512 × 982 display).
_TILE_PX: int = 12  # source tile size in the tilesheet
_SCALE: int = 2  # display scale factor

COLS: int = 10  # sprites per row (reduced to fit 2× tiles on screen)
CELL_W: int = 6  # 1 sprite tile + 1 gap col + 4-char hex label
CELL_H: int = 2  # sprite row + hex-label row
STATUS_ROWS: int = 2  # fixed info rows pinned to the bottom
VISIBLE_ROWS: int = 19  # sprite rows on screen at once  (19 × 2 = 38 tile rows)

CONSOLE_W: int = COLS * CELL_W  # 60  →  1440 px at 2×
CONSOLE_H: int = VISIBLE_ROWS * CELL_H + STATUS_ROWS  # 40  →   960 px at 2×

# ── sprite catalogue ──────────────────────────────────────────────────────────
_SHEET_COLS: int = 16
N_CP437: int = 256
N_URIZEN: int = 10_300
N_TOTAL: int = N_CP437 + N_URIZEN  # 10 556 sprites
URIZEN_BASE: int = 0xE000

_CHARMAP: list[int] = list(tcod.tileset.CHARMAP_CP437) + list(
    range(URIZEN_BASE, URIZEN_BASE + N_URIZEN)
)
_SHEET_ROWS: int = 16 + (N_URIZEN + _SHEET_COLS - 1) // _SHEET_COLS
_N_SPRITE_ROWS: int = (N_TOTAL + COLS - 1) // COLS
_MAX_SCROLL: int = max(0, _N_SPRITE_ROWS - VISIBLE_ROWS)

# ── colours ───────────────────────────────────────────────────────────────────
_FG = (230, 230, 230)
_HEX_DIM = (90, 130, 50)
_CURSOR_FG = (255, 220, 0)
_CURSOR_BG = (50, 50, 0)
_STATUS_FG = (200, 200, 110)
_STATUS_BG = (20, 20, 40)
_HINT_FG = (80, 80, 80)
_BLACK = (0, 0, 0)

# ── types ─────────────────────────────────────────────────────────────────────
_Dispatch = dict[tcod.event.KeySym, Callable[[], None]]
_MOUSE_TYPES = (
    tcod.event.MouseMotion,
    tcod.event.MouseButtonDown,
    tcod.event.MouseWheel,
)


# ── state ─────────────────────────────────────────────────────────────────────


@dataclass
class _State:
    cursor: int = 0
    scroll_row: int = 0

    def scroll_to_cursor(self) -> None:
        row = self.cursor // COLS
        if row < self.scroll_row:
            self.scroll_row = row
        elif row >= self.scroll_row + VISIBLE_ROWS:
            self.scroll_row = row - VISIBLE_ROWS + 1
        self.scroll_row = max(0, min(self.scroll_row, _MAX_SCROLL))

    def move_cursor(self, delta: int) -> None:
        self.cursor = max(0, min(N_TOTAL - 1, self.cursor + delta))
        self.scroll_to_cursor()

    def jump(self, idx: int) -> None:
        self.cursor = max(0, min(N_TOTAL - 1, idx))
        self.scroll_to_cursor()

    def hover(self, tile_x: int, tile_y: int) -> bool:
        if tile_y >= CONSOLE_H - STATUS_ROWS:
            return False
        idx = (self.scroll_row + tile_y // CELL_H) * COLS + tile_x // CELL_W
        if 0 <= idx < N_TOTAL and idx != self.cursor:
            self.cursor = idx
            return True
        return False

    def scroll(self, delta: int) -> bool:
        old = self.scroll_row
        self.scroll_row = max(0, min(self.scroll_row + delta, _MAX_SCROLL))
        return self.scroll_row != old


# ── rendering ─────────────────────────────────────────────────────────────────


def _render_cell(
    console: tcod.console.Console,
    cx: int,
    cy: int,
    sprite_idx: int,
    is_cursor: bool,
) -> None:
    cp = _CHARMAP[sprite_idx]
    console.rgb[cy, cx]["ch"] = cp
    console.rgb[cy, cx]["fg"] = _CURSOR_FG if is_cursor else _FG
    console.rgb[cy, cx]["bg"] = _CURSOR_BG if is_cursor else _BLACK
    console.print(
        cx + 1,
        cy + 1,
        f"{cp:04X}",
        fg=_CURSOR_FG if is_cursor else _HEX_DIM,
    )


def _render_sprite_row(
    console: tcod.console.Console,
    sprite_row: int,
    vis_row: int,
    cursor: int,
) -> None:
    cy = vis_row * CELL_H
    for col in range(COLS):
        idx = sprite_row * COLS + col
        if idx >= N_TOTAL:
            break
        _render_cell(console, col * CELL_W, cy, idx, idx == cursor)


def _status_lines(cursor: int) -> tuple[str, str]:
    cp = _CHARMAP[cursor]
    if cursor < N_CP437:
        detail = f"CP437 slot {cursor:3d}  |  U+{cp:04X} ({cp})  |  ch = {cursor}"
    else:
        n = cursor - N_CP437
        detail = f"Urizen #{n:<5d}  |  U+{cp:04X} ({cp})  |  URIZEN_BASE + {n}"
    hint = (
        f"  {cursor + 1}/{N_TOTAL}"
        "  [←↑→↓ move  PgUp/Dn page  c=CP437  u=Urizen  q=quit]"
    )
    return detail, hint


def _render_status(console: tcod.console.Console, state: _State) -> None:
    sy = CONSOLE_H - STATUS_ROWS
    for x in range(CONSOLE_W):
        console.rgb[sy, x]["bg"] = _STATUS_BG
        console.rgb[sy + 1, x]["bg"] = _STATUS_BG
    detail, hint = _status_lines(state.cursor)
    console.print(0, sy, detail[:CONSOLE_W], fg=_STATUS_FG)
    console.print(0, sy + 1, hint[:CONSOLE_W], fg=_HINT_FG)


def _render(console: tcod.console.Console, state: _State) -> None:
    console.clear()
    for vis_row in range(VISIBLE_ROWS):
        sprite_row = state.scroll_row + vis_row
        if sprite_row >= _N_SPRITE_ROWS:
            break
        _render_sprite_row(console, sprite_row, vis_row, state.cursor)
    _render_status(console, state)


# ── event handling ────────────────────────────────────────────────────────────


def _make_dispatch(state: _State) -> _Dispatch:
    page = COLS * VISIBLE_ROWS
    return {
        tcod.event.KeySym.UP: lambda: state.move_cursor(-COLS),
        tcod.event.KeySym.DOWN: lambda: state.move_cursor(COLS),
        tcod.event.KeySym.LEFT: lambda: state.move_cursor(-1),
        tcod.event.KeySym.RIGHT: lambda: state.move_cursor(1),
        tcod.event.KeySym.PAGEUP: lambda: state.move_cursor(-page),
        tcod.event.KeySym.PAGEDOWN: lambda: state.move_cursor(page),
        tcod.event.KeySym.HOME: lambda: state.jump(0),
        tcod.event.KeySym.END: lambda: state.jump(N_TOTAL - 1),
        tcod.event.KeySym(ord("c")): lambda: state.jump(0),
        tcod.event.KeySym(ord("u")): lambda: state.jump(N_CP437),
    }


def _on_key(
    event: tcod.event.KeyDown,
    state: _State,
    dispatch: _Dispatch,
) -> bool | None:
    sym = event.sym
    if sym in (tcod.event.KeySym.ESCAPE, tcod.event.KeySym(ord("q"))):
        return False
    action = dispatch.get(sym)
    if action is not None:
        action()
        return True
    return None


def _on_mouse(event: tcod.event.Event, state: _State) -> bool:
    if isinstance(event, tcod.event.MouseWheel):
        return state.scroll(-event.y * 3)
    if isinstance(event, (tcod.event.MouseMotion, tcod.event.MouseButtonDown)):
        return state.hover(event.tile.x, event.tile.y)
    return False


def _on_event(
    event: tcod.event.Event,
    state: _State,
    dispatch: _Dispatch,
) -> bool | None:
    if isinstance(event, tcod.event.Quit):
        return False
    if isinstance(event, tcod.event.KeyDown):
        return _on_key(event, state, dispatch)
    if isinstance(event, _MOUSE_TYPES):
        return _on_mouse(event, state) or None
    return None


def _drain_events(state: _State, dispatch: _Dispatch) -> bool | None:
    dirty = False
    for event in tcod.event.wait():
        result = _on_event(event, state, dispatch)
        if result is False:
            return False
        dirty = dirty or bool(result)
    return dirty or None


def _loop(
    ctx: tcod.context.Context,
    console: tcod.console.Console,
    state: _State,
    dispatch: _Dispatch,
) -> None:
    while True:
        result = _drain_events(state, dispatch)
        if result is False:
            return
        if result:
            _render(console, state)
            ctx.present(console)


def main() -> None:
    """Launch the interactive unified tileset viewer."""
    if not _TILESET_PATH.exists():
        msg = (
            f"Tileset not found: {_TILESET_PATH}\n"
            "Run: uv run python tools/build_tileset.py"
        )
        raise FileNotFoundError(msg)
    tileset = tcod.tileset.load_tilesheet(
        _TILESET_PATH, _SHEET_COLS, _SHEET_ROWS, _CHARMAP
    )
    console = tcod.console.Console(CONSOLE_W, CONSOLE_H, order="C")
    state = _State()
    dispatch = _make_dispatch(state)
    with tcod.context.new(
        console=console,
        tileset=tileset,
        title="Tileset viewer — unified_12x12",
        width=CONSOLE_W * _TILE_PX * _SCALE,
        height=CONSOLE_H * _TILE_PX * _SCALE,
    ) as ctx:
        _render(console, state)
        ctx.present(console)
        _loop(ctx, console, state, dispatch)


if __name__ == "__main__":
    main()
