#!/usr/bin/env python3
"""Build a unified 12×12 tilesheet: CP437 base on top, Urizen sprites below.

Output
------
faraway_realms/assets/unified_12x12.png
    RGBA image, 192px wide (16 tiles × 12px).
    Rows  0–15 : 256 CP437 glyphs (same layout as terminal12x12_gs_ro.png).
    Rows 16+   : 10 300 Urizen sprites packed 16 per row, white-on-transparent.

Charmap
-------
Positions 0–255    → tcod.tileset.CHARMAP_CP437   (standard CP437 Unicode mapping)
Positions 256+     → U+E000, U+E001, …            (Unicode Private Use Area)

Usage in game
-------------
    import tcod.tileset
    URIZEN_BASE = 0xE000
    N_URIZEN    = 10_300
    charmap = (list(tcod.tileset.CHARMAP_CP437)
               + list(range(URIZEN_BASE, URIZEN_BASE + N_URIZEN)))
    tileset = tcod.tileset.load_tilesheet(
        "unified_12x12.png", 16, 16 + N_URIZEN // 16 + 1, charmap)

    # Render the 42nd Urizen sprite at console position (x=5, y=3):
    console.tiles["ch"][3, 5] = URIZEN_BASE + 42
    console.tiles["fg"][3, 5] = (255, 200, 50, 255)   # tinted gold

Run
---
    uv run python tools/build_tileset.py
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
from PIL import Image

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

_ROOT = Path(__file__).parent.parent
_ASSETS = _ROOT / "faraway_realms" / "assets"

BASE_PATH = _ASSETS / "terminal12x12_gs_ro.png"
URIZEN_PATH = _ASSETS / "urizen_onebit_tileset__v2d0.png"
OUT_PATH = _ASSETS / "unified_12x12.png"

# ---------------------------------------------------------------------------
# Layout constants
# ---------------------------------------------------------------------------

TILE = 12  # tile size in pixels (both sheets)
COLS = 16  # tiles per row in the combined output

# Urizen sheet: 1px transparent gap before every tile (including the left/top
# edges).  Each tile therefore starts at offset 1 within a 13px stride.
_URIZEN_GAP = 1
_URIZEN_STRIDE = TILE + _URIZEN_GAP  # 13

# ---------------------------------------------------------------------------
# Conversion helpers
# ---------------------------------------------------------------------------


def _cp437_to_rgba(img: Image.Image) -> np.ndarray:
    """Convert the greyscale-on-black CP437 sheet (RGB) to RGBA.

    Black pixels are the background (transparent in tcod's model).  Any
    non-black pixel is foreground and gets alpha=255.
    """
    arr = np.array(img.convert("RGB"), dtype=np.uint8)
    rgba = np.zeros((*arr.shape[:2], 4), dtype=np.uint8)
    rgba[..., :3] = arr
    is_black = (arr[..., 0] == 0) & (arr[..., 1] == 0) & (arr[..., 2] == 0)
    rgba[..., 3] = np.where(is_black, 0, 255).astype(np.uint8)
    return rgba


def _to_bw_rgba(tile: np.ndarray) -> np.ndarray:
    """Convert a 1-bit Urizen tile to pure white-on-transparent for tcod.

    Urizen tiles are fully opaque two-colour: black (0,0,0) is the background
    and the non-black colour is the foreground sprite pixel.  There is no alpha
    transparency inside tile areas — only the inter-tile gap pixels have alpha=0.

    Conversion: black → transparent (0,0,0,0); non-black → white (255,255,255,255).
    This matches the CP437 greyscale-on-black convention and lets fg_color tint
    the sprite without attenuation.
    """
    is_black = (tile[..., 0] == 0) & (tile[..., 1] == 0) & (tile[..., 2] == 0)
    result = np.zeros_like(tile)
    result[~is_black] = (255, 255, 255, 255)
    return result


# ---------------------------------------------------------------------------
# Urizen extraction
# ---------------------------------------------------------------------------


def _extract_urizen(img: Image.Image) -> list[np.ndarray]:
    """Return every 12×12 tile from the Urizen sheet as a list of RGBA arrays.

    The sheet has a 1px fully-transparent gap before each tile column and row
    (including the outer edges), so tiles start at (x=1, y=1) with stride 13.

    Order: row-major (left→right, top→bottom), matching tcod's tilesheet read
    order so sprite_index = row * cols_per_urizen_row + col.
    """
    arr = np.array(img)
    h, w = arr.shape[:2]
    tiles: list[np.ndarray] = []
    y = _URIZEN_GAP
    while y + TILE <= h:
        x = _URIZEN_GAP
        while x + TILE <= w:
            tiles.append(arr[y : y + TILE, x : x + TILE].copy())
            x += _URIZEN_STRIDE
        y += _URIZEN_STRIDE
    return tiles


# ---------------------------------------------------------------------------
# Assembly
# ---------------------------------------------------------------------------


def _build_combined(
    base_rgba: np.ndarray, urizen_tiles: list[np.ndarray]
) -> np.ndarray:
    """Composite base (top) and Urizen sprites (bottom) into one RGBA array."""
    base_h, base_w = base_rgba.shape[:2]
    n = len(urizen_tiles)
    n_rows = (n + COLS - 1) // COLS

    combined = np.zeros((base_h + n_rows * TILE, base_w, 4), dtype=np.uint8)
    combined[:base_h, :base_w] = base_rgba

    for i, tile in enumerate(urizen_tiles):
        row, col = divmod(i, COLS)
        y = base_h + row * TILE
        x = col * TILE
        combined[y : y + TILE, x : x + TILE] = _to_bw_rgba(tile)

    return combined


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    """Build and save the unified tilesheet."""
    base = Image.open(BASE_PATH)
    urizen = Image.open(URIZEN_PATH)

    base_rgba = _cp437_to_rgba(base)

    urizen_tiles = _extract_urizen(urizen)
    n = len(urizen_tiles)
    n_rows = (n + COLS - 1) // COLS
    print(f"Extracted {n} Urizen tiles ({n // 206} source rows × 206 cols)")

    combined_arr = _build_combined(base_rgba, urizen_tiles)
    h, w = combined_arr.shape[:2]

    Image.fromarray(combined_arr, "RGBA").save(OUT_PATH)
    print(f"Saved: {OUT_PATH}  ({w}×{h}px)")
    print("  CP437 tiles  : 256  (codepoints via CHARMAP_CP437)")
    print(f"  Urizen tiles : {n}  (codepoints U+E000 – U+{0xE000 + n - 1:04X})")
    print()
    print("Load in game:")
    print("  charmap = list(tcod.tileset.CHARMAP_CP437)")
    print(f"          + list(range(0xE000, 0xE000 + {n}))")
    print(f"  tcod.tileset.load_tilesheet(path, {COLS}, {16 + n_rows}, charmap)")


if __name__ == "__main__":
    main()
