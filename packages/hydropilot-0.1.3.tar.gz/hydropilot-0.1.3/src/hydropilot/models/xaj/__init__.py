"""XAJ model template support."""
