# Generated from grammar/FhY.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,69,381,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,1,0,1,0,1,1,1,1,1,1,1,1,
        1,1,1,1,1,1,1,1,3,1,73,8,1,1,2,5,2,76,8,2,10,2,12,2,79,9,2,1,3,1,
        3,1,3,1,3,1,4,1,4,1,4,1,5,1,5,1,5,1,5,1,5,1,6,1,6,1,6,1,6,1,6,1,
        6,3,6,99,8,6,1,6,1,6,1,6,1,6,3,6,105,8,6,1,6,1,6,1,6,1,6,1,6,3,6,
        112,8,6,1,7,1,7,1,7,5,7,117,8,7,10,7,12,7,120,9,7,3,7,122,8,7,1,
        8,1,8,1,8,5,8,127,8,8,10,8,12,8,130,9,8,3,8,132,8,8,1,9,1,9,3,9,
        136,8,9,1,10,1,10,1,11,1,11,1,11,1,11,3,11,144,8,11,1,11,1,11,1,
        12,1,12,1,12,3,12,151,8,12,1,12,1,12,1,12,1,13,1,13,1,13,1,13,1,
        13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,3,13,168,8,13,1,14,1,14,1,
        14,1,14,1,14,1,14,1,14,1,14,1,15,1,15,1,15,1,15,1,16,3,16,183,8,
        16,1,16,1,16,1,17,1,17,1,17,3,17,190,8,17,1,18,1,18,1,18,1,18,1,
        18,1,18,1,18,1,18,4,18,200,8,18,11,18,12,18,201,1,18,3,18,205,8,
        18,3,18,207,8,18,1,18,1,18,1,19,1,19,1,19,1,19,1,19,3,19,216,8,19,
        1,20,1,20,1,20,1,20,1,20,3,20,223,8,20,1,21,1,21,1,21,5,21,228,8,
        21,10,21,12,21,231,9,21,1,21,3,21,234,8,21,3,21,236,8,21,1,22,1,
        22,1,22,1,22,1,22,1,23,1,23,1,23,1,23,1,23,3,23,248,8,23,1,24,1,
        24,1,24,1,24,1,24,1,24,1,24,1,24,3,24,258,8,24,1,24,1,24,1,24,1,
        24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,
        24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,
        24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,5,24,299,8,24,10,
        24,12,24,302,9,24,1,25,1,25,1,25,5,25,307,8,25,10,25,12,25,310,9,
        25,3,25,312,8,25,1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,
        26,3,26,324,8,26,1,26,1,26,1,26,1,26,3,26,330,8,26,1,26,1,26,1,26,
        1,26,1,26,1,26,1,26,1,26,1,26,5,26,341,8,26,10,26,12,26,344,9,26,
        1,27,1,27,1,27,3,27,349,8,27,1,28,1,28,1,28,1,28,1,28,1,28,1,28,
        1,28,1,28,4,28,360,8,28,11,28,12,28,361,1,28,3,28,365,8,28,1,28,
        1,28,3,28,369,8,28,1,29,1,29,1,29,5,29,374,8,29,10,29,12,29,377,
        9,29,1,30,1,30,1,30,0,2,48,52,31,0,2,4,6,8,10,12,14,16,18,20,22,
        24,26,28,30,32,34,36,38,40,42,44,46,48,50,52,54,56,58,60,0,7,2,0,
        28,29,36,36,1,0,31,34,1,0,35,36,1,0,37,38,1,0,39,42,1,0,43,44,1,
        0,51,53,408,0,62,1,0,0,0,2,72,1,0,0,0,4,77,1,0,0,0,6,80,1,0,0,0,
        8,84,1,0,0,0,10,87,1,0,0,0,12,92,1,0,0,0,14,121,1,0,0,0,16,131,1,
        0,0,0,18,133,1,0,0,0,20,137,1,0,0,0,22,139,1,0,0,0,24,150,1,0,0,
        0,26,155,1,0,0,0,28,169,1,0,0,0,30,177,1,0,0,0,32,182,1,0,0,0,34,
        189,1,0,0,0,36,191,1,0,0,0,38,210,1,0,0,0,40,217,1,0,0,0,42,235,
        1,0,0,0,44,237,1,0,0,0,46,242,1,0,0,0,48,257,1,0,0,0,50,311,1,0,
        0,0,52,313,1,0,0,0,54,348,1,0,0,0,56,368,1,0,0,0,58,370,1,0,0,0,
        60,378,1,0,0,0,62,63,3,4,2,0,63,1,1,0,0,0,64,73,3,6,3,0,65,73,3,
        8,4,0,66,73,3,10,5,0,67,73,3,22,11,0,68,73,3,24,12,0,69,73,3,26,
        13,0,70,73,3,28,14,0,71,73,3,30,15,0,72,64,1,0,0,0,72,65,1,0,0,0,
        72,66,1,0,0,0,72,67,1,0,0,0,72,68,1,0,0,0,72,69,1,0,0,0,72,70,1,
        0,0,0,72,71,1,0,0,0,73,3,1,0,0,0,74,76,3,2,1,0,75,74,1,0,0,0,76,
        79,1,0,0,0,77,75,1,0,0,0,77,78,1,0,0,0,78,5,1,0,0,0,79,77,1,0,0,
        0,80,81,5,1,0,0,81,82,3,58,29,0,82,83,5,26,0,0,83,7,1,0,0,0,84,85,
        3,12,6,0,85,86,5,26,0,0,86,9,1,0,0,0,87,88,3,12,6,0,88,89,5,19,0,
        0,89,90,3,20,10,0,90,91,5,20,0,0,91,11,1,0,0,0,92,93,5,6,0,0,93,
        98,5,50,0,0,94,95,5,40,0,0,95,96,3,14,7,0,96,97,5,39,0,0,97,99,1,
        0,0,0,98,94,1,0,0,0,98,99,1,0,0,0,99,104,1,0,0,0,100,101,5,17,0,
        0,101,102,3,16,8,0,102,103,5,18,0,0,103,105,1,0,0,0,104,100,1,0,
        0,0,104,105,1,0,0,0,105,106,1,0,0,0,106,107,5,15,0,0,107,108,3,16,
        8,0,108,111,5,16,0,0,109,110,5,21,0,0,110,112,3,32,16,0,111,109,
        1,0,0,0,111,112,1,0,0,0,112,13,1,0,0,0,113,118,5,50,0,0,114,115,
        5,24,0,0,115,117,5,50,0,0,116,114,1,0,0,0,117,120,1,0,0,0,118,116,
        1,0,0,0,118,119,1,0,0,0,119,122,1,0,0,0,120,118,1,0,0,0,121,113,
        1,0,0,0,121,122,1,0,0,0,122,15,1,0,0,0,123,128,3,18,9,0,124,125,
        5,24,0,0,125,127,3,18,9,0,126,124,1,0,0,0,127,130,1,0,0,0,128,126,
        1,0,0,0,128,129,1,0,0,0,129,132,1,0,0,0,130,128,1,0,0,0,131,123,
        1,0,0,0,131,132,1,0,0,0,132,17,1,0,0,0,133,135,3,32,16,0,134,136,
        5,50,0,0,135,134,1,0,0,0,135,136,1,0,0,0,136,19,1,0,0,0,137,138,
        3,4,2,0,138,21,1,0,0,0,139,140,3,32,16,0,140,143,5,50,0,0,141,142,
        5,22,0,0,142,144,3,48,24,0,143,141,1,0,0,0,143,144,1,0,0,0,144,145,
        1,0,0,0,145,146,5,26,0,0,146,23,1,0,0,0,147,148,3,52,26,0,148,149,
        5,22,0,0,149,151,1,0,0,0,150,147,1,0,0,0,150,151,1,0,0,0,151,152,
        1,0,0,0,152,153,3,48,24,0,153,154,5,26,0,0,154,25,1,0,0,0,155,156,
        5,12,0,0,156,157,5,15,0,0,157,158,3,48,24,0,158,159,5,16,0,0,159,
        160,5,19,0,0,160,161,3,4,2,0,161,167,5,20,0,0,162,163,5,13,0,0,163,
        164,5,19,0,0,164,165,3,4,2,0,165,166,5,20,0,0,166,168,1,0,0,0,167,
        162,1,0,0,0,167,168,1,0,0,0,168,27,1,0,0,0,169,170,5,11,0,0,170,
        171,5,15,0,0,171,172,3,48,24,0,172,173,5,16,0,0,173,174,5,19,0,0,
        174,175,3,4,2,0,175,176,5,20,0,0,176,29,1,0,0,0,177,178,5,14,0,0,
        178,179,3,48,24,0,179,180,5,26,0,0,180,31,1,0,0,0,181,183,5,50,0,
        0,182,181,1,0,0,0,182,183,1,0,0,0,183,184,1,0,0,0,184,185,3,34,17,
        0,185,33,1,0,0,0,186,190,3,36,18,0,187,190,3,38,19,0,188,190,3,44,
        22,0,189,186,1,0,0,0,189,187,1,0,0,0,189,188,1,0,0,0,190,35,1,0,
        0,0,191,192,5,4,0,0,192,206,5,17,0,0,193,194,3,34,17,0,194,195,5,
        24,0,0,195,207,1,0,0,0,196,199,3,34,17,0,197,198,5,24,0,0,198,200,
        3,34,17,0,199,197,1,0,0,0,200,201,1,0,0,0,201,199,1,0,0,0,201,202,
        1,0,0,0,202,204,1,0,0,0,203,205,5,24,0,0,204,203,1,0,0,0,204,205,
        1,0,0,0,205,207,1,0,0,0,206,193,1,0,0,0,206,196,1,0,0,0,206,207,
        1,0,0,0,207,208,1,0,0,0,208,209,5,18,0,0,209,37,1,0,0,0,210,215,
        3,40,20,0,211,212,5,17,0,0,212,213,3,50,25,0,213,214,5,18,0,0,214,
        216,1,0,0,0,215,211,1,0,0,0,215,216,1,0,0,0,216,39,1,0,0,0,217,222,
        5,50,0,0,218,219,5,40,0,0,219,220,3,50,25,0,220,221,5,39,0,0,221,
        223,1,0,0,0,222,218,1,0,0,0,222,223,1,0,0,0,223,41,1,0,0,0,224,229,
        3,40,20,0,225,226,5,24,0,0,226,228,3,40,20,0,227,225,1,0,0,0,228,
        231,1,0,0,0,229,227,1,0,0,0,229,230,1,0,0,0,230,233,1,0,0,0,231,
        229,1,0,0,0,232,234,5,24,0,0,233,232,1,0,0,0,233,234,1,0,0,0,234,
        236,1,0,0,0,235,224,1,0,0,0,235,236,1,0,0,0,236,43,1,0,0,0,237,238,
        5,5,0,0,238,239,5,17,0,0,239,240,3,46,23,0,240,241,5,18,0,0,241,
        45,1,0,0,0,242,243,3,48,24,0,243,244,5,27,0,0,244,247,3,48,24,0,
        245,246,5,27,0,0,246,248,3,48,24,0,247,245,1,0,0,0,247,248,1,0,0,
        0,248,47,1,0,0,0,249,250,6,24,-1,0,250,251,5,15,0,0,251,252,3,48,
        24,0,252,253,5,16,0,0,253,258,1,0,0,0,254,255,7,0,0,0,255,258,3,
        48,24,14,256,258,3,52,26,0,257,249,1,0,0,0,257,254,1,0,0,0,257,256,
        1,0,0,0,258,300,1,0,0,0,259,260,10,13,0,0,260,261,5,30,0,0,261,299,
        3,48,24,14,262,263,10,12,0,0,263,264,7,1,0,0,264,299,3,48,24,13,
        265,266,10,11,0,0,266,267,7,2,0,0,267,299,3,48,24,12,268,269,10,
        10,0,0,269,270,7,3,0,0,270,299,3,48,24,11,271,272,10,9,0,0,272,273,
        7,4,0,0,273,299,3,48,24,10,274,275,10,8,0,0,275,276,7,5,0,0,276,
        299,3,48,24,9,277,278,10,7,0,0,278,279,5,45,0,0,279,299,3,48,24,
        8,280,281,10,6,0,0,281,282,5,46,0,0,282,299,3,48,24,7,283,284,10,
        5,0,0,284,285,5,47,0,0,285,299,3,48,24,6,286,287,10,4,0,0,287,288,
        5,48,0,0,288,299,3,48,24,5,289,290,10,3,0,0,290,291,5,49,0,0,291,
        299,3,48,24,4,292,293,10,2,0,0,293,294,5,23,0,0,294,295,3,48,24,
        0,295,296,5,27,0,0,296,297,3,48,24,3,297,299,1,0,0,0,298,259,1,0,
        0,0,298,262,1,0,0,0,298,265,1,0,0,0,298,268,1,0,0,0,298,271,1,0,
        0,0,298,274,1,0,0,0,298,277,1,0,0,0,298,280,1,0,0,0,298,283,1,0,
        0,0,298,286,1,0,0,0,298,289,1,0,0,0,298,292,1,0,0,0,299,302,1,0,
        0,0,300,298,1,0,0,0,300,301,1,0,0,0,301,49,1,0,0,0,302,300,1,0,0,
        0,303,308,3,48,24,0,304,305,5,24,0,0,305,307,3,48,24,0,306,304,1,
        0,0,0,307,310,1,0,0,0,308,306,1,0,0,0,308,309,1,0,0,0,309,312,1,
        0,0,0,310,308,1,0,0,0,311,303,1,0,0,0,311,312,1,0,0,0,312,51,1,0,
        0,0,313,314,6,26,-1,0,314,315,3,54,27,0,315,342,1,0,0,0,316,317,
        10,4,0,0,317,341,5,52,0,0,318,323,10,3,0,0,319,320,5,40,0,0,320,
        321,3,42,21,0,321,322,5,39,0,0,322,324,1,0,0,0,323,319,1,0,0,0,323,
        324,1,0,0,0,324,329,1,0,0,0,325,326,5,17,0,0,326,327,3,50,25,0,327,
        328,5,18,0,0,328,330,1,0,0,0,329,325,1,0,0,0,329,330,1,0,0,0,330,
        331,1,0,0,0,331,332,5,15,0,0,332,333,3,50,25,0,333,334,5,16,0,0,
        334,341,1,0,0,0,335,336,10,2,0,0,336,337,5,17,0,0,337,338,3,50,25,
        0,338,339,5,18,0,0,339,341,1,0,0,0,340,316,1,0,0,0,340,318,1,0,0,
        0,340,335,1,0,0,0,341,344,1,0,0,0,342,340,1,0,0,0,342,343,1,0,0,
        0,343,53,1,0,0,0,344,342,1,0,0,0,345,349,3,56,28,0,346,349,3,58,
        29,0,347,349,3,60,30,0,348,345,1,0,0,0,348,346,1,0,0,0,348,347,1,
        0,0,0,349,55,1,0,0,0,350,351,5,15,0,0,351,352,3,48,24,0,352,353,
        5,24,0,0,353,354,5,16,0,0,354,369,1,0,0,0,355,356,5,15,0,0,356,359,
        3,48,24,0,357,358,5,24,0,0,358,360,3,48,24,0,359,357,1,0,0,0,360,
        361,1,0,0,0,361,359,1,0,0,0,361,362,1,0,0,0,362,364,1,0,0,0,363,
        365,5,24,0,0,364,363,1,0,0,0,364,365,1,0,0,0,365,366,1,0,0,0,366,
        367,5,16,0,0,367,369,1,0,0,0,368,350,1,0,0,0,368,355,1,0,0,0,369,
        57,1,0,0,0,370,375,5,50,0,0,371,372,5,25,0,0,372,374,5,50,0,0,373,
        371,1,0,0,0,374,377,1,0,0,0,375,373,1,0,0,0,375,376,1,0,0,0,376,
        59,1,0,0,0,377,375,1,0,0,0,378,379,7,6,0,0,379,61,1,0,0,0,38,72,
        77,98,104,111,118,121,128,131,135,143,150,167,182,189,201,204,206,
        215,222,229,233,235,247,257,298,300,308,311,323,329,340,342,348,
        361,364,368,375
    ]

class FhYParser ( Parser ):

    grammarFileName = "FhY.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'import'", "'from'", "'as'", "'tuple'", 
                     "'index'", "<INVALID>", "'proc'", "'op'", "'reduc'", 
                     "'native'", "'forall'", "'if'", "'else'", "'return'", 
                     "'('", "')'", "'['", "']'", "'{'", "'}'", "'->'", "'='", 
                     "'?'", "','", "'.'", "';'", "':'", "'!'", "'~'", "'**'", 
                     "'*'", "'/'", "'//'", "'%'", "'+'", "'-'", "'<<'", 
                     "'>>'", "'>'", "'<'", "'>='", "'<='", "'=='", "'!='", 
                     "'&'", "'^'", "'|'", "'&&'", "'||'" ]

    symbolicNames = [ "<INVALID>", "IMPORT", "FROM", "AS", "TUPLE", "INDEX", 
                      "FUNCTION_KEYWORD", "PROCEDURE", "OPERATION", "REDUCTION", 
                      "NATIVE", "FORALL", "IF", "ELSE", "RETURN", "OPEN_PARENTHESES", 
                      "CLOSE_PARENTHESES", "OPEN_BRACKET", "CLOSE_BRACKET", 
                      "OPEN_BRACE", "CLOSE_BRACE", "ARROW", "EQUALS_SIGN", 
                      "QUESTION_MARK", "COMMA", "DOT", "SEMICOLON", "COLON", 
                      "LOGICAL_NOT", "BITWISE_NOT", "POWER", "MULTIPLICATION", 
                      "DIVISION", "FLOORDIV", "MODULO", "ADDITION", "SUBTRACTION", 
                      "LEFT_SHIFT", "RIGHT_SHIFT", "GREATER_THAN", "LESS_THAN", 
                      "GREATER_THAN_OR_EQUAL", "LESS_THAN_OR_EQUAL", "EQUAL_TO", 
                      "NOT_EQUAL_TO", "AND", "EXCLUSIVE_OR", "OR", "LOGICAL_AND", 
                      "LOGICAL_OR", "IDENTIFIER", "INT_LITERAL", "FLOAT_LITERAL", 
                      "COMPLEX_LITERAL", "FRACTION_PART", "NONDIGIT", "BINARY_INT_LITERAL", 
                      "OCTAL_INT_LITERAL", "DECIMAL_INT_LITERAL", "HEXADECIMAL_INT_LITERAL", 
                      "EXPONENT_PART", "DIGIT_SEQUENCE", "SIGN", "BIN_DIGIT", 
                      "OCT_DIGIT", "DEC_DIGIT", "HEX_DIGIT", "WHITESPACE", 
                      "NEWLINE", "LINECOMMENT" ]

    RULE_module = 0
    RULE_statement = 1
    RULE_scope = 2
    RULE_import_statement = 3
    RULE_function_declaration = 4
    RULE_function_definition = 5
    RULE_function_header = 6
    RULE_identifier_list = 7
    RULE_function_args = 8
    RULE_function_arg = 9
    RULE_function_body = 10
    RULE_declaration_statement = 11
    RULE_expression_statement = 12
    RULE_selection_statement = 13
    RULE_iteration_statement = 14
    RULE_return_statement = 15
    RULE_qualified_type = 16
    RULE_type = 17
    RULE_tuple_type = 18
    RULE_numerical_type = 19
    RULE_dtype = 20
    RULE_dtype_list = 21
    RULE_index_type = 22
    RULE_range = 23
    RULE_expression = 24
    RULE_expression_list = 25
    RULE_primitive_expression = 26
    RULE_atom = 27
    RULE_tuple = 28
    RULE_identifier_expression = 29
    RULE_literal = 30

    ruleNames =  [ "module", "statement", "scope", "import_statement", "function_declaration", 
                   "function_definition", "function_header", "identifier_list", 
                   "function_args", "function_arg", "function_body", "declaration_statement", 
                   "expression_statement", "selection_statement", "iteration_statement", 
                   "return_statement", "qualified_type", "type", "tuple_type", 
                   "numerical_type", "dtype", "dtype_list", "index_type", 
                   "range", "expression", "expression_list", "primitive_expression", 
                   "atom", "tuple", "identifier_expression", "literal" ]

    EOF = Token.EOF
    IMPORT=1
    FROM=2
    AS=3
    TUPLE=4
    INDEX=5
    FUNCTION_KEYWORD=6
    PROCEDURE=7
    OPERATION=8
    REDUCTION=9
    NATIVE=10
    FORALL=11
    IF=12
    ELSE=13
    RETURN=14
    OPEN_PARENTHESES=15
    CLOSE_PARENTHESES=16
    OPEN_BRACKET=17
    CLOSE_BRACKET=18
    OPEN_BRACE=19
    CLOSE_BRACE=20
    ARROW=21
    EQUALS_SIGN=22
    QUESTION_MARK=23
    COMMA=24
    DOT=25
    SEMICOLON=26
    COLON=27
    LOGICAL_NOT=28
    BITWISE_NOT=29
    POWER=30
    MULTIPLICATION=31
    DIVISION=32
    FLOORDIV=33
    MODULO=34
    ADDITION=35
    SUBTRACTION=36
    LEFT_SHIFT=37
    RIGHT_SHIFT=38
    GREATER_THAN=39
    LESS_THAN=40
    GREATER_THAN_OR_EQUAL=41
    LESS_THAN_OR_EQUAL=42
    EQUAL_TO=43
    NOT_EQUAL_TO=44
    AND=45
    EXCLUSIVE_OR=46
    OR=47
    LOGICAL_AND=48
    LOGICAL_OR=49
    IDENTIFIER=50
    INT_LITERAL=51
    FLOAT_LITERAL=52
    COMPLEX_LITERAL=53
    FRACTION_PART=54
    NONDIGIT=55
    BINARY_INT_LITERAL=56
    OCTAL_INT_LITERAL=57
    DECIMAL_INT_LITERAL=58
    HEXADECIMAL_INT_LITERAL=59
    EXPONENT_PART=60
    DIGIT_SEQUENCE=61
    SIGN=62
    BIN_DIGIT=63
    OCT_DIGIT=64
    DEC_DIGIT=65
    HEX_DIGIT=66
    WHITESPACE=67
    NEWLINE=68
    LINECOMMENT=69

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ModuleContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def scope(self):
            return self.getTypedRuleContext(FhYParser.ScopeContext,0)


        def getRuleIndex(self):
            return FhYParser.RULE_module

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterModule" ):
                listener.enterModule(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitModule" ):
                listener.exitModule(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitModule" ):
                return visitor.visitModule(self)
            else:
                return visitor.visitChildren(self)




    def module(self):

        localctx = FhYParser.ModuleContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_module)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 62
            self.scope()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def import_statement(self):
            return self.getTypedRuleContext(FhYParser.Import_statementContext,0)


        def function_declaration(self):
            return self.getTypedRuleContext(FhYParser.Function_declarationContext,0)


        def function_definition(self):
            return self.getTypedRuleContext(FhYParser.Function_definitionContext,0)


        def declaration_statement(self):
            return self.getTypedRuleContext(FhYParser.Declaration_statementContext,0)


        def expression_statement(self):
            return self.getTypedRuleContext(FhYParser.Expression_statementContext,0)


        def selection_statement(self):
            return self.getTypedRuleContext(FhYParser.Selection_statementContext,0)


        def iteration_statement(self):
            return self.getTypedRuleContext(FhYParser.Iteration_statementContext,0)


        def return_statement(self):
            return self.getTypedRuleContext(FhYParser.Return_statementContext,0)


        def getRuleIndex(self):
            return FhYParser.RULE_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStatement" ):
                listener.enterStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStatement" ):
                listener.exitStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStatement" ):
                return visitor.visitStatement(self)
            else:
                return visitor.visitChildren(self)




    def statement(self):

        localctx = FhYParser.StatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_statement)
        try:
            self.state = 72
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,0,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 64
                self.import_statement()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 65
                self.function_declaration()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 66
                self.function_definition()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 67
                self.declaration_statement()
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 68
                self.expression_statement()
                pass

            elif la_ == 6:
                self.enterOuterAlt(localctx, 6)
                self.state = 69
                self.selection_statement()
                pass

            elif la_ == 7:
                self.enterOuterAlt(localctx, 7)
                self.state = 70
                self.iteration_statement()
                pass

            elif la_ == 8:
                self.enterOuterAlt(localctx, 8)
                self.state = 71
                self.return_statement()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ScopeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(FhYParser.StatementContext)
            else:
                return self.getTypedRuleContext(FhYParser.StatementContext,i)


        def getRuleIndex(self):
            return FhYParser.RULE_scope

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterScope" ):
                listener.enterScope(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitScope" ):
                listener.exitScope(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitScope" ):
                return visitor.visitScope(self)
            else:
                return visitor.visitChildren(self)




    def scope(self):

        localctx = FhYParser.ScopeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_scope)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 77
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 16888568127477874) != 0):
                self.state = 74
                self.statement()
                self.state = 79
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Import_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IMPORT(self):
            return self.getToken(FhYParser.IMPORT, 0)

        def identifier_expression(self):
            return self.getTypedRuleContext(FhYParser.Identifier_expressionContext,0)


        def SEMICOLON(self):
            return self.getToken(FhYParser.SEMICOLON, 0)

        def getRuleIndex(self):
            return FhYParser.RULE_import_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterImport_statement" ):
                listener.enterImport_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitImport_statement" ):
                listener.exitImport_statement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitImport_statement" ):
                return visitor.visitImport_statement(self)
            else:
                return visitor.visitChildren(self)




    def import_statement(self):

        localctx = FhYParser.Import_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_import_statement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 80
            self.match(FhYParser.IMPORT)
            self.state = 81
            self.identifier_expression()
            self.state = 82
            self.match(FhYParser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Function_declarationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def function_header(self):
            return self.getTypedRuleContext(FhYParser.Function_headerContext,0)


        def SEMICOLON(self):
            return self.getToken(FhYParser.SEMICOLON, 0)

        def getRuleIndex(self):
            return FhYParser.RULE_function_declaration

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunction_declaration" ):
                listener.enterFunction_declaration(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunction_declaration" ):
                listener.exitFunction_declaration(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFunction_declaration" ):
                return visitor.visitFunction_declaration(self)
            else:
                return visitor.visitChildren(self)




    def function_declaration(self):

        localctx = FhYParser.Function_declarationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_function_declaration)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 84
            self.function_header()
            self.state = 85
            self.match(FhYParser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Function_definitionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def function_header(self):
            return self.getTypedRuleContext(FhYParser.Function_headerContext,0)


        def OPEN_BRACE(self):
            return self.getToken(FhYParser.OPEN_BRACE, 0)

        def function_body(self):
            return self.getTypedRuleContext(FhYParser.Function_bodyContext,0)


        def CLOSE_BRACE(self):
            return self.getToken(FhYParser.CLOSE_BRACE, 0)

        def getRuleIndex(self):
            return FhYParser.RULE_function_definition

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunction_definition" ):
                listener.enterFunction_definition(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunction_definition" ):
                listener.exitFunction_definition(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFunction_definition" ):
                return visitor.visitFunction_definition(self)
            else:
                return visitor.visitChildren(self)




    def function_definition(self):

        localctx = FhYParser.Function_definitionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_function_definition)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 87
            self.function_header()
            self.state = 88
            self.match(FhYParser.OPEN_BRACE)
            self.state = 89
            self.function_body()
            self.state = 90
            self.match(FhYParser.CLOSE_BRACE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Function_headerContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.function_type = None # Token
            self.name = None # Token
            self.function_template_types = None # Identifier_listContext
            self.function_indices = None # Function_argsContext
            self.return_type = None # Qualified_typeContext

        def OPEN_PARENTHESES(self):
            return self.getToken(FhYParser.OPEN_PARENTHESES, 0)

        def function_args(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(FhYParser.Function_argsContext)
            else:
                return self.getTypedRuleContext(FhYParser.Function_argsContext,i)


        def CLOSE_PARENTHESES(self):
            return self.getToken(FhYParser.CLOSE_PARENTHESES, 0)

        def FUNCTION_KEYWORD(self):
            return self.getToken(FhYParser.FUNCTION_KEYWORD, 0)

        def IDENTIFIER(self):
            return self.getToken(FhYParser.IDENTIFIER, 0)

        def LESS_THAN(self):
            return self.getToken(FhYParser.LESS_THAN, 0)

        def GREATER_THAN(self):
            return self.getToken(FhYParser.GREATER_THAN, 0)

        def OPEN_BRACKET(self):
            return self.getToken(FhYParser.OPEN_BRACKET, 0)

        def CLOSE_BRACKET(self):
            return self.getToken(FhYParser.CLOSE_BRACKET, 0)

        def ARROW(self):
            return self.getToken(FhYParser.ARROW, 0)

        def identifier_list(self):
            return self.getTypedRuleContext(FhYParser.Identifier_listContext,0)


        def qualified_type(self):
            return self.getTypedRuleContext(FhYParser.Qualified_typeContext,0)


        def getRuleIndex(self):
            return FhYParser.RULE_function_header

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunction_header" ):
                listener.enterFunction_header(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunction_header" ):
                listener.exitFunction_header(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFunction_header" ):
                return visitor.visitFunction_header(self)
            else:
                return visitor.visitChildren(self)




    def function_header(self):

        localctx = FhYParser.Function_headerContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_function_header)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 92
            localctx.function_type = self.match(FhYParser.FUNCTION_KEYWORD)
            self.state = 93
            localctx.name = self.match(FhYParser.IDENTIFIER)
            self.state = 98
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==40:
                self.state = 94
                self.match(FhYParser.LESS_THAN)
                self.state = 95
                localctx.function_template_types = self.identifier_list()
                self.state = 96
                self.match(FhYParser.GREATER_THAN)


            self.state = 104
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==17:
                self.state = 100
                self.match(FhYParser.OPEN_BRACKET)
                self.state = 101
                localctx.function_indices = self.function_args()
                self.state = 102
                self.match(FhYParser.CLOSE_BRACKET)


            self.state = 106
            self.match(FhYParser.OPEN_PARENTHESES)
            self.state = 107
            self.function_args()
            self.state = 108
            self.match(FhYParser.CLOSE_PARENTHESES)
            self.state = 111
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==21:
                self.state = 109
                self.match(FhYParser.ARROW)
                self.state = 110
                localctx.return_type = self.qualified_type()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Identifier_listContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self, i:int=None):
            if i is None:
                return self.getTokens(FhYParser.IDENTIFIER)
            else:
                return self.getToken(FhYParser.IDENTIFIER, i)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(FhYParser.COMMA)
            else:
                return self.getToken(FhYParser.COMMA, i)

        def getRuleIndex(self):
            return FhYParser.RULE_identifier_list

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIdentifier_list" ):
                listener.enterIdentifier_list(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIdentifier_list" ):
                listener.exitIdentifier_list(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIdentifier_list" ):
                return visitor.visitIdentifier_list(self)
            else:
                return visitor.visitChildren(self)




    def identifier_list(self):

        localctx = FhYParser.Identifier_listContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_identifier_list)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 121
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==50:
                self.state = 113
                self.match(FhYParser.IDENTIFIER)
                self.state = 118
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==24:
                    self.state = 114
                    self.match(FhYParser.COMMA)
                    self.state = 115
                    self.match(FhYParser.IDENTIFIER)
                    self.state = 120
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Function_argsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def function_arg(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(FhYParser.Function_argContext)
            else:
                return self.getTypedRuleContext(FhYParser.Function_argContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(FhYParser.COMMA)
            else:
                return self.getToken(FhYParser.COMMA, i)

        def getRuleIndex(self):
            return FhYParser.RULE_function_args

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunction_args" ):
                listener.enterFunction_args(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunction_args" ):
                listener.exitFunction_args(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFunction_args" ):
                return visitor.visitFunction_args(self)
            else:
                return visitor.visitChildren(self)




    def function_args(self):

        localctx = FhYParser.Function_argsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_function_args)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 131
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 1125899906842672) != 0):
                self.state = 123
                self.function_arg()
                self.state = 128
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==24:
                    self.state = 124
                    self.match(FhYParser.COMMA)
                    self.state = 125
                    self.function_arg()
                    self.state = 130
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Function_argContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.name = None # Token

        def qualified_type(self):
            return self.getTypedRuleContext(FhYParser.Qualified_typeContext,0)


        def IDENTIFIER(self):
            return self.getToken(FhYParser.IDENTIFIER, 0)

        def getRuleIndex(self):
            return FhYParser.RULE_function_arg

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunction_arg" ):
                listener.enterFunction_arg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunction_arg" ):
                listener.exitFunction_arg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFunction_arg" ):
                return visitor.visitFunction_arg(self)
            else:
                return visitor.visitChildren(self)




    def function_arg(self):

        localctx = FhYParser.Function_argContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_function_arg)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 133
            self.qualified_type()
            self.state = 135
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==50:
                self.state = 134
                localctx.name = self.match(FhYParser.IDENTIFIER)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Function_bodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def scope(self):
            return self.getTypedRuleContext(FhYParser.ScopeContext,0)


        def getRuleIndex(self):
            return FhYParser.RULE_function_body

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunction_body" ):
                listener.enterFunction_body(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunction_body" ):
                listener.exitFunction_body(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFunction_body" ):
                return visitor.visitFunction_body(self)
            else:
                return visitor.visitChildren(self)




    def function_body(self):

        localctx = FhYParser.Function_bodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_function_body)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 137
            self.scope()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Declaration_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.name = None # Token

        def qualified_type(self):
            return self.getTypedRuleContext(FhYParser.Qualified_typeContext,0)


        def SEMICOLON(self):
            return self.getToken(FhYParser.SEMICOLON, 0)

        def IDENTIFIER(self):
            return self.getToken(FhYParser.IDENTIFIER, 0)

        def EQUALS_SIGN(self):
            return self.getToken(FhYParser.EQUALS_SIGN, 0)

        def expression(self):
            return self.getTypedRuleContext(FhYParser.ExpressionContext,0)


        def getRuleIndex(self):
            return FhYParser.RULE_declaration_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDeclaration_statement" ):
                listener.enterDeclaration_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDeclaration_statement" ):
                listener.exitDeclaration_statement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDeclaration_statement" ):
                return visitor.visitDeclaration_statement(self)
            else:
                return visitor.visitChildren(self)




    def declaration_statement(self):

        localctx = FhYParser.Declaration_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_declaration_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 139
            self.qualified_type()
            self.state = 140
            localctx.name = self.match(FhYParser.IDENTIFIER)
            self.state = 143
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==22:
                self.state = 141
                self.match(FhYParser.EQUALS_SIGN)
                self.state = 142
                self.expression(0)


            self.state = 145
            self.match(FhYParser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Expression_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self):
            return self.getTypedRuleContext(FhYParser.ExpressionContext,0)


        def SEMICOLON(self):
            return self.getToken(FhYParser.SEMICOLON, 0)

        def primitive_expression(self):
            return self.getTypedRuleContext(FhYParser.Primitive_expressionContext,0)


        def EQUALS_SIGN(self):
            return self.getToken(FhYParser.EQUALS_SIGN, 0)

        def getRuleIndex(self):
            return FhYParser.RULE_expression_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpression_statement" ):
                listener.enterExpression_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpression_statement" ):
                listener.exitExpression_statement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpression_statement" ):
                return visitor.visitExpression_statement(self)
            else:
                return visitor.visitChildren(self)




    def expression_statement(self):

        localctx = FhYParser.Expression_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_expression_statement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 150
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,11,self._ctx)
            if la_ == 1:
                self.state = 147
                self.primitive_expression(0)
                self.state = 148
                self.match(FhYParser.EQUALS_SIGN)


            self.state = 152
            self.expression(0)
            self.state = 153
            self.match(FhYParser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Selection_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IF(self):
            return self.getToken(FhYParser.IF, 0)

        def OPEN_PARENTHESES(self):
            return self.getToken(FhYParser.OPEN_PARENTHESES, 0)

        def expression(self):
            return self.getTypedRuleContext(FhYParser.ExpressionContext,0)


        def CLOSE_PARENTHESES(self):
            return self.getToken(FhYParser.CLOSE_PARENTHESES, 0)

        def OPEN_BRACE(self, i:int=None):
            if i is None:
                return self.getTokens(FhYParser.OPEN_BRACE)
            else:
                return self.getToken(FhYParser.OPEN_BRACE, i)

        def scope(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(FhYParser.ScopeContext)
            else:
                return self.getTypedRuleContext(FhYParser.ScopeContext,i)


        def CLOSE_BRACE(self, i:int=None):
            if i is None:
                return self.getTokens(FhYParser.CLOSE_BRACE)
            else:
                return self.getToken(FhYParser.CLOSE_BRACE, i)

        def ELSE(self):
            return self.getToken(FhYParser.ELSE, 0)

        def getRuleIndex(self):
            return FhYParser.RULE_selection_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSelection_statement" ):
                listener.enterSelection_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSelection_statement" ):
                listener.exitSelection_statement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSelection_statement" ):
                return visitor.visitSelection_statement(self)
            else:
                return visitor.visitChildren(self)




    def selection_statement(self):

        localctx = FhYParser.Selection_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_selection_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 155
            self.match(FhYParser.IF)
            self.state = 156
            self.match(FhYParser.OPEN_PARENTHESES)
            self.state = 157
            self.expression(0)
            self.state = 158
            self.match(FhYParser.CLOSE_PARENTHESES)
            self.state = 159
            self.match(FhYParser.OPEN_BRACE)
            self.state = 160
            self.scope()
            self.state = 161
            self.match(FhYParser.CLOSE_BRACE)
            self.state = 167
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==13:
                self.state = 162
                self.match(FhYParser.ELSE)
                self.state = 163
                self.match(FhYParser.OPEN_BRACE)
                self.state = 164
                self.scope()
                self.state = 165
                self.match(FhYParser.CLOSE_BRACE)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Iteration_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FORALL(self):
            return self.getToken(FhYParser.FORALL, 0)

        def OPEN_PARENTHESES(self):
            return self.getToken(FhYParser.OPEN_PARENTHESES, 0)

        def expression(self):
            return self.getTypedRuleContext(FhYParser.ExpressionContext,0)


        def CLOSE_PARENTHESES(self):
            return self.getToken(FhYParser.CLOSE_PARENTHESES, 0)

        def OPEN_BRACE(self):
            return self.getToken(FhYParser.OPEN_BRACE, 0)

        def scope(self):
            return self.getTypedRuleContext(FhYParser.ScopeContext,0)


        def CLOSE_BRACE(self):
            return self.getToken(FhYParser.CLOSE_BRACE, 0)

        def getRuleIndex(self):
            return FhYParser.RULE_iteration_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIteration_statement" ):
                listener.enterIteration_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIteration_statement" ):
                listener.exitIteration_statement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIteration_statement" ):
                return visitor.visitIteration_statement(self)
            else:
                return visitor.visitChildren(self)




    def iteration_statement(self):

        localctx = FhYParser.Iteration_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_iteration_statement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 169
            self.match(FhYParser.FORALL)
            self.state = 170
            self.match(FhYParser.OPEN_PARENTHESES)
            self.state = 171
            self.expression(0)
            self.state = 172
            self.match(FhYParser.CLOSE_PARENTHESES)
            self.state = 173
            self.match(FhYParser.OPEN_BRACE)
            self.state = 174
            self.scope()
            self.state = 175
            self.match(FhYParser.CLOSE_BRACE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Return_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RETURN(self):
            return self.getToken(FhYParser.RETURN, 0)

        def expression(self):
            return self.getTypedRuleContext(FhYParser.ExpressionContext,0)


        def SEMICOLON(self):
            return self.getToken(FhYParser.SEMICOLON, 0)

        def getRuleIndex(self):
            return FhYParser.RULE_return_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterReturn_statement" ):
                listener.enterReturn_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitReturn_statement" ):
                listener.exitReturn_statement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitReturn_statement" ):
                return visitor.visitReturn_statement(self)
            else:
                return visitor.visitChildren(self)




    def return_statement(self):

        localctx = FhYParser.Return_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_return_statement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 177
            self.match(FhYParser.RETURN)
            self.state = 178
            self.expression(0)
            self.state = 179
            self.match(FhYParser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Qualified_typeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.type_qualifier = None # Token

        def type_(self):
            return self.getTypedRuleContext(FhYParser.TypeContext,0)


        def IDENTIFIER(self):
            return self.getToken(FhYParser.IDENTIFIER, 0)

        def getRuleIndex(self):
            return FhYParser.RULE_qualified_type

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterQualified_type" ):
                listener.enterQualified_type(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitQualified_type" ):
                listener.exitQualified_type(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitQualified_type" ):
                return visitor.visitQualified_type(self)
            else:
                return visitor.visitChildren(self)




    def qualified_type(self):

        localctx = FhYParser.Qualified_typeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_qualified_type)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 182
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,13,self._ctx)
            if la_ == 1:
                self.state = 181
                localctx.type_qualifier = self.match(FhYParser.IDENTIFIER)


            self.state = 184
            self.type_()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def tuple_type(self):
            return self.getTypedRuleContext(FhYParser.Tuple_typeContext,0)


        def numerical_type(self):
            return self.getTypedRuleContext(FhYParser.Numerical_typeContext,0)


        def index_type(self):
            return self.getTypedRuleContext(FhYParser.Index_typeContext,0)


        def getRuleIndex(self):
            return FhYParser.RULE_type

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterType" ):
                listener.enterType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitType" ):
                listener.exitType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitType" ):
                return visitor.visitType(self)
            else:
                return visitor.visitChildren(self)




    def type_(self):

        localctx = FhYParser.TypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_type)
        try:
            self.state = 189
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [4]:
                self.enterOuterAlt(localctx, 1)
                self.state = 186
                self.tuple_type()
                pass
            elif token in [50]:
                self.enterOuterAlt(localctx, 2)
                self.state = 187
                self.numerical_type()
                pass
            elif token in [5]:
                self.enterOuterAlt(localctx, 3)
                self.state = 188
                self.index_type()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Tuple_typeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def TUPLE(self):
            return self.getToken(FhYParser.TUPLE, 0)

        def OPEN_BRACKET(self):
            return self.getToken(FhYParser.OPEN_BRACKET, 0)

        def CLOSE_BRACKET(self):
            return self.getToken(FhYParser.CLOSE_BRACKET, 0)

        def type_(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(FhYParser.TypeContext)
            else:
                return self.getTypedRuleContext(FhYParser.TypeContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(FhYParser.COMMA)
            else:
                return self.getToken(FhYParser.COMMA, i)

        def getRuleIndex(self):
            return FhYParser.RULE_tuple_type

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTuple_type" ):
                listener.enterTuple_type(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTuple_type" ):
                listener.exitTuple_type(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTuple_type" ):
                return visitor.visitTuple_type(self)
            else:
                return visitor.visitChildren(self)




    def tuple_type(self):

        localctx = FhYParser.Tuple_typeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_tuple_type)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 191
            self.match(FhYParser.TUPLE)
            self.state = 192
            self.match(FhYParser.OPEN_BRACKET)
            self.state = 206
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,17,self._ctx)
            if la_ == 1:
                self.state = 193
                self.type_()
                self.state = 194
                self.match(FhYParser.COMMA)

            elif la_ == 2:
                self.state = 196
                self.type_()
                self.state = 199 
                self._errHandler.sync(self)
                _alt = 1
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt == 1:
                        self.state = 197
                        self.match(FhYParser.COMMA)
                        self.state = 198
                        self.type_()

                    else:
                        raise NoViableAltException(self)
                    self.state = 201 
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,15,self._ctx)

                self.state = 204
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==24:
                    self.state = 203
                    self.match(FhYParser.COMMA)




            self.state = 208
            self.match(FhYParser.CLOSE_BRACKET)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Numerical_typeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def dtype(self):
            return self.getTypedRuleContext(FhYParser.DtypeContext,0)


        def OPEN_BRACKET(self):
            return self.getToken(FhYParser.OPEN_BRACKET, 0)

        def expression_list(self):
            return self.getTypedRuleContext(FhYParser.Expression_listContext,0)


        def CLOSE_BRACKET(self):
            return self.getToken(FhYParser.CLOSE_BRACKET, 0)

        def getRuleIndex(self):
            return FhYParser.RULE_numerical_type

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumerical_type" ):
                listener.enterNumerical_type(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumerical_type" ):
                listener.exitNumerical_type(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNumerical_type" ):
                return visitor.visitNumerical_type(self)
            else:
                return visitor.visitChildren(self)




    def numerical_type(self):

        localctx = FhYParser.Numerical_typeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_numerical_type)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 210
            self.dtype()
            self.state = 215
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==17:
                self.state = 211
                self.match(FhYParser.OPEN_BRACKET)
                self.state = 212
                self.expression_list()
                self.state = 213
                self.match(FhYParser.CLOSE_BRACKET)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DtypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.base_dtype = None # Token

        def IDENTIFIER(self):
            return self.getToken(FhYParser.IDENTIFIER, 0)

        def LESS_THAN(self):
            return self.getToken(FhYParser.LESS_THAN, 0)

        def expression_list(self):
            return self.getTypedRuleContext(FhYParser.Expression_listContext,0)


        def GREATER_THAN(self):
            return self.getToken(FhYParser.GREATER_THAN, 0)

        def getRuleIndex(self):
            return FhYParser.RULE_dtype

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDtype" ):
                listener.enterDtype(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDtype" ):
                listener.exitDtype(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDtype" ):
                return visitor.visitDtype(self)
            else:
                return visitor.visitChildren(self)




    def dtype(self):

        localctx = FhYParser.DtypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_dtype)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 217
            localctx.base_dtype = self.match(FhYParser.IDENTIFIER)
            self.state = 222
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==40:
                self.state = 218
                self.match(FhYParser.LESS_THAN)
                self.state = 219
                self.expression_list()
                self.state = 220
                self.match(FhYParser.GREATER_THAN)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Dtype_listContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def dtype(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(FhYParser.DtypeContext)
            else:
                return self.getTypedRuleContext(FhYParser.DtypeContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(FhYParser.COMMA)
            else:
                return self.getToken(FhYParser.COMMA, i)

        def getRuleIndex(self):
            return FhYParser.RULE_dtype_list

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDtype_list" ):
                listener.enterDtype_list(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDtype_list" ):
                listener.exitDtype_list(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDtype_list" ):
                return visitor.visitDtype_list(self)
            else:
                return visitor.visitChildren(self)




    def dtype_list(self):

        localctx = FhYParser.Dtype_listContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_dtype_list)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 235
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==50:
                self.state = 224
                self.dtype()
                self.state = 229
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,20,self._ctx)
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt==1:
                        self.state = 225
                        self.match(FhYParser.COMMA)
                        self.state = 226
                        self.dtype() 
                    self.state = 231
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,20,self._ctx)

                self.state = 233
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==24:
                    self.state = 232
                    self.match(FhYParser.COMMA)




        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Index_typeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INDEX(self):
            return self.getToken(FhYParser.INDEX, 0)

        def OPEN_BRACKET(self):
            return self.getToken(FhYParser.OPEN_BRACKET, 0)

        def range_(self):
            return self.getTypedRuleContext(FhYParser.RangeContext,0)


        def CLOSE_BRACKET(self):
            return self.getToken(FhYParser.CLOSE_BRACKET, 0)

        def getRuleIndex(self):
            return FhYParser.RULE_index_type

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIndex_type" ):
                listener.enterIndex_type(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIndex_type" ):
                listener.exitIndex_type(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIndex_type" ):
                return visitor.visitIndex_type(self)
            else:
                return visitor.visitChildren(self)




    def index_type(self):

        localctx = FhYParser.Index_typeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_index_type)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 237
            self.match(FhYParser.INDEX)
            self.state = 238
            self.match(FhYParser.OPEN_BRACKET)
            self.state = 239
            self.range_()
            self.state = 240
            self.match(FhYParser.CLOSE_BRACKET)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RangeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(FhYParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(FhYParser.ExpressionContext,i)


        def COLON(self, i:int=None):
            if i is None:
                return self.getTokens(FhYParser.COLON)
            else:
                return self.getToken(FhYParser.COLON, i)

        def getRuleIndex(self):
            return FhYParser.RULE_range

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRange" ):
                listener.enterRange(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRange" ):
                listener.exitRange(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRange" ):
                return visitor.visitRange(self)
            else:
                return visitor.visitChildren(self)




    def range_(self):

        localctx = FhYParser.RangeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_range)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 242
            self.expression(0)
            self.state = 243
            self.match(FhYParser.COLON)
            self.state = 244
            self.expression(0)
            self.state = 247
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==27:
                self.state = 245
                self.match(FhYParser.COLON)
                self.state = 246
                self.expression(0)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.power_expression = None # ExpressionContext
            self.multiplicative_expression = None # ExpressionContext
            self.additive_expression = None # ExpressionContext
            self.shift_expression = None # ExpressionContext
            self.relational_expression = None # ExpressionContext
            self.equality_expression = None # ExpressionContext
            self.and_expression = None # ExpressionContext
            self.exclusive_or_expression = None # ExpressionContext
            self.or_expression = None # ExpressionContext
            self.logical_and_expression = None # ExpressionContext
            self.logical_or_expression = None # ExpressionContext
            self.ternary_expression = None # ExpressionContext
            self.nested_expression = None # Token
            self.unary_expression = None # Token

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(FhYParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(FhYParser.ExpressionContext,i)


        def CLOSE_PARENTHESES(self):
            return self.getToken(FhYParser.CLOSE_PARENTHESES, 0)

        def OPEN_PARENTHESES(self):
            return self.getToken(FhYParser.OPEN_PARENTHESES, 0)

        def SUBTRACTION(self):
            return self.getToken(FhYParser.SUBTRACTION, 0)

        def BITWISE_NOT(self):
            return self.getToken(FhYParser.BITWISE_NOT, 0)

        def LOGICAL_NOT(self):
            return self.getToken(FhYParser.LOGICAL_NOT, 0)

        def primitive_expression(self):
            return self.getTypedRuleContext(FhYParser.Primitive_expressionContext,0)


        def POWER(self):
            return self.getToken(FhYParser.POWER, 0)

        def MULTIPLICATION(self):
            return self.getToken(FhYParser.MULTIPLICATION, 0)

        def DIVISION(self):
            return self.getToken(FhYParser.DIVISION, 0)

        def FLOORDIV(self):
            return self.getToken(FhYParser.FLOORDIV, 0)

        def MODULO(self):
            return self.getToken(FhYParser.MODULO, 0)

        def ADDITION(self):
            return self.getToken(FhYParser.ADDITION, 0)

        def LEFT_SHIFT(self):
            return self.getToken(FhYParser.LEFT_SHIFT, 0)

        def RIGHT_SHIFT(self):
            return self.getToken(FhYParser.RIGHT_SHIFT, 0)

        def LESS_THAN(self):
            return self.getToken(FhYParser.LESS_THAN, 0)

        def LESS_THAN_OR_EQUAL(self):
            return self.getToken(FhYParser.LESS_THAN_OR_EQUAL, 0)

        def GREATER_THAN(self):
            return self.getToken(FhYParser.GREATER_THAN, 0)

        def GREATER_THAN_OR_EQUAL(self):
            return self.getToken(FhYParser.GREATER_THAN_OR_EQUAL, 0)

        def EQUAL_TO(self):
            return self.getToken(FhYParser.EQUAL_TO, 0)

        def NOT_EQUAL_TO(self):
            return self.getToken(FhYParser.NOT_EQUAL_TO, 0)

        def AND(self):
            return self.getToken(FhYParser.AND, 0)

        def EXCLUSIVE_OR(self):
            return self.getToken(FhYParser.EXCLUSIVE_OR, 0)

        def OR(self):
            return self.getToken(FhYParser.OR, 0)

        def LOGICAL_AND(self):
            return self.getToken(FhYParser.LOGICAL_AND, 0)

        def LOGICAL_OR(self):
            return self.getToken(FhYParser.LOGICAL_OR, 0)

        def QUESTION_MARK(self):
            return self.getToken(FhYParser.QUESTION_MARK, 0)

        def COLON(self):
            return self.getToken(FhYParser.COLON, 0)

        def getRuleIndex(self):
            return FhYParser.RULE_expression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpression" ):
                listener.enterExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpression" ):
                listener.exitExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpression" ):
                return visitor.visitExpression(self)
            else:
                return visitor.visitChildren(self)



    def expression(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = FhYParser.ExpressionContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 48
        self.enterRecursionRule(localctx, 48, self.RULE_expression, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 257
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,24,self._ctx)
            if la_ == 1:
                self.state = 250
                localctx.nested_expression = self.match(FhYParser.OPEN_PARENTHESES)
                self.state = 251
                self.expression(0)
                self.state = 252
                self.match(FhYParser.CLOSE_PARENTHESES)
                pass

            elif la_ == 2:
                self.state = 254
                localctx.unary_expression = self._input.LT(1)
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 69524783104) != 0)):
                    localctx.unary_expression = self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 255
                self.expression(14)
                pass

            elif la_ == 3:
                self.state = 256
                self.primitive_expression(0)
                pass


            self._ctx.stop = self._input.LT(-1)
            self.state = 300
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,26,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 298
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,25,self._ctx)
                    if la_ == 1:
                        localctx = FhYParser.ExpressionContext(self, _parentctx, _parentState)
                        localctx.power_expression = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 259
                        if not self.precpred(self._ctx, 13):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 13)")
                        self.state = 260
                        self.match(FhYParser.POWER)
                        self.state = 261
                        self.expression(14)
                        pass

                    elif la_ == 2:
                        localctx = FhYParser.ExpressionContext(self, _parentctx, _parentState)
                        localctx.multiplicative_expression = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 262
                        if not self.precpred(self._ctx, 12):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 12)")
                        self.state = 263
                        _la = self._input.LA(1)
                        if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 32212254720) != 0)):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 264
                        self.expression(13)
                        pass

                    elif la_ == 3:
                        localctx = FhYParser.ExpressionContext(self, _parentctx, _parentState)
                        localctx.additive_expression = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 265
                        if not self.precpred(self._ctx, 11):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 11)")
                        self.state = 266
                        _la = self._input.LA(1)
                        if not(_la==35 or _la==36):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 267
                        self.expression(12)
                        pass

                    elif la_ == 4:
                        localctx = FhYParser.ExpressionContext(self, _parentctx, _parentState)
                        localctx.shift_expression = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 268
                        if not self.precpred(self._ctx, 10):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 10)")
                        self.state = 269
                        _la = self._input.LA(1)
                        if not(_la==37 or _la==38):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 270
                        self.expression(11)
                        pass

                    elif la_ == 5:
                        localctx = FhYParser.ExpressionContext(self, _parentctx, _parentState)
                        localctx.relational_expression = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 271
                        if not self.precpred(self._ctx, 9):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 9)")
                        self.state = 272
                        _la = self._input.LA(1)
                        if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 8246337208320) != 0)):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 273
                        self.expression(10)
                        pass

                    elif la_ == 6:
                        localctx = FhYParser.ExpressionContext(self, _parentctx, _parentState)
                        localctx.equality_expression = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 274
                        if not self.precpred(self._ctx, 8):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 8)")
                        self.state = 275
                        _la = self._input.LA(1)
                        if not(_la==43 or _la==44):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 276
                        self.expression(9)
                        pass

                    elif la_ == 7:
                        localctx = FhYParser.ExpressionContext(self, _parentctx, _parentState)
                        localctx.and_expression = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 277
                        if not self.precpred(self._ctx, 7):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 7)")
                        self.state = 278
                        self.match(FhYParser.AND)
                        self.state = 279
                        self.expression(8)
                        pass

                    elif la_ == 8:
                        localctx = FhYParser.ExpressionContext(self, _parentctx, _parentState)
                        localctx.exclusive_or_expression = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 280
                        if not self.precpred(self._ctx, 6):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 6)")
                        self.state = 281
                        self.match(FhYParser.EXCLUSIVE_OR)
                        self.state = 282
                        self.expression(7)
                        pass

                    elif la_ == 9:
                        localctx = FhYParser.ExpressionContext(self, _parentctx, _parentState)
                        localctx.or_expression = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 283
                        if not self.precpred(self._ctx, 5):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 5)")
                        self.state = 284
                        self.match(FhYParser.OR)
                        self.state = 285
                        self.expression(6)
                        pass

                    elif la_ == 10:
                        localctx = FhYParser.ExpressionContext(self, _parentctx, _parentState)
                        localctx.logical_and_expression = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 286
                        if not self.precpred(self._ctx, 4):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 4)")
                        self.state = 287
                        self.match(FhYParser.LOGICAL_AND)
                        self.state = 288
                        self.expression(5)
                        pass

                    elif la_ == 11:
                        localctx = FhYParser.ExpressionContext(self, _parentctx, _parentState)
                        localctx.logical_or_expression = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 289
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 290
                        self.match(FhYParser.LOGICAL_OR)
                        self.state = 291
                        self.expression(4)
                        pass

                    elif la_ == 12:
                        localctx = FhYParser.ExpressionContext(self, _parentctx, _parentState)
                        localctx.ternary_expression = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 292
                        if not self.precpred(self._ctx, 2):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                        self.state = 293
                        self.match(FhYParser.QUESTION_MARK)
                        self.state = 294
                        self.expression(0)
                        self.state = 295
                        self.match(FhYParser.COLON)
                        self.state = 296
                        self.expression(3)
                        pass

             
                self.state = 302
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,26,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class Expression_listContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(FhYParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(FhYParser.ExpressionContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(FhYParser.COMMA)
            else:
                return self.getToken(FhYParser.COMMA, i)

        def getRuleIndex(self):
            return FhYParser.RULE_expression_list

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpression_list" ):
                listener.enterExpression_list(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpression_list" ):
                listener.exitExpression_list(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpression_list" ):
                return visitor.visitExpression_list(self)
            else:
                return visitor.visitChildren(self)




    def expression_list(self):

        localctx = FhYParser.Expression_listContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_expression_list)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 311
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 16888568127455232) != 0):
                self.state = 303
                self.expression(0)
                self.state = 308
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==24:
                    self.state = 304
                    self.match(FhYParser.COMMA)
                    self.state = 305
                    self.expression(0)
                    self.state = 310
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Primitive_expressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.tuple_access_expression = None # Primitive_expressionContext
            self.function_expression = None # Primitive_expressionContext
            self.array_access_expression = None # Primitive_expressionContext

        def atom(self):
            return self.getTypedRuleContext(FhYParser.AtomContext,0)


        def FLOAT_LITERAL(self):
            return self.getToken(FhYParser.FLOAT_LITERAL, 0)

        def primitive_expression(self):
            return self.getTypedRuleContext(FhYParser.Primitive_expressionContext,0)


        def OPEN_PARENTHESES(self):
            return self.getToken(FhYParser.OPEN_PARENTHESES, 0)

        def expression_list(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(FhYParser.Expression_listContext)
            else:
                return self.getTypedRuleContext(FhYParser.Expression_listContext,i)


        def CLOSE_PARENTHESES(self):
            return self.getToken(FhYParser.CLOSE_PARENTHESES, 0)

        def LESS_THAN(self):
            return self.getToken(FhYParser.LESS_THAN, 0)

        def dtype_list(self):
            return self.getTypedRuleContext(FhYParser.Dtype_listContext,0)


        def GREATER_THAN(self):
            return self.getToken(FhYParser.GREATER_THAN, 0)

        def OPEN_BRACKET(self):
            return self.getToken(FhYParser.OPEN_BRACKET, 0)

        def CLOSE_BRACKET(self):
            return self.getToken(FhYParser.CLOSE_BRACKET, 0)

        def getRuleIndex(self):
            return FhYParser.RULE_primitive_expression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrimitive_expression" ):
                listener.enterPrimitive_expression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrimitive_expression" ):
                listener.exitPrimitive_expression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrimitive_expression" ):
                return visitor.visitPrimitive_expression(self)
            else:
                return visitor.visitChildren(self)



    def primitive_expression(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = FhYParser.Primitive_expressionContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 52
        self.enterRecursionRule(localctx, 52, self.RULE_primitive_expression, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 314
            self.atom()
            self._ctx.stop = self._input.LT(-1)
            self.state = 342
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,32,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 340
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,31,self._ctx)
                    if la_ == 1:
                        localctx = FhYParser.Primitive_expressionContext(self, _parentctx, _parentState)
                        localctx.tuple_access_expression = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_primitive_expression)
                        self.state = 316
                        if not self.precpred(self._ctx, 4):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 4)")
                        self.state = 317
                        self.match(FhYParser.FLOAT_LITERAL)
                        pass

                    elif la_ == 2:
                        localctx = FhYParser.Primitive_expressionContext(self, _parentctx, _parentState)
                        localctx.function_expression = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_primitive_expression)
                        self.state = 318
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 323
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)
                        if _la==40:
                            self.state = 319
                            self.match(FhYParser.LESS_THAN)
                            self.state = 320
                            self.dtype_list()
                            self.state = 321
                            self.match(FhYParser.GREATER_THAN)


                        self.state = 329
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)
                        if _la==17:
                            self.state = 325
                            self.match(FhYParser.OPEN_BRACKET)
                            self.state = 326
                            self.expression_list()
                            self.state = 327
                            self.match(FhYParser.CLOSE_BRACKET)


                        self.state = 331
                        self.match(FhYParser.OPEN_PARENTHESES)
                        self.state = 332
                        self.expression_list()
                        self.state = 333
                        self.match(FhYParser.CLOSE_PARENTHESES)
                        pass

                    elif la_ == 3:
                        localctx = FhYParser.Primitive_expressionContext(self, _parentctx, _parentState)
                        localctx.array_access_expression = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_primitive_expression)
                        self.state = 335
                        if not self.precpred(self._ctx, 2):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                        self.state = 336
                        self.match(FhYParser.OPEN_BRACKET)
                        self.state = 337
                        self.expression_list()
                        self.state = 338
                        self.match(FhYParser.CLOSE_BRACKET)
                        pass

             
                self.state = 344
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,32,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class AtomContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def tuple_(self):
            return self.getTypedRuleContext(FhYParser.TupleContext,0)


        def identifier_expression(self):
            return self.getTypedRuleContext(FhYParser.Identifier_expressionContext,0)


        def literal(self):
            return self.getTypedRuleContext(FhYParser.LiteralContext,0)


        def getRuleIndex(self):
            return FhYParser.RULE_atom

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAtom" ):
                listener.enterAtom(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAtom" ):
                listener.exitAtom(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAtom" ):
                return visitor.visitAtom(self)
            else:
                return visitor.visitChildren(self)




    def atom(self):

        localctx = FhYParser.AtomContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_atom)
        try:
            self.state = 348
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [15]:
                self.enterOuterAlt(localctx, 1)
                self.state = 345
                self.tuple_()
                pass
            elif token in [50]:
                self.enterOuterAlt(localctx, 2)
                self.state = 346
                self.identifier_expression()
                pass
            elif token in [51, 52, 53]:
                self.enterOuterAlt(localctx, 3)
                self.state = 347
                self.literal()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TupleContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def OPEN_PARENTHESES(self):
            return self.getToken(FhYParser.OPEN_PARENTHESES, 0)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(FhYParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(FhYParser.ExpressionContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(FhYParser.COMMA)
            else:
                return self.getToken(FhYParser.COMMA, i)

        def CLOSE_PARENTHESES(self):
            return self.getToken(FhYParser.CLOSE_PARENTHESES, 0)

        def getRuleIndex(self):
            return FhYParser.RULE_tuple

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTuple" ):
                listener.enterTuple(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTuple" ):
                listener.exitTuple(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTuple" ):
                return visitor.visitTuple(self)
            else:
                return visitor.visitChildren(self)




    def tuple_(self):

        localctx = FhYParser.TupleContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_tuple)
        self._la = 0 # Token type
        try:
            self.state = 368
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,36,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 350
                self.match(FhYParser.OPEN_PARENTHESES)
                self.state = 351
                self.expression(0)
                self.state = 352
                self.match(FhYParser.COMMA)
                self.state = 353
                self.match(FhYParser.CLOSE_PARENTHESES)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 355
                self.match(FhYParser.OPEN_PARENTHESES)
                self.state = 356
                self.expression(0)
                self.state = 359 
                self._errHandler.sync(self)
                _alt = 1
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt == 1:
                        self.state = 357
                        self.match(FhYParser.COMMA)
                        self.state = 358
                        self.expression(0)

                    else:
                        raise NoViableAltException(self)
                    self.state = 361 
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,34,self._ctx)

                self.state = 364
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==24:
                    self.state = 363
                    self.match(FhYParser.COMMA)


                self.state = 366
                self.match(FhYParser.CLOSE_PARENTHESES)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Identifier_expressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self, i:int=None):
            if i is None:
                return self.getTokens(FhYParser.IDENTIFIER)
            else:
                return self.getToken(FhYParser.IDENTIFIER, i)

        def DOT(self, i:int=None):
            if i is None:
                return self.getTokens(FhYParser.DOT)
            else:
                return self.getToken(FhYParser.DOT, i)

        def getRuleIndex(self):
            return FhYParser.RULE_identifier_expression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIdentifier_expression" ):
                listener.enterIdentifier_expression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIdentifier_expression" ):
                listener.exitIdentifier_expression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIdentifier_expression" ):
                return visitor.visitIdentifier_expression(self)
            else:
                return visitor.visitChildren(self)




    def identifier_expression(self):

        localctx = FhYParser.Identifier_expressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_identifier_expression)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 370
            self.match(FhYParser.IDENTIFIER)
            self.state = 375
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,37,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 371
                    self.match(FhYParser.DOT)
                    self.state = 372
                    self.match(FhYParser.IDENTIFIER) 
                self.state = 377
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,37,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LiteralContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT_LITERAL(self):
            return self.getToken(FhYParser.INT_LITERAL, 0)

        def FLOAT_LITERAL(self):
            return self.getToken(FhYParser.FLOAT_LITERAL, 0)

        def COMPLEX_LITERAL(self):
            return self.getToken(FhYParser.COMPLEX_LITERAL, 0)

        def getRuleIndex(self):
            return FhYParser.RULE_literal

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLiteral" ):
                listener.enterLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLiteral" ):
                listener.exitLiteral(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLiteral" ):
                return visitor.visitLiteral(self)
            else:
                return visitor.visitChildren(self)




    def literal(self):

        localctx = FhYParser.LiteralContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_literal)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 378
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 15762598695796736) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[24] = self.expression_sempred
        self._predicates[26] = self.primitive_expression_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expression_sempred(self, localctx:ExpressionContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 13)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 12)
         

            if predIndex == 2:
                return self.precpred(self._ctx, 11)
         

            if predIndex == 3:
                return self.precpred(self._ctx, 10)
         

            if predIndex == 4:
                return self.precpred(self._ctx, 9)
         

            if predIndex == 5:
                return self.precpred(self._ctx, 8)
         

            if predIndex == 6:
                return self.precpred(self._ctx, 7)
         

            if predIndex == 7:
                return self.precpred(self._ctx, 6)
         

            if predIndex == 8:
                return self.precpred(self._ctx, 5)
         

            if predIndex == 9:
                return self.precpred(self._ctx, 4)
         

            if predIndex == 10:
                return self.precpred(self._ctx, 3)
         

            if predIndex == 11:
                return self.precpred(self._ctx, 2)
         

    def primitive_expression_sempred(self, localctx:Primitive_expressionContext, predIndex:int):
            if predIndex == 12:
                return self.precpred(self._ctx, 4)
         

            if predIndex == 13:
                return self.precpred(self._ctx, 3)
         

            if predIndex == 14:
                return self.precpred(self._ctx, 2)
         




