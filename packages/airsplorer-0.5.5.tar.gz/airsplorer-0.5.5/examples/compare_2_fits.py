from airsplorer import filediag

file1 = r"C:\Users\ccossou\LocalStorage\Documents\Ariel\CDP\ariel_airs_readnoise_CH1_STM_0001.fits"
file2 = r"C:\Users\ccossou\LocalStorage\Documents\Ariel\CDP\ariel_airs_readnoise_CH1_EM_00001.fits"

print(filediag.compare_headers([file1, file2]))
