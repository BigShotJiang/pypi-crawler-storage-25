"""
Using a _ramp .fits, explore the datacube, click on a pixel to see its integration and correspondant group flags.
Select group and integration to see the corresponding image.
"""

import matplotlib.pyplot as plt

import airsplorer

filename = r"C:\Users\ccossou\LocalStorage\data\ariel\2026_03_EM_CONFIG1\CH0\Ref2_9999nm_Tx\260407_225744_2018_ifpa_em_ch0\260407_225744_2018_ifpa_em_ch0_0.fits"

interactive_ramp = airsplorer.ql.interactive_super_raw(filename, ypos=100, xpos=15)

plt.show()
