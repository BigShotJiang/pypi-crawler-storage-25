"""
Using a _ramp .fits, explore the datacube, click on a pixel to see its integration and correspondant group flags.
Select group and integration to see the corresponding image.
"""

import matplotlib.pyplot as plt
from astropy.io import fits

import airsplorer

filename = r"C:\Users\ccossou\LocalStorage\data\ariel\2026_03_EM_CONFIG1\CH0\260331_205034_1123_ifpa_em_ch0_ramp.fits"
filename = r"C:\Users\ccossou\LocalStorage\data\ariel\2026_03_EM_CONFIG1\CH0\260331_205034_1123_ifpa_em_ch0_uncal.fits"

with fits.open(filename) as hdulist:
    datacube = hdulist["SCI"].data

    if "GROUPDQ" in hdulist:
        groupdq = hdulist['GROUPDQ'].data
    else:
        groupdq = None

# interactive_ramp = airsplorer.plot.InteractiveRampDQ(datacube, groupdq)
interactive_ramp = airsplorer.plot.InteractiveRampDQ(datacube, dqcube=groupdq, ypos=59, xpos=32, intpos=1)

plt.show()
