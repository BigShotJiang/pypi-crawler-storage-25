# AIRSplorer

Convenience tools for analysis and data manipulation related to ARIEL AIRS. The package provides utilities for working with images and cubes, basic flux calculations, coordinate conversions, mask handling, I/O helpers, and common plotting routines.

- Python ≥ 3.11
- License: MIT
- Repository: https://github.com/ccossou/airsplorer

## Key features

- Image and cube manipulation (load, save, simple transforms)
- Basic photometry and flux/statistics utilities
- Sky/pixel coordinate conversions
- Mask creation, application, and operations
- Plotting helpers and tabulated outputs
- Test suite for core functionality

Indicative modules:
- `coord`: coordinate conversions and utilities
- `flux`: simple photometry and flux-related computations
- `imager` / `imlib`: image operations
- `mask`: mask creation and manipulation
- `read` / `write`: I/O helpers
- `plot`: common plotting helpers
- `utils`: assorted utility functions

## Installation

From PyPI (when available):
```
bash
python -m pip install airsplorer
```
From source (development):
```
bash
git clone https://github.com/ccossou/airsplorer.git
cd airsplorer
python -m pip install -e .
```
Main runtime dependencies are installed automatically.

## Quick start
```
python
# Example imports (see function docstrings for exact APIs)
from airsplorer import coord, flux, imager, mask, utils, read, write, plot

# Loading and saving (adjust paths and formats to your data)
# data = read.load_image("path/to/file.fits")
# write.save_image(data, "path/to/output.fits")

# Image operations
# img2 = imager.normalize(data)
# m = mask.create_threshold_mask(img2, threshold=5.0)
# img3 = imager.apply_mask(img2, m)

# Flux calculations
# f = flux.aperture_photometry(img3, center=(x0, y0), radius=5)

# Coordinate conversions
# px, py = coord.sky_to_pixel(ra, dec, wcs_header)
# ra2, dec2 = coord.pixel_to_sky(px, py, wcs_header)

# Plotting
# plot.imshow(img3, title="Processed image")
```
Notes:
- Check each function’s docstring for signatures, units, and options.
- Adjust examples to your data formats and WCS headers.

## Documentation

Install optional documentation dependencies:
```
bash
python -m pip install "airsplorer[docs]"
```
Build locally with Sphinx (if you keep docs in a `docs/` folder):
```
bash
sphinx-build -b html docs docs/_build/html
```
## Testing

Run the test suite:
```
bash
pytest
```
With coverage:
```
bash
pytest --cov=. --cov-report=term-missing
```
## Contributing

Contributions are welcome:
1. Fork the repository and create a feature branch.
2. Install in development mode: `python -m pip install -e .`
3. Add tests that cover your changes.
4. Run tests locally: `pytest`
5. Open a pull request with a clear description.

Please follow idiomatic Python style and add documentation (docstrings, examples) where helpful.

## License and citation

- License: MIT
- If you use airsplorer in scientific work, please cite the repository and the software version you used. A DOI or BibTeX entry may be added in the future.
```
