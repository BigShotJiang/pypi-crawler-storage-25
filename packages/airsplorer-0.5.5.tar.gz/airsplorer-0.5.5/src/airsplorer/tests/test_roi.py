import numpy as np
import pytest

from airsplorer import roi

test_data = [
    ((0, 0), (1, 1, 1032, 1024), (0, 0)),
    ((452, 50), (453, 51, 512, 512), (0, 0))  # Brightsky first pixel
]


@pytest.mark.parametrize("abs_px,sub_start,expected_result", test_data)
def test_abs_to_rel_pixels(abs_px, sub_start, expected_result):
    """
    Test abs_to_rel_pixels
    """

    header = {
        "SUBSTRT1": sub_start[0],
        "SUBSTRT2": sub_start[1],
        "SUBSIZE1": sub_start[2],
        "SUBSIZE2": sub_start[3],
    }

    rel_px = roi.abs_to_rel_pixels(abs_px, header)

    assert rel_px == expected_result


def test_abs_to_rel_pixels_fail():
    """
    Test abs_to_rel_pixels exceptions
    """
    # Correspond to a FULL array
    header = {
        "SUBSTRT1": 453,
        "SUBSTRT2": 51,
        "SUBSIZE1": 512,
        "SUBSIZE2": 512,
    }

    # First absolute pixel don't exist in brightsky and should fail
    with pytest.raises(IndexError):
        roi.abs_to_rel_pixels((451, 50), header)

    with pytest.raises(IndexError):
        roi.abs_to_rel_pixels((452, 49), header)

    with pytest.raises(IndexError):
        roi.abs_to_rel_pixels((964, 561), header)

    with pytest.raises(IndexError):
        roi.abs_to_rel_pixels((963, 562), header)


def test_crop_images():
    """
    Test crop_images
    """

    # Images with no header
    small_im = np.ones((10, 12))

    big_im = np.zeros((100, 120))
    big_im[:10, :12] = 2

    cropped_im = roi.crop_image(big_im, small_im)

    assert small_im.shape == cropped_im.shape
    assert np.all(cropped_im == 2)

    # Images with header
    small_header = {
        "SUBSTRT1": 4,
        "SUBSTRT2": 5,
    }
    big_header = {
        "SUBSTRT1": 1,
        "SUBSTRT2": 1,
    }
    small_im = np.ones((10, 12))

    big_im = np.zeros((100, 120))
    xstart = 3
    xstop = xstart + 12
    ystart = 4
    ystop = ystart + 10
    big_im[ystart:ystop, xstart:xstop] = 2

    cropped_im = roi.crop_image(big_im, small_im, big_header, small_header)

    assert small_im.shape == cropped_im.shape
    assert np.all(cropped_im == 2)

    # Ensure it crash if one header is missing
    with pytest.raises(ValueError):
        roi.crop_image(big_im, small_im, big_meta=big_header)

    with pytest.raises(ValueError):
        roi.crop_image(big_im, small_im, small_meta=small_header)


def test_find_array_intersect():
    """
    Test find_array_intersect
    """

    met_big = dict(SUBSTRT1=1, SUBSTRT2=1, SUBSIZE1=1032, SUBSIZE2=1024)
    met_medium = dict(SUBSTRT1=256, SUBSTRT2=257, SUBSIZE1=512, SUBSIZE2=512)
    met_small = dict(SUBSTRT1=512, SUBSTRT2=534, SUBSIZE1=64, SUBSIZE2=70)

    # ((xmin, xmax), (ymin, ymax))
    ref_values = ((511, 575), (533, 603))
    ((ref_xmin, ref_xmax), (ref_ymin, ref_ymax)) = ref_values

    ((xmin, xmax), (ymin, ymax)) = roi.find_array_intersect([met_big, met_medium, met_small])

    assert xmin == ref_xmin, f"xmin ({xmin}) not equal to expected value {ref_xmin}"
    assert xmax == ref_xmax, f"xmax ({xmax}) not equal to expected value {ref_xmax}"
    assert ymin == ref_ymin, f"ymin ({ymin}) not equal to expected value {ref_ymin}"
    assert ymax == ref_ymax, f"ymax ({ymax}) not equal to expected value {ref_ymax}"


def test_select_sub_image():
    """
    Test select_sub_image
    """

    # Images with no header
    big_im = np.zeros((10, 10))
    big_im[2:9, 3:10] = 2

    sub_image = roi.select_sub_image(big_im, center=(5, 6), radius=3)

    # If correctly placed, all pixels will have the same value
    assert np.all(sub_image == 2)

    # If correctly placed, no pixel outside the sub_image have a non-zero value
    assert sub_image.sum() == big_im.sum()


def test_select_sub_image_fail():
    """
    Test select_sub_image fails scenarii
    """

    # Images with no header
    big_im = np.zeros((11, 11))

    roi.select_sub_image(big_im, center=(5, 5), radius=5)

    with pytest.raises(ValueError):
        roi.select_sub_image(big_im, center=(4, 5), radius=5)

    with pytest.raises(ValueError):
        roi.select_sub_image(big_im, center=(5, 4), radius=5)

    with pytest.raises(ValueError):
        roi.select_sub_image(big_im, center=(6, 5), radius=5)

    with pytest.raises(ValueError):
        roi.select_sub_image(big_im, center=(5, 6), radius=5)


test_data = [  # (dy, dx), reference_position in pixel index (y, x)
    ((-1, 0), (1, 2)),
    ((0, 1), (2, 3))
]


@pytest.mark.parametrize("shift, ref_pos", test_data)
def test_subpixel_shift(shift, ref_pos):
    """
    Test of subpixel_shift

    All shift are done on one pixel located at (2, 2)
    Only test integer shifts to ensure X and Y are not inverted.
    """
    (dy, dx) = shift
    (yref, xref) = ref_pos

    image = np.zeros((5, 5))
    image[2, 2] = 1

    new_image = roi.subpixel_shift(image, dy, dx)

    (ymax, xmax) = np.unravel_index(np.argmax(new_image), new_image.shape)

    max_value = new_image[ymax, xmax]

    assert ymax == yref, "Y position of maximum incorrect"
    assert xmax == xref, "X position of maximum incorrect"
    assert max_value == 1, "Max value is not 1"
