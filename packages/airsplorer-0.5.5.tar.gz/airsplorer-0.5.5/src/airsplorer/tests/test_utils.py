
from airsplorer import utils


def test_dump_dict():
    """
    Test dump_dict
    """

    input = {
    "plot": {
        "display": True,
        "folder": "output_folder",
        "extension": "pdf",
        "save": True,
    },
    "input": {
        "folder": "input_folder",
    },
    "analysis": {
        "sub": {
            "one": 1.,
            "two": 2.,
        },
        "log_file": "results.txt",
        "version":"miricap502.__version__",
    }
    }

    ref_str = """[plot]
  display = True
  folder = output_folder
  extension = pdf
  save = True

[input]
  folder = input_folder

[analysis]
  [[sub]]
    one = 1.0
    two = 2.0

  log_file = results.txt
  version = miricap502.__version__

"""

    output = utils.dump_dict(input)

    assert output == ref_str
