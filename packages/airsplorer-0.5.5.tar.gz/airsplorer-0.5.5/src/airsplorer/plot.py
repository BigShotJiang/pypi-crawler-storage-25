import logging
import os

import matplotlib.lines as mlines
import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
import numpy as np
from astropy.io import fits
from astropy.visualization import interval
from matplotlib import colors, ticker, widgets

from . import constants
from . import mask as mk
from . import utils

LOG = logging.getLogger(__name__)


def double_image(image1, image2, ititles=None, vlabel=None, title=None, force_positive=False):
    """
    Plot two images using the same Zscale

    :param image1: Input image, Normalisation will be done on that image
    :type image1: np.ndarray(y, x)
    :param image2: Input image
    :type image2: np.ndarray(y, x)
    :param list(str) ititles: [optional] If given, will be one title per image
    :param str vlabel: [optional] Unit of image data
    :param str title: [optional] Image title
    :param bool force_positive: [optional] If True, will force the Zscale vrange to display only positive values

    :return: return the figure
    :rtype: Matplotlib.Figure
    """
    if ititles is not None:
        if not isinstance(ititles, (list, tuple)):
            raise ValueError(f"Expect ititles to be list or tuple of strings, was given '{ititles}'")

        if len(ititles) != 2:
            raise ValueError(f"Expect 2 values (one title per image), got {len(ititles)} instead.")

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6), sharex=True, sharey=True)  # figsize=(8, 3)
    fig.subplots_adjust(left=0.05, bottom=0.05, right=0.99, top=0.96, wspace=0.1, hspace=0.1)

    zscale = interval.ZScaleInterval(n_samples=600, contrast=0.25, max_reject=0.5, min_npixels=5, krej=2.5,
                                     max_iterations=5)

    if force_positive:
        (vmin, vmax) = zscale.get_limits(image1[image1 > 0])
    else:
        (vmin, vmax) = zscale.get_limits(image1)

    normalization = colors.Normalize(vmin=vmin, vmax=vmax)  # Linear

    cmap = ax1.imshow(image1, origin='lower', norm=normalization, cmap="viridis")
    ax1.set_xlabel("X [pixels]")
    ax1.set_ylabel("Y [pixels]")
    if ititles is not None:
        ax1.set_title(ititles[0])

    cmap = ax2.imshow(image2, origin='lower', norm=normalization, cmap="viridis")
    ax2.set_xlabel("X [pixels]")
    ax2.set_ylabel("Y [pixels]")
    if ititles is not None:
        ax2.set_title(ititles[1])

    cbar = fig.colorbar(cmap, ax=fig.get_axes())
    if vlabel is not None:
        cbar.set_label(vlabel)

    if title is not None:
        fig.suptitle(title)

    return fig

def single_image(image, vlabel=None, title=None, force_positive=False):
    """
    Plot a simple image using Zscale

    :param image: Input image
    :type image: np.ndarray(y, x)
    :param str vlabel: [optional] Unit of image data
    :param str title: [optional] Image title
    :param bool force_positive: [optional] If True, will force the Zscale vrange to display only positive values

    :return: return the figure
    :rtype: Matplotlib.Figure
    """

    fig, ax = plt.subplots()  # figsize=(8, 3)

    zscale = interval.ZScaleInterval(n_samples=600, contrast=0.25, max_reject=0.5, min_npixels=5, krej=2.5,
                                     max_iterations=5)

    if force_positive:
        (vmin, vmax) = zscale.get_limits(image[image > 0])
    else:
        (vmin, vmax) = zscale.get_limits(image)

    normalization = colors.Normalize(vmin=vmin, vmax=vmax)  # Linear

    cmap = ax.imshow(image, origin='lower', norm=normalization, cmap="viridis")

    cbar = fig.colorbar(cmap, ax=ax)
    if vlabel is not None:
        cbar.set_label(vlabel)

    if title is not None:
        fig.suptitle(title)

    ax.set_xlabel("X [pixels]")
    ax.set_ylabel("Y [pixels]")

    return fig


def histogram(data, xlabel, title=None):
    """
    Histogram of input data with nb bins optimized for the given data
    Histogram is normalized by default

    :param data:
    :param str xlabel: Description of the data
    :param str title: [optional] Title for the figure

    :return: return the figure
    :rtype: Matplotlib.Figure
    """
    fig, ax = plt.subplots(figsize=(10, 7.5))

    ax.hist(data, bins=utils.optimum_nbins(data), density=True, histtype="step")
    ax.set_xlabel(xlabel)
    ax.set_ylabel("Probability distribution")

    if title is not None:
        fig.suptitle(title)

    return fig


def compare_images_flag(filenames, flag=2, titles=None, title_keyword=None):
    """
    Given level 2 files, (cal or rates) will display the DQ image of one given flag for each file
    By default, will be the Saturation flag (2^1=2 ; flag=1)

    :param list(str) filenames: List of FITS filenames (or just one filename as a str)
    :param int flag: [optional] Display saturation by default. If set, represent the flag value. Can be a pure flag
                                (2) or a combination of multiple flags (5 = 4+1)

    :param list(str) titles: [optional] If set, will be used as title for each image.
                             If title_keyword is set, this parameter is ignored.
                             If neither titles, nor title_keyword are set, the filename is used as title
    :param str title_keyword: [optional] If set, will retrieve and display the value of that
                              header keyword for each image as its title.
                              This parameter takes precedence over titles if both are set

    :return: return the figure
    :rtype: Matplotlib.Figure
    """

    if isinstance(filenames, str):
        filenames = [filenames]

    nb_plots = len(filenames)
    nb_x_plots = int(np.ceil(np.sqrt(nb_plots)))
    nb_y_plots = int(np.ceil(nb_plots / nb_x_plots))

    if titles is None:
        titles = [os.path.basename(f) for f in filenames]
    elif len(titles) != nb_plots:
        raise ValueError(f"titles must be a list with the same length as filenames")

    # If power of 2, we can get the flag meaning
    if flag & (flag - 1) == 0:
        flag_detail = constants.status_pipeline[flag]
    else:
        bits = mk.decompose_mask_status(flag)
        flag_detail = "+".join(map(str, bits))

    # Plot
    # define a figure which can contains several plots, you can define resolution and so on here...
    fig, axarr = plt.subplots(nb_y_plots, nb_x_plots, sharex='all', sharey='all', figsize=(9., 7.))

    if nb_plots > 1:
        axarr = axarr.flatten()
    else:
        axarr = [axarr]

    for i in range(nb_plots):
        file = filenames[i]
        ax = axarr[i]

        hdulist = fits.open(file)
        metadata = hdulist[0].header

        if title_keyword:
            title = f"{title_keyword} = {metadata[title_keyword]}"
        else:
            title = titles[i]

        # Create a masked array
        mask = hdulist['DQ'].data

        flag_image = mk.extract_flag_image(mask, flag)

        ax.imshow(flag_image, cmap='Greys_r', origin="lower")
        ax.set_title(title)

    # Delete extra plots
    for j in range(i+1, len(axarr)):
        fig.delaxes(axarr[j])

    for int_i in range(0, nb_plots, nb_x_plots):
        axi = axarr[int_i]
        axi.set_ylabel("Y pixels")

    for int_i in range(nb_plots - nb_x_plots, nb_plots):
        axi = axarr[int_i]
        axi.set_xlabel("X pixels")

    fig.suptitle(f"Flag: {flag_detail} (Black=Not flagged ; White=flagged)")

    return fig



def image_flags(filename, flags=None):
    """
    Used to study flags and find what flag is causing one specific part of the image to be masked

    :param str filename: Filename of the FITS file to read
    :param list(int) flags: [optional] Display all flags in individual images by default. If you only want of subset,
    provide a list of those flags (e.g. [1, 2, 4]). WARNING: Must be a power of 2 (i.e individual flag)

    :return: return the figure
    :rtype: Matplotlib.Figure
    """
    if flags is None:
        flags = [2**i for i in range(32)]

    nb_plots = len(flags) + 1 # One extra plot for the image
    nb_x_plots = int(np.ceil(np.sqrt(nb_plots)))
    nb_y_plots = int(np.ceil(nb_plots / nb_x_plots))

    hdulist = fits.open(filename)
    image = hdulist["SCI"].data

    # Create a masked array
    mask = hdulist['DQ'].data

    indiv_masks = mk.get_separated_dq_array(mask)

    # For all requested flag, we need the corresponding power of 2
    power_of_2s = []
    for flag in flags:
        power_of_2 = int(np.log10(flag)/np.log10(2))
        power_of_2s.append(power_of_2)

    # Plot
    # define a figure which can contains several plots, you can define resolution and so on here...
    fig, axarr = plt.subplots(nb_y_plots, nb_x_plots, sharex='all', sharey='all', figsize=(12., 10.))
    fig.subplots_adjust(left=0.08, bottom=0.1, right=0.96, top=0.9, wspace=0.1, hspace=0.3)

    if nb_plots > 1:
        axarr = axarr.flatten()
    else:
        axarr = [axarr]

    # Plot of actual image first, for easier zoom
    ax = axarr[0]

    zscale = interval.ZScaleInterval(n_samples=600, contrast=0.25, max_reject=0.5, min_npixels=5, krej=2.5,
                                     max_iterations=5)

    (vmin, vmax) = zscale.get_limits(image)

    normalization = colors.Normalize(vmin=vmin, vmax=vmax)  # Linear

    ax.imshow(image, origin='lower', norm=normalization, cmap="viridis")
    ax.set_title("Image")

    for i in range(1, nb_plots):

        power_of_2 = power_of_2s[i-1]  # First plot is actual image
        flag = 2**power_of_2
        ax = axarr[i]
        title = f"Flag: {flag}"  # Not using detail because too long and too many plots  ({constants.status_pipeline[flag]})

        ax.imshow(indiv_masks[:, :, power_of_2], cmap='Greys_r', origin="lower")
        ax.set_title(title)

    # Delete extra plots
    for j in range(i+1, len(axarr)):
        fig.delaxes(axarr[j])

    for int_i in range(0, nb_plots, nb_x_plots):
        axi = axarr[int_i]
        axi.set_ylabel("Y pixels")

    for int_i in range(nb_plots - nb_x_plots, nb_plots):
        axi = axarr[int_i]
        axi.set_xlabel("X pixels")

    fig.suptitle(f"Flag images for {os.path.basename(filename)} (Black=Not flagged ; White=flagged)")

    # fig2, ax2 = plt.subplots()

    # y = len(power_of_2s)+1
    # for power_of_2 in power_of_2s:
    #     flag = 2**power_of_2
    #     text = f"Flag {flag} (2**{power_of_2}): {constants.status_pipeline[flag]}"
    #     ax2.text(0, y, text)
    #     y -= 1

    fig2 = plt.figure(figsize=(10, 7.5))
    # text = fig2.text(0.5, 0.5, 'Hello path effects world!\nThis is the normal '
    #                           'path effect.\nPretty dull, huh?',
    #                 ha='center', va='center', size=20)
    y = 0.9
    for power_of_2 in power_of_2s:
        flag = 2**power_of_2
        text = f"Flag {flag} (2**{power_of_2}): {constants.status_pipeline[flag]}"
        fig2.text(0.1, y, text)
        y -= 0.025
    plt.show()

    # ax2.set_axis_off() # We only care about text, hide axis and border

    return fig


def integration_first_threshold_group(ramp_image, frame_to_plot=None, adu_threshold=62000, filename=None, vmin=None, vmax=None):
    """
    Display at which frame each pixel reach the requested count level

    :param ramp_image: Ramp image i.e raw data (only one integration accepted)
    :type ramp_image: np.array(n_frames, y, x) or np.array(1, n_frames, y, x)
    :param int frame_to_plot: [Optional] What frame index do you want to plot for the reference image (left plot)?
                              By default, last frame is used
    :param int adu_threshold: ADU count threshold you want to use. By default 62000 is used
    :param str filename: [Optional] Filename for the output file if you want to save it
    :param float vmin: [optional] If set, will limit the Vrange to focus on a subset of frames to look for partial
    saturation.
    :param float vmax: [optional] If set, will limit the Vrange to focus on a subset of frames to look for partial
    saturation.

    :return: return the figure
    :rtype: Matplotlib.Figure
    """

    # Get rid of the 4th dimension if we pass a ramp cube with only one integration
    ramp_image = ramp_image.squeeze()

    if ramp_image.ndim != 3:
        msg = f"ramp_image need to be a 3D array (ngroups, ny, nx), got {ramp_image.ndim} dimensions instead."
        raise ValueError(msg)

    (ngroups, ny, nx) = ramp_image.shape

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12., 6.), sharex=True, sharey=True)
    fig.subplots_adjust(left=0, right=1, wspace=0.1)

    if frame_to_plot is None:
        frame_to_plot = ngroups - 1
    else:
        if frame_to_plot < 0:
            frame_to_plot = ngroups + frame_to_plot

        if frame_to_plot >= ngroups:
            raise ValueError(f"frame_to_plot ({frame_to_plot}) can't be bigger than ramp length (Ngroups={ngroups})")

    image_to_plot = ramp_image[frame_to_plot, :, :]
    LOG.debug(f"Max signal value in data (frame = {frame_to_plot+1}) - {np.max(image_to_plot)}")

    # True if that particular frame is saturated. Display True up until a given frame number of each pixel
    saturation_mask = ramp_image >= adu_threshold
    frame_calc = np.argmax(saturation_mask, axis=0) + 1  # frame number = index + 1

    # Mask unsaturated pixels for the plot
    no_saturation_mask = ramp_image[-1, :, :] < adu_threshold
    masked_array = np.ma.masked_where(no_saturation_mask, frame_calc)

    kwargs = {}

    if vmax is not None:
        kwargs["vmax"] = vmax

    if vmin is not None:
        kwargs["vmin"] = vmin

    cs = ax1.imshow(image_to_plot, origin='lower', cmap="viridis")
    cs2 = ax2.imshow(masked_array, origin='lower', cmap="Set1", **kwargs)

    cbar = fig.colorbar(cs, ax=ax1)
    cbar.set_label("Signal [DN]")
    ax1.set_title(f"Detector signal at frame {frame_to_plot+1} / {ngroups}")
    ax1.set_xlabel("X [Pixel]")
    ax1.set_ylabel("Y [Pixel]")

    cbar2 = fig.colorbar(cs2, ax=ax2)
    cbar2.set_label(f"Frame Number")
    ax2.set_title(f"First saturated (DN > {adu_threshold}) frame (white = No saturation)")
    ax2.set_xlabel("X [Pixel]")
    ax2.set_ylabel("Y [Pixel]")

    if filename:
        fig.savefig(filename)

    return fig


def ramp_flag_first_occurence(filename, flag=2):
    """
    Given level 2 files, (cal or rates) will display the DQ image of one given flag for each file
    By default, will be the Saturation flag (2^1=2 ; flag=1)

    :param list(str) filenames: List of FITS filenames (or just one filename as a str)
    :param int flag: [optional] Display saturation by default. If set, represent the flag value. Can be a pure flag
                                (2) or a combination of multiple flags (5 = 4+1)

    :param list(str) titles: [optional] If set, will be used as title for each image.
                             If title_keyword is set, this parameter is ignored.
                             If neither titles, nor title_keyword are set, the filename is used as title
    :param str title_keyword: [optional] If set, will retrieve and display the value of that
                              header keyword for each image as its title.
                              This parameter takes precedence over titles if both are set

    :return: return the figure
    :rtype: Matplotlib.Figure
    """
    hdulist = fits.open(filename)
    sample_image = hdulist[1].data[0,-1,:,:]

    groupdq = hdulist[3].data

    (nints, ngroups, ny, nx) = groupdq.shape

    nb_plots = nints + 1
    nb_x_plots = int(np.ceil(np.sqrt(nb_plots)))
    nb_y_plots = int(np.ceil(nb_plots / nb_x_plots))

    titles = [f"Int {i+1}" for i in range(nints)]
    titles.insert(0, "Image")

    # If power of 2, we can get the flag meaning
    if flag & (flag - 1) == 0:
        flag_detail = constants.status_pipeline[flag]
    else:
        bits = mk.decompose_mask_status(flag)
        flag_detail = "+".join(map(str, bits))

    # Plot
    # define a figure which can contains several plots, you can define resolution and so on here...
    fig, axarr = plt.subplots(nb_y_plots, nb_x_plots, sharex='all', sharey='all', figsize=(9., 7.))
    fig.subplots_adjust(left=0.12, bottom=0.1, right=0.96, top=0.9, wspace=0.1, hspace=0.26)

    if nb_plots > 1:
        axarr = axarr.flatten()
    else:
        axarr = [axarr]

    # todo
    ax = axarr[0]
    ax.imshow(sample_image, origin='lower', cmap="viridis")

    # I have to make the full flag image myself because it's too big when I try to get it in one go
    full_flags = np.zeros_like(groupdq)

    for i in range(nints):
        int_mask = groupdq[i-1]  # i is the plot index, and the first one is the image, not the integration; so we are
        # shifted by one

        flag_image = mk.extract_flag_image(int_mask, flag)
        full_flags[i] = flag_image

    # True if that particular frame is saturated. Display True up until a given frame number of each pixel
    frame_calc = np.argmax(full_flags, axis=1) + 1  # frame number = index + 1

    # Mask pixels not flagged at all for the plot
    no_saturation_mask = np.sum(full_flags, axis=1) == 0
    del full_flags
    masked_array = np.ma.masked_where(no_saturation_mask, frame_calc)

    vmin = np.min(frame_calc)
    vmax = np.max(frame_calc)

    kwargs = {}
    kwargs["vmax"] = vmax
    kwargs["vmin"] = vmin

    for i in range(1, nb_plots):
        ax = axarr[i]
        title = titles[i]

        cs2 = ax.imshow(masked_array[i-1], origin='lower', cmap="Set1", **kwargs)

        ax.set_title(title)

    # Delete extra plots
    for j in range(i + 1, len(axarr)):
        fig.delaxes(axarr[j])

    # Display the colorbat only once for all integrations since we did the same vrange
    cbar2 = fig.colorbar(cs2, ax=fig.get_axes())
    cbar2.set_label(f"Frame Number")

    for int_i in range(0, nb_plots, nb_x_plots):
        axi = axarr[int_i]
        axi.set_ylabel("Y pixels")

    for int_i in range(nb_plots - nb_x_plots, nb_plots):
        axi = axarr[int_i]
        axi.set_xlabel("X pixels")

    fig.suptitle(f"First occurence of flag in integration: {flag_detail}")

    return fig

def _add_arrow_to_line2D(axes, line, arrow_locs=[0.2, 0.4, 0.6, 0.8], arrowstyle='-|>', arrowsize=1, transform=None):
    """
    Add arrows to a matplotlib.lines.Line2D at selected locations.

    source: https://stackoverflow.com/questions/26911898/matplotlib-curve-with-arrow-ticks

    Parameters:
    -----------
    axes:
    line: Line2D object as returned by plot command
    arrow_locs: list of locations where to insert arrows, % of total length
    arrowstyle: style of the arrow
    arrowsize: size of the arrow
    transform: a matplotlib transform instance, default to data coordinates

    Returns:
    --------
    arrows: list of arrows
    """
    if not isinstance(line, mlines.Line2D):
        raise ValueError("expected a matplotlib.lines.Line2D object")
    x, y = line.get_xdata(), line.get_ydata()

    arrow_kw = {
        "arrowstyle": arrowstyle,
        "mutation_scale": 10 * arrowsize,
    }

    color = line.get_color()
    use_multicolor_lines = isinstance(color, np.ndarray)
    if use_multicolor_lines:
        raise NotImplementedError("multicolor lines not supported")
    else:
        arrow_kw['color'] = color

    linewidth = line.get_linewidth()
    if isinstance(linewidth, np.ndarray):
        raise NotImplementedError("multiwidth lines not supported")
    else:
        arrow_kw['linewidth'] = linewidth

    if transform is None:
        transform = axes.transData

    arrows = []
    for loc in arrow_locs:
        s = np.cumsum(np.sqrt(np.diff(x) ** 2 + np.diff(y) ** 2))
        n = np.searchsorted(s, s[-1] * loc)
        arrow_tail = (x[n], y[n])
        arrow_head = (np.mean(x[n:n + 2]), np.mean(y[n:n + 2]))
        p = mpatches.FancyArrowPatch(
            arrow_tail, arrow_head, transform=transform,
            **arrow_kw)
        axes.add_patch(p)
        arrows.append(p)
    return arrows


def compare_pixel_ramps(ramp_image, metadata, pixel, filename=None):
    """
    Plots all ramps in one exposure for a given pixel. First frame value is substracted so all ramps start from the
    same point.

    :param ramp_image: Ramp image for one exposure
    :type ramp_image: ndarray(nints, ngroups, y, x)
    :param dict metadata: Metadata as dictionnary from 1st extension
    :param pixel:pixel coordinates (y,x) (0-indexed)
    :type pixel: tuple(int, int)
    :param str filename: savefig filename for plot
    them. But if you care about saturation, you might not want to do that.

    :return: return the figure
    :rtype: Matplotlib.Figure
    """

    # Plot
    fig, ax = plt.subplots(figsize=(14., 8.))  # size in inches
    fig.subplots_adjust(left=0.06, bottom=0.1, right=0.97, top=0.92, wspace=0.1, hspace=0.22)

    nints, ngroups, ny, nx = ramp_image.shape

    y_p, x_p = pixel

    if x_p < 0:
        raise ValueError("Pixel x coordinate can't be lower than 0")

    if y_p < 0:
        raise ValueError("Pixel y coordinate can't be lower than 0")

    ramps = ramp_image[:, :, y_p, x_p].astype(float)

    ylabel = "Signal [DN]"

    times = np.arange(ngroups) * metadata["TGROUP"]

    firstint_start = metadata["PARTSTRT"]
    lastint_end = metadata["PARTSTOP"]

    ramps[0,:firstint_start] = np.nan
    ramps[-1,lastint_end:] = np.nan

    plot_colors = plt.cm.nipy_spectral(np.linspace(0, 1, nints))

    for i, ramp in enumerate(ramps):
        int_color = plot_colors[i]

        ax.plot(times, ramp, marker="o", markersize=2, color=int_color, linestyle="-", label=f"Integration {i+1}")

    ax.legend()

    ax.xaxis.grid(True, which='major', color='#000000', linestyle='--')
    ax.yaxis.grid(True, which='major', color='#000000', linestyle='--')
    ax.set_xlabel("Time [s]")


    ax.set_ylabel(ylabel)

    fig.suptitle(f"Plot all integration for pixel (x, y) = {pixel}")

    if filename is not None:
        fig.savefig(filename)

    return fig


class InteractiveDQ:
    def __init__(self, image, dq):
        # Two columns: main image (wider) + text panel (narrower)
        self.fig, (self.ax_img, self.ax_txt) = plt.subplots(
            ncols=2,
            figsize=(8, 4),
            gridspec_kw={"width_ratios": [3, 1]},
            constrained_layout=True,  # or use fig.tight_layout() at the end
        )

        self.image = image
        self.dq = dq

        # Compute Zscale
        zscale = interval.ZScaleInterval(n_samples=600, contrast=0.25, max_reject=0.5, min_npixels=5, krej=2.5,
                                         max_iterations=5)
        (vmin, vmax) = zscale.get_limits(image)
        normalization = colors.Normalize(vmin=vmin, vmax=vmax)  # Linear

        im = self.ax_img.imshow(image, norm=normalization, cmap="viridis", origin="lower")
        self.ax_img.set_title("Main image")
        # Optional colorbar
        self.fig.colorbar(im, ax=self.ax_img)

        # Text-only axes
        self.ax_txt.set_axis_off()
        self.annotation_header = (
            "Click on a pixel in the image on the left to see its DQ flags.\n\n"
        )

        self.annotation = self.ax_txt.text(
            0.1, 1.0, self.annotation_header,
            transform=self.ax_txt.transAxes,
            va="top", ha="left",
            wrap=True,
            fontsize=10,
        )

        self.center, = self.ax_img.plot(0, 0, "+", color="red", label="Selected Center")

        self.ax_img.figure.canvas.mpl_connect('button_press_event', self)

    def __call__(self, event):
        ix = int(np.round(event.xdata))
        iy = int(np.round(event.ydata))

        pixel_dq = self.dq[iy, ix]
        print(f"Pixel: ({ix}, {iy}) - DQ: {pixel_dq}")

        self.center.set_data([ix], [iy])

        indiv_flags = mk.decompose_mask_status(pixel_dq, )

        pixel_dq_info = f"Pixel: (x,y) = ({ix}, {iy})\n"
        if not indiv_flags:
            pixel_dq_info += "* No flags set\n"
        for flag in indiv_flags:
            pixel_dq_info += f"* {flag}: {constants.status_pipeline[flag]}\n"

        print(pixel_dq_info)

        self.annotation.set_text(self.annotation_header + pixel_dq_info)

        self.fig.canvas.draw_idle()


class InteractiveRampDQ:
    neighbor_marker = {
    "n": "^",
    "s": "v",
    "e": ">",
    "w": "<",
    "se": "*",
    "sw": "D",
    "ne": "s",
    "nw": "P",
    }

    neigbor_shifts = [  # key, y, x
        ("n", 1, 0),
        ("s", -1, 0),
        ("e", 0, 1),
        ("w", 0, -1),
        ("se", -1, 1),
        ("sw", -1, -1),
        ("ne", 1, 1),
        ("nw", 1, -1),
    ]

    def __init__(self, datacube, dqcube=None, xpos=None, ypos=None, intpos=None, grouppos=None):
        """
        Initializes and configures a dynamic visualization tool for analyzing data cubes.

        This class is responsible for setting up a visualization interface with components
        to view and interact with data cubes and their attributes. It allows for selecting
        specific pixels, visualizing integrations and groups, exploring neighbors,
        and viewing associated data qualities (DQ flags).

        It uses matplotlib for plotting and controls the interface dynamically with sliders
        for seamless interaction with different components of the data cube.

        Attributes:
            datacube: The main data cube to be visualized.
            dqcube: The data quality cube associated with the primary data cube.
            ny: The height (number of rows) of the data cube.
            nx: The width (number of columns) of the data cube.
            ax_dict: Dictionary holding matplotlib axes identified by predefined keys.
            ax_sint: Matplotlib axis for integration slider.
            ax_sgroup: Matplotlib axis for group slider.
            ax_im: Matplotlib axis for displaying the selected image slice.
            ax_colorbar: Axis for the associated colorbar of the image.
            ax_int: Axis for displaying integration data.
            ax_dq: Axis for displaying the data quality flags.
            int_i: Current integration frame index.
            group_i: Current group index.
            xi: Current x-coordinate of the selected pixel (column).
            yi: Current y-coordinate of the selected pixel (row).
            im: The current image display of the selected group and integration.
            center: Marker for the currently selected pixel center.
            neighbor_center: Dictionary mapping neighbor positions to their respective matplotlib markers.
            int_line: Line plot displaying the integration value for the selected pixel over time.
            neighbor_lines: Dictionary mapping neighbor positions to their respective line plots.
            dq_im: Image visualization for data quality flags.
            fig: Matplotlib figure used for the visualization layout.
            slider_int: Slider widget for controlling the integration index.
            slider_group: Slider widget for controlling the group index.

        Args:
            datacube: Data cube containing scientific data to be visualized.
            dqcube: Optional; Data quality cube associated with the given data cube. If not given, no DQ info will be provided.
            xpos: Optional; Initial x-coordinate of the selected pixel. Defaults to 0.
            ypos: Optional; Initial y-coordinate of the selected pixel. Defaults to 0.
            intpos: Optional; Initial index of the integration frame. Defaults to 0.
            grouppos: Optional; Initial index of the group frame. Defaults to the last group.
        """

        self.datacube = datacube

        # if dqcube is None:
        #     dqcube = np.zeros_like(datacube, dtype=np.uint32)

        self.dqcube = dqcube

        nints, ngroups, ny, nx = datacube.shape
        self.ny = ny
        self.nx = nx

        mosaic = """
        cfdd
        cfdd
        cfee
        aaee
        bbee
        """

        if self.dqcube is None:
            mosaic = mosaic.replace("e", "d")

        self.fig = plt.figure(constrained_layout=True)
        self.ax_dict = self.fig.subplot_mosaic(mosaic,
                                               # set the height ratios between the rows
                                               height_ratios=[1, 1, 1, 0.1, 0.1],
                                               # set the width ratios between the columns
                                               width_ratios=[1, 0.1, 1, 1],
                                               )

        self.ax_sint = self.ax_dict["a"]
        self.ax_sgroup = self.ax_dict["b"]
        self.ax_im = self.ax_dict["c"]
        self.ax_colorbar = self.ax_dict["f"]
        self.ax_int = self.ax_dict["d"]

        if self.dqcube is not None:
            self.ax_dq = self.ax_dict["e"]
        else:
            self.ax_dq = None

        if intpos is None:
            intpos = 0
        if grouppos is None:
            grouppos = ngroups - 1
        if xpos is None:
            xpos = 0
        if ypos is None:
            ypos = 0



        self.int_i = intpos
        self.group_i = grouppos
        self.xi = xpos
        self.yi = ypos

        self.im = self.ax_im.imshow(datacube[self.int_i, self.group_i], origin="lower")
        cbar = self.fig.colorbar(self.im, cax=self.ax_colorbar)
        self._update_image_title()

        self.center, = self.ax_im.plot(self.xi, self.yi, "+", color="red", label="Selected Center")

        self.neighbor_center = {}
        for key, marker in self.neighbor_marker.items():
            self.neighbor_center[key], = self.ax_im.plot(self.xi, self.yi, marker, color="black")

        self.ax_im.figure.canvas.mpl_connect('button_press_event', self.select_pixel)

        # For first draw, we draw twice since _update_integration also does it. But it's needed or else
        # xdata doesn't have the right size.
        self.int_line, = self.ax_int.plot(datacube[self.int_i, :, self.yi, self.xi], color="red")

        # Draw neigbors integrations Identified by position (n=North, ne= North-East, etc...)
        # For now, just placeholders we can update later
        self.neighbor_lines = {}
        for key, marker in self.neighbor_marker.items():
            self.neighbor_lines[key], = self.ax_int.plot(datacube[self.int_i, :, self.yi, self.xi], ":", label=key, marker=marker)

        self.ax_int.legend()

        if self.dqcube is not None:

            cmap = colors.ListedColormap(["white", "#1f77b4"])
            self.dq_im = self.ax_dq.imshow(np.zeros((32, ngroups)), aspect="auto",
                                           cmap=cmap, vmin=0, vmax=1, origin="lower")
            # self.ax_dq.set_yticks(range(32))

            dq_ticks = [""] * 32
            for key, value in constants.pixel_flags.items():
                dq_ticks[value.bit_length() - 1] = key

            # Put ticks at integer positions and map to labels
            self.ax_dq.yaxis.set_major_locator(ticker.FixedLocator(range(32)))
            self.ax_dq.yaxis.set_major_formatter(
                ticker.FuncFormatter(lambda v, pos: dq_ticks[int(np.round(v))] if -0.5 <= v < 31.5 else ""))

            # self.ax_dq.set_yticklabels(dq_ticks)
            self.ax_dq.set_xlabel("x")
            self.ax_dq.set_title("Active flags per x (1 = colored)")

            # Optional: gridlines for readability
            for j in range(32 + 1):
                self.ax_dq.axhline(j - 0.5, color="#ddd", lw=0.5, zorder=0)

            self.dq_im.set_clim(0, 1)
            self.ax_dq.sharex(self.ax_int)

        self._update_integrations()


        # create the sliders
        self.slider_int = widgets.Slider(
            self.ax_sint, "Int", 0, nints - 1,
            valinit=self.int_i, valstep=1,
            color="green"
        )
        nticks = min(10, nints)
        self.ax_sint.add_artist(self.ax_sint.xaxis)
        sl_xticks = np.arange(0, nints, int(nints / nticks))
        self.ax_sint.set_xticks(sl_xticks)

        self.slider_group = widgets.Slider(
            self.ax_sgroup, "Group", 0, ngroups - 1,
            valinit=self.group_i, valstep=1,
            initcolor='none'  # Remove the line marking the valinit position.
        )
        nticks = min(10, ngroups)
        self.ax_sgroup.add_artist(self.ax_sgroup.xaxis)
        sl_xticks = np.arange(0, ngroups, int(ngroups / nticks))
        self.ax_sgroup.set_xticks(sl_xticks)

        self.slider_int.on_changed(self.image_update)
        self.slider_group.on_changed(self.image_update)

    def _update_neigbors_int(self):
        # Prepare range values to ensure main + neighbors all fit in the axis range
        min_value = np.inf
        max_value = -np.inf
        for key, dy, dx in self.neigbor_shifts:

            nyi = self.yi + dy
            nxi = self.xi + dx

            outside_boundaries = (nyi < 0) or (nyi >= self.ny) or (nxi < 0) or (nxi >= self.nx)

            if outside_boundaries:
                self.neighbor_lines[key].set_visible(False)
                self.neighbor_lines[key].set_label("_hidden")

                self.neighbor_center[key].set_visible(False)
                self.neighbor_center[key].set_label("_hidden")
            else:
                # Set visibility again for neigbor
                if not self.neighbor_lines[key].get_visible():
                    self.neighbor_lines[key].set_visible(True)
                    self.neighbor_lines[key].set_label(key)

                    self.neighbor_center[key].set_visible(True)

                # Update integration
                data = self.datacube[self.int_i, :, nyi, nxi]
                min_value = min(min_value, np.nanmin(data))
                max_value = max(max_value, np.nanmax(data))
                self.neighbor_lines[key].set_ydata(data)

                # Update neighbor position in image
                self.neighbor_center[key].set_data([nxi], [nyi])
        return min_value, max_value

    def _update_image_title(self):
        self.ax_im.set_title(f"int: {self.int_i} ; group:{self.group_i}")

    def _update_integrations(self):
        pixel_ramp = self.datacube[self.int_i, :, self.yi, self.xi]
        self.int_line.set_ydata(pixel_ramp)

        min_value, max_value = self._update_neigbors_int()
        min_value = min(min_value, np.nanmin(pixel_ramp))
        max_value = max(max_value, np.nanmax(pixel_ramp))

        self.ax_int.legend()

        self.ax_int.set_ylim(min_value, max_value)
        self.ax_int.set_title(f"Pixel: (x,y) = ({self.xi}, {self.yi})")

        if self.dqcube is not None:
            dq_int = self.dqcube[self.int_i, :, self.yi, self.xi]
            dq_image = mk.get_separated_dq_array(dq_int)
            self.dq_im.set_data(dq_image.T)
        self.fig.canvas.draw_idle()

    def image_update(self, val):
        old_int_i = self.int_i
        self.int_i = self.slider_int.val
        self.group_i = self.slider_group.val
        data = self.datacube[self.int_i, self.group_i]
        self.im.set_data(data)
        vmin = np.nanmin(data)
        vmax = np.nanmax(data)
        self.im.set_clim(vmin, vmax)
        self._update_image_title()

        if old_int_i != self.int_i:
            self._update_integrations()

        self.fig.canvas.draw_idle()

    def select_pixel(self, event):
        # Only act if the click was in the image axis.
        if event.inaxes == self.ax_im:
            self.xi = int(np.round(event.xdata))
            self.yi = int(np.round(event.ydata))

            self.center.set_data([self.xi], [self.yi])
            self._update_integrations()

            self.fig.canvas.draw_idle()
        elif (event.inaxes == self.ax_int) or ((self.ax_dq is not None) and (event.inaxes == self.ax_dq)):
            group_i = int(np.round(event.xdata))

            self.slider_group.set_val(group_i)
