"""
Manipulation of matrices to select regions of interest
"""
import logging
from typing import Dict, List, Optional, Tuple

import matplotlib.patches as mpatches
import numpy as np
from scipy import ndimage

LOG = logging.getLogger(__name__)


def crop_image(big_image: np.ndarray, small_image: np.ndarray, big_meta: Optional[Dict] = None,
               small_meta: Optional[Dict] = None) -> np.ndarray:
    """
    Will crop the first image to the size of the second image. If metadatas are provided for both images, with shift the
    first image to the position of the second, using SUBSTRT1 and SUBSTRT2 metadata

    :param big_image: Image to be cropped
    :param small_image:
    :param big_meta:   [Optional] Metadata dict for big image
    :param small_meta: [Optional] Metadata dict for small image
    :return: Cropped image of big image (same shape as small image)
    :rtype: np.array(y, x)
    """

    (y_size, x_size) = small_image.shape

    if (big_meta is None) != (small_meta is None):
        raise ValueError("One header is defined but the other is missing.")

    if big_meta is None or small_meta is None:
        y_start = 0
        x_start = 0
    else:
        x_big = big_meta["SUBSTRT1"] - 1  # Because FITS start at 1, but indexes in Python start at 0
        y_big = big_meta["SUBSTRT2"] - 1  # Because FITS start at 1, but indexes in Python start at 0

        x_small = small_meta["SUBSTRT1"] - 1  # Because FITS start at 1, but indexes in Python start at 0
        y_small = small_meta["SUBSTRT2"] - 1  # Because FITS start at 1, but indexes in Python start at 0

        y_start = y_small - y_big
        x_start = x_small - x_big

    y_stop = y_start + y_size
    x_stop = x_start + x_size

    # We don't want to change the original image via cropped
    cropped_image = big_image[y_start:y_stop, x_start:x_stop].copy()

    return cropped_image


def abs_to_rel_pixels(abs_coords: Tuple[int, int], metadatas: Dict) -> Tuple[int, int]:
    """
    Given absolute coordinates (Coordinates in fictious FULL array), will return the coordinates for the current image
    (as described by metadatas) given its point of origin and size.

    Will return an IndexError if the calculated index is outside the range of the image.

    :param abs_coords: Absolute coordinates (x, y)
    :param metadatas:
    :return: Relative coordinates depending on the Sub-array if there's one (x, y)
    """

    (abs_x, abs_y) = abs_coords

    rel_x = abs_x - (metadatas["SUBSTRT1"] - 1)
    rel_y = abs_y - (metadatas["SUBSTRT2"] - 1)

    x_max = metadatas["SUBSIZE1"] - 1
    y_max = metadatas["SUBSIZE2"] - 1
    if (rel_x < 0) or (rel_y < 0) or (rel_x > x_max) or (rel_y > y_max):
        LOG.exception(
            "Pixel coordinates (x,y)=({},{}) outside of Image range (Xmax,Ymax)=({},{})".format(rel_x, rel_y, x_max,
                                                                                                y_max))
        raise IndexError

    return rel_x, rel_y


def find_array_intersect(metadatas: List[Dict]) -> Tuple[Tuple[int, int], Tuple[int, int]]:
    """
    Given a list of metadatas dictionaries, will return the absolute coordinates that are common to all images

    :param metadatas: list of metadata dictionaries, one per image

    :return: Coordinates of [(x_min, x_max), (y_min, y_max)] that define the common rectangle of all images. Return None
             if no common indexes exists bot X, Y or both
             Note: You define the rectangle with [x_min:x_max+1, y_min:y_max+1] meaning the maximum pixel index
             is (x_max, y_max)
    """

    x_starts = []
    x_stops = []
    y_starts = []
    y_stops = []

    for meta in metadatas:
        x_start = meta["SUBSTRT1"] - 1
        y_start = meta["SUBSTRT2"] - 1
        x_stop = x_start + meta["SUBSIZE1"]
        y_stop = y_start + meta["SUBSIZE2"]

        x_starts.append(x_start)
        x_stops.append(x_stop)
        y_starts.append(y_start)
        y_stops.append(y_stop)

    x_min = np.max(x_starts)
    y_min = np.max(y_starts)
    x_max = np.min(x_stops)
    y_max = np.min(y_stops)

    if x_min > x_max:
        x_range = None
    else:
        x_range = (x_min, x_max)

    if y_min > y_max:
        y_range = None
    else:
        y_range = (y_min, y_max)

    return x_range, y_range


def select_sub_image(image, center, radius, corner=False):
    """
    Select a subarray from an input image, given a center and a radius (here equivalent to a half-width of a square)

    :param image: input 2D image
    :type image: np.array(y, x)
    :param center: Center (y,x) (in pixels). Float will be force converted to int
    :type center: tuple(int, int)
    :param int radius: half-width of the cropped image (width = 2 * size + 1). Float will be force converted to int
    :param bool corner: By default, False. Return the corner coordinates (y,x) as 2nd value of a tuple with image.
    :return: cropped image with size = 2 * radius + 1 for each dimension. If corner=true, return the coordinates (y,x)
             of the lower left corner
    :rtype: np.array(y, x)
    """

    yc, xc = center

    # Force conversion to integer
    xc = int(xc)
    yc = int(yc)
    radius = int(radius)

    x1 = xc - radius
    x2 = xc + radius
    y1 = yc - radius
    y2 = yc + radius

    x1min = y1min = 0
    (y2max, x2max) = image.shape

    # Index go from 0 to shape - 1
    if (x1 < x1min) or (x2 >= x2max) or (y1 < y1min) or (y2 >= y2max):
        raise ValueError(
            f"sub-image (center: {center} ; half-size: {radius}) cross border of array of shape {image.shape}")

    sub_image = image[y1:y2 + 1, x1:x2 + 1]

    if corner:
        return sub_image, (y1, x1)
    else:
        return sub_image


def subpixel_shift(image, dy, dx):
    """
    Shift an image with a sub-pixel precision.
    This uses a property of the Fourier transform :
    a shift in the space domain corresponds to a phase rotation in the frequency domain.
    For integer shift, this method gives the same result that numpy roll function, within numerical precision
    https://docs.scipy.org/doc/scipy/reference/generated/scipy.ndimage.fourier_shift.html

    :param image: The input image. By default, we expect a 2D image. If a cube is given, we assume (n_slices, ny,
    nx) and apply the shifts to the first 2 dimensions.
    :type image: np.ndarray(ny, nx), float
    :param float dy: shift on the y axis
    :param float dx: shift on the x axis

    :return: shifted image
    :rtype: np.ndarray(ny, nx), float
    """
    shifts = [dy, dx]
    if image.ndim > 2:
        for i in range(image.ndim - 2):
            shifts.insert(0, 0)

    intermediate = ndimage.fourier_shift(np.fft.fftn(image), shifts)
    result = np.fft.ifftn(intermediate).real
    return result


def make_box(center, width, height, **kwargs):
    """
    Create a patches.Rectangle. The only difference is we use the center instead of the lower left corner

    All extra parameters will
    be passed to the Rectangle object

    :param center: (x,y) position of the box center
    :type center: tuple(float, float)
    :param float width: rectangle width
    :param float height: rectangle height


    :return:
    """
    half_width = width / 2
    half_height = height / 2
    lower_left_x = center[0] - half_width
    lower_left_y = center[1] - half_height
    lower_left = (lower_left_x, lower_left_y)
    box = mpatches.Rectangle(lower_left, width, height, **kwargs)

    return box
