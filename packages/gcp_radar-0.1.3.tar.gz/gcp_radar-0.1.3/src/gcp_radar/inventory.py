#!/usr/bin/env python3
"""
GCP Resource Inventory Script
Lists all running/active resources across your GCP projects:
Compute Engine, Cloud SQL, Cloud Functions, GKE, Cloud Storage, Cloud Run, Firestore, Pub/Sub, and more.

Requirements:
    pip install google-cloud-compute google-cloud-functions google-api-python-client rich

Usage:
    gcp-radar inventory                            # uses default GCP project from gcloud config
    gcp-radar inventory --project my-project
    gcp-radar inventory --all-projects
    gcp-radar inventory --export inventory.csv
"""

# ── stdlib ──────────────────────────────────────────────────────────────────
import argparse
import csv
import sys
from datetime import datetime

# ── Google Cloud clients ─────────────────────────────────────────────────────
from google.cloud import compute_v1, functions_v1, container_v1, storage, run_v2, firestore, pubsub_v1
from google.api_core.exceptions import GoogleAPIError, PermissionDenied
import googleapiclient.discovery  # Cloud SQL Admin API (no standalone package exists on PyPI)

try:
    from rich.console import Console
    from rich.table import Table
    from rich import box
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False

console = Console() if RICH_AVAILABLE else None

COLS = ["ProjectID", "Service", "Name", "ID", "Type/Size", "Status", "Region", "Extra"]


# ─────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────

def get_label(resource, key="name"):
    if not resource or not hasattr(resource, key):
        return "-"
    val = getattr(resource, key, "-")
    return str(val) if val else "-"


def safe_call(fn, *args, default=None, **kwargs):
    try:
        return fn(*args, **kwargs)
    except PermissionDenied:
        service = fn.__self__.__class__.__name__ if hasattr(fn, '__self__') else "GCP"
        print(f"  [!] Access denied: {service} – skipping")
        return default
    except GoogleAPIError as e:
        print(f"  [!] Error: {e}")
        return default


def row(project_id, service, name, rid, type_size, status, region, extra):
    return {
        "ProjectID": project_id,
        "Service":   service,
        "Name":      name,
        "ID":        rid,
        "Type/Size": type_size,
        "Status":    status,
        "Region":    region,
        "Extra":     extra,
    }


# ─────────────────────────────────────────────
# Collectors
# ─────────────────────────────────────────────

def collect_compute_instances(project_id, region=None):
    """Collect Compute Engine VM instances."""
    client = compute_v1.InstancesClient()
    rows = []
    try:
        if region:
            request = compute_v1.ListInstancesRequest(
                project=project_id,
                zone=f"{region}-a",
            )
            for instance in client.list(request=request):
                rows.append(row(project_id, "Compute Engine",
                    instance.name, instance.id,
                    instance.machine_type.split("/")[-1],
                    instance.status, region,
                    f"CPU: {instance.machine_type}"))
        else:
            request = compute_v1.AggregatedListInstancesRequest(project=project_id)
            for zone, response in client.aggregated_list(request=request):
                if response.instances:
                    for instance in response.instances:
                        zone_name = zone.split("/")[-1]
                        rows.append(row(project_id, "Compute Engine",
                            instance.name, instance.id,
                            instance.machine_type.split("/")[-1],
                            instance.status, zone_name,
                            f"CPU: {instance.machine_type}"))
    except GoogleAPIError as e:
        print(f"  [!] Compute Engine error: {e}")
    return rows


def collect_cloud_sql(project_id):
    """Collect Cloud SQL instances via the SQL Admin API (google-api-python-client)."""
    rows = []
    try:
        # 'google-cloud-sql' does not exist on PyPI — use the discovery client instead
        service = googleapiclient.discovery.build('sqladmin', 'v1beta4')
        request = service.instances().list(project=project_id)
        while request is not None:
            response = request.execute()
            for instance in response.get("items", []):
                rows.append(row(
                    project_id, "Cloud SQL",
                    instance.get("name", "-"),
                    instance.get("name", "-"),
                    instance.get("databaseVersion", "-"),
                    instance.get("state", "-"),
                    instance.get("region", "-"),
                    instance.get("databaseVersion", "-"),
                ))
            request = service.instances().list_next(
                previous_request=request, previous_response=response
            )
    except GoogleAPIError as e:
        print(f"  [!] Cloud SQL error: {e}")
    except Exception as e:
        print(f"  [!] Cloud SQL unexpected error: {e}")
    return rows


def collect_cloud_functions(project_id, region=None):
    """Collect Cloud Functions."""
    client = functions_v1.CloudFunctionsServiceClient()
    rows = []
    try:
        location = f"projects/{project_id}/locations/{region or '-'}"
        request = functions_v1.ListFunctionsRequest(location=location)
        for function in client.list_functions(request=request):
            func_region = function.name.split("/")[3]
            runtime = function.runtime or "-"
            rows.append(row(project_id, "Cloud Functions",
                function.name.split("/")[-1], function.name,
                runtime, "ACTIVE" if function.status == 1 else "UNKNOWN",
                func_region,
                f"Runtime: {runtime}"))
    except GoogleAPIError as e:
        print(f"  [!] Cloud Functions error: {e}")
    return rows


def collect_gke_clusters(project_id, region=None):
    """Collect GKE clusters."""
    client = container_v1.ClusterManagerClient()
    rows = []
    try:
        parent = f"projects/{project_id}/locations/{region or '-'}"
        request = container_v1.ListClustersRequest(parent=parent)
        response = client.list_clusters(request=request)
        for cluster in response.clusters:
            rows.append(row(project_id, "GKE",
                cluster.name, cluster.name,
                f"{len(cluster.node_pools)} pools", cluster.status.name,
                cluster.location,
                f"Kubernetes: {cluster.initial_cluster_version}"))
    except GoogleAPIError as e:
        print(f"  [!] GKE error: {e}")
    return rows


def collect_cloud_storage(project_id):
    """Collect Cloud Storage buckets."""
    client = storage.Client(project=project_id)
    rows = []
    try:
        for bucket in client.list_buckets():
            created = bucket.time_created.strftime('%Y-%m-%d') if bucket.time_created else '-'
            rows.append(row(project_id, "Cloud Storage",
                bucket.name, bucket.name,
                "-", "active",
                bucket.location or "-",
                f"Created: {created}"))
    except GoogleAPIError as e:
        print(f"  [!] Cloud Storage error: {e}")
    return rows


def collect_cloud_run(project_id, region=None):
    """Collect Cloud Run services."""
    rows = []
    try:
        client = run_v2.ServicesClient()
        parent = f"projects/{project_id}/locations/{region or '-'}"
        request = run_v2.ListServicesRequest(parent=parent)
        for service in client.list_services(request=request):
            svc_region = service.name.split("/")[3]
            rows.append(row(project_id, "Cloud Run",
                service.name.split("/")[-1], service.name,
                "-", "active",
                svc_region,
                f"URL: {service.uri}"))
    except GoogleAPIError as e:
        print(f"  [!] Cloud Run error: {e}")
    return rows


def collect_vertex_models(project_id, region=None):
    """Collect Vertex AI models."""
    rows = []
    try:
        from google.cloud import aiplatform_v1
        location = region or "us-central1"
        client = aiplatform_v1.ModelServiceClient(
            client_options={"api_endpoint": f"{location}-aiplatform.googleapis.com"}
        )
        parent = f"projects/{project_id}/locations/{location}"
        for model in client.list_models(request={"parent": parent}):
            display = getattr(model, "display_name", model.name.split("/")[-1])
            labels = getattr(model, "labels", None)
            lbl_str = str(dict(labels)) if labels else "-"
            rows.append(row(project_id, "Vertex AI Model",
                display, model.name,
                getattr(model, "etag", "-"),
                "-", location,
                f"Labels: {lbl_str}"))
    except GoogleAPIError as e:
        print(f"  [!] Vertex AI Models error: {e}")
    except Exception as e:
        print(f"  [!] Vertex AI Models unexpected error: {e}")
    return rows


def collect_vertex_endpoints(project_id, region=None):
    """Collect Vertex AI endpoints."""
    rows = []
    try:
        from google.cloud import aiplatform_v1
        location = region or "us-central1"
        client = aiplatform_v1.EndpointServiceClient(
            client_options={"api_endpoint": f"{location}-aiplatform.googleapis.com"}
        )
        parent = f"projects/{project_id}/locations/{location}"
        for ep in client.list_endpoints(request={"parent": parent}):
            name = getattr(ep, "display_name", ep.name.split("/")[-1])
            deployed = getattr(ep, "deployed_models", [])
            status = "deployed" if deployed else "undeployed"
            rows.append(row(project_id, "Vertex AI Endpoint",
                name, ep.name,
                "-", status, location,
                f"Deployed models: {len(deployed)}"))
    except GoogleAPIError as e:
        print(f"  [!] Vertex AI Endpoints error: {e}")
    except Exception as e:
        print(f"  [!] Vertex AI Endpoints unexpected error: {e}")
    return rows


def collect_vertex_featurestores(project_id, region=None):
    """Collect Vertex AI Featurestores."""
    rows = []
    try:
        from google.cloud import aiplatform_v1
        location = region or "us-central1"
        client = aiplatform_v1.FeaturestoreServiceClient(
            client_options={"api_endpoint": f"{location}-aiplatform.googleapis.com"}
        )
        parent = f"projects/{project_id}/locations/{location}"
        for fs in client.list_featurestores(request={"parent": parent}):
            name = getattr(fs, "display_name", fs.name.split("/")[-1])
            rows.append(row(project_id, "Vertex AI Featurestore",
                name, fs.name,
                "-", "active", location,
                f"Online serving: {getattr(fs, 'online_serving_config', '-')}"))
    except GoogleAPIError as e:
        print(f"  [!] Vertex AI Featurestores error: {e}")
    except Exception as e:
        print(f"  [!] Vertex AI Featurestores unexpected error: {e}")
    return rows


def collect_firestore(project_id):
    """Collect Firestore databases."""
    rows = []
    try:
        client = firestore.Client(project=project_id)
        # Firestore doesn't have a list-databases API via this client;
        # we probe existence by attempting a lightweight operation
        collections = list(client.collections())
        rows.append(row(project_id, "Firestore",
            "default", "(default)",
            "Native", "active",
            "global",
            f"Collections: {len(collections)}"))
    except GoogleAPIError as e:
        print(f"  [!] Firestore error: {e}")
    except Exception as e:
        print(f"  [!] Firestore unexpected error: {e}")
    return rows


def collect_pubsub(project_id):
    """Collect Pub/Sub topics and subscriptions."""
    publisher = pubsub_v1.PublisherClient()
    subscriber = pubsub_v1.SubscriberClient()
    rows = []
    try:
        project_path = f"projects/{project_id}"
        for topic in publisher.list_topics(request={"project": project_path}):
            topic_name = topic.name.split("/")[-1]
            rows.append(row(project_id, "Pub/Sub Topic",
                topic_name, topic.name,
                "-", "active", "-",
                f"Topic: {topic_name}"))
        for subscription in subscriber.list_subscriptions(request={"project": project_path}):
            sub_name = subscription.name.split("/")[-1]
            rows.append(row(project_id, "Pub/Sub Subscription",
                sub_name, subscription.name,
                "-", "active", "-",
                f"Subscription: {sub_name}"))
    except GoogleAPIError as e:
        print(f"  [!] Pub/Sub error: {e}")
    return rows


# ─────────────────────────────────────────────
# Export / Display
# ─────────────────────────────────────────────

def export_csv(rows, output_path):
    """Export rows to CSV file."""
    with open(output_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=COLS)
        writer.writeheader()
        writer.writerows(rows)
    print(f"✓ Inventory exported to {output_path}")


def display_table(rows):
    """Display rows in a rich table."""
    if not RICH_AVAILABLE or not rows:
        for r in rows:
            print("\t".join(str(r.get(c, "-")) for c in COLS))
        return

    table = Table(title="GCP Resource Inventory", box=box.ROUNDED)
    for col in COLS:
        table.add_column(col, style="cyan")
    for r in rows:
        table.add_row(*[str(r.get(c, "-")) for c in COLS])
    console.print(table)


def run_inventory(projects, regions=None, export_path=None):
    """Run full inventory scan across specified projects."""
    all_rows = []

    for project_id in projects:
        print(f"\n── Project: {project_id} ──")

        collectors = [
            ("Compute Instances",      lambda p=project_id: collect_compute_instances(p)),
            ("Cloud SQL",              lambda p=project_id: collect_cloud_sql(p)),
            ("Cloud Functions",        lambda p=project_id: collect_cloud_functions(p)),
            ("GKE Clusters",           lambda p=project_id: collect_gke_clusters(p)),
            ("Cloud Storage",          lambda p=project_id: collect_cloud_storage(p)),
            ("Cloud Run",              lambda p=project_id: collect_cloud_run(p)),
            ("Vertex AI Models",       lambda p=project_id: collect_vertex_models(p)),
            ("Vertex AI Endpoints",    lambda p=project_id: collect_vertex_endpoints(p)),
            ("Vertex AI Featurestores",lambda p=project_id: collect_vertex_featurestores(p)),
            ("Firestore",              lambda p=project_id: collect_firestore(p)),
            ("Pub/Sub",                lambda p=project_id: collect_pubsub(p)),
        ]

        for label, collector in collectors:
            print(f"  Collecting {label} … ", end="", flush=True)
            result = safe_call(collector, default=[])
            if result is None:
                result = []
            print(f"{len(result)} found")
            all_rows.extend(result)

    if export_path:
        export_csv(all_rows, export_path)
    else:
        display_table(all_rows)

    return all_rows


def main():
    parser = argparse.ArgumentParser(description="GCP Resource Inventory Scanner")
    subparsers = parser.add_subparsers(dest="command")

    inv = subparsers.add_parser("inventory", help="Scan GCP resources")
    inv.add_argument("--project", help="GCP project ID")
    inv.add_argument("--all-projects", action="store_true", help="Scan all accessible projects")
    inv.add_argument("--region", help="Specific region (e.g., us-central1)")
    inv.add_argument("--export", help="Export inventory to CSV file")
    inv.add_argument("--diagram", help="Generate architecture diagram")

    args = parser.parse_args()

    if args.command == "inventory":
        projects = []
        if args.all_projects:
            print("  [!] --all-projects not yet implemented")
            sys.exit(1)
        elif args.project:
            projects = [args.project]
        else:
            import subprocess
            try:
                result = subprocess.run(
                    ["gcloud", "config", "get-value", "project"],
                    capture_output=True, text=True, check=True
                )
                projects = [result.stdout.strip()]
            except Exception as e:
                print(f"  [!] Could not determine GCP project: {e}")
                sys.exit(1)

        rows = run_inventory(projects, export_path=args.export)

        if args.diagram and args.export:
            from gcp_radar.drawio import build_drawio
            import xml.etree.ElementTree as ET
            mxfile = build_drawio(rows, project_id=projects[0])
            xml_str = ET.tostring(mxfile, encoding="unicode")
            with open(args.diagram, "w") as f:
                f.write(xml_str)
            print(f"✓ Architecture diagram generated: {args.diagram}")
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
