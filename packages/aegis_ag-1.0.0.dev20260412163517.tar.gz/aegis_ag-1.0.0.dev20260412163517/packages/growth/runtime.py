"""Profile growth scoring and progression helpers."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
import math

from packages.contracts.runtime import ProfileGrowthState

MAX_GROWTH_LEVEL = 40


@dataclass(frozen=True, slots=True)
class GrowthStageDescriptor:
    stage_id: str
    display_name: str
    title: str
    logo_asset: str
    min_level: int
    max_level: int


@dataclass(frozen=True, slots=True)
class GrowthTurnSignals:
    session_id: str
    profile_id: str
    total_tokens: int
    captured_experiences: int = 0
    promoted_experiences: int = 0
    continuity_bonus: bool = False
    occurred_at: datetime | None = None


@dataclass(frozen=True, slots=True)
class GrowthSnapshot:
    state: ProfileGrowthState
    level: int
    stage: GrowthStageDescriptor
    level_floor_score: int
    next_level_score: int | None
    score_into_level: int
    score_to_next_level: int
    progress_ratio: float
    progress_percent: int
    lifetime_days: int


@dataclass(frozen=True, slots=True)
class GrowthUpdate:
    before: GrowthSnapshot
    after: GrowthSnapshot
    delta_score: int
    awarded_for: tuple[str, ...]

    @property
    def leveled_up(self) -> bool:
        return self.after.level > self.before.level

    @property
    def stage_changed(self) -> bool:
        return self.after.stage.stage_id != self.before.stage.stage_id


GROWTH_STAGES = (
    GrowthStageDescriptor(
        stage_id="seed",
        display_name="Seed",
        title="火种",
        logo_asset="evolution-stage-1",
        min_level=0,
        max_level=9,
    ),
    GrowthStageDescriptor(
        stage_id="hatchling",
        display_name="Hatchling",
        title="初生体",
        logo_asset="evolution-stage-2",
        min_level=10,
        max_level=19,
    ),
    GrowthStageDescriptor(
        stage_id="scout",
        display_name="Scout",
        title="巡行者",
        logo_asset="evolution-stage-3",
        min_level=20,
        max_level=29,
    ),
    GrowthStageDescriptor(
        stage_id="guardian",
        display_name="Guardian",
        title="守望者",
        logo_asset="aegis-logo",
        min_level=30,
        max_level=MAX_GROWTH_LEVEL,
    ),
)

_STAGE_BONUS = {
    "seed": 0,
    "hatchling": 60,
    "scout": 180,
    "guardian": 500,
}


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _local_day(moment: datetime) -> date:
    return moment.astimezone().date()


def default_growth_state(profile_id: str, *, now: datetime | None = None) -> ProfileGrowthState:
    timestamp = now or _utc_now()
    return ProfileGrowthState(
        profile_id=profile_id,
        created_at=timestamp,
        updated_at=timestamp,
    )


def stage_for_level(level: int) -> GrowthStageDescriptor:
    for stage in GROWTH_STAGES:
        if stage.min_level <= level <= stage.max_level:
            return stage
    return GROWTH_STAGES[-1]


def xp_to_next_level(level: int) -> int:
    if level >= MAX_GROWTH_LEVEL:
        return 0
    stage = stage_for_level(level)
    required = 100 + (6 * level) + (1.4 * (level**2)) + _STAGE_BONUS[stage.stage_id]
    return int(round(required / 5.0) * 5)


def level_floor_score(level: int) -> int:
    capped = min(max(level, 0), MAX_GROWTH_LEVEL)
    score = 0
    for current in range(capped):
        score += xp_to_next_level(current)
    return score


def level_for_score(score: int) -> int:
    if score <= 0:
        return 0
    level = 0
    remaining = score
    while level < MAX_GROWTH_LEVEL:
        required = xp_to_next_level(level)
        if remaining < required:
            return level
        remaining -= required
        level += 1
    return MAX_GROWTH_LEVEL


def build_growth_snapshot(state: ProfileGrowthState) -> GrowthSnapshot:
    level = level_for_score(state.growth_score)
    stage = stage_for_level(level)
    floor_score = level_floor_score(level)
    next_cost = xp_to_next_level(level) if level < MAX_GROWTH_LEVEL else 0
    next_level_score = floor_score + next_cost if next_cost else None
    score_into_level = max(0, state.growth_score - floor_score)
    progress_ratio = 1.0 if next_cost == 0 else min(1.0, score_into_level / next_cost)
    progress_percent = int(round(progress_ratio * 100))
    lifetime_days = 0
    if state.first_dialogue_at is not None and state.last_dialogue_at is not None:
        lifetime_days = max(1, (_local_day(state.last_dialogue_at) - _local_day(state.first_dialogue_at)).days + 1)
    return GrowthSnapshot(
        state=state,
        level=level,
        stage=stage,
        level_floor_score=floor_score,
        next_level_score=next_level_score,
        score_into_level=score_into_level,
        score_to_next_level=0 if next_cost == 0 else max(0, next_cost - score_into_level),
        progress_ratio=progress_ratio,
        progress_percent=progress_percent,
        lifetime_days=lifetime_days,
    )


def apply_turn_growth(
    state: ProfileGrowthState | None,
    signals: GrowthTurnSignals,
) -> GrowthUpdate:
    timestamp = signals.occurred_at or _utc_now()
    current = state or default_growth_state(signals.profile_id, now=timestamp)
    before = build_growth_snapshot(current)
    delta_score, awarded_for, active_days_delta, next_streak = _score_turn_delta(current, signals, timestamp=timestamp)
    total_experiences = current.total_experiences + max(0, signals.captured_experiences)
    promoted_experiences = current.promoted_experiences + max(0, signals.promoted_experiences)
    current_local_day = _local_day(timestamp).isoformat()
    next_state = ProfileGrowthState(
        profile_id=current.profile_id,
        growth_score=current.growth_score + delta_score,
        total_dialogues=current.total_dialogues + 1,
        total_tokens=current.total_tokens + max(0, signals.total_tokens),
        total_experiences=total_experiences,
        promoted_experiences=promoted_experiences,
        active_days=current.active_days + active_days_delta,
        streak_days=next_streak,
        first_dialogue_at=current.first_dialogue_at or timestamp,
        last_dialogue_at=timestamp,
        last_active_day=current_local_day,
        created_at=current.created_at or timestamp,
        updated_at=timestamp,
    )
    after = build_growth_snapshot(next_state)
    return GrowthUpdate(before=before, after=after, delta_score=delta_score, awarded_for=tuple(awarded_for))


def _score_turn_delta(
    state: ProfileGrowthState,
    signals: GrowthTurnSignals,
    *,
    timestamp: datetime,
) -> tuple[int, list[str], int, int]:
    awarded_for: list[str] = []
    last_active_day = date.fromisoformat(state.last_active_day) if state.last_active_day else None
    current_day = _local_day(timestamp)
    active_days_delta = 0
    streak_days = state.streak_days

    if last_active_day is None:
        active_days_delta = 1
        streak_days = 1
    elif current_day > last_active_day:
        active_days_delta = 1
        streak_days = state.streak_days + 1 if current_day == last_active_day + timedelta(days=1) else 1

    if state.total_dialogues == 0:
        return 40, ["first-turn-boost"], active_days_delta or 1, max(streak_days, 1)

    if state.total_dialogues == 1 and state.growth_score < xp_to_next_level(0):
        required = xp_to_next_level(0) - state.growth_score
        return required, ["second-turn-promotion"], active_days_delta, streak_days

    delta_score = 26
    awarded_for.append("turn")

    token_xp = min(16, round(4 * math.log1p(max(0, signals.total_tokens) / 160.0)))
    if token_xp:
        delta_score += token_xp
        awarded_for.append(f"tokens:{token_xp}")

    if active_days_delta:
        delta_score += 18
        awarded_for.append("active-day")
        streak_bonus = min(12, max(0, (streak_days - 1) * 2))
        if streak_bonus:
            delta_score += streak_bonus
            awarded_for.append(f"streak:{streak_bonus}")

    if signals.continuity_bonus:
        delta_score += 8
        awarded_for.append("continuity")

    if signals.captured_experiences:
        experience_xp = signals.captured_experiences * 10
        delta_score += experience_xp
        awarded_for.append(f"captured-experience:{experience_xp}")

    if signals.promoted_experiences:
        promoted_xp = signals.promoted_experiences * 40
        delta_score += promoted_xp
        awarded_for.append(f"promoted-experience:{promoted_xp}")

    return delta_score, awarded_for, active_days_delta, streak_days
