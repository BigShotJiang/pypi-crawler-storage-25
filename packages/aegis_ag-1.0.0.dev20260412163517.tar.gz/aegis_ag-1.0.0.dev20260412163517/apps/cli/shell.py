from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from importlib.metadata import PackageNotFoundError, version as package_version
import os
from pathlib import Path
import re
import shlex
import threading
import time

try:
    from prompt_toolkit.application import Application
    from prompt_toolkit.buffer import Buffer
    from prompt_toolkit.filters import Condition, has_completions
    from prompt_toolkit import PromptSession
    from prompt_toolkit.completion import Completer, Completion
    from prompt_toolkit.document import Document
    from prompt_toolkit.formatted_text import FormattedText
    from prompt_toolkit.history import FileHistory
    from prompt_toolkit.key_binding import KeyBindings
    from prompt_toolkit.layout.controls import BufferControl, FormattedTextControl
    from prompt_toolkit.layout.containers import ConditionalContainer, HSplit, Window
    from prompt_toolkit.layout.dimension import Dimension
    from prompt_toolkit.layout.layout import Layout
    from prompt_toolkit.layout.menus import CompletionsMenu
    from prompt_toolkit.layout.processors import BeforeInput
    from prompt_toolkit.styles import Style

    PROMPT_TOOLKIT_AVAILABLE = True
except ModuleNotFoundError:  # pragma: no cover - minimal env fallback
    PROMPT_TOOLKIT_AVAILABLE = False

    class Completion:
        def __init__(
            self,
            text: str,
            start_position: int = 0,
            display: str | None = None,
            display_meta: str | None = None,
        ) -> None:
            self.text = text
            self.start_position = start_position
            self.display = display or text
            self.display_meta = display_meta or ""

    class Completer:
        pass

    class Document:
        def __init__(self, text: str) -> None:
            self.text_before_cursor = text

        def get_word_before_cursor(self, WORD: bool = False) -> str:
            delimiter = " " if WORD else None
            return self.text_before_cursor.split(delimiter)[-1] if self.text_before_cursor else ""

    class FormattedText(list):
        pass

    class FileHistory:
        def __init__(self, filename: str) -> None:
            self.filename = filename

    class _BindingsHandle:
        def add(self, *_keys: str):
            def decorator(func):
                return func

            return decorator

    def KeyBindings() -> _BindingsHandle:
        return _BindingsHandle()

    has_completions = None

    class Style:
        @classmethod
        def from_dict(cls, mapping):
            return mapping

    class PromptSession:
        def __init__(self, **_kwargs) -> None:
            pass

        def prompt(self, prompt_text: str, **_kwargs) -> str:
            return input(prompt_text)

    Application = None
    Buffer = None
    BufferControl = None
    Condition = None
    BeforeInput = None
    ConditionalContainer = None
    CompletionsMenu = None
    Dimension = None
    FormattedTextControl = None
    HSplit = None
    Layout = None
    Window = None

try:
    from rich.align import Align
    from rich.cells import cell_len as rich_cell_len
    from rich.console import Console
    from rich.console import Group
    from rich.live import Live
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text

    RICH_AVAILABLE = True
except ModuleNotFoundError:  # pragma: no cover - minimal env fallback
    RICH_AVAILABLE = False

    class Text(str):
        def __new__(cls, text: str, style: str | None = None):
            return str.__new__(cls, text)

        @property
        def plain(self) -> str:
            return str(self)

    class Panel:
        def __init__(
            self,
            renderable,
            *,
            title: str | None = None,
            subtitle: str | None = None,
            border_style: str | None = None,
            padding: tuple[int, int] | None = None,
        ) -> None:
            self.renderable = renderable
            self.title = title or ""
            self.subtitle = subtitle or ""

    def _render_plain(renderable) -> str:
        if isinstance(renderable, Text):
            return renderable.plain
        if isinstance(renderable, str):
            return renderable
        if isinstance(renderable, Panel):
            parts = [renderable.title] if renderable.title else []
            parts.append(_render_plain(renderable.renderable))
            if renderable.subtitle:
                parts.append(renderable.subtitle)
            return "\n".join(part for part in parts if part)
        return str(renderable)

    class Console:
        def __init__(self, **_kwargs) -> None:
            pass

        def clear(self, home: bool = False) -> None:
            return None

        def print(self, renderable) -> None:
            print(_render_plain(renderable))

    Align = None
    Group = None
    Table = None
    Live = None

from packages.contracts import ExperienceRecord
from packages.kernel.runtime import KernelOutcome
from packages.tools import ToolLifecycleEvent

from .runtime import CliRuntime

BRAND_ACCENT = "#d5ac89"
BRAND_ACCENT_STRONG = "#f0b56e"
BRAND_LIGHT = "#ece7de"
BRAND_MUTED = "#93a1b6"
BRAND_DARK = "#202736"
COMMAND_PALETTE_VISIBLE_ROWS = 6
USER_HISTORY_BG = "#454649"
USER_HISTORY_FG = "#f2efe8"
QUEUE_PREVIEW_INSET = 3
MARKDOWN_BOLD_PATTERN = re.compile(r"\*\*(.+?)\*\*")
WEB_URL_PATTERN = re.compile(r"(https?://[^\s]+)", re.IGNORECASE)
EXPERIENCE_NOISE_PATTERN = re.compile(
    r"^(?:it looks like|i couldn't|i could not|sorry|tool failed\b|unable to\b)",
    re.IGNORECASE,
)
# SVG-derived top-half crop with one-cell side gutters preserved so the mark
# stays locked to the canonical source logo geometry.
GUARDIAN_HEAD_ROWS = (
    "          kggk          ",
    "        kcccccck        ",
    "       kcccccccck       ",
    "      kcccmmmmccck      ",
    "      kccmmmmmmcck      ",
    "      kccmttttmcck      ",
    "      kcctxttxtcck      ",
    "      kccttxxttcck      ",
)
SEED_STAGE_ROWS = (
    "           gg",
    "          kkkk",
    "         kcccck",
    "        kcccccck",
    "        kcttttck",
    "        kcxttxck",
    "        k cccc k",
    "         kkcckk",
    "          kggk",
    "           kk",
)
HATCHLING_STAGE_ROWS = (
    "          kggk",
    "        kcccccck",
    "       kccmmmmcck",
    "      kcccccccccck",
    "      kcctxttxtcck",
    "      kccttxxttcck",
    "      kcc tttt cck",
    "      k cccccccc k",
    "       kk      kk",
    "        kkkkkkkk",
    "         kkkkkk",
    "         mtggtm",
    "          tggt",
    "          k  k",
    "          k  k",
    "         kkkkkk",
)
SCOUT_STAGE_ROWS = (
    "          kggk",
    "        kcccccck",
    "       kcccccccck",
    "      kcccmmmmccck",
    "      kccmmmmmmcck",
    "      kcctxttxtcck",
    "      kccttxxttcck",
    "      k ccttttcc k",
    "        kkkkkkkk",
    "       kkkkkkkkkk",
    "        kcmmmmck",
    "        kctggtck",
    "        kctggtck",
    "        kccttcck",
    "         kmmmmkk",
    "         kk  kk",
    "         kk  kk",
    "        kkk  kkk",
)
GUARDIAN_STAGE_ROWS = (
    "          kggk",
    "        kcccccck",
    "       kcccccccck",
    "      kcccmmmmccck",
    "      kccmmmmmmcck",
    "      kccmttttmcck",
    "      kcctxttxtcck",
    "      kccttxxttcck",
    "      k ccttttcc k",
    "       kkccxxcckk",
    "        kkkkkkkk",
    "       kkkkkkkkkk",
    "      kccmmmmmmcck",
    "     kkccmttttmcckk",
    "     kkcmttggttmckk",
    "      kcmttggttmck",
    "      k  mttttm  k",
    "       kccmggmcck",
    "        ccm  mcc",
    "        ccm  mcc",
    "        ccm  mcc",
    "       kcck  kcck",
)
GROWTH_STAGE_ROWS = {
    "seed": SEED_STAGE_ROWS,
    "hatchling": HATCHLING_STAGE_ROWS,
    "scout": SCOUT_STAGE_ROWS,
    "guardian": GUARDIAN_STAGE_ROWS,
}


@dataclass(frozen=True, slots=True)
class TranscriptEntry:
    kind: str
    title: str
    body: str
    meta: str = ""


@dataclass(frozen=True, slots=True)
class PendingShellCommand:
    command: str


@dataclass(frozen=True, slots=True)
class ShellCommandSpec:
    name: str
    description: str


def _completion(text: str, *, start_position: int, display: str, meta: str = "") -> Completion:
    try:
        return Completion(text, start_position=start_position, display=display, display_meta=meta)
    except TypeError:  # pragma: no cover - fallback signature
        return Completion(text, start_position=start_position, display=display)


class ShellCompleter(Completer):
    def __init__(self, shell: "ProductizedShell") -> None:
        self.shell = shell

    def get_completions(self, document: Document, complete_event):
        text = document.text_before_cursor
        stripped = text.lstrip()
        if not stripped.startswith("/"):
            return
        words = stripped.split()
        current_word = document.get_word_before_cursor(WORD=True)
        if not words:
            return
        command = words[0]
        if len(words) <= 1 and not text.endswith(" "):
            for spec in self.shell.command_specs:
                if spec.name.startswith(command):
                    yield _completion(
                        spec.name,
                        start_position=-len(current_word),
                        display=spec.name,
                        meta=spec.description,
                    )
            return

        if command == "/resume":
            candidates = (
                ("latest", "Resume the latest Aegis clone"),
                *tuple((clone_id, "Resume the latest session for a clone") for clone_id in self.shell.recent_clone_ids()),
            ) + tuple(
                (session_id, "Resume a known session")
                for session_id in self.shell.recent_session_ids()
            )
        elif command == "/identity":
            if len(words) >= 2 and words[1] == "soul":
                candidates = (
                    ("show", "Inspect the current SOUL text"),
                    ("set", "Replace the current SOUL text"),
                    ("clear", "Clear the current SOUL text"),
                )
            elif len(words) >= 2 and words[1] in {"preset", "personality"}:
                candidates = tuple(
                    (preset_id, description)
                    for preset_id, description in self.shell.personality_preset_choices()
                )
            elif len(words) == 2 and text.endswith(" "):
                candidates = (
                    ("inspect", "Show current identity, mode, and SOUL"),
                    ("set-name", "Rename the active companion"),
                    ("soul", "Show, set, or clear SOUL"),
                    ("initiative", "Tune proactive initiative"),
                    ("preset", "Choose a personality preset"),
                )
            else:
                candidates = (
                    ("inspect", "Show current identity, mode, and SOUL"),
                    ("set-name", "Rename the active companion"),
                    ("soul", "Show, set, or clear SOUL"),
                    ("initiative", "Tune proactive initiative"),
                    ("preset", "Choose a personality preset"),
                )
        elif command == "/tools":
            candidates = (
                ("inspect", "Show metadata for one tool"),
                ("enable", "Enable a tool for this clone"),
                ("disable", "Disable a tool for this clone"),
                ("install", "Load a tool manifest into this clone"),
                ("run", "Run a tool with explicit key=value arguments"),
            )
        elif command == "/skills":
            candidates = (
                ("search", "Search installable skill packages from local shelves"),
                ("inspect", "Show metadata for one skill"),
                ("enable", "Enable a skill for this clone"),
                ("disable", "Disable a skill for this clone"),
                ("install", "Install a skill package or manifest into this clone"),
            )
        elif command == "/mcp":
            candidates = (
                ("search", "Search installable MCP servers"),
                ("inspect", "Show one configured MCP server"),
                ("enable", "Enable a configured MCP server"),
                ("disable", "Disable a configured MCP server"),
                ("install", "Install an MCP server from the registry"),
            )
        elif command == "/cron":
            candidates = (
                ("create", "Create a scheduled greeting, web search, or prompt"),
                ("inspect", "Show one cron job"),
                ("pause", "Pause a cron job"),
                ("resume", "Resume a paused cron job"),
                ("remove", "Remove a cron job"),
            )
        else:
            return

        for value, description in candidates:
            if value.startswith(current_word):
                yield _completion(
                    value,
                    start_position=-len(current_word),
                    display=value,
                    meta=description,
                )


class ProductizedShell:
    command_specs = (
        ShellCommandSpec("/help", "Open the command palette and interaction hints"),
        ShellCommandSpec("/status", "Refresh session, provider, and growth posture"),
        ShellCommandSpec("/clone", "Create a new named Aegis clone and switch into it"),
        ShellCommandSpec("/clones", "Inspect the available Aegis clones"),
        ShellCommandSpec("/resume", "Resume the latest or a known Aegis clone"),
        ShellCommandSpec("/goals", "Inspect the current durable goals"),
        ShellCommandSpec("/memory", "Inspect remembered context for this clone"),
        ShellCommandSpec("/tools", "Inspect, install, toggle, and run built-in or manifest-backed tools"),
        ShellCommandSpec("/skills", "Inspect, search, install, and toggle built-in or external skill packages"),
        ShellCommandSpec("/mcp", "Inspect, search, install, and toggle configured MCP servers"),
        ShellCommandSpec("/cron", "Inspect, create, pause, resume, and remove built-in scheduled jobs"),
        ShellCommandSpec("/identity", "Inspect or tune display name, SOUL, initiative, and preset"),
        ShellCommandSpec("/health", "Review readiness, voice, and security checks"),
        ShellCommandSpec("/grow", "Inspect the next long-horizon growth action"),
        ShellCommandSpec("/clear", "Clear the current transcript and redraw the frame"),
        ShellCommandSpec("/exit", "Leave the grow surface"),
    )

    def __init__(self, runtime: CliRuntime, *, session_id: str, opened: str, debug: bool = False) -> None:
        self.runtime = runtime
        self.session_id = session_id
        self.opened = opened
        self.debug = debug or os.environ.get("AEGIS_DEBUG") == "1"
        self.console = Console(highlight=False, soft_wrap=True)
        self.version = _resolve_aegis_version()
        self.cwd = _display_path(Path.cwd())
        self.transcript: list[TranscriptEntry] = []
        self._pending_commands: deque[PendingShellCommand] = deque()
        self._rendered_entries = 0
        self.runtime.prepare_session_surface(self.session_id)
        self._prime_transcript()

    def run(self) -> int:
        self._render_startup_sequence()
        self._refresh_shell_frame()
        self._render_pending_entries()
        while True:
            try:
                command = self._next_command()
            except KeyboardInterrupt:
                self._append_entry(
                    "notice",
                    "Grow surface",
                    "Prompt interrupted. Type a request, use /help, or /exit when you are done.",
                )
                self._render_pending_entries()
                continue
            except EOFError:
                self._append_entry("notice", "Grow surface", f"Leaving session {self.session_id}.")
                self._render_pending_entries()
                break
            if self._dispatch(command.command):
                break
            self._render_pending_entries()
        self.console.print("Aegis stays by your side.")
        return 0

    def recent_session_ids(self) -> tuple[str, ...]:
        return tuple(session.session_id for session in self.runtime.recent_sessions(limit=8))

    def recent_clone_ids(self) -> tuple[str, ...]:
        return tuple(clone.clone_id for clone in self.runtime.list_clones(limit=8))

    def _next_command(self) -> PendingShellCommand:
        if self._pending_commands:
            return self._pending_commands.popleft()
        return PendingShellCommand(self._read_command())

    def _prompt_toolkit_composer_available(self) -> bool:
        if not PROMPT_TOOLKIT_AVAILABLE:
            return False
        return not any(
            component is None
            for component in (
                Application,
                Buffer,
                BufferControl,
                Condition,
                BeforeInput,
                ConditionalContainer,
                CompletionsMenu,
                Dimension,
                FormattedTextControl,
                HSplit,
                Layout,
                Window,
                has_completions,
            )
        )

    def _shell_history(self):
        return FileHistory(str(self.runtime.paths.state_dir / "shell-history.txt"))

    def _build_prompt_buffer(self):
        return Buffer(
            multiline=True,
            completer=ShellCompleter(self),
            complete_while_typing=True,
            history=self._shell_history(),
        )

    def _build_input_window(self, buffer):
        return Window(
            BufferControl(
                buffer=buffer,
                input_processors=[BeforeInput("› ", style="class:composer-prefix")],
                focus_on_click=True,
            ),
            wrap_lines=True,
            dont_extend_height=True,
            height=Dimension(min=1, preferred=1, max=6),
        )

    def _build_command_palette(self):
        return ConditionalContainer(
            content=CompletionsMenu(max_height=COMMAND_PALETTE_VISIBLE_ROWS, scroll_offset=1),
            filter=has_completions,
        )

    def _build_queue_preview_window(self):
        return ConditionalContainer(
            content=Window(
                FormattedTextControl(lambda: self._render_queued_followup_fragments()),
                wrap_lines=True,
                dont_extend_height=True,
            ),
            filter=Condition(lambda: bool(self._pending_commands)),
        )

    def _build_divider_window(self):
        return Window(
            FormattedTextControl([("class:composer-divider", self._composer_divider())]),
            height=1,
            dont_extend_height=True,
        )

    def _build_composer_body(self, *, input_window, command_palette, top_windows=()):
        return HSplit(
            [
                *top_windows,
                self._build_divider_window(),
                command_palette,
                input_window,
                self._build_divider_window(),
            ]
        )

    def _read_command(self) -> str:
        if not PROMPT_TOOLKIT_AVAILABLE:
            return input(f"{self._composer_divider()}\n› ")
        if not self._prompt_toolkit_composer_available():
            session = PromptSession(
                multiline=True,
                completer=ShellCompleter(self),
                complete_while_typing=True,
                history=self._shell_history(),
                reserve_space_for_menu=COMMAND_PALETTE_VISIBLE_ROWS,
            )
            return session.prompt(
                self._prompt_label(),
                style=self._prompt_style(),
                key_bindings=self._build_key_bindings(),
                prompt_continuation=self._prompt_continuation(),
                erase_when_done=True,
            )

        buffer = self._build_prompt_buffer()

        def submit(event) -> None:
            if event.current_buffer.text:
                event.current_buffer.append_to_history()
            event.app.exit(result=event.current_buffer.text)

        bindings = self._build_key_bindings(submit=submit)
        input_window = self._build_input_window(buffer)
        command_palette = self._build_command_palette()
        composer_body = self._build_composer_body(
            input_window=input_window,
            command_palette=command_palette,
        )
        application = Application(
            layout=Layout(composer_body, focused_element=input_window),
            key_bindings=bindings,
            style=self._prompt_style(),
            full_screen=False,
            erase_when_done=True,
        )
        result = application.run()
        if result is None:
            raise EOFError
        return str(result)

    def personality_preset_choices(self) -> tuple[tuple[str, str], ...]:
        return tuple(
            (preset.preset_id, preset.summary)
            for preset in self.runtime.personality_presets()
            if preset.preset_id != "custom"
        )

    def _prompt_label(self) -> str:
        divider = self._composer_divider()
        if not PROMPT_TOOLKIT_AVAILABLE:
            return f"{divider}\n› "
        return FormattedText(
            [
                ("class:composer-divider", f"{divider}\n"),
                ("class:composer-prefix", "› "),
            ]
        )

    def _prompt_continuation(self):
        if not PROMPT_TOOLKIT_AVAILABLE:
            return "  "
        return FormattedText([("class:composer-prefix", "  ")])

    def _prompt_style(self):
        if not PROMPT_TOOLKIT_AVAILABLE:
            return None
        return Style.from_dict(self._prompt_style_map())

    def _prompt_style_map(self) -> dict[str, str]:
        return {
            "": f"fg:{BRAND_LIGHT}",
            "composer-divider": f"fg:{BRAND_ACCENT}",
            "composer-prefix": f"fg:{BRAND_ACCENT_STRONG} bold",
            "queue-user": f"{USER_HISTORY_FG} bg:{USER_HISTORY_BG}",
            "progress-title": f"fg:{BRAND_ACCENT} bold",
            "progress-active": f"fg:{BRAND_ACCENT_STRONG} bold",
            "progress-meta": f"fg:{BRAND_MUTED}",
            "progress-tool": f"fg:{BRAND_LIGHT} bold",
            "progress-queue": f"fg:{BRAND_LIGHT}",
            "progress-hint": f"fg:{BRAND_MUTED}",
        }

    def _build_key_bindings(self, *, submit=None, allow_exit: bool = True) -> KeyBindings:
        bindings = KeyBindings()
        submit_handler = submit or (lambda event: event.current_buffer.validate_and_handle())

        @bindings.add("enter")
        def _(event) -> None:
            submit_handler(event)

        @bindings.add("escape", "enter")
        def _(event) -> None:
            event.current_buffer.insert_text("\n")

        if allow_exit:

            @bindings.add("c-c")
            def _(event) -> None:
                raise KeyboardInterrupt

            @bindings.add("c-d")
            def _(event) -> None:
                raise EOFError
        else:

            @bindings.add("c-c")
            def _(event) -> None:
                event.current_buffer.text = ""

            @bindings.add("c-d")
            def _(event) -> None:
                event.current_buffer.text = ""

        return bindings

    def _composer_divider(self) -> str:
        width = getattr(self.console, "width", 100)
        try:
            width = self.console.size.width
        except AttributeError:
            pass
        return "─" * max(24, width - 1)

    def _clear_composer(self, command: str) -> None:
        if PROMPT_TOOLKIT_AVAILABLE:
            return
        stream = getattr(self.console, "file", None)
        if stream is None or not hasattr(stream, "isatty") or not stream.isatty():
            return
        logical_lines = 3 + command.count("\n")
        stream.write("\r\x1b[2K")
        for _ in range(logical_lines):
            stream.write("\x1b[1A\r\x1b[2K")
        stream.flush()

    def _enqueue_followup_command(self, raw_command: str) -> None:
        command = raw_command.strip()
        if not command:
            return
        self._pending_commands.append(PendingShellCommand(command=command))

    def _prime_transcript(self) -> None:
        session = self.runtime.inspect_session(self.session_id)
        continuity = self.runtime.inspect_continuity(session_id=self.session_id)
        assistant_name = continuity.profile.state.display_name or "Aegis"
        opener = self._compose_opener(session, continuity)
        self._append_entry("assistant", assistant_name, opener)
        for execution in self.runtime.run_due_cron_jobs(session_id=self.session_id):
            if execution.job.action_kind == "greeting":
                self._append_entry(
                    "assistant",
                    assistant_name,
                    execution.summary,
                    meta=f"cron · {execution.job.name}",
                )
            else:
                self._append_entry(
                    "notice",
                    "Cron job",
                    execution.summary,
                    meta=f"{execution.job.name} · {execution.job.action_kind}",
                )
        if self.debug:
            self._append_entry(
                "notice",
                "Growth context",
                "\n".join(
                    [
                        f"session_id: {session.session_id}",
                        f"clone_id: {self.runtime.clone_id_for_session(session)}",
                        f"continuity: {continuity.continuity_summary}",
                        f"growth_action: {continuity.wake_action}",
                        f"growth_summary: {continuity.wake_summary}",
                        f"reengagement_style: {continuity.reengagement_style}",
                        f"reengagement_prompt: {continuity.reengagement_prompt}",
                    ]
                ),
            )

    def _compose_opener(self, session, continuity) -> str:
        display_name = continuity.profile.state.display_name or "Aegis"
        intro = "Welcome back." if self.opened != "Cloned new" else "I'm here."
        personality = continuity.profile.her_mode.personality if continuity.profile.her_mode is not None else ()
        if personality:
            posture = f"I'll stay {', '.join(personality)} and keep our thread steady."
        elif continuity.reengagement_style == "proactive-check-in":
            posture = "I'll stay lightly proactive and keep the next durable step visible."
        elif continuity.reengagement_style == "gentle-presence":
            posture = "I'll keep a calm presence and carry forward the useful context."
        else:
            posture = "I'll keep continuity explicit and the next step legible."
        if continuity.wake_action not in {"idle", "defer_or_schedule"}:
            next_step = f"I still have one live thread in mind: {continuity.wake_summary.rstrip('.')}."
        else:
            next_step = "Tell me what matters next and I'll carry it forward."
        return f"I am {display_name}. {intro} {posture} {next_step}"

    def _assistant_name(self) -> str:
        session = self.runtime.inspect_session(self.session_id)
        return self.runtime.inspect_profile(session.profile_id).state.display_name or "Aegis"

    def _append_assistant_surface_reply(self, body: str, *, meta: str = "") -> None:
        self._append_entry("assistant", self._assistant_name(), body, meta=meta)

    def _render_shell_frame(self):
        session = self.runtime.inspect_session(self.session_id)
        continuity = self.runtime.inspect_continuity(session_id=self.session_id)
        provider = dict(self.runtime.provider_summary())
        growth = self.runtime.inspect_growth(session_id=self.session_id)
        clone_id = self.runtime.clone_id_for_session(session)
        if RICH_AVAILABLE and Table is not None and Group is not None:
            hero = Table.grid(expand=True)
            console_width = getattr(self.console.size, "width", 0)
            if console_width and console_width < 132:
                hero.add_column(ratio=1, min_width=48)
                hero.add_row(self._render_brand_column(session, provider, growth))
                hero.add_row(Text(" "))
                hero.add_row(self._render_status_column(session, continuity, provider, growth))
            else:
                hero.add_column(ratio=13, min_width=72)
                hero.add_column(ratio=12, min_width=42)
                hero.add_row(
                    self._render_brand_column(session, provider, growth),
                    self._render_status_column(session, continuity, provider, growth),
                )
            return Panel(
                hero,
                title=f"[bold {BRAND_ACCENT}] Your Own Aegis [/bold {BRAND_ACCENT}]",
                subtitle=f"[bold {BRAND_LIGHT}]Persistent memory, long-horizon decisions, and long context.[/bold {BRAND_LIGHT}]",
                border_style=BRAND_ACCENT,
                padding=(1, 2),
            )
        logo = "\n".join(
            (
                "    ___    ________ _____ _____ _____",
                "   /   |  / ____/ //_/ // / ___// ___/",
                "  / /| | / / __/ ,< / ,<  \\__ \\\\__ \\",
                " / ___ |/ /_/ / /| / /| |___/ /__/ /",
                "/_/  |_|\\____/_/ |_/_/ |_/____/____/",
            )
        )
        growth_lines = self._growth_panel_lines(session, continuity, provider, growth)
        welcome = "Welcome back !"
        lines = [
            welcome,
            "The Aegis that remembers, reasons, and stays with you.",
            logo,
            "",
            "persistent memory · long-horizon decisions · long context",
            "",
            "Tips for getting started",
            "Start talking directly, or type / to open the command palette.",
            "",
            "Growth",
            *growth_lines,
            "",
            f"clone: {clone_id}",
            f"continuity: {session.session_id[:8]}",
            f"provider: {provider['provider_id']} · model: {provider['default_model'] or '<unset>'}",
        ]
        return Panel(
            Text("\n".join(lines)),
            title=" Your Own Aegis ",
            subtitle=" persistent memory, long-horizon decisions, and long context ",
            border_style="bright_white",
            padding=(1, 2),
        )

    def _render_brand_column(self, session, provider, growth):
        continuity = self.runtime.inspect_continuity(session_id=self.session_id)
        display_name = continuity.profile.state.display_name or "Aegis"
        welcome = "Welcome back !"
        heading = Text(no_wrap=True, justify="center")
        heading.append(f"{welcome}\n", style=f"bold {BRAND_LIGHT}")
        heading.append("The Aegis that remembers, reasons, and stays with you.", style=BRAND_MUTED)
        meta = Text(no_wrap=True, justify="center")
        meta.append(f"{display_name}\n", style=f"bold {BRAND_LIGHT}")
        meta.append("persistent memory · long-horizon decisions · long context\n", style=BRAND_MUTED)
        meta.append(f"{growth.stage.title} · Lv.{growth.level}\n", style=BRAND_ACCENT_STRONG)
        meta.append(f"{provider['default_model'] or '<unset>'} · companion mode\n", style=BRAND_LIGHT)
        meta.append(f"{self.cwd}", style=BRAND_MUTED)
        if Table is None:
            return Group(heading, self._render_growth_mark(growth.stage.stage_id), meta)
        brand = Table.grid(expand=True)
        brand.add_column(no_wrap=True)
        brand.add_row(self._center_brand_block(heading))
        brand.add_row(self._center_brand_block(Text(" ")))
        brand.add_row(self._center_brand_block(self._render_growth_mark(growth.stage.stage_id)))
        brand.add_row(self._center_brand_block(Text(" ")))
        brand.add_row(self._center_brand_block(meta))
        return brand

    def _render_status_column(self, session, continuity, provider, growth):
        divider = "─" * 44
        tips = Text()
        tips.append("Tips for getting started\n", style=f"bold {BRAND_ACCENT}")
        tips.append("Start talking directly, or open / for the command palette.\n", style=BRAND_LIGHT)
        tips.append(f"{divider}\n", style=BRAND_DARK)
        tips.append("Growth\n", style=f"bold {BRAND_ACCENT}")
        growth_lines = self._growth_panel_lines(session, continuity, provider, growth)
        for line in growth_lines:
            tips.append(f"{line}\n", style=BRAND_MUTED if "none" in line.lower() else BRAND_LIGHT)
        return tips

    def _render_startup_sequence(self) -> None:
        if not self._animations_enabled() or Group is None or Table is None:
            return
        steps = (
            ("bind.identity", "Locking the Aegis identity and companion posture"),
            ("recover.memory", "Recovering durable memory and recent clone context"),
            ("score.grow", "Scoring the growth loop and next long-horizon move"),
            ("enter.dialogue", "Opening the branded dialogue surface"),
        )
        with Live(
            self._render_boot_frame(steps, active=0),
            console=self.console,
            refresh_per_second=30,
            transient=True,
        ) as live:
            for index in range(len(steps)):
                live.update(self._render_boot_frame(steps, active=index), refresh=True)
                time.sleep(0.05)
            time.sleep(0.03)

    def _render_boot_frame(self, steps: tuple[tuple[str, str], ...], *, active: int):
        if not RICH_AVAILABLE or Table is None or Group is None:
            return Text("Aegis booting...")
        headline = Text()
        headline.append("AEGIS // grow\n", style=f"bold {BRAND_ACCENT}")
        headline.append("building the persistent dialogue surface", style=BRAND_MUTED)

        table = Table.grid(expand=True)
        table.add_column(ratio=4, style=BRAND_MUTED)
        table.add_column(ratio=12, style=BRAND_LIGHT)
        for index, (label, detail) in enumerate(steps):
            marker = "●" if index <= active else "○"
            style = BRAND_ACCENT if index <= active else "#4f5560"
            table.add_row(f"[{style}]{marker}[/{style}] {label}", detail)

        footer = Text("born is separate; grow is the first conversational frame", style=BRAND_MUTED)
        return Panel(
            Group(headline, table, footer),
            title=f"[bold {BRAND_ACCENT}]Boot sequence[/bold {BRAND_ACCENT}]",
            border_style=BRAND_DARK,
            padding=(1, 2),
        )

    def _refresh_shell_frame(self) -> None:
        self._rendered_entries = 0
        self.console.clear(home=True)
        self.console.print(self._render_shell_frame())

    def _dispatch(self, raw_command: str) -> bool:
        command = raw_command.strip()
        if not command:
            return False
        if command.startswith("/"):
            self._clear_composer(command)
            return self._handle_slash_command(command)
        self._clear_composer(command)
        self._append_entry("user", "You", command)
        self._render_pending_entries()
        if self._handle_conversational_surface_request(command):
            self._refresh_shell_frame()
            return False
        try:
            if self.debug:
                self._append_entry(
                    "status",
                    "Runtime",
                    "\n".join(
                        [
                            f"session_id: {self.session_id}",
                            "mode: shared-runtime",
                            "trace: debug diagnostics enabled",
                        ]
                    ),
                )
                self._render_pending_entries()
            outcome = self._run_turn_with_progress(command)
        except Exception as error:  # pragma: no cover - defensive shell surface
            self._append_entry(
                "recovery",
                "Turn failed",
                f"{error}\nstatus: /status\nhealth: /health",
            )
            self._refresh_shell_frame()
            return False
        self._append_outcome(outcome)
        self._show_growth_celebration_if_needed()
        self._refresh_shell_frame()
        return False

    def _handle_conversational_surface_request(self, message: str) -> bool:
        normalized = message.strip().lower().rstrip("?.!")
        if normalized in {
            "what tools do you have",
            "which tools do you have",
            "show tools",
            "list tools",
        }:
            tools = self.runtime.tool_catalog(session_id=self.session_id)
            lines = [
                "I can use these tools right now:",
                *[
                    f"- {tool.display_name} ({tool.tool_id}): {tool.description}"
                    for tool in tools
                ],
                "",
                "Ask me naturally if you want one used, or give me a manifest path if you want me to install an external tool.",
            ]
            self._append_assistant_surface_reply("\n".join(lines))
            return True
        if normalized in {
            "what cron jobs do you have",
            "which cron jobs do you have",
            "show cron jobs",
            "list cron jobs",
            "show schedules",
            "list schedules",
        }:
            jobs = self.runtime.cron_jobs(session_id=self.session_id)
            if jobs:
                body = "\n".join(
                    [
                        "These scheduled jobs are active for this clone:",
                        *[
                            f"- {job.name} ({job.job_id}) · {job.status} · {job.schedule_text} · {job.action_kind}"
                            for job in jobs
                        ],
                    ]
                )
            else:
                body = "I don't have any scheduled jobs running for this clone yet."
            self._append_assistant_surface_reply(body)
            return True
        tool_match = re.match(r"(?i)^(install|add|load)\s+tools?\s+(.+)$", message.strip())
        if tool_match is not None:
            reference = self._strip_wrapping_quotes(tool_match.group(2).strip())
            try:
                record = self.runtime.install_tool_manifest(reference, session_id=self.session_id)
            except Exception as error:
                self._append_assistant_surface_reply(
                    "I couldn't install that tool manifest yet.\n"
                    f"reason: {error}\n"
                    "Right now external tools install from a local manifest path.",
                )
                return True
            self._append_assistant_surface_reply(
                "\n".join(
                    [
                        "I installed that tool manifest for this clone.",
                        f"- source: {record.source_path}",
                        f"- tools: {', '.join(record.tool_ids) or '<empty>'}",
                        f"- executable: {', '.join(record.executable_tool_ids) or '<empty>'}",
                    ]
                )
            )
            return True
        cron_greeting = re.match(
            r"(?is)^(?:schedule|create|set up)\s+(?:a\s+)?greeting(?:\s+job)?(?:\s+to\s+say\s+(.+?))?\s+(every .+|daily at .+|\d+[mhd])$",
            message.strip(),
        )
        if cron_greeting is not None:
            message_text = self._strip_wrapping_quotes((cron_greeting.group(1) or "").strip())
            schedule = cron_greeting.group(2).strip()
            arguments = [f'schedule="{schedule}"', "kind=greeting"]
            if message_text:
                arguments.append(f'message="{message_text}"')
                arguments.append(f'name="Greeting · {schedule}"')
            else:
                arguments.append(f'name="Greeting · {schedule}"')
            try:
                payload = self._parse_named_arguments(arguments)
                job = self.runtime.create_cron_job(
                    session_id=self.session_id,
                    name=payload.get("name", f"Greeting · {schedule}"),
                    schedule=payload["schedule"],
                    action_kind=payload["kind"],
                    payload={"message": payload.get("message", "")},
                )
            except Exception as error:
                self._append_assistant_surface_reply(f"I couldn't create that scheduled greeting yet.\nreason: {error}")
                return True
            self._append_assistant_surface_reply(
                f"I scheduled that greeting for this clone.\n- {job.name} · {job.schedule_text} · {job.action_kind}"
            )
            return True
        cron_search = re.match(
            r"(?is)^(?:schedule|create|set up)\s+(?:a\s+)?(?:web\s+search|search)(?:\s+job)?\s+(?:for\s+)?(.+?)\s+(every .+|daily at .+|\d+[mhd])$",
            message.strip(),
        )
        if cron_search is not None:
            query = self._strip_wrapping_quotes(cron_search.group(1).strip())
            schedule = cron_search.group(2).strip()
            try:
                job = self.runtime.create_cron_job(
                    session_id=self.session_id,
                    name=f"Web search · {query[:32]}",
                    schedule=schedule,
                    action_kind="web_search",
                    payload={"query": query},
                )
            except Exception as error:
                self._append_assistant_surface_reply(f"I couldn't create that scheduled web search yet.\nreason: {error}")
                return True
            self._append_assistant_surface_reply(
                f"I scheduled that web search for this clone.\n- {job.name} · {job.schedule_text} · {job.action_kind}"
            )
            return True
        webpage_url = self._requested_webpage_url(message)
        if webpage_url is not None:
            try:
                result = self._run_tool_with_progress("tool.web.fetch", {"url": webpage_url})
            except Exception as error:
                self._append_assistant_surface_reply(
                    f"I couldn't fetch that web page yet.\nreason: {error}",
                    meta=webpage_url,
                )
                return True
            self._append_assistant_surface_reply(
                f"I opened that page and pulled the readable content:\n{result.summary}",
                meta=webpage_url,
            )
            return True
        return False

    def _handle_slash_command(self, raw_command: str) -> bool:
        try:
            parts = shlex.split(raw_command)
        except ValueError as error:
            self._append_entry("recovery", "Command parse error", str(error))
            return False
        command = parts[0]
        args = parts[1:]

        if command in {"/exit", "/quit"}:
            self._append_entry("notice", "Grow surface", f"Leaving session {self.session_id}.")
            return True
        if command == "/help":
            self._append_help()
            return False
        if command == "/status":
            self._append_status()
            return False
        if command == "/clone":
            if not args:
                self._append_entry("recovery", "Clone", "Usage: /clone <name>")
                return False
            self._clone_new_session(args[0])
            return False
        if command == "/clones":
            self._append_clones()
            return False
        if command == "/resume":
            self._resume_session(args[0] if args else "latest")
            return False
        if command == "/goals":
            self._append_goals()
            return False
        if command == "/memory":
            self._append_memory()
            return False
        if command == "/tools":
            self._append_tools(args)
            return False
        if command == "/skills":
            self._append_skills(args)
            return False
        if command == "/mcp":
            self._append_mcp(args)
            return False
        if command == "/cron":
            self._append_cron(args)
            return False
        if command == "/identity":
            self._append_identity(args)
            return False
        if command == "/health":
            self._append_doctor()
            return False
        if command == "/grow":
            self._append_wake()
            return False
        if command == "/clear":
            self.transcript.clear()
            self._refresh_shell_frame()
            self._prime_transcript()
            return False

        self._append_entry("recovery", "Unknown command", f"{command}\nhelp: /help")
        return False

    def _append_help(self) -> None:
        lines = [
            "Stay in the conversation. Slash commands exist only for orientation and control.",
            "",
            "/status - refresh session, provider, and growth posture",
            "/clone <name> - create and enter a new named Aegis clone",
            "/clones - inspect known Aegis clones",
            "/resume latest|<clone-id>|<session-id> - re-enter a clone or jump to a known session",
            "/goals - inspect current durable goals",
            "/memory - inspect remembered context for the active clone",
            "/tools [inspect|enable|disable|install|run] - govern built-ins and manifest-backed tools",
            "/skills [search|inspect|enable|disable|install] - govern built-ins and external skill packages",
            "/mcp [search|inspect|enable|disable|install] - govern configured MCP servers",
            "/cron [create|inspect|pause|resume|remove] - govern built-in scheduled jobs",
            "/identity inspect|set-name|soul|initiative|preset",
            "/health - review readiness, voice, and security checks",
            "/grow - inspect the next proactive growth action",
            "/clear - redraw the grow surface",
            "/exit - leave the shell",
            "",
            "Retire clones from the CLI: aegis clones bye <name> or aegis clones bye --all",
            "",
            "Tip: type / and keep typing to open the command palette.",
        ]
        self._append_entry("notice", "Command palette", "\n".join(lines))

    def _append_tools(self, args: list[str]) -> None:
        command = args[0] if args else "list"
        if command in {"list", "ls"}:
            tools = self.runtime.tool_catalog(session_id=self.session_id)
            lines = [
                f"{tool.tool_id} | enabled={tool.enabled} | {tool.display_name} | {tool.description}"
                for tool in tools
            ] or ["<empty>"]
            lines.extend(
                [
                    "",
                    "inspect: /tools inspect <tool-id>",
                    "enable: /tools enable <tool-id>",
                    "disable: /tools disable <tool-id>",
                    "install: /tools install </path/to/tools.json>",
                    'run shell: /tools run tool.shell.command command="pwd"',
                    'run search: /tools run tool.workspace.search query="aegis"',
                    'run web: /tools run tool.web.search query="agentic intelligence"',
                    'read page: /tools run tool.web.fetch url="https://example.com"',
                    'manage cron: /tools run tool.cron.manage action=list',
                ]
            )
            self._append_entry("notice", "Tools", "\n".join(lines))
            return
        if command == "inspect":
            if len(args) < 2:
                self._append_entry("recovery", "Tools", "Usage: /tools inspect <tool-id>")
                return
            tool = self.runtime.inspect_tool(args[1], session_id=self.session_id)
            self._append_entry(
                "status",
                "Tool",
                "\n".join(
                    [
                        f"tool_id: {tool.tool_id}",
                        f"display_name: {tool.display_name}",
                        f"enabled: {tool.enabled}",
                        f"version: {tool.version}",
                        f"description: {tool.description}",
                        f"categories: {', '.join(tool.side_effects.categories) or '<none>'}",
                        f"approval_class: {tool.side_effects.approval_class}",
                        f"risk_class: {tool.side_effects.risk_class}",
                        f"provenance: {tool.provenance or 'built-in'}",
                    ]
                ),
            )
            return
        if command in {"enable", "disable"}:
            if len(args) < 2:
                self._append_entry("recovery", "Tools", f"Usage: /tools {command} <tool-id>")
                return
            updated = self.runtime.set_tool_enabled(
                args[1],
                command == "enable",
                session_id=self.session_id,
            )
            self._append_entry("status", "Tool updated", f"{updated.tool_id}\nenabled: {updated.enabled}")
            return
        if command == "install":
            if len(args) < 2:
                self._append_entry("recovery", "Tools", "Usage: /tools install </path/to/tools.json>")
                return
            try:
                record = self.runtime.install_tool_manifest(args[1], session_id=self.session_id)
            except Exception as error:
                self._append_entry("recovery", "Tools", str(error))
                return
            self._append_entry(
                "status",
                "Tool manifest installed",
                "\n".join(
                    [
                        f"source_path: {record.source_path}",
                        f"tool_ids: {', '.join(record.tool_ids) or '<empty>'}",
                        f"executable_tool_ids: {', '.join(record.executable_tool_ids) or '<empty>'}",
                    ]
                ),
            )
            return
        if command == "run":
            if len(args) < 2:
                self._append_entry("recovery", "Tools", "Usage: /tools run <tool-id> key=value ...")
                return
            try:
                arguments = self._parse_named_arguments(args[2:])
            except ValueError as error:
                self._append_entry("recovery", "Tools", str(error))
                return
            try:
                result = self._run_tool_with_progress(args[1], arguments)
            except Exception as error:
                self._append_entry("recovery", "Tool result", str(error), meta=args[1])
                return
            self._append_entry(
                "assistant" if result.outcome == "success" else "recovery",
                "Tool result",
                result.summary,
                meta=f"{args[1]} · outcome={result.outcome}",
            )
            return
        self._append_entry("recovery", "Tools", "Usage: /tools [inspect|enable|disable|install|run]")

    def _append_skills(self, args: list[str]) -> None:
        command = args[0] if args else "list"
        if command in {"list", "ls"}:
            skills = self.runtime.skill_catalog(session_id=self.session_id)
            lines = [
                f"{skill.skill_id} | enabled={skill.enabled} | {skill.display_name} | {skill.summary}"
                for skill in skills
            ] or ["<empty>"]
            lines.extend(
                [
                    "",
                    "search: /skills search <query>",
                    "inspect: /skills inspect <skill-id>",
                    "enable: /skills enable <skill-id>",
                    "disable: /skills disable <skill-id>",
                    "install from hub: /skills install <skill-id>",
                    "install from path: /skills install </path/to/skill-or-skills.json>",
                ]
            )
            self._append_entry("notice", "Skills", "\n".join(lines))
            return
        if command == "search":
            if len(args) < 2:
                self._append_entry("recovery", "Skills", "Usage: /skills search <query>")
                return
            matches = self.runtime.search_skill_hub(" ".join(args[1:]))
            lines = [
                f"{entry.reference} | {entry.display_name} | {entry.summary} | source={entry.source_label}"
                for entry in matches
            ] or ["<empty>"]
            lines.extend(
                [
                    "",
                    "install one: /skills install <source:skill-id>",
                ]
            )
            self._append_entry("notice", "Skill search", "\n".join(lines))
            return
        if command == "inspect":
            if len(args) < 2:
                self._append_entry("recovery", "Skills", "Usage: /skills inspect <skill-id>")
                return
            skill = self.runtime.inspect_skill(args[1], session_id=self.session_id)
            self._append_entry(
                "status",
                "Skill",
                "\n".join(
                    [
                        f"skill_id: {skill.skill_id}",
                        f"display_name: {skill.display_name}",
                        f"enabled: {skill.enabled}",
                        f"version: {skill.version}",
                        f"summary: {skill.summary}",
                        f"provenance: {skill.provenance or 'built-in'}",
                    ]
                ),
            )
            return
        if command in {"enable", "disable"}:
            if len(args) < 2:
                self._append_entry("recovery", "Skills", f"Usage: /skills {command} <skill-id>")
                return
            updated = self.runtime.set_skill_enabled(
                args[1],
                command == "enable",
                session_id=self.session_id,
            )
            self._append_entry("status", "Skill updated", f"{updated.skill_id}\nenabled: {updated.enabled}")
            return
        if command == "install":
            if len(args) < 2:
                self._append_entry("recovery", "Skills", "Usage: /skills install <skill-id|/path/to/skill|/path/to/skills.json>")
                return
            try:
                record = self.runtime.install_skill_source(args[1], session_id=self.session_id)
            except Exception as error:
                self._append_entry("recovery", "Skills", str(error))
                return
            self._append_entry(
                "status",
                "Skill installed",
                "\n".join(
                    [
                        f"source_path: {record.source_path}",
                        f"skill_ids: {', '.join(record.skill_ids) or '<empty>'}",
                    ]
                ),
            )
            return
        self._append_entry("recovery", "Skills", "Usage: /skills [search|inspect|enable|disable|install]")

    def _append_mcp(self, args: list[str]) -> None:
        command = args[0] if args else "list"
        if command in {"list", "ls"}:
            servers = self.runtime.mcp_catalog(session_id=self.session_id)
            lines = [
                f"{server.server_id} | enabled={server.enabled} | {server.display_name} | {server.summary}"
                for server in servers
            ] or ["<empty>"]
            lines.extend(
                [
                    "",
                    "search: /mcp search <query>",
                    "inspect: /mcp inspect <server-id>",
                    "enable: /mcp enable <server-id>",
                    "disable: /mcp disable <server-id>",
                    "install: /mcp install <server-id>",
                ]
            )
            self._append_entry("notice", "MCP servers", "\n".join(lines))
            return
        if command == "search":
            if len(args) < 2:
                self._append_entry("recovery", "MCP servers", "Usage: /mcp search <query>")
                return
            matches = self.runtime.search_mcp_registry(" ".join(args[1:]))
            lines = [
                f"{server.server_id} | {server.display_name} | {server.summary}"
                for server in matches
            ] or ["<empty>"]
            lines.extend(
                [
                    "",
                    "install one: /mcp install <server-id>",
                ]
            )
            self._append_entry("notice", "MCP search", "\n".join(lines))
            return
        if command == "inspect":
            if len(args) < 2:
                self._append_entry("recovery", "MCP servers", "Usage: /mcp inspect <server-id>")
                return
            server = self.runtime.inspect_mcp_server(args[1], session_id=self.session_id)
            self._append_entry(
                "status",
                "MCP server",
                "\n".join(
                    [
                        f"server_id: {server.server_id}",
                        f"display_name: {server.display_name}",
                        f"enabled: {server.enabled}",
                        f"transport: {server.transport}",
                        f"command: {server.command or '<none>'}",
                        f"args: {' '.join(server.args) or '<none>'}",
                        f"url: {server.url or '<none>'}",
                        f"provenance: {server.provenance or 'registry'}",
                    ]
                ),
            )
            return
        if command in {"enable", "disable"}:
            if len(args) < 2:
                self._append_entry("recovery", "MCP servers", f"Usage: /mcp {command} <server-id>")
                return
            updated = self.runtime.set_mcp_enabled(
                args[1],
                command == "enable",
                session_id=self.session_id,
            )
            self._append_entry("status", "MCP updated", f"{updated.server_id}\nenabled: {updated.enabled}")
            return
        if command == "install":
            if len(args) < 2:
                self._append_entry("recovery", "MCP servers", "Usage: /mcp install <server-id>")
                return
            try:
                server = self.runtime.install_mcp_server(args[1], session_id=self.session_id)
            except Exception as error:
                self._append_entry("recovery", "MCP servers", str(error))
                return
            self._append_entry(
                "status",
                "MCP installed",
                "\n".join(
                    [
                        f"server_id: {server.server_id}",
                        f"display_name: {server.display_name}",
                        f"transport: {server.transport}",
                        f"command: {server.command or '<none>'}",
                    ]
                ),
            )
            return
        self._append_entry("recovery", "MCP servers", "Usage: /mcp [search|inspect|enable|disable|install]")

    def _append_cron(self, args: list[str]) -> None:
        command = args[0] if args else "list"
        if command in {"list", "ls"}:
            jobs = self.runtime.cron_jobs(session_id=self.session_id)
            lines = [
                f"{job.job_id} | {job.status} | {job.name} | {job.schedule_text} | {job.action_kind}"
                for job in jobs
            ] or ["<empty>"]
            lines.extend(
                [
                    "",
                    'create greeting: /cron create name="Morning hello" schedule="every morning" kind=greeting message="Good morning."',
                    'create web search: /cron create name="Web check" schedule="every 2h" kind=web_search query="agentic ai news"',
                    "inspect: /cron inspect <job-id>",
                    "pause: /cron pause <job-id>",
                    "resume: /cron resume <job-id>",
                    "remove: /cron remove <job-id>",
                ]
            )
            self._append_entry("notice", "Cron jobs", "\n".join(lines))
            return
        if command == "create":
            try:
                arguments = self._parse_named_arguments(args[1:])
            except ValueError as error:
                self._append_entry("recovery", "Cron jobs", str(error))
                return
            schedule = arguments.get("schedule", "").strip()
            action_kind = arguments.get("kind", "").strip()
            if not schedule or not action_kind:
                self._append_entry(
                    "recovery",
                    "Cron jobs",
                    "Usage: /cron create name=<name> schedule=<schedule> kind=greeting|web_search|prompt [message=...] [query=...] [prompt=...]",
                )
                return
            payload = {
                key: value
                for key, value in (
                    ("message", arguments.get("message")),
                    ("query", arguments.get("query")),
                    ("prompt", arguments.get("prompt")),
                )
                if value
            }
            name = arguments.get("name", "").strip() or f"Cron · {action_kind}"
            try:
                job = self.runtime.create_cron_job(
                    session_id=self.session_id,
                    name=name,
                    schedule=schedule,
                    action_kind=action_kind,
                    payload=payload,
                )
            except Exception as error:
                self._append_entry("recovery", "Cron jobs", str(error))
                return
            self._append_entry(
                "status",
                "Cron job created",
                "\n".join(
                    [
                        f"job_id: {job.job_id}",
                        f"name: {job.name}",
                        f"schedule: {job.schedule_text}",
                        f"action_kind: {job.action_kind}",
                        f"next_run_at: {job.next_run_at.isoformat() if job.next_run_at is not None else '<none>'}",
                    ]
                ),
            )
            return
        if command == "inspect":
            if len(args) < 2:
                self._append_entry("recovery", "Cron jobs", "Usage: /cron inspect <job-id>")
                return
            try:
                job = self.runtime.inspect_cron_job(args[1])
            except Exception as error:
                self._append_entry("recovery", "Cron jobs", str(error))
                return
            self._append_entry(
                "status",
                "Cron job",
                "\n".join(
                    [
                        f"job_id: {job.job_id}",
                        f"name: {job.name}",
                        f"status: {job.status}",
                        f"schedule: {job.schedule_text}",
                        f"action_kind: {job.action_kind}",
                        f"last_summary: {job.last_summary or '<none>'}",
                    ]
                ),
            )
            return
        if command in {"pause", "resume", "remove"}:
            if len(args) < 2:
                self._append_entry("recovery", "Cron jobs", f"Usage: /cron {command} <job-id>")
                return
            try:
                if command == "pause":
                    job = self.runtime.pause_cron_job(args[1])
                elif command == "resume":
                    job = self.runtime.resume_cron_job(args[1])
                else:
                    job = self.runtime.remove_cron_job(args[1])
            except Exception as error:
                self._append_entry("recovery", "Cron jobs", str(error))
                return
            self._append_entry(
                "status",
                "Cron job updated",
                "\n".join(
                    [
                        f"job_id: {job.job_id}",
                        f"name: {job.name}",
                        f"status: {'removed' if command == 'remove' else job.status}",
                    ]
                ),
            )
            return
        self._append_entry("recovery", "Cron jobs", "Usage: /cron [create|inspect|pause|resume|remove]")

    def _parse_named_arguments(self, args: list[str]) -> dict[str, str]:
        payload: dict[str, str] = {}
        for item in args:
            if "=" not in item:
                raise ValueError("tool arguments must be key=value pairs")
            key, value = item.split("=", 1)
            key = key.strip()
            if not key:
                raise ValueError("tool argument keys must not be empty")
            payload[key] = self._strip_wrapping_quotes(value.strip())
        return payload

    def _requested_webpage_url(self, message: str) -> str | None:
        lowered = message.strip().lower()
        match = WEB_URL_PATTERN.search(message)
        if match is None:
            return None
        if not any(
            phrase in lowered
            for phrase in (
                "read ",
                "open ",
                "fetch ",
                "visit ",
                "browse ",
                "look at ",
                "check ",
                "web page",
                "website",
                " url",
            )
        ):
            return None
        return match.group(1).rstrip(").,!?\"'")

    def _strip_wrapping_quotes(self, value: str) -> str:
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
            return value[1:-1].strip()
        return value

    def _append_status(self) -> None:
        session = self.runtime.inspect_session(self.session_id)
        provider = dict(self.runtime.provider_summary())
        continuity = self.runtime.inspect_continuity(session_id=self.session_id)
        growth = self.runtime.inspect_growth(session_id=self.session_id)
        lines = [
            f"session_id: {session.session_id}",
            f"clone_id: {self.runtime.clone_id_for_session(session)}",
            f"status: {session.status}",
            f"provider_id: {provider['provider_id']}",
            f"provider_source: {provider['source']}",
            f"provider_model_id: {provider['default_model'] or '<unset>'}",
            f"growth_action: {continuity.wake_action}",
            f"growth_summary: {continuity.wake_summary}",
            f"voice_status: {continuity.voice_status}",
            f"growth_title: {growth.stage.title}",
            f"growth_stage: {growth.stage.display_name}",
            f"growth_level: {growth.level}",
            f"growth_exp: {growth.state.growth_score}",
            f"growth_progress: {growth.progress_percent}%",
            f"growth_next: {growth.score_to_next_level} EXP to Lv.{min(growth.level + 1, 40)}",
            (
                "growth_lifetime: "
                f"dialogues={growth.state.total_dialogues} "
                f"tokens={growth.state.total_tokens} "
                f"experiences={growth.state.total_experiences} "
                f"promoted={growth.state.promoted_experiences} "
                f"active_days={growth.state.active_days}"
            ),
        ]
        experiences = self.runtime.inspect_experiences(session_id=self.session_id, limit=2)
        displayable = self._displayable_experiences(experiences)
        if displayable:
            lines.append(f"latest_learning: {self._format_experience_status(displayable[0])}")
        else:
            lines.append("latest_learning: no captured experience yet")
        self._append_entry("status", "Clone status", "\n".join(lines))

    def _append_clones(self) -> None:
        clones = self.runtime.list_clones(limit=12)
        current_session = self.runtime.inspect_session(self.session_id)
        current_clone_id = self.runtime.clone_id_for_session(current_session)
        lines = [
            (
                f"{clone.clone_id} | current={clone.clone_id == current_clone_id} | "
                f"sessions={clone.session_count} | latest={clone.latest_session_id[:8]}"
            )
            for clone in clones
        ] or ["<empty>"]
        lines.extend(
            [
                "",
                "retire one: aegis clones bye <name>",
                "retire all: aegis clones bye --all",
            ]
        )
        self._append_entry("notice", "Clones", "\n".join(lines))

    def _append_goals(self) -> None:
        goals = self.runtime.inspect_goals(self.session_id)
        lines = [f"{goal.goal_id} | {goal.status} | {goal.priority} | {goal.title}" for goal in goals] or ["<empty>"]
        self._append_entry("notice", "Goals", "\n".join(lines))

    def _append_memory(self) -> None:
        memories = self.runtime.inspect_memories(self.session_id)
        lines = [
            f"{memory.memory_id} | {memory.kind} | {', '.join(memory.tags) or '<none>'} | {memory.content}"
            for memory in memories
        ] or ["<empty>"]
        self._append_entry("notice", "Memory", "\n".join(lines))

    def _resume_session(self, target: str) -> None:
        if target == "latest":
            latest = self.runtime.latest_session()
            if latest is None:
                self._append_entry("recovery", "Resume", "No existing clone is available. Use /clone to create one.")
                return
            self.session_id = latest.session_id
            self.opened = f"Opened clone {self.runtime.clone_id_for_session(latest)}"
        else:
            clone_session = self.runtime.latest_session_for_clone(target)
            if clone_session is not None:
                self.session_id = clone_session.session_id
                self.opened = f"Opened clone {target}"
            else:
                self.runtime.inspect_session(target)
                self.session_id = target
                selected = self.runtime.inspect_session(target)
                self.opened = f"Opened clone {self.runtime.clone_id_for_session(selected)}"
        self._append_entry("status", "Resume", f"{self.opened} via session {self.session_id}.")
        self._append_status()

    def _clone_new_session(self, clone_id: str) -> None:
        session = self.runtime.create_clone(clone_id=clone_id, mode="her")
        self.session_id = session.session_id
        resolved_clone_id = self.runtime.clone_id_for_session(session)
        self.opened = "Cloned new"
        self._append_entry("status", "Clone created", f"Cloned {resolved_clone_id} via session {self.session_id}.")
        self._append_status()

    def _append_identity(self, args: list[str]) -> None:
        action = args[0] if args else "inspect"
        profile_id = self.runtime.inspect_session(self.session_id).profile_id
        if action == "inspect":
            lines = self._identity_lines(profile_id)
            lines.extend(
                [
                    "set name: /identity set-name <display-name>",
                    "soul: /identity soul show|set|clear",
                    "initiative: /identity initiative <value>",
                    "preset: /identity preset <preset-id>",
                ]
            )
            self._append_entry("notice", "Identity", "\n".join(lines))
            return
        if action == "set-name":
            if len(args) < 2:
                self._append_entry("recovery", "Identity", "Usage: /identity set-name <display-name>")
                return
            loaded = self.runtime.update_identity(profile_id=profile_id, display_name=" ".join(args[1:]))
            self._append_entry("notice", "Identity updated", f"display_name: {loaded.state.display_name}")
            return
        if action == "set-mode":
            self.runtime.update_identity(profile_id=profile_id, mode="her")
            self._append_entry("notice", "Identity", "mode: her\nAegis now stays in her mode by default.")
            return
        if action == "initiative":
            if len(args) != 2:
                self._append_entry("recovery", "Identity", "Usage: /identity initiative <value>")
                return
            self.runtime.update_identity(profile_id=profile_id, mode="her")
            loaded = self.runtime.update_her_mode(profile_id=profile_id, initiative=args[1])
            initiative = loaded.her_mode.initiative if loaded.her_mode is not None else "<none>"
            self._append_entry("notice", "Identity updated", f"initiative: {initiative}")
            return
        if action in {"preset", "personality"}:
            if len(args) != 2:
                self._append_entry("recovery", "Identity", "Usage: /identity preset <preset-id>")
                return
            self.runtime.update_identity(profile_id=profile_id, mode="her")
            loaded = self.runtime.update_her_mode(profile_id=profile_id, personality_preset=args[1])
            rendered = ", ".join(loaded.her_mode.personality) if loaded.her_mode is not None else "<none>"
            preset = loaded.her_mode.personality_preset if loaded.her_mode is not None else "<none>"
            self._append_entry("notice", "Identity updated", f"personality_preset: {preset}\npersonality_traits: {rendered}")
            return
        if action == "soul":
            self._append_identity_soul(profile_id, args[1:])
            return
        self._append_entry("recovery", "Identity", "Usage: /identity inspect|set-name|soul|initiative|preset")

    def _append_identity_soul(self, profile_id: str, args: list[str]) -> None:
        action = args[0] if args else "show"
        if action == "show":
            profile = self.runtime.inspect_profile(profile_id)
            self._append_entry(
                "notice",
                "SOUL",
                "\n".join(
                    [
                        f"profile_id: {profile.state.profile_id}",
                        f"soul_path: {profile.state.soul_path or '<empty>'}",
                        f"soul_text: {profile.soul_text or '<empty>'}",
                    ]
                ),
            )
            return
        if action == "set":
            if len(args) < 2:
                self._append_entry("recovery", "SOUL", "Usage: /identity soul set <text>")
                return
            loaded = self.runtime.update_soul_text(profile_id=profile_id, soul_text=" ".join(args[1:]))
            self._append_entry("notice", "SOUL updated", f"soul_text: {loaded.soul_text or '<empty>'}")
            return
        if action == "clear":
            self.runtime.update_soul_text(profile_id=profile_id, soul_text=None)
            self._append_entry("notice", "SOUL updated", "status: cleared")
            return
        self._append_entry("recovery", "SOUL", "Usage: /identity soul show|set|clear")

    def _append_doctor(self) -> None:
        provider = self.runtime.provider_doctor()
        voice = self.runtime.voice_doctor(profile_id=self.runtime.inspect_session(self.session_id).profile_id)
        security = self.runtime.security_doctor()
        lines = [
            f"provider_status: {provider['status']}",
            f"voice_status: {voice['status']}",
            f"security_status: {security['status']}",
        ]
        for check in provider["checks"]:
            summary = f" | {check['summary']}" if check.get("summary") else ""
            lines.append(f"{check['check']}: {check['status']}{summary}")
        for check in voice["checks"]:
            summary = f" | {check['summary']}" if check.get("summary") else ""
            lines.append(f"voice/{check['check']}: {check['status']}{summary}")
        if provider["status"] != "ready":
            lines.append("next: exit and run aegis born")
        else:
            lines.append("next: keep talking")
        self._append_entry("notice", "Health", "\n".join(lines))

    def _append_wake(self) -> None:
        try:
            outcome = self.runtime.wake(self.session_id, inspect_only=True)
        except Exception:
            continuity = self.runtime.inspect_continuity(session_id=self.session_id)
            self._append_entry(
                "notice",
                "Growth progression",
                "\n".join(
                    [
                        f"mode: foreground",
                        f"selected_kind: {continuity.wake_action}",
                        "selected_goal_id: <none>",
                        f"rationale: {continuity.wake_summary}",
                        "planned_active_goal_id: <none>",
                    ]
                ),
            )
            return
        lines = [
            f"mode: {outcome.decision.mode}",
            f"selected_kind: {outcome.decision.selected_move.kind}",
            f"selected_goal_id: {outcome.decision.selected_move.goal_id or '<none>'}",
            f"rationale: {outcome.decision.rationale.summary}",
            f"planned_active_goal_id: {outcome.planned_goal_graph.active_goal_id or '<none>'}",
        ]
        self._append_entry("notice", "Growth progression", "\n".join(lines))

    def _append_outcome(self, outcome: KernelOutcome) -> None:
        if self.debug and outcome.stages:
            stage_lines = [
                f"{stage.stage} | {stage.detail} | {stage.recorded_at.isoformat(timespec='seconds')}"
                for stage in outcome.stages
            ]
            self._append_entry("status", "Runtime stages", "\n".join(stage_lines))
        assistant_name = self.runtime.inspect_profile(self.runtime.inspect_session(self.session_id).profile_id).state.display_name
        assistant_lines = [outcome.execution.summary]
        if self.debug and outcome.plan is not None:
            assistant_lines.append(f"plan: {outcome.plan.rationale}")
        if self.debug:
            assistant_lines.extend(
                [
                    f"execution: {outcome.execution.outcome}",
                    f"goals_in_play: {len(outcome.goals)}",
                    f"memory_hits: {len(outcome.memories)}",
                ]
            )
        self._append_entry("assistant", assistant_name, "\n".join(assistant_lines))

    def _show_growth_celebration_if_needed(self) -> None:
        update = self.runtime.consume_growth_update(session_id=self.session_id)
        if update is None or not update.leveled_up:
            return
        if not self._animations_enabled() or Live is None:
            return
        if update.stage_changed:
            with Live(
                self._render_stage_transition_frame(update, tick=0),
                console=self.console,
                refresh_per_second=24,
                transient=True,
            ) as live:
                for tick in range(4):
                    live.update(self._render_stage_transition_frame(update, tick=tick), refresh=True)
                    time.sleep(0.12)
            return
        with Live(
            self._render_level_up_frame(update, tick=0),
            console=self.console,
            refresh_per_second=24,
            transient=True,
        ) as live:
            for tick in range(4):
                live.update(self._render_level_up_frame(update, tick=tick), refresh=True)
                time.sleep(0.1)

    def _render_level_up_frame(self, update, *, tick: int):
        marker = ("*", "+", "*", "+")[tick % 4]
        body = Text()
        body.append(f"{marker} LEVEL UP\n", style=f"bold {BRAND_ACCENT_STRONG}")
        body.append(
            f"{update.after.stage.title} · {update.after.stage.display_name}\n",
            style=f"bold {BRAND_LIGHT}",
        )
        body.append(f"Lv.{update.before.level} -> Lv.{update.after.level}\n", style=BRAND_LIGHT)
        body.append(
            f"EXP +{update.delta_score} · {self._growth_progress_bar(update.after)} · {update.after.progress_percent}%",
            style=BRAND_MUTED,
        )
        return Panel(
            body,
            title=f"[bold {BRAND_ACCENT}]Aegis is evolving[/bold {BRAND_ACCENT}]",
            border_style=BRAND_ACCENT,
            padding=(0, 1),
        )

    def _render_stage_transition_frame(self, update, *, tick: int):
        if Table is None or Group is None:
            return Text(
                f"Stage shift: {update.before.stage.display_name} -> {update.after.stage.display_name} "
                f"(Lv.{update.after.level})"
            )
        body = Table.grid(expand=True)
        body.add_column(ratio=1, justify="center")
        body.add_column(ratio=1, justify="center")
        left_mark = self._render_growth_mark(update.before.stage.stage_id)
        right_mark = self._render_growth_mark(update.after.stage.stage_id)
        if tick % 2 == 1:
            left_mark, right_mark = right_mark, left_mark
        body.add_row(left_mark, right_mark)
        caption = Text()
        caption.append("STAGE SHIFT\n", style=f"bold {BRAND_ACCENT_STRONG}")
        caption.append(
            f"{update.before.stage.title} -> {update.after.stage.title}\n",
            style=f"bold {BRAND_LIGHT}",
        )
        caption.append(
            f"Lv.{update.before.level} -> Lv.{update.after.level} · {update.after.score_to_next_level} EXP to next level",
            style=BRAND_MUTED,
        )
        return Panel(
            Group(body, caption),
            title=f"[bold {BRAND_ACCENT}]Aegis crossed a new stage[/bold {BRAND_ACCENT}]",
            border_style=BRAND_ACCENT,
            padding=(0, 1),
        )

    def _identity_lines(self, profile_id: str) -> list[str]:
        profile = self.runtime.inspect_profile(profile_id)
        lines = [
            f"profile_id: {profile.state.profile_id}",
            f"display_name: {profile.state.display_name}",
            f"mode: {profile.state.mode}",
            f"soul_path: {profile.state.soul_path or '<empty>'}",
            f"soul_text: {profile.soul_text or '<empty>'}",
        ]
        if profile.her_mode is not None:
            lines.extend(
                [
                    f"initiative: {profile.her_mode.initiative}",
                    f"personality_preset: {profile.her_mode.personality_preset}",
                    f"personality_traits: {', '.join(profile.her_mode.personality) or '<empty>'}",
                    f"governance_summary: {profile.her_mode.governance_summary()}",
                    f"voice_identity_summary: {profile.her_mode.voice_identity_summary()}",
                ]
            )
        full_contract = self.runtime.prompt_contract(profile_id=profile_id, prompt_mode="full")
        minimal_contract = self.runtime.prompt_contract(profile_id=profile_id, prompt_mode="minimal")
        lines.extend(
            [
                f"prompt_contract_full: {', '.join(full_contract.section_names)}",
                f"prompt_contract_minimal: {', '.join(minimal_contract.section_names)}",
            ]
        )
        return lines

    def _append_entry(self, kind: str, title: str, body: str, *, meta: str = "") -> None:
        self.transcript.append(TranscriptEntry(kind=kind, title=title, body=body, meta=meta))
        if len(self.transcript) > 40:
            overflow = len(self.transcript) - 40
            self.transcript = self.transcript[overflow:]
            self._rendered_entries = max(0, self._rendered_entries - overflow)

    def _animations_enabled(self) -> bool:
        return RICH_AVAILABLE and Live is not None and os.environ.get("AEGIS_NO_ANIMATION") != "1"

    def _turn_phase(self, tick: int) -> tuple[str, str, str]:
        phases = (
            ("recover.clone", "Recovering the active clone and its durable context"),
            ("aligning.identity", "Keeping Aegis identity locked"),
            ("drafting.reply", "Shaping the next reply"),
        )
        phase_label, phase_detail = phases[(tick // 3) % len(phases)]
        marker = ("·", "•", "●", "•")[tick % 4]
        return marker, phase_label, phase_detail

    def _summarize_progress_prompt(self, prompt: str) -> str:
        normalized = " ".join(prompt.split())
        if len(normalized) <= 72:
            return normalized
        return f"{normalized[:69]}..."

    def _render_turn_progress_fragments(
        self,
        *,
        prompt: str,
        tick: int,
        tool_event: ToolLifecycleEvent | None = None,
        queued_count: int = 0,
    ) -> FormattedText:
        marker, phase_label, phase_detail = self._turn_phase(tick)
        fragments: list[tuple[str, str]] = [
            ("class:progress-title", "Aegis is growing\n"),
            ("class:progress-active", f"{marker} {phase_detail}\n"),
            ("class:progress-meta", f"{phase_label} · active request: {self._summarize_progress_prompt(prompt)}"),
        ]
        if queued_count:
            label = "message" if queued_count == 1 else "messages"
            fragments.append(("class:progress-queue", f"\nqueued follow-ups · {queued_count} {label}"))
        tool_title, tool_detail = self._tool_event_lines(tool_event)
        if tool_title is not None:
            fragments.append(("class:progress-tool", f"\n{tool_title}"))
        if tool_detail is not None:
            fragments.append(("class:progress-meta", f"\n{tool_detail}"))
        fragments.append(("class:progress-hint", "\nPress Enter to queue another message."))
        return FormattedText(fragments)

    def _render_queued_followup_fragments(self) -> FormattedText:
        fragments: list[tuple[str, str]] = []
        for command in self._pending_commands:
            lines = _strip_markdown_bold(command.command).splitlines() or [""]
            for index, line in enumerate(lines):
                prefix = "› " if index == 0 else "  "
                fragments.append(("", " " * QUEUE_PREVIEW_INSET))
                fragments.append(("class:queue-user", self._pad_queue_preview_line(f"{prefix}{line}")))
                fragments.append(("", "\n"))
        if fragments:
            fragments.pop()
        return FormattedText(fragments)

    def _queued_turn_input_supported(self) -> bool:
        return self._prompt_toolkit_composer_available()

    def _resolve_turn_outcome(self, holder: dict[str, object]) -> KernelOutcome:
        error = holder.get("error")
        if isinstance(error, Exception):
            raise error
        outcome = holder.get("outcome")
        if not isinstance(outcome, KernelOutcome):
            raise RuntimeError("turn completed without a kernel outcome")
        return outcome

    def _run_turn_with_queued_input(self, prompt: str) -> KernelOutcome:
        holder: dict[str, object] = {}
        tool_event_holder, tool_event_lock, tool_observer = self._tool_event_tracker()
        unsubscribe = self.runtime.tool_runtime.subscribe(tool_observer)

        def worker() -> None:
            try:
                holder["outcome"] = self.runtime.explain_next_step(session_id=self.session_id, prompt=prompt)
            except Exception as error:  # pragma: no cover - surfaced below
                holder["error"] = error

        thread = threading.Thread(target=worker, daemon=True)
        thread.start()
        started_at = time.monotonic()
        buffer = self._build_prompt_buffer()
        input_window = self._build_input_window(buffer)
        command_palette = self._build_command_palette()

        def submit(event) -> None:
            raw_command = event.current_buffer.text
            if not raw_command.strip():
                return
            event.current_buffer.append_to_history()
            event.current_buffer.text = ""
            self._enqueue_followup_command(raw_command)
            event.app.invalidate()

        progress_window = Window(
            FormattedTextControl(
                lambda: self._render_turn_progress_fragments(
                    prompt=prompt,
                    tick=int(max(0.0, time.monotonic() - started_at) / 0.08),
                    tool_event=self._latest_tool_event(tool_event_holder, tool_event_lock),
                    queued_count=len(self._pending_commands),
                )
            ),
            wrap_lines=True,
            dont_extend_height=True,
        )
        composer_body = self._build_composer_body(
            input_window=input_window,
            command_palette=command_palette,
            top_windows=(progress_window, self._build_queue_preview_window()),
        )
        application = Application(
            layout=Layout(composer_body, focused_element=input_window),
            key_bindings=self._build_key_bindings(submit=submit, allow_exit=False),
            style=self._prompt_style(),
            full_screen=False,
            erase_when_done=True,
            refresh_interval=0.08,
        )

        def exit_when_complete() -> None:
            thread.join()
            try:
                application.exit(result=True)
            except Exception:  # pragma: no cover - defensive cross-thread exit
                return

        threading.Thread(target=exit_when_complete, daemon=True).start()
        try:
            application.run()
        finally:
            unsubscribe()
        return self._resolve_turn_outcome(holder)

    def _run_turn_with_progress(self, prompt: str) -> KernelOutcome:
        if not self._animations_enabled():
            return self.runtime.explain_next_step(session_id=self.session_id, prompt=prompt)
        if self._queued_turn_input_supported():
            return self._run_turn_with_queued_input(prompt)

        holder: dict[str, object] = {}
        tool_event_holder, tool_event_lock, tool_observer = self._tool_event_tracker()
        unsubscribe = self.runtime.tool_runtime.subscribe(tool_observer)

        def worker() -> None:
            try:
                holder["outcome"] = self.runtime.explain_next_step(session_id=self.session_id, prompt=prompt)
            except Exception as error:  # pragma: no cover - surfaced below
                holder["error"] = error

        thread = threading.Thread(target=worker, daemon=True)
        thread.start()
        tick = 0
        try:
            with Live(
                self._render_turn_frame(prompt=prompt, tick=tick),
                console=self.console,
                refresh_per_second=18,
                transient=True,
            ) as live:
                while thread.is_alive():
                    live.update(
                        self._render_turn_frame(
                            prompt=prompt,
                            tick=tick,
                            tool_event=self._latest_tool_event(tool_event_holder, tool_event_lock),
                        ),
                        refresh=True,
                    )
                    time.sleep(0.08)
                    tick += 1
                thread.join(timeout=0.1)
        finally:
            unsubscribe()
        return self._resolve_turn_outcome(holder)

    def _run_tool_with_progress(self, tool_id: str, arguments: dict[str, str]):
        if not self._animations_enabled():
            return self.runtime.run_tool(tool_id, arguments, session_id=self.session_id)

        holder: dict[str, object] = {}
        tool_event_holder, tool_event_lock, tool_observer = self._tool_event_tracker()
        unsubscribe = self.runtime.tool_runtime.subscribe(tool_observer)

        def worker() -> None:
            try:
                holder["result"] = self.runtime.run_tool(tool_id, arguments, session_id=self.session_id)
            except Exception as error:  # pragma: no cover - surfaced below
                holder["error"] = error

        thread = threading.Thread(target=worker, daemon=True)
        thread.start()
        tick = 0
        try:
            with Live(
                self._render_tool_frame(tool_id=tool_id, tick=tick),
                console=self.console,
                refresh_per_second=18,
                transient=True,
            ) as live:
                while thread.is_alive():
                    live.update(
                        self._render_tool_frame(
                            tool_id=tool_id,
                            tick=tick,
                            tool_event=self._latest_tool_event(tool_event_holder, tool_event_lock),
                        ),
                        refresh=True,
                    )
                    time.sleep(0.08)
                    tick += 1
                thread.join(timeout=0.1)
        finally:
            unsubscribe()
        error = holder.get("error")
        if isinstance(error, Exception):
            raise error
        result = holder.get("result")
        if result is None:
            raise RuntimeError("tool call completed without a result")
        return result

    def _tool_event_tracker(self):
        holder: dict[str, ToolLifecycleEvent | None] = {"latest": None}
        lock = threading.Lock()

        def observer(event: ToolLifecycleEvent) -> None:
            with lock:
                holder["latest"] = event

        return holder, lock, observer

    def _latest_tool_event(self, holder, lock) -> ToolLifecycleEvent | None:
        with lock:
            return holder.get("latest")

    def _render_turn_frame(self, *, prompt: str, tick: int, tool_event: ToolLifecycleEvent | None = None):
        marker, phase_label, phase_detail = self._turn_phase(tick)
        if not RICH_AVAILABLE:
            tool_summary = self._tool_event_summary(tool_event)
            return f"{marker} {phase_detail}" if tool_summary is None else f"{marker} {phase_detail} | {tool_summary}"
        body = Text()
        body.append(f"{marker} {phase_detail}\n", style=f"bold {BRAND_ACCENT_STRONG}")
        body.append(f"{phase_label}", style=BRAND_MUTED)
        tool_title, tool_detail = self._tool_event_lines(tool_event)
        if tool_title is not None:
            body.append(f"\n{tool_title}", style=f"bold {BRAND_LIGHT}")
            if tool_detail is not None:
                body.append(f"\n{tool_detail}", style=BRAND_MUTED)
        return Panel(
            body,
            title=f"[bold {BRAND_ACCENT}]Aegis is growing[/bold {BRAND_ACCENT}]",
            border_style=BRAND_DARK,
            padding=(0, 1),
        )

    def _render_tool_frame(self, *, tool_id: str, tick: int, tool_event: ToolLifecycleEvent | None = None):
        phases = (
            ("tool.bind", "Binding the requested built-in capability"),
            ("tool.execute", "Running the tool inside the current clone surface"),
            ("tool.report", "Folding the tool result back into the transcript"),
        )
        phase_label, phase_detail = phases[(tick // 3) % len(phases)]
        marker = ("·", "•", "●", "•")[tick % 4]
        if not RICH_AVAILABLE:
            tool_summary = self._tool_event_summary(tool_event)
            return f"{marker} {phase_detail}" if tool_summary is None else f"{marker} {tool_summary}"
        body = Text()
        body.append(f"{marker} {phase_detail}\n", style=f"bold {BRAND_ACCENT_STRONG}")
        body.append(f"{phase_label} · {tool_id}", style=BRAND_MUTED)
        tool_title, tool_detail = self._tool_event_lines(tool_event)
        if tool_title is not None:
            body.append(f"\n{tool_title}", style=f"bold {BRAND_LIGHT}")
            if tool_detail is not None:
                body.append(f"\n{tool_detail}", style=BRAND_MUTED)
        return Panel(
            body,
            title=f"[bold {BRAND_ACCENT}]Aegis is using a tool[/bold {BRAND_ACCENT}]",
            border_style=BRAND_DARK,
            padding=(0, 1),
        )

    def _tool_event_lines(self, tool_event: ToolLifecycleEvent | None) -> tuple[str | None, str | None]:
        if tool_event is None:
            return (None, None)
        phase_labels = {
            "requested": "Tool requested",
            "classified": "Tool classified",
            "approval.granted": "Approval granted",
            "approval.denied": "Approval denied",
            "approval.deferred": "Approval deferred",
            "execution.started": "Tool executing",
            "execution.completed": "Tool completed",
            "execution.failed": "Tool failed",
        }
        title = f"{phase_labels.get(tool_event.phase, tool_event.phase)} · {tool_event.invocation.tool_id}"
        details = [tool_event.detail]
        if tool_event.approval is not None and tool_event.approval.required_controls:
            details.append(f"controls: {', '.join(tool_event.approval.required_controls)}")
        if tool_event.execution is not None:
            details.append(f"outcome: {tool_event.execution.outcome}")
        return (title, " · ".join(part for part in details if part))

    def _tool_event_summary(self, tool_event: ToolLifecycleEvent | None) -> str | None:
        if tool_event is None:
            return None
        title, _ = self._tool_event_lines(tool_event)
        return title

    def _render_pending_entries(self) -> None:
        pending = self.transcript[self._rendered_entries :]
        previous_kind = self.transcript[self._rendered_entries - 1].kind if self._rendered_entries else None
        for entry in pending:
            if entry.kind == "assistant" and previous_kind == "user":
                self.console.print("")
            self.console.print(self._render_entry(entry))
            previous_kind = entry.kind
        self._rendered_entries = len(self.transcript)

    def _render_entry(self, entry: TranscriptEntry):
        styles = {
            "assistant": BRAND_LIGHT,
            "user": USER_HISTORY_FG,
            "status": "bright_black",
            "notice": "white",
            "recovery": "yellow",
        }
        if entry.kind in {"assistant", "user"}:
            if RICH_AVAILABLE:
                return self._render_chat_entry(entry, accent=styles.get(entry.kind, "white"))
            prefix = "" if entry.kind == "user" else "● "
            lines = [f"{prefix}{_strip_markdown_bold(entry.body)}"]
            if entry.meta:
                lines.append(entry.meta)
            return "\n".join(lines) + "\n"
        return Panel(
            Text(entry.body),
            title=entry.title,
            subtitle=entry.meta,
            border_style=styles.get(entry.kind, "white"),
            padding=(0, 1),
        )

    def _growth_panel_lines(self, session, continuity, provider, growth) -> tuple[str, ...]:
        lines = [
            f"title · {growth.stage.title} · {growth.stage.display_name}",
            f"level · Lv.{growth.level} · EXP {growth.state.growth_score}",
            f"progress · {self._growth_progress_bar(growth)} · {growth.progress_percent}%",
        ]
        if growth.next_level_score is None:
            lines.append("next · max level reached")
        else:
            lines.append(f"next · {growth.score_to_next_level} EXP to Lv.{growth.level + 1}")
        lines.extend(
            [
                (
                    "lifetime · "
                    f"{growth.state.total_dialogues} dialogues · "
                    f"{growth.state.active_days} active days · "
                    f"{growth.lifetime_days} days across time"
                ),
                (
                    "learning · "
                    f"{growth.state.total_experiences} experiences · "
                    f"{growth.state.promoted_experiences} promoted · "
                    f"{growth.state.total_tokens} tokens"
                ),
            ]
        )
        experiences = self.runtime.inspect_experiences(session_id=session.session_id, limit=2)
        displayable = self._displayable_experiences(experiences)
        if displayable:
            lines.append(f"latest · {self._format_experience_status(displayable[0])}")
        else:
            lines.append("latest · no captured experience yet")
        if continuity.wake_action and continuity.wake_action != "idle":
            lines.append(f"next move · {continuity.wake_action}")
        return tuple(lines)

    def _recent_activity_lines(self, session, continuity, provider) -> tuple[str, ...]:
        growth = self.runtime.inspect_growth(session_id=session.session_id)
        return self._growth_panel_lines(session, continuity, provider, growth)

    def _recent_experience_lines(self, experiences: tuple[ExperienceRecord, ...]) -> tuple[str, ...]:
        return tuple(f"learning · {self._format_experience_status(experience)}" for experience in experiences)

    def _displayable_experiences(self, experiences: tuple[ExperienceRecord, ...]) -> tuple[ExperienceRecord, ...]:
        filtered = tuple(experience for experience in experiences if self._should_display_experience(experience))
        return filtered[:2]

    def _should_display_experience(self, experience: ExperienceRecord) -> bool:
        title = " ".join(experience.title.split()).strip()
        summary = " ".join(experience.summary.split()).strip()
        text = f"{title} {summary}".strip()
        if not text:
            return False
        lowered = text.lower()
        if EXPERIENCE_NOISE_PATTERN.match(title) or EXPERIENCE_NOISE_PATTERN.match(summary):
            return False
        if "requires an 'action' argument" in lowered:
            return False
        if "controls:" in lowered and "outcome: error" in lowered:
            return False
        return True

    def _format_experience_status(self, experience: ExperienceRecord) -> str:
        markers = [experience.status]
        if experience.tool_call_count:
            markers.append(f"tools={experience.tool_call_count}")
        if experience.model_turn_count:
            markers.append(f"turns={experience.model_turn_count}")
        if experience.related_skill_ids:
            markers.append(f"skills={len(experience.related_skill_ids)}")
        title = _compact_line(experience.title, limit=68)
        return f"{title} [{', '.join(markers)}]"

    def _growth_progress_bar(self, growth, *, width: int = 18) -> str:
        filled = min(width, max(0, round(growth.progress_ratio * width)))
        return "[" + ("#" * filled) + ("-" * (width - filled)) + "]"

    def _render_chat_entry(self, entry: TranscriptEntry, *, accent: str):
        if entry.kind == "user":
            block = Text()
            lines = _strip_markdown_bold(entry.body).splitlines() or [""]
            for index, line in enumerate(lines):
                prefix = "› " if index == 0 else "  "
                block.append(
                    self._pad_history_line(f"{prefix}{line}"),
                    style=f"{USER_HISTORY_FG} on {USER_HISTORY_BG}",
                )
                block.append("\n")
            if entry.meta:
                for meta_line in entry.meta.splitlines() or [""]:
                    block.append(
                        self._pad_history_line(f"  {meta_line}"),
                        style=f"{BRAND_MUTED} on {USER_HISTORY_BG}",
                    )
                    block.append("\n")
            return block

        block = Text()
        block.append("● ", style=f"bold {accent}")
        block.append_text(_render_markdown_bold(entry.body, base_style=BRAND_LIGHT))
        if entry.meta:
            block.append(f"\n{entry.meta}", style=BRAND_MUTED)
        block.append("\n")
        return block

    def _history_row_width(self) -> int:
        return max(24, len(self._composer_divider()))

    def _queue_preview_row_width(self) -> int:
        return max(16, self._history_row_width() - (QUEUE_PREVIEW_INSET * 2))

    def _pad_history_line(self, content: str) -> str:
        display_width = _display_width(content)
        width = self._history_row_width()
        if display_width >= width:
            return content
        return content + (" " * (width - display_width))

    def _pad_queue_preview_line(self, content: str) -> str:
        display_width = _display_width(content)
        width = self._queue_preview_row_width()
        if display_width >= width:
            return content
        return content + (" " * (width - display_width))

    def _center_brand_block(self, renderable):
        if Align is None:
            return renderable
        return Align.center(renderable)

    def _render_growth_mark(self, stage_id: str):
        return render_growth_mark(stage_id)

    def _render_guardian_mark(self):
        return render_guardian_mark()


def _display_path(path: Path) -> str:
    home = Path.home()
    try:
        return f"~/{path.relative_to(home)}"
    except ValueError:
        return str(path)


def _display_width(content: str) -> int:
    if RICH_AVAILABLE:
        return rich_cell_len(content)
    return len(content)


def _compact_line(value: str, *, limit: int) -> str:
    compact = " ".join(value.split()).strip()
    if len(compact) <= limit:
        return compact
    return compact[: max(0, limit - 3)].rstrip() + "..."


def render_guardian_mark():
    return _render_pixel_mark(_centered_rows(GUARDIAN_HEAD_ROWS), fallback="[Aegis guardian]")


def render_growth_mark(stage_id: str):
    rows = GROWTH_STAGE_ROWS.get(stage_id, GUARDIAN_STAGE_ROWS)
    fallback = f"[Aegis {stage_id}]"
    return _render_pixel_mark(_centered_rows(rows), fallback=fallback)


def _render_pixel_mark(rows: tuple[str, ...], *, fallback: str):
    if not RICH_AVAILABLE:
        return Text(fallback)
    palette = {
        "g": BRAND_ACCENT_STRONG,
        "c": "#e8e1d6",
        "t": BRAND_ACCENT,
        "m": BRAND_MUTED,
        "k": "#13161c",
        "x": "#08090c",
        " ": None,
    }
    glyph = Text(no_wrap=True)
    for row_index, row in enumerate(rows):
        for cell in row:
            color = palette.get(cell)
            if color is None:
                glyph.append("  ")
            else:
                glyph.append("██", style=color)
        if row_index < len(rows) - 1:
            glyph.append("\n")
    return glyph


def _centered_guardian_rows() -> tuple[str, ...]:
    return _centered_rows(GUARDIAN_HEAD_ROWS)


def _centered_rows(rows: tuple[str, ...]) -> tuple[str, ...]:
    width = max(len(row) for row in rows)
    centered: list[str] = []
    for row in rows:
        padding = width - len(row)
        left = padding // 2
        right = padding - left
        centered.append((" " * left) + row + (" " * right))
    return tuple(centered)


def _resolve_aegis_version() -> str:
    try:
        return package_version("aegis-ag")
    except PackageNotFoundError:
        pyproject = Path(__file__).resolve().parents[2] / "pyproject.toml"
        if pyproject.exists():
            for raw in pyproject.read_text(encoding="utf-8").splitlines():
                stripped = raw.strip()
                if stripped.startswith("version = "):
                    return stripped.split("=", 1)[1].strip().strip('"')
        return "dev"


def _strip_markdown_bold(text: str) -> str:
    return MARKDOWN_BOLD_PATTERN.sub(lambda match: match.group(1), text)


def _render_markdown_bold(text: str, *, base_style: str) -> Text:
    rendered = Text()
    cursor = 0
    for match in MARKDOWN_BOLD_PATTERN.finditer(text):
        if match.start() > cursor:
            rendered.append(text[cursor : match.start()], style=base_style)
        rendered.append(match.group(1), style=f"bold {base_style}")
        cursor = match.end()
    if cursor < len(text):
        rendered.append(text[cursor:], style=base_style)
    if not text:
        rendered.append("", style=base_style)
    return rendered
