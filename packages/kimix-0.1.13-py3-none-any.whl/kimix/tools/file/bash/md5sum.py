"""md5sum tool - compute and check MD5 message digest."""
import hashlib
import os
from pathlib import Path

from kimi_agent_sdk import CallableTool2, ToolError, ToolOk, ToolReturnValue
from .params import Params

from kimix.tools.common import _maybe_export_output_async


class Md5sum(CallableTool2[Params]):
    name: str = "Md5sum"
    description: str = "Compute and check MD5 message digest."
    params: type[Params] = Params

    async def __call__(self, params: Params) -> ToolReturnValue:
        try:
            paths = [arg for arg in params.args if not arg.startswith("-")]
            if not paths:
                return ToolError(message="md5sum: missing operand", output="", brief="missing operand")

            cwd = params.cwd or os.getcwd()
            results = []
            errors = []
            for p in paths:
                target = Path(cwd) / p if not Path(p).is_absolute() else Path(p)
                try:
                    h = hashlib.md5()
                    with open(target, "rb") as f:
                        while chunk := f.read(8192):
                            h.update(chunk)
                    results.append(f"{h.hexdigest()}  {p}")
                except FileNotFoundError:
                    errors.append(f"md5sum: {p}: No such file or directory")
                except OSError as e:
                    errors.append(f"md5sum: {p}: {e}")

            if errors:
                output = "\n".join(errors)
                if params.output_path:
                    with open(params.output_path, "w", encoding="utf-8") as f:
                        f.write(output)
                    output = f"saved to file `{params.output_path}`"
                return ToolError(message=output, output=output, brief="md5sum failed")

            output = "\n".join(results)
            if params.output_path:
                with open(params.output_path, "w", encoding="utf-8") as f:
                    f.write(output)
                output = f"saved to file `{params.output_path}`"
            else:
                output = await _maybe_export_output_async(output)
            return ToolOk(output=output)
        except Exception as e:
            return ToolError(message=str(e), output="", brief="md5sum failed")
