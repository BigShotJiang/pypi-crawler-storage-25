"""Linter rule selection and configuration."""

from pydantic import BaseModel

from usethis._core.tool import use_deptry, use_ruff
from usethis._tool.impl.base.deptry import DeptryTool
from usethis._tool.impl.base.ruff import RuffTool


class RulesMapping(BaseModel):
    ruff_rules: list[str]
    deptry_rules: list[str]


def select_rules(rules: list[str]) -> None:
    """Select the given linter rules, enabling the appropriate tools as needed."""
    rules_mapping = get_rules_mapping(rules)

    if rules_mapping.deptry_rules and not DeptryTool().is_used():
        use_deptry()
    if rules_mapping.ruff_rules and not RuffTool().is_used():
        use_ruff()

    DeptryTool().select_rules(rules_mapping.deptry_rules)
    RuffTool().select_rules(rules_mapping.ruff_rules)


def deselect_rules(rules: list[str]) -> None:
    """Deselect the given linter rules from the relevant tools."""
    rules_mapping = get_rules_mapping(rules)

    DeptryTool().deselect_rules(rules_mapping.deptry_rules)
    RuffTool().deselect_rules(rules_mapping.ruff_rules)


def ignore_rules(rules: list[str]) -> None:
    """Add the given linter rules to the ignore list of the relevant tools."""
    rules_mapping = get_rules_mapping(rules)

    DeptryTool().ignore_rules(rules_mapping.deptry_rules)
    RuffTool().ignore_rules(rules_mapping.ruff_rules)


def unignore_rules(rules: list[str]) -> None:
    """Remove the given linter rules from the ignore list of the relevant tools."""
    rules_mapping = get_rules_mapping(rules)

    DeptryTool().unignore_rules(rules_mapping.deptry_rules)
    RuffTool().unignore_rules(rules_mapping.ruff_rules)


def get_rules_mapping(rules: list[str]) -> RulesMapping:
    """Partition a list of rule codes into deptry and Ruff rule groups."""
    deptry_rules = [rule for rule in rules if rule.startswith("DEP")]
    ruff_rules = [rule for rule in rules if rule not in deptry_rules]

    return RulesMapping(ruff_rules=ruff_rules, deptry_rules=deptry_rules)
