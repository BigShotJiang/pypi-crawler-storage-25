"""Tool specification implementations."""
