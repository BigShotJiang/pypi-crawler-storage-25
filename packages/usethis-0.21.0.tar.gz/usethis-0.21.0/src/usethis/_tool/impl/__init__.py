"""Concrete tool implementations."""
