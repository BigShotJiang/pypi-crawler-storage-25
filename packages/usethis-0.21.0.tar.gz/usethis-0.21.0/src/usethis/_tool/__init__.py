"""Tool management framework."""
