"""Python language utilities."""
