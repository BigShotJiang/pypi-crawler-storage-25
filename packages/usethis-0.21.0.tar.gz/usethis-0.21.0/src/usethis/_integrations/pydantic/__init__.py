"""Pydantic model utilities."""
