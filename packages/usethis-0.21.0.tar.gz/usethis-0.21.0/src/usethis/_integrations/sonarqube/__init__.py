"""SonarQube integration."""
