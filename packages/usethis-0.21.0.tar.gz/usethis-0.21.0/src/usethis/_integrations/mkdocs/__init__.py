"""MkDocs documentation integration."""
