"""Environment detection utilities."""
