"""pytest test framework integration."""
