"""GitHub CI integration."""
