import os
import shlex
import subprocess
import unittest
import unittest.mock
from pathlib import Path
from unittest.mock import MagicMock

import pytest
from pydantic import TypeAdapter

import usethis._backend.dispatch
from usethis._backend.uv.call import call_uv_subprocess
from usethis._backend.uv.link_mode import ensure_symlink_mode
from usethis._backend.uv.toml import UVTOMLManager
from usethis._config import usethis_config
from usethis._config_file import RuffTOMLManager, files_manager
from usethis._core.tool import (
    use_codespell,
    use_coverage_py,
    use_deptry,
    use_import_linter,
    use_mkdocs,
    use_pre_commit,
    use_pyproject_fmt,
    use_pyproject_toml,
    use_pytest,
    use_requirements_txt,
    use_ruff,
    use_tach,
    use_tool,
    use_ty,
)
from usethis._deps import add_deps_to_group, get_deps_from_group, is_dep_satisfied_in
from usethis._fallback import (
    FALLBACK_RUFF_VERSION,
    FALLBACK_SYNC_WITH_UV_VERSION,
    FALLBACK_UV_VERSION,
)
from usethis._file.pyproject_toml.io_ import PyprojectTOMLManager
from usethis._integrations.pre_commit.hooks import HOOK_GROUPS, get_hook_ids
from usethis._integrations.pre_commit.yaml import PreCommitConfigYAMLManager
from usethis._python.version import PythonVersion
from usethis._test import change_cwd
from usethis._tool.all_ import ALL_TOOLS, SupportedToolType
from usethis._tool.impl.base.ruff import RuffTool
from usethis._types.backend import BackendEnum
from usethis._types.deps import Dependency
from usethis.errors import NoDefaultToolCommand


class TestAllHooksList:
    def test_subset_hook_names(self, tmp_path: Path):
        all_hooks = [hook for group in HOOK_GROUPS for hook in group]
        with change_cwd(tmp_path):
            for tool in ALL_TOOLS:
                try:
                    hook_names = [
                        hook.id
                        for repo_config in tool.get_pre_commit_repos()
                        for hook in repo_config.hooks or []
                    ]
                except NotImplementedError:
                    continue
                for hook_name in hook_names:
                    assert hook_name in all_hooks


class TestCodespell:
    class TestAdd:
        @pytest.mark.usefixtures("_vary_network_conn")
        def test_config(self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]):
            # Arrange
            with change_cwd(uv_init_dir), PyprojectTOMLManager():
                add_deps_to_group([Dependency(name="codespell")], "dev")
                ensure_symlink_mode()

            capfd.readouterr()

            # Act
            with change_cwd(uv_init_dir), files_manager():
                use_codespell()

            # Assert
            assert (
                (uv_init_dir / "pyproject.toml")
                .read_text()
                .__contains__(
                    """\
[tool.codespell]
ignore-regex = ["[A-Za-z0-9+/]{100,}"]
"""
                )
            )
            out, err = capfd.readouterr()
            assert not err
            assert out == (
                "✔ Adding Codespell config to 'pyproject.toml'.\n"
                "☐ Run 'uv run codespell' to run the Codespell spellchecker.\n"
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_pre_commit_integration(
            self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            with change_cwd(uv_init_dir), files_manager():
                # Arrange
                use_pre_commit()
                capfd.readouterr()

                # Act
                use_codespell()

                # Assert
                # Check dependencies - should have installed codespell (issue #1020)
                dev_deps = get_deps_from_group("dev")
                assert any(dep.name == "codespell" for dep in dev_deps)

                # Check hook names
                hook_names = get_hook_ids()
                assert "codespell" in hook_names

            # Check output
            out, err = capfd.readouterr()
            assert not err
            # Note: Since deps are now added (issue #1020), the message is "uv run codespell"
            # not "pre-commit run -acodespell" because get_install_method() returns "devdep"
            assert out == (
                "✔ Adding dependency 'codespell' to the 'dev' group in 'pyproject.toml'.\n"
                "☐ Install the dependency 'codespell'.\n"
                "✔ Adding hook 'codespell' to '.pre-commit-config.yaml'.\n"
                "✔ Adding Codespell config to 'pyproject.toml'.\n"
                "☐ Run 'uv run codespell' to run the Codespell spellchecker.\n"
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_codespell_rc_file(self, uv_init_dir: Path):
            # This file is only preferred to pyproject.toml if there's already
            # some codespell config in the file

            # Arrange
            (uv_init_dir / ".codespellrc").write_text(
                """\
[codespell]
fake = bar
"""
            )

            # Act
            with change_cwd(uv_init_dir), files_manager():
                use_codespell()

            # Assert
            assert (uv_init_dir / ".codespellrc").read_text() == (
                """\
[codespell]
fake = bar
ignore-regex = [A-Za-z0-9+/]{100,}
ignore-words-list = ...
"""
            )

        def test_adding_twice(
            self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            # https://github.com/usethis-python/usethis-python/issues/509

            with change_cwd(uv_init_dir), files_manager():
                # Arrange
                use_codespell()
                capfd.readouterr()

                # Act
                use_codespell()

            # Assert
            out, err = capfd.readouterr()
            assert not err
            assert out == (
                "☐ Run 'uv run codespell' to run the Codespell spellchecker.\n"
            )

        def test_setup_cfg_nonempty(self, uv_init_dir: Path):
            # https://github.com/usethis-python/usethis-python/issues/542
            # Basically we want to make sure the "first_content" resolution strategy
            # works correctly.

            # Arrange
            content = """\
[codespell]
foo = bar
"""
            (uv_init_dir / "setup.cfg").write_text(content)

            with change_cwd(uv_init_dir), files_manager():
                # Arrange
                use_codespell()

            # Assert
            assert (uv_init_dir / "setup.cfg").read_text() != content
            assert (
                "[tool.codespell]" not in (uv_init_dir / "pyproject.toml").read_text()
            )

        def test_setup_cfg_empty(self, uv_init_dir: Path):
            # https://github.com/usethis-python/usethis-python/issues/542
            # Basically we want to make sure the "first_content" resolution strategy
            # works correctly.

            # Arrange
            (uv_init_dir / "setup.cfg").touch()

            with change_cwd(uv_init_dir), files_manager():
                # Arrange
                use_codespell()

            # Assert
            assert (uv_init_dir / "setup.cfg").read_text() == ""
            assert "[tool.codespell]" in (uv_init_dir / "pyproject.toml").read_text()

        def test_none_backend_pyproject_toml(
            self, tmp_path: Path, capfd: pytest.CaptureFixture[str]
        ):
            # Arrange
            (tmp_path / "pyproject.toml").touch()

            # Act
            with (
                change_cwd(tmp_path),
                usethis_config.set(backend=BackendEnum.none),
                files_manager(),
            ):
                use_codespell()

            # Assert
            out, err = capfd.readouterr()
            assert not err
            # Check if tomli is needed based on current interpreter
            current_version = PythonVersion.from_interpreter()
            needs_tomli = current_version.to_short_tuple() < (3, 11)
            if needs_tomli:
                expected_deps = "☐ Add the dev dependencies 'codespell', 'tomli'.\n"
            else:
                expected_deps = "☐ Add the dev dependency 'codespell'.\n"
            assert out == (
                expected_deps + "✔ Adding Codespell config to 'pyproject.toml'.\n"
                "☐ Run 'codespell' to run the Codespell spellchecker.\n"
            )

        def test_none_backend_no_pyproject_toml(
            self, tmp_path: Path, capfd: pytest.CaptureFixture[str]
        ):
            # Act
            with (
                change_cwd(tmp_path),
                usethis_config.set(backend=BackendEnum.none),
                files_manager(),
            ):
                use_codespell()

            # Assert
            out, err = capfd.readouterr()
            assert not err
            # Check if tomli is needed based on current interpreter
            current_version = PythonVersion.from_interpreter()
            needs_tomli = (int(current_version.major), int(current_version.minor)) < (
                3,
                11,
            )
            if needs_tomli:
                expected_deps = "☐ Add the dev dependencies 'codespell', 'tomli'.\n"
            else:
                expected_deps = "☐ Add the dev dependency 'codespell'.\n"
            assert out == (
                expected_deps + "✔ Writing '.codespellrc'.\n"
                "✔ Adding Codespell config to '.codespellrc'.\n"
                "☐ Run 'codespell' to run the Codespell spellchecker.\n"
            )

    class TestRemove:
        @pytest.mark.usefixtures("_vary_network_conn")
        def test_config_file(
            self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            # Arrange
            (uv_init_dir / "pyproject.toml").write_text(
                """\
[tool.codespell]
foo = "bar"
"""
            )

            # Act
            with change_cwd(uv_init_dir), files_manager():
                use_codespell(remove=True)

            # Assert
            assert (uv_init_dir / "pyproject.toml").read_text() == ""
            out, err = capfd.readouterr()
            assert not err
            assert out == ("✔ Removing Codespell config from 'pyproject.toml'.\n")

        def test_doesnt_add_pyproject(self, tmp_path: Path):
            # No pyproject.toml file to begin with...

            # Act
            with change_cwd(tmp_path), files_manager():
                use_codespell(remove=True)

            # Assert
            assert not (tmp_path / "pyproject.toml").exists()


class TestCoverage:
    class TestAdd:
        @pytest.mark.usefixtures("_vary_network_conn")
        def test_from_nothing(
            self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            with change_cwd(uv_init_dir), files_manager():
                # Act
                use_coverage_py()

                # Assert
                assert Dependency(
                    name="coverage", extras=frozenset({"toml"})
                ) in get_deps_from_group("test")

                assert ["tool", "uv", "default-groups"] in PyprojectTOMLManager()

            out, err = capfd.readouterr()
            assert not err
            assert out == (
                "✔ Adding dependency 'coverage' to the 'test' group in 'pyproject.toml'.\n"
                "☐ Install the dependency 'coverage'.\n"
                "✔ Adding Coverage.py config to 'pyproject.toml'.\n"
                "☐ Run 'uv run coverage help' to see available Coverage.py commands.\n"
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_no_pyproject_toml(
            self, tmp_path: Path, capfd: pytest.CaptureFixture[str]
        ):
            # Arrange
            # Set python version
            (tmp_path / ".python-version").write_text(
                str(PythonVersion.from_interpreter())
            )

            with (
                change_cwd(tmp_path),
                files_manager(),
                usethis_config.set(backend=BackendEnum.uv),
            ):
                # Act
                use_coverage_py()

                # Assert
                assert Dependency(
                    name="coverage", extras=frozenset({"toml"})
                ) in get_deps_from_group("test")
                out, err = capfd.readouterr()
                assert not err
                assert out == (
                    "✔ Writing 'pyproject.toml'.\n"
                    "✔ Adding dependency 'coverage' to the 'test' group in 'pyproject.toml'.\n"
                    "✔ Adding Coverage.py config to 'pyproject.toml'.\n"
                    "☐ Run 'uv run coverage help' to see available Coverage.py commands.\n"
                )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_pytest_integration(
            self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            with change_cwd(uv_init_dir), files_manager():
                # Arrange
                with usethis_config.set(quiet=True):
                    use_pytest()

                # Act
                use_coverage_py()

                # Assert
                assert Dependency(
                    name="coverage", extras=frozenset({"toml"})
                ) in get_deps_from_group("test")
                out, err = capfd.readouterr()
                assert not err
                assert out == (
                    "✔ Adding dependencies 'coverage', 'pytest-cov' to the 'test' group in 'pyproject.toml'.\n"
                    "☐ Install the dependencies 'coverage', 'pytest-cov'.\n"
                    "✔ Adding Coverage.py config to 'pyproject.toml'.\n"
                    "☐ Run 'uv run pytest --cov' to run your tests with Coverage.py.\n"
                )

        def test_coverage_rc_file(self, uv_init_dir: Path):
            # Arrange
            (uv_init_dir / ".coveragerc").write_text("")

            # Act
            with change_cwd(uv_init_dir), files_manager():
                use_coverage_py()

            # Assert
            assert (uv_init_dir / ".coveragerc").read_text() == (
                """\
[run]
source =
    src
relative_files = true

[report]
exclude_also =
    if TYPE_CHECKING:
    raise AssertionError
    raise NotImplementedError
    msg = ["']
    assert_never(.*)
    class .*\\bProtocol\\):
    @(abc\\.)?abstractmethod
omit =
    */pytest-of-*/*
"""
            )

        def test_tox_ini_file(self, uv_init_dir: Path):
            # Arrange
            (uv_init_dir / "tox.ini").touch()

            # Act
            with change_cwd(uv_init_dir), files_manager():
                use_coverage_py()

            # Assert
            assert (uv_init_dir / "tox.ini").read_text() == (
                """\
[coverage:run]
source =
    src
relative_files = true

[coverage:report]
exclude_also =
    if TYPE_CHECKING:
    raise AssertionError
    raise NotImplementedError
    msg = ["']
    assert_never(.*)
    class .*\\bProtocol\\):
    @(abc\\.)?abstractmethod
omit =
    */pytest-of-*/*
"""
            )

    @pytest.mark.usefixtures("_vary_network_conn")
    def test_after_codespell(self, tmp_path: Path):
        # To check the config is valid
        # https://github.com/usethis-python/usethis-python/issues/558

        # Arrange
        (tmp_path / "pyproject.toml").write_text("""\
[project]
name = "example"
version = "0.1.0"
description = "Add your description here"

[dependency-groups]
dev = [
    "codespell>=2.4.1",
]
                                                    
[tool.codespell]
ignore-regex = ["[A-Za-z0-9+/]{100,}"]
""")

        # Act
        with change_cwd(tmp_path), files_manager():
            use_coverage_py()

            # Assert
            assert ["tool", "coverage"] in PyprojectTOMLManager()
        content = (tmp_path / "pyproject.toml").read_text()
        assert "[tool.coverage]" in content

    class TestRemove:
        def test_unused(self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]):
            with change_cwd(uv_init_dir), PyprojectTOMLManager():
                # Act
                use_coverage_py(remove=True)

                # Assert
                assert not get_deps_from_group("test")
                out, err = capfd.readouterr()
                assert not out  # Should not be removing anything
                assert not err

        def test_roundtrip(self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]):
            with change_cwd(uv_init_dir), files_manager():
                # Arrange
                with usethis_config.set(quiet=True):
                    use_coverage_py()

                # Act
                use_coverage_py(remove=True)

                # Assert
                assert not get_deps_from_group("test")
            out, err = capfd.readouterr()
            assert not err
            assert out == (
                "✔ Removing Coverage.py config from 'pyproject.toml'.\n"
                "✔ Removing dependency 'coverage' from the 'test' group in 'pyproject.toml'.\n"
            )

        def test_pytest_integration(
            self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            with change_cwd(uv_init_dir), files_manager():
                # Arrange
                with usethis_config.set(quiet=True):
                    use_pytest()
                    use_coverage_py()

                # Act
                use_coverage_py(remove=True)

                # Assert
                assert get_deps_from_group("test") == [Dependency(name="pytest")]
                out, err = capfd.readouterr()
                assert not err
                assert out == (
                    "✔ Removing Coverage.py config from 'pyproject.toml'.\n"
                    "✔ Removing dependencies 'coverage', 'pytest-cov' from the 'test' group in 'pyproject.toml'.\n"
                )

        def test_doesnt_add_pyproject(
            self, tmp_path: Path, capfd: pytest.CaptureFixture[str]
        ):
            # No pyproject.toml file to begin with...

            # Act
            with change_cwd(tmp_path), files_manager():
                use_coverage_py(remove=True)

            # Assert
            assert not (tmp_path / "pyproject.toml").exists()
            out, _err = capfd.readouterr()
            assert not out


class TestDeptry:
    class TestAdd:
        @pytest.mark.usefixtures("_vary_network_conn")
        def test_dependency_added(self, uv_init_dir: Path):
            # Act
            with change_cwd(uv_init_dir), PyprojectTOMLManager():
                use_deptry()

                # Assert
                (dev_dep,) = get_deps_from_group("dev")
            assert dev_dep == Dependency(name="deptry")

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_ignore_notebooks(self, uv_init_dir: Path):
            # Act
            with change_cwd(uv_init_dir), PyprojectTOMLManager():
                use_deptry()

                # Assert
                assert (
                    PyprojectTOMLManager()[["tool", "deptry", "ignore_notebooks"]]
                    is False
                )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_stdout(
            self,
            uv_init_dir: Path,
            capfd: pytest.CaptureFixture[str],
        ):
            # Act
            with change_cwd(uv_init_dir), PyprojectTOMLManager():
                use_deptry()

            # Assert
            out, _ = capfd.readouterr()
            assert out == (
                "✔ Adding dependency 'deptry' to the 'dev' group in 'pyproject.toml'.\n"
                "☐ Install the dependency 'deptry'.\n"
                "✔ Adding deptry config to 'pyproject.toml'.\n"
                "☐ Run 'uv run deptry src' to run deptry.\n"
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_stdout_unfrozen(
            self,
            uv_init_dir: Path,
            capfd: pytest.CaptureFixture[str],
        ):
            # The idea here is we make sure that the 'uv run' prefix is added

            # Act
            with (
                change_cwd(uv_init_dir),
                PyprojectTOMLManager(),
                usethis_config.set(frozen=False),
            ):
                use_deptry()

            # Assert
            out, _ = capfd.readouterr()
            assert out == (
                "✔ Adding dependency 'deptry' to the 'dev' group in 'pyproject.toml'.\n"
                "✔ Adding deptry config to 'pyproject.toml'.\n"
                "☐ Run 'uv run deptry src' to run deptry.\n"
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_run_deptry_fail(self, uv_init_dir: Path, uv_path: Path):
            # Arrange
            f = uv_init_dir / "bad.py"
            f.write_text("import broken_dependency")

            # Act
            with change_cwd(uv_init_dir), PyprojectTOMLManager():
                use_deptry()

            # Assert
            with pytest.raises(subprocess.CalledProcessError):
                subprocess.run(
                    [uv_path.as_posix(), "run", "deptry", "."],
                    cwd=uv_init_dir,
                    check=True,
                )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_run_deptry_pass(self, uv_init_dir: Path):
            # Arrange
            f = uv_init_dir / "good.py"
            f.write_text("import sys")

            with (
                change_cwd(uv_init_dir),
                PyprojectTOMLManager(),
                usethis_config.set(frozen=False),
            ):
                # Act
                use_deptry()

                # Assert
                call_uv_subprocess(["run", "deptry", "."], change_toml=False)

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_pre_commit_after(
            self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            # Act
            with change_cwd(uv_init_dir), files_manager():
                use_deptry()
                use_pre_commit()

                # Assert
                hook_names = get_hook_ids()

            # 1. File exists
            assert (uv_init_dir / ".pre-commit-config.yaml").exists()

            # 2. Hook is in the file
            assert "deptry" in hook_names

            # 3. Test file contents
            assert (uv_init_dir / ".pre-commit-config.yaml").read_text() == (
                f"""\
repos:
  - repo: https://github.com/tsvikas/sync-with-uv
    rev: {FALLBACK_SYNC_WITH_UV_VERSION}
    hooks:
      - id: sync-with-uv
  - repo: local
    hooks:
      - id: deptry
        name: deptry
        always_run: true
        entry: uv run --frozen --offline deptry src
        language: system
        pass_filenames: false
"""
            )

            # 4. Check messages
            out, _ = capfd.readouterr()
            assert out == (
                "✔ Adding dependency 'deptry' to the 'dev' group in 'pyproject.toml'.\n"
                "☐ Install the dependency 'deptry'.\n"
                "✔ Adding deptry config to 'pyproject.toml'.\n"
                "☐ Run 'uv run deptry src' to run deptry.\n"
                "✔ Adding dependency 'pre-commit' to the 'dev' group in 'pyproject.toml'.\n"
                "☐ Install the dependency 'pre-commit'.\n"
                "✔ Writing '.pre-commit-config.yaml'.\n"
                "✔ Adding hook 'sync-with-uv' to '.pre-commit-config.yaml'.\n"
                "✔ Adding hook 'deptry' to '.pre-commit-config.yaml'.\n"
                "☐ Run 'uv run pre-commit install' to register pre-commit.\n"
                "☐ Run 'uv run pre-commit run -a' to run the hooks manually.\n"
            )

    class TestRemove:
        @pytest.mark.usefixtures("_vary_network_conn")
        def test_dep(self, uv_init_dir: Path):
            with change_cwd(uv_init_dir), PyprojectTOMLManager():
                # Arrange
                add_deps_to_group([Dependency(name="deptry")], "dev")

                # Act
                use_deptry(remove=True)

                # Assert
                assert not get_deps_from_group("dev")

        def test_use_deptry_removes_config(self, tmp_path: Path):
            """Test that use_deptry removes the tool's config when removing."""
            # Arrange
            pyproject = tmp_path / "pyproject.toml"
            pyproject.write_text("""[tool.deptry]
ignore_missing = ["pytest"]
""")

            # Act
            with change_cwd(tmp_path), PyprojectTOMLManager():
                use_deptry(remove=True)

            # Assert
            assert "[tool.deptry]" not in pyproject.read_text()

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_roundtrip(self, uv_init_dir: Path):
            # Arrange
            contents = (uv_init_dir / "pyproject.toml").read_text()

            # Act
            with change_cwd(uv_init_dir), PyprojectTOMLManager():
                use_deptry()
                use_deptry(remove=True)

            # Assert
            assert (
                (uv_init_dir / "pyproject.toml").read_text()
                == contents
                + """\
link-mode = "symlink"

[dependency-groups]
dev = []
"""
            )

        def test_doesnt_add_pyproject(
            self, tmp_path: Path, capfd: pytest.CaptureFixture[str]
        ):
            # No pyproject.toml file to begin with...

            # Act
            with change_cwd(tmp_path), files_manager():
                use_deptry(remove=True)

            # Assert
            assert not (tmp_path / "pyproject.toml").exists()
            out, err = capfd.readouterr()
            assert not out
            assert not err

    class TestPreCommitIntegration:
        @pytest.mark.usefixtures("_vary_network_conn")
        def test_pre_commit_first(
            self, uv_init_repo_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            """Basically this checks that the placeholders gets removed."""
            with change_cwd(uv_init_repo_dir), files_manager():
                # Arrange
                use_pre_commit()
                capfd.readouterr()

                # Act
                use_deptry()

                # Assert
                # Check dependencies - SHOULD have installed deptry (issue #1020)
                dev_deps = get_deps_from_group("dev")
                assert any(dep.name == "deptry" for dep in dev_deps)

                hook_names = get_hook_ids()

            # 1. File exists
            assert (uv_init_repo_dir / ".pre-commit-config.yaml").exists()

            # 2. Hook is in the file
            assert "deptry" in hook_names

            # 3. Test file contents
            assert (uv_init_repo_dir / ".pre-commit-config.yaml").read_text() == (
                f"""\
repos:
  - repo: https://github.com/tsvikas/sync-with-uv
    rev: {FALLBACK_SYNC_WITH_UV_VERSION}
    hooks:
      - id: sync-with-uv
  - repo: local
    hooks:
      - id: deptry
        name: deptry
        always_run: true
        entry: uv run --frozen --offline deptry src
        language: system
        pass_filenames: false
"""
            )

            # 4. Check messages
            out, _ = capfd.readouterr()
            assert out == (
                "✔ Adding dependency 'deptry' to the 'dev' group in 'pyproject.toml'.\n"
                "☐ Install the dependency 'deptry'.\n"
                "✔ Adding hook 'deptry' to '.pre-commit-config.yaml'.\n"
                "✔ Adding deptry config to 'pyproject.toml'.\n"
                "☐ Run 'uv run deptry src' to run deptry.\n"
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_placeholder_removed(
            self, uv_init_repo_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            # Arrange
            (uv_init_repo_dir / ".pre-commit-config.yaml").write_text(
                """\
repos:
  - repo: local
    hooks:
      - id: placeholder
"""
            )

            # Act
            with change_cwd(uv_init_repo_dir), files_manager():
                use_deptry()

            # Assert
            contents = (uv_init_repo_dir / ".pre-commit-config.yaml").read_text()
            assert "deptry" in contents
            assert "placeholder" not in contents
            out, err = capfd.readouterr()
            assert not err
            # Expecting not to get a specific message about removing the placeholder.
            assert out == (
                "✔ Adding dependency 'deptry' to the 'dev' group in 'pyproject.toml'.\n"
                "☐ Install the dependency 'deptry'.\n"
                "✔ Adding hook 'deptry' to '.pre-commit-config.yaml'.\n"
                "✔ Adding deptry config to 'pyproject.toml'.\n"
                "☐ Run 'uv run deptry src' to run deptry.\n"
            )

        def test_remove(self, uv_init_repo_dir: Path):
            with (
                change_cwd(uv_init_repo_dir),
                files_manager(),
                usethis_config.set(quiet=True),
            ):
                # Arrange
                use_deptry()
                use_pre_commit()

                # Check that deptry was added by reading from FileManager
                mgr = PreCommitConfigYAMLManager()
                model = mgr.model_validate()
                hook_ids = [
                    hook.id for repo in model.repos if repo.hooks for hook in repo.hooks
                ]
                assert "deptry" in hook_ids

                # Act
                use_deptry(remove=True)

            # Assert
            content = (uv_init_repo_dir / ".pre-commit-config.yaml").read_text()
            assert "deptry" not in content


class TestImportLinter:
    class TestAdd:
        def test_dependency(self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]):
            # Act
            with change_cwd(uv_init_dir), files_manager():
                use_import_linter()

                # Assert
                assert Dependency(name="import-linter") in get_deps_from_group("dev")

            out, err = capfd.readouterr()
            assert not err
            assert out == (
                "✔ Adding dependency 'import-linter' to the 'dev' group in 'pyproject.toml'.\n"
                "☐ Install the dependency 'import-linter'.\n"
                "✔ Adding Import Linter config to 'pyproject.toml'.\n"
                "ℹ Ensure '__init__.py' files are used in your packages.\n"  # noqa: RUF001
                "ℹ For more info see <https://docs.python.org/3/tutorial/modules.html#packages>\n"  # noqa: RUF001
                "☐ Run 'uv run lint-imports' to run Import Linter.\n"
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_ini_contracts(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
            # Arrange
            (tmp_path / ".importlinter").touch()
            (tmp_path / "qwerttyuiop").mkdir()
            (tmp_path / "qwerttyuiop" / "a.py").touch()
            (tmp_path / "qwerttyuiop" / "b.py").touch()
            (tmp_path / "qwerttyuiop" / "__init__.py").touch()
            (tmp_path / "qwerttyuiop" / "c").mkdir()
            (tmp_path / "qwerttyuiop" / "c" / "__init__.py").touch()

            monkeypatch.syspath_prepend(str(tmp_path))

            # Act
            with change_cwd(tmp_path), files_manager():
                use_import_linter()

            # Assert
            contents = (tmp_path / ".importlinter").read_text()
            assert contents == (
                """\
[importlinter]
root_packages =
    qwerttyuiop

[importlinter:contract:0]
name = qwerttyuiop
type = layers
layers =
    a | b | c
containers =
    qwerttyuiop
exhaustive = True
"""
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_toml_contracts(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
            # Arrange
            (tmp_path / "pyproject.toml").write_text(
                """\
[project]
name = "usethis"
version = "0.1.0"
"""
            )

            (tmp_path / "a").mkdir()
            (tmp_path / "a" / "__init__.py").touch()
            (tmp_path / "b").mkdir()
            (tmp_path / "b" / "__init__.py").touch()

            monkeypatch.syspath_prepend(str(tmp_path))

            # Act
            with change_cwd(tmp_path), files_manager():
                use_import_linter()

            # Assert
            contents = (tmp_path / "pyproject.toml").read_text()
            assert contents.__contains__("""\
[tool.importlinter]
root_packages = ["a", "b"]

[[tool.importlinter.contracts]]
name = "a"
type = "layers"
layers = []
containers = ["a"]
exhaustive = true

[[tool.importlinter.contracts]]
name = "b"
type = "layers"
layers = []
containers = ["b"]
exhaustive = true
""")

        def test_pre_commit_used_not_uv(
            self, tmp_path: Path, capfd: pytest.CaptureFixture[str]
        ):
            # Arrange
            (tmp_path / ".pre-commit-config.yaml").write_text(
                """\
repos:
  - repo: local
    hooks:
      - id: placeholder
"""
            )
            # Package to analyze
            (tmp_path / "a").mkdir()
            (tmp_path / "a" / "__init__.py").touch()

            # Act
            with (
                change_cwd(tmp_path),
                files_manager(),
                usethis_config.set(backend=BackendEnum.none),
            ):
                use_import_linter()

            # Assert
            contents = (tmp_path / ".pre-commit-config.yaml").read_text()
            assert "import-linter" in contents
            out, err = capfd.readouterr()
            assert not err
            assert out == (
                "☐ Add the dev dependency 'import-linter'.\n"
                "✔ Writing '.importlinter'.\n"
                "✔ Adding Import Linter config to '.importlinter'.\n"
                "✔ Adding hook 'import-linter' to '.pre-commit-config.yaml'.\n"
                "ℹ Ensure '__init__.py' files are used in your packages.\n"  # noqa: RUF001
                "ℹ For more info see <https://docs.python.org/3/tutorial/modules.html#packages>\n"  # noqa: RUF001
                "☐ Run 'pre-commit run -a import-linter' to run Import Linter.\n"
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_small_contracts_dropped(
            self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
        ):
            # Arrange
            (tmp_path / ".importlinter").touch()
            (tmp_path / "qwerttyuiop").mkdir()
            (tmp_path / "qwerttyuiop" / "a.py").touch()
            (tmp_path / "qwerttyuiop" / "b.py").touch()
            (tmp_path / "qwerttyuiop" / "__init__.py").touch()
            (tmp_path / "qwerttyuiop" / "c").mkdir()
            (tmp_path / "qwerttyuiop" / "c" / "__init__.py").touch()
            (tmp_path / "qwerttyuiop" / "c" / "d").mkdir()
            (tmp_path / "qwerttyuiop" / "c" / "d" / "__init__.py").touch()

            monkeypatch.syspath_prepend(str(tmp_path))

            # Act
            with change_cwd(tmp_path), files_manager():
                use_import_linter()

            # Assert
            contents = (tmp_path / ".importlinter").read_text()
            assert contents == (
                """\
[importlinter]
root_packages =
    qwerttyuiop

[importlinter:contract:0]
name = qwerttyuiop
type = layers
layers =
    a | b | c
containers =
    qwerttyuiop
exhaustive = True
"""
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_cyclic_excluded(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
            # Arrange
            (tmp_path / ".importlinter").touch()
            (tmp_path / "a").mkdir()
            (tmp_path / "a" / "__init__.py").touch()
            (tmp_path / "a" / "b.py").write_text("import a.c")
            (tmp_path / "a" / "c.py").write_text("import a.b")

            monkeypatch.syspath_prepend(str(tmp_path))

            # Act
            with change_cwd(tmp_path), files_manager():
                use_import_linter()

            # Assert
            contents = (tmp_path / ".importlinter").read_text()
            assert contents == (
                """\
[importlinter]
root_packages =
    a

[importlinter:contract:0]
name = a
type = layers
layers = 
containers =
    a
exhaustive = True
exhaustive_ignores =
    b
    c
"""
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_version_excluded(
            self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
        ):
            """_version.py is auto-excluded into exhaustive_ignores.

            Ref: https://github.com/usethis-python/usethis-python/issues/1423
            """
            # Arrange
            (tmp_path / ".importlinter").touch()
            (tmp_path / "a").mkdir()
            (tmp_path / "a" / "__init__.py").touch()
            (tmp_path / "a" / "b.py").touch()
            (tmp_path / "a" / "c.py").touch()
            (tmp_path / "a" / "_version.py").touch()

            monkeypatch.syspath_prepend(str(tmp_path))

            # Act
            with change_cwd(tmp_path), files_manager():
                use_import_linter()

            # Assert
            contents = (tmp_path / ".importlinter").read_text()
            assert contents == (
                """\
[importlinter]
root_packages =
    a

[importlinter:contract:0]
name = a
type = layers
layers =
    b | c
containers =
    a
exhaustive = True
exhaustive_ignores =
    _version
"""
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_existing_ini_match(self, tmp_path: Path):
            # Arrange
            (tmp_path / ".importlinter").write_text(
                """\
[importlinter:contract:0]
name = a
"""
            )
            (tmp_path / "a").mkdir()
            (tmp_path / "a" / "__init__.py").touch()

            # Act
            with change_cwd(tmp_path), files_manager():
                use_import_linter()

            # Assert
            contents = (tmp_path / ".importlinter").read_text()
            assert contents == (
                """\
[importlinter:contract:0]
name = a

[importlinter]
root_packages =
    a
"""
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_existing_ini_differs(self, tmp_path: Path):
            # Arrange
            (tmp_path / ".importlinter").write_text(
                """\
[importlinter:contract:existing]
name = a
"""
            )
            (tmp_path / "a").mkdir()
            (tmp_path / "a" / "__init__.py").touch()

            # Act
            with change_cwd(tmp_path), files_manager():
                use_import_linter()

            # Assert
            contents = (tmp_path / ".importlinter").read_text()
            assert contents == (
                """\
[importlinter:contract:existing]
name = a

[importlinter]
root_packages =
    a
"""
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_numbers_in_layer_names(self, tmp_path: Path):
            # Arrange
            (tmp_path / ".importlinter").touch()
            (tmp_path / "hillslope").mkdir()
            (tmp_path / "hillslope" / "__init__.py").touch()
            (tmp_path / "hillslope" / "s1_sample.py").touch()
            (tmp_path / "hillslope" / "s2_inspect.py").touch()

            # Act
            with change_cwd(tmp_path), files_manager():
                use_import_linter()

            # Assert
            contents = (tmp_path / ".importlinter").read_text()
            assert contents == (
                """\
[importlinter]
root_packages =
    hillslope

[importlinter:contract:0]
name = hillslope
type = layers
layers =
    s1_sample | s2_inspect
containers =
    hillslope
exhaustive = True
"""
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_nesting(self, tmp_path: Path):
            # Arrange
            (tmp_path / ".importlinter").touch()
            (tmp_path / "hillslope").mkdir()
            (tmp_path / "hillslope" / "__init__.py").touch()
            (tmp_path / "hillslope" / "s1_sample").mkdir()
            (tmp_path / "hillslope" / "s1_sample" / "__init__.py").touch()
            (tmp_path / "hillslope" / "s1_sample" / "s2_inspect.py").touch()
            (tmp_path / "hillslope" / "s1_sample" / "s3_inspect.py").touch()
            (tmp_path / "hillslope" / "s1_sample" / "s4_inspect.py").touch()

            # Act
            with change_cwd(tmp_path), files_manager():
                use_import_linter()

            # Assert
            contents = (tmp_path / ".importlinter").read_text()
            assert contents == (
                """\
[importlinter]
root_packages =
    hillslope

[importlinter:contract:0]
name = hillslope
type = layers
layers =
    s1_sample
containers =
    hillslope
exhaustive = True

[importlinter:contract:1]
name = hillslope.s1_sample
type = layers
layers =
    s2_inspect | s3_inspect | s4_inspect
containers =
    hillslope.s1_sample
exhaustive = True
"""
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_multiple_packages_with_nesting(self, tmp_path: Path):
            # The logic here is that we want to have the minimum number of nesting
            # levels required to reach the minimum number of modules which is 3.

            # Arrange
            (tmp_path / ".importlinter").touch()
            (tmp_path / "hillslope").mkdir()
            (tmp_path / "hillslope" / "__init__.py").touch()
            (tmp_path / "hillslope" / "s1_sample").mkdir()
            (tmp_path / "hillslope" / "s1_sample" / "__init__.py").touch()
            (tmp_path / "hillslope" / "s1_sample" / "s2_inspect.py").touch()
            (tmp_path / "hillslope" / "s1_sample" / "s3_inspect.py").touch()
            (tmp_path / "hillslope" / "s1_sample" / "s4_inspect.py").touch()
            (tmp_path / "hillslope2").mkdir()
            (tmp_path / "hillslope2" / "__init__.py").touch()
            (tmp_path / "hillslope3").mkdir()
            (tmp_path / "hillslope3" / "__init__.py").touch()
            (tmp_path / "hillslope4").mkdir()
            (tmp_path / "hillslope4" / "__init__.py").touch()

            # Act
            with change_cwd(tmp_path), files_manager():
                use_import_linter()

            # Assert
            contents = (tmp_path / ".importlinter").read_text()
            assert contents == (
                """\
[importlinter]
root_packages =
    hillslope
    hillslope2
    hillslope3
    hillslope4

[importlinter:contract:0]
name = hillslope
type = layers
layers =
    s1_sample
containers =
    hillslope
exhaustive = True

[importlinter:contract:1]
name = hillslope.s1_sample
type = layers
layers =
    s2_inspect | s3_inspect | s4_inspect
containers =
    hillslope.s1_sample
exhaustive = True

[importlinter:contract:2]
name = hillslope2
type = layers
layers = 
containers =
    hillslope2
exhaustive = True

[importlinter:contract:3]
name = hillslope3
type = layers
layers = 
containers =
    hillslope3
exhaustive = True

[importlinter:contract:4]
name = hillslope4
type = layers
layers = 
containers =
    hillslope4
exhaustive = True
"""
            )

        def test_stdout_when_cant_find_package(
            self, tmp_path: Path, capfd: pytest.CaptureFixture[str]
        ):
            # Having an issue where the message is being repeated multiple times
            # https://github.com/usethis-python/usethis-python/pull/501#issuecomment-2784482750

            # Act
            with (
                change_cwd(tmp_path),
                files_manager(),
                usethis_config.set(frozen=True, backend=BackendEnum.uv),
            ):
                use_import_linter()

            # Assert
            out, err = capfd.readouterr()
            assert not err
            assert out == (
                "✔ Writing 'pyproject.toml'.\n"
                "✔ Adding dependency 'import-linter' to the 'dev' group in 'pyproject.toml'.\n"
                "☐ Install the dependency 'import-linter'.\n"
                "⚠ Could not find any importable packages.\n"
                "⚠ Assuming the package name is test-stdout-when-cant-find-pac0.\n"
                "✔ Adding Import Linter config to 'pyproject.toml'.\n"
                "ℹ Ensure '__init__.py' files are used in your packages.\n"  # noqa: RUF001
                "ℹ For more info see <https://docs.python.org/3/tutorial/modules.html#packages>\n"  # noqa: RUF001
                "☐ Run 'uv run lint-imports' to run Import Linter.\n"
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_root_packages_not_added_if_already_root_package_ini(
            self, tmp_path: Path
        ):
            # Basically the user can either specify a list of root_packages, or
            # a single root package. We prefer to always use `root_packages`, but
            # we will leave the existing configuration alone if it already exists.

            # Arrange
            (tmp_path / ".importlinter").write_text(
                """\
[importlinter]
root_package = a
"""
            )

            # Act
            with change_cwd(tmp_path), files_manager():
                use_import_linter()

            # Assert
            contents = (tmp_path / ".importlinter").read_text()
            assert contents.startswith(
                """\
[importlinter]
root_package = a

[importlinter:contract:0]
"""
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_root_packages_not_added_if_already_root_package_toml(
            self, tmp_path: Path
        ):
            # Arrange
            (tmp_path / "pyproject.toml").write_text(
                """\
[tool.importlinter]
root_package = "a"
"""
            )

            # Act
            with change_cwd(tmp_path), files_manager():
                use_import_linter()

            # Assert
            content = (tmp_path / "pyproject.toml").read_text()
            assert "root_packages = " not in content
            assert "root_package = " in content

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_inp_rules_selected(self, tmp_path: Path):
            # Arrange
            (tmp_path / "ruff.toml").touch()

            with change_cwd(tmp_path), files_manager():
                # Act
                use_import_linter()

                # Assert
                assert "INP" in RuffTool().selected_rules()

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_no_duplicate_inp_rules(self, tmp_path: Path):
            # https://github.com/usethis-python/usethis-python/issues/935

            # Arrange
            (tmp_path / "ruff.toml").touch()
            (tmp_path / "tests").mkdir()

            with change_cwd(tmp_path), files_manager():
                # ... preparing for duplicate call
                use_import_linter()

                # Act - duplicate
                use_import_linter()

                # Assert
                assert (
                    len(
                        [
                            rule
                            for rule in TypeAdapter(list[str]).validate_python(
                                RuffTOMLManager()[
                                    ["lint", "per-file-ignores", "tests/**"]
                                ]
                            )
                            if rule == "INP"
                        ]
                    )
                    == 1
                )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_inp_rules_not_selected_for_tests_dir(
            self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            # Arrange
            (uv_init_dir / "ruff.toml").touch()
            (uv_init_dir / "tests").mkdir()

            with change_cwd(uv_init_dir), files_manager():
                # Act
                use_import_linter()

            # Assert
            contents = (uv_init_dir / "ruff.toml").read_text()
            assert (
                contents
                == """\
[lint]
select = ["INP"]

[lint.per-file-ignores]
"tests/**" = ["INP"]
"""
            )
            out, err = capfd.readouterr()
            assert not err
            assert out == (
                "✔ Adding dependency 'import-linter' to the 'dev' group in 'pyproject.toml'.\n"
                "☐ Install the dependency 'import-linter'.\n"
                "✔ Adding Import Linter config to 'pyproject.toml'.\n"
                "✔ Selecting Ruff rule 'INP' in 'ruff.toml'.\n"
                "☐ Run 'uv run lint-imports' to run Import Linter.\n"
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_message_for_already_selected_but_needs_ignoring(
            self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            # Arrange
            (uv_init_dir / "ruff.toml").write_text("""\
[lint]
select = ["INP"]
""")
            (uv_init_dir / "tests").mkdir()

            with change_cwd(uv_init_dir), files_manager():
                # Act
                use_import_linter()

            # Assert
            contents = (uv_init_dir / "ruff.toml").read_text()
            assert (
                contents
                == """\
[lint]
select = ["INP"]

[lint.per-file-ignores]
"tests/**" = ["INP"]
"""
            )
            out, err = capfd.readouterr()
            assert not err
            assert out == (
                "✔ Adding dependency 'import-linter' to the 'dev' group in 'pyproject.toml'.\n"
                "☐ Install the dependency 'import-linter'.\n"
                "✔ Adding Import Linter config to 'pyproject.toml'.\n"
                "✔ Ignoring Ruff rule 'INP' for 'tests/**' in 'ruff.toml'.\n"
                "☐ Run 'uv run lint-imports' to run Import Linter.\n"
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_inp_rules_dont_break_config(self, uv_init_dir: Path):
            # Arrange
            (uv_init_dir / "pyproject.toml").write_text("""\
[project]
name = "test"
version = "0.1.0"

[tool.ruff]
line-length = 88
format.docstring-code-format = true
lint.select = [ "A", "C4", "E4", "E7", "E9", "F", "FLY", "FURB", "I", "INP", "PLE", "PLR", "PT", "RUF", "SIM", "UP" ]
lint.ignore = [ "PLR2004", "SIM108" ]
""")
            (uv_init_dir / "tests").mkdir()

            with change_cwd(uv_init_dir), files_manager():
                # Act
                use_import_linter()

            # Assert
            contents = (uv_init_dir / "pyproject.toml").read_text()
            assert contents.startswith("""\
[project]
name = "test"
version = "0.1.0"

[tool.ruff]
line-length = 88
format.docstring-code-format = true
lint.select = [ "A", "C4", "E4", "E7", "E9", "F", "FLY", "FURB", "I", "INP", "PLE", "PLR", "PT", "RUF", "SIM", "UP" ]
lint.per-file-ignores."tests/**" = ["INP"]
lint.ignore = [ "PLR2004", "SIM108" ]
""")

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_ruff_passes(self, tmp_path: Path):
            with change_cwd(tmp_path), files_manager():
                # Arrange
                use_ruff()
                use_pytest()

                # Act
                use_import_linter()

            # Assert
            with change_cwd(tmp_path), files_manager():
                call_uv_subprocess(["run", "ruff", "check", "."], change_toml=False)

    class TestRemove:
        def test_config_file(self, uv_init_repo_dir: Path):
            # Arrange
            (uv_init_repo_dir / ".importlinter").touch()

            # Act
            with change_cwd(uv_init_repo_dir), files_manager():
                use_import_linter(remove=True)

            # Assert
            assert not (uv_init_repo_dir / ".importlinter").exists()

        def test_doesnt_add_pyproject(self, tmp_path: Path):
            # No pyproject.toml file to begin with...

            # Act
            with change_cwd(tmp_path), files_manager():
                use_import_linter(remove=True)

            # Assert
            assert not (tmp_path / "pyproject.toml").exists()

        def test_doesnt_deselect_inp_rules(self, tmp_path: Path):
            # Arrange
            (tmp_path / "ruff.toml").touch()

            with change_cwd(tmp_path), files_manager():
                RuffTool().select_rules(["INP"])

                # Act
                use_import_linter(remove=True)

            # Assert
            contents = (tmp_path / "ruff.toml").read_text()
            assert "INP" in contents

    class TestPreCommitIntegration:
        def test_config(
            self, uv_init_repo_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            # Arrange
            (uv_init_repo_dir / ".pre-commit-config.yaml").write_text(
                """\
repos:
  - repo: local
    hooks:
      - id: placeholder
"""
            )

            # Act
            with change_cwd(uv_init_repo_dir), files_manager():
                use_import_linter()

                # Assert
                # Check dependencies - should have installed import-linter (issue #1020)
                dev_deps = get_deps_from_group("dev")
                assert any(dep.name == "import-linter" for dep in dev_deps)

            contents = (uv_init_repo_dir / ".pre-commit-config.yaml").read_text()
            assert "import-linter" in contents
            assert "placeholder" not in contents

            out, err = capfd.readouterr()
            assert not err
            assert out == (
                "✔ Adding dependency 'import-linter' to the 'dev' group in 'pyproject.toml'.\n"
                "☐ Install the dependency 'import-linter'.\n"
                "✔ Adding Import Linter config to 'pyproject.toml'.\n"
                "✔ Adding hook 'import-linter' to '.pre-commit-config.yaml'.\n"
                "ℹ Ensure '__init__.py' files are used in your packages.\n"  # noqa: RUF001
                "ℹ For more info see <https://docs.python.org/3/tutorial/modules.html#packages>\n"  # noqa: RUF001
                "☐ Run 'uv run lint-imports' to run Import Linter.\n"
            )


class TestMkDocs:
    class TestAdd:
        @pytest.mark.usefixtures("_vary_network_conn")
        def test_config_contents(self, tmp_path: Path):
            # Arrange
            (tmp_path / "pyproject.toml").write_text("""\
[project]
name = "my-project"
""")

            # Act
            with change_cwd(tmp_path), files_manager():
                use_mkdocs()

            # Assert
            assert (tmp_path / "mkdocs.yml").exists()
            contents = (tmp_path / "mkdocs.yml").read_text()
            assert contents == (
                """\
site_name: my-project
nav:
  - Home: index.md
"""
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_successful_build(self, tmp_path: Path):
            # Act
            with change_cwd(tmp_path), files_manager():
                use_mkdocs()
                # ... close/save file via context manager

            # Assert
            with change_cwd(tmp_path), files_manager():
                call_uv_subprocess(
                    ["run", "mkdocs", "build", "--strict"], change_toml=False
                )

    class TestRemove:
        def test_config(self, tmp_path: Path):
            # Arrange
            (tmp_path / "mkdocs.yml").touch()

            # Act
            with change_cwd(tmp_path), files_manager():
                use_mkdocs(remove=True)

            # Assert
            assert not (tmp_path / "mkdocs.yml").exists()

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_doc_deps_removed(self, uv_init_repo_dir: Path):
            with change_cwd(uv_init_repo_dir), files_manager():
                # Arrange
                add_deps_to_group(
                    [
                        Dependency(name="mkdocs"),
                        Dependency(name="sphinx"),
                        Dependency(name="mkdocs-material"),
                    ],
                    "doc",
                )

                # Act
                use_mkdocs(remove=True)

                # Assert
                assert get_deps_from_group("doc") == [Dependency(name="sphinx")]

    class TestHow:
        @pytest.mark.usefixtures("_vary_network_conn")
        def test_how_to_use(
            self, uv_init_repo_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            # Arrange
            (uv_init_repo_dir / "mkdocs.yml").touch()

            # Act
            with change_cwd(uv_init_repo_dir), files_manager():
                use_mkdocs(how=True)

            # Assert
            out, _ = capfd.readouterr()
            assert out == (
                """\
☐ Run 'uv run mkdocs build' to build the documentation.
☐ Run 'uv run mkdocs serve' to serve the documentation locally.
"""
            )


class TestPreCommit:
    class TestAdd:
        @pytest.mark.usefixtures("_vary_network_conn")
        def test_fresh(self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]):
            # Act
            with change_cwd(uv_init_dir), files_manager():
                use_pre_commit()

                # Assert
                # Has dev dep
                (dev_dep,) = get_deps_from_group("dev")
                assert dev_dep == Dependency(name="pre-commit")
            # Correct stdout
            out, _ = capfd.readouterr()
            assert out == (
                "✔ Adding dependency 'pre-commit' to the 'dev' group in 'pyproject.toml'.\n"
                "☐ Install the dependency 'pre-commit'.\n"
                "✔ Writing '.pre-commit-config.yaml'.\n"
                "✔ Adding hook 'sync-with-uv' to '.pre-commit-config.yaml'.\n"
                "☐ Run 'uv run pre-commit install' to register pre-commit.\n"
                "☐ Run 'uv run pre-commit run -a' to run the hooks manually.\n"
            )
            # Config file
            assert (uv_init_dir / ".pre-commit-config.yaml").exists()
            contents = (uv_init_dir / ".pre-commit-config.yaml").read_text()
            assert contents == (
                f"""\
repos:
  - repo: https://github.com/tsvikas/sync-with-uv
    rev: {FALLBACK_SYNC_WITH_UV_VERSION}
    hooks:
      - id: sync-with-uv
"""
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_fresh_no_backend(
            self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            # Act
            with (
                change_cwd(uv_init_dir),
                files_manager(),
                usethis_config.set(backend=BackendEnum.none),
            ):
                use_pre_commit()

            # Assert
            # Correct stdout
            out, _ = capfd.readouterr()
            assert out == (
                "☐ Add the dev dependency 'pre-commit'.\n"
                "☐ Install the dependency 'pre-commit'.\n"
                "✔ Writing '.pre-commit-config.yaml'.\n"
                "✔ Adding placeholder hook to '.pre-commit-config.yaml'.\n"
                "☐ Remove the placeholder hook in '.pre-commit-config.yaml'.\n"
                "☐ Replace it with your own hooks.\n"
                "☐ Alternatively, use 'usethis tool' to add other tools and their hooks.\n"
                "☐ Run 'pre-commit install' to register pre-commit.\n"
                "☐ Run 'pre-commit run -a' to run the hooks manually.\n"
            )
            # Config file
            assert (uv_init_dir / ".pre-commit-config.yaml").exists()
            contents = (uv_init_dir / ".pre-commit-config.yaml").read_text()
            assert contents == (
                """\
repos:
  - repo: local
    hooks:
      - id: placeholder
        name: Placeholder - add your own hooks!
        entry: uv run --isolated --frozen --offline python -c "print('hello world!')"
        language: system
"""
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_config_file_already_exists(self, uv_init_repo_dir: Path):
            # Arrange
            (uv_init_repo_dir / ".pre-commit-config.yaml").write_text(
                """\
repos:
  - repo: local
    hooks:
      - id: my hook
        name: Its mine
        entry: uv run --isolated --frozen --offline python -c "print('hello world!')"
        language: system
"""
            )

            # Act
            with change_cwd(uv_init_repo_dir), files_manager():
                use_pre_commit()

            # Assert
            contents = (uv_init_repo_dir / ".pre-commit-config.yaml").read_text()
            assert contents == (
                f"""\
repos:
  - repo: local
    hooks:
      - id: my hook
        name: Its mine
        entry: uv run --isolated --frozen --offline python -c "print('hello world!')"
        language: system
  - repo: https://github.com/tsvikas/sync-with-uv
    rev: {FALLBACK_SYNC_WITH_UV_VERSION}
    hooks:
      - id: sync-with-uv
"""
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_bad_commit(self, uv_env_dir: Path, git_path: Path):
            # This needs a venv so that we can actually run pre-commit via git

            if os.environ.get("CI") and not usethis_config.offline:
                pytest.skip("Skipping online test on CI to avoid flakiness")

            # Arrange
            (uv_env_dir / ".gitignore").write_text(".venv/\n")

            # Act
            with change_cwd(uv_env_dir), files_manager():
                use_pre_commit()
            subprocess.run(
                [git_path.as_posix(), "add", "."], cwd=uv_env_dir, check=True
            )
            result = subprocess.run(
                [git_path.as_posix(), "commit", "-m", "Good commit"], cwd=uv_env_dir
            )
            assert not result.stderr
            assert result.returncode == 0, (
                f"stdout: {result.stdout}\nstderr: {result.stderr}\n"
            )

            # Assert
            (uv_env_dir / ".pre-commit-config.yaml").write_text("[")
            subprocess.run(
                [git_path.as_posix(), "add", "."], cwd=uv_env_dir, check=True
            )
            result = subprocess.run(
                [git_path.as_posix(), "commit", "-m", "Bad commit"],
                cwd=uv_env_dir,
                capture_output=True,
            )
            assert not result.stdout
            assert result.returncode != 0, (
                f"stdout: {result.stdout}\nstderr: {result.stderr}\n"
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_requirements_txt_used(self, uv_init_dir: Path):
            with change_cwd(uv_init_dir), files_manager():
                # Arrange
                with usethis_config.set(frozen=False):
                    use_requirements_txt()

                # Act
                use_pre_commit()

                # Assert
                assert "uv-export" in get_hook_ids()

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_pyproject_fmt_used(self, uv_init_repo_dir: Path):
            with change_cwd(uv_init_repo_dir), files_manager():
                # Arrange
                use_pyproject_fmt()

                # Act
                use_pre_commit()

                # Assert
                hook_names = get_hook_ids()
                assert "pyproject-fmt" in hook_names

                # Issue #1020: Deps should remain even when using pre-commit
                dev_deps = get_deps_from_group("dev")
                assert any(dep.name == "pyproject-fmt" for dep in dev_deps)

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_codespell_used(self, uv_init_repo_dir: Path):
            with change_cwd(uv_init_repo_dir), files_manager():
                # Arrange
                use_codespell()

                # Act
                use_pre_commit()

                # Assert
                hook_names = get_hook_ids()
                assert "codespell" in hook_names

                # Issue #1020: Deps should remain even when using pre-commit
                dev_deps = get_deps_from_group("dev")
                assert any(dep.name == "codespell" for dep in dev_deps)

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_ruff_used(self, uv_init_repo_dir: Path):
            with change_cwd(uv_init_repo_dir), files_manager():
                # Arrange
                use_ruff()

                # Act
                use_pre_commit()

                # Assert
                hook_names = get_hook_ids()
                assert "ruff-check" in hook_names
                assert "ruff-format" in hook_names

                # Issue #1126: Deps should remain even when using pre-commit
                dev_deps = get_deps_from_group("dev")
                assert any(dep.name == "ruff" for dep in dev_deps)

    class TestRemove:
        @pytest.mark.usefixtures("_vary_network_conn")
        def test_config_file(self, uv_init_repo_dir: Path):
            # Arrange
            (uv_init_repo_dir / ".pre-commit-config.yaml").touch()

            # Act
            with change_cwd(uv_init_repo_dir), files_manager():
                use_pre_commit(remove=True)

            # Assert
            assert not (uv_init_repo_dir / ".pre-commit-config.yaml").exists()

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_dep(self, uv_init_repo_dir: Path):
            with change_cwd(uv_init_repo_dir), files_manager():
                # Arrange
                add_deps_to_group([Dependency(name="pre-commit")], "dev")

                # Act
                use_pre_commit(remove=True)

                # Assert
                assert not get_deps_from_group("dev")

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_stdout(self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]):
            # Arrange
            (uv_init_dir / ".pre-commit-config.yaml").write_text(
                """\
repos:
  - repo: local
    hooks:
      - id: pre-commit
"""
            )

            with change_cwd(uv_init_dir), files_manager():
                # Arrange contd....
                # Add dependency
                add_deps_to_group([Dependency(name="pre-commit")], "dev")
                capfd.readouterr()

                # Act
                use_pre_commit(remove=True)

            # Assert
            out, err = capfd.readouterr()
            assert not err
            assert out == (
                "☐ Run 'uv run --with pre-commit pre-commit uninstall' to deregister pre-commit.\n"
                "✔ Removing '.pre-commit-config.yaml'.\n"
                "✔ Removing dependency 'pre-commit' from the 'dev' group in 'pyproject.toml'.\n"
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_requirements_txt_used(
            self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            with change_cwd(uv_init_dir), files_manager():
                # Arrange
                use_pre_commit()
                with usethis_config.set(frozen=False):
                    use_requirements_txt()
                capfd.readouterr()

                # Act
                use_pre_commit(remove=True)

                # Assert
                out, _ = capfd.readouterr()
                assert out == (
                    "☐ Run 'uv run --with pre-commit pre-commit uninstall' to deregister pre-commit.\n"
                    "✔ Removing '.pre-commit-config.yaml'.\n"
                    "✔ Removing dependency 'pre-commit' from the 'dev' group in 'pyproject.toml'.\n"
                    "☐ Run 'uv export -o=requirements.txt' to write 'requirements.txt'.\n"
                )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_pyproject_fmt_used(
            self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            with change_cwd(uv_init_dir), files_manager():
                # Arrange
                with usethis_config.set(quiet=True):
                    use_pre_commit()
                    use_pyproject_fmt()

                # Act
                use_pre_commit(remove=True)

                # Assert
                out, _ = capfd.readouterr()
                # Note: Since deps are now added when tool is used with pre-commit (issue #1020),
                # the dependency is already present and doesn't need to be re-added when
                # removing pre-commit.
                assert out == (
                    "☐ Run 'uv run --with pre-commit pre-commit uninstall' to deregister pre-commit.\n"
                    "✔ Removing '.pre-commit-config.yaml'.\n"
                    "✔ Removing dependency 'pre-commit' from the 'dev' group in 'pyproject.toml'.\n"
                    "☐ Run 'uv run pyproject-fmt pyproject.toml' to run pyproject-fmt.\n"
                )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_codespell_used(
            self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            with change_cwd(uv_init_dir), files_manager():
                # Arrange
                with usethis_config.set(quiet=True):
                    use_pre_commit()
                    use_codespell()
                    capfd.readouterr()

                # Act
                use_pre_commit(remove=True)

                # Assert
                out, err = capfd.readouterr()
                assert not err
                # Note: Since deps are now added when tool is used with pre-commit (issue #1020),
                # the dependency is already present and doesn't need to be re-added when
                # removing pre-commit.
                assert out == (
                    "☐ Run 'uv run --with pre-commit pre-commit uninstall' to deregister pre-commit.\n"
                    "✔ Removing '.pre-commit-config.yaml'.\n"
                    "✔ Removing dependency 'pre-commit' from the 'dev' group in 'pyproject.toml'.\n"
                    "☐ Run 'uv run codespell' to run the Codespell spellchecker.\n"
                )

        def test_doesnt_add_pyproject(self, uv_init_repo_dir: Path):
            # Arrange
            # We use uv_init_repo_dir to get a git repo
            (uv_init_repo_dir / "pyproject.toml").unlink()

            # Act
            with change_cwd(uv_init_repo_dir), files_manager():
                use_pre_commit(remove=True)

            # Assert
            assert not (uv_init_repo_dir / "pyproject.toml").exists()

    class TestMultipleIntegrations:
        @pytest.mark.usefixtures("_vary_network_conn")
        def test_hooks_run_all_tools_empty_repo(self, uv_env_dir: Path):
            # Arrange
            with change_cwd(uv_env_dir), files_manager():
                # Add the tools
                use_pre_commit()
                for tool in ALL_TOOLS:
                    if tool.get_pre_commit_repos():
                        use_tool(tool)

                # Act, Assert
                # Run the pre-commit hooks via subprocess - check it doesn't raise
                call_uv_subprocess(
                    ["run", "pre-commit", "run", "-a"],
                    change_toml=False,
                )

    class TestMigration:
        """Test migration of tools to/from pre-commit (issue #1020)."""

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_deps_not_removed_when_migrating_to_pre_commit(self, uv_init_dir: Path):
            """Test that deps are NOT removed when migrating to pre-commit."""
            with change_cwd(uv_init_dir), files_manager():
                # Arrange - Add a tool first
                use_codespell()

                # Verify dep is present before migration
                dev_deps_before = get_deps_from_group("dev")
                assert any(dep.name == "codespell" for dep in dev_deps_before)

                # Act - Add pre-commit (which triggers migration)
                use_pre_commit()

                # Assert - Dep should STILL be present after migration (issue #1020)
                dev_deps_after = get_deps_from_group("dev")
                assert any(dep.name == "codespell" for dep in dev_deps_after)

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_deps_not_added_when_migrating_from_pre_commit(self, uv_init_dir: Path):
            """Test that deps are NOT re-added when migrating from pre-commit."""
            with change_cwd(uv_init_dir), files_manager():
                # Arrange - Add pre-commit first, then a tool
                use_pre_commit()
                use_codespell()

                # Verify dep is present before removal
                dev_deps_before = get_deps_from_group("dev")
                codespell_deps_before = [
                    dep for dep in dev_deps_before if dep.name == "codespell"
                ]
                assert len(codespell_deps_before) == 1

                # Act - Remove pre-commit (which triggers migration)
                use_pre_commit(remove=True)

                # Assert - Dep should still be present exactly once (not duplicated)
                dev_deps_after = get_deps_from_group("dev")
                codespell_deps_after = [
                    dep for dep in dev_deps_after if dep.name == "codespell"
                ]
                assert len(codespell_deps_after) == 1
                assert codespell_deps_after == codespell_deps_before

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_ruff_deps_not_removed_when_migrating_to_pre_commit(
            self, uv_init_dir: Path
        ):
            """Test that Ruff deps are NOT removed when migrating to pre-commit."""
            with change_cwd(uv_init_dir), files_manager():
                # Arrange - Add Ruff first
                use_ruff()

                # Verify dep is present before migration
                dev_deps_before = get_deps_from_group("dev")
                assert any(dep.name == "ruff" for dep in dev_deps_before)

                # Act - Add pre-commit (which triggers migration)
                use_pre_commit()

                # Assert - Dep should STILL be present after migration (issue #1126)
                dev_deps_after = get_deps_from_group("dev")
                assert any(dep.name == "ruff" for dep in dev_deps_after)

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_ruff_deps_not_added_when_migrating_from_pre_commit(
            self, uv_init_dir: Path
        ):
            """Test that Ruff deps are NOT re-added when migrating from pre-commit."""
            with change_cwd(uv_init_dir), files_manager():
                # Arrange - Add pre-commit first, then Ruff
                use_pre_commit()
                use_ruff()

                # Verify dep is present before removal
                dev_deps_before = get_deps_from_group("dev")
                ruff_deps_before = [
                    dep for dep in dev_deps_before if dep.name == "ruff"
                ]
                assert len(ruff_deps_before) == 1

                # Act - Remove pre-commit (which triggers migration)
                use_pre_commit(remove=True)

                # Assert - Dep should still be present exactly once (not duplicated)
                dev_deps_after = get_deps_from_group("dev")
                ruff_deps_after = [dep for dep in dev_deps_after if dep.name == "ruff"]
                assert len(ruff_deps_after) == 1
                assert ruff_deps_after == ruff_deps_before


class TestPyprojectFmt:
    class TestAdd:
        class TestPyproject:
            @pytest.mark.usefixtures("_vary_network_conn")
            def test_added(self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]):
                # Arrange
                with (
                    change_cwd(uv_init_dir),
                    PyprojectTOMLManager(),
                    usethis_config.set(quiet=True),
                ):
                    add_deps_to_group([Dependency(name="pyproject-fmt")], "dev")

                # Act
                with change_cwd(uv_init_dir), PyprojectTOMLManager():
                    use_pyproject_fmt()

                # Assert
                assert (
                    (uv_init_dir / "pyproject.toml")
                    .read_text()
                    .__contains__(
                        """\
[tool.pyproject-fmt]
keep_full_version = true
"""
                    )
                )
                out, _ = capfd.readouterr()
                assert out == (
                    "✔ Adding pyproject-fmt config to 'pyproject.toml'.\n"
                    "✔ Running pyproject-fmt on 'pyproject.toml'.\n"
                    "☐ Run 'uv run pyproject-fmt pyproject.toml' to run pyproject-fmt.\n"
                )

        class TestDeps:
            @pytest.mark.usefixtures("_vary_network_conn")
            def test_added(self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]):
                with change_cwd(uv_init_dir), PyprojectTOMLManager():
                    # Act
                    use_pyproject_fmt()

                    # Assert
                    assert get_deps_from_group("dev") == [
                        Dependency(name="pyproject-fmt")
                    ]
                out, _ = capfd.readouterr()
                assert out == (
                    "✔ Adding dependency 'pyproject-fmt' to the 'dev' group in 'pyproject.toml'.\n"
                    "☐ Install the dependency 'pyproject-fmt'.\n"
                    "✔ Adding pyproject-fmt config to 'pyproject.toml'.\n"
                    "✔ Running pyproject-fmt on 'pyproject.toml'.\n"
                    "☐ Run 'uv run pyproject-fmt pyproject.toml' to run pyproject-fmt.\n"
                )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_pre_commit_integration(
            self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            # Issue #1020: deps should be added even when pre-commit is used
            with change_cwd(uv_init_dir), files_manager():
                # Arrange
                use_pre_commit()
                capfd.readouterr()

                # Act
                use_pyproject_fmt()

                # Assert
                # Check dependencies - should have installed pyproject-fmt (issue #1020)
                dev_deps = get_deps_from_group("dev")
                assert any(dep.name == "pyproject-fmt" for dep in dev_deps)

                # Check hook names
                hook_names = get_hook_ids()
                assert "pyproject-fmt" in hook_names

            # Check output
            out, err = capfd.readouterr()
            assert not err
            assert out == (
                "✔ Adding dependency 'pyproject-fmt' to the 'dev' group in 'pyproject.toml'.\n"
                "☐ Install the dependency 'pyproject-fmt'.\n"
                "✔ Adding hook 'pyproject-fmt' to '.pre-commit-config.yaml'.\n"
                "✔ Adding pyproject-fmt config to 'pyproject.toml'.\n"
                "✔ Running pyproject-fmt on 'pyproject.toml'.\n"
                "☐ Run 'uv run pyproject-fmt pyproject.toml' to run pyproject-fmt.\n"
            )

    class TestRemove:
        @pytest.mark.usefixtures("_vary_network_conn")
        def test_config_file(self, uv_init_dir: Path):
            # Arrange
            (uv_init_dir / "pyproject.toml").write_text(
                """\
[tool.pyproject-fmt]
foo = "bar"
"""
            )

            # Act
            with change_cwd(uv_init_dir), PyprojectTOMLManager():
                use_pyproject_fmt(remove=True)

            # Assert
            assert (uv_init_dir / "pyproject.toml").read_text() == ""

        def test_doesnt_add_pyproject(self, tmp_path: Path):
            # No pyproject.toml file to begin with...

            # Act
            with change_cwd(tmp_path), files_manager():
                use_pyproject_fmt(remove=True)

            # Assert
            assert not (tmp_path / "pyproject.toml").exists()

    class TestPreCommitIntegration:
        @pytest.mark.usefixtures("_vary_network_conn")
        def test_use_first(self, uv_init_repo_dir: Path):
            with change_cwd(uv_init_repo_dir), files_manager():
                # Arrange
                use_pre_commit()

                # Act
                use_pyproject_fmt()

                # Assert
                hook_names = get_hook_ids()

            assert (uv_init_repo_dir / ".pre-commit-config.yaml").exists()
            assert "pyproject-fmt" in hook_names

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_use_after(self, uv_init_repo_dir: Path):
            with change_cwd(uv_init_repo_dir), files_manager():
                # Arrange
                use_pyproject_fmt()

                # Act
                use_pre_commit()

                # Assert
                hook_names = get_hook_ids()

            assert (uv_init_repo_dir / ".pre-commit-config.yaml").exists()
            assert "pyproject-fmt" in hook_names

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_remove_with_precommit(
            self, uv_init_repo_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            with change_cwd(uv_init_repo_dir), files_manager():
                # Arrange
                with usethis_config.set(quiet=True):
                    use_pyproject_fmt()
                    use_pre_commit()

                # Act
                use_pyproject_fmt(remove=True)

            # Assert
            contents = (uv_init_repo_dir / ".pre-commit-config.yaml").read_text()
            assert "pyproject-fmt" not in contents
            out, err = capfd.readouterr()
            assert not err
            # Issue #1020: Deps are now present even with pre-commit, so they're removed
            assert out == (
                "✔ Removing pyproject-fmt config from 'pyproject.toml'.\n"
                "✔ Removing hook 'pyproject-fmt' from '.pre-commit-config.yaml'.\n"
                "✔ Removing dependency 'pyproject-fmt' from the 'dev' group in 'pyproject.toml'.\n"
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_remove_without_precommit(
            self, uv_init_repo_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            with change_cwd(uv_init_repo_dir), PyprojectTOMLManager():
                # Arrange
                with usethis_config.set(quiet=True):
                    use_pyproject_fmt()

                # Act
                use_pyproject_fmt(remove=True)

            # Assert
            out, err = capfd.readouterr()
            assert not err
            assert out == (
                "✔ Removing pyproject-fmt config from 'pyproject.toml'.\n"
                "✔ Removing dependency 'pyproject-fmt' from the 'dev' group in 'pyproject.toml'.\n"
            )


class TestPyprojectTOML:
    class TestRemove:
        def test_doesnt_invoke_ensure_dep_declaration_file(self, tmp_path: Path):
            # Arrange
            # Mock the ensure_dep_declaration_file function to raise an error

            mock = MagicMock()

            # Act
            with (
                unittest.mock.patch(
                    "usethis._core.tool.ensure_dep_declaration_file", mock
                ),
                change_cwd(tmp_path),
                files_manager(),
            ):
                use_pyproject_toml(remove=True)

            # Assert
            assert not mock.called
            assert not (tmp_path / "pyproject.toml").exists()


class TestPytest:
    class TestAdd:
        @pytest.mark.usefixtures("_vary_network_conn")
        def test_no_pyproject_toml(
            self, tmp_path: Path, capfd: pytest.CaptureFixture[str]
        ):
            with (
                change_cwd(tmp_path),
                files_manager(),
                usethis_config.set(backend=BackendEnum.uv),
            ):
                # Act
                use_pytest()

                # Assert
                deps_from_test = get_deps_from_group("test")
                assert is_dep_satisfied_in(
                    Dependency(name="pytest"), in_=list(deps_from_test)
                )
                # pytest-cov should only be added when we are using coverage
                assert not is_dep_satisfied_in(
                    Dependency(name="pytest-cov"), in_=list(deps_from_test)
                )
                out, _ = capfd.readouterr()
                assert out == (
                    "✔ Writing 'pyproject.toml'.\n"
                    "✔ Adding dependency 'pytest' to the 'test' group in 'pyproject.toml'.\n"
                    "✔ Adding pytest config to 'pyproject.toml'.\n"
                    "✔ Creating '/tests'.\n"
                    "✔ Writing '/tests/conftest.py'.\n"
                    "✔ Writing '/tests/test_example.py'.\n"
                    "☐ Add test files to the '/tests' directory with the format 'test_*.py'.\n"
                    "☐ Add test functions with the format 'test_*()'.\n"
                    "☐ Run 'uv run pytest' to run the tests.\n"
                )

            assert (tmp_path / "pyproject.toml").exists()
            content = (tmp_path / "pyproject.toml").read_text()
            assert content.__contains__(
                """\
[tool.pytest.ini_options]
testpaths = ["tests"]
addopts = ["--import-mode=importlib", "-ra", "--strict-markers", "--strict-config"]
filterwarnings = ["error"]
xfail_strict = true
log_cli_level = "INFO"
minversion = "7\""""
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_example_file_exists(self, uv_init_dir: Path):
            with change_cwd(uv_init_dir), files_manager():
                # Act
                use_pytest()

            # Assert
            assert (uv_init_dir / "tests" / "test_example.py").exists()
            content = (uv_init_dir / "tests" / "test_example.py").read_text()
            assert "def test_add():" in content
            assert "assert 1 + 1 == 2" in content

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_no_example(self, uv_init_dir: Path):
            with change_cwd(uv_init_dir), files_manager():
                # Act
                use_pytest(example=False)

            # Assert
            assert not (uv_init_dir / "tests" / "test_example.py").exists()
            assert (uv_init_dir / "tests" / "conftest.py").exists()

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_coverage_integration(
            self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            with change_cwd(uv_init_dir), files_manager():
                # Arrange
                with usethis_config.set(quiet=True):
                    use_coverage_py()

                # Act
                use_pytest()

            # Assert
            out, _ = capfd.readouterr()
            assert out == (
                "✔ Adding dependencies 'pytest', 'pytest-cov' to the 'test' group in 'pyproject.toml'.\n"
                "☐ Install the dependencies 'pytest', 'pytest-cov'.\n"
                "✔ Adding pytest config to 'pyproject.toml'.\n"
                "✔ Creating '/tests'.\n"
                "✔ Writing '/tests/conftest.py'.\n"
                "✔ Writing '/tests/test_example.py'.\n"
                "☐ Add test files to the '/tests' directory with the format 'test_*.py'.\n"
                "☐ Add test functions with the format 'test_*()'.\n"
                "☐ Run 'uv run pytest' to run the tests.\n"
                "☐ Run 'uv run pytest --cov' to run your tests with Coverage.py.\n"
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_pytest_installed(self, tmp_path: Path):
            with (
                change_cwd(tmp_path),
                files_manager(),
                usethis_config.set(backend=BackendEnum.uv),
            ):
                # Act
                use_pytest()

                # Assert
                # This will raise if pytest is not installed
                call_uv_subprocess(["pip", "show", "pytest"], change_toml=False)

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_registers_test_group(self, tmp_path: Path):
            with (
                change_cwd(tmp_path),
                files_manager(),
                usethis_config.set(backend=BackendEnum.uv),
            ):
                # Act
                use_pytest()

                # Assert
                default_groups = TypeAdapter(list[str]).validate_python(
                    PyprojectTOMLManager()[["tool", "uv", "default-groups"]]
                )
                assert "test" in default_groups

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_registers_test_group_uv_toml(self, tmp_path: Path):
            with change_cwd(tmp_path), files_manager():
                # Arrange
                (tmp_path / "uv.toml").touch()

                # Act
                use_pytest()

                # Assert
                default_groups = TypeAdapter(list[str]).validate_python(
                    UVTOMLManager()[["default-groups"]]
                )
                assert "test" in default_groups

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_ruff_integration(self, uv_init_dir: Path):
            with change_cwd(uv_init_dir), files_manager():
                # Arrange
                use_ruff()

                # Act
                use_pytest()

                # Assert
                assert "PT" in RuffTool().selected_rules()

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_ruff_import_linter_integration_adds_test_dir_ignores(
            self, uv_init_dir: Path
        ):
            with change_cwd(uv_init_dir), files_manager():
                # Arrange
                use_ruff()
                use_import_linter()

                # Act
                use_pytest()

                # Assert
                # Verify that INP rules are ignored in tests/** after pytest creates tests/
                assert "INP" in RuffTool().get_ignored_rules_in_glob("tests/**")

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_pytest_then_ruff_ignores_pt_in_nontests(self, uv_init_dir: Path):
            with change_cwd(uv_init_dir), files_manager():
                # Arrange
                use_pytest()

                # Act
                use_ruff()

                # Assert
                # Verify that PT rules are ignored in non-test files (!tests/**/*.py)
                assert "PT" in RuffTool().get_ignored_rules_in_glob("!tests/**/*.py")

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_ruff_then_pytest_ignores_pt_in_nontests(self, uv_init_dir: Path):
            with change_cwd(uv_init_dir), files_manager():
                # Arrange
                use_ruff()

                # Act
                use_pytest()

                # Assert
                # Verify that PT rules are ignored in non-test files (!tests/**/*.py)
                assert "PT" in RuffTool().get_ignored_rules_in_glob("!tests/**/*.py")

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_pytest_ini_priority(self, uv_init_dir: Path):
            # Arrange
            (uv_init_dir / "pytest.ini").touch()
            (uv_init_dir / "uv.lock").touch()

            # Act
            with change_cwd(uv_init_dir), files_manager():
                use_pytest()

            # Assert
            assert (
                (uv_init_dir / "pytest.ini").read_text()
                == """\
[pytest]
testpaths =
    tests
addopts =
    --import-mode=importlib
    -ra
    --strict-markers
    --strict-config
filterwarnings =
    error
xfail_strict = True
log_cli_level = INFO
minversion = 7
"""
            )

            with PyprojectTOMLManager() as manager:
                assert ["tool", "pytest"] not in manager

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_pyproject_with_ini_priority(self, uv_init_repo_dir: Path):
            # testing it takes priority over setup.cfg
            # Arrange
            (uv_init_repo_dir / "setup.cfg").touch()
            (uv_init_repo_dir / "pyproject.toml").write_text("""\
[tool.pytest.ini_options]
testpaths = ["tests"]
""")

            # Act
            with change_cwd(uv_init_repo_dir), files_manager():
                use_pytest()

            # Assert
            assert (uv_init_repo_dir / "setup.cfg").read_text() == "", (
                "Expected pyproject.toml to take priority when it has a [tool.pytest.ini_options] section"
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_pyproject_without_ini_priority(self, uv_init_repo_dir: Path):
            # Arrange
            (uv_init_repo_dir / "setup.cfg").touch()
            (uv_init_repo_dir / "pyproject.toml").write_text("""\
[tool.pytest]
foo = "bar"
""")

            # Act
            with change_cwd(uv_init_repo_dir), files_manager():
                use_pytest()

            # Assert
            assert (uv_init_repo_dir / "setup.cfg").read_text()

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_pythonpath_needed(self, tmp_path: Path):
            # https://github.com/usethis-python/usethis-python/issues/347

            # Arrange
            # No build backend, so finding './src' for imports won't work unless we
            # explicitly tell pytest where to go.
            (tmp_path / "pyproject.toml").touch()

            (tmp_path / "src").mkdir()
            (tmp_path / "src" / "foo").mkdir()
            (tmp_path / "src" / "foo" / "__init__.py").touch()

            (tmp_path / "tests").mkdir()
            (tmp_path / "tests" / "test_foo.py").write_text(
                """\
def test_foo():
    import foo
"""
            )

            # Act
            with change_cwd(tmp_path), files_manager():
                use_pytest()

            with change_cwd(tmp_path):
                # Assert (that this doesn't raise an error)
                call_uv_subprocess(["run", "pytest"], change_toml=False)

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_import_linter_inp_rules(self, tmp_path: Path):
            with change_cwd(tmp_path), files_manager():
                # Arrange
                use_import_linter()
                (tmp_path / "tests").mkdir()

                # Act
                (tmp_path / "ruff.toml").touch()
                use_ruff()

            # Assert
            with change_cwd(tmp_path), files_manager():
                contents = (tmp_path / "ruff.toml").read_text()
                assert """"tests/**" = ["RUF059", "INP"]""" in contents

    class TestRemove:
        class TestRuffIntegration:
            def test_deselected(self, uv_init_dir: Path):
                # Arrange
                (uv_init_dir / "pyproject.toml").write_text(
                    """\
[tool.ruff.lint]
select = ["E", "PT"]
"""
                )

                # Act
                with change_cwd(uv_init_dir), files_manager():
                    use_pytest(remove=True)

                # Assert
                assert (uv_init_dir / "pyproject.toml").read_text() == (
                    """\
[tool.ruff.lint]
select = ["E"]
"""
                )

            def test_message(
                self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]
            ):
                # Arrange
                (uv_init_dir / "pyproject.toml").write_text(
                    """\
[tool.ruff.lint]
select = ["PT"]
"""
                )

                # Act
                with change_cwd(uv_init_dir), files_manager():
                    use_pytest(remove=True)

                # Assert
                out, _ = capfd.readouterr()
                assert (
                    out
                    == """\
✔ Deselecting Ruff rule 'PT' in 'pyproject.toml'.
"""
                )

        class TestPyprojectIntegration:
            def test_removed(
                self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]
            ):
                # Arrange
                (uv_init_dir / "pyproject.toml").write_text(
                    """\
    [tool.pytest]
    foo = "bar"
    """
                )

                # Act
                with change_cwd(uv_init_dir), files_manager():
                    use_pytest(remove=True)

                # Assert
                assert (uv_init_dir / "pyproject.toml").read_text() == ""
                out, _ = capfd.readouterr()
                # N.B. we don't put `pytest` in quotes because we are referring to the
                # tool, not the package.
                assert out == "✔ Removing pytest config from 'pyproject.toml'.\n"

        class TestDependencies:
            def test_removed(self, uv_init_dir: Path):
                with change_cwd(uv_init_dir), files_manager():
                    # Arrange
                    add_deps_to_group([Dependency(name="pytest")], "test")

                    # Act
                    use_pytest(remove=True)

                    # Assert
                    assert not get_deps_from_group("test")

        def test_coverage_integration(
            self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            with change_cwd(uv_init_dir), files_manager():
                # Arrange
                with usethis_config.set(quiet=True):
                    use_coverage_py()
                    use_pytest()

                # Act
                use_pytest(remove=True)

            # Assert
            out, _ = capfd.readouterr()
            assert out == (
                "✔ Removing pytest config from 'pyproject.toml'.\n"
                "✔ Removing dependencies 'pytest', 'pytest-cov' from the 'test' group in 'pyproject.toml'.\n"
                "✔ Removing '/tests'.\n"
                "☐ Run 'uv run coverage help' to see available Coverage.py commands.\n"
            )

        def test_doesnt_create_pyproject_toml(self, tmp_path: Path):
            # Arrange
            (tmp_path / "pyproject.toml").unlink(missing_ok=True)

            # Act
            with change_cwd(tmp_path), files_manager():
                use_pytest(remove=True)

            # Assert
            assert not (tmp_path / "pyproject.toml").exists()


class TestRequirementsTxt:
    class TestAdd:
        def test_start_from_nothing_uv_backend(
            self, tmp_path: Path, capfd: pytest.CaptureFixture[str]
        ):
            # Act
            with (
                change_cwd(tmp_path),
                PyprojectTOMLManager(),
                usethis_config.set(backend=BackendEnum.uv),
            ):
                use_requirements_txt()

            # Assert
            assert (tmp_path / "requirements.txt").exists()
            assert not (tmp_path / "pyproject.toml").exists()
            assert not (tmp_path / "uv.lock").exists()
            out, err = capfd.readouterr()
            assert not err
            assert out == (
                "✔ Writing 'requirements.txt'.\n"
                "☐ Run 'uv export -o=requirements.txt' to write 'requirements.txt'.\n"
            )
            content = (tmp_path / "requirements.txt").read_text()
            assert content == "-e .\n"

        def test_start_from_nothing_none_backend(
            self, tmp_path: Path, capfd: pytest.CaptureFixture[str]
        ):
            # Act
            with (
                change_cwd(tmp_path),
                PyprojectTOMLManager(),
                usethis_config.set(backend=BackendEnum.none),
            ):
                use_requirements_txt()

            # Assert
            assert (tmp_path / "requirements.txt").exists()
            assert not (tmp_path / "pyproject.toml").exists()
            out, err = capfd.readouterr()
            assert not err
            assert out == "✔ Writing 'requirements.txt'.\n"
            content = (tmp_path / "requirements.txt").read_text()
            assert content == "-e .\n"

        def test_start_from_nothing_poetry_backend(
            self, tmp_path: Path, capfd: pytest.CaptureFixture[str]
        ):
            # Act
            with (
                change_cwd(tmp_path),
                PyprojectTOMLManager(),
                usethis_config.set(backend=BackendEnum.poetry),
            ):
                use_requirements_txt()

            # Assert
            assert (tmp_path / "requirements.txt").exists()
            out, err = capfd.readouterr()
            assert not err
            assert "Writing 'requirements.txt'." in out
            content = (tmp_path / "requirements.txt").read_text()
            assert content == "-e .\n"

        def test_start_from_uv_init(
            self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            # Act
            with (
                change_cwd(uv_init_dir),
                PyprojectTOMLManager(),
                usethis_config.set(frozen=False),
            ):
                use_requirements_txt()

            # Assert
            assert (uv_init_dir / "requirements.txt").exists()
            out, err = capfd.readouterr()
            assert not err
            assert out == (
                "✔ Writing 'uv.lock'.\n"
                "✔ Writing 'requirements.txt'.\n"
                "☐ Run 'uv export -o=requirements.txt' to write 'requirements.txt'.\n"
            )

        def test_start_from_uv_locked(
            self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            with (
                change_cwd(uv_init_dir),
                PyprojectTOMLManager(),
                usethis_config.set(frozen=False),
            ):
                # Arrange
                call_uv_subprocess(["lock"], change_toml=False)

                # Act
                use_requirements_txt()

            # Assert
            assert (uv_init_dir / "requirements.txt").exists()
            out, err = capfd.readouterr()
            assert not err
            assert out == (
                "✔ Writing 'requirements.txt'.\n"
                "☐ Run 'uv export -o=requirements.txt' to write 'requirements.txt'.\n"
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_pre_commit(
            self, uv_init_repo_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            with (
                change_cwd(uv_init_repo_dir),
                files_manager(),
                usethis_config.set(frozen=False),
            ):
                # Arrange
                use_pre_commit()
                capfd.readouterr()

                # Act
                use_requirements_txt()

            # Assert
            assert (uv_init_repo_dir / "requirements.txt").exists()
            content = (uv_init_repo_dir / ".pre-commit-config.yaml").read_text()
            assert content == (
                f"""\
repos:
  - repo: https://github.com/tsvikas/sync-with-uv
    rev: {FALLBACK_SYNC_WITH_UV_VERSION}
    hooks:
      - id: sync-with-uv
  - repo: https://github.com/astral-sh/uv-pre-commit
    rev: {FALLBACK_UV_VERSION}
    hooks:
      - id: uv-export
"""
            )
            out, err = capfd.readouterr()
            assert not err
            assert out == (
                "✔ Adding hook 'uv-export' to '.pre-commit-config.yaml'.\n"
                "✔ Adding requirements.txt config to 'pyproject.toml'.\n"
                "✔ Writing 'requirements.txt'.\n"
                "☐ Run 'uv run pre-commit run -a uv-export' to write 'requirements.txt'.\n"
            )

        def test_none_backend(
            self,
            tmp_path: Path,
            capfd: pytest.CaptureFixture[str],
            monkeypatch: pytest.MonkeyPatch,
        ):
            # Arrange
            (tmp_path / "pyproject.toml").write_text("""\
project.dependencies = [ "ruff", "typer-slim[standard]" ]
""")

            monkeypatch.setattr(  # Do this rather than set Backend.none to test the auto behaviour messages
                usethis._backend.dispatch,
                "is_uv_available",
                lambda *_, **__: False,
            )
            with (
                change_cwd(tmp_path),
                PyprojectTOMLManager(),
                usethis_config.set(backend=BackendEnum.auto),
            ):
                # Act
                use_requirements_txt()

            # Assert
            assert (tmp_path / "requirements.txt").exists()
            assert (
                (tmp_path / "requirements.txt").read_text()
                == """\
-e .
ruff
typer-slim[standard]
"""
            )

            out, err = capfd.readouterr()
            assert not err
            assert out == (
                "ℹ Generating 'requirements.txt' with un-pinned, abstract dependencies.\n"  # noqa: RUF001
                "ℹ Consider installing 'uv' for pinned, cross-platform, full requirements files.\n"  # noqa: RUF001
                "✔ Writing 'requirements.txt'.\n"
            )

    class TestRemove:
        def test_file_gone(self, tmp_path: Path):
            # Arrange
            (tmp_path / "requirements.txt").touch()

            # Act
            with change_cwd(tmp_path), PyprojectTOMLManager():
                use_requirements_txt(remove=True)

            # Assert
            assert not (tmp_path / "requirements.txt").exists()

        def test_requirements_dir(self, tmp_path: Path):
            # Arrange
            (tmp_path / "requirements.txt").mkdir()

            # Act
            with change_cwd(tmp_path), PyprojectTOMLManager():
                use_requirements_txt(remove=True)

            # Assert
            assert (tmp_path / "requirements.txt").exists()

        def test_precommit_integration(self, tmp_path: Path):
            # Arrange
            (tmp_path / ".pre-commit-config.yaml").write_text(
                """\
repos:
  - repo: local
    hooks:
      - id: uv-export
"""
            )

            # Act
            with change_cwd(tmp_path), files_manager():
                use_requirements_txt(remove=True)

            # Assert
            assert (tmp_path / ".pre-commit-config.yaml").exists()
            content = (tmp_path / ".pre-commit-config.yaml").read_text()
            assert "uv-export" not in content

        def test_roundtrip(self, tmp_path: Path):
            with change_cwd(tmp_path), PyprojectTOMLManager():
                # Arrange
                use_requirements_txt()

                # Act
                use_requirements_txt(remove=True)

            # Assert
            assert not (tmp_path / "requirements.txt").exists()

        def test_doesnt_create_pyproject_toml(self, tmp_path: Path):
            # Act
            with change_cwd(tmp_path), files_manager():
                use_requirements_txt(remove=True)

            # Assert
            assert not (tmp_path / "pyproject.toml").exists()


class TestRuff:
    class TestAdd:
        @pytest.mark.usefixtures("_vary_network_conn")
        def test_dependency_added(self, uv_init_dir: Path):
            # Act
            with change_cwd(uv_init_dir), files_manager():
                use_ruff()

                # Assert
                (dev_dep,) = get_deps_from_group("dev")
            assert dev_dep == Dependency(name="ruff")

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_stdout(self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]):
            # Act
            with change_cwd(uv_init_dir), files_manager():
                use_ruff()

            # Assert
            out, _ = capfd.readouterr()
            assert out == (
                "✔ Adding dependency 'ruff' to the 'dev' group in 'pyproject.toml'.\n"
                "☐ Install the dependency 'ruff'.\n"
                "✔ Adding Ruff config to 'pyproject.toml'.\n"
                "✔ Selecting Ruff rules 'A', 'C4', 'E4', 'E7', 'E9', 'F', 'FLY', 'FURB', 'I', 'PLE', 'PLR', 'RUF', 'SIM', 'UP' in 'pyproject.toml'.\n"
                "✔ Ignoring Ruff rules 'PLR2004', 'SIM108' in 'pyproject.toml'.\n"
                "✔ Running the Ruff formatter.\n"
                "☐ Run 'uv run ruff check --fix' to run the Ruff linter with autofixes.\n"
                "☐ Run 'uv run ruff format' to run the Ruff formatter.\n"
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_pre_commit_first(self, uv_init_repo_dir: Path):
            # Act
            with change_cwd(uv_init_repo_dir), files_manager():
                use_ruff()
                use_pre_commit()

                # Assert
                hook_names = get_hook_ids()

            assert "ruff-format" in hook_names
            assert "ruff-check" in hook_names

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_creates_pyproject_toml(
            self, tmp_path: Path, capfd: pytest.CaptureFixture[str]
        ):
            # Act
            with change_cwd(tmp_path), files_manager():
                use_ruff()

            # Assert
            assert (tmp_path / "pyproject.toml").exists()
            out, err = capfd.readouterr()
            assert not err
            assert out.startswith("✔ Writing 'pyproject.toml'.\n")

        def test_existing_ruff_toml(
            self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            # https://github.com/usethis-python/usethis-python/issues/420

            # Arrange
            (uv_init_dir / "ruff.toml").write_text("""\
namespace-packages = ["src/usethis/namespace"]

[lint]
select = [ "ALL" ]
ignore = [ "EM", "T20", "TRY003", "S603" ]

[lint.extend-per-file-ignores]
"__main__.py" = [ "BLE001" ]
""")

            # Act
            with change_cwd(uv_init_dir), files_manager():
                use_ruff()

            # Assert
            out, err = capfd.readouterr()
            assert not err
            assert out == (
                "✔ Adding dependency 'ruff' to the 'dev' group in 'pyproject.toml'.\n"
                "☐ Install the dependency 'ruff'.\n"
                "✔ Adding Ruff config to 'ruff.toml'.\n"
                "✔ Running the Ruff formatter.\n"
                "☐ Run 'uv run ruff check --fix' to run the Ruff linter with autofixes.\n"
                "☐ Run 'uv run ruff format' to run the Ruff formatter.\n"
            )
            assert (uv_init_dir / "ruff.toml").read_text() == (
                """\
namespace-packages = ["src/usethis/namespace"]
line-length = 88

[lint]
select = [ "ALL" ]
ignore = [ "EM", "T20", "TRY003", "S603" ]

[lint.extend-per-file-ignores]
"__main__.py" = [ "BLE001" ]

[format]
docstring-code-format = true
"""
            )

        def test_doesnt_overwrite_existing_line_length(self, uv_init_dir: Path):
            # Arrange
            (uv_init_dir / "ruff.toml").write_text("line-length = 100")

            # Act
            with change_cwd(uv_init_dir), files_manager():
                use_ruff()

                # Assert
                assert RuffTOMLManager()[["line-length"]] == 100

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_ruf059_ignored_in_tests(self, uv_init_dir: Path):
            # https://github.com/usethis-python/usethis-python/issues/1186
            # Arrange
            (uv_init_dir / "tests").mkdir()

            # Act
            with change_cwd(uv_init_dir), files_manager():
                use_ruff()

                # Assert
                assert "RUF059" in RuffTool().get_ignored_rules_in_glob("tests/**")

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_ruf059_not_ignored_in_tests_without_tests_dir(self, uv_init_dir: Path):
            # Arrange - no tests/ directory

            # Act
            with change_cwd(uv_init_dir), files_manager():
                use_ruff()

                # Assert
                assert "RUF059" not in RuffTool().get_ignored_rules_in_glob("tests/**")

        def test_only_add_linter(
            self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            # Act
            with change_cwd(uv_init_dir), files_manager():
                use_ruff(linter=True, formatter=False)

                # Assert
                assert not PyprojectTOMLManager().__contains__(
                    ["tool", "ruff", "format"]
                )

            out, _ = capfd.readouterr()
            assert out == (
                "✔ Adding dependency 'ruff' to the 'dev' group in 'pyproject.toml'.\n"
                "☐ Install the dependency 'ruff'.\n"
                "✔ Adding Ruff config to 'pyproject.toml'.\n"
                "✔ Selecting Ruff rules 'A', 'C4', 'E4', 'E7', 'E9', 'F', 'FLY', 'FURB', 'I', 'PLE', 'PLR', 'RUF', 'SIM', 'UP' in 'pyproject.toml'.\n"
                "✔ Ignoring Ruff rules 'PLR2004', 'SIM108' in 'pyproject.toml'.\n"
                "☐ Run 'uv run ruff check --fix' to run the Ruff linter with autofixes.\n"
            )

        def test_only_add_formatter(
            self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            # Act
            with change_cwd(uv_init_dir), files_manager():
                use_ruff(linter=False, formatter=True)

                # Assert
                assert not PyprojectTOMLManager().__contains__(["tool", "ruff", "lint"])

            out, _ = capfd.readouterr()
            assert out == (
                "✔ Adding dependency 'ruff' to the 'dev' group in 'pyproject.toml'.\n"
                "☐ Install the dependency 'ruff'.\n"
                "✔ Adding Ruff config to 'pyproject.toml'.\n"
                "✔ Running the Ruff formatter.\n"
                "☐ Run 'uv run ruff format' to run the Ruff formatter.\n"
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_config_file(self, uv_init_dir: Path):
            # Arrange
            (uv_init_dir / "pyproject.toml").write_text(
                """\
[tool.ruff.lint]
select = ["A", "B", "C"]
"""
            )

            # Act
            with change_cwd(uv_init_dir), files_manager():
                use_ruff(remove=True)

            # Assert
            assert (uv_init_dir / "pyproject.toml").read_text() == ""

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_blank_slate(self, uv_init_dir: Path):
            # Arrange
            contents = (uv_init_dir / "pyproject.toml").read_text()

            # Act
            with change_cwd(uv_init_dir), files_manager():
                use_ruff(remove=True)

            # Assert
            assert (uv_init_dir / "pyproject.toml").read_text() == contents

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_roundtrip(self, uv_init_dir: Path):
            # Arrange
            with change_cwd(uv_init_dir), files_manager():
                ensure_symlink_mode()
            contents = (uv_init_dir / "pyproject.toml").read_text()

            # Act
            with change_cwd(uv_init_dir), files_manager():
                use_ruff()
                use_ruff(remove=True)

            # Assert
            assert (
                (uv_init_dir / "pyproject.toml").read_text()
                == contents
                + """\

[dependency-groups]
dev = []
"""
            )

        def test_doesnt_create_pyproject_toml(self, tmp_path: Path):
            # Arrange
            (tmp_path / "pyproject.toml").unlink(missing_ok=True)

            # Act
            with change_cwd(tmp_path), files_manager():
                use_ruff(remove=True)

            # Assert
            assert not (tmp_path / "pyproject.toml").exists()

        def test_only_formatter(self, tmp_path: Path):
            # Arrange
            (tmp_path / "pyproject.toml").write_text(
                """\
[tool.ruff.lint]
select = ["E", "PT"]

[tool.ruff.format]
select = ["F"]
"""
            )

            # Act
            with change_cwd(tmp_path), files_manager():
                use_ruff(linter=False, formatter=True, remove=True)

            # Assert
            assert (tmp_path / "pyproject.toml").read_text() == (
                """\
[tool.ruff.lint]
select = ["E", "PT"]

"""
            )

        def test_only_linter(self, tmp_path: Path):
            # Arrange
            (tmp_path / "pyproject.toml").write_text(
                """\
[tool.ruff.lint]
fake = ["E", "PT"]

[tool.ruff.format]
select = ["F"]
"""
            )

            # Act
            with change_cwd(tmp_path), files_manager():
                use_ruff(linter=True, formatter=False, remove=True)

            # Assert
            assert (tmp_path / "pyproject.toml").read_text() == (
                """\
[tool.ruff.format]
select = ["F"]
"""
            )

    class TestHow:
        def test_both_linter_and_formatter(
            self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            # Act
            with change_cwd(uv_init_dir), files_manager():
                use_ruff(how=True, linter=True, formatter=True)

            # Assert
            out, _ = capfd.readouterr()
            assert out == (
                "☐ Run 'uv run ruff check --fix' to run the Ruff linter with autofixes.\n"
                "☐ Run 'uv run ruff format' to run the Ruff formatter.\n"
            )

        def test_only_linter(
            self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            # Act
            with change_cwd(uv_init_dir), files_manager():
                use_ruff(how=True, linter=True, formatter=False)

            # Assert
            out, _ = capfd.readouterr()
            assert out == (
                "☐ Run 'uv run ruff check --fix' to run the Ruff linter with autofixes.\n"
            )

        def test_only_formatter(
            self, uv_init_repo_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            # Act
            with change_cwd(uv_init_repo_dir), files_manager():
                use_ruff(how=True, linter=False, formatter=True)

            # Assert
            out, _ = capfd.readouterr()
            assert out == "☐ Run 'uv run ruff format' to run the Ruff formatter.\n"

    class TestPrecommitIntegration:
        @pytest.mark.usefixtures("_vary_network_conn")
        def test_use_first(self, uv_init_repo_dir: Path):
            with change_cwd(uv_init_repo_dir), files_manager():
                # Arrange
                use_ruff()

                # Act
                use_pre_commit()

                # Assert
                hook_names = get_hook_ids()
                assert "ruff-format" in hook_names
                assert "ruff-check" in hook_names

                # Issue #1126: Deps should remain even when using pre-commit
                dev_deps = get_deps_from_group("dev")
                assert any(dep.name == "ruff" for dep in dev_deps)

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_use_after(self, uv_init_repo_dir: Path):
            with change_cwd(uv_init_repo_dir), files_manager():
                # Arrange
                use_pre_commit()

                # Act
                use_ruff()

                # Assert
                hook_names = get_hook_ids()
                assert "ruff-format" in hook_names
                assert "ruff-check" in hook_names

                # Issue #1126: Deps should be added even when pre-commit is used
                dev_deps = get_deps_from_group("dev")
                assert any(dep.name == "ruff" for dep in dev_deps)

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_remove(
            self, uv_init_repo_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            with change_cwd(uv_init_repo_dir), files_manager():
                # Arrange
                with usethis_config.set(quiet=True):
                    use_ruff()
                    use_pre_commit()

                # Act
                use_ruff(remove=True)

            # Assert
            contents = (uv_init_repo_dir / ".pre-commit-config.yaml").read_text()
            assert "ruff" not in contents
            out, err = capfd.readouterr()
            assert not err
            # Issue #1020: Deps are now present even with pre-commit, so they're removed
            assert out == (
                "✔ Removing hook 'ruff-check' from '.pre-commit-config.yaml'.\n"
                "✔ Removing hook 'ruff-format' from '.pre-commit-config.yaml'.\n"
                "✔ Removing Ruff config from 'pyproject.toml'.\n"
                "✔ Removing dependency 'ruff' from the 'dev' group in 'pyproject.toml'.\n"
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_add_only_linter(
            self, uv_init_repo_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            with change_cwd(uv_init_repo_dir), files_manager():
                # Arrange
                use_pre_commit()
                capfd.readouterr()

                # Act
                use_ruff(linter=True, formatter=False)

                # Assert
                hook_names = get_hook_ids()

            # 1. File exists
            assert (uv_init_repo_dir / ".pre-commit-config.yaml").exists()

            # 2. Hook is in the file
            assert "ruff-check" in hook_names
            assert "ruff-format" not in hook_names

            # 3. Test file contents
            assert (uv_init_repo_dir / ".pre-commit-config.yaml").read_text() == (
                f"""\
repos:
  - repo: https://github.com/tsvikas/sync-with-uv
    rev: {FALLBACK_SYNC_WITH_UV_VERSION}
    hooks:
      - id: sync-with-uv
  - repo: https://github.com/astral-sh/ruff-pre-commit
    rev: {FALLBACK_RUFF_VERSION}
    hooks:
      - id: ruff-check
"""
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_add_only_linter_to_existing_formatter(
            self, uv_init_repo_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            with change_cwd(uv_init_repo_dir), files_manager():
                # Arrange
                use_ruff(formatter=True)
                use_pre_commit()
                capfd.readouterr()

                # Act
                use_ruff(linter=True, formatter=False)

                # Assert
                hook_names = get_hook_ids()

            # 1. File exists
            assert (uv_init_repo_dir / ".pre-commit-config.yaml").exists()

            # 2. Hook is in the file
            assert "ruff-check" in hook_names
            assert "ruff-format" in hook_names

            # 3. Test file contents
            assert (uv_init_repo_dir / ".pre-commit-config.yaml").read_text() == (
                f"""\
repos:
  - repo: https://github.com/tsvikas/sync-with-uv
    rev: {FALLBACK_SYNC_WITH_UV_VERSION}
    hooks:
      - id: sync-with-uv
  - repo: https://github.com/astral-sh/ruff-pre-commit
    rev: {FALLBACK_RUFF_VERSION}
    hooks:
      - id: ruff-check
  - repo: https://github.com/astral-sh/ruff-pre-commit
    rev: {FALLBACK_RUFF_VERSION}
    hooks:
      - id: ruff-format
"""
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_add_only_formatter(
            self, uv_init_repo_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            with change_cwd(uv_init_repo_dir), files_manager():
                # Arrange
                use_pre_commit()
                capfd.readouterr()

                # Act
                use_ruff(linter=False, formatter=True)

                # Assert
                hook_names = get_hook_ids()

            # 1. File exists
            assert (uv_init_repo_dir / ".pre-commit-config.yaml").exists()

            # 2. Hook is in the file
            assert "ruff" not in hook_names
            assert "ruff-format" in hook_names

            # 3. Test file contents
            assert (uv_init_repo_dir / ".pre-commit-config.yaml").read_text() == (
                f"""\
repos:
  - repo: https://github.com/tsvikas/sync-with-uv
    rev: {FALLBACK_SYNC_WITH_UV_VERSION}
    hooks:
      - id: sync-with-uv
  - repo: https://github.com/astral-sh/ruff-pre-commit
    rev: {FALLBACK_RUFF_VERSION}
    hooks:
      - id: ruff-format
"""
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_remove_only_linter(
            self, uv_init_repo_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            with change_cwd(uv_init_repo_dir), files_manager():
                # Arrange
                use_ruff()
                use_pre_commit()
                capfd.readouterr()

                # Act
                use_ruff(linter=True, formatter=False, remove=True)

                # Assert
                hook_names = get_hook_ids()

            # 1. File exists
            assert (uv_init_repo_dir / ".pre-commit-config.yaml").exists()

            # 2. Hook is in the file
            assert "ruff" not in hook_names
            assert "ruff-format" in hook_names

            # 3. Test file contents
            assert (uv_init_repo_dir / ".pre-commit-config.yaml").read_text() == (
                f"""\
repos:
  - repo: https://github.com/tsvikas/sync-with-uv
    rev: {FALLBACK_SYNC_WITH_UV_VERSION}
    hooks:
      - id: sync-with-uv
  - repo: https://github.com/astral-sh/ruff-pre-commit
    rev: {FALLBACK_RUFF_VERSION}
    hooks:
      - id: ruff-format
"""
            )

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_remove_only_linter_yaml_only(
            self, uv_init_repo_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            # Arrange
            (uv_init_repo_dir / ".pre-commit-config.yaml").write_text("""\
repos:
  - repo: local
    hooks:
      - id: ruff
        name: ruff
        types_or:
          - python
          - pyi
          - jupyter
        always_run: true
        entry: uv run --frozen --offline ruff check --fix --force-exclude
        language: system
        require_serial: true
  - repo: local
    hooks:
      - id: ruff-format
        name: ruff-format
        types_or:
          - python
          - pyi
          - jupyter
        always_run: true
        entry: uv run --frozen --offline ruff format --force-exclude
        language: system
        require_serial: true
""")

            with change_cwd(uv_init_repo_dir), files_manager():
                capfd.readouterr()

                # Act
                use_ruff(linter=True, formatter=False, remove=True)

                # Assert
                hook_names = get_hook_ids()

            # 1. File exists
            assert (uv_init_repo_dir / ".pre-commit-config.yaml").exists()

            # 2. Hook is in the file
            assert "ruff" not in hook_names
            assert "ruff-check" not in hook_names
            assert "ruff-format" in hook_names

            # 3. Test file contents
            assert (uv_init_repo_dir / ".pre-commit-config.yaml").read_text() == (
                """\
repos:
  - repo: local
    hooks:
      - id: ruff-format
        name: ruff-format
        types_or:
          - python
          - pyi
          - jupyter
        always_run: true
        entry: uv run --frozen --offline ruff format --force-exclude
        language: system
        require_serial: true
"""
            )

    class TestConfig:
        def test_removed(self, uv_init_dir: Path):
            # Arrange
            (uv_init_dir / ".ruff.toml").write_text(
                """\
[lint]
select = ["A", "B", "C"]
"""
            )

            # Act
            with change_cwd(uv_init_dir), files_manager():
                use_ruff(remove=True)

            # Assert
            assert not (uv_init_dir / ".ruff.toml").exists()

        def test_adding_to_file(self, uv_init_dir: Path):
            # Arrange
            (uv_init_dir / ".ruff.toml").touch()

            # Act
            with change_cwd(uv_init_dir), files_manager():
                use_ruff()

            # Assert
            assert (uv_init_dir / ".ruff.toml").exists()
            assert "[lint]" in (uv_init_dir / ".ruff.toml").read_text()

        def test_highest_priority(self, uv_init_dir: Path):
            # Arrange
            (uv_init_dir / ".ruff.toml").touch()
            (uv_init_dir / "pyproject.toml").touch()
            (uv_init_dir / "ruff.toml").touch()

            # Act
            with change_cwd(uv_init_dir), files_manager():
                use_ruff()

            # Assert
            assert "[lint]" in (uv_init_dir / ".ruff.toml").read_text()
            assert "[lint]" not in (uv_init_dir / "pyproject.toml").read_text()
            assert (uv_init_dir / "ruff.toml").read_text() == ""

        def test_removed_from_all_files(self, uv_init_dir: Path):
            # Arrange
            (uv_init_dir / ".ruff.toml").write_text(
                """\
[lint]
select = ["A", "B", "C"]
"""
            )
            (uv_init_dir / "pyproject.toml").write_text(
                """\
[tool.ruff.lint]
select = ["A", "B", "C"]
"""
            )
            (uv_init_dir / "ruff.toml").write_text(
                """\
[lint]
select = ["A", "B", "C"]
"""
            )

            # Act
            with change_cwd(uv_init_dir), files_manager():
                use_ruff(remove=True)

            # Assert
            assert not (uv_init_dir / ".ruff.toml").exists()
            assert (
                "[tool.ruff.lint]" not in (uv_init_dir / "pyproject.toml").read_text()
            )
            assert not (uv_init_dir / "ruff.toml").exists()


class TestUseTool:
    def test_add_all_tool(self, uv_init_dir: Path):
        # Act
        with change_cwd(uv_init_dir), files_manager():
            for tool in ALL_TOOLS:
                use_tool(tool)

    @pytest.mark.parametrize("tool", ALL_TOOLS, ids=lambda t: t.name)
    @pytest.mark.usefixtures("_vary_network_conn")
    def test_runs(self, tool: SupportedToolType, uv_env_dir: Path):
        with change_cwd(uv_env_dir):
            with files_manager():
                use_tool(tool)

            # Re-apply after files_manager flushes: apply() inside use_tool()
            # runs before files are written to disk, so formatters' on-disk
            # changes are overwritten by the deferred write. A fresh
            # files_manager() context is needed because some apply() methods
            # (e.g. RuffTool) read config via file managers.
            with files_manager():
                tool.apply()

            try:
                cmd = tool.raw_cmd()
            except NoDefaultToolCommand:
                pytest.skip(f"{tool.name} has no default command")

            call_uv_subprocess(
                ["run", *shlex.split(cmd)],
                change_toml=False,
            )


class TestTy:
    class TestAdd:
        @pytest.mark.usefixtures("_vary_network_conn")
        def test_dependency_added(self, uv_init_dir: Path):
            # Act
            with change_cwd(uv_init_dir), files_manager():
                use_ty()

                # Assert
                (dev_dep,) = [d for d in get_deps_from_group("dev") if d.name == "ty"]
            assert dev_dep == Dependency(name="ty")

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_config(self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]):
            # Arrange
            with change_cwd(uv_init_dir), PyprojectTOMLManager():
                add_deps_to_group([Dependency(name="ty")], "dev")

            capfd.readouterr()

            # Act
            with change_cwd(uv_init_dir), files_manager():
                use_ty()

            # Assert
            out, err = capfd.readouterr()
            assert not err
            assert "Adding ty config to 'pyproject.toml'." in out
            assert "☐ Run 'uv run ty check' to run the ty type checker.\n" in out

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_pre_commit_integration(
            self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            with change_cwd(uv_init_dir), files_manager():
                # Arrange
                use_pre_commit()
                capfd.readouterr()

                # Act
                use_ty()

                # Assert
                dev_deps = get_deps_from_group("dev")
                assert any(dep.name == "ty" for dep in dev_deps)

                hook_names = get_hook_ids()
                assert "ty" in hook_names

    class TestRemove:
        @pytest.mark.usefixtures("_vary_network_conn")
        def test_removes_config(self, uv_init_dir: Path):
            with change_cwd(uv_init_dir), files_manager():
                # Arrange
                use_ty()

                # Act
                use_ty(remove=True)

            # Assert
            assert "[tool.ty" not in (uv_init_dir / "pyproject.toml").read_text()

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_removes_dependency(self, uv_init_dir: Path):
            with change_cwd(uv_init_dir), files_manager():
                # Arrange
                use_ty()

                # Act
                use_ty(remove=True)

                # Assert
                deps = get_deps_from_group("dev")
            assert not any(dep.name == "ty" for dep in deps)

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_removes_managed_ty_toml(self, uv_init_dir: Path):
            with change_cwd(uv_init_dir), files_manager():
                # Arrange
                use_ty()
                (uv_init_dir / "ty.toml").touch()

                # Act
                use_ty(remove=True)

            # Assert
            assert not (uv_init_dir / "ty.toml").exists()

        @pytest.mark.usefixtures("_vary_network_conn")
        def test_removes_managed_dot_ty_toml(self, uv_init_dir: Path):
            with change_cwd(uv_init_dir), files_manager():
                # Arrange
                use_ty()
                (uv_init_dir / ".ty.toml").write_text(
                    """\
[rules]
possibly-unresolved-reference = "warn"
"""
                )

                # Act
                use_ty(remove=True)

            # Assert
            assert not (uv_init_dir / ".ty.toml").exists()

    class TestHow:
        def test_how(self, tmp_path: Path, capfd: pytest.CaptureFixture[str]):
            # Act
            with change_cwd(tmp_path), files_manager():
                use_ty(how=True)

            # Assert
            out, err = capfd.readouterr()
            assert not err
            assert out == "☐ Run 'ty check' to run the ty type checker.\n"


class TestTach:
    class TestAdd:
        def test_dependency_added(self, uv_init_dir: Path):
            # Act
            with change_cwd(uv_init_dir), files_manager():
                use_tach()

                # Assert
                (dev_dep,) = [d for d in get_deps_from_group("dev") if d.name == "tach"]
            assert dev_dep == Dependency(name="tach")

        def test_config_created(
            self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            # Act
            with change_cwd(uv_init_dir), files_manager():
                use_tach()

            # Assert
            out, err = capfd.readouterr()
            assert not err
            assert "Writing 'tach.toml'." in out
            assert (uv_init_dir / "tach.toml").exists()

        def test_pre_commit_integration(
            self, uv_init_dir: Path, capfd: pytest.CaptureFixture[str]
        ):
            with change_cwd(uv_init_dir), files_manager():
                # Arrange
                use_pre_commit()
                capfd.readouterr()

                # Act
                use_tach()

                # Assert
                dev_deps = get_deps_from_group("dev")
                assert any(dep.name == "tach" for dep in dev_deps)

                hook_names = get_hook_ids()
                assert "tach" in hook_names

    class TestRemove:
        def test_removes_config(self, uv_init_dir: Path):
            with change_cwd(uv_init_dir), files_manager():
                # Arrange
                use_tach()

                # Act
                use_tach(remove=True)

            # Assert
            assert not (uv_init_dir / "tach.toml").exists()

        def test_removes_dependency(self, uv_init_dir: Path):
            with change_cwd(uv_init_dir), files_manager():
                # Arrange
                use_tach()

                # Act
                use_tach(remove=True)

                # Assert
                deps = get_deps_from_group("dev")
            assert not any(dep.name == "tach" for dep in deps)

    class TestHow:
        def test_how(self, tmp_path: Path, capfd: pytest.CaptureFixture[str]):
            # Act
            with change_cwd(tmp_path), files_manager():
                use_tach(how=True)

            # Assert
            out, err = capfd.readouterr()
            assert not err
            assert out == "☐ Run 'tach check' to run Tach.\n"
