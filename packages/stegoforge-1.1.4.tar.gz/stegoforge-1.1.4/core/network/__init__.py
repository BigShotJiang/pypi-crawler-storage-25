"""Network covert channel modules."""
