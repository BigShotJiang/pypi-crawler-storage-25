"""Video carrier encoders."""
