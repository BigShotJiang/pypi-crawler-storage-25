"""OpenAI integration — log every tool call returned by chat.completions.

This is a one-liner helper, not a monkey-patch: you call
``wrapper.process_tool_calls(response)`` after each OpenAI response.
Keeping it explicit avoids surprising side-effects on the OpenAI client
and works with any version of ``openai>=1.0``.

Optionally requires the ``openai`` extra::

    pip install 'alsorn[openai]'

(``openai`` is not imported eagerly — the wrapper duck-types the
response object, so installing ``openai`` is only required to *make* the
calls in the first place.)

Usage::

    from alsorn.integrations.openai import AlsornOpenAIWrapper
    import openai

    wrapper = AlsornOpenAIWrapper(
        agent_id="a3f8c9d2-...",
        api_key="als_your_key",
    )

    client = openai.OpenAI()
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[...],
        tools=[...],
    )

    wrapper.process_tool_calls(response)
"""

from __future__ import annotations

import json
import logging
import re
from typing import Any

from alsorn.client import AlsornClient


_logger = logging.getLogger("alsorn")

_NOTES_MAX = 500
_CURRENCY_RE = re.compile(r"^[A-Z]{3}$")


def _map_action(function_name: str) -> str:
    name = function_name.lower()
    for keyword, action in (
        ("trade", "execute_trades"),
        ("buy", "execute_trades"),
        ("sell", "execute_trades"),
        ("transfer", "execute_trades"),
        ("payment", "execute_trades"),
        ("pay", "execute_trades"),
        ("email", "send_emails"),
        ("send", "send_emails"),
        ("message", "send_emails"),
        ("book", "book_flights"),
        ("flight", "book_flights"),
        ("travel", "book_flights"),
        ("contract", "file_contracts"),
        ("file", "file_contracts"),
        ("sign", "file_contracts"),
        ("support", "customer_support"),
        ("ticket", "customer_support"),
        ("write", "write_data"),
        ("update", "write_data"),
        ("create", "write_data"),
    ):
        if keyword in name:
            return action
    return "read_data"


def _coerce_amount(raw: Any) -> float:
    if raw is None:
        return 0.0
    if isinstance(raw, (int, float)):
        return float(raw)
    if isinstance(raw, str):
        cleaned = raw.replace("$", "").replace(",", "").strip()
        try:
            return float(cleaned)
        except ValueError:
            return 0.0
    return 0.0


def _normalize_currency(raw: Any) -> str:
    if isinstance(raw, str):
        candidate = raw.strip().upper()
        if _CURRENCY_RE.match(candidate):
            return candidate
    return "USD"


def _truncate_notes(text: str) -> str:
    return text if len(text) <= _NOTES_MAX else text[: _NOTES_MAX - 1] + "…"


class AlsornOpenAIWrapper:
    """Logs OpenAI tool calls to the Alsorn ledger.

    The wrapper does not modify the underlying OpenAI client. Call
    ``process_tool_calls(response)`` after each ``chat.completions.create``
    response that may contain tool calls. Logging failures are swallowed
    and routed to the ``alsorn`` logger.
    """

    def __init__(
        self,
        agent_id: str,
        api_key: str,
        openai_client: Any = None,
        base_url: str = "https://api.alsorn.com",
    ) -> None:
        self.agent_id = agent_id
        self.alsorn = AlsornClient(api_key=api_key, base_url=base_url)
        self.openai = openai_client

    def process_tool_calls(self, response: Any) -> None:
        try:
            message = response.choices[0].message
        except (AttributeError, IndexError):
            return

        tool_calls = getattr(message, "tool_calls", None)
        if not tool_calls:
            return

        for tool_call in tool_calls:
            self._log_tool_call(tool_call)

    def _log_tool_call(self, tool_call: Any) -> None:
        function_name = getattr(getattr(tool_call, "function", None), "name", "unknown_function")
        raw_arguments = getattr(getattr(tool_call, "function", None), "arguments", "{}") or "{}"

        try:
            arguments: dict[str, Any] = json.loads(raw_arguments)
        except (ValueError, TypeError):
            arguments = {}

        amount = _coerce_amount(arguments.get("amount", arguments.get("value")))
        currency = _normalize_currency(arguments.get("currency", "USD"))
        counterparty_id = arguments.get("counterparty") or "openai-function"

        notes = _truncate_notes(
            f"Function: {function_name} | Args: {json.dumps(arguments)[:300]}"
        )

        try:
            self.alsorn.transactions.execute(
                agent_id=self.agent_id,
                counterparty_id=str(counterparty_id),
                amount=amount,
                action_type=_map_action(function_name),
                currency=currency,
                notes=notes,
            )
        except Exception as exc:
            _logger.warning("Failed to log OpenAI tool call %s: %s", function_name, exc)
