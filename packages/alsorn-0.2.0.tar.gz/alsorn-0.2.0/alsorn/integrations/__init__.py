"""Optional integrations for popular agent frameworks.

Each submodule has its own optional dependency and is imported lazily.
Importing this package alone does not require LangChain or OpenAI to be
installed; you only need them when you ``import alsorn.integrations.langchain``
or ``import alsorn.integrations.openai``.

Install extras with::

    pip install 'alsorn[langchain]'
    pip install 'alsorn[openai]'
    pip install 'alsorn[all]'
"""
