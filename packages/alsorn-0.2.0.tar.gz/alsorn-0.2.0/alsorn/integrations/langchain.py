"""LangChain integration — automatic transaction logging via callback handler.

Requires the ``langchain`` extra::

    pip install 'alsorn[langchain]'

Usage::

    from alsorn.integrations.langchain import AlsornCallback

    callback = AlsornCallback(
        agent_id="a3f8c9d2-...",
        api_key="als_your_key",
    )

    agent = initialize_agent(
        tools=tools,
        llm=llm,
        callbacks=[callback],
    )

    agent.run("Execute the trading strategy")
"""

from __future__ import annotations

import logging
import re
from typing import Any

from alsorn.client import AlsornClient
from alsorn.exceptions import AlsornError

try:
    from langchain_core.callbacks import BaseCallbackHandler
except ImportError:
    try:
        from langchain.callbacks.base import BaseCallbackHandler  # type: ignore[no-redef]
    except ImportError as e:
        raise AlsornError(
            "LangChain is not installed. Install with: pip install 'alsorn[langchain]'"
        ) from e


_logger = logging.getLogger("alsorn")

_NOTES_MAX = 500

_TOOL_TO_ACTION: dict[str, str] = {
    "trade": "execute_trades",
    "order": "execute_trades",
    "buy": "execute_trades",
    "sell": "execute_trades",
    "transfer": "execute_trades",
    "payment": "execute_trades",
    "email": "send_emails",
    "mail": "send_emails",
    "send": "send_emails",
    "contract": "file_contracts",
    "file": "file_contracts",
    "sign": "file_contracts",
    "book": "book_flights",
    "flight": "book_flights",
    "travel": "book_flights",
    "support": "customer_support",
    "ticket": "customer_support",
    "read": "read_data",
    "search": "read_data",
    "query": "read_data",
    "fetch": "read_data",
    "write": "write_data",
    "update": "write_data",
    "create": "write_data",
    "code": "manage_code",
    "git": "manage_code",
    "commit": "manage_code",
}

_AMOUNT_RE = re.compile(r"\$?([\d,]+\.?\d*)")


def _map_action(tool_name: str) -> str:
    name = tool_name.lower()
    for keyword, action in _TOOL_TO_ACTION.items():
        if keyword in name:
            return action
    return "read_data"


def _extract_amount(*texts: str) -> float:
    for text in texts:
        if not text:
            continue
        for match in _AMOUNT_RE.findall(text):
            try:
                value = float(match.replace(",", ""))
            except ValueError:
                continue
            if value > 0:
                return value
    return 0.0


def _truncate_notes(text: str) -> str:
    return text if len(text) <= _NOTES_MAX else text[: _NOTES_MAX - 1] + "…"


class AlsornCallback(BaseCallbackHandler):
    """LangChain callback handler that logs every tool call to the Alsorn ledger.

    Logging failures are caught and routed to the ``alsorn`` logger
    (``logging.getLogger("alsorn")``) so that audit-side issues never break
    the agent. The handler implements both sync and async variants so it
    works with ``AgentExecutor.invoke`` and ``AgentExecutor.ainvoke``.
    """

    def __init__(
        self,
        agent_id: str,
        api_key: str,
        base_url: str = "https://api.alsorn.com",
        counterparty_id: str = "langchain-tool",
    ) -> None:
        self.agent_id = agent_id
        self.counterparty_id = counterparty_id
        self.client: AlsornClient = AlsornClient(api_key=api_key, base_url=base_url)
        self._current_tool: str | None = None
        self._current_input: str | None = None

    # -- sync ---------------------------------------------------------

    def on_tool_start(
        self,
        serialized: dict[str, Any],
        input_str: str,
        **kwargs: Any,
    ) -> None:
        self._current_tool = serialized.get("name", "unknown_tool")
        self._current_input = input_str

    def on_tool_end(self, output: str, **kwargs: Any) -> None:
        tool_name = self._current_tool or "unknown_tool"
        input_str = self._current_input or ""

        amount = _extract_amount(input_str, output)
        action_type = _map_action(tool_name)

        notes = _truncate_notes(
            f"Tool: {tool_name} | Input: {input_str[:200]} | Output: {output[:200]}"
        )

        try:
            self.client.transactions.execute(
                agent_id=self.agent_id,
                counterparty_id=self.counterparty_id,
                amount=amount,
                action_type=action_type,
                notes=notes,
            )
        except Exception as exc:
            _logger.warning("Failed to log LangChain tool call: %s", exc)

        self._current_tool = None
        self._current_input = None

    def on_agent_action(self, action: Any, **kwargs: Any) -> None:
        # Logging happens in on_tool_end to avoid double-logging the same step.
        pass

    # -- async --------------------------------------------------------

    async def on_tool_start_async(
        self,
        serialized: dict[str, Any],
        input_str: str,
        **kwargs: Any,
    ) -> None:
        self.on_tool_start(serialized, input_str, **kwargs)

    async def on_tool_end_async(self, output: str, **kwargs: Any) -> None:
        import asyncio

        await asyncio.to_thread(self.on_tool_end, output, **kwargs)
