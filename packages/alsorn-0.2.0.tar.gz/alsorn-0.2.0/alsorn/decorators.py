"""Function decorator for automatic transaction logging.

Wraps any sync or async function so that every successful call is logged
to the Alsorn ledger. Drop-in alternative to the LangChain or OpenAI
integrations for code that doesn't use either framework.

Usage::

    from alsorn.decorators import track

    @track(
        agent_id="a3f8c9d2-...",
        api_key="als_your_key",
        action_type="execute_trades",
        extract_amount=lambda amount, asset: amount,
    )
    def execute_trade(amount, asset):
        broker.place_order(asset, amount)
        return {"status": "completed"}

    execute_trade(5000, "BTC")  # logged automatically
"""

from __future__ import annotations

import functools
import inspect
import logging
from typing import Any, Callable

from alsorn.client import AlsornClient


_logger = logging.getLogger("alsorn")

_NOTES_MAX = 500


def _truncate_notes(text: str) -> str:
    return text if len(text) <= _NOTES_MAX else text[: _NOTES_MAX - 1] + "…"


def track(
    agent_id: str,
    api_key: str,
    action_type: str = "read_data",
    extract_amount: Callable[..., float] | None = None,
    base_url: str = "https://api.alsorn.com",
    counterparty_id: str = "decorated-call",
    currency: str = "USD",
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Wrap a function so each successful call is logged to the Alsorn ledger.

    Args:
        agent_id: The agent ID to log the call under.
        api_key: An Alsorn API key (must start with ``als_``).
        action_type: Action type for the ledger entry. Must be one of the
            agent's authorized actions, otherwise the server returns 403.
            Defaults to ``"read_data"``.
        extract_amount: Optional callable receiving the same args/kwargs as
            the wrapped function and returning a float amount. If omitted,
            ``amount=0`` is logged (which the API now accepts for
            non-monetary actions). Example: ``lambda amount, asset: amount``.
        base_url: Override the API base URL (e.g. for staging).
        counterparty_id: Free-form counterparty identifier written to the
            ledger entry. Defaults to ``"decorated-call"``.
        currency: ISO 4217 currency code. Defaults to ``"USD"``.

    Notes:
        * Logging failures are caught and routed to the ``alsorn`` logger;
          they never propagate to the caller.
        * Exceptions raised inside the wrapped function are NOT swallowed —
          they propagate normally. No ledger entry is written when the
          wrapped function raises.
        * Both sync and ``async def`` functions are supported.
    """
    if not isinstance(action_type, str) or not action_type:
        raise ValueError("action_type must be a non-empty string")

    client = AlsornClient(api_key=api_key, base_url=base_url)

    def _log(func_name: str, args: tuple[Any, ...], kwargs: dict[str, Any]) -> None:
        amount = 0.0
        if extract_amount is not None:
            try:
                amount = float(extract_amount(*args, **kwargs))
            except Exception as exc:
                _logger.warning(
                    "extract_amount raised for %s: %s — defaulting to 0", func_name, exc
                )

        notes = _truncate_notes(
            f"Function: {func_name} | Args: {str(args)[:100]}"
        )

        try:
            client.transactions.execute(
                agent_id=agent_id,
                counterparty_id=counterparty_id,
                amount=amount,
                action_type=action_type,
                currency=currency,
                notes=notes,
            )
        except Exception as exc:
            _logger.warning("Failed to log decorated call %s: %s", func_name, exc)

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        if inspect.iscoroutinefunction(func):

            @functools.wraps(func)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                result = await func(*args, **kwargs)
                _log(func.__name__, args, kwargs)
                return result

            return async_wrapper

        @functools.wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            result = func(*args, **kwargs)
            _log(func.__name__, args, kwargs)
            return result

        return sync_wrapper

    return decorator
