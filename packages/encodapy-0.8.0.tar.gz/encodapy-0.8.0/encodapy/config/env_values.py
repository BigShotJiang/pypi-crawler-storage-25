"""
This module contains the environment variables for the communication interfaces.
Authors: Martin Altenburger, Paul Seidel, Maximilian Beyer
more information: https://docs.pydantic.dev/latest/concepts/pydantic_settings/#usage
"""

from typing import Optional
from datetime import time, timedelta
from pydantic import AnyHttpUrl, Field
from pydantic_settings import BaseSettings, SettingsConfigDict
from encodapy.config.models import FileStorageMethod

class BasicEnvVariables(BaseSettings):
    """
    Basic environment variables for the service.
    They are automatically loaded from the environment or a .env file.
    """

    model_config = SettingsConfigDict(
        extra="ignore", env_file=".env", env_prefix="", case_sensitive=False
    )

    config_path: str = Field(
        default="config.json", description="Path to the configuration file"
    )
    log_level: str = Field(
        default="WARNING", description="Logging level for the service"
    )
    log_path: Optional[str] = Field(
        default=None,
        description=(
            "Path to the log file. If not provided, logs will be printed to the console. "
            "Example: './logs/service.log'"
        ),
    )
    log_retention: Optional[int | str | timedelta] = Field(
        default=None,
        description=(
            "Retention policy for log files. Can be an integer (number of files to keep), "
            "a string (e.g., '7 days'), or a timedelta object. "
            "Example: '7 days' or 5 (to keep the last 5 log files)."
        ),
    )
    log_rotation: Optional[int | str | time | timedelta] = Field(
        default=None,
        description=(
            "Rotation policy for log files. Can be an integer (size in bytes), a string "
            "(e.g., '00:00' for daily rotation at midnight), a time object, or a timedelta object. "
            "Example: '00:00' for daily rotation at midnight or 10485760 (to rotate after 10 MB)."
        ),
    )
    reload_staticdata: bool = Field(
        default=False,
        description="If true, static data will be reloaded at each time step",
    )
    start_hold_time: Optional[float] = Field(
        default=None, description="Time in seconds to hold the start of the service"
    )


class FiwareEnvVariables(BaseSettings):
    """
    Environment variables for FIWARE communication.
    They are automatically loaded from the environment or a .env file.

    Environment variables always have the prefix `FIWARE_`.
    """

    model_config = SettingsConfigDict(
        extra="ignore", env_file=".env", env_prefix="FIWARE_", case_sensitive=False
    )

    auth: bool = Field(
        default=False,
        description="Enables authentication for FIWARE requests",
    )
    client_id: Optional[str] = Field(
        default=None, description="Client ID for FIWARE authentication"
    )
    client_pw: Optional[str] = Field(
        default=None, description="Client password for FIWARE authentication"
    )
    token_url: Optional[AnyHttpUrl] = Field(
        default=None, description="Token URL for FIWARE authentication"
    )
    bearer_token: Optional[str] = Field(
        default=None, description="Bearer token for FIWARE authentication"
    )
    cb_url: Optional[AnyHttpUrl] = Field(
        default=AnyHttpUrl("http://127.0.0.1:1026"),
        description="URL of the Context Broker (e.g., Orion-LD)",
    )
    service: str = Field(..., description="FIWARE Service header for tenant isolation")
    service_path: str = Field(
        default="/", description="FIWARE Service Path for sub-tenant isolation"
    )

    crate_db_url: AnyHttpUrl = Field(
        default=AnyHttpUrl("http://127.0.0.1:4200"),
        description="URL of the CrateDB instance",
    )
    crate_db_user: str = Field(default="crate", description="Username for CrateDB")
    crate_db_pw: str = Field(
        default="", description="Password for CrateDB (empty = no authentication)"
    )
    crate_db_ssl: bool = Field(
        default=False, description="Enables SSL for the connection to CrateDB"
    )


class MQTTEnvVariables(BaseSettings):
    """
    MQTT environment variables for the service.
    They are automatically loaded from the environment or a .env file.

    Environment variables always have the prefix `MQTT_`.
    """

    model_config = SettingsConfigDict(
        extra="ignore", env_file=".env", env_prefix="MQTT_", case_sensitive=False
    )

    host: str = Field(
        default="127.0.0.1", description="Hostname or IP address of the MQTT broker"
    )
    port: int = Field(default=1883, description="Port number of the MQTT broker")
    username: Optional[str] = Field(
        default="", description="Username for MQTT broker authentication"
    )
    password: Optional[str] = Field(
        default="", description="Password for MQTT broker authentication"
    )
    topic_prefix: str = Field(
        default="", description="Prefix for all MQTT topics used by the service"
    )
    timestamp_key: str = Field(
        default="TimeInstant",
        description=(
            "Key name in the MQTT message payload that contains the timestamp. "
            "Examples: 'TimeInstant' (default), 'timestamp', 'time'. "
            "If the key is not present in the payload, "
            "the timestamp of the MQTT message receipt will be used."
        ),
    )
    tls_enabled: bool = Field(
        default=False,
        description="Enable TLS/SSL encryption for MQTT connection",
    )
    tls_ca_cert: Optional[str] = Field(
        default=None,
        description=(
            "Path to the CA certificate file for TLS/SSL verification. "
            "Optional - if not provided, system default certificates are used. "
            "Only needed for self-signed or custom CA certificates."
        ),
    )
    tls_insecure: bool = Field(
        default=False,
        description=(
            "Set to True to disable certificate verification (insecure). "
            "Only use for testing purposes."
        ),
    )
    publish_delay: float = Field(
        default=0.0,
        description=(
            "Delay in seconds before publishing MQTT messages. "
            "Can be used to give slow clients sufficient time to receive everything. "
            "Be careful when using this option, as unexpected behaviour may occur if the "
            "delay of all messages is longer than the sampling time."
        ),
    )


class FileEnvVariables(BaseSettings):
    """
    File environment variables for the service.
    They are automatically loaded from the environment or a .env file.

    Environment variables always have the prefix `FILE_`.
    """

    model_config = SettingsConfigDict(
        extra="ignore", env_file=".env", env_prefix="FILE_", case_sensitive=False
    )

    storage_method: FileStorageMethod = Field(
        default=FileStorageMethod.APPEND,
        description="""Type of file storage: 'overwrite', 'append', or 'new_file',
        see FileStorageMethod enum for details""",
    )

    path_of_input_file: str = Field(
        default="./input/input_file.csv", description="Path to the input CSV file"
    )
    path_of_static_data: str = Field(
        default="./input/static_data.json",
        description="Path to the static data JSON file",
    )
    path_of_results: str = Field(
        default="./results", description="Directory path to store the results"
    )
