# AGENTS.md

This file gives AI coding agents the minimum repo-specific context needed to work effectively in `appliku-cli`.

## Project Overview

`appliku-cli` is a Python package that exposes:

- a Typer-based CLI under the `appliku` command
- a small hand-written SDK surface built on top of generated OpenAPI client code

The canonical API schema is:

- `https://api.appliku.com/api/schema/`

This repo uses **uv** for dependency management and command execution.

## Tooling Rules

- Use `uv`, not `pip`, for local project work.
- Use `uv sync` to create/update the environment.
- Use `uv run ...` for commands inside the project environment.
- `pyproject.toml` is the source of truth for dependencies and tool config.
- The build backend is `hatchling`.

If `uv` fails in sandboxed environments because it tries to write to the default cache, use:

```bash
UV_CACHE_DIR=/tmp/uv-cache uv run ...
```

## Current Repository Layout

The old docs referenced files that no longer exist, especially `_client.py`. The actual structure is:

```text
.
├── AGENTS.md
├── README.md
├── pyproject.toml
├── spec.md
├── scripts/
│   └── codegen.sh
├── src/appliku/
│   ├── __init__.py
│   ├── _auth.py
│   ├── _exceptions.py
│   ├── _main.py
│   ├── _models.py
│   ├── _generated/
│   │   ├── api/
│   │   ├── client.py
│   │   ├── errors.py
│   │   ├── models/
│   │   └── types.py
│   ├── cli/
│   │   ├── __init__.py
│   │   ├── apps.py
│   │   ├── auth.py
│   │   ├── clusters.py
│   │   ├── cron_jobs.py
│   │   ├── datastores.py
│   │   ├── deployments.py
│   │   ├── domains.py
│   │   ├── invites.py
│   │   ├── migrations.py
│   │   ├── servers.py
│   │   ├── teams.py
│   │   └── volumes.py
│   └── resources/
│       ├── __init__.py
│       ├── _base.py
│       ├── apps.py
│       ├── clusters.py
│       ├── cron_jobs.py
│       ├── datastores.py
│       ├── deployments.py
│       ├── domains.py
│       ├── invites.py
│       ├── migrations.py
│       ├── servers.py
│       ├── teams.py
│       └── volumes.py
└── tests/
    ├── conftest.py
    └── test_auth.py
```

## Architecture

### Hand-written SDK layer

Core hand-written files:

- `src/appliku/_main.py`
  - Defines `Appliku`, the main SDK entry point.
  - Lazily instantiates resource objects.
  - Uses `AuthenticatedClient` from generated code.
- `src/appliku/_auth.py`
  - Token resolution and config persistence.
  - Browser-based device auth flow for CLI login.
- `src/appliku/_exceptions.py`
  - Typed exception hierarchy and response-to-exception mapping.
- `src/appliku/_models.py`
  - Generated Pydantic models from the schema, but treated as the SDK-facing model module.
- `src/appliku/resources/*.py`
  - Thin wrappers around generated endpoint functions.
  - Convert generated models into Pydantic models from `_models.py`.

### Generated layer

Generated code lives under `src/appliku/_generated/`.

- `src/appliku/_generated/client.py`
  - OpenAPI client used by the hand-written SDK.
- `src/appliku/_generated/api/`
  - Endpoint functions grouped by tag/path.
- `src/appliku/_generated/models/`
  - Generated request/response data classes.

Do not hand-edit generated files unless the task explicitly requires it. Prefer regenerating with:

```bash
./scripts/codegen.sh
```

### CLI layer

- `src/appliku/cli/__init__.py`
  - Creates the root Typer app.
  - Registers all subcommands.
  - Contains shared output helpers.
- `src/appliku/cli/auth.py`
  - Registers root commands: `login`, `logout`, `whoami`.
- Other files in `src/appliku/cli/`
  - Each defines one Typer sub-app for a resource area.

## Authentication Behavior

Token resolution order is:

1. explicit `Appliku(token=...)`
2. `APPLIKU_TOKEN` environment variable
3. `~/.config/appliku/config.toml`

The CLI login flow is not email/password. It is:

1. `appliku login`
2. device authorization starts via `/api/cli/auth/initiate/`
3. browser opens to authorize the session
4. CLI polls `/api/cli/auth/poll/`
5. received API token is saved to `~/.config/appliku/config.toml`

There is also direct token login:

```bash
appliku login --token YOUR_API_TOKEN
```

## Current Public Surface

Document and test against what is actually implemented, not what the schema might support.

### Implemented SDK resource properties

`Appliku` currently exposes:

- `apps`
- `teams`
- `deployments`
- `datastores`
- `domains`
- `volumes`
- `cron_jobs`
- `clusters`
- `servers`
- `invites`
- `migrations`

### Implemented CLI command groups

Root commands:

- `login`
- `logout`
- `whoami`

Subcommands:

- `apps`
- `clusters`
- `crons`
- `datastores`
- `deployments`
- `domains`
- `invites`
- `migrations`
- `servers`
- `teams`
- `volumes`

### Important limitation

The SDK/resources already implement more operations than the CLI exposes.

Examples:

- `AppsResource` supports `get`, `create`, `update`, `delete`, `deploy`, config var methods, `get_logs`, `get_service_logs`.
- `CronJobsResource` supports `create` and `update`.
- `VolumesResource` supports `create` and `update`.
- `ClustersResource` supports `create` and `get`.

But the current CLI only exposes a smaller subset of these operations. Do not assume CLI parity with the SDK.

## Command Map

Current CLI commands by file:

- `src/appliku/cli/apps.py`
  - `apps list`
  - `apps logs`
  - `apps service-logs`
- `src/appliku/cli/teams.py`
  - `teams list`
  - `teams get`
- `src/appliku/cli/deployments.py`
  - `deployments list`
  - `deployments latest`
  - `deployments logs`
- `src/appliku/cli/datastores.py`
  - `datastores list`
  - `datastores delete`
  - `datastores start`
  - `datastores stop`
  - `datastores restart`
- `src/appliku/cli/domains.py`
  - `domains list`
  - `domains create`
  - `domains delete`
- `src/appliku/cli/volumes.py`
  - `volumes list`
  - `volumes delete`
- `src/appliku/cli/cron_jobs.py`
  - `crons list`
  - `crons delete`
- `src/appliku/cli/clusters.py`
  - `clusters list`
  - `clusters delete`
- `src/appliku/cli/servers.py`
  - `servers list`
  - `servers get`
- `src/appliku/cli/invites.py`
  - `invites list`
  - `invites delete`
- `src/appliku/cli/migrations.py`
  - `migrations list`
  - `migrations logs`

## Application Log Commands

There are two distinct log endpoints for applications, each with different mechanics.

### `apps logs` — advanced (application-level) logs

Two-step async flow implemented in `AppsResource.get_logs()`:

1. **POST** `/api/team/{team_path}/applications/{id}/request_advanced_logs`
   - Body: `{"process": "web"}` or multi-process: `{"process": "celery celery_stats", "tail": 100}`
   - Returns `{"request_id": 1775644231.187654}`
2. **Poll GET** `/api/team/{team_path}/applications/{id}/retrieve_advanced_logs/{request_id}`
   - While `logs` is `null`, the server is still gathering (`status` shows progress)
   - When ready, `logs` contains the HTML-formatted output

**Important codegen bug**: the generated `team_applications_request_advanced_logs_create` endpoint has three identical `isinstance` checks for the request body, causing all three content-type branches (JSON, form, multipart) to run — the last one (multipart) always wins and breaks the request. `get_logs()` bypasses this by calling the httpx client directly with `json=` instead of using the generated function.

Multiple processes are space-separated in a single string: `"celery celery_stats"`. The CLI `--process` flag is repeatable and joins them before sending.

### `apps service-logs` — service-level logs

Single GET request implemented in `AppsResource.get_service_logs()`:

- **GET** `/api/team/{team_path}/applications/{id}/service_logs/{service}/{tail}`
- `service` is a single process name as defined in the app's Processes config (e.g. `web`, `celery`) — only one per request
- `tail` is the number of lines (default 100)
- Returns immediately with HTML-formatted logs in the `logs` field

The generated `team_applications_service_logs_retrieve` endpoint works correctly and is used directly.

### HTML stripping

Both log methods return HTML (ansi2html format). The `_HTMLStripper` class in `src/appliku/resources/apps.py` strips all tags while skipping `<style>`, `<script>`, and `<head>` content. Log commands output raw text via `typer.echo()` rather than Rich tables.

## Output Conventions

- CLI output defaults to Rich tables.
- Most list/read commands accept `--output json`.
- Shared rendering helpers live in `src/appliku/cli/__init__.py`.

When adding a new CLI command, follow the existing pattern:

1. call the relevant SDK resource
2. normalize objects into `list[dict[str, Any]]`
3. render with `render_output(...)`

## Testing

Current tests are minimal and focused on auth:

- `tests/test_auth.py`
- `tests/conftest.py`

Testing notes:

- `tests/conftest.py` provides `mock_client`, backed by `httpx.MockTransport`.
- Push `httpx.Response` objects into the shared `responses` list before SDK calls.
- `paginated_response()` builds the standard paginated response envelope.

When adding SDK/resource behavior, prefer unit tests using `mock_client` and avoid real network access.

## Regeneration Workflow

Schema-driven files are produced by `scripts/codegen.sh`:

1. generate Pydantic models into `src/appliku/_models.py`
2. generate OpenAPI client code into `src/appliku/_generated/`

If the schema changes:

- regenerate first
- then update hand-written resource wrappers or CLI code
- then update docs/tests as needed

## Practical Guidance For Agents

- Read the target CLI/resource file before changing docs or adding commands.
- Do not assume methods documented in old README or old CLAUDE/AGENTS text still exist.
- Prefer editing hand-written files in `src/appliku/cli/`, `src/appliku/resources/`, `_main.py`, `_auth.py`, `_exceptions.py`, and docs.
- Treat `src/appliku/_generated/` and large parts of `_models.py` as generated artifacts.
- If you add a new CLI command, also decide whether README and tests need to be updated in the same change.
