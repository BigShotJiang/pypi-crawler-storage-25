import pytest

from filedge.config import CdcConfig, ColumnMapping, PipelineConfig
from filedge.connectors.sqlite import SQLiteConnector
from filedge.connectors import SchemaError


@pytest.fixture
def config():
    return PipelineConfig(
        format="csv",
        dest_table="orders",
        columns=[
            ColumnMapping(source="name", dest="name", type="string", required=True),
            ColumnMapping(source="amount", dest="amount", type="float", required=True),
        ],
    )


@pytest.fixture
def connector(tmp_path, config):
    url = f"sqlite:///{tmp_path}/dest.db"
    c = SQLiteConnector(url=url, write_mode="append", batch_size=100)
    yield c
    c.close()


def _row_count(connector, table):
    return connector._get_conn().execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]


def _all_rows(connector, table):
    return connector._get_conn().execute(f"SELECT * FROM {table}").fetchall()


def test_ensure_table_creates_table_with_provenance(connector, config):
    connector.ensure_table(config)
    cols = {
        row[1]
        for row in connector._get_conn().execute("PRAGMA table_info(orders)").fetchall()
    }
    assert "name" in cols
    assert "amount" in cols
    assert "_source_file_hash" in cols
    assert "_ingested_at" in cols


def test_ensure_table_is_idempotent(connector, config):
    connector.ensure_table(config)
    connector.ensure_table(config)  # must not raise


def test_ensure_table_raises_schema_error_on_mismatch(connector, config):
    connector.ensure_table(config)
    config.columns.append(
        ColumnMapping(source="extra", dest="extra", type="string", required=True)
    )
    with pytest.raises(SchemaError, match="extra"):
        connector.ensure_table(config)


def test_ensure_table_raises_schema_error_on_type_mismatch(connector, config):
    conn = connector._get_conn()
    conn.execute(
        "CREATE TABLE orders ("
        "_id INTEGER PRIMARY KEY, "
        "name TEXT, "
        "amount TEXT, "
        "_source_file_hash TEXT NOT NULL, "
        "_ingested_at TEXT NOT NULL"
        ")"
    )
    conn.commit()

    with pytest.raises(SchemaError, match="amount.*TEXT.*REAL"):
        connector.ensure_table(config)


def test_ensure_table_raises_schema_error_on_extra_live_column(connector, config):
    connector.ensure_table(config)
    connector._get_conn().execute("ALTER TABLE orders ADD COLUMN stale TEXT")
    connector._get_conn().commit()

    with pytest.raises(SchemaError, match="stale.*not declared"):
        connector.ensure_table(config)


def test_write_rows_append_inserts_rows(connector, config):
    connector.ensure_table(config)
    rows = [{"name": "Alice", "amount": 10.0}, {"name": "Bob", "amount": 20.0}]
    connector.write_rows("orders", iter(rows), "hash1")
    assert _row_count(connector, "orders") == 2


def test_write_rows_append_idempotent_for_same_hash(connector, config):
    connector.ensure_table(config)
    rows = [{"name": "Alice", "amount": 10.0}]
    connector.write_rows("orders", iter(rows), "hash1")
    connector.write_rows("orders", iter(rows), "hash1")  # retry — same hash
    assert _row_count(connector, "orders") == 1


def test_write_rows_append_accumulates_different_hashes(connector, config):
    connector.ensure_table(config)
    connector.write_rows("orders", iter([{"name": "Alice", "amount": 1.0}]), "hash1")
    connector.write_rows("orders", iter([{"name": "Bob", "amount": 2.0}]), "hash2")
    assert _row_count(connector, "orders") == 2


def test_write_rows_truncate_replaces_rows(connector, config):
    url = f"sqlite:///{pytest.importorskip('tempfile').mkdtemp()}/trunc.db"
    tc = SQLiteConnector(url=url, write_mode="truncate", batch_size=100)
    tc.ensure_table(config)
    tc.write_rows("orders", iter([{"name": "Alice", "amount": 1.0}]), "hash1")
    assert _row_count(tc, "orders") == 1
    tc.write_rows("orders", iter([{"name": "Bob", "amount": 2.0}, {"name": "Carol", "amount": 3.0}]), "hash2")
    assert _row_count(tc, "orders") == 2  # Alice gone, Bob+Carol present
    tc.close()


def test_write_rows_rollback_on_error(connector, config):
    connector.ensure_table(config)

    def bad_iter():
        yield {"name": "Alice", "amount": 1.0}
        raise ValueError("injected error")

    with pytest.raises(ValueError):
        connector.write_rows("orders", bad_iter(), "hash1")

    assert _row_count(connector, "orders") == 0


def test_provenance_columns_set_correctly(connector, config):
    connector.ensure_table(config)
    connector.write_rows("orders", iter([{"name": "Alice", "amount": 5.0}]), "myhash")
    row = connector._get_conn().execute(
        "SELECT _source_file_hash, _ingested_at FROM orders"
    ).fetchone()
    assert row[0] == "myhash"
    assert row[1] is not None


def test_write_cdc_rows_applies_insert_update_delete(tmp_path):
    config = PipelineConfig(
        format="ndjson",
        dest_table="customers",
        write_mode="cdc",
        columns=[
            ColumnMapping("customer_id", "customer_id", "string", True),
            ColumnMapping("email", "email", "string", False),
            ColumnMapping("updated_at", "updated_at", "timestamp", True),
        ],
        cdc=CdcConfig(
            keys=["customer_id"],
            operation_column="op",
            sequence_by="updated_at",
            operations={
                "insert": ["c"],
                "update": ["u"],
                "delete": ["d"],
            },
        ),
    )
    connector = SQLiteConnector(
        url=f"sqlite:///{tmp_path}/cdc.db", write_mode="cdc", batch_size=100
    )
    connector.ensure_table(config)

    connector.write_cdc_rows(
        "customers",
        iter(
            [
                {
                    "customer_id": "c1",
                    "email": "old@example.com",
                    "updated_at": "2026-05-01T00:00:00",
                    "op": "c",
                },
                {
                    "customer_id": "c1",
                    "email": "new@example.com",
                    "updated_at": "2026-05-02T00:00:00",
                    "op": "u",
                },
                {
                    "customer_id": "c2",
                    "email": "gone@example.com",
                    "updated_at": "2026-05-03T00:00:00",
                    "op": "c",
                },
                {
                    "customer_id": "c2",
                    "email": "gone@example.com",
                    "updated_at": "2026-05-04T00:00:00",
                    "op": "d",
                },
            ]
        ),
        "hash1",
        config.cdc,
    )

    rows = connector._get_conn().execute(
        "SELECT customer_id, email, _source_file_hash FROM customers ORDER BY customer_id"
    ).fetchall()
    assert rows == [("c1", "new@example.com", "hash1")]
    connector.close()


def test_reserved_keyword_column_name(tmp_path):
    """SQLite reserved words like 'Index' must be quoted in DDL and DML."""
    config = PipelineConfig(
        format="csv",
        dest_table="items",
        columns=[ColumnMapping(source="Index", dest="Index", type="integer", required=True)],
    )
    connector = SQLiteConnector(url=f"sqlite:///{tmp_path}/kw.db", write_mode="append", batch_size=100)
    connector.ensure_table(config)
    connector.write_rows("items", iter([{"Index": 1}]), "h1")
    row = connector._get_conn().execute("SELECT \"Index\" FROM items").fetchone()
    assert row == (1,)
    connector.close()


def test_column_names_with_spaces(tmp_path):
    """Column names containing spaces must be quoted in DDL and DML."""
    config = PipelineConfig(
        format="csv",
        dest_table="customers",
        columns=[
            ColumnMapping(source="Customer Id", dest="Customer Id", type="string", required=True),
            ColumnMapping(source="First Name", dest="First Name", type="string", required=True),
        ],
    )
    connector = SQLiteConnector(url=f"sqlite:///{tmp_path}/spaces.db", write_mode="append", batch_size=100)
    connector.ensure_table(config)
    connector.write_rows("customers", iter([{"Customer Id": "C1", "First Name": "Alice"}]), "h1")
    row = connector._get_conn().execute(
        "SELECT \"Customer Id\", \"First Name\" FROM customers"
    ).fetchone()
    assert row == ("C1", "Alice")
    connector.close()


def test_write_cdc_rows_is_idempotent_for_same_hash(tmp_path):
    config = PipelineConfig(
        format="ndjson",
        dest_table="customers",
        write_mode="cdc",
        columns=[
            ColumnMapping("customer_id", "customer_id", "string", True),
            ColumnMapping("email", "email", "string", False),
            ColumnMapping("updated_at", "updated_at", "timestamp", True),
        ],
        cdc=CdcConfig(
            keys=["customer_id"],
            operation_column="op",
            sequence_by="updated_at",
            operations={"insert": ["c"], "update": ["u"], "delete": ["d"]},
        ),
    )
    connector = SQLiteConnector(
        url=f"sqlite:///{tmp_path}/cdc_retry.db", write_mode="cdc", batch_size=100
    )
    connector.ensure_table(config)
    rows = [
        {
            "customer_id": "c1",
            "email": "new@example.com",
            "updated_at": "2026-05-02T00:00:00",
            "op": "u",
        }
    ]

    connector.write_cdc_rows("customers", iter(rows), "hash1", config.cdc)
    connector.write_cdc_rows("customers", iter(rows), "hash1", config.cdc)

    assert _row_count(connector, "customers") == 1
    row = connector._get_conn().execute(
        "SELECT customer_id, email, _source_file_hash FROM customers"
    ).fetchone()
    assert row == ("c1", "new@example.com", "hash1")
    connector.close()
