# getstack (Python SDK)

Published to PyPI as `getstack`. Not a workspace member of the main monorepo
(Python has its own tooling via `pyproject.toml` + its own tests).

## Purpose

- Python ergonomic equivalent of `@getstackrun/sdk`
- `with stack.passports.mission(...) as m:` context manager that handles
  checkpoints + checkout automatically
- Same RESTful coverage: agents, passports, services, credentials, drop-offs,
  skills, identity, audit, notifications, security-events, proxy

## Where to look

- Package metadata: `sdk-python/pyproject.toml`
- Module entry: `sdk-python/src/getstack/`
- User-facing quickstart + examples: `sdk-python/README.md`
- License: `sdk-python/LICENSE`

## Key divergence from JS SDK

The Python SDK has a **mission context manager** the JS SDK doesn't have:

```python
with stack.passports.mission(
    agent_id=agent.id,
    intent="Process invoices from Slack",
    services=["slack", "stripe"],
    checkpoint_interval="5m",
) as mission:
    mission.log("slack", "read_channel", "#invoices")
    mission.log("stripe", "create_invoice")
    # Checkpoints submitted automatically on schedule
# Checkout submitted automatically when the block exits
```

When the JS SDK adds an equivalent, align the shape (same keyword args,
same method names) for cross-language familiarity.

## Gotchas

- **Not installed by `npm install` at monorepo root.** Python devs run `pip install -e sdk-python/` or `uv pip install -e sdk-python/`. The JS monorepo lockfile does not resolve Python deps.
- **Published to PyPI separately.** There's no coordinated release between the JS + Python SDKs; they can (and sometimes do) drift in version numbers.
- **Same authentication posture.** API keys, session JWTs, and the same `sk_live_*` prefix convention. Token type detection works identically to JS.
- **Offline passport verification is also available** (mirrors `verify_passport_offline` from the JS SDK) — but confirm the exact function name in `sdk-python/src/getstack/` before citing.
