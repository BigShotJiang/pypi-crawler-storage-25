"""STACK SDK type definitions."""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any


@dataclass
class Agent:
    id: str
    operator_id: str
    name: str
    description: str | None
    status: str
    accountability_mode: str
    on_warning: str
    on_critical: str
    passport_blocked: bool
    passport_blocked_reason: str | None
    passport_blocked_at: str | None
    created_at: str
    updated_at: str


@dataclass
class Passport:
    token: str
    jti: str
    expires_at: str
    accountability: str | None = None


@dataclass
class CheckpointResult:
    checkpoint_id: str
    passport_jti: str
    new_expires_at: str | None = None
    flags: list[str] | None = None


@dataclass
class CheckoutResult:
    checkout_id: str
    passport_jti: str
    review_status: str  # clean | flagged | blocked
    flags: list[dict[str, str]] | None = None


@dataclass
class ReviewFlag:
    type: str
    severity: str
    message: str


@dataclass
class PassportReport:
    passport: dict[str, Any]
    intent: dict[str, Any] | None
    checkpoints: list[dict[str, Any]]
    checkout: dict[str, Any] | None
    review: dict[str, Any] | None


@dataclass
class ReviewQueueItem:
    checkout_id: str
    passport_jti: str
    agent_id: str
    agent_name: str
    intent_summary: str
    review_status: str
    flags: list[dict[str, str]]
    submitted_at: str


@dataclass
class ReviewQueue:
    items: list[ReviewQueueItem]
    total: int


@dataclass
class ReviewDecisionResult:
    review_id: str
    agent_id: str
    decision: str
    passport_blocked: bool


@dataclass
class Credential:
    provider: str
    credential: str | None = None
    credentials: dict[str, str] | None = None


@dataclass
class Service:
    id: str
    provider: str
    name: str
    description: str
    available: bool = True


@dataclass
class ServiceConnection:
    id: str
    provider: str
    status: str
    connected_at: str


@dataclass
class Dropoff:
    id: str
    from_agent_id: str
    to_agent_id: str
    status: str
    created_at: str
    expires_at: str


@dataclass
class NotificationChannel:
    id: str
    channel_type: str
    destination: str
    events: list[str]
    min_severity: str
    active: bool
    verified: bool


@dataclass
class AuditEntry:
    entry_id: str
    action: str
    outcome: str
    timestamp: int
    agent_id: str


@dataclass
class ToolCall:
    """A single tool call logged during a mission."""
    service: str
    method: str
    target: str | None = None

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"service": self.service, "method": self.method}
        if self.target:
            d["target"] = self.target
        return d


# ─── Skills ──────────────────────────────────────────────────────────


@dataclass
class Skill:
    id: str
    operator_id: str
    name: str
    description: str
    version: str = "1.0.0"
    tags: list[str] = field(default_factory=list)
    trust_level_required: str = "L0"
    status: str = "active"
    execution_mode: str = "open"
    price_per_invocation: int = 0
    invocation_count: int = 0
    created_at: str = ""
    updated_at: str = ""


@dataclass
class SkillInvocation:
    id: str
    skill_id: str
    status: str
    output: Any = None
    error: dict[str, str] | None = None
    expires_at: str = ""
    created_at: str = ""
    started_at: str | None = None
    completed_at: str | None = None
    llm_tokens_input: int | None = None
    llm_tokens_output: int | None = None
    execution_duration_ms: int | None = None


@dataclass
class SkillRequest:
    id: str
    operator_id: str
    description: str
    desired_input_schema: dict[str, Any] | None = None
    desired_output_schema: dict[str, Any] | None = None
    max_price_cents: int | None = None
    tags: list[str] = field(default_factory=list)
    status: str = "open"
    created_at: str = ""


# ─── Identity ────────────────────────────────────────────────────────


@dataclass
class IdentityProvider:
    key: str
    name: str
    layers: list[str] = field(default_factory=list)
    assurance: str = ""
    description: str = ""


@dataclass
class IdentityClaim:
    id: str
    operator_id: str
    provider_key: str
    layer: str
    claim_type: str
    claim_ref: str
    assurance_level: str
    verified_at: str
    expires_at: str | None = None


@dataclass
class IdentitySettings:
    identity_claim_ttl: str  # 30d | 90d | 180d | 1y
    identity_claim_inheritance: str  # auto | opt_in
    identity_auto_revoke: bool


@dataclass
class VerificationSession:
    session_ref: str
    authorization_url: str | None = None
    status: str = "pending"
