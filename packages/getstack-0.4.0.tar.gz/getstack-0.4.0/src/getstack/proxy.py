"""Credential proxy — send requests through STACK without seeing secrets."""

from __future__ import annotations

from typing import Any

from .client import HttpClient


class ProxyResponse:
    """Response from a proxied request."""

    __slots__ = ("status", "headers", "body")

    def __init__(self, status: int, headers: dict[str, str], body: Any):
        self.status = status
        self.headers = headers
        self.body = body

    def ok(self) -> bool:
        return 200 <= self.status < 400

    def json(self) -> Any:
        return self.body

    def __repr__(self) -> str:
        return f"ProxyResponse(status={self.status})"


class ProxyService:
    def __init__(self, client: HttpClient):
        self._client = client

    def request(
        self,
        service: str,
        url: str,
        method: str = "GET",
        *,
        headers: dict[str, str] | None = None,
        body: Any | None = None,
        query: dict[str, str] | None = None,
        passport_token: str | None = None,
    ) -> ProxyResponse:
        """Send a request through STACK's credential proxy.

        Args:
            service: Provider slug (e.g. "openai", "slack").
            url: Full target URL.
            method: HTTP method.
            headers: Extra headers (auth headers will be stripped).
            body: Request body.
            query: Query parameters.
            passport_token: Passport JWT (required).
        """
        extra_headers = {}
        if passport_token:
            extra_headers["X-Passport-Token"] = passport_token

        payload: dict[str, Any] = {
            "service": service,
            "url": url,
            "method": method,
        }
        if headers:
            payload["headers"] = headers
        if body is not None:
            payload["body"] = body
        if query:
            payload["query"] = query

        data = self._client.request(
            "POST",
            "/v1/proxy",
            json=payload,
            extra_headers=extra_headers if extra_headers else None,
        )
        return ProxyResponse(
            status=data.get("status", 0),
            headers=data.get("headers", {}),
            body=data.get("body"),
        )

    def get(self, service: str, url: str, **kwargs) -> ProxyResponse:
        """GET through proxy."""
        return self.request(service, url, "GET", **kwargs)

    def post(self, service: str, url: str, **kwargs) -> ProxyResponse:
        """POST through proxy."""
        return self.request(service, url, "POST", **kwargs)

    def put(self, service: str, url: str, **kwargs) -> ProxyResponse:
        """PUT through proxy."""
        return self.request(service, url, "PUT", **kwargs)

    def patch(self, service: str, url: str, **kwargs) -> ProxyResponse:
        """PATCH through proxy."""
        return self.request(service, url, "PATCH", **kwargs)

    def delete(self, service: str, url: str, **kwargs) -> ProxyResponse:
        """DELETE through proxy."""
        return self.request(service, url, "DELETE", **kwargs)

    def usage(self) -> dict:
        """Get monthly proxy usage stats.

        Returns dict with: tier, limit, used, remaining, period.
        """
        return self._client.request("GET", "/v1/proxy/usage")
