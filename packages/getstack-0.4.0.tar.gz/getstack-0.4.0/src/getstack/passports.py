"""Passport management with mission context manager and continuous rotation."""

from __future__ import annotations

import re
import time
import threading
from contextlib import contextmanager
from typing import Any, Generator

from .client import HttpClient
from .proxy import ProxyService, ProxyResponse
from .types import Passport, CheckpointResult, CheckoutResult, PassportReport, ToolCall


def _parse_duration(s: str) -> int:
    """Parse a duration string like '30m', '2h', '300' to seconds."""
    match = re.match(r"^(\d+)(s|m|h)$", s)
    if match:
        num, unit = int(match.group(1)), match.group(2)
        return num * {"s": 1, "m": 60, "h": 3600}[unit]
    return int(s)


def _to_passport(data: dict[str, Any]) -> Passport:
    return Passport(
        token=data["token"],
        jti=data["jti"],
        expires_at=data["expires_at"],
        accountability=data.get("accountability"),
    )


class Mission:
    """A bounded accountability window for an agent mission.

    Tracks tool calls, submits checkpoints on schedule, and checks out
    automatically when the context manager exits.
    """

    def __init__(
        self,
        service: PassportService,
        agent_id: str,
        intent: str,
        services: list[str],
        will_delegate: bool = False,
        estimated_duration: str | None = None,
        checkpoint_interval: str | None = None,
    ):
        self._service = service
        self._agent_id = agent_id
        self._intent = intent
        self._declared_services = services
        self._will_delegate = will_delegate
        self._estimated_duration = estimated_duration
        self._checkpoint_interval = checkpoint_interval

        self.passport: Passport | None = None
        self.review_status: str | None = None
        self.result: CheckoutResult | None = None
        self.rotation_count: int = 0

        self._tool_calls: list[ToolCall] = []
        self._services_used: set[str] = set()
        self._delegated_to: list[str] = []
        self._last_checkpoint_index: int = 0
        self._timer: threading.Timer | None = None
        self._timer_interval: float | None = None
        self._rotation_start: float = 0
        self._rotation_interval: float | None = None

    @property
    def should_rotate(self) -> bool:
        """True when the rotation interval has elapsed. Check at natural breakpoints."""
        if self._rotation_interval is None:
            return False
        return time.monotonic() - self._rotation_start >= self._rotation_interval

    def log(self, service: str, method: str, target: str | None = None) -> None:
        """Log a tool call. Call this for each action the agent takes."""
        self._tool_calls.append(ToolCall(service=service, method=method, target=target))
        self._services_used.add(service)

    def delegate(self, child_agent_id: str) -> None:
        """Record that delegation occurred to a child agent."""
        self._delegated_to.append(child_agent_id)

    @property
    def token(self) -> str | None:
        """Current passport token, for passing to credential retrieval."""
        return self.passport.token if self.passport else None

    def proxy(
        self,
        service: str,
        url: str,
        method: str = "GET",
        *,
        headers: dict[str, str] | None = None,
        body: Any = None,
        query: dict[str, str] | None = None,
        _proxy_service: ProxyService | None = None,
    ) -> ProxyResponse:
        """Send a request through STACK's credential proxy using this mission's passport.

        Requires passing the proxy service from the Stack client, or set it via
        ``mission._proxy = stack.proxy`` before calling.

        Args:
            service: Provider slug (e.g. "openai", "slack").
            url: Full target URL.
            method: HTTP method.
            headers: Extra headers (auth headers will be stripped).
            body: Request body.
            query: Query parameters.
            _proxy_service: ProxyService instance (falls back to self._proxy).
        """
        ps = _proxy_service or getattr(self, "_proxy", None)
        if ps is None:
            raise RuntimeError(
                "No proxy service available. Set mission._proxy = stack.proxy before calling proxy()."
            )
        resp = ps.request(
            service, url, method,
            headers=headers, body=body, query=query,
            passport_token=self.token,
        )
        self.log(service, method, url)
        return resp

    def _enter(self) -> None:
        """Issue passport and start checkpoint timer."""
        self.passport = self._service.issue(
            agent_id=self._agent_id,
            intent=self._intent,
            services=self._declared_services,
            will_delegate=self._will_delegate,
            estimated_duration=self._estimated_duration,
            checkpoint_interval=self._checkpoint_interval,
        )
        self._rotation_start = time.monotonic()

        # Start checkpoint timer for enforced mode
        if self._checkpoint_interval:
            self._timer_interval = _parse_duration(self._checkpoint_interval)
        elif self.passport.accountability == "enforced":
            self._timer_interval = 300  # 5 min default
        else:
            self._timer_interval = None

        if self._timer_interval:
            self._schedule_checkpoint()

    def _schedule_checkpoint(self) -> None:
        """Schedule the next automatic checkpoint."""
        if self._timer_interval:
            # Submit slightly before the interval to ensure we don't miss it
            delay = max(self._timer_interval - 5, 10)
            self._timer = threading.Timer(delay, self._auto_checkpoint)
            self._timer.daemon = True
            self._timer.start()

    def _auto_checkpoint(self) -> None:
        """Submit checkpoint and reschedule."""
        try:
            self._submit_checkpoint()
        except Exception:
            pass  # Don't crash the agent on checkpoint failure
        self._schedule_checkpoint()

    def _submit_checkpoint(self) -> None:
        """Submit accumulated activity as a checkpoint."""
        if not self.passport:
            return

        new_calls = self._tool_calls[self._last_checkpoint_index:]
        self._service.checkpoint(
            self.passport.jti,
            services_used=list(self._services_used),
            actions_count=len(new_calls),
            tool_calls=[tc.to_dict() for tc in new_calls] if new_calls else None,
            delegated_to=self._delegated_to if self._delegated_to else None,
        )
        self._last_checkpoint_index = len(self._tool_calls)

    def _exit(self, error: Exception | None = None) -> None:
        """Stop timer and submit checkout."""
        if self._timer:
            self._timer.cancel()
            self._timer = None

        if not self.passport:
            return

        summary = None
        if error:
            summary = f"Mission failed: {type(error).__name__}: {error}"

        try:
            self.result = self._service.checkout(
                self.passport.jti,
                services_used=list(self._services_used),
                actions_count=len(self._tool_calls),
                tool_calls=[tc.to_dict() for tc in self._tool_calls] if self._tool_calls else None,
                summary=summary,
                delegated_to=self._delegated_to if self._delegated_to else None,
            )
            self.review_status = self.result.review_status
        except Exception:
            pass  # Best-effort checkout

    def __enter__(self) -> Mission:
        self._enter()
        return self

    def __exit__(self, exc_type: type | None, exc_val: Exception | None, exc_tb: Any) -> bool:
        self._exit(error=exc_val if exc_type else None)
        return False  # Don't suppress exceptions


class PassportService:
    def __init__(self, client: HttpClient):
        self._client = client

    def issue(
        self,
        agent_id: str,
        intent: str | None = None,
        services: list[str] | None = None,
        will_delegate: bool = False,
        estimated_duration: str | None = None,
        checkpoint_interval: str | None = None,
        ttl_seconds: int | None = None,
        scopes: list[dict[str, Any]] | None = None,
    ) -> Passport:
        body: dict[str, Any] = {"agent_id": agent_id}
        if scopes:
            body["scopes"] = scopes
        if ttl_seconds:
            body["ttl_seconds"] = ttl_seconds
        if intent or services:
            body["intent"] = {
                "summary": intent or "",
                "services": services or [],
                "will_delegate": will_delegate,
            }
            if estimated_duration:
                body["intent"]["estimated_duration_seconds"] = _parse_duration(estimated_duration)
        if checkpoint_interval:
            body["checkpoint_interval_seconds"] = _parse_duration(checkpoint_interval)
        return _to_passport(self._client.post("/v1/passports/issue", json=body))

    def checkpoint(
        self,
        passport_jti: str,
        services_used: list[str],
        actions_count: int,
        tool_calls: list[dict[str, Any]] | None = None,
        summary: str | None = None,
        delegated_to: list[str] | None = None,
    ) -> CheckpointResult:
        body: dict[str, Any] = {
            "services_used": services_used,
            "actions_count": actions_count,
        }
        if tool_calls:
            body["tool_calls"] = tool_calls
        if summary:
            body["summary"] = summary
        if delegated_to:
            body["delegated_to"] = delegated_to
        data = self._client.post(f"/v1/passports/{passport_jti}/checkpoint", json=body)
        return CheckpointResult(
            checkpoint_id=data["checkpoint_id"],
            passport_jti=data["passport_jti"],
            new_expires_at=data.get("new_expires_at"),
            flags=data.get("flags"),
        )

    def checkout(
        self,
        passport_jti: str,
        services_used: list[str],
        actions_count: int,
        tool_calls: list[dict[str, Any]] | None = None,
        summary: str | None = None,
        delegated_to: list[str] | None = None,
    ) -> CheckoutResult:
        body: dict[str, Any] = {
            "services_used": services_used,
            "actions_count": actions_count,
        }
        if tool_calls:
            body["tool_calls"] = tool_calls
        if summary:
            body["summary"] = summary
        if delegated_to:
            body["delegated_to"] = delegated_to
        data = self._client.post(f"/v1/passports/{passport_jti}/checkout", json=body)
        return CheckoutResult(
            checkout_id=data["checkout_id"],
            passport_jti=data["passport_jti"],
            review_status=data["review_status"],
            flags=data.get("flags"),
        )

    def report(self, passport_jti: str) -> PassportReport:
        data = self._client.get(f"/v1/passports/{passport_jti}/report")
        return PassportReport(**data)

    def verify(self, token: str) -> dict[str, Any]:
        return self._client.post("/v1/passports/verify", json={"token": token})

    def revoke(self, jti: str, reason: str | None = None) -> dict[str, Any]:
        return self._client.post("/v1/passports/revoke", json={"jti": jti, "reason": reason})

    def refresh(self, token: str, ttl_seconds: int | None = None) -> Passport:
        body: dict[str, Any] = {"token": token}
        if ttl_seconds:
            body["ttl_seconds"] = ttl_seconds
        return _to_passport(self._client.post("/v1/passports/refresh", json=body))

    def list_active(self, agent_id: str | None = None, session_id: str | None = None) -> list[dict[str, Any]]:
        params: dict[str, str] = {}
        if agent_id:
            params["agent_id"] = agent_id
        if session_id:
            params["session_id"] = session_id
        return self._client.get("/v1/passports/active", params=params or None)

    @contextmanager
    def mission(
        self,
        agent_id: str,
        intent: str,
        services: list[str],
        will_delegate: bool = False,
        estimated_duration: str | None = None,
        checkpoint_interval: str | None = None,
    ) -> Generator[Mission, None, None]:
        """Context manager for a single bounded mission."""
        m = Mission(
            self, agent_id, intent, services,
            will_delegate=will_delegate,
            estimated_duration=estimated_duration,
            checkpoint_interval=checkpoint_interval,
        )
        m._enter()
        try:
            yield m
        except Exception as e:
            m._exit(error=e)
            raise
        else:
            m._exit()

    def continuous_mission(
        self,
        agent_id: str,
        intent: str,
        services: list[str],
        rotation_interval: str = "4h",
        will_delegate: bool = False,
        checkpoint_interval: str | None = None,
    ) -> Generator[Mission, None, None]:
        """Generator yielding successive Mission objects with automatic rotation.

        Each iteration issues a new passport, runs checkpoints, and checks out
        when the rotation interval elapses (signaled via mission.should_rotate).

        Usage::

            for mission in stack.passports.continuous_mission(
                agent_id="agt_...",
                intent="Monitor Slack",
                services=["slack"],
                rotation_interval="4h",
            ):
                while not mission.should_rotate:
                    event = wait_for_event()
                    mission.log("slack", "read_message")
                    process(event)
        """
        rotation_secs = _parse_duration(rotation_interval)
        rotation_count = 0

        while True:
            m = Mission(
                self, agent_id, intent, services,
                will_delegate=will_delegate,
                checkpoint_interval=checkpoint_interval,
            )
            m.rotation_count = rotation_count
            m._rotation_interval = rotation_secs

            m._enter()
            try:
                yield m
            finally:
                m._exit()

            rotation_count += 1
