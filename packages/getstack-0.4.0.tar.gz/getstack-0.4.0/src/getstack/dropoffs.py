"""Drop-off management."""

from __future__ import annotations

from typing import Any

from .client import HttpClient


class DropoffService:
    def __init__(self, client: HttpClient):
        self._client = client

    def create(
        self,
        from_agent_id: str,
        to_agent_id: str,
        schema: dict[str, Any],
        ttl_seconds: int | None = None,
        on_expire: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "from_agent": from_agent_id,
            "to_agent": to_agent_id,
            "schema": schema,
        }
        if ttl_seconds:
            body["ttl_seconds"] = ttl_seconds
        if on_expire:
            body["on_expire"] = on_expire
        return self._client.post("/v1/dropoffs", json=body)

    def deposit(self, dropoff_id: str, data: dict[str, Any], agent_id: str) -> dict[str, Any]:
        return self._client.post(f"/v1/dropoffs/{dropoff_id}/deposit", json={"agent_id": agent_id, "payload": data})

    def collect(self, dropoff_id: str, agent_id: str) -> dict[str, Any]:
        return self._client.post(f"/v1/dropoffs/{dropoff_id}/collect", json={"agent_id": agent_id})

    def get(self, dropoff_id: str) -> dict[str, Any]:
        return self._client.get(f"/v1/dropoffs/{dropoff_id}")

    def list(self) -> list[dict[str, Any]]:
        return self._client.get("/v1/dropoffs")
