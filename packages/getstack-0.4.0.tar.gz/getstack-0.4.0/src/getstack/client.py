"""HTTP client for the STACK API."""

from __future__ import annotations

from typing import Any

import httpx

from .auth import AuthStrategy
from .errors import raise_for_status

DEFAULT_BASE_URL = "https://api.getstack.run"


class HttpClient:
    """Synchronous HTTP client wrapping httpx."""

    def __init__(self, auth: AuthStrategy, base_url: str = DEFAULT_BASE_URL, timeout: float = 30.0):
        self.auth = auth
        self.base_url = base_url.rstrip("/")
        self._client = httpx.Client(timeout=timeout)

    def request(self, method: str, path: str, json: Any = None, params: dict[str, Any] | None = None, extra_headers: dict[str, str] | None = None) -> Any:
        headers = {
            "Content-Type": "application/json",
            **self.auth.get_headers(),
            **(extra_headers or {}),
        }

        url = f"{self.base_url}{path}"
        resp = self._client.request(method, url, json=json, params=params, headers=headers)

        if resp.status_code >= 400:
            try:
                body = resp.json()
            except Exception:
                body = {"error": {"message": resp.text}}
            raise_for_status(resp.status_code, body)

        if resp.status_code == 204:
            return None

        return resp.json()

    def get(self, path: str, params: dict[str, Any] | None = None, extra_headers: dict[str, str] | None = None) -> Any:
        return self.request("GET", path, params=params, extra_headers=extra_headers)

    def post(self, path: str, json: Any = None) -> Any:
        return self.request("POST", path, json=json)

    def patch(self, path: str, json: Any = None) -> Any:
        return self.request("PATCH", path, json=json)

    def delete(self, path: str) -> Any:
        return self.request("DELETE", path)

    def close(self) -> None:
        self._client.close()


class AsyncHttpClient:
    """Asynchronous HTTP client wrapping httpx."""

    def __init__(self, auth: AuthStrategy, base_url: str = DEFAULT_BASE_URL, timeout: float = 30.0):
        self.auth = auth
        self.base_url = base_url.rstrip("/")
        self._client = httpx.AsyncClient(timeout=timeout)

    async def request(self, method: str, path: str, json: Any = None, params: dict[str, Any] | None = None) -> Any:
        headers = {
            "Content-Type": "application/json",
            **self.auth.get_headers(),
        }

        url = f"{self.base_url}{path}"
        resp = await self._client.request(method, url, json=json, params=params, headers=headers)

        if resp.status_code >= 400:
            try:
                body = resp.json()
            except Exception:
                body = {"error": {"message": resp.text}}
            raise_for_status(resp.status_code, body)

        if resp.status_code == 204:
            return None

        return resp.json()

    async def get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        return await self.request("GET", path, params=params)

    async def post(self, path: str, json: Any = None) -> Any:
        return await self.request("POST", path, json=json)

    async def patch(self, path: str, json: Any = None) -> Any:
        return await self.request("PATCH", path, json=json)

    async def delete(self, path: str) -> Any:
        return await self.request("DELETE", path)

    async def close(self) -> None:
        await self._client.aclose()
