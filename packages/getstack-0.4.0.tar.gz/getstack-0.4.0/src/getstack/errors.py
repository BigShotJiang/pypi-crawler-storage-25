"""STACK SDK error classes."""

from __future__ import annotations


class StackError(Exception):
    """Base error for all STACK API errors."""

    def __init__(self, message: str, code: str = "UNKNOWN", status_code: int = 500, details: dict | None = None):
        super().__init__(message)
        self.code = code
        self.status_code = status_code
        self.details = details or {}


class NotFoundError(StackError):
    def __init__(self, message: str = "Resource not found"):
        super().__init__(message, "NOT_FOUND", 404)


class UnauthorizedError(StackError):
    def __init__(self, message: str = "Unauthorized"):
        super().__init__(message, "UNAUTHORIZED", 401)


class ForbiddenError(StackError):
    def __init__(self, message: str = "Forbidden"):
        super().__init__(message, "FORBIDDEN", 403)


class ValidationError(StackError):
    def __init__(self, message: str = "Validation failed", details: dict | None = None):
        super().__init__(message, "VALIDATION_ERROR", 400, details)


class PassportBlockedError(StackError):
    def __init__(self, message: str = "Agent is blocked from passport issuance"):
        super().__init__(message, "PASSPORT_BLOCKED", 403)


# Map HTTP status codes to error classes
_STATUS_MAP = {
    401: UnauthorizedError,
    403: ForbiddenError,
    404: NotFoundError,
}


def raise_for_status(status_code: int, body: dict) -> None:
    """Raise an appropriate StackError from an API error response."""
    error = body.get("error", {})
    message = error.get("message", f"API error: {status_code}")
    code = error.get("code", "UNKNOWN")

    cls = _STATUS_MAP.get(status_code, StackError)
    raise cls(message)
