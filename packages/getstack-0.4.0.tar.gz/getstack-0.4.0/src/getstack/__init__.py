"""STACK Python SDK — trust infrastructure for AI agents.

Usage::

    from getstack import Stack

    stack = Stack(api_key="sk_live_...")
    agent = stack.agents.register("my-agent")

    with stack.passports.mission(
        agent_id=agent.id,
        intent="Process invoices",
        services=["slack", "stripe"],
    ) as mission:
        mission.log("slack", "read_channel", "#invoices")
        mission.log("stripe", "create_invoice")

For OAuth auth::

    stack = Stack.from_oauth(
        client_id="...",
        client_secret="...",
        access_token="...",
        refresh_token="...",
    )

For async usage::

    from getstack import AsyncStack

    stack = AsyncStack(api_key="sk_live_...")
"""

from __future__ import annotations

import os

from .auth import ApiKeyAuth, SessionAuth, OAuthAuth, CredentialsFileAuth
from .agent_auth import AgentKeypairAuth
from .client import HttpClient, AsyncHttpClient, DEFAULT_BASE_URL
from .agents import AgentService
from .passports import PassportService, Mission
from .credentials import CredentialService
from .services import ServiceService
from .dropoffs import DropoffService
from .reviews import ReviewService
from .notifications import NotificationService
from .audit import AuditService
from .proxy import ProxyService as ProxySvc, ProxyResponse
from .scan import ScanService
from .security_events import SecurityEventService as SecurityEventSvc
from .skills import SkillService
from .identity import IdentityService
from .types import (
    Agent,
    Passport,
    CheckpointResult,
    CheckoutResult,
    ReviewFlag,
    PassportReport,
    ReviewQueue,
    ReviewQueueItem,
    ReviewDecisionResult,
    Credential,
    NotificationChannel,
    ToolCall,
    Skill,
    SkillInvocation,
    SkillRequest,
    IdentityProvider,
    IdentityClaim,
    IdentitySettings,
    VerificationSession,
)
from .errors import (
    StackError,
    NotFoundError,
    UnauthorizedError,
    ForbiddenError,
    ValidationError,
    PassportBlockedError,
)

__version__ = "0.2.0"


def _build_static_auth(
    *,
    api_key: str | None,
    base_url: str,
) -> ApiKeyAuth | CredentialsFileAuth:
    """Phase 2 helper. Resolve a static-bearer auth strategy for the
    one-time agent-enrollment dance — explicit api_key, STACK_API_KEY
    env var, or ~/.stack/credentials.json (CLI-managed OAuth refresh).
    """
    if api_key:
        return ApiKeyAuth(api_key)
    env_key = os.environ.get("STACK_API_KEY")
    if env_key:
        return ApiKeyAuth(env_key)
    return _resolve_creds_or_bootstrap(base_url)


def _resolve_creds_or_bootstrap(base_url: str) -> CredentialsFileAuth:
    """Read ~/.stack/credentials.json — and if it's missing AND the
    process looks interactive (TTY + not CI), spawn the browser-spawn
    OAuth bootstrap to create it. Raises ValueError when neither path
    resolves.
    """
    try:
        return CredentialsFileAuth(api_base_url=base_url)
    except RuntimeError:
        from .browser_bootstrap import browser_bootstrap, should_run_browser_bootstrap
        if should_run_browser_bootstrap():
            browser_bootstrap(base_url)
            try:
                return CredentialsFileAuth(api_base_url=base_url)
            except RuntimeError as e:
                raise ValueError(
                    "STACK SDK: browser bootstrap reported success but "
                    "credentials file still missing."
                ) from e
        raise ValueError(
            "No STACK credentials found. Pass api_key=, set "
            "STACK_API_KEY, or run `stack-cli auth login`."
        )

__all__ = [
    "Stack",
    "AsyncStack",
    "__version__",
    # Types
    "Agent",
    "Passport",
    "CheckpointResult",
    "CheckoutResult",
    "ReviewFlag",
    "PassportReport",
    "ReviewQueue",
    "ReviewQueueItem",
    "ReviewDecisionResult",
    "Credential",
    "NotificationChannel",
    "Mission",
    "ToolCall",
    "ProxyResponse",
    "Skill",
    "SkillInvocation",
    "SkillRequest",
    "IdentityProvider",
    "IdentityClaim",
    "IdentitySettings",
    "VerificationSession",
    # Errors
    "StackError",
    "NotFoundError",
    "UnauthorizedError",
    "ForbiddenError",
    "ValidationError",
    "PassportBlockedError",
]


class Stack:
    """Synchronous STACK client.

    Args:
        api_key: A STACK API key (``sk_live_...``).
        base_url: Override the API base URL.
        timeout: HTTP timeout in seconds.
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        agent_id: str | None = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
        _auth: ApiKeyAuth | SessionAuth | OAuthAuth | CredentialsFileAuth | AgentKeypairAuth | None = None,
    ):
        # Four-source resolution, in priority order:
        #   1. Explicit _auth (callers that pre-built a strategy).
        #   2. agent_id (Phase 2 — agent-keypair runtime mode). Static
        #      bearer is auto-resolved for enrollment via api_key/env/file.
        #   3. api_key arg or STACK_API_KEY env var (legacy sk_live_*).
        #   4. ~/.stack/credentials.json — OAuth refresh token written
        #      by `stack-cli auth login`.
        if _auth:
            auth: ApiKeyAuth | SessionAuth | OAuthAuth | CredentialsFileAuth | AgentKeypairAuth = _auth
        elif agent_id:
            static_auth = _build_static_auth(api_key=api_key, base_url=base_url)
            auth = AgentKeypairAuth(
                agent_id=agent_id,
                api_base_url=base_url,
                bearer_provider=lambda: static_auth.get_headers()["Authorization"].split(" ", 1)[1],
            )
        elif api_key or os.environ.get("STACK_API_KEY"):
            auth = ApiKeyAuth(api_key or os.environ["STACK_API_KEY"])
        else:
            auth = _resolve_creds_or_bootstrap(base_url)

        self._client = HttpClient(auth, base_url=base_url, timeout=timeout)
        self.agents = AgentService(self._client)
        self.passports = PassportService(self._client)
        self.credentials = CredentialService(self._client)
        self.services = ServiceService(self._client)
        self.dropoffs = DropoffService(self._client)
        self.reviews = ReviewService(self._client)
        self.notifications = NotificationService(self._client)
        self.audit = AuditService(self._client)
        self.proxy = ProxySvc(self._client)
        self.scan = ScanService(self._client)
        self.security_events = SecurityEventSvc(self._client)
        self.skills = SkillService(self._client)
        self.identity = IdentityService(self._client)

    @classmethod
    def from_session(cls, session_token: str, **kwargs) -> Stack:
        """Create a client authenticated with a session JWT."""
        return cls(_auth=SessionAuth(session_token), **kwargs)

    @classmethod
    def from_oauth(
        cls,
        client_id: str,
        client_secret: str,
        access_token: str,
        refresh_token: str,
        token_endpoint: str = "https://api.getstack.run/v1/oauth/token",
        **kwargs,
    ) -> Stack:
        """Create a client with OAuth tokens. Auto-refreshes when expired."""
        auth = OAuthAuth(
            client_id=client_id,
            client_secret=client_secret,
            access_token=access_token,
            refresh_token=refresh_token,
            token_endpoint=token_endpoint,
        )
        return cls(_auth=auth, **kwargs)

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> Stack:
        return self

    def __exit__(self, *args) -> None:
        self.close()


class AsyncStack:
    """Asynchronous STACK client.

    Uses httpx.AsyncClient under the hood. All service methods are sync
    (they use the sync HttpClient wrapper) — for true async, the async
    client needs async service modules. This provides the async HTTP
    transport layer for future async service implementations.

    Args:
        api_key: A STACK API key (``sk_live_...``).
        base_url: Override the API base URL.
        timeout: HTTP timeout in seconds.
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        agent_id: str | None = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
        _auth: ApiKeyAuth | SessionAuth | OAuthAuth | CredentialsFileAuth | AgentKeypairAuth | None = None,
    ):
        # Same four-source resolution as Stack — see Stack.__init__.
        if _auth:
            auth: ApiKeyAuth | SessionAuth | OAuthAuth | CredentialsFileAuth | AgentKeypairAuth = _auth
        elif agent_id:
            static_auth = _build_static_auth(api_key=api_key, base_url=base_url)
            auth = AgentKeypairAuth(
                agent_id=agent_id,
                api_base_url=base_url,
                bearer_provider=lambda: static_auth.get_headers()["Authorization"].split(" ", 1)[1],
            )
        elif api_key or os.environ.get("STACK_API_KEY"):
            auth = ApiKeyAuth(api_key or os.environ["STACK_API_KEY"])
        else:
            auth = _resolve_creds_or_bootstrap(base_url)

        self._client = AsyncHttpClient(auth, base_url=base_url, timeout=timeout)

    @classmethod
    def from_session(cls, session_token: str, **kwargs) -> AsyncStack:
        """Create an async client authenticated with a session JWT."""
        return cls(_auth=SessionAuth(session_token), **kwargs)

    @classmethod
    def from_oauth(
        cls,
        client_id: str,
        client_secret: str,
        access_token: str,
        refresh_token: str,
        token_endpoint: str = "https://api.getstack.run/v1/oauth/token",
        **kwargs,
    ) -> AsyncStack:
        """Create an async client with OAuth tokens. Auto-refreshes when expired."""
        auth = OAuthAuth(
            client_id=client_id,
            client_secret=client_secret,
            access_token=access_token,
            refresh_token=refresh_token,
            token_endpoint=token_endpoint,
        )
        return cls(_auth=auth, **kwargs)

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._client.close()

    async def __aenter__(self) -> AsyncStack:
        return self

    async def __aexit__(self, *args) -> None:
        await self.close()
