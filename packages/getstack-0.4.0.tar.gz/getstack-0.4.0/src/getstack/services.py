"""Service management."""

from __future__ import annotations

from typing import Any

from .client import HttpClient


class ServiceService:
    def __init__(self, client: HttpClient):
        self._client = client

    def list(self) -> list[dict[str, Any]]:
        return self._client.get("/v1/services/connections")

    def list_available(self) -> list[dict[str, Any]]:
        return self._client.get("/v1/services")

    def list_templates(self) -> list[dict[str, Any]]:
        return self._client.get("/v1/services/templates")

    def connect_custom(
        self,
        name: str,
        credential: str | dict[str, str],
        description: str | None = None,
        scopes: list[str] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"name": name, "credential": credential}
        if description:
            body["description"] = description
        if scopes:
            body["scopes"] = scopes
        return self._client.post("/v1/services/custom", json=body)

    def verify(self, connection_id: str) -> dict[str, Any]:
        return self._client.post(f"/v1/services/{connection_id}/verify")

    def disconnect(self, connection_id: str) -> dict[str, Any]:
        return self._client.delete(f"/v1/services/connections/{connection_id}")
