"""Agent management."""

from __future__ import annotations

from typing import Any

from .client import HttpClient
from .types import Agent


def _to_agent(data: dict[str, Any]) -> Agent:
    return Agent(
        id=data["id"],
        operator_id=data["operator_id"],
        name=data["name"],
        description=data.get("description"),
        status=data["status"],
        accountability_mode=data.get("accountability_mode", "standard"),
        on_warning=data.get("on_warning", "notify"),
        on_critical=data.get("on_critical", "notify"),
        passport_blocked=data.get("passport_blocked", False),
        passport_blocked_reason=data.get("passport_blocked_reason"),
        passport_blocked_at=data.get("passport_blocked_at"),
        created_at=data["created_at"],
        updated_at=data["updated_at"],
    )


class AgentService:
    def __init__(self, client: HttpClient):
        self._client = client

    def register(
        self,
        name: str,
        description: str | None = None,
        accountability_mode: str = "enforced",
        on_warning: str = "notify",
        on_critical: str = "notify",
    ) -> Agent:
        body: dict[str, Any] = {"name": name, "accountability_mode": accountability_mode}
        if description:
            body["description"] = description
        if on_warning != "notify":
            body["on_warning"] = on_warning
        if on_critical != "notify":
            body["on_critical"] = on_critical
        return _to_agent(self._client.post("/v1/agents/register", json=body))

    def get(self, agent_id: str) -> Agent:
        return _to_agent(self._client.get(f"/v1/agents/{agent_id}"))

    def list(self) -> list[Agent]:
        data = self._client.get("/v1/agents")
        return [_to_agent(a) for a in data]

    def update(self, agent_id: str, **kwargs: Any) -> Agent:
        return _to_agent(self._client.patch(f"/v1/agents/{agent_id}", json=kwargs))

    def suspend(self, agent_id: str) -> Agent:
        return self.update(agent_id, status="suspended")

    def activate(self, agent_id: str) -> Agent:
        return self.update(agent_id, status="active")

    def delete(self, agent_id: str) -> dict[str, Any]:
        return self._client.delete(f"/v1/agents/{agent_id}")

    def unblock(self, agent_id: str) -> dict[str, Any]:
        return self._client.post(f"/v1/agents/{agent_id}/unblock")
