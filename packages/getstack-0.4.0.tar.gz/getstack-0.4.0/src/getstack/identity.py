"""Identity verification — providers, claims, and verification flow."""

from __future__ import annotations

from typing import Any

from .client import HttpClient
from .types import IdentityProvider, IdentityClaim, IdentitySettings, VerificationSession


def _to_provider(data: dict[str, Any]) -> IdentityProvider:
    return IdentityProvider(
        key=data["key"],
        name=data["name"],
        layers=data.get("layers", []),
        assurance=data.get("assurance", ""),
        description=data.get("description", ""),
    )


def _to_claim(data: dict[str, Any]) -> IdentityClaim:
    return IdentityClaim(
        id=data["id"],
        operator_id=data["operator_id"],
        provider_key=data["provider_key"],
        layer=data["layer"],
        claim_type=data["claim_type"],
        claim_ref=data["claim_ref"],
        assurance_level=data["assurance_level"],
        verified_at=data["verified_at"],
        expires_at=data.get("expires_at"),
    )


class IdentityService:
    def __init__(self, client: HttpClient):
        self._client = client

    def get_settings(self) -> IdentitySettings:
        data = self._client.get("/v1/operators/me/identity-settings")
        return IdentitySettings(
            identity_claim_ttl=data["identity_claim_ttl"],
            identity_claim_inheritance=data["identity_claim_inheritance"],
            identity_auto_revoke=data["identity_auto_revoke"],
        )

    def update_settings(
        self,
        *,
        identity_claim_ttl: str | None = None,
        identity_claim_inheritance: str | None = None,
        identity_auto_revoke: bool | None = None,
    ) -> IdentitySettings:
        body: dict[str, Any] = {}
        if identity_claim_ttl is not None:
            body["identity_claim_ttl"] = identity_claim_ttl
        if identity_claim_inheritance is not None:
            body["identity_claim_inheritance"] = identity_claim_inheritance
        if identity_auto_revoke is not None:
            body["identity_auto_revoke"] = identity_auto_revoke
        data = self._client.patch("/v1/operators/me/identity-settings", json=body)
        return IdentitySettings(
            identity_claim_ttl=data["identity_claim_ttl"],
            identity_claim_inheritance=data["identity_claim_inheritance"],
            identity_auto_revoke=data["identity_auto_revoke"],
        )

    def list_providers(self) -> list[IdentityProvider]:
        data = self._client.get("/v1/identity/providers")
        return [_to_provider(p) for p in data]

    def initiate_verification(
        self,
        provider_key: str,
        *,
        requested_claims: list[str] | None = None,
        return_url: str | None = None,
    ) -> VerificationSession:
        body: dict[str, Any] = {"provider_key": provider_key}
        if requested_claims:
            body["requested_claims"] = requested_claims
        if return_url:
            body["return_url"] = return_url
        data = self._client.post("/v1/identity/verify/initiate", json=body)
        return VerificationSession(
            session_ref=data["session_ref"],
            authorization_url=data.get("authorization_url"),
            status=data.get("status", "pending"),
        )

    def complete_verification(
        self,
        provider_key: str,
        session_ref: str,
    ) -> dict[str, Any]:
        return self._client.post(
            "/v1/identity/verify/complete",
            json={"provider_key": provider_key, "session_ref": session_ref},
        )

    def grant_delegation(self, delegated_scopes: list[str]) -> IdentityClaim:
        data = self._client.post(
            "/v1/identity/delegate",
            json={"delegated_scopes": delegated_scopes},
        )
        return _to_claim(data)

    def list_claims(self) -> list[IdentityClaim]:
        data = self._client.get("/v1/identity/claims")
        return [_to_claim(c) for c in data]

    def revoke_claim(self, claim_id: str) -> dict[str, Any]:
        return self._client.delete(f"/v1/identity/claims/{claim_id}")

    def get_service_requirements(self, service_id: str) -> dict[str, Any]:
        return self._client.get(f"/v1/services/{service_id}/requirements")

    def set_service_requirement(self, service_id: str, **kwargs: Any) -> dict[str, Any]:
        return self._client.post(f"/v1/services/{service_id}/requirements", json=kwargs)
