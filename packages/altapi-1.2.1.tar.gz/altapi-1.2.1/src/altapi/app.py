import asyncio
import inspect
import os
from concurrent.futures import ThreadPoolExecutor
from typing import List, Optional, Dict, Any, Union
from pathlib import Path
from contextlib import asynccontextmanager

from .http.responses import HTMLResponse

from .router import Router
from .websocket.ws import WebSocket
from .http.request import Request
from .http.responses import JSONResponse, FileResponse, PlainTextResponse
from .middleware.middleware import Middleware, ASGIApp
from .templating.default_templates import DEFAULT_404_BODY, DEFAULT_405_BODY, DEFAULT_500_BODY
from .templating.templates import Jinja2Templates, set_default_templates_directory
from .caching.cache import CacheMiddleware, CacheManager, InMemoryCache, cache as cache_decorator, CacheBackend

_sync_executor = ThreadPoolExecutor(max_workers=10)


def _run_gc_optimize():
    """
    Garbage collector optimization.
    
    Applies the following optimizations:
    - Forced garbage collection
    - Object freezing
    - Increased GC thresholds
    """
    import gc
    gc.collect(2)
    gc.freeze()
    allocs, gen1, gen2 = gc.get_threshold()
    allocs = 50000
    gen1 = gen1 * 2
    gen2 = gen2 * 2
    gc.set_threshold(allocs, gen1, gen2)


async def _lifespan(app):
    """
    Common lifespan for all AltAPI instances with GC optimization.
    
    Called on each worker startup.
    """
    _run_gc_optimize()
    yield


class AltAPI:
    """
    Main AltAPI application class.
    
    ASGI framework for building web applications with support for:
    - HTTP routes (GET, POST, PUT, DELETE)
    - WebSocket connections
    - Middleware
    - Jinja2 templates
    - Static files
    - Caching
    """
    
    def __init__(
        self,
        middleware: List[Middleware] = None,
        templates_directory: Union[str, os.PathLike] = "templates",
        static_directory: Optional[Union[str, os.PathLike]] = None,
        cache_backend: Optional[CacheBackend] = None,
        cache_timeout: int = 300,
    ):
        """
        Initialize AltAPI application.

        Args:
            middleware: List of middleware for the application
            templates_directory: Directory with Jinja2 templates
            static_directory: Directory with static files (optional)
            cache_backend: Cache backend (optional)
            cache_timeout: Default cache lifetime in seconds
        """
        self._router = Router()
        self._middlewares = middleware or []
        self._mounted_apps: Dict[str, Any] = {}
        self._static_dirs: Dict[str, str] = {}

        self._core = self._build_core()
        self._app = self._build_middlewares(self._core)
        self._sync_executor = _sync_executor

        # Initialize Jinja2 templates
        self._templates_directory = str(templates_directory)
        self._templates = Jinja2Templates(self._templates_directory)

        # Set global templates directory for render_template
        set_default_templates_directory(self._templates_directory)

        # Initialize static directory (if specified)
        if static_directory is not None:
            self._static_directory = str(static_directory)
            self.mount("/static", directory=self._static_directory)
        else:
            self._static_directory = None

        # Initialize caching (if backend specified)
        self._cache_backend = cache_backend
        if cache_backend is not None:
            # Set as default backend
            CacheManager.set_default_backend(cache_backend)
            # Add CacheMiddleware automatically
            self._middlewares.append(Middleware(CacheMiddleware, cache_timeout=cache_timeout))
        self._cache_timeout = cache_timeout

    @property
    def templates(self) -> Jinja2Templates:
        """Return Jinja2Templates object for template rendering."""
        return self._templates

    @property
    def static_directory(self) -> Optional[str]:
        """Return path to static files directory (if configured)."""
        return self._static_directory

    @property
    def cache_backend(self) -> Optional[CacheBackend]:
        """Return cache backend (if configured)."""
        return self._cache_backend

    def route(self, path, methods=None):
        """
        Decorator for registering HTTP routes.

        Args:
            path: Route path
            methods: List of HTTP methods (default ["GET"])

        Returns:
            Decorator for registering handler function
        """
        methods = methods or ["GET"]

        def decorator(func):
            for m in methods:
                self._router.add_route(path, m.upper(), func)
            return func

        return decorator

    def get(self, path):
        """
        Decorator for registering GET routes.

        Args:
            path: Route path
        """
        return self.route(path, ["GET"])

    def post(self, path):
        """
        Decorator for registering POST routes.

        Args:
            path: Route path
        """
        return self.route(path, ["POST"])

    def put(self, path):
        """
        Decorator for registering PUT routes.

        Args:
            path: Route path
        """
        return self.route(path, ["PUT"])

    def delete(self, path):
        """
        Decorator for registering DELETE routes.

        Args:
            path: Route path
        """
        return self.route(path, ["DELETE"])

    def websocket(self, path):
        """
        Decorator for registering WebSocket routes.

        Args:
            path: Route path for WebSocket connections
        """
        def decorator(func):
            self._router.add_websocket_route(path, func)
            return func

        return decorator

    def cache(self, path: str, expires: int = 300):
        """
        Register a route for caching.

        Args:
            path: Route path
            expires: Cache lifetime in seconds

        Example:
            app.cache("/api/data", expires=3600)

            @app.get("/api/data")
            async def get_data(request):
                return JSONResponse({"data": "cached"})
        """
        # Find CacheMiddleware and register handler
        for mw in self._middlewares:
            if mw.middleware_cls == CacheMiddleware:
                # Get middleware instance after build
                pass

        # Store for later registration
        if not hasattr(self, "_cache_routes"):
            self._cache_routes = []
        self._cache_routes.append((path, expires))

        def decorator(func):
            # Add route as usual
            for m in ["GET"]:
                self._router.add_route(path, m.upper(), func)

            # Wrap function in cache
            return cache_decorator(expires=expires)(func)

        return decorator

    def mount(self, path: str, app: Any = None, directory: Union[str, os.PathLike] = None):
        """
        Mount an external ASGI application or static files directory.

        Args:
            path: Path prefix (e.g., "/static" or "/api")
            app: ASGI application to mount
            directory: Path to static files directory
        """
        if app is not None:
            self._mounted_apps[path] = app
        elif directory is not None:
            self._static_dirs[path] = str(directory)

    def run(
        self,
        host: str = "0.0.0.0",
        port: int = 8000,
        workers: int = 1,
        gc_optimize: bool = True,
        access_log: bool = True,
    ):
        """
        Run uvicorn server.

        Args:
            host: Host to listen on
            port: Port to listen on
            workers: Number of worker processes
            gc_optimize: Whether to optimize garbage collector
            access_log: Whether to enable request logging
        """
        import sys
        import uvicorn

        # Generate import string for workers support
        if workers > 1:
            main_module = sys.modules.get("__main__")
            if main_module and hasattr(main_module, "__file__") and main_module.__file__:
                # Get absolute path to file
                file_path = os.path.realpath(os.path.abspath(main_module.__file__))
                module_name = os.path.splitext(os.path.basename(file_path))[0]

                # If this is __main__.py in a package
                if module_name == "__main__":
                    # Package name is the directory name
                    package_name = os.path.basename(os.path.dirname(file_path))
                    app_str = f"{package_name}:app"
                else:
                    # Regular module - use filename without extension
                    app_str = f"{module_name}:app"
            else:
                app_str = "app:app"
        else:
            app_str = self

        uvicorn.run(
            app_str,
            host=host,
            port=port,
            workers=workers,
            access_log=access_log,
            http="httptools",
        )

    def _build_core(self):
        # Apply GC optimizations when creating the app (for each worker)
        _run_gc_optimize()

        async def app(scope, receive, send):
            if scope["type"] == "http":
                return await self._handle_http(scope, receive, send)
            elif scope["type"] == "websocket":
                return await self._handle_ws(scope, receive, send)

        return app

    def _build_middlewares(self, app: ASGIApp) -> ASGIApp:
        for mw in reversed(self._middlewares):
            app = mw.build(app)

        # Register cache routes after creating middleware
        if hasattr(self, "_cache_routes"):
            for mw in self._middlewares:
                if mw.middleware_cls == CacheMiddleware:
                    # Get middleware instance
                    middleware_instance = mw.build(app)
                    for path, expires in self._cache_routes:
                        middleware_instance.register_handler(path, expires)
                    break

        return app

    async def _handle_http(self, scope, receive, send):
        path = scope.get("path", "/")
        method = scope.get("method", "GET")

        # Check mounted applications
        for mount_path, mounted_app in self._mounted_apps.items():
            if path.startswith(mount_path):
                new_scope = dict(scope)  # shallow copy to avoid mutation
                new_scope["path"] = path[len(mount_path):] or "/"
                return await mounted_app(new_scope, receive, send)

        # Check static directories
        for mount_path, directory in self._static_dirs.items():
            if path.startswith(mount_path):
                relative_path = path[len(mount_path):].lstrip("/")
                file_path = os.path.join(directory, relative_path)

                # Protect against directory traversal (use realpath for symlink resolution)
                abs_directory = os.path.realpath(directory)
                abs_file = os.path.realpath(file_path)

                if abs_file.startswith(abs_directory) and os.path.isfile(abs_file):
                    response = FileResponse(file_path)
                    return await response(scope, receive, send)
                else:
                    # TODO: add logging
                    response = HTMLResponse(DEFAULT_404_BODY, 404)
                    return await response(scope, receive, send)

        handler, params = self._router.find_handler(path, method)

        if not handler:
            return await HTMLResponse(DEFAULT_404_BODY, 404)(scope, receive, send)

        request = Request(scope, receive, params)

        try:
            if inspect.iscoroutinefunction(handler):
                response = await handler(request)
            else:
                response = await asyncio.get_running_loop().run_in_executor(
                    self._sync_executor,
                    handler,
                    request,
                )

            await response(scope, receive, send)
        except Exception as e:
            print(f"\033[31mERROR:\033[37m {str(e)}\033[0m")
            await HTMLResponse(DEFAULT_500_BODY, 500)(scope, receive, send)

    async def _handle_ws(self, scope, receive, send):
        path = scope.get("path", "/")

        handler, params = self._router.find_websocket_handler(path)
        websocket = WebSocket(scope, receive, send, params)

        if not handler:
            await websocket.close(1000)
            return

        try:
            if inspect.iscoroutinefunction(handler):
                await handler(websocket)
            else:
                await asyncio.get_running_loop().run_in_executor(
                    self._sync_executor,
                    handler,
                    websocket,
                )

        except Exception as e:
            try:
                await websocket.close(1011, str(e))
            except Exception:
                pass

    async def __call__(self, scope, receive, send):
        return await self._app(scope, receive, send)
