# Validate Prompt
**Task:** Validate `spec.md` for completeness and correctness.
**Token budget:** ~800 tokens (Zone 0)

## Your Job
Run validation checks against spec.md and output a structured report.

## Checklist
1. All 6 sections present: Overview, Data Context, Integration Patterns, Business Rules, Acceptance Criteria, Open Questions
2. No invented field names (cross-reference Data Context with known schemas)
3. All AC items are measurable (contain threshold, value, or action)
4. No OQ marked resolved without an answer
5. Data sources listed match platform catalog (if online)

## Output Format
```
VALIDATION REPORT — {project_name}
Status: PASS | FAIL

[PASS] Section: Overview present
[FAIL] Section: Acceptance Criteria — AC-02 not measurable
[WARN] Field: customer_name not found in Silver (unchecked, offline)
...

Exit code: 0 (PASS) | 1 (FAIL)
```
