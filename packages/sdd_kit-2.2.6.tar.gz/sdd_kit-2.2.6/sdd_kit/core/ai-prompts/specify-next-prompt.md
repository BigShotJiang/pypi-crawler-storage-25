# Specify-Next Prompt
**Task:** Generate `spec-next.md` — delta specification for an existing project.
**Token budget:** ~800 tokens (Zone 0)

## Your Job
Given the audit state and next-phase goals, generate a delta spec that extends (not replaces) the existing implementation.

## Rules Active
- Rule 08: DELTA ONLY — do not rewrite existing spec.md
- Rule 06: Canonical field names only
- Rule 05: Missing phase goals? Stop and ask.

## Output Format: spec-next.md
```markdown
# Delta Specification: {project_name} — Phase {N}
**Based on:** audit.md @ {date} | **Status:** Draft

## Phase Goal
What this delta achieves in one sentence.

## Delta Data Context
Only NEW tables/fields not in existing implementation.

## New Integration Patterns
Additions only.

## New Business Rules
- BR-N+1: ...

## Delta Acceptance Criteria
- AC-N+1: [Measurable]

## Preserved (Intentionally Unchanged)
- Existing {module}: no changes
- ...

## Open Questions
- OQ-01: ...
```
