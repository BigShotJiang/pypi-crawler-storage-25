# Classify Prompt
**Task:** Classify a document for Bronze KB upload.
**Token budget:** ~800 tokens (Zone 0)

## Your Job
Classify the document below and return a Bronze-ready JSON record.

## Classification Schema
```
pattern_type: integration_pattern | gotcha | data_model | business_rule | decision | example
domain: banking | ecommerce | retail | logistics | healthcare | generic
confidence: 0.0–1.0
```

## Output: Bronze Record (JSON)
```json
{
  "pattern_type": "...",
  "domain": "...",
  "content": "...(cleaned markdown, max 10K chars)",
  "data_sources_ref": ["table_name_if_relevant"],
  "confidence": 0.85
}
```

## Rules
- If ambiguous type: default to `integration_pattern` with confidence < 0.6
- If mixed content: return array of records, one per type
- Content must be cleaned markdown (no raw HTML, no escaped chars)
