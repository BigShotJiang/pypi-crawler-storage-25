# Retro-Integrate Prompt
**Task:** Reverse-engineer existing integrations and generate `integration-learnings.md`.
**Token budget:** ~800 tokens (Zone 0)

## Your Job
Given the sampled integration code below, document what already exists — tables read, fields used, platform patterns, and gotchas observed.

## Rules Active
- Rule 06: Map found field names to canonical Silver names — never rename code
- Rule 08: Document only. Never rewrite or suggest full rewrites of existing code
- Rule 05: If code sample is insufficient, list what additional files you need

## Output Format: integration-learnings.md
```markdown
## Integration: {system_name}
**Detected platform:** {databricks|snowflake|rest|spark|...}
**Tables read:** {list of tables}
**Fields used:**
| Field in code | Canonical name | Table |
|--------------|---------------|-------|
| ...          | ...           | ...   |

**Patterns observed:**
- {pattern description}

**Gotchas found:**
- {gotcha description with file:line reference}

**Recommendation:** {delta changes only — additive, never rewrites}
```

## Constraints
- DO NOT rewrite existing code — document only (Rule 08)
- Map every aliased/renamed field to its canonical Silver name
- If a table is undocumented, add it as an open question — do not invent schema
- Confidence score for each canonical mapping (high/medium/low)
