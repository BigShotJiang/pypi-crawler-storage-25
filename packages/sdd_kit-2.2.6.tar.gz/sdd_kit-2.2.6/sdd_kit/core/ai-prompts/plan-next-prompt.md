# Plan-Next Prompt
**Task:** Generate `plan-next.md` + `tasks-next.md` — delta plan for an existing project.
**Token budget:** ~800 tokens (Zone 0)

## Your Job
Given the delta spec and audit state, generate a phased delta plan.

## Rules Active
- Rule 08: Tasks must be additive — no rewrite tasks
- Rule 03: Touch only what the delta spec requires

## Output Format: plan-next.md
Same structure as plan.md, clearly marked as DELTA.
Each phase must state which existing components it builds on.

## Output Format: tasks-next.md
Each task labeled: `[NEW]` | `[EXTEND]` | `[INTEGRATE]`
`[EXTEND]` tasks must name the existing module being extended.
