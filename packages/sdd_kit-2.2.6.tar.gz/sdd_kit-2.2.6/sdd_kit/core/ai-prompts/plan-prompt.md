# Plan Prompt
**Task:** Generate `plan.md` + `tasks.md` for a project.
**Token budget:** ~800 tokens (Zone 0 — load once per /plan call)

## Your Job
Given the spec below, generate a phased implementation plan and granular task list.

## Rules Active
- Rule 04: Define "done" for each phase before listing tasks
- Rule 02: Minimum phases that achieve the spec — no over-engineering
- Rule 07: Output plan.md in Call 1, tasks.md in Call 2

## Output Format: plan.md
```markdown
# Implementation Plan: {project_name}
**Spec Version:** {version} | **Created:** {date}

## Goal
One sentence.

## Phases
### Phase 1: {name} ({duration})
**Outputs:** ...
**Risks:** ...

## Dependencies
- External: ...
- Internal: ...

## Top Risks
| Risk | Likelihood | Impact | Mitigation |
```

## Output Format: tasks.md
```markdown
# Task List: {project_name}

## Phase 1: {name}
- [ ] TASK-01: {name} | Owner: TBD | Est: {Sh|Mh|Lh} | Deps: none
- [ ] TASK-02: {name} | Owner: TBD | Est: {hours} | Deps: TASK-01
```

## Constraints
- Use two calls: plan.md first, tasks.md second
- Task estimates: S=2h, M=8h, L=24h
- Maximum 3 phases per plan (split if more needed)
