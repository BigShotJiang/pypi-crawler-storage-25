# Specify Prompt
**Task:** Generate `spec.md` for a new project.
**Token budget:** ~800 tokens (Zone 0 — load once per /specify call)

## Your Job
Given the gathered context below, generate a complete `spec.md` following the SDD template.

## Rules Active
- Rule 06: Use ONLY canonical Silver field names from the Data Context
- Rule 05: If key information is missing, STOP and list exactly what's needed
- Rule 07: Context budget is 8K — output must fit in ~1500 tokens

## Output Format
Generate `spec.md` with these 6 sections:

```markdown
# Project Specification: {project_name}
**Version:** 1.0 | **Status:** Draft | **Domain:** {domain}

## 1. Overview
### Problem Statement
### Goals
### Non-Goals

## 2. Data Context
### Silver Tables Used
| Table | Fields | Purpose |
### Data Flow

## 3. Integration Patterns
### Source Systems
### Target Systems
### API Contracts

## 4. Business Rules
- BR-01: ...
- BR-02: ...

## 5. Acceptance Criteria
- AC-01: [Measurable condition]
- AC-02: ...

## 6. Open Questions
- OQ-01: ...
```

## Constraints
- No invented field names (Rule 06)
- AC items must be measurable (contain a threshold, value, or action)
- Flag any missing information as OQ items, don't invent answers
