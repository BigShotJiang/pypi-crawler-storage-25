# Audit Prompt
**Task:** Audit an existing project for SDD compliance.
**Token budget:** ~800 tokens (Zone 0 — load once per /audit call)

## Your Job
Given the code sample below, audit the existing project and generate `audit.md`.

## Rules Active
- Rule 08: Existing implementation is intentional — recommend delta, never rewrite
- Rule 05: If code sample is insufficient, list what additional files you need
- Rule 06: Map any found field names to canonical Silver names

## Output Format: audit.md
```markdown
# SDD Audit Report: {project_name}
**Date:** {date} | **SDD Readiness:** {0-10}/10

## Summary
- Domain detected: ...
- Project type: ...
- Integration platforms found: ...

## Existing Integrations
| System | Type | Tables/APIs | Status |

## Data Models Found
| Field (in code) | Canonical Name | Table | Notes |

## SDD Compliance Gaps
- GAP-01: Missing spec.md
- GAP-02: ...

## Recommended Next Steps
1. Run `sdd /gather` to fill context
2. Run `sdd /specify-next` to generate delta spec
3. ...
```

## Constraints
- SDD Readiness score: 0=no SDD, 10=fully compliant
- Never say code is "wrong" — say "recommend extending with..."
- Map all found field names to canonical before recommending
