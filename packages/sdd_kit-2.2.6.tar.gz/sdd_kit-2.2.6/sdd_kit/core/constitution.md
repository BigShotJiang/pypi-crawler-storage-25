# Company Constitution & Development Principles

## 1. Core Principles
- **Spec-First**: Never write code without a clear specification.
- **AI-Native**: Optimize all documentation and code structure for AI collaboration (Cursor, Copilot, etc.).
- **Data-Centric**: Clearly define data structures and context before implementing logic.
- **Maintainability**: Write code that is easy to read, test, and update.

## 2. SDD Workflow
1. **Specify**: Define requirements in `spec.md`.
2. **Plan**: Create an `implementation_plan.md` and get approval.
3. **Execute**: Build the features step-by-step.
4. **Verify**: Ensure everything works as expected with tests and walkthroughs.

## 3. Communication
- Be concise and clear.
- Use standardized templates for consistency.
- Document design decisions and rationale.
