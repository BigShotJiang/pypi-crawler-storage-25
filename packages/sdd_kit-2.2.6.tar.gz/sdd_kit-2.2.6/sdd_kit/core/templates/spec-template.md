# Spec: [Project Name]

## 1. Project Overview
- **Goal**: Brief description of the project.
- **Objectives**: What are we trying to achieve?
- **Target Audience**: Who is this for?

## 2. Scope & Requirements
### Functional Requirements
- Requirement 1
- Requirement 2

### Non-Functional Requirements
- Performance
- Security
- Scalability

## 3. Data Context (CRITICAL)
> [!IMPORTANT]
> This section defines the "Source of Truth" for the AI.

### Data Models
- **Model A**: description, fields, relationships.
- **Model B**: description, fields, relationships.

### API / Interface
- Endpoint definitions
- Input/Output schemas

## 4. Technical Architecture
- **Tech Stack**: Python, Typer, etc.
- **Infrastructure**: AWS, Vercel, etc.

## 5. Implementation Plan (Summary)
- Phase 1: Core setup
- Phase 2: Feature development
- Phase 3: Testing & Deployment

## 6. Acceptance Criteria
- [ ] Criterion 1
- [ ] Criterion 2
