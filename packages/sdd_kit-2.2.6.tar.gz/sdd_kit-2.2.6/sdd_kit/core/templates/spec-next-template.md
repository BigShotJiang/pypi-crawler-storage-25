# Spec-Next Template
**Version:** 1.0 | **Type:** Delta Specification

# Delta Specification: {{PROJECT_NAME}} — Phase {{N}}
**Based on:** audit.md @ {{DATE}} | **Domain:** {{DOMAIN}} | **Status:** Draft

---

## Phase Goal
{{PHASE_GOAL}}

---

## Delta Data Context

### New Silver Tables
| Table | Canonical Fields | Purpose |
|-------|-----------------|---------|
| {{TABLE}} | {{FIELDS}} | {{PURPOSE}} |

### New Data Flow
{{DELTA_DATA_FLOW}}

---

## New Integration Patterns
{{NEW_INTEGRATION_PATTERNS}}

---

## New Business Rules
- BR-{{N}}: {{RULE}}

---

## Delta Acceptance Criteria
- AC-{{N}}: {{MEASURABLE_CONDITION}}

---

## Preserved (Intentionally Unchanged)
- Existing {{MODULE}}: no changes planned
- Existing {{INTEGRATION}}: no changes planned

---

## Open Questions
- OQ-01: {{QUESTION}}
