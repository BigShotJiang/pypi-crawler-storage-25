# Audit Template
**Version:** 1.0

# SDD Audit Report: {{PROJECT_NAME}}
**Date:** {{DATE}} | **SDD Readiness:** {{SCORE}}/10 | **Auditor:** sdd-kit v2.0

---

## Summary
- **Domain detected:** {{DOMAIN}}
- **Project type:** {{PROJECT_TYPE}}
- **Integration platforms:** {{PLATFORMS}}
- **Existing spec.md:** {{YES/NO}}
- **LOC (approx):** {{LOC}}

---

## Existing Integrations
| System | Type | Tables/APIs | Status |
|--------|------|-------------|--------|
| {{SYSTEM}} | {{TYPE}} | {{TABLES}} | {{STATUS}} |

---

## Data Models Found
| Field (in code) | Canonical Name | Table | Notes |
|-----------------|---------------|-------|-------|
| {{ALIAS}} | {{CANONICAL}} | {{TABLE}} | {{NOTES}} |

---

## SDD Compliance Gaps
- GAP-01: {{GAP}}

---

## Recommended Next Steps
1. `sdd /gather` — fill in context gaps
2. `sdd /specify-next` — generate delta spec for next phase
3. `sdd /integrate --retro` — document existing integrations
