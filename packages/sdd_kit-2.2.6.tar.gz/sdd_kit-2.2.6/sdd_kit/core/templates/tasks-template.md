# Tasks Template
**Version:** 1.0

# Task List: {{PROJECT_NAME}}
**Plan version:** {{PLAN_VERSION}} | **Created:** {{DATE}}

---

## Phase 1: {{PHASE_NAME}}

- [ ] TASK-01: {{TASK_NAME}} | Owner: TBD | Est: S (2h) | Deps: none
- [ ] TASK-02: {{TASK_NAME}} | Owner: TBD | Est: M (8h) | Deps: TASK-01
- [ ] TASK-03: {{TASK_NAME}} | Owner: TBD | Est: L (24h) | Deps: TASK-01, TASK-02

---

## Phase 2: {{PHASE_NAME}}

- [ ] TASK-04: {{TASK_NAME}} | Owner: TBD | Est: M (8h) | Deps: TASK-02
- [ ] TASK-05: {{TASK_NAME}} | Owner: TBD | Est: S (2h) | Deps: TASK-04

---

## Legend
- `[ ]` Not started
- `[/]` In progress
- `[x]` Completed
- **S** = Small (~2h) | **M** = Medium (~8h) | **L** = Large (~24h)
