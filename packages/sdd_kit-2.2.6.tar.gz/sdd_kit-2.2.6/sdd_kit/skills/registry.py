"""
Skills Registry — Layer 1 manifest (always in context) + Layer 2 loader (on-demand).
Rule 09: Load skill file before starting any task.
"""
from __future__ import annotations

import logging
from pathlib import Path

logger = logging.getLogger(__name__)

# Layer 1 — always in context (~45 tokens)
SKILLS_MANIFEST: list[dict] = [
    {"name": "specify-skill",          "desc": "Generate spec.md from gathered context"},
    {"name": "plan-skill",             "desc": "Generate plan.md + tasks.md from spec"},
    {"name": "integrate-skill",        "desc": "Live Silver schema + integration skeleton"},
    {"name": "validate-skill",         "desc": "Validate spec completeness + catalog"},
    {"name": "audit-skill",            "desc": "Audit existing codebase for SDD compliance"},
    {"name": "specify-next-skill",     "desc": "Delta spec for existing projects"},
    {"name": "plan-next-skill",        "desc": "Delta plan for existing projects"},
    {"name": "classify-skill",         "desc": "Classify KB documents for Bronze upload"},
    {"name": "retro-integrate-skill",  "desc": "Reverse-engineer existing integrations"},
]

_SKILL_FILES_DIR = Path(__file__).parent / "skill_files"


class SkillsRegistry:
    """
    Manages the two-layer skills system:
    - Layer 1: SKILLS_MANIFEST (always in system prompt, ~45 tokens)
    - Layer 2: skill_files/*.md (loaded on-demand per task, ~500-2000 tokens each)
    """

    @staticmethod
    def get_manifest_text() -> str:
        """Return Layer 1 manifest as markdown string."""
        lines = ["## Available Skills (Layer 1 — always in context)"]
        for s in SKILLS_MANIFEST:
            lines.append(f"- **{s['name']}**: {s['desc']}")
        return "\n".join(lines)

    @staticmethod
    def list_skills() -> list[dict]:
        """Return skill manifest with availability info."""
        result = []
        for s in SKILLS_MANIFEST:
            path = _SKILL_FILES_DIR / f"{s['name']}.md"
            result.append({
                **s,
                "available": path.exists(),
                "path": str(path),
                "size_bytes": path.stat().st_size if path.exists() else 0,
            })
        return result

    @staticmethod
    def load_skill_file(name: str) -> str:
        """
        Load a Layer 2 skill file by name.
        name: 'specify-skill' | 'plan-skill' | etc. (with or without .md)
        Returns skill file content, or empty string if not found.
        """
        skill_name = name.removesuffix(".md")
        path = _SKILL_FILES_DIR / f"{skill_name}.md"
        if path.exists():
            content = path.read_text(encoding="utf-8")
            logger.debug(f"Loaded skill: {skill_name} ({len(content)} chars)")
            return content
        logger.debug(f"Skill not found (will improvise): {skill_name}")
        return ""

    @staticmethod
    def skill_exists(name: str) -> bool:
        skill_name = name.removesuffix(".md")
        return (_SKILL_FILES_DIR / f"{skill_name}.md").exists()

    @staticmethod
    def update_skill(name: str, content: str) -> Path:
        """Write or update a skill file (Rule 10: Failures are skill inputs)."""
        skill_name = name.removesuffix(".md")
        _SKILL_FILES_DIR.mkdir(parents=True, exist_ok=True)
        path = _SKILL_FILES_DIR / f"{skill_name}.md"
        path.write_text(content, encoding="utf-8")
        logger.info(f"Skill updated: {path}")
        return path
