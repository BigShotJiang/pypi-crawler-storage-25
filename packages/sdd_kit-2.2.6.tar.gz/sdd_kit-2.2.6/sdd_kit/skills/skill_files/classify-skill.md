# Classify Skill
**When to load:** When running `sdd upload-kb`
**Derived from run:** 2026-05-13T03:00:00Z (initial seed)

## Inputs Required
- Document to classify (markdown or text)
- Zone 0: `classify-prompt.md`

## Step-by-Step Workflow
1. Read document
2. Classify into pattern_type:
   - `integration_pattern` — How to connect to a system
   - `gotcha` — Known failure mode or non-obvious behavior
   - `data_model` — Table/field documentation
   - `business_rule` — Domain constraint or rule
   - `decision` — Architecture or design decision with rationale
   - `example` — Working code or configuration example
3. Assign domain (banking | ecommerce | retail | logistics | healthcare | generic)
4. Assign confidence score (0.0–1.0)
5. Return Bronze-ready record

## Output: Bronze Record
```json
{
  "pattern_type": "integration_pattern",
  "domain": "banking",
  "content": "...",
  "confidence": 0.85,
  "data_sources_ref": ["silver_transactions"]
}
```

## Known Failure Modes → Fixes
- **Ambiguous type:** Default to `integration_pattern` with confidence < 0.6
- **Mixed content:** Split into multiple records, one per type
