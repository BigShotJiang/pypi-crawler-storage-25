# Specify-Next Skill
**When to load:** When running `sdd /specify-next` (existing projects)
**Derived from run:** 2026-05-13T03:00:00Z (initial seed)

## Inputs Required
- `audit.md` — full audit output (this IS the state, ~1500 tokens)
- Zone 0: `specify-next-prompt.md`
- Gold chunks: top-10
- User input: next-phase goals (~500 tokens)

## Step-by-Step Workflow
1. Read `audit.md` fully — it is the source of truth for current state
2. Read user's next-phase goals
3. Retrieve Gold chunks relevant to the next phase
4. Assemble context (≤8K)
5. Generate `spec-next.md` — DELTA ONLY (Rule 08)
6. Write to project root alongside existing `spec.md`

## Required Output: spec-next.md
- **Phase Goal** — What this delta achieves
- **Delta Data Context** — New tables/fields added (not existing ones)
- **New Integration Patterns** — Additions only
- **New Business Rules** — Additions only
- **Delta Acceptance Criteria** — Testable additions
- **Preserved Items** — List what is intentionally NOT changed

## Known Failure Modes → Fixes
- **Rewriting existing spec:** STOP — generate delta file only
- **audit.md too long:** Truncate to key findings section (Recommended Next Steps)
- **Contradicting existing implementation:** Flag as open question, don't resolve unilaterally
