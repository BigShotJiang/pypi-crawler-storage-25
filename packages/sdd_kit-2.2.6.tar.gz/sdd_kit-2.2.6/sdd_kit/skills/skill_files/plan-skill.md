# Plan Skill
**When to load:** When running `sdd /plan`
**Derived from run:** 2026-05-13T03:00:00Z (initial seed)

## Inputs Required
- `spec.md` — completed specification
- Zone 0: `plan-prompt.md`
- Gold chunks: top-10 (integration patterns, past plans)
- Zone 2: `decisions.md`, `integration-learnings.md` (if non-empty)

## Step-by-Step Workflow
1. Read `spec.md` fully (acceptance criteria are the north star)
2. Break spec into implementation phases/sprints
3. For each phase: identify tasks, dependencies, and risks
4. CALL 1: Generate `plan.md` (phases, milestones, risks)
5. CALL 2: Generate `tasks.md` (granular task list with estimates)
6. Write both files to project root
7. Log both calls to session log

## Required Output: plan.md
- **Goal** — One sentence
- **Phases** — Ordered phases with: name, duration, outputs, risks
- **Dependencies** — External systems, approvals, data access
- **Risks** — Top-3 risks with mitigation

## Required Output: tasks.md
- Checklist format: `[ ]` / `[/]` / `[x]`
- Each task: name, phase, owner, estimate (hours), dependencies
- Group by phase

## Known Failure Modes → Fixes
- **Too many tasks:** Group into epics first, break down only top-priority
- **Missing estimates:** Use T-shirt sizing (S=2h, M=8h, L=24h) as default
- **Circular dependencies:** Map dependencies before generating tasks
- **Context overflow:** Use two 8K calls — plan.md in Call 1, tasks.md in Call 2
