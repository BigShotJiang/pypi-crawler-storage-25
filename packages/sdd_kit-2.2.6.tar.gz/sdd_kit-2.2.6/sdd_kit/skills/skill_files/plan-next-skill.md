# Plan-Next Skill
**When to load:** When running `sdd /plan-next` (existing projects)
**Derived from run:** 2026-05-13T03:00:00Z (initial seed)

## Inputs Required
- `spec-next.md` — delta specification
- `audit.md` — existing state
- Zone 0: `plan-next-prompt.md`
- Gold chunks: top-10

## Step-by-Step Workflow
1. Read `spec-next.md` and `audit.md`
2. Identify delta tasks only (Rule 08: no rewrites)
3. Map dependencies on existing implementation
4. Generate `plan-next.md` + `tasks-next.md`
5. Tasks must reference which existing components they extend

## Required Output: plan-next.md
- Same structure as plan.md but clearly marked as DELTA
- Each phase: state which existing components it builds on
- Risk section must include: "Regression risk to existing implementation"

## Required Output: tasks-next.md
- Same format as tasks.md
- Each task labeled: `[NEW]` | `[EXTEND]` | `[INTEGRATE]`
- `[EXTEND]` tasks must name the existing module being extended

## Known Failure Modes → Fixes
- **Tasks that rewrite existing code:** Change to `[EXTEND]` with wrapper pattern
- **Scope too large:** Limit to 1-2 phases per /plan-next call
