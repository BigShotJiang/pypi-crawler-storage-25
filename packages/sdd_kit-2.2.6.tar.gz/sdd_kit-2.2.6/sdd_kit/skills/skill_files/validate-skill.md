# Validate Skill
**When to load:** When running `sdd /validate`
**Derived from run:** 2026-05-13T03:00:00Z (initial seed)

## Inputs Required
- `spec.md` (or `spec-next.md`)
- Zone 0: `validate-prompt.md`
- Optional: catalog connection for live schema validation

## Step-by-Step Workflow
1. Parse `spec.md` — check all 6 sections present
2. Validate Data Context: all field names exist in Silver schema
3. Validate Acceptance Criteria: all criteria are testable (contain measurable condition)
4. Validate Business Rules: no contradictions
5. Output: exit code 0 (pass) or 1 (fail) + validation report

## Validation Checklist
- `[ ]` All 6 sections present in spec.md
- `[ ]` No invented field names (cross-check Silver schema)
- `[ ]` Acceptance Criteria are measurable (contain: value, threshold, or action)
- `[ ]` No open questions marked as resolved without answer
- `[ ]` Data sources listed match platform catalog

## Exit Codes
- `0` — All checks passed
- `1` — One or more checks failed (see report)

## Known Failure Modes → Fixes
- **Field name mismatch:** Run `sdd /integrate` first to get canonical names
- **Missing sections:** Return specific section names that are missing
- **No catalog access:** Skip catalog check, label as `(unchecked, offline)`
