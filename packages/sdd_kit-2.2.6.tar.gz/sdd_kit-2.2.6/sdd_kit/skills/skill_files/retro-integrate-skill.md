# Retro-Integrate Skill
**When to load:** When running `sdd /integrate --retro` (existing projects)
**Derived from run:** 2026-05-13T03:00:00Z (initial seed)

## Inputs Required
- Existing integration code (sampled, ~2K tokens)
- Zone 0: `integrate-prompt.md`
- Gold chunks: top-8

## Step-by-Step Workflow
1. Sample existing integration code (entry points, data reads, transforms)
2. Identify: what tables are read, what fields are used, what platform
3. Map fields to canonical Silver names (Rule 06)
4. Generate `integration-learnings.md` in `.sdd/local-kb/`
5. Rule 08: DO NOT rewrite existing code — document only

## Required Output: integration-learnings.md
```markdown
## Integration: {system_name}
**Detected platform:** {databricks|snowflake|rest|...}
**Tables read:** {list}
**Fields used:** {canonical_name: actual_name_in_code}
**Patterns observed:** {list}
**Gotchas found:** {list}
**Recommendation:** {delta changes only, if any}
```

## Known Failure Modes → Fixes
- **Aliased field names:** Map alias → canonical in learnings, don't rename code
- **Undocumented table:** Add as open question in learnings, don't invent schema
- **Rule 08 violation:** If tempted to rewrite — STOP, document as recommendation instead
