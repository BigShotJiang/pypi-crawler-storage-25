# Specify Skill
**When to load:** When running `sdd /specify`
**Derived from run:** 2026-05-13T03:00:00Z (initial seed)

## Inputs Required
- `gather-context.yaml` — completed gather context
- Zone 0: `specify-prompt.md`
- Gold chunks: top-12 from semantic retrieval
- Zone 2: `data-models.md`, `gotchas.md` (if non-empty)

## Step-by-Step Workflow
1. Read `gather-context.yaml` fully
2. Identify the domain, data sources, and integration targets
3. Retrieve Gold chunks for the domain + integration pattern
4. Assemble context (ContextBuilder, ≤8K tokens)
5. Generate `spec.md` with all 6 required sections
6. Write `spec.md` to project root
7. Log token count to session log

## Required Output Sections (spec.md)
1. **Overview** — Problem statement, goals, non-goals
2. **Data Context** — Silver tables, field names (canonical only, Rule 06)
3. **Integration Patterns** — How data flows in/out
4. **Business Rules** — Domain-specific constraints
5. **Acceptance Criteria** — Testable, measurable done conditions
6. **Open Questions** — Unresolved items for team review

## Known Failure Modes → Fixes
- **Invented field names:** Always confirm against `data-models.md` or Silver schema — never invent
- **Over-long spec:** If context budget exceeded, cut Gold chunks (never cut Zone 0)
- **Missing business rules:** Prompt user to fill gather-context.yaml `business_rules` field
- **Context overflow:** Reduce Gold top_k from 12 → 8; truncate Zone 2 if needed
