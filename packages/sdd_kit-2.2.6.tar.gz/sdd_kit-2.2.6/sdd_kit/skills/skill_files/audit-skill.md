# Audit Skill
**When to load:** When running `sdd /audit` (existing projects)
**Derived from run:** 2026-05-13T03:00:00Z (initial seed)

## Inputs Required
- Code sample: `src/` files, `tests/`, `.env` keys (~2K tokens max)
- Zone 0: `audit-prompt.md`
- Gold chunks: top-8 (fewer than /specify — more output budget needed)

## Step-by-Step Workflow
1. Scan project: `src/`, `tests/`, config files
2. Sample code strategically (entry points, data models, integrations)
3. Retrieve Gold chunks for observed domain/patterns
4. Assemble context (≤8K, reserve 3.2K for output)
5. Generate `audit.md` + `audit-findings.md`
6. Write both to `.sdd/` directory
7. Rule 08: Never call existing code "broken" — recommend delta only

## Required Output: audit.md
- **Summary** — Domain detected, project type, SDD readiness score (0-10)
- **Existing Integrations** — What's already connected (data sources, APIs)
- **Data Models Used** — Field names found, canonical mapping
- **Compliance Gaps** — What's missing from SDD methodology
- **Recommended Next Steps** — Specific commands to run next

## Required Output: audit-findings.md
- Granular findings: `[FIELD]`, `[PATTERN]`, `[RISK]`, `[GOTCHA]` tags
- Each finding: description, file:line reference, recommendation

## Known Failure Modes → Fixes
- **Too much code to sample:** Prioritize entry points + data models only
- **Unknown domain:** Ask user to confirm domain before proceeding
- **Rule 08 violation:** Never suggest rewriting existing code — only additive changes
