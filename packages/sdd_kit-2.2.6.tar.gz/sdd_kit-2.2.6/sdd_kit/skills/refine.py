"""
sdd skills refine <name>
Opens skill file in $EDITOR for manual refinement (Rule 10: failures are skill inputs).
"""
import os
import subprocess
from rich.console import Console
from sdd_kit.skills.registry import SkillsRegistry, _SKILL_FILES_DIR

console = Console()


def run(name: str) -> None:
    skill_name = name.removesuffix(".md")
    path = _SKILL_FILES_DIR / f"{skill_name}.md"

    if not path.exists():
        console.print(f"[yellow]⚠️  Skill '{skill_name}' doesn't exist yet. Creating template...[/]")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            f"# {skill_name}\n**When to load:** When running `sdd /{skill_name.replace('-skill', '')}`\n"
            f"**Derived from run:** (add timestamp after first successful run)\n\n"
            f"## Inputs Required\n\n## Step-by-Step Workflow\n\n## Known Failure Modes → Fixes\n",
            encoding="utf-8",
        )

    editor = os.environ.get("EDITOR", "vi")
    console.print(f"[blue]Opening {path} in {editor}...[/]")
    subprocess.run([editor, str(path)])
    console.print(f"[green]✓ Skill '{skill_name}' updated[/]")
