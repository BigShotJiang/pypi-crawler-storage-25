"""
sdd skills list
"""
from rich.console import Console
from rich.table import Table
from sdd_kit.skills.registry import SkillsRegistry

console = Console()


def run() -> None:
    skills = SkillsRegistry.list_skills()
    table = Table(show_header=True, header_style="bold cyan", title="Available Skills (Layer 2)")
    table.add_column("Name")
    table.add_column("Description")
    table.add_column("Available", justify="center")
    table.add_column("Size", justify="right")

    for s in skills:
        avail = "[green]✓[/]" if s["available"] else "[red]✗[/]"
        size = f"{s['size_bytes']} B" if s["available"] else "—"
        table.add_row(s["name"], s["desc"], avail, size)

    console.print(table)
    console.print(f"\n[dim]Skills dir: {__import__('sdd_kit.skills.registry', fromlist=['_SKILL_FILES_DIR'])._SKILL_FILES_DIR}[/]")
