"""
sdd skills inspect <name>
"""
from rich.console import Console
from rich.markdown import Markdown
from sdd_kit.skills.registry import SkillsRegistry

console = Console()


def run(name: str) -> None:
    content = SkillsRegistry.load_skill_file(name)
    if not content:
        console.print(f"[red]❌ Skill '{name}' not found[/]")
        return
    console.print(Markdown(content))
