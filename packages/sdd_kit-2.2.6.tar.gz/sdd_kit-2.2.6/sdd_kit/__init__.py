"""
sdd-kit — Spec-Driven Development CLI
"""
from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("sdd-kit")
except PackageNotFoundError:
    __version__ = "2.2.6"

__author__ = "SDD Team"
