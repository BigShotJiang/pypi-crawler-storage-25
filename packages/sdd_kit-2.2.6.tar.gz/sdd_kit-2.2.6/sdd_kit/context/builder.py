"""
ContextBuilder — assembles context within the 8,000 token budget.
Rule 07: Context budget is sacred. Never exceed 8K.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path

from sdd_kit.context.token_counter import count_tokens, format_token_report, tokens_remaining
from sdd_kit.lakehouse.schema import Chunk

logger = logging.getLogger(__name__)

MAX_BUDGET = 8_000


@dataclass
class BuiltContext:
    text: str
    token_count: int
    sources: list[str]
    breakdown: dict[str, int]
    is_over_budget: bool

    def report(self) -> str:
        return format_token_report(self.breakdown, MAX_BUDGET)


class ContextBuilder:
    """
    Assembles the final context string for an AI call.
    Enforces the 8,000 token budget by truncating Gold chunks if needed.
    Never cuts Zone 0 (task prompt).

    Build order (priority):
    1. Zone 0 task prompt    (~800 tokens, NEVER cut)
    2. Zone 2 local-kb       (~700 tokens if non-empty)
    3. Existing state        (~1500 tokens for /specify-next, /plan-next)
    4. User input            (~500 tokens)
    5. Gold chunks           (fill remaining budget up to top_k)
    6. Output buffer         (reserve ~1500 tokens for response)
    """

    OUTPUT_RESERVE = 1_500
    ZONE0_RESERVE = 900    # Protect Zone 0 from being exceeded

    def build_for_task(
        self,
        task: str,
        zone0_prompt: str,
        gold_chunks: list[Chunk],
        zone2_kb: str = "",
        user_input: str = "",
        existing_state: str = "",
    ) -> BuiltContext:
        """
        Assemble context for a given task within the token budget.
        Returns BuiltContext with the assembled text, token count, sources, and breakdown.
        """
        budget = MAX_BUDGET - self.OUTPUT_RESERVE  # Usable budget
        breakdown: dict[str, int] = {}
        sources: list[str] = []
        parts: list[str] = []

        # 1. Zone 0 task prompt — NEVER cut
        z0_tokens = count_tokens(zone0_prompt)
        if z0_tokens > self.ZONE0_RESERVE:
            logger.warning(f"Zone 0 prompt exceeds reserve ({z0_tokens} > {self.ZONE0_RESERVE})")
        parts.append(zone0_prompt)
        breakdown["zone0_prompt"] = z0_tokens
        budget -= z0_tokens

        # 2. Existing state (for /specify-next, /plan-next, /audit)
        if existing_state:
            es_tokens = count_tokens(existing_state)
            if es_tokens <= budget:
                parts.append("\n\n---\n## Existing State\n" + existing_state)
                breakdown["existing_state"] = es_tokens
                budget -= es_tokens
            else:
                truncated = self._truncate_to_tokens(existing_state, budget - 50)
                parts.append("\n\n---\n## Existing State (truncated)\n" + truncated)
                breakdown["existing_state"] = count_tokens(truncated)
                budget -= breakdown["existing_state"]
                logger.warning("Existing state truncated to fit budget")

        # 3. Zone 2 local-kb
        if zone2_kb:
            z2_tokens = count_tokens(zone2_kb)
            if z2_tokens <= budget:
                parts.append("\n\n---\n## Project Knowledge Base (Zone 2)\n" + zone2_kb)
                breakdown["zone2_kb"] = z2_tokens
                budget -= z2_tokens
            else:
                logger.info("Zone 2 KB skipped (not enough budget)")

        # 4. User input
        if user_input:
            ui_tokens = count_tokens(user_input)
            if ui_tokens <= budget:
                parts.append("\n\n---\n## Task Input\n" + user_input)
                breakdown["user_input"] = ui_tokens
                budget -= ui_tokens

        # 5. Gold chunks — fill remaining budget
        if gold_chunks:
            gold_text_parts = []
            gold_tokens_used = 0
            header = "\n\n---\n## Retrieved Knowledge (Gold Layer)\n"
            header_tokens = count_tokens(header)
            budget -= header_tokens

            for chunk in gold_chunks:
                chunk_text = self._format_chunk(chunk)
                ct = count_tokens(chunk_text)
                if gold_tokens_used + ct > budget:
                    logger.info(f"Gold budget exhausted after {len(gold_text_parts)} chunks")
                    break
                gold_text_parts.append(chunk_text)
                gold_tokens_used += ct
                sources.append(chunk.source)

            if gold_text_parts:
                parts.append(header + "\n".join(gold_text_parts))
                breakdown["gold_chunks"] = gold_tokens_used + header_tokens

        # Assemble
        final_text = "\n".join(parts)
        total_tokens = count_tokens(final_text)
        breakdown["output_reserve"] = self.OUTPUT_RESERVE
        is_over = total_tokens + self.OUTPUT_RESERVE > MAX_BUDGET

        if is_over:
            logger.error(f"Context OVER BUDGET: {total_tokens + self.OUTPUT_RESERVE} > {MAX_BUDGET}")

        return BuiltContext(
            text=final_text,
            token_count=total_tokens,
            sources=sources,
            breakdown=breakdown,
            is_over_budget=is_over,
        )

    @staticmethod
    def _format_chunk(chunk: Chunk) -> str:
        stale = " *(offline, may be stale)*" if chunk.score == 0.0 else ""
        return (
            f"\n### {chunk.pattern_type} [{chunk.domain}]{stale}\n"
            f"{chunk.content}\n"
            f"*Source: {chunk.source} | Relevance: {chunk.score:.2f}*\n"
        )

    @staticmethod
    def _truncate_to_tokens(text: str, max_tokens: int) -> str:
        """Truncate text to approximately max_tokens."""
        # ~4 chars per token
        max_chars = max_tokens * 4
        if len(text) <= max_chars:
            return text
        return text[:max_chars] + "\n...(truncated for token budget)"
