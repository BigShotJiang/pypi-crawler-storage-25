"""
Token counter using tiktoken.
Falls back to character-based estimate if tiktoken unavailable.
"""
from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

# Try to load tiktoken; graceful fallback for offline/no-install environments
try:
    import tiktoken
    _ENC = tiktoken.get_encoding("cl100k_base")  # Used by claude models as rough proxy
    _TIKTOKEN_AVAILABLE = True
except Exception:
    _ENC = None
    _TIKTOKEN_AVAILABLE = False
    logger.debug("tiktoken not available, using char-based token estimate")


def count_tokens(text: str) -> int:
    """
    Count tokens in a text string.
    Uses tiktoken cl100k_base if available, else ~4 chars/token estimate.
    """
    if not text:
        return 0
    if _TIKTOKEN_AVAILABLE and _ENC:
        return len(_ENC.encode(text))
    # Fallback: ~1 token per 4 chars (conservative)
    return max(1, len(text) // 4)


def count_tokens_for_messages(messages: list[dict]) -> int:
    """Count total tokens across a list of {role, content} messages."""
    total = 0
    for msg in messages:
        total += count_tokens(msg.get("content", ""))
        total += 4  # Per-message overhead
    return total


def tokens_remaining(used: int, budget: int = 8_000) -> int:
    return max(0, budget - used)


def format_token_report(breakdown: dict[str, int], budget: int = 8_000) -> str:
    """Return a human-readable token budget breakdown."""
    total = sum(breakdown.values())
    lines = [f"Token Budget Report (budget={budget}):", ""]
    for zone, tokens in breakdown.items():
        pct = tokens / budget * 100
        bar = "█" * int(pct / 5)
        lines.append(f"  {zone:<20} {tokens:>5} tokens  {bar} {pct:.1f}%")
    lines.append("")
    status = "✅ Under budget" if total <= budget else f"❌ OVER BUDGET by {total - budget}"
    lines.append(f"  {'TOTAL':<20} {total:>5} tokens  {status}")
    return "\n".join(lines)
