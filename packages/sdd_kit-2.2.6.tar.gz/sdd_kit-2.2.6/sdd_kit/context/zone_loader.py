"""
Zone Loader — loads context from each zone on demand.
Rule 07: No full files. No repeated instructions.
"""
from __future__ import annotations

import logging
from pathlib import Path

logger = logging.getLogger(__name__)


class ZoneLoader:
    """
    Loads content from the three knowledge zones on demand:
    - Zone 0: bundled core (constitution, prompts, templates)
    - Zone 1: local cache (Gold chunks, schemas)
    - Zone 2: project local-kb (data-models.md, gotchas.md, etc.)
    """

    def __init__(self, project_root: Path | None = None):
        from sdd_kit.utils.config import get_zone0_dir, get_zone2_dir
        self._zone0 = get_zone0_dir()
        self._zone2 = get_zone2_dir(project_root)

    # ── Zone 0 ───────────────────────────────────────────────────────────────

    def load_task_prompt(self, task: str) -> str:
        """
        Load ONLY the task-specific prompt (~800 tokens).
        task: 'specify' | 'plan' | 'audit' | 'specify-next' | 'plan-next' |
              'integrate' | 'validate' | 'classify'
        """
        prompt_path = self._zone0 / "ai-prompts" / f"{task}-prompt.md"
        if prompt_path.exists():
            content = prompt_path.read_text(encoding="utf-8")
            logger.debug(f"Loaded Zone 0 prompt: {prompt_path} ({len(content)} chars)")
            return content
        logger.warning(f"Zone 0 prompt not found: {prompt_path}")
        return f"# {task.title()} Task\nComplete the {task} task following SDD methodology."

    def load_template(self, template_name: str) -> str:
        """Load a Zone 0 template file."""
        path = self._zone0 / "templates" / f"{template_name}.md"
        if path.exists():
            return path.read_text(encoding="utf-8")
        logger.warning(f"Template not found: {path}")
        return ""

    def load_constitution(self) -> str:
        """
        Load constitution.md as REFERENCE only — never inject into per-turn context.
        Call only when user explicitly requests it.
        """
        path = self._zone0 / "constitution.md"
        if path.exists():
            return path.read_text(encoding="utf-8")
        return "# SDD Constitution\n(not found)"

    # ── Zone 2 ───────────────────────────────────────────────────────────────

    def load_zone2_kb(self, max_chars: int = 2800) -> str:
        """
        Load project local-kb files into a single string (~700 tokens).
        Priority order: data-models.md, integration-learnings.md, gotchas.md, decisions.md
        """
        priority_files = [
            "data-models.md",
            "integration-learnings.md",
            "gotchas.md",
            "decisions.md",
            "audit-findings.md",
        ]
        collected = []
        total = 0
        for fname in priority_files:
            path = self._zone2 / fname
            if path.exists():
                content = path.read_text(encoding="utf-8")
                if total + len(content) > max_chars:
                    # Truncate to fit budget
                    content = content[: max_chars - total] + "\n...(truncated)"
                collected.append(f"### {fname}\n{content}")
                total += len(content)
                if total >= max_chars:
                    break
        return "\n\n".join(collected)

    def has_zone2_kb(self) -> bool:
        return self._zone2.exists() and any(self._zone2.glob("*.md"))

    # ── Zone 2 writers ───────────────────────────────────────────────────────

    def write_zone2_file(self, filename: str, content: str) -> Path:
        """Write or update a Zone 2 local-kb file."""
        self._zone2.mkdir(parents=True, exist_ok=True)
        path = self._zone2 / filename
        path.write_text(content, encoding="utf-8")
        return path

    def append_zone2_file(self, filename: str, content: str) -> Path:
        """Append to a Zone 2 local-kb file."""
        self._zone2.mkdir(parents=True, exist_ok=True)
        path = self._zone2 / filename
        existing = path.read_text(encoding="utf-8") if path.exists() else ""
        path.write_text(existing + "\n\n" + content, encoding="utf-8")
        return path
