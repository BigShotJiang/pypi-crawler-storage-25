"""
sdd-kit MCP Server
Exposes all 16 sdd commands as MCP tools callable from Cursor / VS Code / Claude Desktop.

Usage:
  sdd serve           # starts the MCP server (stdio transport, for Cursor/Claude Desktop)
  sdd serve --port 8080  # starts with SSE transport (for web-based clients)
"""
from __future__ import annotations

import json
import os
from pathlib import Path


def create_server():
    """
    Build and return the FastMCP server with all sdd-kit tools registered.
    Called once at startup.
    """
    try:
        from mcp.server.fastmcp import FastMCP
    except ImportError:
        raise RuntimeError(
            "MCP package not installed. Run: pip install 'sdd-kit[mcp]' or pip install mcp"
        )

    mcp = FastMCP(
        "sdd-kit",
        instructions=(
            "SDD-Kit is a Spec-Driven Development assistant. "
            "Use these tools to initialize projects, generate specs and plans, "
            "audit existing codebases, and manage the knowledge base. "
            "All tools work offline with --dry_run=True."
        ),
    )

    # ──────────────────────────────────────────────────────────────────────────
    # NEW PROJECT TOOLS
    # ──────────────────────────────────────────────────────────────────────────

    @mcp.tool()
    def sdd_init(
        project_name: str,
        domain: str = "generic",
        here: bool = False,
    ) -> str:
        """
        Initialize a new SDD project. Creates .sdd/, .clinerules, and gather-context.yaml.
        
        Use this when starting a brand new project from scratch.
        Supported domains: banking, ecommerce, retail, logistics, healthcare, generic
        
        Example: sdd_init("my-banking-app", "banking")
        """
        from sdd_kit.commands.new_project.init import run
        result_path = run(project_name=project_name, domain=domain, here=here)
        return f"✅ Project '{project_name}' initialized at {result_path}\nNext: fill gather-context.yaml then call sdd_gather()"

    @mcp.tool()
    def sdd_gather(non_interactive: bool = True) -> str:
        """
        Guide context collection for the current project (fills gather-context.yaml).
        
        Call this after sdd_init() to review and complete the project context before generating spec.
        Set non_interactive=True to skip prompts and use the existing file.
        """
        from sdd_kit.commands.new_project.gather import run
        path = run(non_interactive=non_interactive)
        content = path.read_text(encoding="utf-8") if path.exists() else ""
        return f"✅ gather-context.yaml ready at {path}\n\nContent preview:\n```yaml\n{content[:1500]}\n```"

    @mcp.tool()
    def sdd_specify(
        domain: str = "generic",
        dry_run: bool = False,
        platform: str = "mock",
    ) -> str:
        """
        Generate spec.md for the current project using AI + Gold context.
        
        Reads gather-context.yaml → retrieves Gold knowledge → calls AI → writes spec.md.
        Token budget: ~8,000 tokens (Zone0 800 + Gold 3000 + Zone2 700 + output 1500).
        Use dry_run=True to preview context assembly without calling the AI API.
        
        Requires: gather-context.yaml in current directory
        Requires: ANTHROPIC_API_KEY env var (unless dry_run=True)
        """
        from sdd_kit.commands.new_project.specify import run
        # We return the prompt so the IDE chatbot can handle the generation
        return run(domain=domain, dry_run=dry_run, platform_name=platform, return_prompt=True)

    @mcp.tool()
    def sdd_plan(
        dry_run: bool = False,
        platform: str = "mock",
    ) -> str:
        """
        Generate plan.md + tasks.md from the current spec.md.
        """
        from sdd_kit.commands.new_project.plan import run
        return run(dry_run=dry_run, platform_name=platform, return_prompt=True)

    @mcp.tool()
    def sdd_integrate(
        retro: bool = False,
        dry_run: bool = False,
        platform: str = "mock",
    ) -> str:
        """
        Generate an integration skeleton from Silver schema.
        
        Set retro=True for existing projects (reverse-engineer existing integrations).
        Set retro=False (default) for new projects (generate skeleton from spec).
        """
        if retro:
            from sdd_kit.commands.existing_project.retro_integrate import run
        else:
            from sdd_kit.commands.new_project.integrate import run
        path = run(dry_run=dry_run, platform_name=platform)
        return f"✅ Integration skeleton generated → {path}"

    @mcp.tool()
    def sdd_validate() -> str:
        """
        Validate spec.md for completeness and correctness.
        
        Checks: all 6 sections present, AC items measurable, no invented field names.
        Returns exit status and full validation report.
        This tool is fully OFFLINE — no API key needed.
        """
        from sdd_kit.commands.new_project.validate import run
        import io
        from contextlib import redirect_stdout
        code = run()
        status = "✅ PASSED" if code == 0 else "❌ FAILED"
        return f"Validation result: {status} (exit code {code})"

    @mcp.tool()
    def sdd_estimate(task: str = "") -> str:
        """
        Show token budget breakdown for all sdd commands (fully offline, no API needed).
        
        Optionally specify a task name (e.g. '/specify', '/plan') for a specific breakdown.
        """
        from sdd_kit.commands.new_project.estimate import BUDGETS, MAX_BUDGET
        if task and task in BUDGETS:
            budgets = {task: BUDGETS[task]}
        else:
            budgets = BUDGETS
        lines = ["## Token Budget Estimates (8,000 token max)\n"]
        for cmd, b in budgets.items():
            total = sum(b.values())
            status = "✅" if total <= MAX_BUDGET else "❌ OVER"
            lines.append(f"**{cmd}**: Zone0={b['zone0']} Gold={b['gold']} Zone2={b['zone2']} Output={b['output']} → **{total}** {status}")
        return "\n".join(lines)

    @mcp.tool()
    def sdd_sync_kb(domain: str = "generic", platform: str = "mock") -> str:
        """
        Sync the local Gold knowledge cache from the lakehouse (delta only).
        
        Use this to update cached knowledge for a specific domain before running /specify.
        Works offline — if platform unreachable, reports stale status.
        """
        from sdd_kit.commands.new_project.sync_kb import run
        summary = run(domain=domain, platform_name=platform)
        offline = " (offline, may be stale)" if summary.get("offline") else ""
        return f"✅ KB sync complete{offline}\nDomain: {domain} | Chunks synced: {summary.get('chunks_synced', 0)} | Time: {summary.get('timestamp', '')}"

    @mcp.tool()
    def sdd_upload_kb(
        file_path: str = "",
        dry_run: bool = False,
        platform: str = "mock",
    ) -> str:
        """
        Classify and upload a learning document to the Bronze knowledge base.
        
        If file_path is empty, auto-selects documents from .sdd/local-kb/.
        Use dry_run=True to preview classification without uploading.
        """
        from sdd_kit.commands.new_project.upload_kb import run
        path = Path(file_path) if file_path else None
        uuids = run(file_path=path, dry_run=dry_run, platform_name=platform)
        return f"✅ Uploaded {len(uuids)} records → UUIDs: {uuids}"

    # ──────────────────────────────────────────────────────────────────────────
    # EXISTING PROJECT TOOLS
    # ──────────────────────────────────────────────────────────────────────────

    @mcp.tool()
    def sdd_onboard() -> str:
        """
        Onboard an existing project into SDD. Creates .sdd/ without modifying existing files.
        
        Run this in an existing project directory before running /audit.
        Rule 08: Never modifies existing files — 100% surgical.
        """
        from sdd_kit.commands.existing_project.onboard import run
        sdd_dir = run()
        return f"✅ Project onboarded → {sdd_dir}\nNext: call sdd_audit() to analyze existing codebase"

    @mcp.tool()
    def sdd_audit(
        dry_run: bool = False,
        platform: str = "mock",
    ) -> str:
        """
        Audit an existing codebase for SDD compliance.
        """
        from sdd_kit.commands.existing_project.audit import run
        return run(dry_run=dry_run, platform_name=platform, return_prompt=True)

    @mcp.tool()
    def sdd_specify_next(
        goals: str = "",
        dry_run: bool = False,
        platform: str = "mock",
    ) -> str:
        """
        Generate spec-next.md — a delta spec for the NEXT phase.
        """
        from sdd_kit.commands.existing_project.specify_next import run
        return run(next_goals=goals, dry_run=dry_run, platform_name=platform, return_prompt=True)

    @mcp.tool()
    def sdd_plan_next(
        dry_run: bool = False,
        platform: str = "mock",
    ) -> str:
        """
        Generate plan-next.md + tasks-next.md — delta plan for the next phase.
        """
        from sdd_kit.commands.existing_project.plan_next import run
        return run(dry_run=dry_run, platform_name=platform, return_prompt=True)

    # ──────────────────────────────────────────────────────────────────────────
    # SKILLS + DIAGNOSTICS TOOLS
    # ──────────────────────────────────────────────────────────────────────────

    @mcp.tool()
    def sdd_skills_list() -> str:
        """
        List all available SDD skills with their descriptions and availability status.
        
        Skills are Layer 2 knowledge files loaded on-demand by AI commands.
        All 9 skills: specify, plan, audit, specify-next, plan-next, integrate, validate, classify, retro-integrate.
        """
        from sdd_kit.skills.registry import SkillsRegistry
        skills = SkillsRegistry.list_skills()
        lines = ["## SDD-Kit Skills (Layer 2)\n"]
        for s in skills:
            status = "✅" if s["available"] else "❌"
            lines.append(f"{status} **{s['name']}** — {s['desc']} ({s['size_bytes']} bytes)")
        return "\n".join(lines)

    @mcp.tool()
    def sdd_skills_inspect(name: str) -> str:
        """
        Read the full content of a skill file.
        
        Use this to understand how a specific AI task is configured.
        Example names: 'specify-skill', 'plan-skill', 'audit-skill'
        """
        from sdd_kit.skills.registry import SkillsRegistry
        content = SkillsRegistry.load_skill_file(name)
        if not content:
            return f"❌ Skill '{name}' not found. Run sdd_skills_list() to see available skills."
        return f"## {name}\n\n{content}"

    @mcp.tool()
    def sdd_doctor() -> str:
        """
        Check the environment for required tools and configuration.
        
        Verifies: Python version, git, uv, anthropic SDK, ANTHROPIC_API_KEY, DATABRICKS credentials.
        """
        import subprocess
        import sys
        lines = ["## SDD-Kit Environment Check\n"]

        checks = [("python", [sys.executable, "--version"]), ("git", ["git", "--version"])]
        for name, cmd in checks:
            try:
                r = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
                icon = "✅" if r.returncode == 0 else "❌"
                lines.append(f"{icon} **{name}**: {r.stdout.strip() or r.stderr.strip()}")
            except Exception as e:
                lines.append(f"❌ **{name}**: {e}")

        env_vars = [
            ("ANTHROPIC_API_KEY", True),
            ("DATABRICKS_HOST", False),
            ("DATABRICKS_TOKEN", False),
        ]
        lines.append("")
        for var, required in env_vars:
            val = os.environ.get(var, "")
            if val:
                lines.append(f"✅ **{var}**: set")
            elif required:
                lines.append(f"❌ **{var}**: NOT SET — required for AI commands")
            else:
                lines.append(f"⚠️ **{var}**: not set (optional)")

        return "\n".join(lines)

    @mcp.tool()
    def sdd_read_spec() -> str:
        """
        Read and return the current project's spec.md content.
        
        Use this to review the current specification before making changes.
        """
        spec = Path.cwd() / "spec.md"
        if not spec.exists():
            return "❌ spec.md not found. Run sdd_specify() first."
        return f"## spec.md\n\n{spec.read_text(encoding='utf-8')}"

    @mcp.tool()
    def sdd_read_plan() -> str:
        """
        Read and return the current project's plan.md content.
        """
        plan = Path.cwd() / "plan.md"
        if not plan.exists():
            return "❌ plan.md not found. Run sdd_plan() first."
        return f"## plan.md\n\n{plan.read_text(encoding='utf-8')}"

    return mcp


def run_stdio():
    """Run MCP server with stdio transport (for Cursor, Claude Desktop)."""
    server = create_server()
    server.run(transport="stdio")


def run_sse(port: int = 8080):
    """Run MCP server with SSE transport (for web-based clients)."""
    server = create_server()
    server.run(transport="sse", port=port)
