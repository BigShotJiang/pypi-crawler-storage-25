"""
sdd-kit v2.0 CLI — Entry point, 16 commands.
Rules loaded once at import (Rule 07).
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

app = typer.Typer(
    name="sdd",
    help="sdd-kit v2.0 — Spec-Driven Development CLI with AI-assisted lakehouse context",
    add_completion=True,
    no_args_is_help=True,
    rich_markup_mode="rich",
)

skills_app = typer.Typer(name="skills", help="Manage SDD skills (Layer 2)")
app.add_typer(skills_app, name="skills")

console = Console()

# ── Common options ─────────────────────────────────────────────────────────────
_verbose = typer.Option(False, "--verbose", "-v", help="Show debug output")
_dry_run = typer.Option(False, "--dry-run", help="Assemble context but don't call AI")
_prompt = typer.Option(False, "--prompt", help="Output only the assembled prompt for IDE chatbot use")
_platform = typer.Option("mock", "--platform", help="Platform: mock | databricks | snowflake")
_domain = typer.Option("generic", "--domain", help="Domain: banking | ecommerce | retail | logistics | healthcare | generic")


# ══════════════════════════════════════════════════════════════════════════════
# NEW PROJECT COMMANDS
# ══════════════════════════════════════════════════════════════════════════════

@app.command("init")
def cmd_init(
    project_name: str = typer.Argument(..., help="Project name"),
    domain: str = _domain,
    here: bool = typer.Option(False, "--here", help="Init in current directory"),
    verbose: bool = _verbose,
):
    """[NEW] Initialize a new SDD project (≤45s). Creates .sdd/, .clinerules, gather-context.yaml."""
    from sdd_kit.utils.logger import setup_logging
    setup_logging(verbose)
    from sdd_kit.commands.new_project.init import run
    run(project_name=project_name, domain=domain, here=here, verbose=verbose)


@app.command("gather")
def cmd_gather(
    non_interactive: bool = typer.Option(False, "--non-interactive", help="Skip prompts, use existing file"),
    verbose: bool = _verbose,
):
    """[NEW] Fill gather-context.yaml interactively (≤3m)."""
    from sdd_kit.utils.logger import setup_logging
    setup_logging(verbose)
    from sdd_kit.commands.new_project.gather import run
    try:
        run(non_interactive=non_interactive)
    except FileNotFoundError:
        raise typer.Exit(code=1)


@app.command("specify")
def cmd_specify(
    domain: str = _domain,
    dry_run: bool = _dry_run,
    platform: str = _platform,
    verbose: bool = _verbose,
    prompt: bool = _prompt,
):
    """[NEW] Generate spec.md from gather-context.yaml (≤60s). Context: Zone0 + Gold + Zone2."""
    from sdd_kit.utils.logger import setup_logging
    setup_logging(verbose)
    from sdd_kit.commands.new_project.specify import run
    try:
        result = run(domain=domain, dry_run=dry_run, platform_name=platform, return_prompt=prompt)
    except FileNotFoundError:
        raise typer.Exit(code=1)
    if prompt:
        print(result)


@app.command("plan")
def cmd_plan(
    dry_run: bool = _dry_run,
    platform: str = _platform,
    verbose: bool = _verbose,
    prompt: bool = _prompt,
):
    """[NEW] Generate plan.md + tasks.md from spec.md (~2m, two AI calls)."""
    from sdd_kit.utils.logger import setup_logging
    setup_logging(verbose)
    from sdd_kit.commands.new_project.plan import run
    try:
        result = run(dry_run=dry_run, platform_name=platform, return_prompt=prompt)
    except FileNotFoundError:
        raise typer.Exit(code=1)
    if prompt:
        print(result)


@app.command("integrate")
def cmd_integrate(
    retro: bool = typer.Option(False, "--retro", help="Reverse-engineer existing integrations"),
    dry_run: bool = _dry_run,
    platform: str = _platform,
    verbose: bool = _verbose,
    prompt: bool = _prompt,
):
    """[NEW/EXISTING] Generate integration skeleton from Silver schema (~1m). Use --retro for existing projects."""
    from sdd_kit.utils.logger import setup_logging
    setup_logging(verbose)
    if retro:
        from sdd_kit.commands.existing_project.retro_integrate import run
    else:
        from sdd_kit.commands.new_project.integrate import run
    try:
        result = run(dry_run=dry_run, platform_name=platform, return_prompt=prompt)
    except FileNotFoundError:
        raise typer.Exit(code=1)
    if prompt:
        print(result)


@app.command("validate")
def cmd_validate(
    check_catalog: bool = typer.Option(False, "--check-catalog", help="Validate against live catalog"),
    verbose: bool = _verbose,
):
    """[NEW] Validate spec.md completeness (~30s). Returns exit code 0 (pass) or 1 (fail)."""
    from sdd_kit.utils.logger import setup_logging
    setup_logging(verbose)
    from sdd_kit.commands.new_project.validate import run
    code = run(check_catalog=check_catalog)
    raise typer.Exit(code=code)


@app.command("estimate")
def cmd_estimate(
    task: Optional[str] = typer.Argument(None, help="Specific task to estimate (e.g. /specify)"),
    verbose: bool = _verbose,
):
    """[NEW] Show token budget breakdown for all commands (~10s, offline)."""
    from sdd_kit.commands.new_project.estimate import run
    run(task=task)


@app.command("sync-kb")
def cmd_sync_kb(
    domain: str = _domain,
    platform: str = _platform,
    verbose: bool = _verbose,
):
    """[NEW] Sync Gold knowledge cache from lakehouse (≤30s, delta only)."""
    from sdd_kit.utils.logger import setup_logging
    setup_logging(verbose)
    from sdd_kit.commands.new_project.sync_kb import run
    run(domain=domain, platform_name=platform)


@app.command("upload-kb")
def cmd_upload_kb(
    file: Optional[Path] = typer.Argument(None, help="Path to document to upload"),
    dry_run: bool = _dry_run,
    platform: str = _platform,
    verbose: bool = _verbose,
):
    """[NEW] Classify and upload learning document to Bronze KB (≤45s)."""
    from sdd_kit.utils.logger import setup_logging
    setup_logging(verbose)
    from sdd_kit.commands.new_project.upload_kb import run
    try:
        run(file_path=file, dry_run=dry_run, platform_name=platform)
    except FileNotFoundError:
        raise typer.Exit(code=1)


# ══════════════════════════════════════════════════════════════════════════════
# EXISTING PROJECT COMMANDS
# ══════════════════════════════════════════════════════════════════════════════

@app.command("onboard")
def cmd_onboard(
    verbose: bool = _verbose,
):
    """[EXISTING] Onboard an existing project into SDD (≤30s). Creates .sdd/ — never modifies existing files."""
    from sdd_kit.utils.logger import setup_logging
    setup_logging(verbose)
    from sdd_kit.commands.existing_project.onboard import run
    run(verbose=verbose)


@app.command("audit")
def cmd_audit(
    dry_run: bool = _dry_run,
    platform: str = _platform,
    verbose: bool = _verbose,
    prompt: bool = _prompt,
):
    """[EXISTING] Audit existing codebase for SDD compliance (≤90s). Generates audit.md."""
    from sdd_kit.utils.logger import setup_logging
    setup_logging(verbose)
    from sdd_kit.commands.existing_project.audit import run
    result = run(dry_run=dry_run, platform_name=platform, return_prompt=prompt)
    if prompt:
        print(result)


@app.command("specify-next")
def cmd_specify_next(
    goals: str = typer.Option("", "--goals", help="Next phase goals (overrides interactive prompt)"),
    dry_run: bool = _dry_run,
    platform: str = _platform,
    verbose: bool = _verbose,
    prompt: bool = _prompt,
):
    """[EXISTING] Generate delta spec (spec-next.md) for existing project (≤60s)."""
    from sdd_kit.utils.logger import setup_logging
    setup_logging(verbose)
    from sdd_kit.commands.existing_project.specify_next import run
    try:
        result = run(next_goals=goals, dry_run=dry_run, platform_name=platform, return_prompt=prompt)
    except FileNotFoundError:
        raise typer.Exit(code=1)
    if prompt:
        print(result)


@app.command("plan-next")
def cmd_plan_next(
    dry_run: bool = _dry_run,
    platform: str = _platform,
    verbose: bool = _verbose,
    prompt: bool = _prompt,
):
    """[EXISTING] Generate delta plan (plan-next.md + tasks-next.md) for existing project (≤60s)."""
    from sdd_kit.utils.logger import setup_logging
    setup_logging(verbose)
    from sdd_kit.commands.existing_project.plan_next import run
    try:
        result = run(dry_run=dry_run, platform_name=platform, return_prompt=prompt)
    except FileNotFoundError:
        raise typer.Exit(code=1)
    if prompt:
        print(result)


# ══════════════════════════════════════════════════════════════════════════════
# SKILLS COMMANDS
# ══════════════════════════════════════════════════════════════════════════════

@skills_app.command("list")
def cmd_skills_list():
    """List all available SDD skills (Layer 1 + Layer 2 status)."""
    from sdd_kit.skills.list import run
    run()


@skills_app.command("inspect")
def cmd_skills_inspect(
    name: str = typer.Argument(..., help="Skill name (e.g. specify-skill)"),
):
    """Inspect a skill file (Layer 2 detail)."""
    from sdd_kit.skills.inspect import run
    run(name)


@skills_app.command("refine")
def cmd_skills_refine(
    name: str = typer.Argument(..., help="Skill name to refine"),
):
    """Open a skill file for editing (Rule 10: failures are skill inputs)."""
    from sdd_kit.skills.refine import run
    run(name)


# ══════════════════════════════════════════════════════════════════════════════
# DIAGNOSTIC COMMANDS
# ══════════════════════════════════════════════════════════════════════════════

@app.command("doctor")
def cmd_doctor(verbose: bool = _verbose):
    """Check environment: Python, uv, git, anthropic, databricks-sdk."""
    console.print("[bold blue]🩺 Checking environment...[/]\n")

    checks = [
        ("python", ["python3", "--version"]),
        ("git", ["git", "--version"]),
        ("uv", ["uv", "--version"]),
    ]

    all_ok = True
    for name, cmd in checks:
        try:
            result = subprocess.run(cmd, capture_output=True, text=True)
            if result.returncode == 0:
                console.print(f"[green]  ✅ {name:<20} {result.stdout.strip()}[/]")
            else:
                console.print(f"[red]  ❌ {name:<20} error (code {result.returncode})[/]")
                all_ok = False
        except Exception:
            console.print(f"[red]  ❌ {name:<20} not found[/]")
            all_ok = False

    # Check Python packages
    packages = ["anthropic", "databricks", "tiktoken", "yaml", "typer"]
    for pkg in packages:
        try:
            __import__(pkg.replace("-", "_").replace("databricks", "databricks.sdk"))
            console.print(f"[green]  ✅ {pkg:<20} installed[/]")
        except ImportError:
            status = "[yellow]  ⚠️ [/]" if pkg in ["databricks", "tiktoken"] else "[red]  ❌[/]"
            console.print(f"{status} {pkg:<20} not installed")
            if pkg in ["anthropic"]:
                all_ok = False

    # Check env vars
    import os
    env_checks = [
        ("ANTHROPIC_API_KEY", os.environ.get("ANTHROPIC_API_KEY"), True),
        ("DATABRICKS_HOST", os.environ.get("DATABRICKS_HOST"), False),
        ("DATABRICKS_TOKEN", os.environ.get("DATABRICKS_TOKEN"), False),
    ]
    console.print()
    for var, val, required in env_checks:
        if val:
            console.print(f"[green]  ✅ {var:<25} set[/]")
        elif required:
            console.print(f"[red]  ❌ {var:<25} NOT SET (required for AI calls)[/]")
            all_ok = False
        else:
            console.print(f"[yellow]  ⚠️  {var:<25} not set (optional for databricks)[/]")

    console.print()
    if all_ok:
        console.print("[bold green]✨ Environment ready for sdd-kit v2.0![/]")
    else:
        console.print("[bold yellow]⚠️  Some issues found. AI commands require ANTHROPIC_API_KEY.[/]")
        console.print("[dim]Tip: All commands work offline with --dry-run or --platform mock[/]")


@app.command("install-extension")
def cmd_install_extension():
    """Install the VS Code extension directly from the Python package."""
    from sdd_kit.commands.utils.install_extension import run
    run()


@app.command("version")
def cmd_version():
    """Show sdd-kit version."""
    from sdd_kit import __version__
    console.print(f"[bold]sdd-kit[/] v{__version__}")


@app.command("serve")
def cmd_serve(
    port: Optional[int] = typer.Option(None, "--port", "-p", help="Port for SSE transport (default: stdio)"),
    debug: bool = typer.Option(False, "--debug", help="Enable debug logging"),
):
    """
    Start the sdd-kit MCP server for VS Code / Cursor / Claude Desktop integration.

    Exposes all sdd commands as AI-callable tools (slash commands in chat).

    Add to ~/.cursor/mcp.json or VS Code settings to enable @sdd-kit in chat.
    """
    if debug:
        import logging
        logging.basicConfig(level=logging.DEBUG)

    console.print("[bold blue]🚀 Starting sdd-kit MCP server...[/]")
    console.print("[dim]Tools registered: sdd_init, sdd_specify, sdd_plan, sdd_audit, sdd_validate + 12 more[/]")

    try:
        from sdd_kit.mcp.server import run_stdio, run_sse
    except ImportError:
        console.print("[red]❌ MCP package not installed. Run: pip install 'mcp>=1.0.0'[/]")
        raise typer.Exit(code=1)

    if port:
        console.print(f"[green]SSE transport on port {port}[/]")
        run_sse(port=port)
    else:
        console.print("[green]stdio transport (Cursor / Claude Desktop mode)[/]")
        run_stdio()


if __name__ == "__main__":
    app()
