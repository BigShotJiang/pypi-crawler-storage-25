"""
sdd /plan
Generate plan.md + tasks.md from spec.md. Two AI calls (~2m).
"""
from __future__ import annotations

from pathlib import Path

from rich.console import Console

console = Console()


def run(
    project_root: Path | None = None,
    dry_run: bool = False,
    return_prompt: bool = False,
    platform_name: str = "mock",
) -> tuple[Path, Path] | str:
    """
    Generate plan.md and tasks.md.
    Returns (plan_path, tasks_path).
    """
    root = project_root or Path.cwd()
    spec_path = root / "spec.md"

    if not spec_path.exists():
        console.print("[red]❌ spec.md not found. Run 'sdd /specify' first.[/]")
        raise FileNotFoundError("spec.md not found")

    spec_content = spec_path.read_text(encoding="utf-8")
    domain = _detect_domain(spec_content)

    console.print(f"[bold blue]📋 Generating plan.md + tasks.md (domain={domain})...[/]")

    from sdd_kit.agent.orchestrator import Orchestrator
    orch = Orchestrator(project_root=root, platform_name=platform_name)

    # Call 1: plan.md
    console.print("[dim]  Call 1/2: Generating plan.md...[/]")
    plan_result = orch.run_task(
        task="plan",
        user_input=f"Generate plan.md and then tasks.md for this spec:\n\n{spec_content}",
        domain=domain,
        top_k=10,
        dry_run=dry_run,
        return_prompt=return_prompt,
    )

    if return_prompt:
        return plan_result
    plan_path = root / "plan.md"
    plan_path.write_text(plan_result, encoding="utf-8")
    console.print(f"[green]  ✓ plan.md[/]")

    # Call 2: tasks.md
    console.print("[dim]  Call 2/2: Generating tasks.md...[/]")
    tasks_result = orch.run_task(
        task="plan",
        user_input=(
            f"Now generate tasks.md (granular task list) for this plan:\n\n{plan_result}\n\n"
            f"Based on spec:\n\n{spec_content[:2000]}"
        ),
        domain=domain,
        top_k=6,
        dry_run=dry_run,
    )
    tasks_path = root / "tasks.md"
    tasks_path.write_text(tasks_result, encoding="utf-8")
    console.print(f"[green]  ✓ tasks.md[/]")

    console.print(f"\n[bold green]✅ plan.md + tasks.md generated[/]")
    console.print("[dim]Next: run 'sdd /integrate' to generate integration skeleton[/]")

    return plan_path, tasks_path


def _detect_domain(spec_content: str) -> str:
    from sdd_kit.utils.config import SUPPORTED_DOMAINS
    content_lower = spec_content.lower()
    for d in SUPPORTED_DOMAINS:
        if d in content_lower:
            return d
    return "generic"
