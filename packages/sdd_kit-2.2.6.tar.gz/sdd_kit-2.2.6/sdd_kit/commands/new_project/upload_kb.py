"""
sdd upload-kb
Classify and upload learning documents to Bronze (≤45s).
"""
from __future__ import annotations

from pathlib import Path

from rich.console import Console

console = Console()


def run(
    file_path: Path | None = None,
    project_root: Path | None = None,
    platform_name: str = "mock",
    dry_run: bool = False,
) -> list[str]:
    """
    Classify a document and upload to Bronze KB.
    Returns list of UUIDs.
    """
    root = project_root or Path.cwd()

    # If no file specified, scan Zone 2 for new learnings
    if file_path is None:
        zone2 = root / ".sdd" / "local-kb"
        candidates = list(zone2.glob("*.md")) if zone2.exists() else []
        if not candidates:
            console.print("[yellow]⚠️  No documents found in .sdd/local-kb/[/]")
            return []
        file_path = candidates[0]
        console.print(f"[dim]Auto-selected: {file_path.name}[/]")

    if not file_path.exists():
        console.print(f"[red]❌ File not found: {file_path}[/]")
        raise FileNotFoundError(f"File not found: {file_path}")

    content = file_path.read_text(encoding="utf-8")
    console.print(f"[bold blue]📤 Uploading {file_path.name} to Bronze KB...[/]")

    from sdd_kit.agent.orchestrator import Orchestrator
    from sdd_kit.lakehouse.kb_sync_adapter import KBSyncAdapter

    orch = Orchestrator(project_root=root, platform_name=platform_name)

    # Classify via AI
    classification_result = orch.run_task(
        task="classify",
        user_input=content,
        dry_run=dry_run,
    )

    if dry_run:
        console.print(f"[dim][DRY RUN] Classification result:\n{classification_result}[/]")
        return ["dry-run-uuid"]

    # Parse classification and upload
    adapter = KBSyncAdapter(orch._platform)
    import json
    try:
        record = json.loads(classification_result)
    except json.JSONDecodeError:
        record = {
            "pattern_type": "integration_pattern",
            "domain": "generic",
            "content": content[:10000],
            "confidence": 0.5,
        }

    records = record if isinstance(record, list) else [record]
    uuids = adapter.upload_learnings(records)

    console.print(f"[green]✓ Uploaded {len(uuids)} records → {uuids}[/]")
    return uuids
