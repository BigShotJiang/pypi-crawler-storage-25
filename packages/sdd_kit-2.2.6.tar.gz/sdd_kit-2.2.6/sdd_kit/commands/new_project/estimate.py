"""
sdd /estimate
Show token budget breakdown for a task (~10s, static, offline).
"""
from __future__ import annotations

from pathlib import Path

from rich.console import Console
from rich.table import Table

console = Console()

# Token budgets per command (from spec)
BUDGETS = {
    "/specify":      {"zone0": 800, "gold": 3000, "zone2": 700, "existing": 0,    "output": 1500},
    "/plan":         {"zone0": 800, "gold": 2000, "zone2": 0,   "existing": 0,    "output": 2000},
    "/audit":        {"zone0": 800, "gold": 2000, "zone2": 0,   "existing": 0,    "output": 3200},
    "/specify-next": {"zone0": 800, "gold": 2500, "zone2": 0,   "existing": 1500, "output": 2700},
    "/plan-next":    {"zone0": 800, "gold": 2000, "zone2": 0,   "existing": 1500, "output": 2700},
    "/integrate":    {"zone0": 800, "gold": 2000, "zone2": 0,   "existing": 0,    "output": 2000},
    "/validate":     {"zone0": 800, "gold": 0,    "zone2": 0,   "existing": 0,    "output": 1500},
}

MAX_BUDGET = 8_000


def run(project_root: Path | None = None, task: str | None = None) -> None:
    """
    Print token budget breakdown for all commands (or a specific one).
    (offline) — static, no API calls.
    """
    console.print("[bold blue]📊 Token Budget Estimate (offline, static)[/]\n")

    table = Table(show_header=True, header_style="bold cyan")
    table.add_column("Command", style="bold")
    table.add_column("Zone0", justify="right")
    table.add_column("Gold", justify="right")
    table.add_column("Zone2", justify="right")
    table.add_column("Existing", justify="right")
    table.add_column("Output", justify="right")
    table.add_column("Total", justify="right")
    table.add_column("Budget", justify="right")

    tasks_to_show = {task: BUDGETS[task]} if task and task in BUDGETS else BUDGETS

    for cmd, b in tasks_to_show.items():
        total = sum(b.values())
        status = "✅" if total <= MAX_BUDGET else "❌"
        table.add_row(
            cmd,
            str(b["zone0"]),
            str(b["gold"]),
            str(b["zone2"]),
            str(b["existing"]),
            str(b["output"]),
            str(total),
            f"{status} {MAX_BUDGET}",
        )

    console.print(table)
    console.print(f"\n[dim]Max budget: {MAX_BUDGET} tokens | All estimates are approximations[/]")

    # Show actual file sizes if project root provided
    root = project_root or Path.cwd()
    spec = root / "spec.md"
    gather = root / "gather-context.yaml"
    if spec.exists():
        tokens = len(spec.read_text(encoding="utf-8")) // 4
        console.print(f"[dim]Current spec.md: ~{tokens} tokens[/]")
    if gather.exists():
        tokens = len(gather.read_text(encoding="utf-8")) // 4
        console.print(f"[dim]Current gather-context.yaml: ~{tokens} tokens[/]")
