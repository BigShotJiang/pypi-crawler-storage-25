"""
sdd /specify
Generate spec.md from gather-context.yaml in ≤60s.
Context: Zone 0 (~800t) + Gold (3K) + Zone 2 (700t) + user input (500t)
"""
from __future__ import annotations

from pathlib import Path

import yaml
from rich.console import Console

console = Console()


def run(
    project_root: Path | None = None,
    domain: str = "generic",
    dry_run: bool = False,
    return_prompt: bool = False,
    platform_name: str = "mock",
) -> Path | str:
    """
    Generate spec.md using AI + Gold context.
    Returns path to the generated spec.md.
    """
    root = project_root or Path.cwd()
    gather_path = root / "gather-context.yaml"

    if not gather_path.exists():
        console.print("[red]❌ gather-context.yaml not found. Run 'sdd /gather' first.[/]")
        raise FileNotFoundError("gather-context.yaml not found")

    gather_content = gather_path.read_text(encoding="utf-8")
    gather_data = yaml.safe_load(gather_content) or {}
    detected_domain = gather_data.get("project", {}).get("domain", domain)

    console.print(f"[bold blue]📝 Generating spec.md (domain={detected_domain})...[/]")

    from sdd_kit.agent.orchestrator import Orchestrator

    orch = Orchestrator(project_root=root, platform_name=platform_name)
    result = orch.run_task(
        task="specify",
        user_input=gather_content,
        domain=detected_domain,
        top_k=12,
        dry_run=dry_run,
        return_prompt=return_prompt,
    )

    if return_prompt:
        return result

    spec_path = root / "spec.md"
    spec_path.write_text(result, encoding="utf-8")

    console.print(f"[green]✓ spec.md generated → {spec_path}[/]")
    console.print("[dim]Next: run 'sdd /plan' to generate implementation plan[/]")

    return spec_path
