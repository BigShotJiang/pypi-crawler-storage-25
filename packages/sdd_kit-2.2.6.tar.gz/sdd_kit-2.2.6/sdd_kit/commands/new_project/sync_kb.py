"""
sdd sync-kb
Sync local Gold cache from lakehouse (≤30s, delta only).
"""
from __future__ import annotations

from pathlib import Path

from rich.console import Console

console = Console()


def run(
    domain: str = "generic",
    project_root: Path | None = None,
    platform_name: str = "mock",
    queries: list[str] | None = None,
) -> dict:
    """
    Sync Gold domain data to Zone 1 local cache.
    Returns sync summary.
    """
    console.print(f"[bold blue]🔄 Syncing KB for domain: {domain}...[/]")

    from sdd_kit.agent.orchestrator import Orchestrator
    from sdd_kit.lakehouse.kb_sync_adapter import KBSyncAdapter

    orch = Orchestrator(project_root=project_root, platform_name=platform_name)
    adapter = KBSyncAdapter(orch._platform)

    summary = adapter.sync_domain(domain=domain, queries=queries)

    if summary["offline"]:
        console.print(f"[yellow]⚠️  (offline, may be stale) Platform unreachable — cache not updated[/]")
    else:
        console.print(f"[green]✓ Synced {summary['chunks_synced']} chunks for '{domain}'[/]")

    console.print(f"[dim]Timestamp: {summary['timestamp']}[/]")
    return summary
