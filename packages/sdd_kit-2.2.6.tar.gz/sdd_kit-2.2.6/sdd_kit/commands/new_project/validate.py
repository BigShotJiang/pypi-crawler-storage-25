"""
sdd /validate
Validate spec.md for completeness. Returns exit code + report (~30s).
"""
from __future__ import annotations

from pathlib import Path

from rich.console import Console

console = Console()

REQUIRED_SECTIONS = [
    "## 1. Overview",
    "## 2. Data Context",
    "## 3. Integration Patterns",
    "## 4. Business Rules",
    "## 5. Acceptance Criteria",
    "## 6. Open Questions",
]


def run(project_root: Path | None = None, check_catalog: bool = False) -> int:
    """
    Validate spec.md. Returns 0 (pass) or 1 (fail).
    """
    root = project_root or Path.cwd()
    spec_path = root / "spec.md"

    if not spec_path.exists():
        console.print("[red]❌ spec.md not found[/]")
        return 1

    content = spec_path.read_text(encoding="utf-8")
    failures: list[str] = []
    warnings: list[str] = []
    passes: list[str] = []

    # Check 1: Required sections
    for section in REQUIRED_SECTIONS:
        # Flexible match (case and numbering)
        section_key = section.split(". ", 1)[-1] if ". " in section else section.lstrip("#").strip()
        if section_key.lower() in content.lower():
            passes.append(f"Section '{section_key}' present")
        else:
            failures.append(f"Section '{section_key}' MISSING")

    # Check 2: Acceptance criteria are measurable
    import re
    ac_pattern = re.compile(r"- AC-\d+:(.+)", re.MULTILINE)
    ac_items = ac_pattern.findall(content)
    for i, ac in enumerate(ac_items, 1):
        # Measurability heuristics: numbers, percentages, pass/fail, specific values
        if re.search(r"\d+|pass|fail|≤|≥|>|<|%|must|shall|should", ac, re.IGNORECASE):
            passes.append(f"AC-{i:02d} is measurable")
        else:
            failures.append(f"AC-{i:02d} may not be measurable: '{ac.strip()[:60]}'")

    if not ac_items:
        failures.append("No Acceptance Criteria (AC-xx) items found")

    # Check 3: Catalog validation (if online and requested)
    if check_catalog:
        warnings.append("(unchecked, offline) Catalog validation requires --platform flag")

    # Report
    console.print("\n[bold]VALIDATION REPORT[/]")
    console.print(f"Spec: {spec_path}\n")

    for msg in passes:
        console.print(f"[green]  [PASS][/] {msg}")
    for msg in warnings:
        console.print(f"[yellow]  [WARN][/] {msg}")
    for msg in failures:
        console.print(f"[red]  [FAIL][/] {msg}")

    if failures:
        console.print(f"\n[bold red]❌ FAILED ({len(failures)} issues)[/]")
        return 1
    else:
        console.print(f"\n[bold green]✅ PASSED ({len(passes)} checks)[/]")
        return 0
