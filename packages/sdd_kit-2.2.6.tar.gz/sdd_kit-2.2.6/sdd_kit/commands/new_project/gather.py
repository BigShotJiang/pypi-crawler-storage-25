"""
sdd /gather
Interactive context gathering — fills gather-context.yaml in ≤3m.
"""
from __future__ import annotations

from pathlib import Path

import yaml
from rich.console import Console
from rich.prompt import Prompt

console = Console()


def run(project_root: Path | None = None, non_interactive: bool = False) -> Path:
    """
    Walk user through gather-context.yaml fields.
    Returns path to the completed gather-context.yaml.
    """
    root = project_root or Path.cwd()
    gather_path = root / "gather-context.yaml"

    if not gather_path.exists():
        console.print("[red]❌ gather-context.yaml not found. Run 'sdd init' first.[/]")
        raise FileNotFoundError(f"gather-context.yaml not found in {root}")

    # Load existing
    existing = yaml.safe_load(gather_path.read_text(encoding="utf-8")) or {}

    if non_interactive:
        console.print(f"[dim](offline, non-interactive) Using existing gather-context.yaml at {gather_path}[/]")
        return gather_path

    console.print("[bold blue]📋 Gather Context — Fill in your project details[/]")
    console.print("[dim]Press Enter to keep existing value. Ctrl+C to cancel.[/]\n")

    proj = existing.get("project", {})

    # Project description
    desc = Prompt.ask(
        "Project description",
        default=proj.get("description", ""),
    )
    existing.setdefault("project", {})["description"] = desc

    # Silver tables
    tables_raw = Prompt.ask(
        "Silver tables (comma-separated, e.g. silver_transactions,dim_customer)",
        default=", ".join(existing.get("data_sources", {}).get("silver_tables", [])),
    )
    tables = [t.strip() for t in tables_raw.split(",") if t.strip()]
    existing.setdefault("data_sources", {})["silver_tables"] = tables

    # Business goals
    goals = Prompt.ask(
        "Business goals",
        default=existing.get("business_context", {}).get("goals", ""),
    )
    existing.setdefault("business_context", {})["goals"] = goals

    # Business rules
    rules_raw = Prompt.ask(
        "Business rules (semicolon-separated)",
        default="; ".join(existing.get("business_context", {}).get("business_rules", [])),
    )
    rules = [r.strip() for r in rules_raw.split(";") if r.strip()]
    existing.setdefault("business_context", {})["business_rules"] = rules

    # Team
    team_id = Prompt.ask(
        "Project ID",
        default=existing.get("team", {}).get("project_id", ""),
    )
    existing.setdefault("team", {})["project_id"] = team_id

    # Write back
    gather_path.write_text(
        yaml.dump(existing, allow_unicode=True, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )

    console.print(f"\n[green]✓ gather-context.yaml updated → {gather_path}[/]")
    console.print("[dim]Next: run 'sdd /specify' to generate spec.md[/]")

    return gather_path
