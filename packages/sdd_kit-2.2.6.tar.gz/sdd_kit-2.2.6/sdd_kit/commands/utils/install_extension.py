"""
sdd install-extension
Helper to install the VS Code extension directly from the Python package.
Falls back to manual extraction if 'code' CLI is unavailable or crashes.
"""
from __future__ import annotations

import subprocess
import zipfile
from pathlib import Path

from rich.console import Console

console = Console()

# VS Code extensions directory (standard location on all platforms)
VSCODE_EXTENSIONS_DIR = Path.home() / ".vscode" / "extensions"


def run() -> bool:
    """
    Locate the bundled VSIX and install it into VS Code.
    Strategy:
    1. Try 'code --install-extension' (official CLI)
    2. Fall back to manual extraction into ~/.vscode/extensions/
    """
    # 1. Locate the VSIX inside the package (search dynamically)
    pkg_root = Path(__file__).parent.parent.parent  # commands/utils/ -> commands/ -> sdd_kit/
    extensions_dir = pkg_root / "core" / "extensions"
    vsix_files = list(extensions_dir.glob("*.vsix")) if extensions_dir.exists() else []

    if not vsix_files:
        console.print("[red]❌ Extension package (.vsix) not found in the installation.[/]")
        console.print(f"[dim]Searched in: {extensions_dir}[/]")
        console.print("[dim]Note: The extension must be bundled during the build process.[/]")
        return False

    vsix_path = vsix_files[0]  # Use the first (and usually only) .vsix found
    console.print(f"[bold blue]📦 Found extension: {vsix_path.name}[/]")

    # 2. Try using 'code' CLI first
    if _try_code_cli(vsix_path):
        return True

    # 3. Fall back to manual extraction
    console.print("[yellow]⚠️  Falling back to manual installation...[/]")
    return _manual_install(vsix_path)


def _try_code_cli(vsix_path: Path) -> bool:
    """Attempt to install via the official 'code' CLI."""
    try:
        subprocess.run(["code", "--version"], check=True, capture_output=True, timeout=5)
    except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
        console.print("[dim]'code' CLI not available, trying manual install...[/]")
        return False

    try:
        result = subprocess.run(
            ["code", "--install-extension", str(vsix_path)],
            capture_output=True,
            text=True,
            timeout=30,
        )
        # Check output for success message regardless of exit code.
        # VS Code CLI sometimes crashes (exit 134) AFTER a successful install
        # due to App Translocation on macOS — but the extension IS installed.
        combined = (result.stdout or "") + (result.stderr or "")
        if "successfully installed" in combined.lower():
            console.print("[bold green]✅ VS Code Extension installed successfully![/]")
            console.print("[yellow]👉 Please restart VS Code (or Cmd+Shift+P → Reload Window) to activate it.[/]")
            return True

        if result.returncode == 0:
            console.print("[bold green]✅ VS Code Extension installed successfully![/]")
            console.print("[yellow]👉 Please restart VS Code to activate it.[/]")
            return True

        console.print("[dim]'code' CLI did not confirm success, trying manual install...[/]")
        return False
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
        return False


def _manual_install(vsix_path: Path) -> bool:
    """
    Manually extract the VSIX into ~/.vscode/extensions/.
    A VSIX file is just a ZIP archive. The extension files live in the 'extension/' subfolder.
    """
    try:
        # Read publisher and name from the VSIX to determine the extension folder name
        with zipfile.ZipFile(vsix_path, "r") as z:
            # Get extension metadata from package.json inside the VSIX
            import json
            pkg_json = json.loads(z.read("extension/package.json").decode("utf-8"))
            publisher = pkg_json.get("publisher", "sdd-team")
            name = pkg_json.get("name", "sdd-kit")
            version = pkg_json.get("version", "2.1.3")

        ext_folder_name = f"{publisher}.{name}-{version}"
        target_dir = VSCODE_EXTENSIONS_DIR / ext_folder_name

        # Remove old version if exists
        import shutil
        for old in VSCODE_EXTENSIONS_DIR.glob(f"{publisher}.{name}-*"):
            shutil.rmtree(old, ignore_errors=True)
            console.print(f"[dim]Removed old version: {old.name}[/]")

        # Extract the VSIX
        target_dir.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(vsix_path, "r") as z:
            for member in z.namelist():
                if member.startswith("extension/"):
                    # Strip the 'extension/' prefix when extracting
                    relative = member[len("extension/"):]
                    if not relative:
                        continue
                    dest = target_dir / relative
                    if member.endswith("/"):
                        dest.mkdir(parents=True, exist_ok=True)
                    else:
                        dest.parent.mkdir(parents=True, exist_ok=True)
                        dest.write_bytes(z.read(member))

        console.print(f"[bold green]✅ Extension installed to: {target_dir}[/]")
        console.print("[yellow]👉 Please restart VS Code to activate the SDD Kit extension.[/]")
        return True

    except Exception as e:
        console.print(f"[red]❌ Manual installation failed: {e}[/]")
        console.print("[dim]Please install manually: open VS Code → Cmd+Shift+P → 'Install from VSIX'[/]")
        console.print(f"[dim]VSIX location: {vsix_path}[/]")
        return False
