"""
sdd onboard
Onboard an existing project — creates .sdd/ without touching any existing files (≤30s).
Rule 08: Never modify existing project files.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

from rich.console import Console
from rich.panel import Panel

console = Console()


def run(project_root: Path | None = None, verbose: bool = False) -> Path:
    """
    Onboard an existing project into SDD.
    Creates .sdd/ structure. Never modifies existing files.
    Returns .sdd/ path.
    """
    root = project_root or Path.cwd()
    sdd_dir = root / ".sdd"

    if sdd_dir.exists():
        console.print(f"[yellow]⚠️  .sdd/ already exists at {sdd_dir}. Skipping init.[/]")
    else:
        # Create .sdd structure — surgical (Rule 03)
        (sdd_dir / "local-kb").mkdir(parents=True, exist_ok=True)
        (sdd_dir / "logs").mkdir(parents=True, exist_ok=True)
        console.print("[green]  ✓ .sdd/ created[/]")

    # Scan existing project (non-invasive)
    findings = _scan_project(root, verbose=verbose)

    # Write Cursor Rules & MCP Config
    cursor_rules_dir = root / ".cursor" / "rules"
    cursor_rules_dir.mkdir(parents=True, exist_ok=True)
    
    # Load template from package core
    pkg_core = Path(__file__).parent.parent.parent / "core"
    rules_template_path = pkg_core / "cursor-rules" / "sdd-kit-rules.md"
    
    if rules_template_path.exists():
        rules_content = rules_template_path.read_text(encoding="utf-8")
        # Existing project formatting
        formatted_rules = rules_content.format(
            project_name=root.name,
            domain="generic",
            project_type="existing",
            spec_status="Onboarded (Run /audit)",
            plan_status="Pending (Run /plan-next)"
        )
        (cursor_rules_dir / "sdd.md").write_text(formatted_rules, encoding="utf-8")
        if verbose:
            console.print("[dim]  ✓ .cursor/rules/sdd.md[/]")

    # Write .cursor/mcp.json
    mcp_config = {
        "mcpServers": {
            "sdd-kit": {
                "command": "sdd",
                "args": ["serve"],
                "env": {
                    "ANTHROPIC_API_KEY": os.environ.get("ANTHROPIC_API_KEY", "")
                }
            }
        }
    }
    mcp_path = root / ".cursor" / "mcp.json"
    mcp_path.write_text(json.dumps(mcp_config, indent=2), encoding="utf-8")
    if verbose:
        console.print("[dim]  ✓ .cursor/mcp.json[/]")

    console.print(f"[green]  ✓ .cursor/rules/sdd.md created[/]")
    console.print(f"[green]  ✓ .cursor/mcp.json created[/]")

    console.print(Panel(
        f"[bold green]✅ Project '{root.name}' onboarded![/]\n\n"
        f"Language: [cyan]{findings['language']}[/] | "
        f"Files: [cyan]{findings['file_count']}[/] | "
        f"Has tests: [cyan]{findings['has_tests']}[/]\n\n"
        f"AI Setup:\n"
        f"  • Rules: [dim].cursor/rules/sdd.md[/]\n"
        f"  • Tools: [dim].cursor/mcp.json[/]\n\n"
        f"Next steps:\n"
        f"  1. [cyan]sdd /audit[/] — audit existing codebase\n"
        f"  2. [cyan]sdd /gather[/] — fill context\n"
        f"  3. [cyan]sdd /specify-next[/] — generate delta spec",
        title="sdd onboard",
        expand=False,
    ))

    return sdd_dir


def _detect_language(root: Path) -> str:
    indicators = {
        "python": ["*.py", "pyproject.toml", "requirements.txt"],
        "typescript": ["*.ts", "tsconfig.json", "package.json"],
        "java": ["*.java", "pom.xml", "build.gradle"],
        "go": ["*.go", "go.mod"],
    }
    for lang, patterns in indicators.items():
        for pattern in patterns:
            if list(root.glob(pattern)):
                return lang
    return "unknown"


def _scan_project(root: Path, verbose: bool = False) -> dict:
    src_files = list(root.rglob("*.py")) + list(root.rglob("*.ts")) + list(root.rglob("*.java"))
    src_files = [f for f in src_files if ".venv" not in str(f) and "node_modules" not in str(f)]

    has_tests = any(
        root.glob(p) for p in ["tests/", "test/", "**/test_*.py", "**/*.test.ts"]
    )

    if verbose:
        console.print(f"[dim]  Scanned: {len(src_files)} source files[/]")

    return {
        "language": _detect_language(root),
        "file_count": len(src_files),
        "has_tests": has_tests,
    }
