"""
sdd /plan-next
Generate plan-next.md + tasks-next.md — delta plan for existing projects (≤60s).
"""
from __future__ import annotations

from pathlib import Path

from rich.console import Console

console = Console()


def run(
    project_root: Path | None = None,
    dry_run: bool = False,
    platform_name: str = "mock",
    return_prompt: bool = False,
) -> str | tuple[Path, Path]:
    root = project_root or Path.cwd()
    sdd_dir = root / ".sdd"
    spec_next = sdd_dir / "spec-next.md"
    audit_path = sdd_dir / "audit.md"
    constitution_path = root / "constitution.md"

    if not spec_next.exists():
        console.print("[red]❌ .sdd/spec-next.md not found. Run 'sdd /specify-next' first.[/]")
        raise FileNotFoundError(".sdd/spec-next.md not found")

    spec_content = spec_next.read_text(encoding="utf-8")
    audit_content = audit_path.read_text(encoding="utf-8") if audit_path.exists() else ""
    constitution_content = constitution_path.read_text(encoding="utf-8") if constitution_path.exists() else ""

    if not return_prompt:
        console.print("[bold blue]📋 Generating plan-next.md + tasks-next.md (delta)...[/]")

    from sdd_kit.agent.orchestrator import Orchestrator
    orch = Orchestrator(project_root=root, platform_name=platform_name)

    user_input = f"## Delta Spec\n{spec_content}\n\n## Audit State\n{audit_content[:2000]}"
    if constitution_content:
        user_input = f"## Project Constitution\n{constitution_content}\n\n---\n\n{user_input}"

    plan_result = orch.run_task(
        task="plan-next",
        user_input=user_input,
        existing_state=audit_content[:3000],
        top_k=10,
        dry_run=dry_run,
        return_prompt=return_prompt,
    )

    if return_prompt:
        return plan_result

    sdd_dir = root / ".sdd"
    sdd_dir.mkdir(exist_ok=True)
    plan_path = sdd_dir / "plan-next.md"
    plan_path.write_text(plan_result, encoding="utf-8")

    tasks_result = orch.run_task(
        task="plan-next",
        user_input=f"Generate tasks-next.md for this delta plan:\n{plan_result}",
        top_k=6,
        dry_run=dry_run,
    )

    tasks_path = sdd_dir / "tasks-next.md"
    tasks_path.write_text(tasks_result, encoding="utf-8")

    console.print(f"[green]✓ .sdd/plan-next.md + .sdd/tasks-next.md generated[/]")
    return plan_path, tasks_path
