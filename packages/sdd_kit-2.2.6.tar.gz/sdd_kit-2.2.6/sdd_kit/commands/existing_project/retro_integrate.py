"""
sdd /integrate --retro
Reverse-engineer existing integrations — generates integration-learnings.md (≤90s).
Rule 08: Document only, never rewrite.
"""
from __future__ import annotations

from pathlib import Path

from rich.console import Console

console = Console()


def run(
    project_root: Path | None = None,
    dry_run: bool = False,
    platform_name: str = "mock",
    return_prompt: bool = False,
) -> str | Path:
    root = project_root or Path.cwd()
    if not return_prompt:
        console.print("[bold blue]🔍 Reverse-engineering existing integrations...[/]")

    # Sample integration-related code
    code_sample = _sample_integration_code(root)

    from sdd_kit.agent.orchestrator import Orchestrator
    orch = Orchestrator(project_root=root, platform_name=platform_name)

    result = orch.run_task(
        task="retro-integrate",
        user_input=code_sample,
        top_k=8,
        dry_run=dry_run,
        return_prompt=return_prompt,
    )

    if return_prompt:
        return result

    # Write to Zone 2 local-kb
    kb_dir = root / ".sdd" / "local-kb"
    kb_dir.mkdir(parents=True, exist_ok=True)
    learnings_path = kb_dir / "integration-learnings.md"
    learnings_path.write_text(result, encoding="utf-8")

    console.print(f"[green]✓ integration-learnings.md → {learnings_path}[/]")
    console.print("[dim]Next: run 'sdd /specify-next' to generate delta spec using these learnings[/]")

    return learnings_path


def _sample_integration_code(root: Path) -> str:
    """Sample integration-related files."""
    patterns = [
        "**/integration*.py", "**/connector*.py", "**/adapter*.py",
        "**/client*.py", "**/api*.py", "**/databricks*.py",
        "**/snowflake*.py", "**/database*.py",
    ]
    collected = []
    total = 0
    max_chars = 6_000

    for pattern in patterns:
        for path in root.glob(pattern):
            if any(s in str(path) for s in [".venv", "__pycache__", ".git"]):
                continue
            try:
                content = path.read_text(encoding="utf-8", errors="ignore")[:2000]
                entry = f"\n### {path.relative_to(root)}\n```python\n{content}\n```\n"
                if total + len(entry) > max_chars:
                    break
                collected.append(entry)
                total += len(entry)
            except Exception:
                continue

    return f"# Integration Code Sample\nProject: {root.name}\n" + "".join(collected)
