"""
Git helper utilities.
"""
from __future__ import annotations

import subprocess
from pathlib import Path


def get_project_hash(project_id: str) -> str:
    """SHA-256 hash of project_id for Bronze source_project_hash."""
    import hashlib
    return hashlib.sha256(project_id.encode()).hexdigest()


def get_current_branch(root: Path | None = None) -> str:
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            cwd=root or Path.cwd(),
            capture_output=True, text=True,
        )
        return result.stdout.strip() if result.returncode == 0 else "unknown"
    except Exception:
        return "unknown"


def is_git_repo(root: Path | None = None) -> bool:
    result = subprocess.run(
        ["git", "rev-parse", "--git-dir"],
        cwd=root or Path.cwd(),
        capture_output=True,
    )
    return result.returncode == 0
