"""
Utils: configuration, paths, environment.
"""
from __future__ import annotations

import os
from pathlib import Path


# ── Global dirs ──────────────────────────────────────────────────────────────
SDD_HOME = Path.home() / ".sdd"
ZONE0_DIR = SDD_HOME / "core"          # bundled in pip
ZONE1_DIR = SDD_HOME / "cache"         # local Gold mirror
LOGS_DIR = SDD_HOME / "logs"

# ── Token budget ──────────────────────────────────────────────────────────────
MAX_TOKENS_PER_CALL = 8_000

# ── AI provider ──────────────────────────────────────────────────────────────
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
DEFAULT_MODEL = os.environ.get("SDD_MODEL", "claude-3-5-sonnet-20241022")

# ── Lakehouse ─────────────────────────────────────────────────────────────────
DATABRICKS_HOST = os.environ.get("DATABRICKS_HOST", "")
DATABRICKS_TOKEN = os.environ.get("DATABRICKS_TOKEN", "")
DATABRICKS_CATALOG = os.environ.get("SDD_BRONZE_CATALOG", "bronze")
DATABRICKS_SCHEMA = os.environ.get("SDD_BRONZE_SCHEMA", "sdd")

PLATFORM = os.environ.get("SDD_PLATFORM", "mock")  # mock | databricks | snowflake

# ── Domain enum ───────────────────────────────────────────────────────────────
SUPPORTED_DOMAINS = [
    "banking",
    "ecommerce",
    "retail",
    "logistics",
    "healthcare",
    "generic",
]


def get_zone0_dir() -> Path:
    """Return the bundled core dir shipped with the package."""
    pkg_dir = Path(__file__).parent.parent / "core"
    return pkg_dir if pkg_dir.exists() else ZONE0_DIR


def get_zone1_dir(domain: str = "") -> Path:
    cache = ZONE1_DIR / "domain-marts" / domain if domain else ZONE1_DIR
    cache.mkdir(parents=True, exist_ok=True)
    return cache


def get_zone2_dir(project_root: Path | None = None) -> Path:
    root = project_root or Path.cwd()
    return root / ".sdd" / "local-kb"


def ensure_logs_dir() -> Path:
    LOGS_DIR.mkdir(parents=True, exist_ok=True)
    return LOGS_DIR
