"""
Bronze schema validator — validates records against sdd_contributions schema.
"""
from __future__ import annotations

REQUIRED_FIELDS = [
    "project_id", "domain", "pattern_type", "content", "confidence"
]

VALID_PATTERN_TYPES = [
    "integration_pattern", "gotcha", "data_model",
    "business_rule", "decision", "example",
]


def validate_bronze_record(record: dict) -> tuple[bool, list[str]]:
    """Validate a Bronze record. Returns (is_valid, error_list)."""
    errors = []
    for field in REQUIRED_FIELDS:
        if field not in record:
            errors.append(f"Missing required field: {field}")
    if "pattern_type" in record and record["pattern_type"] not in VALID_PATTERN_TYPES:
        errors.append(f"Invalid pattern_type: {record['pattern_type']}")
    if "confidence" in record:
        c = record["confidence"]
        if not isinstance(c, (int, float)) or not (0.0 <= c <= 1.0):
            errors.append(f"confidence must be 0.0–1.0, got: {c}")
    if "content" in record and len(record["content"]) > 10_000:
        errors.append(f"content exceeds 10K chars: {len(record['content'])}")
    return len(errors) == 0, errors
