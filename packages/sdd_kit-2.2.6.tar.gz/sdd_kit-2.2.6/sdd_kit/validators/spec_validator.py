"""
Spec validator — validates spec.md structure and content.
"""
from __future__ import annotations

import re
from pathlib import Path

REQUIRED_SECTIONS = [
    "Overview",
    "Data Context",
    "Integration Patterns",
    "Business Rules",
    "Acceptance Criteria",
    "Open Questions",
]


class SpecValidator:
    def __init__(self, spec_path: Path):
        self.path = spec_path
        self.content = spec_path.read_text(encoding="utf-8") if spec_path.exists() else ""
        self.failures: list[str] = []
        self.warnings: list[str] = []
        self.passes: list[str] = []

    def validate(self) -> bool:
        if not self.content:
            self.failures.append("spec.md not found or empty")
            return False

        self._check_sections()
        self._check_acceptance_criteria()
        self._check_no_placeholder_fields()

        return len(self.failures) == 0

    def _check_sections(self) -> None:
        for section in REQUIRED_SECTIONS:
            if section.lower() in self.content.lower():
                self.passes.append(f"Section '{section}' present")
            else:
                self.failures.append(f"Section '{section}' MISSING")

    def _check_acceptance_criteria(self) -> None:
        ac_pattern = re.compile(r"- AC-\d+:(.+)", re.MULTILINE)
        items = ac_pattern.findall(self.content)
        if not items:
            self.failures.append("No Acceptance Criteria (AC-xx) found")
            return
        for i, ac in enumerate(items, 1):
            if re.search(r"\d+|pass|fail|≤|≥|>|<|%|must|shall|should", ac, re.IGNORECASE):
                self.passes.append(f"AC-{i:02d} is measurable")
            else:
                self.warnings.append(f"AC-{i:02d} may not be measurable: '{ac.strip()[:60]}'")

    def _check_no_placeholder_fields(self) -> None:
        placeholders = re.findall(r"\{\{[^}]+\}\}", self.content)
        if placeholders:
            self.warnings.append(f"Unfilled placeholders found: {placeholders[:3]}")
