"""
Catalog validator — validates field names against Silver schema.
"""
from __future__ import annotations

from sdd_kit.lakehouse.base import LakehousePlatform


def validate_fields_against_catalog(
    field_names: list[str],
    table_name: str,
    platform: LakehousePlatform,
) -> tuple[list[str], list[str]]:
    """
    Returns (valid_fields, invalid_fields).
    Invalid = not found in Silver schema.
    """
    try:
        schema = platform.read_silver_schema(table_name)
        canonical = {col.name.lower() for col in schema.columns}
        valid = [f for f in field_names if f.lower() in canonical]
        invalid = [f for f in field_names if f.lower() not in canonical]
        return valid, invalid
    except Exception as e:
        # Offline — can't validate
        return field_names, []
