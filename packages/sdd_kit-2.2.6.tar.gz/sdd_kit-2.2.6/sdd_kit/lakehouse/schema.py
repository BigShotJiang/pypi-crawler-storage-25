"""
Shared dataclasses for lakehouse layer.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Chunk:
    """A retrieved chunk from the Gold knowledge layer."""
    id: str
    content: str
    domain: str
    pattern_type: str
    source: str
    score: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)

    def token_estimate(self) -> int:
        """Rough token estimate: ~1 token per 4 chars."""
        return len(self.content) // 4


@dataclass
class ColumnDef:
    name: str
    data_type: str
    nullable: bool = True
    description: str = ""


@dataclass
class Schema:
    """Silver layer table schema."""
    table_name: str
    catalog: str
    schema_name: str
    columns: list[ColumnDef] = field(default_factory=list)
    description: str = ""
    is_cached: bool = False

    def to_markdown(self) -> str:
        lines = [
            f"## Table: `{self.catalog}.{self.schema_name}.{self.table_name}`",
            f"\n{self.description}\n" if self.description else "",
            "| Column | Type | Nullable | Description |",
            "|--------|------|----------|-------------|",
        ]
        for col in self.columns:
            nullable = "Yes" if col.nullable else "No"
            lines.append(f"| `{col.name}` | {col.data_type} | {nullable} | {col.description} |")
        if self.is_cached:
            lines.append("\n> ⚠️ (offline, may be stale)")
        return "\n".join(lines)
