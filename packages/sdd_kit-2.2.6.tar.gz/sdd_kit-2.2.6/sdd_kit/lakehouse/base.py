"""
LakehousePlatform — Abstract Base Class.

Every platform (Databricks, Snowflake, Mock) must implement these 5 methods.
Rule 12: Offline is first-class — all methods must handle offline gracefully.
"""
from __future__ import annotations

from abc import ABC, abstractmethod

from sdd_kit.lakehouse.schema import Chunk, Schema


class LakehousePlatform(ABC):
    """Abstract interface for all lakehouse backends."""

    @abstractmethod
    def read_gold_embeddings(self, query: str, top_k: int = 12) -> list[Chunk]:
        """
        Retrieve top-k semantically relevant chunks from the Gold layer.
        Must work offline (return cached results + label as stale).
        """
        ...

    @abstractmethod
    def read_silver_schema(self, table_name: str) -> Schema:
        """
        Fetch the canonical Silver schema for a given table.
        Must work offline (return snapshot + label as stale).
        """
        ...

    @abstractmethod
    def write_bronze(self, records: list[dict]) -> list[str]:
        """
        Write learning records to Bronze layer.
        Returns list of UUIDs assigned to each record.
        Raises OfflineError if no connection available.
        """
        ...

    @abstractmethod
    def verify_connection(self) -> bool:
        """Return True if the platform is reachable, False otherwise."""
        ...

    @abstractmethod
    def get_platform_name(self) -> str:
        """Return platform identifier: 'databricks' | 'snowflake' | 'mock' | 'open'."""
        ...


class OfflineError(RuntimeError):
    """Raised when an operation requires connectivity but none is available."""
    pass
