"""
Semantic Query Adapter — retrieves Gold chunks and Silver schemas.
Uses local cache when offline (Rule 12).
"""
from __future__ import annotations

import logging

from sdd_kit.lakehouse.base import LakehousePlatform
from sdd_kit.lakehouse.local_cache import LocalCache
from sdd_kit.lakehouse.schema import Chunk, Schema

logger = logging.getLogger(__name__)


class SemanticQueryAdapter:
    """
    Thin wrapper around the platform for Gold/Silver retrieval.
    Adds: offline fallback, logging, and token estimate logging.
    """

    def __init__(self, platform: LakehousePlatform):
        self._platform = platform
        self._cache = LocalCache()

    def retrieve(self, query: str, domain: str = "generic", top_k: int = 12) -> list[Chunk]:
        """
        Retrieve top-k Gold chunks for a query.
        Always returns results (offline = cached, labeled as stale).
        """
        logger.info(f"SemanticQuery.retrieve: query='{query[:60]}' domain={domain} top_k={top_k}")
        chunks = self._platform.read_gold_embeddings(query, top_k=top_k)
        total_tokens = sum(c.token_estimate() for c in chunks)
        logger.info(f"Retrieved {len(chunks)} chunks (~{total_tokens} tokens)")
        return chunks

    def retrieve_data_model(self, table_name: str) -> Schema:
        """
        Fetch Silver schema for a table.
        Falls back to cached snapshot + labels as stale.
        """
        logger.info(f"SemanticQuery.retrieve_data_model: table={table_name}")
        return self._platform.read_silver_schema(table_name)

    def chunks_to_text(self, chunks: list[Chunk]) -> str:
        """Convert chunk list to a single markdown string for context injection."""
        if not chunks:
            return ""
        parts = ["## Retrieved Knowledge (Gold Layer)\n"]
        for i, chunk in enumerate(chunks, 1):
            stale = " *(offline, may be stale)*" if chunk.score == 0.0 else ""
            parts.append(f"### [{i}] {chunk.pattern_type} — {chunk.domain}{stale}\n")
            parts.append(chunk.content)
            parts.append(f"\n*Source: {chunk.source} | Relevance: {chunk.score:.2f}*\n")
        return "\n".join(parts)
