"""
Databricks adapter — primary production lakehouse platform.
Requires: DATABRICKS_HOST, DATABRICKS_TOKEN env vars.
Falls back to local cache when offline (Rule 12).
"""
from __future__ import annotations

import logging

from sdd_kit.lakehouse.base import LakehousePlatform, OfflineError
from sdd_kit.lakehouse.local_cache import LocalCache
from sdd_kit.lakehouse.schema import Chunk, ColumnDef, Schema

logger = logging.getLogger(__name__)


class DatabricksPlatform(LakehousePlatform):
    """Databricks lakehouse adapter using databricks-sdk."""

    def __init__(self, host: str = "", token: str = "", catalog: str = "bronze", schema: str = "sdd"):
        self._host = host
        self._token = token
        self._catalog = catalog
        self._schema = schema
        self._client = None
        self._cache = LocalCache()
        self._online = False
        self._try_connect()

    def _try_connect(self) -> None:
        if not self._host or not self._token:
            logger.warning("Databricks credentials not set — running offline (Rule 12)")
            return
        try:
            from databricks.sdk import WorkspaceClient  # type: ignore
            self._client = WorkspaceClient(host=self._host, token=self._token)
            self._online = True
            logger.info("Databricks connection established")
        except Exception as e:
            logger.warning(f"Databricks connection failed, falling back to cache: {e}")

    def read_gold_embeddings(self, query: str, top_k: int = 12) -> list[Chunk]:
        if not self._online:
            cached = self._cache.load_chunks(query, top_k)
            if cached:
                logger.info(f"(offline, may be stale) Returning {len(cached)} cached chunks")
                return cached
            logger.warning("(offline, may be stale) No cached chunks found, returning empty")
            return []
        try:
            # Execute semantic search via Databricks SQL
            sql = f"""
                SELECT chunk_id, content, domain, pattern_type, source, score
                FROM {self._catalog}.{self._schema}.gold_embeddings
                ORDER BY vector_similarity(embedding, :query_embedding) DESC
                LIMIT {top_k}
            """
            # NOTE: Full vector similarity implementation depends on Databricks
            # Vector Search configuration in the target workspace.
            # For now, fall back to keyword search as placeholder.
            result = self._client.statement_execution.execute_statement(
                warehouse_id=self._get_warehouse_id(),
                statement=f"""
                    SELECT chunk_id as id, content, domain, pattern_type, source, 0.8 as score
                    FROM {self._catalog}.{self._schema}.gold_embeddings
                    WHERE content LIKE '%{query[:50]}%'
                    LIMIT {top_k}
                """,
            )
            chunks = []
            if result.result and result.result.data_array:
                for row in result.result.data_array:
                    chunks.append(Chunk(
                        id=row[0], content=row[1], domain=row[2],
                        pattern_type=row[3], source=row[4], score=float(row[5]),
                    ))
            self._cache.save_chunks(query, chunks)
            return chunks
        except Exception as e:
            logger.warning(f"(offline, may be stale) Gold read failed, using cache: {e}")
            return self._cache.load_chunks(query, top_k) or []

    def read_silver_schema(self, table_name: str) -> Schema:
        cached = self._cache.load_schema(table_name)
        if not self._online:
            if cached:
                return cached
            raise OfflineError(f"No cached schema for {table_name} and platform is offline")
        try:
            info = self._client.tables.get(f"silver.{table_name}")
            cols = [
                ColumnDef(
                    name=c.name,
                    data_type=c.type_text or "STRING",
                    nullable=c.nullable or True,
                    description=c.comment or "",
                )
                for c in (info.columns or [])
            ]
            parts = table_name.split(".")
            schema = Schema(
                table_name=parts[-1],
                catalog=parts[0] if len(parts) > 2 else "silver",
                schema_name=parts[1] if len(parts) > 2 else "default",
                columns=cols,
                description=info.comment or "",
            )
            self._cache.save_schema(table_name, schema)
            return schema
        except Exception as e:
            logger.warning(f"(offline, may be stale) Schema read failed: {e}")
            if cached:
                return cached
            raise OfflineError(f"Cannot fetch schema for {table_name}") from e

    def write_bronze(self, records: list[dict]) -> list[str]:
        if not self._online:
            raise OfflineError("Cannot write to Bronze — platform is offline")
        import json
        import uuid
        ids = [str(uuid.uuid4()) for _ in records]
        for rec, rid in zip(records, ids):
            rec["contribution_id"] = rid
        values = ", ".join(f"({json.dumps(r)})" for r in records)
        self._client.statement_execution.execute_statement(
            warehouse_id=self._get_warehouse_id(),
            statement=f"INSERT INTO {self._catalog}.{self._schema}.sdd_contributions VALUES {values}",
        )
        return ids

    def verify_connection(self) -> bool:
        if not self._online:
            return False
        try:
            self._client.current_user.me()
            return True
        except Exception:
            return False

    def get_platform_name(self) -> str:
        return "databricks"

    def _get_warehouse_id(self) -> str:
        """Get first available SQL warehouse."""
        warehouses = list(self._client.warehouses.list())
        if not warehouses:
            raise RuntimeError("No SQL warehouses available in Databricks workspace")
        return warehouses[0].id
