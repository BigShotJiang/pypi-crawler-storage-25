"""
Mock platform — offline-first, used in all tests.
Returns deterministic fake data. Never requires credentials.
"""
from __future__ import annotations

import uuid

from sdd_kit.lakehouse.base import LakehousePlatform
from sdd_kit.lakehouse.schema import Chunk, ColumnDef, Schema


_MOCK_CHUNKS: list[dict] = [
    {
        "id": "mock-001",
        "content": "## Integration Pattern: REST → Databricks\nUse databricks-sdk WorkspaceClient to execute SQL queries. Always use parameterized queries to prevent injection. Cache schema snapshots locally for offline use.",
        "domain": "generic",
        "pattern_type": "integration_pattern",
        "source": "mock://integration-patterns",
        "score": 0.95,
    },
    {
        "id": "mock-002",
        "content": "## Gotcha: Databricks Token Expiry\nDatabricks PAT tokens expire after 90 days by default. Implement token refresh logic or use service principal OAuth2 for production deployments.",
        "domain": "generic",
        "pattern_type": "gotcha",
        "source": "mock://gotchas",
        "score": 0.88,
    },
    {
        "id": "mock-003",
        "content": "## Data Model: silver_transactions\nCanonical transaction table. Always filter by `is_deleted = FALSE` and `status IN ('COMPLETED', 'SETTLED')`. Join to `dim_customer` on `customer_id`.",
        "domain": "banking",
        "pattern_type": "data_model",
        "source": "mock://data-models",
        "score": 0.82,
    },
]

_MOCK_SCHEMA = Schema(
    table_name="silver_transactions",
    catalog="silver",
    schema_name="banking",
    description="Canonical transaction table for banking domain.",
    columns=[
        ColumnDef("transaction_id", "STRING", False, "UUID primary key"),
        ColumnDef("customer_id", "STRING", False, "FK to dim_customer"),
        ColumnDef("amount", "DECIMAL(18,2)", False, "Transaction amount"),
        ColumnDef("currency", "STRING(3)", False, "ISO-4217 currency code"),
        ColumnDef("status", "STRING", False, "PENDING | COMPLETED | SETTLED | FAILED"),
        ColumnDef("created_at", "TIMESTAMP", False, "UTC creation timestamp"),
        ColumnDef("is_deleted", "BOOLEAN", False, "Soft delete flag"),
    ],
    is_cached=True,
)


class MockPlatform(LakehousePlatform):
    """Fully offline mock — deterministic, no credentials required."""

    def read_gold_embeddings(self, query: str, top_k: int = 12) -> list[Chunk]:
        results = [Chunk(**c) for c in _MOCK_CHUNKS]
        # Simple keyword relevance filter
        q = query.lower()
        scored = sorted(results, key=lambda c: sum(w in c.content.lower() for w in q.split()), reverse=True)
        return scored[:top_k]

    def read_silver_schema(self, table_name: str) -> Schema:
        schema = Schema(
            table_name=table_name,
            catalog="silver",
            schema_name="mock",
            description=f"Mock schema for {table_name}",
            columns=[
                ColumnDef("id", "STRING", False, "UUID primary key"),
                ColumnDef("created_at", "TIMESTAMP", False, "Creation timestamp"),
                ColumnDef("updated_at", "TIMESTAMP", True, "Last update timestamp"),
            ],
            is_cached=True,
        )
        if table_name == "silver_transactions":
            return _MOCK_SCHEMA
        return schema

    def write_bronze(self, records: list[dict]) -> list[str]:
        return [str(uuid.uuid4()) for _ in records]

    def verify_connection(self) -> bool:
        return True  # Mock is always "connected"

    def get_platform_name(self) -> str:
        return "mock"
