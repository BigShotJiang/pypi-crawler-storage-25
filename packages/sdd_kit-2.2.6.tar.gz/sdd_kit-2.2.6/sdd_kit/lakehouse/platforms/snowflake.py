"""
Snowflake adapter — Phase 4 stub.
Not implemented yet. Raises NotImplementedError on all calls.
"""
from __future__ import annotations

from sdd_kit.lakehouse.base import LakehousePlatform
from sdd_kit.lakehouse.schema import Chunk, Schema


class SnowflakePlatform(LakehousePlatform):
    """Snowflake adapter — Phase 4, not yet implemented."""

    def read_gold_embeddings(self, query: str, top_k: int = 12) -> list[Chunk]:
        raise NotImplementedError("Snowflake adapter is scheduled for Phase 4")

    def read_silver_schema(self, table_name: str) -> Schema:
        raise NotImplementedError("Snowflake adapter is scheduled for Phase 4")

    def write_bronze(self, records: list[dict]) -> list[str]:
        raise NotImplementedError("Snowflake adapter is scheduled for Phase 4")

    def verify_connection(self) -> bool:
        return False

    def get_platform_name(self) -> str:
        return "snowflake"
