"""
KB Sync Adapter — syncs Gold domain data to Zone 1 cache,
and uploads learnings to Bronze.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone

from sdd_kit.lakehouse.base import LakehousePlatform
from sdd_kit.lakehouse.local_cache import LocalCache
from sdd_kit.lakehouse.schema import Chunk

logger = logging.getLogger(__name__)


class KBSyncAdapter:
    """
    Syncs the local Zone 1 cache with the lakehouse.
    - sync_domain(): pulls Gold delta → saves to Zone 1
    - upload_learnings(): writes new learnings to Bronze
    """

    def __init__(self, platform: LakehousePlatform):
        self._platform = platform
        self._cache = LocalCache()

    def sync_domain(self, domain: str, queries: list[str] | None = None, top_k: int = 50) -> dict:
        """
        Fetch Gold chunks for a domain and persist to Zone 1 cache.
        Returns summary: {domain, chunks_synced, timestamp, offline}.
        """
        default_queries = [
            f"{domain} integration patterns",
            f"{domain} data models",
            f"{domain} gotchas best practices",
            f"{domain} Silver schema",
        ]
        search_queries = queries or default_queries

        total_synced = 0
        offline = not self._platform.verify_connection()

        for query in search_queries:
            if offline:
                logger.warning(f"(offline, may be stale) Skipping sync for: {query}")
                continue
            try:
                chunks = self._platform.read_gold_embeddings(query, top_k=top_k)
                self._cache.save_chunks(query, chunks, domain=domain)
                total_synced += len(chunks)
                logger.info(f"Synced {len(chunks)} chunks for '{query}'")
            except Exception as e:
                logger.warning(f"Sync failed for query '{query}': {e}")

        self._cache.set_version(domain, datetime.now(timezone.utc).isoformat())

        return {
            "domain": domain,
            "chunks_synced": total_synced,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "offline": offline,
        }

    def upload_learnings(self, records: list[dict]) -> list[str]:
        """
        Write learning records to Bronze layer.
        Records must conform to the sdd_contributions schema.
        Returns list of assigned UUIDs.
        """
        import uuid
        from sdd_kit.utils.config import DATABRICKS_CATALOG, DATABRICKS_SCHEMA

        enriched = []
        for rec in records:
            enriched.append({
                "contribution_id": str(uuid.uuid4()),
                "project_id": rec.get("project_id", "unknown"),
                "project_type": rec.get("project_type", "new"),
                "phase": rec.get("phase", "unknown"),
                "domain": rec.get("domain", "generic"),
                "pattern_type": rec.get("pattern_type", "integration_pattern"),
                "content": rec.get("content", ""),
                "data_sources_ref": rec.get("data_sources_ref", []),
                "confidence": rec.get("confidence", 0.5),
                "contributor_team": rec.get("contributor_team", "sdd-team"),
                "source_project_hash": rec.get("source_project_hash", ""),
                "created_at": datetime.now(timezone.utc).isoformat(),
                "sdd_kit_version": "2.0.0",
            })

        return self._platform.write_bronze(enriched)
