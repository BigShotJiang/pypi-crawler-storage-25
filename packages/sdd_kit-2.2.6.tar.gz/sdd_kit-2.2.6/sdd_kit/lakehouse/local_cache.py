"""
Zone 1 local cache — persists Gold chunks, Silver schemas, and embeddings.
All reads/writes are offline-safe. Max ~500 MB.
"""
from __future__ import annotations

import json
import logging
import pickle
from pathlib import Path

from sdd_kit.lakehouse.schema import Chunk, ColumnDef, Schema

logger = logging.getLogger(__name__)


class LocalCache:
    """
    Zone 1: ~/.sdd/cache/
    ├─ domain-marts/{domain}/chunks/{query_hash}.json
    ├─ schema-snapshots/{table_name}.json
    └─ versions.json
    """

    def __init__(self, base_dir: Path | None = None):
        from sdd_kit.utils.config import ZONE1_DIR
        self._base = base_dir or ZONE1_DIR
        self._chunks_dir = self._base / "domain-marts"
        self._schema_dir = self._base / "schema-snapshots"
        self._chunks_dir.mkdir(parents=True, exist_ok=True)
        self._schema_dir.mkdir(parents=True, exist_ok=True)

    # ── Chunks ────────────────────────────────────────────────────────────────

    def save_chunks(self, query: str, chunks: list[Chunk], domain: str = "generic") -> None:
        key = self._query_key(query)
        path = self._chunks_dir / domain / f"{key}.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        data = [
            {
                "id": c.id, "content": c.content, "domain": c.domain,
                "pattern_type": c.pattern_type, "source": c.source,
                "score": c.score, "metadata": c.metadata,
            }
            for c in chunks
        ]
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        logger.debug(f"Cached {len(chunks)} chunks → {path}")

    def load_chunks(self, query: str, top_k: int = 12, domain: str = "generic") -> list[Chunk]:
        key = self._query_key(query)
        path = self._chunks_dir / domain / f"{key}.json"
        if not path.exists():
            # Try all domains
            for p in self._chunks_dir.glob(f"**/{key}.json"):
                path = p
                break
            else:
                return []
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            chunks = [Chunk(**c) for c in data]
            return chunks[:top_k]
        except Exception as e:
            logger.warning(f"Cache read error for chunks: {e}")
            return []

    # ── Schemas ───────────────────────────────────────────────────────────────

    def save_schema(self, table_name: str, schema: Schema) -> None:
        path = self._schema_dir / f"{table_name.replace('.', '_')}.json"
        data = {
            "table_name": schema.table_name,
            "catalog": schema.catalog,
            "schema_name": schema.schema_name,
            "description": schema.description,
            "columns": [
                {"name": c.name, "data_type": c.data_type,
                 "nullable": c.nullable, "description": c.description}
                for c in schema.columns
            ],
        }
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    def load_schema(self, table_name: str) -> Schema | None:
        path = self._schema_dir / f"{table_name.replace('.', '_')}.json"
        if not path.exists():
            return None
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            cols = [ColumnDef(**c) for c in data.get("columns", [])]
            return Schema(
                table_name=data["table_name"],
                catalog=data["catalog"],
                schema_name=data["schema_name"],
                description=data.get("description", ""),
                columns=cols,
                is_cached=True,
            )
        except Exception as e:
            logger.warning(f"Cache read error for schema {table_name}: {e}")
            return None

    # ── Versions ──────────────────────────────────────────────────────────────

    def get_versions(self) -> dict:
        path = self._base / "versions.json"
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
        return {}

    def set_version(self, domain: str, version: str) -> None:
        versions = self.get_versions()
        versions[domain] = version
        path = self._base / "versions.json"
        path.write_text(json.dumps(versions, indent=2), encoding="utf-8")

    # ── Helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _query_key(query: str) -> str:
        import hashlib
        return hashlib.md5(query.strip().lower().encode()).hexdigest()[:12]
