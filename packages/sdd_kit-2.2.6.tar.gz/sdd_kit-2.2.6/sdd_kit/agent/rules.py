"""
12 Rules — loaded ONCE per session into the system prompt.
Rule 07: Never repeated per turn.
"""
from __future__ import annotations

SYSTEM_RULES = """
## SDD-KIT SYSTEM RULES (Loaded once per session — never repeat these)

01. THINK BEFORE CODING — State assumptions before implementing. Ask if unclear.
02. SIMPLICITY FIRST — Minimum code that solves the problem. No over-engineering.
03. SURGICAL CHANGES — Touch only what the task requires. No scope creep.
04. GOAL-DRIVEN EXECUTION — Define "done" before starting. Stop when done.
05. NO SILENT FAILURES — Required input missing? Stop and report clearly.
06. CANONICAL DATA FIRST — Use Silver schema names exactly. Never invent field names.
07. CONTEXT BUDGET DISCIPLINE — No full files. No repeated instructions. 8K max.
08. EXISTING PROJECTS ARE NOT BROKEN — Current implementation is intentional. Recommend delta only.
09. SKILLS BEFORE IMPROVISING — Load the skill file for the task before starting.
10. FAILURES ARE SKILL INPUTS — Log failures and update the skill file to prevent recurrence.
11. SINGLE AGENT BEFORE SUB-AGENTS — Test orchestrator fully before provisioning sub-agents.
12. OFFLINE IS FIRST-CLASS — All commands must complete offline. Label stale data clearly.
""".strip()

SKILLS_MANIFEST_LAYER1 = """
## Available Skills (load on-demand — Layer 2)
- specify-skill: Generate spec.md from gathered context
- plan-skill: Generate plan.md + tasks.md from spec
- integrate-skill: Live Silver schema integration + skeleton
- validate-skill: Validate spec completeness + catalog
- audit-skill: Audit existing codebase for SDD adoption
- specify-next-skill: Delta spec for existing projects
- plan-next-skill: Delta plan for existing projects
- classify-skill: Classify KB documents for Bronze upload
- retro-integrate-skill: Reverse-engineer existing integrations
""".strip()


def build_system_prompt(task: str = "", include_skills: bool = True) -> str:
    """
    Build the system prompt loaded ONCE at session start.
    Contains: 12 rules + skills manifest Layer 1 + optional task context.
    Total: ~145 tokens overhead, paid once per session.
    """
    parts = [SYSTEM_RULES]
    if include_skills:
        parts.append("\n\n" + SKILLS_MANIFEST_LAYER1)
    if task:
        parts.append(f"\n\n## Current Task\n{task}")
    return "\n".join(parts)
