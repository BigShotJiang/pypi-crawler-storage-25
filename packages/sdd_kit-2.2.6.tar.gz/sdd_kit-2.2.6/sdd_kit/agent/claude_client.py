"""
Claude API client wrapper.
Handles: API calls, retries, token logging, offline detection.
"""
from __future__ import annotations

import json
import logging
import time
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)


class ClaudeClient:
    """
    Thin wrapper around the Anthropic Python SDK.
    Manages: session state, token logging, offline detection.
    """

    def __init__(self, api_key: str = "", model: str = ""):
        from sdd_kit.utils.config import ANTHROPIC_API_KEY, DEFAULT_MODEL, ensure_logs_dir
        self._api_key = api_key or ANTHROPIC_API_KEY
        self._model = model or DEFAULT_MODEL
        self._client = None
        self._session_tokens: list[dict] = []
        self._logs_dir = ensure_logs_dir()
        self._session_id = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
        self._try_init()

    def _try_init(self) -> None:
        if not self._api_key:
            logger.warning("ANTHROPIC_API_KEY not set — AI calls will fail. Running in offline mode.")
            return
        try:
            import anthropic
            self._client = anthropic.Anthropic(api_key=self._api_key)
            logger.debug(f"Claude client initialized (model={self._model})")
        except ImportError:
            logger.warning("anthropic package not installed. AI calls disabled.")
        except Exception as e:
            logger.warning(f"Claude client init failed: {e}")

    def is_available(self) -> bool:
        return self._client is not None and bool(self._api_key)

    def call(
        self,
        system_prompt: str,
        user_content: str,
        max_tokens: int = 2048,
        task_name: str = "unknown",
    ) -> str:
        """
        Make a single Claude API call.
        Logs token usage. Returns response text.
        Raises RuntimeError if client unavailable.
        """
        if not self.is_available():
            raise RuntimeError(
                "Claude API unavailable. Set ANTHROPIC_API_KEY env var. "
                "Use --dry-run for offline mode."
            )

        start = time.time()
        try:
            response = self._client.messages.create(
                model=self._model,
                max_tokens=max_tokens,
                system=system_prompt,
                messages=[{"role": "user", "content": user_content}],
            )
            elapsed = time.time() - start
            usage = response.usage
            self._log_tokens(task_name, usage.input_tokens, usage.output_tokens, elapsed)
            return response.content[0].text

        except Exception as e:
            logger.error(f"Claude API call failed ({task_name}): {e}")
            raise

    def _log_tokens(self, task: str, input_tokens: int, output_tokens: int, elapsed: float) -> None:
        entry = {
            "task": task,
            "model": self._model,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "total_tokens": input_tokens + output_tokens,
            "elapsed_s": round(elapsed, 2),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        self._session_tokens.append(entry)
        logger.info(
            f"[tokens] task={task} in={input_tokens} out={output_tokens} "
            f"total={input_tokens + output_tokens} ({elapsed:.1f}s)"
        )
        self._save_session_log()

    def _save_session_log(self) -> None:
        log_path = self._logs_dir / f"session-{self._session_id}.json"
        log_path.write_text(
            json.dumps(self._session_tokens, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

    def get_session_summary(self) -> dict:
        total_in = sum(e["input_tokens"] for e in self._session_tokens)
        total_out = sum(e["output_tokens"] for e in self._session_tokens)
        return {
            "session_id": self._session_id,
            "calls": len(self._session_tokens),
            "total_input_tokens": total_in,
            "total_output_tokens": total_out,
            "total_tokens": total_in + total_out,
        }
