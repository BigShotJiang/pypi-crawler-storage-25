import os
from collections.abc import Mapping
from copy import deepcopy
from pathlib import Path
from types import MappingProxyType

from pyodide_build.common import (
    IS_WIN,
    _environment_substitute_str,
    run_command,
    search_pyproject_toml,
)
from pyodide_build.constants import BASE_IGNORED_REQUIREMENTS
from pyodide_build.logger import logger


class ConfigManager:
    """
    Configuration manager for pyodide-build.
    This class works "before" installing the cross build environment.
    So it does not have access to the variables that are retrieved from the cross build environment.

    Most of the times, use CrossBuildEnvConfigManager instead of this class.
    But if you need to access the configuration without installing the cross build environment, use this class.
    """

    def __init__(self):
        self._config = {
            **self._load_default_config(),
            **self._load_cross_build_envs(),
            **self._load_config_file(Path.cwd(), os.environ),
            **self._load_config_from_env(os.environ),
        }

    def _load_default_config(self) -> Mapping[str, str]:
        return deepcopy(DEFAULT_CONFIG)

    def _load_cross_build_envs(self) -> Mapping[str, str]:
        """
        Load environment variables from the cross build environment.
        """

        # This method should be implemented in the subclass.
        return {}

    def _load_config_from_env(self, env: Mapping[str, str]) -> Mapping[str, str]:
        return {
            BUILD_VAR_TO_KEY[key]: env[key] for key in env if key in BUILD_VAR_TO_KEY
        }

    def _load_config_file(
        self, curdir: Path, env: Mapping[str, str]
    ) -> Mapping[str, str]:
        pyproject_path, configs = search_pyproject_toml(curdir)

        if pyproject_path is None or configs is None:
            return {}

        if (
            "tool" in configs
            and "pyodide" in configs["tool"]
            and "build" in configs["tool"]["pyodide"]
        ):
            build_config = {}
            for key, v in configs["tool"]["pyodide"]["build"].items():
                if key not in OVERRIDABLE_BUILD_KEYS:
                    logger.warning(
                        "WARNING: The provided build key %s is either invalid or not overridable, hence ignored.",
                        key,
                    )
                    continue
                build_config[key] = _environment_substitute_str(v, env)

            return build_config
        else:
            return {}

    @property
    def config(self) -> Mapping[str, str]:
        return MappingProxyType(self._config)

    def to_env(self) -> dict[str, str]:
        """
        Export the configuration to environment variables.
        """
        return {BUILD_KEY_TO_VAR[k]: v for k, v in self.config.items()}


class CrossBuildEnvConfigManager(ConfigManager):
    """
    Configuration manager for Package build process.
    This class works "after" installing the cross build environment.

    The configuration manager is responsible for loading configuration from various sources.
    The configuration can be loaded from the following sources (in order of precedence):

        1. Command line arguments (TODO)
        2. Environment variables
        3. Configuration file
        4. Makefile.envs
        5. Default values
    """

    def __init__(self, pyodide_root: Path):
        self.pyodide_root = pyodide_root
        super().__init__()

    def _load_cross_build_envs(self) -> Mapping[str, str]:
        makefile_vars = self._get_make_environment_vars()
        computed_vars = {
            k: _environment_substitute_str(v, env=makefile_vars)
            for k, v in DEFAULT_CONFIG_COMPUTED.items()
        }

        # Compute the Emscripten directory from pyodide_root. The emsdk directory
        # is a sibling of the xbuildenv directory, both living under the versioned
        # xbuildenv root (pyodide_root/../../emsdk/upstream/emscripten).
        # We compute this here rather than via Makefile.envs or DEFAULT_CONFIG so
        # that the path is always the resolved, versioned path – not the shared
        # xbuildenv symlink, because there are some issues I have noticed with
        # concurrent builds especially when being used in cibuildwheel etc.
        emsdk_root = self.pyodide_root.parent.parent / "emsdk"
        computed_vars["emsdk_dir"] = str(emsdk_root)
        computed_vars["emscripten_dir"] = str(emsdk_root / "upstream" / "emscripten")

        return {
            BUILD_VAR_TO_KEY[k]: v
            for k, v in makefile_vars.items()
            if k in BUILD_VAR_TO_KEY
        } | computed_vars

    def _get_make_environment_vars(self) -> Mapping[str, str]:
        """
        Load environment variables from Makefile.envs
        """
        environment = {}
        env = os.environ | {"PYODIDE_ROOT": str(self.pyodide_root)}
        makefile_path = self.pyodide_root / "Makefile.envs"

        if IS_WIN:
            logger.debug("Using internal Makefile.envs parser on Windows system")
            return _parse_makefile_envs(env=env, makefile_path=makefile_path)
        else:
            result = run_command(
                ["make", "-f", str(makefile_path), ".output_vars"],
                env=env,
                err_msg="ERROR: Failed to load environment variables from Makefile.envs",
            )

            for line in result.stdout.splitlines():
                equalPos = line.find("=")
                if equalPos == -1:
                    continue

                varname = line[0:equalPos]

                if varname not in BUILD_VAR_TO_KEY:
                    continue

                value = line[equalPos + 1 :]
                value = value.strip("'").strip()
                environment[varname] = value

            return environment


def _parse_makefile_envs(
    env: Mapping[str, str],
    makefile_path: Path,
) -> dict[str, str]:
    """
    Simple parser for Makefile.envs that doesn't require make.
    This is a fallback for systems where make is not available (e.g., Windows).

    This function is not a full-featured Makefile parser, but it can handle simple variable assignments.
    For instance, it does not parse multi-line values or complex Makefile syntax correctly.
    But it is sufficient to extract the build configuration required for `pyodide venv`.
    Ideally, we should get rid of Makefile.envs and find a better way to pass build configuration
    from Pyodide to pyodide-build. Still, to support backward compatibility, we keep this parser for now.
    """
    environment = dict(env)

    with open(makefile_path) as f:
        for line in f:
            line = line.strip()

            # Skip comments and empty lines
            if not line or line.startswith("#"):
                continue

            # Only process export statements
            if not line.startswith("export "):
                continue

            line = line.removeprefix("export ").strip()

            # Handle variable assignments
            if "=" not in line:
                continue

            # Split on first '=' only
            parts = line.split("=", 1)
            varname = parts[0].removesuffix("?").rstrip()  # Remove ?= operator
            value = parts[1].split("#")[0].strip()  # Remove trailing comments

            # Skip if not a variable we care about
            if varname not in BUILD_VAR_TO_KEY:
                continue

            value = _environment_substitute_str(value, environment)
            environment[varname] = value

    return environment


# Configuration variables and corresponding environment variables.
# TODO: distinguish between variables that are overridable by the user and those that are not.
BUILD_KEY_TO_VAR: dict[str, str] = {
    "pyodide_version": "PYODIDE_VERSION",
    "pyodide_abi_version": "PYODIDE_ABI_VERSION",
    "cargo_build_target": "CARGO_BUILD_TARGET",
    "cargo_target_wasm32_unknown_emscripten_linker": "CARGO_TARGET_WASM32_UNKNOWN_EMSCRIPTEN_LINKER",
    "host_install_dir": "HOSTINSTALLDIR",
    "host_site_packages": "HOSTSITEPACKAGES",
    "numpy_lib": "NUMPY_LIB",
    "pyodide_interpreter": "PYODIDE_INTERPRETER",
    "pyodide_package_index": "PYODIDE_PACKAGE_INDEX",
    "platform_triplet": "PLATFORM_TRIPLET",
    "pip_constraint": "PIP_CONSTRAINT",
    "pip_build_constraint": "PIP_BUILD_CONSTRAINT",
    "pymajor": "PYMAJOR",
    "pymicro": "PYMICRO",
    "pyminor": "PYMINOR",
    "pyo3_cross_include_dir": "PYO3_CROSS_INCLUDE_DIR",
    "pyo3_cross_lib_dir": "PYO3_CROSS_LIB_DIR",
    "pyo3_cross_python_version": "PYO3_CROSS_PYTHON_VERSION",
    "pyodide_emscripten_version": "PYODIDE_EMSCRIPTEN_VERSION",
    "pyodide_jobs": "PYODIDE_JOBS",
    "pyodide_root": "PYODIDE_ROOT",
    "python_archive_sha256": "PYTHON_ARCHIVE_SHA256",
    "python_archive_url": "PYTHON_ARCHIVE_URL",
    "pythoninclude": "PYTHONINCLUDE",
    "pyversion": "PYVERSION",
    "cpythoninstall": "CPYTHONINSTALL",
    "rustflags": "RUSTFLAGS",
    "rust_toolchain": "RUST_TOOLCHAIN",
    "rust_emscripten_target_url": "RUST_EMSCRIPTEN_TARGET_URL",
    "cflags": "SIDE_MODULE_CFLAGS",
    "cxxflags": "SIDE_MODULE_CXXFLAGS",
    "ldflags": "SIDE_MODULE_LDFLAGS",
    "sysconfigdata_dir": "SYSCONFIGDATA_DIR",
    "sysconfig_name": "SYSCONFIG_NAME",
    "targetinstalldir": "TARGETINSTALLDIR",
    "cmake_toolchain_file": "CMAKE_TOOLCHAIN_FILE",
    "meson_cross_file": "MESON_CROSS_FILE",
    "cflags_base": "CFLAGS_BASE",
    "cxxflags_base": "CXXFLAGS_BASE",
    "ldflags_base": "LDFLAGS_BASE",
    "zip_compression_level": "PYODIDE_ZIP_COMPRESSION_LEVEL",
    "skip_emscripten_version_check": "SKIP_EMSCRIPTEN_VERSION_CHECK",
    "build_dependency_index_url": "BUILD_DEPENDENCY_INDEX_URL",
    "default_cross_build_env_url": "DEFAULT_CROSS_BUILD_ENV_URL",
    "xbuildenv_path": "PYODIDE_XBUILDENV_PATH",
    "emsdk_dir": "PYODIDE_EMSDK_DIR",
    "emscripten_dir": "PYODIDE_EMSCRIPTEN_DIR",
    "dist_dir": "PYODIDE_DIST_DIR",
    "ignored_build_requirements": "IGNORED_BUILD_REQUIREMENTS",
    "use_legacy_platform": "USE_LEGACY_PLATFORM",
    # maintainer only
    "_f2c_fixes_wrapper": "_F2C_FIXES_WRAPPER",
}

BUILD_VAR_TO_KEY = {v: k for k, v in BUILD_KEY_TO_VAR.items()}

# Configuration keys that can be overridden by the user.
# TODO: distinguish between variables that are overridable by the user and those that are not.
OVERRIDABLE_BUILD_KEYS = {
    "cflags",
    "cxxflags",
    "ldflags",
    "rustflags",
    "rust_toolchain",
    "rust_emscripten_target_url",
    "meson_cross_file",
    "skip_emscripten_version_check",
    "build_dependency_index_url",
    "default_cross_build_env_url",
    "xbuildenv_path",
    "ignored_build_requirements",
    "use_legacy_platform",
    # maintainer only
    "_f2c_fixes_wrapper",
}

# Default configuration values.
TOOLS_DIR = Path(__file__).parent / "tools"
DEFAULT_CONFIG: dict[str, str] = {
    # Paths to toolchain configuration files
    "cmake_toolchain_file": str(TOOLS_DIR / "cmake/Modules/Platform/Emscripten.cmake"),
    "meson_cross_file": str(TOOLS_DIR / "emscripten.meson.cross"),
    # Rust-specific configuration
    "rustflags": "-C link-arg=-sSIDE_MODULE=2 -C link-arg=-sWASM_BIGINT",
    "cargo_build_target": "wasm32-unknown-emscripten",
    "cargo_target_wasm32_unknown_emscripten_linker": "emcc",
    "rust_toolchain": "nightly-2025-02-01",
    "rust_emscripten_target_url": "",
    # Other configuration
    "pyodide_jobs": "1",
    "skip_emscripten_version_check": "0",
    "build_dependency_index_url": "https://pypi.anaconda.org/pyodide/simple",
    "default_cross_build_env_url": "",
    "xbuildenv_path": "",
    # A list of PEP508 build-time requirements to be ignored when building a wheel
    "ignored_build_requirements": " ".join(BASE_IGNORED_REQUIREMENTS),
    "use_legacy_platform": "0",
    # maintainer only
    "_f2c_fixes_wrapper": "",
}

# Default configs that are computed from other values (often from Makefile.envs)
# TODO: Remove dependency on Makefile.envs
DEFAULT_CONFIG_COMPUTED: dict[str, str] = {
    # Compiler flags
    "cflags": "$(CFLAGS_BASE) -I$(PYTHONINCLUDE) -Oz",
    "cxxflags": "$(CFLAGS_BASE) -Oz",
    "ldflags": "$(LDFLAGS_BASE) -s SIDE_MODULE=1 -Oz",
    # Rust-specific configuration
    "pyo3_cross_lib_dir": "$(CPYTHONINSTALL)/sysconfigdata",  # FIXME: pyodide xbuildenv stores sysconfigdata here
    "pyo3_cross_include_dir": "$(PYTHONINCLUDE)",
    "pyo3_cross_python_version": "$(PYMAJOR).$(PYMINOR)",
    # Paths to build dependencies
    "host_install_dir": "$(PYODIDE_ROOT)/packages/.artifacts",
    "host_site_packages": "$(PYODIDE_ROOT)/packages/.artifacts/lib/python$(PYMAJOR).$(PYMINOR)/site-packages",
    "numpy_lib": "$(PYODIDE_ROOT)/packages/.artifacts/lib/python$(PYMAJOR).$(PYMINOR)/site-packages/numpy/",
    "pyodide_interpreter": "$(PYODIDE_ROOT)/dist/python",
    "pyodide_package_index": "$(PYODIDE_ROOT)/package_index",
    "dist_dir": "$(PYODIDE_ROOT)/dist",
    # Pip constraints - defaults to PIP_CONSTRAINT if not set
    "pip_build_constraint": "$(PIP_CONSTRAINT)",
}


# A dictionary of config variables that are exposed through pyodide config CLI.
PYODIDE_CLI_CONFIGS = {
    "emscripten_version": "PYODIDE_EMSCRIPTEN_VERSION",
    "python_version": "PYVERSION",
    "rustflags": "RUSTFLAGS",
    "cmake_toolchain_file": "CMAKE_TOOLCHAIN_FILE",
    "rust_toolchain": "RUST_TOOLCHAIN",
    "rust_emscripten_target_url": "RUST_EMSCRIPTEN_TARGET_URL",
    "cflags": "SIDE_MODULE_CFLAGS",
    "cxxflags": "SIDE_MODULE_CXXFLAGS",
    "ldflags": "SIDE_MODULE_LDFLAGS",
    "meson_cross_file": "MESON_CROSS_FILE",
    "xbuildenv_path": "PYODIDE_XBUILDENV_PATH",
    "emsdk_dir": "PYODIDE_EMSDK_DIR",
    "emscripten_dir": "PYODIDE_EMSCRIPTEN_DIR",
    "pyodide_abi_version": "PYODIDE_ABI_VERSION",
    "pyodide_root": "PYODIDE_ROOT",
    "dist_dir": "PYODIDE_DIST_DIR",
    "python_include_dir": "PYTHONINCLUDE",
    "ignored_build_requirements": "IGNORED_BUILD_REQUIREMENTS",
    "interpreter": "PYODIDE_INTERPRETER",
    "package_index": "PYODIDE_PACKAGE_INDEX",
}
