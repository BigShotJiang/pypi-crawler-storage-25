from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.batch_upload_record_item_dto import BatchUploadRecordItemDto





T = TypeVar("T", bound="FailedUploadItem")



@_attrs_define
class FailedUploadItem:
    """ 
        Attributes:
            index (Any):
            file_name (str):
            error (str):
            item (BatchUploadRecordItemDto):
     """

    index: Any
    file_name: str
    error: str
    item: BatchUploadRecordItemDto
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.batch_upload_record_item_dto import BatchUploadRecordItemDto
        index = self.index

        file_name = self.file_name

        error = self.error

        item = self.item.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "index": index,
            "fileName": file_name,
            "error": error,
            "item": item,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.batch_upload_record_item_dto import BatchUploadRecordItemDto
        d = dict(src_dict)
        index = d.pop("index")

        file_name = d.pop("fileName")

        error = d.pop("error")

        item = BatchUploadRecordItemDto.from_dict(d.pop("item"))




        failed_upload_item = cls(
            index=index,
            file_name=file_name,
            error=error,
            item=item,
        )


        failed_upload_item.additional_properties = d
        return failed_upload_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
