from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.agent_type import AgentType
from ..models.agent_type import check_agent_type
from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="CreateMiniCosmosCommand")



@_attrs_define
class CreateMiniCosmosCommand:
    """ 
        Attributes:
            name (str):
            agent_type (AgentType | Unset):
            profile_picture_url (str | Unset):
            profile (Any | Unset):
            external_uri (str | Unset):
            labels (list[str] | None | Unset):
     """

    name: str
    agent_type: AgentType | Unset = UNSET
    profile_picture_url: str | Unset = UNSET
    profile: Any | Unset = UNSET
    external_uri: str | Unset = UNSET
    labels: list[str] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        name = self.name

        agent_type: str | Unset = UNSET
        if not isinstance(self.agent_type, Unset):
            agent_type = self.agent_type


        profile_picture_url = self.profile_picture_url

        profile = self.profile

        external_uri = self.external_uri

        labels: list[str] | None | Unset
        if isinstance(self.labels, Unset):
            labels = UNSET
        elif isinstance(self.labels, list):
            labels = self.labels


        else:
            labels = self.labels


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "name": name,
        })
        if agent_type is not UNSET:
            field_dict["agentType"] = agent_type
        if profile_picture_url is not UNSET:
            field_dict["profilePictureUrl"] = profile_picture_url
        if profile is not UNSET:
            field_dict["profile"] = profile
        if external_uri is not UNSET:
            field_dict["externalUri"] = external_uri
        if labels is not UNSET:
            field_dict["labels"] = labels

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        _agent_type = d.pop("agentType", UNSET)
        agent_type: AgentType | Unset
        if isinstance(_agent_type,  Unset):
            agent_type = UNSET
        else:
            agent_type = check_agent_type(_agent_type)




        profile_picture_url = d.pop("profilePictureUrl", UNSET)

        profile = d.pop("profile", UNSET)

        external_uri = d.pop("externalUri", UNSET)

        def _parse_labels(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                labels_type_0 = cast(list[str], data)

                return labels_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        labels = _parse_labels(d.pop("labels", UNSET))


        create_mini_cosmos_command = cls(
            name=name,
            agent_type=agent_type,
            profile_picture_url=profile_picture_url,
            profile=profile,
            external_uri=external_uri,
            labels=labels,
        )


        create_mini_cosmos_command.additional_properties = d
        return create_mini_cosmos_command

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
