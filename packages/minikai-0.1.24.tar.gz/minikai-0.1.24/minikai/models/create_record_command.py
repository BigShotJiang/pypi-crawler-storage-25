from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.record_state import check_record_state
from ..models.record_state import RecordState
from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime

if TYPE_CHECKING:
  from ..models.create_record_command_tags import CreateRecordCommandTags
  from ..models.record_authorization_dto import RecordAuthorizationDto
  from ..models.record_relation_dto import RecordRelationDto





T = TypeVar("T", bound="CreateRecordCommand")



@_attrs_define
class CreateRecordCommand:
    """ 
        Attributes:
            title (None | str | Unset):
            description (None | str | Unset):
            mini_id (None | str | Unset):
            event_date (datetime.datetime | None | Unset):
            schema (Any | Unset):
            content (Any | Unset):
            relations (list[RecordRelationDto] | Unset):
            external_uri (str | Unset):
            labels (list[str] | Unset):
            tags (CreateRecordCommandTags | Unset):
            authorization (RecordAuthorizationDto | Unset):
            state (RecordState | Unset):
            batch_process (bool | Unset):
     """

    title: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    mini_id: None | str | Unset = UNSET
    event_date: datetime.datetime | None | Unset = UNSET
    schema: Any | Unset = UNSET
    content: Any | Unset = UNSET
    relations: list[RecordRelationDto] | Unset = UNSET
    external_uri: str | Unset = UNSET
    labels: list[str] | Unset = UNSET
    tags: CreateRecordCommandTags | Unset = UNSET
    authorization: RecordAuthorizationDto | Unset = UNSET
    state: RecordState | Unset = UNSET
    batch_process: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.create_record_command_tags import CreateRecordCommandTags
        from ..models.record_authorization_dto import RecordAuthorizationDto
        from ..models.record_relation_dto import RecordRelationDto
        title: None | str | Unset
        if isinstance(self.title, Unset):
            title = UNSET
        else:
            title = self.title

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        mini_id: None | str | Unset
        if isinstance(self.mini_id, Unset):
            mini_id = UNSET
        else:
            mini_id = self.mini_id

        event_date: None | str | Unset
        if isinstance(self.event_date, Unset):
            event_date = UNSET
        elif isinstance(self.event_date, datetime.datetime):
            event_date = self.event_date.isoformat()
        else:
            event_date = self.event_date

        schema = self.schema

        content = self.content

        relations: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.relations, Unset):
            relations = []
            for relations_item_data in self.relations:
                relations_item = relations_item_data.to_dict()
                relations.append(relations_item)



        external_uri = self.external_uri

        labels: list[str] | Unset = UNSET
        if not isinstance(self.labels, Unset):
            labels = self.labels



        tags: dict[str, Any] | Unset = UNSET
        if not isinstance(self.tags, Unset):
            tags = self.tags.to_dict()

        authorization: dict[str, Any] | Unset = UNSET
        if not isinstance(self.authorization, Unset):
            authorization = self.authorization.to_dict()

        state: str | Unset = UNSET
        if not isinstance(self.state, Unset):
            state = self.state


        batch_process = self.batch_process


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if title is not UNSET:
            field_dict["title"] = title
        if description is not UNSET:
            field_dict["description"] = description
        if mini_id is not UNSET:
            field_dict["miniId"] = mini_id
        if event_date is not UNSET:
            field_dict["eventDate"] = event_date
        if schema is not UNSET:
            field_dict["schema"] = schema
        if content is not UNSET:
            field_dict["content"] = content
        if relations is not UNSET:
            field_dict["relations"] = relations
        if external_uri is not UNSET:
            field_dict["externalUri"] = external_uri
        if labels is not UNSET:
            field_dict["labels"] = labels
        if tags is not UNSET:
            field_dict["tags"] = tags
        if authorization is not UNSET:
            field_dict["authorization"] = authorization
        if state is not UNSET:
            field_dict["state"] = state
        if batch_process is not UNSET:
            field_dict["batchProcess"] = batch_process

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.create_record_command_tags import CreateRecordCommandTags
        from ..models.record_authorization_dto import RecordAuthorizationDto
        from ..models.record_relation_dto import RecordRelationDto
        d = dict(src_dict)
        def _parse_title(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        title = _parse_title(d.pop("title", UNSET))


        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))


        def _parse_mini_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        mini_id = _parse_mini_id(d.pop("miniId", UNSET))


        def _parse_event_date(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                event_date_type_0 = isoparse(data)



                return event_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        event_date = _parse_event_date(d.pop("eventDate", UNSET))


        schema = d.pop("schema", UNSET)

        content = d.pop("content", UNSET)

        _relations = d.pop("relations", UNSET)
        relations: list[RecordRelationDto] | Unset = UNSET
        if _relations is not UNSET:
            relations = []
            for relations_item_data in _relations:
                relations_item = RecordRelationDto.from_dict(relations_item_data)



                relations.append(relations_item)


        external_uri = d.pop("externalUri", UNSET)

        labels = cast(list[str], d.pop("labels", UNSET))


        _tags = d.pop("tags", UNSET)
        tags: CreateRecordCommandTags | Unset
        if isinstance(_tags,  Unset):
            tags = UNSET
        else:
            tags = CreateRecordCommandTags.from_dict(_tags)




        _authorization = d.pop("authorization", UNSET)
        authorization: RecordAuthorizationDto | Unset
        if isinstance(_authorization,  Unset):
            authorization = UNSET
        else:
            authorization = RecordAuthorizationDto.from_dict(_authorization)




        _state = d.pop("state", UNSET)
        state: RecordState | Unset
        if isinstance(_state,  Unset):
            state = UNSET
        else:
            state = check_record_state(_state)




        batch_process = d.pop("batchProcess", UNSET)

        create_record_command = cls(
            title=title,
            description=description,
            mini_id=mini_id,
            event_date=event_date,
            schema=schema,
            content=content,
            relations=relations,
            external_uri=external_uri,
            labels=labels,
            tags=tags,
            authorization=authorization,
            state=state,
            batch_process=batch_process,
        )


        create_record_command.additional_properties = d
        return create_record_command

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
