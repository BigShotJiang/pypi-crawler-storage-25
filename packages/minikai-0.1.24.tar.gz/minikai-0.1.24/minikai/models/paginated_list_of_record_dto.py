from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.record_dto import RecordDto





T = TypeVar("T", bound="PaginatedListOfRecordDto")



@_attrs_define
class PaginatedListOfRecordDto:
    """ 
        Attributes:
            items (list[RecordDto]):
            page_number (Any):
            total_pages (Any | Unset):
            total_count (Any | Unset):
            has_previous_page (bool | Unset):
            has_next_page (bool | Unset):
     """

    items: list[RecordDto]
    page_number: Any
    total_pages: Any | Unset = UNSET
    total_count: Any | Unset = UNSET
    has_previous_page: bool | Unset = UNSET
    has_next_page: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.record_dto import RecordDto
        items = []
        for items_item_data in self.items:
            items_item = items_item_data.to_dict()
            items.append(items_item)



        page_number = self.page_number

        total_pages = self.total_pages

        total_count = self.total_count

        has_previous_page = self.has_previous_page

        has_next_page = self.has_next_page


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "items": items,
            "pageNumber": page_number,
        })
        if total_pages is not UNSET:
            field_dict["totalPages"] = total_pages
        if total_count is not UNSET:
            field_dict["totalCount"] = total_count
        if has_previous_page is not UNSET:
            field_dict["hasPreviousPage"] = has_previous_page
        if has_next_page is not UNSET:
            field_dict["hasNextPage"] = has_next_page

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.record_dto import RecordDto
        d = dict(src_dict)
        items = []
        _items = d.pop("items")
        for items_item_data in (_items):
            items_item = RecordDto.from_dict(items_item_data)



            items.append(items_item)


        page_number = d.pop("pageNumber")

        total_pages = d.pop("totalPages", UNSET)

        total_count = d.pop("totalCount", UNSET)

        has_previous_page = d.pop("hasPreviousPage", UNSET)

        has_next_page = d.pop("hasNextPage", UNSET)

        paginated_list_of_record_dto = cls(
            items=items,
            page_number=page_number,
            total_pages=total_pages,
            total_count=total_count,
            has_previous_page=has_previous_page,
            has_next_page=has_next_page,
        )


        paginated_list_of_record_dto.additional_properties = d
        return paginated_list_of_record_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
