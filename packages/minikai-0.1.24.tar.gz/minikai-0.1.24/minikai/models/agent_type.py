from typing import Literal, cast

AgentType = Literal['person', 'workspace']

AGENT_TYPE_VALUES: set[AgentType] = { 'person', 'workspace',  }

def check_agent_type(value: str) -> AgentType:
    if value in AGENT_TYPE_VALUES:
        return cast(AgentType, value)
    raise TypeError(f"Unexpected value {value!r}. Expected one of {AGENT_TYPE_VALUES!r}")
