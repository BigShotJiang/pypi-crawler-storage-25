from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime

if TYPE_CHECKING:
  from ..models.record_attachment_dto import RecordAttachmentDto
  from ..models.record_authorization_dto import RecordAuthorizationDto
  from ..models.record_relation_dto import RecordRelationDto
  from ..models.record_version_dto_tags import RecordVersionDtoTags





T = TypeVar("T", bound="RecordVersionDto")



@_attrs_define
class RecordVersionDto:
    """ 
        Attributes:
            id (UUID | Unset):
            record_id (UUID | Unset):
            title (None | str | Unset):
            description (None | str | Unset):
            created_at (datetime.datetime | Unset):
            updated_at (datetime.datetime | Unset):
            event_date (datetime.datetime | None | Unset):
            created_by (str | Unset):
            updated_by (None | str | Unset):
            searchable (bool | Unset):
            archived (bool | Unset):
            schema (Any | Unset):
            content (Any | Unset):
            content_text (None | str | Unset):
            attachments (list[RecordAttachmentDto] | Unset):
            authorization (RecordAuthorizationDto | Unset):
            relations (list[RecordRelationDto] | Unset):
            external_uri (str | Unset):
            labels (list[str] | Unset):
            tags (RecordVersionDtoTags | Unset):
            checksum (None | str | Unset):
     """

    id: UUID | Unset = UNSET
    record_id: UUID | Unset = UNSET
    title: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    updated_at: datetime.datetime | Unset = UNSET
    event_date: datetime.datetime | None | Unset = UNSET
    created_by: str | Unset = UNSET
    updated_by: None | str | Unset = UNSET
    searchable: bool | Unset = UNSET
    archived: bool | Unset = UNSET
    schema: Any | Unset = UNSET
    content: Any | Unset = UNSET
    content_text: None | str | Unset = UNSET
    attachments: list[RecordAttachmentDto] | Unset = UNSET
    authorization: RecordAuthorizationDto | Unset = UNSET
    relations: list[RecordRelationDto] | Unset = UNSET
    external_uri: str | Unset = UNSET
    labels: list[str] | Unset = UNSET
    tags: RecordVersionDtoTags | Unset = UNSET
    checksum: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.record_attachment_dto import RecordAttachmentDto
        from ..models.record_authorization_dto import RecordAuthorizationDto
        from ..models.record_relation_dto import RecordRelationDto
        from ..models.record_version_dto_tags import RecordVersionDtoTags
        id: str | Unset = UNSET
        if not isinstance(self.id, Unset):
            id = str(self.id)

        record_id: str | Unset = UNSET
        if not isinstance(self.record_id, Unset):
            record_id = str(self.record_id)

        title: None | str | Unset
        if isinstance(self.title, Unset):
            title = UNSET
        else:
            title = self.title

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        updated_at: str | Unset = UNSET
        if not isinstance(self.updated_at, Unset):
            updated_at = self.updated_at.isoformat()

        event_date: None | str | Unset
        if isinstance(self.event_date, Unset):
            event_date = UNSET
        elif isinstance(self.event_date, datetime.datetime):
            event_date = self.event_date.isoformat()
        else:
            event_date = self.event_date

        created_by = self.created_by

        updated_by: None | str | Unset
        if isinstance(self.updated_by, Unset):
            updated_by = UNSET
        else:
            updated_by = self.updated_by

        searchable = self.searchable

        archived = self.archived

        schema = self.schema

        content = self.content

        content_text: None | str | Unset
        if isinstance(self.content_text, Unset):
            content_text = UNSET
        else:
            content_text = self.content_text

        attachments: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.attachments, Unset):
            attachments = []
            for attachments_item_data in self.attachments:
                attachments_item = attachments_item_data.to_dict()
                attachments.append(attachments_item)



        authorization: dict[str, Any] | Unset = UNSET
        if not isinstance(self.authorization, Unset):
            authorization = self.authorization.to_dict()

        relations: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.relations, Unset):
            relations = []
            for relations_item_data in self.relations:
                relations_item = relations_item_data.to_dict()
                relations.append(relations_item)



        external_uri = self.external_uri

        labels: list[str] | Unset = UNSET
        if not isinstance(self.labels, Unset):
            labels = self.labels



        tags: dict[str, Any] | Unset = UNSET
        if not isinstance(self.tags, Unset):
            tags = self.tags.to_dict()

        checksum: None | str | Unset
        if isinstance(self.checksum, Unset):
            checksum = UNSET
        else:
            checksum = self.checksum


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if id is not UNSET:
            field_dict["id"] = id
        if record_id is not UNSET:
            field_dict["recordId"] = record_id
        if title is not UNSET:
            field_dict["title"] = title
        if description is not UNSET:
            field_dict["description"] = description
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if updated_at is not UNSET:
            field_dict["updatedAt"] = updated_at
        if event_date is not UNSET:
            field_dict["eventDate"] = event_date
        if created_by is not UNSET:
            field_dict["createdBy"] = created_by
        if updated_by is not UNSET:
            field_dict["updatedBy"] = updated_by
        if searchable is not UNSET:
            field_dict["searchable"] = searchable
        if archived is not UNSET:
            field_dict["archived"] = archived
        if schema is not UNSET:
            field_dict["schema"] = schema
        if content is not UNSET:
            field_dict["content"] = content
        if content_text is not UNSET:
            field_dict["contentText"] = content_text
        if attachments is not UNSET:
            field_dict["attachments"] = attachments
        if authorization is not UNSET:
            field_dict["authorization"] = authorization
        if relations is not UNSET:
            field_dict["relations"] = relations
        if external_uri is not UNSET:
            field_dict["externalUri"] = external_uri
        if labels is not UNSET:
            field_dict["labels"] = labels
        if tags is not UNSET:
            field_dict["tags"] = tags
        if checksum is not UNSET:
            field_dict["checksum"] = checksum

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.record_attachment_dto import RecordAttachmentDto
        from ..models.record_authorization_dto import RecordAuthorizationDto
        from ..models.record_relation_dto import RecordRelationDto
        from ..models.record_version_dto_tags import RecordVersionDtoTags
        d = dict(src_dict)
        _id = d.pop("id", UNSET)
        id: UUID | Unset
        if isinstance(_id,  Unset):
            id = UNSET
        else:
            id = UUID(_id)




        _record_id = d.pop("recordId", UNSET)
        record_id: UUID | Unset
        if isinstance(_record_id,  Unset):
            record_id = UNSET
        else:
            record_id = UUID(_record_id)




        def _parse_title(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        title = _parse_title(d.pop("title", UNSET))


        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))


        _created_at = d.pop("createdAt", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at,  Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)




        _updated_at = d.pop("updatedAt", UNSET)
        updated_at: datetime.datetime | Unset
        if isinstance(_updated_at,  Unset):
            updated_at = UNSET
        else:
            updated_at = isoparse(_updated_at)




        def _parse_event_date(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                event_date_type_0 = isoparse(data)



                return event_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        event_date = _parse_event_date(d.pop("eventDate", UNSET))


        created_by = d.pop("createdBy", UNSET)

        def _parse_updated_by(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        updated_by = _parse_updated_by(d.pop("updatedBy", UNSET))


        searchable = d.pop("searchable", UNSET)

        archived = d.pop("archived", UNSET)

        schema = d.pop("schema", UNSET)

        content = d.pop("content", UNSET)

        def _parse_content_text(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        content_text = _parse_content_text(d.pop("contentText", UNSET))


        _attachments = d.pop("attachments", UNSET)
        attachments: list[RecordAttachmentDto] | Unset = UNSET
        if _attachments is not UNSET:
            attachments = []
            for attachments_item_data in _attachments:
                attachments_item = RecordAttachmentDto.from_dict(attachments_item_data)



                attachments.append(attachments_item)


        _authorization = d.pop("authorization", UNSET)
        authorization: RecordAuthorizationDto | Unset
        if isinstance(_authorization,  Unset):
            authorization = UNSET
        else:
            authorization = RecordAuthorizationDto.from_dict(_authorization)




        _relations = d.pop("relations", UNSET)
        relations: list[RecordRelationDto] | Unset = UNSET
        if _relations is not UNSET:
            relations = []
            for relations_item_data in _relations:
                relations_item = RecordRelationDto.from_dict(relations_item_data)



                relations.append(relations_item)


        external_uri = d.pop("externalUri", UNSET)

        labels = cast(list[str], d.pop("labels", UNSET))


        _tags = d.pop("tags", UNSET)
        tags: RecordVersionDtoTags | Unset
        if isinstance(_tags,  Unset):
            tags = UNSET
        else:
            tags = RecordVersionDtoTags.from_dict(_tags)




        def _parse_checksum(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        checksum = _parse_checksum(d.pop("checksum", UNSET))


        record_version_dto = cls(
            id=id,
            record_id=record_id,
            title=title,
            description=description,
            created_at=created_at,
            updated_at=updated_at,
            event_date=event_date,
            created_by=created_by,
            updated_by=updated_by,
            searchable=searchable,
            archived=archived,
            schema=schema,
            content=content,
            content_text=content_text,
            attachments=attachments,
            authorization=authorization,
            relations=relations,
            external_uri=external_uri,
            labels=labels,
            tags=tags,
            checksum=checksum,
        )


        record_version_dto.additional_properties = d
        return record_version_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
