from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.batch_upload_result_successful_ids import BatchUploadResultSuccessfulIds
  from ..models.failed_upload_item import FailedUploadItem





T = TypeVar("T", bound="BatchUploadResult")



@_attrs_define
class BatchUploadResult:
    """ 
        Attributes:
            successful_ids (BatchUploadResultSuccessfulIds | Unset):
            failed (list[FailedUploadItem] | Unset):
            success_count (Any | Unset):
            failure_count (Any | Unset):
     """

    successful_ids: BatchUploadResultSuccessfulIds | Unset = UNSET
    failed: list[FailedUploadItem] | Unset = UNSET
    success_count: Any | Unset = UNSET
    failure_count: Any | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.batch_upload_result_successful_ids import BatchUploadResultSuccessfulIds
        from ..models.failed_upload_item import FailedUploadItem
        successful_ids: dict[str, Any] | Unset = UNSET
        if not isinstance(self.successful_ids, Unset):
            successful_ids = self.successful_ids.to_dict()

        failed: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.failed, Unset):
            failed = []
            for failed_item_data in self.failed:
                failed_item = failed_item_data.to_dict()
                failed.append(failed_item)



        success_count = self.success_count

        failure_count = self.failure_count


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if successful_ids is not UNSET:
            field_dict["successfulIds"] = successful_ids
        if failed is not UNSET:
            field_dict["failed"] = failed
        if success_count is not UNSET:
            field_dict["successCount"] = success_count
        if failure_count is not UNSET:
            field_dict["failureCount"] = failure_count

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.batch_upload_result_successful_ids import BatchUploadResultSuccessfulIds
        from ..models.failed_upload_item import FailedUploadItem
        d = dict(src_dict)
        _successful_ids = d.pop("successfulIds", UNSET)
        successful_ids: BatchUploadResultSuccessfulIds | Unset
        if isinstance(_successful_ids,  Unset):
            successful_ids = UNSET
        else:
            successful_ids = BatchUploadResultSuccessfulIds.from_dict(_successful_ids)




        _failed = d.pop("failed", UNSET)
        failed: list[FailedUploadItem] | Unset = UNSET
        if _failed is not UNSET:
            failed = []
            for failed_item_data in _failed:
                failed_item = FailedUploadItem.from_dict(failed_item_data)



                failed.append(failed_item)


        success_count = d.pop("successCount", UNSET)

        failure_count = d.pop("failureCount", UNSET)

        batch_upload_result = cls(
            successful_ids=successful_ids,
            failed=failed,
            success_count=success_count,
            failure_count=failure_count,
        )


        batch_upload_result.additional_properties = d
        return batch_upload_result

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
