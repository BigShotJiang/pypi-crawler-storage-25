from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="UpsertExternalMiniCosmosCommand")



@_attrs_define
class UpsertExternalMiniCosmosCommand:
    """ 
        Attributes:
            external_uri (str):
            name (str):
            profile_picture_url (str | Unset):
            profile (Any | Unset):
     """

    external_uri: str
    name: str
    profile_picture_url: str | Unset = UNSET
    profile: Any | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        external_uri = self.external_uri

        name = self.name

        profile_picture_url = self.profile_picture_url

        profile = self.profile


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "externalUri": external_uri,
            "name": name,
        })
        if profile_picture_url is not UNSET:
            field_dict["profilePictureUrl"] = profile_picture_url
        if profile is not UNSET:
            field_dict["profile"] = profile

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        external_uri = d.pop("externalUri")

        name = d.pop("name")

        profile_picture_url = d.pop("profilePictureUrl", UNSET)

        profile = d.pop("profile", UNSET)

        upsert_external_mini_cosmos_command = cls(
            external_uri=external_uri,
            name=name,
            profile_picture_url=profile_picture_url,
            profile=profile,
        )


        upsert_external_mini_cosmos_command.additional_properties = d
        return upsert_external_mini_cosmos_command

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
