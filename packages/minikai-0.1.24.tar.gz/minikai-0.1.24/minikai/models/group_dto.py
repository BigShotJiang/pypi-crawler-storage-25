from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID

if TYPE_CHECKING:
  from ..models.mini_cosmos_dto import MiniCosmosDto
  from ..models.user_dto import UserDto





T = TypeVar("T", bound="GroupDto")



@_attrs_define
class GroupDto:
    """ 
        Attributes:
            name (str):
            organization_id (str):
            id (UUID | Unset):
            description (None | str | Unset):
            users (list[UserDto] | Unset):
            minis (list[MiniCosmosDto] | Unset):
     """

    name: str
    organization_id: str
    id: UUID | Unset = UNSET
    description: None | str | Unset = UNSET
    users: list[UserDto] | Unset = UNSET
    minis: list[MiniCosmosDto] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.mini_cosmos_dto import MiniCosmosDto
        from ..models.user_dto import UserDto
        name = self.name

        organization_id = self.organization_id

        id: str | Unset = UNSET
        if not isinstance(self.id, Unset):
            id = str(self.id)

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        users: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.users, Unset):
            users = []
            for users_item_data in self.users:
                users_item = users_item_data.to_dict()
                users.append(users_item)



        minis: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.minis, Unset):
            minis = []
            for minis_item_data in self.minis:
                minis_item = minis_item_data.to_dict()
                minis.append(minis_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "name": name,
            "organizationId": organization_id,
        })
        if id is not UNSET:
            field_dict["id"] = id
        if description is not UNSET:
            field_dict["description"] = description
        if users is not UNSET:
            field_dict["users"] = users
        if minis is not UNSET:
            field_dict["minis"] = minis

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.mini_cosmos_dto import MiniCosmosDto
        from ..models.user_dto import UserDto
        d = dict(src_dict)
        name = d.pop("name")

        organization_id = d.pop("organizationId")

        _id = d.pop("id", UNSET)
        id: UUID | Unset
        if isinstance(_id,  Unset):
            id = UNSET
        else:
            id = UUID(_id)




        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))


        _users = d.pop("users", UNSET)
        users: list[UserDto] | Unset = UNSET
        if _users is not UNSET:
            users = []
            for users_item_data in _users:
                users_item = UserDto.from_dict(users_item_data)



                users.append(users_item)


        _minis = d.pop("minis", UNSET)
        minis: list[MiniCosmosDto] | Unset = UNSET
        if _minis is not UNSET:
            minis = []
            for minis_item_data in _minis:
                minis_item = MiniCosmosDto.from_dict(minis_item_data)



                minis.append(minis_item)


        group_dto = cls(
            name=name,
            organization_id=organization_id,
            id=id,
            description=description,
            users=users,
            minis=minis,
        )


        group_dto.additional_properties = d
        return group_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
