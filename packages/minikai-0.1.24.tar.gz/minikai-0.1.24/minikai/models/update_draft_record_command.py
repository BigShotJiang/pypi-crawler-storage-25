from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime

if TYPE_CHECKING:
  from ..models.record_authorization_dto import RecordAuthorizationDto
  from ..models.record_relation_dto import RecordRelationDto
  from ..models.update_draft_record_command_tags import UpdateDraftRecordCommandTags





T = TypeVar("T", bound="UpdateDraftRecordCommand")



@_attrs_define
class UpdateDraftRecordCommand:
    """ 
        Attributes:
            id (UUID):
            title (None | str | Unset):
            description (None | str | Unset):
            event_date (datetime.datetime | None | Unset):
            schema (Any | Unset):
            content (Any | Unset):
            relations (list[RecordRelationDto] | Unset):
            external_uri (str | Unset):
            labels (list[str] | Unset):
            tags (UpdateDraftRecordCommandTags | Unset):
            authorization (Any | RecordAuthorizationDto | Unset):
            e_tag (None | str | Unset):
     """

    id: UUID
    title: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    event_date: datetime.datetime | None | Unset = UNSET
    schema: Any | Unset = UNSET
    content: Any | Unset = UNSET
    relations: list[RecordRelationDto] | Unset = UNSET
    external_uri: str | Unset = UNSET
    labels: list[str] | Unset = UNSET
    tags: UpdateDraftRecordCommandTags | Unset = UNSET
    authorization: Any | RecordAuthorizationDto | Unset = UNSET
    e_tag: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.record_authorization_dto import RecordAuthorizationDto
        from ..models.record_relation_dto import RecordRelationDto
        from ..models.update_draft_record_command_tags import UpdateDraftRecordCommandTags
        id = str(self.id)

        title: None | str | Unset
        if isinstance(self.title, Unset):
            title = UNSET
        else:
            title = self.title

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        event_date: None | str | Unset
        if isinstance(self.event_date, Unset):
            event_date = UNSET
        elif isinstance(self.event_date, datetime.datetime):
            event_date = self.event_date.isoformat()
        else:
            event_date = self.event_date

        schema = self.schema

        content = self.content

        relations: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.relations, Unset):
            relations = []
            for relations_item_data in self.relations:
                relations_item = relations_item_data.to_dict()
                relations.append(relations_item)



        external_uri = self.external_uri

        labels: list[str] | Unset = UNSET
        if not isinstance(self.labels, Unset):
            labels = self.labels



        tags: dict[str, Any] | Unset = UNSET
        if not isinstance(self.tags, Unset):
            tags = self.tags.to_dict()

        authorization: Any | dict[str, Any] | Unset
        if isinstance(self.authorization, Unset):
            authorization = UNSET
        elif isinstance(self.authorization, RecordAuthorizationDto):
            authorization = self.authorization.to_dict()
        else:
            authorization = self.authorization

        e_tag: None | str | Unset
        if isinstance(self.e_tag, Unset):
            e_tag = UNSET
        else:
            e_tag = self.e_tag


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
        })
        if title is not UNSET:
            field_dict["title"] = title
        if description is not UNSET:
            field_dict["description"] = description
        if event_date is not UNSET:
            field_dict["eventDate"] = event_date
        if schema is not UNSET:
            field_dict["schema"] = schema
        if content is not UNSET:
            field_dict["content"] = content
        if relations is not UNSET:
            field_dict["relations"] = relations
        if external_uri is not UNSET:
            field_dict["externalUri"] = external_uri
        if labels is not UNSET:
            field_dict["labels"] = labels
        if tags is not UNSET:
            field_dict["tags"] = tags
        if authorization is not UNSET:
            field_dict["authorization"] = authorization
        if e_tag is not UNSET:
            field_dict["eTag"] = e_tag

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.record_authorization_dto import RecordAuthorizationDto
        from ..models.record_relation_dto import RecordRelationDto
        from ..models.update_draft_record_command_tags import UpdateDraftRecordCommandTags
        d = dict(src_dict)
        id = UUID(d.pop("id"))




        def _parse_title(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        title = _parse_title(d.pop("title", UNSET))


        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))


        def _parse_event_date(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                event_date_type_0 = isoparse(data)



                return event_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        event_date = _parse_event_date(d.pop("eventDate", UNSET))


        schema = d.pop("schema", UNSET)

        content = d.pop("content", UNSET)

        _relations = d.pop("relations", UNSET)
        relations: list[RecordRelationDto] | Unset = UNSET
        if _relations is not UNSET:
            relations = []
            for relations_item_data in _relations:
                relations_item = RecordRelationDto.from_dict(relations_item_data)



                relations.append(relations_item)


        external_uri = d.pop("externalUri", UNSET)

        labels = cast(list[str], d.pop("labels", UNSET))


        _tags = d.pop("tags", UNSET)
        tags: UpdateDraftRecordCommandTags | Unset
        if isinstance(_tags,  Unset):
            tags = UNSET
        else:
            tags = UpdateDraftRecordCommandTags.from_dict(_tags)




        def _parse_authorization(data: object) -> Any | RecordAuthorizationDto | Unset:
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                authorization_type_1 = RecordAuthorizationDto.from_dict(data)



                return authorization_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(Any | RecordAuthorizationDto | Unset, data)

        authorization = _parse_authorization(d.pop("authorization", UNSET))


        def _parse_e_tag(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        e_tag = _parse_e_tag(d.pop("eTag", UNSET))


        update_draft_record_command = cls(
            id=id,
            title=title,
            description=description,
            event_date=event_date,
            schema=schema,
            content=content,
            relations=relations,
            external_uri=external_uri,
            labels=labels,
            tags=tags,
            authorization=authorization,
            e_tag=e_tag,
        )


        update_draft_record_command.additional_properties = d
        return update_draft_record_command

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
