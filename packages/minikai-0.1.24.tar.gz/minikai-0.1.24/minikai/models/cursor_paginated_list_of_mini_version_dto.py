from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.mini_version_dto import MiniVersionDto





T = TypeVar("T", bound="CursorPaginatedListOfMiniVersionDto")



@_attrs_define
class CursorPaginatedListOfMiniVersionDto:
    """ 
        Attributes:
            items (list[MiniVersionDto]):
            before_cursor (None | str):
            after_cursor (None | str):
            total_count (Any | Unset):
     """

    items: list[MiniVersionDto]
    before_cursor: None | str
    after_cursor: None | str
    total_count: Any | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.mini_version_dto import MiniVersionDto
        items = []
        for items_item_data in self.items:
            items_item = items_item_data.to_dict()
            items.append(items_item)



        before_cursor: None | str
        before_cursor = self.before_cursor

        after_cursor: None | str
        after_cursor = self.after_cursor

        total_count = self.total_count


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "items": items,
            "beforeCursor": before_cursor,
            "afterCursor": after_cursor,
        })
        if total_count is not UNSET:
            field_dict["totalCount"] = total_count

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.mini_version_dto import MiniVersionDto
        d = dict(src_dict)
        items = []
        _items = d.pop("items")
        for items_item_data in (_items):
            items_item = MiniVersionDto.from_dict(items_item_data)



            items.append(items_item)


        def _parse_before_cursor(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        before_cursor = _parse_before_cursor(d.pop("beforeCursor"))


        def _parse_after_cursor(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        after_cursor = _parse_after_cursor(d.pop("afterCursor"))


        total_count = d.pop("totalCount", UNSET)

        cursor_paginated_list_of_mini_version_dto = cls(
            items=items,
            before_cursor=before_cursor,
            after_cursor=after_cursor,
            total_count=total_count,
        )


        cursor_paginated_list_of_mini_version_dto.additional_properties = d
        return cursor_paginated_list_of_mini_version_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
