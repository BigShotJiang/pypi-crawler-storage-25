from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from uuid import UUID






T = TypeVar("T", bound="FailedAttachmentItem")



@_attrs_define
class FailedAttachmentItem:
    """ 
        Attributes:
            index (Any):
            file_name (str):
            record_id (UUID):
            error (str):
     """

    index: Any
    file_name: str
    record_id: UUID
    error: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        index = self.index

        file_name = self.file_name

        record_id = str(self.record_id)

        error = self.error


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "index": index,
            "fileName": file_name,
            "recordId": record_id,
            "error": error,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        index = d.pop("index")

        file_name = d.pop("fileName")

        record_id = UUID(d.pop("recordId"))




        error = d.pop("error")

        failed_attachment_item = cls(
            index=index,
            file_name=file_name,
            record_id=record_id,
            error=error,
        )


        failed_attachment_item.additional_properties = d
        return failed_attachment_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
