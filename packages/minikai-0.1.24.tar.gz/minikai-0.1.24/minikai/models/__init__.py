""" Contains all the data models used in inputs/outputs """

from .add_attachments_body import AddAttachmentsBody
from .agent_type import AgentType
from .batch_add_attachments_body import BatchAddAttachmentsBody
from .batch_attachment_result import BatchAttachmentResult
from .batch_attachment_result_successful_ids import BatchAttachmentResultSuccessfulIds
from .batch_upload_record_item_dto import BatchUploadRecordItemDto
from .batch_upload_record_item_dto_tags import BatchUploadRecordItemDtoTags
from .batch_upload_records_body import BatchUploadRecordsBody
from .batch_upload_result import BatchUploadResult
from .batch_upload_result_successful_ids import BatchUploadResultSuccessfulIds
from .batch_upsert_result import BatchUpsertResult
from .batch_upsert_result_successful_ids import BatchUpsertResultSuccessfulIds
from .create_draft_record_command import CreateDraftRecordCommand
from .create_draft_record_command_tags import CreateDraftRecordCommandTags
from .create_group_command import CreateGroupCommand
from .create_mini_cosmos_command import CreateMiniCosmosCommand
from .create_record_command import CreateRecordCommand
from .create_record_command_tags import CreateRecordCommandTags
from .cursor_paginated_list_of_mini_version_dto import CursorPaginatedListOfMiniVersionDto
from .cursor_paginated_list_of_record_dto import CursorPaginatedListOfRecordDto
from .cursor_paginated_list_of_record_version_dto import CursorPaginatedListOfRecordVersionDto
from .failed_attachment_item import FailedAttachmentItem
from .failed_upload_item import FailedUploadItem
from .failed_upsert_item import FailedUpsertItem
from .group_dto import GroupDto
from .group_summary_dto import GroupSummaryDto
from .http_validation_problem_details import HttpValidationProblemDetails
from .http_validation_problem_details_errors import HttpValidationProblemDetailsErrors
from .mini_cosmos_dto import MiniCosmosDto
from .mini_group_summary_dto import MiniGroupSummaryDto
from .mini_version_dto import MiniVersionDto
from .paginated_list_of_record_dto import PaginatedListOfRecordDto
from .patch_mini_cosmos_command import PatchMiniCosmosCommand
from .record_attachment_dto import RecordAttachmentDto
from .record_attachment_dto_metadata_type_0 import RecordAttachmentDtoMetadataType0
from .record_authorization_dto import RecordAuthorizationDto
from .record_dto import RecordDto
from .record_dto_tags import RecordDtoTags
from .record_relation_dto import RecordRelationDto
from .record_state import RecordState
from .record_version_dto import RecordVersionDto
from .record_version_dto_tags import RecordVersionDtoTags
from .update_attachments_body import UpdateAttachmentsBody
from .update_draft_record_command import UpdateDraftRecordCommand
from .update_draft_record_command_tags import UpdateDraftRecordCommandTags
from .update_group_command import UpdateGroupCommand
from .update_mini_cosmos_command import UpdateMiniCosmosCommand
from .update_record_command import UpdateRecordCommand
from .update_record_command_tags import UpdateRecordCommandTags
from .upload_mini_profile_picture_body import UploadMiniProfilePictureBody
from .upsert_external_mini_cosmos_command import UpsertExternalMiniCosmosCommand
from .upsert_record_dto import UpsertRecordDto
from .upsert_record_dto_tags import UpsertRecordDtoTags
from .upsert_records_by_external_uri_command import UpsertRecordsByExternalUriCommand
from .user_dto import UserDto
from .user_to_mini_dto import UserToMiniDto

__all__ = (
    "AddAttachmentsBody",
    "AgentType",
    "BatchAddAttachmentsBody",
    "BatchAttachmentResult",
    "BatchAttachmentResultSuccessfulIds",
    "BatchUploadRecordItemDto",
    "BatchUploadRecordItemDtoTags",
    "BatchUploadRecordsBody",
    "BatchUploadResult",
    "BatchUploadResultSuccessfulIds",
    "BatchUpsertResult",
    "BatchUpsertResultSuccessfulIds",
    "CreateDraftRecordCommand",
    "CreateDraftRecordCommandTags",
    "CreateGroupCommand",
    "CreateMiniCosmosCommand",
    "CreateRecordCommand",
    "CreateRecordCommandTags",
    "CursorPaginatedListOfMiniVersionDto",
    "CursorPaginatedListOfRecordDto",
    "CursorPaginatedListOfRecordVersionDto",
    "FailedAttachmentItem",
    "FailedUploadItem",
    "FailedUpsertItem",
    "GroupDto",
    "GroupSummaryDto",
    "HttpValidationProblemDetails",
    "HttpValidationProblemDetailsErrors",
    "MiniCosmosDto",
    "MiniGroupSummaryDto",
    "MiniVersionDto",
    "PaginatedListOfRecordDto",
    "PatchMiniCosmosCommand",
    "RecordAttachmentDto",
    "RecordAttachmentDtoMetadataType0",
    "RecordAuthorizationDto",
    "RecordDto",
    "RecordDtoTags",
    "RecordRelationDto",
    "RecordState",
    "RecordVersionDto",
    "RecordVersionDtoTags",
    "UpdateAttachmentsBody",
    "UpdateDraftRecordCommand",
    "UpdateDraftRecordCommandTags",
    "UpdateGroupCommand",
    "UpdateMiniCosmosCommand",
    "UpdateRecordCommand",
    "UpdateRecordCommandTags",
    "UploadMiniProfilePictureBody",
    "UpsertExternalMiniCosmosCommand",
    "UpsertRecordDto",
    "UpsertRecordDtoTags",
    "UpsertRecordsByExternalUriCommand",
    "UserDto",
    "UserToMiniDto",
)
