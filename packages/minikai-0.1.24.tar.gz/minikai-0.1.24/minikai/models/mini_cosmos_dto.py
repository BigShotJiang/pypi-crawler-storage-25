from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.agent_type import AgentType
from ..models.agent_type import check_agent_type
from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime






T = TypeVar("T", bound="MiniCosmosDto")



@_attrs_define
class MiniCosmosDto:
    """ 
        Attributes:
            id (str):
            name (str):
            created_by (str):
            agent_type (AgentType | Unset):
            profile_picture_url (str | Unset):
            profile (Any | Unset):
            external_uri (str | Unset):
            labels (list[str] | Unset):
            created_at (datetime.datetime | Unset):
            updated_at (datetime.datetime | Unset):
            updated_by (None | str | Unset):
            e_tag (None | str | Unset):
     """

    id: str
    name: str
    created_by: str
    agent_type: AgentType | Unset = UNSET
    profile_picture_url: str | Unset = UNSET
    profile: Any | Unset = UNSET
    external_uri: str | Unset = UNSET
    labels: list[str] | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    updated_at: datetime.datetime | Unset = UNSET
    updated_by: None | str | Unset = UNSET
    e_tag: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = self.id

        name = self.name

        created_by = self.created_by

        agent_type: str | Unset = UNSET
        if not isinstance(self.agent_type, Unset):
            agent_type = self.agent_type


        profile_picture_url = self.profile_picture_url

        profile = self.profile

        external_uri = self.external_uri

        labels: list[str] | Unset = UNSET
        if not isinstance(self.labels, Unset):
            labels = self.labels



        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        updated_at: str | Unset = UNSET
        if not isinstance(self.updated_at, Unset):
            updated_at = self.updated_at.isoformat()

        updated_by: None | str | Unset
        if isinstance(self.updated_by, Unset):
            updated_by = UNSET
        else:
            updated_by = self.updated_by

        e_tag: None | str | Unset
        if isinstance(self.e_tag, Unset):
            e_tag = UNSET
        else:
            e_tag = self.e_tag


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "name": name,
            "createdBy": created_by,
        })
        if agent_type is not UNSET:
            field_dict["agentType"] = agent_type
        if profile_picture_url is not UNSET:
            field_dict["profilePictureUrl"] = profile_picture_url
        if profile is not UNSET:
            field_dict["profile"] = profile
        if external_uri is not UNSET:
            field_dict["externalUri"] = external_uri
        if labels is not UNSET:
            field_dict["labels"] = labels
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if updated_at is not UNSET:
            field_dict["updatedAt"] = updated_at
        if updated_by is not UNSET:
            field_dict["updatedBy"] = updated_by
        if e_tag is not UNSET:
            field_dict["eTag"] = e_tag

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        created_by = d.pop("createdBy")

        _agent_type = d.pop("agentType", UNSET)
        agent_type: AgentType | Unset
        if isinstance(_agent_type,  Unset):
            agent_type = UNSET
        else:
            agent_type = check_agent_type(_agent_type)




        profile_picture_url = d.pop("profilePictureUrl", UNSET)

        profile = d.pop("profile", UNSET)

        external_uri = d.pop("externalUri", UNSET)

        labels = cast(list[str], d.pop("labels", UNSET))


        _created_at = d.pop("createdAt", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at,  Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)




        _updated_at = d.pop("updatedAt", UNSET)
        updated_at: datetime.datetime | Unset
        if isinstance(_updated_at,  Unset):
            updated_at = UNSET
        else:
            updated_at = isoparse(_updated_at)




        def _parse_updated_by(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        updated_by = _parse_updated_by(d.pop("updatedBy", UNSET))


        def _parse_e_tag(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        e_tag = _parse_e_tag(d.pop("eTag", UNSET))


        mini_cosmos_dto = cls(
            id=id,
            name=name,
            created_by=created_by,
            agent_type=agent_type,
            profile_picture_url=profile_picture_url,
            profile=profile,
            external_uri=external_uri,
            labels=labels,
            created_at=created_at,
            updated_at=updated_at,
            updated_by=updated_by,
            e_tag=e_tag,
        )


        mini_cosmos_dto.additional_properties = d
        return mini_cosmos_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
