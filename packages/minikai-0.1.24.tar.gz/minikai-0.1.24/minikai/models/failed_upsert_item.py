from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.upsert_record_dto import UpsertRecordDto





T = TypeVar("T", bound="FailedUpsertItem")



@_attrs_define
class FailedUpsertItem:
    """ 
        Attributes:
            index (Any):
            item (UpsertRecordDto):
            error (str):
     """

    index: Any
    item: UpsertRecordDto
    error: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.upsert_record_dto import UpsertRecordDto
        index = self.index

        item = self.item.to_dict()

        error = self.error


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "index": index,
            "item": item,
            "error": error,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.upsert_record_dto import UpsertRecordDto
        d = dict(src_dict)
        index = d.pop("index")

        item = UpsertRecordDto.from_dict(d.pop("item"))




        error = d.pop("error")

        failed_upsert_item = cls(
            index=index,
            item=item,
            error=error,
        )


        failed_upsert_item.additional_properties = d
        return failed_upsert_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
