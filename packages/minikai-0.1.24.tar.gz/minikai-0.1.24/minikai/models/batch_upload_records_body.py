from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field
import json
from .. import types

from ..types import UNSET, Unset

from ..types import File, FileTypes
from io import BytesIO
from typing import cast






T = TypeVar("T", bound="BatchUploadRecordsBody")



@_attrs_define
class BatchUploadRecordsBody:
    """ 
        Attributes:
            files (list[File]):
            items (str):
     """

    files: list[File]
    items: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        files = []
        for componentsschemas_i_form_file_collection_item_data in self.files:
            componentsschemas_i_form_file_collection_item = componentsschemas_i_form_file_collection_item_data.to_tuple()

            files.append(componentsschemas_i_form_file_collection_item)



        items = self.items


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "files": files,
            "items": items,
        })

        return field_dict


    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        for componentsschemas_i_form_file_collection_item_element in self.files:
            files.append(("files", componentsschemas_i_form_file_collection_item_element.to_tuple()))




        files.append(("items", (None, str(self.items).encode(), "text/plain")))




        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))



        return files


    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        files = []
        _files = d.pop("files")
        for componentsschemas_i_form_file_collection_item_data in (_files):
            componentsschemas_i_form_file_collection_item = File(
                 payload = BytesIO(componentsschemas_i_form_file_collection_item_data)
            )



            files.append(componentsschemas_i_form_file_collection_item)


        items = d.pop("items")

        batch_upload_records_body = cls(
            files=files,
            items=items,
        )


        batch_upload_records_body.additional_properties = d
        return batch_upload_records_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
