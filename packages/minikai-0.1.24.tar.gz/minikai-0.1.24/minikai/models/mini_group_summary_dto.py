from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from uuid import UUID






T = TypeVar("T", bound="MiniGroupSummaryDto")



@_attrs_define
class MiniGroupSummaryDto:
    """ 
        Attributes:
            name (str):
            id (UUID | Unset):
            mini_count (Any | Unset):
            user_count (Any | Unset):
     """

    name: str
    id: UUID | Unset = UNSET
    mini_count: Any | Unset = UNSET
    user_count: Any | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        name = self.name

        id: str | Unset = UNSET
        if not isinstance(self.id, Unset):
            id = str(self.id)

        mini_count = self.mini_count

        user_count = self.user_count


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "name": name,
        })
        if id is not UNSET:
            field_dict["id"] = id
        if mini_count is not UNSET:
            field_dict["miniCount"] = mini_count
        if user_count is not UNSET:
            field_dict["userCount"] = user_count

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        _id = d.pop("id", UNSET)
        id: UUID | Unset
        if isinstance(_id,  Unset):
            id = UNSET
        else:
            id = UUID(_id)




        mini_count = d.pop("miniCount", UNSET)

        user_count = d.pop("userCount", UNSET)

        mini_group_summary_dto = cls(
            name=name,
            id=id,
            mini_count=mini_count,
            user_count=user_count,
        )


        mini_group_summary_dto.additional_properties = d
        return mini_group_summary_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
