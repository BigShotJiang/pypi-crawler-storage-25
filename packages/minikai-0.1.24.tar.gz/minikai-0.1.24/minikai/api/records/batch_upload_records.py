from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.batch_upload_records_body import BatchUploadRecordsBody
from ...models.batch_upload_result import BatchUploadResult
from ...models.http_validation_problem_details import HttpValidationProblemDetails
from typing import cast



def _get_kwargs(
    *,
    body: BatchUploadRecordsBody,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/Records/batch/upload",
    }

    _kwargs["files"] = body.to_multipart()



    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> BatchUploadResult | HttpValidationProblemDetails | None:
    if response.status_code == 202:
        response_202 = BatchUploadResult.from_dict(response.json())



        return response_202

    if response.status_code == 400:
        response_400 = HttpValidationProblemDetails.from_dict(response.json())



        return response_400

    if response.status_code == 422:
        response_422 = BatchUploadResult.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[BatchUploadResult | HttpValidationProblemDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: BatchUploadRecordsBody,

) -> Response[BatchUploadResult | HttpValidationProblemDetails]:
    """ 
    Args:
        body (BatchUploadRecordsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BatchUploadResult | HttpValidationProblemDetails]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: BatchUploadRecordsBody,

) -> BatchUploadResult | HttpValidationProblemDetails | None:
    """ 
    Args:
        body (BatchUploadRecordsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BatchUploadResult | HttpValidationProblemDetails
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: BatchUploadRecordsBody,

) -> Response[BatchUploadResult | HttpValidationProblemDetails]:
    """ 
    Args:
        body (BatchUploadRecordsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BatchUploadResult | HttpValidationProblemDetails]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: BatchUploadRecordsBody,

) -> BatchUploadResult | HttpValidationProblemDetails | None:
    """ 
    Args:
        body (BatchUploadRecordsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BatchUploadResult | HttpValidationProblemDetails
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
