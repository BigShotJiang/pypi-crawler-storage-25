from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.http_validation_problem_details import HttpValidationProblemDetails
from ...models.update_attachments_body import UpdateAttachmentsBody
from typing import cast
from uuid import UUID



def _get_kwargs(
    record_id: UUID,
    *,
    body: UpdateAttachmentsBody,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/api/Records/{record_id}/attachments".format(record_id=quote(str(record_id), safe=""),),
    }

    _kwargs["files"] = body.to_multipart()



    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Any | HttpValidationProblemDetails | list[UUID] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in (_response_200):
            response_200_item = UUID(response_200_item_data)



            response_200.append(response_200_item)

        return response_200

    if response.status_code == 400:
        response_400 = HttpValidationProblemDetails.from_dict(response.json())



        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Any | HttpValidationProblemDetails | list[UUID]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    record_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateAttachmentsBody,

) -> Response[Any | HttpValidationProblemDetails | list[UUID]]:
    """ 
    Args:
        record_id (UUID):
        body (UpdateAttachmentsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HttpValidationProblemDetails | list[UUID]]
     """


    kwargs = _get_kwargs(
        record_id=record_id,
body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    record_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateAttachmentsBody,

) -> Any | HttpValidationProblemDetails | list[UUID] | None:
    """ 
    Args:
        record_id (UUID):
        body (UpdateAttachmentsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HttpValidationProblemDetails | list[UUID]
     """


    return sync_detailed(
        record_id=record_id,
client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    record_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateAttachmentsBody,

) -> Response[Any | HttpValidationProblemDetails | list[UUID]]:
    """ 
    Args:
        record_id (UUID):
        body (UpdateAttachmentsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HttpValidationProblemDetails | list[UUID]]
     """


    kwargs = _get_kwargs(
        record_id=record_id,
body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    record_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateAttachmentsBody,

) -> Any | HttpValidationProblemDetails | list[UUID] | None:
    """ 
    Args:
        record_id (UUID):
        body (UpdateAttachmentsBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HttpValidationProblemDetails | list[UUID]
     """


    return (await asyncio_detailed(
        record_id=record_id,
client=client,
body=body,

    )).parsed
