from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.http_validation_problem_details import HttpValidationProblemDetails
from typing import cast
from uuid import UUID



def _get_kwargs(
    record_id: UUID,
    *,
    mini_id: str,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["miniId"] = mini_id


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/Records/drafts/{record_id}/submit".format(record_id=quote(str(record_id), safe=""),),
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Any | HttpValidationProblemDetails | UUID | None:
    if response.status_code == 200:
        response_200 = UUID(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = HttpValidationProblemDetails.from_dict(response.json())



        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Any | HttpValidationProblemDetails | UUID]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    record_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    mini_id: str,

) -> Response[Any | HttpValidationProblemDetails | UUID]:
    """ 
    Args:
        record_id (UUID):
        mini_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HttpValidationProblemDetails | UUID]
     """


    kwargs = _get_kwargs(
        record_id=record_id,
mini_id=mini_id,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    record_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    mini_id: str,

) -> Any | HttpValidationProblemDetails | UUID | None:
    """ 
    Args:
        record_id (UUID):
        mini_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HttpValidationProblemDetails | UUID
     """


    return sync_detailed(
        record_id=record_id,
client=client,
mini_id=mini_id,

    ).parsed

async def asyncio_detailed(
    record_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    mini_id: str,

) -> Response[Any | HttpValidationProblemDetails | UUID]:
    """ 
    Args:
        record_id (UUID):
        mini_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HttpValidationProblemDetails | UUID]
     """


    kwargs = _get_kwargs(
        record_id=record_id,
mini_id=mini_id,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    record_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    mini_id: str,

) -> Any | HttpValidationProblemDetails | UUID | None:
    """ 
    Args:
        record_id (UUID):
        mini_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HttpValidationProblemDetails | UUID
     """


    return (await asyncio_detailed(
        record_id=record_id,
client=client,
mini_id=mini_id,

    )).parsed
