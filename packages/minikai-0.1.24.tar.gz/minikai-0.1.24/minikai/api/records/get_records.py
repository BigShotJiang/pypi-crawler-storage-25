from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.cursor_paginated_list_of_record_dto import CursorPaginatedListOfRecordDto
from ...models.record_state import check_record_state
from ...models.record_state import RecordState
from ...types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime



def _get_kwargs(
    *,
    mini_id: str,
    record_ids: list[UUID] | Unset = UNSET,
    external_uris: list[str] | Unset = UNSET,
    session_id: UUID | Unset = UNSET,
    record_id: UUID | Unset = UNSET,
    before_cursor: UUID | Unset = UNSET,
    after_cursor: UUID | Unset = UNSET,
    limit_before: Any | Unset = UNSET,
    limit_after: Any | Unset = UNSET,
    labels: list[str] | Unset = UNSET,
    states: list[RecordState] | Unset = UNSET,
    start_date: datetime.datetime | Unset = UNSET,
    end_date: datetime.datetime | Unset = UNSET,
    created_by: list[str] | Unset = UNSET,
    updated_by: list[str] | Unset = UNSET,
    sort_descending: bool | Unset = True,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["miniId"] = mini_id

    json_record_ids: list[str] | Unset = UNSET
    if not isinstance(record_ids, Unset):
        json_record_ids = []
        for record_ids_item_data in record_ids:
            record_ids_item = str(record_ids_item_data)
            json_record_ids.append(record_ids_item)


    params["recordIds"] = json_record_ids

    json_external_uris: list[str] | Unset = UNSET
    if not isinstance(external_uris, Unset):
        json_external_uris = external_uris


    params["externalUris"] = json_external_uris

    json_session_id: str | Unset = UNSET
    if not isinstance(session_id, Unset):
        json_session_id = str(session_id)
    params["sessionId"] = json_session_id

    json_record_id: str | Unset = UNSET
    if not isinstance(record_id, Unset):
        json_record_id = str(record_id)
    params["recordId"] = json_record_id

    json_before_cursor: str | Unset = UNSET
    if not isinstance(before_cursor, Unset):
        json_before_cursor = str(before_cursor)
    params["beforeCursor"] = json_before_cursor

    json_after_cursor: str | Unset = UNSET
    if not isinstance(after_cursor, Unset):
        json_after_cursor = str(after_cursor)
    params["afterCursor"] = json_after_cursor

    params["limitBefore"] = limit_before

    params["limitAfter"] = limit_after

    json_labels: list[str] | Unset = UNSET
    if not isinstance(labels, Unset):
        json_labels = labels


    params["labels"] = json_labels

    json_states: list[str] | Unset = UNSET
    if not isinstance(states, Unset):
        json_states = []
        for states_item_data in states:
            states_item: str = states_item_data
            json_states.append(states_item)


    params["states"] = json_states

    json_start_date: str | Unset = UNSET
    if not isinstance(start_date, Unset):
        json_start_date = start_date.isoformat()
    params["startDate"] = json_start_date

    json_end_date: str | Unset = UNSET
    if not isinstance(end_date, Unset):
        json_end_date = end_date.isoformat()
    params["endDate"] = json_end_date

    json_created_by: list[str] | Unset = UNSET
    if not isinstance(created_by, Unset):
        json_created_by = created_by


    params["createdBy"] = json_created_by

    json_updated_by: list[str] | Unset = UNSET
    if not isinstance(updated_by, Unset):
        json_updated_by = updated_by


    params["updatedBy"] = json_updated_by

    params["sortDescending"] = sort_descending


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/Records",
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> CursorPaginatedListOfRecordDto | None:
    if response.status_code == 200:
        response_200 = CursorPaginatedListOfRecordDto.from_dict(response.json())



        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[CursorPaginatedListOfRecordDto]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    mini_id: str,
    record_ids: list[UUID] | Unset = UNSET,
    external_uris: list[str] | Unset = UNSET,
    session_id: UUID | Unset = UNSET,
    record_id: UUID | Unset = UNSET,
    before_cursor: UUID | Unset = UNSET,
    after_cursor: UUID | Unset = UNSET,
    limit_before: Any | Unset = UNSET,
    limit_after: Any | Unset = UNSET,
    labels: list[str] | Unset = UNSET,
    states: list[RecordState] | Unset = UNSET,
    start_date: datetime.datetime | Unset = UNSET,
    end_date: datetime.datetime | Unset = UNSET,
    created_by: list[str] | Unset = UNSET,
    updated_by: list[str] | Unset = UNSET,
    sort_descending: bool | Unset = True,

) -> Response[CursorPaginatedListOfRecordDto]:
    """ 
    Args:
        mini_id (str):
        record_ids (list[UUID] | Unset):
        external_uris (list[str] | Unset):
        session_id (UUID | Unset):
        record_id (UUID | Unset):
        before_cursor (UUID | Unset):
        after_cursor (UUID | Unset):
        limit_before (Any | Unset):
        limit_after (Any | Unset):
        labels (list[str] | Unset):
        states (list[RecordState] | Unset):
        start_date (datetime.datetime | Unset):
        end_date (datetime.datetime | Unset):
        created_by (list[str] | Unset):
        updated_by (list[str] | Unset):
        sort_descending (bool | Unset):  Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CursorPaginatedListOfRecordDto]
     """


    kwargs = _get_kwargs(
        mini_id=mini_id,
record_ids=record_ids,
external_uris=external_uris,
session_id=session_id,
record_id=record_id,
before_cursor=before_cursor,
after_cursor=after_cursor,
limit_before=limit_before,
limit_after=limit_after,
labels=labels,
states=states,
start_date=start_date,
end_date=end_date,
created_by=created_by,
updated_by=updated_by,
sort_descending=sort_descending,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    mini_id: str,
    record_ids: list[UUID] | Unset = UNSET,
    external_uris: list[str] | Unset = UNSET,
    session_id: UUID | Unset = UNSET,
    record_id: UUID | Unset = UNSET,
    before_cursor: UUID | Unset = UNSET,
    after_cursor: UUID | Unset = UNSET,
    limit_before: Any | Unset = UNSET,
    limit_after: Any | Unset = UNSET,
    labels: list[str] | Unset = UNSET,
    states: list[RecordState] | Unset = UNSET,
    start_date: datetime.datetime | Unset = UNSET,
    end_date: datetime.datetime | Unset = UNSET,
    created_by: list[str] | Unset = UNSET,
    updated_by: list[str] | Unset = UNSET,
    sort_descending: bool | Unset = True,

) -> CursorPaginatedListOfRecordDto | None:
    """ 
    Args:
        mini_id (str):
        record_ids (list[UUID] | Unset):
        external_uris (list[str] | Unset):
        session_id (UUID | Unset):
        record_id (UUID | Unset):
        before_cursor (UUID | Unset):
        after_cursor (UUID | Unset):
        limit_before (Any | Unset):
        limit_after (Any | Unset):
        labels (list[str] | Unset):
        states (list[RecordState] | Unset):
        start_date (datetime.datetime | Unset):
        end_date (datetime.datetime | Unset):
        created_by (list[str] | Unset):
        updated_by (list[str] | Unset):
        sort_descending (bool | Unset):  Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CursorPaginatedListOfRecordDto
     """


    return sync_detailed(
        client=client,
mini_id=mini_id,
record_ids=record_ids,
external_uris=external_uris,
session_id=session_id,
record_id=record_id,
before_cursor=before_cursor,
after_cursor=after_cursor,
limit_before=limit_before,
limit_after=limit_after,
labels=labels,
states=states,
start_date=start_date,
end_date=end_date,
created_by=created_by,
updated_by=updated_by,
sort_descending=sort_descending,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    mini_id: str,
    record_ids: list[UUID] | Unset = UNSET,
    external_uris: list[str] | Unset = UNSET,
    session_id: UUID | Unset = UNSET,
    record_id: UUID | Unset = UNSET,
    before_cursor: UUID | Unset = UNSET,
    after_cursor: UUID | Unset = UNSET,
    limit_before: Any | Unset = UNSET,
    limit_after: Any | Unset = UNSET,
    labels: list[str] | Unset = UNSET,
    states: list[RecordState] | Unset = UNSET,
    start_date: datetime.datetime | Unset = UNSET,
    end_date: datetime.datetime | Unset = UNSET,
    created_by: list[str] | Unset = UNSET,
    updated_by: list[str] | Unset = UNSET,
    sort_descending: bool | Unset = True,

) -> Response[CursorPaginatedListOfRecordDto]:
    """ 
    Args:
        mini_id (str):
        record_ids (list[UUID] | Unset):
        external_uris (list[str] | Unset):
        session_id (UUID | Unset):
        record_id (UUID | Unset):
        before_cursor (UUID | Unset):
        after_cursor (UUID | Unset):
        limit_before (Any | Unset):
        limit_after (Any | Unset):
        labels (list[str] | Unset):
        states (list[RecordState] | Unset):
        start_date (datetime.datetime | Unset):
        end_date (datetime.datetime | Unset):
        created_by (list[str] | Unset):
        updated_by (list[str] | Unset):
        sort_descending (bool | Unset):  Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CursorPaginatedListOfRecordDto]
     """


    kwargs = _get_kwargs(
        mini_id=mini_id,
record_ids=record_ids,
external_uris=external_uris,
session_id=session_id,
record_id=record_id,
before_cursor=before_cursor,
after_cursor=after_cursor,
limit_before=limit_before,
limit_after=limit_after,
labels=labels,
states=states,
start_date=start_date,
end_date=end_date,
created_by=created_by,
updated_by=updated_by,
sort_descending=sort_descending,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    mini_id: str,
    record_ids: list[UUID] | Unset = UNSET,
    external_uris: list[str] | Unset = UNSET,
    session_id: UUID | Unset = UNSET,
    record_id: UUID | Unset = UNSET,
    before_cursor: UUID | Unset = UNSET,
    after_cursor: UUID | Unset = UNSET,
    limit_before: Any | Unset = UNSET,
    limit_after: Any | Unset = UNSET,
    labels: list[str] | Unset = UNSET,
    states: list[RecordState] | Unset = UNSET,
    start_date: datetime.datetime | Unset = UNSET,
    end_date: datetime.datetime | Unset = UNSET,
    created_by: list[str] | Unset = UNSET,
    updated_by: list[str] | Unset = UNSET,
    sort_descending: bool | Unset = True,

) -> CursorPaginatedListOfRecordDto | None:
    """ 
    Args:
        mini_id (str):
        record_ids (list[UUID] | Unset):
        external_uris (list[str] | Unset):
        session_id (UUID | Unset):
        record_id (UUID | Unset):
        before_cursor (UUID | Unset):
        after_cursor (UUID | Unset):
        limit_before (Any | Unset):
        limit_after (Any | Unset):
        labels (list[str] | Unset):
        states (list[RecordState] | Unset):
        start_date (datetime.datetime | Unset):
        end_date (datetime.datetime | Unset):
        created_by (list[str] | Unset):
        updated_by (list[str] | Unset):
        sort_descending (bool | Unset):  Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CursorPaginatedListOfRecordDto
     """


    return (await asyncio_detailed(
        client=client,
mini_id=mini_id,
record_ids=record_ids,
external_uris=external_uris,
session_id=session_id,
record_id=record_id,
before_cursor=before_cursor,
after_cursor=after_cursor,
limit_before=limit_before,
limit_after=limit_after,
labels=labels,
states=states,
start_date=start_date,
end_date=end_date,
created_by=created_by,
updated_by=updated_by,
sort_descending=sort_descending,

    )).parsed
