from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.cursor_paginated_list_of_mini_version_dto import CursorPaginatedListOfMiniVersionDto
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    id: str,
    *,
    limit: Any | Unset = 20,
    after_cursor: str | Unset = UNSET,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["limit"] = limit

    params["afterCursor"] = after_cursor


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/MinisCosmos/{id}/versions".format(id=quote(str(id), safe=""),),
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> CursorPaginatedListOfMiniVersionDto | None:
    if response.status_code == 200:
        response_200 = CursorPaginatedListOfMiniVersionDto.from_dict(response.json())



        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[CursorPaginatedListOfMiniVersionDto]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: str,
    *,
    client: AuthenticatedClient | Client,
    limit: Any | Unset = 20,
    after_cursor: str | Unset = UNSET,

) -> Response[CursorPaginatedListOfMiniVersionDto]:
    """ 
    Args:
        id (str):
        limit (Any | Unset):  Default: 20.
        after_cursor (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CursorPaginatedListOfMiniVersionDto]
     """


    kwargs = _get_kwargs(
        id=id,
limit=limit,
after_cursor=after_cursor,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    id: str,
    *,
    client: AuthenticatedClient | Client,
    limit: Any | Unset = 20,
    after_cursor: str | Unset = UNSET,

) -> CursorPaginatedListOfMiniVersionDto | None:
    """ 
    Args:
        id (str):
        limit (Any | Unset):  Default: 20.
        after_cursor (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CursorPaginatedListOfMiniVersionDto
     """


    return sync_detailed(
        id=id,
client=client,
limit=limit,
after_cursor=after_cursor,

    ).parsed

async def asyncio_detailed(
    id: str,
    *,
    client: AuthenticatedClient | Client,
    limit: Any | Unset = 20,
    after_cursor: str | Unset = UNSET,

) -> Response[CursorPaginatedListOfMiniVersionDto]:
    """ 
    Args:
        id (str):
        limit (Any | Unset):  Default: 20.
        after_cursor (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CursorPaginatedListOfMiniVersionDto]
     """


    kwargs = _get_kwargs(
        id=id,
limit=limit,
after_cursor=after_cursor,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    id: str,
    *,
    client: AuthenticatedClient | Client,
    limit: Any | Unset = 20,
    after_cursor: str | Unset = UNSET,

) -> CursorPaginatedListOfMiniVersionDto | None:
    """ 
    Args:
        id (str):
        limit (Any | Unset):  Default: 20.
        after_cursor (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CursorPaginatedListOfMiniVersionDto
     """


    return (await asyncio_detailed(
        id=id,
client=client,
limit=limit,
after_cursor=after_cursor,

    )).parsed
