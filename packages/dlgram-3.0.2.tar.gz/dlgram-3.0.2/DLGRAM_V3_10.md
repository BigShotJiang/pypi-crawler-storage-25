<!-- Copyright (C) 2026-present DLGram <https://t.me/dlgramUpdates> | SPDX-License-Identifier: LGPL-3.0-or-later -->

# DLGram v3.10

## Install

From GitHub:

```bash
pip uninstall -y pyrogram pyrofork kurigram dlgram
pip install --no-cache-dir --force-reinstall "git+https://github.com/growxupdate/dlgram.git"
```

From a GitHub Actions artifact:

1. Open the latest **DLGram Auto Build** workflow run.
2. Download the `dlgram-dist` artifact.
3. Install the wheel:

```bash
pip install --force-reinstall dlgram-*.whl
```

## Auto build and version bump

Every push to `main` or `master` runs `.github/workflows/dlgram-build.yml`.

The workflow does three things:

1. bumps `pyrogram/__init__.py` patch version automatically,
2. commits the new version back to the repo with `[skip version]`,
3. builds and uploads the wheel/sdist as the `dlgram-dist` artifact.

The `[skip version]` marker prevents an infinite version-bump loop.

## Button color API

Use `color=` or `colour=` directly in the button. `style=` still works for old code.

```python
from pyrogram import types

button = types.InlineKeyboardButton(
    "Play",
    callback_data="play",
    color="green",
    icon_emoji_id="6267032805910254913"
)
```

Supported colors:

- `default`
- `blue`
- `red`
- `green`

Unsupported values like `orange` show a warning and fall back to `default`.
