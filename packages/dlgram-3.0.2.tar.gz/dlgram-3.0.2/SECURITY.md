# DLGram Security Policy

Community/update channel: https://t.me/dlgramUpdates

## Secrets

Never commit real values for:

- `API_ID`
- `API_HASH`
- `BOT_TOKEN`
- `SESSION_STRING`
- database URLs
- MongoDB URLs
- owner/admin private IDs if you do not want them public

Use deployment secrets, environment variables, or private config files ignored by Git.

## No backdoor policy

DLGram should not include owner-only commands that expose environment variables, sessions, tokens, shell access, database URLs, or filesystem secrets.

Avoid adding features that do any of these unless the repository owner explicitly understands the risk:

- `eval` / `exec` command handlers
- shell command handlers
- environment dump commands
- token/session dump commands
- remote upload of `.env`, session, or config files
- hidden HTTP calls to external URLs

## Local audit commands

```bash
rg -n "(BOT_TOKEN|API_HASH|SESSION_STRING|MONGO|DATABASE|eval\(|exec\(|subprocess|os\.system|popen|requests\.|aiohttp|httpx|urlopen)" .
python3 -m compileall -q pyrogram
```

## Reporting

Open an issue on the repository or contact the DLGram update channel if you find a security issue. Do not post real tokens or session strings publicly.
