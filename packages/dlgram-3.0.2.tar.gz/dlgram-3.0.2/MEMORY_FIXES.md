<!-- Copyright (C) 2026-present DLGram <https://t.me/dlgramUpdates> | SPDX-License-Identifier: LGPL-3.0-or-later -->

# dlgram memory fixes

This build changes only dlgram files. Kurigram was used only as a behavioral reference and no kurigram source was copied.

## Changes

- Reduced default full-message cache from 10000 to 1000.
- Added `max_update_queue_size` client option and `PYROGRAM_MAX_UPDATE_QUEUE_SIZE` env override.
- Bounded update queue memory; when full, the oldest queued update is dropped before adding the newest update.
- `no_updates=True` now exits `handle_updates()` immediately and media/CDN sessions no longer forward incoming update packets to the dispatcher.
- Packet handling tasks are tracked and capped to avoid unlimited task growth under traffic bursts.
- Cache capacity is clamped safely, and `max_message_cache_size=0` now truly disables message caching.

## Recommended bot setting for low RAM

```python
app = Client(
    "bot",
    api_id=API_ID,
    api_hash=API_HASH,
    bot_token=BOT_TOKEN,
    max_message_cache_size=300,
    max_business_user_connection_cache_size=100,
    max_update_queue_size=1000,
)
```

For download-only clients/sessions:

```python
app = Client(
    "download_session",
    api_id=API_ID,
    api_hash=API_HASH,
    session_string=SESSION_STRING,
    no_updates=True,
    max_message_cache_size=0,
    max_update_queue_size=0,
)
```
