__version__ = '0.34.0'         
__author__ = 'pengyeqin'

def hello():
    print("Hello from ub-clean-test!")