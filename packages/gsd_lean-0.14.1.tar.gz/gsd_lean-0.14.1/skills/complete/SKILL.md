---
description: This skill should be used when the user asks to "complete the workflow", "finish the cycle", "wrap up", or runs /gsd-lean:complete. Transitions to complete phase and generates a summary of tasks, decisions, and files changed.
allowed-tools: Read, Write, Edit, Bash(uvx gsd-lean:*), Bash(git:*)
---

## Current State

**Phase:** !`uvx gsd-lean status --path . 2>/dev/null | grep -A1 "Current Phase" | tail -1 | tr -d '\140'`
**Plan:** !`uvx gsd-lean plan-status --path . 2>/dev/null || echo "No plan"`

## Instructions

Run the **complete phase** of GSD-Lean's development workflow.

### Step 1: Transition Phase

Run:
```
uvx gsd-lean transition complete --path .
```

If this fails because tasks are still pending, tell the user which tasks remain.

### Step 2: Generate Summary

Read `.planning/cycle/PLAN.md`, `.planning/cycle/DECISIONS.md`, and `.planning/CONTEXT.md`. Output:

```
## Workflow Complete

### Tasks Completed
- T-001: <title>
- T-002: <title>
...

### Key Decisions Made
- <decision 1>
- <decision 2>

### Files Changed
- `path/to/file.py` — <what changed>
```

### Step 3: Suggest Next Steps

- "Run `/gsd-lean:commit` to commit any remaining changes"
- "Run `uvx gsd-lean new-cycle` or `/gsd-lean:discuss` to start a new development cycle"
