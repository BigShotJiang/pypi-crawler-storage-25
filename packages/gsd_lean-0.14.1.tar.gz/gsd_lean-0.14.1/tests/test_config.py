"""Tests for the config module."""

from gsd_lean.state.config import (
    KNOWN_SUBAGENTS,
    SubagentConfig,
    load_config,
    resolve_subagent_config,
    validate_config,
)
from gsd_lean.state.planning import PLANNING_DIR


class TestLoadConfig:
    """Tests for load_config function."""

    def test_loads_valid_yaml(self, tmp_path):
        """Test that load_config parses a valid YAML file."""
        config_dir = tmp_path / PLANNING_DIR
        config_dir.mkdir()
        (config_dir / 'config.yaml').write_text('defaults:\n  model: sonnet\n')

        data = load_config(tmp_path)
        assert data == {'defaults': {'model': 'sonnet'}}

    def test_returns_empty_dict_when_missing(self, tmp_path):
        """Test that load_config returns {} when config file is missing."""
        data = load_config(tmp_path)
        assert data == {}

    def test_returns_empty_dict_on_invalid_yaml(self, tmp_path):
        """Test that load_config returns {} for malformed YAML."""
        config_dir = tmp_path / PLANNING_DIR
        config_dir.mkdir()
        (config_dir / 'config.yaml').write_text('{{invalid yaml: [}')

        data = load_config(tmp_path)
        assert data == {}

    def test_returns_empty_dict_on_empty_file(self, tmp_path):
        """Test that load_config returns {} for an empty file."""
        config_dir = tmp_path / PLANNING_DIR
        config_dir.mkdir()
        (config_dir / 'config.yaml').write_text('')

        data = load_config(tmp_path)
        assert data == {}


class TestValidateConfig:
    """Tests for validate_config function."""

    def test_valid_full_config(self):
        """Test that a fully valid config produces no errors."""
        data = {
            'defaults': {'model': 'sonnet'},
            'skills': {
                'execute': {
                    'subagents': {
                        'executor': {'model': 'sonnet'},
                        'auto-debug': {'model': 'haiku'},
                        'verify-execute': {'model': 'haiku'},
                    }
                }
            },
        }
        errors = validate_config(data)
        assert errors == []

    def test_invalid_model_value(self):
        """Test that an invalid model value produces an error."""
        data = {'defaults': {'model': 'gpt-4'}}
        errors = validate_config(data)
        assert len(errors) == 1
        assert 'invalid model' in errors[0]

    def test_unknown_skill_warns(self):
        """Test that an unknown skill name produces a warning."""
        data = {'skills': {'unknown_skill': {'subagents': {}}}}
        errors = validate_config(data)
        assert len(errors) == 1
        assert 'unknown skill' in errors[0]

    def test_unknown_subagent_warns(self):
        """Test that an unknown subagent name produces a warning."""
        data = {'skills': {'execute': {'subagents': {'nonexistent': {'model': 'sonnet'}}}}}
        errors = validate_config(data)
        assert len(errors) == 1
        assert 'unknown subagent' in errors[0]

    def test_valid_discuss_config_with_new_subagents(self):
        """Test that discuss config with codebase-explore, external-research, verify-discuss validates cleanly."""
        data = {
            'skills': {
                'discuss': {
                    'subagents': {
                        'codebase-explore': {'model': 'sonnet'},
                        'external-research': {'model': 'haiku'},
                        'verify-discuss': {'model': 'haiku'},
                    }
                }
            },
        }
        errors = validate_config(data)
        assert errors == []

    def test_old_explore_subagent_warns(self):
        """Test that old 'explore' subagent name for init produces a warning."""
        data = {'skills': {'init': {'subagents': {'explore': {'model': 'sonnet'}}}}}
        errors = validate_config(data)
        assert len(errors) == 1
        assert 'unknown subagent' in errors[0]
        assert "'explore'" in errors[0]

    def test_old_verify_subagent_warns(self):
        """Test that old 'verify' subagent name produces a warning after rename."""
        for skill in ('discuss', 'execute'):
            data = {'skills': {skill: {'subagents': {'verify': {'model': 'haiku'}}}}}
            errors = validate_config(data)
            assert len(errors) == 1, f'Expected 1 warning for {skill}.verify'
            assert 'unknown subagent' in errors[0]

    def test_empty_config_no_errors(self):
        """Test that an empty dict passes validation."""
        errors = validate_config({})
        assert errors == []


class TestKnownSubagents:
    """Tests for KNOWN_SUBAGENTS mapping."""

    def test_known_subagents_mapping(self):
        """Test that KNOWN_SUBAGENTS contains expected agents per skill."""
        assert KNOWN_SUBAGENTS == {
            'init': ('init-explore',),
            'discuss': ('codebase-explore', 'external-research', 'verify-discuss'),
            'plan': ('plan-review',),
            'execute': ('executor', 'auto-debug', 'verify-execute'),
        }


class TestResolveSubagentConfig:
    """Tests for resolve_subagent_config function."""

    def test_skill_specific_overrides_defaults(self):
        """Test that skill-specific config overrides defaults."""
        data = {
            'defaults': {'model': 'sonnet'},
            'skills': {
                'execute': {
                    'subagents': {
                        'executor': {'model': 'opus'},
                    }
                }
            },
        }
        config = resolve_subagent_config(data, 'execute', 'executor')
        assert config == SubagentConfig(model='opus')

    def test_defaults_used_when_no_skill_override(self):
        """Test that defaults are used when no skill-specific config exists."""
        data = {'defaults': {'model': 'sonnet'}}
        config = resolve_subagent_config(data, 'execute', 'executor')
        assert config == SubagentConfig(model='sonnet')

    def test_none_when_not_configured(self):
        """Test that model is None when nothing is set anywhere."""
        config = resolve_subagent_config({}, 'execute', 'executor')
        assert config.model is None

    def test_resolve_codebase_explore_config(self):
        """Test that codebase-explore subagent model resolves correctly."""
        data = {
            'skills': {
                'discuss': {
                    'subagents': {
                        'codebase-explore': {'model': 'opus'},
                    }
                }
            },
        }
        config = resolve_subagent_config(data, 'discuss', 'codebase-explore')
        assert config == SubagentConfig(model='opus')

    def test_resolve_external_research_config(self):
        """Test that external-research subagent model resolves correctly."""
        data = {
            'defaults': {'model': 'sonnet'},
            'skills': {
                'discuss': {
                    'subagents': {
                        'external-research': {'model': 'haiku'},
                    }
                }
            },
        }
        config = resolve_subagent_config(data, 'discuss', 'external-research')
        assert config == SubagentConfig(model='haiku')

    def test_empty_config_returns_none(self):
        """Test that empty config returns None model."""
        config = resolve_subagent_config({}, 'discuss', 'codebase-explore')
        assert config.model is None

    def test_unknown_skill_returns_none(self):
        """Test that an unknown skill returns None model."""
        config = resolve_subagent_config({}, 'unknown', 'subagent')
        assert config.model is None
