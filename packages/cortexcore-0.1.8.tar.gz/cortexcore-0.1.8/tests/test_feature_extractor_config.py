from cortex.rl.feature_extractors.config import TokenMLPFeatureExtractorConfig, TokenPerceiverFeatureExtractorConfig


def test_token_feature_extractor_defaults_use_full_observation_budget() -> None:
    assert TokenPerceiverFeatureExtractorConfig().max_tokens == 300
    assert TokenMLPFeatureExtractorConfig().max_tokens == 300
