"""Configuration classes for Cortex cores, scaffolds, and stacks."""

from __future__ import annotations

from typing import Any, Mapping

from pydantic import BaseModel, ConfigDict, Field, SerializeAsAny, field_validator, model_validator


class CoreConfig(BaseModel):
    """Base configuration for memory cores with optional hidden size inference."""

    model_config = ConfigDict(extra="allow")

    hidden_size: int | None = Field(default=None)


class LSTMCoreConfig(CoreConfig):
    """Configuration for standard LSTM core (batch-first, single layer default)."""

    core_type: str = "lstm"
    hidden_size: int | None = Field(default=None)
    num_layers: int = Field(default=1, ge=1)
    bias: bool = Field(default=True)
    dropout: float = Field(default=0.0, ge=0.0)
    proj_size: int = Field(default=0, ge=0)


class CausalConv1dCoreConfig(CoreConfig):
    """Configuration for causal 1D convolution with optional channel mixing."""

    core_type: str = "cconv"
    kernel_size: int = Field(default=4, ge=0)
    causal_conv_bias: bool = Field(default=True)
    channel_mixing: bool = Field(default=False)


class mLSTMCoreConfig(CoreConfig):
    """Configuration for Matrix LSTM core with parallel chunk processing."""

    core_type: str = "mlstm"
    hidden_size: int | None = Field(default=None)
    num_heads: int = Field(default=4, ge=1)
    chunk_size: int = Field(default=64, ge=1)
    conv1d_kernel_size: int = Field(default=4, ge=1)
    use_axon_layer: bool = Field(default=False)
    use_axon_qkv: bool = Field(default=False)
    axon_layer_config: AxonCoreConfig | None = Field(default=None)
    axon_qkv_config: AxonCoreConfig | None = Field(default=None)


class sLSTMCoreConfig(CoreConfig):
    """Configuration for Structured LSTM core with per-head recurrence."""

    core_type: str = "slstm"
    hidden_size: int | None = Field(default=None)
    num_heads: int = Field(default=4, ge=1)
    conv1d_kernel_size: int = Field(default=4, ge=0)
    dropout: float = Field(default=0.0, ge=0.0)
    use_axon_layer: bool = Field(default=False)
    axon_layer_config: AxonCoreConfig | None = Field(default=None)


class XLCoreConfig(CoreConfig):
    """Configuration for Transformer-XL style attention core."""

    core_type: str = "xl"
    hidden_size: int | None = Field(default=None)
    n_heads: int = Field(default=4, ge=1)
    head_dim: int | None = Field(default=None, ge=1)
    mem_len: int = Field(default=128, ge=0)
    attn_dropout: float = Field(default=0.0, ge=0.0, le=1.0)
    out_dropout: float = Field(default=0.0, ge=0.0, le=1.0)
    use_bias: bool = Field(default=True)
    use_axon_qkv: bool = Field(default=False)
    axon_qkv_config: AxonCoreConfig | None = Field(default=None)


class AGaLiTeCoreConfig(CoreConfig):
    """Configuration for AGaLiTe attention core with recurrent discounted state."""

    core_type: str = "agalite"
    hidden_size: int | None = Field(default=None)
    n_heads: int = Field(default=8, ge=1)
    head_dim: int | None = Field(default=None, ge=1)
    eta: int = Field(default=6, ge=1)
    r: int = Field(default=2, ge=1)
    eps: float = Field(default=1e-5, ge=0.0)
    dropout: float = Field(default=0.0, ge=0.0, le=1.0)


class AxonCoreConfig(CoreConfig):
    """Configuration for Axon core with streaming RTU and diagonal input weights."""

    core_type: str = "axon"
    hidden_size: int | None = Field(default=None)
    activation: str = Field(default="identity")
    r_max: float = Field(default=1.0)
    r_min: float = Field(default=0.0)
    max_phase: float = Field(default=6.28)
    out_dim: int | None = Field(default=None, ge=1)
    cuda_seq_threshold: int = Field(default=5000, ge=1)
    use_srht: bool = Field(default=False)
    srht_permute: bool = Field(default=True)
    use_fullrank_rtu: bool = Field(default=False)
    use_untraced_linear: bool = Field(default=True)


class ScaffoldConfig(BaseModel):
    """Base configuration for cortex scaffolds."""

    model_config = ConfigDict(extra="allow")

    core: SerializeAsAny[CoreConfig | None] = Field(default=None)

    def get_core_hidden_size(self, d_hidden: int) -> int:
        """Compute core hidden size from the stack's external dimension."""
        return d_hidden

    @field_validator("core", mode="before")
    @classmethod
    def _coerce_core(cls, value: Any) -> Any:
        if value is None or isinstance(value, CoreConfig):
            return value
        if isinstance(value, Mapping):
            tag = value.get("core_type")
            if not isinstance(tag, str) or not tag:
                return value
            from cortex.cores.registry import get_core_config_class  # noqa: PLC0415

            config_class = get_core_config_class(tag)
            return config_class.model_validate(value)
        return value


class PassThroughScaffoldConfig(ScaffoldConfig):
    """Configuration for a passthrough scaffold (no projections)."""

    scaffold_type: str = "passthrough"


class PreUpScaffoldConfig(ScaffoldConfig):
    """Configuration for pre-upsampling scaffolds (projects before the core)."""

    scaffold_type: str = "preup"
    proj_factor: float = Field(default=2.0, gt=0.0)
    activate_core_input: bool = Field(default=True)
    dropout: float = Field(default=0.0, ge=0.0, le=1.0, description="Consistent dropout probability")

    def get_core_hidden_size(self, d_hidden: int) -> int:
        """Core operates on the expanded inner dimension."""
        return int(self.proj_factor * d_hidden)


class PreUpGatedScaffoldConfig(ScaffoldConfig):
    """Configuration for GRU-gated pre-upsampling scaffolds (projects before the core)."""

    scaffold_type: str = "preup_gated"
    proj_factor: float = Field(default=2.0, gt=0.0)
    gru_bias: float = Field(default=2.0)
    activate_core_input: bool = Field(default=True)
    dropout: float = Field(default=0.0, ge=0.0, le=1.0, description="Consistent dropout probability")

    def get_core_hidden_size(self, d_hidden: int) -> int:
        """Core operates on the expanded inner dimension."""
        return int(self.proj_factor * d_hidden)


class PostUpScaffoldConfig(ScaffoldConfig):
    """Configuration for post-processing scaffolds (core then FFN)."""

    scaffold_type: str = "postup"
    proj_factor: float = Field(default=1.5, gt=0.0)
    dropout: float = Field(default=0.0, ge=0.0, le=1.0, description="Consistent dropout probability for FFN")


class PostUpGatedScaffoldConfig(ScaffoldConfig):
    """Configuration for GRU-gated post scaffolds (GTrXL-style gating)."""

    scaffold_type: str = "postup_gated"
    proj_factor: float = Field(default=1.5, gt=0.0)
    gru_bias: float = Field(default=2.0)
    dropout: float = Field(default=0.0, ge=0.0, le=1.0, description="Consistent dropout probability for FFN")


class AdapterScaffoldConfig(ScaffoldConfig):
    """Configuration for adapter scaffolds with identity-initialized residual paths."""

    scaffold_type: str = "adapter"
    base_scaffold: SerializeAsAny[ScaffoldConfig]
    core: CoreConfig | None = None
    bottleneck: int = Field(default=64, ge=1)
    dropout: float = Field(default=0.0, ge=0.0, le=1.0)
    per_channel_gate: bool = Field(default=False)
    activation: str = Field(default="gelu")

    def get_core_hidden_size(self, d_hidden: int) -> int:
        """Delegate to the wrapped scaffold."""
        return self.base_scaffold.get_core_hidden_size(d_hidden)

    @field_validator("base_scaffold", mode="before")
    @classmethod
    def _coerce_base_scaffold(cls, value: Any) -> Any:
        if isinstance(value, ScaffoldConfig):
            return value
        if isinstance(value, Mapping):
            tag = value.get("scaffold_type")
            if not isinstance(tag, str) or not tag:
                return value
            from cortex.scaffolds.registry import get_scaffold_config_class  # noqa: PLC0415

            config_class = get_scaffold_config_class(tag)
            return config_class.model_validate(value)
        return value


class RoutedAdapterConfig(BaseModel):
    """Configuration for route-ID-routed low-rank adapters on linear-like modules."""

    enabled: bool = Field(default=True)
    num_slots: int = Field(ge=1)
    rank: int = Field(default=4, ge=1)
    alpha: float | None = Field(default=None, gt=0.0)
    dropout: float = Field(default=0.0, ge=0.0, le=1.0)
    freeze_base: bool = Field(default=False)
    trunk_lr_mult: float = Field(
        default=1.0,
        ge=0.0,
        description=(
            "Initial gradient multiplier applied to all non-adapter parameters in the adapted module tree "
            "(can be updated via cortex.routed_adapter.set_trunk_lr_mult_)."
        ),
    )
    require_route_ids: bool = Field(default=True)


class CortexStackConfig(BaseModel):
    """Configuration for a sequential stack of scaffolds."""

    scaffolds: list[SerializeAsAny[ScaffoldConfig]]
    d_hidden: int = Field(ge=1)
    post_norm: bool = Field(default=False)
    compile_scaffolds: bool = Field(default=True)
    routed_adapter: RoutedAdapterConfig | None = Field(default=None)

    @field_validator("scaffolds", mode="before")
    @classmethod
    def _coerce_scaffolds(cls, value: Any) -> Any:
        if not isinstance(value, list):
            return value
        out: list[Any] = []
        for item in value:
            if isinstance(item, ScaffoldConfig):
                out.append(item)
                continue
            if isinstance(item, Mapping):
                tag = item.get("scaffold_type")
                if isinstance(tag, str) and tag:
                    from cortex.scaffolds.registry import get_scaffold_config_class  # noqa: PLC0415

                    config_class = get_scaffold_config_class(tag)
                    out.append(config_class.model_validate(item))
                    continue
            out.append(item)
        return out


class MultiScaleLayerConfig(BaseModel):
    period: int = Field(ge=1)
    scaffold: SerializeAsAny[ScaffoldConfig]

    @field_validator("scaffold", mode="before")
    @classmethod
    def _coerce_scaffold(cls, value: Any) -> Any:
        if isinstance(value, ScaffoldConfig):
            return value
        if isinstance(value, Mapping):
            tag = value.get("scaffold_type")
            if isinstance(tag, str) and tag:
                from cortex.scaffolds.registry import get_scaffold_config_class  # noqa: PLC0415

                config_class = get_scaffold_config_class(tag)
                return config_class.model_validate(value)
        return value


class MultiScaleStackConfig(BaseModel):
    layers: list[SerializeAsAny[MultiScaleLayerConfig]]
    d_hidden: int = Field(ge=1)
    num_inner_steps: int = Field(ge=1)
    splits: list[str] = Field(min_length=1)
    split_start_layer: int = Field(
        ge=1,
        description="Index of the first split-specific layer; all prior layers are shared.",
    )
    post_norm: bool = Field(default=False)
    compile_scaffolds: bool = Field(default=True)

    @field_validator("splits")
    @classmethod
    def _validate_splits(cls, value: list[str]) -> list[str]:
        normalized = [split.strip() for split in value]
        if any(not split for split in normalized):
            raise ValueError("splits must be non-empty")
        if len(set(normalized)) != len(normalized):
            raise ValueError(f"splits must be unique, got {normalized}")
        return normalized

    @model_validator(mode="after")
    def _validate_schedule(self) -> "MultiScaleStackConfig":
        if not self.layers:
            raise ValueError("MultiScaleStackConfig requires at least one layer")

        previous_period: int | None = None
        for idx, layer in enumerate(self.layers):
            if self.num_inner_steps % layer.period != 0:
                raise ValueError(
                    f"Layer {idx} period {layer.period} must divide num_inner_steps={self.num_inner_steps}"
                )
            if previous_period is not None and layer.period < previous_period:
                raise ValueError("Layer periods must be monotone nondecreasing")
            if previous_period is not None and layer.period % previous_period != 0:
                raise ValueError(
                    f"Layer {idx} period {layer.period} must divide cleanly by prior period {previous_period}"
                )
            previous_period = layer.period

        if self.split_start_layer >= len(self.layers):
            raise ValueError("split_start_layer must leave at least one split-specific layer")

        return self


class RouterConfig(BaseModel):
    """Router settings with global prior and optional per-token refinement."""

    model_config = ConfigDict(extra="allow")

    d_key: int | None = Field(default=None, ge=1, description="Key/query dim for global prior; defaults to d_hidden.")
    temperature: float = Field(default=1.0, gt=0.0, description="Softmax temperature for the global gate.")
    top_k: int | None = Field(default=None, ge=1, description="If set, keep only top-k experts in the global prior.")
    use_sqrt_scale: bool = Field(default=True, description="Use 1/sqrt(d_key) (vs 1/d_key) dot-product scaling.")
    init_scale_wq: float = Field(default=0.0, description="Uniform init scale for Wq; 0 -> near-uniform prior.")
    init_scale_wk: float = Field(default=0.0, description="Uniform init scale for Wk; 0 -> near-uniform prior.")

    d_key_local: int | None = Field(default=None, ge=1, description="Key dim for per-token refiner; defaults to d_key.")
    local_temperature: float = Field(default=1.0, gt=0.0, description="Temperature for token-refiner logits.")
    whisper_lambda: float = Field(
        default=0.1,
        ge=0.0,
        description="Strength lambda of per-token refinement (0 disables).",
    )
    center_refine: bool = Field(default=True, description="Center token logits over experts to redistribute mass only.")
    restrict_to_topk: bool = Field(default=True, description="Limit refinement to the global top-k support if set.")


class ColumnScaffoldConfig(ScaffoldConfig):
    """Column of experts with a shared router."""

    model_config = ConfigDict(extra="allow")

    scaffold_type: str = "column"
    experts: list[SerializeAsAny[ScaffoldConfig]]
    router: RouterConfig = Field(default_factory=RouterConfig, description="Router hyperparameters for this column.")
    alpha_init: float = Field(
        default=1.0,
        ge=0.0,
        description=(
            "Initial scale for the shared ReZero gate alpha applied to BOTH the main MoE residual r_t "
            "and the correction head rho(r_t): out = x + alpha·r_t + alpha·rho(r_t). "
            "Smaller values keep the scaffold near-identity at init; "
            "larger values engage both paths more strongly. Also scales gradient flow through both paths."
        ),
    )

    def get_core_hidden_size(self, d_hidden: int) -> int:  # type: ignore[override]
        return d_hidden

    @field_validator("experts", mode="before")
    @classmethod
    def _coerce_experts(cls, value: Any) -> Any:
        if not isinstance(value, list):
            return value
        out: list[ScaffoldConfig] = []
        for item in value:
            if isinstance(item, ScaffoldConfig):
                out.append(item)
                continue
            if isinstance(item, Mapping):
                tag = item.get("scaffold_type")
                if isinstance(tag, str) and tag:
                    from cortex.scaffolds.registry import get_scaffold_config_class  # noqa: PLC0415

                    config_class = get_scaffold_config_class(tag)
                    out.append(config_class.model_validate(item))
                    continue
            out.append(item)
        return out


__all__ = [
    "CoreConfig",
    "CausalConv1dCoreConfig",
    "LSTMCoreConfig",
    "mLSTMCoreConfig",
    "sLSTMCoreConfig",
    "XLCoreConfig",
    "AGaLiTeCoreConfig",
    "AxonCoreConfig",
    "ScaffoldConfig",
    "PassThroughScaffoldConfig",
    "PreUpScaffoldConfig",
    "PreUpGatedScaffoldConfig",
    "PostUpScaffoldConfig",
    "PostUpGatedScaffoldConfig",
    "AdapterScaffoldConfig",
    "RoutedAdapterConfig",
    "CortexStackConfig",
    "MultiScaleLayerConfig",
    "MultiScaleStackConfig",
    "RouterConfig",
    "ColumnScaffoldConfig",
]
