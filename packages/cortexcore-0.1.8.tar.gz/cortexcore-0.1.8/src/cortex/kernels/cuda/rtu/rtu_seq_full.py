import os
from typing import Optional

from cortex.kernels.cuda.extension_loader import safe_load_extension

_mod_path = os.path.dirname(__file__)
_ext: Optional[object] = None


def _load_ext() -> object:
    global _ext
    if _ext is not None:
        return _ext

    sources = [
        os.path.join(_mod_path, "rtu_seq_full_binding.cpp"),
        os.path.join(_mod_path, "rtu_seq_full_kernels.cu"),
    ]
    _ext = safe_load_extension(
        name="rtu_seq_full",
        sources=sources,
        extra_cflags=["-O3"],
        extra_cuda_cflags=["-O3", "-Xptxas", "-O3"],
        verbose=False,
    )
    return _ext


def forward_full(*args: object, **kwargs: object) -> object:
    return _load_ext().forward_full(*args, **kwargs)


def backward_full(*args: object, **kwargs: object) -> object:
    return _load_ext().backward_full(*args, **kwargs)
