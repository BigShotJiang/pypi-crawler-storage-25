from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import Tensor


@dataclass(frozen=True)
class IntrinsicRewardResult:
    intrinsic_b: Tensor


def successor_intrinsic_reward(
    *,
    psi_bf: Tensor,
    prev_psi_bf: Tensor,
    prev_valid_b: Tensor,
    beta_count: float,
    epsilon: float,
    beta_delta: float,
    delta_clip: float,
) -> Tensor:
    count_bonus = float(beta_count) / (float(epsilon) + psi_bf.abs().sum(dim=-1))
    if float(beta_delta) <= 0:
        return count_bonus

    delta_bonus = (psi_bf - prev_psi_bf).pow(2).sum(dim=-1)
    delta_bonus = delta_bonus.clamp(min=0.0, max=float(delta_clip))
    delta_bonus = delta_bonus * prev_valid_b.to(device=delta_bonus.device, dtype=delta_bonus.dtype)
    return count_bonus + float(beta_delta) * delta_bonus


def compute_successor_intrinsic_bonus(
    *,
    psi_bf: Tensor,
    prev_psi_bf: Tensor,
    prev_valid_b: Tensor,
    beta_count: float,
    epsilon: float,
    beta_delta: float,
    delta_clip: float,
) -> IntrinsicRewardResult:
    return IntrinsicRewardResult(
        intrinsic_b=successor_intrinsic_reward(
            psi_bf=psi_bf,
            prev_psi_bf=prev_psi_bf,
            prev_valid_b=prev_valid_b,
            beta_count=beta_count,
            epsilon=epsilon,
            beta_delta=beta_delta,
            delta_clip=delta_clip,
        )
    )


def update_prev_successor_state_(
    *,
    prev_psi_agentF: Tensor,
    agent_ids_b: Tensor,
    psi_bf: Tensor,
    boundary_b: Tensor,
) -> None:
    with torch.no_grad():
        prev_psi_agentF[agent_ids_b] = psi_bf
        if bool(boundary_b.any()):
            prev_psi_agentF[agent_ids_b[boundary_b]] = torch.nan


__all__ = [
    "IntrinsicRewardResult",
    "successor_intrinsic_reward",
    "compute_successor_intrinsic_bonus",
    "update_prev_successor_state_",
]
