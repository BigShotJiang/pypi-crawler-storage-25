from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Sequence

import torch
import torch.nn as nn
from torch import Tensor

from cortex.cognitive_substrate._shared import make_mlp
from cortex.rl.diff_horde import diff_horde_delta_lambda, diff_horde_update_phi_bar_agents_


class DecisionBox(nn.Module, ABC):
    """Abstract decision/evaluation box."""

    @abstractmethod
    def forward(self, rl_state: Tensor) -> "DecisionOutputs":
        """Return action-head logits and value estimates."""


@dataclass(frozen=True)
class DecisionOutputs:
    action_head_logits: tuple[Tensor, ...]
    values: Tensor
    h_values: Tensor


class DefaultDecisionBox(DecisionBox):
    """Default RL box for action selection and evaluation."""

    def __init__(
        self,
        *,
        state_dim: int,
        actor_hidden: int,
        critic_hidden: int,
        action_head_dims: Sequence[int],
    ) -> None:
        super().__init__()
        self.actor_body = make_mlp(state_dim, actor_hidden, actor_hidden)
        self.value_body = make_mlp(state_dim, critic_hidden, 1)
        self.h_value_body = make_mlp(state_dim, critic_hidden, 1)
        self.action_head_layers = nn.ModuleList(nn.Linear(actor_hidden, head_dim) for head_dim in action_head_dims)

    def forward(self, rl_state: Tensor) -> DecisionOutputs:
        actor_hidden = self.actor_body(rl_state)
        return DecisionOutputs(
            action_head_logits=tuple(head(actor_hidden) for head in self.action_head_layers),
            values=self.value_body(rl_state).squeeze(-1),
            h_values=self.h_value_body(rl_state).squeeze(-1),
        )


@dataclass(frozen=True)
class PPOActorObjectiveResult:
    policy_loss: Tensor
    ratio: Tensor
    approx_kl: Tensor
    clipfrac: Tensor


@dataclass(frozen=True)
class ClippedValueObjectiveResult:
    value_loss: Tensor
    value_loss_vec: Tensor


@dataclass(frozen=True)
class GTDCriticObjectiveResult:
    total: Tensor
    critic_loss: Tensor
    aux_loss: Tensor
    h_mse: Tensor
    delta_lambda: Tensor
    returns: Tensor
    rho_clipfrac: Tensor | None


def compute_ppo_actor_objective(
    *,
    advantages: Tensor,
    old_logprob: Tensor,
    new_logprob: Tensor,
    clip_coef: float,
    ratio: Tensor | None = None,
) -> PPOActorObjectiveResult:
    if ratio is None:
        logratio = torch.clamp(new_logprob - old_logprob, -10, 10)
        ratio = logratio.exp()

    pg_loss1 = -advantages * ratio
    pg_loss2 = -advantages * torch.clamp(ratio, 1 - float(clip_coef), 1 + float(clip_coef))
    policy_loss = torch.max(pg_loss1, pg_loss2).mean()

    logratio_metric = new_logprob - old_logprob
    approx_kl = ((ratio - 1) - logratio_metric).mean()
    clipfrac = ((ratio - 1.0).abs() > float(clip_coef)).float().mean()
    return PPOActorObjectiveResult(
        policy_loss=policy_loss,
        ratio=ratio,
        approx_kl=approx_kl,
        clipfrac=clipfrac,
    )


def compute_clipped_value_objective(
    *,
    old_values: Tensor,
    new_values: Tensor,
    returns: Tensor,
    vf_clip_coef: float,
    clip_vloss: bool,
) -> ClippedValueObjectiveResult:
    if clip_vloss:
        v_loss_unclipped = (new_values - returns) ** 2
        v_clipped = old_values + torch.clamp(new_values - old_values, -float(vf_clip_coef), float(vf_clip_coef))
        v_loss_clipped = (v_clipped - returns) ** 2
        value_loss_vec = 0.5 * torch.max(v_loss_unclipped, v_loss_clipped)
    else:
        value_loss_vec = 0.5 * ((new_values - returns) ** 2)

    return ClippedValueObjectiveResult(
        value_loss=value_loss_vec.mean(),
        value_loss_vec=value_loss_vec,
    )


def resolve_reward_baseline(
    *,
    reward_phi_bar_agentF: Tensor,
    agent_ids_b: Tensor,
    rewards_b1: Tensor,
    avg_reward_agent: Tensor | None = None,
) -> Tensor:
    if avg_reward_agent is not None:
        baseline_b1 = (
            avg_reward_agent[agent_ids_b].to(device=reward_phi_bar_agentF.device, dtype=torch.float32).view(-1, 1)
        )
    else:
        baseline_b1 = reward_phi_bar_agentF[agent_ids_b]
    uninitialized = torch.isnan(baseline_b1)
    if bool(uninitialized.any()):
        baseline_b1 = torch.where(uninitialized, rewards_b1, baseline_b1)
    return baseline_b1


def update_reward_baseline_state_(
    *,
    reward_phi_bar_agentF: Tensor,
    agent_ids_b: Tensor,
    rewards_b1: Tensor,
    baseline_b1: Tensor,
    eta: float,
) -> None:
    with torch.no_grad():
        reward_phi_bar_agentF[agent_ids_b] = baseline_b1
        diff_horde_update_phi_bar_agents_(
            phi_bar_agentF=reward_phi_bar_agentF,
            agent_ids_b=agent_ids_b,
            phi_bF=rewards_b1,
            eta=float(eta),
        )


def compute_gtd_critic_objective(
    *,
    new_values_bt: Tensor,
    h_values_bt: Tensor,
    rewards_bt: Tensor,
    reward_baseline_bt: Tensor,
    resets_bt: Tensor,
    rho_bt: Tensor,
    gamma: float,
    gae_lambda: float,
    rho_clip: float,
    vf_coef: float,
    aux_coef: float,
    beta: float,
    aux_params: Sequence[Tensor] = (),
    teacher_mask_b: Tensor | None = None,
) -> GTDCriticObjectiveResult:
    delta_lambda_bt1F, _metrics = diff_horde_delta_lambda(
        psi_btF=new_values_bt.unsqueeze(-1),
        phi_btF=rewards_bt.unsqueeze(-1),
        phi_bar_btF=reward_baseline_bt.unsqueeze(-1),
        resets_bt=resets_bt,
        gamma=float(gamma),
        lambda_=float(gae_lambda),
        rho_bt=rho_bt,
        rho_clip=float(rho_clip),
    )

    delta_lambda = torch.zeros_like(new_values_bt)
    delta_lambda[:, :-1] = delta_lambda_bt1F.squeeze(-1)

    dl = delta_lambda[:, :-1]
    v_t = new_values_bt[:, :-1]
    h_t = h_values_bt[:, :-1]
    h_mse = (dl.detach() - h_t) ** 2

    critic_loss = (h_t.detach() * dl).mean() - ((dl.detach() - h_t.detach()) * v_t).mean()

    l2_sum = torch.tensor(0.0, device=critic_loss.device, dtype=critic_loss.dtype)
    l2_count = 0
    if float(beta) > 0:
        for param in aux_params:
            l2_sum = l2_sum + (param * param).sum()
            l2_count += int(param.numel())
    l2 = l2_sum / max(l2_count, 1)
    aux_loss = 0.5 * h_mse.mean() + 0.5 * float(beta) * l2
    total = float(vf_coef) * critic_loss + float(aux_coef) * aux_loss

    rho_clipfrac = None
    if teacher_mask_b is not None and bool(teacher_mask_b.any()):
        rho_trim = rho_bt[teacher_mask_b][:, :-1]
        rho_clipfrac = (rho_trim > float(rho_clip)).float().mean()

    return GTDCriticObjectiveResult(
        total=total,
        critic_loss=critic_loss,
        aux_loss=aux_loss,
        h_mse=h_mse.mean(),
        delta_lambda=delta_lambda,
        returns=(new_values_bt + delta_lambda).detach(),
        rho_clipfrac=rho_clipfrac,
    )


__all__ = [
    "DecisionBox",
    "DecisionOutputs",
    "DefaultDecisionBox",
    "PPOActorObjectiveResult",
    "ClippedValueObjectiveResult",
    "GTDCriticObjectiveResult",
    "compute_ppo_actor_objective",
    "compute_clipped_value_objective",
    "resolve_reward_baseline",
    "update_reward_baseline_state_",
    "compute_gtd_critic_objective",
]
