from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass

import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor

from cortex.cognitive_substrate._shared import make_mlp

COGNITIVE_SUBSTRATE_SUCCESSOR_OUTPUT_KEYS = {
    "cognitive_substrate_phi",
    "cognitive_substrate_psi",
    "cognitive_substrate_h",
    "cognitive_substrate_sf_reward_pred",
}


class SuccessorBox(nn.Module, ABC):
    """Abstract successor-feature box."""

    @abstractmethod
    def forward(
        self,
        z: Tensor,
        sf_state: Tensor,
        *,
        couple_into_pred: bool,
    ) -> dict[str, Tensor]:
        """Return phi/psi/h outputs for the successor objective."""


class DefaultSuccessorBox(SuccessorBox):
    """Default successor-feature box with GTD-style psi/h outputs."""

    def __init__(
        self,
        *,
        latent_dim: int,
        sf_state_dim: int,
        phi_dim: int,
        hidden_dim: int,
    ) -> None:
        super().__init__()
        self.phi_dim = int(phi_dim)
        self.phi_head = make_mlp(latent_dim, hidden_dim, phi_dim)
        self.psi_head = make_mlp(sf_state_dim, hidden_dim, phi_dim)
        self.h_head = make_mlp(sf_state_dim, hidden_dim, phi_dim)
        self.reward_head = nn.Linear(phi_dim, 1)

    def forward(
        self,
        z: Tensor,
        sf_state: Tensor,
        *,
        couple_into_pred: bool,
    ) -> dict[str, Tensor]:
        phi_input = z if couple_into_pred else z.detach()
        phi = self.phi_head(phi_input)
        psi = self.psi_head(sf_state)
        return {
            "cognitive_substrate_phi": phi,
            "cognitive_substrate_psi": psi,
            "cognitive_substrate_h": self.h_head(sf_state),
            "cognitive_substrate_sf_reward_pred": self.reward_head(phi).squeeze(-1),
        }


@dataclass(frozen=True)
class SuccessorRewardPredictionResult:
    loss: Tensor


def compute_successor_reward_reconstruction_loss(
    *,
    reward_pred_bt: Tensor,
    extrinsic_rewards_bt: Tensor,
) -> SuccessorRewardPredictionResult:
    return SuccessorRewardPredictionResult(loss=F.mse_loss(reward_pred_bt, extrinsic_rewards_bt, reduction="mean"))


__all__ = [
    "COGNITIVE_SUBSTRATE_SUCCESSOR_OUTPUT_KEYS",
    "SuccessorBox",
    "DefaultSuccessorBox",
    "SuccessorRewardPredictionResult",
    "compute_successor_reward_reconstruction_loss",
]
