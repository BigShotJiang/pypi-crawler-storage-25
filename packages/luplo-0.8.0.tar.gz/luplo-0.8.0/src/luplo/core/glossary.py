"""CRUD + query expansion for the glossary tables.

The glossary is luplo's strict-first terminology layer.  Terms are extracted
from items, normalised, and grouped.  Approved groups power the search
pipeline's query expansion — e.g. ``"vendor"`` expands to
``(vendor | shop | NPC벤더)``.

Three tables: ``glossary_groups``, ``glossary_terms``, ``glossary_rejections``.
No aggressive clustering — strict LLM matching only, with a human curation
queue for anything uncertain.
"""

from __future__ import annotations

import uuid
from typing import Any

from psycopg import AsyncConnection, sql
from psycopg.rows import dict_row

from luplo.core.errors import GlossaryGroupHasActiveTermsError, NotFoundError
from luplo.core.id_resolve import resolve_uuid_prefix
from luplo.core.models import GlossaryGroup, GlossaryRejection, GlossaryTerm


async def _resolve_group(
    conn: AsyncConnection[Any],
    group_id: str,
    *,
    project_id: str | None = None,
) -> str | None:
    """Resolve a glossary group ID or hex prefix; returns the full ID or None.

    ``resolve_uuid_prefix`` short-circuits on full UUIDs without touching
    the DB, so we follow up with an existence check when the input was a
    full UUID. Otherwise a non-existent UUID would propagate silently
    until a downstream INSERT trips an FK violation.
    """
    resolved = await resolve_uuid_prefix(
        conn,
        "glossary_groups",
        group_id,
        project_id=project_id,
        label_column="canonical",
    )
    if resolved is None or resolved != group_id:
        return resolved
    async with conn.cursor() as cur:
        await cur.execute("SELECT 1 FROM glossary_groups WHERE id = %s", (resolved,))
        if await cur.fetchone() is None:
            return None
    return resolved


async def _resolve_term(conn: AsyncConnection[Any], term_id: str) -> str | None:
    """Resolve a glossary term ID or hex prefix.

    glossary_terms has no project_id column (project scope flows through
    group_id), so prefix collisions are unscoped. UUID prefix space makes
    cross-project clashes negligibly rare in practice. Like
    :func:`_resolve_group`, we verify existence for full UUIDs as well so
    callers can rely on a ``None`` to mean "no such row."
    """
    resolved = await resolve_uuid_prefix(
        conn,
        "glossary_terms",
        term_id,
        label_column="surface",
    )
    if resolved is None or resolved != term_id:
        return resolved
    async with conn.cursor() as cur:
        await cur.execute("SELECT 1 FROM glossary_terms WHERE id = %s", (resolved,))
        if await cur.fetchone() is None:
            return None
    return resolved


# ── Column definitions ───────────────────────────────────────────

_GROUP_COLUMNS = (
    "id",
    "project_id",
    "scope",
    "scope_id",
    "canonical",
    "definition",
    "created_at",
    "created_by",
    "last_reviewed_at",
    "last_reviewed_by",
)
_GROUP_RETURNING = sql.SQL(", ").join(sql.Identifier(c) for c in _GROUP_COLUMNS)

_TERM_COLUMNS = (
    "id",
    "group_id",
    "surface",
    "normalized",
    "is_protected",
    "status",
    "source_item_id",
    "context_snippet",
    "decided_by",
    "decided_at",
    "created_at",
)
_TERM_RETURNING = sql.SQL(", ").join(sql.Identifier(c) for c in _TERM_COLUMNS)


def _row_to_group(row: dict[str, Any]) -> GlossaryGroup:
    for col in ("created_by", "last_reviewed_by"):
        if row.get(col) is not None:
            row[col] = str(row[col])
    return GlossaryGroup(**row)


def _row_to_term(row: dict[str, Any]) -> GlossaryTerm:
    if row.get("decided_by") is not None:
        row["decided_by"] = str(row["decided_by"])
    return GlossaryTerm(**row)


# ── Groups ───────────────────────────────────────────────────────


async def create_glossary_group(
    conn: AsyncConnection[Any],
    *,
    project_id: str,
    canonical: str,
    definition: str | None = None,
    scope: str = "project",
    scope_id: str | None = None,
    created_by: str | None = None,
    id: str | None = None,
) -> GlossaryGroup:
    """Create a glossary group (a semantic unit with one canonical term).

    Args:
        conn: Async psycopg connection.
        project_id: Owning project.
        canonical: The canonical surface form for this concept.
        definition: Optional one-line definition.
        scope: Scope level — ``"project"`` (default) or ``"system"``.
        scope_id: System ID when scope is ``"system"``.
        created_by: Actor who created this group.
        id: Optional ID override.

    Returns:
        The new ``GlossaryGroup``.
    """
    group_id = id or str(uuid.uuid4())
    query = sql.SQL(
        "INSERT INTO glossary_groups"
        " (id, project_id, scope, scope_id, canonical, definition, created_by)"
        " VALUES (%(id)s, %(project_id)s, %(scope)s, %(scope_id)s,"
        "  %(canonical)s, %(definition)s, %(created_by)s)"
        " RETURNING {returning}"
    ).format(returning=_GROUP_RETURNING)

    async with conn.cursor(row_factory=dict_row) as cur:
        await cur.execute(
            query,
            {
                "id": group_id,
                "project_id": project_id,
                "scope": scope,
                "scope_id": scope_id,
                "canonical": canonical,
                "definition": definition,
                "created_by": created_by,
            },
        )
        row = await cur.fetchone()
        assert row is not None
        return _row_to_group(row)


async def get_glossary_group(
    conn: AsyncConnection[Any],
    group_id: str,
    *,
    project_id: str | None = None,
) -> GlossaryGroup | None:
    """Fetch a glossary group by ID or hex prefix (≥8 chars).

    Returns ``None`` when nothing matches; raises
    :class:`AmbiguousIdError` when a prefix matches multiple groups.
    Pass *project_id* to scope prefix lookups.
    """
    resolved = await _resolve_group(conn, group_id, project_id=project_id)
    if resolved is None:
        return None
    query = sql.SQL("SELECT {columns} FROM glossary_groups WHERE id = %(id)s").format(
        columns=_GROUP_RETURNING
    )

    async with conn.cursor(row_factory=dict_row) as cur:
        await cur.execute(query, {"id": resolved})
        row = await cur.fetchone()
        return _row_to_group(row) if row else None


async def list_glossary_groups(
    conn: AsyncConnection[Any],
    project_id: str,
    *,
    needs_review: bool = False,
    limit: int = 100,
    offset: int = 0,
) -> list[GlossaryGroup]:
    """List glossary groups, optionally filtering to those needing review.

    ``needs_review=True`` returns groups that have pending terms.
    """
    if needs_review:
        query = sql.SQL(
            "SELECT DISTINCT {columns} FROM glossary_groups gg"
            " JOIN glossary_terms gt ON gt.group_id = gg.id"
            " WHERE gg.project_id = %(project_id)s AND gt.status = 'pending'"
            " ORDER BY gg.created_at DESC"
            " LIMIT %(limit)s OFFSET %(offset)s"
        ).format(
            columns=sql.SQL(", ").join(sql.SQL("gg.") + sql.Identifier(c) for c in _GROUP_COLUMNS)
        )
    else:
        query = sql.SQL(
            "SELECT {columns} FROM glossary_groups"
            " WHERE project_id = %(project_id)s"
            " ORDER BY canonical"
            " LIMIT %(limit)s OFFSET %(offset)s"
        ).format(columns=_GROUP_RETURNING)

    async with conn.cursor(row_factory=dict_row) as cur:
        await cur.execute(
            query,
            {
                "project_id": project_id,
                "limit": limit,
                "offset": offset,
            },
        )
        return [_row_to_group(row) for row in await cur.fetchall()]


# ── Terms ────────────────────────────────────────────────────────


async def create_glossary_term(
    conn: AsyncConnection[Any],
    *,
    group_id: str | None,
    surface: str,
    normalized: str,
    is_protected: bool = False,
    status: str = "pending",
    source_item_id: str | None = None,
    context_snippet: str | None = None,
    id: str | None = None,
) -> GlossaryTerm:
    """Create a glossary term (a surface form belonging to a group)."""
    term_id = id or str(uuid.uuid4())
    query = sql.SQL(
        "INSERT INTO glossary_terms"
        " (id, group_id, surface, normalized, is_protected, status,"
        "  source_item_id, context_snippet)"
        " VALUES (%(id)s, %(group_id)s, %(surface)s, %(normalized)s,"
        "  %(is_protected)s, %(status)s, %(source_item_id)s, %(context_snippet)s)"
        " RETURNING {returning}"
    ).format(returning=_TERM_RETURNING)

    async with conn.cursor(row_factory=dict_row) as cur:
        await cur.execute(
            query,
            {
                "id": term_id,
                "group_id": group_id,
                "surface": surface,
                "normalized": normalized,
                "is_protected": is_protected,
                "status": status,
                "source_item_id": source_item_id,
                "context_snippet": context_snippet,
            },
        )
        row = await cur.fetchone()
        assert row is not None
        return _row_to_term(row)


async def list_pending_terms(
    conn: AsyncConnection[Any],
    project_id: str,
    *,
    limit: int = 50,
) -> list[GlossaryTerm]:
    """List terms awaiting human curation.

    Includes both grouped pending terms (via group → project) and orphan
    pending terms (via source_item → project).
    """
    t_cols = sql.SQL(", ").join(sql.SQL("gt.") + sql.Identifier(c) for c in _TERM_COLUMNS)
    query = sql.SQL(
        "SELECT {columns} FROM glossary_terms gt"
        " LEFT JOIN glossary_groups gg ON gt.group_id = gg.id"
        " LEFT JOIN items i ON gt.source_item_id = i.id"
        " WHERE gt.status = 'pending'"
        "   AND (gg.project_id = %(project_id)s OR i.project_id = %(project_id)s)"
        " ORDER BY gt.created_at DESC"
        " LIMIT %(limit)s"
    ).format(columns=t_cols)

    async with conn.cursor(row_factory=dict_row) as cur:
        await cur.execute(query, {"project_id": project_id, "limit": limit})
        return [_row_to_term(row) for row in await cur.fetchall()]


# ── Curation actions ─────────────────────────────────────────────


async def approve_term(
    conn: AsyncConnection[Any],
    term_id: str,
    *,
    group_id: str,
    actor_id: str,
    as_canonical: bool = False,
) -> GlossaryTerm | None:
    """Approve a pending term into a group.

    Args:
        conn: Async psycopg connection.
        term_id: The term to approve.
        group_id: Target group.
        actor_id: Who approved.
        as_canonical: If ``True``, set status to ``"canonical"``
            (group should have at most one). Otherwise ``"alias"``.

    Returns:
        The updated term, or ``None`` if not found.
    """
    resolved_term = await _resolve_term(conn, term_id)
    if resolved_term is None:
        return None
    resolved_group = await _resolve_group(conn, group_id)
    if resolved_group is None:
        raise NotFoundError(f"Glossary group {group_id!r} not found")

    new_status = "canonical" if as_canonical else "alias"
    query = sql.SQL(
        "UPDATE glossary_terms SET"
        "  group_id = %(group_id)s,"
        "  status = %(status)s,"
        "  decided_by = %(actor_id)s,"
        "  decided_at = now()"
        " WHERE id = %(term_id)s"
        " RETURNING {returning}"
    ).format(returning=_TERM_RETURNING)

    async with conn.cursor(row_factory=dict_row) as cur:
        await cur.execute(
            query,
            {
                "term_id": resolved_term,
                "group_id": resolved_group,
                "status": new_status,
                "actor_id": actor_id,
            },
        )
        row = await cur.fetchone()
        return _row_to_term(row) if row else None


async def reject_term(
    conn: AsyncConnection[Any],
    term_id: str,
    *,
    actor_id: str,
    reason: str | None = None,
) -> GlossaryRejection | None:
    """Reject a term — the system will never re-propose this match.

    Sets the term's status to ``"rejected"`` and inserts a permanent
    record into ``glossary_rejections``.

    Returns:
        The rejection record, or ``None`` if the term was not found.
    """
    resolved = await _resolve_term(conn, term_id)
    if resolved is None:
        return None

    # Get term info for the rejection record
    async with conn.cursor(row_factory=dict_row) as cur:
        await cur.execute(
            "UPDATE glossary_terms SET"
            "  status = 'rejected', decided_by = %(actor)s, decided_at = now()"
            " WHERE id = %(id)s"
            " RETURNING group_id, surface",
            {"id": resolved, "actor": actor_id},
        )
        term_row = await cur.fetchone()
        if not term_row or not term_row["group_id"]:
            return None

        # Record permanent rejection
        await cur.execute(
            "INSERT INTO glossary_rejections (group_id, rejected_term, rejected_by, reason)"
            " VALUES (%(group_id)s, %(term)s, %(actor)s, %(reason)s)"
            " ON CONFLICT (group_id, rejected_term) DO NOTHING"
            " RETURNING rejected_at",
            {
                "group_id": term_row["group_id"],
                "term": term_row["surface"],
                "actor": actor_id,
                "reason": reason,
            },
        )
        rej_row = await cur.fetchone()
        if rej_row is None:
            # Conflict (already rejected) — fetch the existing timestamp.
            await cur.execute(
                "SELECT rejected_at FROM glossary_rejections"
                " WHERE group_id = %(group_id)s AND rejected_term = %(term)s",
                {"group_id": term_row["group_id"], "term": term_row["surface"]},
            )
            rej_row = await cur.fetchone()
            assert rej_row is not None

        return GlossaryRejection(
            group_id=term_row["group_id"],
            rejected_term=term_row["surface"],
            rejected_by=actor_id,
            rejected_at=rej_row["rejected_at"],
            reason=reason,
        )


async def merge_groups(
    conn: AsyncConnection[Any],
    source_group_id: str,
    target_group_id: str,
    *,
    actor_id: str,
) -> GlossaryGroup | None:
    """Merge source group into target — move all terms, delete source.

    Returns:
        The target ``GlossaryGroup`` after merge, or ``None`` if
        either group was not found.
    """
    resolved_source = await _resolve_group(conn, source_group_id)
    resolved_target = await _resolve_group(conn, target_group_id)
    if resolved_source is None or resolved_target is None:
        return None

    # Move all terms from source to target
    await conn.execute(
        "UPDATE glossary_terms SET group_id = %(target)s WHERE group_id = %(source)s",
        {"source": resolved_source, "target": resolved_target},
    )

    # Delete source group
    await conn.execute(
        "DELETE FROM glossary_groups WHERE id = %(id)s",
        {"id": resolved_source},
    )

    # Update review timestamp on target
    query = sql.SQL(
        "UPDATE glossary_groups SET"
        "  last_reviewed_at = now(), last_reviewed_by = %(actor)s"
        " WHERE id = %(id)s"
        " RETURNING {returning}"
    ).format(returning=_GROUP_RETURNING)

    async with conn.cursor(row_factory=dict_row) as cur:
        await cur.execute(query, {"id": resolved_target, "actor": actor_id})
        row = await cur.fetchone()
        return _row_to_group(row) if row else None


async def split_term(
    conn: AsyncConnection[Any],
    term_id: str,
    *,
    new_canonical: str,
    actor_id: str,
) -> GlossaryGroup | None:
    """Split a term out of its group into a new group.

    The term becomes the canonical member of the new group.

    Args:
        conn: Async psycopg connection.
        term_id: The term to split out.
        new_canonical: Canonical name for the new group.
        actor_id: Who performed the split.

    Returns:
        The new ``GlossaryGroup``, or ``None`` if the term was not found.
    """
    resolved = await _resolve_term(conn, term_id)
    if resolved is None:
        return None

    # Get term's current group to inherit project_id
    async with conn.cursor(row_factory=dict_row) as cur:
        await cur.execute(
            "SELECT gt.id, gg.project_id FROM glossary_terms gt"
            " JOIN glossary_groups gg ON gt.group_id = gg.id"
            " WHERE gt.id = %(id)s",
            {"id": resolved},
        )
        row = await cur.fetchone()
        if not row:
            return None
        project_id = row["project_id"]

    # Create new group
    new_group = await create_glossary_group(
        conn,
        project_id=project_id,
        canonical=new_canonical,
        created_by=actor_id,
    )

    # Move term to new group as canonical
    await conn.execute(
        "UPDATE glossary_terms SET"
        "  group_id = %(group_id)s,"
        "  status = 'canonical',"
        "  decided_by = %(actor)s,"
        "  decided_at = now()"
        " WHERE id = %(id)s",
        {"id": resolved, "group_id": new_group.id, "actor": actor_id},
    )

    return new_group


# ── Direct user-facing add / delete ──────────────────────────────


async def create_glossary_group_with_canonical(
    conn: AsyncConnection[Any],
    *,
    project_id: str,
    canonical: str,
    definition: str | None = None,
    created_by: str | None = None,
) -> tuple[GlossaryGroup, GlossaryTerm]:
    """Create a glossary group AND its canonical surface term in one shot.

    The CLI `lp glossary group create` flow assumes a group always has a
    canonical term — separating the two creation steps would let users
    leave the system in a broken intermediate state.

    Args:
        conn: Async psycopg connection.
        project_id: Owning project.
        canonical: Canonical surface form. Becomes both the group's
            ``canonical`` field and the surface of the seeded term.
        definition: Optional one-line definition stored on the group.
        created_by: Actor who created this.

    Returns:
        Tuple of (group, canonical_term).
    """
    group = await create_glossary_group(
        conn,
        project_id=project_id,
        canonical=canonical,
        definition=definition,
        created_by=created_by,
    )
    term = await create_glossary_term(
        conn,
        group_id=group.id,
        surface=canonical,
        normalized=canonical.lower(),
        status="canonical",
    )
    return group, term


async def add_term_to_group(
    conn: AsyncConnection[Any],
    group_id: str,
    *,
    surface: str,
    actor_id: str,
    as_canonical: bool = False,
) -> GlossaryTerm:
    """Add a new surface term to an existing group.

    Default status is ``alias``. When *as_canonical* is true the existing
    canonical (if any) is demoted to ``alias`` first — there is at most
    one canonical per group.

    Args:
        conn: Async psycopg connection.
        group_id: Target group (full UUID or ≥8 hex prefix).
        surface: New surface form. Stored verbatim; ``normalized`` is the
            lowercased copy.
        actor_id: Who added this term.
        as_canonical: Promote this term to canonical, demoting the
            current canonical to alias.

    Returns:
        The newly created ``GlossaryTerm``.

    Raises:
        NotFoundError: If the group does not exist.
    """
    resolved = await _resolve_group(conn, group_id)
    if resolved is None:
        raise NotFoundError(f"Glossary group {group_id!r} not found")

    if as_canonical:
        await conn.execute(
            "UPDATE glossary_terms SET"
            "  status = 'alias', decided_by = %(actor)s, decided_at = now()"
            " WHERE group_id = %(g)s AND status = 'canonical'",
            {"g": resolved, "actor": actor_id},
        )

    new_status = "canonical" if as_canonical else "alias"
    return await create_glossary_term(
        conn,
        group_id=resolved,
        surface=surface,
        normalized=surface.lower(),
        status=new_status,
    )


async def delete_glossary_term(
    conn: AsyncConnection[Any],
    term_id: str,
    *,
    actor_id: str,
) -> bool:
    """Permanently remove a glossary term.

    Cascade rule (option B): removing the last canonical/alias term in a
    group deletes the group as well, including any rejection records and
    any leftover pending/rejected terms in the same group. Removing the
    canonical while aliases still exist is refused — promote one alias to
    canonical first, or remove the aliases.

    Args:
        conn: Async psycopg connection.
        term_id: Term ID or hex prefix (≥8 chars).
        actor_id: Who is removing the term (audit trail).

    Returns:
        ``True`` if a term was removed, ``False`` if the term was not
        found.

    Raises:
        GlossaryGroupHasActiveTermsError: When removing the canonical
            would leave aliases without a canonical anchor.
    """
    del actor_id  # reserved for future audit fields
    resolved = await _resolve_term(conn, term_id)
    if resolved is None:
        return False

    async with conn.cursor(row_factory=dict_row) as cur:
        await cur.execute(
            "SELECT id, group_id, status FROM glossary_terms WHERE id = %(id)s",
            {"id": resolved},
        )
        term = await cur.fetchone()
    if term is None:
        return False

    group_id_val = term["group_id"]
    status = term["status"]

    if status == "canonical" and group_id_val is not None:
        async with conn.cursor(row_factory=dict_row) as cur:
            await cur.execute(
                "SELECT count(*) AS c FROM glossary_terms"
                " WHERE group_id = %(g)s"
                "   AND id <> %(id)s"
                "   AND status IN ('canonical', 'alias')",
                {"g": group_id_val, "id": resolved},
            )
            row = await cur.fetchone()
        active_siblings = int(row["c"]) if row else 0
        if active_siblings > 0:
            raise GlossaryGroupHasActiveTermsError(group_id_val, resolved)

        # Last active term in the group: cascade delete the whole group.
        await conn.execute(
            "DELETE FROM glossary_rejections WHERE group_id = %(g)s",
            {"g": group_id_val},
        )
        await conn.execute(
            "DELETE FROM glossary_terms WHERE group_id = %(g)s",
            {"g": group_id_val},
        )
        await conn.execute(
            "DELETE FROM glossary_groups WHERE id = %(g)s",
            {"g": group_id_val},
        )
        return True

    await conn.execute(
        "DELETE FROM glossary_terms WHERE id = %(id)s",
        {"id": resolved},
    )
    return True


# ── Query expansion ──────────────────────────────────────────────


async def fetch_glossary_map(
    conn: AsyncConnection[Any],
    words: list[str],
    project_id: str,
) -> dict[str, list[str]]:
    """Look up glossary aliases for *words* in a single project.

    Args:
        conn: Async psycopg connection.
        words: Lowercased words to look up.
        project_id: Project scope for glossary lookup.

    Returns:
        Mapping ``lowercased_word → [surface1, surface2, ...]``. Missing
        keys (no glossary hit) are simply absent from the mapping. Each
        value contains every approved surface in the matching group,
        including the lookup word itself.
    """
    if not words:
        return {}

    normalised = [w.lower() for w in words]
    async with conn.cursor(row_factory=dict_row) as cur:
        await cur.execute(
            "SELECT gt.normalized, gt.group_id"
            " FROM glossary_terms gt"
            " JOIN glossary_groups gg ON gt.group_id = gg.id"
            " WHERE gt.normalized = ANY(%(words)s)"
            "   AND gt.status IN ('canonical', 'alias')"
            "   AND gg.project_id = %(project_id)s",
            {"words": normalised, "project_id": project_id},
        )
        word_to_group: dict[str, str] = {}
        for row in await cur.fetchall():
            word_to_group[row["normalized"]] = row["group_id"]

    if not word_to_group:
        return {}

    group_ids = list(set(word_to_group.values()))
    group_surfaces: dict[str, list[str]] = {}
    async with conn.cursor(row_factory=dict_row) as cur:
        await cur.execute(
            "SELECT group_id, surface FROM glossary_terms"
            " WHERE group_id = ANY(%(ids)s)"
            "   AND status IN ('canonical', 'alias')",
            {"ids": group_ids},
        )
        for row in await cur.fetchall():
            group_surfaces.setdefault(row["group_id"], []).append(row["surface"])

    return {word: group_surfaces.get(gid, []) for word, gid in word_to_group.items()}


async def expand_query(
    conn: AsyncConnection[Any],
    query: str,
    project_id: str,
) -> str:
    """Expand a search query using the glossary (legacy, plain-word only).

    Each whitespace-delimited word in *query* is looked up; approved
    aliases are OR'd, groups are AND'd. This helper predates the
    web-search-style query dialect and does not understand phrases,
    negations, or ``OR`` keywords — pipeline callers should parse with
    :func:`luplo.core.search.tsquery.parse_user_query` and consult
    :func:`fetch_glossary_map` directly. Kept for backwards compatibility
    with any external caller.

    Example::

        >>> await expand_query(conn, "vendor budget", "proj-1")
        "(vendor | shop | NPC벤더) & budget"
    """
    words = query.strip().split()
    if not words:
        return ""

    normalised = [w.lower() for w in words]

    async with conn.cursor(row_factory=dict_row) as cur:
        await cur.execute(
            "SELECT gt.normalized, gt.group_id"
            " FROM glossary_terms gt"
            " JOIN glossary_groups gg ON gt.group_id = gg.id"
            " WHERE gt.normalized = ANY(%(words)s)"
            "   AND gt.status IN ('canonical', 'alias')"
            "   AND gg.project_id = %(project_id)s",
            {"words": normalised, "project_id": project_id},
        )
        word_to_group: dict[str, str] = {}
        for row in await cur.fetchall():
            word_to_group[row["normalized"]] = row["group_id"]

    group_ids = list(set(word_to_group.values()))

    group_surfaces: dict[str, list[str]] = {}
    if group_ids:
        async with conn.cursor(row_factory=dict_row) as cur:
            await cur.execute(
                "SELECT group_id, surface FROM glossary_terms"
                " WHERE group_id = ANY(%(ids)s)"
                "   AND status IN ('canonical', 'alias')",
                {"ids": group_ids},
            )
            for row in await cur.fetchall():
                group_surfaces.setdefault(row["group_id"], []).append(row["surface"])

    parts: list[str] = []
    for word, norm in zip(words, normalised, strict=True):
        gid = word_to_group.get(norm)
        if gid and gid in group_surfaces:
            surfaces = group_surfaces[gid]
            if len(surfaces) > 1:
                parts.append("(" + " | ".join(sorted(surfaces)) + ")")
            else:
                parts.append(surfaces[0])
        else:
            parts.append(word)

    return " & ".join(parts)
