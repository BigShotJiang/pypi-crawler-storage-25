"""luplo CLI — ``lp`` command-line interface.

All commands delegate to ``LocalBackend``.  Async core functions are
bridged via ``asyncio.run()``.  Configuration is loaded from ``.luplo``
file → env vars → CLI flags (highest priority wins).
"""

from __future__ import annotations

import asyncio
import os
import subprocess
import uuid
from collections.abc import AsyncIterator, Coroutine
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

import typer

from luplo.config import CONFIG_FILENAME, load_config, write_config
from luplo.core.backend.local import LocalBackend
from luplo.core.db import close_pool, create_pool
from luplo.core.impact import ImpactNode, ImpactResult
from luplo.core.models import Item, ItemCreate

app = typer.Typer(
    name="lp",
    help="luplo — long-term memory for engineering decisions.",
    no_args_is_help=True,
)

items_app = typer.Typer(name="items", help="Manage items (decisions, knowledge, policies).")
work_app = typer.Typer(name="work", help="Manage work units.")
systems_app = typer.Typer(name="systems", help="Manage systems.")
glossary_app = typer.Typer(name="glossary", help="Manage the glossary.")
glossary_group_app = typer.Typer(name="group", help="Manage glossary groups.")
glossary_term_app = typer.Typer(name="term", help="Manage glossary terms.")
task_app = typer.Typer(name="task", help="Manage tasks (item_type='task').")
qa_app = typer.Typer(name="qa", help="Manage QA checks (item_type='qa_check').")

app.add_typer(items_app)
app.add_typer(work_app)
app.add_typer(systems_app)
app.add_typer(glossary_app)
glossary_app.add_typer(glossary_group_app)
glossary_app.add_typer(glossary_term_app)
app.add_typer(task_app)
app.add_typer(qa_app)


# ── Config helpers ───────────────────────────────────────────────


def _cfg_project(flag: str | None = None) -> str:
    """Resolve project ID from flag → env → .luplo."""
    if flag:
        return flag
    cfg = load_config()
    if cfg.project_id:
        return cfg.project_id
    typer.echo("Error: no project. Use --project, LUPLO_PROJECT, or run 'lp init'.", err=True)
    raise typer.Exit(1)


def _cfg_actor(flag: str | None = None) -> str:
    """Resolve actor ID from flag → env → .luplo."""
    if flag:
        return flag
    cfg = load_config()
    if cfg.actor_id:
        return cfg.actor_id
    typer.echo("Error: no actor. Use --actor, LUPLO_ACTOR_ID, or run 'lp init'.", err=True)
    raise typer.Exit(1)


def _cfg_db_url() -> str:
    """Resolve DB URL from env → .luplo."""
    cfg = load_config()
    return cfg.db_url


# ── Backend lifecycle ────────────────────────────────────────────


@asynccontextmanager
async def _backend() -> AsyncIterator[LocalBackend]:
    """Create a LocalBackend with a connection pool, yield it, then clean up."""
    db_url = _cfg_db_url()
    pool = await create_pool(db_url)
    try:
        yield LocalBackend(pool)
    finally:
        await close_pool(pool)


def _run[T](coro: Coroutine[Any, Any, T]) -> T:
    """Run a coroutine; translate domain errors to CLI exit codes."""
    from luplo.core.errors import (
        AmbiguousIdError,
        ConflictError,
        IdTooShortError,
        InvalidIdFormatError,
        NotFoundError,
    )

    try:
        return asyncio.run(coro)
    except AmbiguousIdError as exc:
        # Listed before ConflictError because AmbiguousIdError prints
        # extra match lines.
        typer.echo(f"Error: {exc.message}", err=True)
        for mid, label in exc.matches:
            typer.echo(f"  - {mid[:12]}  {label}", err=True)
        raise typer.Exit(2) from exc
    except IdTooShortError as exc:
        typer.echo(f"Error: {exc.message}", err=True)
        raise typer.Exit(2) from exc
    except InvalidIdFormatError as exc:
        typer.echo(f"Error: {exc.message}", err=True)
        raise typer.Exit(2) from exc
    except NotFoundError as exc:
        typer.echo(f"Error: {exc.message}", err=True)
        raise typer.Exit(1) from exc
    except ConflictError as exc:
        # Catches TaskStateTransitionError, QAStateTransitionError,
        # TaskAlreadyInProgressError, WorkUnitHasActiveTasksError, etc.
        typer.echo(f"Error: {exc.message}", err=True)
        raise typer.Exit(2) from exc


# ── Init ─────────────────────────────────────────────────────────


@app.command("init")
def init(
    project: str = typer.Option(
        ...,
        "--project",
        "-p",
        help="Project ID (e.g. 'hearthward'). Stored in .luplo and created in DB.",
    ),
    email: str = typer.Option(
        ...,
        "--email",
        "-e",
        help="Your email (required — primary identifier after v0.5.1).",
    ),
    project_name: str | None = typer.Option(
        None,
        "--project-name",
        help="Human-readable project name. Defaults to project ID.",
    ),
    actor_name: str | None = typer.Option(
        None,
        "--name",
        help="Your display name. Defaults to the local-part of email.",
    ),
    actor_id: str | None = typer.Option(
        None,
        "--actor-id",
        help="Explicit actor UUID. Auto-generated (uuid4) if omitted.",
    ),
    db_url: str = typer.Option(
        "postgresql://localhost/luplo",
        "--db-url",
        help="PostgreSQL connection string.",
        envvar="LUPLO_DB_URL",
    ),
    server_url: str = typer.Option(
        "",
        "--server-url",
        help="Optional remote server URL (for `lp login`).",
        envvar="LUPLO_SERVER_URL",
    ),
) -> None:
    """Initialise luplo in the current directory.

    Creates a .luplo config file, runs database migrations, and seeds the
    project and actor. After init, all other commands read from .luplo
    automatically.

    \b
    Examples:
        lp init -p hearthward -e me@example.com
        lp init -p hearthward -e me@example.com --name "Ryan"
        lp init -p myapp -e me@example.com --db-url postgresql://...
    """
    p_name = project_name or project
    a_name = actor_name or email.split("@", 1)[0]
    a_id = actor_id or str(uuid.uuid4())
    config_path = Path.cwd() / CONFIG_FILENAME

    write_config(
        config_path,
        db_url=db_url,
        project_id=project,
        project_name=p_name,
        actor_id=a_id,
        actor_name=a_name,
        actor_email=email,
        server_url=server_url,
    )
    typer.echo(f"Created {CONFIG_FILENAME}")

    typer.echo("Running migrations...")
    project_root = Path(__file__).resolve().parent.parent.parent
    alembic_ini = project_root / "alembic.ini"
    env = {**os.environ, "LUPLO_DB_URL": db_url}

    if alembic_ini.exists():
        result = subprocess.run(
            ["alembic", "upgrade", "head"],
            cwd=str(project_root),
            env=env,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            typer.echo(f"Migration failed: {result.stderr}", err=True)
            raise typer.Exit(1)
        typer.echo("Migrations up to date.")
    else:
        typer.echo("Warning: alembic.ini not found, skipping migrations.", err=True)

    async def _seed() -> None:
        pool = await create_pool(db_url)
        try:
            async with pool.connection() as conn:
                await conn.execute(
                    "INSERT INTO projects (id, name) VALUES (%s, %s) ON CONFLICT (id) DO NOTHING",
                    (project, p_name),
                )
                await conn.execute(
                    "INSERT INTO actors (id, name, email) VALUES (%s, %s, %s)"
                    " ON CONFLICT (id) DO NOTHING",
                    (a_id, a_name, email),
                )
        finally:
            await close_pool(pool)

    _run(_seed())
    typer.echo(f"Project '{p_name}' ({project}) ready.")
    typer.echo(f"Actor '{a_name}' ({a_id[:8]}…) <{email}> ready.")

    gitignore = Path.cwd() / ".gitignore"
    if gitignore.exists():
        content = gitignore.read_text()
        if CONFIG_FILENAME not in content:
            with open(gitignore, "a") as f:
                f.write(f"\n# luplo local config (contains DB credentials)\n{CONFIG_FILENAME}\n")
            typer.echo(f"Added {CONFIG_FILENAME} to .gitignore")
    else:
        gitignore.write_text(
            f"# luplo local config (contains DB credentials)\n{CONFIG_FILENAME}\n"
        )
        typer.echo(f"Created .gitignore with {CONFIG_FILENAME}")

    typer.echo("")
    typer.echo("Done! Try:")
    typer.echo('  lp items add "Your first decision"')
    typer.echo("  lp items list")
    typer.echo("  lp brief")


# ── Items ────────────────────────────────────────────────────────


@items_app.command("add")
def items_add(
    title: str = typer.Argument(..., help="Item title."),
    item_type: str = typer.Option("decision", "--type", "-t", help="Item type."),
    body: str | None = typer.Option(None, "--body", "-b", help="Item body."),
    rationale: str | None = typer.Option(None, "--rationale", "-r"),
    system: list[str] | None = typer.Option(None, "--system", "-s"),
    work_unit: str | None = typer.Option(
        None,
        "--wu",
        "-w",
        help="Attach this item to a work unit (full UUID).",
    ),
    project: str | None = typer.Option(None, "--project", "-p", envvar="LUPLO_PROJECT"),
    actor: str | None = typer.Option(None, "--actor", "-a", envvar="LUPLO_ACTOR_ID"),
) -> None:
    """Add a new item."""
    pid = _cfg_project(project)
    aid = _cfg_actor(actor)

    async def _do() -> None:
        async with _backend() as b:
            item = await b.create_item(
                ItemCreate(
                    project_id=pid,
                    actor_id=aid,
                    item_type=item_type,
                    title=title,
                    body=body,
                    rationale=rationale,
                    system_ids=system or [],
                    work_unit_id=work_unit,
                )
            )
            typer.echo(f"Created {item.item_type} [{item.id[:8]}] {item.title}")

    _run(_do())


@items_app.command("show")
def items_show(
    item_id: str = typer.Argument(
        ...,
        help="Full UUID or 8-char+ hex prefix. Ambiguous prefixes error out.",
    ),
) -> None:
    """Show a single item."""

    async def _do() -> None:
        pid = _cfg_project(None)
        async with _backend() as b:
            item = await b.get_item(item_id, project_id=pid)
            if not item:
                typer.echo(f"Item {item_id} not found.", err=True)
                raise typer.Exit(1)
            typer.echo(f"[{item.id[:8]}] {item.title}")
            typer.echo(f"  type: {item.item_type}")
            typer.echo(f"  systems: {', '.join(item.system_ids) or '—'}")
            typer.echo(f"  created: {item.created_at:%Y-%m-%d %H:%M}")
            if item.body:
                typer.echo(f"  body: {item.body[:200]}")
            if item.rationale:
                typer.echo(f"  rationale: {item.rationale[:200]}")
            if item.supersedes_id:
                typer.echo(f"  supersedes: {item.supersedes_id[:8]}")

    _run(_do())


@items_app.command("list")
def items_list(
    project: str | None = typer.Option(None, "--project", "-p", envvar="LUPLO_PROJECT"),
    item_type: str | None = typer.Option(None, "--type", "-t"),
    system: str | None = typer.Option(None, "--system", "-s"),
    work_unit: str | None = typer.Option(
        None,
        "--wu",
        "-w",
        help="Filter to items attached to this work unit (full UUID).",
    ),
    limit: int = typer.Option(20, "--limit", "-n"),
) -> None:
    """List items for a project."""
    pid = _cfg_project(project)

    async def _do() -> None:
        async with _backend() as b:
            results = await b.list_items(
                pid,
                item_type=item_type,
                system_id=system,
                work_unit_id=work_unit,
                limit=limit,
            )
            if not results:
                typer.echo("No items found.")
                return
            for item in results:
                systems = f" [{','.join(item.system_ids)}]" if item.system_ids else ""
                typer.echo(f"  {item.id[:8]}  {item.item_type:<12} {item.title}{systems}")

    _run(_do())


@items_app.command("search")
def items_search(
    query: str = typer.Argument(..., help="Search query."),
    project: str | None = typer.Option(None, "--project", "-p", envvar="LUPLO_PROJECT"),
    limit: int = typer.Option(10, "--limit", "-n"),
) -> None:
    """Search items using glossary-expanded tsquery."""
    pid = _cfg_project(project)

    async def _do() -> None:
        async with _backend() as b:
            results = await b.search(query, pid, limit=limit)
            if not results:
                typer.echo("No results.")
                return
            for r in results:
                score = f"{r.score:.3f}"
                typer.echo(f"  {score}  {r.item.id[:8]}  {r.item.title}")
                if r.snippet and r.snippet != r.item.title:
                    typer.echo(f"         {r.snippet[:100]}")

    _run(_do())


# ── Work Units ───────────────────────────────────────────────────


@work_app.command("open")
def work_open(
    title: str = typer.Argument(..., help="Work unit title."),
    description: str | None = typer.Option(None, "--desc", "-d"),
    system: list[str] | None = typer.Option(None, "--system", "-s"),
    project: str | None = typer.Option(None, "--project", "-p", envvar="LUPLO_PROJECT"),
    actor: str | None = typer.Option(None, "--actor", "-a", envvar="LUPLO_ACTOR_ID"),
) -> None:
    """Open a new work unit."""
    import uuid

    pid = _cfg_project(project)
    aid = _cfg_actor(actor)

    async def _do() -> None:
        async with _backend() as b:
            wu = await b.open_work_unit(
                id=str(uuid.uuid4()),
                project_id=pid,
                title=title,
                description=description,
                system_ids=system,
                created_by=aid,
            )
            typer.echo(f"Opened work unit [{wu.id[:8]}] {wu.title}")

    _run(_do())


@work_app.command("ls")
def work_ls(
    status: str | None = typer.Option(
        None,
        "--status",
        "-s",
        help="Filter by status (in_progress | done | abandoned). Default: all.",
    ),
    project: str | None = typer.Option(None, "--project", "-p", envvar="LUPLO_PROJECT"),
) -> None:
    """List work units for a project, ordered by created_at DESC."""
    pid = _cfg_project(project)

    async def _do() -> None:
        async with _backend() as b:
            results = await b.list_work_units(pid, status=status)
            if not results:
                typer.echo("No work units.")
                return
            for wu in results:
                systems = f" [{','.join(wu.system_ids)}]" if wu.system_ids else ""
                typer.echo(
                    f"  {wu.id[:8]}  [{wu.status:<11}] {wu.title}{systems}"
                    f"  ({wu.created_at:%Y-%m-%d})"
                )

    _run(_do())


@work_app.command("resume")
def work_resume(
    query: str = typer.Argument(..., help="Title keyword to search."),
    project: str | None = typer.Option(None, "--project", "-p", envvar="LUPLO_PROJECT"),
) -> None:
    """Find in-progress work units by title."""
    from luplo.core.work_units import find_work_units

    pid = _cfg_project(project)

    async def _do() -> None:
        async with _backend() as b:
            async with b.pool.connection() as conn:
                results = await find_work_units(conn, pid, query)
            if not results:
                typer.echo("No matching work units in progress.")
                return
            for wu in results:
                systems = f" [{','.join(wu.system_ids)}]" if wu.system_ids else ""
                typer.echo(f"  {wu.id[:8]}  {wu.title}{systems}  ({wu.created_at:%Y-%m-%d})")

    _run(_do())


@work_app.command("close")
def work_close(
    work_id: str = typer.Argument(..., help="Work unit ID."),
    status: str = typer.Option("done", "--status", help="done or abandoned."),
    force: bool = typer.Option(
        False, "--force", "-f", help="Close even if an in_progress task remains."
    ),
    actor: str | None = typer.Option(None, "--actor", "-a", envvar="LUPLO_ACTOR_ID"),
) -> None:
    """Close a work unit. Refuses if an in_progress task remains (use --force)."""
    aid = _cfg_actor(actor)

    async def _do() -> None:
        async with _backend() as b:
            result = await b.close_work_unit(work_id, actor_id=aid, force=force)
            if result:
                typer.echo(f"Closed [{result.id[:8]}] {result.title} -> {result.status}")
            else:
                typer.echo("Work unit not found or already closed.", err=True)
                raise typer.Exit(1)

    _run(_do())


# ── Systems ──────────────────────────────────────────────────────


@systems_app.command("add")
def systems_add(
    name: str = typer.Argument(..., help="System name."),
    description: str | None = typer.Option(None, "--desc", "-d"),
    depends: list[str] | None = typer.Option(None, "--depends"),
    project: str | None = typer.Option(None, "--project", "-p", envvar="LUPLO_PROJECT"),
) -> None:
    """Add a new system."""
    import uuid

    pid = _cfg_project(project)

    async def _do() -> None:
        async with _backend() as b:
            s = await b.create_system(
                id=str(uuid.uuid4()),
                project_id=pid,
                name=name,
                description=description,
                depends_on_system_ids=depends,
            )
            typer.echo(f"Created system [{s.id[:8]}] {s.name}")

    _run(_do())


@systems_app.command("list")
def systems_list(
    project: str | None = typer.Option(None, "--project", "-p", envvar="LUPLO_PROJECT"),
) -> None:
    """List all systems for a project."""
    pid = _cfg_project(project)

    async def _do() -> None:
        async with _backend() as b:
            results = await b.list_systems(pid)
            if not results:
                typer.echo("No systems.")
                return
            for s in results:
                deps = (
                    f" -> {','.join(s.depends_on_system_ids)}" if s.depends_on_system_ids else ""
                )
                typer.echo(f"  {s.id[:8]}  {s.name}{deps}")

    _run(_do())


# ── Glossary ─────────────────────────────────────────────────────


@glossary_app.command("ls")
def glossary_ls(
    project: str | None = typer.Option(None, "--project", "-p", envvar="LUPLO_PROJECT"),
    limit: int = typer.Option(50, "--limit", "-n"),
) -> None:
    """List glossary groups."""
    pid = _cfg_project(project)

    async def _do() -> None:
        async with _backend() as b:
            groups = await b.list_glossary_groups(pid, limit=limit)
            if not groups:
                typer.echo("No glossary groups.")
                return
            for g in groups:
                defn = f" — {g.definition}" if g.definition else ""
                typer.echo(f"  {g.id[:8]}  {g.canonical}{defn}")

    _run(_do())


@glossary_app.command("pending")
def glossary_pending(
    project: str | None = typer.Option(None, "--project", "-p", envvar="LUPLO_PROJECT"),
    limit: int = typer.Option(20, "--limit", "-n"),
) -> None:
    """Show terms awaiting curation."""
    pid = _cfg_project(project)

    async def _do() -> None:
        async with _backend() as b:
            terms = await b.list_pending_terms(pid, limit=limit)
            if not terms:
                typer.echo("No pending terms.")
                return
            for t in terms:
                group = t.group_id[:8] if t.group_id else "orphan"
                typer.echo(f'  {t.id[:8]}  "{t.surface}" -> group:{group}')
                if t.context_snippet:
                    typer.echo(f"           ctx: {t.context_snippet[:80]}")

    _run(_do())


@glossary_app.command("approve")
def glossary_approve(
    term_id: str = typer.Argument(..., help="Term ID to approve."),
    group_id: str = typer.Option(..., "--group", "-g", help="Target group ID."),
    canonical: bool = typer.Option(False, "--canonical", "-c", help="Set as canonical."),
    actor: str | None = typer.Option(None, "--actor", "-a", envvar="LUPLO_ACTOR_ID"),
) -> None:
    """Approve a pending term into a group."""
    aid = _cfg_actor(actor)

    async def _do() -> None:
        async with _backend() as b:
            t = await b.approve_term(
                term_id,
                group_id=group_id,
                actor_id=aid,
                as_canonical=canonical,
            )
            if t:
                typer.echo(f'Approved "{t.surface}" as {t.status}')
            else:
                typer.echo("Term not found.", err=True)

    _run(_do())


@glossary_app.command("reject")
def glossary_reject(
    term_id: str = typer.Argument(..., help="Term ID to reject."),
    reason: str | None = typer.Option(None, "--reason", "-r"),
    actor: str | None = typer.Option(None, "--actor", "-a", envvar="LUPLO_ACTOR_ID"),
) -> None:
    """Reject a term permanently."""
    aid = _cfg_actor(actor)

    async def _do() -> None:
        async with _backend() as b:
            r = await b.reject_term(term_id, actor_id=aid, reason=reason)
            if r:
                typer.echo(f'Rejected "{r.rejected_term}"')
            else:
                typer.echo("Term not found.", err=True)

    _run(_do())


@glossary_group_app.command("create")
def glossary_group_create(
    canonical: str = typer.Argument(..., help="Canonical surface form for the new group."),
    definition: str | None = typer.Option(
        None, "--def", "-d", help="One-line definition stored on the group."
    ),
    project: str | None = typer.Option(None, "--project", "-p", envvar="LUPLO_PROJECT"),
    actor: str | None = typer.Option(None, "--actor", "-a", envvar="LUPLO_ACTOR_ID"),
) -> None:
    """Create a glossary group plus its canonical surface term."""
    pid = _cfg_project(project)
    aid = _cfg_actor(actor)

    async def _do() -> None:
        async with _backend() as b:
            group, term = await b.create_glossary_group_with_canonical(
                project_id=pid,
                canonical=canonical,
                definition=definition,
                actor_id=aid,
            )
            typer.echo(
                f"Created group [{group.id[:8]}] {group.canonical}"
                f" with canonical term [{term.id[:8]}]"
            )

    _run(_do())


@glossary_app.command("add")
def glossary_add(
    surface: str = typer.Argument(..., help="New surface form to add to a group."),
    group: str = typer.Option(
        ...,
        "--group",
        "-g",
        help="Target group ID (full UUID or ≥8-char hex prefix).",
    ),
    canonical: bool = typer.Option(
        False,
        "--canonical",
        "-c",
        help="Promote this term to canonical, demoting any existing canonical to alias.",
    ),
    actor: str | None = typer.Option(None, "--actor", "-a", envvar="LUPLO_ACTOR_ID"),
) -> None:
    """Add a new alias (or canonical) term to an existing group."""
    aid = _cfg_actor(actor)

    async def _do() -> None:
        async with _backend() as b:
            term = await b.add_term_to_group(
                group,
                surface=surface,
                actor_id=aid,
                as_canonical=canonical,
            )
            group_label = term.group_id[:8] if term.group_id else "—"
            typer.echo(
                f'Added [{term.id[:8]}] "{term.surface}" -> group:{group_label} ({term.status})'
            )

    _run(_do())


@glossary_term_app.command("rm")
def glossary_term_rm(
    term_id: str = typer.Argument(..., help="Term ID (full UUID or ≥8-char hex prefix)."),
    actor: str | None = typer.Option(None, "--actor", "-a", envvar="LUPLO_ACTOR_ID"),
) -> None:
    """Permanently remove a glossary term.

    Removing the last canonical/alias term in a group cascades — the
    group (plus its rejection records) is dropped as well. Removing the
    canonical while aliases remain is refused; promote one alias first.
    """
    aid = _cfg_actor(actor)

    async def _do() -> None:
        async with _backend() as b:
            removed = await b.delete_glossary_term(term_id, actor_id=aid)
            if removed:
                typer.echo(f"Removed term {term_id}")
            else:
                typer.echo(f"Term {term_id} not found.", err=True)
                raise typer.Exit(1)

    _run(_do())


# ── Brief ────────────────────────────────────────────────────────


@app.command("brief")
def brief(
    project: str | None = typer.Option(None, "--project", "-p", envvar="LUPLO_PROJECT"),
    system: str | None = typer.Option(None, "--system", "-s"),
) -> None:
    """Get a project brief — active work + recent decisions."""
    pid = _cfg_project(project)

    async def _do() -> None:
        async with _backend() as b:
            active = await b.list_work_units(pid, status="in_progress")
            if active:
                typer.echo("Active work units:")
                for wu in active:
                    systems = f" [{','.join(wu.system_ids)}]" if wu.system_ids else ""
                    typer.echo(f"  {wu.id[:8]}  {wu.title}{systems}")
            else:
                typer.echo("No active work units.")

            typer.echo("")

            recent = await b.list_items(pid, system_id=system, limit=10)
            if recent:
                typer.echo("Recent items:")
                for item in recent:
                    typer.echo(f"  {item.id[:8]}  {item.item_type:<12} {item.title}")
            else:
                typer.echo("No items yet.")

    _run(_do())


# ── Impact ───────────────────────────────────────────────────────


def _render_impact_tree(result: ImpactResult) -> str:
    """Render an ImpactResult as a connected tree of box-drawing characters."""
    children: dict[str, list[ImpactNode]] = {}
    for node in result.nodes:
        children.setdefault(node.via.parent_id, []).append(node)

    lines: list[str] = [f"[{result.root.id[:8]}] {result.root.title}"]

    def _walk(parent_id: str, prefix: str) -> None:
        siblings = children.get(parent_id, [])
        for i, node in enumerate(siblings):
            is_last = i == len(siblings) - 1
            branch = "└── " if is_last else "├── "
            lines.append(
                f"{prefix}{branch}[{node.item.id[:8]}] ({node.via.link_type}) {node.item.title}"
            )
            extension = "    " if is_last else "│   "
            _walk(node.item.id, prefix + extension)

    _walk(result.root.id, "")
    return "\n".join(lines)


def _render_impact_flat(result: ImpactResult) -> str:
    lines: list[str] = [f"[{result.root.id[:8]}] {result.root.title}"]
    for node in result.nodes:
        indent = "  " * node.depth
        lines.append(
            f"{indent}[{node.item.id[:8]}] ({node.via.link_type}) "
            f"{node.item.title}  (depth={node.depth})"
        )
    return "\n".join(lines)


def _render_impact_json(result: ImpactResult) -> str:
    import dataclasses
    import json

    return json.dumps(dataclasses.asdict(result), indent=2, default=str)


@app.command("impact")
def impact_cmd(
    item_id: str = typer.Argument(
        ...,
        help="Root item (full UUID or 8+ char hex prefix).",
    ),
    depth: int = typer.Option(
        5,
        "--depth",
        "-d",
        min=1,
        max=5,
        help="Maximum traversal depth (1-5, capped at 5 server-side).",
    ),
    output_format: str = typer.Option(
        "tree",
        "--format",
        "-f",
        help="Output format: tree | flat | json.",
    ),
    project: str | None = typer.Option(None, "--project", "-p", envvar="LUPLO_PROJECT"),
) -> None:
    """Traverse typed edges to find an item's blast radius.

    Walks outgoing ``depends`` / ``blocks`` / ``supersedes`` / ``conflicts``
    edges up to the given depth and prints every item reachable from the
    root. Cycles are broken automatically; each item appears once, at its
    shortest-path depth.

    \b
    Examples:
        lp impact 5d4b04c4
        lp impact 5d4b04c4 --depth 2
        lp impact 5d4b04c4 --format json
    """
    from luplo.core.errors import NotFoundError, ValidationError

    if output_format not in {"tree", "flat", "json"}:
        typer.echo(f"Error: unknown --format {output_format!r}.", err=True)
        raise typer.Exit(2)

    pid = _cfg_project(project)

    async def _do() -> None:
        async with _backend() as b:
            try:
                result = await b.impact(item_id, pid, depth=depth)
            except NotFoundError as exc:
                typer.echo(f"Error: {exc.message}", err=True)
                raise typer.Exit(1) from exc
            except ValidationError as exc:
                typer.echo(f"Error: {exc.message}", err=True)
                raise typer.Exit(2) from exc

        if output_format == "json":
            typer.echo(_render_impact_json(result))
        elif output_format == "flat":
            typer.echo(_render_impact_flat(result))
        else:
            typer.echo(_render_impact_tree(result))

        if not result.nodes:
            typer.echo(
                f"\nNo impact edges from [{result.root.id[:8]}] at depth ≤ {depth}.",
                err=True,
            )

    _run(_do())


# ── Checks (rule pack) ───────────────────────────────────────────


@app.command("check")
def check_cmd(
    rule: list[str] = typer.Option(
        [],
        "--rule",
        "-r",
        help="Run only these rules (by name). Repeat for multiple. Default: all enabled.",
    ),
    severity: str = typer.Option(
        "warn",
        "--severity",
        "-s",
        help="Show findings at or above this severity. One of: error, warn, info.",
    ),
    list_rules: bool = typer.Option(
        False, "--list", help="Print every registered rule and its default severity, then exit."
    ),
    project: str | None = typer.Option(None, "--project", "-p", envvar="LUPLO_PROJECT"),
) -> None:
    """Run the deterministic rule pack and report findings.

    Exits non-zero if any finding has severity=error. Rules disabled in
    ``.luplo [checks] disabled_rules`` are skipped regardless of
    ``--rule``.

    \b
    Examples:
        lp check
        lp check --rule missing_rationale --rule dangling_edge
        lp check --severity error
        lp check --list
    """
    from luplo.core.checks import RULES
    from luplo.core.errors import ValidationError

    if list_rules:
        for name, r in RULES.items():
            typer.echo(f"  {name:<22} [{r.default_severity}] {r.description}")
        return

    severity_order = {"info": 0, "warn": 1, "error": 2}
    if severity not in severity_order:
        typer.echo(
            f"Error: --severity must be one of: error, warn, info (got {severity!r})", err=True
        )
        raise typer.Exit(2)

    pid = _cfg_project(project)
    cfg = load_config()

    async def _do() -> None:
        async with _backend() as b:
            try:
                findings = await b.run_checks(
                    pid,
                    rule_names=rule or None,
                    disabled=cfg.disabled_checks,
                )
            except ValidationError as exc:
                typer.echo(f"Error: {exc.message}", err=True)
                raise typer.Exit(2) from exc

        threshold = severity_order[severity]
        shown = [f for f in findings if severity_order[f.severity] >= threshold]

        if not shown:
            typer.echo(f"No findings at severity ≥ {severity}.")
            return

        typer.echo(f"{len(shown)} finding(s):")
        for f in shown:
            target = f" [{f.item_id[:8]}]" if f.item_id else ""
            typer.echo(f"  [{f.severity:<5}] {f.rule_name}{target}  {f.message}")

        if any(f.severity == "error" for f in findings):
            raise typer.Exit(1)

    _run(_do())


# ── Worker ───────────────────────────────────────────────────────


@app.command("worker")
def worker_start() -> None:
    """Start the background worker (sync jobs + glossary processing)."""
    from luplo.core.worker import run_worker

    async def _do() -> None:
        db_url = _cfg_db_url()
        pool = await create_pool(db_url)
        try:
            typer.echo("Worker running. Ctrl+C to stop.")
            await run_worker(pool)
        except KeyboardInterrupt:
            pass
        finally:
            await close_pool(pool)

    _run(_do())


# ── Tasks ────────────────────────────────────────────────────────


def _print_task(item: Item) -> None:
    """Compact one-liner for a task item."""
    status = item.context.get("status", "?")
    sort_order = item.context.get("sort_order", "?")
    typer.echo(f"  {item.id[:8]}  [{status:<11}] (#{sort_order:>3}) {item.title}")


@task_app.command("add")
def task_add(
    title: str = typer.Argument(..., help="Task title."),
    work_unit: str = typer.Option(
        ...,
        "--wu",
        "-w",
        help="Work unit full UUID or 8-char+ hex prefix.",
    ),
    body: str | None = typer.Option(None, "--body", "-b"),
    system: list[str] | None = typer.Option(None, "--system", "-s"),
    sort_order: int | None = typer.Option(None, "--sort"),
    project: str | None = typer.Option(None, "--project", "-p", envvar="LUPLO_PROJECT"),
    actor: str | None = typer.Option(None, "--actor", "-a", envvar="LUPLO_ACTOR_ID"),
) -> None:
    """Add a new task in 'proposed' status."""
    pid = _cfg_project(project)
    aid = _cfg_actor(actor)

    async def _do() -> None:
        async with _backend() as b:
            t = await b.create_task(
                project_id=pid,
                work_unit_id=work_unit,
                title=title,
                actor_id=aid,
                sort_order=sort_order,
                systems=system,
                body=body,
            )
            _print_task(t)

    _run(_do())


@task_app.command("ls")
def task_ls(
    work_unit: str = typer.Option(..., "--wu", "-w"),
    status: str | None = typer.Option(None, "--status", "-s"),
) -> None:
    """List tasks (chain heads) for a work unit, ordered by sort_order."""

    async def _do() -> None:
        async with _backend() as b:
            rows = await b.list_tasks(work_unit, status=status)
            if not rows:
                typer.echo("No tasks.")
                return
            for r in rows:
                _print_task(r)

    _run(_do())


@task_app.command("show")
def task_show(
    task_id: str = typer.Argument(
        ...,
        help="Full UUID or 8-char+ hex prefix. Ambiguous prefixes error out.",
    ),
) -> None:
    """Show a single task (resolved to chain head)."""

    async def _do() -> None:
        pid = _cfg_project(None)
        async with _backend() as b:
            t = await b.get_task(task_id, project_id=pid)
            if not t:
                typer.echo(f"Task {task_id} not found.", err=True)
                raise typer.Exit(1)
            _print_task(t)
            for k, v in t.context.items():
                typer.echo(f"    {k}: {v}")
            typer.echo(f"    work_unit: {t.work_unit_id}")

    _run(_do())


@task_app.command("start")
def task_start(
    task_id: str = typer.Argument(...),
    actor: str | None = typer.Option(None, "--actor", "-a", envvar="LUPLO_ACTOR_ID"),
) -> None:
    """Transition task to 'in_progress' (enforces 1 in_progress per WU)."""
    aid = _cfg_actor(actor)
    pid = _cfg_project(None)

    async def _do() -> None:
        async with _backend() as b:
            t = await b.start_task(task_id, actor_id=aid, project_id=pid)
            _print_task(t)

    _run(_do())


@task_app.command("done")
def task_done(
    task_id: str = typer.Argument(...),
    summary: str | None = typer.Option(None, "--summary"),
    propose_decision: bool = typer.Option(
        False,
        "--propose-decision",
        help="After completion, print a draft decision item derived from this task. "
        "The draft is NOT inserted — copy-paste the lp command shown to save it.",
    ),
    actor: str | None = typer.Option(None, "--actor", "-a", envvar="LUPLO_ACTOR_ID"),
) -> None:
    """Transition task to 'done'."""
    aid = _cfg_actor(actor)
    pid = _cfg_project(None)

    async def _do() -> None:
        async with _backend() as b:
            t = await b.complete_task(task_id, actor_id=aid, summary=summary, project_id=pid)
            _print_task(t)

            if propose_decision:
                draft = await b.suggest_decision_from_task(t.id, project_id=pid)
                typer.echo("")
                if draft is None:
                    typer.echo(
                        "No decision draft suggested "
                        "(task has no body or summary — nothing to derive from).",
                    )
                else:
                    typer.echo("Suggested decision (not saved):")
                    typer.echo(f"  title:     {draft.title}")
                    if draft.body:
                        typer.echo(f"  body:      {draft.body}")
                    if draft.rationale:
                        typer.echo(f"  rationale: {draft.rationale}")
                    if draft.tags:
                        typer.echo(f"  tags:      {', '.join(draft.tags)}")
                    typer.echo("")
                    typer.echo("To save, run: lp items add <title> --type decision ...")

    _run(_do())


@task_app.command("blocked")
def task_blocked(
    task_id: str = typer.Argument(...),
    reason: str = typer.Option(..., "--reason", "-r"),
    actor: str | None = typer.Option(None, "--actor", "-a", envvar="LUPLO_ACTOR_ID"),
) -> None:
    """Transition task to 'blocked' (auto-creates a decision item)."""
    aid = _cfg_actor(actor)
    pid = _cfg_project(None)

    async def _do() -> None:
        async with _backend() as b:
            t = await b.block_task(task_id, actor_id=aid, reason=reason, project_id=pid)
            _print_task(t)
            typer.echo("  (auto-created decision item — see `lp items list --type decision`)")

    _run(_do())


@task_app.command("skip")
def task_skip(
    task_id: str = typer.Argument(...),
    reason: str | None = typer.Option(None, "--reason", "-r"),
    actor: str | None = typer.Option(None, "--actor", "-a", envvar="LUPLO_ACTOR_ID"),
) -> None:
    """Transition task to 'skipped' (terminal)."""
    aid = _cfg_actor(actor)
    pid = _cfg_project(None)

    async def _do() -> None:
        async with _backend() as b:
            t = await b.skip_task(task_id, actor_id=aid, reason=reason, project_id=pid)
            _print_task(t)

    _run(_do())


@task_app.command("reorder")
def task_reorder(
    work_unit: str = typer.Argument(..., help="Work unit ID."),
    task_ids: list[str] = typer.Argument(..., help="Task IDs in desired order."),
    actor: str | None = typer.Option(None, "--actor", "-a", envvar="LUPLO_ACTOR_ID"),
) -> None:
    """Reorder tasks (in-place sort_order update — P10)."""
    aid = _cfg_actor(actor)
    pid = _cfg_project(None)

    async def _do() -> None:
        async with _backend() as b:
            rows = await b.reorder_tasks(work_unit, task_ids, actor_id=aid, project_id=pid)
            for r in rows:
                _print_task(r)

    _run(_do())


@task_app.command("edit")
def task_edit(
    task_id: str = typer.Argument(...),
    title: str | None = typer.Option(None, "--title", "-t", help="New title."),
    body: str | None = typer.Option(None, "--body", "-b", help="New body."),
    sort_order: int | None = typer.Option(None, "--sort", "-s", help="New sort_order."),
    actor: str | None = typer.Option(None, "--actor", "-a", envvar="LUPLO_ACTOR_ID"),
) -> None:
    """Edit a task's title / body / sort_order via a supersede row.

    Status is preserved — use lp task start / done / blocked / skip to
    change status. Passing no flags is a no-op that just returns the
    current head.
    """
    aid = _cfg_actor(actor)
    pid = _cfg_project(None)

    async def _do() -> None:
        async with _backend() as b:
            t = await b.edit_task(
                task_id,
                actor_id=aid,
                title=title,
                body=body,
                sort_order=sort_order,
                project_id=pid,
            )
            _print_task(t)

    _run(_do())


@task_app.command("in-progress")
def task_in_progress(work_unit: str = typer.Option(..., "--wu", "-w")) -> None:
    """Show the current in_progress task for a work unit, if any."""

    async def _do() -> None:
        async with _backend() as b:
            t = await b.get_in_progress_task(work_unit)
            if t is None:
                typer.echo("(none)")
            else:
                _print_task(t)

    _run(_do())


# ── QA Checks ────────────────────────────────────────────────────


def _print_qa(item: Item) -> None:
    status = item.context.get("status", "?")
    coverage = item.context.get("coverage", "?")
    areas = ",".join(item.context.get("areas") or []) or "—"
    typer.echo(f"  {item.id[:8]}  [{status:<10}] {coverage:<12} ({areas}) {item.title}")


@qa_app.command("add")
def qa_add(
    title: str = typer.Argument(...),
    coverage: str = typer.Option(..., "--coverage", "-c", help="auto_partial | human_only"),
    area: list[str] | None = typer.Option(
        None, "--area", help="vfx, sfx, ux, edge_case, perf, a11y, sec"
    ),
    tasks_target: list[str] | None = typer.Option(None, "--task", "-t", help="Target task IDs."),
    items_target: list[str] | None = typer.Option(None, "--item", "-i", help="Target item IDs."),
    work_unit: str | None = typer.Option(None, "--wu", "-w"),
    body: str | None = typer.Option(None, "--body"),
    project: str | None = typer.Option(None, "--project", "-p", envvar="LUPLO_PROJECT"),
    actor: str | None = typer.Option(None, "--actor", "-a", envvar="LUPLO_ACTOR_ID"),
) -> None:
    """Add a new qa_check in 'pending' status."""
    pid = _cfg_project(project)
    aid = _cfg_actor(actor)

    async def _do() -> None:
        async with _backend() as b:
            q = await b.create_qa(
                project_id=pid,
                title=title,
                actor_id=aid,
                coverage=coverage,
                areas=area,
                target_task_ids=tasks_target,
                target_item_ids=items_target,
                work_unit_id=work_unit,
                body=body,
            )
            _print_qa(q)

    _run(_do())


@qa_app.command("ls")
def qa_ls(
    status: str | None = typer.Option(None, "--status", "-s"),
    work_unit: str | None = typer.Option(None, "--wu", "-w"),
    task: str | None = typer.Option(
        None, "--task", "-t", help="Filter to qa_checks targeting this task."
    ),
    item_id_filter: str | None = typer.Option(None, "--item", "-i"),
    project: str | None = typer.Option(None, "--project", "-p", envvar="LUPLO_PROJECT"),
) -> None:
    """List qa_checks. With --task / --item shows pending qa for that target."""
    pid = _cfg_project(project)

    async def _do() -> None:
        async with _backend() as b:
            if task:
                rows = await b.list_pending_qa_for_task(task)
            elif item_id_filter:
                rows = await b.list_pending_qa_for_item(item_id_filter)
            else:
                rows = await b.list_qa(pid, status=status, work_unit_id=work_unit)
            if not rows:
                typer.echo("No qa_checks.")
                return
            for r in rows:
                _print_qa(r)

    _run(_do())


@qa_app.command("show")
def qa_show(
    qa_id: str = typer.Argument(
        ...,
        help="Full UUID or 8-char+ hex prefix. Ambiguous prefixes error out.",
    ),
) -> None:
    """Show a single qa_check (chain head)."""

    async def _do() -> None:
        pid = _cfg_project(None)
        async with _backend() as b:
            q = await b.get_qa(qa_id, project_id=pid)
            if not q:
                typer.echo(f"qa_check {qa_id} not found.", err=True)
                raise typer.Exit(1)
            _print_qa(q)
            for k, v in q.context.items():
                typer.echo(f"    {k}: {v}")

    _run(_do())


@qa_app.command("start")
def qa_start(
    qa_id: str = typer.Argument(...),
    actor: str | None = typer.Option(None, "--actor", "-a", envvar="LUPLO_ACTOR_ID"),
) -> None:
    aid = _cfg_actor(actor)
    pid = _cfg_project(None)

    async def _do() -> None:
        async with _backend() as b:
            q = await b.start_qa(qa_id, actor_id=aid, project_id=pid)
            _print_qa(q)

    _run(_do())


@qa_app.command("pass")
def qa_pass(
    qa_id: str = typer.Argument(...),
    evidence: str | None = typer.Option(None, "--evidence", "-e"),
    actor: str | None = typer.Option(None, "--actor", "-a", envvar="LUPLO_ACTOR_ID"),
) -> None:
    aid = _cfg_actor(actor)
    pid = _cfg_project(None)

    async def _do() -> None:
        async with _backend() as b:
            q = await b.pass_qa(qa_id, actor_id=aid, evidence=evidence, project_id=pid)
            _print_qa(q)

    _run(_do())


@qa_app.command("fail")
def qa_fail(
    qa_id: str = typer.Argument(...),
    reason: str = typer.Option(..., "--reason", "-r"),
    actor: str | None = typer.Option(None, "--actor", "-a", envvar="LUPLO_ACTOR_ID"),
) -> None:
    aid = _cfg_actor(actor)
    pid = _cfg_project(None)

    async def _do() -> None:
        async with _backend() as b:
            q = await b.fail_qa(qa_id, actor_id=aid, reason=reason, project_id=pid)
            _print_qa(q)

    _run(_do())


@qa_app.command("block")
def qa_block(
    qa_id: str = typer.Argument(...),
    reason: str = typer.Option(..., "--reason", "-r"),
    actor: str | None = typer.Option(None, "--actor", "-a", envvar="LUPLO_ACTOR_ID"),
) -> None:
    aid = _cfg_actor(actor)
    pid = _cfg_project(None)

    async def _do() -> None:
        async with _backend() as b:
            q = await b.block_qa(qa_id, actor_id=aid, reason=reason, project_id=pid)
            _print_qa(q)

    _run(_do())


@qa_app.command("assign")
def qa_assign(
    qa_id: str = typer.Argument(...),
    assignee: str = typer.Option(..., "--to", help="Assignee actor UUID."),
    actor: str | None = typer.Option(None, "--actor", "-a", envvar="LUPLO_ACTOR_ID"),
) -> None:
    aid = _cfg_actor(actor)
    pid = _cfg_project(None)

    async def _do() -> None:
        async with _backend() as b:
            q = await b.assign_qa(qa_id, actor_id=aid, assignee_actor_id=assignee, project_id=pid)
            _print_qa(q)

    _run(_do())


if __name__ == "__main__":
    app()
