"""Context governance contracts for workflow input resolution."""

from __future__ import annotations

import json
from contextlib import contextmanager
from contextvars import ContextVar
from datetime import datetime
from enum import StrEnum
from typing import Iterator, Literal

from pydantic import BaseModel, ConfigDict, Field

from runsight_core.redaction import REDACTED_VALUE, RunRedactor
from runsight_core.state import BlockResult, WorkflowState

_MAX_PREVIEW_LENGTH = 200
_WHOLE_OUTPUT_ALIASES = {"output", "result"}
_SECRET_KEY_FRAGMENTS = (
    "api_key",
    "apikey",
    "access_token",
    "auth_token",
    "bearer_token",
    "client_secret",
    "credential",
    "password",
    "private_key",
    "refresh_token",
    "secret",
)
_SECRET_VALUE_MARKERS = (
    "sk-",
    "secret",
    "bearer ",
    "-----begin private key-----",
)
_SUPPRESSED_DECLARED_INPUT_BLOCK_IDS: ContextVar[frozenset[str]] = ContextVar(
    "suppressed_declared_input_block_ids",
    default=frozenset(),
)


class ContextAccess(StrEnum):
    """Block-level context access policy declared in workflow YAML."""

    DECLARED = "declared"


class ContextAuditNamespace(StrEnum):
    """Supported namespaces for context audit records."""

    WORKFLOW = "workflow"
    RESULTS = "results"
    SHARED_MEMORY = "shared_memory"
    METADATA = "metadata"


class ContextAuditMode(StrEnum):
    """Context governance enforcement mode."""

    STRICT = "strict"
    DEV = "dev"


class ContextAuditStatus(StrEnum):
    """Resolution outcome for one requested context reference."""

    RESOLVED = "resolved"
    MISSING = "missing"
    DENIED = "denied"
    EMPTY = "empty"


class ContextAuditSeverity(StrEnum):
    """Audit severity for one resolution record."""

    ALLOW = "allow"
    WARN = "warn"
    ERROR = "error"


class ParsedContextRef(BaseModel):
    """Normalized context reference split into namespace, source, and field path."""

    model_config = ConfigDict(extra="forbid", use_enum_values=True)

    namespace: ContextAuditNamespace
    source: str
    field_path: str | None = None


class ContextGovernancePolicy(BaseModel):
    """Runtime context governance policy."""

    model_config = ConfigDict(extra="forbid", use_enum_values=True)

    mode: ContextAuditMode = ContextAuditMode.STRICT


class ContextDeclaration(BaseModel):
    """Block-level context declaration consumed by ContextResolver."""

    model_config = ConfigDict(extra="forbid", use_enum_values=True)

    block_id: str
    block_type: str
    access: ContextAccess = ContextAccess.DECLARED
    declared_inputs: dict[str, str] = Field(default_factory=dict)
    internal_inputs: dict[str, str] = Field(default_factory=dict)


class ContextAuditRecordV1(BaseModel):
    """Audit record for a single block input context reference."""

    model_config = ConfigDict(extra="forbid", use_enum_values=True)

    input_name: str | None
    from_ref: str | None
    namespace: ContextAuditNamespace | None
    source: str | None
    field_path: str | None = None
    status: ContextAuditStatus
    severity: ContextAuditSeverity
    value_type: str | None = None
    preview: str | None = None
    reason: str | None = None
    internal: bool = False


class ContextAuditEventV1(BaseModel):
    """Audit event emitted after resolving context for one block."""

    model_config = ConfigDict(extra="forbid", use_enum_values=True)

    schema_version: Literal["context_audit.v1"] = "context_audit.v1"
    event: Literal["context_resolution"] = "context_resolution"
    run_id: str
    workflow_name: str
    node_id: str
    block_type: str
    access: ContextAccess
    mode: ContextAuditMode
    sequence: int | None = None
    records: list[ContextAuditRecordV1] = Field(default_factory=list)
    resolved_count: int = Field(default=0, ge=0)
    denied_count: int = Field(default=0, ge=0)
    warning_count: int = Field(default=0, ge=0)
    emitted_at: datetime


class ScopedContextData(BaseModel):
    """Least-privilege context resolved for a single block."""

    model_config = ConfigDict(extra="forbid")

    inputs: dict[str, object] = Field(default_factory=dict)
    scoped_workflow_inputs: dict[str, object] = Field(default_factory=dict)
    scoped_results: dict[str, object] = Field(default_factory=dict)
    scoped_shared_memory: dict[str, object] = Field(default_factory=dict)
    scoped_metadata: dict[str, object] = Field(default_factory=dict)
    state_snapshot: WorkflowState | None = None
    audit_event: ContextAuditEventV1


class ContextResolutionError(ValueError, KeyError):
    """Raised when declared context cannot be resolved."""


class ContextResolutionAuditError(ContextResolutionError):
    """Raised when context resolution fails after producing an audit event."""

    def __init__(self, message: str, *, audit_event: ContextAuditEventV1) -> None:
        super().__init__(message)
        self.audit_event = audit_event


class ContextReadDeniedError(ContextResolutionError):
    """Raised when a context read violates the declared access policy."""


class ContextResolver:
    """Resolve declared block inputs into least-privilege scoped context."""

    def __init__(
        self,
        *,
        policy: ContextGovernancePolicy | None = None,
        run_id: str,
        workflow_name: str,
    ) -> None:
        self.policy = policy or ContextGovernancePolicy()
        self.run_id = run_id
        self.workflow_name = workflow_name

    def resolve(
        self,
        *,
        declaration: ContextDeclaration,
        state: WorkflowState,
    ) -> ScopedContextData:
        inputs: dict[str, object] = {}
        scoped_workflow_inputs: dict[str, object] = {}
        scoped_results: dict[str, BlockResult] = {}
        scoped_shared_memory: dict[str, object] = {}
        scoped_metadata: dict[str, object] = {}
        records: list[ContextAuditRecordV1] = []
        redactor = state.input_redactor

        if declaration.access != ContextAccess.DECLARED.value:
            raise ContextReadDeniedError(
                f"Context access '{declaration.access}' is not implemented for {declaration.block_id}"
            )

        for input_name, from_ref, internal in _iter_declared_and_internal_inputs(declaration):
            parsed: ParsedContextRef | None = None
            try:
                parsed = _canonicalize_context_ref(parse_context_ref(from_ref), state)
                value = _resolve_parsed_ref(parsed, state)
            except (ValueError, ContextResolutionError) as exc:
                if isinstance(exc, ValueError) and from_ref == ContextAuditNamespace.WORKFLOW.value:
                    raise ValueError(str(exc)) from exc
                if self.policy.mode == ContextAuditMode.DEV.value:
                    records.append(
                        _audit_record(
                            input_name=input_name,
                            from_ref=from_ref,
                            parsed=parsed,
                            status=ContextAuditStatus.MISSING,
                            severity=ContextAuditSeverity.WARN,
                            reason=str(exc),
                            internal=internal,
                            preview_value=None,
                            redactor=redactor,
                        )
                    )
                    continue
                status = (
                    ContextAuditStatus.DENIED
                    if isinstance(exc, ContextReadDeniedError)
                    else ContextAuditStatus.MISSING
                )
                records.append(
                    _audit_record(
                        input_name=input_name,
                        from_ref=from_ref,
                        parsed=parsed,
                        status=status,
                        severity=ContextAuditSeverity.ERROR,
                        reason=str(exc),
                        internal=internal,
                        preview_value=None,
                        redactor=redactor,
                    )
                )
                raise ContextResolutionAuditError(
                    str(exc),
                    audit_event=ContextAuditEventV1(
                        run_id=self.run_id,
                        workflow_name=self.workflow_name,
                        node_id=declaration.block_id,
                        block_type=declaration.block_type,
                        access=declaration.access,
                        mode=self.policy.mode,
                        records=records,
                        resolved_count=sum(
                            1
                            for record in records
                            if record.status == ContextAuditStatus.RESOLVED.value
                        ),
                        denied_count=sum(
                            1
                            for record in records
                            if record.status == ContextAuditStatus.DENIED.value
                        ),
                        warning_count=sum(
                            1
                            for record in records
                            if record.severity == ContextAuditSeverity.WARN.value
                        ),
                        emitted_at=datetime.now().astimezone(),
                    ),
                ) from exc

            inputs[input_name] = value
            _scope_value(
                parsed=parsed,
                value=value,
                whole_output_alias=_is_non_json_result_alias(parsed, state),
                scoped_workflow_inputs=scoped_workflow_inputs,
                scoped_results=scoped_results,
                scoped_shared_memory=scoped_shared_memory,
                scoped_metadata=scoped_metadata,
            )
            records.append(
                _audit_record(
                    input_name=input_name,
                    from_ref=from_ref,
                    parsed=parsed,
                    status=ContextAuditStatus.RESOLVED,
                    severity=ContextAuditSeverity.ALLOW,
                    value=value,
                    preview_value=_audit_preview_value(parsed, value, state, redactor),
                    internal=internal,
                    redactor=redactor,
                )
            )

        warning_count = sum(
            1 for record in records if record.severity == ContextAuditSeverity.WARN.value
        )
        audit_event = ContextAuditEventV1(
            run_id=self.run_id,
            workflow_name=self.workflow_name,
            node_id=declaration.block_id,
            block_type=declaration.block_type,
            access=declaration.access,
            mode=self.policy.mode,
            records=records,
            resolved_count=sum(
                1 for record in records if record.status == ContextAuditStatus.RESOLVED.value
            ),
            denied_count=sum(
                1 for record in records if record.status == ContextAuditStatus.DENIED.value
            ),
            warning_count=warning_count,
            emitted_at=datetime.now().astimezone(),
        )
        return ScopedContextData(
            inputs=inputs,
            scoped_workflow_inputs=scoped_workflow_inputs,
            scoped_results=scoped_results,
            scoped_shared_memory=scoped_shared_memory,
            scoped_metadata=scoped_metadata,
            audit_event=audit_event,
        )


def collect_context_declaration(block: object, step: object | None = None) -> ContextDeclaration:
    """Collect user and special-block context declarations for one runtime block."""

    declared_inputs = _user_declared_inputs(block, step)
    internal_inputs = _special_internal_inputs(block)
    collisions = sorted(set(declared_inputs) & set(internal_inputs))
    if collisions:
        raise ValueError(
            f"Block '{getattr(block, 'block_id', '<unknown>')}' input(s) {collisions} "
            "collide with internal context inputs"
        )

    access = str(getattr(block, "context_access", "declared"))
    if access != ContextAccess.DECLARED.value:
        raise ContextReadDeniedError(
            f"Context access '{access}' is not implemented for "
            f"{getattr(block, 'block_id', '<unknown>')}"
        )

    return ContextDeclaration(
        block_id=str(getattr(block, "block_id")),
        block_type=_context_block_type(block),
        access=access,
        declared_inputs=declared_inputs,
        internal_inputs=internal_inputs,
    )


def parse_context_ref(ref: str) -> ParsedContextRef:
    """Parse a context reference into the supported governance namespaces."""

    parts = ref.split(".")
    if not parts or any(part == "" for part in parts):
        raise ValueError("context ref must be a non-empty dot path")

    if parts[0] == ContextAuditNamespace.WORKFLOW.value:
        if len(parts) < 2:
            raise ValueError("workflow context references must name an input")
        source = parts[1]
        field_path = ".".join(parts[2:]) or None
        return ParsedContextRef(
            namespace=ContextAuditNamespace.WORKFLOW,
            source=source,
            field_path=field_path,
        )

    if parts[0] in {namespace.value for namespace in ContextAuditNamespace}:
        if len(parts) < 2:
            raise ValueError("context ref must include a source")
        namespace = parts[0]
        source = parts[1]
        field_path = ".".join(parts[2:]) or None
        return ParsedContextRef(namespace=namespace, source=source, field_path=field_path)

    source = parts[0]
    field_path = ".".join(parts[1:]) or None
    return ParsedContextRef(
        namespace=ContextAuditNamespace.RESULTS,
        source=source,
        field_path=field_path,
    )


def _canonicalize_context_ref(
    parsed: ParsedContextRef,
    state: WorkflowState,
) -> ParsedContextRef:
    """Prefer exact/longest result keys so block IDs may contain dots."""
    if parsed.namespace != ContextAuditNamespace.RESULTS.value:
        return parsed

    source, field_path = _resolve_result_source(parsed, state)
    if source == parsed.source and field_path == parsed.field_path:
        return parsed
    return parsed.model_copy(update={"source": source, "field_path": field_path})


def _resolve_result_source(
    parsed: ParsedContextRef,
    state: WorkflowState,
) -> tuple[str, str | None]:
    if parsed.field_path is None:
        return parsed.source, None

    parts = [parsed.source, *parsed.field_path.split(".")]
    for split_at in range(len(parts), 0, -1):
        candidate = ".".join(parts[:split_at])
        if candidate in state.results:
            remaining = ".".join(parts[split_at:]) or None
            return candidate, remaining
    if parsed.source in state.results:
        return parsed.source, parsed.field_path
    return parsed.source, parsed.field_path


def _iter_declared_and_internal_inputs(
    declaration: ContextDeclaration,
) -> list[tuple[str, str, bool]]:
    return [
        *((name, from_ref, False) for name, from_ref in declaration.declared_inputs.items()),
        *((name, from_ref, True) for name, from_ref in declaration.internal_inputs.items()),
    ]


@contextmanager
def suppress_declared_inputs_for_block(block_id: str) -> Iterator[None]:
    """Temporarily skip user-declared input resolution for one block in this task."""
    suppressed = _SUPPRESSED_DECLARED_INPUT_BLOCK_IDS.get()
    token = _SUPPRESSED_DECLARED_INPUT_BLOCK_IDS.set(suppressed | {block_id})
    try:
        yield
    finally:
        _SUPPRESSED_DECLARED_INPUT_BLOCK_IDS.reset(token)


def _user_declared_inputs(block: object, step: object | None) -> dict[str, str]:
    block_id = str(getattr(block, "block_id", ""))
    if block_id in _SUPPRESSED_DECLARED_INPUT_BLOCK_IDS.get():
        return {}
    if step is not None and hasattr(step, "declared_inputs"):
        return dict(getattr(step, "declared_inputs") or {})
    declared_inputs = getattr(block, "declared_inputs", None)
    if declared_inputs:
        return dict(declared_inputs)
    return {}


def _special_internal_inputs(block: object) -> dict[str, str]:
    eval_key = getattr(block, "eval_key", None)
    if eval_key is not None:
        return {"content": str(eval_key)}

    input_block_ids = getattr(block, "input_block_ids", None)
    if input_block_ids is not None:
        return {str(block_id): str(block_id) for block_id in input_block_ids}

    return {}


def _context_block_type(block: object) -> str:
    if getattr(block, "eval_key", None) is not None:
        return "gate"
    if getattr(block, "input_block_ids", None) is not None:
        return "synthesize"
    if getattr(block, "branches", None) is not None:
        return "dispatch"
    if getattr(block, "child_workflow", None) is not None:
        return "workflow"
    if getattr(block, "inner_block_refs", None) is not None:
        return "loop"
    if getattr(block, "code", None) is not None:
        return "code"
    return block.__class__.__name__


def _resolve_parsed_ref(parsed: ParsedContextRef, state: WorkflowState) -> object:
    if parsed.namespace == ContextAuditNamespace.WORKFLOW.value:
        if parsed.source not in state.workflow_inputs:
            raise ContextResolutionError(f"Workflow input '{parsed.source}' field path missing")
        value = state.workflow_inputs[parsed.source]
        if parsed.field_path is None:
            return value
        return _resolve_field_path(value, parsed.field_path, parsed)

    if parsed.namespace == ContextAuditNamespace.RESULTS.value:
        if parsed.source not in state.results:
            raise ContextResolutionError(
                f"Context resolution failed for {parsed.source}"
                f"{'.' + parsed.field_path if parsed.field_path else ''}: source result missing. "
                f"Available: {sorted(state.results.keys())}"
            )
        result = state.results[parsed.source]
        raw_output = result.output if isinstance(result, BlockResult) else result
        if parsed.field_path is None:
            return raw_output
        return _resolve_field_path(raw_output, parsed.field_path, parsed)

    if parsed.namespace == ContextAuditNamespace.SHARED_MEMORY.value:
        return _resolve_mapping_path(state.shared_memory, parsed)

    if parsed.namespace == ContextAuditNamespace.METADATA.value:
        return _resolve_mapping_path(state.metadata, parsed)

    raise ContextReadDeniedError(f"Unsupported context namespace: {parsed.namespace}")


def _resolve_mapping_path(data: dict[str, object], parsed: ParsedContextRef) -> object:
    if parsed.source not in data:
        raise ContextResolutionError(
            f"Context resolution failed for {parsed.namespace}.{parsed.source}: source missing"
        )
    value = data[parsed.source]
    if parsed.field_path is None:
        return value
    return _resolve_field_path(value, parsed.field_path, parsed)


def _resolve_field_path(value: object, field_path: str, parsed: ParsedContextRef) -> object:
    parsed_value = value
    if isinstance(value, str):
        try:
            parsed_value = json.loads(value)
        except (json.JSONDecodeError, TypeError) as exc:
            if field_path in _WHOLE_OUTPUT_ALIASES:
                return value
            raise ContextResolutionError(
                f"Context resolution failed: non-JSON output cannot satisfy "
                f"{parsed.source}.{field_path}"
            ) from exc

    if isinstance(parsed_value, str) or parsed_value is None:
        raise ContextResolutionError(
            f"Context resolution failed: non-JSON output cannot satisfy {parsed.source}.{field_path}"
        )

    from runsight_core.conditions.engine import resolve_dotted_path

    resolved = resolve_dotted_path(parsed_value, field_path)
    if resolved is None and not _has_explicit_none(parsed_value, field_path):
        raise ContextResolutionError(
            f"Context resolution failed for {parsed.source}.{field_path}: field path missing"
        )
    return resolved


def _has_explicit_none(value: object, field_path: str) -> bool:
    current = value
    for part in field_path.split("."):
        if isinstance(current, dict) and part in current:
            current = current[part]
            continue
        return False
    return current is None


def _scope_value(
    *,
    parsed: ParsedContextRef,
    value: object,
    whole_output_alias: bool,
    scoped_workflow_inputs: dict[str, object],
    scoped_results: dict[str, BlockResult],
    scoped_shared_memory: dict[str, object],
    scoped_metadata: dict[str, object],
) -> None:
    if parsed.namespace == ContextAuditNamespace.WORKFLOW.value:
        if parsed.field_path is None:
            scoped_workflow_inputs[parsed.source] = value
        else:
            scoped_workflow_inputs[parsed.source] = _merge_mapping_slice(
                existing=scoped_workflow_inputs.get(parsed.source),
                slice_value=_nest_field_path(parsed.field_path, value),
            )
        return

    if parsed.namespace == ContextAuditNamespace.RESULTS.value:
        if parsed.field_path is None or whole_output_alias:
            output = value if isinstance(value, str) else json.dumps(value)
        else:
            output = _merge_result_slice(
                existing=scoped_results.get(parsed.source),
                slice_value=_nest_field_path(parsed.field_path, value),
            )
        scoped_results[parsed.source] = BlockResult(output=output)
        return

    target = (
        scoped_shared_memory
        if parsed.namespace == ContextAuditNamespace.SHARED_MEMORY.value
        else scoped_metadata
    )
    if parsed.field_path is None:
        target[parsed.source] = value
    else:
        target[parsed.source] = _merge_mapping_slice(
            existing=target.get(parsed.source),
            slice_value=_nest_field_path(parsed.field_path, value),
        )


def _merge_result_slice(existing: BlockResult | None, slice_value: dict[str, object]) -> str:
    if existing is None:
        return json.dumps(slice_value)

    existing_value = _json_object_or_none(existing.output)
    if existing_value is None:
        return json.dumps(slice_value)

    return json.dumps(_deep_merge_dicts(existing_value, slice_value))


def _merge_mapping_slice(
    existing: object | None,
    slice_value: dict[str, object],
) -> object:
    if isinstance(existing, dict):
        return _deep_merge_dicts(existing, slice_value)
    return slice_value


def _json_object_or_none(value: str) -> dict[str, object] | None:
    try:
        parsed = json.loads(value)
    except (json.JSONDecodeError, TypeError):
        return None
    return parsed if isinstance(parsed, dict) else None


def _deep_merge_dicts(
    left: dict[str, object],
    right: dict[str, object],
) -> dict[str, object]:
    merged = dict(left)
    for key, value in right.items():
        existing = merged.get(key)
        if isinstance(existing, dict) and isinstance(value, dict):
            merged[key] = _deep_merge_dicts(existing, value)
        else:
            merged[key] = value
    return merged


def _nest_field_path(field_path: str, value: object) -> dict[str, object]:
    parts = field_path.split(".")
    nested: object = value
    for part in reversed(parts):
        nested = {part: nested}
    return nested if isinstance(nested, dict) else {}


def _is_non_json_result_alias(parsed: ParsedContextRef, state: WorkflowState) -> bool:
    if (
        parsed.namespace != ContextAuditNamespace.RESULTS.value
        or parsed.field_path not in _WHOLE_OUTPUT_ALIASES
        or parsed.source not in state.results
    ):
        return False
    raw = state.results[parsed.source]
    raw_output = raw.output if isinstance(raw, BlockResult) else raw
    if not isinstance(raw_output, str):
        return False
    try:
        json.loads(raw_output)
    except (json.JSONDecodeError, TypeError):
        return True
    return False


def _audit_record(
    *,
    input_name: str,
    from_ref: str,
    parsed: ParsedContextRef | None,
    status: ContextAuditStatus,
    severity: ContextAuditSeverity,
    value: object | None = None,
    preview_value: object | None = None,
    reason: str | None = None,
    internal: bool = False,
    redactor: RunRedactor | None = None,
) -> ContextAuditRecordV1:
    redacted_reason = redactor.redact_text(reason) if redactor is not None and reason else reason
    return ContextAuditRecordV1(
        input_name=input_name,
        from_ref=from_ref,
        namespace=None if parsed is None else parsed.namespace,
        source=None if parsed is None else parsed.source,
        field_path=None if parsed is None else parsed.field_path,
        status=status,
        severity=severity,
        value_type=None if value is None else type(value).__name__,
        preview=None
        if value is None
        else bounded_context_preview(
            preview_value
            if preview_value is not None
            else (redactor.redact(value) if redactor is not None else value)
        ),
        reason=redacted_reason,
        internal=internal,
    )


def _audit_preview_value(
    parsed: ParsedContextRef,
    value: object,
    state: WorkflowState,
    redactor: RunRedactor | None,
) -> object:
    if redactor is None:
        return _redact_unregistered_secret_preview(value)

    if parsed.namespace != ContextAuditNamespace.WORKFLOW.value:
        return _redact_unregistered_secret_preview(redactor.redact(value))

    workflow_inputs = state.workflow_inputs
    if len(workflow_inputs) <= 1:
        preview_value = redactor.redact_named(parsed.source, value)
        if parsed.field_path is None:
            return _redact_unregistered_secret_preview(preview_value)
        try:
            return _redact_unregistered_secret_preview(
                _resolve_field_path(preview_value, parsed.field_path, parsed)
            )
        except ContextResolutionError:
            return _redact_unregistered_secret_preview(redactor.redact_named(parsed.source, value))

    redacted_workflow_inputs = redactor.redact(workflow_inputs)
    preview_value = redacted_workflow_inputs.get(parsed.source, value)
    if parsed.field_path is None:
        return _redact_unregistered_secret_preview(preview_value)

    try:
        return _redact_unregistered_secret_preview(
            _resolve_field_path(preview_value, parsed.field_path, parsed)
        )
    except ContextResolutionError:
        return _redact_unregistered_secret_preview(redactor.redact_named(parsed.source, value))


def _redact_unregistered_secret_preview(value: object) -> object:
    return REDACTED_VALUE if _contains_secret_like_preview(value) else value


def redact_context_audit_event_preview(event: ContextAuditEventV1) -> ContextAuditEventV1:
    """Apply heuristic preview redaction before audit events leave core."""
    records: list[ContextAuditRecordV1] = []
    for record in event.records:
        records.append(record.model_copy(update={"preview": _redact_audit_preview(record.preview)}))
    return event.model_copy(update={"records": records})


def _redact_audit_preview(preview: str | None) -> str | None:
    if preview is None:
        return None
    preview_value: object = preview
    try:
        preview_value = json.loads(preview)
    except (json.JSONDecodeError, TypeError):
        pass
    redacted = _redact_unregistered_secret_preview(preview_value)
    if redacted == preview_value:
        return preview
    return bounded_context_preview(redacted)


def _contains_secret_like_preview(value: object) -> bool:
    if isinstance(value, str):
        lowered = value.strip().lower()
        return any(marker in lowered for marker in _SECRET_VALUE_MARKERS)
    if isinstance(value, dict):
        return any(
            (_is_secret_like_key(key) and item != REDACTED_VALUE)
            or _contains_secret_like_preview(item)
            for key, item in value.items()
        )
    if isinstance(value, list | tuple):
        return any(_contains_secret_like_preview(item) for item in value)
    return False


def _is_secret_like_key(value: object) -> bool:
    if not isinstance(value, str):
        return False
    normalized = value.strip().lower().replace("-", "_")
    return any(fragment in normalized for fragment in _SECRET_KEY_FRAGMENTS)


def bounded_context_preview(value: object, *, max_length: int = _MAX_PREVIEW_LENGTH) -> str:
    """Return a deterministic bounded preview for audit records."""

    if isinstance(value, str):
        preview = value
    else:
        try:
            preview = json.dumps(value, sort_keys=True, separators=(",", ":"))
        except TypeError:
            preview = repr(value)
    if len(preview) <= max_length:
        return preview
    return preview[: max_length - 3] + "..."
