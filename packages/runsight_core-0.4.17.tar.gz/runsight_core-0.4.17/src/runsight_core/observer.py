"""
Workflow observability: protocol and built-in observers.

Usage:
    from runsight_core.observer import LoggingObserver, FileObserver

    # Logging (prints to stderr via Python logging)
    observer = LoggingObserver(level=logging.INFO)
    await workflow.run(state, observer=observer)

    # File-based (JSON lines, tail -f friendly)
    observer = FileObserver("pipeline.log")
    await workflow.run(state, observer=observer)
"""

import hashlib
import inspect
import json
import logging
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional, Protocol, runtime_checkable

from runsight_core.context_governance import ContextAuditEventV1
from runsight_core.identity import EntityKind, EntityRef, validate_entity_id
from runsight_core.primitives import Soul
from runsight_core.redaction import redact_text_for_state
from runsight_core.state import WorkflowState


def compute_prompt_hash(soul: Optional[Soul]) -> Optional[str]:
    """Return SHA-256 hex digest of soul.system_prompt, or None if soul is None."""
    if soul is None:
        return None
    return hashlib.sha256(soul.system_prompt.encode()).hexdigest()


def compute_soul_version(soul: Optional[Soul]) -> Optional[str]:
    """Return SHA-256 hex digest of soul.model_dump_json(), or None if soul is None."""
    if soul is None:
        return None
    return hashlib.sha256(soul.model_dump_json().encode()).hexdigest()


@runtime_checkable
class WorkflowObserver(Protocol):
    """Protocol for workflow execution observers. All methods are optional no-ops by default."""

    def on_workflow_start(self, workflow_name: str, state: WorkflowState) -> None: ...

    def on_block_start(
        self,
        workflow_name: str,
        block_id: str,
        block_type: str,
        *,
        soul: Optional[Soul] = None,
        **kwargs: Any,
    ) -> None: ...

    def on_block_complete(
        self,
        workflow_name: str,
        block_id: str,
        block_type: str,
        duration_s: float,
        state: WorkflowState,
        *,
        soul: Optional[Soul] = None,
    ) -> None: ...

    def on_block_error(
        self,
        workflow_name: str,
        block_id: str,
        block_type: str,
        duration_s: float,
        error: Exception,
        *,
        state: WorkflowState | None = None,
    ) -> None: ...

    def on_workflow_complete(
        self, workflow_name: str, state: WorkflowState, duration_s: float
    ) -> None: ...

    def on_block_heartbeat(
        self,
        workflow_name: str,
        block_id: str,
        phase: str,
        detail: str,
        timestamp: datetime,
    ) -> None: ...

    def on_workflow_error(
        self,
        workflow_name: str,
        error: Exception,
        duration_s: float,
        *,
        state: WorkflowState | None = None,
    ) -> None: ...

    def on_context_resolution(self, event: ContextAuditEventV1) -> None: ...


class LoggingObserver:
    """Observer that logs workflow events via Python's logging module."""

    def __init__(self, logger_name: str = "runsight.workflow", level: int = logging.INFO):
        self.logger = logging.getLogger(logger_name)
        self.level = level

    def on_workflow_start(self, workflow_name: str, state: WorkflowState) -> None:
        try:
            validate_entity_id(workflow_name, EntityKind.WORKFLOW)
            workflow_ref = str(EntityRef(EntityKind.WORKFLOW, workflow_name))
        except ValueError:
            workflow_ref = workflow_name
        self.logger.log(self.level, "[%s] Workflow started", workflow_ref)

    def on_block_start(
        self,
        workflow_name: str,
        block_id: str,
        block_type: str,
        *,
        soul: Optional[Soul] = None,
        **kwargs: Any,
    ) -> None:
        self.logger.log(
            self.level, "[%s] Block started: %s (type: %s)", workflow_name, block_id, block_type
        )

    def on_block_complete(
        self,
        workflow_name: str,
        block_id: str,
        block_type: str,
        duration_s: float,
        state: WorkflowState,
        *,
        soul: Optional[Soul] = None,
    ) -> None:
        self.logger.log(
            self.level,
            "[%s] Block complete: %s (%.1fs, cost: $%.4f, tokens: %d)",
            workflow_name,
            block_id,
            duration_s,
            state.total_cost_usd,
            state.total_tokens,
        )

    def on_block_error(
        self,
        workflow_name: str,
        block_id: str,
        block_type: str,
        duration_s: float,
        error: Exception,
        *,
        state: WorkflowState | None = None,
    ) -> None:
        message = redact_text_for_state(str(error), state)
        self.logger.error(
            "[%s] Block error: %s (%.1fs) — %s: %s",
            workflow_name,
            block_id,
            duration_s,
            type(error).__name__,
            message,
        )

    def on_workflow_complete(
        self, workflow_name: str, state: WorkflowState, duration_s: float
    ) -> None:
        self.logger.log(
            self.level,
            "[%s] Workflow complete (%.1fs, total cost: $%.4f, total tokens: %d)",
            workflow_name,
            duration_s,
            state.total_cost_usd,
            state.total_tokens,
        )

    def on_block_heartbeat(
        self,
        workflow_name: str,
        block_id: str,
        phase: str,
        detail: str,
        timestamp: datetime,
    ) -> None:
        self.logger.log(
            self.level,
            "[%s] Heartbeat: block=%s phase=%s detail=%s",
            workflow_name,
            block_id,
            phase,
            detail,
        )

    def on_workflow_error(
        self,
        workflow_name: str,
        error: Exception,
        duration_s: float,
        *,
        state: WorkflowState | None = None,
    ) -> None:
        message = redact_text_for_state(str(error), state)
        self.logger.error(
            "[%s] Workflow failed (%.1fs) — %s: %s",
            workflow_name,
            duration_s,
            type(error).__name__,
            message,
        )

    def on_context_resolution(self, event: ContextAuditEventV1) -> None:
        self.logger.log(
            self.level,
            "[%s] Context resolved: %s (%d records)",
            event.workflow_name,
            event.node_id,
            len(event.records),
        )


class FileObserver:
    """
    Observer that writes JSON-lines to a file. Designed for real-time tailing.
    Each line is a self-contained JSON object with event type and data.
    """

    def __init__(self, path: str):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        # Truncate on init (new run = new log)
        self.path.write_text("", encoding="utf-8")

    def _write(self, event: str, data: Dict[str, Any]) -> None:
        entry = {"ts": time.time(), "event": event, **data}
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")
            f.flush()

    def on_workflow_start(self, workflow_name: str, state: WorkflowState) -> None:
        self._write("workflow_start", {"workflow": workflow_name})

    def on_block_start(
        self,
        workflow_name: str,
        block_id: str,
        block_type: str,
        *,
        soul: Optional[Soul] = None,
        **kwargs: Any,
    ) -> None:
        self._write(
            "block_start",
            {"workflow": workflow_name, "block_id": block_id, "block_type": block_type},
        )

    def on_block_complete(
        self,
        workflow_name: str,
        block_id: str,
        block_type: str,
        duration_s: float,
        state: WorkflowState,
        *,
        soul: Optional[Soul] = None,
    ) -> None:
        self._write(
            "block_complete",
            {
                "workflow": workflow_name,
                "block_id": block_id,
                "block_type": block_type,
                "duration_s": round(duration_s, 2),
                "cost_usd": round(state.total_cost_usd, 6),
                "tokens": state.total_tokens,
            },
        )

    def on_block_error(
        self,
        workflow_name: str,
        block_id: str,
        block_type: str,
        duration_s: float,
        error: Exception,
        *,
        state: WorkflowState | None = None,
    ) -> None:
        self._write(
            "block_error",
            {
                "workflow": workflow_name,
                "block_id": block_id,
                "block_type": block_type,
                "duration_s": round(duration_s, 2),
                "error": f"{type(error).__name__}: {redact_text_for_state(str(error), state)}",
            },
        )

    def on_workflow_complete(
        self, workflow_name: str, state: WorkflowState, duration_s: float
    ) -> None:
        self._write(
            "workflow_complete",
            {
                "workflow": workflow_name,
                "duration_s": round(duration_s, 2),
                "cost_usd": round(state.total_cost_usd, 6),
                "tokens": state.total_tokens,
            },
        )

    def on_block_heartbeat(
        self,
        workflow_name: str,
        block_id: str,
        phase: str,
        detail: str,
        timestamp: datetime,
    ) -> None:
        self._write(
            "block_heartbeat",
            {
                "workflow": workflow_name,
                "block_id": block_id,
                "phase": phase,
                "detail": detail,
            },
        )

    def on_workflow_error(
        self,
        workflow_name: str,
        error: Exception,
        duration_s: float,
        *,
        state: WorkflowState | None = None,
    ) -> None:
        self._write(
            "workflow_error",
            {
                "workflow": workflow_name,
                "duration_s": round(duration_s, 2),
                "error": f"{type(error).__name__}: {redact_text_for_state(str(error), state)}",
            },
        )

    def on_context_resolution(self, event: ContextAuditEventV1) -> None:
        self._write("context_resolution", event.model_dump(mode="json"))


_composite_logger = logging.getLogger("runsight.observer.composite")


def _filtered_observer_kwargs(method: Any, kwargs: Dict[str, Any]) -> Dict[str, Any]:
    try:
        signature = inspect.signature(method)
    except (TypeError, ValueError):
        return kwargs
    if any(param.kind == inspect.Parameter.VAR_KEYWORD for param in signature.parameters.values()):
        return kwargs
    return {key: value for key, value in kwargs.items() if key in signature.parameters}


def _call_observer_method(method: Any, *args: Any, **kwargs: Any) -> None:
    method(*args, **_filtered_observer_kwargs(method, kwargs))


def _clone_child_observer(method: Any, *, child_run_id: str, **kwargs: Any) -> Any:
    return method(child_run_id=child_run_id, **_filtered_observer_kwargs(method, kwargs))


class ChildObserverWrapper:
    """Wraps a parent observer, forwarding non-terminal events and intercepting terminal ones.

    When a child workflow runs inside a WorkflowBlock, its completion/error
    events are local to the child — they must NOT propagate to the parent's
    observer (e.g. StreamingObserver) because the parent workflow is still
    running.  Block-level events (start, complete, error, heartbeat) are
    forwarded normally so the parent observer can track child block progress.
    """

    def __init__(self, parent_observer: WorkflowObserver, child_run_id: Optional[str] = None):
        self._parent = parent_observer
        self.child_run_id = child_run_id

    # -- Forwarded events (block-level) ------------------------------------

    def on_block_start(
        self,
        workflow_name: str,
        block_id: str,
        block_type: str,
        *,
        soul: Optional[Soul] = None,
        **kwargs: Any,
    ) -> None:
        self._parent.on_block_start(workflow_name, block_id, block_type, soul=soul, **kwargs)

    def on_block_complete(
        self,
        workflow_name: str,
        block_id: str,
        block_type: str,
        duration_s: float,
        state: WorkflowState,
        *,
        soul: Optional[Soul] = None,
    ) -> None:
        self._parent.on_block_complete(
            workflow_name, block_id, block_type, duration_s, state, soul=soul
        )

    def on_block_error(
        self,
        workflow_name: str,
        block_id: str,
        block_type: str,
        duration_s: float,
        error: Exception,
        *,
        state: WorkflowState | None = None,
    ) -> None:
        kwargs: Dict[str, Any] = {}
        if state is not None:
            kwargs["state"] = state
        _call_observer_method(
            self._parent.on_block_error,
            workflow_name,
            block_id,
            block_type,
            duration_s,
            error,
            **kwargs,
        )

    def on_block_heartbeat(
        self,
        workflow_name: str,
        block_id: str,
        phase: str,
        detail: str,
        timestamp: datetime,
    ) -> None:
        self._parent.on_block_heartbeat(workflow_name, block_id, phase, detail, timestamp)

    def on_context_resolution(self, event: ContextAuditEventV1) -> None:
        self._parent.on_context_resolution(event)

    # -- Intercepted events (workflow-level terminal) -----------------------

    def on_workflow_start(self, workflow_name: str, state: WorkflowState) -> None:
        pass  # child start is not a parent event

    def on_workflow_complete(
        self, workflow_name: str, state: WorkflowState, duration_s: float
    ) -> None:
        pass  # child completion is NOT terminal for parent

    def on_workflow_error(
        self,
        workflow_name: str,
        error: Exception,
        duration_s: float,
        *,
        state: WorkflowState | None = None,
    ) -> None:
        pass  # child error is NOT terminal for parent


def build_child_observer(
    parent_observer: WorkflowObserver,
    *,
    block_id: str,
    **kwargs: Any,
) -> tuple[WorkflowObserver, Optional[str]]:
    """Derive a child observer when the parent can expose child-run context.

    For simple observers, fall back to ChildObserverWrapper so child terminal
    events do not bubble up to the parent observer. When the parent observer
    chain can provide a concrete child run id and child-specific clones, return
    those instead so nested runs get their own persisted lifecycle.
    """

    getter = getattr(parent_observer, "get_child_run_id_for_block", None)
    child_run_id = getter(block_id) if callable(getter) else None

    cloner = getattr(parent_observer, "clone_for_child_run", None)
    if child_run_id and callable(cloner):
        return _clone_child_observer(cloner, child_run_id=child_run_id, **kwargs), child_run_id

    return ChildObserverWrapper(parent_observer), child_run_id


class CompositeObserver:
    """Composite observer that delegates to multiple observers.

    Each observer call is isolated with try/except so that one failing
    observer never prevents the remaining observers from firing.
    """

    def __init__(self, *observers: WorkflowObserver):
        self.observers = list(observers)

    @staticmethod
    def _child_run_getter(obs: WorkflowObserver) -> Any | None:
        getter = getattr(type(obs), "get_child_run_id_for_block", None)
        if not callable(getter):
            return None
        bound = getattr(obs, "get_child_run_id_for_block", None)
        return bound if callable(bound) else None

    @staticmethod
    def _is_workflow_block_type(block_type: str) -> bool:
        return block_type.strip().lower() in {"workflow", "workflowblock"}

    def get_child_run_id_for_block(self, block_id: str) -> Optional[str]:
        for obs in self.observers:
            getter = self._child_run_getter(obs)
            if getter is None:
                continue
            child_run_id = getter(block_id)
            if child_run_id:
                return child_run_id
        return None

    def clone_for_child_run(self, *, child_run_id: str, **kwargs: Any) -> "CompositeObserver":
        child_observers: list[WorkflowObserver] = []
        child_stream_queue: Any | None = None
        child_stream_queue_factory: Any | None = None
        queue_binders: list[Any] = []
        for obs in self.observers:
            cloner = getattr(obs, "clone_for_child_run", None)
            if callable(cloner):
                cloned = _clone_child_observer(cloner, child_run_id=child_run_id, **kwargs)
            else:
                cloned = ChildObserverWrapper(obs)
            child_observers.append(cloned)

            queue_factory = getattr(cloned, "child_queue_for_run", None)
            if callable(queue_factory) and hasattr(cloned, "queue"):
                child_stream_queue = getattr(cloned, "queue")
                child_stream_queue_factory = queue_factory

            queue_binder = getattr(cloned, "bind_sse_queue", None)
            if callable(queue_binder):
                queue_binders.append(queue_binder)

        if child_stream_queue is not None:
            for queue_binder in queue_binders:
                queue_binder(
                    sse_queue=child_stream_queue,
                    child_sse_queue_factory=child_stream_queue_factory,
                )
        return CompositeObserver(*child_observers)

    def record_workflow_input_snapshot(self, input_schema: Any, inputs: Any, **kwargs: Any) -> None:
        for obs in self.observers:
            recorder = getattr(obs, "record_workflow_input_snapshot", None)
            if callable(recorder):
                self._safe_call(
                    obs,
                    "record_workflow_input_snapshot",
                    input_schema,
                    inputs,
                    **kwargs,
                )

    def _safe_call(
        self, obs: WorkflowObserver, method_name: str, *args: Any, **kwargs: Any
    ) -> None:
        """Call a method on an observer, catching and logging any exception."""
        try:
            method = getattr(obs, method_name)
            _call_observer_method(method, *args, **kwargs)
        except Exception:
            _composite_logger.warning(
                "Observer %s.%s failed", type(obs).__name__, method_name, exc_info=True
            )

    def on_workflow_start(self, workflow_name: str, state: WorkflowState) -> None:
        for obs in self.observers:
            self._safe_call(obs, "on_workflow_start", workflow_name, state)

    def on_block_start(
        self,
        workflow_name: str,
        block_id: str,
        block_type: str,
        *,
        soul: Optional[Soul] = None,
        **kwargs: Any,
    ) -> None:
        kwargs = dict(kwargs)
        if soul is not None:
            kwargs["soul"] = soul
        handled_indices: set[int] = set()
        if "child_run_id" not in kwargs and self._is_workflow_block_type(block_type):
            getters: list[Any] = []
            for index, obs in enumerate(self.observers):
                getter = self._child_run_getter(obs)
                if getter is None:
                    continue
                self._safe_call(
                    obs, "on_block_start", workflow_name, block_id, block_type, **kwargs
                )
                handled_indices.add(index)
                getters.append(getter)
            for getter in getters:
                child_run_id = getter(block_id)
                if child_run_id:
                    kwargs["child_run_id"] = child_run_id
                    break

        for index, obs in enumerate(self.observers):
            if index in handled_indices:
                continue
            self._safe_call(obs, "on_block_start", workflow_name, block_id, block_type, **kwargs)

    def on_block_complete(
        self,
        workflow_name: str,
        block_id: str,
        block_type: str,
        duration_s: float,
        state: WorkflowState,
        *,
        soul: Optional[Soul] = None,
    ) -> None:
        kwargs: Dict[str, Any] = {}
        if soul is not None:
            kwargs["soul"] = soul
        for obs in self.observers:
            self._safe_call(
                obs,
                "on_block_complete",
                workflow_name,
                block_id,
                block_type,
                duration_s,
                state,
                **kwargs,
            )

    def on_block_error(
        self,
        workflow_name: str,
        block_id: str,
        block_type: str,
        duration_s: float,
        error: Exception,
        *,
        state: WorkflowState | None = None,
    ) -> None:
        kwargs: Dict[str, Any] = {}
        if state is not None:
            kwargs["state"] = state
        for obs in self.observers:
            self._safe_call(
                obs,
                "on_block_error",
                workflow_name,
                block_id,
                block_type,
                duration_s,
                error,
                **kwargs,
            )

    def on_workflow_complete(
        self, workflow_name: str, state: WorkflowState, duration_s: float
    ) -> None:
        for obs in self.observers:
            self._safe_call(obs, "on_workflow_complete", workflow_name, state, duration_s)

    def on_block_heartbeat(
        self,
        workflow_name: str,
        block_id: str,
        phase: str,
        detail: str,
        timestamp: datetime,
    ) -> None:
        for obs in self.observers:
            self._safe_call(
                obs,
                "on_block_heartbeat",
                workflow_name,
                block_id,
                phase,
                detail,
                timestamp,
            )

    def on_workflow_error(
        self,
        workflow_name: str,
        error: Exception,
        duration_s: float,
        *,
        state: WorkflowState | None = None,
    ) -> None:
        kwargs: Dict[str, Any] = {}
        if state is not None:
            kwargs["state"] = state
        for obs in self.observers:
            self._safe_call(obs, "on_workflow_error", workflow_name, error, duration_s, **kwargs)

    def on_context_resolution(self, event: ContextAuditEventV1) -> None:
        for obs in self.observers:
            if not callable(getattr(obs, "on_context_resolution", None)):
                continue
            self._safe_call(obs, "on_context_resolution", event)
