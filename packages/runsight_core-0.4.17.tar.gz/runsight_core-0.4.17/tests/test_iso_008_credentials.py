"""
Failing tests for RUN-398: ISO-008 — Credential injection + URL allowlists.

Tests cover every AC item:
1.  LLM API key passed via env var — ONE key per subprocess
2.  HTTP tool: credentials injected by engine at IPC time, subprocess never sees token
3.  HTTP tool: URL allowlist enforced (requests to non-allowed hosts rejected)
4.  HTTP tool: SSRF blocks private/reserved IPs
5.  File I/O: base_dir scoped per workflow, not CWD
6.  File I/O: path traversal blocked (.. in path parts rejected)
7.  ${ENV_VAR} resolved at engine level (existing SecretsEnvLoader pattern)
8.  Undefined ${ENV_VAR} produces clear error at parse time (not silent empty string)
9.  Subprocess memory has ONE API key only, no other secrets
"""

from __future__ import annotations

import asyncio
import json
import socket
from pathlib import Path
from typing import Any

import pytest
from runsight_core.isolation import (
    ContextEnvelope,
    IPCClient,
    IPCServer,
    PromptEnvelope,
    SoulEnvelope,
    SubprocessHarness,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_context_envelope(
    *,
    block_id: str = "block-1",
    block_type: str = "linear",
    block_config: dict[str, Any] | None = None,
    tools: list | None = None,
    timeout_seconds: int = 30,
) -> ContextEnvelope:
    return ContextEnvelope(
        block_id=block_id,
        block_type=block_type,
        block_config=block_config or {},
        soul=SoulEnvelope(
            id="soul-1",
            role="Tester",
            system_prompt="You test things.",
            model_name="gpt-4o-mini",
            max_tool_iterations=3,
        ),
        tools=tools or [],
        prompt=PromptEnvelope(id="task-1", instruction="Do the thing.", context={}),
        scoped_results={},
        scoped_shared_memory={},
        conversation_history=[],
        timeout_seconds=timeout_seconds,
        max_output_bytes=1_000_000,
    )


async def _setup_ipc_pair(
    tmp_path: Path,
    handlers: dict[str, Any],
    *,
    sock_name: str = "test.sock",
) -> tuple[IPCServer, IPCClient, socket.socket, Path, asyncio.Task]:
    """Create an IPC server+client pair for testing handlers."""
    sock_path = tmp_path / sock_name
    server_sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    server_sock.bind(str(sock_path))
    server_sock.listen(1)

    server = IPCServer(sock=server_sock, handlers=handlers)
    server_task = asyncio.create_task(server.serve())

    client = IPCClient(socket_path=str(sock_path))
    await client.connect()

    return server, client, server_sock, sock_path, server_task


async def _teardown_ipc_pair(
    server: IPCServer,
    client: IPCClient,
    server_sock: socket.socket,
    sock_path: Path,
    server_task: asyncio.Task,
) -> None:
    """Clean up an IPC server+client pair."""
    await client.close()
    await server.shutdown()
    server_task.cancel()
    server_sock.close()
    sock_path.unlink(missing_ok=True)


async def _tool_call_echo(args: dict[str, Any]) -> str:
    return f"echo:{args['value']}"


async def _tool_call_boom(args: dict[str, Any]) -> str:
    raise RuntimeError("boom")


# ---------------------------------------------------------------------------
# AC1 + AC9: ONE API key per subprocess, no other secrets in env
# NOTE: _build_subprocess_env already exists and passes basic checks.
#       These tests verify the NEW credential-scoped envelope building
#       where the harness resolves tool credentials at envelope construction
#       time and strips them from the subprocess env.
# ---------------------------------------------------------------------------


class TestSubprocessCredentialScoping:
    """Harness must resolve tool credentials and pass them only via IPC handlers."""

    def test_harness_accepts_tool_credentials(self):
        """SubprocessHarness accepts a tool_credentials dict for IPC handler setup."""
        harness = SubprocessHarness(
            api_keys={"openai": "sk-test-key"},
            tool_credentials={"http_tool_1": {"Authorization": "Bearer sk-secret"}},
        )
        assert harness is not None

    def test_tool_credentials_not_in_subprocess_env(self):
        """Tool credentials must NOT appear in the subprocess environment."""
        harness = SubprocessHarness(
            api_keys={"openai": "sk-test-key"},
            tool_credentials={"http_tool_1": {"Authorization": "Bearer sk-tool-secret"}},
        )
        env = harness._build_subprocess_env(socket_path="/tmp/test.sock")

        # The tool credential value must not appear anywhere in the env
        all_env_values = " ".join(env.values())
        assert "sk-tool-secret" not in all_env_values

    def test_harness_creates_handlers_with_credentials(self):
        """Harness builds IPC handlers that have the tool credentials baked in."""
        harness = SubprocessHarness(
            api_keys={"openai": "sk-test-key"},
            tool_credentials={"http_tool_1": {"Authorization": "Bearer sk-injected"}},
        )
        handlers = harness._build_ipc_handlers()
        assert "http" in handlers
        assert "file_io" in handlers


# ---------------------------------------------------------------------------
# RUN-529: Generic tool_call IPC handler
# ---------------------------------------------------------------------------


class TestGenericToolCallHandler:
    """Generic IPC tool_call handler dispatches to resolved ToolInstances by name."""

    @pytest.mark.asyncio
    async def test_make_tool_call_handler_dispatches_to_tool_by_name(self):
        """Resolved tool instances should be callable through the generic tool_call handler."""
        from runsight_core.isolation.handlers import make_tool_call_handler
        from runsight_core.tools import ToolInstance

        handler = make_tool_call_handler(
            {
                "echo_tool": ToolInstance(
                    name="echo_tool",
                    description="Echoes input",
                    parameters={"type": "object", "properties": {"value": {"type": "string"}}},
                    execute=_tool_call_echo,
                )
            }
        )

        result = await handler({"name": "echo_tool", "arguments": {"value": "hi"}})

        assert result == {"output": "echo:hi"}

    @pytest.mark.asyncio
    async def test_make_tool_call_handler_returns_error_for_unknown_tool_name(self):
        """Unknown tool names should not crash the handler."""
        from runsight_core.isolation.handlers import make_tool_call_handler

        handler = make_tool_call_handler({})

        result = await handler({"name": "missing_tool", "arguments": {"value": "hi"}})

        assert "error" in result
        assert "missing_tool" in result["error"]

    @pytest.mark.asyncio
    async def test_make_tool_call_handler_catches_execute_exceptions(self):
        """Tool execution exceptions should be returned as error strings."""
        from runsight_core.isolation.handlers import make_tool_call_handler
        from runsight_core.tools import ToolInstance

        handler = make_tool_call_handler(
            {
                "boom_tool": ToolInstance(
                    name="boom_tool",
                    description="Always fails",
                    parameters={"type": "object", "properties": {}},
                    execute=_tool_call_boom,
                )
            }
        )

        result = await handler({"name": "boom_tool", "arguments": {}})

        assert "error" in result
        assert "boom" in result["error"]


# ---------------------------------------------------------------------------
# RUN-813: LLM handler budget ownership
# ---------------------------------------------------------------------------


class TestLLMHandlerBudgetOwnership:
    """Engine-side LLM calls must leave budget enforcement to the IPC interceptor."""

    @staticmethod
    def _make_litellm_response(
        content: str = "done",
        prompt_tokens: int = 50,
        completion_tokens: int = 30,
        total_tokens: int = 80,
    ):
        from unittest.mock import MagicMock

        message = MagicMock()
        message.content = content
        message.tool_calls = None

        choice = MagicMock()
        choice.message = message
        choice.finish_reason = "stop"

        usage = MagicMock()
        usage.prompt_tokens = prompt_tokens
        usage.completion_tokens = completion_tokens
        usage.total_tokens = total_tokens

        response = MagicMock()
        response.choices = [choice]
        response.usage = usage
        return response

    @pytest.mark.asyncio
    async def test_llm_handler_does_not_use_active_budget_context(self):
        """The IPC handler should return the paid response even when it exceeds cap."""
        from unittest.mock import AsyncMock, patch

        from runsight_core.budget_enforcement import BudgetSession, _active_budget
        from runsight_core.isolation.handlers import make_llm_call_handler

        session = BudgetSession(scope_name="workflow:test", cost_cap_usd=0.001)
        token = _active_budget.set(session)
        try:
            handler = make_llm_call_handler({"openai": "sk-test-openai"})
            with (
                patch(
                    "runsight_core.llm.client.acompletion",
                    new_callable=AsyncMock,
                    return_value=self._make_litellm_response(total_tokens=100),
                ),
                patch("runsight_core.llm.client.completion_cost", return_value=0.002),
            ):
                chunks = [
                    chunk
                    async for chunk in handler(
                        {
                            "model": "gpt-4o",
                            "messages": [{"role": "user", "content": "hi"}],
                        }
                    )
                ]
        finally:
            _active_budget.reset(token)

        assert len(chunks) == 1
        assert chunks[0]["cost_usd"] == pytest.approx(0.002)
        assert session.cost_usd == 0.0


# ---------------------------------------------------------------------------
# AC2: HTTP tool — credentials injected by engine at IPC time
# ---------------------------------------------------------------------------


class TestHTTPCredentialInjection:
    """Engine-side IPC http handler must inject credentials into outgoing requests.

    The subprocess sends a bare HTTP request via IPC. The engine-side handler
    enriches the request with credentials (e.g. Authorization header) from the
    tool config before executing it. The subprocess never sees the raw token.
    """

    @pytest.mark.asyncio
    async def test_http_handler_injects_auth_header(self, tmp_path: Path):
        """http handler adds Authorization header from tool credential config."""
        from unittest.mock import AsyncMock, patch

        from runsight_core.isolation.handlers import make_http_handler

        credentials = {"api.example.com": {"Authorization": "Bearer sk-engine-secret-token"}}
        handler = make_http_handler(credentials=credentials, url_allowlist=["api.example.com"])

        with (
            patch("runsight_core.isolation.handlers.validate_ssrf", new_callable=AsyncMock),
            patch(
                "runsight_core.isolation.handlers._perform_http_request",
                new_callable=AsyncMock,
                return_value={"status_code": 200, "body": "ok", "headers": {}},
            ) as perform_request,
        ):
            result = await handler(
                {
                    "method": "GET",
                    "url": "https://api.example.com/data",
                    "headers": {"Accept": "application/json"},
                }
            )

        assert "error" not in result
        assert perform_request.await_args.kwargs["headers"] == {
            "Accept": "application/json",
            "Authorization": "Bearer sk-engine-secret-token",
        }

    @pytest.mark.asyncio
    async def test_http_handler_does_not_expose_token_in_response(self, tmp_path: Path):
        """The token injected by the engine must not appear in the IPC response."""
        from unittest.mock import AsyncMock, patch

        from runsight_core.isolation.handlers import make_http_handler

        credentials = {"api.example.com": {"Authorization": "Bearer sk-super-secret"}}
        handler = make_http_handler(credentials=credentials, url_allowlist=["api.example.com"])

        with (
            patch("runsight_core.isolation.handlers.validate_ssrf", new_callable=AsyncMock),
            patch(
                "runsight_core.isolation.handlers._perform_http_request",
                new_callable=AsyncMock,
                return_value={"status_code": 200, "body": "ok", "headers": {}},
            ),
        ):
            result = await handler(
                {
                    "method": "GET",
                    "url": "https://api.example.com/data",
                    "headers": {},
                }
            )

        # Response must not contain the injected credential
        result_str = json.dumps(result)
        assert "sk-super-secret" not in result_str

    @pytest.mark.asyncio
    async def test_subprocess_request_has_no_credential_fields(self, tmp_path: Path):
        """Subprocess sends requests without credential fields — engine adds them."""
        from unittest.mock import AsyncMock, patch

        from runsight_core.isolation.handlers import make_http_handler

        credentials = {"api.example.com": {"Authorization": "Bearer sk-injected"}}
        handler = make_http_handler(credentials=credentials, url_allowlist=["api.example.com"])

        # Simulate a subprocess request with NO auth header
        subprocess_request = {
            "method": "GET",
            "url": "https://api.example.com/data",
            "headers": {},
        }

        with (
            patch("runsight_core.isolation.handlers.validate_ssrf", new_callable=AsyncMock),
            patch(
                "runsight_core.isolation.handlers._perform_http_request",
                new_callable=AsyncMock,
                return_value={"status_code": 200, "body": "ok", "headers": {}},
            ) as perform_request,
        ):
            result = await handler(subprocess_request)

        assert "error" not in result
        assert perform_request.await_args.kwargs["headers"]["Authorization"] == "Bearer sk-injected"


# ---------------------------------------------------------------------------
# AC3: HTTP tool — URL allowlist enforced
# ---------------------------------------------------------------------------


class TestHTTPURLAllowlist:
    """HTTP requests must be validated against a URL allowlist."""

    @pytest.mark.asyncio
    async def test_allowed_host_passes(self, tmp_path: Path):
        """Requests to hosts on the allowlist are permitted."""
        from unittest.mock import AsyncMock, patch

        from runsight_core.isolation.handlers import make_http_handler

        handler = make_http_handler(
            credentials={},
            url_allowlist=["api.example.com", "cdn.example.com"],
        )

        with (
            patch("runsight_core.isolation.handlers.validate_ssrf", new_callable=AsyncMock),
            patch(
                "runsight_core.isolation.handlers._perform_http_request",
                new_callable=AsyncMock,
                return_value={"status_code": 200, "body": "ok", "headers": {}},
            ),
        ):
            result = await handler(
                {
                    "method": "GET",
                    "url": "https://api.example.com/data",
                    "headers": {},
                }
            )
        assert "error" not in result

    @pytest.mark.asyncio
    async def test_disallowed_host_rejected(self, tmp_path: Path):
        """Requests to hosts NOT on the allowlist are rejected with an error."""
        from runsight_core.isolation.handlers import make_http_handler

        handler = make_http_handler(
            credentials={},
            url_allowlist=["api.example.com"],
        )

        result = await handler(
            {
                "method": "GET",
                "url": "https://evil.attacker.com/steal",
                "headers": {},
            }
        )
        assert "error" in result
        assert "allowlist" in result["error"].lower() or "allowed" in result["error"].lower()

    @pytest.mark.asyncio
    async def test_empty_allowlist_blocks_all(self, tmp_path: Path):
        """An empty allowlist blocks all HTTP requests."""
        from runsight_core.isolation.handlers import make_http_handler

        handler = make_http_handler(credentials={}, url_allowlist=[])

        result = await handler(
            {
                "method": "GET",
                "url": "https://any-host.com/path",
                "headers": {},
            }
        )
        assert "error" in result

    @pytest.mark.asyncio
    async def test_literal_wildcard_does_not_bypass_allowlist(self, tmp_path: Path):
        """A '*' entry is treated literally; hosts must still be explicitly allowed."""
        from unittest.mock import AsyncMock, patch

        from runsight_core.isolation.handlers import make_http_handler

        handler = make_http_handler(credentials={}, url_allowlist=["10.0.0.1"])

        with patch("runsight_core.isolation.handlers.validate_ssrf", new_callable=AsyncMock):
            result = await handler(
                {
                    "method": "GET",
                    "url": "https://literally-anything.com/path",
                    "headers": {},
                }
            )
        assert "error" in result
        assert "allowed" in result["error"].lower()

    @pytest.mark.asyncio
    async def test_allowlist_matches_hostname_not_path(self, tmp_path: Path):
        """Allowlist checks the hostname, not the full URL path."""
        from unittest.mock import AsyncMock, patch

        from runsight_core.isolation.handlers import make_http_handler

        handler = make_http_handler(
            credentials={},
            url_allowlist=["api.example.com"],
        )

        # Different paths on the same allowed host should be fine
        with (
            patch("runsight_core.isolation.handlers.validate_ssrf", new_callable=AsyncMock),
            patch(
                "runsight_core.isolation.handlers._perform_http_request",
                new_callable=AsyncMock,
                return_value={"status_code": 200, "body": "ok", "headers": {}},
            ),
        ):
            result = await handler(
                {
                    "method": "GET",
                    "url": "https://api.example.com/any/path/here",
                    "headers": {},
                }
            )
        assert "error" not in result


# ---------------------------------------------------------------------------
# AC4: HTTP tool — SSRF blocks private/reserved IPs
# ---------------------------------------------------------------------------


class TestHTTPSSRFProtection:
    """HTTP handler must block requests targeting private/reserved IPs."""

    @pytest.mark.asyncio
    async def test_localhost_blocked(self, tmp_path: Path):
        """Requests to 127.0.0.1 are blocked by SSRF validation."""
        from runsight_core.isolation.handlers import make_http_handler

        handler = make_http_handler(credentials={}, url_allowlist=["127.0.0.1"])

        result = await handler(
            {
                "method": "GET",
                "url": "http://127.0.0.1:8080/admin",
                "headers": {},
            }
        )
        assert "error" in result
        assert "ssrf" in result["error"].lower() or "blocked" in result["error"].lower()

    @pytest.mark.asyncio
    async def test_private_ip_10_blocked(self, tmp_path: Path):
        """Requests to 10.x.x.x private range are blocked."""
        from runsight_core.isolation.handlers import make_http_handler

        handler = make_http_handler(credentials={}, url_allowlist=["192.168.1.1"])

        result = await handler(
            {
                "method": "GET",
                "url": "http://10.0.0.1/internal",
                "headers": {},
            }
        )
        assert "error" in result

    @pytest.mark.asyncio
    async def test_private_ip_192_168_blocked(self, tmp_path: Path):
        """Requests to 192.168.x.x private range are blocked."""
        from runsight_core.isolation.handlers import make_http_handler

        handler = make_http_handler(credentials={}, url_allowlist=["169.254.169.254"])

        result = await handler(
            {
                "method": "GET",
                "url": "http://192.168.1.1/router",
                "headers": {},
            }
        )
        assert "error" in result

    @pytest.mark.asyncio
    async def test_link_local_169_254_blocked(self, tmp_path: Path):
        """Requests to 169.254.x.x (link-local / cloud metadata) are blocked."""
        from runsight_core.isolation.handlers import make_http_handler

        handler = make_http_handler(credentials={}, url_allowlist=["*"])

        result = await handler(
            {
                "method": "GET",
                "url": "http://169.254.169.254/latest/meta-data/",
                "headers": {},
            }
        )
        assert "error" in result

    @pytest.mark.asyncio
    async def test_public_ip_allowed(self, tmp_path: Path):
        """Requests to public IPs pass SSRF validation."""
        from unittest.mock import AsyncMock, patch

        from runsight_core.isolation.handlers import make_http_handler

        handler = make_http_handler(credentials={}, url_allowlist=["8.8.8.8"])

        # 8.8.8.8 is public (Google DNS)
        with (
            patch("runsight_core.isolation.handlers.validate_ssrf", new_callable=AsyncMock),
            patch(
                "runsight_core.isolation.handlers._perform_http_request",
                new_callable=AsyncMock,
                return_value={"status_code": 200, "body": "ok", "headers": {}},
            ),
        ):
            result = await handler(
                {
                    "method": "GET",
                    "url": "http://8.8.8.8/",
                    "headers": {},
                }
            )
        assert "error" not in result


# ---------------------------------------------------------------------------
# RUN-811: Real HTTP transport contract (httpx + allowlist + SSRF)
# ---------------------------------------------------------------------------


class TestRUN811RealHTTPHandlerContract:
    """RUN-811: make_http_handler must perform real httpx requests with strict controls."""

    @pytest.mark.asyncio
    async def test_allowed_host_uses_httpx_and_returns_actual_body_status_headers(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        from unittest.mock import AsyncMock

        from runsight_core.isolation import handlers as handlers_module
        from runsight_core.isolation.handlers import make_http_handler

        captured: dict[str, Any] = {}

        class _FakeResponse:
            status_code = 200
            headers = {"content-type": "application/json"}
            text = '{"ok": true, "source": "mock"}'

        class _FakeAsyncClient:
            async def __aenter__(self):
                return self

            async def __aexit__(self, exc_type, exc, tb):
                return False

            async def request(
                self, method: str, url: str, headers: dict[str, str], json: Any = None
            ):
                captured["method"] = method
                captured["url"] = url
                captured["headers"] = dict(headers)
                captured["json"] = json
                return _FakeResponse()

        fake_httpx = type("FakeHTTPX", (), {"AsyncClient": _FakeAsyncClient})
        monkeypatch.setattr(handlers_module, "httpx", fake_httpx, raising=False)
        monkeypatch.setattr(handlers_module, "validate_ssrf", AsyncMock(return_value=None))

        handler = make_http_handler(
            credentials={"api.example.com": {"Authorization": "Bearer host-token"}},
            url_allowlist=["api.example.com"],
        )
        result = await handler(
            {
                "method": "GET",
                "url": "https://api.example.com/data",
                "headers": {"Accept": "application/json"},
            }
        )

        assert captured["method"] == "GET"
        assert captured["url"] == "https://api.example.com/data"
        assert captured["headers"]["Authorization"] == "Bearer host-token"
        assert result["status_code"] == 200
        assert result["body"] == '{"ok": true, "source": "mock"}'
        assert result["headers"]["content-type"] == "application/json"

    @pytest.mark.asyncio
    async def test_empty_allowlist_blocks_request_before_httpx(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        from unittest.mock import AsyncMock

        from runsight_core.isolation import handlers as handlers_module
        from runsight_core.isolation.handlers import make_http_handler

        captured: dict[str, Any] = {"http_calls": 0}

        class _FakeAsyncClient:
            async def __aenter__(self):
                return self

            async def __aexit__(self, exc_type, exc, tb):
                return False

            async def request(self, *args: Any, **kwargs: Any):
                captured["http_calls"] += 1
                raise AssertionError("httpx must not run when allowlist blocks request")

        fake_httpx = type("FakeHTTPX", (), {"AsyncClient": _FakeAsyncClient})
        monkeypatch.setattr(handlers_module, "httpx", fake_httpx, raising=False)
        monkeypatch.setattr(handlers_module, "validate_ssrf", AsyncMock(return_value=None))

        handler = make_http_handler(credentials={}, url_allowlist=[])
        result = await handler(
            {
                "method": "GET",
                "url": "https://api.example.com/private",
                "headers": {},
            }
        )

        assert "error" in result
        assert "Host not on allowed list" in result["error"]
        assert captured["http_calls"] == 0

    @pytest.mark.asyncio
    async def test_per_host_credentials_are_scoped_to_request_host(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        from unittest.mock import AsyncMock

        from runsight_core.isolation import handlers as handlers_module
        from runsight_core.isolation.handlers import make_http_handler

        captured: dict[str, Any] = {}

        class _FakeResponse:
            status_code = 200
            headers = {}
            text = "ok"

        class _FakeAsyncClient:
            async def __aenter__(self):
                return self

            async def __aexit__(self, exc_type, exc, tb):
                return False

            async def request(
                self, method: str, url: str, headers: dict[str, str], json: Any = None
            ):
                captured["headers"] = dict(headers)
                return _FakeResponse()

        fake_httpx = type("FakeHTTPX", (), {"AsyncClient": _FakeAsyncClient})
        monkeypatch.setattr(handlers_module, "httpx", fake_httpx, raising=False)
        monkeypatch.setattr(handlers_module, "validate_ssrf", AsyncMock(return_value=None))

        handler = make_http_handler(
            credentials={
                "host-a.com": {"Authorization": "Bearer host-a", "X-Host-A": "yes"},
                "host-b.com": {"Authorization": "Bearer host-b", "X-Host-B": "yes"},
            },
            url_allowlist=["host-a.com", "host-b.com"],
        )

        _ = await handler(
            {
                "method": "POST",
                "url": "https://host-a.com/v1/data",
                "headers": {"Content-Type": "application/json"},
                "json": {"value": 1},
            }
        )

        assert captured["headers"]["Authorization"] == "Bearer host-a"
        assert captured["headers"]["X-Host-A"] == "yes"
        assert "X-Host-B" not in captured["headers"]

    @pytest.mark.asyncio
    async def test_redirect_is_not_followed_by_default(self, monkeypatch: pytest.MonkeyPatch):
        from unittest.mock import AsyncMock

        from runsight_core.isolation import handlers as handlers_module
        from runsight_core.isolation.handlers import make_http_handler

        captured: dict[str, Any] = {"calls": 0, "client_kwargs": None}

        class _FakeResponse:
            status_code = 302
            headers = {"location": "https://api.example.com/new-location"}
            text = "redirect"

        class _FakeAsyncClient:
            def __init__(self, **kwargs: Any):
                captured["client_kwargs"] = dict(kwargs)

            async def __aenter__(self):
                return self

            async def __aexit__(self, exc_type, exc, tb):
                return False

            async def request(
                self, method: str, url: str, headers: dict[str, str], json: Any = None
            ):
                captured["calls"] += 1
                return _FakeResponse()

        fake_httpx = type("FakeHTTPX", (), {"AsyncClient": _FakeAsyncClient})
        monkeypatch.setattr(handlers_module, "httpx", fake_httpx, raising=False)
        monkeypatch.setattr(handlers_module, "validate_ssrf", AsyncMock(return_value=None))

        handler = make_http_handler(credentials={}, url_allowlist=["api.example.com"])
        result = await handler(
            {
                "method": "GET",
                "url": "https://api.example.com/old-location",
                "headers": {},
                "follow_redirects": True,
            }
        )

        assert captured["client_kwargs"]["follow_redirects"] is False
        assert captured["calls"] == 1
        assert result["status_code"] == 302
        assert result["headers"]["location"] == "https://api.example.com/new-location"

    @pytest.mark.asyncio
    async def test_response_body_over_max_response_bytes_returns_error(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        from unittest.mock import AsyncMock

        from runsight_core.isolation import handlers as handlers_module
        from runsight_core.isolation.handlers import make_http_handler

        class _FakeResponse:
            status_code = 200
            headers = {}
            text = "too-large"

        class _FakeAsyncClient:
            def __init__(self, **_kwargs: Any):
                return None

            async def __aenter__(self):
                return self

            async def __aexit__(self, exc_type, exc, tb):
                return False

            async def request(
                self, method: str, url: str, headers: dict[str, str], json: Any = None
            ):
                return _FakeResponse()

        fake_httpx = type("FakeHTTPX", (), {"AsyncClient": _FakeAsyncClient})
        monkeypatch.setattr(handlers_module, "httpx", fake_httpx, raising=False)
        monkeypatch.setattr(handlers_module, "validate_ssrf", AsyncMock(return_value=None))

        handler = make_http_handler(credentials={}, url_allowlist=["api.example.com"])
        result = await handler(
            {
                "method": "GET",
                "url": "https://api.example.com/large",
                "headers": {},
                "max_response_bytes": 4,
            }
        )

        assert result == {"error": "response body exceeds max_response_bytes=4"}

    @pytest.mark.asyncio
    async def test_private_ip_request_returns_ssrf_error_without_httpx_call(
        self, monkeypatch: pytest.MonkeyPatch
    ):
        from unittest.mock import AsyncMock

        from runsight_core.isolation import handlers as handlers_module
        from runsight_core.isolation.handlers import make_http_handler
        from runsight_core.security import SSRFError

        captured: dict[str, Any] = {"http_calls": 0}

        class _FakeAsyncClient:
            async def __aenter__(self):
                return self

            async def __aexit__(self, exc_type, exc, tb):
                return False

            async def request(self, *args: Any, **kwargs: Any):
                captured["http_calls"] += 1
                raise AssertionError("httpx must not run after SSRF validation fails")

        fake_httpx = type("FakeHTTPX", (), {"AsyncClient": _FakeAsyncClient})
        monkeypatch.setattr(handlers_module, "httpx", fake_httpx, raising=False)
        monkeypatch.setattr(
            handlers_module,
            "validate_ssrf",
            AsyncMock(side_effect=SSRFError("SSRF blocked private IP 10.0.0.1")),
        )

        handler = make_http_handler(credentials={}, url_allowlist=["10.0.0.1"])
        result = await handler(
            {
                "method": "GET",
                "url": "http://10.0.0.1/internal",
                "headers": {},
            }
        )

        assert "error" in result
        assert "ssrf" in result["error"].lower()
        assert captured["http_calls"] == 0


# ---------------------------------------------------------------------------
# AC5: File I/O — base_dir scoped per workflow
# ---------------------------------------------------------------------------


class TestFileIOBaseDir:
    """File I/O handler must scope all paths to a per-workflow base directory."""

    @pytest.mark.asyncio
    async def test_file_io_handler_requires_base_dir(self, tmp_path: Path):
        """make_file_io_handler requires a base_dir parameter."""
        from runsight_core.isolation.handlers import make_file_io_handler

        base = tmp_path / "workflow-files"
        base.mkdir()

        handler = make_file_io_handler(base_dir=str(base))
        assert handler is not None

    @pytest.mark.asyncio
    async def test_read_resolves_relative_to_base_dir(self, tmp_path: Path):
        """Reading a file resolves the path relative to base_dir."""
        from runsight_core.isolation.handlers import make_file_io_handler

        base = tmp_path / "wf-data"
        base.mkdir()
        (base / "notes.txt").write_text("hello from base")

        handler = make_file_io_handler(base_dir=str(base))
        result = await handler(
            {
                "action_type": "read",
                "path": "notes.txt",
            }
        )

        assert result.get("content") == "hello from base"

    @pytest.mark.asyncio
    async def test_write_resolves_relative_to_base_dir(self, tmp_path: Path):
        """Writing a file places it inside base_dir."""
        from runsight_core.isolation.handlers import make_file_io_handler

        base = tmp_path / "wf-output"
        base.mkdir()

        handler = make_file_io_handler(base_dir=str(base))
        result = await handler(
            {
                "action_type": "write",
                "path": "output.txt",
                "content": "result data",
            }
        )

        assert "error" not in result
        assert (base / "output.txt").read_text() == "result data"

    @pytest.mark.asyncio
    async def test_write_over_max_write_bytes_is_rejected(self, tmp_path: Path):
        """File writes are capped engine-side to avoid disk exhaustion."""
        from runsight_core.isolation.handlers import make_file_io_handler

        base = tmp_path / "wf-output"
        base.mkdir()

        handler = make_file_io_handler(base_dir=str(base), max_write_bytes=4)
        result = await handler(
            {
                "action_type": "write",
                "path": "too-large.txt",
                "content": "12345",
            }
        )

        assert result == {"error": "file write exceeds max_write_bytes=4"}
        assert not (base / "too-large.txt").exists()

    @pytest.mark.asyncio
    async def test_cumulative_writes_over_max_total_write_bytes_are_rejected(self, tmp_path: Path):
        """Many individually valid writes cannot exceed the handler's total write budget."""
        from runsight_core.isolation.handlers import make_file_io_handler

        base = tmp_path / "wf-output"
        base.mkdir()

        handler = make_file_io_handler(
            base_dir=str(base),
            max_write_bytes=10,
            max_total_write_bytes=8,
        )
        first = await handler(
            {
                "action_type": "write",
                "path": "first.txt",
                "content": "1234",
            }
        )
        second = await handler(
            {
                "action_type": "write",
                "path": "second.txt",
                "content": "56789",
            }
        )

        assert first == {"ok": True}
        assert second == {"error": "file writes exceed max_total_write_bytes=8"}
        assert (base / "first.txt").read_text() == "1234"
        assert not (base / "second.txt").exists()

    @pytest.mark.asyncio
    async def test_absolute_path_rejected(self, tmp_path: Path):
        """Absolute paths must be rejected — only relative paths within base_dir."""
        from runsight_core.isolation.handlers import make_file_io_handler

        base = tmp_path / "wf-safe"
        base.mkdir()

        handler = make_file_io_handler(base_dir=str(base))
        result = await handler(
            {
                "action_type": "read",
                "path": "/etc/passwd",
            }
        )

        assert "error" in result


# ---------------------------------------------------------------------------
# AC6: File I/O — path traversal blocked
# ---------------------------------------------------------------------------


class TestFileIOPathTraversal:
    """File I/O handler must block path traversal via '..' in path components."""

    @pytest.mark.asyncio
    async def test_dotdot_in_path_rejected(self, tmp_path: Path):
        """Paths containing '..' are rejected."""
        from runsight_core.isolation.handlers import make_file_io_handler

        base = tmp_path / "wf-guarded"
        base.mkdir()

        handler = make_file_io_handler(base_dir=str(base))
        result = await handler(
            {
                "action_type": "read",
                "path": "../../../etc/passwd",
            }
        )

        assert "error" in result
        assert "traversal" in result["error"].lower() or ".." in result["error"]

    @pytest.mark.asyncio
    async def test_dotdot_in_middle_of_path_rejected(self, tmp_path: Path):
        """Paths with '..' in a middle segment are rejected."""
        from runsight_core.isolation.handlers import make_file_io_handler

        base = tmp_path / "wf-mid"
        base.mkdir()

        handler = make_file_io_handler(base_dir=str(base))
        result = await handler(
            {
                "action_type": "read",
                "path": "subdir/../../secret.txt",
            }
        )

        assert "error" in result

    @pytest.mark.asyncio
    async def test_encoded_dotdot_rejected(self, tmp_path: Path):
        """URL-encoded '..' variants should also be caught."""
        from runsight_core.isolation.handlers import make_file_io_handler

        base = tmp_path / "wf-enc"
        base.mkdir()

        handler = make_file_io_handler(base_dir=str(base))

        # Even after normalization, if the resolved path escapes base_dir, it's blocked
        result = await handler(
            {
                "action_type": "read",
                "path": "subdir/%2e%2e/secret.txt",
            }
        )

        assert "error" in result

    @pytest.mark.asyncio
    async def test_write_with_traversal_rejected(self, tmp_path: Path):
        """Write operations with path traversal are blocked."""
        from runsight_core.isolation.handlers import make_file_io_handler

        base = tmp_path / "wf-write-guard"
        base.mkdir()

        handler = make_file_io_handler(base_dir=str(base))
        result = await handler(
            {
                "action_type": "write",
                "path": "../../escape.txt",
                "content": "malicious content",
            }
        )

        assert "error" in result
        # Ensure the file was NOT written outside base_dir
        assert not (tmp_path / "escape.txt").exists()

    @pytest.mark.asyncio
    async def test_symlink_to_sibling_prefix_directory_rejected(self, tmp_path: Path):
        """Symlink escapes to a similarly named sibling must be rejected."""
        from runsight_core.isolation.handlers import make_file_io_handler

        base = tmp_path / "wf-safe"
        sibling = tmp_path / "wf-safe-escape"
        base.mkdir()
        sibling.mkdir()
        (sibling / "secret.txt").write_text("outside")
        (base / "escape-link").symlink_to(sibling, target_is_directory=True)

        handler = make_file_io_handler(base_dir=str(base))
        result = await handler(
            {
                "action_type": "read",
                "path": "escape-link/secret.txt",
            }
        )

        assert "error" in result
        assert "escape" in result["error"].lower() or "base" in result["error"].lower()


# ---------------------------------------------------------------------------
# AC7: ${ENV_VAR} resolved at engine level
# ---------------------------------------------------------------------------


class TestEnvVarResolution:
    """${ENV_VAR} references in tool configs must be resolved at engine level."""

    def test_resolve_env_var_reference(self, monkeypatch):
        """${MY_TOKEN} in a credential config resolves to the env var value."""
        from runsight_core.isolation.credentials import resolve_credential_refs

        monkeypatch.setenv("MY_TOKEN", "resolved-secret-value")

        config = {"Authorization": "Bearer ${MY_TOKEN}"}
        resolved = resolve_credential_refs(config)

        assert resolved["Authorization"] == "Bearer resolved-secret-value"

    def test_resolve_multiple_refs_in_one_value(self, monkeypatch):
        """Multiple ${VAR} references in one string are all resolved."""
        from runsight_core.isolation.credentials import resolve_credential_refs

        monkeypatch.setenv("USER_ID", "user-42")
        monkeypatch.setenv("API_SECRET", "s3cr3t")

        config = {"X-Custom": "${USER_ID}:${API_SECRET}"}
        resolved = resolve_credential_refs(config)

        assert resolved["X-Custom"] == "user-42:s3cr3t"

    def test_resolve_nested_dict(self, monkeypatch):
        """Nested dicts have their ${VAR} references resolved recursively."""
        from runsight_core.isolation.credentials import resolve_credential_refs

        monkeypatch.setenv("DB_PASS", "p@ssw0rd")

        config = {
            "headers": {"Authorization": "Basic ${DB_PASS}"},
            "params": {"key": "${DB_PASS}"},
        }
        resolved = resolve_credential_refs(config)

        assert resolved["headers"]["Authorization"] == "Basic p@ssw0rd"
        assert resolved["params"]["key"] == "p@ssw0rd"

    def test_plain_strings_unchanged(self):
        """Strings without ${...} are returned unchanged."""
        from runsight_core.isolation.credentials import resolve_credential_refs

        config = {"host": "api.example.com", "port": "443"}
        resolved = resolve_credential_refs(config)

        assert resolved == config


# ---------------------------------------------------------------------------
# AC8: Undefined ${ENV_VAR} produces clear error
# ---------------------------------------------------------------------------


class TestUndefinedEnvVarError:
    """Undefined ${ENV_VAR} must produce a clear error, not silent empty string."""

    def test_undefined_var_raises(self):
        """Referencing an undefined env var raises a clear error."""
        from runsight_core.isolation.credentials import resolve_credential_refs

        config = {"Authorization": "Bearer ${TOTALLY_UNDEFINED_VAR}"}

        with pytest.raises(Exception) as exc_info:
            resolve_credential_refs(config)

        error_msg = str(exc_info.value)
        assert "TOTALLY_UNDEFINED_VAR" in error_msg

    def test_undefined_var_not_empty_string(self, monkeypatch):
        """An undefined var must NOT silently become an empty string."""
        from runsight_core.isolation.credentials import resolve_credential_refs

        # Make sure the var is truly undefined
        monkeypatch.delenv("NONEXISTENT_SECRET", raising=False)

        config = {"token": "${NONEXISTENT_SECRET}"}

        with pytest.raises(Exception):
            resolve_credential_refs(config)

    def test_error_message_names_the_variable(self):
        """The error message must name the undefined variable for debugging."""
        from runsight_core.isolation.credentials import resolve_credential_refs

        config = {"key": "${MISSING_KEY_XYZ}"}

        with pytest.raises(Exception) as exc_info:
            resolve_credential_refs(config)

        assert "MISSING_KEY_XYZ" in str(exc_info.value)

    def test_partially_defined_config_reports_first_missing(self, monkeypatch):
        """When some vars exist and some don't, error names the missing one."""
        from runsight_core.isolation.credentials import resolve_credential_refs

        monkeypatch.setenv("GOOD_VAR", "exists")

        config = {
            "good": "${GOOD_VAR}",
            "bad": "${DOES_NOT_EXIST_999}",
        }

        with pytest.raises(Exception) as exc_info:
            resolve_credential_refs(config)

        assert "DOES_NOT_EXIST_999" in str(exc_info.value)
