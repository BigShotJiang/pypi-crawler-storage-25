# Changelog

All notable changes to skill-blast are documented here.  
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

---

## [Unreleased]

## [2.0.2] — 2026-05-11

### Fixed
- **Concurrent Git Conflicts**: Resolved errors such as `Another git process seems to be running in this repository` and random command failures caused by multi-threaded `git fetch/reset` operations simultaneously targeting the same locally cached GitHub repository when multiple skills exist in a single repository. Implemented per-repository thread locks (`_REPO_LOCKS`) and an `UPDATED_REPOS` cache.


## [2.0.1] — 2026-05-11

### Fixed
- **Permission Denied Error**: Resolved `[Errno 13] Permission denied` errors during `--update` by correctly ignoring `.git` directories when copying from cache to central store.
- **Fast-forward Error**: Resolved `fatal: Cannot fast-forward to multiple branches` error by using explicit `git fetch` and `git reset --hard FETCH_HEAD` instead of `git pull --ff-only`.


## [2.0.0] — 2026-05-11

### Added
- **Frontmatter Auto-Injector**: Solved Claude Code ignoring 24 skills by auto-generating YAML frontmatter dynamically. All 50 skills are now visible in Claude Code.
- **Interactive Terminal UI**: Added a sleek, interactive multi-select TUI powered by `questionary` when running without flags.
- **Custom Skill Adder**: Added `--add <github-repo>` flag so users can inject arbitrary GitHub repositories into their local skill-blast database persistently.
- **Update with Safe Backup**: `--update` now properly pulls the newest branch and writes a `SKILL.md.bak` file before overwriting, protecting local user tweaks.


## [1.1.1] — 2026-05-11

### Fixed
- Fixed 8 skills that were pointing to "awesome-list" repos instead of the actual skill repositories (`nothing-design`, `dev-browser`, `generative-media`, `design-auditor`, `personal-health`, `dna-analysis`, `twitter-algorithm`, `competitive-ads`).


## [1.1.0] — 2026-05-11

### Added
- Concurrent multi-threaded skill installation (8 threads) — ~5x faster downloads.
- Dynamic `M/N` progress counter (e.g. `21/50`) during install and uninstall.

### Changed
- Thread-safe `FAILED_REPOS` tracking with `threading.Lock` in installer module.


## [1.0.1] — 2026-05-11

### Fixed
- Fixed `UnicodeEncodeError` crashes on Windows by enforcing `utf-8` on stdout/stderr.
- Fixed integration test crashes on Windows CI by forcing `utf-8` decoding in subprocesses.
- Skipped symlink creation tests on Windows CI runners missing Developer Mode.
- Updated `actions/checkout` to v5 and `actions/setup-python` to v6 in CI pipelines.
### Added
- `--uninstall` flag to remove installed skills from agent directories
- `--check` flag for health diagnostics (broken symlinks, cache/store status, git connectivity)
- `--version` flag to print current version
- Integration tests for installer logic (mocked filesystem + subprocess)
- Agent detection tests
- Troubleshooting guide in README
- Management commands section in README
- `--info <ID>` flag to show detailed skill metadata
- `CODE_OF_CONDUCT.md` for the community
- CLI integration tests (`tests/test_cli_integration.py`)
- Social preview image for GitHub sharing

### Changed
- Replaced `YOUR_USERNAME` placeholder with `Venkatesh-6921` in all files

## [1.0.0] — 2026-05-10

### Added
- 50 curated AI agent skills across 9 categories
- Interactive wizard for non-developers (no flags needed)
- Auto-detection for 8 agents: Claude Code, OpenCode, Antigravity, Gemini CLI, Cursor, Windsurf, Continue.dev, Aider
- Cross-platform: Linux, macOS, Windows
- One-liner installers: `install.sh`, `install.ps1`, `install.bat`
- PyPI package: `pip install skill-blast`
- `--dry-run`, `--update`, `--list`, `--only`, `--skip`, `--agents` flags
- Symlink-based install on Linux/macOS (copy-based on Windows)
- Central skill store at `~/.skill-blast/` shared across all agents
- Rich TUI with progress bar, live status, summary table
