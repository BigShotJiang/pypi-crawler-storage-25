"""Bundled ASO configuration data."""
