"""Bundled ASO prompt templates."""
