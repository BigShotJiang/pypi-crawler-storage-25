"""Tests for the Agenitry Python SDK — mirrors the TypeScript SDK test suite."""

import json
from unittest.mock import patch, MagicMock
from urllib.error import HTTPError, URLError
from io import BytesIO

import pytest

from agenitry import Agenitry, AgenitryError, create_agenitry


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_response(data, status=200):
    """Create a mock response object for urlopen."""
    resp = MagicMock()
    resp.read.return_value = json.dumps(data).encode("utf-8")
    resp.__enter__ = MagicMock(return_value=resp)
    resp.__exit__ = MagicMock(return_value=False)
    return resp


def make_http_error(status, reason="Error", body=None):
    """Create an HTTPError for testing."""
    error_body = json.dumps(body or {}).encode("utf-8") if body else b""
    return HTTPError(
        url="https://api.agenitry.com/v1/events",
        code=status,
        msg=reason,
        hdrs={},
        fp=BytesIO(error_body),
    )


# ---------------------------------------------------------------------------
# Constructor tests
# ---------------------------------------------------------------------------

class TestConstructor:
    def test_requires_api_key(self):
        with pytest.raises(AgenitryError, match="api_key"):
            Agenitry(api_key="", venue_id="my-venue")

    def test_requires_venue_id(self):
        with pytest.raises(AgenitryError, match="venue_id"):
            Agenitry(api_key="ag_xxx", venue_id="")

    def test_uses_default_base_url(self):
        agent = Agenitry(api_key="ag_xxx", venue_id="my-venue")
        assert agent.base_url == "https://api.agenitry.com"

    def test_strips_trailing_slashes(self):
        agent = Agenitry(api_key="ag_xxx", venue_id="my-venue", base_url="https://api.agenitry.com///")
        assert agent.base_url == "https://api.agenitry.com"


# ---------------------------------------------------------------------------
# create_agenitry factory
# ---------------------------------------------------------------------------

class TestCreateAgenitry:
    def test_returns_agenitry_instance(self):
        agent = create_agenitry(api_key="ag_xxx", venue_id="my-venue")
        assert isinstance(agent, Agenitry)


# ---------------------------------------------------------------------------
# log() tests
# ---------------------------------------------------------------------------

class TestLog:
    @patch("agenitry.urlopen")
    def test_sends_post_to_events(self, mock_urlopen):
        mock_urlopen.return_value = make_response(
            {"id": "evt_123", "status": "logged", "created_at": "2025-01-01T00:00:00Z"}
        )
        agent = Agenitry(api_key="ag_test", venue_id="my-venue")
        result = agent.log(action="order_captured", amount=42.5, await_confirmation=True)

        assert result["id"] == "evt_123"
        assert result["status"] == "logged"
        call_args = mock_urlopen.call_args
        req = call_args[0][0]
        assert req.method == "POST"
        assert req.full_url == "https://api.agenitry.com/v1/events"

    @patch("agenitry.urlopen")
    def test_uses_agent_id_from_payload(self, mock_urlopen):
        mock_urlopen.return_value = make_response(
            {"id": "evt_123", "status": "logged", "created_at": "2025-01-01T00:00:00Z"}
        )
        agent = Agenitry(api_key="ag_test", venue_id="my-venue", agent_id="default-agent")
        agent.log(action="order_captured", agent_id="custom-agent", await_confirmation=True)

        body = json.loads(mock_urlopen.call_args[0][0].data)
        assert body["agent_id"] == "custom-agent"

    @patch("agenitry.urlopen")
    def test_sends_authorization_header(self, mock_urlopen):
        mock_urlopen.return_value = make_response(
            {"id": "evt_123", "status": "logged", "created_at": "2025-01-01T00:00:00Z"}
        )
        agent = Agenitry(api_key="ag_test", venue_id="my-venue")
        agent.log(action="order_captured", await_confirmation=True)

        req = mock_urlopen.call_args[0][0]
        assert req.get_header("Authorization") == "Bearer ag_test"

    @patch("agenitry.urlopen")
    def test_fire_and_forget_swallows_errors(self, mock_urlopen):
        mock_urlopen.side_effect = URLError("Connection refused")
        agent = Agenitry(api_key="ag_test", venue_id="my-venue")
        result = agent.log(action="order_captured")  # should NOT raise
        assert result["status"] == "logged"
        assert result["id"] == ""

    @patch("agenitry.urlopen")
    def test_await_mode_propagates_errors(self, mock_urlopen):
        mock_urlopen.side_effect = URLError("Connection refused")
        agent = Agenitry(api_key="ag_test", venue_id="my-venue")
        with pytest.raises(AgenitryError, match="network error"):
            agent.log(action="order_captured", await_confirmation=True)

    @patch("agenitry.urlopen")
    def test_retries_on_429(self, mock_urlopen):
        mock_urlopen.side_effect = [
            make_http_error(429, "Too Many Requests"),
            make_response({"id": "evt_123", "status": "logged", "created_at": "2025-01-01T00:00:00Z"}),
        ]
        agent = Agenitry(api_key="ag_test", venue_id="my-venue", max_retries=2, retry_base_delay=0.01)
        result = agent.log(action="order_captured", await_confirmation=True)
        assert result["id"] == "evt_123"

    @patch("agenitry.urlopen")
    def test_retries_on_500(self, mock_urlopen):
        mock_urlopen.side_effect = [
            make_http_error(500, "Internal Server Error"),
            make_response({"id": "evt_123", "status": "logged", "created_at": "2025-01-01T00:00:00Z"}),
        ]
        agent = Agenitry(api_key="ag_test", venue_id="my-venue", max_retries=2, retry_base_delay=0.01)
        result = agent.log(action="order_captured", await_confirmation=True)
        assert result["id"] == "evt_123"

    @patch("agenitry.urlopen")
    def test_does_not_retry_on_400(self, mock_urlopen):
        mock_urlopen.side_effect = make_http_error(400, "Bad Request", {"error": "Invalid action"})
        agent = Agenitry(api_key="ag_test", venue_id="my-venue", max_retries=2, retry_base_delay=0.01)
        with pytest.raises(AgenitryError) as exc_info:
            agent.log(action="order_captured", await_confirmation=True)
        assert exc_info.value.status == 400

    @patch("agenitry.urlopen")
    def test_throws_agenitry_error_with_status_and_body(self, mock_urlopen):
        mock_urlopen.side_effect = make_http_error(401, "Unauthorized", {"error": "Invalid API key"})
        agent = Agenitry(api_key="ag_test", venue_id="my-venue")
        with pytest.raises(AgenitryError) as exc_info:
            agent.log(action="order_captured", await_confirmation=True)
        assert exc_info.value.status == 401
        assert exc_info.value.body == {"error": "Invalid API key"}

    @patch("agenitry.urlopen")
    def test_throws_network_error_on_url_error(self, mock_urlopen):
        mock_urlopen.side_effect = URLError("Connection refused")
        agent = Agenitry(api_key="ag_test", venue_id="my-venue")
        with pytest.raises(AgenitryError) as exc_info:
            agent.log(action="order_captured", await_confirmation=True)
        assert exc_info.value.code == "NETWORK"


# ---------------------------------------------------------------------------
# events() tests
# ---------------------------------------------------------------------------

class TestEvents:
    @patch("agenitry.urlopen")
    def test_fetches_events_with_default_params(self, mock_urlopen):
        mock_urlopen.return_value = make_response(
            {"venue_id": "my-venue", "total": 1, "limit": 50, "offset": 0, "has_more": False, "events": []}
        )
        agent = Agenitry(api_key="ag_test", venue_id="my-venue")
        result = agent.events()
        assert result["venue_id"] == "my-venue"

    @patch("agenitry.urlopen")
    def test_passes_query_parameters(self, mock_urlopen):
        mock_urlopen.return_value = make_response(
            {"venue_id": "my-venue", "total": 0, "limit": 10, "offset": 0, "has_more": False, "events": []}
        )
        agent = Agenitry(api_key="ag_test", venue_id="my-venue")
        agent.events(agent_id="voice-agent", action="order_captured", limit=10)
        req = mock_urlopen.call_args[0][0]
        assert "agent_id=voice-agent" in req.full_url
        assert "action=order_captured" in req.full_url
        assert "limit=10" in req.full_url

    @patch("agenitry.urlopen")
    def test_url_encodes_venue_ids(self, mock_urlopen):
        mock_urlopen.return_value = make_response(
            {"venue_id": "my venue", "total": 0, "limit": 50, "offset": 0, "has_more": False, "events": []}
        )
        agent = Agenitry(api_key="ag_test", venue_id="my venue")
        agent.events()
        req = mock_urlopen.call_args[0][0]
        assert "my%20venue" in req.full_url


# ---------------------------------------------------------------------------
# stats() tests
# ---------------------------------------------------------------------------

class TestStats:
    @patch("agenitry.urlopen")
    def test_fetches_stats_with_default_period(self, mock_urlopen):
        mock_urlopen.return_value = make_response(
            {"venue_id": "my-venue", "period": "today", "total_inbound": 0, "total_outbound": 0, "event_count": 0, "by_agent": {}}
        )
        agent = Agenitry(api_key="ag_test", venue_id="my-venue")
        result = agent.stats()
        assert result["period"] == "today"

    @patch("agenitry.urlopen")
    def test_passes_period_parameter(self, mock_urlopen):
        mock_urlopen.return_value = make_response(
            {"venue_id": "my-venue", "period": "7d", "total_inbound": 0, "total_outbound": 0, "event_count": 0, "by_agent": {}}
        )
        agent = Agenitry(api_key="ag_test", venue_id="my-venue")
        agent.stats(period="7d")
        req = mock_urlopen.call_args[0][0]
        assert "period=7d" in req.full_url

    @patch("agenitry.urlopen")
    def test_returns_by_agent_breakdown(self, mock_urlopen):
        mock_urlopen.return_value = make_response(
            {"venue_id": "my-venue", "period": "7d", "total_inbound": 100, "total_outbound": 50, "event_count": 10, "by_agent": {"agent-1": {"events": 10, "inbound": 100, "outbound": 50}}}
        )
        agent = Agenitry(api_key="ag_test", venue_id="my-venue")
        result = agent.stats(period="7d")
        assert "agent-1" in result["by_agent"]


# ---------------------------------------------------------------------------
# All 6 event actions
# ---------------------------------------------------------------------------

class TestEventActions:
    @patch("agenitry.urlopen")
    def test_logs_action_order_captured(self, mock_urlopen):
        _test_action(mock_urlopen, "order_captured")

    @patch("agenitry.urlopen")
    def test_logs_action_reservation_booked(self, mock_urlopen):
        _test_action(mock_urlopen, "reservation_booked")

    @patch("agenitry.urlopen")
    def test_logs_action_price_changed(self, mock_urlopen):
        _test_action(mock_urlopen, "price_changed")

    @patch("agenitry.urlopen")
    def test_logs_action_item_86d(self, mock_urlopen):
        _test_action(mock_urlopen, "item_86d")

    @patch("agenitry.urlopen")
    def test_logs_action_comp_issued(self, mock_urlopen):
        _test_action(mock_urlopen, "comp_issued")

    @patch("agenitry.urlopen")
    def test_logs_action_purchase_order(self, mock_urlopen):
        _test_action(mock_urlopen, "purchase_order")


def _test_action(mock_urlopen, action):
    mock_urlopen.return_value = make_response(
        {"id": "evt_123", "status": "logged", "created_at": "2025-01-01T00:00:00Z"}
    )
    agent = Agenitry(api_key="ag_test", venue_id="my-venue")
    result = agent.log(action=action, await_confirmation=True)
    body = json.loads(mock_urlopen.call_args[0][0].data)
    assert body["action"] == action


# ---------------------------------------------------------------------------
# All 3 event directions
# ---------------------------------------------------------------------------

class TestEventDirections:
    @patch("agenitry.urlopen")
    def test_logs_direction_inbound(self, mock_urlopen):
        _test_direction(mock_urlopen, "inbound")

    @patch("agenitry.urlopen")
    def test_logs_direction_outbound(self, mock_urlopen):
        _test_direction(mock_urlopen, "outbound")

    @patch("agenitry.urlopen")
    def test_logs_direction_internal(self, mock_urlopen):
        _test_direction(mock_urlopen, "internal")


def _test_direction(mock_urlopen, direction):
    mock_urlopen.return_value = make_response(
        {"id": "evt_123", "status": "logged", "created_at": "2025-01-01T00:00:00Z"}
    )
    agent = Agenitry(api_key="ag_test", venue_id="my-venue")
    agent.log(action="order_captured", direction=direction, await_confirmation=True)
    body = json.loads(mock_urlopen.call_args[0][0].data)
    assert body["direction"] == direction