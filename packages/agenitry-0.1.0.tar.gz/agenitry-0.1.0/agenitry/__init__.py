"""
Agenitry SDK — Official Python client for the Agenitry audit-trail API.

Usage:
    from agenitry import Agenitry

    agent = Agenitry(api_key="ag_your_key", venue_id="my-venue")

    # Fire-and-forget — never blocks, never raises
    agent.log(action="order_captured", amount=42.50)

    # Query events
    result = agent.events(limit=10)

    # Pull stats
    stats = agent.stats(period="7d")
"""

from __future__ import annotations

import json
import time
from typing import Any, Literal, Optional
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, quote

# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------

EventAction = Literal[
    "order_captured",
    "reservation_booked",
    "price_changed",
    "item_86d",
    "comp_issued",
    "purchase_order",
]

EventDirection = Literal["inbound", "outbound", "internal"]

StatsPeriod = Literal["today", "7d", "30d", "all"]


# ---------------------------------------------------------------------------
# Error
# ---------------------------------------------------------------------------

class AgenitryError(Exception):
    """Error thrown by the Agenitry SDK.

    Attributes:
        status: HTTP status code (0 if no response was received).
        body: Parsed response body (if available).
        code: Machine-readable error code ('NETWORK', 'TIMEOUT', 'API').
    """

    def __init__(
        self,
        message: str,
        status: int = 0,
        body: Any = None,
        code: Literal["NETWORK", "TIMEOUT", "API"] = "API",
    ):
        super().__init__(message)
        self.status = status
        self.body = body
        self.code = code

    def __repr__(self) -> str:
        return f"AgenitryError(status={self.status}, code={self.code}, message={self.args[0]!r})"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_DEFAULT_BASE_URL = "https://api.agenitry.com"
_DEFAULT_MAX_RETRIES = 2
_DEFAULT_RETRY_BASE_DELAY = 0.5  # seconds


def _is_retryable(status: int) -> bool:
    return status == 429 or status >= 500


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------

class Agenitry:
    """Agenitry client — the main entry point for the SDK.

    Usage:
        from agenitry import Agenitry

        agent = Agenitry(api_key="ag_xxx", venue_id="my-venue")
        agent.log(action="order_captured", amount=42.5)
    """

    def __init__(
        self,
        api_key: str,
        venue_id: str,
        *,
        base_url: str = _DEFAULT_BASE_URL,
        agent_id: str = "default",
        max_retries: int = _DEFAULT_MAX_RETRIES,
        retry_base_delay: float = _DEFAULT_RETRY_BASE_DELAY,
    ):
        if not api_key:
            raise AgenitryError("Agenitry: `api_key` is required", code="API")
        if not venue_id:
            raise AgenitryError("Agenitry: `venue_id` is required", code="API")

        self.api_key = api_key
        self.venue_id = venue_id
        self.base_url = base_url.rstrip("/")
        self.agent_id = agent_id
        self.max_retries = max_retries
        self.retry_base_delay = retry_base_delay

    # -------------------------------------------------------------------
    # log() — fire-and-forget event logging
    # -------------------------------------------------------------------

    def log(
        self,
        action: EventAction,
        *,
        amount: Optional[float] = None,
        currency: Optional[str] = None,
        direction: Optional[EventDirection] = None,
        context: Optional[dict[str, Any]] = None,
        reason: Optional[str] = None,
        agent_id: Optional[str] = None,
        await_confirmation: bool = False,
    ) -> dict[str, Any]:
        """Log an event to the audit trail.

        This method is **fire-and-forget** by default — it never raises.
        If you need confirmation, set ``await_confirmation=True``.

        Args:
            action: What happened. One of the six canonical actions.
            amount: Dollar amount associated with the event.
            currency: ISO-4217 currency code. Defaults to "USD".
            direction: Direction of flow.
            context: Arbitrary JSON context (metadata, order details, etc.).
            reason: Human-readable reason for the event.
            agent_id: Override the default agent_id for this event.
            await_confirmation: If True, raise on errors instead of swallowing.

        Returns:
            dict with id, status, created_at (empty on fire-and-forget failure).
        """
        body: dict[str, Any] = {
            "venue_id": self.venue_id,
            "agent_id": agent_id or self.agent_id,
            "action": action,
        }
        if amount is not None:
            body["amount"] = amount
        if currency is not None:
            body["currency"] = currency
        if direction is not None:
            body["direction"] = direction
        if context is not None:
            body["context"] = context
        if reason is not None:
            body["reason"] = reason

        try:
            return self._request("POST", "/v1/events", body=body)
        except AgenitryError:
            if await_confirmation:
                raise
            # Fire-and-forget: swallow the error
            return {
                "id": "",
                "status": "logged",
                "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            }

    # -------------------------------------------------------------------
    # events() — query the audit trail
    # -------------------------------------------------------------------

    def events(
        self,
        *,
        agent_id: Optional[str] = None,
        action: Optional[EventAction] = None,
        context: Optional[dict[str, Any]] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> dict[str, Any]:
        """Fetch events for the venue.

        Args:
            agent_id: Filter by agent_id.
            action: Filter by action type.
            context: Filter by context (JSONB contains).
            limit: Max events to return (1-200).
            offset: Pagination offset.

        Returns:
            dict with venue_id, total, limit, offset, has_more, events.
        """
        params: dict[str, str] = {
            "limit": str(limit),
            "offset": str(offset),
        }
        if agent_id is not None:
            params["agent_id"] = agent_id
        if action is not None:
            params["action"] = action
        if context is not None:
            params["context"] = json.dumps(context)

        path = f"/v1/events/{quote(self.venue_id, safe='')}"
        return self._request("GET", path, params=params)

    # -------------------------------------------------------------------
    # stats() — aggregated statistics
    # -------------------------------------------------------------------

    def stats(
        self,
        *,
        period: StatsPeriod = "today",
    ) -> dict[str, Any]:
        """Fetch aggregated stats for the venue.

        Args:
            period: Aggregation period. One of "today", "7d", "30d", "all".

        Returns:
            dict with venue_id, period, total_inbound, total_outbound,
            event_count, by_agent.
        """
        path = f"/v1/events/{quote(self.venue_id, safe='')}/stats"
        return self._request("GET", path, params={"period": period})

    # -------------------------------------------------------------------
    # Internal HTTP helper with retry
    # -------------------------------------------------------------------

    def _request(
        self,
        method: str,
        path: str,
        *,
        body: Optional[dict[str, Any]] = None,
        params: Optional[dict[str, str]] = None,
    ) -> dict[str, Any]:
        url = f"{self.base_url}{path}"
        if params:
            url = f"{url}?{urlencode(params)}"

        data = json.dumps(body).encode("utf-8") if body else None

        last_error: AgenitryError | None = None

        for attempt in range(self.max_retries + 1):
            try:
                req = Request(url, data=data, method=method)
                req.add_header("Content-Type", "application/json")
                req.add_header("Authorization", f"Bearer {self.api_key}")

                with urlopen(req, timeout=30) as resp:
                    return json.loads(resp.read().decode("utf-8"))

            except HTTPError as e:
                status = e.code
                try:
                    resp_body = json.loads(e.read().decode("utf-8"))
                except Exception:
                    resp_body = None

                if not _is_retryable(status):
                    raise AgenitryError(
                        message=f"Agenitry API error: {status} {e.reason}",
                        status=status,
                        body=resp_body,
                    )

                last_error = AgenitryError(
                    message=f"Agenitry API error (retryable): {status} {e.reason}",
                    status=status,
                )

            except URLError as e:
                raise AgenitryError(
                    message=f"Agenitry network error: {e.reason}",
                    code="NETWORK",
                )

            except Exception as e:
                raise AgenitryError(
                    message=f"Agenitry error: {e}",
                    code="API",
                )

            # Exponential backoff before retry
            if attempt < self.max_retries:
                delay = self.retry_base_delay * (2 ** attempt)
                time.sleep(delay)

        raise last_error or AgenitryError("Agenitry: all retries exhausted")


# ---------------------------------------------------------------------------
# Convenience factory
# ---------------------------------------------------------------------------

def create_agenitry(
    api_key: str,
    venue_id: str,
    *,
    base_url: str = _DEFAULT_BASE_URL,
    agent_id: str = "default",
    max_retries: int = _DEFAULT_MAX_RETRIES,
    retry_base_delay: float = _DEFAULT_RETRY_BASE_DELAY,
) -> Agenitry:
    """Create an Agenitry client in one line.

    Usage:
        from agenitry import create_agenitry
        agent = create_agenitry(api_key="ag_xxx", venue_id="my-venue")
    """
    return Agenitry(
        api_key=api_key,
        venue_id=venue_id,
        base_url=base_url,
        agent_id=agent_id,
        max_retries=max_retries,
        retry_base_delay=retry_base_delay,
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

__all__ = [
    "Agenitry",
    "AgenitryError",
    "create_agenitry",
    "EventAction",
    "EventDirection",
    "StatsPeriod",
]