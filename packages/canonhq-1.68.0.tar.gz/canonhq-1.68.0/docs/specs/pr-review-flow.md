---
title: "PR Review Persistence & Web UI"
status: draft
owner: ng
team: canon
ticket_project: canonhq/canon-private
created: 2026-05-15
updated: 2026-05-15
tags: [pr-reviews, web-app, github-app, performance, agent]
audience: internal
---

# PR Review Persistence & Web UI

Store the full output of the Canon GitHub App's PR review bot in the database, expose it via a web UI in the Vue SPA, deep-link from the GitHub PR comment, and optimize re-analysis so subsequent commits don't always trigger a full review.

## 1. Background

<!-- canon:system:1 status:draft -->

When the Canon agent analyzes a PR, it generates a rich `PRAnalysisResult` (summary, spec references, discrepancies, doc update suggestions, AC realizations, token usage). Today this data is:

- **Posted as a GitHub PR comment** with a hidden `<!-- canon-analysis-b64: ... -->` blob
- **Partially stored**: per-AC rows in `realization_evidence`, a count-only log in `agent_events`
- **Not stored in full**: the summary, spec references, discrepancies, and doc update suggestions are only in the GitHub comment

Problems:
1. **Data loss risk** — if the comment is deleted, the full analysis is gone. The post-merge handler (`on_pull_request_merged.py`) depends on that comment to apply doc updates.
2. **No web UI** — users can't browse PR reviews in Canon. The "View in Canon" link in the comment points to the repo specs page, not the review itself.
3. **Wasted compute** — every push to a PR branch triggers a full Claude analysis (~$0.03–0.10 per call). On a 10-commit PR, that's 10 identical analysis calls even when only CI config or lockfiles changed after the first review.

**Related:** `pr-comment-enhancements.md` (existing spec for PR comment deep links, now done)

## 2. PR Review Storage

<!-- canon:system:2 status:todo -->

<!-- canon:ticket:github:723 url:https://github.com/canonhq/canon-private/issues/723 -->
Persist the complete `PRAnalysisResult` for every PR review so that it is durable, queryable, and independent of the GitHub comment.

### 2.1 Database Schema

<!-- canon:system:2.1 status:todo -->

<!-- canon:ticket:github:13 url:https://github.com/canonhq/canon-private/issues/13 -->
New table `pr_reviews` (migration `0017_pr_reviews.py`):

| Column | Type | Notes |
|--------|------|-------|
| `id` | `SERIAL` | Primary key |
| `org` | `TEXT NOT NULL` | GitHub org / Canon org slug |
| `repo` | `TEXT NOT NULL` | `{owner}/{repo}` full name |
| `pr_number` | `INT NOT NULL` | PR number |
| `pr_url` | `TEXT NOT NULL` | GitHub PR URL |
| `pr_title` | `TEXT NOT NULL` | PR title at time of analysis |
| `pr_author` | `TEXT NOT NULL` | GitHub username of PR author |
| `head_sha` | `TEXT NOT NULL` | Commit SHA analyzed |
| `base_ref` | `TEXT NOT NULL` | Base branch name |
| `analysis` | `JSONB NOT NULL` | Full `PRAnalysisResult` serialized |
| `model` | `TEXT NOT NULL` | Model used (e.g., `claude-sonnet-4-6`) |
| `tokens_in` | `INT NOT NULL` | Input tokens |
| `tokens_out` | `INT NOT NULL` | Output tokens |
| `cost_estimate` | `NUMERIC(10,6)` | Estimated cost in USD |
| `review_kind` | `TEXT NOT NULL DEFAULT 'full'` | `full` or `incremental` |
| `created_at` | `TIMESTAMPTZ NOT NULL DEFAULT now()` | When the review was created |

Indexes:
- `UNIQUE (repo, pr_number, head_sha)` — enables upsert, prevents duplicate reviews per commit
- `(repo, pr_number, created_at DESC)` — efficient latest-review lookup
- `(org, created_at DESC)` — efficient org-level listing

### 2.2 Store Class

<!-- canon:system:2.2 status:todo -->

<!-- canon:ticket:github:724 url:https://github.com/canonhq/canon-private/issues/724 -->
New file `src/canon/db/pr_review_store.py` following the existing store pattern (`__init__(self, pool)`, `async with self._pool.acquire()`).

Methods:
- `upsert_review(org, repo, pr_number, ...)` — insert or update on `(repo, pr_number, head_sha)` conflict
- `get_latest_review(repo, pr_number)` — most recent review for a PR
- `get_review_by_sha(repo, pr_number, head_sha)` — specific review by commit
- `list_reviews_for_pr(repo, pr_number)` — all reviews for a PR, newest first (review history)
- `list_reviews_for_repo(repo, *, limit, offset)` — paginated list for a repo
- `list_reviews_for_org(org, *, limit, offset)` — paginated list across an org
- `get_review_by_id(review_id)` — fetch by primary key (for direct links)

### 2.3 Integration with PR Handler

<!-- canon:system:2.3 status:todo -->

<!-- canon:ticket:github:725 url:https://github.com/canonhq/canon-private/issues/725 -->
After `analyze_pr()` returns a result in `on_pull_request()`, call `pr_review_store.upsert_review()` to persist the full result. This is best-effort (wrapped in try/except like the existing `agent_store` calls).

The store is initialized in `main.py` lifespan alongside other stores and attached to `app.state.pr_review_store`.

### Acceptance Criteria

- [ ] Migration `0017_pr_reviews.py` creates the `pr_reviews` table with the schema above
- [ ] `PRReviewStore` implements all listed methods following existing store conventions
- [ ] `on_pull_request()` persists the full `PRAnalysisResult` after each analysis
- [ ] Store is initialized in `main.py` lifespan and available at `app.state.pr_review_store`
- [ ] Existing behavior is unaffected if DB is unavailable (best-effort storage)
- [ ] `realization_evidence` and `agent_events` storage continues to work unchanged

## 3. Web UI for PR Reviews

<!-- canon:system:3 status:todo -->

<!-- canon:ticket:github:726 url:https://github.com/canonhq/canon-private/issues/726 -->
Add PR review pages to the Vue SPA so users can browse and view analysis results directly in Canon.

### 3.1 API Endpoints

<!-- canon:system:3.1 status:todo -->

<!-- canon:ticket:github:727 url:https://github.com/canonhq/canon-private/issues/727 -->
New JSON API routes (added to `routes.py` or a new `review_routes.py`):

| Method | Path | Response |
|--------|------|----------|
| `GET` | `/app/{org}/api/reviews/{owner}/{repo}` | Paginated list of PR reviews for a repo |
| `GET` | `/app/{org}/api/reviews/{owner}/{repo}/{pr_number}` | Latest review for a specific PR + review history |

The repo review list returns a summary per PR (pr_number, title, author, head_sha, created_at, spec_reference_count, discrepancy_count, realization counts) without the full analysis JSONB.

The PR detail endpoint returns the full analysis for the latest review, plus a list of previous review summaries (by SHA) for the history view.

### 3.2 Service Layer

<!-- canon:system:3.2 status:todo -->

<!-- canon:ticket:github:34 url:https://github.com/canonhq/canon-private/issues/34 -->
New service functions in `services.py` (or a new `review_services.py`):
- `get_repo_reviews(pr_review_store, repo, limit, offset)` — returns `RepoReviewList` Pydantic model
- `get_pr_review_detail(pr_review_store, repo, pr_number)` — returns `PRReviewDetail` Pydantic model

### 3.3 Vue SPA Views

<!-- canon:system:3.3 status:todo -->

<!-- canon:ticket:github:728 url:https://github.com/canonhq/canon-private/issues/728 -->
Two new Vue views:

**Repo Reviews List** (`/app/{org}/reviews/{owner}/{repo}`):
- Table/card list of analyzed PRs for the repo
- Columns: PR number + title (linked to GitHub), author, head SHA (abbreviated), date, spec references count, discrepancy count (with severity indicator), realization summary
- Sortable by date, filterable by open/closed/merged status
- Pagination

**PR Review Detail** (`/app/{org}/reviews/{owner}/{repo}/{pr_number}`):
- Header: PR title, number, author, branch info, GitHub link, cost, model
- Rendered analysis: summary, spec references (linked to spec pages), discrepancies (with severity badges), suggested doc updates (diff view), realization status table
- Review history sidebar/tabs showing previous reviews by commit SHA with timestamps — click to view that version
- Link back to the GitHub PR

### 3.4 Repo Detail Integration

<!-- canon:system:3.4 status:todo -->

<!-- canon:ticket:github:729 url:https://github.com/canonhq/canon-private/issues/729 -->
Add a "Recent Reviews" section to the existing repo detail page (`/app/{org}/repos/{owner}/{repo}`) showing the 5 most recent PR reviews for that repo with links to the full review view.

### Acceptance Criteria

- [ ] API endpoint returns paginated PR reviews for a repo
- [ ] API endpoint returns full review detail with history for a specific PR
- [ ] Vue SPA has a review list view at `/app/{org}/reviews/{owner}/{repo}`
- [ ] Vue SPA has a review detail view at `/app/{org}/reviews/{owner}/{repo}/{pr_number}`
- [ ] Review detail renders all analysis sections: summary, spec references, discrepancies, doc updates, realizations
- [ ] Review history is navigable — user can view previous reviews by commit SHA
- [ ] Repo detail page shows a "Recent Reviews" section with links
- [ ] All views degrade gracefully when no reviews exist (empty states)

## 4. GitHub Comment Deep Link

<!-- canon:system:4 status:todo -->

<!-- canon:ticket:github:730 url:https://github.com/canonhq/canon-private/issues/730 -->
Update the GitHub PR comment footer to link directly to the review page in Canon instead of the repo specs page.

### 4.1 Comment Footer Update

<!-- canon:system:4.1 status:todo -->

<!-- canon:ticket:github:731 url:https://github.com/canonhq/canon-private/issues/731 -->
In `format_analysis_comment()`, change the "View in Canon" link from:
```
{base_url}/{owner}/{repo}
```
to:
```
{base_url}/reviews/{owner}/{repo}/{pr_number}
```

This requires adding `pr_number` as a parameter to `format_analysis_comment()`.

### 4.2 Review ID in Comment

<!-- canon:system:4.2 status:todo -->

<!-- canon:ticket:github:732 url:https://github.com/canonhq/canon-private/issues/732 -->
Add the review's `head_sha` to the embedded `<!-- canon-analysis-b64: ... -->` JSON payload so that the merged-PR handler can look up the review from the database as a fallback if the comment is malformed or the base64 extraction fails.

### Acceptance Criteria

- [ ] "View in Canon" link in PR comment points to the review detail page
- [ ] Link includes the correct org, owner, repo, and PR number
- [ ] Link degrades gracefully when `platform_url` is not configured (omit link, don't error)
- [ ] Embedded analysis JSON includes `head_sha` for DB lookup fallback
- [ ] `on_pull_request_merged.py` can fall back to DB lookup when comment extraction fails

## 5. Smart Re-analysis

<!-- canon:system:5 status:todo -->

<!-- canon:ticket:github:733 url:https://github.com/canonhq/canon-private/issues/733 -->
Reduce unnecessary Claude API calls on subsequent commits to a PR that has already been reviewed.

### 5.1 Skip Logic

<!-- canon:system:5.1 status:todo -->

<!-- canon:ticket:github:734 url:https://github.com/canonhq/canon-private/issues/734 -->
On `synchronize` events (new commits pushed to PR branch), before running the full analysis pipeline:

1. **Look up the latest review** for this PR from `pr_reviews`
2. **If no prior review exists** → run full analysis (first time)
3. **If prior review exists**, compute the incremental diff (files changed since the reviewed `head_sha`):
   - **Skip entirely** if all changed files match `CONFIG_ONLY_RE` (config, CI, lockfiles) — post a brief "Previous review still applies" note
   - **Skip entirely** if no files changed since the reviewed commit (force push to same content)
   - **Run full analysis** if spec files themselves changed, OR if >50% of PR files are new/modified since last review, OR if >24 hours since last review (staleness threshold)
   - **Otherwise**, run full analysis (but the prior review lookup prevents unnecessary work in the skip cases above)

### 5.2 Force Re-analysis

<!-- canon:system:5.2 status:todo -->

<!-- canon:ticket:github:735 url:https://github.com/canonhq/canon-private/issues/735 -->
The existing `@canon reanalyze` command (`on_issue_comment.py`) always runs a full analysis regardless of skip logic. No change needed to this behavior — just ensure it bypasses the skip logic.

### 5.3 Telemetry

<!-- canon:system:5.3 status:todo -->

<!-- canon:ticket:github:736 url:https://github.com/canonhq/canon-private/issues/736 -->
Track skipped analyses in PostHog:
- `pr_analysis_skipped` event with properties: `repo`, `pr_number`, `skip_reason` (`config_only_changes`, `no_changes`, etc.), `previous_review_age_hours`

### Acceptance Criteria

- [ ] Subsequent pushes with only config/lockfile changes skip analysis and post a "previous review applies" note
- [ ] Subsequent pushes with no file changes (same content) skip analysis
- [ ] Pushes that change spec files always trigger a full re-analysis
- [ ] Pushes where >50% of files changed since last review trigger full re-analysis
- [ ] Reviews older than 24 hours trigger full re-analysis regardless
- [ ] `@canon reanalyze` always runs full analysis, bypassing skip logic
- [ ] Skipped analyses are tracked in PostHog with skip reason
- [ ] First push to a PR always triggers full analysis (no prior review to skip from)

## 6. Rollout Plan

<!-- canon:system:6 status:draft -->

### Phase 1: Storage (no user-visible change)
- Deploy migration and store
- Wire persistence into `on_pull_request()` handler
- Monitor via logs and PostHog for successful storage

### Phase 2: Deep Link + Skip Logic
- Update `format_analysis_comment()` footer link
- Add skip logic to `on_pull_request()` handler
- Deploy and monitor skip rate via PostHog

### Phase 3: Web UI
- Deploy API endpoints behind the existing auth middleware
- Add Vue SPA views and integrate with repo detail page
- QA the review rendering against real PR review data accumulated in Phase 1

## 7. Open Questions

- Should we backfill existing PR reviews by scraping the base64 blobs from GitHub comments on recently-analyzed PRs? (Nice-to-have, not blocking.)
- Should the review list page be linked from the main nav, or only accessible from the repo detail page?
- For the incremental skip logic, should we expose a per-repo config in CANON.yaml to disable it (always re-analyze)?

## 8. Implementation Plan

<!-- canon:system:8 status:todo -->

<!-- canon:ticket:github:737 url:https://github.com/canonhq/canon-private/issues/737 -->
### Task 1: Migration + PRReviewStore

**Spec section:** §2 (PR Review Storage)

**Files to create:**

`src/canon/db/migrations/versions/0017_pr_reviews.py`
- `revision = "0017"`, `down_revision = "0016"`
- `upgrade()`: `CREATE TABLE IF NOT EXISTS pr_reviews (...)` with columns per §2.1
  - `id SERIAL PRIMARY KEY`
  - `org TEXT NOT NULL`
  - `repo TEXT NOT NULL` (full `owner/repo`)
  - `pr_number INT NOT NULL`
  - `pr_url TEXT NOT NULL`
  - `pr_title TEXT NOT NULL`
  - `pr_author TEXT NOT NULL`
  - `head_sha TEXT NOT NULL`
  - `base_ref TEXT NOT NULL`
  - `analysis JSONB NOT NULL DEFAULT '{}'::jsonb`
  - `model TEXT NOT NULL DEFAULT ''`
  - `tokens_in INT NOT NULL DEFAULT 0`
  - `tokens_out INT NOT NULL DEFAULT 0`
  - `cost_estimate NUMERIC(10,6) DEFAULT 0`
  - `review_kind TEXT NOT NULL DEFAULT 'full'`
  - `created_at TIMESTAMPTZ NOT NULL DEFAULT now()`
  - `UNIQUE (repo, pr_number, head_sha)`
  - Index on `(repo, pr_number, created_at DESC)`
  - Index on `(org, created_at DESC)`
- `downgrade()`: `DROP TABLE IF EXISTS pr_reviews`

`src/canon/db/pr_review_store.py`
- Class `PRReviewStore` with `__init__(self, pool: asyncpg.Pool)`
- Follow `SyncHistoryStore` pattern: raw SQL, `$N` params, `async with self._pool.acquire()`
- Methods:
  - `async def upsert_review(self, org, repo, pr_number, pr_url, pr_title, pr_author, head_sha, base_ref, analysis: dict, model, tokens_in, tokens_out, cost_estimate, review_kind='full') -> int`
    - `INSERT ... ON CONFLICT (repo, pr_number, head_sha) DO UPDATE SET analysis=$9, ... RETURNING id`
  - `async def get_latest_review(self, repo, pr_number) -> dict | None`
    - `SELECT * FROM pr_reviews WHERE repo=$1 AND pr_number=$2 ORDER BY created_at DESC LIMIT 1`
  - `async def get_review_by_sha(self, repo, pr_number, head_sha) -> dict | None`
  - `async def list_reviews_for_pr(self, repo, pr_number) -> list[dict]`
    - All reviews for a PR, newest first
  - `async def list_reviews_for_repo(self, repo, *, limit=20, offset=0) -> list[dict]`
    - Paginated, only returns latest review per PR (use `DISTINCT ON (pr_number)`)
  - `async def list_reviews_for_org(self, org, *, limit=20, offset=0) -> list[dict]`
  - `async def get_review_by_id(self, review_id: int) -> dict | None`

**Files to modify:**

`src/canon/db/__init__.py`
- Add `from .pr_review_store import PRReviewStore` import
- Add `"PRReviewStore"` to `__all__`

---

### Task 2: Wire Storage into PR Handler

**Spec section:** §2.3

**Files to modify:**

`src/canon/main.py` (~line 310, in lifespan after other stores)
- Add `app.state.pr_review_store = PRReviewStore(pool)` after pool creation
- Add `app.state.pr_review_store = None` in the pre-DB-init block (~line 280)

`src/canon/github/handlers/on_pull_request.py`
- Add helper `_get_pr_review_store()` following the `_get_agent_store()` pattern:
  ```python
  def _get_pr_review_store():
      try:
          from canon.main import app
          return getattr(app.state, "pr_review_store", None)
      except Exception:
          return None
  ```
- After the `agent_store.log_event()` block (~line 604), add persistence call:
  ```python
  pr_review_store = _get_pr_review_store()
  if pr_review_store is not None:
      try:
          await pr_review_store.upsert_review(
              org=owner,
              repo=f"{owner}/{repo}",
              pr_number=pr_number,
              pr_url=pr["html_url"],
              pr_title=pr["title"],
              pr_author=pr["user"]["login"],
              head_sha=pr["head"]["sha"],
              base_ref=pr["base"]["ref"],
              analysis=result.model_dump(mode="json"),
              model=DEFAULT_AGENT_CONFIG.model,
              tokens_in=result.tokens_used.input,
              tokens_out=result.tokens_used.output,
              cost_estimate=_estimate_cost(result.tokens_used, DEFAULT_AGENT_CONFIG.model),
          )
      except Exception:
          logger.warning("%s — failed to store PR review", tag, exc_info=True)
  ```
- Extract cost estimation into a helper `_estimate_cost(tokens, model)` (pull the logic from `format_analysis_comment` lines 640-665 which already computes cost)

---

### Task 3: Smart Re-analysis Skip Logic

**Spec section:** §5

**Files to modify:**

`src/canon/github/handlers/on_pull_request.py`
- At the top of `on_pull_request()`, after extracting `pr_number` (~line 363), check the webhook action:
  ```python
  action = payload.get("action")
  is_synchronize = action == "synchronize"
  ```
- After the `has_non_config` check (~line 370), before loading specs, add skip logic:
  ```python
  if is_synchronize:
      pr_review_store = _get_pr_review_store()
      if pr_review_store is not None:
          prev = await pr_review_store.get_latest_review(f"{owner}/{repo}", pr_number)
          if prev is not None:
              skip_reason = _should_skip_reanalysis(prev, raw_files, pr)
              if skip_reason:
                  # Post a brief "previous review applies" note
                  await client.upsert_bot_comment(...)
                  analytics.track("pr_analysis_skipped", properties={...})
                  return
  ```
- New helper function `_should_skip_reanalysis(prev_review: dict, raw_files: list, pr: dict) -> str | None`:
  - Returns `None` if full analysis should run, or a skip reason string
  - Check 1: If all new files match `CONFIG_ONLY_RE` → return `"config_only_changes"`
  - Check 2: If `prev["head_sha"] == pr["head"]["sha"]` → return `"no_changes"` (force push to same content)
  - Check 3: If any file in `raw_files` matches spec patterns → return `None` (always re-analyze)
  - Check 4: If `prev["created_at"]` is >24h ago → return `None` (staleness)
  - Otherwise → return `"no_spec_relevant_changes"`
- Note: The comment posted on skip should preserve the existing `<!-- canon-bot -->` marker format and explain that a previous review exists with a link

`src/canon/github/handlers/on_issue_comment.py`
- The `@canon reanalyze` handler already calls `on_pull_request()` directly. Ensure it passes a synthetic payload with `action: "reopened"` (not `"synchronize"`) so the skip logic is bypassed. Check current behavior — if it already uses `"reopened"` or `"opened"`, no change needed.

---

### Task 4: GitHub Comment Deep Link Update

**Spec section:** §4

**Files to modify:**

`src/canon/agent/analyzer.py`
- `format_analysis_comment()` signature: add `pr_number: int = 0` parameter
- Change the "View in Canon" link (~line 669-671):
  ```python
  if base_url and owner and repo and pr_number:
      review_url = f"{base_url.rstrip('/')}/reviews/{owner}/{repo}/{pr_number}"
      footer_parts.append(f"[View in Canon]({review_url})")
  elif base_url and owner and repo:
      # Fallback to repo specs page if pr_number not available
      specs_url = f"{base_url.rstrip('/')}/{owner}/{repo}"
      footer_parts.append(f"[View in Canon]({specs_url})")
  ```
- In the embedded JSON block (~line 678-684), add `head_sha` to the payload:
  - Add `head_sha: str = ""` parameter to `format_analysis_comment()`
  - Include `"headSha": head_sha` in the `embedded_json` dict

`src/canon/github/handlers/on_pull_request.py`
- Update the `format_analysis_comment()` call (~line 507-515) to pass `pr_number` and `head_sha`:
  ```python
  comment = format_analysis_comment(
      result,
      model=DEFAULT_AGENT_CONFIG.model,
      preview_url=preview_url,
      base_url=_settings.platform_url,
      owner=owner,
      repo=repo,
      pr_number=pr_number,
      head_sha=pr["head"]["sha"],
      doc_patterns=doc_paths,
  )
  ```

`src/canon/github/handlers/on_pull_request_merged.py`
- After `analysis = extract_analysis_data(bot_comment["body"])` (~line 110), add DB fallback:
  ```python
  if not analysis:
      pr_review_store = _get_pr_review_store()
      if pr_review_store:
          db_review = await pr_review_store.get_latest_review(f"{owner}/{repo}", pr_number)
          if db_review:
              analysis = {
                  "realizations": db_review["analysis"].get("realizations", []),
                  "discrepancies": db_review["analysis"].get("discrepancies", []),
                  "docUpdates": db_review["analysis"].get("doc_updates", []),
              }
  ```
- Add the same `_get_pr_review_store()` helper import or define it locally

---

### Task 5: Web API Endpoints for Reviews

**Spec section:** §3.1, §3.2

**Files to create:**

`src/canon/web/review_routes.py`
- New FastAPI `APIRouter` with prefix pattern matching existing routes
- Two endpoints:
  - `GET /app/{org}/api/reviews/{owner}/{repo}` → `list_repo_reviews()`
    - Query params: `limit` (default 20), `offset` (default 0)
    - Calls `pr_review_store.list_reviews_for_repo(f"{owner}/{repo}", limit=limit, offset=offset)`
    - Returns list of review summaries (strip the full `analysis` JSONB, keep counts)
  - `GET /app/{org}/api/reviews/{owner}/{repo}/{pr_number}` → `get_pr_review()`
    - Calls `pr_review_store.get_latest_review(f"{owner}/{repo}", pr_number)` for the main review
    - Calls `pr_review_store.list_reviews_for_pr(f"{owner}/{repo}", pr_number)` for history
    - Returns `{ "review": {...full analysis...}, "history": [{summary}, ...] }`
- Both routes require auth (use the existing `require_org_access` dependency from `routes.py`)

**Files to modify:**

`src/canon/web/models.py`
- Add Pydantic response models:
  - `ReviewSummary`: id, pr_number, pr_url, pr_title, pr_author, head_sha, model, tokens_in, tokens_out, cost_estimate, review_kind, created_at, spec_reference_count, discrepancy_count, realization_counts (realized/partial/conflicting)
  - `ReviewDetail`: all of ReviewSummary plus full analysis (summary, spec_references, discrepancies, doc_updates, realizations)
  - `PRReviewResponse`: review (ReviewDetail), history (list[ReviewSummary])
  - `RepoReviewListResponse`: reviews (list[ReviewSummary]), total (int)

`src/canon/main.py`
- Mount the new review router: `app.include_router(review_router)`

`src/canon/web/routes.py`
- Add SPA catch-all support for `/app/{org}/reviews/...` paths (these will be caught by the existing `spa_catch_all` route at the bottom — verify it handles the pattern)

---

### Task 6: Vue SPA Review Views

**Spec section:** §3.3, §3.4

**Files to create:**

`frontend/src/api/reviews.ts`
- Import `get` from `./client`
- Define interfaces: `ReviewSummary`, `ReviewDetail`, `PRReviewResponse`, `RepoReviewListResponse`
- Export functions:
  - `fetchRepoReviews(org, owner, repo, limit?, offset?): Promise<RepoReviewListResponse>`
  - `fetchPRReview(org, owner, repo, prNumber): Promise<PRReviewResponse>`

`frontend/src/views/ReviewListView.vue`
- `<script setup lang="ts">` with `useRoute()`, `useQuery()` for `fetchRepoReviews()`
- Table layout: PR # + title (GitHub link), author, SHA (abbreviated), date, spec refs count, discrepancy count (color-coded by severity), realizations summary
- Pagination controls
- Empty state when no reviews exist
- Breadcrumb: Dashboard / {repo} / Reviews

`frontend/src/views/ReviewDetailView.vue`
- `<script setup lang="ts">` with `useRoute()`, `useQuery()` for `fetchPRReview()`
- Header card: PR title, #, author, branch, SHA, GitHub link, model, cost
- Tab layout or collapsible sections:
  - **Summary** — rendered blockquote (same as GH comment)
  - **Spec References** — table with spec name (linked to spec view), section, relevance, explanation
  - **Discrepancies** — cards with severity badge (caution/warning), spec-says vs pr-does
  - **Suggested Updates** — diff view (use `<pre>` with +/- coloring)
  - **Realizations** — table with AC text, status badge, evidence file links
- Review history sidebar: list of previous reviews by date + abbreviated SHA, click to load
- Breadcrumb: Dashboard / {repo} / Reviews / PR #{number}

`frontend/src/components/repo/RecentReviews.vue`
- Small component showing 5 most recent reviews for a repo
- Each row: PR title (linked to review detail), date, discrepancy count badge
- "View all reviews →" link to full review list

**Files to modify:**

`frontend/src/router/index.ts`
- Add two routes inside the org-scoped section:
  ```ts
  {
    path: '/app/:org/reviews/:owner/:repo',
    name: 'reviews',
    component: () => import('../views/ReviewListView.vue'),
  },
  {
    path: '/app/:org/reviews/:owner/:repo/:prNumber',
    name: 'review-detail',
    component: () => import('../views/ReviewDetailView.vue'),
  },
  ```

`frontend/src/views/RepoView.vue`
- Import and render `RecentReviews` component after the existing spec list section
- Pass `org`, `owner`, `repo` as props

---

### Task 7: Tests

**Spec section:** all

**Files to create:**

`tests/test_db/test_pr_review_store.py`
- Test `upsert_review()` creates and updates reviews
- Test `get_latest_review()` returns most recent
- Test `get_review_by_sha()` returns specific review
- Test `list_reviews_for_pr()` returns all reviews in order
- Test `list_reviews_for_repo()` returns distinct-per-PR, paginated
- Test upsert conflict resolution (same repo+pr+sha → update)
- Use the same in-memory asyncpg pool fixtures used by other store tests (see `tests/conftest.py`)

`tests/test_agent/test_format_comment_deep_link.py`
- Test that `format_analysis_comment()` with `pr_number` produces the review URL
- Test fallback when `pr_number=0` or `base_url=""` (no link)
- Test that embedded JSON includes `headSha`

`tests/test_github/test_skip_logic.py`
- Test `_should_skip_reanalysis()` with various scenarios:
  - Config-only changes → skip
  - Same SHA → skip
  - Spec files changed → no skip
  - >50% files changed → no skip
  - >24h staleness → no skip
  - Small non-spec change → skip

`tests/test_web/test_review_routes.py`
- Test `GET /app/{org}/api/reviews/{owner}/{repo}` returns paginated list
- Test `GET /app/{org}/api/reviews/{owner}/{repo}/{pr_number}` returns detail + history
- Test 404 when no reviews exist
- Use the integration test fixtures (real FastAPI test client + Postgres)

---

### Dependency Graph

```
Task 1 (Migration + Store)
  ├─→ Task 2 (Wire into handler)
  │     ├─→ Task 3 (Skip logic)
  │     └─→ Task 4 (Deep link)
  ├─→ Task 5 (API endpoints)
  │     └─→ Task 6 (Vue views)
  └─→ Task 7 (Tests — after all above)
```

Tasks 3, 4, 5 can be parallelized once Task 2 is done. Task 6 depends on Task 5. Task 7 covers all.
