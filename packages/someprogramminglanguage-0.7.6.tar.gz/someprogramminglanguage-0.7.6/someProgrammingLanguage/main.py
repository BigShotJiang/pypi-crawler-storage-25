from importlib.metadata import version
import importlib.util
import ctypes
import hashlib
import re
import shutil
import subprocess
import sys
import math
import os
import copy
import random

_spl_dir = os.path.dirname(os.path.abspath(__file__))
if _spl_dir not in sys.path:
    sys.path.insert(0, _spl_dir)
from spl_ast import (
    ASTNode,
    MethodCallNode,
    ImportNode,
    BlockNode,
    LogicNode,
    HashLiteralNode,
    TupleLiteralNode,
    SetLiteralNode,
    TryExceptNode,
    InheritNode,
    ThisAssignNode,
    ExprStmtNode,
)

# stops runaway while/forLoop; high enough for real use, low enough to fail fast.
_MAX_LOOP_ITERATIONS = 100_000

# Sentinel: _dispatch_instance_member did not handle the MethodCallNode.
_DISPATCH_SKIP = object()


class SPLSet:
    """Ordered unique collection; str() / print uses {a,b,c} style."""

    __slots__ = ("_items",)

    def __init__(self, iterable=()):
        self._items = []
        it = iterable._items if isinstance(iterable, SPLSet) else iterable
        for x in it:
            if x not in self._items:
                self._items.append(x)

    def append(self, item):
        if item not in self._items:
            self._items.append(item)
        return self

    def remove_value(self, item):
        if item in self._items:
            self._items.remove(item)
        return self

    def remove_index(self, idx):
        i = int(idx)
        if i < 0 or i >= len(self._items):
            raise SPLException("IndexOutOfRangeError", f"set index {i} for length {len(self._items)}")
        del self._items[i]
        return self

    def __repr__(self):
        return str(self)

    def __str__(self):
        inner = ",".join(str(x) for x in self._items)
        return "{" + inner + "}"


class SPLFunctionRef:
    """First-class reference to a user-defined function by name (resolved at call time)."""

    __slots__ = ("name",)

    def __init__(self, name: str):
        self.name = name

    def __repr__(self):
        return f"SPLFunctionRef({self.name!r})"


class SPLClass:
    """User-defined class: methods, field defaults/visibility, optional parent, optional constructor body."""

    __slots__ = ("name", "parent", "methods", "field_defaults", "field_visibility", "constructor_body", "keymap_entries")

    def __init__(self, name: str):
        self.name = name
        self.parent = None
        self.methods = {}
        self.field_defaults = {}
        self.field_visibility = {}
        self.constructor_body = None
        self.keymap_entries = None  # list of (single-char str, value_expr_ast) from keymapDefine.keymap

    def merge_parent(self, parent: "SPLClass"):
        self.parent = parent
        for mn, mb in parent.methods.items():
            if mn not in self.methods:
                self.methods[mn] = mb
        for fn, fv in parent.field_defaults.items():
            if fn not in self.field_defaults:
                self.field_defaults[fn] = fv
                self.field_visibility.setdefault(fn, parent.field_visibility.get(fn, "private"))
        if parent.keymap_entries is not None and self.keymap_entries is None:
            self.keymap_entries = copy.deepcopy(parent.keymap_entries)

    def method_lookup(self, name: str):
        if name in self.methods:
            return self.methods[name]
        if self.parent:
            return self.parent.method_lookup(name)
        return None


class SPLInstance:
    __slots__ = ("cls", "fields")

    def __init__(self, cls: SPLClass):
        self.cls = cls
        self.fields = {}


class SPLKeyMap:
    """Runtime handle for a class keymap; ``curr`` is the hash built during key evaluation / string.sorted."""

    __slots__ = ("spl_class", "curr")

    def __init__(self, spl_class: SPLClass):
        self.spl_class = spl_class
        self.curr = {}


def _resolve_library_path(relative_name, line):
    """relative_name is the path after lib/ (may include dots, e.g. new_math.spl)."""
    if not relative_name or relative_name.strip() != relative_name:
        raise Exception(f"[Line {line}] Invalid library path")
    if ".." in relative_name or relative_name.startswith(("/", "\\")):
        raise Exception(f"[Line {line}] Invalid library path (no .. or absolute paths)")
    lib_root = os.path.realpath(os.path.join(_spl_dir, "lib"))
    lib_path = os.path.realpath(os.path.join(lib_root, relative_name))
    if lib_path != lib_root and not lib_path.startswith(lib_root + os.sep):
        raise Exception(f"[Line {line}] Library path escapes lib directory")
    return lib_path


# Libraries may opt in to extensionless `use name` by declaring at the top of the file:
#   SPL: reqFileExtension.setVar(false);
#   Python: reqFileExtension = False
#   C: #include <stdbool.h> and bool reqFileExtension = false;
#   C++: bool reqFileExtension = false;
#   Java: boolean reqFileExtension = false;
_REQ_SPL_EXT_RE = re.compile(
    r"reqFileExtension\s*\.\s*setVar\s*\(\s*(false|true)\s*\)",
    re.IGNORECASE,
)
_REQ_PY_EXT_RE = re.compile(
    r"^\s*reqFileExtension\s*=\s*(False|True)\b",
    re.MULTILINE,
)
_REQ_C_CXX_BOOL_EXT_RE = re.compile(
    r"(?:^|\n)\s*(?:static\s+)?bool\s+reqFileExtension\s*=\s*(false|true)\s*;",
    re.MULTILINE,
)
_REQ_JAVA_BOOL_EXT_RE = re.compile(
    r"\bboolean\s+reqFileExtension\s*=\s*(false|true)\s*;",
    re.MULTILINE,
)


def _spl_allows_extensionless_import(lib_path):
    try:
        with open(lib_path, encoding="utf-8") as f:
            head = f.read(16000)
    except OSError:
        return False
    m = _REQ_SPL_EXT_RE.search(head)
    if not m:
        return False
    return m.group(1).lower() == "false"


def _py_allows_extensionless_import(lib_path):
    try:
        with open(lib_path, encoding="utf-8") as f:
            head = f.read(16000)
    except OSError:
        return False
    m = _REQ_PY_EXT_RE.search(head)
    if not m:
        return False
    return m.group(1) == "False"


def _c_cpp_allows_extensionless_import(lib_path):
    try:
        with open(lib_path, encoding="utf-8") as f:
            head = f.read(16000)
    except OSError:
        return False
    m = _REQ_C_CXX_BOOL_EXT_RE.search(head)
    if not m:
        return False
    return m.group(1).lower() == "false"


def _java_allows_extensionless_import(lib_path):
    try:
        with open(lib_path, encoding="utf-8") as f:
            head = f.read(16000)
    except OSError:
        return False
    m = _REQ_JAVA_BOOL_EXT_RE.search(head)
    if not m:
        return False
    return m.group(1).lower() == "false"


def _resolve_library_import_lib(module_name, line):
    """Resolve under someProgrammingLanguage/lib/ only. Returns (real_path, ext_lower)."""
    if not module_name or module_name.strip() != module_name:
        raise Exception(f"[Line {line}] Invalid library path")
    if "." in module_name:
        lib_path = _resolve_library_path(module_name, line)
        if not os.path.isfile(lib_path):
            raise Exception(f"[Line {line}] Cannot open library: {lib_path}")
        return lib_path, os.path.splitext(module_name)[1].lower()
    extensionless_checks = [
        (".spl", module_name + ".spl", _spl_allows_extensionless_import),
        (".py", module_name + ".py", _py_allows_extensionless_import),
        (".c", module_name + ".c", _c_cpp_allows_extensionless_import),
        (".cpp", module_name + ".cpp", _c_cpp_allows_extensionless_import),
        (".cc", module_name + ".cc", _c_cpp_allows_extensionless_import),
        (".cxx", module_name + ".cxx", _c_cpp_allows_extensionless_import),
        (".java", module_name + ".java", _java_allows_extensionless_import),
    ]
    candidates = []
    for ext, rel, allow_fn in extensionless_checks:
        path = _resolve_library_path(rel, line)
        if os.path.isfile(path) and allow_fn(path):
            candidates.append((ext, path))
    if len(candidates) > 1:
        kinds = ", ".join(f"{module_name}{e}" for e, _ in candidates)
        raise Exception(
            f"[Line {line}] Ambiguous use {module_name!r}: multiple libraries opt in to extensionless import ({kinds}); "
            f"use an explicit file extension in the use statement"
        )
    if len(candidates) == 1:
        ext, path = candidates[0]
        return path, ext
    raise Exception(
        f"[Line {line}] Cannot resolve use {module_name!r}: include the file extension (e.g. {module_name}.spl), "
        f"or add an opt-in (SPL: reqFileExtension.setVar(false); Python: reqFileExtension = False; "
        f"C/C++: bool reqFileExtension = false; Java: boolean reqFileExtension = false;)"
    )


_NATIVE_SOURCE_EXTS = {".c", ".cpp", ".cc", ".cxx"}
_NATIVE_JAVA_EXT = ".java"


def _native_build_root():
    """User cache for compiled .so / Java classes — keeps site-packages clean after pip install."""
    if sys.platform == "win32":
        preferred = os.path.join(
            os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"),
            "someProgrammingLanguage",
            "native_build",
        )
    else:
        xdg = os.environ.get("XDG_CACHE_HOME")
        if xdg:
            preferred = os.path.join(xdg, "someProgrammingLanguage", "native_build")
        else:
            preferred = os.path.join(
                os.path.expanduser("~"), ".cache", "someProgrammingLanguage", "native_build"
            )
    fallback = os.path.join(_spl_dir, "lib", ".spl_native_build")
    for path in (preferred, fallback):
        try:
            os.makedirs(path, exist_ok=True)
            return path
        except OSError:
            continue
    raise OSError("Could not create native build cache directory")


def _compile_native_shared(lib_path, ext, line):
    """Compile lib_path to a cached .so (Linux/macOS) shared object; returns path to .so."""
    with open(lib_path, "rb") as f:
        digest = hashlib.md5(f.read()).hexdigest()[:14]
    stem = os.path.splitext(os.path.basename(lib_path))[0]
    out_dir = os.path.join(_native_build_root(), f"{stem}_{digest}")
    os.makedirs(out_dir, exist_ok=True)
    out_so = os.path.join(out_dir, f"lib{stem}.so")
    include_dir = os.path.join(_spl_dir, "include")
    if os.path.isfile(out_so) and os.path.getmtime(out_so) >= os.path.getmtime(lib_path):
        return out_so
    cc = shutil.which("cc") or shutil.which("gcc") or shutil.which("clang")
    cxx = shutil.which("c++") or shutil.which("g++") or shutil.which("clang++")
    if ext == ".c":
        if not cc:
            raise Exception(f"[Line {line}] No C compiler found (cc, gcc, or clang) for native library")
        cmd = [cc, "-shared", "-fPIC", "-O2", f"-I{include_dir}", "-o", out_so, os.path.abspath(lib_path)]
    else:
        if not cxx:
            raise Exception(f"[Line {line}] No C++ compiler found (c++, g++, or clang++) for native library")
        cmd = [
            cxx,
            "-shared",
            "-fPIC",
            "-O2",
            "-std=c++17",
            f"-I{include_dir}",
            "-o",
            out_so,
            os.path.abspath(lib_path),
        ]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        msg = (r.stderr or r.stdout or "").strip() or "(no compiler output)"
        raise Exception(f"[Line {line}] Native compile failed:\n{msg}")
    return out_so


def _register_native_c_library(interpreter, lib_path, ext, line):
    so_path = _compile_native_shared(lib_path, ext, line)
    lib = ctypes.CDLL(so_path)
    SplAdd = ctypes.CFUNCTYPE(
        None,
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.CFUNCTYPE(ctypes.c_double),
    )

    @SplAdd
    def add_cb(ns_b, name_b, fn):
        ns = ns_b.decode("utf-8")
        name = name_b.decode("utf-8")

        def pyfn():
            return float(fn())

        interpreter.library.setdefault(ns, {})[name] = pyfn

    try:
        spl_register = lib.spl_register
    except AttributeError as e:
        raise Exception(
            f"[Line {line}] Native library must export spl_register (see include/spl_native.h)"
        ) from e
    spl_register.argtypes = [SplAdd]
    spl_register.restype = None
    spl_register(add_cb)


def _ensure_java_spl_host(jbuild, line):
    spl_host = os.path.join(_spl_dir, "lib", "SPLHost.java")
    if not os.path.isfile(spl_host):
        raise Exception(f"[Line {line}] Missing bundled SPLHost.java")
    spl_cls = os.path.join(jbuild, "SPLHost.class")
    if not os.path.isfile(spl_cls) or os.path.getmtime(spl_host) > os.path.getmtime(spl_cls):
        r = subprocess.run(
            ["javac", "-encoding", "UTF-8", "-d", jbuild, spl_host],
            capture_output=True,
            text=True,
        )
        if r.returncode != 0:
            msg = (r.stderr or r.stdout or "").strip() or "(no javac output)"
            raise Exception(f"[Line {line}] javac SPLHost.java failed:\n{msg}")


def _load_java_library(interpreter, lib_path, line):
    try:
        import jpype
        import jpype.imports
    except ImportError as e:
        raise Exception(
            f"[Line {line}] Java libraries need jpype1: pip install jpype1 "
            f"(or pip install 'someProgrammingLanguage[java]')"
        ) from e
    javac = shutil.which("javac")
    java = shutil.which("java")
    if not javac or not java:
        raise Exception(f"[Line {line}] javac/java not found on PATH for Java library import")
    with open(lib_path, encoding="utf-8") as f:
        src = f.read()
    m = re.search(r"public\s+class\s+(\w+)\b", src)
    if not m:
        raise Exception(f"[Line {line}] Java library must declare one public class")
    class_name = m.group(1)
    jbuild = os.path.join(_native_build_root(), "java_classes")
    os.makedirs(jbuild, exist_ok=True)
    _ensure_java_spl_host(jbuild, line)
    r = subprocess.run(
        ["javac", "-encoding", "UTF-8", "-cp", jbuild, "-d", jbuild, os.path.abspath(lib_path)],
        capture_output=True,
        text=True,
    )
    if r.returncode != 0:
        msg = (r.stderr or r.stdout or "").strip() or "(no javac output)"
        raise Exception(f"[Line {line}] javac failed:\n{msg}")
    jbuild_abs = os.path.abspath(jbuild)
    if not jpype.isJVMStarted():
        jpype.startJVM(jpype.getDefaultJVMPath(), classpath=[jbuild_abs])

    spl_host_cls = jpype.JClass("SPLHost")

    @jpype.JImplements(spl_host_cls)
    class HostImpl:
        @jpype.JOverride
        def registerDoubleVoid(self, ns, name, supplier):
            ns = str(ns)
            name = str(name)

            def pyfn():
                return float(supplier.get())

            interpreter.library.setdefault(ns, {})[name] = pyfn

    host = HostImpl()
    user_cls = jpype.JClass(class_name)
    user_cls.splRegister(host)


def _spl_from_ascii_binary_mod(s, m):
    if not isinstance(s, str) or m is None:
        return None
    if not s:
        return 0
    if not all(c in "01" for c in s):
        return 0
    try:
        return int(s, 2) % int(m)
    except ValueError:
        return 0

def _decode_spl_string_escapes(inner, line):
    """Decode escape sequences inside a double-quoted string body (no surrounding quotes)."""
    out = []
    i = 0
    n = len(inner)
    while i < n:
        if inner[i] != "\\":
            out.append(inner[i])
            i += 1
            continue
        if i + 1 >= n:
            raise Exception(f"[Line {line}] Unterminated escape at end of string")
        c = inner[i + 1]
        if c == "n":
            out.append("\n")
        elif c == "'":
            out.append("'")
        elif c == '"':
            out.append('"')
        elif c == "\\":
            out.append("\\")
        elif c == "t":
            out.append("\t")
        elif c == "r":
            out.append("\r")
        else:
            raise Exception(f"[Line {line}] Unknown escape sequence: \\{c}")
        i += 2
    return "".join(out)

# lexer
TOKEN_SPEC = [
    ('COMMENT',   r'#comment:.*'),
    ('NUMBER',    r'-?\d+(\.\d*)?'),
    ('STRING',    r'"(?:[^"\\]|\\.)*"'),
    ('BOOLEAN',   r'\b(true|false)\b'),
    ('NOT',       r'\bnot\b'),
    ('NAND',      r'\bnand\b'),
    ('AND',       r'\band\b'),
    ('NOR',       r'\bnor\b'),
    ('XNOR',      r'\bxnor\b'),
    ('XOR',       r'\bxor\b'),
    ('OR',        r'\bor\b'),
    ('DOT',       r'\.'),
    ('LPAREN',    r'\('),
    ('RPAREN',    r'\)'),
    ('COLON',     r':'),
    ('END',       r'end\b'),
    ('USE',       r'use\b'),
    ('CODEKW',    r'\bcode\b'),
    ('LEFTARROW', r'<-'),
    ('ASSIGN',    r'='),
    ('ID',        r'[A-Za-z_][A-Za-z0-9_]*'),
    ('SEMICOLON', r';'),
    ('NEWLINE',   r'\n'),
    ('SKIP',      r'[ \t]+'),
    ('COMMA',     r','),
    ('LBRACKET',  r'\['),
    ('RBRACKET',  r'\]'),
    ('LBRACE',    r'\{'),
    ('RBRACE',    r'\}'),
    ('QMARK',     r'\?'),
    ('ERROR',     r'.'),
]

class Token:
    def __init__(self, t, v, line):
        self.t, self.v, self.line = t, v, line

def tokenize(code):
    tok_regex = '|'.join('(?P<%s>%s)' % pair for pair in TOKEN_SPEC)
    tokens, line_num = [], 1
    for mo in re.finditer(tok_regex, code):
        kind, val = mo.lastgroup, mo.group()
        if kind in ['COMMENT','SKIP']: continue
        elif kind == 'NEWLINE': line_num += 1; continue
        elif kind == 'ERROR': raise Exception(f"[Line {line_num}] Lexer Error: '{val}'")
        elif kind == 'BOOLEAN': val = 1 if val=='true' else 0
        elif kind == 'NUMBER': val = float(val) if '.' in val else int(val)
        elif kind == 'STRING':
            val = _decode_spl_string_escapes(val[1:-1], line_num)
        tokens.append(Token(kind,val,line_num))
    tokens.append(Token("EOF",None,line_num))
    return tokens

# parser
class Parser:
    def __init__(self,tokens): self.tokens, self.pos = tokens,0
    def consume(self,expected_type=None):
        token = self.tokens[self.pos]
        if expected_type and token.t != expected_type:
            raise Exception(f"[Line {token.line}] Expected {expected_type} got {token.t}")
        self.pos += 1
        return token
    def peek(self,offset=0):
        if self.pos+offset>=len(self.tokens): return self.tokens[-1]
        return self.tokens[self.pos+offset]

    def parse_expression(self):
        if self.tokens[self.pos].t=="LBRACKET":
            self.consume("LBRACKET")
            elements=[]
            if self.tokens[self.pos].t!="RBRACKET":
                elements.append(self.parse_expression())
                while self.tokens[self.pos].t=="COMMA":
                    self.consume("COMMA")
                    elements.append(self.parse_expression())
            self.consume("RBRACKET")
            return elements
        if self.tokens[self.pos].t=="LBRACE":
            return self.parse_brace_literal()
        return self.parse_logic_nor()

    def parse_brace_literal(self):
        """`{k: v, ...}` hash literal or `{a, b, ...}` set literal (no duplicates at runtime)."""
        start = self.consume("LBRACE")
        if self.tokens[self.pos].t == "RBRACE":
            self.consume("RBRACE")
            return HashLiteralNode([], start.line)
        first = self.parse_expression()
        if self.tokens[self.pos].t == "COLON":
            self.consume("COLON")
            val = self.parse_expression()
            pairs = [(first, val)]
            while self.tokens[self.pos].t == "COMMA":
                self.consume("COMMA")
                key = self.parse_expression()
                self.consume("COLON")
                val = self.parse_expression()
                pairs.append((key, val))
            self.consume("RBRACE")
            return HashLiteralNode(pairs, start.line)
        elements = [first]
        while self.tokens[self.pos].t == "COMMA":
            self.consume("COMMA")
            elements.append(self.parse_expression())
        self.consume("RBRACE")
        return SetLiteralNode(elements, start.line)

    def parse_logic_nor(self):
        left=self.parse_logic_xor_xnor()
        while self.tokens[self.pos].t=="NOR":
            op=self.consume("NOR")
            right=self.parse_logic_xor_xnor()
            left=LogicNode(left,op.v,right,op.line)
        return left

    def parse_logic_xor_xnor(self):
        left=self.parse_logic_or()
        while self.tokens[self.pos].t in ("XOR","XNOR"):
            op=self.consume()
            right=self.parse_logic_or()
            left=LogicNode(left,op.v,right,op.line)
        return left

    def parse_logic_or(self):
        left=self.parse_logic_and()
        while self.tokens[self.pos].t=="OR":
            op=self.consume("OR")
            right=self.parse_logic_and()
            left=LogicNode(left,op.v,right,op.line)
        return left

    def parse_logic_and(self):
        left=self.parse_logic_nand()
        while self.tokens[self.pos].t=="AND":
            op=self.consume("AND")
            right=self.parse_logic_nand()
            left=LogicNode(left,op.v,right,op.line)
        return left

    def parse_logic_nand(self):
        left=self.parse_logic_not()
        while self.tokens[self.pos].t=="NAND":
            op=self.consume("NAND")
            right=self.parse_logic_not()
            left=LogicNode(left,op.v,right,op.line)
        return left

    def parse_logic_not(self):
        if self.tokens[self.pos].t=="NOT":
            op=self.consume("NOT")
            operand=self.parse_logic_not()
            return LogicNode(None,op.v,operand,op.line)
        return self.parse_logic_primary()

    def parse_logic_primary(self):
        if self.tokens[self.pos].t=="LPAREN":
            line=self.tokens[self.pos].line
            self.consume("LPAREN")
            if self.tokens[self.pos].t=="RPAREN":
                self.consume("RPAREN")
                return TupleLiteralNode([], line)
            first=self.parse_expression()
            if self.tokens[self.pos].t=="COMMA":
                elements=[first]
                while self.tokens[self.pos].t=="COMMA":
                    self.consume("COMMA")
                    elements.append(self.parse_expression())
                self.consume("RPAREN")
                return TupleLiteralNode(elements, line)
            self.consume("RPAREN")
            return first
        if self.tokens[self.pos].t=="ID" and self.peek(1).t=="DOT":
            # Allow property-like member tokens in expressions (e.g. list.iterable).
            if self.peek(3).t!="LPAREN":
                token_start=self.tokens[self.pos]
                obj=self.consume("ID").v
                self.consume("DOT")
                method=self.consume("ID").v
                return MethodCallNode(obj,method,[],token_start.line)
            return self.parse_method_call()
        return self.consume()

    def _parse_call_arguments(self):
        """Parse ``( ... )`` → positional args, optional ``name <- expr`` named args, and whether ``(`` was present."""
        args = []
        named = {}
        if self.tokens[self.pos].t != "LPAREN":
            return args, named, False
        self.consume("LPAREN")
        if self.tokens[self.pos].t == "RPAREN":
            self.consume("RPAREN")
            return args, named, True
        while True:
            if self.tokens[self.pos].t == "ID" and self.peek(1).t == "LEFTARROW":
                nk = self.consume("ID").v
                self.consume("LEFTARROW")
                named[nk] = self.parse_expression()
            else:
                args.append(self.parse_expression())
            if self.tokens[self.pos].t == "COMMA":
                self.consume("COMMA")
                continue
            if self.tokens[self.pos].t == "RPAREN":
                self.consume("RPAREN")
                break
            raise Exception(
                f"[Line {self.tokens[self.pos].line}] Expected ',' or ')' in argument list"
            )
        return args, named, True

    def parse_method_call(self):
        token_start=self.tokens[self.pos]
        obj=self.consume("ID").v
        self.consume("DOT")
        method=self.consume("ID").v
        args, named, had_paren = self._parse_call_arguments()
        if not had_paren and not args and not named:
            if self.tokens[self.pos].t not in ("COLON", "SEMICOLON"):
                raise Exception(
                    f"[Line {self.tokens[self.pos].line}] Expected '(' or ':' or ';' after {obj}.{method}"
                )

        if self.tokens[self.pos].t=="COLON":
            colon_tok = self.consume("COLON")
            colon_line = colon_tok.line
            # Keep call arguments for blocks that need them (conditions, params, random.run probability).
            param_tokens=(
                args
                if obj
                in (
                    "functionDefine",
                    "test",
                    "random",
                    "methodDefine",
                    "classDefine",
                    "errorDefine",
                )
                or (obj == "error" and method == "except")
                else []
            )
            body = self._parse_block_body_after_colon(token_start.line, colon_line)
            return BlockNode(obj, method, param_tokens, body, token_start.line)

        return MethodCallNode(obj, method, args, token_start.line, named if named else None)

    def _parse_block_body_after_colon(self, start_line: int, colon_line: int) -> list:
        """
        After ``obj.method(...):`` or ``name ... <- code:``.

        If the next statement starts on the **same line** as the colon, the body is a
        **single** statement and no trailing ``end`` is required.

        If the next token is on a **later line**, use classic ``... end`` block parsing.
        """
        if self.tokens[self.pos].t == "EOF":
            raise Exception(f"[Line {colon_line}] Expected statement or 'end' after ':'")
        if self.tokens[self.pos].line > colon_line:
            body = self._parse_block_body(start_line)
            self.consume("END")
            return body
        stmt = self.parse_statement()
        if stmt is None:
            raise Exception(f"[Line {colon_line}] Expected statement after ':'")
        return [stmt]

    def _parse_block_body(self, start_line):
        """Statements until matching end; does not consume the closing END."""
        body = []
        depth = 1
        while depth > 0:
            if self.tokens[self.pos].t == "EOF":
                raise Exception(f"[Line {start_line}] Unclosed block")
            if (
                self.tokens[self.pos].t == "ID"
                and self.peek(1).t == "DOT"
                and self.peek(4).t == "COLON"
            ):
                depth += 1
            if self.tokens[self.pos].t == "END":
                depth -= 1
                if depth == 0:
                    break
            stmt = self.parse_statement()
            if stmt:
                body.append(stmt)
        return body

    def _starts_function_alias(self) -> bool:
        """True for ``fname arg1 ... <- code:`` (not ``x <- expr`` assignment)."""
        p = self.pos
        if p >= len(self.tokens) or self.tokens[p].t != "ID":
            return False
        p += 1
        while p < len(self.tokens) and self.tokens[p].t == "ID":
            p += 1
        if p >= len(self.tokens) or self.tokens[p].t != "LEFTARROW":
            return False
        p += 1
        if p >= len(self.tokens) or self.tokens[p].t != "CODEKW":
            return False
        p += 1
        return p < len(self.tokens) and self.tokens[p].t == "COLON"

    def parse_use_module_path(self):
        parts=[self.consume("ID").v]
        while self.tokens[self.pos].t=="DOT":
            self.consume("DOT")
            if self.tokens[self.pos].t!="ID":
                raise Exception(f"[Line {self.tokens[self.pos].line}] Expected identifier after '.' in use path")
            parts.append(self.consume("ID").v)
        return ".".join(parts)

    def parse_statement(self):
        if self.tokens[self.pos].t=="EOF": return None
        if self.tokens[self.pos].t=="SEMICOLON":
            self.consume("SEMICOLON"); return None
        if self.tokens[self.pos].t=="USE":
            token_start=self.consume("USE")
            module=self.parse_use_module_path()
            self.consume("SEMICOLON")
            return ImportNode(module,token_start.line)
        if self.tokens[self.pos].t == "ID" and self.tokens[self.pos].v == "inherit":
            line = self.consume("ID").line
            module = self.parse_use_module_path()
            self.consume("SEMICOLON")
            return InheritNode(module, line)
        if self.tokens[self.pos].t == "QMARK" and self.peek(1).t == "LPAREN":
            line = self.consume("QMARK").line
            self.consume("LPAREN")
            cond = self.parse_expression()
            self.consume("RPAREN")
            self.consume("LEFTARROW")
            run_tok = self.consume("ID")
            if run_tok.v != "run":
                raise Exception(
                    f"[Line {run_tok.line}] ?(cond) <- run: expects keyword 'run' after '<-', got {run_tok.v!r}"
                )
            colon_tok = self.consume("COLON")
            body = self._parse_block_body_after_colon(line, colon_tok.line)
            return BlockNode("test", "ifTrue", [cond], body, line)
        if (
            self.tokens[self.pos].t == "ID"
            and self.tokens[self.pos].v == "constructorDefine"
            and self.peek(1).t == "LPAREN"
        ):
            line = self.consume("ID").line
            self.consume("LPAREN")
            self.consume("RPAREN")
            colon_tok = self.consume("COLON")
            body = self._parse_block_body_after_colon(line, colon_tok.line)
            return BlockNode("constructorDefine", "run", [], body, line)
        if (
            self.tokens[self.pos].t == "ID"
            and self.tokens[self.pos].v == "this"
            and self.peek(1).t == "DOT"
            and self.peek(2).t == "ID"
            and self.peek(3).t == "ASSIGN"
        ):
            line = self.consume("ID").line
            self.consume("DOT")
            field = self.consume("ID").v
            self.consume("ASSIGN")
            expr = self.parse_expression()
            self.consume("SEMICOLON")
            return ThisAssignNode(field, expr, line)
        if self.tokens[self.pos].t == "LBRACE":
            line = self.tokens[self.pos].line
            expr = self.parse_expression()
            if self.tokens[self.pos].t == "SEMICOLON":
                self.consume("SEMICOLON")
            return ExprStmtNode(expr, line)
        if self._starts_function_alias():
            token_start = self.tokens[self.pos]
            fname = self.consume("ID").v
            arg_tokens = []
            while self.tokens[self.pos].t == "ID":
                arg_tokens.append(self.consume("ID"))
            self.consume("LEFTARROW")
            self.consume("CODEKW")
            colon_tok = self.consume("COLON")
            body = self._parse_block_body_after_colon(token_start.line, colon_tok.line)
            return BlockNode("functionDefine", fname, arg_tokens, body, token_start.line)
        if self.tokens[self.pos].t == "ID" and self.peek(1).t == "LEFTARROW":
            token_start = self.tokens[self.pos]
            name = self.consume("ID").v
            self.consume("LEFTARROW")
            expr = self.parse_expression()
            if self.tokens[self.pos].t == "SEMICOLON":
                self.consume("SEMICOLON")
            return MethodCallNode(name, "setVar", [expr], token_start.line)
        node=self.parse_method_call()
        if self.tokens[self.pos].t=="SEMICOLON": self.consume("SEMICOLON")
        return node

    def parse(self):
        nodes=[]
        while self.tokens[self.pos].t!="EOF":
            stmt=self.parse_statement()
            if stmt: nodes.append(stmt)
        return self._merge_try_except(nodes)

    def _merge_try_except(self, stmts):
        out = []
        i = 0
        n = len(stmts)
        while i < n:
            s = stmts[i]
            if isinstance(s, BlockNode) and s.obj == "error" and s.method == "try":
                handlers = []
                j = i + 1
                while j < n:
                    nxt = stmts[j]
                    if (
                        isinstance(nxt, BlockNode)
                        and nxt.obj == "error"
                        and nxt.method == "except"
                    ):
                        handlers.append((nxt.args, nxt.body))
                        j += 1
                    else:
                        break
                out.append(TryExceptNode(s.body, handlers, s.line))
                i = j
            else:
                out.append(s)
                i += 1
        return out

# interpreter
class ReturnSignal(Exception):
    def __init__(self,value): self.value=value

class BreakSignal(Exception):
    pass

class ContinueSignal(Exception):
    pass


class SPLException(Exception):
    """Typed error visible to SPL error.except handlers (match on .kind)."""

    __slots__ = ("kind", "spl_line")

    def __init__(self, kind, message="", spl_line=0):
        self.kind = kind
        self.spl_line = spl_line
        msg = f"{kind}"
        if message:
            msg = f"{kind}: {message}"
        if spl_line:
            msg = f"[Line {spl_line}] {msg}"
        super().__init__(msg)


class SPLErrorType:
    """First-class SPL error kind for error.except(error.SomeError) (not a string)."""

    __slots__ = ("name",)

    def __init__(self, name: str):
        self.name = name

    def __str__(self):
        return self.name

    __repr__ = __str__


def _spl_except_kind_matches(want, spl_kind: str) -> bool:
    if isinstance(want, SPLErrorType):
        return want.name == spl_kind
    return str(want) == spl_kind

_TEST_BRANCH_ALIASES={
    "if":"ifTrue",
    "iftrue":"ifTrue","iffalse":"ifFalse",
    "elseif":"elseIfTrue",
    "elseifTrue":"elseIfTrue","elseifFalse":"elseIfFalse",
    "forloop":"forLoop",
    "While":"while",
}

def _resolve_user_file_path(rel_name):
    """Resolve a path relative to the current working directory; disallow .. and absolute paths."""
    if not isinstance(rel_name, str) or not rel_name.strip():
        raise Exception("file: path must be a non-empty string")
    if rel_name != rel_name.strip():
        raise Exception("file: path must not have leading or trailing whitespace")
    for part in rel_name.replace("\\", "/").split("/"):
        if part == "..":
            raise Exception("file: path must not contain '..'")
    if rel_name.startswith(("/", "\\")) or (len(rel_name) > 2 and rel_name[1] == ":"):
        raise Exception("file: path must be relative to the working directory (no absolute paths)")
    cwd = os.path.realpath(os.getcwd())
    full = os.path.realpath(os.path.join(cwd, rel_name))
    if full != cwd and not full.startswith(cwd + os.sep):
        raise Exception("file: path escapes the working directory")
    return full


class Interpreter:
    def __init__(self):
        # Scope chain: _scopes[0] is module/global; inner frames are block/function locals.
        self._scopes = [{"null": None}]
        self.funcs={}
        self.classes = {}
        self._class_def_stack = []
        self._instance_this_stack = []
        # Stack of real paths for SPL files currently executing (top = innermost use/inherit).
        # Enables use/inherit to resolve sibling paths next to the running script without copying to lib/.
        self._spl_file_stack = []
        self.if_stack=[]
        self._function_run_depth = 0
        self._file_read_handles={}
        self.library={
            "math":{"add":self._math_add,
                    "subtract":self._math_subtract,
                    "multiply":self._math_multiply,
                    "div":self._math_div,
                    "mod":self._math_mod,
                    "sqrtR":lambda a: math.sqrt(float(a)) if float(a)>=0 else None,
                    "sqrtI":lambda a: math.sqrt(float(a)) if float(a)>=0 else str(math.sqrt(-float(a)))+"i",
                    "floor":lambda a: math.floor(float(a)),
                    "ceil":lambda a: math.ceil(float(a)),
                    "round":lambda a: round(float(a))},
            "user":{"ask":lambda msg: input(str(msg))},
            "string":{"concatenate":lambda a,b: str(a)+str(b) if isinstance(a,str) and isinstance(b,str) else None,
                      "length":lambda s: len(str(s)) if isinstance(s,str) else None,
                      "convertInt":lambda string: int(string) if isinstance(string,str) else None,
                      "convertFloat":lambda string: float(string) if isinstance(string,str) else None,
                      "getChar":self._string_get_char,
                      "lowercase":lambda string: string.lower() if isinstance(string,str) else None,
                      "uppercase":lambda string: string.upper() if isinstance(string,str) else None,
                      "trim":lambda string: string.strip() if isinstance(string,str) else None,
                      "padLeft":lambda string,length,char: string.ljust(int(length),str(char)) if isinstance(string,str) and isinstance(length,int) and isinstance(char,str) else None,
                      "padRight":lambda string,length,char: string.rjust(int(length),str(char)) if isinstance(string,str) and isinstance(length,int) and isinstance(char,str) else None,
                      "padBoth":lambda string,length,char: string.center(int(length),str(char)) if isinstance(string,str) and isinstance(length,int) and isinstance(char,str) else None,
                      "padLeftIgnoreCase":lambda string,length,char: string.ljust(int(length),str(char)) if isinstance(string,str) and isinstance(length,int) and isinstance(char,str) else None,
                      "padRightIgnoreCase":lambda string,length,char: string.rjust(int(length),str(char)) if isinstance(string,str) and isinstance(length,int) and isinstance(char,str) else None,
                      "padBothIgnoreCase":lambda string,length,char: string.center(int(length),str(char)) if isinstance(string,str) and isinstance(length,int) and isinstance(char,str) else None,
                      "replaceAllIgnoreCase":lambda string,old,new: string.replace(old,new) if isinstance(string,str) and isinstance(old,str) and isinstance(new,str) else None,
                      "replaceFirstIgnoreCase":lambda string,old,new: string.replace(old,new,1) if isinstance(string,str) and isinstance(old,str) and isinstance(new,str) else None,
                      "replaceLastIgnoreCase":lambda string,old,new: string.replace(old,new,1) if isinstance(string,str) and isinstance(old,str) and isinstance(new,str) else None,
                      "reverse":lambda s: s[::-1] if isinstance(s,str) else None,
                      "toAsciiBinary":lambda s: "".join(format(ord(c), "08b") for c in s) if isinstance(s,str) else None,
                      "fromAsciiBinaryMod":lambda s,m: _spl_from_ascii_binary_mod(s,m)},
            "float":{"convertInt":self._float_convert_int},
            "random":{"randint":self._random_randint,
                      "randfloat":self._random_randfloat},
            "test":{"isEqual":lambda a,b:1 if a==b else 0,
                    "isEqualNumber":lambda a,b:1 if float(a)==float(b) else 0,
                    "isEqualString":lambda a,b:1 if str(a)==str(b) else 0,
                    "isEven":lambda n:1 if float(n)%2==0 else 0,
                    "isOdd":lambda n:1 if float(n)%2!=0 else 0,
                    "isGreater":lambda a,b:1 if float(a)>float(b) else 0,
                    "isLess":lambda a,b:1 if float(a)<float(b) else 0,
                    "find":lambda string,substring: string.find(substring) if isinstance(string,str) and isinstance(substring,str) else None,
                    "replaceAll":lambda string,old,new: string.replace(old,new) if isinstance(string,str) and isinstance(old,str) and isinstance(new,str) else None,
                    "replaceFirst":lambda string,old,new: string.replace(old,new,1) if isinstance(string,str) and isinstance(old,str) and isinstance(new,str) else None,
                    "replaceLast":lambda string,old,new: string.replace(old,new,1) if isinstance(string,str) and isinstance(old,str) and isinstance(new,str) else None,
                    "replaceAllIgnoreCase":lambda string,old,new: string.replace(old,new) if isinstance(string,str) and isinstance(old,str) and isinstance(new,str) else None,
                    "replaceFirstIgnoreCase":lambda string,old,new: string.replace(old,new,1) if isinstance(string,str) and isinstance(old,str) and isinstance(new,str) else None,
                    "replaceLastIgnoreCase":lambda string,old,new: string.replace(old,new,1) if isinstance(string,str) and isinstance(old,str) and isinstance(new,str) else None},
            "list":{"createList":self.lib_create_list,
                    "get":self.lib_list_get,
                    "remove":self.lib_list_remove,
                    "removeAll":self.lib_list_remove_all,
                    "change":self.lib_list_change,
                    "copy":self.lib_list_deep_copy,
                    "append":self.lib_list_append,
                    "sort":self.lib_list_sort,
                    "iterable":lambda: "__list_iterable_marker__",
                    "iterate":lambda: "__list_iterate_marker__"},
            "hash":{"getValue":self._hash_get_value,
                    "getKey":self._hash_get_key,
                    "add":self._hash_add,
                    "delete":self._hash_delete},
            "type":{"isNumber":lambda x:1 if isinstance(x,(int,float)) and not isinstance(x,bool) else 0,
                    "isString":lambda x:1 if isinstance(x,str) else 0,
                    "isBoolean":lambda x:1 if isinstance(x,int) and (x==0 or x==1) else 0,
                    "isList":lambda x:1 if isinstance(x,list) else 0,
                    "isTuple":lambda x:1 if isinstance(x,tuple) else 0,
                    "isSet":lambda x:1 if isinstance(x,SPLSet) else 0,
                    "isFunctionRef":lambda x:1 if isinstance(x,SPLFunctionRef) else 0,
                    "isNull":lambda x:1 if x is None else 0,
                    "isHash":lambda x:1 if isinstance(x,dict) else 0,
                    "isInstance":lambda x:1 if isinstance(x,SPLInstance) else 0,
                    "isClass":lambda x:1 if isinstance(x,SPLClass) else 0},
            "file":{"readline":self._file_readline,
                    "write":self._file_write,
                    "append":self._file_append},
            "tuple":{"createTuple":self.lib_tuple_create,
                     "get":self.lib_tuple_get},
            "set":{"createSet":self.lib_set_create,
                   "append":self.lib_set_append,
                   "remove":self.lib_set_remove,
                   "removeByIndex":self.lib_set_remove_by_index},
            "error":{
                "DivisionByZeroError":lambda:SPLErrorType("DivisionByZeroError"),
                "IndexOutOfRangeError":lambda:SPLErrorType("IndexOutOfRangeError"),
                "UndefinedVariableError":lambda:SPLErrorType("UndefinedVariableError"),
                "FileNotFoundError":lambda:SPLErrorType("FileNotFoundError"),
                "IOError":lambda:SPLErrorType("IOError"),
            },
        }

    @property
    def vars(self):
        """Module-level global bindings (same dict as the root of the scope chain). Host code may read/write this."""
        return self._scopes[0]

    def _scope_push_empty(self):
        self._scopes.append({})

    def _scope_push_bindings(self, bindings: dict):
        self._scopes.append(dict(bindings))

    def _scope_pop(self):
        if len(self._scopes) <= 1:
            raise RuntimeError("internal error: cannot pop global scope")
        self._scopes.pop()

    def _scope_assign(self, name: str, value):
        """Assign: update innermost existing binding for name, else define in the innermost frame."""
        for i in range(len(self._scopes) - 1, -1, -1):
            if name in self._scopes[i]:
                self._scopes[i][name] = value
                return
        self._scopes[-1][name] = value

    def _scope_get(self, name: str, line=None):
        for i in range(len(self._scopes) - 1, -1, -1):
            if name in self._scopes[i]:
                return self._scopes[i][name]
        raise SPLException("UndefinedVariableError", name, line or 0)

    def _normalize_numeric_result(self, result, inputs):
        # keep integer results as ints unless any input was explicitly decimal.
        if any(isinstance(v,float) for v in inputs):
            return float(result)
        if isinstance(result,float) and result.is_integer():
            return int(result)
        return result

    def _string_get_char(self, string, index):
        if not isinstance(string, str) or not isinstance(index, (int, float)):
            return None
        idx = int(index)
        if idx < 0 or idx >= len(string):
            raise SPLException("IndexOutOfRangeError", f"string index {idx} for length {len(string)}")
        return string[idx]

    def _keymap_create_keymap(self, node, line):
        if not node.arg or len(node.arg) != 1:
            raise Exception(f"[Line {line}] keymap.createKeyMap requires (variableName)")
        name_arg = node.arg[0]
        if not isinstance(name_arg, Token) or name_arg.t != "ID":
            raise Exception(f"[Line {line}] keymap.createKeyMap name must be an identifier")
        if not self._class_def_stack:
            raise Exception(f"[Line {line}] keymap.createKeyMap only allowed inside classDefine")
        cls = self._class_def_stack[-1]
        km = SPLKeyMap(cls)
        self._scope_assign(name_arg.v, km)
        return km

    def _string_sorted(self, node, line):
        pos_args = [self.evaluate(a) for a in (node.arg or [])]
        named = getattr(node, "named", None) or {}
        named_eval = {k: self.evaluate(v) for k, v in named.items()}
        s = pos_args[0] if len(pos_args) > 0 else None
        if s is None:
            raise Exception(f"[Line {line}] string.sorted requires the string as first argument")
        if not isinstance(s, str):
            raise Exception(f"[Line {line}] string.sorted: first argument must be a string")
        km = named_eval.get("key")
        if km is None and len(pos_args) > 1:
            km = pos_args[1]
        rev = named_eval.get("reverse")
        if rev is None and len(pos_args) > 2:
            rev = pos_args[2]
        if km is None:
            raise Exception(
                f"[Line {line}] string.sorted requires key (second positional or name key <- keymap)"
            )
        if not isinstance(km, SPLKeyMap):
            raise Exception(
                f"[Line {line}] string.sorted: key must be a keymap from keymap.createKeyMap"
            )
        if rev is None:
            rev = 0
        if isinstance(rev, bool):
            reverse_bool = rev
        else:
            reverse_bool = float(rev) != 0
        cls = km.spl_class
        entries = cls.keymap_entries
        if not entries:
            raise Exception(f"[Line {line}] string.sorted: class has no keymapDefine.keymap body")
        curr = {}
        km.curr = curr
        inst = SPLInstance(cls)
        for fn, fv in cls.field_defaults.items():
            inst.fields[fn] = copy.deepcopy(fv)
        for fn in ("string1", "string", "s"):
            if fn in cls.field_defaults or fn in inst.fields:
                inst.fields[fn] = s
        inst.fields["keymap"] = km
        bindings = {"this": inst}
        for k, v in inst.fields.items():
            bindings[k] = v
        self._scope_push_bindings(bindings)
        try:
            for ch, expr_ast in entries:
                km.curr = curr
                curr[ch] = self.evaluate(expr_ast)
        finally:
            self._scope_pop()
        for c in s:
            if c not in curr:
                raise Exception(
                    f"[Line {line}] string.sorted: character {c!r} has no keymap entry"
                )
        weights = {i: curr[s[i]] for i in range(len(s))}
        idx_sorted = sorted(
            range(len(s)),
            key=lambda i: (weights[i], i),
            reverse=reverse_bool,
        )
        return "".join(s[i] for i in idx_sorted)

    def _math_add(self,a,b):
        af=float(a); bf=float(b)
        return self._normalize_numeric_result(af+bf,(a,b))

    def _math_subtract(self,a,b):
        af=float(a); bf=float(b)
        return self._normalize_numeric_result(af-bf,(a,b))

    def _math_multiply(self,a,b):
        af=float(a); bf=float(b)
        return self._normalize_numeric_result(af*bf,(a,b))

    def _math_div(self, a, b):
        af = float(a)
        bf = float(b)
        if bf == 0:
            raise SPLException("DivisionByZeroError", "division by zero")
        return self._normalize_numeric_result(af / bf, (a, b))

    def _math_mod(self,a,b):
        af=float(a); bf=float(b)
        if bf==0:
            return None
        return self._normalize_numeric_result(af%bf,(a,b))

    def _hash_get_value(self, key, h):
        # O(1) average: single dict lookup (hash table under the hood).
        if not isinstance(h, dict):
            raise Exception("hash.getValue expects (key, hash)")
        k = key
        if isinstance(k, float) and not isinstance(k, bool) and k.is_integer():
            k = int(k)
        if k in h:
            return h[k]
        return h.get(key)

    def _hash_get_key(self, value, h):
        # O(n): must scan entries when searching by value.
        if not isinstance(h, dict):
            raise Exception("hash.getKey expects (value, hash)")
        for k, v in h.items():
            if v == value:
                return k
        return None

    def _hash_add(self, pair, h):
        if not isinstance(h, dict):
            raise Exception("hash.add expects ((key, value), hash)")
        if not isinstance(pair, tuple) or len(pair) != 2:
            raise Exception("hash.add first argument must be (key, value)")
        k, v = pair[0], pair[1]
        h[k] = v
        return h

    def _hash_delete(self, key, h):
        if not isinstance(h, dict):
            raise Exception("hash.delete expects (key, hash)")
        h.pop(key, None)
        return h

    def _float_convert_int(self, value):
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            raise Exception("float.convertInt expects a numeric value")
        fval=float(value)
        if not fval.is_integer():
            raise Exception(f"float.convertInt requires a whole-number float, got {value!r}")
        return int(fval)

    def _random_randint(self, lower, upper):
        if isinstance(lower, bool) or isinstance(upper, bool):
            raise Exception("random.randint expects numeric bounds")
        lo, hi = int(lower), int(upper)
        if lo > hi:
            raise Exception("random.randint: lower must be <= upper")
        return random.randint(lo, hi)

    def _random_randfloat(self, lower, upper):
        if isinstance(lower, bool) or isinstance(upper, bool):
            raise Exception("random.randfloat expects numeric bounds")
        a, b = float(lower), float(upper)
        if a > b:
            raise Exception("random.randfloat: lower must be <= upper")
        return random.uniform(a, b)

    def _file_close_read_handle(self, path):
        fh = self._file_read_handles.pop(path, None)
        if fh is not None:
            try:
                fh.close()
            except OSError:
                pass

    def _file_readline(self, rel):
        p = _resolve_user_file_path(str(rel))
        if p not in self._file_read_handles:
            try:
                self._file_read_handles[p] = open(p, "r", encoding="utf-8", newline="")
            except FileNotFoundError as e:
                raise SPLException("FileNotFoundError", str(e)) from e
            except OSError as e:
                raise SPLException("IOError", str(e)) from e
        fh = self._file_read_handles[p]
        line = fh.readline()
        if line == "":
            return ""
        if line.endswith("\n"):
            line = line[:-1]
        if line.endswith("\r"):
            line = line[:-1]
        return line

    def _file_write(self, text, rel):
        p = _resolve_user_file_path(str(rel))
        self._file_close_read_handle(p)
        try:
            with open(p, "w", encoding="utf-8", newline="\n") as out:
                out.write(str(text))
        except OSError as e:
            raise SPLException("IOError", str(e)) from e

    def _file_append(self, text, rel):
        p = _resolve_user_file_path(str(rel))
        self._file_close_read_handle(p)
        try:
            need_nl = os.path.isfile(p) and os.path.getsize(p) > 0
            with open(p, "a", encoding="utf-8", newline="\n") as out:
                if need_nl:
                    out.write("\n")
                out.write(str(text))
        except OSError as e:
            raise SPLException("IOError", str(e)) from e

    def lib_create_list(self, items, name_token):
        evaluated=[self.evaluate(i) for i in items]
        name=name_token if isinstance(name_token,str) else name_token.v
        self._scope_assign(name, evaluated)
        return evaluated
    def lib_list_get(self,index,list_var):
        idx=int(index)
        if idx < 0 or idx >= len(list_var):
            raise SPLException("IndexOutOfRangeError", f"list index {idx} for length {len(list_var)}")
        return list_var[idx]
    def lib_list_remove(self,element,list_var):
        if element in list_var: list_var.remove(element)
    def lib_list_remove_all(self,element,list_var):
        while element in list_var: list_var.remove(element)
    def lib_list_change(self,index,new_value,list_var):
        idx = int(index)
        if idx < 0 or idx >= len(list_var):
            raise SPLException("IndexOutOfRangeError", f"list index {idx} for length {len(list_var)}")
        list_var[idx] = new_value
    def lib_list_deep_copy(self,list_var,new_name_token):
        new_list=copy.deepcopy(list_var)
        name=new_name_token if isinstance(new_name_token,str) else new_name_token.v
        self._scope_assign(name, new_list)
        return new_list
    def lib_list_append(self,item,list_var): list_var.append(item); return list_var

    def _spl_truthy_reverse(self, reverse_arg):
        """SPL booleans are 0/1; accept int/float/bool."""
        if isinstance(reverse_arg, bool):
            return reverse_arg
        if isinstance(reverse_arg, (int, float)):
            return int(reverse_arg) != 0
        return bool(reverse_arg)

    def lib_list_sort(self, list_var, key_name, reverse_arg):
        """In-place sort. key: alpha, numeric, ascii, utf-8, utf-16, utf-32. reverse: truthy = descending."""
        if not isinstance(list_var, list):
            raise Exception("list.sort expects a list as first argument")
        raw = str(key_name).strip().lower().replace("_", "-")
        key_aliases = {
            "alpha": "alpha",
            "numeric": "numeric",
            "ascii": "ascii",
            "utf-8": "utf-8",
            "utf8": "utf-8",
            "utf-16": "utf-16",
            "utf16": "utf-16",
            "utf-32": "utf-32",
            "utf32": "utf-32",
        }
        if raw not in key_aliases:
            raise Exception(
                "list.sort key must be one of: alpha, numeric, ascii, utf-8, utf-16, utf-32; "
                f"got {key_name!r}"
            )
        mode = key_aliases[raw]
        rev = self._spl_truthy_reverse(reverse_arg)

        def key_fn(x):
            if mode == "alpha":
                return str(x)
            if mode == "numeric":
                return float(x)
            if mode == "ascii":
                return tuple(map(ord, str(x)))
            s = str(x)
            if mode == "utf-8":
                return s.encode("utf-8")
            if mode == "utf-16":
                return s.encode("utf-16-le")
            if mode == "utf-32":
                return s.encode("utf-32-le")
            raise RuntimeError("lib_list_sort: internal unknown mode")

        try:
            list_var.sort(key=key_fn, reverse=rev)
        except (TypeError, ValueError) as e:
            raise Exception(f"list.sort failed: {e}") from e
        return list_var

    def _function_ref(self, arg_expr, line):
        """Build SPLFunctionRef: identifier is the function name; other expressions must evaluate to a string name."""
        if isinstance(arg_expr, Token) and arg_expr.t == "ID":
            name = arg_expr.v
        else:
            name = self.evaluate(arg_expr)
            if not isinstance(name, str):
                raise Exception(
                    f"[Line {line}] function.ref expects a function name (identifier or string), "
                    f"got {type(name).__name__}"
                )
        return SPLFunctionRef(name)

    def _invoke_user_function(self, fn_name, arg_vals, line):
        """Run a user-defined function body; returns the value from return.* or None."""
        if fn_name not in self.funcs:
            raise Exception(f"[Line {line}] Error: Undefined Function: {fn_name}")
        params, body = self.funcs[fn_name]
        if len(arg_vals) != len(params):
            raise Exception(
                f"[Line {line}] function.{fn_name} expects {len(params)} args, got {len(arg_vals)}"
            )
        param_names = [p.v if isinstance(p, Token) else p for p in params]
        self._scope_push_bindings(dict(zip(param_names, arg_vals)))
        old_if = self.if_stack
        self.if_stack = []
        self._function_run_depth += 1
        try:
            try:
                for sub in body:
                    try:
                        self.run(sub, True)
                    except BreakSignal:
                        raise Exception("Error: test.break used outside of a loop")
                    except ContinueSignal:
                        raise Exception("Error: test.continue used outside of a loop")
            except ReturnSignal as rs:
                return rs.value
            return None
        finally:
            self._function_run_depth -= 1
            self.if_stack = old_if
            self._scope_pop()

    def _spl_inst_uses_alltypes_return_method(self, inst: SPLInstance) -> bool:
        """True if inst's return method is the same (params, body) as class AllTypes."""
        at = self.classes.get("AllTypes")
        if not at:
            return False
        ref = at.methods.get("return")
        if not ref:
            return False
        m = inst.cls.method_lookup("return")
        return m is not None and m is ref

    def _field_visibility_for(self, cls: SPLClass, name: str) -> str:
        vis = cls.field_visibility.get(name)
        if vis:
            return vis
        if cls.parent:
            return self._field_visibility_for(cls.parent, name)
        return "private"

    def _instance_get_field(
        self, inst: SPLInstance, field_name: str, line, allow_private: bool
    ):
        vis = self._field_visibility_for(inst.cls, field_name)
        if vis == "private" and not allow_private:
            raise Exception(f"[Line {line}] private field {field_name!r}")
        if field_name in inst.fields:
            return inst.fields[field_name]
        if field_name in inst.cls.field_defaults:
            return inst.cls.field_defaults[field_name]
        raise Exception(f"[Line {line}] unknown field {field_name!r} on instance")

    def _dispatch_instance_member(self, node: MethodCallNode, as_statement: bool = False):
        """Instance method call or field read; _DISPATCH_SKIP if not applicable."""
        if node.obj in self.library or node.obj == "method":
            return _DISPATCH_SKIP
        if node.method in ("setVar", "public", "private"):
            return _DISPATCH_SKIP
        if node.obj == "this":
            if not self._instance_this_stack:
                raise Exception(f"[Line {node.line}] this.{node.method} outside of class")
            inst = self._instance_this_stack[-1]
        else:
            try:
                val = self._scope_get(node.obj, node.line)
            except SPLException:
                return _DISPATCH_SKIP
            if not isinstance(val, SPLInstance):
                return _DISPATCH_SKIP
            inst = val
        arg_vals = [self.evaluate(a) for a in (node.arg or [])]
        m = inst.cls.method_lookup(node.method)
        if m is not None:
            return self._invoke_instance_method(
                inst, node.method, arg_vals, node.line, as_statement
            )
        if len(arg_vals) == 0:
            allow_private = node.obj == "this" or (
                self._instance_this_stack and self._instance_this_stack[-1] is inst
            )
            return self._instance_get_field(inst, node.method, node.line, allow_private)
        raise Exception(
            f"[Line {node.line}] No method {node.method!r} on class {inst.cls.name!r}"
        )

    def _instantiate_class(self, var_name: str, class_name: str, line):
        cls = self.classes.get(class_name)
        if cls is None:
            raise Exception(f"[Line {line}] No class named {class_name!r}")
        inst = SPLInstance(cls)
        for fn, fv in cls.field_defaults.items():
            inst.fields[fn] = copy.deepcopy(fv)
        self._instance_this_stack.append(inst)
        self._scope_push_bindings({"this": inst})
        try:
            if cls.constructor_body:
                for sub in cls.constructor_body:
                    self.run(sub, False)
        finally:
            self._scope_pop()
            self._instance_this_stack.pop()
        self._scope_assign(var_name, inst)
        return inst

    def _invoke_instance_method(
        self,
        inst: SPLInstance,
        method_name: str,
        arg_vals,
        line,
        as_statement: bool = False,
    ):
        m = inst.cls.method_lookup(method_name)
        if not m:
            raise Exception(
                f"[Line {line}] No method {method_name!r} on class {inst.cls.name!r}"
            )
        params, body = m
        if len(arg_vals) != len(params):
            raise Exception(
                f"[Line {line}] method.{method_name} expects {len(params)} args, got {len(arg_vals)}"
            )
        param_names = [p.v if isinstance(p, Token) else p for p in params]
        bindings = dict(zip(param_names, arg_vals))
        bindings["this"] = inst
        self._instance_this_stack.append(inst)
        self._scope_push_bindings(bindings)
        old_if = self.if_stack
        self.if_stack = []
        try:
            try:
                for sub in body:
                    try:
                        self.run(sub, as_statement)
                    except BreakSignal:
                        raise Exception("Error: test.break used outside of a loop")
                    except ContinueSignal:
                        raise Exception("Error: test.continue used outside of a loop")
            except ReturnSignal as rs:
                if (
                    as_statement
                    and method_name == "return"
                    and self._spl_inst_uses_alltypes_return_method(inst)
                ):
                    raise rs
                return rs.value
            return None
        finally:
            self.if_stack = old_if
            self._scope_pop()
            self._instance_this_stack.pop()

    def _coerce_name_literal(self, expr, line):
        if isinstance(expr, Token) and expr.t == "ID":
            return expr.v
        if isinstance(expr, Token) and expr.t == "STRING":
            return expr.v
        v = self.evaluate(expr)
        if not isinstance(v, str):
            raise Exception(
                f"[Line {line}] expected identifier or string name, got {type(v).__name__}"
            )
        return v

    def _path_is_under(self, path: str, base_real: str) -> bool:
        path = os.path.realpath(path)
        base_real = os.path.realpath(base_real)
        return path == base_real or path.startswith(base_real + os.sep)

    def _try_resolve_import_beside_current_spl(self, module_name, line):
        """If an SPL file is executing, try a file in the same directory before lib/."""
        if not self._spl_file_stack:
            return None
        if not module_name or module_name.strip() != module_name:
            return None
        if ".." in module_name or module_name.startswith(("/", "\\")):
            return None
        base_dir = os.path.dirname(self._spl_file_stack[-1])
        base_real = os.path.realpath(base_dir)
        if "." in module_name:
            cand = os.path.realpath(os.path.join(base_dir, module_name))
            if not self._path_is_under(cand, base_real):
                raise Exception(f"[Line {line}] import path escapes directory")
            if os.path.isfile(cand):
                return cand, os.path.splitext(module_name)[1].lower()
            return None
        extensionless_checks = [
            (".spl", module_name + ".spl", _spl_allows_extensionless_import),
            (".py", module_name + ".py", _py_allows_extensionless_import),
            (".c", module_name + ".c", _c_cpp_allows_extensionless_import),
            (".cpp", module_name + ".cpp", _c_cpp_allows_extensionless_import),
            (".cc", module_name + ".cc", _c_cpp_allows_extensionless_import),
            (".cxx", module_name + ".cxx", _c_cpp_allows_extensionless_import),
            (".java", module_name + ".java", _java_allows_extensionless_import),
        ]
        candidates = []
        for ext, rel, allow_fn in extensionless_checks:
            path = os.path.realpath(os.path.join(base_dir, rel))
            if not self._path_is_under(path, base_real):
                continue
            if os.path.isfile(path) and allow_fn(path):
                candidates.append((ext, path))
        if len(candidates) > 1:
            kinds = ", ".join(f"{module_name}{e}" for e, _ in candidates)
            raise Exception(
                f"[Line {line}] Ambiguous use {module_name!r}: multiple libraries opt in ({kinds}); "
                f"use an explicit file extension in the use statement"
            )
        if len(candidates) == 1:
            ext, path = candidates[0]
            return path, ext
        return None

    def _resolve_library_import(self, module_name, line):
        """Resolve use/inherit: try same directory as the executing SPL file, then lib/."""
        local = self._try_resolve_import_beside_current_spl(module_name, line)
        if local is not None:
            return local
        return _resolve_library_import_lib(module_name, line)

    def _run_inherit(self, module_path: str, line):
        if not self._class_def_stack:
            raise Exception(f"[Line {line}] inherit only allowed inside classDefine")
        lib_path, ext = self._resolve_library_import(module_path, line)
        if ext != ".spl":
            raise Exception(f"[Line {line}] inherit expects a .spl file")
        classes_before = set(self.classes.keys())
        self._exec_spl_file(lib_path, line)
        classes_after = set(self.classes.keys())
        new_ones = classes_after - classes_before
        if not new_ones:
            raise Exception(f"[Line {line}] inherit: no new class defined in {module_path!r}")
        parent_name = sorted(new_ones)[-1]
        parent = self.classes[parent_name]
        self._class_def_stack[-1].merge_parent(parent)

    def _exec_spl_file(self, lib_path, line):
        lib_path = os.path.realpath(lib_path)
        self._spl_file_stack.append(lib_path)
        try:
            with open(lib_path, encoding="utf-8") as f:
                src = f.read()
            for sub in Parser(tokenize(src)).parse():
                try:
                    self.run(sub)
                except BreakSignal:
                    raise Exception("Error: test.break used outside of a loop")
                except ContinueSignal:
                    raise Exception("Error: test.continue used outside of a loop")
        finally:
            self._spl_file_stack.pop()

    def lib_tuple_create(self, tup, name_token):
        if not isinstance(tup, tuple):
            raise Exception("tuple.createTuple expects a (a,b,...) tuple literal as the first argument")
        if isinstance(name_token, Token) and name_token.t == "ID":
            name = name_token.v
        elif isinstance(name_token, str):
            name = name_token
        else:
            raise Exception("tuple.createTuple second argument must be a variable name or string")
        self._scope_assign(name, tup)
        return tup

    def lib_tuple_get(self, index, tup):
        if not isinstance(tup, tuple):
            raise Exception("tuple.get expects a tuple value")
        idx = int(index)
        if idx < 0 or idx >= len(tup):
            raise SPLException("IndexOutOfRangeError", f"tuple index {idx} for length {len(tup)}")
        return tup[idx]

    def lib_set_create(self, raw, name_token):
        if isinstance(name_token, Token) and name_token.t == "ID":
            name = name_token.v
        elif isinstance(name_token, str):
            name = name_token
        else:
            raise Exception("set.createSet second argument must be a variable name or string")
        if isinstance(raw, SPLSet):
            s = SPLSet(raw._items)
        elif isinstance(raw, (list, tuple)):
            s = SPLSet(raw)
        elif isinstance(raw, dict) and len(raw) == 0:
            s = SPLSet()
        else:
            raise Exception(
                "set.createSet expects a {a,b,...} set literal, or [] list, or an existing SPL set"
            )
        self._scope_assign(name, s)
        return s

    def lib_set_append(self, item, s):
        if not isinstance(s, SPLSet):
            raise Exception("set.append expects a set value")
        s.append(item)
        return s

    def lib_set_remove(self, item, s):
        if not isinstance(s, SPLSet):
            raise Exception("set.remove expects a set value")
        s.remove_value(item)
        return s

    def lib_set_remove_by_index(self, index, s):
        if not isinstance(s, SPLSet):
            raise Exception("set.removeByIndex expects a set value")
        s.remove_index(index)
        return s

    def _eval_with_bound_var(self,var_name,var_value,expr):
        self._scope_push_bindings({var_name: var_value})
        try:
            return self.evaluate(expr)
        finally:
            self._scope_pop()

    def _extract_list_binding(self,binding_expr,expected_marker):
        if not isinstance(binding_expr,MethodCallNode):
            raise Exception("list.convert* first argument must be like x.setVar(list.iterable) or x.setVar(list.iterate)")
        if binding_expr.method!="setVar" or not binding_expr.arg or len(binding_expr.arg)!=1:
            raise Exception("list.convert* first argument must be a setVar call")
        marker_expr=binding_expr.arg[0]
        if not isinstance(marker_expr,MethodCallNode) or marker_expr.obj!="list":
            raise Exception("list.convert* binding must assign list.iterable or list.iterate")
        if marker_expr.method!=expected_marker:
            raise Exception(f"Expected list.{expected_marker} in binding, got list.{marker_expr.method}")
        return binding_expr.obj

    def _list_convert(self,var_name,fn_expr,list_var):
        if not isinstance(list_var,list):
            raise Exception("list.convert expects a list argument")
        for i,item in enumerate(list_var):
            list_var[i]=self._eval_with_bound_var(var_name,item,fn_expr)
        return list_var

    def _list_convert_if(self,var_name,fn_expr,cond_expr,list_var,should_convert_when_true,use_index=False):
        if not isinstance(list_var,list):
            raise Exception("list.convertIf* expects a list argument")
        for i,item in enumerate(list_var):
            bound_value=i if use_index else item
            cond=self._eval_with_bound_var(var_name,bound_value,cond_expr)
            cond_true=(cond!=0)
            if cond_true==should_convert_when_true:
                list_var[i]=self._eval_with_bound_var(var_name,bound_value,fn_expr)
        return list_var

    def _typed_print(self,method,arg_vals,line):
        if not arg_vals:
            raise Exception(f"[Line {line}] print.{method} requires an argument")
        val=arg_vals[0]
        if method=="string":
            if not isinstance(val,str):
                raise Exception(f"[Line {line}] print.string expected str, got {type(val).__name__}: {val!r}")
            print(val)
            return None
        if method=="number":
            if not isinstance(val,(int,float)) or isinstance(val,bool):
                raise Exception(f"[Line {line}] print.number expected int or float, got {type(val).__name__}: {val!r}")
            print(val)
            return None
        if method=="boolean":
            if val not in (0,1):
                raise Exception(f"[Line {line}] print.boolean expected 0 or 1, got {val!r}")
            print(int(val))
            return None
        if method=="list":
            if not isinstance(val,list):
                raise Exception(f"[Line {line}] print.list expected list, got {type(val).__name__}: {val!r}")
            print(val)
            return None
        if method=="hash":
            if not isinstance(val,dict):
                raise Exception(f"[Line {line}] print.hash expected dict, got {type(val).__name__}: {val!r}")
            print(val)
            return None
        if method=="tuple":
            if not isinstance(val,tuple):
                raise Exception(f"[Line {line}] print.tuple expected tuple, got {type(val).__name__}: {val!r}")
            print(val)
            return None
        if method=="set":
            if not isinstance(val,SPLSet):
                raise Exception(f"[Line {line}] print.set expected set, got {type(val).__name__}: {val!r}")
            print(val)
            return None
        if method=="functionRef":
            if not isinstance(val, SPLFunctionRef):
                raise Exception(f"[Line {line}] print.functionRef expected function ref, got {type(val).__name__}: {val!r}")
            print(val)
            return None
        if method=="instance":
            if not isinstance(val, SPLInstance):
                raise Exception(f"[Line {line}] print.instance expected instance, got {type(val).__name__}: {val!r}")
            print(f"<instance {val.cls.name}>")
            return None
        if method=="class":
            if not isinstance(val, SPLClass):
                raise Exception(f"[Line {line}] print.class expected class, got {type(val).__name__}: {val!r}")
            print(f"<class {val.name}>")
            return None
        raise Exception(f"[Line {line}] unknown print.{method}")

    def run(self, node, as_statement=None):
        if as_statement is None:
            as_statement = self._function_run_depth > 0
        if isinstance(node,ImportNode):
            lib_path, ext = self._resolve_library_import(node.module, node.line)
            if ext==".py":
                mod_name="spl_lib_"+re.sub(r"[^A-Za-z0-9_]", "_", os.path.basename(lib_path))
                spec=importlib.util.spec_from_file_location(mod_name,lib_path)
                if spec is None or spec.loader is None:
                    raise Exception(f"[Line {node.line}] Cannot load Python library: {lib_path}")
                pymod=importlib.util.module_from_spec(spec)
                spec.loader.exec_module(pymod)
                reg = getattr(pymod, "spl_register", None)
                if callable(reg):
                    reg(self)
                return None
            if ext in _NATIVE_SOURCE_EXTS:
                _register_native_c_library(self, lib_path, ext, node.line)
                return None
            if ext == _NATIVE_JAVA_EXT:
                _load_java_library(self, lib_path, node.line)
                return None
            self._exec_spl_file(lib_path, node.line)
            return None
        if isinstance(node, InheritNode):
            self._run_inherit(node.module, node.line)
            return None
        if isinstance(node, ThisAssignNode):
            if not self._instance_this_stack:
                raise Exception(
                    f"[Line {node.line}] this.{node.field} = ... only allowed inside constructorDefine or methodDefine (no active this)"
                )
            inst = self._instance_this_stack[-1]
            inst.fields[node.field] = self.evaluate(node.expr)
            return None
        if isinstance(node, ExprStmtNode):
            self.evaluate(node.expr)
            return None
        if isinstance(node, TryExceptNode):
            self._scope_push_empty()
            try:
                try:
                    for sub in node.try_body:
                        self.run(sub, as_statement)
                except ReturnSignal:
                    raise
                except BreakSignal:
                    raise
                except ContinueSignal:
                    raise
                except SPLException as e:
                    for handler_args, handler_body in node.handlers:
                        if not handler_args:
                            raise Exception(
                                f"[Line {node.line}] error.except requires an error type, e.g. error.DivisionByZeroError or \"DivisionByZeroError\""
                            )
                        want = self.evaluate(handler_args[0])
                        if _spl_except_kind_matches(want, e.kind):
                            self._scope_push_empty()
                            try:
                                for sub in handler_body:
                                    self.run(sub, as_statement)
                            finally:
                                self._scope_pop()
                            return None
                    raise e
                return None
            finally:
                self._scope_pop()
        if isinstance(node,BlockNode):
            if node.obj == "classDefine":
                name = node.method
                cls = SPLClass(name)
                self._class_def_stack.append(cls)
                try:
                    for sub in node.body:
                        self.run(sub, as_statement)
                finally:
                    self._class_def_stack.pop()
                self.classes[name] = cls
                return None
            if node.obj == "errorDefine":
                ename = node.method
                self.library["error"][ename] = (lambda nm=ename: (lambda: SPLErrorType(nm)))()
                self._scopes[0][ename] = SPLErrorType(ename)
                for sub in node.body:
                    self.run(sub, as_statement)
                return None
            if node.obj == "methodDefine":
                if not self._class_def_stack:
                    raise Exception(
                        f"[Line {node.line}] methodDefine.{node.method} only allowed inside classDefine"
                    )
                cls = self._class_def_stack[-1]
                params = []
                for p in node.args:
                    if isinstance(p, Token) and p.t == "ID":
                        params.append(p)
                    else:
                        raise Exception(
                            f"[Line {node.line}] methodDefine parameters must be identifiers"
                        )
                cls.methods[node.method] = (params, node.body)
                return None
            if node.obj == "constructorDefine":
                if not self._class_def_stack:
                    raise Exception(
                        f"[Line {node.line}] constructorDefine only allowed inside classDefine"
                    )
                self._class_def_stack[-1].constructor_body = node.body
                return None
            if node.obj == "keymapDefine" and node.method == "keymap":
                if not self._class_def_stack:
                    raise Exception(
                        f"[Line {node.line}] keymapDefine.keymap only allowed inside classDefine"
                    )
                if len(node.body) != 1:
                    raise Exception(
                        f"[Line {node.line}] keymapDefine.keymap expects a single {{ ... }} statement"
                    )
                stmt = node.body[0]
                if not isinstance(stmt, ExprStmtNode):
                    raise Exception(
                        f"[Line {node.line}] keymapDefine.keymap body must be a hash literal {{ ... }}"
                    )
                expr = stmt.expr
                if not isinstance(expr, HashLiteralNode):
                    raise Exception(
                        f"[Line {node.line}] keymapDefine.keymap body must be a hash literal {{ ... }}"
                    )
                pairs = []
                for k_expr, v_expr in expr.pairs:
                    k = self.evaluate(k_expr)
                    if not isinstance(k, str) or len(k) != 1:
                        raise Exception(
                            f"[Line {expr.line}] keymap key must be a single-character string, got {k!r}"
                        )
                    pairs.append((k, v_expr))
                self._class_def_stack[-1].keymap_entries = pairs
                return None
            if node.obj=="functionDefine":
                self.funcs[node.method]=(node.args,node.body)
                return None
            if node.obj=="test":
                m=_TEST_BRANCH_ALIASES.get(node.method,node.method)
                if m=="forLoop":
                    if len(node.args)<3:
                        raise Exception(f"[Line {node.line}] test.forLoop requires (start, end, varName)")
                    start=self.evaluate(node.args[0])
                    end=self.evaluate(node.args[1])
                    vt=node.args[2]
                    if not isinstance(vt,Token) or vt.t!="ID":
                        raise Exception(f"[Line {node.line}] test.forLoop third argument must be a variable name")
                    name=vt.v
                    cur=float(start)
                    endv=float(end)
                    iter_guard=0
                    self._scope_push_empty()
                    try:
                        while cur<=endv+1e-12:
                            if iter_guard>=_MAX_LOOP_ITERATIONS:
                                raise Exception(f"[Line {node.line}] test.forLoop exceeded maximum iterations ({_MAX_LOOP_ITERATIONS})")
                            iter_guard+=1
                            self._scope_assign(name, cur)
                            for sub in node.body:
                                try:
                                    self.run(sub, as_statement)
                                except ContinueSignal:
                                    break
                                except BreakSignal:
                                    return None
                            cur+=1.0
                        return None
                    finally:
                        self._scope_pop()
                if m=="while":
                    if not node.args:
                        raise Exception(f"[Line {node.line}] test.while requires a condition")
                    iter_guard=0
                    self._scope_push_empty()
                    try:
                        while True:
                            cond=self.evaluate(node.args[0])
                            if cond!=1:
                                break
                            if iter_guard>=_MAX_LOOP_ITERATIONS:
                                raise Exception(f"[Line {node.line}] test.while exceeded maximum iterations ({_MAX_LOOP_ITERATIONS})")
                            iter_guard+=1
                            for sub in node.body:
                                try:
                                    self.run(sub, as_statement)
                                except ContinueSignal:
                                    break
                                except BreakSignal:
                                    return None
                        return None
                    finally:
                        self._scope_pop()
                if m=="ifTrue":
                    cond=self.evaluate(node.args[0]) if node.args else 0
                    executed=False
                    if cond==1:
                        executed=True
                        self._scope_push_empty()
                        try:
                            for sub in node.body:
                                self.run(sub, as_statement)
                        finally:
                            self._scope_pop()
                    self.if_stack.append(executed)
                    return cond
                if m=="ifFalse":
                    cond=self.evaluate(node.args[0]) if node.args else 0
                    executed=False
                    if cond==0:
                        executed=True
                        self._scope_push_empty()
                        try:
                            for sub in node.body:
                                self.run(sub, as_statement)
                        finally:
                            self._scope_pop()
                    self.if_stack.append(executed)
                    return cond
                if m in ["elseIfTrue","elseIfFalse"]:
                    if not self.if_stack: return 0
                    if self.if_stack[-1]: return 0
                    cond=self.evaluate(node.args[0]) if node.args else 0
                    should_execute=(m=="elseIfTrue" and cond==1) or (m=="elseIfFalse" and cond==0)
                    if should_execute:
                        self.if_stack[-1]=True
                        self._scope_push_empty()
                        try:
                            for sub in node.body:
                                self.run(sub, as_statement)
                        finally:
                            self._scope_pop()
                    return cond if should_execute else 0
                if m=="else":
                    if not self.if_stack: return 0
                    if not self.if_stack[-1]:
                        self._scope_push_empty()
                        try:
                            for sub in node.body:
                                self.run(sub, as_statement)
                        finally:
                            self._scope_pop()
                    self.if_stack.pop()
                    return 1
            if node.obj=="random":
                if node.method=="run":
                    if not node.args:
                        raise Exception(f"[Line {node.line}] random.run requires a probability in [0,1]")
                    p = float(self.evaluate(node.args[0]))
                    if p < 0 or p > 1:
                        raise Exception(f"[Line {node.line}] random.run probability must be between 0 and 1, got {p!r}")
                    if random.random() < p:
                        self._scope_push_empty()
                        try:
                            for sub in node.body:
                                self.run(sub, as_statement)
                        finally:
                            self._scope_pop()
                    return None
            if node.obj == "error":
                raise Exception(
                    f"[Line {node.line}] error.try(): ... end; must be paired with error.except(error.ErrorType): ... end; (adjacent statements)."
                )

        if isinstance(node,MethodCallNode):
            if node.obj=="test" and node.method in ("break","Break"):
                raise BreakSignal()
            if node.obj=="test" and node.method in ("continue","Continue"):
                raise ContinueSignal()
            if node.obj == "test" and node.method == "pass":
                return None
            if node.obj == "keymap" and node.method == "createKeyMap":
                return self._keymap_create_keymap(node, node.line)
            if node.obj == "string" and node.method == "sorted":
                return self._string_sorted(node, node.line)
            try:
                km_obj = self._scope_get(node.obj, node.line)
            except SPLException:
                km_obj = None
            else:
                if isinstance(km_obj, SPLKeyMap):
                    if node.method == "curr":
                        if node.arg:
                            raise Exception(
                                f"[Line {node.line}] keymap.curr takes no arguments (use hash.getValue(k, keymap.curr))"
                            )
                        return km_obj.curr
                    raise Exception(
                        f"[Line {node.line}] SPLKeyMap only exposes .curr for hash.getValue (no .{node.method})"
                    )
            if node.obj=="list" and node.method=="convert":
                if not node.arg or len(node.arg)!=3:
                    raise Exception(f"[Line {node.line}] list.convert requires (var.setVar(list.iterable), function, list_var)")
                var_name=self._extract_list_binding(node.arg[0],"iterable")
                fn_expr=node.arg[1]
                target_list=self.evaluate(node.arg[2])
                return self._list_convert(var_name,fn_expr,target_list)
            if node.obj=="list" and node.method=="convertIfTrue":
                if not node.arg or len(node.arg)!=4:
                    raise Exception(f"[Line {node.line}] list.convertIfTrue requires (var.setVar(list.iterable), function, condition, list_var)")
                var_name=self._extract_list_binding(node.arg[0],"iterable")
                fn_expr=node.arg[1]
                cond_expr=node.arg[2]
                target_list=self.evaluate(node.arg[3])
                return self._list_convert_if(var_name,fn_expr,cond_expr,target_list,True,use_index=False)
            if node.obj=="list" and node.method=="convertIfFalse":
                if not node.arg or len(node.arg)!=4:
                    raise Exception(f"[Line {node.line}] list.convertIfFalse requires (var.setVar(list.iterable), function, condition, list_var)")
                var_name=self._extract_list_binding(node.arg[0],"iterable")
                fn_expr=node.arg[1]
                cond_expr=node.arg[2]
                target_list=self.evaluate(node.arg[3])
                return self._list_convert_if(var_name,fn_expr,cond_expr,target_list,False,use_index=False)
            if node.obj=="list" and node.method=="convertIfTrueIndex":
                if not node.arg or len(node.arg)!=4:
                    raise Exception(f"[Line {node.line}] list.convertIfTrueIndex requires (var.setVar(list.iterate), function, condition, list_var)")
                var_name=self._extract_list_binding(node.arg[0],"iterate")
                fn_expr=node.arg[1]
                cond_expr=node.arg[2]
                target_list=self.evaluate(node.arg[3])
                return self._list_convert_if(var_name,fn_expr,cond_expr,target_list,True,use_index=True)
            if node.obj=="list" and node.method=="convertIfFalseIndex":
                if not node.arg or len(node.arg)!=4:
                    raise Exception(f"[Line {node.line}] list.convertIfFalseIndex requires (var.setVar(list.iterate), function, condition, list_var)")
                var_name=self._extract_list_binding(node.arg[0],"iterate")
                fn_expr=node.arg[1]
                cond_expr=node.arg[2]
                target_list=self.evaluate(node.arg[3])
                return self._list_convert_if(var_name,fn_expr,cond_expr,target_list,False,use_index=True)
            if node.obj=="hash" and node.method=="createHashTable":
                if not node.arg or len(node.arg)!=2:
                    raise Exception(f"[Line {node.line}] hash.createHashTable requires ({{key:value pairs}}, name)")
                hash_val=self.evaluate(node.arg[0])
                if not isinstance(hash_val,dict):
                    raise Exception(f"[Line {node.line}] First argument to hash.createHashTable must be a hash literal")
                name_arg=node.arg[1]
                if isinstance(name_arg,Token) and name_arg.t=="ID":
                    name=name_arg.v
                else:
                    name=self.evaluate(name_arg)
                if not isinstance(name,str):
                    raise Exception(f"[Line {node.line}] hash.createHashTable name must be a variable identifier or string")
                self._scope_assign(name, hash_val)
                return hash_val
            if node.obj == "tuple" and node.method == "createTuple":
                if not node.arg or len(node.arg) != 2:
                    raise Exception(
                        f"[Line {node.line}] tuple.createTuple requires ((tuple literal), variableName)"
                    )
                tup = self.evaluate(node.arg[0])
                name_arg = node.arg[1]
                if isinstance(name_arg, Token) and name_arg.t == "ID":
                    return self.lib_tuple_create(tup, name_arg)
                return self.lib_tuple_create(tup, self.evaluate(name_arg))
            if node.obj == "set" and node.method == "createSet":
                if not node.arg or len(node.arg) != 2:
                    raise Exception(
                        f"[Line {node.line}] set.createSet requires ({{set literal}} or list, variableName)"
                    )
                raw = self.evaluate(node.arg[0])
                name_arg = node.arg[1]
                if isinstance(name_arg, Token) and name_arg.t == "ID":
                    return self.lib_set_create(raw, name_arg)
                return self.lib_set_create(raw, self.evaluate(name_arg))
            if node.obj == "list" and node.method == "createList":
                if not node.arg or len(node.arg) != 2:
                    raise Exception(
                        f"[Line {node.line}] list.createList requires ([items], variableName)"
                    )
                items_val = self.evaluate(node.arg[0])
                if not isinstance(items_val, list):
                    raise Exception(
                        f"[Line {node.line}] list.createList first argument must be a list literal"
                    )
                name_arg = node.arg[1]
                if isinstance(name_arg, Token) and name_arg.t == "ID":
                    name = name_arg.v
                else:
                    name = self.evaluate(name_arg)
                    if not isinstance(name, str):
                        raise Exception(
                            f"[Line {node.line}] list.createList name must be an identifier or string"
                        )
                self._scope_assign(name, list(items_val))
                return self._scope_get(name, node.line)
            if node.obj == "function" and node.method == "ref":
                if not node.arg or len(node.arg) != 1:
                    raise Exception(f"[Line {node.line}] function.ref expects one argument")
                return self._function_ref(node.arg[0], node.line)
            if node.obj == "function" and node.method == "call":
                if not node.arg or len(node.arg) < 2:
                    raise Exception(
                        f"[Line {node.line}] function.call expects (ref, arg1, ...)"
                    )
                ref_val = self.evaluate(node.arg[0])
                if not isinstance(ref_val, SPLFunctionRef):
                    raise Exception(
                        f"[Line {node.line}] function.call first argument must be function.ref(...)"
                    )
                call_args = [self.evaluate(a) for a in node.arg[1:]]
                return self._invoke_user_function(ref_val.name, call_args, node.line)
            if node.obj == "class" and node.method == "createObj":
                if not node.arg or len(node.arg) != 2:
                    raise Exception(
                        f"[Line {node.line}] class.createObj requires (variableName, className)"
                    )
                vn = self._coerce_name_literal(node.arg[0], node.line)
                cn = self._coerce_name_literal(node.arg[1], node.line)
                return self._instantiate_class(vn, cn, node.line)
            if node.obj == "method":
                if not self._instance_this_stack:
                    raise Exception(
                        f"[Line {node.line}] method.{node.method} outside of instance method"
                    )
                inst = self._instance_this_stack[-1]
                arg_vals_m = [self.evaluate(a) for a in (node.arg or [])]
                return self._invoke_instance_method(
                    inst, node.method, arg_vals_m, node.line, as_statement
                )
            if node.method == "setVar" and self._class_def_stack:
                if not node.arg:
                    raise Exception(f"[Line {node.line}] {node.obj}.setVar requires a value")
                val = self.evaluate(node.arg[0])
                c = self._class_def_stack[-1]
                c.field_defaults[node.obj] = copy.deepcopy(val)
                c.field_visibility.setdefault(node.obj, "private")
                return val
            if node.method == "public" and self._class_def_stack:
                self._class_def_stack[-1].field_visibility[node.obj] = "public"
                return None
            if node.method == "private" and self._class_def_stack:
                self._class_def_stack[-1].field_visibility[node.obj] = "private"
                return None
            dispatched = self._dispatch_instance_member(node, as_statement)
            if dispatched is not _DISPATCH_SKIP:
                return dispatched
            arg_vals=[self.evaluate(a) for a in (node.arg or [])]
            if node.obj == "error" and node.method == "raise":
                if len(arg_vals) != 2:
                    raise Exception(
                        f"[Line {node.line}] error.raise requires (errorType, message)"
                    )
                k, msg = arg_vals[0], arg_vals[1]
                if isinstance(k, SPLErrorType):
                    kind_str = k.name
                elif isinstance(k, str):
                    kind_str = k
                else:
                    raise Exception(
                        f"[Line {node.line}] error.raise first argument must be SPLErrorType or string, got {type(k).__name__}"
                    )
                raise SPLException(kind_str, str(msg), node.line)
            if node.obj=="return":
                m=node.method
                val=arg_vals[0] if arg_vals else None
                if m=="string":
                    if not isinstance(val,str):
                        raise Exception(f"[Line {node.line}] return.string expected str, got {type(val).__name__}: {val!r}")
                    raise ReturnSignal(val)
                if m=="number":
                    if not isinstance(val,(int,float)) or isinstance(val,bool):
                        raise Exception(f"[Line {node.line}] return.number expected int or float, got {type(val).__name__}: {val!r}")
                    raise ReturnSignal(val)
                if m=="boolean":
                    if val is None:
                        raise ReturnSignal(None)
                    if val not in (0,1):
                        raise Exception(f"[Line {node.line}] return.boolean expected 0 or 1, got {val!r}")
                    raise ReturnSignal(1 if val else 0)
                if m=="list":
                    if not isinstance(val, list):
                        raise Exception(f"[Line {node.line}] return.list expected list, got {type(val).__name__}: {val!r}")
                    raise ReturnSignal(val)
                if m=="hash":
                    if not isinstance(val, dict):
                        raise Exception(f"[Line {node.line}] return.hash expected dict, got {type(val).__name__}: {val!r}")
                    raise ReturnSignal(val)
                if m=="tuple":
                    if not isinstance(val, tuple):
                        raise Exception(f"[Line {node.line}] return.tuple expected tuple, got {type(val).__name__}: {val!r}")
                    raise ReturnSignal(val)
                if m=="set":
                    if not isinstance(val, SPLSet):
                        raise Exception(f"[Line {node.line}] return.set expected set, got {type(val).__name__}: {val!r}")
                    raise ReturnSignal(val)
                if m=="functionRef":
                    if not isinstance(val, SPLFunctionRef):
                        raise Exception(f"[Line {node.line}] return.functionRef expected function ref, got {type(val).__name__}: {val!r}")
                    raise ReturnSignal(val)
                if m=="instance":
                    if not isinstance(val, SPLInstance):
                        raise Exception(f"[Line {node.line}] return.instance expected instance, got {type(val).__name__}: {val!r}")
                    raise ReturnSignal(val)
                if m=="class":
                    if not isinstance(val, SPLClass):
                        raise Exception(f"[Line {node.line}] return.class expected class, got {type(val).__name__}: {val!r}")
                    raise ReturnSignal(val)
                raise Exception(f"[Line {node.line}] unknown return.{m}")
            if node.method=="setVar":
                self._scope_assign(node.obj, arg_vals[0])
                return arg_vals[0]
            if node.obj=="print" and node.method in (
                "string",
                "number",
                "boolean",
                "list",
                "hash",
                "tuple",
                "set",
                "functionRef",
                "instance",
                "class",
            ):
                return self._typed_print(node.method,arg_vals,node.line)
            if node.obj=="function":
                if node.method not in self.funcs:
                    raise Exception(f"[Line {node.line}] Error: Undefined Function: {node.method}")
                return self._invoke_user_function(node.method, arg_vals, node.line)
            if node.obj in self.library and node.method in self.library[node.obj]:
                return self.library[node.obj][node.method](*arg_vals)

        return None

    def evaluate(self,arg):
        if isinstance(arg,LogicNode):
            if arg.operator=="not":
                r=self.evaluate(arg.right)
                return 0 if r!=0 else 1
            l=self.evaluate(arg.left) if arg.left is not None else 0
            r=self.evaluate(arg.right)
            lb=1 if l!=0 else 0
            rb=1 if r!=0 else 0
            if arg.operator=="and":
                return 1 if (lb==1 and rb==1) else 0
            if arg.operator=="or":
                return 1 if (lb==1 or rb==1) else 0
            if arg.operator=="xor":
                return 1 if (lb!=rb) else 0
            if arg.operator=="xnor":
                return 1 if (lb==rb) else 0
            if arg.operator=="nand":
                return 0 if (lb==1 and rb==1) else 1
            if arg.operator=="nor":
                return 1 if (lb==0 and rb==0) else 0
            raise Exception(f"[Line {arg.line}] Unknown logical operator: {arg.operator}")
        if isinstance(arg,(MethodCallNode,BlockNode)):
            return self.run(arg, as_statement=False)
        if isinstance(arg,list):
            return [self.evaluate(i) for i in arg]
        if isinstance(arg,HashLiteralNode):
            out={}
            for k_expr,v_expr in arg.pairs:
                key=self.evaluate(k_expr)
                val=self.evaluate(v_expr)
                try:
                    out[key]=val
                except TypeError as e:
                    raise Exception(f"[Line {arg.line}] Hash key must be immutable/hashable: {key!r}") from e
            return out
        if isinstance(arg, SetLiteralNode):
            return SPLSet(self.evaluate(e) for e in arg.elements)
        if isinstance(arg, TupleLiteralNode):
            return tuple(self.evaluate(e) for e in arg.elements)
        if isinstance(arg,Token):
            if arg.t=="ID":
                return self._scope_get(arg.v, arg.line)
            return arg.v
        return arg

def _print_spl_error(message: str) -> None:
    """Print error lines in red on TTY stderr; plain text when not a terminal."""
    if sys.stderr.isatty():
        sys.stderr.write(f"\033[91m{message}\033[0m\n")
    else:
        sys.stderr.write(message + "\n")


# Main loop
def main():
    interpreter=Interpreter()
    print(f"---SPL OS v{version('someProgrammingLanguage')}---")
    if len(sys.argv)>1:
        try:
            entry_path = os.path.realpath(os.path.abspath(sys.argv[1]))
            interpreter._spl_file_stack.append(entry_path)
            try:
                with open(entry_path, encoding="utf-8") as f:
                    for node in Parser(tokenize(f.read())).parse():
                        try:
                            interpreter.run(node)
                        except BreakSignal:
                            _print_spl_error("Error: test.break used outside of a loop"); return 1
                        except ContinueSignal:
                            _print_spl_error("Error: test.continue used outside of a loop"); return 1
                return 0
            finally:
                interpreter._spl_file_stack.pop()
        except SPLException as e:
            _print_spl_error(f"Error: {e}")
            return 1
        except Exception as e:
            _print_spl_error(f"Error: {e}"); return 1
    else:
        while True:
            try:
                line=input(">>> ")
                for node in Parser(tokenize(line)).parse():
                    try:
                        interpreter.run(node)
                    except BreakSignal:
                        _print_spl_error("Error: test.break used outside of a loop"); return 1
                    except ContinueSignal:
                        _print_spl_error("Error: test.continue used outside of a loop"); return 1
            except (EOFError,KeyboardInterrupt):
                return 0
            except SPLException as e:
                _print_spl_error(f"Error: {e}")
            except Exception as e:
                _print_spl_error(f"Error: {e}"); return 1

if __name__=="__main__":
    sys.exit(main())
