(function () {
  var PYODIDE_BASE = "https://cdn.jsdelivr.net/pyodide/v0.26.4/full/";

  function uniqueUrls(urls) {
    var seen = {};
    var out = [];
    urls.forEach(function (u) {
      if (!u || seen[u]) return;
      seen[u] = true;
      out.push(u);
    });
    return out;
  }

  function defaultPort() {
    if (typeof window.SPL_RUN_PORT === "number") {
      return String(window.SPL_RUN_PORT);
    }
    return String(window.SPL_RUN_PORT || 8765);
  }

  /** @param {string} pathSuffix e.g. "/api/run" or "/api/practice-check" */
  function defaultApiUrls(pathSuffix) {
    var port = defaultPort();
    var loopback = "http://127.0.0.1:" + port + pathSuffix;
    var localName = "http://localhost:" + port + pathSuffix;

    if (typeof window.SPL_RUN_API_BASE === "string" && window.SPL_RUN_API_BASE) {
      return uniqueUrls([
        window.SPL_RUN_API_BASE.replace(/\/$/, "") + pathSuffix,
      ]);
    }

    if (location.protocol === "file:") {
      return uniqueUrls([loopback, localName]);
    }

    return uniqueUrls([
      location.origin + pathSuffix,
      loopback,
      localName,
    ]);
  }

  function explainFetchFailure(err) {
    var msg = (err && err.message) || String(err);
    if (/failed to fetch/i.test(msg)) {
      return (
        msg +
        ". If the server is running, you may be on HTTPS (use http://) or file:// (use the " +
        "server URL), or a firewall may be blocking localhost."
      );
    }
    return msg;
  }

  function reportPyodideStatus(msg) {
    if (typeof window.splPyodideStatus === "function") {
      try {
        window.splPyodideStatus(msg);
      } catch (e) {}
    }
  }

  function loadScript(src) {
    return new Promise(function (resolve, reject) {
      var s = document.createElement("script");
      s.src = src;
      s.async = true;
      s.onload = function () {
        resolve();
      };
      s.onerror = function () {
        reject(new Error("Failed to load " + src));
      };
      document.head.appendChild(s);
    });
  }

  var _splPyodidePromise = null;

  /**
   * Load Pyodide + micropip + someProgrammingLanguage from PyPI (large; cached by browser).
   * Exposed for debugging.
   */
  window.splEnsurePyodide = async function splEnsurePyodide() {
    if (window._splPyodideInstance) {
      return window._splPyodideInstance;
    }
    if (_splPyodidePromise) {
      return _splPyodidePromise;
    }
    _splPyodidePromise = (async function () {
      reportPyodideStatus(
        "Loading Python in the browser (Pyodide; first visit may take a minute)…",
      );
      if (typeof globalThis.loadPyodide !== "function") {
        await loadScript(PYODIDE_BASE + "pyodide.js");
      }
      var loadPyodide = globalThis.loadPyodide;
      if (typeof loadPyodide !== "function") {
        throw new Error("loadPyodide not available after loading pyodide.js");
      }
      var py = await loadPyodide({ indexURL: PYODIDE_BASE });
      await py.loadPackage("micropip");
      reportPyodideStatus("Installing SPL from PyPI (micropip)…");
      /* Pyodide only installs py3-none-any wheels. If only sdist is on PyPI, fall back to 0.6.x. */
      await py.runPythonAsync(
        "import micropip\n" +
          "try:\n" +
          "    await micropip.install('someProgrammingLanguage>=0.7.0')\n" +
          "except ValueError as e:\n" +
          "    err = str(e)\n" +
          "    if 'pure Python' in err or 'find wheel' in err.lower():\n" +
          "        await micropip.install('someProgrammingLanguage>=0.6.2')\n" +
          "    else:\n" +
          "        raise\n",
      );
      window._splPyodideInstance = py;
      reportPyodideStatus("");
      return py;
    })().catch(function (e) {
      _splPyodidePromise = null;
      throw e;
    });
    return _splPyodidePromise;
  };

  function runHintFetchFailure(lastErr, lastBadStatus) {
    var hint =
      "Could not reach SPL run API. Use the same URL as spl-web (local or deployed), or run spl-web " +
      "after pip install. HTTPS previews that only serve static files cannot reach localhost.";
    if (lastBadStatus != null) {
      hint =
        "This page is not served by spl-web (got HTTP " +
        lastBadStatus +
        " on /api/run). " +
        hint;
    }
    return (
      explainFetchFailure(lastErr) +
      "\n\n" +
      hint
    );
  }

  function practiceHintFetchFailure(lastErr, lastBadStatus) {
    var hint =
      "Could not reach practice API. Open the site from your spl-web or deployed server URL.";
    if (lastBadStatus != null) {
      hint =
        "Got HTTP " + lastBadStatus + " on /api/practice-check. " + hint;
    }
    return explainFetchFailure(lastErr) + "\n\n" + hint;
  }

  /**
   * Run SPL source via POST /api/run (spl-web), or Pyodide fallback when SPL_PYODIDE is not false.
   * @param {string} code
   * @returns {Promise<{ ok: boolean, stdout: string, stderr: string, exitCode: number, error?: string }>}
   */
  window.splRunCode = async function splRunCode(code) {
    var opts = {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code: code }),
    };
    var urls = defaultApiUrls("/api/run");
    var lastErr = null;
    var lastBadStatus = null;

    for (var i = 0; i < urls.length; i++) {
      var url = urls[i];
      try {
        var res = await fetch(url, opts);
        if (res.status === 404 || res.status === 405 || res.status === 501) {
          lastBadStatus = res.status;
          continue;
        }
        var data = await res.json().catch(function () {
          return { ok: false, error: "Invalid JSON from server" };
        });
        if (!res.ok) {
          return {
            ok: false,
            stdout: "",
            stderr: data.error || res.statusText,
            exitCode: -1,
          };
        }
        return {
          ok: !!data.ok,
          stdout: typeof data.stdout === "string" ? data.stdout : "",
          stderr: typeof data.stderr === "string" ? data.stderr : "",
          exitCode:
            typeof data.exitCode === "number" ? data.exitCode : -1,
        };
      } catch (e) {
        lastErr = e;
      }
    }

    if (window.SPL_PYODIDE === false) {
      return {
        ok: false,
        stdout: "",
        stderr: runHintFetchFailure(lastErr, lastBadStatus),
        exitCode: -1,
      };
    }

    try {
      reportPyodideStatus("Starting in-browser SPL…");
      var py = await window.splEnsurePyodide();
      py.globals.set("_spl_code", code);
      var jsonStr = String(
        await py.runPythonAsync(
          "import json\n" +
            "from someProgrammingLanguage.spl_exec import run_spl_source\n" +
            "ok, out, err, ec = run_spl_source(_spl_code)\n" +
            "json.dumps({'ok': ok, 'stdout': out, 'stderr': err, 'exitCode': ec})",
        ),
      );
      var data = JSON.parse(jsonStr);
      reportPyodideStatus("");
      return {
        ok: !!data.ok,
        stdout: typeof data.stdout === "string" ? data.stdout : "",
        stderr: typeof data.stderr === "string" ? data.stderr : "",
        exitCode: typeof data.exitCode === "number" ? data.exitCode : -1,
      };
    } catch (e) {
      reportPyodideStatus("");
      return {
        ok: false,
        stdout: "",
        stderr:
          explainFetchFailure(e) +
          "\n\n" +
          "In-browser run (Pyodide) failed. Needs network for the Pyodide CDN and PyPI on first use.",
        exitCode: -1,
      };
    }
  };

  /**
   * Practice: POST /api/practice-check, or Pyodide fallback.
   * @param {string} problemId
   * @param {string} code
   * @returns {Promise<object>}
   */
  window.splPracticeCheck = async function splPracticeCheck(problemId, code) {
    var opts = {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ problemId: problemId, code: code }),
    };
    var urls = defaultApiUrls("/api/practice-check");
    var lastErr = null;
    var lastBadStatus = null;

    for (var i = 0; i < urls.length; i++) {
      var url = urls[i];
      try {
        var res = await fetch(url, opts);
        if (res.status === 404 || res.status === 405 || res.status === 501) {
          lastBadStatus = res.status;
          continue;
        }
        var data = await res.json().catch(function () {
          return { ok: false, error: "Invalid JSON from server" };
        });
        if (!res.ok) {
          return {
            ok: false,
            passed: false,
            error: data.error || res.statusText,
          };
        }
        return data;
      } catch (e) {
        lastErr = e;
      }
    }

    if (window.SPL_PYODIDE === false) {
      return {
        ok: false,
        passed: false,
        error: practiceHintFetchFailure(lastErr, lastBadStatus),
      };
    }

    try {
      reportPyodideStatus("Running practice checks in-browser…");
      var py = await window.splEnsurePyodide();
      py.globals.set("_spl_pid", problemId);
      py.globals.set("_spl_pcode", code);
      var jsonStr = String(
        await py.runPythonAsync(
          "import json\n" +
            "from someProgrammingLanguage.practice_judge import judge_practice\n" +
            "json.dumps(judge_practice(_spl_pid, _spl_pcode))",
        ),
      );
      var data = JSON.parse(jsonStr);
      reportPyodideStatus("");
      return data;
    } catch (e) {
      reportPyodideStatus("");
      return {
        ok: false,
        passed: false,
        error:
          explainFetchFailure(e) +
          "\n\n" +
          "In-browser practice (Pyodide) failed. Needs network for the Pyodide CDN and PyPI on first use.",
      };
    }
  };

  window.splNormalizeOutput = function splNormalizeOutput(s) {
    if (s == null) return "";
    return String(s).replace(/\r\n/g, "\n").replace(/\s*$/, "");
  };
})();
