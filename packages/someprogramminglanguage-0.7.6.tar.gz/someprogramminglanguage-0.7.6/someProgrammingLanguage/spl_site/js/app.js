(function () {
  const PAGE_SIZE = 20;

  const tbody = document.getElementById("ref-tbody");
  const searchInput = document.getElementById("search-text");
  const classFilter = document.getElementById("search-class");
  const countEl = document.getElementById("result-count");
  const paginationSummary = document.getElementById("pagination-summary");
  const paginationPage = document.getElementById("pagination-page");
  const pagePrev = document.getElementById("page-prev");
  const pageNext = document.getElementById("page-next");

  if (!window.SPL_REFERENCE || !tbody) return;

  let currentPage = 1;

  const catLabels = {};
  SPL_REFERENCE.forEach((r) => {
    catLabels[r.category] = r.categoryLabel;
  });
  const categories = Object.keys(catLabels).sort((a, b) =>
    catLabels[a].localeCompare(catLabels[b])
  );

  categories.forEach((cat) => {
    const label = SPL_REFERENCE.find((r) => r.category === cat).categoryLabel;
    const opt = document.createElement("option");
    opt.value = cat;
    opt.textContent = label + " (" + cat + ")";
    classFilter.appendChild(opt);
  });

  function rowMatches(row, textQ, classQ) {
    if (classQ && row.category !== classQ) return false;
    if (!textQ) return true;
    const hay = (
      row.name +
      " " +
      row.desc +
      " " +
      row.categoryLabel
    ).toLowerCase();
    return hay.includes(textQ);
  }

  function getFilteredRows() {
    const textQ = (searchInput.value || "").trim().toLowerCase();
    const classQ = classFilter.value || "";
    return SPL_REFERENCE.filter((r) => rowMatches(r, textQ, classQ));
  }

  function render() {
    const rows = getFilteredRows();
    const total = rows.length;
    const totalPages =
      total === 0 ? 0 : Math.ceil(total / PAGE_SIZE);

    if (totalPages === 0) {
      currentPage = 1;
    } else {
      if (currentPage > totalPages) currentPage = totalPages;
      if (currentPage < 1) currentPage = 1;
    }

    const startIdx = total === 0 ? 0 : (currentPage - 1) * PAGE_SIZE;
    const pageRows = rows.slice(startIdx, startIdx + PAGE_SIZE);

    tbody.innerHTML = "";
    pageRows.forEach((r) => {
      const tr = document.createElement("tr");
      tr.className =
        "border-b border-slate-700/80 hover:bg-slate-800/50 transition-colors";
      tr.innerHTML = `
        <td class="px-4 py-3 align-top">
          <span class="inline-flex items-center rounded-md bg-slate-700/80 px-2 py-0.5 text-xs font-medium text-sky-300 ring-1 ring-inset ring-slate-600">${escapeHtml(
            r.categoryLabel
          )}</span>
          <code class="mt-2 block font-mono text-sm text-emerald-300/95">${splHighlightSyntax(
            escapeHtml(r.name)
          )}</code>
        </td>
        <td class="px-4 py-3 text-slate-300 text-sm leading-relaxed">${splHighlightSyntax(
          escapeHtml(r.desc)
        )}</td>
      `;
      tbody.appendChild(tr);
    });

    countEl.textContent =
      total + " match" + (total === 1 ? "" : "es");

    if (total === 0) {
      paginationSummary.textContent = "No matching entries.";
      paginationPage.textContent = "";
    } else {
      const from = startIdx + 1;
      const to = startIdx + pageRows.length;
      paginationSummary.textContent =
        "Showing " + from + "–" + to + " of " + total;
      paginationPage.textContent =
        "Page " + currentPage + " / " + totalPages;
    }

    const canPrev = totalPages > 0 && currentPage > 1;
    const canNext = totalPages > 0 && currentPage < totalPages;
    pagePrev.disabled = !canPrev;
    pageNext.disabled = !canNext;
  }

  function escapeHtml(s) {
    const div = document.createElement("div");
    div.textContent = s;
    return div.innerHTML;
  }

  /** HTML-escaped string only: wraps SPL arrow, `code`, `run`, and `?` for display. */
  function splHighlightSyntax(escaped) {
    let out = escaped.replace(
      /&lt;-/g,
      '<span class="spl-arrow">&lt;-</span>'
    );
    out = out.replace(
      /(<span class="spl-arrow">&lt;-<\/span>)\s*(run)(?=\s*:)/g,
      "$1 <span class=\"spl-kw-run\">$2</span>"
    );
    out = out.replace(/\?/g, '<span class="spl-qmark">?</span>');
    out = out.replace(/\bcode\b/g, '<span class="spl-kw-code">code</span>');
    return out;
  }

  function resetToFirstPage() {
    currentPage = 1;
    render();
  }

  searchInput.addEventListener("input", resetToFirstPage);
  classFilter.addEventListener("change", resetToFirstPage);

  pagePrev.addEventListener("click", function () {
    if (currentPage > 1) {
      currentPage -= 1;
      render();
    }
  });

  pageNext.addEventListener("click", function () {
    const rows = getFilteredRows();
    const totalPages =
      rows.length === 0 ? 0 : Math.ceil(rows.length / PAGE_SIZE);
    if (currentPage < totalPages) {
      currentPage += 1;
      render();
    }
  });

  render();
})();
