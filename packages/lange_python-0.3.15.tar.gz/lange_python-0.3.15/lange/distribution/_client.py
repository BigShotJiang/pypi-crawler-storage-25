from __future__ import annotations

import hashlib
import os
import mimetypes
import shutil
from pathlib import Path
from typing import Any

import httpx

from ._update_macos import (
    extract_macos_app_from_zip,
    read_macos_bundle_identifier,
    spawn_macos_update_process,
)
from ._util import (
    _compare_versions,
    detect_distribution_os,
    parse_distribution_os,
    validate_installed_macos_app_path,
)
from .._util import BaseLangeLabsClient
from .._util._base_client import _UNSET_API_KEY


class DistributionClient(BaseLangeLabsClient):
    """
    Client for querying public distribution metadata and update availability.

    :param host: Base app-service URL, e.g. ``https://lange-labs.com``.
    :param api_key: Optional API key supplied directly or resolved from the environment.
    :param timeout: HTTP timeout in seconds for metadata requests.
    :raises ValueError: If ``api_key`` is provided but empty.
    """

    def __init__(self,
                 distribution_name: str,
                 host: str = "https://lange-labs.com",
                 api_key: str | None = None,
                 timeout: float = 10.0) -> None:
        """
        Initialize a distribution metadata client for the Lange app service.

        :param host: Base app-service URL, e.g. ``https://lange-labs.com``.
        :param api_key: Optional API key supplied directly or resolved from the environment.
        :param timeout: HTTP timeout in seconds for metadata requests.
        :param distribution_name: Distribution name as stored by the app service.
        :raises ValueError: If ``api_key`` is provided but empty.
        """
        super().__init__(api_key, host=host)
        self.timeout = timeout
        self._last_checked_version: str | None = None
        self._last_update_result: str | None = None
        self._last_downloaded_version: str | None = None
        self._last_downloaded_artifact_path: str | None = None
        self._last_error: str | None = None
        normalized_distribution_name = distribution_name.strip()

        if not normalized_distribution_name:
            raise ValueError("distribution_name is required.")

        if " " in normalized_distribution_name:
            raise ValueError("check your distribution name again. spaces are not allowed by design")

        self.distribution_name = normalized_distribution_name
        self._refresh_capabilities()

    @property
    def status(self) -> str:
        """
        Get the current distribution client status.

        :returns: Shared client status string.
        """
        return self._status

    @property
    def last_checked_version(self) -> str | None:
        """
        Get the version used for the most recent update check.

        :returns: Last checked version string or ``None``.
        """
        return self._last_checked_version

    @property
    def update_state(self) -> dict[str, Any]:
        can_check = self.api_key is not None
        can_download = self._last_update_result is not None and can_check
        return {
            "status": self._status,
            "last_checked_version": self._last_checked_version,
            "available_version": self._last_update_result,
            "downloaded_version": self._last_downloaded_version,
            "downloaded_artifact_path": self._last_downloaded_artifact_path,
            "can_check_for_update": can_check,
            "can_download": can_download,
            "can_update": can_download or self._last_downloaded_artifact_path is not None,
            "last_error": self._last_error,
        }

    def reload(self, api_key: str | None | object = _UNSET_API_KEY) -> None:
        """
        Reload authentication and repeat the last update check when available.

        :param api_key: Optional replacement API key. Pass ``None`` explicitly to clear authentication.
        :returns: ``None``.
        """
        super().reload(api_key=api_key)
        self._last_error = None

        if self.api_key is None:
            self._last_update_result = None
            self._refresh_capabilities()
            return

        if self._last_checked_version is None:
            self._set_status("off")
            self._refresh_capabilities()
            return

        self.check_for_update(self._last_checked_version)

    def search_for_update(self, current_version: str) -> str | None:
        return self.check_for_update(current_version)

    def check_for_update(self, current_version: str) -> str | None:
        """
        Resolve the newest available version for the current OS when it is newer.

        :param distribution_name: Distribution name as stored by the app service.
        :param current_version: Current installed version string.
        :returns: Newer version string when available, otherwise ``None``.
        :raises ValueError: If required inputs are missing.
        :raises httpx.HTTPError: If the metadata request fails.
        """
        normalized_current_version = current_version.strip()

        if not normalized_current_version:
            raise ValueError("current_version is required.")

        self._last_checked_version = normalized_current_version

        if self.api_key is None:
            self._set_status("unauthenticated")
            self._last_error = "API key is required for this operation."
            self._refresh_capabilities()
            raise ValueError("API key is required for this operation.")

        self._set_status("pending")

        try:
            current_os = detect_distribution_os()
            payload = self._get_distribution_payload()
            versions = payload.get("distribution", {}).get("versions", [])

            newest_version: str | None = None

            for version_entry in versions:
                if not isinstance(version_entry, dict):
                    continue

                version = str(version_entry.get("version", "")).strip()
                artifacts = version_entry.get("artifacts", {})
                artifact = artifacts.get(current_os) if isinstance(artifacts, dict) else None

                if not version or artifact is None:
                    continue

                if _compare_versions(version, normalized_current_version) <= 0:
                    continue

                if newest_version is None or _compare_versions(version, newest_version) > 0:
                    newest_version = version

            self._last_update_result = newest_version
            self._last_error = None
            self._set_status("connected")
            self._refresh_capabilities()
            return newest_version
        except Exception as error:
            if self.api_key is None:
                self._set_status("unauthenticated")
            else:
                self._set_status("failed")
            self._last_error = str(error)
            self._refresh_capabilities()
            raise

    def _build_distribution_url(self) -> str:
        """
        Build the public metadata endpoint URL for one distribution.

        :param distribution_name: Distribution name to request.
        :returns: Fully qualified public metadata URL.
        """
        return f"{self.host}/api/public/distributions/{self.distribution_name}"

    def _build_artifact_download_url(self, version: str, os_name: str) -> str:
        """
        Build the public artifact download endpoint URL for one version and OS.

        :param version: Distribution version to download.
        :param os_name: Operating-system label accepted by the app service.
        :returns: Fully qualified public artifact download URL.
        """
        return (
            f"{self.host}/api/public/distributions/{self.distribution_name}"
            f"/versions/{version}/artifacts/{os_name}/download"
        )

    def _build_versions_url(self) -> str:
        """
        Build the authenticated distribution versions endpoint URL.

        :returns: Fully qualified versions collection URL.
        """
        return f"{self.host}/api/distributions/{self.distribution_name}/versions"

    def _get_newest_version_artifact(self, os_name: str) -> tuple[str, dict[str, Any]] | None:
        """
        Resolve the newest downloadable artifact for one operating system.

        :param os_name: Operating-system label accepted by the app service.
        :returns: Tuple of version string and artifact payload, otherwise ``None``.
        :raises httpx.HTTPError: If the metadata request fails.
        """
        payload = self._get_distribution_payload()
        versions = payload.get("distribution", {}).get("versions", [])
        newest_match: tuple[str, dict[str, Any]] | None = None

        for version_entry in versions:
            if not isinstance(version_entry, dict):
                continue

            version = str(version_entry.get("version", "")).strip()
            artifacts = version_entry.get("artifacts", {})
            artifact = artifacts.get(os_name) if isinstance(artifacts, dict) else None

            if not version or not isinstance(artifact, dict):
                continue

            if newest_match is None or _compare_versions(version, newest_match[0]) > 0:
                newest_match = (version, artifact)

        return newest_match

    def download_to_temp(self) -> Path:
        version, artifact_path = self.download()
        _ = version
        return artifact_path

    def download(self, current_version: str | None = None, target_version: str | None = None) -> tuple[str, Path]:
        """
        Download one update artifact for the current OS into ``/tmp``.

        :param current_version: Optional current installed version used to discover newer versions.
        :param target_version: Optional explicit version to download.
        :returns: Tuple of resolved version and downloaded artifact path.
        :raises ValueError: If no downloadable artifact exists for the current OS.
        :raises httpx.HTTPError: If the metadata or artifact download fails.
        """
        current_os = detect_distribution_os()
        resolved_version: str | None = None

        if target_version is not None:
            resolved_version = target_version.strip()
        elif current_version is not None:
            resolved_version = self.check_for_update(current_version)
        else:
            newest_match = self._get_newest_version_artifact(current_os)
            if newest_match is not None:
                resolved_version = newest_match[0]

        if not resolved_version:
            raise ValueError(f"No downloadable versions available for operating system: {current_os}.")

        artifact_path = self._download_version_artifact_to_temp(version=resolved_version, os_name=current_os)
        self._last_downloaded_version = resolved_version
        self._last_downloaded_artifact_path = str(artifact_path)
        self._last_error = None
        self._refresh_capabilities()
        self._cleanup_old_temp_versions()
        return resolved_version, artifact_path

    def update(
        self,
        *,
        current_version: str,
        installed_app_path: str | Path,
        target_version: str | None = None,
        current_process_id: int | None = None,
        wait_for_exit_timeout: float = 30.0,
        relaunch: bool = True,
        strict_bundle_identifier: bool = True,
    ) -> dict[str, str]:
        """
        Download and stage a macOS update, then spawn a detached helper to apply it.

        :param current_version: Current installed version string.
        :param installed_app_path: Path to the installed macOS ``.app`` bundle to replace.
        :param target_version: Explicit target version to install. When omitted, the newest newer version is used.
        :param current_process_id: PID that must exit before replacement begins. Defaults to the current process.
        :param wait_for_exit_timeout: Maximum seconds the helper waits for the current process to exit.
        :returns: Metadata describing the staged update and spawned helper process.
        :raises ValueError: If the platform, app path, or artifact layout is invalid.
        :raises RuntimeError: If the detached helper process could not be launched.
        """
        current_os = detect_distribution_os()
        if current_os != "macos":
            raise ValueError(f"macOS updates are not implemented for operating system: {current_os}.")

        normalized_current_version = current_version.strip()
        if not normalized_current_version:
            raise ValueError("current_version is required.")

        normalized_installed_app_path = validate_installed_macos_app_path(installed_app_path)
        resolved_target_version = target_version.strip() if target_version is not None else self.check_for_update(
            normalized_current_version
        )

        if not resolved_target_version:
            raise ValueError("No newer update is available for the current macOS installation.")

        artifact = self._get_version_artifact(version=resolved_target_version, os_name="macos")
        if artifact is None:
            raise ValueError(f"No macos artifact is available for version {resolved_target_version}.")

        artifact_path = self._download_version_artifact_to_temp(
            version=resolved_target_version,
            os_name="macos",
            artifact=artifact,
        )
        extracted_app_path = extract_macos_app_from_zip(artifact_path)
        if strict_bundle_identifier:
            installed_bundle_identifier = read_macos_bundle_identifier(normalized_installed_app_path)
            extracted_bundle_identifier = read_macos_bundle_identifier(extracted_app_path)
            if (
                installed_bundle_identifier is not None
                and extracted_bundle_identifier is not None
                and installed_bundle_identifier != extracted_bundle_identifier
            ):
                raise ValueError(
                    "Downloaded app bundle identifier does not match installed application bundle identifier."
                )
        helper_process = spawn_macos_update_process(
            source_app_path=extracted_app_path,
            installed_app_path=normalized_installed_app_path,
            current_process_id=os.getpid() if current_process_id is None else current_process_id,
            workspace_path=artifact_path.parent,
            wait_for_exit_timeout=wait_for_exit_timeout,
            relaunch=relaunch,
        )
        process_id = helper_process.get("process_id", helper_process.get("pid", ""))
        self._last_downloaded_version = resolved_target_version
        self._last_downloaded_artifact_path = str(artifact_path)
        self._last_error = None
        self._refresh_capabilities()
        self._cleanup_old_temp_versions()

        return {
            "version": resolved_target_version,
            "artifact_path": str(artifact_path),
            "installed_app_path": str(normalized_installed_app_path),
            "extracted_app_path": str(extracted_app_path),
            "script_path": helper_process["script_path"],
            "log_path": helper_process["log_path"],
            "process_id": str(process_id),
        }

    def _download_version_artifact_to_temp(
        self,
        version: str,
        os_name: str,
        artifact: dict[str, Any] | None = None,
    ) -> Path:
        """
        Download one explicit version artifact for one operating system into ``/tmp``.

        :param version: Distribution version to download.
        :param os_name: Operating-system label accepted by the app service.
        :returns: Absolute path to the downloaded artifact.
        :raises ValueError: If the artifact metadata is incomplete or missing.
        :raises httpx.HTTPError: If the metadata or artifact download fails.
        """
        resolved_artifact = artifact if artifact is not None else self._get_version_artifact(version=version, os_name=os_name)

        if resolved_artifact is None:
            raise ValueError(f"No {os_name} artifact is available for version {version}.")

        filename = str(resolved_artifact.get("filename", "")).strip()

        if not filename:
            raise ValueError("Artifact filename is required.")

        destination_dir = Path("/tmp") / self.distribution_name / "versions" / version
        destination_dir.mkdir(parents=True, exist_ok=True)
        destination_path = destination_dir / filename

        client = httpx.Client(timeout=self.timeout)

        try:
            response = client.get(
                self._build_artifact_download_url(version, os_name),
                headers=self._build_connection_headers(),
            )
            response.raise_for_status()
            destination_path.write_bytes(response.content)
            self._verify_downloaded_artifact(destination_path, resolved_artifact)
        finally:
            client.close()

        return destination_path

    def _verify_downloaded_artifact(self, artifact_path: Path, artifact_payload: dict[str, Any]) -> None:
        checksum = str(
            artifact_payload.get("sha256")
            or artifact_payload.get("checksumSha256")
            or artifact_payload.get("checksum")
            or ""
        ).strip().lower()
        if not checksum:
            raise ValueError("Artifact checksum metadata is required for secure updates.")

        digest = hashlib.sha256(artifact_path.read_bytes()).hexdigest()
        if digest.lower() != checksum:
            raise ValueError("Downloaded artifact checksum validation failed.")

    def _cleanup_old_temp_versions(self, retain_count: int = 3) -> None:
        versions_root = Path("/tmp") / self.distribution_name / "versions"
        if not versions_root.is_dir():
            return

        version_dirs = [path for path in versions_root.iterdir() if path.is_dir()]
        version_dirs.sort(key=lambda directory: directory.stat().st_mtime, reverse=True)
        for stale_path in version_dirs[retain_count:]:
            shutil.rmtree(stale_path, ignore_errors=True)

    def _refresh_capabilities(self) -> None:
        # The update_state property is computed from current fields; this method keeps callers consistent.
        return None

    def _get_version_artifact(self, version: str, os_name: str) -> dict[str, Any] | None:
        """
        Resolve the downloadable artifact payload for one version and operating system.

        :param version: Distribution version to inspect.
        :param os_name: Operating-system label accepted by the app service.
        :returns: Artifact metadata for the version and OS, otherwise ``None``.
        :raises ValueError: If the version is missing.
        :raises httpx.HTTPError: If the metadata request fails.
        """
        normalized_version = version.strip()
        normalized_os_name = parse_distribution_os(os_name)

        if not normalized_version:
            raise ValueError("version is required.")

        payload = self._get_distribution_payload()
        versions = payload.get("distribution", {}).get("versions", [])

        for version_entry in versions:
            if not isinstance(version_entry, dict):
                continue

            if str(version_entry.get("version", "")).strip() != normalized_version:
                continue

            artifacts = version_entry.get("artifacts", {})
            artifact = artifacts.get(normalized_os_name) if isinstance(artifacts, dict) else None
            if isinstance(artifact, dict):
                return artifact
            return None

        return None

    def upload(self, path: str | Path, version_name: str, os_name: str) -> dict[str, Any]:
        """
        Upload one OS-specific distribution artifact for a version.

        :param path: Artifact file path to upload.
        :param version_name: Version string to associate with the artifact.
        :param os_name: Operating-system label for the artifact.
        :returns: Decoded JSON response payload.
        :raises ValueError: If any input is missing, invalid, or the file does not exist.
        :raises httpx.HTTPError: If the upload request fails.
        """
        artifact_path = Path(path)
        normalized_version_name = version_name.strip()
        normalized_os_name = parse_distribution_os(os_name)

        if not normalized_version_name:
            raise ValueError("version_name is required.")

        if not artifact_path.exists():
            raise ValueError("Artifact file does not exist.")

        if not artifact_path.is_file():
            raise ValueError("Artifact path must point to a file.")

        content_type = mimetypes.guess_type(artifact_path.name)[0] or "application/octet-stream"
        file_field_name = f"{normalized_os_name}File"

        client = httpx.Client(timeout=self.timeout)

        try:
            with artifact_path.open("rb") as artifact_file:
                response = client.post(
                    self._build_versions_url(),
                    headers=self._build_connection_headers(),
                    data={"version": normalized_version_name},
                    files={
                        file_field_name: (
                            artifact_path.name,
                            artifact_file,
                            content_type,
                        )
                    },
                )
            response.raise_for_status()
            return response.json()
        finally:
            client.close()

    def _get_distribution_payload(self) -> dict[str, Any]:
        """
        Fetch the public distribution metadata payload from the app service.

        :returns: Decoded JSON payload.
        :raises httpx.HTTPError: If the request fails or returns invalid JSON.
        """
        client = httpx.Client(timeout=self.timeout)

        try:
            response = client.get(
                self._build_distribution_url(),
                headers=self._build_connection_headers(),
            )
            response.raise_for_status()
            return response.json()
        finally:
            client.close()
