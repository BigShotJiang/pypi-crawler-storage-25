from __future__ import annotations

import os
import platform
import re
from pathlib import Path


def detect_distribution_os() -> str:
    """
    Detect the current operating system for distribution artifact selection.

    :returns: Normalized operating-system label accepted by the app service.
    :raises ValueError: If the current platform is unsupported.
    """
    system_name = platform.system().strip().lower()

    if system_name == "windows":
        return "windows"

    if system_name == "darwin":
        return "macos"

    if system_name == "linux":
        return "linux"

    raise ValueError(f"Unsupported operating system: {platform.system()}.")


def parse_distribution_os(os_name: str) -> str:
    """
    Validate and normalize a distribution artifact operating-system label.

    :param os_name: Untrusted operating-system label.
    :returns: Normalized operating-system label accepted by the app service.
    :raises ValueError: If the operating-system label is missing or unsupported.
    """
    normalized_os_name = os_name.strip().lower()

    if not normalized_os_name:
        raise ValueError("os_name is required.")

    if normalized_os_name not in {"windows", "macos", "linux"}:
        raise ValueError("os_name must be one of: windows, macos, linux.")

    return normalized_os_name


def _compare_versions(left: str, right: str) -> int:
    """
    Compare two dotted numeric version strings.

    :param left: Left-hand version string.
    :param right: Right-hand version string.
    :returns: Positive when ``left`` is newer, negative when older, otherwise ``0``.
    """
    left_core, left_pre = _normalize_version_parts(left)
    right_core, right_pre = _normalize_version_parts(right)
    max_length = max(len(left_core), len(right_core))

    padded_left = left_core + (0,) * (max_length - len(left_core))
    padded_right = right_core + (0,) * (max_length - len(right_core))

    if padded_left > padded_right:
        return 1

    if padded_left < padded_right:
        return -1

    if left_pre is None and right_pre is None:
        return 0
    if left_pre is None:
        return 1
    if right_pre is None:
        return -1

    max_pre_len = max(len(left_pre), len(right_pre))
    for index in range(max_pre_len):
        if index >= len(left_pre):
            return -1
        if index >= len(right_pre):
            return 1

        left_identifier = left_pre[index]
        right_identifier = right_pre[index]

        if left_identifier == right_identifier:
            continue

        left_is_number = left_identifier.isdigit()
        right_is_number = right_identifier.isdigit()

        if left_is_number and right_is_number:
            return 1 if int(left_identifier) > int(right_identifier) else -1
        if left_is_number and not right_is_number:
            return -1
        if not left_is_number and right_is_number:
            return 1
        return 1 if left_identifier > right_identifier else -1

    return 0


def _normalize_version_parts(version: str) -> tuple[tuple[int, ...], tuple[str, ...] | None]:
    """
    Convert a dotted numeric version string into comparable integer parts.

    :param version: Version string to normalize.
    :returns: Comparable integer tuple.
    :raises ValueError: If the version is empty or malformed.
    """
    normalized_version = version.strip()
    if not normalized_version:
        raise ValueError("Version is required.")

    version_without_build = normalized_version.split("+", 1)[0]
    core_part, separator, prerelease_part = version_without_build.partition("-")
    parts = core_part.split(".")
    normalized_parts: list[int] = []

    for part in parts:
        if not part.isdigit():
            raise ValueError(f"Unsupported version format: {version}.")

        normalized_parts.append(int(part))

    prerelease_identifiers: tuple[str, ...] | None = None
    if separator:
        if not prerelease_part:
            raise ValueError(f"Unsupported version format: {version}.")
        tokens = prerelease_part.split(".")
        if any(not token or not re.match(r"^[0-9A-Za-z-]+$", token) for token in tokens):
            raise ValueError(f"Unsupported version format: {version}.")
        prerelease_identifiers = tuple(tokens)

    return tuple(normalized_parts), prerelease_identifiers


def validate_installed_macos_app_path(installed_app_path: str | Path) -> Path:
    """
    Validate and normalize the macOS app bundle path that should be replaced.

    :param installed_app_path: Untrusted path to the installed ``.app`` bundle.
    :returns: Absolute path to the installed ``.app`` bundle.
    :raises ValueError: If the path is missing, does not exist, or is not a ``.app`` directory.
    """
    normalized_path = Path(installed_app_path).expanduser().resolve()

    if not normalized_path.exists():
        raise ValueError("installed_app_path must point to an existing .app bundle.")

    if not normalized_path.is_dir() or normalized_path.suffix != ".app":
        raise ValueError("installed_app_path must point to an existing .app bundle.")

    if not os.access(normalized_path, os.W_OK):
        raise ValueError("installed_app_path is not writable for replacement.")

    if not os.access(normalized_path.parent, os.W_OK):
        raise ValueError("installed_app_path parent directory is not writable for replacement.")

    return normalized_path
