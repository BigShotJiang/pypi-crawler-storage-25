import os


def _resolve_api_key(api_key: str | None) -> str | None:
    """
    Resolve API key from argument or environment.

    :param api_key: Optional direct API key value.
    :returns: Sanitized API key or ``None`` when no key is configured.
    :raises ValueError: If the provided API key is empty or whitespace-only.
    """
    if api_key is not None:
        normalized_api_key = api_key.strip()
        if not normalized_api_key:
            raise ValueError("api_key cannot be empty.")
        return normalized_api_key

    env_api_key = os.getenv("LANGE_LABS_API_KEY", "")
    if env_api_key.strip():
        return env_api_key.strip()

    return None
