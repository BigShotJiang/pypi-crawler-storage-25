from threading import Thread
from typing import Literal

from ._key_handling import _resolve_api_key

ClientStatus = Literal["unauthenticated", "off", "pending", "connected", "failed"]
_UNSET_API_KEY = object()


class BaseLangeLabsClient(Thread):
    """Shared thread-based Lange Labs client base class."""

    def __init__(self,
                 api_key: str | None = None,
                 daemon: bool = True,
                 host: str | None = None,
                 ) -> None:
        """
        Initialize a thread-based Lange Labs client with shared connection settings.

        :param api_key: Optional API key supplied directly or resolved from the environment.
        :param daemon: Whether the client thread should run as a daemon thread.
        :param host: Base service URL used for outbound requests.
        :raises ValueError: If ``api_key`` is provided but empty.
        """
        super().__init__(daemon=daemon)
        self.api_key = _resolve_api_key(api_key)
        self.host = host.rstrip("/") if host is not None else ""
        self._status: ClientStatus = self._status_for_auth()

    def reload(self, api_key: str | None | object = _UNSET_API_KEY) -> None:
        """
        Reload shared client configuration.

        :param api_key: Optional replacement API key. Pass ``None`` explicitly to clear authentication.
        :returns: ``None``.
        :raises ValueError: If ``api_key`` is provided but empty.
        """
        if api_key is _UNSET_API_KEY:
            pass
        elif api_key is None:
            self.api_key = None
        else:
            self.api_key = _resolve_api_key(api_key)

        self._status = self._status_for_auth()

    def _build_connection_headers(self) -> dict[str, str]:
        """
        Build outbound handshake headers.

        :returns: Header dictionary with bearer authorization.
        :raises ValueError: If the client is unauthenticated.
        """
        if self.api_key is None:
            raise ValueError("API key is required for this operation.")

        return {"Authorization": f"Bearer {self.api_key}"}

    def _set_status(self, status: ClientStatus) -> None:
        """
        Store the current client status.

        :param status: New shared client status value.
        :returns: ``None``.
        """
        self._status = status

    def _status_for_auth(self) -> ClientStatus:
        """
        Resolve the default status from the configured authentication state.

        :returns: ``\"unauthenticated\"`` when no key is set, otherwise ``\"off\"``.
        """
        if self.api_key is None:
            return "unauthenticated"

        return "off"
