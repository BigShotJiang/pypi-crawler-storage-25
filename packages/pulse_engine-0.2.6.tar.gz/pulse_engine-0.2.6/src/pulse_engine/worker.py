"""Celery application factory.

The engine provides the Celery infrastructure (broker, result backend, base
configuration).  Individual *products* register their own tasks by importing
this app and using ``@celery_app.task``.
"""

from __future__ import annotations

import os
import ssl
from typing import TYPE_CHECKING

from celery import Celery

if TYPE_CHECKING:
    from pulse_engine.config import Settings
    from pulse_engine.registry import ProductManifest


def create_celery_app(
    settings: Settings, manifest: ProductManifest | None = None
) -> Celery:
    app = Celery(
        "pulse",
        broker=settings.effective_celery_broker_url,
        backend=settings.effective_celery_result_backend,
    )

    app.conf.update(
        task_serializer="json",
        accept_content=["json"],
        result_serializer="json",
        timezone="UTC",
        enable_utc=True,
        task_track_started=True,
        task_acks_late=True,
        worker_prefetch_multiplier=1,
        broker_connection_retry_on_startup=True,
        # ElastiCache Serverless (Valkey) rejects PSUBSCRIBE (cluster mode).
        # Disable remote control and task events (both use PSUBSCRIBE).
        # gossip/heartbeat/mingle are disabled via CLI flags in the ECS task command.
        worker_enable_remote_control=False,
        worker_send_task_events=False,
        task_send_sent_event=False,
        # Force all Celery keys to the same Redis cluster slot.
        broker_transport_options={
            "global_keyprefix": "{pulse-celery}",
            "fanout_patterns": False,
            "fanout_prefix": True,
        },
        result_backend_transport_options={
            "global_keyprefix": "{pulse-celery}",
        },
    )

    broker_url = settings.effective_celery_broker_url or ""
    if broker_url.startswith("rediss://"):
        ssl_mode_str = os.getenv("REDIS_SSL_CERT_REQS", "CERT_NONE")
        ssl_mode_val = getattr(ssl, ssl_mode_str, ssl.CERT_NONE)
        ssl_opts = {"ssl_cert_reqs": ssl_mode_val}
        app.conf.update(
            broker_use_ssl=ssl_opts,
            redis_backend_use_ssl=ssl_opts.copy(),
        )

    # Auto-discover tasks in engine and any product modules
    packages = ["pulse_engine"]
    if manifest and manifest.celery_task_modules:
        packages.extend(manifest.celery_task_modules)
    app.autodiscover_tasks(packages)

    return app


# Module-level instance for Celery CLI (-A pulse_engine.worker) and for product
# packages to import as ``from pulse_engine.worker import celery_app``.
from pulse_engine.config import get_settings  # noqa: E402

celery_app = create_celery_app(get_settings())
