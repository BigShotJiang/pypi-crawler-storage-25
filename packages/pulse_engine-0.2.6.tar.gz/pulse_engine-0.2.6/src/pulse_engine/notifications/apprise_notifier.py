from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING

import structlog

from pulse_engine.pipeline.schemas import NotificationTarget, SecretRef
from pulse_engine.secrets import fetch_secret

if TYPE_CHECKING:
    pass

logger = structlog.get_logger(__name__)


async def _resolve_url(value: str | SecretRef | None) -> str | None:
    if value is None:
        return None
    if isinstance(value, SecretRef):
        return await fetch_secret(value.from_secret)
    return value


def _to_apprise_url(notification_type: str, raw_url: str) -> str | None:
    if notification_type == "discord" and "/api/webhooks/" in raw_url:
        _, rest = raw_url.split("/api/webhooks/", 1)
        return f"discord://{rest}"
    if notification_type in ("slack", "email", "webhook"):
        return raw_url
    return None


async def send_notifications(
    targets: list[NotificationTarget],
    title: str,
    body: str,
) -> None:
    import apprise  # lazy import — optional dependency

    ap = apprise.Apprise()
    for target in targets:
        raw = await _resolve_url(target.webhook_url or target.smtp_url)
        if not raw:
            logger.warning(
                "notification_target_no_url",
                notification_type=target.type,
            )
            continue
        url = _to_apprise_url(target.type, raw)
        if url:
            ap.add(url)
        else:
            logger.warning(
                "notification_url_unrecognised",
                notification_type=target.type,
            )

    if not len(ap):
        return

    await asyncio.to_thread(ap.notify, title=title, body=body)
