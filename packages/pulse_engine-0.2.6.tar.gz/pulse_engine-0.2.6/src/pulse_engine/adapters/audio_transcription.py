"""Audio transcription adapter using OpenAI Whisper."""

from __future__ import annotations

import asyncio
import glob
import os
import subprocess
import tempfile
from pathlib import Path
from typing import Any

import structlog

from .models import TranscriptSegment, VideoAudio

logger = structlog.get_logger(__name__)

_WHISPER_MAX_BYTES = 24 * 1024 * 1024  # stay under Whisper's 25 MB hard limit
_WHISPER_CHUNK_SECS = 10 * 60  # split large files into 10-min chunks


class AudioTranscriptionAdapter:
    """Transcribes an audio file using OpenAI Whisper, returning a VideoAudio.

    Large files (>24 MB) are automatically split into 10-minute chunks via
    ffmpeg and stitched back together with adjusted timestamps.

    Usage::

        adapter = AudioTranscriptionAdapter(openai_api_key="sk-...")
        audio = await adapter.transcribe(Path("/tmp/abc123.mp3"), language="en")
    """

    def __init__(self, openai_api_key: str) -> None:
        self._openai_api_key = openai_api_key

    async def transcribe(self, audio_path: Path, language: str = "en") -> VideoAudio:
        """Transcribe *audio_path* and return a :class:`VideoAudio`.

        Args:
            audio_path: Path to an mp3 (or other audio) file.
            language:   BCP-47 language tag, or ``"auto"`` for Whisper auto-detect.
        """
        logger.info(
            "audio_transcription_started",
            audio_path=str(audio_path),
            language=language,
        )
        transcript, segments = await self._transcribe(audio_path, language=language)
        logger.info(
            "audio_transcription_completed",
            audio_path=str(audio_path),
            segments=len(segments),
            chars=len(transcript),
        )
        return VideoAudio(transcript=transcript, language=language, segments=segments)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    async def _transcribe(
        self, audio_path: Path, language: str
    ) -> tuple[str, list[TranscriptSegment]]:
        """Send audio to Whisper, returning (full_text, segments).

        Large files (>24 MB) are split into 10-minute chunks via ffmpeg and
        stitched back together with adjusted timestamps.
        """
        # Empty language string signals Whisper auto-detect.
        whisper_language = "" if language.lower() == "auto" else language

        try:
            from openai import OpenAI

            client = OpenAI(api_key=self._openai_api_key)

            def _transcribe_file(path: Path, offset: float) -> list[TranscriptSegment]:
                with open(path, "rb") as fobj:
                    kwargs: dict[str, Any] = {
                        "model": "whisper-1",
                        "file": fobj,
                        "response_format": "verbose_json",
                        "timestamp_granularities": ["segment"],
                    }
                    if whisper_language:
                        kwargs["language"] = whisper_language
                    resp = client.audio.transcriptions.create(**kwargs)

                raw = getattr(resp, "segments", None) or []
                return [
                    TranscriptSegment(
                        start=float(
                            s.get("start", 0) if isinstance(s, dict) else s.start
                        )
                        + offset,
                        end=float(s.get("end", 0) if isinstance(s, dict) else s.end)
                        + offset,
                        text=(
                            s.get("text", "") if isinstance(s, dict) else s.text
                        ).strip(),
                    )
                    for s in raw
                ]

            file_size = audio_path.stat().st_size

            if file_size <= _WHISPER_MAX_BYTES:
                segments = await asyncio.to_thread(_transcribe_file, audio_path, 0.0)
            else:
                logger.info(
                    "audio_whisper_splitting_large_file",
                    size_mb=round(file_size / (1024 * 1024), 1),
                )

                def _split_and_transcribe() -> list[TranscriptSegment]:
                    with tempfile.TemporaryDirectory(prefix="whisper_chunks_") as td:
                        chunk_pattern = os.path.join(td, "chunk_%04d.mp3")
                        subprocess.run(
                            [
                                "ffmpeg",
                                "-i",
                                str(audio_path),
                                "-f",
                                "segment",
                                "-segment_time",
                                str(_WHISPER_CHUNK_SECS),
                                "-c",
                                "copy",
                                "-reset_timestamps",
                                "1",
                                chunk_pattern,
                            ],
                            check=True,
                            capture_output=True,
                        )
                        chunk_files = sorted(glob.glob(os.path.join(td, "chunk_*.mp3")))
                        all_segs: list[TranscriptSegment] = []
                        offset = 0.0
                        for chunk_path in chunk_files:
                            segs = _transcribe_file(Path(chunk_path), offset)
                            if segs:
                                offset = segs[-1].end
                            all_segs.extend(segs)
                    return all_segs

                segments = await asyncio.to_thread(_split_and_transcribe)

            full_text = " ".join(s.text for s in segments)
            return full_text, segments

        except Exception:
            logger.warning(
                "audio_whisper_transcription_failed",
                audio_path=str(audio_path),
                exc_info=True,
            )
            return "", []
