"""Lambda handler wrapper for product containers.

This is the Lambda handler pointed to by Terraform for native Lambda compute.
Product containers must NOT add any orchestration logic — they expose a plain
`entrypoint:run` function and this runner unpacks the event and calls it.

Event schema (sent by _dispatch_lambda in prefect_pipeline_flow.py):
    MODULE_NAME, ARGS (JSON str), PIPELINE_RUN_ID, STEP_NAME, TENANT_ID,
    PULSE_ENGINE_URL, PULSE_API_TOKEN, OUTPUT_S3_BUCKET, OUTPUT_S3_KEY,
    INPUTS_S3_KEY (optional — inputs offloaded to S3)

Terraform Lambda resource handler:
    pulse_engine.runners.lambda_runner.handler
"""

from __future__ import annotations

import json
from typing import Any, cast


def handler(event: dict[str, Any], context: object) -> dict[str, Any]:
    """Engine-owned Lambda handler. Delegates to the product's plain entrypoint."""
    import boto3
    from entrypoint import run  # imported at call time from the product container

    pipeline_run_id = event["PIPELINE_RUN_ID"]
    pulse_engine_url = event["PULSE_ENGINE_URL"]
    pulse_api_token = event["PULSE_API_TOKEN"]
    s3_bucket = event["OUTPUT_S3_BUCKET"]
    s3_key = event["OUTPUT_S3_KEY"]

    args = json.loads(event.get("ARGS", "{}"))

    inputs_s3_key = event.get("INPUTS_S3_KEY")
    if inputs_s3_key:
        raw = (
            boto3.client("s3")
            .get_object(Bucket=s3_bucket, Key=inputs_s3_key)["Body"]
            .read()
            .decode()
        )
        inputs = json.loads(raw)
    else:
        inputs = json.loads(event.get("INPUTS", "{}")) if event.get("INPUTS") else None

    result: dict[str, Any] = cast(
        dict[str, Any],
        run(
            job_id=pipeline_run_id,
            args=args,
            inputs=inputs,
            pipeline_run_id=pipeline_run_id,
            pulse_engine_url=pulse_engine_url,
            pulse_api_token=pulse_api_token,
        ),
    )

    boto3.client("s3").put_object(
        Bucket=s3_bucket,
        Key=s3_key,
        Body=json.dumps(result).encode(),
        ContentType="application/json",
    )

    return result
