"""Dynamic AWS infrastructure provisioner for pipeline step execution.

The engine auto-provisions ECS task definitions, Lambda functions, and ECR
repositories so that products can execute immediately after registration
without requiring manual Terraform runs for each new product/module.

Prerequisites (created by Terraform once):
  - ECS cluster, execution role, task role, security group (pipeline_cluster module)
  - Lambda execution role, security group (lambda_pipeline module)
  - VPC with private subnets (networking module)
"""

from __future__ import annotations

import logging
from typing import Any

import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)


class InfraProvisioner:
    """Auto-provisions AWS infrastructure for pipeline step containers.

    Uses IAM roles and networking created by Terraform. Creates the dynamic
    resources (task definitions, Lambda functions, ECR repos) on demand.
    """

    def __init__(
        self,
        *,
        region: str,
        pipeline_cluster_name: str,
        pipeline_execution_role_arn: str,
        pipeline_task_role_arn: str,
        pipeline_log_group: str,
        pipeline_subnets: list[str],
        pipeline_security_groups: list[str],
        lambda_execution_role_arn: str,
        lambda_subnets: list[str],
        lambda_security_groups: list[str],
        lambda_log_group: str,
    ) -> None:
        self._region = region
        self._cluster = pipeline_cluster_name
        self._exec_role_arn = pipeline_execution_role_arn
        self._task_role_arn = pipeline_task_role_arn
        self._log_group = pipeline_log_group
        self._subnets = pipeline_subnets
        self._security_groups = pipeline_security_groups
        self._lambda_role_arn = lambda_execution_role_arn
        self._lambda_subnets = lambda_subnets
        self._lambda_sgs = lambda_security_groups
        self._lambda_log_group = lambda_log_group

        # Cache to avoid redundant API calls within same process lifetime
        self._ecs_task_def_cache: dict[str, str] = {}
        self._lambda_fn_cache: set[str] = set()
        self._ecr_repo_cache: dict[str, str] = {}

    # ------------------------------------------------------------------
    # ECS Task Definition
    # ------------------------------------------------------------------

    def ensure_ecs_task_definition(
        self,
        family: str = "pulse-pipeline-step",
        cpu: str = "256",
        memory: str = "512",
        image: str | None = None,
    ) -> str:
        """Create or update a Fargate task definition for pipeline steps.

        When image is provided, registers a new revision with that image.
        When image is None, reuses existing revision or creates one with
        a placeholder image.

        Returns the task definition ARN.
        """
        cache_key = f"{family}:{cpu}:{memory}:{image or 'default'}"
        if cache_key in self._ecs_task_def_cache:
            return self._ecs_task_def_cache[cache_key]

        ecs = boto3.client("ecs", region_name=self._region)

        # If no specific image requested, reuse existing task def
        if image is None:
            try:
                resp = ecs.describe_task_definition(taskDefinition=family)
                existing = resp["taskDefinition"]
                result_arn = str(existing["taskDefinitionArn"])
                logger.info(
                    "ECS task definition already exists: %s (rev %s)",
                    family,
                    existing["revision"],
                )
                self._ecs_task_def_cache[cache_key] = result_arn
                return result_arn
            except ClientError as e:
                if e.response["Error"]["Code"] != "ClientException":
                    raise

        # Register new task definition with the specified (or placeholder) image
        container_def: dict[str, Any] = {
            "name": "step",
            "image": image or "amazon/amazon-ecs-sample",
            "essential": True,
            # Set entryPoint to "python -c" so that the ECS
            # containerOverrides.command becomes the script body.
            # This overrides any image ENTRYPOINT (e.g. Lambda images
            # with awslambdaric) ensuring the pipeline runner script
            # executes instead of the Lambda runtime.
            "entryPoint": ["python", "-c"],
            "command": ["print('task-definition placeholder')"],
            "logConfiguration": {
                "logDriver": "awslogs",
                "options": {
                    "awslogs-group": self._log_group,
                    "awslogs-region": self._region,
                    "awslogs-stream-prefix": "step",
                },
            },
        }

        resp = ecs.register_task_definition(
            family=family,
            networkMode="awsvpc",
            requiresCompatibilities=["FARGATE"],
            cpu=cpu,
            memory=memory,
            executionRoleArn=self._exec_role_arn,
            taskRoleArn=self._task_role_arn,
            containerDefinitions=[container_def],
        )

        result_arn = str(resp["taskDefinition"]["taskDefinitionArn"])
        logger.info("Registered ECS task definition: %s (image=%s)", result_arn, image)
        self._ecs_task_def_cache[cache_key] = result_arn
        return result_arn

    # ------------------------------------------------------------------
    # Lambda Function
    # ------------------------------------------------------------------

    def ensure_lambda_function(  # noqa: PLR0913
        self,
        function_name: str,
        image_uri: str,
        timeout: int = 900,
        memory_size: int = 3008,
        use_vpc: bool = True,
    ) -> str:
        """Create or update a Lambda function backed by a container image.

        When use_vpc=False the function is created without VpcConfig — it gets
        direct internet access. Use this for extractor/discovery modules that
        only call external APIs and S3 (no RDS/OpenSearch needed).

        Always waits for the function to be Active before returning.
        Returns the function name.
        """
        if function_name in self._lambda_fn_cache:
            return function_name

        lam = boto3.client("lambda", region_name=self._region)

        create_kwargs: dict[str, Any] = {
            "FunctionName": function_name,
            "Role": self._lambda_role_arn,
            "Code": {"ImageUri": image_uri},
            "PackageType": "Image",
            "Timeout": timeout,
            "MemorySize": memory_size,
            "Environment": {"Variables": {}},
        }
        if use_vpc and (self._lambda_subnets or self._lambda_sgs):
            create_kwargs["VpcConfig"] = {
                "SubnetIds": self._lambda_subnets,
                "SecurityGroupIds": self._lambda_sgs,
            }

        try:
            lam.get_function(FunctionName=function_name)
            # Function exists — update code to latest image
            self._update_lambda_code(function_name, image_uri)
            logger.info("Lambda function exists, updated code: %s", function_name)
        except ClientError as e:
            if e.response["Error"]["Code"] != "ResourceNotFoundException":
                raise
            # Create the function
            lam.create_function(**create_kwargs)
            logger.info("Created Lambda function: %s", function_name)

        # Always wait for function to be Active (handles both create and update)
        waiter = lam.get_waiter("function_active_v2")
        waiter.wait(FunctionName=function_name, WaiterConfig={"MaxAttempts": 60})
        logger.info("Lambda function active: %s", function_name)

        self._lambda_fn_cache.add(function_name)
        return function_name

    def _update_lambda_code(self, function_name: str, image_uri: str) -> None:
        """Update Lambda function code to a new container image."""
        lam = boto3.client("lambda", region_name=self._region)
        try:
            lam.update_function_code(FunctionName=function_name, ImageUri=image_uri)
        except ClientError:
            logger.warning(
                "Failed to update Lambda code for %s", function_name, exc_info=True
            )

    # ------------------------------------------------------------------
    # ECR Repository
    # ------------------------------------------------------------------

    def ensure_ecr_repository(self, repo_name: str) -> str:
        """Create an ECR repository if it doesn't exist.

        Returns the repository URI.
        """
        if repo_name in self._ecr_repo_cache:
            return self._ecr_repo_cache[repo_name]

        ecr = boto3.client("ecr", region_name=self._region)

        lifecycle_policy = (
            '{"rules":[{"rulePriority":1,"description":"Keep last 30",'
            '"selection":{"tagStatus":"any","countType":"imageCountMoreThan",'
            '"countNumber":30},"action":{"type":"expire"}}]}'
        )

        try:
            resp = ecr.describe_repositories(repositoryNames=[repo_name])
            uri = str(resp["repositories"][0]["repositoryUri"])
        except ClientError as e:
            if e.response["Error"]["Code"] != "RepositoryNotFoundException":
                raise
            resp = ecr.create_repository(
                repositoryName=repo_name,
                imageScanningConfiguration={"scanOnPush": True},
                imageTagMutability="MUTABLE",
            )
            uri = str(resp["repository"]["repositoryUri"])
            ecr.put_lifecycle_policy(
                repositoryName=repo_name,
                lifecyclePolicyText=lifecycle_policy,
            )
            logger.info("Created ECR repository: %s (%s)", repo_name, uri)

        self._ecr_repo_cache[repo_name] = uri
        return uri

    # ------------------------------------------------------------------
    # Convenience: provision everything a module needs
    # ------------------------------------------------------------------

    def provision_for_ecs_module(
        self,
        product: str,
        module: str,
        task_def_family: str = "pulse-pipeline-step",
    ) -> dict[str, str]:
        """Ensure all ECS infrastructure exists for a pipeline module.

        Returns dict with cluster, task_definition, subnets, security_groups.
        """
        task_def_arn = self.ensure_ecs_task_definition(family=task_def_family)
        ecr_repo = self.ensure_ecr_repository(f"{product}-{module}")

        return {
            "cluster": self._cluster,
            "task_definition": task_def_arn,
            "subnets": ",".join(self._subnets),
            "security_groups": ",".join(self._security_groups),
            "ecr_repository": ecr_repo,
        }

    def provision_for_lambda_module(
        self,
        product: str,
        module: str,
        image_uri: str,
    ) -> dict[str, str]:
        """Ensure Lambda function exists for a pipeline module.

        Returns dict with function_name.
        """
        func_name = f"{product}-{module}"
        self.ensure_lambda_function(func_name, image_uri)

        return {"function_name": func_name}
