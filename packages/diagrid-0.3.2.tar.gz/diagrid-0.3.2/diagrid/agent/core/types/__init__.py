# Copyright (c) 2026-Present Diagrid Inc.
# SPDX-License-Identifier: BUSL-1.1

from .type import (
    SupportedFrameworks,
)

__all__ = [
    "SupportedFrameworks",
]
