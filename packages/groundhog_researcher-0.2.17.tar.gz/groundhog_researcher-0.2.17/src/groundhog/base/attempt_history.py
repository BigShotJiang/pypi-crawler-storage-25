"""Attempt History — the optimizer's memory of every candidate.

An immutable tree of attempts. Each attempt stores code, raw results (metrics,
not scores), artifacts, and a parent pointer. Scores are never persisted —
scoring is always a read-side concern via the Evaluator's scorer, so scoring
criteria can change without re-evaluating.

Workspace pattern: history.workspace(parent) → Workspace with a path.
Strategy works in the path (writes files, runs eval), then calls commit() or
abort(). Commit makes it an immutable attempt. Abort deletes everything.

Properties:
- Immutable — once committed, an attempt never changes
- Atomic — committed fully or aborted entirely
- Complete — nothing discarded; failed attempts are recorded too
"""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Callable, List, Optional

from groundhog.base.types import EvaluationResult, StageResult


class Attempt(ABC):
    """A committed attempt in the history. Read-only."""
    number: int
    parent: Optional[int]

    @property
    @abstractmethod
    def code(self) -> str: ...

    @property
    @abstractmethod
    def result(self) -> EvaluationResult: ...

    @property
    @abstractmethod
    def metadata(self) -> dict: ...

    @abstractmethod
    def list_files(self) -> List[str]:
        """List all files in this attempt (relative paths)."""
        ...

    @abstractmethod
    def read_file(self, path: str) -> Optional[str]:
        """Read a text file from this attempt. Returns None if not found.
        Returns a placeholder for binary files."""
        ...


class Workspace(ABC):
    """A working directory for one attempt. Start → work → commit or abort."""
    number: int
    parent: Optional[int]
    path: Path

    @abstractmethod
    def commit(self, success: bool = True) -> Attempt:
        """Mark this workspace as a completed attempt. No going back."""
        ...

    @abstractmethod
    def abort(self):
        """Discard this workspace. No trace left."""
        ...


class AttemptHistory(ABC):
    """Storage and retrieval for all attempts."""

    @abstractmethod
    def workspace(self, parent: Optional[int] = None) -> Workspace:
        """Create a new workspace to work in. Call commit() or abort() when done."""
        ...

    @abstractmethod
    def list(self, only_done: bool = True) -> List[Attempt]: ...

    @abstractmethod
    def get(self, number: int) -> Optional[Attempt]: ...

    @abstractmethod
    def best(self, scorer: Callable[[StageResult], float]) -> Optional[Attempt]: ...

    @abstractmethod
    def lineage(self, attempt: Attempt) -> List[Attempt]: ...

    def derive_trunks(self, scorer: Callable[[StageResult], float]) -> List[List[Attempt]]:
        """Find improvement chains — trunks are derived, not stored.

        A trunk is a chain from a root where each step improved on its parent
        under the given scorer. Change the scorer, get different trunks.
        """
        attempts = self.list()
        if not attempts:
            return []

        by_number = {a.number: a for a in attempts}
        children = {}
        roots = []
        for a in attempts:
            if a.parent is None:
                roots.append(a)
            else:
                children.setdefault(a.parent, []).append(a)

        def score_attempt(attempt):
            result = attempt.result
            if not result.completed:
                return -1.0
            last = list(result.stages.values())[-1]
            return scorer(last)

        trunks = []
        for root in roots:
            trunk = [root]
            current = root
            current_score = score_attempt(current)
            while current.number in children:
                best_child = None
                best_score = current_score
                for child in children[current.number]:
                    s = score_attempt(child)
                    if s > best_score:
                        best_child = child
                        best_score = s
                if best_child is None:
                    break
                trunk.append(best_child)
                current = best_child
                current_score = best_score
            trunks.append(trunk)
        return trunks

    def derive_families(self) -> List[List[Attempt]]:
        """Group attempts by their core direction (read-side derived view).

        A family = attempts sharing the same normalized ``core_direction.md``
        content. Falls back to legacy ``approach.md``. Attempts with no
        direction file land in a "no-direction" sentinel family (stable key
        ``None``). Families are returned sorted by attempt-number of the
        oldest member, so the seed family appears first.

        See ``Optimizer/Implementation Details/Family Identity.md``.
        """
        from groundhog.utils.direction import read_direction, normalize_direction

        groups: dict = {}
        for a in self.list():
            text = read_direction(a.path) if hasattr(a, "path") else None
            key = normalize_direction(text) if text else None
            groups.setdefault(key, []).append(a)
        # Sort each group by attempt number; sort families by oldest member.
        for members in groups.values():
            members.sort(key=lambda x: x.number)
        return sorted(groups.values(), key=lambda g: g[0].number)
