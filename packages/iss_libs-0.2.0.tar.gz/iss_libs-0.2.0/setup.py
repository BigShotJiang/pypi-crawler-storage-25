from pathlib import Path

from setuptools import find_packages, setup


BASE_DIR = Path(__file__).parent
README_PATH = BASE_DIR / "README.md"

INSTALL_REQUIRES = [
    "asgiref",
    "connexion",
    "fastapi",
    "itsdangerous",
    "matplotlib",
    "marshmallow",
    "marshmallow_sqlalchemy",
    "minimalmodbus",
    "ntplib",
    "paramiko",
    "prettytable",
    "psycopg2-binary",
    "psutil",
    "python-dotenv",
    "python-gitlab",
    "python-socketio",
    "pyModbusTCP",
    "pyserial",
    "PyVISA",
    "pyvisa-py",
    "redis",
    "requests",
    "robotframework",
    "robotframework-sshlibrary",
    "sqlalchemy",
    "six",
    "xmltodict",
    "uvicorn",
    "pip-review",
]

CLASSIFIERS = [
    "Development Status :: 4 - Beta",
    "Intended Audience :: Developers",
    "Topic :: Software Development :: Build Tools",
    "Programming Language :: Python :: 3.10",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
]


setup(
    name="iss-libs",
    version="0.2.0",
    author="PosterSom",
    author_email="PosterSom@gmail.com",
    maintainer="PosterSom",
    maintainer_email="PosterSom@gmail.com",
    description="",
    long_description=README_PATH.read_text(encoding="utf-8"),
    long_description_content_type="text/markdown",
    url="https://github.com/postersom/iss-libs",
    license_expression="MIT",
    packages=find_packages(),
    package_dir={"client": "Client"},
    install_requires=INSTALL_REQUIRES,
    classifiers=CLASSIFIERS,
    python_requires=">=3.10",
)
