# iss-libs

![Release](https://img.shields.io/github/v/release/postersom/libs)
![Downloads](https://img.shields.io/github/downloads/postersom/libs/total)
![License](https://img.shields.io/github/license/postersom/iss-libs)
![Python](https://img.shields.io/badge/python-3.10%2B-blue)

`iss-libs` is a Python package intended to centralize shared libraries and runtime dependencies for ISS-related projects.

## Overview

This repository currently provides the package metadata and dependency definition used to publish `iss-libs` on PyPI. It targets Python `3.10+` and bundles a broad set of libraries commonly used for:

- API and backend development
- Database access
- Modbus / serial / VISA communication
- Automation and Robot Framework workflows
- System utilities and networking

## Installation

Install from PyPI:

```bash
pip install iss-libs
```

Or install locally for development:

```bash
pip install -e .
```

## Requirements

- Python `>= 3.10`
- `pip`

## Included Dependencies

The package currently declares dependencies such as:

- `fastapi`, `uvicorn`, `connexion`
- `sqlalchemy`, `psycopg2-binary`, `redis`
- `pyserial`, `pyModbusTCP`, `minimalmodbus`, `PyVISA`, `pyvisa-py`
- `robotframework`, `robotframework-sshlibrary`
- `paramiko`, `requests`, `python-socketio`, `ntplib`
- `marshmallow`, `marshmallow_sqlalchemy`, `python-dotenv`

For the complete and authoritative list, see [setup.py](/home/tdeadmin/Documents/iss-libs/setup.py).

## Project Status

The current repository structure is minimal and primarily focused on packaging and distribution. If this project is intended to expose reusable Python modules, the package source directories should be added alongside the existing packaging files.

## Contributing

Contributions are welcome. A good starting workflow is:

- Fork the repository.
- Create a feature branch.
- Make your changes.
- Test your changes locally.
- Open a pull request with a clear description.

## Maintainer

- PosterSom (@postersom)

## License

This project is released under the MIT License. See [LICENSE](/home/tdeadmin/Documents/iss-libs/LICENSE) for details.
