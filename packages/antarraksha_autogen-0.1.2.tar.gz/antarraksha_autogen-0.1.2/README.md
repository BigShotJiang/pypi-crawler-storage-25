# antarraksha-autogen

Antarraksha AI Agent Enforcement SDK for Autogen.

## Installation

```bash
pip install antarraksha-autogen
```

## Quick Start

```python
from antarraksha_autogen import AntarakshaClient

client = AntarakshaClient(
    base_url="https://antarraksha.ai",
    agent_id="my-agent",
    passport_id="ANTK-PASS-xxx",
)
client.register()
```
