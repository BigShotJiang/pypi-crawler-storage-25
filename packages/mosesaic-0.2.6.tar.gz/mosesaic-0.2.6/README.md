# Mosesaic

AI agent orchestration framework and virtual agile sprint team for solo developers.

## Install

```bash
pip install mosesaic
```

Requires Python 3.12+.

## Quick Start

```bash
# Create config
mosesaic init

# Start the server (REST + MCP)
mosesaic serve

# Or start with Claude Code MCP integration
mosesaic serve --with-mcp
```

## What's Included

| Package | Purpose |
|---------|---------|
| `mosesaic-core` | Actor model runtime, message bus, agent lifecycle |
| `mosesaic-llm` | Multi-provider LLM abstraction (Anthropic, OpenAI, Groq, Ollama, Gemini) |
| `mosesaic-tools` | Tool decorator, registry, and policy |
| `mosesaic-memory` | Short/working/long-term memory |
| `mosesaic-workflow` | Workflow primitives: step, parallel, verify, human_gate |
| `mosesaic-server` | FastAPI REST server for agents and workflows |
| `mosesaic-mcp-server` | MCP server — use Mosesaic from Claude Code |
| `mosesaic-team` | Virtual sprint team: PM, Architect, Developer, QA, Designer agents |
| `mosesaic-cli` | `mosesaic` command-line tool |

## Documentation

[https://github.com/alexFund/mosesaic](https://github.com/alexFund/mosesaic)

## License

[Elastic License 2.0](https://www.elastic.co/licensing/elastic-license) — free to use, cannot redistribute or offer as a managed service.
