"""Typer-based CLI implementation."""
