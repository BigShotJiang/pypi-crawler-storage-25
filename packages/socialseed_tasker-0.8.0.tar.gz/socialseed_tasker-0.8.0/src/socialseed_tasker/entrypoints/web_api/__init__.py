"""FastAPI-based REST implementation."""
