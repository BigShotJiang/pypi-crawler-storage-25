import io
import json
import pytest
import docopt

from .tokens_cli import main as run_main


_SPEC = {
    "lexical": {"ruleList": [
        {"name": "NUM", "pattern": "\\d+", "isSkip": False,
         "line": {"string": "", "number": 1, "file": None}}
    ]},
    "syntax": {"rules": []},
    "semantics": []
}


def test_no_args_prints_usage():
    with pytest.raises((docopt.DocoptExit, SystemExit)):
        run_main([])


def test_help(capsys):
    with pytest.raises(SystemExit):
        run_main(['--help'])
    out, err = capsys.readouterr()
    assert 'Usage' in out


def test_outputs_token_jsonl(capsys, monkeypatch, fs):
    fs.create_file('/spec.json', contents=json.dumps(_SPEC_WITH_SKIP))
    monkeypatch.setattr('sys.stdin', io.StringIO('42\n'))
    run_main(['/spec.json'])
    out, err = capsys.readouterr()
    lines = [l for l in out.strip().splitlines() if l]
    records = [json.loads(l) for l in lines]
    non_sentinel = [r for r in records if r.get('name') != 'eof']
    assert len(non_sentinel) == 1
    record = non_sentinel[0]
    assert record['kind'] == 'token'
    assert record['name'] == 'NUM'
    assert record['lexeme'] == '42'


def test_lex_error_emits_error_record_to_stdout(capsys, monkeypatch, fs):
    fs.create_file('/spec.json', contents=json.dumps(_SPEC))
    monkeypatch.setattr('sys.stdin', io.StringIO('@'))  # no trailing \n
    # Verify it does not raise SystemExit (exits 0)
    try:
        run_main(['/spec.json'])
    except SystemExit as e:
        pytest.fail(f"run_main raised SystemExit({e.code}), expected normal return")
    out, err = capsys.readouterr()
    lines = [l for l in out.strip().splitlines() if l]
    records = [json.loads(l) for l in lines]
    error_records = [r for r in records if r.get('kind') == 'error']
    assert len(error_records) == 1
    record = error_records[0]
    assert record['kind'] == 'error'
    assert record['stage'] == 'plcc-tokens'
    assert record['severity'] == 'error'
    assert record['lexeme'] == '@'
    assert record['source'] == {'file': '-', 'line': 1, 'column': 1}
    assert record['message'] == "unrecognized character '@'"
    assert err == ''


def test_lex_error_and_token_appear_in_stream_order(capsys, monkeypatch, fs):
    fs.create_file('/spec.json', contents=json.dumps(_SPEC_WITH_SKIP))
    # '@' is unrecognized, then '42' is a valid NUM token
    monkeypatch.setattr('sys.stdin', io.StringIO('@42\n'))
    run_main(['/spec.json'])
    out, err = capsys.readouterr()
    lines = [l for l in out.strip().splitlines() if l]
    records = [json.loads(l) for l in lines]
    non_sentinel = [r for r in records if r.get('name') != 'eof']
    assert len(non_sentinel) == 2
    assert non_sentinel[0]['kind'] == 'error'
    assert non_sentinel[1]['kind'] == 'token'
    assert non_sentinel[1]['name'] == 'NUM'


def test_stdin_labels_tokens_with_dash(capsys, monkeypatch, fs):
    fs.create_file('/spec.json', contents=json.dumps(_SPEC_WITH_SKIP))
    monkeypatch.setattr('sys.stdin', io.StringIO('42\n'))
    run_main(['/spec.json'])
    out, _ = capsys.readouterr()
    records = [json.loads(l) for l in out.strip().splitlines() if l]
    token_records = [r for r in records if r.get('name') != 'eof']
    assert len(token_records) == 1
    assert token_records[0]['source']['file'] == '-'


def test_named_file_arg_labels_tokens_with_filename(capsys, fs):
    fs.create_file('/spec.json', contents=json.dumps(_SPEC_WITH_SKIP))
    fs.create_file('/src.txt', contents='42\n')
    run_main(['/spec.json', '/src.txt'])
    out, _ = capsys.readouterr()
    records = [json.loads(l) for l in out.strip().splitlines() if l]
    token_records = [r for r in records if r.get('name') != 'eof']
    assert len(token_records) == 1
    assert token_records[0]['source']['file'] == '/src.txt'


_SPEC_WITH_SKIP = {
    "lexical": {"ruleList": [
        {"name": "NUM", "pattern": "\\d+", "isSkip": False,
         "line": {"string": "", "number": 1, "file": None}},
        {"name": "WS", "pattern": "\\s+", "isSkip": True,
         "line": {"string": "", "number": 2, "file": None}},
    ]},
    "syntax": {"rules": []},
    "semantics": []
}


_SPEC_WITH_NL_TOKEN = {
    "lexical": {"ruleList": [
        {"name": "NUM", "pattern": "\\d+", "isSkip": False,
         "line": {"string": "", "number": 1, "file": None}},
        {"name": "NL", "pattern": "\\n", "isSkip": False,
         "line": {"string": "", "number": 2, "file": None}},
        {"name": "WS", "pattern": "[ \\t]+", "isSkip": True,
         "line": {"string": "", "number": 3, "file": None}},
    ]},
    "syntax": {"rules": []},
    "semantics": []
}


def test_default_omits_regex_and_source_line(capsys, monkeypatch, fs):
    fs.create_file('/spec.json', contents=json.dumps(_SPEC_WITH_SKIP))
    monkeypatch.setattr('sys.stdin', io.StringIO('42\n'))
    run_main(['/spec.json'])
    out, _ = capsys.readouterr()
    records = [json.loads(l) for l in out.strip().splitlines() if l]
    token_records = [r for r in records if r.get('name') != 'eof']
    assert len(token_records) == 1
    record = token_records[0]
    assert 'regex' not in record
    assert 'source_line' not in record


def test_trace_includes_regex_and_source_line(capsys, monkeypatch, fs):
    fs.create_file('/spec.json', contents=json.dumps(_SPEC_WITH_SKIP))
    monkeypatch.setattr('sys.stdin', io.StringIO('42\n'))
    run_main(['--trace', '/spec.json'])
    out, _ = capsys.readouterr()
    records = [json.loads(l) for l in out.strip().splitlines() if l]
    token_records = [r for r in records if r.get('kind') == 'token' and r.get('name') != 'eof']
    assert len(token_records) == 1
    record = token_records[0]
    assert record['regex'] == '\\d+'
    assert record['source_line'] == '42'


def test_default_suppresses_skip_records(capsys, monkeypatch, fs):
    fs.create_file('/spec.json', contents=json.dumps(_SPEC_WITH_SKIP))
    monkeypatch.setattr('sys.stdin', io.StringIO('42 99\n'))
    run_main(['/spec.json'])
    out, _ = capsys.readouterr()
    records = [json.loads(l) for l in out.strip().splitlines() if l]
    kinds = [r['kind'] for r in records]
    assert 'skip' not in kinds


def test_trace_emits_skip_records(capsys, monkeypatch, fs):
    fs.create_file('/spec.json', contents=json.dumps(_SPEC_WITH_SKIP))
    monkeypatch.setattr('sys.stdin', io.StringIO('42 99\n'))
    run_main(['--trace', '/spec.json'])
    out, _ = capsys.readouterr()
    records = [json.loads(l) for l in out.strip().splitlines() if l]
    kinds = [r['kind'] for r in records]
    assert 'skip' in kinds


def test_verbose_scanning_file_event(capsys, fs):
    fs.create_file('/spec.json', contents=json.dumps(_SPEC))
    fs.create_file('/src.txt', contents='42\n')
    run_main(['-v', '--verbose-format=text', '/spec.json', '/src.txt'])
    _, err = capsys.readouterr()
    assert 'scanning /src.txt' in err


def test_verbose_started_finished_events(capsys, monkeypatch, fs):
    fs.create_file('/spec.json', contents=json.dumps(_SPEC))
    monkeypatch.setattr('sys.stdin', io.StringIO('42\n'))
    run_main(['-v', '--verbose-format=text', '/spec.json'])
    _, err = capsys.readouterr()
    assert 'started' in err
    assert 'finished' in err


def test_source_name_overrides_stdin_label(capsys, monkeypatch, fs):
    fs.create_file('/spec.json', contents=json.dumps(_SPEC_WITH_SKIP))
    monkeypatch.setattr('sys.stdin', io.StringIO('42\n'))
    run_main(['/spec.json', '--source-name=myfile.txt', '-'])
    out, _ = capsys.readouterr()
    records = [json.loads(l) for l in out.strip().splitlines() if l]
    token_records = [r for r in records if r.get('name') != 'eof']
    assert len(token_records) == 1
    assert token_records[0]['source']['file'] == 'myfile.txt'


def test_newline_matched_as_nl_token(capsys, monkeypatch, fs):
    fs.create_file('/spec.json', contents=json.dumps(_SPEC_WITH_NL_TOKEN))
    monkeypatch.setattr('sys.stdin', io.StringIO('42\n'))
    run_main(['/spec.json'])
    out, _ = capsys.readouterr()
    records = [json.loads(l) for l in out.strip().splitlines() if l]
    non_sentinel = [r for r in records if r.get('name') != 'eof']
    assert len(non_sentinel) == 2
    assert non_sentinel[0]['kind'] == 'token'
    assert non_sentinel[0]['name'] == 'NUM'
    assert non_sentinel[0]['lexeme'] == '42'
    assert non_sentinel[1]['kind'] == 'token'
    assert non_sentinel[1]['name'] == 'NL'
    assert non_sentinel[1]['lexeme'] == '\n'


def test_unhandled_newline_produces_lex_error(capsys, monkeypatch, fs):
    # _SPEC has only NUM '\d+' — no whitespace or newline handler
    fs.create_file('/spec.json', contents=json.dumps(_SPEC))
    monkeypatch.setattr('sys.stdin', io.StringIO('42\n'))
    run_main(['/spec.json'])
    out, _ = capsys.readouterr()
    records = [json.loads(l) for l in out.strip().splitlines() if l]
    non_sentinel = [r for r in records if r.get('name') != 'eof']
    assert len(non_sentinel) == 2
    assert non_sentinel[0]['kind'] == 'token'
    assert non_sentinel[0]['name'] == 'NUM'
    assert non_sentinel[1]['kind'] == 'error'
    assert non_sentinel[1]['lexeme'] == '\n'
