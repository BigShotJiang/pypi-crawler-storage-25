"""Official Python SDK for the EmailProbe disposable email detection API."""

from .client import EmailProbeClient
from .errors import (
    EmailProbeError,
    AuthenticationError,
    RateLimitError,
    ValidationError,
)

__version__ = "0.1.1"
__all__ = [
    "EmailProbeClient",
    "EmailProbeError",
    "AuthenticationError",
    "RateLimitError",
    "ValidationError",
]
