class EmailProbeError(Exception):
    """Base exception for EmailProbe SDK errors."""

    def __init__(self, message: str, status: int = 0, code: str = "UNKNOWN_ERROR", request_id: str = None):
        super().__init__(message)
        self.status = status
        self.code = code
        self.request_id = request_id


class AuthenticationError(EmailProbeError):
    """Raised when the API key is invalid or missing."""

    def __init__(self, message: str = "Invalid API key", request_id: str = None):
        super().__init__(message, status=401, code="AUTHENTICATION_ERROR", request_id=request_id)


class RateLimitError(EmailProbeError):
    """Raised when the rate limit is exceeded."""

    def __init__(self, message: str = "Rate limit exceeded", retry_after: int = 60, request_id: str = None):
        super().__init__(message, status=429, code="RATE_LIMIT_EXCEEDED", request_id=request_id)
        self.retry_after = retry_after


class ValidationError(EmailProbeError):
    """Raised when the request input is invalid."""

    def __init__(self, message: str = "Validation error", request_id: str = None):
        super().__init__(message, status=422, code="VALIDATION_ERROR", request_id=request_id)
