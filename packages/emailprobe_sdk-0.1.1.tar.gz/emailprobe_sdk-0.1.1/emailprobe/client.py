"""EmailProbe API client — sync (urllib) and async (httpx) support."""

import json
import urllib.request
import urllib.error
from typing import Any, Dict, Optional

from .errors import (
    EmailProbeError,
    AuthenticationError,
    RateLimitError,
    ValidationError,
)

DEFAULT_BASE_URL = "https://api.emailprobe.dev"
DEFAULT_TIMEOUT = 10


class EmailProbeClient:
    """Client for the EmailProbe disposable email detection API.

    Args:
        api_key: Your API key from app.emailprobe.dev.
        base_url: API base URL (default: https://api.emailprobe.dev).
        timeout: Request timeout in seconds (default: 10).
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: int = DEFAULT_TIMEOUT,
    ):
        if not api_key:
            raise ValueError("API key is required. Get one at https://app.emailprobe.dev/signup.html")
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout

    def validate(self, email: str) -> Dict[str, Any]:
        """Validate a full email address.

        Returns disposable detection, MX records, DNS auth, scoring, and more.
        """
        return self._request("POST", "/v1/validate", body={"email": email})

    def check_domain(self, domain: str) -> Dict[str, Any]:
        """Check a domain only (no local part needed)."""
        return self._request("GET", f"/v1/domain/{urllib.parse.quote(domain, safe='')}")

    def usage(self) -> Dict[str, Any]:
        """Get your current API usage stats."""
        return self._request("GET", "/v1/usage")

    def is_disposable(self, domain: str) -> Dict[str, Any]:
        """Free open API — check if a domain is disposable. No API key needed."""
        url = f"{self._base_url}/open/v1/disposable/{urllib.parse.quote(domain, safe='')}"
        req = urllib.request.Request(
            url,
            headers={
                "Accept": "application/json",
                "User-Agent": "emailprobe-sdk-py/0.1.0",
            },
            method="GET",
        )
        try:
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                return json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            self._handle_http_error(e)
        except urllib.error.URLError as e:
            raise EmailProbeError(f"Network error: {e.reason}", code="NETWORK_ERROR")

    def _request(self, method: str, path: str, body: Optional[dict] = None) -> Dict[str, Any]:
        url = f"{self._base_url}{path}"
        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Accept": "application/json",
            "User-Agent": "emailprobe-sdk-py/0.1.0",
        }

        data = None
        if body is not None:
            headers["Content-Type"] = "application/json"
            data = json.dumps(body).encode("utf-8")

        req = urllib.request.Request(url, data=data, headers=headers, method=method)

        try:
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                return json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            self._handle_http_error(e)
        except urllib.error.URLError as e:
            raise EmailProbeError(f"Network error: {e.reason}", code="NETWORK_ERROR")

    @staticmethod
    def _handle_http_error(error: urllib.error.HTTPError):
        try:
            error_data = json.loads(error.read().decode())
        except (json.JSONDecodeError, UnicodeDecodeError):
            error_data = {}

        message = error_data.get("error", f"HTTP {error.code}")
        request_id = error_data.get("request_id")

        if error.code == 401:
            raise AuthenticationError(message, request_id=request_id)
        elif error.code == 422:
            raise ValidationError(message, request_id=request_id)
        elif error.code == 429:
            retry_after = int(error.headers.get("Retry-After", "60"))
            raise RateLimitError(message, retry_after=retry_after, request_id=request_id)
        else:
            raise EmailProbeError(
                message,
                status=error.code,
                code=error_data.get("code", "UNKNOWN_ERROR"),
                request_id=request_id,
            )


# Optional async client — only available if httpx is installed
try:
    import httpx

    class AsyncEmailProbeClient:
        """Async client for the EmailProbe API. Requires httpx."""

        def __init__(
            self,
            api_key: str,
            base_url: str = DEFAULT_BASE_URL,
            timeout: int = DEFAULT_TIMEOUT,
        ):
            if not api_key:
                raise ValueError("API key is required.")
            self._api_key = api_key
            self._base_url = base_url.rstrip("/")
            self._client = httpx.AsyncClient(
                base_url=self._base_url,
                timeout=timeout,
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Accept": "application/json",
                },
            )

        async def validate(self, email: str) -> Dict[str, Any]:
            return await self._request("POST", "/v1/validate", json={"email": email})

        async def check_domain(self, domain: str) -> Dict[str, Any]:
            return await self._request("GET", f"/v1/domain/{domain}")

        async def usage(self) -> Dict[str, Any]:
            return await self._request("GET", "/v1/usage")

        async def is_disposable(self, domain: str) -> Dict[str, Any]:
            resp = await self._client.get(
                f"/open/v1/disposable/{domain}",
                headers={"Authorization": ""},  # No auth needed
            )
            if resp.status_code != 200:
                self._handle_error(resp)
            return resp.json()

        async def _request(self, method: str, path: str, **kwargs) -> Dict[str, Any]:
            resp = await self._client.request(method, path, **kwargs)
            if resp.status_code != 200:
                self._handle_error(resp)
            return resp.json()

        @staticmethod
        def _handle_error(resp: httpx.Response):
            try:
                data = resp.json()
            except Exception:
                data = {}

            message = data.get("error", f"HTTP {resp.status_code}")
            request_id = data.get("request_id")

            if resp.status_code == 401:
                raise AuthenticationError(message, request_id=request_id)
            elif resp.status_code == 422:
                raise ValidationError(message, request_id=request_id)
            elif resp.status_code == 429:
                retry_after = int(resp.headers.get("Retry-After", "60"))
                raise RateLimitError(message, retry_after=retry_after, request_id=request_id)
            else:
                raise EmailProbeError(message, status=resp.status_code, request_id=request_id)

        async def close(self):
            await self._client.aclose()

        async def __aenter__(self):
            return self

        async def __aexit__(self, *args):
            await self.close()

except ImportError:
    pass
