from ch00_py.db_toolbox import db_table_exists
from ch00_py.file_toolbox import (
    create_path,
    get_dir_filenames,
    get_level1_dirs,
    open_file,
    save_file,
)
from ch02_contact.contact import ContactUnit
from ch04_rope.rope import create_rope, is_sub_rope
from ch05_reason.reason_main import ReasonHeir
from ch06_plan.plan import PlanUnit
from ch07_person_logic.person_main import PersonUnit, get_sorted_plan_list
from ch09_person_lesson._ref.ch09_path import create_moments_dir_path
from ch09_person_lesson.lasso import LassoUnit, lassounit_shop
from ch10_person_listen._ref.ch10_path import create_job_path
from ch10_person_listen.keep_tool import open_job_file
from ch13_time.epoch_main import (
    TimeShoe,
    add_epoch_planunit,
    get_default_epoch_config_dict,
    get_epoch_min_from_dt,
    get_epoch_rope,
    timeshoe_shop,
)
from ch13_time.epoch_reason import set_epoch_fact
from ch14_moment.moment_main import open_moment_file
from ch18_etl_config._ref.ch18_path import create_moment_mstr_path, create_world_db_path
from ch31_kpi._ref.ch31_path import (
    create_day_punch_txt_path,
    create_dst_person_punch_path,
)
from ch31_kpi._ref.ch31_semantic_types import (
    FundNum,
    GroupTitle,
    LabelTerm,
    MomentRope,
    PersonName,
    RopeTerm,
    TimeNum,
)
from ch99_glossary.sorter import get_library_version
from copy import copy as copy_copy, deepcopy as copy_deepcopy
from csv import DictWriter as csv_DictWriter
from dataclasses import dataclass
from datetime import datetime, timedelta
from io import StringIO as io_StringIO
from os.path import exists as os_path_exists
from sqlite3 import connect as sqlite3_connect


def gcal_readable_percent(value: float, precision=2):
    """
    Convert a float into a readable percentage string.
    Handles very small and large values gracefully.
    """
    if value is None:
        return "0% (None)"

    percent = value * 100

    if 0 < abs(percent) < 0.01:
        return f"{percent:.2e}%"

    formatted = f"{percent:.{precision}f}".rstrip("0").rstrip(".")
    return f"{formatted}%"


@dataclass
class PersonTranBookMetric:
    moment_rope: MomentRope = None
    person_name: PersonName = None
    offi_time: TimeNum = None
    last_tran_time: TimeNum = None
    net: FundNum = None
    circulation_total: FundNum = None

    def get_circulation_str(self) -> str:
        if self.circulation_total is None and self.offi_time is None:
            return f"{self.net} funds"
        elif self.offi_time is None:
            return f"{self.net} funds out of {self.circulation_total}"
        return f"{self.net} funds out of {self.circulation_total} at {self.offi_time}"


def persontranbookmetric_shop(
    moment_rope: MomentRope,
    person_name: PersonName,
    offi_time: TimeNum = None,
    last_tran_time: TimeNum = None,
    net: TimeNum = None,
    circulation_total: TimeNum = None,
) -> PersonTranBookMetric:
    return PersonTranBookMetric(
        moment_rope=moment_rope,
        person_name=person_name,
        offi_time=offi_time,
        last_tran_time=last_tran_time,
        net=net,
        circulation_total=circulation_total,
    )


@dataclass
class DayEvent:
    plan: PlanUnit = None
    item_rank: int = None
    day_min_lower: int = None
    day_min_upper: int = None
    clock_lower: str = None  # TimeShoe.clock() for day_min_lower
    clock_upper: str = None  # TimeShoe.clock() for day_min_upper


def planunit_is_scheduled_in_day(reasonheir: ReasonHeir, epoch_rope) -> bool:
    case = reasonheir.get_case(reasonheir.reason_context)
    divisor_remainder = case.reason_divisor % 1440
    return bool(
        is_sub_rope(reasonheir.reason_context, epoch_rope) and divisor_remainder == 0
    )


def set_day_epoch_fact(person: PersonUnit, epoch_label: LabelTerm, day: datetime):
    epoch_min_lower = get_epoch_min_from_dt(person, epoch_label, day)
    next_day = day + timedelta(days=1)
    epoch_min_upper = get_epoch_min_from_dt(person, epoch_label, next_day)
    set_epoch_fact(person, epoch_label, epoch_min_lower, epoch_min_upper)


def get_dayevents(
    person: PersonUnit, epoch_label: LabelTerm, day: datetime
) -> list[DayEvent]:
    set_day_epoch_fact(person, epoch_label, day)

    moment_rope = person.planroot.get_plan_rope()
    epoch_rope = get_epoch_rope(moment_rope, epoch_label, person.knot)
    agenda_plans_dict = person.get_agenda_dict()
    agenda_list = get_sorted_plan_list(agenda_plans_dict, "fund_ratio")
    dayevents = []
    for item_rank, agenda_item in enumerate(agenda_list, start=1):
        for reason_context, reasonheir in agenda_item.reasonheirs.items():
            if planunit_is_scheduled_in_day(reasonheir, epoch_rope):
                if epoch_reasonheir := agenda_item.get_reasonheir(reason_context):
                    add_dayevent(
                        person=person,
                        epoch_reasonheir=epoch_reasonheir,
                        reason_context=reason_context,
                        epoch_label=epoch_label,
                        day=day,
                        agenda_item=agenda_item,
                        item_rank=item_rank,
                        dayevents=dayevents,
                    )
    return dayevents


def add_dayevent(
    person: PersonUnit,
    epoch_reasonheir: ReasonHeir,
    reason_context: RopeTerm,
    epoch_label: LabelTerm,
    day: datetime,
    agenda_item: PlanUnit,
    item_rank: int,
    dayevents: list[DayEvent],
):
    epoch_case = epoch_reasonheir.get_case(reason_context)
    day_reason_lower = epoch_case.reason_lower % 1440
    day_reason_upper = epoch_case.reason_upper % 1440
    midnight_epoch_min = get_epoch_min_from_dt(person, epoch_label, day)
    epoch_min_lower = midnight_epoch_min + day_reason_lower
    epoch_min_upper = midnight_epoch_min + day_reason_upper
    lower_shoe = timeshoe_shop(person, epoch_label, epoch_min_lower)
    upper_shoe = timeshoe_shop(person, epoch_label, epoch_min_upper)
    x_dayevent = DayEvent(
        agenda_item,
        item_rank,
        day_min_lower=day_reason_lower,
        day_min_upper=day_reason_upper,
        clock_lower=lower_shoe.clock(),
        clock_upper=upper_shoe.clock(),
    )
    dayevents.append(x_dayevent)


def get_inflection_points_dict(dayevents: list[DayEvent]) -> dict[int, DayEvent | None]:
    """
    Returns a dict[day_minute, DayEvent] representing inflection day_minutes where the
    "most important active event" changes.

    An inflection point occurs when:
    - A more important event starts while another is ongoing
    - The current top event ends and a different one takes over (or nothing)
    - A gap exists between events (represented as day_minute: None)
    """
    # Collect all relevant timestamps
    timestamps = sorted(
        {t for event in dayevents for t in (event.day_min_lower, event.day_min_upper)}
    )

    inflection_points = {}
    last_top_dayevent = None

    for t in timestamps:
        active = [e for e in dayevents if e.day_min_lower <= t < e.day_min_upper]
        top_dayevent = max(active, key=lambda e: e.plan.fund_ratio) if active else None

        if top_dayevent != last_top_dayevent:
            inflection_points[t] = top_dayevent
            last_top_dayevent = top_dayevent

    return inflection_points


def minute_to_clock_time(minute: int, midnight_shoe: TimeShoe) -> str:
    local_shoe = copy_copy(midnight_shoe)
    local_shoe.calc_epoch(local_shoe.epoch_min + minute)
    return local_shoe.clock()


def get_gcal_priorities_schedule_str(dayevents: list[DayEvent]) -> str:
    inflections_dict = get_inflection_points_dict(dayevents)
    x_str = "Schedule Priorities"
    for inflection_minute in sorted(list(inflections_dict.keys())):
        if dayevent := inflections_dict.get(inflection_minute):
            precent_str = gcal_readable_percent(dayevent.plan.fund_ratio)
            x_str += f"\n{dayevent.clock_lower} {dayevent.item_rank}. {dayevent.plan.plan_label} {precent_str}"
            previous_dayevent = dayevent
        elif previous_dayevent:
            x_str += f"\n{previous_dayevent.clock_upper} Nothing scheduled."
    return x_str


def get_gcal_all_agenda_str(
    x_person: PersonUnit, epoch_label: LabelTerm, day: datetime
) -> str:
    day = day.replace(hour=0, minute=0, second=0, microsecond=0)
    epoch_min = get_epoch_min_from_dt(x_person, epoch_label, day)
    midnight_shoe = timeshoe_shop(x_person, epoch_label, epoch_min)
    set_day_epoch_fact(x_person, epoch_label, day)

    agenda_plans_dict = x_person.get_agenda_dict()
    agenda_list = get_sorted_plan_list(agenda_plans_dict, "fund_ratio")
    moment_rope = x_person.planroot.get_plan_rope()
    epoch_rope = get_epoch_rope(moment_rope, epoch_label, x_person.knot)
    gcal_agenda_list_str = "All Agenda Items"
    for item_rank, agenda_item in enumerate(agenda_list, start=1):
        item_fund_ratio_str = gcal_readable_percent(agenda_item.fund_ratio)
        event_subject = f"{item_rank}. {agenda_item.plan_label} ({item_fund_ratio_str})"

        for reason_context, reasonheir in agenda_item.reasonheirs.items():
            if planunit_is_scheduled_in_day(reasonheir, epoch_rope):
                epoch_reasonheir = agenda_item.get_reasonheir(reason_context)
                epoch_case = epoch_reasonheir.get_case(reason_context)
                day_reason_lower = epoch_case.reason_lower % 1440
                day_reason_upper = epoch_case.reason_upper % 1440
                clock_lower = minute_to_clock_time(day_reason_lower, midnight_shoe)
                clock_upper = minute_to_clock_time(day_reason_upper, midnight_shoe)
                clock_range = f" {clock_lower}-{clock_upper}"
                event_subject += clock_range
        gcal_agenda_list_str += f"\n{event_subject}"
    return gcal_agenda_list_str


def get_gcal_contacts_str(x_person: PersonUnit) -> str:
    x_str = "Person Contacts"
    contacts_list = list(x_person.contacts.values())
    return create_contacts_only_list_str(contacts_list, x_str)


def create_contacts_only_list_str(contacts_list: list[ContactUnit], x_str: str) -> str:
    contacts_list.sort(
        key=lambda pu: (
            -pu.fund_agenda_ratio_give - pu.fund_agenda_ratio_take,
            pu.contact_name,
        )
    )

    for contact in contacts_list:
        give_left = contact.fund_agenda_ratio_give - contact.fund_agenda_ratio_take
        agenda_relative_give = f" ({gcal_readable_percent(give_left)})"
        agenda_ratio_give = gcal_readable_percent(contact.fund_agenda_ratio_give)
        agenda_ratio_take = gcal_readable_percent(contact.fund_agenda_ratio_take)
        agenda_ratios_str = f"give: {agenda_ratio_give}, take: {agenda_ratio_take}"
        if agenda_relative_give == " (0%)":
            agenda_relative_give = " (even give/take)"
        x_str += (
            f"\n{contact.contact_name:10} {agenda_ratios_str} {agenda_relative_give}"
        )
    return x_str


def get_gcal_memberships_str(x_person: PersonUnit, group_title: GroupTitle) -> str:
    x_str = f"{group_title} Group"
    groupunit = x_person.get_groupunit(group_title)
    group_contact_names = []
    if not groupunit or len(groupunit.memberships) == 0:
        x_str += "\nNo memberships"
    else:
        group_contact_names.extend(iter(groupunit.memberships.keys()))
    contacts_list = []
    contacts_list.extend(
        x_person.get_contact(group_contact_name)
        for group_contact_name in group_contact_names
    )
    return create_contacts_only_list_str(contacts_list, x_str)


def get_gcal_day_punch_from_personunit(
    x_person: PersonUnit,
    day: datetime,
    epoch_label: LabelTerm = None,
    group_title: GroupTitle = None,
    persontranbookmetric: PersonTranBookMetric = None,
) -> str:
    """parameter x_person is assumed to have already thinkouted."""
    moment_rope = x_person.planroot.get_plan_rope()
    if not epoch_label:
        epoch_label = get_default_epoch_config_dict().get("epoch_label")
    epoch_min = get_epoch_min_from_dt(x_person, epoch_label, day)
    timeshoe = timeshoe_shop(x_person, epoch_label, epoch_min)
    x_str = f"{timeshoe.get_long_date_blurb()} Agenda for {x_person.person_name} in the '{moment_rope}' Moment\n"
    if persontranbookmetric:
        x_str += f"\n{persontranbookmetric.get_circulation_str()}"

    x_dayevents = get_dayevents(x_person, epoch_label, day)
    x_str += f"\n{get_gcal_priorities_schedule_str(x_dayevents)}"
    x_str += f"\n{get_gcal_all_agenda_str(x_person, epoch_label, day)}"
    x_str += f"\n\n{get_gcal_contacts_str(x_person)}"
    if group_title:
        x_str += f"\n{get_gcal_memberships_str(x_person, group_title)}"
    x_str += f"\n\nkeg version: {get_library_version()}"

    return x_str


def create_gcalendar_events_list(x_person: PersonUnit, day: datetime) -> list[dict]:
    x_person = copy_deepcopy(x_person)
    default_epoch_config = get_default_epoch_config_dict()
    epoch_label = default_epoch_config.get("epoch_label")
    gcal_agenda_list_str = ""
    day_events = []
    dayevent_objs = get_dayevents(x_person, epoch_label, day)
    for dayevent_obj in dayevent_objs:
        item_fund_ratio_str = gcal_readable_percent(dayevent_obj.plan.fund_ratio)
        event_subject = f"{dayevent_obj.item_rank}. {dayevent_obj.plan.plan_label} ({item_fund_ratio_str})"
        start_date = day + timedelta(minutes=dayevent_obj.day_min_lower)
        end_date = day + timedelta(minutes=dayevent_obj.day_min_upper)
        event_dict = {
            "Subject": event_subject,
            "Start Date": start_date.strftime("%m/%d/%Y"),
            "Start Time": start_date.strftime("%I:%M %p"),
            "End Date": end_date.strftime("%m/%d/%Y"),
            "End Time": end_date.strftime("%I:%M %p"),
            "All Day Event": "False",
            "Description": dayevent_obj.plan.get_plan_rope(),
        }
        day_events.append(event_dict)
    gcal_agenda_list_str = get_gcal_all_agenda_str(x_person, epoch_label, day)
    all_day_events = {
        "Subject": "Pledges",
        "Start Date": day.strftime("%m/%d/%Y"),
        "End Date": day.strftime("%m/%d/%Y"),
        "All Day Event": "True",
        "Description": gcal_agenda_list_str,
    }
    if x_person.get_agenda_dict() != {}:
        day_events.append(all_day_events)
    return day_events


def create_gcalendar_csv_from_list(events: list[dict]) -> str:
    """Create a Google Calendar-compatible CSV file."""
    fieldnames = [
        "Subject",
        "Start Date",
        "Start Time",
        "End Date",
        "End Time",
        "All Day Event",
        "Description",
    ]

    # Use StringIO to build in memory
    output = io_StringIO()
    writer = csv_DictWriter(output, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(events)

    return output.getvalue()


def create_gcalendar_csv_from_person(x_person: PersonUnit, day: datetime = None) -> str:
    if day is None:
        day = datetime.combine(datetime.now().date(), datetime.min.time())
    events_list = create_gcalendar_events_list(x_person, day)
    return create_gcalendar_csv_from_list(events_list)


def get_gcal_day_punch_from_job_file(
    moment_mstr_dir: str,
    moment_lasso: LassoUnit,
    person_name: PersonName,
    day: datetime,
    focus_group_title: GroupTitle = None,
    persontranbookmetric: PersonTranBookMetric = None,
) -> str:
    momentunit = open_moment_file(moment_mstr_dir, moment_lasso)
    epoch_label = momentunit.epoch.epoch_label
    job = open_job_file(moment_mstr_dir, moment_lasso, person_name)
    epoch_rope = get_epoch_rope(momentunit.moment_rope, epoch_label, momentunit.knot)
    if not job.plan_exists(epoch_rope):
        add_epoch_planunit(job, momentunit.get_epoch_config())
    return get_gcal_day_punch_from_personunit(
        x_person=job,
        day=day,
        epoch_label=epoch_label,
        group_title=focus_group_title,
        persontranbookmetric=persontranbookmetric,
    )


def add_gcal_day_punch_to_dict(
    day_punchs: dict,
    moment_mstr_dir: str,
    moment_lasso: LassoUnit,
    person_name: PersonName,
    day: datetime,
    focus_group_title: GroupTitle,
    persontranbookmetric: PersonTranBookMetric = None,
):
    mmt_job_path = create_job_path(moment_mstr_dir, moment_lasso, person_name)
    if os_path_exists(mmt_job_path):
        day_punch_str = get_gcal_day_punch_from_job_file(
            moment_mstr_dir,
            moment_lasso,
            person_name,
            day,
            focus_group_title,
            persontranbookmetric,
        )
        report_path = create_day_punch_txt_path(
            moment_mstr_dir, moment_lasso, person_name
        )
        day_punchs[moment_lasso.moment_rope] = {
            "day_punch": day_punch_str,
            "file_path": report_path,
        }


def get_persontranbookmetrics(
    world_dir,
) -> dict[tuple[MomentRope, PersonName], PersonTranBookMetric]:
    # sourcery skip: extract-method
    world_db_path = create_world_db_path(world_dir)
    persontranbookmetrics = {}
    if os_path_exists(world_db_path):
        with sqlite3_connect(world_db_path) as conn:
            if db_table_exists(conn, "moment_tranbook_nets"):
                select_sql = "SELECT moment_rope, person_name, person_net_amount FROM moment_tranbook_nets;"
                cursor = conn.cursor()
                cursor.execute(select_sql)
                rows = cursor.fetchall()
                moment_circulation_total = sum(row[2] for row in rows)
                for row in rows:
                    row_moment_rope = row[0]
                    row_person_name = row[1]
                    persontranbookmetric = persontranbookmetric_shop(
                        moment_rope=row_moment_rope,
                        person_name=row_person_name,
                        net=row[2],
                        circulation_total=moment_circulation_total,
                    )
                    moment_person_tuple = (row_moment_rope, row_person_name)
                    persontranbookmetrics[moment_person_tuple] = persontranbookmetric
    return persontranbookmetrics


def get_person_gcal_day_punchs(
    world_dir: str,
    person_name: PersonName,
    day: datetime,
    focus_group_title: GroupTitle = None,
) -> dict[PersonName, dict[str, str]]:
    persontranbookmetrics = get_persontranbookmetrics(world_dir)
    day_punchs = {}
    moment_mstr_dir = create_moment_mstr_path(world_dir)
    moments_dir = create_moments_dir_path(moment_mstr_dir)
    for moment_label in get_level1_dirs(moments_dir):
        moment_lasso = lassounit_shop(create_rope(moment_label))
        moment_path = create_path(moments_dir, moment_lasso.make_path())
        persons_path = create_path(moment_path, "persons")
        for dir_person in get_level1_dirs(persons_path):
            if dir_person == person_name:
                moment_person_tuple = (moment_lasso.moment_rope, person_name)
                persontranbookmetric = persontranbookmetrics.get(moment_person_tuple)
                add_gcal_day_punch_to_dict(
                    day_punchs,
                    moment_mstr_dir,
                    moment_lasso,
                    person_name,
                    day,
                    focus_group_title,
                    persontranbookmetric,
                )
    return day_punchs


def lego_to_person_gcal_day_punchs(
    world_dir: str,
    person_name: PersonName,
    day: datetime,
    focus_group_title: GroupTitle = None,
):
    day_punchs = get_person_gcal_day_punchs(
        world_dir, person_name, day, focus_group_title
    )
    for person_name, report_dict in day_punchs.items():
        file_path = report_dict.get("file_path")
        day_punch = report_dict.get("day_punch")
        save_file(file_path, None, day_punch)


def copy_person_day_punches_to_dst_dir(
    moment_mstr_dir: str, dst_dir: str, person_name: PersonName
) -> set[str]:
    dst_person_punch_paths = {}
    moments_dir = create_moments_dir_path(moment_mstr_dir)
    for moment_label in get_level1_dirs(moments_dir):
        moment_lasso = lassounit_shop(create_rope(moment_label))
        moment_path = create_path(moments_dir, moment_lasso.make_path())
        day_punchs_path = create_path(moment_path, "day_punchs")

        for sub_dir, person_filename in get_dir_filenames(day_punchs_path):
            if person_filename == f"{person_name}.txt":
                dst_person_punch_path = create_dst_person_punch_path(
                    dst_dir, moment_lasso, person_name
                )
                day_punch_file_path = create_path(day_punchs_path, person_filename)
                save_file(dst_person_punch_path, None, open_file(day_punch_file_path))
                if dst_person_punch_paths.get(moment_lasso.moment_rope) is None:
                    dst_person_punch_paths[moment_lasso.moment_rope] = set()
                paths_set = dst_person_punch_paths.get(moment_lasso.moment_rope)
                paths_set.add(dst_person_punch_path)
    return dst_person_punch_paths


def get_day_punchs_persons(moment_mstr_dir: str) -> set[str]:
    """Get all person names that have day punch files in the moment master directory."""
    available_persons = set()
    moments_dir = create_moments_dir_path(moment_mstr_dir)
    for moment_label in get_level1_dirs(moments_dir):
        moment_lasso = lassounit_shop(create_rope(moment_label))
        moment_path = create_path(moments_dir, moment_lasso.make_path())
        day_punchs_path = create_path(moment_path, "day_punchs")

        for sub_dir, person_filename in get_dir_filenames(day_punchs_path):
            if person_filename.endswith(".txt"):
                person_name = person_filename.replace(".txt", "")
                available_persons.add(person_name)
    return available_persons
