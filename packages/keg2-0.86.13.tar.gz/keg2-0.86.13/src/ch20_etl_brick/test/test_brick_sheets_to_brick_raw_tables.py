from ch00_py.db_toolbox import db_table_exists, get_row_count, get_table_columns
from ch00_py.file_toolbox import create_path
from ch17_brick.brick_db_tool import save_sheet
from ch20_etl_brick.etl_brick_main import etl_brick_dfs_to_brixk_raw_tables
from ch99_glossary.ch_keyword import Ch20Keywords as kw, ExampleStrs as exx
from pandas import NA as pandas_NA, DataFrame
from sqlite3 import Cursor


def test_etl_brick_dfs_to_brixk_raw_tables_PopulatesTables_Scenario0(
    temp3_fs, cursor0: Cursor
):
    # ESTABLISH
    spark1 = 1
    spark2 = 2
    spark3 = 3
    minute_360 = 360
    minute_420 = 420
    hour6am = "6am"
    hour7am = "7am"
    ex_filename = "Faybob.xlsx"
    b_src_dir = create_path(str(temp3_fs), kw.b_src)
    b_src_file_path = create_path(b_src_dir, ex_filename)
    bk3_columns = [
        kw.spark_num,
        kw.spark_face,
        kw.cumulative_minute,
        kw.moment_rope,
        kw.hour_label,
        kw.knot,
    ]
    row0 = [spark1, exx.sue, minute_360, exx.a23_dash, hour6am, exx.dash]
    row1 = [spark1, exx.sue, minute_420, exx.a23_dash, hour7am, exx.dash]
    row2 = [spark2, exx.sue, minute_420, exx.a23_dash, hour7am, exx.dash]
    row3 = [spark3, exx.sue, "num55", exx.a23_dash, hour7am, exx.dash]
    row4 = ["spark3", exx.sue, "num55", exx.a23_dash, hour7am, exx.dash]

    df1 = DataFrame([row0, row1, row2, row3, row4], columns=bk3_columns)
    bk00103_ex1_str = "example1_bk00103"
    save_sheet(b_src_file_path, bk00103_ex1_str, df1)
    bk00103_tablename = f"bk00103_{kw.b_raw}"
    assert not db_table_exists(cursor0, bk00103_tablename)

    # WHEN
    etl_brick_dfs_to_brixk_raw_tables(cursor0, b_src_dir)

    # THEN
    assert db_table_exists(cursor0, bk00103_tablename)
    bk00103_table_cols = get_table_columns(cursor0, bk00103_tablename)
    file_dir_str = "file_dir"
    filename_str = "filename"
    sheet_name_str = "sheet_name"
    assert file_dir_str == bk00103_table_cols[0]
    assert filename_str == bk00103_table_cols[1]
    assert sheet_name_str == bk00103_table_cols[2]
    assert kw.error_message == bk00103_table_cols[-1]
    assert get_row_count(cursor0, bk00103_tablename) == 5
    select_agg_sqlstr = f"""
SELECT * 
FROM {bk00103_tablename} 
ORDER BY sheet_name, {kw.spark_num}, {kw.cumulative_minute};"""
    cursor0.execute(select_agg_sqlstr)

    rows = cursor0.fetchall()
    assert len(rows) == 5
    file = ex_filename
    e1 = spark1
    e2 = spark2
    e3 = spark3
    s_dir = create_path(b_src_dir, ".")
    m_360 = minute_360
    m_420 = minute_420
    bk3_str = bk00103_ex1_str
    err4 = f"Conversion errors: {kw.cumulative_minute}: num55"
    err0 = f"Conversion errors: {kw.spark_num}: spark3, {kw.cumulative_minute}: num55"
    row0 = (s_dir, file, bk3_str, None, exx.sue, exx.a23_dash, None, hour7am, "-", err0)
    row1 = (s_dir, file, bk3_str, e1, exx.sue, exx.a23_dash, m_360, hour6am, "-", None)
    row2 = (s_dir, file, bk3_str, e1, exx.sue, exx.a23_dash, m_420, hour7am, "-", None)
    row3 = (s_dir, file, bk3_str, e2, exx.sue, exx.a23_dash, m_420, hour7am, "-", None)
    row4 = (s_dir, file, bk3_str, e3, exx.sue, exx.a23_dash, None, hour7am, "-", err4)
    print(f"{rows[1]=}")
    print(f"   {row1=}")
    assert rows[0] == row0
    assert rows[1] == row1
    assert rows[2] == row2
    assert rows[3] == row3
    assert rows[4] == row4


def test_etl_brick_dfs_to_brixk_raw_tables_PopulatesTables_Scenario1(
    temp3_fs, cursor0: Cursor
):
    # ESTABLISH
    spark1 = 1
    spark2 = 2
    minute_360 = 360
    minute_420 = 420
    hour6am = "6am"
    hour7am = "7am"
    ex_filename = "Faybob.xlsx"
    b_src_dir = create_path(str(temp3_fs), kw.b_src)
    b_src_file_path = create_path(b_src_dir, ex_filename)
    brick_columns = [
        kw.spark_num,
        kw.spark_face,
        kw.cumulative_minute,
        kw.moment_rope,
        kw.hour_label,
        kw.knot,
    ]
    row1 = [spark1, exx.sue, minute_360, exx.a23_dash, hour6am, exx.dash]
    row2 = [spark1, exx.sue, minute_420, exx.a23_dash, hour7am, exx.dash]
    row3 = [spark2, exx.sue, minute_420, exx.a23_dash, hour7am, exx.dash]
    incomplete_brick_columns = [
        kw.spark_num,
        kw.spark_face,
        kw.cumulative_minute,
        kw.moment_rope,
        kw.knot,
    ]
    incom_row1 = [spark1, exx.sue, minute_360, exx.a23_dash, exx.dash]
    incom_row2 = [spark1, exx.sue, minute_420, exx.a23_dash, exx.dash]

    df1 = DataFrame([row1, row2], columns=brick_columns)
    df2 = DataFrame([incom_row1, incom_row2], columns=incomplete_brick_columns)
    df3 = DataFrame([row2, row1, row3], columns=brick_columns)
    bk00103_ex1_str = "example1_bk00103"
    bk00103_ex2_str = "example2_bk00103"
    bk00103_ex3_str = "example3_bk00103"
    save_sheet(b_src_file_path, bk00103_ex1_str, df1)
    save_sheet(b_src_file_path, bk00103_ex2_str, df2)
    save_sheet(b_src_file_path, bk00103_ex3_str, df3)
    bk00103_tablename = f"bk00103_{kw.b_raw}"
    assert not db_table_exists(cursor0, bk00103_tablename)

    # WHEN
    etl_brick_dfs_to_brixk_raw_tables(cursor0, b_src_dir)

    # THEN
    assert db_table_exists(cursor0, bk00103_tablename)
    assert get_row_count(cursor0, bk00103_tablename) == 5
    bk00103_table_cols = get_table_columns(cursor0, bk00103_tablename)
    file_dir_str = "file_dir"
    filename_str = "filename"
    sheet_name_str = "sheet_name"
    assert file_dir_str == bk00103_table_cols[0]
    assert filename_str == bk00103_table_cols[1]
    assert sheet_name_str == bk00103_table_cols[2]
    assert kw.error_message == bk00103_table_cols[-1]
    select_agg_sqlstr = f"""
SELECT * 
FROM {bk00103_tablename} 
ORDER BY sheet_name, {kw.spark_num}, {kw.cumulative_minute};"""
    cursor0.execute(select_agg_sqlstr)

    rows = cursor0.fetchall()
    assert len(rows) == 5
    file = ex_filename
    e1 = spark1
    e2 = spark2
    s_dir = create_path(b_src_dir, ".")
    m_360 = minute_360
    m_420 = minute_420
    b1_str = bk00103_ex1_str
    b3_str = bk00103_ex3_str
    row0 = (s_dir, file, b1_str, e1, exx.sue, exx.a23_dash, m_360, hour6am, "-", None)
    row1 = (s_dir, file, b1_str, e1, exx.sue, exx.a23_dash, m_420, hour7am, "-", None)
    row2 = (s_dir, file, b3_str, e1, exx.sue, exx.a23_dash, m_360, hour6am, "-", None)
    row3 = (s_dir, file, b3_str, e1, exx.sue, exx.a23_dash, m_420, hour7am, "-", None)
    row4 = (s_dir, file, b3_str, e2, exx.sue, exx.a23_dash, m_420, hour7am, "-", None)
    print(f"{rows[0]=}")
    print(f"   {row0=}")
    assert rows[0] == row0
    assert rows[1] == row1
    assert rows[2] == row2
    assert rows[3] == row3
    assert rows[4] == row4


def test_etl_brick_dfs_to_brixk_raw_tables_PopulatesTables_Scenario2_NanValuesConvertToNull(
    temp3_fs, cursor0: Cursor
):
    # ESTABLISH
    spark1 = 1
    spark2 = 2
    spark3 = 3
    minute_360 = 360
    minute_420 = 420
    hour6am = "6am"
    hour7am = "7am"
    ex_filename = "Faybob.xlsx"
    b_src_dir = create_path(str(temp3_fs), kw.b_src)
    b_src_file_path = create_path(b_src_dir, ex_filename)
    bk3_columns = [
        kw.spark_num,
        kw.spark_face,
        kw.cumulative_minute,
        kw.moment_rope,
        kw.hour_label,
        kw.knot,
    ]
    row0 = [spark1, exx.sue, minute_360, exx.a23_dash, hour6am, exx.dash]
    row1 = [spark1, exx.sue, minute_420, exx.a23_dash, hour7am, exx.dash]
    row2 = [spark2, exx.sue, minute_420, exx.a23_dash, pandas_NA, exx.dash]
    df1 = DataFrame([row0, row1, row2], columns=bk3_columns)
    bk00103_ex1_str = "example1_bk00103"
    save_sheet(b_src_file_path, bk00103_ex1_str, df1)
    bk00103_tablename = f"bk00103_{kw.b_raw}"
    assert not db_table_exists(cursor0, bk00103_tablename)

    # WHEN
    etl_brick_dfs_to_brixk_raw_tables(cursor0, b_src_dir)

    # THEN
    assert db_table_exists(cursor0, bk00103_tablename)
    bk00103_table_cols = get_table_columns(cursor0, bk00103_tablename)
    assert kw.error_message == bk00103_table_cols[-1]
    assert get_row_count(cursor0, bk00103_tablename) == 3
    select_agg_sqlstr = f"""
SELECT * 
FROM {bk00103_tablename} 
ORDER BY sheet_name, {kw.spark_num}, {kw.cumulative_minute};"""
    cursor0.execute(select_agg_sqlstr)

    rows = cursor0.fetchall()
    assert len(rows) == 3
    file = ex_filename
    e1 = spark1
    e2 = spark2
    e3 = spark3
    s_dir = create_path(b_src_dir, ".")
    m_360 = minute_360
    m_420 = minute_420
    bk3_str = bk00103_ex1_str
    e_r0 = (s_dir, file, bk3_str, e1, exx.sue, exx.a23_dash, m_360, hour6am, "-", None)
    e_r1 = (s_dir, file, bk3_str, e1, exx.sue, exx.a23_dash, m_420, hour7am, "-", None)
    e_r2 = (s_dir, file, bk3_str, e2, exx.sue, exx.a23_dash, m_420, None, "-", None)
    print(f"{rows[0]=}")
    print(f"   {row0=}")
    assert rows[0] == e_r0
    assert rows[1] == e_r1
    assert rows[2] == e_r2


def test_etl_brick_dfs_to_brixk_raw_tables_PopulatesTables_Scenario3_DeletesTableBeforeLoad(
    temp3_fs, cursor0: Cursor
):
    # ESTABLISH
    spark1 = 1
    spark2 = 2
    spark3 = 3
    minute_360 = 360
    minute_420 = 420
    hour6am = "6am"
    hour7am = "7am"
    ex_filename = "Faybob.xlsx"
    b_src_dir = create_path(str(temp3_fs), kw.b_src)
    b_src_file_path = create_path(b_src_dir, ex_filename)
    bk3_columns = [
        kw.spark_num,
        kw.spark_face,
        kw.cumulative_minute,
        kw.moment_rope,
        kw.hour_label,
        kw.knot,
    ]
    row0 = [spark1, exx.sue, minute_360, exx.a23_dash, hour6am, exx.dash]
    row1 = [spark1, exx.sue, minute_420, exx.a23_dash, hour7am, exx.dash]
    row2 = [spark2, exx.sue, minute_420, exx.a23_dash, hour7am, exx.dash]
    row3 = [spark3, exx.sue, "num55", exx.a23_dash, hour7am, exx.dash]
    row4 = ["spark3", exx.sue, "num55", exx.a23_dash, hour7am, exx.dash]

    df1 = DataFrame([row0, row1, row2, row3, row4], columns=bk3_columns)
    bk00103_ex1_str = "example1_bk00103"
    save_sheet(b_src_file_path, bk00103_ex1_str, df1)
    bk00103_tablename = f"bk00103_{kw.b_raw}"
    assert not db_table_exists(cursor0, bk00103_tablename)
    etl_brick_dfs_to_brixk_raw_tables(cursor0, b_src_dir)
    assert get_row_count(cursor0, bk00103_tablename) == 5
    # WHEN
    etl_brick_dfs_to_brixk_raw_tables(cursor0, b_src_dir)
    # THEN
    assert get_row_count(cursor0, bk00103_tablename) == 5


def test_etl_brick_dfs_to_brixk_raw_tables_Excel_TRUE_FALSE_ConvertedToText(
    temp3_fs, cursor0: Cursor
):
    # ESTABLISH an Excel sheet containing formula-like boolean cells
    x_file = "Faybob.xlsx"
    b_dir = create_path(str(temp3_fs), kw.b_src)
    b_src_file_path = create_path(b_dir, x_file)
    min320, min420 = 320, 420

    columns = [
        kw.spark_num,
        kw.spark_face,
        kw.cumulative_minute,
        kw.moment_rope,
        kw.hour_label,
        kw.knot,
    ]
    bk_row0 = [7, exx.sue, min320, exx.a23_dash, "=TRUE()", exx.dash]
    bk_row1 = [9, exx.sue, min420, exx.a23_dash, "=FALSE()", exx.dash]
    df = DataFrame([bk_row0, bk_row1], columns=columns)
    bk3_str = "bk00103"
    save_sheet(b_src_file_path, "sheet1_bk00103", df)

    table_name = f"bk00103_{kw.b_raw}"
    assert not db_table_exists(cursor0, table_name)

    # WHEN
    etl_brick_dfs_to_brixk_raw_tables(cursor0, b_dir)

    # THEN
    cursor0.execute(f"SELECT * FROM {table_name} ORDER BY spark_num;")
    rows = cursor0.fetchall()
    assert len(rows) == 2
    for row in rows:
        print(f"{row=}")
    # expected_rows = {
    #     (b_dir, x_file, bk3_str, 7, exx.sue, min320, exx.a23_dash, 1, exx.dash),
    #     (b_dir, x_file, bk3_str, 9, exx.sue, min420, exx.a23_dash, 0, exx.dash),
    # }

    assert '1' in rows[0]
    assert '0' in rows[1]
    # assert set(rows) == expected_rows
