# splattools

A collection of utility tools for working with Gaussian Splatting PLY files.

## Features

- **info**: Get basic information about a Gaussian Splatting PLY file (vertex count, properties).
- **remove-sh**: Remove spherical harmonics coefficients from a PLY file, leaving only the DC components (colors). This significantly reduces file size while maintaining basic appearance.

## Usage

After installation, the `splattools` command will be available.

### Get PLY Info

```bash
splattools info path/to/model.ply
```

Output:
```text
Vertex count: 123456
Properties: x, y, z, opacity, f_dc_0, f_dc_1, f_dc_2, f_rest_0, ..., scale_0, ..., rot_0, ...
```

### Remove Spherical Harmonics

```bash
splattools remove-sh input.ply output.ply
```

This command extracts only the essential properties (`x, y, z, opacity, f_dc_0, f_dc_1, f_dc_2, scale_0, scale_1, scale_2, rot_0, rot_1, rot_2, rot_3`) and saves them to a new file.

## License

MIT
