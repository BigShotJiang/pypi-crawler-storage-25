from dataclasses import dataclass
from pathlib import Path

from numpy.lib.recfunctions import repack_fields
from plyfile import PlyData, PlyElement, PlyHeaderParseError


@dataclass
class PlyInfo:
    vertex_count: int
    properties: list[str]


expected_properties = (
    ["x", "y", "z", "opacity"]
    + [f"f_dc_{i}" for i in range(3)]
    + [f"scale_{i}" for i in range(3)]
    + [f"rot_{i}" for i in range(4)]
)


def check_header(path: Path) -> PlyData:
    with open(path, "rb") as f:
        try:
            ply_header = PlyData._parse_header(f)
        except PlyHeaderParseError:
            raise ValueError("Failed to parse PLY file")

    try:
        vertex_element: PlyElement = ply_header["vertex"]
    except KeyError:
        raise ValueError("Vertex element not found in PLY file")

    for prop_name in expected_properties:
        try:
            vertex_element.ply_property(prop_name)
        except KeyError:
            raise ValueError(f"Property '{prop_name}' not found in PLY file")

    return ply_header


def info(path: Path) -> PlyInfo:
    """
    Get basic information about the PLY file.
    """
    ply_header = check_header(path)

    vertex_element = ply_header["vertex"]
    return PlyInfo(
        vertex_count=vertex_element.count,
        properties=[prop.name for prop in vertex_element.properties],
    )


def remove_sh(input_path: Path, output_path: Path) -> None:
    """
    Remove spherical harmonics from the input file and save the result to the output path.
    """
    check_header(input_path)
    orig_plydata = PlyData.read(input_path)

    new_vertex_data = orig_plydata["vertex"].data[expected_properties]
    new_vertex_data = repack_fields(new_vertex_data)

    new_element = PlyElement.describe(new_vertex_data, "vertex")
    PlyData(
        [new_element], text=orig_plydata.text, byte_order=orig_plydata.byte_order
    ).write(output_path)
