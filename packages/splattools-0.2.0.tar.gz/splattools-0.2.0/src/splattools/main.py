import argparse
from pathlib import Path

from splattools.ply import info, remove_sh


def main() -> None:
    parser = argparse.ArgumentParser(description="Gaussian splattings tools")
    subparsers = parser.add_subparsers(dest="command", help="Available subcommands")

    # Subcommand: info
    parser_info = subparsers.add_parser(
        "info", help="Get basic information about a PLY file"
    )
    parser_info.add_argument("path", type=Path, help="Path to the PLY file")

    # Subcommand: remove-sh
    parser_remove_sh = subparsers.add_parser(
        "remove-sh", help="Remove spherical harmonics"
    )
    parser_remove_sh.add_argument(
        "input_path", type=Path, help="Path to the input PLY file"
    )
    parser_remove_sh.add_argument(
        "output_path", type=Path, help="Path to the output PLY file"
    )

    args = parser.parse_args()

    if args.command == "info":
        ply_info = info(args.path)
        print(f"Vertex count: {ply_info.vertex_count}")
        print(f"Properties: {', '.join(ply_info.properties)}")
    elif args.command == "remove-sh":
        remove_sh(args.input_path, args.output_path)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
