"""Helpers for extracting one structured JSON object from LLM-style output."""

from __future__ import annotations

import json


def extract_json_object(raw_output: str, *, required_keys: set[str]) -> dict[str, object]:
    """Return the first JSON object containing the required keys.

    The OpenCode CLI may return plain JSON, JSON inside markdown fences, or surrounding prose.
    This helper scans the raw output and extracts the first object that matches the expected
    contract shape.
    """

    decoder = json.JSONDecoder()

    def _matches(candidate: object) -> dict[str, object] | None:
        if not isinstance(candidate, dict):
            return None
        if not required_keys.issubset(candidate.keys()):
            return None
        return candidate

    stripped = raw_output.strip()
    if stripped:
        try:
            direct = json.loads(stripped)
        except json.JSONDecodeError:
            pass
        else:
            matched = _matches(direct)
            if matched is not None:
                return matched

    for index, char in enumerate(raw_output):
        if char != "{":
            continue
        try:
            candidate, _ = decoder.raw_decode(raw_output[index:])
        except json.JSONDecodeError:
            continue
        matched = _matches(candidate)
        if matched is not None:
            return matched

    required_text = ", ".join(sorted(required_keys))
    raise ValueError(f"no JSON object found with required keys: {required_text}")
