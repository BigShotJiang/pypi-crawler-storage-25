/**
 * @supero/mobile v3.0.1
 *
 * v3.3.1 — Transactional registry auto-load (SUPERO_MOBILE_TXN_AUTOLOAD_BANNER_V1):
 *   - SuperoTransactionalRegistry.load() is now auto-called from
 *     AuthProvider's mount useEffect and from MobileShell() right
 *     after setConfig. Idempotent via _txnLoadStartedM guard.
 *   - TransactionalListScreen and TransactionalDetailScreen track
 *     a per-screen ready state via useState/useEffect so they
 *     re-render when the registry finishes loading.
 *   - Fixes a latent bug where Mode A/B apps that used
 *     view: 'transactional' tabs would render with gray state
 *     badges and no action buttons because .load() was never called.
 *   - User code that already calls .load() explicitly continues to
 *     work: the first .load() call wins, subsequent calls return
 *     the cached promise.
 *
 * Supero Platform — React Native / Expo Components
 *
 * v3.0.1 — AuthProvider hang fix (2026-04-30):
 *   - SUPERO_MOBILE_AUTH_HANG_FIX_V1: AuthProvider's useEffect now
 *     handles client.init() rejection and ALWAYS flips isReady=true
 *     via .finally(). Without this fix, any rejection from init()
 *     (e.g. AsyncStorage TurboModule timeout on the new architecture)
 *     would leave isReady=false forever, causing _Root to render the
 *     ActivityIndicator indefinitely. The app would appear to spin
 *     forever and Expo Go would silently close after its watchdog
 *     timeout. No red error screen because the rejection was an
 *     unhandled promise that never reached a React error boundary.
 *
 * v3.0.0 — UX Overhaul (matches supero-ui.js v3):
 *   - Theme engine: full palette from primary color
 *   - Themed navigation bar and tab bar
 *   - Image-forward list cards with cardTemplate support
 *   - dashboardWidgets for KPI cards
 *   - actionButtons for email/sms on detail views
 *   - Improved visual quality across all screens
 *
 * Provides: SuperoClient, client, useAuth, AuthProvider,
 * formatters, AI chat client, workflow utils, InlineSelect,
 * buildFieldDefs, parse422Error, MobileShell, services.
 *
 * Usage in Expo app:
 *   import { MobileShell } from './src/lib/supero';
 *   import { APP_CONFIG, TABS, WORKFLOW_MAP } from './src/appConfig';
 *   export default () => MobileShell({ ...APP_CONFIG, tabs: TABS, workflowMap: WORKFLOW_MAP });
 *
 * ⚠️ Call setConfig() BEFORE any client operations.
 * ⛔ NEVER use expo-secure-store — triggers TurboModule crash.
 * ⛔ NEVER use @react-native-picker/picker — not in Expo SDK 54.
 * ⛔ NEVER use stream: true in AI chat — RN fetch can't stream.
 */


// === SUPERO_CRASH_REPORTER_BEGIN ===
// Self-contained crash reporter for supero-mobile.
// Installs BEFORE imports complete so it can catch top-level module errors.
//
// Crash URL resolution (in priority order):
//   1. EXPO_PUBLIC_SUPERO_CRASH_URL  (build-baked, recommended for prod)
//   2. CONFIG.API_URL                (set via setConfig, must differ from default localhost)
//   3. Drop the report + console.warn (developer sees the warning on-device)
//
// Why no fallback to localhost: silent posts to localhost never reach
// Cloud Run, defeating the entire reporter. We'd rather drop+warn than
// pretend we sent something.
//
// Kill switch:    EXPO_PUBLIC_SUPERO_CRASH_DISABLED=1
// No breadcrumbs: EXPO_PUBLIC_SUPERO_CRASH_NO_BREADCRUMBS=1
// Shared secret:  EXPO_PUBLIC_SUPERO_CRASH_TOKEN=<value>
(function _installSuperoCrashReporter() {
    try {
        var ENV = (typeof process !== 'undefined' && process && process.env) ? process.env : {};
        if (ENV.EXPO_PUBLIC_SUPERO_CRASH_DISABLED === '1') return;

        var REPORTING = false;        // re-entry guard — prevent recursion
        var BREADCRUMBS = [];         // ring buffer of last N console.error/warn
        var BREADCRUMBS_MAX = 20;
        var SDK_VERSION = '3.3.0';    // matches SUPERO_MOBILE_VERSION below

        function _now() {
            try { return new Date().toISOString(); } catch (_) { return ''; }
        }

        function _addBreadcrumb(level, args) {
            try {
                var msg = '';
                for (var i = 0; i < args.length && i < 5; i++) {
                    var a = args[i];
                    if (a == null) { msg += 'null '; continue; }
                    if (typeof a === 'string') { msg += a + ' '; continue; }
                    try { msg += JSON.stringify(a) + ' '; }
                    catch (_) { msg += String(a) + ' '; }
                }
                if (msg.length > 500) msg = msg.slice(0, 500) + '...';
                BREADCRUMBS.push({ ts: _now(), level: level, msg: msg });
                if (BREADCRUMBS.length > BREADCRUMBS_MAX) BREADCRUMBS.shift();
            } catch (_) { /* never let breadcrumb capture crash */ }
        }

        // Console hooking — DON'T hook console.log (too noisy). Only error/warn.
        if (ENV.EXPO_PUBLIC_SUPERO_CRASH_NO_BREADCRUMBS !== '1' && typeof console !== 'undefined') {
            try {
                var origErr = console.error;
                console.error = function () {
                    _addBreadcrumb('error', arguments);
                    try { return origErr.apply(console, arguments); } catch (_) {}
                };
                var origWarn = console.warn;
                console.warn = function () {
                    _addBreadcrumb('warn', arguments);
                    try { return origWarn.apply(console, arguments); } catch (_) {}
                };
            } catch (_) {}
        }

        // Walk the error.cause chain (ES2022). Cap depth to avoid cycles.
        function _causeChain(err) {
            var chain = []; var cur = err && err.cause; var depth = 0;
            while (cur && depth < 5) {
                try {
                    chain.push({
                        name: (cur && cur.name) || 'Error',
                        message: (cur && cur.message) || String(cur),
                        stack: (cur && cur.stack) ? String(cur.stack).slice(0, 4096) : null,
                    });
                } catch (_) { break; }
                cur = cur && cur.cause; depth++;
            }
            return chain;
        }

        function _readConfig() {
            // Read CONFIG lazily — setConfig() may have run since install.
            // Tolerant of CONFIG not being defined yet (very early crash).
            try {
                if (typeof CONFIG !== 'undefined' && CONFIG) return CONFIG;
            } catch (_) {}
            // Fall back to defaults that match DEFAULT_CONFIG below.
            return { API_URL: 'http://localhost:5648', DOMAIN: 'app', PROJECT: 'app-project', TENANT: 'default-tenant' };
        }

        function _platformInfo() {
            try {
                // Lazy access — Platform may not be imported yet at install time.
                var P = (typeof require === 'function')
                    ? (function () { try { return require('react-native').Platform; } catch (_) { return null; } })()
                    : null;
                if (P) return { os: String(P.OS || 'unknown'), version: String(P.Version != null ? P.Version : 'unknown') };
            } catch (_) {}
            return { os: 'unknown', version: 'unknown' };
        }

        function _resolveCrashUrl() {
            // Priority 1: EXPO_PUBLIC_SUPERO_CRASH_URL — explicit, build-baked,
            //             always-available. This is the production path.
            // Priority 2: CONFIG.API_URL — but ONLY if setConfig has been called
            //             with a non-default value. The default is localhost,
            //             which would silently lose reports in Cloud Run.
            // Otherwise: return null and the caller drops the report with a
            //            console warning so the developer can see it on-device.
            try {
                if (ENV.EXPO_PUBLIC_SUPERO_CRASH_URL) {
                    return String(ENV.EXPO_PUBLIC_SUPERO_CRASH_URL).replace(/\/+$/, '') + '/api/v1/mobile/crash';
                }
            } catch (_) {}
            try {
                if (typeof CONFIG !== 'undefined' && CONFIG && CONFIG.API_URL
                    && CONFIG.API_URL !== 'http://localhost:5648') {
                    return String(CONFIG.API_URL).replace(/\/+$/, '') + '/api/v1/mobile/crash';
                }
            } catch (_) {}
            return null;
        }

        function _post(payload) {
            // Raw fetch with a hard timeout. Fire-and-forget. Never throws.
            try {
                var url = _resolveCrashUrl();
                if (!url) {
                    // No usable URL — log on-device so the developer sees something.
                    // Direct console.warn here would re-enter our own breadcrumb hook,
                    // but origWarn is captured before that hook is installed in some
                    // paths, so use console.warn defensively.
                    try {
                        if (typeof console !== 'undefined' && console.warn) {
                            console.warn(
                                '[supero-crash] no crash URL configured (set EXPO_PUBLIC_SUPERO_CRASH_URL ' +
                                'or call setConfig({ API_URL: ... }) before any crashes); dropping report:',
                                (payload && payload.message) || '<unknown>'
                            );
                        }
                    } catch (_) {}
                    return;
                }
                var headers = { 'Content-Type': 'application/json' };
                if (ENV.EXPO_PUBLIC_SUPERO_CRASH_TOKEN) {
                    headers['X-Supero-Crash-Token'] = ENV.EXPO_PUBLIC_SUPERO_CRASH_TOKEN;
                }
                if (typeof fetch !== 'function') return;
                // Timeout via AbortController if available.
                var ctrl = (typeof AbortController === 'function') ? new AbortController() : null;
                var timer = ctrl ? setTimeout(function () { try { ctrl.abort(); } catch (_) {} }, 4000) : null;
                var p = fetch(url, {
                    method: 'POST',
                    headers: headers,
                    body: JSON.stringify(payload),
                    signal: ctrl ? ctrl.signal : undefined,
                });
                if (p && typeof p.then === 'function') {
                    p.then(function () { if (timer) clearTimeout(timer); })
                     .catch(function () { if (timer) clearTimeout(timer); });
                }
            } catch (_) { /* never raise */ }
        }

        function _report(err, kind, extra) {
            if (REPORTING) return;          // re-entry guard
            REPORTING = true;
            try {
                var cfg = _readConfig();
                var p = _platformInfo();
                var payload = {
                    kind: kind || 'js',
                    fatal: !!(extra && extra.fatal),
                    name: (err && err.name) || 'Error',
                    message: String((err && err.message) || err || 'unknown'),
                    stack: (err && err.stack) ? String(err.stack) : null,
                    platform: p.os,
                    platform_version: p.version,
                    sdk_version: SDK_VERSION,
                    app_version: (extra && extra.app_version) || cfg.APP_NAME || 'unknown',
                    project_uuid: cfg.PROJECT_UUID || cfg.project_uuid || cfg.projectUuid || cfg.PROJECT || '',
                    domain_name: cfg.DOMAIN || '',
                    ts: _now(),
                    extra: {
                        breadcrumbs: BREADCRUMBS.slice(),
                        cause_chain: _causeChain(err),
                        custom: (extra && extra.custom) || null,
                    },
                };
                _post(payload);
            } catch (e) {
                try { /* original */ console && console.error && console.error('[supero-crash] reporter failed:', e); } catch (_) {}
            } finally {
                // Allow next crash to be reported (after a beat) — but a single
                // tick is enough; we want to be able to report multiple distinct
                // crashes in a session.
                setTimeout(function () { REPORTING = false; }, 0);
            }
        }

        // Expose for the ErrorBoundary and any user code that wants to report manually.
        if (typeof globalThis !== 'undefined') {
            globalThis.__SUPERO_REPORT_CRASH__ = _report;
        }

        // Hook 1: global synchronous JS errors via RN's ErrorUtils.
        // ErrorUtils is RN-provided; it may not exist in test environments.
        if (typeof ErrorUtils !== 'undefined' && ErrorUtils && typeof ErrorUtils.setGlobalHandler === 'function') {
            try {
                var prev = (typeof ErrorUtils.getGlobalHandler === 'function') ? ErrorUtils.getGlobalHandler() : null;
                ErrorUtils.setGlobalHandler(function (error, isFatal) {
                    _report(error, 'js', { fatal: !!isFatal });
                    if (prev) { try { prev(error, isFatal); } catch (_) {} }
                });
            } catch (_) {}
        }

        // Hook 2: unhandled promise rejections via Hermes.
        // Expo SDK 54 defaults to Hermes; non-Hermes runtimes silently skip.
        try {
            if (typeof HermesInternal !== 'undefined' && HermesInternal && typeof HermesInternal.enablePromiseRejectionTracker === 'function') {
                HermesInternal.enablePromiseRejectionTracker({
                    allRejections: true,
                    onUnhandled: function (id, err) { _report(err, 'promise', { fatal: false, custom: { rejection_id: id } }); },
                });
            }
        } catch (_) {}
    } catch (_) {
        // The reporter failed to install. Swallow — never block the app.
    }
})();
// === SUPERO_CRASH_REPORTER_END ===
// ─────────────────────────────────────────────────────────
// Imports
// ─────────────────────────────────────────────────────────

import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import {
    View, Text, Pressable, StyleSheet, ScrollView, TextInput, Switch,
    Alert, RefreshControl, ActivityIndicator, Image, FlatList, Dimensions,
    TouchableOpacity, Animated, Platform, StatusBar, KeyboardAvoidingView,
    Linking,
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import AsyncStorage from '@react-native-async-storage/async-storage';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();
const { width: SCREEN_WIDTH } = Dimensions.get('window');

// ─────────────────────────────────────────────────────────
// Config
// ─────────────────────────────────────────────────────────

export const DEFAULT_CONFIG = {
    API_URL: 'http://localhost:5648',
    DOMAIN: 'app',
    PROJECT: 'app-project',
    TENANT: 'default-tenant',
    APP_NAME: 'Supero App',
};

let CONFIG = { ...DEFAULT_CONFIG };

export function setConfig(appConfig) {
    CONFIG = { ...DEFAULT_CONFIG };

    // Accept both camelCase (caller-friendly) and UPPER_CASE (output-shape) keys.
    // Lookup falls back left-to-right; first defined value wins.
    const apiUrl  = appConfig.serverUrl ?? appConfig.apiUrl  ?? appConfig.API_URL;
    const domain  = appConfig.domain    ?? appConfig.DOMAIN;
    const project = appConfig.project   ?? appConfig.PROJECT;
    const tenant  = appConfig.tenant    ?? appConfig.TENANT;
    const appName = appConfig.appName   ?? appConfig.APP_NAME;

    if (apiUrl)  CONFIG.API_URL  = apiUrl;
    if (domain)  CONFIG.DOMAIN   = domain;
    if (project) CONFIG.PROJECT  = project;
    if (tenant)  CONFIG.TENANT   = tenant;
    if (appName) CONFIG.APP_NAME = appName;

    // Loud failure for typos / wrong casing — silent no-ops were the original bug.
    const known = new Set([
        'serverUrl', 'apiUrl', 'API_URL',
        'domain',    'DOMAIN',
        'project',   'PROJECT',
        'tenant',    'TENANT',
        'appName',   'APP_NAME',
    ]);
    const unknown = Object.keys(appConfig).filter(k => !known.has(k));
    if (unknown.length && typeof console !== 'undefined' && console.warn) {
        console.warn('[supero] setConfig: ignoring unknown keys:', unknown);
    }

    if (typeof client !== 'undefined' && client && !client.token) {
        client.domain = CONFIG.DOMAIN;
        client.project = CONFIG.PROJECT;
        client.tenant = CONFIG.TENANT;
    }
}

export function getConfig() { return CONFIG; }

// ─────────────────────────────────────────────────────────
// Theme Engine — generates palette from primary hex
// ─────────────────────────────────────────────────────────

function _hexToHSL(hex) {
    hex = hex.replace('#', '');
    if (hex.length === 3) hex = hex[0]+hex[0]+hex[1]+hex[1]+hex[2]+hex[2];
    const r = parseInt(hex.substr(0,2), 16) / 255;
    const g = parseInt(hex.substr(2,2), 16) / 255;
    const b = parseInt(hex.substr(4,2), 16) / 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    let h, s, l = (max + min) / 2;
    if (max === min) { h = s = 0; }
    else {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch (max) {
            case r: h = ((g - b) / d + (g < b ? 6 : 0)) / 6; break;
            case g: h = ((b - r) / d + 2) / 6; break;
            case b: h = ((r - g) / d + 4) / 6; break;
        }
    }
    return { h: Math.round(h * 360), s: Math.round(s * 100), l: Math.round(l * 100) };
}

function _hslToHex(h, s, l) {
    s /= 100; l /= 100;
    const c = (1 - Math.abs(2 * l - 1)) * s;
    const x = c * (1 - Math.abs((h / 60) % 2 - 1));
    const m = l - c / 2;
    let r, g, b;
    if (h < 60) { r=c; g=x; b=0; }
    else if (h < 120) { r=x; g=c; b=0; }
    else if (h < 180) { r=0; g=c; b=x; }
    else if (h < 240) { r=0; g=x; b=c; }
    else if (h < 300) { r=x; g=0; b=c; }
    else { r=c; g=0; b=x; }
    r = Math.round((r+m)*255).toString(16).padStart(2,'0');
    g = Math.round((g+m)*255).toString(16).padStart(2,'0');
    b = Math.round((b+m)*255).toString(16).padStart(2,'0');
    return '#' + r + g + b;
}

function generatePalette(hex) {
    const hsl = _hexToHSL(hex);
    return {
        50:  _hslToHex(hsl.h, Math.min(100, hsl.s + 10), 97),
        100: _hslToHex(hsl.h, Math.min(100, hsl.s + 5), 93),
        200: _hslToHex(hsl.h, hsl.s, 85),
        300: _hslToHex(hsl.h, hsl.s, 73),
        400: _hslToHex(hsl.h, hsl.s, 60),
        500: hex,
        600: _hslToHex(hsl.h, hsl.s, Math.max(0, hsl.l - 8)),
        700: _hslToHex(hsl.h, hsl.s, Math.max(0, hsl.l - 16)),
        800: _hslToHex(hsl.h, Math.max(0, hsl.s - 5), Math.max(0, hsl.l - 24)),
        900: _hslToHex(hsl.h, Math.max(0, hsl.s - 10), Math.max(0, hsl.l - 32)),
    };
}

// Theme context — all components read from this
const ThemeContext = createContext({
    primary: '#6366f1', palette: generatePalette('#6366f1'),
});
const useTheme = () => useContext(ThemeContext);

// ─────────────────────────────────────────────────────────
// Formatters (identical to web)
// ─────────────────────────────────────────────────────────

export const formatCurrency = (v, c = 'USD') =>
    v != null ? new Intl.NumberFormat('en-US', { style: 'currency', currency: c }).format(v) : '$0';

export const formatNumber = (v) => {
    if (v == null) return '0';
    if (v >= 1e6) return (v / 1e6).toFixed(1) + 'M';
    if (v >= 1e3) return (v / 1e3).toFixed(1) + 'K';
    return new Intl.NumberFormat('en-US').format(v);
};

export const formatDate = (s) =>
    s ? new Date(s).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : '—';

export const formatDateTime = (s) =>
    s ? new Date(s).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }) : '—';

export const formatFieldValue = (field, value) => {
    if (value == null) return '—';
    if ((field.type === 'number' || field.type === 'float' || field.type === 'integer') &&
        ['amount', 'budget', 'price', 'cost', 'total', 'revenue', 'rent', 'rate', 'spent', 'fee', 'salary']
            .some(k => field.name.includes(k)))
        return formatCurrency(value);
    if (field.type === 'number' || field.type === 'float' || field.type === 'integer') return formatNumber(value);
    if (field.type === 'date' || field.type === 'datetime') return formatDate(value);
    if (typeof value === 'boolean') return value ? 'Yes' : 'No';
    if (typeof value === 'string' && value.includes('_')) return value.replace(/_/g, ' ');
    return String(value);
};

// ─────────────────────────────────────────────────────────
// Image URL resolver (matches web resolveImageUrl)
// ─────────────────────────────────────────────────────────

export function resolveImageUrl(val) {
    if (!val) return '';
    if (typeof val === 'string') return val;
    return val.thumbnail_url || val.url || '';
}

// ─────────────────────────────────────────────────────────
// Status colors (matches web getStatusColor)
// ─────────────────────────────────────────────────────────

const STATUS_COLORS = {
    active: { bg: '#dcfce7', text: '#166534' }, approved: { bg: '#dcfce7', text: '#166534' },
    hired: { bg: '#dcfce7', text: '#166534' }, paid: { bg: '#dcfce7', text: '#166534' },
    open: { bg: '#dcfce7', text: '#166534' }, completed: { bg: '#dcfce7', text: '#166534' },
    pending: { bg: '#fef3c7', text: '#92400e' }, processing: { bg: '#fef3c7', text: '#92400e' },
    on_leave: { bg: '#fef3c7', text: '#92400e' },
    scheduled: { bg: '#dbeafe', text: '#1e40af' }, screening: { bg: '#dbeafe', text: '#1e40af' },
    interview: { bg: '#f3e8ff', text: '#7c3aed' }, offer: { bg: '#eef2ff', text: '#4338ca' },
    applied: { bg: '#f1f5f9', text: '#64748b' }, draft: { bg: '#f1f5f9', text: '#64748b' },
    inactive: { bg: '#f1f5f9', text: '#64748b' },
    terminated: { bg: '#fee2e2', text: '#991b1b' }, rejected: { bg: '#fee2e2', text: '#991b1b' },
    failed: { bg: '#fee2e2', text: '#991b1b' }, cancelled: { bg: '#f1f5f9', text: '#64748b' },
};

function getStatusStyle(status) {
    return STATUS_COLORS[status] || { bg: '#f1f5f9', text: '#64748b' };
}

// ─────────────────────────────────────────────────────────
// SuperoClient (identical logic to web, AsyncStorage instead of localStorage)
// ─────────────────────────────────────────────────────────

export class SuperoClient {
    token = null;
    domain = CONFIG.DOMAIN;
    project = CONFIG.PROJECT;
    tenant = CONFIG.TENANT;
    userInfo = {};
    policy = null;

    async init() {
        try {
            const storedDomain = await AsyncStorage.getItem('supero_domain');
            // Stale auth from a different domain — clear it so the new config takes effect
            if (storedDomain && storedDomain !== CONFIG.DOMAIN) {
                await AsyncStorage.multiRemove(['supero_token', 'supero_domain', 'supero_project', 'supero_tenant', 'supero_user', 'supero_policy']);
                this.domain = CONFIG.DOMAIN;
                this.project = CONFIG.PROJECT;
                this.tenant = CONFIG.TENANT;
                return;
            }
            this.token = await AsyncStorage.getItem('supero_token');
            this.domain = storedDomain || CONFIG.DOMAIN;
            this.project = (await AsyncStorage.getItem('supero_project')) || CONFIG.PROJECT;
            this.tenant = (await AsyncStorage.getItem('supero_tenant')) || CONFIG.TENANT;
            const ui = await AsyncStorage.getItem('supero_user');
            this.userInfo = ui ? JSON.parse(ui) : {};
            const pol = await AsyncStorage.getItem('supero_policy');
            this.policy = pol ? JSON.parse(pol) : null;
        } catch { this.token = null; }
    }

    async setAuth(token, domain, project, tenant, userInfo, policy = null) {
        Object.assign(this, { token, domain, project, tenant, userInfo, policy });
        await AsyncStorage.setItem('supero_token', token);
        await AsyncStorage.setItem('supero_domain', domain);
        await AsyncStorage.setItem('supero_project', project);
        await AsyncStorage.setItem('supero_tenant', tenant);
        await AsyncStorage.setItem('supero_user', JSON.stringify(userInfo));
        if (policy !== null) await AsyncStorage.setItem('supero_policy', JSON.stringify(policy));
    }

    async clearAuth() {
        this.token = null; this.userInfo = {}; this.policy = null;
        this.domain = CONFIG.DOMAIN; this.project = CONFIG.PROJECT; this.tenant = CONFIG.TENANT;
        await AsyncStorage.multiRemove(['supero_token', 'supero_domain', 'supero_project', 'supero_tenant', 'supero_user', 'supero_policy']);
    }

    isAuthenticated() { return !!this.token; }

    _headers() {
        const h = { 'Content-Type': 'application/json', 'X-Domain': this.domain, 'X-Tenant': this.tenant };
        if (this.token) h['Authorization'] = `Bearer ${this.token}`;
        return h;
    }

    async request(method, path, data, retries = 2, extraHeaders = {}) {
        const url = `${CONFIG.API_URL}${path}`;
        for (let attempt = 0; attempt <= retries; attempt++) {
            try {
                const opts = { method, headers: { ...this._headers(), ...extraHeaders } };
                if (data) opts.body = JSON.stringify(data);
                const resp = await fetch(url, opts);
                const result = await resp.json().catch(() => ({}));
                if (!resp.ok) {
                    const msg = result.detail || result.message || result.error || `HTTP ${resp.status}`;
                    const err = new Error(msg); err.status = resp.status; err.body = result;
                    throw err;
                }
                return result;
            } catch (err) {
                if (attempt === retries) throw err;
                await new Promise(r => setTimeout(r, 1000 * (attempt + 1)));
            }
        }
    }

    async login(domain, email, password, project) {
        const r = await this.request('POST', '/api/v1/auth/login',
            { domain_name: domain, email, password, project },
            2, { 'X-Domain': domain });
        const policy = r.policy || null;
        await this.setAuth(r.auth.access_token, domain,
            project || r.context.project, r.context.tenant,
            { email, role: r.user?.role, fullName: r.user?.full_name }, policy);
        return r;
    }

    can(action, schema = null) {
        if (this.policy?.is_admin) return true;
        const p = this.policy;
        if (!p) {
            const role = this.userInfo?.role || '';
            return ['platform_admin', 'domain_admin', 'tenant_admin'].includes(role);
        }
        if (schema && p.entities?.[schema]) {
            const e = p.entities[schema];
            if (action === 'create') return !!e.can_create;
            if (action === 'update') return !!e.can_update;
            if (action === 'delete') return !!e.can_delete;
            return !!e.can_read;
        }
        const da = p.default_access || 'none';
        return da === 'full' ? true : da === 'read' ? action === 'read' : false;
    }

    canWrite(schema = null) { return this.can('create', schema) || this.can('update', schema); }

    async getObjects(schema) {
        return (await this.request('GET', `/api/v1/crud/${this.domain}/${schema}`)).results || [];
    }

    async createObject(schema, data) {
        const name = data.name || `${schema}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
        const payload = data.parent_uuid ? { name, ...data } : { name, parent_type: 'tenant', ...data };
        delete payload.fq_name;
        return this.request('POST', `/api/v1/crud/${this.domain}/${schema}`, payload);
    }

    _tenantFromItem(item) {
        if (!item) return null;
        const fq = item.fq_name;
        if (Array.isArray(fq) && fq.length >= 3) return fq[2];
        if (typeof fq === 'string') { const p = fq.split(':'); if (p.length >= 3) return p[2]; }
        return item.tenant_name || item.parent_name || null;
    }

    async updateObject(schema, uuid, data, item = null) {
        const th = this._tenantFromItem(item);
        return this.request('PUT', `/api/v1/crud/${this.domain}/${schema}/${uuid}`, data, 2, th ? { 'X-Tenant': th } : {});
    }

    async deleteObject(schema, uuid, item = null) {
        const th = this._tenantFromItem(item);
        return this.request('DELETE', `/api/v1/crud/${this.domain}/${schema}/${uuid}`, null, 2, th ? { 'X-Tenant': th } : {});
    }
}

export const client = new SuperoClient();


// === SUPERO_ERROR_BOUNDARY_BEGIN ===
// React error boundary that reports render-time errors and shows the stack
// on-screen instead of leaving the user with a blank Expo Go window.
// Exported so user apps can also wrap manually if needed.
export class SuperoErrorBoundary extends React.Component {
    constructor(props) {
        super(props);
        this.state = { error: null, info: null };
    }
    static getDerivedStateFromError(error) {
        return { error: error };
    }
    componentDidCatch(error, info) {
        try {
            this.setState({ info: info });
            if (typeof globalThis !== 'undefined' && typeof globalThis.__SUPERO_REPORT_CRASH__ === 'function') {
                globalThis.__SUPERO_REPORT_CRASH__(error, 'render', {
                    fatal: false,
                    custom: { component_stack: (info && info.componentStack) ? String(info.componentStack).slice(0, 4096) : null },
                });
            }
        } catch (_) { /* never re-throw from boundary */ }
    }
    render() {
        if (this.state.error) {
            var msg = (this.state.error && this.state.error.message) || String(this.state.error);
            var stack = (this.state.error && this.state.error.stack) || '';
            var compStack = (this.state.info && this.state.info.componentStack) || '';
            return React.createElement(
                ScrollView,
                { style: { flex: 1, backgroundColor: '#fff' }, contentContainerStyle: { padding: 20 } },
                React.createElement(Text, { style: { fontSize: 18, fontWeight: '700', color: '#991b1b', marginBottom: 8 } }, 'App Error'),
                React.createElement(Text, { style: { fontSize: 14, color: '#1f2937', marginBottom: 12 } }, msg),
                React.createElement(Text, { style: { fontSize: 11, fontFamily: 'Courier', color: '#374151' }, selectable: true }, String(stack)),
                compStack ? React.createElement(Text, { style: { fontSize: 11, fontFamily: 'Courier', color: '#6b7280', marginTop: 12 }, selectable: true }, String(compStack)) : null,
                React.createElement(Text, { style: { fontSize: 11, color: '#6b7280', marginTop: 16 } }, 'This crash has been reported.')
            );
        }
        return this.props.children;
    }
}
// === SUPERO_ERROR_BOUNDARY_END ===
// ─────────────────────────────────────────────────────────
// AI Chat (non-streaming — RN safe)
// ─────────────────────────────────────────────────────────

export async function aiChat(message, sessionId = null) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 60000);
    try {
        const headers = { 'Content-Type': 'application/json', 'Accept': 'application/json', 'X-Domain': client.domain, 'X-Tenant': client.tenant };
        if (client.token) headers['Authorization'] = `Bearer ${client.token}`;
        const resp = await fetch(`${CONFIG.API_URL}/ai/v1/chat`, {
            method: 'POST', headers,
            body: JSON.stringify({ message, session_id: sessionId, stream: false }),
            signal: controller.signal,
        });
        if (!resp.ok) throw new Error(`AI failed (${resp.status})`);
        const data = await resp.json();
        return { response: data.response || data.message || data.content || '', sessionId: data.session_id || null, toolCalls: [] };
    } finally { clearTimeout(timeout); }
}

// ─────────────────────────────────────────────────────────
// Auth Context
// ─────────────────────────────────────────────────────────

const AuthContext = createContext({});

export function AuthProvider({ children }) {
    const [isReady, setIsReady] = useState(false);
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [userInfo, setUserInfo] = useState({});

    useEffect(() => {
        // SUPERO_MOBILE_AUTH_HANG_FIX_V1
        // Bug: original code was `client.init().then(() => { setIsReady(true); ... })`
        // with no .catch() and no .finally(). If client.init() rejected for any
        // reason (e.g. AsyncStorage TurboModule timeout under newArchEnabled:true),
        // isReady stayed false forever — _Root would render the ActivityIndicator
        // indefinitely and Expo Go would silently close after watchdog timeout.
        // Fix: chain .catch() + .finally() so isReady ALWAYS flips to true once
        // init() settles, even on rejection. Diagnostic console output kept so
        // we can observe behavior via Metro / Remote JS Debugger.
        console.log('[supero-mobile] AuthProvider mount, calling client.init()');
        const _t0 = Date.now();
        const _watchdog = setTimeout(() => {
            console.warn('[supero-mobile] client.init() did not settle within 5s');
        }, 5000);
        client.init()
            .then(() => {
                console.log('[supero-mobile] client.init() RESOLVED in', Date.now() - _t0, 'ms');
                setIsAuthenticated(client.isAuthenticated());
                setUserInfo(client.userInfo);
            })
            .catch((err) => {
                console.error('[supero-mobile] client.init() REJECTED:', err && err.message, err);
            })
            .finally(() => {
                clearTimeout(_watchdog);
                setIsReady(true);
            });
    }, []);

    // SUPERO_MOBILE_TXN_AUTOLOAD_AUTH_V1
    // Auto-load the transactional registry once on mount. Independent
    // of client.init() so a rejection there (e.g. AsyncStorage broken
    // on RN new architecture) doesn't block manifest loading. The
    // load() method is internally idempotent via _txnLoadStartedM,
    // so subsequent calls from MobileShell or user code are no-ops.
    useEffect(() => {
        try {
            SuperoTransactionalRegistry.load();
        } catch (e) {
            // Defensive: load() should never throw, but if it did we
            // don't want to crash AuthProvider mount.
            if (typeof console !== 'undefined' && console.warn) {
                console.warn('[supero-mobile] auto-load registry failed:', e);
            }
        }
    }, []);

    const login = async (domain, email, password, project) => {
        await client.login(domain, email, password, project);
        setIsAuthenticated(true);
        setUserInfo(client.userInfo);
    };

    const logout = async () => {
        await client.clearAuth();
        setIsAuthenticated(false);
        setUserInfo({});
    };

    return (
        <AuthContext.Provider value={{ isReady, isAuthenticated, userInfo, login, logout }}>
            {children}
        </AuthContext.Provider>
    );
}

export const useAuth = () => useContext(AuthContext);

// ─────────────────────────────────────────────────────────
// Services — all 26 platform services (SINGLE definition)
// ─────────────────────────────────────────────────────────

function _svc(serviceId, operationId, input) {
    return client.request('POST', '/api/v1/services/execute',
        { service_id: serviceId, operation_id: operationId, input });
}

export const services = {
    email: { send: (p) => _svc('email', 'send_email', { to_email: p.to, subject: p.subject, body_html: p.bodyHtml || p.body, body_text: p.bodyText, from_name: p.fromName }) },
    emailSmtp: { send: (p) => _svc('email_smtp', 'send_email', { to_email: p.to, subject: p.subject, body_html: p.bodyHtml, body_text: p.bodyText }) },
    sms: { send: (p) => _svc('sms', 'send_sms', { to_number: p.to, body: p.body }) },
    whatsapp: {
        send: (p) => _svc('whatsapp', 'send_message', { to_number: p.to, body: p.body }),
        sendTemplate: (p) => _svc('whatsapp', 'send_template', { to_number: p.to, template_name: p.templateName, template_params: p.templateParams }),
    },
    push: {
        notify: (p) => _svc('push_notification', 'send_notification', { device_token: p.token, title: p.title, body: p.body }),
        broadcast: (p) => _svc('push_notification', 'send_topic_broadcast', { topic: p.topic, title: p.title, body: p.body }),
    },
    slack: {
        message: (p) => _svc('slack', 'send_message', { channel: p.channel, text: p.text }),
        createChannel: (p) => _svc('slack', 'create_channel', { channel_name: p.name, topic: p.topic }),
    },
    stripe: {
        checkout: (p) => _svc('stripe_checkout', 'create_checkout_session', { amount: p.amount, product_name: p.product, success_url: p.successUrl }),
        paymentLink: (p) => _svc('stripe_checkout', 'create_payment_link', { price_id: p.priceId }),
    },
    billing: {
        createCustomer: (p) => _svc('billing', 'create_customer', { email: p.email, company_name: p.company }),
        createInvoice: (p) => _svc('billing', 'create_invoice', { customer_uuid: p.customerUuid, amount: p.amount, currency: p.currency || 'USD', due_date: p.dueDate }),
    },
    paypal: { createOrder: (p) => _svc('billing_paypal', 'create_order', { amount: p.amount, currency: p.currency || 'USD', description: p.description }) },
    razorpay: { createOrder: (p) => _svc('billing_razorpay', 'create_order', { amount_paise: p.amountPaise, currency: p.currency || 'INR', customer_name: p.customerName }) },
    plaid: {
        createLinkToken: (p) => _svc('plaid', 'create_link_token', { client_user_id: p.userId, products: p.products || 'transactions' }),
        exchangeToken: (p) => _svc('plaid', 'exchange_public_token', { public_token: p.publicToken }),
    },
    salesforce: {
        createLead: (p) => _svc('salesforce', 'create_lead', { last_name: p.lastName, company: p.company, email: p.email }),
        createCase: (p) => _svc('salesforce', 'create_case', { subject: p.subject, priority: p.priority || 'Medium', case_origin: p.origin || 'Web' }),
    },
    instagram: { publish: (p) => _svc('instagram', 'publish_post', { media_type: p.mediaType || 'IMAGE', media_url: p.mediaUrl, caption: p.caption }) },
    twitter: {
        tweet: (p) => _svc('x_social', 'post_tweet', { text: p.text }),
        thread: (p) => _svc('x_social', 'post_thread', { tweets_text: p.tweets }),
    },
    linkedin: { post: (p) => _svc('linkedin', 'create_post', { text: p.text }) },
    youtube: { search: (p) => _svc('youtube', 'search_videos', { query: p.query, max_results: p.maxResults || 5 }) },
    github: {
        createIssue: (p) => _svc('github', 'create_issue', { repo_owner: p.owner, repo_name: p.repo, title: p.title, labels: p.labels }),
        createPR: (p) => _svc('github', 'create_pull_request', { repo_owner: p.owner, repo_name: p.repo, title: p.title, head_branch: p.head, base_branch: p.base || 'main' }),
    },
    bitbucket: { createRepo: (p) => _svc('bitbucket', 'create_repository', { workspace: p.workspace, repo_slug: p.slug, is_private: p.isPrivate !== false }) },
    s3: { uploadUrl: (p) => _svc('amazon_s3', 'generate_upload_url', { key: p.key, content_type: p.contentType }) },
    gdrive: { createFolder: (p) => _svc('google_drive', 'create_folder', { file_name: p.name, description: p.description }) },
    calendar: { createEvent: (p) => _svc('google_calendar', 'create_event', { summary: p.title, start_time: p.start, end_time: p.end, add_meet: !!p.addMeet }) },
    servicenow: {
        createIncident: (p) => _svc('servicenow', 'create_incident', { short_description: p.description, urgency: p.urgency || '3', impact: p.impact || '3' }),
        createChange: (p) => _svc('servicenow', 'create_change_request', { short_description: p.description, change_type: p.type || 'normal' }),
    },
    ai: {
        complete: (p) => _svc('ai', 'simple_completion', { prompt: p.prompt, model: p.model || 'claude-sonnet', max_tokens: p.maxTokens || 1000 }),
        chat: (p) => _svc('ai', 'chat_completion', { messages: p.messages, model: p.model || 'claude-sonnet' }),
    },
    search: { web: (p) => _svc('google_search', 'web_search', { query: p.query, num: p.num || 5 }) },
    otp: { send: (p) => _svc('auth_otp', 'send_otp', { channel: p.channel || 'sms', recipient: p.to, purpose: p.purpose || 'login' }) },
    googleAuth: {
        login: (p) => _svc('google_oauth', 'google_login', { auth_code: p.authCode, redirect_uri: p.redirectUri }),
        signup: (p) => _svc('google_oauth', 'google_signup', { auth_code: p.authCode, redirect_uri: p.redirectUri, signup: true }),
        linkAccount: (p) => _svc('google_oauth', 'link_account', { auth_code: p.authCode, redirect_uri: p.redirectUri, link_account: true }),
        getConfig: () => _svc('google_oauth', 'get_google_config', {}),
    },
    googleAds: {
        createCampaign: (p) => _svc('google_ads', 'create_campaign', { campaign_name: p.campaignName, budget_amount: p.budgetAmount || 50, channel_type: p.channelType || 'SEARCH', bidding_strategy: p.biddingStrategy }),
        listCampaigns: () => _svc('google_ads', 'list_campaigns', { list_campaigns: true }),
        getPerformance: (p) => _svc('google_ads', 'get_performance', p?.query ? { query: p.query } : {}),
    },
    googleReviews: {
        listReviews: (p) => _svc('google_reviews', 'list_reviews', { location_id: p?.locationId, page_size: p?.pageSize }),
        getRating: (locationId) => _svc('google_reviews', 'get_rating', { get_rating: true, location_id: locationId }),
    },
    quickbooks: {
        createCustomer: (p) => _svc('quickbooks', 'create_customer', { display_name: p.displayName, email: p.email, phone: p.phone, company: p.company }),
        createInvoice: (p) => _svc('quickbooks', 'create_invoice', { customer_ref: p.customerRef, line_items: p.lineItems, due_date: p.dueDate, currency: p.currency || 'USD', notes: p.notes }),
        recordPayment: (p) => _svc('quickbooks', 'record_payment', { customer_ref: p.customerRef, amount: p.amount, payment_method: p.paymentMethod, invoice_ref: p.invoiceRef }),
        getReport: (p) => _svc('quickbooks', 'get_report', { report_type: p.reportType, start_date: p.startDate, end_date: p.endDate }),
    },
    mcpServer: {
        registerTools: () => _svc('mcp_server', 'register_tools', {}),
        handleToolCall: (p) => _svc('mcp_server', 'handle_tool_call', { tool_name: p.toolName, arguments: p.arguments }),
        listResources: () => _svc('mcp_server', 'list_resources', {}),
        getEndpoint: () => _svc('mcp_server', 'get_endpoint', {}),
    },
    mcpClient: {
        callTool: (p) => _svc('mcp_client', 'call_tool', { server_url: p.serverUrl, server_name: p.serverName, tool_name: p.toolName, arguments: p.arguments }),
        listTools: (p) => _svc('mcp_client', 'list_tools', { server_url: p.serverUrl, server_name: p.serverName }),
        connectServer: (p) => _svc('mcp_client', 'connect_server', { server_url: p.serverUrl, name: p.name, auth_type: p.authType, auth_token: p.authToken }),
    },
    workflow: {
        run: (id, input) => _svc('workflows', 'execute_workflow', { workflow_id: id, ...input }),
        validate: (id) => _svc('workflows', 'validate_workflow', { workflow_id: id }),
    },
};

// ─────────────────────────────────────────────────────────
// Utilities (identical API to web)
// ─────────────────────────────────────────────────────────

export function buildFieldDefs(attrs) {
    return (attrs || []).map(a => ({
        name: a.name,
        label: a.name.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase()),
        type: a.values ? 'select' : a.type === 'Image' ? 'image' : a.type === 'File' ? 'file'
            : a.type === 'bool' ? 'bool' : (a.type === 'float' || a.type === 'integer') ? 'number'
            : (a.type === 'datetime' || a.type === 'date') ? 'date'
            : a.type === 'string' && a.name.includes('description') ? 'textarea' : 'text',
        required: !!a.mandatory, isList: !!a.list,
        options: a.values ? a.values.map(v => ({ value: v, label: v.replace(/_/g, ' ') })) : undefined,
    }));
}

export function parse422Error(error) {
    const msg = error?.body?.error || error?.body?.message || error?.message || '';
    if (msg.includes('Missing mandatory field')) {
        return msg.split(';').map(s => s.trim().replace(/.*Missing mandatory field:\s*/, '').replace(/_/g, ' ')).filter(Boolean);
    }
    return [];
}

export async function triggerWorkflow(workflowId, schema, item, inputFields = []) {
    return client.request('POST', '/api/v1/services/execute', {
        service_id: 'workflows', operation_id: 'execute_workflow',
        input: { workflow_id: workflowId, [`${schema}_uuid`]: item.uuid,
            ...Object.fromEntries(inputFields.map(f => [f, item[f] || ''])) },
    });
}

// ─────────────────────────────────────────────────────────
// InlineSelect (unchanged — no @react-native-picker/picker)
// ─────────────────────────────────────────────────────────

export function InlineSelect({ value, options = [], onChange, placeholder, required }) {
    const [expanded, setExpanded] = useState(false);
    const theme = useTheme();
    const selected = options.find(o => o.value === value);
    return (
        <View>
            <Pressable style={selS.btn} onPress={() => setExpanded(!expanded)}>
                <Text style={[selS.btnText, !value && { color: '#94a3b8' }]}>
                    {selected ? selected.label : placeholder || 'Select...'}
                </Text>
                <Text style={selS.arrow}>{expanded ? '▴' : '▾'}</Text>
            </Pressable>
            {expanded && (
                <View style={selS.list}>
                    {!required && (
                        <Pressable style={selS.clearBtn} onPress={() => { onChange(''); setExpanded(false); }}>
                            <Text style={selS.clearText}>✕ Clear</Text>
                        </Pressable>
                    )}
                    {options.map(o => (
                        <Pressable key={o.value}
                            style={[selS.item, value === o.value && { backgroundColor: theme.palette[50] }]}
                            onPress={() => { onChange(o.value); setExpanded(false); }}>
                            <Text style={[selS.itemText, value === o.value && { color: theme.primary, fontWeight: '700' }]}>
                                {value === o.value ? '✓  ' : '    '}{o.label}
                            </Text>
                        </Pressable>
                    ))}
                </View>
            )}
        </View>
    );
}

const selS = StyleSheet.create({
    btn: { backgroundColor: '#fff', borderWidth: 1, borderColor: '#e2e8f0', borderRadius: 12, padding: 14, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    btnText: { fontSize: 15, color: '#1e293b', flex: 1 },
    arrow: { fontSize: 14, color: '#94a3b8' },
    list: { backgroundColor: '#fff', borderWidth: 1, borderColor: '#e2e8f0', borderRadius: 12, marginTop: 4, overflow: 'hidden' },
    clearBtn: { padding: 12, borderBottomWidth: 1, borderBottomColor: '#f1f5f9' },
    clearText: { fontSize: 12, color: '#94a3b8' },
    item: { padding: 14, borderBottomWidth: 1, borderBottomColor: '#f1f5f9' },
    itemText: { fontSize: 14, color: '#1e293b' },
});

// ═══════════════════════════════════════════════════════════
// SCREENS — v3 visual overhaul
// ═══════════════════════════════════════════════════════════

// ─────────────────────────────────────────────────────────
// LoginScreen — themed
// ─────────────────────────────────────────────────────────

function LoginScreen({ navigation, route }) {
    const { appName, domain, project, signupMode } = route.params;
    const { login } = useAuth();
    const theme = useTheme();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    const handleLogin = async () => {
        if (!email || !password) { setError('Please enter email and password'); return; }
        setLoading(true); setError('');
        try { await login(domain, email, password, project); }
        catch (err) { setError(err.message || 'Login failed'); }
        finally { setLoading(false); }
    };

    return (
        <ScrollView contentContainerStyle={{ flex: 1, justifyContent: 'center', padding: 24, backgroundColor: '#fff' }}>
            <View style={{ alignItems: 'center', marginBottom: 40 }}>
                <View style={{ width: 72, height: 72, borderRadius: 20, backgroundColor: theme.palette[50],
                    alignItems: 'center', justifyContent: 'center', marginBottom: 16 }}>
                    <Text style={{ fontSize: 36 }}>🚀</Text>
                </View>
                <Text style={{ fontSize: 26, fontWeight: '800', color: '#1e293b' }}>{appName || 'App'}</Text>
                <Text style={{ fontSize: 14, color: '#94a3b8', marginTop: 6 }}>Sign in to your account</Text>
            </View>

            {error ? <View style={{ backgroundColor: '#fef2f2', borderRadius: 14, padding: 14, marginBottom: 16 }}>
                <Text style={{ color: '#991b1b', fontSize: 13, fontWeight: '500' }}>{error}</Text>
            </View> : null}

            <TextInput placeholder="Email address" value={email} onChangeText={setEmail}
                keyboardType="email-address" autoCapitalize="none" placeholderTextColor="#94a3b8"
                style={{ borderWidth: 1, borderColor: '#e2e8f0', borderRadius: 14, padding: 16, fontSize: 15, marginBottom: 12, backgroundColor: '#f8fafc', color: '#1e293b' }} />
            <TextInput placeholder="Password" value={password} onChangeText={setPassword}
                secureTextEntry returnKeyType="go" onSubmitEditing={handleLogin} placeholderTextColor="#94a3b8"
                style={{ borderWidth: 1, borderColor: '#e2e8f0', borderRadius: 14, padding: 16, fontSize: 15, marginBottom: 24, backgroundColor: '#f8fafc', color: '#1e293b' }} />

            <Pressable onPress={handleLogin} disabled={loading}
                style={{ backgroundColor: theme.primary, borderRadius: 14, padding: 17, alignItems: 'center',
                    opacity: loading ? 0.6 : 1, shadowColor: theme.primary, shadowOffset: { width: 0, height: 4 },
                    shadowOpacity: 0.25, shadowRadius: 8, elevation: 4 }}>
                <Text style={{ color: '#fff', fontWeight: '700', fontSize: 15 }}>
                    {loading ? 'Signing in...' : 'Sign In'}
                </Text>
            </Pressable>

            {signupMode && signupMode !== 'none' &&
                <Pressable onPress={() => navigation.navigate('Signup')} style={{ marginTop: 24, alignItems: 'center' }}>
                    <Text style={{ color: theme.primary, fontSize: 14, fontWeight: '600' }}>
                        {signupMode === 'invite_only' ? 'Have an invite code?' : 'Create Account'}
                    </Text>
                </Pressable>
            }
        </ScrollView>
    );
}

// ─────────────────────────────────────────────────────────
// SignupScreen — themed
// ─────────────────────────────────────────────────────────

function SignupScreen({ navigation, route }) {
    const { appName, domain, project, signupMode } = route.params;
    const { login } = useAuth();
    const theme = useTheme();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [name, setName] = useState('');
    const [code, setCode] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    const handleSignup = async () => {
        if (!email || !password) { setError('Email and password required'); return; }
        if (password.length < 8) { setError('Password must be 8+ characters'); return; }
        if (signupMode === 'invite_only' && !code) { setError('Invite code required'); return; }
        setLoading(true); setError('');
        try {
            const payload = { email, password, domain, project };
            if (name) payload.full_name = name;
            if (code) payload.invite_code = code;
            await client.request('POST', '/api/signup', payload);
            await login(domain, email, password, project);
        } catch (err) { setError(err.message || 'Signup failed'); }
        finally { setLoading(false); }
    };

    const inputStyle = { borderWidth: 1, borderColor: '#e2e8f0', borderRadius: 14, padding: 16, fontSize: 15, marginBottom: 12, backgroundColor: '#f8fafc', color: '#1e293b' };

    return (
        <ScrollView contentContainerStyle={{ flex: 1, justifyContent: 'center', padding: 24, backgroundColor: '#fff' }}>
            <Text style={{ fontSize: 26, fontWeight: '800', color: '#1e293b', textAlign: 'center', marginBottom: 8 }}>Create Account</Text>
            <Text style={{ fontSize: 14, color: '#94a3b8', textAlign: 'center', marginBottom: 28 }}>Join {appName}</Text>
            {error ? <View style={{ backgroundColor: '#fef2f2', borderRadius: 14, padding: 14, marginBottom: 16 }}>
                <Text style={{ color: '#991b1b', fontSize: 13 }}>{error}</Text>
            </View> : null}
            <TextInput placeholder="Full name (optional)" value={name} onChangeText={setName} placeholderTextColor="#94a3b8" style={inputStyle} />
            <TextInput placeholder="Email address" value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" placeholderTextColor="#94a3b8" style={inputStyle} />
            <TextInput placeholder="Password (8+ characters)" value={password} onChangeText={setPassword} secureTextEntry placeholderTextColor="#94a3b8" style={inputStyle} />
            {signupMode === 'invite_only' && <TextInput placeholder="Invite code" value={code} onChangeText={setCode} placeholderTextColor="#94a3b8" style={inputStyle} />}
            <Pressable onPress={handleSignup} disabled={loading}
                style={{ backgroundColor: theme.primary, borderRadius: 14, padding: 17, alignItems: 'center', opacity: loading ? 0.6 : 1, marginTop: 8 }}>
                <Text style={{ color: '#fff', fontWeight: '700', fontSize: 15 }}>{loading ? 'Creating...' : 'Create Account'}</Text>
            </Pressable>
            <Pressable onPress={() => navigation.goBack()} style={{ marginTop: 20, alignItems: 'center' }}>
                <Text style={{ color: theme.primary, fontSize: 14 }}>← Back to login</Text>
            </Pressable>
        </ScrollView>
    );
}

// ─────────────────────────────────────────────────────────
// DashboardScreen v3 — dashboardWidgets support + themed
// ─────────────────────────────────────────────────────────

function DashboardScreen({ navigation, route }) {
    const { tabs, dashboardWidgets } = route.params;
    const theme = useTheme();
    const [stats, setStats] = useState({});
    const [allData, setAllData] = useState({});
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);

    const load = async () => {
        const readable = tabs.filter(t => client.can('read', t.schema));
        const results = await Promise.all(readable.map(async t => {
            try { const data = await client.getObjects(t.schema); return { schema: t.schema, data }; }
            catch { return { schema: t.schema, data: [] }; }
        }));
        const s = {}; const d = {};
        results.forEach(r => { s[r.schema] = r.data.length; d[r.schema] = r.data; });
        setStats(s); setAllData(d); setLoading(false);
    };

    useEffect(() => { load(); }, []);
    const onRefresh = async () => { setRefreshing(true); await load(); setRefreshing(false); };

    // Compute dashboardWidgets if provided
    let widgets = [];
    if (dashboardWidgets && !loading) {
        widgets = dashboardWidgets.map(w => {
            let data = allData[w.schema] || [];
            if (w.filter) data = data.filter(item => Object.keys(w.filter).every(k => item[k] === w.filter[k]));
            let value;
            if (w.aggregate === 'sum' && w.field) value = data.reduce((s, i) => s + (parseFloat(i[w.field]) || 0), 0);
            else if (w.aggregate === 'avg' && w.field) { const t = data.reduce((s, i) => s + (parseFloat(i[w.field]) || 0), 0); value = data.length > 0 ? t / data.length : 0; }
            else value = data.length;
            let formatted;
            if (w.format === 'currency') formatted = formatCurrency(value);
            else if (w.format === 'percent') formatted = value.toFixed(1) + '%';
            else formatted = formatNumber(value);
            return { label: w.label, value: formatted, icon: w.icon || '📊' };
        });
    }

    return (
        <ScrollView style={{ flex: 1, backgroundColor: '#f8fafc' }}
            refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.primary} />}>
            <View style={{ padding: 20 }}>
                <Text style={{ fontSize: 24, fontWeight: '800', color: '#1e293b', marginBottom: 4 }}>Dashboard</Text>
                <Text style={{ fontSize: 13, color: '#94a3b8', marginBottom: 20 }}>Overview of your data</Text>

                {loading ? <ActivityIndicator size="large" color={theme.primary} /> :
                    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 12 }}>
                        {(widgets.length > 0 ? widgets : tabs.filter(t => client.can('read', t.schema)).map(t => ({
                            label: t.label, value: formatNumber(stats[t.schema] || 0), icon: t.icon
                        }))).map((w, i) => (
                            <Pressable key={i}
                                onPress={widgets.length === 0 ? () => navigation.navigate(tabs[i]?.id + '_Tab') : undefined}
                                style={{ backgroundColor: '#fff', borderRadius: 18, padding: 18, width: '47%',
                                    borderWidth: 1, borderColor: '#f1f5f9', borderLeftWidth: 3, borderLeftColor: theme.primary,
                                    shadowColor: '#000', shadowOpacity: 0.03, shadowRadius: 8, elevation: 2 }}>
                                <Text style={{ fontSize: 22, marginBottom: 4 }}>{w.icon}</Text>
                                <Text style={{ fontSize: 28, fontWeight: '900', color: '#1e293b', marginTop: 2 }}>{w.value}</Text>
                                <Text style={{ fontSize: 11, color: '#94a3b8', fontWeight: '500', marginTop: 2 }}>{w.label}</Text>
                            </Pressable>
                        ))}
                    </View>
                }
            </View>
        </ScrollView>
    );
}

// ─────────────────────────────────────────────────────────
// ListScreen v3 — image-forward cards, themed, cardTemplate
// ─────────────────────────────────────────────────────────

function ListScreen({ navigation, route }) {
    const { tab, workflowMap } = route.params;
    const theme = useTheme();
    const [items, setItems] = useState([]);
    const [search, setSearch] = useState('');
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);

    const canCreate = client.can('create', tab.schema);
    const canDelete = client.can('delete', tab.schema);

    const load = async () => {
        try { setItems(await client.getObjects(tab.schema)); }
        catch {} finally { setLoading(false); }
    };

    useEffect(() => { load(); }, [tab.schema]);
    useEffect(() => {
        const unsub = navigation.addListener('focus', () => { load(); });
        return unsub;
    }, [navigation]);

    const onRefresh = async () => { setRefreshing(true); await load(); setRefreshing(false); };

    const filtered = search
        ? items.filter(i => JSON.stringify(i).toLowerCase().includes(search.toLowerCase()))
        : items;

    // Determine card layout
    const tmpl = tab.cardTemplate;
    const imgAttr = tmpl ? tab.attrs.find(a => a.name === tmpl.image) : tab.attrs.find(a => a.type === 'Image' && !a.list);
    const hasImage = !!imgAttr;
    const featuredAttrs = tab.attrs.filter(a => a.featured).slice(0, 2);

    const handleDelete = (item) => {
        Alert.alert('Delete?', `Delete "${item.display_name || item.name}"?`, [
            { text: 'Cancel', style: 'cancel' },
            { text: 'Delete', style: 'destructive', onPress: async () => {
                try { await client.deleteObject(tab.schema, item.uuid, item); load(); }
                catch (err) { Alert.alert('Error', err.message); }
            }},
        ]);
    };

    const renderItem = ({ item }) => {
        const imgUrl = imgAttr ? resolveImageUrl(item[imgAttr.name]) : '';
        const title = (tmpl?.title && item[tmpl.title]) || item.display_name || item.name || '';
        const subtitle = tmpl?.subtitle && item[tmpl.subtitle] ? String(item[tmpl.subtitle]) : '';
        const priceAttr = tmpl?.price || tab.attrs.find(a => (a.type === 'float' || a.type === 'integer') && ['price','cost','amount','total','rent','rate','fee'].some(k => a.name.includes(k)))?.name;
        const priceVal = priceAttr && item[priceAttr] != null ? formatCurrency(item[priceAttr]) + (tmpl?.priceSuffix || '') : '';
        const statusVal = item.status || (tmpl?.badge && item[tmpl.badge]) || '';
        const statusStyle = getStatusStyle(statusVal);

        if (hasImage && imgUrl) {
            // Image card — two-column grid style
            return (
                <Pressable
                    onPress={() => navigation.navigate(tab.id + '_Detail', { item, tab, workflowMap })}
                    onLongPress={canDelete ? () => handleDelete(item) : undefined}
                    style={{ backgroundColor: '#fff', borderRadius: 16, marginBottom: 12, borderWidth: 1,
                        borderColor: '#f1f5f9', overflow: 'hidden', shadowColor: '#000', shadowOpacity: 0.04,
                        shadowRadius: 8, elevation: 2 }}>
                    <Image source={{ uri: imgUrl }}
                        style={{ width: '100%', height: 160, backgroundColor: '#f1f5f9' }} />
                    {priceVal ? <View style={{ position: 'absolute', top: 12, right: 12, backgroundColor: 'rgba(255,255,255,0.92)',
                        borderRadius: 10, paddingHorizontal: 10, paddingVertical: 5 }}>
                        <Text style={{ fontSize: 13, fontWeight: '800', color: '#1e293b' }}>{priceVal}</Text>
                    </View> : null}
                    {statusVal ? <View style={{ position: 'absolute', top: 12, left: 12,
                        backgroundColor: statusStyle.bg, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3 }}>
                        <Text style={{ fontSize: 10, fontWeight: '700', color: statusStyle.text }}>{statusVal.replace(/_/g, ' ')}</Text>
                    </View> : null}
                    <View style={{ padding: 14 }}>
                        <Text style={{ fontWeight: '700', fontSize: 15, color: '#1e293b' }}>{title}</Text>
                        {subtitle ? <Text style={{ fontSize: 12, color: '#94a3b8', marginTop: 2 }}>{subtitle}</Text> : null}
                        {featuredAttrs.length > 0 && !tmpl && <Text style={{ fontSize: 11, color: '#94a3b8', marginTop: 4 }}>
                            {featuredAttrs.map(a => item[a.name] != null ? formatFieldValue(a, item[a.name]) : null).filter(Boolean).join(' · ')}
                        </Text>}
                    </View>
                </Pressable>
            );
        }

        // Standard list card
        const hasPerson = tab.attrs.some(a => a.name.includes('email') || a.name.includes('phone'));
        const initials = title.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();

        return (
            <Pressable
                onPress={() => navigation.navigate(tab.id + '_Detail', { item, tab, workflowMap })}
                onLongPress={canDelete ? () => handleDelete(item) : undefined}
                style={{ backgroundColor: '#fff', borderRadius: 14, padding: 14, marginBottom: 10, borderWidth: 1,
                    borderColor: '#f1f5f9', flexDirection: 'row', alignItems: 'center', gap: 12,
                    borderLeftWidth: 3, borderLeftColor: theme.palette[300] }}>
                {hasPerson ? (
                    <View style={{ width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center',
                        backgroundColor: theme.palette[100] }}>
                        <Text style={{ fontSize: 14, fontWeight: '700', color: theme.primary }}>{initials || '?'}</Text>
                    </View>
                ) : (
                    <View style={{ width: 40, height: 40, borderRadius: 12, backgroundColor: theme.palette[50],
                        alignItems: 'center', justifyContent: 'center' }}>
                        <Text style={{ fontSize: 18 }}>{tab.icon}</Text>
                    </View>
                )}
                <View style={{ flex: 1 }}>
                    <Text style={{ fontWeight: '700', fontSize: 14, color: '#1e293b' }}>{title}</Text>
                    {subtitle ? <Text style={{ fontSize: 12, color: '#94a3b8', marginTop: 1 }}>{subtitle}</Text> : null}
                    {featuredAttrs.length > 0 && <Text style={{ fontSize: 11, color: '#b0b8c4', marginTop: 2 }}>
                        {featuredAttrs.map(a => item[a.name] != null ? formatFieldValue(a, item[a.name]) : null).filter(Boolean).join(' · ')}
                    </Text>}
                    {statusVal ? <View style={{ backgroundColor: statusStyle.bg, borderRadius: 8, paddingHorizontal: 8,
                        paddingVertical: 2, alignSelf: 'flex-start', marginTop: 4 }}>
                        <Text style={{ fontSize: 10, fontWeight: '700', color: statusStyle.text }}>{statusVal.replace(/_/g, ' ')}</Text>
                    </View> : null}
                </View>
                {priceVal ? <Text style={{ fontSize: 14, fontWeight: '800', color: theme.palette[700] }}>{priceVal}</Text>
                    : <Text style={{ color: '#cbd5e1', fontSize: 18 }}>›</Text>}
            </Pressable>
        );
    };

    return (
        <View style={{ flex: 1, backgroundColor: '#f8fafc' }}>
            <View style={{ paddingHorizontal: 16, paddingTop: 12, paddingBottom: 8, flexDirection: 'row', gap: 10, alignItems: 'center' }}>
                <View style={{ flex: 1, backgroundColor: '#fff', borderRadius: 12, flexDirection: 'row', alignItems: 'center',
                    borderWidth: 1, borderColor: '#e2e8f0', paddingHorizontal: 12 }}>
                    <Text style={{ color: '#94a3b8', marginRight: 8 }}>🔍</Text>
                    <TextInput placeholder={`Search ${tab.label}...`} value={search} onChangeText={setSearch}
                        placeholderTextColor="#94a3b8"
                        style={{ flex: 1, paddingVertical: 12, fontSize: 14, color: '#1e293b' }} />
                </View>
                {canCreate && <Pressable
                    onPress={() => navigation.navigate(tab.id + '_Form', { tab, mode: 'create' })}
                    style={{ backgroundColor: theme.primary, borderRadius: 12, paddingHorizontal: 16, paddingVertical: 13,
                        shadowColor: theme.primary, shadowOpacity: 0.25, shadowRadius: 8, elevation: 4 }}>
                    <Text style={{ color: '#fff', fontWeight: '700', fontSize: 15 }}>+</Text>
                </Pressable>}
            </View>
            {loading ? <ActivityIndicator style={{ marginTop: 40 }} color={theme.primary} /> :
                filtered.length === 0 ?
                    <View style={{ alignItems: 'center', paddingTop: 60 }}>
                        <Text style={{ fontSize: 48, opacity: 0.15, marginBottom: 8 }}>{tab.icon}</Text>
                        <Text style={{ color: '#94a3b8', fontSize: 15, fontWeight: '600' }}>No {tab.label.toLowerCase()} yet</Text>
                        <Text style={{ color: '#cbd5e1', fontSize: 13, marginTop: 4 }}>Create your first record</Text>
                        {canCreate && <Pressable
                            onPress={() => navigation.navigate(tab.id + '_Form', { tab, mode: 'create' })}
                            style={{ backgroundColor: theme.primary, borderRadius: 12, paddingHorizontal: 24, paddingVertical: 14, marginTop: 20 }}>
                            <Text style={{ color: '#fff', fontWeight: '700' }}>+ Create First</Text>
                        </Pressable>}
                    </View>
                :
                    <FlatList data={filtered} keyExtractor={item => item.uuid}
                        renderItem={renderItem}
                        contentContainerStyle={{ padding: 16 }}
                        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.primary} />} />
            }
        </View>
    );
}

// ─────────────────────────────────────────────────────────
// DetailScreen v3 — actionButtons, themed fields
// ─────────────────────────────────────────────────────────

function DetailScreen({ navigation, route }) {
    const { item, tab, workflowMap, actionButtons: actionBtns } = route.params;
    const theme = useTheme();
    const canUpdate = client.can('update', tab.schema);
    const canDelete = client.can('delete', tab.schema);

    const heroImgAttr = tab.attrs.find(a => a.type === 'Image' && !a.list);
    const galleryAttr = tab.attrs.find(a => a.type === 'Image' && a.list);
    const heroUrl = heroImgAttr ? resolveImageUrl(item[heroImgAttr.name]) : '';
    const galleryItems = galleryAttr ? (item[galleryAttr.name] || []) : [];

    const displayFields = tab.attrs.filter(a =>
        a.type !== 'Image' && a.type !== 'File' &&
        !['workflow_status', 'processed_at', 'fq_name', 'uuid'].includes(a.name));

    const wf = workflowMap?.[tab.schema];
    const [triggering, setTriggering] = useState(false);
    const [sending, setSending] = useState({});

    const handleTrigger = async () => {
        setTriggering(true);
        try {
            await triggerWorkflow(wf.workflowId, tab.schema, item, wf.inputFields);
            Alert.alert('Success', wf.triggerLabel ? wf.triggerLabel + ' completed' : 'Workflow triggered');
        } catch (err) { Alert.alert('Error', err.message); }
        finally { setTriggering(false); }
    };

    const handleDelete = () => {
        Alert.alert('Delete?', `Delete "${item.display_name || item.name}"?`, [
            { text: 'Cancel', style: 'cancel' },
            { text: 'Delete', style: 'destructive', onPress: async () => {
                try { await client.deleteObject(tab.schema, item.uuid, item); navigation.goBack(); }
                catch (err) { Alert.alert('Error', err.message); }
            }},
        ]);
    };

    // actionButtons handler
    const resolveTemplate = (template, data) => {
        if (!template) return '';
        return template.replace(/\{\{(\w+)\}\}/g, (m, key) => data[key] || data.display_name || data.name || m);
    };

    const handleAction = async (btn, idx) => {
        setSending(p => ({ ...p, [idx]: true }));
        try {
            if (btn.service === 'email' && btn.emailField && item[btn.emailField]) {
                await services.email.send({ to: item[btn.emailField], subject: resolveTemplate(btn.subject || 'Notification', item), bodyHtml: '<p>' + resolveTemplate(btn.bodyTemplate || 'Hello!', item) + '</p>' });
            } else if (btn.service === 'sms' && btn.phoneField && item[btn.phoneField]) {
                await services.sms.send({ to: item[btn.phoneField], body: resolveTemplate(btn.bodyTemplate || 'Hello!', item) });
            } else { Alert.alert('Missing', 'Contact field not found'); return; }
            Alert.alert('Success', btn.successMessage || btn.label + ' sent!');
        } catch (err) { Alert.alert('Failed', err.message); }
        finally { setSending(p => ({ ...p, [idx]: false })); }
    };

    const schemaActions = actionBtns?.[tab.schema] || [];

    return (
        <ScrollView style={{ flex: 1, backgroundColor: '#fff' }}>
            {heroUrl ? <Image source={{ uri: heroUrl }} style={{ width: '100%', height: 240 }} /> : null}
            <View style={{ padding: 20 }}>
                <Text style={{ fontSize: 24, fontWeight: '800', color: '#1e293b' }}>{item.display_name || item.name}</Text>
                <View style={{ flexDirection: 'row', gap: 8, marginTop: 8, flexWrap: 'wrap' }}>
                    {item.status && (() => { const s = getStatusStyle(item.status); return (
                        <View style={{ backgroundColor: s.bg, borderRadius: 12, paddingHorizontal: 10, paddingVertical: 4 }}>
                            <Text style={{ fontSize: 11, fontWeight: '700', color: s.text }}>{item.status.replace(/_/g, ' ')}</Text>
                        </View>
                    ); })()}
                    {item.workflow_status && (() => { const ok = item.workflow_status === 'processed'; return (
                        <View style={{ backgroundColor: ok ? '#dcfce7' : '#fee2e2', borderRadius: 12, paddingHorizontal: 10, paddingVertical: 4 }}>
                            <Text style={{ fontSize: 11, fontWeight: '700', color: ok ? '#166534' : '#991b1b' }}>
                                {ok ? '✓ Processed' : '✕ Failed'}
                            </Text>
                        </View>
                    ); })()}
                </View>

                {/* Workflow trigger */}
                {wf && client.can('create', tab.schema) &&
                    <Pressable onPress={handleTrigger} disabled={triggering}
                        style={{ backgroundColor: theme.palette[50], borderRadius: 14, padding: 16, marginTop: 16, alignItems: 'center' }}>
                        <Text style={{ color: theme.palette[700], fontWeight: '700', fontSize: 13 }}>
                            {triggering ? '⏳ Running...' : (wf.triggerLabel || '⚡ Run Workflow')}
                        </Text>
                    </Pressable>
                }

                {/* Action buttons (declarative) */}
                {schemaActions.length > 0 && (
                    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 16 }}>
                        {schemaActions.map((btn, idx) => {
                            const fieldName = btn.emailField || btn.phoneField;
                            if (fieldName && !item[fieldName]) return null;
                            return (
                                <Pressable key={idx} onPress={() => handleAction(btn, idx)} disabled={!!sending[idx]}
                                    style={{ backgroundColor: theme.palette[50], borderRadius: 12, paddingHorizontal: 16,
                                        paddingVertical: 12, opacity: sending[idx] ? 0.6 : 1 }}>
                                    <Text style={{ color: theme.palette[700], fontWeight: '600', fontSize: 13 }}>
                                        {sending[idx] ? '⏳ Sending...' : btn.label}
                                    </Text>
                                </Pressable>
                            );
                        })}
                    </View>
                )}

                {/* Field grid */}
                <View style={{ marginTop: 20, gap: 8 }}>
                    {displayFields.map(attr => (
                        <View key={attr.name} style={{ backgroundColor: theme.palette[50], borderRadius: 14, padding: 14,
                            borderWidth: 1, borderColor: theme.palette[100] }}>
                            <Text style={{ fontSize: 10, color: theme.palette[400], textTransform: 'uppercase', letterSpacing: 0.6, marginBottom: 2 }}>
                                {attr.name.replace(/_/g, ' ')}
                            </Text>
                            <Text style={{ fontSize: 14, fontWeight: '500', color: '#1e293b' }}>
                                {formatFieldValue(attr, item[attr.name])}
                            </Text>
                        </View>
                    ))}
                </View>

                {/* Gallery */}
                {galleryItems.length > 0 && <View style={{ marginTop: 20 }}>
                    <Text style={{ fontWeight: '700', marginBottom: 8, color: '#1e293b' }}>Gallery</Text>
                    <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                        {galleryItems.map((img, i) => {
                            const url = resolveImageUrl(img);
                            return url ? <Image key={i} source={{ uri: url }}
                                style={{ width: 160, height: 110, borderRadius: 12, marginRight: 10 }} /> : null;
                        })}
                    </ScrollView>
                </View>}

                {/* Actions */}
                <View style={{ flexDirection: 'row', gap: 10, marginTop: 24 }}>
                    {canUpdate && <Pressable
                        onPress={() => navigation.navigate(tab.id + '_Form', { tab, mode: 'edit', item })}
                        style={{ flex: 1, backgroundColor: theme.primary, borderRadius: 14, padding: 15, alignItems: 'center' }}>
                        <Text style={{ color: '#fff', fontWeight: '700' }}>✏️ Edit</Text>
                    </Pressable>}
                    {canDelete && <Pressable onPress={handleDelete}
                        style={{ flex: 1, backgroundColor: '#fef2f2', borderRadius: 14, padding: 15, alignItems: 'center' }}>
                        <Text style={{ color: '#991b1b', fontWeight: '700' }}>🗑️ Delete</Text>
                    </Pressable>}
                </View>
            </View>
        </ScrollView>
    );
}

// ─────────────────────────────────────────────────────────
// FormScreen — themed, unchanged logic
// ─────────────────────────────────────────────────────────

function FormScreen({ navigation, route }) {
    const { tab, mode, item: existingItem } = route.params;
    const theme = useTheme();
    const [formData, setFormData] = useState(existingItem || {});
    const [saving, setSaving] = useState(false);
    const [error, setError] = useState('');
    const [parents, setParents] = useState([]);
    const fields = buildFieldDefs(tab.attrs);

    useEffect(() => {
        if (tab.parentSchema && mode === 'create') {
            client.getObjects(tab.parentSchema).then(setParents).catch(() => {});
        }
    }, []);

    const handleChange = (name, value) => setFormData(prev => ({ ...prev, [name]: value }));

    const handleSave = async () => {
        const missing = fields.filter(f => f.required && !formData[f.name]?.toString().trim()).map(f => f.label);
        if (missing.length) { setError('Required: ' + missing.join(', ')); return; }
        setSaving(true); setError('');
        try {
            if (mode === 'edit' && existingItem) {
                await client.updateObject(tab.schema, existingItem.uuid, formData, existingItem);
            } else {
                const data = { ...formData };
                if (tab.parentSchema && data._parent_uuid) {
                    data.parent_uuid = data._parent_uuid; data.parent_type = tab.parentSchema;
                    delete data._parent_uuid;
                }
                await client.createObject(tab.schema, data);
            }
            navigation.goBack();
        } catch (err) {
            const parsed = parse422Error(err);
            setError(parsed.length ? 'Missing: ' + parsed.join(', ') : err.message);
        } finally { setSaving(false); }
    };

    const inputStyle = { borderWidth: 1, borderColor: '#e2e8f0', borderRadius: 14, padding: 16, fontSize: 15, backgroundColor: '#f8fafc', color: '#1e293b' };

    return (
        <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView style={{ flex: 1, backgroundColor: '#fff' }} contentContainerStyle={{ padding: 20 }}>
            <Text style={{ fontSize: 22, fontWeight: '800', color: '#1e293b', marginBottom: 20 }}>
                {mode === 'edit' ? 'Edit' : 'New'} {tab.label.replace(/s$/, '')}
            </Text>
            {error ? <View style={{ backgroundColor: '#fef2f2', borderRadius: 14, padding: 14, marginBottom: 16 }}>
                <Text style={{ color: '#991b1b', fontSize: 13 }}>{error}</Text>
            </View> : null}
            {tab.parentSchema && mode === 'create' && parents.length > 0 &&
                <View style={{ marginBottom: 16 }}>
                    <Text style={{ fontSize: 13, fontWeight: '600', color: '#1e293b', marginBottom: 6 }}>
                        {tab.parentLabel || tab.parentSchema} <Text style={{ color: '#ef4444' }}>*</Text>
                    </Text>
                    <InlineSelect value={formData._parent_uuid || ''}
                        options={parents.map(p => ({ value: p.uuid, label: p.display_name || p.name }))}
                        onChange={v => handleChange('_parent_uuid', v)}
                        placeholder={'Select ' + (tab.parentLabel || tab.parentSchema) + '...'} required />
                </View>
            }
            {fields.map(f => (
                <View key={f.name} style={{ marginBottom: 16 }}>
                    <Text style={{ fontSize: 13, fontWeight: '600', color: '#1e293b', marginBottom: 6 }}>
                        {f.label} {f.required && <Text style={{ color: '#ef4444' }}>*</Text>}
                    </Text>
                    {f.type === 'select' ?
                        <InlineSelect value={formData[f.name] || ''} options={f.options || []}
                            onChange={v => handleChange(f.name, v)} placeholder="Select..." required={f.required} />
                    : f.type === 'bool' ?
                        <Switch value={!!formData[f.name]} onValueChange={v => handleChange(f.name, v)}
                            trackColor={{ true: theme.primary, false: '#e2e8f0' }} />
                    : f.type === 'image' || f.type === 'file' ?
                        <View style={{ backgroundColor: '#f8fafc', borderRadius: 14, padding: 18, alignItems: 'center' }}>
                            <Text style={{ color: '#94a3b8', fontSize: 13 }}>📷 Upload via web portal</Text>
                        </View>
                    : f.type === 'textarea' ?
                        <TextInput value={formData[f.name] || ''} onChangeText={v => handleChange(f.name, v)}
                            multiline numberOfLines={4} textAlignVertical="top" placeholderTextColor="#94a3b8"
                            style={[inputStyle, { minHeight: 100 }]} />
                    :
                        <TextInput value={formData[f.name] != null ? String(formData[f.name]) : ''}
                            onChangeText={v => handleChange(f.name, f.type === 'number' ? (v === '' ? '' : parseFloat(v) || '') : v)}
                            keyboardType={f.type === 'number' ? 'decimal-pad' : f.name.includes('email') ? 'email-address' : 'default'}
                            autoCapitalize={f.name.includes('email') ? 'none' : 'sentences'}
                            placeholderTextColor="#94a3b8"
                            style={inputStyle} />
                    }
                </View>
            ))}
            <Pressable onPress={handleSave} disabled={saving}
                style={{ backgroundColor: theme.primary, borderRadius: 14, padding: 17, alignItems: 'center',
                    opacity: saving ? 0.6 : 1, marginTop: 8, marginBottom: 40 }}>
                <Text style={{ color: '#fff', fontWeight: '700', fontSize: 15 }}>
                    {saving ? 'Saving...' : (mode === 'edit' ? 'Save Changes' : 'Create')}
                </Text>
            </Pressable>
        </ScrollView>
        </KeyboardAvoidingView>
    );
}

// ─────────────────────────────────────────────────────────
// AIChatScreen — themed
// ─────────────────────────────────────────────────────────

function AIChatScreen() {
    const theme = useTheme();
    const [messages, setMessages] = useState([
        { role: 'assistant', text: 'Hi! I\'m your AI assistant. Ask me anything about your data.' }
    ]);
    const [input, setInput] = useState('');
    const [loading, setLoading] = useState(false);
    const [sessionId, setSessionId] = useState(null);

    const handleSend = async () => {
        const msg = input.trim();
        if (!msg || loading) return;
        setInput('');
        setMessages(prev => [...prev, { role: 'user', text: msg }]);
        setLoading(true);
        try {
            const result = await aiChat(msg, sessionId);
            setSessionId(result.sessionId);
            setMessages(prev => [...prev, { role: 'assistant', text: result.response || 'No response.' }]);
        } catch (err) {
            setMessages(prev => [...prev, { role: 'assistant', text: '⚠️ ' + (err.message || 'AI request failed') }]);
        } finally { setLoading(false); }
    };

    return (
        <View style={{ flex: 1, backgroundColor: '#fff' }}>
            <FlatList data={messages} keyExtractor={(_, i) => String(i)}
                contentContainerStyle={{ padding: 16, paddingBottom: 80 }}
                renderItem={({ item: msg }) => (
                    <View style={{ alignItems: msg.role === 'user' ? 'flex-end' : 'flex-start', marginBottom: 12 }}>
                        <View style={{ maxWidth: '80%', padding: 12, borderRadius: 16,
                            backgroundColor: msg.role === 'user' ? theme.primary : '#f1f5f9',
                            borderBottomRightRadius: msg.role === 'user' ? 4 : 16,
                            borderBottomLeftRadius: msg.role === 'user' ? 16 : 4 }}>
                            <Text style={{ color: msg.role === 'user' ? '#fff' : '#1e293b', fontSize: 14, lineHeight: 20 }}>
                                {msg.text}
                            </Text>
                        </View>
                    </View>
                )} />
            {loading && <View style={{ padding: 12, alignItems: 'center' }}>
                <ActivityIndicator size="small" color={theme.primary} />
            </View>}
            <View style={{ position: 'absolute', bottom: 0, left: 0, right: 0, backgroundColor: '#fff',
                borderTopWidth: 1, borderTopColor: '#f1f5f9', padding: 12, flexDirection: 'row', gap: 8 }}>
                <TextInput value={input} onChangeText={setInput} placeholder="Ask anything..."
                    returnKeyType="send" onSubmitEditing={handleSend} placeholderTextColor="#94a3b8"
                    style={{ flex: 1, borderWidth: 1, borderColor: '#e2e8f0', borderRadius: 14, paddingHorizontal: 14, paddingVertical: 12, fontSize: 14, color: '#1e293b' }} />
                <Pressable onPress={handleSend} disabled={loading || !input.trim()}
                    style={{ backgroundColor: loading ? '#e2e8f0' : theme.primary, borderRadius: 14,
                        width: 46, height: 46, alignItems: 'center', justifyContent: 'center' }}>
                    <Text style={{ color: '#fff', fontWeight: '700', fontSize: 16 }}>↑</Text>
                </Pressable>
            </View>
        </View>
    );
}

// ─────────────────────────────────────────────────────────
// SettingsScreen — themed
// ─────────────────────────────────────────────────────────

function SettingsScreen() {
    const { logout } = useAuth();
    const theme = useTheme();
    const handleLogout = () => {
        Alert.alert('Sign Out', 'Are you sure?', [
            { text: 'Cancel', style: 'cancel' },
            { text: 'Sign Out', style: 'destructive', onPress: logout },
        ]);
    };
    return (
        <ScrollView style={{ flex: 1, backgroundColor: '#f8fafc' }} contentContainerStyle={{ padding: 20 }}>
            <View style={{ backgroundColor: '#fff', borderRadius: 18, padding: 20, marginBottom: 16, borderWidth: 1, borderColor: '#f1f5f9' }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
                    <View style={{ width: 52, height: 52, borderRadius: 26, backgroundColor: theme.palette[50], alignItems: 'center', justifyContent: 'center' }}>
                        <Text style={{ fontSize: 20, fontWeight: '700', color: theme.primary }}>
                            {(client.userInfo?.email || '?')[0].toUpperCase()}
                        </Text>
                    </View>
                    <View>
                        <Text style={{ fontWeight: '700', fontSize: 16, color: '#1e293b' }}>
                            {client.userInfo?.fullName || client.userInfo?.email || 'User'}
                        </Text>
                        <Text style={{ fontSize: 13, color: '#94a3b8', marginTop: 2 }}>{client.userInfo?.email}</Text>
                        <Text style={{ fontSize: 11, color: theme.primary, fontWeight: '600', marginTop: 2 }}>
                            {(client.userInfo?.role || '').replace(/_/g, ' ')}
                        </Text>
                    </View>
                </View>
            </View>
            <Pressable onPress={handleLogout}
                style={{ backgroundColor: '#fef2f2', borderRadius: 16, padding: 18, alignItems: 'center' }}>
                <Text style={{ color: '#991b1b', fontWeight: '700', fontSize: 14 }}>🚪 Sign Out</Text>
            </Pressable>
        </ScrollView>
    );
}

// ═══════════════════════════════════════════════════════════
// MobileShell — THE MAIN ENTRY POINT
// ═══════════════════════════════════════════════════════════

const MobileConfigContext = React.createContext({});
const useMobileConfig = () => React.useContext(MobileConfigContext);

function _AuthStack() {
    const cfg = useMobileConfig();
    return (
        <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="Login" component={LoginScreen}
                initialParams={{ appName: cfg.appName, domain: cfg.domain, project: cfg.project, signupMode: cfg.signupMode }} />
            {cfg.signupMode && cfg.signupMode !== 'none' &&
                <Stack.Screen name="Signup" component={SignupScreen}
                    initialParams={{ appName: cfg.appName, domain: cfg.domain, project: cfg.project, signupMode: cfg.signupMode }} />
            }
        </Stack.Navigator>
    );
}

function _SchemaStack({ route }) {
    const cfg = useMobileConfig();
    const theme = useTheme();
    const tab = route.params.tab;
    return (
        <Stack.Navigator screenOptions={{ headerBackTitleVisible: false,
            headerTintColor: theme.primary, headerTitleStyle: { fontWeight: '700' } }}>
            <Stack.Screen name={tab.id + '_List'} component={tab.view === 'transactional' ? TransactionalListScreen : ListScreen}
                options={{ title: tab.label }}
                initialParams={{ tab, workflowMap: cfg.workflowMap || {} }} />
            <Stack.Screen name={tab.id + '_Detail'} component={tab.view === 'transactional' ? TransactionalDetailScreen : DetailScreen}
                options={{ title: 'Details' }}
                initialParams={{ actionButtons: cfg.actionButtons }} />
            <Stack.Screen name={tab.id + '_Form'} component={FormScreen}
                options={({ route: r }) => ({ title: (r.params.mode === 'edit' ? 'Edit' : 'New') + ' ' + tab.label.replace(/s$/, '') })} />
        </Stack.Navigator>
    );
}

function _MainTabs() {
    const cfg = useMobileConfig();
    const theme = useTheme();
    const tabs = cfg.tabs || [];
    const readableTabs = tabs.filter(t => client.can('read', t.schema));
    return (
        <Tab.Navigator screenOptions={{ headerShown: false,
            tabBarActiveTintColor: theme.primary, tabBarInactiveTintColor: '#94a3b8',
            tabBarLabelStyle: { fontSize: 10, fontWeight: '600' },
            tabBarStyle: { borderTopColor: '#f1f5f9', paddingTop: 4 } }}>
            <Tab.Screen name="Home" component={DashboardScreen}
                options={{ tabBarIcon: () => <Text style={{ fontSize: 18 }}>🏠</Text>, tabBarLabel: 'Home' }}
                initialParams={{ tabs, dashboardWidgets: cfg.dashboardWidgets }} />
            {readableTabs.map(tab => (
                <Tab.Screen key={tab.id} name={tab.id + '_Tab'} component={_SchemaStack}
                    options={{ tabBarIcon: () => <Text style={{ fontSize: 16 }}>{tab.icon}</Text>, tabBarLabel: tab.label }}
                    initialParams={{ tab }} />
            ))}
            <Tab.Screen name="AI" component={AIChatScreen}
                options={{ tabBarIcon: () => <Text style={{ fontSize: 16 }}>🤖</Text>, tabBarLabel: 'AI',
                    headerShown: true, headerTitle: 'AI Assistant' }} />
            <Tab.Screen name="Settings" component={SettingsScreen}
                options={{ tabBarIcon: () => <Text style={{ fontSize: 16 }}>⚙️</Text>, tabBarLabel: 'Settings', headerShown: true }} />
        </Tab.Navigator>
    );
}

function _Root() {
    const { isReady, isAuthenticated } = useAuth();
    const theme = useTheme();
    if (!isReady) return (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#fff' }}>
            <ActivityIndicator size="large" color={theme.primary} />
            <Text style={{ marginTop: 12, color: '#94a3b8', fontSize: 13 }}>Loading...</Text>
        </View>
    );
    return (
        <NavigationContainer>
            {isAuthenticated ? <_MainTabs /> : <_AuthStack />}
        </NavigationContainer>
    );
}

export function MobileShell(config) {
    setConfig({
        serverUrl: config.serverUrl, domain: config.domain,
        project: config.project, appName: config.appName,
    });
    // SUPERO_MOBILE_TXN_AUTOLOAD_SHELL_V1
    // Fire-and-forget eager load of the transactional registry. This
    // handles the case where transactional screens render before
    // AuthProvider's auto-load useEffect fires (e.g. pre-auth landing
    // screens that render transactional public data). Idempotent.
    try {
        SuperoTransactionalRegistry.load();
    } catch (e) {
        if (typeof console !== 'undefined' && console.warn) {
            console.warn('[supero-mobile] MobileShell auto-load registry failed:', e);
        }
    }


    const primary = config.theme?.primary || '#6366f1';
    const palette = generatePalette(primary);
    const themeValue = { primary, palette };

    return (/* SUPERO_BOUNDARY_WRAP_BEGIN */<SuperoErrorBoundary>
        <ThemeContext.Provider value={themeValue}>
            <MobileConfigContext.Provider value={config}>
                <AuthProvider>
                    <StatusBar barStyle="dark-content" />
                    <_Root />
                </AuthProvider>
            </MobileConfigContext.Provider>
        </ThemeContext.Provider>
    </SuperoErrorBoundary>/* SUPERO_BOUNDARY_WRAP_END */);
}

// ─────────────────────────────────────────────────────────
// Version
// ─────────────────────────────────────────────────────────

// ═══════════════════════════════════════════════════════════════════════════
// SERVICES UI v1 — Mobile (React Native)
//
// Mirror of the web services-ui v1: registry + manifests + StatusBadge.
// Mobile uses real ES exports (vs window globals on web).
//
// Differences from web:
//   - SERVICE_MANIFESTS uses 'gdrive' for Google Drive (matches mobile services)
//   - StatusBadge renders as <View> + <Text> instead of <span>
//   - Chat mode for ai falls back to existing AIChatScreen (not yet integrated;
//     v1 marks ai/chat as 'pending' on mobile until wired up)
// ═══════════════════════════════════════════════════════════════════════════

export const SERVICE_MANIFESTS = {
    email: {
        servicesKey: 'email',
        display: { name: 'Email', icon: '✉️', brandColor: '#2563eb' },
        archetypes: { action: ['send'], composer: ['compose'] },
        modes: { action: 'pending', compose: 'pending', status: 'available' },
    },
    emailSmtp: {
        servicesKey: 'emailSmtp',
        display: { name: 'SMTP Email', icon: '📧', brandColor: '#475569' },
        archetypes: { action: ['send'], composer: ['compose'] },
        modes: { action: 'pending', compose: 'pending', status: 'available' },
    },
    sms: {
        servicesKey: 'sms',
        display: { name: 'SMS', icon: '💬', brandColor: '#10b981' },
        archetypes: { action: ['send'] },
        modes: { action: 'pending', status: 'available' },
    },
    whatsapp: {
        servicesKey: 'whatsapp',
        display: { name: 'WhatsApp', icon: '💚', brandColor: '#25d366' },
        archetypes: { action: ['send', 'sendTemplate'] },
        modes: { action: 'pending', status: 'available' },
    },
    push: {
        servicesKey: 'push',
        display: { name: 'Push Notifications', icon: '🔔', brandColor: '#f59e0b' },
        archetypes: { action: ['notify', 'broadcast'] },
        modes: { action: 'pending', status: 'available' },
    },
    slack: {
        servicesKey: 'slack',
        display: { name: 'Slack', icon: '#', brandColor: '#4a154b' },
        archetypes: { action: ['message', 'createChannel'], composer: ['post'] },
        modes: { action: 'pending', compose: 'pending', status: 'available' },
    },
    stripe: {
        servicesKey: 'stripe',
        display: { name: 'Stripe Checkout', icon: '💳', brandColor: '#635bff' },
        archetypes: { checkout: ['session', 'paymentLink'] },
        modes: { checkout: 'pending', status: 'available' },
    },
    billing: {
        servicesKey: 'billing',
        display: { name: 'Billing', icon: '🧾', brandColor: '#0f172a' },
        archetypes: { action: ['createCustomer', 'createInvoice'] },
        modes: { action: 'pending', status: 'available' },
    },
    paypal: {
        servicesKey: 'paypal',
        display: { name: 'PayPal', icon: '🅿️', brandColor: '#003087' },
        archetypes: { checkout: ['createOrder'] },
        modes: { checkout: 'pending', status: 'available' },
    },
    razorpay: {
        servicesKey: 'razorpay',
        display: { name: 'Razorpay', icon: '🇮🇳', brandColor: '#0c0a8c' },
        archetypes: { checkout: ['createOrder'] },
        modes: { checkout: 'pending', status: 'available' },
    },
    plaid: {
        servicesKey: 'plaid',
        display: { name: 'Plaid', icon: '🏦', brandColor: '#000000' },
        archetypes: { checkout: ['linkAccount'] },
        modes: { checkout: 'pending', status: 'available' },
    },
    salesforce: {
        servicesKey: 'salesforce',
        display: { name: 'Salesforce', icon: '☁️', brandColor: '#00a1e0' },
        archetypes: { action: ['createLead', 'createCase'] },
        modes: { action: 'pending', status: 'available' },
    },
    servicenow: {
        servicesKey: 'servicenow',
        display: { name: 'ServiceNow', icon: '⚙️', brandColor: '#62d84e' },
        archetypes: { action: ['createIncident', 'createChange'] },
        modes: { action: 'pending', status: 'available' },
    },
    quickbooks: {
        servicesKey: 'quickbooks',
        display: { name: 'QuickBooks', icon: '📊', brandColor: '#2ca01c' },
        archetypes: {
            action: ['createCustomer', 'createInvoice', 'recordPayment'],
            list: ['report'],
        },
        modes: { action: 'pending', list: 'pending', status: 'available' },
    },
    s3: {
        servicesKey: 's3',
        display: { name: 'Amazon S3', icon: '🪣', brandColor: '#ff9900' },
        archetypes: { action: ['uploadUrl'], picker: ['file'] },
        modes: { action: 'pending', picker: 'pending', status: 'available' },
        notes: 'Picker requires read API — not yet in services.s3.',
    },
    gdrive: {
        servicesKey: 'gdrive',
        display: { name: 'Google Drive', icon: '📁', brandColor: '#1a73e8' },
        archetypes: { action: ['createFolder'], picker: ['file', 'folder'] },
        modes: { action: 'pending', picker: 'pending', status: 'available' },
        notes: 'Picker requires read API — not yet in services.gdrive.',
    },
    calendar: {
        servicesKey: 'calendar',
        display: { name: 'Google Calendar', icon: '📅', brandColor: '#1a73e8' },
        archetypes: { action: ['createEvent'], picker: ['event'] },
        modes: { action: 'pending', picker: 'pending', status: 'available' },
        notes: 'Picker requires read API — not yet in services.calendar.',
    },
    ai: {
        servicesKey: 'ai',
        display: { name: 'AI', icon: '🤖', brandColor: '#7c3aed' },
        archetypes: { chat: ['chat'], action: ['complete'] },
        modes: { chat: 'pending', action: 'pending', status: 'available' },
        reuses: 'AIChatScreen',
    },
    search: {
        servicesKey: 'search',
        display: { name: 'Web Search', icon: '🔍', brandColor: '#4285f4' },
        archetypes: { list: ['results'] },
        modes: { list: 'pending', status: 'available' },
    },
    otp: {
        servicesKey: 'otp',
        display: { name: 'OTP', icon: '🔐', brandColor: '#dc2626' },
        archetypes: { action: ['send'] },
        modes: { action: 'pending', status: 'available' },
    },
    instagram: {
        servicesKey: 'instagram',
        display: { name: 'Instagram', icon: '📸', brandColor: '#e4405f' },
        archetypes: { action: ['publish'], composer: ['post'] },
        modes: { action: 'pending', compose: 'pending', status: 'available' },
    },
    twitter: {
        servicesKey: 'twitter',
        display: { name: 'X (Twitter)', icon: '𝕏', brandColor: '#000000' },
        archetypes: { action: ['tweet', 'thread'], composer: ['tweet'] },
        modes: { action: 'pending', compose: 'pending', status: 'available' },
    },
    linkedin: {
        servicesKey: 'linkedin',
        display: { name: 'LinkedIn', icon: '💼', brandColor: '#0a66c2' },
        archetypes: { action: ['post'], composer: ['post'] },
        modes: { action: 'pending', compose: 'pending', status: 'available' },
    },
    youtube: {
        servicesKey: 'youtube',
        display: { name: 'YouTube', icon: '▶️', brandColor: '#ff0000' },
        archetypes: { picker: ['video'], list: ['videos'] },
        modes: { picker: 'pending', list: 'pending', status: 'available' },
    },
    github: {
        servicesKey: 'github',
        display: { name: 'GitHub', icon: '🐙', brandColor: '#24292e' },
        archetypes: { action: ['createIssue', 'createPR'] },
        modes: { action: 'pending', status: 'available' },
    },
    bitbucket: {
        servicesKey: 'bitbucket',
        display: { name: 'Bitbucket', icon: '🪣', brandColor: '#0052cc' },
        archetypes: { action: ['createRepo'] },
        modes: { action: 'pending', status: 'available' },
    },
    googleAuth: {
        servicesKey: 'googleAuth',
        display: { name: 'Google Sign-In', icon: 'G', brandColor: '#4285f4' },
        archetypes: { action: ['login', 'signup', 'linkAccount'] },
        modes: { action: 'pending', status: 'available' },
    },
    googleAds: {
        servicesKey: 'googleAds',
        display: { name: 'Google Ads', icon: '📢', brandColor: '#4285f4' },
        archetypes: { action: ['createCampaign'], list: ['campaigns', 'performance'] },
        modes: { action: 'pending', list: 'pending', status: 'available' },
    },
    googleReviews: {
        servicesKey: 'googleReviews',
        display: { name: 'Google Reviews', icon: '⭐', brandColor: '#fbbc04' },
        archetypes: { list: ['reviews'] },
        modes: { list: 'pending', status: 'available' },
    },
    mcpServer: {
        servicesKey: 'mcpServer',
        display: { name: 'MCP Server', icon: '🔌', brandColor: '#0891b2' },
        archetypes: { action: ['registerTools'], list: ['resources'] },
        modes: { action: 'pending', list: 'pending', status: 'available' },
    },
    mcpClient: {
        servicesKey: 'mcpClient',
        display: { name: 'MCP Client', icon: '🤝', brandColor: '#0891b2' },
        archetypes: { chat: ['chat'], action: ['callTool'], list: ['tools'] },
        modes: { chat: 'pending', action: 'pending', list: 'pending', status: 'available' },
    },
    workflow: {
        servicesKey: 'workflow',
        display: { name: 'Workflow', icon: '🔄', brandColor: '#8b5cf6' },
        archetypes: { action: ['run', 'validate'] },
        modes: { action: 'pending', status: 'available' },
    },
    // ─── Backend service_id aliases (FIX B2) ─────────────────────────
    // Mirrors the canonical entries above. Object.keys(SERVICE_MANIFESTS) returns all valid widget names matching the prompt list used by the generator.
    stripe_checkout: {
        servicesKey: 'stripe',
        display: { name: 'Stripe Checkout', icon: '💳', brandColor: '#635bff' },
        modes: { action: 'pending', status: 'available' },
    },
    push_notification: {
        servicesKey: 'push',
        display: { name: 'Push Notifications', icon: '🔔', brandColor: '#f59e0b' },
        modes: { action: 'pending', status: 'available' },
    },
    x_social: {
        servicesKey: 'twitter',
        display: { name: 'X (Twitter)', icon: '𝕏', brandColor: '#000000' },
        modes: { action: 'pending', status: 'available' },
    },
    billing_paypal: {
        servicesKey: 'paypal',
        display: { name: 'PayPal', icon: '🅿️', brandColor: '#003087' },
        modes: { action: 'pending', status: 'available' },
    },
    billing_razorpay: {
        servicesKey: 'razorpay',
        display: { name: 'Razorpay', icon: '🇮🇳', brandColor: '#0c0a8c' },
        modes: { action: 'pending', status: 'available' },
    },
    amazon_s3: {
        servicesKey: 's3',
        display: { name: 'Amazon S3', icon: '🪣', brandColor: '#ff9900' },
        modes: { action: 'pending', status: 'available' },
    },
    google_drive: {
        servicesKey: 'gdrive',
        display: { name: 'Google Drive', icon: '📁', brandColor: '#1a73e8' },
        modes: { action: 'pending', status: 'available' },
    },
    google_calendar: {
        servicesKey: 'calendar',
        display: { name: 'Google Calendar', icon: '📅', brandColor: '#1a73e8' },
        modes: { action: 'pending', status: 'available' },
    },
    google_search: {
        servicesKey: 'search',
        display: { name: 'Google Search', icon: '🔎', brandColor: '#34a853' },
        modes: { action: 'pending', status: 'available' },
    },
    google_oauth: {
        servicesKey: 'googleAuth',
        display: { name: 'Google Auth', icon: '🔐', brandColor: '#1a73e8' },
        modes: { action: 'pending', status: 'available' },
    },
    google_ads: {
        servicesKey: 'googleAds',
        display: { name: 'Google Ads', icon: '📢', brandColor: '#1a73e8' },
        modes: { action: 'pending', status: 'available' },
    },
    google_reviews: {
        servicesKey: 'googleReviews',
        display: { name: 'Google Reviews', icon: '⭐', brandColor: '#1a73e8' },
        modes: { action: 'pending', status: 'available' },
    },
    auth_otp: {
        servicesKey: 'otp',
        display: { name: 'OTP Auth', icon: '🔢', brandColor: '#0ea5e9' },
        modes: { action: 'pending', status: 'available' },
    },
    mcp_client: {
        servicesKey: 'mcpClient',
        display: { name: 'MCP Client', icon: '🤝', brandColor: '#7c3aed' },
        modes: { action: 'pending', status: 'available' },
    },
    mcp_server: {
        servicesKey: 'mcpServer',
        display: { name: 'MCP Server', icon: '🛰️', brandColor: '#7c3aed' },
        modes: { action: 'pending', status: 'available' },
    },
    workflows: {
        servicesKey: 'workflow',
        display: { name: 'Workflows', icon: '⚡', brandColor: '#0f172a' },
        modes: { action: 'pending', status: 'available' },
    },
    email_smtp: {
        servicesKey: 'emailSmtp',
        display: { name: 'SMTP Email', icon: '📧', brandColor: '#475569' },
        modes: { action: 'pending', status: 'available' },
    },
};

// ─────────────────────────────────────────────────────────────────────
// Registry (mobile)
// ─────────────────────────────────────────────────────────────────────

const _archetypes = {};

// FIX B2 — backend-id alias map. Lets <ServiceWidget service="stripe_checkout">
// resolve to the 'stripe' manifest, so app code can use either spelling.
const _BACKEND_ID_ALIAS = {
    stripe_checkout: 'stripe',
    push_notification: 'push',
    x_social: 'twitter',
    billing_paypal: 'paypal',
    billing_razorpay: 'razorpay',
    amazon_s3: 's3',
    google_drive: 'gdrive',
    google_calendar: 'calendar',
    google_search: 'search',
    google_oauth: 'googleAuth',
    google_ads: 'googleAds',
    google_reviews: 'googleReviews',
    auth_otp: 'otp',
    mcp_client: 'mcpClient',
    mcp_server: 'mcpServer',
    workflows: 'workflow',
    email_smtp: 'emailSmtp',
    drive: 'gdrive',
};

export const SuperoServiceRegistry = {
    get(key) {
        return SERVICE_MANIFESTS[key]
            || SERVICE_MANIFESTS[_BACKEND_ID_ALIAS[key]]
            || null;
    },
    all() {
        return Object.keys(SERVICE_MANIFESTS).map(k =>
            Object.assign({ key: k }, SERVICE_MANIFESTS[k]));
    },
    isAvailable(key, mode) {
        const m = SERVICE_MANIFESTS[key];
        return !!(m && m.modes && (m.modes[mode] === 'available' || m.modes[mode] === 'available_via_aichat'));
    },
    archetypeFor(key, mode) {
        const m = SERVICE_MANIFESTS[key];
        return m && m.modes && m.modes[mode] ? mode : null;
    },
    liveServices(key) {
        return (typeof services !== 'undefined' && services) ? (services[key] || null) : null;
    },
    registerArchetype(mode, impl) { _archetypes[mode] = impl; },
    getArchetype(mode) { return _archetypes[mode] || null; },
};

// ─────────────────────────────────────────────────────────────────────
// StatusBadge (mobile) — checks REAL service status via backend probe
// ─────────────────────────────────────────────────────────────────────

let _SERVICES_STATUS_CACHE = null;
let _SERVICES_STATUS_PROMISE = null;

function _fetchServicesStatus() {
    if (_SERVICES_STATUS_CACHE !== null) return Promise.resolve(_SERVICES_STATUS_CACHE);
    if (_SERVICES_STATUS_PROMISE) return _SERVICES_STATUS_PROMISE;
    if (!client || typeof client.request !== 'function') {
        _SERVICES_STATUS_CACHE = 'error';
        return Promise.resolve(_SERVICES_STATUS_CACHE);
    }
    _SERVICES_STATUS_PROMISE = client.request('GET', '/api/v1/services/status', null)
        .then(resp => {
            const body = resp && resp.data && resp.success === undefined ? resp.data : resp;
            const byId = {};
            if (body && Array.isArray(body.services)) {
                body.services.forEach(s => {
                    if (s && s.service_id) byId[s.service_id] = s;
                });
            }
            _SERVICES_STATUS_CACHE = byId;
            _SERVICES_STATUS_PROMISE = null;
            return byId;
        })
        .catch(() => {
            _SERVICES_STATUS_CACHE = 'error';
            _SERVICES_STATUS_PROMISE = null;
            return _SERVICES_STATUS_CACHE;
        });
    return _SERVICES_STATUS_PROMISE;
}

function _superoBackendIdForKey(serviceKey) {
    const KEY_MAP = {
        stripe: 'stripe_checkout', push: 'push_notification', twitter: 'x_social',
        paypal: 'billing_paypal', razorpay: 'billing_razorpay',
        s3: 'amazon_s3', gdrive: 'google_drive', drive: 'google_drive',
        calendar: 'google_calendar', search: 'google_search', otp: 'auth_otp',
        googleAuth: 'google_oauth', googleAds: 'google_ads', googleReviews: 'google_reviews',
        mcpServer: 'mcp_server', mcpClient: 'mcp_client', workflow: 'workflows',
        emailSmtp: 'email_smtp',
    };
    return KEY_MAP[serviceKey] || serviceKey;
}

export const __superoStatusReset = () => {
    _SERVICES_STATUS_CACHE = null;
    _SERVICES_STATUS_PROMISE = null;
};

function _ServiceStatusBadge({ service, manifest }) {
    const [statusInfo, setStatusInfo] = useState(undefined);

    useEffect(() => {
        let alive = true;
        _fetchServicesStatus().then(byId => {
            if (!alive) return;
            if (byId === 'error') { setStatusInfo(null); return; }
            const backendId = _superoBackendIdForKey(service);
            setStatusInfo(byId[backendId] || { service_id: backendId, imported: false, config_status: 'unknown' });
        });
        return () => { alive = false; };
    }, [service]);

    let icon, label, bg, border, color;
    if (statusInfo === undefined) {
        icon = '⏳'; label = manifest.display.name + ' …';
        bg = '#f1f5f9'; border = '#e2e8f0'; color = '#475569';
    } else if (statusInfo === null) {
        icon = '❓'; label = manifest.display.name + ' status unknown';
        bg = '#f1f5f9'; border = '#e2e8f0'; color = '#475569';
    } else if (statusInfo.imported && (statusInfo.config_status === 'complete' || statusInfo.config_status === 'configured')) {
        icon = '✅'; label = manifest.display.name + ' ready';
        bg = '#d1fae5'; border = '#a7f3d0'; color = '#065f46';
    } else if (statusInfo.imported) {
        icon = '⚠️'; label = manifest.display.name + ' (config incomplete)';
        bg = '#fef3c7'; border = '#fde68a'; color = '#92400e';
    } else {
        icon = '⚪'; label = manifest.display.name + ' not imported';
        bg = '#f1f5f9'; border = '#e2e8f0'; color = '#475569';
    }

    return (
        <View style={{
            flexDirection: 'row', alignItems: 'center',
            paddingVertical: 6, paddingHorizontal: 10,
            borderRadius: 999, backgroundColor: bg,
            borderWidth: 1, borderColor: border,
            alignSelf: 'flex-start',
        }}>
            <Text style={{ fontSize: 12, color: color, fontWeight: '600' }}>
                {icon} {label}
            </Text>
        </View>
    );
}

SuperoServiceRegistry.registerArchetype('status', { render: _ServiceStatusBadge });

// ─────────────────────────────────────────────────────────────────────
// ServiceWidget (mobile)
// ─────────────────────────────────────────────────────────────────────

export function ServiceWidget({ service, mode = 'status', ...rest }) {
    const manifest = SuperoServiceRegistry.get(service);

    if (!manifest) {
        return (
            <View style={{ padding: 12, borderRadius: 8, backgroundColor: '#fef2f2', borderWidth: 1, borderColor: '#fecaca' }}>
                <Text style={{ color: '#991b1b', fontSize: 13, fontWeight: '600' }}>
                    [ServiceWidget] Unknown service: "{service}"
                </Text>
            </View>
        );
    }

    const modeStatus = manifest.modes && manifest.modes[mode];
    if (!modeStatus) {
        return (
            <View style={{ padding: 12, borderRadius: 8, backgroundColor: '#fef3c7', borderWidth: 1, borderColor: '#fde68a' }}>
                <Text style={{ color: '#92400e', fontSize: 13 }}>
                    {manifest.display.name}: mode "{mode}" not supported.
                </Text>
            </View>
        );
    }

    if (modeStatus === 'pending') {
        return (
            <View style={{
                flexDirection: 'row', alignItems: 'center', gap: 8,
                padding: 12, borderRadius: 8, backgroundColor: '#f0f9ff',
                borderWidth: 1, borderColor: '#bae6fd', borderStyle: 'dashed',
                alignSelf: 'flex-start',
            }}>
                <Text style={{ fontSize: 18 }}>{manifest.display.icon}</Text>
                <Text style={{ color: '#0c4a6e', fontSize: 13 }}>
                    <Text style={{ fontWeight: '700' }}>{manifest.display.name}</Text> · {mode} (coming soon)
                </Text>
            </View>
        );
    }

    const archetype = SuperoServiceRegistry.getArchetype(mode);
    if (!archetype || !archetype.render) {
        return (
            <View style={{ padding: 12 }}>
                <Text style={{ color: '#dc2626', fontSize: 13 }}>
                    [ServiceWidget] No archetype impl registered for mode "{mode}"
                </Text>
            </View>
        );
    }

    return archetype.render({ service, manifest, ...rest });
}

// SUPERO_SERVICES_UI_V1_APPLIED

// ═══════════════════════════════════════════════════════════════════════════
// SERVICES UI v2 — ActionForm archetype (Mobile)
//
// Mirror of web v2: 86 ops × 32 services. Uses React Native primitives.
// SUPERO_SERVICES_UI_V2_APPLIED
// ═══════════════════════════════════════════════════════════════════════════

export const ACTION_OPS = {
    "ai": {
        name: "AI / LLM",
        ops: [
            {"op":"chat_completion","name":"Chat Completion","desc":"Send a conversation (system + user messages) to an LLM and get a response. Supports OpenAI GPT and Anthropic Claude models.","in":{"messages":{"t":"json","r":1,"h":"Array of messages: [{\"role\":\"system\",\"content\":\"...\"},{\"role\":\"user\",\"content\":\"...\"}]"},"model":{"t":"string","h":"Model name. gpt-4o, gpt-4o-mini, claude-sonnet-4-20250514, claude-haiku-4-5-20251001. Auto-detected from prefix."},"max_tokens":{"t":"integer","d":1024,"h":"Maximum tokens in response"},"temperature":{"t":"float","d":0.7,"h":"Sampling temperature (0=deterministic, 1=creative)"},"provider":{"t":"string","h":"Force provider: 'openai' or 'anthropic'. Auto-detected from model if omitted."}},"out":{"record_uuid":"string","generated_text":"string","model_used":"string","total_tokens":"integer","status":"string"}},
            {"op":"simple_completion","name":"Simple Prompt","desc":"Send a single prompt and get a response. Easier than chat_completion — no message array needed.","in":{"prompt":{"t":"string","r":1,"h":"Your prompt or question"},"system_message":{"t":"string","h":"System instructions (e.g., 'You are a helpful assistant')"},"model":{"t":"string","h":"Model name (default: gpt-4o-mini or claude-sonnet-4)"},"max_tokens":{"t":"integer","d":1024},"temperature":{"t":"float","d":0.7}},"out":{"record_uuid":"string","generated_text":"string","model_used":"string","total_tokens":"integer","status":"string"}}
        ],
    },
    "amazon_s3": {
        name: "Amazon S3",
        ops: [
            {"op":"generate_upload_url","name":"Generate Upload URL","desc":"Generate a presigned URL for uploading a file directly to S3 (client-side upload)","in":{"bucket":{"t":"string","h":"S3 bucket name (uses default if not provided)"},"key":{"t":"string","r":1,"h":"Object key (path/filename.ext)"},"content_type":{"t":"string","h":"MIME type (e.g., image/png, application/pdf)"},"expires_in":{"t":"integer","h":"URL expiry in seconds (default: 3600)"}},"out":{"record_uuid":"string","presigned_upload_url":"string","s3_uri":"string","status":"string"}},
            {"op":"generate_download_url","name":"Generate Download URL","desc":"Generate a presigned URL for downloading a file from S3","in":{"bucket":{"t":"string","h":"S3 bucket name (uses default if not provided)"},"key":{"t":"string","r":1,"h":"Object key (path/filename.ext)"},"expires_in":{"t":"integer","h":"URL expiry in seconds (default: 3600)"}},"out":{"record_uuid":"string","presigned_download_url":"string","status":"string"}},
            {"op":"delete_object","name":"Delete Object","desc":"Delete an object from S3","in":{"bucket":{"t":"string","h":"S3 bucket name"},"key":{"t":"string","r":1,"h":"Object key to delete"}},"out":{"record_uuid":"string","status":"string"}}
        ],
    },
    "auth_otp": {
        name: "OTP Verification",
        ops: [
            {"op":"send_otp","name":"Send OTP","desc":"Send a one-time password to the recipient via SMS, email, or WhatsApp","in":{"channel":{"t":"string","r":1,"h":"Delivery channel: sms, email, or whatsapp"},"recipient":{"t":"string","r":1,"h":"Phone number (E.164) or email address"},"purpose":{"t":"string","d":"login","h":"Verification purpose: login, signup, transaction"},"code_length":{"t":"integer","d":6,"h":"OTP code length (4-8 digits)"},"expires_in_seconds":{"t":"integer","d":300,"h":"OTP validity in seconds (default: 5 min)"}},"out":{"record_uuid":"string","provider_verification_id":"string","status":"string"}},
            {"op":"verify_otp","name":"Verify OTP","desc":"Verify a one-time password submitted by the user","in":{"verification_uuid":{"t":"string","r":1,"h":"Verification record UUID from send_otp"},"code":{"t":"string","r":1,"h":"OTP code entered by user"}},"out":{"record_uuid":"string","verified":"boolean","status":"string"}}
        ],
    },
    "billing": {
        name: "Billing & Payments",
        ops: [
            {"op":"create_customer","name":"Create Billing Customer","desc":"Create a new billing customer and sync to Stripe.","in":{"email":{"t":"string","r":1,"h":"Customer email"},"company_name":{"t":"string","h":"Company name"},"currency":{"t":"string","h":"Currency code (default from config)"}},"out":{"record_uuid":"string","stripe_customer_id":"string","status":"string"}},
            {"op":"create_invoice","name":"Create Invoice","desc":"Create and optionally send an invoice to a customer. Pass stripe_customer_id from create_customer, or it will be auto-resolved from the customer record.","in":{"customer_uuid":{"t":"string","r":1,"h":"Billing customer UUID (Supero internal)"},"stripe_customer_id":{"t":"string","h":"Stripe customer ID (cus_...). Auto-resolved from customer record if not provided."},"amount":{"t":"float","r":1,"h":"Invoice amount"},"currency":{"t":"string","h":"Currency (default from config)"},"due_date":{"t":"string","r":1,"h":"Due date (ISO format)"},"line_items":{"t":"string","h":"JSON array of line items"},"notes":{"t":"string","h":"Invoice notes"}},"out":{"record_uuid":"string","invoice_number":"string","stripe_invoice_id":"string","hosted_invoice_url":"string","status":"string"}},
            {"op":"create_subscription","name":"Create Subscription","desc":"Create a recurring subscription for a customer.","in":{"customer_uuid":{"t":"string","r":1,"h":"Billing customer UUID (Supero internal)"},"stripe_customer_id":{"t":"string","h":"Stripe customer ID (cus_...). Auto-resolved from customer record if not provided."},"plan_name":{"t":"string","r":1,"h":"Subscription plan name"},"plan_id":{"t":"string","h":"Stripe Price ID (price_...). If not provided, an inline price is created."},"interval":{"t":"string","r":1,"h":"Billing interval: monthly, yearly, weekly"},"amount":{"t":"float","r":1,"h":"Subscription amount per interval"},"currency":{"t":"string","h":"Currency (default from config)"}},"out":{"record_uuid":"string","stripe_subscription_id":"string","status":"string"}}
        ],
    },
    "billing_paypal": {
        name: "PayPal Payments",
        ops: [
            {"op":"create_order","name":"Create Payment Order","desc":"Create a PayPal payment order and get approval URL","in":{"amount":{"t":"float","r":1,"h":"Payment amount"},"currency":{"t":"string","r":1,"d":"USD","h":"Currency code"},"description":{"t":"string","h":"Payment description"},"customer_email":{"t":"string","h":"Customer email"},"return_url":{"t":"string","h":"Redirect URL after approval"},"cancel_url":{"t":"string","h":"Redirect URL on cancel"}},"out":{"record_uuid":"string","provider_order_id":"string","approval_url":"string","status":"string"}},
            {"op":"refund_order","name":"Refund Payment","desc":"Issue a full or partial refund for a completed order","in":{"order_uuid":{"t":"string","r":1,"h":"Original order record UUID"},"provider_order_id":{"t":"string","r":1,"h":"PayPal order ID"},"amount":{"t":"float","r":1,"h":"Refund amount"},"reason":{"t":"string","h":"Reason for refund"}},"out":{"record_uuid":"string","provider_refund_id":"string","status":"string"}}
        ],
    },
    "billing_razorpay": {
        name: "RazorPay Payments",
        ops: [
            {"op":"create_order","name":"Create Payment Order","desc":"Create a RazorPay order for checkout (supports UPI, cards, wallets, net banking)","in":{"amount_paise":{"t":"integer","r":1,"h":"Amount in paise (e.g., 10000 = ₹100)"},"currency":{"t":"string","r":1,"d":"INR","h":"Currency code (INR)"},"customer_name":{"t":"string","h":"Customer name"},"customer_email":{"t":"string","h":"Customer email"},"customer_phone":{"t":"string","h":"Customer phone"},"description":{"t":"string","h":"Payment description"}},"out":{"record_uuid":"string","provider_order_id":"string","checkout_url":"string","status":"string"}},
            {"op":"create_refund","name":"Create Refund","desc":"Refund a completed payment (full or partial)","in":{"provider_payment_id":{"t":"string","r":1,"h":"RazorPay payment ID (pay_xxx)"},"amount_paise":{"t":"integer","r":1,"h":"Refund amount in paise"},"reason":{"t":"string","h":"Refund reason"},"speed":{"t":"string","d":"normal","h":"normal or optimum (instant)"}},"out":{"record_uuid":"string","provider_refund_id":"string","status":"string"}}
        ],
    },
    "bitbucket": {
        name: "Bitbucket",
        ops: [
            {"op":"create_repository","name":"Create Repository","desc":"Create a new Bitbucket repository in a workspace","in":{"workspace":{"t":"string","r":1,"h":"Bitbucket workspace slug"},"repo_slug":{"t":"string","r":1,"h":"Repository slug (URL-friendly name)"},"description":{"t":"string","h":"Repository description"},"is_private":{"t":"boolean","h":"Create as private (default: true)"},"project_key":{"t":"string","h":"Project key to create repo under"}},"out":{"record_uuid":"string","provider_repo_uuid":"string","full_name":"string","html_url":"string","status":"string"}},
            {"op":"create_pull_request","name":"Create Pull Request","desc":"Create a pull request in a Bitbucket repository","in":{"workspace":{"t":"string","r":1,"h":"Workspace slug"},"repo_slug":{"t":"string","r":1,"h":"Repository slug"},"title":{"t":"string","r":1,"h":"PR title"},"description":{"t":"string","h":"PR description (Markdown)"},"source_branch":{"t":"string","r":1,"h":"Source branch name"},"destination_branch":{"t":"string","r":1,"h":"Target branch (default: main)"},"close_source_branch":{"t":"boolean","h":"Delete source branch on merge"},"reviewers":{"t":"string","h":"Comma-separated reviewer UUIDs"}},"out":{"record_uuid":"string","provider_pr_id":"integer","html_url":"string","status":"string"}},
            {"op":"create_issue","name":"Create Issue","desc":"Create an issue in a Bitbucket repository (requires issue tracker enabled)","in":{"workspace":{"t":"string","r":1,"h":"Workspace slug"},"repo_slug":{"t":"string","r":1,"h":"Repository slug"},"title":{"t":"string","r":1,"h":"Issue title"},"content":{"t":"string","h":"Issue body (Markdown)"},"kind":{"t":"string","h":"bug, enhancement, proposal, task"},"priority":{"t":"string","h":"trivial, minor, major, critical, blocker"}},"out":{"record_uuid":"string","provider_issue_id":"integer","html_url":"string","status":"string"}}
        ],
    },
    "email": {
        name: "Email Notifications",
        ops: [
            {"op":"send_email","name":"Send Email","desc":"Send a transactional email to one or more recipients.","in":{"to_email":{"t":"string","r":1},"to_name":{"t":"string"},"subject":{"t":"string","r":1},"body_html":{"t":"string"},"body_text":{"t":"string"},"template_uuid":{"t":"string"},"variables":{"t":"object"},"cc":{"t":"string"},"bcc":{"t":"string"},"priority":{"t":"string"},"scheduled_at":{"t":"string"},"tags":{"t":"string"},"message_type":{"t":"string","d":"transactional","h":"Email type: transactional or marketing"}},"out":{"record_uuid":"string","provider_message_id":"string","status":"string"}},
            {"op":"send_bulk","name":"Start Campaign Send","desc":"Start sending emails for a campaign.","in":{"campaign_uuid":{"t":"string","r":1},"test_mode":{"t":"boolean"}},"out":{"campaign_uuid":"string","queued_count":"integer","status":"string"}},
            {"op":"verify_sender","name":"Verify Sender Domain","desc":"Initiate DNS verification for a sender identity.","in":{"sender_uuid":{"t":"string","r":1}},"out":{"sender_uuid":"string","dns_records":"object","verification_url":"string","status":"string"}}
        ],
    },
    "email_smtp": {
        name: "Email (SMTP)",
        ops: [
            {"op":"send_email","name":"Send Email (SMTP)","desc":"Send an email via SMTP. Supports HTML and plain text, CC/BCC, reply-to, and priority.","in":{"to_email":{"t":"string","r":1,"h":"Recipient email address"},"to_name":{"t":"string","h":"Recipient display name"},"subject":{"t":"string","r":1,"h":"Email subject line"},"body_html":{"t":"string","h":"HTML email body"},"body_text":{"t":"string","h":"Plain text email body"},"cc":{"t":"string","h":"CC recipients (comma-separated)"},"bcc":{"t":"string","h":"BCC recipients (comma-separated)"},"reply_to":{"t":"string","h":"Reply-to email address"},"priority":{"t":"string","h":"Email priority: high, normal, low"}},"out":{"record_uuid":"string","provider_message_id":"string","status":"string"}}
        ],
    },
    "github": {
        name: "GitHub",
        ops: [
            {"op":"create_issue","name":"Create Issue","desc":"Create a new issue in a GitHub repository","in":{"repo_owner":{"t":"string","r":1,"h":"Repository owner (user or org)"},"repo_name":{"t":"string","r":1,"h":"Repository name"},"title":{"t":"string","r":1,"h":"Issue title"},"body":{"t":"string","h":"Issue body (Markdown)"},"labels":{"t":"string","h":"Comma-separated label names"},"assignees":{"t":"string","h":"Comma-separated usernames"}},"out":{"record_uuid":"string","provider_issue_number":"integer","html_url":"string","status":"string"}},
            {"op":"create_pull_request","name":"Create Pull Request","desc":"Create a new pull request in a GitHub repository","in":{"repo_owner":{"t":"string","r":1,"h":"Repository owner"},"repo_name":{"t":"string","r":1,"h":"Repository name"},"title":{"t":"string","r":1,"h":"PR title"},"body":{"t":"string","h":"PR description (Markdown)"},"head_branch":{"t":"string","r":1,"h":"Source branch (head)"},"base_branch":{"t":"string","r":1,"h":"Target branch (base)"},"draft":{"t":"boolean","h":"Create as draft PR"}},"out":{"record_uuid":"string","provider_pr_number":"integer","html_url":"string","status":"string"}},
            {"op":"add_comment","name":"Add Comment","desc":"Add a comment to a GitHub issue or pull request","in":{"repo_owner":{"t":"string","r":1,"h":"Repository owner"},"repo_name":{"t":"string","r":1,"h":"Repository name"},"issue_number":{"t":"integer","r":1,"h":"Issue or PR number"},"body":{"t":"string","r":1,"h":"Comment body (Markdown)"}},"out":{"record_uuid":"string","provider_comment_id":"string","html_url":"string","status":"string"}},
            {"op":"create_repository","name":"Create Repository","desc":"Create a new GitHub repository (for the authenticated user)","in":{"repo_name":{"t":"string","r":1,"h":"Repository name"},"description":{"t":"string","h":"Repository description"},"private":{"t":"boolean","h":"Create as private (default: false)"},"auto_init":{"t":"boolean","h":"Initialize with README"}},"out":{"record_uuid":"string","provider_repo_id":"string","full_name":"string","html_url":"string","clone_url":"string","status":"string"}}
        ],
    },
    "google_ads": {
        name: "Google Ads",
        ops: [
            {"op":"create_campaign","name":"Create campaign","desc":"Create a Google Ads campaign with budget. Status starts as PAUSED.","in":{"campaign_name":{"t":"string","r":1},"budget_amount":{"t":"float","h":"Daily budget in dollars (converted to micros)"},"channel_type":{"t":"string","h":"SEARCH, DISPLAY, etc. Default: SEARCH"},"bidding_strategy":{"t":"string","h":"Default: MAXIMIZE_CLICKS"}},"out":{"gads_campaign_id":"string","gads_budget_id":"string","campaign_status":"string","status":"string"}},
            {"op":"create_ad_group","name":"Create ad group","desc":"Create an ad group within a campaign.","in":{"campaign_id":{"t":"string","r":1},"ad_group_name":{"t":"string","r":1},"cpc_bid":{"t":"float","h":"CPC bid in dollars. Default: 1.00"}},"out":{"gads_ad_group_id":"string","gads_campaign_id":"string","status":"string"}},
            {"op":"create_ad","name":"Create ad","desc":"Create a responsive search ad with headlines and descriptions.","in":{"ad_group_id":{"t":"string","r":1},"headlines":{"t":"string","r":1,"h":"JSON array of headline strings (max 15)"},"descriptions":{"t":"string","h":"JSON array of description strings (max 4)"},"final_url":{"t":"string"}},"out":{"gads_ad_id":"string","gads_ad_group_id":"string","status":"string"}},
            {"op":"add_keywords","name":"Add keywords","desc":"Add keyword targeting to an ad group.","in":{"ad_group_id":{"t":"string","r":1},"keywords":{"t":"string","r":1,"h":"JSON array or comma-separated list"},"match_type":{"t":"string","h":"BROAD, PHRASE, or EXACT. Default: BROAD"}},"out":{"keywords_added":"integer","match_type":"string","status":"string"}},
            {"op":"pause_campaign","name":"Pause campaign","desc":"Set campaign status to PAUSED.","in":{"campaign_id":{"t":"string","r":1},"new_status":{"t":"string","h":"Always PAUSED"}},"out":{"gads_campaign_id":"string","campaign_status":"string","status":"string"}},
            {"op":"enable_campaign","name":"Enable campaign","desc":"Set campaign status to ENABLED.","in":{"campaign_id":{"t":"string","r":1},"new_status":{"t":"string","h":"Always ENABLED"}},"out":{"gads_campaign_id":"string","campaign_status":"string","status":"string"}}
        ],
    },
    "google_calendar": {
        name: "Google Calendar",
        ops: [
            {"op":"create_event","name":"Create Calendar Event","desc":"Create a new event on Google Calendar with optional attendees, Meet link, recurrence, and reminders","in":{"summary":{"t":"string","r":1,"h":"Event title"},"start_time":{"t":"string","r":1,"h":"Start time in ISO 8601 (e.g., 2026-04-01T10:00:00-07:00)"},"end_time":{"t":"string","r":1,"h":"End time in ISO 8601"},"timezone":{"t":"string","h":"IANA timezone (e.g., America/New_York). Applied to both start and end."},"description":{"t":"string","h":"Event description (supports HTML)"},"location":{"t":"string","h":"Physical location or address"},"attendees":{"t":"string","h":"Comma-separated attendee emails (e.g., alice@example.com,bob@example.com)"},"add_meet":{"t":"boolean","h":"Auto-create a Google Meet video link"},"recurrence":{"t":"string","h":"RFC 5545 recurrence rule (e.g., RRULE:FREQ=WEEKLY;COUNT=10)"},"reminder_minutes":{"t":"integer","h":"Popup reminder N minutes before"},"send_updates":{"t":"string","d":"all","h":"Notify attendees: all, externalOnly, or none"},"calendar_id":{"t":"string","h":"Calendar ID (default: primary). Use service account's email or shared calendar ID."}},"out":{"record_uuid":"string","provider_event_id":"string","event_link":"string","meet_link":"string","status":"string"}},
            {"op":"delete_event","name":"Delete Calendar Event","desc":"Delete an event from Google Calendar by event ID","in":{"event_id":{"t":"string","r":1,"h":"Google Calendar event ID"},"send_updates":{"t":"string","d":"all","h":"Notify attendees: all, externalOnly, or none"},"calendar_id":{"t":"string","h":"Calendar ID (default: primary)"}},"out":{"record_uuid":"string","provider_event_id":"string","status":"string"}}
        ],
    },
    "google_drive": {
        name: "Google Drive",
        ops: [
            {"op":"create_folder","name":"Create Folder","desc":"Create a new folder in Google Drive","in":{"file_name":{"t":"string","r":1,"h":"Folder name"},"parent_folder_id":{"t":"string","h":"Parent folder ID (default: root)"},"description":{"t":"string","h":"Folder description"}},"out":{"record_uuid":"string","provider_file_id":"string","web_view_link":"string","status":"string"}},
            {"op":"upload_file","name":"Upload File (from URL)","desc":"Upload a file to Google Drive from a public URL","in":{"file_name":{"t":"string","r":1,"h":"File name in Drive"},"source_url":{"t":"string","r":1,"h":"Public URL to download file from"},"mime_type":{"t":"string","h":"MIME type (auto-detected if not provided)"},"parent_folder_id":{"t":"string","h":"Parent folder ID"},"description":{"t":"string","h":"File description"}},"out":{"record_uuid":"string","provider_file_id":"string","web_view_link":"string","web_content_link":"string","status":"string"}},
            {"op":"share_file","name":"Share File","desc":"Create a sharing link for a Google Drive file","in":{"provider_file_id":{"t":"string","r":1,"h":"Google Drive file ID"},"sharing_permission":{"t":"string","h":"reader, writer, commenter (default: reader)"},"sharing_type":{"t":"string","h":"anyone, domain (default: anyone)"}},"out":{"record_uuid":"string","shared_link":"string","status":"string"}}
        ],
    },
    "google_oauth": {
        name: "Google OAuth (Sign in with Google)",
        ops: [
            {"op":"google_login","name":"Sign in with Google","desc":"Exchange Google auth code for Supero JWT. Creates account if needed (same as password login response).","in":{"auth_code":{"t":"string","r":1,"h":"Google authorization code from OAuth redirect"},"redirect_uri":{"t":"string","h":"Redirect URI used in the auth request (must match)"}},"out":{"auth":"string","user":"string","context":"string","status":"string"}},
            {"op":"google_signup","name":"Sign up with Google","desc":"Create new account via Google. Fails if account already exists.","in":{"auth_code":{"t":"string","r":1,"h":"Google authorization code"},"redirect_uri":{"t":"string","h":"Redirect URI used in the auth request"}},"out":{"auth":"string","user":"string","status":"string"}},
            {"op":"link_account","name":"Link Google Account","desc":"Link Google to an existing Supero account (user must be logged in).","in":{"auth_code":{"t":"string","r":1,"h":"Google authorization code"},"redirect_uri":{"t":"string","h":"Redirect URI"},"link_account":{"t":"boolean","h":"Set to true to trigger link_account flow"}},"out":{"google_sub":"string","google_email":"string","google_linked_at":"string","status":"string"}}
        ],
    },
    "google_reviews": {
        name: "Google Reviews",
        ops: [
            {"op":"reply_review","name":"Reply to review","desc":"Reply to a review or update existing reply.","in":{"review_id":{"t":"string","r":1},"reply_comment":{"t":"string","r":1},"location_id":{"t":"string"}},"out":{"review_id":"string","reply_comment":"string","reply_updated_at":"string","status":"string"}},
            {"op":"delete_reply","name":"Delete reply","desc":"Delete a reply to a review.","in":{"review_id":{"t":"string","r":1},"delete_reply":{"t":"boolean","h":"Set to true"},"location_id":{"t":"string"}},"out":{"review_id":"string","status":"string"}}
        ],
    },
    "google_search": {
        name: "Google Search",
        ops: [
            {"op":"web_search","name":"Web Search","desc":"Search the web via Google Custom Search","in":{"query":{"t":"string","r":1,"h":"Search query"},"num":{"t":"integer","d":10,"h":"Number of results (1-10)"},"start":{"t":"integer","h":"Start index for pagination"},"language":{"t":"string","h":"Language code (en, fr, de, etc.)"},"country":{"t":"string","h":"Country code (US, GB, DE, etc.)"},"safe_search":{"t":"string","h":"off, medium, or high"},"date_restrict":{"t":"string","h":"Date filter: d7 (7 days), m1 (1 month), y1 (1 year)"},"site_search":{"t":"string","h":"Restrict results to a specific site (e.g., example.com)"}},"out":{"record_uuid":"string","results":"json","result_count":"integer","total_results":"string","status":"string"}},
            {"op":"image_search","name":"Image Search","desc":"Search for images via Google Custom Search","in":{"query":{"t":"string","r":1,"h":"Image search query"},"num":{"t":"integer","d":10},"image_size":{"t":"string","h":"huge, large, medium, small, or icon"},"image_type":{"t":"string","h":"clipart, face, lineart, stock, or photo"},"safe_search":{"t":"string","h":"off, medium, or high"}},"out":{"record_uuid":"string","results":"json","result_count":"integer","status":"string"}}
        ],
    },
    "instagram": {
        name: "Instagram Business",
        ops: [
            {"op":"publish_post","name":"Publish Post","desc":"Publish an image or carousel post to Instagram","in":{"media_type":{"t":"string","r":1,"h":"IMAGE, VIDEO, or CAROUSEL"},"media_url":{"t":"string","r":1,"h":"Public URL of the media file"},"caption":{"t":"string","h":"Post caption"},"hashtags":{"t":"string","h":"Space-separated hashtags"},"location_id":{"t":"string","h":"Instagram location ID"},"children_urls":{"t":"json","h":"Array of URLs for carousel items"}},"out":{"record_uuid":"string","provider_media_id":"string","permalink":"string","status":"string"}},
            {"op":"publish_story","name":"Publish Story","desc":"Post an image or video to Instagram Stories","in":{"media_type":{"t":"string","r":1,"h":"IMAGE or VIDEO"},"media_url":{"t":"string","r":1,"h":"Public URL of media"}},"out":{"record_uuid":"string","provider_media_id":"string","status":"string"}},
            {"op":"reply_comment","name":"Reply to Comment","desc":"Reply to a comment on one of your posts","in":{"comment_id":{"t":"string","r":1,"h":"Instagram comment ID"},"reply_text":{"t":"string","r":1,"h":"Reply text"}},"out":{"record_uuid":"string","provider_reply_id":"string","status":"string"}}
        ],
    },
    "linkedin": {
        name: "LinkedIn",
        ops: [
            {"op":"create_post","name":"Create Text Post","desc":"Publish a text post to LinkedIn feed","in":{"text":{"t":"string","r":1,"h":"Post content (up to 3000 characters)"},"author_urn":{"t":"string","h":"Author URN (urn:li:person:xxx or urn:li:organization:xxx). Auto-detected if omitted."},"visibility":{"t":"string","d":"PUBLIC","h":"PUBLIC or CONNECTIONS"}},"out":{"record_uuid":"string","provider_post_id":"string","author_urn":"string","status":"string"}},
            {"op":"create_article_post","name":"Share Article","desc":"Share an article/link on LinkedIn with commentary","in":{"text":{"t":"string","r":1,"h":"Commentary text for the article share"},"article_url":{"t":"string","r":1,"h":"URL of the article to share"},"article_title":{"t":"string","h":"Custom title for the article preview"},"article_description":{"t":"string","h":"Custom description for the article preview"},"author_urn":{"t":"string","h":"Author URN (auto-detected if omitted)"},"visibility":{"t":"string","d":"PUBLIC"}},"out":{"record_uuid":"string","provider_post_id":"string","status":"string"}}
        ],
    },
    "mcp_client": {
        name: "MCP Client",
        ops: [
            {"op":"call_tool","name":"Call MCP Tool","desc":"Execute a tool on an external MCP server. Use in workflows to connect to Figma, Jira, Slack, etc.","in":{"server_url":{"t":"string","h":"MCP server URL (or use server_name if registered)"},"server_name":{"t":"string","h":"Registered server name (alternative to URL)"},"tool_name":{"t":"string","r":1,"h":"Tool to execute"},"arguments":{"t":"string","h":"Tool arguments (JSON object)"}},"out":{"record_uuid":"string","mcp_tool_name":"string","result_text":"string","mcp_call_duration_ms":"float","status":"string","mcp_call_status":"string"}},
            {"op":"connect_server","name":"Connect MCP Server","desc":"Register and validate an external MCP server. Verifies connection and discovers tools.","in":{"server_url":{"t":"string","r":1,"h":"MCP server SSE endpoint URL"},"name":{"t":"string","h":"Friendly name for the server"},"auth_type":{"t":"string","h":"none, bearer, api_key, basic"},"auth_token":{"t":"string","h":"Auth token/key for the server"}},"out":{"server_url":"string","server_name":"string","tool_count":"integer","tools":"string","status":"string"}}
        ],
    },
    "mcp_server": {
        name: "MCP Server",
        ops: [
            {"op":"register_tools","name":"Register MCP Tools","desc":"Auto-generate MCP tool definitions from domain schemas. Each schema becomes list/get/create/update tools.","in":{},"out":{"tools":"string","tool_count":"integer","schema_count":"integer","mcp_endpoint_url":"string","status":"string"}},
            {"op":"handle_tool_call","name":"Handle MCP Tool Call","desc":"Execute an MCP tool call by mapping to the appropriate CRUD operation.","in":{"tool_name":{"t":"string","r":1,"h":"MCP tool name (e.g. list_property)"},"arguments":{"t":"string","h":"Tool arguments (JSON object)"}},"out":{"tool_name":"string","result":"string","status":"string"}}
        ],
    },
    "plaid": {
        name: "Plaid",
        ops: [
            {"op":"create_link_token","name":"Create Link Token","desc":"Generate a link_token to initialize Plaid Link on your client. Pass this token to Plaid Link in your frontend — the user will select their bank and authenticate.","in":{"client_user_id":{"t":"string","r":1,"h":"Your internal user ID (ties the bank connection to a user)"},"products":{"t":"string","h":"Comma-separated Plaid products: transactions, auth, identity, balance, investments, liabilities"},"country_codes":{"t":"string","d":"US","h":"Comma-separated country codes (US, CA, GB, etc.)"},"language":{"t":"string","d":"en","h":"Link UI language"},"redirect_uri":{"t":"string","h":"OAuth redirect URI (required for some institutions)"}},"out":{"record_uuid":"string","link_token":"string","expiration":"string","status":"string"}},
            {"op":"exchange_public_token","name":"Exchange Public Token","desc":"Exchange the public_token from Plaid Link's onSuccess callback for a permanent access_token. The public_token expires after 30 minutes.","in":{"public_token":{"t":"string","r":1,"h":"Public token from Plaid Link onSuccess callback"}},"out":{"record_uuid":"string","plaid_access_token":"string","plaid_item_id":"string","status":"string"}}
        ],
    },
    "push_notification": {
        name: "Push Notifications",
        ops: [
            {"op":"send_notification","name":"Send Push Notification","desc":"Send a push notification to a specific device token via FCM HTTP v1","in":{"device_token":{"t":"string","r":1,"h":"FCM device registration token"},"title":{"t":"string","r":1,"h":"Notification title"},"body":{"t":"string","r":1,"h":"Notification body text"},"image_url":{"t":"string","h":"Image URL for rich notification"},"click_action":{"t":"string","h":"Deep link or URL on tap"},"data_payload":{"t":"json","h":"Custom key-value data (string values only)"},"priority":{"t":"string","d":"high","h":"HIGH or NORMAL"}},"out":{"record_uuid":"string","provider_message_id":"string","status":"string"}},
            {"op":"send_topic_broadcast","name":"Broadcast to Topic","desc":"Send a notification to all subscribers of a topic via FCM HTTP v1","in":{"topic":{"t":"string","r":1,"h":"Topic name (e.g., 'news', 'alerts')"},"title":{"t":"string","r":1,"h":"Notification title"},"body":{"t":"string","r":1,"h":"Notification body text"},"data_payload":{"t":"json","h":"Custom key-value data"}},"out":{"record_uuid":"string","provider_message_id":"string","status":"string"}}
        ],
    },
    "quickbooks": {
        name: "QuickBooks Online",
        ops: [
            {"op":"create_customer","name":"Create Customer","desc":"Create a customer in QuickBooks Online","in":{"display_name":{"t":"string","r":1,"h":"Customer display name"},"email":{"t":"string","h":"Email address"},"phone":{"t":"string","h":"Phone number"},"company":{"t":"string","h":"Company name"}},"out":{"record_uuid":"string","qbo_customer_id":"string","status":"string"}},
            {"op":"create_invoice","name":"Create Invoice","desc":"Create an invoice in QuickBooks Online","in":{"customer_ref":{"t":"string","r":1,"h":"QBO customer ID"},"line_items":{"t":"string","h":"JSON array: [{description, amount, quantity, unit_price}]"},"due_date":{"t":"string","r":1,"h":"Due date (YYYY-MM-DD)"},"currency":{"t":"string","h":"Currency code (default: USD)"},"notes":{"t":"string","h":"Customer memo"}},"out":{"record_uuid":"string","qbo_invoice_id":"string","qbo_doc_number":"string","qbo_total_amount":"float","status":"string"}},
            {"op":"record_payment","name":"Record Payment","desc":"Record a payment in QuickBooks Online","in":{"customer_ref":{"t":"string","r":1,"h":"QBO customer ID"},"amount":{"t":"float","r":1,"h":"Payment amount"},"payment_method":{"t":"string","h":"Payment method"},"invoice_ref":{"t":"string","h":"QBO invoice ID to apply payment to"}},"out":{"record_uuid":"string","qbo_payment_id":"string","status":"string"}},
            {"op":"create_expense","name":"Create Expense","desc":"Record an expense in QuickBooks Online","in":{"account_ref":{"t":"string","r":1,"h":"QBO expense account ID"},"amount":{"t":"float","r":1,"h":"Expense amount"},"description":{"t":"string","h":"Expense description"},"vendor":{"t":"string","h":"QBO vendor ID"}},"out":{"record_uuid":"string","qbo_expense_id":"string","status":"string"}},
            {"op":"create_bill","name":"Create Bill","desc":"Create a bill (accounts payable) in QuickBooks Online","in":{"vendor_ref":{"t":"string","r":1,"h":"QBO vendor ID"},"line_items":{"t":"string","h":"JSON array: [{description, amount, account_ref}]"},"due_date":{"t":"string","h":"Due date (YYYY-MM-DD)"}},"out":{"record_uuid":"string","qbo_bill_id":"string","qbo_doc_number":"string","status":"string"}},
            {"op":"create_vendor","name":"Create Vendor","desc":"Create a vendor in QuickBooks Online","in":{"display_name":{"t":"string","r":1,"h":"Vendor display name"},"email":{"t":"string","h":"Vendor email"},"phone":{"t":"string","h":"Vendor phone"}},"out":{"record_uuid":"string","qbo_vendor_id":"string","status":"string"}},
            {"op":"sync_invoice","name":"Sync Invoice to QBO","desc":"Read invoice from Supero CRUD and push to QuickBooks","in":{"invoice_uuid":{"t":"string","r":1,"h":"Supero invoice UUID to sync"}},"out":{"record_uuid":"string","qbo_invoice_id":"string","qbo_sync_status":"string","status":"string"}}
        ],
    },
    "salesforce": {
        name: "Salesforce CRM",
        ops: [
            {"op":"create_lead","name":"Create Lead","desc":"Create a new Lead in Salesforce","in":{"last_name":{"t":"string","r":1,"h":"Lead last name"},"company":{"t":"string","r":1,"h":"Company name"},"first_name":{"t":"string","h":"Lead first name"},"email":{"t":"string","h":"Email address"},"phone":{"t":"string","h":"Phone number"},"title":{"t":"string","h":"Job title"},"lead_source":{"t":"string","h":"Lead source (e.g., Web, Referral, Campaign)"},"description":{"t":"string","h":"Notes or description"}},"out":{"record_uuid":"string","provider_lead_id":"string","status":"string"}},
            {"op":"create_contact","name":"Create Contact","desc":"Create a new Contact in Salesforce","in":{"last_name":{"t":"string","r":1,"h":"Contact last name"},"first_name":{"t":"string","h":"Contact first name"},"email":{"t":"string","h":"Email address"},"phone":{"t":"string","h":"Phone number"},"account_id":{"t":"string","h":"Salesforce Account ID to link to"},"title":{"t":"string","h":"Job title"}},"out":{"record_uuid":"string","provider_contact_id":"string","status":"string"}},
            {"op":"create_opportunity","name":"Create Opportunity","desc":"Create a new Opportunity (deal) in Salesforce","in":{"opportunity_name":{"t":"string","r":1,"h":"Opportunity name"},"stage_name":{"t":"string","r":1,"h":"Pipeline stage (e.g., Prospecting, Closed Won)"},"close_date":{"t":"string","r":1,"h":"Expected close date (YYYY-MM-DD)"},"amount":{"t":"float","h":"Deal amount"},"account_id":{"t":"string","h":"Salesforce Account ID"},"description":{"t":"string","h":"Notes"}},"out":{"record_uuid":"string","provider_opportunity_id":"string","status":"string"}},
            {"op":"create_case","name":"Create Case","desc":"Create a support Case in Salesforce","in":{"subject":{"t":"string","r":1,"h":"Case subject line"},"description":{"t":"string","h":"Case description/details"},"priority":{"t":"string","h":"High, Medium, Low"},"case_origin":{"t":"string","h":"Origin: Web, Phone, Email"},"case_type":{"t":"string","h":"Problem, Feature Request, Question"},"contact_id":{"t":"string","h":"Salesforce Contact ID"}},"out":{"record_uuid":"string","provider_case_id":"string","case_number":"string","status":"string"}}
        ],
    },
    "servicenow": {
        name: "ServiceNow",
        ops: [
            {"op":"create_incident","name":"Create Incident","desc":"Create a new IT incident in ServiceNow","in":{"short_description":{"t":"string","r":1,"h":"Incident summary (what happened)"},"description":{"t":"string","h":"Detailed description"},"urgency":{"t":"string","h":"1=High, 2=Medium, 3=Low"},"impact":{"t":"string","h":"1=High, 2=Medium, 3=Low"},"priority":{"t":"string","h":"1=Critical, 2=High, 3=Moderate, 4=Low, 5=Planning"},"category":{"t":"string","h":"e.g., software, hardware, network"},"assignment_group":{"t":"string","h":"ServiceNow sys_id of assignment group"},"caller_id":{"t":"string","h":"ServiceNow sys_id of the reporting user"}},"out":{"record_uuid":"string","provider_sys_id":"string","incident_number":"string","status":"string"}},
            {"op":"update_incident","name":"Update Incident","desc":"Update fields on an existing incident (state, priority, assignment, resolution, etc.)","in":{"sys_id":{"t":"string","r":1,"h":"ServiceNow sys_id of the incident"},"state":{"t":"string","h":"1=New, 2=In Progress, 3=On Hold, 6=Resolved, 7=Closed"},"priority":{"t":"string","h":"Updated priority"},"assignment_group":{"t":"string","h":"Reassign to different group"},"close_notes":{"t":"string","h":"Resolution notes (required when closing)"},"close_code":{"t":"string","h":"Resolution code (Solved, Not Solved, etc.)"}},"out":{"record_uuid":"string","provider_sys_id":"string","incident_number":"string","status":"string"}},
            {"op":"create_change_request","name":"Create Change Request","desc":"Create a change request for planned infrastructure or application changes","in":{"short_description":{"t":"string","r":1,"h":"Change summary"},"change_type":{"t":"string","r":1,"h":"normal, standard, or emergency"},"description":{"t":"string","h":"Detailed change description"},"priority":{"t":"string","h":"Priority level"},"risk":{"t":"string","h":"Risk level"},"start_date":{"t":"string","h":"Planned start (YYYY-MM-DD HH:MM:SS)"},"end_date":{"t":"string","h":"Planned end"},"justification":{"t":"string","h":"Business justification"},"implementation_plan":{"t":"string","h":"Implementation steps"},"backout_plan":{"t":"string","h":"Rollback plan if change fails"},"test_plan":{"t":"string","h":"Testing steps"}},"out":{"record_uuid":"string","provider_sys_id":"string","change_number":"string","status":"string"}},
            {"op":"add_work_note","name":"Add Work Note","desc":"Add an internal work note or customer-visible comment to an existing incident","in":{"sys_id":{"t":"string","r":1,"h":"ServiceNow sys_id of the incident"},"work_notes":{"t":"string","h":"Internal work note (not visible to customer)"},"comments":{"t":"string","h":"Customer-visible comment"}},"out":{"record_uuid":"string","provider_sys_id":"string","incident_number":"string","status":"string"}}
        ],
    },
    "slack": {
        name: "Slack Integration",
        ops: [
            {"op":"send_message","name":"Send Slack Message","desc":"Post a message to a Slack channel or DM","in":{"channel":{"t":"string","r":1,"h":"Channel name (#general) or ID (C01234567)"},"text":{"t":"string","r":1,"h":"Message text (supports Slack markdown)"},"thread_ts":{"t":"string","h":"Thread timestamp to reply in a thread"},"unfurl_links":{"t":"boolean","d":true,"h":"Expand URL previews"}},"out":{"record_uuid":"string","provider_ts":"string","status":"string"}},
            {"op":"send_rich_message","name":"Send Rich Message (Block Kit)","desc":"Post a rich message using Slack Block Kit layout","in":{"channel":{"t":"string","r":1,"h":"Channel name or ID"},"text":{"t":"string","r":1,"h":"Fallback text for notifications"},"blocks":{"t":"json","r":1,"h":"Slack Block Kit JSON array"}},"out":{"record_uuid":"string","provider_ts":"string","status":"string"}},
            {"op":"create_channel","name":"Create Channel","desc":"Create a new Slack channel","in":{"channel_name":{"t":"string","r":1,"h":"Channel name (lowercase, no spaces)"},"is_private":{"t":"boolean","d":false,"h":"Create as private channel"},"topic":{"t":"string","h":"Channel topic"},"purpose":{"t":"string","h":"Channel purpose/description"}},"out":{"record_uuid":"string","channel_id":"string","status":"string"}}
        ],
    },
    "sms": {
        name: "SMS Gateway",
        ops: [
            {"op":"send_sms","name":"Send SMS","desc":"Send an SMS message to a phone number.","in":{"to_number":{"t":"string","r":1,"h":"Recipient phone number (E.164)"},"body":{"t":"string","r":1,"h":"Message body (max 1600 chars)"},"from_number":{"t":"string","h":"Override sender number"},"template_uuid":{"t":"string","h":"Use template instead of body"}},"out":{"record_uuid":"string","twilio_sid":"string","status":"string"}}
        ],
    },
    "stripe_checkout": {
        name: "Stripe Checkout",
        ops: [
            {"op":"create_checkout_session","name":"Create Checkout Session","desc":"Generate a hosted payment page. Redirect your user to the checkout_url. Supports one-time payments (mode=payment), subscriptions (mode=subscription), and card setup (mode=setup).","in":{"success_url":{"t":"string","r":1,"h":"URL to redirect after successful payment. Append ?session_id={CHECKOUT_SESSION_ID} for tracking."},"cancel_url":{"t":"string","h":"URL if customer cancels"},"mode":{"t":"string","d":"payment","h":"payment (one-time), subscription (recurring), or setup (save card)"},"amount":{"t":"float","h":"Amount in major currency units (e.g., 29.99). Converted to cents automatically. Required if no price_id."},"currency":{"t":"string","d":"usd","h":"Three-letter ISO currency code"},"product_name":{"t":"string","h":"Product display name (used with ad-hoc amount)"},"price_id":{"t":"string","h":"Existing Stripe Price ID (e.g., price_1ABC...). Use instead of amount for pre-configured products."},"quantity":{"t":"integer","d":1,"h":"Item quantity"},"interval":{"t":"string","h":"Billing interval for subscriptions: month, year, week, day"},"customer_email":{"t":"string","h":"Pre-fill customer email on checkout page"},"stripe_customer_id":{"t":"string","h":"Existing Stripe Customer ID to associate payment with"},"client_reference_id":{"t":"string","h":"Your internal reference ID (e.g., order_id, user_id)"},"metadata":{"t":"json","h":"Custom key-value pairs stored on the Stripe session"}},"out":{"record_uuid":"string","provider_session_id":"string","checkout_url":"string","payment_status":"string","status":"string"}},
            {"op":"create_payment_link","name":"Create Payment Link","desc":"Create a reusable, shareable payment URL. Unlike checkout sessions, payment links don't expire and can be used multiple times.","in":{"price_id":{"t":"string","r":1,"h":"Stripe Price ID (create in Stripe Dashboard → Products)"},"quantity":{"t":"integer","d":1,"h":"Default quantity"},"adjustable_quantity":{"t":"boolean","h":"Allow customers to change quantity"},"min_quantity":{"t":"integer","h":"Min quantity if adjustable"},"max_quantity":{"t":"integer","h":"Max quantity if adjustable"},"after_completion_url":{"t":"string","h":"Redirect URL after payment"}},"out":{"record_uuid":"string","provider_link_id":"string","payment_link_url":"string","status":"string"}}
        ],
    },
    "whatsapp": {
        name: "WhatsApp Messaging",
        ops: [
            {"op":"send_message","name":"Send WhatsApp Message","desc":"Send a free-form text message (within 24h session window)","in":{"to_number":{"t":"string","r":1,"h":"Recipient phone (E.164 format: +1234567890)"},"body":{"t":"string","r":1,"h":"Message text"},"media_url":{"t":"string","h":"URL of image/video/document to attach"}},"out":{"record_uuid":"string","provider_message_id":"string","status":"string"}},
            {"op":"send_template","name":"Send Template Message","desc":"Send a pre-approved template message (can initiate conversations)","in":{"to_number":{"t":"string","r":1,"h":"Recipient phone (E.164 format)"},"template_name":{"t":"string","r":1,"h":"Approved template name"},"template_params":{"t":"json","h":"Template variable values: {\"1\": \"John\", \"2\": \"Order #123\"}"},"language":{"t":"string","d":"en","h":"Template language code"}},"out":{"record_uuid":"string","provider_message_id":"string","status":"string"}}
        ],
    },
    "workflows": {
        name: "Workflow Engine",
        ops: [
            {"op":"run_workflow","name":"Run workflow","desc":"Execute a workflow by ID. Resolves the workflow definition, validates input, runs all steps sequentially/parallel as defined, and returns combined result.","in":{"workflow_id":{"t":"string","r":1,"h":"ID of the workflow to execute (must exist as a workflow_definition record)"},"input":{"t":"json","r":1,"h":"Input data passed to the workflow — keys must match the workflow's input_schema"},"steps":{"t":"json","h":"Optional inline steps array. If omitted, steps are resolved from the workflow_definition CRUD record."},"input_schema":{"t":"json","h":"Optional input schema for validation. If omitted, resolved from the workflow_definition."}},"out":{"instance_uuid":"string","workflow_id":"string","status":"string","steps_completed":"integer","steps_total":"integer","steps_failed":"integer","current_step":"string","error_message":"string","duration_ms":"integer","started_at":"string","completed_at":"string","input_data":"json","output_data":"json","step_results":"json","trigger_source":"string"}},
            {"op":"validate_workflow","name":"Validate workflow definition","desc":"Validate a workflow definition without executing it. Checks that referenced services and operations exist, input mappings are valid, and the step graph is well-formed.","in":{"workflow_id":{"t":"string","r":1,"h":"ID of the workflow to validate"},"steps":{"t":"json","h":"Optional inline steps to validate. If omitted, resolved from CRUD."}},"out":{"valid":"boolean","workflow_id":"string","errors":"json","warnings":"json","step_count":"integer","services_referenced":"json"}}
        ],
    },
    "x_social": {
        name: "X (Twitter)",
        ops: [
            {"op":"post_tweet","name":"Post Tweet","desc":"Publish a tweet (with optional media, poll, or as a reply)","in":{"text":{"t":"string","r":1,"h":"Tweet text (max 280 chars)"},"media_urls":{"t":"json","h":"Array of media URLs to attach (max 4 images or 1 video)"},"reply_to_tweet_id":{"t":"string","h":"Tweet ID to reply to"},"quote_tweet_id":{"t":"string","h":"Tweet ID to quote"},"poll_options":{"t":"json","h":"Poll options array: [\"Option A\", \"Option B\"]"},"poll_duration_minutes":{"t":"integer","h":"Poll duration (5-10080 minutes)"}},"out":{"record_uuid":"string","provider_tweet_id":"string","tweet_url":"string","status":"string"}},
            {"op":"post_thread","name":"Post Thread","desc":"Publish a tweet thread (multiple connected tweets)","in":{"tweets_text":{"t":"json","r":1,"h":"Array of tweet texts: [\"First tweet\", \"Second tweet\", ...]"},"media_per_tweet":{"t":"json","h":"Array of media URL arrays per tweet: [[\"url1\"], [], [\"url2\"]]"}},"out":{"record_uuid":"string","provider_tweet_ids":"json","first_tweet_url":"string","status":"string"}},
            {"op":"send_dm","name":"Send Direct Message","desc":"Send a direct message to a user","in":{"recipient_id":{"t":"string","r":1,"h":"X user ID of the recipient"},"text":{"t":"string","r":1,"h":"Message text"},"media_url":{"t":"string","h":"Media URL to attach"}},"out":{"record_uuid":"string","provider_dm_id":"string","status":"string"}}
        ],
    },
    "youtube": {
        name: "YouTube",
        ops: [
            {"op":"create_playlist","name":"Create Playlist","desc":"Create a new YouTube playlist (requires OAuth access token)","in":{"playlist_title":{"t":"string","r":1,"h":"Playlist title"},"description":{"t":"string","h":"Playlist description"},"privacy_status":{"t":"string","d":"private","h":"public, private, or unlisted"}},"out":{"record_uuid":"string","provider_playlist_id":"string","status":"string"}},
            {"op":"add_to_playlist","name":"Add Video to Playlist","desc":"Add a video to an existing playlist (requires OAuth access token)","in":{"playlist_id":{"t":"string","r":1,"h":"YouTube playlist ID"},"video_id":{"t":"string","r":1,"h":"YouTube video ID to add"},"position":{"t":"integer","h":"Position in playlist (0-based)"}},"out":{"record_uuid":"string","provider_playlist_id":"string","provider_video_id":"string","status":"string"}}
        ],
    }
};

// ─── Field rendering helpers (shared logic) ──────────────────────────────

function _suiFieldRenderType(fieldName, fieldSpec) {
    const t = fieldSpec.t || 'string';
    if (t === 'boolean') return 'checkbox';
    if (t === 'integer') return 'integer';
    if (t === 'float')   return 'float';
    if (t === 'json' || t === 'object') return 'json';
    const n = String(fieldName);
    const TEXTAREA_FIELDS = ['body', 'body_html', 'body_text', 'description', 'short_description',
        'text', 'content', 'comments', 'comment', 'prompt', 'system_message',
        'notes', 'close_notes', 'reply_comment', 'reply_text', 'caption'];
    if (TEXTAREA_FIELDS.indexOf(n) >= 0) return 'textarea';
    if (n === 'to_email' || n === 'from_email' || n === 'email' || n === 'customer_email') return 'email';
    if (n === 'to_number' || n === 'from_number' || n === 'phone' || n === 'customer_phone') return 'tel';
    // FIX 7.3 — mask sensitive fields on mobile too
    const SECRET_FIELDS = ['auth_token', 'public_token', 'device_token',
        'api_key', 'apikey', 'client_secret', 'webhook_secret',
        'password', 'secret', 'private_key'];
    if (SECRET_FIELDS.indexOf(n) >= 0) return 'secret';
    // FIX 5.3 — recognize URL fields on mobile (keyboardType='url', autoCapitalize='none')
    const URL_FIELDS = ['success_url', 'cancel_url', 'redirect_uri', 'return_url',
        'after_completion_url', 'media_url', 'image_url', 'final_url',
        'article_url', 'source_url', 'server_url'];
    if (URL_FIELDS.indexOf(n) >= 0) return 'url';
    return 'text';
}

function _suiInterpolate(template, context) {
    if (typeof template !== 'string') return template;
    if (!context || typeof context !== 'object') return template;
    if (template.indexOf('{{') < 0) return template;
    return template.replace(/\{\{\s*([\w.]+)\s*\}\}/g, (_m, path) => {
        const parts = path.split('.');
        let obj = context;
        for (const p of parts) {
            if (obj == null) return '';
            obj = obj[p];
        }
        return obj == null ? '' : String(obj);
    });
}

function _suiInitialFormData(opDef, defaultsFromProps, context) {
    const data = {};
    const inSchema = opDef.in || {};
    Object.keys(inSchema).forEach(k => {
        if ('d' in inSchema[k]) data[k] = inSchema[k].d;
    });
    if (defaultsFromProps && typeof defaultsFromProps === 'object') {
        Object.keys(defaultsFromProps).forEach(k => {
            data[k] = _suiInterpolate(defaultsFromProps[k], context);
        });
    }
    return data;
}

function _suiValidateRequired(opDef, formData) {
    const inSchema = opDef.in || {};
    const missing = [];
    Object.keys(inSchema).forEach(k => {
        if (!inSchema[k].r) return;
        const v = formData[k];
        if (v == null || v === '' || (Array.isArray(v) && v.length === 0)) missing.push(k);
    });
    return missing;
}

// FIX 1.5 — JSON parse errors caught client-side so user gets a useful message.
function _suiValidateJsonFields(opDef, formData) {
    const inSchema = opDef.in || {};
    const errors = [];
    Object.keys(formData).forEach(k => {
        const spec = inSchema[k] || {};
        const t = spec.t || 'string';
        if (t !== 'json' && t !== 'object') return;
        const v = formData[k];
        if (v === '' || v == null || typeof v !== 'string') return;  // FIX M16 (mobile) — pre-validated object passes through
        try { JSON.parse(v); }
        catch (e) {
            errors.push({ field: k, error: (e && e.message) || 'invalid JSON' });
        }
    });
    return errors;
}

function _suiCoerceForSubmit(opDef, formData) {
    const inSchema = opDef.in || {};
    const payload = {};
    Object.keys(formData).forEach(k => {
        const spec = inSchema[k] || {};
        const v = formData[k];
        const t = spec.t || 'string';
        // FIX S4 — boolean fields always emit, even when undefined (unchecked
        // switch with no default). Other types skip empty optional fields.
        if (t === 'boolean') { payload[k] = !!v; return; }
        if (v === '' || v == null) return;
        if (t === 'integer') {
            const n = parseInt(v, 10);
            payload[k] = isNaN(n) ? v : n;
        } else if (t === 'float') {
            const f = parseFloat(v);
            payload[k] = isNaN(f) ? v : f;
        } else if (t === 'json' || t === 'object') {
            if (typeof v === 'string') {
                try { payload[k] = JSON.parse(v); } catch (e) { payload[k] = v; }
            } else { payload[k] = v; }
        } else {
            payload[k] = v;
        }
    });
    return payload;
}

// FIX L5 (mobile) — known acronyms uppercased so labels read 'Record UUID' not 'Record Uuid'
const _SUI_ACRONYMS_MOBILE = ['UUID', 'URL', 'API', 'ID', 'OTP', 'MCP', 'JSON', 'HTML', 'SMS', 'JWT', 'OAUTH', 'SQL', 'IP', 'CSS', 'HTTP', 'SSL', 'TLS'];
const _suiFieldLabel = (fieldName) => {
    const titled = fieldName.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
    return titled.split(' ').map(w => {
        const up = w.toUpperCase();
        return _SUI_ACRONYMS_MOBILE.indexOf(up) >= 0 ? up : w;
    }).join(' ');
};

// ─── ActionResult component (RN) ─────────────────────────────────────────

// FIX S2 — sensitive output fields render masked.
// (No copy button on mobile — would need an extra dep like
//  @react-native-clipboard/clipboard. User can re-fetch if needed.)
const _OUTPUT_SECRET_FIELDS = [
    'auth', 'plaid_access_token', 'link_token',
    'auth_token', 'refresh_token',
    'api_key', 'apikey', 'client_secret', 'webhook_secret',
    'password', 'secret', 'private_key',
];

// FIX 5.2 — URL output fields render as tappable text (open via Linking)
const URL_OUTPUT_FIELDS = [
    'html_url', 'permalink', 'web_view_link', 'web_content_link',
    'shared_link', 'event_link', 'meet_link',
    'checkout_url', 'payment_link_url', 'hosted_invoice_url',
    'approval_url', 'tweet_url', 'first_tweet_url',
    'verification_url', 'mcp_endpoint_url',
    'presigned_upload_url', 'presigned_download_url',
    'clone_url', 'auth_url',
];

function _isSafeUrl(s) {
    // FIX 7.2 — only http/https URLs render as openable links
    if (typeof s !== 'string') return false;
    return /^https?:\/\//i.test(s);
}

function _ServiceActionResult({ success, output, error }) {
    if (!success) {
        return (
            <View style={{ marginTop: 12, padding: 10, borderRadius: 8,
                backgroundColor: '#fef2f2', borderWidth: 1, borderColor: '#fecaca' }}>
                <Text style={{ color: '#991b1b', fontWeight: '600', fontSize: 13 }}>✗ Failed</Text>
                {error ? <Text style={{ color: '#7f1d1d', fontSize: 12, marginTop: 4 }}>{error}</Text> : null}
            </View>
        );
    }
    const outputKeys = Object.keys(output || {});
    return (
        <View style={{ marginTop: 12, padding: 10, borderRadius: 8,
            backgroundColor: '#f0fdf4', borderWidth: 1, borderColor: '#bbf7d0' }}>
            <Text style={{ color: '#14532d', fontWeight: '700', fontSize: 13, marginBottom: outputKeys.length ? 8 : 0 }}>
                ✓ {output && output.status ? output.status : 'Success'}
            </Text>
            {outputKeys.filter(k => k !== 'status').map(k => {
                const v = output[k];
                if (v == null || v === '') return null;
                // FIX S2 — mask sensitive output values (JWTs, access tokens, …)
                if (_OUTPUT_SECRET_FIELDS.indexOf(k) >= 0) {
                    return (
                        <View key={k} style={{ flexDirection: 'row', marginBottom: 4, alignItems: 'center' }}>
                            <Text style={{ color: '#94a3b8', fontSize: 12, marginRight: 6 }}>{k}:</Text>
                            <Text style={{ color: '#0f172a', fontSize: 12, fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace', letterSpacing: 2 }}>
                                {'\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022'}
                            </Text>
                        </View>
                    );
                }
                const display = typeof v === 'object' ? JSON.stringify(v) : String(v);
                const isUrl = URL_OUTPUT_FIELDS.indexOf(k) >= 0 && _isSafeUrl(v);
                if (isUrl) {
                    return (
                        <View key={k} style={{ flexDirection: 'row', marginBottom: 4, flexWrap: 'wrap', alignItems: 'flex-start' }}>
                            <Text style={{ color: '#94a3b8', fontSize: 12, marginRight: 6 }}>{k}:</Text>
                            <Pressable onPress={() => {
                                // FIX M13 — surface failures (Android intent-filter rejections etc.)
                                Linking.openURL(v).catch((err) => {
                                    Alert.alert('Cannot open link', (err && err.message) || 'Unknown error');
                                });
                            }} style={{ flexShrink: 1 }}>
                                <Text style={{ color: '#0369a1', fontSize: 12, textDecorationLine: 'underline' }}>{display}</Text>
                            </Pressable>
                        </View>
                    );
                }
                return (
                    <View key={k} style={{ flexDirection: 'row', marginBottom: 4, flexWrap: 'wrap' }}>
                        <Text style={{ color: '#94a3b8', fontSize: 12, marginRight: 6 }}>{k}:</Text>
                        <Text style={{ color: '#0f172a', fontSize: 12, flexShrink: 1 }}>{display}</Text>
                    </View>
                );
            })}
        </View>
    );
}

// ─── ActionForm archetype (RN) ───────────────────────────────────────────

function _ServiceActionForm({ service, manifest, operation, defaults, context, compact, onSuccess, onError, title }) {
    const KEY_TO_SERVICE_ID = {
        stripe: 'stripe_checkout', push: 'push_notification', twitter: 'x_social',
        paypal: 'billing_paypal', razorpay: 'billing_razorpay',
        s3: 'amazon_s3', gdrive: 'google_drive', drive: 'google_drive',
        calendar: 'google_calendar', search: 'google_search', otp: 'auth_otp',
        googleAuth: 'google_oauth', googleAds: 'google_ads', googleReviews: 'google_reviews',
        mcpServer: 'mcp_server', mcpClient: 'mcp_client', workflow: 'workflows',
        emailSmtp: 'email_smtp',
    };
    let actionServiceId = (manifest && manifest.serviceId) || service;
    let actionInfo = ACTION_OPS[actionServiceId];
    if (!actionInfo) {
        const altId = KEY_TO_SERVICE_ID[service];
        if (altId && ACTION_OPS[altId]) {
            actionInfo = ACTION_OPS[altId];
            actionServiceId = altId;
        }
    }
    if (!actionInfo) {
        return (
            <View style={{ padding: 12, borderRadius: 8, backgroundColor: '#fef3c7',
                borderWidth: 1, borderColor: '#fde68a' }}>
                <Text style={{ color: '#92400e', fontSize: 13 }}>
                    No action operations available for service "{service}"
                </Text>
            </View>
        );
    }

    // FIX 4.1 — explicit operation that doesn't exist gets surfaced rather
    // than silently falling back to the first op.
    let opDef = null;
    let operationLookupFailed = false;
    if (operation) {
        opDef = actionInfo.ops.find(o => o.op === operation) || null;
        if (!opDef) operationLookupFailed = true;
    } else {
        opDef = actionInfo.ops[0];
    }
    if (operationLookupFailed) {
        return (
            <View style={{ padding: 12, borderRadius: 8, backgroundColor: '#fef2f2',
                borderWidth: 1, borderColor: '#fecaca' }}>
                <Text style={{ color: '#991b1b', fontWeight: '600', fontSize: 13, marginBottom: 4 }}>
                    Unknown operation "{operation}" for service "{service}"
                </Text>
                <Text style={{ color: '#7f1d1d', fontSize: 12 }}>
                    Available: {actionInfo.ops.map(o => o.op).join(', ')}
                </Text>
            </View>
        );
    }
    if (!opDef) {
        return (
            <View style={{ padding: 12 }}>
                <Text style={{ color: '#dc2626' }}>Service "{service}" has no operations.</Text>
            </View>
        );
    }

    const [formData, setFormData] = useState(() => _suiInitialFormData(opDef, defaults, context));
    const [loading, setLoading] = useState(false);
    const [result, setResult] = useState(null);
    const [error, setError] = useState('');
    const [showAdvanced, setShowAdvanced] = useState(false);

    useEffect(() => {
        const fresh = _suiInitialFormData(opDef, defaults, context);
        setFormData(prev => {
            const merged = Object.assign({}, fresh, prev);
            if (defaults) Object.keys(defaults).forEach(k => { merged[k] = fresh[k]; });
            return merged;
        });
    }, [operation, JSON.stringify(defaults), context && context.uuid]);

    const handleChange = (field, value) => {
        setFormData(prev => Object.assign({}, prev, { [field]: value }));
    };

    const handleSubmit = async () => {
        setError(''); setResult(null);
        const missing = _suiValidateRequired(opDef, formData);
        if (missing.length > 0) {
            setError('Required fields missing: ' + missing.join(', '));
            return;
        }
        // FIX 1.5 — JSON parse errors caught client-side
        const jsonErrors = _suiValidateJsonFields(opDef, formData);
        if (jsonErrors.length > 0) {
            setError('Invalid JSON in field' + (jsonErrors.length > 1 ? 's' : '') + ': ' +
                jsonErrors.map(e => e.field + ' (' + e.error + ')').join(', '));
            return;
        }

        const payload = _suiCoerceForSubmit(opDef, formData);

        if (!client || typeof client.request !== 'function') {
            setError('Supero client not available');
            return;
        }

        // FIX 1.1 — mobile config doesn't include project_uuid by default.
        // Accept it from getConfig() (if user has called setConfig with one)
        // or fall back to the lib's PROJECT slug as a last resort. If neither
        // is available, surface a clear error rather than letting the backend
        // reject with 422.
        const cfg = getConfig();
        const projectUuid = cfg.PROJECT_UUID || cfg.project_uuid || cfg.projectUuid;
        if (!projectUuid) {
            setError(
                'Cannot execute service: project_uuid not in mobile config. ' +
                'Call setConfig({ project_uuid: "<your-uuid>" }) before mounting widgets.'
            );
            return;
        }

        setLoading(true);
        try {
            const resp = await client.request('POST', '/api/v1/services/execute', {
                service_id: actionServiceId,
                operation: opDef.op,
                input: payload,
                domain: cfg.DOMAIN,
                project_uuid: projectUuid,
            });
            setLoading(false);
            // FIX 3.1 — handle both axios-style and direct-body shapes
            const body = (resp && resp.data && resp.success === undefined) ? resp.data : resp;
            if (body && body.success) {
                setResult({ success: true, output: body.output || {} });
                if (typeof onSuccess === 'function') onSuccess(body);
            } else {
                const errMsg = (body && body.error) || 'Operation failed';
                setResult({ success: false, error: errMsg });
                if (typeof onError === 'function') onError(body);
            }
        } catch (err) {
            setLoading(false);
            const errMsg = (err && err.message) || String(err);
            setResult({ success: false, error: errMsg });
            if (typeof onError === 'function') onError(err);
        }
    };

    const inSchema = opDef.in || {};
    const fieldNames = Object.keys(inSchema);
    const requiredFields = fieldNames.filter(k => inSchema[k].r);
    const optionalFields = fieldNames.filter(k => !inSchema[k].r);
    const hasOptional = optionalFields.length > 0;

    const inputBaseStyle = {
        borderWidth: 1, borderColor: '#e2e8f0', borderRadius: 10,
        backgroundColor: '#f8fafc', fontSize: 14, paddingHorizontal: 12, paddingVertical: 10,
        color: '#0f172a',
    };

    const renderField = (k) => {
        const spec = inSchema[k];
        const value = formData[k];
        const renderType = _suiFieldRenderType(k, spec);
        const label = _suiFieldLabel(k);

        let inputElement;
        if (renderType === 'checkbox') {
            inputElement = (
                <View style={{ flexDirection: 'row', alignItems: 'center', marginVertical: 8 }}>
                    <Switch value={!!value} onValueChange={v => handleChange(k, v)} />
                    <Text style={{ marginLeft: 10, fontSize: 14, color: '#334155' }}>{spec.h || label}</Text>
                </View>
            );
        } else if (renderType === 'textarea' || renderType === 'json') {
            inputElement = (
                <TextInput
                    value={value == null ? '' : (typeof value === 'object' ? JSON.stringify(value, null, 2) : String(value))}
                    onChangeText={t => handleChange(k, t)}
                    multiline
                    numberOfLines={4}
                    placeholder={spec.h || label}
                    placeholderTextColor="#94a3b8"
                    style={[inputBaseStyle, {
                        height: 90, textAlignVertical: 'top',
                        fontFamily: renderType === 'json' ? (Platform.OS === 'ios' ? 'Menlo' : 'monospace') : undefined,
                        fontSize: renderType === 'json' ? 12 : 14,
                    }]}
                />
            );
        } else {
            // FIX 5.3, 5.4, 7.3 — `url` and `secret` field types now handled.
            const keyboardType =
                renderType === 'integer' || renderType === 'float' ? 'numeric' :
                renderType === 'email' ? 'email-address' :
                renderType === 'tel' ? 'phone-pad' :
                renderType === 'url' ? 'url' :
                'default';
            // Disable auto-capitalize for fields where it would corrupt input.
            const autoCap =
                renderType === 'email' || renderType === 'url' ||
                renderType === 'tel' || renderType === 'secret' ||
                renderType === 'json'
                    ? 'none'
                    : 'sentences';
            inputElement = (
                <TextInput
                    value={value == null ? '' : String(value)}
                    onChangeText={t => handleChange(k, t)}
                    placeholder={spec.h || label}
                    placeholderTextColor="#94a3b8"
                    keyboardType={keyboardType}
                    autoCapitalize={autoCap}
                    autoCorrect={renderType === 'secret' || renderType === 'url' || renderType === 'email' ? false : true}
                    secureTextEntry={renderType === 'secret'}
                    style={inputBaseStyle}
                />
            );
        }

        return (
            <View key={k} style={{ marginBottom: 14 }}>
                {renderType !== 'checkbox' && (
                    <Text style={{ fontSize: 13, fontWeight: '600', color: '#334155', marginBottom: 4 }}>
                        {label}{spec.r ? <Text style={{ color: '#dc2626' }}> *</Text> : null}
                    </Text>
                )}
                {inputElement}
                {renderType !== 'checkbox' && spec.h ? (
                    <Text style={{ fontSize: 11, color: '#64748b', marginTop: 4 }}>{spec.h}</Text>
                ) : null}
            </View>
        );
    };

    // Compact mode — just a button
    if (compact) {
        const btnLabel = title || opDef.name;
        return (
            <Pressable
                onPress={handleSubmit}
                disabled={loading}
                style={{
                    paddingHorizontal: 16, paddingVertical: 10,
                    backgroundColor: loading ? '#94a3b8' : '#0284c7',
                    borderRadius: 8, alignSelf: 'flex-start',
                    flexDirection: 'row', alignItems: 'center', gap: 6,
                    opacity: loading ? 0.8 : 1,
                }}
            >
                {manifest && manifest.display && manifest.display.icon ? (
                    <Text style={{ fontSize: 16 }}>{manifest.display.icon}</Text>
                ) : null}
                <Text style={{ color: '#fff', fontSize: 14, fontWeight: '600' }}>
                    {loading ? '…' : btnLabel}
                </Text>
            </Pressable>
        );
    }

    // FIX 5.1 — KeyboardAvoidingView so form's submit button doesn't get hidden
    // by the keyboard on iOS. ScrollView for overflow on small screens.
    return (
        <KeyboardAvoidingView
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
            keyboardVerticalOffset={Platform.OS === 'ios' ? 64 : 0}
            style={{ width: '100%' }}
        >
            <ScrollView
                keyboardShouldPersistTaps="handled"
                contentContainerStyle={{ flexGrow: 1 }}
            >
                <View style={{
                    backgroundColor: '#fff', borderRadius: 12, padding: 20,
                    borderWidth: 1, borderColor: '#e2e8f0',
                }}>
                    <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 16, gap: 10 }}>
                        {manifest && manifest.display && manifest.display.icon ? (
                            <Text style={{ fontSize: 22 }}>{manifest.display.icon}</Text>
                        ) : null}
                        <View style={{ flexShrink: 1 }}>
                            <Text style={{ fontSize: 16, fontWeight: '700', color: '#0f172a' }}>
                                {title || opDef.name}
                            </Text>
                            {manifest && manifest.display && manifest.display.name ? (
                                <Text style={{ fontSize: 12, color: '#64748b' }}>{manifest.display.name}</Text>
                            ) : null}
                        </View>
                    </View>

                    {opDef.desc ? (
                        <Text style={{ fontSize: 13, color: '#475569', marginBottom: 16, lineHeight: 18 }}>
                            {opDef.desc}
                        </Text>
                    ) : null}

                    {requiredFields.map(renderField)}

                    {hasOptional ? (
                        <Pressable onPress={() => setShowAdvanced(!showAdvanced)} style={{ marginBottom: 8 }}>
                            <Text style={{ color: '#0284c7', fontSize: 13, fontWeight: '600' }}>
                                {showAdvanced ? '▾ Hide advanced options' : '▸ Show ' + optionalFields.length + ' more option' + (optionalFields.length === 1 ? '' : 's')}
                            </Text>
                        </Pressable>
                    ) : null}

                    {showAdvanced && optionalFields.map(renderField)}

                    {error ? (
                        <View style={{ backgroundColor: '#fef2f2', borderWidth: 1, borderColor: '#fecaca',
                            padding: 10, borderRadius: 6, marginBottom: 12 }}>
                            <Text style={{ color: '#991b1b', fontSize: 12 }}>{error}</Text>
                        </View>
                    ) : null}

                    <Pressable
                        onPress={handleSubmit}
                        disabled={loading}
                        style={{
                            paddingVertical: 12, paddingHorizontal: 16,
                            backgroundColor: loading ? '#94a3b8' : '#0284c7',
                            borderRadius: 8, alignItems: 'center',
                            opacity: loading ? 0.8 : 1, marginTop: 4,
                            flexDirection: 'row', justifyContent: 'center', gap: 8,
                        }}
                    >
                        {loading ? <ActivityIndicator size="small" color="#fff" /> : null}
                        <Text style={{ color: '#fff', fontSize: 14, fontWeight: '600' }}>
                            {loading ? 'Working…' : opDef.name}
                        </Text>
                    </Pressable>

                    {result && <_ServiceActionResult success={result.success} output={result.output} error={result.error} />}
                </View>
            </ScrollView>
        </KeyboardAvoidingView>
    );
}

// ─── Register + flip mode availability ──────────────────────────────────

if (typeof SuperoServiceRegistry !== 'undefined' && SuperoServiceRegistry.registerArchetype) {
    SuperoServiceRegistry.registerArchetype('action', { render: _ServiceActionForm });

    (function _flipModeAvailability() {
        if (typeof SERVICE_MANIFESTS === 'undefined') return;
        const MANIFEST_TO_BACKEND = {
            stripe: 'stripe_checkout', push: 'push_notification', twitter: 'x_social',
            paypal: 'billing_paypal', razorpay: 'billing_razorpay',
            s3: 'amazon_s3', gdrive: 'google_drive', drive: 'google_drive',
            calendar: 'google_calendar', search: 'google_search', otp: 'auth_otp',
            googleAuth: 'google_oauth', googleAds: 'google_ads', googleReviews: 'google_reviews',
            mcpServer: 'mcp_server', mcpClient: 'mcp_client', workflow: 'workflows',
            emailSmtp: 'email_smtp',
        };
        Object.keys(SERVICE_MANIFESTS).forEach(mk => {
            const entry = SERVICE_MANIFESTS[mk];
            if (!entry || !entry.modes) return;
            const backendId = MANIFEST_TO_BACKEND[mk] || mk;
            if (ACTION_OPS && ACTION_OPS[backendId] && ACTION_OPS[backendId].ops.length > 0) {
                // FIX M18 — respect manifest's original action declaration.
                // Don't auto-add 'action' mode to services that didn't declare it.
                if (entry.modes.action === 'pending') {
                    entry.modes.action = 'available';
                }
                entry.serviceId = backendId;
            }
        });
    })();
}

// SUPERO_SERVICES_UI_V2_APPLIED



// ═══════════════════════════════════════════════════════════════════════════
// Supero Transactional UI — Mobile Append Block (v1.0)
//
// Appended to supero-mobile.jsx by apply_ui_patch.py. Pure additive.
// Adds: registry, client extensions, list + detail screens.
//
// Tab dispatch: when MobileShell encounters a tab with view='transactional',
// it should register a TransactionalListScreen instead of the standard
// ListScreen. The applier script handles that surgical edit.
//
// View types covered in v1.0: 'transactional' (list + detail).
// View types deferred to v1.1: 'inbox', 'flow'.
// ═══════════════════════════════════════════════════════════════════════════

// ─── Registry ───────────────────────────────────────────────────────────

let _txnCacheM = null;
let _txnReadyM = null;
let _txnLoadStartedM = false;
let _txnErrorHandlersM = [];

export const SuperoTransactionalRegistry = {
  load() {
    if (_txnLoadStartedM) return _txnReadyM;
    _txnLoadStartedM = true;
    const apiUrl = (getConfig().API_URL || '').replace(/\/$/, '');
    _txnReadyM = fetch(apiUrl + '/api/transactional/describe', {
      method: 'GET',
      headers: { 'Accept': 'application/json' },
    })
      .then(r => r.ok ? r.json() : { version: '0.0.0', services: {} })
      .catch(err => {
        console.warn('[TransactionalRegistry/mobile] fetch failed:', err);
        return { version: '0.0.0', services: {} };
      })
      .then(payload => {
        _txnCacheM = payload || { version: '0.0.0', services: {} };
        if (!_txnCacheM.services) _txnCacheM.services = {};
        return _txnCacheM;
      });
    return _txnReadyM;
  },
  ready() { return _txnReadyM || this.load(); },
  isLoaded() { return _txnCacheM !== null; },
  all() { return _txnCacheM; },
  get(serviceId) {
    return _txnCacheM && _txnCacheM.services[serviceId] || null;
  },
  operation(serviceId, opId) {
    const svc = this.get(serviceId);
    return svc && svc.operations ? (svc.operations[opId] || null) : null;
  },
  allowedActions(serviceId, stateValue) {
    const svc = this.get(serviceId);
    if (!svc) return [];
    if (!svc.states) return Object.keys(svc.operations || {});
    const stateDef = svc.states[stateValue];
    return stateDef ? (stateDef.allows || []) : [];
  },
  actionDescriptors(serviceId, stateValue) {
    const allowed = this.allowedActions(serviceId, stateValue);
    const svc = this.get(serviceId);
    if (!svc) return [];
    return allowed.map(opId => {
      const op = (svc.operations || {})[opId] || {};
      return { op: opId, label: op.label || opId, category: op.category || 0, input: op.input || [] };
    });
  },
  stateColor(serviceId, stateValue) {
    const svc = this.get(serviceId);
    return svc && svc.states && svc.states[stateValue]
      ? (svc.states[stateValue].color || 'gray') : 'gray';
  },
  stateLabel(serviceId, stateValue) {
    const svc = this.get(serviceId);
    return svc && svc.states && svc.states[stateValue]
      ? (svc.states[stateValue].label || stateValue) : stateValue;
  },
  viewConfig(qualifiedSchema) {
    const views = (getConfig().transactionalViews || {});
    if (views[qualifiedSchema]) return views[qualifiedSchema];
    const bare = qualifiedSchema.includes(':')
      ? qualifiedSchema.split(':').pop() : qualifiedSchema;
    for (const k of Object.keys(views)) {
      if (k.split(':').pop() === bare) return views[k];
    }
    return null;
  },
  onError(handler) { if (typeof handler === 'function') _txnErrorHandlersM.push(handler); },
  _runErrorHandlers(err, ctx) {
    for (const h of _txnErrorHandlersM) {
      try { const o = h(err, ctx); if (o) return o; }
      catch (e) { console.warn('[TransactionalRegistry/mobile] error handler threw:', e); }
    }
    return null;
  },
};


// ─── Typed errors ───────────────────────────────────────────────────────

export class TxnServiceError extends Error {
  constructor(message, ctx = {}) {
    super(message);
    this.name = this.constructor.name;
    this.status = 0;
    this.serviceId = ctx.serviceId || '';
    this.operation = ctx.operation || '';
    this.raw = ctx.raw || null;
  }
}
export class TxnBadRequestError    extends TxnServiceError { constructor(m, c) { super(m, c); this.status = 400; } }
export class TxnNotFoundError      extends TxnServiceError { constructor(m, c) { super(m, c); this.status = 404; } }
export class TxnStateConflictError extends TxnServiceError { constructor(m, c) { super(m, c); this.status = 409; } }
export class TxnPlatformError      extends TxnServiceError { constructor(m, c) { super(m, c); this.status = 502; } }
export class TxnSoftFailureError   extends TxnServiceError { constructor(m, c) { super(m, c); this.status = 200; } }

function _classifyHttpErrorM(status, body, ctx) {
  let msg = '';
  if (body && typeof body === 'object') {
    msg = body.error || (body.output && body.output.error) ||
          JSON.stringify(body).slice(0, 200);
  }
  if (status === 200 && body && body.success === false) return new TxnSoftFailureError(msg, ctx);
  if (status === 400) return new TxnBadRequestError(msg, ctx);
  if (status === 404) return new TxnNotFoundError(msg, ctx);
  if (status === 409) return new TxnStateConflictError(msg, ctx);
  if (status === 502) return new TxnPlatformError(msg, ctx);
  return new TxnServiceError(msg || ('HTTP ' + status), ctx);
}

function _txnOpCategoryM(serviceId, opId) {
  const op = SuperoTransactionalRegistry.operation(serviceId, opId);
  return op ? (op.category || 0) : 0;
}

function _txnBackoffM(attempt) {
  const base = 100 * Math.pow(3, attempt - 1);
  const j = base * (0.7 + 0.6 * Math.random());
  return new Promise(r => setTimeout(r, j));
}


// ─── SuperoClient extensions ────────────────────────────────────────────
// Note: The existing SuperoClient class is at line 478. These methods are
// attached to its prototype here, AFTER the class definition.

SuperoClient.prototype._txnExecute = async function(serviceId, opId, input, options = {}) {
  const maxRetries = options.maxRetries == null ? 3 : options.maxRetries;
  const safe = !!options.safe;
  const ctx = { serviceId, operation: opId };

  if (!this._txnExtensions) this._txnExtensions = {};
  const registered = this._txnExtensions[serviceId];
  if (registered) {
    for (const k of Object.keys(registered)) {
      if (input[k] === undefined) input[k] = registered[k];
    }
  }

  if (serviceId === 'cart' && opId === 'checkout_cart') {
    const orderReg = this._txnExtensions.order;
    if (orderReg) {
      if (input.order_extending_schema === undefined && orderReg.extending_schema) {
        input.order_extending_schema = orderReg.extending_schema;
      }
      if (input.order_item_extending_schema === undefined && orderReg.order_item_extending_schema) {
        input.order_item_extending_schema = orderReg.order_item_extending_schema;
      }
    }
  }

  if (input.op === undefined) input.op = opId;

  const clean = {};
  for (const k of Object.keys(input)) {
    if (input[k] !== undefined && input[k] !== null) clean[k] = input[k];
  }

  const category = _txnOpCategoryM(serviceId, opId);
  let attempt = 0;
  let lastErr = null;
  while (true) {
    try {
      const resp = await this.request('POST', '/api/v1/services/execute', {
        service_id: serviceId, operation: opId, input: clean,
        domain: this.domain,
        project_uuid: this.projectUuid || getConfig().project_uuid || '',
      });
      if (resp && resp.success === false) {
        throw new TxnSoftFailureError(
          (resp.output && resp.output.error) || resp.error || 'Soft failure', ctx);
      }
      return (resp && resp.output) || resp || {};
    } catch (e) {
      let err;
      if (e instanceof TxnServiceError) err = e;
      else {
        const status = e.status || (e.response && e.response.status) || 0;
        const body = e.body || (e.response && e.response.body) || null;
        err = _classifyHttpErrorM(status, body, ctx);
      }
      lastErr = err;
      const retryable = (err instanceof TxnPlatformError) && (category === 1 || category === 2);
      if (!retryable) break;
      attempt += 1;
      if (attempt >= maxRetries) break;
      await _txnBackoffM(attempt);
    }
  }
  if (safe) {
    console.warn(`[txn/mobile] ${serviceId}.${opId} failed:`, lastErr);
    return null;
  }
  throw lastErr;
};

SuperoClient.prototype.registerTransactionalExtensions = function(mapping) {
  if (!this._txnExtensions) this._txnExtensions = {};
  const TWO_SCHEMA = {
    cart:               ['extending_schema', 'cart_item_extending_schema'],
    order:              ['extending_schema', 'order_item_extending_schema'],
    approval:           ['extending_schema', 'step_extending_schema'],
    inventory:          ['_inventory_schema', '_reservation_schema'],
    loyalty_points:     ['account_extending_schema', 'txn_extending_schema'],
    document_signature: ['extending_schema', 'signature_extending_schema'],
  };
  for (const svc of Object.keys(mapping)) {
    const v = mapping[svc];
    if (typeof v === 'string') {
      this._txnExtensions[svc] = { extending_schema: v };
    } else if (Array.isArray(v)) {
      const slots = TWO_SCHEMA[svc];
      if (!slots) { console.warn(`[txn/mobile] ${svc} is single-schema`); continue; }
      if (v.length !== slots.length) { console.warn(`[txn/mobile] ${svc} expects ${slots.length} schemas`); continue; }
      const e = {};
      slots.forEach((s, i) => e[s] = v[i]);
      this._txnExtensions[svc] = e;
    } else if (v && typeof v === 'object') {
      this._txnExtensions[svc] = { ...v };
    }
  }
};

Object.defineProperty(SuperoClient.prototype, 'transactional', {
  get() {
    if (this._txnAccessor) return this._txnAccessor;
    if (!this._txnExtensions) this._txnExtensions = {};
    const self = this;
    const ex = (svc, op) => (input, opt) => self._txnExecute(svc, op, input || {}, opt);
    this._txnAccessor = {
      task: {
        start:    (uuid, opt) => ex('task', 'start_task')({ task_uuid: uuid }, opt),
        complete: (uuid, opt) => ex('task', 'complete_task')({ task_uuid: uuid }, opt),
        block:    (uuid, reason, opt) => ex('task', 'block_task')({ task_uuid: uuid, blocked_reason: reason }, opt),
        unblock:  (uuid, opt) => ex('task', 'unblock_task')({ task_uuid: uuid }, opt),
        cancel:   (uuid, opt) => ex('task', 'cancel_task')({ task_uuid: uuid }, opt),
      },
      ticket: {
        assign:      (uuid, assignee, opt) => ex('ticket', 'assign_ticket')({ ticket_uuid: uuid, assignee_uuid: assignee }, opt),
        resolve:     (uuid, notes, opt) => ex('ticket', 'resolve_ticket')({ ticket_uuid: uuid, resolution_notes: notes }, opt),
        reopen:      (uuid, opt) => ex('ticket', 'reopen_ticket')({ ticket_uuid: uuid }, opt),
        close:       (uuid, opt) => ex('ticket', 'close_ticket')({ ticket_uuid: uuid }, opt),
        setPriority: (uuid, p, opt) => ex('ticket', 'set_priority')({ ticket_uuid: uuid, priority: p }, opt),
      },
      comment: {
        edit:       (uuid, body, opt) => ex('comment', 'edit_comment')({ comment_uuid: uuid, body }, opt),
        hide:       (uuid, opt) => ex('comment', 'hide_comment')({ comment_uuid: uuid }, opt),
        show:       (uuid, opt) => ex('comment', 'show_comment')({ comment_uuid: uuid }, opt),
        flag:       (uuid, reason, opt) => ex('comment', 'flag_comment')({ comment_uuid: uuid, flag_reason: reason }, opt),
        softDelete: (uuid, opt) => ex('comment', 'soft_delete_comment')({ comment_uuid: uuid }, opt),
        pin:        (uuid, pinned, opt) => ex('comment', 'pin_comment')({ comment_uuid: uuid, pinned }, opt),
      },
      attachment: {
        markUploaded: (uuid, opt) => ex('attachment', 'mark_uploaded')({ attachment_uuid: uuid }, opt),
        markScanned:  (uuid, result, opt) => ex('attachment', 'mark_scanned')({ attachment_uuid: uuid, scan_result: result }, opt),
        archive:      (uuid, opt) => ex('attachment', 'archive_attachment')({ attachment_uuid: uuid }, opt),
        softDelete:   (uuid, opt) => ex('attachment', 'soft_delete_attachment')({ attachment_uuid: uuid }, opt),
        failUpload:   (uuid, reason, opt) => ex('attachment', 'fail_upload')({ attachment_uuid: uuid, failure_reason: reason }, opt),
      },
      feedback: {
        publish:     (uuid, opt) => ex('feedback', 'publish_feedback')({ feedback_uuid: uuid }, opt),
        hide:        (uuid, opt) => ex('feedback', 'hide_feedback')({ feedback_uuid: uuid }, opt),
        show:        (uuid, opt) => ex('feedback', 'show_feedback')({ feedback_uuid: uuid }, opt),
        flag:        (uuid, reason, opt) => ex('feedback', 'flag_feedback')({ feedback_uuid: uuid, flag_reason: reason }, opt),
        markHelpful: (uuid, opt) => ex('feedback', 'mark_helpful')({ feedback_uuid: uuid }, opt),
      },
      membership: {
        enroll:    (uuid, role, opt) => ex('membership', 'enroll_member')({ membership_uuid: uuid, role }, opt),
        suspend:   (uuid, reason, opt) => ex('membership', 'suspend_member')({ membership_uuid: uuid, suspension_reason: reason }, opt),
        reinstate: (uuid, opt) => ex('membership', 'reinstate_member')({ membership_uuid: uuid }, opt),
        expel:     (uuid, reason, opt) => ex('membership', 'expel_member')({ membership_uuid: uuid, expulsion_reason: reason }, opt),
        transfer:  (uuid, target, opt) => ex('membership', 'transfer_member')({ membership_uuid: uuid, transfer_target_uuid: target }, opt),
      },
      notification: {
        send:        (uuid, opt) => ex('notification', 'send_notification')({ notification_uuid: uuid }, opt),
        markSeen:    (uuid, opt) => ex('notification', 'mark_seen')({ notification_uuid: uuid }, opt),
        dismiss:     (uuid, opt) => ex('notification', 'dismiss_notification')({ notification_uuid: uuid }, opt),
        archive:     (uuid, opt) => ex('notification', 'archive_notification')({ notification_uuid: uuid }, opt),
        markAllSeen: (rUuid, rField, opt) => ex('notification', 'mark_all_seen')({ recipient_uuid: rUuid, recipient_field: rField }, opt),
      },
      payment: {
        authorize: (uuid, externalId, opt) => ex('payment', 'authorize_payment')({ payment_uuid: uuid, external_payment_id: externalId }, opt),
        capture:   (uuid, charge, amount, opt) => ex('payment', 'capture_payment')({ payment_uuid: uuid, external_charge_id: charge, capture_amount: amount }, opt),
        refund:    (uuid, amount, opt) => ex('payment', 'refund_payment')({ payment_uuid: uuid, refund_amount: amount }, opt),
        void:      (uuid, reason, opt) => ex('payment', 'void_payment')({ payment_uuid: uuid, reason }, opt),
        fail:      (uuid, reason, opt) => ex('payment', 'fail_payment')({ payment_uuid: uuid, failure_reason: reason }, opt),
      },
      cart: {
        checkout:        (uuid, opt) => ex('cart', 'checkout_cart')({ cart_uuid: uuid }, opt),
        abandon:         (uuid, opt) => ex('cart', 'abandon_cart')({ cart_uuid: uuid }, opt),
        expire:          (uuid, opt) => ex('cart', 'expire_cart')({ cart_uuid: uuid }, opt),
        recomputeTotals: (uuid, opt) => ex('cart', 'recompute_totals')({ cart_uuid: uuid }, opt),
      },
      order: {
        place:           (uuid, opt) => ex('order', 'place_order')({ order_uuid: uuid }, opt),
        fulfill:         (uuid, notes, opt) => ex('order', 'fulfill_order')({ order_uuid: uuid, fulfillment_notes: notes }, opt),
        cancel:          (uuid, reason, opt) => ex('order', 'cancel_order')({ order_uuid: uuid, cancellation_reason: reason }, opt),
        recomputeTotals: (uuid, opt) => ex('order', 'recompute_order_totals')({ order_uuid: uuid }, opt),
      },
      booking: {
        book:              (uuid, opt) => ex('booking', 'book_slot')({ booking_uuid: uuid }, opt),
        cancel:            (uuid, reason, opt) => ex('booking', 'cancel_booking')({ booking_uuid: uuid, cancellation_reason: reason }, opt),
        reschedule:        (uuid, start, end, opt) => ex('booking', 'reschedule_booking')({ booking_uuid: uuid, start_time: start, end_time: end }, opt),
        complete:          (uuid, opt) => ex('booking', 'complete_booking')({ booking_uuid: uuid }, opt),
        checkAvailability: (res, field, start, end, opt) => ex('booking', 'check_availability')({ resource_uuid: res, resource_field: field, start_time: start, end_time: end }, opt),
      },
      appointment: {
        schedule:   (uuid, opt) => ex('appointment', 'schedule_appointment')({ appointment_uuid: uuid }, opt),
        cancel:     (uuid, reason, opt) => ex('appointment', 'cancel_appointment')({ appointment_uuid: uuid, cancellation_reason: reason }, opt),
        reschedule: (uuid, start, end, opt) => ex('appointment', 'reschedule_appointment')({ appointment_uuid: uuid, start_time: start, end_time: end }, opt),
        complete:   (uuid, notes, opt) => ex('appointment', 'complete_appointment')({ appointment_uuid: uuid, notes }, opt),
        markNoShow: (uuid, opt) => ex('appointment', 'mark_no_show')({ appointment_uuid: uuid }, opt),
      },
      recurringPlan: {
        start:       (uuid, opt) => ex('recurring_plan', 'start_plan')({ plan_uuid: uuid }, opt),
        pause:       (uuid, opt) => ex('recurring_plan', 'pause_plan')({ plan_uuid: uuid }, opt),
        resume:      (uuid, opt) => ex('recurring_plan', 'resume_plan')({ plan_uuid: uuid }, opt),
        cancel:      (uuid, reason, immediate, opt) => ex('recurring_plan', 'cancel_plan')({ plan_uuid: uuid, cancellation_reason: reason, immediate: !!immediate }, opt),
        renewPeriod: (uuid, opt) => ex('recurring_plan', 'renew_period')({ plan_uuid: uuid }, opt),
      },
      approval: {
        submit:       (uuid, opt) => ex('approval', 'submit_approval')({ approval_uuid: uuid }, opt),
        approveStep:  (uuid, notes, opt) => ex('approval', 'approve_step')({ approval_uuid: uuid, decision_notes: notes }, opt),
        rejectStep:   (uuid, notes, opt) => ex('approval', 'reject_step')({ approval_uuid: uuid, decision_notes: notes }, opt),
        delegateStep: (uuid, target, opt) => ex('approval', 'delegate_step')({ approval_uuid: uuid, delegated_to_uuid: target }, opt),
        withdraw:     (uuid, opt) => ex('approval', 'withdraw_approval')({ approval_uuid: uuid }, opt),
      },
      inventory: {
        reserve:        (uuid, opt) => ex('inventory', 'reserve_stock')({ reservation_uuid: uuid }, opt),
        commit:         (uuid, opt) => ex('inventory', 'commit_reservation')({ reservation_uuid: uuid }, opt),
        release:        (uuid, opt) => ex('inventory', 'release_reservation')({ reservation_uuid: uuid }, opt),
        adjustQuantity: (uuid, delta, opt) => ex('inventory', 'adjust_quantity')({ inventory_uuid: uuid, delta }, opt),
      },
      loyaltyPoints: {
        accrue:  (uuid, opt) => ex('loyalty_points', 'accrue_points')({ txn_uuid: uuid }, opt),
        redeem:  (uuid, opt) => ex('loyalty_points', 'redeem_points')({ txn_uuid: uuid }, opt),
        expire:  (uuid, opt) => ex('loyalty_points', 'expire_points')({ txn_uuid: uuid }, opt),
        reverse: (uuid, opt) => ex('loyalty_points', 'reverse_txn')({ txn_uuid: uuid }, opt),
      },
      documentSignature: {
        request: (uuid, opt) => ex('document_signature', 'request_signatures')({ document_uuid: uuid }, opt),
        sign:    (uuid, data, ip, opt) => ex('document_signature', 'sign_document')({ signature_uuid: uuid, signature_data: data, ip_address: ip }, opt),
        decline: (uuid, reason, opt) => ex('document_signature', 'decline_signature')({ signature_uuid: uuid, decline_reason: reason }, opt),
        void:    (uuid, reason, opt) => ex('document_signature', 'void_document')({ document_uuid: uuid, void_reason: reason }, opt),
      },
      execute: (svc, op, input, opt) => self._txnExecute(svc, op, input || {}, opt),
      registerExtensions: (m) => self.registerTransactionalExtensions(m),
    };
    return this._txnAccessor;
  },
  configurable: true,
});

Object.defineProperty(SuperoClient.prototype, 'refs', {
  get() {
    if (this._refsAccessor) return this._refsAccessor;
    const self = this;
    this._refsAccessor = {
      add: (sourceType, sourceUuid, refName, targetUuid) =>
        self.request('PUT', `/api/v1/crud/${self.domain}/ref-update`, {
          type: sourceType, uuid: sourceUuid,
          'ref-type': refName, 'ref-uuid': targetUuid,
          operation: 'ADD',
        }),
      remove: (sourceType, sourceUuid, refName, targetUuid) =>
        self.request('PUT', `/api/v1/crud/${self.domain}/ref-update`, {
          type: sourceType, uuid: sourceUuid,
          'ref-type': refName, 'ref-uuid': targetUuid,
          operation: 'DELETE',
        }),
      list(record, refName) {
        if (!record || typeof record !== 'object') return [];
        let frag = (refName || '').toLowerCase();
        if (frag.includes(':')) frag = frag.split(':').pop();
        for (const k of Object.keys(record)) {
          if (typeof k === 'string' && k.endsWith('_refs') && k.toLowerCase().includes(frag)) {
            return Array.isArray(record[k]) ? record[k] : [];
          }
        }
        return [];
      },
      hasRef(record, refName, targetUuid) {
        return this.list(record, refName).some(r => r && r.uuid === targetUuid);
      },
      async reAttach(sourceRecord, targetType, targetUuid, refNames) {
        const results = {};
        for (const name of refNames) {
          const refs = this.list(sourceRecord, name);
          results[name] = 0;
          for (const r of refs) {
            if (!r || !r.uuid) continue;
            try { await this.add(targetType, targetUuid, name, r.uuid); results[name] += 1; }
            catch (e) { console.warn(`[refs.reAttach/mobile] failed for ${name}:`, e); }
          }
        }
        return results;
      },
    };
    return this._refsAccessor;
  },
  configurable: true,
});


// ─── Theme/UI primitives ────────────────────────────────────────────────

const TXN_PALETTES_M = {
  blue:   { bg: '#E6F1FB', fg: '#0C447C', border: '#B5D4F4' },
  teal:   { bg: '#E1F5EE', fg: '#085041', border: '#9FE1CB' },
  gray:   { bg: '#F1EFE8', fg: '#444441', border: '#D3D1C7' },
  amber:  { bg: '#FAEEDA', fg: '#633806', border: '#FAC775' },
  red:    { bg: '#FCEBEB', fg: '#791F1F', border: '#F7C1C1' },
  green:  { bg: '#EAF3DE', fg: '#27500A', border: '#C0DD97' },
  purple: { bg: '#EEEDFE', fg: '#3C3489', border: '#CECBF6' },
};
const txnColorM = (c) => TXN_PALETTES_M[c] || TXN_PALETTES_M.gray;

export function TxnStateBadge({ color, label }) {
  const c = txnColorM(color);
  return (
    <View style={{
      alignSelf: 'flex-start',
      paddingHorizontal: 10, paddingVertical: 3,
      borderRadius: 999, backgroundColor: c.bg,
    }}>
      <Text style={{ fontSize: 12, fontWeight: '500', color: c.fg }}>{label || ''}</Text>
    </View>
  );
}

export function TxnActionButton({ kind = 'secondary', label, onPress, disabled, fullWidth }) {
  const styles = {
    primary:    { bg: '#0284c7', fg: '#fff', border: '#0284c7' },
    secondary:  { bg: '#fff', fg: '#0f172a', border: '#cbd5e1' },
    destructive:{ bg: 'transparent', fg: '#A32D2D', border: '#F09595' },
  }[kind] || {};
  return (
    <TouchableOpacity
      onPress={onPress} disabled={disabled}
      style={{
        paddingHorizontal: 14, paddingVertical: 9,
        borderWidth: 0.5, borderColor: styles.border,
        borderRadius: 6, backgroundColor: styles.bg,
        opacity: disabled ? 0.5 : 1,
        alignSelf: fullWidth ? 'stretch' : 'flex-start',
        alignItems: 'center',
      }}
    >
      <Text style={{ fontSize: 13, color: styles.fg, fontWeight: kind === 'primary' ? '500' : '400' }}>{label}</Text>
    </TouchableOpacity>
  );
}

function TxnActionSheetM({ visible, actions, onSelect, onClose, viewCfg }) {
  return (
    <Modal animationType="slide" transparent visible={visible} onRequestClose={onClose}>
      <TouchableOpacity activeOpacity={1} onPress={onClose}
        style={{ flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.4)' }}>
        <TouchableOpacity activeOpacity={1} style={{
          backgroundColor: '#fff',
          borderTopLeftRadius: 16, borderTopRightRadius: 16,
          paddingVertical: 8, paddingBottom: 24,
        }}>
          <View style={{ alignItems: 'center', paddingVertical: 8 }}>
            <View style={{ width: 36, height: 4, borderRadius: 2, backgroundColor: '#cbd5e1' }} />
          </View>
          {actions.map((a) => {
            const isPrimary = a.op === viewCfg.primary_action;
            const isDestructive = (viewCfg.destructive_actions || []).includes(a.op);
            const isCat3 = a.category === 3;
            return (
              <TouchableOpacity key={a.op}
                onPress={() => { onClose(); onSelect(a.op); }}
                style={{
                  paddingHorizontal: 20, paddingVertical: 14,
                  borderBottomWidth: 0.5, borderBottomColor: '#e2e8f0',
                  flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
                }}>
                <Text style={{
                  fontSize: 16,
                  fontWeight: isPrimary ? '500' : '400',
                  color: isDestructive ? '#A32D2D' : isPrimary ? '#0284c7' : '#0f172a',
                }}>{a.label}</Text>
                {isCat3 && <Text style={{ fontSize: 11, color: '#633806' }}>⚠ retries unsafe</Text>}
              </TouchableOpacity>
            );
          })}
          <TouchableOpacity onPress={onClose} style={{ paddingHorizontal: 20, paddingVertical: 14 }}>
            <Text style={{ fontSize: 16, color: '#64748b', textAlign: 'center' }}>Cancel</Text>
          </TouchableOpacity>
        </TouchableOpacity>
      </TouchableOpacity>
    </Modal>
  );
}

function _txnDefaultErrorMessageM(err) {
  if (err instanceof TxnStateConflictError) return err.message || 'Cannot perform that action in the current state';
  if (err instanceof TxnNotFoundError) return 'Record not found';
  if (err instanceof TxnBadRequestError) return err.message || 'Invalid request';
  if (err instanceof TxnSoftFailureError) return err.message || 'Action could not complete';
  if (err instanceof TxnPlatformError) return 'Platform error — please try again';
  return (err && err.message) || 'Action failed';
}

async function _txnRunActionM(client, serviceId, opId, input, opts = {}) {
  const category = _txnOpCategoryM(serviceId, opId);
  if (category === 3 && !opts.skipConfirm) {
    const proceed = await new Promise((resolve) => {
      Alert.alert(
        'Confirm action',
        opts.confirmMessage || 'This action cannot be safely retried. Continue?',
        [
          { text: 'Cancel', style: 'cancel', onPress: () => resolve(false) },
          { text: 'Continue', style: 'destructive', onPress: () => resolve(true) },
        ]
      );
    });
    if (!proceed) return null;
  }
  try {
    const result = await client._txnExecute(serviceId, opId, input, { maxRetries: opts.maxRetries });
    if (opts.onSuccess) opts.onSuccess(result);
    return result;
  } catch (err) {
    const ctx = { service: serviceId, operation: opId };
    const override = SuperoTransactionalRegistry._runErrorHandlers(err, ctx);
    const msg = override ? override.toast : _txnDefaultErrorMessageM(err);
    Alert.alert('Action failed', msg);
    if (opts.onError) opts.onError(err);
    return null;
  }
}


// ─── Schema qualifier (mirror of web) ───────────────────────────────────

function _qualifySchemaNameM(name) {
  if (!name) return name;
  if (name.includes(':')) return name;
  const cfg = getConfig();
  // SUPERO_NAMESPACE_REQUIRED_V1 — fail loud, never fall back to domain.
  if (!cfg || !cfg.appNamespace) {
      throw new Error(
          '[Supero Mobile SDK] cfg.appNamespace is missing or empty. ' +
          'Without it, CRUD URLs silently route to the domain ' +
          'namespace and return empty results.\n\n' +
          'Fix: ensure your bundle\'s appConfig (typically in ' +
          'appConfig.ts) sets appNamespace. The AI service writes ' +
          'this at app-generation time from project.schema_namespace.\n\n' +
          'See SUPERO_NAMESPACE_REQUIRED_V1.'
      );
  }
  const ns = cfg.appNamespace.toLowerCase().replace(/-/g, '_');
  const SYSTEM = ['project', 'tenant', 'user_account', 'api_key', 'domain', 'access_policy', 'access_rule', 'schema'];
  if (SYSTEM.includes(name)) return name;
  return ns ? `${ns}:${name}` : name;
}


// ─── TransactionalListScreen ────────────────────────────────────────────

export function TransactionalListScreen({ route, navigation }) {
  const tab = (route && route.params && route.params.tab);
  if (!tab) {
    return <View style={{ flex: 1, padding: 24 }}><Text>No tab in route params</Text></View>;
  }

  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');
  const [sheetFor, setSheetFor] = useState(null);
  const [refreshTick, setRefreshTick] = useState(0);
  // SUPERO_MOBILE_TXN_AUTOLOAD_LIST_V1
  // Track registry-ready state so this screen re-renders once
  // the transactional manifest finishes fetching. Without this,
  // the registry might fill AFTER this screen first renders, leaving
  // gray badges and empty action arrays on screen forever.
  const [_txnRegReady, _setTxnRegReady] = useState(
    SuperoTransactionalRegistry.isLoaded()
  );
  useEffect(() => {
    if (_txnRegReady) return;
    let mounted = true;
    SuperoTransactionalRegistry.load()
      .then(() => { if (mounted) _setTxnRegReady(true); })
      .catch(() => { if (mounted) _setTxnRegReady(true); });
    return () => { mounted = false; };
  }, [_txnRegReady]);


  const qualified = _qualifySchemaNameM(tab.schema);
  const viewCfg = SuperoTransactionalRegistry.viewConfig(qualified) || {};
  const serviceId = viewCfg.service;
  const stateField = viewCfg.state_field || 'status';
  const titleField = viewCfg.title_field || 'name';
  const summaryFields = viewCfg.summary_fields || [titleField];

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const resp = await client.request('GET', `/api/v1/crud/${client.domain}/${qualified}`);
        if (cancelled) return;
        const rows = resp.results || resp.data || resp || [];
        setItems(Array.isArray(rows) ? rows : []);
      } catch (e) {
        if (!cancelled) setItems([]);
      } finally {
        if (!cancelled) { setLoading(false); setRefreshing(false); }
      }
    })();
    return () => { cancelled = true; };
  }, [qualified, refreshTick]);

  const onRefresh = useCallback(() => { setRefreshing(true); setRefreshTick(t => t + 1); }, []);

  if (!serviceId) {
    return (
      <View style={{ flex: 1, padding: 24 }}>
        <Text style={{ fontSize: 14, color: '#64748b' }}>
          No transactionalViews entry for {qualified}.
        </Text>
        <Text style={{ fontSize: 12, color: '#94a3b8', marginTop: 4 }}>
          Add one via setConfig to enable the transactional view.
        </Text>
      </View>
    );
  }

  const svcDef = SuperoTransactionalRegistry.get(serviceId) || {};
  const allStates = svcDef.states ? Object.keys(svcDef.states) : [];

  const filtered = items.filter(r => {
    if (filter !== 'all' && r[stateField] !== filter) return false;
    if (search) {
      const hay = JSON.stringify(r).toLowerCase();
      if (!hay.includes(search.toLowerCase())) return false;
    }
    return true;
  });

  const onRowAction = async (record, opId) => {
    const op = SuperoTransactionalRegistry.operation(serviceId, opId);
    const input = {};
    if (op && op.input) {
      op.input.forEach((field) => {
        if (field.endsWith('_uuid') && field !== 'project_uuid' && field !== 'tenant_uuid') {
          input[field] = record.uuid;
        }
      });
    }
    await _txnRunActionM(client, serviceId, opId, input, {
      onSuccess: () => setRefreshTick(t => t + 1),
    });
  };

  if (loading) {
    return <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}><ActivityIndicator size="large" /></View>;
  }

  return (
    <View style={{ flex: 1, backgroundColor: '#f8fafc' }}>
      <View style={{ padding: 12, backgroundColor: '#fff', borderBottomWidth: 0.5, borderBottomColor: '#e2e8f0' }}>
        <TextInput
          value={search} onChangeText={setSearch}
          placeholder="Search…"
          style={{
            height: 36, paddingHorizontal: 12,
            borderWidth: 0.5, borderColor: '#e2e8f0',
            borderRadius: 6, fontSize: 14, backgroundColor: '#f8fafc',
          }}
        />
        <ScrollView horizontal showsHorizontalScrollIndicator={false}
          style={{ marginTop: 10 }} contentContainerStyle={{ gap: 8 }}>
          {['all', ...allStates].map((s) => {
            const active = filter === s;
            const label = s === 'all' ? 'All' : SuperoTransactionalRegistry.stateLabel(serviceId, s);
            return (
              <TouchableOpacity key={s} onPress={() => setFilter(s)}
                style={{
                  paddingHorizontal: 12, paddingVertical: 5,
                  borderRadius: 999, borderWidth: 0.5,
                  borderColor: active ? '#B5D4F4' : '#e2e8f0',
                  backgroundColor: active ? '#E6F1FB' : '#fff',
                }}>
                <Text style={{ fontSize: 12, color: active ? '#0C447C' : '#64748b' }}>{label}</Text>
              </TouchableOpacity>
            );
          })}
        </ScrollView>
      </View>

      <FlatList
        data={filtered} keyExtractor={(r) => r.uuid}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        ListEmptyComponent={
          <View style={{ padding: 40, alignItems: 'center' }}>
            <Text style={{ fontSize: 14, color: '#64748b' }}>No records</Text>
          </View>
        }
        renderItem={({ item: record }) => {
          const stateValue = record[stateField];
          const stateColorName = SuperoTransactionalRegistry.stateColor(serviceId, stateValue);
          const stateLbl = SuperoTransactionalRegistry.stateLabel(serviceId, stateValue);
          const actions = SuperoTransactionalRegistry.actionDescriptors(serviceId, stateValue);
          const primaryAction = actions.find(a => a.op === viewCfg.primary_action);

          return (
            <TouchableOpacity
              onPress={() => navigation.navigate(tab.id + '_TxnDetail', { tab, recordUuid: record.uuid })}
              style={{
                backgroundColor: '#fff',
                paddingHorizontal: 16, paddingVertical: 12,
                borderBottomWidth: 0.5, borderBottomColor: '#e2e8f0',
              }}
            >
              <View style={{ flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between' }}>
                <View style={{ flex: 1, marginRight: 12 }}>
                  <Text style={{ fontSize: 15, fontWeight: '500', color: '#0f172a' }}>
                    {record[titleField] || (record.uuid ? record.uuid.slice(0, 8) : '—')}
                  </Text>
                  <Text style={{ fontSize: 12, color: '#64748b', marginTop: 2 }}>
                    {summaryFields.filter(f => f !== titleField).map(f =>
                      `${f}: ${record[f] != null ? record[f] : '—'}`
                    ).join(' · ')}
                  </Text>
                  <View style={{ marginTop: 8 }}>
                    <TxnStateBadge color={stateColorName} label={stateLbl} />
                  </View>
                </View>
                <View style={{ flexDirection: 'row', gap: 6, alignItems: 'center' }}>
                  {primaryAction && (
                    <TouchableOpacity
                      onPress={(e) => { e.stopPropagation(); onRowAction(record, primaryAction.op); }}
                      style={{
                        paddingHorizontal: 12, paddingVertical: 6,
                        backgroundColor: '#0284c7', borderRadius: 6,
                      }}
                    >
                      <Text style={{ color: '#fff', fontSize: 12, fontWeight: '500' }}>{primaryAction.label}</Text>
                    </TouchableOpacity>
                  )}
                  {actions.length > (primaryAction ? 1 : 0) && (
                    <TouchableOpacity
                      onPress={(e) => { e.stopPropagation(); setSheetFor({ record, actions }); }}
                      style={{ width: 32, height: 32, alignItems: 'center', justifyContent: 'center' }}
                    >
                      <Text style={{ fontSize: 18, color: '#94a3b8' }}>⋯</Text>
                    </TouchableOpacity>
                  )}
                </View>
              </View>
            </TouchableOpacity>
          );
        }}
      />

      <TxnActionSheetM
        visible={!!sheetFor}
        actions={sheetFor ? sheetFor.actions : []}
        viewCfg={viewCfg}
        onClose={() => setSheetFor(null)}
        onSelect={(opId) => { if (sheetFor) onRowAction(sheetFor.record, opId); }}
      />
    </View>
  );
}


// ─── TransactionalDetailScreen ──────────────────────────────────────────

export function TransactionalDetailScreen({ route, navigation }) {
  const { tab, recordUuid } = (route && route.params) || {};
  const [record, setRecord] = useState(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [children, setChildren] = useState([]);
  const [refsExpanded, setRefsExpanded] = useState(true);
  // SUPERO_MOBILE_TXN_AUTOLOAD_DETAIL_V1
  // Same pattern as TransactionalListScreen — re-render when the
  // registry finishes loading so action descriptors / state colors
  // appear correctly on first view.
  const [_txnRegReady, _setTxnRegReady] = useState(
    SuperoTransactionalRegistry.isLoaded()
  );
  useEffect(() => {
    if (_txnRegReady) return;
    let mounted = true;
    SuperoTransactionalRegistry.load()
      .then(() => { if (mounted) _setTxnRegReady(true); })
      .catch(() => { if (mounted) _setTxnRegReady(true); });
    return () => { mounted = false; };
  }, [_txnRegReady]);


  const qualified = _qualifySchemaNameM(tab.schema);
  const viewCfg = SuperoTransactionalRegistry.viewConfig(qualified) || {};
  const serviceId = viewCfg.service;
  const stateField = viewCfg.state_field || 'status';
  const titleField = viewCfg.title_field || 'name';

  const refresh = useCallback(async () => {
    try {
      const fresh = await client.request('GET', `/api/v1/crud/${client.domain}/${qualified}/${recordUuid}`);
      setRecord(fresh);
    } catch (e) { /* swallow */ }
  }, [recordUuid, qualified]);

  useEffect(() => { refresh().then(() => setLoading(false)); }, [refresh]);

  useEffect(() => {
    if (!record || !viewCfg.child_schema) return;
    const parentField = serviceId === 'cart' ? 'cart_uuid'
      : serviceId === 'order' ? 'order_uuid'
      : serviceId === 'approval' ? 'approval_uuid'
      : 'parent_uuid';
    client.request('GET', `/api/v1/crud/${client.domain}/${viewCfg.child_schema}`)
      .then(resp => {
        const rows = resp.results || resp.data || resp || [];
        setChildren(rows.filter(r => r[parentField] === record.uuid));
      })
      .catch(() => setChildren([]));
  }, [record && record.uuid]);

  if (loading || !record) {
    return <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}><ActivityIndicator size="large" /></View>;
  }

  if (!serviceId) {
    return (
      <View style={{ flex: 1, padding: 24 }}>
        <Text>No transactionalViews entry for {qualified}</Text>
      </View>
    );
  }

  const stateValue = record[stateField];
  const stateColorName = SuperoTransactionalRegistry.stateColor(serviceId, stateValue);
  const stateLbl = SuperoTransactionalRegistry.stateLabel(serviceId, stateValue);
  const actions = SuperoTransactionalRegistry.actionDescriptors(serviceId, stateValue);
  const primaryOp = viewCfg.primary_action;
  const destructiveOps = viewCfg.destructive_actions || [];

  const onAction = async (opId) => {
    setBusy(true);
    const op = SuperoTransactionalRegistry.operation(serviceId, opId);
    const input = {};
    if (op && op.input) {
      op.input.forEach(field => {
        if (field.endsWith('_uuid') && field !== 'project_uuid' && field !== 'tenant_uuid') {
          input[field] = record.uuid;
        }
      });
    }
    await _txnRunActionM(client, serviceId, opId, input, { onSuccess: refresh });
    setBusy(false);
  };

  const skip = { uuid: 1, fq_name: 1, parent_uuid: 1, parent_type: 1, _id: 1, [stateField]: 1 };
  const fieldKeys = Object.keys(record).filter(k =>
    !skip[k] && !k.endsWith('_refs') && !k.startsWith('_')
  );

  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#f8fafc' }}>
      <View style={{ padding: 16, backgroundColor: '#fff', borderBottomWidth: 0.5, borderBottomColor: '#e2e8f0' }}>
        <Text style={{ fontSize: 20, fontWeight: '500', color: '#0f172a' }}>
          {record[titleField] || (record.uuid ? record.uuid.slice(0, 8) : '—')}
        </Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 8, gap: 8 }}>
          <TxnStateBadge color={stateColorName} label={stateLbl} />
          <Text style={{ fontSize: 11, color: '#64748b' }}>{(record.uuid || '').slice(0, 12)}…</Text>
        </View>
      </View>

      <View style={{ padding: 12, backgroundColor: '#fff', borderBottomWidth: 0.5, borderBottomColor: '#e2e8f0', gap: 8 }}>
        {actions.length === 0 && (
          <Text style={{ fontSize: 12, color: '#64748b', textAlign: 'center' }}>
            No actions available in current state
          </Text>
        )}
        {actions.map((a) => {
          const kind = a.op === primaryOp ? 'primary'
            : destructiveOps.includes(a.op) ? 'destructive'
            : 'secondary';
          return <TxnActionButton key={a.op} kind={kind} label={a.label} fullWidth disabled={busy} onPress={() => onAction(a.op)} />;
        })}
      </View>

      <View style={{ padding: 16, backgroundColor: '#fff', marginTop: 8 }}>
        <Text style={{ fontSize: 11, fontWeight: '500', color: '#64748b', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 10 }}>
          Details
        </Text>
        {fieldKeys.slice(0, 12).map(k => (
          <View key={k} style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 6, borderBottomWidth: 0.5, borderBottomColor: '#f1f5f9' }}>
            <Text style={{ fontSize: 13, color: '#64748b' }}>{k}</Text>
            <Text style={{ fontSize: 13, color: '#0f172a', flex: 1, textAlign: 'right', marginLeft: 12 }}>
              {typeof formatFieldValue !== 'undefined' ? formatFieldValue(k, record[k]) : (record[k] == null ? '—' : String(record[k]))}
            </Text>
          </View>
        ))}
      </View>

      {viewCfg.child_schema && children.length > 0 && (
        <View style={{ padding: 16, backgroundColor: '#fff', marginTop: 8 }}>
          <Text style={{ fontSize: 11, fontWeight: '500', color: '#64748b', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 10 }}>
            Items · {viewCfg.child_schema}
          </Text>
          {children.map(c => (
            <View key={c.uuid} style={{ paddingVertical: 8, borderBottomWidth: 0.5, borderBottomColor: '#f1f5f9' }}>
              <Text style={{ fontSize: 14, color: '#0f172a' }}>
                {c.name || (c.uuid ? c.uuid.slice(0, 8) : '—')}
              </Text>
              <Text style={{ fontSize: 12, color: '#64748b', marginTop: 2 }}>
                {Object.keys(c).filter(k =>
                  k !== 'uuid' && !k.endsWith('_refs') && !k.startsWith('_') && !k.endsWith('_uuid') && k !== 'fq_name' && k !== 'name'
                ).slice(0, 3).map(k => `${k}: ${c[k] != null ? c[k] : '—'}`).join(' · ')}
              </Text>
            </View>
          ))}
        </View>
      )}

      {viewCfg.ref_panel && viewCfg.ref_panel.length > 0 && (
        <View style={{ padding: 16, backgroundColor: '#fff', marginTop: 8, marginBottom: 16 }}>
          <TouchableOpacity
            onPress={() => setRefsExpanded(!refsExpanded)}
            style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: refsExpanded ? 10 : 0 }}
          >
            <Text style={{ fontSize: 11, fontWeight: '500', color: '#64748b', textTransform: 'uppercase', letterSpacing: 0.5 }}>
              References
            </Text>
            <Text style={{ fontSize: 16, color: '#94a3b8' }}>{refsExpanded ? '▾' : '▸'}</Text>
          </TouchableOpacity>
          {refsExpanded && viewCfg.ref_panel.map(refName => {
            const refs = client.refs.list(record, refName);
            return (
              <View key={refName} style={{ marginBottom: 10 }}>
                <Text style={{ fontSize: 12, fontWeight: '500', color: '#0f172a', marginBottom: 4 }}>
                  {refName}
                </Text>
                {refs.length === 0 ? (
                  <View style={{
                    paddingVertical: 8, paddingHorizontal: 10,
                    borderWidth: 0.5, borderStyle: 'dashed', borderColor: '#cbd5e1',
                    borderRadius: 6, alignItems: 'center',
                  }}>
                    <Text style={{ fontSize: 12, color: '#64748b' }}>No {refName} attached</Text>
                  </View>
                ) : (
                  refs.map(r => (
                    <View key={r.uuid} style={{
                      flexDirection: 'row', alignItems: 'center',
                      padding: 8, borderRadius: 6,
                      backgroundColor: '#f8fafc', marginBottom: 4,
                    }}>
                      <Text style={{ flex: 1, fontSize: 13, color: '#0f172a' }}>
                        {r.name || (r.uuid ? r.uuid.slice(0, 8) : '—')}
                      </Text>
                      <TouchableOpacity onPress={async () => {
                        try {
                          await client.refs.remove(qualified, record.uuid, refName, r.uuid);
                          refresh();
                        } catch (e) { Alert.alert('Failed to remove ref'); }
                      }}>
                        <Text style={{ fontSize: 18, color: '#94a3b8', paddingHorizontal: 8 }}>×</Text>
                      </TouchableOpacity>
                    </View>
                  ))
                )}
              </View>
            );
          })}
        </View>
      )}
    </ScrollView>
  );
}

export const SUPERO_MOBILE_VERSION = '3.3.1';

// SUPERO_SERVICES_UI_V3_REVIEW_FIXES_APPLIED

// SUPERO_SERVICES_UI_V3_1_B2_S1_APPLIED

// SUPERO_SERVICES_UI_V3_2_QUALITY_FIXES_APPLIED
