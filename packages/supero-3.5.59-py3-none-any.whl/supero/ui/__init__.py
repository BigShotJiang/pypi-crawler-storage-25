"""Frontend library bundles.

Exposes filesystem paths to the bundled supero-ui.js (browser) and
supero-mobile.jsx (React Native) so:

- supero.server can serve supero-ui.js to browsers
- mobile/expo.sh can copy supero-mobile.jsx into projects (replacing
  the previous CDN curl per §1.3)
- platform-core's Cloud Build can extract these via extract_to_project
  (per §1.8)

The actual binary content (~544KB supero-ui.js, ~84KB supero-mobile.jsx)
lives next to this file inside the wheel. Per blueprint §1.1 the wheel
is the single source of truth for both.
"""
from importlib.resources import files
import os

_ROOT = files(__package__)


def get_path(name: str) -> str:
    """Return absolute path to the named bundled UI artifact.

    Raises FileNotFoundError if the artifact isn't bundled.
    """
    p = _ROOT / name
    if not os.path.isfile(str(p)):
        raise FileNotFoundError(
            f"No bundled UI artifact: {name!r}. "
            f"Looked in {_ROOT}."
        )
    return str(p)


def web_lib_path() -> str:
    """Filesystem path to supero-ui.js inside the installed wheel."""
    return get_path("supero-ui.js")


def mobile_lib_path() -> str:
    """Filesystem path to supero-mobile.jsx inside the installed wheel."""
    return get_path("supero-mobile.jsx")


# ─── BEGIN SERVICE_UI_MANIFESTS_V1 ───
# Loader functions for tenant-services UI manifests bundled at build time
# (see build.sh SERVICE_UI_MANIFESTS_V1 block).

def list_service_ui_manifest_ids() -> list:
    """Return sorted list of service IDs that have a bundled UI manifest.

    Returns [] if no manifests are bundled (e.g., dev install before
    build.sh has run).
    """
    services_dir = _ROOT / "schemas" / "services"
    if not os.path.isdir(str(services_dir)):
        return []
    return sorted(
        entry.name[:-len(".ui.json")]
        for entry in services_dir.iterdir()
        if entry.name.endswith(".ui.json")
    )


def get_service_ui_manifest(service_id: str) -> dict:
    """Return parsed UI manifest dict for service_id, or None if not bundled.

    Does NOT raise on missing — caller can check list_service_ui_manifest_ids()
    first if they need raising behavior.
    """
    import json
    p = _ROOT / "schemas" / "services" / f"{service_id}.ui.json"
    if not os.path.isfile(str(p)):
        return None
    with open(str(p), "r", encoding="utf-8") as f:
        return json.load(f)


def get_all_service_ui_manifests() -> dict:
    """Return {service_id: parsed_manifest_dict} for every bundled service.

    Convenience for build-time consumers (supero.cli --build-ui-schemas).
    """
    return {sid: get_service_ui_manifest(sid)
            for sid in list_service_ui_manifest_ids()}
# ─── END SERVICE_UI_MANIFESTS_V1 ───


__all__ = [
    "web_lib_path",
    "mobile_lib_path",
    "get_path",
    # SERVICE_UI_MANIFESTS_V1
    "list_service_ui_manifest_ids",
    "get_service_ui_manifest",
    "get_all_service_ui_manifests",
]
