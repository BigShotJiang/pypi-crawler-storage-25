// ═══════════════════════════════════════════════════════════════════════════
// SuperoUIDispatcher — schema-driven field renderer
//
// Routes a field's value to a renderer function based on either:
//   1. A tenant-specific renderer schema (via SuperoUISchemaResolver lookup),
//      OR
//   2. An explicit fallback type ('currency', 'lifecycle_state', etc.)
//
// Renderers return React elements (or plain strings for trivial cases).
//
// Loaded by index.html BEFORE supero-ui.js, so it's available to both
// supero-ui.js internals (future patches) and tenant app.js code.
//
// Patch 1 (current): infrastructure + 5 renderers.
// Future patches will add 27 more renderers and 27 editors.
//
// Usage from tenant app.js or supero-ui.js:
//   SuperoUIDispatcher.renderField({
//       uiSchemaName: 'flowtix:vendor_admin_ui',  // optional tenant override
//       fieldName: 'status',                       // field name on the record
//       value: item.status,                        // raw value
//       item: item,                                // optional, for context
//       fallbackRenderer: 'lifecycle_state'        // used if no override
//   });
// ═══════════════════════════════════════════════════════════════════════════

var SuperoUIDispatcher = (function() {
    'use strict';

    // ── Module version (for debugging / future compat) ──
    var VERSION = '1.3.0';   // bumped by Patch 4a (+highlight/info_alt categories for lifecycle_state)

    // ── Renderer registry ──
    var _renderers = {};

    function registerRenderer(type, fn) {
        _renderers[type] = fn;
    }

    function getRenderer(type) {
        return _renderers[type] || null;
    }

    // ── Convention override hook ──
    // Default convention for turning (uiSchemaName, fieldName) into a tenant
    // renderer schema name. Tenants can call setResolverConvention(fn) to
    // override before any renderField call.
    function _defaultConvention(uiSchemaName, fieldName) {
        var bare = uiSchemaName.indexOf(':') >= 0
            ? uiSchemaName.split(':')[1]
            : uiSchemaName;
        var ns = uiSchemaName.indexOf(':') >= 0
            ? uiSchemaName.split(':')[0]
            : null;
        if (!ns) return null;

        var recordName = bare
            .replace(/_admin_ui$/, '')
            .replace(/_live_app_(?:authed|public)_ui$/, '')
            .replace(/_ui$/, '');

        return ns + ':' + recordName + '_' + fieldName + '_renderer';
    }

    var _conventionFn = _defaultConvention;

    function setResolverConvention(fn) {
        if (typeof fn !== 'function') {
            console.warn('[SuperoUIDispatcher] setResolverConvention requires a function');
            return;
        }
        _conventionFn = fn;
    }

    // ── Resolve tenant renderer override ──
    // Convention: <namespace>:<record>_<field>_renderer
    // e.g. flowtix:vendor_email_renderer extends supero_ui:email_renderer
    function resolveRenderer(uiSchemaName, fieldName) {
        if (typeof SuperoUISchemaResolver === 'undefined') return null;
        if (!uiSchemaName || !fieldName) return null;

        var rendererName;
        try {
            rendererName = _conventionFn(uiSchemaName, fieldName);
        } catch (e) {
            if (typeof console !== 'undefined') {
                console.error('[SuperoUIDispatcher] convention function threw: ' + e);
            }
            return null;
        }
        if (!rendererName) return null;

        var schema = SuperoUISchemaResolver.resolve(rendererName);
        if (!schema) return null;

        return SuperoUISchemaResolver.toConfig(rendererName);
    }

    // ── Main entry: renderField ──
    function renderField(opts) {
        opts = opts || {};
        var value = opts.value;
        var item = opts.item || {};
        var rendererType = null;
        var config = {};

        // Try tenant override first
        if (opts.uiSchemaName && opts.fieldName) {
            var overrideConfig = resolveRenderer(opts.uiSchemaName, opts.fieldName);
            if (overrideConfig && overrideConfig.renderer_type) {
                rendererType = overrideConfig.renderer_type;
                config = overrideConfig;
            }
        }

        // Fall back to explicit type
        if (!rendererType && opts.fallbackRenderer) {
            rendererType = opts.fallbackRenderer;
        }

        if (!rendererType) {
            return value == null ? null : String(value);
        }

        var renderer = getRenderer(rendererType);
        if (!renderer) {
            if (typeof console !== 'undefined') {
                console.warn('[SuperoUIDispatcher] no renderer for type: ' + rendererType);
            }
            return value == null ? null : String(value);
        }

        try {
            return renderer(value, config, item);
        } catch (e) {
            if (typeof console !== 'undefined') {
                console.error('[SuperoUIDispatcher] renderer "' + rendererType + '" threw: ' + e);
            }
            return value == null ? null : String(value);
        }
    }

    function listRenderers() {
        return Object.keys(_renderers).sort();
    }

    return {
        VERSION: VERSION,
        registerRenderer: registerRenderer,
        getRenderer: getRenderer,
        renderField: renderField,
        resolveRenderer: resolveRenderer,
        listRenderers: listRenderers,
        setResolverConvention: setResolverConvention,
    };
})();

// ──────────────────────────────────────────────────────────────────────
// BUILT-IN RENDERERS (Patch 1: high-impact subset of 32 total)
// ──────────────────────────────────────────────────────────────────────

// ── currency_renderer ──
// Config:
//   currency_code: 'USD' (default), 'INR', 'EUR', 'GBP', etc.
//   locale: 'en-US' (default), 'en-IN', 'de-DE', etc.
//   show_symbol: true (default) — false uses ISO code instead
//   compact: false (default) — true for '$1.5M' style
SuperoUIDispatcher.registerRenderer('currency', function(value, config, item) {
    if (value == null || value === '') return null;
    var num = typeof value === 'number' ? value : parseFloat(value);
    if (isNaN(num)) return String(value);

    var locale = config.locale
              || (window.__SUPERO_CONFIG && window.__SUPERO_CONFIG.locale)
              || 'en-US';
    var currency = config.currency_code
                || (window.__SUPERO_CONFIG && window.__SUPERO_CONFIG.currencyCode)
                || 'USD';
    var compact = config.compact === true;

    try {
        var opts = {
            style: 'currency',
            currency: currency,
            currencyDisplay: config.show_symbol === false ? 'code' : 'symbol',
        };
        if (compact && Math.abs(num) >= 1000) {
            opts.notation = 'compact';
            opts.maximumFractionDigits = 1;
        }
        return new Intl.NumberFormat(locale, opts).format(num);
    } catch (e) {
        return (config.show_symbol === false ? currency + ' ' : '$') + num.toFixed(2);
    }
});

// ── lifecycle_state_renderer ──
// Config:
//   state_machine: optional name
//   state_colors: dict mapping state → category (positive|warning|negative|neutral|info)
//                 may be a JSON string or a dict
//   terminal_states: list of "final" state names (rendered slightly muted)
SuperoUIDispatcher.registerRenderer('lifecycle_state', function(value, config, item) {
    if (value == null || value === '') return null;

    var stateStr = String(value);
    var colors = {};
    try {
        if (typeof config.state_colors === 'string') {
            colors = JSON.parse(config.state_colors);
        } else if (config.state_colors && typeof config.state_colors === 'object') {
            colors = config.state_colors;
        }
    } catch (e) {
        if (typeof console !== 'undefined') {
            console.warn(
                '[SuperoUIDispatcher] lifecycle_state: bad state_colors JSON, falling back to heuristics: '
                + (config.state_colors || '').toString().slice(0, 80)
            );
        }
    }

    var categoryClass = {
        positive: 'bg-green-100 text-green-800 ring-green-200',
        warning:  'bg-yellow-100 text-yellow-800 ring-yellow-200',
        negative: 'bg-red-100 text-red-800 ring-red-200',
        neutral:  'bg-gray-100 text-gray-700 ring-gray-200',
        info:     'bg-blue-100 text-blue-800 ring-blue-200',
        // FIELD_RENDERER_DISPATCHER_V1 — added for parity with legacy getStatusColor table:
        highlight: 'bg-purple-100 text-purple-800 ring-purple-200',  // interview, exceptional
        info_alt:  'bg-indigo-100 text-indigo-800 ring-indigo-200',  // offer
    };

    var category = colors[stateStr];

    if (!category) {
        var lowered = stateStr.toLowerCase();
        // Prefix-then-underscore-or-end-of-string matching for compound states
        if (/^(active|approved|completed|confirmed|success|done|published|paid|fulfilled|won|enabled|live|open|ready)(_|$)/.test(lowered)) {
            category = 'positive';
        } else if (/^(pending|in_progress|in_review|review|processing|draft|scheduled|waiting|submitted|requested)(_|$)/.test(lowered)) {
            category = 'warning';
        } else if (/^(rejected|cancelled|canceled|failed|error|expired|denied|terminated|lost|blocked|deleted|void)(_|$)/.test(lowered)) {
            category = 'negative';
        } else if (/^(inactive|archived|paused|on_hold|disabled|closed|dormant)(_|$)/.test(lowered)) {
            category = 'neutral';
        } else {
            category = 'info';
        }
    }

    var className = categoryClass[category] || categoryClass.info;
    var displayText = stateStr.replace(/_/g, ' ');

    var terminalStates = config.terminal_states || [];
    var isTerminal = terminalStates.indexOf && terminalStates.indexOf(stateStr) >= 0;

    return React.createElement('span', {
        className: 'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ring-1 ring-inset ' + className + (isTerminal ? ' opacity-75' : ''),
    }, displayText);
});

// ── rating_renderer ──
// Config:
//   max: 5 (default)
//   show_value: true (default)
//   precision: 'half' (default) | 'integer' | 'continuous'
SuperoUIDispatcher.registerRenderer('rating', function(value, config, item) {
    if (value == null || value === '') return null;
    var num = typeof value === 'number' ? value : parseFloat(value);
    if (isNaN(num)) return String(value);

    var max = parseInt(config.max, 10) || 5;
    var showValue = config.show_value !== false;
    var precision = config.precision || 'half';

    if (precision === 'integer') {
        num = Math.round(num);
    } else if (precision === 'half') {
        num = Math.round(num * 2) / 2;
    }

    // Inline SVG stars — reliable across all fonts/platforms.
    // 'full' = solid yellow, 'half' = yellow left half + gray right half
    // (via clipPath), 'empty' = gray outline.
    function _starSvg(fillState, key) {
        var FILL = '#facc15';     // text-yellow-400
        var EMPTY = '#d1d5db';    // text-gray-300
        var path = 'M8 1.5l1.93 4.5L14.5 6.4l-3.5 3.1.94 4.65L8 11.8l-3.94 2.35.94-4.65-3.5-3.1 4.57-.4z';

        var children;
        if (fillState === 'full') {
            children = [React.createElement('path', { key: 'fg', d: path, fill: FILL })];
        } else if (fillState === 'empty') {
            children = [React.createElement('path', { key: 'fg', d: path, fill: EMPTY })];
        } else {
            // half: gray full underneath, yellow on left half via clipPath
            var clipId = 'sup-star-clip-' + key;
            children = [
                React.createElement('defs', { key: 'defs' },
                    React.createElement('clipPath', { id: clipId },
                        React.createElement('rect', { x: 0, y: 0, width: 8, height: 16 })
                    )
                ),
                React.createElement('path', { key: 'bg', d: path, fill: EMPTY }),
                React.createElement('path', { key: 'fg', d: path, fill: FILL, clipPath: 'url(#' + clipId + ')' }),
            ];
        }

        return React.createElement('svg', {
            key: key,
            width: 14, height: 14,
            viewBox: '0 0 16 16',
            xmlns: 'http://www.w3.org/2000/svg',
            style: { display: 'inline-block', verticalAlign: 'middle' },
            'aria-hidden': 'true',
        }, children);
    }

    var stars = [];
    for (var i = 1; i <= max; i++) {
        var fillState;
        if (num >= i) fillState = 'full';
        else if (num >= i - 0.5) fillState = 'half';
        else fillState = 'empty';
        stars.push(_starSvg(fillState, 'star-' + i));
    }

    var children = [React.createElement('span', {
        key: 'stars',
        className: 'inline-flex tracking-tight',
    }, stars)];

    if (showValue) {
        children.push(React.createElement('span', {
            key: 'val',
            className: 'ml-1.5 text-xs text-gray-500 tabular-nums',
        }, num.toFixed(precision === 'integer' ? 0 : 1) + '/' + max));
    }

    return React.createElement('span', {
        className: 'inline-flex items-center',
    }, children);
});

// ── progress_renderer ──
// Config:
//   max: 100 (default)
//   show_value: true (default)
//   color: 'auto' (default) | 'positive' | 'warning' | 'negative' | 'info'
//   height: 'sm' (default) | 'md' | 'lg'
SuperoUIDispatcher.registerRenderer('progress', function(value, config, item) {
    if (value == null || value === '') return null;
    var num = typeof value === 'number' ? value : parseFloat(value);
    if (isNaN(num)) return String(value);

    var max = parseFloat(config.max) || 100;
    var pct = Math.max(0, Math.min(100, (num / max) * 100));
    var showValue = config.show_value !== false;
    var color = config.color || 'auto';
    var height = config.height || 'sm';

    var fillClass;
    if (color === 'auto') {
        if (pct >= 75) fillClass = 'bg-green-500';
        else if (pct >= 40) fillClass = 'bg-blue-500';
        else if (pct >= 20) fillClass = 'bg-yellow-500';
        else fillClass = 'bg-red-500';
    } else if (color === 'positive') fillClass = 'bg-green-500';
    else if (color === 'warning') fillClass = 'bg-yellow-500';
    else if (color === 'negative') fillClass = 'bg-red-500';
    else fillClass = 'bg-indigo-500';

    var heightClass = height === 'lg' ? 'h-3' : height === 'md' ? 'h-2' : 'h-1.5';

    var bar = React.createElement('div', {
        className: 'w-full bg-gray-200 rounded-full overflow-hidden ' + heightClass,
    },
        React.createElement('div', {
            className: 'h-full rounded-full transition-all duration-500 ' + fillClass,
            style: { width: pct.toFixed(1) + '%' },
        })
    );

    if (!showValue) return bar;

    return React.createElement('div', {
        className: 'flex items-center gap-2',
    },
        React.createElement('div', { className: 'flex-1' }, bar),
        React.createElement('span', {
            className: 'text-xs text-gray-600 tabular-nums whitespace-nowrap',
        }, num + '/' + max)
    );
});

// ── address_renderer ──
// Config:
//   format: 'inline' (default) | 'multiline' | 'short'
//   show_map_link: true (default)
//   map_provider: 'google' (default) | 'apple' | 'osm'
// Value: string, OR object {street, city, state, postal_code, country}
SuperoUIDispatcher.registerRenderer('address', function(value, config, item) {
    if (value == null || value === '') return null;

    var format = config.format || 'inline';
    var showMapLink = config.show_map_link !== false;
    var mapProvider = config.map_provider || 'google';

    var parts;
    var shortPreferred;   // city, state (for 'short' format with object input)
    var mapQuery;
    if (typeof value === 'string') {
        parts = [value];
        shortPreferred = null;   // can't extract city/state from a free-form string
        mapQuery = encodeURIComponent(value);
    } else if (typeof value === 'object') {
        parts = [value.street, value.city, value.state, value.postal_code, value.country]
            .filter(function(p) { return p; });
        // For 'short' format: prefer city + state if both present.
        shortPreferred = [value.city, value.state].filter(function(p) { return p; });
        if (shortPreferred.length === 0) shortPreferred = null;
        mapQuery = encodeURIComponent(parts.join(', '));
    } else {
        return String(value);
    }

    if (parts.length === 0) return null;

    var addrEl;
    if (format === 'multiline') {
        addrEl = React.createElement('div', { className: 'space-y-0.5' },
            parts.map(function(p, i) {
                return React.createElement('div', { key: 'p' + i }, p);
            })
        );
    } else if (format === 'short') {
        // For object input: show city, state. For string input: show the string.
        var shortText = shortPreferred ? shortPreferred.join(', ') : parts.join(', ');
        addrEl = React.createElement('span', null, shortText);
    } else {
        addrEl = React.createElement('span', null, parts.join(', '));
    }

    if (!showMapLink) return addrEl;

    var mapUrl;
    if (mapProvider === 'apple') {
        mapUrl = 'https://maps.apple.com/?q=' + mapQuery;
    } else if (mapProvider === 'osm') {
        mapUrl = 'https://www.openstreetmap.org/search?query=' + mapQuery;
    } else {
        mapUrl = 'https://www.google.com/maps/search/?api=1&query=' + mapQuery;
    }

    return React.createElement('span', { className: 'inline-flex items-center gap-2' },
        addrEl,
        React.createElement('a', {
            href: mapUrl,
            target: '_blank',
            rel: 'noopener noreferrer',
            className: 'text-xs text-indigo-600 hover:text-indigo-800 hover:underline',
            title: 'View on map',
        }, '📍')
    );
});

// ──────────────────────────────────────────────────────────────────────
// BUILT-IN RENDERERS (Patch 2: remaining 27 of 32 total)
//
// Organized by family:
//   Text:     text, markdown, rich_text, code, json
//   Numeric:  number, percentage, price_block
//   Contact:  email, phone, url
//   Date:     date, duration
//   Media:    image, image_gallery, attached_file, pdf_viewer, video
//   Compose:  reference, tag_list, key_value, color_swatch, user
//   UI:       boolean, enum, step_progress, geo_point, map
//
// Conventions used by ALL renderers:
//   - Return null for null/empty values (callers decide how to render absence)
//   - Catch internal errors and fall back to String(value)
//   - Use React.createElement (no JSX, no build step)
//   - Read locale/currency from window.__SUPERO_CONFIG when needed
// ──────────────────────────────────────────────────────────────────────

// ── text_renderer ──
// Simple text passthrough with optional truncation.
// Config:
//   max_length: optional integer — truncates with ellipsis
//   white_space: 'normal' (default) | 'pre' | 'pre-wrap' | 'nowrap'
SuperoUIDispatcher.registerRenderer('text', function(value, config, item) {
    if (value == null || value === '') return null;
    var str = String(value);
    var maxLen = parseInt(config.max_length, 10);
    if (maxLen > 0 && str.length > maxLen) {
        str = str.slice(0, maxLen) + '…';
    }
    var whitespace = config.white_space || 'normal';
    if (whitespace === 'normal') return str;
    return React.createElement('span', {
        style: { whiteSpace: whitespace }
    }, str);
});

// ── markdown_renderer ──
// Renders markdown source via window.renderMarkdown if available, else
// falls back to plain text (markdown source as-is).
// Config: none
SuperoUIDispatcher.registerRenderer('markdown', function(value, config, item) {
    if (value == null || value === '') return null;
    var str = String(value);
    // Prefer a real markdown renderer if supero-ui.js provides one
    if (typeof window !== 'undefined' && typeof window.renderMarkdown === 'function') {
        try {
            var html = window.renderMarkdown(str);
            return React.createElement('div', {
                className: 'prose prose-sm max-w-none',
                dangerouslySetInnerHTML: { __html: html }
            });
        } catch (e) {
            // Fall through to plain
        }
    }
    return React.createElement('span', {
        style: { whiteSpace: 'pre-wrap' }
    }, str);
});

// ── rich_text_renderer ──
// Renders HTML. SECURITY: This renderer trusts the source — by default
// it only strips <script> tags as a minimal defense. If your tenant accepts
// HTML from untrusted sources, you MUST either:
//   (a) sanitize on the backend before storing (recommended), OR
//   (b) load DOMPurify (window.DOMPurify) — this renderer will use it
//       if present.
// Config:
//   class_name: extra wrapper class
SuperoUIDispatcher.registerRenderer('rich_text', function(value, config, item) {
    if (value == null || value === '') return null;
    var html = String(value);
    // Prefer DOMPurify if loaded (window.DOMPurify from a <script> include)
    if (typeof window !== 'undefined' && window.DOMPurify && typeof window.DOMPurify.sanitize === 'function') {
        try {
            html = window.DOMPurify.sanitize(html);
        } catch (e) {
            // Fall through to manual stripping
        }
    } else {
        // Minimal client-side safety — covers the most common script vector.
        // NOT sufficient for untrusted input. Strip script tags, javascript:
        // URLs in href/src, and on*= event handler attributes.
        html = html.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '');
        html = html.replace(/\s(href|src|action|formaction)\s*=\s*(['"])\s*(?:javascript|data|vbscript):[^'"]*\2/gi, '');
        html = html.replace(/\son[a-z]+\s*=\s*(['"])[^'"]*\1/gi, '');
    }
    return React.createElement('div', {
        className: 'rich-text ' + (config.class_name || ''),
        dangerouslySetInnerHTML: { __html: html }
    });
});

// ── code_renderer ──
// Monospace code display with optional language hint.
// Config:
//   language: optional, just used as a CSS class hint (no syntax highlighting)
//   wrap: false (default) — true for soft-wrap
SuperoUIDispatcher.registerRenderer('code', function(value, config, item) {
    if (value == null || value === '') return null;
    var str = String(value);
    var lang = config.language || '';
    var wrap = config.wrap === true;
    return React.createElement('code', {
        className: 'block bg-gray-50 text-gray-800 text-xs font-mono p-2 rounded border border-gray-200 ' + (lang ? 'lang-' + lang : ''),
        style: { whiteSpace: wrap ? 'pre-wrap' : 'pre', overflowX: wrap ? 'visible' : 'auto' }
    }, str);
});

// ── json_renderer ──
// Pretty-printed JSON value. Accepts object/array/string.
// Config:
//   indent: 2 (default)
//   max_chars: optional — truncates with ellipsis
SuperoUIDispatcher.registerRenderer('json', function(value, config, item) {
    if (value == null) return null;
    var indent = parseInt(config.indent, 10);
    if (isNaN(indent)) indent = 2;
    var str;
    try {
        if (typeof value === 'string') {
            // Try parsing in case it's already JSON-encoded
            try {
                str = JSON.stringify(JSON.parse(value), null, indent);
            } catch (parseErr) {
                str = value;
            }
        } else {
            str = JSON.stringify(value, null, indent);
        }
    } catch (e) {
        str = String(value);
    }
    var maxChars = parseInt(config.max_chars, 10);
    if (maxChars > 0 && str.length > maxChars) {
        str = str.slice(0, maxChars) + '…';
    }
    return React.createElement('pre', {
        className: 'bg-gray-50 text-gray-800 text-xs font-mono p-2 rounded border border-gray-200 overflow-x-auto',
        style: { whiteSpace: 'pre' }
    }, str);
});

// ── number_renderer ──
// Locale-aware numeric formatting.
// Config:
//   decimals: optional integer
//   thousands: true (default) — group separators
//   compact: false (default) — '1.5K' / '1.2M' style
//   suffix: optional string appended
//   prefix: optional string prepended
SuperoUIDispatcher.registerRenderer('number', function(value, config, item) {
    if (value == null || value === '') return null;
    var num = typeof value === 'number' ? value : parseFloat(value);
    if (isNaN(num)) return String(value);

    var locale = config.locale
              || (window.__SUPERO_CONFIG && window.__SUPERO_CONFIG.locale)
              || 'en-US';
    var decimals = parseInt(config.decimals, 10);
    var thousands = config.thousands !== false;
    var compact = config.compact === true;

    var opts = { useGrouping: thousands };
    // If both compact and decimals are set, compact takes precedence and
    // we cap fraction digits at 1 (Intl rejects min > max).
    if (compact && Math.abs(num) >= 1000) {
        opts.notation = 'compact';
        opts.maximumFractionDigits = 1;
        // Don't set minimumFractionDigits — compact prefers terse output.
    } else if (!isNaN(decimals)) {
        opts.minimumFractionDigits = decimals;
        opts.maximumFractionDigits = decimals;
    }

    var formatted;
    try {
        formatted = new Intl.NumberFormat(locale, opts).format(num);
    } catch (e) {
        formatted = String(num);
    }

    var prefix = config.prefix || '';
    var suffix = config.suffix || '';
    return prefix + formatted + suffix;
});

// ── percentage_renderer ──
// Renders a fractional or whole-number value as a percentage.
// Config:
//   decimals: 1 (default)
//   input_scale: 'fraction' (default; 0.42 → 42%) | 'whole' (42 → 42%)
SuperoUIDispatcher.registerRenderer('percentage', function(value, config, item) {
    if (value == null || value === '') return null;
    var num = typeof value === 'number' ? value : parseFloat(value);
    if (isNaN(num)) return String(value);

    var inputScale = config.input_scale || 'fraction';
    var pct = inputScale === 'whole' ? num : num * 100;
    var decimals = parseInt(config.decimals, 10);
    if (isNaN(decimals)) decimals = 1;

    return pct.toFixed(decimals) + '%';
});

// ── price_block_renderer ──
// Currency + optional suffix like "/night", "/unit", "/month".
// Config:
//   currency_code, locale, show_symbol — same as currency_renderer
//   suffix: '/unit' (no default) — appended after price
//   size: 'md' (default) | 'sm' | 'lg' — affects font size
SuperoUIDispatcher.registerRenderer('price_block', function(value, config, item) {
    if (value == null || value === '') return null;
    var num = typeof value === 'number' ? value : parseFloat(value);
    if (isNaN(num)) return String(value);

    var locale = config.locale
              || (window.__SUPERO_CONFIG && window.__SUPERO_CONFIG.locale)
              || 'en-US';
    var currency = config.currency_code
                || (window.__SUPERO_CONFIG && window.__SUPERO_CONFIG.currencyCode)
                || 'USD';

    var formatted;
    try {
        formatted = new Intl.NumberFormat(locale, {
            style: 'currency',
            currency: currency,
            currencyDisplay: config.show_symbol === false ? 'code' : 'symbol',
        }).format(num);
    } catch (e) {
        formatted = '$' + num.toFixed(2);
    }

    var suffix = config.suffix || '';
    var size = config.size || 'md';
    var sizeClass = size === 'lg' ? 'text-lg' : size === 'sm' ? 'text-xs' : 'text-sm';

    return React.createElement('span', {
        className: 'inline-flex items-baseline gap-1'
    },
        React.createElement('span', {
            key: 'p',
            className: sizeClass + ' font-semibold text-gray-900 tabular-nums'
        }, formatted),
        suffix && React.createElement('span', {
            key: 's',
            className: 'text-xs text-gray-500'
        }, suffix)
    );
});

// ── email_renderer ──
// Clickable mailto link.
// Config:
//   show_icon: true (default)
//   truncate_at: optional integer
SuperoUIDispatcher.registerRenderer('email', function(value, config, item) {
    if (value == null || value === '') return null;
    var email = String(value).trim();
    if (!email) return null;

    var displayText = email;
    var truncateAt = parseInt(config.truncate_at, 10);
    if (truncateAt > 0 && email.length > truncateAt) {
        displayText = email.slice(0, truncateAt) + '…';
    }

    var showIcon = config.show_icon !== false;

    return React.createElement('a', {
        href: 'mailto:' + encodeURIComponent(email).replace(/%40/g, '@'),
        className: 'text-indigo-600 hover:text-indigo-800 hover:underline inline-flex items-center gap-1',
        title: email
    },
        showIcon && React.createElement('span', { key: 'i', 'aria-hidden': 'true' }, '✉'),
        React.createElement('span', { key: 't' }, displayText)
    );
});

// ── phone_renderer ──
// Clickable tel link with optional country-aware formatting (basic).
// Config:
//   show_icon: true (default)
//   format: 'raw' (default) — phone as-is | 'e164' — normalize
SuperoUIDispatcher.registerRenderer('phone', function(value, config, item) {
    if (value == null || value === '') return null;
    var phone = String(value).trim();
    if (!phone) return null;

    // tel: URI: strip everything except digits and leading +
    var telHref = phone.replace(/[^\d+]/g, '');
    if (!telHref) return phone;

    var displayText = phone;
    if (config.format === 'e164') {
        displayText = telHref.startsWith('+') ? telHref : '+' + telHref;
    }

    var showIcon = config.show_icon !== false;

    return React.createElement('a', {
        href: 'tel:' + telHref,
        className: 'text-indigo-600 hover:text-indigo-800 hover:underline inline-flex items-center gap-1',
        title: phone
    },
        showIcon && React.createElement('span', { key: 'i', 'aria-hidden': 'true' }, '☎'),
        React.createElement('span', { key: 't' }, displayText)
    );
});

// ── url_renderer ──
// Clickable external link.
// Config:
//   show_icon: true (default) — adds ↗ icon
//   truncate_at: optional integer
//   open_in_new: true (default)
SuperoUIDispatcher.registerRenderer('url', function(value, config, item) {
    if (value == null || value === '') return null;
    var url = String(value).trim();
    if (!url) return null;

    // Normalize: prepend https:// if missing scheme.
    // Reject dangerous schemes that could execute code.
    var href = url;
    var schemeMatch = url.match(/^([a-z][a-z0-9+.-]*):/i);
    if (schemeMatch) {
        var scheme = schemeMatch[1].toLowerCase();
        if (scheme === 'javascript' || scheme === 'data' || scheme === 'vbscript' || scheme === 'file') {
            if (typeof console !== 'undefined') {
                console.warn('[SuperoUIDispatcher] url: rejected dangerous scheme: ' + scheme);
            }
            return React.createElement('span', { className: 'text-gray-500 text-xs italic' }, '(rejected URL)');
        }
    } else {
        href = 'https://' + url;
    }

    var displayText = url.replace(/^https?:\/\//, '');
    var truncateAt = parseInt(config.truncate_at, 10);
    if (truncateAt > 0 && displayText.length > truncateAt) {
        displayText = displayText.slice(0, truncateAt) + '…';
    }

    var showIcon = config.show_icon !== false;
    var openInNew = config.open_in_new !== false;

    var linkProps = {
        href: href,
        className: 'text-indigo-600 hover:text-indigo-800 hover:underline inline-flex items-center gap-1',
        title: url,
    };
    if (openInNew) {
        linkProps.target = '_blank';
        linkProps.rel = 'noopener noreferrer';
    }

    return React.createElement('a', linkProps,
        React.createElement('span', { key: 't' }, displayText),
        showIcon && React.createElement('span', {
            key: 'i',
            'aria-hidden': 'true',
            className: 'text-xs opacity-60'
        }, '↗')
    );
});

// ── date_renderer ──
// Locale-aware date/datetime formatting with optional "relative" mode.
// Config:
//   format: 'short' (default) | 'medium' | 'long' | 'full' | 'relative' | 'iso'
//   include_time: false (default)
SuperoUIDispatcher.registerRenderer('date', function(value, config, item) {
    if (value == null || value === '') return null;
    var d;
    if (value instanceof Date) {
        d = value;
    } else {
        d = new Date(value);
    }
    if (isNaN(d.getTime())) return String(value);

    var format = config.format || 'short';
    var includeTime = config.include_time === true;
    var locale = config.locale
              || (window.__SUPERO_CONFIG && window.__SUPERO_CONFIG.locale)
              || 'en-US';

    if (format === 'iso') {
        return d.toISOString();
    }

    if (format === 'relative') {
        var diffMs = d.getTime() - Date.now();
        var diffSec = Math.round(diffMs / 1000);
        var abs = Math.abs(diffSec);
        try {
            var rtf = new Intl.RelativeTimeFormat(locale, { numeric: 'auto' });
            if (abs < 60) return rtf.format(diffSec, 'second');
            if (abs < 3600) return rtf.format(Math.round(diffSec / 60), 'minute');
            if (abs < 86400) return rtf.format(Math.round(diffSec / 3600), 'hour');
            if (abs < 86400 * 30) return rtf.format(Math.round(diffSec / 86400), 'day');
            if (abs < 86400 * 365) return rtf.format(Math.round(diffSec / (86400 * 30)), 'month');
            return rtf.format(Math.round(diffSec / (86400 * 365)), 'year');
        } catch (e) {
            // Fall through to short
            format = 'short';
        }
    }

    var dateStyleMap = { short: 'short', medium: 'medium', long: 'long', full: 'full' };
    var opts = { dateStyle: dateStyleMap[format] || 'short' };
    if (includeTime) opts.timeStyle = 'short';

    try {
        return new Intl.DateTimeFormat(locale, opts).format(d);
    } catch (e) {
        return d.toLocaleDateString();
    }
});

// ── duration_renderer ──
// Human-readable duration. Input: seconds (number) or ISO 8601 duration.
// Config:
//   units: 'auto' (default) | 'seconds' | 'minutes' | 'hours' | 'days'
//   compact: false (default) — '2h 30m' vs 'about 2 hours'
SuperoUIDispatcher.registerRenderer('duration', function(value, config, item) {
    if (value == null || value === '') return null;
    var totalSeconds;
    if (typeof value === 'number') {
        totalSeconds = value;
    } else if (typeof value === 'string') {
        // Try parsing ISO 8601 (PT1H30M) or just digits
        var iso = value.match(/^PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$/);
        if (iso) {
            totalSeconds = (parseInt(iso[1], 10) || 0) * 3600
                         + (parseInt(iso[2], 10) || 0) * 60
                         + (parseInt(iso[3], 10) || 0);
        } else {
            totalSeconds = parseFloat(value);
        }
    }
    if (totalSeconds == null || isNaN(totalSeconds)) return String(value);

    var compact = config.compact === true;
    var sign = totalSeconds < 0 ? '-' : '';
    var abs = Math.abs(totalSeconds);

    var parts = [];
    var days = Math.floor(abs / 86400); abs -= days * 86400;
    var hours = Math.floor(abs / 3600); abs -= hours * 3600;
    var minutes = Math.floor(abs / 60); abs -= minutes * 60;
    var seconds = Math.floor(abs);

    if (compact) {
        if (days > 0) parts.push(days + 'd');
        if (hours > 0) parts.push(hours + 'h');
        if (minutes > 0) parts.push(minutes + 'm');
        if (seconds > 0 && parts.length === 0) parts.push(seconds + 's');
        if (parts.length === 0) parts.push('0s');
    } else {
        if (days > 0) parts.push(days + ' day' + (days !== 1 ? 's' : ''));
        if (hours > 0) parts.push(hours + ' hour' + (hours !== 1 ? 's' : ''));
        if (minutes > 0 && days === 0) parts.push(minutes + ' minute' + (minutes !== 1 ? 's' : ''));
        if (seconds > 0 && days === 0 && hours === 0) parts.push(seconds + ' second' + (seconds !== 1 ? 's' : ''));
        if (parts.length === 0) parts.push('0 seconds');
    }

    return sign + parts.join(compact ? ' ' : ', ');
});

// ── image_renderer ──
// Single image with optional lightbox-on-click.
// Config:
//   size: 'sm' (40px) | 'md' (80px, default) | 'lg' (160px) | 'full'
//   alt: optional string
//   open_lightbox: true (default)
// Value: string URL or object {url, thumbnail_url, alt}
SuperoUIDispatcher.registerRenderer('image', function(value, config, item) {
    if (value == null || value === '') return null;

    var url, thumbUrl, alt;
    if (typeof value === 'string') {
        url = value;
        thumbUrl = value;
        alt = config.alt || '';
    } else if (typeof value === 'object') {
        url = value.url || value.full_url || value.original_url;
        thumbUrl = value.thumbnail_url || value.thumb_url || url;
        alt = value.alt || config.alt || '';
    } else {
        return null;
    }
    if (!url) return null;

    var size = config.size || 'md';
    var sizeStyle;
    if (size === 'full') {
        sizeStyle = { width: '100%', maxWidth: '400px', height: 'auto' };
    } else if (size === 'lg') {
        sizeStyle = { width: '160px', height: '160px', objectFit: 'cover' };
    } else if (size === 'sm') {
        sizeStyle = { width: '40px', height: '40px', objectFit: 'cover' };
    } else {
        sizeStyle = { width: '80px', height: '80px', objectFit: 'cover' };
    }

    var openLightbox = config.open_lightbox !== false;
    var imgProps = {
        src: thumbUrl,
        alt: alt,
        loading: 'lazy',
        className: 'rounded-md border border-gray-200',
        style: sizeStyle,
    };

    if (openLightbox) {
        return React.createElement('a', {
            href: url,
            target: '_blank',
            rel: 'noopener noreferrer',
            title: 'Open full size',
        }, React.createElement('img', imgProps));
    }
    return React.createElement('img', imgProps);
});

// ── image_gallery_renderer ──
// Thumbnail strip of multiple images.
// Config:
//   max_visible: 5 (default)
//   thumb_size: 60 (default, px)
// Value: array of strings/objects (same shape as image_renderer)
SuperoUIDispatcher.registerRenderer('image_gallery', function(value, config, item) {
    if (value == null) return null;
    if (!Array.isArray(value)) value = [value];
    if (value.length === 0) return null;

    var maxVisible = parseInt(config.max_visible, 10) || 5;
    var thumbSize = parseInt(config.thumb_size, 10) || 60;
    var visible = value.slice(0, maxVisible);
    var overflow = value.length - maxVisible;

    var children = visible.map(function(img, i) {
        var url, thumbUrl, alt;
        if (typeof img === 'string') {
            url = img; thumbUrl = img; alt = '';
        } else if (typeof img === 'object' && img !== null) {
            url = img.url || img.full_url || '';
            thumbUrl = img.thumbnail_url || img.thumb_url || url;
            alt = img.alt || '';
        } else {
            return null;
        }
        if (!url) return null;
        return React.createElement('a', {
            key: 'g' + i,
            href: url,
            target: '_blank',
            rel: 'noopener noreferrer',
        },
            React.createElement('img', {
                src: thumbUrl,
                alt: alt,
                loading: 'lazy',
                className: 'rounded border border-gray-200 object-cover',
                style: { width: thumbSize + 'px', height: thumbSize + 'px' }
            })
        );
    }).filter(function(x) { return x !== null; });

    if (overflow > 0) {
        children.push(React.createElement('div', {
            key: 'overflow',
            className: 'flex items-center justify-center rounded border border-gray-200 bg-gray-50 text-gray-500 text-sm font-medium',
            style: { width: thumbSize + 'px', height: thumbSize + 'px' }
        }, '+' + overflow));
    }

    return React.createElement('div', {
        className: 'inline-flex gap-1 flex-wrap'
    }, children);
});

// ── attached_file_renderer ──
// Download link for an arbitrary file.
// Config:
//   show_size: true (default)
//   show_icon: true (default)
// Value: object {url, filename, size_bytes, mime_type} or string URL
SuperoUIDispatcher.registerRenderer('attached_file', function(value, config, item) {
    if (value == null || value === '') return null;
    var url, filename, sizeBytes, mimeType;
    if (typeof value === 'string') {
        url = value;
        filename = url.split('/').pop() || 'file';
    } else if (typeof value === 'object') {
        url = value.url || value.download_url;
        filename = value.filename || value.name || (url ? url.split('/').pop() : 'file');
        sizeBytes = value.size_bytes || value.size;
        mimeType = value.mime_type || value.content_type;
    }
    if (!url) return null;

    var showSize = config.show_size !== false;
    var showIcon = config.show_icon !== false;

    // Pick an icon based on mime/ext
    var icon = '📎';
    var ext = (filename || '').toLowerCase().split('.').pop();
    if (mimeType) {
        if (mimeType.indexOf('pdf') >= 0) icon = '📄';
        else if (mimeType.indexOf('image') === 0) icon = '🖼';
        else if (mimeType.indexOf('video') === 0) icon = '🎞';
        else if (mimeType.indexOf('audio') === 0) icon = '🎵';
        else if (mimeType.indexOf('zip') >= 0 || mimeType.indexOf('compressed') >= 0) icon = '🗜';
    } else if (ext) {
        if (ext === 'pdf') icon = '📄';
        else if (['png','jpg','jpeg','gif','webp','svg'].indexOf(ext) >= 0) icon = '🖼';
        else if (['mp4','mov','avi','webm','mkv'].indexOf(ext) >= 0) icon = '🎞';
        else if (['mp3','wav','ogg','flac'].indexOf(ext) >= 0) icon = '🎵';
        else if (['zip','tar','gz','7z','rar'].indexOf(ext) >= 0) icon = '🗜';
    }

    // Format size
    var sizeText = '';
    if (showSize && sizeBytes != null) {
        var n = parseFloat(sizeBytes);
        if (!isNaN(n)) {
            if (n < 1024) sizeText = n + ' B';
            else if (n < 1024 * 1024) sizeText = (n / 1024).toFixed(1) + ' KB';
            else if (n < 1024 * 1024 * 1024) sizeText = (n / (1024 * 1024)).toFixed(1) + ' MB';
            else sizeText = (n / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
        }
    }

    return React.createElement('a', {
        href: url,
        target: '_blank',
        rel: 'noopener noreferrer',
        download: filename,
        className: 'inline-flex items-center gap-2 px-2 py-1 rounded border border-gray-200 bg-white hover:bg-gray-50 text-sm'
    },
        showIcon && React.createElement('span', { key: 'i', 'aria-hidden': 'true' }, icon),
        React.createElement('span', { key: 'n', className: 'text-gray-800' }, filename),
        sizeText && React.createElement('span', { key: 's', className: 'text-xs text-gray-500' }, '(' + sizeText + ')')
    );
});

// ── pdf_viewer_renderer ──
// Embedded PDF viewer with download fallback. For full PDF UX a tenant
// should provide a custom renderer; this is a minimal default.
// Config:
//   height: 480 (default, px)
//   show_download: true (default)
SuperoUIDispatcher.registerRenderer('pdf_viewer', function(value, config, item) {
    if (value == null || value === '') return null;
    var url;
    if (typeof value === 'string') {
        url = value;
    } else if (typeof value === 'object') {
        url = value.url || value.download_url;
    }
    if (!url) return null;

    var height = parseInt(config.height, 10) || 480;
    var showDownload = config.show_download !== false;

    var children = [
        React.createElement('iframe', {
            key: 'iframe',
            src: url,
            title: 'PDF viewer',
            // Sandbox limits what the embedded content can do:
            // allow-same-origin (PDFs need it for cross-page nav within),
            // no allow-scripts/forms/popups — those would let a malicious
            // HTML masquerading as a PDF run code.
            sandbox: 'allow-same-origin',
            className: 'w-full rounded border border-gray-200 bg-white',
            style: { height: height + 'px' }
        })
    ];
    if (showDownload) {
        children.push(React.createElement('div', {
            key: 'dl',
            className: 'mt-1 text-right'
        },
            React.createElement('a', {
                href: url,
                target: '_blank',
                rel: 'noopener noreferrer',
                download: true,
                className: 'text-xs text-indigo-600 hover:text-indigo-800 hover:underline'
            }, '↓ Download PDF')
        ));
    }
    return React.createElement('div', { className: 'pdf-viewer' }, children);
});

// ── video_renderer ──
// HTML5 video player.
// Config:
//   controls: true (default)
//   autoplay: false (default)
//   loop: false (default)
//   muted: false (default)
//   width: '100%' (default) or px integer
// Value: string URL or object {url, poster_url, mime_type}
SuperoUIDispatcher.registerRenderer('video', function(value, config, item) {
    if (value == null || value === '') return null;
    var url, posterUrl, mimeType;
    if (typeof value === 'string') {
        url = value;
    } else if (typeof value === 'object') {
        url = value.url;
        posterUrl = value.poster_url || value.poster;
        mimeType = value.mime_type || value.content_type;
    }
    if (!url) return null;

    var widthVal = config.width;
    var widthStyle;
    if (widthVal == null) widthStyle = '100%';
    else if (typeof widthVal === 'number') widthStyle = widthVal + 'px';
    else widthStyle = String(widthVal);

    var videoProps = {
        src: url,
        controls: config.controls !== false,
        autoPlay: config.autoplay === true,
        loop: config.loop === true,
        muted: config.muted === true,
        poster: posterUrl,
        className: 'rounded border border-gray-200 bg-black',
        style: { width: widthStyle, maxWidth: '100%' }
    };
    return React.createElement('video', videoProps);
});

// ── reference_renderer ──
// Display a reference to another record. Without a fetch hook, shows the
// display_name from the value object (if shaped like a record) or the
// raw UUID/value as a fallback. To resolve UUIDs to records, set a
// reference resolver via the future setReferenceResolver hook.
// Config:
//   target_schema: name of the referenced data schema (informational)
//   display_field: 'display_name' (default) — field on the referenced record
//   uuid_field: 'uuid' (default)
// Value: string UUID, OR object with the referenced record's data.
SuperoUIDispatcher.registerRenderer('reference', function(value, config, item) {
    if (value == null || value === '') return null;
    var displayField = config.display_field || 'display_name';
    var uuidField = config.uuid_field || 'uuid';

    var label, uuid;
    if (typeof value === 'string') {
        // Looks like a UUID — display abbreviated
        label = value.length > 13 ? value.slice(0, 8) + '…' + value.slice(-4) : value;
        uuid = value;
    } else if (typeof value === 'object') {
        label = value[displayField] || value.name || value[uuidField] || JSON.stringify(value).slice(0, 40);
        uuid = value[uuidField];
    } else {
        return String(value);
    }

    return React.createElement('span', {
        className: 'inline-flex items-center gap-1 px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 text-xs font-medium',
        title: uuid || ''
    },
        React.createElement('span', { key: 'icon', 'aria-hidden': 'true' }, '↗'),
        React.createElement('span', { key: 'label' }, label)
    );
});

// ── tag_list_renderer ──
// Renders a list of strings as chip badges.
// Config:
//   max_visible: 6 (default)
//   variant: 'subtle' (default) | 'solid' | 'outline'
//   color: 'indigo' (default) — Tailwind color name
SuperoUIDispatcher.registerRenderer('tag_list', function(value, config, item) {
    if (value == null) return null;
    var tags;
    if (Array.isArray(value)) tags = value;
    else if (typeof value === 'string') tags = value.split(/[,;]\s*/).filter(function(t) { return t; });
    else return String(value);

    if (tags.length === 0) return null;

    var maxVisible = parseInt(config.max_visible, 10) || 6;
    var variant = config.variant || 'subtle';
    var color = config.color || 'indigo';

    // Static class lookup tables — Tailwind AOT purge requires literal class
    // tokens, not runtime concatenation. We support a fixed palette.
    var SUBTLE = {
        indigo: 'bg-indigo-50 text-indigo-700 ring-1 ring-inset ring-indigo-200',
        green:  'bg-green-50 text-green-700 ring-1 ring-inset ring-green-200',
        yellow: 'bg-yellow-50 text-yellow-700 ring-1 ring-inset ring-yellow-200',
        red:    'bg-red-50 text-red-700 ring-1 ring-inset ring-red-200',
        blue:   'bg-blue-50 text-blue-700 ring-1 ring-inset ring-blue-200',
        gray:   'bg-gray-100 text-gray-700 ring-1 ring-inset ring-gray-200',
        purple: 'bg-purple-50 text-purple-700 ring-1 ring-inset ring-purple-200',
        pink:   'bg-pink-50 text-pink-700 ring-1 ring-inset ring-pink-200',
    };
    var SOLID = {
        indigo: 'bg-indigo-600 text-white',
        green:  'bg-green-600 text-white',
        yellow: 'bg-yellow-600 text-white',
        red:    'bg-red-600 text-white',
        blue:   'bg-blue-600 text-white',
        gray:   'bg-gray-600 text-white',
        purple: 'bg-purple-600 text-white',
        pink:   'bg-pink-600 text-white',
    };
    var OUTLINE = {
        indigo: 'text-indigo-700 ring-1 ring-inset ring-indigo-300',
        green:  'text-green-700 ring-1 ring-inset ring-green-300',
        yellow: 'text-yellow-700 ring-1 ring-inset ring-yellow-300',
        red:    'text-red-700 ring-1 ring-inset ring-red-300',
        blue:   'text-blue-700 ring-1 ring-inset ring-blue-300',
        gray:   'text-gray-700 ring-1 ring-inset ring-gray-300',
        purple: 'text-purple-700 ring-1 ring-inset ring-purple-300',
        pink:   'text-pink-700 ring-1 ring-inset ring-pink-300',
    };
    var bucket = variant === 'solid' ? SOLID : variant === 'outline' ? OUTLINE : SUBTLE;
    var chipClass = bucket[color] || bucket.indigo;

    var visible = tags.slice(0, maxVisible);
    var overflow = tags.length - maxVisible;

    var children = visible.map(function(t, i) {
        return React.createElement('span', {
            key: 'tag' + i,
            className: 'inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ' + chipClass,
        }, String(t));
    });
    if (overflow > 0) {
        children.push(React.createElement('span', {
            key: 'overflow',
            className: 'inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-600',
        }, '+' + overflow));
    }
    return React.createElement('div', {
        className: 'inline-flex gap-1 flex-wrap'
    }, children);
});

// ── key_value_renderer ──
// Renders a dict/object as a definition list.
// Config:
//   max_keys: optional integer
//   compact: false (default) — true uses inline 'key: value' commas
SuperoUIDispatcher.registerRenderer('key_value', function(value, config, item) {
    if (value == null) return null;
    if (typeof value !== 'object' || Array.isArray(value)) return String(value);

    var keys = Object.keys(value);
    if (keys.length === 0) return null;

    var maxKeys = parseInt(config.max_keys, 10);
    if (maxKeys > 0 && keys.length > maxKeys) keys = keys.slice(0, maxKeys);

    if (config.compact === true) {
        return React.createElement('span', {
            className: 'text-sm text-gray-700'
        },
            keys.map(function(k, i) {
                var v = value[k];
                var vStr = (v == null) ? '—' : (typeof v === 'object' ? JSON.stringify(v) : String(v));
                return React.createElement('span', { key: 'kv' + i },
                    React.createElement('span', { className: 'text-gray-500' }, k + ': '),
                    React.createElement('span', { className: 'text-gray-900' }, vStr),
                    i < keys.length - 1 ? ', ' : ''
                );
            })
        );
    }

    return React.createElement('dl', {
        className: 'grid grid-cols-[max-content_1fr] gap-x-3 gap-y-1 text-sm'
    },
        keys.reduce(function(acc, k, i) {
            var v = value[k];
            var vStr = (v == null) ? '—' : (typeof v === 'object' ? JSON.stringify(v) : String(v));
            acc.push(React.createElement('dt', {
                key: 'k' + i,
                className: 'text-gray-500 font-medium'
            }, k));
            acc.push(React.createElement('dd', {
                key: 'v' + i,
                className: 'text-gray-900'
            }, vStr));
            return acc;
        }, [])
    );
});

// ── color_swatch_renderer ──
// Color circle/square with hex label.
// Config:
//   shape: 'circle' (default) | 'square'
//   size: 24 (default, px)
//   show_label: true (default)
// Value: hex string (#RRGGBB or rgb()) or object {hex, label}
SuperoUIDispatcher.registerRenderer('color_swatch', function(value, config, item) {
    if (value == null || value === '') return null;
    var hex, label;
    if (typeof value === 'string') {
        hex = value;
        label = value;
    } else if (typeof value === 'object') {
        hex = value.hex || value.color || '';
        label = value.label || hex;
    } else {
        return String(value);
    }
    if (!hex) return null;

    var shape = config.shape || 'circle';
    var size = parseInt(config.size, 10) || 24;
    var showLabel = config.show_label !== false;

    var swatchStyle = {
        width: size + 'px',
        height: size + 'px',
        backgroundColor: hex,
        borderRadius: shape === 'square' ? '4px' : '50%',
        border: '1px solid rgba(0,0,0,0.1)',
        display: 'inline-block',
        verticalAlign: 'middle',
    };

    return React.createElement('span', {
        className: 'inline-flex items-center gap-2'
    },
        React.createElement('span', { key: 's', style: swatchStyle, 'aria-hidden': 'true' }),
        showLabel && React.createElement('span', {
            key: 'l',
            className: 'text-xs text-gray-700 font-mono'
        }, label)
    );
});

// ── user_renderer ──
// Renders a user reference as avatar (initials) + name.
// Config:
//   show_email: false (default)
//   size: 'md' (default) | 'sm' | 'lg'
// Value: object {name, email, avatar_url} or string (treated as name)
SuperoUIDispatcher.registerRenderer('user', function(value, config, item) {
    if (value == null || value === '') return null;
    var name, email, avatarUrl;
    if (typeof value === 'string') {
        name = value;
    } else if (typeof value === 'object') {
        name = value.name || value.display_name || value.email || '';
        email = value.email;
        avatarUrl = value.avatar_url || value.avatar;
    } else {
        return String(value);
    }
    if (!name) return null;

    var size = config.size || 'md';
    var avatarPx = size === 'lg' ? 36 : size === 'sm' ? 20 : 28;

    // Initials from name
    var initials = name.split(/\s+/).slice(0, 2).map(function(s) {
        return s.charAt(0).toUpperCase();
    }).join('');
    if (!initials) initials = '?';

    var avatarEl;
    if (avatarUrl) {
        avatarEl = React.createElement('img', {
            src: avatarUrl,
            alt: '',
            className: 'rounded-full object-cover',
            style: { width: avatarPx + 'px', height: avatarPx + 'px' }
        });
    } else {
        // Hash name to color
        var hash = 0;
        for (var i = 0; i < name.length; i++) hash = (hash * 31 + name.charCodeAt(i)) & 0xffffffff;
        var hue = Math.abs(hash) % 360;
        avatarEl = React.createElement('span', {
            className: 'inline-flex items-center justify-center rounded-full text-white font-semibold',
            style: {
                width: avatarPx + 'px',
                height: avatarPx + 'px',
                fontSize: Math.round(avatarPx * 0.4) + 'px',
                backgroundColor: 'hsl(' + hue + ', 55%, 50%)',
            }
        }, initials);
    }

    var showEmail = config.show_email === true;

    return React.createElement('span', {
        className: 'inline-flex items-center gap-2'
    },
        avatarEl,
        React.createElement('span', { key: 'txt', className: 'inline-flex flex-col leading-tight' },
            React.createElement('span', { key: 'n', className: 'text-sm font-medium text-gray-900' }, name),
            showEmail && email && React.createElement('span', { key: 'e', className: 'text-xs text-gray-500' }, email)
        )
    );
});

// ── boolean_renderer ──
// True/false display as ✓/✗ or Yes/No or labels.
// Config:
//   style: 'check' (default) | 'yesno' | 'labels' | 'pill'
//   true_label: 'Yes' (used by 'labels' and 'pill')
//   false_label: 'No'
SuperoUIDispatcher.registerRenderer('boolean', function(value, config, item) {
    if (value == null) return null;
    // Coerce to boolean — accept true/false, "true"/"false", 1/0
    var truthy;
    if (typeof value === 'boolean') truthy = value;
    else if (typeof value === 'number') truthy = value !== 0;
    else if (typeof value === 'string') {
        var lowered = value.toLowerCase().trim();
        if (lowered === '') return null;   // empty string = no value, not false
        if (lowered === 'true' || lowered === '1' || lowered === 'yes') truthy = true;
        else if (lowered === 'false' || lowered === '0' || lowered === 'no') truthy = false;
        else return String(value);  // unknown string — show as-is
    } else {
        return String(value);
    }

    var style = config.style || 'check';
    var trueLabel = config.true_label || 'Yes';
    var falseLabel = config.false_label || 'No';

    if (style === 'check') {
        return React.createElement('span', {
            className: truthy ? 'text-green-600' : 'text-gray-300',
            'aria-label': truthy ? 'Yes' : 'No',
        }, truthy ? '✓' : '✗');
    }
    if (style === 'yesno') {
        return truthy ? 'Yes' : 'No';
    }
    if (style === 'labels') {
        return truthy ? trueLabel : falseLabel;
    }
    if (style === 'pill') {
        var cls = truthy
            ? 'bg-green-100 text-green-800 ring-green-200'
            : 'bg-gray-100 text-gray-600 ring-gray-200';
        return React.createElement('span', {
            className: 'inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ring-1 ring-inset ' + cls,
        }, truthy ? trueLabel : falseLabel);
    }
    return String(truthy);
});

// ── enum_renderer ──
// Display label for an enum value, with optional value→label mapping.
// Config:
//   value_labels: dict mapping raw value → display label (JSON string or object)
//   variant: 'plain' (default) | 'pill'
//   color: 'gray' (default for pill variant) — Tailwind color name
SuperoUIDispatcher.registerRenderer('enum', function(value, config, item) {
    if (value == null || value === '') return null;
    var rawValue = String(value);

    var labels = {};
    try {
        if (typeof config.value_labels === 'string') {
            labels = JSON.parse(config.value_labels);
        } else if (config.value_labels && typeof config.value_labels === 'object') {
            labels = config.value_labels;
        }
    } catch (e) {
        if (typeof console !== 'undefined') {
            console.warn('[SuperoUIDispatcher] enum: bad value_labels JSON, using raw values');
        }
    }

    var displayLabel = labels[rawValue] || rawValue.replace(/_/g, ' ');
    var variant = config.variant || 'plain';

    if (variant === 'pill') {
        // Static class lookup (Tailwind AOT-safe).
        var PILL_CLASSES = {
            indigo: 'bg-indigo-100 text-indigo-800',
            green:  'bg-green-100 text-green-800',
            yellow: 'bg-yellow-100 text-yellow-800',
            red:    'bg-red-100 text-red-800',
            blue:   'bg-blue-100 text-blue-800',
            gray:   'bg-gray-100 text-gray-800',
            purple: 'bg-purple-100 text-purple-800',
            pink:   'bg-pink-100 text-pink-800',
        };
        var color = config.color || 'gray';
        var pillClass = PILL_CLASSES[color] || PILL_CLASSES.gray;
        return React.createElement('span', {
            className: 'inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ' + pillClass,
        }, displayLabel);
    }
    return displayLabel;
});

// ── step_progress_renderer ──
// Multi-step progress indicator (e.g. for onboarding flows or order
// fulfillment). Renders dots/lines with current step highlighted.
// Config:
//   steps: array of {key, label} OR plain string list (JSON string or array)
//   show_labels: true (default)
//   compact: false (default)
// Value: string (current step key) OR integer (current step index)
SuperoUIDispatcher.registerRenderer('step_progress', function(value, config, item) {
    if (value == null || value === '') return null;

    var steps;
    try {
        if (typeof config.steps === 'string') steps = JSON.parse(config.steps);
        else if (Array.isArray(config.steps)) steps = config.steps;
        else steps = [];
    } catch (e) {
        steps = [];
    }
    if (!Array.isArray(steps) || steps.length === 0) return String(value);

    // Normalize step entries to {key, label}
    var normSteps = steps.map(function(s) {
        if (typeof s === 'string') return { key: s, label: s.replace(/_/g, ' ') };
        if (s && typeof s === 'object') return { key: s.key || String(s.label || ''), label: s.label || s.key || '' };
        return { key: String(s), label: String(s) };
    });

    // Determine current step index
    var currentIdx = -1;
    if (typeof value === 'number') {
        currentIdx = value;
    } else {
        var valStr = String(value);
        for (var i = 0; i < normSteps.length; i++) {
            if (normSteps[i].key === valStr) { currentIdx = i; break; }
        }
    }

    var showLabels = config.show_labels !== false;
    var compact = config.compact === true;

    var children = [];
    for (var i = 0; i < normSteps.length; i++) {
        var isPast = i < currentIdx;
        var isCurrent = i === currentIdx;
        var dotClass = isPast
            ? 'bg-green-500 border-green-500'
            : isCurrent
                ? 'bg-indigo-500 border-indigo-500'
                : 'bg-gray-100 border-gray-300';
        var dotSize = compact ? 8 : 12;

        children.push(React.createElement('div', {
            key: 'step' + i,
            className: 'flex flex-col items-center'
        },
            React.createElement('span', {
                key: 'dot',
                className: 'rounded-full border-2 ' + dotClass,
                style: { width: dotSize + 'px', height: dotSize + 'px' }
            }),
            showLabels && React.createElement('span', {
                key: 'lbl',
                className: 'mt-1 text-xs ' + (isCurrent ? 'font-medium text-indigo-700' : 'text-gray-500'),
                style: { whiteSpace: 'nowrap' }
            }, normSteps[i].label)
        ));

        if (i < normSteps.length - 1) {
            children.push(React.createElement('div', {
                key: 'conn' + i,
                className: 'flex-1 h-0.5 ' + (i < currentIdx ? 'bg-green-500' : 'bg-gray-200'),
                style: { marginTop: (dotSize / 2 - 1) + 'px' }
            }));
        }
    }

    return React.createElement('div', {
        className: 'flex items-start gap-2'
    }, children);
});

// ── geo_point_renderer ──
// Latitude/longitude display with optional map link.
// Config:
//   show_map_link: true (default)
//   precision: 4 (default decimal places)
//   map_provider: 'google' (default) | 'apple' | 'osm'
// Value: object {lat, lng} OR {latitude, longitude} OR "lat,lng" string
SuperoUIDispatcher.registerRenderer('geo_point', function(value, config, item) {
    if (value == null || value === '') return null;
    var lat, lng;
    if (typeof value === 'string') {
        var parts = value.split(',').map(function(s) { return parseFloat(s.trim()); });
        lat = parts[0]; lng = parts[1];
    } else if (typeof value === 'object') {
        lat = parseFloat(value.lat != null ? value.lat : value.latitude);
        lng = parseFloat(value.lng != null ? value.lng : value.longitude);
    } else {
        return String(value);
    }
    if (isNaN(lat) || isNaN(lng)) return String(value);

    var precision = parseInt(config.precision, 10);
    if (isNaN(precision)) precision = 4;
    var latStr = lat.toFixed(precision);
    var lngStr = lng.toFixed(precision);
    var text = latStr + ', ' + lngStr;

    var showMapLink = config.show_map_link !== false;
    if (!showMapLink) return React.createElement('span', { className: 'font-mono text-xs' }, text);

    var provider = config.map_provider || 'google';
    var mapUrl;
    if (provider === 'apple') {
        mapUrl = 'https://maps.apple.com/?ll=' + lat + ',' + lng;
    } else if (provider === 'osm') {
        mapUrl = 'https://www.openstreetmap.org/?mlat=' + lat + '&mlon=' + lng + '#map=15/' + lat + '/' + lng;
    } else {
        mapUrl = 'https://www.google.com/maps?q=' + lat + ',' + lng;
    }

    return React.createElement('span', {
        className: 'inline-flex items-center gap-2'
    },
        React.createElement('span', { key: 't', className: 'font-mono text-xs text-gray-700' }, text),
        React.createElement('a', {
            key: 'a',
            href: mapUrl,
            target: '_blank',
            rel: 'noopener noreferrer',
            className: 'text-xs text-indigo-600 hover:text-indigo-800 hover:underline',
            title: 'View on map'
        }, '📍')
    );
});

// ── map_renderer ──
// Embedded map. Without a real map SDK, falls back to an iframe of
// OSM or a Google Maps link. For real interactive maps, tenants
// should override with a custom renderer using Leaflet/Mapbox.
// Config:
//   provider: 'osm' (default) | 'google_link' | 'apple_link'
//   height: 240 (default px)
//   zoom: 13 (default for osm)
// Value: same shapes as geo_point_renderer
SuperoUIDispatcher.registerRenderer('map', function(value, config, item) {
    if (value == null || value === '') return null;
    var lat, lng;
    if (typeof value === 'string') {
        var parts = value.split(',').map(function(s) { return parseFloat(s.trim()); });
        lat = parts[0]; lng = parts[1];
    } else if (typeof value === 'object') {
        lat = parseFloat(value.lat != null ? value.lat : value.latitude);
        lng = parseFloat(value.lng != null ? value.lng : value.longitude);
    } else {
        return String(value);
    }
    if (isNaN(lat) || isNaN(lng)) return String(value);

    var provider = config.provider || 'osm';
    var height = parseInt(config.height, 10) || 240;
    var zoom = parseInt(config.zoom, 10) || 13;

    if (provider === 'osm') {
        var bbox = (lng - 0.01) + ',' + (lat - 0.01) + ',' + (lng + 0.01) + ',' + (lat + 0.01);
        var src = 'https://www.openstreetmap.org/export/embed.html?bbox=' + bbox + '&layer=mapnik&marker=' + lat + ',' + lng;
        return React.createElement('iframe', {
            src: src,
            title: 'Map',
            className: 'w-full rounded border border-gray-200',
            style: { height: height + 'px', border: 'none' },
            loading: 'lazy'
        });
    }
    // Link-only fallbacks
    var linkUrl = provider === 'apple'
        ? 'https://maps.apple.com/?ll=' + lat + ',' + lng
        : 'https://www.google.com/maps?q=' + lat + ',' + lng;
    return React.createElement('a', {
        href: linkUrl,
        target: '_blank',
        rel: 'noopener noreferrer',
        className: 'inline-flex items-center gap-2 px-3 py-2 rounded border border-gray-200 hover:bg-gray-50 text-sm text-indigo-600 hover:underline'
    }, '📍 View location on map');
});


// Expose globally
if (typeof window !== 'undefined') {
    window.SuperoUIDispatcher = SuperoUIDispatcher;

    if (typeof console !== 'undefined' && console.info) {
        console.info('[SuperoUIDispatcher] loaded with renderers: '
                     + SuperoUIDispatcher.listRenderers().join(', '));
    }
}
