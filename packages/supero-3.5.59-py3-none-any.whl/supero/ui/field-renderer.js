// ═══════════════════════════════════════════════════════════════════════
// field-renderer.js — canonical field-rendering layer for Supero apps
// VERSION = '1.0.0'
//
// Loaded by index.html AFTER dispatcher.js, BEFORE supero-ui.js.
//   <script src="dispatcher.js"></script>
//   <script src="field-renderer.js"></script>
//   <script src="supero-ui.js"></script>
//
// SuperoFieldRenderer.renderField(attr, value, item, context)
//
// Purpose:
//   Replaces ad-hoc field-rendering scattered throughout supero-ui.js with
//   one canonical function. Knows about UI schemas, knows about dispatcher
//   renderers, knows about legacy formatters — picks the right rendering
//   for the (field, value, context) triple.
//
// Resolution order:
//   1. UI schema override (tenant declared a specific renderer for this field)
//   2. Field-name heuristic (email/phone/url/rating/status patterns)
//   3. Type-based default (Image/File → file renderers; date → formatDate; etc.)
//   4. Fallback (text span / String(v))
//
// Return types per context.mode:
//   - 'detail', 'card_field', 'cell'       → React element (or null)
//   - 'subtitle', 'hero_inline', 'tooltip_value' → string (joinable, '—' if null)
//
// Why two return shapes?
//   Three callsites in supero-ui.js use .join(' · ') on rendered values.
//   That idiom requires strings. We honour it by returning compact strings
//   for those modes. For modes where elements work (detail card, kanban
//   tile, table cell), we return rich React elements with mailto:/tel:/
//   color pills/etc.
//
// Dependencies (read at call-time, not load-time, so order doesn't matter):
//   window.React              — REQUIRED, will throw if absent
//   window.SuperoUIDispatcher — REQUIRED, used for rich rendering
//   window.formatCurrency     — OPTIONAL, used in string modes for currency
//   window.formatNumber       — OPTIONAL, used in string modes for numbers
//   window.formatDate         — OPTIONAL, used in string modes for dates
//   window.SuperoUISchemaResolver — OPTIONAL, used for UI schema lookups
// ═══════════════════════════════════════════════════════════════════════
(function() {
    'use strict';

    var VERSION = '1.0.0';

    // Modes that return React elements (rich rendering)
    var ELEMENT_MODES = { detail: 1, card_field: 1, cell: 1 };
    // Modes that return plain strings (string-joinable; subtitle text)
    var STRING_MODES  = { subtitle: 1, hero_inline: 1, tooltip_value: 1 };

    // ── Status color mapping ──────────────────────────────────────────
    // Carried forward from supero-ui.js getStatusColor (line 2563+). The
    // dispatcher's lifecycle_state renderer takes a `colors` config that
    // maps state strings to category names ('positive', 'warning', etc.).
    // We pass this map every time we route a status field to lifecycle_state,
    // ensuring colors stay consistent with what cards and kanban tiles
    // displayed before Patch 4.
    //
    // Categories:
    //   positive (emerald/green) — successful end states or active states
    //   warning  (amber/yellow)  — in-progress, awaiting action
    //   negative (red)           — failed, rejected, terminated
    //   neutral  (gray)          — inactive, archived, draft, applied
    //   info     (blue)          — scheduled, screening, evaluating
    //   highlight (purple)       — interview, exceptional (special attention)
    //   info_alt (indigo)        — offer (between info and highlight)
    //
    // Status names not in this map fall through to dispatcher's category
    // heuristics (which handle compounds like 'active_paid' → positive).
    var SUPERO_STATUS_COLORS = {
        // positive
        active: 'positive', approved: 'positive', hired: 'positive',
        paid: 'positive', open: 'positive', passed: 'positive',
        completed: 'positive', meets_expectations: 'positive',
        // warning
        on_leave: 'warning', pending: 'warning', processing: 'warning',
        probation: 'warning', needs_improvement: 'warning',
        // info (blue)
        scheduled: 'info', screening: 'info',
        exceeds_expectations: 'info',
        // highlight (purple) — for emphasis
        interview: 'highlight', exceptional: 'highlight',
        // info_alt (indigo) — distinct from info
        offer: 'info_alt',
        // neutral (gray)
        applied: 'neutral', draft: 'neutral', inactive: 'neutral',
        cancelled: 'neutral',
        // negative (red)
        terminated: 'negative', rejected: 'negative', failed: 'negative',
        unsatisfactory: 'negative',
    };

    // ── Field-name pattern heuristics ─────────────────────────────────
    // Each pattern → dispatcher renderer name. Patterns target the most
    // common field names; tenants can override per-field via UI schema.
    //
    // The regex check is on `attr.name` (not display label). Field names
    // are snake_case in our convention.
    // Patterns are narrow on purpose. False positives (e.g. matching
    // 'state' on an address.state field, or 'link' on next_link UUIDs)
    // produce visibly wrong rendering — better to miss than misclassify.
    // Tenants can opt in to broader patterns via per-field UI schema.
    var NAME_PATTERNS = [
        // [regex, renderer_name, applies_only_to_types_array_or_null]
        [/(^|_)(email|email_address|contact_email)(_|$)/i,        'email',           ['string', null, undefined]],
        [/(^|_)(phone|phone_number|telephone|mobile_number|mobile_phone)(_|$)/i, 'phone', ['string', null, undefined]],
        // URL pattern: must match a clear URL-ish suffix (website, url,
        // homepage). 'link' / 'site' alone are too ambiguous.
        [/(^|_)(website|url|homepage|website_url|link_url)(_|$)/i, 'url',             ['string', null, undefined]],
        [/(^|_)rating(_|$)/i,                                      'rating',          ['float', 'integer', 'number', null, undefined]],
        // Status: 'state' is omitted because address.state collides.
        // Tenants whose state field is a lifecycle should rename it
        // (e.g. 'workflow_state') or use a UI schema override.
        [/(^|_)status(_|$)/i,                                      'lifecycle_state', ['string', null, undefined]],
    ];

    // ── Type-based defaults ───────────────────────────────────────────
    // attr.type → dispatcher renderer name (when applicable).
    // 'Image'/'File' come from the Supero schema type vocabulary.
    var TYPE_RENDERERS = {
        Image:    'image',
        File:     'attached_file',
    };

    // ── Currency name patterns (matches formatFieldValue's original logic) ─
    // Numeric fields whose names contain these substrings render as currency.
    var CURRENCY_NAME_HINTS = [
        'amount', 'budget', 'price', 'cost', 'total', 'revenue',
        'rent', 'rate', 'spent', 'fee', 'salary', 'spend'
    ];

    function _isNumericType(type) {
        return type === 'float' || type === 'integer' || type === 'number';
    }

    function _isCurrencyField(attr) {
        if (!attr || !attr.name) return false;
        if (!_isNumericType(attr.type)) return false;
        var name = String(attr.name).toLowerCase();
        for (var i = 0; i < CURRENCY_NAME_HINTS.length; i++) {
            if (name.indexOf(CURRENCY_NAME_HINTS[i]) >= 0) return true;
        }
        return false;
    }

    function _isDateType(type) {
        return type === 'date' || type === 'datetime';
    }

    // ── UI schema lookup (future hook) ────────────────────────────────
    // FUTURE: tenants will be able to declare per-field renderers in a UI
    // schema. The expected resolver API:
    //
    //   window.SuperoUISchemaResolver.resolveFieldRenderer(uiSchemaName, fieldName)
    //     → { renderer: <name>, config: <object> } | null
    //
    // The resolver does not implement this method yet. This code is
    // safe-by-design: if the method is absent or throws, we silently fall
    // through to field-name heuristics. This means Patch 4a ships with
    // heuristics-only behavior. A future patch will add resolveFieldRenderer
    // to SuperoUISchemaResolver, at which point per-field overrides become
    // available with zero change to this file.
    //
    // Returns: { renderer: <name>, config: <object> } or null.
    function _resolveUiSchemaOverride(attr, context) {
        if (!context || !context.uiSchemaName) return null;
        if (!attr || !attr.name) return null;
        var resolver = (typeof window !== 'undefined') && window.SuperoUISchemaResolver;
        if (!resolver || typeof resolver.resolveFieldRenderer !== 'function') return null;
        try {
            var result = resolver.resolveFieldRenderer(context.uiSchemaName, attr.name);
            if (result && result.renderer) return result;
        } catch (e) {
            // Resolver method absent or threw — heuristics handle it.
        }
        return null;
    }

    // ── Pick a dispatcher renderer based on heuristics ────────────────
    // Returns { renderer: <name>, config: {} } or null.
    function _pickRenderer(attr) {
        if (!attr || typeof attr !== 'object') return null;

        // 1. Field-name patterns (with type compatibility check)
        var name = attr.name || '';
        for (var i = 0; i < NAME_PATTERNS.length; i++) {
            var entry = NAME_PATTERNS[i];
            var pattern = entry[0], rendererName = entry[1], allowedTypes = entry[2];
            if (!pattern.test(name)) continue;
            if (allowedTypes && allowedTypes.indexOf(attr.type) < 0) continue;
            // Special: lifecycle_state needs the Supero status color map
            // (preserves visual parity with legacy getStatusColor).
            if (rendererName === 'lifecycle_state') {
                return { renderer: rendererName, config: { state_colors: SUPERO_STATUS_COLORS } };
            }
            return { renderer: rendererName, config: {} };
        }

        // 2. Currency name pattern (numeric type + currency-ish name)
        if (_isCurrencyField(attr)) {
            return { renderer: 'currency', config: {} };
        }

        // 3. Type-based defaults (Image/File/etc.)
        if (TYPE_RENDERERS[attr.type]) {
            return { renderer: TYPE_RENDERERS[attr.type], config: {} };
        }

        // 4. No match — caller falls back to legacy formatting
        return null;
    }

    // ── String-mode rendering (subtitle, hero_inline, tooltip_value) ──
    // Returns a string suitable for .join(' · '). Mirrors the legacy
    // formatFieldValue behavior exactly (preserves visual parity for
    // subtitle contexts).
    //
    // Note: legacy formatFieldValue returns '—' for null. We follow that.
    function _renderString(attr, value, item, context) {
        if (value == null) return '—';

        // Currency name → formatCurrency
        if (_isCurrencyField(attr)) {
            if (typeof window !== 'undefined' && typeof window.formatCurrency === 'function') {
                return window.formatCurrency(value);
            }
            return '$' + Number(value).toFixed(2);
        }

        // Numeric type → formatNumber
        if (_isNumericType(attr && attr.type)) {
            if (typeof window !== 'undefined' && typeof window.formatNumber === 'function') {
                return window.formatNumber(value);
            }
            return String(value);
        }

        // Date type → formatDate
        if (_isDateType(attr && attr.type)) {
            if (typeof window !== 'undefined' && typeof window.formatDate === 'function') {
                return window.formatDate(value);
            }
            return String(value);
        }

        // Boolean → Yes/No (legacy behavior)
        if (typeof value === 'boolean') return value ? 'Yes' : 'No';

        // String with underscores → spaced (legacy: enum-ish display)
        if (typeof value === 'string' && value.indexOf('_') >= 0) {
            return value.replace(/_/g, ' ');
        }

        return String(value);
    }

    // ── Element-mode rendering ────────────────────────────────────────
    // Returns React element (or null). Used by detail view, card field
    // grids, table cells.
    function _renderElement(attr, value, item, context) {
        if (typeof window === 'undefined' || !window.React) {
            throw new Error('[SuperoFieldRenderer] React not loaded');
        }
        var R = window.React;
        var Dispatcher = window.SuperoUIDispatcher;

        // Null/empty → render the em-dash so detail cards don't collapse
        if (value == null) {
            return R.createElement('span', {
                className: 'text-gray-400'
            }, '—');
        }

        // ── 1. UI schema override (tenant-declared per-field renderer) ──
        var override = _resolveUiSchemaOverride(attr, context);
        if (override && Dispatcher) {
            var orRenderer = Dispatcher.getRenderer(override.renderer);
            if (orRenderer) {
                try {
                    var orResult = orRenderer(value, override.config || {}, item);
                    if (orResult != null) return _wrap(orResult);
                } catch (e) {
                    if (typeof console !== 'undefined') {
                        console.warn('[SuperoFieldRenderer] override renderer ' +
                                     override.renderer + ' threw:', e);
                    }
                    // Fall through to heuristics
                }
            }
        }

        // ── 2 & 3. Field-name heuristic + type-based ──
        var picked = _pickRenderer(attr);
        if (picked && Dispatcher) {
            var renderer = Dispatcher.getRenderer(picked.renderer);
            if (renderer) {
                try {
                    var result = renderer(value, picked.config, item);
                    if (result != null) return _wrap(result);
                } catch (e) {
                    if (typeof console !== 'undefined') {
                        console.warn('[SuperoFieldRenderer] renderer ' +
                                     picked.renderer + ' threw for ' +
                                     (attr && attr.name) + ':', e);
                    }
                    // Fall through to legacy formatting
                }
            }
        }

        // ── 4. Fallback: legacy string formatting wrapped in <span> ──
        // Boolean gets a ✓/✗ in element mode (richer than Yes/No)
        if (typeof value === 'boolean') {
            return R.createElement('span', {
                className: value ? 'text-green-600' : 'text-gray-400',
                'aria-label': value ? 'Yes' : 'No'
            }, value ? '✓' : '✗');
        }

        // Date type
        if (_isDateType(attr && attr.type)) {
            var dateText = (typeof window.formatDate === 'function')
                ? window.formatDate(value)
                : String(value);
            return R.createElement('span', null, dateText);
        }

        // Numeric (non-currency)
        if (_isNumericType(attr && attr.type)) {
            var numText = (typeof window.formatNumber === 'function')
                ? window.formatNumber(value)
                : String(value);
            return R.createElement('span', { className: 'tabular-nums' }, numText);
        }

        // String with underscores → spaced
        if (typeof value === 'string' && value.indexOf('_') >= 0) {
            return R.createElement('span', null, value.replace(/_/g, ' '));
        }

        // Pure string fallback
        return R.createElement('span', null, String(value));
    }

    // _wrap: ensure return value is a React element. Strings get wrapped
    // in a <span>. React elements pass through unchanged. Used after
    // dispatcher renderer calls (some return strings, some return elements).
    function _wrap(value) {
        if (typeof window === 'undefined' || !window.React) return value;
        // Object with $$typeof is a React element
        if (typeof value === 'object' && value !== null && value.$$typeof) return value;
        // Array of React children
        if (Array.isArray(value)) return window.React.createElement('span', null, value);
        // String / number — wrap
        return window.React.createElement('span', null, String(value));
    }

    // ── Public API ────────────────────────────────────────────────────
    // renderField(attr, value, item, context)
    //
    //   attr    : { name, type, ... } — schema attribute object.
    //             Can also be a plain string for cell_keyed contexts,
    //             but those should use legacy formatFieldValue instead.
    //   value   : the raw field value from item[attr.name]
    //   item    : the full record (for cross-field renderers; usually unused)
    //   context : { mode: <string>, uiSchemaName?: <string>, dense?: bool }
    //             mode is REQUIRED. Defaults to 'card_field' if absent
    //             (the most-permissive element mode).
    //
    // Returns:
    //   - For element modes (detail/card_field/cell): React element or null
    //   - For string modes (subtitle/hero_inline/tooltip_value): string
    function renderField(attr, value, item, context) {
        context = context || {};
        var mode = context.mode || 'card_field';

        // Defensive: if attr is a string (legacy cell_keyed callsites),
        // construct a minimal attr object so heuristics don't blow up.
        if (typeof attr === 'string') {
            attr = { name: attr, type: undefined };
        }
        if (attr == null) attr = { name: '', type: undefined };

        if (STRING_MODES[mode]) {
            return _renderString(attr, value, item, context);
        }
        if (ELEMENT_MODES[mode]) {
            return _renderElement(attr, value, item, context);
        }
        // Unknown mode — log warning, treat as element mode
        if (typeof console !== 'undefined') {
            console.warn('[SuperoFieldRenderer] unknown mode: ' + mode +
                         '. Treating as card_field.');
        }
        return _renderElement(attr, value, item, context);
    }

    // ── Diagnostics ───────────────────────────────────────────────────
    function listPatterns() {
        return NAME_PATTERNS.map(function(p) {
            return { pattern: String(p[0]), renderer: p[1], types: p[2] };
        });
    }

    function listTypeMappings() {
        var out = {};
        Object.keys(TYPE_RENDERERS).forEach(function(t) { out[t] = TYPE_RENDERERS[t]; });
        return out;
    }

    // ── Expose ────────────────────────────────────────────────────────
    var api = {
        VERSION: VERSION,
        renderField: renderField,
        listPatterns: listPatterns,
        listTypeMappings: listTypeMappings,
        // Internal helpers exposed for tests
        _renderString: _renderString,
        _renderElement: _renderElement,
        _pickRenderer: _pickRenderer,
    };

    if (typeof window !== 'undefined') {
        window.SuperoFieldRenderer = api;
        if (typeof console !== 'undefined' && console.info) {
            console.info('[SuperoFieldRenderer] loaded VERSION ' + VERSION);
        }
    }
    if (typeof module !== 'undefined' && module.exports) {
        module.exports = api;
    }
})();
