"""
progress.py — Smart progress reporting for Supero app setup.

Two modes:
  - Interactive (TTY): Single-line progress bar that updates in place
  - Non-interactive (pipe/CI): Step-by-step log lines (no \r tricks)
  - Verbose (--verbose): Full detail like before

The progress bar shows:
  🚀 Setting up ram-corp  [████████░░░░░░░░] 48%  Uploading schemas...

On error, it breaks out of the bar and shows the full error detail.
On completion, it shows a clean summary.

All detailed output goes to .supero-run.log regardless of mode.

Usage in app_setup.py:
    from supero.progress import Progress
    
    p = Progress(domain="ram-corp", total_steps=12, verbose=False)
    p.step(1, "Registering domain")
    p.ok("Domain ready")
    p.step(5, "Uploading schemas")
    p.ok("12 uploaded, 3 skipped")
    p.complete()  # shows final summary
"""

import sys
import os
import logging
from typing import Optional

logger = logging.getLogger("supero.setup")


# ── Progress bar rendering ─────────────────────────────────

def _bar(pct: float, width: int = 20) -> str:
    """Render a progress bar: [████████░░░░░░░░]"""
    filled = int(width * pct / 100)
    empty = width - filled
    return f"[{'█' * filled}{'░' * empty}]"


def _is_tty() -> bool:
    """Check if stdout is a terminal (not piped)."""
    try:
        return sys.stdout.isatty()
    except Exception:
        return False


# ── Step definitions with weights ──────────────────────────

STEPS = {
    1: {"label": "Registering domain",     "weight": 5},
    2: {"label": "Logging in",             "weight": 5},
    3: {"label": "Retrieving API key",     "weight": 3},
    4: {"label": "Creating project",       "weight": 5},
    5: {"label": "Uploading schemas",      "weight": 15},
    6: {"label": "Building SDK",           "weight": 25},
    7: {"label": "Creating tenants",       "weight": 5},
    8: {"label": "Creating users",         "weight": 5},
    9: {"label": "Importing services",     "weight": 10},
    10: {"label": "Setting up policies",   "weight": 7},
    11: {"label": "Creating workflows",    "weight": 7},
    12: {"label": "Seeding data",          "weight": 8},
}

TOTAL_WEIGHT = sum(s["weight"] for s in STEPS.values())


class Progress:
    """
    Smart progress reporter with inline progress bar.
    
    Interactive mode: single-line bar that updates in place.
    Non-interactive: simple log lines.
    Verbose: full detail (legacy behavior).
    """

    def __init__(
        self,
        total_steps: int = 12,
        domain: str = "",
        verbose: bool = False,
    ):
        self.total = total_steps
        self.domain = domain
        self.verbose = verbose
        self.interactive = _is_tty() and not verbose
        self.current_step = 0
        self.current_label = ""
        self._completed_weight = 0
        self._errors: list = []
        self._warnings: list = []
        self._bar_active = False

        # Log file — always write detail here
        self._log_file = os.path.join(os.getcwd(), ".supero-run.log")

    # ── Public API ────────────────────────────────────────

    def step(self, num: int, msg: str = ""):
        """Start a new step. Updates the progress bar or prints a line."""
        self.current_step = num
        label = msg or STEPS.get(num, {}).get("label", f"Step {num}")
        self.current_label = label

        # Accumulate weight from completed steps
        self._completed_weight = sum(
            STEPS.get(s, {}).get("weight", 0)
            for s in range(1, num)
        )

        self._log(f"[{num}/{self.total}] {label}")

        if self.interactive:
            self._render_bar()
        elif self.verbose:
            print(f"  [{num:>2}/{self.total}] {label}")
            sys.stdout.flush()
        # Non-interactive non-verbose: silent (only errors/ok shown)

    def ok(self, msg: str):
        """Report success for current step."""
        self._log(f"  ✅ {msg}")

        if self.interactive:
            # Don't break the bar — just update the label briefly
            self._render_bar(detail=msg)
        elif self.verbose:
            print(f"         ✅ {msg}")
            sys.stdout.flush()

    def warn(self, msg: str):
        """Report warning for current step."""
        self._warnings.append(msg)
        self._log(f"  ⚠️  {msg}")

        if self.interactive:
            self._break_bar()
            print(f"  ⚠️  {msg}")
            self._render_bar()
        else:
            print(f"         ⚠️  {msg}")
            sys.stdout.flush()

    def note(self, msg: str):
        """Report a supplementary note (always visible, non-critical)."""
        self._log(f"  📝 {msg}")
        if self.interactive:
            self._break_bar()
            print(f"         {msg}")
            self._render_bar()
        else:
            print(f"         {msg}")
            sys.stdout.flush()

    def info(self, msg: str):
        """Report info (non-critical)."""
        self._log(f"  ℹ️  {msg}")
        if self.verbose:
            print(f"         ℹ️  {msg}")
            sys.stdout.flush()

    def fail(self, msg: str):
        """Report error for current step."""
        self._errors.append(msg)
        self._log(f"  ❌ {msg}")

        if self.interactive:
            self._break_bar()
            print(f"  ❌ {msg}")
            self._render_bar()
        else:
            print(f"         ❌ {msg}")
            sys.stdout.flush()

    def complete(self):
        """Finish progress — show summary."""
        if self.interactive:
            self._break_bar()

        if self._errors:
            print(f"\n  ⚠️  Completed with {len(self._errors)} error(s)")
            for e in self._errors[:5]:
                print(f"     ❌ {e}")
            if len(self._errors) > 5:
                print(f"     ... and {len(self._errors) - 5} more (see .supero-run.log)")
        # Summary line is printed by AppSetup._print_summary()

    # ── Progress bar rendering ────────────────────────────

    def _render_bar(self, detail: str = ""):
        """Render the inline progress bar (overwrites current line)."""
        if not self.interactive:
            return

        pct = self._pct()
        label = detail or self.current_label
        # Truncate label to fit terminal
        try:
            cols = os.get_terminal_size().columns
        except Exception:
            cols = 80
        max_label = cols - 45  # space for emoji + bar + pct
        if len(label) > max_label:
            label = label[:max_label - 1] + "…"

        bar = _bar(pct)
        emoji = "🚀" if not self._errors else "⚠️ "
        domain = f" {self.domain}" if self.domain else ""

        line = f"  {emoji}{domain}  {bar} {pct:3.0f}%  {label}"

        # Pad to terminal width to clear previous longer lines
        line = line.ljust(cols - 1)

        sys.stdout.write(f"\r{line}")
        sys.stdout.flush()
        self._bar_active = True

    def _break_bar(self):
        """Move to next line (break out of the \r progress bar)."""
        if self._bar_active:
            sys.stdout.write("\n")
            sys.stdout.flush()
            self._bar_active = False

    def _pct(self) -> float:
        """Calculate current progress percentage from step weights."""
        if self.current_step <= 0:
            return 0.0
        # Current step contributes half its weight (in progress)
        current_weight = STEPS.get(self.current_step, {}).get("weight", 0)
        total = self._completed_weight + (current_weight * 0.5)
        return min(99.0, (total / TOTAL_WEIGHT) * 100)

    # ── Logging ───────────────────────────────────────────

    def _log(self, msg: str):
        """Write to log file (always, regardless of mode)."""
        logger.info(msg)
        try:
            with open(self._log_file, "a") as f:
                from datetime import datetime
                f.write(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}\n")
        except Exception:
            pass
