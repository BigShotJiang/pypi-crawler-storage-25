"""
supero.cli.env_manager — .env file management + config.js generation.

Reads, writes, and manages .env values for Supero apps.
Also generates the runtime config.js that the web UI reads.
No external dependencies.

Quoting rules (important):
  - All values are written QUOTED in double quotes, always.
    This makes .env files safe to `source` in bash, safe for Docker
    --env-file, and removes any ambiguity with special chars like
    `=`, `#`, spaces, or `$`.
  - On read, outer single- or double-quotes are stripped exactly once.
    Backslash escapes inside quotes (\\" and \\\\) are unescaped.

Project name rule (important):
  - SUPERO_PROJECT has NO default. If not set, generate_config_js()
    raises, setup fails loudly, and the caller must fix the config.
  - "default-project" used to be a silent fallback that routed apps
    to a zombie namespace. Never again.
"""

import os
import re


# Keys that, if present, form a complete Supero app configuration.
# Used by is_configured() and validation in save().
_REQUIRED_API_KEY_MODE = ("SUPERO_DOMAIN", "SUPERO_PROJECT", "SUPERO_API_KEY")
_REQUIRED_PASSWORD_MODE = ("SUPERO_DOMAIN", "SUPERO_PROJECT", "SUPERO_ADMIN_EMAIL", "SUPERO_PASSWORD")

# Well-known Supero-related keys (used for clear() and env-override logic)
_SUPERO_KEYS = (
    "SUPERO_URL", "SUPERO_DOMAIN", "SUPERO_ADMIN_EMAIL",
    "SUPERO_PASSWORD", "SUPERO_API_KEY", "SUPERO_PROJECT",
    "SUPERO_DEFAULT_TENANT",
    "PLATFORM_CORE_HOST", "PLATFORM_CORE_PORT",
    "PUBLIC_SCHEMAS",
    "APP_NAME", "APP_EMOJI", "APP_DESCRIPTION",
    "PORT", "UI_PORT",
    "SUPERO_PREVIEW",  # set by Cloud Run preview containers
)


def _shell_quote(value: str) -> str:
    """
    Quote a value for safe .env storage.

    Always uses double quotes so shell `source`, Docker --env-file,
    and most parsers all agree. Escapes embedded backslashes and
    double quotes.
    """
    if value is None:
        return '""'
    s = str(value)
    # Escape backslashes FIRST, then double quotes
    s = s.replace("\\", "\\\\").replace('"', '\\"')
    return f'"{s}"'


def _shell_unquote(value: str) -> str:
    """
    Reverse of _shell_quote. Strips one layer of matching outer
    single- or double-quotes and unescapes backslash escapes inside
    double-quoted values.

    - '"foo"'      → 'foo'
    - "'foo'"      → 'foo'
    - '"he said \\"hi\\""' → 'he said "hi"'
    - 'foo'        → 'foo'  (no quotes, returned as-is)
    - '"mismatched\\''  → '"mismatched\\''  (no matching quotes, returned as-is)
    """
    if value is None or len(value) < 2:
        return value

    first, last = value[0], value[-1]
    if first == last and first in ('"', "'"):
        inner = value[1:-1]
        if first == '"':
            # Unescape \\ and \"
            inner = inner.replace('\\"', '"').replace("\\\\", "\\")
        return inner
    return value


class EnvManager:
    """
    Manages .env configuration for Supero apps.

    Reads/writes .env files with proper quoting, merges environment
    variables (for containerized deploys), and generates the config.js
    file that the web UI reads at runtime.
    """

    def __init__(self, env_path: str = ".env"):
        self.path = env_path
        self.values: dict = {}
        self._load()

    # ─────────────────────────────────────────────────────────────
    # Loading
    # ─────────────────────────────────────────────────────────────

    def _load(self):
        """
        Load values from .env file if it exists, then layer OS environment
        on top (environment always wins, to support Docker/Cloud Run deploys
        that inject config via env vars without touching .env).

        Unlike the previous implementation, this version:
          - Strips quotes properly (matching pairs only)
          - Unescapes \\\" and \\\\ inside double-quoted values
          - Warns on malformed lines instead of silently dropping them
          - Picks up well-known Supero env vars even if .env is missing
            or doesn't contain them (critical for preview containers)
        """
        # 1. Read .env file if present
        if os.path.exists(self.path):
            with open(self.path) as f:
                for lineno, raw_line in enumerate(f, start=1):
                    line = raw_line.strip()
                    if not line or line.startswith("#"):
                        continue

                    # Allow optional `export KEY=VALUE` form
                    if line.startswith("export "):
                        line = line[len("export "):].lstrip()

                    if "=" not in line:
                        print(f"  ⚠ {self.path}:{lineno}: skipping malformed line (no '='): {line[:40]}")
                        continue

                    key, val = line.split("=", 1)
                    key = key.strip()
                    val = val.strip()

                    if not key or not re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", key):
                        print(f"  ⚠ {self.path}:{lineno}: skipping invalid key: {key!r}")
                        continue

                    self.values[key] = _shell_unquote(val)

        # 2. Layer OS environment on top (env always wins).
        #
        # Loop over the UNION of keys already in .env AND well-known
        # Supero keys that MAY be in the environment. This fixes the
        # Cloud Run preview scenario where .env was stripped during
        # sanitization but Cloud Run injects SUPERO_* env vars.
        candidate_keys = set(self.values.keys()) | set(_SUPERO_KEYS)
        for key in candidate_keys:
            env_val = os.environ.get(key)
            if env_val is not None and env_val != "":
                self.values[key] = env_val


        # SUPERO_SENTINEL_GUARD_V1 — scrub bootstrap sentinels from .env.
        # bootstrap.py uses "__name__"-shaped strings as in-memory
        # signals (e.g. "__existing__"). If any of those leaked into
        # the .env file, they masquerade as real values: every code
        # path that reads SUPERO_PROJECT_UUID gets back "__existing__"
        # and uses it as if it were a UUID, breaking CRUD silently.
        # Drop them here so subsequent resolution paths (login, lazy
        # resolve, etc.) can fill in real values.
        for _k in list(self.values.keys()):
            _v = self.values[_k]
            if isinstance(_v, str) and _v.startswith("__") and _v.endswith("__"):
                print(f"  ⚠ Discarded sentinel value for {_k} from .env "
                      f"(was {_v!r} — see SUPERO_SENTINEL_GUARD_V1)")
                del self.values[_k]

        # SUPERO_STARTUP_VALIDATION_V1 — UUID no longer belongs in .env.
        # Self-heal legacy .env files by dropping it on load. Bootstrap
        # will re-resolve from server every startup; caching it caused
        # stale-UUID bugs (wrong project, "__existing__" leak, etc.).
        if "SUPERO_PROJECT_UUID" in self.values:
            _stale = self.values.pop("SUPERO_PROJECT_UUID")
            print(f"  ⚠ Removed SUPERO_PROJECT_UUID={_stale!r} from .env\n"
                  f"     (no longer persisted — resolved fresh each startup)")

    def reload(self):
        """Reload .env file (call after setup.py may have modified it)."""
        self.values.clear()
        self._load()

    # ─────────────────────────────────────────────────────────────
    # Access
    # ─────────────────────────────────────────────────────────────

    def get(self, key: str, default: str = "") -> str:
        """
        Get a value. Priority order:
          1. In-memory value (from .env load + any set() calls)
          2. OS environment
          3. provided default

        Note: _load() already merges env into self.values, so path (1)
        is normally authoritative. Path (2) is a safety net for keys
        set via os.environ after construction.
        """
        val = self.values.get(key)
        if val:
            return val
        env_val = os.environ.get(key)
        if env_val:
            return env_val
        return default

    def set(self, key: str, value: str):
        """Set a value in memory and in the process environment."""
        self.values[key] = value
        os.environ[key] = value

    def is_configured(self) -> bool:
        """
        Check if minimum configuration exists to run setup.

        Two valid modes:
          - API-key mode: DOMAIN + PROJECT + ak_... API key
          - Password mode: DOMAIN + PROJECT + EMAIL + PASSWORD

        NOTE: PROJECT is now required in both modes. Previously it
        silently defaulted to "default-project", which caused apps
        to upload schemas to the wrong namespace.
        """
        api_key = self.get("SUPERO_API_KEY", "")
        if (
            self.get("SUPERO_DOMAIN")
            and self.get("SUPERO_PROJECT")
            and api_key.startswith("ak_")
        ):
            return True
        return bool(
            self.get("SUPERO_DOMAIN")
            and self.get("SUPERO_PROJECT")
            and self.get("SUPERO_ADMIN_EMAIL")
            and self.get("SUPERO_PASSWORD")
        )

    def missing_required_keys(self) -> list:
        """
        Return a list of required keys missing for either config mode.
        Useful for producing actionable error messages.
        """
        api_key = self.get("SUPERO_API_KEY", "")
        if api_key.startswith("ak_"):
            return [k for k in _REQUIRED_API_KEY_MODE if not self.get(k)]
        return [k for k in _REQUIRED_PASSWORD_MODE if not self.get(k)]

    # ─────────────────────────────────────────────────────────────
    # Writing
    # ─────────────────────────────────────────────────────────────

    # [PROJECT_UUID_PERSIST_v1]

    def _maybe_resolve_project_uuid(self):

        """Best-effort: derive SUPERO_PROJECT_UUID from SUPERO_PROJECT.

    

        Called from save() so newly-generated .env files persist the UUID

        alongside the project name. Without this, downstream tools (like

        service_lib's exec()) have only the name and have to look up the

        UUID at runtime — or worse, omit project_uuid from requests entirely.

    

        Resolution path:

          1. If SUPERO_PROJECT_UUID already set, do nothing.

          2. Need SUPERO_DOMAIN + SUPERO_PROJECT + (SUPERO_API_KEY or

             SUPERO_URL). Otherwise skip silently.

          3. POST /api/v1/crud/{domain}/list-bulk with the project name

             filter; cache the resulting UUID in self.values.

    

        NEVER raises. Network/auth failures are swallowed — .save()

        must not block on this optional convenience.

        """

        if self.get('SUPERO_PROJECT_UUID'):

            return

        domain = self.get('SUPERO_DOMAIN')

        project = self.get('SUPERO_PROJECT')

        api_key = self.get('SUPERO_API_KEY')

        base_url = self.get('SUPERO_URL') or 'https://api.supero.dev'

        if not (domain and project and api_key):

            return

        try:

            import urllib.request, json as _json

            url = f'{base_url.rstrip("/")}/api/v1/crud/{domain}/list-bulk'

            body = _json.dumps({

                'type': 'project',

                'filters': {'name': project},

                'limit': 1,

            }).encode('utf-8')

            req = urllib.request.Request(

                url, data=body, method='POST',

                headers={

                    'Content-Type': 'application/json',

                    'Authorization': f'Bearer {api_key}',

                },

            )

            with urllib.request.urlopen(req, timeout=10) as resp:

                data = _json.loads(resp.read().decode('utf-8'))

            records = data.get('results', [])

            if records and records[0].get('uuid'):

                self.values['SUPERO_PROJECT_UUID'] = records[0]['uuid']

        except Exception:

            # Best-effort only. Save proceeds without the UUID; runtime

            # fallback in service_lib will handle it (or fail loudly there).

            pass



    def save(self, allow_partial: bool = False):
        """
        Write current values to .env file, quoting all values.

        Args:
            allow_partial: If False (default), raises ValueError if
                           required keys are missing. Set True only for
                           partial/bootstrap writes from interactive
                           setup where the user hasn't filled in
                           everything yet.

        All values are double-quoted with proper escape handling, so the
        resulting .env is safe to `source` in bash and to pass as a
        Docker --env-file.
        """
        if not allow_partial:
            missing = self.missing_required_keys()
            if missing:
                raise ValueError(
                    f"Refusing to save incomplete .env — missing required keys: "
                    f"{', '.join(missing)}. Pass allow_partial=True if intentional."
                )

        # SUPERO_STARTUP_VALIDATION_V1 — UUID no longer persisted to .env.
        # Bootstrap resolves it from the server at runtime; caching
        # was the source of stale-UUID corruption bugs.

        with open(self.path, "w") as f:
            f.write("# Supero App Configuration\n")
            f.write("# Generated by supero CLI — edit or delete to re-configure\n")
            f.write("# All values are double-quoted for safe shell/Docker parsing.\n\n")

            ordered_keys = [
                "SUPERO_URL", "SUPERO_DOMAIN", "SUPERO_ADMIN_EMAIL",
                "SUPERO_PASSWORD", "SUPERO_PROJECT",  # SUPERO_PROJECT_UUID intentionally omitted — see SUPERO_STARTUP_VALIDATION_V1

                "SUPERO_API_KEY",
                "SUPERO_DEFAULT_TENANT",
                "PLATFORM_CORE_HOST", "PLATFORM_CORE_PORT",
                "PUBLIC_SCHEMAS",
                "APP_NAME", "APP_EMOJI", "APP_DESCRIPTION",
                "PORT", "UI_PORT",
            ]
            written = set()

            for key in ordered_keys:
                if key in self.values:
                    f.write(f"{key}={_shell_quote(self.values[key])}\n")
                    written.add(key)

            remaining = {k: v for k, v in self.values.items() if k not in written}
            if remaining:
                f.write("\n# Additional configuration\n")
                for key, val in remaining.items():
                    f.write(f"{key}={_shell_quote(val)}\n")

    def clear(self):
        """Clear all values and delete .env file."""
        self.values.clear()
        if os.path.exists(self.path):
            os.remove(self.path)

        for key in _SUPERO_KEYS:
            os.environ.pop(key, None)

    # ─────────────────────────────────────────────────────────────
    # SDK derivations
    # ─────────────────────────────────────────────────────────────

    def derive_sdk_vars(self):
        """
        Derive PLATFORM_CORE_HOST and PLATFORM_CORE_PORT from SUPERO_URL.

        The Supero SDK reads these env vars for API connectivity,
        not the higher-level SUPERO_URL.
        """
        url = self.get("SUPERO_URL", "https://api.supero.dev")
        stripped = url.replace("http://", "").replace("https://", "")

        if ":" in stripped:
            host = stripped.split(":")[0]
            port = stripped.split(":")[1].split("/")[0]
        elif url.startswith("https://"):
            host = stripped.split("/")[0]
            port = "443"
        else:
            host = stripped.split("/")[0]
            port = "8083"

        self.set("PLATFORM_CORE_HOST", host)
        self.set("PLATFORM_CORE_PORT", port)

    # ─────────────────────────────────────────────────────────────
    # config.js generation
    # ─────────────────────────────────────────────────────────────


    def get_project_setting(self, key: str, default=None):
        """Get a project-level setting from SUPERO_<KEY> env var.

        Reads SUPERO_<UPPERCASE_KEY> from the env. Strips outer quotes.
        Coerces boolean-looking values to real bools:
          "true"/"1"/"yes"  → True
          "false"/"0"/"no"  → False
        Empty or missing → returns `default`.
        Anything else is returned as a stripped string.

        This is the canonical way to access project-level settings in the
        SDK. Prefer this over remote API fetches — the AI service writes
        these into .env at app-generation time, so they are available
        immediately without network calls or auth.
        """
        env_key = f"SUPERO_{key.upper()}"
        raw = (self.get(env_key, "") or "").strip().strip('"').strip("'")
        if not raw:
            return default
        low = raw.lower()
        if low in ("true", "1", "yes"):
            return True
        if low in ("false", "0", "no"):
            return False
        return raw

    def generate_config_js(self, ui_dir: str, app_name: str = "", app_emoji: str = "", app_description: str = "", public_schemas: list = None, is_multi_tenant: bool = False, tenant_noun_singular: str = "Workspace", tenant_noun_plural: str = "Workspaces", app_namespace: str = ""):
        """
        Generate config.js for the web UI.

        The web UI reads window.__SUPERO_CONFIG at startup to determine
        domain, project, API server, and app branding for the login page.

        CRITICAL CHANGES vs. previous version:
          - SUPERO_PROJECT NO LONGER defaults to "default-project".
            If it's missing, this method raises ValueError. This prevents
            the silent-fallback-to-zombie-namespace bug where apps were
            deployed pointing at a project that was never explicitly set.
          - SUPERO_DOMAIN is also required (was implicitly empty string).
        """
        domain = self.get("SUPERO_DOMAIN", "")
        project = self.get("SUPERO_PROJECT", "")
        # SUPERO_PROJECT_UUID_FIX_V1 — emit project_uuid into config.js
        # so the web UI can pass it as project_uuid on /services/execute
        # calls. Without this, _svc() falls back to project NAME which
        # the server misinterprets as a UUID ("not imported" errors).
        project_uuid = self.get("SUPERO_PROJECT_UUID", "")

        if not domain:
            raise ValueError(
                "Cannot generate config.js: SUPERO_DOMAIN is not set. "
                "Run `supero init` or set SUPERO_DOMAIN in the environment."
            )
        if not project:
            raise ValueError(
                "Cannot generate config.js: SUPERO_PROJECT is not set. "
                "There is NO default project — pass --project or set "
                "SUPERO_PROJECT explicitly. 'default-project' is no longer "
                "a silent fallback because it caused apps to route schemas "
                "to the wrong namespace."
            )

        tenant = self.get("SUPERO_DEFAULT_TENANT", "default-tenant")
        api_url = self.get("SUPERO_URL", "https://api.supero.dev")

        # App branding: env > method args > domain-derived
        name = self.get("APP_NAME") or app_name or domain.replace("-", " ").title() or "Supero App"
        emoji = self.get("APP_EMOJI") or app_emoji or "🚀"
        description = self.get("APP_DESCRIPTION") or app_description or ""

        def js_escape(s: str) -> str:
            return s.replace("\\", "\\\\").replace('"', '\\"')

        # publicSchemas is the runtime injection point for the browser.
        # The CLI populates it from schemas.py PUBLIC_SCHEMAS so AppShell
        # never has to read it from app.js (where the LLM might have
        # hardcoded a wrong value).
        _ps_list = list(public_schemas) if public_schemas is not None else []
        _ps_js_items = ", ".join(f'"{js_escape(s)}"' for s in _ps_list)
        _ps_js_array = f"[{_ps_js_items}]"

        # Normalize namespace the same way schema_naming does on the server
        # (lowercase + hyphens to underscores). Fall back to domain (the
        # most common app namespace) if not explicitly passed.
        # SUPERO_NAMESPACE_REQUIRED_V1 — refuse silent fallback to domain.
        _ns_raw = (app_namespace or self.get("SUPERO_APP_NAMESPACE", "")).strip()
        if not _ns_raw:
            raise ValueError(
                "Cannot generate config.js: SUPERO_APP_NAMESPACE is required.\n"
                "Previously this fell back to SUPERO_DOMAIN which silently\n"
                "routed CRUD calls to the wrong namespace, returning empty\n"
                "results with no error.\n"
                "\n"
                "Fix: set SUPERO_APP_NAMESPACE one of these ways:\n"
                "  1. .env: add SUPERO_APP_NAMESPACE=\"<namespace>\"\n"
                "  2. schemas.py: add as a bare literal (per §1.7 contract)\n"
                "  3. Pass app_namespace='<value>' to generate_config_js()\n"
                "\n"
                "See SUPERO_NAMESPACE_REQUIRED_V1."
            )
        _ns_normalized = _ns_raw.lower().replace("-", "_")

        config_js = (
            "// Generated by supero CLI — do not edit manually\n"
            "window.__SUPERO_CONFIG = {\n"
            f'    domain: "{js_escape(domain)}",\n'
            f'    project: "{js_escape(project)}",\n'
            f'    project_uuid: "{js_escape(project_uuid)}",\n'
            f'    tenant: "{js_escape(tenant)}",\n'
            f'    apiUrl: "{js_escape(api_url)}",\n'
            f'    appName: "{js_escape(name)}",\n'
            f'    appEmoji: "{js_escape(emoji)}",\n'
            f'    appDescription: "{js_escape(description)}",\n'
            f'    publicSchemas: {_ps_js_array},\n'
            f'    isMultiTenant: {"true" if is_multi_tenant else "false"},\n'
            f'    tenantNoun: {{ singular: "{js_escape(tenant_noun_singular)}", plural: "{js_escape(tenant_noun_plural)}" }},\n'
            f'    appNamespace: "{js_escape(_ns_normalized)}"\n'
            "};\n"
        )

        os.makedirs(ui_dir, exist_ok=True)
        config_path = os.path.join(ui_dir, "config.js")
        with open(config_path, "w") as f:
            f.write(config_js)

        print(f"  ✓ Generated config.js (domain={domain}, project={project})")

    # ─────────────────────────────────────────────────────────────
    # Bundle-identity recovery (SUPERO_BUNDLE_RECOVERY_V1)
    # ─────────────────────────────────────────────────────────────

    def recover_from_bundle(self, app_dir: str, *, no_interactive: bool = False) -> bool:
        """SUPERO_BUNDLE_RECOVERY_V1 — rebuild .env from bundle identity.

        Called from cli/run.py before interactive_setup() when .env is
        missing. Reads three bare string literals from schemas.py:

            SUPERO_DOMAIN          = "..."
            SUPERO_PROJECT         = "..."
            SUPERO_APP_NAMESPACE   = "..."

        If all three are present, prompts the user for admin credentials
        only (NOT for project name — bundle identity is the source of
        truth) and writes a partial .env. The CLI's normal "configure
        port / save full .env" path runs afterward.

        Why this exists:
        EnvManager already refuses 'default-project' as a silent
        fallback (see is_configured + generate_config_js). But when
        .env is missing entirely, interactive_setup re-prompts for
        every value including project name. A user who 'rm .env' to
        reset can type a wrong project, orphaning their seed data and
        confusing the UI. Bundle-identity recovery makes that impossible
        — the project comes from schemas.py, the user can only enter
        credentials.

        Args:
            app_dir:        bundle root (where schemas.py lives)
            no_interactive: if True, skip the credentials prompt and
                            return False if creds aren't already in
                            self.values

        Returns:
            True if recovery wrote a usable .env, False if caller
            should fall back to interactive_setup (e.g. bundle has no
            identity literals — predates V1 — or user declined).
        """
        import os as _os
        import ast as _ast

        schemas_py_path = _os.path.join(app_dir, "schemas.py")
        if not _os.path.isfile(schemas_py_path):
            return False

        # AST-extract the three literals. We want all-or-nothing: if
        # any of the three is missing or is an expression rather than
        # a bare Constant string, treat the bundle as not-recoverable
        # and fall back to interactive_setup.
        try:
            with open(schemas_py_path, "r", encoding="utf-8") as f:
                tree = _ast.parse(f.read(), filename=schemas_py_path)
        except (OSError, SyntaxError):
            return False

        targets = {
            "SUPERO_DOMAIN": None,
            "SUPERO_PROJECT": None,
            "SUPERO_APP_NAMESPACE": None,
        }
        for node in tree.body:  # top-level only — per §1.7 contract
            if not isinstance(node, _ast.Assign):
                continue
            for tgt in node.targets:
                if not isinstance(tgt, _ast.Name):
                    continue
                if tgt.id not in targets:
                    continue
                # Must be a bare string literal — refuse expressions
                if (isinstance(node.value, _ast.Constant)
                        and isinstance(node.value.value, str)
                        and node.value.value):
                    targets[tgt.id] = node.value.value

        if not all(targets.values()):
            # Bundle predates V1 or is incomplete — caller falls back
            return False

        domain = targets["SUPERO_DOMAIN"]
        project = targets["SUPERO_PROJECT"]
        namespace = targets["SUPERO_APP_NAMESPACE"]

        # Display + prompt
        print()
        print("  ╔══════════════════════════════════════════════════════════╗")
        print("  ║  Bundle identity detected — recovering .env              ║")
        print("  ╚══════════════════════════════════════════════════════════╝")
        print(f"    Domain:    {domain}")
        print(f"    Project:   {project}")
        print(f"    Namespace: {namespace}")
        print()
        print("  This bundle is registered to the project shown above.")
        print("  Recovery will NOT create a new project — to migrate to a")
        print("  different project, regenerate the bundle with different")
        print("  SUPERO_DOMAIN / SUPERO_PROJECT in schemas.py.")
        print()

        # If creds already present (e.g. from os.environ for Cloud Run),
        # use them without prompting. Otherwise prompt unless no_interactive.
        email = self.get("SUPERO_ADMIN_EMAIL", "")
        password = self.get("SUPERO_PASSWORD", "")

        if not (email and password):
            if no_interactive:
                print("  ⚠ Credentials missing and --no-interactive set — skipping recovery")
                return False
            try:
                if not email:
                    email = input("    Admin email: ").strip()
                if not password:
                    import getpass as _getpass
                    password = _getpass.getpass("    Password:    ")
            except (EOFError, KeyboardInterrupt):
                print()
                print("  ⚠ Recovery cancelled")
                return False

        if not email or not password:
            print("  ⚠ Email and password required for recovery")
            return False

        # Write to env. URL gets a sensible default; project_uuid is left
        # for the save() lazy-resolve to fill in once we have credentials.
        self.set("SUPERO_DOMAIN", domain)
        self.set("SUPERO_PROJECT", project)
        self.set("SUPERO_APP_NAMESPACE", namespace)
        self.set("SUPERO_ADMIN_EMAIL", email)
        self.set("SUPERO_PASSWORD", password)
        if not self.get("SUPERO_URL"):
            self.set("SUPERO_URL", "https://api.supero.dev")

        # Save with allow_partial=False — the four-key password-mode
        # requirement should already be satisfied at this point.
        try:
            self.save()
        except ValueError as e:
            print(f"  ⚠ Recovery write failed: {e}")
            return False

        print()
        print(f"  ✓ Recovered .env for project '{project}'")
        return True

    # ─────────────────────────────────────────────────────────────
    # Startup validation (SUPERO_STARTUP_VALIDATION_V1)
    # ─────────────────────────────────────────────────────────────

    def _parse_api_key_segments(self, api_key):
        """SUPERO_STARTUP_VALIDATION_V1 — parse API key into segments.

        Format: ak_<domain>_<project>_<tenant>_<env>_<uuid>_<secret>

        Project/tenant can contain hyphens but NOT underscores, so
        splitting on _ gives clean segments. UUID has internal hyphens
        too (standard UUID format).

        Returns dict {domain, project, tenant, env, uuid} or None
        if the format doesn't match.
        """
        if not api_key or not isinstance(api_key, str):
            return None
        api_key = api_key.strip()
        if not api_key.startswith("ak_"):
            return None
        parts = api_key.split("_")
        # ["ak", domain, project, tenant, env, uuid, secret]
        if len(parts) < 7:
            return None
        return {
            "domain":  parts[1],
            "project": parts[2],
            "tenant":  parts[3],
            "env":     parts[4],
            "uuid":    parts[5],
            # secret = parts[6] — not returned, would leak in logs
        }

    def validate_required(self):
        """SUPERO_STARTUP_VALIDATION_V1 — Step 0 config gate.

        Called from cli/run.py before ANY setup runs. Checks every
        critical config field that, if wrong, would cause silent
        downstream failures (empty UI, wrong namespace, wrong project).

        Collects ALL failures and raises a single ValueError with
        combined message. Fail-all (not fail-fast) is intentional here:
        setup is a one-time review-config moment, user benefits from
        seeing every problem at once.

        After this returns successfully, run.py is allowed to proceed
        to bootstrap. Bootstrap then resolves SUPERO_PROJECT_UUID from
        the server (login response) — never read from .env.

        Raises:
            ValueError: with multi-line message listing every problem
                        found and a concrete fix for each.
        """
        problems = []

        # Check 1: SUPERO_DOMAIN
        domain = (self.get("SUPERO_DOMAIN", "") or "").strip()
        if not domain:
            problems.append(
                "SUPERO_DOMAIN is missing or empty.\n"
                "  Fix: add to .env:  SUPERO_DOMAIN=\"<your-domain>\""
            )

        # Check 2: SUPERO_PROJECT
        project = (self.get("SUPERO_PROJECT", "") or "").strip()
        if not project:
            problems.append(
                "SUPERO_PROJECT is missing or empty.\n"
                "  Fix: add to .env:  SUPERO_PROJECT=\"<your-project-name>\"\n"
                "  (NOT the namespace — the project name is the slug "
                "shown in the admin UI, e.g. 'car-fleet-mani45-tpnj')"
            )
        elif project == "default-project":
            problems.append(
                "SUPERO_PROJECT is set to 'default-project'.\n"
                "  'default-project' is the auth realm, not a real project.\n"
                "  Bundles must run against a named project so CRUD calls\n"
                "  route to the right namespace.\n"
                "  Fix: in .env, change SUPERO_PROJECT to your actual project\n"
                "  name (e.g. SUPERO_PROJECT=\"car-fleet-mani45-tpnj\")"
            )

        # Check 3: SUPERO_APP_NAMESPACE
        namespace = (self.get("SUPERO_APP_NAMESPACE", "") or "").strip()
        if not namespace:
            problems.append(
                "SUPERO_APP_NAMESPACE is missing or empty.\n"
                "  This is required to qualify CRUD URLs so they route to\n"
                "  the right schema namespace (e.g. 'my_app:vehicle' not\n"
                "  just 'vehicle'). Without it, the SDK previously fell\n"
                "  back to SUPERO_DOMAIN as namespace, causing silent\n"
                "  empty-result UIs.\n"
                "  Fix: add to .env:  SUPERO_APP_NAMESPACE=\"<your_namespace>\"\n"
                "  Or add to schemas.py as a bare literal:\n"
                "    SUPERO_APP_NAMESPACE = \"<your_namespace>\""
            )

        # Check 4: SUPERO_URL (need it to call platform)
        url = (self.get("SUPERO_URL", "") or "").strip()
        if not url:
            problems.append(
                "SUPERO_URL is missing or empty.\n"
                "  Fix: add to .env:  SUPERO_URL=\"https://api.supero.dev\""
            )

        # Check 5: API key OR (email + password) — need some auth path
        api_key = (self.get("SUPERO_API_KEY", "") or "").strip()
        email   = (self.get("SUPERO_ADMIN_EMAIL", "") or "").strip()
        passwd  = (self.get("SUPERO_PASSWORD", "") or "").strip()

        has_api_auth = bool(api_key)
        has_pw_auth  = bool(email and passwd)

        if not (has_api_auth or has_pw_auth):
            problems.append(
                "No authentication credentials found.\n"
                "  Provide ONE of:\n"
                "    SUPERO_API_KEY=\"ak_...\"    (API key auth)\n"
                "  OR:\n"
                "    SUPERO_ADMIN_EMAIL=\"...\"\n"
                "    SUPERO_PASSWORD=\"...\"      (password auth)"
            )

        # Check 6: If API key present, validate its scope matches env
        if api_key:
            segs = self._parse_api_key_segments(api_key)
            if segs is None:
                problems.append(
                    "SUPERO_API_KEY format is invalid.\n"
                    "  Expected: ak_<domain>_<project>_<tenant>_<env>_<uuid>_<secret>\n"
                    "  Got something with fewer than 7 underscore-separated segments.\n"
                    "  Fix: regenerate the API key from the admin UI."
                )
            else:
                # API key project must match env project
                if domain and segs["domain"] != domain:
                    problems.append(
                        f"SUPERO_API_KEY domain segment is '{segs['domain']}' "
                        f"but SUPERO_DOMAIN is '{domain}'.\n"
                        f"  The API key was issued for a different domain. "
                        f"All CRUD calls will be rejected.\n"
                        f"  Fix: regenerate API key for domain '{domain}', "
                        f"or change SUPERO_DOMAIN to match the key."
                    )
                if project and segs["project"] != project:
                    problems.append(
                        f"SUPERO_API_KEY project segment is '{segs['project']}' "
                        f"but SUPERO_PROJECT is '{project}'.\n"
                        f"  The API key is scoped to the wrong project — CRUD\n"
                        f"  calls will land there instead of '{project}',\n"
                        f"  returning empty results with no error.\n"
                        f"  Fix: regenerate API key scoped to project '{project}'."
                    )
                if segs["project"] == "default-project":
                    problems.append(
                        "SUPERO_API_KEY is scoped to 'default-project' "
                        "(the auth realm, not a real project).\n"
                        "  CRUD calls will land in default-project, returning\n"
                        "  empty results for your actual project's schemas.\n"
                        "  Fix: regenerate API key scoped to your real\n"
                        "  project name (whatever SUPERO_PROJECT is)."
                    )

        if not problems:
            return  # all good

        # Build the combined error message
        header = (
            "═══════════════════════════════════════════════════════════\n"
            "  CONFIGURATION VALIDATION FAILED — refusing to start\n"
            "═══════════════════════════════════════════════════════════\n"
            f"\n  Found {len(problems)} problem(s) in .env / environment:\n\n"
        )
        body = ""
        for i, p in enumerate(problems, start=1):
            body += f"  [{i}] {p}\n\n"
        footer = (
            "  After fixing the above, re-run ./run.sh.\n"
            "  See SUPERO_STARTUP_VALIDATION_V1 in env_manager.py for\n"
            "  rationale on each check.\n"
        )
        raise ValueError(header + body + footer)

