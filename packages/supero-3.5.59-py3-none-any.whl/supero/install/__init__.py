# PATCH_APPLIED:SDK-MANIFEST-E2E-V1 (e2e_tests.py already present)
"""Project bootstrap subsystem — single canonical writer for project files.

Public contracts:
    PROJECT_MANIFEST — dict mapping bundled-resource specs to project-relative paths
    extract_to_project — the canonical writer
    EnvSchema — typed schema for project .env files
    build_env_content — render an .env from a generation request

Per SUPERO_3_5_0_BLUEPRINT.md principles:
    §1.1  One source of truth — every bundled file lives in this wheel
    §1.4  One canonical writer — extract_to_project is the only one
    §1.6  Configuration has a schema — EnvSchema is shared by both writers
    §1.7  Per-project secrets are random by default

Note on serve_mobile: per the blueprint bug log entry BUG-9, the manifest
includes serve_mobile.py as an OPTIONAL extraction. Web-only callers don't
extract it; platform-core's mobile-aware preview path does, replacing the
current `_hydrate_mobile_routes` shutil.copy from supero.cli.
"""
import base64
import json
import os
import secrets
import shutil
from dataclasses import dataclass, field, MISSING
from importlib.resources import files
from pathlib import Path
from typing import Optional

_INSTALL_ROOT = files('supero.install')
_UI_ROOT = files('supero.ui')


# ── Project manifest ──────────────────────────────────────────────────────
#
# Single source of truth for "where does X go in a project."
# Adding a new bundled file = one new manifest entry.
#
# `serve_mobile.py` was added per BUG-9 in the blueprint review; it maps
# to `_serve_mobile.py` at the project root because that's where
# platform-core's `_hydrate_mobile_routes` copies it today (the leading
# underscore prevents it being treated as user-facing module).
#
PROJECT_MANIFEST = {
    'supero.install:scripts/run.sh':                 'run.sh',
    'supero.install:scripts/run.bat':                'run.bat',
    'supero.install:scripts/expo.sh':                'mobile/expo.sh',
    # RUN_TESTS_SH_V1
    'supero.install:scripts/run_tests.sh':           'tests/run_tests.sh',
    # Dockerfile + docker-compose.yml are TEMPLATES (use {SDK_VERSION},
    # {APP_SLUG}, {PORT} placeholders) — see extract_templates.py docstring.
    # Source on disk is .tmpl; destination filename is plain.
    'supero.install:containers/Dockerfile.tmpl':         'Dockerfile',
    'supero.install:containers/docker-compose.yml.tmpl': 'docker-compose.yml',
    'supero.install:docs/README.md.tmpl':            'README.md',
    'supero.install:docs/CLAUDE.md':                 'CLAUDE.md',
    'supero.install:docs/CUSTOMIZATION.md':          'CUSTOMIZATION.md',
    # TESTS_FOLDER_V1 — all test files land in tests/ subfolder
    'supero.install:templates/test_bundle.py':       'tests/test_bundle.py',
    'supero.install:templates/e2e_tests.py':         'tests/e2e_tests.py',
    'supero.install:templates/workflow_tests.py':    'tests/workflow_tests.py',
    # DIAGNOSTICS_V1 — diagnostic suite (now in tests/)
    'supero.install:templates/_test_lib.py':           'tests/_test_lib.py',
    'supero.install:templates/integration_tests.py':   'tests/integration_tests.py',
    'supero.install:templates/transactional_tests.py': 'tests/transactional_tests.py',
    'supero.install:templates/test_all.py':            'tests/test_all.py',
    # SERVICE_INTEGRATION_REPORT_V1
    'supero.install:templates/service_integration_report.py': 'tests/service_integration_report.py',
    'supero.install:templates/server.py':            'ui/server.py',
    'supero.install:templates/serve_mobile.py':      '_serve_mobile.py',
    'supero.install:templates/index.html.tmpl':      'ui/index.html',
    # DISPATCHER_MANIFEST_V1
    'supero.ui:dispatcher.js':    'ui/dispatcher.js',
    # FIELD_RENDERER_MANIFEST_V1
    'supero.ui:field-renderer.js': 'ui/field-renderer.js',
    'supero.ui:supero-ui.js':                        'ui/supero-ui.js',
    'supero.ui:supero-mobile.jsx':                   'mobile/src/lib/supero-mobile.jsx',
}


# ── EnvSchema ─────────────────────────────────────────────────────────────


@dataclass
class EnvSchema:
    """Typed schema for project .env files.

    Generation-time fields (default=MISSING) must be supplied by ai-service.
    Runtime fields default to None and are filled by app_setup.py at first
    run when API key is fetched, tenant resolved, etc.

    Tunable defaults (port, public_schemas) have concrete defaults that
    callers can override.
    """

    # ── Generation-time fields (ai-service populates) ──
    supero_url: str = MISSING
    supero_domain: str = MISSING
    supero_project: str = MISSING
    supero_project_display: str = MISSING
    supero_project_uuid: str = MISSING
    supero_admin_email: str = MISSING

    # Random per project (§1.7). Generated at construction unless provided.
    supero_password: str = field(
        default_factory=lambda: secrets.token_urlsafe(20)
    )

    # ── Runtime fields (app_setup populates) ──
    supero_api_key: Optional[str] = None
    supero_tenant_uuid: Optional[str] = None

    # ── Multi-tenant config (optional) ──
    # Mirrors the existing _build_env_content behaviour: only emitted when
    # the request explicitly opts in. Pass None to omit; pass values to emit.
    supero_is_multi_tenant: Optional[bool] = None
    supero_tenant_noun_singular: Optional[str] = None
    supero_tenant_noun_plural: Optional[str] = None

    # ── Tunable defaults ──
    port: int = 5648
    public_schemas: str = ""

    def to_env_text(self) -> str:
        """Render as .env file content with comments. Matches the layout
        produced by the legacy _build_env_content so existing tooling
        (test_bundle.py, server.py) finds the same keys.
        """
        from datetime import datetime
        lines = [
            "# Pre-configured by Supero",
            f"# Generated: {datetime.now().isoformat()}",
            f"SUPERO_URL={self.supero_url}",
            f"SUPERO_DOMAIN={self.supero_domain}",
            f'SUPERO_PROJECT="{self.supero_project}"',
            f'SUPERO_PROJECT_DISPLAY="{self.supero_project_display}"',
        ]
        if self.supero_project_uuid:
            lines.append(f'SUPERO_PROJECT_UUID="{self.supero_project_uuid}"')
        # [bug9-patch] env var renamed APP_NAMESPACE -> SUPERO_APP_NAMESPACE
        # SUPERO_APP_NAMESPACE — single canonical env var read by server.py,
        # env_manager.py, and the smoke test in cli/run.py. Emit only if
        # supero_app_namespace is set on the config; older callers continue
        # to work since the generated schemas.py has its own baked-in fallback.
        _app_ns = getattr(self, "supero_app_namespace", "") or ""
        if _app_ns:
            lines.append(f'SUPERO_APP_NAMESPACE="{_app_ns}"')
        if self.supero_admin_email:
            lines.append(f"SUPERO_ADMIN_EMAIL={self.supero_admin_email}")

        # Per §1.7: random password is the default. Always emit.
        lines.append(f"SUPERO_PASSWORD={self.supero_password}")

        if self.supero_api_key:
            lines.append(f"SUPERO_API_KEY={self.supero_api_key}")
        if self.supero_tenant_uuid:
            lines.append(f"SUPERO_TENANT_UUID={self.supero_tenant_uuid}")

        # Multi-tenant bits — emitted only when caller set the flag.
        if self.supero_is_multi_tenant:
            lines.append("SUPERO_IS_MULTI_TENANT=true")
            if self.supero_tenant_noun_singular:
                lines.append(
                    f"SUPERO_TENANT_NOUN_SINGULAR={self.supero_tenant_noun_singular}"
                )
            if self.supero_tenant_noun_plural:
                lines.append(
                    f"SUPERO_TENANT_NOUN_PLURAL={self.supero_tenant_noun_plural}"
                )

        lines.append(f"PORT={self.port}")
        if self.public_schemas:
            lines.append(f"PUBLIC_SCHEMAS={self.public_schemas}")

        # trailing newline (POSIX convention)
        return "\n".join(lines) + "\n"

    @classmethod
    def from_env_path(cls, env_path: str) -> "EnvSchema":
        """Parse an existing .env file into an EnvSchema instance.

        Returns a fully-constructed instance even if the .env is missing
        generation-time fields — those default to empty strings (so the
        caller can detect "field absent" via truthiness without dealing
        with MISSING sentinels). Unknown keys in the .env are ignored.

        Used by app_setup.py to read-modify-write the .env at runtime.
        """
        # Build kwargs with safe defaults for required fields so the
        # constructor doesn't choke on a partial .env (e.g. one that
        # only has runtime fields after first login).
        kwargs = {
            'supero_url': '',
            'supero_domain': '',
            'supero_project': '',
            'supero_project_display': '',
            'supero_project_uuid': '',
            'supero_admin_email': '',
        }
        if not os.path.exists(env_path):
            return cls(**kwargs)

        with open(env_path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                v = v.strip().strip('"').strip("'")
                k_lower = k.strip().lower()
                # BUG-7 fix: direct dict membership is idiomatic and
                # version-portable.
                if k_lower in cls.__dataclass_fields__:
                    if k_lower == "port":
                        try:
                            kwargs[k_lower] = int(v)
                        except ValueError:
                            pass
                    elif k_lower == "supero_is_multi_tenant":
                        kwargs[k_lower] = v.lower() == "true"
                    else:
                        kwargs[k_lower] = v
        return cls(**kwargs)

    def merge_runtime_from_env_path(self, env_path: str) -> None:
        """Update self in-place with runtime fields from an existing .env.

        Only runtime fields (api_key, tenant_uuid) are merged — generation-
        time fields stay as set on self. Used by ai-service at re-generation
        time when an existing project already has an API key the user
        wants to preserve.
        """
        if not os.path.exists(env_path):
            return
        existing = self.from_env_path(env_path)
        if existing.supero_api_key:
            self.supero_api_key = existing.supero_api_key
        if existing.supero_tenant_uuid:
            self.supero_tenant_uuid = existing.supero_tenant_uuid


# ── build_env_content (the ai-service entry point) ────────────────────────


def _decode_jwt_email(jwt_token: str) -> str:
    """Best-effort email extraction from a JWT (no signature verification).

    Used only to populate SUPERO_ADMIN_EMAIL for display. Verification is
    irrelevant because we're not authenticating anything from the value —
    we're echoing the user's identity back into a config file the user
    will then run.
    """
    if not jwt_token:
        return ""
    try:
        parts = jwt_token.split(".")
        if len(parts) < 2:
            return ""
        payload = parts[1] + "=" * (4 - len(parts[1]) % 4)
        claims = json.loads(base64.urlsafe_b64decode(payload))
        return claims.get("email") or claims.get("username") or ""
    except Exception:
        return ""


def build_env_content(
    *,
    request=None,
    jwt_token: Optional[str] = None,
) -> str:
    """Build .env file content from a BundleAppRequest + optional JWT.

    `request` is duck-typed: any object with attributes `domain`,
    `project_name`, `project_uuid`, optional `is_multi_tenant`,
    `tenant_noun_singular`, `tenant_noun_plural`, `project_context`.
    Falls back to a minimal stub if request is None (legacy callers).

    Replaces ai-service's _build_env_content. Honors §1.7 by emitting a
    random password — no interactive setup required. Honors §1.6 by
    routing through EnvSchema instead of building lines ad-hoc.
    """
    if request is None:
        # Legacy fallback. Emits the minimum viable .env so a user running
        # ./run.sh can fill in the rest. Random password still applied so
        # there's no Password123! anywhere.
        return EnvSchema(
            supero_url="https://api.supero.dev",
            supero_domain="",
            supero_project="default-project",
            supero_project_display="Default Project",
            supero_project_uuid="",
            supero_admin_email="",
        ).to_env_text()

    pctx = getattr(request, "project_context", None) or {}

    project_name = (
        pctx.get("name")
        or getattr(request, "project_name", None)
        or "default-project"
    )
    project_display = (
        pctx.get("display_name")
        or project_name.replace("-", " ").replace("_", " ").title()
    )
    project_uuid = (getattr(request, "project_uuid", None) or "").strip()

    admin_email = (
        _decode_jwt_email(jwt_token)
        if jwt_token
        else getattr(request, "admin_email", "")
    ) or ""

    # Multi-tenant resolution mirrors legacy logic exactly: request flag
    # wins, then project_context, then omit.
    is_mt = getattr(request, "is_multi_tenant", None)
    if is_mt is None:
        is_mt = pctx.get("is_multi_tenant")

    tenant_noun_singular = None
    tenant_noun_plural = None
    if is_mt:
        tenant_noun_singular = (
            getattr(request, "tenant_noun_singular", None)
            or pctx.get("tenant_noun_singular")
            or "Workspace"
        )
        tenant_noun_plural = (
            getattr(request, "tenant_noun_plural", None)
            or pctx.get("tenant_noun_plural")
            or "Workspaces"
        )

    schema = EnvSchema(
        supero_url=getattr(request, "supero_url", "https://api.supero.dev"),
        supero_domain=request.domain,
        supero_project=project_name,
        supero_project_display=project_display,
        supero_project_uuid=project_uuid,
        supero_admin_email=admin_email,
        supero_is_multi_tenant=bool(is_mt) if is_mt else None,
        supero_tenant_noun_singular=tenant_noun_singular,
        supero_tenant_noun_plural=tenant_noun_plural,
    )
    return schema.to_env_text()


# ── extract_to_project (the canonical writer) ─────────────────────────────


def get_path(spec: str) -> str:
    """Resolve '<pkg>:<path>' spec to absolute filesystem path.

    Raises ValueError on malformed spec or unknown package.
    Raises FileNotFoundError if the file isn't bundled in the wheel.
    """
    if ':' not in spec:
        raise ValueError(f"Invalid spec '{spec}' — expected '<pkg>:<path>'")

    pkg, rel = spec.split(':', 1)
    if pkg == 'supero.install':
        root = _INSTALL_ROOT
    elif pkg == 'supero.ui':
        root = _UI_ROOT
    else:
        raise ValueError(
            f"Unknown package '{pkg}' — expected 'supero.install' or 'supero.ui'"
        )

    p = root / rel
    if not os.path.isfile(str(p)):
        raise FileNotFoundError(f"No such bundled resource: {spec}")
    return str(p)


def extract_to_project(
    project_dir: str,
    items: Optional[list] = None,
    render_values: Optional[dict] = None,
) -> list:
    """Extract bundled resources into a project per PROJECT_MANIFEST.

    If items is None, extracts ALL items in the manifest.

    .tmpl files are rendered with {KEY} substitution from render_values.
    Non-.tmpl files are copied verbatim.
    Shell scripts (.sh, .bat) get executable bit set.

    Special-cased post-extraction aliases (only fire if CLAUDE.md was
    in the items list for this call — BUG-5 fix):
        - CLAUDE.md → .cursorrules (copy)
        - CLAUDE.md → .windsurfrules (copy)

    Idempotent — running twice produces identical state.
    Atomic per file — uses tempfile + rename, no partial writes.

    Returns list of absolute paths written.
    """
    project_dir = os.path.abspath(project_dir)
    if not os.path.isdir(project_dir):
        raise FileNotFoundError(f"Project dir does not exist: {project_dir}")

    if items is None:
        items = list(PROJECT_MANIFEST.keys())

    written = []
    for spec in items:
        if spec not in PROJECT_MANIFEST:
            raise KeyError(
                f"Unknown bundled resource: {spec!r}. "
                f"See PROJECT_MANIFEST for valid specs."
            )
        src = get_path(spec)
        dst = os.path.join(project_dir, PROJECT_MANIFEST[spec])
        os.makedirs(os.path.dirname(dst) or '.', exist_ok=True)

        if src.endswith('.tmpl'):
            content = Path(src).read_text(encoding='utf-8')
            # Use Python str.format_map semantics so `{{` and `}}` escape
            # correctly to `{` and `}` (these are common in Dockerfiles
            # that use shell `${VAR}` syntax — the source file has
            # `${{VAR}}` which must end up as `${VAR}` literal, NOT have
            # VAR substituted). A plain str.replace can't distinguish
            # `{PORT}` (substitute) from `${{PORT}}` (literal).
            #
            # _SafeFormat returns the original placeholder for keys not
            # in render_values, so unrecognized {KEY} placeholders survive
            # rendering instead of raising KeyError.
            class _SafeFormat(dict):
                def __missing__(self, key):
                    return '{' + key + '}'
            try:
                rendered = content.format_map(_SafeFormat(render_values or {}))
            except (ValueError, IndexError) as e:
                # format_map raises ValueError on unmatched braces (e.g.
                # `{` followed by a `}` later with non-key content). If
                # the source isn't a clean .format-style template, fail
                # loudly so the migration doesn't ship garbled files.
                raise ValueError(
                    f"Failed to render template {spec}: {e}. "
                    f"The source likely contains stray '{{' or '}}' "
                    f"that aren't proper Python format escapes."
                ) from e
            tmp = dst + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as f:
                f.write(rendered)
            os.replace(tmp, dst)
        else:
            # shutil.copy2 preserves mode + mtime. We then re-chmod
            # shell scripts unconditionally below for correctness.
            shutil.copy2(src, dst)

        if dst.endswith('.sh') or dst.endswith('.bat'):
            os.chmod(dst, 0o755)
        written.append(dst)

    # Editor-rule aliases — BUG-5: only fire when CLAUDE.md was extracted
    # in THIS call. Selective extractions don't surprise callers.
    CLAUDE_SPEC = 'supero.install:docs/CLAUDE.md'
    if CLAUDE_SPEC in items:
        claude_md = os.path.join(project_dir, 'CLAUDE.md')
        if os.path.exists(claude_md):
            for editor_rule in ('.cursorrules', '.windsurfrules'):
                rule_path = os.path.join(project_dir, editor_rule)
                shutil.copy2(claude_md, rule_path)
                written.append(rule_path)

    return written


__all__ = [
    'PROJECT_MANIFEST',
    'EnvSchema',
    'build_env_content',
    'extract_to_project',
    'get_path',
]
