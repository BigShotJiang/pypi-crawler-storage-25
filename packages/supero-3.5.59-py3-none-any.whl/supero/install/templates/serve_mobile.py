#!/usr/bin/env python3
import json
import mimetypes
import os
import sys
import uuid
from datetime import datetime, timezone


# ── Constants ────────────────────────────────────────────────────────────
# These are bound at module load time. In production, MOBILE_DIST is
# always /app/mobile-dist (set by Cloud Build stage 2 via COPY --from).
# If you need to override for testing, monkey-patch all three together
# (MOBILE_DIST, UNAVAILABLE_MARKER, METADATA_PATH) — the latter two are
# computed FROM MOBILE_DIST and won't auto-update if only MOBILE_DIST is
# patched.

MOBILE_DIST = "/app/mobile-dist"
UNAVAILABLE_MARKER = os.path.join(MOBILE_DIST, "UNAVAILABLE")
METADATA_PATH = os.path.join(MOBILE_DIST, "metadata.json")

# Mobile app source paths — present in the runtime container because
# stage 2 does `COPY . /app/` which includes the mobile/ subdirectory.
_APP_JSON_PATH = "/app/mobile/app.json"
_PKG_JSON_PATH = "/app/mobile/package.json"

# Module-level caches so config files are read once per container lifetime.
_app_config_cache: dict = None   # type: ignore[assignment]
_runtime_version_cache: str = None  # type: ignore[assignment]


def _load_app_files():
    """Read app.json and package.json from the mobile app directory.

    Returns (expo_config: dict, sdk_major: str).  Never raises — falls
    back to empty dict / "54" so the manifest is always synthesisable.
    """
    import re as _re
    expo_config: dict = {}
    sdk_major = "54"

    try:
        with open(_APP_JSON_PATH, encoding="utf-8") as f:
            raw = json.load(f)
        # Support both {expo: {...}} wrapper and flat format.
        expo_config = raw.get("expo", raw)
    except Exception as e:
        print(f"[mobile] app.json read failed ({e}); using empty expoClient",
              file=sys.stderr, flush=True)

    try:
        with open(_PKG_JSON_PATH, encoding="utf-8") as f:
            pkg = json.load(f)
        expo_dep = pkg.get("dependencies", {}).get("expo", "~54.0.0")
        m = _re.search(r"(\d+)", expo_dep)
        if m:
            sdk_major = m.group(1)
    except Exception as e:
        print(f"[mobile] package.json read failed ({e}); defaulting to SDK {sdk_major}",
              file=sys.stderr, flush=True)

    return expo_config, sdk_major


def _get_runtime_version() -> str:
    """Return the runtimeVersion that matches the installed Expo Go runtime.

    Expo Go validates that the manifest's runtimeVersion equals its own
    native runtime string (e.g. "exposdk:54.0.0" for SDK 54 Expo Go).
    A mismatch causes Expo Go to immediately reject the update and close.

    Priority:
      1. Explicit runtimeVersion string in app.json  (e.g. "1.0.0" won't
         work with Expo Go — only use this if you know what you're doing)
      2. "exposdk:<major>.0.0" derived from the expo package version in
         package.json  (correct for standard Expo Go installations)
      3. Hardcoded "exposdk:54.0.0" if neither file is readable.
    """
    global _runtime_version_cache
    if _runtime_version_cache is None:
        expo_config, sdk_major = _load_app_files()
        explicit = expo_config.get("runtimeVersion")
        if explicit and isinstance(explicit, str):
            _runtime_version_cache = explicit
        else:
            _runtime_version_cache = f"exposdk:{sdk_major}.0.0"
        print(f"[mobile] runtimeVersion resolved to: {_runtime_version_cache}",
              file=sys.stderr, flush=True)
    return _runtime_version_cache


def _get_expo_client_config() -> dict:
    """Return app.json's expo config for the manifest's extra.expoClient field.

    Expo Go reads extra.expoClient to populate Constants.expoConfig.
    Without it, any code that touches Constants.expoConfig (navigation
    schemes, status bar, splash, etc.) gets null and may crash immediately.
    """
    global _app_config_cache
    if _app_config_cache is None:
        expo_config, _ = _load_app_files()
        _app_config_cache = expo_config
    return _app_config_cache


# ── Marker / state helpers ───────────────────────────────────────────────

def is_unavailable() -> bool:
    """True when Cloud Build stage 1 wrote the UNAVAILABLE marker."""
    return os.path.exists(UNAVAILABLE_MARKER)


def _read_unavailable_reason() -> str:
    """Read the failure reason JSON written by stage 1, or fallback string."""
    try:
        with open(UNAVAILABLE_MARKER, encoding="utf-8") as f:
            return json.load(f).get("reason", "unknown")
    except Exception:
        return "marker present but unreadable"


def _read_metadata() -> dict:
    """Read mobile-dist/metadata.json (input to manifest synthesis).

    NOTE: this is `expo export`'s output metadata, NOT the Expo Updates
    manifest we synthesize and return. The shape of THIS file may vary
    slightly across Expo SDK versions; manifest synthesis below adapts.
    """
    if not os.path.exists(METADATA_PATH):
        raise FileNotFoundError(f"metadata.json missing at {METADATA_PATH}")
    with open(METADATA_PATH, encoding="utf-8") as f:
        return json.load(f)


# ── Manifest synthesis (Expo Updates v1) ─────────────────────────────────

def _expo_hash(rel_path: str) -> str:
    """base64url(SHA-256(file bytes)) with no padding.

    Required by Expo Go's native iOS updates client (EXUpdates), which
    force-unwraps `hash` on launchAsset/assets and crashes with
    NSInternalInconsistencyException ('Value for (key = hash) is null')
    if it is absent. Computed over the exact bytes serve_static returns.
    """
    import hashlib as _hashlib, base64 as _base64
    abs_path = os.path.join(MOBILE_DIST, rel_path)
    h = _hashlib.sha256()
    with open(abs_path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return _base64.urlsafe_b64encode(h.digest()).decode("ascii").rstrip("=")


def _expo_client_required_fields(expo_client: dict, runtime_version: str) -> dict:
    """MOBILE_EXPOCLIENT_FIELDS_V2 — return a COPY of expo_client with the
    classic-manifest fields Expo Go's native parser force-unwraps.

    Expo Go reads extra.expoClient (legacy/classic shape) and throws
    'Failed to parse manifest JSON: Value for (key = X) is null' when any of
    these are absent. We supply sane defaults derived from slug/runtimeVersion.
    Only fills missing keys — never overwrites values already present.
    """
    out = dict(expo_client)
    slug = out.get("slug") or out.get("name") or "app"
    # sdkVersion: bare '<major>.0.0' from runtimeVersion ('exposdk:54.0.0').
    if not out.get("sdkVersion"):
        rv = runtime_version or ""
        if rv.startswith("exposdk:"):
            out["sdkVersion"] = rv.split(":", 1)[1]
        elif rv and all(p.isdigit() for p in rv.split(".")):
            out["sdkVersion"] = rv
        else:
            out["sdkVersion"] = "54.0.0"
    # scopeKey: per-app scoping id. '@anonymous/<slug>' for unowned previews.
    full_name = f"@anonymous/{slug}"
    out.setdefault("scopeKey", full_name)
    # id / fullName fields the classic parser also reads for scoping.
    out.setdefault("id", full_name)
    out.setdefault("currentFullName", full_name)
    out.setdefault("originalFullName", full_name)
    return out


def _synthesize_manifest(host: str, scheme: str, platform: str,
                         runtime_version_override: str = None) -> dict:
    """Build Expo Updates v1 manifest from expo export's metadata.json.

    Spec: https://docs.expo.dev/technical-specs/expo-updates-1/#manifest-body

    Required fields per spec:
      id (UUID), createdAt (ISO8601), runtimeVersion (string),
      launchAsset (Asset), assets (Asset[]),
      metadata ({[key]: string}), extra ({[key]: any})

    Asset required fields: key (string), contentType (string), url (string)
    Asset optional: hash (base64url SHA-256), fileExtension (must start with ".")

    runtime_version_override: when set, used instead of the value from app.json.
    Expo Go sends its own SDK version as `expo-runtime-version` in the request;
    echoing it back ensures the match always succeeds regardless of which Expo Go
    SDK version the user has installed.
    """
    meta = _read_metadata()
    base = f"{scheme}://{host}/mobile"

    # Pick the platform's bundle/assets section. expo export's metadata.json
    # uses `fileMetadata.<platform>` per spec.
    fm = meta.get("fileMetadata", {})
    if platform not in fm:
        raise ValueError(
            f"No bundle for platform {platform!r} "
            f"(available: {sorted(fm.keys())})"
        )
    pdata = fm[platform]

    # launchAsset: per spec, fileExtension is OPTIONAL on launchAsset and
    # generally omitted (it's a JS bundle, contentType conveys the type).
    launch_bundle_path = pdata.get("bundle", "")
    if not launch_bundle_path:
        raise ValueError(
            f"metadata.json fileMetadata.{platform} has no 'bundle' field — "
            f"cannot synthesize manifest"
        )
    launch_asset = {
        "key": "main-bundle",
        "contentType": "application/javascript",
        "url": f"{base}/{launch_bundle_path}",
        "hash": _expo_hash(launch_bundle_path),
    }

    # assets: each must have key, contentType, url; fileExtension MUST start
    # with "." if present.
    assets = []
    for a in pdata.get("assets", []):
        # Skip malformed asset entries (missing path) — better than crashing
        # the whole manifest synthesis.
        path = a.get("path", "")
        if not path:
            continue
        # Defensive: lowercase ext for case-insensitive matching against
        # known image/font extensions.
        ext = (a.get("ext", "") or "").lower()
        ext_with_dot = f".{ext}" if ext and not ext.startswith(".") else ext

        if ext in ("png", "jpg", "jpeg", "gif", "webp"):
            content_type = f"image/{'jpeg' if ext == 'jpg' else ext}"
        elif ext in ("ttf", "otf"):
            content_type = f"font/{ext}"
        else:
            content_type = "application/octet-stream"

        asset_obj = {
            "key": path,
            "contentType": content_type,
            "url": f"{base}/{path}",
            "hash": _expo_hash(path),
        }
        if ext_with_dot:
            asset_obj["fileExtension"] = ext_with_dot
        assets.append(asset_obj)

    runtime_version = runtime_version_override or _get_runtime_version()
    return {
        "id": str(uuid.uuid4()),
        "createdAt": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
        "runtimeVersion": runtime_version,
        "launchAsset": launch_asset,
        "assets": assets,
        # Per spec, both required.
        "metadata": {},
        # expoClient is read by Expo Go to populate Constants.expoConfig.
        # Without it the app has no name/scheme/orientation config and
        # crashes immediately after the bundle executes.
        # MOBILE_SDKVERSION_INJECT_V1
        # Expo Go validates compatibility from expoClient.sdkVersion. If
        # absent it fetches the manifest (200) then refuses the bundle with
        # "Incompatible SDK version or no SDK version specified". Inject a
        # bare "<major>.0.0" derived from runtimeVersion. Copy first so the
        # module-level _app_config_cache is never mutated.
        "extra": {
            "expoClient": _expo_client_required_fields(
                _get_expo_client_config(), runtime_version
            ),
        },
    }


# ── Handler functions (called from _Handler.do_GET) ──────────────────────

def _set_expo_response_headers(handler):
    """Set required Expo Updates v1 protocol response headers.

    Per spec section "Common response headers":
      expo-protocol-version: 1
      expo-sfv-version: 0
    """
    handler.send_header("expo-protocol-version", "1")
    handler.send_header("expo-sfv-version", "0")
    handler.send_header("Cache-Control", "private, max-age=0")
    handler.send_header("Access-Control-Allow-Origin", "*")


def _send_json(handler, status: int, body: dict, expo_headers: bool = False):
    """Send a JSON response. If expo_headers=True, add Expo protocol headers."""
    payload = json.dumps(body).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(payload)))
    if expo_headers:
        _set_expo_response_headers(handler)
    handler.end_headers()
    handler.wfile.write(payload)


def serve_health(handler):
    """GET /mobile/health → { ok, available, reason?, platforms?, dist? }."""
    if is_unavailable():
        _send_json(handler, 200, {
            "ok": True,
            "available": False,
            "reason": _read_unavailable_reason(),
        })
        return

    try:
        meta = _read_metadata()
    except FileNotFoundError as e:
        # Mobile claims to be available (no UNAVAILABLE marker) but
        # metadata.json is missing — surface clearly so ops can debug.
        print(f"[mobile] serve_health: {e}", file=sys.stderr)
        _send_json(handler, 200, {
            "ok": False,
            "available": False,
            "error": str(e),
        })
        return
    except Exception as e:
        print(f"[mobile] serve_health metadata.json error: {e}", file=sys.stderr)
        _send_json(handler, 500, {
            "ok": False,
            "available": False,
            "error": f"metadata.json read error: {e}",
        })
        return

    _send_json(handler, 200, {
        "ok": True,
        "available": True,
        "platforms": sorted(meta.get("fileMetadata", {}).keys()),
        "dist": MOBILE_DIST,
    })


def _build_multipart_manifest_response(manifest: dict):
    """Wrap an Expo Updates v1 manifest in a multipart/mixed body.

    Expo Go SDK 50+ sends `expo-protocol-version: 1` and expects the
    response to be `multipart/mixed` with a 'manifest' part — NOT plain
    application/json. With plain JSON, Expo Go fetches the manifest,
    fails to parse as multipart, and silently bails (no bundle fetch,
    no error screen). The misleading part is that the spec says
    "content-type MUST be application/json" — that refers to the inner
    manifest part, not the outer response.

    Reference: https://docs.expo.dev/technical-specs/expo-updates-1/
    Reference impl: github.com/expo/custom-expo-updates-server

    Returns (content_type_header_value, body_bytes).
    """
    import secrets
    boundary = "supero-" + secrets.token_hex(16)
    manifest_json = json.dumps(manifest)
    extensions_json = json.dumps({})

    # Per Expo Updates v1 spec and the official reference implementation
    # (github.com/expo/custom-expo-updates-server), the manifest part MUST
    # use Content-Disposition: inline (NOT form-data). Expo Go's native
    # multipart parser is spec-strict: with `form-data` it cannot find the
    # "manifest" named part, silently bails, never fetches the bundle, and
    # the app terminates immediately after scanning the QR. Headers also
    # MUST use ASCII title-case (Content-Disposition, Content-Type).
    parts = []
    parts.append(f"--{boundary}\r\n")
    parts.append('Content-Disposition: inline; name="manifest"\r\n')
    parts.append("Content-Type: application/json\r\n")
    parts.append("\r\n")
    parts.append(manifest_json)
    parts.append("\r\n")

    parts.append(f"--{boundary}\r\n")
    parts.append('Content-Disposition: inline; name="extensions"\r\n')
    parts.append("Content-Type: application/json\r\n")
    parts.append("\r\n")
    parts.append(extensions_json)
    parts.append("\r\n")

    parts.append(f"--{boundary}--\r\n")

    body = "".join(parts).encode("utf-8")
    content_type = f"multipart/mixed; boundary={boundary}"
    return content_type, body


def serve_manifest(handler):
    """GET /mobile/manifest.json → Expo Updates v1 manifest.

    Platform comes from `expo-platform` header (per spec). Falls back
    to ?platform= query param so curl/diagnostics still work.
    """
    if is_unavailable():
        _send_json(handler, 503, {
            "unavailable": True,
            "reason": _read_unavailable_reason(),
        }, expo_headers=True)
        return

    # Per Expo Updates v1 spec: platform is an HTTP header.
    # Headers are case-insensitive; BaseHTTPRequestHandler.headers handles that.
    platform_header = handler.headers.get("expo-platform") or ""
    platform_query = ""
    if "?" in handler.path:
        # Cheap query parse — we only need ?platform=...
        from urllib.parse import urlparse, parse_qs
        qs = parse_qs(urlparse(handler.path).query)
        platform_query = (qs.get("platform") or [""])[0]

    platform = (platform_header or platform_query or "ios").lower()
    if platform not in ("ios", "android"):
        _send_json(handler, 400, {
            "error": f"unsupported platform: {platform!r}",
        }, expo_headers=True)
        return

    host = (
        handler.headers.get("X-Forwarded-Host")
        or handler.headers.get("Host")
        or "localhost"
    )
    # Cloud Run terminates TLS at the load balancer and forwards
    # X-Forwarded-Proto. Default to https since Expo Go requires it
    # for non-localhost URLs. Validate to prevent attacker-controlled
    # weird schemes from polluting our manifest URLs.
    scheme = handler.headers.get("X-Forwarded-Proto", "https").lower().strip()
    if scheme not in ("http", "https"):
        scheme = "https"

    # Expo Go sends its own runtime version in the request header.
    # The manifest's runtimeVersion MUST match exactly or Expo Go's native
    # updates client immediately rejects the manifest and closes the app
    # (no JS error screen — native-level rejection).
    # For Cloud Run preview builds the bundle is pure JS running inside
    # Expo Go, so it is compatible with any Expo Go SDK version. We echo
    # the client's declared version back so the match always succeeds.
    client_runtime_version = handler.headers.get("expo-runtime-version", "").strip()
    print(
        f"[mobile] manifest request: host={host!r} scheme={scheme!r} "
        f"platform={platform!r} client-runtime-version={client_runtime_version!r}",
        file=sys.stderr, flush=True,
    )

    try:
        manifest = _synthesize_manifest(host, scheme, platform,
                                        runtime_version_override=client_runtime_version or None)
    except FileNotFoundError as e:
        _send_json(handler, 503, {"error": str(e)}, expo_headers=True)
        return
    except ValueError as e:
        _send_json(handler, 404, {"error": str(e)}, expo_headers=True)
        return
    except Exception as e:
        print(f"[mobile] manifest synthesis failed: {e}", file=sys.stderr)
        _send_json(handler, 500, {
            "error": f"Manifest synthesis failed: {e}",
        }, expo_headers=True)
        return

    # Per Expo Updates v1 spec, the response MUST be multipart/mixed for
    # protocol-version: 1 (sent by every Expo Go SDK 50+). Plain JSON is
    # silently rejected by the client. The inner manifest *part* is
    # application/json — that's what the spec means.
    content_type, body = _build_multipart_manifest_response(manifest)
    handler.send_response(200)
    handler.send_header("Content-Type", content_type)
    handler.send_header("Content-Length", str(len(body)))
    _set_expo_response_headers(handler)
    handler.end_headers()
    handler.wfile.write(body)


def serve_static(handler, rel_path: str):
    """GET /mobile/<rel_path> → file from MOBILE_DIST.

    Covers _expo/<...> bundle paths and assets/<...> asset paths both.
    """
    if is_unavailable():
        _send_json(handler, 503, {"error": "Mobile bundle unavailable"})
        return

    # Strip query string if present
    if "?" in rel_path:
        rel_path = rel_path.split("?", 1)[0]

    # Path safety — disallow traversal
    if (
        not rel_path
        or rel_path.startswith("/")
        or ".." in rel_path.split("/")
        or "\x00" in rel_path
    ):
        _send_json(handler, 400, {"error": "Invalid path"})
        return

    full_path = os.path.join(MOBILE_DIST, rel_path)
    # Defense-in-depth: resolve and confirm we didn't escape MOBILE_DIST.
    real_full = os.path.realpath(full_path)
    real_root = os.path.realpath(MOBILE_DIST)
    if not real_full.startswith(real_root + os.sep) and real_full != real_root:
        _send_json(handler, 400, {"error": "Path escapes mobile-dist"})
        return

    if not os.path.isfile(real_full):
        _send_json(handler, 404, {"error": f"Not found: {rel_path}"})
        return

    # Content-Type from extension. .hbc (Hermes bytecode) is not registered in
    # the OS MIME database, so mimetypes returns None for it. Expo Go uses the
    # manifest's launchAsset.contentType ("application/javascript") to decide
    # how to execute the bundle — serving the HTTP header as application/octet-stream
    # creates a mismatch that some Expo Go versions reject. Use "application/javascript"
    # for any file under _expo/static/js/ regardless of extension.
    content_type, _ = mimetypes.guess_type(real_full)
    if not content_type:
        if "_expo/static/js/" in real_full.replace(os.sep, "/"):
            content_type = "application/javascript"
        else:
            content_type = "application/octet-stream"

    try:
        with open(real_full, "rb") as f:
            body = f.read()
    except OSError as e:
        # Log to stderr so Cloud Run captures it. Without this, ops sees
        # 500s with no explanation when serve_static fails.
        print(
            f"[mobile] serve_static read error for {rel_path!r}: {e}",
            file=sys.stderr,
        )
        _send_json(handler, 500, {"error": f"Read error: {e}"})
        return

    handler.send_response(200)
    handler.send_header("Content-Type", content_type)
    handler.send_header("Content-Length", str(len(body)))
    # Per spec: assets SHOULD have long cache-control with `immutable`
    handler.send_header("Cache-Control", "public, max-age=31536000, immutable")
    handler.send_header("Access-Control-Allow-Origin", "*")
    handler.end_headers()
    handler.wfile.write(body)

# MOBILE_DIAG_BC_HELPER_V1
# Diagnostics: shared summary helper, one-shot startup dump, /mobile/__diagnose.
# Imports are local to keep top-of-module clean and avoid touching existing imports.
def _build_diagnostics_summary():
    """Filesystem-only snapshot of mobile preview state. Cheap; no I/O outside /app."""
    import os as _os, json as _json, re as _re
    summary = {
        "MOBILE_DIST": MOBILE_DIST,
        "exists": _os.path.isdir(MOBILE_DIST),
        "unavailable_marker": is_unavailable(),
        "metadata_json": _os.path.isfile(METADATA_PATH),
        "expo_dir_exists": _os.path.isdir(_os.path.join(MOBILE_DIST, "_expo")),
        "runtime_version": _get_runtime_version(),
    }
    for plat in ("ios", "android"):
        d = _os.path.join(MOBILE_DIST, "_expo", "static", "js", plat)
        if _os.path.isdir(d):
            try:
                files = sorted(f for f in _os.listdir(d) if f.endswith(".hbc"))
            except OSError:
                files = []
            summary[f"{plat}_bundles"] = files
            for f in files:
                try:
                    summary[f"{plat}_size_{f}"] = _os.path.getsize(_os.path.join(d, f))
                except OSError:
                    pass
    appconfig = "/app/mobile/src/appConfig.ts"
    if _os.path.isfile(appconfig):
        try:
            with open(appconfig, encoding="utf-8") as f:
                content = f.read()
            for field in ("domain", "project", "serverUrl", "appName"):
                m = _re.search(rf"{field}:\s*[\'\"]([^\'\"]+)", content)
                if m:
                    summary[f"appConfig.{field}"] = m.group(1)
        except OSError as e:
            summary["appConfig.error"] = str(e)
    else:
        summary["appConfig.present"] = False
    return summary


def log_startup_diagnostics():
    """One-shot dump at server startup. Read by ops via gcloud logs."""
    import sys as _sys, json as _json
    try:
        s = _build_diagnostics_summary()
        print(f"[mobile][startup] {_json.dumps(s, sort_keys=True)}",
              file=_sys.stderr, flush=True)
    except Exception as e:
        print(f"[mobile][startup] diagnostics failed: {e}",
              file=_sys.stderr, flush=True)


def serve_diagnose(handler):
    """GET /mobile/__diagnose -> same payload as startup dump, on demand."""
    try:
        s = _build_diagnostics_summary()
    except Exception as e:
        _send_json(handler, 500, {"error": f"diagnose failed: {e}"})
        return
    _send_json(handler, 200, s)
# /MOBILE_DIAG_BC_HELPER_V1
