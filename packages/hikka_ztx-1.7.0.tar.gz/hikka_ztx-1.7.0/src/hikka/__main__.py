from __future__ import annotations

if __name__ == "__main__":
    from hikka.main import hikka

    hikka.main()
