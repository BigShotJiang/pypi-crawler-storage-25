"""Represents current userbot version"""
# ©️ Dan Gazizullin, 2021-2023
# This file is a part of Hikka Userbot
# 🌐 https://github.com/hikariatama/Hikka
# You can redistribute it and/or modify it under the terms of the GNU AGPLv3
# 🔑 https://www.gnu.org/licenses/agpl-3.0.html

from __future__ import annotations

from packaging.version import Version

from ._internal import get_metadata

__raw_version__ = Version(get_metadata()["version"])
__version__ = __raw_version__.release
branch = "master"
