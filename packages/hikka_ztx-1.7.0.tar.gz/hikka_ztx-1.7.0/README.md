Modification of [Hikka by hikariatama](https://github.com/hikariatama/Hikka). 

---

## install:
```bash
uv tool install hikka-ztx
```
run
```bash
hikka
```
or
```bash
uv venv hikka-venv
uv pip install --directory hikka-venv hikka-ztx
```
run:
```bash
hikka-venv/bin/hikka
```