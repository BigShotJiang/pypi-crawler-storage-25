"""StageWhisper plugin for Hermes Agent.

Provides:
- Tools: stagewhisper_pair, stagewhisper_relay, stagewhisper_unpair
- CLI:  stagewhisper-hermes pair|unpair|status|start|stop|restart
- Auto-start relay on plugin load when configured

Install: pipx run --spec hermes-plugin-stagewhisper stagewhisper-hermes-install
(A plugin directory at ~/.hermes/plugins/stagewhisper/)
"""

from __future__ import annotations

import asyncio
import logging
import threading
from inspect import signature

logger = logging.getLogger(__name__)

_relay_thread: threading.Thread | None = None
_relay_loop: asyncio.AbstractEventLoop | None = None
_relay_lock = threading.Lock()


def register(ctx) -> None:
    from . import schemas
    from .cli import _handle_command, _setup_argparse

    _register_tool(ctx, "stagewhisper_pair", schemas.STAGEWHISPER_PAIR, _handle_pair)
    _register_tool(ctx, "stagewhisper_relay", schemas.STAGEWHISPER_RELAY, _handle_relay)
    _register_tool(ctx, "stagewhisper_unpair", schemas.STAGEWHISPER_UNPAIR, _handle_unpair)

    if hasattr(ctx, "register_cli_command"):
        ctx.register_cli_command(
            "stagewhisper",
            "Manage StageWhisper BYO AI relay",
            _setup_argparse,
            _handle_command,
        )

    _start_relay_when_paired()


def _register_tool(ctx, name: str, schema: dict, handler) -> None:
    try:
        params = signature(ctx.register_tool).parameters
    except (TypeError, ValueError):
        params = {}

    if "toolset" in params:
        ctx.register_tool(name, "stagewhisper", schema, handler)
        return

    try:
        ctx.register_tool(name, schema, handler)
    except TypeError as exc:
        try:
            ctx.register_tool(
                name=name,
                toolset="stagewhisper",
                schema=schema,
                handler=handler,
            )
        except TypeError:
            raise exc


def _handle_pair(args: dict, **kwargs) -> str:
    from .tools import stagewhisper_pair

    return stagewhisper_pair(
        code=args.get("code", ""),
        label=args.get("label", "StageWhisper"),
        api_url=args.get("api_url"),
    )


def _handle_relay(args: dict, **kwargs) -> str:
    from .tools import stagewhisper_relay

    return stagewhisper_relay(action=args.get("action", "status"))


def _handle_unpair(args: dict, **kwargs) -> str:
    from .tools import stagewhisper_unpair

    return stagewhisper_unpair()


def _start_relay_when_paired() -> None:
    try:
        from .config import is_paired

        if not is_paired():
            logger.info("StageWhisper not paired — relay will not auto-start")
            return

        _spawn_relay_thread()
    except Exception as exc:
        logger.warning("StageWhisper relay auto-start skipped: %s", exc)


def _spawn_relay_thread() -> None:
    global _relay_thread, _relay_loop

    with _relay_lock:
        if _relay_thread and _relay_thread.is_alive():
            logger.info("StageWhisper relay thread already running")
            return

        ready = threading.Event()

        def _run() -> None:
            global _relay_loop
            from .relay.service import relay_service

            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            _relay_loop = loop
            try:
                loop.run_until_complete(relay_service.start())
                ready.set()
                loop.run_forever()
            except Exception as exc:
                logger.exception("StageWhisper relay thread crashed: %s", exc)
            finally:
                ready.set()
                try:
                    loop.run_until_complete(relay_service.stop())
                except Exception:
                    pass
                loop.close()
                _relay_loop = None

        thread = threading.Thread(
            target=_run, daemon=True, name="stagewhisper-relay"
        )
        thread.start()
        _relay_thread = thread
        ready.wait(timeout=10)
        logger.info("StageWhisper relay thread started")
