"""
This module was getted from the babi text editor:
https://github.com/asottile/babi/blob/main/babi/horizontal_scrolling.py
"""

from __future__ import annotations

import curses
from bisect import bisect_right
from functools import cached_property


def line_x(x: int, width: int) -> int:
    if x + 1 < width:
        return 0
    elif width == 1:
        return x
    else:
        margin = min(width - 3, 6)
        return (
            width
            - margin
            - 2
            + (x + 1 - width) // (width - margin - 2) * (width - margin - 2)
        )


class _CalcWidth:
    @cached_property
    def _window(self) -> curses.window:
        return curses.newwin(1, 10)

    def wcwidth(self, c: str) -> int:
        self._window.addstr(0, 0, c)
        return self._window.getyx()[1]


wcwidth = _CalcWidth().wcwidth
del _CalcWidth


def get_offsets(line, tab_size: int) -> tuple[int, ...]:
    """
    Return visual screen-cell offsets for every character boundary.

    offsets[i] = visual column before character i
    offsets[len(line)] = total visual width

    Supports RichString._width_cache when available.
    """
    cached = getattr(line, "_width_cache", None)
    if cached is not None:
        return cached

    offsets = [0]
    x = 0

    for c in line:
        if c == "\t":
            x += tab_size - (x % tab_size)
        else:
            w = wcwidth(c)
            if w > 0:
                x += w

        offsets.append(x)

    result = tuple(offsets)

    try:
        line._width_cache = result
    except AttributeError:
        pass

    return result


def visual_x(line, char_index: int, tab_size: int) -> int:
    """
    Convert character index to terminal screen-cell column.
    """
    char_index = max(0, min(char_index, len(line)))
    return get_offsets(line, tab_size)[char_index]


def char_width(c: str) -> int:
    """
    Return terminal display width for one character.

    Normal ASCII      -> 1
    Wide Unicode      -> 2
    Combining marks   -> 0
    Control chars     -> 0

    Tabs are NOT handled here because tab width depends on the current
    visual column. Use char_display_width() for tabs.
    """
    if not c:
        return 0

    w = wcwidth(c)

    if w <= 0:
        return 0

    return w


def char_display_width(c: str, visual_x: int, tab_size: int) -> int:
    """
    Return how many screen cells this character occupies at visual_x.

    This is needed because tabs depend on the current visual column.
    """
    if c == "\t":
        return tab_size - (visual_x % tab_size)

    return char_width(c)


def visual_to_logical_x(line, target_visual_x: int, tab_size: int) -> int:
    """
    Convert terminal screen-cell column to logical character index.

    This is the inverse operation of visual_x().

    Use this for mouse clicks.

    Example:

        line = "\\tab"
        tab_size = 4

        visual columns:

            0 1 2 3 4 5
            [ tab ] a b

        Clicking inside the tab area will return either index 0 or 1
        depending on which side of the visual midpoint was clicked.
    """
    if target_visual_x <= 0:
        return 0

    offsets = get_offsets(line, tab_size)
    line_len = len(line)

    if line_len == 0:
        return 0

    total_width = offsets[-1]

    if target_visual_x >= total_width:
        return line_len

    # Find the character span containing target_visual_x.
    #
    # offsets[i] <= target_visual_x < offsets[i + 1]
    i = bisect_right(offsets, target_visual_x) - 1
    i = max(0, min(i, line_len - 1))

    start = offsets[i]
    end = offsets[i + 1]

    # Zero-width characters can produce equal offsets.
    # Skip over them safely.
    while i < line_len - 1 and end == start:
        i += 1
        start = offsets[i]
        end = offsets[i + 1]

    width = end - start

    if width <= 0:
        return i

    midpoint = start + (width / 2)

    if target_visual_x < midpoint:
        return i

    return i + 1


def visual_line_width(line, tab_size: int) -> int:
    """
    Return total visual terminal width of the line.
    """
    return get_offsets(line, tab_size)[-1]
