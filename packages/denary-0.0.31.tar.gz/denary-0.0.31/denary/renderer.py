from __future__ import annotations

import curses
from bisect import bisect_left, bisect_right
from collections import defaultdict
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Callable, Iterable, Optional, cast

from denary import config
from denary.buf import Buffer, RichString
from denary.config import MAX_SCAN_LINES
from denary.horizontal_scrolling import line_x, wcwidth
from denary.key_mappings import BRACKET_PAIRS, BRACKETS, REVERSE_BRACKET_PAIRS
from denary.syntax import hilighing

if TYPE_CHECKING:
    from denary.editor import SimpleEditor
    from denary.windows import BufferWindow


@dataclass(slots=True)
class DrawContext:
    editor: SimpleEditor
    stdscr: curses.window
    window: BufferWindow
    buffer: Buffer
    cp: Callable[[int], int]

    # Local pane dimensions.
    width: int
    height: int

    top: int
    bottom: int
    len_buffer_lines: int
    max_width: int
    tab_size: int
    width_len_buffer_lines: int

    normal: int
    red_trailing: int
    sel_attr: int

    match: Optional[tuple[tuple[int, int], tuple[int, int]]] = None
    current_gutter: int = 0


@dataclass(slots=True)
class LineContext:
    ctx: DrawContext
    line: RichString
    screen_row: int
    line_no: int
    offsets: tuple[int, ...]
    visual_width: int
    gutter_width: int
    line_width: int
    start_i: int
    end_i: int
    slice_text: str
    visible_cells_used: int
    marker_x: int


def get_offsets(line: RichString, tab_size: int) -> tuple[int, ...]:
    if line._width_cache is not None:
        return line._width_cache

    offsets = [0]
    x = 0

    for c in line:
        if c == "\t":
            spaces = tab_size - (x % tab_size)
            x += spaces
        else:
            w = wcwidth(c)
            if w < 0:
                w = 0
            x += w

        offsets.append(x)

    line._width_cache = tuple(offsets)
    return line._width_cache


def render_slice(
    line: RichString,
    h_scroll: int,
    line_width: int,
    offsets: tuple[int, ...],
    tab_size: int,
) -> tuple[str, int]:
    """
    Render the visible part of a line using terminal screen cells.

    Returns:
        tuple[str, int]:
            - rendered text
            - number of terminal cells used by that rendered text

    Why this exists:
        Python slicing and len() are character/codepoint based, but curses draws using
        terminal cells. Tabs, CJK characters, emojis, and combining characters can all
        make len(text) different from the number of cells occupied on screen.
    """
    if line_width <= 0 or not line:
        return "", 0

    visible_left = h_scroll
    visible_right = h_scroll + line_width

    result: list[str] = []
    cells_used = 0

    # Start at the character that owns visible_left. This is important when the
    # viewport starts inside a tab or inside a wide character.
    i = max(0, bisect_right(offsets, visible_left) - 1)

    while i < len(line) and cells_used < line_width:
        ch_start = offsets[i]
        ch_end = offsets[i + 1]

        if ch_end <= visible_left:
            i += 1
            continue

        if ch_start >= visible_right:
            break

        c = line[i]

        draw_start = max(ch_start, visible_left)
        draw_end = min(ch_end, visible_right)
        visible_cells = draw_end - draw_start

        if visible_cells <= 0:
            i += 1
            continue

        if c == "\t":
            # A tab can be partially visible. Render only the visible cells as spaces.
            result.append(" " * visible_cells)
            cells_used += visible_cells
        else:
            char_cells = ch_end - ch_start

            if char_cells <= 0:
                # Zero-width / combining character. Include it only when its logical
                # column is visible. It does not advance cells_used.
                if visible_left <= ch_start < visible_right:
                    result.append(c)
            elif ch_start >= visible_left and ch_end <= visible_right:
                # Fully visible character. Safe to draw.
                result.append(c)
                cells_used += char_cells
            else:
                # The viewport cuts through this character. Terminals cannot draw
                # half of a wide character, so use spaces to keep the following text
                # aligned to the real screen columns.
                result.append(" " * visible_cells)
                cells_used += visible_cells

        i += 1

    return "".join(result), cells_used


def get_brackets(line: RichString) -> list[tuple[int, str]]:
    if line._bracket_cache is None:
        line._bracket_cache = [(i, c) for i, c in enumerate(line) if c in BRACKETS]

    return line._bracket_cache


def find_matching_bracket(
    lines,
    y,
    x,
) -> Optional[tuple[tuple[int, int], tuple[int, int]]]:
    if y < 0 or y >= len(lines):
        return None

    line = lines[y]
    if not line:
        return None

    if x <= 0 or x > len(line):
        return None

    c = line[x - 1]
    cx = x - 1

    if c not in BRACKETS:
        return None

    bracket_pairs = BRACKET_PAIRS
    reverse_pairs = REVERSE_BRACKET_PAIRS
    getb = get_brackets
    lines_len = len(lines)

    if c in bracket_pairs:
        target = bracket_pairs[c]
        depth = 1

        max_y = min(lines_len, y + MAX_SCAN_LINES)

        yy = y
        xx = cx + 1

        while yy < max_y:
            line = lines[yy]
            brackets = getb(line)

            if brackets:
                for pos, ch in brackets:
                    if yy == y and pos < xx:
                        continue

                    if ch == c:
                        depth += 1
                    elif ch == target:
                        depth -= 1
                        if depth == 0:
                            return (y, cx), (yy, pos)

            yy += 1
            xx = 0

    else:
        target = reverse_pairs[c]
        depth = 1

        min_y = max(0, y - MAX_SCAN_LINES)

        yy = y
        xx = cx - 1

        while yy >= min_y:
            line = lines[yy]
            brackets = getb(line)

            if brackets:
                i = len(brackets) - 1

                if yy == y:
                    while i >= 0 and brackets[i][0] > xx:
                        i -= 1

                while i >= 0:
                    pos, ch = brackets[i]

                    if ch == c:
                        depth += 1
                    elif ch == target:
                        depth -= 1
                        if depth == 0:
                            return (yy, pos), (y, cx)

                    i -= 1

            yy -= 1
            if yy >= 0:
                xx = len(lines[yy]) - 1

    return None


def draw(editor: SimpleEditor, window: BufferWindow) -> None:
    if window.win is None:
        return

    ctx = build_draw_context(editor, window)

    update_horizontal_scroll(ctx)
    prepare_syntax_highlighting(ctx)

    search_by_line = build_search_highlights(ctx)
    best_diag = build_best_diagnostics(ctx)
    completions_by_line = build_completions_by_line(ctx)
    selection = get_normalized_selection(ctx)

    # begin_screen_draw(ctx)

    draw_visible_lines(
        ctx=ctx,
        search_by_line=search_by_line,
        best_diag=best_diag,
        completions_by_line=completions_by_line,
        selection=selection,
    )

    draw_status_bar(ctx)
    draw_cursor(ctx)
    # finish_screen_draw(ctx)


def build_draw_context(
    editor: SimpleEditor,
    window: BufferWindow,
) -> DrawContext:
    stdscr = window.win

    if stdscr is None:
        raise RuntimeError("Cannot build draw context without a curses window.")

    cp = curses.color_pair

    buffer = editor.buffers[window._current_buffer]

    # window.viewport

    # Important:
    # window.win is the inner drawable pane.
    # Do not use window.rect dimensions here when using borders,
    # because window.rect includes the outer frame.
    # height, width = stdscr.getmaxyx()
    height, width = window.viewport_height, window.viewport_width

    width = max(1, width)
    height = max(1, height)

    top = window.scroll
    len_buffer_lines = len(buffer.lines)

    # Last local row is reserved for this pane's status bar.
    bottom = min(len_buffer_lines, top + height - 1)

    match = None
    if config.STATIC_CONFIG.get("brkm", False):
        match = find_matching_bracket(
            buffer.lines,
            window.cursor_y,
            window.cursor_x,
        )

    return DrawContext(
        editor=editor,
        stdscr=stdscr,
        buffer=buffer,
        window=window,
        cp=cp,
        width=width,
        height=height,
        top=top,
        bottom=bottom,
        len_buffer_lines=len_buffer_lines,
        max_width=width - 1,
        tab_size=buffer.tab_size,
        width_len_buffer_lines=len(str(len_buffer_lines)),
        normal=cp(1),
        red_trailing=cp(15),
        sel_attr=cp(31),
        match=match,
    )


def update_horizontal_scroll(ctx: DrawContext) -> None:
    """
    Keep gutter information updated for this draw.

    Horizontal scroll is now window-local and should already be adjusted
    by editor.adjust_scroll() using window.h_scroll.

    Do not write to buffer.h_scroll here.
    """

    editor = ctx.editor
    buffer = ctx.buffer
    window = ctx.window

    if not (ctx.top <= window.cursor_y < ctx.bottom):
        return

    cursor_y_screen = window.cursor_y - window.scroll

    if editor.gutter_render and 0 <= cursor_y_screen < ctx.height - 1:
        ctx.current_gutter = editor.gutter_render(
            ctx.stdscr,
            cursor_y_screen,
            window.cursor_y,
            buffer,
            ctx.width_len_buffer_lines,
        )

    window.current_gutter_width = (
        0 if ctx.current_gutter <= 0 else ctx.current_gutter - 2
    )


def prepare_syntax_highlighting(ctx: DrawContext) -> None:
    hilighing.highlight_with_pygments(
        buffer=ctx.buffer,
        window=ctx.window,
    )


def build_search_highlights(ctx: DrawContext):
    editor = ctx.editor
    buffer = ctx.buffer
    window = ctx.window

    if editor.disable_search or not editor.last_search:
        return None

    search_by_line = defaultdict(list)

    use_regex = editor.last_search_re is not None
    needle = editor.last_search.lower() if not use_regex else None
    h_scroll = window.h_scroll

    for y in range(ctx.top, ctx.bottom):
        line = buffer.lines[y]
        offsets = get_offsets(line, ctx.tab_size)
        visual_width = offsets[-1]

        if h_scroll >= visual_width:
            continue

        if editor.last_search_re is not None:
            matches: Iterable[Any] = editor.last_search_re.finditer(line)
        else:
            matches = find_plain_text_matches(line, needle or "")

        for m in matches:
            if use_regex:
                a = m.start()
                b = m.end()
            else:
                a, b = cast(tuple[int, int], m)

            if not is_span_visible(
                start=a,
                end=b,
                offsets=offsets,
                visual_width=visual_width,
                h_scroll=h_scroll,
                line_width=ctx.max_width,
            ):
                continue

            search_by_line[y].append(
                hilighing.HilightedLine(
                    y=y,
                    start=a,
                    end=b,
                    attr=21,
                )
            )

    return search_by_line


def find_plain_text_matches(line: str, needle: str) -> list[tuple[int, int]]:
    if needle == "":
        return []

    matches = []
    text = line.lower()
    i = 0

    while True:
        pos = text.find(needle, i)
        if pos < 0:
            break

        matches.append((pos, pos + len(needle)))
        i = pos + len(needle)

    return matches


def is_span_visible(
    *,
    start: int,
    end: int,
    offsets: tuple[int, ...],
    visual_width: int,
    h_scroll: int,
    line_width: int,
) -> bool:
    s = offsets[start] if start < len(offsets) else visual_width
    e = offsets[end] if end < len(offsets) else visual_width

    return not (e <= h_scroll or s >= h_scroll + line_width)


def build_best_diagnostics(ctx: DrawContext):
    if not ctx.buffer.diagnostics:
        return None

    diags_by_line = defaultdict(list)

    for d in ctx.buffer.diagnostics:
        if ctx.top <= d.line < ctx.bottom:
            diags_by_line[d.line].append(d)

    best_diag = {}

    for line_no, items in diags_by_line.items():
        items.sort(key=lambda d: d.severity, reverse=True)
        best_diag[line_no] = (items[0], len(items))

    return best_diag


def build_completions_by_line(ctx: DrawContext):
    if not ctx.buffer.ai_completions:
        return None

    return {
        c.line: c for c in ctx.buffer.ai_completions if ctx.top <= c.line < ctx.bottom
    }


def get_normalized_selection(ctx: DrawContext):
    editor = ctx.editor
    buffer = ctx.buffer
    window = ctx.window

    if ctx.window.selection_start is None:
        return None

    sy, sx = ctx.window.selection_start
    ey, ex = window.cursor_y, window.cursor_x

    if (sy, sx) > (ey, ex):
        sy, sx, ey, ex = ey, ex, sy, sx

    return sy, sx, ey, ex


def begin_screen_draw(ctx: DrawContext) -> None:
    try:
        curses.curs_set(0 if not ctx.editor.input_timeout else 1)
    except curses.error:
        pass


def finish_screen_draw(ctx: DrawContext) -> None:
    try:
        curses.curs_set(1)
    except curses.error:
        pass


def draw_visible_lines(
    *,
    ctx: DrawContext,
    search_by_line,
    best_diag,
    completions_by_line,
    selection,
) -> None:
    for screen_row, line_no in enumerate(range(ctx.top, ctx.bottom)):
        line_ctx = build_line_context(ctx, screen_row, line_no)

        if line_ctx is None:
            clear_editor_row(ctx, screen_row)
            continue

        draw_one_line(
            line_ctx=line_ctx,
            search_by_line=search_by_line,
            best_diag=best_diag,
            completions_by_line=completions_by_line,
            selection=selection,
        )

    # Clear editor rows that no longer correspond to buffer lines.
    # The status bar owns the last local row.
    first_unused_row = ctx.bottom - ctx.top
    for screen_row in range(first_unused_row, ctx.height - 1):
        clear_editor_row(ctx, screen_row)


def clear_editor_row(ctx: DrawContext, screen_row: int) -> None:
    try:
        ctx.stdscr.move(screen_row, 0)
        ctx.stdscr.clrtoeol()
    except curses.error:
        pass


def build_line_context(
    ctx: DrawContext,
    screen_row: int,
    line_no: int,
) -> Optional[LineContext]:
    editor = ctx.editor
    buffer = ctx.buffer
    window = ctx.window
    h_scroll = window.h_scroll

    line = buffer.lines[line_no]
    offsets = get_offsets(line, ctx.tab_size)
    visual_width = offsets[-1]

    gutter_width = ctx.current_gutter

    if editor.gutter_render:
        gutter_width = editor.gutter_render(
            ctx.stdscr,
            screen_row,
            line_no,
            buffer,
            ctx.width_len_buffer_lines,
        )

    line_width = ctx.max_width - gutter_width - 1
    if line_width <= 0:
        return None

    start_i = max(0, bisect_right(offsets, h_scroll) - 1)
    end_i = min(len(line), bisect_right(offsets, h_scroll + line_width))

    slice_text, visible_cells_used = render_slice(
        line=line,
        h_scroll=h_scroll,
        line_width=line_width,
        offsets=offsets,
        tab_size=ctx.tab_size,
    )

    marker_x = gutter_width + line_width

    return LineContext(
        ctx=ctx,
        line=line,
        screen_row=screen_row,
        line_no=line_no,
        offsets=offsets,
        visual_width=visual_width,
        gutter_width=gutter_width,
        line_width=line_width,
        start_i=start_i,
        end_i=end_i,
        slice_text=slice_text,
        visible_cells_used=visible_cells_used,
        marker_x=marker_x,
    )


def draw_one_line(
    *,
    line_ctx: LineContext,
    search_by_line,
    best_diag,
    completions_by_line,
    selection,
) -> None:
    draw_base_text(line_ctx)
    draw_trailing_spaces(line_ctx)
    draw_syntax_highlights(line_ctx)
    draw_bracket_highlight(line_ctx)
    draw_search_highlights_for_line(line_ctx, search_by_line)
    draw_selection(line_ctx, selection)
    draw_diagnostics(line_ctx, best_diag)
    draw_ai_completion(line_ctx, completions_by_line)

    # Draw overflow markers last so highlights do not overwrite them.
    draw_backward_overflow_marker(line_ctx)
    draw_forward_overflow_marker(line_ctx)


def draw_base_text(line_ctx: LineContext) -> None:
    ctx = line_ctx.ctx
    y = line_ctx.screen_row

    try:
        ctx.stdscr.move(y, line_ctx.gutter_width)
        ctx.stdscr.clrtoeol()

        if not line_ctx.slice_text:
            return

        ctx.stdscr.addnstr(
            y,
            line_ctx.gutter_width,
            line_ctx.slice_text,
            line_ctx.line_width,
            ctx.normal,
        )
    except curses.error:
        pass


def draw_trailing_spaces(line_ctx: LineContext) -> None:
    ctx = line_ctx.ctx
    h_scroll = ctx.window.h_scroll
    line = line_ctx.line
    offsets = line_ctx.offsets

    trail_idx = len(line.rstrip())
    if trail_idx >= len(line):
        return

    trail_col = offsets[trail_idx]
    vis_start = trail_col - h_scroll

    trail_end_col = offsets[len(line)]
    trail_len = trail_end_col - trail_col

    if 0 <= vis_start < line_ctx.line_width:
        try:
            ctx.stdscr.chgat(
                line_ctx.screen_row,
                line_ctx.gutter_width + vis_start,
                min(trail_len, line_ctx.line_width - vis_start),
                ctx.red_trailing,
            )
        except curses.error:
            pass


def draw_syntax_highlights(line_ctx: LineContext) -> None:
    ctx = line_ctx.ctx
    line = line_ctx.line

    if not line.tokens:
        return

    for span in line.tokens:
        if span is None or span.start >= len(line_ctx.offsets):
            continue

        visible = get_visible_draw_range(
            start=span.start,
            end=span.end,
            offsets=line_ctx.offsets,
            visual_width=line_ctx.visual_width,
            h_scroll=ctx.window.h_scroll,
            line_width=line_ctx.line_width,
        )

        if visible is None:
            continue

        ds, de = visible

        try:
            ctx.stdscr.chgat(
                line_ctx.screen_row,
                line_ctx.gutter_width + ds,
                de - ds,
                ctx.cp(span.attr),
            )
        except curses.error:
            pass


def draw_bracket_highlight(line_ctx: LineContext) -> None:
    if not line_ctx.ctx.window.focused:
        return

    ctx = line_ctx.ctx

    if not ctx.match:
        return

    buffer = ctx.buffer
    window = ctx.window
    cursor_pos = (window.cursor_y, window.cursor_x)

    for by, bx in ctx.match:
        if line_ctx.line_no != by:
            continue

        if bx < len(line_ctx.offsets):
            col = line_ctx.offsets[bx] - window.h_scroll
        else:
            col = line_ctx.offsets[-1] - window.h_scroll

        if not (0 <= col < line_ctx.line_width):
            continue

        if (by, bx) == cursor_pos:
            continue

        try:
            attr = ctx.cp(1)

            if line_ctx.line.tokens:
                for span in line_ctx.line.tokens:
                    if span and span.start <= bx < span.end:
                        attr = ctx.cp(span.attr)
                        break

            ctx.stdscr.chgat(
                line_ctx.screen_row,
                line_ctx.gutter_width + col,
                1,
                attr | curses.A_REVERSE,
            )

        except Exception:
            pass


def draw_search_highlights_for_line(line_ctx: LineContext, search_by_line) -> None:
    if search_by_line is None:
        return

    ctx = line_ctx.ctx

    for span in search_by_line.get(line_ctx.line_no, ()):
        visible = get_visible_draw_range(
            start=span.start,
            end=span.end,
            offsets=line_ctx.offsets,
            visual_width=line_ctx.visual_width,
            h_scroll=ctx.window.h_scroll,
            line_width=line_ctx.line_width,
        )

        if visible is None:
            continue

        ds, de = visible

        try:
            ctx.stdscr.chgat(
                line_ctx.screen_row,
                line_ctx.gutter_width + ds,
                de - ds,
                ctx.cp(span.attr),
            )
        except curses.error:
            pass


def draw_selection(line_ctx: LineContext, selection) -> None:
    if selection is None:
        return

    sy, sx, ey, ex = selection

    if not (sy <= line_ctx.line_no <= ey):
        return

    ctx = line_ctx.ctx
    line = line_ctx.line
    h_scroll = ctx.window.h_scroll

    start_col = sx if line_ctx.line_no == sy else 0
    end_col = ex if line_ctx.line_no == ey else len(line)

    if len(line) == 0:
        draw_empty_line_selection(line_ctx)
        return

    s = (
        line_ctx.offsets[start_col] - h_scroll
        if start_col < len(line_ctx.offsets)
        else line_ctx.visual_width - h_scroll
    )
    e = (
        line_ctx.offsets[end_col] - h_scroll
        if end_col < len(line_ctx.offsets)
        else line_ctx.visual_width - h_scroll
    )

    ds = max(s, 0)
    de = min(e, line_ctx.line_width)

    if de <= ds and start_col != end_col:
        de = min(ds + 1, line_ctx.line_width)

    if de > ds:
        try:
            ctx.stdscr.chgat(
                line_ctx.screen_row,
                line_ctx.gutter_width + ds,
                de - ds,
                ctx.sel_attr,
            )
        except curses.error:
            pass


def draw_empty_line_selection(line_ctx: LineContext) -> None:
    ctx = line_ctx.ctx
    h_scroll = ctx.window.h_scroll

    draw_start = max(0, -h_scroll)
    draw_end = max(draw_start + 1, 1)

    if draw_start >= line_ctx.line_width:
        return

    draw_end = min(draw_end, line_ctx.line_width)

    try:
        ctx.stdscr.chgat(
            line_ctx.screen_row,
            line_ctx.gutter_width + draw_start,
            draw_end - draw_start,
            ctx.sel_attr,
        )
    except curses.error:
        pass


def draw_diagnostics(line_ctx: LineContext, best_diag) -> None:
    if best_diag is None or line_ctx.line_no not in best_diag:
        return

    ctx = line_ctx.ctx

    diag, count = best_diag[line_ctx.line_no]
    char_pos = min(line_ctx.visible_cells_used + 1, line_ctx.line_width - 1)

    if not (
        0 <= char_pos < line_ctx.line_width
        and line_ctx.gutter_width + char_pos < line_ctx.marker_x
    ):
        return

    sev_color = hilighing.SEVERITY_COLORS.get(diag.severity, 1)
    diag_text = f"{diag.code}{f'+{count - 1}' if count > 1 else ''}: {diag.message}"

    try:
        ctx.stdscr.addnstr(
            line_ctx.screen_row,
            line_ctx.gutter_width + char_pos,
            diag_text,
            max(0, line_ctx.marker_x - (line_ctx.gutter_width + char_pos)),
            ctx.cp(sev_color),
        )
    except Exception:
        pass


def draw_ai_completion(line_ctx: LineContext, completions_by_line) -> None:
    if completions_by_line is None or line_ctx.line_no not in completions_by_line:
        return

    ctx = line_ctx.ctx

    diag = completions_by_line[line_ctx.line_no]
    char_pos = min(line_ctx.visible_cells_used + 1, line_ctx.line_width - 1)

    if not (
        0 <= char_pos < line_ctx.line_width
        and line_ctx.gutter_width + char_pos < line_ctx.marker_x
    ):
        return

    sev_color = hilighing.SEVERITY_COLORS.get(diag.severity, 1)
    diag_text = f"{diag.code}: {diag.message}"

    try:
        ctx.stdscr.addnstr(
            line_ctx.screen_row,
            line_ctx.gutter_width + char_pos,
            diag_text,
            max(0, line_ctx.marker_x - (line_ctx.gutter_width + char_pos)),
            ctx.cp(sev_color),
        )
    except Exception:
        pass


def draw_backward_overflow_marker(line_ctx: LineContext) -> None:
    ctx = line_ctx.ctx

    if ctx.window.h_scroll <= 0:
        return

    try:
        ctx.stdscr.addch(
            line_ctx.screen_row,
            line_ctx.gutter_width,
            "«",
            ctx.red_trailing,
        )
    except curses.error:
        pass


def draw_forward_overflow_marker(line_ctx: LineContext) -> None:
    ctx = line_ctx.ctx

    if line_ctx.visual_width <= ctx.window.h_scroll + line_ctx.line_width:
        return

    try:
        ctx.stdscr.addch(
            line_ctx.screen_row,
            line_ctx.marker_x,
            "»",
            ctx.red_trailing,
        )
    except curses.error:
        pass


def get_visible_draw_range(
    *,
    start: int,
    end: int,
    offsets: tuple[int, ...],
    visual_width: int,
    h_scroll: int,
    line_width: int,
) -> Optional[tuple[int, int]]:
    s = offsets[start] - h_scroll if start < len(offsets) else visual_width - h_scroll
    e = offsets[end] - h_scroll if end < len(offsets) else visual_width - h_scroll

    if e <= 0 or s >= line_width:
        return None

    return max(s, 0), min(e, line_width)


def draw_status_bar(ctx: DrawContext) -> None:
    status_line = build_status_line(ctx)

    status_y = ctx.height - 1

    try:
        ctx.stdscr.move(status_y, 0)
        ctx.stdscr.clrtoeol()

        ctx.stdscr.addnstr(
            status_y,
            0,
            status_line,
            ctx.width - 1,
            curses.color_pair(20),
        )

        ctx.stdscr.addstr(
            status_y,
            ctx.width - 1,
            " ",
            curses.color_pair(20),
        )
    except curses.error:
        pass


def build_status_line(ctx: DrawContext) -> str:
    editor = ctx.editor
    buffer = ctx.buffer
    window = ctx.window

    status_left = (
        f"{editor.current_branch}\u2387 "
        f"({window.current_buffer + 1}/{len(editor.buffers)}) -- "
        f"{editor.mode} -- "
        f"{'*' if buffer.modified else ' '}"
        f"{buffer.file_name or '[No Name]'} "
    )

    if editor.recording_macro:
        status_left += f" @{editor.current_macro_recording} "

    if editor.last_search and not editor.disable_search:
        status_left += f"search: [{editor.last_search}] "

    sel_text = build_selection_status_text(ctx)
    ai_info = build_ai_status_text(buffer.ai_completions)
    lsp_info = build_lsp_status_text(buffer.diagnostics)
    lang_info = build_language_status_text(ctx)

    right_chunk = f"{sel_text}{ai_info}{lsp_info}{lang_info}"

    usable = ctx.width - 1
    max_left = max(0, usable - len(right_chunk))

    left_part = status_left[:max_left]

    return left_part.ljust(max_left) + right_chunk


def build_selection_status_text(ctx: DrawContext) -> str:
    editor = ctx.editor
    buffer = ctx.buffer
    window = ctx.window

    if not editor.selection_start:
        return ""

    lines_selected = abs(window.cursor_y - editor.selection_start[0]) + 1
    selected_length = len("".join(editor.get_selected_text(move_cursor=False)))

    return f"selected: [{lines_selected}, {selected_length}] "


def build_ai_status_text(ai_completions) -> str:
    if not ai_completions:
        return ""

    completed = sum(1 for c in ai_completions if c.message == "COMPLETED")
    total = len(ai_completions)

    return f"AI[{completed}/{total}] "


def build_lsp_status_text(diagnostics) -> str:
    if not diagnostics:
        return ""

    sev_map = {1: "E", 2: "W", 3: "I", 4: "H"}
    sev_counts: dict[int, int] = {}

    for d in diagnostics:
        sev_counts[d.severity] = sev_counts.get(d.severity, 0) + 1

    sev_str = ", ".join(
        f"{sev_map.get(sev, sev)}:{count}" for sev, count in sorted(sev_counts.items())
    )

    return f"LSP[{sev_str}] "


def build_language_status_text(ctx: DrawContext) -> str:
    buffer = ctx.buffer
    window = ctx.window

    if ctx.len_buffer_lines <= 0:
        line_percentage = "Top"
    elif window.cursor_y == 0:
        line_percentage = "Top"
    elif window.cursor_y == ctx.len_buffer_lines - 1:
        line_percentage = "Bot"
    else:
        line_percentage = f"{int(window.cursor_y / ctx.len_buffer_lines * 100)}%"

    line_percentage = line_percentage.rjust(5)

    return (
        f"({buffer.lexer.name if buffer.lexer else 'Text'}) "
        f"{buffer.encoding} "
        f"[{window.cursor_y + 1}, {window.cursor_x}]"
        f"{line_percentage}"
    )


def draw_cursor(ctx: DrawContext) -> None:
    if not ctx.window.focused:
        return

    buffer = ctx.buffer
    window = ctx.window

    if not (ctx.top <= window.cursor_y < ctx.bottom):
        return

    line = buffer.lines[window.cursor_y]
    offsets = get_offsets(line, ctx.tab_size)

    cursor_vis_col = (
        offsets[window.cursor_x] if window.cursor_x < len(offsets) else offsets[-1]
    )

    cursor_y = window.cursor_y - window.scroll

    visible_width = max(1, (ctx.width - 1) - ctx.current_gutter - 1)

    cursor_x_screen = cursor_vis_col - window.h_scroll
    cursor_x_screen = max(0, min(cursor_x_screen, visible_width - 1))

    try:
        ctx.stdscr.move(cursor_y, ctx.current_gutter + cursor_x_screen)
    except curses.error:
        pass
