"""Placeholder. The real auto-instrumentation ships in v0.3.0b1+."""

__version__ = "0.0.1"
