# aicostguard-dev (placeholder)

This is a **name reservation** for the upcoming AI Cost Guard auto-instrumentation
package for Python.

The real package ships starting in **v0.3.0b1** with one-line auto-instrumentation
for OpenAI, Anthropic, Gemini, Cohere, Mistral, and OpenAI-compatible providers
(xAI, Groq, Together, Fireworks, Perplexity, DeepSeek, OpenRouter, Vercel AI Gateway).

**Don't install this version.** It's an empty placeholder. Wait for `aicostguard-dev>=0.3.0b1`.

- Homepage: https://aicostguard.dev
- Source: https://github.com/Vinodmurkute/ai-cost-guard
- License: Apache-2.0
