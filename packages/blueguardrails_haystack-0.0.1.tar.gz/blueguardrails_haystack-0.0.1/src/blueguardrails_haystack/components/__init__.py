# SPDX-FileCopyrightText: 2025-present Blue Guardrails
#
# SPDX-License-Identifier: Apache-2.0

"""Haystack components provided by blueguardrails-haystack."""

from blueguardrails_haystack.components.connector import BlueGuardrailsConnector

__all__ = ["BlueGuardrailsConnector"]
