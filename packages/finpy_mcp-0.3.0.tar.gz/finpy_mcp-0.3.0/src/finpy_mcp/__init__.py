def main() -> None:
    print("Hello from finpy-mcp!")
