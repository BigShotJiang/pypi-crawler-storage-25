"""
Finpy CLI — Interactive terminal authentication

Commands:
  finpy-cli login       — Login via browser (OAuth device flow)
  finpy-cli login --basic — Login with email/password in terminal (fallback)
  finpy-cli logout      — Delete stored credentials
  finpy-cli set-org     — Set active organization
  finpy-cli status      — Show current auth status
"""

import getpass
import time
import webbrowser

import click
import httpx

from .config import API_BASE_URL, REQUEST_TIMEOUT
from .credentials import load_credentials, save_credentials, delete_credentials


@click.group()
def main():
    """Finpy CLI — Authenticate and manage your Finpy MCP connection."""
    pass


def _save_and_show(data: dict) -> None:
    """Save credentials and show orgs. Shared between login flows."""
    token = data["token"]
    user = data["data"]["user"]
    orgs = data["data"]["organizations"]

    # Default to first organization
    default_org_id = orgs[0]["id"] if orgs else None

    save_credentials({
        "access_token": token["access_token"],
        "refresh_token": token["refresh_token"],
        "organization_id": default_org_id,
        "user_email": user["email"],
    })

    click.echo(f"\n✓ Logged in as {user['email']}")
    click.echo(f"✓ Credentials saved to ~/.finpy/credentials.json\n")

    if orgs:
        click.echo("Organizations:")
        for org in orgs:
            marker = " (active)" if org["id"] == default_org_id else ""
            click.echo(f"  {org['id']}. {org['name']} — role: {org['user_role']}{marker}")
        click.echo(f"\nUse 'finpy-cli set-org <id>' to change active organization.")
    else:
        click.echo("Warning: No organizations found. Create one in the Finpy dashboard.")


@main.command()
@click.option("--basic", is_flag=True, help="Use email/password login instead of browser (for headless environments)")
def login(basic: bool):
    """Login to Finpy. Opens browser by default (OAuth device flow).
    Use --basic for email/password in terminal."""
    if basic:
        _login_basic()
    else:
        _login_device()


def _login_device():
    """Device flow: open browser, user approves, CLI polls for token."""
    try:
        with httpx.Client(timeout=REQUEST_TIMEOUT) as client:
            # Step 1: Request device code
            r = client.post(f"{API_BASE_URL}/accounts/auth/device-code")
            r.raise_for_status()
            device = r.json()

            device_code = device["device_code"]
            user_code = device["user_code"]
            verification_url = device["verification_url"]
            interval = device.get("interval", 2)
            expires_in = device.get("expires_in", 300)

            # Step 2: Open browser
            click.echo(f"\nOpening browser to authorize...")
            click.echo(f"If browser doesn't open, go to: {verification_url}")
            click.echo(f"Code: {user_code}\n")
            webbrowser.open(verification_url)

            # Step 3: Poll for token
            click.echo("Waiting for authorization", nl=False)
            start = time.time()
            while time.time() - start < expires_in:
                time.sleep(interval)
                click.echo(".", nl=False)

                r = client.post(
                    f"{API_BASE_URL}/accounts/auth/device-token",
                    json={"device_code": device_code},
                )
                data = r.json()

                if data.get("success"):
                    click.echo("")  # newline after dots
                    _save_and_show(data)
                    return

                error = data.get("error", "")
                if error == "authorization_pending":
                    continue
                elif error == "expired_token":
                    click.echo("\nError: Code expired. Please try again.", err=True)
                    raise SystemExit(1)
                elif error == "access_denied":
                    click.echo("\nError: Authorization denied.", err=True)
                    raise SystemExit(1)
                else:
                    click.echo(f"\nError: {error}", err=True)
                    raise SystemExit(1)

            click.echo("\nError: Timed out waiting for authorization.", err=True)
            raise SystemExit(1)

    except httpx.ConnectError:
        click.echo(f"Error: Cannot connect to {API_BASE_URL}. Is the server running?", err=True)
        raise SystemExit(1)


def _login_basic():
    """Basic flow: email/password in terminal (fallback for headless environments)."""
    email = click.prompt("Email")
    password = getpass.getpass("Password: ")

    click.echo("Logging in...")

    try:
        with httpx.Client(timeout=REQUEST_TIMEOUT) as client:
            r = client.post(
                f"{API_BASE_URL}/accounts/auth/login",
                json={"email": email, "password": password},
            )

            if r.status_code == 401:
                click.echo("Error: Invalid email or password.", err=True)
                raise SystemExit(1)

            r.raise_for_status()
            _save_and_show(r.json())

    except httpx.HTTPStatusError as e:
        click.echo(f"Error: API returned {e.response.status_code}", err=True)
        raise SystemExit(1)
    except httpx.ConnectError:
        click.echo(f"Error: Cannot connect to {API_BASE_URL}. Is the server running?", err=True)
        raise SystemExit(1)


@main.command()
def logout():
    """Delete stored credentials."""
    delete_credentials()
    click.echo("✓ Logged out. Credentials deleted.")


@main.command("set-org")
@click.argument("org_id", type=int)
def set_org(org_id: int):
    """Set the active organization ID."""
    creds = load_credentials()
    if not creds:
        click.echo("Error: Not logged in. Run 'finpy-cli login' first.", err=True)
        raise SystemExit(1)

    creds["organization_id"] = org_id
    save_credentials(creds)
    click.echo(f"✓ Active organization set to {org_id}")


@main.command()
def status():
    """Show current authentication status."""
    creds = load_credentials()
    if not creds:
        click.echo("Not authenticated. Run 'finpy-cli login' first.")
        return

    click.echo(f"Email: {creds.get('user_email', 'unknown')}")
    click.echo(f"Organization ID: {creds.get('organization_id', 'not set')}")
    click.echo(f"API: {API_BASE_URL}")
    click.echo(f"Token: {'present' if creds.get('access_token') else 'missing'}")
    click.echo(f"Refresh token: {'present' if creds.get('refresh_token') else 'missing'}")
