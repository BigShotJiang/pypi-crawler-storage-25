"""
Finpy MCP Server

FastMCP instance with all tools registered.
Entrypoint: finpy-mcp (stdio transport for Claude Desktop/Code/Cursor)
"""

from fastmcp import FastMCP

mcp = FastMCP(
    "Finpy",
    instructions=(
        "Finpy Asset Manager — manage cap tables, deals, holdings, and financials through conversation.\n\n"
        "IMPORTANT: Before using any tools, the user must have run 'finpy-cli login' in their terminal.\n"
        "Then use set_context() to select an organization and entity.\n\n"
        "Workflow: set_context → list/create data.\n"
        "Entity is the foundation — everything (stakeholders, securities, deals, holdings) belongs to an entity.\n"
        "Subscription is charged per entity — inform users when creating new entities."
    ),
    mask_error_details=True,
)

# Register all tools by importing tool modules
# Each module uses @mcp.tool decorator from this instance
from .tools import context  # noqa: F401, E402
from .tools import entity  # noqa: F401, E402
from .tools import captable  # noqa: F401, E402
from .tools import deals  # noqa: F401, E402
from .tools import holdings  # noqa: F401, E402
from .tools import financials  # noqa: F401, E402
from .tools import fees  # noqa: F401, E402
from .tools import kpis  # noqa: F401, E402
from .tools import pipeline  # noqa: F401, E402
from .tools import valuations  # noqa: F401, E402


def main():
    """Entrypoint for finpy-mcp command. Runs stdio transport for Claude Desktop/Code/Codex."""
    mcp.run()


def main_http():
    """Entrypoint for finpy-mcp-http command. Runs Streamable HTTP transport for ChatGPT / remote clients."""
    mcp.run(transport="http", host="0.0.0.0", port=8811)
