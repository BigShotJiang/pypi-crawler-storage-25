"""
Finpy MCP Server — Configuration

API base URL is read from FINPY_API_URL env var.
Defaults to localhost for development, override for production.
"""

import os

# API base URL — override with FINPY_API_URL env var for production
API_BASE_URL = os.environ.get("FINPY_API_URL", "https://server.finpy.tech")

# Credentials file path — where JWT + refresh token are stored locally
CREDENTIALS_PATH = os.path.expanduser("~/.finpy/credentials.json")

# HTTP client timeout (seconds)
REQUEST_TIMEOUT = 30.0
