"""
Fees tools — management fees, performance fees, setup costs, etc.
"""

from typing import Literal

from ..server import mcp
from ..client import finpy


@mcp.tool(annotations={"readOnlyHint": True})
async def list_fees() -> str:
    """List all fees for the current entity."""
    if not finpy.entity_id:
        return "Error: No entity set. Use set_context() first."

    result = await finpy.get("/assetmanager/fees/", params={"entity_id": finpy.entity_id})
    items = result.get("data", [])

    if not items:
        return "No fees found. Create one with create_fee()."

    lines = [f"Fees ({len(items)}):"]
    for f in items:
        amount = f", amount={f['amount']:,.2f}" if f.get("amount") else ""
        pct = f", percentage={f['percentage']}%" if f.get("percentage") else ""
        freq = f", frequency={f['frequency']}" if f.get("frequency") else ""
        lines.append(
            f"  - id={f['id']} | {f['fee_type']} | year={f['year']}{amount}{pct}{freq}"
        )

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False})
async def create_fee(
    year: int,
    fee_type: Literal["management", "performance", "setup", "administrative", "other"],
    amount: float | None = None,
    percentage: float | None = None,
    frequency: Literal["one_time", "monthly", "quarterly", "annual"] = "one_time",
    scenario: Literal["actual", "forecast", "budget"] = "actual",
    quarter: Literal["Q1", "Q2", "Q3", "Q4"] | None = None,
    funding_round_id: int | None = None,
    fee_cost_name: str | None = None,
    description: str | None = None,
) -> str:
    """Create a fee on the current entity.
    Provide either amount (absolute) or percentage (of AUM/commitment), or both.
    fee_type: management (ongoing AUM fee), performance (carry/incentive), setup (one-time), administrative, other."""
    if not finpy.entity_id:
        return "Error: No entity set. Use set_context() first."

    payload: dict = {
        "entity_id": finpy.entity_id,
        "year": year,
        "fee_type": fee_type,
        "frequency": frequency,
        "scenario": scenario,
    }
    optional = {
        "amount": amount, "percentage": percentage, "quarter": quarter,
        "funding_round_id": funding_round_id, "fee_cost_name": fee_cost_name,
        "description": description,
    }
    for k, v in optional.items():
        if v is not None:
            payload[k] = v

    result = await finpy.post("/assetmanager/fees/", payload)
    f = result["data"]

    return f"Fee created: id={f['id']}, type={f['fee_type']}, year={f['year']}."
