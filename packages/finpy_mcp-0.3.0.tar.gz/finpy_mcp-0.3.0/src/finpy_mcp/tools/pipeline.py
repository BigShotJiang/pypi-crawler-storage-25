"""
Deal Pipeline tools — track prospective investments through screening to close.

Pipeline entries track deals your entity is EVALUATING (not yet invested).
Once a deal closes and you invest, create a Holding to track the actual investment.
"""

from typing import Literal

from ..server import mcp
from ..client import finpy


@mcp.tool(annotations={"readOnlyHint": True})
async def list_deal_pipeline() -> str:
    """List all deal pipeline entries for the current entity."""
    if not finpy.entity_id:
        return "Error: No entity set. Use set_context() first."

    result = await finpy.get("/assetmanager/deal-pipeline/", params={"entity_id": finpy.entity_id})
    items = result.get("data", [])

    if not items:
        return "No pipeline entries found. Create one with create_pipeline_entry()."

    lines = [f"Deal Pipeline ({len(items)}):"]
    for p in items:
        amount = f", amount={p['investment_amount']:,.2f}" if p.get("investment_amount") else ""
        close = f", close={p['expected_close_date']}" if p.get("expected_close_date") else ""
        lines.append(
            f"  - {p['deal_name']} (id={p['id']}, {p['status']}, {p['priority']}, "
            f"{p['round_type']}, {p['sector']}{amount}{close})"
        )

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False})
async def create_pipeline_entry(
    deal_name: str,
    priority: Literal["p1", "p2", "p3", "p4", "p5"],
    round_type: str,
    sector: str,
    status: Literal["initial_screening", "due_diligence", "term_sheet", "negotiation", "closing", "closed", "passed", "rejected"] = "initial_screening",
    company_name: str | None = None,
    target_raise: float | None = None,
    pre_money_valuation: float | None = None,
    investment_amount: float | None = None,
    expected_ownership: float | None = None,
    expected_close_date: str | None = None,
    is_lead_investor: bool = False,
    investment_thesis: str | None = None,
    key_risks: str | None = None,
    notes: str | None = None,
) -> str:
    """Add a prospective deal to the pipeline.
    priority: p1 (highest) to p5 (lowest).
    round_type examples: Series A, Seed, Bridge.
    sector examples: fintech, healthtech, saas, ai_ml, ecommerce.
    Use this when evaluating a new investment opportunity (e.g., from an info memo or pitch deck)."""
    if not finpy.entity_id:
        return "Error: No entity set. Use set_context() first."

    payload: dict = {
        "entity_id": finpy.entity_id,
        "deal_name": deal_name,
        "priority": priority,
        "round_type": round_type,
        "sector": sector,
        "status": status,
        "is_lead_investor": is_lead_investor,
    }
    optional = {
        "company_name": company_name, "target_raise": target_raise,
        "pre_money_valuation": pre_money_valuation, "investment_amount": investment_amount,
        "expected_ownership": expected_ownership, "expected_close_date": expected_close_date,
        "investment_thesis": investment_thesis, "key_risks": key_risks, "notes": notes,
    }
    for k, v in optional.items():
        if v is not None:
            payload[k] = v

    result = await finpy.post("/assetmanager/deal-pipeline/", payload)
    p = result["data"]

    return f"Pipeline entry created: {p['deal_name']} (id={p['id']}, status={p['status']}, priority={p['priority']})."


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False})
async def update_pipeline_entry(
    pipeline_id: int,
    status: Literal["initial_screening", "due_diligence", "term_sheet", "negotiation", "closing", "closed", "passed", "rejected"] | None = None,
    priority: Literal["p1", "p2", "p3", "p4", "p5"] | None = None,
    investment_amount: float | None = None,
    expected_ownership: float | None = None,
    expected_close_date: str | None = None,
    investment_thesis: str | None = None,
    key_risks: str | None = None,
    due_diligence_notes: str | None = None,
    next_steps: str | None = None,
    rejection_reason: str | None = None,
    notes: str | None = None,
) -> str:
    """Update a pipeline entry. Only provided fields are changed.
    Common use: advance status (initial_screening → due_diligence → term_sheet → closing),
    update investment thesis after meetings, add due diligence notes, mark as passed/rejected."""
    payload: dict = {}
    fields = {
        "status": status, "priority": priority, "investment_amount": investment_amount,
        "expected_ownership": expected_ownership, "expected_close_date": expected_close_date,
        "investment_thesis": investment_thesis, "key_risks": key_risks,
        "due_diligence_notes": due_diligence_notes, "next_steps": next_steps,
        "rejection_reason": rejection_reason, "notes": notes,
    }
    for k, v in fields.items():
        if v is not None:
            payload[k] = v

    if not payload:
        return "Error: No fields to update."

    result = await finpy.put(f"/assetmanager/deal-pipeline/{pipeline_id}", payload)
    p = result["data"]

    return f"Pipeline entry updated: {p['deal_name']} (id={p['id']}, status={p['status']})."
