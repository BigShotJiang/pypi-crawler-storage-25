"""
Valuation tools — NAV snapshots and performance tracking over time.

Each valuation is a point-in-time snapshot of entity value.
Used by the Reporting page for NAV charts and historical performance.
"""

from ..server import mcp
from ..client import finpy


@mcp.tool(annotations={"readOnlyHint": True})
async def list_valuations() -> str:
    """List all valuation snapshots for the current entity (ordered by date, most recent first)."""
    if not finpy.entity_id:
        return "Error: No entity set. Use set_context() first."

    result = await finpy.get("/assetmanager/valuations/", params={"entity_id": finpy.entity_id})
    items = result.get("data", [])

    if not items:
        return "No valuation snapshots found. Create one with create_valuation()."

    lines = [f"Valuations ({len(items)}):"]
    for v in items:
        date = v.get("date", "—")
        nav = f", NAV/share={v['nav_per_share']:,.2f}" if v.get("nav_per_share") else ""
        irr = f", IRR={v['irr']:.2f}%" if v.get("irr") else ""
        tvpi = f", TVPI={v['tvpi']:.2f}x" if v.get("tvpi") else ""
        lines.append(
            f"  - id={v['id']} | date={date} | value={v['valuation_value']:,.2f}{nav}{tvpi}{irr}"
        )

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False})
async def create_valuation(
    valuation_value: float,
    date: str | None = None,
    funding_round_id: int | None = None,
    total_fund_units: float | None = None,
    nav_per_share: float | None = None,
    total_invested_amount: float | None = None,
    fair_value: float | None = None,
    cash_realized: float | None = None,
    tvpi: float | None = None,
    dpi: float | None = None,
    rvpi: float | None = None,
    irr: float | None = None,
    notes: str | None = None,
) -> str:
    """Create a valuation snapshot for the current entity.
    valuation_value is the total entity/fund valuation at this point in time.
    Optional performance fields: tvpi, dpi, rvpi, irr — capture point-in-time metrics.
    Date format: YYYY-MM-DD. If not provided, defaults to today."""
    if not finpy.entity_id:
        return "Error: No entity set. Use set_context() first."

    payload: dict = {
        "entity_id": finpy.entity_id,
        "valuation_value": valuation_value,
    }
    optional = {
        "date": date, "funding_round_id": funding_round_id,
        "total_fund_units": total_fund_units, "nav_per_share": nav_per_share,
        "total_invested_amount": total_invested_amount, "fair_value": fair_value,
        "cash_realized": cash_realized, "tvpi": tvpi, "dpi": dpi, "rvpi": rvpi,
        "irr": irr, "notes": notes,
    }
    for k, v in optional.items():
        if v is not None:
            payload[k] = v

    result = await finpy.post("/assetmanager/valuations/", payload)
    v = result["data"]

    return f"Valuation created: id={v['id']}, value={v['valuation_value']:,.2f}, date={v.get('date', '—')}."


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False})
async def update_valuation(
    valuation_id: int,
    valuation_value: float | None = None,
    nav_per_share: float | None = None,
    total_invested_amount: float | None = None,
    fair_value: float | None = None,
    cash_realized: float | None = None,
    tvpi: float | None = None,
    dpi: float | None = None,
    rvpi: float | None = None,
    irr: float | None = None,
    notes: str | None = None,
) -> str:
    """Update a valuation snapshot. Only provided fields are changed.
    Common use: update performance metrics (IRR, TVPI) or adjust NAV after revaluation."""
    payload: dict = {}
    fields = {
        "valuation_value": valuation_value, "nav_per_share": nav_per_share,
        "total_invested_amount": total_invested_amount, "fair_value": fair_value,
        "cash_realized": cash_realized, "tvpi": tvpi, "dpi": dpi, "rvpi": rvpi,
        "irr": irr, "notes": notes,
    }
    for k, v in fields.items():
        if v is not None:
            payload[k] = v

    if not payload:
        return "Error: No fields to update."

    result = await finpy.put(f"/assetmanager/valuations/{valuation_id}", payload)
    v = result["data"]

    return f"Valuation updated: id={v['id']}, value={v['valuation_value']:,.2f}."
