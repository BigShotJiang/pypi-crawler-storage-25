from enum import StrEnum

import numpy as np

from mujoco_mojo.typing import Vec3, Vec4
from mujoco_mojo.utils.log import get_logger

logger = get_logger(__name__)

__all__ = ["Color"]

rng = np.random.default_rng(seed=42)


class Color(StrEnum):
    """
    Contains color aliases and converters to go between the various color formats. The color values are defined by the standard [Tailwind CSS](https://tailwindcss.com/docs/colors) color theme.

    MuJoCo uses a normalized rgba (all color channels clamped between 0 and 1). This enum defines with hex values, but they can be easily transformed with the provided methods (for example: `Color.WHITE.rgba`).
    """

    BLACK = "#000000"
    WHITE = "#FFFFFF"
    SLATE_50 = "#F8FAFC"
    SLATE_100 = "#F1F5F9"
    SLATE_200 = "#E2E8F0"
    SLATE_300 = "#CBD5E1"
    SLATE_400 = "#94A3B8"
    SLATE_500 = "#64748B"
    SLATE_600 = "#475569"
    SLATE_700 = "#334155"
    SLATE_800 = "#1E293B"
    SLATE_900 = "#0F172A"
    SLATE_950 = "#020617"
    GRAY_50 = "#F9FAFB"
    GRAY_100 = "#F3F4F6"
    GRAY_200 = "#E5E7EB"
    GRAY_300 = "#D1D5DB"
    GRAY_400 = "#9CA3AF"
    GRAY_500 = "#6B7280"
    GRAY_600 = "#4B5563"
    GRAY_700 = "#374151"
    GRAY_800 = "#1F2937"
    GRAY_900 = "#111827"
    GRAY_950 = "#030712"
    ZINC_50 = "#FAFAFA"
    ZINC_100 = "#F4F4F5"
    ZINC_200 = "#E4E4E7"
    ZINC_300 = "#D4D4D8"
    ZINC_400 = "#A1A1AA"
    ZINC_500 = "#71717A"
    ZINC_600 = "#52525B"
    ZINC_700 = "#3F3F46"
    ZINC_800 = "#27272A"
    ZINC_900 = "#18181B"
    ZINC_950 = "#09090B"
    NEUTRAL_50 = "#FAFAFA"
    NEUTRAL_100 = "#F5F5F5"
    NEUTRAL_200 = "#E5E5E5"
    NEUTRAL_300 = "#D4D4D4"
    NEUTRAL_400 = "#A3A3A3"
    NEUTRAL_500 = "#737373"
    NEUTRAL_600 = "#525252"
    NEUTRAL_700 = "#404040"
    NEUTRAL_800 = "#262626"
    NEUTRAL_900 = "#171717"
    NEUTRAL_950 = "#0A0A0A"
    STONE_50 = "#FAFAF9"
    STONE_100 = "#F5F5F4"
    STONE_200 = "#E7E5E4"
    STONE_300 = "#D6D3D1"
    STONE_400 = "#A8A29E"
    STONE_500 = "#78716C"
    STONE_600 = "#57534E"
    STONE_700 = "#44403C"
    STONE_800 = "#292524"
    STONE_900 = "#1C1917"
    STONE_950 = "#0C0A09"
    RED_50 = "#FEF2F2"
    RED_100 = "#FEE2E2"
    RED_200 = "#FECACA"
    RED_300 = "#FCA5A5"
    RED_400 = "#F87171"
    RED_500 = "#EF4444"
    RED_600 = "#DC2626"
    RED_700 = "#B91C1C"
    RED_800 = "#991B1B"
    RED_900 = "#7F1D1D"
    RED_950 = "#450A0A"
    ORANGE_50 = "#FFF7ED"
    ORANGE_100 = "#FFEDD5"
    ORANGE_200 = "#FED7AA"
    ORANGE_300 = "#FDBA74"
    ORANGE_400 = "#FB923C"
    ORANGE_500 = "#F97316"
    ORANGE_600 = "#EA580C"
    ORANGE_700 = "#C2410C"
    ORANGE_800 = "#9A3412"
    ORANGE_900 = "#7C2D12"
    ORANGE_950 = "#431407"
    AMBER_50 = "#FFFBEB"
    AMBER_100 = "#FEF3C7"
    AMBER_200 = "#FDE68A"
    AMBER_300 = "#FCD34D"
    AMBER_400 = "#FBBF24"
    AMBER_500 = "#F59E0B"
    AMBER_600 = "#D97706"
    AMBER_700 = "#B45309"
    AMBER_800 = "#92400E"
    AMBER_900 = "#78350F"
    AMBER_950 = "#451A03"
    YELLOW_50 = "#FEFCE8"
    YELLOW_100 = "#FEF9C3"
    YELLOW_200 = "#FEF08A"
    YELLOW_300 = "#FDE047"
    YELLOW_400 = "#FACC15"
    YELLOW_500 = "#EAB308"
    YELLOW_600 = "#CA8A04"
    YELLOW_700 = "#A16207"
    YELLOW_800 = "#854D0E"
    YELLOW_900 = "#713F12"
    YELLOW_950 = "#422006"
    LIME_50 = "#F7FEE7"
    LIME_100 = "#ECFCCB"
    LIME_200 = "#D9F99D"
    LIME_300 = "#BEF264"
    LIME_400 = "#A3E635"
    LIME_500 = "#84CC16"
    LIME_600 = "#65A30D"
    LIME_700 = "#4D7C0F"
    LIME_800 = "#3F6212"
    LIME_900 = "#365314"
    LIME_950 = "#1A2E05"
    GREEN_50 = "#F0FDF4"
    GREEN_100 = "#DCFCE7"
    GREEN_200 = "#BBF7D0"
    GREEN_300 = "#86EFAC"
    GREEN_400 = "#4ADE80"
    GREEN_500 = "#22C55E"
    GREEN_600 = "#16A34A"
    GREEN_700 = "#15803D"
    GREEN_800 = "#166534"
    GREEN_900 = "#14532D"
    GREEN_950 = "#052E16"
    EMERALD_50 = "#ECFDF5"
    EMERALD_100 = "#D1FAE5"
    EMERALD_200 = "#A7F3D0"
    EMERALD_300 = "#6EE7B7"
    EMERALD_400 = "#34D399"
    EMERALD_500 = "#10B981"
    EMERALD_600 = "#059669"
    EMERALD_700 = "#047857"
    EMERALD_800 = "#065F46"
    EMERALD_900 = "#064E3B"
    EMERALD_950 = "#022C22"
    TEAL_50 = "#F0FDFA"
    TEAL_100 = "#CCFBF1"
    TEAL_200 = "#99F6E4"
    TEAL_300 = "#5EEAD4"
    TEAL_400 = "#2DD4BF"
    TEAL_500 = "#14B8A6"
    TEAL_600 = "#0D9488"
    TEAL_700 = "#0F766E"
    TEAL_800 = "#115E59"
    TEAL_900 = "#134E4A"
    TEAL_950 = "#042F2E"
    CYAN_50 = "#ECFEFF"
    CYAN_100 = "#CFFAFE"
    CYAN_200 = "#A5F3FC"
    CYAN_300 = "#67E8F9"
    CYAN_400 = "#22D3EE"
    CYAN_500 = "#06B6D4"
    CYAN_600 = "#0891B2"
    CYAN_700 = "#0E7490"
    CYAN_800 = "#155E75"
    CYAN_900 = "#164E63"
    CYAN_950 = "#083344"
    SKY_50 = "#F0F9FF"
    SKY_100 = "#E0F2FE"
    SKY_200 = "#BAE6FD"
    SKY_300 = "#7DD3FC"
    SKY_400 = "#38BDF8"
    SKY_500 = "#0EA5E9"
    SKY_600 = "#0284C7"
    SKY_700 = "#0369A1"
    SKY_800 = "#075985"
    SKY_900 = "#0C4A6E"
    SKY_950 = "#082F49"
    BLUE_50 = "#EFF6FF"
    BLUE_100 = "#DBEAFE"
    BLUE_200 = "#BFDBFE"
    BLUE_300 = "#93C5FD"
    BLUE_400 = "#60A5FA"
    BLUE_500 = "#3B82F6"
    BLUE_600 = "#2563EB"
    BLUE_700 = "#1D4ED8"
    BLUE_800 = "#1E40AF"
    BLUE_900 = "#1E3A8A"
    BLUE_950 = "#172554"
    INDIGO_50 = "#EEF2FF"
    INDIGO_100 = "#E0E7FF"
    INDIGO_200 = "#C7D2FE"
    INDIGO_300 = "#A5B4FC"
    INDIGO_400 = "#818CF8"
    INDIGO_500 = "#6366F1"
    INDIGO_600 = "#4F46E5"
    INDIGO_700 = "#4338CA"
    INDIGO_800 = "#3730A3"
    INDIGO_900 = "#312E81"
    INDIGO_950 = "#1E1B4B"
    VIOLET_50 = "#F5F3FF"
    VIOLET_100 = "#EDE9FE"
    VIOLET_200 = "#DDD6FE"
    VIOLET_300 = "#C4B5FD"
    VIOLET_400 = "#A78BFA"
    VIOLET_500 = "#8B5CF6"
    VIOLET_600 = "#7C3AED"
    VIOLET_700 = "#6D28D9"
    VIOLET_800 = "#5B21B6"
    VIOLET_900 = "#4C1D95"
    VIOLET_950 = "#2E1065"
    PURPLE_50 = "#FAF5FF"
    PURPLE_100 = "#F3E8FF"
    PURPLE_200 = "#E9D5FF"
    PURPLE_300 = "#D8B4FE"
    PURPLE_400 = "#C084FC"
    PURPLE_500 = "#A855F7"
    PURPLE_600 = "#9333EA"
    PURPLE_700 = "#7E22CE"
    PURPLE_800 = "#6B21A8"
    PURPLE_900 = "#581C87"
    PURPLE_950 = "#3B0764"
    FUCHSIA_50 = "#FDF4FF"
    FUCHSIA_100 = "#FAE8FF"
    FUCHSIA_200 = "#F5D0FE"
    FUCHSIA_300 = "#F0ABFC"
    FUCHSIA_400 = "#E879F9"
    FUCHSIA_500 = "#D946EF"
    FUCHSIA_600 = "#C026D3"
    FUCHSIA_700 = "#A21CAF"
    FUCHSIA_800 = "#86198F"
    FUCHSIA_900 = "#701A75"
    FUCHSIA_950 = "#4A044E"
    PINK_50 = "#FDF2F8"
    PINK_100 = "#FCE7F3"
    PINK_200 = "#FBCFE8"
    PINK_300 = "#F9A8D4"
    PINK_400 = "#F472B6"
    PINK_500 = "#EC4899"
    PINK_600 = "#DB2777"
    PINK_700 = "#BE185D"
    PINK_800 = "#9D174D"
    PINK_900 = "#831843"
    PINK_950 = "#500724"
    ROSE_50 = "#FFF1F2"
    ROSE_100 = "#FFE4E6"
    ROSE_200 = "#FECDD3"
    ROSE_300 = "#FDA4AF"
    ROSE_400 = "#FB7185"
    ROSE_500 = "#F43F5E"
    ROSE_600 = "#E11D48"
    ROSE_700 = "#BE123C"
    ROSE_800 = "#9F1239"
    ROSE_900 = "#881337"
    ROSE_950 = "#4C0519"

    @property
    def invisible(self) -> Vec4:
        return self.with_alpha(0)

    @classmethod
    def random_rgba(cls) -> Vec4:
        return np.append((rng.random(3)), 1)

    @property
    def rgba(self) -> Vec4:
        """Returns the normalized RGBA array for MuJoCo."""
        return Color.hex_to_rgba(self.value)

    @property
    def rgb(self) -> Vec3:
        return self.rgba[0:3]

    def with_alpha(self, alpha: float) -> Vec4:
        """Returns the color with a custom transparency level."""
        return Color.hex_to_rgba(self.value, alpha=alpha)

    @classmethod
    def hex_to_rgba(cls, hex_str: str, alpha: float = 1.0) -> Vec4:
        """Converts '#RRGGBB' or 'RRGGBB' to normalized [0, 1] RGBA."""
        hex_str = hex_str.lstrip("#")
        # Convert hex to integers using bit-shifting
        lv = len(hex_str)
        if lv == 6:
            rgb = tuple(int(hex_str[i : i + 2], 16) for i in (0, 2, 4))
        else:
            raise ValueError(f"Invalid hex color: {hex_str}. Expected 6 characters.")

        return np.array([*(np.array(rgb) / 255.0), alpha])

    @classmethod
    def rgba255_to_rgba(cls, rgba255: Vec4) -> Vec4:
        """Converts [0-255, 0-255, 0-255, 0-1] to normalized [0, 1] RGBA."""
        res = np.array(rgba255, dtype=float)
        res[:3] /= 255.0
        return res

    @classmethod
    def rgba_to_hex(cls, rgba: Vec4) -> str:
        """Converts normalized RGBA to '#RRGGBB' (alpha is discarded)."""
        rgba = np.asarray(rgba, dtype=float)
        rgb255 = (rgba[:3] * 255).astype(int)
        return "#{:02x}{:02x}{:02x}".format(*rgb255)

    @classmethod
    def rgba_to_rgba255(cls, rgba: Vec4) -> Vec4:
        """Converts normalized RGBA to [0-255, 0-255, 0-255, 0-1]."""
        res = np.array(rgba, dtype=float)
        res[:3] *= 255.0
        return res
