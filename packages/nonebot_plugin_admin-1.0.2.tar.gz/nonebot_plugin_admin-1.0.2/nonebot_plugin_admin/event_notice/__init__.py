"""Event notice domain."""
