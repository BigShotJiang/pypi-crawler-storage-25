﻿"""Approval domain helpers."""


