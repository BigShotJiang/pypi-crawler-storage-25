"""Broadcast domain."""
