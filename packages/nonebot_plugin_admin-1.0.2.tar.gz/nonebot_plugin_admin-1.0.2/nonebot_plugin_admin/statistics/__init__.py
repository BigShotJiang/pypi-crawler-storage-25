﻿"""Statistics domain helpers."""


