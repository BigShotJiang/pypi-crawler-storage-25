# MundiX Agent — Modelos de IA e Sistema de Skills

## 1. Recomendação de Modelos (Hugging Face)

A escolha dos modelos para o MundiX Agent é baseada em três critérios fundamentais: **inteligência** (capacidade de raciocínio e planejamento), **velocidade** (latência aceitável para uso interativo) e **ausência de censura** (não recusar comandos de pentest). A pesquisa revelou que modelos "instruct" e "thinking" das versões mais recentes (Qwen3, GPT-4) adicionaram censura pesada para comandos ofensivos, enquanto modelos base, abliterated e especializados em cybersecurity mantêm a liberdade necessária.

### Arquitetura Multi-Modelo (Recomendada)

O MundiX Agent deve utilizar modelos diferentes para funções diferentes, otimizando custo, velocidade e qualidade. A tabela abaixo apresenta a recomendação por tier.

| Tier | Função | Modelo HuggingFace | Codinome MundiX | Parâmetros | Justificativa |
|---|---|---|---|---|---|
| **T1 — Cérebro** | Planejamento, decisão de skills, análise de resultados | Qwen2.5-72B-Instruct-abliterated | mx-strategist-72b | 72B | Melhor raciocínio + sem censura via abliteration [1] |
| **T2 — Especialista** | Geração de comandos, interpretação de output, exploits | DeepHat-V1-7B (WhiteRabbitNeo V3) | mx-deephat-7b | 7.6B | Fine-tune de Qwen2.5-Coder em dados de cybersecurity [2] |
| **T3 — Executor** | Parsing rápido, decisões simples, formatação | Qwen2.5-3B-Instruct-abliterated | mx-swift-3b | 3B | Ultra-rápido, sem censura, suficiente para tarefas simples |
| **Backup** | Fallback se T1 estiver lento | Llama-3.1-Minitron-8B-Base | mx-minitron-8b | 8B | 92% no Red Team Benchmark, zero censura [3] |

### Por que estes modelos?

**Qwen2.5 como base:** Testes independentes de Mauricio Giraldo (pesquisador de AI pentesting) demonstraram que o Qwen é o único modelo que consistentemente propõe sequências de comandos ricas e diversas, seguindo o fluxo natural de pentest (Recon, Deep Research, Attacks) sem entrar em loops ou alucinar [1]. Outros modelos (Llama, Mistral, DeepSeek) falharam em manter coerência multi-step.

**Abliteration para remover censura:** As versões "instruct" do Qwen3 adicionaram censura total (0% no Red Team Benchmark [3]). A técnica de abliteration remove o vetor de recusa do modelo sem degradar a inteligência, mantendo a capacidade de raciocínio intacta enquanto elimina bloqueios éticos para comandos de pentest.

**DeepHat V1 7B como especialista:** Este modelo é um fine-tune do Qwen2.5-Coder-7B treinado especificamente em dados de cybersecurity ofensiva e defensiva pela Kindo.ai [2]. Ele entende ferramentas como Nmap, Metasploit, SQLmap nativamente e gera comandos corretos sem necessidade de few-shot examples. Com 131K tokens de contexto, pode processar outputs longos de ferramentas.

**Llama-3.1-Minitron-8B como backup:** Obteve 92% no Red Team AI Benchmark [3], superando todos os outros modelos em tarefas ofensivas (AMSI Bypass, NTLM Relay, EDR Unhooking, etc.). Como modelo base (não instruct), não possui nenhuma camada de censura.

### Integração via Hugging Face Inference API

Todos os modelos estão disponíveis no Hugging Face e podem ser consumidos via Inference API (serverless) ou Inference Endpoints (dedicado). A integração com o MundiX CLI já existe via `ai_provider.py` e utiliza o token `hf_ONl...` para autenticação. A mudança para multi-modelo requer apenas adicionar lógica de roteamento no provider.

```python
# Exemplo de roteamento multi-modelo
MODEL_TIERS = {
    "brain": "Qwen/Qwen2.5-72B-Instruct-abliterated",
    "specialist": "DeepHat/DeepHat-V1-7B",
    "executor": "Qwen/Qwen2.5-3B-Instruct-abliterated",
}

def select_model(task_type: str) -> str:
    if task_type in ["plan", "analyze", "decide"]:
        return MODEL_TIERS["brain"]
    elif task_type in ["command", "exploit", "interpret"]:
        return MODEL_TIERS["specialist"]
    else:
        return MODEL_TIERS["executor"]
```

---

## 2. Sistema de Skills — Catálogo Completo

As skills são arquivos `.md` que o agente carrega dinamicamente para saber **o que fazer**, **quais ferramentas usar**, **como interpretar resultados** e **qual skill acionar em seguida**. Cada skill segue um formato padronizado.

### Formato Padrão de uma Skill

```yaml
---
name: nome_da_skill
phase: N_nome_da_fase
tools: [ferramenta1, ferramenta2]
dependencies: [condição_necessária]
mitre_tactic: TAXXXX (Nome)
---
```

Seguido por seções: **Objetivo**, **Condições de Execução**, **Comandos e Sintaxe**, **Análise de Resultados**, **Próximos Passos**, **Tratamento de Erros**.

### Catálogo de Skills por Fase

#### Fase 1 — Reconhecimento (OSINT Passivo)

| Skill | Ferramentas | Descrição |
|---|---|---|
| `osint_domain_enumeration` | Subfinder, crt.sh, httpx | Descobrir subdomínios válidos via fontes passivas |
| `osint_email_harvesting` | theHarvester, LinkedIn | Coletar e-mails e nomes de funcionários |
| `tech_stack_fingerprinting` | WhatWeb, Wafw00f, curl | Identificar tecnologias, CMS, WAFs |
| `osint_leak_search` | GitHub Dorks, HIBP, Google Dorks | Buscar credenciais vazadas e arquivos sensíveis |

#### Fase 2 — Varredura e Enumeração

| Skill | Ferramentas | Descrição |
|---|---|---|
| `network_port_scan` | Nmap, Masscan | Mapear portas abertas e versões de serviços |
| `web_directory_discovery` | Gobuster, Feroxbuster, FFUF | Descobrir diretórios e arquivos ocultos |
| `smb_rpc_enumeration` | Enum4linux-ng, CrackMapExec, RPCClient | Enumerar shares, usuários e políticas SMB |
| `dns_zone_transfer` | Dig, DNSRecon | Tentar AXFR e enumerar registros DNS |

#### Fase 3 — Análise de Vulnerabilidades

| Skill | Ferramentas | Descrição |
|---|---|---|
| `cve_search_engine` | Searchsploit, Nmap Vulners, NVD API | Buscar CVEs e exploits para serviços encontrados |
| `web_vulnerability_scan` | Nuclei, Nikto | Varredura automatizada de vulns web (XSS, SQLi, RCE) |
| `ssl_tls_analysis` | Testssl.sh, SSLScan | Analisar configuração SSL/TLS e cifras |
| `owasp_top10_manual_test` | Burp Suite, curl, manual | Testes manuais OWASP Top 10 (a ser criada) |

#### Fase 4 — Exploração

| Skill | Ferramentas | Descrição |
|---|---|---|
| `sql_injection_exploitation` | SQLmap | Explorar SQLi para extrair dados e obter shell |
| `bruteforce_authentication` | Hydra, CrackMapExec, Medusa | Força bruta e password spraying |
| `metasploit_auto_exploit` | Metasploit Framework | Exploração automatizada via Metasploit (a ser criada) |
| `file_upload_exploitation` | Manual, Weevely | Explorar upload de arquivos para webshell (a ser criada) |

#### Fase 5 — Pós-Exploração

| Skill | Ferramentas | Descrição |
|---|---|---|
| `linux_privilege_escalation` | LinPEAS, sudo, SUID, capabilities | Escalar privilégios em Linux |
| `hash_dumping_and_cracking` | Hashcat, John, Mimikatz, Impacket | Extrair e quebrar hashes de senha |
| `windows_privilege_escalation` | WinPEAS, PowerUp | Escalar privilégios em Windows (a ser criada) |
| `lateral_movement_psexec` | Impacket, CrackMapExec | Movimento lateral via PsExec/WMI (a ser criada) |

#### Fase 6 — Relatório

| Skill | Ferramentas | Descrição |
|---|---|---|
| `generate_pentest_report` | Markdown, Pandoc | Gerar relatório completo com achados e recomendações |
| `mitre_attack_mapping` | Manual | Mapear achados para MITRE ATT&CK (a ser criada) |
| `executive_summary` | Manual | Gerar sumário executivo para gestores (a ser criada) |

### Skills Criadas (16 de 23)

As seguintes 16 skills já foram escritas com comandos, análise e tratamento de erros completos:

1. `osint_domain_enumeration.md`
2. `osint_email_harvesting.md`
3. `tech_stack_fingerprinting.md`
4. `osint_leak_search.md`
5. `network_port_scan.md`
6. `web_directory_discovery.md`
7. `smb_rpc_enumeration.md`
8. `dns_zone_transfer.md`
9. `cve_search_engine.md`
10. `web_vulnerability_scan.md`
11. `ssl_tls_analysis.md`
12. `sql_injection_exploitation.md`
13. `bruteforce_authentication.md`
14. `linux_privilege_escalation.md`
15. `hash_dumping_and_cracking.md`
16. `generate_pentest_report.md`

### Skills Pendentes (7 de 23)

As seguintes skills precisam ser criadas:

1. `owasp_top10_manual_test.md` — Testes manuais OWASP Top 10
2. `metasploit_auto_exploit.md` — Exploração automatizada via Metasploit
3. `file_upload_exploitation.md` — Exploração de upload de arquivos
4. `windows_privilege_escalation.md` — Escalação de privilégios Windows
5. `lateral_movement_psexec.md` — Movimento lateral via PsExec/WMI
6. `mitre_attack_mapping.md` — Mapeamento MITRE ATT&CK
7. `executive_summary.md` — Sumário executivo para gestores

---

## 3. Fluxo do Autopilot 5 (Exemplo Completo)

Quando o usuário digita um alvo no modo `/autopilot 5`, o agente executa o seguinte fluxo autônomo:

```
Usuário: "Faça um pentest completo em example.com"
         │
         ▼
[T1 Brain] Analisa o alvo → Classifica como "web"
         │
         ▼
[Fase 1] Carrega skills de reconhecimento
         ├── osint_domain_enumeration → encontra 15 subdomínios
         ├── osint_email_harvesting → encontra 8 e-mails
         ├── tech_stack_fingerprinting → WordPress 5.8, Apache 2.4.41
         └── osint_leak_search → 2 credenciais em vazamentos
         │
         ▼
[T1 Brain] Analisa resultados → Decide prioridades
         │
         ▼
[Fase 2] Carrega skills de varredura
         ├── network_port_scan → 22, 80, 443, 3306 abertos
         ├── web_directory_discovery → /wp-admin, /backup.sql encontrados
         └── dns_zone_transfer → AXFR bloqueado
         │
         ▼
[T1 Brain] Analisa → WordPress + MySQL + backup.sql = alto risco
         │
         ▼
[Fase 3] Carrega skills de vulnerabilidade
         ├── cve_search_engine → CVE-2024-XXXX (WordPress RCE)
         ├── web_vulnerability_scan → SQLi em /search?q=
         └── ssl_tls_analysis → TLS 1.0 habilitado
         │
         ▼
[T2 Specialist] Gera comandos de exploração específicos
         │
         ▼
[Fase 4] Carrega skills de exploração
         ├── sql_injection_exploitation → dump do banco, hashes obtidos
         └── bruteforce_authentication → admin:Password123! válido
         │
         ▼
[Fase 5] Carrega skills de pós-exploração
         ├── linux_privilege_escalation → root via sudo misconfiguration
         └── hash_dumping_and_cracking → 5 senhas quebradas
         │
         ▼
[Fase 6] Gera relatório
         └── generate_pentest_report → PDF com 12 vulnerabilidades
```

---

## Referências

[1]: Giraldo, M. "How I Found the Best LLM Model for My AI Pentesting Framework." Medium, Jun 2025. https://medium.com/@mgiraldo_36166/how-i-found-the-best-llm-model-for-my-ai-pentesting-framework-ee5aae0d0103

[2]: Kindo.ai. "DeepHat V1 7B." Hugging Face, 2025. https://huggingface.co/DeepHat/DeepHat-V1-7B

[3]: Toxy4ny. "Red Team AI Benchmark: Evaluating Uncensored LLMs for Offensive Security." Dev.to, Nov 2025. https://dev.to/toxy4ny/red-team-ai-benchmark-evaluating-uncensored-llms-for-offensive-security-1fol

[4]: vxcontrol. "PentAGI — Fully Autonomous AI Pentesting Agent." GitHub, 2025. https://github.com/vxcontrol/pentagi

[5]: AutoPentester. "AutoPentester: Towards Automated Penetration Testing with LLM Agents." arXiv, 2025. https://arxiv.org/html/2510.05605v1

[6]: Meta FoundationAI. "SecurityLLM: A Cybersecurity-Focused LLM." arXiv, Jan 2026. https://arxiv.org/html/2601.21051v1
