# MundiX Autonomous Pentesting Agent: Blueprint de Arquitetura e Skills

**Autor:** Manus AI & Equipe MundiX
**Data:** Março de 2026

Este documento define a arquitetura, o sistema de skills e o fluxo de execução para transformar o MundiX de um copiloto reativo em um **Agente Autônomo de Pentest**. A arquitetura é baseada nas melhores práticas da indústria, incluindo o PTES (Penetration Testing Execution Standard), OWASP Web Security Testing Guide (WSTG) v4.2 e o framework MITRE ATT&CK [1] [2] [3].

---

## 1. Visão Geral da Arquitetura

Para que o MundiX opere de forma autônoma (Autopilot 5), ele precisa de uma arquitetura baseada em agentes (Agentic Workflow), semelhante a sistemas acadêmicos e open-source de ponta como PentAGI e AutoPentester [4] [5].

A arquitetura é composta por 4 pilares:

1. **Core Agent (O Cérebro):** O LLM principal (ex: MX-RedHawk) atuando como orquestrador. Ele recebe o alvo, analisa o estado atual, escolhe a próxima skill, executa, avalia o resultado e decide o próximo passo.
2. **Skill System (O Conhecimento):** Um repositório de arquivos `.md` modulares. Cada arquivo ensina o agente a executar uma técnica específica, usar uma ferramenta e interpretar seus resultados.
3. **State & Memory (O Contexto):** 
   - *Pentest Tree (PTT):* Uma árvore de estado que rastreia quais fases foram concluídas e quais vulnerabilidades foram encontradas.
   - *Knowledge Graph:* Relações entre ativos descobertos (ex: IP -> Porta -> Serviço -> Versão -> CVE).
4. **Agent Computer Interface (ACI):** A interface segura (sandbox/Kali Linux) onde o agente executa os comandos reais e captura o `stdout`/`stderr`.

---

## 2. O Sistema de Skills (.md)

O grande diferencial desta arquitetura é que o conhecimento não está "hardcoded" no código Python, mas sim em arquivos Markdown (`.md`). Isso permite que a comunidade ou a equipe atualize as táticas rapidamente.

Cada arquivo de Skill (ex: `nmap_stealth_scan.md`) deve conter a seguinte estrutura:

```markdown
---
name: nmap_stealth_scan
phase: scanning_enumeration
tools: [nmap]
dependencies: [target_ip_identified]
mitre_tactic: TA0043 (Reconnaissance)
---

# Objetivo
Realizar uma varredura furtiva de portas para identificar serviços rodando no alvo sem disparar alarmes básicos de IDS/IPS.

# Condições de Execução
- O IP ou domínio do alvo foi confirmado.
- O escopo permite varredura ativa.

# Comandos e Sintaxe
Use o seguinte template para a execução:
`nmap -sS -p- -T4 --min-rate 1000 -oN {workspace}/nmap_stealth.txt {target}`

# Análise de Resultados (Como interpretar)
- Se a porta 80/443 estiver aberta: Acione a skill `web_directory_bruteforce` e `nikto_scan`.
- Se a porta 445/139 estiver aberta: Acione a skill `smb_enumeration`.
- Se todas as portas estiverem "filtered": O host pode estar atrás de um WAF/Firewall. Acione a skill `waf_detection`.

# Tratamento de Erros
- Se o nmap retornar "Host seems down": Tente adicionar a flag `-Pn` (pular ping sweep).
```

Esta estrutura serve tanto como **RAG (Retrieval-Augmented Generation)** para o LLM ler e aprender, quanto como **Playbook** para execução automatizada.

---

## 3. Fases do Pentest e Catálogo de Skills

O fluxo autônomo do MundiX seguirá as fases do PTES. Abaixo está o mapeamento das skills necessárias para cada fase.

### Fase 1: Reconhecimento (Intelligence Gathering)
**Objetivo:** Mapear a superfície de ataque externa sem tocar diretamente nos servidores de forma agressiva.
*Skills (.md):*
- `osint_domain_enumeration.md` (Subfinder, Amass, crt.sh)
- `osint_email_harvesting.md` (theHarvester, Hunter.io)
- `osint_leak_search.md` (Dehashed, HaveIBeenPwned)
- `tech_stack_fingerprinting.md` (Wappalyzer, WhatWeb)

### Fase 2: Varredura e Enumeração (Scanning)
**Objetivo:** Interagir com o alvo para descobrir portas, serviços e caminhos ocultos.
*Skills (.md):*
- `network_port_scan.md` (Nmap, Masscan)
- `web_directory_discovery.md` (Gobuster, Feroxbuster)
- `smb_rpc_enumeration.md` (Enum4linux, SMBClient)
- `dns_zone_transfer.md` (Dig, Fierce)

### Fase 3: Análise de Vulnerabilidades (Vulnerability Analysis)
**Objetivo:** Identificar falhas conhecidas (CVEs) ou misconfigurations nos serviços descobertos.
*Skills (.md):*
- `cve_search_engine.md` (Searchsploit, Vulners)
- `web_vulnerability_scan.md` (Nuclei, Nikto)
- `ssl_tls_analysis.md` (Testssl.sh)
- `owasp_top_10_checks.md` (Testes específicos do WSTG v4.2)

### Fase 4: Exploração (Exploitation / Initial Access)
**Objetivo:** Obter acesso inicial ao sistema (MITRE TA0001).
*Skills (.md):*
- `metasploit_auto_exploit.md` (Msfconsole rc scripts)
- `sql_injection_exploitation.md` (SQLmap)
- `bruteforce_authentication.md` (Hydra, CrackMapExec)
- `file_upload_bypass.md` (Bypass de restrições de upload web)

### Fase 5: Pós-Exploração (Post-Exploitation)
**Objetivo:** Escalação de privilégios, movimento lateral e persistência (MITRE TA0004, TA0008).
*Skills (.md):*
- `linux_privilege_escalation.md` (LinPEAS)
- `windows_privilege_escalation.md` (WinPEAS, BloodHound)
- `hash_dumping_and_cracking.md` (Mimikatz, Hashcat, John)
- `lateral_movement_psexec.md` (Impacket)

### Fase 6: Relatório (Reporting)
**Objetivo:** Consolidar os achados em um relatório executivo e técnico.
*Skills (.md):*
- `generate_executive_summary.md`
- `generate_technical_findings.md`
- `map_to_mitre_attack.md`

---

## 4. O Fluxo de Execução (Exemplo: Autopilot 5)

Quando o usuário digita `/project target example.com` e `/autopilot 5`, o seguinte loop autônomo é iniciado:

1. **Planejamento Inicial:** O Core Agent lê o alvo e carrega as skills da Fase 1 (Reconhecimento).
2. **Execução (Loop):**
   - O agente seleciona a skill `osint_domain_enumeration.md`.
   - Lê a sintaxe, gera o comando (ex: `subfinder -d example.com`) e executa no terminal.
   - O *Results Verifier* captura o output.
3. **Análise e Atualização de Estado:**
   - O agente lê o output, extrai os subdomínios encontrados e salva no *Knowledge Graph*.
4. **Decisão Dinâmica:**
   - Baseado nos subdomínios encontrados, o agente decide avançar para a Fase 2.
   - Ele carrega a skill `network_port_scan.md` e executa o Nmap contra os subdomínios.
5. **Tratamento de Beco Sem Saída (Repetition Identifier):**
   - Se uma ferramenta falhar 3 vezes, o agente abandona aquela tática e busca uma skill alternativa (ex: se o Nmap for bloqueado, tenta varredura passiva via Shodan).
6. **Conclusão:**
   - Após esgotar as fases permitidas no escopo, o agente aciona as skills da Fase 6 e gera o relatório final em PDF/Markdown.

---

## 5. Próximos Passos para Implementação

Para transformar essa visão em realidade no MundiX CLI, recomendo a seguinte ordem de desenvolvimento:

1. **Criar o Motor de Skills:** Desenvolver o parser em Python que lê os arquivos `.md` e os converte em prompts de sistema dinâmicos para o LLM.
2. **Criar o Repositório de Skills:** Escrever os primeiros 10 arquivos `.md` focados apenas em Reconhecimento e Varredura (Fases 1 e 2).
3. **Implementar o Loop Autônomo:** Criar a lógica de `while True` no CLI onde o LLM decide a próxima skill, executa o comando, lê o output e decide novamente, até atingir o objetivo.
4. **Mecanismo de Segurança:** Garantir que comandos destrutivos (Fase 4 e 5) exijam confirmação do usuário se o Autopilot for < 5.

---
### Referências
[1] PTES - Penetration Testing Execution Standard. Disponível em: http://www.pentest-standard.org/
[2] OWASP Web Security Testing Guide v4.2. Disponível em: https://owasp.org/www-project-web-security-testing-guide/v42/
[3] MITRE ATT&CK Enterprise Matrix. Disponível em: https://attack.mitre.org/matrices/enterprise/
[4] PentAGI: Fully autonomous AI Agents system. Disponível em: https://github.com/vxcontrol/pentagi
[5] AutoPentester: An LLM Agent-based Framework for Automated Pentesting. Disponível em: https://arxiv.org/html/2510.05605v1
