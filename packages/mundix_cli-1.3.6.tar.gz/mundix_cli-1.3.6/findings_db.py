"""
MundiX Findings Database — Cross-Engagement Persistence
========================================================

SQLite-based persistence layer that stores findings, vulnerabilities,
attack chains, and engagement history across sessions. This gives
the agent long-term memory about targets and discovered weaknesses.

Usage:
    from findings_db import FindingsDB
    
    db = FindingsDB()
    db.save_finding("example.com", "CVE-2024-1234", "critical", {...})
    history = db.get_target_history("example.com")
"""

import json
import os
import sqlite3
import hashlib
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


MUNDIX_DIR = Path.home() / ".mundix"
DB_PATH = MUNDIX_DIR / "findings.db"


class FindingsDB:
    """SQLite-based persistence for pentest findings across engagements."""

    SCHEMA_VERSION = 1

    def __init__(self, db_path: str = None):
        self.db_path = db_path or str(DB_PATH)
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        self._init_db()

    def _get_conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        return conn

    def _init_db(self):
        """Initialize database schema."""
        conn = self._get_conn()
        try:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS schema_version (
                    version INTEGER PRIMARY KEY
                );
                INSERT OR IGNORE INTO schema_version (version) VALUES (1);

                -- Engagement history
                CREATE TABLE IF NOT EXISTS engagements (
                    id TEXT PRIMARY KEY,
                    target TEXT NOT NULL,
                    engagement_type TEXT DEFAULT 'web',
                    started_at TEXT NOT NULL,
                    completed_at TEXT,
                    status TEXT DEFAULT 'running',
                    skills_total INTEGER DEFAULT 0,
                    skills_completed INTEGER DEFAULT 0,
                    findings_count INTEGER DEFAULT 0,
                    risk_score REAL DEFAULT 0.0,
                    report_path TEXT,
                    metadata TEXT DEFAULT '{}'
                );
                CREATE INDEX IF NOT EXISTS idx_eng_target ON engagements(target);
                CREATE INDEX IF NOT EXISTS idx_eng_status ON engagements(status);

                -- Discovered hosts
                CREATE TABLE IF NOT EXISTS hosts (
                    id TEXT PRIMARY KEY,
                    engagement_id TEXT,
                    ip TEXT,
                    hostname TEXT,
                    os TEXT,
                    source TEXT DEFAULT 'scan',
                    first_seen TEXT NOT NULL,
                    last_seen TEXT NOT NULL,
                    FOREIGN KEY (engagement_id) REFERENCES engagements(id)
                );
                CREATE INDEX IF NOT EXISTS idx_hosts_ip ON hosts(ip);
                CREATE INDEX IF NOT EXISTS idx_hosts_hostname ON hosts(hostname);

                -- Discovered ports/services
                CREATE TABLE IF NOT EXISTS services (
                    id TEXT PRIMARY KEY,
                    host_id TEXT,
                    port INTEGER NOT NULL,
                    protocol TEXT DEFAULT 'tcp',
                    service TEXT,
                    version TEXT,
                    banner TEXT,
                    source TEXT DEFAULT 'nmap',
                    first_seen TEXT NOT NULL,
                    last_seen TEXT NOT NULL,
                    FOREIGN KEY (host_id) REFERENCES hosts(id)
                );
                CREATE INDEX IF NOT EXISTS idx_svc_host ON services(host_id);
                CREATE INDEX IF NOT EXISTS idx_svc_service ON services(service);

                -- Vulnerabilities / Findings
                CREATE TABLE IF NOT EXISTS findings (
                    id TEXT PRIMARY KEY,
                    engagement_id TEXT,
                    host_id TEXT,
                    service_id TEXT,
                    finding_type TEXT NOT NULL,
                    title TEXT NOT NULL,
                    description TEXT,
                    severity TEXT DEFAULT 'medium',
                    cvss REAL DEFAULT 0.0,
                    cve_id TEXT,
                    evidence TEXT,
                    remediation TEXT,
                    status TEXT DEFAULT 'open',
                    found_at TEXT NOT NULL,
                    confirmed_at TEXT,
                    source TEXT DEFAULT 'auto',
                    skill_name TEXT,
                    metadata TEXT DEFAULT '{}',
                    FOREIGN KEY (engagement_id) REFERENCES engagements(id),
                    FOREIGN KEY (host_id) REFERENCES hosts(id),
                    FOREIGN KEY (service_id) REFERENCES services(id)
                );
                CREATE INDEX IF NOT EXISTS idx_find_engagement ON findings(engagement_id);
                CREATE INDEX IF NOT EXISTS idx_find_severity ON findings(severity);
                CREATE INDEX IF NOT EXISTS idx_find_cve ON findings(cve_id);
                CREATE INDEX IF NOT EXISTS idx_find_status ON findings(status);
                CREATE INDEX IF NOT EXISTS idx_find_host ON findings(host_id);

                -- Attack chains (from Knowledge Graph)
                CREATE TABLE IF NOT EXISTS attack_chains (
                    id TEXT PRIMARY KEY,
                    engagement_id TEXT,
                    chain_path TEXT NOT NULL,
                    chain_labels TEXT NOT NULL,
                    weight REAL DEFAULT 0.0,
                    risk_level TEXT DEFAULT 'high',
                    discovered_at TEXT NOT NULL,
                    FOREIGN KEY (engagement_id) REFERENCES engagements(id)
                );

                -- Credentials discovered
                CREATE TABLE IF NOT EXISTS credentials (
                    id TEXT PRIMARY KEY,
                    engagement_id TEXT,
                    host_id TEXT,
                    service TEXT,
                    username TEXT,
                    password_hash TEXT,
                    password_clear TEXT,
                    auth_type TEXT DEFAULT 'password',
                    source TEXT DEFAULT 'bruteforce',
                    found_at TEXT NOT NULL,
                    FOREIGN KEY (engagement_id) REFERENCES engagements(id),
                    FOREIGN KEY (host_id) REFERENCES hosts(id)
                );
                CREATE INDEX IF NOT EXISTS idx_cred_host ON credentials(host_id);

                -- Auto-generated skills log
                CREATE TABLE IF NOT EXISTS auto_skills (
                    id TEXT PRIMARY KEY,
                    cve_id TEXT,
                    product TEXT,
                    version TEXT,
                    skill_filename TEXT NOT NULL,
                    generated_at TEXT NOT NULL,
                    source TEXT DEFAULT 'nvd-auto',
                    cvss REAL DEFAULT 0.0,
                    used_count INTEGER DEFAULT 0,
                    success_count INTEGER DEFAULT 0
                );
                CREATE INDEX IF NOT EXISTS idx_askill_cve ON auto_skills(cve_id);

                -- Learnings (cross-engagement knowledge)
                CREATE TABLE IF NOT EXISTS learnings (
                    id TEXT PRIMARY KEY,
                    category TEXT NOT NULL,
                    key TEXT NOT NULL,
                    value TEXT NOT NULL,
                    confidence REAL DEFAULT 0.5,
                    learned_at TEXT NOT NULL,
                    used_count INTEGER DEFAULT 0,
                    UNIQUE(category, key)
                );
                CREATE INDEX IF NOT EXISTS idx_learn_category ON learnings(category);
            """)
            conn.commit()
        finally:
            conn.close()

    # --- Engagement Operations ---

    def start_engagement(self, target: str, engagement_type: str = "web",
                        metadata: Dict = None) -> str:
        """Record a new engagement. Returns engagement ID."""
        eng_id = hashlib.md5(f"{target}:{datetime.now().isoformat()}".encode()).hexdigest()[:16]
        conn = self._get_conn()
        try:
            conn.execute(
                "INSERT INTO engagements (id, target, engagement_type, started_at, metadata) "
                "VALUES (?, ?, ?, ?, ?)",
                (eng_id, target, engagement_type, datetime.now().isoformat(),
                 json.dumps(metadata or {}))
            )
            conn.commit()
        finally:
            conn.close()
        return eng_id

    def complete_engagement(self, eng_id: str, risk_score: float = 0.0,
                           report_path: str = None):
        """Mark an engagement as completed."""
        conn = self._get_conn()
        try:
            # Count findings
            row = conn.execute(
                "SELECT COUNT(*) as cnt FROM findings WHERE engagement_id = ?", (eng_id,)
            ).fetchone()
            findings_count = row["cnt"] if row else 0

            conn.execute(
                "UPDATE engagements SET status = 'completed', completed_at = ?, "
                "risk_score = ?, report_path = ?, findings_count = ? WHERE id = ?",
                (datetime.now().isoformat(), risk_score, report_path, findings_count, eng_id)
            )
            conn.commit()
        finally:
            conn.close()

    def get_target_history(self, target: str) -> List[Dict]:
        """Get all past engagements for a target."""
        conn = self._get_conn()
        try:
            rows = conn.execute(
                "SELECT * FROM engagements WHERE target = ? ORDER BY started_at DESC",
                (target,)
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    # --- Host Operations ---

    def save_host(self, engagement_id: str, ip: str, hostname: str = "",
                  os_info: str = "", source: str = "scan") -> str:
        """Save a discovered host. Returns host ID."""
        host_id = hashlib.md5(f"{ip}:{hostname}".encode()).hexdigest()[:16]
        now = datetime.now().isoformat()
        conn = self._get_conn()
        try:
            conn.execute(
                "INSERT INTO hosts (id, engagement_id, ip, hostname, os, source, first_seen, last_seen) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?) "
                "ON CONFLICT(id) DO UPDATE SET last_seen = ?, os = COALESCE(?, os)",
                (host_id, engagement_id, ip, hostname, os_info, source, now, now, now, os_info)
            )
            conn.commit()
        finally:
            conn.close()
        return host_id

    # --- Service Operations ---

    def save_service(self, host_id: str, port: int, protocol: str = "tcp",
                     service: str = "", version: str = "", banner: str = "",
                     source: str = "nmap") -> str:
        """Save a discovered service. Returns service ID."""
        svc_id = hashlib.md5(f"{host_id}:{port}:{protocol}".encode()).hexdigest()[:16]
        now = datetime.now().isoformat()
        conn = self._get_conn()
        try:
            conn.execute(
                "INSERT INTO services (id, host_id, port, protocol, service, version, banner, source, first_seen, last_seen) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) "
                "ON CONFLICT(id) DO UPDATE SET last_seen = ?, version = COALESCE(?, version), banner = COALESCE(?, banner)",
                (svc_id, host_id, port, protocol, service, version, banner, source, now, now, now, version, banner)
            )
            conn.commit()
        finally:
            conn.close()
        return svc_id

    # --- Finding Operations ---

    def save_finding(self, engagement_id: str, host_id: str = None,
                     service_id: str = None, finding_type: str = "vulnerability",
                     title: str = "", description: str = "", severity: str = "medium",
                     cvss: float = 0.0, cve_id: str = None, evidence: str = "",
                     remediation: str = "", skill_name: str = "",
                     metadata: Dict = None) -> str:
        """Save a finding. Returns finding ID."""
        find_id = hashlib.md5(
            f"{engagement_id}:{title}:{cve_id or ''}:{datetime.now().isoformat()}".encode()
        ).hexdigest()[:16]
        conn = self._get_conn()
        try:
            conn.execute(
                "INSERT INTO findings (id, engagement_id, host_id, service_id, finding_type, "
                "title, description, severity, cvss, cve_id, evidence, remediation, "
                "found_at, source, skill_name, metadata) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'auto', ?, ?)",
                (find_id, engagement_id, host_id, service_id, finding_type,
                 title, description, severity, cvss, cve_id, evidence, remediation,
                 datetime.now().isoformat(), skill_name, json.dumps(metadata or {}))
            )
            conn.commit()
        finally:
            conn.close()
        return find_id

    def get_findings_by_target(self, target: str, severity: str = None) -> List[Dict]:
        """Get all findings for a target across all engagements."""
        conn = self._get_conn()
        try:
            query = (
                "SELECT f.*, e.target FROM findings f "
                "JOIN engagements e ON f.engagement_id = e.id "
                "WHERE e.target = ?"
            )
            params = [target]
            if severity:
                query += " AND f.severity = ?"
                params.append(severity)
            query += " ORDER BY f.cvss DESC, f.found_at DESC"
            rows = conn.execute(query, params).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    def get_known_cves_for_service(self, service: str, version: str = "") -> List[Dict]:
        """Check if we've seen CVEs for this service before (cross-engagement)."""
        conn = self._get_conn()
        try:
            query = (
                "SELECT DISTINCT f.cve_id, f.severity, f.cvss, f.title, f.description "
                "FROM findings f "
                "JOIN services s ON f.service_id = s.id "
                "WHERE s.service LIKE ? AND f.cve_id IS NOT NULL"
            )
            params = [f"%{service}%"]
            if version:
                query += " AND s.version LIKE ?"
                params.append(f"%{version}%")
            rows = conn.execute(query, params).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    # --- Attack Chain Operations ---

    def save_attack_chain(self, engagement_id: str, chain_path: List[str],
                          chain_labels: List[str], weight: float = 0.0,
                          risk_level: str = "high") -> str:
        """Save a discovered attack chain."""
        chain_id = hashlib.md5(
            f"{engagement_id}:{'→'.join(chain_labels)}".encode()
        ).hexdigest()[:16]
        conn = self._get_conn()
        try:
            conn.execute(
                "INSERT OR REPLACE INTO attack_chains (id, engagement_id, chain_path, "
                "chain_labels, weight, risk_level, discovered_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                (chain_id, engagement_id, json.dumps(chain_path),
                 json.dumps(chain_labels), weight, risk_level,
                 datetime.now().isoformat())
            )
            conn.commit()
        finally:
            conn.close()
        return chain_id

    # --- Credential Operations ---

    def save_credential(self, engagement_id: str, host_id: str = None,
                        service: str = "", username: str = "",
                        password_hash: str = "", password_clear: str = "",
                        auth_type: str = "password", source: str = "bruteforce") -> str:
        """Save a discovered credential."""
        cred_id = hashlib.md5(
            f"{host_id}:{service}:{username}:{datetime.now().isoformat()}".encode()
        ).hexdigest()[:16]
        conn = self._get_conn()
        try:
            conn.execute(
                "INSERT INTO credentials (id, engagement_id, host_id, service, "
                "username, password_hash, password_clear, auth_type, source, found_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (cred_id, engagement_id, host_id, service, username,
                 password_hash, password_clear, auth_type, source,
                 datetime.now().isoformat())
            )
            conn.commit()
        finally:
            conn.close()
        return cred_id

    # --- Auto-Skill Tracking ---

    def log_auto_skill(self, cve_id: str, product: str, version: str,
                       skill_filename: str, cvss: float = 0.0,
                       source: str = "nvd-auto") -> str:
        """Log an auto-generated skill."""
        skill_id = hashlib.md5(f"{cve_id}:{skill_filename}".encode()).hexdigest()[:16]
        conn = self._get_conn()
        try:
            conn.execute(
                "INSERT OR IGNORE INTO auto_skills (id, cve_id, product, version, "
                "skill_filename, generated_at, source, cvss) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (skill_id, cve_id, product, version, skill_filename,
                 datetime.now().isoformat(), source, cvss)
            )
            conn.commit()
        finally:
            conn.close()
        return skill_id

    def increment_skill_usage(self, skill_filename: str, success: bool = False):
        """Track skill usage and success rate."""
        conn = self._get_conn()
        try:
            conn.execute(
                "UPDATE auto_skills SET used_count = used_count + 1 WHERE skill_filename = ?",
                (skill_filename,)
            )
            if success:
                conn.execute(
                    "UPDATE auto_skills SET success_count = success_count + 1 WHERE skill_filename = ?",
                    (skill_filename,)
                )
            conn.commit()
        finally:
            conn.close()

    # --- Learnings (Cross-Engagement Knowledge) ---

    def save_learning(self, category: str, key: str, value: str,
                      confidence: float = 0.5):
        """Save a learning that persists across engagements."""
        learn_id = hashlib.md5(f"{category}:{key}".encode()).hexdigest()[:16]
        conn = self._get_conn()
        try:
            conn.execute(
                "INSERT INTO learnings (id, category, key, value, confidence, learned_at) "
                "VALUES (?, ?, ?, ?, ?, ?) "
                "ON CONFLICT(category, key) DO UPDATE SET "
                "value = ?, confidence = MAX(confidence, ?), learned_at = ?",
                (learn_id, category, key, value, confidence, datetime.now().isoformat(),
                 value, confidence, datetime.now().isoformat())
            )
            conn.commit()
        finally:
            conn.close()

    def get_learnings(self, category: str = None, min_confidence: float = 0.0) -> List[Dict]:
        """Retrieve learnings, optionally filtered by category."""
        conn = self._get_conn()
        try:
            query = "SELECT * FROM learnings WHERE confidence >= ?"
            params: list = [min_confidence]
            if category:
                query += " AND category = ?"
                params.append(category)
            query += " ORDER BY confidence DESC, used_count DESC"
            rows = conn.execute(query, params).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    def get_learning(self, category: str, key: str) -> Optional[str]:
        """Get a specific learning value."""
        conn = self._get_conn()
        try:
            row = conn.execute(
                "SELECT value FROM learnings WHERE category = ? AND key = ?",
                (category, key)
            ).fetchone()
            return row["value"] if row else None
        finally:
            conn.close()

    # --- Statistics ---

    def get_stats(self) -> Dict[str, Any]:
        """Get overall database statistics."""
        conn = self._get_conn()
        try:
            stats = {}
            for table in ["engagements", "hosts", "services", "findings",
                         "attack_chains", "credentials", "auto_skills", "learnings"]:
                row = conn.execute(f"SELECT COUNT(*) as cnt FROM {table}").fetchone()
                stats[table] = row["cnt"] if row else 0

            # Severity breakdown
            rows = conn.execute(
                "SELECT severity, COUNT(*) as cnt FROM findings GROUP BY severity"
            ).fetchall()
            stats["severity_breakdown"] = {r["severity"]: r["cnt"] for r in rows}

            # Recent activity
            row = conn.execute(
                "SELECT MAX(started_at) as latest FROM engagements"
            ).fetchone()
            stats["last_engagement"] = row["latest"] if row else None

            return stats
        finally:
            conn.close()

    def get_target_intelligence(self, target: str) -> Dict[str, Any]:
        """
        Get comprehensive intelligence for a target from all past engagements.
        This is what makes the agent SMART — it remembers what it found before.
        """
        conn = self._get_conn()
        try:
            intel = {
                "target": target,
                "engagements": [],
                "known_hosts": [],
                "known_services": [],
                "known_vulns": [],
                "known_creds_count": 0,
                "attack_chains": [],
                "learnings": [],
            }

            # Past engagements
            engs = conn.execute(
                "SELECT * FROM engagements WHERE target = ? ORDER BY started_at DESC LIMIT 10",
                (target,)
            ).fetchall()
            intel["engagements"] = [dict(e) for e in engs]
            eng_ids = [e["id"] for e in engs]

            if not eng_ids:
                return intel

            placeholders = ",".join("?" * len(eng_ids))

            # Known hosts
            hosts = conn.execute(
                f"SELECT DISTINCT ip, hostname, os FROM hosts WHERE engagement_id IN ({placeholders})",
                eng_ids
            ).fetchall()
            intel["known_hosts"] = [dict(h) for h in hosts]

            # Known services
            services = conn.execute(
                f"SELECT DISTINCT s.port, s.protocol, s.service, s.version "
                f"FROM services s JOIN hosts h ON s.host_id = h.id "
                f"WHERE h.engagement_id IN ({placeholders})",
                eng_ids
            ).fetchall()
            intel["known_services"] = [dict(s) for s in services]

            # Known vulnerabilities
            vulns = conn.execute(
                f"SELECT title, severity, cvss, cve_id, status "
                f"FROM findings WHERE engagement_id IN ({placeholders}) "
                f"ORDER BY cvss DESC LIMIT 50",
                eng_ids
            ).fetchall()
            intel["known_vulns"] = [dict(v) for v in vulns]

            # Credential count (don't expose details)
            row = conn.execute(
                f"SELECT COUNT(*) as cnt FROM credentials WHERE engagement_id IN ({placeholders})",
                eng_ids
            ).fetchone()
            intel["known_creds_count"] = row["cnt"] if row else 0

            # Attack chains
            chains = conn.execute(
                f"SELECT chain_labels, weight, risk_level FROM attack_chains "
                f"WHERE engagement_id IN ({placeholders}) ORDER BY weight DESC LIMIT 10",
                eng_ids
            ).fetchall()
            intel["attack_chains"] = [dict(c) for c in chains]

            return intel
        finally:
            conn.close()

    def format_as_ai_context(self, target: str, max_lines: int = 30) -> str:
        """
        Format target intelligence as context for the AI Brain.
        This is injected into the agent's prompt for informed decision-making.
        """
        intel = self.get_target_intelligence(target)

        if not intel["engagements"]:
            return ""

        lines = [
            f"## Prior Intelligence for {target}",
            f"Past engagements: {len(intel['engagements'])}",
        ]

        if intel["known_hosts"]:
            hosts_str = ", ".join(f"{h['ip']} ({h['hostname']})" for h in intel["known_hosts"][:5])
            lines.append(f"Known hosts: {hosts_str}")

        if intel["known_services"]:
            svcs = ", ".join(f"{s['port']}/{s['service']} {s['version']}" for s in intel["known_services"][:10])
            lines.append(f"Known services: {svcs}")

        if intel["known_vulns"]:
            lines.append(f"Known vulnerabilities ({len(intel['known_vulns'])}):")
            for v in intel["known_vulns"][:10]:
                cve = f" [{v['cve_id']}]" if v.get("cve_id") else ""
                lines.append(f"  - [{v['severity'].upper()}] {v['title']}{cve} (CVSS {v['cvss']})")

        if intel["known_creds_count"]:
            lines.append(f"Known credentials: {intel['known_creds_count']} (from prior engagements)")

        if intel["attack_chains"]:
            lines.append("Known attack chains:")
            for c in intel["attack_chains"][:3]:
                labels = json.loads(c["chain_labels"])
                lines.append(f"  - {'→'.join(labels)} (weight: {c['weight']:.1f})")

        return "\n".join(lines[:max_lines])
