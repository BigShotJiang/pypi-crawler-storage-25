---
name: smb_rpc_enumeration
phase: 2_scanning_enumeration
tools: [enum4linux-ng, smbclient, crackmapexec, rpcclient]
dependencies: [smb_port_open]
mitre_tactic: TA0007 (Discovery)
---

# Objetivo
Enumerar compartilhamentos SMB, usuários, grupos, políticas de senha e informações do domínio Active Directory via protocolos SMB (445) e RPC (135/139).

# Condições de Execução
- Porta 445 (SMB) e/ou 139 (NetBIOS) está aberta no alvo.
- O escopo permite enumeração ativa de serviços.

# Comandos e Sintaxe

## 1. Enum4linux-ng (Enumeração Completa)
```bash
enum4linux-ng -A {target_ip} -oJ {workspace}/enum4linux_results 2>&1 | tee {workspace}/enum4linux_output.txt
```

## 2. CrackMapExec (Enumeração de Shares e Null Session)
```bash
crackmapexec smb {target_ip} --shares -u '' -p '' 2>&1 | tee {workspace}/cme_null_shares.txt
crackmapexec smb {target_ip} --shares -u 'guest' -p '' 2>&1 | tee {workspace}/cme_guest_shares.txt
```

## 3. SMBClient (Listagem de Shares)
```bash
smbclient -L //{target_ip}/ -N 2>&1 | tee {workspace}/smbclient_shares.txt
```

## 4. RPCClient (Enumeração de Usuários via Null Session)
```bash
rpcclient -U "" -N {target_ip} -c "enumdomusers" 2>&1 | tee {workspace}/rpc_users.txt
rpcclient -U "" -N {target_ip} -c "enumdomgroups" 2>&1 | tee {workspace}/rpc_groups.txt
rpcclient -U "" -N {target_ip} -c "getdompwinfo" 2>&1 | tee {workspace}/rpc_pwpolicy.txt
```

# Análise de Resultados
- **Null session permitida:** Se `enum4linux-ng` ou `rpcclient` retornarem dados sem credenciais, o alvo permite null sessions (vulnerabilidade crítica).
- **Shares com permissão READ:** Se encontrar shares acessíveis (ex: `IPC$`, `SYSVOL`, `NETLOGON`, shares customizados), explore-os para buscar scripts, GPOs e credenciais.
- **Lista de usuários obtida:** Use os nomes de usuário para password spraying com a skill `bruteforce_authentication`.
- **Política de senha fraca:** Se `min_password_length` < 8 ou `lockout_threshold` = 0, o alvo é vulnerável a brute force.

# Próximos Passos
- Se encontrar credenciais ou null session, acione a skill `smb_share_exploration`.
- Se encontrar lista de usuários, acione a skill `bruteforce_authentication` com password spraying.
- Se o alvo for um Domain Controller, acione a skill `active_directory_enumeration`.

# Tratamento de Erros
- Se `enum4linux-ng` não estiver instalado: `pip install enum4linux-ng`.
- Se o SMB retornar "NT_STATUS_ACCESS_DENIED", null sessions estão desabilitadas. Tente com credenciais conhecidas.
- Se o SMBv1 estiver desabilitado, adicione `--option 'client min protocol = SMB2'` ao smbclient.
