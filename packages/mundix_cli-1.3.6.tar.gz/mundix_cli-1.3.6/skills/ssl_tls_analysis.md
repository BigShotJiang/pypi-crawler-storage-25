---
name: ssl_tls_analysis
phase: 3_vulnerability_analysis
tools: [testssl.sh, sslscan, nmap]
dependencies: [https_service_identified]
mitre_tactic: TA0043 (Reconnaissance)
---

# Objetivo
Analisar a configuração SSL/TLS do alvo para identificar cifras fracas, protocolos obsoletos, certificados expirados e vulnerabilidades conhecidas (Heartbleed, POODLE, BEAST, etc.).

# Condições de Execução
- O alvo possui serviço HTTPS acessível (porta 443 ou outra porta com TLS).

# Comandos e Sintaxe

## 1. Testssl.sh (Análise Completa)
```bash
testssl.sh --severity HIGH --color 0 --jsonfile {workspace}/testssl_results.json https://{target_domain}:{port} 2>&1 | tee {workspace}/testssl_output.txt
```

## 2. SSLScan (Rápido)
```bash
sslscan --no-colour {target_domain}:{port} | tee {workspace}/sslscan_results.txt
```

## 3. Nmap SSL Scripts
```bash
nmap --script ssl-enum-ciphers,ssl-heartbleed,ssl-poodle,ssl-cert -p {port} -Pn {target_ip} -oN {workspace}/nmap_ssl.txt
```

# Análise de Resultados
- **SSLv3 ou TLS 1.0/1.1 habilitado:** Protocolo obsoleto e vulnerável. Registre como vulnerabilidade média/alta.
- **Heartbleed (CVE-2014-0160):** Vulnerabilidade crítica que permite leitura de memória do servidor. Acione exploração imediata.
- **Certificado expirado ou auto-assinado:** Registre no relatório. Pode indicar ambiente de desenvolvimento exposto.
- **Cifras fracas (RC4, DES, NULL, EXPORT):** Registre como vulnerabilidade. Permite ataques de downgrade.
- **HSTS ausente:** Registre como finding informativo.

# Próximos Passos
- Se Heartbleed for detectado, acione a skill `heartbleed_exploitation`.
- Registre todos os findings SSL/TLS no relatório final.

# Tratamento de Erros
- Se `testssl.sh` não estiver instalado: `git clone --depth 1 https://github.com/drwetter/testssl.sh.git /opt/testssl`.
- Se o teste demorar muito, adicione `--fast` para modo rápido.
