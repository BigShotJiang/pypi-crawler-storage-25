---
name: osint_domain_enumeration
phase: 1_reconnaissance
tools: [subfinder, amass, crt.sh]
dependencies: [target_domain_identified]
mitre_tactic: TA0043 (Reconnaissance)
---

# Objetivo
Descobrir subdomínios válidos associados ao domínio alvo utilizando fontes passivas (OSINT) e ativas, expandindo a superfície de ataque conhecida.

# Condições de Execução
- O domínio principal do alvo foi confirmado pelo usuário.
- O escopo permite enumeração de subdomínios.

# Comandos e Sintaxe
Execute as seguintes ferramentas em sequência para maximizar a descoberta.

## 1. Subfinder (Passivo - Rápido)
Use o Subfinder para buscar subdomínios em fontes públicas sem tocar na infraestrutura do alvo.
```bash
subfinder -d {target_domain} -all -silent -o {workspace}/subfinder_out.txt
```

## 2. crt.sh (Passivo - Certificados)
Busque subdomínios registrados em certificados SSL/TLS via API do crt.sh.
```bash
curl -s "https://crt.sh/?q=%25.{target_domain}&output=json" | jq -r '.[].name_value' | sed 's/\*\.//g' | sort -u > {workspace}/crtsh_out.txt
```

## 3. Consolidação e Resolução (Ativo)
Junte os resultados e verifique quais subdomínios estão vivos (resolvem para um IP).
```bash
cat {workspace}/subfinder_out.txt {workspace}/crtsh_out.txt | sort -u > {workspace}/all_subdomains.txt
cat {workspace}/all_subdomains.txt | httpx -silent -status-code -title -tech-detect -o {workspace}/alive_subdomains.txt
```

# Análise de Resultados (Como interpretar)
- Leia o arquivo `{workspace}/alive_subdomains.txt`.
- Identifique subdomínios de desenvolvimento, homologação ou painéis administrativos (ex: `dev.`, `staging.`, `admin.`, `vpn.`, `api.`).
- Se encontrar subdomínios com status `403 Forbidden` ou `401 Unauthorized`, anote-os para bypass de autorização posterior.
- Se encontrar subdomínios apontando para serviços de terceiros (ex: AWS S3, GitHub Pages, Heroku) com erro `404` ou `NXDOMAIN`, acione a skill `subdomain_takeover_check`.

# Próximos Passos (Decisão do Agente)
- Para cada subdomínio vivo descoberto, acione a skill `network_port_scan` para mapear portas abertas.
- Para subdomínios web (HTTP/HTTPS), acione a skill `web_directory_discovery`.

# Tratamento de Erros
- Se o `subfinder` não estiver instalado, instale-o via `go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest`.
- Se o `httpx` falhar por timeout, aumente o timeout com a flag `-timeout 10`.
