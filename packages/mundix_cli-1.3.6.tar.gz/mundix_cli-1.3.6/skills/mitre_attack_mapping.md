---
name: mitre_attack_mapping
phase: 6_reporting
tools: [python3, jq]
dependencies: [engagement_has_findings]
mitre_tactic: Multiple
---

# Objetivo
Mapear todos os achados do engajamento de pentest para tecnicas e taticas do framework MITRE ATT&CK, gerar visualizacao em formato de matriz, criar narrativa de ataque com a cadeia completa de tecnicas utilizadas.

# Condicoes de Execucao
- O engajamento possui achados documentados (vulnerabilidades, exploits executados, movimentos laterais, etc.).
- Os resultados das fases anteriores estao disponiveis no workspace.
- Python3 e jq estao disponiveis no sistema.

# Comandos e Sintaxe

## 1. Coleta de Dados das Fases Anteriores
```bash
find {workspace} -name "*.txt" -o -name "*.json" | sort | tee {workspace}/all_findings_files.txt
```

## 2. Script de Mapeamento ATT&CK
```bash
python3 mitre_mapper.py --workspace {workspace} --output {workspace}/mitre_attack_reference.json
```

O script `mitre_mapper.py` deve conter o seguinte mapeamento de referencia:

```python
mitre_mapping = {
    "Reconnaissance": {
        "tactic_id": "TA0043",
        "techniques": {
            "T1595": "Active Scanning",
            "T1595.001": "Scanning IP Blocks",
            "T1595.002": "Vulnerability Scanning",
            "T1592": "Gather Victim Host Information",
            "T1589": "Gather Victim Identity Information",
            "T1590": "Gather Victim Network Information",
            "T1593": "Search Open Websites/Domains",
            "T1596": "Search Open Technical Databases"
        }
    },
    "Initial Access": {
        "tactic_id": "TA0001",
        "techniques": {
            "T1190": "Exploit Public-Facing Application",
            "T1078": "Valid Accounts",
            "T1133": "External Remote Services"
        }
    },
    "Execution": {
        "tactic_id": "TA0002",
        "techniques": {
            "T1059": "Command and Scripting Interpreter",
            "T1059.001": "PowerShell",
            "T1059.003": "Windows Command Shell",
            "T1059.004": "Unix Shell",
            "T1203": "Exploitation for Client Execution"
        }
    },
    "Persistence": {
        "tactic_id": "TA0003",
        "techniques": {
            "T1505.003": "Web Shell",
            "T1136": "Create Account",
            "T1098": "Account Manipulation"
        }
    },
    "Privilege Escalation": {
        "tactic_id": "TA0004",
        "techniques": {
            "T1068": "Exploitation for Privilege Escalation",
            "T1548": "Abuse Elevation Control Mechanism",
            "T1548.002": "Bypass User Account Control",
            "T1134": "Access Token Manipulation",
            "T1574": "Hijack Execution Flow",
            "T1574.001": "DLL Search Order Hijacking"
        }
    },
    "Credential Access": {
        "tactic_id": "TA0006",
        "techniques": {
            "T1110": "Brute Force",
            "T1003": "OS Credential Dumping",
            "T1003.001": "LSASS Memory",
            "T1003.002": "Security Account Manager",
            "T1558.003": "Kerberoasting"
        }
    },
    "Lateral Movement": {
        "tactic_id": "TA0008",
        "techniques": {
            "T1021": "Remote Services",
            "T1021.001": "Remote Desktop Protocol",
            "T1021.002": "SMB/Windows Admin Shares",
            "T1021.006": "Windows Remote Management",
            "T1550.002": "Pass the Hash",
            "T1550.003": "Pass the Ticket"
        }
    },
    "Collection": {
        "tactic_id": "TA0009",
        "techniques": {
            "T1005": "Data from Local System",
            "T1039": "Data from Network Shared Drive"
        }
    },
    "Exfiltration": {
        "tactic_id": "TA0010",
        "techniques": {
            "T1041": "Exfiltration Over C2 Channel",
            "T1048": "Exfiltration Over Alternative Protocol"
        }
    }
}
```

## 3. Gerar Mapeamento Baseado em Achados
```bash
python3 -c "
import json, os, glob

workspace = '{workspace}'
findings = []

file_technique_map = {
    'nmap': ['T1595.001', 'T1595.002'],
    'nikto': ['T1595.002'],
    'nuclei': ['T1595.002'],
    'sqlmap': ['T1190'],
    'ffuf': ['T1595.002'],
    'searchsploit': ['T1595.002'],
    'msf': ['T1190', 'T1059'],
    'linpeas': ['T1068', 'T1548'],
    'winpeas': ['T1068', 'T1548'],
    'rubeus': ['T1558.003'],
    'sharphound': ['T1087'],
    'crackmapexec': ['T1021.002', 'T1550.002'],
    'psexec': ['T1021.002'],
    'wmiexec': ['T1047'],
    'evilwinrm': ['T1021.006'],
    'hashcat': ['T1110'],
    'john': ['T1110'],
    'weevely': ['T1505.003'],
    'bloodhound': ['T1087.002']
}

result_files = glob.glob(os.path.join(workspace, '*.txt'))
techniques_used = set()

for f in result_files:
    basename = os.path.basename(f).lower()
    for tool, techs in file_technique_map.items():
        if tool in basename:
            for t in techs:
                techniques_used.add(t)
            findings.append({'file': basename, 'tool': tool, 'techniques': techs})

output = {
    'total_findings_files': len(result_files),
    'techniques_identified': sorted(list(techniques_used)),
    'total_techniques': len(techniques_used),
    'findings_detail': findings
}

with open(os.path.join(workspace, 'mitre_mapping_results.json'), 'w') as out:
    json.dump(output, out, indent=2)
print(json.dumps(output, indent=2))
" 2>&1 | tee {workspace}/mitre_mapping_output.txt
```

## 4. Gerar Matriz ATT&CK em Texto
```bash
python3 -c "
import json, os

workspace = '{workspace}'
mapping_file = os.path.join(workspace, 'mitre_mapping_results.json')

if os.path.exists(mapping_file):
    with open(mapping_file) as f:
        data = json.load(f)
    techniques = set(data.get('techniques_identified', []))
else:
    techniques = set()

tactics_order = [
    ('TA0043', 'Recon'),
    ('TA0042', 'ResrcDev'),
    ('TA0001', 'InitAccess'),
    ('TA0002', 'Execution'),
    ('TA0003', 'Persist'),
    ('TA0004', 'PrivEsc'),
    ('TA0005', 'DefEvas'),
    ('TA0006', 'CredAccess'),
    ('TA0007', 'Discovery'),
    ('TA0008', 'LatMov'),
    ('TA0009', 'Collection'),
    ('TA0011', 'C2'),
    ('TA0010', 'Exfil'),
    ('TA0040', 'Impact')
]

tactic_techniques = {
    'TA0043': ['T1595', 'T1595.001', 'T1595.002', 'T1592', 'T1589', 'T1590'],
    'TA0001': ['T1190', 'T1078', 'T1133'],
    'TA0002': ['T1059', 'T1059.001', 'T1059.003', 'T1059.004', 'T1203'],
    'TA0003': ['T1505.003', 'T1136', 'T1098'],
    'TA0004': ['T1068', 'T1548', 'T1548.002', 'T1134', 'T1574'],
    'TA0005': ['T1027', 'T1070', 'T1562'],
    'TA0006': ['T1110', 'T1003', 'T1003.001', 'T1003.002', 'T1558.003'],
    'TA0007': ['T1087', 'T1087.002', 'T1046', 'T1083'],
    'TA0008': ['T1021', 'T1021.001', 'T1021.002', 'T1021.006', 'T1550.002', 'T1550.003'],
    'TA0009': ['T1005', 'T1039'],
    'TA0010': ['T1041', 'T1048']
}

print('=' * 80)
print('MITRE ATT&CK MATRIX - ENGAGEMENT COVERAGE')
print('=' * 80)

for tactic_id, tactic_name in tactics_order:
    techs = tactic_techniques.get(tactic_id, [])
    active = [t for t in techs if t in techniques]
    status = '[%d/%d]' % (len(active), len(techs)) if techs else '[N/A]'
    marker = ' *** ACTIVE ***' if active else ''
    print('  %s | %-12s | %s%s' % (tactic_id, tactic_name, status, marker))
    for t in active:
        print('      -> %s' % t)

print('=' * 80)
print('Total Techniques Used: %d' % len(techniques))
print('=' * 80)

with open(os.path.join(workspace, 'mitre_matrix_text.txt'), 'w') as f:
    f.write('MITRE ATT&CK Matrix - Engagement Coverage\n')
    f.write('Total Techniques: %d\n' % len(techniques))
    for t in sorted(techniques):
        f.write('  %s\n' % t)
" 2>&1 | tee {workspace}/mitre_matrix_output.txt
```

## 5. Gerar Narrativa de Ataque
```bash
python3 -c "
import os

workspace = '{workspace}'

narrative = '''# Narrativa de Ataque - MITRE ATT&CK

## Resumo da Cadeia de Ataque (Kill Chain)

### Fase 1: Reconhecimento (TA0043)
Tecnicas de reconhecimento ativo foram utilizadas para identificar servicos, portas e vulnerabilidades no alvo.

### Fase 2: Acesso Inicial (TA0001)
Vulnerabilidades identificadas foram exploradas para obter acesso inicial ao sistema alvo.

### Fase 3: Execucao (TA0002)
Comandos e scripts foram executados no sistema comprometido para enumeracao e coleta.

### Fase 4: Escalacao de Privilegios (TA0004)
Misconfiguracoes e vulnerabilidades locais foram exploradas para obter privilegios elevados.

### Fase 5: Movimento Lateral (TA0008)
Credenciais obtidas foram utilizadas para acessar outros sistemas na rede.

### Fase 6: Acesso a Credenciais (TA0006)
Hashes e credenciais foram extraidos dos sistemas comprometidos.

## Recomendacoes de Deteccao
- Implementar monitoramento de logs com SIEM.
- Configurar alertas para tecnicas MITRE ATT&CK identificadas.
- Implementar EDR com deteccao comportamental.
- Monitorar trafego lateral (SMB, WMI, WinRM) entre estacoes.
'''

output_path = os.path.join(workspace, 'mitre_attack_narrative.md')
with open(output_path, 'w') as f:
    f.write(narrative)
print('Narrative generated:', output_path)
" 2>&1 | tee {workspace}/mitre_narrative_output.txt
```

## 6. Extrair Tecnicas em Formato Navigator Layer
```bash
python3 -c "
import json, os

workspace = '{workspace}'
mapping_file = os.path.join(workspace, 'mitre_mapping_results.json')

techniques = []
if os.path.exists(mapping_file):
    with open(mapping_file) as f:
        data = json.load(f)
    for t in data.get('techniques_identified', []):
        techniques.append({
            'techniqueID': t,
            'score': 100,
            'color': '#ff6666',
            'comment': 'Used during engagement',
            'enabled': True
        })

navigator_layer = {
    'name': 'Pentest Engagement Coverage',
    'versions': {'attack': '14', 'navigator': '4.9.1', 'layer': '4.5'},
    'domain': 'enterprise-attack',
    'description': 'MITRE ATT&CK techniques used during penetration test',
    'techniques': techniques,
    'gradient': {
        'colors': ['#ffffff', '#ff6666'],
        'minValue': 0,
        'maxValue': 100
    }
}

output_path = os.path.join(workspace, 'mitre_navigator_layer.json')
with open(output_path, 'w') as f:
    json.dump(navigator_layer, f, indent=2)
print('Navigator layer generated:', output_path)
print('Import into https://mitre-attack.github.io/attack-navigator/')
" 2>&1 | tee {workspace}/mitre_navigator_output.txt
```

## 7. Processar Resultados com jq
```bash
jq '.techniques_identified | length' {workspace}/mitre_mapping_results.json
jq '.findings_detail[] | select(.techniques | length > 1)' {workspace}/mitre_mapping_results.json | tee {workspace}/multi_technique_findings.json
```

# Analise de Resultados
- **Muitas tecnicas em Reconnaissance:** Normal para engajamentos com fase de OSINT extensa.
- **Tecnicas em Initial Access presentes:** Exploracao bem-sucedida foi realizada. Documentar vetores.
- **Tecnicas de Privilege Escalation ativas:** Indicam misconfiguracoes serias no hardening do sistema.
- **Tecnicas de Lateral Movement presentes:** Segmentacao de rede e insuficiente.
- **Navigator layer gerado:** Importar em https://mitre-attack.github.io/attack-navigator/ para visualizacao grafica.
- **Cobertura baixa de taticas:** Pode indicar que o teste foi focado ou que defesas bloquearam avanco.

# Proximos Passos
- Importar o navigator layer no ATT&CK Navigator para incluir no relatorio.
- Usar a narrativa de ataque como base para a secao tecnica do relatorio.
- Acionar `executive_summary` com os dados do mapeamento MITRE.
- Acionar `generate_pentest_report` com todos os achados mapeados.

# Tratamento de Erros
- Se `jq` nao estiver instalado, use `python3 -m json.tool` como alternativa.
- Se o workspace nao contiver arquivos de resultado, verifique se as fases anteriores foram executadas.
- Se o mapeamento automatico nao identificar tecnicas, adicione manualmente baseado nos logs.
- Se o Navigator layer nao importar, verifique o formato JSON com `jq . {workspace}/mitre_navigator_layer.json`.
