---
name: network_port_scan
phase: 2_scanning_enumeration
tools: [nmap, masscan]
dependencies: [target_ip_identified]
mitre_tactic: TA0043 (Reconnaissance), TA0007 (Discovery)
---

# Objetivo
Identificar portas abertas, serviços em execução e suas respectivas versões no alvo, estabelecendo os vetores de entrada possíveis para exploração.

# Condições de Execução
- O IP ou domínio do alvo foi confirmado e está acessível.
- O escopo permite varredura ativa de portas.

# Comandos e Sintaxe
Execute a varredura em duas etapas: uma rápida para todas as portas e uma profunda para as portas abertas.

## 1. Varredura Rápida (Todas as 65535 portas)
Use o Nmap com alta taxa de pacotes para descobrir rapidamente quais portas estão abertas.
```bash
nmap -sS -p- --min-rate 5000 -n -Pn -oG {workspace}/nmap_ports.txt {target_ip}
```

## 2. Extração de Portas
Extraia as portas abertas do resultado anterior para focar a varredura profunda.
```bash
grep "Ports:" {workspace}/nmap_ports.txt | awk -F "Ports: " '{print $2}' | awk -F "," '{for(i=1;i<=NF;i++){split($i,a,"/"); print a[1]}}' | tr '\n' ',' | sed 's/,$//' > {workspace}/open_ports.txt
```

## 3. Varredura Profunda (Serviços e Scripts)
Execute detecção de versão (`-sV`) e scripts padrão (`-sC`) apenas nas portas abertas encontradas.
```bash
PORTS=$(cat {workspace}/open_ports.txt)
nmap -sV -sC -p $PORTS -Pn -oN {workspace}/nmap_deep.txt -oX {workspace}/nmap_deep.xml {target_ip}
```

# Análise de Resultados (Como interpretar)
- Leia o arquivo `{workspace}/nmap_deep.txt`.
- **Portas Web (80, 443, 8080, 8443):** Acione a skill `web_directory_discovery` e `web_vulnerability_scan`.
- **Portas SMB (139, 445):** Acione a skill `smb_rpc_enumeration`.
- **Portas FTP (21):** Verifique se o script `ftp-anon` reportou "Anonymous FTP login allowed". Se sim, acione a skill `ftp_anonymous_login`.
- **Portas SSH (22):** Verifique a versão. Se for antiga, busque CVEs.
- **Portas de Banco de Dados (3306, 5432, 1433):** Acione a skill `database_bruteforce` se o escopo permitir.

# Próximos Passos (Decisão do Agente)
- Registre todos os serviços e versões no *Knowledge Graph*.
- Para cada serviço com versão identificada, acione a skill `cve_search_engine` para buscar vulnerabilidades conhecidas (ex: Searchsploit).

# Tratamento de Erros
- Se o Nmap retornar "Host seems down", certifique-se de que a flag `-Pn` está sendo usada.
- Se todas as portas retornarem "filtered", o alvo está bloqueando ICMP ou TCP SYN. Tente varredura TCP Connect (`-sT`) ou diminua a taxa (`--max-rate 100`).
- Se o Nmap exigir privilégios de root para `-sS`, use `sudo nmap` ou mude para `-sT` (que não exige root).
