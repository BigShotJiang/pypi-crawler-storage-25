---
name: tech_stack_fingerprinting
phase: 1_reconnaissance
tools: [whatweb, wafw00f, curl]
dependencies: [target_domain_identified]
mitre_tactic: TA0043 (Reconnaissance)
---

# Objetivo
Identificar as tecnologias, frameworks, CMS, linguagens de programação, servidores web e WAFs utilizados pelo alvo para direcionar ataques específicos.

# Condições de Execução
- O domínio ou URL do alvo foi confirmado.
- O alvo possui serviço web acessível (HTTP/HTTPS).

# Comandos e Sintaxe

## 1. WhatWeb (Fingerprinting Completo)
```bash
whatweb -v -a 3 https://{target_domain} 2>&1 | tee {workspace}/whatweb_results.txt
```

## 2. Detecção de WAF
```bash
wafw00f https://{target_domain} -o {workspace}/waf_detection.txt
```

## 3. Headers HTTP (Manual)
```bash
curl -sI https://{target_domain} | tee {workspace}/http_headers.txt
```

## 4. Fingerprinting de Múltiplos Subdomínios (se disponíveis)
```bash
if [ -f {workspace}/alive_subdomains.txt ]; then
  cat {workspace}/alive_subdomains.txt | awk '{print $1}' | while read url; do
    echo "=== $url ===" >> {workspace}/tech_stack_all.txt
    whatweb -q -a 1 "$url" >> {workspace}/tech_stack_all.txt 2>&1
  done
fi
```

# Análise de Resultados
- **WordPress detectado:** Acione a skill `wordpress_enumeration` (WPScan).
- **Joomla/Drupal detectado:** Acione a skill `cms_vulnerability_scan`.
- **WAF detectado (Cloudflare, Akamai, etc.):** Registre no Knowledge Graph. Ajuste as ferramentas de varredura para usar rate-limiting e evasão.
- **Servidor Apache/Nginx com versão antiga:** Busque CVEs com a skill `cve_search_engine`.
- **Framework detectado (Laravel, Django, Spring):** Direcione testes para vulnerabilidades específicas do framework.

# Próximos Passos
- Registre todas as tecnologias no Knowledge Graph.
- Acione skills de vulnerabilidade específicas para cada tecnologia encontrada.

# Tratamento de Erros
- Se `whatweb` não estiver instalado: `sudo apt install whatweb -y`.
- Se `wafw00f` não estiver instalado: `pip install wafw00f`.
- Se o site retornar `403 Forbidden`, tente com User-Agent diferente: `whatweb -U "Mozilla/5.0" https://{target_domain}`.
