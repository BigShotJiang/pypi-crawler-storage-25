# MundiX CLI

**AI-Powered Autonomous Pentesting Agent for Kali Linux**

MundiX CLI is an intelligent terminal-based pentesting copilot for penetration testers, red teamers, and security researchers. It features a multi-tier AI architecture with specialized models for planning, exploitation, and analysis — all routed through the MundiX backend API.

Think of it as **an AI agent that actually runs your pentest — not just suggests commands.**

---

## Features

| Feature | Description |
| :--- | :--- |
| **Autonomous Agent** | Full autonomous pentesting with 6-phase methodology (recon → exploitation → reporting) |
| **AI Chat** | Interactive conversation with specialized cybersecurity AI models |
| **Multi-Agent** | Parallel skill execution with coordinator + specialist agents |
| **23 Skills** | Pre-built attack skills (nmap, sqlmap, nuclei, hydra, etc.) |
| **Smart Auto-Fix** | Auto-installs missing tools, retries with sudo, evades WAFs |
| **Knowledge Graph** | Builds attack graph of discovered hosts, ports, vulns, creds |
| **Threat Intel** | Enriches findings with NVD CVEs, ExploitDB, CISA KEV |
| **5-Level Autopilot** | From manual confirmation to full autonomy |
| **Safety Checks** | Command whitelist, destructive command blocking, scope validation |
| **Streaming** | Real-time token streaming for fast responses |

---

## Quick Install (Kali Linux)

```bash
curl -sSL https://raw.githubusercontent.com/k0k4/mundix-cli/main/install.sh | bash
```

### Manual Install

```bash
git clone https://github.com/k0k4/mundix-cli.git
cd mundix-cli
pip3 install -r requirements.txt
python3 mundix_cli.py
```

### Install via pip

```bash
pip3 install -e .
mundix
```

### Activation

After install, activate your device at **https://mundix.dev/activate** or run:
```bash
mundix --activate
```
You get **3 free queries** before registration is required.

---

## Usage

### Interactive Mode
```bash
mundix
```

### One-Shot Query
```bash
mundix "how to scan for open ports on 10.0.0.1"
```

### Autonomous Pentest
Inside the interactive shell:
```
/agent example.com web
```

### Choose a Model
```bash
mundix --model mx-strategist-72b
```

---

## AI Models (Multi-Tier Architecture)

| Key | Model | Tier | Description |
| :--- | :--- | :--- | :--- |
| `mx-strategist-72b` | MX-Strategist 72B | Brain | Strategic planner — pentest orchestration & deep analysis |
| `mx-deephat-7b` | MX-DeepHat 7B | Specialist | Offensive specialist — exploit generation & attack chains |
| `mx-swift-3b` | MX-Swift 3B | Executor | Fast executor — parsing, formatting & quick decisions |
| `mx-minitron-8b` | MX-Minitron 8B | Backup | Fallback model for high availability |

---

## CLI Commands

Inside the interactive shell, use these slash commands:

| Command | Description |
| :--- | :--- |
| `/help` | Show help message |
| `/agent <target> [type]` | Start autonomous pentest (types: web, internal, app) |
| `/models` | List available AI models |
| `/model <name>` | Switch to a different model |
| `/memory` | Show memory statistics |
| `/clear` | Clear conversation history |
| `/system` | Show system information |
| `/history` | Show command execution history |
| `/exec <cmd>` | Execute a command directly |
| `/analyze` | Send last command output to AI |
| `/exit` | Exit MundiX CLI |

---

## Autonomous Agent — 6-Phase Methodology

1. **Reconnaissance** — OSINT, subdomain discovery, email harvesting
2. **Scanning & Enumeration** — Port scanning, service detection, directory discovery
3. **Vulnerability Analysis** — CVE search, vulnerability scanning, SSL/TLS analysis
4. **Exploitation** — SQL injection, brute force, file upload exploits, Metasploit
5. **Post-Exploitation** — Privilege escalation, lateral movement, hash cracking
6. **Reporting** — MITRE ATT&CK mapping, executive summary generation

---

## Project Structure

```
mundix-cli/
  mundix_cli.py          # Main CLI application (REPL, Rich TUI)
  ai_provider.py         # MundiX Backend API integration
  agent_orchestrator.py  # Autonomous pentest brain
  multi_agent.py         # Multi-agent parallelism coordinator
  skill_loader.py        # Skill markdown parser and registry
  autopilot.py           # 5-level autonomy control
  playbooks.py           # Pre-defined attack methodologies
  knowledge_graph.py     # Attack graph for findings
  findings_db.py         # SQLite findings database
  threat_intel.py        # CVE/exploit enrichment
  memory.py              # Engagement memory/persistence
  system_integrator.py   # System interaction layer
  osint_monitor.py       # OSINT monitoring
  project.py             # Project/engagement state management
  skills/                # 23 skill definition files (.md)
  install.sh             # Quick installer for Kali Linux
  requirements.txt       # Python dependencies
  setup.py               # pip install support
```

---

## Requirements

- Python 3.8+
- Linux (optimized for Kali Linux)
- MundiX account (free tier: 3 queries, register for more)

---

## License

MIT License - [MundiX](https://mundix.com.br)

---

**Built with purpose by MundiX. Happy Hacking.**
