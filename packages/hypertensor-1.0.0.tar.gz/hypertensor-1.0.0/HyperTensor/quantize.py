from typing import Dict, Any
import torch
import torch.nn as nn

from .formats import (
    PrecisionFormat,
    PRECISION_ORDER,   # should be [INT4, INT8, FP16, BF16, FP32]
)
from .weight_options import WeightOption
from .block_utils import compute_block_grid


def _compute_op_precision_from_map(
    fmt_map: torch.Tensor,
    option: WeightOption,
) -> PrecisionFormat:
    flat = fmt_map.reshape(-1).to(torch.int32)

    if flat.numel() == 0:
        return PrecisionFormat.FP32

    counts = torch.bincount(flat, minlength=max(int(pf) for pf in PRECISION_ORDER) + 1)
    order = [int(pf) for pf in PRECISION_ORDER]
    indices = torch.tensor(order, dtype=torch.float32)

    # -------- LOWEST / HIGHEST --------
    if option == WeightOption.LOWEST:
        # Lowest usable precision that actually appears
        for pf in order:
            if counts[pf] > 0:
                return PrecisionFormat(pf)
        return PrecisionFormat.FP32

    if option == WeightOption.HIGHEST:
        # Highest usable precision that actually appears
        for pf in reversed(order):
            if counts[pf] > 0:
                return PrecisionFormat(pf)
        return PrecisionFormat.FP32

    # Restrict counts/indices to usable formats only
    usable_counts = torch.tensor([counts[pf] for pf in order], dtype=torch.float32)
    total = usable_counts.sum().item()
    if total == 0:
        return PrecisionFormat.FP32

    if option == WeightOption.CLOSEST:
        cumsum = usable_counts.cumsum(0)
        median_idx = int((cumsum >= (total / 2)).nonzero()[0].item())
        pf_idx = order[median_idx]
        return PrecisionFormat(pf_idx)

    if option == WeightOption.AVERAGE:
        avg_idx = float((indices * usable_counts).sum().item() / total)
        max_count_idx = int(usable_counts.argmax().item())
        if usable_counts[max_count_idx] / total > 0.6:
            pf_idx = order[max_count_idx]
            return PrecisionFormat(pf_idx)
        # Round to nearest usable index
        nearest = int(round(avg_idx))
        nearest = max(0, min(nearest, len(order) - 1))
        return PrecisionFormat(order[nearest])

    # ---------- ALLOW ----------
    if option == WeightOption.ALLOW:
        # Prefer low-precision (INT4/INT8) if they dominate
        low_indices = [
            int(PrecisionFormat.INT4),
            int(PrecisionFormat.INT8),
        ]
        low_count = sum(counts[idx].item() for idx in low_indices)
        if low_count / total > 0.7:
            for idx in low_indices:
                if counts[idx] > 0:
                    return PrecisionFormat(idx)

        # Otherwise choose the average usable precision
        avg_idx = float((indices * usable_counts).sum().item() / total)
        nearest = int(round(avg_idx))
        nearest = max(0, min(nearest, len(order) - 1))
        return PrecisionFormat(order[nearest])


    # ---------- BEST ----------
    if option == WeightOption.BEST:
        # BEST = highest-accuracy usable format
        # Prefer FP16 then BF16 then FP32
        high_order = [
            int(PrecisionFormat.FP16),
            int(PrecisionFormat.BF16),
            int(PrecisionFormat.FP32),
        ]

        for pf in high_order:
            if counts[pf] > 0:
                return PrecisionFormat(pf)

        # If none of the high-accuracy formats appear,
        # fall back to INT8 then INT4 only if error was extremely tiny
        for pf in [int(PrecisionFormat.INT8), int(PrecisionFormat.INT4)]:
            if counts[pf] > 0:
                return PrecisionFormat(pf)

    return PrecisionFormat.FP32


def scan_model(
    model: nn.Module,
    eps_fp16: float = 0.0,
    eps_bf16: float = 0.0,
    option: WeightOption = WeightOption.ALLOW,
    block_size: int = 32,
    prefer_bf16: bool = False,
) -> Dict[str, Any]:
    """
    Build a per-parameter format map using only INT4, INT8, FP16, BF16, FP32.
    The actual per-weight decision logic lives in choose_format_for_tensor.
    """
    from .formats import choose_format_for_tensor  # avoid circular import

    plan: Dict[str, Any] = {"params": {}, "meta": {"block_size": block_size}}
    state = model.state_dict()

    for name, tensor in state.items():
        if not tensor.is_floating_point():
            continue

        fmt_map = choose_format_for_tensor(
            tensor,
            eps_fp16=eps_fp16,
            eps_bf16=eps_bf16,
            prefer_bf16=prefer_bf16,
        )

        plan["params"][name] = {
            "shape": tuple(tensor.shape),
            "block_size": block_size,
            "format_map": fmt_map.cpu(),
        }

    return plan


def quantize_tensor_to_format(
    weight: torch.Tensor,
    fmt: PrecisionFormat,
):
    """
    Quantize a tensor to one of the supported formats:
    INT4, INT8, FP16, BF16, FP32.
    """
    w32 = weight.to(torch.float32)

    if fmt == PrecisionFormat.INT4:
        q = w32.round().clamp(-8, 7)
        return q.to(torch.int8)

    if fmt == PrecisionFormat.INT8:
        q = w32.round().clamp(-128, 127)
        return q.to(torch.int8)

    if fmt == PrecisionFormat.FP16:
        return w32.to(torch.float16)

    if fmt == PrecisionFormat.BF16:
        return w32.to(torch.bfloat16)

    if fmt == PrecisionFormat.FP32:
        return w32

    # Fallback: treat any unknown format as FP32
    return w32


def _build_block_id_map(
    shape,
    block_format_map: torch.Tensor,
    block_size: int,
) -> torch.Tensor:
    out_features, in_features = shape
    n_br, n_bc = block_format_map.shape

    row_ids = torch.arange(n_br, device=block_format_map.device).repeat_interleave(block_size)
    col_ids = torch.arange(n_bc, device=block_format_map.device).repeat_interleave(block_size)

    row_ids = row_ids[:out_features]
    col_ids = col_ids[:in_features]

    block_ids = block_format_map[row_ids[:, None], col_ids[None, :]]
    return block_ids.to(torch.int8)


def build_quantized_buffers_for_param(
    weight: torch.Tensor,
    meta: Dict[str, Any],
    option: WeightOption,
) -> Dict[str, Any]:
    device = weight.device
    w32 = weight.to(torch.float32)
    shape = w32.shape

    fmt_map = meta["format_map"].to(torch.int8).reshape(shape)
    block_size = int(meta.get("block_size", 32))

    buffers: Dict[str, Any] = {
        "shape": shape,
        "block_size": block_size,
        "format_map": fmt_map.cpu(),
    }

    is_matrix = (w32.dim() == 2)

    # -------- PER_WEIGHT (eval) --------
    if option == WeightOption.PER_WEIGHT and is_matrix:
        buffers["mode"] = "per_weight"

        w_full = torch.empty(shape, dtype=torch.float16, device=device)

        for pf in PRECISION_ORDER:
            mask = (fmt_map == int(pf))
            if not mask.any():
                continue

            subset = w32[mask]
            q = quantize_tensor_to_format(subset, pf)

            if isinstance(q, tuple):
                data, scale = q
                vals = (data.to(torch.float32) * scale)
            else:
                vals = q.to(torch.float32)

            w_full[mask] = vals.to(torch.float16)

        buffers["w_full"] = w_full
        return buffers

    # -------- PER_BLOCK (eval, vectorized) --------
    if option == WeightOption.PER_BLOCK and is_matrix:
        buffers["mode"] = "per_block"

        out_features, in_features = shape
        n_br, n_bc = compute_block_grid(shape, block_size)
        block_format_map = torch.empty((n_br, n_bc), dtype=torch.int8)

        for br in range(n_br):
            r0 = br * block_size
            r1 = min(r0 + block_size, out_features)
            for bc in range(n_bc):
                c0 = bc * block_size
                c1 = min(c0 + block_size, in_features)
                block_fmt = fmt_map[r0:r1, c0:c1]
                pf = _compute_op_precision_from_map(block_fmt, option)
                block_format_map[br, bc] = int(pf)

        block_ids = _build_block_id_map(shape, block_format_map, block_size)

        w_full = torch.empty(shape, dtype=torch.float16, device=device)

        for pf in PRECISION_ORDER:
            mask = (block_ids == int(pf))
            if not mask.any():
                continue

            subset = w32[mask]
            q = quantize_tensor_to_format(subset, pf)

            if isinstance(q, tuple):
                data, scale = q
                vals = (data.to(torch.float32) * scale)
            else:
                vals = q.to(torch.float32)

            w_full[mask] = vals.to(torch.float16)

        buffers["block_format_map"] = block_format_map.cpu()
        buffers["w_full"] = w_full
        return buffers

    # -------- Normal single-format (eval) --------
    exec_option = option if option != WeightOption.ALLOW else WeightOption.BEST
    exec_pf = _compute_op_precision_from_map(fmt_map, exec_option)
    q_exec = quantize_tensor_to_format(w32, exec_pf)

    buffers["exec_format"] = exec_pf

    if isinstance(q_exec, tuple):
        data, scale = q_exec
        buffers["exec_data"] = data.to(device)
        buffers["exec_scale"] = float(scale)
    else:
        buffers["exec_data"] = q_exec.to(device)

    # Prebuild FP16 exec weight for INT4/INT8
    if exec_pf in (PrecisionFormat.INT4, PrecisionFormat.INT8):
        if isinstance(q_exec, tuple):
            data, scale = q_exec
            w_fp32 = data.to(torch.float32) * scale
        else:
            w_fp32 = q_exec.to(torch.float32)
        buffers["exec_w_fp16"] = w_fp32.to(torch.float16)
    elif exec_pf in (PrecisionFormat.FP16, PrecisionFormat.BF16, PrecisionFormat.FP32):
        # can reconstruct on the fly in modules.py
        pass

    return buffers


def build_quantized_buffers(
    model: nn.Module,
    plan: Dict[str, Any],
    option: WeightOption,
) -> Dict[str, Dict[str, Any]]:
    state = model.state_dict()
    qbuffers: Dict[str, Dict[str, Any]] = {}

    for name, meta in plan["params"].items():
        if name not in state:
            continue
        weight = state[name]
        if not weight.is_floating_point():
            continue
        qbuffers[name] = build_quantized_buffers_for_param(weight, meta, option)

    return qbuffers
