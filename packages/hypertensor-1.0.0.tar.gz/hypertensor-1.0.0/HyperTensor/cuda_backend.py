import os
import torch
from torch.utils.cpp_extension import load

_src_dir = os.path.dirname(__file__)
_ext_name = "hypertensor_kernels"

_hypertensor_ext = load(
    name=_ext_name,
    sources=[
        os.path.join(_src_dir, "kernels.cu"),
        os.path.join(_src_dir, "binding.cpp"),
    ],
    verbose=False,
    extra_cflags=[
        "-O3",
        "-DTORCH_DISABLE_DYNAMO",
    ],
    extra_cuda_cflags=[
        "-O3",
        "--use_fast_math",
        "-DTORCH_DISABLE_DYNAMO",
        "-U__CUDA_NO_HALF_OPERATORS__",
        "-U__CUDA_NO_HALF_CONVERSIONS__",
        "-U__CUDA_NO_BFLOAT16_CONVERSIONS__",
        "-U__CUDA_NO_BFLOAT16_OPERATORS__",
        "-gencode=arch=compute_89,code=sm_89",
    ],
)


def _ensure_same_device(a: torch.Tensor, b: torch.Tensor):
    if a.device != b.device:
        b = b.to(a.device)
    return a, b


# ---------- FP32 / FP16 / BF16: let cuBLAS do its job ----------

def matmul_fp32(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    a, b = _ensure_same_device(a, b)
    return torch.matmul(a, b)


def matmul_fp16(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    a, b = _ensure_same_device(a, b)
    return torch.matmul(a, b)


def matmul_bf16(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    a, b = _ensure_same_device(a, b)
    return torch.matmul(a, b)


# ---------- INT8 / INT4 weight GEMM (for HyperLinear) ----------

def matmul_int8(a: torch.Tensor, w_int8: torch.Tensor, scale: torch.Tensor) -> torch.Tensor:
    a, w_int8 = _ensure_same_device(a, w_int8)
    scale = scale.to(a.device)

    if a.dtype != torch.float16:
        a = a.to(torch.float16)

    if (
        a.is_cuda
        and w_int8.is_cuda
        and scale.is_cuda
        and w_int8.dtype == torch.int8
        and scale.dtype == torch.float32
    ):
        return _hypertensor_ext.gemm_int8_fp16_tc(a, w_int8, scale)

    w_f = w_int8.to(torch.float32)
    if scale.numel() == 1:
        w_f = w_f * scale.view(1, 1)
    else:
        w_f = w_f * scale.view(1, -1)

    return torch.matmul(a.to(torch.float32), w_f)


def matmul_int4(a: torch.Tensor,
                w_int4_packed: torch.Tensor,
                scale: torch.Tensor,
                out_features: int) -> torch.Tensor:

    a, w_int4_packed = _ensure_same_device(a, w_int4_packed)
    scale = scale.to(a.device)

    if a.dtype != torch.float16:
        a = a.to(torch.float16)

    if (
        a.is_cuda
        and w_int4_packed.is_cuda
        and scale.is_cuda
        and w_int4_packed.dtype == torch.int8
        and scale.dtype == torch.float32
    ):
        return _hypertensor_ext.gemm_int4_fp16_tc(a, w_int4_packed, scale)

    K = w_int4_packed.size(0)
    N_packed = w_int4_packed.size(1)
    N = out_features

    w_full = torch.empty((K, N), dtype=torch.float32, device=a.device)

    for k in range(K):
        row = w_int4_packed[k]
        for n in range(N):
            col_packed = n // 2
            high = (n % 2) == 1
            packed = int(row[col_packed].item())
            if high:
                v = (packed >> 4) & 0x0F
            else:
                v = packed & 0x0F
            if v & 0x08:
                v |= 0xF0
            w_full[k, n] = float(torch.tensor(v, dtype=torch.int8))

    if scale.numel() == 1:
        w_full = w_full * scale.view(1, 1)
    else:
        w_full = w_full * scale.view(1, -1)

    return torch.matmul(a.to(torch.float32), w_full)



def matmul_bw_dx_fp16(grad_out: torch.Tensor, w: torch.Tensor) -> torch.Tensor:
    grad_out, w = _ensure_same_device(grad_out, w)
    return _hypertensor_ext.gemm_bw_dx_fp16(grad_out, w)


def matmul_bw_dw_fp16(grad_out: torch.Tensor, x: torch.Tensor) -> torch.Tensor:
    grad_out, x = _ensure_same_device(grad_out, x)
    return _hypertensor_ext.gemm_bw_dw_fp16(grad_out, x)

def matmul_bw_dx_bf16(grad_out: torch.Tensor, w: torch.Tensor) -> torch.Tensor:
    grad_out, w = _ensure_same_device(grad_out, w)
    return _hypertensor_ext.gemm_bw_dx_bf16(grad_out, w)


def matmul_bw_dw_bf16(grad_out: torch.Tensor, x: torch.Tensor) -> torch.Tensor:
    grad_out, x = _ensure_same_device(grad_out, x)
    return _hypertensor_ext.gemm_bw_dw_bf16(grad_out, x)