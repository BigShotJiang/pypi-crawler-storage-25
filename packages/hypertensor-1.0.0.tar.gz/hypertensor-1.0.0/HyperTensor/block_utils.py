from typing import Tuple


def compute_block_grid(shape: Tuple[int, int], block_size: int) -> Tuple[int, int]:
    out_features, in_features = shape
    n_blocks_out = (out_features + block_size - 1) // block_size
    n_blocks_in = (in_features + block_size - 1) // block_size
    return n_blocks_out, n_blocks_in
