﻿from typing import Dict, Any, Optional
import torch
import torch.nn as nn

from .weight_options import WeightOption
from .quantize import build_quantized_buffers, quantize_tensor_to_format
from .formats import PrecisionFormat, PRECISION_ORDER
from .cuda_backend import (
    matmul_fp32,
    matmul_fp16,
    matmul_bf16,
    matmul_int8,
    matmul_int4,
)
from .block_utils import compute_block_grid

from .cuda_backend import (
    matmul_bw_dx_fp16, matmul_bw_dw_fp16,
    matmul_bw_dx_bf16, matmul_bw_dw_bf16
)


class _HyperLinearBwFn(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, weight_fp32, bias, w_exec, prefer_bf16: bool):
        """
        x:           input activations (any shape)
        weight_fp32: FP32 master weight
        w_exec:      STE-quantized exec weight (float32)
        prefer_bf16: bool flag from HyperLinear
        """

        ctx.save_for_backward(x, weight_fp32, bias)
        ctx.prefer_bf16 = prefer_bf16

        x_f = x
        if x_f.dtype != torch.float32:
            x_f = x_f.to(torch.float32)
        x_f = x_f.view(-1, weight_fp32.size(1))

        y = torch.matmul(x_f, w_exec.t())
        if bias is not None:
            y = y + bias

        return y

    @staticmethod
    def backward(ctx, grad_out):
        x, weight_fp32, bias = ctx.saved_tensors
        prefer_bf16 = ctx.prefer_bf16

        M = x.numel() // x.size(-1)
        K = weight_fp32.size(1)
        N = weight_fp32.size(0)

        grad_out_flat = grad_out.view(M, N)
        x_flat = x.view(M, K)

        if prefer_bf16:
            grad_x_flat = matmul_bw_dx_bf16(grad_out_flat, weight_fp32.t())
            grad_w      = matmul_bw_dw_bf16(grad_out_flat, x_flat)
        else:
            grad_x_flat = matmul_bw_dx_fp16(grad_out_flat, weight_fp32.t())
            grad_w      = matmul_bw_dw_fp16(grad_out_flat, x_flat)

        grad_x = grad_x_flat.view_as(x).to(x.dtype)

        grad_bias = None
        if bias is not None:
            grad_bias = grad_out_flat.sum(dim=0).to(bias.dtype)

        return grad_x, grad_w.to(weight_fp32.dtype), grad_bias, None, None


def ste_quantize_single_format(
    weight: torch.Tensor,
    fmt: PrecisionFormat,
    scale: Optional[float] = None,
):
    with torch.no_grad():
        q = quantize_tensor_to_format(weight, fmt)
        if isinstance(q, tuple):
            data, s = q
            s = scale if scale is not None else s
            q_f = (data.to(torch.float32) * s)
        else:
            q_f = q.to(torch.float32)
    return weight + (q_f - weight).detach()


def ste_quantize_per_weight(weight: torch.Tensor, fmt_map: torch.Tensor):
    w32 = weight.to(torch.float32)
    shape = w32.shape
    fmt_map = fmt_map.to(torch.int8).reshape(shape)

    with torch.no_grad():
        w_q = torch.empty_like(w32)
        for pf in PRECISION_ORDER:
            mask = (fmt_map == int(pf))
            if not mask.any():
                continue
            subset = w32[mask]
            q = quantize_tensor_to_format(subset, pf)
            if isinstance(q, tuple):
                data, scale = q
                vals = (data.to(torch.float32) * scale)
            else:
                vals = q.to(torch.float32)
            w_q[mask] = vals

    return weight + (w_q - weight).detach()


def _build_block_id_map_train(
    weight: torch.Tensor,
    block_format_map: torch.Tensor,
    block_size: int,
) -> torch.Tensor:
    shape = (weight.size(0), weight.size(1))
    out_features, in_features = shape
    n_br, n_bc = compute_block_grid(shape, block_size)
    block_format_map = block_format_map.to(torch.int8).reshape(n_br, n_bc)

    row_ids = torch.arange(n_br, device=weight.device).repeat_interleave(block_size)
    col_ids = torch.arange(n_bc, device=weight.device).repeat_interleave(block_size)

    row_ids = row_ids[:out_features]
    col_ids = col_ids[:in_features]

    block_ids = block_format_map[row_ids[:, None], col_ids[None, :]]
    return block_ids.to(torch.int8)


def ste_quantize_per_block(
    weight: torch.Tensor,
    block_format_map: torch.Tensor,
    block_size: int,
):
    block_ids = _build_block_id_map_train(weight, block_format_map, block_size)
    return ste_quantize_per_weight(weight, block_ids)


class HyperLinear(nn.Linear):
    """
    HyperTensor-aware Linear layer.

    TRAIN:
      - Uses FP32 master weight (self.weight).
      - PER_WEIGHT: per-element STE (cached, refresh_every steps).
      - PER_BLOCK: blockwise STE via block_id map (cached).
      - Others: single-format STE (cached).

    EVAL:
      - PER_WEIGHT / PER_BLOCK: prebuilt FP16 w_full.
      - Others: exec_data + exec_format, with INT8/INT4 using CUDA kernels
        and FP16/BF16/FP32 using cuBLAS matmul.
    """

    def __init__(
        self,
        in_features: int,
        out_features: int,
        bias: bool = True,
        refresh_every: int = 1,
        prefer_bf16: bool = False,
        inference_only: bool = False,
    ):
        super().__init__(in_features, out_features, bias=bias)
        self._hypertensor_param_name_weight: Optional[str] = None
        self._hypertensor_param_name_bias: Optional[str] = None
        self._hypertensor_buffers: Dict[str, Any] = {}

        self.register_buffer("_ht_w_full", None, persistent=False)
        self.register_buffer("_ht_exec_data", None, persistent=False)

        self._ht_train_cache: Dict[str, torch.Tensor] = {}
        self._ht_train_step: int = 0
        self._ht_refresh_every: int = refresh_every

        self._ht_exec_w_fp16: Optional[torch.Tensor] = None

        self.prefer_bf16 = prefer_bf16
        self.inference_only = inference_only

    def register_hypertensor_names(self, prefix: str):
        self._hypertensor_param_name_weight = f"{prefix}.weight"
        if self.bias is not None:
            self._hypertensor_param_name_bias = f"{prefix}.bias"

    def set_hypertensor_buffers(self, buffers: Dict[str, Any]):
        dev = self.weight.device
        for k, v in list(buffers.items()):
            if isinstance(v, torch.Tensor):
                buffers[k] = v.to(dev)

        self._hypertensor_buffers = buffers

        mode = buffers.get("mode", None)
        if mode in ("per_weight", "per_block"):
            w_full = buffers["w_full"]
            if not isinstance(w_full, torch.Tensor):
                raise TypeError("w_full must be a tensor")
            self._ht_w_full = w_full
        else:
            exec_data = buffers.get("exec_data", None)
            if isinstance(exec_data, torch.Tensor):
                self._ht_exec_data = exec_data

        self._ht_exec_w_fp16 = None

        if self.bias is not None:
            self.bias = nn.Parameter(self.bias.to(torch.float32), requires_grad=not self.inference_only)

        if self.inference_only:
            with torch.no_grad():
                self._ht_master_weight_cpu = self.weight.data.to("cpu")
            self.register_parameter("weight", None)
            if self.bias is not None:
                self.bias.requires_grad_(False)

    def _maybe_refresh_train_cache(self, key: str, build_fn):
        step = self._ht_train_step
        if key not in self._ht_train_cache or (step % self._ht_refresh_every) == 0:
            self._ht_train_cache[key] = build_fn()
        return self._ht_train_cache[key]

    # -------- TRAINING PATHS --------

    def _forward_per_weight_train(self, input: torch.Tensor) -> torch.Tensor:
        meta_fmt = self._hypertensor_buffers.get("format_map", None)
        if meta_fmt is None:
            return super().forward(input)

        def build():
            return ste_quantize_per_weight(self.weight, meta_fmt.to(self.weight.device))

        W_q = self._maybe_refresh_train_cache("per_weight", build)
        out = _HyperLinearBwFn.apply(input, self.weight, self.bias, W_q, self.prefer_bf16)
        out_shape = list(input.shape[:-1]) + [self.out_features]
        return out.view(*out_shape)

    def _forward_per_block_train(self, input: torch.Tensor) -> torch.Tensor:
        block_fmt = self._hypertensor_buffers.get("block_format_map", None)
        block_size = int(self._hypertensor_buffers.get("block_size", 32))
        if block_fmt is None:
            return super().forward(input)

        def build():
            return ste_quantize_per_block(
                self.weight, block_fmt.to(self.weight.device), block_size
            )

        W_q = self._maybe_refresh_train_cache("per_block", build)

        x = input
        if x.dtype != torch.float32:
            x = x.to(torch.float32)
        x = x.view(-1, self.in_features)

        out = matmul_fp32(x, W_q.t())

        if self.bias is not None:
            out = out + self.bias

        out_shape = list(input.shape[:-1]) + [self.out_features]
        return out.view(*out_shape)

    def _forward_single_format_train(self, input: torch.Tensor) -> torch.Tensor:
        exec_fmt: PrecisionFormat = self._hypertensor_buffers["exec_format"]
        scale = self._hypertensor_buffers.get("exec_scale", None)

        def build():
            return ste_quantize_single_format(self.weight, exec_fmt, scale)

        W_q = self._maybe_refresh_train_cache("single", build)

        x = input
        if x.dtype != torch.float32:
            x = x.to(torch.float32)
        x = x.view(-1, self.in_features)

        if exec_fmt in (PrecisionFormat.FP16, PrecisionFormat.BF16):
            out = matmul_fp16(x.to(torch.float16), W_q.to(torch.float16))
        else:
            out = matmul_fp32(x, W_q.to(torch.float32))

        if self.bias is not None:
            out = out + self.bias

        out_shape = list(input.shape[:-1]) + [self.out_features]
        return out.view(*out_shape)

    # -------- EVAL PATHS --------

    def _forward_per_weight_eval(self, input: torch.Tensor) -> torch.Tensor:
        if self._ht_w_full is None:
            return super().forward(input)

        x = input.to(torch.float16)
        x = x.view(-1, self.in_features)

        w = self._ht_w_full
        out = matmul_fp16(x, w.t())

        if self.bias is not None:
            out = out + self.bias

        out_shape = list(input.shape[:-1]) + [self.out_features]
        return out.view(*out_shape)

    def _forward_per_block_eval(self, input: torch.Tensor) -> torch.Tensor:
        if self._ht_w_full is None:
            return super().forward(input)

        x = input.to(torch.float16)
        x = x.view(-1, self.in_features)

        w = self._ht_w_full
        out = matmul_fp16(x, w.t())

        if self.bias is not None:
            out = out + self.bias

        out_shape = list(input.shape[:-1]) + [self.out_features]
        return out.view(*out_shape)

    def _forward_single_format_eval(self, input: torch.Tensor) -> torch.Tensor:
        exec_fmt: PrecisionFormat = self._hypertensor_buffers["exec_format"]
        data = self._ht_exec_data
        if data is None:
            data = self._hypertensor_buffers["exec_data"]

        x = input
        if x.dtype != torch.float32:
            x = x.to(torch.float32)
        x = x.view(-1, self.in_features)

        w_shape = (self.out_features, self.in_features)

        # Fast path: prebuilt FP16 weight for INT4/INT8
        if "exec_w_fp16" in self._hypertensor_buffers:
            if (
                self._ht_exec_w_fp16 is None
                or self._ht_exec_w_fp16.device != x.device
            ):
                self._ht_exec_w_fp16 = (
                    self._hypertensor_buffers["exec_w_fp16"]
                    .to(x.device)
                    .view(w_shape)
                )

            w_fp16 = self._ht_exec_w_fp16
            x16 = x.to(torch.float16)
            out = matmul_fp16(x16, w_fp16.t())
        else:
            if exec_fmt == PrecisionFormat.INT4:
                w_int4 = data.view(w_shape)
                x16 = x.to(torch.float16)
                w_int4_t = w_int4.t().contiguous()
                scale = self._hypertensor_buffers.get("exec_scale", None)
                if isinstance(scale, torch.Tensor):
                    scale_t = scale.to(torch.float32)
                else:
                    scale_t = torch.tensor(
                        [float(scale if scale is not None else 1.0)],
                        device=x.device,
                        dtype=torch.float32,
                    )
                out16 = matmul_int4(x16, w_int4_t, scale_t, self.out_features)
                out = out16.to(torch.float32)

            elif exec_fmt == PrecisionFormat.INT8:
                w_int8 = data.view(w_shape)
                x16 = x.to(torch.float16)
                w_int8_t = w_int8.t().contiguous()
                scale = self._hypertensor_buffers.get("exec_scale", None)
                if isinstance(scale, torch.Tensor):
                    scale_t = scale.to(torch.float32)
                else:
                    scale_t = torch.tensor(
                        [float(scale if scale is not None else 1.0)],
                        device=x.device,
                        dtype=torch.float32,
                    )
                out16 = matmul_int8(x16, w_int8_t, scale_t)
                out = out16.to(torch.float32)

            elif exec_fmt == PrecisionFormat.FP16:
                x16 = x.to(torch.float16)
                w_fp16 = data.view(w_shape)
                out = matmul_fp16(x16, w_fp16.t())

            elif exec_fmt == PrecisionFormat.BF16:
                x_bf16 = x.to(torch.bfloat16)
                w_bf16 = data.view(w_shape)
                out = matmul_bf16(x_bf16, w_bf16.t())

            elif exec_fmt == PrecisionFormat.FP32:
                x32 = x.to(torch.float32)
                w_fp32 = data.view(w_shape)
                out = matmul_fp32(x32, w_fp32.t())

            else:
                x32 = x.to(torch.float32)
                w_fallback = data.view(w_shape).to(torch.float32)
                out = matmul_fp32(x32, w_fallback.t())

        if self.bias is not None:
            out = out + self.bias

        out_shape = list(input.shape[:-1]) + [self.out_features]
        return out.view(*out_shape)

    # -------- MAIN FORWARD --------
    def forward(self, input: torch.Tensor) -> torch.Tensor:
        if not self._hypertensor_buffers:
            return super().forward(input)

        mode = self._hypertensor_buffers.get("mode", None)

        if self.inference_only:
            if mode == "per_weight":
                return self._forward_per_weight_eval(input)
            if mode == "per_block":
                return self._forward_per_block_eval(input)
            return self._forward_single_format_eval(input)

        if self.training:
            self._ht_train_step += 1
            if mode == "per_weight":
                return self._forward_per_weight_train(input)
            if mode == "per_block":
                return self._forward_per_block_train(input)
            return self._forward_single_format_train(input)

        if mode == "per_weight":
            return self._forward_per_weight_eval(input)
        if mode == "per_block":
            return self._forward_per_block_eval(input)
        return self._forward_single_format_eval(input)


def wrap_model_with_hypertensor(
    model: nn.Module,
    plan: Dict[str, Any],
    option: WeightOption = WeightOption.ALLOW,
    inference_only: bool = False,
) -> nn.Module:
    if not hasattr(model, "_hypertensor_plan"):
        model._hypertensor_plan = {}
    model._hypertensor_plan.update(plan["params"])

    qbuffers = build_quantized_buffers(model, plan, option)

    for name, module in model.named_modules():
        if isinstance(module, HyperLinear):
            module.inference_only = inference_only
            module.register_hypertensor_names(name)
            if module._hypertensor_param_name_weight in qbuffers:
                module.set_hypertensor_buffers(
                    qbuffers[module._hypertensor_param_name_weight]
                )

    return model
