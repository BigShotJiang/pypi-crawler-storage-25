from enum import Enum


class WeightOption(Enum):
    LOWEST = "lowest"
    HIGHEST = "highest"
    ALLOW = "allow"
    CLOSEST = "closest"
    AVERAGE = "average"
    BEST = "best"
    PER_WEIGHT = "per_weight"
    PER_BLOCK = "per_block"  # NEW: blockwise precision

    @classmethod
    def from_str(cls, s: str) -> "WeightOption":
        s = s.lower()
        for opt in cls:
            if opt.value == s:
                return opt
        raise ValueError(f"Unknown WeightOption: {s}")
