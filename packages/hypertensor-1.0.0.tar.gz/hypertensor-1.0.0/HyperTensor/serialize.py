from typing import Dict, Any, Type
import os
import torch
import torch.nn as nn


def save_hypertensors(
    model: nn.Module,
    plan: Dict[str, Any],
    path: str,
) -> None:
    if not path.endswith(".hypertensors"):
        path = path + ".hypertensors"

    payload: Dict[str, Any] = {
        "state_dict": model.state_dict(),
        "plan": plan,
    }
    torch.save(payload, path)


def load_hypertensors(
    path: str,
    model_class: Type[nn.Module],
    *model_args,
    **model_kwargs,
) -> nn.Module:
    if not os.path.exists(path):
        raise FileNotFoundError(path)

    payload = torch.load(path, map_location="cpu")
    state_dict = payload["state_dict"]
    plan = payload.get("plan", {"params": {}, "meta": {}})

    model = model_class(*model_args, **model_kwargs)
    model.load_state_dict(state_dict)
    model._hypertensor_plan = plan.get("params", {})
    model._hypertensor_meta = plan.get("meta", {})
    return model
