﻿# HyperTensor/hyper_attention.py

import math
from typing import Optional, Tuple

import torch
import torch.nn as nn

from .modules import HyperLinear


class HyperAttention(nn.Module):
    def __init__(
        self,
        hidden_size: int,
        num_heads: int,
        num_kv_heads: Optional[int] = None,
        bias: bool = False,
        rope_theta: float = 10000.0,
        prefer_bf16: bool = False,
        inference_only: bool = False,
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.num_heads = num_heads
        self.num_kv_heads = num_kv_heads or num_heads
        self.head_dim = hidden_size // num_heads
        self.rope_theta = rope_theta

        self.q_proj = HyperLinear(
            hidden_size,
            num_heads * self.head_dim,
            bias=bias,
            prefer_bf16=prefer_bf16,
            inference_only=inference_only,
        )
        self.k_proj = HyperLinear(
            hidden_size,
            self.num_kv_heads * self.head_dim,
            bias=bias,
            prefer_bf16=prefer_bf16,
            inference_only=inference_only,
        )
        self.v_proj = HyperLinear(
            hidden_size,
            self.num_kv_heads * self.head_dim,
            bias=bias,
            prefer_bf16=prefer_bf16,
            inference_only=inference_only,
        )
        self.o_proj = HyperLinear(
            num_heads * self.head_dim,
            hidden_size,
            bias=bias,
            prefer_bf16=prefer_bf16,
            inference_only=inference_only,
        )

        self.prefer_bf16 = prefer_bf16
        self.inference_only = inference_only

    def _shape(self, x: torch.Tensor, bsz: int, n_heads: int) -> torch.Tensor:
        return x.view(bsz, -1, n_heads, self.head_dim).transpose(1, 2)

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_value: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
        output_attentions: bool = False,
        use_cache: bool = False,
        **kwargs,
    ):
        bsz, q_len, _ = hidden_states.size()

        q = self.q_proj(hidden_states)
        k = self.k_proj(hidden_states)
        v = self.v_proj(hidden_states)

        q = self._shape(q, bsz, self.num_heads)          # [B,H,T,D]
        k = self._shape(k, bsz, self.num_kv_heads)
        v = self._shape(v, bsz, self.num_kv_heads)

        if past_key_value is not None:
            k = torch.cat([past_key_value[0], k], dim=2)
            v = torch.cat([past_key_value[1], v], dim=2)

        present = (k, v) if use_cache else None

        if self.num_kv_heads != self.num_heads:
            repeat_factor = self.num_heads // self.num_kv_heads
            k = k.repeat_interleave(repeat_factor, dim=1)
            v = v.repeat_interleave(repeat_factor, dim=1)

        dtype = torch.bfloat16 if self.prefer_bf16 else torch.float16
        q = q.to(dtype)
        k = k.to(dtype)
        v = v.to(dtype)

        # Fast FP16 attention using cuBLAS/FlashAttention
        attn_scores = torch.matmul(q, k.transpose(-1, -2)) / math.sqrt(self.head_dim)

        if attention_mask is not None:
            attn_scores = attn_scores + attention_mask

        attn_weights = torch.softmax(attn_scores, dim=-1)
        attn_output = torch.matmul(attn_weights, v)

        attn_output = attn_output.transpose(1, 2).contiguous().view(bsz, q_len, -1)
        attn_output = self.o_proj(attn_output)

        if output_attentions:
            return attn_output, present, attn_weights
        return attn_output, present
