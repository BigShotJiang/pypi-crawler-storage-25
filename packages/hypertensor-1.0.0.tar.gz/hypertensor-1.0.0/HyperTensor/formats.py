from enum import IntEnum
import torch


class PrecisionFormat(IntEnum):
    INT4 = 1
    INT8 = 2
    FP16 = 5
    BF16 = 6
    FP32 = 7


PRECISION_ORDER = [
    PrecisionFormat.INT4,
    PrecisionFormat.INT8,
    PrecisionFormat.FP16,
    PrecisionFormat.BF16,
    PrecisionFormat.FP32,
]


def _can_be_int4(x: torch.Tensor) -> torch.Tensor:
    return (x == x.round()) & (x >= -8) & (x <= 7)


def _can_be_int8(x: torch.Tensor) -> torch.Tensor:
    return (x == x.round()) & (x >= -128) & (x <= 127)


def _roundtrip_error(x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
    return (x - y).abs()


def _can_be_fp16(x: torch.Tensor, eps: float = 0.0) -> torch.Tensor:
    x16 = x.to(torch.float16)
    x32 = x16.to(torch.float32)
    if eps == 0.0:
        return x32 == x
    else:
        return _roundtrip_error(x, x32) <= eps


def _can_be_bf16(x: torch.Tensor, eps: float = 0.0) -> torch.Tensor:
    x16 = x.to(torch.bfloat16)
    x32 = x16.to(torch.float32)
    if eps == 0.0:
        return x32 == x
    else:
        return _roundtrip_error(x, x32) <= eps


def choose_format_for_tensor(
    t: torch.Tensor,
    eps_int4: float = 1e-1,
    eps_int8: float = 5e-2,
    eps_fp16: float = 1e-3,
    eps_bf16: float = 1e-3,
    prefer_bf16: bool = False,
) -> torch.Tensor:
    """
    Per-weight format choice based on approximate fit.
    - INT4: allowed if quantization error <= eps_int4
    - INT8: if INT4 too inaccurate, but error <= eps_int8
    - FP16/BF16: if INT8 too inaccurate, but error <= eps_fp16/eps_bf16
    - FP32: fallback if nothing else fits well
    """

    w32 = t.to(torch.float32)
    fmt = torch.full_like(w32, fill_value=int(PrecisionFormat.FP32), dtype=torch.int8)

    # ----- INT4 -----
    q4 = w32.round().clamp(-8, 7)
    err4 = (w32 - q4).abs()
    mask_int4 = err4 <= eps_int4
    fmt[mask_int4] = int(PrecisionFormat.INT4)

    # ----- INT8 (only where not INT4) -----
    q8 = w32.round().clamp(-128, 127)
    err8 = (w32 - q8).abs()
    mask_int8 = (err8 <= eps_int8) & ~mask_int4
    fmt[mask_int8] = int(PrecisionFormat.INT8)

    # ----- FP16 / BF16 (only where not INT4/INT8) -----
    remaining = ~mask_int4 & ~mask_int8

    if prefer_bf16:
        # BF16 first
        x_bf16 = w32.to(torch.bfloat16)
        x_bf32 = x_bf16.to(torch.float32)
        err_bf16 = (w32 - x_bf32).abs()
        mask_bf16 = (err_bf16 <= eps_bf16) & remaining
        fmt[mask_bf16] = int(PrecisionFormat.BF16)

        remaining = remaining & ~mask_bf16

        x_f16 = w32.to(torch.float16)
        x_f32 = x_f16.to(torch.float32)
        err_f16 = (w32 - x_f32).abs()
        mask_fp16 = (err_f16 <= eps_fp16) & remaining
        fmt[mask_fp16] = int(PrecisionFormat.FP16)
    else:
        # FP16 first
        x_f16 = w32.to(torch.float16)
        x_f32 = x_f16.to(torch.float32)
        err_f16 = (w32 - x_f32).abs()
        mask_fp16 = (err_f16 <= eps_fp16) & remaining
        fmt[mask_fp16] = int(PrecisionFormat.FP16)

        remaining = remaining & ~mask_fp16

        x_bf16 = w32.to(torch.bfloat16)
        x_bf32 = x_bf16.to(torch.float32)
        err_bf16 = (w32 - x_bf32).abs()
        mask_bf16 = (err_bf16 <= eps_bf16) & remaining
        fmt[mask_bf16] = int(PrecisionFormat.BF16)

    # Anything that didn't fit any of the above stays FP32
    return fmt.to(torch.int8)
