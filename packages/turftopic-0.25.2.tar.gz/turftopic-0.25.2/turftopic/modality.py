from abc import abstractmethod
from collections import defaultdict

import numpy as np
from PIL import Image
from sentence_transformers.base.modality import Modality, infer_modality


def _get_modalities(inputs, supported: list[Modality]) -> list[Modality]:
    out = []
    for input in inputs:
        out.append(infer_modality(input, supported))
    return out


def groupby_modality(
    X: list | np.ndarray, modalities: list[Modality]
) -> dict[str, np.ndarray | list]:
    is_array = isinstance(X, np.ndarray)
    groups = defaultdict(list)
    for x, m in zip(X, modalities):
        if isinstance(m, tuple):
            for _m in m:
                groups[_m].append(x)
        else:
            groups[m].append(x)
    if is_array:
        groups = {m: np.stack(m_x) for m, m_x in groups.items()}
    return groups


class Multimodal:
    @property
    def supported_modalities(self) -> list[Modality]:
        return ["text"]

    def get_modalities(self, inputs):
        return _get_modalities(inputs, self.supported_modalities)

    def extract_modality(self, inputs, modality: Modality) -> list:
        modalities = self.get_modalities(inputs)
        out = []
        for inp, m in zip(inputs, modalities):
            if m == modality:
                out.append(inp)
            elif m in modality:
                out.append(inp[m])
        return out

    def collect_top_k(
        self,
        inputs,
        doc_topic_matrix: np.ndarray,
        top_k: int = 10,
        prefix: str = "top",
    ):
        document_ids = np.arange(len(inputs))
        groups = groupby_modality(document_ids, self.get_modalities(inputs))
        input_array = np.array(inputs)
        for supported in self.supported_modalities:
            m_ids = groups.get(supported, None)
            if m_ids is None:
                continue
            else:
                toplist = []
                setattr(
                    self, f"{supported}_topic_matrix", doc_topic_matrix[m_ids]
                )
                for doc_topic_vec in doc_topic_matrix[m_ids].T:
                    top_inputs = np.argsort(-doc_topic_vec)[:10]
                    top_ids = m_ids[top_inputs]
                    top_inputs = input_array[top_ids]
                    top_m = self.extract_modality(top_inputs, supported)
                    if supported == "image":
                        top_m = [
                            Image.open(im) if not isinstance(im, Image) else im
                            for im in top_m
                        ]
                    toplist.append(list(top_m))
                setattr(self, f"{prefix}_{supported}s", toplist)
