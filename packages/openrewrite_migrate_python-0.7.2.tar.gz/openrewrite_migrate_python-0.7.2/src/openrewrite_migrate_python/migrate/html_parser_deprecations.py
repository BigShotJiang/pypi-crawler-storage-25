"""
Recipe for replacing deprecated HTMLParser.unescape() with html.unescape().

HTMLParser.unescape() was deprecated in Python 3.4 and removed in Python 3.9.
Use html.unescape() instead.

See: https://docs.python.org/3/whatsnew/3.9.html#removed
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Preconditions, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.preconditions import uses_method
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier, MethodInvocation

# Define category path: Python > Migrate > Python 3.9
_Python39 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.9"),
]


@categorize(_Python39)
class ReplaceHtmlParserUnescape(Recipe):
    """
    Replace `HTMLParser.unescape()` with `html.unescape()`.

    `HTMLParser.unescape()` was deprecated in Python 3.4 and removed in Python 3.9.
    Use `html.unescape()` instead.

    Example:
        Before:
            from html.parser import HTMLParser
            parser = HTMLParser()
            text = parser.unescape(html_text)

        After:
            import html
            text = html.unescape(html_text)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceHtmlParserUnescape"

    @property
    def display_name(self) -> str:
        return "Replace `HTMLParser.unescape()` with `html.unescape()`"

    @property
    def description(self) -> str:
        return (
            "`HTMLParser.unescape()` was removed in Python 3.9. "
            "Use `html.unescape()` instead."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.9", "html"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "unescape":
                    return method

                # Already using html.unescape(), no change needed
                select = method.select
                if isinstance(select, Identifier) and select.simple_name == "html":
                    return method

                # Skip if no select (bare function call)
                if select is None:
                    return method

                # Require type info to confirm HTMLParser
                if not method.method_type or not method.method_type.declaring_type:
                    return method
                dt = method.method_type.declaring_type
                if not hasattr(dt, '_fully_qualified_name'):
                    return method
                fqn = str(dt._fully_qualified_name)
                if 'html.parser' not in fqn:
                    return method

                # Replace select with html identifier
                if isinstance(select, Identifier):
                    new_select = select.replace(_simple_name="html")
                    old_padded = method.padding.select
                    new_padded = old_padded.replace(_element=new_select)
                    return method.padding.replace(_select=new_padded)

                return method

        return Preconditions.check(uses_method("*..* unescape(..)"), Visitor())
