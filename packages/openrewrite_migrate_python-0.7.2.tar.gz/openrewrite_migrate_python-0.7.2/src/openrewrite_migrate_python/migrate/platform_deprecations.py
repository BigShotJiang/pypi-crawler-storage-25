"""
Recipes for replacing deprecated platform.popen() with subprocess.check_output().

platform.popen() was deprecated in Python 3.3 and removed in Python 3.8.
Use subprocess.check_output(cmd, shell=True) instead.

See: https://docs.python.org/3/whatsnew/3.8.html#api-and-feature-removals
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Preconditions, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers
from rewrite.python.preconditions import uses_method
from rewrite.python.visitor import PythonVisitor
from rewrite.java.support_types import JLeftPadded, JRightPadded, Space
from rewrite.java.tree import Identifier, Literal, MethodInvocation
from rewrite.python.tree import NamedArgument
from rewrite.utils import random_id

# Define category path: Python > Migrate > Python 3.8
_Python38 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.8"),
]


@categorize(_Python38)
class ReplacePlatformPopen(Recipe):
    """
    Replace `platform.popen(cmd)` with `subprocess.check_output(cmd, shell=True)`.

    `platform.popen()` was deprecated in Python 3.3 and removed in Python 3.8.

    Example:
        Before:
            import platform
            output = platform.popen('ls')

        After:
            import subprocess
            output = subprocess.check_output('ls', shell=True)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplacePlatformPopen"

    @property
    def display_name(self) -> str:
        return "Replace `platform.popen()` with `subprocess.check_output()`"

    @property
    def description(self) -> str:
        return (
            "`platform.popen()` was removed in Python 3.8. "
            "Use `subprocess.check_output(cmd, shell=True)` instead. "
            "Note: this rewrites call sites but does not manage imports."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.8", "platform"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "popen":
                    return method

                select = method.select
                if not isinstance(select, Identifier):
                    return method
                if select.simple_name != "platform":
                    return method

                # Replace platform with subprocess
                new_select = select.replace(_simple_name="subprocess")
                old_padded_select = method.padding.select
                new_padded_select = old_padded_select.replace(_element=new_select)
                method = method.padding.replace(_select=new_padded_select)

                # Rename popen -> check_output
                new_name = method.name.replace(_simple_name="check_output")
                method = method.replace(_name=new_name)

                # Add shell=True keyword argument
                shell_name = Identifier(
                    _id=random_id(),
                    _prefix=Space.EMPTY,
                    _markers=Markers.EMPTY,
                    _annotations=[],
                    _simple_name="shell",
                    _type=None,
                    _field_type=None,
                )
                true_literal = Identifier(
                    _id=random_id(),
                    _prefix=Space.EMPTY,
                    _markers=Markers.EMPTY,
                    _annotations=[],
                    _simple_name="True",
                    _type=None,
                    _field_type=None,
                )
                true_padded_value = JLeftPadded(
                    _before=Space.EMPTY,
                    _element=true_literal,
                    _markers=Markers.EMPTY,
                )
                shell_arg = NamedArgument(
                    _id=random_id(),
                    _prefix=Space.SINGLE_SPACE,
                    _markers=Markers.EMPTY,
                    _name=shell_name,
                    _value=true_padded_value,
                    _type=None,
                )
                shell_padded = JRightPadded(shell_arg, Space.EMPTY, Markers.EMPTY)

                old_container = method.padding.arguments
                old_elements = list(old_container.padding.elements)
                old_elements.append(shell_padded)
                new_container = old_container.replace(_elements=old_elements)
                method = method.replace(_arguments=new_container)

                return method

        return Preconditions.check(uses_method("*..* popen(..)"), Visitor())
