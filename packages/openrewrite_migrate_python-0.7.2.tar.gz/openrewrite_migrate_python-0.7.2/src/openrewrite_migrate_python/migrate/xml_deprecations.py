"""
Recipes for migrating deprecated xml.etree.ElementTree methods.

Several Element methods were deprecated in Python 3.9:
- Element.getchildren() -> list(element)
- Element.getiterator() -> element.iter()

See: https://docs.python.org/3/library/xml.etree.elementtree.html
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Preconditions, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers
from rewrite.python.preconditions import uses_method
from rewrite.python.visitor import PythonVisitor
from rewrite.java.support_types import JRightPadded, Space
from rewrite.java.tree import Identifier, MethodInvocation
from rewrite.utils import random_id

# Define category path: Python > Migrate > Python 3.9
_Python39 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.9"),
]


@categorize(_Python39)
class ReplaceElementGetchildren(Recipe):
    """
    Replace `Element.getchildren()` with `list(element)`.

    The `getchildren()` method was deprecated in Python 3.9. Instead of
    `element.getchildren()`, use `list(element)` to get child elements.

    Example:
        Before:
            children = element.getchildren()

        After:
            children = list(element)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceElementGetchildren"

    @property
    def display_name(self) -> str:
        return "Replace `Element.getchildren()` with `list(element)`"

    @property
    def description(self) -> str:
        return (
            "Replace `getchildren()` with `list(element)` on XML Element objects. "
            "Deprecated in Python 3.9."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.9", "xml"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "getchildren":
                    return method

                # Must have a select (the element we're calling getchildren on)
                select = method.select
                if select is None:
                    return method

                # Require type info to confirm XML Element
                if not method.method_type or not method.method_type.declaring_type:
                    return method
                dt = method.method_type.declaring_type
                if not hasattr(dt, '_fully_qualified_name'):
                    return method
                fqn = str(dt._fully_qualified_name)
                if 'xml.etree' not in fqn:
                    return method

                # Transform: element.getchildren() -> list(element)
                # 1. Change method name to "list"
                new_name = method.name.replace(_simple_name="list")

                # 2. Move the select expression to be the first argument
                # Preserve the select's expression but adjust spacing
                arg_expr = select.replace(_prefix=Space.EMPTY)
                new_arg_padded = JRightPadded(arg_expr, Space.EMPTY, Markers.EMPTY)

                # 3. Replace arguments with the single argument
                old_container = method.padding.arguments
                new_container = old_container.replace(_elements=[new_arg_padded])

                # 4. Remove the select and set new name and arguments
                # Build the new method invocation without select
                result = method.replace(_name=new_name, _arguments=new_container)

                # 5. Clear the select via padding
                old_padded_select = result.padding.select
                if old_padded_select is not None:
                    result = result.padding.replace(_select=None)

                return result

        return Preconditions.check(uses_method("*..* getchildren(..)"), Visitor())


@categorize(_Python39)
class ReplaceElementGetiterator(Recipe):
    """
    Replace `Element.getiterator()` with `Element.iter()`.

    The `getiterator()` method was deprecated in Python 3.9 and will be
    removed in a future version. Use `iter()` instead.

    Example:
        Before:
            for child in element.getiterator():
                ...
            for tag in element.getiterator('tag'):
                ...

        After:
            for child in element.iter():
                ...
            for tag in element.iter('tag'):
                ...
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceElementGetiterator"

    @property
    def display_name(self) -> str:
        return "Replace `Element.getiterator()` with `Element.iter()`"

    @property
    def description(self) -> str:
        return (
            "Replace `getiterator()` with `iter()` on XML Element objects. "
            "The getiterator() method was deprecated in Python 3.9."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.9", "xml"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "getiterator":
                    return method

                # Require type info to confirm XML Element
                if not method.method_type or not method.method_type.declaring_type:
                    return method
                dt = method.method_type.declaring_type
                if not hasattr(dt, '_fully_qualified_name'):
                    return method
                fqn = str(dt._fully_qualified_name)
                if 'xml.etree' not in fqn:
                    return method

                # Replace getiterator with iter
                new_name = method.name.replace(_simple_name="iter")
                return method.replace(_name=new_name)

        return Preconditions.check(uses_method("*..* getiterator(..)"), Visitor())
