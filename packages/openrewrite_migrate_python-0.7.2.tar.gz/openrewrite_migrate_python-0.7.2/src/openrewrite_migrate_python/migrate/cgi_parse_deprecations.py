"""
Recipes for replacing deprecated cgi.parse_qs/parse_qsl with
urllib.parse.parse_qs/parse_qsl.

The following functions were deprecated in Python 3.2 and removed in Python 3.8:
- cgi.parse_qs() -> urllib.parse.parse_qs()
- cgi.parse_qsl() -> urllib.parse.parse_qsl()

Note: cgi.escape() -> html.escape() is handled in cgi_migrations.py.

See: https://docs.python.org/3/whatsnew/3.8.html#api-and-feature-removals
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Preconditions, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers
from rewrite.python.preconditions import uses_method
from rewrite.python.visitor import PythonVisitor
from rewrite.java.support_types import JLeftPadded, Space
from rewrite.java.tree import FieldAccess, Identifier, MethodInvocation
from rewrite.utils import random_id

# Define category path: Python > Migrate > Python 3.8
_Python38 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.8"),
]


def _create_urllib_parse_select(original_select: Identifier) -> FieldAccess:
    """Create a FieldAccess node representing 'urllib.parse'.

    Preserves the prefix/whitespace from the original select.
    """
    parse_identifier = Identifier(
        _id=random_id(),
        _prefix=Space.EMPTY,
        _markers=Markers.EMPTY,
        _annotations=[],
        _simple_name="parse",
        _type=None,
        _field_type=None,
    )

    padded_parse = JLeftPadded(
        _before=Space.EMPTY,
        _element=parse_identifier,
        _markers=Markers.EMPTY,
    )

    urllib_identifier = Identifier(
        _id=random_id(),
        _prefix=original_select.prefix,
        _markers=Markers.EMPTY,
        _annotations=[],
        _simple_name="urllib",
        _type=None,
        _field_type=None,
    )

    return FieldAccess(
        _id=random_id(),
        _prefix=Space.EMPTY,
        _markers=Markers.EMPTY,
        _target=urllib_identifier,
        _name=padded_parse,
        _type=None,
    )


@categorize(_Python38)
class ReplaceCgiParseQs(Recipe):
    """
    Replace `cgi.parse_qs()` with `urllib.parse.parse_qs()`.

    `cgi.parse_qs()` was deprecated in Python 3.2 and removed in Python 3.8.
    Use `urllib.parse.parse_qs()` instead.

    Example:
        Before:
            import cgi
            params = cgi.parse_qs(query_string)

        After:
            from urllib.parse import parse_qs
            params = urllib.parse.parse_qs(query_string)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceCgiParseQs"

    @property
    def display_name(self) -> str:
        return "Replace `cgi.parse_qs()` with `urllib.parse.parse_qs()`"

    @property
    def description(self) -> str:
        return (
            "`cgi.parse_qs()` was removed in Python 3.8. "
            "Use `urllib.parse.parse_qs()` instead. "
            "Note: this rewrites call sites but does not manage imports. "
            "Use with `ChangeImport` in a composite recipe to update `from` imports."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.8", "cgi"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "parse_qs":
                    return method

                select = method.select
                if not isinstance(select, Identifier):
                    return method
                if select.simple_name != "cgi":
                    return method

                # Replace cgi with urllib.parse
                new_select = _create_urllib_parse_select(select)
                old_padded = method.padding.select
                new_padded = old_padded.replace(_element=new_select)
                return method.padding.replace(_select=new_padded)

        return Preconditions.check(uses_method("*..* parse_qs(..)"), Visitor())


@categorize(_Python38)
class ReplaceCgiParseQsl(Recipe):
    """
    Replace `cgi.parse_qsl()` with `urllib.parse.parse_qsl()`.

    `cgi.parse_qsl()` was deprecated in Python 3.2 and removed in Python 3.8.
    Use `urllib.parse.parse_qsl()` instead.

    Example:
        Before:
            import cgi
            params = cgi.parse_qsl(query_string)

        After:
            from urllib.parse import parse_qsl
            params = urllib.parse.parse_qsl(query_string)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceCgiParseQsl"

    @property
    def display_name(self) -> str:
        return "Replace `cgi.parse_qsl()` with `urllib.parse.parse_qsl()`"

    @property
    def description(self) -> str:
        return (
            "`cgi.parse_qsl()` was removed in Python 3.8. "
            "Use `urllib.parse.parse_qsl()` instead. "
            "Note: this rewrites call sites but does not manage imports. "
            "Use with `ChangeImport` in a composite recipe to update `from` imports."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.8", "cgi"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "parse_qsl":
                    return method

                select = method.select
                if not isinstance(select, Identifier):
                    return method
                if select.simple_name != "cgi":
                    return method

                # Replace cgi with urllib.parse
                new_select = _create_urllib_parse_select(select)
                old_padded = method.padding.select
                new_padded = old_padded.replace(_element=new_select)
                return method.padding.replace(_select=new_padded)

        return Preconditions.check(uses_method("*..* parse_qsl(..)"), Visitor())
