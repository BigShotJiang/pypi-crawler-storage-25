"""HTTP client for the Orkestr API."""

import sys

import click
import httpx

from orkestr_cli import config


def _client() -> httpx.Client:
    headers = config.get_auth_header()
    return httpx.Client(
        base_url=config.get_api_url(),
        headers=headers,
        timeout=30.0,
    )


def _request(method: str, path: str, **kwargs) -> httpx.Response:
    """Execute a request with connection error handling."""
    try:
        with _client() as c:
            return getattr(c, method)(path, **kwargs)
    except httpx.ConnectError:
        url = config.get_api_url()
        click.secho(f"Connection refused: {url}", fg="red", err=True)
        click.secho("Is the API running? Check with: orkestr set-url <url>", err=True)
        sys.exit(1)
    except httpx.TimeoutException:
        click.secho("Request timed out.", fg="red", err=True)
        sys.exit(1)
    except httpx.HTTPError as e:
        click.secho(f"HTTP error: {e}", fg="red", err=True)
        sys.exit(1)


def _handle(resp: httpx.Response) -> dict | list | None:
    if resp.status_code == 204:
        return None
    if resp.status_code == 401:
        click.secho("Authentication required. Run: orkestr login <token>", fg="red", err=True)
        sys.exit(1)
    if resp.status_code >= 400:
        try:
            detail = resp.json().get("detail", resp.text)
        except Exception:
            detail = resp.text
        click.secho(f"Error ({resp.status_code}): {detail}", fg="red", err=True)
        sys.exit(1)
    return resp.json()


def _get(path: str, **kwargs):
    return _handle(_request("get", path, **kwargs))


def _post(path: str, **kwargs):
    return _handle(_request("post", path, **kwargs))


def _patch(path: str, **kwargs):
    return _handle(_request("patch", path, **kwargs))


def _delete(path: str, **kwargs):
    return _handle(_request("delete", path, **kwargs))


# -- Auth -------------------------------------------------------------------

def me() -> dict:
    return _get("/api/auth/me")


# -- Helpers ----------------------------------------------------------------

def resolve_project_id(name_or_id: str) -> str:
    """Accept a project name or UUID, return the full UUID."""
    # Already looks like a UUID
    if len(name_or_id) >= 32 or name_or_id.count("-") >= 4:
        return name_or_id
    # Search by name
    data = list_projects(limit=100)
    for p in data.get("projects", []):
        if p.get("name") == name_or_id:
            return p["id"]
    click.secho(f"Project not found: {name_or_id}", fg="red", err=True)
    sys.exit(1)


# -- Projects ---------------------------------------------------------------

def list_projects(skip: int = 0, limit: int = 20) -> dict:
    return _get("/api/v1/projects", params={"skip": skip, "limit": limit})


def create_project(name: str, repo_url: str, branch: str = "main",
                   display_name: str | None = None, description: str | None = None,
                   env_vars: dict | None = None) -> dict:
    payload = {"name": name, "repo_url": repo_url, "repo_branch": branch}
    if display_name:
        payload["display_name"] = display_name
    if description:
        payload["description"] = description
    if env_vars:
        payload["env_vars"] = env_vars
    return _post("/api/v1/projects", json=payload)


def get_project(project_id: str) -> dict:
    return _get(f"/api/v1/projects/{project_id}")


def update_project(project_id: str, **fields) -> dict:
    return _patch(f"/api/v1/projects/{project_id}", json=fields)


def delete_project(project_id: str):
    _delete(f"/api/v1/projects/{project_id}")


def analyze_project(project_id: str) -> dict:
    return _post(f"/api/v1/projects/{project_id}/analyze")


# -- Environments -----------------------------------------------------------

def list_environments(project_id: str) -> list:
    return _get(f"/api/v1/projects/{project_id}/environments")


def create_environment(project_id: str, name: str, branch: str,
                       env_vars: dict | None = None, auto_deploy: bool = True) -> dict:
    payload = {"name": name, "branch": branch, "auto_deploy": auto_deploy}
    if env_vars:
        payload["env_vars"] = env_vars
    return _post(f"/api/v1/projects/{project_id}/environments", json=payload)


def update_environment(project_id: str, env_id: str, **fields) -> dict:
    return _patch(f"/api/v1/projects/{project_id}/environments/{env_id}", json=fields)


def delete_environment(project_id: str, env_id: str):
    _delete(f"/api/v1/projects/{project_id}/environments/{env_id}")


# -- Deployments ------------------------------------------------------------

def trigger_deployment(project_id: str, environment_id: str | None = None) -> dict:
    params = {}
    if environment_id:
        params["environment_id"] = environment_id
    return _post(f"/api/v1/projects/{project_id}/deployments", params=params)


def list_deployments(project_id: str, skip: int = 0, limit: int = 20) -> dict:
    return _get(f"/api/v1/projects/{project_id}/deployments",
                params={"skip": skip, "limit": limit})


def get_deployment(deployment_id: str) -> dict:
    return _get(f"/api/v1/deployments/{deployment_id}")


def get_deployment_logs(deployment_id: str) -> dict:
    return _get(f"/api/v1/deployments/{deployment_id}/logs")


def rollback_deployment(deployment_id: str) -> dict:
    return _post(f"/api/v1/deployments/{deployment_id}/rollback")


# -- Addons -----------------------------------------------------------------

def list_addons(project_id: str) -> dict:
    return _get(f"/api/v1/projects/{project_id}/addons")


def create_addon(project_id: str, name: str, service_type: str,
                 version: str | None = None, env_var_name: str | None = None) -> dict:
    payload = {"name": name, "service_type": service_type}
    if version:
        payload["version"] = version
    if env_var_name:
        payload["env_var_name"] = env_var_name
    return _post(f"/api/v1/projects/{project_id}/addons", json=payload)


def delete_addon(project_id: str, addon_id: str):
    _delete(f"/api/v1/projects/{project_id}/addons/{addon_id}")


# -- Backups ----------------------------------------------------------------

def list_backups(project_id: str, addon_id: str) -> dict:
    return _get(f"/api/projects/{project_id}/addons/{addon_id}/backups")


def create_backup(project_id: str, addon_id: str) -> dict:
    return _post(f"/api/projects/{project_id}/addons/{addon_id}/backups")


def download_backup(project_id: str, addon_id: str, backup_id: str) -> dict:
    return _get(f"/api/projects/{project_id}/addons/{addon_id}/backups/{backup_id}/download")


def delete_backup(project_id: str, addon_id: str, backup_id: str):
    _delete(f"/api/projects/{project_id}/addons/{addon_id}/backups/{backup_id}")


# -- Monitoring -------------------------------------------------------------

def get_stats(project_id: str, environment_id: str | None = None) -> dict:
    params = {}
    if environment_id:
        params["environment_id"] = environment_id
    return _get(f"/api/v1/projects/{project_id}/stats", params=params)


def get_logs(project_id: str, environment_id: str | None = None, lines: int = 200) -> dict:
    params = {"lines": lines}
    if environment_id:
        params["environment_id"] = environment_id
    return _get(f"/api/v1/projects/{project_id}/logs", params=params)


def get_health(project_id: str, environment_id: str | None = None) -> dict:
    params = {}
    if environment_id:
        params["environment_id"] = environment_id
    return _get(f"/api/v1/projects/{project_id}/health", params=params)
