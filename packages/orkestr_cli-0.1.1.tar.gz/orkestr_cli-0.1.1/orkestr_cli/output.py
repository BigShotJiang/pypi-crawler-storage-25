"""Output formatting helpers using Rich."""

import json as json_mod

import click
from rich.console import Console
from rich.table import Table

console = Console()


def print_json(data):
    """Print raw JSON output."""
    click.echo(json_mod.dumps(data, indent=2, default=str))


def print_table(title: str, columns: list[str], rows: list[list[str]]):
    """Print a Rich table."""
    table = Table(title=title, show_lines=False)
    for col in columns:
        table.add_column(col)
    for row in rows:
        table.add_row(*[str(c) for c in row])
    console.print(table)


def print_kv(pairs: list[tuple[str, str]]):
    """Print key-value pairs."""
    max_key = max(len(k) for k, _ in pairs) if pairs else 0
    for key, value in pairs:
        click.echo(f"  {key:<{max_key + 2}} {value}")


def truncate(text: str, length: int = 40) -> str:
    if not text:
        return "-"
    return text[:length] + "..." if len(text) > length else text


def format_dt(dt_str: str | None) -> str:
    if not dt_str:
        return "-"
    return dt_str[:19].replace("T", " ")


def status_color(status: str) -> str:
    colors = {
        "live": "green",
        "running": "green",
        "active": "green",
        "building": "yellow",
        "deploying": "yellow",
        "queued": "cyan",
        "failed": "red",
        "deleted": "dim",
        "stopped": "dim",
    }
    color = colors.get(status, "white")
    return click.style(status, fg=color)
