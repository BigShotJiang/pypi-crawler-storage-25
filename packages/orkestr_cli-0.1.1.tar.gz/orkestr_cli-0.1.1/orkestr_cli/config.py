"""Configuration and credential storage for the Orkestr CLI."""

import json
from pathlib import Path

CONFIG_DIR = Path.home() / ".orkestr"
CONFIG_FILE = CONFIG_DIR / "config.json"

DEFAULTS = {
    "api_url": "https://api.orkestr.eu",
}


def _ensure_dir():
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.touch(exist_ok=True)


def load() -> dict:
    _ensure_dir()
    text = CONFIG_FILE.read_text().strip()
    if not text:
        return dict(DEFAULTS)
    data = json.loads(text)
    for k, v in DEFAULTS.items():
        data.setdefault(k, v)
    return data


def save(data: dict):
    _ensure_dir()
    CONFIG_FILE.write_text(json.dumps(data, indent=2) + "\n")


def get_api_url() -> str:
    return load().get("api_url", DEFAULTS["api_url"])


def get_auth_header() -> dict[str, str]:
    """Return the Authorization header dict, or empty dict if not logged in."""
    cfg = load()
    token = cfg.get("api_token") or cfg.get("access_token")
    if not token:
        return {}
    prefix = "Bearer" if cfg.get("access_token") else "Bearer"
    return {"Authorization": f"{prefix} {token}"}


def store_tokens(access_token: str, refresh_token: str | None = None):
    cfg = load()
    cfg["access_token"] = access_token
    if refresh_token:
        cfg["refresh_token"] = refresh_token
    cfg.pop("api_token", None)
    save(cfg)


def store_api_token(token: str):
    cfg = load()
    cfg["api_token"] = token
    cfg.pop("access_token", None)
    cfg.pop("refresh_token", None)
    save(cfg)


def clear_auth():
    cfg = load()
    cfg.pop("access_token", None)
    cfg.pop("refresh_token", None)
    cfg.pop("api_token", None)
    save(cfg)


def is_logged_in() -> bool:
    cfg = load()
    return bool(cfg.get("access_token") or cfg.get("api_token"))
