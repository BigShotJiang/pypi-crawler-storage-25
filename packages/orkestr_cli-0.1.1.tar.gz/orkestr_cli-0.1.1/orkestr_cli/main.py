"""Orkestr CLI — manage your projects, deployments, and infrastructure."""

import click

from orkestr_cli import api, config
from orkestr_cli.output import (
    console,
    format_dt,
    print_json,
    print_kv,
    print_table,
    status_color,
    truncate,
)


# ---------------------------------------------------------------------------
# Root group
# ---------------------------------------------------------------------------

@click.group()
@click.option("--api-url", envvar="ORKESTR_API_URL", help="Override API base URL.")
@click.option("--token", envvar="ORKESTR_API_TOKEN", help="API token for auth.")
@click.option("--json", "use_json", is_flag=True, help="Output raw JSON.")
@click.version_option("0.1.1", prog_name="orkestr")
@click.pass_context
def cli(ctx, api_url, token, use_json):
    """Orkestr CLI — deploy and manage your applications."""
    ctx.ensure_object(dict)
    ctx.obj["json"] = use_json

    if api_url:
        cfg = config.load()
        cfg["api_url"] = api_url
        config.save(cfg)

    if token:
        config.store_api_token(token)


# ---------------------------------------------------------------------------
# Auth commands
# ---------------------------------------------------------------------------

@cli.command()
@click.option("--token", prompt="API token", hide_input=True, prompt_required=True,
              help="API token (will be prompted if not provided).")
def login(token):
    """Authenticate with an API token.

    Generate a token from the Orkestr dashboard under Settings > API Tokens.
    """
    token = token.strip()
    if not token:
        click.secho("Token cannot be empty.", fg="red", err=True)
        raise SystemExit(1)
    config.store_api_token(token)
    data = api.me()
    click.secho(f"Logged in as {data.get('username', 'unknown')}.", fg="green")


@cli.command()
def logout():
    """Clear stored credentials."""
    config.clear_auth()
    click.secho("Logged out.", fg="green")


@cli.command()
@click.pass_context
def whoami(ctx):
    """Show current user info."""
    data = api.me()
    if ctx.obj["json"]:
        print_json(data)
        return
    print_kv([
        ("Username:", data.get("username", "-")),
        ("Email:", data.get("email", "-")),
        ("Plan:", data.get("plan", "-")),
        ("Active:", str(data.get("is_active", "-"))),
        ("Created:", format_dt(data.get("created_at"))),
    ])


@cli.command("set-url")
@click.argument("url")
def set_url(url):
    """Set the API base URL."""
    cfg = config.load()
    cfg["api_url"] = url.rstrip("/")
    config.save(cfg)
    click.secho(f"API URL set to {cfg['api_url']}", fg="green")



# ---------------------------------------------------------------------------
# Projects
# ---------------------------------------------------------------------------

@cli.group()
def projects():
    """Manage projects."""


@projects.command("list")
@click.option("--limit", default=20, help="Max results.")
@click.pass_context
def projects_list(ctx, limit):
    """List all projects."""
    data = api.list_projects(limit=limit)
    if ctx.obj["json"]:
        print_json(data)
        return

    rows = []
    for p in data.get("projects", []):
        rows.append([
            p.get("name", "-"),
            p.get("display_name") or p.get("name", "-"),
            p.get("framework") or "-",
            status_color(p.get("status", "-")),
            format_dt(p.get("created_at")),
        ])
    print_table("Projects", ["Name", "Display Name", "Framework", "Status", "Created"], rows)
    click.echo(f"\nTotal: {data.get('total', len(rows))}")


@projects.command("create")
@click.argument("name")
@click.option("--repo", required=True, help="Git repository URL.")
@click.option("--branch", default="main", help="Default branch.")
@click.option("--display-name", help="Display name.")
@click.option("--description", help="Project description.")
@click.pass_context
def projects_create(ctx, name, repo, branch, display_name, description):
    """Create a new project."""
    data = api.create_project(
        name=name,
        repo_url=repo,
        branch=branch,
        display_name=display_name,
        description=description,
    )
    if ctx.obj["json"]:
        print_json(data)
        return
    click.secho(f"Project '{data['name']}' created.", fg="green")
    print_kv([
        ("ID:", data["id"]),
        ("Domain:", data.get("domain", "-")),
    ])


@projects.command("show")
@click.argument("project")
@click.pass_context
def projects_show(ctx, project):
    """Show project details. Accepts a project name or UUID."""
    project_id = api.resolve_project_id(project)
    data = api.get_project(project_id)
    if ctx.obj["json"]:
        print_json(data)
        return
    print_kv([
        ("ID:", data["id"]),
        ("Name:", data.get("name", "-")),
        ("Display Name:", data.get("display_name") or "-"),
        ("Repo:", data.get("repo_url", "-")),
        ("Branch:", data.get("repo_branch", "-")),
        ("Framework:", data.get("framework") or "-"),
        ("Dockerfile:", str(data.get("has_dockerfile", "-"))),
        ("Status:", data.get("status", "-")),
        ("Domain:", data.get("domain") or "-"),
        ("Created:", format_dt(data.get("created_at"))),
    ])


@projects.command("delete")
@click.argument("project")
@click.confirmation_option(prompt="Are you sure you want to delete this project?")
def projects_delete(project):
    """Delete a project and its infrastructure. Accepts a project name or UUID."""
    project_id = api.resolve_project_id(project)
    api.delete_project(project_id)
    click.secho("Project deleted.", fg="green")


@projects.command("analyze")
@click.argument("project")
@click.pass_context
def projects_analyze(ctx, project):
    """Analyze a project's repository. Accepts a project name or UUID."""
    project_id = api.resolve_project_id(project)
    data = api.analyze_project(project_id)
    if ctx.obj["json"]:
        print_json(data)
        return
    print_kv([
        ("Framework:", data.get("framework", "-")),
        ("Has Dockerfile:", str(data.get("has_dockerfile", "-"))),
        ("Detected Port:", str(data.get("detected_port", "-"))),
        ("Suggested CPU:", str(data.get("suggested_cpu", "-"))),
        ("Suggested Memory:", data.get("suggested_memory", "-")),
    ])


@projects.command("update")
@click.argument("project")
@click.option("--display-name", help="New display name.")
@click.option("--description", help="New description.")
@click.option("--branch", help="New default branch.")
@click.pass_context
def projects_update(ctx, project, display_name, description, branch):
    """Update project settings. Accepts a project name or UUID."""
    project_id = api.resolve_project_id(project)
    fields = {}
    if display_name is not None:
        fields["display_name"] = display_name
    if description is not None:
        fields["description"] = description
    if branch is not None:
        fields["repo_branch"] = branch
    if not fields:
        click.secho("No fields to update.", fg="yellow")
        return
    data = api.update_project(project_id, **fields)
    if ctx.obj["json"]:
        print_json(data)
        return
    click.secho(f"Project '{data['name']}' updated.", fg="green")


# ---------------------------------------------------------------------------
# Environments
# ---------------------------------------------------------------------------

@cli.group("envs")
def envs():
    """Manage environments."""


@envs.command("list")
@click.argument("project")
@click.pass_context
def envs_list(ctx, project):
    """List environments for a project."""
    project_id = api.resolve_project_id(project)
    data = api.list_environments(project_id)
    if ctx.obj["json"]:
        print_json(data)
        return

    rows = []
    for e in data:
        rows.append([
            e.get("name", "-"),
            e.get("branch", "-"),
            e.get("domain") or "-",
            "Yes" if e.get("is_production") else "No",
            "Yes" if e.get("auto_deploy") else "No",
            status_color(e.get("status", "-")),
        ])
    print_table("Environments", ["Name", "Branch", "Domain", "Prod", "Auto Deploy", "Status"], rows)


@envs.command("create")
@click.argument("project")
@click.argument("name")
@click.option("--branch", required=True, help="Git branch.")
@click.option("--auto-deploy/--no-auto-deploy", default=True, help="Auto deploy on push.")
@click.pass_context
def envs_create(ctx, project, name, branch, auto_deploy):
    """Create a new environment."""
    project_id = api.resolve_project_id(project)
    data = api.create_environment(project_id, name, branch, auto_deploy=auto_deploy)
    if ctx.obj["json"]:
        print_json(data)
        return
    click.secho(f"Environment '{data['name']}' created.", fg="green")
    print_kv([
        ("ID:", data["id"]),
        ("Domain:", data.get("domain", "-")),
    ])


@envs.command("update")
@click.argument("project")
@click.argument("env_id")
@click.option("--branch", help="New branch.")
@click.option("--auto-deploy/--no-auto-deploy", default=None, help="Auto deploy on push.")
@click.pass_context
def envs_update(ctx, project, env_id, branch, auto_deploy):
    """Update an environment."""
    project_id = api.resolve_project_id(project)
    fields = {}
    if branch is not None:
        fields["branch"] = branch
    if auto_deploy is not None:
        fields["auto_deploy"] = auto_deploy
    if not fields:
        click.secho("No fields to update.", fg="yellow")
        return
    data = api.update_environment(project_id, env_id, **fields)
    if ctx.obj["json"]:
        print_json(data)
        return
    click.secho(f"Environment '{data['name']}' updated.", fg="green")


@envs.command("delete")
@click.argument("project")
@click.argument("env_id")
@click.confirmation_option(prompt="Are you sure you want to delete this environment?")
def envs_delete(project, env_id):
    """Delete an environment."""
    project_id = api.resolve_project_id(project)
    api.delete_environment(project_id, env_id)
    click.secho("Environment deleted.", fg="green")


# ---------------------------------------------------------------------------
# Addons
# ---------------------------------------------------------------------------

@cli.group()
def addons():
    """Manage add-ons (databases, caches)."""


@addons.command("list")
@click.argument("project")
@click.pass_context
def addons_list(ctx, project):
    """List add-ons for a project."""
    project_id = api.resolve_project_id(project)
    data = api.list_addons(project_id)
    if ctx.obj["json"]:
        print_json(data)
        return

    items = data.get("addons", [])
    if not items:
        click.echo("No add-ons found.")
        return

    rows = []
    for a in items:
        rows.append([
            a.get("name", "-"),
            a.get("service_type", "-"),
            a.get("version", "-"),
            status_color(a.get("status", "-")),
            a.get("env_var_name", "-"),
            format_dt(a.get("created_at")),
        ])
    print_table("Add-ons", ["Name", "Type", "Version", "Status", "Env Var", "Created"], rows)


@addons.command("add")
@click.argument("project")
@click.option("--type", "service_type", required=True, type=click.Choice(["postgres", "redis"]),
              help="Service type.")
@click.option("--name", required=True, help="Add-on name (slug).")
@click.option("--version", default=None, help="Service version (e.g. 16, 7).")
@click.option("--env-var", default=None, help="Override env var name (e.g. DATABASE_URL).")
@click.pass_context
def addons_add(ctx, project, service_type, name, version, env_var):
    """Provision a new add-on."""
    project_id = api.resolve_project_id(project)
    data = api.create_addon(project_id, name, service_type, version=version, env_var_name=env_var)
    if ctx.obj["json"]:
        print_json(data)
        return
    click.secho(f"Add-on '{data.get('name')}' ({data.get('service_type')}) provisioned.", fg="green")
    print_kv([
        ("Status:", data.get("status", "-")),
        ("Env Var:", data.get("env_var_name", "-")),
        ("Connection:", data.get("connection_url", "-")),
    ])


@addons.command("delete")
@click.argument("project")
@click.argument("addon_id")
@click.confirmation_option(prompt="This will destroy the add-on and all its data. Continue?")
def addons_delete(project, addon_id):
    """Destroy an add-on and its data."""
    project_id = api.resolve_project_id(project)
    api.delete_addon(project_id, addon_id)
    click.secho("Add-on deleted.", fg="green")


@addons.command("backups")
@click.argument("project")
@click.argument("addon_id")
@click.pass_context
def addons_backups(ctx, project, addon_id):
    """List backups for an add-on."""
    project_id = api.resolve_project_id(project)
    data = api.list_backups(project_id, addon_id)
    if ctx.obj["json"]:
        print_json(data)
        return

    items = data.get("backups", [])
    if not items:
        click.echo("No backups found.")
        return

    rows = []
    for b in items:
        size = b.get("size_bytes", 0)
        size_str = f"{size / 1024:.1f} KB" if size < 1048576 else f"{size / 1048576:.1f} MB"
        rows.append([
            b["id"][:8],
            status_color(b.get("status", "-")),
            b.get("trigger", "-"),
            size_str if size > 0 else "-",
            format_dt(b.get("created_at")),
        ])
    print_table("Backups", ["ID", "Status", "Trigger", "Size", "Created"], rows)


@addons.command("backup")
@click.argument("project")
@click.argument("addon_id")
@click.pass_context
def addons_backup(ctx, project, addon_id):
    """Trigger a manual backup."""
    project_id = api.resolve_project_id(project)
    data = api.create_backup(project_id, addon_id)
    if ctx.obj["json"]:
        print_json(data)
        return
    click.secho(f"Backup started for {data.get('addon', 'addon')}.", fg="green")


@addons.command("download")
@click.argument("project")
@click.argument("addon_id")
@click.argument("backup_id")
def addons_download(project, addon_id, backup_id):
    """Get a download URL for a backup."""
    project_id = api.resolve_project_id(project)
    data = api.download_backup(project_id, addon_id, backup_id)
    click.echo(data.get("url", ""))


@addons.command("delete-backup")
@click.argument("project")
@click.argument("addon_id")
@click.argument("backup_id")
@click.confirmation_option(prompt="Are you sure you want to delete this backup?")
def addons_delete_backup(project, addon_id, backup_id):
    """Delete a backup."""
    project_id = api.resolve_project_id(project)
    api.delete_backup(project_id, addon_id, backup_id)
    click.secho("Backup deleted.", fg="green")


# ---------------------------------------------------------------------------
# Deploy (shortcut)
# ---------------------------------------------------------------------------

@cli.command()
@click.argument("project")
@click.option("--env", "environment_id", help="Environment ID (defaults to production).")
@click.pass_context
def deploy(ctx, project, environment_id):
    """Trigger a deployment."""
    project_id = api.resolve_project_id(project)
    data = api.trigger_deployment(project_id, environment_id)
    if ctx.obj["json"]:
        print_json(data)
        return
    click.secho("Deployment triggered.", fg="green")
    print_kv([
        ("Deployment ID:", data["id"]),
        ("Status:", data.get("status", "-")),
    ])
    click.echo(f"\nTrack progress: orkestr deployments show {data['id']}")


# ---------------------------------------------------------------------------
# Deployments
# ---------------------------------------------------------------------------

@cli.group()
def deployments():
    """Manage deployments."""


@deployments.command("list")
@click.argument("project")
@click.option("--limit", default=20, help="Max results.")
@click.pass_context
def deployments_list(ctx, project, limit):
    """List deployments for a project."""
    project_id = api.resolve_project_id(project)
    data = api.list_deployments(project_id, limit=limit)
    if ctx.obj["json"]:
        print_json(data)
        return

    rows = []
    for d in data.get("deployments", []):
        rows.append([
            d["id"][:8],
            status_color(d.get("status", "-")),
            d.get("trigger", "-"),
            truncate(d.get("commit_sha") or "-", 8),
            format_dt(d.get("created_at")),
        ])
    print_table("Deployments", ["ID", "Status", "Trigger", "Commit", "Created"], rows)
    click.echo(f"\nTotal: {data.get('total', len(rows))}")


@deployments.command("show")
@click.argument("deployment_id")
@click.pass_context
def deployments_show(ctx, deployment_id):
    """Show deployment details."""
    data = api.get_deployment(deployment_id)
    if ctx.obj["json"]:
        print_json(data)
        return
    print_kv([
        ("ID:", data["id"]),
        ("Status:", data.get("status", "-")),
        ("Trigger:", data.get("trigger", "-")),
        ("Commit:", data.get("commit_sha") or "-"),
        ("Image:", data.get("docker_image") or "-"),
        ("Created:", format_dt(data.get("created_at"))),
        ("Finished:", format_dt(data.get("finished_at"))),
    ])

    steps = data.get("steps", [])
    if steps:
        click.echo("\nPipeline Steps:")
        for s in steps:
            icon = {"completed": "[green]OK[/]", "failed": "[red]FAIL[/]", "running": "[yellow]...[/]"}.get(s.get("status"), "  ")
            console.print(f"  {icon}  {s.get('step_name', '-')}")


@deployments.command("logs")
@click.argument("deployment_id")
@click.pass_context
def deployments_logs(ctx, deployment_id):
    """Show deployment pipeline logs."""
    data = api.get_deployment_logs(deployment_id)
    if ctx.obj["json"]:
        print_json(data)
        return

    current_step = None
    for entry in data.get("logs", []):
        step = entry.get("step", "")
        if step != current_step:
            current_step = step
            click.secho(f"\n--- {step} ---", fg="cyan", bold=True)
        click.echo(entry.get("message", ""))


@deployments.command("rollback")
@click.argument("deployment_id")
@click.confirmation_option(prompt="Are you sure you want to rollback to this deployment?")
@click.pass_context
def deployments_rollback(ctx, deployment_id):
    """Rollback to a previous deployment's image."""
    data = api.rollback_deployment(deployment_id)
    if ctx.obj["json"]:
        print_json(data)
        return
    click.secho("Rollback deployment triggered.", fg="green")
    print_kv([
        ("Deployment ID:", data["id"]),
        ("Status:", data.get("status", "-")),
    ])


# ---------------------------------------------------------------------------
# Monitoring shortcuts
# ---------------------------------------------------------------------------

@cli.command()
@click.argument("project")
@click.option("--env", "environment_id", help="Environment ID.")
@click.option("--lines", default=200, help="Number of log lines.")
@click.pass_context
def logs(ctx, project, environment_id, lines):
    """Show application runtime logs."""
    project_id = api.resolve_project_id(project)
    data = api.get_logs(project_id, environment_id, lines)
    if ctx.obj["json"]:
        print_json(data)
        return

    click.secho(f"Container: {data.get('container', '-')}", fg="cyan")
    click.echo()
    for line in data.get("logs", "").strip().split("\n"):
        click.echo(line)


@cli.command()
@click.argument("project")
@click.option("--env", "environment_id", help="Environment ID.")
@click.pass_context
def stats(ctx, project, environment_id):
    """Show container resource stats."""
    project_id = api.resolve_project_id(project)
    data = api.get_stats(project_id, environment_id)
    if ctx.obj["json"]:
        print_json(data)
        return

    print_kv([
        ("CPU %:", str(data.get("cpu_percent", "-"))),
        ("Memory:", f"{data.get('memory_usage', '-')} / {data.get('memory_limit', '-')}"),
        ("Memory %:", str(data.get("memory_percent", "-"))),
        ("Net I/O:", f"{data.get('network_rx', '-')} / {data.get('network_tx', '-')}"),
    ])


@cli.command()
@click.argument("project")
@click.option("--env", "environment_id", help="Environment ID.")
@click.pass_context
def health(ctx, project, environment_id):
    """Show container health info."""
    project_id = api.resolve_project_id(project)
    data = api.get_health(project_id, environment_id)
    if ctx.obj["json"]:
        print_json(data)
        return

    print_kv([
        ("Status:", data.get("status", "-")),
        ("Uptime:", data.get("uptime", "-")),
        ("Restarts:", str(data.get("restart_count", "-"))),
        ("Image:", data.get("image", "-")),
        ("Started:", data.get("started_at", "-")),
    ])


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    cli()
