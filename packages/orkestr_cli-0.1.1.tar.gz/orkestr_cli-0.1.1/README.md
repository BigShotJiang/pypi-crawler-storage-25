# orkestr-cli

CLI for the [Orkestr](https://orkestr.eu) Internal Developer Platform.

## Install

```bash
pip install orkestr-cli
```

## Quick start

```bash
# Authenticate with your API token
orkestr login

# List your projects
orkestr projects list

# Deploy
orkestr deploy my-api

# View logs
orkestr logs my-api

# Check health
orkestr health my-api
```

## Commands

| Command | Description |
|---|---|
| `orkestr login` | Authenticate with an API token |
| `orkestr logout` | Clear stored credentials |
| `orkestr whoami` | Show current user info |
| `orkestr projects list\|create\|show\|update\|delete\|analyze` | Manage projects |
| `orkestr envs list\|create\|update\|delete` | Manage environments |
| `orkestr deploy <project>` | Trigger a deployment |
| `orkestr deployments list\|show\|logs\|rollback` | Deployment history |
| `orkestr logs <project>` | Runtime container logs |
| `orkestr stats <project>` | CPU/memory/network stats |
| `orkestr health <project>` | Container health info |

All commands support `--json` for raw JSON output.

## Publishing to PyPI

1. Bump the version in `pyproject.toml`
2. Build and upload:

```bash
cd cli
pip install build twine

# Build the package
python -m build

# Upload to PyPI (username is literally __token__)
twine upload dist/*
# Username: __token__
# Password: your PyPI API token
```

3. Verify:

```bash
pip install --upgrade orkestr-cli
orkestr --version
```

PyPI project page: [pypi.org/project/orkestr-cli](https://pypi.org/project/orkestr-cli/)

## Documentation

Full docs at [orkestr.eu/docs](https://orkestr.eu/docs)
