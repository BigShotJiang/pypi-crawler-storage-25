"""Tellr application package."""

