"""Google Slides export endpoints.

Provides user-scoped OAuth2 authorization flow and presentation creation
using the V3 LLM code-gen approach.

Credentials come from the global ``GoogleGlobalCredentials`` table;
user tokens are stored per-user in the ``google_oauth_tokens`` table.
"""

import json
import logging
import os
from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session

from src.api.services.chat_service import get_chat_service
from src.api.routes.export import ExportJobResponse
from src.core.database import get_db
from src.services.drive_uploader import replace_presentation, upload_pptx_as_slides
from src.services.google_slides_auth import GoogleSlidesAuth, GoogleSlidesAuthError
from src.services.pptx_from_records import EmitError, build_pptx

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/export/google-slides", tags=["google-slides"])


# -------------------------------------------------------------------------
# Helpers
# -------------------------------------------------------------------------


def _get_user_identity() -> str:
    """Return the current user's identity string.

    In production (Databricks Apps) this is the authenticated user's email.
    In local dev it falls back to ``"local_dev"``.
    """
    if os.getenv("ENVIRONMENT") in ("development", "test"):
        return "local_dev"
    try:
        from src.core.databricks_client import get_user_client
        client = get_user_client()
        return client.current_user.me().user_name or "local_dev"
    except Exception:
        return "local_dev"


def _get_auth(db: Session) -> GoogleSlidesAuth:
    """Build a DB-backed ``GoogleSlidesAuth`` for the current user."""
    user_identity = _get_user_identity()
    return GoogleSlidesAuth.from_global(user_identity, db)


# -------------------------------------------------------------------------
# Request / Response schemas
# -------------------------------------------------------------------------


class ChartImage(BaseModel):
    """Chart image data from client-side capture."""
    canvas_id: str
    base64_data: str


class ExportGoogleSlidesRequest(BaseModel):
    """Request to export slides to Google Slides."""
    session_id: str
    chart_images: Optional[list[list[ChartImage]]] = None


class AuthStatusResponse(BaseModel):
    authorized: bool


class AuthUrlResponse(BaseModel):
    url: str




# -------------------------------------------------------------------------
# OAuth2 auth endpoints
# -------------------------------------------------------------------------


def _build_redirect_uri(request: Request) -> str:
    """Build the OAuth callback redirect URI from the current request.

    Google requires redirect URIs to match *exactly* what's registered in GCP,
    with no query parameters.

    Behind a reverse proxy (e.g. Databricks Apps), ``request.base_url``
    returns the internal address (``http://localhost:8000``).  We use the
    ``X-Forwarded-Host`` / ``X-Forwarded-Proto`` headers set by the proxy
    to reconstruct the public URL instead.

    For localhost, Google only allows ``http``.
    """
    forwarded_host = request.headers.get("x-forwarded-host")
    forwarded_proto = request.headers.get("x-forwarded-proto")

    if forwarded_host:
        scheme = forwarded_proto or "https"
        base = f"{scheme}://{forwarded_host.split(',')[0].strip()}"
    else:
        base = str(request.base_url).rstrip("/")
        # Force http for localhost (Google rejects https://localhost)
        if "://localhost" in base or "://127.0.0.1" in base:
            base = base.replace("https://", "http://")

    return f"{base}/api/export/google-slides/auth/callback"


@router.get("/auth/status", response_model=AuthStatusResponse)
async def auth_status(db: Session = Depends(get_db)):
    """Check whether the current user has a valid Google OAuth token."""
    try:
        auth = _get_auth(db)
        return AuthStatusResponse(authorized=auth.is_authorized())
    except (GoogleSlidesAuthError, Exception) as exc:
        # No credentials, bad encryption key, or any other issue → not authorized
        logger.debug("auth_status check failed: %s", exc)
        return AuthStatusResponse(authorized=False)


@router.get("/auth/url", response_model=AuthUrlResponse)
async def auth_url(
    request: Request,
    db: Session = Depends(get_db),
):
    """Generate the Google OAuth consent URL.

    The frontend should open this URL in a popup window.  User identity is
    passed via the OAuth ``state`` parameter so the callback can persist the
    token for the correct user — the redirect URI itself stays clean
    (no query params) to satisfy Google's exact-match requirement.
    """
    try:
        auth = _get_auth(db)
        redirect_uri = _build_redirect_uri(request)
        state = json.dumps({"user": _get_user_identity()})
        url = auth.get_auth_url(redirect_uri=redirect_uri, state=state)

        return AuthUrlResponse(url=url)
    except GoogleSlidesAuthError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        logger.error("Failed to generate auth URL: %s", exc)
        raise HTTPException(
            status_code=500,
            detail="Failed to generate authorization URL. Credentials may be corrupt — try re-uploading.",
        ) from exc


@router.get("/auth/callback", response_class=HTMLResponse)
async def auth_callback(
    request: Request,
    code: str,
    state: str = Query("", description="OAuth state carrying user identity"),
    db: Session = Depends(get_db),
):
    """Handle the OAuth callback from Google.

    User identity is extracted from the ``state`` parameter that was set
    during the consent URL generation.  The redirect URI used here must
    match exactly what was registered in GCP (no query params).

    Exchanges the authorization code for tokens, encrypts them, and stores
    them in the ``google_oauth_tokens`` table.  Returns a small HTML page
    that notifies the opener window and closes itself.
    """
    try:
        state_data = json.loads(state) if state else {}
        user = state_data.get("user")
        if not user:
            raise ValueError("Missing user in OAuth state")

        auth = _get_auth(db)
        redirect_uri = _build_redirect_uri(request)
        code_verifier = state_data.get("code_verifier")
        auth.authorize(code=code, redirect_uri=redirect_uri, code_verifier=code_verifier)
        logger.info(
            "Google Slides OAuth callback successful",
            extra={"user": _get_user_identity()},
        )
    except Exception as exc:
        logger.error("OAuth callback failed", exc_info=True)
        return HTMLResponse(
            content=f"""
            <html><body>
                <h2>Authorization Failed</h2>
                <p>{exc}</p>
                <script>
                    if (window.opener) {{
                        window.opener.postMessage({{ type: 'google-slides-auth', success: false }}, '*');
                    }}
                    setTimeout(() => window.close(), 3000);
                </script>
            </body></html>
            """,
            status_code=200,
        )

    return HTMLResponse(
        content="""
        <html><body>
            <h2>Authorization Successful</h2>
            <p>You can close this window.</p>
            <script>
                if (window.opener) {
                    window.opener.postMessage({ type: 'google-slides-auth', success: true }, '*');
                }
                setTimeout(() => window.close(), 1500);
            </script>
        </body></html>
        """,
        status_code=200,
    )


# -------------------------------------------------------------------------
# Export endpoint
# -------------------------------------------------------------------------


def _build_slide_html(slide: dict, slide_deck: dict) -> str:
    """Build complete HTML for a slide."""
    from src.api.routes.export import build_slide_html
    return build_slide_html(slide, slide_deck)


@router.post("", response_model=ExportJobResponse)
async def start_google_slides_export(
    request_body: ExportGoogleSlidesRequest,
    db: Session = Depends(get_db),
):
    """Start an async Google Slides export job.

    Returns immediately with a job_id.  The frontend polls
    ``GET .../poll/{job_id}`` for progress until completion.

    Flow:
    1. Validate auth, fetch slides, build HTML (fast).
    2. Enqueue background job for the slow LLM conversion.
    3. Return job_id so the frontend can poll.
    """
    from src.api.services.export_job_queue import (
        enqueue_export_job,
        generate_job_id,
    )

    try:
        auth = _get_auth(db)
    except GoogleSlidesAuthError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    if not auth.is_authorized():
        raise HTTPException(
            status_code=401,
            detail="Not authorized with Google. Complete the OAuth flow first.",
        )

    # Fetch slide deck
    try:
        chat_service = get_chat_service()
        slide_deck = chat_service.get_slides(request_body.session_id)
    except Exception as exc:
        logger.error("Failed to fetch slides", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to fetch slides: {exc}") from exc

    if not slide_deck or not slide_deck.get("slides"):
        raise HTTPException(status_code=404, detail="No slides available")

    # Substitute {{image:ID}} placeholders with base64 data URIs
    from src.utils.image_utils import substitute_deck_dict_images
    from src.core.database import get_db_session
    with get_db_session() as db:
        substitute_deck_dict_images(slide_deck, db)

    slides_data = slide_deck.get("slides", [])
    total = len(slides_data)
    title = slide_deck.get("title", "Presentation")

    # Build complete HTML for each slide (fast — no LLM calls)
    slides_html: list[str] = []
    for slide in slides_data:
        slides_html.append(_build_slide_html(slide, slide_deck))

    # Prepare chart images
    chart_images_per_slide: Optional[list[dict[str, str]]] = None
    if request_body.chart_images:
        chart_images_per_slide = [
            {img.canvas_id: img.base64_data for img in slide_charts}
            for slide_charts in request_body.chart_images
        ]

    # Check for existing presentation on this session (re-export overwrites)
    from src.api.services.session_manager import get_session_manager
    session_manager = get_session_manager()
    existing_info = session_manager.get_google_slides_info(request_body.session_id)
    existing_presentation_id = existing_info["presentation_id"] if existing_info else None

    # Enqueue background job
    job_id = generate_job_id()
    payload = {
        "session_id": request_body.session_id,
        "user_identity": _get_user_identity(),
        "slides_html": slides_html,
        "title": title,
        "total_slides": total,
        "chart_images_per_slide": chart_images_per_slide,
        "job_type": "google_slides",
        "existing_presentation_id": existing_presentation_id,
    }
    await enqueue_export_job(job_id, payload)

    logger.info(
        "Google Slides export job enqueued",
        extra={"job_id": job_id, "session_id": request_body.session_id, "total_slides": total},
    )

    return ExportJobResponse(
        job_id=job_id,
        status="pending",
        total_slides=total,
    )


@router.get("/poll/{job_id}", response_model=ExportJobResponse)
async def poll_google_slides_export(job_id: str):
    """Poll for Google Slides export status and progress.

    When ``status`` is ``completed``, the response includes
    ``presentation_id`` and ``presentation_url``.
    """
    from src.api.services.export_job_queue import build_export_job_response

    try:
        return ExportJobResponse(**build_export_job_response(job_id))
    except ValueError:
        raise HTTPException(status_code=404, detail="Export job not found")


# -------------------------------------------------------------------------
# Records-based export — PPTX → Drive auto-convert to Slides
# -------------------------------------------------------------------------


class GoogleSlidesFromRecordsRequest(BaseModel):
    """Records-based Google Slides export request.

    Mirrors the editable-PPTX ``/from-records`` route shape so the
    frontend can reuse ``extractSlideRecordsForExport``.
    """
    session_id: str
    title: str
    slides: list[dict[str, Any]]
    font_mode: str = "google_slides"


class GoogleSlidesExportResponse(BaseModel):
    presentation_id: str
    presentation_url: str


@router.post("/from-records", response_model=GoogleSlidesExportResponse)
async def export_google_slides_from_records(
    request: GoogleSlidesFromRecordsRequest,
    db: Session = Depends(get_db),
):
    """Build a PPTX from DOM-walker records and upload to Drive.

    Drive's ``files.create`` with ``mimeType=application/vnd.google-apps.
    presentation`` triggers automatic conversion to a native Google
    Slides deck — no per-element Slides API calls needed.

    Re-exports on the same session overwrite the previous presentation.
    """
    try:
        auth = _get_auth(db)
    except GoogleSlidesAuthError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    if not auth.is_authorized():
        raise HTTPException(
            status_code=401,
            detail="Not authorized with Google. Complete the OAuth flow first.",
        )

    try:
        pptx_bytes = build_pptx(
            title=request.title,
            slides=request.slides,
            font_mode=request.font_mode,
        )
    except EmitError as exc:
        logger.error("PPTX build failed for Google Slides export", exc_info=True)
        raise HTTPException(status_code=500, detail=f"PPTX build failed: {exc}") from exc

    from src.api.services.session_manager import get_session_manager
    session_manager = get_session_manager()
    existing_info = session_manager.get_google_slides_info(request.session_id)
    existing_id = existing_info["presentation_id"] if existing_info else None

    try:
        if existing_id:
            presentation_id, url = replace_presentation(
                auth, existing_id, pptx_bytes, request.title,
            )
        else:
            presentation_id, url = upload_pptx_as_slides(
                auth, pptx_bytes, request.title,
            )
    except Exception as exc:
        logger.error("Drive upload failed", exc_info=True)
        raise HTTPException(status_code=502, detail=f"Drive upload failed: {exc}") from exc

    session_manager.set_google_slides_info(
        session_id=request.session_id,
        presentation_id=presentation_id,
        presentation_url=url,
    )

    logger.info(
        "Google Slides export complete",
        extra={
            "session_id": request.session_id,
            "presentation_id": presentation_id,
            "replaced": bool(existing_id),
        },
    )

    return GoogleSlidesExportResponse(
        presentation_id=presentation_id,
        presentation_url=url,
    )


# -------------------------------------------------------------------------
# Huashu-based export — server-side Chromium → PPTX → Drive auto-convert
# -------------------------------------------------------------------------


class GoogleSlidesFromHuashuRequest(BaseModel):
    """Huashu-based Google Slides export request.

    No client-side records needed — the backend fetches the deck from
    session storage and builds complete HTML server-side.
    """
    session_id: str


@router.post("/from-huashu", response_model=GoogleSlidesExportResponse)
async def export_google_slides_from_huashu(
    request: GoogleSlidesFromHuashuRequest,
    db: Session = Depends(get_db),
):
    """Build a PPTX via the huashu (Playwright + Chromium) pipeline and
    upload to Drive.

    Trade-offs vs. ``/from-records``:
      * Higher fidelity — server-side Chromium re-renders the actual deck
        HTML and walks the rendered DOM, getting exact positions/fonts/
        colors instead of relying on the client-side walker's records.
      * Slower — ~20-30s for a 10-slide deck because Chromium spawns per
        slide. Acceptable for a one-shot Drive upload.
      * ``bypass_validation=True`` is set so every slide makes it into the
        output PPTX even if it violates huashu's design rules. Without
        this, failing slides would be silently dropped from the deck on
        Drive (e.g. slide 7 missing, numbering shifted) — terrible UX.

    Re-exports on the same session overwrite the previous presentation
    (same as ``/from-records``).
    """
    from src.services.pptx_from_html_huashu import (
        HuashuExportError,
        build_pptx_huashu,
    )

    try:
        auth = _get_auth(db)
    except GoogleSlidesAuthError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    if not auth.is_authorized():
        raise HTTPException(
            status_code=401,
            detail="Not authorized with Google. Complete the OAuth flow first.",
        )

    chat_service = get_chat_service()
    slide_deck = chat_service.get_slides(request.session_id)
    if not slide_deck or not slide_deck.get("slides"):
        raise HTTPException(status_code=404, detail="No slides available")

    # Substitute {{image:ID}} placeholders with base64 data URIs (same as the
    # legacy /export route). Use a fresh session because the request's `db`
    # is held by the route's transaction context.
    from src.core.database import get_db_session
    from src.utils.image_utils import substitute_deck_dict_images
    with get_db_session() as imdb:
        substitute_deck_dict_images(slide_deck, imdb)

    title = slide_deck.get("title") or "Presentation"
    slides_data = slide_deck.get("slides") or []

    slides_html = [
        {
            "html": _build_slide_html(slide, slide_deck),
            "notes": slide.get("notes") or "",
        }
        for slide in slides_data
    ]

    try:
        pptx_bytes, failures = build_pptx_huashu(
            title=title,
            slides_html=slides_html,
            bypass_validation=True,
        )
    except HuashuExportError as exc:
        logger.error("Huashu pipeline error for Google Slides export", exc_info=True)
        raise HTTPException(
            status_code=503,
            detail=f"Huashu pipeline unavailable: {exc}",
        ) from exc

    if not pptx_bytes:
        # With bypass_validation=True the only way this happens is if every
        # slide hit a non-validation error (e.g. chromium failed to launch
        # for all of them). Surface the failures so the user can debug.
        logger.error(
            "Huashu produced no output even with bypass; failures=%s", failures
        )
        raise HTTPException(
            status_code=500,
            detail=f"Huashu produced no output. failures={failures}",
        )

    from src.api.services.session_manager import get_session_manager
    session_manager = get_session_manager()
    existing_info = session_manager.get_google_slides_info(request.session_id)
    existing_id = existing_info["presentation_id"] if existing_info else None

    try:
        if existing_id:
            presentation_id, url = replace_presentation(
                auth, existing_id, pptx_bytes, title,
            )
        else:
            presentation_id, url = upload_pptx_as_slides(
                auth, pptx_bytes, title,
            )
    except Exception as exc:
        logger.error("Drive upload failed (huashu path)", exc_info=True)
        raise HTTPException(
            status_code=502,
            detail=f"Drive upload failed: {exc}",
        ) from exc

    session_manager.set_google_slides_info(
        session_id=request.session_id,
        presentation_id=presentation_id,
        presentation_url=url,
    )

    logger.info(
        "Google Slides huashu export complete",
        extra={
            "session_id": request.session_id,
            "presentation_id": presentation_id,
            "replaced": bool(existing_id),
            "huashu_failures": len(failures),
        },
    )

    return GoogleSlidesExportResponse(
        presentation_id=presentation_id,
        presentation_url=url,
    )
