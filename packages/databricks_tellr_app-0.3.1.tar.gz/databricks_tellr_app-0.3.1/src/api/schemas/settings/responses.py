"""Response schemas for configuration API."""
from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, ConfigDict


class ProfileSummary(BaseModel):
    """Summary view of a profile."""

    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    description: Optional[str]
    is_default: bool
    global_permission: Optional[str] = None
    created_at: datetime
    created_by: Optional[str]
    updated_at: datetime
    updated_by: Optional[str]
    my_permission: Optional[str] = None
    is_my_default: bool = False


class GenieSpace(BaseModel):
    """
    Genie space configuration.
    
    Each profile has exactly one Genie space.
    """

    model_config = ConfigDict(from_attributes=True)

    id: int
    profile_id: int
    space_id: str
    space_name: str
    description: Optional[str]
    created_at: datetime
    updated_at: datetime


class PromptsConfig(BaseModel):
    """Prompts configuration."""

    model_config = ConfigDict(from_attributes=True)

    id: int
    profile_id: int
    selected_deck_prompt_id: Optional[int] = None
    selected_slide_style_id: Optional[int] = None
    system_prompt: str
    slide_editing_instructions: str
    created_at: datetime
    updated_at: datetime


class ProfileDetail(BaseModel):
    """Detailed view of a profile with all configurations."""

    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    description: Optional[str]
    is_default: bool
    global_permission: Optional[str] = None
    created_at: datetime
    created_by: Optional[str]
    updated_at: datetime
    updated_by: Optional[str]
    genie_spaces: List[GenieSpace]
    prompts: PromptsConfig
    my_permission: Optional[str] = None
    is_my_default: bool = False


class ErrorResponse(BaseModel):
    """Standard error response."""

    detail: str
    error_type: Optional[str] = None


class ValidationErrorDetail(BaseModel):
    """Validation error detail."""

    loc: List[str]
    msg: str
    type: str


class ValidationErrorResponse(BaseModel):
    """Validation error response."""

    detail: List[ValidationErrorDetail]

