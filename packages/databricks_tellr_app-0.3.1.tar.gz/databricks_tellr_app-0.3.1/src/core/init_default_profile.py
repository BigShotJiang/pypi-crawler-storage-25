"""
Initialize database with default profile from YAML configuration.

This script creates a default configuration profile in the database using
values from the YAML configuration files. Run this once after database setup.
"""

import logging
import os
import sys
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root))

from src.core.database import get_db_session
from src.core.defaults import DEFAULT_CONFIG, DEFAULT_SLIDE_STYLE
from src.core.config_loader import load_config
from src.database.models import (
    ConfigGenieSpace,
    ConfigProfile,
    ConfigPrompts,
    SlideDeckPromptLibrary,
    SlideStyleLibrary,
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# Generic deck prompt templates (always deployed)
GENERIC_DECK_PROMPTS = [
    {
        "name": "Quarterly Business Review",
        "description": "Template for QBR presentations. Covers performance metrics, achievements, challenges, and strategic recommendations.",
        "category": "Report",
        "prompt_content": """PRESENTATION TYPE: Quarterly Business Review (QBR)

When creating a QBR presentation, structure it as follows:

1. QUARTER OVERVIEW
   - Executive summary of the quarter
   - Key performance indicators vs. targets
   - Major achievements and milestones

2. METRICS DEEP DIVE
   - Query for all relevant metrics for the quarter
   - Compare to previous quarter and same quarter last year
   - Use charts to visualize performance trends

3. SUCCESS STORIES
   - Highlight specific wins with data
   - Quantify impact where possible
   - Include growth or improvement percentages

4. CHALLENGES & LEARNINGS
   - Acknowledge areas that didn't meet expectations
   - Provide context with supporting data
   - Share lessons learned

5. NEXT QUARTER OUTLOOK
   - Goals and targets for upcoming quarter
   - Strategic initiatives planned
   - Resource requirements or asks

Use a professional, data-driven approach with clear visualizations for each section.""",
    },
    {
        "name": "Executive Summary",
        "description": "High-level overview format for executive audiences. Focuses on key metrics and strategic insights.",
        "category": "Summary",
        "prompt_content": """PRESENTATION TYPE: Executive Summary

When creating an executive summary presentation:

DESIGN PRINCIPLES:
- Keep it concise - executives have limited time
- Lead with insights, not data
- Use clear, impactful titles that state the takeaway
- Maximum 5-7 slides total

STRUCTURE:
1. HEADLINE SLIDE
   - Single most important insight or conclusion
   - One key metric that supports it

2. SITUATION OVERVIEW
   - Brief context (2-3 bullets max)
   - Current state summary

3. KEY FINDINGS (2-3 slides max)
   - One major insight per slide
   - Support each with 1-2 data points
   - Use simple charts (bar or line)

4. RECOMMENDATIONS
   - Clear, actionable next steps
   - Prioritized list (max 3 items)

5. ASK (if applicable)
   - What decision or action is needed
   - Required resources or support

Keep language simple and avoid jargon. Every data point should support a decision.""",
    },
]

# Databricks-specific deck prompt templates (only deployed with --include-databricks-prompts)
DATABRICKS_DECK_PROMPTS = [
    {
        "name": "Consumption Review",
        "description": "Template for consumption review meetings. Analyzes usage trends, identifies key drivers, and highlights areas for optimization.",
        "category": "Review",
        "prompt_content": """PRESENTATION TYPE: Consumption Review

When creating a consumption review presentation, focus on:

1. EXECUTIVE SUMMARY
   - Overall consumption trend (increasing/decreasing/stable)
   - Key highlight metrics (total spend, month-over-month change)
   - Top 3 insights that require attention

2. USAGE ANALYSIS
   - Query for consumption data over the past 6-12 months
   - Break down by major categories (compute, storage, etc.)
   - Identify the top consumers and their growth patterns

3. TREND IDENTIFICATION
   - Look for seasonal patterns or anomalies
   - Compare current period to previous periods
   - Highlight significant changes (>10% movement)

4. OPTIMIZATION OPPORTUNITIES
   - Identify underutilized resources
   - Highlight cost-saving opportunities
   - Recommend actions based on data

5. FORWARD OUTLOOK
   - Project future consumption based on trends
   - Flag any concerns or risks
   - Provide actionable recommendations

Structure the deck with clear data visualizations showing trends over time.""",
    },
    {
        "name": "Use Case Analysis",
        "description": "Template for analyzing use case progression and identifying blockers or accelerators.",
        "category": "Analysis",
        "prompt_content": """PRESENTATION TYPE: Use Case Analysis

When analyzing use cases, focus on:

1. PORTFOLIO OVERVIEW
   - Total number of use cases in scope
   - Distribution by stage/status
   - Overall health metrics

2. PROGRESSION ANALYSIS
   - Query for use case movement between stages
   - Identify velocity patterns
   - Calculate average time in each stage

3. BLOCKER IDENTIFICATION
   - Find use cases that are stuck or slowed
   - Categorize blockers (technical, resource, dependency)
   - Quantify impact of each blocker type

4. SUCCESS PATTERNS
   - Identify fast-moving use cases
   - Find common characteristics of successful progression
   - Extract best practices

5. RECOMMENDATIONS
   - Specific actions to unblock stuck use cases
   - Resource allocation suggestions
   - Process improvements

Use funnel charts for progression and bar charts for blocker analysis.""",
    },
]

# Combined list for backward compatibility (used by local dev scripts)
DEFAULT_DECK_PROMPTS = GENERIC_DECK_PROMPTS + DATABRICKS_DECK_PROMPTS


def _seed_deck_prompts(db, include_databricks: bool = False) -> None:
    """Seed the deck prompt library with default templates.
    
    Args:
        db: Database session
        include_databricks: If True, also seed Databricks-specific prompts
    """
    existing_count = db.query(SlideDeckPromptLibrary).count()
    if existing_count > 0:
        logger.info(f"Deck prompt library already has {existing_count} prompts, skipping seed")
        return

    # Always seed generic prompts
    prompts_to_seed = list(GENERIC_DECK_PROMPTS)
    
    # Optionally add Databricks-specific prompts
    if include_databricks:
        prompts_to_seed.extend(DATABRICKS_DECK_PROMPTS)

    for prompt_data in prompts_to_seed:
        prompt = SlideDeckPromptLibrary(
            name=prompt_data["name"],
            description=prompt_data["description"],
            category=prompt_data["category"],
            prompt_content=prompt_data["prompt_content"],
            is_active=True,
            created_by="system",
            updated_by="system",
        )
        db.add(prompt)
        logger.info(f"Created deck prompt: {prompt_data['name']}")

    logger.info(f"Seeded {len(prompts_to_seed)} deck prompts")
    print(f"  ✓ Seeded {len(prompts_to_seed)} deck prompts in library")


# System slide styles (always deployed)
SYSTEM_SLIDE_STYLES = [
    {
        "name": "System Default",
        "description": "Protected system style. Use this as a template when creating your own custom styles.",
        "category": "System",
        "style_content": DEFAULT_SLIDE_STYLE,
        "is_system": True,  # Cannot be edited or deleted
        "is_default": True,
    },
]

# Databricks-specific slide styles (only deployed with --include-databricks-prompts)
DATABRICKS_SLIDE_STYLES = [
    {
        "name": "Databricks Brand",
        "description": "Official Databricks brand colors and typography. Navy headers, Lava red accents, clean modern layout.",
        "category": "Brand",
        "style_content": DEFAULT_SLIDE_STYLE,
        "is_system": False,  # User-editable
    },
]

# Combined list for backward compatibility (used by local dev scripts)
DEFAULT_SLIDE_STYLES = SYSTEM_SLIDE_STYLES + DATABRICKS_SLIDE_STYLES


def _seed_slide_styles(db, include_databricks: bool = False) -> int | None:
    """Seed the slide style library with default styles.
    
    Args:
        db: Database session
        include_databricks: If True, also seed Databricks-specific styles
    
    Returns:
        ID of the default style if created, None otherwise.
        Prefers Databricks Brand if include_databricks=True, else System Default.
    """
    existing_count = db.query(SlideStyleLibrary).count()
    if existing_count > 0:
        logger.info(f"Slide style library already has {existing_count} styles, skipping seed")
        # Return the ID of preferred default style if it exists
        if include_databricks:
            default_style = db.query(SlideStyleLibrary).filter_by(name="Databricks Brand").first()
        else:
            default_style = db.query(SlideStyleLibrary).filter_by(name="System Default").first()
        return default_style.id if default_style else None

    # Always seed system styles
    styles_to_seed = list(SYSTEM_SLIDE_STYLES)
    
    # Optionally add Databricks-specific styles
    if include_databricks:
        styles_to_seed.extend(DATABRICKS_SLIDE_STYLES)

    default_style_id = None
    for style_data in styles_to_seed:
        style = SlideStyleLibrary(
            name=style_data["name"],
            description=style_data["description"],
            category=style_data["category"],
            style_content=style_data["style_content"],
            is_active=True,
            is_system=style_data.get("is_system", False),
            is_default=style_data.get("is_default", False),
            created_by="system",
            updated_by="system",
        )
        db.add(style)
        db.flush()  # Get the ID
        logger.info(f"Created slide style: {style_data['name']} (is_system={style.is_system})")
        
        # Track the default style ID
        # Prefer Databricks Brand if available, else use System Default
        if include_databricks and style_data["name"] == "Databricks Brand":
            default_style_id = style.id
        elif not include_databricks and style_data["name"] == "System Default":
            default_style_id = style.id

    logger.info(f"Seeded {len(styles_to_seed)} slide styles")
    print(f"  ✓ Seeded {len(styles_to_seed)} slide styles in library")
    return default_style_id


def seed_defaults(include_databricks: bool = False) -> None:
    """Seed default deck prompts and slide styles into the database.
    
    This function is called by init_database() in run.py to populate the
    library tables with default content. It's safe to call multiple times -
    seeding is skipped if content already exists.
    
    Args:
        include_databricks: If True, also seed Databricks-specific content
                           (DATABRICKS_DECK_PROMPTS, DATABRICKS_SLIDE_STYLES).
                           If False, only seed generic content.
    """
    logger.info(f"Seeding defaults (include_databricks={include_databricks})")
    
    try:
        with get_db_session() as db:
            # Seed deck prompt library
            _seed_deck_prompts(db, include_databricks=include_databricks)
            
            # Seed slide style library
            _seed_slide_styles(db, include_databricks=include_databricks)
            
            db.commit()
            
        logger.info("Default seeding completed successfully")
        
    except Exception as e:
        logger.error(f"Failed to seed defaults: {e}", exc_info=True)
        raise


def init_default_profile() -> None:
    """
    Initialize database with default profile.
    
    Creates a profile named "default" with configuration from:
    - src/core/defaults.py - prompts and fallback values
    - slide_style_library - visual styling (seeded separately)
    
    Raises:
        Exception: If profile creation fails
    """
    logger.info("Initializing default profile")

    try:
        # Load YAML configuration for LLM settings, use defaults for prompts
        try:
            config = load_config()
            logger.info("Loaded LLM configuration from YAML")
        except Exception as e:
            logger.warning(f"Failed to load YAML settings, using defaults: {e}")
            config = DEFAULT_CONFIG
        
        # Prompts always come from defaults (visual styling from slide_style_library)
        prompts = DEFAULT_CONFIG["prompts"]

        with get_db_session() as db:
            # Check if default profile already exists
            existing = db.query(ConfigProfile).filter_by(name="default").first()
            if existing:
                logger.info(
                    "Default profile already exists",
                    extra={"profile_id": existing.id},
                )
                print(f"✓ Default profile already exists (ID: {existing.id})")
                return

            # Create default profile
            profile = ConfigProfile(
                name="default",
                description="Default configuration profile",
                is_default=True,
                created_by="system",
                updated_by="system",
            )
            db.add(profile)
            db.flush()

            logger.info("Created default profile", extra={"profile_id": profile.id})

            # LLM config now comes from DEFAULT_CONFIG, no per-profile AI infra needed

            # Create Genie space settings (one per profile)
            genie_space = ConfigGenieSpace(
                profile_id=profile.id,
                space_id=config["genie"]["default_space_id"],
                space_name=config["genie"].get("space_name", "Default Genie Space"),
                description=config["genie"].get("description", "Default Genie data space"),
            )
            db.add(genie_space)
            logger.info("Created Genie space settings")

            # Seed deck prompt library (global, not per-profile)
            # For local dev, include Databricks-specific content for backward compatibility
            _seed_deck_prompts(db, include_databricks=True)

            # Seed slide style library (global, not per-profile)
            # For local dev, include Databricks-specific styles for backward compatibility
            default_style_id = _seed_slide_styles(db, include_databricks=True)

            # Create prompts settings with default slide style
            prompts_config = ConfigPrompts(
                profile_id=profile.id,
                selected_slide_style_id=default_style_id,
                system_prompt=prompts["system_prompt"],
                slide_editing_instructions=prompts["slide_editing_instructions"],
            )
            db.add(prompts_config)
            logger.info("Created prompts settings")

            db.commit()

            logger.info(
                "Default profile initialized successfully",
                extra={
                    "profile_id": profile.id,
                    "genie_space": genie_space.space_name,
                },
            )

            print("\n✓ Default profile initialized successfully")
            print(f"  Profile ID: {profile.id}")
            print(f"  Profile Name: {profile.name}")
            print(f"  Genie Space: {genie_space.space_name}")
            print("\nYou can now start the application with database-backed configuration.")

    except Exception as e:
        logger.error(f"Failed to initialize default profile: {e}", exc_info=True)
        print(f"\n✗ Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    print("Initializing default configuration profile...")
    print("This will create a 'default' profile in the database from YAML files.\n")

    # Check database connection
    database_url = os.getenv("DATABASE_URL")
    if not database_url:
        print("✗ Error: DATABASE_URL environment variable not set")
        print("Please set DATABASE_URL to your PostgreSQL connection string:")
        print("  export DATABASE_URL='postgresql://user:pass@localhost:5432/ai_slide_generator'")
        sys.exit(1)

    print(f"Database: {database_url.split('@')[1] if '@' in database_url else database_url}")

    init_default_profile()

