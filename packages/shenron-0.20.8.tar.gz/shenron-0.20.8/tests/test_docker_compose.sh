#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if ! command -v shenron >/dev/null 2>&1; then
  echo "shenron CLI not available; install the local package first (for example: python3 -m pip install -e \"$ROOT_DIR\")" >&2
  exit 1
fi

if ! command -v docker >/dev/null 2>&1; then
  echo "docker not available; install docker to validate docker-compose output" >&2
  exit 1
fi

workdir="$(mktemp -d)"
cp "$ROOT_DIR/configs/Qwen06B-cu126-TP1.yml" "$workdir/"

shenron "$workdir"

docker compose -f "$workdir/docker-compose.yml" config >/dev/null
services="$(docker compose -f "$workdir/docker-compose.yml" config --services)"
for svc in vllm caddy prometheus scouter-reporter; do
  if ! echo "$services" | grep -qx "$svc"; then
    echo "docker-compose config missing service: $svc" >&2
    exit 1
  fi
done

echo "docker-compose.yml parses and includes expected services"
