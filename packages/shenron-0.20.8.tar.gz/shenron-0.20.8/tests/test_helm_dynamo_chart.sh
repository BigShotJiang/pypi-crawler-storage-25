#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CHART_DIR="$ROOT_DIR/helm/dynamo"

if ! command -v helm >/dev/null 2>&1; then
  echo "helm not available, skipping dynamo chart lint/render test"
  exit 0
fi

helm lint "$CHART_DIR" -f "$CHART_DIR/node-piccolo.yaml"

rendered_default="$(mktemp)"
rendered_multi="$(mktemp)"
multi_values="$(mktemp)"
trap 'rm -f "$rendered_default" "$rendered_multi" "$multi_values"' EXIT

helm template shenron-dynamo "$CHART_DIR" -f "$CHART_DIR/node-piccolo.yaml" >"$rendered_default"

if ! grep -q "app.kubernetes.io/component: caddy" "$rendered_default"; then
  echo "expected caddy resources to be rendered in dynamo profile" >&2
  exit 1
fi

if ! grep -q "handle_path /replica/\\*" "$rendered_default"; then
  echo "expected caddy to route /replica/* in dynamo profile" >&2
  exit 1
fi

if grep -q "handle_path /llm/\\*" "$rendered_default"; then
  echo "did not expect caddy to route /llm/* in dynamo profile" >&2
  exit 1
fi

if ! grep -q "name: shenron-dynamo-replica-manager" "$rendered_default"; then
  echo "expected replica manager resources to be rendered in dynamo profile" >&2
  exit 1
fi

if ! grep -q '^kind: DynamoGraphDeployment$' "$rendered_default"; then
  echo "expected DynamoGraphDeployment resources to be rendered in dynamo profile" >&2
  exit 1
fi

if ! grep -q "DYN_DISCOVERY_BACKEND" "$rendered_default"; then
  echo "expected DYN_DISCOVERY_BACKEND env wiring in dynamo workers" >&2
  exit 1
fi

if ! grep -q 'value: "nats"' "$rendered_default"; then
  echo "expected current nats request plane configuration in dynamo workers" >&2
  exit 1
fi

if ! grep -q 'nats://dynamo-nats.tail5ef35.ts.net:4222' "$rendered_default"; then
  echo "expected rendered workers to include the configured nats endpoint" >&2
  exit 1
fi

if grep -q -- '--port' "$rendered_default"; then
  echo "did not expect the chart to append --port to dynamo worker commands" >&2
  exit 1
fi

if grep -q "app.kubernetes.io/component: router" "$rendered_default"; then
  echo "did not expect legacy router resources in dynamo chart" >&2
  exit 1
fi

if [[ "$(grep -c '^kind: Deployment$' "$rendered_default")" -ne 2 ]]; then
  echo "expected only caddy and replica-manager Deployments alongside DGD resources" >&2
  exit 1
fi

if grep -q "app.kubernetes.io/component: prometheus" "$rendered_default"; then
  echo "did not expect prometheus resources in dynamo chart" >&2
  exit 1
fi

cat >"$multi_values" <<'EOF'
workerService:
  basePort: 32000
models:
  Qwen/Qwen3-0.6B:
    replicas: 2
EOF

helm template shenron-dynamo "$CHART_DIR" \
  -f "$CHART_DIR/node-piccolo.yaml" \
  -f "$multi_values" >"$rendered_multi"

if [[ "$(grep -c '^kind: DynamoGraphDeployment$' "$rendered_multi")" -lt 2 ]]; then
  echo "expected multiple DynamoGraphDeployments in multi-replica dynamo render" >&2
  exit 1
fi

if ! grep -q 'componentType: frontend' "$rendered_multi"; then
  echo "expected disabled frontend components to be present in the rendered DGD" >&2
  exit 1
fi

if ! grep -q 'replicas: 0' "$rendered_multi"; then
  echo "expected frontend components to be disabled with replicas 0" >&2
  exit 1
fi

if ! grep -q 'value: "nats"' "$rendered_multi"; then
  echo "expected multi-replica dynamo render to preserve the nats request plane" >&2
  exit 1
fi

if ! grep -q 'nats://dynamo-nats.tail5ef35.ts.net:4222' "$rendered_multi"; then
  echo "expected multi-replica dynamo render to preserve the configured nats endpoint" >&2
  exit 1
fi

if [[ "$(grep -c '^kind: Service$' "$rendered_multi")" -ne 2 ]]; then
  echo "expected only caddy and replica-manager services in the current nats-based multi-replica render" >&2
  exit 1
fi

echo "dynamo helm chart lint/template succeeded"
