#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if ! command -v shenron >/dev/null 2>&1; then
  echo "shenron CLI not available; install the local package first (for example: python3 -m pip install -e \"$ROOT_DIR\")" >&2
  exit 1
fi

mapfile -t configs < <(find "$ROOT_DIR/configs" -maxdepth 1 -type f \( -name '*.yml' -o -name '*.yaml' \) | sort)

if [ "${#configs[@]}" -eq 0 ]; then
  echo "no config fixtures found under $ROOT_DIR/configs" >&2
  exit 1
fi

for cfg in "${configs[@]}"; do
  workdir="$(mktemp -d)"
  cp "$cfg" "$workdir/"

  shenron "$workdir"

  required=(
    "$workdir/docker-compose.yml"
    "$workdir/.generated/Caddyfile"
    "$workdir/.generated/prometheus.yml"
    "$workdir/.generated/scouter_reporter.env"
  )

  for f in "${required[@]}"; do
    if [ ! -f "$f" ]; then
      echo "expected generated file not found for $(basename "$cfg"): $f" >&2
      exit 1
    fi
  done

  if [ ! -f "$workdir/.generated/engine_start.sh" ]; then
    if [ ! -f "$workdir/.generated/engine_start_1.sh" ] || [ ! -f "$workdir/.generated/sglangmux_start.sh" ]; then
      echo "expected engine startup scripts not found for $(basename "$cfg")" >&2
      exit 1
    fi
  fi

  rm -rf "$workdir"
done

echo "generator produced expected files for all config fixtures"
