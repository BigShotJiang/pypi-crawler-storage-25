#!/usr/bin/env bash
set -euo pipefail

exec sglangmux --listen-port 8100 --host 0.0.0.0 --upstream-timeout-secs 120 --model-ready-timeout-secs 600 --model-switch-timeout-secs 120 --log-dir /generated/logs /generated/engine_start_1.sh /generated/engine_start_2.sh
