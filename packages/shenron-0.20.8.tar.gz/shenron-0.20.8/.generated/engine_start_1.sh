#!/usr/bin/env bash
set -euo pipefail

exec python -m sglang.launch_server --model HuggingFaceTB/SmolLM2-135M-Instruct --port 8001 --host 0.0.0.0 --tp 1 --attention-backend triton
