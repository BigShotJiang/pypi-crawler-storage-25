#!/usr/bin/env bash
set -euo pipefail

exec python -m sglang.launch_server --model Qwen/Qwen3-0.6B --port 8002 --host 0.0.0.0 --tp 1 --attention-backend triton
