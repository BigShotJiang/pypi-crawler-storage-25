#!/usr/bin/env bash

export ETCD_ENDPOINTS=http://127.0.0.1:2379
export NATS_SERVER=nats://127.0.0.1:4222
export DYN_DISCOVERY_BACKEND=etcd
export DYN_REQUEST_PLANE=http

# This must be reachable by your workers.
# If workers are on this same machine, 127.0.0.1 is fine.
# If workers are remote, use this machine's real IP or DNS name instead.
export DYN_HTTP_RPC_HOST=127.0.0.1
export DYN_HTTP_RPC_PORT=8888

python -m dynamo.frontend --http-port 8000
