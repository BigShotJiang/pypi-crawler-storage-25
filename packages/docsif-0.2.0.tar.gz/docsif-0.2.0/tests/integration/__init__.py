"""Integration tests for SIF."""
