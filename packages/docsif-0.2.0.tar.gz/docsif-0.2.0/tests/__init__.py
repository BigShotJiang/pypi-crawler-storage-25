"""SIF test suite."""
