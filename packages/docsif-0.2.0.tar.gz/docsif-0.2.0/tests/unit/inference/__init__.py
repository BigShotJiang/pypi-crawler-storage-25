"""Inference unit tests."""
