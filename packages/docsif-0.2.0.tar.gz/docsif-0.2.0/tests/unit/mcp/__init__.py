"""MCP unit tests."""
