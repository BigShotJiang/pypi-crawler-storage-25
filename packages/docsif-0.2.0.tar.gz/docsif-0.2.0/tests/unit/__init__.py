"""Unit tests for SIF."""
