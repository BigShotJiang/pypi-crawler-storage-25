from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command

from wexample_wex_addon_services_db.services.mysql.commands.service.ready import (
    mysql__service__ready,
)

if TYPE_CHECKING:
    from wexample_app.response.boolean_response import BooleanResponse
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext


@command(type=COMMAND_TYPE_SERVICE, description="Check if maria service is ready")
def maria__service__ready(
    context: ExecutionContext,
    service: AppService,
) -> BooleanResponse:
    return mysql__service__ready(context=context, service=service)
