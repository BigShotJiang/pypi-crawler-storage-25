from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command

if TYPE_CHECKING:
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext


@command(
    type=COMMAND_TYPE_SERVICE,
    description="Configure mysql service in app config",
)
def mysql__service__install(
    context: ExecutionContext,
    service: AppService,
) -> None:
    from wexample_helpers.helpers.string import string_random_password

    app_name = service.app_workdir.get_config().search("global.name").get_str()
    config_file = service.app_workdir.get_config_file()
    config = config_file.read_config()

    config.set_by_path(f"service.{service.name}.host", f"{app_name}_{service.name}")
    config.set_by_path(f"service.{service.name}.name", app_name)
    config.set_by_path(f"service.{service.name}.password", string_random_password())
    config.set_by_path(f"service.{service.name}.port", 3306)
    config.set_by_path(f"service.{service.name}.user", "root")

    config_file.write_config(config)
    service.app_workdir.get_runtime_config(rebuild=True)

    context.io.log(f"Configured mysql service for app '{app_name}'")
