from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.annotation_row import AnnotationRow


T = TypeVar("T", bound="AnnotationsListResponse")


@_attrs_define
class AnnotationsListResponse:
    """GET /api/annotations — pinned-first ordering, rich filter set.

    Attributes:
        annotations (list[AnnotationRow]):
        count (int):
    """

    annotations: list[AnnotationRow]
    count: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        annotations = []
        for annotations_item_data in self.annotations:
            annotations_item = annotations_item_data.to_dict()
            annotations.append(annotations_item)

        count = self.count

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "annotations": annotations,
                "count": count,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.annotation_row import AnnotationRow

        d = dict(src_dict)
        annotations = []
        _annotations = d.pop("annotations")
        for annotations_item_data in _annotations:
            annotations_item = AnnotationRow.from_dict(annotations_item_data)

            annotations.append(annotations_item)

        count = d.pop("count")

        annotations_list_response = cls(
            annotations=annotations,
            count=count,
        )

        annotations_list_response.additional_properties = d
        return annotations_list_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
