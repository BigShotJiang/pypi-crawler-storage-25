from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.database_save_response import DatabaseSaveResponse
from ...models.database_settings import DatabaseSettings
from ...models.error_detail import ErrorDetail
from ...models.http_validation_error import HTTPValidationError
from ...models.rbac_error_detail import RBACErrorDetail
from ...types import Response


def _get_kwargs(
    *,
    body: DatabaseSettings,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/settings/database",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DatabaseSaveResponse | ErrorDetail | HTTPValidationError | RBACErrorDetail | None:
    if response.status_code == 200:
        response_200 = DatabaseSaveResponse.from_dict(response.json())

        return response_200

    if response.status_code == 401:
        response_401 = ErrorDetail.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = RBACErrorDetail.from_dict(response.json())

        return response_403

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DatabaseSaveResponse | ErrorDetail | HTTPValidationError | RBACErrorDetail]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: DatabaseSettings,
) -> Response[DatabaseSaveResponse | ErrorDetail | HTTPValidationError | RBACErrorDetail]:
    """Save Postgres config + reconnect pool (no restart)

     Update Postgres connection settings in .env and in the live process,
    then reconnect the pool — no API restart needed.

    On connect failure, the .env was still patched. The response carries
    `ok=false` + `error` so the operator can fix and retry. Reverting to
    the prior config requires editing .env on disk.

    Args:
        body (DatabaseSettings):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DatabaseSaveResponse | ErrorDetail | HTTPValidationError | RBACErrorDetail]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: DatabaseSettings,
) -> DatabaseSaveResponse | ErrorDetail | HTTPValidationError | RBACErrorDetail | None:
    """Save Postgres config + reconnect pool (no restart)

     Update Postgres connection settings in .env and in the live process,
    then reconnect the pool — no API restart needed.

    On connect failure, the .env was still patched. The response carries
    `ok=false` + `error` so the operator can fix and retry. Reverting to
    the prior config requires editing .env on disk.

    Args:
        body (DatabaseSettings):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DatabaseSaveResponse | ErrorDetail | HTTPValidationError | RBACErrorDetail
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: DatabaseSettings,
) -> Response[DatabaseSaveResponse | ErrorDetail | HTTPValidationError | RBACErrorDetail]:
    """Save Postgres config + reconnect pool (no restart)

     Update Postgres connection settings in .env and in the live process,
    then reconnect the pool — no API restart needed.

    On connect failure, the .env was still patched. The response carries
    `ok=false` + `error` so the operator can fix and retry. Reverting to
    the prior config requires editing .env on disk.

    Args:
        body (DatabaseSettings):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DatabaseSaveResponse | ErrorDetail | HTTPValidationError | RBACErrorDetail]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: DatabaseSettings,
) -> DatabaseSaveResponse | ErrorDetail | HTTPValidationError | RBACErrorDetail | None:
    """Save Postgres config + reconnect pool (no restart)

     Update Postgres connection settings in .env and in the live process,
    then reconnect the pool — no API restart needed.

    On connect failure, the .env was still patched. The response carries
    `ok=false` + `error` so the operator can fix and retry. Reverting to
    the prior config requires editing .env on disk.

    Args:
        body (DatabaseSettings):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DatabaseSaveResponse | ErrorDetail | HTTPValidationError | RBACErrorDetail
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
