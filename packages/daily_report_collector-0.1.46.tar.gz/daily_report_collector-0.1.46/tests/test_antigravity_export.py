from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "collector"))

from collector.parsers.antigravity_export import (  # noqa: E402
    _collect_local_session_artifacts,
    _build_pb_fallback_messages,
    _merge_summary,
    _extract_generator_fallbacks,
    _step_to_jsonl_line,
)


class AntigravityExportTests(unittest.TestCase):
    def test_merge_summary_keeps_richer_fields(self) -> None:
        merged = _merge_summary(
            {
                "summary": "",
                "stepCount": 3,
                "createdTime": "",
                "lastModifiedTime": "2026-04-05T10:00:00Z",
                "workspaces": [],
            },
            {
                "summary": "Recovered title",
                "stepCount": 8,
                "createdTime": "2026-04-05T09:00:00Z",
                "lastModifiedTime": "",
                "workspaces": [{"workspaceFolderAbsoluteUri": "file:///tmp/project"}],
            },
        )

        self.assertEqual(merged["summary"], "Recovered title")
        self.assertEqual(merged["stepCount"], 8)
        self.assertEqual(merged["createdTime"], "2026-04-05T09:00:00Z")
        self.assertEqual(
            merged["workspaces"][0]["workspaceFolderAbsoluteUri"],
            "file:///tmp/project",
        )

    def test_planner_response_keeps_response_and_thinking(self) -> None:
        step = {
            "type": "CORTEX_STEP_TYPE_PLANNER_RESPONSE",
            "metadata": {"createdAt": "2026-04-05T10:00:00Z"},
            "plannerResponse": {
                "response": "Final answer",
                "thinking": "Internal reasoning",
            },
        }

        msg = _step_to_jsonl_line(step, "cascade-id", "2026-04-05T09:59:59Z")

        self.assertIsNotNone(msg)
        assert msg is not None
        self.assertEqual(msg["type"], "assistant")
        self.assertEqual(msg["response_text"], "Final answer")
        self.assertEqual(msg["thinking_text"], "Internal reasoning")
        self.assertEqual(msg["fallback_source"], "")
        self.assertEqual(msg["message"]["content"][0]["text"], "Final answer")

    def test_generator_metadata_recovers_transcript_and_metadata_messages(self) -> None:
        payload = {
            "messagesTruncated": True,
            "transcript": "User: hello\nAssistant: recovered from transcript",
            "items": [
                {"role": "assistant", "text": "recovered from metadata"},
                {"role": "assistant", "text": "recovered from metadata"},
            ],
        }

        messages, diagnostics = _extract_generator_fallbacks(payload, "2026-04-05T10:00:00Z")
        contents = [msg["message"]["content"][0]["text"] for msg in messages]

        self.assertIn("recovered from transcript", contents)
        self.assertIn("recovered from metadata", contents)
        self.assertEqual(diagnostics["transcript_messages"], 1)
        self.assertEqual(diagnostics["generator_metadata_messages"], 1)
        self.assertTrue(diagnostics["messages_truncated"])

    def test_offline_pb_fallback_builds_messages_from_fragments(self) -> None:
        messages, diagnostics = _build_pb_fallback_messages([
            "Assistant: recovered from transcript",
            "This is a long recovered protobuf fragment that should remain visible to the user.",
            "file:///Users/test/project",
            "abcd1234",
        ], "2026-04-05T10:00:00Z")

        contents = [msg["message"]["content"][0]["text"] for msg in messages]
        self.assertIn("recovered from transcript", contents)
        self.assertIn(
            "This is a long recovered protobuf fragment that should remain visible to the user.",
            contents,
        )
        self.assertEqual(diagnostics["offline_pb_transcript_messages"], 1)
        self.assertEqual(diagnostics["offline_pb_messages"], 1)

    def test_collect_local_session_artifacts_counts_sources(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            conv = root / "conversations"
            brain = root / "brain" / "session-1"
            browser = root / "browser_recordings" / "session-1"
            conv.mkdir(parents=True)
            brain.mkdir(parents=True)
            browser.mkdir(parents=True)

            (conv / "session-1.pb").write_bytes(b"\x00\x01")
            (brain / "task.md").write_text("# task\n", encoding="utf-8")
            (brain / "walkthrough.md").write_text("# walkthrough\n", encoding="utf-8")
            (browser / "1.jpg").write_bytes(b"jpg")
            (browser / "2.jpg").write_bytes(b"jpg")
            (browser / "metadata.json").write_text(
                json.dumps({"highlights": [{"start_time": "a", "end_time": "b"}]}),
                encoding="utf-8",
            )

            diagnostics = _collect_local_session_artifacts(root, "session-1")

        self.assertTrue(diagnostics["pb_file_present"])
        self.assertEqual(diagnostics["brain_file_count"], 2)
        self.assertEqual(diagnostics["browser_recording_frame_count"], 2)
        self.assertEqual(diagnostics["browser_recording_highlight_count"], 1)


if __name__ == "__main__":
    unittest.main()
