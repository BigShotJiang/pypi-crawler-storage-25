"""Fluxwallet CLI — command-line interface for the Flux wallet library.

Usage:
    fluxwallet wallet list
    fluxwallet wallet info my_wallet
    fluxwallet tx send my_wallet t1abc... 1.5
    fluxwallet address list my_wallet
    fluxwallet multisig pair --new my_ms
    fluxwallet mnemonic
"""

from __future__ import annotations

import asyncio
import base64
import io
import json
import sys
from collections.abc import Awaitable, Callable
from functools import wraps
from pathlib import Path
from typing import Annotated

import qrcode
import typer
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm
from rich.table import Table
from typer import rich_utils

from fluxwallet.config import DEFAULT_WALLET_FILE
from fluxwallet.encoding import bech32_decode
from fluxwallet.keys import BKeyError, HDKey, derive_identity_key, sign_message, verify_message
from fluxwallet.migrate import migrate_sqlite_to_store
from fluxwallet.mnemonic import Mnemonic
from fluxwallet.sapling import SHIELDED_AVAILABLE
from fluxwallet.secure_mem import secure_wipe
from fluxwallet.services import Service
from fluxwallet.services.core import ServiceError
from fluxwallet.ssp import SSPWallet, _derive_relay_auth
from fluxwallet.transactions import FluxTransaction
from fluxwallet.type_guards import is_hdkey, is_wallet_key
from fluxwallet.values import Value, value_to_satoshi
from fluxwallet.wallet import Wallet, WalletError
from fluxwallet.wallet.core import AUTH_ONLY_NETWORKS
from fluxwallet.wallet.store_access import _get_store
from fluxwallet.wallet_file import change_password as _change_wallet_password
from fluxwallet.wallet_file import is_wallet_file, store_key_in_keyring, unwrap_master_key
from fluxwallet.wallets import wallet_delete as _wallet_delete
from fluxwallet.wallets import wallet_exists

rich_utils.STYLE_HELPTEXT = ""  # type: ignore[assignment]

console = Console()


class _Output:
    """Thin output layer that switches between Rich and JSON."""

    json_mode: bool = False
    _result: dict[str, object] | None = None

    def data(self, d: dict[str, object]) -> None:
        self._result = d

    def error(self, msg: str, details: dict[str, object] | None = None) -> None:
        if self.json_mode:
            err: dict[str, object] = {"error": msg}
            if details:
                err.update(details)
            print(json.dumps({"ok": False, **err}, indent=2, default=str))
            raise SystemExit(1)

    def flush(self) -> None:
        if self.json_mode and self._result is not None:
            print(json.dumps({"ok": True, "data": self._result}, indent=2, default=str))
            self._result = None


output = _Output()


def _json_prompt(label: str, *, hide_input: bool = False) -> str:
    """typer.prompt wrapper that errors in JSON mode when stdin is not piped."""
    if output.json_mode and sys.stdin.isatty():
        output.error(f"'{label}' requires piped stdin in JSON mode")
    return typer.prompt(label, hide_input=hide_input)


# ---------------------------------------------------------------------------
# Async bridge
# ---------------------------------------------------------------------------


def async_command[F: Callable[..., Awaitable[object]]](f: F) -> F:
    """Wrap an async function for use as a typer command."""

    @wraps(f)
    def wrapper(*args: object, **kwargs: object) -> object:
        async def _run() -> object:
            result = f(*args, **kwargs)
            if isinstance(result, Awaitable):
                return await result
            return result

        try:
            return asyncio.run(_run())
        finally:
            output.flush()

    return wrapper  # type: ignore[return-value]


def _print_decoded_tx(wt: object) -> None:
    """Print decoded transaction details."""
    tx = wt.tx  # type: ignore[attr-defined]
    fee_str = Value.from_satoshi(tx.fee or 0, network="flux").format_unit()
    lines = [
        f"[bold]TxID:[/bold]    {tx.txid}",
        f"[bold]Size:[/bold]    {tx.size} bytes",
        f"[bold]Fee:[/bold]     {fee_str}",
        f"[bold]Inputs:[/bold]  {len(tx.inputs)}",
    ]
    for i, inp in enumerate(tx.inputs):
        lines.append(f"  [{i}] {inp.prev_txid.hex()[:16]}... vout={inp.output_n}")
    lines.append(f"[bold]Outputs:[/bold] {len(tx.outputs)}")
    for i, out in enumerate(tx.outputs):
        out_val = Value.from_satoshi(out.value, network="flux").format_unit()
        lines.append(f"  [{i}] {out.address or '(unknown)'} {out_val}")
    console.print(Panel("\n".join(lines), title="Transaction"))


def _print_decoded_raw(raw_tx: bytes) -> None:
    """Parse and print a raw transaction hex."""

    tx = FluxTransaction.parse(raw_tx)
    lines = [
        f"[bold]TxID:[/bold]    {tx.txid}",
        f"[bold]Size:[/bold]    {tx.size} bytes",
        f"[bold]Inputs:[/bold]  {len(tx.inputs)}",
    ]
    for i, inp in enumerate(tx.inputs):
        lines.append(f"  [{i}] {inp.prev_txid.hex()[:16]}... vout={inp.output_n}")
    lines.append(f"[bold]Outputs:[/bold] {len(tx.outputs)}")
    for i, out in enumerate(tx.outputs):
        out_val = Value.from_satoshi(out.value, network="flux").format_unit()
        lines.append(f"  [{i}] {out.address or '(unknown)'} {out_val}")
    console.print(Panel("\n".join(lines), title="Transaction"))


def _handle_error(e: Exception) -> None:
    if output.json_mode:
        details: dict[str, object] | None = None
        if isinstance(e, ServiceError) and e.provider_errors:
            details = {"provider_errors": {p: str(err) for p, err in e.provider_errors.items()}}
            output.error(e.msg, details)
        else:
            output.error(str(e))
    if isinstance(e, ServiceError) and e.provider_errors:
        console.print(f"[bold red]Error:[/bold red] {e.msg}")
        for provider, err in e.provider_errors.items():
            console.print(f"  [bold]{provider}:[/bold] {err}")
    else:
        console.print(f"[bold red]Error:[/bold red] {e}")
    raise typer.Exit(1)


def _save_mnemonic(name: str, mnemonic: str) -> Path:
    """Write mnemonic to a file with restricted permissions."""
    path = Path(f"{name}-mnemonic.txt")
    path.write_text(mnemonic + "\n")
    path.chmod(0o600)
    return path


def _confirm(message: str) -> None:
    """Rich-styled confirmation prompt.

    Aborts on 'no'.  Auto-confirms in JSON mode.
    """
    if output.json_mode:
        return
    console.print(Panel(message, border_style="yellow"))
    if not Confirm.ask("[bold]Continue?[/bold]", console=console, default=False):
        raise typer.Abort()


def _print_qr(data: str) -> None:
    qr = qrcode.QRCode(
        version=None,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=1,
        border=1,
    )
    qr.add_data(data)
    qr.make(fit=True)
    buf = io.StringIO()
    qr.print_ascii(out=buf, invert=True)
    console.print(buf.getvalue())


async def _ensure_encrypted() -> None:
    """Ensure wallet store is loaded."""
    await Wallet.ensure_loaded()


def _get_master_key(w: Wallet) -> HDKey:
    """Extract the master HDKey from a wallet (regular or multisig)."""
    if w.multisig:
        for cs in w.cosigner:
            if cs.main_key and cs.main_key.is_private:
                if is_wallet_key(cs.main_key):
                    k = cs.main_key.key()
                    if k is not None:
                        return k
                elif is_hdkey(cs.main_key):
                    return cs.main_key
        raise WalletError("No private key found in multisig cosigners")
    mk = w.main_key
    if is_wallet_key(mk):
        k = mk.key()
        if k is not None:
            return k
    elif is_hdkey(mk):
        return mk
    raise WalletError("No master key available")


def _require_shielded() -> None:
    if not SHIELDED_AVAILABLE:
        console.print(
            "[bold red]Error:[/bold red] Shielded transactions require the sapling package.\n"
            "Install with: [bold]uv pip install fluxwallet\\[shielded][/bold]"
        )
        raise typer.Exit(1)


FLUX_COIN_TYPE = 19167


async def _broadcast_raw_tx(raw_tx: bytes) -> str:
    """Broadcast a raw transaction and return the txid."""
    srv = Service(network="flux")
    result = await srv.sendrawtransaction(raw_tx.hex())
    return result.txid


# ---------------------------------------------------------------------------
# App structure
# ---------------------------------------------------------------------------


class _CLIState:
    key_file: str | None = None
    json_output: bool = False


_cli = _CLIState()


def _global_options(
    key_file: Annotated[str | None, typer.Option("--key-file", help="Path to encryption key file")] = None,
    tpm_auth_file: Annotated[str | None, typer.Option("--tpm-auth-file", help="Path to TPM auth secret file")] = None,
    json_flag: Annotated[bool, typer.Option("--json", help="Output JSON instead of formatted text")] = False,
) -> None:
    global console
    _cli.key_file = key_file
    _cli.json_output = json_flag
    if json_flag:
        output.json_mode = True
        console = Console(quiet=True)
    Wallet.configure(key_file=key_file, tpm_auth_file=tpm_auth_file)
    def _new_password_with_confirm() -> str:
        pw = _json_prompt("Choose wallet password", hide_input=True)
        confirm = _json_prompt("Confirm wallet password", hide_input=True)
        if pw != confirm:
            _handle_error(Exception("Passwords do not match"))
        return pw

    Wallet.set_password_prompt(
        lambda: _json_prompt("Wallet password", hide_input=True),
        new_callback=_new_password_with_confirm,
    )


app = typer.Typer(
    name="fluxwallet",
    help="Flux blockchain wallet CLI\n\nUnlock: stdin pipe > --key-file > OS keychain > password prompt.",
    no_args_is_help=True,
    add_completion=False,
    callback=_global_options,
)
wallet_app = typer.Typer(help="Wallet management.", no_args_is_help=True)
address_app = typer.Typer(help="Address and key management.", no_args_is_help=True)
tx_app = typer.Typer(help="Transactions.", no_args_is_help=True)
multisig_app = typer.Typer(help="2-of-2 multisig co-signing.", no_args_is_help=True)
db_app = typer.Typer(help="Database operations.", no_args_is_help=True)


# Registration order controls display order in --help.
app.add_typer(wallet_app, name="wallet")
app.add_typer(address_app, name="address")
app.add_typer(tx_app, name="tx")
app.add_typer(multisig_app, name="multisig")
app.add_typer(db_app, name="db")

# network and mnemonic registered as invoke-without-command typers
# so they appear after the main groups in --help output.
_network_app = typer.Typer(help="Show blockchain network status.", invoke_without_command=True)
_mnemonic_app = typer.Typer(help="Generate a new mnemonic seed phrase.", invoke_without_command=True)
app.add_typer(_network_app, name="network")
app.add_typer(_mnemonic_app, name="mnemonic")


@_network_app.callback(invoke_without_command=True)
@async_command
async def network_info(
    network: Annotated[str, typer.Option("--network", "-n", help="Network name")] = "flux",
) -> None:
    """Show blockchain network status."""
    try:
        srv = Service(network=network)
        with console.status("Querying network..."):
            height = await srv.blockcount()
            fee = await srv.estimatefee()

        fee_str = Value.from_satoshi(fee, network=network).format_unit()
        output.data({"network": network, "height": height, "fee": fee_str, "fee_sats": fee})
        console.print(
            Panel(
                f"[bold]Network:[/bold]  {network}\n"
                f"[bold]Height:[/bold]   {height}\n"
                f"[bold]Fee:[/bold]      {fee_str}/KB",
                title="Network Status",
            )
        )
    except (WalletError, ServiceError) as e:
        _handle_error(e)


@_mnemonic_app.callback(invoke_without_command=True)
@async_command
async def mnemonic_generate(
    words: Annotated[int, typer.Option("--words", "-w", help="Number of words (12 or 24)")] = 24,
) -> None:
    """Generate a new mnemonic seed phrase."""

    if words not in (12, 24):
        _handle_error(Exception(
            "--words must be 12 or 24."
            " Recovery: use --words 12 or --words 24"
        ))

    strength = 256 if words == 24 else 128
    m = Mnemonic()
    phrase = m.generate(strength=strength)

    output.data({"mnemonic": phrase, "words": words})
    console.print(
        Panel(
            phrase,
            title=f"Mnemonic ({words} words)",
            subtitle="SAVE THIS SECURELY",
            border_style="yellow",
        )
    )


# ---------------------------------------------------------------------------
# wallet commands
# ---------------------------------------------------------------------------


@wallet_app.command("list")
@async_command
async def wallet_list() -> None:
    """List all wallets."""
    wallets = await Wallet.list_all()
    if not wallets:
        output.data({"wallets": []})
        console.print("No wallets found.")
        return

    PURPOSE_LABELS = {44: "standard", 48: "multisig"}

    table = Table(title="Wallets")
    table.add_column("ID", style="dim")
    table.add_column("Name", style="bold")
    table.add_column("Network")
    table.add_column("Type")

    for w in wallets:
        purpose = w["purpose"]
        if not isinstance(purpose, int):
            purpose = int(purpose) if purpose is not None else 0
        table.add_row(
            str(w["id"]),
            str(w["name"]),
            str(w["network"]),
            PURPOSE_LABELS.get(purpose, f"BIP{purpose}"),
        )

    output.data({"wallets": [
        {
            "id": w["id"],
            "name": str(w["name"]),
            "network": str(w["network"]),
            "type": PURPOSE_LABELS.get(
                int(w["purpose"]) if w["purpose"] is not None else 0,
                f"BIP{w['purpose']}",
            ),
        }
        for w in wallets
    ]})
    console.print(table)


@wallet_app.command("create")
@async_command
async def wallet_create(
    wallet: Annotated[str, typer.Argument(help="Wallet name")],
    network: Annotated[str, typer.Option("--network", "-n", help="Network name")] = "flux",
    multisig: Annotated[bool, typer.Option("--multisig", "-m", help="Create SSP multisig wallet")] = False,
    peer: Annotated[bool, typer.Option("--peer", help="Immediately pair with SSP Key (requires --multisig)")] = False,
    relay: Annotated[str, typer.Option("--relay", help="SSP relay server URL")] = "relay.sspwallet.io",
    show_mnemonic: Annotated[
        bool, typer.Option("--show-mnemonic", help="Display mnemonic on screen"),
    ] = False,
) -> None:
    """Create a new wallet from a generated mnemonic."""
    if peer and not multisig:
        _handle_error(Exception("--peer requires --multisig"))

    try:
        await _ensure_encrypted()
        mnemonic = Mnemonic().generate()
        mnemonic_path = _save_mnemonic(wallet, mnemonic)

        if multisig:
            await _create_multisig(
                wallet, mnemonic, relay,
                peer=peer, show_mnemonic=show_mnemonic, mnemonic_path=mnemonic_path,
            )
            return

        w = await Wallet.from_mnemonic(wallet, mnemonic, network=network)
        key = await w.get_key()

        data: dict[str, object] = {
            "name": w.name,
            "network": w.network.name,
            "address": key.address,
            "mnemonic_file": str(mnemonic_path),
        }
        if show_mnemonic:
            data["mnemonic"] = mnemonic

        z_line = ""
        if SHIELDED_AVAILABLE:
            z_addr = await w.z_address()
            z_line = f"[bold]z-receive:[/bold] {z_addr}\n"
            data["z_address"] = z_addr

        output.data(data)
        info = (
            f"[bold]Name:[/bold]      {w.name}\n"
            f"[bold]Network:[/bold]   {w.network.name}\n"
            f"[bold]Receive:[/bold]   {key.address}\n"
            f"{z_line}"
        )
        console.print(Panel(info.rstrip(), title="Wallet Created"))
        if show_mnemonic:
            console.print(Panel(mnemonic, title="Mnemonic", border_style="red"))
        console.print(f"[yellow]Mnemonic saved to:[/yellow] {mnemonic_path}")
    except (WalletError, ServiceError) as e:
        _handle_error(e)


@wallet_app.command("restore")
@async_command
async def wallet_restore(
    wallet: Annotated[str, typer.Argument(help="Wallet name")],
    network: Annotated[str, typer.Option("--network", "-n", help="Network name")] = "flux",
    multisig: Annotated[bool, typer.Option("--multisig", "-m", help="Restore SSP multisig wallet")] = False,
    peer: Annotated[bool, typer.Option("--peer", help="Immediately pair with SSP Key (requires --multisig)")] = False,
    relay: Annotated[str, typer.Option("--relay", help="SSP relay server URL")] = "relay.sspwallet.io",
) -> None:
    """Restore a wallet from a mnemonic seed phrase."""
    if peer and not multisig:
        _handle_error(Exception("--peer requires --multisig"))

    mnemonic = _json_prompt("Mnemonic seed phrase", hide_input=True)

    if multisig:
        await _create_multisig(wallet, mnemonic, relay, peer=peer)
        return

    try:
        await _ensure_encrypted()
        w = await Wallet.from_mnemonic(wallet, mnemonic, network=network)
        key = await w.get_key()

        z_line = ""
        data: dict[str, object] = {
            "name": w.name,
            "network": w.network.name,
            "address": key.address,
        }
        if SHIELDED_AVAILABLE:
            z_addr = await w.z_address()
            z_line = f"[bold]z-receive:[/bold] {z_addr}\n"
            data["z_address"] = z_addr

        output.data(data)
        console.print(
            Panel(
                f"[bold]Name:[/bold]      {w.name}\n"
                f"[bold]Network:[/bold]   {w.network.name}\n"
                f"[bold]Receive:[/bold]   {key.address}\n"
                f"{z_line}",
                title="Wallet Restored",
            )
        )
    except (WalletError, ServiceError) as e:
        _handle_error(e)


@wallet_app.command("info")
@async_command
async def wallet_info(
    wallet: Annotated[str, typer.Argument(help="Wallet name")],
) -> None:
    """Show wallet details, balance, and receive address."""
    try:
        w = await Wallet.open(wallet)
        try:
            with console.status("Updating from network..."):
                await w.utxos_update()
        except (WalletError, ServiceError, OSError):
            pass
        balance = await w.balance(as_string=True)
        balance_sats = await w.balance()
        key = await w.get_key()

        data: dict[str, object] = {
            "name": w.name,
            "network": w.network.name,
            "scheme": w.scheme,
            "multisig": w.multisig,
            "balance": balance,
            "balance_sats": balance_sats,
            "address": key.address,
        }

        z_addr_line = ""
        if SHIELDED_AVAILABLE:
            try:
                z_addr = await w.z_address()
                max_addr = console.width - 17
                display = z_addr if len(z_addr) <= max_addr else z_addr[: max_addr - 1] + "…"
                z_addr_line = f"\n[bold]z-receive:[/bold] {display}"
                data["z_address"] = z_addr
            except WalletError:
                pass

        shielded_line = ""
        if SHIELDED_AVAILABLE:
            try:
                sw = await w.open_shielded()
                shielded_bal = Value.from_satoshi(sw.balance(), network="flux").format_unit()
                shielded_line = f"\n[bold]Shielded:[/bold]  {shielded_bal} ({len(sw.unspent_notes())} notes)"
                data["shielded_balance"] = shielded_bal
                data["shielded_balance_sats"] = sw.balance()
            except (WalletError, OSError, ValueError):
                pass

        fluxid_line = ""
        try:

            master_key = _get_master_key(w)
            identity = derive_identity_key(master_key)
            fluxid_line = f"\n[bold]FluxID:[/bold]    {identity.address()}"
            data["fluxid"] = identity.address()
        except (WalletError, BKeyError, ValueError):
            pass

        if w.multisig:
            data["paired"] = bool(w.ssp_peer_pubkey)

        info = (
            f"[bold]Name:[/bold]      {w.name}\n"
            f"[bold]Network:[/bold]   {w.network.name}\n"
            f"[bold]Scheme:[/bold]    {w.scheme}\n"
            f"[bold]Multisig:[/bold]  {w.multisig}\n"
            f"[bold]Balance:[/bold]   {balance}"
            f"{shielded_line}\n"
            f"[bold]Receive:[/bold]   {key.address}"
            f"{z_addr_line}"
            f"{fluxid_line}"
        )
        if w.multisig and w.ssp_peer_pubkey:
            info += "\n[bold]Multisig:[/bold] paired"
        elif w.multisig:
            info += f"\n[bold]Multisig:[/bold] [yellow]unpaired[/yellow] — run `fluxwallet multisig pair {w.name}`"

        output.data(data)
        console.print(Panel(info, title=w.name))
    except (WalletError, ServiceError) as e:
        _handle_error(e)


@wallet_app.command("rename")
@async_command
async def wallet_rename(
    wallet: Annotated[str, typer.Argument(help="Current wallet name")],
    new_name: Annotated[str, typer.Argument(help="New wallet name")],
) -> None:
    """Rename a wallet."""
    try:
        w = await Wallet.open(wallet)
        await w.set_name(new_name)
        output.data({"old_name": wallet, "new_name": new_name})
        console.print(f"Renamed '{wallet}' to '{new_name}'.")
    except (WalletError, ServiceError) as e:
        _handle_error(e)


@wallet_app.command("find")
@async_command
async def wallet_find(
    address: Annotated[str, typer.Argument(help="Address to look up")],
) -> None:
    """Find which wallet owns an address."""
    w = await Wallet.find_by_address(address)
    if w:
        output.data({"wallet": w.name, "wallet_id": w.wallet_id})
        console.print(
            Panel(
                f"[bold]Wallet:[/bold] {w.name}\n[bold]ID:[/bold]     {w.wallet_id}",
                title="Address Found",
            )
        )
    else:
        output.data({"found": False})
        console.print("Address not found in any wallet.")


@wallet_app.command("delete")
@async_command
async def wallet_delete(
    wallet: Annotated[str, typer.Argument(help="Wallet name")],
    yes: Annotated[bool, typer.Option("--yes", "-y", help="Skip confirmation")] = False,
    force: Annotated[bool, typer.Option("--force", help="Required for --json mode")] = False,
) -> None:
    """Delete a wallet."""

    if output.json_mode and not force:
        output.error("--force is required when using --json")
    if not yes and not force:
        _confirm(f"Delete wallet '{wallet}'?")
    try:
        await _wallet_delete(wallet, force=True)
        output.data({"deleted": wallet})
        console.print(f"Wallet '{wallet}' deleted.")
    except (WalletError, ServiceError) as e:
        _handle_error(e)


@wallet_app.command("balance")
@async_command
async def wallet_balance(
    wallet: Annotated[str, typer.Argument(help="Wallet name")],
) -> None:
    """Show wallet balance."""
    try:
        w = await Wallet.open(wallet)
        with console.status("Updating from network..."):
            await w.utxos_update()
        balance = await w.balance(as_string=True)
        balance_sats = await w.balance()

        data: dict[str, object] = {"wallet": wallet, "balance": balance, "balance_sats": balance_sats}
        shielded_line = ""
        if SHIELDED_AVAILABLE:
            try:
                sw = await w.open_shielded()
                shielded_bal = Value.from_satoshi(sw.balance(), network="flux").format_unit()
                shielded_line = f"\n[bold]Shielded:[/bold] {shielded_bal}"
                data["shielded_balance"] = shielded_bal
                data["shielded_balance_sats"] = sw.balance()
            except (WalletError, OSError, ValueError):
                pass

        output.data(data)
        console.print(Panel(f"[bold]Balance:[/bold]  {balance}{shielded_line}", title=wallet))
    except (WalletError, ServiceError) as e:
        _handle_error(e)


@wallet_app.command("scan")
@async_command
async def wallet_scan(
    wallet: Annotated[str, typer.Argument(help="Wallet name")],
) -> None:
    """Full scan wallet from network."""
    try:
        w = await Wallet.open(wallet)
        with console.status("Scanning..."):
            await w.scan()
        balance = await w.balance(as_string=True)
        balance_sats = await w.balance()

        data: dict[str, object] = {"wallet": wallet, "balance": balance, "balance_sats": balance_sats}
        shielded_line = ""
        if SHIELDED_AVAILABLE:
            try:
                sw = await w.open_shielded()
                with console.status("Scanning shielded transactions..."):
                    new_count = await sw.sync()
                shielded_bal = Value.from_satoshi(sw.balance(), network="flux").format_unit()
                shielded_line = f"\n[bold]Shielded:[/bold] {shielded_bal} ({new_count} new notes)"
                data["shielded_balance"] = shielded_bal
                data["shielded_balance_sats"] = sw.balance()
            except (WalletError, ServiceError, OSError, ValueError):
                pass

        output.data(data)
        console.print(Panel(f"[bold]Balance:[/bold] {balance}{shielded_line}", title="Scan Complete"))
    except (WalletError, ServiceError) as e:
        _handle_error(e)


@wallet_app.command("export")
@async_command
async def wallet_export(
    wallet: Annotated[str, typer.Argument(help="Wallet name")],
    private: Annotated[bool, typer.Option("--private", help="Export private key (WIF)")] = False,
    account: Annotated[int, typer.Option("--account", help="Account ID")] = 0,
) -> None:
    """Export the master public key (xpub) or private key (WIF)."""
    try:
        w = await Wallet.open(wallet)

        if private:
            _confirm("This will display your PRIVATE KEY. Anyone with this key can spend your funds.")
            if w.multisig:
                wifs = w.wif_multisig(is_private=True)
                output.data({"keys": list(wifs), "type": "private"})
                for i, wif in enumerate(wifs):
                    console.print(Panel(wif, title=f"Private Key (Cosigner {i})", border_style="red"))
            else:
                wif = w.wif(is_private=True, account_id=account)
                if wif is None:
                    _handle_error(WalletError(
                        "Private key not available."
                        " Recovery: import the private key first"
                    ))
                output.data({"key": str(wif), "type": "private"})
                console.print(Panel(str(wif), title="Private Key", border_style="red"))
        else:
            if w.multisig:
                wifs = w.wif_multisig(is_private=False)
                output.data({"keys": list(wifs), "type": "public"})
                for i, wif in enumerate(wifs):
                    console.print(Panel(wif, title=f"Public Key (Cosigner {i})"))
            else:
                xpub = w.wif(is_private=False, account_id=account)
                if xpub is None:
                    _handle_error(WalletError(
                        "Public key not available."
                        " Recovery: try generating a key first"
                    ))
                output.data({"key": str(xpub), "type": "public"})
                console.print(Panel(str(xpub), title="Public Key"))
    except (WalletError, Exception) as e:
        _handle_error(e)


# ---------------------------------------------------------------------------
# address commands
# ---------------------------------------------------------------------------


@address_app.command("list")
@async_command
async def address_list(
    wallet: Annotated[str, typer.Argument(help="Wallet name")],
    limit: Annotated[int, typer.Option("--limit", "-l", help="Max addresses to show")] = 0,
    qr: Annotated[bool, typer.Option("--qr", help="Display QR code for receive address")] = False,
) -> None:
    """List wallet addresses."""
    try:
        w = await Wallet.open(wallet)
        keys = await w.keys()

        receive = await w.get_key()
        change = await w.get_key_change()

        table = Table(title=f"Addresses — {wallet}")
        table.add_column("Path", style="dim")
        table.add_column("Address")
        table.add_column("Used")
        table.add_column("Type")

        shown = 0
        transparent_keys = []
        sapling_keys = []
        for k in keys:
            if k.network_name in AUTH_ONLY_NETWORKS:
                continue
            if k.key_type == "sapling":
                continue
            if k.key_type == "sapling_address":
                sapling_keys.append(k)
            elif k.depth is not None and k.depth >= 5:
                transparent_keys.append(k)

        for k in transparent_keys:
            if limit and shown >= limit:
                break
            key_type = "change" if k.change else "receive"
            table.add_row(
                str(k.path) if k.path else "",
                str(k.address) if k.address else "",
                "yes" if k.used else "",
                key_type,
            )
            shown += 1

        z_receive_n = 0
        z_change_n = 0
        for k in sapling_keys:
            if limit and shown >= limit:
                break
            if k.change:
                label = "z-change"
                z_change_n += 1
                display_path = f"z/1/{z_change_n - 1}"
            else:
                label = "z-receive"
                z_receive_n += 1
                display_path = f"z/0/{z_receive_n - 1}"
            table.add_row(display_path, k.address or "", "yes" if k.used else "", label)
            shown += 1

        addr_list = [
            {
                "path": str(k.path) or "",
                "address": k.address or "",
                "used": k.used,
                "type": "change" if k.change else "receive",
            }
            for k in transparent_keys[: limit or None]
        ]
        z_recv_n = 0
        z_chg_n = 0
        for k in sapling_keys[: (limit - len(addr_list)) if limit else None]:
            if k.change:
                z_chg_n += 1
                p = f"z/1/{z_chg_n - 1}"
                t = "z-change"
            else:
                z_recv_n += 1
                p = f"z/0/{z_recv_n - 1}"
                t = "z-receive"
            addr_list.append({"path": p, "address": k.address or "", "used": k.used, "type": t})
        output.data({
            "addresses": addr_list,
            "receive": receive.address,
            "change": change.address,
        })

        console.print(table)
        console.print(Panel(
            f"[bold]Receive:[/bold] {receive.address}\n"
            f"[bold]Change:[/bold]  {change.address}",
            title=f"Current — {wallet}",
        ))
        if qr:
            _print_qr(receive.address)
    except (WalletError, ServiceError) as e:
        _handle_error(e)


@address_app.command("new")
@async_command
async def address_new(
    wallet: Annotated[str, typer.Argument(help="Wallet name")],
    change: Annotated[bool, typer.Option("--change", help="Generate change address")] = False,
    shielded: Annotated[bool, typer.Option("--shielded", "-z", help="Generate shielded z-address")] = False,
    qr: Annotated[bool, typer.Option("--qr", help="Display QR code")] = False,
) -> None:
    """Generate a new receiving address."""
    try:
        w = await Wallet.open(wallet)
        if shielded:
            _require_shielded()
            addr_key = await w.new_sapling_key(change=1 if change else 0)
            label = "z-change" if change else "z-receive"
            output.data({"address": addr_key.address, "type": label})
            console.print(Panel(addr_key.address, title=f"New Address ({label})"))
            if qr:
                _print_qr(addr_key.address)
        else:
            key = await w.new_key(change=1 if change else 0)
            label = "change" if change else "receive"
            output.data({"address": key.address, "type": label})
            console.print(Panel(key.address, title=f"New Address ({label})"))
            if qr:
                _print_qr(key.address)
    except (WalletError, ServiceError) as e:
        _handle_error(e)


@address_app.command("pubkey")
@async_command
async def address_pubkey(
    address: Annotated[str, typer.Argument(help="Flux address to look up")],
) -> None:
    """Show the compressed public key for an address in the wallet."""
    try:
        await Wallet.ensure_loaded()
        store = await _get_store()
        sk = store.get_key(address=address)
        if sk is None:
            _handle_error(WalletError(
                f"Address {address} not found in any wallet."
                " Recovery: check the address or use 'address list' to see available addresses"
            ))
            return
        if not sk.public:
            _handle_error(WalletError(f"No public key stored for {address}"))
            return
        pubkey_hex = sk.public.hex()

        output.data({"address": sk.address, "pubkey": pubkey_hex})
        console.print(Panel(
            f"[bold]Address:[/bold] {sk.address}\n"
            f"[bold]Pubkey:[/bold]  {pubkey_hex}",
            title="Public Key",
        ))
    except (WalletError, ServiceError) as e:
        _handle_error(e)


@address_app.command("import")
@async_command
async def address_import(
    wallet: Annotated[str, typer.Argument(help="Wallet name")],
) -> None:
    """Import a private key (WIF) or public key into a wallet."""
    try:
        key = _json_prompt("Key (WIF or public)")
        w = await Wallet.open(wallet)
        wk = await w.import_key(key)
        if wk is None:
            output.data({"address": None, "imported": False})
            console.print("Key already exists in wallet.")
        else:
            output.data({"address": wk.address, "imported": True})
            console.print(Panel(f"[bold]Address:[/bold] {wk.address}", title="Key Imported"))
    except (WalletError, ServiceError) as e:
        _handle_error(e)


@address_app.command("identity")
@async_command
async def address_identity(
    wallet: Annotated[str, typer.Argument(help="Wallet name")],
    qr: Annotated[bool, typer.Option("--qr", help="Display QR code")] = False,
) -> None:
    """Show the wallet's FluxID (Bitcoin identity address for FluxOS login)."""

    try:
        w = await Wallet.open(wallet)
        master_key = _get_master_key(w)
        identity = derive_identity_key(master_key)
        output.data({"wallet": w.name, "fluxid": identity.address()})
        console.print(
            Panel(
                f"[bold]Wallet:[/bold] {w.name}\n[bold]FluxID:[/bold] {identity.address()}",
                title="FluxID",
            )
        )
        if qr:
            _print_qr(identity.address())
    except (WalletError, Exception) as e:
        _handle_error(e)


@address_app.command("sign")
@async_command
async def address_sign(
    wallet: Annotated[str, typer.Argument(help="Wallet name")],
    message: Annotated[str, typer.Argument(help="Message to sign")],
    fluxid: Annotated[
        bool,
        typer.Option("--fluxid", help="Sign with FluxID identity key (Bitcoin prefix)"),
    ] = False,
) -> None:
    """Sign a message with the wallet's private key."""

    try:
        w = await Wallet.open(wallet)

        if fluxid:

            master_key = _get_master_key(w)
            identity = derive_identity_key(master_key)
            btc_prefix = b"\x18Bitcoin Signed Message:\n"
            sig, pubkey = sign_message(message, identity, message_prefix=btc_prefix)
            address = identity.address()
        else:
            key = await w.get_key()
            hdkey = key.key()
            if hdkey is None or hdkey.private_byte is None:
                _handle_error(WalletError(
                    "No private key available for signing."
                    " Recovery: import a private key or use a wallet that has one"
                ))
                return
            sig, pubkey = sign_message(message, hdkey)
            address = key.address

        output.data({"address": address, "signature": base64.b64encode(sig).decode()})
        console.print(
            Panel(
                f"[bold]Address:[/bold]   {address}\n[bold]Signature:[/bold] {base64.b64encode(sig).decode()}",
                title="Message Signed",
            )
        )
    except (WalletError, Exception) as e:
        _handle_error(e)


@address_app.command("verify")
@async_command
async def address_verify(
    address: Annotated[str, typer.Argument(help="Address that signed the message")],
    message: Annotated[str, typer.Argument(help="Original message")],
    signature: Annotated[str, typer.Argument(help="Base64-encoded signature")],
) -> None:
    """Verify a message signature against an address."""

    try:
        sig_bytes = base64.b64decode(signature)
        valid = verify_message(message, sig_bytes, address=address)
        if valid:
            output.data({"valid": True})
            console.print("[green]Valid[/green] signature.")
        else:
            output.data({"valid": False})
            console.print("[red]Invalid[/red] signature.")
            raise typer.Exit(1)
    except (BKeyError, ValueError) as e:
        _handle_error(e)


# ---------------------------------------------------------------------------
# tx commands
# ---------------------------------------------------------------------------


@tx_app.command("list")
@async_command
async def tx_list(
    wallet: Annotated[str, typer.Argument(help="Wallet name")],
) -> None:
    """List wallet transactions."""
    try:
        w = await Wallet.open(wallet)
        txs = await w.transactions(as_dict=True)

        if not txs:
            output.data({"transactions": []})
            console.print("No transactions.")
            return

        output.data({
            "transactions": [
                {
                    "txid": str(t.get("txid", "")),
                    "date": str(t.get("date", "")),
                    "confirmations": t.get("confirmations"),
                    "status": str(t.get("status", "")),
                }
                for t in txs
            ],
        })
        table = Table(title=f"Transactions — {wallet}")
        table.add_column("TxID", style="dim")
        table.add_column("Date")
        table.add_column("Confirmations", justify="right")
        table.add_column("Status")

        for tx_dict in txs:
            txid = str(tx_dict.get("txid", ""))
            table.add_row(
                txid[:16] + "..." if len(txid) > 16 else txid,
                str(tx_dict.get("date", "")),
                str(tx_dict.get("confirmations", "")),
                str(tx_dict.get("status", "")),
            )

        console.print(table)
    except (WalletError, ServiceError) as e:
        _handle_error(e)


@tx_app.command("utxos")
@async_command
async def tx_utxos(
    wallet: Annotated[str, typer.Argument(help="Wallet name")],
    shielded: Annotated[
        bool,
        typer.Option("--shielded", "-z", help="Show shielded notes instead of transparent UTXOs"),
    ] = False,
) -> None:
    """List unspent outputs (transparent UTXOs or shielded notes)."""
    try:
        w = await Wallet.open(wallet)

        if shielded:
            _require_shielded()
            sw = await w.open_shielded()

            notes = sw.unspent_notes()
            if not notes:
                output.data({"notes": []})
                console.print("No unspent shielded notes.")
                return

            table = Table(title=f"Shielded Notes — {wallet}")
            table.add_column("Index", justify="right", style="dim")
            table.add_column("Value", justify="right")

            total = 0
            for i, note in enumerate(notes):
                val = Value.from_satoshi(note.value, network="flux").format_unit()
                table.add_row(str(i), val)
                total += note.value

            total_str = Value.from_satoshi(total, network="flux").format_unit()
            output.data({
                "notes": [
                    {
                        "index": i,
                        "value_sats": note.value,
                        "value": Value.from_satoshi(note.value, network="flux").format_unit(),
                    }
                    for i, note in enumerate(notes)
                ],
                "total_sats": total,
                "total": total_str,
                "count": len(notes),
            })
            console.print(table)
            console.print(f"[bold]Total:[/bold] {total_str} ({len(notes)} notes)")
        else:
            with console.status("Updating UTXOs..."):
                await w.utxos_update()
            utxos = await w.utxos()

            if not utxos:
                output.data({"utxos": []})
                console.print("No UTXOs.")
                return

            table = Table(title=f"UTXOs — {wallet}")
            table.add_column("TxID", style="dim")
            table.add_column("Index", justify="right")
            table.add_column("Address")
            table.add_column("Value", justify="right")
            table.add_column("Confirmations", justify="right")

            for u in utxos:
                txid = u.txid
                value = Value.from_satoshi(u.value, network="flux")
                table.add_row(
                    txid[:16] + "..." if len(txid) > 16 else txid,
                    str(u.output_n),
                    u.address,
                    value.format_unit(),
                    str(u.confirmations),
                )

            output.data({
                "utxos": [
                    {
                        "txid": u.txid,
                        "output_n": u.output_n,
                        "address": u.address,
                        "value_sats": u.value,
                        "value": Value.from_satoshi(u.value, network="flux").format_unit(),
                        "confirmations": u.confirmations,
                    }
                    for u in utxos
                ],
            })
            console.print(table)
    except (WalletError, ServiceError) as e:
        _handle_error(e)


@tx_app.command("update")
@async_command
async def tx_update(
    wallet: Annotated[str, typer.Argument(help="Wallet name")],
) -> None:
    """Update UTXOs from network."""
    try:
        w = await Wallet.open(wallet)
        with console.status("Updating UTXOs..."):
            await w.utxos_update()
        balance = await w.balance(as_string=True)
        balance_sats = await w.balance()
        output.data({"balance": balance, "balance_sats": balance_sats})
        console.print(f"Updated. Balance: {balance}")
    except (WalletError, ServiceError) as e:
        _handle_error(e)


@tx_app.command("send")
@async_command
async def tx_send(
    wallet: Annotated[str, typer.Argument(help="Wallet name")],
    address: Annotated[str, typer.Argument(help="Destination address (t-address or z-address)")],
    amount: Annotated[str, typer.Argument(help="Amount in FLUX (e.g. 1.5) or satoshis with --sat")],
    sat: Annotated[bool, typer.Option("--sat", help="Amount is in satoshis")] = False,
    fee: Annotated[int | None, typer.Option("--fee", help="Fee in satoshis (auto if omitted)")] = None,
    yes: Annotated[bool, typer.Option("--yes", "-y", help="Skip confirmation")] = False,
    broadcast: Annotated[bool, typer.Option("--broadcast", "-b", help="Broadcast transaction")] = False,
    decode: Annotated[bool, typer.Option("--decode", "-d", help="Show decoded transaction")] = False,
    memo: Annotated[
        str,
        typer.Option("--memo", help="Encrypted memo for shielded sends (max 512 bytes)"),
    ] = "",
    relay: Annotated[str, typer.Option("--relay", help="SSP relay server URL")] = "relay.sspwallet.io",
    timeout: Annotated[int, typer.Option("--timeout", help="SSP Key approval timeout in seconds")] = 300,
) -> None:
    """Create and sign a transaction, outputs raw hex by default."""
    is_shielded = address.startswith("za1")

    if is_shielded:
        _require_shielded()
        await _tx_send_shielded(
            wallet,
            address,
            amount,
            sat=sat,
            fee=fee or 10000,
            yes=yes,
            broadcast=broadcast,
            decode=decode,
            memo=memo,
        )
    else:
        await _tx_send_transparent(
            wallet,
            address,
            amount,
            sat=sat,
            fee=fee,
            yes=yes,
            broadcast=broadcast,
            decode=decode,
            relay=relay,
            timeout=timeout,
        )


async def _tx_send_transparent(
    wallet: str,
    address: str,
    amount: str,
    *,
    sat: bool,
    fee: int | None,
    yes: bool,
    broadcast: bool,
    decode: bool,
    relay: str,
    timeout: int,
) -> None:
    ssp = None
    try:
        amount_sat = int(amount) if sat else value_to_satoshi(amount)

        w = await Wallet.open(wallet)
        amt_str = Value.from_satoshi(amount_sat, network="flux").format_unit()

        if not yes:
            _confirm(f"Send {amt_str} to {address}?")

        if w.multisig and w.ssp_peer_pubkey:

            ssp = await SSPWallet.from_existing(w, relay)
            with console.status("Waiting for SSP Key approval..."):
                txid = await ssp.send([(address, amount_sat)], fee=fee, timeout=timeout)
            output.data({"txid": txid})
            console.print(
                Panel(
                    f"[bold]TxID:[/bold] {txid}",
                    title="Transaction Sent",
                )
            )
        else:
            wt = await w.send([(address, amount_sat)], fee=fee, offline=not broadcast)
            if decode:
                output.data({"raw_hex": wt.tx.raw_hex()})
                _print_decoded_tx(wt)
            elif broadcast:
                output.data({"txid": wt.tx.txid})
                console.print(
                    Panel(
                        f"[bold]TxID:[/bold] {wt.tx.txid}",
                        title="Transaction Sent",
                    )
                )
            else:
                output.data({"raw_hex": wt.tx.raw_hex()})
                console.print(wt.tx.raw_hex())
    except (WalletError, ServiceError, BKeyError, ValueError) as e:
        _handle_error(e)
    finally:
        if ssp:
            await ssp.close()


async def _tx_send_shielded(
    wallet: str,
    address: str,
    amount: str,
    *,
    sat: bool,
    fee: int,
    yes: bool,
    broadcast: bool,
    decode: bool,
    memo: str,
) -> None:

    try:
        amount_sat = int(amount) if sat else value_to_satoshi(amount)

        w = await Wallet.open(wallet)
        sw = await w.open_shielded()

        addr_bytes = bech32_decode(address, prefix="za")
        dest = _SaplingPaymentAddress(addr_bytes)
        amt_str = Value.from_satoshi(amount_sat, network="flux").format_unit()
        if not yes:
            _confirm(f"Send {amt_str} to {address[:20]}...?")

        srv = Service(network="flux")
        chain_height = await srv.blockcount()

        with console.status("Building shielded transaction..."):
            raw_tx = await sw.send(dest, amount_sat, chain_height, fee=fee, memo=memo.encode())

        if decode:
            output.data({"raw_hex": raw_tx.hex()})
            _print_decoded_raw(raw_tx)
        elif broadcast:
            with console.status("Broadcasting..."):
                txid = await _broadcast_raw_tx(raw_tx)
            output.data({"txid": txid})
            console.print(
                Panel(
                    f"[bold]txid:[/bold] {txid}",
                    title="Shielded Transaction Sent",
                )
            )
        else:
            output.data({"raw_hex": raw_tx.hex()})
            console.print(raw_tx.hex())
    except (WalletError, ServiceError, ValueError) as e:
        _handle_error(e)


@tx_app.command("sweep")
@async_command
async def tx_sweep(
    wallet: Annotated[str, typer.Argument(help="Wallet name")],
    address: Annotated[str, typer.Argument(help="Destination address")],
    fee: Annotated[int | None, typer.Option("--fee", help="Fee in satoshis (auto if omitted)")] = None,
    yes: Annotated[bool, typer.Option("--yes", "-y", help="Skip confirmation")] = False,
    broadcast: Annotated[bool, typer.Option("--broadcast", "-b", help="Broadcast transaction")] = False,
    decode: Annotated[bool, typer.Option("--decode", "-d", help="Show decoded transaction")] = False,
) -> None:
    """Sweep all funds to an address, outputs raw hex by default."""
    try:
        w = await Wallet.open(wallet)
        balance = await w.balance(as_string=True)

        if not yes:
            _confirm(f"Sweep {balance} to {address}?")

        wt = await w.sweep(address, fee=fee, offline=not broadcast)
        if decode:
            output.data({"raw_hex": wt.tx.raw_hex()})
            _print_decoded_tx(wt)
        elif broadcast:
            output.data({"txid": wt.tx.txid})
            console.print(
                Panel(
                    f"[bold]TxID:[/bold] {wt.tx.txid}",
                    title="Sweep Sent",
                )
            )
        else:
            output.data({"raw_hex": wt.tx.raw_hex()})
            console.print(wt.tx.raw_hex())
    except (WalletError, Exception) as e:
        _handle_error(e)


@tx_app.command("deshield")
@async_command
async def tx_deshield(
    wallet: Annotated[str, typer.Argument(help="Wallet name")],
    address: Annotated[str, typer.Argument(help="Destination t-address")],
    amount: Annotated[str, typer.Argument(help="Amount in FLUX (e.g. 1.5) or satoshis with --sat")],
    fee: Annotated[int, typer.Option("--fee", help="Fee in satoshis")] = 10000,
    sat: Annotated[bool, typer.Option("--sat", help="Amount is in satoshis")] = False,
    yes: Annotated[bool, typer.Option("--yes", "-y", help="Skip confirmation")] = False,
    broadcast: Annotated[bool, typer.Option("--broadcast", "-b", help="Broadcast transaction")] = False,
    decode: Annotated[bool, typer.Option("--decode", "-d", help="Show decoded transaction")] = False,
) -> None:
    """Create a deshielding transaction (z->t), outputs raw hex by default."""
    _require_shielded()
    try:
        amount_sat = int(amount) if sat else value_to_satoshi(amount)

        w = await Wallet.open(wallet)
        sw = await w.open_shielded()

        amt_str = Value.from_satoshi(amount_sat, network="flux").format_unit()
        if not yes:
            _confirm(f"Deshield {amt_str} to {address}?")

        srv = Service(network="flux")
        chain_height = await srv.blockcount()

        with console.status("Building deshielding transaction..."):
            raw_tx = await sw.deshield(address, amount_sat, chain_height, fee=fee)

        if decode:
            output.data({"raw_hex": raw_tx.hex()})
            _print_decoded_raw(raw_tx)
        elif broadcast:
            with console.status("Broadcasting..."):
                txid = await _broadcast_raw_tx(raw_tx)
            output.data({"txid": txid})
            console.print(
                Panel(
                    f"[bold]txid:[/bold] {txid}",
                    title="Deshielding Transaction Sent",
                )
            )
        else:
            output.data({"raw_hex": raw_tx.hex()})
            console.print(raw_tx.hex())
    except (WalletError, ServiceError, ValueError) as e:
        _handle_error(e)


@tx_app.command("shield")
@async_command
async def tx_shield(
    wallet: Annotated[str, typer.Argument(help="Wallet name")],
    amount: Annotated[str, typer.Argument(help="Amount in FLUX (e.g. 1.5) or satoshis with --sat")],
    fee: Annotated[int, typer.Option("--fee", help="Fee in satoshis")] = 10000,
    sat: Annotated[bool, typer.Option("--sat", help="Amount is in satoshis")] = False,
) -> None:
    """Shield transparent funds (t->z transaction)."""
    output.error("Shielding (t→z) is not supported on the Flux network.")
    console.print(
        "[bold red]Error:[/bold red] Shielding (t→z) is not supported on the Flux network.\n"
        "Flux consensus rules do not allow transparent inputs and shielded outputs in the same transaction."
    )
    raise typer.Exit(1)


@tx_app.command("decode")
@async_command
async def tx_decode(
    raw_hex: Annotated[str, typer.Argument(help="Raw transaction hex")],
) -> None:
    """Decode and display a raw transaction."""

    try:
        tx = FluxTransaction.parse(raw_hex)
        fee_str = Value.from_satoshi(tx.fee or 0, network="flux").format_unit()
        output.data({
            "txid": tx.txid,
            "size": tx.size,
            "fee_sats": tx.fee or 0,
            "fee": fee_str,
            "inputs": [
                {"prev_txid": inp.prev_txid.hex(), "output_n": inp.output_n}
                for inp in tx.inputs
            ],
            "outputs": [
                {
                    "address": out.address,
                    "value_sats": out.value,
                    "value": Value.from_satoshi(out.value, network="flux").format_unit(),
                }
                for out in tx.outputs
            ],
        })
        lines = [
            f"[bold]TxID:[/bold]    {tx.txid}",
            f"[bold]Size:[/bold]    {tx.size} bytes",
            f"[bold]Fee:[/bold]     {fee_str}",
            f"[bold]Inputs:[/bold]  {len(tx.inputs)}",
        ]
        for i, inp in enumerate(tx.inputs):
            lines.append(f"  [{i}] {inp.prev_txid.hex()[:16]}... vout={inp.output_n}")
        lines.append(f"[bold]Outputs:[/bold] {len(tx.outputs)}")
        for i, out in enumerate(tx.outputs):
            out_val = Value.from_satoshi(out.value, network="flux").format_unit()
            lines.append(f"  [{i}] {out.address or '(unknown)'} {out_val}")
        console.print(Panel("\n".join(lines), title="Transaction"))
    except (ValueError, BKeyError) as e:
        _handle_error(e)


@tx_app.command("broadcast")
@async_command
async def tx_broadcast(
    raw_hex: Annotated[str, typer.Argument(help="Raw transaction hex")],
    yes: Annotated[bool, typer.Option("--yes", "-y", help="Skip confirmation")] = False,
) -> None:
    """Broadcast a raw transaction to the network."""
    try:
        if not yes:
            _confirm("Broadcast this transaction?")

        srv = Service(network="flux")
        with console.status("Broadcasting..."):
            result = await srv.sendrawtransaction(raw_hex)
        output.data({"txid": result.txid})
        console.print(
            Panel(
                f"[bold]TxID:[/bold] {result.txid}",
                title="Transaction Broadcast",
            )
        )
    except (ServiceError, ValueError) as e:
        _handle_error(e)


# ---------------------------------------------------------------------------
# multisig helpers & commands
# ---------------------------------------------------------------------------


async def _ssp_pairing_flow(ssp: SSPWallet, *, is_repair: bool) -> None:
    """Run the interactive SSP Key QR scan flow and complete pairing/repair."""
    btc_xpub = ssp.xpub_identity()
    identity = ssp.identity_key()

    console.print(Panel("Scan with SSP Key (BTC identity)", title="Step 1"))
    _print_qr(btc_xpub)
    console.print(f"Manual: btc:{btc_xpub}", soft_wrap=True)

    with console.status("Waiting for SSP Key BTC sync..."):
        await ssp.wait_for_btc_sync()
    console.print("[green]BTC sync received.[/green]")

    flux_xpub = await ssp.pair_with_key()

    console.print(Panel("Switch to Flux in SSP Key, then scan", title="Step 2"))
    _print_qr(flux_xpub)
    console.print(f"Manual: flux:{flux_xpub}", soft_wrap=True)
    console.print(f"Identity: {identity.address()}")

    with console.status("Waiting for SSP Key Flux sync..."):
        await ssp.wait_for_chain_sync()
    console.print("[green]Flux sync received.[/green]")

    if is_repair:
        await ssp.complete_repair()
    else:
        await ssp.complete_pairing()


async def _create_multisig(
    name: str,
    seed_phrase: str,
    relay: str,
    *,
    peer: bool,
    show_mnemonic: bool = False,
    mnemonic_path: Path | None = None,
) -> None:
    """Create a multisig wallet, optionally pairing immediately."""
    ssp = None
    try:
        if await wallet_exists(name):
            _handle_error(WalletError(f"Wallet '{name}' already exists"))

        seed = Mnemonic().to_seed(seed_phrase)
        try:
            master_key = HDKey.from_seed(seed, network="flux")
        finally:
            secure_wipe(seed)

        w = await Wallet.from_multisig(
            name,
            [master_key],
            2,
            network="flux",
            cosigner_id=0,
            key_path=["m", "purpose'", "coin_type'", "account'", "script_type'", "change", "address_index"],
            purpose=48,
            pending=True,
        )

        if show_mnemonic:
            console.print(Panel(seed_phrase, title="Mnemonic", border_style="red"))
        if mnemonic_path:
            console.print(f"[yellow]Mnemonic saved to:[/yellow] {mnemonic_path}")

        if peer:
            ssp = await SSPWallet.pair_existing(w, relay)
            await _ssp_pairing_flow(ssp, is_repair=False)
            key = await w.get_key()
            data: dict[str, object] = {
                "wallet": name,
                "network": "flux",
                "address": key.address,
                "paired": True,
            }
            if mnemonic_path:
                data["mnemonic_file"] = str(mnemonic_path)
            output.data(data)
        else:
            unpaired_data: dict[str, object] = {
                "wallet": name,
                "network": "flux",
                "paired": False,
            }
            if mnemonic_path:
                unpaired_data["mnemonic_file"] = str(mnemonic_path)
            output.data(unpaired_data)
            console.print(
                Panel(
                    f"[bold]Name:[/bold]      {name}\n"
                    f"[bold]Network:[/bold]   flux\n"
                    f"[bold]Multisig:[/bold]  2-of-2 (unpaired)",
                    title="Multisig Wallet Created",
                )
            )
            console.print(f"To pair with SSP Key, run: [bold]fluxwallet multisig pair {name}[/bold]")
    except KeyboardInterrupt:
        console.print("\nPairing cancelled.")
        raise typer.Exit(1) from None
    except (WalletError, ServiceError, BKeyError, ValueError, OSError) as e:
        _handle_error(e)
    finally:
        if ssp:
            await ssp.close()


@multisig_app.command("pair")
@async_command
async def multisig_pair(
    wallet: Annotated[str, typer.Argument(help="Multisig wallet to pair or re-pair")],
    relay: Annotated[str, typer.Option("--relay", help="Relay server URL")] = "relay.sspwallet.io",
) -> None:
    """Pair or re-pair a multisig wallet with SSP Key."""

    ssp = None
    try:
        w = await Wallet.open(wallet)
        if not w.multisig:
            _handle_error(WalletError(
                f"'{wallet}' is not a multisig wallet."
                " Recovery: use 'wallet create --multisig' to create one"
            ))

        if w.ssp_peer_pubkey:
            ssp = await SSPWallet.repair(w, relay)
            await _ssp_pairing_flow(ssp, is_repair=True)
            output.data({"wallet": wallet, "paired": True})
            console.print(Panel(f"Re-pairing complete for: {wallet}", title="Done"))
        else:
            ssp = await SSPWallet.pair_existing(w, relay)
            await _ssp_pairing_flow(ssp, is_repair=False)
            key = await w.get_key()
            output.data({"wallet": wallet, "address": key.address, "paired": True})
            console.print(
                Panel(
                    f"[bold]Wallet:[/bold]  {wallet}\n[bold]Address:[/bold] {key.address}",
                    title="Multisig Wallet Paired",
                )
            )
    except KeyboardInterrupt:
        console.print("\nPairing cancelled.")
        raise typer.Exit(1) from None
    except (WalletError, ServiceError, BKeyError, ValueError, OSError) as e:
        _handle_error(e)
    finally:
        if ssp:
            await ssp.close()


@multisig_app.command("pair-start")
@async_command
async def multisig_pair_start(
    wallet: Annotated[str, typer.Argument(help="Multisig wallet to pair")],
    relay: Annotated[str, typer.Option("--relay", help="Relay server URL")] = "relay.sspwallet.io",
) -> None:
    """Output pairing data for automation. Use pair-complete to finalize."""
    try:
        w = await Wallet.open(wallet)
        if not w.multisig:
            _handle_error(WalletError(
                f"'{wallet}' is not a multisig wallet."
                " Recovery: use 'wallet create --multisig' to create one"
            ))
        if w.ssp_peer_pubkey:
            _handle_error(WalletError("Already paired. Use 'multisig pair' to re-pair."))

        ssp = await SSPWallet.pair_existing(w, relay)
        try:
            btc_xpub = ssp.xpub_identity()
            flux_xpub = ssp.xpub()
            identity = ssp.identity_key()

            output.data({
                "wallet": wallet,
                "btc_xpub": btc_xpub,
                "flux_xpub": flux_xpub,
                "identity": identity.address(),
            })
            console.print(Panel("BTC Identity xpub — scan with SSP Key", title="Step 1"))
            _print_qr(btc_xpub)
            console.print(f"Manual: btc:{btc_xpub}", soft_wrap=True)
            console.print(Panel("Flux chain xpub — switch to Flux in SSP Key, then scan", title="Step 2"))
            _print_qr(flux_xpub)
            console.print(f"Manual: flux:{flux_xpub}", soft_wrap=True)
            console.print(f"Identity: {identity.address()}")
            console.print(f"\nRun [bold]fluxwallet multisig pair-complete {wallet}[/bold] to finalize.")
        finally:
            await ssp.close()
    except (WalletError, ServiceError, BKeyError, ValueError, OSError) as e:
        _handle_error(e)


@multisig_app.command("pair-complete")
@async_command
async def multisig_pair_complete(
    wallet: Annotated[str, typer.Argument(help="Multisig wallet to complete pairing")],
    relay: Annotated[str, typer.Option("--relay", help="Relay server URL")] = "relay.sspwallet.io",
    timeout: Annotated[int, typer.Option("--timeout", help="Seconds to wait for SSP Key")] = 300,
) -> None:
    """Wait for SSP Key response and complete pairing."""
    try:
        w = await Wallet.open(wallet)
        if not w.multisig:
            _handle_error(WalletError(
                f"'{wallet}' is not a multisig wallet."
                " Recovery: use 'wallet create --multisig' to create one"
            ))
        if w.ssp_peer_pubkey:
            _handle_error(WalletError("Already paired. Use 'multisig pair' to re-pair."))

        ssp = await SSPWallet.pair_existing(w, relay)
        try:
            with console.status("Waiting for SSP Key BTC sync..."):
                await ssp.wait_for_btc_sync(timeout=timeout)
            console.print("[green]BTC sync received.[/green]")

            with console.status("Waiting for SSP Key Flux sync..."):
                await ssp.wait_for_chain_sync(timeout=timeout)
            console.print("[green]Flux sync received.[/green]")

            await ssp.complete_pairing()
            key = await w.get_key()

            output.data({"wallet": wallet, "address": key.address, "paired": True})
            console.print(
                Panel(
                    f"[bold]Wallet:[/bold]  {wallet}\n[bold]Address:[/bold] {key.address}",
                    title="Multisig Wallet Paired",
                )
            )
        finally:
            await ssp.close()
    except KeyboardInterrupt:
        console.print("\nPairing cancelled.")
        raise typer.Exit(1) from None
    except (WalletError, ServiceError, BKeyError, ValueError, OSError) as e:
        _handle_error(e)


@multisig_app.command("info")
@async_command
async def multisig_info(
    wallet: Annotated[str, typer.Argument(help="Wallet name")],
) -> None:
    """Show multisig wallet identity info."""
    try:
        w = await Wallet.open(wallet)

        info = (
            f"[bold]Name:[/bold]      {w.name}\n"
            f"[bold]Multisig:[/bold]  {w.multisig}\n"
            f"[bold]Network:[/bold]   {w.network.name}"
        )

        if w.ssp_peer_pubkey:

            private_cosigner = None
            for cs in w.cosigner:
                if cs.main_key and cs.main_key.is_private:
                    private_cosigner = cs
                    break

            if private_cosigner and private_cosigner.main_key is not None:
                mk = private_cosigner.main_key
                if is_wallet_key(mk):
                    mk_result = mk.key()
                    if mk_result is not None:
                        master_key = mk_result
                elif is_hdkey(mk):
                    master_key = mk
                else:
                    master_key = None
                if master_key is not None:
                    wk_identity, witness_script, our_pubkey = _derive_relay_auth(
                        master_key,
                        w.ssp_peer_pubkey,
                    )
                    info += (
                        f"\n[bold]Paired:[/bold]    yes"
                        f"\n[bold]wkIdentity:[/bold]{wk_identity}"
                        f"\n[bold]Our pubkey:[/bold]{our_pubkey[:16]}..."
                        f"\n[bold]Peer pubkey:[/bold]{w.ssp_peer_pubkey[:16]}..."
                    )
                    output.data({
                        "name": w.name,
                        "multisig": w.multisig,
                        "network": w.network.name,
                        "paired": True,
                        "wk_identity": wk_identity,
                        "our_pubkey": our_pubkey,
                        "peer_pubkey": w.ssp_peer_pubkey,
                    })
        else:
            info += "\n[bold]Paired:[/bold]    no"
            output.data({"name": w.name, "multisig": w.multisig, "network": w.network.name, "paired": False})

        console.print(Panel(info, title=f"Multisig — {w.name}"))
    except (WalletError, ServiceError) as e:
        _handle_error(e)


# ---------------------------------------------------------------------------
# db commands
# ---------------------------------------------------------------------------


@db_app.command("info")
@async_command
async def db_info() -> None:
    """Show wallet file info."""
    wallet_path = str(DEFAULT_WALLET_FILE)
    exists = Path(wallet_path).exists()
    encrypted = is_wallet_file(wallet_path) if exists else False
    info = (
        f"[bold]Path:[/bold]      {wallet_path}\n"
        f"[bold]Exists:[/bold]    {'yes' if exists else 'no'}\n"
        f"[bold]Encrypted:[/bold] {'yes' if encrypted else 'n/a'}"
    )
    output.data({"path": wallet_path, "exists": exists, "encrypted": encrypted})
    console.print(Panel(info, title="Wallet File"))


@db_app.command("export-key")
@async_command
async def db_export_key() -> None:
    """Export the master encryption key for use with --key-file or stdin."""

    wallet_path = str(DEFAULT_WALLET_FILE)
    if not Path(wallet_path).exists():
        console.print("No wallet file found.")
        raise typer.Exit(1)

    _confirm("This will display your master encryption key. Anyone with this key can decrypt your wallet.")

    password = _json_prompt("Wallet password", hide_input=True)
    try:
        mk = unwrap_master_key(wallet_path, password)
        output.data({"master_key": mk.hex()})
        console.print(Panel(mk.hex(), title="Master Key", border_style="red"))
    except (ValueError, OSError):
        _handle_error(Exception(
            "Wrong password or corrupted wallet file."
            " Recovery: check caps lock, or try --key-file"
        ))


@db_app.command("change-password")
@async_command
async def db_change_password() -> None:
    """Change the wallet file encryption password."""
    wallet_path = str(DEFAULT_WALLET_FILE)
    if not Path(wallet_path).exists():
        console.print("No wallet file found. Create a wallet first.")
        return

    old_password = _json_prompt("Current password", hide_input=True)
    new_password = _json_prompt("New password", hide_input=True)
    confirm = _json_prompt("Confirm new password", hide_input=True)
    if new_password != confirm:
        _handle_error(Exception("Passwords do not match"))

    try:
        _change_wallet_password(wallet_path, old_password, new_password)
        output.data({"changed": True})
        console.print("[green]Password changed.[/green]")
    except (ValueError, OSError) as e:
        _handle_error(e)


@db_app.command("migrate")
@async_command
async def db_migrate(
    source: Annotated[str, typer.Option("--from", help="Path to legacy SQLite database")],
    password: Annotated[
        str | None,
        typer.Option("--password", "-p", help="Password for new wallet file"),
    ] = None,
) -> None:
    """Migrate a legacy SQLite wallet database to the new encrypted format."""

    if not Path(source).exists():
        _handle_error(Exception(f"Source file not found: {source}"))

    if not password:
        password = _json_prompt("Choose a password for the new wallet file", hide_input=True)
        confirm = _json_prompt("Confirm password", hide_input=True)
        if password != confirm:
            _handle_error(Exception("Passwords do not match"))

    wallet_path = str(DEFAULT_WALLET_FILE)
    if Path(wallet_path).exists():
        _handle_error(Exception(f"Wallet file already exists at {wallet_path}. Remove it first."))

    store = migrate_sqlite_to_store(source)
    mk = store.save(password, path=wallet_path)


    stored = store_key_in_keyring(mk.hex())

    output.data({
        "wallets": len(store.wallets),
        "keys": len(store.keys),
        "transactions": len(store.transactions),
        "path": wallet_path,
        "keychain": stored,
    })
    console.print(
        f"[green]Migrated {len(store.wallets)} wallets, {len(store.keys)} keys, "
        f"{len(store.transactions)} transactions[/green]"
    )
    console.print(f"Saved to: {wallet_path}")
    if stored:
        console.print("[green]Master key stored in OS keychain.[/green]")
    else:
        console.print("[yellow]No keychain available — you'll need your password to unlock.[/yellow]")


# ---------------------------------------------------------------------------
# Sapling type injection (same pattern as wallet/key_manager.py)
# ---------------------------------------------------------------------------

if SHIELDED_AVAILABLE:
    from fluxwallet.sapling.keys import SaplingPaymentAddress as _SaplingPaymentAddress
else:

    def _SaplingPaymentAddress(_addr_bytes: bytes):  # type: ignore[misc]
        raise RuntimeError("fluxwallet-sapling is not installed")
