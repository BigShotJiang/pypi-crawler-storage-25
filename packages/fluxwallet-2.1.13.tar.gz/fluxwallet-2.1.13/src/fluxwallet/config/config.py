from __future__ import annotations

import configparser
import locale
import os
import platform
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from shutil import copyfile

# ---------------------------------------------------------------------------
# Constants (never change at runtime)
# ---------------------------------------------------------------------------

TYPE_TEXT: type = str
TYPE_INT: type = int

SCRIPT_TYPES_LOCKING: dict[str, list[str]] = {
    "p2pkh": ["OP_DUP", "OP_HASH160", "hash-20", "OP_EQUALVERIFY", "OP_CHECKSIG"],
    "p2sh": ["OP_HASH160", "hash-20", "OP_EQUAL"],
    "p2wpkh": ["OP_0", "hash-20"],
    "p2wsh": ["OP_0", "hash-32"],
    "p2tr": ["op_n", "hash-32"],
    "multisig": ["op_m", "multisig", "op_n", "OP_CHECKMULTISIG"],
    "p2pk": ["public_key", "OP_CHECKSIG"],
    "nulldata": ["OP_RETURN", "return_data"],
}

SCRIPT_TYPES_UNLOCKING: dict[str, list[str]] = {
    "sig_pubkey": ["signature", "SIGHASH_ALL", "public_key"],
    "p2sh_multisig": ["OP_0", "multisig", "redeemscript"],
    "p2sh_p2wpkh": ["OP_0", "OP_HASH160", "redeemscript", "OP_EQUAL"],
    "p2sh_p2wsh": ["OP_0", "push_size", "redeemscript"],
    "locktime_cltv": ["locktime_cltv", "OP_CHECKLOCKTIMEVERIFY", "OP_DROP"],
    "signature": ["signature"],
}

SIGHASH_ALL: int = 1
SIGHASH_NONE: int = 2
SIGHASH_SINGLE: int = 3
SIGHASH_ANYONECANPAY: int = 80

SEQUENCE_LOCKTIME_DISABLE_FLAG: int = 1 << 31
SEQUENCE_LOCKTIME_TYPE_FLAG: int = 1 << 22
SEQUENCE_LOCKTIME_GRANULARITY: int = 9
SEQUENCE_LOCKTIME_MASK: int = 0x0000FFFF
SEQUENCE_ENABLE_LOCKTIME: int = 0xFFFFFFFE
SEQUENCE_REPLACE_BY_FEE: int = 0xFFFFFFFD

SIGNATURE_VERSION_STANDARD: int = 0

# BIP39 PBKDF2 iterations for mnemonic-to-seed derivation
BIP39_PBKDF2_ITERATIONS: int = 2048

# BIP68 relative locktime granularity (seconds per unit)
BIP68_LOCKTIME_GRANULARITY_SECONDS: int = 512

# Relay / SSP timeouts
RELAY_HTTP_TIMEOUT: int = 30
RELAY_WAIT_TIMEOUT: float = 300

# LMDB cache map size
LMDB_DEFAULT_MAP_SIZE: int = 100 * 1024 * 1024

# Log file max size
LOG_FILE_MAX_BYTES: int = 100 * 1024 * 1024

# Service batch sizes
UTXO_BATCH_SIZE: int = 50

SUPPORTED_ADDRESS_ENCODINGS: list[str] = ["base58"]

NETWORK_DENOMINATORS: dict[float | int, str] = {
    0.00000000000001: "µsat",
    0.00000000001: "msat",
    0.000000001: "n",
    0.00000001: "sat",
    0.0000001: "fin",
    0.000001: "µ",
    0.001: "m",
    0.01: "c",
    0.1: "d",
    1: "",
    10: "da",
    100: "h",
    1000: "k",
    1000000: "M",
    1000000000: "G",
    1000000000000: "T",
    1000000000000000: "P",
    1000000000000000000: "E",
    1000000000000000000000: "Z",
    1000000000000000000000000: "Y",
}

WALLET_KEY_STRUCTURES: list[dict[str, int | str | bool | None | list[str]]] = [
    {
        "purpose": None,
        "script_type": "p2pkh",
        "witness_type": "legacy",
        "multisig": False,
        "encoding": "base58",
        "description": "Single key wallet with no hierarchical deterministic key structure",
        "key_path": ["m"],
    },
    {
        "purpose": 44,
        "script_type": "p2pkh",
        "witness_type": "legacy",
        "multisig": False,
        "encoding": "base58",
        "description": "Legacy wallet using pay-to-public-key-hash scripts",
        "key_path": [
            "m",
            "purpose'",
            "coin_type'",
            "account'",
            "change",
            "address_index",
        ],
    },
    {
        "purpose": 45,
        "script_type": "p2sh",
        "witness_type": "legacy",
        "multisig": True,
        "encoding": "base58",
        "description": "Legacy multisig wallet using pay-to-script-hash scripts",
        "key_path": ["m", "purpose'", "cosigner_index", "change", "address_index"],
    },
]

FW_INSTALL_DIR: Path = Path(__file__).parents[1]

if os.name == "nt" and locale.getpreferredencoding() != "UTF-8":
    import _locale

    _locale._getdefaultlocale = lambda *args: ["en_US", "utf8"]
elif locale.getpreferredencoding() != "UTF-8":
    raise OSError(
        f"Locale is currently set to '{locale.getpreferredencoding()}'. "
        "This library needs the locale set to UTF-8 to function properly"
    )


# ---------------------------------------------------------------------------
# Mutable config (loaded from config.ini)
# ---------------------------------------------------------------------------


@dataclass
class _Config:
    # Paths
    config_file: Path = Path("~/.fluxwallet/config.ini")
    data_dir: Path = Path("~/.fluxwallet")
    wallet_dir: Path = Path("~/.fluxwallet/wallets")
    wallet_file: Path = Path("~/.fluxwallet/wallets/fluxwallet.fxwl")
    cache_dir: Path = Path("~/.fluxwallet/wallets/cache")
    log_file: Path = Path("~/.fluxwallet/fluxwallet.log")

    # Logging
    enable_logging: bool = True
    loglevel: str = "WARNING"

    # Services
    timeout_requests: int = 5
    max_transactions: int = 20000
    block_count_cache_time: int = 3
    service_max_errors: int = 3
    service_caching_enabled: bool = True

    # Defaults
    default_language: str = "english"
    default_network: str = "flux"
    default_witness_type: str = "legacy"

    # TPM
    tpm_auth_file: str = ""

    # Testing
    unittests_full_database_test: bool = False

    # Version (set after init)
    version: str = ""


_cfg: _Config = _Config()


def _config_get(
    config: configparser.ConfigParser,
    section: str,
    var: str,
    fallback: str | bool | int,
    is_boolean: bool = False,
) -> str | bool | int:
    try:
        if is_boolean:
            return config.getboolean(section, var, fallback=fallback)
        return config.get(section, var, fallback=fallback)
    except (configparser.Error, ValueError):
        return fallback


def read_config() -> bool:
    config: configparser.ConfigParser = configparser.ConfigParser()

    config_file_name: str | None = os.environ.get("FW_CONFIG_FILE")
    if not config_file_name:
        _cfg.config_file = Path("~/.fluxwallet/config.ini").expanduser()
    else:
        _cfg.config_file = Path(config_file_name)
        if not _cfg.config_file.is_absolute():
            _cfg.config_file = Path(Path.home(), ".fluxwallet", _cfg.config_file)
        if not _cfg.config_file.exists():
            _cfg.config_file = Path(FW_INSTALL_DIR, "data", config_file_name)
        if not _cfg.config_file.exists():
            raise OSError(f"fluxwallet configuration file not found: {str(_cfg.config_file)}")

    data: list[str] = config.read(str(_cfg.config_file))

    _cfg.data_dir = Path(str(_config_get(config, "locations", "data_dir", fallback="~/.fluxwallet"))).expanduser()

    _cfg.wallet_dir = Path(
        _cfg.data_dir,
        str(_config_get(config, "locations", "wallet_dir", fallback="wallets")),
    )
    _cfg.wallet_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
    _cfg.wallet_file = _cfg.wallet_dir / "fluxwallet.fxwl"
    _cfg.cache_dir = _cfg.wallet_dir / "cache"

    _cfg.service_caching_enabled = bool(
        _config_get(config, "common", "service_caching_enabled", fallback=True, is_boolean=True)
    )

    _cfg.enable_logging = bool(_config_get(config, "logs", "enable_fluxwallet_logging", fallback=True, is_boolean=True))
    _cfg.log_file = Path(
        _cfg.data_dir,
        str(_config_get(config, "logs", "log_file", fallback="fluxwallet.log")),
    )
    _cfg.log_file.parent.mkdir(parents=True, exist_ok=True)
    if _cfg.log_file.exists() and os.name != "nt":
        os.chmod(_cfg.log_file, 0o600)
    _cfg.loglevel = str(_config_get(config, "logs", "loglevel", fallback="WARNING"))

    _cfg.timeout_requests = int(_config_get(config, "common", "timeout_requests", fallback=_cfg.timeout_requests))
    _cfg.service_max_errors = int(_config_get(config, "common", "service_max_errors", fallback=_cfg.service_max_errors))
    _cfg.max_transactions = int(_config_get(config, "common", "max_transactions", fallback=_cfg.max_transactions))
    _cfg.block_count_cache_time = int(
        _config_get(
            config,
            "common",
            "block_count_cache_time",
            fallback=_cfg.block_count_cache_time,
        )
    )

    _cfg.default_language = str(_config_get(config, "common", "default_language", fallback=_cfg.default_language))
    _cfg.default_network = str(_config_get(config, "common", "default_network", fallback=_cfg.default_network))
    _cfg.default_witness_type = str(
        _config_get(config, "common", "default_witness_type", fallback=_cfg.default_witness_type)
    )
    _cfg.tpm_auth_file = str(_config_get(config, "common", "tpm_auth_file", fallback=_cfg.tpm_auth_file))
    if not _cfg.tpm_auth_file:
        default_tpm_path = _cfg.data_dir / "tpm-auth-secret"
        if default_tpm_path.exists():
            _cfg.tpm_auth_file = str(default_tpm_path)

    full_db_test: str | None = os.environ.get("UNITTESTS_FULL_DATABASE_TEST")
    if full_db_test and full_db_test in [1, True, "True", "true", "TRUE"]:
        _cfg.unittests_full_database_test = True

    return bool(data)


def initialize_lib() -> None:
    for file in Path(FW_INSTALL_DIR, "data").iterdir():
        if file.suffix == ".json":
            target: Path = Path(_cfg.data_dir, file.name)
            copyfile(str(file), target)

    instlogfile: Path = Path(_cfg.data_dir, "install.log")
    if instlogfile.exists():
        return

    with instlogfile.open("w") as f:
        f.write(
            "fluxwallet installed, check further logs in fluxwallet.log\n\n"
            "Installation parameters:\n"
            f"fluxwallet version: {_cfg.version}\n"
            f"Installation date : {datetime.now().isoformat()}\n"
            f"Python            : {platform.python_version()}\n"
            f"Platform          : {platform.platform()}\n"
        )

    for file in Path(FW_INSTALL_DIR, "data").iterdir():
        if file.suffix == ".ini":
            target = Path(_cfg.data_dir, file.name)
            if not target.exists():
                copyfile(str(file), target)


# ---------------------------------------------------------------------------
# Backwards-compatible module-level names
# These read from _cfg so they stay in sync after read_config()
# ---------------------------------------------------------------------------

# We define these as module-level attributes via __getattr__ so that
# `from fluxwallet.config import DEFAULT_WALLET_FILE` works and always
# returns the current _cfg value (not a stale copy from import time).

_ATTR_MAP: dict[str, str] = {
    "FW_CONFIG_FILE": "config_file",
    "FW_DATA_DIR": "data_dir",
    "FW_WALLET_DIR": "wallet_dir",
    "DEFAULT_WALLET_FILE": "wallet_file",
    "DEFAULT_CACHE_DIR": "cache_dir",
    "FW_LOG_FILE": "log_file",
    "ENABLE_LOGGING": "enable_logging",
    "LOGLEVEL": "loglevel",
    "TIMEOUT_REQUESTS": "timeout_requests",
    "MAX_TRANSACTIONS": "max_transactions",
    "BLOCK_COUNT_CACHE_TIME": "block_count_cache_time",
    "SERVICE_MAX_ERRORS": "service_max_errors",
    "SERVICE_CACHING_ENABLED": "service_caching_enabled",
    "DEFAULT_LANGUAGE": "default_language",
    "DEFAULT_NETWORK": "default_network",
    "DEFAULT_WITNESS_TYPE": "default_witness_type",
    "UNITTESTS_FULL_DATABASE_TEST": "unittests_full_database_test",
    "FLUXWALLET_VERSION": "version",
    "TPM_AUTH_FILE": "tpm_auth_file",
}


def __getattr__(name: str) -> Path | bool | str | int:
    if name in _ATTR_MAP:
        return getattr(_cfg, _ATTR_MAP[name])
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


# Initialize on import
read_config()

from importlib.metadata import version as _pkg_version

_cfg.version = _pkg_version("fluxwallet")

initialize_lib()
