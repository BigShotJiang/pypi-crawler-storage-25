"""Transaction creation, sending, and shielded-tx methods extracted from Wallet.

WalletTransactionManager receives a ``wallet`` reference and delegates shared state
access through ``self._wallet.*``.
"""

from __future__ import annotations

import logging
import secrets
from pathlib import Path
from typing import TYPE_CHECKING

import msgpack

from fluxwallet.config import FW_DATA_DIR
from fluxwallet.encoding import (
    addr_base58_to_pubkeyhash,
    to_bytes,
    to_hexstring,
    varstr,
)
from fluxwallet.keys import (
    Address,
    HDKey,
    Key,
)
from fluxwallet.networks import Network
from fluxwallet.services.core import Service, provider_url_for_capability
from fluxwallet.transactions import (
    FluxTransaction,
    Input,
    Output,
    TransactionMixin,
    get_unlocking_script_type,
)
from fluxwallet.values import Value, value_to_satoshi
from fluxwallet.wallet.errors import WalletError
from fluxwallet.wallet.key_manager import _KeyType
from fluxwallet.wallet.store_access import _get_store, _save_store
from fluxwallet.wallet.wallet_key import WalletKey
from fluxwallet.wallet.wallet_transaction import WalletTransaction
from fluxwallet.wallet_store import StoredKey, StoredTxOutput

if TYPE_CHECKING:
    from fluxwallet.keys import Signature
    from fluxwallet.sapling.wallet import ShieldedWallet
    from fluxwallet.wallet.core import Wallet

_logger = logging.getLogger(__name__)


class TransactionBuilder:
    """Fluent builder for constructing and sending wallet transactions.

    Usage::

        wt = await (
            wallet.build_transaction()
            .to("t1abc...", 50000)
            .to("t1def...", 30000)
            .fee(10000)
            .offline()
            .send()
        )

    All parameters can also be passed at construction::

        wt = await wallet.build_transaction(
            outputs=[("t1abc...", 50000)],
            fee=10000,
        ).send()
    """

    def __init__(
        self,
        tx_mgr: WalletTransactionManager,
        *,
        outputs: list[tuple[str, int]] | None = None,
        inputs: list[tuple[str, int, int, int]] | list[Input] | None = None,
        input_key_id: int | list[int] | None = None,
        account_id: int | None = None,
        network: str | None = None,
        fee: int | None = None,
        min_confirms: int = 1,
        priv_keys: HDKey | list[HDKey] | list[HDKey | str] | None = None,
        max_utxos: int | None = None,
        locktime: int = 0,
        offline: bool = True,
        number_of_change_outputs: int = 1,
        message: str | bytes = "",
    ) -> None:
        self._tx_mgr = tx_mgr
        self._outputs: list[tuple[str | Address | HDKey | WalletKey, int]] = list(outputs) if outputs else []
        self._inputs = inputs
        self._input_key_id = input_key_id
        self._account_id = account_id
        self._network = network
        self._fee = fee
        self._min_confirms = min_confirms
        self._priv_keys = priv_keys
        self._max_utxos = max_utxos
        self._locktime = locktime
        self._offline = offline
        self._change_outputs = number_of_change_outputs
        self._message = message

    def to(self, address: str | Address | HDKey | WalletKey, amount: int) -> TransactionBuilder:
        """Add an output destination."""
        self._outputs.append((address, amount))
        return self

    def from_inputs(self, inputs: list[tuple[str, int, int, int]] | list[Input]) -> TransactionBuilder:
        """Specify explicit inputs."""
        self._inputs = inputs
        return self

    def fee(self, fee: int) -> TransactionBuilder:
        """Set the transaction fee in satoshis."""
        self._fee = fee
        return self

    def min_confirms(self, n: int) -> TransactionBuilder:
        """Set minimum confirmations for UTXO selection."""
        self._min_confirms = n
        return self

    def max_utxos(self, n: int) -> TransactionBuilder:
        """Limit the number of UTXOs used as inputs."""
        self._max_utxos = n
        return self

    def locktime(self, locktime: int) -> TransactionBuilder:
        """Set the transaction locktime."""
        self._locktime = locktime
        return self

    def offline(self, offline: bool = True) -> TransactionBuilder:
        """Set offline mode (don't broadcast)."""
        self._offline = offline
        return self

    def change_outputs(self, n: int) -> TransactionBuilder:
        """Set the number of change outputs."""
        self._change_outputs = n
        return self

    def message(self, msg: str | bytes) -> TransactionBuilder:
        """Attach an OP_RETURN message."""
        self._message = msg
        return self

    def sign_with(self, priv_keys: HDKey | list[HDKey] | list[HDKey | str]) -> TransactionBuilder:
        """Provide private keys for signing."""
        self._priv_keys = priv_keys
        return self

    def account(self, account_id: int) -> TransactionBuilder:
        """Set the account ID."""
        self._account_id = account_id
        return self

    def network(self, network: str) -> TransactionBuilder:
        """Set the network."""
        self._network = network
        return self

    async def send(self) -> WalletTransaction:
        """Build, sign, and send the transaction."""
        if not self._outputs and not self._message:
            raise WalletError("No outputs specified — use .to(address, amount) or .message(data)")
        return await self._tx_mgr.send(
            self._outputs,
            self._inputs,
            self._input_key_id,
            self._account_id,
            self._network,
            self._fee,
            self._min_confirms,
            self._priv_keys,
            self._max_utxos,
            self._locktime,
            self._offline,
            self._change_outputs,
            self._message,
        )


def _narrow_dict(d: object) -> dict[str, object]:
    """Safely narrow an untyped dict to dict[str, object]."""
    if not isinstance(d, dict):
        return {}
    return {str(k): v for k, v in d.items()}


class WalletTransactionManager:
    """Manages transaction creation, sending, and shielded operations for a Wallet."""

    def __init__(self, wallet: Wallet) -> None:
        self._wallet = wallet

    def build_transaction(self, **kwargs: object) -> TransactionBuilder:
        """Return a TransactionBuilder for fluent transaction construction."""
        return TransactionBuilder(self, **kwargs)  # type: ignore[arg-type]

    async def _objects_by_key_id(
        self, key_id: int,
    ) -> tuple[list[HDKey | Key | bytes | str], StoredKey]:
        store = await _get_store()
        key = store.get_key(key_id=key_id)

        if not key:
            raise WalletError(f"Key '{key_id}' not found in this wallet")
        inp_keys: list[HDKey | Key | bytes | str] = []
        if key.key_type == "multisig":
            for child_id, _child_order in key.multisig_children:
                child_key = store.get_key(key_id=child_id)
                if child_key and child_key.wif:
                    inp_keys.append(HDKey.from_wif(child_key.wif, network=child_key.network_name))
        elif key.key_type in ["bip32", "single"]:
            if not key.wif:
                raise WalletError("WIF of key is empty cannot create HDKey")
            inp_keys = [HDKey.from_wif(key.wif, network=key.network_name)]
        else:
            raise WalletError(f"Input key type {key.key_type} not supported")
        return inp_keys, key

    async def select_inputs(
        self,
        amount: int,
        variance: int | None = None,
        input_key_id: int | list[int] | None = None,
        account_id: int | None = None,
        network: str | None = None,
        min_confirms: int = 1,
        max_utxos: int | None = None,
        return_input_obj: bool = True,
        skip_dust_amounts: bool = True,
    ) -> list[Input] | list[StoredTxOutput]:
        """Select available UTXO's which can be used as inputs for a transaction."""

        network, account_id, _ = await self._wallet._get_account_defaults(network, account_id)
        dust_amount = Network(network).dust_amount

        if variance is None:
            variance = dust_amount

        store = await _get_store()
        txs = store.get_transactions(
            wallet_id=self._wallet.wallet_id,
            account_id=account_id,
            network_name=network,
            min_confirmations=min_confirms,
        )

        utxos = []
        for tx in txs:
            for out in tx.outputs:
                if out.spent:
                    continue
                if out.key_id is None:
                    continue
                k = store.get_key(key_id=out.key_id)
                if not k or not k.public or k.public == b"":
                    continue
                if input_key_id and (
                    isinstance(input_key_id, int)
                    and k.id != input_key_id
                    or isinstance(input_key_id, list)
                    and k.id not in input_key_id
                ):
                    continue
                if skip_dust_amounts and out.value <= dust_amount:
                    continue
                utxos.append((tx, out, k))

        # Sort by confirmations descending
        utxos.sort(key=lambda x: x[0].confirmations, reverse=True)

        if not utxos:
            raise WalletError(
                "Create transaction: No unspent transaction outputs found"
                " or no key available for UTXO's."
                " Recovery: run 'fluxwallet wallet scan' to sync"
            )

        # Try to find one utxo with exact amount
        selected_utxos = []
        for tx, out, k in utxos:
            if amount <= out.value <= amount + variance:
                selected_utxos = [(tx, out, k)]
                break

        if not selected_utxos:
            # Try to find one utxo with higher amount
            higher = [(tx, out, k) for tx, out, k in utxos if out.value >= amount]
            if higher:
                higher.sort(key=lambda x: x[1].value)
                selected_utxos = [higher[0]]
            elif max_utxos and max_utxos <= 1:
                _logger.info(
                    "No single UTXO found with requested amount, use higher 'max_utxo' setting to use multiple UTXO's"
                )
                return []

        # Otherwise compose of 2 or more lesser outputs
        if not selected_utxos:
            lessers = [(tx, out, k) for tx, out, k in utxos if out.value < amount]
            lessers.sort(key=lambda x: x[1].value, reverse=True)

            total_amount = 0
            selected_utxos = []
            for item in lessers[:max_utxos]:
                if total_amount < amount:
                    selected_utxos.append(item)
                    total_amount += item[1].value
            if total_amount < amount:
                return []

        if not return_input_obj:
            return [out for _, out, _ in selected_utxos]
        inputs = []
        for tx, utxo_out, _utxo_key in selected_utxos:
            inp_keys, key = await self._objects_by_key_id(utxo_out.key_id)
            multisig = not len(inp_keys) < 2
            script_type = get_unlocking_script_type(utxo_out.script_type, multisig=multisig)
            inputs.append(
                Input(
                    tx.txid,
                    utxo_out.output_n,
                    keys=inp_keys,
                    script_type=script_type,
                    sigs_required=self._wallet.multisig_n_required,
                    sort=self._wallet.sort_keys,
                    address=key.address,
                    compressed=key.compressed,
                    value=utxo_out.value,
                    network=key.network_name,
                )
            )
        return inputs

    async def transaction_create(
        self,
        outputs: list[Output] | list[tuple[str, int]] | list[tuple[str | Address | HDKey | WalletKey, int]],
        inputs: list[Input] | list[tuple[str, int, int, int]] | None = None,
        input_key_id: int | list[int] | None = None,
        account_id: int | None = None,
        network: str | None = None,
        fee: int | str | None = None,
        min_confirms: int = 1,
        max_utxos: int | None = None,
        locktime: int = 0,
        number_of_change_outputs: int = 1,
        random_output_order: bool = True,
        message: str | bytes = "",
    ) -> WalletTransaction:
        """Create new transaction with specified outputs."""

        if not isinstance(outputs, list):
            raise WalletError(
                "Output array must be a list of tuples with address and amount. "
                "Use 'send_to' method to send to one address"
            )
        if not network and outputs:
            if isinstance(outputs[0], Output):
                network = outputs[0].network.name
            elif isinstance(outputs[0][1], str):
                network = Value(outputs[0][1]).network.name
        network, account_id, _ = await self._wallet._get_account_defaults(network, account_id)

        if inputs and max_utxos and len(inputs) > max_utxos:
            raise WalletError(
                f"Input array contains {len(inputs)} UTXO's but max_utxos={max_utxos} parameter specified"
            )

        srv = Service(
            network=network,
            providers=self._wallet.providers,
            cache_uri=self._wallet.db_cache_uri,
        )
        expiry_height = await srv.blockcount() + 21

        amount_total_output = 0

        tx = FluxTransaction(
            network=network,
            locktime=locktime,
            expiry_height=expiry_height,
        )

        for o in outputs:
            if isinstance(o, Output):
                tx.outputs.append(o)
                amount_total_output += o.value
            else:
                value = value_to_satoshi(o[1], network=tx.network)
                amount_total_output += value
                addr = o[0]
                if isinstance(addr, WalletKey):
                    addr = addr.address
                tx.add_output(value, str(addr) if not isinstance(addr, Address) else addr)

        tx.fee_per_kb = None
        if isinstance(fee, int):
            fee_estimate = fee
        else:
            n_blocks = 3
            priority = ""
            if isinstance(fee, str):
                priority = fee
            tx.fee_per_kb = await srv.estimatefee(blocks=n_blocks, priority=priority)
            if not inputs:
                fee_estimate = (
                    tx.estimate_size(number_of_change_outputs=number_of_change_outputs) * tx.fee_per_kb
                ) // 1000
            else:
                fee_estimate = 0
            if isinstance(fee, str):
                fee = fee_estimate

        # Add inputs
        sequence = 0xFFFFFFFF
        if 0 < tx.locktime < 0xFFFFFFFF:
            sequence = 0xFFFFFFFE
        amount_total_input = 0

        if inputs is None:
            selected_raw = await self.select_inputs(
                amount_total_output + fee_estimate,
                tx.network.dust_amount,
                input_key_id,
                account_id,
                network,
                min_confirms,
                max_utxos,
                False,
            )

            if not selected_raw:
                raise WalletError(
                    "Not enough unspent transaction outputs found."
                    " Recovery: run 'fluxwallet wallet scan' to sync"
                )
            selected_utxos: list[StoredTxOutput] = [u for u in selected_raw if isinstance(u, StoredTxOutput)]

            store = await _get_store()
            for utxo in selected_utxos:
                amount_total_input += utxo.value
                if utxo.key_id is None:
                    raise WalletError("UTXO has no key_id")
                inp_keys, key = await self._objects_by_key_id(utxo.key_id)
                multisig = not (isinstance(inp_keys, list) and len(inp_keys) < 2)

                # Need to find parent tx to get txid
                parent_tx = None
                for _tid, stx in store.transactions.items():
                    for out in stx.outputs:
                        if out is utxo:
                            parent_tx = stx
                            break
                    if parent_tx:
                        break

                if not parent_tx:
                    raise WalletError("Cannot find parent transaction for UTXO")

                unlock_script_type = get_unlocking_script_type(
                    utxo.script_type or "", self._wallet.witness_type, multisig=multisig
                )

                tx.add_input(
                    parent_tx.txid,
                    utxo.output_n,
                    keys=inp_keys,
                    script_type=unlock_script_type,
                    sigs_required=self._wallet.multisig_n_required,
                    sort=self._wallet.sort_keys,
                    compressed=key.compressed,
                    value=utxo.value,
                    address=key.address,
                    sequence=sequence,
                    key_path=key.path,
                    witness_type=self._wallet.witness_type,
                )
        else:
            for inp in inputs:
                locktime_cltv = None
                unlocking_script_unsigned = None
                unlocking_script_type = ""
                if isinstance(inp, Input):
                    prev_txid = inp.prev_txid
                    output_n = inp.output_n
                    key_id = None
                    value = inp.value
                    signatures: list[Signature | bytes | str] | None = list(inp.signatures) if inp.signatures else None
                    unlocking_script = inp.unlocking_script
                    unlocking_script_unsigned = inp.unlocking_script_unsigned
                    unlocking_script_type = inp.script_type
                    address = inp.address
                    sequence = inp.sequence
                    locktime_cltv = inp.locktime_cltv
                else:
                    prev_txid = inp[0]
                    output_n = inp[1]
                    key_id = None if len(inp) <= 2 else inp[2]
                    value = 0 if len(inp) <= 3 else inp[3]
                    signatures = None if len(inp) <= 4 else inp[4]
                    unlocking_script = b"" if len(inp) <= 5 else inp[5]
                    address = "" if len(inp) <= 6 else inp[6]
                # Get key_ids, value from store if not specified
                if not (key_id and value):
                    if not isinstance(output_n, int):
                        output_n = int.from_bytes(output_n, "big")

                    store = await _get_store()
                    inp_utxo = None
                    inp_utxo_tx = store.get_transaction(txid=to_bytes(prev_txid), wallet_id=self._wallet.wallet_id)
                    if inp_utxo_tx:
                        for out in inp_utxo_tx.outputs:
                            if out.output_n == output_n:
                                inp_utxo = out
                                break

                    if inp_utxo:
                        key_id = inp_utxo.key_id
                        value = inp_utxo.value
                        utxo_key = store.get_key(key_id=key_id) if key_id else None
                        address = utxo_key.address if utxo_key else ""
                        unlocking_script_type = get_unlocking_script_type(
                            inp_utxo.script_type, multisig=self._wallet.multisig,
                        )
                    else:
                        _logger.info(
                            f"UTXO {to_hexstring(prev_txid)} not found in this wallet. "
                            "Please update UTXO's if this is not an offline wallet"
                        )
                        sk = store.get_key(address=address)
                        key_id = sk.id if sk and sk.wallet_id == self._wallet.wallet_id else None

                        if not key_id:
                            raise WalletError(
                                f"UTXO {to_hexstring(prev_txid)} and key with address "
                                f"{address} not found in this wallet"
                            )
                        if not value:
                            raise WalletError(
                                f"Input value is zero for address {address}. Import or update UTXO's first "
                                "or import transaction as dictionary"
                            )

                amount_total_input += value
                if key_id is None:
                    raise WalletError("Cannot find key for input UTXO")
                inp_keys, key = await self._objects_by_key_id(key_id)

                tx.add_input(
                    prev_txid,
                    output_n,
                    keys=inp_keys,
                    script_type=unlocking_script_type,
                    sigs_required=self._wallet.multisig_n_required,
                    sort=self._wallet.sort_keys,
                    compressed=key.compressed,
                    value=value,
                    signatures=signatures,
                    unlocking_script=unlocking_script,
                    address=address,
                    unlocking_script_unsigned=unlocking_script_unsigned,
                    sequence=sequence,
                    locktime_cltv=locktime_cltv,
                    witness_type=self._wallet.witness_type,
                    key_path=key.path,
                )
        # Calculate fees
        tx.fee = fee
        fee_per_output = None
        tx.size = tx.estimate_size(number_of_change_outputs=number_of_change_outputs)
        if fee is None:
            if not inputs:
                if not tx.fee_per_kb:
                    tx.fee_per_kb = await srv.estimatefee()
                if tx.fee_per_kb < tx.network.fee_min:
                    tx.fee_per_kb = tx.network.fee_min
                tx.fee = (tx.size * tx.fee_per_kb) // 1000
                fee_per_output = (50 * tx.fee_per_kb) // 1000
            else:
                if amount_total_output and amount_total_input:
                    fee = False
                else:
                    tx.fee = 0

        if fee is False:
            tx.change = 0
            tx.fee = int(amount_total_input - amount_total_output)
        else:
            tx.change = int(amount_total_input - (amount_total_output + (tx.fee or 0)))

        if (fee_per_output and tx.change < fee_per_output) or tx.change <= tx.network.dust_amount:
            tx.fee = (tx.fee or 0) + tx.change
            tx.change = 0
        if tx.change < 0:
            raise WalletError(
                "Total amount of outputs is greater than total"
                " amount of inputs."
                " Recovery: reduce the send amount or check balance"
            )
        if amount_total_input and tx.fee is not None and tx.fee > amount_total_input // 2:
            raise WalletError(
                f"Fee ({tx.fee}) exceeds 50% of total inputs ({amount_total_input}). This is likely an error."
            )
        if tx.change:
            min_output_value = tx.network.dust_amount * 2 + tx.network.fee_min * 4
            if tx.fee and tx.size:
                if not tx.fee_per_kb:
                    tx.fee_per_kb = ((tx.fee or 0) * 1000) // (tx.vsize or 1)
                min_output_value = tx.fee_per_kb + tx.network.fee_min * 4 + tx.network.dust_amount

            if number_of_change_outputs == 0:
                if tx.change < amount_total_output / 10 or tx.change < min_output_value * 8:
                    number_of_change_outputs = 1
                elif tx.change / 10 > amount_total_output:
                    number_of_change_outputs = secrets.SystemRandom().randint(2, 5)
                else:
                    number_of_change_outputs = secrets.SystemRandom().randint(1, 3)
                    if number_of_change_outputs == 3:
                        number_of_change_outputs = secrets.SystemRandom().randint(3, 4)
                tx.size = tx.estimate_size(number_of_change_outputs=number_of_change_outputs)

            average_change = tx.change // number_of_change_outputs
            if number_of_change_outputs > 1 and average_change < min_output_value:
                raise WalletError(
                    "Not enough funds to create multiple change outputs. Try less change outputs or lower fees"
                )

            if self._wallet.scheme == "single":
                change_keys = [await self._wallet.get_key(
                    account_id=account_id, network=network, key_type=_KeyType.CHANGE,
                )]
            else:
                change_keys = await self._wallet.get_keys(
                    account_id=account_id,
                    network=network,
                    key_type=_KeyType.CHANGE,
                    number_of_keys=number_of_change_outputs,
                )

            if number_of_change_outputs > 1:
                rand_prop = tx.change - number_of_change_outputs * min_output_value
                raw = [secrets.SystemRandom().random() for _ in range(number_of_change_outputs)]
                total = sum(raw)
                proportions = [r / total for r in raw]
                change_amounts = [int(p * rand_prop + min_output_value) for p in proportions]
                diffs = tx.change - sum(change_amounts)
                for idx, co in enumerate(change_amounts):
                    if co - diffs > min_output_value:
                        change_amounts[idx] += change_amounts.index(co) + diffs
                        break
            else:
                change_amounts = [tx.change]

            for idx, ck in enumerate(change_keys):
                on = tx.add_output(change_amounts[idx], ck.address, encoding=self._wallet.encoding)
                tx.outputs[on].key_id = ck.key_id

        if random_output_order:
            tx.shuffle()

        if message:
            msg_bytes = message if isinstance(message, bytes) else message.encode("utf-8")
            lock_script = b"\x6a" + varstr(msg_bytes)
            tx.add_output(0, lock_script=lock_script)

        tx.input_total = sum([i.value for i in tx.inputs])
        tx.output_total = sum([o.value for o in tx.outputs])
        if tx.input_total != (tx.fee or 0) + tx.output_total:
            raise WalletError("Sum of inputs values is not equal to sum of outputs values plus fees")

        tx.txid = tx.signature_hash()[::-1].hex()
        if not tx.fee_per_kb:
            tx.fee_per_kb = ((tx.fee or 0) * 1000) // (tx.vsize or 1)
        if tx.fee_per_kb < tx.network.fee_min:
            raise WalletError(
                f"Fee per kB of {tx.fee_per_kb} is lower then minimal network fee of {tx.network.fee_min}"
            )
        if tx.fee_per_kb > tx.network.fee_max:
            raise WalletError(
                f"Fee per kB of {tx.fee_per_kb} is higher then maximum network fee of {tx.network.fee_max}"
            )

        return await WalletTransaction.create(self._wallet, tx, account_id=account_id)

    async def transaction_import(self, t: TransactionMixin | dict[str, object]) -> WalletTransaction:
        """Import a Transaction into this wallet."""
        if isinstance(t, TransactionMixin):
            rt = await self.transaction_create(
                t.outputs,
                t.inputs,
                fee=t.fee,
                network=t.network.name,
                random_output_order=False,
            )

            rt.tx.block_height = t.block_height
            rt.tx.confirmations = t.confirmations
            rt.tx.witness_type = t.witness_type
            rt.tx.date = t.date
            rt.tx.txid = t.txid
            rt.tx.txhash = t.txhash
            rt.tx.locktime = t.locktime
            rt.tx.version = t.version
            rt.tx.version_int = t.version_int
            rt.tx.block_hash = t.block_hash
            rt.tx.rawtx = t.rawtx
            rt.tx.coinbase = t.coinbase
            rt.tx.flag = t.flag
            rt.tx.size = t.size
            if not t.size:
                rt.tx.size = len(t.raw())
            rt.tx.vsize = t.vsize
            if not t.vsize:
                rt.tx.vsize = rt.tx.size
            rt.tx.fee_per_kb = int(((rt.tx.fee or 0) / float(rt.tx.vsize or 1)) * 1000)
        elif isinstance(t, dict):
            td: dict[str, object] = t
            inputs = []
            t_inputs = td["inputs"]
            if not isinstance(t_inputs, list):
                raise WalletError("Invalid transaction dict: inputs must be a list")
            for i_raw in t_inputs:
                if not isinstance(i_raw, dict):
                    continue
                i_inp = _narrow_dict(i_raw)
                sigs_raw = i_inp["signatures"]
                if not isinstance(sigs_raw, list):
                    raise WalletError("Invalid input dict: signatures must be a list")
                signatures = [bytes.fromhex(str(sig)) for sig in sigs_raw]
                script = i_inp.get("script", b"")
                address = i_inp.get("address", "")
                i_value = i_inp["value"]
                inputs.append(
                    (
                        i_inp["prev_txid"],
                        i_inp["output_n"],
                        None,
                        int(i_value) if isinstance(i_value, (int, str)) else 0,
                        signatures,
                        script,
                        address,
                    )
                )
            outputs = []
            t_outputs = td["outputs"]
            if not isinstance(t_outputs, list):
                raise WalletError("Invalid transaction dict: outputs must be a list")
            for o in t_outputs:
                if not isinstance(o, dict):
                    continue
                o_dict: dict[str, object] = _narrow_dict(o)
                o_value = o_dict["value"]
                outputs.append(
                    (
                        o_dict["address"],
                        int(o_value) if isinstance(o_value, (int, str)) else 0,
                    )
                )
            td_fee = td.get("fee")
            td_network = td.get("network")
            rt = await self.transaction_create(
                outputs,
                inputs,
                fee=int(td_fee) if isinstance(td_fee, (int, str)) else None,
                network=str(td_network) if td_network else None,
                random_output_order=False,
            )
            rt.tx.block_height = td.get("block_height")
            td_confirmations = td.get("confirmations", 0)
            rt.tx.confirmations = int(td_confirmations) if isinstance(td_confirmations, (int, str)) else 0
            td_witness = td.get("witness_type", "legacy")
            rt.tx.witness_type = str(td_witness) if td_witness else "legacy"
            rt.tx.date = td.get("date")
            td_txid = td.get("txid", "")
            rt.tx.txid = str(td_txid) if td_txid else ""
            td_txhash = td.get("txhash", "")
            rt.tx.txhash = str(td_txhash) if td_txhash else ""
            td_locktime = td.get("locktime", 0)
            rt.tx.locktime = int(td_locktime) if isinstance(td_locktime, (int, str)) else 0
            t_version = td.get("version", 4)
            rt.tx.version = int(t_version).to_bytes(4, "big") if isinstance(t_version, int) else t_version
            rt.tx.version_int = int(t_version) if isinstance(t_version, int) else 4
            td_block_hash = td.get("block_hash")
            rt.tx.block_hash = str(td_block_hash) if td_block_hash else None
            rt.tx.rawtx = td.get("raw", b"")
            rt.tx.coinbase = bool(td.get("coinbase", False))
            td_flag = td.get("flag")
            rt.tx.flag = str(td_flag) if td_flag else None
            td_size = td.get("size", 0)
            rt.tx.size = int(td_size) if isinstance(td_size, (int, str)) and td_size else None
            if not rt.tx.size:
                rt.tx.size = len(rt.tx.raw())
            td_vsize = td.get("vsize", 0)
            rt.tx.vsize = int(td_vsize) if isinstance(td_vsize, (int, str)) and td_vsize else None
            if not rt.tx.vsize:
                rt.tx.vsize = rt.tx.size
            rt.tx.fee_per_kb = int(((rt.tx.fee or 0) / float(rt.tx.vsize or 1)) * 1000)
        else:
            raise WalletError("Import transaction must be of type Transaction or dict")
        rt.tx.verify()
        return rt

    async def send(
        self,
        outputs: list[tuple[str, int]] | list[tuple[str | Address | HDKey | WalletKey, int]],
        inputs: list[tuple[str, int, int, int]] | list[Input] | None = None,
        input_key_id: int | list[int] | None = None,
        account_id: int | None = None,
        network: str | None = None,
        fee: int | None = None,
        min_confirms: int = 1,
        priv_keys: HDKey | list[HDKey] | list[HDKey | str] | None = None,
        max_utxos: int | None = None,
        locktime: int = 0,
        offline: bool = True,
        number_of_change_outputs: int = 1,
        message: str | bytes = "",
    ) -> WalletTransaction:
        """Create a new transaction with specified outputs and push it to the network."""

        if inputs and max_utxos and len(inputs) > max_utxos:
            raise WalletError(
                f"Input array contains {len(inputs)} UTXO's but max_utxos={max_utxos} parameter specified"
            )

        transaction = await self.transaction_create(
            outputs,
            inputs,
            input_key_id,
            account_id,
            network,
            fee,
            min_confirms,
            max_utxos,
            locktime,
            number_of_change_outputs,
            message=message,
        )
        transaction.sign(priv_keys)
        if fee is None and transaction.tx.fee_per_kb and transaction.tx.change:
            fee_exact = transaction.tx.calculate_fee()
            if (
                fee_exact != self._wallet.network.fee_min
                and fee_exact != self._wallet.network.fee_max
                and fee_exact
                and abs((float(transaction.tx.fee or 0) - float(fee_exact)) / float(fee_exact)) > 0.10
            ):
                _logger.info(
                    f"Transaction fee not correctly estimated (est.: {transaction.tx.fee}, real: {fee_exact}). "
                    "Recreate transaction with correct fee"
                )
                transaction = await self.transaction_create(
                    outputs,
                    inputs,
                    input_key_id,
                    account_id,
                    network,
                    fee_exact,
                    min_confirms,
                    max_utxos,
                    locktime,
                    number_of_change_outputs,
                    message=message,
                )
                transaction.sign(priv_keys)

        transaction.tx.rawtx = transaction.tx.raw()
        transaction.tx.size = len(transaction.tx.rawtx)
        transaction.tx.calc_weight_units()
        transaction.tx.fee_per_kb = int(float(transaction.tx.fee or 0) / float(transaction.tx.vsize or 1) * 1000)
        transaction.tx.txid = transaction.tx.signature_hash()[::-1].hex()
        await transaction.send(offline)

        return transaction

    async def send_to(
        self,
        to_address: str | Address | HDKey | WalletKey,
        amount: int,
        input_key_id: int | list[int] | None = None,
        account_id: int | None = None,
        network: str | None = None,
        fee: int | None = None,
        min_confirms: int = 1,
        priv_keys: HDKey | list[HDKey] | list[HDKey | str] | None = None,
        locktime: int = 0,
        offline: bool = True,
        number_of_change_outputs: int = 1,
        message: str = "",
    ) -> WalletTransaction:
        """Create transaction and send it.

        Wrapper for wallet :func:`send` method.
        """

        outputs = [(to_address, amount)]

        return await self.send(
            outputs,
            input_key_id=input_key_id,
            account_id=account_id,
            network=network,
            fee=fee,
            min_confirms=min_confirms,
            priv_keys=priv_keys,
            locktime=locktime,
            offline=offline,
            number_of_change_outputs=number_of_change_outputs,
            message=message,
        )

    async def sweep(
        self,
        to_address: str | list[tuple[str, int]],
        account_id: int | None = None,
        input_key_id: int | list[int] | None = None,
        network: str | None = None,
        max_utxos: int = 999,
        min_confirms: int = 1,
        fee_per_kb: int | None = None,
        fee: int | str | None = None,
        locktime: int = 0,
        offline: bool = True,
    ) -> WalletTransaction:
        """Sweep all unspent transaction outputs and send them to one or more output addresses."""

        network, account_id, _ = await self._wallet._get_account_defaults(network, account_id)

        utxos = await self._wallet.utxos(
            account_id=account_id,
            network=network,
            min_confirms=min_confirms,
            key_id=input_key_id,
        )
        utxos = utxos[0:max_utxos]
        inputs = []
        total_amount = 0
        if not utxos:
            raise WalletError(
                "Cannot sweep wallet, no UTXO's found."
                " Recovery: run 'fluxwallet wallet scan' to update"
            )
        for utxo in utxos:
            if utxo.value <= self._wallet.network.dust_amount:
                continue
            inputs.append((utxo.txid, utxo.output_n, utxo.key_id, utxo.value))
            total_amount += utxo.value
        srv = Service(
            network=network,
            providers=self._wallet.providers,
            cache_uri=self._wallet.db_cache_uri,
        )

        if isinstance(fee, str):
            n_outputs = 1 if not isinstance(to_address, list) else len(to_address)
            fee_per_kb = await srv.estimatefee(priority=fee)
            tr_size = 125 + (len(inputs) * (77 + self._wallet.multisig_n_required * 72)) + n_outputs * 30
            fee = 100 + (tr_size * fee_per_kb) // 1000

        if not fee:
            if fee_per_kb is None:
                fee_per_kb = await srv.estimatefee()
            tr_size = 125 + (len(inputs) * 125)
            fee = (tr_size * fee_per_kb) // 1000
        if total_amount - fee <= self._wallet.network.dust_amount:
            raise WalletError(
                "Amount to send is smaller than dust amount: %s."
                " Recovery: send a larger amount or add more UTXOs"
                % (total_amount - fee)
            )

        if isinstance(to_address, str):
            to_list = [(to_address, total_amount - fee)]
        else:
            to_list = []
            for o in to_address:
                if o[1] == 0:
                    o_amount = total_amount - sum([x[1] for x in to_list]) - fee
                    if o_amount > 0:
                        to_list.append((o[0], o_amount))
                else:
                    to_list.append(o)

        if sum(x[1] for x in to_list) + fee != total_amount:
            raise WalletError(
                "Total amount of outputs does not match total input amount. If you specify a list of "
                "outputs, use amount value = 0 to indicate a change/rest output"
            )

        return await self.send(
            to_list,
            inputs,
            network=network,
            fee=fee,
            min_confirms=min_confirms,
            locktime=locktime,
            offline=offline,
        )

    async def transaction_load(self, txid: str | None = None, filename: str | None = None) -> WalletTransaction:
        """Load transaction object from file."""
        if not filename and not txid:
            raise WalletError("Please supply filename or txid")
        if not filename and txid:
            p = Path(FW_DATA_DIR, f"{txid}.tx")
        else:
            if filename is None:
                raise WalletError("Please supply filename or txid")
            p = Path(filename)
            if not p.parent or str(p.parent) == ".":
                p = Path(FW_DATA_DIR, filename)
        with p.open("rb") as f:
            data = msgpack.unpack(f, raw=False)
        t = FluxTransaction.from_dict(data)
        return await self.transaction_import(t)

    async def open_shielded(self, explorer_url: str | None = None) -> ShieldedWallet:
        """Create a ShieldedWallet backed by this wallet's Sapling key."""
        from fluxwallet.sapling.wallet import ShieldedWallet as _ShieldedWallet  # noqa: PLC0415

        if explorer_url is None:
            explorer_url = provider_url_for_capability("shielded")

        if self._wallet.multisig:
            raise WalletError(
                "Shielded transactions not supported for multisig"
                " wallets. Recovery: use a single-key wallet"
            )
        sk = await self._wallet.sapling_spending_key()
        store = await _get_store()
        sw = store.get_wallet(name=self._wallet.name)
        if sw is None:
            raise WalletError(f"Wallet '{self._wallet.name}' not found in store")
        return _ShieldedWallet(sk, explorer_url, self._wallet.wallet_id, store, sw, save_callback=_save_store)

    async def transparent_inputs_for_shielding(
        self,
        amount: int,
        fee: int,
    ) -> list[dict[str, bytes | int]]:
        """Select UTXOs and return transparent inputs for a shielding transaction."""
        store = await _get_store()
        utxo_list = await self._wallet.utxos()
        total_needed = amount + fee
        inputs: list[dict[str, bytes | int]] = []
        gathered = 0
        for utxo in utxo_list:
            if gathered >= total_needed:
                break
            k = store.get_key(key_id=utxo.key_id)
            if k is None or k.private is None:
                continue
            addr_hash = addr_base58_to_pubkeyhash(k.address)
            inputs.append(
                {
                    "txid": bytes.fromhex(utxo.txid),
                    "vout": utxo.output_n,
                    "address_hash": addr_hash,
                    "value": utxo.value,
                    "secret_key": k.private,
                }
            )
            gathered += utxo.value
        if gathered < total_needed:
            raise WalletError(
                f"Insufficient transparent balance: need"
                f" {total_needed}, have {gathered}."
                " Recovery: run 'fluxwallet wallet scan' or send less"
            )
        return inputs

