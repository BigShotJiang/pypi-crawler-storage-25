# vanya

A constrained DSL for e2e tests. Transpiles to Python, JavaScript, etc.

## Install

```bash
pipx install vanya-lang
```

## Quick Start

```bash
vanya init              # Creates example test.vanya
vanya check test.vanya  # Validate syntax
vanya build test.vanya -o out/  # Transpile to Python
```

## Documentation

**https://vanya-lang.pages.dev/**

## License

MIT
