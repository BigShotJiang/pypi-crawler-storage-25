import platform
import subprocess
import sys
import urllib.request
import urllib.error
import tarfile
import zipfile
import lzma
from pathlib import Path

try:
    from importlib.metadata import version as pkg_version
    __version__ = pkg_version("vanya")
except Exception:
    __version__ = "0.2.11"

BINARY_VERSION = __version__
R2_BASE = "https://pub-5dae181f67424ed482a6fd7383474727.r2.dev"

PLATFORMS = {
    ("Darwin", "x86_64"): "x86_64-apple-darwin",
    ("Darwin", "arm64"): "aarch64-apple-darwin",
    ("Linux", "x86_64"): "x86_64-unknown-linux-gnu",
    ("Linux", "aarch64"): "aarch64-unknown-linux-gnu",
    ("Windows", "AMD64"): "x86_64-pc-windows-msvc",
}


def get_binary_path() -> Path:
    bin_dir = Path(__file__).parent / "bin"
    bin_dir.mkdir(exist_ok=True)
    ext = ".exe" if platform.system() == "Windows" else ""
    binary = bin_dir / f"vanya{ext}"
    if not binary.exists():
        download_binary(binary)
    return binary


def download_binary(dest: Path) -> None:
    system = platform.system()
    machine = platform.machine()
    target = PLATFORMS.get((system, machine))
    if not target:
        raise RuntimeError(f"Unsupported platform: {system}-{machine}")

    ext = ".zip" if system == "Windows" else ".tar.xz"
    url = f"{R2_BASE}/v{BINARY_VERSION}/vanya-{target}{ext}"

    print(f"Downloading vanya from {url}", file=sys.stderr)
    archive_path = dest.parent / f"vanya{ext}"
    req = urllib.request.Request(url, headers={"User-Agent": "vanya-installer"})
    try:
        with urllib.request.urlopen(req) as resp, open(archive_path, "wb") as f:
            f.write(resp.read())
    except urllib.error.HTTPError as e:
        if e.code == 404:
            raise RuntimeError(
                f"Binary not found at {url}\n"
                f"The vanya v{BINARY_VERSION} binary has not been published to the download server.\n"
                f"This can happen if:\n"
                f"  1. You installed a pre-release version before binaries were uploaded\n"
                f"  2. The release pipeline failed to upload binaries\n"
                f"\n"
                f"Workarounds:\n"
                f"  - Try: pip install vanya-lang==<older-version>\n"
                f"  - Or use npm: npm install -g @vanya-lang/vanya\n"
                f"  - Check https://github.com/vanya-org/vanya/releases for available versions"
            ) from e
        raise

    if ext == ".tar.xz":
        with lzma.open(archive_path) as xz:
            with tarfile.open(fileobj=xz) as tar:
                for member in tar.getmembers():
                    if member.name.endswith("vanya"):
                        member.name = "vanya"
                        tar.extract(member, dest.parent)
                        break
    else:
        with zipfile.ZipFile(archive_path, "r") as z:
            for name in z.namelist():
                if name.endswith("vanya.exe"):
                    with z.open(name) as src, open(dest, "wb") as dst:
                        dst.write(src.read())
                    break

    archive_path.unlink()
    dest.chmod(0o755)


def main() -> None:
    binary = get_binary_path()
    result = subprocess.run([str(binary)] + sys.argv[1:])
    sys.exit(result.returncode)
