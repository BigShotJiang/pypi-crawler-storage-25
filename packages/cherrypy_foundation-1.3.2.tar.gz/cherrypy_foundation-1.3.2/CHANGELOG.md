# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

<!-- insertion marker -->
## [1.3.2](https://gitlab.com/ikus-soft/cherrypy-foundation/tags/1.3.2) - 2026-04-01

<small>[Compare with 1.3.1](https://gitlab.com/ikus-soft/cherrypy-foundation/compare/1.3.1...1.3.2)</small>

### Documented

- doc: fix `url_for()` example ([4eca46e](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/4eca46ed61f6a14db795591ebe255c6c67d129b5) by Patrik Dufresne).

### Misc

- field,password: show a little eye to toggle password visibility ([4863167](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/486316779baf5774b1a9f3d8e61eb4bd85046f49) by Patrik Dufresne).

## [1.3.1](https://gitlab.com/ikus-soft/cherrypy-foundation/tags/1.3.1) - 2026-03-18

<small>[Compare with 1.3.0](https://gitlab.com/ikus-soft/cherrypy-foundation/compare/1.3.0...1.3.1)</small>

### Misc

- datatable: fix javascript to handle static uses ([316e949](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/316e949ef01bff79b106fab440fe084aaae98aa1) by Patrik Dufresne).
- gitignore: ignore `build` folder ([4c66637](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/4c66637d50fcf68f23ea1c6a9f18ae6ed58afccd) by Patrik Dufresne).
- ci: pin git-changelog to 2.9.1 ([546c61a](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/546c61ac502287a26d13aa223843ff924bd9c0eb) by Patrik Dufresne).
- debian: remove `<!nodoc>` from `sphinx-common` as it's required by debian helper ([0e6f0eb](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/0e6f0eb0d647d365646f1d09434ad67e0aaeee5d) by Patrik Dufresne).
- ci: add `--no-install-recommends` to `apt build-dep` ([45acc6f](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/45acc6f9a8e1d92e913a098c9cd8c2a15b7c6524) by Patrik Dufresne).
- ci: revert "debian: replace `.dev0` by `.dev`" ([628d66e](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/628d66e79fa1db9fe246107c12b02eee6fc7cd5c) by Patrik Dufresne).
- ci: define only 2 tox target: format & lint ([c7509f8](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/c7509f830367f9f51c0fa96eda6d014f919b4d37) by Patrik Dufresne).

## [1.3.0](https://gitlab.com/ikus-soft/cherrypy-foundation/tags/1.3.0) - 2026-03-12

<small>[Compare with 1.2.0](https://gitlab.com/ikus-soft/cherrypy-foundation/compare/1.2.0...1.3.0)</small>

### Added

- Add git-changelog to maintain CHANGELOG.md and debian/changelog ([928ae83](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/928ae83aafb1c0272b69803c56c09bf005115af3) by Patrik Dufresne).

### Misc

- ci: support with and without dfsg ([f34f7ac](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/f34f7ac0edddd4a78bcd55c39dd7a26f73ee9c61) by Patrik Dufresne).
- ci: generate changelog without `+dfsg` ([611e6e1](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/611e6e19a409b09828925ee0acf2bb0efca3ef8a) by Patrik Dufresne).
- debian: don't call with `-us -uc` -not required in this environment ([b845e4c](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/b845e4c4ed9f3e8869b2f7ab411ec193c3f7dc8e) by Patrik Dufresne).
- debian: remove redundant field ([9bd0ec1](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/9bd0ec15df3fb014465e45c0e35be50b63eb18bf) by Patrik Dufresne).
- debian: add `watch` file ([e3d4746](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/e3d474661b3baed11a511c78bda1477ebd5b1404) by Patrik Dufresne).
- debian: remove `Built-Using` ([960d143](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/960d143e9ddee15e48c3f0a1a4291fa103fa318c) by Patrik Dufresne).
- debian: remove `python3-all-dev` from build depends ([dcba3bf](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/dcba3bfd30424025b16ace8f8adfc4f40e15cb9d) by Patrik Dufresne).
- ci: change build to run `lintian` only once on binary packages ([0f1dd8d](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/0f1dd8d4e8b916eac72e562aba6ddf53b2ecb08b) by Patrik Dufresne).
- ci: remove call to `apt build-dep` when building debian source package ([778a23c](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/778a23c96a514596f86d47d83f165a2618bec392) by Patrik Dufresne).
- ci: do not install devscripts ([0d6a036](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/0d6a0360e679b10ff4ae628195d3988caf73caba) by Patrik Dufresne).
- ci: use unstable to build debian source package ([c0902bd](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/c0902bd4426fb68be826727eaf72672b11297455) by Patrik Dufresne).
- debian: replace `.dev0` by `.dev` ([5c5a9cc](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/5c5a9ccf7329342eb51835f2c3e3f7501602ab0b) by Patrik Dufresne).
- debian: make datatable test optional when `+dfsg` ([5b3e6aa](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/5b3e6aa4a791a18c41da919486fde137b74edc5f) by Patrik Dufresne).
- debian: change to avoid calling `sed` in subshell ([7963ff6](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/7963ff6ea206666168360e45148f86d14a1a1239) by Patrik Dufresne).
- ci: change to bump git-changelog version ([956f311](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/956f31128df632bc6ae034c9b1089e0e45746abc) by Patrik Dufresne).
- debian: disable datatable test ([6a85ae9](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/6a85ae942274ff330ff635a028e62516f58a9b79) by Patrik Dufresne).
- debian: ignore "vendor" folder ([0139915](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/0139915e7fa7de29e4b1a9a8f151058b2af35992) by Patrik Dufresne).
- ci, debian: split source and binary build for isolation ([cd900fc](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/cd900fc95657b45751c447af9166fd690c9ae47f) by Patrik Dufresne).
- debian: append .dev0 for unreleased version ([ee21061](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/ee210610975c8ab6ba1524c24f0caeeb62c90336) by Patrik Dufresne).
- debian: create "vendor" folder if missing ([a2af45f](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/a2af45f7f66fe8fef82103e128782eff94493d36) by Patrik Dufresne).
- debian: exclude "debian" from ".orig.tar.xz" ([779b183](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/779b183083e4d43b19ede4288285d7e77b649866) by Patrik Dufresne).
- build: include translation files in sdist ([3a5cd45](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/3a5cd454c3ed8c393817d541115b0c16179d1bf9) by Patrik Dufresne).
- debian: Update upstream contact ([101764a](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/101764a94d48ce1156941b6739a34340c9cdba9a) by Patrik Dufresne).
- Use `xz` for original tarball ([ea50f57](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/ea50f57c3bba7141f35105f19db2054af91fa797) by Patrik Dufresne).

## [1.2.0](https://gitlab.com/ikus-soft/cherrypy-foundation/tags/1.2.0) - 2026-03-06

<small>[Compare with 1.0.6](https://gitlab.com/ikus-soft/cherrypy-foundation/compare/1.0.6...1.2.0)</small>

### Added

- Add unit test for error page ([bcecd75](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/bcecd75593b64da05628daa8ed7fc79397de94db) by Patrik Dufresne).
- Add `python3-sqlalchemy` to suggests packages ([a1f477c](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/a1f477c9f4a2de16e35fb0d37028008044285e1f) by Patrik Dufresne).

### Fixed

- Fix url_for to avoid leaking form data in query_string ([6eac38d](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/6eac38d264842e6410e1803de9a92f927cfd00fa) by Patrik Dufresne).

### Misc

- datatable: add static content support ([cc536c8](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/cc536c85ee49db1f3db5f90639707dc29808a462) by Patrik Dufresne).
- debian: wrap-and-sort ([47e65bb](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/47e65bb3b8ccd7670b0cd34126ba5410266a11ef) by Patrik Dufresne).
- debian: Harmonize indenting in rules ([4ab9d53](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/4ab9d53db2d71be972bb63563613e7622c04d11a) by Daniel Baumann).
- debian: Updating python-tz build-depends for trixie and newer ([eeb759c](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/eeb759cb7df619a5d7608b8bb8b66b2568b446cb) by Daniel Baumann).
- debian: Sorting fields in control ([23edd23](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/23edd2364c95015cf36e5c76fecf2061ae34ab86) by Daniel Baumann).

## [1.0.6](https://gitlab.com/ikus-soft/cherrypy-foundation/tags/1.0.6) - 2026-02-20

<small>[Compare with 1.0.5](https://gitlab.com/ikus-soft/cherrypy-foundation/compare/1.0.5...1.0.6)</small>

### Added

- Add forky, plucky, questing, resolute ([0508049](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/0508049a98a4da259b693f15990031ba22743a70) by Patrik Dufresne).

### Misc

- Clear db sessions before drop table to avoid dead lock ([b4c1244](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/b4c1244b00296515f9acb41bbbe433aff4247d2e) by Patrik Dufresne).

## [1.0.5](https://gitlab.com/ikus-soft/cherrypy-foundation/tags/1.0.5) - 2026-02-19

<small>[Compare with 1.0.4](https://gitlab.com/ikus-soft/cherrypy-foundation/compare/1.0.4...1.0.5)</small>

### Fixed

- Fix oauth module to use session_lock ([ed51d36](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/ed51d3642213351b90ce6d83ad8fbeb05cbbcd4f) by Patrik Dufresne).

### Misc

- Adjust logging ([d4f3b44](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/d4f3b4429914b1f52e149e517adb63be474e4654) by Patrik Dufresne).
- Ignore 'priority' in ratelimit.increase_hit() ([6f46ff3](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/6f46ff3f53da55479b5322542cadb63e5877922b) by Patrik Dufresne).
- wip: upload multiple deb ([a1582fb](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/a1582fbc7c51fbbe50a241d77194fa77618c5206) by Patrik Dufresne).

## [1.0.4](https://gitlab.com/ikus-soft/cherrypy-foundation/tags/1.0.4) - 2026-02-18

<small>[Compare with 1.0.2](https://gitlab.com/ikus-soft/cherrypy-foundation/compare/1.0.2...1.0.4)</small>

### Added

- Add bytes support to url_for() ([26aeb44](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/26aeb4465033cf08269666450373c984d4117245) by Patrik Dufresne).
- Add oauth module from rdiffweb ([afa1380](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/afa1380b1f7842a6aa50167b74de1b00a6b169cb) by Patrik Dufresne).

### Fixed

- Fix error messages in `url_for()` ([5345c0b](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/5345c0b6d161c301d7296514549bcb84280abdb9) by Patrik Dufresne).

### Documented

- Document sessions module ([113c761](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/113c761e2134e618c876968ff754801faa5b9087) by Patrik Dufresne).

### Misc

- Enable wtform translation automatically ([a54dc18](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/a54dc181036af27dd4dd224ad455525e5904dce6) by Patrik Dufresne).
- Clean-up previous debian archive in CICD pipeline ([78b0b90](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/78b0b901c756e2778a0374cad926f75ef392f21e) by Patrik Dufresne).
- Include doc in Debian package ([4c88bea](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/4c88bea124208e3f161309549e53cd58932f7ced) by Patrik Dufresne).
- Run test for Debian unstable ([f53152a](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/f53152ac3cb5404e54fd672794cee892be089de3) by Patrik Dufresne).
- Declare `db` optional-dependencies ([1c442b8](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/1c442b817dd0b76f07ac1a4c96cd27430a0b9a34) by Patrik Dufresne).

## [1.0.2](https://gitlab.com/ikus-soft/cherrypy-foundation/tags/1.0.2) - 2026-02-10

<small>[Compare with 1.0.1](https://gitlab.com/ikus-soft/cherrypy-foundation/compare/1.0.1...1.0.2)</small>

### Fixed

- Fix search of `chromedriver` for selenium tests ([2ba11fd](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/2ba11fdc0eb99f0472e3e7dd18ade32917645bc0) by Patrik Dufresne).

### Misc

- ldap: Fix implementation of `all_attribute` ([d605015](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/d605015b190be702835e5a85e6132584ac13bbbb) by Patrik Dufresne).
- Symlink for bootstrap5, jquery, jquery-typeahead & popper.js ([e770697](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/e770697236ce35d4f3f1f0d02b72452b4964fe83) by Patrik Dufresne).
- Use `no-guess-dev` with setuptools-scm ([33e430b](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/33e430b02e2959ee533494c79abb3e0bd88d7b9a) by Patrik Dufresne).

## [1.0.1](https://gitlab.com/ikus-soft/cherrypy-foundation/tags/1.0.1) - 2026-02-04

<small>[Compare with 1.0.0](https://gitlab.com/ikus-soft/cherrypy-foundation/compare/1.0.0...1.0.1)</small>

### Added

- Add wrap-and-sort to CICD pipeline ([5b85415](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/5b85415881bf06b858dfaf420db8a511067a9178) by Patrik Dufresne).

### Misc

- Improve support for JinjaX 0.57 ([e794847](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/e794847c92f175f6f799669b666069c81ce9e875) by Patrik Dufresne).

## [1.0.0](https://gitlab.com/ikus-soft/cherrypy-foundation/tags/1.0.0) - 2026-02-03

<small>[Compare with first commit](https://gitlab.com/ikus-soft/cherrypy-foundation/compare/84f6f117af9d14251cf9539aca8259bb1096d20f...1.0.0)</small>

### Added

- Add `pool_size` option to ldap module ([3d3da00](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/3d3da00f0c466c66a7338c38606c5ace48a41fef) by Patrik Dufresne).
- Add logging unit test ([e946c8d](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/e946c8de5eaa4825faa6f26e0681ef74e15d3575) by Patrik Dufresne).
- Add ratelimit unit test ([6a61fa4](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/6a61fa46d223e65527fe251e22c7e7eac844013c) by Patrik Dufresne).
- Add `bcc` to smtp module ([82c15a6](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/82c15a6faf9047fea9d4b14f3aa3c06bbda49f91) by Patrik Dufresne).
- Add unit test for CherrpyForm ([1a63d51](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/1a63d515c9c599a7be76acfcb70b38563e567e29) by Patrik Dufresne).
- Add secure-header unit test ([b15dc88](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/b15dc888565536fb77c68fee1e153cdbdc239691) by Patrik Dufresne).
- Add LanguageSelection component ([d2d3ecd](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/d2d3ecd0295f42077d966cba8a908eac69ee76f4) by Patrik Dufresne).
- Add jinja2 unit test ([bfa81df](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/bfa81df0d03f180be9ae126b116541f085533066) by Patrik Dufresne).
- Add source code ([55586a7](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/55586a72443060bb039fd391f34b18736ab86bfb) by Patrik Dufresne).

### Fixed

- Fix for ldap first_attribute ([925d1e3](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/925d1e3d3f324f0b1d1e662f9dc747830bd50dc1) by Patrik Dufresne).
- Fix to handle invalid locale ([7cc32d1](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/7cc32d1966067445ea7a09ba949de221913d2dd0) by Patrik Dufresne).
- Fix i18n config ([a352c08](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/a352c0858319ab755d5e2160d7fcbc12b216f22a) by Patrik Dufresne).
- Fix copyright header ([bea1db8](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/bea1db85adc3961a437e390683da6b3e9bd1e984) by Patrik Dufresne).
- Fix LDAP logs, enhance error page & more unit test ([5404195](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/5404195ea5fc18dee5fd801807b45c2e873d259b) by Patrik Dufresne).

### Removed

- Remove translation from ColorModes ([a4ecd23](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/a4ecd23c58e8a6e4e21a1c226c7a19eae97e1ddd) by Patrik Dufresne).

### Misc

- ldap: Rename variable `username` to `login` ([0e9d152](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/0e9d152bd62143121b30a85a5bf18e5550238639) by Patrik Dufresne).
- Support explicit session lock ([957c4b5](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/957c4b5594dfd3a25a5cf6fbbaa9ac6fb11e0efe) by Patrik Dufresne).
- Start writing documentation ([88a5825](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/88a5825c532375606b57a2cc89499547e91c43a9) by Patrik Dufresne).
- Update copyright ([fba5d3a](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/fba5d3addb9e6fa07dcffba99ba719506689dc2f) by Patrik Dufresne).
- Drop cherrypy.tools.errors ([37cc38e](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/37cc38e9e9d092d0576520d2f1a81ef9c23ce5fc) by Patrik Dufresne).
- Initial Debian packaging ([6a33d2e](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/6a33d2ebb48d68746e5ded7ebcfbdb7f6cdf92d1) by Patrik Dufresne).
- Adjust datatable button margins for responsive design ([19dd22b](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/19dd22bcb23675a4af9e54fc5ca4e50d737b312e) by Patrik Dufresne).
- Refactor i18n module ([bb50659](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/bb506593072fe7bf4b7b77edeaf02ba944848880) by Patrik Dufresne).
- Publish deb package to nexus server ([fe29338](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/fe293383f1a74381ed0bd21ae40419945c2b3af8) by Patrik Dufresne).
- Update scheduler module from rdiffweb ([6039130](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/6039130242db47ed8b016a5bb1867da5759bdd70) by Patrik Dufresne).
- Handle LazyString in `<Field>` ([86db29f](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/86db29f2badc04e274a5b3f38682df8d697966f8) by Patrik Dufresne).
- Move `<Fields>` dependencies to `<Field>` ([325fe78](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/325fe784c49063f7b812c2d66aa9f951782aa1e8) by Patrik Dufresne).
- Make better use of region in i18n ([3c07c8c](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/3c07c8c677a2aebcadad2975d42da46ec90fccfa) by Patrik Dufresne).
- Adjust error page for 404 error ([d90f51b](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/d90f51b8f70bc5c38d0069c987130e9089113de9) by Patrik Dufresne).
- Create debian package ([eaced72](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/eaced72acc97edac587338538eb9bb7b8aa82517) by Patrik Dufresne).
- Update flash component ([2807eb4](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/2807eb41a5191c09b7fd4c1fd25ffd99f3cd26b9) by Patrik Dufresne).
- Revisit `url_for` implementation and tests ([9681e9b](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/9681e9bdc473740a0810c5f5ed95e9c4ebff4dcf) by Patrik Dufresne).
- Update Typeahead defaults value & adjust css ([24775e4](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/24775e49e133a679e51f23cbe40022b571c78d33) by Patrik Dufresne).
- Allow specific render_kw for container and label ([eda6288](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/eda6288fb394596b7567e626c0117683fac088e3) by Patrik Dufresne).
- Update module from rdiffweb ([5cb6353](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/5cb6353f1885caf23842ec3c0ac48ec1447fe731) by Patrik Dufresne).
- Adjust logging & Add MFA unit test ([2410195](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/2410195be1cf33ff96f63b577d0d967cd79defea) by Patrik Dufresne).
- Initial commit ([84f6f11](https://gitlab.com/ikus-soft/cherrypy-foundation/commit/84f6f117af9d14251cf9539aca8259bb1096d20f) by Patrik Dufresne).
