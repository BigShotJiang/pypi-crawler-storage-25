"""Core ChecklistFabrik package."""

__version__ = '1.7.0'
