"""csrd WebSocket Library — real-time connection lifecycle and routing.

This package is a stub (v0.1.0) with reserved PyPI name.
Implementation in progress per docs/WEBSOCKET_LIBRARY_DESIGN.md.
"""

__version__ = "0.1.0"
__all__: list[str] = []
