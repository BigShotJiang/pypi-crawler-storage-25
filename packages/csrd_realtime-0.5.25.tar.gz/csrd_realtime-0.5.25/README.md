# csrd WebSocket Library

**Status:** Stub (v0.1.0) — Name claimed, implementation in progress.

Real-time WebSocket connection lifecycle, room broadcast, and routing primitives for the csrd ecosystem.

## Overview

This package provides reusable WebSocket infrastructure for building real-time services on FastAPI. It handles connection registration, room membership, message routing, and optional policy hooks — but does **not** define domain-specific protocols.

## Design reference

- **Design doc:** `../../docs/WEBSOCKET_LIBRARY_DESIGN.md`
- **Implementation plan:** `../../docs/WEBSOCKET_LIBRARY_IMPLEMENTATION_PLAN.md`

## Planned v1 API (stub)

```python
from csrd.realtime import (
    ConnectionContext,
    ConnectionManager,
    MessageEnvelope,
    MessageRouter,
)
```

## Status

This is a reserved namespace stub. The full implementation will be available in v0.2.0+.
