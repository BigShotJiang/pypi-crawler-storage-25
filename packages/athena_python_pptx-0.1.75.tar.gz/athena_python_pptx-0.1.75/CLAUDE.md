# athena-python-pptx SDK — Claude Instructions

## API Parity Rule (MANDATORY)

**This SDK MUST be a 100% exact replica of the standard [python-pptx](https://python-pptx.readthedocs.io/) API.**

Every class, method, property, and parameter name must match python-pptx exactly. The goal is that any code written for python-pptx works identically with this SDK — no surprises, no differences.

### What this means in practice

- **Do NOT add new methods** that don't exist in python-pptx (e.g., `fill.set_color()`, `line.no_fill()`, `fill.solid_fill()`)
- **Do NOT add new properties** that don't exist in python-pptx (e.g., `fill.color_hex`, `line.color_hex`, `line.width_pt`)
- **Do NOT rename parameters** — use the exact same parameter names as python-pptx (e.g., `autoshape_type_id`, not `autoshape_type`)
- **Do NOT change method signatures** — if python-pptx's `fill.solid()` takes no arguments, ours must also take no arguments
- **Do NOT change return types** — if python-pptx's `font.color` returns a `ColorFormat`, ours must too (never `None`)

### How to verify parity

Before adding or modifying any API surface:

1. Check the [python-pptx documentation](https://python-pptx.readthedocs.io/)
2. Check the [python-pptx source code](https://github.com/scanny/python-pptx)
3. Confirm the method/property/parameter exists with the same name and signature
4. If it doesn't exist in python-pptx, **do not add it** without explicit user approval

### Current status (v0.1.74)

**Full public-class parity reached** against python-pptx 1.0.2 across
three dimensions:

- **150 classes covered**, 0 uncovered upstream public classes. Every class user code might import from python-pptx 1.0.2 has an importable counterpart at the matching module path.
- **14 enum classes value-tested**: every upstream enum member name and integer value resolves identically (MSO_SHAPE / MSO_THEME_COLOR / MSO_LINE_DASH_STYLE / MSO_FILL_TYPE / MSO_AUTO_SIZE / MSO_LANGUAGE_ID / PP_ACTION_TYPE / PP_PARAGRAPH_ALIGNMENT / XL_CHART_TYPE / XL_LEGEND_POSITION / XL_DATA_LABEL_POSITION / XL_TICK_MARK / XL_TICK_LABEL_POSITION / XL_AXIS_CROSSES / XL_CATEGORY_TYPE / XL_MARKER_STYLE).
- **57 canonical import paths verified** — every `from pptx.X import Y` statement from the python-pptx docs resolves. This includes the upstream subpackage layout (`pptx.shapes.autoshape`, `pptx.text.text`, `pptx.dml.fill`, `pptx.chart.axis`, `pptx.parts.image`, etc.).

**Test files**:
- `tests/test_python_pptx_api_parity.py` — class + enum surface parity.
- `tests/test_parity_class_hierarchy.py` — behavioural smoke tests.
- `tests/test_canonical_import_paths.py` — every canonical import statement works.

Run: `python -m pytest tests/test_python_pptx_api_parity.py tests/test_parity_class_hierarchy.py tests/test_canonical_import_paths.py -v`.

### Documented user-facing departures

A small number of REST-SDK-specific departures are documented in
[`docs/API_PARITY_EXCEPTIONS.md`](docs/API_PARITY_EXCEPTIONS.md):

- **`Presentation(filename)` not supported** — REST SDK uses
  `Presentation.upload(path)` or `Presentation(deck_id=…)` instead;
  there's no local OPC package to open.
- **`NotesSlide.shapes` / `.placeholders` / `.notes_placeholder`** not yet exposed —
  use `slide.notes_slide.notes_text_frame` for notes text.
- **`XyChartData.add_series(name, values)`** signature drift vs upstream's
  `add_series(name, number_format=None)` — caller passes inline tuples.
- **`TextFitter.best_fit_font_size()`** returns `max_size` unchanged
  (auto-fit is server-side); emits `RuntimeWarning`.
- **`_BaseSeriesData.index`** raises `NotImplementedError` (raising
  rather than silently returning 0).
- **`Package.open()`** raises `UnsupportedFeatureError`.

### Intentionally omitted (REST SDK limitations)

These standard python-pptx members are omitted because a REST SDK has no
local XML / OPC parts:
- `Shape.element`, `Shape.part` — XML element access.
- `TextFrame.part`, `Paragraph.part`, `Run.part` — package part access.
- `FillFormat.from_fill_parent()`, `ColorFormat.from_colorchoice_parent()` — internal XML constructors.
- `Font.fill` — Font fill format (uncommon; use `font.color` for text color).

`Font.language_id` IS now implemented (returns `MSO_LANGUAGE_ID` enum, accepts enum or int LCID) — added in v0.1.68.

### If you need a deviation

If there is a genuine technical reason why a deviation from python-pptx is necessary (e.g., the SDK is a REST client and cannot replicate XML-level behavior):

1. **Stop and ask the user** before implementing
2. Explain what the deviation is and why it's needed
3. Get explicit confirmation that the deviation is acceptable
4. Document the deviation in the table above

**Do NOT silently add convenience methods, aliases, or "improved" APIs.** The value of this SDK is that it's a drop-in replacement — any divergence breaks that contract.

## Development

```bash
# Install in editable mode
pip install -e ".[dev]"

# Run tests
python -m pytest tests/ -x -q

# Run specific test file
python -m pytest tests/test_sdk_features.py -x -q
```

## Architecture

This is a **REST API client** that mimics the python-pptx API. Instead of manipulating XML directly, method calls are translated to commands sent to the PPTX Studio API server. Key differences from python-pptx internals:

- No `_element`, `_sp`, `_spTree` XML attributes — these don't exist
- Operations are batched via `with prs.batch():` context manager
- State is synchronized via the PPTX Studio collaboration layer (Yjs)
- **Programmatic Tool Calling (PTC):** every `CommandBuffer.add` and
  `flush` emits begin/end events to agora via `pptx/_ptc.py` when run
  inside a Daytona sandbox with `ATHENA_PTC_URL` set. Each method call
  surfaces as a nested sub-tool-card under the parent
  `run_python_code` tool. See
  [`docs/PROGRAMMATIC_TOOL_CALLING_GUIDE.md`](../../docs/PROGRAMMATIC_TOOL_CALLING_GUIDE.md)
  at the monorepo root.
