# athena-python-pptx ↔ python-pptx — Open Parity Questions

A living index of open design questions, deferred work, and edge cases
that surface while expanding parity coverage. Sister doc to
[`API_PARITY_REPORT.md`](API_PARITY_REPORT.md) (status snapshot) and
[`docs/API_PARITY_EXCEPTIONS.md`](docs/API_PARITY_EXCEPTIONS.md) (intentional
deviations).

**Tracking style:** every item gets a heading + status + notes + owner.
Mark `RESOLVED` and link the PR when closed; leave the section in
place for context.

---

## OPEN — Server-side patch ops needed for full round-trip

Many of the SDK adapter classes shipped in v0.1.68 expose python-pptx-
canonical *local state* but don't yet round-trip to the exported `.pptx`
because the studio's chart-patch pipeline (`@pptx/chart-ooxml`) doesn't
have matching ops. The SDK setters are no-ops on export; the docstrings
flag this explicitly.

Concrete patch ops we'd need to wire:

- `SetCategoryAxisVisible(chart_id, visible)`
- `SetAxisGridlines(chart_id, which, has_major, has_minor)`
- `SetAxisScale(chart_id, axis, min, max, major_unit, minor_unit)`
- `SetAxisTickLabelFont(chart_id, axis, style)` — font sub-surface
- `SetAxisTitle(chart_id, axis, text)` — `axis.axis_title.text_frame.text`
- `SetLegendFont(chart_id, style)` — legend sub-surface
- `SetLegendPosition(chart_id, position)`
- `SetChartFont(chart_id, style)` — chart-wide default font
- `SetChartStyle(chart_id, style_id)` — 1..48 style ids
- `SetConnectorEndpoint(connector_id, which, target_shape_id, cxn_pt_idx)`
- `SetDataLabels(chart_id, series_id, ...)`
- `SetSeriesMarker(chart_id, series_id, style, size, color)`

**Why deferred:** each is a multi-system change (schema → applier →
ooxml-patch → maybe export-worker authoring). The SDK adapter surface
unblocks isinstance-style code and read-modify-write recipes today;
landing the patch ops is sequential work that doesn't belong on the
parity-expansion PR.

---

## OPEN — How should the SDK treat python-pptx's "private" classes?

Stock python-pptx exports several `_Underscore` classes that users still
reach for (`_Paragraph`, `_Run`, `_PlaceholderFormat`, `_Cell`, etc.).
We've been matching them as the canonical surface and exposing public
names where it makes sense (e.g. `Paragraph` instead of `_Paragraph` in
`pptx.text`).

**Decision rule we've been following:** match python-pptx's import name
exactly when user code is likely to import it; use a public name when
the class is only reached via accessors. Document both via `from pptx.X
import Foo` aliases. The parity test imports the upstream name and
compares against our SDK name; the mapping lives in `PARITY_CLASSES`.

**Still open:** there are ~10 more `_X` adapter classes we've added in
v0.1.68 (`_AxisTitle`, `_TickLabels`, etc.) that should probably be
public. Tranche B in this PR's followup will rename them.

---

## OPEN — Detached `Font(run=None)` shape

`Chart.font`, `_ChartLegend.font`, `_TickLabels.font` (and other chart-
adjacent font surfaces) return `Font(run=None)`. After v0.1.68's
`_emit_style_change` guard, these are local-state-only — mutations don't
round-trip on export.

**Question:** should detached fonts share a single backing instance per
adapter (caching, current behaviour) or should each chart sub-element
have its own field on the chart spec that the adapter mutates?

The latter is more correct (write-and-forget consistency with a future
`SetChartFont` patch) but invasive. The former is what we ship today; it
satisfies `read-modify-write` survival within a single Python process
but doesn't persist across processes.

---

## OPEN — `Connector.begin_connect(None)` semantics

python-pptx raises `TypeError` when binding a connector endpoint to a
`None` target. Athena currently records `shapeId: None` via
`getattr(shape, "shape_id", None)`. The risk is small (None shapeId
serializes harmlessly server-side) but the API contract differs.

**Action:** add a `None`-check + `TypeError` in `Connector.begin_connect`
/ `end_connect`. Low priority; not on the immediate path.

---

## OPEN — `Font.language_id == MSO_LANGUAGE_ID.NONE`

`MSO_LANGUAGE_ID.NONE` is `0` (the enum's "no language specified"
sentinel). Setting `font.language_id = MSO_LANGUAGE_ID.NONE` stores `0`
in `_language_id`, which lands on the wire as `languageId: 0`.

**Question:** does the studio's export side treat `languageId: 0` as
"unset" (drops the `@lang` attribute) or as a literal locale (`@lang=""`
or `@lang="x-none"`)?

We need the server-side behaviour documented; for now the SDK round-
trips the integer faithfully.

---

## OPEN — `MSO_LANGUAGE_ID` lacks the OOXML string-code mapping

Our enum only stores the integer LCIDs (e.g. `ENGLISH_US = 1033`).
python-pptx's `BaseXmlEnum` carries the OOXML string code too
(`"en-US"`). For full export-side support we'll eventually need the
mapping — either inline in `pptx/enum/lang.py` or as a side table the
export-worker consults.

---

## OPEN — `Picture.image` is `None`

Stock python-pptx returns an `Image` with `.blob` / `.content_type` /
`.filename`. The REST SDK doesn't materialize raw image bytes back
into Python — they live in the studio's asset store reachable via a
rendered URL.

**Decision:** keep `Picture.image` returning `None`; agent code that
needs raw bytes can fetch from the studio API. Document in
`API_PARITY_EXCEPTIONS.md`. (Already documented in v0.1.68.)

---

## OPEN — `GroupShape.shapes` returns `[]`

Athena's snapshot keeps grouped shapes as flat slide-level siblings
with a synthetic group anchor; children aren't re-parented to the
group. python-pptx's `GroupShape.shapes` is a real child collection.

**Action:** plumb a `parentGroupId` on each Y.Doc element so
`group.shapes` can enumerate them. Multi-layer change: ingest →
snapshot → SDK. Deferred to a focused PR.

---

## OPEN — Chart axis adapters use local state, not chart spec

`CategoryAxis.visible = False` mutates the adapter's `_visible: bool`
field, NOT the chart's stored spec. After process restart, the value is
lost. This is intentional for now (no `SetAxis*` patch op exists) but
needs a design pass before we wire chart-axis round-tripping.

**Open question:** should the adapter mirror its state onto the chart
element's `properties.axis*` dict so it survives Y.Doc serialization
even before the patch ops exist? Risk: silent fidelity loss if the dict
gets read by other code paths expecting empty.

---

## OPEN — Should `shape.click_action` return `ActionSetting` (canonical) or `ClickAction` (SDK-native)?

Today: returns `ClickAction` for backward compat with the existing
SDK tests; user can wrap manually via `ActionSetting(shape.click_action)`.

**Future:** the canonical python-pptx pattern is
`shape.click_action.action = PP_ACTION.NEXT_SLIDE`, which requires
`shape.click_action` to be an `ActionSetting`. Switching would need a
migration of the existing SDK tests (they assert on the string-typed
action). Not breaking-change-friendly; deferred until we're ready for a
v0.2.0 cut.

---

## OPEN — `MSO_LANGUAGE_ID.MIXED == -2`

python-pptx uses `MIXED = -2` for "more than one language in specified
range (read-only)". Our enum carries it but nothing produces it. Should
the SDK ever return `MIXED` for ranges that span multiple runs with
different `language_id` values? Probably not — runs are individually
addressable in our model — but it's worth noting that this enum value
is unlikely to ever round-trip from upstream content.

---

## RESOLVED — Detached `Font(run=None)` crashed on setter

Fixed in v0.1.68 (commit `79b826b051`): `_emit_style_change` guards
`self._run is None` and no-ops, matching the stub-adapter "local-state-
only" docstrings.

---

## RESOLVED — `_add_shape_from_snapshot` always created bare `Shape`

Fixed in v0.1.68: routes `image` / `connector` / `group` elements to
the type-aware constructor, same as `Shapes.__init__`.

---

## RESOLVED — `Font.language_id` getter discarded unknown LCIDs

Fixed in v0.1.68: getter returns the raw int for LCIDs not in our
`MSO_LANGUAGE_ID` enum, preserving round-trip. Previously corrupted to
`None`.

---

## RESOLVED — Read-modify-write lost writes on chart axis sub-adapters

Fixed in v0.1.68: `_BaseChartAxis.major_gridlines` / `tick_labels` are
now cached per-axis. `Chart.font` / `_ChartLegend.font` / `_TickLabels.font`
also cached. `ax.tick_labels.number_format = "0.0%"` survives the next
read.

---

## Followups inventory (from the 2026-05-11 Explore-agent pass)

Tracked in this PR's followup commits — see commit log for status.

| Tranche | Classes | Status |
|---|---|---|
| A | `Pt`, `Cm`, `Inches`, `Emu`, `Mm`, `Centipoints`, `Length`; `CategoryChartData`, `XyChartData`, `BubbleChartData`, `Categories`, `Category`; `GraphicFrame` | (working) |
| B | Public-rename `_AxisTitle`/`_MajorGridlines`/`_TickLabels`/`_ChartFormat`/`_ChartLegend` → `AxisTitle`/`MajorGridlines`/`TickLabels`/`ChartFormat`/`Legend` | (working) |
| C | `ShadowFormat.inherit` | (working) |
| D | `BarPlot`/`LinePlot`/`PiePlot`/etc. + `BarSeries`/`LineSeries`/etc. | (working) |
| E | `DataLabels`, `DataLabel`, `Marker`, `Point`, `CategoryPoints`, `XyPoints`, `BubblePoints` | (working) |
| F | `Adjustment`, `AdjustmentCollection`, `AutoShapeType` | (working) |
| G | `Movie`, `Video`, `_MediaFormat` | (working) |
| H | `SlidePlaceholder`, `ChartPlaceholder`, `PicturePlaceholder`, `TablePlaceholder`, `PlaceholderGraphicFrame`, `PlaceholderPicture`, `LayoutPlaceholder`, `MasterPlaceholder`, `NotesSlidePlaceholder` | (working) |
| I | `FreeformBuilder` + drawing ops | (working) |
| J | `LayoutShapes`, `MasterShapes`, `NotesSlideShapes`, `GroupShapes` | v0.1.71 |
| K | `BasePlaceholders`, `LayoutPlaceholders`, `MasterPlaceholders`, `NotesSlidePlaceholders` + SlidePlaceholders parity entry | v0.1.71 |
| L | `NotesMaster`, NotesSlide parity entry | v0.1.71 |
| M | `CategoryDataPoint`, `XyDataPoint`, `BubbleDataPoint`, `CategoryLevel` | v0.1.71 |
| N | `ChartData` (alias), `ChartTitle`, `DateAxis`, `Area3DPlot` | v0.1.71 |
| O | `BaseShape = Shape` alias | v0.1.71 |
| P | `SlideLayouts`, `SlideMasters` parity entries; `SlideLayouts.get_by_name(default=…)` kwarg | v0.1.71 |

### v0.1.71 open follow-ups

These were closed in name/parity-surface this round but have known
gaps in the round-trip layer; tracked here for visibility:

- **NotesSlide.shapes / NotesSlide.placeholders / .notes_placeholder /
  .clone_master_placeholders / .background / .name** — currently
  allowlisted under `KNOWN_MISSING["NotesSlide"]`. We expose
  `slide.notes_slide.notes_text_frame` as the working notes path;
  the broader shape/placeholder accessors await a notes-master
  patch op (server-side).
- **NotesMaster.background / NotesMaster.name** — same story; the
  NotesMaster adapter is a placeholder for `isinstance` parity.
- **DateAxis.category_type** — pending. The `DateAxis` adapter
  inherits the full `_BaseChartAxis` surface; date-specific
  semantics (`category_type = "auto" | "category" | "date" | "time"`)
  is not yet plumbed.
- **Area3DPlot** — currently behaves identically to `AreaPlot`;
  3D-specific properties (perspective, depth) are a follow-up.
- **ChartTitle.format** — pending the ChartFormat server-side patch
  op (already tracked for other adapters).
- **SlideLayouts.index / .remove** — pending; layout removal /
  reorder is server-side.

---

## v0.1.72 — Full public-class parity reached (Tranches R-W)

**0 uncovered upstream public classes**: every class in
`python-pptx` 1.0.2's public surface has an importable counterpart at
the matching module path in athena-python-pptx.

| Tranche | Classes | Surface | Notes |
|---|---|---|---|
| R | `PythonPptxError`, `PackageNotFoundError`, `InvalidXmlError` | Real | `PythonPptxError` is an alias of `PptxSdkError`. |
| S | `ElementProxy`, `ParentedElementProxy`, `PartElementProxy`, `Subshape`, `ProvidesExtents`, `ProvidesPart` | Stub | REST SDK has no XML elements; classes provided for `isinstance`/type-annotation parity. |
| T | 15 Part stubs (`BaseSlidePart`, `SlidePart`, `SlideLayoutPart`, `SlideMasterPart`, `NotesSlidePart`, `NotesMasterPart`, `PresentationPart`, `CorePropertiesPart`, `ImagePart`, `EmbeddedPackagePart`, `EmbeddedDocxPart`, `EmbeddedPptxPart`, `EmbeddedXlsxPart`, `MediaPart`, `ChartPart`) | Stub | REST SDK has no OPC parts; reach core properties via deck metadata, images via the studio asset store. |
| U | `Image`, `Package`, `ChartWorkbook`, `FontFiles`, `TextFitter`, `PlotTypeInspector`, `ShapeSpec` | Real (Image) / Stub | Image has real blob/sha1/from_blob/from_file. Package.open() raises pointing callers at Presentation.upload(). |
| V | `CategorySeriesData`, `XySeriesData`, `BubbleSeriesData`, `CategoryWorkbookWriter`, `XyWorkbookWriter`, `BubbleWorkbookWriter` | Stub | Series-data classes implement Sequence protocol; workbook writers are stubs because the studio handles chart-data XLSX generation. |
| W | `Shape` (autoshape variant) | Aliased | Upstream has `BaseShape → Shape`; our root `Shape` plays both roles. |

### v0.1.72 open follow-ups (server-side work, not parity-test gaps)

These are real features that exist on the upstream Parts/Packages but
that the REST SDK can't reproduce without server-side patch ops. The
class surfaces are in place; only the implementations are stubs:

- **Image bytes** — `Picture.image.blob` returns `b""` because images
  live in the studio's asset store, not Python. To fetch the bytes
  use the studio asset API (out of band).
- **Core document properties (`CorePropertiesPart`)** — author /
  title / created / modified / etc. The REST SDK exposes some of
  these via deck metadata APIs but doesn't yet plumb them through
  `Presentation.core_properties` for parity. Tracked as a follow-up.
- **Embedded OLE objects** (`EmbeddedDocxPart` / `EmbeddedPptxPart`
  / `EmbeddedXlsxPart`) — upstream supports embedding one Office doc
  inside another. Not yet supported by the studio; would need a
  server-side `AddEmbeddedObject` patch op.
- **`Package.save()`** — upstream serializes the OPC package to a
  file. The REST SDK uses `Presentation.save()` which exports a
  PPTX from the studio side; the underlying flow is different.
- **`TextFitter` auto-fit** — upstream binary-searches font sizes
  locally; we return `max_size` unchanged and let the server / Skia
  measurement handle auto-fit. A future improvement would call the
  server's text-measurement endpoint.
- **`PlotTypeInspector`** — upstream classifies a plot from XML; we
  delegate to the plot's `chart_type` attribute. Adequate for
  parity but not a 1:1 behavioural match.

These are documented per-class in `pptx/parts/*.py` and
`pptx/{exc,shared,types,spec,package}.py` so users see the gap
clearly when reading the class docstrings.
