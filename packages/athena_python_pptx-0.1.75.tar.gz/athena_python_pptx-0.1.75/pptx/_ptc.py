"""Programmatic Tool Calling (PTC) — client side, docx SDK.

Activated only when ``ATHENA_PTC_URL`` is set. The URL is a presigned
endpoint URL with an HMAC-signed token embedded as ``?t=…``; the token
carries the (thread, parent_tool_call_id, run) triple and an expiry.
The SDK doesn't need to know that triple — it just POSTs to the URL
verbatim, and the server derives identity from the token.

Without ``ATHENA_PTC_URL`` set, every call here is a no-op.

Emits are fire-and-forget on a background daemon thread:

- Never raise into user code.
- Never block the calling thread.
- Re-read ``ATHENA_PTC_URL`` on every emit so updates between sandbox
  executions take effect immediately (the SDK module itself is cached
  across runs).
- Snapshot the URL at ``emit_begin`` time and carry it to ``emit_end``
  so late end events can't be misattributed if a new sandbox run
  swapped in a different URL between begin and end.

This module is *intentionally* duplicated into the pptx and xlsx SDKs
— the three SDKs have no shared base. Keeping it byte-identical
(modulo ``_LIB_NAME``) makes diffs trivial.
"""

from __future__ import annotations

import json
import os
import queue
import threading
import time
import urllib.error
import urllib.request
import uuid
from typing import Any

_LIB_NAME = "pptx"

_MAX_QUEUE = 4096
_MAX_BODY = 64 * 1024
_HTTP_TIMEOUT = 2.0

_PTC_URL_ENV = "ATHENA_PTC_URL"


def _read_url() -> str | None:
    url = os.environ.get(_PTC_URL_ENV)
    return url if url else None


def _utcnow_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S.000Z", time.gmtime())


class _PTCClient:
    def __init__(self) -> None:
        # Lazy: don't snapshot URL at import time; runs change between
        # sandbox executions and the module is cached in sys.modules.
        self._q: queue.Queue[tuple[str, dict[str, Any]] | None] = queue.Queue(
            maxsize=_MAX_QUEUE,
        )
        self._started = False
        self._lock = threading.Lock()
        # call_id -> URL snapshot at begin time. Lets emit_end target
        # the original run's endpoint even if env changed since.
        self._call_url: dict[str, str] = {}

    def _ensure_started(self) -> None:
        if self._started:
            return
        with self._lock:
            if self._started:
                return
            t = threading.Thread(
                target=self._drain,
                name=f"athena-{_LIB_NAME}-ptc",
                daemon=True,
            )
            t.start()
            self._started = True

    def emit_begin(self, tool_name: str, args: dict[str, Any]) -> str:
        call_id = uuid.uuid4().hex
        url = _read_url()
        if url is None:
            return call_id
        self._call_url[call_id] = url
        self._ensure_started()
        body = {
            "callId": call_id,
            "toolName": f"{_LIB_NAME}.{tool_name}",
            "phase": "begin",
            "args": args,
            "ts": _utcnow_iso(),
        }
        self._enqueue(url, body)
        return call_id

    def emit_end(
        self,
        *,
        call_id: str,
        tool_name: str,
        result: dict[str, Any] | None,
        is_error: bool,
    ) -> None:
        url = self._call_url.pop(call_id, None)
        if url is None:
            return  # PTC was disabled at begin, or begin wasn't emitted
        body = {
            "callId": call_id,
            "toolName": f"{_LIB_NAME}.{tool_name}",
            "phase": "end",
            "result": result,
            "isError": is_error,
            "ts": _utcnow_iso(),
        }
        self._enqueue(url, body)

    def _enqueue(self, url: str, body: dict[str, Any]) -> None:
        try:
            self._q.put_nowait((url, body))
        except queue.Full:
            pass  # drop on backpressure; never block user code

    def _drain(self) -> None:
        while True:
            item = self._q.get()
            if item is None:
                return
            url, body = item
            try:
                raw = json.dumps(body).encode("utf-8")
                if len(raw) > _MAX_BODY:
                    truncated_key = "args" if body.get("phase") == "begin" else "result"
                    body[truncated_key] = {"__truncated__": True}
                    raw = json.dumps(body).encode("utf-8")
                req = urllib.request.Request(
                    url,
                    data=raw,
                    method="POST",
                    headers={"Content-Type": "application/json"},
                )
                urllib.request.urlopen(req, timeout=_HTTP_TIMEOUT).close()
            except (urllib.error.URLError, OSError, ValueError):
                pass  # never propagate


_CLIENT = _PTCClient()


def emit_begin(tool_name: str, args: dict[str, Any]) -> str:
    return _CLIENT.emit_begin(tool_name, args)


def emit_end(
    *,
    call_id: str,
    tool_name: str,
    result: dict[str, Any] | None,
    is_error: bool,
) -> None:
    _CLIENT.emit_end(
        call_id=call_id,
        tool_name=tool_name,
        result=result,
        is_error=is_error,
    )


__all__ = ["emit_begin", "emit_end"]
