"""
Command batching and transaction support.

Provides the `CommandBuffer` for collecting commands and the
context manager interface for batch operations.
"""

from __future__ import annotations
import threading
from contextlib import contextmanager
from threading import local
from typing import TYPE_CHECKING, Any, Generator, Optional

from . import _ptc
from .commands import AnyCommand
from .typing import CommandsResponse

if TYPE_CHECKING:
    from .client import Client


def _ptc_emit_end_batch(cmds: list[AnyCommand], *, is_error: bool) -> None:
    """Emit a PTC ``end`` event for every cmd that received a ``begin``."""
    for c in cmds:
        call_id = getattr(c, "_ptc_call_id", None)
        if not call_id:
            continue
        try:
            _ptc.emit_end(
                call_id=call_id,
                tool_name=type(c).__name__,
                result={"ok": not is_error}
                if not is_error
                else {"ok": False, "error": "command batch failed"},
                is_error=is_error,
            )
        except Exception:  # noqa: BLE001
            pass


class CommandBuffer:
    """
    Buffer for collecting commands before sending to server.

    By default, commands are buffered (batch mode) and sent when flush()
    is called. This avoids one HTTP round-trip per operation.

    An auto-flush timer (default 2.0s) automatically flushes pending commands
    after an idle period. This ensures commands are not silently lost in
    persistent process environments (e.g. Daytona) where atexit never fires.

    Usage:
        # Default: commands are buffered
        buffer.add(AddTextBox(...))
        buffer.add(SetText(...))
        buffer.flush()  # sends both in one request

        # Explicit batch context (flushes on exit)
        with buffer.batch():
            buffer.add(AddTextBox(...))
            buffer.add(SetText(...))
        # Both commands sent here in one request

        # Immediate mode: each command sent separately
        buffer = CommandBuffer(client, deck_id, auto_batch=False)
        buffer.add(AddTextBox(...))  # sent immediately
    """

    def __init__(
        self,
        client: Client,
        deck_id: str,
        auto_batch: bool = True,
        auto_flush_seconds: Optional[float] = 2.0,
    ):
        """
        Initialize the command buffer.

        Args:
            client: HTTP client for sending commands
            deck_id: ID of the deck to operate on
            auto_batch: If True (default), buffer commands until flush().
                       If False, send each command immediately (legacy behavior).
            auto_flush_seconds: Seconds of idle time before auto-flushing
                       pending commands. Set to 0 or None to disable.
                       Default 2.0s. Ignored when auto_batch is False.
        """
        self._client = client
        self._deck_id = deck_id
        self._commands: list[AnyCommand] = []
        self._batch_depth = 0
        self._auto_batch = auto_batch
        self._last_response: Optional[CommandsResponse] = None
        self._auto_flush_seconds = auto_flush_seconds
        self._flush_timer: Optional[threading.Timer] = None
        self._timer_lock = threading.Lock()

    @property
    def is_batching(self) -> bool:
        """Return True if currently in batch mode."""
        return self._batch_depth > 0

    @property
    def pending_count(self) -> int:
        """Return the number of pending commands."""
        return len(self._commands)

    @property
    def last_response(self) -> Optional[CommandsResponse]:
        """Return the last response from the server."""
        return self._last_response

    def add(self, command: AnyCommand) -> Optional[CommandsResponse]:
        """
        Add a command to the buffer.

        When auto_batch is True (default) or inside a batch() context,
        commands are buffered until flush() is called.
        When auto_batch is False and not in a batch() context,
        the command is sent immediately.

        Args:
            command: Command to add

        Returns:
            Response if sent immediately, None if buffered
        """
        # PTC begin: one event per user-facing method call, before batching.
        try:
            command._ptc_call_id = _ptc.emit_begin(  # type: ignore[attr-defined]
                type(command).__name__,
                command.to_dict(),
            )
        except Exception:  # noqa: BLE001
            pass

        self._commands.append(command)

        if not self._auto_batch and not self.is_batching:
            return self.flush()
        # Schedule auto-flush if enabled and not inside explicit batch()
        if self._auto_flush_seconds and self._auto_flush_seconds > 0 and not self.is_batching:
            self._schedule_auto_flush()
        return None

    def _schedule_auto_flush(self) -> None:
        """Reset the debounce timer. Flush fires after idle period."""
        with self._timer_lock:
            if self._flush_timer is not None:
                self._flush_timer.cancel()
            self._flush_timer = threading.Timer(
                self._auto_flush_seconds,  # type: ignore[arg-type]
                self._auto_flush,
            )
            self._flush_timer.daemon = True  # Don't block process exit
            self._flush_timer.start()

    def _auto_flush(self) -> None:
        """Called by timer thread. Flush if still have pending commands."""
        with self._timer_lock:
            self._flush_timer = None
        if self._commands and not self.is_batching:
            try:
                self.flush()
            except Exception:
                pass

    def _cancel_timer(self) -> None:
        """Cancel the pending auto-flush timer if any."""
        with self._timer_lock:
            if self._flush_timer is not None:
                self._flush_timer.cancel()
                self._flush_timer = None

    def flush(self) -> Optional[CommandsResponse]:
        """
        Send all buffered commands to the server.

        Returns:
            Server response, or None if no commands to send
        """
        self._cancel_timer()

        if not self._commands:
            return None

        commands = self._commands
        self._commands = []

        try:
            self._last_response = self._client.post_commands(
                self._deck_id,
                commands,
                return_snapshot=True,
            )
        except Exception:
            _ptc_emit_end_batch(commands, is_error=True)
            raise
        _ptc_emit_end_batch(commands, is_error=False)
        return self._last_response

    def clear(self) -> None:
        """Clear all pending commands without sending."""
        self._cancel_timer()
        self._commands = []

    @contextmanager
    def batch(self) -> Generator[CommandBuffer, None, None]:
        """
        Context manager for batch operations.

        Commands added within this context are buffered and sent
        as a single request when the context exits.

        Example:
            with buffer.batch():
                buffer.add(AddTextBox(...))
                buffer.add(SetText(...))
            # Both commands sent here in one request

        Yields:
            self for chaining
        """
        self._batch_depth += 1
        try:
            yield self
        finally:
            self._batch_depth -= 1
            if self._batch_depth == 0:
                self.flush()


# Thread-local storage for the active batch context
_context = local()


def get_active_buffer() -> Optional[CommandBuffer]:
    """Get the currently active command buffer (if in a batch context)."""
    return getattr(_context, "buffer", None)


def set_active_buffer(buffer: Optional[CommandBuffer]) -> None:
    """Set the active command buffer for the current thread."""
    _context.buffer = buffer


@contextmanager
def batch_context(buffer: CommandBuffer) -> Generator[CommandBuffer, None, None]:
    """
    Context manager that sets the active buffer for the thread.

    This allows proxy objects to automatically use the correct buffer
    without needing explicit references.
    """
    previous = get_active_buffer()
    set_active_buffer(buffer)
    try:
        with buffer.batch():
            yield buffer
    finally:
        set_active_buffer(previous)
