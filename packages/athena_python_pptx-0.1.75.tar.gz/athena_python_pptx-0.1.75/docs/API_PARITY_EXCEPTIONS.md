# athena-python-pptx API Parity Exceptions

This document lists all intentional deviations from the standard [python-pptx](https://python-pptx.readthedocs.io/) API in the athena-python-pptx SDK.

The SDK's goal is 1:1 API parity with python-pptx. These exceptions exist because the SDK is a REST client (no local XML), or because LLM agents need ergonomic aliases for common patterns.

---

## REST SDK Limitations (python-pptx members that don't apply)

These standard python-pptx members are omitted because a REST SDK has no access to the underlying XML or package structure:

| Member | Reason |
|--------|--------|
| `Shape.element`, `Shape.part` | XML element access (no local XML) |
| `TextFrame.part`, `Paragraph.part`, `Run.part` | Package part access |
| `FillFormat.from_fill_parent()` | Internal constructor |
| `ColorFormat.from_colorchoice_parent()` | Internal constructor |
| `Font.fill` | Font fill format (uncommon) |
| `Font.language_id` | Implemented in v0.1.68 (returns `MSO_LANGUAGE_ID` enum, accepts enum or int LCID) |

---

## User-Facing Departures (read these — they may surprise you)

These are documented intentional differences in behavior where the
SDK doesn't yet match python-pptx's API one-for-one.

### `NotesSlide.shapes` / `.placeholders` / `.notes_placeholder` / `.background` / `.name` — not yet exposed

Upstream's `NotesSlide` exposes a full shape tree (`notes_slide.shapes`,
`notes_slide.placeholders`, etc.) so user code can iterate or inspect
every shape on the notes page. **Our SDK only exposes
`notes_slide.notes_text_frame`** — the body-placeholder text frame.

**Workaround:** Read/write notes content via:

```python
# Set notes text
slide.notes_slide.notes_text_frame.text = "Speaker notes here."

# Read notes text
text = slide.notes_slide.notes_text_frame.text
```

A future server-side notes-master patch op will plumb the full shape
tree through. Tracked in `PARITY_QUESTIONS.md`.

### `XyChartData.add_series()` — different signature

Upstream signature: `add_series(name, number_format=None)` — caller adds
data points via the returned series object.

**Our signature:** `add_series(name, values)` — caller passes the
(x, y) tuples up front.

**Migration:**

```python
# python-pptx pattern (NOT supported by athena-python-pptx):
series = data.add_series("Series 1")
series.add_data_point(1.0, 2.0)
series.add_data_point(3.0, 4.0)

# athena-python-pptx pattern (use this):
data.add_series("Series 1", [(1.0, 2.0), (3.0, 4.0)])
```

Same applies to `BubbleChartData.add_series`. Fixing this is a larger
refactor (the SDK's chart-authoring path expects values inline);
tracked in `PARITY_QUESTIONS.md`.

### `TextFitter.best_fit_font_size()` — returns `max_size` unchanged

Upstream binary-searches font sizes locally to fit text within bounds.
Our stub always returns `max_size` and emits a `RuntimeWarning`.
Auto-fit happens server-side at render time. **Don't rely on this for
local layout decisions**; use the auto-fit text frame property instead:

```python
from pptx.enum.text import MSO_AUTO_SIZE
text_frame.auto_size = MSO_AUTO_SIZE.TEXT_TO_FIT_SHAPE
```

### `_BaseSeriesData.index` — raises `NotImplementedError`

Upstream's `CategorySeriesData.index` returns the series's offset
within its parent chart-data. Our stub raises rather than silently
returning `0` (which would corrupt any OOXML `<c:idx>` builder that
trusts the value). If you need the series index, track it externally.

### `Package.open(pkg_file)` — raises `UnsupportedFeatureError`

Upstream's `Package.open(path)` loads a `.pptx` file into the OPC
adapter. The REST SDK has no OPC; use `Presentation.upload(path)`
instead, which uploads the file to the studio backend and returns
a `Presentation` adapter.

---

## Agent-Friendly Additions (not in python-pptx)

These properties/methods were added because LLM agents (Claude, GPT, etc.) frequently generate code using these patterns. Without them, agent-generated table code fails at runtime.

### `TableCell` — RGB tuple aliases

| Property | Type | Maps to | Why |
|----------|------|---------|-----|
| `cell.font_bold` | `bool` | `cell.bold` | Agents write `cell.font_bold = True` instead of `cell.bold = True` |
| `cell.font_color_rgb` | `tuple(R,G,B)` | `cell.font_color_hex` | Agents write `cell.font_color_rgb = (255, 255, 255)` instead of `cell.font_color_hex = "FFFFFF"` |
| `cell.fill_color_rgb` | `tuple(R,G,B)` | `cell.fill` (hex) | Agents write `cell.fill_color_rgb = (31, 57, 100)` instead of `cell.fill = "1F3964"` |

**Example of the agent pattern these support:**

```python
# LLM agents commonly generate this pattern:
cell = tbl.cell(0, 0)
cell.text = "Header"
cell.font_size_pt = 14
cell.font_bold = True
cell.font_color_rgb = (255, 255, 255)
cell.fill_color_rgb = (31, 57, 100)
```

### `GraphicFrame` — Table passthrough methods

In python-pptx, `add_table()` returns a `GraphicFrame` and the table is accessed via `.table`. However, agents frequently call `.cell()`, `.rows`, `.cols` directly on the return value. These passthroughs prevent `AttributeError`:

| Member | Delegates to |
|--------|-------------|
| `graphic_frame.cell(row, col)` | `graphic_frame.table.cell(row, col)` |
| `graphic_frame.rows` | `graphic_frame.table.rows` |
| `graphic_frame.cols` | `graphic_frame.table.cols` |

**Example:**

```python
# Both patterns work:
tbl = slide.shapes.add_table(rows=3, cols=3, ...)

# Pattern 1: python-pptx canonical
tbl.table.cell(0, 0).text = "Header"

# Pattern 2: agent shortcut (also works)
tbl.cell(0, 0).text = "Header"
```

---

## Structural Deviations (python-pptx behavior differs)

### `Table.first_row` / `Table.last_row` — Boolean look flags, not cell lists

In python-pptx, `Table.first_row` and `Table.last_row` are boolean properties controlling table style look flags (whether the first/last row gets special styling).

In a prior version of this SDK, these were cell-list properties returning `list[TableCell]`. They have been changed to match python-pptx (boolean). The old cell-list accessors are available as methods:

| Old (removed) | New (python-pptx parity) | Cell-list replacement |
|---------------|-------------------------|----------------------|
| `table.first_row` → `list[TableCell]` | `table.first_row` → `bool` | `table.get_first_row_cells()` |
| `table.last_row` → `list[TableCell]` | `table.last_row` → `bool` | `table.get_last_row_cells()` |
| `table.first_column` → `list[TableCell]` | (not a python-pptx property) | `table.get_first_column_cells()` |
| `table.last_column` → `list[TableCell]` | (not a python-pptx property) | `table.get_last_column_cells()` |

### `Shapes.add_table()` — Returns `GraphicFrame`, not `Table`

Changed to match python-pptx semantics. `add_table()` returns a `GraphicFrame`. Access the `Table` via `.table`. The passthrough methods above ensure backward compatibility for code that calls `.cell()` directly.

### `_Row` / `_Column` with height/width setters

python-pptx's `_Row.height` and `_Column.width` are read/write EMU properties. This SDK matches that API, but setting them also emits SDK commands (`SetRowHeight`, `SetColWidth`) to the server.

### `Table.rows` / `Table.columns` — Return `_RowCollection` / `_ColumnCollection`

In python-pptx, `Table.rows` returns a `_RowCollection` of `_Row` objects (each with `.height`). This SDK matches that. In a prior version, `Table.rows` returned a flat collection of cell lists.

---

## Non-Standard Convenience Methods (candidates for future cleanup)

These exist on `TextFrame`, `Paragraph`, `Run`, `TableCell`, and `Table` but are NOT in python-pptx:

- `to_dict()`, `word_count`, `capitalize()`, `upper()`, `lower()`, `title()`, `strip()`, `is_empty`
- `Table.to_csv()`, `Table.to_list()`, `Table.to_dict_list()`, `Table.all_text`, `Table.contains_text()`, `Table.find_cells()`
- `TableCell.address` (A1 notation), `TableCell.copy_from()`, `TableCell.clear()`

These are convenience methods for agents and don't conflict with python-pptx API (python-pptx doesn't have them, so there's no behavioral difference).

## OOXML Run Properties Not Surfaced by python-pptx

Stock python-pptx's `Font` class exposes `bold`, `italic`, `underline`, `size`, `name`, `color`, `fill`, and `language_id`, but doesn't surface every OOXML `a:rPr` attribute. The SDK adds three properties for run shapes that are commonly needed for content fidelity:

| Property | OOXML | Type | Meaning |
|----------|-------|------|---------|
| `font.strike` | `a:rPr/@strike` | `bool \| None` | `True` → `sngStrike` (strikethrough), `False` → `noStrike`, `None` → inherit |
| `font.subscript` | `a:rPr/@baseline` | `bool \| None` | `True` → negative baseline percentage (default `-25000`), inherits otherwise |
| `font.superscript` | `a:rPr/@baseline` | `bool \| None` | `True` → positive baseline percentage (default `30000`), inherits otherwise |

These are accepted on the SDK and round-trip through the OOXML export. Removing them would lose useful fidelity, so they stay despite not appearing in `python-pptx`'s public `Font` API.
