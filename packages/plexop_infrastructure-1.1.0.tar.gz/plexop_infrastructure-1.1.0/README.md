Package with Plexop Python infrastructure
Include 
	* Logger decorator
	* Config decorator
	* Requests decorator
	* Some boto3 stuff decorators

Install from http://static.plexop.com/packages/python/plexop-infrastructure-latest.tar.gz

in order to upgrade dependencies:
cd C:\Projects\python-lambda-infrastructure-layer
pip install --upgrade -r requirements.txt --target=C:\Projects\python-lambda-infrastructure-layer\env\Lib\site-packages

# Installation
* The layer can be used as pip-installable package and as a lambda layer.  
* Packages are located in `s3://static-plexop/packages/python/plexop-infrastructure`. Open a given version and copy it's URL.
    * It can be installed via e.g. `pip install http://static.plexop.com/packages/python/plexop-infrastructure-0.2.8.tar.gz`
    * Latest version is always here: http://static.plexop.com/packages/python/plexop-infrastructure-latest.tar.gz

# Deployment
* Each commit to this repo will create a new version (both on s3 & layer) with version name <branch>-<commit>-<date>
* To deploy a given commit to PROD, create a new branch based off this commit and name the branch with some semantic version and add a `-release` suffix (e.g. `1.3-release`)