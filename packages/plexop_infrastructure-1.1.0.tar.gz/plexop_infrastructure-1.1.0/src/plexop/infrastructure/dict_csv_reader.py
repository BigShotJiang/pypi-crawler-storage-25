import csv


def read_file(csv_file_path, delimiter='\t'):
    results = []
    with open(csv_file_path) as csv_file:
        reader = csv.DictReader(csv_file, delimiter=delimiter)
        for row in reader:
            results.append(row)

    return results
