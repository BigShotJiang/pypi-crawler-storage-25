import boto3
import json
from plexop.infrastructure import config, logger


class S3:
    def __init__(self, region=None, profile_name=None):
        region = region or config.get('s3', 'region', fallback=None)
        profile_name = profile_name or config.get('s3', 'profile_name', fallback=None)
        self.client = boto3.session.Session(profile_name=profile_name, region_name=region).client('s3')

    def read(self, bucket_name, key, read_as_json=True, suppress_404_exception=False, is_binary=False):
        try:
            logger.debug("try to read from S3", bucket_name=bucket_name, key=key)
            file = self.client.get_object(Bucket=bucket_name, Key=key)
            file_content = file['Body'].read()
            if is_binary:
                logger.debug("binary data loaded from S3")
                return file_content
            file_content = file_content.decode('utf-8')
            if read_as_json:
                json_result = json.loads(file_content)
                logger.debug("json content loaded from S3", result=json_result)
                return json_result
            else:
                logger.debug("content loaded from S3", result=file_content)
                return file_content
        except Exception as ex:
            if hasattr(ex, 'response') and ex.response['Error']['Code'] == 'NoSuchKey' and suppress_404_exception:
                logger.info("File not found", bucket_name=bucket_name, key=key)
                return
            logger.exception(ex)
            raise

    def save(self, bucket_name, key, body):
        logger.debug("try to put object to S3", bucket_name=bucket_name, key=key, body=body)
        if isinstance(body, dict):
            body = json.dumps(body)
        result = self.client.put_object(Bucket=bucket_name, Key=key, Body=body)
        logger.debug("content saved", result=result)
        return result
