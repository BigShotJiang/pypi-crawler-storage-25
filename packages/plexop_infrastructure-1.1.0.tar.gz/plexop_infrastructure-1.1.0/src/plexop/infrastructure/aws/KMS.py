import boto3
import json
import base64
from plexop.infrastructure import config, logger


class KMS:
    def __init__(self):
        kms_region = config.get('kms', 'region')
        self.key_id = config.get('kms', 'key_id')
        if self.key_id:
            self.client = boto3.client('kms', region_name=kms_region)

    def encrypt(self, message):
        if not self.key_id:
            return message
        result = self.client.encrypt(KeyId=self.key_id, Plaintext=message)
        return base64.b64encode(result['CiphertextBlob']).decode("utf-8")

    def decrypt(self, message):
        if not self.key_id:
            return message
        decrypted_message = self.client.decrypt(CiphertextBlob=base64.b64decode(message))
        result = decrypted_message['Plaintext']
        return result
