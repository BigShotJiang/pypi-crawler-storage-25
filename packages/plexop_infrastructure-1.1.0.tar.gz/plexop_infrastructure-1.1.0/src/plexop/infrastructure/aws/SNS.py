import boto3
import json
from plexop.infrastructure import config, logger


class SNS:
    def __init__(self, region=None, profile_name=None):
        region = region or config.get('sns', 'region', fallback=None)
        profile_name = profile_name or config.get('sqs', 'profile_name', fallback=None)
        self.client = boto3.session.Session(profile_name=profile_name, region_name=region).client('sns')

    def publish(self, TopicArn, Message, **kwargs):
        logger.debug("sending message to sns", topic=TopicArn, message_to_publish=Message, **kwargs)
        if not isinstance(Message, str):
            Message = json.dumps(Message)
        publication_result = self.client.publish(TopicArn=TopicArn, Message=Message, **kwargs)
        logger.debug("message sent to sns", result=publication_result)
        return publication_result
