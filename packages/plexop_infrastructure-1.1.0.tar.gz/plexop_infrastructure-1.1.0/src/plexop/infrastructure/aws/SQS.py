import boto3
import json
import uuid
from plexop.infrastructure import config, logger


class SQS:
    def __init__(self, region=None, profile_name=None):
        region = region or config.get('sqs', 'region', fallback=None)
        profile_name = profile_name or config.get('sqs', 'profile_name', fallback=None)
        self.client = boto3.session.Session(profile_name=profile_name, region_name=region).client('sqs')

    def push_message(self, QueueUrl, MessageBody, **kwargs):
        logger.debug("Try to send message to queue", queue_url=QueueUrl, message_body=MessageBody, **kwargs)
        if isinstance(MessageBody, dict):
            MessageBody = json.dumps(MessageBody)
        receipt = self.client.send_message(QueueUrl=QueueUrl, MessageBody=MessageBody, **kwargs)
        logger.debug("Message sent to SQS", receipt=receipt)
        return receipt

    def push_messages(self, QueueUrl, MessageBodies, **kwargs):
        def build_message_for_bulk(message):
            return {
                'Id': str(uuid.uuid1()),
                'MessageBody': message if isinstance(message, str) else json.dumps(message),
            }
        if not hasattr(MessageBodies, '__iter__'):
            raise Exception("Bodies argument for bulk messages SQS push is not iterable")
        if not len(MessageBodies):
            logger.warn("Push bulk messages call failed. Bodies array length is 0")
            return
        logger.debug('Try to push messages to SQS', queue_url=QueueUrl, count=len(MessageBodies))
        messages = [build_message_for_bulk(m) for m in MessageBodies]
        result = self.client.send_message_batch(QueueUrl=QueueUrl, Entries=messages, **kwargs)
        logger.debug("Messages bulk sent successfully to SQS", queue_url=QueueUrl, count=len(MessageBodies), response=result)
        return result

    def delete_message(self, QueueUrl, ReceiptHandle, **kwargs):
        logger.debug("Try to delete message", queue_url=QueueUrl, receipt_handle=ReceiptHandle)
        result = self.client.delete_message(QueueUrl=QueueUrl, ReceiptHandle=ReceiptHandle, **kwargs)
        logger.debug("Message deleted successfully", queue_url=QueueUrl, receipt_handle=ReceiptHandle, response=result)
        return result
