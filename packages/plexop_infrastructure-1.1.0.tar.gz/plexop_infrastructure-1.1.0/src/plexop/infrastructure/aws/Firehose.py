import boto3
import json
import base64
from plexop.infrastructure import config, logger

class Firehose:
    def __init__(self, region=None, profile_name=None):
        region = region or config.get('firehose', 'region', fallback=None)
        profile_name = profile_name or config.get('firehose', 'profile_name', fallback=None)
        self.client = boto3.session.Session(profile_name=profile_name, region_name=region).client('firehose')

    def put_record(self, data, stream_name=None):
        stream_name = stream_name or config.get('firehose', 'stream_name')
        logger.debug("sending data to fireshose stream", stream_name=stream_name, data=data)
        result = self.client.put_record(DeliveryStreamName=stream_name, Record={'Data': data})
        logger.debug("data sent to firehose successfully", result=result)
        return result