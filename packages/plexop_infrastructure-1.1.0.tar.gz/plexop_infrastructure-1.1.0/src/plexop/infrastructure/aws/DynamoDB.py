import boto3
from botocore.exceptions import ClientError
from plexop.infrastructure.models.write_condition_not_met_exception import WriteConditionNotMetError
from plexop.infrastructure.sleep_iterator import sleep_iterator
from plexop.infrastructure import config, logger
import time
from functools import wraps


def decorate_with_try(fn):
    @wraps(fn)
    def surround(*args, **kwargs):
        sleeper = sleep_iterator()
        start_time = time.time()
        while next(sleeper):
            try:
                logger.debug("try to execute dynamo operation", kwargs=kwargs, fn=str(fn))
                result = fn(*args, **kwargs)
                logger.debug("dynamo operation executed successfully", kwargs=kwargs, fn=str(fn), result=result)
                return result
            except ClientError as ex:
                elapsed_time = time.time() - start_time
                error_code = ex.response['Error']['Code']
                if error_code == u'ConditionalCheckFailedException':
                    raise WriteConditionNotMetError()
                logger.exception(ex, function_name=fn.__name__, elapsed_time=elapsed_time, args=str(args),
                                 kwargs=str(kwargs), error_code=error_code)
                if error_code == u'ProvisionedThroughputExceededException':
                    continue
                raise

    return surround


class DynamoDB:
    def __init__(self, region=None, profile_name=None):
        region = region or config.get('dynamodb', 'region', fallback=None)
        profile_name = profile_name or config.get('dynamodb', 'profile_name', fallback=None)
        self.client = boto3.session.Session(profile_name=profile_name, region_name=region).client('dynamodb')

    @decorate_with_try
    def get_item(self, *args, **kwargs):
        response = self.client.get_item(**kwargs)
        if 'Item' not in response:
            return None
        result = dict((key, list(value.values())[0]) for key, value in response['Item'].items())
        return result

    @decorate_with_try
    def query(self, *args, **kwargs):
        response = self.client.query(**kwargs)
        return response

    @decorate_with_try
    def put_item(self, *args, **kwargs):
        result = self.client.put_item(**kwargs)
        return result.get('Attributes')

    @decorate_with_try
    def update_item(self, *args, **kwargs):
        result = self.client.update_item(**kwargs)
        return result.get('Attributes')

    @decorate_with_try
    def delete_item(self, *args, **kwargs):
        query_result = self.client.delete_item(**kwargs)
        result = dict((key, list(value.values())[0]) for key, value in query_result['Attributes'].items())