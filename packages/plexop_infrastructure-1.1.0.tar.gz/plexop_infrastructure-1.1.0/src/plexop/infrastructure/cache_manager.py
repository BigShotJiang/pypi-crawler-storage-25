from functools import wraps
import json
from plexop.infrastructure import config, logger
from plexop.infrastructure.expiringdict import ExpiringDict

cache_ttl_seconds = config.getint('settings', 'cache_ttl_seconds', fallback=600)
cache_max_len = config.getint('settings', 'cache_max_len', fallback=1000)

_memory = ExpiringDict(max_len=cache_max_len, max_age_seconds=cache_ttl_seconds)


def cache(fn):
    @wraps(fn)
    def surround(self, url, *args, **kwargs):
        
        if kwargs.get('method', 'GET').upper() != 'GET' or not kwargs.get('use_cache', False):
            return fn(self, url, *args, **kwargs)
       
        cache_url = url
        if 'params' in kwargs:
            cache_url += json.dumps(kwargs['params'])
        if 'headers' in kwargs:
            cache_url += json.dumps(kwargs['headers'])
        result = _memory.get(cache_url)
        if not result:
            result = fn(self, url, *args, **kwargs)
            str_result = str(result)
            if 'error' not in str_result and 'timed' not in str_result:
                _memory[cache_url] = result
        else:
            logger.debug("result found in cache", key=cache_url)
        return result
    return surround
