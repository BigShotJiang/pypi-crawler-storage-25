import logging
import os, json
import copy
import sys
from logging.handlers import TimedRotatingFileHandler, SMTPHandler
import hashlib
import traceback
import threading
import re
if 'local_thread' not in globals():
    local_thread = threading.local()


class Logger(object):
    def __init__(self, config, logger_name=None, *args, **kwargs):
        logger_name = logger_name or (sys.argv[1] if len(sys.argv) > 1 else 'init')
        self._masked_fields = ['mobile_number', 'phone_number', 'work_phone_number',
                               'default_phone', 'email']
        self._qs_fields = ['original_querystring', 'pixel']
        self._qs_masked_fields_regex = self.set_qs_masked_parameters(kwargs.get('qs_params_for_masking') or ['email', 'phone', 'mobile'])
        self.warn = self.warning
        formatter = logging.Formatter(f'%(asctime)s - %(process)d - {logger_name} - %(levelname)s - %(message)s')

        self.text_logger = logging.getLogger(logger_name)
        self.text_logger.setLevel(10)

        self.gelf_logger = logging.getLogger(f'gelf-{logger_name}')
        self.gelf_logger.setLevel(logging.DEBUG)
        self.gelf_logger.handlers = []

        self.send_to_graylog = config.getboolean('logging', 'send_to_graylog', fallback=False)
        if self.send_to_graylog:
            from pygelf import GelfUdpHandler
            app_name = kwargs.get('app_name') or os.environ.get('AWS_LAMBDA_FUNCTION_NAME') or (
                sys.argv[1] if len(sys.argv) > 1 else '')
            graylog_server_host = config.get('logging', 'graylog_server_host')
            graylog_port = config.getint('logging', 'graylog_port')
            graylog_handler = GelfUdpHandler(
                host=graylog_server_host,
                port=graylog_port,
                _app_name=app_name,
                _pid=os.getpid(),
                _logger_name=logger_name,
                include_extra_fields=True)
            self.gelf_logger.addHandler(graylog_handler)
            if not self.gelf_logger.filters:
                self.gelf_logger.addFilter(ContextFilter())
        
        if config.getboolean('logging', 'write_to_console', fallback=False):
            console_handler = logging.StreamHandler()
            console_handler.setFormatter(formatter)
            console_handler.setLevel(config.getint('logging', 'console_level', fallback=10))
            self.text_logger.addHandler(console_handler)

        if config.getboolean('logging', 'write_to_file', fallback=False):
            logging_filename = '%s_%s.log' % (config.get('logging', 'filename'), os.getpid())
            logging_file_level = config.getint('logging', 'file_level', fallback=30)
            time_handler = TimedRotatingFileHandler(filename=logging_filename, when='H', interval=1, utc=True)
            time_handler.setLevel(logging_file_level)
            self.text_logger.addHandler(time_handler)

        if config.getboolean('logging', 'send_emails', fallback=False):
            environment_type = config.get('environment', 'environment_type')
            logging_email_level = config.getint('logging', 'email_level', fallback=50)
            logging_email_smtp_port = config.getint('logging', 'email_smtp_port')
            logging_email_from = f"{environment_type}-{config.get('logging', 'email_from')}"
            logging_email_to = config.get('logging', 'email_to')
            logging_email_subject = config.get('logging', 'email_subject')
            logging_email_username = config.get('logging', 'email_username')
            logging_email_password = config.get('logging', 'email_password')
            logging_email_smtp_server = config.get('logging', 'email_smtp_server')
            email_handler = SMTPHandler(mailhost=(logging_email_smtp_server, logging_email_smtp_port),
                fromaddr=logging_email_from,
                toaddrs=[logging_email_to],
                subject="%s::%s %s" % (environment_type, logging_email_subject, logger_name),
                credentials=(logging_email_username, logging_email_password) if logging_email_username else None,
                secure=())

            email_handler.setLevel(logging_email_level)
            email_handler.setFormatter(formatter)
            self.text_logger.addHandler(email_handler)

    def set_local_value(self, key, value):
        setattr(local_thread, key, value)

    def get_local_value(self, key):
        getattr(local_thread, key, None)

    def remove_local_value(self, key):
        delattr(local_thread, key)

    def clean_local_values(self, leave_fields=[]):
        leave_dict = dict((field_name, self.get_local_value(field_name)) for field_name in leave_fields)
        global local_thread
        local_thread = threading.local()
        [self.set_local_value(key, value) for key, value in leave_dict.items()]

    def set_masked_field(self, masked_field):
        if not masked_field:
            return
        if masked_field not in self._masked_fields:
            self._masked_fields.append(masked_field.lower())

    def set_qs_masked_field(self, qs_field):
        if not qs_field:
            return
        if qs_field not in self._qs_fields:
            self._qs_fields.append(qs_field.lower())

    def set_qs_masked_parameters(self, parameters_to_mask_in_qs: list):
        self._qs_masked_fields_regex = re.compile(r'(?:' + '|'.join(parameters_to_mask_in_qs) + r')=([^&]{6,})')
        return self._qs_masked_fields_regex
            
    def debug(self, message, **kwargs):
        message_in_json_format = self._kwargs_to_string(message, kwargs)
        self.text_logger.debug(message_in_json_format)
        if self.send_to_graylog:
            self.gelf_logger.debug(message_in_json_format)

    def info(self, message, **kwargs):
        message_in_json_format = self._kwargs_to_string(message, kwargs)
        self.text_logger.info(message_in_json_format)
        if self.send_to_graylog:
            self.gelf_logger.info(message_in_json_format)

    def warning(self, message, **kwargs):
        message_in_json_format = self._kwargs_to_string(message, kwargs)
        self.text_logger.warning(message_in_json_format)
        if self.send_to_graylog:
            self.gelf_logger.warning(message_in_json_format)

    def error(self, message, **kwargs):
        message_in_json_format = self._kwargs_to_string(message, kwargs)
        self.text_logger.error(message_in_json_format)
        if self.send_to_graylog:
            self.gelf_logger.error(message_in_json_format)

    def exception(self, exception, **kwargs):
        kwargs['call_stack'] = traceback.format_exc()
        kwargs['exception_type'] = str(type(exception))
        message_in_json_format = self._kwargs_to_string(str(exception), kwargs)
        self.text_logger.exception(message_in_json_format)
        if self.send_to_graylog:
            self.gelf_logger.exception(message_in_json_format)

    def critical(self, message, **kwargs):
        message_in_json_format = self._kwargs_to_string(message, kwargs)
        self.text_logger.critical(message_in_json_format)
        if self.send_to_graylog:
            self.gelf_logger.critical(message_in_json_format)

    def _kwargs_to_string(self, message, kwargs) -> str:
        kwargs = copy.deepcopy(kwargs)
        kwargs.update(local_thread.__dict__)
        kwargs['msg'] = message
        masked_kwargs = self._apply_masking(kwargs)
        try:
            return json.dumps(masked_kwargs)
        except TypeError as ex:
            return json.dumps({key: str(val) for key, val in kwargs.items()})

    def _apply_masking(self, kwargs: dict) -> dict:
        def mask(string) -> str:
            return hashlib.md5(string.lower().encode('utf-8')).hexdigest()

        def mask_qs(qs) -> str:
            for match in self._qs_masked_fields_regex.finditer(qs):
                match_group = match.group(1)
                if match_group:  # just for safety
                    qs = qs.replace(match_group, mask(match_group))
            return qs

        for key, value in kwargs.items():
            if value and isinstance(value, str):
                key_lower = key.lower()
                if key_lower in self._masked_fields:
                    kwargs[key] = mask(value)
                elif key_lower in self._qs_fields:
                    kwargs[key] = mask_qs(value)
            elif isinstance(kwargs[key], dict):
                if type(kwargs[key]).__name__ == 'ImmutableMultiDict':
                    value = dict(value)
                kwargs[key] = self._apply_masking(value)
        return kwargs


class ContextFilter(logging.Filter):
    def filter(self, record):
        record.__dict__.update(json.loads(record.msg))
        return True
