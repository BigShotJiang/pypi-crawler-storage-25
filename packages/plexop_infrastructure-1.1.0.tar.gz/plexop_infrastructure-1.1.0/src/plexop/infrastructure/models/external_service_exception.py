class ExternalServiceException(Exception):
    def __init__(self, url, status_code, message, response=None):
        self.msg = f"url: {url} status_code: {status_code} message: [{message}]"
        self.status_code = status_code
        self.response=response

    def __str__(self):
        return f"External Service Error: {self.msg}. " + (('Response: ' + str(self.response)) if self.response else '')