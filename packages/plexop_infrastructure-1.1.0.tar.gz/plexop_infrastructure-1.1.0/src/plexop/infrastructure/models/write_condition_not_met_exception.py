class WriteConditionNotMetError(Exception):
    def __str__(self):
        return "Write condition wasn't met"