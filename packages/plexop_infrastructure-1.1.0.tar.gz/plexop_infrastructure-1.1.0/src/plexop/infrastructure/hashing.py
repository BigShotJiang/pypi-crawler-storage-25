import hashlib
import uuid


def string_to_hash_guid(string, pure_hash_object=False, upper=True, algorithm=hashlib.md5):
    if string is None:
        return None
    m = algorithm()
    m.update(string.encode('utf-8'))
    hash_result = m.hexdigest()
    if pure_hash_object:
        return hash_result.upper() if upper else hash_result
    result = str(uuid.UUID(hash_result))
    return result.upper() if upper else result
