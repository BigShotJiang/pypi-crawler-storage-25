﻿from plexop.infrastructure.config_provider import get_config
from plexop.infrastructure.log_provider import Logger

if 'config' not in globals():
    config = get_config()

if 'logger' not in globals():
    Logger(config, 'quart')
    Logger(config, 'flask')
    Logger(config, 'boto3')
    logger = Logger(config)

def get_logger(logger_name):
    return Logger(config, logger_name)
