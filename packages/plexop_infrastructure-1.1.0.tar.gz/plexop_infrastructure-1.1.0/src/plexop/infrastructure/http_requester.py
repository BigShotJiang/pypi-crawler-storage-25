import json
import requests
from plexop.infrastructure.models.external_service_exception import ExternalServiceException
from plexop.infrastructure.cache_manager import cache
from plexop.infrastructure import config, logger
import time


class HttpRequester(object):
    def __init__(self, timeout=None):
        self.default_timeout = timeout or config.getfloat('external_services', 'timeout', fallback=10)
        self.default_connection_error_retries = config.getint('external_services', 'connection_error_retries', fallback=0)
        self.default_verify_ssl = config.getboolean('external_services', 'verify_ssl', fallback=True)
        self.default_user_agent = config.get('external_services', 'default_user_agent', fallback='Python Plexop Service')

    @cache
    def execute(self, url, read_as_json=True, log_response=True, **kwargs):
        kwargs['url'] = url
        kwargs.setdefault('method', 'get')
        kwargs.setdefault('timeout', self.default_timeout)
        kwargs.setdefault('verify', self.default_verify_ssl)
        return_raw_response = kwargs.pop('raw_response', False)
        headers = kwargs.get('headers', {}) or {}
        headers.setdefault('User-Agent', self.default_user_agent)
        kwargs['headers'] = headers
        kwargs.pop('use_cache', None)
        connection_error_retries = kwargs.pop('connection_error_retries', self.default_connection_error_retries)
        logger.debug('try to perform http request', **kwargs)
        result, elapsed_time = self.__try_to_execute(kwargs, connection_error_retries, time.time())
        try:
            if return_raw_response:
                response = result
                logable_response = response.text
            else:
                if read_as_json:
                    response = result.json()
                else:
                    response = result.text
                logable_response = response
            if not log_response:
                logable_response = 'response logging disabled for this request'
            logger.debug('http request returned result', url=url, result=logable_response,
                         status_code=result.status_code, elapsed_time=elapsed_time)
            return response
        except Exception as ex:
            logger.warning('http request returned not a json result', url=url, result=result.text, elapsed_time=elapsed_time)
            raise ExternalServiceException(url, result.status_code, result.text)

    def __try_to_execute(self, kwargs, connection_error_retries, start_time, attempt=1):
        try:
            result = self.__execute(kwargs)
            if result.status_code >= 400:
                raise ExternalServiceException(kwargs['url'], result.status_code, result.text)
            else:
                elapsed_time = time.time() - start_time
                return result, elapsed_time
        except Exception as ex:
            elapsed_time = time.time() - start_time
            logger.error("failed to perform http request",
                         attempts_performed=attempt,
                         error=str(ex),
                         url=kwargs['url'],
                         elapsed_time=elapsed_time,
                         status_code=getattr(ex, 'status_code', 'status_code_not_received'),
                         response=getattr(ex, 'text', None))
            if isinstance(ex, ExternalServiceException) and ex.status_code < 500:
                raise
            if attempt <= connection_error_retries:
                logger.debug("retry one more time", attempt=attempt + 1)
                return self.__try_to_execute(kwargs, connection_error_retries, time.time(), attempt + 1)
            else:
                if isinstance(ex, ExternalServiceException):
                    raise
                raise ExternalServiceException(kwargs['url'], getattr(ex, 'status_code', 'status_code_not_received'), str(ex))

    def __execute(self, kwargs):
        return requests.request(**kwargs)
