import configparser
import os
from base64 import b64decode

_config: configparser.ConfigParser = None


def read_config_from(path):
    config = configparser.ConfigParser(allow_no_value=True)
    try:
        config.read(path)
        return config
    except IOError:
        pass
    return config


def read_config_from_env_variables():
    for key, value in os.environ.items():
        section_name, _, param_name = key.partition('__')
        if param_name and section_name:
            if not _config.has_section(section_name.lower()):
                _config.add_section(section_name.lower())
            _config.set(section_name.lower(), param_name.lower(), value)
    decrypt_env_variables()


def decrypt_env_variables():
    encrypted_fields = _config.get('settings', 'encrypted_fields', fallback=None)
    if encrypted_fields:
        encrypted_fields = encrypted_fields.split(',')
        import boto3
        kms_client = boto3.client('kms')
        for k in encrypted_fields:
            section, _, param_name = k.lower().partition('__')
            enc_value = _config.get(section, param_name)
            decryption_result = kms_client.decrypt(CiphertextBlob=b64decode(enc_value), EncryptionContext={
                'LambdaFunctionName': os.environ['AWS_LAMBDA_FUNCTION_NAME']})
            dec_value = decryption_result['Plaintext'].decode('utf-8')
            _config.set(section, param_name, dec_value)


def load_configs_from_aws_secrets_manager():
    secret_names = _config.get('settings', 'aws_secrets_names', fallback=None)
    if secret_names:
        import boto3
        import json
        aws_region = _config.get('settings', 'aws_secrets_region', fallback=None)
        if not aws_region:
            boto3.setup_default_session()
            aws_region = boto3.DEFAULT_SESSION.region_name
        client = boto3.client('secretsmanager', region_name=aws_region)
        for secret_name in secret_names.split(','):
            response = client.get_secret_value(SecretId=secret_name)
            result = json.loads(response['SecretString'])
            for complex_key, value in result.items():
                section, key = complex_key.split('__')
                if not _config.has_section(section):
                    _config.add_section(section)
                _config.set(section, key, value)


def get_config():
    global _config
    if not _config:
        _config = read_config_from(os.getenv('CONFIG_FILE_PATH', 'conf.cfg'))
        read_config_from_env_variables()
        load_configs_from_aws_secrets_manager()
    return _config
