import time
import random
from plexop.infrastructure import logger


def sleep_iterator(max=4, base_sleep_time=0.1):
    yield True
    i = 1
    while i <= max:
        sleep_time = base_sleep_time*(i**2)*random.random()*10
        logger.debug("sleep before next attempt", time_to_sleep_in_seconds=sleep_time, iteration=i)
        time.sleep(sleep_time)
        i += 1
        yield i
