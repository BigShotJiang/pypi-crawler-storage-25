from plexop.infrastructure import logger, config
from plexop.infrastructure.http_requester import HttpRequester

logger.debug('test', obj={'mobile_number': '+972-55-55-55-55', 'email': 'asdfsDf@gmaiL.com', 'test': 'test',
                          'original_querystring': '?asdfd=213&mobile=&phone=234&email=asdfsdf@gmail.com'})

#r = HttpRequester()
#result = r.execute('http://5aklie.free.bg', read_as_json=False, use_cache=True, raw_response=1)
#result = r.execute('http://5aklie.free.bg', read_as_json=False, use_cache=True, raw_response=1)

# from plexop.infrastructure.aws.SNS import SNS
# sns = SNS(profile_name='dev')
# sns.publish('arn:aws:sns:us-east-1:872540588091:sophie-test', 'test')
#
# from plexop.infrastructure.aws.SQS import SQS
# sqs = SQS(region=None, profile_name='dev')
# sqs.push_message('https://sqs.us-east-1.amazonaws.com/872540588091/hello-world', 'test')
# sqs.push_messages('https://sqs.us-east-1.amazonaws.com/872540588091/hello-world', ['test1', 'test2'])