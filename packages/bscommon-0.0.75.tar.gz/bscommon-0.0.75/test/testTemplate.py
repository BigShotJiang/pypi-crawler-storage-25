import os
from jinja2 import Template

# --- 你的原有函数 (保持不变) ---
def ReadFile(filename, encoding='utf-8'):
    if not os.path.exists(filename): return ""
    with open(filename, "r", encoding=encoding) as file:
        content = file.read()
        return content
    
def SaveFile(filename, content, encoding='utf-8', mode='w'):
    with open(filename, mode, encoding=encoding) as file:
        file.write(content)

# --- 核心方法：使用默认 {{ key }} 语法 ---
def RenderTemplate(template_file, output_file, data_map, encoding='utf-8'):
    """
    读取模板文件，将 {{ key }} 替换为 data_map 中的值，并保存到输出文件
    :param template_file: 模板文件名
    :param output_file: 输出文件名
    :param data_map: 包含键值对的字典对象
    :param encoding: 文件编码格式
    """
    # 1. 读取模板内容
    content = ReadFile(template_file, encoding)
    if not content:
        print(f"❌ 错误: 找不到模板文件 '{template_file}'")
        return

    try:
        # 2. 创建模板对象 (Jinja2 默认识别 {{ ... }} )
        t = Template(content)
        
        # 3. 渲染数据 (**data_map 自动将字典解包匹配变量)
        result_content = t.render(**data_map)
        
        # 4. 保存文件
        SaveFile(output_file, result_content, encoding)
        print(f"✅ 成功生成: {output_file}")
        
    except Exception as e:
        print(f"❌ 渲染失败: {e}")

# ==========================================
# 🧪 使用示例
# ==========================================
if __name__ == "__main__":
    # 1. 创建一个演示用的模板文件 (注意这里用的是双花括号 {{ }})
    demo_template_content = """
    服务器配置报告
    --------------
    主机名: {{hostname }}
    IP地址: {{ ip_address }}
    端口号: {{ port }}
    
    管理员: {{ admin_name }}
    状态: {{ status }}
    """
    
    # 先保存模板文件以便测试
    SaveFile("config_template.txt", demo_template_content)
    
    # 2. 准备 Map 数据
    config_data = {
        "hostname": "Aliyun-CN-Hangzhou",
        "ip_address": "192.168.0.1",
        "port": 8080,
        "admin_name": "Admin",
        "status": "Running"
    }
    
    # 3. 调用方法
    # 它会自动查找 {{ hostname }} 等并替换
    RenderTemplate("config_template.txt", "final_config.txt", config_data)


