"""Wireless InSite interface helpers."""
