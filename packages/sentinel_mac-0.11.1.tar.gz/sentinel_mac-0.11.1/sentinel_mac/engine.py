"""Sentinel — Alert Engine."""

import logging
import re
import time
from collections import deque
from datetime import datetime
from pathlib import Path
from typing import Callable, Optional

from sentinel_mac.models import Alert, SecurityEvent, SystemMetrics

logger = logging.getLogger(__name__)


# ── ADR 0007 D6 — Forensic context [ctx] block ────────────────────────
# Append a short 4-line block (Project / Session / Where / What) to the
# Alert message so a single notification answers "who/where/what" without
# the user grepping the JSONL audit log.
#
# Privacy boundary (D7): `git.remote` is intentionally NOT surfaced in
# the user-visible alert text — it stays in the audit log only.
#
# ADR 0008 D2 narrows that "audit-log-only forever" commitment to
# `minimal` and `standard` modes only; `full` mode opts the user into
# rendering `Repo: owner/repo` under the Project line. The privacy
# default (standard) is unchanged from v0.8.0 — git.remote stays out
# of the alert body unless the user explicitly sets full.

# macOS Notification Center truncates around ~250 chars; the `What:`
# line is the longest and most variable, so we cap it here. cwd gets
# `~/` substitution under HOME for the same reason.
_CTX_COMMAND_MAX_CHARS = 80

# ADR 0008 D1 frozen three-state enum. The default ("standard") matches
# v0.8.0 behavior verbatim; unknown values fall back to "standard"
# defensively — config validation should have caught the typo upstream
# (ADR 0008 D5) but the renderer never crashes on a bad level.
_VALID_CONTEXT_LEVELS: frozenset[str] = frozenset(
    {"minimal", "standard", "full"}
)


def _format_ctx_block(detail: dict, *, level: str = "standard") -> str:
    """ADR 0007 D6 — render the ``[ctx]`` block for an Alert message.

    Reads the ``session`` (D2) and ``project_meta`` (D3) sub-dicts from
    ``detail`` (both nullable, both may be missing on event types
    without enrichment such as MacOSCollector system-thermal alerts).

    Returns the empty string when neither block has anything to show —
    callers append unconditionally so it's safe to use ``message + ctx``.

    ADR 0008 D4 — render the ``[ctx]`` block at the requested level:
        - ``"minimal"`` → return ``""`` (drop entire block).
        - ``"standard"`` → current v0.8 behavior (no git.remote).
        - ``"full"`` → standard + ``Repo: owner/repo`` line under Project:
          (only when ``project_meta.git.remote`` is non-null).

    Unknown level values fall back to ``"standard"`` — defensive guard;
    config validation (``_validate_config``) is the canonical filter.

    Output shape (each line indented 3 spaces to match the existing
    notification body convention):

        \\n
           Project: <name> (<branch> @ <head>)
           Repo:    <owner>/<repo>          # full mode only
           Session: <model> #<id8> (CC <version>)
           Where:   <cwd>
           What:    <command>

    Per ADR D7 / ADR 0008 D2 the audit log always keeps git.remote;
    this helper omits it unless ``level == "full"``.
    """
    # ADR 0008 D4 — minimal short-circuits before any work.
    if level == "minimal":
        return ""

    # ADR 0008 D5 defensive — unknown values land on standard so a
    # config-validation gap can never crash the renderer.
    if level not in _VALID_CONTEXT_LEVELS:
        level = "standard"

    if not isinstance(detail, dict):
        return ""

    session = detail.get("session") or {}
    project = detail.get("project_meta")

    lines: list[str] = []

    # Project line: name (branch @ head) | name (branch) | name
    if isinstance(project, dict):
        name = project.get("name")
        git = project.get("git") or {}
        branch = git.get("branch") if isinstance(git, dict) else None
        head = git.get("head") if isinstance(git, dict) else None
        remote = git.get("remote") if isinstance(git, dict) else None
        if name and branch and head:
            lines.append(f"   Project: {name} ({branch} @ {head})")
        elif name and branch:
            lines.append(f"   Project: {name} ({branch})")
        elif name:
            lines.append(f"   Project: {name}")

        # ADR 0008 D1 — `full` mode adds the Repo line directly under
        # Project:. Only renders when git.remote is a non-empty string;
        # null remote (private repo without a normalized GitHub-shaped
        # URL) silently omits the line so the block stays clean.
        if level == "full" and isinstance(remote, str) and remote:
            lines.append(f"   Repo:    {remote}")

    # Session line: model #shortid (CC version) | model #shortid | model | #shortid
    if isinstance(session, dict):
        sid = session.get("id")
        model = session.get("model")
        version = session.get("version")
        short_sid = (sid or "")[:8] if isinstance(sid, str) else ""
        if model and short_sid and version:
            lines.append(f"   Session: {model} #{short_sid} (CC {version})")
        elif model and short_sid:
            lines.append(f"   Session: {model} #{short_sid}")
        elif model:
            lines.append(f"   Session: {model}")
        elif short_sid:
            lines.append(f"   Session: #{short_sid}")

        cwd = session.get("cwd")
        if isinstance(cwd, str) and cwd:
            # macOS truncation guard: ~/ substitution under HOME (D6).
            try:
                home = str(Path.home())
                if home and cwd.startswith(home):
                    cwd = "~" + cwd[len(home):]
            except Exception:
                pass
            lines.append(f"   Where:   {cwd}")

    # What line: command (truncated to 80 chars per D6 macOS-tightened cap).
    command = detail.get("command")
    if isinstance(command, str) and command:
        if len(command) > _CTX_COMMAND_MAX_CHARS:
            command = command[: _CTX_COMMAND_MAX_CHARS - 1] + "…"
        lines.append(f"   What:    {command}")

    if not lines:
        return ""
    return "\n\n" + "\n".join(lines)


class AlertEngine:
    """Evaluates composite conditions and generates smart alerts."""

    def __init__(self, config: dict):
        self.config = config
        self.thresholds = config.get("thresholds", {})
        self._cooldowns: dict[str, datetime] = {}
        self._cooldown_minutes = config.get("cooldown_minutes", 10)
        self._history: deque = deque(maxlen=30)
        self._session_start: Optional[datetime] = None
        self._idle_start: Optional[datetime] = None
        self._custom_rules = self._compile_custom_rules(config)
        # ADR 0008 D4 — cache the context level once at construction so
        # the per-event hot path doesn't re-walk the config dict on every
        # alert. _validate_config is the single source of truth for the
        # value (fail-soft: unknown values are normalized to "standard"
        # before the engine ever sees them, but we still defensively
        # default here in case a test bypasses load_config).
        notif = config.get("notifications") or {}
        level = notif.get("context_level", "standard") if isinstance(notif, dict) else "standard"
        if level not in _VALID_CONTEXT_LEVELS:
            level = "standard"
        self._context_level: str = level

        # v0.9 Track 3b — optional callback returning the most-recent
        # user/assistant message timestamp (epoch seconds) from the
        # AgentLogParser. When present, the stuck_process branch in
        # evaluate() consults it to skip false-positive alerts during
        # active interactive sessions (PR #28 follow-up). Wired by
        # core.Sentinel.__init__ after collector construction; stays
        # None for tests / standalone construction so the engine
        # behavior is unchanged from v0.8.
        self._agent_activity_callback: Optional[
            Callable[[], Optional[float]]
        ] = None

    # v0.9 Track 3b — late-bound dependency injection. Setter (vs
    # __init__ kwarg) is deliberate: AlertEngine is constructed before
    # the AgentLogParser exists in core.Sentinel.__init__, and tests
    # that build a bare AlertEngine should not have to pass a stub.
    def set_agent_activity_callback(
        self, callback: Optional[Callable[[], Optional[float]]]
    ) -> None:
        """Wire a callable returning the most-recent agent activity epoch.

        Pass ``None`` to detach (e.g. when the agent log parser is
        disabled by config). The callback is consulted on every
        ``evaluate()`` call where the stuck_process precondition
        (5 samples, avg_cpu > 50, avg_net < 0.1) is otherwise met,
        so the implementation should be cheap and lock-thrifty —
        ``AgentLogParser.last_user_or_assistant_activity_epoch``
        satisfies that contract.
        """
        self._agent_activity_callback = callback

    # v0.9 Track 3b — stuck_process false-positive grace window.
    # Keep as a class-level constant (not a config knob) until/unless
    # users ask for tuning. PR #28 commit narrative explicitly favors
    # "tighten the heuristic" over "add another threshold".
    _STUCK_PROCESS_ACTIVITY_GRACE_SEC: float = 300.0  # 5 minutes

    def evaluate(self, m: SystemMetrics) -> list[Alert]:
        self._history.append(m)
        alerts = []

        # -- Battery Alerts --
        if m.battery_percent is not None and not m.battery_plugged:
            if m.battery_percent <= self.thresholds.get("battery_critical", 10):
                alerts.append(Alert(
                    level="critical", category="battery_critical",
                    title="\U0001faab Battery Critical",
                    message=f"Battery at {m.battery_percent}% \u2014 plug in now!\n"
                           f"{'~' + str(m.battery_minutes_left) + ' min remaining' if m.battery_minutes_left else ''}",
                    emoji="\U0001f534", priority=5
                ))
            elif m.battery_percent <= self.thresholds.get("battery_warning", 20):
                time_msg = f"\n~{m.battery_minutes_left} min remaining" if m.battery_minutes_left else ""
                ai_msg = f"\n{len(m.ai_processes)} AI process(es) running" if m.ai_processes else ""
                alerts.append(Alert(
                    level="warning", category="battery_warning",
                    title="\U0001f50b Battery Low",
                    message=f"Battery {m.battery_percent}%, not charging{time_msg}{ai_msg}",
                    emoji="\U0001f7e0", priority=4
                ))

            # Rapid drain detection (time-based: %/hour)
            if len(self._history) >= 3:
                oldest = self._history[0]
                elapsed_hours = (m.timestamp - oldest.timestamp).total_seconds() / 3600
                if (elapsed_hours > 0.01
                        and oldest.battery_percent is not None
                        and m.battery_percent is not None):
                    drain_total = oldest.battery_percent - m.battery_percent
                    drain_per_hour = drain_total / elapsed_hours
                    threshold = self.thresholds.get("battery_drain_rate", 10)
                    if drain_per_hour > threshold:
                        alerts.append(Alert(
                            level="warning", category="battery_drain",
                            title="\u26a1 Rapid Battery Drain",
                            message=f"Drain rate: {drain_per_hour:.1f}%/hr\n"
                                   f"({drain_total:.1f}% lost in {elapsed_hours * 60:.0f} min)\n"
                                   f"AI CPU usage: {m.ai_cpu_total:.0f}%",
                            emoji="\U0001f7e0", priority=4
                        ))

        # -- Thermal Alerts --
        if m.cpu_temp is not None:
            if m.cpu_temp >= self.thresholds.get("temp_critical", 95):
                alerts.append(Alert(
                    level="critical", category="temp_critical",
                    title="\U0001f321\ufe0f CPU Overheating!",
                    message=f"CPU temp {m.cpu_temp}\u00b0C \u2014 throttling active\n"
                           f"Thermal: {m.thermal_pressure}\n"
                           f"{'Fan ' + str(m.fan_speed_rpm) + ' RPM' if m.fan_speed_rpm else ''}",
                    emoji="\U0001f534", priority=5
                ))
            elif m.cpu_temp >= self.thresholds.get("temp_warning", 85):
                alerts.append(Alert(
                    level="warning", category="temp_warning",
                    title="\U0001f321\ufe0f CPU Temperature High",
                    message=f"CPU {m.cpu_temp}\u00b0C | Fan {m.fan_speed_rpm or '?'} RPM\n"
                           f"CPU usage {m.cpu_percent}%",
                    emoji="\U0001f7e0", priority=3
                ))

        elif m.thermal_pressure in ("critical", "serious"):
            alerts.append(Alert(
                level="warning", category="thermal_pressure",
                title="\U0001f321\ufe0f System Throttling Detected",
                message=f"Thermal pressure: {m.thermal_pressure}\n"
                       f"CPU {m.cpu_percent}% | Memory {m.memory_percent}%",
                emoji="\U0001f7e0", priority=4
            ))

        # -- Memory Alerts --
        if m.memory_percent >= self.thresholds.get("memory_critical", 90):
            alerts.append(Alert(
                level="warning", category="memory_high",
                title="\U0001f4be Memory Critical",
                message=f"Memory at {m.memory_percent}% ({m.memory_used_gb}GB)\n"
                       f"AI processes using {m.ai_memory_total_mb:.0f}MB",
                emoji="\U0001f7e0", priority=4
            ))

        # -- Security Posture --
        disabled_controls = []
        if m.firewall_enabled is False:
            disabled_controls.append("Firewall")
        if m.gatekeeper_enabled is False:
            disabled_controls.append("Gatekeeper")
        if m.filevault_enabled is False:
            disabled_controls.append("FileVault")

        if disabled_controls:
            alerts.append(Alert(
                level="warning", category="security_posture",
                title="\U0001f6e1\ufe0f Security Posture Risk",
                message=f"Disabled protections: {', '.join(disabled_controls)}\n"
                       f"Re-enable them to reduce security exposure.",
                emoji="\U0001f7e0", priority=4
            ))

        # -- AI Process Alerts --
        if m.ai_processes:
            if self._session_start is None:
                self._session_start = m.timestamp
                self._idle_start = None

            if len(self._history) >= 5:
                recent = list(self._history)[-5:]
                avg_cpu = sum(h.ai_cpu_total for h in recent) / len(recent)
                avg_net = sum(h.net_sent_mb + h.net_recv_mb for h in recent) / len(recent)
                if avg_cpu > 50 and avg_net < 0.1:
                    # v0.9 Track 3b (PR #28 follow-up) \u2014 high CPU +
                    # near-zero network is necessary but not sufficient
                    # evidence of a stuck process. Local model thinking,
                    # batch processing, and any heavily-CPU-bound but
                    # legitimately-running interactive session match
                    # the same shape. Before firing, consult the agent
                    # log parser's most-recent user/assistant message
                    # timestamp; if it is within the grace window
                    # (default 5 min) we suppress the alert as a
                    # false-positive on an active session.
                    #
                    # Suppression is intentionally conservative: only
                    # callbacks that return a real epoch and are within
                    # the window suppress. A None callback (no parser
                    # wired) or a None return (no messages observed
                    # yet this process) falls through to the legacy
                    # CPU+net heuristic so prior behavior is preserved.
                    suppressed_by_activity = False
                    if self._agent_activity_callback is not None:
                        try:
                            last_activity = self._agent_activity_callback()
                        except Exception:  # pragma: no cover - defensive
                            # The callback is supposed to be
                            # exception-free, but the alert path must
                            # never crash the daemon \u2014 fall through to
                            # legacy heuristic on any failure.
                            last_activity = None
                        if last_activity is not None:
                            age_sec = time.time() - last_activity
                            if 0 <= age_sec < self._STUCK_PROCESS_ACTIVITY_GRACE_SEC:
                                suppressed_by_activity = True

                    if not suppressed_by_activity:
                        alerts.append(Alert(
                            level="warning", category="stuck_process",
                            title="\U0001f504 Suspected Stuck Process",
                            message=f"AI process using {avg_cpu:.0f}% CPU\n"
                                   f"but near-zero network I/O \u2014 possible infinite loop",
                            emoji="\U0001f7e0", priority=4
                        ))

        else:
            if self._session_start:
                duration = (m.timestamp - self._session_start).total_seconds() / 60
                if duration > 5:
                    alerts.append(Alert(
                        level="info", category="session_end",
                        title="\u2705 AI Session Ended",
                        message=f"Session duration: {duration:.0f} min",
                        emoji="\u2705", priority=2
                    ))
                self._session_start = None

            self._idle_start = self._idle_start or m.timestamp

        # -- Night Watch --
        hour = m.timestamp.hour
        if (0 <= hour <= 6) and m.ai_processes and not m.battery_plugged:
            alerts.append(Alert(
                level="warning", category="night_watch",
                title="\U0001f319 Unattended Night Session",
                message=f"{hour}:00 AM \u2014 AI session active + battery {m.battery_percent}%\n"
                       f"Charger not connected",
                emoji="\U0001f7e1", priority=4
            ))

        # -- Disk Alert --
        disk_threshold = self.thresholds.get("disk_critical", 90)
        if m.disk_percent >= disk_threshold:
            alerts.append(Alert(
                level="warning", category="disk_high",
                title="\U0001f4bf Disk Space Low",
                message=f"Disk usage at {m.disk_percent}%\n"
                       f"Remaining: {m.disk_free_gb}GB",
                emoji="\U0001f7e0", priority=4
            ))

        # -- Network Spike --
        total_mb = m.net_sent_mb + m.net_recv_mb
        net_threshold = self.thresholds.get("network_spike_mb", 100)
        if total_mb > net_threshold:
            alerts.append(Alert(
                level="info", category="network_spike",
                title="\U0001f4e1 Network Traffic Spike",
                message=f"This interval: \u2191{m.net_sent_mb:.1f}MB \u2193{m.net_recv_mb:.1f}MB\n"
                       f"Total {total_mb:.1f}MB",
                emoji="\U0001f7e1", priority=3
            ))

        return self._apply_cooldowns(alerts, now=m.timestamp)

    def evaluate_security_event(self, event: SecurityEvent) -> list[Alert]:
        """Convert a SecurityEvent into alerts based on risk rules."""
        if event.source == "net_tracker":
            alerts = self._evaluate_net_event(event)
        elif event.source == "agent_log":
            alerts = self._evaluate_agent_log_event(event)
        else:
            alerts = self._evaluate_fs_event(event)

        # ADR 0001: host-trust downgrade. Built-in alerts get one severity
        # step removed (warning -> info, critical -> warning) when the
        # collector marked the event as trustable. BLOCKED hosts are
        # explicitly exempt — even if `downgrade` was set upstream we
        # never weaken an alert against a user-blocklisted host. Custom
        # user rules below are intentionally NOT downgraded so user
        # intent always wins.
        alerts = self._apply_trust_downgrade(alerts, event)

        # Apply custom rules on top of built-in rules
        if self._custom_rules:
            custom_alerts = self._evaluate_custom_rules(event)
            alerts.extend(self._apply_cooldowns(custom_alerts, now=event.timestamp))

        # ADR 0007 D6 — append the [ctx] block to every alert message
        # produced from a SecurityEvent. The block is best-effort: when
        # neither `session` nor `project_meta` carry usable fields the
        # helper returns "" and the message is unchanged. Strict addition
        # to existing message text — preserves substring-based regression
        # tests (e.g., `assert "Risk: pipe to shell" in alert.message`).
        #
        # ADR 0008 D4 — pass the cached context level so the renderer
        # can render minimal (drop block entirely) / standard (v0.8
        # default) / full (Repo line added).
        ctx_block = _format_ctx_block(event.detail, level=self._context_level)
        if ctx_block:
            for alert in alerts:
                alert.message = alert.message + ctx_block

        return alerts

    @staticmethod
    def _apply_trust_downgrade(
        alerts: list[Alert], event: SecurityEvent,
    ) -> list[Alert]:
        """Downgrade alert severity by one step when host trust signals it.

        Reads two optional fields populated by collectors:
            event.detail["downgrade"]    — bool, requested downgrade
            event.detail["trust_level"]  — "unknown"/"learned"/"known"/"blocked"

        BLOCKED takes precedence — a blocklisted host always preserves
        original severity, even if downgrade=True somehow leaked through.
        """
        if not alerts:
            return alerts
        if not event.detail.get("downgrade", False):
            return alerts
        if event.detail.get("trust_level") == "blocked":
            return alerts

        step = {"critical": "warning", "warning": "info", "info": "info"}
        for alert in alerts:
            alert.level = step.get(alert.level, alert.level)
        return alerts

    def _evaluate_fs_event(self, event: SecurityEvent) -> list[Alert]:
        """Evaluate file system security events."""
        alerts = []

        is_sensitive = event.detail.get("sensitive", False)
        is_executable = event.detail.get("executable", False)
        is_ai = event.detail.get("ai_process", False)
        actor = event.actor_name if event.actor_name != "unknown" else "Unknown process"

        # Bulk change alert
        if event.event_type == "bulk_change":
            count = event.detail.get("count", 0)
            project = event.detail.get("project", "")
            top_dirs = event.detail.get("top_directories", [])
            suspect = event.detail.get("suspect_process", "")
            suspect_pid = event.detail.get("suspect_pid", 0)

            msg_lines = [f"{count} file operations in a short window."]
            if project:
                msg_lines.append(f"Project: {project}")
            if suspect:
                msg_lines.append(f"Suspect process: {suspect} (PID {suspect_pid})")
            if top_dirs:
                msg_lines.append(f"Top dirs: {', '.join(top_dirs[:3])}")

            alerts.append(Alert(
                level="warning", category="fs_bulk_change",
                title="\U0001f4c1 Bulk File Changes Detected",
                message="\n".join(msg_lines),
                emoji="\U0001f7e0", priority=4
            ))
            return self._apply_cooldowns(alerts, now=event.timestamp)

        # Critical: AI process accessing sensitive files
        if is_sensitive and is_ai:
            event.risk_score = 0.9
            alerts.append(Alert(
                level="critical", category="fs_sensitive_ai",
                title="\U0001f6a8 AI Agent Accessed Sensitive File",
                message=f"{actor} (PID {event.actor_pid}) {event.event_type}: {event.target}",
                emoji="\U0001f534", priority=5
            ))
        # Warning: any process accessing sensitive files
        elif is_sensitive:
            event.risk_score = 0.7
            alerts.append(Alert(
                level="warning", category="fs_sensitive",
                title="\U0001f6e1\ufe0f Sensitive File Accessed",
                message=f"{actor} {event.event_type}: {event.target}",
                emoji="\U0001f7e0", priority=4
            ))
        # Warning: executable file created
        elif is_executable:
            event.risk_score = 0.6
            alerts.append(Alert(
                level="warning", category="fs_executable",
                title="\u26a0\ufe0f Executable File Created",
                message=f"{actor} created executable: {event.target}",
                emoji="\U0001f7e0", priority=4
            ))
        # Info: AI process modifying files (non-sensitive)
        elif is_ai:
            event.risk_score = 0.3
            alerts.append(Alert(
                level="info", category="fs_ai_activity",
                title="\U0001f4dd AI File Activity",
                message=f"{actor} {event.event_type}: {event.target}",
                emoji="\U0001f7e1", priority=2
            ))

        return self._apply_cooldowns(alerts, now=event.timestamp)

    def _evaluate_net_event(self, event: SecurityEvent) -> list[Alert]:
        """Evaluate network security events."""
        alerts = []
        actor = event.actor_name
        is_allowed = event.detail.get("allowed", True)
        is_nonstandard = event.detail.get("nonstandard_port", False)
        hostname = event.detail.get("hostname", event.target)
        port = event.detail.get("remote_port", 0)

        if not is_allowed and is_nonstandard:
            # Unknown host + non-standard port = highest risk
            event.risk_score = 0.9
            alerts.append(Alert(
                level="critical", category="net_unknown_suspicious",
                title="\U0001f6a8 Suspicious AI Network Connection",
                message=f"{actor} (PID {event.actor_pid}) connected to\n"
                       f"{hostname}:{port}\n"
                       f"Unknown host + non-standard port",
                emoji="\U0001f534", priority=5
            ))
        elif not is_allowed:
            # Unknown host on standard port
            event.risk_score = 0.7
            alerts.append(Alert(
                level="warning", category="net_unknown_host",
                title="\U0001f310 AI Connected to Unknown Host",
                message=f"{actor} (PID {event.actor_pid}) connected to\n"
                       f"{hostname}:{port}\n"
                       f"Host not in allowlist",
                emoji="\U0001f7e0", priority=4
            ))
        elif is_nonstandard:
            # Known host but non-standard port
            event.risk_score = 0.4
            alerts.append(Alert(
                level="info", category="net_nonstandard_port",
                title="\U0001f50c AI Using Non-Standard Port",
                message=f"{actor} connected to {hostname}:{port}",
                emoji="\U0001f7e1", priority=3
            ))

        return self._apply_cooldowns(alerts, now=event.timestamp)

    def _evaluate_agent_log_event(self, event: SecurityEvent) -> list[Alert]:
        """Evaluate agent log events (tool calls from Claude Code, Cursor, etc.)."""
        alerts = []
        actor = event.actor_name
        tool = event.detail.get("tool", "")
        risk_reason = event.detail.get("risk_reason", "")
        is_high_risk = event.detail.get("high_risk", False)

        if is_high_risk and event.event_type == "agent_command":
            # High-risk bash command.
            # NOTE (v0.8 Track 2b — same defect class as PR #18):
            # collector (agent_log_parser._check_bash_command) now sets
            # risk_score=0.9 before queueing so the JSONL audit row
            # carries the right severity. The trust-downgrade SSH/SCP
            # branch in the collector lowers it to 0.2 and clears
            # high_risk so this whole `if` is skipped — the lowered
            # score therefore reaches disk untouched. We re-assert 0.9
            # here as a defensive idempotent guard for callers that
            # bypass the collector (test fixtures, custom integrations).
            event.risk_score = 0.9
            alerts.append(Alert(
                level="critical", category="agent_high_risk_command",
                title="\U0001f6a8 High-Risk AI Command Detected",
                message=f"{actor} executed: {event.target}\n"
                       f"Risk: {risk_reason}",
                emoji="\U0001f534", priority=5
            ))
        elif is_high_risk and event.event_type == "agent_tool_use":
            # High-risk tool use (e.g. write to sensitive path).
            # NOTE (v0.8 Track 2b — same defect class as PR #18):
            # collector (_check_file_write / _check_file_read) now sets
            # risk_score=0.8 before the JSONL audit write. We re-assert
            # the same value idempotently so the engine remains the
            # source of the alert level and the collector is the source
            # of the persisted score; the two stay in lockstep.
            event.risk_score = 0.8
            alerts.append(Alert(
                level="warning", category="agent_sensitive_write",
                title="\U0001f6e1\ufe0f AI Writing to Sensitive Path",
                message=f"{actor} {tool}: {event.target}\n"
                       f"Risk: {risk_reason}",
                emoji="\U0001f7e0", priority=4
            ))
        elif event.event_type == "mcp_injection_suspect":
            # MCP prompt injection detected — critical.
            # NOTE (v0.8 Track 2b — same defect class as PR #18):
            # collector (_check_mcp_tool_result) now sets risk_score=0.95
            # before queueing so the JSONL audit row matches the
            # critical Alert. Idempotent re-assertion here protects
            # callers that bypass the collector.
            event.risk_score = 0.95
            matched = event.detail.get("matched_pattern", "unknown")
            preview = event.detail.get("content_preview", "")[:150]
            alerts.append(Alert(
                level="critical", category="mcp_injection",
                title="\U0001f6a8 MCP Prompt Injection Detected",
                message=f"Suspicious content in MCP response:\n"
                       f"Pattern: {matched}\n"
                       f"Preview: {preview}...",
                emoji="\U0001f534", priority=5
            ))
        elif event.event_type == "mcp_tool_call":
            # MCP tool invocation — informational.
            # NOTE (v0.8 Track 2b — same defect class as PR #18):
            # collector (_handle_mcp_tool_call) now sets risk_score=0.2
            # before queueing. Idempotent re-assertion keeps engine and
            # collector mappings in lockstep; both must agree on 0.2 so
            # --report --severity info correctly buckets these events.
            event.risk_score = 0.2
            server = event.detail.get("server", "unknown")
            method = event.detail.get("method", "unknown")
            alerts.append(Alert(
                level="info", category="mcp_tool_call",
                title="\U0001f50c MCP Tool Invocation",
                message=f"{actor} called {server}/{method}",
                emoji="\U0001f7e1", priority=2
            ))
        elif event.event_type == "typosquatting_suspect":
            similar_to = event.detail.get("similar_to", "?")
            confidence = event.detail.get("confidence", "medium")
            ecosystem = event.detail.get("ecosystem", "")
            # NOTE (v0.8 defect fix): collector
            # (agent_log_parser._check_typosquatting) now sets risk_score
            # before the JSONL audit write so audit-log severity matches
            # the alert. We re-assert the same mapping here idempotently
            # for backward compatibility — engine remains the source of
            # the alert level, collector is the source of the persisted
            # score, and the two stay in lockstep.
            event.risk_score = 0.9 if confidence == "high" else 0.6
            level = "critical" if confidence == "high" else "warning"
            alerts.append(Alert(
                level=level, category="typosquatting_suspect",
                title="\U0001f4e6 Typosquatting Suspect Package",
                message=(
                    f"{actor} installing '{event.target}' via {ecosystem}\n"
                    f"Looks like '{similar_to}' — possible typosquat or hallucination"
                ),
                emoji="\U0001f7e0", priority=4
            ))
        elif event.event_type == "agent_tool_use" and tool == "WebFetch":
            # URL fetch — informational.
            # NOTE (v0.8 Track 2b — same defect class as PR #18):
            # collector (_evaluate_tool_call WebFetch branch) now sets
            # risk_score=0.3 before queueing. Engine re-asserts the
            # same value idempotently for callers that bypass the
            # collector. Note: agent_tool_use covers two distinct
            # branches in this method — sensitive write (high_risk →
            # 0.8) above and WebFetch (info → 0.3) here. The collector
            # disambiguates by setting the score correctly per branch
            # at emit time, so the persisted score is always right.
            event.risk_score = 0.3
            alerts.append(Alert(
                level="info", category="agent_web_fetch",
                title="\U0001f310 AI Fetching External URL",
                message=f"{actor} fetching: {event.target}",
                emoji="\U0001f7e1", priority=2
            ))
        elif event.event_type == "agent_download":
            # ADR 0002 §D5 — agent_log_parser already set risk_score per
            # the severity matrix (sensitive path → 0.9, BLOCKED/UNKNOWN
            # host → 0.5, KNOWN/LEARNED host → 0.2). The engine does NOT
            # re-score; it only maps the score to an Alert level so the
            # macOS notification channel actually fires.
            score = event.risk_score
            source_url = event.detail.get("source_url", event.target)
            output_path = event.detail.get("output_path") or "(unknown path)"
            downloader = event.detail.get("downloader", "?")
            if score >= 0.8:
                # critical — sensitive output_path
                alerts.append(Alert(
                    level="critical", category="agent_download_sensitive",
                    title="\U0001f6a8 AI Downloading to Sensitive Path",
                    message=f"{actor} via {downloader}\n"
                           f"From: {source_url}\n"
                           f"To:   {output_path}",
                    emoji="\U0001f534", priority=5
                ))
            elif score >= 0.5:
                # warning — BLOCKED or UNKNOWN host
                trust = event.detail.get("trust_level", "unknown")
                alerts.append(Alert(
                    level="warning", category="agent_download_untrusted",
                    title="\U0001f4e5 AI Download from Untrusted Host",
                    message=f"{actor} via {downloader} (host trust: {trust})\n"
                           f"From: {source_url}\n"
                           f"To:   {output_path}",
                    emoji="\U0001f7e0", priority=4
                ))
            else:
                # info — KNOWN/LEARNED host
                alerts.append(Alert(
                    level="info", category="agent_download",
                    title="\U0001f4e5 AI Download",
                    message=f"{actor} via {downloader}\n"
                           f"From: {source_url}\n"
                           f"To:   {output_path}",
                    emoji="\U0001f7e1", priority=2
                ))

        return self._apply_cooldowns(alerts, now=event.timestamp)

    @staticmethod
    def _compile_custom_rules(config: dict) -> list:
        """Compile user-defined custom rules from config."""
        rules = []
        raw = config.get("security", {}).get("custom_rules", [])
        for r in raw:
            name = r.get("name", "Unnamed rule")
            pattern = r.get("pattern", "")
            source = r.get("source", "all")
            level = r.get("level", "warning")
            if level not in ("critical", "warning", "info"):
                level = "warning"
            if not pattern:
                continue
            try:
                compiled = re.compile(pattern, re.IGNORECASE)
                rules.append({
                    "name": name,
                    "pattern": compiled,
                    "source": source,
                    "level": level,
                })
            except re.error as e:
                logger.warning(f"Invalid custom rule regex '{name}': {e}")
        if rules:
            logger.info(f"Loaded {len(rules)} custom rule(s)")
        return rules

    def _evaluate_custom_rules(self, event: SecurityEvent) -> list[Alert]:
        """Match event against user-defined custom rules."""
        alerts = []
        # Build text to match against: target + detail values
        match_text = event.target or ""
        for v in event.detail.values():
            if isinstance(v, str):
                match_text += " " + v

        for rule in self._custom_rules:
            # Filter by source if specified
            if rule["source"] != "all" and rule["source"] != event.source:
                continue
            if rule["pattern"].search(match_text):
                level = rule["level"]
                risk = {"critical": 0.9, "warning": 0.7, "info": 0.3}.get(level, 0.7)
                event.risk_score = max(event.risk_score, risk)
                emoji = {"critical": "\U0001f534", "warning": "\U0001f7e0", "info": "\U0001f7e1"}.get(level, "\U0001f7e0")
                alerts.append(Alert(
                    level=level,
                    category="custom_{}".format(rule["name"].lower().replace(" ", "_")),
                    title="\U0001f6a8 Custom Rule: {}".format(rule["name"]),
                    message="Matched: {}\nTarget: {}".format(rule["pattern"].pattern, event.target or "N/A"),
                    emoji=emoji,
                    priority=5 if level == "critical" else 4 if level == "warning" else 2,
                ))
        return alerts

    def _apply_cooldowns(self, alerts: list[Alert], now: Optional[datetime] = None) -> list[Alert]:
        """Prevent alert spam by enforcing cooldown per category."""
        now = now or datetime.now()
        filtered = []
        for alert in alerts:
            last = self._cooldowns.get(alert.category)
            cooldown = self._cooldown_minutes
            if alert.level == "critical":
                cooldown = max(2, cooldown // 3)

            if last is None or (now - last).total_seconds() > cooldown * 60:
                filtered.append(alert)
                self._cooldowns[alert.category] = now
        return filtered
