from __future__ import annotations

import datetime
from typing import ClassVar, Literal

from pydantic import Field

from kubex.k8s.v1_36.core.v1.event_source import EventSource
from kubex.k8s.v1_36.core.v1.object_reference import ObjectReference
from kubex.k8s.v1_36.events.v1.event_series import EventSeries
from kubex_core.models.interfaces import NamespaceScopedEntity
from kubex_core.models.resource_config import ResourceConfig, Scope


class Event(NamespaceScopedEntity):
    """Event is a report of an event somewhere in the cluster. It generally denotes some state change in the system. Events have a limited retention time and triggers and messages may evolve with time. Event consumers should not rely on the timing of an event with a given Reason reflecting a consistent underlying trigger, or the continued existence of events with that Reason. Events should be treated as informative, best-effort, supplemental data."""

    __RESOURCE_CONFIG__: ClassVar[ResourceConfig["Event"]] = ResourceConfig["Event"](
        version="v1",
        kind="Event",
        group="events.k8s.io",
        plural="events",
        scope=Scope.NAMESPACE,
    )
    action: str | None = Field(
        default=None,
        alias="action",
        description="action is what action was taken/failed regarding to the regarding object. It is machine-readable. This field cannot be empty for new Events and it can have at most 128 characters.",
    )
    api_version: Literal["events.k8s.io/v1"] = Field(
        default="events.k8s.io/v1",
        alias="apiVersion",
        description="APIVersion defines the versioned schema of this representation of an object. Servers should convert recognized schemas to the latest internal value, and may reject unrecognized values. More info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#resources",
    )
    deprecated_count: int | None = Field(
        default=None,
        alias="deprecatedCount",
        description="deprecatedCount is the deprecated field assuring backward compatibility with core.v1 Event type.",
    )
    deprecated_first_timestamp: datetime.datetime | None = Field(
        default=None,
        alias="deprecatedFirstTimestamp",
        description="deprecatedFirstTimestamp is the deprecated field assuring backward compatibility with core.v1 Event type.",
    )
    deprecated_last_timestamp: datetime.datetime | None = Field(
        default=None,
        alias="deprecatedLastTimestamp",
        description="deprecatedLastTimestamp is the deprecated field assuring backward compatibility with core.v1 Event type.",
    )
    deprecated_source: EventSource | None = Field(
        default=None,
        alias="deprecatedSource",
        description="deprecatedSource is the deprecated field assuring backward compatibility with core.v1 Event type.",
    )
    event_time: datetime.datetime = Field(
        ...,
        alias="eventTime",
        description="eventTime is the time when this Event was first observed. It is required.",
    )
    kind: Literal["Event"] = Field(
        default="Event",
        alias="kind",
        description="Kind is a string value representing the REST resource this object represents. Servers may infer this from the endpoint the client submits requests to. Cannot be updated. In CamelCase. More info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#types-kinds",
    )
    note: str | None = Field(
        default=None,
        alias="note",
        description="note is a human-readable description of the status of this operation. Maximal length of the note is 1kB, but libraries should be prepared to handle values up to 64kB.",
    )
    reason: str | None = Field(
        default=None,
        alias="reason",
        description="reason is why the action was taken. It is human-readable. This field cannot be empty for new Events and it can have at most 128 characters.",
    )
    regarding: ObjectReference | None = Field(
        default=None,
        alias="regarding",
        description="regarding contains the object this Event is about. In most cases it's an Object reporting controller implements, e.g. ReplicaSetController implements ReplicaSets and this event is emitted because it acts on some changes in a ReplicaSet object.",
    )
    related: ObjectReference | None = Field(
        default=None,
        alias="related",
        description="related is the optional secondary object for more complex actions. E.g. when regarding object triggers a creation or deletion of related object.",
    )
    reporting_controller: str | None = Field(
        default=None,
        alias="reportingController",
        description="reportingController is the name of the controller that emitted this Event, e.g. `kubernetes.io/kubelet`. This field cannot be empty for new Events.",
    )
    reporting_instance: str | None = Field(
        default=None,
        alias="reportingInstance",
        description="reportingInstance is the ID of the controller instance, e.g. `kubelet-xyzf`. This field cannot be empty for new Events and it can have at most 128 characters.",
    )
    series: EventSeries | None = Field(
        default=None,
        alias="series",
        description="series is data about the Event series this event represents or nil if it's a singleton Event.",
    )
    type_: str | None = Field(
        default=None,
        alias="type",
        description="type is the type of this event (Normal, Warning), new types could be added in the future. It is machine-readable. This field cannot be empty for new Events.",
    )
