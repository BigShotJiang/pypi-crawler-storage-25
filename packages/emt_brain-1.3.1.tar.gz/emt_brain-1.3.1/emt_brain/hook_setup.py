"""
hook_setup.py — Install HARNESS hook pipeline to ~/.claude/hooks/ (user scope).

Mirrors the pattern of mcp_setup.py. Hook scripts are bundled as package data
under emt_brain/hooks/ and installed to ~/.claude/hooks/ for user-level access.

Why user scope:
  HARNESS Protocol is cross-cutting — applies to all projects, not one repo.
  MCP servers are already at user scope; hooks should be consistent.
  Projects do not need to copy hooks — one install works everywhere.

settings-template.json is the single source of truth for hooks + top-level
model settings. It mirrors .claude/settings.json (project scope) with paths
rewritten to $HOME/.claude/hooks/ and project-specific hooks removed.
To update: edit settings-template.json directly — no Python dict to sync.
"""

import importlib.resources
import json
import shutil
from pathlib import Path

HOOK_SCRIPTS = [
    "context-pct.mjs",
    "signal-density-gate.mjs",
    "distraction-filter.mjs",
    "observation-masking.mjs",
    "compaction-trigger.mjs",
    "poisoning-detector.mjs",
    "session-cleanup.mjs",
    "precompact-instruction.mjs",
    "thinking_router_hook.mjs",
]

LIB_SCRIPTS = ["context-usage.mjs"]


def _load_template() -> dict:
    """
    Load settings-template.json (symlink → .claude/settings.json) and transform
    for user-scope install: rewrite relative hook paths to $HOME absolute paths,
    and strip project-specific ExitPlanMode hook.
    """
    pkg = importlib.resources.files("emt_brain")
    template_path = Path(str(pkg)) / "settings-template.json"
    raw = template_path.read_text()

    # Rewrite relative paths to $HOME absolute paths
    raw = raw.replace("node .claude/hooks/", "node $HOME/.claude/hooks/")

    data = json.loads(raw)

    # Strip project-specific ExitPlanMode hook (copies plan to .flezi-emt/plans/)
    post = data.get("hooks", {}).get("PostToolUse", [])
    data["hooks"]["PostToolUse"] = [h for h in post if h.get("matcher") != "ExitPlanMode"]

    return data


def get_hooks_source() -> Path:
    """Return the bundled hooks directory inside the installed package."""
    pkg = importlib.resources.files("emt_brain")
    return Path(str(pkg)) / "hooks"


def install_hook_scripts(dry_run: bool = False) -> tuple[Path, list[str], list[str]]:
    """
    Copy hook scripts from package data to ~/.claude/hooks/.
    Returns (hooks_dir, installed, skipped).
    """
    hooks_dir = Path.home() / ".claude" / "hooks"
    lib_dir = hooks_dir / "lib"

    if not dry_run:
        hooks_dir.mkdir(parents=True, exist_ok=True)
        lib_dir.mkdir(parents=True, exist_ok=True)

    source = get_hooks_source()
    installed: list[str] = []
    skipped: list[str] = []

    for script in HOOK_SCRIPTS:
        src = source / script
        dst = hooks_dir / script
        if dst.exists() and not dry_run:
            skipped.append(script)
            continue
        if not dry_run:
            shutil.copy2(src, dst)
        installed.append(script)

    for script in LIB_SCRIPTS:
        src = source / "lib" / script
        dst = lib_dir / script
        if dst.exists() and not dry_run:
            skipped.append(f"lib/{script}")
            continue
        if not dry_run:
            shutil.copy2(src, dst)
        installed.append(f"lib/{script}")

    return hooks_dir, installed, skipped


def update_user_settings(dry_run: bool = False, force: bool = False) -> tuple[Path, bool]:
    """
    Merge HARNESS settings from settings-template.json into ~/.claude/settings.json.
    Returns (settings_path, already_had_hooks).
    """
    settings_path = Path.home() / ".claude" / "settings.json"
    template = _load_template()

    existing: dict = {}
    if settings_path.exists():
        try:
            existing = json.loads(settings_path.read_text())
        except (json.JSONDecodeError, OSError):
            existing = {}

    already_had = "hooks" in existing and not force

    if not already_had or force:
        existing["hooks"] = template["hooks"]
        for key in ("advisorModel", "model", "permissions"):
            if key in template:
                existing.setdefault(key, template[key])
        # Merge env: add keys from template without overwriting existing keys
        if "env" in template:
            existing.setdefault("env", {})
            for k, v in template["env"].items():
                existing["env"].setdefault(k, v)
        if not dry_run:
            settings_path.parent.mkdir(parents=True, exist_ok=True)
            settings_path.write_text(json.dumps(existing, indent=2) + "\n")

    return settings_path, already_had
