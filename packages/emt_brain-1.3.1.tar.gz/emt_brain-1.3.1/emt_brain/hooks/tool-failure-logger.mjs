/**
 * tool-failure-logger.mjs — PostToolUseFailure
 * Tracks per-tool failure counts in .flezi-emt/.error-log.json.
 * After 3+ failures for the same tool, injects a targeted hint.
 *
 * Namespace: __tool_fail_<ToolName> keys — poisoning-detector skips all __ keys.
 * State cleared by session-cleanup.mjs on SessionStart.
 */

import { readFileSync, writeFileSync, mkdirSync, existsSync } from "node:fs";

const ERROR_LOG = ".flezi-emt/.error-log.json";
const THRESHOLD = 3;
const HINTS = {
  Edit:  "Check file path or write permissions.",
  Write: "Check file path or write permissions.",
  Bash:  "Check command syntax or permissions.",
  Read:  "Check file path or read permissions.",
};

try {
  const raw = await new Promise((resolve) => {
    let d = "";
    process.stdin.on("data", (c) => (d += c));
    process.stdin.on("end", () => resolve(d));
    process.stdin.on("error", () => resolve(""));
  });
  if (!raw.trim()) process.exit(0);

  const input = JSON.parse(raw);
  const toolName = input.tool_name ?? "Unknown";
  const key = `__tool_fail_${toolName}`;

  mkdirSync(".flezi-emt", { recursive: true });
  let log = {};
  if (existsSync(ERROR_LOG)) {
    try { log = JSON.parse(readFileSync(ERROR_LOG, "utf-8")); } catch {}
  }

  log[key] = (log[key] ?? 0) + 1;
  writeFileSync(ERROR_LOG, JSON.stringify(log));

  if (log[key] >= THRESHOLD) {
    const hint = HINTS[toolName] ?? "Review tool input.";
    process.stdout.write(`⚠ [tool-failure-logger] ${toolName} failed ${log[key]}× this session. ${hint}\n`);
  }
} catch {}
process.exit(0);
