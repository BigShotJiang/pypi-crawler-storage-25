/**
 * session-close-reminder.mjs — Stop
 * Reminds user to run /emt-sk-session-close when a session intent is active
 * but session-close has not been run yet.
 *
 * Sentinel files:
 *   .flezi-emt/.session-intent    — written by emt-sk-session-open
 *   .flezi-emt/.clear-approved    — written by emt-sk-session-close
 */

import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";

try {
  const raw = await new Promise((resolve) => {
    let d = "";
    process.stdin.on("data", (c) => (d += c));
    process.stdin.on("end", () => resolve(d));
    process.stdin.on("error", () => resolve(""));
  });
  const input = raw.trim() ? JSON.parse(raw) : {};
  const cwd = input.cwd || process.cwd();

  const intentPath = join(cwd, ".flezi-emt", ".session-intent");
  const clearPath  = join(cwd, ".flezi-emt", ".clear-approved");

  if (existsSync(intentPath) && !existsSync(clearPath)) {
    let intentLine = "";
    try {
      const text = readFileSync(intentPath, "utf-8").trim().slice(0, 80);
      if (text) intentLine = ` (${text})`;
    } catch {}
    process.stdout.write(`[HARNESS] Session intent active${intentLine} — run /emt-sk-session-close before ending.\n`);
  }
} catch {}
process.exit(0);
