/**
 * tool_failure_logger.test.mjs
 * Tests for tool-failure-logger.mjs hook (PostToolUseFailure).
 *
 * Strategy: spawn as subprocess with mock PostToolUseFailure JSON on stdin;
 * verify warning output after threshold is reached, and key isolation.
 *
 * Run: node --test flezi-emt/hooks/tests/tool_failure_logger.test.mjs
 */

import { test, describe } from "node:test";
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { mkdtempSync, writeFileSync, readFileSync, rmSync, mkdirSync } from "node:fs";
import { join, resolve } from "node:path";
import { tmpdir } from "node:os";

const HOOK_PATH = resolve(import.meta.dirname, "../tool-failure-logger.mjs");
const THRESHOLD = 3;

function runHook(toolName, cwd) {
  return spawnSync("node", [HOOK_PATH], {
    input: JSON.stringify({ tool_name: toolName, error_message: "test error" }),
    encoding: "utf8",
    timeout: 5000,
    cwd,
  });
}

function makeTmpDir() {
  const dir = mkdtempSync(join(tmpdir(), "tool-fail-test-"));
  mkdirSync(join(dir, ".flezi-emt"), { recursive: true });
  return dir;
}

describe("tool-failure-logger threshold behavior", () => {
  test("first failure: no output (count=1 < threshold)", () => {
    const tmp = makeTmpDir();
    try {
      const r = runHook("Edit", tmp);
      assert.equal(r.status, 0);
      assert.equal((r.stdout ?? "").trim(), "");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("second failure: no output (count=2 < threshold)", () => {
    const tmp = makeTmpDir();
    try {
      runHook("Edit", tmp);
      const r = runHook("Edit", tmp);
      assert.equal(r.status, 0);
      assert.equal((r.stdout ?? "").trim(), "");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("third failure: outputs warning with tool name, count, and hint", () => {
    const tmp = makeTmpDir();
    try {
      runHook("Edit", tmp);
      runHook("Edit", tmp);
      const r = runHook("Edit", tmp);
      assert.equal(r.status, 0);
      const out = r.stdout ?? "";
      assert.ok(out.includes("[tool-failure-logger]"), "should mention hook name");
      assert.ok(out.includes("Edit"), "should mention tool name");
      assert.ok(out.includes(`${THRESHOLD}×`), "should report threshold count");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("4th+ failures: continues warning (not just once at threshold)", () => {
    const tmp = makeTmpDir();
    try {
      for (let i = 0; i < THRESHOLD + 1; i++) runHook("Bash", tmp);
      const r = runHook("Bash", tmp);
      assert.equal(r.status, 0);
      assert.ok((r.stdout ?? "").includes("[tool-failure-logger]"), "should still warn after threshold");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("different tools do not share counts", () => {
    const tmp = makeTmpDir();
    try {
      runHook("Edit", tmp);
      runHook("Edit", tmp);
      // Bash only 1× — should not trigger
      const r = runHook("Bash", tmp);
      assert.equal(r.status, 0);
      assert.equal((r.stdout ?? "").trim(), "");
      // Edit still at 2 — should not trigger
      const r2 = runHook("Edit", tmp); // Edit now at 3 — should trigger
      assert.ok((r2.stdout ?? "").includes("Edit"), "Edit should trigger at 3");
      assert.ok(!(r2.stdout ?? "").includes("Bash"), "Bash should not appear in Edit warning");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });
});

describe("tool-failure-logger hints", () => {
  test("Edit hint mentions file path or write permissions", () => {
    const tmp = makeTmpDir();
    try {
      for (let i = 0; i < THRESHOLD; i++) runHook("Edit", tmp);
      const r = runHook("Edit", tmp);
      assert.ok((r.stdout ?? "").toLowerCase().includes("file path"), "Edit hint should mention file path");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("Bash hint mentions syntax or permissions", () => {
    const tmp = makeTmpDir();
    try {
      for (let i = 0; i < THRESHOLD; i++) runHook("Bash", tmp);
      const r = runHook("Bash", tmp);
      assert.ok((r.stdout ?? "").toLowerCase().includes("syntax"), "Bash hint should mention syntax");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });
});

describe("tool-failure-logger log state", () => {
  test("pre-seeded log with count=2 triggers on next call", () => {
    const tmp = makeTmpDir();
    try {
      const logPath = join(tmp, ".flezi-emt", ".error-log.json");
      writeFileSync(logPath, JSON.stringify({ "__tool_fail_Edit": 2 }));
      const r = runHook("Edit", tmp);
      assert.equal(r.status, 0);
      assert.ok((r.stdout ?? "").includes("[tool-failure-logger]"), "should trigger with pre-seeded count");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("__tool_fail_* keys written to log are namespaced (__ prefix)", () => {
    const tmp = makeTmpDir();
    try {
      runHook("Write", tmp);
      const logPath = join(tmp, ".flezi-emt", ".error-log.json");
      const log = JSON.parse(readFileSync(logPath, "utf-8"));
      const keys = Object.keys(log);
      assert.ok(keys.every((k) => k.startsWith("__")), "all keys should start with __ for poisoning-detector isolation");
      assert.ok(keys.includes("__tool_fail_Write"), "should have __tool_fail_Write key");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });
});

describe("tool-failure-logger edge cases", () => {
  test("empty stdin: exits silently (exit 0, no output)", () => {
    const r = spawnSync("node", [HOOK_PATH], {
      input: "",
      encoding: "utf8",
      timeout: 5000,
    });
    assert.equal(r.status, 0);
    assert.equal((r.stdout ?? "").trim(), "");
  });

  test("malformed stdin: exits silently (exit 0, no crash)", () => {
    const r = spawnSync("node", [HOOK_PATH], {
      input: "not valid json",
      encoding: "utf8",
      timeout: 5000,
    });
    assert.equal(r.status, 0);
  });
});
