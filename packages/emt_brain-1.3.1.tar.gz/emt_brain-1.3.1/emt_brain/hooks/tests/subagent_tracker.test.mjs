/**
 * subagent_tracker.test.mjs
 * Tests for subagent-tracker.mjs hook (SubagentStart / SubagentStop).
 *
 * Run: node --test flezi-emt/hooks/tests/subagent_tracker.test.mjs
 */

import { test, describe } from "node:test";
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import {
  mkdtempSync,
  writeFileSync,
  readFileSync,
  rmSync,
  mkdirSync,
  existsSync,
} from "node:fs";
import { join, resolve } from "node:path";
import { tmpdir } from "node:os";

const HOOK_PATH = resolve(
  import.meta.dirname,
  "../subagent-tracker.mjs"
);

function makeTmpDir() {
  const dir = mkdtempSync(join(tmpdir(), "subagent-tracker-test-"));
  mkdirSync(join(dir, ".flezi-emt"), { recursive: true });
  return dir;
}

function runHook(mode, input, cwd) {
  return spawnSync("node", [HOOK_PATH, mode], {
    input: JSON.stringify(input),
    encoding: "utf8",
    timeout: 5000,
    cwd,
  });
}

function readLog(cwd) {
  const logPath = join(cwd, ".flezi-emt", ".subagent-log.jsonl");
  if (!existsSync(logPath)) return [];
  return readFileSync(logPath, "utf-8")
    .trim()
    .split("\n")
    .filter(Boolean)
    .map((l) => JSON.parse(l));
}

describe("subagent-tracker: start mode", () => {
  test("appends start record to .subagent-log.jsonl", () => {
    const tmp = makeTmpDir();
    try {
      runHook("start", { agent_id: "abc123", task_description: "build spec" }, tmp);
      const records = readLog(tmp);
      assert.equal(records.length, 1);
      assert.equal(records[0].event, "start");
      assert.equal(records[0].agent_id, "abc123");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("start record has agent_id, task, ts, event fields", () => {
    const tmp = makeTmpDir();
    try {
      runHook("start", { agent_id: "xyz", task_description: "generate idea" }, tmp);
      const [rec] = readLog(tmp);
      assert.ok("agent_id" in rec, "should have agent_id");
      assert.ok("task" in rec, "should have task");
      assert.ok("ts" in rec, "should have ts");
      assert.ok("event" in rec, "should have event");
      assert.equal(rec.task, "generate idea");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("truncates task to 200 chars", () => {
    const tmp = makeTmpDir();
    try {
      const longTask = "t".repeat(300);
      runHook("start", { agent_id: "a", task_description: longTask }, tmp);
      const [rec] = readLog(tmp);
      assert.ok(rec.task.length <= 200, "task should be truncated to 200 chars");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("injects [Contract] token budget in stdout", () => {
    const tmp = makeTmpDir();
    try {
      const r = runHook("start", { agent_id: "a", task_description: "test" }, tmp);
      assert.ok(r.stdout.includes("[Contract] Return ≤1,500 tokens"), "should inject token contract");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("injects [Expected] sections if pending-deliverable.json exists", () => {
    const tmp = makeTmpDir();
    try {
      writeFileSync(
        join(tmp, ".flezi-emt", ".pending-deliverable.json"),
        JSON.stringify({ required_sections: ["## Summary", "## Artifacts"], max_chars: 6000 })
      );
      const r = runHook("start", { agent_id: "a", task_description: "test" }, tmp);
      assert.ok(r.stdout.includes("[Expected]"), "should inject [Expected] line");
      assert.ok(r.stdout.includes("## Summary"), "should list required sections");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("works without pending-deliverable.json (no [Expected] line)", () => {
    const tmp = makeTmpDir();
    try {
      const r = runHook("start", { agent_id: "a", task_description: "test" }, tmp);
      assert.ok(!r.stdout.includes("[Expected]"), "should not inject [Expected] without pending-deliverable");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });
});

describe("subagent-tracker: stop mode", () => {
  test("appends stop record to .subagent-log.jsonl", () => {
    const tmp = makeTmpDir();
    try {
      runHook("stop", { agent_id: "abc123", status: "success", output: "result text", duration_ms: 1234 }, tmp);
      const records = readLog(tmp);
      assert.equal(records.length, 1);
      assert.equal(records[0].event, "stop");
      assert.equal(records[0].agent_id, "abc123");
      assert.equal(records[0].status, "success");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("records output_chars correctly", () => {
    const tmp = makeTmpDir();
    try {
      runHook("stop", { agent_id: "a", status: "success", output: "hello world", duration_ms: 100 }, tmp);
      const [rec] = readLog(tmp);
      assert.equal(rec.output_chars, "hello world".length);
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("timeout status outputs warning", () => {
    const tmp = makeTmpDir();
    try {
      const r = runHook("stop", { agent_id: "timed-out-agent", status: "timeout", output: "", duration_ms: null }, tmp);
      assert.ok(r.stdout.includes("⚠ [subagent-tracker]"), "should warn on timeout");
      assert.ok(r.stdout.includes("timed-out-agent"), "warning should include agent_id");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("success status produces no stdout output", () => {
    const tmp = makeTmpDir();
    try {
      const r = runHook("stop", { agent_id: "a", status: "success", output: "done", duration_ms: 500 }, tmp);
      assert.equal((r.stdout ?? "").trim(), "");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });
});

describe("subagent-tracker: edge cases", () => {
  test("empty stdin: exit 0, no output", () => {
    const r = spawnSync("node", [HOOK_PATH, "start"], {
      input: "",
      encoding: "utf8",
      timeout: 5000,
    });
    assert.equal(r.status, 0);
    assert.equal((r.stdout ?? "").trim(), "");
  });

  test("malformed stdin: exit 0, no crash", () => {
    const r = spawnSync("node", [HOOK_PATH, "start"], {
      input: "not valid json }{",
      encoding: "utf8",
      timeout: 5000,
    });
    assert.equal(r.status, 0);
  });
});
