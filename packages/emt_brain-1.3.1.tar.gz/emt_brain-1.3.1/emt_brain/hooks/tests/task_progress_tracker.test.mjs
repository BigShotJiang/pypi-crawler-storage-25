/**
 * task_progress_tracker.test.mjs
 * Tests for task-progress-tracker.mjs hook (PostToolUse TodoWrite).
 *
 * Run: node --test flezi-emt/hooks/tests/task_progress_tracker.test.mjs
 */

import { test, describe } from "node:test";
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import {
  mkdtempSync,
  readFileSync,
  rmSync,
  mkdirSync,
  existsSync,
} from "node:fs";
import { join, resolve } from "node:path";
import { tmpdir } from "node:os";

const HOOK_PATH = resolve(
  import.meta.dirname,
  "../task-progress-tracker.mjs"
);

function makeTmpDir() {
  const dir = mkdtempSync(join(tmpdir(), "task-progress-test-"));
  mkdirSync(join(dir, ".flezi-emt"), { recursive: true });
  return dir;
}

function makeTodos(specs) {
  return specs.map(([content, status]) => ({ content, status, activeForm: content }));
}

function runHook(toolInput, cwd) {
  return spawnSync("node", [HOOK_PATH], {
    input: JSON.stringify({ tool_name: "TodoWrite", tool_input: toolInput }),
    encoding: "utf8",
    timeout: 5000,
    cwd,
  });
}

function readProgress(cwd) {
  const p = join(cwd, ".flezi-emt", ".task-progress.json");
  if (!existsSync(p)) return null;
  return JSON.parse(readFileSync(p, "utf-8"));
}

describe("task-progress-tracker: progress tracking", () => {
  test("writes task-progress.json with correct total and done", () => {
    const tmp = makeTmpDir();
    try {
      const todos = makeTodos([
        ["Task A", "completed"],
        ["Task B", "in_progress"],
        ["Task C", "pending"],
      ]);
      runHook({ todos }, tmp);
      const progress = readProgress(tmp);
      assert.equal(progress.total, 3);
      assert.equal(progress.done, 1);
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("all tasks completed: done == total", () => {
    const tmp = makeTmpDir();
    try {
      const todos = makeTodos([
        ["Task A", "completed"],
        ["Task B", "completed"],
      ]);
      runHook({ todos }, tmp);
      const progress = readProgress(tmp);
      assert.equal(progress.total, 2);
      assert.equal(progress.done, 2);
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("no tasks completed: done == 0", () => {
    const tmp = makeTmpDir();
    try {
      const todos = makeTodos([
        ["Task A", "pending"],
        ["Task B", "in_progress"],
      ]);
      runHook({ todos }, tmp);
      const progress = readProgress(tmp);
      assert.equal(progress.total, 2);
      assert.equal(progress.done, 0);
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("subsequent call overwrites (latest state wins)", () => {
    const tmp = makeTmpDir();
    try {
      const todos1 = makeTodos([["Task A", "pending"], ["Task B", "pending"]]);
      runHook({ todos: todos1 }, tmp);
      const todos2 = makeTodos([["Task A", "completed"], ["Task B", "in_progress"]]);
      runHook({ todos: todos2 }, tmp);
      const progress = readProgress(tmp);
      assert.equal(progress.total, 2);
      assert.equal(progress.done, 1);
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("no stdout output (silent hook)", () => {
    const tmp = makeTmpDir();
    try {
      const todos = makeTodos([["Task A", "completed"]]);
      const r = runHook({ todos }, tmp);
      assert.equal((r.stdout ?? "").trim(), "");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });
});

describe("task-progress-tracker: edge cases", () => {
  test("empty todos array: no file written", () => {
    const tmp = makeTmpDir();
    try {
      runHook({ todos: [] }, tmp);
      assert.ok(!existsSync(join(tmp, ".flezi-emt", ".task-progress.json")), "should not write for empty todos");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("missing todos field: no file written", () => {
    const tmp = makeTmpDir();
    try {
      runHook({}, tmp);
      assert.ok(!existsSync(join(tmp, ".flezi-emt", ".task-progress.json")), "should not write without todos");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("empty stdin: exit 0, no output", () => {
    const r = spawnSync("node", [HOOK_PATH], {
      input: "",
      encoding: "utf8",
      timeout: 5000,
    });
    assert.equal(r.status, 0);
    assert.equal((r.stdout ?? "").trim(), "");
  });

  test("malformed stdin: exit 0, no crash", () => {
    const r = spawnSync("node", [HOOK_PATH], {
      input: "not json }{",
      encoding: "utf8",
      timeout: 5000,
    });
    assert.equal(r.status, 0);
  });
});
