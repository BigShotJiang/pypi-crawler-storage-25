/**
 * session_close_reminder.test.mjs
 * Tests for session-close-reminder.mjs hook (Stop).
 *
 * Strategy: spawn as subprocess with mock Stop JSON on stdin;
 * control sentinel files in temp cwd to verify reminder logic.
 *
 * Run: node --test flezi-emt/hooks/tests/session_close_reminder.test.mjs
 */

import { test, describe } from "node:test";
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { mkdtempSync, writeFileSync, rmSync, mkdirSync } from "node:fs";
import { join, resolve } from "node:path";
import { tmpdir } from "node:os";

const HOOK_PATH = resolve(import.meta.dirname, "../session-close-reminder.mjs");

function makeTmpDir() {
  const dir = mkdtempSync(join(tmpdir(), "session-reminder-test-"));
  mkdirSync(join(dir, ".flezi-emt"), { recursive: true });
  return dir;
}

function runHook(cwd) {
  return spawnSync("node", [HOOK_PATH], {
    input: JSON.stringify({ cwd }),
    encoding: "utf8",
    timeout: 5000,
    cwd,
  });
}

describe("session-close-reminder: reminder conditions", () => {
  test("no .session-intent file: no output (session never opened)", () => {
    const tmp = makeTmpDir();
    try {
      const r = runHook(tmp);
      assert.equal(r.status, 0);
      assert.equal((r.stdout ?? "").trim(), "");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test(".session-intent exists, no .clear-approved: outputs reminder", () => {
    const tmp = makeTmpDir();
    try {
      writeFileSync(join(tmp, ".flezi-emt", ".session-intent"), "implement feature X");
      const r = runHook(tmp);
      assert.equal(r.status, 0);
      const out = r.stdout ?? "";
      assert.ok(out.includes("[HARNESS]"), "should include [HARNESS] prefix");
      assert.ok(out.includes("Session intent active"), "should mention session intent");
      assert.ok(out.includes("/emt-sk-session-close"), "should mention the skill to run");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("both .session-intent and .clear-approved exist: no output (already closed)", () => {
    const tmp = makeTmpDir();
    try {
      writeFileSync(join(tmp, ".flezi-emt", ".session-intent"), "implement feature X");
      writeFileSync(join(tmp, ".flezi-emt", ".clear-approved"), "1");
      const r = runHook(tmp);
      assert.equal(r.status, 0);
      assert.equal((r.stdout ?? "").trim(), "");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("only .clear-approved exists (no intent): no output", () => {
    const tmp = makeTmpDir();
    try {
      writeFileSync(join(tmp, ".flezi-emt", ".clear-approved"), "1");
      const r = runHook(tmp);
      assert.equal(r.status, 0);
      assert.equal((r.stdout ?? "").trim(), "");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });
});

describe("session-close-reminder: intent content in output", () => {
  test("intent text appears in reminder", () => {
    const tmp = makeTmpDir();
    try {
      writeFileSync(join(tmp, ".flezi-emt", ".session-intent"), "harness-refactor session");
      const r = runHook(tmp);
      assert.ok((r.stdout ?? "").includes("harness-refactor session"), "should include intent text");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("long intent (>80 chars) is truncated — output still valid", () => {
    const tmp = makeTmpDir();
    try {
      const longIntent = "a".repeat(200);
      writeFileSync(join(tmp, ".flezi-emt", ".session-intent"), longIntent);
      const r = runHook(tmp);
      assert.equal(r.status, 0);
      const out = r.stdout ?? "";
      assert.ok(out.includes("[HARNESS]"), "should still output reminder for long intent");
      // The parenthetical should contain at most 80 chars of intent
      const match = out.match(/\(([^)]+)\)/);
      if (match) {
        assert.ok(match[1].length <= 80, "intent in output should be truncated to 80 chars");
      }
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });
});

describe("session-close-reminder: edge cases", () => {
  test("empty stdin: exits silently (exit 0, no output)", () => {
    const r = spawnSync("node", [HOOK_PATH], {
      input: "",
      encoding: "utf8",
      timeout: 5000,
    });
    assert.equal(r.status, 0);
    assert.equal((r.stdout ?? "").trim(), "");
  });

  test("malformed stdin: exits silently (exit 0, no crash)", () => {
    const r = spawnSync("node", [HOOK_PATH], {
      input: "not valid json }{",
      encoding: "utf8",
      timeout: 5000,
    });
    assert.equal(r.status, 0);
  });
});
