/**
 * verify_deliverables.test.mjs
 * Tests for verify-deliverables.mjs hook (SubagentStop).
 *
 * Run: node --test flezi-emt/hooks/tests/verify_deliverables.test.mjs
 */

import { test, describe } from "node:test";
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import {
  mkdtempSync,
  writeFileSync,
  readFileSync,
  rmSync,
  mkdirSync,
  existsSync,
} from "node:fs";
import { join, resolve } from "node:path";
import { tmpdir } from "node:os";

const HOOK_PATH = resolve(
  import.meta.dirname,
  "../verify-deliverables.mjs"
);

function makeTmpDir() {
  const dir = mkdtempSync(join(tmpdir(), "verify-deliverables-test-"));
  mkdirSync(join(dir, ".flezi-emt"), { recursive: true });
  return dir;
}

function runHook(input, cwd) {
  return spawnSync("node", [HOOK_PATH], {
    input: JSON.stringify(input),
    encoding: "utf8",
    timeout: 5000,
    cwd,
  });
}

describe("verify-deliverables: Tier 1 baseline checks", () => {
  test("empty output warns about empty output", () => {
    const tmp = makeTmpDir();
    try {
      const r = runHook({ status: "success", output: "", agent_id: "test" }, tmp);
      assert.ok(r.stdout.includes("⚠ [verify-deliverables]"), "should warn");
      assert.ok(r.stdout.includes("empty output"), "should mention empty output");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("whitespace-only output warns about empty output", () => {
    const tmp = makeTmpDir();
    try {
      const r = runHook({ status: "success", output: "   \n\t  ", agent_id: "test" }, tmp);
      assert.ok(r.stdout.includes("empty output"), "whitespace-only should be treated as empty");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("output >6000 chars warns about budget exceeded", () => {
    const tmp = makeTmpDir();
    try {
      const r = runHook({ status: "success", output: "x".repeat(6001), agent_id: "test" }, tmp);
      assert.ok(r.stdout.includes("exceeds budget"), "should warn about budget");
      assert.ok(r.stdout.includes("6001"), "should include char count");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("output ending with '...' warns about truncation", () => {
    const tmp = makeTmpDir();
    try {
      const r = runHook({ status: "success", output: "Some result...", agent_id: "test" }, tmp);
      assert.ok(r.stdout.includes("truncated"), "should warn about truncation");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("output ending with '[truncated]' warns about truncation", () => {
    const tmp = makeTmpDir();
    try {
      const r = runHook({ status: "success", output: "Result [truncated]", agent_id: "test" }, tmp);
      assert.ok(r.stdout.includes("truncated"), "should warn about [truncated] suffix");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("normal output <6000 chars: no output", () => {
    const tmp = makeTmpDir();
    try {
      const r = runHook({ status: "success", output: "Good result here.", agent_id: "test" }, tmp);
      assert.equal((r.stdout ?? "").trim(), "");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("timeout status: no output (subagent-tracker handles it)", () => {
    const tmp = makeTmpDir();
    try {
      const r = runHook({ status: "timeout", output: "", agent_id: "test" }, tmp);
      assert.equal((r.stdout ?? "").trim(), "");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });
});

describe("verify-deliverables: Tier 2 schema checks", () => {
  test("pending-deliverable with missing sections warns with section names", () => {
    const tmp = makeTmpDir();
    try {
      writeFileSync(
        join(tmp, ".flezi-emt", ".pending-deliverable.json"),
        JSON.stringify({ required_sections: ["## Summary", "## Artifacts"] })
      );
      const r = runHook({ status: "success", output: "No structure here.", agent_id: "test" }, tmp);
      assert.ok(r.stdout.includes("Missing required sections"), "should warn about missing sections");
      assert.ok(r.stdout.includes("## Summary"), "should list missing section");
      assert.ok(r.stdout.includes("## Artifacts"), "should list all missing sections");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("pending-deliverable with max_chars exceeded warns with counts", () => {
    const tmp = makeTmpDir();
    try {
      writeFileSync(
        join(tmp, ".flezi-emt", ".pending-deliverable.json"),
        JSON.stringify({ max_chars: 100 })
      );
      const r = runHook({ status: "success", output: "x".repeat(200), agent_id: "test" }, tmp);
      assert.ok(r.stdout.includes("workflow limit"), "should warn about workflow limit");
      assert.ok(r.stdout.includes("200"), "should show actual char count");
      assert.ok(r.stdout.includes("100"), "should show max_chars");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("pending-deliverable satisfied: no warning", () => {
    const tmp = makeTmpDir();
    try {
      writeFileSync(
        join(tmp, ".flezi-emt", ".pending-deliverable.json"),
        JSON.stringify({ required_sections: ["## Summary"], max_chars: 6000 })
      );
      const r = runHook(
        { status: "success", output: "## Summary\nAll good here.", agent_id: "test" },
        tmp
      );
      assert.equal((r.stdout ?? "").trim(), "");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("pending-deliverable is consumed (deleted) after SubagentStop", () => {
    const tmp = makeTmpDir();
    try {
      const specPath = join(tmp, ".flezi-emt", ".pending-deliverable.json");
      writeFileSync(specPath, JSON.stringify({ required_sections: [] }));
      runHook({ status: "success", output: "result", agent_id: "test" }, tmp);
      assert.ok(!existsSync(specPath), "pending-deliverable should be deleted after hook runs");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });

  test("no pending-deliverable: Tier 1 only (no schema error)", () => {
    const tmp = makeTmpDir();
    try {
      const r = runHook({ status: "success", output: "Good output.", agent_id: "test" }, tmp);
      assert.equal(r.status, 0);
      assert.equal((r.stdout ?? "").trim(), "");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });
});

describe("verify-deliverables: edge cases", () => {
  test("empty stdin: exit 0, no output", () => {
    const r = spawnSync("node", [HOOK_PATH], {
      input: "",
      encoding: "utf8",
      timeout: 5000,
    });
    assert.equal(r.status, 0);
    assert.equal((r.stdout ?? "").trim(), "");
  });

  test("malformed stdin: exit 0, no crash", () => {
    const r = spawnSync("node", [HOOK_PATH], {
      input: "not valid json }{",
      encoding: "utf8",
      timeout: 5000,
    });
    assert.equal(r.status, 0);
  });
});
