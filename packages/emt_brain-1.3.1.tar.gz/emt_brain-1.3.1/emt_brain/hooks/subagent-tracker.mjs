/**
 * subagent-tracker.mjs — SubagentStart (argv[2]="start") / SubagentStop (argv[2]="stop")
 *
 * SubagentStart: logs start record + injects token budget contract via stdout
 * SubagentStop:  logs stop record + warns on timeout
 *
 * State file: .flezi-emt/.subagent-log.jsonl
 * Cleared by session-cleanup.mjs on SessionStart.
 *
 * NOTE on injection channel: SubagentStart stdout is forwarded to sub-agent context
 * (confirmed via probe). hookSpecificOutput for SubagentStart is not in the validated
 * schema so stdout is the correct channel.
 */

import { appendFileSync, existsSync, readFileSync, mkdirSync } from "node:fs";

const LOG_PATH = ".flezi-emt/.subagent-log.jsonl";
const PENDING_DELIVERABLE = ".flezi-emt/.pending-deliverable.json";

const mode = process.argv[2]; // "start" or "stop"

try {
  const raw = await new Promise((resolve) => {
    let d = "";
    process.stdin.on("data", (c) => (d += c));
    process.stdin.on("end", () => resolve(d));
    process.stdin.on("error", () => resolve(""));
  });
  if (!raw.trim()) process.exit(0);

  const input = JSON.parse(raw);
  mkdirSync(".flezi-emt", { recursive: true });

  if (mode === "start") {
    const record = {
      event: "start",
      agent_id: input.agent_id ?? "unknown",
      task: (input.task_description ?? "").slice(0, 200),
      ts: Date.now(),
    };
    appendFileSync(LOG_PATH, JSON.stringify(record) + "\n");

    // Inject token contract + optional expected-format hint via stdout
    const parts = [
      "[Contract] Return ≤1,500 tokens. Coordinator does NOT re-expand exploration context.",
    ];

    const spec = existsSync(PENDING_DELIVERABLE)
      ? (() => {
          try {
            return JSON.parse(readFileSync(PENDING_DELIVERABLE, "utf-8"));
          } catch {
            return null;
          }
        })()
      : null;

    if (spec?.required_sections?.length > 0) {
      parts.push(
        `[Expected] Required sections: ${spec.required_sections.join(", ")}`
      );
    }

    process.stdout.write(parts.join("\n") + "\n");
  } else if (mode === "stop") {
    const stop = {
      event: "stop",
      agent_id: input.agent_id ?? "unknown",
      status: input.status ?? "unknown",
      output_chars: (input.output ?? "").length,
      duration_ms: input.duration_ms ?? null,
      ts: Date.now(),
    };
    appendFileSync(LOG_PATH, JSON.stringify(stop) + "\n");

    if (input.status === "timeout") {
      process.stdout.write(
        `⚠ [subagent-tracker] Sub-agent timed out (agent_id: ${input.agent_id ?? "unknown"}). Output may be incomplete.\n`
      );
    }
  }
} catch {}
process.exit(0);
