/**
 * verify-deliverables.mjs — SubagentStop
 * Two-tier validation of sub-agent output.
 *
 * Tier 1 — Baseline checks (always run):
 *   - empty output
 *   - exceeds 6000-char budget (≈1500 tokens; CLAUDE.md contract)
 *   - appears truncated
 *
 * Tier 2 — Schema checks (opt-in via .flezi-emt/.pending-deliverable.json):
 *   - required sections present
 *   - max_chars per workflow limit
 *   File is consumed (deleted) after first read — one-shot protocol.
 *
 * Timeout sub-agents are skipped: subagent-tracker.mjs already warned.
 * Always exit 0 — never blocks the coordinator.
 */

import { existsSync, readFileSync, unlinkSync, mkdirSync } from "node:fs";

const PENDING_DELIVERABLE = ".flezi-emt/.pending-deliverable.json";

try {
  const raw = await new Promise((resolve) => {
    let d = "";
    process.stdin.on("data", (c) => (d += c));
    process.stdin.on("end", () => resolve(d));
    process.stdin.on("error", () => resolve(""));
  });
  if (!raw.trim()) process.exit(0);

  const input = JSON.parse(raw);
  const output = input.output ?? "";

  // Skip timeout — subagent-tracker.mjs already warned
  if (input.status === "timeout") process.exit(0);

  const warnings = [];

  // Tier 1: Baseline checks (always)
  if (!output.trim()) {
    warnings.push("⚠ [verify-deliverables] Sub-agent returned empty output.");
  } else {
    if (output.length > 6000) {
      warnings.push(
        `⚠ [verify-deliverables] Output exceeds budget: ${output.length} chars (max ~6000). Coordinator will not re-expand — request a condensed version.`
      );
    }
    if (/\.\.\.$|\[truncated\]$/i.test(output.trimEnd())) {
      warnings.push(
        "⚠ [verify-deliverables] Output appears truncated — may be missing conclusions."
      );
    }
  }

  // Tier 2: Schema (opt-in when .pending-deliverable.json exists)
  if (existsSync(PENDING_DELIVERABLE)) {
    let spec = null;
    try {
      spec = JSON.parse(readFileSync(PENDING_DELIVERABLE, "utf-8"));
    } catch {}
    try {
      unlinkSync(PENDING_DELIVERABLE); // consume — one-shot
    } catch {}

    if (spec) {
      const missing = (spec.required_sections ?? []).filter(
        (s) => !output.includes(s)
      );
      if (missing.length > 0) {
        warnings.push(
          `⚠ [verify-deliverables] Missing required sections: ${missing.join(", ")}`
        );
      }
      if (spec.max_chars && output.length > spec.max_chars) {
        warnings.push(
          `⚠ [verify-deliverables] Output exceeds workflow limit: ${output.length} / ${spec.max_chars} chars`
        );
      }
    }
  }

  if (warnings.length > 0) {
    process.stdout.write(warnings.join("\n") + "\n");
  }
} catch {}
process.exit(0);
