/**
 * task-progress-tracker.mjs — PostToolUse (matcher: "TodoWrite")
 * Tracks todo task progress from TodoWrite tool calls.
 *
 * On each TodoWrite call, reads the updated todos list from tool_input
 * and writes { total, done } to .flezi-emt/.task-progress.json.
 * context-pct.mjs reads this file to show [HARNESS/todos] M/N done.
 *
 * Uses PostToolUse + matcher:"TodoWrite" — no TaskCreated/TaskCompleted
 * events needed (reliable, works in all Claude Code builds).
 *
 * State cleared by session-cleanup.mjs on SessionStart.
 */

import { writeFileSync, mkdirSync } from "node:fs";

try {
  const raw = await new Promise((resolve) => {
    let d = "";
    process.stdin.on("data", (c) => (d += c));
    process.stdin.on("end", () => resolve(d));
    process.stdin.on("error", () => resolve(""));
  });
  if (!raw.trim()) process.exit(0);

  const input = JSON.parse(raw);

  // PostToolUse: tool_input contains the todos array
  const todos = input.tool_input?.todos;
  if (!Array.isArray(todos) || todos.length === 0) process.exit(0);

  const total = todos.length;
  const done = todos.filter((t) => t.status === "completed").length;

  mkdirSync(".flezi-emt", { recursive: true });
  writeFileSync(
    ".flezi-emt/.task-progress.json",
    JSON.stringify({ total, done })
  );
} catch {}
process.exit(0);
