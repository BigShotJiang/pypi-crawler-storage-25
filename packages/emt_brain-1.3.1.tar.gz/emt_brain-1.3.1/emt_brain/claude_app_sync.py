"""claude_app_sync.py — Install EMT co-work skills into the Claude desktop app.

Skills are installed as .skill files (ZIP containing SKILL.md). Each .skill file
is opened with the Claude desktop app, which shows a preview dialog so the user
can confirm installation into their personal skills.
"""
from __future__ import annotations

import io
import subprocess
import zipfile
from dataclasses import dataclass
from pathlib import Path

CLAUDE_APP_DATA = Path.home() / "Library" / "Application Support" / "Claude"
CLAUDE_APP = Path("/Applications/Claude.app")

# Skill IDs that belong to the co-work bundle
COWORK_SKILL_IDS: list[str] = [
    "emt-sk-brand-guide",
    "emt-sk-docx",
    "emt-sk-jp-trans",
    "emt-sk-pdf",
    "emt-sk-pptx"
]


@dataclass
class SkillSyncResult:
    skill_id: str
    action: str  # "packaged", "missing"
    dest: Path | None = None
    error: str | None = None


def is_available() -> bool:
    """Return True if Claude desktop app is installed."""
    return CLAUDE_APP.exists() or CLAUDE_APP_DATA.exists()


def _make_skill_zip(skill_md_content: str) -> bytes:
    """Create an in-memory ZIP (the .skill format) containing SKILL.md."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("SKILL.md", skill_md_content.encode("utf-8"))
    return buf.getvalue()


def generate_skill_files(
    source_skills_root: Path,
    output_dir: Path,
    skill_ids: list[str] | None = None,
    dry_run: bool = False,
) -> list[SkillSyncResult]:
    """
    Generate .skill ZIP files from SKILL.md sources.

    Args:
        source_skills_root: directory with <skill-id>/SKILL.md (e.g. ~/.claude/skills/)
        output_dir:         where to write <skill-id>.skill files
        skill_ids:          which skills to package; defaults to COWORK_SKILL_IDS
        dry_run:            preview without writing
    """
    if skill_ids is None:
        skill_ids = COWORK_SKILL_IDS

    if not dry_run:
        output_dir.mkdir(parents=True, exist_ok=True)

    results: list[SkillSyncResult] = []
    for sid in skill_ids:
        src_md = source_skills_root / sid / "SKILL.md"
        if not src_md.exists():
            results.append(SkillSyncResult(skill_id=sid, action="missing",
                                           error="SKILL.md not found in source"))
            continue

        dest = output_dir / f"{sid}.skill"
        if not dry_run:
            content = src_md.read_text(encoding="utf-8")
            dest.write_bytes(_make_skill_zip(content))

        results.append(SkillSyncResult(skill_id=sid, action="packaged", dest=dest))

    return results


def open_skill_files_sequential(skill_files: list[Path], delay: float = 5.0) -> None:
    """Open .skill files one at a time with a delay so each dialog can be confirmed.

    Claude's skill import dialog is modal — opening all files at once causes the
    app to drop everything after the first file. Opening sequentially with a delay
    gives the user time to click Install before the next file is sent.
    """
    import time
    for path in skill_files:
        subprocess.run(["open", "-a", "Claude", str(path)], check=False)
        time.sleep(delay)


def open_skill_folder(folder: Path) -> None:
    """Open a Finder window at the given folder so the user can double-click each .skill file."""
    subprocess.run(["open", str(folder)], check=False)
