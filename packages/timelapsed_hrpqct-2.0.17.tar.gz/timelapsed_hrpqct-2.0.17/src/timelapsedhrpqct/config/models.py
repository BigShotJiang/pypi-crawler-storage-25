from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(slots=True)
class ImportConfig:
    stack_depth: int = 168
    on_incomplete_stack: str = "keep_last"

    crop_to_subject_box: bool = False
    crop_threshold_bmd: float = 450.0
    crop_padding_voxels: int = 5
    crop_num_largest_components: int = 1


@dataclass(slots=True)
class DiscoveryConfig:
    """
    Controls filename-based dataset discovery.

    If `session_regex` is provided, it is used to extract subject/session/role
    from filenames. Named groups supported:
    - subject
    - session
    - role (optional)
    """
    session_regex: str | None = None
    default_site: str = "tibia"
    site_aliases: dict[str, list[str]] = field(
        default_factory=lambda: {
            "radius": ["DR", "RADIUS", "RAD"],
            "tibia": ["DT", "TIBIA", "TIB"],
            "knee": ["KN", "KNEE"],
            "radius_left": ["RL", "RADIUS_LEFT", "RADL", "LEFT_RADIUS"],
            "radius_right": ["RR", "RADIUS_RIGHT", "RADR", "RIGHT_RADIUS"],
            "tibia_left": ["TL", "TIBIA_LEFT", "TIBL", "LEFT_TIBIA"],
            "tibia_right": ["TR", "TIBIA_RIGHT", "TIBR", "RIGHT_TIBIA"],
            "knee_left": ["KL", "KNL", "KNEE_LEFT", "KNEEL", "LEFT_KNEE"],
            "knee_right": ["KR", "KNR", "KNEE_RIGHT", "KNEER", "RIGHT_KNEE"],
        }
    )
    session_aliases: dict[str, list[str]] = field(
        default_factory=lambda: {
            "T1": ["BASELINE", "BL"],
            "T2": ["FOLLOWUP", "FOLLOWUP1", "FL", "FU"],
        }
    )
    role_aliases: dict[str, list[str]] = field(
        default_factory=lambda: {
            "cort": ["CORT_MASK", "_CORT", "CORTICAL"],
            "trab": ["TRAB_MASK", "_TRAB", "TRABECULAR"],
            "full": ["FULL_MASK", "_FULL"],
            "regmask": ["REGMASK", "_REGMASK", "_REG"],
            "seg": ["_SEG", "SEG"],
        }
    )


@dataclass(slots=True)
class OuterContourConfig:
    periosteal_threshold: float = 300.0
    periosteal_kernelsize: int = 5
    periosteal_open_radius: int = 2
    morphology_downsample_factor: int = 1
    morphology_refine_edges: bool = False
    morphology_refine_band_voxels: int = 3
    gaussian_sigma: float = 1.5
    gaussian_truncate: float = 1.0
    expansion_depth: list[int] = field(default_factory=lambda: [0, 5])
    init_pad: int = 15
    fill_holes: bool = True
    use_adaptive_threshold: bool = True


@dataclass(slots=True)
class InnerContourConfig:
    site: str = "misc"
    endosteal_threshold: float = 500.0
    endosteal_kernelsize: int = 3
    morphology_downsample_factor: int = 1
    morphology_refine_edges: bool = False
    morphology_refine_band_voxels: int = 3
    gaussian_sigma: float = 1.5
    gaussian_truncate: float = 1.0
    peel: int = 3
    expansion_depth: list[int] = field(default_factory=lambda: [0, 3, 10, 3])
    trabecular_close_radius: int | None = None
    init_pad: int = 30
    use_adaptive_threshold: bool = False


@dataclass(slots=True)
class MaskSegmentationConfig:
    method: str = "adaptive"  # "adaptive" | "seg_gauss" | "laplace_hamming"
    gaussian_sigma: float = 0.8
    trab_threshold: float = 320.0
    cort_threshold: float = 450.0
    adaptive_low_threshold: float = 100.0
    adaptive_high_threshold: float = 300.0
    adaptive_block_size: int = 13
    min_size_voxels: int = 64
    keep_largest_component: bool = True
    laplace_hamming_low_pass_cutoff: float = 0.3
    laplace_hamming_high_pass_cutoff: float = 0.0
    laplace_hamming_threshold: float = 15564.0
    laplace_hamming_epsilon: float = 0.45
    laplace_hamming_amplitude: float = 1.0
    laplace_hamming_amplification: float = 1.0
    laplace_hamming_input_offset: float = 32768.0
    laplace_hamming_ipl_scale_a: float = 77.7911
    laplace_hamming_ipl_scale_b: float = -1359190.17
    laplace_hamming_ipl_float_max: float = 200000.0
    laplace_hamming_int16_max: float = 32768.0
    laplace_hamming_min_size_voxels: int = 70
    laplace_hamming_backend: str = "cpu"  # "cpu" | "auto" | "torch_mps"


@dataclass(slots=True)
class MasksConfig:
    generate: bool = True
    overwrite: bool = False
    roles: list[str] = field(default_factory=lambda: ["full", "trab", "cort"])
    generate_segmentation: bool = True
    site_defaults: dict[str, dict[str, dict[str, object]]] = field(
        default_factory=lambda: {
            "radius": {
                "inner": {
                    "endosteal_threshold": 500,
                    "endosteal_kernelsize": 3,
                    "morphology_downsample_factor": 1,
                    "morphology_refine_edges": False,
                    "morphology_refine_band_voxels": 3,
                    "gaussian_sigma": 1.5,
                    "gaussian_truncate": 1.0,
                    "peel": 3,
                    "trabecular_close_radius": 15,
                    "init_pad": 30,
                    "use_adaptive_threshold": False,
                },
                "outer": {
                    "periosteal_threshold": 300,
                    "periosteal_kernelsize": 5,
                    "periosteal_open_radius": 2,
                    "morphology_downsample_factor": 1,
                    "morphology_refine_edges": False,
                    "morphology_refine_band_voxels": 3,
                    "gaussian_sigma": 1.5,
                    "gaussian_truncate": 1.0,
                    "expansion_depth": [0, 5],
                    "init_pad": 15,
                    "fill_holes": True,
                    "use_adaptive_threshold": True,
                }
            },
            "tibia": {
                "inner": {
                    "endosteal_threshold": 500,
                    "endosteal_kernelsize": 3,
                    "morphology_downsample_factor": 1,
                    "morphology_refine_edges": False,
                    "morphology_refine_band_voxels": 3,
                    "gaussian_sigma": 1.5,
                    "gaussian_truncate": 1.0,
                    "peel": 3,
                    "trabecular_close_radius": 25,
                    "init_pad": 30,
                    "use_adaptive_threshold": False,
                },
                "outer": {
                    "periosteal_threshold": 300,
                    "periosteal_kernelsize": 5,
                    "periosteal_open_radius": 2,
                    "morphology_downsample_factor": 1,
                    "morphology_refine_edges": False,
                    "morphology_refine_band_voxels": 3,
                    "gaussian_sigma": 1.5,
                    "gaussian_truncate": 1.0,
                    "expansion_depth": [0, 5],
                    "init_pad": 15,
                    "fill_holes": True,
                    "use_adaptive_threshold": False,
                }
            },
            "knee": {
                "inner": {
                    "endosteal_threshold": 250,
                    "endosteal_kernelsize": 3,
                    "morphology_downsample_factor": 3,
                    "morphology_refine_edges": False,
                    "morphology_refine_band_voxels": 3,
                    "gaussian_sigma": 2.0,
                    "gaussian_truncate": 1.0,
                    "peel": 4,
                    "trabecular_close_radius": 36,
                    "init_pad": 30,
                    "use_adaptive_threshold": False,
                },
                "outer": {
                    "periosteal_threshold": 150,
                    "periosteal_kernelsize": 16,
                    "periosteal_open_radius": 8,
                    "morphology_downsample_factor": 3,
                    "morphology_refine_edges": False,
                    "morphology_refine_band_voxels": 3,
                    "gaussian_sigma": 1.5,
                    "gaussian_truncate": 1.0,
                    "expansion_depth": [0, 5],
                    "init_pad": 15,
                    "fill_holes": True,
                    "use_adaptive_threshold": False,
                }
            },
        }
    )

    outer: OuterContourConfig = field(default_factory=OuterContourConfig)
    inner: InnerContourConfig = field(default_factory=InnerContourConfig)
    segmentation: MaskSegmentationConfig = field(default_factory=MaskSegmentationConfig)


@dataclass(slots=True)
class TimelapsedRegistrationConfig:
    strategy: str = "sequential_to_baseline"
    reference_session: str = "baseline"
    transform_type: str = "euler"
    metric: str = "mattes"
    sampling_percentage: float = 0.001
    interpolator: str = "linear"
    optimizer: str = "adaptive_stochastic_gradient_descent"
    number_of_iterations: int = 250
    automatic_parameter_estimation: bool = True
    sp_a: float = 20.0
    maximum_step_length: float | None = None
    sigmoid_scale_factor: float = 0.1
    number_of_gradient_measurements: int = 0
    number_of_jacobian_measurements: int = 1000

    initializer: str = "geometry"
    number_of_resolutions: int = 6
    use_masks: bool = True

    debug: bool = False


@dataclass(slots=True)
class MultistackCorrectionConfig:
    enabled: bool = True
    method: str = "superstack"
    overlap_crop_buffer_voxels: int = 40

    transform_type: str = "euler"
    metric: str = "mattes"
    sampling_percentage: float = 0.005
    interpolator: str = "linear"
    optimizer: str = "adaptive_stochastic_gradient_descent"
    number_of_iterations: int = 250
    automatic_parameter_estimation: bool = True
    sp_a: float = 20.0
    maximum_step_length: float | None = None
    sigmoid_scale_factor: float = 0.1
    number_of_gradient_measurements: int = 0
    number_of_jacobian_measurements: int = 1000
    initial_translation_voxels: list[float] = field(
        default_factory=lambda: [0.0, 0.0, -20.0]
    )

    initializer: str = "identity"
    number_of_resolutions: int = 4
    use_masks: bool = True

    debug: bool = False


@dataclass(slots=True)
class TransformConfig:
    image_interpolator: str = "linear"
    mask_interpolator: str = "nearest"


@dataclass(slots=True)
class FusionConfig:
    enable_filling: bool = False


@dataclass(slots=True)
class FillingConfig:
    spatial_min_size: int = 3
    spatial_max_size: int = 23
    spatial_step: int = 5
    temporal_n_images: int = 3
    small_object_min_size_factor: int = 9
    support_closing_z: int = 11
    roi_margin_xy: int = 3
    roi_margin_z_extra: int = 2


@dataclass(slots=True)
class AnalysisValidRegionConfig:
    erosion_voxels: int = 1


@dataclass(slots=True)
class AnalysisConfig:
    space: str = "pairwise_fixed_t0"
    method: str = "grayscale_and_binary"
    compartments: list[str] = field(default_factory=lambda: ["full", "trab", "cort"])
    thresholds: list[float] = field(default_factory=lambda: [225.0])
    cluster_sizes: list[int] = field(default_factory=lambda: [12])
    pair_mode: str = "adjacent"
    use_filled_images: bool = False
    gaussian_filter: bool = True
    gaussian_sigma: float = 1.2
    full_mask_dilation_voxels: int = 2
    marrow_mask_erosion_voxels: int = 2
    valid_region: AnalysisValidRegionConfig = field(default_factory=AnalysisValidRegionConfig)


@dataclass(slots=True)
class VisualizationLabelMapConfig:
    resorption: int = 1
    demineralisation: int = 2
    quiescent: int = 2
    formation: int = 3
    mineralisation: int = 2


@dataclass(slots=True)
class VisualizationConfig:
    enabled: bool = True
    threshold: float | None = 225.0
    cluster_size: int | None = 12
    label_map: VisualizationLabelMapConfig = field(default_factory=VisualizationLabelMapConfig)


@dataclass(slots=True)
class AppConfig:
    import_: ImportConfig = field(default_factory=ImportConfig)
    discovery: DiscoveryConfig = field(default_factory=DiscoveryConfig)
    masks: MasksConfig = field(default_factory=MasksConfig)
    timelapsed_registration: TimelapsedRegistrationConfig = field(
        default_factory=TimelapsedRegistrationConfig
    )
    multistack_correction: MultistackCorrectionConfig = field(
        default_factory=MultistackCorrectionConfig
    )
    transform: TransformConfig = field(default_factory=TransformConfig)
    fusion: FusionConfig = field(default_factory=FusionConfig)
    filling: FillingConfig = field(default_factory=FillingConfig)
    analysis: AnalysisConfig = field(default_factory=AnalysisConfig)
    visualization: VisualizationConfig = field(default_factory=VisualizationConfig)
