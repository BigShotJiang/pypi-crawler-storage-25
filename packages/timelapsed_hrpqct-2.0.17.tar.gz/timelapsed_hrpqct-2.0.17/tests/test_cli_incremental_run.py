from __future__ import annotations

import argparse
import json
from pathlib import Path
from types import SimpleNamespace

import pytest

from timelapsedhrpqct.cli import (
    DEFAULT_CONFIG_PATH,
    _build_parser,
    _cmd_undo_restructure,
    _cmd_run,
    _filling_enabled,
    _needs_analysis,
    _needs_apply_transforms,
    _needs_filling,
    _needs_timelapse_registration,
    _sessions_needing_import,
)
from timelapsedhrpqct.dataset.artifacts import (
    FilledSessionRecord,
    FusedSessionRecord,
    ImportedStackRecord,
    group_fused_sessions_by_subject_site,
    group_imported_stacks_by_subject_site_and_stack,
    upsert_filled_session_record,
    upsert_fused_session_record,
    upsert_imported_stack_records,
)
from timelapsedhrpqct.dataset.derivative_paths import (
    analysis_metadata_path,
    filled_full_mask_path,
    filled_image_path,
    filladded_mask_path,
    final_transform_path,
    timelapse_baseline_transform_path,
)
from timelapsedhrpqct.dataset.models import RawSession, StackSliceRange


def _touch(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("", encoding="utf-8")


def test_parser_uses_repo_default_config_for_commands() -> None:
    parser = _build_parser()

    import_args = parser.parse_args(["import", "/tmp/raw"])
    run_args = parser.parse_args(["run", "/tmp/raw"])

    assert import_args.config == DEFAULT_CONFIG_PATH
    assert run_args.config == DEFAULT_CONFIG_PATH
    assert import_args.copy_raw_inputs is False
    assert run_args.copy_raw_inputs is False
    assert import_args.restructure_raw is False
    assert run_args.restructure_raw is False
    assert import_args.force_header_discovery is False
    assert run_args.force_header_discovery is False


def test_parser_accepts_copy_raw_inputs_for_import_and_run() -> None:
    parser = _build_parser()

    import_args = parser.parse_args(["import", "/tmp/raw", "--copy-raw-inputs"])
    run_args = parser.parse_args(["run", "/tmp/raw", "--copy-raw-inputs"])

    assert import_args.copy_raw_inputs is True
    assert run_args.copy_raw_inputs is True


def test_parser_accepts_restructure_raw_for_import_and_run() -> None:
    parser = _build_parser()

    import_args = parser.parse_args(["import", "/tmp/raw", "--restructure-raw"])
    run_args = parser.parse_args(["run", "/tmp/raw", "--restructure-raw"])

    assert import_args.restructure_raw is True
    assert run_args.restructure_raw is True


def test_parser_accepts_force_header_discovery_for_import_and_run() -> None:
    parser = _build_parser()

    import_args = parser.parse_args(["import", "/tmp/raw", "--force-header-discovery"])
    run_args = parser.parse_args(["run", "/tmp/raw", "--force-header-discovery"])

    assert import_args.force_header_discovery is True
    assert run_args.force_header_discovery is True


def test_parser_accepts_undo_restructure_command() -> None:
    parser = _build_parser()
    args = parser.parse_args(["undo-restructure", "/tmp/dataset", "--dry-run"])
    assert args.command == "undo-restructure"
    assert args.dataset_root == Path("/tmp/dataset")
    assert args.dry_run is True


def test_parser_accepts_subject_and_site_filters_for_analyse() -> None:
    parser = _build_parser()
    args = parser.parse_args(["analyse", "/tmp/dataset", "--subject", "001", "--site", "tibia"])
    assert args.command == "analyse"
    assert args.subject == "001"
    assert args.site == "tibia"


def test_parser_accepts_scanco_transform_commands() -> None:
    parser = _build_parser()

    import_args = parser.parse_args(["import-transforms", "/tmp/raw", "/tmp/dataset"])
    export_args = parser.parse_args(
        [
            "export-transform-dat",
            "/tmp/dataset/in.tfm",
            "/tmp/dataset/out.DAT",
        ]
    )
    aim_args = parser.parse_args(
        [
            "export-aim",
            "/tmp/dataset/in.nii.gz",
            "/tmp/dataset/out.AIM",
            "--metadata-json",
            "/tmp/dataset/in.json",
            "--mask",
            "--log",
            "converted",
        ]
    )

    assert import_args.command == "import-transforms"
    assert import_args.input_root == Path("/tmp/raw")
    assert import_args.dataset_root == Path("/tmp/dataset")
    assert export_args.command == "export-transform-dat"
    assert export_args.transform_path == Path("/tmp/dataset/in.tfm")
    assert export_args.output_path == Path("/tmp/dataset/out.DAT")
    assert aim_args.command == "export-aim"
    assert aim_args.image_path == Path("/tmp/dataset/in.nii.gz")
    assert aim_args.output_path == Path("/tmp/dataset/out.AIM")
    assert aim_args.metadata_json == Path("/tmp/dataset/in.json")
    assert aim_args.mask is True
    assert aim_args.log == "converted"


def test_parser_accepts_professional_cli_commands() -> None:
    parser = _build_parser()

    doctor_args = parser.parse_args(["doctor", "--profile", "low-memory"])
    inspect_args = parser.parse_args(["inspect", "/tmp/dataset"])
    list_args = parser.parse_args(["config", "list"])
    show_args = parser.parse_args(["config", "show", "multistack"])
    benchmark_args = parser.parse_args(["analyse", "/tmp/dataset", "--benchmark"])
    write_args = parser.parse_args(
        ["config", "write", "--profile", "standard", "--output", "/tmp/config.yml"]
    )
    explain_args = parser.parse_args(
        ["config", "explain", "--profile", "standard", "--config", "/tmp/user.yml"]
    )

    assert doctor_args.command == "doctor"
    assert doctor_args.profile == "low-memory"
    assert inspect_args.command == "inspect"
    assert inspect_args.dataset_root == Path("/tmp/dataset")
    assert list_args.command == "config"
    assert list_args.config_command == "list"
    assert show_args.profile == "multistack"
    assert benchmark_args.benchmark is True
    assert write_args.output == Path("/tmp/config.yml")
    assert explain_args.config == Path("/tmp/user.yml")


def test_sessions_needing_import_skips_already_imported_complete_sessions(tmp_path: Path, monkeypatch) -> None:
    dataset_root = tmp_path / "dataset"
    raw_sessions = [
        RawSession("001", "C1", Path("/tmp/C1.AIM")),
        RawSession("001", "C2", Path("/tmp/C2.AIM")),
    ]

    monkeypatch.setattr(
        "timelapsedhrpqct.cli._expected_stack_count_for_session",
        lambda session, config: 2,
    )

    upsert_imported_stack_records(
        dataset_root,
        [
            ImportedStackRecord("001", "C1", 1, Path("/tmp/a.mha"), {}, None, None, StackSliceRange(1, 0, 10)),
            ImportedStackRecord("001", "C1", 2, Path("/tmp/b.mha"), {}, None, None, StackSliceRange(2, 10, 20)),
            ImportedStackRecord("001", "C2", 1, Path("/tmp/c.mha"), {}, None, None, StackSliceRange(1, 0, 10)),
        ],
    )

    needed = _sessions_needing_import(
        sessions=raw_sessions,
        dataset_root=dataset_root,
        config=SimpleNamespace(import_=SimpleNamespace()),
    )

    assert [s.session_id for s in needed] == ["C2"]


def test_sessions_needing_import_is_site_aware(tmp_path: Path, monkeypatch) -> None:
    dataset_root = tmp_path / "dataset"
    raw_sessions = [
        RawSession("001", "C1", Path("/tmp/DT_C1.AIM"), site="tibia"),
        RawSession("001", "C1", Path("/tmp/DR_C1.AIM"), site="radius"),
    ]

    monkeypatch.setattr(
        "timelapsedhrpqct.cli._expected_stack_count_for_session",
        lambda session, config: 1,
    )

    upsert_imported_stack_records(
        dataset_root,
        [
            ImportedStackRecord(
                "001",
                "C1",
                1,
                Path("/tmp/tibia_stack.mha"),
                {},
                None,
                None,
                StackSliceRange(1, 0, 10),
                site="tibia",
            ),
        ],
    )

    needed = _sessions_needing_import(
        sessions=raw_sessions,
        dataset_root=dataset_root,
        config=SimpleNamespace(import_=SimpleNamespace()),
    )

    assert [(s.session_id, s.site) for s in needed] == [("C1", "radius")]


def test_group_helpers_use_natural_session_order() -> None:
    imported = [
        ImportedStackRecord("001", "T10", 1, Path("/tmp/a.mha"), {}, None, None, site="radius"),
        ImportedStackRecord("001", "T2", 1, Path("/tmp/b.mha"), {}, None, None, site="radius"),
        ImportedStackRecord("001", "T1", 1, Path("/tmp/c.mha"), {}, None, None, site="radius"),
    ]
    grouped_imported = group_imported_stacks_by_subject_site_and_stack(imported)
    assert [r.session_id for r in grouped_imported[("001", "radius")][1]] == ["T1", "T2", "T10"]

    fused = [
        FusedSessionRecord("001", "T10", Path("/tmp/a.mha"), {}, None, None, site="radius"),
        FusedSessionRecord("001", "T2", Path("/tmp/b.mha"), {}, None, None, site="radius"),
        FusedSessionRecord("001", "T1", Path("/tmp/c.mha"), {}, None, None, site="radius"),
    ]
    grouped_fused = group_fused_sessions_by_subject_site(fused)
    assert [r.session_id for r in grouped_fused[("001", "radius")]] == ["T1", "T2", "T10"]


def test_needs_timelapse_registration_false_when_all_baselines_exist(tmp_path: Path) -> None:
    dataset_root = tmp_path / "dataset"
    records = [
        ImportedStackRecord("001", "C1", 1, Path("/tmp/a.mha"), {}, None, None),
        ImportedStackRecord("001", "C2", 1, Path("/tmp/b.mha"), {}, None, None),
    ]
    upsert_imported_stack_records(dataset_root, records)

    _touch(timelapse_baseline_transform_path(dataset_root, "001", 1, "C1", "C1"))
    _touch(timelapse_baseline_transform_path(dataset_root, "001", 1, "C2", "C1"))

    assert _needs_timelapse_registration(dataset_root) is False


def test_needs_apply_transforms_and_filling_reflect_artifact_presence(tmp_path: Path) -> None:
    dataset_root = tmp_path / "dataset"

    fused_image = tmp_path / "fused_image.mha"
    fused_full = tmp_path / "fused_full.mha"
    fused_meta = tmp_path / "fused.json"
    for path in (fused_image, fused_full, fused_meta):
        _touch(path)

    upsert_fused_session_record(
        dataset_root,
        FusedSessionRecord(
            "001",
            "C1",
            fused_image,
            {"full": fused_full},
            None,
            fused_meta,
        ),
    )

    assert _needs_apply_transforms(dataset_root) is False
    assert _needs_filling(dataset_root) is True

    _touch(filled_image_path(dataset_root, "001", "C1"))
    _touch(filled_full_mask_path(dataset_root, "001", "C1"))
    _touch(filladded_mask_path(dataset_root, "001", "C1"))
    meta_path = dataset_root / "derivatives" / "TimelapsedHRpQCT" / "sub-001" / "filled" / "ses-C1" / "sub-001_ses-C1_filling.json"
    _touch(meta_path)

    upsert_filled_session_record(
        dataset_root,
        FilledSessionRecord(
            "001",
            "C1",
            filled_image_path(dataset_root, "001", "C1"),
            filled_full_mask_path(dataset_root, "001", "C1"),
            filladded_mask_path(dataset_root, "001", "C1"),
            None,
            None,
            meta_path,
        ),
    )

    assert _needs_filling(dataset_root) is False


def test_needs_apply_transforms_detects_missing_imported_session_fusion(tmp_path: Path) -> None:
    dataset_root = tmp_path / "dataset"
    imported_image = tmp_path / "imported_image.mha"
    _touch(imported_image)

    upsert_imported_stack_records(
        dataset_root,
        [
            ImportedStackRecord(
                "001",
                "C1",
                1,
                imported_image,
                {},
                None,
                None,
                site="radius",
            ),
            ImportedStackRecord(
                "001",
                "C2",
                1,
                imported_image,
                {},
                None,
                None,
                site="radius",
            ),
            ImportedStackRecord(
                "002",
                "C1",
                1,
                imported_image,
                {},
                None,
                None,
                site="tibia",
            ),
        ],
    )

    fused_image = tmp_path / "fused_image.mha"
    fused_full = tmp_path / "fused_full.mha"
    fused_meta = tmp_path / "fused.json"
    for path in (fused_image, fused_full, fused_meta):
        _touch(path)

    upsert_fused_session_record(
        dataset_root,
        FusedSessionRecord(
            "001",
            "C1",
            fused_image,
            {"full": fused_full},
            None,
            fused_meta,
            site="radius",
        ),
    )

    assert _needs_apply_transforms(dataset_root) is True

    upsert_fused_session_record(
        dataset_root,
        FusedSessionRecord(
            "001",
            "C2",
            fused_image,
            {"full": fused_full},
            None,
            fused_meta,
            site="radius",
        ),
    )
    upsert_fused_session_record(
        dataset_root,
        FusedSessionRecord(
            "002",
            "C1",
            fused_image,
            {"full": fused_full},
            None,
            fused_meta,
            site="tibia",
        ),
    )

    assert _needs_apply_transforms(dataset_root) is False


def test_needs_analysis_uses_existing_summary_when_no_overrides(tmp_path: Path) -> None:
    dataset_root = tmp_path / "dataset"
    fused_image = tmp_path / "fused_image.mha"
    fused_full = tmp_path / "fused_full.mha"
    fused_meta = tmp_path / "fused.json"
    for path in (fused_image, fused_full, fused_meta):
        _touch(path)

    upsert_fused_session_record(dataset_root, FusedSessionRecord("001", "C1", fused_image, {"full": fused_full}, None, fused_meta))
    upsert_fused_session_record(dataset_root, FusedSessionRecord("001", "C2", fused_image, {"full": fused_full}, None, fused_meta))

    pairwise = tmp_path / "pairwise.csv"
    trajectory = tmp_path / "trajectory.csv"
    _touch(pairwise)
    _touch(trajectory)
    meta_path = analysis_metadata_path(dataset_root, "001")
    meta_path.parent.mkdir(parents=True, exist_ok=True)
    meta_path.write_text(
        json.dumps({"pairwise_csv": str(pairwise), "trajectory_csv": str(trajectory)}),
        encoding="utf-8",
    )

    config = SimpleNamespace(
        analysis=SimpleNamespace(
            use_filled_images=False,
            compartments=["trab", "cort", "full"],
            thresholds=[225.0],
            cluster_sizes=[12],
            pair_mode="adjacent",
            valid_region=SimpleNamespace(erosion_voxels=1),
        ),
        visualization=SimpleNamespace(enabled=False, threshold=None, cluster_size=None),
    )

    meta_path.write_text(
        json.dumps(
            {
                "pairwise_csv": str(pairwise),
                "trajectory_csv": str(trajectory),
                "use_filled_images": False,
                "compartments": ["trab", "cort", "full"],
                "thresholds": [225.0],
                "cluster_sizes": [12],
                "pair_mode": "adjacent",
                "erosion_voxels": 1,
                "visualization_enabled": False,
                "visualization_threshold": None,
                "visualization_cluster_size": None,
            }
        ),
        encoding="utf-8",
    )

    args = SimpleNamespace(thr=None, clusters=None, visualize=None)
    assert _needs_analysis(dataset_root, config, args) is False

    args_with_override = SimpleNamespace(thr=[225.0], clusters=None, visualize=None)
    assert _needs_analysis(dataset_root, config, args_with_override) is True


def test_needs_analysis_reruns_when_visualization_enabled_in_config_but_outputs_missing(
    tmp_path: Path,
) -> None:
    dataset_root = tmp_path / "dataset"
    fused_image = tmp_path / "fused_image.mha"
    fused_full = tmp_path / "fused_full.mha"
    fused_meta = tmp_path / "fused.json"
    for path in (fused_image, fused_full, fused_meta):
        _touch(path)

    upsert_fused_session_record(dataset_root, FusedSessionRecord("001", "C1", fused_image, {"full": fused_full}, None, fused_meta))
    upsert_fused_session_record(dataset_root, FusedSessionRecord("001", "C2", fused_image, {"full": fused_full}, None, fused_meta))

    pairwise = tmp_path / "pairwise.csv"
    trajectory = tmp_path / "trajectory.csv"
    _touch(pairwise)
    _touch(trajectory)
    meta_path = analysis_metadata_path(dataset_root, "001")
    meta_path.parent.mkdir(parents=True, exist_ok=True)
    meta_path.write_text(
        json.dumps(
            {
                "pairwise_csv": str(pairwise),
                "trajectory_csv": str(trajectory),
                "use_filled_images": False,
                "compartments": ["trab", "cort", "full"],
                "thresholds": [225.0],
                "cluster_sizes": [12],
                "pair_mode": "adjacent",
                "erosion_voxels": 1,
                "visualization_enabled": True,
                "visualization_threshold": 225.0,
                "visualization_cluster_size": 12,
            }
        ),
        encoding="utf-8",
    )

    config = SimpleNamespace(
        analysis=SimpleNamespace(
            use_filled_images=False,
            compartments=["trab", "cort", "full"],
            thresholds=[225.0],
            cluster_sizes=[12],
            pair_mode="adjacent",
            valid_region=SimpleNamespace(erosion_voxels=1),
        ),
        visualization=SimpleNamespace(enabled=True, threshold=225.0, cluster_size=12),
    )

    args = SimpleNamespace(thr=None, clusters=None, visualize=None)
    assert _needs_analysis(dataset_root, config, args) is True


def test_filling_enabled_reads_config_flag() -> None:
    assert _filling_enabled(SimpleNamespace(fusion=SimpleNamespace(enable_filling=True))) is True
    assert _filling_enabled(SimpleNamespace(fusion=SimpleNamespace(enable_filling=False))) is False


def test_cmd_run_skips_fill_when_disabled_and_analysis_does_not_require_filled(monkeypatch, tmp_path: Path) -> None:
    dataset_root = tmp_path / "imported_dataset"
    input_root = tmp_path / "raw"
    input_root.mkdir()
    dataset_root.mkdir()

    config = SimpleNamespace(
        discovery=SimpleNamespace(),
        fusion=SimpleNamespace(enable_filling=False),
        analysis=SimpleNamespace(use_filled_images=False),
    )

    monkeypatch.setattr("timelapsedhrpqct.cli._load_config_or_die", lambda path: config)
    monkeypatch.setattr(
        "timelapsedhrpqct.cli.discover_raw_sessions",
        lambda root, discovery_config, force_header_discovery=False, canonicalize_sessions=False: [
            RawSession("001", "C1", Path("/tmp/C1.AIM"))
        ],
    )
    monkeypatch.setattr("timelapsedhrpqct.cli._cmd_import", lambda args: 0)
    monkeypatch.setattr("timelapsedhrpqct.cli._needs_mask_generation", lambda dataset_root: False)
    monkeypatch.setattr("timelapsedhrpqct.cli._needs_timelapse_registration", lambda dataset_root: False)
    monkeypatch.setattr("timelapsedhrpqct.cli._needs_stack_correction", lambda dataset_root: False)
    monkeypatch.setattr("timelapsedhrpqct.cli._needs_apply_transforms", lambda dataset_root: False)
    monkeypatch.setattr(
        "timelapsedhrpqct.cli._needs_analysis",
        lambda dataset_root, config, args: False,
    )

    fill_calls: list[object] = []
    monkeypatch.setattr("timelapsedhrpqct.cli._cmd_fill", lambda args: fill_calls.append(args) or 0)

    rc = _cmd_run(
        argparse.Namespace(
            input_root=input_root,
            output_root=dataset_root,
            config=tmp_path / "config.yml",
            mode="multistack",
            dry_run=False,
            skip_mask_generation=False,
            thr=None,
            clusters=None,
            visualize=None,
            force_header_discovery=False,
        )
    )

    assert rc == 0
    assert fill_calls == []


def test_cmd_run_errors_if_fill_disabled_but_analysis_uses_filled(monkeypatch, tmp_path: Path) -> None:
    dataset_root = tmp_path / "imported_dataset"
    input_root = tmp_path / "raw"
    input_root.mkdir()
    dataset_root.mkdir()

    config = SimpleNamespace(
        discovery=SimpleNamespace(),
        fusion=SimpleNamespace(enable_filling=False),
        analysis=SimpleNamespace(use_filled_images=True),
    )

    monkeypatch.setattr("timelapsedhrpqct.cli._load_config_or_die", lambda path: config)
    monkeypatch.setattr(
        "timelapsedhrpqct.cli.discover_raw_sessions",
        lambda root, discovery_config, force_header_discovery=False, canonicalize_sessions=False: [
            RawSession("001", "C1", Path("/tmp/C1.AIM"))
        ],
    )
    monkeypatch.setattr("timelapsedhrpqct.cli._cmd_import", lambda args: 0)
    monkeypatch.setattr("timelapsedhrpqct.cli._needs_mask_generation", lambda dataset_root: False)
    monkeypatch.setattr("timelapsedhrpqct.cli._needs_timelapse_registration", lambda dataset_root: False)
    monkeypatch.setattr("timelapsedhrpqct.cli._needs_stack_correction", lambda dataset_root: False)
    monkeypatch.setattr("timelapsedhrpqct.cli._needs_apply_transforms", lambda dataset_root: False)

    with pytest.raises(ValueError, match="analysis.use_filled_images=true requires fusion.enable_filling=true"):
        _cmd_run(
            argparse.Namespace(
                input_root=input_root,
                output_root=dataset_root,
                config=tmp_path / "config.yml",
                mode="multistack",
                dry_run=False,
                skip_mask_generation=False,
                thr=None,
                clusters=None,
                visualize=None,
                force_header_discovery=False,
            )
        )


def test_cmd_undo_restructure_moves_files_back_to_original_source(tmp_path: Path) -> None:
    dataset_root = tmp_path / "dataset"
    moved_path = dataset_root / "sub-001" / "site-tibia" / "ses-T1" / "SUBJECT_001_DT_T1.AIM"
    moved_path.parent.mkdir(parents=True, exist_ok=True)
    moved_path.write_text("raw", encoding="utf-8")

    source_path = tmp_path / "raw_input" / "SUBJECT_001_DT_T1.AIM"
    metadata_path = dataset_root / "derivatives" / "TimelapsedHRpQCT" / "sub-001" / "site-tibia" / "ses-T1" / "stacks" / "meta.json"
    metadata_path.parent.mkdir(parents=True, exist_ok=True)
    metadata_path.write_text(
        json.dumps(
            {
                "source_image": str(source_path),
                "source_masks": {},
                "source_seg": None,
                "copied_raw_paths": {"image": str(moved_path)},
            }
        ),
        encoding="utf-8",
    )

    upsert_imported_stack_records(
        dataset_root,
        [
            ImportedStackRecord(
                "001",
                "T1",
                1,
                image_path=metadata_path,
                mask_paths={},
                seg_path=None,
                metadata_path=metadata_path,
                slice_range=StackSliceRange(1, 0, 10),
                site="tibia",
            )
        ],
    )

    rc = _cmd_undo_restructure(argparse.Namespace(dataset_root=dataset_root, dry_run=True))
    assert rc == 0
    assert moved_path.exists()
    assert not source_path.exists()

    rc = _cmd_undo_restructure(argparse.Namespace(dataset_root=dataset_root, dry_run=False))
    assert rc == 0
    assert not moved_path.exists()
    assert source_path.exists()
