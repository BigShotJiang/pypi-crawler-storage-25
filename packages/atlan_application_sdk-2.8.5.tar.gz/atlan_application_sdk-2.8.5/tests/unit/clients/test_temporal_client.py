import tempfile
from typing import Any, Dict, Generator
from unittest.mock import ANY, AsyncMock, MagicMock, Mock, patch

import pytest
import trustme
from temporalio.runtime import Runtime
from temporalio.service import TLSConfig

from application_sdk.clients.temporal import TemporalWorkflowClient
from application_sdk.interceptors.cleanup import cleanup
from application_sdk.interceptors.events import publish_event
from application_sdk.workflows import WorkflowInterface


@pytest.fixture(autouse=True)
def mock_runtime():
    """Mock Runtime and reset the class-level singleton for each test.

    Patches the Runtime class to avoid real port binding, and resets
    TemporalWorkflowClient._prometheus_runtime so each test starts with
    a fresh singleton state, preventing cross-test interference.
    """
    TemporalWorkflowClient._prometheus_runtime = None
    with patch("application_sdk.clients.temporal.Runtime") as mock_cls:
        mock_cls.return_value = MagicMock(spec=Runtime)
        yield mock_cls
    TemporalWorkflowClient._prometheus_runtime = None


# Mock workflow class for testing
class MockWorkflow(WorkflowInterface):
    pass


@pytest.fixture
def temporal_client() -> TemporalWorkflowClient:
    """Create a TemporalWorkflowClient instance for testing."""

    def mock_get_deployment_secret(key: str):
        # Return None for all keys by default (tests can override if needed)
        return None

    with patch(
        "application_sdk.clients.temporal.SecretStore.get_deployment_secret",
        side_effect=mock_get_deployment_secret,
    ):
        return TemporalWorkflowClient(
            host="localhost",
            port="7233",
            application_name="test_app",
            namespace="default",
        )


@pytest.fixture
def mock_dapr_output_client() -> Generator[Mock, None, None]:
    """Mock Dapr output clients."""
    with patch(
        "application_sdk.clients.temporal.StateStore"
    ) as mock_state_output, patch(
        "application_sdk.services.statestore.StateStore.get_state"
    ) as mock_get_state, patch(
        "application_sdk.services.objectstore.ObjectStore.upload_file"
    ) as mock_push_file:
        mock_state_output.save_state = AsyncMock()
        mock_state_output.save_state_object = AsyncMock()
        mock_get_state.return_value = {}  # Return empty state
        mock_push_file.return_value = None  # Mock the push file operation
        yield mock_state_output


@patch(
    "application_sdk.clients.temporal.Client.connect",
    new_callable=AsyncMock,
)
@patch("application_sdk.clients.temporal.SecretStore.get_deployment_secret")
async def test_load(
    mock_get_config: AsyncMock,
    mock_connect: AsyncMock,
    temporal_client: TemporalWorkflowClient,
):
    """Test loading the temporal client."""
    # Mock the deployment config to return None for all keys (auth disabled)
    mock_get_config.return_value = None

    # Mock the client connection
    mock_client = AsyncMock()
    mock_connect.return_value = mock_client

    # Run load to connect the client
    await temporal_client.load()

    # Verify that Client.connect was called with the correct parameters
    mock_connect.assert_called_once()
    call_kwargs = mock_connect.call_args[1]
    assert call_kwargs["target_host"] == temporal_client.get_connection_string()
    assert call_kwargs["namespace"] == temporal_client.get_namespace()
    assert call_kwargs["tls"] is False
    assert isinstance(call_kwargs["runtime"], Runtime)

    # Check that client is set
    assert temporal_client.client == mock_client


@patch("application_sdk.services.secretstore.SecretStore")
@patch(
    "application_sdk.clients.temporal.Client.connect",
    new_callable=AsyncMock,
)
async def test_start_workflow(
    mock_connect: AsyncMock,
    mock_secret_store: MagicMock,
    temporal_client: TemporalWorkflowClient,
    mock_dapr_output_client: Mock,
):
    """Test starting a workflow."""
    # Mock the client connection
    mock_client = AsyncMock()
    mock_connect.return_value = mock_client

    mock_handle = MagicMock()
    mock_handle.id = "test_workflow_id"
    mock_handle.result_run_id = "test_run_id"

    # Run load to connect the client
    await temporal_client.load()
    mock_client.start_workflow.return_value = mock_handle

    # Mock the state store
    mock_secret_store.store_credentials.return_value = "test_credentials"

    # Sample workflow arguments
    credentials = {"username": "test_username", "password": "test_password"}
    workflow_args = {"param1": "value1", "credentials": credentials}

    workflow_class = MockWorkflow

    # Run start_workflow and capture the result
    result = await temporal_client.start_workflow(workflow_args, workflow_class)

    # Assertions
    mock_client.start_workflow.assert_called_once()
    assert (
        mock_dapr_output_client.save_state_object.call_count == 1
    )  # Expect one call when workflow_id not provided
    assert result["workflow_id"] == "test_workflow_id"
    assert result["run_id"] == "test_run_id"


@patch("application_sdk.services.secretstore.SecretStore")
@patch(
    "application_sdk.clients.temporal.Client.connect",
    new_callable=AsyncMock,
)
async def test_start_workflow_with_workflow_id(
    mock_connect: AsyncMock,
    mock_secret_store: MagicMock,
    temporal_client: TemporalWorkflowClient,
    mock_dapr_output_client: Mock,
):
    """Test starting a workflow with a provided workflow ID."""
    # Mock the client connection
    mock_client = AsyncMock()
    mock_connect.return_value = mock_client

    def start_workflow_side_effect(
        workflow_class: type[WorkflowInterface],
        args: Dict[str, Any],
        id: str,
        *_args: Any,
        **_kwargs: Any,
    ) -> Mock:
        mock_handle = MagicMock()
        mock_handle.id = id
        mock_handle.result_run_id = "test_run_id"
        return mock_handle

    # Run load to connect the client
    await temporal_client.load()
    mock_client.start_workflow.side_effect = start_workflow_side_effect

    # Mock the state store
    mock_secret_store.store_credentials.return_value = "test_credentials"

    # Sample workflow arguments
    credentials = {"username": "test_username", "password": "test_password"}
    workflow_args = {
        "param1": "value1",
        "credentials": credentials,
        "workflow_id": "test_workflow_id",
    }

    workflow_class = MockWorkflow

    # Run start_workflow and capture the result
    result = await temporal_client.start_workflow(
        workflow_args,
        workflow_class,
    )

    # Assertions
    mock_client.start_workflow.assert_called_once()
    mock_dapr_output_client.save_state_object.assert_not_called()  # Should not be called when workflow_id is provided
    assert result["workflow_id"] == "test_workflow_id"
    assert result["run_id"] == "test_run_id"


@patch("application_sdk.services.secretstore.SecretStore")
@patch(
    "application_sdk.clients.temporal.Client.connect",
    new_callable=AsyncMock,
)
async def test_start_workflow_failure(
    mock_connect: AsyncMock,
    mock_secret_store: MagicMock,
    temporal_client: TemporalWorkflowClient,
    mock_dapr_output_client: Mock,
):
    """Test workflow start failure handling."""
    # Mock the client connection
    mock_client = AsyncMock()
    mock_connect.return_value = mock_client

    # Run load to connect the client
    await temporal_client.load()
    mock_client.start_workflow.side_effect = Exception("Simulated failure")

    # Mock the state store
    mock_secret_store.store_credentials.return_value = "test_credentials"

    # Sample workflow arguments
    credentials = {"username": "test_username", "password": "test_password"}
    workflow_args = {"param1": "value1", "credentials": credentials}

    workflow_class = MockWorkflow

    # Assertions
    with pytest.raises(Exception, match="Simulated failure"):
        await temporal_client.start_workflow(workflow_args, workflow_class)
    mock_client.start_workflow.assert_called_once()
    mock_dapr_output_client.save_state_object.assert_called()


@patch("application_sdk.clients.temporal.Worker")
@patch(
    "application_sdk.clients.temporal.Client.connect",
    new_callable=AsyncMock,
)
async def test_create_worker_without_client(
    mock_connect: AsyncMock,
    mock_worker_class: MagicMock,
    temporal_client: TemporalWorkflowClient,
):
    """Test creating a worker without a loaded client."""
    # Mock the client connection
    mock_client = AsyncMock()
    mock_connect.return_value = mock_client

    # Mock workflow class and activities
    workflow_classes = [MagicMock(), MagicMock()]
    activities = [MagicMock(), MagicMock()]
    passthrough_modules = ["application_sdk", "os"]

    # Run create_worker
    with pytest.raises(ValueError, match="Client is not loaded"):
        temporal_client.create_worker(activities, workflow_classes, passthrough_modules)


@patch("application_sdk.clients.temporal.TEMPORAL_DEPLOYMENT_NAME", "")
@patch("application_sdk.clients.temporal.TEMPORAL_BUILD_ID", "")
@patch("application_sdk.clients.temporal.Worker")
@patch(
    "application_sdk.clients.temporal.Client.connect",
    new_callable=AsyncMock,
)
async def test_create_worker(
    mock_connect: AsyncMock,
    mock_worker_class: MagicMock,
    temporal_client: TemporalWorkflowClient,
):
    """Test creating a worker with a loaded client."""
    # Mock the client connection
    mock_client = AsyncMock()
    mock_connect.return_value = mock_client

    # Run load to connect the client
    await temporal_client.load()

    # Mock workflow class and activities
    workflow_classes = [MagicMock(), MagicMock()]
    activities = [MagicMock(), MagicMock()]
    passthrough_modules = ["application_sdk", "os"]

    # Run create_worker
    worker = temporal_client.create_worker(
        activities, workflow_classes, passthrough_modules
    )

    expected_activities = list(activities) + [publish_event, cleanup]
    mock_worker_class.assert_called_once_with(
        temporal_client.client,
        task_queue=temporal_client.worker_task_queue,
        workflows=workflow_classes,
        activities=expected_activities,
        workflow_runner=ANY,
        interceptors=ANY,
        activity_executor=ANY,
        max_concurrent_activities=ANY,
        graceful_shutdown_timeout=ANY,
        deployment_config=None,
    )

    assert worker == mock_worker_class.return_value


@patch("application_sdk.clients.temporal.TEMPORAL_DEPLOYMENT_NAME", "test-ns/test-twd")
@patch("application_sdk.clients.temporal.TEMPORAL_BUILD_ID", "v1.2.3-abc123")
@patch("application_sdk.clients.temporal.Worker")
@patch(
    "application_sdk.clients.temporal.Client.connect",
    new_callable=AsyncMock,
)
async def test_create_worker_with_deployment_config(
    mock_connect: AsyncMock,
    mock_worker_class: MagicMock,
    temporal_client: TemporalWorkflowClient,
):
    """Test creating a versioned worker with Worker Deployment config."""
    mock_client = AsyncMock()
    mock_connect.return_value = mock_client
    await temporal_client.load()

    workflow_classes = [MagicMock()]
    activities = [MagicMock()]
    passthrough_modules = ["application_sdk"]

    temporal_client.create_worker(activities, workflow_classes, passthrough_modules)

    expected_activities = list(activities) + [publish_event, cleanup]
    mock_worker_class.assert_called_once_with(
        temporal_client.client,
        task_queue=temporal_client.worker_task_queue,
        workflows=workflow_classes,
        activities=expected_activities,
        workflow_runner=ANY,
        interceptors=ANY,
        activity_executor=ANY,
        max_concurrent_activities=ANY,
        graceful_shutdown_timeout=ANY,
        deployment_config=ANY,
    )
    # Verify the deployment_config has the right values
    call_kwargs = mock_worker_class.call_args[1]
    dc = call_kwargs["deployment_config"]
    assert dc.version.deployment_name == "test-ns/test-twd"
    assert dc.version.build_id == "v1.2.3-abc123"


@patch("application_sdk.clients.temporal.TEMPORAL_DEPLOYMENT_NAME", "")
@patch("application_sdk.clients.temporal.TEMPORAL_BUILD_ID", "v1.2.3-abc123")
@patch("application_sdk.clients.temporal.Worker")
@patch(
    "application_sdk.clients.temporal.Client.connect",
    new_callable=AsyncMock,
)
async def test_create_worker_with_build_id_only(
    mock_connect: AsyncMock,
    mock_worker_class: MagicMock,
    temporal_client: TemporalWorkflowClient,
):
    """Test creating a versioned worker with only build_id (no deployment name)."""
    mock_client = AsyncMock()
    mock_connect.return_value = mock_client
    await temporal_client.load()

    workflow_classes = [MagicMock()]
    activities = [MagicMock()]
    passthrough_modules = ["application_sdk"]

    temporal_client.create_worker(activities, workflow_classes, passthrough_modules)

    call_kwargs = mock_worker_class.call_args[1]
    dc = call_kwargs["deployment_config"]
    assert dc.version.deployment_name == "v1.2.3-abc123"
    assert dc.version.build_id == "v1.2.3-abc123"


def test_get_worker_task_queue(temporal_client: TemporalWorkflowClient):
    """Test get_worker_task_queue returns the application name with deployment name."""
    assert temporal_client.get_worker_task_queue() == "atlan-test_app-local"


def test_get_connection_string(temporal_client: TemporalWorkflowClient):
    """Test get_connection_string returns properly formatted connection string."""
    assert temporal_client.get_connection_string() == "localhost:7233"


def test_get_namespace(temporal_client: TemporalWorkflowClient):
    """Test get_namespace returns the correct namespace."""
    assert temporal_client.get_namespace() == "default"


@patch(
    "application_sdk.clients.temporal.Client.connect",
    new_callable=AsyncMock,
)
async def test_get_workflow_run_status_error(
    mock_connect: AsyncMock, temporal_client: TemporalWorkflowClient
):
    """Test get_workflow_run_status error handling."""
    # Mock the client connection
    mock_client = AsyncMock()
    mock_connect.return_value = mock_client

    # Mock workflow handle with unexpected error
    mock_handle = AsyncMock()
    mock_handle.describe = AsyncMock(
        side_effect=Exception("Error getting workflow status")
    )
    mock_client.get_workflow_handle = AsyncMock(return_value=mock_handle)

    # Run load to connect the client
    await temporal_client.load()

    # Verify error is raised with correct message
    with pytest.raises(Exception, match="Error getting workflow status"):
        await temporal_client.get_workflow_run_status("test_workflow_id", "test_run_id")


@patch(
    "application_sdk.clients.temporal.Client.connect",
    new_callable=AsyncMock,
)
async def test_get_workflow_run_status_client_not_loaded(
    mock_connect: AsyncMock, temporal_client: TemporalWorkflowClient
):
    """Test get_workflow_run_status when client is not loaded."""
    with pytest.raises(ValueError, match="Client is not loaded"):
        await temporal_client.get_workflow_run_status("test_workflow_id", "test_run_id")


@patch("application_sdk.clients.temporal.logger")
@patch("application_sdk.clients.temporal.EventStore.publish_event")
@patch("application_sdk.clients.temporal.time.time")
@patch("application_sdk.clients.temporal.DEPLOYMENT_NAME", "test_deployment")
async def test_publish_token_refresh_event_success(
    mock_time: Mock,
    mock_publish_event: AsyncMock,
    mock_logger: MagicMock,
    temporal_client: TemporalWorkflowClient,
):
    """Test successful token refresh event publishing."""
    # Arrange
    mock_time.return_value = 1234567890.0
    mock_auth_manager = MagicMock()
    mock_auth_manager.get_token_expiry_time.return_value = 1234567895.0
    mock_auth_manager.get_time_until_expiry.return_value = 300.0
    temporal_client.auth_manager = mock_auth_manager

    # Act
    await temporal_client._publish_token_refresh_event()

    # Assert
    mock_time.assert_called_once()
    mock_auth_manager.get_token_expiry_time.assert_called_once()
    mock_auth_manager.get_time_until_expiry.assert_called_once()
    mock_publish_event.assert_called_once()

    # Verify the event structure
    call_args = mock_publish_event.call_args
    event = call_args[0][0]  # First positional argument

    assert event.event_type == "application_events"
    assert event.event_name == "token_refresh"
    assert event.data["application_name"] == "test_app"
    assert event.data["deployment_name"] == "test_deployment"
    assert event.data["force_refresh"] is True
    assert event.data["token_expiry_time"] == 1234567895.0
    assert event.data["time_until_expiry"] == 300.0
    assert event.data["refresh_timestamp"] == 1234567890.0

    mock_logger.info.assert_called_once_with("Published token refresh event")
    mock_logger.warning.assert_not_called()


@patch("application_sdk.clients.temporal.logger")
@patch("application_sdk.clients.temporal.EventStore.publish_event")
@patch("application_sdk.clients.temporal.time.time")
@patch("application_sdk.clients.temporal.DEPLOYMENT_NAME", "test_deployment")
async def test_publish_token_refresh_event_with_none_expiry_times(
    mock_time: Mock,
    mock_publish_event: AsyncMock,
    mock_logger: MagicMock,
    temporal_client: TemporalWorkflowClient,
):
    """Test token refresh event publishing with None expiry times."""
    # Arrange
    mock_time.return_value = 1234567890.0
    mock_auth_manager = MagicMock()
    mock_auth_manager.get_token_expiry_time.return_value = None
    mock_auth_manager.get_time_until_expiry.return_value = None
    temporal_client.auth_manager = mock_auth_manager

    # Act
    await temporal_client._publish_token_refresh_event()

    # Assert
    call_args = mock_publish_event.call_args
    event = call_args[0][0]  # First positional argument

    assert event.data["token_expiry_time"] == 0
    assert event.data["time_until_expiry"] == 0

    mock_logger.info.assert_called_once_with("Published token refresh event")
    mock_logger.warning.assert_not_called()


@patch("application_sdk.clients.temporal.logger")
@patch("application_sdk.clients.temporal.EventStore.publish_event")
@patch("application_sdk.clients.temporal.time.time")
async def test_publish_token_refresh_event_exception_handling(
    mock_time: Mock,
    mock_publish_event: AsyncMock,
    mock_logger: MagicMock,
    temporal_client: TemporalWorkflowClient,
):
    """Test token refresh event publishing handles exceptions gracefully."""
    # Arrange
    mock_time.return_value = 1234567890.0
    mock_auth_manager = MagicMock()
    mock_auth_manager.get_token_expiry_time.return_value = 1234567895.0
    mock_auth_manager.get_time_until_expiry.return_value = 300.0
    temporal_client.auth_manager = mock_auth_manager

    # Simulate event publishing failure
    mock_publish_event.side_effect = Exception("Event store connection failed")

    # Act - should not raise exception
    await temporal_client._publish_token_refresh_event()

    # Assert
    mock_publish_event.assert_called_once()
    mock_logger.info.assert_not_called()
    mock_logger.warning.assert_called_once_with(
        "Failed to publish token refresh event: Event store connection failed"
    )


@patch(
    "application_sdk.clients.temporal.Client.connect",
    new_callable=AsyncMock,
)
@patch("application_sdk.clients.temporal.SecretStore.get_deployment_secret")
async def test_load_with_prometheus_metrics(
    mock_get_config: AsyncMock,
    mock_connect: AsyncMock,
    temporal_client: TemporalWorkflowClient,
):
    """Test that load always passes a Runtime with PrometheusConfig."""
    mock_get_config.return_value = None
    mock_client = AsyncMock()
    mock_connect.return_value = mock_client

    await temporal_client.load()

    mock_connect.assert_called_once()
    call_kwargs = mock_connect.call_args[1]
    assert "runtime" in call_kwargs
    assert isinstance(call_kwargs["runtime"], Runtime)


class TestTemporalSslContext:
    """Test cases for TLS configuration integration with Temporal client.

    These tests verify that:
    1. Custom CA certificates are properly loaded when SSL_CERT_DIR is set
    2. The Temporal client uses TLSConfig with custom certificates for connections
    3. Default TLS behavior works when SSL_CERT_DIR is not set
    4. Both scenarios work correctly with the load() method
    """

    def test_get_tls_config_returns_tls_config_when_cert_dir_set(
        self, temporal_client: TemporalWorkflowClient
    ) -> None:
        """Test that _get_tls_config returns a TLSConfig when SSL_CERT_DIR is set."""
        # Create mock certificate bytes
        mock_cert_bytes = (
            b"-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----"
        )

        with patch(
            "application_sdk.clients.temporal.get_custom_ca_cert_bytes",
            return_value=mock_cert_bytes,
        ):
            result = temporal_client._get_tls_config()

            # Verify result is a TLSConfig with the certificate bytes
            assert isinstance(result, TLSConfig)
            assert result.server_root_ca_cert == mock_cert_bytes

    def test_get_tls_config_returns_workflow_tls_enabled_when_no_cert_dir(
        self, temporal_client: TemporalWorkflowClient
    ) -> None:
        """Test that _get_tls_config returns WORKFLOW_TLS_ENABLED when no SSL_CERT_DIR is set."""
        with patch(
            "application_sdk.clients.temporal.get_custom_ca_cert_bytes",
            return_value=None,
        ):
            with patch("application_sdk.clients.temporal.WORKFLOW_TLS_ENABLED", False):
                result = temporal_client._get_tls_config()
                assert result is False

            with patch("application_sdk.clients.temporal.WORKFLOW_TLS_ENABLED", True):
                result = temporal_client._get_tls_config()
                assert result is True

    @patch(
        "application_sdk.clients.temporal.Client.connect",
        new_callable=AsyncMock,
    )
    @patch("application_sdk.clients.temporal.SecretStore.get_deployment_secret")
    async def test_load_uses_tls_config_when_cert_dir_set(
        self,
        mock_get_config: AsyncMock,
        mock_connect: AsyncMock,
        temporal_client: TemporalWorkflowClient,
    ) -> None:
        """Test that load() passes TLSConfig to Client.connect() when SSL_CERT_DIR is set."""
        mock_get_config.return_value = None
        mock_client = AsyncMock()
        mock_connect.return_value = mock_client

        # Create mock certificate bytes
        mock_cert_bytes = (
            b"-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----"
        )

        with patch(
            "application_sdk.clients.temporal.get_custom_ca_cert_bytes",
            return_value=mock_cert_bytes,
        ):
            await temporal_client.load()

            # Verify Client.connect was called
            mock_connect.assert_called_once()

            # Verify the tls argument is a TLSConfig with the certificate bytes
            call_kwargs = mock_connect.call_args[1]
            tls_config = call_kwargs["tls"]
            assert isinstance(tls_config, TLSConfig)
            assert tls_config.server_root_ca_cert == mock_cert_bytes

    @patch(
        "application_sdk.clients.temporal.Client.connect",
        new_callable=AsyncMock,
    )
    @patch("application_sdk.clients.temporal.SecretStore.get_deployment_secret")
    async def test_load_uses_workflow_tls_enabled_when_no_cert_dir(
        self,
        mock_get_config: AsyncMock,
        mock_connect: AsyncMock,
        temporal_client: TemporalWorkflowClient,
    ) -> None:
        """Test that load() uses WORKFLOW_TLS_ENABLED when SSL_CERT_DIR is not set."""
        mock_get_config.return_value = None
        mock_client = AsyncMock()
        mock_connect.return_value = mock_client

        with patch(
            "application_sdk.clients.temporal.get_custom_ca_cert_bytes",
            return_value=None,
        ):
            with patch("application_sdk.clients.temporal.WORKFLOW_TLS_ENABLED", True):
                await temporal_client.load()

                # Verify Client.connect was called with tls=True
                mock_connect.assert_called_once()
                call_kwargs = mock_connect.call_args[1]
                assert call_kwargs["tls"] is True

    def test_get_tls_config_with_real_cert_from_cert_dir(
        self, temporal_client: TemporalWorkflowClient
    ) -> None:
        """Integration test: verify TLSConfig is properly created from certificate directory."""
        # Create a trustme CA and certificate
        ca = trustme.CA()

        with tempfile.TemporaryDirectory() as tmpdir:
            # Export the CA certificate to the temp directory
            ca_cert_path = f"{tmpdir}/ca.pem"
            ca.cert_pem.write_to_path(ca_cert_path)  # type: ignore[no-untyped-call]

            with patch("application_sdk.clients.ssl_utils.SSL_CERT_DIR", tmpdir):
                result = temporal_client._get_tls_config()

                # Should return a TLSConfig with the certificate bytes
                assert isinstance(result, TLSConfig)
                assert result.server_root_ca_cert is not None
                # Verify the certificate bytes contain PEM data
                assert b"-----BEGIN CERTIFICATE-----" in result.server_root_ca_cert

    def test_get_tls_config_with_custom_certificate_file(
        self, temporal_client: TemporalWorkflowClient
    ) -> None:
        """Test that custom certificate files are loaded into TLSConfig."""
        # Create a trustme CA and certificate
        ca = trustme.CA()

        with tempfile.TemporaryDirectory() as tmpdir:
            # Export the CA certificate to the temp directory
            ca_cert_path = f"{tmpdir}/ca.pem"
            ca.cert_pem.write_to_path(ca_cert_path)  # type: ignore[no-untyped-call]

            with patch("application_sdk.clients.ssl_utils.SSL_CERT_DIR", tmpdir):
                result = temporal_client._get_tls_config()

                # Should return a TLSConfig with the custom certificate loaded
                assert isinstance(result, TLSConfig)
                assert result.server_root_ca_cert is not None
                # The certificate bytes should contain valid PEM format
                assert b"-----BEGIN CERTIFICATE-----" in result.server_root_ca_cert
                assert b"-----END CERTIFICATE-----" in result.server_root_ca_cert

    @patch(
        "application_sdk.clients.temporal.Client.connect",
        new_callable=AsyncMock,
    )
    @patch("application_sdk.clients.temporal.SecretStore.get_deployment_secret")
    async def test_load_with_custom_cert_passes_tls_config(
        self,
        mock_get_config: AsyncMock,
        mock_connect: AsyncMock,
        temporal_client: TemporalWorkflowClient,
    ) -> None:
        """Test that load() passes a proper TLSConfig when custom certs are present.

        This verifies that the Temporal SDK receives the certificate bytes
        in the format it expects (TLSConfig.server_root_ca_cert).
        """
        mock_get_config.return_value = None
        mock_client = AsyncMock()
        mock_connect.return_value = mock_client

        # Create a trustme CA
        ca = trustme.CA()

        with tempfile.TemporaryDirectory() as tmpdir:
            # Export the CA certificate
            ca_cert_path = f"{tmpdir}/ca.pem"
            ca.cert_pem.write_to_path(ca_cert_path)  # type: ignore[no-untyped-call]

            with patch("application_sdk.clients.ssl_utils.SSL_CERT_DIR", tmpdir):
                await temporal_client.load()

                # Verify Client.connect was called
                mock_connect.assert_called_once()

                # Get the tls argument that was passed
                call_kwargs = mock_connect.call_args[1]
                tls_config = call_kwargs["tls"]

                # Verify it's a TLSConfig with the certificate bytes
                assert isinstance(tls_config, TLSConfig)
                assert tls_config.server_root_ca_cert is not None
                assert b"-----BEGIN CERTIFICATE-----" in tls_config.server_root_ca_cert
