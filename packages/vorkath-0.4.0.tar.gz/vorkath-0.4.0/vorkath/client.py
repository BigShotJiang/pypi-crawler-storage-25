"""Synchronous Vorkath client.

Construct one `Client` per process and reuse it. The client is
thread-safe; the underlying `httpx.Client` shares its connection
pool across threads. For asyncio code, use `vorkath.AsyncClient`
instead.

Example
-------

    import vorkath

    with vorkath.Client.from_env() as client:
        client.databases.create(name="docs", dimensions=64)
        client.vectors("docs").insert(key="d1", vector=[0.1] * 64)
        hits = client.vectors("docs").search(vector=[0.1] * 64, k=5)
        for hit in hits.results:
            print(hit.key, hit.distance)
"""

from __future__ import annotations

from types import TracebackType
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Type, Union
from urllib.parse import urlparse, urlunparse

from . import _paths, _transport
from ._transport import (
    DEFAULT_BACKOFF_BASE,
    DEFAULT_BACKOFF_CAP,
    DEFAULT_MAX_CONNECTIONS,
    DEFAULT_MAX_RETRIES,
    DEFAULT_POOL_SIZE,
    DEFAULT_TIMEOUT_SECONDS,
    OnRequest,
    RequestSummary,
    Transport,
    TransportConfig,
    _read_env_api_key,
    _read_env_core_url,
    _read_env_timeout,
    _read_env_url,
)
from .embed import EmbedResponse, embed_request
from .filters import Filter, to_payload
from .rerank import RerankResponse, rerank_request
from .search import Search
from .types import (
    AffectedIdsResponse,
    AggregateResponse,
    DatabaseInfo,
    InsertResponse,
    MultiSearchResponse,
    NamespaceMetadata,
    SearchResponse,
    ServerInfo,
    Snapshot,
    SqlResponse,
    VorkathError,
)

__all__ = [
    "Client",
    "DatabaseOperations",
    "Database",
    "VectorOperations",
    "BM25Operations",
    "SqlOperations",
    "AdminOperations",
    "SchemaOperations",
]


class Client:
    """Top-level synchronous Vorkath client.

    Parameters
    ----------
    base_url:
        REST root, e.g. ``http://localhost:8080``. Falls back to
        ``$VORKATH_BASE_URL`` when omitted.
    api_key:
        Optional API key. Falls back to ``$VORKATH_API_KEY``.
    timeout:
        Request timeout in seconds. Falls back to
        ``$VORKATH_TIMEOUT``, then 30s.
    max_retries:
        Number of retry attempts after the first failure. Default 2.
        Set to 0 to disable.
    default_database:
        If set, the per-resource accessors (``vectors()``, ``sql()``,
        ``database()``) use this database when the caller omits one.
    pool_size, max_connections:
        Tuning knobs for the underlying connection pool.
    user_agent:
        Override the default User-Agent. The library appends the SDK
        version when this is left empty.
    verify, http2, proxies:
        Forwarded to ``httpx.Client``.
    extra_headers:
        Extra headers attached to every request (e.g. tenant ID).
    """

    def __init__(
        self,
        base_url: Optional[str] = None,
        *,
        core_url: Optional[str] = None,
        api_key: Optional[str] = None,
        timeout: Optional[float] = None,
        max_retries: int = DEFAULT_MAX_RETRIES,
        backoff_base: float = DEFAULT_BACKOFF_BASE,
        backoff_cap: float = DEFAULT_BACKOFF_CAP,
        default_database: Optional[str] = None,
        pool_size: int = DEFAULT_POOL_SIZE,
        max_connections: int = DEFAULT_MAX_CONNECTIONS,
        user_agent: str = "",
        verify: bool = True,
        http2: bool = True,
        proxies: Optional[Any] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        on_request: Optional[OnRequest] = None,
        strict_validation: bool = False,
        transport: Optional[Transport] = None,
    ) -> None:
        resolved_url = _read_env_url(base_url)
        if not resolved_url:
            raise ValueError(
                "no base_url provided and VORKATH_BASE_URL is not set"
            )
        from . import __version__

        resolved_core = _read_env_core_url(core_url)
        config = TransportConfig(
            base_url=resolved_url.rstrip("/"),
            core_url=resolved_core.rstrip("/") if resolved_core else None,
            api_key=_read_env_api_key(api_key),
            timeout=_read_env_timeout(timeout),
            max_retries=max_retries,
            backoff_base=backoff_base,
            backoff_cap=backoff_cap,
            pool_size=pool_size,
            max_connections=max_connections,
            user_agent=user_agent,
            verify=verify,
            http2=http2,
            proxies=proxies,
            extra_headers=extra_headers,
            on_request=on_request,
            strict_validation=strict_validation,
            version=__version__,
        )
        self._transport: Transport = transport or Transport(config)
        self.default_database = default_database
        self.databases = DatabaseOperations(self._transport)
        self.search = Search(self._transport)

    # --- Constructors ----------------------------------------------------

    @classmethod
    def from_env(cls, **overrides: Any) -> "Client":
        """Build a client from ``VORKATH_BASE_URL`` and friends."""
        return cls(**overrides)

    @classmethod
    def from_url(cls, url: str, **overrides: Any) -> "Client":
        """Parse a connection URL into a Client.

        Accepted shapes:

            http://<api-key>@host:port/<database>
            https://<api-key>@host:port/<database>
            vorkath://<api-key>@host:port/<database>
            vorkaths://<api-key>@host:port/<database>
        """
        parsed = urlparse(url)
        scheme_map = {"vorkath": "http", "vorkaths": "https"}
        scheme = scheme_map.get(parsed.scheme, parsed.scheme) or "http"
        if scheme not in ("http", "https"):
            raise ValueError(f"unsupported scheme {parsed.scheme!r}")
        host = parsed.hostname or "localhost"
        port = parsed.port or (443 if scheme == "https" else 80)
        netloc = f"{host}:{port}"
        base_url = urlunparse((scheme, netloc, "", "", "", ""))
        api_key = parsed.username or None
        path = parsed.path.lstrip("/")
        default_db = path.split("/", 1)[0] if path else None
        return cls(
            base_url,
            api_key=api_key,
            default_database=default_db or None,
            **overrides,
        )

    # --- Resources -------------------------------------------------------

    def vectors(self, db: Optional[str] = None) -> "VectorOperations":
        return VectorOperations(self._transport, self._resolve_db(db))

    def bm25(self, db: Optional[str] = None) -> "BM25Operations":
        return BM25Operations(self._transport, self._resolve_db(db))

    def sql(self, db: Optional[str] = None) -> "SqlOperations":
        return SqlOperations(self._transport, self._resolve_db(db))

    def database(self, db: Optional[str] = None) -> "Database":
        return Database(self._transport, self._resolve_db(db))

    def admin(self, db: Optional[str] = None) -> "AdminOperations":
        """Admin RPCs (warm cache, pin, namespace metadata, copy)."""
        return AdminOperations(self._transport, self._resolve_db(db))

    def schema(self, db: Optional[str] = None) -> "SchemaOperations":
        """Schema CRUD for the named database."""
        return SchemaOperations(self._transport, self._resolve_db(db))

    # --- Top-level RPCs --------------------------------------------------

    # --- Managed-search RPCs --------------------------------------------

    def embed(
        self,
        inputs: Any,
        *,
        model: Optional[str] = None,
        namespace_id: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> EmbedResponse:
        """Embed one text or a batch of texts via the managed backend.

        Pass a single ``str`` for the caller-friendly form (the SDK
        still sends a one-element array to the backend and returns
        the standard :class:`EmbedResponse`). Pass a sequence of ``str``
        for batch mode.
        """
        return embed_request(
            self._transport,
            inputs,
            model=model,
            namespace_id=namespace_id,
            timeout=timeout,
        )

    def rerank(
        self,
        query: str,
        documents: Sequence[str],
        *,
        model: Optional[str] = None,
        top_n: Optional[int] = None,
        return_documents: bool = False,
        timeout: Optional[float] = None,
    ) -> RerankResponse:
        """Re-score ``(query, documents)`` pairs with the managed reranker.

        ``top_n`` defaults to ``len(documents)``. ``return_documents``
        defaults to ``False`` (caller already has the strings).
        """
        return rerank_request(
            self._transport,
            query,
            documents,
            model=model,
            top_n=top_n,
            return_documents=return_documents,
            timeout=timeout,
        )

    def health(self) -> bool:
        """Liveness probe. Returns True iff the server reports ``ok``."""
        try:
            r = self._transport.request("GET", "/healthz")
            return isinstance(r, dict) and r.get("status") == "ok"
        except VorkathError:
            return False

    def info(self) -> Dict[str, Any]:
        """Server identity + capability set as a raw dict."""
        return dict(self._transport.request("GET", "/v1/info"))

    def server_info(self) -> ServerInfo:
        """Typed variant of `info()`."""
        return ServerInfo.from_dict(self._transport.request("GET", "/v1/info"))

    # --- Lifecycle -------------------------------------------------------

    def close(self) -> None:
        self._transport.close()

    def __enter__(self) -> "Client":
        return self

    def __exit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc: Optional[BaseException],
        tb: Optional[TracebackType],
    ) -> None:
        self.close()

    def with_options(self, **overrides: Any) -> "Client":
        """Return a copy of the client with overrides applied.

        Useful for per-tenant headers, tighter timeouts on a hot path,
        etc. Shares no transport state with the original.
        """
        cfg = self._transport.config
        defaults = {
            "base_url": cfg.base_url,
            "core_url": cfg.core_url,
            "api_key": cfg.api_key,
            "timeout": cfg.timeout,
            "max_retries": cfg.max_retries,
            "backoff_base": cfg.backoff_base,
            "backoff_cap": cfg.backoff_cap,
            "default_database": self.default_database,
            "pool_size": cfg.pool_size,
            "max_connections": cfg.max_connections,
            "user_agent": cfg.user_agent,
            "verify": cfg.verify,
            "http2": cfg.http2,
            "proxies": cfg.proxies,
            "extra_headers": cfg.extra_headers,
        }
        defaults.update(overrides)
        return Client(**defaults)

    # --- Internal --------------------------------------------------------

    def _resolve_db(self, db: Optional[str]) -> str:
        resolved = db or self.default_database
        if not resolved:
            raise ValueError(
                "no database specified; pass one explicitly or use "
                "Client(default_database=...) or Client.from_url(.../db)"
            )
        return resolved

    def __repr__(self) -> str:
        masked = "***" if self._transport.config.api_key else None
        return (
            f"Client(base_url={self._transport.config.base_url!r}, "
            f"api_key={masked!r})"
        )


class DatabaseOperations:
    """Database-level CRUD."""

    def __init__(self, transport: Transport) -> None:
        self._transport = transport

    def create(
        self,
        *,
        name: str,
        dimensions: int = 0,
        metric: str = "l2",
        capabilities: Optional[Sequence[str]] = None,
        shard_group: Optional[str] = None,
        qps_limit: Optional[int] = None,
        storage_bytes_limit: Optional[int] = None,
        oltp_schema: Optional[Mapping[str, Any]] = None,
    ) -> DatabaseInfo:
        body = _paths.create_database_body(
            name=name,
            dimensions=dimensions,
            metric=metric,
            capabilities=capabilities,
            shard_group=shard_group,
            qps_limit=qps_limit,
            storage_bytes_limit=storage_bytes_limit,
            oltp_schema=oltp_schema,
        )
        resp = self._transport.request("POST", _paths.databases(), json_body=body)
        db = resp.get("database") or {"db_id": name}
        return DatabaseInfo.from_dict(db)

    def list(self) -> List[DatabaseInfo]:
        resp = self._transport.request("GET", _paths.databases())
        return [DatabaseInfo.from_dict(d) for d in resp.get("databases", [])]

    def iter(self) -> Iterable[DatabaseInfo]:
        """Iterator wrapper around `list()`. The router does not yet
        page database listings; this method is forward-compatible
        with cursor pagination when it lands."""
        for db in self.list():
            yield db

    def describe(self, name: str) -> DatabaseInfo:
        resp = self._transport.request("GET", _paths.database(name))
        return DatabaseInfo.from_dict(resp.get("database", {}))

    def drop(self, name: str) -> None:
        self._transport.request("DELETE", _paths.database(name))


class Database:
    """Snapshot / restore / metadata for one database."""

    def __init__(self, transport: Transport, db: str) -> None:
        self._transport = transport
        self._db = db

    @property
    def name(self) -> str:
        return self._db

    def snapshot(self, tag: str) -> Snapshot:
        resp = self._transport.request(
            "POST", _paths.snapshot(self._db), json_body=_paths.snapshot_body(tag)
        )
        return Snapshot(
            tag=tag,
            db_id=self._db,
            paths=list(resp.get("snapshot_paths_per_shard", [])),
        )

    def restore(self, tag: str) -> None:
        self._transport.request(
            "POST", _paths.restore(self._db), json_body=_paths.snapshot_body(tag)
        )

    def describe(self) -> DatabaseInfo:
        return DatabaseInfo.from_dict(
            self._transport.request("GET", _paths.database(self._db)).get(
                "database", {}
            )
        )


class VectorOperations:
    """Vector CRUD scoped to one database."""

    def __init__(self, transport: Transport, db: str) -> None:
        self._transport = transport
        self._db = db

    def insert(
        self,
        *,
        key: str,
        vector: Sequence[float],
        metadata: Optional[Mapping[str, str]] = None,
        text: Optional[str] = None,
        title: Optional[str] = None,
        return_affected_ids: bool = False,
        idempotency_key: Optional[str] = None,
        if_match: Optional[str] = None,
        if_none_match: Optional[str] = None,
        expected_version: Optional[int] = None,
    ) -> InsertResponse:
        body = _paths.insert_vector_body(
            key=key,
            vector=vector,
            metadata=metadata,
            text=text,
            title=title,
            return_affected_ids=return_affected_ids,
        )
        headers = _paths.cas_headers(
            if_match=if_match, if_none_match=if_none_match, expected_version=expected_version
        )
        resp = self._transport.request(
            "POST",
            _paths.vectors(self._db),
            json_body=body,
            idempotency_key=idempotency_key,
            headers=headers or None,
        )
        return InsertResponse.from_dict(resp)

    def upsert_many(
        self,
        rows: Sequence[Mapping[str, Any]],
        *,
        return_affected_ids: bool = False,
        allow_partial: bool = False,
        disable_backpressure: bool = False,
        schema: Optional[Mapping[str, Any]] = None,
        idempotency_key: Optional[str] = None,
    ) -> AffectedIdsResponse:
        """Upsert a batch of rows in one RPC.

        Each row is a dict with at least `id`/`key` and `vector`,
        plus any attributes the schema declares. For chunked
        client-side batching across many requests, see
        `vectors(...).bulk_upsert(...)`.
        """
        body = _paths.upsert_batch_body(
            rows,
            return_affected_ids=return_affected_ids,
            allow_partial=allow_partial,
            disable_backpressure=disable_backpressure,
            schema=schema,
        )
        resp = self._transport.request(
            "POST",
            _paths.vector_upsert_batch(self._db),
            json_body=body,
            idempotency_key=idempotency_key,
        )
        return AffectedIdsResponse.from_dict(resp)

    def bulk_upsert(
        self,
        rows: Iterable[Mapping[str, Any]],
        *,
        chunk_size: int = 1000,
        max_bytes: int = 8 * 1024 * 1024,
        return_affected_ids: bool = False,
        schema: Optional[Mapping[str, Any]] = None,
    ) -> AffectedIdsResponse:
        """Stream `rows` to the server in bounded chunks.

        Chunks are flushed when either `chunk_size` rows or
        `max_bytes` of JSON-encoded payload accumulates. The synch
        path issues chunks back-to-back; for parallel inflight, use
        the async client's `bulk_upsert` instead.
        """
        import json as _json

        buffer: List[Mapping[str, Any]] = []
        buffer_bytes = 2  # `[]`
        all_ids: List[str] = []
        total = 0

        def flush() -> None:
            nonlocal buffer, buffer_bytes
            if not buffer:
                return
            resp = self.upsert_many(
                buffer,
                return_affected_ids=return_affected_ids,
                schema=schema,
            )
            all_ids.extend(resp.affected_ids)
            buffer = []
            buffer_bytes = 2

        for row in rows:
            row_bytes = len(_json.dumps(row, separators=(",", ":"))) + 1
            if buffer and (
                len(buffer) >= chunk_size or buffer_bytes + row_bytes > max_bytes
            ):
                flush()
            buffer.append(row)
            buffer_bytes += row_bytes
            total += 1
        flush()
        return AffectedIdsResponse(affected_ids=all_ids, affected_count=total)

    def search(
        self,
        *,
        vector: Sequence[float],
        k: int = 10,
        n_probe: Optional[int] = None,
        query_dimensions: Optional[int] = None,
        text_query: Optional[str] = None,
        search_mode: str = "vector",
        filters: Optional[Union[Filter, Mapping[str, Any]]] = None,
        consistency: Optional[str] = None,
        last_as_prefix: bool = False,
        rank: Optional[Mapping[str, Any]] = None,
        limit_per: Optional[Mapping[str, Any]] = None,
        page_token: Optional[str] = None,
    ) -> SearchResponse:
        body = _paths.search_vector_body(
            vector=vector,
            k=k,
            n_probe=n_probe,
            query_dimensions=query_dimensions,
            text_query=text_query,
            search_mode=search_mode,
            filters=to_payload(filters),
            consistency=consistency,
            last_as_prefix=last_as_prefix,
            rank=rank,
            limit_per=limit_per,
            page_token=page_token,
        )
        resp = self._transport.request(
            "POST", _paths.vector_search(self._db), json_body=body
        )
        return SearchResponse.from_dict(resp)

    def knn(
        self,
        *,
        vector: Sequence[float],
        k: int = 10,
        filters: Optional[Union[Filter, Mapping[str, Any]]] = None,
        query_dimensions: Optional[int] = None,
    ) -> SearchResponse:
        """Exact-kNN search (ground truth, no IVF/HNSW probing).

        Slower than `search()` but useful for recall measurement and
        for filtered queries where the index can't reach `k` matches.
        """
        body = _paths.knn_body(
            vector=vector,
            k=k,
            filters=to_payload(filters),
            query_dimensions=query_dimensions,
        )
        resp = self._transport.request(
            "POST", _paths.vector_knn(self._db), json_body=body
        )
        return SearchResponse.from_dict(resp)

    def patch_by_filter(
        self,
        *,
        filters: Union[Filter, Mapping[str, Any]],
        patch: Mapping[str, Any],
        return_affected_ids: bool = False,
        allow_partial: bool = False,
        idempotency_key: Optional[str] = None,
    ) -> AffectedIdsResponse:
        """Update every row matching `filters` with `patch`."""
        payload = to_payload(filters)
        if payload is None:
            raise ValueError("filters cannot be None for patch_by_filter")
        body = _paths.patch_by_filter_body(
            filters=payload,
            patch=patch,
            return_affected_ids=return_affected_ids,
            allow_partial=allow_partial,
        )
        resp = self._transport.request(
            "POST",
            _paths.vector_patch_by_filter(self._db),
            json_body=body,
            idempotency_key=idempotency_key,
        )
        return AffectedIdsResponse.from_dict(resp)

    def delete_by_filter(
        self,
        *,
        filters: Union[Filter, Mapping[str, Any]],
        return_affected_ids: bool = False,
        allow_partial: bool = False,
        idempotency_key: Optional[str] = None,
    ) -> AffectedIdsResponse:
        """Delete every row matching `filters`."""
        payload = to_payload(filters)
        if payload is None:
            raise ValueError("filters cannot be None for delete_by_filter")
        body = _paths.delete_by_filter_body(
            filters=payload,
            return_affected_ids=return_affected_ids,
            allow_partial=allow_partial,
        )
        resp = self._transport.request(
            "POST",
            _paths.vector_delete_by_filter(self._db),
            json_body=body,
            idempotency_key=idempotency_key,
        )
        return AffectedIdsResponse.from_dict(resp)

    def aggregate(
        self,
        *,
        aggregations: Sequence[Mapping[str, Any]],
        group_by: Optional[Sequence[str]] = None,
        filters: Optional[Union[Filter, Mapping[str, Any]]] = None,
        for_each_unique: Optional[str] = None,
    ) -> AggregateResponse:
        """Run aggregations (count, sum, avg, min, max) with optional
        grouping. Set `for_each_unique=field` to fan out the
        aggregations once per distinct value of `field`."""
        body = _paths.aggregate_body(
            aggregations=aggregations,
            group_by=group_by,
            filters=to_payload(filters),
            for_each_unique=for_each_unique,
        )
        resp = self._transport.request(
            "POST", _paths.vector_aggregate(self._db), json_body=body
        )
        return AggregateResponse.from_dict(resp)

    def multi_search(
        self, queries: Sequence[Mapping[str, Any]]
    ) -> MultiSearchResponse:
        """Atomic multi-query against `/multi-search`."""
        resp = self._transport.request(
            "POST",
            _paths.vector_multi_search(self._db),
            json_body=_paths.multi_search_body(queries),
        )
        return MultiSearchResponse.from_dict(resp)

    def delete(self, key: str) -> None:
        self._transport.request("DELETE", _paths.vector(self._db, key))


class BM25Operations:
    """Per-database BM25 index management."""

    def __init__(self, transport: Transport, db: str) -> None:
        self._transport = transport
        self._db = db

    def create(self, *, name: str, schema: Mapping[str, Any]) -> Dict[str, Any]:
        return dict(
            self._transport.request(
                "POST",
                _paths.bm25_indexes(self._db),
                json_body={"name": name, "schema": dict(schema)},
            )
        )

    def list(self) -> List[Dict[str, Any]]:
        resp = self._transport.request("GET", _paths.bm25_indexes(self._db))
        return list(resp.get("indexes", []) or [])

    def describe(self, name: str) -> Dict[str, Any]:
        return dict(self._transport.request("GET", _paths.bm25_index(self._db, name)))

    def drop(self, name: str) -> None:
        self._transport.request("DELETE", _paths.bm25_index(self._db, name))

    def search(
        self, name: str, *, query: str, k: int = 10, **extra: Any
    ) -> SearchResponse:
        body = {"query": query, "k": k, **extra}
        resp = self._transport.request(
            "POST", _paths.bm25_index_search(self._db, name), json_body=body
        )
        return SearchResponse.from_dict(resp)


class SchemaOperations:
    """Schema CRUD for one database (per-attribute types, indexes,
    tokenizers, etc.)."""

    def __init__(self, transport: Transport, db: str) -> None:
        self._transport = transport
        self._db = db

    def get(self) -> Dict[str, Any]:
        return dict(self._transport.request("GET", _paths.schema(self._db)))

    def set(self, schema: Mapping[str, Any]) -> Dict[str, Any]:
        """Replace the schema. Online schema changes rebuild affected
        attribute indexes in the background."""
        return dict(
            self._transport.request(
                "PUT", _paths.schema(self._db), json_body={"schema": dict(schema)}
            )
        )

    def patch(self, patch: Mapping[str, Any]) -> Dict[str, Any]:
        """Merge `patch` into the existing schema."""
        return dict(
            self._transport.request(
                "PATCH", _paths.schema(self._db), json_body={"patch": dict(patch)}
            )
        )


class AdminOperations:
    """Admin RPCs scoped to one database."""

    def __init__(self, transport: Transport, db: str) -> None:
        self._transport = transport
        self._db = db

    def warm_cache(
        self,
        *,
        scope: str = "namespace",
        ranges: Optional[Sequence[Mapping[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """Hint the server to warm the cache. `scope` is one of
        `"namespace"` (whole DB), `"vectors"`, `"bm25"`. Pass
        `ranges=[{"key_min": ..., "key_max": ...}]` to warm specific
        slices."""
        body: Dict[str, Any] = {"scope": scope}
        if ranges is not None:
            body["ranges"] = [dict(r) for r in ranges]
        return dict(
            self._transport.request("POST", _paths.admin_warm_cache(self._db), json_body=body)
        )

    def pin(self, *, temperature: str = "hot") -> Dict[str, Any]:
        """Pin the database in cache. `temperature` is `"hot"`,
        `"warm"`, or `"cold"`. Hot data stays in NVMe; warm in tier 2;
        cold may evict to object storage."""
        return dict(
            self._transport.request(
                "POST",
                _paths.admin_pin(self._db),
                json_body={"temperature": temperature},
            )
        )

    def namespace_metadata(self) -> NamespaceMetadata:
        """Row count, bytes-on-disk, last-write timestamp, schema."""
        return NamespaceMetadata.from_dict(
            self._transport.request("GET", _paths.admin_namespace_metadata(self._db))
        )

    def copy_from(
        self,
        *,
        source_db: str,
        filters: Optional[Union[Filter, Mapping[str, Any]]] = None,
        attributes: Optional[Sequence[str]] = None,
    ) -> Dict[str, Any]:
        """Server-side copy from `source_db` into this database.

        `attributes=None` copies every column. Set `filters=` to copy
        only matching rows."""
        body: Dict[str, Any] = {"source": source_db}
        payload = to_payload(filters)
        if payload is not None:
            body["filters"] = payload
        if attributes is not None:
            body["attributes"] = list(attributes)
        return dict(
            self._transport.request(
                "POST", _paths.admin_copy_from(self._db), json_body=body
            )
        )


class SqlOperations:
    """Execute SQL against a database."""

    def __init__(self, transport: Transport, db: str) -> None:
        self._transport = transport
        self._db = db

    def execute(
        self,
        statement: str,
        *,
        params: Optional[Sequence[Any]] = None,
        idempotency_key: Optional[str] = None,
    ) -> SqlResponse:
        resp = self._transport.request(
            "POST",
            _paths.sql(self._db),
            json_body=_paths.sql_body(statement, params),
            idempotency_key=idempotency_key,
        )
        return SqlResponse.from_dict(resp)
