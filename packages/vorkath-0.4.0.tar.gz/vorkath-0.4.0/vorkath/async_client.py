"""Asynchronous Vorkath client.

Use this from any asyncio program. Construct one `AsyncClient` per
process and reuse it; the underlying connection pool is shared
across tasks.

Example
-------

    import asyncio
    import vorkath

    async def main() -> None:
        async with vorkath.AsyncClient.from_env() as client:
            await client.databases.create(name="docs", dimensions=64)
            await client.vectors("docs").insert(key="d1", vector=[0.1] * 64)
            hits = await client.vectors("docs").search(vector=[0.1] * 64, k=5)
            for hit in hits.results:
                print(hit.key, hit.distance)

    asyncio.run(main())
"""

from __future__ import annotations

import asyncio
from types import TracebackType
from typing import Any, AsyncIterable, Awaitable, Dict, Iterable, List, Mapping, Optional, Sequence, Type, Union
from urllib.parse import urlparse, urlunparse

from . import _paths
from ._transport import (
    DEFAULT_BACKOFF_BASE,
    DEFAULT_BACKOFF_CAP,
    DEFAULT_MAX_CONNECTIONS,
    DEFAULT_MAX_RETRIES,
    DEFAULT_POOL_SIZE,
    AsyncTransport,
    OnRequest,
    RequestSummary,
    TransportConfig,
    _read_env_api_key,
    _read_env_core_url,
    _read_env_timeout,
    _read_env_url,
)
from .embed import EmbedResponse, embed_request_async
from .filters import Filter, to_payload
from .rerank import RerankResponse, rerank_request_async
from .search import AsyncSearch
from .types import (
    AffectedIdsResponse,
    AggregateResponse,
    DatabaseInfo,
    InsertResponse,
    MultiSearchResponse,
    NamespaceMetadata,
    SearchResponse,
    ServerInfo,
    Snapshot,
    SqlResponse,
    VorkathError,
)

__all__ = [
    "AsyncClient",
    "AsyncDatabaseOperations",
    "AsyncDatabase",
    "AsyncVectorOperations",
    "AsyncBM25Operations",
    "AsyncSqlOperations",
    "AsyncAdminOperations",
    "AsyncSchemaOperations",
]


class AsyncClient:
    """Top-level asyncio Vorkath client."""

    def __init__(
        self,
        base_url: Optional[str] = None,
        *,
        core_url: Optional[str] = None,
        api_key: Optional[str] = None,
        timeout: Optional[float] = None,
        max_retries: int = DEFAULT_MAX_RETRIES,
        backoff_base: float = DEFAULT_BACKOFF_BASE,
        backoff_cap: float = DEFAULT_BACKOFF_CAP,
        default_database: Optional[str] = None,
        pool_size: int = DEFAULT_POOL_SIZE,
        max_connections: int = DEFAULT_MAX_CONNECTIONS,
        user_agent: str = "",
        verify: bool = True,
        http2: bool = True,
        proxies: Optional[Any] = None,
        extra_headers: Optional[Mapping[str, str]] = None,
        on_request: Optional[OnRequest] = None,
        strict_validation: bool = False,
        transport: Optional[AsyncTransport] = None,
    ) -> None:
        resolved_url = _read_env_url(base_url)
        if not resolved_url:
            raise ValueError(
                "no base_url provided and VORKATH_BASE_URL is not set"
            )
        from . import __version__

        resolved_core = _read_env_core_url(core_url)
        config = TransportConfig(
            base_url=resolved_url.rstrip("/"),
            core_url=resolved_core.rstrip("/") if resolved_core else None,
            api_key=_read_env_api_key(api_key),
            timeout=_read_env_timeout(timeout),
            max_retries=max_retries,
            backoff_base=backoff_base,
            backoff_cap=backoff_cap,
            pool_size=pool_size,
            max_connections=max_connections,
            user_agent=user_agent,
            verify=verify,
            http2=http2,
            proxies=proxies,
            extra_headers=extra_headers,
            on_request=on_request,
            strict_validation=strict_validation,
            version=__version__,
        )
        self._transport: AsyncTransport = transport or AsyncTransport(config)
        self.default_database = default_database
        self.databases = AsyncDatabaseOperations(self._transport)
        self.search = AsyncSearch(self._transport)

    # --- Constructors ----------------------------------------------------

    @classmethod
    def from_env(cls, **overrides: Any) -> "AsyncClient":
        return cls(**overrides)

    @classmethod
    def from_url(cls, url: str, **overrides: Any) -> "AsyncClient":
        parsed = urlparse(url)
        scheme_map = {"vorkath": "http", "vorkaths": "https"}
        scheme = scheme_map.get(parsed.scheme, parsed.scheme) or "http"
        if scheme not in ("http", "https"):
            raise ValueError(f"unsupported scheme {parsed.scheme!r}")
        host = parsed.hostname or "localhost"
        port = parsed.port or (443 if scheme == "https" else 80)
        netloc = f"{host}:{port}"
        base_url = urlunparse((scheme, netloc, "", "", "", ""))
        api_key = parsed.username or None
        path = parsed.path.lstrip("/")
        default_db = path.split("/", 1)[0] if path else None
        return cls(
            base_url,
            api_key=api_key,
            default_database=default_db or None,
            **overrides,
        )

    # --- Resources -------------------------------------------------------

    def vectors(self, db: Optional[str] = None) -> "AsyncVectorOperations":
        return AsyncVectorOperations(self._transport, self._resolve_db(db))

    def bm25(self, db: Optional[str] = None) -> "AsyncBM25Operations":
        return AsyncBM25Operations(self._transport, self._resolve_db(db))

    def sql(self, db: Optional[str] = None) -> "AsyncSqlOperations":
        return AsyncSqlOperations(self._transport, self._resolve_db(db))

    def database(self, db: Optional[str] = None) -> "AsyncDatabase":
        return AsyncDatabase(self._transport, self._resolve_db(db))

    def admin(self, db: Optional[str] = None) -> "AsyncAdminOperations":
        return AsyncAdminOperations(self._transport, self._resolve_db(db))

    def schema(self, db: Optional[str] = None) -> "AsyncSchemaOperations":
        return AsyncSchemaOperations(self._transport, self._resolve_db(db))

    # --- Top-level RPCs --------------------------------------------------

    # --- Managed-search RPCs --------------------------------------------

    async def embed(
        self,
        inputs: Any,
        *,
        model: Optional[str] = None,
        namespace_id: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> EmbedResponse:
        """Embed one text or a batch of texts via the managed backend."""
        return await embed_request_async(
            self._transport,
            inputs,
            model=model,
            namespace_id=namespace_id,
            timeout=timeout,
        )

    async def rerank(
        self,
        query: str,
        documents: Sequence[str],
        *,
        model: Optional[str] = None,
        top_n: Optional[int] = None,
        return_documents: bool = False,
        timeout: Optional[float] = None,
    ) -> RerankResponse:
        """Re-score ``(query, documents)`` pairs with the managed reranker."""
        return await rerank_request_async(
            self._transport,
            query,
            documents,
            model=model,
            top_n=top_n,
            return_documents=return_documents,
            timeout=timeout,
        )

    async def health(self) -> bool:
        try:
            r = await self._transport.request("GET", "/healthz")
            return isinstance(r, dict) and r.get("status") == "ok"
        except VorkathError:
            return False

    async def info(self) -> Dict[str, Any]:
        return dict(await self._transport.request("GET", "/v1/info"))

    async def server_info(self) -> ServerInfo:
        return ServerInfo.from_dict(await self._transport.request("GET", "/v1/info"))

    # --- Lifecycle -------------------------------------------------------

    async def aclose(self) -> None:
        await self._transport.aclose()

    async def __aenter__(self) -> "AsyncClient":
        return self

    async def __aexit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc: Optional[BaseException],
        tb: Optional[TracebackType],
    ) -> None:
        await self.aclose()

    def with_options(self, **overrides: Any) -> "AsyncClient":
        cfg = self._transport.config
        defaults = {
            "base_url": cfg.base_url,
            "api_key": cfg.api_key,
            "timeout": cfg.timeout,
            "max_retries": cfg.max_retries,
            "backoff_base": cfg.backoff_base,
            "backoff_cap": cfg.backoff_cap,
            "default_database": self.default_database,
            "pool_size": cfg.pool_size,
            "max_connections": cfg.max_connections,
            "user_agent": cfg.user_agent,
            "verify": cfg.verify,
            "http2": cfg.http2,
            "proxies": cfg.proxies,
            "extra_headers": cfg.extra_headers,
        }
        defaults.update(overrides)
        return AsyncClient(**defaults)

    # --- Internal --------------------------------------------------------

    def _resolve_db(self, db: Optional[str]) -> str:
        resolved = db or self.default_database
        if not resolved:
            raise ValueError(
                "no database specified; pass one explicitly or use "
                "AsyncClient(default_database=...) or AsyncClient.from_url(.../db)"
            )
        return resolved

    def __repr__(self) -> str:
        masked = "***" if self._transport.config.api_key else None
        return (
            f"AsyncClient(base_url={self._transport.config.base_url!r}, "
            f"api_key={masked!r})"
        )


class AsyncDatabaseOperations:
    def __init__(self, transport: AsyncTransport) -> None:
        self._transport = transport

    async def create(
        self,
        *,
        name: str,
        dimensions: int = 0,
        metric: str = "l2",
        capabilities: Optional[Sequence[str]] = None,
        shard_group: Optional[str] = None,
        qps_limit: Optional[int] = None,
        storage_bytes_limit: Optional[int] = None,
        oltp_schema: Optional[Mapping[str, Any]] = None,
    ) -> DatabaseInfo:
        body = _paths.create_database_body(
            name=name,
            dimensions=dimensions,
            metric=metric,
            capabilities=capabilities,
            shard_group=shard_group,
            qps_limit=qps_limit,
            storage_bytes_limit=storage_bytes_limit,
            oltp_schema=oltp_schema,
        )
        resp = await self._transport.request("POST", _paths.databases(), json_body=body)
        db = resp.get("database") or {"db_id": name}
        return DatabaseInfo.from_dict(db)

    async def list(self) -> List[DatabaseInfo]:
        resp = await self._transport.request("GET", _paths.databases())
        return [DatabaseInfo.from_dict(d) for d in resp.get("databases", [])]

    async def iter(self) -> AsyncIterable[DatabaseInfo]:
        """Async iterator wrapper around `list()`. Forward-compatible
        with cursor pagination."""
        for db in await self.list():
            yield db

    async def describe(self, name: str) -> DatabaseInfo:
        resp = await self._transport.request("GET", _paths.database(name))
        return DatabaseInfo.from_dict(resp.get("database", {}))

    async def drop(self, name: str) -> None:
        await self._transport.request("DELETE", _paths.database(name))


class AsyncDatabase:
    def __init__(self, transport: AsyncTransport, db: str) -> None:
        self._transport = transport
        self._db = db

    @property
    def name(self) -> str:
        return self._db

    async def snapshot(self, tag: str) -> Snapshot:
        resp = await self._transport.request(
            "POST", _paths.snapshot(self._db), json_body=_paths.snapshot_body(tag)
        )
        return Snapshot(
            tag=tag,
            db_id=self._db,
            paths=list(resp.get("snapshot_paths_per_shard", [])),
        )

    async def restore(self, tag: str) -> None:
        await self._transport.request(
            "POST", _paths.restore(self._db), json_body=_paths.snapshot_body(tag)
        )

    async def describe(self) -> DatabaseInfo:
        resp = await self._transport.request("GET", _paths.database(self._db))
        return DatabaseInfo.from_dict(resp.get("database", {}))


class AsyncVectorOperations:
    def __init__(self, transport: AsyncTransport, db: str) -> None:
        self._transport = transport
        self._db = db

    async def insert(
        self,
        *,
        key: str,
        vector: Sequence[float],
        metadata: Optional[Mapping[str, str]] = None,
        text: Optional[str] = None,
        title: Optional[str] = None,
        return_affected_ids: bool = False,
        idempotency_key: Optional[str] = None,
        if_match: Optional[str] = None,
        if_none_match: Optional[str] = None,
        expected_version: Optional[int] = None,
    ) -> InsertResponse:
        body = _paths.insert_vector_body(
            key=key,
            vector=vector,
            metadata=metadata,
            text=text,
            title=title,
            return_affected_ids=return_affected_ids,
        )
        headers = _paths.cas_headers(
            if_match=if_match, if_none_match=if_none_match, expected_version=expected_version
        )
        resp = await self._transport.request(
            "POST",
            _paths.vectors(self._db),
            json_body=body,
            idempotency_key=idempotency_key,
            headers=headers or None,
        )
        return InsertResponse.from_dict(resp)

    async def upsert_many(
        self,
        rows: Sequence[Mapping[str, Any]],
        *,
        return_affected_ids: bool = False,
        allow_partial: bool = False,
        disable_backpressure: bool = False,
        schema: Optional[Mapping[str, Any]] = None,
        idempotency_key: Optional[str] = None,
    ) -> AffectedIdsResponse:
        body = _paths.upsert_batch_body(
            rows,
            return_affected_ids=return_affected_ids,
            allow_partial=allow_partial,
            disable_backpressure=disable_backpressure,
            schema=schema,
        )
        resp = await self._transport.request(
            "POST",
            _paths.vector_upsert_batch(self._db),
            json_body=body,
            idempotency_key=idempotency_key,
        )
        return AffectedIdsResponse.from_dict(resp)

    async def bulk_upsert(
        self,
        rows: Union[Iterable[Mapping[str, Any]], AsyncIterable[Mapping[str, Any]]],
        *,
        chunk_size: int = 1000,
        max_bytes: int = 8 * 1024 * 1024,
        max_inflight: int = 4,
        return_affected_ids: bool = False,
        schema: Optional[Mapping[str, Any]] = None,
    ) -> AffectedIdsResponse:
        """Stream `rows` to the server in bounded chunks with up to
        `max_inflight` requests outstanding. Accepts both sync and
        async iterables."""
        import json as _json

        sem = asyncio.Semaphore(max_inflight)
        results: List[AffectedIdsResponse] = []

        async def flush(chunk: List[Mapping[str, Any]]) -> None:
            async with sem:
                resp = await self.upsert_many(
                    chunk,
                    return_affected_ids=return_affected_ids,
                    schema=schema,
                )
                results.append(resp)

        tasks: List[asyncio.Task[None]] = []
        buffer: List[Mapping[str, Any]] = []
        buffer_bytes = 2
        total = 0

        async def emit() -> None:
            nonlocal buffer, buffer_bytes
            if buffer:
                tasks.append(asyncio.create_task(flush(buffer)))
                buffer = []
                buffer_bytes = 2

        if hasattr(rows, "__aiter__"):
            async for row in rows:  # type: ignore[union-attr]
                row_bytes = len(_json.dumps(row, separators=(",", ":"))) + 1
                if buffer and (
                    len(buffer) >= chunk_size or buffer_bytes + row_bytes > max_bytes
                ):
                    await emit()
                buffer.append(row)
                buffer_bytes += row_bytes
                total += 1
        else:
            for row in rows:  # type: ignore[union-attr]
                row_bytes = len(_json.dumps(row, separators=(",", ":"))) + 1
                if buffer and (
                    len(buffer) >= chunk_size or buffer_bytes + row_bytes > max_bytes
                ):
                    await emit()
                buffer.append(row)
                buffer_bytes += row_bytes
                total += 1
        await emit()
        if tasks:
            await asyncio.gather(*tasks)
        all_ids: List[str] = []
        for r in results:
            all_ids.extend(r.affected_ids)
        return AffectedIdsResponse(affected_ids=all_ids, affected_count=total)

    async def search(
        self,
        *,
        vector: Sequence[float],
        k: int = 10,
        n_probe: Optional[int] = None,
        query_dimensions: Optional[int] = None,
        text_query: Optional[str] = None,
        search_mode: str = "vector",
        filters: Optional[Union[Filter, Mapping[str, Any]]] = None,
        consistency: Optional[str] = None,
        last_as_prefix: bool = False,
        rank: Optional[Mapping[str, Any]] = None,
        limit_per: Optional[Mapping[str, Any]] = None,
        page_token: Optional[str] = None,
    ) -> SearchResponse:
        body = _paths.search_vector_body(
            vector=vector,
            k=k,
            n_probe=n_probe,
            query_dimensions=query_dimensions,
            text_query=text_query,
            search_mode=search_mode,
            filters=to_payload(filters),
            consistency=consistency,
            last_as_prefix=last_as_prefix,
            rank=rank,
            limit_per=limit_per,
            page_token=page_token,
        )
        resp = await self._transport.request(
            "POST", _paths.vector_search(self._db), json_body=body
        )
        return SearchResponse.from_dict(resp)

    async def knn(
        self,
        *,
        vector: Sequence[float],
        k: int = 10,
        filters: Optional[Union[Filter, Mapping[str, Any]]] = None,
        query_dimensions: Optional[int] = None,
    ) -> SearchResponse:
        body = _paths.knn_body(
            vector=vector,
            k=k,
            filters=to_payload(filters),
            query_dimensions=query_dimensions,
        )
        resp = await self._transport.request(
            "POST", _paths.vector_knn(self._db), json_body=body
        )
        return SearchResponse.from_dict(resp)

    async def patch_by_filter(
        self,
        *,
        filters: Union[Filter, Mapping[str, Any]],
        patch: Mapping[str, Any],
        return_affected_ids: bool = False,
        allow_partial: bool = False,
        idempotency_key: Optional[str] = None,
    ) -> AffectedIdsResponse:
        payload = to_payload(filters)
        if payload is None:
            raise ValueError("filters cannot be None for patch_by_filter")
        body = _paths.patch_by_filter_body(
            filters=payload,
            patch=patch,
            return_affected_ids=return_affected_ids,
            allow_partial=allow_partial,
        )
        resp = await self._transport.request(
            "POST",
            _paths.vector_patch_by_filter(self._db),
            json_body=body,
            idempotency_key=idempotency_key,
        )
        return AffectedIdsResponse.from_dict(resp)

    async def delete_by_filter(
        self,
        *,
        filters: Union[Filter, Mapping[str, Any]],
        return_affected_ids: bool = False,
        allow_partial: bool = False,
        idempotency_key: Optional[str] = None,
    ) -> AffectedIdsResponse:
        payload = to_payload(filters)
        if payload is None:
            raise ValueError("filters cannot be None for delete_by_filter")
        body = _paths.delete_by_filter_body(
            filters=payload,
            return_affected_ids=return_affected_ids,
            allow_partial=allow_partial,
        )
        resp = await self._transport.request(
            "POST",
            _paths.vector_delete_by_filter(self._db),
            json_body=body,
            idempotency_key=idempotency_key,
        )
        return AffectedIdsResponse.from_dict(resp)

    async def aggregate(
        self,
        *,
        aggregations: Sequence[Mapping[str, Any]],
        group_by: Optional[Sequence[str]] = None,
        filters: Optional[Union[Filter, Mapping[str, Any]]] = None,
        for_each_unique: Optional[str] = None,
    ) -> AggregateResponse:
        body = _paths.aggregate_body(
            aggregations=aggregations,
            group_by=group_by,
            filters=to_payload(filters),
            for_each_unique=for_each_unique,
        )
        resp = await self._transport.request(
            "POST", _paths.vector_aggregate(self._db), json_body=body
        )
        return AggregateResponse.from_dict(resp)

    async def multi_search(
        self, queries: Sequence[Mapping[str, Any]]
    ) -> MultiSearchResponse:
        resp = await self._transport.request(
            "POST",
            _paths.vector_multi_search(self._db),
            json_body=_paths.multi_search_body(queries),
        )
        return MultiSearchResponse.from_dict(resp)

    async def delete(self, key: str) -> None:
        await self._transport.request("DELETE", _paths.vector(self._db, key))


class AsyncBM25Operations:
    def __init__(self, transport: AsyncTransport, db: str) -> None:
        self._transport = transport
        self._db = db

    async def create(self, *, name: str, schema: Mapping[str, Any]) -> Dict[str, Any]:
        return dict(
            await self._transport.request(
                "POST",
                _paths.bm25_indexes(self._db),
                json_body={"name": name, "schema": dict(schema)},
            )
        )

    async def list(self) -> List[Dict[str, Any]]:
        resp = await self._transport.request("GET", _paths.bm25_indexes(self._db))
        return list(resp.get("indexes", []) or [])

    async def describe(self, name: str) -> Dict[str, Any]:
        return dict(
            await self._transport.request("GET", _paths.bm25_index(self._db, name))
        )

    async def drop(self, name: str) -> None:
        await self._transport.request("DELETE", _paths.bm25_index(self._db, name))

    async def search(
        self, name: str, *, query: str, k: int = 10, **extra: Any
    ) -> SearchResponse:
        body = {"query": query, "k": k, **extra}
        resp = await self._transport.request(
            "POST", _paths.bm25_index_search(self._db, name), json_body=body
        )
        return SearchResponse.from_dict(resp)


class AsyncSchemaOperations:
    def __init__(self, transport: AsyncTransport, db: str) -> None:
        self._transport = transport
        self._db = db

    async def get(self) -> Dict[str, Any]:
        return dict(await self._transport.request("GET", _paths.schema(self._db)))

    async def set(self, schema: Mapping[str, Any]) -> Dict[str, Any]:
        return dict(
            await self._transport.request(
                "PUT", _paths.schema(self._db), json_body={"schema": dict(schema)}
            )
        )

    async def patch(self, patch: Mapping[str, Any]) -> Dict[str, Any]:
        return dict(
            await self._transport.request(
                "PATCH", _paths.schema(self._db), json_body={"patch": dict(patch)}
            )
        )


class AsyncAdminOperations:
    def __init__(self, transport: AsyncTransport, db: str) -> None:
        self._transport = transport
        self._db = db

    async def warm_cache(
        self,
        *,
        scope: str = "namespace",
        ranges: Optional[Sequence[Mapping[str, Any]]] = None,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {"scope": scope}
        if ranges is not None:
            body["ranges"] = [dict(r) for r in ranges]
        return dict(
            await self._transport.request(
                "POST", _paths.admin_warm_cache(self._db), json_body=body
            )
        )

    async def pin(self, *, temperature: str = "hot") -> Dict[str, Any]:
        return dict(
            await self._transport.request(
                "POST",
                _paths.admin_pin(self._db),
                json_body={"temperature": temperature},
            )
        )

    async def namespace_metadata(self) -> NamespaceMetadata:
        return NamespaceMetadata.from_dict(
            await self._transport.request("GET", _paths.admin_namespace_metadata(self._db))
        )

    async def copy_from(
        self,
        *,
        source_db: str,
        filters: Optional[Union[Filter, Mapping[str, Any]]] = None,
        attributes: Optional[Sequence[str]] = None,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {"source": source_db}
        payload = to_payload(filters)
        if payload is not None:
            body["filters"] = payload
        if attributes is not None:
            body["attributes"] = list(attributes)
        return dict(
            await self._transport.request(
                "POST", _paths.admin_copy_from(self._db), json_body=body
            )
        )


class AsyncSqlOperations:
    def __init__(self, transport: AsyncTransport, db: str) -> None:
        self._transport = transport
        self._db = db

    async def execute(
        self,
        statement: str,
        *,
        params: Optional[Sequence[Any]] = None,
        idempotency_key: Optional[str] = None,
    ) -> SqlResponse:
        resp = await self._transport.request(
            "POST",
            _paths.sql(self._db),
            json_body=_paths.sql_body(statement, params),
            idempotency_key=idempotency_key,
        )
        return SqlResponse.from_dict(resp)
