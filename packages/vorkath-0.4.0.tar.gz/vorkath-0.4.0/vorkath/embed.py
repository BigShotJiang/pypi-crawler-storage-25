"""Embedding endpoint wrapper for the managed-search backend.

Wraps ``POST {base_url}/v1/embed`` so callers can convert text to a
vector without owning the model server.

Backend contract: see ``vorkath-backend/docs/embedding-and-rerank.md``.
SDK spec: ``docs/sdk/embed-rerank-extension.md``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Mapping, Optional, Sequence, Union

from . import _errors


@dataclass
class EmbedUsage:
    """Token-count usage block returned by the backend."""

    prompt_tokens: int = 0
    total_tokens: int = 0


@dataclass
class EmbedResult:
    """One embedded text in the response array."""

    index: int
    vector: List[float]
    dim: int


@dataclass
class EmbedResponse:
    """Decoded response from ``POST /v1/embed``."""

    model: str
    embeddings: List[EmbedResult] = field(default_factory=list)
    usage: EmbedUsage = field(default_factory=EmbedUsage)
    degraded: Optional[str] = None


def _normalize_inputs(inputs: Union[str, Sequence[str]]) -> List[str]:
    if isinstance(inputs, str):
        return [inputs]
    arr = list(inputs)
    if not arr:
        raise ValueError("embed: inputs must be a non-empty string or sequence of str")
    return arr


def _build_body(
    inputs: List[str],
    model: Optional[str],
    namespace_id: Optional[str],
) -> Dict[str, Any]:
    body: Dict[str, Any] = {"inputs": inputs}
    if model is not None:
        body["model"] = model
    if namespace_id is not None:
        body["namespace_id"] = namespace_id
    return body


def _decode_response(
    raw: Mapping[str, Any],
    headers: Mapping[str, str],
    fallback_model: Optional[str],
) -> EmbedResponse:
    items = raw.get("embeddings") or []
    embeddings: List[EmbedResult] = []
    for i, e in enumerate(items):
        vector = list(e.get("vector") or [])
        embeddings.append(
            EmbedResult(
                index=int(e.get("index", i)),
                vector=vector,
                dim=int(e.get("dim", len(vector))),
            )
        )
    usage_raw = raw.get("usage") or {}
    usage = EmbedUsage(
        prompt_tokens=int(usage_raw.get("prompt_tokens", 0)),
        total_tokens=int(usage_raw.get("total_tokens", 0)),
    )
    degraded = headers.get("x-vorkath-degraded")
    if degraded not in ("embed-down", "rerank-down"):
        degraded = None
    return EmbedResponse(
        model=str(raw.get("model") or fallback_model or ""),
        embeddings=embeddings,
        usage=usage,
        degraded=degraded,
    )


def _maybe_remap_rate_limit(exc: BaseException) -> None:
    """Convert generic 429 errors to the managed-search-specific class."""
    if isinstance(exc, _errors.RateLimitError) and not isinstance(
        exc, _errors.VorkathRateLimitError
    ):
        raise _errors.VorkathRateLimitError(
            exc.message,
            status_code=exc.status_code,
            request_id=exc.request_id,
            server_message=exc.server_message,
            body=exc.body,
            headers=exc.headers,
        ) from exc


def embed_request(
    transport: Any,
    inputs: Union[str, Sequence[str]],
    *,
    model: Optional[str] = None,
    namespace_id: Optional[str] = None,
    timeout: Optional[float] = None,
) -> EmbedResponse:
    """Issue a synchronous ``POST /v1/embed`` call."""
    arr = _normalize_inputs(inputs)
    body = _build_body(arr, model, namespace_id)
    try:
        raw, headers, _status = transport.request_raw(
            "POST",
            "/v1/embed",
            json_body=body,
            timeout=timeout,
            endpoint="backend",
        )
    except BaseException as exc:
        _maybe_remap_rate_limit(exc)
        raise
    return _decode_response(raw or {}, headers or {}, model)


async def embed_request_async(
    transport: Any,
    inputs: Union[str, Sequence[str]],
    *,
    model: Optional[str] = None,
    namespace_id: Optional[str] = None,
    timeout: Optional[float] = None,
) -> EmbedResponse:
    """Issue an asynchronous ``POST /v1/embed`` call."""
    arr = _normalize_inputs(inputs)
    body = _build_body(arr, model, namespace_id)
    try:
        raw, headers, _status = await transport.request_raw(
            "POST",
            "/v1/embed",
            json_body=body,
            timeout=timeout,
            endpoint="backend",
        )
    except BaseException as exc:
        _maybe_remap_rate_limit(exc)
        raise
    return _decode_response(raw or {}, headers or {}, model)


__all__ = [
    "EmbedResult",
    "EmbedResponse",
    "EmbedUsage",
    "embed_request",
    "embed_request_async",
]
