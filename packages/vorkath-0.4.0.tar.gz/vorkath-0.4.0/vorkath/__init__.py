"""Official Python SDK for Vorkath.

Quick start (sync)::

    import vorkath
    from vorkath import filters as f

    with vorkath.Client.from_env() as client:
        client.databases.create(name="docs", dimensions=64, metric="l2")
        client.vectors("docs").insert(key="d1", vector=[0.1] * 64)
        hits = client.vectors("docs").search(
            vector=[0.1] * 64,
            k=5,
            filters=f.Eq("source", "wiki") & f.In("lang", ["en", "de"]),
        )

Quick start (async)::

    import asyncio
    import vorkath

    async def main():
        async with vorkath.AsyncClient.from_env() as client:
            await client.databases.create(name="docs", dimensions=64)
            hits = await client.vectors("docs").search(vector=[0.1] * 64, k=5)
            for hit in hits.results:
                print(hit.key, hit.distance)

    asyncio.run(main())

Configuration env vars: ``VORKATH_BASE_URL``, ``VORKATH_API_KEY``,
``VORKATH_TIMEOUT``.
"""

from __future__ import annotations

__version__ = "0.4.0"

from . import filters, rank, tokenizer  # noqa: F401
from .embed import EmbedResponse, EmbedResult, EmbedUsage, embed_request, embed_request_async
from .rerank import RerankResponse, RerankResult, rerank_request, rerank_request_async
from .search import AsyncSearch, Search, SearchTextResponse, SearchTextResult
from .async_client import (
    AsyncAdminOperations,
    AsyncBM25Operations,
    AsyncClient,
    AsyncDatabase,
    AsyncDatabaseOperations,
    AsyncSchemaOperations,
    AsyncSqlOperations,
    AsyncVectorOperations,
)
from .client import (
    AdminOperations,
    BM25Operations,
    Client,
    Database,
    DatabaseOperations,
    SchemaOperations,
    SqlOperations,
    VectorOperations,
)
from .types import (
    AffectedIdsResponse,
    AggregateBucket,
    AggregateResponse,
    APIConnectionError,
    APIStatusError,
    APITimeoutError,
    AuthenticationError,
    BadRequestError,
    ConflictError,
    DatabaseInfo,
    DeadlineExceededError,
    InsertResponse,
    InternalServerError,
    MultiSearchResponse,
    NamespaceMetadata,
    NotFoundError,
    NotImplementedAPIError,
    PermissionDeniedError,
    PreconditionFailedError,
    RateLimitError,
    SearchResponse,
    SearchResult,
    ServerInfo,
    Snapshot,
    SqlResponse,
    SqlRow,
    VorkathError,
    VorkathRateLimitError,
    VorkathServiceUnavailableError,
    VorkathTimeoutError,
)

__all__ = [
    "__version__",
    "filters",
    "rank",
    "tokenizer",
    # Sync surface
    "Client",
    "DatabaseOperations",
    "Database",
    "VectorOperations",
    "BM25Operations",
    "SqlOperations",
    "AdminOperations",
    "SchemaOperations",
    # Async surface
    "AsyncClient",
    "AsyncDatabaseOperations",
    "AsyncDatabase",
    "AsyncVectorOperations",
    "AsyncBM25Operations",
    "AsyncSqlOperations",
    "AsyncAdminOperations",
    "AsyncSchemaOperations",
    # Response types
    "DatabaseInfo",
    "SearchResult",
    "SearchResponse",
    "MultiSearchResponse",
    "InsertResponse",
    "AffectedIdsResponse",
    "AggregateBucket",
    "AggregateResponse",
    "NamespaceMetadata",
    "SqlRow",
    "SqlResponse",
    "Snapshot",
    "ServerInfo",
    # Error hierarchy
    "VorkathError",
    "APIConnectionError",
    "APITimeoutError",
    "APIStatusError",
    "BadRequestError",
    "AuthenticationError",
    "PermissionDeniedError",
    "NotFoundError",
    "ConflictError",
    "PreconditionFailedError",
    "RateLimitError",
    "NotImplementedAPIError",
    "DeadlineExceededError",
    "InternalServerError",
    "VorkathRateLimitError",
    "VorkathServiceUnavailableError",
    "VorkathTimeoutError",
    # Managed-search types
    "EmbedResponse",
    "EmbedResult",
    "EmbedUsage",
    "embed_request",
    "embed_request_async",
    "RerankResponse",
    "RerankResult",
    "rerank_request",
    "rerank_request_async",
    "Search",
    "AsyncSearch",
    "SearchTextResponse",
    "SearchTextResult",
]
