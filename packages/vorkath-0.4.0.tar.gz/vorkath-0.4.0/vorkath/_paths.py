"""URL path + request body builders.

Pure functions shared by the sync and async clients so the wire
shape stays in one place.
"""

from __future__ import annotations

from typing import Any, Dict, List, Mapping, Optional, Sequence
from urllib.parse import quote


def _q(value: str) -> str:
    return quote(value, safe="")


def databases() -> str:
    return "/v1/databases"


def database(db: str) -> str:
    return f"/v1/databases/{_q(db)}"


def vectors(db: str) -> str:
    return f"/v1/databases/{_q(db)}/vectors"


def vector(db: str, key: str) -> str:
    return f"/v1/databases/{_q(db)}/vectors/{_q(key)}"


def vector_search(db: str) -> str:
    return f"/v1/databases/{_q(db)}/vectors/search"


def vector_multi_search(db: str) -> str:
    return f"/v1/databases/{_q(db)}/vectors/multi-search"


def vector_knn(db: str) -> str:
    return f"/v1/databases/{_q(db)}/vectors/knn"


def vector_patch_by_filter(db: str) -> str:
    return f"/v1/databases/{_q(db)}/vectors/patch-by-filter"


def vector_delete_by_filter(db: str) -> str:
    return f"/v1/databases/{_q(db)}/vectors/delete-by-filter"


def vector_aggregate(db: str) -> str:
    return f"/v1/databases/{_q(db)}/vectors/aggregate"


def vector_upsert_batch(db: str) -> str:
    return f"/v1/databases/{_q(db)}/vectors/batch"


def schema(db: str) -> str:
    return f"/v1/databases/{_q(db)}/schema"


def admin_warm_cache(db: str) -> str:
    return f"/v1/databases/{_q(db)}/admin/warm-cache"


def admin_pin(db: str) -> str:
    return f"/v1/databases/{_q(db)}/admin/pin"


def admin_namespace_metadata(db: str) -> str:
    return f"/v1/databases/{_q(db)}/admin/metadata"


def admin_copy_from(db: str) -> str:
    return f"/v1/databases/{_q(db)}/admin/copy-from"


def bm25_indexes(db: str) -> str:
    return f"/v1/databases/{_q(db)}/bm25-indexes"


def bm25_index(db: str, name: str) -> str:
    return f"/v1/databases/{_q(db)}/bm25-indexes/{_q(name)}"


def bm25_index_search(db: str, name: str) -> str:
    return f"/v1/databases/{_q(db)}/bm25-indexes/{_q(name)}/search"


def sql(db: str) -> str:
    return f"/v1/databases/{_q(db)}/sql"


def snapshot(db: str) -> str:
    return f"/v1/databases/{_q(db)}/snapshot"


def restore(db: str) -> str:
    return f"/v1/databases/{_q(db)}/restore"


def create_database_body(
    *,
    name: str,
    dimensions: int = 0,
    metric: str = "l2",
    capabilities: Optional[Sequence[str]] = None,
    shard_group: Optional[str] = None,
    qps_limit: Optional[int] = None,
    storage_bytes_limit: Optional[int] = None,
    oltp_schema: Optional[Mapping[str, Any]] = None,
) -> Dict[str, Any]:
    body: Dict[str, Any] = {
        "name": name,
        "dimensions": dimensions,
        "metric": metric,
    }
    if capabilities is not None:
        body["capabilities"] = list(capabilities)
    if shard_group is not None:
        body["shard_group"] = shard_group
    if qps_limit is not None:
        body["qps_limit"] = qps_limit
    if storage_bytes_limit is not None:
        body["storage_bytes_limit"] = storage_bytes_limit
    if oltp_schema is not None:
        body["oltp_schema"] = dict(oltp_schema)
    return body


def insert_vector_body(
    *,
    key: str,
    vector: Sequence[float],
    metadata: Optional[Mapping[str, str]] = None,
    text: Optional[str] = None,
    title: Optional[str] = None,
    return_affected_ids: bool = False,
) -> Dict[str, Any]:
    body: Dict[str, Any] = {"key": key, "vector": list(vector)}
    if metadata:
        body["metadata"] = dict(metadata)
    if text is not None:
        body["text"] = text
    if title is not None:
        body["title"] = title
    if return_affected_ids:
        body["return_affected_ids"] = True
    return body


def upsert_batch_body(
    rows: Sequence[Mapping[str, Any]],
    *,
    return_affected_ids: bool = False,
    allow_partial: bool = False,
    disable_backpressure: bool = False,
    schema: Optional[Mapping[str, Any]] = None,
) -> Dict[str, Any]:
    body: Dict[str, Any] = {"upsert_rows": [dict(r) for r in rows]}
    if return_affected_ids:
        body["return_affected_ids"] = True
    if allow_partial:
        body["allow_partial"] = True
    if disable_backpressure:
        body["disable_backpressure"] = True
    if schema is not None:
        body["schema"] = dict(schema)
    return body


def knn_body(
    *,
    vector: Sequence[float],
    k: int,
    filters: Optional[Mapping[str, Any]] = None,
    query_dimensions: Optional[int] = None,
) -> Dict[str, Any]:
    body: Dict[str, Any] = {"vector": list(vector), "k": k}
    if filters is not None:
        body["filters"] = dict(filters)
    if query_dimensions is not None:
        body["query_dimensions"] = query_dimensions
    return body


def patch_by_filter_body(
    *,
    filters: Mapping[str, Any],
    patch: Mapping[str, Any],
    return_affected_ids: bool = False,
    allow_partial: bool = False,
) -> Dict[str, Any]:
    body: Dict[str, Any] = {"filters": dict(filters), "patch": dict(patch)}
    if return_affected_ids:
        body["return_affected_ids"] = True
    if allow_partial:
        body["allow_partial"] = True
    return body


def delete_by_filter_body(
    *,
    filters: Mapping[str, Any],
    return_affected_ids: bool = False,
    allow_partial: bool = False,
) -> Dict[str, Any]:
    body: Dict[str, Any] = {"filters": dict(filters)}
    if return_affected_ids:
        body["return_affected_ids"] = True
    if allow_partial:
        body["allow_partial"] = True
    return body


def aggregate_body(
    *,
    aggregations: Sequence[Mapping[str, Any]],
    group_by: Optional[Sequence[str]] = None,
    filters: Optional[Mapping[str, Any]] = None,
    for_each_unique: Optional[str] = None,
) -> Dict[str, Any]:
    body: Dict[str, Any] = {"aggregations": [dict(a) for a in aggregations]}
    if group_by is not None:
        body["group_by"] = list(group_by)
    if filters is not None:
        body["filters"] = dict(filters)
    if for_each_unique is not None:
        body["for_each_unique"] = for_each_unique
    return body


def cas_headers(
    *,
    if_match: Optional[str] = None,
    if_none_match: Optional[str] = None,
    expected_version: Optional[int] = None,
) -> Dict[str, str]:
    """Translate CAS preconditions into HTTP headers."""
    headers: Dict[str, str] = {}
    if if_match is not None:
        headers["If-Match"] = if_match
    if if_none_match is not None:
        headers["If-None-Match"] = if_none_match
    if expected_version is not None:
        headers["X-Vorkath-Expected-Version"] = str(expected_version)
    return headers


def search_vector_body(
    *,
    vector: Sequence[float],
    k: int = 10,
    n_probe: Optional[int] = None,
    query_dimensions: Optional[int] = None,
    text_query: Optional[str] = None,
    search_mode: str = "vector",
    filters: Optional[Mapping[str, Any]] = None,
    consistency: Optional[str] = None,
    last_as_prefix: bool = False,
    rank: Optional[Mapping[str, Any]] = None,
    limit_per: Optional[Mapping[str, Any]] = None,
    page_token: Optional[str] = None,
) -> Dict[str, Any]:
    body: Dict[str, Any] = {
        "vector": list(vector),
        "k": k,
        "search_mode": search_mode,
    }
    if n_probe is not None:
        body["n_probe"] = n_probe
    if query_dimensions is not None:
        body["query_dimensions"] = query_dimensions
    if text_query is not None:
        body["text_query"] = text_query
    if filters is not None:
        body["filters"] = dict(filters)
    if consistency is not None:
        body["consistency"] = consistency
    if last_as_prefix:
        body["last_as_prefix"] = True
    if rank is not None:
        body["rank"] = dict(rank)
    if limit_per is not None:
        body["limit_per"] = dict(limit_per)
    if page_token is not None:
        body["page_token"] = page_token
    return body


def multi_search_body(queries: Sequence[Mapping[str, Any]]) -> Dict[str, Any]:
    return {"queries": [dict(q) for q in queries]}


def sql_body(
    statement: str, params: Optional[Sequence[Any]] = None
) -> Dict[str, Any]:
    body: Dict[str, Any] = {"statement": statement}
    if params is not None:
        body["params"] = list(params)
    return body


def snapshot_body(tag: str) -> Dict[str, str]:
    return {"tag": tag}
