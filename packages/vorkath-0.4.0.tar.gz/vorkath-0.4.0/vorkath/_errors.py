"""Exception hierarchy for the Vorkath SDK.

Catch `VorkathError` to handle anything raised by the SDK. Catch a
subclass to react to a specific HTTP status (e.g. `RateLimitError`
to back off, `NotFoundError` to create-if-missing).

Every exception preserves:
- `status_code`: the HTTP status (0 for connection / timeout errors).
- `message`: short human-readable summary.
- `request_id`: server-issued ID for log correlation, when present.
- `server_message`: full server error string, when present.
- `body`: raw response body when JSON parsing failed.
- `headers`: response headers as a dict, when present.
"""

from __future__ import annotations

from typing import Any, Dict, Optional


class VorkathError(Exception):
    """Base class for every error raised by the Vorkath SDK."""

    status_code: int = 0
    message: str = ""
    request_id: Optional[str] = None
    server_message: Optional[str] = None
    body: Optional[str] = None
    headers: Optional[Dict[str, str]] = None

    def __init__(
        self,
        message: str,
        *,
        status_code: int = 0,
        request_id: Optional[str] = None,
        server_message: Optional[str] = None,
        body: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> None:
        super().__init__(self._format(message, status_code, request_id))
        self.status_code = status_code
        self.message = message
        self.request_id = request_id
        self.server_message = server_message
        self.body = body
        self.headers = headers

    @staticmethod
    def _format(message: str, status: int, request_id: Optional[str]) -> str:
        prefix = f"Vorkath API error {status}" if status else "Vorkath SDK error"
        suffix = f" [request_id={request_id}]" if request_id else ""
        return f"{prefix}: {message}{suffix}"


class APIConnectionError(VorkathError):
    """Network or transport failure before a response was received."""


class APITimeoutError(APIConnectionError):
    """Request timed out before completion."""


class VorkathTimeoutError(APITimeoutError):
    """Per-request timeout on a managed-search endpoint.

    Subclass of :class:`APITimeoutError` so legacy ``except
    APITimeoutError`` blocks still match. The new name lets callers
    react specifically to managed-search timeouts.
    """


class APIStatusError(VorkathError):
    """Base class for any non-2xx HTTP response."""


class BadRequestError(APIStatusError):
    """HTTP 400. Malformed request, validation error."""


class AuthenticationError(APIStatusError):
    """HTTP 401. Missing or invalid API key."""


class PermissionDeniedError(APIStatusError):
    """HTTP 403. API key valid but lacks the required scope."""


class NotFoundError(APIStatusError):
    """HTTP 404. Resource does not exist."""


class ConflictError(APIStatusError):
    """HTTP 409. Conflict (e.g. database name already exists)."""


class PreconditionFailedError(APIStatusError):
    """HTTP 412. Required capability missing, CAS expectation failed."""


class RateLimitError(APIStatusError):
    """HTTP 429. Per-database QPS limit reached."""


class VorkathRateLimitError(RateLimitError):
    """HTTP 429 from a managed-search endpoint.

    Subclass of :class:`RateLimitError` so legacy handlers still
    match. The new name lets callers distinguish managed-search
    rate limits from per-database QPS limits.
    """


class NotImplementedAPIError(APIStatusError):
    """HTTP 501. Feature not implemented on the server yet."""


class DeadlineExceededError(APIStatusError):
    """HTTP 504. Server-side deadline exceeded."""


class InternalServerError(APIStatusError):
    """HTTP 5xx. Server failure; retry may succeed."""


class VorkathServiceUnavailableError(APIStatusError):
    """HTTP 503 raised when the backend's circuit breaker is open.

    Surfaces here so callers can fall back to a cached result or an
    alternate retrieval path.
    """


_STATUS_MAP: Dict[int, type] = {
    400: BadRequestError,
    401: AuthenticationError,
    403: PermissionDeniedError,
    404: NotFoundError,
    409: ConflictError,
    412: PreconditionFailedError,
    429: RateLimitError,
    501: NotImplementedAPIError,
    503: VorkathServiceUnavailableError,
    504: DeadlineExceededError,
}


def from_response(
    status_code: int,
    body_json: Optional[Dict[str, Any]],
    body_text: Optional[str],
    headers: Optional[Dict[str, str]],
) -> APIStatusError:
    """Construct the most specific APIStatusError for the response."""
    server_message: Optional[str] = None
    if isinstance(body_json, dict):
        raw = body_json.get("error")
        if isinstance(raw, str):
            server_message = raw
    message = server_message or body_text or f"HTTP {status_code}"
    request_id = (headers or {}).get("x-request-id") or (headers or {}).get(
        "x-vorkath-request-id"
    )
    cls = _STATUS_MAP.get(status_code)
    if cls is None:
        cls = InternalServerError if status_code >= 500 else APIStatusError
    return cls(
        message,
        status_code=status_code,
        request_id=request_id,
        server_message=server_message,
        body=body_text,
        headers=headers,
    )
