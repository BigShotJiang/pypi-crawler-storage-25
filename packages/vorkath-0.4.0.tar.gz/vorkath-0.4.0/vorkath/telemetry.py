"""OpenTelemetry integration for the Vorkath SDK.

Drop-in helpers that wrap the SDK's pluggable transport with OTel
spans + W3C `traceparent` propagation. The SDK does not import
`opentelemetry`; if you don't call these helpers you get no extra
deps.

Example
-------

    from opentelemetry import trace
    from vorkath import Client
    from vorkath.telemetry import instrument_client

    instrument_client(Client.from_env(), tracer=trace.get_tracer("my-app"))
"""

from __future__ import annotations

from typing import Any, Optional

from .async_client import AsyncClient
from .client import Client


def instrument_client(client: Client, *, tracer: Any = None) -> Client:
    """Wrap `client._transport.request` with OTel span emission.

    The wrapper is idempotent: calling it twice on the same client
    has no double-instrumentation effect.
    """
    if getattr(client._transport, "_otel_instrumented", False):
        return client
    transport = client._transport
    original = transport.request

    def wrapped(method: str, path: str, **kwargs: Any) -> Any:
        if tracer is None:
            return original(method, path, **kwargs)
        with tracer.start_as_current_span(
            f"vorkath.{method}",
            attributes={
                "http.method": method,
                "http.url": f"{transport.config.base_url}{path}",
                "vorkath.path": path,
            },
        ):
            traceparent = _extract_traceparent()
            if traceparent:
                headers = dict(kwargs.get("headers") or {})
                headers.setdefault("traceparent", traceparent)
                kwargs["headers"] = headers
            return original(method, path, **kwargs)

    transport.request = wrapped  # type: ignore[method-assign]
    setattr(transport, "_otel_instrumented", True)
    return client


def instrument_async_client(client: AsyncClient, *, tracer: Any = None) -> AsyncClient:
    """Async variant of `instrument_client`."""
    if getattr(client._transport, "_otel_instrumented", False):
        return client
    transport = client._transport
    original = transport.request

    async def wrapped(method: str, path: str, **kwargs: Any) -> Any:
        if tracer is None:
            return await original(method, path, **kwargs)
        with tracer.start_as_current_span(
            f"vorkath.{method}",
            attributes={
                "http.method": method,
                "http.url": f"{transport.config.base_url}{path}",
                "vorkath.path": path,
            },
        ):
            traceparent = _extract_traceparent()
            if traceparent:
                headers = dict(kwargs.get("headers") or {})
                headers.setdefault("traceparent", traceparent)
                kwargs["headers"] = headers
            return await original(method, path, **kwargs)

    transport.request = wrapped  # type: ignore[method-assign]
    setattr(transport, "_otel_instrumented", True)
    return client


def _extract_traceparent() -> Optional[str]:
    """Extract a W3C `traceparent` from the current OTel context, if
    any. Returns None when OTel is not installed / no active span."""
    try:
        from opentelemetry.propagate import inject  # type: ignore
    except ImportError:
        return None
    carrier: dict[str, str] = {}
    inject(carrier)
    return carrier.get("traceparent")


__all__ = ["instrument_client", "instrument_async_client"]
