"""Reranker endpoint wrapper for the managed-search backend.

Wraps ``POST {base_url}/v1/rerank`` so callers can re-score
``(query, candidates)`` pairs with the cross-encoder.

Backend contract: see ``vorkath-backend/docs/embedding-and-rerank.md``.
SDK spec: ``docs/sdk/embed-rerank-extension.md``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Mapping, Optional, Sequence

from . import _errors
from .embed import EmbedUsage, _maybe_remap_rate_limit


@dataclass
class RerankResult:
    """One scored candidate in the rerank response."""

    index: int
    relevance_score: float
    document: Optional[str] = None


@dataclass
class RerankResponse:
    """Decoded response from ``POST /v1/rerank``."""

    model: str
    results: List[RerankResult] = field(default_factory=list)
    usage: EmbedUsage = field(default_factory=EmbedUsage)
    degraded: Optional[str] = None


def _validate(query: str, documents: Sequence[str]) -> List[str]:
    if not isinstance(query, str) or not query:
        raise ValueError("rerank: query must be a non-empty string")
    arr = list(documents)
    if not arr:
        raise ValueError("rerank: documents must be a non-empty sequence of str")
    return arr


def _build_body(
    query: str,
    documents: List[str],
    *,
    model: Optional[str],
    top_n: Optional[int],
    return_documents: bool,
) -> Dict[str, Any]:
    body: Dict[str, Any] = {
        "query": query,
        "documents": documents,
        "top_n": top_n if top_n is not None else len(documents),
        "return_documents": return_documents,
    }
    if model is not None:
        body["model"] = model
    return body


def _decode_response(
    raw: Mapping[str, Any],
    headers: Mapping[str, str],
    fallback_model: Optional[str],
) -> RerankResponse:
    items = raw.get("results") or []
    results: List[RerankResult] = []
    for i, r in enumerate(items):
        results.append(
            RerankResult(
                index=int(r.get("index", i)),
                relevance_score=float(r.get("relevance_score", 0.0)),
                document=r.get("document") if isinstance(r.get("document"), str) else None,
            )
        )
    usage_raw = raw.get("usage") or {}
    usage = EmbedUsage(
        prompt_tokens=int(usage_raw.get("prompt_tokens", 0)),
        total_tokens=int(usage_raw.get("total_tokens", 0)),
    )
    degraded = headers.get("x-vorkath-degraded")
    if degraded not in ("embed-down", "rerank-down"):
        degraded = None
    return RerankResponse(
        model=str(raw.get("model") or fallback_model or ""),
        results=results,
        usage=usage,
        degraded=degraded,
    )


def rerank_request(
    transport: Any,
    query: str,
    documents: Sequence[str],
    *,
    model: Optional[str] = None,
    top_n: Optional[int] = None,
    return_documents: bool = False,
    timeout: Optional[float] = None,
) -> RerankResponse:
    """Issue a synchronous ``POST /v1/rerank`` call."""
    docs = _validate(query, documents)
    body = _build_body(
        query,
        docs,
        model=model,
        top_n=top_n,
        return_documents=return_documents,
    )
    try:
        raw, headers, _status = transport.request_raw(
            "POST",
            "/v1/rerank",
            json_body=body,
            timeout=timeout,
            endpoint="backend",
        )
    except BaseException as exc:
        _maybe_remap_rate_limit(exc)
        raise
    return _decode_response(raw or {}, headers or {}, model)


async def rerank_request_async(
    transport: Any,
    query: str,
    documents: Sequence[str],
    *,
    model: Optional[str] = None,
    top_n: Optional[int] = None,
    return_documents: bool = False,
    timeout: Optional[float] = None,
) -> RerankResponse:
    """Issue an asynchronous ``POST /v1/rerank`` call."""
    docs = _validate(query, documents)
    body = _build_body(
        query,
        docs,
        model=model,
        top_n=top_n,
        return_documents=return_documents,
    )
    try:
        raw, headers, _status = await transport.request_raw(
            "POST",
            "/v1/rerank",
            json_body=body,
            timeout=timeout,
            endpoint="backend",
        )
    except BaseException as exc:
        _maybe_remap_rate_limit(exc)
        raise
    return _decode_response(raw or {}, headers or {}, model)


__all__ = [
    "RerankResult",
    "RerankResponse",
    "rerank_request",
    "rerank_request_async",
]
