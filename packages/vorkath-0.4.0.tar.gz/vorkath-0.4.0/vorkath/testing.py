"""Test utilities for SDK consumers.

`MockTransport` lets you inject canned responses or a route table
into a `Client` / `AsyncClient` so unit tests do not need a live
Vorkath server.

Example
-------

    import httpx, vorkath
    from vorkath.testing import build_mock_client

    client = build_mock_client({
        "GET /healthz": {"status": "ok"},
        "POST /v1/databases": {"success": True, "database": {"db_id": "x"}},
    })
    assert client.health() is True
"""

from __future__ import annotations

from typing import Any, Callable, Dict, Mapping, Optional, Union

import httpx

from .async_client import AsyncClient
from .client import Client
from ._transport import AsyncTransport, Transport, TransportConfig

Route = Union[Mapping[str, Any], Callable[[httpx.Request], httpx.Response]]


def _resolve(route: Route, request: httpx.Request) -> httpx.Response:
    if callable(route):
        return route(request)
    return httpx.Response(200, json=dict(route))


class MockRouter:
    """Maps `"METHOD /path"` keys to canned responses or handler
    callables. Unknown routes return 404."""

    def __init__(self, routes: Mapping[str, Route]) -> None:
        self.routes: Dict[str, Route] = dict(routes)
        self.calls: list[Dict[str, Any]] = []

    def __call__(self, request: httpx.Request) -> httpx.Response:
        method = request.method.upper()
        path = request.url.path
        key = f"{method} {path}"
        self.calls.append(
            {
                "method": method,
                "path": path,
                "headers": dict(request.headers),
                "content": request.content,
            }
        )
        route = self.routes.get(key)
        if route is None:
            # Allow trailing-slash variants and method wildcards.
            for k, v in self.routes.items():
                k_method, _, k_path = k.partition(" ")
                if k_method in ("*", method) and k_path == path:
                    return _resolve(v, request)
            return httpx.Response(404, json={"error": f"no mock route for {key}"})
        return _resolve(route, request)


def build_mock_client(routes: Mapping[str, Route]) -> Client:
    """Construct a `vorkath.Client` whose transport is a
    `httpx.MockTransport`. The returned client also exposes a
    `mock_router` attribute for inspecting recorded calls."""
    router = MockRouter(routes)
    cfg = TransportConfig(
        base_url="http://mock", max_retries=0, http2=False, version="0.0-test"
    )
    inner = httpx.Client(transport=httpx.MockTransport(router), base_url="http://mock")
    transport = Transport(cfg, client=inner)
    client = Client("http://mock", max_retries=0, transport=transport)
    setattr(client, "mock_router", router)
    return client


def build_async_mock_client(routes: Mapping[str, Route]) -> AsyncClient:
    """Async variant of `build_mock_client`."""
    router = MockRouter(routes)
    cfg = TransportConfig(
        base_url="http://mock", max_retries=0, http2=False, version="0.0-test"
    )
    inner = httpx.AsyncClient(transport=httpx.MockTransport(router), base_url="http://mock")
    transport = AsyncTransport(cfg, client=inner)
    client = AsyncClient("http://mock", max_retries=0, transport=transport)
    setattr(client, "mock_router", router)
    return client


__all__ = [
    "MockRouter",
    "build_mock_client",
    "build_async_mock_client",
    "Route",
]
