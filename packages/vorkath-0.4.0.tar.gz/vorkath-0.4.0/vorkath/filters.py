"""Typed filter DSL for vector / BM25 / SQL search.

Use these helpers to build filter trees that the SDK serializes to
the wire format the Vorkath router expects:

    from vorkath import filters as f

    expr = f.And(
        f.Eq("source", "wiki"),
        f.In("lang", ["en", "de"]),
        f.Or(
            f.Contains("text", "neighbor"),
            f.Glob("title", "introduction*"),
        ),
        f.Not(f.Eq("private", True)),
    )

    client.vectors("docs").search(vector=[...], filters=expr)

Every node renders to a JSON object via `to_dict()`. Pass any
`Filter` to a search call's `filters=` kwarg and the SDK calls
`to_dict()` for you.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Iterable, List, Sequence, Union

JsonValue = Union[
    str, int, float, bool, None, "list[JsonValue]", "dict[str, JsonValue]"
]


class Filter:
    """Base class for filter expressions."""

    def to_dict(self) -> "dict[str, Any]":
        raise NotImplementedError

    def __and__(self, other: "Filter") -> "Filter":
        return And(self, other)

    def __or__(self, other: "Filter") -> "Filter":
        return Or(self, other)

    def __invert__(self) -> "Filter":
        return Not(self)


def _validate_field(field: str) -> None:
    if not field or not isinstance(field, str):
        raise ValueError(f"filter field must be a non-empty string, got {field!r}")


@dataclass
class Eq(Filter):
    """Field equals a literal value."""

    field: str
    value: JsonValue

    def __post_init__(self) -> None:
        _validate_field(self.field)

    def to_dict(self) -> "dict[str, Any]":
        return {"op": "eq", "field": self.field, "value": self.value}


@dataclass
class Ne(Filter):
    """Field does not equal a literal value."""

    field: str
    value: JsonValue

    def __post_init__(self) -> None:
        _validate_field(self.field)

    def to_dict(self) -> "dict[str, Any]":
        return {"op": "ne", "field": self.field, "value": self.value}


@dataclass
class In(Filter):
    """Field equals any value in the set."""

    field: str
    values: Sequence[JsonValue]

    def __post_init__(self) -> None:
        _validate_field(self.field)

    def to_dict(self) -> "dict[str, Any]":
        return {"op": "in", "field": self.field, "values": list(self.values)}


@dataclass
class NotIn(Filter):
    """Field does not equal any value in the set."""

    field: str
    values: Sequence[JsonValue]

    def __post_init__(self) -> None:
        _validate_field(self.field)

    def to_dict(self) -> "dict[str, Any]":
        return {"op": "not_in", "field": self.field, "values": list(self.values)}


@dataclass
class Lt(Filter):
    field: str
    value: JsonValue

    def to_dict(self) -> "dict[str, Any]":
        return {"op": "lt", "field": self.field, "value": self.value}


@dataclass
class Le(Filter):
    field: str
    value: JsonValue

    def to_dict(self) -> "dict[str, Any]":
        return {"op": "le", "field": self.field, "value": self.value}


@dataclass
class Gt(Filter):
    field: str
    value: JsonValue

    def to_dict(self) -> "dict[str, Any]":
        return {"op": "gt", "field": self.field, "value": self.value}


@dataclass
class Ge(Filter):
    field: str
    value: JsonValue

    def to_dict(self) -> "dict[str, Any]":
        return {"op": "ge", "field": self.field, "value": self.value}


@dataclass
class Contains(Filter):
    """Substring match on a string field."""

    field: str
    value: str

    def to_dict(self) -> "dict[str, Any]":
        return {"op": "contains", "field": self.field, "value": self.value}


@dataclass
class ContainsAny(Filter):
    """At least one of the substrings matches."""

    field: str
    values: Sequence[str]

    def to_dict(self) -> "dict[str, Any]":
        return {"op": "contains_any", "field": self.field, "values": list(self.values)}


@dataclass
class Glob(Filter):
    """Glob pattern (`*`, `?`, `[abc]`) match on a string field."""

    field: str
    pattern: str

    def to_dict(self) -> "dict[str, Any]":
        return {"op": "glob", "field": self.field, "pattern": self.pattern}


@dataclass
class Regex(Filter):
    """Regex match on a string field. Validated client-side."""

    field: str
    pattern: str

    def __post_init__(self) -> None:
        try:
            re.compile(self.pattern)
        except re.error as e:
            raise ValueError(f"invalid regex {self.pattern!r}: {e}") from e

    def to_dict(self) -> "dict[str, Any]":
        return {"op": "regex", "field": self.field, "pattern": self.pattern}


@dataclass
class Exists(Filter):
    """Field is present (not null)."""

    field: str

    def to_dict(self) -> "dict[str, Any]":
        return {"op": "exists", "field": self.field}


class And(Filter):
    """Conjunction. Empty `And()` is the always-true filter."""

    def __init__(self, *children: Filter) -> None:
        self.children: List[Filter] = list(children)

    def to_dict(self) -> "dict[str, Any]":
        return {"op": "and", "children": [c.to_dict() for c in self.children]}


class Or(Filter):
    """Disjunction. Empty `Or()` is the always-false filter."""

    def __init__(self, *children: Filter) -> None:
        self.children: List[Filter] = list(children)

    def to_dict(self) -> "dict[str, Any]":
        return {"op": "or", "children": [c.to_dict() for c in self.children]}


@dataclass
class Not(Filter):
    """Negation of a single child filter."""

    child: Filter

    def to_dict(self) -> "dict[str, Any]":
        return {"op": "not", "child": self.child.to_dict()}


def to_payload(filter_: Union[Filter, "dict[str, Any]", None]) -> Union["dict[str, Any]", None]:
    """Coerce a filter or raw dict into the JSON payload."""
    if filter_ is None:
        return None
    if isinstance(filter_, Filter):
        return filter_.to_dict()
    return dict(filter_)


__all__ = [
    "Filter",
    "Eq",
    "Ne",
    "In",
    "NotIn",
    "Lt",
    "Le",
    "Gt",
    "Ge",
    "Contains",
    "ContainsAny",
    "Glob",
    "Regex",
    "Exists",
    "And",
    "Or",
    "Not",
    "to_payload",
]
