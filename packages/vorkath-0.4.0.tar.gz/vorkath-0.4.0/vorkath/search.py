"""Managed-search endpoint wrapper for the backend.

Wraps ``POST {base_url}/v1/search``.  The backend embeds the query,
runs hybrid retrieval against vorkath core, optionally reranks, and
returns a final ranked list. This is the canonical entry point for
managed callers.

Backend contract: see ``vorkath-backend/docs/embedding-and-rerank.md``.
SDK spec: ``docs/sdk/embed-rerank-extension.md``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Mapping, Optional

from .embed import _maybe_remap_rate_limit


@dataclass
class SearchTextResult:
    """One row in :class:`SearchTextResponse`."""

    id: str
    score: float
    metadata: Optional[Dict[str, Any]] = None
    rerank_score: Optional[float] = None
    retrieval_score: Optional[float] = None


@dataclass
class SearchTextResponse:
    """Decoded response from ``POST /v1/search``."""

    results: List[SearchTextResult] = field(default_factory=list)
    k: int = 0
    rerank_applied: bool = False
    embed_ms: float = 0.0
    retrieve_ms: float = 0.0
    rerank_ms: float = 0.0
    total_ms: float = 0.0
    degraded: Optional[str] = None


def _build_body(
    namespace_id: str,
    query: str,
    *,
    k: int,
    mode: str,
    rerank: bool,
    rerank_top_n: int,
    filters: Optional[Mapping[str, Any]],
    return_metadata: bool,
    rank_by: Optional[Mapping[str, Any]],
) -> Dict[str, Any]:
    body: Dict[str, Any] = {
        "namespace_id": namespace_id,
        "query": query,
        "mode": mode,
        "k": k,
        "rerank": rerank,
        "rerank_top_n": rerank_top_n,
        "return_metadata": return_metadata,
    }
    if filters is not None:
        body["filters"] = dict(filters)
    if rank_by is not None:
        body["rank_by"] = dict(rank_by)
    return body


def _decode_response(
    raw: Mapping[str, Any], headers: Mapping[str, str], fallback_k: int
) -> SearchTextResponse:
    items = raw.get("results") or []
    results: List[SearchTextResult] = []
    for r in items:
        results.append(
            SearchTextResult(
                id=str(r.get("id", "")),
                score=float(r.get("score", 0.0)),
                metadata=dict(r["metadata"]) if isinstance(r.get("metadata"), Mapping) else None,
                rerank_score=float(r["rerank_score"]) if "rerank_score" in r else None,
                retrieval_score=float(r["retrieval_score"]) if "retrieval_score" in r else None,
            )
        )
    degraded = headers.get("x-vorkath-degraded")
    if degraded not in ("embed-down", "rerank-down"):
        degraded = None
    return SearchTextResponse(
        results=results,
        k=int(raw.get("k", fallback_k)),
        rerank_applied=bool(raw.get("rerank_applied", False)),
        embed_ms=float(raw.get("embed_ms", 0.0)),
        retrieve_ms=float(raw.get("retrieve_ms", 0.0)),
        rerank_ms=float(raw.get("rerank_ms", 0.0)),
        total_ms=float(raw.get("total_ms", 0.0)),
        degraded=degraded,
    )


def _validate(namespace_id: str, query: str) -> None:
    if not isinstance(namespace_id, str) or not namespace_id:
        raise ValueError("search.text: namespace_id must be a non-empty string")
    if not isinstance(query, str) or not query:
        raise ValueError("search.text: query must be a non-empty string")


class Search:
    """Search namespace exposed via ``client.search``.

    Currently holds the :meth:`text` method; future search-related
    calls (e.g. ``by_vector``, ``by_image``) will land here.
    """

    def __init__(self, transport: Any) -> None:
        self._transport = transport

    def text(
        self,
        namespace_id: str,
        query: str,
        *,
        k: int = 20,
        mode: str = "hybrid",
        rerank: bool = True,
        rerank_top_n: int = 50,
        filters: Optional[Mapping[str, Any]] = None,
        return_metadata: bool = True,
        rank_by: Optional[Mapping[str, Any]] = None,
        timeout: Optional[float] = None,
    ) -> SearchTextResponse:
        """Issue a synchronous ``POST /v1/search`` call."""
        _validate(namespace_id, query)
        body = _build_body(
            namespace_id,
            query,
            k=k,
            mode=mode,
            rerank=rerank,
            rerank_top_n=rerank_top_n,
            filters=filters,
            return_metadata=return_metadata,
            rank_by=rank_by,
        )
        try:
            raw, headers, _status = self._transport.request_raw(
                "POST",
                "/v1/search",
                json_body=body,
                timeout=timeout,
                endpoint="backend",
            )
        except BaseException as exc:
            _maybe_remap_rate_limit(exc)
            raise
        return _decode_response(raw or {}, headers or {}, fallback_k=k)


class AsyncSearch:
    """Async equivalent of :class:`Search`."""

    def __init__(self, transport: Any) -> None:
        self._transport = transport

    async def text(
        self,
        namespace_id: str,
        query: str,
        *,
        k: int = 20,
        mode: str = "hybrid",
        rerank: bool = True,
        rerank_top_n: int = 50,
        filters: Optional[Mapping[str, Any]] = None,
        return_metadata: bool = True,
        rank_by: Optional[Mapping[str, Any]] = None,
        timeout: Optional[float] = None,
    ) -> SearchTextResponse:
        """Issue an asynchronous ``POST /v1/search`` call."""
        _validate(namespace_id, query)
        body = _build_body(
            namespace_id,
            query,
            k=k,
            mode=mode,
            rerank=rerank,
            rerank_top_n=rerank_top_n,
            filters=filters,
            return_metadata=return_metadata,
            rank_by=rank_by,
        )
        try:
            raw, headers, _status = await self._transport.request_raw(
                "POST",
                "/v1/search",
                json_body=body,
                timeout=timeout,
                endpoint="backend",
            )
        except BaseException as exc:
            _maybe_remap_rate_limit(exc)
            raise
        return _decode_response(raw or {}, headers or {}, fallback_k=k)


__all__ = [
    "Search",
    "AsyncSearch",
    "SearchTextResult",
    "SearchTextResponse",
]
