"""Typed responses for the Vorkath SDK.

Every public method on `Client` / `AsyncClient` returns a dataclass
in this module. We pass through unknown response keys (kept on
`extra`) so a server upgrade does not immediately break the client.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Mapping, Optional


def _opt_str(value: Any) -> Optional[str]:
    return value if isinstance(value, str) else None


def _opt_int(value: Any) -> Optional[int]:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float) and float(value).is_integer():
        return int(value)
    return None


@dataclass
class DatabaseInfo:
    """Metadata about a database. Returned by create / list / describe."""

    db_id: str
    dimensions: int
    metric: str
    capabilities: List[Any] = field(default_factory=list)
    shard_group: str = ""
    created_at: int = 0
    qps_limit: Optional[int] = None
    storage_bytes_limit: Optional[int] = None
    extra: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "DatabaseInfo":
        known = {
            "db_id",
            "dimensions",
            "metric",
            "capabilities",
            "shard_group",
            "created_at",
            "qps_limit",
            "storage_bytes_limit",
        }
        extra = {k: v for k, v in data.items() if k not in known}
        return cls(
            db_id=str(data.get("db_id", "")),
            dimensions=int(data.get("dimensions", 0)),
            metric=str(data.get("metric", "")),
            capabilities=list(data.get("capabilities", [])),
            shard_group=str(data.get("shard_group", "")),
            created_at=int(data.get("created_at", 0)),
            qps_limit=_opt_int(data.get("qps_limit")),
            storage_bytes_limit=_opt_int(data.get("storage_bytes_limit")),
            extra=extra,
        )


@dataclass
class SearchResult:
    """One hit in a vector or BM25 search response."""

    key: str
    distance: float
    metadata: Dict[str, Any] = field(default_factory=dict)
    score: Optional[float] = None

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "SearchResult":
        return cls(
            key=str(data.get("key", "")),
            distance=float(data.get("distance", 0.0)),
            metadata=dict(data.get("metadata", {}) or {}),
            score=float(data["score"]) if "score" in data else None,
        )


@dataclass
class SearchResponse:
    """Response from `vectors(...).search(...)`."""

    results: List[SearchResult]
    total_time_ms: float = 0.0
    shards_queried: int = 0
    last_included_write_at: Optional[int] = None
    extra: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "SearchResponse":
        known = {"results", "total_time_ms", "shards_queried", "last_included_write_at"}
        extra = {k: v for k, v in data.items() if k not in known}
        results_data = data.get("results", []) or []
        return cls(
            results=[SearchResult.from_dict(r) for r in results_data],
            total_time_ms=float(data.get("total_time_ms", 0.0)),
            shards_queried=int(data.get("shards_queried", 0)),
            last_included_write_at=_opt_int(data.get("last_included_write_at")),
            extra=extra,
        )

    def summary(self) -> str:
        return (
            f"SearchResponse(hits={len(self.results)}, "
            f"time={self.total_time_ms:.1f}ms, "
            f"shards={self.shards_queried})"
        )

    def _repr_pretty_(self, p: Any, cycle: bool) -> None:
        """IPython rich repr."""
        if cycle:
            p.text(self.summary())
            return
        with p.group(2, self.summary() + " {", "}"):
            for r in self.results[:5]:
                p.breakable()
                p.text(f"{r.key}: {r.distance:.4f}")
            if len(self.results) > 5:
                p.breakable()
                p.text(f"... ({len(self.results) - 5} more)")


@dataclass
class MultiSearchResponse:
    """Response from `vectors(...).multi_search([...])`."""

    responses: List[SearchResponse]

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "MultiSearchResponse":
        raw = data.get("responses") or data.get("results") or []
        return cls(responses=[SearchResponse.from_dict(r) for r in raw])


@dataclass
class InsertResponse:
    """Response from `vectors(...).insert(...)`."""

    success: bool
    shard_id: int = 0
    error: str = ""
    affected_ids: List[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "InsertResponse":
        return cls(
            success=bool(data.get("success", True)),
            shard_id=int(data.get("shard_id", 0)),
            error=str(data.get("error", "") or ""),
            affected_ids=list(data.get("affected_ids", []) or []),
        )


@dataclass
class SqlRow:
    """One row in a SQL response. `columns` maps name -> JSON value."""

    columns: Dict[str, Any]


@dataclass
class SqlResponse:
    """Response from `sql(...).execute(...)`."""

    rows: List[SqlRow]
    row_count: int

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "SqlResponse":
        rows = [SqlRow(columns=dict(r)) for r in data.get("rows", []) or []]
        return cls(rows=rows, row_count=int(data.get("row_count", len(rows))))


@dataclass
class Snapshot:
    """Reference to a snapshot. Returned by `database(...).snapshot(...)`."""

    tag: str
    db_id: str
    paths: List[str] = field(default_factory=list)


@dataclass
class AffectedIdsResponse:
    """Response from `patch_by_filter` / `delete_by_filter` /
    bulk-mutating ops with `return_affected_ids=True`."""

    affected_ids: List[str]
    affected_count: int = 0
    extra: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "AffectedIdsResponse":
        ids = list(data.get("affected_ids", []) or [])
        known = {"affected_ids", "affected_count"}
        extra = {k: v for k, v in data.items() if k not in known}
        return cls(
            affected_ids=ids,
            affected_count=int(data.get("affected_count", len(ids))),
            extra=extra,
        )


@dataclass
class AggregateBucket:
    """One bucket in an aggregation response."""

    key: Dict[str, Any]
    values: Dict[str, Any]


@dataclass
class AggregateResponse:
    """Response from `vectors(...).aggregate(...)`."""

    buckets: List[AggregateBucket]
    extra: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "AggregateResponse":
        raw = data.get("buckets") or []
        buckets = [
            AggregateBucket(
                key=dict(b.get("key", {}) or {}),
                values=dict(b.get("values", {}) or {}),
            )
            for b in raw
        ]
        known = {"buckets"}
        extra = {k: v for k, v in data.items() if k not in known}
        return cls(buckets=buckets, extra=extra)


@dataclass
class NamespaceMetadata:
    """Response from `admin.namespace_metadata(db)`."""

    db_id: str
    row_count: int = 0
    bytes_on_disk: int = 0
    last_write_at: Optional[int] = None
    schema: Dict[str, Any] = field(default_factory=dict)
    extra: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "NamespaceMetadata":
        known = {"db_id", "row_count", "bytes_on_disk", "last_write_at", "schema"}
        extra = {k: v for k, v in data.items() if k not in known}
        return cls(
            db_id=str(data.get("db_id", "")),
            row_count=int(data.get("row_count", 0)),
            bytes_on_disk=int(data.get("bytes_on_disk", 0)),
            last_write_at=_opt_int(data.get("last_write_at")),
            schema=dict(data.get("schema", {}) or {}),
            extra=extra,
        )


@dataclass
class ServerInfo:
    """Response from `info()`."""

    service: str
    version: str
    capabilities: List[str]
    api_version: str
    extra: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "ServerInfo":
        known = {"service", "version", "capabilities", "api_version"}
        extra = {k: v for k, v in data.items() if k not in known}
        return cls(
            service=str(data.get("service", "")),
            version=str(data.get("version", "")),
            capabilities=[str(c) for c in (data.get("capabilities") or [])],
            api_version=str(data.get("api_version", "")),
            extra=extra,
        )


# Re-export the error hierarchy for backwards-compatible imports
# (``from vorkath.types import VorkathError``).
from ._errors import (  # noqa: E402
    APIConnectionError,
    APIStatusError,
    APITimeoutError,
    AuthenticationError,
    BadRequestError,
    ConflictError,
    DeadlineExceededError,
    InternalServerError,
    NotFoundError,
    NotImplementedAPIError,
    PermissionDeniedError,
    PreconditionFailedError,
    RateLimitError,
    VorkathError,
    VorkathRateLimitError,
    VorkathServiceUnavailableError,
    VorkathTimeoutError,
)

__all__ = [
    "DatabaseInfo",
    "SearchResult",
    "SearchResponse",
    "MultiSearchResponse",
    "InsertResponse",
    "AffectedIdsResponse",
    "AggregateBucket",
    "AggregateResponse",
    "NamespaceMetadata",
    "SqlRow",
    "SqlResponse",
    "Snapshot",
    "ServerInfo",
    "VorkathError",
    "APIConnectionError",
    "APITimeoutError",
    "APIStatusError",
    "BadRequestError",
    "AuthenticationError",
    "PermissionDeniedError",
    "NotFoundError",
    "ConflictError",
    "PreconditionFailedError",
    "RateLimitError",
    "NotImplementedAPIError",
    "DeadlineExceededError",
    "InternalServerError",
    "VorkathRateLimitError",
    "VorkathServiceUnavailableError",
    "VorkathTimeoutError",
]
