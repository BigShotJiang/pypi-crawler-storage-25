"""Rank-operator builders for hybrid / re-ranking queries.

Used in conjunction with `client.vectors(db).search(rank=...)`.

Examples
--------

    from vorkath import rank

    rank_expr = rank.Sum(
        rank.Saturate(rank.field("bm25_score"), p=1.5),
        rank.Decay(rank.field("recency_days"), half_life=7),
        rank.Dist(rank.field("vector_distance"), weight=0.5),
    )

The builder produces JSON the router understands; you can also pass
a hand-written dict if you prefer.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Union

RankNode = Union["RankExpr", float, int, str, Dict[str, Any]]


def _serialize(node: RankNode) -> Any:
    if isinstance(node, RankExpr):
        return node.to_dict()
    return node


def field(name: str) -> "Field":
    """Reference a stored field as a rank input."""
    return Field(name)


class RankExpr:
    """Base class for rank operator nodes."""

    def to_dict(self) -> Dict[str, Any]:
        raise NotImplementedError

    def __add__(self, other: RankNode) -> "Sum":
        return Sum(self, other)

    def __mul__(self, other: RankNode) -> "Mul":
        return Mul(self, other)


@dataclass
class Field(RankExpr):
    name: str

    def to_dict(self) -> Dict[str, Any]:
        return {"op": "field", "name": self.name}


@dataclass
class Const(RankExpr):
    value: float

    def to_dict(self) -> Dict[str, Any]:
        return {"op": "const", "value": self.value}


@dataclass
class Saturate(RankExpr):
    """`x / (x + p)` saturation curve. Tames long tails."""

    input: RankNode
    p: float = 1.0

    def to_dict(self) -> Dict[str, Any]:
        return {"op": "saturate", "input": _serialize(self.input), "p": self.p}


@dataclass
class Decay(RankExpr):
    """Exponential decay: `exp(-x / tau)`. Set `half_life` (in input
    units) and the SDK derives tau."""

    input: RankNode
    half_life: float

    def to_dict(self) -> Dict[str, Any]:
        return {
            "op": "decay",
            "input": _serialize(self.input),
            "half_life": self.half_life,
        }


@dataclass
class Dist(RankExpr):
    """Distance-style score: `weight * (1 - x)` for a similarity
    input, `weight * x` for a distance input. Server picks the
    convention based on the field's metric."""

    input: RankNode
    weight: float = 1.0

    def to_dict(self) -> Dict[str, Any]:
        return {"op": "dist", "input": _serialize(self.input), "weight": self.weight}


class Sum(RankExpr):
    def __init__(self, *children: RankNode) -> None:
        self.children: List[RankNode] = list(children)

    def to_dict(self) -> Dict[str, Any]:
        return {"op": "sum", "children": [_serialize(c) for c in self.children]}


class Mul(RankExpr):
    def __init__(self, *children: RankNode) -> None:
        self.children: List[RankNode] = list(children)

    def to_dict(self) -> Dict[str, Any]:
        return {"op": "mul", "children": [_serialize(c) for c in self.children]}


@dataclass
class Hybrid(RankExpr):
    """Convenience builder for hybrid vector + BM25 ranking with
    weighted fusion."""

    vector_weight: float = 0.5
    bm25_weight: float = 0.5
    vector_field: str = "vector_distance"
    bm25_field: str = "bm25_score"

    def to_dict(self) -> Dict[str, Any]:
        return Sum(
            Dist(field(self.vector_field), weight=self.vector_weight),
            Saturate(field(self.bm25_field), p=1.5)
            if self.bm25_weight == 0
            else Mul(Const(self.bm25_weight), Saturate(field(self.bm25_field), p=1.5)),
        ).to_dict()


__all__ = [
    "RankExpr",
    "Field",
    "Const",
    "Saturate",
    "Decay",
    "Dist",
    "Sum",
    "Mul",
    "Hybrid",
    "field",
]
