"""Tokenizer configuration helpers for BM25 / full-text fields.

Build a tokenizer config and pass it to schema definitions or to
`bm25(db).create(schema=...)`. The shape mirrors the wire format the
router expects.

Examples
--------

    from vorkath import tokenizer as tk

    schema = {
        "title": tk.text(language="english", k3=8.0),
        "tags":  tk.pre_tokenized_array(),
        "code":  tk.text(stemmer="none", lowercase=False),
    }
"""

from __future__ import annotations

from typing import Any, Dict, Optional, Sequence


_SUPPORTED_LANGUAGES = frozenset(
    {
        "arabic",
        "danish",
        "dutch",
        "english",
        "finnish",
        "french",
        "german",
        "greek",
        "hungarian",
        "italian",
        "norwegian",
        "portuguese",
        "romanian",
        "russian",
        "spanish",
        "swedish",
        "tamil",
        "turkish",
    }
)


def text(
    *,
    language: str = "english",
    stemmer: Optional[str] = None,
    lowercase: bool = True,
    stop_words: Optional[Sequence[str]] = None,
    k3: Optional[float] = None,
    version: Optional[str] = None,
) -> Dict[str, Any]:
    """Standard text-tokenized full-text field.

    `k3` is the BM25 query-side saturation parameter. Default on the
    server is the standard 1.2 - 2.0 range; tune higher (~8.0) for
    long LLM-generated queries.
    """
    if language and language != "none" and language not in _SUPPORTED_LANGUAGES:
        raise ValueError(
            f"unsupported tokenizer language {language!r}; "
            f"supported: {sorted(_SUPPORTED_LANGUAGES)}"
        )
    cfg: Dict[str, Any] = {
        "type": "string",
        "full_text_search": True,
        "tokenizer": {
            "kind": "text",
            "language": language,
            "lowercase": lowercase,
        },
    }
    if stemmer is not None:
        cfg["tokenizer"]["stemmer"] = stemmer
    if stop_words is not None:
        cfg["tokenizer"]["stop_words"] = list(stop_words)
    if k3 is not None:
        cfg["bm25_k3"] = k3
    if version is not None:
        cfg["tokenizer_version"] = version
    return cfg


def pre_tokenized_array(*, k3: Optional[float] = None) -> Dict[str, Any]:
    """Field whose value is already tokenized: `["foo", "bar"]`."""
    cfg: Dict[str, Any] = {
        "type": "[]string",
        "full_text_search": True,
        "tokenizer": {"kind": "pre_tokenized_array"},
    }
    if k3 is not None:
        cfg["bm25_k3"] = k3
    return cfg


def keyword(
    *, lowercase: bool = False, k3: Optional[float] = None
) -> Dict[str, Any]:
    """Untokenized keyword field. Whole-string match only."""
    cfg: Dict[str, Any] = {
        "type": "string",
        "full_text_search": True,
        "tokenizer": {"kind": "keyword", "lowercase": lowercase},
    }
    if k3 is not None:
        cfg["bm25_k3"] = k3
    return cfg


__all__ = [
    "text",
    "pre_tokenized_array",
    "keyword",
]
