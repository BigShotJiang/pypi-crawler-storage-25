"""HTTP transport layer for the Vorkath SDK.

One source of truth for retries, idempotency keys, timeouts, headers,
and response decoding. The sync `Transport` and async `AsyncTransport`
wrap `httpx.Client` / `httpx.AsyncClient` and present a uniform
`request` method.

Design notes:
- HTTP/2 is on by default; httpx negotiates and falls back cleanly.
- Connection pool is sized for the common SDK case (32 keep-alive,
  max 100 in-flight). Tune via `pool_size` / `max_connections`.
- Mutating requests (POST/PUT/PATCH/DELETE) get an auto-generated
  Idempotency-Key. Callers can override per request.
- Retries: exponential backoff with full jitter, capped at
  `max_retries`, only on retriable failures (network errors, 408,
  429, 502, 503, 504). Honors the `Retry-After` header when present.
- Cancellation: `asyncio.CancelledError` is never swallowed; we abort
  the in-flight retry loop immediately.
"""

from __future__ import annotations

import asyncio
import logging
import os
import platform
import random
import time
import uuid
from dataclasses import dataclass
from typing import Any, Callable, Dict, Mapping, Optional, Tuple, Union

import inspect

import httpx

from . import _errors

_SYNC_CLIENT_PARAMS = set(inspect.signature(httpx.Client.__init__).parameters)
_ASYNC_CLIENT_PARAMS = set(inspect.signature(httpx.AsyncClient.__init__).parameters)


def _http2_available() -> bool:
    try:
        import h2  # type: ignore  # noqa: F401
        return True
    except ImportError:
        return False


_HTTP2_AVAILABLE = _http2_available()


def _filter_kwargs(kwargs: Dict[str, Any], allowed: set) -> Dict[str, Any]:
    return {k: v for k, v in kwargs.items() if k in allowed and v is not None}

_LOGGER = logging.getLogger("vorkath")

DEFAULT_TIMEOUT_SECONDS = 30.0
DEFAULT_MAX_RETRIES = 2
DEFAULT_BACKOFF_BASE = 0.5
DEFAULT_BACKOFF_CAP = 8.0
DEFAULT_POOL_SIZE = 32
DEFAULT_MAX_CONNECTIONS = 100

_RETRIABLE_STATUSES = frozenset({408, 425, 429, 500, 502, 503, 504})
_MUTATING_METHODS = frozenset({"POST", "PUT", "PATCH", "DELETE"})


def _user_agent(version: str) -> str:
    py = platform.python_version()
    sysname = platform.system().lower() or "unknown"
    return f"vorkath-python/{version} (python/{py}; {sysname})"


def _read_env_url(value: Optional[str]) -> Optional[str]:
    if value:
        return value
    return os.environ.get("VORKATH_BASE_URL")


def _read_env_core_url(value: Optional[str]) -> Optional[str]:
    if value:
        return value
    return os.environ.get("VORKATH_CORE_URL")


def _read_env_api_key(value: Optional[str]) -> Optional[str]:
    if value:
        return value
    return os.environ.get("VORKATH_API_KEY")


def _read_env_timeout(value: Optional[float]) -> float:
    if value is not None:
        return value
    raw = os.environ.get("VORKATH_TIMEOUT")
    if raw:
        try:
            return float(raw)
        except ValueError:
            pass
    return DEFAULT_TIMEOUT_SECONDS


@dataclass
class RequestSummary:
    """Per-request telemetry payload passed to `on_request`."""

    method: str
    url: str
    attempts: int
    duration_ms: float
    status: Optional[int]
    error: Optional[str] = None


OnRequest = Callable[[RequestSummary], None]


@dataclass
class TransportConfig:
    """User-facing knobs for the transport. Constructed by `Client`."""

    base_url: str
    core_url: Optional[str] = None
    api_key: Optional[str] = None
    timeout: float = DEFAULT_TIMEOUT_SECONDS
    max_retries: int = DEFAULT_MAX_RETRIES
    backoff_base: float = DEFAULT_BACKOFF_BASE
    backoff_cap: float = DEFAULT_BACKOFF_CAP
    pool_size: int = DEFAULT_POOL_SIZE
    max_connections: int = DEFAULT_MAX_CONNECTIONS
    user_agent: str = ""
    verify: bool = True
    http2: bool = True
    proxies: Optional[Union[str, Mapping[str, str]]] = None
    extra_headers: Optional[Mapping[str, str]] = None
    version: str = "0.0.0"
    on_request: Optional[OnRequest] = None
    strict_validation: bool = False

    def headers(self) -> Dict[str, str]:
        h: Dict[str, str] = {
            "Accept": "application/json",
            "User-Agent": self.user_agent or _user_agent(self.version),
        }
        if self.api_key:
            h["Authorization"] = f"Bearer {self.api_key}"
        if self.extra_headers:
            for k, v in self.extra_headers.items():
                h[k] = v
        return h

    def httpx_timeout(self) -> httpx.Timeout:
        return httpx.Timeout(self.timeout)

    def httpx_limits(self) -> httpx.Limits:
        return httpx.Limits(
            max_keepalive_connections=self.pool_size,
            max_connections=self.max_connections,
        )


def _new_idempotency_key() -> str:
    return f"vk-{uuid.uuid4().hex}"


def _is_retriable_status(status: int) -> bool:
    return status in _RETRIABLE_STATUSES


def _retry_after_seconds(headers: Mapping[str, str]) -> Optional[float]:
    value = headers.get("Retry-After") or headers.get("retry-after")
    if not value:
        return None
    try:
        return max(0.0, float(value))
    except ValueError:
        return None


def _backoff_seconds(attempt: int, base: float, cap: float) -> float:
    expo = min(cap, base * (2**attempt))
    return random.uniform(0.0, expo)


def _decode_body(response: httpx.Response) -> Tuple[Optional[Dict[str, Any]], str]:
    text = response.text
    try:
        data = response.json()
        if isinstance(data, dict):
            return data, text
        return None, text
    except ValueError:
        return None, text


def _format_request_log(method: str, url: str, attempt: int) -> str:
    return f"vorkath request method={method} url={url} attempt={attempt}"


class _BaseTransport:
    """Shared logic between sync + async transports."""

    def __init__(self, config: TransportConfig) -> None:
        self._config = config
        self._closed = False

    @property
    def base_url(self) -> str:
        return self._config.base_url

    @property
    def config(self) -> TransportConfig:
        return self._config

    def _build_headers(
        self,
        method: str,
        idempotency_key: Optional[str],
        request_headers: Optional[Mapping[str, str]],
    ) -> Dict[str, str]:
        headers = self._config.headers()
        if method.upper() in _MUTATING_METHODS:
            key = idempotency_key or _new_idempotency_key()
            headers["Idempotency-Key"] = key
        if request_headers:
            for k, v in request_headers.items():
                headers[k] = v
        return headers

    def _build_url(self, path: str, endpoint: str = "core") -> str:
        if path.startswith("http://") or path.startswith("https://"):
            return path
        if endpoint == "backend":
            base = self._config.base_url
        else:
            base = self._config.core_url or self._config.base_url
        return f"{base}{path}"

    def _emit(
        self,
        method: str,
        url: str,
        attempts: int,
        start_monotonic: float,
        status: Optional[int],
        error: Optional[BaseException] = None,
    ) -> None:
        cb = self._config.on_request
        if cb is None:
            return
        try:
            cb(
                RequestSummary(
                    method=method.upper(),
                    url=url,
                    attempts=attempts,
                    duration_ms=(time.monotonic() - start_monotonic) * 1000.0,
                    status=status,
                    error=type(error).__name__ if error else None,
                )
            )
        except Exception:  # noqa: BLE001 -- telemetry must not break calls
            pass

    def _process_response(self, response: httpx.Response) -> Any:
        body, _headers, _status = self._process_response_raw(response)
        return body

    def _process_response_raw(
        self, response: httpx.Response
    ) -> Tuple[Any, Dict[str, str], int]:
        if response.status_code >= 400:
            body_json, body_text = _decode_body(response)
            raise _errors.from_response(
                status_code=response.status_code,
                body_json=body_json,
                body_text=body_text,
                headers=dict(response.headers),
            )
        headers = {k.lower(): v for k, v in response.headers.items()}
        status = response.status_code
        if response.status_code == 204:
            return {}, headers, status
        if not response.content:
            return {}, headers, status
        try:
            return response.json(), headers, status
        except ValueError as exc:
            raise _errors.VorkathError(
                f"failed to decode JSON response: {exc}",
                status_code=response.status_code,
                body=response.text,
                headers=dict(response.headers),
            ) from exc


class Transport(_BaseTransport):
    """Synchronous httpx-backed transport."""

    def __init__(
        self,
        config: TransportConfig,
        *,
        client: Optional[httpx.Client] = None,
    ) -> None:
        super().__init__(config)
        if client is None:
            kwargs = _filter_kwargs(
                {
                    "timeout": config.httpx_timeout(),
                    "limits": config.httpx_limits(),
                    "http2": config.http2 and _HTTP2_AVAILABLE,
                    "verify": config.verify,
                    "proxies": config.proxies,
                    "proxy": config.proxies if isinstance(config.proxies, str) else None,
                },
                _SYNC_CLIENT_PARAMS,
            )
            self._client = httpx.Client(**kwargs)
            self._owns_client = True
        else:
            self._client = client
            self._owns_client = False

    def request(
        self,
        method: str,
        path: str,
        *,
        json_body: Any = None,
        params: Optional[Mapping[str, Any]] = None,
        headers: Optional[Mapping[str, str]] = None,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
        endpoint: str = "core",
    ) -> Any:
        body, _h, _s = self.request_raw(
            method,
            path,
            json_body=json_body,
            params=params,
            headers=headers,
            idempotency_key=idempotency_key,
            timeout=timeout,
            endpoint=endpoint,
        )
        return body

    def request_raw(
        self,
        method: str,
        path: str,
        *,
        json_body: Any = None,
        params: Optional[Mapping[str, Any]] = None,
        headers: Optional[Mapping[str, str]] = None,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
        endpoint: str = "core",
    ) -> Tuple[Any, Dict[str, str], int]:
        url = self._build_url(path, endpoint=endpoint)
        all_headers = self._build_headers(method, idempotency_key, headers)
        last_exc: Optional[Exception] = None
        last_status: Optional[int] = None
        start = time.monotonic()
        for attempt in range(self._config.max_retries + 1):
            _LOGGER.debug(_format_request_log(method, url, attempt))
            try:
                response = self._client.request(
                    method,
                    url,
                    json=json_body,
                    params=params,
                    headers=all_headers,
                    timeout=timeout if timeout is not None else httpx.USE_CLIENT_DEFAULT,
                )
            except httpx.TimeoutException as exc:
                last_exc = _errors.VorkathTimeoutError(f"request timed out: {exc}")
            except httpx.RequestError as exc:
                last_exc = _errors.APIConnectionError(f"network error: {exc}")
            else:
                last_status = response.status_code
                if not _is_retriable_status(response.status_code):
                    try:
                        result = self._process_response_raw(response)
                    except _errors.VorkathError as exc:
                        self._emit(method, url, attempt + 1, start, last_status, exc)
                        raise
                    self._emit(method, url, attempt + 1, start, last_status)
                    return result
                last_exc = None
                if attempt >= self._config.max_retries:
                    try:
                        result = self._process_response_raw(response)
                    except _errors.VorkathError as exc:
                        self._emit(method, url, attempt + 1, start, last_status, exc)
                        raise
                    self._emit(method, url, attempt + 1, start, last_status)
                    return result
                wait = _retry_after_seconds(response.headers) or _backoff_seconds(
                    attempt, self._config.backoff_base, self._config.backoff_cap
                )
                time.sleep(wait)
                continue
            if attempt >= self._config.max_retries:
                assert last_exc is not None
                self._emit(method, url, attempt + 1, start, last_status, last_exc)
                raise last_exc
            time.sleep(_backoff_seconds(attempt, self._config.backoff_base, self._config.backoff_cap))
        assert last_exc is not None
        self._emit(method, url, self._config.max_retries + 1, start, last_status, last_exc)
        raise last_exc

    def close(self) -> None:
        if self._owns_client and not self._closed:
            self._client.close()
            self._closed = True


class AsyncTransport(_BaseTransport):
    """Asynchronous httpx-backed transport."""

    def __init__(
        self,
        config: TransportConfig,
        *,
        client: Optional[httpx.AsyncClient] = None,
    ) -> None:
        super().__init__(config)
        if client is None:
            kwargs = _filter_kwargs(
                {
                    "timeout": config.httpx_timeout(),
                    "limits": config.httpx_limits(),
                    "http2": config.http2 and _HTTP2_AVAILABLE,
                    "verify": config.verify,
                    "proxies": config.proxies,
                    "proxy": config.proxies if isinstance(config.proxies, str) else None,
                },
                _ASYNC_CLIENT_PARAMS,
            )
            self._client = httpx.AsyncClient(**kwargs)
            self._owns_client = True
        else:
            self._client = client
            self._owns_client = False

    async def request(
        self,
        method: str,
        path: str,
        *,
        json_body: Any = None,
        params: Optional[Mapping[str, Any]] = None,
        headers: Optional[Mapping[str, str]] = None,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
        endpoint: str = "core",
    ) -> Any:
        body, _h, _s = await self.request_raw(
            method,
            path,
            json_body=json_body,
            params=params,
            headers=headers,
            idempotency_key=idempotency_key,
            timeout=timeout,
            endpoint=endpoint,
        )
        return body

    async def request_raw(
        self,
        method: str,
        path: str,
        *,
        json_body: Any = None,
        params: Optional[Mapping[str, Any]] = None,
        headers: Optional[Mapping[str, str]] = None,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
        endpoint: str = "core",
    ) -> Tuple[Any, Dict[str, str], int]:
        url = self._build_url(path, endpoint=endpoint)
        all_headers = self._build_headers(method, idempotency_key, headers)
        last_exc: Optional[Exception] = None
        last_status: Optional[int] = None
        start = time.monotonic()
        for attempt in range(self._config.max_retries + 1):
            _LOGGER.debug(_format_request_log(method, url, attempt))
            try:
                response = await self._client.request(
                    method,
                    url,
                    json=json_body,
                    params=params,
                    headers=all_headers,
                    timeout=timeout if timeout is not None else httpx.USE_CLIENT_DEFAULT,
                )
            except httpx.TimeoutException as exc:
                last_exc = _errors.VorkathTimeoutError(f"request timed out: {exc}")
            except httpx.RequestError as exc:
                last_exc = _errors.APIConnectionError(f"network error: {exc}")
            else:
                last_status = response.status_code
                if not _is_retriable_status(response.status_code):
                    try:
                        result = self._process_response_raw(response)
                    except _errors.VorkathError as exc:
                        self._emit(method, url, attempt + 1, start, last_status, exc)
                        raise
                    self._emit(method, url, attempt + 1, start, last_status)
                    return result
                last_exc = None
                if attempt >= self._config.max_retries:
                    try:
                        result = self._process_response_raw(response)
                    except _errors.VorkathError as exc:
                        self._emit(method, url, attempt + 1, start, last_status, exc)
                        raise
                    self._emit(method, url, attempt + 1, start, last_status)
                    return result
                wait = _retry_after_seconds(response.headers) or _backoff_seconds(
                    attempt, self._config.backoff_base, self._config.backoff_cap
                )
                await asyncio.sleep(wait)
                continue
            if attempt >= self._config.max_retries:
                assert last_exc is not None
                self._emit(method, url, attempt + 1, start, last_status, last_exc)
                raise last_exc
            await asyncio.sleep(
                _backoff_seconds(attempt, self._config.backoff_base, self._config.backoff_cap)
            )
        assert last_exc is not None
        self._emit(method, url, self._config.max_retries + 1, start, last_status, last_exc)
        raise last_exc

    async def aclose(self) -> None:
        if self._owns_client and not self._closed:
            await self._client.aclose()
            self._closed = True
