# Changelog

All notable changes to the `vorkath` Python SDK are documented here.
This project adheres to [semantic versioning](https://semver.org).

Version policy:

- `0.x.y` releases: pre-1.0, public API may change in any minor bump.
  Patch bumps are non-breaking.
- `>=1.0.0` releases: semver strictly. Breaking changes require a major
  bump and at least one minor release of deprecation warnings first.

## [Unreleased]

## [0.4.0] - 2026-04-28

### Added

- `client.embed(inputs, model=..., namespace_id=...)`: wraps
  `POST /v1/embed`. Accepts a single ``str`` or a sequence of ``str``;
  both forms return the standard `EmbedResponse`.
- `client.rerank(query, documents, top_n=..., return_documents=...)`:
  wraps `POST /v1/rerank`. ``top_n`` defaults to ``len(documents)``;
  ``return_documents`` defaults to ``False``.
- `client.search.text(namespace_id, query, **opts)`: wraps
  `POST /v1/search`. Embeds, retrieves, optionally reranks in one
  round trip; ``mode`` defaults to ``"hybrid"``, ``rerank`` defaults
  to ``True``, ``k`` defaults to ``20``.
- New `core_url` constructor kwarg (and `VORKATH_CORE_URL` env var)
  for hybrid deployments where vector ops route to a self-hosted
  vorkath core while embed / rerank / search route to a managed
  backend.
- Typed exception classes for the managed-search endpoints:
  `VorkathServiceUnavailableError` (HTTP 503 from the backend
  circuit breaker), `VorkathTimeoutError` (per-request timeout),
  `VorkathRateLimitError` (HTTP 429 on a managed-search endpoint).
  Each subclasses an existing exception so legacy ``except`` blocks
  still match.
- ``X-Vorkath-Degraded`` response header surfaced on
  ``SearchTextResponse.degraded``, ``EmbedResponse.degraded``, and
  ``RerankResponse.degraded`` as
  ``"embed-down" | "rerank-down" | None``.
- ``AsyncClient`` mirrors all three new methods and a
  ``client.search.text(...)`` namespace.
- New examples: ``examples/managed_search.py`` and
  ``examples/explicit_pipeline.py``.

### Changed

- Internal ``Transport.request_raw(...)`` returns body + headers +
  status so managed-search calls can capture the degraded header.
  ``Transport.request(...)`` keeps the prior signature; existing
  low-level methods are unchanged.

## [0.3.0] - 2026-04-28

### Added

- `vorkath.filters`: typed filter DSL with `Eq`, `Ne`, `In`, `NotIn`,
  `Lt`, `Le`, `Gt`, `Ge`, `Contains`, `ContainsAny`, `Glob`, `Regex`,
  `Exists`, `And`, `Or`, `Not`. Operator overloads (`&`, `|`, `~`)
  for ergonomic composition. Regex patterns validated client-side.
- `vorkath.rank`: rank-operator builders `Saturate`, `Decay`, `Dist`,
  `Sum`, `Mul`, plus a `Hybrid` shortcut for vector + BM25 fusion.
- `vorkath.tokenizer`: BM25 tokenizer config (`text`,
  `pre_tokenized_array`, `keyword`) with language validation
  covering 18 Snowball stemmers + the `none` baseline.
- Conditional writes (CAS): `if_match`, `if_none_match`,
  `expected_version` on every mutating call.
- `vectors(db).knn(...)` exact-kNN search.
- `vectors(db).patch_by_filter(...)` and `.delete_by_filter(...)`.
- `vectors(db).aggregate(...)` with `group_by` and `for_each_unique`.
- `vectors(db).upsert_many(...)` and `.bulk_upsert(...)` with
  chunking by row count + bytes; the async variant runs up to
  `max_inflight` requests in parallel.
- `client.schema(db)` CRUD: `get`, `set`, `patch`.
- `client.admin(db)` resource: `warm_cache`, `pin`,
  `namespace_metadata`, `copy_from`.
- `last_as_prefix`, `rank`, `limit_per`, `page_token` on `search`.
- `return_affected_ids`, `allow_partial`, `disable_backpressure`
  flags on bulk + filter operations.
- `vorkath.testing`: `MockRouter`, `build_mock_client`,
  `build_async_mock_client` for offline tests.
- `vorkath.telemetry`: `instrument_client` and
  `instrument_async_client` to wrap the SDK with OpenTelemetry
  spans + `traceparent` propagation. OTel is an optional dependency.

### Distribution

- `LICENSE` (Apache-2.0) ships with both wheel and sdist.
- `MANIFEST.in` whitelists exactly what enters the sdist; the
  `scripts/check_package.sh` builder verifies no Vorkath repo source
  leaks into either artifact.
- GitHub Actions: `sdk-python-test.yml` (matrix Python 3.9 - 3.13 on
  Linux/macOS/Windows + lint + typecheck + package check) and
  `sdk-python-publish.yml` (PyPI OIDC trusted publisher with PEP 740
  attestations, TestPyPI dry-run before promotion).

## [0.2.0] - 2026-04-28

### Added

- `vorkath.AsyncClient` - first-class asyncio support, mirrors every
  method on the sync `Client`.
- Full error hierarchy: `VorkathError` base plus `BadRequestError`,
  `AuthenticationError`, `PermissionDeniedError`, `NotFoundError`,
  `ConflictError`, `PreconditionFailedError`, `RateLimitError`,
  `NotImplementedAPIError`, `DeadlineExceededError`,
  `InternalServerError`, `APIConnectionError`, `APITimeoutError`,
  `APIStatusError`. Errors carry `status_code`, `request_id`,
  `server_message`, `body`, and `headers`.
- Retries with exponential backoff and full jitter, configurable via
  `max_retries`, `backoff_base`, `backoff_cap`. Honors `Retry-After`
  on 429/503.
- `Idempotency-Key` header is auto-generated for every mutating
  request (POST/PUT/PATCH/DELETE). Override per call via the
  `idempotency_key=` argument.
- Connection pooling and HTTP/2 (when the `h2` extra is installed)
  default-on via `httpx`.
- Configurable timeouts (single value today; per-phase timeouts on
  the roadmap).
- Environment-variable config: `VORKATH_BASE_URL`, `VORKATH_API_KEY`,
  `VORKATH_TIMEOUT`. Constructors `Client.from_env()` and
  `AsyncClient.from_env()`.
- Sync `with Client(...)` and async `async with AsyncClient(...)`
  context managers; `close()` / `aclose()` lifecycle methods.
- `client.with_options(**overrides)` for per-tenant copies.
- Configurable User-Agent (defaults to
  `vorkath-python/<version> (python/<py>; <os>)`).
- API surface coverage: BM25 indexes (`client.bm25(db)`), atomic
  multi-search (`client.vectors(db).multi_search([...])`), filter
  and consistency parameters on search, snapshot/restore.
- Secret redaction: `repr(client)` masks the API key.
- Strict typing: `py.typed` marker, mypy/pyright strict-clean.

### Changed

- Renamed PyPI distribution from `vorkath-client` to `vorkath`. The
  importable module name was already `vorkath`; only the install
  name changes (`pip install vorkath`).
- Replaced `requests` with `httpx` for sync + async parity.
- `Client(base_url, ...)` now accepts `base_url=None` to read from
  `VORKATH_BASE_URL`.
- Search responses now expose `last_included_write_at` and an
  `extra` dict for forward-compatible server fields.

### Removed

- `vorkath-client` package name (the package is now `vorkath`). No
  back-compat shim per the project's no-back-compat policy.

## [0.1.0]

Initial preview release: sync `Client` over `requests`, basic CRUD,
search, snapshots, SQL.
