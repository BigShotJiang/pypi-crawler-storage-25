"""
Quality scoring and session-level statistics for FITS subframes.
"""

from __future__ import annotations

from collections import defaultdict

import numpy as np


def compute_session_stats(subs: list[dict]) -> dict:
    """Compute reference statistics for a collection of analysed subframes.

    Parameters
    ----------
    subs:
        List of result dicts as returned by :func:`~astro_quality.analyze_fits`.

    Returns
    -------
    dict with median values for each metric across all error-free subs,
    plus ``n_subs`` and ``n_good`` counts.  Returns an empty dict if all
    subs have errors.
    """
    good = [s for s in subs if s.get("error") is None]
    if not good:
        return {}

    def med_of(key: str) -> float:
        vals = [s["metrics"].get(key, 0) for s in good if key in s.get("metrics", {})]
        return float(np.median(vals)) if vals else 0.0

    return {
        "noise_med":      med_of("background_noise"),
        "gradient_med":   med_of("gradient"),
        "star_count_med": med_of("star_count"),
        "snr_med":        med_of("snr_proxy"),
        "sat_med":        med_of("saturation_pct"),
        "fwhm_med":       med_of("fwhm_median"),
        "ecc_med":        med_of("eccentricity"),
        "n_subs":         len(subs),
        "n_good":         len(good),
    }


def score_sub(metrics: dict, stats: dict) -> float:
    """Return a quality score 0–100 for one sub relative to its session.

    100 = indistinguishable from the session median, 0 = unusable.
    The score is *relative*: a score of 90 in a poor session may be worse
    in absolute terms than a score of 70 in an excellent session.

    Scoring penalties
    -----------------
    * Background noise above median    → up to −35
    * Star count below median          → up to −40
    * FWHM more than 1.2× median       → up to −20
    * Eccentricity (absolute, ecc>0.5) → up to −35  (catches whole-session distortion)
    * Eccentricity more than 1.3× med. → up to −20  (catches per-sub outliers)
    * Background gradient above median → up to −15
    * Saturated pixels                 → up to −20
    """
    if not metrics or not stats:
        return 0.0

    score = 100.0

    if stats.get("noise_med", 0) > 0:
        ratio = metrics.get("background_noise", stats["noise_med"]) / stats["noise_med"]
        if ratio > 1.0:
            score -= min(35, (ratio - 1.0) * 40)

    sc     = metrics.get("star_count", -1)
    sc_med = stats.get("star_count_med", -1)
    if sc >= 0 and sc_med > 3:
        ratio = sc / sc_med
        if ratio < 1.0:
            score -= min(40, (1.0 - ratio) * 50)
        elif ratio > 1.3:
            score += min(5, (ratio - 1.0) * 8)

    if stats.get("gradient_med", 0) > 0:
        ratio = metrics.get("gradient", 0) / stats["gradient_med"]
        if ratio > 1.5:
            score -= min(15, (ratio - 1.0) * 8)

    fwhm     = metrics.get("fwhm_median", 0)
    fwhm_med = stats.get("fwhm_med", 0)
    if fwhm > 0 and fwhm_med > 0:
        ratio = fwhm / fwhm_med
        if ratio > 1.2:
            score -= min(20, (ratio - 1.0) * 25)

    ecc     = metrics.get("eccentricity", 0)
    ecc_med = stats.get("ecc_med", 0)
    if ecc > 0:
        # Absolute penalty: ecc > 0.5 means the minor star axis is <87 % of the major
        # axis — a level of elongation visible in stacked images. This fires even when
        # the whole session is distorted (relative scoring alone would miss it).
        abs_pen = min(35, max(0.0, (ecc - 0.5) * 140))
        # Relative penalty: this sub is a worse outlier than the session baseline.
        rel_pen = 0.0
        if ecc_med > 0:
            ratio = ecc / max(ecc_med, 0.05)
            if ratio > 1.3:
                rel_pen = min(20, (ratio - 1.0) * 15)
        score -= abs_pen + rel_pen

    score -= min(20, metrics.get("saturation_pct", 0) * 5)

    return max(0.0, min(100.0, score))


def grade(score: float) -> str:
    """Convert a numeric score to a letter grade (A–F)."""
    if score >= 85: return "A"
    if score >= 70: return "B"
    if score >= 50: return "C"
    if score >= 30: return "D"
    return "F"


def build_report_data(
    cache: dict,
    obj_filter: str | None = None,
    sess_filter: str | None = None,
) -> dict:
    """Aggregate a quality cache into a scored, sorted report structure.

    Parameters
    ----------
    cache:
        Dict as returned by :func:`~astro_quality.cache.load_cache`.
    obj_filter:
        Case-insensitive substring filter on object names.
    sess_filter:
        Case-insensitive substring filter on session names.

    Returns
    -------
    Nested dict: ``{object_name: {session_name: {subs, stats, score_mean, …}}}``
    Subs within each session are sorted best-first by score.
    """
    objects: dict[str, dict[str, list]] = defaultdict(lambda: defaultdict(list))

    for entry in cache.values():
        if entry.get("error"):
            continue
        obj  = entry.get("object", "?")
        sess = entry.get("session", "?")
        if obj_filter  and obj_filter.lower()  not in obj.lower():
            continue
        if sess_filter and sess_filter.lower() not in sess.lower():
            continue
        objects[obj][sess].append(entry)

    report: dict = {}
    for obj, sessions in sorted(objects.items()):
        report[obj] = {}
        for sess, subs in sorted(sessions.items()):
            stats  = compute_session_stats(subs)
            scored = []
            for sub in subs:
                s = score_sub(sub.get("metrics", {}), stats)
                scored.append({**sub, "score": s, "grade": grade(s)})
            scored.sort(key=lambda x: x["score"], reverse=True)
            scores = [s["score"] for s in scored]
            report[obj][sess] = {
                "subs":       scored,
                "stats":      stats,
                "score_mean": float(np.mean(scores))  if scores else 0.0,
                "score_min":  float(np.min(scores))   if scores else 0.0,
                "score_max":  float(np.max(scores))   if scores else 0.0,
                "grade":      grade(float(np.mean(scores)) if scores else 0.0),
            }
    return report
