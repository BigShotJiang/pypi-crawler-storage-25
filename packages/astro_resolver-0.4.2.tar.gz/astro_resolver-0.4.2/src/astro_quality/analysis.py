"""
Core FITS subframe quality analysis.

analyse_fits() reads a single FITS file and returns a metrics dict
that is camera-agnostic (DSLR, ASI, QHY, DWARF, …) and handles
Bayer RAW as well as mono images.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

import numpy as np

try:
    from astropy.io import fits
    from astropy.stats import sigma_clipped_stats
except ImportError as exc:
    raise ImportError("astropy is required: pip install astropy") from exc

try:
    from photutils.detection import DAOStarFinder
    from photutils.background import Background2D, SExtractorBackground
    _HAS_PHOTUTILS = True
except ImportError:
    _HAS_PHOTUTILS = False


def debayer_green(data: np.ndarray, pattern: str = "RGGB") -> np.ndarray:
    """Extract the green channel(s) from a Bayer RAW array as a luminance proxy.

    Returns an array of shape (H//2, W//2) for standard 2×2 patterns.
    Falls back to the original array for unknown patterns.
    """
    data = data.astype(np.float32)
    if pattern in ("RGGB", "BGGR"):
        g1 = data[0::2, 1::2]
        g2 = data[1::2, 0::2]
    elif pattern in ("GRBG", "GBRG"):
        g1 = data[0::2, 0::2]
        g2 = data[1::2, 1::2]
    else:
        return data
    return (g1 + g2) / 2.0


def analyze_fits(filepath: Path, fast: bool = False) -> dict:
    """Analyze a single FITS light frame and return a quality metrics dict.

    Parameters
    ----------
    filepath:
        Path to the FITS file.
    fast:
        If True, skip star detection, FWHM and eccentricity computation
        (roughly 4–6× faster, suitable for a first-pass scan).

    Returns
    -------
    dict with keys:

    * ``path`` / ``filename`` — file location
    * ``error`` — None on success, error message string on failure
    * ``header`` — selected FITS header fields
    * ``metrics`` — quality metrics (see below)
    * ``analyzed_at`` — ISO timestamp
    * ``file_mtime`` — file modification time (float)

    Metrics
    -------
    Always present:
        background_median, background_mean, background_noise,
        max_value, saturation_pct, snr_proxy, gradient

    Present when ``fast=False`` and photutils is installed:
        star_count, fwhm_median, fwhm_std, eccentricity
    """
    result: dict = {
        "path":        str(filepath),
        "filename":    filepath.name,
        "error":       None,
        "header":      {},
        "metrics":     {},
        "analyzed_at": datetime.now().isoformat(),
        "file_mtime":  filepath.stat().st_mtime if filepath.exists() else 0,
    }

    try:
        with fits.open(filepath, memmap=False, ignore_missing_simple=True) as hdul:
            hdr = hdul[0].header
            raw = hdul[0].data

        if raw is None:
            result["error"] = "No image data in Primary HDU"
            return result

        # Skip calibration frames that slipped past filename filtering
        frame_type = str(hdr.get("IMAGETYP", hdr.get("FRAME", "light"))).strip().lower()
        if frame_type not in ("light", "science", "object", ""):
            result["error"] = f"Not a light frame (IMAGETYP={frame_type!r})"
            return result

        result["header"] = {
            "date_obs":  str(hdr.get("DATE-OBS", "")),
            "exptime":   float(hdr.get("EXPTIME", 0)),
            "gain":      int(hdr.get("GAIN", 0)),
            "filter":    str(hdr.get("FILTER", "")),
            "temp":      float(hdr.get("DET-TEMP", hdr.get("CCD-TEMP", 0))),
            "object":    str(hdr.get("OBJECT", "")),
            "telescope": str(hdr.get("TELESCOP", hdr.get("INSTRUME", ""))),
            "camera":    str(hdr.get("INSTRUME", hdr.get("CAMERA", ""))),
            "bayer":     str(hdr.get("BAYERPAT", "")),
            "xpixsz":    float(hdr.get("XPIXSZ", 0)),
            "focallen":  float(hdr.get("FOCALLEN", 0)),
        }

        bayer = result["header"]["bayer"]
        lum = debayer_green(raw, bayer) if bayer else raw.astype(np.float32)

        # Crop 5 % border to avoid vignetting artefacts
        h, w = lum.shape
        mh, mw = max(1, h // 20), max(1, w // 20)
        roi = lum[mh:h - mh, mw:w - mw]

        mean, median, std = sigma_clipped_stats(roi, sigma=3.0, maxiters=5)

        m = result["metrics"]
        m["background_median"] = float(median)
        m["background_mean"]   = float(mean)
        m["background_noise"]  = float(std) if std > 0 else 1e-6
        m["max_value"]         = float(np.max(roi))

        # Saturation threshold — camera-agnostic:
        # prefer explicit header keywords, fall back to BITPIX + actual data max.
        sat_threshold = None
        for key in ("SATLEVEL", "SATURATE", "DATAMAX"):
            val = hdr.get(key)
            if val is not None:
                sat_threshold = float(val) * 0.99
                break
        if sat_threshold is None:
            bitpix = abs(int(hdr.get("BITPIX", 16)))
            nominal_max = float(2 ** bitpix - 1)
            data_max = float(np.max(roi))
            sat_threshold = min(nominal_max, data_max) * 0.99
        m["saturation_pct"] = float(np.sum(roi >= sat_threshold) / roi.size * 100)

        # Coarse SNR: brightest 1 % of pixels above background divided by noise
        signal_proxy = max(0.0, float(np.percentile(roi, 99)) - float(median))
        m["snr_proxy"] = float(signal_proxy / m["background_noise"])

        # Gradient: spatial variation of background (normalised)
        row_med = np.median(roi, axis=1)
        col_med = np.median(roi, axis=0)
        norm = max(float(median), 1.0)
        m["gradient"] = float((np.std(row_med) + np.std(col_med)) / 2.0 / norm)

        # Star detection, FWHM and eccentricity (skipped in fast mode)
        if _HAS_PHOTUTILS and not fast:
            try:
                # Local background via mesh to handle galaxy gradients / nebulosity
                box = max(32, min(128, min(roi.shape) // 10))
                try:
                    bkg = Background2D(roi, box_size=box, filter_size=3,
                                       bkg_estimator=SExtractorBackground())
                    data_sub = (roi - bkg.background).astype(np.float32)
                    local_std = float(bkg.background_rms_median)
                except Exception:
                    data_sub = (roi - float(median)).astype(np.float32)
                    local_std = float(std)

                det_threshold = max(5.0 * local_std, 1.0)
                dao = DAOStarFinder(
                    fwhm=3.0,
                    threshold=det_threshold,
                    peak_max=sat_threshold * 0.95,
                    exclude_border=True,
                )
                sources = dao(data_sub)
                if sources is not None and len(sources) > 0:
                    m["star_count"] = int(len(sources))
                    fwhm_vals: list[float] = []
                    ecc_vals:  list[float] = []
                    pad = 6
                    x_col = "x_centroid" if "x_centroid" in sources.colnames else "xcentroid"
                    y_col = "y_centroid" if "y_centroid" in sources.colnames else "ycentroid"
                    for src in sources:
                        cx = int(round(float(src[x_col])))
                        cy = int(round(float(src[y_col])))
                        y0 = max(0, cy - pad); y1 = min(roi.shape[0], cy + pad + 1)
                        x0 = max(0, cx - pad); x1 = min(roi.shape[1], cx + pad + 1)
                        stamp = data_sub[y0:y1, x0:x1].clip(min=0)
                        total = stamp.sum()
                        if total <= 0:
                            continue
                        yy, xx = np.mgrid[0:stamp.shape[0], 0:stamp.shape[1]].astype(np.float32)
                        yc  = (yy * stamp).sum() / total
                        xc  = (xx * stamp).sum() / total
                        vy  = ((yy - yc) ** 2 * stamp).sum() / total
                        vx  = ((xx - xc) ** 2 * stamp).sum() / total
                        vxy = ((yy - yc) * (xx - xc) * stamp).sum() / total
                        sigma2 = (vy + vx) / 2.0
                        if sigma2 > 0:
                            fwhm_vals.append(2.355 * float(np.sqrt(sigma2)))
                        disc = float(np.sqrt(max(0.0, ((vy - vx) / 2) ** 2 + vxy ** 2)))
                        lam1 = sigma2 + disc
                        lam2 = sigma2 - disc
                        if lam1 > 1e-9:
                            ecc_vals.append(float(np.sqrt(max(0.0, 1.0 - max(lam2, 0.0) / lam1))))
                    m["fwhm_median"]  = float(np.median(fwhm_vals)) if fwhm_vals else 0.0
                    m["fwhm_std"]     = float(np.std(fwhm_vals))    if fwhm_vals else 0.0
                    m["eccentricity"] = float(np.median(ecc_vals))  if ecc_vals  else 0.0
                else:
                    m["star_count"] = 0
                    m["fwhm_median"] = m["fwhm_std"] = m["eccentricity"] = 0.0
            except Exception as _star_exc:
                m["star_count"] = -1
                m["fwhm_median"] = m["fwhm_std"] = m["eccentricity"] = 0.0
                m["star_detection_error"] = str(_star_exc)
        else:
            m["star_count"] = -1
            m["fwhm_median"] = m["fwhm_std"] = m["eccentricity"] = 0.0

    except Exception as exc:
        result["error"] = str(exc)

    return result
