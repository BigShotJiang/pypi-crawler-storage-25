"""
Archive navigation: iterates over the object/session/FITS hierarchy
and filters out calibration frames.
"""

from pathlib import Path

FITS_EXTENSIONS = {".fits", ".fit", ".fts"}

# Session-level folder names that are not imaging sessions
SKIP_DIR_NAMES: frozenset[str] = frozenset({
    "presets", "preset",
    "calibration", "calibrations", "masters",
    "flats", "flat", "darks", "dark", "bias",
})

# File-name prefixes that identify calibration frames
_CALIB_PREFIXES = (
    "flat_", "masterflat_", "flat ",  "masterflat ",
    "dark_", "masterdark_", "bias_", "masterbias_",
)


def is_calib_frame(f: Path) -> bool:
    """Return True if *f* is a calibration frame (Flat, Dark, Bias)."""
    stem_lower = f.stem.lower() + "_"   # trailing _ ensures prefix boundary
    if any(stem_lower.startswith(p) for p in _CALIB_PREFIXES):
        return True
    if f.parent.name.lower() in SKIP_DIR_NAMES:
        return True
    return False


def iter_sessions(root: Path):
    """Yield (object_name, session_name, session_path) for every session under *root*.

    Skips non-session directories (presets, flats, calibration, …).
    Expected layout::

        <root>/
            <ObjectName>/
                <YYYY-MM-DD[_Telescope]>/
                    *.fits
    """
    if not root.exists():
        return
    for obj_dir in sorted(root.iterdir()):
        if not obj_dir.is_dir():
            continue
        for sess_dir in sorted(obj_dir.iterdir()):
            if not sess_dir.is_dir():
                continue
            if sess_dir.name.lower() in SKIP_DIR_NAMES:
                continue
            yield obj_dir.name, sess_dir.name, sess_dir


def iter_fits(session_path: Path):
    """Yield light-frame FITS files from *session_path* (no Flats / Darks / Bias)."""
    for f in sorted(session_path.iterdir()):
        if f.suffix.lower() not in FITS_EXTENSIONS:
            continue
        if is_calib_frame(f):
            continue
        yield f
