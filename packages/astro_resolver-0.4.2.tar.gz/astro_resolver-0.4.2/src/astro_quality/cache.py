"""
JSON cache for FITS analysis results.

The cache maps absolute file paths (str) to analysis result dicts.
Callers supply the cache path so the library stays path-agnostic.
"""

import json
from pathlib import Path

import numpy as np


class _NumpyEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        if isinstance(obj, np.floating):
            return float(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        return super().default(obj)


def load_cache(path: Path) -> dict:
    """Load the JSON cache from *path*. Returns an empty dict on any error."""
    if path.exists():
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def save_cache(cache: dict, path: Path) -> None:
    """Write *cache* to *path* atomically (write-to-tmp then rename).

    Falls back to delete-then-rename on Windows mapped drives where
    os.replace() raises PermissionError.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cache, f, indent=2, ensure_ascii=False, cls=_NumpyEncoder)
    try:
        tmp.replace(path)
    except OSError:
        if path.exists():
            path.unlink()
        tmp.rename(path)
