"""
astro_quality — FITS subframe quality analysis for astrophotography archives.

Typical usage
-------------
>>> from astro_quality import analyze_fits, score_sub, grade, compute_session_stats
>>> result = analyze_fits(Path("frame.fits"))
>>> if not result["error"]:
...     print(result["metrics"]["background_noise"])

For scanning a full archive session::

    from astro_quality import analyze_fits, compute_session_stats, score_sub, grade
    from astro_quality.archive import iter_sessions, iter_fits
    from astro_quality.cache import load_cache, save_cache
    from astro_quality.scoring import build_report_data
"""

from .analysis import analyze_fits, debayer_green
from .archive import iter_sessions, iter_fits, is_calib_frame, FITS_EXTENSIONS, SKIP_DIR_NAMES
from .cache import load_cache, save_cache
from .scoring import compute_session_stats, score_sub, grade, build_report_data

__all__ = [
    # analysis
    "analyze_fits",
    "debayer_green",
    # archive
    "iter_sessions",
    "iter_fits",
    "is_calib_frame",
    "FITS_EXTENSIONS",
    "SKIP_DIR_NAMES",
    # cache
    "load_cache",
    "save_cache",
    # scoring
    "compute_session_stats",
    "score_sub",
    "grade",
    "build_report_data",
]
