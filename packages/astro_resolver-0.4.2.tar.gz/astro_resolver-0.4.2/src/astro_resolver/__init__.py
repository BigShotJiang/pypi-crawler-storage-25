"""
astro_resolver – astronomical object name resolution library.
"""

from .resolver import resolve_object_name, resolve_caldwell, resolve_alias, resolve_sharpless, resolve_barnard
from .formatting import (
    format_folder_name, sanitize, normalize_val,
    format_exptime, clean_filter, normalize_object_name,
)
from .openngc import openngc_lookup
from .constants import (
    SOLAR_SYSTEM, CALDWELL_MAP, CUSTOM_ALIASES,
    SHARPLESS_NAMES, BARNARD_NAMES,
    CATALOG_PRIORITY, CATALOG_BLACKLIST,
    STAR_OTYPES, INTERESTING_OTYPES, EMPTY_VALS,
)

__all__ = [
    "resolve_object_name",
    "resolve_caldwell",
    "resolve_alias",
    "format_folder_name",
    "sanitize",
    "normalize_val",
    "format_exptime",
    "clean_filter",
    "normalize_object_name",
    "openngc_lookup",
    "SOLAR_SYSTEM",
    "CALDWELL_MAP",
    "CUSTOM_ALIASES",
    "CATALOG_PRIORITY",
    "CATALOG_BLACKLIST",
    "STAR_OTYPES",
    "INTERESTING_OTYPES",
    "EMPTY_VALS",
]
