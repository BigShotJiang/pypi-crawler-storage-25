"""
High-level astronomical object name resolver.

Resolution priority (all local steps first, SIMBAD only as last resort):
  1. Solar System objects   (local)
  2. Caldwell catalog       (local)
  3. Custom aliases         (local)
  4. OpenNGC offline        (local, ~14k NGC/IC objects)
  5. Sharpless catalog      (local, Sh 2-xxx HII regions)
  6. Barnard catalog        (local, dark nebulae)
  7. SIMBAD by name         (online; otype-check skipped for known DSO catalogs)
  8. SIMBAD by coords       (online)
  9. format_folder_name(obj_raw) fallback
"""

import re

from astropy.coordinates import SkyCoord
import astropy.units as u

from .constants import (
    SOLAR_SYSTEM, CALDWELL_MAP, CUSTOM_ALIASES, STAR_OTYPES,
    SHARPLESS_NAMES, BARNARD_NAMES, DSO_CATALOG_RE, STELLAR_CATALOG_RE,
)
from .formatting import (
    normalize_object_name, format_folder_name, sanitize
)
from .simbad import simbad_get_otype, simbad_lookup_by_name, simbad_lookup_by_coords
from .openngc import openngc_lookup


# ── Local lookups ─────────────────────────────────────────────────────────────

def resolve_caldwell(name: str):
    m = re.match(r"^C\s*(\d+)$", str(name).strip(), re.IGNORECASE)
    if not m:
        return None
    entry = CALDWELL_MAP.get(int(m.group(1)))
    if not entry:
        return None
    ngc_id, cname = entry
    return (ngc_id or ("C" + m.group(1)), cname)


def resolve_alias(name: str):
    key       = str(name).strip().lower()
    key_clean = re.sub(r"['\-\s]", "", key)
    return CUSTOM_ALIASES.get(key) or CUSTOM_ALIASES.get(key_clean)


def resolve_sharpless(name: str):
    """
    Resolve any Sh 2-xxx variant to (catalog_id, common_name_or_None).
    Handles: 'Sh 2-101', 'SH2-101', 'sh2101', 'Sh2 101', etc.
    Returns None if the input is not a Sharpless identifier.
    """
    m = re.match(r"^sh\s*[-–]?\s*2[-–\s]?(\d+)", str(name).strip(), re.IGNORECASE)
    if not m:
        return None
    num    = int(m.group(1))
    cat_id = f"Sh2-{num}"
    common = SHARPLESS_NAMES.get(num)
    return (cat_id, common)


def resolve_barnard(name: str):
    """
    Resolve B xxx / Barnard xxx to (catalog_id, common_name_or_None).
    Handles: 'B33', 'B 33', 'Barnard 33', 'barnard33', etc.
    Returns None if the input is not a Barnard identifier.
    """
    m = re.match(r"^(?:barnard\s+|b\s*)(\d+)$", str(name).strip(), re.IGNORECASE)
    if not m:
        return None
    num    = int(m.group(1))
    cat_id = f"B{num}"
    common = BARNARD_NAMES.get(num)
    return (cat_id, common)


# ── Coordinate helpers ────────────────────────────────────────────────────────

def _coords_to_deg(ra_str: str, dec_str: str):
    try:
        return float(ra_str), float(dec_str)
    except ValueError:
        pass
    try:
        sc = SkyCoord(ra_str, dec_str, unit=("hourangle", "deg"))
        return sc.ra.deg, sc.dec.deg
    except Exception:
        return None, None


def _resolve_by_coords(ra: str | None, dec: str | None, label: str, log=print):
    if not ra or not dec:
        return None
    log(f"    → coords lookup ({label}): RA={ra} DEC={dec}")
    ra_deg, dec_deg = _coords_to_deg(ra, dec)
    if ra_deg is None:
        return None
    result = simbad_lookup_by_coords(ra_deg, dec_deg, log=log)
    if not result:
        return None
    cat_id, cname = result
    return format_folder_name(cat_id, cname) or cat_id


# ── Main resolver ─────────────────────────────────────────────────────────────

def resolve_object_name(
    obj_raw: str,
    ra:  str | None = None,
    dec: str | None = None,
    log = print,
) -> str:
    """
    Resolve a raw FITS OBJECT name to a filesystem-safe folder name.

    Args:
        obj_raw: Raw object name from FITS OBJECT header, e.g. 'M 81' or 'Sh 2-101'.
        ra:      Right ascension string (decimal degrees or sexagesimal), optional.
        dec:     Declination string (decimal degrees or sexagesimal), optional.
        log:     Logging callable; defaults to print. Pass siril.log for Siril scripts.

    Returns:
        Filesystem-safe folder name, e.g. 'M81_BodesGalaxy' or 'Sh2-101_TulipNebula'.
    """
    obj_raw = normalize_object_name(str(obj_raw))
    key     = re.sub(r"[\s\-]", "", obj_raw).lower()

    # 1. Solar System
    if ss := SOLAR_SYSTEM.get(key) or SOLAR_SYSTEM.get(obj_raw.lower()):
        log(f"☀️  Solar System → {ss}")
        return ss

    # 2. Caldwell
    if c := resolve_caldwell(obj_raw):
        name = format_folder_name(*c)
        log(f"📚 Caldwell → {name}")
        return sanitize(name)

    # 3. Custom Alias
    if a := resolve_alias(obj_raw):
        name = format_folder_name(*a) or a[1]
        log(f"🏷️  Alias → {name}")
        return sanitize(name)

    # 4. OpenNGC offline (~14k NGC/IC objects)
    if ngc := openngc_lookup(obj_raw):
        cat_id, cname = ngc
        name = format_folder_name(cat_id, cname) or cat_id
        log(f"📖 OpenNGC → {name}")
        return sanitize(name)

    # 5. Sharpless HII regions
    if sh := resolve_sharpless(obj_raw):
        cat_id, cname = sh
        name = format_folder_name(cat_id, cname) or cat_id
        log(f"🌌 Sharpless → {name}")
        return sanitize(name)

    # 6. Barnard dark nebulae
    if b := resolve_barnard(obj_raw):
        cat_id, cname = b
        name = format_folder_name(cat_id, cname) or cat_id
        log(f"🌑 Barnard → {name}")
        return sanitize(name)

    # 7. SIMBAD by name
    # For known stellar catalog IDs (HD, HIP, SAO, TYC …) skip the otype round-trip
    # entirely – we know it's a star, go straight to coord-based lookup.
    if STELLAR_CATALOG_RE.match(obj_raw.strip()):
        log(f"    OBJECT '{obj_raw}' is a stellar catalog ID → coords lookup...")
        if resolved := _resolve_by_coords(ra, dec, obj_raw, log=log):
            return sanitize(resolved)
        log("⚠️  No coord hit → using OBJECT header")
        return format_folder_name(obj_raw, None) or sanitize(obj_raw) or "Unknown"

    # Skip otype check for recognized DSO catalog prefixes (LBN, LDN, RCW, VdB …)
    # – we know it's a DSO, no need to waste a round-trip confirming that.
    is_known_dso = bool(DSO_CATALOG_RE.match(obj_raw.strip()))

    if not is_known_dso:
        otype = simbad_get_otype(obj_raw, log=log)
        if otype in STAR_OTYPES or otype is None:
            reason = "is a star" if otype in STAR_OTYPES else "unknown in SIMBAD"
            log(f"    OBJECT '{obj_raw}' {reason} → coords lookup...")
            if resolved := _resolve_by_coords(ra, dec, obj_raw, log=log):
                return sanitize(resolved)
            log("⚠️  No SIMBAD hit → using OBJECT header")
            return format_folder_name(obj_raw, None) or sanitize(obj_raw) or "Unknown"

    result = simbad_lookup_by_name(obj_raw, log=log)
    if result:
        cat_id, cname = result
        name = format_folder_name(cat_id, cname) or cat_id
        log(f"🔭 SIMBAD → {name}")
        return sanitize(name)

    # 8. SIMBAD by coords (last online attempt)
    if resolved := _resolve_by_coords(ra, dec, obj_raw, log=log):
        log(f"📍 SIMBAD coords → {resolved}")
        return sanitize(resolved)

    # 9. Fallback
    log("⚠️  No match → using OBJECT header")
    return format_folder_name(obj_raw, None) or sanitize(obj_raw) or "Unknown"
