"""
String formatting and normalization utilities for astronomical object names.
"""

import re


def normalize_val(val):
    from .constants import EMPTY_VALS
    if val is None:
        return None
    s = str(val).strip()
    return None if s.lower() in EMPTY_VALS else s


def sanitize(s: str) -> str:
    s = str(s).replace("'", "").replace(" ", "_").replace("(", "").replace(")", "")
    s = re.sub(r"[^\w\-.]", "_", s)
    return re.sub(r"_+", "_", s).strip("_")


def format_exptime(secs) -> str | None:
    try:
        secs = int(float(secs))
    except Exception:
        return None
    if secs <= 0:
        return None
    if secs >= 3600:
        h, m = secs // 3600, (secs % 3600) // 60
        return (str(h) + "h" + str(m).zfill(2) + "m") if m else str(h) + "h"
    if secs >= 60:
        return str(secs // 60) + "m"
    return str(secs) + "s"


def clean_filter(filter_str: str) -> str:
    seen = []
    for p in str(filter_str).replace(" ", "").split("_"):
        if p and p not in seen:
            seen.append(p)
    return "_".join(seen)


def normalize_object_name(obj: str) -> str:
    """M 45(1) → M 45,  HD_343641 → HD 343641."""
    obj = str(obj).strip()
    obj = re.sub(r"\s*\(\d+\)\s*$", "", obj).strip()
    obj = re.sub(r"([A-Za-z]+)_([\d])", r"\1 \2", obj)
    return re.sub(r"\s+", " ", obj).strip()


def normalize_for_simbad(name: str) -> str:
    name = str(name).strip()
    m = re.match(r"^SH[-\s]?2[-\s](\d+).*$", name, re.IGNORECASE)
    if m:
        return "Sh 2-" + m.group(1)
    m = re.match(r"^(IC|NGC)\s*(\d+)\s*[-]?.*$", name, re.IGNORECASE)
    if m:
        return m.group(1).upper() + " " + m.group(2)
    return name


def format_folder_name(catalog_id, common_name) -> str | None:
    """
    Builds a filesystem-safe folder name: 'NGC891_NeedleGalaxy' or 'M81_BodeGalaxy'.
    Spaces in catalog_id are removed (e.g. 'M 81' → 'M81').
    Spaces in common_name are title-cased and removed (e.g. 'Bode Galaxy' → 'BodeGalaxy').
    """
    def clean_cat(s):
        s = str(s).strip().replace(" ", "")
        s = re.sub(r"[^\w\-]", "_", s)
        return re.sub(r"_+", "_", s).strip("_")

    def clean_name(s):
        s = str(s).strip()
        if len(s.split()) == 1 and s.upper() == s and len(s) > 6 and s.isalpha():
            return None
        s = s.replace("'", "")  # strip apostrophes before title() to avoid 'BodeSGalaxy'
        if " " in s:
            s = s.title().replace(" ", "")
        s = re.sub(r"[^\w\-]", "", s)
        return s if s else None

    cat  = clean_cat(catalog_id)   if catalog_id  else None
    name = clean_name(common_name) if common_name else None

    if cat and name and cat.lower() != name.lower():
        return cat + "_" + name
    if cat:  return cat
    if name: return name
    return None
