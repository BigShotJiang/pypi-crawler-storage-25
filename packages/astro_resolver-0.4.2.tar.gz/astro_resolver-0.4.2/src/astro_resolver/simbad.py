"""
SIMBAD online name resolution with combined IDS+otype request and caching.
Robust against different field names across astroquery versions.
"""

import time

from astroquery.simbad import Simbad
from astropy.coordinates import SkyCoord
import astropy.units as u

from .constants import CATALOG_PRIORITY, CATALOG_BLACKLIST, INTERESTING_OTYPES
from .formatting import normalize_for_simbad


_simbad_cache: dict = {}
_otype_cache:  dict = {}


def pick_best_common_name(names):
    if not names:
        return None
    def score(n):
        s, sc = n.strip(), 0
        if any(k in s for k in ["Nebula", "Galaxy", "Cluster", "Cloud"]):   sc += 200
        if any(k in s for k in ["Andromeda", "Pleiades", "Orion", "Heart",
                                  "Soul", "Rosette", "Tarantula", "Helix",
                                  "Sunflower", "Whirlpool", "Pinwheel", "Bode"]): sc += 120
        if s.upper().startswith(("AFGL", "TIC", "GAIA", "2MASS", "WISE", "TYC", "HIP", "HD ")): sc -= 300
        sc -= sum(ch.isdigit() for ch in s) * 15
        sc -= len(s) // 4
        return sc
    best = sorted(names, key=score, reverse=True)[0]
    return None if score(best) < -50 else best


def _id_prefix_token(id_str: str) -> str:
    s = id_str.strip()
    return s.split()[0].split("-")[0].upper() if s else ""


def parse_catalog_and_name(ids):
    catalog_id = None
    for prefix in CATALOG_PRIORITY:
        for id_str in ids:
            if id_str.upper().startswith(prefix.upper()):
                catalog_id = id_str.strip()
                break
        if catalog_id:
            break
    if not catalog_id:
        for id_str in ids:
            if _id_prefix_token(id_str) not in CATALOG_BLACKLIST:
                catalog_id = id_str.strip()
                break
    name_candidates = [id_str[5:].strip() for id_str in ids if id_str.upper().startswith("NAME ")]
    return (catalog_id, pick_best_common_name(name_candidates))


def _simbad_query(raw_name: str, log=print):
    """
    Single SIMBAD request per object: fetches otype AND all IDs together.
    Robust against varying field names across astroquery versions.
    Fills both _simbad_cache and _otype_cache.
    Returns (parsed, otype) where parsed = (catalog_id, common_name) or None.
    """
    query_name = normalize_for_simbad(raw_name)
    key = query_name.strip().lower()

    if key in _simbad_cache and key in _otype_cache:
        return _simbad_cache[key], _otype_cache[key]

    time.sleep(0.2)
    otype  = None
    parsed = None
    try:
        sim = Simbad()
        sim.add_votable_fields("otype", "ids")
        result = sim.query_object(query_name)

        if result is not None and len(result) > 0:
            row = result[0]

            try:
                otype = str(row["otype"]).strip()
            except Exception:
                pass

            ids_raw = None
            for field in ("IDS", "ids", "ID", "id"):
                try:
                    ids_raw = str(row[field])
                    break
                except Exception:
                    continue

            if ids_raw:
                ids = [i.strip() for i in ids_raw.split("|") if i.strip()]
            else:
                log(f"    IDS field not found, falling back to query_objectids()")
                time.sleep(0.2)
                id_tbl = Simbad.query_objectids(query_name)
                ids = [str(r["ID"]).strip() for r in id_tbl] if id_tbl is not None else []

            parsed = parse_catalog_and_name(ids) if ids else None

    except Exception as e:
        log(f"SIMBAD error ({query_name}): {e}")

    _simbad_cache[key] = parsed
    _otype_cache[key]  = otype
    return parsed, otype


def simbad_lookup_by_name(raw_name: str, log=print):
    parsed, _ = _simbad_query(raw_name, log=log)
    return parsed


def simbad_get_otype(object_name: str, log=print):
    _, otype = _simbad_query(object_name, log=log)
    return otype


def simbad_lookup_by_coords(ra_deg: float, dec_deg: float, radius_deg: float = 0.5, log=print):
    key = f"coord_{round(ra_deg, 3)}_{round(dec_deg, 3)}"
    if key in _simbad_cache:
        return _simbad_cache[key]
    time.sleep(0.2)
    try:
        sim = Simbad()
        sim.add_votable_fields("otype")
        coord = SkyCoord(ra=ra_deg * u.deg, dec=dec_deg * u.deg, frame="fk5")
        tbl = sim.query_region(coord, radius=str(radius_deg) + "d")
        if tbl is None or len(tbl) == 0:
            _simbad_cache[key] = None
            return None
        chosen_id = None
        for row in tbl:
            if str(row["otype"]).strip() in INTERESTING_OTYPES:
                chosen_id = str(row["main_id"]).strip()
                break
        if not chosen_id:
            chosen_id = str(tbl[0]["main_id"]).strip()
        result, _ = _simbad_query(chosen_id, log=log)
        _simbad_cache[key] = result
        return result
    except Exception as e:
        log(f"SIMBAD coords error: {e}")
        _simbad_cache[key] = None
        return None
