"""
Offline astronomical object name lookup via the bundled OpenNGC catalog.

Data source: https://github.com/mattiaverga/OpenNGC (CC BY-SA 4.0)
CSV columns (semicolon-separated):
  0=Name, 1=Type, ..., 23=M, 24=NGC, 25=IC, ..., 28=Common names
"""

import csv
import re
from importlib import resources
from functools import lru_cache


def _normalize_key(name: str) -> str:
    """Normalize any catalog identifier to a compact uppercase key.

    Examples:
        'M 81'    → 'M81'
        'NGC 224' → 'NGC224'
        'IC0410'  → 'IC410'
        'm31'     → 'M31'
    """
    name = str(name).strip().upper()
    # Remove all spaces
    name = name.replace(" ", "")
    # Strip leading zeros in the numeric part
    m = re.match(r"^([A-Z]+)0*(\d+.*)$", name)
    if m:
        return m.group(1) + m.group(2)
    return name


def _pick_common_name(raw: str) -> str | None:
    """Return the best common name from a comma-separated OpenNGC field."""
    if not raw or not raw.strip():
        return None
    candidates = [c.strip() for c in raw.split(",") if c.strip()]
    if not candidates:
        return None
    # Prefer names with recognizable DSO keywords
    for c in candidates:
        if any(k in c for k in ("Nebula", "Galaxy", "Cluster", "Cloud",
                                  "Void", "Group", "Supercluster")):
            return c
    return candidates[0]


@lru_cache(maxsize=1)
def _load_catalog() -> dict[str, tuple[str, str | None]]:
    """
    Load NGC.csv once and build a normalized lookup dict.
    Returns: {normalized_key: (display_catalog_id, common_name_or_None)}

    Keys added per row:
    - From Name column:  e.g. 'NGC224'  → ('NGC224', 'Andromeda Galaxy')
    - From M column:     e.g. 'M31'     → ('M31',    'Andromeda Galaxy')
    - From IC column:    e.g. 'IC410'   → ('IC410',  'TadpolesNebula')  (for IC objects)
    """
    catalog: dict[str, tuple[str, str | None]] = {}

    csv_path = resources.files("astro_resolver").joinpath("data/NGC.csv")
    with resources.as_file(csv_path) as p:
        with open(p, encoding="utf-8", newline="") as f:
            reader = csv.reader(f, delimiter=";")
            next(reader)  # skip header
            for row in reader:
                if len(row) < 29:
                    continue
                name_col    = row[0].strip()   # e.g. "NGC0224"
                m_col       = row[23].strip()  # e.g. "031"
                ic_col      = row[25].strip()  # e.g. "" or "0410"
                common_raw  = row[28].strip()  # e.g. "Andromeda Galaxy,..."

                common = _pick_common_name(common_raw)

                # Determine the clean catalog ID from the Name column
                # "NGC0224" → "NGC224", "IC0410" → "IC410"
                name_key = _normalize_key(name_col)

                # Preferred display ID: Messier if available, else normalized Name
                if m_col:
                    try:
                        m_num = int(m_col)
                        display_id = f"M{m_num}"
                        m_key = f"M{m_num}"
                        catalog[m_key] = (display_id, common)
                    except ValueError:
                        display_id = name_key
                else:
                    display_id = name_key

                catalog[name_key] = (display_id, common)

                # Also index by IC number for IC objects (rare cross-refs)
                if ic_col:
                    try:
                        ic_key = f"IC{int(ic_col)}"
                        catalog[ic_key] = (ic_key, common)
                    except ValueError:
                        pass

    return catalog


def openngc_lookup(name: str) -> tuple[str, str] | None:
    """
    Look up a DSO in the bundled OpenNGC catalog.

    Args:
        name: Any common form of a catalog identifier, e.g.
              'M81', 'M 81', 'NGC3031', 'NGC 3031', 'IC410', 'IC 410'.

    Returns:
        (catalog_id, common_name) tuple, e.g. ('M81', "Bode's Galaxy"),
        or None if not found or no useful name available.
    """
    key = _normalize_key(name)
    entry = _load_catalog().get(key)
    if entry is None:
        return None
    catalog_id, common_name = entry
    # Only return entries with a useful common name
    if not common_name:
        return None
    return (catalog_id, common_name)
