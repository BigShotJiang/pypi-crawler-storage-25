"""
Shared constants for astronomical object name resolution.
Used by siril-export, rename-astro, dwarf-import and other tools.
"""

SOLAR_SYSTEM = {
    "sonne":   "Sun",       "sun":     "Sun",
    "mond":    "Moon",      "moon":    "Moon",
    "merkur":  "Mercury",   "mercury": "Mercury",
    "venus":   "Venus",     "mars":    "Mars",
    "jupiter": "Jupiter",
    "saturn":  "Saturn",
    "uranus":  "Uranus",
    "neptun":  "Neptune",   "neptune": "Neptune",
    "pluto":   "Pluto",
}

CUSTOM_ALIASES = {
    "tadpoles":               ("IC 410",     "TadpolesNebula"),
    "tadpoles mosaic":        ("IC 410",     "TadpolesNebula"),
    "tadpoles nebula":        ("IC 410",     "TadpolesNebula"),
    "tadpolesmosaic":         ("IC 410",     "TadpolesNebula"),
    "markarians chain":       (None,         "MarkarianChain"),
    "markarian chain":        (None,         "MarkarianChain"),
    "markarian's chain":      (None,         "MarkarianChain"),
    "markarianchain":         (None,         "MarkarianChain"),
    "medusa nebula":          ("Sh 2-274",   "MedusaNebula"),
    "abell 21":               ("Sh 2-274",   "MedusaNebula"),
    "sh2274":                 ("Sh 2-274",   "MedusaNebula"),
    "heart nebula":           ("IC 1805",    "HeartNebula"),
    "soul nebula":            ("IC 1848",    "SoulNebula"),
    "horsehead nebula":       ("Barnard 33", "HorseheadNebula"),
    "christmas tree cluster": ("NGC 2264",   "XmasTreeCluster"),
    "rosette nebula":         ("NGC 2237",   "RosetteNebula"),
    # NGC 3628 — OpenNGC has no entry; "Hamburger Galaxy" appears as FITS OBJECT value,
    # and 2MASXJ11192695 is the 2MASS ID the old resolver returned for the same object.
    "hamburger galaxy":       ("NGC 3628",   "Hamburger Galaxy"),
    "ngc 3628":               ("NGC 3628",   "Hamburger Galaxy"),
    "2masxj11192695":         ("NGC 3628",   "Hamburger Galaxy"),
    # NGC 4889 is Caldwell 35, but the migrate script extracts "NGC 4889" not "C 35",
    # so the Caldwell lookup never fires. Alias ensures the ComaB name is preserved.
    "ngc 4889":               ("NGC 4889",   "Coma B"),
    # Rosette Nebula NGC sub-entries — OpenNGC only knows "Rosette A/B/C" for these.
    # Map all components to the canonical NGC 2237 + well-known name.
    "ngc 2237":               ("NGC 2237",   "RosetteNebula"),
    "ngc 2238":               ("NGC 2237",   "RosetteNebula"),
    "ngc 2239":               ("NGC 2237",   "RosetteNebula"),
    "ngc 2246":               ("NGC 2237",   "RosetteNebula"),
}

CALDWELL_MAP = {
    1:  ("NGC 188",  "Polarissima Cluster"),    2:  ("NGC 40",   "Bow-Tie Nebula"),
    3:  ("NGC 4236", None),                      4:  ("NGC 7023", "Iris Nebula"),
    5:  ("IC 342",   "Hidden Galaxy"),           6:  ("NGC 6543", "Cat's Eye Nebula"),
    7:  ("NGC 2403", None),                      8:  ("NGC 559",  None),
    9:  ("Sh 2-155", "Cave Nebula"),            10:  ("NGC 663",  None),
    11: ("NGC 7635", "Bubble Nebula"),          12:  ("NGC 6946", "Fireworks Galaxy"),
    13: ("NGC 457",  "Owl Cluster"),            14:  ("NGC 869",  "Double Cluster"),
    15: ("NGC 6826", "Blinking Planetary"),     16:  ("NGC 7243", None),
    17: ("NGC 147",  None),                     18:  ("NGC 185",  None),
    19: ("IC 5146",  "Cocoon Nebula"),          20:  ("NGC 7000", "North America Nebula"),
    21: ("NGC 4449", None),                     22:  ("NGC 7662", "Blue Snowball"),
    23: ("NGC 891",  "Silver Sliver Galaxy"),   24:  ("NGC 1275", "Perseus A"),
    25: ("NGC 2419", None),                     26:  ("NGC 4244", None),
    27: ("NGC 6888", "Crescent Nebula"),        28:  ("NGC 752",  None),
    29: ("NGC 5005", None),                     30:  ("NGC 7331", None),
    31: ("IC 405",   "Flaming Star Nebula"),    32:  ("NGC 4631", "Whale Galaxy"),
    33: ("NGC 6992", "East Veil Nebula"),       34:  ("NGC 6960", "West Veil Nebula"),
    35: ("NGC 4889", "Coma B"),                 36:  ("NGC 4559", None),
    37: ("NGC 6885", None),                     38:  ("NGC 4565", "Needle Galaxy"),
    39: ("NGC 2392", "Eskimo Nebula"),          40:  ("NGC 3626", None),
    41: ("Mel 25",   "Hyades"),                 42:  ("NGC 7006", None),
    43: ("NGC 7814", None),                     44:  ("NGC 7479", "Superman Galaxy"),
    45: ("NGC 5248", None),                     46:  ("NGC 2261", "Hubble's Variable Nebula"),
    47: ("NGC 6934", None),                     48:  ("NGC 2775", None),
    49: ("NGC 2237", "Rosette Nebula"),         50:  ("NGC 2244", "Satellite Cluster"),
    51: ("IC 1613",  None),                     52:  ("NGC 4697", None),
    53: ("NGC 3115", "Spindle Galaxy"),         54:  ("NGC 2506", None),
    55: ("NGC 7009", "Saturn Nebula"),          56:  ("NGC 246",  "Skull Nebula"),
    57: ("NGC 6822", "Barnard's Galaxy"),       58:  ("NGC 2360", "Caroline's Cluster"),
    59: ("NGC 3242", "Ghost of Jupiter"),       60:  ("NGC 4038", "Antennae Galaxies"),
    61: ("NGC 4039", "Antennae Galaxies"),      62:  ("NGC 247",  None),
    63: ("NGC 7293", "Helix Nebula"),           64:  ("NGC 2362", "Tau Canis Majoris Cluster"),
    65: ("NGC 253",  "Sculptor Galaxy"),        66:  ("NGC 5694", None),
    67: ("NGC 1097", None),                     68:  ("NGC 6729", "R CrA Nebula"),
    69: ("NGC 6302", "Bug Nebula"),             70:  ("NGC 300",  "Sculptor Pinwheel Galaxy"),
    71: ("NGC 2477", None),                     72:  ("NGC 55",   "String of Pearls Galaxy"),
    73: ("NGC 1851", None),                     74:  ("NGC 3132", "Eight Burst Nebula"),
    75: ("NGC 6124", None),                     76:  ("NGC 6231", None),
    77: ("NGC 5128", "Centaurus A"),            78:  ("NGC 6541", None),
    79: ("NGC 3201", None),                     80:  ("NGC 5139", "Omega Centauri"),
    81: ("NGC 6352", None),                     82:  ("NGC 6193", None),
    83: ("NGC 4945", None),                     84:  ("NGC 5286", None),
    85: ("IC 2391",  "Omicron Velorum Cluster"),86:  ("NGC 6397", None),
    87: ("NGC 1261", None),                     88:  ("NGC 5823", None),
    89: ("NGC 6087", "S Normae Cluster"),       90:  ("NGC 2867", None),
    91: ("NGC 3532", "Wishing Well Cluster"),   92:  ("NGC 3372", "Eta Carinae Nebula"),
    93: ("NGC 6752", "Great Peacock Globular"), 94:  ("NGC 4755", "Jewel Box"),
    95: ("NGC 6025", None),                     96:  ("NGC 2516", "Southern Beehive Cluster"),
    97: ("NGC 3766", "Pearl Cluster"),          98:  ("NGC 4609", None),
    99: (None,       "Coalsack Nebula"),       100:  ("IC 2944",  "Lambda Centauri Nebula"),
   101: ("NGC 6744", None),                   102:  ("IC 2602",  "Theta Car Cluster"),
   103: ("NGC 2070", "Tarantula Nebula"),     104:  ("NGC 362",  None),
   105: ("NGC 4833", None),                   106:  ("NGC 104",  "47 Tucanae"),
   107: ("NGC 6101", None),                   108:  ("NGC 4372", None),
   109: ("NGC 3195", None),
}

CATALOG_PRIORITY = [
    "M ", "NGC ", "IC ", "C ",
    "Sh 2-", "SH 2-", "Sh2-", "SH2-",
    "B ", "LBN ", "LDN ",
]

CATALOG_BLACKLIST = {
    "TIC", "GAIA", "GAIADR2", "GAIADR3", "2MASS", "WISE", "ALLWISE",
    "SDSS", "TYC", "HIC", "HD", "HIP", "GSC", "UCAC", "USNO", "APASS", "PS1",
}

STAR_OTYPES = {"*", "**", "V*", "UV", "IR", "Em*", "Be*", "RR*", "Ce*", "WR*", "Er*"}

INTERESTING_OTYPES = {
    "G", "GNe", "EmG", "SyG", "AGN", "QSO",
    "GlC", "OpC", "Cl*",
    "HII", "SNR", "PN", "RNe", "MoC", "DNe",
    "mul", "grp", "MGr",
}

EMPTY_VALS = {"", "0", "0.0", "none", "n/a", "t", "f"}

# ── Sharpless HII regions (Sh 2-xxx) ──────────────────────────────────────────
# Only objects NOT already covered by NGC/IC/Caldwell/Aliases.
# Famous Sh2 objects that ARE in NGC/IC (e.g. Sh2-275=Rosette=NGC2237,
# Sh2-292=Seagull=IC2177) are handled by OpenNGC.
# Value: common name string, or None if no widely-used English name.
SHARPLESS_NAMES: dict[int, str | None] = {
    101: "TulipNebula",
    106: None,               # S106, no consensus common name
    129: "FlyingBatNebula",
    132: "LionNebula",
    157: "LobsterClawNebula",
    170: "LittleRosetteNebula",
    188: "ShrimpNebula",
    240: "Simeis147",        # also known as Spaghetti Nebula
    261: "LowersNebula",
    264: "MeissaRing",       # Lambda Orionis Ring
}

# ── Barnard dark nebulae (B xxx) ──────────────────────────────────────────────
BARNARD_NAMES: dict[int, str | None] = {
    33:  "HorseheadNebula",  # also in CUSTOM_ALIASES for English name input
    68:  None,
    72:  "SnakeNebula",
    78:  "PipeNebula",
    86:  "InkSpot",
    87:  "ParrotsHeadNebula",
    142: "BarnardsE",
    143: "BarnardsE",
}

# ── DSO catalog prefixes → skip SIMBAD otype check ────────────────────────────
# Matches catalog IDs we know are DSOs; avoids an unnecessary otype round-trip.
# Does NOT need to be exhaustive – it only saves one SIMBAD request.
import re as _re
DSO_CATALOG_RE = _re.compile(
    r"^(lbn|ldn|rcw|vdb|ced|gum|ngp)\s*\d",
    _re.IGNORECASE,
)

# ── Stellar catalog prefixes → skip directly to coord-based lookup ─────────────
# Objects from these catalogs are always stars; querying SIMBAD by name only
# confirms what we already know and wastes a round-trip.
# Go straight to simbad_lookup_by_coords when RA/DEC are available.
STELLAR_CATALOG_RE = _re.compile(
    r"^(HD|HIP|SAO|TYC|BD|GSC|UCAC|USNO|APASS|TIC|HR)\s*[\d+\-]",
    _re.IGNORECASE,
)
