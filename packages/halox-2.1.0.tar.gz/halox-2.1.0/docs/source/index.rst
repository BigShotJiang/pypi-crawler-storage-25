.. halox documentation master file, created by
   sphinx-quickstart on Fri Jun 13 14:43:28 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

*****
halox
*****

JAX-powered Python library for differentiable dark matter halo property and mass function calculations.

Installation
^^^^^^^^^^^^

``halox`` can be install via ``pip``:

.. code-block:: bash

   pip install halox

Learn more
^^^^^^^^^^

.. toctree::
   :maxdepth: 1
   :caption: Tutorials

   install
   notebooks/gradients.ipynb
   notebooks/using_the_emulator.ipynb
   notebooks/halox_vs_colossus.ipynb
   notebooks/others.ipynb


.. toctree::
   :maxdepth: 1
   :caption: Physics modules gallery

   notebooks/nfw.ipynb
   notebooks/einasto.ipynb
   notebooks/cMrelations.ipynb
   notebooks/lss.ipynb
   notebooks/hmf.ipynb
   notebooks/bias.ipynb


.. toctree::
   :maxdepth: 1
   :caption: Reference

   api/halox.cosmology
   api/halox.nfw
   api/halox.einasto
   api/halox.cm
   api/halox.lss
   api/halox.emus
   api/halox.hmf
   api/halox.bias
