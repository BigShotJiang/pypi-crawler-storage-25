"""Public Lumesof SDK import surface.

Import user-facing symbols from this module:

    from lumesof.lumeflow import Client, Graph, Job, SyncJobClient, Operator, Proto, Test
"""

from lumecode.lumeflow.runtime.v1.config_query_server.config_query_server_client import (
    ConfigQueryClientError,
    async_getRequiredStringConfigValue,
)
from lumecode.lumeflow.runtime.v1.flow_server import dag_pb2
from lumecode.lumeflow.runtime.v1.flow_server import flow_server_pb2
from lumecode.lumeflow.runtime.v1.operator.operator import Operator, operator_ports
from lumecode.lumeflow.runtime.v1.operator import operator_pb2
from lumecode.lumeflow.runtime.v1.graph.graph import Graph
from lumecode.lumeflow.runtime.v1.graph.graph import graph_type
from lumecode.lumeflow.runtime.v1.graph.graph import materialize
from lumecode.lumeflow.runtime.v1.operator.operator_image_descriptor import (
    OperatorImageDescriptor,
    OperatorPortDescriptor,
)
from lumecode.lumeflow.runtime.v1.opnet import opnet_types_pb2
from lumesof._lumeflow_sdk import (
    AsyncJobClient,
    Client,
    Job,
    JobClientTypeError,
    JobResolutionError,
    JobTypeMismatchError,
    SyncJobClient,
    Test,
    test,
)


class _ProtoNamespace:
    """Namespace of protobuf modules required by the public Lumeflow SDK."""

    flow_server = flow_server_pb2
    dag = dag_pb2
    opnet_types = opnet_types_pb2
    operator = operator_pb2


Proto = _ProtoNamespace()

__all__ = [
    "AsyncJobClient",
    "Client",
    "ConfigQueryClientError",
    "Graph",
    "Job",
    "JobClientTypeError",
    "JobResolutionError",
    "JobTypeMismatchError",
    "Operator",
    "OperatorImageDescriptor",
    "OperatorPortDescriptor",
    "Proto",
    "SyncJobClient",
    "operator_ports",
    "graph_type",
    "materialize",
    "Test",
    "async_getRequiredStringConfigValue",
    "dag_pb2",
    "flow_server_pb2",
    "opnet_types_pb2",
    "operator_pb2",
    "test",
]
