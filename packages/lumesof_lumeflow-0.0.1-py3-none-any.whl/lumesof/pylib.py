"""Public Lumesof SDK import surface.

Import user-facing symbols from this module:

    from lumesof.pylib import Net
"""

from lumecode.base.python.net.target_parser import NetTarget as _NetTarget


class _NetNamespace:
    NetTarget = _NetTarget


Net = _NetNamespace()

__all__ = [
    "Net",
]
