from __future__ import annotations

"""Public Lumesof Python SDK implementation.

This module intentionally contains the concrete implementations behind the
``lumesof.lumeflow`` public import surface. Types and methods documented here
are expected to be consumed directly by SDK users.
"""

import asyncio
from dataclasses import dataclass
import time
from typing import Callable
from typing import Literal

from lumecode.lumeflow.runtime.v1.flow_server import flow_server_pb2
from lumecode.lumeflow.runtime.v1.flow_server.flow_server_client import (
    FlowServerClient,
    FlowServerClientRpcError,
)
from lumecode.lumeflow.runtime.v1.opnet import opnet_types_pb2
from lumecode.lumeflow.runtime.v1.rpc_opnet_bridge.rpc_opnet_bridge_client import (
    RpcOpnetBridgeClient,
    RpcOpnetBridgeRequest,
)

JobType = Literal["sync", "async"]
ClientType = Literal["auto", "sync", "async"]

_JOB_TYPE_SYNCHRONOUS = "SYNCHRONOUS"
_JOB_TYPE_ASYNCHRONOUS = "ASYNCHRONOUS"
_START_JOB_READY_TIMEOUT_SECONDS = 60.0
_STATUS_POLL_INTERVAL_SECONDS = 0.5
_WAIT_FOR_STATUS_DEFAULT_TIMEOUT_SECONDS = 120.0
_SYNC_CALL_DEFAULT_TIMEOUT_MS = 5_000
_TERMINAL_JOB_STATUSES = frozenset({
    flow_server_pb2.JOB_STATUS_FAILED,
    flow_server_pb2.JOB_STATUS_CANCELLED,
    flow_server_pb2.JOB_STATUS_CANCEL_PENDING,
})


@dataclass
class JobResolutionError(Exception):
    """Raised when a job identifier cannot be resolved to an active Flow job.

    Attributes:
        jobId: Requested job id.
        reason: Human-readable lookup failure reason.
    """

    jobId: str
    reason: str


@dataclass
class JobClientTypeError(Exception):
    """Raised when an unsupported job client type selector is requested.

    Attributes:
        requestedType: Unsupported selector string supplied by the caller.
    """

    requestedType: str


@dataclass
class JobTypeMismatchError(Exception):
    """Raised when a caller requests sync/async behavior incompatible with a job.

    Attributes:
        jobId: Job identifier.
        requestedType: Requested client type.
        actualType: Actual job type inferred from Flow metadata.
    """

    jobId: str
    requestedType: str
    actualType: str


@dataclass(frozen=True)
class _JobSnapshot:
    jobId: str
    appId: str
    jobType: JobType


def _normalizeJobType(jobType: str) -> JobType:
    normalized = (jobType or "").strip().lower()
    if normalized in ("sync", _JOB_TYPE_SYNCHRONOUS.lower()):
        return "sync"
    if normalized in ("async", _JOB_TYPE_ASYNCHRONOUS.lower()):
        return "async"
    raise ValueError(f"Unsupported job type '{jobType}'.")


class Client:
    """Top-level SDK entrypoint for Flow lifecycle operations.

    ``Client`` wraps FlowServer RPCs and produces strongly-typed ``Job`` handles.
    It is responsible for submit/start/cancel/status operations and can
    rehydrate existing jobs by id.
    """

    def __init__(
        self,
        *,
        flowServerTarget: str,
        configServiceTarget: str = "",
        endpointRemapper: Callable[[str], str] | None = None,
    ) -> None:
        """Create an SDK client.

        Args:
            flowServerTarget: Flow server target. Accepts ``tcp://host:port`` or
                ``unix:///path``.
            configServiceTarget: Config-query target used by sync bridge clients.
            endpointRemapper: Optional endpoint remapper hook passed through to
                bridge-client discovery.
        """
        self._flowServerTarget = flowServerTarget
        self._configServiceTarget = configServiceTarget
        self._endpointRemapper = endpointRemapper
        self._flowServerClient = FlowServerClient(target=flowServerTarget)
        self._ownedSyncClients: set[SyncJobClient] = set()

    async def async_submitJob(
        self,
        request: flow_server_pb2.SubmitJobRequest,
        *,
        startJob: bool = False,
    ) -> "Job":
        """Submit a Flow DAG and return a ``Job`` handle.

        Args:
            request: ``SubmitJobRequest`` protobuf payload.
            startJob: When true, waits for ``CREATED`` then starts the job.

        Returns:
            Rehydrated ``Job`` object for the submitted id.
        """
        try:
            submitResponse = await self._flowServerClient.async_submitJob(request)
        except FlowServerClientRpcError as exc:
            enrichedError = await self._async_enrichSubmitJobRpcError(
                request=request,
                exc=exc,
            )
            raise enrichedError from exc
        if startJob:
            await self.async_startJobWhenReady(
                jobId=submitResponse.job_id,
            )
        snapshot = await self._async_getJobSnapshot(jobId=submitResponse.job_id)
        if snapshot is None:
            inferredType: JobType = "sync" if request.app_id.strip() else "async"
            snapshot = _JobSnapshot(
                jobId=submitResponse.job_id,
                appId=request.app_id.strip(),
                jobType=inferredType,
            )
        return Job(
            rootClient=self,
            jobId=snapshot.jobId,
            appId=snapshot.appId,
            jobType=snapshot.jobType,
        )

    async def _async_enrichSubmitJobRpcError(
        self,
        *,
        request: flow_server_pb2.SubmitJobRequest,
        exc: FlowServerClientRpcError,
    ) -> FlowServerClientRpcError:
        appId = request.app_id.strip()
        status = (exc.status or "").upper()
        message = exc.message or ""
        if not appId:
            return exc
        if "FAILED_PRECONDITION" not in status:
            return exc

        conflictJobIds: list[str] = []
        try:
            listResponse = await self.async_listJobs()
            for job in listResponse.jobs:
                if (job.app_id or "").strip() == appId:
                    conflictJobIds.append(job.job_id)
        except Exception:
            return exc

        if len(conflictJobIds) == 0:
            return exc

        summarizedIds = ", ".join(conflictJobIds[:3])
        if len(conflictJobIds) > 3:
            summarizedIds = f"{summarizedIds}, ..."
        enrichedMessage = (
            f"{message} app_id conflict: app_id='{appId}' is already used by active "
            f"job_id(s): {summarizedIds}."
        )
        return FlowServerClientRpcError(
            rpcName=exc.rpcName,
            status=exc.status,
            message=enrichedMessage,
        )

    async def async_getJob(self, *, jobId: str) -> "Job":
        """Load an active job handle from Flow by id.

        Args:
            jobId: Flow job id string.

        Raises:
            JobResolutionError: If no active job matches ``jobId``.
        """
        snapshot = await self._async_getJobSnapshot(jobId=jobId)
        if snapshot is None:
            raise JobResolutionError(jobId=jobId, reason="job not found in active jobs list")
        return Job(
            rootClient=self,
            jobId=snapshot.jobId,
            appId=snapshot.appId,
            jobType=snapshot.jobType,
        )

    async def async_rehydrateJob(self, *, jobId: str) -> "Job":
        """Rehydrate a ``Job`` from a known Flow job id."""
        return await self.async_getJob(jobId=jobId)

    async def async_startJob(self, *, jobId: str) -> flow_server_pb2.StartJobResponse:
        """Issue a direct StartJob RPC for ``jobId``."""
        return await self._flowServerClient.async_startJob(
            flow_server_pb2.StartJobRequest(job_id=jobId)
        )

    async def async_startJobWhenReady(
        self,
        *,
        jobId: str,
        timeoutSeconds: float = _START_JOB_READY_TIMEOUT_SECONDS,
    ) -> flow_server_pb2.StartJobResponse:
        """Start a job after it reaches ``CREATED`` status."""
        deadline = time.monotonic() + max(timeoutSeconds, 1.0)
        while True:
            statusResponse = await self.async_getJobStatus(jobId=jobId)
            status = statusResponse.status
            if status == flow_server_pb2.JOB_STATUS_CREATED:
                return await self.async_startJob(jobId=jobId)
            if status == flow_server_pb2.JOB_STATUS_STARTED:
                return flow_server_pb2.StartJobResponse(job_id=jobId)
            if status in _TERMINAL_JOB_STATUSES:
                statusName = flow_server_pb2.JobStatus.Name(status)
                reason = statusResponse.message.strip()
                msg = f"Job {jobId} reached {statusName} before StartJob"
                raise RuntimeError(f"{msg}: {reason}" if reason else msg)
            if time.monotonic() >= deadline:
                statusName = flow_server_pb2.JobStatus.Name(status)
                raise TimeoutError(
                    f"Timed out waiting for job {jobId} to reach CREATED "
                    f"(last_status={statusName})"
                )
            await asyncio.sleep(_STATUS_POLL_INTERVAL_SECONDS)

    async def async_cancelJob(self, *, jobId: str, reason: str = "") -> flow_server_pb2.CancelJobResponse:
        """Cancel a job by id."""
        return await self._flowServerClient.async_cancelJob(
            flow_server_pb2.CancelJobRequest(
                job_id=jobId,
                reason=reason,
            )
        )

    async def async_getJobStatus(self, *, jobId: str) -> flow_server_pb2.GetJobStatusResponse:
        """Fetch current status for a job id."""
        return await self._flowServerClient.async_getJobStatus(
            flow_server_pb2.GetJobStatusRequest(job_id=jobId)
        )

    async def async_listJobs(self) -> flow_server_pb2.ListResponse:
        """List active jobs visible to Flow server."""
        return await self._flowServerClient.async_listJobs(
            flow_server_pb2.ListRequest()
        )

    async def async_injectMessage(
        self,
        *,
        jobId: str,
        message: opnet_types_pb2.OpNetMessage,
    ) -> flow_server_pb2.InjectMessageResponse:
        """Inject an OpNet message into an async job."""
        request = flow_server_pb2.InjectMessageRequest(job_id=jobId)
        request.message.CopyFrom(message)
        return await self._flowServerClient.async_injectMessage(request)

    async def async_close(self) -> None:
        """Close SDK-owned resources.

        Currently closes sync bridge clients created through ``Job.syncClient()``
        / ``Job.client(type="sync")``.
        """
        for client in list(self._ownedSyncClients):
            await client.async_close()
        self._ownedSyncClients.clear()

    async def _async_getJobSnapshot(self, *, jobId: str) -> _JobSnapshot | None:
        listResponse = await self.async_listJobs()
        for job in listResponse.jobs:
            if job.job_id != jobId:
                continue
            return _JobSnapshot(
                jobId=job.job_id,
                appId=job.app_id,
                jobType=_normalizeJobType(job.job_type),
            )
        return None

    def _registerSyncClient(self, *, client: "SyncJobClient") -> None:
        self._ownedSyncClients.add(client)


class Job:
    """Handle object representing one submitted Flow job.

    ``Job`` provides typed client selection for sync/async jobs and convenience
    wrappers for status, start, and cancel operations.
    """

    def __init__(
        self,
        *,
        rootClient: Client,
        jobId: str,
        appId: str,
        jobType: str,
    ) -> None:
        self._rootClient = rootClient
        self._jobId = jobId
        self._appId = (appId or "").strip()
        self._jobType = _normalizeJobType(jobType)

    def id(self) -> str:
        """Return the Flow job id."""
        return self._jobId

    def type(self) -> JobType:
        """Return normalized job type: ``\"sync\"`` or ``\"async\"``."""
        return self._jobType

    def client(self, *, type: ClientType = "auto"):
        """Return a client suitable for this job.

        Args:
            type: ``\"auto\"``, ``\"sync\"``, or ``\"async\"``.

        Returns:
            ``SyncJobClient`` or ``AsyncJobClient``.
        """
        requestedType = (type or "").strip().lower()
        if requestedType not in ("auto", "sync", "async"):
            raise JobClientTypeError(requestedType=requestedType)
        resolvedType = self._jobType if requestedType == "auto" else requestedType
        if resolvedType == "sync":
            self._validateClientType(requestedType="sync")
            if not self._appId:
                raise JobResolutionError(
                    jobId=self._jobId,
                    reason="sync client requires a non-empty app_id",
                )
            client = SyncJobClient(
                appId=self._appId,
                configServiceTarget=self._rootClient._configServiceTarget,
                endpointRemapper=self._rootClient._endpointRemapper,
            )
            self._rootClient._registerSyncClient(client=client)
            return client
        self._validateClientType(requestedType="async")
        return AsyncJobClient(
            rootClient=self._rootClient,
            jobId=self._jobId,
        )

    def syncClient(self):
        """Return a ``SyncJobClient`` for synchronous jobs."""
        return self.client(type="sync")

    def asyncClient(self):
        """Return an ``AsyncJobClient`` for asynchronous jobs."""
        return self.client(type="async")

    async def async_cancel(self, *, reason: str = "") -> flow_server_pb2.CancelJobResponse:
        """Cancel this job."""
        return await self._rootClient.async_cancelJob(jobId=self._jobId, reason=reason)

    async def async_startWhenReady(
        self,
        *,
        timeoutSeconds: float = _START_JOB_READY_TIMEOUT_SECONDS,
    ) -> flow_server_pb2.StartJobResponse:
        """Start this job after it reaches ``CREATED``."""
        return await self._rootClient.async_startJobWhenReady(
            jobId=self._jobId,
            timeoutSeconds=timeoutSeconds,
        )

    async def async_getStatus(self) -> flow_server_pb2.GetJobStatusResponse:
        """Fetch current status for this job."""
        return await self._rootClient.async_getJobStatus(jobId=self._jobId)

    async def async_getStatusName(self) -> str:
        """Fetch current status and return enum name string."""
        status = await self.async_getStatus()
        return self.statusName(status.status)

    def statusName(self, status: int) -> str:
        """Convert a ``JobStatus`` enum numeric value to its symbolic name."""
        return flow_server_pb2.JobStatus.Name(status)

    async def async_waitForStatus(
        self,
        *,
        targetStatus: int,
        timeoutSeconds: float = _WAIT_FOR_STATUS_DEFAULT_TIMEOUT_SECONDS,
        pollIntervalSeconds: float = _STATUS_POLL_INTERVAL_SECONDS,
    ) -> flow_server_pb2.GetJobStatusResponse:
        """Poll until the job reaches ``targetStatus``.

        Raises:
            RuntimeError: If the job enters a terminal non-target status first.
            TimeoutError: If timeout elapses before target status is reached.
        """
        deadline = time.monotonic() + max(timeoutSeconds, 1.0)
        interval = max(pollIntervalSeconds, 0.05)
        targetName = flow_server_pb2.JobStatus.Name(targetStatus)
        while True:
            statusResponse = await self.async_getStatus()
            if statusResponse.status == targetStatus:
                return statusResponse
            if statusResponse.status in _TERMINAL_JOB_STATUSES:
                statusName = flow_server_pb2.JobStatus.Name(statusResponse.status)
                reason = statusResponse.message.strip()
                msg = (
                    f"Job {self._jobId} reached {statusName} before {targetName}"
                )
                raise RuntimeError(f"{msg}: {reason}" if reason else msg)
            if time.monotonic() >= deadline:
                statusName = flow_server_pb2.JobStatus.Name(statusResponse.status)
                raise TimeoutError(
                    f"Timed out waiting for job {self._jobId} to reach {targetName} "
                    f"(last_status={statusName})"
                )
            await asyncio.sleep(interval)

    def _validateClientType(self, *, requestedType: JobType) -> None:
        if requestedType == self._jobType:
            return
        raise JobTypeMismatchError(
            jobId=self._jobId,
            requestedType=requestedType,
            actualType=self._jobType,
        )


class SyncJobClient:
    """Synchronous-job RPC bridge client.

    This class hides low-level bridge request/response types behind a stable
    payload-oriented API.
    """

    def __init__(
        self,
        *,
        appId: str,
        configServiceTarget: str,
        endpointRemapper: Callable[[str], str] | None = None,
    ) -> None:
        """Create a sync bridge client.

        Args:
            appId: Application id used for bridge endpoint lookup.
            configServiceTarget: Config-query target used for endpoint discovery.
            endpointRemapper: Optional endpoint rewrite hook.
        """
        if not appId.strip():
            raise ValueError("appId must be provided")
        if not configServiceTarget.strip():
            raise ValueError("configServiceTarget must be provided")
        self._appId = appId.strip()
        self._configServiceTarget = configServiceTarget.strip()
        self._endpointRemapper = endpointRemapper
        self._delegate: RpcOpnetBridgeClient | None = None
        self._delegateInitLock = asyncio.Lock()

    async def async_call(
        self,
        *,
        payload: bytes,
        payloadTypeUrl: str,
        payloadSerializationFormat: int = int(opnet_types_pb2.OpNetPayloadType.PROTO),
        deadlineTsUnixMs: int = 0,
        timeoutMs: int = _SYNC_CALL_DEFAULT_TIMEOUT_MS,
    ) -> bytes:
        """Make a bridge API call and return response payload bytes.

        Args:
            payload: Serialized request payload.
            payloadTypeUrl: Protobuf type-url of ``payload``.
            payloadSerializationFormat: Serialization format enum value.
            deadlineTsUnixMs: Optional absolute deadline in unix-ms.
            timeoutMs: Relative timeout used when no absolute deadline is given.
        """
        resolvedDeadline = deadlineTsUnixMs
        if resolvedDeadline <= 0:
            resolvedDeadline = int(time.time() * 1000) + max(timeoutMs, 1)
        request = RpcOpnetBridgeRequest(
            payload=payload,
            deadline_ts_unix_ms=resolvedDeadline,
            payload_serialization_format=payloadSerializationFormat,
            payload_type_url=payloadTypeUrl,
        )
        delegate = await self._async_getDelegate()
        response = await delegate.async_makeApiCall(request)
        if not response.ok:
            message = response.error.strip() if response.error else "bridge call failed"
            raise RuntimeError(message)
        return response.payload

    async def async_close(self) -> None:
        """Close underlying bridge sessions and release resources."""
        async with self._delegateInitLock:
            if self._delegate is None:
                return
            await self._delegate.async_close()
            self._delegate = None

    async def _async_getDelegate(self) -> RpcOpnetBridgeClient:
        if self._delegate is not None:
            return self._delegate
        async with self._delegateInitLock:
            if self._delegate is not None:
                return self._delegate
            self._delegate = await RpcOpnetBridgeClient.async_fromConfigService(
                app_id=self._appId,
                config_service_target=self._configServiceTarget,
                endpoint_remapper=self._endpointRemapper,
            )
            return self._delegate


class AsyncJobClient:
    """Asynchronous-job client for direct message injection."""

    def __init__(self, *, rootClient: Client, jobId: str) -> None:
        self._rootClient = rootClient
        self._jobId = jobId

    async def async_injectMessage(
        self,
        *,
        message: opnet_types_pb2.OpNetMessage,
    ) -> flow_server_pb2.InjectMessageResponse:
        """Inject an OpNet message into this async job."""
        return await self._rootClient.async_injectMessage(
            jobId=self._jobId,
            message=message,
        )


class _TestNamespace:
    def __getattr__(self, name: str):
        if name == "standalone_operator_sidecar":
            from lumecode.lumeflow.runtime.v1.test_utils import standalone_operator_sidecar

            return standalone_operator_sidecar
        if name == "FileBackedOpNetProxy":
            from lumecode.lumeflow.runtime.v1.test_utils.file_backed_opnet_proxy import (
                FileBackedOpNetProxy,
            )

            return FileBackedOpNetProxy
        if name == "encodeDelimitedMessage":
            from lumecode.lumeflow.runtime.v1.test_utils.file_backed_opnet_proxy import (
                _encodeDelimitedMessage,
            )

            return _encodeDelimitedMessage
        if name == "decodeDelimitedDeliverRequests":
            from lumecode.lumeflow.runtime.v1.test_utils.file_backed_opnet_proxy import (
                _decodeDelimitedDeliverRequests,
            )

            return _decodeDelimitedDeliverRequests
        if name in ("IngressGenerator", "EgressVerifier", "StandaloneOperatorTestDriver"):
            from lumecode.lumeflow.runtime.v1.test_utils.standalone_operator_test_driver import (
                EgressVerifier,
                IngressGenerator,
                StandaloneOperatorTestDriver,
            )

            lookup = {
                "IngressGenerator": IngressGenerator,
                "EgressVerifier": EgressVerifier,
                "StandaloneOperatorTestDriver": StandaloneOperatorTestDriver,
            }
            return lookup[name]
        if name in (
            "AsyncGeneratorAndVerifier",
            "BasePublisher",
            "FlowServerFactoryContext",
            "StandaloneGraphRunContext",
            "StandaloneGraphTestDriver",
            "SyncGeneratorAndVerifier",
        ):
            from lumecode.lumeflow.runtime.v1.test_utils.standalone_graph_test_driver import (
                AsyncGeneratorAndVerifier,
                BasePublisher,
                FlowServerFactoryContext,
                StandaloneGraphRunContext,
                StandaloneGraphTestDriver,
                SyncGeneratorAndVerifier,
            )

            lookup = {
                "AsyncGeneratorAndVerifier": AsyncGeneratorAndVerifier,
                "BasePublisher": BasePublisher,
                "FlowServerFactoryContext": FlowServerFactoryContext,
                "StandaloneGraphRunContext": StandaloneGraphRunContext,
                "StandaloneGraphTestDriver": StandaloneGraphTestDriver,
                "SyncGeneratorAndVerifier": SyncGeneratorAndVerifier,
            }
            return lookup[name]
        raise AttributeError(name)


Test = _TestNamespace()
# Backward-compatible alias; prefer `Test`.
test = Test
