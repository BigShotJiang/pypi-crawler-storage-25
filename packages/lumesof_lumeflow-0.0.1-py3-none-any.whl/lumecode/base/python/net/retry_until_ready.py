from __future__ import annotations

import asyncio
import errno
import logging
import time
from dataclasses import dataclass
from typing import Awaitable, Callable, TypeVar

T = TypeVar("T")

logger = logging.getLogger(__name__)

_DEFAULT_BACKOFF_MS = 500
_DEFAULT_DEADLINE_SECONDS = 300.0


@dataclass(frozen=True)
class RetryUntilReadyConfig:
    backoffMs: int = _DEFAULT_BACKOFF_MS
    deadlineSeconds: float = _DEFAULT_DEADLINE_SECONDS


class RetryDeadlineExceededError(TimeoutError):
    pass


class RetryUntilReady:
    def __init__(
        self,
        *,
        config: RetryUntilReadyConfig | None = None,
        isRetryableError: Callable[[BaseException], bool] | None = None,
    ) -> None:
        self._config = config or RetryUntilReadyConfig()
        if self._config.backoffMs < 0:
            raise ValueError(f"backoffMs must be >= 0, got {self._config.backoffMs}")
        if self._config.deadlineSeconds <= 0:
            raise ValueError(
                f"deadlineSeconds must be > 0, got {self._config.deadlineSeconds}"
            )
        self._isRetryableErrorFn = isRetryableError or self._isConnectionRefusedError

    async def async_retryUntilReady(
        self,
        *,
        invocation: Callable[[], Awaitable[T]],
        operationName: str = "rpc",
    ) -> T:
        attempt = 0
        startedAt = time.monotonic()
        deadlineAt = startedAt + self._config.deadlineSeconds

        while True:
            attempt += 1
            try:
                return await invocation()
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                if not self._isRetryableErrorFn(exc):
                    raise

                now = time.monotonic()
                if now >= deadlineAt:
                    elapsed = now - startedAt
                    raise RetryDeadlineExceededError(
                        f"retryUntilReady deadline exceeded operation={operationName} "
                        f"attempts={attempt} elapsed_s={elapsed:.3f} "
                        f"last_error={type(exc).__name__}: {exc}"
                    ) from exc

                if attempt == 1 or (attempt % 20) == 0:
                    logger.info(
                        f"retryUntilReady waiting for dependency operation={operationName} "
                        f"attempt={attempt} error={type(exc).__name__}: {exc}",
                        extra={
                            "event": "lumesof.retry_until_ready.waiting",
                            "operation": operationName,
                            "attempt": attempt,
                            "error_type": type(exc).__name__,
                            "error_message": str(exc),
                        },
                    )

                sleepSeconds = min(
                    self._config.backoffMs / 1000.0,
                    max(0.0, deadlineAt - now),
                )
                if sleepSeconds > 0:
                    await asyncio.sleep(sleepSeconds)
                else:
                    await asyncio.sleep(0)

    def _isConnectionRefusedError(self, exc: BaseException) -> bool:
        for chained in self._iterExceptionChain(exc):
            if isinstance(chained, ConnectionRefusedError):
                return True
            if isinstance(chained, FileNotFoundError):
                return True
            if isinstance(chained, OSError):
                if chained.errno in (errno.ECONNREFUSED, errno.ENOENT):
                    return True
                if "connection refused" in str(chained).lower():
                    return True
        return False

    def _iterExceptionChain(self, exc: BaseException):
        current: BaseException | None = exc
        seen: set[int] = set()
        while current is not None and id(current) not in seen:
            seen.add(id(current))
            yield current
            if current.__cause__ is not None:
                current = current.__cause__
                continue
            current = current.__context__


__all__ = [
    "RetryDeadlineExceededError",
    "RetryUntilReady",
    "RetryUntilReadyConfig",
]
