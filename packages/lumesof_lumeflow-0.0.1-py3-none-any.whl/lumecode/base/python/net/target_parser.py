from __future__ import annotations

import os
import sys
from typing import Any, Optional


class NetTarget:
    def __init__(
        self,
        host: Optional[str],
        port: Optional[int],
        path: Optional[str],
        *,
        udsMode: Optional[int] = None,
    ) -> None:
        self._host = host
        self._port = port
        self._path = path
        self._udsMode = self._validateUdsMode(udsMode)

    @classmethod
    def parseTarget(cls, target: str) -> "NetTarget":
        if not target:
            raise ValueError("target must be provided")

        t = target.strip()

        # Accept bare unix socket paths like "/path/to.sock"
        if t.startswith("/"):
            return cls(None, None, t)

        if t.startswith("unix:///"):
            pathSuffix = t[len("unix:///") :].lstrip("/")
            if not pathSuffix:
                raise ValueError("unix target must include a socket path")
            return cls(None, None, f"/{pathSuffix}")

        if t.startswith("unix:"):
            raise ValueError("unix target must start with unix:///")

        if not t.startswith("tcp://"):
            raise ValueError("target must start with tcp:// or unix:///")

        rest = t[len("tcp://") :]
        host, sep, port_str = rest.rpartition(":")
        if not sep or not host or not port_str:
            raise ValueError("target must be host:port or unix:///path")
        try:
            port = int(port_str)
        except ValueError as exc:
            raise ValueError("target must include a valid port") from exc
        return cls(host, port, None)

    def getHost(self) -> Optional[str]:
        return self._host

    def getPort(self) -> Optional[int]:
        return self._port

    def getPath(self) -> Optional[str]:
        return self._path

    def getUdsMode(self) -> Optional[int]:
        return self._udsMode

    def withUdsMode(self, mode: int) -> "NetTarget":
        return NetTarget(
            host=self._host,
            port=self._port,
            path=self._path,
            udsMode=mode,
        )

    async def async_bindGrpclibServer(
        self,
        server: Any,
        *,
        sslContext: Any | None = None,
    ) -> None:
        if self._path is not None:
            await server.start(path=self._path, ssl=sslContext)
            self._applyUdsModeIfNeeded()
            return
        host, port = self._requireTcpTarget()
        await server.start(host, port, ssl=sslContext)

    async def async_bindGrpcAioServer(
        self,
        server: Any,
        *,
        serverCredentials: Any | None = None,
    ) -> int:
        if self._path is not None:
            bindTarget = f"unix://{self._path}"
        else:
            host, port = self._requireTcpTarget()
            bindTarget = f"{host}:{port}"

        if serverCredentials is None:
            boundPort = int(server.add_insecure_port(bindTarget))
        else:
            boundPort = int(server.add_secure_port(bindTarget, serverCredentials))
        if boundPort == 0:
            raise RuntimeError(f"failed binding gRPC server target: {bindTarget}")

        await server.start()
        self._applyUdsModeIfNeeded()
        return boundPort

    @staticmethod
    def _validateUdsMode(mode: Optional[int]) -> Optional[int]:
        if mode is None:
            return None
        if not isinstance(mode, int):
            raise ValueError("uds mode must be an integer.")
        if mode < 0 or mode > 0o777:
            raise ValueError("uds mode must be in range [0o000, 0o777].")
        return mode

    def _requireTcpTarget(self) -> tuple[str, int]:
        if self._host is None or self._port is None:
            raise ValueError("target is not tcp://host:port")
        return self._host, self._port

    def _applyUdsModeIfNeeded(self) -> None:
        if self._path is None or self._udsMode is None:
            return
        os.chmod(self._path, self._udsMode)


def parseTarget(target: str) -> tuple[str, Optional[int], Optional[str]]:
    print(
        "DeprecationWarning: parseTarget() is deprecated; "
        "use NetTarget.parseTarget().",
        file=sys.stderr,
    )
    parsedTarget = NetTarget.parseTarget(target)
    parsedHost = parsedTarget.getHost()
    return (
        parsedHost if parsedHost is not None else "",
        parsedTarget.getPort(),
        parsedTarget.getPath(),
    )


__all__ = ["NetTarget", "parseTarget"]
