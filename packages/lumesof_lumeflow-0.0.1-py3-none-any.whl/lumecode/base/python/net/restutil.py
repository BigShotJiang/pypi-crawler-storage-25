"""
Copyright (C) 2023 Cascade Enrichment, LLC. All Rights Reserved.
You may not use, distribute, or modify this code without explicit
written permission from Cascade Enrichment.
"""

""" A module to simplify making REST requests to remote web servers.

The primary class implemented by this module is 'Client', which enables making
REST requests to remote web servers. A 'Client' object can optionally be
configured with various types of credentials, which the client then presents to
the web server.

Many web servers employ rate limiting on their API endpoints. To comply with
such policies, this module provides a class called 'Backoff'. A Backoff object
implemnts exponential backoff and linear ramp up. A Backoff object should
typically be shared between the clients making requests to the same web server.

"""

from datetime import date, datetime

import base64
import copy
import logging
import requests
import time
import threading


class Credential:
    """A class to hold a REST credential.

    A Credential object is used to hold a single REST credential. The supported
    types of credentials can be converted to appropriate HTTP header strings
    using the <type>_header_string cred_type. If you add a new auth cred_type,
    do not forget to add the corresponding cred_type to the AUTH_PROCESSORS
    dictionary below.

    Public Attributes: None
    """

    _supported_auth_types = {"token", "bearer", "basic", "apikey"}

    def __init__(self, *, cred_type: str, cred: str):
        """Initializes a Credential object.

        Args:
          cred_type:
            Type of credntial.
          cred:
            The actual credential.
        """

        if cred_type.lower() not in Credential._supported_auth_types:
            raise NotImplementedError(
                "Auth cred_type {} is not supported".format(cred_type)
            )
        self.cred_type = cred_type.lower()
        self.cred = cred

    def __str__(self) -> str:
        """Converts a credential to a header string.

        Args: None

        Returns:
          A formatted string that can be included in Authorization header of an
          HTTP request. Multiple such strings can be concatenated together,
          separated by commas, and included in a single Authroization header.

        Raises:
          NotImplementedError:
            If the cred_type of the object is not one of the supported types.
        """
        if self.cred_type == "token":
            return "Token token={}".format(self.cred)
        if self.cred_type == "bearer":
            return "Bearer {}".format(self.cred)
        if self.cred_type == "basic":
            byte_string = self.cred.encode("utf-8")
            base64_bytes = base64.b64encode(byte_string)
            return "Basic {}".format(base64_bytes.decode("utf-8"))
        if self.cred_type == "apikey":
            return self.cred
        raise NotImplementedError(
            "Auth cred_type {} is not supported".format(self.cred_type)
        )

    def getHeaderKey(self):
        """Returns the header name.

        Args: None

        Returns:
          Returns 'Authorization' for all cred types except for 'apikey', where
          it return 'x-api-key'.

        Raises:
          NotImplementedError:
            If the cred_type of the object is not one of the supported types.
        """
        if self.cred_type.lower() not in Credential._supported_auth_types:
            raise NotImplementedError(
                "Auth cred_type {} is not supported".format(self.cred_type)
            )

        if self.cred_type == "apikey":
            return "x-api-key"
        return "Authorization"


class Backoff:
    """A class to implement exponential backoff.

    A Backoff object is used to implement exponential backoff in web requests. A
    number of REST API providers implement rate limits, and bombarding those
    endpoints with high QPS can result in 403 errors. The Backoff object
    implements exponential backoff with linear cooldown to adjust its request
    rate to something that is acceptable by the REST API server.
    """

    def __init__(self, *, backoff_us: int):
        """Initializes the Backoff object.

        Args:
          backoff_us:
            Initial value of the backoff period. This value gets adjusted
            based on the reported success or failure of the REST requests.
        """
        if backoff_us <= 0:
            raise ValueError("Initial backoff period cannot be negative")

        self._original_backoff_us: int = backoff_us
        self._backoff_us: int = backoff_us
        self._last_req_time = datetime.now()
        self._lock = threading.Lock()

    def wait(self):
        """Waits until the current backoff period has elapsed.

        This method is thread-safe.
        """
        with self._lock:
            delta = datetime.now() - self._last_req_time
            us_since_last_call = delta.seconds * 1000000 + delta.microseconds
            if us_since_last_call < self._backoff_us:
                wait_time: float = (
                    float(self._backoff_us - us_since_last_call) / 1000000.0
                )
                time.sleep(wait_time)
            self._last_req_time = datetime.now()

    def report_success(self):
        """Report successful completion of a REST request.

        The object reduces its backoff duration in response to this call.
        """
        if self._backoff_us > self._original_backoff_us:
            self._backoff_us: int = self._backoff_us - self._original_backoff_us

    def report_failure(self):
        """Report successful completion of a REST request.

        The object increases its backoff duration in response to this call.
        """
        self._backoff_us: int = 2 * self._backoff_us


class Client:
    """A Client for initiating REST requests to an API server.

    The client supports making authenticated REST calls. It also supports
    changing the API endpoint from one request to another, and provides
    mechanisms for passing REST API parameters.
    """

    HTTP_OK: int = 200
    HTTP_OK_NO_CONTENT: int = 204
    HTTP_TOO_MANY_REQS: int = 429

    def __init__(
        self,
        *,
        base_url: str,
        headers: dict[str, str] = None,
        creds: list[Credential] = None,
        num_retries: int = 5,
        backoff: Backoff = None
    ):
        """Initializes a restutil Client

        Args:
          base_url:
                Base URL of the API server. This should be the longest URL path
                that is shared between the various endpoints exposed by the API
                server.
          headers:
                A list of HTTP headers to include with every REST request made
                using this Client.
          creds:
                A list of Credential objects to be used with every REST request
                made using this Client. Additional credentials can be added
                using the add_creds() method below.
          num_retries:
                Number of times each REST request is tried before raising an
                exception.

          backoff:
                The Backoff object to be used with this restutil Client. This
                object is copied into the Client by reference, and as such, any
                changes made to this object by the client will be reflected
                elsewhere where the same object is being used. Note that
                multiple Client objects can share the same Backoff object.

          Raises:
            TypeError:
              If 'backoff' is neither None nor an instance of the Backoff
              object.
        """
        self._base_url: str = base_url
        self._headers: dict[str, str] = {}
        if headers is not None:
            if (
                "Content-Type" in headers
                or "Accept" in headers
                or "Authorization" in headers
            ):
                raise ValueError(
                    "Cannot specify Content-Type, Accept, or Authorization headers"
                )
            self._headers: dict[str, str] = copy.copy(headers)
        self._headers["Content-Type"] = "application/json"
        self._headers["Accept"] = "application/json"
        if creds is None:
            self._creds: list[Credential] = []
        else:
            self._creds = copy.copy(creds)
        self._num_retries = num_retries
        if backoff is None:
            self._backoff: Backoff = Backoff(backoff_us=500000)
        else:
            if not isinstance(backoff, Backoff):
                raise TypeError("The 'backoff' param must be an instance of Backoff")
            self._backoff: Backoff = backoff  # Do not make a copy of backoff.
        self._auth_header_added: bool = False
        self._lock = threading.Lock()

    def _add_auth_header(self):
        """Private method to prepare and add auth header based on credentials"""
        with self._lock:
            if self._auth_header_added:
                return
            self._auth_header_added = True
            if len(self._creds) == 0:
                return
            for cred in self._creds:
                self._headers[cred.getHeaderKey()] = str(cred)

    def __create_rest_url(self, base: str, ep: str, params: dict[str, str]):
        """Private method to join URL pieces."""
        web_address = "/".join([base.rstrip("/"), ep.lstrip("/")]).rstrip("/")
        if params is None:
            return web_address

        # To simplify testing, always join the parameters in alphabetical order.
        formatted_params: list[str] = []
        param_names = list(params.keys())
        param_names.sort()
        for name in param_names:
            value = params[name]
            formatted_params.append("=".join([name, value]))
        params_str = "&".join(formatted_params)
        return "?".join([web_address, params_str])

    def add_creds(self, *, creds: list[Credential]):
        """Adds a list of HTTP auth credentials to the client.

        The add_creds() method adds a list of credentials to the client. This
        method can be called multiple times until the client is used for making
        its first REST request, after which new credentials are not accepted.
        All of the provided credentials are converted to a single authorization
        header, which is then used with all REST requests.

        Args:
            creds:
                A list of credential objects to be added.
        """
        if self._auth_header_added == True:
            raise RuntimeError(
                "Cannot add creds after using the client to make requests"
            )
        for cred in creds:
            self._creds.append(cred)

    def get(self, *, endpoint: str = "", params: dict[str, str] = None):
        """Makes an HTTP GET request to the REST server

        The get() method is used for making REST GET requests. The method allows
        specifying an "endpoint", which gets appended to the REST server's base
        URL.  The supplied parameters are appended to the endpoint URL in the
        form param1=val1&param2=val2, etc.

        Args:
            endpoint:
                The API endpoint on the server. Can be empty ('').
            params:
                API parameters stored in an str => str dictionary. The
                dictionary can be empty, or this parameter can be set to None.
                The parameters are appended at the end of the base_urs/endpoint
                in the format ?key1=value1&key2=value2...
        Returns:
            On success, returns the JSON response from the server.

        Raises:
            TimeoutError:
                If the server responds with a status code other than HTTP OK
                (200) successively more than self._num_retries times.
        """
        rest_url: str = self.__create_rest_url(self._base_url, endpoint, params)
        self._add_auth_header()

        self._backoff.wait()
        response = requests.get(rest_url, headers=self._headers)
        attempt: int = 1
        while response.status_code != self.HTTP_OK:
            logging.error("Got REST status code {}".format(response.status_code))
            self._backoff.report_failure()
            if attempt >= self._num_retries:
                raise TimeoutError(
                    "Could not retrieve {} after {} attempts".format(
                        rest_url, self._num_retries
                    )
                )
            self._backoff.wait()
            response = requests.get(rest_url, headers=self._headers)
            attempt = attempt + 1
        self._backoff.report_success()
        return response.json()

    def post(
        self, *, endpoint: str = "", body: dict = {}, params: dict[str, str] = None
    ):
        """Makes an HTTP POST request to the REST server

        The post() method is used for making REST POST requests. The method allows
        specifying an "endpoint", which gets appended to the REST server's base
        URL. The supplied parameters are appended to the endpoint URL in the
        form param1=val1&param2=val2, etc. The body is converted to json and sent
        over to the server

        Args:
            endpoint:
                The API endpoint on the server. Can be empty ('').
            body:
                The body of the HTTP POST request.
            params:
                API parameters stored in an str => str dictionary. The
                dictionary can be empty, or this parameter can be set to None.
                The parameters are appended at the end of the base_urs/endpoint
                in the format ?key1=value1&key2=value2...
        Returns:
            On success, returns the JSON response from the server.

        Raises:
            TimeoutError:
                If the server responds with a status code HTTP_TOO_MANY_REQS,
                (429) successively more than self._num_retries times.
            ValueError:
                If the server responds with any other error code.
        """
        rest_url: str = self.__create_rest_url(self._base_url, endpoint, params)
        print("REST URL: " + rest_url)
        self._add_auth_header()

        # A write request always waits for 1 second before attempting the request
        # this is done to minimize the chance of being throttled on a write request.
        backoff = Backoff(backoff_us=5000000)
        backoff.wait()

        response = requests.post(rest_url, headers=self._headers, json=body)
        if int(response.status_code) >= 300:
            raise ValueError(
                "Could not post {}, status code {}".format(
                    rest_url, response.status_code
                )
            )
        if response.status_code == self.HTTP_OK_NO_CONTENT:
            self._backoff.report_success()
            return {}
        return response.json()

    def put(
        self, *, endpoint: str = "", body: dict = {}, params: dict[str, str] = None
    ):
        """Makes an HTTP PUT request to the REST server

        The post() method is used for making REST POST requests. The method allows
        specifying an "endpoint", which gets appended to the REST server's base
        URL. The supplied parameters are appended to the endpoint URL in the
        form param1=val1&param2=val2, etc. The body is converted to json and sent
        over to the server

        Args:
            endpoint:
                The API endpoint on the server. Can be empty ('').
            body:
                The body of the HTTP PUT request.
            params:
                API parameters stored in an str => str dictionary. The
                dictionary can be empty, or this parameter can be set to None.
                The parameters are appended at the end of the base_urs/endpoint
                in the format ?key1=value1&key2=value2...
        Returns:
            On success, returns the JSON response from the server.

        Raises:
            TimeoutError:
                If the server responds with a status code HTTP_TOO_MANY_REQS,
                (429) successively more than self._num_retries times.
            ValueError:
                If the server responds with any other error code.
        """
        rest_url: str = self.__create_rest_url(self._base_url, endpoint, params)
        print("REST URL: " + rest_url)
        self._add_auth_header()

        # A write request always waits for 1 second before attempting the request
        # this is done to minimize the chance of being throttled on a write request.
        backoff = Backoff(backoff_us=5000000)
        backoff.wait()

        response = requests.put(rest_url, headers=self._headers, json=body)
        if int(response.status_code) >= 300:
            raise ValueError(
                "Could not post {}, status code {}".format(
                    rest_url, response.status_code
                )
            )
        if response.status_code == self.HTTP_OK_NO_CONTENT:
            self._backoff.report_success()
            return {}
        return response.json()


# Module Initialization
def __init_module():
    pass


__init_module()
