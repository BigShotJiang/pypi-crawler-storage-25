class HttpError(Exception):
    """Custom exception for HTTP errors."""

    HTTP_ERRORS = {
        # 1xx - Informational
        100: "CONTINUE",
        101: "SWITCHING_PROTOCOLS",
        102: "PROCESSING",
        103: "EARLY_HINTS",
        # 2xx - Success
        200: "OK",
        201: "CREATED",
        202: "ACCEPTED",
        203: "NON_AUTHORITATIVE",
        204: "NO_CONTENT",
        205: "RESET_CONTENT",
        206: "PARTIAL_CONTENT",
        # 3xx - Redirection
        300: "MULTIPLE_CHOICES",
        301: "MOVED_PERMANENTLY",
        302: "FOUND",
        303: "SEE_OTHER",
        304: "NOT_MODIFIED",
        307: "TEMPORARY_REDIRECT",
        308: "PERMANENT_REDIRECT",
        # 4xx - Client Errors
        400: "BAD_REQUEST",
        401: "UNAUTHORIZED",
        402: "PAYMENT_REQUIRED",
        403: "FORBIDDEN",
        404: "NOT_FOUND",
        405: "METHOD_NOT_ALLOWED",
        406: "NOT_ACCEPTABLE",
        407: "PROXY_AUTH_REQUIRED",
        408: "REQUEST_TIMEOUT",
        409: "CONFLICT",
        410: "GONE",
        411: "LENGTH_REQUIRED",
        412: "PRECONDITION_FAILED",
        413: "PAYLOAD_TOO_LARGE",
        414: "URI_TOO_LONG",
        415: "UNSUPPORTED_MEDIA_TYPE",
        416: "RANGE_NOT_SATISFIABLE",
        417: "EXPECTATION_FAILED",
        418: "I_AM_A_TEAPOT",
        429: "TOO_MANY_REQUESTS",
        # 5xx - Server Errors
        500: "INTERNAL_SERVER_ERROR",
        501: "NOT_IMPLEMENTED",
        502: "BAD_GATEWAY",
        503: "SERVICE_UNAVAILABLE",
        504: "GATEWAY_TIMEOUT",
        505: "HTTP_VERSION_NOT_SUPPORTED",
        507: "INSUFFICIENT_STORAGE",
        508: "LOOP_DETECTED",
        511: "NETWORK_AUTH_REQUIRED",
    }

    def __init__(self, status_code, message="HTTP Error", details=None):
        """
        Initialize the HTTP error.

        :param status_code: HTTP status code (e.g., 404, 500)
        :param message: Custom error message
        :param details: Additional details (optional)
        """
        self.status_code = status_code
        self.message = message
        self.details = details
        super().__init__(f"HTTP {status_code}: {message}")

    def errorType(self):
        return (
            self.HTTP_ERRORS[self.status_code]
            if self.status_code in self.HTTP_ERRORS
            else "UNKNOWN"
        )

    def to_dict(self):
        """Convert error details to a dictionary (useful for APIs)."""
        return {
            "status_code": self.status_code,
            "message": self.message,
            "details": self.details,
        }
