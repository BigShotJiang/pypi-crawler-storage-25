from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Awaitable, Callable, Iterable, Sequence

from grpclib import GRPCError
from grpclib.const import Status

from lumecode.base.proto.grpc_health import health_grpc, health_pb2

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from sqlalchemy.ext.asyncio import AsyncEngine

OVERALL_SERVICE_NAME = ""
READINESS_SERVICE_NAME = "readiness"
LIVENESS_SERVICE_NAME = "liveness"

_DEFAULT_POLL_INTERVAL_SECONDS = 1.0
_DEFAULT_PROBE_TIMEOUT_SECONDS = 5.0


@dataclass(frozen=True)
class ReadinessMonitorConfig:
    pollIntervalSeconds: float = _DEFAULT_POLL_INTERVAL_SECONDS
    probeTimeoutSeconds: float = _DEFAULT_PROBE_TIMEOUT_SECONDS

    def __post_init__(self) -> None:
        if self.pollIntervalSeconds <= 0:
            raise ValueError(
                f"pollIntervalSeconds must be > 0, got {self.pollIntervalSeconds}"
            )
        if self.probeTimeoutSeconds <= 0:
            raise ValueError(
                f"probeTimeoutSeconds must be > 0, got {self.probeTimeoutSeconds}"
            )


class StandardGrpcHealthService(health_grpc.HealthBase):
    def __init__(
        self,
        *,
        registeredServices: Iterable[str] | None = None,
    ) -> None:
        self._statusByService: dict[str, int] = {
            OVERALL_SERVICE_NAME: health_pb2.HealthCheckResponse.NOT_SERVING,
            READINESS_SERVICE_NAME: health_pb2.HealthCheckResponse.NOT_SERVING,
            LIVENESS_SERVICE_NAME: health_pb2.HealthCheckResponse.NOT_SERVING,
        }
        for serviceName in registeredServices or ():
            self._statusByService.setdefault(
                serviceName,
                health_pb2.HealthCheckResponse.NOT_SERVING,
            )
        self._statusCondition = asyncio.Condition()

    async def Check(
        self,
        stream,
    ) -> None:
        await self.async_check(stream)

    async def async_check(self, stream) -> None:
        request = await stream.recv_message()
        if request is None:
            raise GRPCError(Status.INVALID_ARGUMENT, "Health Check request payload missing.")
        status = await self.async_getStatus(serviceName=request.service)
        await stream.send_message(health_pb2.HealthCheckResponse(status=status))

    async def Watch(
        self,
        stream,
    ) -> None:
        await self.async_watch(stream)

    async def async_watch(self, stream) -> None:
        request = await stream.recv_message()
        if request is None:
            raise GRPCError(Status.INVALID_ARGUMENT, "Health Watch request payload missing.")
        serviceName = request.service
        lastSentStatus: int | None = None
        while True:
            async with self._statusCondition:
                nextStatus = self._getStatusLocked(serviceName=serviceName)
                while nextStatus == lastSentStatus:
                    await self._statusCondition.wait()
                    nextStatus = self._getStatusLocked(serviceName=serviceName)
            await stream.send_message(health_pb2.HealthCheckResponse(status=nextStatus))
            lastSentStatus = nextStatus

    async def async_getStatus(self, *, serviceName: str = OVERALL_SERVICE_NAME) -> int:
        async with self._statusCondition:
            return self._getStatusLocked(serviceName=serviceName)

    async def async_setStatus(
        self,
        *,
        status: int,
        serviceNames: Sequence[str],
    ) -> None:
        async with self._statusCondition:
            updated = False
            for serviceName in serviceNames:
                currentStatus = self._statusByService.get(serviceName)
                if currentStatus == status:
                    continue
                self._statusByService[serviceName] = status
                updated = True
            if updated:
                self._statusCondition.notify_all()

    async def async_setReady(self) -> None:
        await self.async_setStatus(
            status=health_pb2.HealthCheckResponse.SERVING,
            serviceNames=(OVERALL_SERVICE_NAME, READINESS_SERVICE_NAME),
        )

    async def async_setNotReady(self) -> None:
        await self.async_setStatus(
            status=health_pb2.HealthCheckResponse.NOT_SERVING,
            serviceNames=(OVERALL_SERVICE_NAME, READINESS_SERVICE_NAME),
        )

    async def async_setLive(self) -> None:
        await self.async_setStatus(
            status=health_pb2.HealthCheckResponse.SERVING,
            serviceNames=(LIVENESS_SERVICE_NAME,),
        )

    async def async_markShutdown(self) -> None:
        await self.async_setStatus(
            status=health_pb2.HealthCheckResponse.NOT_SERVING,
            serviceNames=(
                OVERALL_SERVICE_NAME,
                READINESS_SERVICE_NAME,
                LIVENESS_SERVICE_NAME,
            ),
        )

    def _getStatusLocked(self, *, serviceName: str) -> int:
        return self._statusByService.get(
            serviceName,
            health_pb2.HealthCheckResponse.SERVICE_UNKNOWN,
        )


class ReadinessMonitor:
    def __init__(
        self,
        *,
        componentName: str,
        healthService: StandardGrpcHealthService,
        readinessCheck: Callable[[], Awaitable[None]],
        config: ReadinessMonitorConfig | None = None,
    ) -> None:
        self._componentName = componentName
        self._healthService = healthService
        self._readinessCheck = readinessCheck
        self._config = config or ReadinessMonitorConfig()
        self._task: asyncio.Task[None] | None = None
        self._stopEvent = asyncio.Event()

    def start(self) -> None:
        if self._task is not None and not self._task.done():
            return
        self._stopEvent.clear()
        self._task = asyncio.create_task(self._async_run())

    async def async_close(self) -> None:
        task = self._task
        if task is None:
            return
        self._stopEvent.set()
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass
        finally:
            self._task = None

    async def _async_run(self) -> None:
        lastReady: bool | None = None
        consecutiveFailures = 0
        while not self._stopEvent.is_set():
            try:
                await asyncio.wait_for(
                    self._readinessCheck(),
                    timeout=self._config.probeTimeoutSeconds,
                )
                await self._healthService.async_setReady()
                if lastReady is not True:
                    logger.info(
                        f"{self._componentName} readiness transitioned to SERVING",
                        extra={
                            "event": "lumesof.readiness.transition",
                            "component": self._componentName,
                            "readiness_status": "SERVING",
                        },
                    )
                lastReady = True
                consecutiveFailures = 0
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                await self._healthService.async_setNotReady()
                consecutiveFailures += 1
                if lastReady is not False or consecutiveFailures % 20 == 0:
                    logger.warning(
                        f"{self._componentName} readiness transitioned to NOT_SERVING "
                        f"failure={type(exc).__name__}: {exc} "
                        f"consecutive_failures={consecutiveFailures}",
                        extra={
                            "event": "lumesof.readiness.transition",
                            "component": self._componentName,
                            "readiness_status": "NOT_SERVING",
                            "failure_type": type(exc).__name__,
                            "failure_message": str(exc),
                            "consecutive_failures": consecutiveFailures,
                        },
                    )
                lastReady = False

            try:
                await asyncio.wait_for(
                    self._stopEvent.wait(),
                    timeout=self._config.pollIntervalSeconds,
                )
            except asyncio.TimeoutError:
                continue


async def async_checkSqlAlchemyEngineReady(engine: "AsyncEngine") -> None:
    from sqlalchemy import text

    async with engine.connect() as connection:
        await connection.execute(text("SELECT 1"))


async def async_checkGrpcServing(
    healthStub: object,
    *,
    serviceName: str = READINESS_SERVICE_NAME,
) -> None:
    response = await healthStub.Check(health_pb2.HealthCheckRequest(service=serviceName))
    if response.status != health_pb2.HealthCheckResponse.SERVING:
        raise RuntimeError(
            f"dependency health returned status={response.status} service={serviceName!r}"
        )


__all__ = [
    "LIVENESS_SERVICE_NAME",
    "OVERALL_SERVICE_NAME",
    "READINESS_SERVICE_NAME",
    "ReadinessMonitor",
    "ReadinessMonitorConfig",
    "StandardGrpcHealthService",
    "async_checkGrpcServing",
    "async_checkSqlAlchemyEngineReady",
]
