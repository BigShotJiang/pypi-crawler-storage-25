"""Remote CRDB connection wiring using credential providers."""

from __future__ import annotations

from typing import Any
from urllib import parse as urllib_parse

from lumecode.base.python.sqldb.auth.errors import (
    InvalidDatabaseUrlError,
    MissingCredentialsError,
)
from lumecode.base.python.sqldb.credentials.crdb_credential_provider import (
    CrdbCredentialProvider,
)
from lumecode.base.python.sqldb.credentials.provider import CredentialProvider


class RemoteDbConnector:
    """Delegates remote connection setup to a credential provider and async client."""

    def __init__(self, credentialProvider: CredentialProvider, asyncSqlClient: Any) -> None:
        """Initialize with a credential provider and an async SQL client.

        The async SQL client is treated as an opaque dependency supplied by callers.
        """
        self._credentialProvider = credentialProvider
        self._asyncSqlClient = asyncSqlClient

    def connect(self) -> Any:
        """Resolve DATABASE_URL, validate it, and return an async SessionMaker.

        Validation responsibilities handled here:
        - Scheme check (e.g., cockroachdb+asyncpg).
        - Hostname and port validation.
        - Database path presence.
        """
        return self.createSessionMaker()

    def createSessionMaker(self) -> Any:
        """Create and return an async SessionMaker for the remote CRDB.

        Intended behavior:
        - Resolve DATABASE_URL via the credential provider.
        - Validate DATABASE_URL shape before creating engine.
        - Build an async SQLAlchemy engine using the async client.
        - Construct and return an async sessionmaker bound to that engine.
        """
        database_url = self._credentialProvider.getDatabaseUrl()
        self._validateDatabaseUrl(database_url)
        database_url = self._normalizeDatabaseUrl(database_url)
        engine = self._asyncSqlClient.create_async_engine(
            database_url,
            pool_pre_ping=True,
        )
        return self._asyncSqlClient.async_sessionmaker(
            engine,
            expire_on_commit=False,
            class_=self._asyncSqlClient.AsyncSession,
        )

    def _validateDatabaseUrl(self, databaseUrl: str) -> None:
        """Validate required DATABASE_URL fields for remote connectivity."""
        if not databaseUrl:
            raise MissingCredentialsError("DATABASE_URL must be provided.")
        parsed = urllib_parse.urlparse(databaseUrl)
        if parsed.scheme not in ("cockroachdb+asyncpg", "cockroachdb"):
            raise InvalidDatabaseUrlError(
                "DATABASE_URL must use cockroachdb or cockroachdb+asyncpg scheme."
            )
        if not parsed.hostname:
            raise InvalidDatabaseUrlError("DATABASE_URL must include a hostname.")
        database_name = parsed.path.lstrip("/")
        if not database_name:
            raise InvalidDatabaseUrlError("DATABASE_URL must include a database name.")

    def _normalizeDatabaseUrl(self, databaseUrl: str) -> str:
        """Normalize URL query options for the selected SQLAlchemy async dialect."""
        parsed = urllib_parse.urlparse(databaseUrl)
        if parsed.scheme != "cockroachdb+asyncpg":
            return databaseUrl

        query = urllib_parse.parse_qs(parsed.query, keep_blank_values=True)
        sslmode_values = query.pop("sslmode", None)
        if sslmode_values and "ssl" not in query:
            # asyncpg expects `ssl`, while CRDB URLs are often authored with `sslmode`.
            query["ssl"] = sslmode_values

        normalized_query = urllib_parse.urlencode(query, doseq=True)
        return urllib_parse.urlunparse(
            (
                parsed.scheme,
                parsed.netloc,
                parsed.path,
                parsed.params,
                normalized_query,
                parsed.fragment,
            )
        )


def createRemoteSessionMaker(
    *,
    database: str,
    asyncSqlClient: Any,
    projectId: str | None = None,
    sslMode: str | None = None,
) -> Any:
    """Convenience helper for callers that want a ready-to-use remote SessionMaker."""
    kwargs: dict[str, str] = {"database": database}
    if projectId is not None:
        kwargs["projectId"] = projectId
    if sslMode is not None:
        kwargs["sslMode"] = sslMode
    provider = CrdbCredentialProvider(**kwargs)
    connector = RemoteDbConnector(provider, asyncSqlClient)
    return connector.connect()
