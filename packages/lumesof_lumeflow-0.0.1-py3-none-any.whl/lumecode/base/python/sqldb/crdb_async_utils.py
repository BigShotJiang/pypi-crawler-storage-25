from __future__ import annotations

import asyncio
import inspect
from collections import deque
from contextlib import asynccontextmanager
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
import time
import uuid
from urllib.parse import parse_qs, urlencode, urlparse, urlunparse
import inspect
from typing import (
    AsyncIterator,
    Awaitable,
    Callable,
    Deque,
    Iterable,
    List,
    Optional,
    Sequence,
    Tuple,
    TypeVar,
)

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker
try:  # pragma: no cover - optional dependency
    from sqlalchemy.exc import IntegrityError as _SQLAlchemyIntegrityError
except ModuleNotFoundError:  # pragma: no cover
    class _SQLAlchemyIntegrityError(Exception):
        """Fallback IntegrityError used when SQLAlchemy is unavailable."""

        def __init__(self, statement=None, params=None, orig=None):
            super().__init__(statement, params, orig)
            self.statement = statement
            self.params = params
            self.orig = orig


IntegrityError = _SQLAlchemyIntegrityError

T = TypeVar("T")

_SERIALIZATION_ERROR_NAMES = {
    "SerializationError",
    "TransactionRetryWithProtoRefreshError",
    "ReadWithinUncertaintyIntervalError",
}
_SERIALIZATION_SQLSTATES = {"40001"}


def createAsyncEngine(db_url: str, **kwargs):  # type: ignore[no-untyped-def]
    """Create a SQLAlchemy async engine from a URL.

    Handles ``sslmode=disable`` in the query string by stripping it and
    passing ``connect_args={"ssl": False}`` to asyncpg.  This bridges the
    libpq convention (used by psql / DATABASE_URL env vars) with asyncpg,
    which does not accept ``sslmode`` as a connection parameter and does not
    fall back gracefully when a server rejects the SSL upgrade.
    """
    from sqlalchemy.ext.asyncio import create_async_engine  # local import to keep optional

    parsed = urlparse(db_url)
    params = parse_qs(parsed.query, keep_blank_values=True)
    sslmode_values = [v.lower() for v in params.pop("sslmode", [])]
    ssl_disabled = "disable" in sslmode_values

    new_query = urlencode({k: v[0] for k, v in params.items()})
    clean_url = urlunparse(parsed._replace(query=new_query))

    connect_args = dict(kwargs.pop("connect_args", {}))
    if ssl_disabled:
        connect_args.setdefault("ssl", False)

    return create_async_engine(clean_url, connect_args=connect_args, **kwargs)


def _iterExceptionChain(exc: BaseException) -> Iterable[BaseException]:
    """Yield exc along with its orig/cause chain without repeating nodes."""
    stack: List[BaseException] = [exc]
    seen: set[int] = set()
    while stack:
        current = stack.pop()
        if current is None:
            continue
        ident = id(current)
        if ident in seen:
            continue
        seen.add(ident)
        yield current
        orig = getattr(current, "orig", None)
        cause = getattr(current, "__cause__", None)
        if orig is not None:
            stack.append(orig)
        if cause is not None:
            stack.append(cause)


def isRetryableSerializationError(exc: BaseException) -> bool:
    """Return True if exc (or anything in its chain) looks like a CRDB serialization conflict."""
    for err in _iterExceptionChain(exc):
        name = err.__class__.__name__
        if name in _SERIALIZATION_ERROR_NAMES:
            return True
        sqlstate = getattr(err, "sqlstate", None)
        if sqlstate in _SERIALIZATION_SQLSTATES:
            return True
    return False


async def _async_maybeAwait(result: object) -> None:
    if inspect.isawaitable(result):
        await result


async def _async_maybeAwait(result: object) -> None:
    if inspect.isawaitable(result):
        await result


@asynccontextmanager
async def async_transactionalSession(session) -> AsyncIterator[object]:
    """Async context manager wrapping session commit/rollback."""
    try:
        yield session
    except Exception:
        rollback = getattr(session, "rollback", None)
        if callable(rollback):
            await _async_maybeAwait(rollback())
        raise
    else:
        commit = getattr(session, "commit", None)
        if callable(commit):
            try:
                await _async_maybeAwait(commit())
            except Exception:
                rollback = getattr(session, "rollback", None)
                if callable(rollback):
                    await _async_maybeAwait(rollback())
                raise


async def async_runWithSerializationRetries(
    operation: Callable[[], Awaitable[T]],
    *,
    max_attempts: int = 5,
    base_delay_s: float = 0.02,
    is_retryable: Callable[[BaseException], bool] = isRetryableSerializationError,
    sleep_fn: Callable[[float], Awaitable[None]] = asyncio.sleep,
    bailout: Optional[Callable[[BaseException], Awaitable[Tuple[bool, Optional[T]]]]] = None,
) -> T:
    """Execute operation(), retrying on serialization conflicts."""
    if max_attempts <= 0:
        raise ValueError("max_attempts must be positive.")

    attempt = 0
    while True:
        try:
            return await operation()
        except Exception as exc:
            attempt += 1
            should_retry = is_retryable(exc) and attempt < max_attempts
            if not should_retry:
                raise
            if bailout is not None:
                bail, result = await bailout(exc)
                if not bail:
                    if result is not None:
                        return result
                    raise
            await sleep_fn(base_delay_s * attempt)


async def async_partitionOnIntegrityErrors(
    items: Sequence[T],
    persist_fn: Callable[[Sequence[T]], Awaitable[None]],
    *,
    reason_fn: Optional[Callable[[IntegrityError], Optional[str]]] = None,
) -> Tuple[List[T], List[Tuple[T, Optional[str]]]]:
    """Best-effort persistence helper that bisects batches on IntegrityError."""
    queue: Deque[List[T]] = deque([list(items)])
    successes: List[T] = []
    failures: List[Tuple[T, Optional[str]]] = []

    while queue:
        current = queue.popleft()
        if not current:
            continue
        try:
            await persist_fn(current)
        except IntegrityError as exc:
            if len(current) == 1:
                reason = reason_fn(exc) if reason_fn else None
                failures.append((current[0], reason))
                continue
            mid = len(current) // 2
            queue.append(current[:mid])
            queue.append(current[mid:])
        else:
            successes.extend(current)

    return successes, failures


class ApproxDbTime:
    """Approximate DB time using a periodically refreshed local offset (naive UTC)."""

    def __init__(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        reseedIntervalS: float = 15 * 60,
    ) -> None:
        if reseedIntervalS <= 0:
            raise ValueError("reseedIntervalS must be positive.")
        self._session_maker = session_maker
        self._reseed_interval_s = reseedIntervalS
        self._offset_s: Optional[float] = None
        self._last_seed_monotonic: Optional[float] = None
        self._lock = asyncio.Lock()

    def getReseedIntervalS(self) -> float:
        return self._reseed_interval_s

    def setReseedIntervalS(self, reseedIntervalS: float) -> None:
        if reseedIntervalS <= 0:
            raise ValueError("reseedIntervalS must be positive.")
        self._reseed_interval_s = reseedIntervalS

    async def async_getApproxDbTime(self) -> datetime:
        if self._shouldReseed():
            await self._async_refresh()
        if self._offset_s is None:
            return self._localNow()
        local_now = self._localNow()
        return local_now + timedelta(seconds=self._offset_s)

    def getApproxDbTimeIfSeeded(self) -> Optional[datetime]:
        if self._offset_s is None:
            return None
        local_now = self._localNow()
        return local_now + timedelta(seconds=self._offset_s)

    def getLastSeedAgeS(self) -> Optional[float]:
        if self._last_seed_monotonic is None:
            return None
        return time.monotonic() - self._last_seed_monotonic

    def _localNow(self) -> datetime:
        return datetime.utcnow()

    def _shouldReseed(self) -> bool:
        if self._offset_s is None or self._last_seed_monotonic is None:
            return True
        return (time.monotonic() - self._last_seed_monotonic) >= self._reseed_interval_s

    async def _async_refresh(self) -> None:
        async with self._lock:
            if not self._shouldReseed():
                return
            db_now = await self._async_fetchDbTime()
            if db_now.tzinfo is not None:
                db_now = db_now.astimezone(timezone.utc).replace(tzinfo=None)
            local_now = self._localNow()
            self._offset_s = (db_now - local_now).total_seconds()
            self._last_seed_monotonic = time.monotonic()

    async def _async_fetchDbTime(self) -> datetime:
        async with self._session_maker() as session:
            result = await session.execute(select(func.now()))
        return result.scalar_one()


@dataclass
class TransactionContext:
    session: AsyncSession
    tracer_id: uuid.UUID


@asynccontextmanager
async def async_transactionContext(
    session_maker: Optional[async_sessionmaker[AsyncSession]] = None,
    *,
    existing_session: Optional[AsyncSession] = None,
    context: Optional[TransactionContext] = None,
) -> AsyncIterator[TransactionContext]:
    if context is not None:
        yield context
        return
    if existing_session is not None:
        async with async_transactionalSession(existing_session):
            yield TransactionContext(session=existing_session, tracer_id=uuid.uuid4())
        return
    if session_maker is None:
        raise ValueError("session_maker must be provided when no session context exists.")
    async with session_maker() as session:
        async with async_transactionalSession(session):
            yield TransactionContext(session=session, tracer_id=uuid.uuid4())
