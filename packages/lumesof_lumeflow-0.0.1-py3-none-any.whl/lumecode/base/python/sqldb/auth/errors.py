"""Auth and credential errors for CRDB connectivity."""

from __future__ import annotations


class MissingCredentialsError(Exception):
    """Raised when required credentials (e.g., DATABASE_URL) are missing."""


class InvalidDatabaseUrlError(Exception):
    """Raised when DATABASE_URL fails validation or has an invalid format."""
