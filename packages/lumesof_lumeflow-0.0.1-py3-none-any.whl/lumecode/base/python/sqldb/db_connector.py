import os
import time

class SqlKeyword:
    def __init__(self, keyword: str):
        self._keyword = keyword

    def __str__(self):
        return self._keyword


class Barrier:
    def __init__(self, tid: int, readonly: bool):
        self._tid = tid
        self._readonly = readonly

    @classmethod
    def getReadOnly(cls, request: Request):
        barrierVal = ArgExtractor(request.args).optional("barrier", str, None)
        if barrierVal is not None:
            barrierVal = int(barrierVal)
        return Barrier(barrierVal, True)

    @classmethod
    def getReadWrite(cls, request: Request):
        barrierVal = ArgExtractor(request.args).optional("barrier", str, None)
        if barrierVal is not None:
            barrierVal = int(barrierVal)
        return Barrier(barrierVal, False)

    def wait(self, cursor):
        if self._tid is None:
            return
        for i in range(1, 10):
            cursor.execute(
                "SELECT * FROM sig_transactions WHERE id = %s;", (self._tid,)
            )
            result = cursor.fetchall()
            if result:
                return
            time.sleep(0.5)
        raise ValueError("Could not satisfy barrier")

    def update(self, cursor):
        if self._readonly:
            return
        cursor.execute(
            "INSERT INTO sig_transactions (status) VALUES (%s) RETURNING id",
            ("COMPLETE",),
        )
        self._tid = cursor.fetchone()[0]

    def destroy(self):
        self._tid = None

    def getUpdatedId(self):
        if self._readonly:
            raise ValueError("Readonly barrier cannot provide updated tid")
        return self._tid


# A ManagedCursor object should only be created within a "with" context.
# This object closes its connection on exit.
class ManagedCursor:
    def __init__(self, connection, barrier: Barrier):
        self._connection = connection
        self._barrier = barrier

    def __enter__(self):
        self._cursor = self._connection.cursor()
        self._cursor.execute("BEGIN")
        if self._barrier:
            self._barrier.wait(self._cursor)
        return self._cursor

    def __exit__(self, exc_type, exc_value, traceback):
        if exc_type is None:
            if self._barrier:
                self._barrier.update(self._cursor)
            self._cursor.close()
            self._connection.commit()
        else:
            if self._barrier:
                self._barrier.destroy()
            self._cursor.close()
            self._connection.rollback()
        self._connection.close()


class DbConnector:
    _ca_cert = """
-----BEGIN CERTIFICATE-----
MIIDfzCCAmegAwIBAgIBADANBgkqhkiG9w0BAQsFADB3MS0wKwYDVQQuEyQ1N2Ez
MWEyOC0xYjc3LTQyYzAtODU0Yy1lOGFiNWUwOTQ1M2UxIzAhBgNVBAMTGkdvb2ds
ZSBDbG91ZCBTUUwgU2VydmVyIENBMRQwEgYDVQQKEwtHb29nbGUsIEluYzELMAkG
A1UEBhMCVVMwHhcNMjQxMjI2MjIzMjI0WhcNMzQxMjI0MjIzMzI0WjB3MS0wKwYD
VQQuEyQ1N2EzMWEyOC0xYjc3LTQyYzAtODU0Yy1lOGFiNWUwOTQ1M2UxIzAhBgNV
BAMTGkdvb2dsZSBDbG91ZCBTUUwgU2VydmVyIENBMRQwEgYDVQQKEwtHb29nbGUs
IEluYzELMAkGA1UEBhMCVVMwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
AQDB9GjONyjptSHM3W4TrkSWiV6b11YxBshG7cMkKyoNws2upbN/e2eRdiSEgp86
uWSq8f33fU+gP90V+iPqwUxY4psSMRiMbX5KyylaKXZ5ECpmbqesqAmPlKsaG5tP
+y8aTgSsiiAH9/p7e0eyPg3o7htF8fIVbvSEgSHdcPdXzZ6j/qD62EsyfbUjAOuj
2xScR3mdsHOcbNQ2czGTtDN5JuPXG2YksIIchi7UvWK5GhyjLnAAWbtuN0FYGQGX
SV1Ac5GBfp0H23HCXSqI9iVR8gi7AkFL3NRvxiLWNhUV9ieWIij1VTwJ/6S5P0U7
p9oT4yJVP5OfxFHon+a6tJtHAgMBAAGjFjAUMBIGA1UdEwEB/wQIMAYBAf8CAQAw
DQYJKoZIhvcNAQELBQADggEBAJD6nqbgAwFfkgUaEzNcGN//qfp8bBkBXC5wzJZm
Wa4TtBPeIxYXjPUvEFhz8SeVPj6qk11yM75+6RPJMeQ3S6HYKC0TGuS2frgiTl2j
ybMpdHw/VNh/PG08QhdVtQSUpqKUve+XfNBskh7/oFFCHbSoZdcYm9tyCxol0OT9
iCEuwNiSGkrVLwAlu3qFq8CM/ETHHtHPmTWcBHPw9Si37wGhAz+pHlKqVlwl6SFk
/Sj0Zkm8rM/2VYvy3PKgZliXLAwUMKBzcHR4tk3tYyIq64IJ7SOzycUO/bFBrNhJ
NcchgH8q1Rtvf4nFqwUhCCl++sw+JXJFsGUHolQnJHHlEBw=
-----END CERTIFICATE-----
    """
    _client_cert = """
-----BEGIN CERTIFICATE-----
MIIDWjCCAkKgAwIBAgIECNtv8TANBgkqhkiG9w0BAQsFADB7MS0wKwYDVQQuEyQ1
M2Q0NmRmZS0xNjdlLTRkOTUtYWFlOC00OTI1ODlkZTBmNTMxJzAlBgNVBAMTHkdv
b2dsZSBDbG91ZCBTUUwgQ2xpZW50IENBIGdhZTEUMBIGA1UEChMLR29vZ2xlLCBJ
bmMxCzAJBgNVBAYTAlVTMB4XDTI0MTIyNjIzMTExNFoXDTM0MTIyNDIzMTIxNFow
MTEMMAoGA1UEAxMDZ2FlMRQwEgYDVQQKEwtHb29nbGUsIEluYzELMAkGA1UEBhMC
VVMwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDEwYDo8+IDVBoGqG/c
KObeDObs6R5WIddhI2cMHTb4Bj997fZap3xTsgGuuXTRgTfYZhdGncEuwIOZB4DG
1/H1IikQ+G/S00131cKISoacI0QTubp2W9N61x5J3pSnt86Ab3kyGC8v+XqhYx9V
yjp52iVK04QQNBOJES6LeOgl4jNBHt0u+54TwIJADcKYx2735qQjD6RdMZYm9jUl
HCzOcKbVxhnd9pdHOMfuxKOB8cL5b+49ZTVwBJ40kzY0FQuBzQ0MAwrm/mrZ9oWN
DmACcqm6Yf3Y3gt51hw7na0HXRf2WzJ5rXGaV8ARNxThoXOKOsR7zeBDqTx9DjeV
tVw5AgMBAAGjMDAuMAkGA1UdEwQCMAAwIQYDVR0RBBowGIEWdWRheUBjYXNjYWRl
dHV0b3JzLmNvbTANBgkqhkiG9w0BAQsFAAOCAQEAbiKR0EZR1Hh0VOQweY8Ugftu
yPi75nuIaHqrOduqnVEwwejdrkCWgeOQ0FSZGWdk0WC449msdOQvkDjAFlI5zgVr
uVM9YzFA4G4q4zhg73zSzYKgH/bcUszAlVMvA62oElO6yMMs9/IiJEVnAWn8Crrg
wh3IofLS1sZLbUDGXJgHruvzDAj9QL4PqMX/IxSbUxw9HUSDUTSKF7S9Dk98pHSB
DqavD2ixCiWswPcFyaB7KAYZmAvx2BDJZG9Nv+D+i4WiAOS7uAJdSRQ21TURVJ4n
ScxQ/zrJUObMKXrs6VsHaIs5tMKTHUOR3hOdiKuvIEEjNwgjvPgufsM4/BDUhw==
-----END CERTIFICATE-----
    """

    def __init__(self):
        self._db = os.getenv("UDB_NAME")
        self._user = os.getenv("SQL_USER")

        self._sql_connector = SqlConnector()

    def cursor(self, barrier: Barrier = None):
        return ManagedCursor(
            self._sql_connector.connect(
                self._db, self._user, self._ca_cert, self._client_cert
            ),
            barrier,
        )

    def testConnection(self):
        with self.cursor() as cursor:
            cursor.execute("SELECT current_database(), version();")
            rows = cursor.fetchall()
            retval = []
            for row in rows:
                retval.append(row)
        return retval

    """ select
        Executes a SELECT query on the specified table.
        Required Parameters:
            indexVars:
                List of column names against which an index is built. May be empty.
            kwargs['columns']:
                List of columns to be queried. May be an SQL expression (e.g. count(*)).
            kwargs['table']:
                Name of the table. May be a SQL expression.
        Optional Parameters:
            kwargs['constraints]:
                A dictionary with up to two keys: desc (required) and value (optional).
                'desc' describes the constraint and is added to the WHERE clause of the
                query. 'value' provides the value for the %s part of desc.
            kwargs['for_update']:
                A boolean specifying whether the SELECT is being executed with an intended
                update.
        Returns:
            An object containing all the results of the query along with the various indexes
    """

    @classmethod
    def select(
        cls,
        cursor,
        *,
        table: str,
        columns: list[str],
        constraints: list[dict] = [],
        for_update: bool = False,
        index_vars: list = [],
    ):
        query = f"SELECT {', '.join(columns)} FROM {table}"
        values = []
        if constraints:
            query += " WHERE "
            descriptions = [constraint["desc"] for constraint in constraints]
            query += " AND ".join(descriptions)
            values = [
                constraint["value"]
                for constraint in constraints
                if "value" in constraint
            ]
        if for_update:
            query += " FOR UPDATE"
        query += ";"

        query = cls.cleanString(query)
        if values:
            print(query)
            print(tuple(values))
            cursor.execute(query, tuple(values))
        else:
            print(query)
            cursor.execute(query)
        rows = cursor.fetchall()
        retObj = {}
        for var in index_vars:
            retObj[var] = {}
        retObj["_all_"] = []
        for row in rows:
            entry = {}
            for column in columns:
                entry[column] = row.pop(0)
            for var in index_vars:
                retObj[var][entry[var]] = entry
            retObj["_all_"].append(entry)
        return retObj

    """ update
        Executes an UPDATE query on the specified table.
        Required Parameters:
            kwargs['update']:
                A dictionary containing key-value pairs. Keys are names of the
                columns to be updated. Values are the new values for the columns.
            kwargs['table']:
                Name of the table. May be a SQL expression.
        Optional Parameters:
            kwargs['constraints]:
                A dictionary with up to two keys: desc (required) and value (optional).
                'desc' describes the constraint and is added to the WHERE clause of the
                query. 'value' provides the value for the %s part of desc.
        Returns:
            Nothing
    """

    @classmethod
    def update(cls, cursor, *, table: str, update: dict, constraints: list[dict]):
        keyArr = []
        valueArr = []
        for key in update:
            if isinstance(update[key], SqlKeyword):
                keyArr.append(f"{key} = {str(update[key])}")
            else:
                keyArr.append(f"{key} = %s")
                valueArr.append(update[key])
        query = f"UPDATE {table} SET {', '.join(keyArr)}"
        if constraints:
            query += " WHERE "
            descriptions = [constraint["desc"] for constraint in constraints]
            query += " AND ".join(descriptions)
            values = [
                constraint["value"]
                for constraint in constraints
                if "value" in constraint
            ]
            valueArr.extend(values)
        query += ";"
        query = cls.cleanString(query)
        print(query)
        print(tuple(valueArr))
        cursor.execute(query, tuple(valueArr))

    @classmethod
    def insert(
        cls,
        cursor,
        *,
        table: str,
        columns: list[str],
        records: list[dict],
        primary_key: str,
    ):
        record_tuples = []
        for record in records:
            rec = []
            for column in columns:
                if column not in record:
                    raise ValueError(f"Required field {column} missing in insert query")
                if isinstance(record[column], SqlKeyword):
                    if len(records) != 1:
                        raise ValueError(
                            "SQL keywords are only allowed in single-record inserts"
                        )
                else:
                    rec.append(record[column])
            record_tuples.append(tuple(rec))
        percent_s_arr = []
        if len(records) == 1:
            for column in columns:
                if isinstance(records[0][column], SqlKeyword):
                    percent_s_arr.append(str(records[0][column]))
                else:
                    percent_s_arr.append("%s")
        else:
            percent_s_arr = ["%s" for column in columns]
        query = f"INSERT INTO {table} ({', '.join(columns)}) VALUES ({', '.join(percent_s_arr)})"
        query += f" ON CONFLICT DO NOTHING RETURNING {primary_key};"
        retval = None
        query = cls.cleanString(query)
        print(query)
        if len(record_tuples) == 1:
            cursor.execute(query, record_tuples[0])
            retval = cursor.fetchone()
            retval = retval[0] if retval else None
        else:
            cursor.executemany(query, record_tuples)
        return retval

    @classmethod
    def delete(cls, cursor, *, table: str, constraints: list[dict]):
        valueArr = []
        query = f"DELETE FROM {table}"
        if constraints:
            query += " WHERE "
            descriptions = [constraint["desc"] for constraint in constraints]
            query += " AND ".join(descriptions)
            values = [
                constraint["value"]
                for constraint in constraints
                if "value" in constraint
            ]
            valueArr.extend(values)
        query += ";"
        query = cls.cleanString(query)
        print(query)
        print(tuple(valueArr))
        cursor.execute(query, tuple(valueArr))

    @classmethod
    def lock(cls, cursor, *, table: str, mode: str = "EXCLUSIVE"):
        query = f"LOCK TABLE {table} IN {mode} MODE;"
        query = cls.cleanString(query)
        print(query)
        cursor.execute(query)

    @classmethod
    def filterRecord(
        cls,
        *,
        record: dict,
        columns: set[str],
        except_on_missing: bool = True,
        except_on_extra: bool = False,
        column_rename: dict = {},
    ):
        filtered_record = {}
        for column in columns:
            if column in record:
                new_column_name = (
                    column_rename[column] if column in column_rename else column
                )
                filtered_record[new_column_name] = record[column]
            else:
                if except_on_missing:
                    raise ValueError(
                        f"Column '{column}' is missing from the original record"
                    )
        if except_on_extra:
            for column in record:
                if column not in columns:
                    raise ValueError(
                        f"Original record contains extra column '{column}'"
                    )
        return filtered_record

    @classmethod
    def cleanString(cls, text: str) -> str:
        return " ".join(text.split())


def __init_module():
    # All global initializations go here. DO NOT put any code directly in the
    # global scope.
    pass


# Initialize the module

__init_module()
