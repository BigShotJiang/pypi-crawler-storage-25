"""GCP Secret Manager-backed credential provider using access tokens."""

from __future__ import annotations

import json
import os
from typing import Dict, Mapping, Optional
from urllib import parse as urllib_parse

from lumecode.base.python.gcp.secret_keeper import SecretKeeper
from lumecode.base.python.sqldb.credentials.provider import CredentialProvider


class CrdbCredentialProvider(CredentialProvider):
    """Secret Manager-backed provider using access token or ADC fallback."""

    _defaultProjectId = "895528748313"
    _defaultHost = "dev-cluster-8206.jxf.gcp-us-central1.cockroachlabs.cloud"
    _defaultPort = 26257
    _defaultSslMode = "verify-full"
    _databaseToSecretId = {
        "flow": "crdb-dev-sql-user-flow-writer",
        "lore": "crdb-password-dev-cluster-lore_writer",
        "vm_lifecycle": "crdb-dev-sql-user-vm-lifecycle-writer",
        "test_db": "crdb-dev-sql-user-test-db-writer",
        "spicedb": "crdb-dev-sql-user-spicedb-writer",
    }

    def __init__(
        self,
        secretId: Optional[str] = None,
        *,
        database: Optional[str] = None,
        projectId: str = _defaultProjectId,
        host: str = _defaultHost,
        port: int = _defaultPort,
        sslMode: str = _defaultSslMode,
    ) -> None:
        """Initialize with database mapping or an explicit secret identifier."""
        self._database = database
        self._secretId = secretId or self._mapDatabaseToSecretId(database)
        self._projectId = projectId
        self._host = host
        self._port = port
        self._sslMode = sslMode

    def getCredentials(self) -> str:
        """Fetch the secret payload as a JSON string using access token or ADC."""
        token = os.getenv("GCLOUD_ACCESS_TOKEN")
        secret_value = self._accessSecretPayload(accessToken=token)
        credentials = self._decodePayload(secret_value)
        self._validateSecretJson(credentials)
        return json.dumps(credentials)

    def getDatabaseUrl(self) -> str:
        """Construct a SQLAlchemy-compatible CRDB URL from the retrieved secret."""
        credentials = json.loads(self.getCredentials())
        user = credentials["user"]
        password = credentials["password"]
        database = credentials["database"]
        return self._buildDatabaseUrl(user=user, password=password, database=database)

    def _mapDatabaseToSecretId(self, database: Optional[str]) -> str:
        """Resolve the secret id from a known database name mapping."""
        if not database:
            raise RuntimeError("Either database or secretId must be provided.")
        secretId = self._databaseToSecretId.get(database)
        if not secretId:
            known = sorted(self._databaseToSecretId.keys())
            raise RuntimeError(
                f"No secretId mapping defined for database={database!r}. Known={known}"
            )
        return secretId

    def _accessSecretPayload(self, *, accessToken: Optional[str]) -> str:
        """Fetch the secret text using SecretKeeper and optional access token."""
        keeper = SecretKeeper(project=self._projectId, access_token=accessToken)
        try:
            return keeper.get(self._secretId)
        except Exception as exc:
            message = str(exc)
            raise RuntimeError(
                f"Secret Manager access failed for secret {self._secretId!r}: {message}"
            ) from exc

    def _decodePayload(self, secretValue: str) -> Dict[str, str]:
        """Parse JSON secret text into a dict."""
        try:
            parsed = json.loads(secretValue)
        except json.JSONDecodeError as exc:
            raise RuntimeError("Secret payload was not valid JSON.") from exc
        if not isinstance(parsed, dict):
            raise RuntimeError("Secret payload JSON must be an object.")
        return {str(k): str(v) for k, v in parsed.items()}

    def _validateSecretJson(self, credentials: Mapping[str, str]) -> None:
        """Ensure the secret contains the required CRDB credential keys."""
        requiredKeys = {"user", "password", "database"}
        missing = sorted(requiredKeys - set(credentials.keys()))
        if missing:
            raise RuntimeError(
                f"Secret payload is missing required keys: {missing}"
            )

    def _buildDatabaseUrl(self, *, user: str, password: str, database: str) -> str:
        """Return a properly escaped cockroachdb+asyncpg DATABASE_URL."""
        userEscaped = urllib_parse.quote(user, safe="")
        passwordEscaped = urllib_parse.quote(password, safe="")
        databaseEscaped = urllib_parse.quote(database, safe="")
        return (
            "cockroachdb+asyncpg://"
            f"{userEscaped}:{passwordEscaped}"
            f"@{self._host}:{self._port}/{databaseEscaped}"
            f"?sslmode={self._sslMode}"
        )


# Public module-level defaults for tests and callers.
defaultProjectId = CrdbCredentialProvider._defaultProjectId
