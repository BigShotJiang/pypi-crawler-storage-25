"""Credential provider interfaces for CRDB connection metadata."""

from __future__ import annotations

import abc


class CredentialProvider(abc.ABC):
    """Abstract interface for resolving a database URL at runtime."""

    @abc.abstractmethod
    def getDatabaseUrl(self) -> str:
        """Return the resolved DATABASE_URL for runtime use."""
        pass
