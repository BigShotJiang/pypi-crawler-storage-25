from __future__ import annotations

import asyncio
import socket
import sys
import time
from dataclasses import dataclass

import grpc
from opentelemetry.proto.collector.logs.v1 import logs_service_pb2, logs_service_pb2_grpc

from lumecode.base.python.net.target_parser import NetTarget


def _findFreeTcpPort() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


@dataclass(frozen=True)
class CapturedOtelLog:
    serviceName: str
    streamName: str
    severity: str
    message: str


class OtlpTestLogCollector(logs_service_pb2_grpc.LogsServiceServicer):
    def __init__(self) -> None:
        self._capturedLogs: list[CapturedOtelLog] = []
        self._nextDumpIndex = 0
        self._condition = asyncio.Condition()
        self._server: grpc.aio.Server | None = None
        self._endpointTarget = ""

    @staticmethod
    def _anyValueToString(value) -> str:
        if value is None:
            return ""
        kind = value.WhichOneof("value")
        if kind == "string_value":
            return value.string_value
        if kind == "bool_value":
            return "true" if value.bool_value else "false"
        if kind == "int_value":
            return str(value.int_value)
        if kind == "double_value":
            return str(value.double_value)
        if kind == "bytes_value":
            try:
                return value.bytes_value.decode("utf-8", errors="replace")
            except Exception:
                return "<bytes>"
        if kind == "array_value":
            return f"<array:{len(value.array_value.values)}>"
        if kind == "kvlist_value":
            return f"<kvlist:{len(value.kvlist_value.values)}>"
        return ""

    @classmethod
    def _extractServiceName(cls, resourceLogs) -> str:
        for attribute in resourceLogs.resource.attributes:
            if attribute.key == "service.name":
                return cls._anyValueToString(attribute.value)
        return ""

    @classmethod
    def _extractLogRecordAttribute(cls, logRecord, key: str) -> str:
        for attribute in logRecord.attributes:
            if attribute.key == key:
                return cls._anyValueToString(attribute.value)
        return ""

    async def async_start(self, endpointTarget: str = "") -> str:
        if self._server is not None:
            raise RuntimeError("OTLP test collector is already started.")
        resolvedTarget = endpointTarget.strip() or f"tcp://127.0.0.1:{_findFreeTcpPort()}"
        self._server = grpc.aio.server()
        logs_service_pb2_grpc.add_LogsServiceServicer_to_server(self, self._server)
        boundPort = await NetTarget.parseTarget(resolvedTarget).withUdsMode(0o666).async_bindGrpcAioServer(
            self._server
        )
        if boundPort == 0:
            self._server = None
            raise RuntimeError(f"Failed to bind OTLP test collector on target={resolvedTarget}")
        parsedTarget = NetTarget.parseTarget(resolvedTarget)
        if parsedTarget.getPath() is None and parsedTarget.getPort() == 0:
            resolvedTarget = f"tcp://{parsedTarget.getHost()}:{boundPort}"
        self._endpointTarget = resolvedTarget
        return self._endpointTarget

    async def async_stop(self) -> None:
        if self._server is None:
            return
        await self._server.stop(grace=0.5)
        self._server = None
        self._endpointTarget = ""

    def endpointTarget(self) -> str:
        return self._endpointTarget

    async def Export(self, request, context):  # type: ignore[override]
        _ = context
        pending: list[CapturedOtelLog] = []
        for resourceLogs in request.resource_logs:
            serviceName = self._extractServiceName(resourceLogs)
            for scopeLogs in resourceLogs.scope_logs:
                for logRecord in scopeLogs.log_records:
                    severity = (
                        logRecord.severity_text
                        if logRecord.severity_text
                        else str(logRecord.severity_number)
                    )
                    streamName = self._extractLogRecordAttribute(logRecord, "stream")
                    pending.append(
                        CapturedOtelLog(
                            serviceName=serviceName,
                            streamName=streamName,
                            severity=severity,
                            message=self._anyValueToString(logRecord.body),
                        )
                    )
        if pending:
            async with self._condition:
                self._capturedLogs.extend(pending)
                self._condition.notify_all()
        return logs_service_pb2.ExportLogsServiceResponse()

    async def async_drainCapturedLogs(self) -> list[CapturedOtelLog]:
        async with self._condition:
            drained = list(self._capturedLogs)
            self._capturedLogs.clear()
            self._nextDumpIndex = 0
        return drained

    async def async_waitForMessageContains(
        self,
        *,
        substring: str,
        timeoutSeconds: float,
    ) -> CapturedOtelLog:
        deadline = time.time() + timeoutSeconds
        async with self._condition:
            while True:
                for logEntry in self._capturedLogs:
                    if substring in logEntry.message:
                        return logEntry
                remaining = deadline - time.time()
                if remaining <= 0:
                    raise TimeoutError(
                        f"Timed out waiting for OTLP log containing '{substring}'. "
                        f"captured_count={len(self._capturedLogs)}"
                    )
                await asyncio.wait_for(self._condition.wait(), timeout=remaining)

    async def async_dumpAndClearCapturedLogsToStdout(
        self,
        *,
        label: str,
    ) -> None:
        async with self._condition:
            startIndex = max(self._nextDumpIndex, 0)
            if startIndex >= len(self._capturedLogs):
                return
            pending = list(self._capturedLogs[startIndex:])
            self._nextDumpIndex = len(self._capturedLogs)
        if not pending:
            return
        for logEntry in pending:
            sys.stdout.write(
                "collector-otlp-log "
                f"label={label} "
                f"service={logEntry.serviceName or 'unknown'} "
                f"stream={logEntry.streamName or 'unspecified'} "
                f"severity={logEntry.severity} "
                f"message={logEntry.message}\n"
            )
        sys.stdout.flush()


@dataclass(frozen=True)
class CapturedFluentPayload:
    rawBytes: bytes
    printable: str


class FluentTestLogCollector:
    def __init__(self) -> None:
        self._capturedPayloads: list[CapturedFluentPayload] = []
        self._nextDumpIndex = 0
        self._combinedRawBytes = b""
        self._condition = asyncio.Condition()
        self._server: asyncio.AbstractServer | None = None
        self._address = ""

    async def async_start(self) -> str:
        if self._server is not None:
            raise RuntimeError("Fluent test collector is already started.")
        self._server = await asyncio.start_server(
            self._async_handleConnection,
            host="127.0.0.1",
            port=0,
            start_serving=True,
        )
        sockets = list(self._server.sockets or [])
        if not sockets:
            await self.async_stop()
            raise RuntimeError("Fluent test collector failed to expose a listening socket.")
        host, port = sockets[0].getsockname()[:2]
        self._address = f"{host}:{port}"
        return self._address

    async def async_stop(self) -> None:
        if self._server is None:
            self._address = ""
            return
        self._server.close()
        await self._server.wait_closed()
        self._server = None
        self._address = ""

    def address(self) -> str:
        return self._address

    async def _async_handleConnection(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        try:
            while True:
                chunk = await reader.read(4096)
                if not chunk:
                    break
                await self._async_recordPayload(chunk)
        finally:
            writer.close()
            await writer.wait_closed()

    async def _async_recordPayload(self, payload: bytes) -> None:
        captured = CapturedFluentPayload(
            rawBytes=payload,
            printable=self._toPrintable(payload),
        )
        async with self._condition:
            self._combinedRawBytes += payload
            self._capturedPayloads.append(captured)
            self._condition.notify_all()

    @staticmethod
    def _toPrintable(payload: bytes) -> str:
        parts: list[str] = []
        for byteValue in payload:
            if 32 <= byteValue <= 126:
                parts.append(chr(byteValue))
            else:
                parts.append(f"\\x{byteValue:02x}")
        return "".join(parts)

    async def async_drainCapturedPayloads(self) -> list[CapturedFluentPayload]:
        async with self._condition:
            drained = list(self._capturedPayloads)
            self._capturedPayloads.clear()
            self._nextDumpIndex = 0
            self._combinedRawBytes = b""
        return drained

    async def async_waitForPayloadContains(
        self,
        *,
        token: str,
        timeoutSeconds: float,
    ) -> None:
        deadline = time.time() + timeoutSeconds
        tokenBytes = token.encode("utf-8")
        async with self._condition:
            while True:
                if tokenBytes in self._combinedRawBytes:
                    return
                remaining = deadline - time.time()
                if remaining <= 0:
                    raise TimeoutError(
                        f"Timed out waiting for Fluent payload containing '{token}'. "
                        f"captured_payload_count={len(self._capturedPayloads)}"
                    )
                await asyncio.wait_for(self._condition.wait(), timeout=remaining)

    async def async_dumpAndClearCapturedLogsToStdout(
        self,
        *,
        label: str,
    ) -> None:
        async with self._condition:
            startIndex = max(self._nextDumpIndex, 0)
            if startIndex >= len(self._capturedPayloads):
                return
            pending = list(self._capturedPayloads[startIndex:])
            self._nextDumpIndex = len(self._capturedPayloads)
        if not pending:
            return
        for payload in pending:
            sys.stdout.write(
                f"collector-fluent-log label={label} payload={payload.printable}\n"
            )
        sys.stdout.flush()
