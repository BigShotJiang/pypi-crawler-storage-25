"""Shared logging helpers for OTEL log export configuration."""

from __future__ import annotations

import argparse
from collections.abc import Mapping
from contextlib import contextmanager
import contextvars
from datetime import datetime, timezone
from enum import Enum
import json
import logging
import os
import threading
import traceback
from dataclasses import dataclass, field
from typing import Any
import uuid

from lumecode.base.python.net.target_parser import NetTarget

LOG = logging.getLogger(__name__)
OTEL_EXPORTER_OTLP_ENDPOINT_ENV = "OTEL_EXPORTER_OTLP_ENDPOINT"
OTEL_SERVICE_NAME_ENV = "OTEL_SERVICE_NAME"
OTEL_SERVICE_INSTANCE_ID_ENV = "OTEL_SERVICE_INSTANCE_ID"
LUMESOF_OTEL_EXPORTER_OTLP_ENDPOINT_ENV = "LUMESOF_OTEL_EXPORTER_OTLP_ENDPOINT"
LUMESOF_OTEL_SERVICE_NAME_ENV = "LUMESOF_OTEL_SERVICE_NAME"
LUMESOF_OTEL_SERVICE_INSTANCE_ID_ENV = "LUMESOF_OTEL_SERVICE_INSTANCE_ID"
LUMESOF_LOGS_FILE_ENV = "LUMESOF_LOGS_FILE"
DEFAULT_LUMESOF_LOGS_DIR = "/lumesof/pkg_data/carton/logs"
LOG_LEVEL_ENV = "LUMESOF_LOG_LEVEL"
SIDECAR_LOG_LEVEL_ENV = "LUMESOF_LOG_LEVEL"
EVENT = "event"
EVENT_OUTCOME = "event.outcome"
EXCEPTION = "exception"
RPC_METHOD = "rpc.method"
TRACE_ID = "trace_id"
LUMESOF_APP_ID = "lumesof.app_id"
LUMESOF_BACKEND = "lumesof.backend"
LUMESOF_CLUSTER_ID = "lumesof.cluster_id"
LUMESOF_CONTROLLER_ID = "lumesof.controller_id"
LUMESOF_EXECUTOR_ID = "lumesof.executor_id"
LUMESOF_EXECUTOR_NAME = "lumesof.executor_name"
LUMESOF_EXECUTOR_TYPE = "lumesof.executor_type"
LUMESOF_JOB_ID = "lumesof.job_id"
LUMESOF_JOB_STATUS = "lumesof.job_status"
LUMESOF_LINK_REF = "lumesof.link_ref"
LUMESOF_MESSAGE_ID = "lumesof.message_id"
LUMESOF_NODE_ID = "lumesof.node_id"
LUMESOF_OPERATOR_ID = "lumesof.operator_id"
LUMESOF_OPERATOR_NAME = "lumesof.operator_name"
LUMESOF_OWNER = "lumesof.owner"
LUMESOF_PAYLOAD_TYPE = "lumesof.payload_type"
LUMESOF_PORT = "lumesof.port"
LUMESOF_STAGE = "lumesof.stage"
LUMESOF_STREAM_KIND = "lumesof.stream_kind"
LUMESOF_SUBSTRATE = "lumesof.substrate"
LUMESOF_USECASE = "lumesof.usecase"

_LOG_LEVEL_BY_NAME = {
    "CRITICAL": logging.CRITICAL,
    "FATAL": logging.CRITICAL,
    "ERROR": logging.ERROR,
    "WARNING": logging.WARNING,
    "WARN": logging.WARNING,
    "INFO": logging.INFO,
    "DEBUG": logging.DEBUG,
}
_STRUCTURED_CONTEXT: contextvars.ContextVar[dict[str, Any]] = contextvars.ContextVar(
    "lumesof_logging_structured_context",
    default={},
)
_RECORD_FACTORY_LOCK = threading.Lock()
_RECORD_FACTORY_DELEGATE = logging.getLogRecordFactory()
_RESERVED_LOG_RECORD_KEYS = (
    set(logging.LogRecord(None, 0, "", 0, "", (), None).__dict__.keys())
    | {"message", "asctime"}
)
_JSON_LOG_COMMON_FIELDS = ("timestamp", "severity", "logger", "message")


def _structuredRecordFactory(*args: Any, **kwargs: Any) -> logging.LogRecord:
    record = _RECORD_FACTORY_DELEGATE(*args, **kwargs)
    for key, value in _STRUCTURED_CONTEXT.get().items():
        record.__dict__.setdefault(key, value)
    return record


def _ensureStructuredRecordFactoryInstalled() -> None:
    global _RECORD_FACTORY_DELEGATE

    with _RECORD_FACTORY_LOCK:
        currentFactory = logging.getLogRecordFactory()
        if currentFactory is _structuredRecordFactory:
            return
        _RECORD_FACTORY_DELEGATE = currentFactory
        logging.setLogRecordFactory(_structuredRecordFactory)


def _normalizeDatetime(value: datetime) -> str:
    if value.tzinfo is None:
        utcValue = value.replace(tzinfo=timezone.utc)
    else:
        utcValue = value.astimezone(timezone.utc)
    return utcValue.isoformat().replace("+00:00", "Z")


def _normalizeLogValue(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, uuid.UUID):
        return str(value)
    if isinstance(value, datetime):
        return _normalizeDatetime(value)
    if isinstance(value, Enum):
        return value.name
    if isinstance(value, (list, tuple)):
        return [_normalizeLogValue(item) for item in value]
    raise TypeError(f"Unsupported structured log value type: {type(value).__name__}")


def _normalizeStructuredAttrs(attrs: Mapping[str, Any] | None) -> dict[str, Any]:
    normalized: dict[str, Any] = {}
    if attrs is None:
        return normalized
    for key, value in attrs.items():
        if not isinstance(key, str):
            raise TypeError(f"Structured log key must be str, got {type(key).__name__}")
        normalizedKey = key.strip()
        if not normalizedKey:
            raise ValueError("Structured log key must be a non-empty string.")
        if normalizedKey in _RESERVED_LOG_RECORD_KEYS:
            raise KeyError(f"Structured log key is reserved: {normalizedKey}")
        normalized[normalizedKey] = _normalizeLogValue(value)
    return normalized


def _mergeStructuredAttrs(
    *,
    boundAttrs: Mapping[str, Any] | None = None,
    attrs: Mapping[str, Any] | None = None,
    event: str | None = None,
) -> dict[str, Any]:
    merged = _normalizeStructuredAttrs(boundAttrs)
    merged.update(_normalizeStructuredAttrs(attrs))
    if event is not None:
        merged[EVENT] = _normalizeLogValue(event)
    return merged


def _normalizeJsonValue(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): _normalizeJsonValue(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_normalizeJsonValue(item) for item in value]
    try:
        return _normalizeLogValue(value)
    except TypeError:
        return str(value)


def _extractStructuredRecordAttrs(record: logging.LogRecord) -> dict[str, Any]:
    structuredAttrs: dict[str, Any] = {}
    for key, value in record.__dict__.items():
        if key in _RESERVED_LOG_RECORD_KEYS or key.startswith("_"):
            continue
        structuredAttrs[key] = _normalizeJsonValue(value)
    return structuredAttrs


def _buildStructuredException(record: logging.LogRecord) -> dict[str, Any] | None:
    if record.exc_info:
        exceptionType, exceptionValue, exceptionTraceback = record.exc_info
        exceptionName = (
            exceptionType.__name__ if isinstance(exceptionType, type) else type(exceptionValue).__name__
        )
        return {
            "type": exceptionName,
            "message": str(exceptionValue),
            "stacktrace": "".join(
                traceback.format_exception(exceptionType, exceptionValue, exceptionTraceback)
            ).rstrip(),
        }
    if record.exc_text:
        return {
            "type": "",
            "message": "",
            "stacktrace": str(record.exc_text).rstrip(),
        }
    return None


class JsonLogFormatter(logging.Formatter):
    """One-line JSON formatter with stable common fields and top-level structured attrs.

    Top-level fields:
    - timestamp
    - severity
    - logger
    - message
    - exception (when present)
    - any additional non-reserved LogRecord attributes
    """

    def format(self, record: logging.LogRecord) -> str:
        logEntry: dict[str, Any] = {
            "timestamp": _normalizeDatetime(datetime.fromtimestamp(record.created, tz=timezone.utc)),
            "severity": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        exception = _buildStructuredException(record)
        if exception is not None:
            logEntry["exception"] = exception
        logEntry.update(_extractStructuredRecordAttrs(record))
        return json.dumps(logEntry, separators=(",", ":"), ensure_ascii=True)


@dataclass(slots=True)
class StructuredLogger:
    _logger: logging.Logger
    _boundAttrs: dict[str, Any] = field(default_factory=dict)

    def bind(self, **attrs: Any) -> StructuredLogger:
        mergedAttrs = _mergeStructuredAttrs(boundAttrs=self._boundAttrs, attrs=attrs)
        return StructuredLogger(self._logger, mergedAttrs)

    def debug(
        self,
        message: str,
        *args: Any,
        event: str | None = None,
        attrs: Mapping[str, Any] | None = None,
        exc_info: Any = False,
    ) -> None:
        self._log(logging.DEBUG, message, *args, event=event, attrs=attrs, exc_info=exc_info)

    def info(
        self,
        message: str,
        *args: Any,
        event: str | None = None,
        attrs: Mapping[str, Any] | None = None,
        exc_info: Any = False,
    ) -> None:
        self._log(logging.INFO, message, *args, event=event, attrs=attrs, exc_info=exc_info)

    def warning(
        self,
        message: str,
        *args: Any,
        event: str | None = None,
        attrs: Mapping[str, Any] | None = None,
        exc_info: Any = False,
    ) -> None:
        self._log(logging.WARNING, message, *args, event=event, attrs=attrs, exc_info=exc_info)

    def error(
        self,
        message: str,
        *args: Any,
        event: str | None = None,
        attrs: Mapping[str, Any] | None = None,
        exc_info: Any = False,
    ) -> None:
        self._log(logging.ERROR, message, *args, event=event, attrs=attrs, exc_info=exc_info)

    def exception(
        self,
        message: str,
        *args: Any,
        event: str | None = None,
        attrs: Mapping[str, Any] | None = None,
    ) -> None:
        self._log(logging.ERROR, message, *args, event=event, attrs=attrs, exc_info=True)

    def _log(
        self,
        level: int,
        message: str,
        *args: Any,
        event: str | None,
        attrs: Mapping[str, Any] | None,
        exc_info: Any,
    ) -> None:
        mergedAttrs = _mergeStructuredAttrs(boundAttrs=self._boundAttrs, attrs=attrs, event=event)
        contextToken = None
        currentContext = _STRUCTURED_CONTEXT.get()
        if currentContext:
            overlappingKeys = currentContext.keys() & mergedAttrs.keys()
            if overlappingKeys:
                filteredContext = {
                    key: value for key, value in currentContext.items() if key not in overlappingKeys
                }
                contextToken = _STRUCTURED_CONTEXT.set(filteredContext)
        try:
            self._logger.log(level, message, *args, extra=mergedAttrs, exc_info=exc_info)
        finally:
            if contextToken is not None:
                _STRUCTURED_CONTEXT.reset(contextToken)


def getLogger(name: str | None = None) -> StructuredLogger:
    _ensureStructuredRecordFactoryInstalled()
    return StructuredLogger(logging.getLogger(name))


@contextmanager
def loggingContext(**attrs: Any):
    _ensureStructuredRecordFactoryInstalled()
    mergedContext = _mergeStructuredAttrs(boundAttrs=_STRUCTURED_CONTEXT.get(), attrs=attrs)
    token = _STRUCTURED_CONTEXT.set(mergedContext)
    try:
        yield
    finally:
        _STRUCTURED_CONTEXT.reset(token)


def resolveLogLevelFromEnv(*, envVarName: str = LOG_LEVEL_ENV) -> int:
    configuredLevel = os.environ.get(envVarName, "").strip().upper()
    if not configuredLevel:
        return logging.WARNING
    return _LOG_LEVEL_BY_NAME.get(configuredLevel, logging.WARNING)


def resolveSidecarLogLevelFromEnv() -> int:
    return resolveLogLevelFromEnv(envVarName=SIDECAR_LOG_LEVEL_ENV)


def _runWithTimeout(
    *,
    fn: Any,
    timeoutSeconds: float,
    timeoutMessage: str,
    failureMessage: str,
) -> None:
    if not callable(fn):
        return
    failure: list[BaseException] = []

    def _runFn() -> None:
        try:
            fn()
        except BaseException as exc:  # pragma: no cover
            failure.append(exc)

    workerThread = threading.Thread(target=_runFn, daemon=True)
    workerThread.start()
    workerThread.join(max(timeoutSeconds, 0.0))
    if workerThread.is_alive():
        LOG.warning(timeoutMessage)
    if failure:
        raise RuntimeError(failureMessage) from failure[0]


@contextmanager
def _suppressException(message: str):
    try:
        yield
    except Exception:  # pragma: no cover
        LOG.exception(message)


@dataclass(slots=True)
class OtelLogRuntime:
    loggerProvider: Any
    handler: Any
    rootLogger: logging.Logger

    def flush(self, *, timeoutSeconds: float = 1.0) -> None:
        _runWithTimeout(
            fn=getattr(self.loggerProvider, "force_flush", None),
            timeoutSeconds=timeoutSeconds,
            timeoutMessage="Timed out while force flushing OTel logger provider.",
            failureMessage="OTel logger provider force_flush failed.",
        )

    def shutdown(self, *, timeoutSeconds: float = 1.0) -> None:
        self.rootLogger.removeHandler(self.handler)
        _runWithTimeout(
            fn=getattr(self.loggerProvider, "shutdown", None),
            timeoutSeconds=timeoutSeconds,
            timeoutMessage="Timed out while shutting down OTel logger provider.",
            failureMessage="OTel logger provider shutdown failed.",
        )


@dataclass(slots=True)
class LoggingDestinationsRuntime:
    rootLogger: logging.Logger = field(default_factory=logging.getLogger)
    otelRuntimes: list[OtelLogRuntime] = field(default_factory=list)
    localFileHandlers: list[logging.Handler] = field(default_factory=list)
    _otelEndpoints: set[str] = field(default_factory=set)
    _localLogPaths: set[str] = field(default_factory=set)

    def flush(self, *, timeoutSeconds: float = 1.0) -> None:
        for handler in list(self.localFileHandlers):
            try:
                handler.flush()
            except Exception:  # pragma: no cover
                LOG.exception(f"Failed to flush local file handler {type(handler).__name__}")
        for runtime in list(self.otelRuntimes):
            runtime.flush(timeoutSeconds=timeoutSeconds)

    def shutdown(self, *, timeoutSeconds: float = 1.0) -> None:
        for handler in list(self.localFileHandlers):
            with _suppressException(
                f"Failed while removing local file handler {type(handler).__name__}"
            ):
                self.rootLogger.removeHandler(handler)
            with _suppressException(
                f"Failed while closing local file handler {type(handler).__name__}"
            ):
                handler.close()
        self.localFileHandlers.clear()
        self._localLogPaths.clear()
        for runtime in list(self.otelRuntimes):
            runtime.shutdown(timeoutSeconds=timeoutSeconds)
        self.otelRuntimes.clear()
        self._otelEndpoints.clear()


def addOtelLogFlags(
    parser: argparse.ArgumentParser,
    *,
    defaultServiceName: str = "lumesof-service",
    includeServiceNameFlag: bool = True,
) -> None:
    parser.add_argument(
        "--otel-logs-endpoint",
        default="",
        help=(
            "Optional OTLP gRPC endpoint target in parseTarget format. "
            "Examples: tcp://127.0.0.1:4317 or unix:///tmp/otel-logs.sock."
        ),
    )
    if includeServiceNameFlag:
        parser.add_argument(
            "--otel-logs-service-name",
            default=defaultServiceName,
            help="OTel service.name resource attribute for exported logs.",
        )
    parser.add_argument(
        "--otel-logs-max-queue-size",
        type=int,
        default=2048,
        help="Maximum queued log records before OTel exporter drops new records.",
    )
    parser.add_argument(
        "--otel-logs-max-export-batch-size",
        type=int,
        default=512,
        help="Maximum OTel log records per export batch.",
    )
    parser.add_argument(
        "--otel-logs-schedule-delay-ms",
        type=int,
        default=500,
        help="OTel batch processor schedule delay in milliseconds.",
    )
    parser.add_argument(
        "--otel-logs-export-timeout-ms",
        type=int,
        default=30000,
        help="OTel batch processor export timeout in milliseconds.",
    )


def _buildOtelGrpcEndpoint(target: str) -> str:
    normalizedTarget = target.strip()
    if not normalizedTarget.startswith(("tcp://", "unix:///")):
        normalizedTarget = f"tcp://{normalizedTarget}"
    _parsed = NetTarget.parseTarget(normalizedTarget)
    if _parsed.getPath() is not None:
        normalizedPath = _parsed.getPath()
        if not normalizedPath.startswith("/"):
            normalizedPath = f"/{normalizedPath}"
        return f"unix://{normalizedPath}"
    return f"http://{_parsed.getHost()}:{_parsed.getPort()}"


def _normalizeOtelGrpcEndpoint(target: str) -> str:
    normalizedTarget = target.strip()
    if not normalizedTarget:
        return ""
    if normalizedTarget.startswith(("http://", "https://", "unix://")):
        return normalizedTarget
    return _buildOtelGrpcEndpoint(normalizedTarget)


def _loadOtelDeps() -> tuple[Any, Any, Any, Any, Any]:
    try:
        from opentelemetry.exporter.otlp.proto.grpc._log_exporter import OTLPLogExporter
        from opentelemetry.sdk._logs import LoggerProvider, LoggingHandler
        from opentelemetry.sdk._logs.export import BatchLogRecordProcessor
        from opentelemetry.sdk.resources import Resource
    except ImportError as exc:
        raise RuntimeError(
            "OTel log export requested but opentelemetry dependencies are unavailable."
        ) from exc
    return OTLPLogExporter, LoggerProvider, LoggingHandler, BatchLogRecordProcessor, Resource


def configureOtelLogExport(
    *,
    endpointTarget: str,
    serviceName: str,
    serviceInstanceId: str,
    maxQueueSize: int,
    maxExportBatchSize: int,
    scheduleDelayMs: int,
    exportTimeoutMs: int,
) -> OtelLogRuntime | None:
    normalizedTarget = endpointTarget.strip()
    if not normalizedTarget:
        return None
    if maxQueueSize <= 0:
        raise RuntimeError("--otel-logs-max-queue-size must be > 0")
    if maxExportBatchSize <= 0:
        raise RuntimeError("--otel-logs-max-export-batch-size must be > 0")
    if maxExportBatchSize > maxQueueSize:
        raise RuntimeError("--otel-logs-max-export-batch-size must be <= queue size")
    if scheduleDelayMs <= 0:
        raise RuntimeError("--otel-logs-schedule-delay-ms must be > 0")
    if exportTimeoutMs <= 0:
        raise RuntimeError("--otel-logs-export-timeout-ms must be > 0")

    OTLPLogExporter, LoggerProvider, LoggingHandler, BatchLogRecordProcessor, Resource = _loadOtelDeps()
    endpoint = _normalizeOtelGrpcEndpoint(normalizedTarget)
    resource = Resource.create(
        {
            "service.name": serviceName,
            "service.instance.id": serviceInstanceId,
        }
    )
    loggerProvider = LoggerProvider(resource=resource)
    exporter = OTLPLogExporter(
        endpoint=endpoint,
        insecure=True,
    )
    processor = BatchLogRecordProcessor(
        exporter,
        max_queue_size=maxQueueSize,
        max_export_batch_size=maxExportBatchSize,
        schedule_delay_millis=scheduleDelayMs,
        export_timeout_millis=exportTimeoutMs,
    )
    loggerProvider.add_log_record_processor(processor)
    handler = LoggingHandler(level=logging.NOTSET, logger_provider=loggerProvider)
    rootLogger = logging.getLogger()
    rootLogger.addHandler(handler)
    LOG.debug(f"Configured OTel log export endpoint={endpoint}")
    return OtelLogRuntime(
        loggerProvider=loggerProvider,
        handler=handler,
        rootLogger=rootLogger,
    )


def configureOtelLogExportFromArgs(
    *,
    args: argparse.Namespace,
    serviceInstanceId: str,
) -> OtelLogRuntime | None:
    endpointTarget = getattr(args, "otel_logs_endpoint", "")
    if not str(endpointTarget).strip():
        return None
    try:
        return configureOtelLogExport(
            endpointTarget=endpointTarget,
            serviceName=getattr(args, "otel_logs_service_name", "lumeflow-sidecar"),
            serviceInstanceId=serviceInstanceId,
            maxQueueSize=getattr(args, "otel_logs_max_queue_size", 2048),
            maxExportBatchSize=getattr(args, "otel_logs_max_export_batch_size", 512),
            scheduleDelayMs=getattr(args, "otel_logs_schedule_delay_ms", 500),
            exportTimeoutMs=getattr(args, "otel_logs_export_timeout_ms", 30000),
        )
    except Exception:
        LOG.error(
            "Failed to configure OTel log export from args endpoint=%s service_instance_id=%s",
            endpointTarget,
            serviceInstanceId,
            exc_info=True,
        )
        return None


def configureOtelLogExportFromEnv(
    *,
    defaultServiceName: str,
    defaultServiceInstanceId: str,
) -> OtelLogRuntime | None:
    endpointTarget = os.environ.get(OTEL_EXPORTER_OTLP_ENDPOINT_ENV, "").strip()
    if not endpointTarget:
        return None
    serviceName = os.environ.get(OTEL_SERVICE_NAME_ENV, "").strip() or defaultServiceName
    serviceInstanceId = os.environ.get(OTEL_SERVICE_INSTANCE_ID_ENV, "").strip() or defaultServiceInstanceId
    try:
        return configureOtelLogExport(
            endpointTarget=endpointTarget,
            serviceName=serviceName,
            serviceInstanceId=serviceInstanceId,
            maxQueueSize=2048,
            maxExportBatchSize=512,
            scheduleDelayMs=500,
            exportTimeoutMs=30000,
        )
    except Exception:
        LOG.error(
            "Failed to configure OTel log export from env endpoint=%s service_name=%s service_instance_id=%s",
            endpointTarget,
            serviceName,
            serviceInstanceId,
            exc_info=True,
        )
        return None


def _buildDefaultLocalLogFileName(serviceInstanceId: str) -> str:
    candidate = serviceInstanceId.strip() or "lumesof-service"
    safe = "".join(
        ch if ch.isalnum() or ch in ("-", "_", ".") else "_"
        for ch in candidate
    ).strip("._")
    if not safe:
        safe = "lumesof-service"
    return f"{safe}.log"


def _resolveLocalLogFilePath(*, logsDir: str, fileName: str) -> str:
    resolvedDir = os.path.abspath(logsDir.strip())
    return os.path.abspath(os.path.join(resolvedDir, fileName))


def _configureLocalFileLogging(*, logsDir: str, fileName: str) -> tuple[logging.Handler, str]:
    resolvedPath = _resolveLocalLogFilePath(logsDir=logsDir, fileName=fileName)
    return _configureLocalFileLoggingPath(resolvedPath=resolvedPath)


def _configureLocalFileLoggingPath(*, resolvedPath: str) -> tuple[logging.Handler, str]:
    normalizedPath = os.path.abspath(resolvedPath.strip())
    os.makedirs(os.path.dirname(normalizedPath), exist_ok=True)
    handler = logging.FileHandler(normalizedPath, encoding="utf-8")
    handler.setFormatter(JsonLogFormatter())
    rootLogger = logging.getLogger()
    rootLogger.addHandler(handler)
    LOG.info(f"Configured local file logging path={normalizedPath}")
    return handler, normalizedPath


def _addOtelDestination(
    *,
    runtime: LoggingDestinationsRuntime,
    endpointTarget: str,
    serviceName: str,
    serviceInstanceId: str,
    maxQueueSize: int,
    maxExportBatchSize: int,
    scheduleDelayMs: int,
    exportTimeoutMs: int,
) -> None:
    try:
        normalizedEndpoint = _normalizeOtelGrpcEndpoint(endpointTarget)
        if not normalizedEndpoint:
            return
        if normalizedEndpoint in runtime._otelEndpoints:
            return
        otelRuntime = configureOtelLogExport(
            endpointTarget=normalizedEndpoint,
            serviceName=serviceName,
            serviceInstanceId=serviceInstanceId,
            maxQueueSize=maxQueueSize,
            maxExportBatchSize=maxExportBatchSize,
            scheduleDelayMs=scheduleDelayMs,
            exportTimeoutMs=exportTimeoutMs,
        )
        if otelRuntime is None:
            return
        runtime.otelRuntimes.append(otelRuntime)
        runtime._otelEndpoints.add(normalizedEndpoint)
        LOG.info(
            "Added logging destination type=otel endpoint=%s service_name=%s service_instance_id=%s",
            normalizedEndpoint,
            serviceName,
            serviceInstanceId,
        )
    except Exception:
        LOG.error(
            "Failed to add logging destination type=otel endpoint=%s service_name=%s service_instance_id=%s",
            endpointTarget,
            serviceName,
            serviceInstanceId,
            exc_info=True,
        )


def _addLocalFileDestination(
    *,
    runtime: LoggingDestinationsRuntime,
    logsDir: str,
    fileName: str,
) -> None:
    normalizedDir = logsDir.strip()
    if not normalizedDir:
        return
    resolvedPath = _resolveLocalLogFilePath(logsDir=normalizedDir, fileName=fileName)
    _addLocalFileDestinationPath(runtime=runtime, resolvedPath=resolvedPath)


def _addLocalFileDestinationPath(
    *,
    runtime: LoggingDestinationsRuntime,
    resolvedPath: str,
) -> None:
    normalizedPath = os.path.abspath(resolvedPath.strip())
    if not normalizedPath:
        return
    if normalizedPath in runtime._localLogPaths:
        return
    try:
        handler, path = _configureLocalFileLoggingPath(resolvedPath=normalizedPath)
    except Exception:
        LOG.error(
            "Failed to add logging destination type=local_file path=%s",
            normalizedPath,
            exc_info=True,
        )
        return
    runtime.localFileHandlers.append(handler)
    runtime._localLogPaths.add(path)
    LOG.info("Added logging destination type=local_file path=%s", path)


def _resolveEnvLogsFilePath(
    *,
    logsFileValue: str,
    defaultLogsDir: str = DEFAULT_LUMESOF_LOGS_DIR,
) -> str:
    normalizedValue = logsFileValue.strip()
    if not normalizedValue:
        return ""
    expandedValue = os.path.expanduser(normalizedValue)
    if os.path.isabs(expandedValue):
        return os.path.abspath(expandedValue)
    baseDir = defaultLogsDir.strip() or DEFAULT_LUMESOF_LOGS_DIR
    return os.path.abspath(os.path.join(baseDir, expandedValue))


def configureLoggingDestinationsFromEnv(
    *,
    defaultServiceName: str,
    defaultServiceInstanceId: str,
    serviceName: str = "",
    logLevelEnvVar: str = LOG_LEVEL_ENV,
    otelEndpointEnvVar: str = OTEL_EXPORTER_OTLP_ENDPOINT_ENV,
    otelServiceNameEnvVar: str = OTEL_SERVICE_NAME_ENV,
    otelServiceInstanceIdEnvVar: str = OTEL_SERVICE_INSTANCE_ID_ENV,
    localLogsFileEnvVar: str = LUMESOF_LOGS_FILE_ENV,
    localLogsDefaultDir: str = DEFAULT_LUMESOF_LOGS_DIR,
) -> LoggingDestinationsRuntime:
    runtime = LoggingDestinationsRuntime()
    resolvedLevel = resolveLogLevelFromEnv(envVarName=logLevelEnvVar)
    try:
        runtime.rootLogger.setLevel(resolvedLevel)
        LOG.info(
            "Applied logging level from env var=%s level=%s",
            logLevelEnvVar,
            logging.getLevelName(resolvedLevel),
        )
    except Exception:
        LOG.error(
            "Failed to apply logging level from env var=%s level=%s",
            logLevelEnvVar,
            resolvedLevel,
            exc_info=True,
        )
    envLogsFile = os.environ.get(localLogsFileEnvVar, "").strip()
    if envLogsFile:
        resolvedPath = _resolveEnvLogsFilePath(
            logsFileValue=envLogsFile,
            defaultLogsDir=localLogsDefaultDir,
        )
        _addLocalFileDestinationPath(runtime=runtime, resolvedPath=resolvedPath)

    endpointTarget = os.environ.get(otelEndpointEnvVar, "").strip()
    if endpointTarget:
        resolvedServiceName = (
            serviceName.strip()
            or os.environ.get(otelServiceNameEnvVar, "").strip()
            or defaultServiceName
        )
        serviceInstanceId = (
            os.environ.get(otelServiceInstanceIdEnvVar, "").strip()
            or defaultServiceInstanceId
        )
        _addOtelDestination(
            runtime=runtime,
            endpointTarget=endpointTarget,
            serviceName=resolvedServiceName,
            serviceInstanceId=serviceInstanceId,
            maxQueueSize=2048,
            maxExportBatchSize=512,
            scheduleDelayMs=500,
            exportTimeoutMs=30000,
        )
    return runtime


def addLoggingDestinationsFromArgs(
    *,
    runtime: LoggingDestinationsRuntime,
    args: argparse.Namespace,
    serviceInstanceId: str,
    serviceName: str = "",
    localLogsDirArgName: str = "",
    localLogsFileName: str = "",
    otelEndpointArgName: str = "otel_logs_endpoint",
    otelServiceNameArgName: str = "otel_logs_service_name",
    otelMaxQueueSizeArgName: str = "otel_logs_max_queue_size",
    otelMaxExportBatchSizeArgName: str = "otel_logs_max_export_batch_size",
    otelScheduleDelayMsArgName: str = "otel_logs_schedule_delay_ms",
    otelExportTimeoutMsArgName: str = "otel_logs_export_timeout_ms",
) -> None:
    if localLogsDirArgName:
        try:
            argsLogsDir = getattr(args, localLogsDirArgName, "").strip()
            if argsLogsDir:
                _addLocalFileDestination(
                    runtime=runtime,
                    logsDir=argsLogsDir,
                    fileName=(localLogsFileName.strip() or _buildDefaultLocalLogFileName(serviceInstanceId)),
                )
        except Exception:
            LOG.error(
                "Failed to add local file destination from args arg=%s service_instance_id=%s",
                localLogsDirArgName,
                serviceInstanceId,
                exc_info=True,
            )

    argsEndpoint = getattr(args, otelEndpointArgName, "").strip()
    if argsEndpoint:
        try:
            resolvedServiceName = serviceName.strip() or getattr(
                args,
                otelServiceNameArgName,
                "lumeflow-sidecar",
            )
            _addOtelDestination(
                runtime=runtime,
                endpointTarget=argsEndpoint,
                serviceName=resolvedServiceName,
                serviceInstanceId=serviceInstanceId,
                maxQueueSize=int(getattr(args, otelMaxQueueSizeArgName, 2048)),
                maxExportBatchSize=int(getattr(args, otelMaxExportBatchSizeArgName, 512)),
                scheduleDelayMs=int(getattr(args, otelScheduleDelayMsArgName, 500)),
                exportTimeoutMs=int(getattr(args, otelExportTimeoutMsArgName, 30000)),
            )
        except Exception:
            LOG.error(
                "Failed to add OTel destination from args endpoint=%s service_instance_id=%s",
                argsEndpoint,
                serviceInstanceId,
                exc_info=True,
            )


def areOtelEndpointsEquivalent(leftTarget: str, rightTarget: str) -> bool:
    leftTrimmed = leftTarget.strip()
    rightTrimmed = rightTarget.strip()
    if not leftTrimmed and not rightTrimmed:
        return True
    try:
        leftNormalized = _normalizeOtelGrpcEndpoint(leftTrimmed)
    except RuntimeError:
        leftNormalized = leftTrimmed
    try:
        rightNormalized = _normalizeOtelGrpcEndpoint(rightTrimmed)
    except RuntimeError:
        rightNormalized = rightTrimmed
    return leftNormalized == rightNormalized


def flushRootLogHandlers() -> None:
    rootLogger = logging.getLogger()
    for handler in list(rootLogger.handlers):
        flush = getattr(handler, "flush", None)
        if callable(flush):
            try:
                flush()
            except Exception:  # pragma: no cover
                LOG.exception(f"Failed to flush log handler {type(handler).__name__}")
