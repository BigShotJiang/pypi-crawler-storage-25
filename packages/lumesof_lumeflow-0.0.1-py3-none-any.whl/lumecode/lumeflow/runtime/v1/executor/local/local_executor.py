from __future__ import annotations

import asyncio
import json
import logging
import time
from collections.abc import AsyncIterator, Iterable, Mapping
from dataclasses import dataclass
from typing import Any

from grpclib import GRPCError
from grpclib.const import Status

from lumecode.daemon.cartond import cartond_pb2
from lumecode.daemon.cartond.cartond_client import (
    CartondAppStatusResult,
    CartondClient,
)
from lumecode.lumeflow.runtime.v1.executor.executor import Executor
from lumecode.lumeflow.runtime.v1.executor.executor_types_pb2 import JobResult

LOG = logging.getLogger(__name__)


@dataclass
class _LocalAppState:
    appId: str
    uploaded: bool = False
    startedAt: float | None = None


class LocalExecutor(Executor):
    def __init__(
        self,
        node_name: str,
        *,
        cartondTarget: str,
        cartondClient: CartondClient | None = None,
    ) -> None:
        super().__init__(node_name)
        normalizedTarget = cartondTarget.strip()
        if not normalizedTarget and cartondClient is None:
            raise ValueError("cartondTarget must be provided.")
        self._cartondTarget = normalizedTarget
        self._cartondClient = cartondClient or CartondClient(target=normalizedTarget)
        self._apps: dict[str, _LocalAppState] = {}
        self._stateLock = asyncio.Lock()

    async def async_createApp(
        self,
        appId: str,
        params: Mapping[str, Any] | None = None,
    ) -> None:
        normalizedAppId = self._normalizeAppId(appId)
        normalizedParams = self._normalizeParams(params)
        createOptions = self._parseCreateAppOptions(normalizedParams)
        defaultEnv = self._parseEnvParam(
            normalizedParams.get("--env", normalizedParams.get("env"))
        )
        dockerMediationPolicy = self._parseDockerMediationPolicyParam(
            normalizedParams.get("docker_mediation_policy")
        )
        async with self._stateLock:
            if normalizedAppId in self._apps:
                return
        try:
            result = await self._cartondClient.async_createApp(
                appId=normalizedAppId,
                skipTmpPivot=True,
                defaultEnv=defaultEnv,
                dockerMediationPolicy=dockerMediationPolicy,
                captureFallbackLogs=createOptions.captureFallbackLogs,
                fallbackOtlpTarget=createOptions.fallbackOtlpTarget,
                fallbackLogBufferBytes=createOptions.fallbackLogBufferBytes,
            )
        except GRPCError as exc:
            if exc.status == Status.ALREADY_EXISTS:
                async with self._stateLock:
                    self._apps.setdefault(normalizedAppId, _LocalAppState(appId=normalizedAppId))
                return
            raise
        if result.code != 0:
            raise RuntimeError(f"cartond CreateApp failed: {result.message}")
        async with self._stateLock:
            self._apps.setdefault(normalizedAppId, _LocalAppState(appId=normalizedAppId))

    async def async_uploadAppImage(
        self,
        appId: str,
        chunkStream: AsyncIterator[bytes],
        *,
        hashScheme: str = "",
        hashValue: str = "",
    ) -> None:
        _ = hashScheme
        _ = hashValue
        normalizedAppId = self._normalizeAppId(appId)
        await self._async_requireApp(normalizedAppId)
        uploadResult = await self._cartondClient.async_uploadAppImageStream(
            appId=normalizedAppId,
            chunkStream=chunkStream,
        )
        if uploadResult.code != 0:
            raise RuntimeError(f"cartond UploadAppImage failed: {uploadResult.message}")
        async with self._stateLock:
            state = self._apps.get(normalizedAppId)
            if state is None:
                raise KeyError(f"Unknown app_id: {normalizedAppId}")
            state.uploaded = True

    async def async_launchApp(
        self,
        appId: str,
        params: Mapping[str, Any] | None = None,
    ) -> JobResult:
        normalizedAppId = self._normalizeAppId(appId)
        normalizedParams = self._normalizeParams(params)
        await self._async_requireUploadedApp(normalizedAppId)
        argvRaw = normalizedParams.get("--argv", normalizedParams.get("argv"))
        envRaw = normalizedParams.get("--env", normalizedParams.get("env"))
        cwdRaw = normalizedParams.get("--cwd", normalizedParams.get("cwd"))
        timeoutRaw = normalizedParams.get("--timeout_ms", normalizedParams.get("timeout_ms"))
        runAsUidRaw = normalizedParams.get("--run_as_uid", normalizedParams.get("run_as_uid"))
        runAsGidRaw = normalizedParams.get("--run_as_gid", normalizedParams.get("run_as_gid"))
        runAsTokenRaw = normalizedParams.get("--run_as_token", normalizedParams.get("run_as_token"))

        startedAt = time.time()
        status = await self._cartondClient.async_launchApp(
            appId=normalizedAppId,
            argv=self._parseArgvParam(argvRaw),
            env=self._parseEnvParam(envRaw),
            workingDir=cwdRaw if isinstance(cwdRaw, str) else "",
            timeoutMs=self._parseTimeoutMsParam(timeoutRaw),
            runAsUid=self._parseOptionalIntParam(runAsUidRaw, fieldName="run_as_uid"),
            runAsGid=self._parseOptionalIntParam(runAsGidRaw, fieldName="run_as_gid"),
            runAsToken=runAsTokenRaw if isinstance(runAsTokenRaw, str) else "",
        )
        if status.code != 0:
            raise RuntimeError(f"cartond LaunchApp failed: {status.message}")
        async with self._stateLock:
            state = self._apps.get(normalizedAppId)
            if state is not None:
                state.startedAt = startedAt
        return self._buildJobResultFromAppStatus(
            appId=normalizedAppId,
            startedAt=startedAt,
            appStatus=status,
        )

    async def async_getAppStatus(self, appId: str) -> JobResult:
        normalizedAppId = self._normalizeAppId(appId)
        await self._async_requireApp(normalizedAppId)
        try:
            status = await self._cartondClient.async_getAppStatus(normalizedAppId)
        except GRPCError as exc:
            if exc.status == Status.NOT_FOUND:
                raise KeyError(f"Unknown app_id: {normalizedAppId}") from exc
            raise
        if status.code != 0:
            message = status.message or "cartond GetAppStatus failed"
            if "not found" in message.lower():
                raise KeyError(f"Unknown app_id: {normalizedAppId}")
            raise RuntimeError(f"cartond GetAppStatus failed: {message}")
        async with self._stateLock:
            state = self._apps.get(normalizedAppId)
            startedAt = state.startedAt if state is not None else None
        return self._buildJobResultFromAppStatus(
            appId=normalizedAppId,
            startedAt=startedAt,
            appStatus=status,
        )

    async def async_tearDownApp(self, appId: str) -> None:
        normalizedAppId = self._normalizeAppId(appId)
        async with self._stateLock:
            if normalizedAppId not in self._apps:
                return
        try:
            result = await self._cartondClient.async_tearDownApp(normalizedAppId)
        except GRPCError as exc:
            if exc.status != Status.NOT_FOUND:
                raise
        else:
            if result.code != 0 and "not found" not in result.message.lower():
                raise RuntimeError(f"cartond TearDownApp failed: {result.message}")
        async with self._stateLock:
            self._apps.pop(normalizedAppId, None)

    async def _async_requireApp(self, appId: str) -> _LocalAppState:
        async with self._stateLock:
            state = self._apps.get(appId)
            if state is None:
                raise KeyError(f"Unknown app_id: {appId}")
            return state

    async def _async_requireUploadedApp(self, appId: str) -> _LocalAppState:
        state = await self._async_requireApp(appId)
        if not state.uploaded:
            raise RuntimeError(f"No uploaded app image for app_id: {appId}")
        return state

    def _buildJobResultFromAppStatus(
        self,
        *,
        appId: str,
        startedAt: float | None,
        appStatus: CartondAppStatusResult,
    ) -> JobResult:
        status = self._mapCartondRunStatusToJobStatus(
            runStatus=appStatus.runStatus,
            code=appStatus.code,
            exitCode=appStatus.exitCode,
        )
        result = JobResult(job_id=appId, status=status)
        if startedAt is not None:
            result.started_at = startedAt
        if status in ("SUCCEEDED", "FAILED", "TERMINATED"):
            result.finished_at = time.time()
        result.output["message"] = appStatus.message
        result.output["carton_id"] = appStatus.cartonId
        result.output["launch_handle"] = appStatus.launchHandle
        result.output["run_status"] = str(appStatus.runStatus)
        result.output["exit_code"] = str(appStatus.exitCode)
        return result

    @staticmethod
    def _normalizeAppId(appId: str) -> str:
        if not isinstance(appId, str) or not appId.strip():
            raise ValueError("appId must be provided.")
        return appId.strip()

    @staticmethod
    def _normalizeParams(params: Mapping[str, Any] | None) -> dict[str, Any]:
        if params is None:
            return {}
        if not isinstance(params, Mapping):
            raise TypeError("params must be a mapping.")
        normalized: dict[str, Any] = {}
        for key, value in params.items():
            if not isinstance(key, str):
                raise TypeError("params keys must be strings.")
            normalized[key] = value
        return normalized

    @staticmethod
    def _parseArgvParam(rawValue: object) -> list[str]:
        if rawValue is None:
            return []
        if isinstance(rawValue, list):
            return [str(item) for item in rawValue]
        if isinstance(rawValue, tuple):
            return [str(item) for item in rawValue]
        if isinstance(rawValue, str):
            trimmed = rawValue.strip()
            if not trimmed:
                return []
            if trimmed.startswith("["):
                parsed = json.loads(trimmed)
                if not isinstance(parsed, list):
                    raise ValueError("argv JSON must decode to a list.")
                return [str(item) for item in parsed]
            return trimmed.split()
        if isinstance(rawValue, Iterable):
            return [str(item) for item in rawValue]
        raise ValueError("argv must be a string or iterable.")

    @staticmethod
    def _parseEnvParam(rawValue: object) -> dict[str, str]:
        if rawValue is None:
            return {}
        if isinstance(rawValue, Mapping):
            return {str(key): str(value) for key, value in rawValue.items()}
        if isinstance(rawValue, str):
            trimmed = rawValue.strip()
            if not trimmed:
                return {}
            if not trimmed.startswith("{"):
                raise ValueError("env must be a JSON object.")
            parsed = json.loads(trimmed)
            if not isinstance(parsed, dict):
                raise ValueError("env JSON must decode to an object.")
            return {str(key): str(value) for key, value in parsed.items()}
        raise ValueError("env must be a mapping or JSON object string.")

    @staticmethod
    def _parseTimeoutMsParam(rawValue: object) -> int:
        if rawValue is None:
            return 0
        if isinstance(rawValue, int):
            if rawValue < 0:
                raise ValueError("timeout_ms must be non-negative.")
            return rawValue
        if isinstance(rawValue, str):
            trimmed = rawValue.strip()
            if not trimmed:
                return 0
            timeoutMs = int(trimmed)
            if timeoutMs < 0:
                raise ValueError("timeout_ms must be non-negative.")
            return timeoutMs
        raise ValueError("timeout_ms must be an integer.")

    @staticmethod
    def _parseOptionalIntParam(rawValue: object, *, fieldName: str) -> int | None:
        if rawValue is None:
            return None
        if isinstance(rawValue, int):
            return rawValue
        if isinstance(rawValue, str):
            trimmed = rawValue.strip()
            if not trimmed:
                return None
            return int(trimmed)
        raise ValueError(f"{fieldName} must be an integer.")

    @staticmethod
    def _mapCartondRunStatusToJobStatus(
        *,
        runStatus: int,
        code: int,
        exitCode: int,
    ) -> str:
        if code != 0:
            return "FAILED"
        if runStatus in (
            cartond_pb2.APP_RUN_STATUS_PENDING,
            cartond_pb2.APP_RUN_STATUS_RUNNING,
        ):
            return "RUNNING"
        if runStatus == cartond_pb2.APP_RUN_STATUS_EXITED:
            return "SUCCEEDED" if exitCode == 0 else "FAILED"
        if runStatus == cartond_pb2.APP_RUN_STATUS_FAILED:
            return "FAILED"
        if runStatus in (
            cartond_pb2.APP_RUN_STATUS_TEARING_DOWN,
            cartond_pb2.APP_RUN_STATUS_DISPOSED,
        ):
            return "TERMINATED"
        return "UNKNOWN"

    @staticmethod
    def _parseCreateAppOptions(params: Mapping[str, Any]) -> "_CreateAppOptions":
        captureRaw = params.get(
            "--capture_fallback_logs",
            params.get("capture_fallback_logs"),
        )
        fallbackTargetRaw = params.get(
            "--fallback_otlp_target",
            params.get("fallback_otlp_target"),
        )
        fallbackBufferRaw = params.get(
            "--fallback_log_buffer_bytes",
            params.get("fallback_log_buffer_bytes"),
        )

        captureFallbackLogs = LocalExecutor._parseBoolParam(
            captureRaw,
            fieldName="capture_fallback_logs",
            default=False,
        )
        fallbackOtlpTarget = LocalExecutor._parseOptionalStringParam(
            fallbackTargetRaw,
            fieldName="fallback_otlp_target",
        )
        fallbackLogBufferBytes = LocalExecutor._parseNonNegativeIntParam(
            fallbackBufferRaw,
            fieldName="fallback_log_buffer_bytes",
            default=0,
        )
        if captureFallbackLogs and not fallbackOtlpTarget:
            raise ValueError(
                "fallback_otlp_target is required when capture_fallback_logs is enabled."
            )
        if not captureFallbackLogs and (fallbackOtlpTarget or fallbackLogBufferBytes > 0):
            raise ValueError(
                "fallback_otlp_target and fallback_log_buffer_bytes require "
                "capture_fallback_logs to be enabled."
            )

        LOG.info(
            f"LocalExecutor createApp options app_capture_fallback_logs={captureFallbackLogs} "
            f"fallback_otlp_target={fallbackOtlpTarget!r} "
            f"fallback_log_buffer_bytes={fallbackLogBufferBytes}"
        )
        return _CreateAppOptions(
            captureFallbackLogs=captureFallbackLogs,
            fallbackOtlpTarget=fallbackOtlpTarget,
            fallbackLogBufferBytes=fallbackLogBufferBytes,
        )

    @staticmethod
    def _parseDockerMediationPolicyParam(
        rawValue: object,
    ) -> cartond_pb2.DockerMediationPolicy | None:
        if rawValue is None:
            return None
        if isinstance(rawValue, cartond_pb2.DockerMediationPolicy):
            policy = cartond_pb2.DockerMediationPolicy()
            policy.CopyFrom(rawValue)
            return policy
        if isinstance(rawValue, Mapping):
            policy = cartond_pb2.DockerMediationPolicy()
            logPolicy = rawValue.get("log_policy")
            if isinstance(logPolicy, Mapping):
                driver = logPolicy.get("driver")
                if driver is not None:
                    policy.log_policy.driver = int(driver)
                fluentdAddress = logPolicy.get("fluentd_address")
                if fluentdAddress is not None:
                    policy.log_policy.fluentd_address = str(fluentdAddress)
                logOptions = logPolicy.get("log_options")
                if isinstance(logOptions, Mapping):
                    policy.log_policy.log_options.update(
                        {str(key): str(value) for key, value in logOptions.items()}
                    )
            containerLabels = rawValue.get("container_labels")
            if isinstance(containerLabels, Mapping):
                policy.container_labels.update(
                    {str(key): str(value) for key, value in containerLabels.items()}
                )
            return policy
        raise ValueError("docker_mediation_policy must be a DockerMediationPolicy or mapping.")

    @staticmethod
    def _parseBoolParam(rawValue: object, *, fieldName: str, default: bool) -> bool:
        if rawValue is None:
            return default
        if isinstance(rawValue, bool):
            return rawValue
        if isinstance(rawValue, str):
            lowered = rawValue.strip().lower()
            if lowered in ("true", "1", "yes", "y", "on"):
                return True
            if lowered in ("false", "0", "no", "n", "off", ""):
                return False
        raise ValueError(f"{fieldName} must be a boolean.")

    @staticmethod
    def _parseOptionalStringParam(rawValue: object, *, fieldName: str) -> str:
        if rawValue is None:
            return ""
        if isinstance(rawValue, str):
            return rawValue.strip()
        raise ValueError(f"{fieldName} must be a string.")

    @staticmethod
    def _parseNonNegativeIntParam(
        rawValue: object,
        *,
        fieldName: str,
        default: int,
    ) -> int:
        if rawValue is None:
            return default
        if isinstance(rawValue, int):
            value = rawValue
        elif isinstance(rawValue, str):
            trimmed = rawValue.strip()
            if not trimmed:
                return default
            value = int(trimmed)
        else:
            raise ValueError(f"{fieldName} must be an integer.")
        if value < 0:
            raise ValueError(f"{fieldName} must be non-negative.")
        return value


@dataclass(frozen=True)
class _CreateAppOptions:
    captureFallbackLogs: bool
    fallbackOtlpTarget: str
    fallbackLogBufferBytes: int
