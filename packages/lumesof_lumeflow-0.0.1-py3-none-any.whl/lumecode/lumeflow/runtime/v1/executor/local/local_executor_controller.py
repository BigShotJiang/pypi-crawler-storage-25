from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from typing import Any

from lumecode.base.python.net.target_parser import NetTarget
from lumecode.daemon.cartond.cartond_client import CartondClient, CartondInfoResult
from lumecode.lumeflow.runtime.v1.executor import executor_control_service_pb2
from lumecode.lumeflow.runtime.v1.executor.controller import ExecutorController
from lumecode.lumeflow.runtime.v1.executor.executor import Executor
from lumecode.lumeflow.runtime.v1.executor.local.local_executor import LocalExecutor

LOG = logging.getLogger(__name__)


@dataclass
class _LocalExecutorMetadata:
    executorName: str
    jobId: str


class LocalExecutorController(ExecutorController):
    def __init__(
        self,
        *,
        cartondTarget: str,
        cartondClient: CartondClient | None = None,
    ) -> None:
        normalizedTarget = cartondTarget.strip()
        if not normalizedTarget:
            raise ValueError("cartondTarget must be provided.")
        if "," in normalizedTarget:
            raise ValueError("LocalExecutorController accepts exactly one cartond target.")
        path = NetTarget.parseTarget(normalizedTarget).getPath()
        self._cartondTarget = normalizedTarget
        self._cartondExpectedUdsPath = path
        self._cartondClient = cartondClient or CartondClient(target=normalizedTarget)
        self._executorMetadataByName: dict[str, _LocalExecutorMetadata] = {}
        self._stateLock = asyncio.Lock()

    def getExecutorType(self) -> int:
        return executor_control_service_pb2.LOCAL_EXECUTOR

    async def async_createExecutor(
        self,
        name: str,
        executor_config: dict[str, Any] | None = None,
    ) -> Executor:
        LOG.info(
            f"LocalExecutorController create begin raw_name={name!r} "
            f"config_present={executor_config is not None}"
        )
        normalizedName = self._normalizeExecutorName(name)
        normalizedConfig = self._normalizeLocalConfig(executor_config)
        jobId = str(normalizedConfig.get("job_id", "")).strip()
        if not jobId:
            raise ValueError("job_id must be provided in executor_config.")

        info = await self._cartondClient.async_getInfo()
        self._validateCartondInfo(info)

        async with self._stateLock:
            self._executorMetadataByName[normalizedName] = _LocalExecutorMetadata(
                executorName=normalizedName,
                jobId=jobId,
            )
        LOG.info(
            f"LocalExecutorController create done name={normalizedName} "
            f"job_id={jobId} cartond_target={self._cartondTarget}"
        )
        return LocalExecutor(
            normalizedName,
            cartondTarget=self._cartondTarget,
        )

    def _normalizeLocalConfig(
        self,
        executor_config: dict[str, Any] | None,
    ) -> dict[str, Any]:
        normalized = self._normalizeExecutorConfig(executor_config)
        executor_type = normalized.get("type")
        if executor_type not in (None, "local"):
            LOG.warning(f"LocalExecutorController unsupported executor type={executor_type!r}")
            raise ValueError(f"Unsupported executor type '{executor_type}'.")
        normalized["type"] = "local"
        return normalized

    def _validateCartondInfo(self, info: CartondInfoResult) -> None:
        if info.code != 0:
            raise RuntimeError(f"cartond GetInfo returned non-zero code: {info.code}")
        if not info.daemonVersion.strip():
            raise RuntimeError("cartond GetInfo returned empty daemonVersion.")
        if not info.listenTarget.strip():
            raise RuntimeError("cartond GetInfo returned empty listenTarget.")
        if not info.runtimeRoot.strip():
            raise RuntimeError("cartond GetInfo returned empty runtimeRoot.")
        if not info.cartonInitBinary.strip():
            raise RuntimeError("cartond GetInfo returned empty cartonInitBinary.")
        if info.daemonPid <= 0:
            raise RuntimeError("cartond GetInfo returned non-positive daemonPid.")
        if self._cartondExpectedUdsPath is not None:
            if not info.listensOnUds:
                raise RuntimeError("cartond GetInfo indicates non-UDS listener for local controller.")
            if not info.udsPath.strip():
                raise RuntimeError("cartond GetInfo returned empty udsPath.")
            if info.udsPath != self._cartondExpectedUdsPath:
                raise RuntimeError(
                    f"cartond udsPath mismatch; expected={self._cartondExpectedUdsPath} "
                    f"actual={info.udsPath}"
                )
