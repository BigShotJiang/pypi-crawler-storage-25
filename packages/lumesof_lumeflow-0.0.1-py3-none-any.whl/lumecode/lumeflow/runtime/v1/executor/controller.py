"""Controller interface definitions."""

from __future__ import annotations

import abc
import logging
from typing import Any

from lumecode.lumeflow.runtime.v1.executor.executor import Executor

LOG = logging.getLogger(__name__)


class ExecutorController(abc.ABC):
    """Abstract base class for concrete executor controllers."""

    @abc.abstractmethod
    def getExecutorType(self) -> int:
        raise NotImplementedError

    @abc.abstractmethod
    async def async_createExecutor(
        self,
        name: str,
        executor_config: dict[str, Any] | None = None,
    ) -> Executor:
        raise NotImplementedError

    def _normalizeExecutorName(self, name: str) -> str:
        if not isinstance(name, str):
            LOG.warning(f"ExecutorController invalid executor name type={type(name).__name__}")
            raise TypeError("Executor name must be a string.")
        normalized = name.strip()
        if not normalized:
            LOG.warning("ExecutorController empty executor name")
            raise ValueError("Executor name must not be empty.")
        return normalized

    def _normalizeExecutorConfig(
        self,
        executor_config: dict[str, Any] | None,
    ) -> dict[str, Any]:
        if executor_config is None:
            return {}
        if not isinstance(executor_config, dict):
            LOG.warning(
                f"ExecutorController invalid executor config type={type(executor_config).__name__}"
            )
            raise TypeError("executor_config must be a dictionary with string keys.")
        normalized: dict[str, Any] = {}
        for key, value in executor_config.items():
            if not isinstance(key, str):
                LOG.warning(
                    f"ExecutorController invalid executor config key type={type(key).__name__}"
                )
                raise TypeError("executor_config keys must be strings.")
            normalized[key] = value
        return normalized
