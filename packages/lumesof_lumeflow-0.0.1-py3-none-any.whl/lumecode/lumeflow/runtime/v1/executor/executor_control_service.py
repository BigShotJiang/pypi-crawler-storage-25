from __future__ import annotations

import json
import logging
import os
import secrets
import uuid
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, AsyncIterator, Dict, Optional

from grpclib import GRPCError
from grpclib.client import Channel
from grpclib.const import Status
from grpclib.server import Stream
from sqlalchemy import delete, insert, select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from lumecode.base.python.logging import lumesof_logging
from lumecode.base.python.net.retry_until_ready import RetryDeadlineExceededError, RetryUntilReady
from lumecode.base.python.net.target_parser import NetTarget
from lumecode.base.python.sqldb import crdb_async_utils as sqldb_utils
from lumecode.crdb.schemas.dev_cluster.flow.db_orm_models import TabExecutors
from lumecode.lumeflow.runtime.v1.executor.executor import Executor
from lumecode.lumeflow.runtime.v1.executor.controller import ExecutorController
from lumecode.lumeflow.runtime.v1.executor import (
    executor_control_service_grpc,
    executor_control_service_pb2,
)
from lumecode.daemon.cartond import cartond_pb2
from lumecode.storage.cas import cas_grpc, cas_pb2

try:
    from lumecode.lumeflow.runtime.v1.executor import local_executor_proxy_pb2
    from lumecode.lumeflow.runtime.v1.executor.local_proxy.local_executor_proxy_client import (
        GetAppStatusResult,
        LaunchAppResult,
        LocalExecutorProxyClient,
        TerminateAppResult,
    )
except ImportError:
    local_executor_proxy_pb2 = None
    GetAppStatusResult = Any
    LaunchAppResult = Any
    LocalExecutorProxyClient = None
    TerminateAppResult = Any

_BACKEND_LOCAL_EXECUTOR = "local_executor"
_BACKEND_LOCAL_PROXY = "local_proxy"
_BACKEND_VM_EXECUTOR = "vm_executor"
_VM_STATUS_RUNNING = "RUNNING"
_OTEL_EXPORTER_OTLP_ENDPOINT_ENV = "OTEL_EXPORTER_OTLP_ENDPOINT"
_SIDECAR_LOG_LEVEL_ENV = "LUME_SIDECAR_LOG_LEVEL"
_LOCAL_PROXY_RUNTIME_STATUS_RUNNING = (
    getattr(local_executor_proxy_pb2, "RUNTIME_STATUS_RUNNING", 1)
    if local_executor_proxy_pb2 is not None
    else 1
)
_LOCAL_PROXY_RUNTIME_STATUS_EXITED = (
    getattr(local_executor_proxy_pb2, "RUNTIME_STATUS_EXITED", 2)
    if local_executor_proxy_pb2 is not None
    else 2
)
_LOCAL_PROXY_RUNTIME_STATUS_FAILED = (
    getattr(local_executor_proxy_pb2, "RUNTIME_STATUS_FAILED", 3)
    if local_executor_proxy_pb2 is not None
    else 3
)
_LOCAL_PROXY_RUNTIME_STATUS_TERMINATED = (
    getattr(local_executor_proxy_pb2, "RUNTIME_STATUS_TERMINATED", 4)
    if local_executor_proxy_pb2 is not None
    else 4
)
logger = logging.getLogger(__name__)
structuredLogger = lumesof_logging.getLogger(__name__)

_DOCKER_LABEL_APP_ID = "lumesof.app_id"
_DOCKER_LABEL_OPERATOR_NAME = "lumesof.operator_name"
_DOCKER_LABEL_INSTANCE_ID = "lumesof.instance_id"


class ExecutorControlService(executor_control_service_grpc.ExecutorControlServiceBase):
    """grpclib service handler for executor lifecycle control-plane calls."""

    def __init__(
        self,
        controller: ExecutorController,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        casTarget: str,
        controllerConfig: dict[str, Any] | None = None,
        localProxySocketPath: str | None = None,
        sidecarOtlpTarget: str = "",
        operatorDockerLogDriver: str = "",
        operatorDockerFluentdAddress: str = "",
    ) -> None:
        self._controller = controller
        self._session_maker = session_maker
        self._controllerConfig = self._normalizeControllerConfig(controllerConfig)
        normalizedCasTarget = casTarget.strip()
        if not normalizedCasTarget:
            logger.warning("ExecutorControlService init rejected empty casTarget")
            raise ValueError("casTarget must be provided.")
        try:
            _parsedCas = NetTarget.parseTarget(normalizedCasTarget)
        except RuntimeError as exc:
            logger.error(f"ExecutorControlService init invalid casTarget={normalizedCasTarget}")
            raise ValueError(f"Invalid casTarget: {exc}") from exc
        self._casHost = _parsedCas.getHost()
        self._casPort = _parsedCas.getPort()
        self._casUdsPath = _parsedCas.getPath()
        self._sidecarOtlpTarget = sidecarOtlpTarget.strip()
        self._operatorDockerLogDriver = operatorDockerLogDriver.strip().lower()
        self._operatorDockerFluentdAddress = operatorDockerFluentdAddress.strip()
        if (
            self._operatorDockerLogDriver == "fluentd"
            and not self._operatorDockerFluentdAddress
        ):
            raise ValueError(
                "operatorDockerFluentdAddress must be set when operatorDockerLogDriver=fluentd"
            )
        self._executorMetadata: Dict[str, _ExecutorMetadata] = {}
        self._executorNames: Dict[str, str] = {}
        self._jobExecutors: Dict[str, str] = {}
        self._jobLaunchBackend: Dict[str, str] = {}
        proxy_socket_path = (
            localProxySocketPath
            if localProxySocketPath is not None
            else os.environ.get("LOCAL_EXECUTOR_PROXY_SOCKET_PATH", "")
        )
        if proxy_socket_path and LocalExecutorProxyClient is not None:
            self._localExecutorProxyClient: LocalExecutorProxyClient | None = (
                LocalExecutorProxyClient(socketPath=proxy_socket_path)
            )
        else:
            if proxy_socket_path:
                logger.warning(
                    "ExecutorControlService local executor proxy requested without client module"
                )
            self._localExecutorProxyClient = None
        self._retryUntilReady = RetryUntilReady()
        logger.info(
            f"ExecutorControlService initialized cas_target={normalizedCasTarget} "
            f"executor_type={self.getExecutorType()} "
            f"controller_config_keys={sorted(self._controllerConfig.keys())} "
            f"cas_uds={bool(self._casUdsPath)} "
            f"local_proxy_configured={self._localExecutorProxyClient is not None}"
        )

    def getExecutorType(self) -> int:
        return self._controller.getExecutorType()

    @staticmethod
    def _buildExecutorLogAttrs(
        *,
        executorId: str = "",
        executorName: str = "",
        jobId: str = "",
        executorType: int | None = None,
        backend: str = "",
    ) -> dict[str, Any]:
        attrs: dict[str, Any] = {}
        if executorId:
            attrs[lumesof_logging.LUMESOF_EXECUTOR_ID] = executorId
        if executorName:
            attrs[lumesof_logging.LUMESOF_EXECUTOR_NAME] = executorName
        if jobId:
            attrs[lumesof_logging.LUMESOF_JOB_ID] = jobId
        if executorType is not None:
            attrs[lumesof_logging.LUMESOF_EXECUTOR_TYPE] = executorType
        if backend:
            attrs[lumesof_logging.LUMESOF_BACKEND] = backend
        return attrs

    async def Create(
        self,
        stream: Stream[
            executor_control_service_pb2.CreateRequest,
            executor_control_service_pb2.CreateResponse,
        ],
    ) -> None:
        """Create an executor handle and metadata without starting any processes."""
        await self.async_create(stream)

    async def async_create(
        self,
        stream: Stream[
            executor_control_service_pb2.CreateRequest,
            executor_control_service_pb2.CreateResponse,
        ],
    ) -> None:
        """Create an executor handle and metadata without starting processes."""
        request = await stream.recv_message()
        if request is None:
            logger.warning("ExecutorControlService Create missing request payload")
            raise GRPCError(Status.INVALID_ARGUMENT, "Create request payload missing.")

        executor_name = request.executor_name or self._buildExecutorName()
        requestJobId = (request.job_id or "").strip()
        createContextAttrs = {
            lumesof_logging.RPC_METHOD: "Create",
            **self._buildExecutorLogAttrs(
                executorName=executor_name,
                jobId=requestJobId,
                executorType=self.getExecutorType(),
            ),
        }
        with lumesof_logging.loggingContext(**createContextAttrs):
            structuredLogger.info(
                "ExecutorControlService Create request received",
                event="lumeflow.executor.create.received",
                attrs={
                    lumesof_logging.EVENT_OUTCOME: "start",
                },
            )
        existing = self._getCachedExecutorMetadata(
            executor_name=executor_name,
            job_id=requestJobId or None,
        )
        if existing is None and request.executor_name:
            if requestJobId:
                existing = await self._async_tryLoadExecutorMetadataByNameForFlowJob(
                    executor_name=executor_name,
                    flow_job_id=requestJobId,
                )
            else:
                existing = await self._async_tryLoadExecutorMetadataByName(executor_name)
        if existing is not None:
            if not await self._async_isExecutorReusable(existing):
                logger.warning(
                    f"ExecutorControlService Create dropping unreusable executor "
                    f"executor_name={executor_name} executor_id={existing.executor_id}"
                )
                await self._async_deleteExecutorMetadataAndCaches(existing)
                existing = None
            elif (
                existing.executor_type == executor_control_service_pb2.VM_EXECUTOR
                and not self._shouldReuseActiveVmExecutorOnCreate()
            ):
                logger.warning(
                    f"ExecutorControlService Create rejected active VM executor reuse "
                    f"executor_name={executor_name} executor_id={existing.executor_id}"
                )
                raise GRPCError(
                    Status.ALREADY_EXISTS,
                    "active VM executor reuse on Create is disabled; "
                    "destroy the existing executor or enable "
                    "--reuse-active-vm-executor",
                )
        if existing is None:
            if not request.job_id:
                logger.warning(
                    f"ExecutorControlService Create missing job_id executor_name={executor_name}"
                )
                raise GRPCError(Status.INVALID_ARGUMENT, "job_id must be provided.")
            executor_type = self.getExecutorType()
            logger.info(
                f"ExecutorControlService Create allocating executor executor_name={executor_name} "
                f"job_id={request.job_id} executor_type={executor_type}"
            )
            executor = await self._controller.async_createExecutor(
                executor_name,
                executor_config=self._buildExecutorConfig(
                    controllerConfig=self._buildControllerConfig(),
                    jobId=request.job_id,
                ),
            )
            flow_job_id = self._resolveFlowJobId(request.job_id)
            snapshot = self._buildExecutorSnapshot(
                executor_id="",
                executor_name=executor_name,
                executor_type=executor_type,
                executor=executor,
                job_id=request.job_id,
            )
            executor_id = await self.async_persistExecutorMetadata(
                executor_name=executor_name,
                executor_type=executor_type,
                serialized_executor=snapshot.SerializeToString(),
                flow_job_id=flow_job_id,
            )
            snapshot.executor_id = str(executor_id)
            await self.async_updateExecutorMetadataSnapshot(
                executor_id=executor_id,
                snapshot=snapshot,
            )
            existing = _ExecutorMetadata(
                executor_id=str(executor_id),
                executor_name=executor_name,
                executor_type=executor_type,
                executor=executor,
                job_id=request.job_id,
                vm_id=self._getExecutorVmId(executor) or None,
            )
            createParams = self._buildLaunchParams(
                dict(request.params),
                {},
                request.job_id,
            )
            dockerMediationPolicy = self._buildOperatorDockerMediationPolicy(
                runtimeIdentity=request.runtime_identity,
            )
            await self._async_createAppForExecutor(
                executor=executor,
                appId=existing.executor_id,
                params=createParams,
                dockerMediationPolicy=dockerMediationPolicy,
            )
            self._cacheExecutorMetadata(existing)
            structuredLogger.info(
                f"ExecutorControlService Create persisted executor "
                f"executor_type={existing.executor_type}",
                event="lumeflow.executor.create.completed",
                attrs={
                    lumesof_logging.EVENT_OUTCOME: "success",
                    lumesof_logging.RPC_METHOD: "Create",
                    **self._buildExecutorLogAttrs(
                        executorId=existing.executor_id,
                        executorName=executor_name,
                        jobId=request.job_id,
                        executorType=existing.executor_type,
                    ),
                },
            )
        else:
            structuredLogger.info(
                f"ExecutorControlService Create reused executor "
                f"executor_type={existing.executor_type}",
                event="lumeflow.executor.create.completed",
                attrs={
                    lumesof_logging.EVENT_OUTCOME: "success",
                    lumesof_logging.RPC_METHOD: "Create",
                    **self._buildExecutorLogAttrs(
                        executorId=existing.executor_id,
                        executorName=executor_name,
                        jobId=existing.job_id or "",
                        executorType=existing.executor_type,
                    ),
                },
            )

        await stream.send_message(
            executor_control_service_pb2.CreateResponse(
                executor_name=existing.executor_name,
                executor_id=existing.executor_id,
                job_id=existing.job_id or "",
            )
        )

    async def Launch(
        self,
        stream: Stream[
            executor_control_service_pb2.LaunchRequest,
            executor_control_service_pb2.LaunchResponse,
        ],
    ) -> None:
        """Launch the executor workload through the configured backend."""
        await self.async_launch(stream)

    async def async_launch(
        self,
        stream: Stream[
            executor_control_service_pb2.LaunchRequest,
            executor_control_service_pb2.LaunchResponse,
        ],
    ) -> None:
        """Launch the executor workload via the local executor proxy."""
        request = await stream.recv_message()
        if request is None:
            logger.warning("ExecutorControlService Launch missing request payload")
            raise GRPCError(Status.INVALID_ARGUMENT, "Launch request payload missing.")

        if not request.executor_id:
            logger.warning("ExecutorControlService Launch missing executor_id")
            raise GRPCError(Status.INVALID_ARGUMENT, "executor_id must be provided.")

        metadata = self._executorMetadata.get(request.executor_id)
        if metadata is None:
            metadata = await self._async_tryLoadExecutorMetadataByExecutorId(request.executor_id)
        if metadata is None:
            logger.warning(
                f"ExecutorControlService Launch executor not found executor_id={request.executor_id}"
            )
            raise GRPCError(Status.NOT_FOUND, "executor_id is not registered.")

        params = self._buildLaunchParams(
            {},
            dict(request.params),
            metadata.job_id or "",
        )
        hash_scheme = request.hash_scheme or ""
        hash_value = request.hash_value or ""
        if not hash_scheme:
            logger.warning(
                f"ExecutorControlService Launch missing hash_scheme executor_id={request.executor_id}"
            )
            raise GRPCError(Status.INVALID_ARGUMENT, "hash_scheme must be provided.")
        if not hash_value:
            logger.warning(
                f"ExecutorControlService Launch missing hash_value executor_id={request.executor_id}"
            )
            raise GRPCError(Status.INVALID_ARGUMENT, "hash_value must be provided.")
        launchContextAttrs = {
            lumesof_logging.RPC_METHOD: "Launch",
            **self._buildExecutorLogAttrs(
                executorId=request.executor_id,
                executorName=metadata.executor_name,
                jobId=metadata.job_id or "",
                executorType=metadata.executor_type,
            ),
        }
        with lumesof_logging.loggingContext(**launchContextAttrs):
            structuredLogger.info(
                "ExecutorControlService Launch request received",
                event="lumeflow.executor.launch.received",
                attrs={
                    lumesof_logging.EVENT_OUTCOME: "start",
                },
            )
            structuredLogger.info(
                f"ExecutorControlService Launch begin hash_scheme={hash_scheme}",
                event="lumeflow.executor.launch.begin",
                attrs={
                    lumesof_logging.EVENT_OUTCOME: "start",
                },
            )
            backend = self._getLaunchBackend(metadata.executor_type)
            if self._isLocalExecutorBackend(backend):
                response = await self._async_launchViaExecutor(
                    metadata,
                    hashScheme=hash_scheme,
                    hashValue=hash_value,
                    params=params,
                )
            elif backend == _BACKEND_VM_EXECUTOR:
                response = await self._async_launchViaVmExecutor(
                    metadata,
                    hashScheme=hash_scheme,
                    hashValue=hash_value,
                    params=params,
                )
            else:
                logger.error(
                    f"ExecutorControlService Launch unsupported backend executor_id={request.executor_id} "
                    f"backend={backend}"
                )
                raise GRPCError(Status.FAILED_PRECONDITION, "Unsupported executor backend.")
            metadata.job_id = response.job_id
            self._jobExecutors[response.job_id] = metadata.executor_id
            self._jobLaunchBackend[response.job_id] = backend
            await self.async_updateExecutorMetadataSnapshot(
                executor_id=uuid.UUID(metadata.executor_id),
                snapshot=self._buildExecutorSnapshot(
                    executor_id=metadata.executor_id,
                    executor_name=metadata.executor_name,
                    executor_type=metadata.executor_type,
                    executor=metadata.executor,
                    job_id=metadata.job_id or "",
                    launch_backend=backend,
                ),
            )
            structuredLogger.info(
                f"ExecutorControlService Launch done backend={backend} status={response.status}",
                event="lumeflow.executor.launch.completed",
                attrs={
                    lumesof_logging.EVENT_OUTCOME: "success",
                    lumesof_logging.RPC_METHOD: "Launch",
                    **self._buildExecutorLogAttrs(
                        executorId=metadata.executor_id,
                        executorName=metadata.executor_name,
                        jobId=response.job_id,
                        executorType=metadata.executor_type,
                        backend=backend,
                    ),
                },
            )
            await stream.send_message(response)

    async def GetStatus(
        self,
        stream: Stream[
            executor_control_service_pb2.GetStatusRequest,
            executor_control_service_pb2.GetStatusResponse,
        ],
    ) -> None:
        """Return read-only executor/job status for polling."""
        await self.async_getStatus(stream)

    async def async_getStatus(
        self,
        stream: Stream[
            executor_control_service_pb2.GetStatusRequest,
            executor_control_service_pb2.GetStatusResponse,
        ],
    ) -> None:
        """Return read-only executor/job status for polling."""
        request = await stream.recv_message()
        if request is None:
            logger.warning("ExecutorControlService GetStatus missing request payload")
            raise GRPCError(Status.INVALID_ARGUMENT, "GetStatus request payload missing.")

        if not request.executor_id:
            logger.warning("ExecutorControlService GetStatus missing executor_id")
            raise GRPCError(Status.INVALID_ARGUMENT, "executor_id must be provided.")

        metadata = self._executorMetadata.get(request.executor_id)
        if metadata is None:
            metadata = await self._async_tryLoadExecutorMetadataByExecutorId(request.executor_id)
        if metadata is None:
            logger.warning(
                f"ExecutorControlService GetStatus executor not found executor_id={request.executor_id}"
            )
            raise GRPCError(Status.NOT_FOUND, "executor_id is not registered.")

        job_id = metadata.job_id
        if not job_id:
            logger.warning(
                f"ExecutorControlService GetStatus missing job_id executor_id={request.executor_id}"
            )
            raise GRPCError(Status.NOT_FOUND, "job_id is not registered.")
        backend = self._jobLaunchBackend.get(job_id, "")
        getStatusContextAttrs = {
            lumesof_logging.RPC_METHOD: "GetStatus",
            **self._buildExecutorLogAttrs(
                executorId=request.executor_id,
                executorName=metadata.executor_name,
                jobId=job_id,
                executorType=metadata.executor_type,
                backend=backend,
            ),
        }
        with lumesof_logging.loggingContext(**getStatusContextAttrs):
            structuredLogger.info(
                "ExecutorControlService GetStatus request received",
                event="lumeflow.executor.get_status.received",
                attrs={
                    lumesof_logging.EVENT_OUTCOME: "start",
                },
            )
        if not backend:
            logger.warning(
                f"ExecutorControlService GetStatus unknown backend executor_id={request.executor_id} "
                f"job_id={job_id}"
            )
            raise GRPCError(Status.NOT_FOUND, "job launch backend is not registered.")
        if self._isLocalExecutorBackend(backend):
            executor_status = await self._async_getAppStatusViaExecutor(metadata)
            response = executor_control_service_pb2.GetStatusResponse(
                executor_type=metadata.executor_type,
                job_id=job_id,
                process_group_id=self._parseResultInt(executor_status.output.get("pgid")),
                status=self._mapExecutorRuntimeStatus(executor_status),
                message=self._getResultMessage(executor_status),
            )
        elif backend == _BACKEND_VM_EXECUTOR:
            vm_status = await self._async_getAppStatusViaVmExecutor(metadata, job_id)
            response = executor_control_service_pb2.GetStatusResponse(
                executor_type=metadata.executor_type,
                job_id=job_id,
                process_group_id=self._parseResultInt(vm_status.output.get("pgid")),
                status=self._mapExecutorRuntimeStatus(vm_status),
                message=self._getResultMessage(vm_status),
            )
        else:
            logger.warning(
                f"ExecutorControlService GetStatus unsupported backend executor_id={request.executor_id} "
                f"job_id={job_id} backend={backend}"
            )
            raise GRPCError(Status.NOT_FOUND, "job launch backend is not registered.")

        structuredLogger.info(
            f"ExecutorControlService GetStatus done backend={backend} status={response.status}",
            event="lumeflow.executor.get_status.completed",
            attrs={
                lumesof_logging.EVENT_OUTCOME: "success",
                lumesof_logging.RPC_METHOD: "GetStatus",
                **self._buildExecutorLogAttrs(
                    executorId=request.executor_id,
                    executorName=metadata.executor_name,
                    jobId=job_id,
                    executorType=metadata.executor_type,
                    backend=backend,
                ),
            },
        )
        await stream.send_message(response)

    async def Destroy(
        self,
        stream: Stream[
            executor_control_service_pb2.DestroyRequest,
            executor_control_service_pb2.DestroyResponse,
        ],
    ) -> None:
        """Terminate the executor and clean up all runtime state."""
        await self.async_destroy(stream)

    async def async_destroy(
        self,
        stream: Stream[
            executor_control_service_pb2.DestroyRequest,
            executor_control_service_pb2.DestroyResponse,
        ],
    ) -> None:
        """Terminate the executor and clean up all runtime state."""
        request = await stream.recv_message()
        if request is None:
            logger.warning("ExecutorControlService Destroy missing request payload")
            raise GRPCError(Status.INVALID_ARGUMENT, "Destroy request payload missing.")

        if not request.executor_id:
            logger.warning("ExecutorControlService Destroy missing executor_id")
            raise GRPCError(Status.INVALID_ARGUMENT, "executor_id must be provided.")

        metadata = self._executorMetadata.get(request.executor_id)
        if metadata is None:
            metadata = await self._async_tryLoadExecutorMetadataByExecutorId(request.executor_id)
        if metadata is None:
            logger.warning(
                f"ExecutorControlService Destroy executor not found executor_id={request.executor_id}"
            )
            raise GRPCError(Status.NOT_FOUND, "executor_id is not registered.")

        job_id = metadata.job_id
        backend = self._jobLaunchBackend.get(job_id, "") if job_id else ""
        destroyContextAttrs = {
            lumesof_logging.RPC_METHOD: "Destroy",
            **self._buildExecutorLogAttrs(
                executorId=request.executor_id,
                executorName=metadata.executor_name,
                jobId=job_id or "",
                executorType=metadata.executor_type,
                backend=backend,
            ),
        }
        with lumesof_logging.loggingContext(**destroyContextAttrs):
            structuredLogger.info(
                "ExecutorControlService Destroy request received",
                event="lumeflow.executor.destroy.received",
                attrs={
                    lumesof_logging.EVENT_OUTCOME: "start",
                },
            )
        if job_id and job_id in self._jobExecutors:
            if self._isLocalExecutorBackend(backend):
                try:
                    await self._async_terminateAppViaExecutor(metadata)
                except GRPCError as exc:
                    if exc.status != Status.NOT_FOUND:
                        logger.error(
                            f"ExecutorControlService Destroy local terminate failed "
                            f"executor_id={request.executor_id} job_id={job_id} status={exc.status}"
                        )
                        raise
            elif backend == _BACKEND_VM_EXECUTOR:
                vmTerminateError: GRPCError | None = None
                try:
                    await self._async_terminateAppViaVmExecutor(metadata, job_id)
                except GRPCError as exc:
                    if exc.status != Status.NOT_FOUND:
                        logger.error(
                            f"ExecutorControlService Destroy VM terminate failed "
                            f"executor_id={request.executor_id} job_id={job_id} status={exc.status}"
                        )
                        vmTerminateError = exc
                if metadata.vm_id is not None and metadata.vm_id > 0:
                    await self._async_destroyTrackedVm(
                        metadata,
                        reason=f"Destroy requested for job_id={job_id}",
                        allowMissingVmRow=True,
                    )
                elif vmTerminateError is not None:
                    raise vmTerminateError

        try:
            executor_uuid = uuid.UUID(metadata.executor_id)
        except ValueError as exc:
            logger.error(
                f"ExecutorControlService Destroy invalid stored executor id "
                f"executor_id={metadata.executor_id}"
            )
            raise GRPCError(Status.INTERNAL, "Stored executor_id is not a valid UUID.") from exc

        await self.async_deleteExecutorMetadata(executor_id=executor_uuid)
        self._removeExecutorMetadataFromCaches(metadata)
        structuredLogger.info(
            "ExecutorControlService Destroy done",
            event="lumeflow.executor.destroy.completed",
            attrs={
                lumesof_logging.EVENT_OUTCOME: "success",
                lumesof_logging.RPC_METHOD: "Destroy",
                **self._buildExecutorLogAttrs(
                    executorId=request.executor_id,
                    executorName=metadata.executor_name,
                    jobId=job_id or "",
                    executorType=metadata.executor_type,
                    backend=backend,
                ),
            },
        )
        await stream.send_message(
            executor_control_service_pb2.DestroyResponse(
                status=executor_control_service_pb2.DESTROY_STATUS_SUCCESS,
            )
        )

    @staticmethod
    def _buildExecutorName() -> str:
        token = secrets.token_urlsafe(6).rstrip("=")
        return f"executor-{token[:8]}"

    async def _async_tryLoadExecutorMetadataByName(
        self,
        executor_name: str,
    ) -> "_ExecutorMetadata | None":
        try:
            return await self.async_loadExecutorMetadata(executor_name)
        except GRPCError as exc:
            if exc.status == Status.NOT_FOUND:
                return None
            raise

    async def _async_tryLoadExecutorMetadataByNameForFlowJob(
        self,
        *,
        executor_name: str,
        flow_job_id: str,
    ) -> "_ExecutorMetadata | None":
        try:
            return await self.async_loadExecutorMetadataForFlowJob(
                executor_name=executor_name,
                flow_job_id=flow_job_id,
            )
        except GRPCError as exc:
            if exc.status == Status.NOT_FOUND:
                return None
            raise

    async def _async_tryLoadExecutorMetadataByExecutorId(
        self,
        executor_id: str,
    ) -> "_ExecutorMetadata | None":
        try:
            return await self.async_loadExecutorMetadataByExecutorId(executor_id)
        except GRPCError as exc:
            if exc.status == Status.NOT_FOUND:
                return None
            raise

    @staticmethod
    def _normalizeControllerConfig(
        controllerConfig: dict[str, Any] | None,
    ) -> dict[str, Any]:
        if controllerConfig is None:
            return {}
        if not isinstance(controllerConfig, dict):
            raise TypeError("controllerConfig must be a dictionary when provided.")
        normalized: dict[str, Any] = {}
        for key, value in controllerConfig.items():
            if not isinstance(key, str):
                raise TypeError("controllerConfig keys must be strings.")
            normalized[key] = value
        return normalized

    def _buildControllerConfig(self) -> dict[str, Any] | None:
        if not self._controllerConfig:
            return None
        return dict(self._controllerConfig)

    @staticmethod
    def _buildExecutorConfig(
        *,
        controllerConfig: dict[str, Any] | None,
        jobId: str | None,
    ) -> dict[str, Any] | None:
        mergedConfig = dict(controllerConfig) if controllerConfig is not None else {}
        if jobId:
            mergedConfig["job_id"] = jobId
        return mergedConfig or None

    def _shouldReuseActiveVmExecutorOnCreate(self) -> bool:
        if self.getExecutorType() != executor_control_service_pb2.VM_EXECUTOR:
            return False
        candidate = self._controllerConfig.get("reuse_active_vm_executor")
        return candidate is True

    def _getCachedExecutorMetadata(
        self,
        *,
        executor_name: str,
        job_id: str | None,
    ) -> "_ExecutorMetadata | None":
        if not executor_name:
            return None
        if job_id:
            for metadata in self._executorMetadata.values():
                if metadata.executor_name != executor_name:
                    continue
                if metadata.job_id != job_id:
                    continue
                return metadata
            return None
        executor_id = self._executorNames.get(executor_name)
        if not executor_id:
            return None
        return self._executorMetadata.get(executor_id)

    def _getConfiguredCtldAddress(self) -> str:
        candidate = self._controllerConfig.get("daemon_target")
        if isinstance(candidate, str):
            return candidate
        return ""

    def _getExecutorCtldAddress(self, executor: Executor | None) -> str:
        if executor is not None:
            getter = getattr(executor, "getDaemonTarget", None)
            if callable(getter):
                candidate = getter()
                if isinstance(candidate, str):
                    return candidate
        return self._getConfiguredCtldAddress()

    @staticmethod
    def _executorMetadataSupportsCtldAddress() -> bool:
        return "ctld_address" in executor_control_service_pb2.ExecutorMetadata.DESCRIPTOR.fields_by_name

    def _getSnapshotCtldAddress(
        self,
        snapshot: executor_control_service_pb2.ExecutorMetadata,
    ) -> str:
        if self._executorMetadataSupportsCtldAddress():
            candidate = getattr(snapshot, "ctld_address", "")
            if isinstance(candidate, str):
                return candidate
        return ""

    def _getExecutorVmId(self, executor: Executor | None) -> int:
        if executor is not None:
            getter = getattr(executor, "getVmId", None)
            if callable(getter):
                candidate = getter()
                if isinstance(candidate, int) and candidate > 0:
                    return candidate
        return 0

    def _getVmController(self) -> Any | None:
        getter = getattr(self._controller, "getVmController", None)
        if callable(getter):
            return getter()
        return None

    def _buildExecutorSnapshot(
        self,
        *,
        executor_id: str,
        executor_name: str,
        executor_type: int,
        executor: Executor | None,
        job_id: str,
        launch_backend: str = "",
    ) -> executor_control_service_pb2.ExecutorMetadata:
        snapshot_kwargs: dict[str, str | int] = dict(
            executor_id=executor_id,
            executor_name=executor_name,
            executor_type=executor_type,
            job_id=job_id,
            launch_backend=launch_backend,
            vm_id=self._getExecutorVmId(executor),
        )
        if self._executorMetadataSupportsCtldAddress():
            snapshot_kwargs["ctld_address"] = self._getExecutorCtldAddress(executor)
        return executor_control_service_pb2.ExecutorMetadata(**snapshot_kwargs)

    def _buildControllerConfigFromSnapshot(
        self,
        snapshot: executor_control_service_pb2.ExecutorMetadata,
        *,
        executorName: str,
        executorType: int,
    ) -> dict[str, Any] | None:
        controllerConfig = self._buildControllerConfig() or {}
        if executorType != executor_control_service_pb2.VM_EXECUTOR:
            return controllerConfig or None
        snapshotCtldAddress = self._getSnapshotCtldAddress(snapshot)
        if snapshotCtldAddress:
            controllerConfig["daemon_target"] = snapshotCtldAddress
        if snapshot.vm_id > 0:
            controllerConfig["vm_id"] = int(snapshot.vm_id)
        if snapshotCtldAddress:
            return controllerConfig
        daemonTargetTemplate = controllerConfig.get("daemon_target_template")
        if (
            isinstance(daemonTargetTemplate, str)
            and daemonTargetTemplate.strip()
            and snapshot.vm_id > 0
        ):
            controllerConfig["daemon_target"] = self._resolveVmDaemonTargetFromTemplate(
                daemonTargetTemplate=daemonTargetTemplate,
                executorName=executorName,
                vmId=int(snapshot.vm_id),
            )
            return controllerConfig
        if controllerConfig.get("daemon_target"):
            return controllerConfig
        raise GRPCError(
            Status.FAILED_PRECONDITION,
            "stored VM executor metadata is missing daemon target configuration.",
        )

    @staticmethod
    def _resolveVmDaemonTargetFromTemplate(
        *,
        daemonTargetTemplate: str,
        executorName: str,
        vmId: int,
    ) -> str:
        try:
            resolvedTarget = daemonTargetTemplate.format(
                vm_name=executorName,
                vm_id=vmId,
            ).strip()
        except KeyError as exc:
            raise GRPCError(
                Status.FAILED_PRECONDITION,
                "daemon_target_template only supports {vm_name} and {vm_id} placeholders.",
            ) from exc
        if not resolvedTarget:
            raise GRPCError(
                Status.FAILED_PRECONDITION,
                "resolved daemon target from template must not be empty.",
            )
        try:
            NetTarget.parseTarget(resolvedTarget)
        except RuntimeError as exc:
            raise GRPCError(
                Status.FAILED_PRECONDITION,
                f"resolved daemon target is invalid: {exc}",
            ) from exc
        return resolvedTarget

    def _cacheExecutorMetadata(self, metadata: "_ExecutorMetadata") -> None:
        self._executorMetadata[metadata.executor_id] = metadata
        self._executorNames[metadata.executor_name] = metadata.executor_id

    def _removeExecutorMetadataFromCaches(self, metadata: "_ExecutorMetadata") -> None:
        self._executorMetadata.pop(metadata.executor_id, None)
        if self._executorNames.get(metadata.executor_name) == metadata.executor_id:
            self._executorNames.pop(metadata.executor_name, None)
        if metadata.job_id:
            if self._jobExecutors.get(metadata.job_id) == metadata.executor_id:
                self._jobExecutors.pop(metadata.job_id, None)
            self._jobLaunchBackend.pop(metadata.job_id, None)

    async def _async_deleteExecutorMetadataAndCaches(
        self,
        metadata: "_ExecutorMetadata",
    ) -> None:
        try:
            executorUuid = uuid.UUID(metadata.executor_id)
        except ValueError:
            self._removeExecutorMetadataFromCaches(metadata)
            return
        await self.async_deleteExecutorMetadata(executor_id=executorUuid)
        self._removeExecutorMetadataFromCaches(metadata)

    async def _async_getTrackedVmStatus(
        self,
        metadata: "_ExecutorMetadata",
    ) -> str | None:
        if metadata.vm_id is None or metadata.vm_id <= 0:
            return None
        vm_controller = self._getVmController()
        if vm_controller is None:
            raise GRPCError(
                Status.FAILED_PRECONDITION,
                "VmController is required for managed VM lifecycle operations.",
            )
        try:
            return await vm_controller.async_getVmStatus(metadata.vm_id)
        except GRPCError:
            raise
        except Exception as exc:
            logger.exception(
                f"ExecutorControlService VM status lookup failed "
                f"executor_id={metadata.executor_id} vm_id={metadata.vm_id}"
            )
            raise GRPCError(Status.INTERNAL, f"VmController status lookup failed: {exc}") from exc

    async def _async_isExecutorReusable(self, metadata: "_ExecutorMetadata") -> bool:
        if metadata.executor_type != executor_control_service_pb2.VM_EXECUTOR:
            return True
        if metadata.vm_id is None or metadata.vm_id <= 0:
            return True
        vmStatus = await self._async_getTrackedVmStatus(metadata)
        return vmStatus == _VM_STATUS_RUNNING

    async def _async_ensureManagedVmRunning(
        self,
        metadata: "_ExecutorMetadata",
        *,
        operation: str,
    ) -> None:
        if metadata.executor_type != executor_control_service_pb2.VM_EXECUTOR:
            return
        if metadata.vm_id is None or metadata.vm_id <= 0:
            return
        vmStatus = await self._async_getTrackedVmStatus(metadata)
        if vmStatus == _VM_STATUS_RUNNING:
            return
        if vmStatus is not None:
            await self._async_destroyTrackedVm(
                metadata,
                reason=f"{operation} found non-running vm status={vmStatus}",
                allowMissingVmRow=False,
            )
            raise GRPCError(
                Status.UNAVAILABLE,
                f"managed VM is not running for {operation}: {vmStatus}",
            )
        raise GRPCError(
            Status.FAILED_PRECONDITION,
            f"managed VM record is missing for {operation}.",
        )

    async def _async_destroyTrackedVm(
        self,
        metadata: "_ExecutorMetadata",
        *,
        reason: str,
        allowMissingVmRow: bool,
    ) -> bool:
        if metadata.vm_id is None or metadata.vm_id <= 0:
            return False
        vm_controller = self._getVmController()
        if vm_controller is None:
            raise GRPCError(
                Status.FAILED_PRECONDITION,
                "VmController is required for managed VM destroy operations.",
            )
        try:
            destroy_status = await vm_controller.async_destroyVmAndDeleteEntry(
                metadata.vm_id
            )
        except ValueError as exc:
            if allowMissingVmRow:
                logger.warning(
                    f"ExecutorControlService VM destroy skipped missing row "
                    f"executor_id={metadata.executor_id} vm_id={metadata.vm_id} reason={reason}"
                )
                return False
            raise GRPCError(Status.FAILED_PRECONDITION, str(exc)) from exc
        except Exception as exc:
            logger.exception(
                f"ExecutorControlService VM destroy failed "
                f"executor_id={metadata.executor_id} vm_id={metadata.vm_id} reason={reason}"
            )
            raise GRPCError(Status.INTERNAL, f"VmController destroy failed: {exc}") from exc
        if destroy_status != "DELETED":
            raise GRPCError(
                Status.INTERNAL,
                f"VmController destroy returned unexpected status: {destroy_status}",
            )
        logger.info(
            f"ExecutorControlService destroyed managed VM executor_id={metadata.executor_id} "
            f"vm_id={metadata.vm_id} reason={reason}"
        )
        return True

    async def _async_handleUnhealthyVm(
        self,
        metadata: "_ExecutorMetadata",
        *,
        reason: str,
    ) -> None:
        if metadata.executor_type != executor_control_service_pb2.VM_EXECUTOR:
            return
        if metadata.vm_id is None or metadata.vm_id <= 0:
            return
        await self._async_destroyTrackedVm(
            metadata,
            reason=reason,
            allowMissingVmRow=True,
        )

    @staticmethod
    def _isVmInfrastructureFailureResult(result) -> bool:
        output = getattr(result, "output", None)
        if not isinstance(output, Mapping):
            return False
        stage = output.get("stage", "")
        if isinstance(stage, str) and stage in {"upload", "launch"}:
            return True
        code = output.get("code", "")
        if isinstance(code, str) and code:
            try:
                return int(code) != 0
            except ValueError:
                return True
        return False

    @staticmethod
    def _isLocalExecutorBackend(backend: str) -> bool:
        return backend in {_BACKEND_LOCAL_EXECUTOR, _BACKEND_LOCAL_PROXY}

    @staticmethod
    def _parseExecutorSnapshot(
        serialized_executor: bytes,
    ) -> executor_control_service_pb2.ExecutorMetadata:
        snapshot = executor_control_service_pb2.ExecutorMetadata()
        try:
            snapshot.ParseFromString(serialized_executor)
        except Exception as exc:
            raise GRPCError(
                Status.INTERNAL,
                "stored executor metadata could not be decoded.",
            ) from exc
        return snapshot

    @staticmethod
    def _getLaunchBackend(executorType: int) -> str:
        if executorType == executor_control_service_pb2.LOCAL_EXECUTOR:
            return _BACKEND_LOCAL_EXECUTOR
        if executorType == executor_control_service_pb2.VM_EXECUTOR:
            return _BACKEND_VM_EXECUTOR
        return ""

    @staticmethod
    def _parseExecutorType(raw_value: str) -> int:
        normalized = raw_value.strip().upper()
        if normalized == "PROCESS_GROUP_EXECUTOR":
            return executor_control_service_pb2.LOCAL_EXECUTOR
        if normalized == "LOCAL_EXECUTOR":
            return executor_control_service_pb2.LOCAL_EXECUTOR
        if normalized == "VM_EXECUTOR":
            return executor_control_service_pb2.VM_EXECUTOR
        if normalized == "UNKNOWN_EXECUTOR":
            return executor_control_service_pb2.UNKNOWN_EXECUTOR
        return executor_control_service_pb2.UNKNOWN_EXECUTOR

    @staticmethod
    def _resolveFlowJobId(job_id: str) -> uuid.UUID:
        raw_value = job_id or ""
        if not raw_value:
            raise GRPCError(Status.INVALID_ARGUMENT, "job_id must be provided.")
        try:
            return uuid.UUID(raw_value)
        except ValueError as exc:
            raise GRPCError(Status.INVALID_ARGUMENT, "job_id must be a UUID.") from exc

    @staticmethod
    def _buildLaunchParams(
        create_params: Dict[str, str],
        launch_params: Dict[str, str],
        job_id: str,
    ) -> dict[str, object]:
        merged_params: dict[str, object] = {}
        for key, value in create_params.items():
            if not key.startswith("--"):
                logger.warning(f"ExecutorControlService invalid create param key={key}")
                raise GRPCError(
                    Status.INVALID_ARGUMENT,
                    f"create param keys must start with --: {key}",
                )
            merged_params[key] = value
        for key, value in launch_params.items():
            if not key.startswith("--"):
                logger.warning(f"ExecutorControlService invalid launch param key={key}")
                raise GRPCError(
                    Status.INVALID_ARGUMENT,
                    f"launch param keys must start with --: {key}",
                )
            merged_params[key] = value
        if job_id and "job_id" not in merged_params:
            merged_params["job_id"] = job_id
        return merged_params

    def _buildOperatorDockerMediationPolicy(
        self,
        *,
        runtimeIdentity: executor_control_service_pb2.OperatorRuntimeIdentity,
    ) -> cartond_pb2.DockerMediationPolicy | None:
        labels: dict[str, str] = {}
        loggingAppId = (runtimeIdentity.logging_app_id or "").strip()
        if loggingAppId:
            labels[_DOCKER_LABEL_APP_ID] = loggingAppId
        operatorName = (runtimeIdentity.operator_name or "").strip()
        if operatorName:
            labels[_DOCKER_LABEL_OPERATOR_NAME] = operatorName
        instanceId = (runtimeIdentity.instance_id or "").strip()
        if instanceId:
            labels[_DOCKER_LABEL_INSTANCE_ID] = instanceId

        normalizedDriver = self._operatorDockerLogDriver
        if not normalizedDriver and not labels:
            return None

        policy = cartond_pb2.DockerMediationPolicy()
        if labels:
            policy.container_labels.update(labels)

        if normalizedDriver == "none":
            policy.log_policy.driver = cartond_pb2.DOCKER_LOG_DRIVER_NONE
        elif normalizedDriver == "json-file":
            policy.log_policy.driver = cartond_pb2.DOCKER_LOG_DRIVER_JSON_FILE
        elif normalizedDriver == "fluentd":
            policy.log_policy.driver = cartond_pb2.DOCKER_LOG_DRIVER_FLUENTD
            policy.log_policy.fluentd_address = self._operatorDockerFluentdAddress
        return policy
    @staticmethod
    def _resolveExecutorAppId(metadata: "_ExecutorMetadata") -> str:
        if (
            metadata.executor_type == executor_control_service_pb2.VM_EXECUTOR
            and metadata.job_id
        ):
            return metadata.job_id
        return metadata.executor_id

    async def _async_createAppForExecutor(
        self,
        *,
        executor: Executor,
        appId: str,
        params: Dict[str, object] | Dict[str, str],
        dockerMediationPolicy: cartond_pb2.DockerMediationPolicy | None = None,
    ) -> None:
        createParams = dict(params)
        if dockerMediationPolicy is not None:
            createParams["docker_mediation_policy"] = dockerMediationPolicy
        try:
            await executor.async_createApp(
                appId=appId,
                params=createParams,
            )
        except GRPCError:
            raise
        except Exception as exc:
            logger.exception(
                f"ExecutorControlService create app failed app_id={appId} "
                f"executor_class={executor.__class__.__name__}"
            )
            raise GRPCError(Status.INTERNAL, f"executor create app failed: {exc}") from exc

    async def async_close(self) -> None:
        return

    async def _async_launchViaExecutor(
        self,
        metadata: "_ExecutorMetadata",
        *,
        hashScheme: str,
        hashValue: str,
        params: dict[str, object],
    ) -> executor_control_service_pb2.LaunchResponse:
        executor = self._requireExecutor(metadata)
        appId = self._resolveExecutorAppId(metadata)
        jobId = metadata.job_id or ""
        if not jobId:
            raise GRPCError(Status.FAILED_PRECONDITION, "job_id is not registered.")
        try:
            await executor.async_uploadAppImage(
                appId=appId,
                chunkStream=self._async_readCasChunks(
                    hashScheme=hashScheme,
                    hashValue=hashValue,
                ),
            )
            result = await executor.async_launchApp(appId=appId, params=params)
        except GRPCError:
            raise
        except KeyError as exc:
            raise GRPCError(Status.NOT_FOUND, str(exc)) from exc
        except (TypeError, ValueError) as exc:
            raise GRPCError(Status.INVALID_ARGUMENT, str(exc)) from exc
        except RuntimeError as exc:
            raise GRPCError(Status.INTERNAL, str(exc)) from exc
        logger.info(
            f"ExecutorControlService Launch executor done "
            f"executor_id={metadata.executor_id} job_id={jobId} status={result.status}"
        )
        return executor_control_service_pb2.LaunchResponse(
            job_id=jobId,
            status=self._mapExecutorLaunchStatus(result),
        )

    async def _async_launchViaLocalProxy(
        self,
        metadata: "_ExecutorMetadata",
        *,
        hashScheme: str,
        hashValue: str,
        params: dict[str, object],
    ) -> executor_control_service_pb2.LaunchResponse:
        if self._localExecutorProxyClient is None:
            logger.warning("ExecutorControlService Launch rejected local executor proxy not configured")
            raise GRPCError(
                Status.FAILED_PRECONDITION,
                "local executor proxy is not configured.",
            )

        job_id = params.get("job_id")
        if not isinstance(job_id, str) or not job_id:
            job_id = metadata.job_id
        if not isinstance(job_id, str) or not job_id:
            logger.warning(
                f"ExecutorControlService Launch missing job_id for executor_id={metadata.executor_id}"
            )
            raise GRPCError(Status.INVALID_ARGUMENT, "job_id must be provided.")

        async def _async_uploadAppImage():
            imageId = str(uuid.uuid4())
            logger.info(
                f"ExecutorControlService Launch uploading CAS image "
                f"executor_id={metadata.executor_id} job_id={job_id} image_id={imageId}"
            )
            uploadResult = await self._localExecutorProxyClient.async_uploadAppImageStream(
                imageId=imageId,
                chunkStream=self._async_readCasChunks(hashScheme=hashScheme, hashValue=hashValue),
            )
            return imageId, uploadResult

        try:
            image_id, upload_result = await self._retryUntilReady.async_retryUntilReady(
                operationName="ExecutorControl UploadAppImage",
                invocation=_async_uploadAppImage,
            )
        except RetryDeadlineExceededError as exc:
            raise GRPCError(Status.UNAVAILABLE, "local executor proxy is not ready.") from exc
        if upload_result.code != 0:
            logger.error(
                f"ExecutorControlService Launch upload failed executor_id={metadata.executor_id} "
                f"job_id={job_id} code={upload_result.code} message={upload_result.message}"
            )
            raise GRPCError(
                Status.INTERNAL,
                f"local proxy upload failed: {upload_result.message}",
            )

        argv = self._parseArgvParam(params.get("--argv"))
        env = self._parseEnvParam(params.get("--env"))
        if self._sidecarOtlpTarget:
            env.setdefault(_OTEL_EXPORTER_OTLP_ENDPOINT_ENV, self._sidecarOtlpTarget)
        sidecarLogLevel = os.environ.get(_SIDECAR_LOG_LEVEL_ENV, "").strip()
        if sidecarLogLevel:
            env.setdefault(_SIDECAR_LOG_LEVEL_ENV, sidecarLogLevel)
        working_dir = params.get("--cwd")
        if not isinstance(working_dir, str):
            working_dir = ""
        try:
            launch_result = await self._retryUntilReady.async_retryUntilReady(
                operationName="ExecutorControl LaunchApp",
                invocation=lambda: self._localExecutorProxyClient.async_launchApp(
                    appId=job_id,
                    imageId=image_id,
                    argv=argv,
                    env=env,
                    workingDir=working_dir,
                ),
            )
        except RetryDeadlineExceededError as exc:
            raise GRPCError(Status.UNAVAILABLE, "local executor proxy is not ready.") from exc
        status = self._mapLocalProxyLaunchStatus(launch_result)
        logger.info(
            f"ExecutorControlService Launch local proxy launch done "
            f"executor_id={metadata.executor_id} job_id={job_id} "
            f"run_status={launch_result.runStatus} code={launch_result.code}"
        )
        return executor_control_service_pb2.LaunchResponse(job_id=job_id, status=status)

    async def _async_launchViaVmExecutor(
        self,
        metadata: "_ExecutorMetadata",
        *,
        hashScheme: str,
        hashValue: str,
        params: dict[str, object],
    ) -> executor_control_service_pb2.LaunchResponse:
        executor = self._requireExecutor(metadata)
        await self._async_ensureManagedVmRunning(metadata, operation="Launch")
        blob = await self._async_readCasBlob(
            hashScheme=hashScheme,
            hashValue=hashValue,
        )
        vmParams = self._buildVmLaunchParams(params)
        try:
            result = await executor.async_launch(blob, vmParams)
        except (TypeError, ValueError) as exc:
            logger.warning(
                f"ExecutorControlService Launch invalid VM executor config "
                f"executor_id={metadata.executor_id} error={exc}"
            )
            raise GRPCError(Status.FAILED_PRECONDITION, str(exc)) from exc
        except Exception as exc:
            logger.exception(
                f"ExecutorControlService Launch VM executor failed "
                f"executor_id={metadata.executor_id}"
            )
            await self._async_handleUnhealthyVm(
                metadata,
                reason=f"launch transport failure for executor_id={metadata.executor_id}: {exc}",
            )
            raise GRPCError(Status.INTERNAL, f"VM executor launch failed: {exc}") from exc

        if result.status == "FAILED" and self._isVmInfrastructureFailureResult(result):
            await self._async_handleUnhealthyVm(
                metadata,
                reason=f"launch infrastructure failure for executor_id={metadata.executor_id}",
            )
        jobId = result.job_id or metadata.job_id or ""
        if not jobId:
            raise GRPCError(Status.INTERNAL, "VM executor launch returned no job_id.")
        return executor_control_service_pb2.LaunchResponse(
            job_id=jobId,
            status=self._mapExecutorLaunchStatus(result),
        )

    async def _async_getAppStatusViaVmExecutor(
        self,
        metadata: "_ExecutorMetadata",
        jobId: str,
    ):
        executor = self._requireExecutor(metadata)
        await self._async_ensureManagedVmRunning(metadata, operation="GetStatus")
        try:
            result = await executor.async_getStatus(jobId)
        except KeyError as exc:
            raise GRPCError(Status.NOT_FOUND, str(exc)) from exc
        except (TypeError, ValueError) as exc:
            raise GRPCError(Status.INVALID_ARGUMENT, str(exc)) from exc
        except Exception as exc:
            logger.exception(
                f"ExecutorControlService VM get status failed executor_id={metadata.executor_id} "
                f"job_id={jobId}"
            )
            await self._async_handleUnhealthyVm(
                metadata,
                reason=f"status transport failure for executor_id={metadata.executor_id} job_id={jobId}: {exc}",
            )
            raise GRPCError(Status.INTERNAL, f"VM executor get status failed: {exc}") from exc
        if result.status == "FAILED" and self._isVmInfrastructureFailureResult(result):
            await self._async_handleUnhealthyVm(
                metadata,
                reason=f"status infrastructure failure for executor_id={metadata.executor_id} job_id={jobId}",
            )
        return result

    async def _async_terminateAppViaVmExecutor(
        self,
        metadata: "_ExecutorMetadata",
        jobId: str,
    ) -> None:
        executor = self._requireExecutor(metadata)
        await self._async_ensureManagedVmRunning(metadata, operation="Destroy")
        try:
            await executor.async_killProcess(jobId)
        except KeyError as exc:
            raise GRPCError(Status.NOT_FOUND, str(exc)) from exc
        except (TypeError, ValueError) as exc:
            raise GRPCError(Status.INVALID_ARGUMENT, str(exc)) from exc
        except Exception as exc:
            logger.exception(
                f"ExecutorControlService VM terminate failed executor_id={metadata.executor_id} "
                f"job_id={jobId}"
            )
            await self._async_handleUnhealthyVm(
                metadata,
                reason=f"terminate transport failure for executor_id={metadata.executor_id} job_id={jobId}: {exc}",
            )
            raise GRPCError(Status.INTERNAL, f"VM executor terminate failed: {exc}") from exc

    def _requireExecutor(self, metadata: "_ExecutorMetadata") -> Executor:
        if metadata.executor is None:
            raise GRPCError(Status.FAILED_PRECONDITION, "executor instance is not available.")
        return metadata.executor

    async def _async_getAppStatusViaExecutor(self, metadata: "_ExecutorMetadata"):
        executor = self._requireExecutor(metadata)
        appId = self._resolveExecutorAppId(metadata)
        try:
            return await executor.async_getStatus(appId)
        except GRPCError:
            raise
        except KeyError as exc:
            raise GRPCError(Status.NOT_FOUND, str(exc)) from exc
        except (TypeError, ValueError) as exc:
            raise GRPCError(Status.INVALID_ARGUMENT, str(exc)) from exc
        except RuntimeError as exc:
            raise GRPCError(Status.INTERNAL, str(exc)) from exc

    async def _async_terminateAppViaExecutor(self, metadata: "_ExecutorMetadata") -> None:
        executor = self._requireExecutor(metadata)
        appId = self._resolveExecutorAppId(metadata)
        try:
            await executor.async_tearDownApp(appId)
        except GRPCError:
            raise
        except KeyError as exc:
            raise GRPCError(Status.NOT_FOUND, str(exc)) from exc
        except (TypeError, ValueError) as exc:
            raise GRPCError(Status.INVALID_ARGUMENT, str(exc)) from exc
        except RuntimeError as exc:
            raise GRPCError(Status.INTERNAL, str(exc)) from exc

    async def _async_getAppStatusViaLocalProxy(self, appId: str) -> GetAppStatusResult:
        if self._localExecutorProxyClient is None:
            logger.warning("ExecutorControlService status rejected local executor proxy not configured")
            raise GRPCError(
                Status.FAILED_PRECONDITION,
                "local executor proxy is not configured.",
            )
        try:
            return await self._retryUntilReady.async_retryUntilReady(
                operationName="ExecutorControl GetAppStatus",
                invocation=lambda: self._localExecutorProxyClient.async_getAppStatus(appId),
            )
        except RetryDeadlineExceededError as exc:
            raise GRPCError(Status.UNAVAILABLE, "local executor proxy is not ready.") from exc
        except GRPCError:
            raise
        except Exception as exc:
            logger.exception(f"ExecutorControlService local proxy get status failed app_id={appId}")
            raise GRPCError(Status.UNAVAILABLE, f"local proxy get status failed: {exc}") from exc

    async def _async_terminateAppViaLocalProxy(self, appId: str) -> TerminateAppResult:
        if self._localExecutorProxyClient is None:
            logger.warning("ExecutorControlService terminate rejected local executor proxy not configured")
            raise GRPCError(
                Status.FAILED_PRECONDITION,
                "local executor proxy is not configured.",
            )
        try:
            return await self._retryUntilReady.async_retryUntilReady(
                operationName="ExecutorControl TerminateApp",
                invocation=lambda: self._localExecutorProxyClient.async_terminateApp(appId),
            )
        except RetryDeadlineExceededError as exc:
            raise GRPCError(Status.UNAVAILABLE, "local executor proxy is not ready.") from exc
        except GRPCError:
            raise
        except Exception as exc:
            logger.exception(f"ExecutorControlService local proxy terminate failed app_id={appId}")
            raise GRPCError(Status.UNAVAILABLE, f"local proxy terminate failed: {exc}") from exc

    def _buildCasChannel(self) -> Channel:
        if self._casUdsPath:
            return Channel(path=self._casUdsPath)
        if self._casPort is None:
            logger.error("ExecutorControlService missing CAS target port for TCP channel")
            raise GRPCError(Status.FAILED_PRECONDITION, "cas target port is not configured.")
        return Channel(host=self._casHost, port=self._casPort)

    async def _async_readCasChunks(
        self,
        *,
        hashScheme: str,
        hashValue: str,
        chunkSizeBytes: int = 1024 * 64,
    ) -> AsyncIterator[bytes]:
        logger.info(
            f"ExecutorControlService CAS read begin hash_scheme={hashScheme} hash_value={hashValue}"
        )
        channel = self._buildCasChannel()
        yielded_chunks = 0
        try:
            stub = cas_grpc.CasServiceStub(channel)
            try:
                async def _async_openReadStream():
                    streamContext = stub.Read.open()
                    stream = await streamContext.__aenter__()
                    return streamContext, stream

                streamContext, stream = await self._retryUntilReady.async_retryUntilReady(
                    operationName="ExecutorControl CAS Read.open",
                    invocation=_async_openReadStream,
                )
                try:
                    await stream.send_message(
                        cas_pb2.ReadRequest(
                            hash_scheme=hashScheme,
                            hash_value=hashValue,
                            chunk_size_bytes=chunkSizeBytes,
                        )
                    )
                    await stream.end()
                    while True:
                        readChunk = await stream.recv_message()
                        if readChunk is None:
                            break
                        chunk = bytes(readChunk.data)
                        if chunk:
                            yielded_chunks += 1
                            yield chunk
                finally:
                    await streamContext.__aexit__(None, None, None)
            except RetryDeadlineExceededError as exc:
                raise GRPCError(Status.UNAVAILABLE, "CAS service is not ready.") from exc
            except GRPCError as exc:
                if exc.status == Status.NOT_FOUND:
                    logger.warning(
                        f"ExecutorControlService CAS object not found "
                        f"hash_scheme={hashScheme} hash_value={hashValue}"
                    )
                    raise GRPCError(
                        Status.NOT_FOUND,
                        f"CAS object not found: {hashScheme}:{hashValue}",
                    ) from exc
                if exc.status == Status.INVALID_ARGUMENT:
                    raise
                logger.error(
                    f"ExecutorControlService CAS read failed "
                    f"hash_scheme={hashScheme} hash_value={hashValue} status={exc.status}"
                )
                raise GRPCError(Status.UNAVAILABLE, f"CAS read failed: {exc}") from exc
        finally:
            channel.close()
            logger.info(
                f"ExecutorControlService CAS read done hash_scheme={hashScheme} "
                f"hash_value={hashValue} chunk_count={yielded_chunks}"
            )

    async def _async_readCasBlob(
        self,
        *,
        hashScheme: str,
        hashValue: str,
        chunkSizeBytes: int = 1024 * 64,
    ) -> bytes:
        payload = bytearray()
        async for chunk in self._async_readCasChunks(
            hashScheme=hashScheme,
            hashValue=hashValue,
            chunkSizeBytes=chunkSizeBytes,
        ):
            payload.extend(chunk)
        return bytes(payload)

    def _buildVmLaunchParams(self, params: dict[str, object]) -> dict[str, object]:
        vmParams: dict[str, object] = {}
        jobId = params.get("job_id")
        if isinstance(jobId, str) and jobId:
            vmParams["app_id"] = jobId

        if "--argv" in params:
            vmParams["argv"] = self._parseArgvParam(params.get("--argv"))

        envParamPresent = "--env" in params
        env = self._parseEnvParam(params.get("--env")) if envParamPresent else None
        if env is None:
            env = {}
        if self._sidecarOtlpTarget:
            env.setdefault(_OTEL_EXPORTER_OTLP_ENDPOINT_ENV, self._sidecarOtlpTarget)
        sidecarLogLevel = os.environ.get(_SIDECAR_LOG_LEVEL_ENV, "").strip()
        if sidecarLogLevel:
            env.setdefault(_SIDECAR_LOG_LEVEL_ENV, sidecarLogLevel)
        if envParamPresent or env:
            vmParams["env"] = env

        workingDir = self._parseOptionalStringParam(
            params.get("--working-dir", params.get("--working_dir", params.get("--cwd"))),
            "working_dir",
        )
        if workingDir is not None:
            vmParams["working_dir"] = workingDir

        user = self._parseOptionalStringParam(params.get("--user"), "user")
        if user is not None:
            vmParams["user"] = user

        imageId = self._parseOptionalStringParam(
            params.get("--image-id", params.get("--image_id")),
            "image_id",
        )
        if imageId is not None:
            vmParams["image_id"] = imageId

        return vmParams

    @staticmethod
    def _parseOptionalStringParam(raw_value: object, fieldName: str) -> str | None:
        if raw_value is None:
            return None
        if not isinstance(raw_value, str):
            raise GRPCError(Status.INVALID_ARGUMENT, f"{fieldName} must be a string.")
        normalized = raw_value.strip()
        if not normalized:
            raise GRPCError(
                Status.INVALID_ARGUMENT,
                f"{fieldName} must be a non-empty string.",
            )
        return normalized

    @staticmethod
    def _parseArgvParam(raw_value: object) -> list[str]:
        if raw_value is None:
            return []
        if isinstance(raw_value, list):
            return [str(item) for item in raw_value]
        if isinstance(raw_value, str):
            trimmed = raw_value.strip()
            if not trimmed:
                return []
            if trimmed.startswith("["):
                try:
                    parsed = json.loads(trimmed)
                except json.JSONDecodeError as exc:
                    raise GRPCError(
                        Status.INVALID_ARGUMENT,
                        f"argv must be JSON list: {exc}",
                    ) from exc
                if not isinstance(parsed, list):
                    raise GRPCError(
                        Status.INVALID_ARGUMENT,
                        "argv must be a JSON list.",
                    )
                return [str(item) for item in parsed]
            return trimmed.split()
        raise GRPCError(Status.INVALID_ARGUMENT, "argv must be a string or JSON list.")

    @staticmethod
    def _parseEnvParam(raw_value: object) -> dict[str, str]:
        if raw_value is None:
            return {}
        if isinstance(raw_value, dict):
            return {str(key): str(value) for key, value in raw_value.items()}
        if isinstance(raw_value, str):
            trimmed = raw_value.strip()
            if not trimmed:
                return {}
            if not trimmed.startswith("{"):
                raise GRPCError(Status.INVALID_ARGUMENT, "env must be a JSON object.")
            try:
                parsed = json.loads(trimmed)
            except json.JSONDecodeError as exc:
                raise GRPCError(
                    Status.INVALID_ARGUMENT,
                    f"env must be JSON object: {exc}",
                ) from exc
            if not isinstance(parsed, dict):
                raise GRPCError(Status.INVALID_ARGUMENT, "env must be a JSON object.")
            return {str(key): str(value) for key, value in parsed.items()}
        raise GRPCError(Status.INVALID_ARGUMENT, "env must be a JSON object.")

    @staticmethod
    def _mapLocalProxyLaunchStatus(result: LaunchAppResult) -> int:
        if result.code != 0:
            return executor_control_service_pb2.LAUNCH_STATUS_FAILED
        if result.runStatus == _LOCAL_PROXY_RUNTIME_STATUS_RUNNING:
            return executor_control_service_pb2.LAUNCH_STATUS_RUNNING
        if result.runStatus == _LOCAL_PROXY_RUNTIME_STATUS_FAILED:
            return executor_control_service_pb2.LAUNCH_STATUS_FAILED
        return executor_control_service_pb2.LAUNCH_STATUS_UNKNOWN

    @staticmethod
    def _mapLocalProxyRuntimeStatus(status: int) -> int:
        if status == _LOCAL_PROXY_RUNTIME_STATUS_RUNNING:
            return executor_control_service_pb2.RUNTIME_STATUS_RUNNING
        if status == _LOCAL_PROXY_RUNTIME_STATUS_EXITED:
            return executor_control_service_pb2.RUNTIME_STATUS_EXITED
        if status == _LOCAL_PROXY_RUNTIME_STATUS_FAILED:
            return executor_control_service_pb2.RUNTIME_STATUS_FAILED
        if status == _LOCAL_PROXY_RUNTIME_STATUS_TERMINATED:
            return executor_control_service_pb2.RUNTIME_STATUS_TERMINATED
        return executor_control_service_pb2.RUNTIME_STATUS_UNKNOWN

    @staticmethod
    def _mapExecutorLaunchStatus(result) -> int:
        if result.status == "PENDING":
            return executor_control_service_pb2.LAUNCH_STATUS_PENDING
        if result.status == "RUNNING":
            return executor_control_service_pb2.LAUNCH_STATUS_RUNNING
        if result.status == "FAILED":
            return executor_control_service_pb2.LAUNCH_STATUS_FAILED
        return executor_control_service_pb2.LAUNCH_STATUS_UNKNOWN

    @staticmethod
    def _mapExecutorRuntimeStatus(result) -> int:
        if result.status == "PENDING":
            return executor_control_service_pb2.RUNTIME_STATUS_PENDING
        if result.status == "RUNNING":
            return executor_control_service_pb2.RUNTIME_STATUS_RUNNING
        if result.status == "SUCCEEDED":
            return executor_control_service_pb2.RUNTIME_STATUS_EXITED
        if result.status == "FAILED":
            return executor_control_service_pb2.RUNTIME_STATUS_FAILED
        return executor_control_service_pb2.RUNTIME_STATUS_UNKNOWN

    @staticmethod
    def _parseResultInt(rawValue: object) -> int:
        if not isinstance(rawValue, str) or not rawValue:
            return 0
        try:
            return int(rawValue)
        except ValueError:
            return 0

    @staticmethod
    def _getResultMessage(result) -> str:
        rawValue = result.output.get("message")
        if isinstance(rawValue, str):
            return rawValue
        return ""

    async def async_persistExecutorMetadata(
        self,
        *,
        executor_name: str,
        executor_type: int,
        serialized_executor: bytes,
        flow_job_id: uuid.UUID,
    ) -> uuid.UUID:
        logger.info(
            f"ExecutorControlService persist metadata begin executor_name={executor_name} "
            f"flow_job_id={flow_job_id}"
        )
        async def _attemptPersist() -> uuid.UUID:
            async with self._session_maker() as session:
                async with sqldb_utils.async_transactionContext(existing_session=session) as tx_ctx:
                    try:
                        row = (
                            await tx_ctx.session.execute(
                                insert(TabExecutors)
                                .values(
                                    flow_job_id=flow_job_id,
                                    name=executor_name,
                                    executor_type=str(executor_type),
                                    serialized_executor=serialized_executor,
                                )
                                .returning(TabExecutors.id)
                            )
                        ).one()
                    except IntegrityError:
                        logger.warning(
                            f"ExecutorControlService persist metadata duplicate executor_name={executor_name} "
                            f"flow_job_id={flow_job_id}"
                        )
                        existing = (
                            await tx_ctx.session.execute(
                                select(TabExecutors.id).where(
                                    TabExecutors.flow_job_id == flow_job_id,
                                    TabExecutors.name == executor_name,
                                )
                            )
                        ).one()
                        (executor_id,) = existing
                        return executor_id
                    except Exception as exc:
                        logger.exception(
                            f"ExecutorControlService persist metadata failed executor_name={executor_name} "
                            f"flow_job_id={flow_job_id}"
                        )
                        raise GRPCError(Status.INTERNAL, f"Failed to persist executor metadata: {exc}") from exc
            (executor_id,) = row
            return executor_id

        executor_id = await sqldb_utils.async_runWithSerializationRetries(
            _attemptPersist,
            is_retryable=sqldb_utils.isRetryableSerializationError,
        )
        logger.info(
            f"ExecutorControlService persist metadata done executor_name={executor_name} "
            f"executor_id={executor_id} flow_job_id={flow_job_id}"
        )
        return executor_id

    async def async_updateExecutorMetadataSnapshot(
        self,
        *,
        executor_id: uuid.UUID,
        snapshot: executor_control_service_pb2.ExecutorMetadata,
    ) -> None:
        logger.info(f"ExecutorControlService update metadata begin executor_id={executor_id}")

        async def _attemptUpdate() -> None:
            async with self._session_maker() as session:
                async with sqldb_utils.async_transactionContext(existing_session=session) as tx_ctx:
                    try:
                        await tx_ctx.session.execute(
                            update(TabExecutors)
                            .where(TabExecutors.id == executor_id)
                            .values(serialized_executor=snapshot.SerializeToString())
                        )
                    except Exception as exc:
                        logger.exception(
                            f"ExecutorControlService update metadata failed executor_id={executor_id}"
                        )
                        raise GRPCError(Status.INTERNAL, f"Failed to update executor metadata: {exc}") from exc

        await sqldb_utils.async_runWithSerializationRetries(
            _attemptUpdate,
            is_retryable=sqldb_utils.isRetryableSerializationError,
        )
        logger.info(f"ExecutorControlService update metadata done executor_id={executor_id}")

    async def async_deleteExecutorMetadata(self, *, executor_id: uuid.UUID) -> None:
        logger.info(f"ExecutorControlService delete metadata begin executor_id={executor_id}")
        async def _attemptDelete() -> None:
            async with self._session_maker() as session:
                async with sqldb_utils.async_transactionContext(existing_session=session) as tx_ctx:
                    try:
                        await tx_ctx.session.execute(
                            delete(TabExecutors).where(TabExecutors.id == executor_id)
                        )
                    except Exception as exc:
                        logger.exception(
                            f"ExecutorControlService delete metadata failed executor_id={executor_id}"
                        )
                        raise GRPCError(Status.INTERNAL, f"Failed to delete executor metadata: {exc}") from exc

        await sqldb_utils.async_runWithSerializationRetries(
            _attemptDelete,
            is_retryable=sqldb_utils.isRetryableSerializationError,
        )
        logger.info(f"ExecutorControlService delete metadata done executor_id={executor_id}")

    async def async_loadExecutorMetadata(self, executor_name: str) -> _ExecutorMetadata:
        # validate executor_name (non-empty)
        if not isinstance(executor_name, str) or not executor_name.strip():
            logger.warning("ExecutorControlService load metadata rejected empty executor_name")
            raise GRPCError(Status.INVALID_ARGUMENT, "executor_name must be provided.")
        logger.info(f"ExecutorControlService load metadata begin executor_name={executor_name}")
        # query TabExecutors by name
        async with self._session_maker() as session:
            stmt = select(TabExecutors).where(TabExecutors.name == executor_name)
            result = await session.execute(stmt)
            row = result.scalar_one_or_none()

        if row is None:
            logger.warning(
                f"ExecutorControlService load metadata executor not found executor_name={executor_name}"
            )
            raise GRPCError(Status.NOT_FOUND, "executor_name is not registered.")
        return await self._async_loadExecutorMetadataRow(row)

    async def async_loadExecutorMetadataForFlowJob(
        self,
        *,
        executor_name: str,
        flow_job_id: str,
    ) -> _ExecutorMetadata:
        if not isinstance(executor_name, str) or not executor_name.strip():
            logger.warning("ExecutorControlService load metadata rejected empty executor_name")
            raise GRPCError(Status.INVALID_ARGUMENT, "executor_name must be provided.")
        try:
            flowJobUuid = uuid.UUID(flow_job_id)
        except ValueError as exc:
            raise GRPCError(Status.INVALID_ARGUMENT, "job_id must be a valid UUID.") from exc

        async with self._session_maker() as session:
            stmt = select(TabExecutors).where(
                TabExecutors.name == executor_name,
                TabExecutors.flow_job_id == flowJobUuid,
            )
            result = await session.execute(stmt)
            row = result.scalar_one_or_none()

        if row is None:
            raise GRPCError(Status.NOT_FOUND, "executor_name is not registered for job_id.")
        return await self._async_loadExecutorMetadataRow(row)

    async def async_loadExecutorMetadataByExecutorId(
        self,
        executor_id: str,
    ) -> _ExecutorMetadata:
        if not isinstance(executor_id, str) or not executor_id.strip():
            raise GRPCError(Status.INVALID_ARGUMENT, "executor_id must be provided.")
        try:
            executorUuid = uuid.UUID(executor_id)
        except ValueError as exc:
            raise GRPCError(Status.INVALID_ARGUMENT, "executor_id must be a valid UUID.") from exc

        async with self._session_maker() as session:
            stmt = select(TabExecutors).where(TabExecutors.id == executorUuid)
            result = await session.execute(stmt)
            row = result.scalar_one_or_none()

        if row is None:
            raise GRPCError(Status.NOT_FOUND, "executor_id is not registered.")
        return await self._async_loadExecutorMetadataRow(row)

    async def _async_loadExecutorMetadataRow(self, row) -> _ExecutorMetadata:
        stored_name = row.name or ""
        cached = self._executorMetadata.get(str(row.id))
        if cached is not None:
            return cached

        raw_executor_type = getattr(row, "executor_type", "") or ""
        if isinstance(raw_executor_type, str) and raw_executor_type.isdigit():
            executor_type = int(raw_executor_type)
        elif raw_executor_type:
            executor_type = self._parseExecutorType(raw_executor_type)
        else:
            executor_type = self.getExecutorType()
        expected_executor_type = self.getExecutorType()
        if executor_type != expected_executor_type:
            logger.warning(
                f"ExecutorControlService metadata type mismatch executor_name={stored_name} "
                f"stored_executor_type={executor_type} "
                f"expected_executor_type={expected_executor_type}"
            )
            raise GRPCError(
                Status.FAILED_PRECONDITION,
                "stored executor_type does not match the configured controller.",
            )
        snapshot = self._parseExecutorSnapshot(getattr(row, "serialized_executor", b"") or b"")
        controllerConfig = self._buildControllerConfigFromSnapshot(
            snapshot,
            executorName=stored_name,
            executorType=executor_type,
        )
        executor = await self._controller.async_createExecutor(
            stored_name,
            executor_config=self._buildExecutorConfig(
                controllerConfig=controllerConfig,
                jobId=snapshot.job_id or None,
            ),
        )
        # reconstruct metadata
        metadata = _ExecutorMetadata(
            executor_id=str(row.id),
            executor_name=stored_name,
            executor_type=executor_type,
            executor=executor,
            job_id=snapshot.job_id or None,
            vm_id=(int(snapshot.vm_id) if snapshot.vm_id > 0 else None),
        )
        await self._async_createAppForExecutor(
            executor=executor,
            appId=self._resolveExecutorAppId(metadata),
            params={"job_id": metadata.job_id} if metadata.job_id else {},
        )

        if metadata.job_id:
            await self._async_createAppForExecutor(
                executor=executor,
                appId=self._resolveExecutorAppId(metadata),
                params={"job_id": metadata.job_id},
            )
        self._cacheExecutorMetadata(metadata)
        if metadata.job_id and snapshot.launch_backend:
            self._jobExecutors[metadata.job_id] = metadata.executor_id
            self._jobLaunchBackend[metadata.job_id] = snapshot.launch_backend
        logger.info(
            f"ExecutorControlService load metadata done executor_name={stored_name} "
            f"executor_id={metadata.executor_id}"
        )
        return metadata


@dataclass
class _ExecutorMetadata:
    executor_id: str
    executor_name: str
    executor_type: int
    executor: Executor | None = None
    job_id: Optional[str] = None
    vm_id: int | None = None
