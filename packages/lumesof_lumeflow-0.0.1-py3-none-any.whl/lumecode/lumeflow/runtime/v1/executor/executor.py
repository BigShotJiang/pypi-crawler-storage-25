"""Executor interface definitions."""

from __future__ import annotations

import abc
import uuid
from collections.abc import AsyncIterator
from typing import Any, Mapping

from lumecode.lumeflow.runtime.v1.executor.executor_types_pb2 import JobResult


class Executor(abc.ABC):
    """Abstract base class defining the Executor API.

    Implementations must treat `appId` as a stable key and track each app lifecycle
    independently so a single executor instance can manage multiple apps at once.
    """

    def __init__(self, node_name: str) -> None:
        if not isinstance(node_name, str):
            raise TypeError("node_name must be a string.")
        normalized_name = node_name.strip()
        if not normalized_name:
            raise ValueError("node_name must not be empty.")
        self.node_name = normalized_name

    async def async_createApp(
        self,
        appId: str,
        params: Mapping[str, Any] | None = None,
    ) -> None:
        """Create runtime state for `appId` before image upload/launch."""
        _ = params

    async def async_uploadAppImage(
        self,
        appId: str,
        chunkStream: AsyncIterator[bytes],
        *,
        hashScheme: str = "",
        hashValue: str = "",
    ) -> None:
        """Upload image chunks for the specific app identified by `appId`."""
        _ = appId
        _ = chunkStream
        _ = hashScheme
        _ = hashValue
        raise NotImplementedError("async_uploadAppImage is not implemented.")

    async def async_launchApp(
        self,
        appId: str,
        params: Mapping[str, Any] | None = None,
    ) -> JobResult:
        """Launch the specific app identified by `appId`."""
        _ = appId
        _ = params
        raise NotImplementedError("async_launchApp is not implemented.")

    @abc.abstractmethod
    async def async_getAppStatus(self, appId: str) -> JobResult:
        """Fetch the latest lifecycle status for the specific app `appId`."""
        raise NotImplementedError

    async def async_getStatus(self, appId: str) -> JobResult:
        """Compatibility helper; prefer async_getAppStatus."""
        return await self.async_getAppStatus(appId)

    async def async_tearDownApp(self, appId: str) -> None:
        """Terminate and clean up only the app identified by `appId`."""
        await self.async_killProcess(appId)

    async def async_launch(
        self,
        blob: bytes | bytearray | memoryview,
        params: Mapping[str, Any] | None,
    ) -> JobResult:
        """Compatibility helper that creates/uploads/launches from a byte blob."""
        normalized_blob, normalized_params = self.normalizeLaunchInputs(blob, params)
        appId = self._resolveAppId(normalized_params)
        await self.async_createApp(appId=appId, params=normalized_params)

        async def _async_oneChunk() -> AsyncIterator[bytes]:
            yield normalized_blob

        await self.async_uploadAppImage(
            appId=appId,
            chunkStream=_async_oneChunk(),
        )
        return await self.async_launchApp(appId=appId, params=normalized_params)

    async def async_killProcess(self, job_id: str) -> None:
        """Terminate the process associated with the provided job id."""
        raise NotImplementedError

    @staticmethod
    def normalizeLaunchInputs(
        blob: bytes | bytearray | memoryview,
        params: Mapping[str, Any] | None,
    ) -> tuple[bytes, dict[str, Any]]:
        """Normalize executor inputs for implementations."""
        if not isinstance(blob, (bytes, bytearray, memoryview)):
            raise TypeError("blob must be bytes-like.")
        normalized_blob = bytes(blob)

        if params is None:
            normalized_params: dict[str, Any] = {}
        elif isinstance(params, Mapping):
            normalized_params = {}
            for key, value in params.items():
                if not isinstance(key, str):
                    raise TypeError("params keys must be strings.")
                normalized_params[key] = value
        else:
            raise TypeError("params must be a mapping of string keys to values.")

        return normalized_blob, normalized_params

    @staticmethod
    def _resolveAppId(params: Mapping[str, Any]) -> str:
        candidate = params.get("job_id")
        if isinstance(candidate, str) and candidate:
            return candidate
        return str(uuid.uuid4())
