from __future__ import annotations

import asyncio
from collections import OrderedDict
import hashlib
import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Awaitable, Callable, Optional

from grpclib import GRPCError
from grpclib.const import Status
from grpclib.server import Stream

from lumecode.base.python.logging import lumesof_logging
from lumecode.lumeflow.runtime.v1.flow_server import flow_server_pb2
from lumecode.lumeflow.runtime.v1.opnet import opnet_types_pb2
from lumecode.lumeflow.runtime.v1.opnet.opnet_plugin_interface import OpNetNodePlugin
from lumecode.lumeflow.runtime.v1.rpc_opnet_bridge import rpc_opnet_bridge_grpc
from lumecode.lumeflow.runtime.v1.rpc_opnet_bridge import rpc_opnet_bridge_pb2

logger = logging.getLogger(__name__)
structuredLogger = lumesof_logging.getLogger(__name__)


@dataclass(frozen=True)
class ReplicaRequestContext:
    ingress_link_ref: str
    bridge_trace_id: str
    payload: bytes
    deadline_ts: Optional[object]
    payload_serialization_format: int
    payload_type_url: str


@dataclass(frozen=True)
class ReplicaRequestResult:
    ok: bool
    payload: bytes = b""
    error: str = ""


@dataclass
class _TraceState:
    bridge_trace_id: str
    deadline_ts: Optional[object]
    resolved_result: Optional[ReplicaRequestResult] = None
    has_local_delivery: bool = False
    is_committed: bool = False
    is_acked: bool = False
    message_id: Optional[str] = None
    waiters: list[asyncio.Future[ReplicaRequestResult]] = field(default_factory=list)


class RpcOpnetBridgeEndpointService(rpc_opnet_bridge_grpc.RpcOpnetBridgeEndpointBase):
    def __init__(
        self,
        *,
        flow_server_client: object,
        node_plugin: OpNetNodePlugin,
        local_replica_id: str,
        local_bridge_link_ref: str,
        shard_bridge_link_refs: tuple[str, ...],
        peer_commit_notifier: Optional[Callable[[str], Awaitable[None]]] = None,
        now_fn: Optional[Callable[[], datetime]] = None,
        max_cached_traces: int = 8192,
    ) -> None:
        if max_cached_traces <= 0:
            logger.warning(
                f"RpcOpnetBridgeEndpointService invalid max_cached_traces value={max_cached_traces}"
            )
            raise ValueError("max_cached_traces must be > 0")

        self._flowServerClient = flow_server_client
        self._nodePlugin = node_plugin
        self._localReplicaId = local_replica_id
        self._localBridgeLinkRef = local_bridge_link_ref
        self._shardBridgeLinkRefs = shard_bridge_link_refs
        self._peerCommitNotifier = peer_commit_notifier
        self._nowFn = now_fn or (lambda: datetime.now(timezone.utc))
        self._maxCachedTraces = max_cached_traces

        self._consumerPortName = f"rpc-opnet-bridge-consumer-{local_replica_id}"

        self._stateLock = asyncio.Lock()
        self._consumerReady = False
        self._consumerTask: Optional[asyncio.Task[None]] = None
        self._producerPortsByIngressLink: dict[str, str] = {}
        self._traceStatesById: OrderedDict[str, _TraceState] = OrderedDict()

        self._consumerPortName = f"rpc-opnet-bridge-consumer-{local_replica_id}"

        self._stateLock = asyncio.Lock()
        self._consumerReady = False
        self._consumerTask: Optional[asyncio.Task[None]] = None
        self._producerPortsByIngressLink: dict[str, str] = {}
        self._resolvedByTraceId: dict[str, ReplicaRequestResult] = {}
        self._pendingAckMessageIdsByTraceId: dict[str, str] = {}
        self._committedTraceIds: set[str] = set()
        self._waitersByTraceId: dict[str, list[asyncio.Future[ReplicaRequestResult]]] = {}
        structuredLogger.info(
            "RpcOpnetBridgeEndpointService initialized",
            event="lumeflow.rpc_bridge.endpoint.initialized",
            attrs={
                "replica_id": local_replica_id,
                "local_bridge_link_ref": local_bridge_link_ref,
                "shard_link_count": len(shard_bridge_link_refs),
                "max_cached_traces": max_cached_traces,
            },
        )

    async def Stream(
        self,
        stream: Stream[
            rpc_opnet_bridge_pb2.EndpointEnvelope,
            rpc_opnet_bridge_pb2.ReplicaEnvelope,
        ],
    ) -> None:
        await self.async_stream(stream)

    async def async_stream(
        self,
        stream: Stream[
            rpc_opnet_bridge_pb2.EndpointEnvelope,
            rpc_opnet_bridge_pb2.ReplicaEnvelope,
        ],
    ) -> None:
        ingress_link_ref = ""
        structuredLogger.info(
            "RpcOpnetBridgeEndpointService stream opened",
            event="lumeflow.rpc_bridge.endpoint.stream_opened",
        )
        while True:
            envelope = await stream.recv_message()
            if envelope is None:
                structuredLogger.info(
                    "RpcOpnetBridgeEndpointService stream closed by peer",
                    event="lumeflow.rpc_bridge.endpoint.stream_closed",
                )
                return
            payload_type = envelope.WhichOneof("payload")
            if payload_type is None:
                logger.warning("RpcOpnetBridgeEndpointService stream rejected empty payload envelope")
                raise GRPCError(Status.INVALID_ARGUMENT, "endpoint envelope payload is required")
            if payload_type == "hello":
                ingress_link_ref = await self._async_processHello(envelope.hello)
                continue
            if payload_type == "api_request":
                response = await self._async_processApiRequest(
                    ingress_link_ref=ingress_link_ref,
                    request=envelope.api_request,
                )
                await stream.send_message(response)
                continue
            if payload_type == "fetch_response":
                response = await self._async_processFetchResponse(envelope.fetch_response)
                if response is not None:
                    await stream.send_message(response)
                continue
            if payload_type == "response_ack":
                await self._async_processResponseAck(envelope.response_ack)
                continue
            logger.warning(
                f"RpcOpnetBridgeEndpointService stream rejected payload_type={payload_type}"
            )
            raise GRPCError(Status.INVALID_ARGUMENT, f"unsupported endpoint payload '{payload_type}'")

    async def async_markPeerResponseCommitted(self, *, bridge_trace_id: str) -> None:
        logger.debug(
            f"RpcOpnetBridgeEndpointService peer committed bridge_trace_id={bridge_trace_id}"
        )
        await self._async_markResponseCommitted(
            bridge_trace_id=bridge_trace_id,
            endpoint_id="",
            ack_ts=None,
            notify_peers=False,
        )

    async def async_close(self) -> None:
        logger.info("RpcOpnetBridgeEndpointService close begin")
        async with self._stateLock:
            task = self._consumerTask
            self._consumerTask = None
        if task is not None:
            task.cancel()
            await asyncio.gather(task, return_exceptions=True)
        logger.info("RpcOpnetBridgeEndpointService close done")

    async def _async_processHello(self, hello: rpc_opnet_bridge_pb2.EndpointHello) -> str:
        app_id = hello.app_id.strip()
        if not app_id:
            logger.warning("RpcOpnetBridgeEndpointService hello rejected empty app_id")
            raise GRPCError(Status.INVALID_ARGUMENT, "hello.app_id must be provided")
        structuredLogger.info(
            "RpcOpnetBridgeEndpointService hello received",
            event="lumeflow.rpc_bridge.endpoint.hello.received",
            attrs={"app_id": app_id},
        )
        try:
            lookup = await self._flowServerClient.async_getJobIngressLinkRefByAppId(
                app_id=app_id
            )
        except GRPCError as exc:
            if exc.status in (
                Status.NOT_FOUND,
                Status.FAILED_PRECONDITION,
                Status.UNAVAILABLE,
            ):
                structuredLogger.info(
                    "RpcOpnetBridgeEndpointService hello not ready",
                    event="lumeflow.rpc_bridge.endpoint.hello.not_ready",
                    attrs={
                        "app_id": app_id,
                        "grpc_status": exc.status.name,
                        "details": exc.message,
                    },
                )
                raise GRPCError(
                    Status.UNAVAILABLE,
                    f"Not Ready: app_id='{app_id}' ingress link unavailable",
                ) from exc
            raise
        ingress_link_ref = lookup.bridge_ingress_link_ref.strip()
        if not ingress_link_ref:
            logger.error(
                f"RpcOpnetBridgeEndpointService hello missing ingress link app_id={app_id}"
            )
            raise GRPCError(Status.FAILED_PRECONDITION, "bridge ingress link ref is empty")
        structuredLogger.info(
            "RpcOpnetBridgeEndpointService hello resolved ingress link",
            event="lumeflow.rpc_bridge.endpoint.hello.resolved",
            attrs={
                "app_id": app_id,
                "ingress_link_ref": ingress_link_ref,
            },
        )
        return ingress_link_ref

    async def _async_processApiRequest(
        self,
        *,
        ingress_link_ref: str,
        request: rpc_opnet_bridge_pb2.EndpointApiRequest,
    ) -> rpc_opnet_bridge_pb2.ReplicaEnvelope:
        if not ingress_link_ref:
            logger.warning("RpcOpnetBridgeEndpointService api_request received before hello")
            raise GRPCError(Status.FAILED_PRECONDITION, "hello must be sent before api_request")

        bridge_trace_id = str(uuid.uuid4())
        deadline_ts = request.deadline_ts if request.HasField("deadline_ts") else None

        if deadline_ts is not None and self._isDeadlineExpired(deadline_ts):
            logger.info(
                f"RpcOpnetBridgeEndpointService api_request deadline exceeded "
                f"bridge_trace_id={bridge_trace_id}"
            )
            return self._buildApiResponseEnvelope(
                bridge_trace_id=bridge_trace_id,
                result=ReplicaRequestResult(ok=False, error="deadline exceeded"),
            )

        context = ReplicaRequestContext(
            ingress_link_ref=ingress_link_ref,
            bridge_trace_id=bridge_trace_id,
            payload=request.payload,
            deadline_ts=deadline_ts,
            payload_serialization_format=request.payload_serialization_format,
            payload_type_url=request.payload_type_url,
        )
        structuredLogger.info(
            "RpcOpnetBridgeEndpointService api request received",
            event="lumeflow.rpc_bridge.endpoint.api_request.received",
            attrs={
                "bridge_trace_id": bridge_trace_id,
                "ingress_link_ref": ingress_link_ref,
                "payload_bytes": len(request.payload),
            },
        )
        result = await self._async_handleApiRequest(context)
        structuredLogger.info(
            "RpcOpnetBridgeEndpointService api request resolved",
            event="lumeflow.rpc_bridge.endpoint.api_request.resolved",
            attrs={
                "bridge_trace_id": bridge_trace_id,
                "ingress_link_ref": ingress_link_ref,
                "ok": result.ok,
            },
        )
        return self._buildApiResponseEnvelope(bridge_trace_id=bridge_trace_id, result=result)

    async def _async_processFetchResponse(
        self,
        request: rpc_opnet_bridge_pb2.EndpointFetchResponseRequest,
    ) -> Optional[rpc_opnet_bridge_pb2.ReplicaEnvelope]:
        bridge_trace_id = request.bridge_trace_id.strip()
        if not bridge_trace_id:
            logger.warning("RpcOpnetBridgeEndpointService fetch_response rejected empty bridge_trace_id")
            raise GRPCError(Status.INVALID_ARGUMENT, "fetch_response.bridge_trace_id must be provided")

        result = await self._async_fetchResolvedResponse(bridge_trace_id=bridge_trace_id)
        if result is None:
            logger.debug(
                f"RpcOpnetBridgeEndpointService fetch_response miss bridge_trace_id={bridge_trace_id}"
            )
            return None
        logger.debug(
            f"RpcOpnetBridgeEndpointService fetch_response hit bridge_trace_id={bridge_trace_id}"
        )
        return self._buildApiResponseEnvelope(bridge_trace_id=bridge_trace_id, result=result)

    async def _async_processResponseAck(
        self,
        request: rpc_opnet_bridge_pb2.EndpointResponseAck,
    ) -> None:
        bridge_trace_id = request.bridge_trace_id.strip()
        if not bridge_trace_id:
            logger.warning("RpcOpnetBridgeEndpointService response_ack rejected empty bridge_trace_id")
            raise GRPCError(Status.INVALID_ARGUMENT, "response_ack.bridge_trace_id must be provided")
        structuredLogger.info(
            "RpcOpnetBridgeEndpointService response ack received",
            event="lumeflow.rpc_bridge.endpoint.response_ack.received",
            attrs={"bridge_trace_id": bridge_trace_id},
        )

        await self._async_markResponseCommitted(
            bridge_trace_id=bridge_trace_id,
            endpoint_id=request.endpoint_id.strip(),
            ack_ts=request.ack_ts if request.HasField("ack_ts") else None,
            notify_peers=True,
        )

    async def _async_handleApiRequest(
        self,
        request: ReplicaRequestContext,
    ) -> ReplicaRequestResult:
        state = await self._async_getOrCreateTraceState(
            bridge_trace_id=request.bridge_trace_id,
            deadline_ts=request.deadline_ts,
        )
        if state is None:
            logger.warning(
                f"RpcOpnetBridgeEndpointService trace cache full bridge_trace_id={request.bridge_trace_id}"
            )
            return ReplicaRequestResult(ok=False, error="bridge trace cache is full")

        producer_port_name = await self._async_ensureProducerForIngressLink(request.ingress_link_ref)
        await self._async_ensureConsumer()

        opnet_message = opnet_types_pb2.OpNetMessage()
        opnet_message.message_context.trace_id = request.bridge_trace_id
        opnet_message.message_context.bridge_link_refs.extend(self._shardBridgeLinkRefs)
        if request.deadline_ts is not None:
            opnet_message.message_context.deadline_ts.CopyFrom(request.deadline_ts)
        payload_type_url = request.payload_type_url.strip()
        if payload_type_url:
            serialization_format = request.payload_serialization_format
            if serialization_format <= 0:
                serialization_format = int(opnet_types_pb2.OpNetPayloadType.SerializationFormat.PROTO)
            opnet_message.payload_type.serialization_format = serialization_format
            opnet_message.payload_type.type_url = payload_type_url
        else:
            opnet_message.payload_type.serialization_format = (
                opnet_types_pb2.OpNetPayloadType.SerializationFormat.CUSTOM
            )
            opnet_message.payload_type.type_url = "type://lumecode.rpc_opnet_bridge.payload"
        opnet_message.payload = request.payload

        put_result = await self._nodePlugin.async_putOpNetMessage(
            port_name=producer_port_name,
            work_item=opnet_message,
        )
        if not put_result.ok:
            logger.warning(
                f"RpcOpnetBridgeEndpointService put message failed "
                f"bridge_trace_id={request.bridge_trace_id} message={put_result.message}"
            )
            return ReplicaRequestResult(ok=False, error=put_result.message)

        return await self._async_waitForResponse(
            bridge_trace_id=request.bridge_trace_id,
            deadline_ts=request.deadline_ts,
        )

    async def _async_fetchResolvedResponse(
        self,
        *,
        bridge_trace_id: str,
    ) -> Optional[ReplicaRequestResult]:
        await self._async_ensureConsumer()
        async with self._stateLock:
            state = self._traceStatesById.get(bridge_trace_id)
            if state is None:
                return None
            self._touchTraceStateLocked(bridge_trace_id)
            return state.resolved_result

    async def _async_markResponseCommitted(
        self,
        *,
        bridge_trace_id: str,
        endpoint_id: str,
        ack_ts: Optional[object],
        notify_peers: bool,
    ) -> None:
        del endpoint_id, ack_ts
        cleaned_trace_id = bridge_trace_id.strip()
        if not cleaned_trace_id:
            logger.warning("RpcOpnetBridgeEndpointService mark committed skipped empty bridge_trace_id")
            return

        await self._async_ensureConsumer()

        should_notify = False
        ack_message_id: Optional[str] = None
        async with self._stateLock:
            state = self._traceStatesById.get(cleaned_trace_id)
            if state is None:
                state = await self._async_createTraceStateLocked(cleaned_trace_id, None)
                if state is None:
                    return
            state.is_committed = True
            self._touchTraceStateLocked(cleaned_trace_id)
            ack_message_id = self._computeAckMessageIdLocked(state)
            if notify_peers:
                should_notify = True

        if ack_message_id is not None:
            await self._nodePlugin.async_ack(port_name=self._consumerPortName, message_id=ack_message_id)
            logger.debug(
                f"RpcOpnetBridgeEndpointService acked local message "
                f"bridge_trace_id={cleaned_trace_id} message_id={ack_message_id}"
            )

        if should_notify and self._peerCommitNotifier is not None:
            await self._peerCommitNotifier(cleaned_trace_id)

    async def _async_waitForResponse(
        self,
        *,
        bridge_trace_id: str,
        deadline_ts: Optional[object],
    ) -> ReplicaRequestResult:
        async with self._stateLock:
            state = self._traceStatesById.get(bridge_trace_id)
            if state is None:
                return ReplicaRequestResult(ok=False, error="bridge trace cache is full")
            self._touchTraceStateLocked(bridge_trace_id)
            if state.resolved_result is not None:
                return state.resolved_result
            waiter: asyncio.Future[ReplicaRequestResult] = asyncio.get_running_loop().create_future()
            state.waiters.append(waiter)

        timeout_seconds: Optional[float] = None
        if deadline_ts is not None:
            timeout_seconds = self._deadlineSecondsRemaining(deadline_ts)
            if timeout_seconds <= 0.0:
                await self._async_removeWaiter(bridge_trace_id=bridge_trace_id, waiter=waiter)
                return ReplicaRequestResult(ok=False, error="deadline exceeded")

        try:
            if timeout_seconds is None:
                return await waiter
            return await asyncio.wait_for(waiter, timeout=timeout_seconds)
        except asyncio.TimeoutError:
            await self._async_removeWaiter(bridge_trace_id=bridge_trace_id, waiter=waiter)
            await self._async_markDeadlineExceeded(bridge_trace_id=bridge_trace_id)
            return ReplicaRequestResult(ok=False, error="deadline exceeded")

    async def _async_removeWaiter(
        self,
        *,
        bridge_trace_id: str,
        waiter: asyncio.Future[ReplicaRequestResult],
    ) -> None:
        async with self._stateLock:
            state = self._traceStatesById.get(bridge_trace_id)
            if state is None:
                return
            state.waiters = [w for w in state.waiters if w is not waiter]
            self._touchTraceStateLocked(bridge_trace_id)

    async def _async_markDeadlineExceeded(
        self,
        *,
        bridge_trace_id: str,
    ) -> None:
        async with self._stateLock:
            state = self._traceStatesById.get(bridge_trace_id)
            if state is None or state.resolved_result is not None:
                return
            state.resolved_result = ReplicaRequestResult(ok=False, error="deadline exceeded")
            waiters = list(state.waiters)
            state.waiters.clear()
            self._touchTraceStateLocked(bridge_trace_id)

        for waiter in waiters:
            if not waiter.done():
                waiter.set_result(ReplicaRequestResult(ok=False, error="deadline exceeded"))

    async def _async_ensureProducerForIngressLink(self, ingress_link_ref: str) -> str:
        cleaned_link_ref = ingress_link_ref.strip()
        if not cleaned_link_ref:
            logger.warning("RpcOpnetBridgeEndpointService producer bind rejected empty ingress link ref")
            raise GRPCError(Status.INVALID_ARGUMENT, "ingress link ref must be non-empty")

        async with self._stateLock:
            existing = self._producerPortsByIngressLink.get(cleaned_link_ref)
            if existing is not None:
                return existing

        digest = hashlib.sha256(cleaned_link_ref.encode("utf-8")).hexdigest()[:16]
        port_name = f"rpc-opnet-bridge-ingress-{digest}"
        try:
            add_result, _ = await self._nodePlugin.async_addProducer(
                link_ref=cleaned_link_ref,
                port_name=port_name,
            )
        except ValueError as exc:
            logger.warning(
                f"RpcOpnetBridgeEndpointService invalid ingress link ref format "
                f"ingress_link_ref={cleaned_link_ref} error={exc}"
            )
            raise GRPCError(
                Status.FAILED_PRECONDITION,
                f"invalid ingress_link_ref format: {cleaned_link_ref}",
            ) from exc
        if not add_result.ok:
            logger.error(
                f"RpcOpnetBridgeEndpointService failed to bind ingress producer "
                f"ingress_link_ref={cleaned_link_ref} port_name={port_name} "
                f"message={add_result.message}"
            )
            raise GRPCError(Status.FAILED_PRECONDITION, f"failed to bind ingress producer: {add_result.message}")
        logger.info(
            f"RpcOpnetBridgeEndpointService bound ingress producer "
            f"ingress_link_ref={cleaned_link_ref} port_name={port_name}"
        )

        async with self._stateLock:
            self._producerPortsByIngressLink.setdefault(cleaned_link_ref, port_name)
            return self._producerPortsByIngressLink[cleaned_link_ref]

    async def _async_ensureConsumer(self) -> None:
        async with self._stateLock:
            if self._consumerReady:
                return
            self._consumerReady = True

        try:
            add_result, _ = await self._nodePlugin.async_addConsumer(
                link_ref=self._localBridgeLinkRef,
                port_name=self._consumerPortName,
                max_concurrency=1024,
            )
        except ValueError as exc:
            logger.warning(
                f"RpcOpnetBridgeEndpointService invalid bridge consumer link ref format "
                f"link_ref={self._localBridgeLinkRef} error={exc}"
            )
            raise GRPCError(
                Status.FAILED_PRECONDITION,
                f"invalid bridge consumer link_ref format: {self._localBridgeLinkRef}",
            ) from exc
        if not add_result.ok:
            logger.error(
                f"RpcOpnetBridgeEndpointService failed to bind consumer "
                f"link_ref={self._localBridgeLinkRef} port_name={self._consumerPortName} "
                f"message={add_result.message}"
            )
            raise GRPCError(Status.FAILED_PRECONDITION, f"failed to bind bridge consumer: {add_result.message}")

        async with self._stateLock:
            if self._consumerTask is None:
                self._consumerTask = asyncio.create_task(self._async_runConsumer())
        logger.info(
            f"RpcOpnetBridgeEndpointService consumer ready "
            f"link_ref={self._localBridgeLinkRef} port_name={self._consumerPortName}"
        )

    async def _async_runConsumer(self) -> None:
        logger.info(
            f"RpcOpnetBridgeEndpointService consumer loop started port_name={self._consumerPortName}"
        )
        while True:
            try:
                result, message_id, opnet_message = await self._nodePlugin.async_getOpNetMessage(
                    port_name=self._consumerPortName,
                )
            except asyncio.CancelledError:
                logger.info(
                    f"RpcOpnetBridgeEndpointService consumer loop cancelled "
                    f"port_name={self._consumerPortName}"
                )
                return
            except Exception:
                logger.exception(
                    f"RpcOpnetBridgeEndpointService consumer read failed "
                    f"port_name={self._consumerPortName}"
                )
                await asyncio.sleep(0.05)
                continue

            if not result.ok or message_id is None or opnet_message is None:
                await asyncio.sleep(0.01)
                continue

            bridge_trace_id = opnet_message.message_context.trace_id.strip()
            if not bridge_trace_id:
                await self._nodePlugin.async_ack(port_name=self._consumerPortName, message_id=message_id)
                logger.warning(
                    f"RpcOpnetBridgeEndpointService dropped message without trace_id "
                    f"message_id={message_id}"
                )
                continue

            deadline_ts = opnet_message.message_context.deadline_ts if opnet_message.message_context.HasField("deadline_ts") else None
            if deadline_ts is not None and self._isDeadlineExpired(deadline_ts):
                await self._nodePlugin.async_ack(port_name=self._consumerPortName, message_id=message_id)
                await self._async_resolveTrace(
                    bridge_trace_id=bridge_trace_id,
                    result=ReplicaRequestResult(ok=False, error="deadline exceeded"),
                    message_id=None,
                    deadline_ts=deadline_ts,
                )
                logger.info(
                    f"RpcOpnetBridgeEndpointService consumer deadline exceeded "
                    f"bridge_trace_id={bridge_trace_id}"
                )
                continue

            await self._async_resolveTrace(
                bridge_trace_id=bridge_trace_id,
                result=ReplicaRequestResult(ok=True, payload=opnet_message.payload),
                message_id=message_id,
                deadline_ts=deadline_ts,
            )

    async def _async_resolveTrace(
        self,
        *,
        bridge_trace_id: str,
        result: ReplicaRequestResult,
        message_id: Optional[str],
        deadline_ts: Optional[object],
    ) -> None:
        ack_message_id: Optional[str] = None
        waiters: list[asyncio.Future[ReplicaRequestResult]] = []

        async with self._stateLock:
            state = self._traceStatesById.get(bridge_trace_id)
            if state is None:
                state = await self._async_createTraceStateLocked(bridge_trace_id, deadline_ts)
                if state is None:
                    if message_id is not None:
                        ack_message_id = message_id
                    waiters = []
                else:
                    state.resolved_result = result
                    state.has_local_delivery = message_id is not None
                    state.message_id = message_id
                    waiters = list(state.waiters)
                    state.waiters.clear()
                    self._touchTraceStateLocked(bridge_trace_id)
                    ack_message_id = self._computeAckMessageIdLocked(state)
            else:
                if state.deadline_ts is None and deadline_ts is not None:
                    state.deadline_ts = deadline_ts
                state.resolved_result = result
                state.has_local_delivery = message_id is not None
                state.message_id = message_id
                waiters = list(state.waiters)
                state.waiters.clear()
                self._touchTraceStateLocked(bridge_trace_id)
                ack_message_id = self._computeAckMessageIdLocked(state)

        if ack_message_id is not None:
            await self._nodePlugin.async_ack(port_name=self._consumerPortName, message_id=ack_message_id)
            logger.debug(
                f"RpcOpnetBridgeEndpointService resolve acked message "
                f"bridge_trace_id={bridge_trace_id} message_id={ack_message_id}"
            )

        for waiter in waiters:
            if not waiter.done():
                waiter.set_result(result)

    async def _async_getOrCreateTraceState(
        self,
        *,
        bridge_trace_id: str,
        deadline_ts: Optional[object],
    ) -> Optional[_TraceState]:
        async with self._stateLock:
            existing = self._traceStatesById.get(bridge_trace_id)
            if existing is not None:
                self._touchTraceStateLocked(bridge_trace_id)
                if existing.deadline_ts is None and deadline_ts is not None:
                    existing.deadline_ts = deadline_ts
                return existing
            return await self._async_createTraceStateLocked(bridge_trace_id, deadline_ts)

    async def _async_createTraceStateLocked(
        self,
        bridge_trace_id: str,
        deadline_ts: Optional[object],
    ) -> Optional[_TraceState]:
        if len(self._traceStatesById) >= self._maxCachedTraces:
            self._evictTerminalTraceStatesLocked()
        if len(self._traceStatesById) >= self._maxCachedTraces:
            logger.warning(
                f"RpcOpnetBridgeEndpointService trace cache full max_cached_traces={self._maxCachedTraces}"
            )
            return None

        state = _TraceState(
            bridge_trace_id=bridge_trace_id,
            deadline_ts=deadline_ts,
        )
        self._traceStatesById[bridge_trace_id] = state
        self._touchTraceStateLocked(bridge_trace_id)
        logger.debug(
            f"RpcOpnetBridgeEndpointService trace created bridge_trace_id={bridge_trace_id}"
        )
        return state

    def _evictTerminalTraceStatesLocked(self) -> None:
        while len(self._traceStatesById) >= self._maxCachedTraces:
            evicted_any = False
            for trace_id, state in list(self._traceStatesById.items()):
                if self._isTerminalAndAcked(state):
                    self._traceStatesById.pop(trace_id, None)
                    evicted_any = True
                    break
            if not evicted_any:
                return

    @staticmethod
    def _isTerminalAndAcked(state: _TraceState) -> bool:
        return state.is_acked and state.resolved_result is not None

    def _touchTraceStateLocked(self, bridge_trace_id: str) -> None:
        self._traceStatesById.move_to_end(bridge_trace_id, last=True)

    def _computeAckMessageIdLocked(self, state: _TraceState) -> Optional[str]:
        if not state.has_local_delivery:
            return None
        if not state.is_committed:
            return None
        if state.is_acked:
            return None
        if state.message_id is None:
            return None
        state.is_acked = True
        return state.message_id

    @staticmethod
    def _buildApiResponseEnvelope(
        *,
        bridge_trace_id: str,
        result: ReplicaRequestResult,
    ) -> rpc_opnet_bridge_pb2.ReplicaEnvelope:
        envelope = rpc_opnet_bridge_pb2.ReplicaEnvelope()
        envelope.api_response.bridge_trace_id = bridge_trace_id
        envelope.api_response.ok = result.ok
        envelope.api_response.payload = result.payload
        envelope.api_response.error = result.error
        return envelope

    def _isDeadlineExpired(self, deadline_ts: object) -> bool:
        seconds = getattr(deadline_ts, "seconds", 0)
        nanos = getattr(deadline_ts, "nanos", 0)
        deadline = datetime.fromtimestamp(seconds + nanos / 1_000_000_000, tz=timezone.utc)
        return self._nowFn() >= deadline

    def _deadlineSecondsRemaining(self, deadline_ts: object) -> float:
        seconds = getattr(deadline_ts, "seconds", 0)
        nanos = getattr(deadline_ts, "nanos", 0)
        deadline = datetime.fromtimestamp(seconds + nanos / 1_000_000_000, tz=timezone.utc)
        return (deadline - self._nowFn()).total_seconds()
