from __future__ import annotations

import asyncio
from contextlib import suppress
import random
import time
import uuid
from dataclasses import dataclass
from typing import Any, Awaitable, Callable, Mapping, Optional, Sequence

from google.protobuf import timestamp_pb2
from google.protobuf import struct_pb2
from grpclib.client import Channel

from lumecode.base.python.net.target_parser import NetTarget
from lumecode.lumeflow.runtime.v1.config_query_server import (
    config_query_server_grpc,
    config_query_server_pb2,
)
from lumecode.lumeflow.runtime.v1.rpc_opnet_bridge import (
    rpc_opnet_bridge_grpc,
    rpc_opnet_bridge_pb2,
)


@dataclass(frozen=True)
class RpcOpnetBridgeRequest:
    payload: bytes
    deadline_ts_unix_ms: int = 0
    payload_serialization_format: int = 0
    payload_type_url: str = ""


@dataclass(frozen=True)
class RpcOpnetBridgeResponse:
    ok: bool
    payload: bytes = b""
    error: str = ""


class ReplicaConnectionBroken(Exception):
    """Session-level signal that the active replica connection is broken."""


# Factory signature:
#   int -> shard_id
#   str -> replica_id
# Returns an opened concrete session object for that shard/replica target.
BridgeSessionFactory = Callable[
    [int, str],
    Awaitable[Any],
]


def _normalizeTarget(target: str) -> str:
    if target.startswith("tcp://") or target.startswith("unix:///"):
        return target
    return f"tcp://{target}"


def _buildChannelForTarget(target: str) -> Channel:
    _parsed = NetTarget.parseTarget(_normalizeTarget(target))
    if _parsed.getPath() is not None:
        return Channel(path=_parsed.getPath())
    if _parsed.getPort() is None:
        raise ValueError(f"target must include a port: {target}")
    return Channel(host=_parsed.getHost(), port=_parsed.getPort())


class RpcOpnetBridgeClient:
    """Client-side shard selection wrapper for the OpNet-backed RPC bridge."""

    def __init__(
        self,
        *,
        app_id: str,
        shard_to_replicas: Mapping[int, Sequence[str]],
        session_factory: BridgeSessionFactory,
        endpoint_id: str = "",
        rng: Optional[random.Random] = None,
    ) -> None:
        normalized = self._normalizeShardMap(shard_to_replicas)
        if len(normalized) == 0:
            raise ValueError("shard_to_replicas must contain at least one shard")
        if not app_id.strip():
            raise ValueError("app_id must be provided")
        if session_factory is None:
            raise ValueError("session_factory must be provided")
        self._appId = app_id.strip()
        self._shardToReplicas = normalized
        self._orderedShards = tuple(sorted(normalized))
        self._sessionFactory = session_factory
        self._endpointId = endpoint_id.strip() or str(uuid.uuid4())
        self._rng = rng or random.Random()
        # Design concept: endpoint keeps one active stream/session per shard.
        self._activeReplicaByShard: dict[int, str] = {}
        self._sessionByShard: dict[int, Any] = {}
        self._ackQueueByShard: dict[int, asyncio.Queue[tuple[Any, str]]] = {
            shard_id: asyncio.Queue() for shard_id in self._orderedShards
        }
        self._ackWorkerByShard: dict[int, Optional[asyncio.Task[None]]] = {
            shard_id: None for shard_id in self._orderedShards
        }

    async def async_makeApiCall(
        self,
        request: RpcOpnetBridgeRequest,
    ) -> RpcOpnetBridgeResponse:
        shard_id = self._rng.choice(self._orderedShards)
        bridge_trace_id = str(uuid.uuid4())
        return await self._async_makeSessionApiCall(
            shard_id=shard_id,
            request=request,
            bridge_trace_id=bridge_trace_id,
        )

    @staticmethod
    def _normalizeShardMap(
        shard_to_replicas: Mapping[int, Sequence[str]],
    ) -> dict[int, tuple[str, ...]]:
        # Validate shard keys, drop blank replica ids, and freeze the config snapshot.
        normalized: dict[int, tuple[str, ...]] = {}
        for shard_id, replicas in shard_to_replicas.items():
            if not isinstance(shard_id, int):
                raise ValueError(f"shard id must be int, got {type(shard_id).__name__}")
            cleaned = tuple(replica.strip() for replica in replicas if replica and replica.strip())
            if len(cleaned) == 0:
                raise ValueError(f"shard {shard_id} must define at least one replica")
            normalized[shard_id] = cleaned
        return normalized

    async def _async_makeSessionApiCall(
        self,
        *,
        shard_id: int,
        request: RpcOpnetBridgeRequest,
        bridge_trace_id: str,
    ) -> RpcOpnetBridgeResponse:
        session = await self._async_getOrCreateShardSession(shard_id=shard_id)
        max_attempts = len(self._shardToReplicas[shard_id])
        last_connection_error: Optional[ReplicaConnectionBroken] = None
        for attempt_idx in range(max_attempts):
            if attempt_idx > 0:
                # Rotate through shard replicas on transport breakage.
                session = await self._async_rotateShardSession(shard_id=shard_id)
            try:
                if attempt_idx > 0:
                    recovered = await session.async_fetchResponse(bridge_trace_id=bridge_trace_id)
                    if recovered is not None:
                        self._scheduleResponseAck(
                            shard_id=shard_id,
                            session=session,
                            bridge_trace_id=bridge_trace_id,
                        )
                        return recovered
                response = await session.async_sendApiRequest(request)
                self._scheduleResponseAck(
                    shard_id=shard_id,
                    session=session,
                    bridge_trace_id=bridge_trace_id,
                )
                return response
            except ReplicaConnectionBroken as exc:
                last_connection_error = exc
                continue
        if last_connection_error is not None:
            raise last_connection_error
        raise RuntimeError("bridge replica retry loop exhausted unexpectedly")

    def _scheduleResponseAck(
        self,
        *,
        shard_id: int,
        session: Any,
        bridge_trace_id: str,
    ) -> None:
        if not bridge_trace_id.strip():
            return
        queue = self._ackQueueByShard[shard_id]
        queue.put_nowait((session, bridge_trace_id))
        self._ensureAckWorker(shard_id=shard_id)

    def _ensureAckWorker(self, *, shard_id: int) -> None:
        worker = self._ackWorkerByShard[shard_id]
        if worker is not None and not worker.done():
            return
        self._ackWorkerByShard[shard_id] = asyncio.create_task(
            self._async_processShardAcks(shard_id=shard_id)
        )

    async def _async_processShardAcks(self, *, shard_id: int) -> None:
        queue = self._ackQueueByShard[shard_id]
        try:
            while True:
                try:
                    session, bridge_trace_id = await asyncio.wait_for(queue.get(), timeout=0.2)
                except asyncio.TimeoutError:
                    if queue.empty():
                        return
                    continue
                try:
                    await self._async_sendResponseAckBestEffort(
                        session=session,
                        bridge_trace_id=bridge_trace_id,
                    )
                finally:
                    queue.task_done()
        finally:
            self._ackWorkerByShard[shard_id] = None

    async def _async_sendResponseAckBestEffort(
        self,
        *,
        session: Any,
        bridge_trace_id: str,
    ) -> None:
        try:
            await session.async_sendResponseAck(
                bridge_trace_id=bridge_trace_id,
                endpoint_id=self._endpointId,
            )
        except Exception:
            return

    async def async_close(self) -> None:
        for worker in self._ackWorkerByShard.values():
            if worker is not None and not worker.done():
                worker.cancel()
        for worker in self._ackWorkerByShard.values():
            if worker is not None:
                with suppress(asyncio.CancelledError):
                    await worker
        for session in self._sessionByShard.values():
            with suppress(Exception):
                await session.async_close()
        self._sessionByShard.clear()

    async def _async_getOrCreateShardSession(
        self,
        *,
        shard_id: int,
    ) -> Any:
        existing = self._sessionByShard.get(shard_id)
        if existing is not None:
            return existing
        replica_id = self._rng.choice(self._shardToReplicas[shard_id])
        return await self._async_openShardSession(
            shard_id=shard_id,
            replica_id=replica_id,
        )

    async def _async_rotateShardSession(
        self,
        *,
        shard_id: int,
    ) -> Any:
        replicas = self._shardToReplicas[shard_id]
        current = self._activeReplicaByShard.get(shard_id, "")
        replacement = replicas[0]
        if len(replicas) > 1:
            if current in replicas:
                current_idx = replicas.index(current)
                replacement = replicas[(current_idx + 1) % len(replicas)]
            else:
                replacement = self._rng.choice(replicas)
        old = self._sessionByShard.pop(shard_id, None)
        if old is not None:
            try:
                await old.async_close()
            except Exception:
                pass
        return await self._async_openShardSession(
            shard_id=shard_id,
            replica_id=replacement,
        )

    async def _async_openShardSession(
        self,
        *,
        shard_id: int,
        replica_id: str,
    ) -> Any:
        session = await self._sessionFactory(shard_id, replica_id)
        await session.async_sendHello(
            app_id=self._appId,
            endpoint_id=self._endpointId,
        )
        self._sessionByShard[shard_id] = session
        self._activeReplicaByShard[shard_id] = replica_id
        return session

    @classmethod
    async def async_fromConfigService(
        cls,
        *,
        app_id: str,
        config_service_target: str,
        endpoint_id: str = "",
        rng: Optional[random.Random] = None,
        endpoint_remapper: Optional[Callable[[str], str]] = None,
    ) -> "RpcOpnetBridgeClient":
        channel = _buildChannelForTarget(config_service_target)
        try:
            stub = config_query_server_grpc.ClusterConfigServiceStub(channel)
            response = await stub.GetConfig(
                config_query_server_pb2.GetConfigRequest(key="rpc_bridge.grpc_replicas")
            )
        finally:
            channel.close()

        if not response.HasField("entry"):
            raise ValueError("Config service returned rpc_bridge.grpc_replicas without an entry payload.")
        replicaRecords = cls._parseReplicaConfigValue(response.entry.value)
        return cls._buildClientFromReplicaRecords(
            app_id=app_id,
            replica_records=replicaRecords,
            endpoint_id=endpoint_id,
            rng=rng,
            endpoint_remapper=endpoint_remapper,
        )

    @classmethod
    def _buildClientFromReplicaRecords(
        cls,
        *,
        app_id: str,
        replica_records: Sequence[tuple[str, int, str]],
        endpoint_id: str,
        rng: Optional[random.Random],
        endpoint_remapper: Optional[Callable[[str], str]],
    ) -> "RpcOpnetBridgeClient":
        shard_to_replicas: dict[int, list[str]] = {}
        endpoint_by_replica: dict[str, str] = {}
        for replicaId, shardId, endpointAddress in replica_records:
            shard_to_replicas.setdefault(shardId, []).append(replicaId)
            addr = endpoint_remapper(endpointAddress) if endpoint_remapper else endpointAddress
            endpoint_by_replica[replicaId] = addr

        async def _async_sessionFactory(shard_id: int, replica_id: str) -> "_RpcBridgeSession":
            del shard_id
            return _RpcBridgeSession(target=endpoint_by_replica[replica_id])

        return cls(
            app_id=app_id,
            shard_to_replicas=shard_to_replicas,
            session_factory=_async_sessionFactory,
            endpoint_id=endpoint_id,
            rng=rng,
        )

    @staticmethod
    def _parseReplicaConfigValue(
        value: struct_pb2.Value,
    ) -> list[tuple[str, int, str]]:
        if value.WhichOneof("kind") != "list_value":
            raise ValueError("rpc_bridge.grpc_replicas must be a list value.")

        replicaRecords: list[tuple[str, int, str]] = []
        for index, item in enumerate(value.list_value.values):
            if item.WhichOneof("kind") != "struct_value":
                raise ValueError(f"rpc_bridge.grpc_replicas[{index}] must be an object value.")
            fields = item.struct_value.fields
            replicaId = RpcOpnetBridgeClient._requireStringValueField(
                fields=fields,
                field_name="replica_id",
                index=index,
            )
            endpointAddress = RpcOpnetBridgeClient._requireStringValueField(
                fields=fields,
                field_name="endpoint_address",
                index=index,
            )
            shardIndexValue = fields.get("shard_index")
            if shardIndexValue is None or shardIndexValue.WhichOneof("kind") != "number_value":
                raise ValueError(
                    f"rpc_bridge.grpc_replicas[{index}].shard_index must be a numeric value."
                )
            shardIndexNumber = shardIndexValue.number_value
            if not float(shardIndexNumber).is_integer():
                raise ValueError(
                    f"rpc_bridge.grpc_replicas[{index}].shard_index must be an integer."
                )
            replicaRecords.append((replicaId, int(shardIndexNumber), endpointAddress))
        return replicaRecords

    @staticmethod
    def _requireStringValueField(
        *,
        fields: Mapping[str, struct_pb2.Value],
        field_name: str,
        index: int,
    ) -> str:
        fieldValue = fields.get(field_name)
        if fieldValue is None or fieldValue.WhichOneof("kind") != "string_value":
            raise ValueError(
                f"rpc_bridge.grpc_replicas[{index}].{field_name} must be a string."
            )
        rawValue = fieldValue.string_value.strip()
        if not rawValue:
            raise ValueError(
                f"rpc_bridge.grpc_replicas[{index}].{field_name} must be non-empty."
            )
        return rawValue


class _RpcBridgeSession:
    """gRPC session for a single bridge replica endpoint."""

    def __init__(self, *, target: str) -> None:
        self._target = target
        self._channel = _buildChannelForTarget(target)
        self._stub = rpc_opnet_bridge_grpc.RpcOpnetBridgeEndpointStub(self._channel)
        self._appId = ""
        self._endpointId = ""
        self._defaultApiResponseTimeoutSeconds = 10.0
        self._minApiResponseTimeoutSeconds = 1.0
        self._maxApiResponseTimeoutSeconds = 300.0

    async def async_sendHello(self, *, app_id: str, endpoint_id: str) -> None:
        self._appId = app_id
        self._endpointId = endpoint_id

    async def _async_openStreamWithHello(self):
        if not self._appId:
            raise RuntimeError("Bridge session missing app_id; async_sendHello must be called first.")
        streamContext = self._stub.Stream.open()
        stream = await streamContext.__aenter__()
        hello = rpc_opnet_bridge_pb2.EndpointEnvelope()
        hello.hello.app_id = self._appId
        hello.hello.endpoint_id = self._endpointId
        await stream.send_message(hello)
        return streamContext, stream

    async def async_sendApiRequest(
        self,
        request: RpcOpnetBridgeRequest,
    ) -> Any:
        streamContext = None
        try:
            streamContext, stream = await self._async_openStreamWithHello()
            envelope = rpc_opnet_bridge_pb2.EndpointEnvelope()
            envelope.api_request.payload = request.payload
            if request.deadline_ts_unix_ms > 0:
                deadline_ts = timestamp_pb2.Timestamp()
                deadline_ts.FromMilliseconds(request.deadline_ts_unix_ms)
                envelope.api_request.deadline_ts.CopyFrom(deadline_ts)
            if request.payload_serialization_format > 0:
                envelope.api_request.payload_serialization_format = request.payload_serialization_format
            if request.payload_type_url.strip():
                envelope.api_request.payload_type_url = request.payload_type_url.strip()
            await stream.send_message(envelope, end=True)
            response = await asyncio.wait_for(
                stream.recv_message(),
                timeout=self._resolveApiResponseTimeoutSeconds(request=request),
            )
            if response is None or not response.HasField("api_response"):
                raise ReplicaConnectionBroken("Bridge stream closed without api_response.")
            return response.api_response
        except (OSError, ConnectionError, asyncio.TimeoutError) as exc:
            raise ReplicaConnectionBroken(
                f"Bridge request failed for target={self._target}"
            ) from exc
        finally:
            if streamContext is not None:
                await streamContext.__aexit__(None, None, None)

    def _resolveApiResponseTimeoutSeconds(self, *, request: RpcOpnetBridgeRequest) -> float:
        deadline_ms = request.deadline_ts_unix_ms
        if deadline_ms <= 0:
            return self._defaultApiResponseTimeoutSeconds
        remaining_ms = deadline_ms - int(time.time() * 1000)
        if remaining_ms <= 0:
            return self._minApiResponseTimeoutSeconds
        remaining_seconds = remaining_ms / 1000.0
        if remaining_seconds < self._minApiResponseTimeoutSeconds:
            return self._minApiResponseTimeoutSeconds
        if remaining_seconds > self._maxApiResponseTimeoutSeconds:
            return self._maxApiResponseTimeoutSeconds
        return remaining_seconds

    async def async_fetchResponse(self, *, bridge_trace_id: str) -> Any:
        streamContext = None
        try:
            streamContext, stream = await self._async_openStreamWithHello()
            fetch = rpc_opnet_bridge_pb2.EndpointEnvelope()
            fetch.fetch_response.bridge_trace_id = bridge_trace_id
            await stream.send_message(fetch, end=True)
            response = await asyncio.wait_for(stream.recv_message(), timeout=2.0)
            if response is None or not response.HasField("api_response"):
                return None
            api_response = response.api_response
            return rpc_opnet_bridge_pb2.ReplicaApiResponse(
                ok=api_response.ok,
                payload=api_response.payload,
                error=api_response.error,
                bridge_trace_id=api_response.bridge_trace_id,
            )
        except asyncio.TimeoutError:
            return None
        except (OSError, ConnectionError) as exc:
            raise ReplicaConnectionBroken(f"Bridge fetch failed for target={self._target}") from exc
        finally:
            if streamContext is not None:
                await streamContext.__aexit__(None, None, None)

    async def async_sendResponseAck(self, *, bridge_trace_id: str, endpoint_id: str) -> None:
        streamContext = None
        try:
            streamContext, stream = await self._async_openStreamWithHello()
            ack = rpc_opnet_bridge_pb2.EndpointEnvelope()
            ack.response_ack.bridge_trace_id = bridge_trace_id
            ack.response_ack.endpoint_id = endpoint_id
            await stream.send_message(ack, end=True)
        finally:
            if streamContext is not None:
                await streamContext.__aexit__(None, None, None)

    async def async_close(self) -> None:
        self._channel.close()
