from __future__ import annotations

import asyncio
from dataclasses import dataclass
import logging
from typing import Awaitable, Callable, Optional

from grpclib import GRPCError
from grpclib.const import Status
from grpclib.server import Stream

from lumecode.base.python.logging import lumesof_logging
from lumecode.lumeflow.runtime.v1.rpc_opnet_bridge import rpc_opnet_bridge_grpc
from lumecode.lumeflow.runtime.v1.rpc_opnet_bridge import rpc_opnet_bridge_pb2

logger = logging.getLogger(__name__)
structuredLogger = lumesof_logging.getLogger(__name__)


@dataclass
class _PeerStreamState:
    shard_id: str
    replica_id: str
    stream: Stream[rpc_opnet_bridge_pb2.PeerEnvelope, rpc_opnet_bridge_pb2.PeerEnvelope]


class RpcOpnetBridgePeerService(rpc_opnet_bridge_grpc.RpcOpnetBridgePeerServiceBase):
    def __init__(
        self,
        *,
        response_committed_handler: Optional[Callable[[str], Awaitable[None]]] = None,
    ) -> None:
        self._lock = asyncio.Lock()
        self._streams_by_shard: dict[str, dict[str, _PeerStreamState]] = {}
        self._responseCommittedHandler = response_committed_handler
        structuredLogger.info(
            "RpcOpnetBridgePeerService initialized",
            event="lumeflow.rpc_bridge.peer.initialized",
        )

    def setResponseCommittedHandler(
        self,
        response_committed_handler: Callable[[str], Awaitable[None]],
    ) -> None:
        self._responseCommittedHandler = response_committed_handler
        structuredLogger.info(
            "RpcOpnetBridgePeerService response committed handler set",
            event="lumeflow.rpc_bridge.peer.handler_set",
        )

    async def Exchange(
        self,
        stream: Stream[
            rpc_opnet_bridge_pb2.PeerEnvelope,
            rpc_opnet_bridge_pb2.PeerEnvelope,
        ],
    ) -> None:
        await self.async_exchange(stream)

    async def async_exchange(
        self,
        stream: Stream[
            rpc_opnet_bridge_pb2.PeerEnvelope,
            rpc_opnet_bridge_pb2.PeerEnvelope,
        ],
    ) -> None:
        structuredLogger.info(
            "RpcOpnetBridgePeerService exchange stream opened",
            event="lumeflow.rpc_bridge.peer.stream_opened",
        )
        first = await stream.recv_message()
        if first is None:
            logger.info("RpcOpnetBridgePeerService exchange stream closed before ready")
            return
        if first.WhichOneof("payload") != "ready":
            logger.warning("RpcOpnetBridgePeerService rejected stream missing initial ready payload")
            raise GRPCError(Status.INVALID_ARGUMENT, "first peer message must be ready")
        shard_id = first.ready.shard_id.strip()
        replica_id = first.ready.replica_id.strip()
        if not shard_id or not replica_id:
            logger.warning("RpcOpnetBridgePeerService rejected ready payload missing shard_id/replica_id")
            raise GRPCError(Status.INVALID_ARGUMENT, "ready.shard_id and ready.replica_id must be provided")

        state = _PeerStreamState(
            shard_id=shard_id,
            replica_id=replica_id,
            stream=stream,
        )
        await self._async_registerPeer(state)
        structuredLogger.info(
            "RpcOpnetBridgePeerService peer registered",
            event="lumeflow.rpc_bridge.peer.registered",
            attrs={
                "shard_id": shard_id,
                "replica_id": replica_id,
            },
        )
        try:
            while True:
                envelope = await stream.recv_message()
                if envelope is None:
                    structuredLogger.info(
                        "RpcOpnetBridgePeerService peer stream closed",
                        event="lumeflow.rpc_bridge.peer.stream_closed",
                        attrs={
                            "shard_id": shard_id,
                            "replica_id": replica_id,
                        },
                    )
                    return
                payload_type = envelope.WhichOneof("payload")
                if payload_type == "response_committed":
                    await self._async_broadcastResponseCommitted(
                        sender=state,
                        bridge_trace_id=envelope.response_committed.bridge_trace_id,
                    )
                elif payload_type == "heartbeat":
                    continue
                elif payload_type == "ready":
                    continue
                else:
                    logger.warning(
                        f"RpcOpnetBridgePeerService rejected peer payload "
                        f"shard_id={shard_id} replica_id={replica_id} payload_type={payload_type}"
                    )
                    raise GRPCError(Status.INVALID_ARGUMENT, f"unsupported peer payload '{payload_type}'")
        finally:
            await self._async_unregisterPeer(state)
            structuredLogger.info(
                "RpcOpnetBridgePeerService peer unregistered",
                event="lumeflow.rpc_bridge.peer.unregistered",
                attrs={
                    "shard_id": shard_id,
                    "replica_id": replica_id,
                },
            )

    async def _async_registerPeer(self, state: _PeerStreamState) -> None:
        async with self._lock:
            shard_peers = self._streams_by_shard.setdefault(state.shard_id, {})
            shard_peers[state.replica_id] = state
            logger.debug(
                f"RpcOpnetBridgePeerService register shard_id={state.shard_id} "
                f"replica_id={state.replica_id} shard_peer_count={len(shard_peers)}"
            )

    async def _async_unregisterPeer(self, state: _PeerStreamState) -> None:
        async with self._lock:
            shard_peers = self._streams_by_shard.get(state.shard_id)
            if shard_peers is None:
                return
            shard_peers.pop(state.replica_id, None)
            if len(shard_peers) == 0:
                self._streams_by_shard.pop(state.shard_id, None)
            logger.debug(
                f"RpcOpnetBridgePeerService unregister shard_id={state.shard_id} "
                f"replica_id={state.replica_id} remaining_shard_peers={len(shard_peers)}"
            )

    async def async_broadcastResponseCommitted(self, bridge_trace_id: str) -> None:
        cleaned_bridge_trace_id = bridge_trace_id.strip()
        if not cleaned_bridge_trace_id:
            logger.warning("RpcOpnetBridgePeerService broadcast skipped empty bridge_trace_id")
            return
        async with self._lock:
            recipients = [
                peer
                for shard_peers in self._streams_by_shard.values()
                for peer in shard_peers.values()
            ]
        if len(recipients) == 0:
            logger.debug(
                f"RpcOpnetBridgePeerService broadcast no recipients bridge_trace_id={cleaned_bridge_trace_id}"
            )
            return
        envelope = rpc_opnet_bridge_pb2.PeerEnvelope()
        envelope.response_committed.bridge_trace_id = cleaned_bridge_trace_id
        delivered = 0
        for peer in recipients:
            try:
                await peer.stream.send_message(envelope)
                delivered += 1
            except Exception:
                logger.exception(
                    f"RpcOpnetBridgePeerService broadcast send failed "
                    f"shard_id={peer.shard_id} replica_id={peer.replica_id}"
                )
                continue
        structuredLogger.info(
            "RpcOpnetBridgePeerService broadcast committed",
            event="lumeflow.rpc_bridge.peer.broadcast_committed",
            attrs={
                "bridge_trace_id": cleaned_bridge_trace_id,
                "recipient_count": len(recipients),
                "delivered_count": delivered,
            },
        )

    async def _async_broadcastResponseCommitted(
        self,
        *,
        sender: _PeerStreamState,
        bridge_trace_id: str,
    ) -> None:
        cleaned_bridge_trace_id = bridge_trace_id.strip()
        if not cleaned_bridge_trace_id:
            logger.warning(
                f"RpcOpnetBridgePeerService relay skipped empty bridge_trace_id sender={sender.replica_id}"
            )
            return
        if self._responseCommittedHandler is not None:
            await self._responseCommittedHandler(cleaned_bridge_trace_id)
        async with self._lock:
            shard_peers = self._streams_by_shard.get(sender.shard_id, {})
            recipients = [
                peer
                for replica_id, peer in shard_peers.items()
                if replica_id != sender.replica_id
            ]
        if len(recipients) == 0:
            logger.debug(
                f"RpcOpnetBridgePeerService relay no recipients shard_id={sender.shard_id} "
                f"sender={sender.replica_id} bridge_trace_id={cleaned_bridge_trace_id}"
            )
            return
        envelope = rpc_opnet_bridge_pb2.PeerEnvelope()
        envelope.response_committed.bridge_trace_id = cleaned_bridge_trace_id
        envelope.response_committed.committed_by_replica_id = sender.replica_id
        delivered = 0
        for peer in recipients:
            try:
                await peer.stream.send_message(envelope)
                delivered += 1
            except Exception:
                logger.exception(
                    f"RpcOpnetBridgePeerService relay send failed "
                    f"shard_id={peer.shard_id} replica_id={peer.replica_id}"
                )
                continue
        structuredLogger.info(
            "RpcOpnetBridgePeerService relayed committed trace",
            event="lumeflow.rpc_bridge.peer.relayed_committed",
            attrs={
                "bridge_trace_id": cleaned_bridge_trace_id,
                "shard_id": sender.shard_id,
                "replica_id": sender.replica_id,
                "recipient_count": len(recipients),
                "delivered_count": delivered,
            },
        )
