from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Sequence

from lumecode.base.python.net.target_parser import NetTarget
from lumecode.lumeflow.runtime.v1.opnet.opnet_plugin_interface import OpNetNodePlugin


@dataclass(frozen=True)
class RpcOpNetBridgeReplicaConfig:
    replica_id: str
    network_address: str


class RpcOpNetBridgeRuntimeContext:
    def __init__(
        self,
        *,
        shard_id: str,
        replica_id: str,
        node_plugin: OpNetNodePlugin,
        replica_map_by_shard: Mapping[str, Sequence[RpcOpNetBridgeReplicaConfig]],
        replica_to_link_ref_map: Mapping[str, str],
    ) -> None:
        self._shardId = shard_id
        self._replicaId = replica_id
        self._nodePlugin = node_plugin
        self._replicaMapByShard = self._normalizeReplicaMap(replica_map_by_shard)
        self._replicaToLinkRef = self._normalizeReplicaLinkMap(replica_to_link_ref_map)
        self._localReplicaConfig = self._resolveLocalReplica()

    @property
    def shard_id(self) -> str:
        return self._shardId

    @property
    def replica_id(self) -> str:
        return self._replicaId

    @property
    def node_plugin(self) -> OpNetNodePlugin:
        return self._nodePlugin

    @property
    def local_replica_config(self) -> RpcOpNetBridgeReplicaConfig:
        return self._localReplicaConfig

    def getReplicaConfigsForShard(self, *, shard_id: str | None = None) -> tuple[RpcOpNetBridgeReplicaConfig, ...]:
        target_shard = (shard_id or self._shardId).strip()
        replicas = self._replicaMapByShard.get(target_shard)
        if replicas is None:
            raise ValueError(f"replica map missing shard '{target_shard}'")
        return replicas

    def getLinkRefForReplica(self, *, replica_id: str) -> str:
        cleaned_replica_id = replica_id.strip()
        link_ref = self._replicaToLinkRef.get(cleaned_replica_id, "").strip()
        if not link_ref:
            raise ValueError(f"bridge link ref missing for replica '{cleaned_replica_id}'")
        return link_ref

    def getLinkRefMapForShard(self, *, shard_id: str | None = None) -> dict[str, str]:
        refs: dict[str, str] = {}
        for replica in self.getReplicaConfigsForShard(shard_id=shard_id):
            refs[replica.replica_id] = self.getLinkRefForReplica(replica_id=replica.replica_id)
        return refs

    def getOrderedLinkRefsForShard(self, *, shard_id: str | None = None) -> tuple[str, ...]:
        refs = self.getLinkRefMapForShard(shard_id=shard_id)
        return tuple(refs[replica_id] for replica_id in sorted(refs.keys()))

    @staticmethod
    def _normalizeReplicaMap(
        replica_map_by_shard: Mapping[str, Sequence[RpcOpNetBridgeReplicaConfig]],
    ) -> dict[str, tuple[RpcOpNetBridgeReplicaConfig, ...]]:
        normalized: dict[str, tuple[RpcOpNetBridgeReplicaConfig, ...]] = {}
        for shard_id, replicas in replica_map_by_shard.items():
            cleaned_shard_id = shard_id.strip()
            if not cleaned_shard_id:
                raise ValueError("shard id must be non-empty")
            cleaned_replicas: list[RpcOpNetBridgeReplicaConfig] = []
            seen_replica_ids: set[str] = set()
            for replica in replicas:
                cleaned_replica_id = replica.replica_id.strip()
                if not cleaned_replica_id:
                    raise ValueError(f"replica id must be non-empty for shard '{cleaned_shard_id}'")
                if cleaned_replica_id in seen_replica_ids:
                    raise ValueError(
                        f"replica id '{cleaned_replica_id}' is duplicated for shard '{cleaned_shard_id}'"
                    )
                cleaned_network_address = replica.network_address.strip()
                if not cleaned_network_address:
                    raise ValueError(
                        f"network address must be non-empty for replica '{cleaned_replica_id}'"
                    )
                NetTarget.parseTarget(cleaned_network_address)
                cleaned_replicas.append(
                    RpcOpNetBridgeReplicaConfig(
                        replica_id=cleaned_replica_id,
                        network_address=cleaned_network_address,
                    )
                )
                seen_replica_ids.add(cleaned_replica_id)
            if len(cleaned_replicas) == 0:
                raise ValueError(f"shard '{cleaned_shard_id}' must include at least one replica")
            normalized[cleaned_shard_id] = tuple(cleaned_replicas)
        return normalized

    @staticmethod
    def _normalizeReplicaLinkMap(replica_to_link_ref_map: Mapping[str, str]) -> dict[str, str]:
        normalized: dict[str, str] = {}
        for replica_id, link_ref in replica_to_link_ref_map.items():
            cleaned_replica_id = replica_id.strip()
            cleaned_link_ref = link_ref.strip()
            if not cleaned_replica_id:
                raise ValueError("replica_to_link_ref_map contains empty replica id")
            if not cleaned_link_ref:
                raise ValueError(f"replica_to_link_ref_map missing link ref for replica '{cleaned_replica_id}'")
            normalized[cleaned_replica_id] = cleaned_link_ref
        return normalized

    def _resolveLocalReplica(self) -> RpcOpNetBridgeReplicaConfig:
        shard_replicas = self._replicaMapByShard.get(self._shardId)
        if shard_replicas is None:
            raise ValueError(f"replica map missing shard '{self._shardId}'")
        for replica in shard_replicas:
            if replica.replica_id == self._replicaId:
                if replica.replica_id not in self._replicaToLinkRef:
                    raise ValueError(f"bridge link ref missing for local replica '{self._replicaId}'")
                return replica
        raise ValueError(f"replica map missing local replica '{self._replicaId}' in shard '{self._shardId}'")
