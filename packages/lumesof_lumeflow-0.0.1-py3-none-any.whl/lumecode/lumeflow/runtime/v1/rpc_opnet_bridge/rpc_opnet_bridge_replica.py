from __future__ import annotations

import asyncio
import random
from typing import Any, Callable, Optional, Sequence

from grpclib.client import Channel
from grpclib.server import Server

from lumecode.base.python.net.target_parser import NetTarget
from lumecode.lumeflow.runtime.v1.rpc_opnet_bridge import rpc_opnet_bridge_grpc
from lumecode.lumeflow.runtime.v1.rpc_opnet_bridge import rpc_opnet_bridge_pb2
from lumecode.lumeflow.runtime.v1.rpc_opnet_bridge.rpc_opnet_bridge_endpoint_service import (
    RpcOpnetBridgeEndpointService,
)
from lumecode.lumeflow.runtime.v1.rpc_opnet_bridge.rpc_opnet_bridge_peer import RpcOpnetBridgePeerService
from lumecode.lumeflow.runtime.v1.rpc_opnet_bridge.rpc_opnet_bridge_runtime_context import (
    RpcOpNetBridgeReplicaConfig,
    RpcOpNetBridgeRuntimeContext,
)


class _GrpcPeerConnection:
    def __init__(
        self,
        *,
        shard_id: str,
        local_replica_id: str,
        peer: RpcOpNetBridgeReplicaConfig,
    ) -> None:
        self._shardId = shard_id
        self._localReplicaId = local_replica_id
        self._peer = peer
        self._channel: Optional[Channel] = None

    async def async_run(self) -> None:
        peerTarget = NetTarget.parseTarget(self._peer.network_address)
        peerUdsPath = peerTarget.getPath()
        if peerUdsPath is not None:
            channel = Channel(path=peerUdsPath)
        else:
            peerHost = peerTarget.getHost()
            peerPort = peerTarget.getPort()
            if peerHost is None or peerPort is None:
                raise RuntimeError("peer target must include host and port.")
            channel = Channel(host=peerHost, port=peerPort)
        self._channel = channel
        stub = rpc_opnet_bridge_grpc.RpcOpnetBridgePeerServiceStub(channel)
        async with stub.Exchange.open() as stream:
            ready = rpc_opnet_bridge_pb2.PeerEnvelope()
            ready.ready.shard_id = self._shardId
            ready.ready.replica_id = self._localReplicaId
            await stream.send_message(ready)
            while True:
                envelope = await stream.recv_message()
                if envelope is None:
                    return

    async def async_close(self) -> None:
        if self._channel is None:
            return
        self._channel.close()
        self._channel = None


PeerConnectionFactory = Callable[
    [str, str, RpcOpNetBridgeReplicaConfig],
    Any,
]


class RpcOpNetBridgeReplica:
    def __init__(
        self,
        *,
        runtime_context: RpcOpNetBridgeRuntimeContext,
        flow_server_client: object,
        endpoint_listen_address: Optional[str] = None,
        peer_listen_address: Optional[str] = None,
        peer_reconnect_initial_delay_sec: float = 0.5,
        peer_reconnect_max_delay_sec: float = 10.0,
        peer_reconnect_backoff_multiplier: float = 2.0,
        peer_reconnect_jitter_ratio: float = 0.2,
        peer_connection_factory: Optional[PeerConnectionFactory] = None,
        server_factory: Optional[Callable[[Sequence[object]], Any]] = None,
    ) -> None:
        self._runtimeContext = runtime_context
        self._shardId = runtime_context.shard_id
        self._replicaId = runtime_context.replica_id
        self._peerReconnectInitialDelaySec = peer_reconnect_initial_delay_sec
        self._peerReconnectMaxDelaySec = peer_reconnect_max_delay_sec
        self._peerReconnectBackoffMultiplier = peer_reconnect_backoff_multiplier
        self._peerReconnectJitterRatio = peer_reconnect_jitter_ratio
        if self._peerReconnectInitialDelaySec <= 0:
            raise ValueError("peer_reconnect_initial_delay_sec must be > 0")
        if self._peerReconnectMaxDelaySec < self._peerReconnectInitialDelaySec:
            raise ValueError("peer_reconnect_max_delay_sec must be >= initial delay")
        if self._peerReconnectBackoffMultiplier < 1.0:
            raise ValueError("peer_reconnect_backoff_multiplier must be >= 1.0")
        if self._peerReconnectJitterRatio < 0.0:
            raise ValueError("peer_reconnect_jitter_ratio must be >= 0.0")
        self._localReplicaConfig = runtime_context.local_replica_config
        self._endpointListenAddress = (
            endpoint_listen_address.strip()
            if endpoint_listen_address and endpoint_listen_address.strip()
            else self._localReplicaConfig.network_address
        )
        self._peerListenAddress = (
            peer_listen_address.strip()
            if peer_listen_address and peer_listen_address.strip()
            else self._localReplicaConfig.network_address
        )
        NetTarget.parseTarget(self._endpointListenAddress)
        NetTarget.parseTarget(self._peerListenAddress)
        self._rng = random.Random()

        self._peerService = RpcOpnetBridgePeerService()
        self._endpointService = RpcOpnetBridgeEndpointService(
            flow_server_client=flow_server_client,
            node_plugin=runtime_context.node_plugin,
            local_replica_id=self._replicaId,
            local_bridge_link_ref=runtime_context.getLinkRefForReplica(replica_id=self._replicaId),
            shard_bridge_link_refs=runtime_context.getOrderedLinkRefsForShard(shard_id=self._shardId),
            peer_commit_notifier=self._peerService.async_broadcastResponseCommitted,
        )
        self._peerService.setResponseCommittedHandler(self._async_markPeerResponseCommitted)
        self._serverFactory = server_factory or Server
        self._combinedServer: Optional[Server] = None
        self._endpointServer: Optional[Server] = None
        self._peerServer: Optional[Server] = None
        if self._endpointListenAddress == self._peerListenAddress:
            services = [self._endpointService, self._peerService]
            self._combinedServer = self._serverFactory(services)
        else:
            self._endpointServer = self._serverFactory([self._endpointService])
            self._peerServer = self._serverFactory([self._peerService])
        self._peerConnectionFactory = peer_connection_factory or self._createPeerConnection
        self._peerTasks: list[asyncio.Task[None]] = []
        self._started = False
        self._closing = False

    def _createPeerConnection(
        self,
        shard_id: str,
        local_replica_id: str,
        peer: RpcOpNetBridgeReplicaConfig,
    ) -> _GrpcPeerConnection:
        return _GrpcPeerConnection(
            shard_id=shard_id,
            local_replica_id=local_replica_id,
            peer=peer,
        )

    async def async_start(self) -> None:
        if self._started:
            return
        self._started = True
        if self._combinedServer is not None:
            await self._async_startServer(self._combinedServer, self._endpointListenAddress)
        else:
            if self._endpointServer is not None:
                await self._async_startServer(self._endpointServer, self._endpointListenAddress)
            if self._peerServer is not None:
                await self._async_startServer(self._peerServer, self._peerListenAddress)
        self._startPeerDialers()

    async def _async_startServer(self, server: Server, listen_address: str) -> None:
        bindTarget = NetTarget.parseTarget(listen_address).withUdsMode(0o666)
        await bindTarget.async_bindGrpclibServer(server)

    def _computeBackoffDelaySec(self, delay_sec: float) -> float:
        if self._peerReconnectJitterRatio == 0.0:
            return delay_sec
        jitter = delay_sec * self._peerReconnectJitterRatio
        return max(0.0, delay_sec + self._rng.uniform(-jitter, jitter))

    def _startPeerDialers(self) -> None:
        shard_replicas = self._runtimeContext.getReplicaConfigsForShard(shard_id=self._shardId)
        for peer in shard_replicas:
            if peer.replica_id == self._replicaId:
                continue
            # One directed stream per pair: lexicographically larger replica id dials.
            if self._replicaId > peer.replica_id:
                task = asyncio.create_task(self._async_runPeerDialer(peer))
                self._peerTasks.append(task)

    async def _async_runPeerDialer(self, peer: RpcOpNetBridgeReplicaConfig) -> None:
        current_delay = self._peerReconnectInitialDelaySec
        while not self._closing:
            connection = self._peerConnectionFactory(self._shardId, self._replicaId, peer)
            try:
                await connection.async_run()
            except asyncio.CancelledError:
                await connection.async_close()
                raise
            except Exception:
                await connection.async_close()
                if self._closing:
                    return
                await asyncio.sleep(self._computeBackoffDelaySec(current_delay))
                current_delay = min(
                    self._peerReconnectMaxDelaySec,
                    current_delay * self._peerReconnectBackoffMultiplier,
                )
            else:
                await connection.async_close()
                if self._closing:
                    return
                current_delay = self._peerReconnectInitialDelaySec
                await asyncio.sleep(self._computeBackoffDelaySec(current_delay))

    async def async_close(self) -> None:
        if self._closing:
            return
        self._closing = True
        for task in self._peerTasks:
            task.cancel()
        if self._peerTasks:
            await asyncio.gather(*self._peerTasks, return_exceptions=True)
        self._peerTasks.clear()
        await self._endpointService.async_close()
        servers = tuple(
            server
            for server in (self._combinedServer, self._endpointServer, self._peerServer)
            if server is not None
        )
        for server in servers:
            server.close()
        for server in servers:
            await server.wait_closed()

    async def _async_markPeerResponseCommitted(self, bridge_trace_id: str) -> None:
        await self._endpointService.async_markPeerResponseCommitted(
            bridge_trace_id=bridge_trace_id,
        )
