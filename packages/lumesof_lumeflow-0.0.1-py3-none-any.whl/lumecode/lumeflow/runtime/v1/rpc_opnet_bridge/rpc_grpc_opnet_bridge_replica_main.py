from __future__ import annotations

import argparse
import asyncio
import errno
import logging
import time
from dataclasses import dataclass

from grpclib import GRPCError
from grpclib.client import Channel
from grpclib.const import Status

from lumecode.base.python.logging import lumesof_logging
from lumecode.base.python.net.retry_until_ready import RetryDeadlineExceededError, RetryUntilReady
from lumecode.base.python.net.target_parser import NetTarget
from lumecode.lumeflow.runtime.v1.flow_server import flow_server_grpc
from lumecode.lumeflow.runtime.v1.flow_server import flow_server_pb2
from lumecode.lumeflow.runtime.v1.opnet.inmemory_opnet.inmemory_opnet_grpc_client import (
    GrpcOpNetNodePlugin,
)
from lumecode.lumeflow.runtime.v1.rpc_opnet_bridge.rpc_opnet_bridge_replica import (
    RpcOpNetBridgeReplica,
)
from lumecode.lumeflow.runtime.v1.rpc_opnet_bridge.rpc_opnet_bridge_runtime_context import (
    RpcOpNetBridgeReplicaConfig,
    RpcOpNetBridgeRuntimeContext,
)

DEFAULT_MAX_CACHED_TRACES = 8192
DEFAULT_PEER_RECONNECT_INITIAL_DELAY_MS = 500
DEFAULT_PEER_RECONNECT_MAX_DELAY_MS = 10_000
DEFAULT_PEER_RECONNECT_BACKOFF_MULTIPLIER = 2.0
DEFAULT_PEER_RECONNECT_JITTER_RATIO = 0.2
DEFAULT_STARTUP_RETRY_DELAY_SECONDS = 1.0

_RETRYABLE_GRPC_STATUSES: set[Status] = {
    Status.CANCELLED,
    Status.UNKNOWN,
    Status.DEADLINE_EXCEEDED,
    Status.RESOURCE_EXHAUSTED,
    Status.ABORTED,
    Status.INTERNAL,
    Status.UNAVAILABLE,
}
structuredLogger = lumesof_logging.getLogger(__name__)


@dataclass(frozen=True)
class _ReplicaSpec:
    shard_id: str
    replica_id: str
    network_address: str


def _iterExceptionChain(exc: BaseException):
    current: BaseException | None = exc
    seen: set[int] = set()
    while current is not None and id(current) not in seen:
        seen.add(id(current))
        yield current
        if current.__cause__ is not None:
            current = current.__cause__
            continue
        current = current.__context__


def _isRetryableDependencyError(exc: BaseException) -> bool:
    for chained in _iterExceptionChain(exc):
        if isinstance(chained, RetryDeadlineExceededError):
            return True
        if isinstance(chained, (ConnectionRefusedError, ConnectionResetError, FileNotFoundError)):
            return True
        if isinstance(chained, GRPCError) and chained.status in _RETRYABLE_GRPC_STATUSES:
            return True
        if isinstance(chained, OSError):
            if chained.errno in (
                errno.ECONNREFUSED,
                errno.ECONNRESET,
                errno.EHOSTUNREACH,
                errno.ENETUNREACH,
                errno.ENOENT,
                errno.ETIMEDOUT,
            ):
                return True
            if "connection refused" in str(chained).lower():
                return True
    return False


def _normalizeTarget(target: str) -> str:
    if target.startswith("tcp://") or target.startswith("unix:///"):
        return target
    return f"tcp://{target}"


def _parseTargetOrDie(raw_target: str, *, flag_name: str) -> str:
    normalized = _normalizeTarget(raw_target.strip())
    try:
        NetTarget.parseTarget(normalized)
    except ValueError as exc:
        raise SystemExit(f"invalid {flag_name}: {exc}") from exc
    return normalized


def _parseReplicaSpecs(specs: list[str]) -> dict[str, tuple[RpcOpNetBridgeReplicaConfig, ...]]:
    parsed: dict[str, list[RpcOpNetBridgeReplicaConfig]] = {}
    seen: set[tuple[str, str]] = set()
    for raw_spec in specs:
        left, sep, network_address = raw_spec.partition("=")
        shard_id, shard_sep, replica_id = left.partition(":")
        shard_id = shard_id.strip()
        replica_id = replica_id.strip()
        network_address = network_address.strip()
        if sep != "=" or shard_sep != ":" or not shard_id or not replica_id or not network_address:
            raise SystemExit(
                "invalid --bridge-replica value "
                f"'{raw_spec}'; expected '<shard-id>:<replica-id>=<network-address>'."
            )
        normalized_address = _parseTargetOrDie(
            network_address,
            flag_name="--bridge-replica network-address",
        )
        key = (shard_id, replica_id)
        if key in seen:
            raise SystemExit(
                f"duplicate --bridge-replica for shard '{shard_id}' replica '{replica_id}'."
            )
        seen.add(key)
        parsed.setdefault(shard_id, []).append(
            RpcOpNetBridgeReplicaConfig(
                replica_id=replica_id,
                network_address=normalized_address,
            )
        )
    if len(parsed) == 0:
        raise SystemExit("at least one --bridge-replica entry is required.")
    return {shard_id: tuple(replicas) for shard_id, replicas in parsed.items()}


def _buildChannel(target: str) -> Channel:
    _parsed = NetTarget.parseTarget(target)
    if _parsed.getPath() is not None:
        return Channel(path=_parsed.getPath())
    return Channel(host=_parsed.getHost(), port=_parsed.getPort())


class _FlowServerBridgeClientAdapter:
    def __init__(
        self,
        *,
        stub: flow_server_grpc.FlowServerStub,
        retryUntilReady: RetryUntilReady | None = None,
    ) -> None:
        self._stub = stub
        self._retryUntilReady = retryUntilReady or RetryUntilReady()

    async def async_getJobIngressLinkRefByAppId(
        self,
        *,
        app_id: str,
    ) -> flow_server_pb2.GetJobIngressLinkRefByAppIdResponse:
        try:
            response = await self._retryUntilReady.async_retryUntilReady(
                operationName="RpcBridgeReplica GetJobIngressLinkRefByAppId",
                invocation=lambda: self._stub.GetJobIngressLinkRefByAppId(
                    flow_server_pb2.GetJobIngressLinkRefByAppIdRequest(app_id=app_id)
                ),
            )
        except RetryDeadlineExceededError as exc:
            raise RuntimeError("Flow server is not ready.") from exc
        resolved = flow_server_pb2.GetJobIngressLinkRefByAppIdResponse()
        resolved.CopyFrom(response)
        return resolved

    async def async_getBridgeReplicaLinkMap(self, *, substrate: str) -> dict[str, str]:
        try:
            response = await self._retryUntilReady.async_retryUntilReady(
                operationName="RpcBridgeReplica GetBridgeReplicaLinkMap",
                invocation=lambda: self._stub.GetBridgeReplicaLinkMap(
                    flow_server_pb2.GetBridgeReplicaLinkMapRequest(substrate=substrate)
                ),
            )
        except RetryDeadlineExceededError as exc:
            raise RuntimeError("Flow server is not ready.") from exc
        return dict(response.replica_to_link_ref_map)


def _parseArgs(argv: list[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Rpc OpNet bridge replica using gRPC OpNet substrate")
    parser.add_argument(
        "--shard-id",
        required=True,
        help="Local shard id for this replica.",
    )
    parser.add_argument(
        "--replica-id",
        required=True,
        help="Local replica id for this replica process.",
    )
    parser.add_argument(
        "--endpoint-listen-address",
        required=True,
        help="Endpoint RPC service bind target (tcp://host:port, host:port, or unix:///path).",
    )
    parser.add_argument(
        "--peer-listen-address",
        required=True,
        help="Peer RPC service bind target (tcp://host:port, host:port, or unix:///path).",
    )
    parser.add_argument(
        "--opnet-server-address",
        required=True,
        help="OpNet gRPC node-control target (tcp://host:port, host:port, or unix:///path).",
    )
    parser.add_argument(
        "--flow-server-address",
        required=True,
        help="Flow server target (tcp://host:port, host:port, or unix:///path).",
    )
    parser.add_argument(
        "--bridge-replica",
        action="append",
        default=[],
        help=(
            "Replica-map entry in '<shard-id>:<replica-id>=<network-address>' format. "
            "Repeat this flag for each replica in all shards."
        ),
    )
    parser.add_argument(
        "--max-cached-traces",
        type=int,
        default=DEFAULT_MAX_CACHED_TRACES,
        help="Maximum number of bridge traces cached in-memory per replica.",
    )
    parser.add_argument(
        "--peer-reconnect-initial-delay-ms",
        type=int,
        default=DEFAULT_PEER_RECONNECT_INITIAL_DELAY_MS,
        help="Initial reconnect backoff in milliseconds for peer stream dialers.",
    )
    parser.add_argument(
        "--peer-reconnect-max-delay-ms",
        type=int,
        default=DEFAULT_PEER_RECONNECT_MAX_DELAY_MS,
        help="Maximum reconnect backoff in milliseconds for peer stream dialers.",
    )
    parser.add_argument(
        "--peer-reconnect-backoff-multiplier",
        type=float,
        default=DEFAULT_PEER_RECONNECT_BACKOFF_MULTIPLIER,
        help="Exponential backoff multiplier for peer stream reconnects.",
    )
    parser.add_argument(
        "--peer-reconnect-jitter-ratio",
        type=float,
        default=DEFAULT_PEER_RECONNECT_JITTER_RATIO,
        help="Backoff jitter ratio in [0, +inf) for peer stream reconnects.",
    )
    parser.add_argument(
        "--sleep-forever-on-fatal",
        action="store_true",
        help=(
            "If set, any fatal startup/runtime error is logged and the process "
            "enters an infinite sleep loop instead of exiting."
        ),
    )
    return parser.parse_args(argv)


async def async_runReplica(
    args: argparse.Namespace,
    *,
    stop_event: asyncio.Event | None = None,
) -> None:
    shard_id = args.shard_id.strip()
    replica_id = args.replica_id.strip()
    if not shard_id:
        raise SystemExit("--shard-id must be non-empty")
    if not replica_id:
        raise SystemExit("--replica-id must be non-empty")
    if args.max_cached_traces <= 0:
        raise SystemExit("--max-cached-traces must be > 0")

    endpoint_listen_address = _parseTargetOrDie(
        args.endpoint_listen_address,
        flag_name="--endpoint-listen-address",
    )
    peer_listen_address = _parseTargetOrDie(
        args.peer_listen_address,
        flag_name="--peer-listen-address",
    )
    opnet_server_address = _parseTargetOrDie(
        args.opnet_server_address,
        flag_name="--opnet-server-address",
    )
    flow_server_address = _parseTargetOrDie(
        args.flow_server_address,
        flag_name="--flow-server-address",
    )
    replica_map_by_shard = _parseReplicaSpecs(args.bridge_replica)

    flow_channel = _buildChannel(flow_server_address)
    flow_stub = flow_server_grpc.FlowServerStub(flow_channel)
    flow_adapter = _FlowServerBridgeClientAdapter(
        stub=flow_stub,
    )

    node_plugin = GrpcOpNetNodePlugin(node_id=replica_id)
    replica: RpcOpNetBridgeReplica | None = None
    try:
        with lumesof_logging.loggingContext(
            **{
                "shard_id": shard_id,
                "replica_id": replica_id,
            }
        ):
            structuredLogger.info(
                "rpc bridge replica starting",
                event="lumeflow.rpc_bridge.replica.starting",
                attrs={
                    "endpoint_listen_address": endpoint_listen_address,
                    "peer_listen_address": peer_listen_address,
                    "flow_server_address": flow_server_address,
                    "opnet_server_address": opnet_server_address,
                },
            )
        try:
            bridge_replica_link_map = await flow_adapter.async_getBridgeReplicaLinkMap(
                substrate=node_plugin.getSubstrate()
            )
        except Exception:
            structuredLogger.exception(
                "Failed to fetch bridge replica link map",
                event="lumeflow.rpc_bridge.replica.link_map_failed",
                attrs={
                    "shard_id": shard_id,
                    "replica_id": replica_id,
                    lumesof_logging.LUMESOF_SUBSTRATE: node_plugin.getSubstrate(),
                },
            )
            raise
        runtime_context = RpcOpNetBridgeRuntimeContext(
            shard_id=shard_id,
            replica_id=replica_id,
            node_plugin=node_plugin,
            replica_map_by_shard=replica_map_by_shard,
            replica_to_link_ref_map=bridge_replica_link_map,
        )
        replica = RpcOpNetBridgeReplica(
            runtime_context=runtime_context,
            flow_server_client=flow_adapter,
            endpoint_listen_address=endpoint_listen_address,
            peer_listen_address=peer_listen_address,
            peer_reconnect_initial_delay_sec=args.peer_reconnect_initial_delay_ms / 1000.0,
            peer_reconnect_max_delay_sec=args.peer_reconnect_max_delay_ms / 1000.0,
            peer_reconnect_backoff_multiplier=args.peer_reconnect_backoff_multiplier,
            peer_reconnect_jitter_ratio=args.peer_reconnect_jitter_ratio,
        )
        await replica.async_start()
        structuredLogger.info(
            "rpc bridge replica started",
            event="lumeflow.rpc_bridge.replica.started",
            attrs={
                "shard_id": shard_id,
                "replica_id": replica_id,
                "endpoint_listen_address": endpoint_listen_address,
                "peer_listen_address": peer_listen_address,
            },
        )
        if stop_event is None:
            await asyncio.Future()
        else:
            await stop_event.wait()
    finally:
        if replica is not None:
            await replica.async_close()
        await node_plugin.async_close()
        flow_channel.close()


def _sleepForeverAfterFatal(*, message: str) -> None:
    logging.critical("%s", message)
    while True:
        time.sleep(3600)


def main(argv: list[str] | None = None) -> None:
    logging.basicConfig(level=logging.INFO)
    args: argparse.Namespace | None = None
    try:
        args = _parseArgs(argv)
        while True:
            try:
                asyncio.run(async_runReplica(args))
                return
            except KeyboardInterrupt:
                logging.info("rpc bridge replica interrupted; exiting")
                raise
            except Exception as exc:
                if _isRetryableDependencyError(exc):
                    structuredLogger.warning(
                        "rpc bridge replica dependency not ready; retrying startup",
                        event="lumeflow.rpc_bridge.replica.retrying_dependency",
                        attrs={
                            "retry_delay_seconds": DEFAULT_STARTUP_RETRY_DELAY_SECONDS,
                            "error_type": type(exc).__name__,
                            "error_message": str(exc),
                        },
                    )
                    time.sleep(DEFAULT_STARTUP_RETRY_DELAY_SECONDS)
                    continue
                raise
    except KeyboardInterrupt:
        logging.info("rpc bridge replica interrupted; exiting")
        raise
    except SystemExit:
        logging.exception("rpc bridge replica exited due to fatal argument/configuration error")
        if args is not None and getattr(args, "sleep_forever_on_fatal", False):
            _sleepForeverAfterFatal(
                message=(
                    "rpc bridge replica entering infinite sleep after fatal "
                    "argument/configuration error"
                )
            )
        raise
    except Exception:
        logging.exception("rpc bridge replica encountered fatal runtime error")
        if args is not None and getattr(args, "sleep_forever_on_fatal", False):
            _sleepForeverAfterFatal(
                message="rpc bridge replica entering infinite sleep after fatal runtime error"
            )
        raise


if __name__ == "__main__":
    main()
