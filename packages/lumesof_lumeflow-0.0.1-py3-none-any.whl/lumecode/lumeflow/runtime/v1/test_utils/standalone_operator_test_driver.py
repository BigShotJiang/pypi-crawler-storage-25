from __future__ import annotations

import abc
import asyncio
import contextlib
import json
import logging
import os
import socket
import tempfile
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import AsyncIterator, Optional, Sequence

from python.runfiles import Runfiles

from lumecode.base.python.logging import lumesof_logging
from lumecode.base.python.logging.test_log_collectors import (
    FluentTestLogCollector,
    OtlpTestLogCollector,
)
from lumecode.base.python.net.target_parser import NetTarget
from lumecode.daemon.cartond import cartond_pb2
from lumecode.daemon.cartond.cartond_client import CartondClient
from lumecode.lumeflow.runtime.v1.opnet import opnet_types_pb2

LOG = logging.getLogger(__name__)

DEFAULT_CARTOND_TARGET = "unix:///lumesof/pkg_data/cartond_local/carton.sock"
_DEFAULT_OPERATOR_CONNECT_MAX_ATTEMPTS = 80
_DEFAULT_OPERATOR_CONNECT_BACKOFF_MS = 250
_DEFAULT_TIMEOUT_SECONDS = 180.0
_DEFAULT_STATUS_POLL_SECONDS = 0.5
_DEFAULT_LOG_DUMP_SECONDS = 1.0
_DEFAULT_FALLBACK_LOG_BUFFER_BYTES = 4 * 1024 * 1024
_ACK_STATUS_ACK = "ack"
_ACK_STATUS_NACK = "nack"


class IngressGenerator(abc.ABC):
    @abc.abstractmethod
    def generate(self, *, writableFilePath: Path) -> Sequence[tuple[str, str]]:
        """Write ingress data and return expected (message_id, ack/nack) outcomes."""


class EgressVerifier(abc.ABC):
    @abc.abstractmethod
    def verify(self, *, readableFilePath: Path) -> None:
        """Raise while output is incomplete/invalid; return once verification passes."""


@dataclass(frozen=True)
class _IngressBinding:
    port: opnet_types_pb2.OpNetPort
    generator: Optional[IngressGenerator]


@dataclass(frozen=True)
class _EgressBinding:
    port: opnet_types_pb2.OpNetPort
    verifier: Optional[EgressVerifier]


@dataclass(frozen=True)
class _AckEvent:
    port: str
    messageId: str
    status: str


class StandaloneOperatorTestDriver:
    def __init__(
        self,
        *,
        operatorDockerImage: str,
        operatorName: str,
        opnetNodeId: str,
        cartondTarget: str = DEFAULT_CARTOND_TARGET,
        timeoutSeconds: float = _DEFAULT_TIMEOUT_SECONDS,
        statusPollSeconds: float = _DEFAULT_STATUS_POLL_SECONDS,
        logDumpSeconds: float = _DEFAULT_LOG_DUMP_SECONDS,
        operatorConnectMaxAttempts: int = _DEFAULT_OPERATOR_CONNECT_MAX_ATTEMPTS,
        operatorConnectBackoffMs: int = _DEFAULT_OPERATOR_CONNECT_BACKOFF_MS,
    ) -> None:
        image = operatorDockerImage.strip()
        if not image:
            raise ValueError("operatorDockerImage must be set")
        nodeId = opnetNodeId.strip()
        if not nodeId:
            raise ValueError("opnetNodeId must be set")
        normalizedOperatorName = operatorName.strip()
        if not normalizedOperatorName:
            raise ValueError("operatorName must be set")

        self._operatorDockerImage = image
        self._operatorName = normalizedOperatorName
        self._opnetNodeId = nodeId
        self._cartondTarget = (cartondTarget or "").strip() or DEFAULT_CARTOND_TARGET
        self._timeoutSeconds = max(float(timeoutSeconds), 1.0)
        self._statusPollSeconds = max(float(statusPollSeconds), 0.1)
        self._logDumpSeconds = max(float(logDumpSeconds), 0.1)
        self._operatorConnectMaxAttempts = max(int(operatorConnectMaxAttempts), 1)
        self._operatorConnectBackoffMs = max(int(operatorConnectBackoffMs), 0)

        self._ingressByName: dict[str, _IngressBinding] = {}
        self._egressByName: dict[str, _EgressBinding] = {}

    def addIngressGenerator(
        self,
        *,
        port: opnet_types_pb2.OpNetPort,
        generator: Optional[IngressGenerator] = None,
    ) -> None:
        self._validatePort(port=port, expectedDirection="INGRESS")
        self._ingressByName[port.port_name] = _IngressBinding(port=port, generator=generator)

    def addEgressVerifier(
        self,
        *,
        port: opnet_types_pb2.OpNetPort,
        verifier: Optional[EgressVerifier] = None,
    ) -> None:
        self._validatePort(port=port, expectedDirection="EGRESS")
        self._egressByName[port.port_name] = _EgressBinding(port=port, verifier=verifier)

    async def async_run(self) -> None:
        if len(self._ingressByName) == 0 and len(self._egressByName) == 0:
            raise RuntimeError("No ingress generators or egress verifiers were configured.")

        appId = f"standalone-op-test-{uuid.uuid4().hex[:12]}"
        collectorStopEvent = asyncio.Event()
        dumpTasks: list[asyncio.Task] = []

        cartondClient = CartondClient(target=self._cartondTarget)
        await self._async_verifyCartondReady(cartondClient=cartondClient)

        otlpCollector = OtlpTestLogCollector()
        fluentCollector = FluentTestLogCollector()
        ackReportServer: Optional[asyncio.AbstractServer] = None
        try:
            otlpTarget = await otlpCollector.async_start()
            await fluentCollector.async_start()
            dockerReachableOtlpTarget = _toDockerHostTcpTarget(otlpTarget=otlpTarget)

            dumpTasks.append(
                asyncio.create_task(
                    self._async_periodicDumpCollector(
                        stopEvent=collectorStopEvent,
                        collector=otlpCollector,
                        label="periodic",
                    ),
                    name="standalone-operator-test-otlp-dump",
                )
            )
            dumpTasks.append(
                asyncio.create_task(
                    self._async_periodicDumpCollector(
                        stopEvent=collectorStopEvent,
                        collector=fluentCollector,
                        label="periodic",
                    ),
                    name="standalone-operator-test-fluent-dump",
                )
            )

            with tempfile.TemporaryDirectory(prefix="standalone_operator_test_driver_") as tempDir:
                rootPath = Path(tempDir)
                rootPath.chmod(0o777)
                sharedHostDir = rootPath / "shared"
                sharedHostDir.mkdir(parents=True, exist_ok=True)
                sharedHostDir.chmod(0o777)
                mountedSharedDir = "/tmp/standalone-operator-test-driver"

                ackReportSocketHostPath = sharedHostDir / "ack_report.sock"
                ackReportServer, ackReportQueue = await self._async_startAckReportServer(
                    socketPath=ackReportSocketHostPath
                )

                ingressFiles, expectedAckByMessage = self._generateIngressFiles(
                    sharedHostDir=sharedHostDir
                )
                egressFiles = self._createEgressFiles(sharedHostDir=sharedHostDir)

                appCreated = False
                try:
                    createResult = await cartondClient.async_createApp(
                        appId=appId,
                        skipTmpPivot=True,
                        externalMounts=[
                            cartond_pb2.ExternalMount(
                                source_path=str(sharedHostDir),
                                target_path=mountedSharedDir,
                                read_only=False,
                            )
                        ],
                        captureFallbackLogs=True,
                        fallbackOtlpTarget=otlpTarget,
                        fallbackLogBufferBytes=_DEFAULT_FALLBACK_LOG_BUFFER_BYTES,
                        dockerMediationPolicy=cartond_pb2.DockerMediationPolicy(
                            log_policy=cartond_pb2.DockerLogPolicy(
                                driver=cartond_pb2.DOCKER_LOG_DRIVER_FLUENTD,
                                fluentd_address=fluentCollector.address(),
                            ),
                            container_labels={
                                "lumesof.app_id": appId,
                                "lumesof.operator_name": self._operatorName,
                                "lumesof.instance_id": "cartond-itest",
                            },
                        ),
                    )
                    if createResult.code != 0:
                        raise RuntimeError(
                            f"CreateApp failed app_id={appId} code={createResult.code} "
                            f"message={createResult.message}"
                        )
                    appCreated = True

                    standaloneAppImagePath = self._resolveStandaloneSidecarAppImagePath()
                    uploadResult = await cartondClient.async_uploadAppImageStream(
                        appId=appId,
                        chunkStream=self._async_streamFileChunks(standaloneAppImagePath),
                    )
                    if uploadResult.code != 0:
                        raise RuntimeError(
                            f"UploadAppImage failed app_id={appId} code={uploadResult.code} "
                            f"message={uploadResult.message}"
                        )

                    launchResult = await cartondClient.async_launchApp(
                        appId=appId,
                        argv=self._buildLaunchArgv(
                            ingressFiles=ingressFiles,
                            egressFiles=egressFiles,
                            mountedSharedDir=mountedSharedDir,
                            otlpTarget=dockerReachableOtlpTarget,
                            ackReportSocketFileName=ackReportSocketHostPath.name,
                        ),
                        env={
                            lumesof_logging.LOG_LEVEL_ENV: "INFO",
                            lumesof_logging.LUMESOF_OTEL_EXPORTER_OTLP_ENDPOINT_ENV: otlpTarget,
                            lumesof_logging.OTEL_EXPORTER_OTLP_ENDPOINT_ENV: otlpTarget,
                        },
                    )
                    if launchResult.code != 0:
                        raise RuntimeError(
                            f"LaunchApp failed app_id={appId} code={launchResult.code} "
                            f"message={launchResult.message}"
                        )

                    await self._async_waitForCompletion(
                        cartondClient=cartondClient,
                        appId=appId,
                        egressFiles=egressFiles,
                        expectedAckByMessage=expectedAckByMessage,
                        ackReportQueue=ackReportQueue,
                    )
                finally:
                    if appCreated:
                        with contextlib.suppress(Exception):
                            await cartondClient.async_tearDownApp(appId)
        finally:
            if ackReportServer is not None:
                ackReportServer.close()
                with contextlib.suppress(Exception):
                    await ackReportServer.wait_closed()
            collectorStopEvent.set()
            for task in dumpTasks:
                task.cancel()
                with contextlib.suppress(asyncio.CancelledError, Exception):
                    await task

            with contextlib.suppress(Exception):
                await otlpCollector.async_dumpAndClearCapturedLogsToStdout(label="teardown-final")
            with contextlib.suppress(Exception):
                await fluentCollector.async_dumpAndClearCapturedLogsToStdout(label="teardown-final")
            with contextlib.suppress(Exception):
                await fluentCollector.async_stop()
            with contextlib.suppress(Exception):
                await otlpCollector.async_stop()

    def _generateIngressFiles(
        self,
        *,
        sharedHostDir: Path,
    ) -> tuple[dict[str, Path], dict[tuple[str, str], str]]:
        ingressFiles: dict[str, Path] = {}
        expectedAckByMessage: dict[tuple[str, str], str] = {}
        for portName, binding in self._ingressByName.items():
            filePath = sharedHostDir / f"ingress_{portName}.bin"
            expectations: Sequence[tuple[str, str]] = ()
            if binding.generator is None:
                filePath.write_bytes(b"")
            else:
                expectations = binding.generator.generate(writableFilePath=filePath)
                if not filePath.exists():
                    raise RuntimeError(
                        f"Ingress generator did not create file for port={portName}: {filePath}"
                    )
            for messageId, status in expectations:
                normalizedMessageId = (messageId or "").strip()
                if not normalizedMessageId:
                    raise RuntimeError(f"Ingress plan has empty message_id for port={portName}")
                normalizedStatus = self._normalizeAckStatus(
                    status=status,
                    portName=portName,
                    messageId=normalizedMessageId,
                )
                key = (portName, normalizedMessageId)
                if key in expectedAckByMessage:
                    raise RuntimeError(
                        f"Duplicate ingress ack plan for port={portName} message_id={normalizedMessageId}"
                    )
                expectedAckByMessage[key] = normalizedStatus
            filePath.chmod(0o644)
            ingressFiles[portName] = filePath
        return ingressFiles, expectedAckByMessage

    def _createEgressFiles(self, *, sharedHostDir: Path) -> dict[str, Path]:
        egressFiles: dict[str, Path] = {}
        for portName in self._egressByName.keys():
            filePath = sharedHostDir / f"egress_{portName}.bin"
            filePath.write_bytes(b"")
            filePath.chmod(0o666)
            egressFiles[portName] = filePath
        return egressFiles

    def _buildLaunchArgv(
        self,
        *,
        ingressFiles: dict[str, Path],
        egressFiles: dict[str, Path],
        mountedSharedDir: str,
        otlpTarget: str,
        ackReportSocketFileName: str,
    ) -> list[str]:
        sidecarTarget = f"tcp://0.0.0.0:{_findFreeTcpPort()}"
        argv = [
            "__sidecar_cas_override__",
            "--docker-image",
            self._operatorDockerImage,
            "--bind",
            sidecarTarget,
            "--opnet-node-id",
            self._opnetNodeId,
            "--ack-report-uds-path",
            f"{mountedSharedDir}/{ackReportSocketFileName}",
        ]

        for port in self._iterOrderedPorts():
            argv.extend(["--opnet-port", _formatPortSpec(port=port)])

        for portName, hostPath in ingressFiles.items():
            argv.extend(["--ingress-file", f"{portName}={mountedSharedDir}/{hostPath.name}"])
        for portName, hostPath in egressFiles.items():
            argv.extend(["--egress-file", f"{portName}={mountedSharedDir}/{hostPath.name}"])

        argv.extend([
            "--otel-logs-endpoint",
            otlpTarget,
            "--operator-connect-max-attempts",
            str(self._operatorConnectMaxAttempts),
            "--operator-connect-backoff-ms",
            str(self._operatorConnectBackoffMs),
        ])
        return argv

    def _iterOrderedPorts(self) -> list[opnet_types_pb2.OpNetPort]:
        seen: set[str] = set()
        ordered: list[opnet_types_pb2.OpNetPort] = []
        for binding in self._ingressByName.values():
            if binding.port.port_name in seen:
                continue
            seen.add(binding.port.port_name)
            ordered.append(binding.port)
        for binding in self._egressByName.values():
            if binding.port.port_name in seen:
                continue
            seen.add(binding.port.port_name)
            ordered.append(binding.port)
        return ordered

    async def _async_waitForCompletion(
        self,
        *,
        cartondClient: CartondClient,
        appId: str,
        egressFiles: dict[str, Path],
        expectedAckByMessage: dict[tuple[str, str], str],
        ackReportQueue: "asyncio.Queue[_AckEvent]",
    ) -> None:
        deadline = time.monotonic() + self._timeoutSeconds
        completedPorts: set[str] = {
            portName
            for portName, binding in self._egressByName.items()
            if binding.verifier is None
        }
        lastErrorsByPort: dict[str, str] = {}
        observedAckByMessage: dict[tuple[str, str], str] = {}

        while True:
            self._drainAckReports(
                ackReportQueue=ackReportQueue,
                expectedAckByMessage=expectedAckByMessage,
                observedAckByMessage=observedAckByMessage,
            )

            for portName, binding in self._egressByName.items():
                if portName in completedPorts:
                    continue
                if binding.verifier is None:
                    completedPorts.add(portName)
                    lastErrorsByPort.pop(portName, None)
                    continue
                try:
                    binding.verifier.verify(readableFilePath=egressFiles[portName])
                except Exception as exc:
                    lastErrorsByPort[portName] = f"{type(exc).__name__}: {exc}"
                else:
                    completedPorts.add(portName)
                    lastErrorsByPort.pop(portName, None)

            if (
                len(completedPorts) == len(self._egressByName)
                and len(observedAckByMessage) == len(expectedAckByMessage)
            ):
                return

            appStatus = await cartondClient.async_getAppStatus(appId)
            if appStatus.code != 0:
                raise RuntimeError(
                    f"GetAppStatus failed app_id={appId} code={appStatus.code} "
                    f"message={appStatus.message}"
                )
            if appStatus.runStatus in (
                cartond_pb2.APP_RUN_STATUS_EXITED,
                cartond_pb2.APP_RUN_STATUS_FAILED,
                cartond_pb2.APP_RUN_STATUS_DISPOSED,
            ):
                pendingPorts = sorted(set(self._egressByName.keys()) - completedPorts)
                missingAck = sorted(set(expectedAckByMessage.keys()) - set(observedAckByMessage.keys()))
                raise RuntimeError(
                    f"Standalone sidecar app exited before checks passed app_id={appId} "
                    f"run_status={_runStatusName(appStatus.runStatus)} "
                    f"exit_code={appStatus.exitCode} pending_ports={pendingPorts} "
                    f"missing_ack={missingAck} last_errors={lastErrorsByPort}"
                )

            remaining = deadline - time.monotonic()
            if remaining <= 0.0:
                with contextlib.suppress(Exception):
                    timeoutStatus = await cartondClient.async_getAppStatus(appId)
                    LOG.error(
                        "Standalone operator test timed out app_id=%s run_status=%s "
                        "exit_code=%s pending_ports=%s missing_ack=%s last_errors=%s",
                        appId,
                        _runStatusName(timeoutStatus.runStatus),
                        timeoutStatus.exitCode,
                        sorted(set(self._egressByName.keys()) - completedPorts),
                        sorted(set(expectedAckByMessage.keys()) - set(observedAckByMessage.keys())),
                        lastErrorsByPort,
                    )
                with contextlib.suppress(Exception):
                    await cartondClient.async_tearDownApp(appId)
                raise TimeoutError(
                    f"Timed out waiting for completion app_id={appId} "
                    f"pending_ports={sorted(set(self._egressByName.keys()) - completedPorts)} "
                    f"missing_ack={sorted(set(expectedAckByMessage.keys()) - set(observedAckByMessage.keys()))} "
                    f"last_errors={lastErrorsByPort}"
                )

            await asyncio.sleep(self._statusPollSeconds)

    def _drainAckReports(
        self,
        *,
        ackReportQueue: "asyncio.Queue[_AckEvent]",
        expectedAckByMessage: dict[tuple[str, str], str],
        observedAckByMessage: dict[tuple[str, str], str],
    ) -> None:
        while True:
            try:
                event = ackReportQueue.get_nowait()
            except asyncio.QueueEmpty:
                return

            key = (event.port, event.messageId)
            expectedStatus = expectedAckByMessage.get(key)
            if expectedStatus is None:
                raise RuntimeError(
                    f"Received unexpected ack report port={event.port} "
                    f"message_id={event.messageId} status={event.status}"
                )

            previousStatus = observedAckByMessage.get(key)
            if previousStatus is not None and previousStatus != event.status:
                raise RuntimeError(
                    f"Received conflicting ack reports port={event.port} message_id={event.messageId} "
                    f"statuses={previousStatus},{event.status}"
                )
            observedAckByMessage[key] = event.status

            if event.status != expectedStatus:
                raise RuntimeError(
                    f"Ack status mismatch port={event.port} message_id={event.messageId} "
                    f"expected={expectedStatus} actual={event.status}"
                )

    async def _async_startAckReportServer(
        self,
        *,
        socketPath: Path,
    ) -> tuple[asyncio.AbstractServer, "asyncio.Queue[_AckEvent]"]:
        if socketPath.exists():
            socketPath.unlink()
        ackReportQueue: asyncio.Queue[_AckEvent] = asyncio.Queue()

        async def _async_handleConnection(
            reader: asyncio.StreamReader,
            writer: asyncio.StreamWriter,
        ) -> None:
            try:
                while True:
                    line = await reader.readline()
                    if not line:
                        return
                    event = _parseAckEvent(line=line, socketPath=socketPath)
                    await ackReportQueue.put(event)
            finally:
                writer.close()
                with contextlib.suppress(Exception):
                    await writer.wait_closed()

        server = await asyncio.start_unix_server(
            _async_handleConnection,
            path=str(socketPath),
        )
        socketPath.chmod(0o777)
        return server, ackReportQueue

    async def _async_periodicDumpCollector(
        self,
        *,
        stopEvent: asyncio.Event,
        collector,
        label: str,
    ) -> None:
        while not stopEvent.is_set():
            await collector.async_dumpAndClearCapturedLogsToStdout(label=label)
            try:
                await asyncio.wait_for(stopEvent.wait(), timeout=self._logDumpSeconds)
            except asyncio.TimeoutError:
                pass

    async def _async_verifyCartondReady(self, *, cartondClient: CartondClient) -> None:
        info = await cartondClient.async_getInfo()
        if info.code != 0:
            raise RuntimeError(f"cartond GetInfo failed code={info.code} message={info.message}")
        if not info.allowExternalMounts:
            raise RuntimeError("cartond must allow external mounts for this integration test")
        if not info.enableDockerMediation:
            raise RuntimeError("cartond must enable docker mediation for this integration test")

    def _resolveStandaloneSidecarAppImagePath(self) -> str:
        runfiles = Runfiles.Create()
        candidatePaths = (
            "_main/lumecode/lumeflow/runtime/v1/test_utils/standalone_operator_sidecar_app_image.appimage",
            "lumecode/lumeflow/runtime/v1/test_utils/standalone_operator_sidecar_app_image.appimage",
        )
        candidates: list[str] = []
        for candidate in candidatePaths:
            if runfiles is not None:
                resolved = runfiles.Rlocation(candidate) or ""
                if resolved:
                    candidates.append(resolved)
            candidates.append(candidate)
        for candidate in candidates:
            if os.path.isfile(candidate):
                return candidate
        raise RuntimeError(f"Standalone sidecar app image runfile not found. checked={candidates}")

    async def _async_streamFileChunks(
        self,
        filePath: str,
        *,
        chunkSizeBytes: int = 1024 * 1024,
    ) -> AsyncIterator[bytes]:
        with open(filePath, "rb") as inputFile:
            while True:
                chunk = inputFile.read(chunkSizeBytes)
                if not chunk:
                    return
                yield chunk

    @staticmethod
    def _normalizeAckStatus(*, status: str, portName: str, messageId: str) -> str:
        normalized = (status or "").strip().lower()
        if normalized not in (_ACK_STATUS_ACK, _ACK_STATUS_NACK):
            raise RuntimeError(
                f"Ingress plan has invalid status for port={portName} message_id={messageId}: {status!r}"
            )
        return normalized

    @staticmethod
    def _validatePort(
        *,
        port: opnet_types_pb2.OpNetPort,
        expectedDirection: str,
    ) -> None:
        if not port.port_name:
            raise ValueError("port.port_name must be set")
        if not port.payload_type.type_url:
            raise ValueError(f"port.payload_type.type_url must be set for port={port.port_name}")

        ingressPortKinds = {
            opnet_types_pb2.OpNetPort.PortType.INGRESS,
            opnet_types_pb2.OpNetPort.PortType.INGRESS_BRIDGE,
        }
        egressPortKinds = {
            opnet_types_pb2.OpNetPort.PortType.EGRESS,
            opnet_types_pb2.OpNetPort.PortType.EGRESS_BRIDGE,
        }
        if expectedDirection == "INGRESS" and port.port_type not in ingressPortKinds:
            raise ValueError(
                f"Port {port.port_name} must be ingress; got {opnet_types_pb2.OpNetPort.PortType.Name(port.port_type)}"
            )
        if expectedDirection == "EGRESS" and port.port_type not in egressPortKinds:
            raise ValueError(
                f"Port {port.port_name} must be egress; got {opnet_types_pb2.OpNetPort.PortType.Name(port.port_type)}"
            )


def _parseAckEvent(*, line: bytes, socketPath: Path) -> _AckEvent:
    try:
        payload = json.loads(line.decode("utf-8"))
    except Exception as exc:
        raise RuntimeError(
            f"Failed to parse ack-report JSON line from {socketPath}: {exc}; raw={line!r}"
        ) from exc

    if not isinstance(payload, dict):
        raise RuntimeError(f"Ack report must be JSON object from {socketPath}: {payload!r}")

    port = str(payload.get("port") or "").strip()
    message = payload.get("message")
    if not port:
        raise RuntimeError(f"Ack report missing port from {socketPath}: {payload!r}")
    if not isinstance(message, dict):
        raise RuntimeError(f"Ack report missing message object from {socketPath}: {payload!r}")

    messageId = str(message.get("message_id") or "").strip()
    status = str(message.get("status") or "").strip().lower()
    if not messageId:
        raise RuntimeError(f"Ack report missing message_id from {socketPath}: {payload!r}")
    if status not in (_ACK_STATUS_ACK, _ACK_STATUS_NACK):
        raise RuntimeError(
            f"Ack report has invalid status from {socketPath}: {payload!r}; "
            f"expected one of: {_ACK_STATUS_ACK}, {_ACK_STATUS_NACK}"
        )
    return _AckEvent(port=port, messageId=messageId, status=status)


def _findFreeTcpPort() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def _toDockerHostTcpTarget(*, otlpTarget: str) -> str:
    parsed = NetTarget.parseTarget(otlpTarget)
    if parsed.getPath() is not None:
        return otlpTarget
    return f"tcp://host.docker.internal:{parsed.getPort()}"


def _formatPortSpec(*, port: opnet_types_pb2.OpNetPort) -> str:
    portType = opnet_types_pb2.OpNetPort.PortType.Name(port.port_type)
    serializationFormat = opnet_types_pb2.OpNetPayloadType.SerializationFormat.Name(
        port.payload_type.serialization_format
        if (
            port.payload_type.serialization_format
            != opnet_types_pb2.OpNetPayloadType.SerializationFormat.SERIALIZATION_FORMAT_UNSPECIFIED
        )
        else opnet_types_pb2.OpNetPayloadType.SerializationFormat.PROTO
    )
    return (
        f"{port.port_name},{portType},{port.payload_type.type_url},{serializationFormat}"
    )


def _runStatusName(runStatus: int) -> str:
    try:
        return cartond_pb2.AppRunStatus.Name(runStatus)
    except Exception:
        return str(runStatus)


__all__ = [
    "EgressVerifier",
    "IngressGenerator",
    "StandaloneOperatorTestDriver",
]
