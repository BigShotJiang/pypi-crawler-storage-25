from __future__ import annotations

import abc
import argparse
import asyncio
import contextlib
import logging
import os
import socket
import tempfile
import threading
import time
import uuid
from dataclasses import dataclass
from typing import Awaitable, Callable, Optional, Sequence

import grpc
from google.protobuf import any_pb2, timestamp_pb2
from grpclib.client import Channel
from grpclib.server import Server
from opentelemetry.proto.collector.logs.v1 import logs_service_pb2, logs_service_pb2_grpc
from sqlalchemy import insert
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.pool import NullPool

from lumecode.base.python.net.target_parser import NetTarget
from lumecode.crdb.schemas.dev_cluster.flow.db_orm_models import TabClusters
from lumecode.lumeflow.runtime.v1.executor import executor_control_service_grpc
from lumecode.lumeflow.runtime.v1.executor.executor_control_service import ExecutorControlService
from lumecode.lumeflow.runtime.v1.executor.local.local_executor_controller import (
    LocalExecutorController,
)
from lumecode.lumeflow.runtime.v1.flow_server import dag_pb2, flow_server_grpc, flow_server_pb2
from lumecode.lumeflow.runtime.v1.flow_server.flow_server import FlowServerService
from lumecode.lumeflow.runtime.v1.graph.graph import Graph
from lumecode.lumeflow.runtime.v1.opnet import opnet_controller_grpc, opnet_controller_pb2, opnet_types_pb2
from lumecode.lumeflow.runtime.v1.opnet.inmemory_opnet.inmemory_opnet_grpc_server import (
    AnnouncingOpNetControllerPlugin,
    InMemoryOpNetControllerPlugin,
    start_server as startInMemoryOpNetServer,
)
from lumecode.lumeflow.runtime.v1.opnet.opnet_controller import OpNetControllerCollection
from lumecode.lumeflow.runtime.v1.opnet.opnet_link import OpNetLinkCollection
from lumecode.lumeflow.runtime.v1.opnet.opnet_node import OpNetNodeCollection
from lumecode.lumeflow.runtime.v1.opnet.opnet_server import OpNetControllerService, OpNetManagerService
from lumecode.lumeflow.runtime.v1.rpc_opnet_bridge import rpc_opnet_bridge_grpc, rpc_opnet_bridge_pb2
from lumecode.lumeflow.runtime.v1.rpc_opnet_bridge import rpc_grpc_opnet_bridge_replica_main
from lumecode.lumeflow.runtime.v1.rpc_opnet_bridge.rpc_opnet_bridge_client import (
    ReplicaConnectionBroken,
    RpcOpnetBridgeClient,
    RpcOpnetBridgeRequest,
)
from lumecode.storage.cas import cas_grpc, sidecar_cas

LOG = logging.getLogger(__name__)

_DEFAULT_CARTOND_TARGET = "unix:///lumesof/pkg_data/cartond_local/carton.sock"
_DEFAULT_OWNER = "owner@example.com"
_DEFAULT_STATUS_TIMEOUT_SECONDS = 120.0
_DEFAULT_STATUS_POLL_SECONDS = 0.1
_DEFAULT_BRIDGE_CALL_TIMEOUT_MS = 10_000
_DEFAULT_BRIDGE_FETCH_TIMEOUT_SECONDS = 2.0
_DEFAULT_BRIDGE_RESPONSE_TIMEOUT_SECONDS = 30.0
_CANONICAL_ANY_TYPE_PREFIX = "type.googleapis.com/"


class BasePublisher(abc.ABC):
    @abc.abstractmethod
    async def publish(self) -> None:
        """Publish all graph dependencies required for a standalone test run."""


class SyncGeneratorAndVerifier(abc.ABC):
    @abc.abstractmethod
    async def generate(self) -> any_pb2.Any | None:
        """Return the next request payload or None when generation is complete."""

    @abc.abstractmethod
    async def verify(self, message: any_pb2.Any) -> bool:
        """Return True when a bridge response satisfies test expectations."""


class AsyncGeneratorAndVerifier(abc.ABC):
    @abc.abstractmethod
    async def startVerifier(self) -> None:
        """Start verifier-side resources. Runs on a dedicated verifier loop."""

    @abc.abstractmethod
    async def generate(self) -> any_pb2.Any | None:
        """Return the next message to inject or None when generation is complete."""

    @abc.abstractmethod
    async def getVerificationResult(self) -> bool:
        """Return True when verifier-side assertions passed."""


@dataclass(frozen=True)
class FlowServerFactoryContext:
    sessionMaker: async_sessionmaker[AsyncSession]
    clusterId: uuid.UUID
    opnetManagerClient: object
    executorControlClient: object
    casClient: object
    opnetControllerTarget: str
    sidecarGrpcOpnetTarget: str
    sidecarOtelLogsEndpoint: str
    bridgeReplicaToLinkRef: dict[str, str]
    enableBridgeBootstrap: bool
    enableCreateLoop: bool


@dataclass(frozen=True)
class StandaloneGraphRunContext:
    clusterId: uuid.UUID
    jobId: str
    sessionMaker: async_sessionmaker[AsyncSession]
    flowServerStub: flow_server_grpc.FlowServerStub


@dataclass(frozen=True)
class _BridgeRuntime:
    appId: str
    client: RpcOpnetBridgeClient
    stopEvent: asyncio.Event
    replicaTasks: list[asyncio.Task[None]]
    replicaSocketPaths: list[str]


@dataclass(frozen=True)
class _Runtime:
    clusterId: uuid.UUID
    engine: object
    sessionMaker: async_sessionmaker[AsyncSession]
    grpcOpnetUdsPath: str
    grpcOpnetServer: Server
    opnetControllerCollection: OpNetControllerCollection
    opnetServer: Server
    opnetUdsPath: str
    opnetChannel: Channel
    opnetManagerClient: object
    casServer: Server
    casChannel: Channel
    casTarget: str
    casClient: object
    executorService: ExecutorControlService
    executorServer: Server
    executorUdsPath: str
    executorChannel: Channel
    otlpServer: grpc.aio.Server
    otlpUdsPath: str
    otlpEndpoint: str
    flowServer: FlowServerService
    flowServerServer: Server
    flowServerUdsPath: str
    flowServerChannel: Channel
    flowServerStub: flow_server_grpc.FlowServerStub
    bridgeRuntime: _BridgeRuntime | None


class _NoopOtelCollector(logs_service_pb2_grpc.LogsServiceServicer):
    async def Export(self, request, context):  # type: ignore[override]
        del request
        del context
        return logs_service_pb2.ExportLogsServiceResponse()


class _VerifierLoopThread:
    def __init__(self) -> None:
        self._loop: asyncio.AbstractEventLoop | None = None
        self._thread: threading.Thread | None = None
        self._ready = threading.Event()
        self._stop = threading.Event()

    def start(self) -> None:
        if self._thread is not None:
            return

        def _threadMain() -> None:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            self._loop = loop
            self._ready.set()
            try:
                loop.run_forever()
            finally:
                pending = asyncio.all_tasks(loop=loop)
                for task in pending:
                    task.cancel()
                if pending:
                    loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
                loop.close()
                self._stop.set()

        self._thread = threading.Thread(target=_threadMain, name="standalone-graph-verifier-loop", daemon=True)
        self._thread.start()
        if not self._ready.wait(timeout=5.0):
            raise RuntimeError("Verifier loop thread did not start.")

    async def async_runCoroutine(self, coro):
        if self._loop is None:
            raise RuntimeError("Verifier loop is not started.")
        future = asyncio.run_coroutine_threadsafe(coro, self._loop)
        wrapped = asyncio.wrap_future(future)
        return await wrapped

    def close(self) -> None:
        loop = self._loop
        if loop is None:
            return
        loop.call_soon_threadsafe(loop.stop)
        if not self._stop.wait(timeout=5.0):
            raise RuntimeError("Verifier loop thread did not stop cleanly.")
        self._loop = None


class _RpcBridgeReplicaEndpointSession:
    def __init__(self, *, target: str) -> None:
        self._target = target
        self._channel = self._createChannel(target=target)
        self._stub = rpc_opnet_bridge_grpc.RpcOpnetBridgeEndpointStub(self._channel)
        self._appId = ""
        self._endpointId = ""

    @staticmethod
    def _createChannel(*, target: str) -> Channel:
        if target.startswith("unix:///"):
            return Channel(path=target[len("unix:///") :])
        if target.startswith("tcp://"):
            hostPort = target[len("tcp://") :]
            host, sep, portRaw = hostPort.rpartition(":")
            if sep != ":" or not host or not portRaw:
                raise RuntimeError(f"Invalid tcp target for rpc bridge session: {target}")
            return Channel(host=host, port=int(portRaw))
        raise RuntimeError(f"Unsupported rpc bridge target: {target}")

    async def async_sendHello(self, *, app_id: str, endpoint_id: str) -> None:
        self._appId = app_id
        self._endpointId = endpoint_id

    async def _async_openStreamWithHello(self):
        if not self._appId:
            raise RuntimeError("Bridge session missing app_id; async_sendHello must be called first.")
        streamContext = self._stub.Stream.open()
        try:
            stream = await streamContext.__aenter__()
            hello = rpc_opnet_bridge_pb2.EndpointEnvelope()
            hello.hello.app_id = self._appId
            hello.hello.endpoint_id = self._endpointId
            await stream.send_message(hello)
            return streamContext, stream
        except Exception:
            with contextlib.suppress(Exception):
                await streamContext.__aexit__(None, None, None)
            raise

    async def async_sendApiRequest(
        self,
        request: RpcOpnetBridgeRequest,
    ) -> rpc_opnet_bridge_pb2.ReplicaApiResponse:
        streamContext = None
        try:
            streamContext, stream = await self._async_openStreamWithHello()
            apiRequest = rpc_opnet_bridge_pb2.EndpointEnvelope()
            apiRequest.api_request.payload = request.payload
            if request.deadline_ts_unix_ms > 0:
                deadlineTs = timestamp_pb2.Timestamp()
                deadlineTs.FromMilliseconds(request.deadline_ts_unix_ms)
                apiRequest.api_request.deadline_ts.CopyFrom(deadlineTs)
            if request.payload_serialization_format > 0:
                apiRequest.api_request.payload_serialization_format = request.payload_serialization_format
            if request.payload_type_url.strip():
                apiRequest.api_request.payload_type_url = request.payload_type_url.strip()
            await stream.send_message(apiRequest, end=True)
            response = await asyncio.wait_for(
                stream.recv_message(),
                timeout=_DEFAULT_BRIDGE_RESPONSE_TIMEOUT_SECONDS,
            )
            if response is None or not response.HasField("api_response"):
                raise ReplicaConnectionBroken("Bridge endpoint stream closed without api_response.")
            return response.api_response
        except (OSError, ConnectionError, asyncio.TimeoutError) as exc:
            raise ReplicaConnectionBroken(
                f"Bridge endpoint request failed for target={self._target}"
            ) from exc
        finally:
            if streamContext is not None:
                await streamContext.__aexit__(None, None, None)

    async def async_fetchResponse(self, *, bridge_trace_id: str):
        streamContext = None
        try:
            streamContext, stream = await self._async_openStreamWithHello()
            fetch = rpc_opnet_bridge_pb2.EndpointEnvelope()
            fetch.fetch_response.bridge_trace_id = bridge_trace_id
            await stream.send_message(fetch, end=True)
            response = await asyncio.wait_for(
                stream.recv_message(),
                timeout=_DEFAULT_BRIDGE_FETCH_TIMEOUT_SECONDS,
            )
            if response is None or not response.HasField("api_response"):
                return None
            apiResponse = response.api_response
            return rpc_opnet_bridge_pb2.ReplicaApiResponse(
                ok=apiResponse.ok,
                payload=apiResponse.payload,
                error=apiResponse.error,
                bridge_trace_id=apiResponse.bridge_trace_id,
            )
        except asyncio.TimeoutError:
            return None
        except (OSError, ConnectionError) as exc:
            raise ReplicaConnectionBroken(f"Bridge fetch failed for target={self._target}") from exc
        finally:
            if streamContext is not None:
                await streamContext.__aexit__(None, None, None)

    async def async_sendResponseAck(
        self,
        *,
        bridge_trace_id: str,
        endpoint_id: str,
    ) -> None:
        streamContext = None
        try:
            streamContext, stream = await self._async_openStreamWithHello()
            ack = rpc_opnet_bridge_pb2.EndpointEnvelope()
            ack.response_ack.bridge_trace_id = bridge_trace_id
            ack.response_ack.endpoint_id = endpoint_id
            await stream.send_message(ack, end=True)
        finally:
            if streamContext is not None:
                await streamContext.__aexit__(None, None, None)

    async def async_close(self) -> None:
        self._channel.close()


class StandaloneGraphTestDriver:
    _publishedByClass: set[tuple[str, str]] = set()

    def __init__(
        self,
        *,
        clusterAsyncPgConnFactory: Callable[[], Awaitable[object]],
        graphObject: dag_pb2.Dag | Graph | type[Graph] | object,
        publisher: BasePublisher,
        generatorAndVerifier: SyncGeneratorAndVerifier | AsyncGeneratorAndVerifier,
        testClassName: str,
        owner: str = _DEFAULT_OWNER,
        cartondTarget: str = _DEFAULT_CARTOND_TARGET,
        statusTimeoutSeconds: float = _DEFAULT_STATUS_TIMEOUT_SECONDS,
        statusPollSeconds: float = _DEFAULT_STATUS_POLL_SECONDS,
        bridgeReplicaIds: Sequence[str] = (
            "bridge-shard-0-replica-0",
            "bridge-shard-0-replica-1",
        ),
        flowServerFactory: Callable[[FlowServerFactoryContext], FlowServerService] | None = None,
        enableCreateLoop: bool = True,
        appId: str | None = None,
    ) -> None:
        if not testClassName.strip():
            raise ValueError("testClassName must be provided")
        if not owner.strip():
            raise ValueError("owner must be provided")
        self._clusterAsyncPgConnFactory = clusterAsyncPgConnFactory
        self._graphObject = graphObject
        self._publisher = publisher
        self._generatorAndVerifier = generatorAndVerifier
        self._testClassName = testClassName.strip()
        self._owner = owner.strip()
        self._cartondTarget = (cartondTarget or "").strip() or _DEFAULT_CARTOND_TARGET
        self._statusTimeoutSeconds = max(float(statusTimeoutSeconds), 1.0)
        self._statusPollSeconds = max(float(statusPollSeconds), 0.01)
        self._bridgeReplicaIds = tuple(replicaId.strip() for replicaId in bridgeReplicaIds if replicaId.strip())
        self._flowServerFactory = flowServerFactory
        self._enableCreateLoop = bool(enableCreateLoop)
        self._appId = (appId or "").strip() or f"standalone-graph-{uuid.uuid4().hex}"

    async def async_run(self) -> None:
        await self._async_publishOncePerTestClass()
        dag = self._materializeDag()
        mode = self._resolveExecutionMode(dag=dag)
        runtime = await self._async_startRuntime(dag=dag, mode=mode)
        jobId = ""
        try:
            submitResponse = await runtime.flowServerStub.SubmitJob(
                flow_server_pb2.SubmitJobRequest(
                    owner=self._owner,
                    cluster_id=str(runtime.clusterId),
                    job_dag=dag,
                    app_id=self._appId if mode == "sync" else "",
                )
            )
            jobId = submitResponse.job_id
            await self._async_waitForJobStatus(
                flowServerStub=runtime.flowServerStub,
                jobId=jobId,
                expectedStatus=flow_server_pb2.JOB_STATUS_CREATED,
            )
            await runtime.flowServerStub.StartJob(flow_server_pb2.StartJobRequest(job_id=jobId))
            await self._async_waitForJobStatus(
                flowServerStub=runtime.flowServerStub,
                jobId=jobId,
                expectedStatus=flow_server_pb2.JOB_STATUS_STARTED,
            )
            await self._async_maybeSetRunContext(
                runContext=StandaloneGraphRunContext(
                    clusterId=runtime.clusterId,
                    jobId=jobId,
                    sessionMaker=runtime.sessionMaker,
                    flowServerStub=runtime.flowServerStub,
                )
            )
            if mode == "sync":
                await self._async_runSync(
                    dag=dag,
                    bridgeRuntime=runtime.bridgeRuntime,
                    generatorAndVerifier=self._requireSyncGeneratorAndVerifier(),
                )
            else:
                await self._async_runAsync(
                    flowServerStub=runtime.flowServerStub,
                    jobId=jobId,
                    generatorAndVerifier=self._requireAsyncGeneratorAndVerifier(),
                )
        finally:
            if jobId:
                await self._async_cancelJobBestEffort(
                    flowServerStub=runtime.flowServerStub,
                    jobId=jobId,
                )
            await self._async_stopRuntime(runtime)

    def _materializeDag(self) -> dag_pb2.Dag:
        graphObject = self._graphObject
        if isinstance(graphObject, dag_pb2.Dag):
            copied = dag_pb2.Dag()
            copied.CopyFrom(graphObject)
            return copied

        graphInstance = graphObject
        if isinstance(graphObject, type):
            if not issubclass(graphObject, Graph):
                raise TypeError("graphObject class must derive from Graph.")
            graphInstance = graphObject()

        if isinstance(graphInstance, Graph):
            return graphInstance.materializeDag()

        materializeMethod = getattr(graphInstance, "materializeDag", None)
        if callable(materializeMethod):
            dag = materializeMethod()
            if isinstance(dag, dag_pb2.Dag):
                return dag
            raise TypeError("graphObject.materializeDag() must return dag_pb2.Dag")

        buildDagMethod = getattr(graphInstance, "buildDag", None)
        if callable(buildDagMethod):
            dag = buildDagMethod()
            if isinstance(dag, dag_pb2.Dag):
                return dag
            raise TypeError("graphObject.buildDag() must return dag_pb2.Dag")

        raise TypeError(
            "graphObject must be dag_pb2.Dag, Graph instance/class, or expose materializeDag/buildDag."
        )

    def _resolveExecutionMode(self, *, dag: dag_pb2.Dag) -> str:
        if isinstance(self._generatorAndVerifier, SyncGeneratorAndVerifier):
            if dag.graph_type != dag_pb2.GraphType.SYNC:
                raise ValueError("SyncGeneratorAndVerifier requires a sync graph.")
            return "sync"
        if isinstance(self._generatorAndVerifier, AsyncGeneratorAndVerifier):
            if dag.graph_type != dag_pb2.GraphType.ASYNC:
                raise ValueError("AsyncGeneratorAndVerifier requires an async graph.")
            return "async"
        raise TypeError("generatorAndVerifier must implement SyncGeneratorAndVerifier or AsyncGeneratorAndVerifier")

    def _requireSyncGeneratorAndVerifier(self) -> SyncGeneratorAndVerifier:
        value = self._generatorAndVerifier
        if not isinstance(value, SyncGeneratorAndVerifier):
            raise TypeError("Sync mode requires SyncGeneratorAndVerifier")
        return value

    def _requireAsyncGeneratorAndVerifier(self) -> AsyncGeneratorAndVerifier:
        value = self._generatorAndVerifier
        if not isinstance(value, AsyncGeneratorAndVerifier):
            raise TypeError("Async mode requires AsyncGeneratorAndVerifier")
        return value

    async def _async_maybeSetRunContext(self, *, runContext: StandaloneGraphRunContext) -> None:
        setter = getattr(self._generatorAndVerifier, "setRunContext", None)
        if not callable(setter):
            return
        result = setter(runContext)
        if asyncio.iscoroutine(result):
            await result

    async def _async_publishOncePerTestClass(self) -> None:
        publisherKey = f"{type(self._publisher).__module__}.{type(self._publisher).__qualname__}"
        cacheKey = (self._testClassName, publisherKey)
        if cacheKey in self._publishedByClass:
            return
        await self._publisher.publish()
        self._publishedByClass.add(cacheKey)

    async def _async_startRuntime(self, *, dag: dag_pb2.Dag, mode: str) -> _Runtime:
        clusterId = uuid.uuid4()
        engine = create_async_engine(
            "cockroachdb+asyncpg://",
            async_creator=self._clusterAsyncPgConnFactory,
            pool_pre_ping=True,
            poolclass=NullPool,
        )
        sessionMaker = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)
        async with sessionMaker.begin() as session:
            await session.execute(
                insert(TabClusters).values(
                    id=clusterId,
                    name=f"cluster-{clusterId.hex[:8]}",
                )
            )

        baseOpnetPlugin = InMemoryOpNetControllerPlugin()

        grpcOpnetUdsPath = self._buildUniqueUdsPath(prefix="grpc-opnet")
        grpcOpnetServer = await startInMemoryOpNetServer(
            bus=baseOpnetPlugin.bus,
            bind=self._buildUnixTarget(grpcOpnetUdsPath),
        )

        opnetPlugin = AnnouncingOpNetControllerPlugin(
            bus=baseOpnetPlugin.bus,
            scheme="unix",
            target=grpcOpnetUdsPath,
        )
        opnetNodeCollection = OpNetNodeCollection(
            cluster_id=clusterId,
            usecase="OPERATORS",
            plugin=opnetPlugin,
        )
        opnetLinkCollection = OpNetLinkCollection(
            cluster_id=clusterId,
            usecase="OPERATORS",
            plugin=opnetPlugin,
        )
        opnetControllerCollection = OpNetControllerCollection(
            cluster_id=clusterId,
            usecase="OPERATORS",
            plugin=opnetPlugin,
            node_collection=opnetNodeCollection,
            link_collection=opnetLinkCollection,
            node_session_maker=sessionMaker,
            heartbeat_batching_interval_s=0.01,
        )
        opnetManagerService = OpNetManagerService(
            controller_collection=opnetControllerCollection,
            controller_session_maker=sessionMaker,
        )
        opnetControllerService = OpNetControllerService(
            controller_collection=opnetControllerCollection,
            link_collection=opnetLinkCollection,
            node_session_maker=sessionMaker,
        )

        opnetUdsPath = self._buildUniqueUdsPath(prefix="opnet-controller")
        opnetServer = Server([opnetManagerService, opnetControllerService])
        await NetTarget.parseTarget(opnetUdsPath).withUdsMode(0o666).async_bindGrpclibServer(opnetServer)
        opnetChannel = Channel(path=opnetUdsPath)
        opnetManagerClient = opnet_controller_grpc.OpNetManagerServiceStub(opnetChannel)

        casEntries = sidecar_cas.loadDefaultSidecarEntries(hashScheme="sha256")
        casService = sidecar_cas.SidecarCasService(
            entries=casEntries,
            hashScheme="sha256",
        )
        casServer = Server([casService])
        casPort = self._findFreeTcpPort()
        casTarget = f"tcp://127.0.0.1:{casPort}"
        await NetTarget.parseTarget(casTarget).withUdsMode(0o666).async_bindGrpclibServer(casServer)
        casChannel = Channel(host="127.0.0.1", port=casPort)
        casClient = cas_grpc.CasServiceStub(casChannel)

        otlpUdsPath = self._buildUniqueUdsPath(prefix="otlp-logs")
        otlpEndpoint = f"unix:///{otlpUdsPath.lstrip('/')}"
        otlpServer = grpc.aio.server()
        logs_service_pb2_grpc.add_LogsServiceServicer_to_server(_NoopOtelCollector(), otlpServer)
        boundPort = await NetTarget.parseTarget(otlpEndpoint).withUdsMode(0o666).async_bindGrpcAioServer(
            otlpServer
        )
        if boundPort == 0:
            raise RuntimeError(f"Failed to bind OTLP collector on {otlpEndpoint}")

        executorService = ExecutorControlService(
            LocalExecutorController(cartondTarget=self._cartondTarget),
            session_maker=sessionMaker,
            casTarget=casTarget,
        )
        executorUdsPath = self._buildUniqueUdsPath(prefix="executor-control")
        executorServer = Server([executorService])
        await NetTarget.parseTarget(executorUdsPath).withUdsMode(0o666).async_bindGrpclibServer(executorServer)
        executorChannel = Channel(path=executorUdsPath)
        executorControlClient = executor_control_service_grpc.ExecutorControlServiceStub(executorChannel)

        bridgeReplicaToLinkRef: dict[str, str] = {}
        if mode == "sync":
            grpcOpnetTarget = self._buildUnixTarget(grpcOpnetUdsPath)
            for replicaId in self._bridgeReplicaIds:
                bridgeReplicaToLinkRef[replicaId] = f"{grpcOpnetTarget}:{replicaId}"

        flowServerFactory = self._flowServerFactory or self._buildDefaultFlowServer
        flowServer = flowServerFactory(
            FlowServerFactoryContext(
                sessionMaker=sessionMaker,
                clusterId=clusterId,
                opnetManagerClient=opnetManagerClient,
                executorControlClient=executorControlClient,
                casClient=casClient,
                opnetControllerTarget=self._buildUnixTarget(opnetUdsPath),
                sidecarGrpcOpnetTarget=self._buildUnixTarget(grpcOpnetUdsPath),
                sidecarOtelLogsEndpoint=otlpEndpoint,
                bridgeReplicaToLinkRef=bridgeReplicaToLinkRef,
                enableBridgeBootstrap=(mode == "sync"),
                enableCreateLoop=self._enableCreateLoop,
            )
        )
        self._stubNodeStatusesRunning(flowServer=flowServer)

        flowServerUdsPath = self._buildUniqueUdsPath(prefix="flow-server")
        flowServerServer = Server([flowServer])
        await NetTarget.parseTarget(flowServerUdsPath).withUdsMode(0o666).async_bindGrpclibServer(flowServerServer)
        flowServerChannel = Channel(path=flowServerUdsPath)
        flowServerStub = flow_server_grpc.FlowServerStub(flowServerChannel)

        bridgeRuntime: _BridgeRuntime | None = None
        if mode == "sync":
            bridgeRuntime = await self._async_startBridgeRuntime(
                flowServerUdsPath=flowServerUdsPath,
                grpcOpnetUdsPath=grpcOpnetUdsPath,
                appId=self._appId,
            )

        return _Runtime(
            clusterId=clusterId,
            engine=engine,
            sessionMaker=sessionMaker,
            grpcOpnetUdsPath=grpcOpnetUdsPath,
            grpcOpnetServer=grpcOpnetServer,
            opnetControllerCollection=opnetControllerCollection,
            opnetServer=opnetServer,
            opnetUdsPath=opnetUdsPath,
            opnetChannel=opnetChannel,
            opnetManagerClient=opnetManagerClient,
            casServer=casServer,
            casChannel=casChannel,
            casTarget=casTarget,
            casClient=casClient,
            executorService=executorService,
            executorServer=executorServer,
            executorUdsPath=executorUdsPath,
            executorChannel=executorChannel,
            otlpServer=otlpServer,
            otlpUdsPath=otlpUdsPath,
            otlpEndpoint=otlpEndpoint,
            flowServer=flowServer,
            flowServerServer=flowServerServer,
            flowServerUdsPath=flowServerUdsPath,
            flowServerChannel=flowServerChannel,
            flowServerStub=flowServerStub,
            bridgeRuntime=bridgeRuntime,
        )

    def _buildDefaultFlowServer(self, context: FlowServerFactoryContext) -> FlowServerService:
        return FlowServerService(
            session_maker=context.sessionMaker,
            cluster_id=context.clusterId,
            opnet_manager_client=context.opnetManagerClient,
            executor_control_client=context.executorControlClient,
            cas_client=context.casClient,
            enableCreateLoop=context.enableCreateLoop,
            opnetControllerTarget=context.opnetControllerTarget,
            sidecarGrpcOpnetTarget=context.sidecarGrpcOpnetTarget,
            sidecarOtelLogsEndpoint=context.sidecarOtelLogsEndpoint,
            bridgeReplicaToLinkRef=context.bridgeReplicaToLinkRef,
            enableBridgeBootstrap=context.enableBridgeBootstrap,
        )

    def _stubNodeStatusesRunning(self, *, flowServer: FlowServerService) -> None:
        async def _async_getNodeStatuses(request):
            response = opnet_controller_pb2.OpNetGetNodeStatusesResponse()
            timestamp = timestamp_pb2.Timestamp()
            timestamp.GetCurrentTime()
            for nodeId in request.node_ids:
                entry = response.entries.add(
                    node_id=nodeId,
                    status=opnet_types_pb2.RUNNING,
                    has_heartbeat=True,
                )
                entry.last_contact_ts.CopyFrom(timestamp)
                entry.heartbeat_ts.CopyFrom(timestamp)
            return response

        flowServer._opnet_manager_client.GetNodeStatuses = _async_getNodeStatuses

    async def _async_startBridgeRuntime(
        self,
        *,
        flowServerUdsPath: str,
        grpcOpnetUdsPath: str,
        appId: str,
    ) -> _BridgeRuntime:
        replicaStopEvent = asyncio.Event()
        replicaTasks: list[asyncio.Task[None]] = []
        replicaSocketPaths: list[str] = []
        endpointTargetByReplicaId: dict[str, str] = {}
        peerTargetByReplicaId: dict[str, str] = {}

        bridgeReplicaSpecs: list[str] = []
        for replicaId in self._bridgeReplicaIds:
            peerSocket = self._buildUniqueUdsPath(prefix=f"rpc-bridge-peer-{replicaId}")
            endpointSocket = self._buildUniqueUdsPath(prefix=f"rpc-bridge-endpoint-{replicaId}")
            replicaSocketPaths.extend([peerSocket, endpointSocket])
            peerTarget = self._buildUnixTarget(peerSocket)
            endpointTarget = self._buildUnixTarget(endpointSocket)
            peerTargetByReplicaId[replicaId] = peerTarget
            endpointTargetByReplicaId[replicaId] = endpointTarget
            bridgeReplicaSpecs.append(f"bridge-shard-0:{replicaId}={peerTarget}")

        flowServerTarget = self._buildUnixTarget(flowServerUdsPath)
        for replicaId in self._bridgeReplicaIds:
            args = argparse.Namespace(
                shard_id="bridge-shard-0",
                replica_id=replicaId,
                endpoint_listen_address=endpointTargetByReplicaId[replicaId],
                peer_listen_address=peerTargetByReplicaId[replicaId],
                opnet_server_address=self._buildUnixTarget(grpcOpnetUdsPath),
                flow_server_address=flowServerTarget,
                bridge_replica=bridgeReplicaSpecs,
                max_cached_traces=256,
                peer_reconnect_initial_delay_ms=10,
                peer_reconnect_max_delay_ms=200,
                peer_reconnect_backoff_multiplier=2.0,
                peer_reconnect_jitter_ratio=0.0,
            )
            replicaTasks.append(
                asyncio.create_task(
                    rpc_grpc_opnet_bridge_replica_main.async_runReplica(
                        args,
                        stop_event=replicaStopEvent,
                    )
                )
            )

        async def _async_sessionFactory(shardId: int, replicaId: str):
            del shardId
            target = endpointTargetByReplicaId.get(replicaId)
            if target is None:
                raise RuntimeError(f"Unknown bridge replica id: {replicaId}")
            return _RpcBridgeReplicaEndpointSession(target=target)

        bridgeClient = RpcOpnetBridgeClient(
            app_id=appId,
            shard_to_replicas={0: list(self._bridgeReplicaIds)},
            session_factory=_async_sessionFactory,
            endpoint_id=f"standalone-graph-driver-{uuid.uuid4().hex}",
        )
        return _BridgeRuntime(
            appId=appId,
            client=bridgeClient,
            stopEvent=replicaStopEvent,
            replicaTasks=replicaTasks,
            replicaSocketPaths=replicaSocketPaths,
        )

    async def _async_runSync(
        self,
        *,
        dag: dag_pb2.Dag,
        bridgeRuntime: _BridgeRuntime | None,
        generatorAndVerifier: SyncGeneratorAndVerifier,
    ) -> None:
        if bridgeRuntime is None:
            raise RuntimeError("Bridge runtime is required for sync execution.")
        responseTypeUrl = self._resolveSyncResponseTypeUrl(dag=dag)
        while True:
            requestAny = await generatorAndVerifier.generate()
            if requestAny is None:
                return
            if not requestAny.type_url.strip():
                raise RuntimeError("Sync generate() returned Any without type_url")
            bridgeResponse = await bridgeRuntime.client.async_makeApiCall(
                RpcOpnetBridgeRequest(
                    payload=requestAny.value,
                    deadline_ts_unix_ms=int(time.time() * 1000) + _DEFAULT_BRIDGE_CALL_TIMEOUT_MS,
                    payload_serialization_format=int(
                        opnet_types_pb2.OpNetPayloadType.SerializationFormat.PROTO
                    ),
                    payload_type_url=requestAny.type_url,
                )
            )
            if not bridgeResponse.ok:
                raise RuntimeError(
                    f"Bridge call failed: {bridgeResponse.error.strip() or '<empty>'}"
                )
            responseAny = any_pb2.Any(type_url=responseTypeUrl, value=bridgeResponse.payload)
            verified = await generatorAndVerifier.verify(responseAny)
            if not verified:
                raise AssertionError("Sync verification failed")

    async def _async_runAsync(
        self,
        *,
        flowServerStub: flow_server_grpc.FlowServerStub,
        jobId: str,
        generatorAndVerifier: AsyncGeneratorAndVerifier,
    ) -> None:
        verifierLoop = _VerifierLoopThread()
        verifierLoop.start()
        try:
            await verifierLoop.async_runCoroutine(generatorAndVerifier.startVerifier())
            while True:
                messageAny = await generatorAndVerifier.generate()
                if messageAny is None:
                    break
                if not messageAny.type_url.strip():
                    raise RuntimeError("Async generate() returned Any without type_url")
                injectResponse = await flowServerStub.InjectMessage(
                    flow_server_pb2.InjectMessageRequest(
                        job_id=jobId,
                        message=opnet_types_pb2.OpNetMessage(
                            message_context=opnet_types_pb2.MessageContext(trace_id=str(uuid.uuid4())),
                            payload_type=opnet_types_pb2.OpNetPayloadType(
                                serialization_format=opnet_types_pb2.OpNetPayloadType.PROTO,
                                type_url=messageAny.type_url,
                            ),
                            payload=messageAny.value,
                        ),
                    )
                )
                if not injectResponse.accepted:
                    raise RuntimeError(f"InjectMessage rejected: {injectResponse.details}")
            verified = await verifierLoop.async_runCoroutine(generatorAndVerifier.getVerificationResult())
            if not verified:
                raise AssertionError("Async verification failed")
        finally:
            verifierLoop.close()

    async def _async_waitForJobStatus(
        self,
        *,
        flowServerStub: flow_server_grpc.FlowServerStub,
        jobId: str,
        expectedStatus: int,
        timeoutSeconds: float | None = None,
    ) -> flow_server_pb2.GetJobStatusResponse:
        timeout = self._statusTimeoutSeconds if timeoutSeconds is None else max(float(timeoutSeconds), 0.1)
        deadline = asyncio.get_running_loop().time() + timeout
        lastResponse: flow_server_pb2.GetJobStatusResponse | None = None
        while asyncio.get_running_loop().time() < deadline:
            response = await flowServerStub.GetJobStatus(flow_server_pb2.GetJobStatusRequest(job_id=jobId))
            lastResponse = response
            if response.status == expectedStatus:
                return response
            await asyncio.sleep(self._statusPollSeconds)
        raise TimeoutError(
            f"job_id={jobId} did not reach expected status={expectedStatus}; "
            f"last_status={(lastResponse.status if lastResponse else 'none')}"
        )

    async def _async_cancelJobBestEffort(self, *, flowServerStub: flow_server_grpc.FlowServerStub, jobId: str) -> None:
        with contextlib.suppress(Exception):
            await flowServerStub.CancelJob(
                flow_server_pb2.CancelJobRequest(
                    job_id=jobId,
                    reason="StandaloneGraphTestDriver cleanup",
                )
            )
        with contextlib.suppress(Exception):
            await self._async_waitForJobStatus(
                flowServerStub=flowServerStub,
                jobId=jobId,
                expectedStatus=flow_server_pb2.JOB_STATUS_CANCELLED,
                timeoutSeconds=90.0,
            )

    async def _async_stopRuntime(self, runtime: _Runtime) -> None:
        if runtime.bridgeRuntime is not None:
            await runtime.bridgeRuntime.client.async_close()
            runtime.bridgeRuntime.stopEvent.set()
            if runtime.bridgeRuntime.replicaTasks:
                with contextlib.suppress(Exception):
                    await asyncio.wait_for(
                        asyncio.gather(*runtime.bridgeRuntime.replicaTasks, return_exceptions=True),
                        timeout=10.0,
                    )
            for socketPath in runtime.bridgeRuntime.replicaSocketPaths:
                self._unlinkBestEffort(socketPath)

        runtime.flowServerChannel.close()
        runtime.flowServerServer.close()
        with contextlib.suppress(Exception):
            await asyncio.wait_for(runtime.flowServerServer.wait_closed(), timeout=5.0)
        self._unlinkBestEffort(runtime.flowServerUdsPath)

        with contextlib.suppress(Exception):
            await runtime.flowServer.async_close()

        with contextlib.suppress(Exception):
            await runtime.executorService.async_close()

        runtime.executorChannel.close()
        runtime.executorServer.close()
        with contextlib.suppress(Exception):
            await runtime.executorServer.wait_closed()
        self._unlinkBestEffort(runtime.executorUdsPath)

        runtime.casChannel.close()
        runtime.casServer.close()
        with contextlib.suppress(Exception):
            await runtime.casServer.wait_closed()

        runtime.opnetChannel.close()
        runtime.opnetServer.close()
        with contextlib.suppress(Exception):
            await runtime.opnetServer.wait_closed()
        runtime.grpcOpnetServer.close()
        with contextlib.suppress(Exception):
            await runtime.grpcOpnetServer.wait_closed()

        with contextlib.suppress(Exception):
            await runtime.opnetControllerCollection.async_close()

        with contextlib.suppress(Exception):
            await runtime.otlpServer.stop(grace=0.5)

        self._unlinkBestEffort(runtime.opnetUdsPath)
        self._unlinkBestEffort(runtime.grpcOpnetUdsPath)
        self._unlinkBestEffort(runtime.otlpUdsPath)

        with contextlib.suppress(Exception):
            await runtime.engine.dispose()

    @staticmethod
    def _resolveSyncResponseTypeUrl(*, dag: dag_pb2.Dag) -> str:
        for link in dag.links:
            if link.link_type != dag_pb2.Link.SYNC_RETRIEVER:
                continue
            payloadTypeUrl = link.payload_type.type_url.strip()
            if not payloadTypeUrl:
                raise ValueError("SYNC_RETRIEVER link payload type_url must be set")
            return StandaloneGraphTestDriver._canonicalizeAnyTypeUrl(payloadTypeUrl)
        raise ValueError("Sync graph must define a SYNC_RETRIEVER link.")

    @staticmethod
    def _canonicalizeAnyTypeUrl(typeUrl: str) -> str:
        normalized = typeUrl.strip()
        if not normalized:
            raise ValueError("type_url must be non-empty")
        if "/" in normalized:
            return normalized
        return f"{_CANONICAL_ANY_TYPE_PREFIX}{normalized}"

    @staticmethod
    def _buildUniqueUdsPath(*, prefix: str) -> str:
        path = os.path.join(tempfile.gettempdir(), f"{prefix}-{uuid.uuid4().hex}.sock")
        with contextlib.suppress(FileNotFoundError):
            os.unlink(path)
        return path

    @staticmethod
    def _unlinkBestEffort(path: str) -> None:
        with contextlib.suppress(FileNotFoundError):
            os.unlink(path)

    @staticmethod
    def _findFreeTcpPort() -> int:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.bind(("127.0.0.1", 0))
            return int(sock.getsockname()[1])

    @staticmethod
    def _buildUnixTarget(socketPath: str) -> str:
        return f"unix:///{socketPath}"


__all__ = [
    "AsyncGeneratorAndVerifier",
    "BasePublisher",
    "FlowServerFactoryContext",
    "StandaloneGraphRunContext",
    "StandaloneGraphTestDriver",
    "SyncGeneratorAndVerifier",
]
