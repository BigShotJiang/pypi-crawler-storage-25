"""CLI binary entrypoint for standalone file-backed OperatorSidecar runtime."""

from __future__ import annotations

import argparse
import asyncio
import logging
import os
import shlex
import socket as _socket
import sys
import time
import uuid
from typing import Optional, Sequence

from lumecode.base.python.logging import lumesof_logging as sidecar_otel_logging
from lumecode.base.python.net.target_parser import NetTarget
from lumecode.lumeflow.runtime.v1.opnet import opnet_types_pb2
from lumecode.lumeflow.runtime.v1.sidecar import operator_sidecar
from lumecode.lumeflow.runtime.v1.test_utils.file_backed_opnet_proxy import (
    FileBackedOpNetProxy,
)

LOG = logging.getLogger(__name__)
_OTEL_SERVICE_NAME = "sidecar"
_DOCKER_HOST_ALIAS = "host.docker.internal"


def _resolveOtelServiceNameFromArgv(argv: Optional[list[str]]) -> str:
  rawArgv = list(argv) if argv is not None else sys.argv[1:]
  parser = argparse.ArgumentParser(add_help=False)
  parser.add_argument("--opnet-node-id", default="")
  try:
    parsedArgs, _ = parser.parse_known_args(rawArgv)
  except Exception:
    return _OTEL_SERVICE_NAME
  nodeId = str(parsedArgs.opnet_node_id or "").strip()
  if not nodeId:
    return _OTEL_SERVICE_NAME
  return f"{_OTEL_SERVICE_NAME}-{nodeId}"


def _buildParser() -> argparse.ArgumentParser:
  parser = argparse.ArgumentParser(
      description="Standalone OperatorSidecar backed by local ingress/egress files"
  )
  parser.add_argument(
      "--bind",
      default="tcp://127.0.0.1:50051",
      help="Sidecar listen target in parseTarget format: tcp://host:port or unix:///path",
  )
  parser.add_argument(
      "--docker-image",
      help="Optional Docker image to run while the sidecar is active",
  )
  parser.add_argument(
      "--docker-name",
      help="Optional name to assign to the Docker container",
  )
  parser.add_argument(
      "--docker-arg",
      dest="docker_args",
      action="append",
      help="Additional argument to pass to `docker run` (can be repeated)",
  )
  parser.add_argument(
      "--docker-command",
      help="Command to execute inside the container after the image name",
  )
  parser.add_argument(
      "--opnet-node-id",
      default="",
      help="Optional logical node id used for logging/observability labels",
  )
  parser.add_argument(
      "--opnet-node-version",
      default="",
      help="Optional node version label for logs",
  )
  parser.add_argument(
      "--opnet-node-backend",
      default="",
      help="Optional node backend label for logs",
  )
  parser.add_argument(
      "--opnet-port",
      dest="opnet_ports",
      action="append",
      required=True,
      help=(
          "OpNet port spec: name,port_type,type_url[,serialization_format]. "
          "port_type is INGRESS/EGRESS/INGRESS_BRIDGE/EGRESS_BRIDGE; "
          "serialization_format defaults to PROTO."
      ),
  )
  parser.add_argument(
      "--ingress-file",
      dest="ingress_files",
      action="append",
      default=[],
      help=(
          "Port-to-file mapping for ingress messages formatted as "
          "'port_name=/path/to/input.bin'."
      ),
  )
  parser.add_argument(
      "--egress-file",
      dest="egress_files",
      action="append",
      default=[],
      help=(
          "Port-to-file mapping for egress messages formatted as "
          "'port_name=/path/to/output.bin'."
      ),
  )
  parser.add_argument(
      "--ack-report-uds-path",
      required=True,
      help=(
          "Unix domain socket path used to report ingress message ACK/NACK "
          "events as JSON-lines payloads."
      ),
  )
  parser.add_argument(
      "--operator-connect-max-attempts",
      type=int,
      default=operator_sidecar.DEFAULT_OPERATOR_CONNECT_MAX_ATTEMPTS,
      help=(
          "Maximum operator connect attempts from inside the container "
          f"(exported as {operator_sidecar.OPERATOR_CONNECT_MAX_ATTEMPTS_ENV})."
      ),
  )
  parser.add_argument(
      "--operator-connect-backoff-ms",
      type=int,
      default=operator_sidecar.DEFAULT_OPERATOR_CONNECT_BACKOFF_MS,
      help=(
          "Backoff in milliseconds between operator connect attempts from "
          "inside the container "
          f"(exported as {operator_sidecar.OPERATOR_CONNECT_BACKOFF_MS_ENV})."
      ),
  )
  parser.add_argument(
      "--logs-dir",
      default="",
      help=(
          "Optional directory to write sidecar process logs. "
          "When set, file logging is used and OTel log export settings are ignored."
      ),
  )
  sidecar_otel_logging.addOtelLogFlags(parser, includeServiceNameFlag=False)
  return parser


def _allocateFreePort() -> int:
  with _socket.socket(_socket.AF_INET, _socket.SOCK_STREAM) as s:
    s.setsockopt(_socket.SOL_SOCKET, _socket.SO_REUSEADDR, 1)
    s.bind(("127.0.0.1", 0))
    return s.getsockname()[1]


def _normalizeBindTarget(bindTarget: str) -> str:
  parsed = NetTarget.parseTarget(bindTarget)
  if parsed.getPath() is not None:
    return f"unix:///{parsed.getPath()}"
  return f"{parsed.getHost()}:{parsed.getPort()}"


def _ensureStandaloneDockerLocalhostAccessArgs(
    dockerArgs: Sequence[str],
) -> list[str]:
  normalized: list[str] = []
  hasHostAlias = False
  hasNetwork = False

  i = 0
  while i < len(dockerArgs):
    token = dockerArgs[i]

    if token == "--network":
      if i + 1 >= len(dockerArgs):
        raise RuntimeError("--network requires a value")
      networkValue = dockerArgs[i + 1]
      normalized.extend(["--network", networkValue])
      hasNetwork = True
      i += 2
      continue

    if token.startswith("--network="):
      normalized.append(token)
      hasNetwork = True
      i += 1
      continue

    if token == "--add-host":
      if i + 1 >= len(dockerArgs):
        raise RuntimeError("--add-host requires a value")
      hostValue = dockerArgs[i + 1]
      hostName, sep, hostAddress = hostValue.partition(":")
      if not sep or not hostName or not hostAddress:
        raise RuntimeError(f"Invalid --add-host value {hostValue!r}")
      if hostName == _DOCKER_HOST_ALIAS:
        normalized.extend(["--add-host", f"{_DOCKER_HOST_ALIAS}:host-gateway"])
        hasHostAlias = True
      else:
        normalized.extend(["--add-host", hostValue])
      i += 2
      continue

    if token.startswith("--add-host="):
      hostValue = token.split("=", 1)[1]
      hostName, sep, hostAddress = hostValue.partition(":")
      if not sep or not hostName or not hostAddress:
        raise RuntimeError(f"Invalid --add-host value {hostValue!r}")
      if hostName == _DOCKER_HOST_ALIAS:
        normalized.append(f"--add-host={_DOCKER_HOST_ALIAS}:host-gateway")
        hasHostAlias = True
      else:
        normalized.append(token)
      i += 1
      continue

    normalized.append(token)
    i += 1

  if not hasHostAlias:
    normalized.append(f"--add-host={_DOCKER_HOST_ALIAS}:host-gateway")
  if not hasNetwork:
    normalized.append("--network=bridge")
  return normalized


def _resolveDockerSidecarUri(*, bindTarget: str) -> str:
  parsed = NetTarget.parseTarget(bindTarget)
  if parsed.getPath() is not None:
    return bindTarget
  host = (parsed.getHost() or "").strip().lower()
  if host in ("127.0.0.1", "localhost", "0.0.0.0", "::1"):
    return f"tcp://{_DOCKER_HOST_ALIAS}:{parsed.getPort()}"
  return f"tcp://{parsed.getHost()}:{parsed.getPort()}"


def _parsePortFileMappings(
    entries: Sequence[str],
    *,
    flagName: str,
) -> dict[str, str]:
  mappings: dict[str, str] = {}
  for entry in entries:
    if "=" not in entry:
      raise RuntimeError(f"{flagName} must be formatted as port_name=/path/to/file: {entry}")
    portNameRaw, filePathRaw = entry.split("=", 1)
    portName = portNameRaw.strip()
    filePath = filePathRaw.strip()
    if not portName:
      raise RuntimeError(f"{flagName} contains empty port name: {entry}")
    if not filePath:
      raise RuntimeError(f"{flagName} contains empty file path: {entry}")
    if portName in mappings:
      raise RuntimeError(f"Duplicate {flagName} mapping for port={portName}")
    mappings[portName] = filePath
  return mappings


def _validatePortAndFileMappings(
    *,
    ports: Sequence[opnet_types_pb2.OpNetPort],
    ingressFilesByPort: dict[str, str],
    egressFilesByPort: dict[str, str],
) -> list[str]:
  ingressPortKinds = {
      opnet_types_pb2.OpNetPort.PortType.INGRESS,
      opnet_types_pb2.OpNetPort.PortType.INGRESS_BRIDGE,
  }
  egressPortKinds = {
      opnet_types_pb2.OpNetPort.PortType.EGRESS,
      opnet_types_pb2.OpNetPort.PortType.EGRESS_BRIDGE,
  }
  knownPortNames: set[str] = set()
  ingressPortNames: list[str] = []
  egressPortNames: list[str] = []

  for port in ports:
    if port.port_name in knownPortNames:
      raise RuntimeError(f"Duplicate --opnet-port entry for port={port.port_name}")
    knownPortNames.add(port.port_name)
    if port.port_type in ingressPortKinds:
      ingressPortNames.append(port.port_name)
    elif port.port_type in egressPortKinds:
      egressPortNames.append(port.port_name)
    else:
      raise RuntimeError(
          f"Unsupported port type for port={port.port_name}: {port.port_type}"
      )

  missingIngress = [name for name in ingressPortNames if name not in ingressFilesByPort]
  if missingIngress:
    raise RuntimeError(
        "Missing --ingress-file mapping for ingress ports: "
        + ",".join(sorted(missingIngress))
    )
  missingEgress = [name for name in egressPortNames if name not in egressFilesByPort]
  if missingEgress:
    raise RuntimeError(
        "Missing --egress-file mapping for egress ports: "
        + ",".join(sorted(missingEgress))
    )

  extraIngress = sorted(set(ingressFilesByPort.keys()) - set(ingressPortNames))
  if extraIngress:
    raise RuntimeError(
      "Received --ingress-file mapping for non-ingress ports: "
      + ",".join(extraIngress)
    )
  extraEgress = sorted(set(egressFilesByPort.keys()) - set(egressPortNames))
  if extraEgress:
    raise RuntimeError(
      "Received --egress-file mapping for non-egress ports: "
      + ",".join(extraEgress)
    )

  return ingressPortNames


async def _asyncRun(args: argparse.Namespace) -> None:
  defaultBind = "tcp://127.0.0.1:50051"
  if args.bind == defaultBind:
    if args.docker_image:
      port = _allocateFreePort()
      args.bind = f"tcp://0.0.0.0:{port}"
    else:
      args.bind = f"unix:////tmp/lumesof-standalone-sidecar-{uuid.uuid4().hex}.sock"
  bind = _normalizeBindTarget(args.bind)
  dockerArgs = list(args.docker_args or [])
  if args.docker_image:
    dockerArgs = _ensureStandaloneDockerLocalhostAccessArgs(dockerArgs)
  dockerCommand = shlex.split(args.docker_command) if args.docker_command else []
  if args.docker_image and not any("--sidecar-uri" in token for token in dockerCommand):
    dockerSidecarUri = _resolveDockerSidecarUri(bindTarget=args.bind)
    dockerCommand.append(f"--sidecar-uri={dockerSidecarUri}")

  opnetPorts = [
      operator_sidecar._parseOpNetPortSpec(spec)
      for spec in (args.opnet_ports or [])
  ]
  ingressFilesByPort = _parsePortFileMappings(
      args.ingress_files or [],
      flagName="--ingress-file",
  )
  egressFilesByPort = _parsePortFileMappings(
      args.egress_files or [],
      flagName="--egress-file",
  )
  ingressPortOrder = _validatePortAndFileMappings(
      ports=opnetPorts,
      ingressFilesByPort=ingressFilesByPort,
      egressFilesByPort=egressFilesByPort,
  )

  proxy = FileBackedOpNetProxy(
      ingressFilesByPort=ingressFilesByPort,
      egressFilesByPort=egressFilesByPort,
      ingressPortOrder=ingressPortOrder,
      ackReportUdsPath=args.ack_report_uds_path,
  )
  statusTracker = operator_sidecar.OperatorStatusTracker()
  sidecar = operator_sidecar.SimpleOperatorSidecar(
      opnet_proxy=proxy,
      status_tracker=statusTracker,
  )

  await operator_sidecar._asyncMain(
      bind,
      docker_image=args.docker_image,
      docker_name=args.docker_name,
      docker_args=dockerArgs,
      docker_command=dockerCommand,
      opnet_controller_target=None,
      opnet_node_id=None,
      opnet_ports=opnetPorts,
      opnet_node_version=args.opnet_node_version,
      opnet_node_backend=args.opnet_node_backend,
      operator_connect_max_attempts=args.operator_connect_max_attempts,
      operator_connect_backoff_ms=args.operator_connect_backoff_ms,
      sidecar_service=sidecar,
      status_tracker=statusTracker,
  )


def main(argv: Optional[list[str]] = None) -> None:
  logging.basicConfig(level=sidecar_otel_logging.resolveLogLevelFromEnv())
  LOG.info("Starting standalone operator sidecar")
  otelServiceName = _resolveOtelServiceNameFromArgv(argv)
  loggingDestinationsRuntime = sidecar_otel_logging.configureLoggingDestinationsFromEnv(
      defaultServiceName=otelServiceName,
      defaultServiceInstanceId="standalone-sidecar:bootstrap",
      serviceName=otelServiceName,
      otelEndpointEnvVar=sidecar_otel_logging.LUMESOF_OTEL_EXPORTER_OTLP_ENDPOINT_ENV,
      otelServiceNameEnvVar=sidecar_otel_logging.LUMESOF_OTEL_SERVICE_NAME_ENV,
      otelServiceInstanceIdEnvVar=sidecar_otel_logging.LUMESOF_OTEL_SERVICE_INSTANCE_ID_ENV,
  )
  parser = _buildParser()
  parsedArgv = list(argv) if argv is not None else sys.argv[1:]
  parsedArgv = operator_sidecar._normalizeDockerArgFlags(parsedArgv)
  try:
    args = parser.parse_args(parsedArgv)
  except SystemExit as exc:
    if exc.code not in (None, 0):
      LOG.error(f"Argument parsing failed for standalone sidecar argv={parsedArgv}")
      sidecar_otel_logging.flushRootLogHandlers()
      loggingDestinationsRuntime.flush(timeoutSeconds=1.0)
      time.sleep(10)
    raise

  safeNodeId = (args.opnet_node_id or "unknown").replace("/", "_")
  sidecar_otel_logging.addLoggingDestinationsFromArgs(
      runtime=loggingDestinationsRuntime,
      args=args,
      serviceName=otelServiceName,
      serviceInstanceId=f"standalone-sidecar:{args.opnet_node_id or 'unknown'}",
      localLogsDirArgName="logs_dir",
      localLogsFileName=f"standalone-sidecar-{safeNodeId}.log",
  )
  try:
    asyncio.run(_asyncRun(args))
  finally:
    loggingDestinationsRuntime.flush(timeoutSeconds=1.0)
    loggingDestinationsRuntime.shutdown()


if __name__ == "__main__":
  main()
