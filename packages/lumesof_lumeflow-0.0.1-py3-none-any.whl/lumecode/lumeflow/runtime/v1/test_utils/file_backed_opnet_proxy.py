"""File-backed OpNet proxy for standalone operator testing."""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
from pathlib import Path
from typing import Sequence, Tuple

from google.protobuf.internal.decoder import _DecodeVarint32
from google.protobuf.internal.encoder import _VarintBytes

from lumecode.lumeflow.runtime.v1.operator import operator_pb2
from lumecode.lumeflow.runtime.v1.opnet import opnet_types_pb2
from lumecode.lumeflow.runtime.v1.opnet.opnet_proxy import OpNetProxy
from lumecode.lumeflow.runtime.v1.opnet.opnet_types_pb2 import Result

LOG = logging.getLogger(__name__)


def _encodeDelimitedMessage(payload: bytes) -> bytes:
  return _VarintBytes(len(payload)) + payload


def _decodeDelimitedDeliverRequests(
    *,
    payload: bytes,
    filePath: str,
    portName: str,
) -> list[operator_pb2.DeliverRequest]:
  messages: list[operator_pb2.DeliverRequest] = []
  offset = 0
  while offset < len(payload):
    try:
      size, nextOffset = _DecodeVarint32(payload, offset)
    except Exception as exc:  # pragma: no cover - defensive parsing path
      raise RuntimeError(
          f"Failed to decode protobuf length prefix file={filePath} "
          f"port={portName} offset={offset}: {exc}"
      ) from exc
    offset = nextOffset
    endOffset = offset + size
    if endOffset > len(payload):
      raise RuntimeError(
          f"Truncated protobuf payload file={filePath} port={portName} "
          f"offset={offset} size={size} file_size={len(payload)}"
      )
    message = operator_pb2.DeliverRequest()
    try:
      message.ParseFromString(payload[offset:endOffset])
    except Exception as exc:  # pragma: no cover - defensive parsing path
      raise RuntimeError(
          f"Failed to parse DeliverRequest file={filePath} port={portName} "
          f"offset={offset} size={size}: {exc}"
      ) from exc
    if message.port and message.port != portName:
      raise RuntimeError(
          f"DeliverRequest port mismatch file={filePath} expected_port={portName} "
          f"actual_port={message.port}"
      )
    if not message.port:
      message.port = portName
    messages.append(message)
    offset = endOffset
  return messages


class FileBackedOpNetProxy(OpNetProxy):
  """OpNet proxy backed by one-time ingress files and append-only egress files."""

  def __init__(
      self,
      *,
      ingressFilesByPort: dict[str, str],
      egressFilesByPort: dict[str, str],
      ingressPortOrder: Sequence[str],
      ackReportUdsPath: str,
  ) -> None:
    self._ingressFilesByPort = dict(ingressFilesByPort)
    self._egressFilesByPort = dict(egressFilesByPort)
    self._ackReportUdsPath = (ackReportUdsPath or "").strip()
    if not self._ackReportUdsPath:
      raise ValueError("ackReportUdsPath must be set")
    self._ingressQueue: asyncio.Queue[operator_pb2.DeliverRequest] = asyncio.Queue()
    self._loadIngressFiles(ingressPortOrder=ingressPortOrder)

  def _loadIngressFiles(self, *, ingressPortOrder: Sequence[str]) -> None:
    totalMessages = 0
    for portName in ingressPortOrder:
      filePath = self._ingressFilesByPort[portName]
      path = Path(filePath)
      if not path.exists():
        raise RuntimeError(
            f"Ingress file does not exist for port={portName}: {filePath}"
        )
      raw = path.read_bytes()
      messages = _decodeDelimitedDeliverRequests(
          payload=raw,
          filePath=filePath,
          portName=portName,
      )
      for message in messages:
        cloned = operator_pb2.DeliverRequest()
        cloned.CopyFrom(message)
        self._ingressQueue.put_nowait(cloned)
      totalMessages += len(messages)
      LOG.info(
          "Loaded ingress messages from file port=%s file=%s message_count=%d",
          portName,
          filePath,
          len(messages),
      )
    LOG.info("Loaded total ingress messages=%d", totalMessages)

  async def async_setup(
      self,
      *,
      connections: Sequence[opnet_types_pb2.OpNetConnection],
  ) -> Result:
    del connections
    return Result(ok=True)

  async def async_getOpNetMessage(
      self,
  ) -> Tuple[Result, operator_pb2.DeliverRequest]:
    message = await self._ingressQueue.get()
    return Result(ok=True), message

  async def async_putOpNetMessage(
      self,
      request: operator_pb2.DeliverRequest,
  ) -> Result:
    filePath = self._egressFilesByPort.get(request.port)
    if not filePath:
      return Result(
          ok=False,
          message=f"No egress file configured for port={request.port}",
      )
    try:
      path = Path(filePath)
      path.parent.mkdir(parents=True, exist_ok=True)
      cloned = operator_pb2.DeliverRequest()
      cloned.CopyFrom(request)
      payload = cloned.SerializeToString()
      with path.open("ab") as fh:
        fh.write(_encodeDelimitedMessage(payload))
    except Exception as exc:
      return Result(
          ok=False,
          message=(
              f"Failed to write egress message port={request.port} file={filePath}: "
              f"{type(exc).__name__}: {exc}"
          ),
      )
    return Result(ok=True)

  async def async_ack(self, request: operator_pb2.AckRequest) -> Result:
    if not request.message_id:
      LOG.info(
          "Received ack/nack without message_id port=%s; ignoring report",
          request.port or "<none>",
      )
      return Result(ok=True)

    if request.error.code == 0:
      LOG.info(
          "Received ACK from operator port=%s message_id=%s",
          request.port,
          request.message_id or "<none>",
      )
    else:
      LOG.warning(
          "Received NACK from operator port=%s message_id=%s code=%s message=%s",
          request.port,
          request.message_id or "<none>",
          request.error.code,
          request.error.message or "<none>",
      )
    reportStatus = "ack" if request.error.code == 0 else "nack"
    reportPayload = {
        "port": request.port,
        "message": {
            "message_id": request.message_id,
            "status": reportStatus,
        },
    }
    writer = None
    try:
      _, writer = await asyncio.open_unix_connection(self._ackReportUdsPath)
      writer.write((json.dumps(reportPayload, separators=(",", ":")) + "\n").encode("utf-8"))
      await writer.drain()
    except Exception as exc:
      return Result(
          ok=False,
          message=(
              "Failed to report ack/nack over UDS "
              f"path={self._ackReportUdsPath} port={request.port} "
              f"message_id={request.message_id}: {type(exc).__name__}: {exc}"
          ),
      )
    finally:
      if writer is not None:
        writer.close()
        with contextlib.suppress(Exception):
          await writer.wait_closed()
    return Result(ok=True)

  async def async_reset(self, reset_id: str) -> Result:
    LOG.info("Received proxy reset request reset_id=%s", reset_id)
    return Result(ok=True)

  async def async_hasWork(self) -> bool:
    return not self._ingressQueue.empty()


__all__ = [
    "FileBackedOpNetProxy",
    "_decodeDelimitedDeliverRequests",
    "_encodeDelimitedMessage",
]
