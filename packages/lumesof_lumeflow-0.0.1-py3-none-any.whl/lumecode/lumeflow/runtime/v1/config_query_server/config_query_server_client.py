from __future__ import annotations

from grpclib.client import Channel

from lumecode.base.python.net.target_parser import NetTarget
from lumecode.lumeflow.runtime.v1.config_query_server import (
    config_query_server_grpc,
    config_query_server_pb2,
)


class ConfigQueryClientError(ValueError):
    """Raised when a config value cannot be fetched or validated."""


def _normalizeTarget(target: str) -> str:
    if target.startswith("tcp://") or target.startswith("unix:///"):
        return target
    return f"tcp://{target}"


def _buildChannelForTarget(target: str) -> Channel:
    parsedTarget = NetTarget.parseTarget(_normalizeTarget(target))
    udsPath = parsedTarget.getPath()
    if udsPath is not None:
        return Channel(path=udsPath)

    host = parsedTarget.getHost()
    port = parsedTarget.getPort()
    if host is None or port is None:
        raise ValueError(f"target must include host and port: {target}")
    return Channel(host=host, port=port)


async def async_getRequiredStringConfigValue(
    *,
    configServiceTarget: str,
    key: str,
) -> str:
    cleanedKey = key.strip()
    if not cleanedKey:
        raise ConfigQueryClientError("config key must be non-empty.")

    try:
        channel = _buildChannelForTarget(configServiceTarget)
    except Exception as exc:
        raise ConfigQueryClientError(
            f"Failed to open config service channel target={configServiceTarget!r}: {exc}"
        ) from exc

    try:
        stub = config_query_server_grpc.ClusterConfigServiceStub(channel)
        response = await stub.GetConfig(
            config_query_server_pb2.GetConfigRequest(key=cleanedKey)
        )
    except Exception as exc:
        raise ConfigQueryClientError(
            f"Failed to fetch config key={cleanedKey!r} from target={configServiceTarget!r}: {exc}"
        ) from exc
    finally:
        channel.close()

    if not response.HasField("entry"):
        raise ConfigQueryClientError(
            f"Config service returned no entry for key={cleanedKey!r}."
        )

    valueKind = response.entry.value.WhichOneof("kind")
    if valueKind != "string_value":
        raise ConfigQueryClientError(
            f"Config key={cleanedKey!r} must be a string value, got {valueKind or 'unset'}."
        )

    value = response.entry.value.string_value
    if not value.strip():
        raise ConfigQueryClientError(
            f"Config key={cleanedKey!r} must be a non-empty string."
        )
    return value
