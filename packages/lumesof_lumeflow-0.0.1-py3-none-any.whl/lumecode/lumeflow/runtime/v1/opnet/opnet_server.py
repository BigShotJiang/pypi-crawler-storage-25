# grpclib servicer for OpNet controller RPCs.

from __future__ import annotations

import logging
import uuid
from datetime import datetime, timedelta
from typing import Dict, List, Tuple

from google.protobuf import timestamp_pb2
from grpclib import GRPCError
from grpclib.const import Status
from grpclib.server import Stream
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from lumecode.base.python.logging import lumesof_logging
from lumecode.lumeflow.runtime.v1.opnet import opnet_controller_grpc, opnet_controller_pb2, opnet_types_pb2
from lumecode.lumeflow.runtime.v1.opnet.opnet_controller import (
    OpNetControllerCollection,
    OpNetNodeStatusSnapshot,
)
from lumecode.lumeflow.runtime.v1.opnet.opnet_error import OpNetError, OpNetErrorCode
from lumecode.lumeflow.runtime.v1.opnet.opnet_link import OpNetLinkCollection
from lumecode.lumeflow.runtime.v1.opnet.opnet_node import OpNetNodeCollection, PortInfo
from lumecode.crdb.schemas.dev_cluster.flow.db_orm_models import TabControllers, TabLinks

logger = logging.getLogger(__name__)
structuredLogger = lumesof_logging.getLogger(__name__)

def _grpc_status_from_opnet(code: OpNetErrorCode) -> Status:
    """Convert an OpNet error code into the matching gRPC status."""
    try:
        return Status[code.name]
    except (KeyError, ValueError):  # pragma: no cover - defensive: unknown code values
        return Status.UNKNOWN


def _timestampFromDatetime(value: datetime | None) -> timestamp_pb2.Timestamp | None:
    if value is None:
        return None
    ts = timestamp_pb2.Timestamp()
    ts.FromDatetime(value)
    return ts


class OpNetControllerService(opnet_controller_grpc.OpNetControllerBase):
    """Async grpclib servicer that fronts the OpNet controller collections."""

    def __init__(
        self,
        *,
        controller_collection: OpNetControllerCollection,
        link_collection: OpNetLinkCollection,
        node_session_maker: async_sessionmaker[AsyncSession],
    ) -> None:
        self._controller_collection = controller_collection
        self._node_collection: OpNetNodeCollection = controller_collection.getNodeCollection()
        self._link_collection = link_collection  # retained for future RPC expansion
        self._node_session_maker = node_session_maker

    async def Connect(
        self,
        stream: Stream[
            opnet_controller_pb2.OpNetConnectionRequest,
            opnet_controller_pb2.OpNetConnectionResponse,
        ],
    ) -> None:
        request = await self._recv_request(stream, "Connect")
        node_id = self._parse_uuid(request.node_id, "node_id")
        with lumesof_logging.loggingContext(
            **{
                lumesof_logging.RPC_METHOD: "Connect",
                lumesof_logging.LUMESOF_NODE_ID: str(node_id),
            }
        ):
            structuredLogger.info(
                "Connect request received",
                event="lumeflow.opnet.connect.received",
            )
            result, connections = await self._node_collection.async_connect(
                session_maker=self._node_session_maker,
                node_id=node_id,
                ports=request.ports,
            )
            if not result.ok:
                message = result.message or "Failed to connect node."
                structuredLogger.info(
                    "Connect failed",
                    event="lumeflow.opnet.connect.failed",
                    attrs={"details": message},
                )
                raise GRPCError(Status.FAILED_PRECONDITION, message)

            response = opnet_controller_pb2.OpNetConnectionResponse()
            if connections:
                response.connections.extend(connections)
            structuredLogger.info(
                "Connect completed",
                event="lumeflow.opnet.connect.completed",
                attrs={"connection_count": len(connections)},
            )
            await stream.send_message(response)

    async def DeactivatePort(
        self,
        stream: Stream[
            opnet_controller_pb2.OpNetDeactivatePortRequest,
            opnet_controller_pb2.OpNetDeactivateResponse,
        ],
    ) -> None:
        request = await self._recv_request(stream, "DeactivatePort")
        node_id = self._parse_uuid(request.node_id, "node_id")
        closure_reasons = dict(request.closure_reasons)
        if not closure_reasons:
            raise GRPCError(
                Status.INVALID_ARGUMENT,
                "closure_reasons must include at least one port entry.",
            )

        try:
            result, per_port = await self._node_collection.async_deactivatePorts(
                session_maker=self._node_session_maker,
                node_id=node_id,
                closure_reasons=closure_reasons,
            )
        except OpNetError as exc:
            self._abort_with_opnet_error(exc)

        await stream.send_message(self._build_deactivate_response(result, per_port))

    async def DeactivateAll(
        self,
        stream: Stream[
            opnet_controller_pb2.OpNetDeactivateAllRequest,
            opnet_controller_pb2.OpNetDeactivateResponse,
        ],
    ) -> None:
        request = await self._recv_request(stream, "DeactivateAll")
        node_id = self._parse_uuid(request.node_id, "node_id")
        try:
            result, per_port = await self._node_collection.async_deactivateAll(
                session_maker=self._node_session_maker,
                node_id=node_id,
                reason=request.reason or None,
            )
        except OpNetError as exc:
            self._abort_with_opnet_error(exc)

        await stream.send_message(self._build_deactivate_response(result, per_port))

    async def SendHeartbeat(
        self,
        stream: Stream[
            opnet_controller_pb2.OpNetSendHeatbeatRequest,
            opnet_controller_pb2.OpNetSendHeartbeatResponse,
        ],
    ) -> None:
        request = await self._recv_request(stream, "SendHeartbeat")
        node_id = self._parse_uuid(request.node_id, "node_id")
        if not request.HasField("hb"):
            raise GRPCError(Status.INVALID_ARGUMENT, "hb must be provided.")
        response_proto = await self._controller_collection.async_captureHeartbeat(
            node_id=node_id,
            heartbeat=request.hb,
        )
        response = opnet_controller_pb2.OpNetSendHeartbeatResponse()
        response.resp.CopyFrom(response_proto)
        await stream.send_message(response)

    async def _recv_request(
        self,
        stream: Stream[object, object],
        rpc_name: str,
    ) -> object:
        request = await stream.recv_message()
        if request is None:
            raise GRPCError(Status.INVALID_ARGUMENT, f"{rpc_name} request missing payload.")
        return request

    def _parse_uuid(
        self,
        raw_value: str,
        field_name: str,
    ) -> uuid.UUID:
        if not raw_value:
            raise GRPCError(Status.INVALID_ARGUMENT, f"{field_name} must be provided.")
        try:
            return uuid.UUID(raw_value)
        except ValueError:
            raise GRPCError(Status.INVALID_ARGUMENT, f"{field_name} must be a valid UUID string.")

    def _abort_with_opnet_error(
        self,
        error: OpNetError,
    ) -> None:
        status = _grpc_status_from_opnet(error.code)
        structuredLogger.info(
            "RPC aborted",
            event="lumeflow.opnet.rpc.aborted",
            attrs={
                "grpc_status": status.name,
                "opnet_error_code": error.code.name,
                "details": error.message,
            },
        )
        raise GRPCError(status, error.message)

    @staticmethod
    def _build_deactivate_response(
        result: opnet_types_pb2.Result,
        per_port: Dict[str, opnet_types_pb2.Result],
    ) -> opnet_controller_pb2.OpNetDeactivateResponse:
        response = opnet_controller_pb2.OpNetDeactivateResponse()
        response.result.CopyFrom(result)
        for port_name, status in per_port.items():
            response.per_connection_status[port_name].CopyFrom(status)
        return response


class OpNetManagerService(opnet_controller_grpc.OpNetManagerServiceBase):
    """Async grpclib servicer for OpNet management RPCs (stubbed)."""

    def __init__(
        self,
        *,
        controller_collection: OpNetControllerCollection,
        controller_session_maker: async_sessionmaker[AsyncSession],
    ) -> None:
        self._controller_collection = controller_collection
        self._controller_session_maker = controller_session_maker
        self._cluster_id = controller_collection._cluster_id
        self._usecase = controller_collection._usecase
        self._link_collection = controller_collection.getLinkCollection()
        self._node_collection = controller_collection.getNodeCollection()
        self._controller_plugin = getattr(controller_collection, "_plugin", None)

    async def CreateController(
        self,
        stream: Stream[
            opnet_controller_pb2.OpNetCreateControllerRequest,
            opnet_controller_pb2.OpNetCreateControllerResponse,
        ],
    ) -> None:
        request = await self._recv_request(stream, "CreateController")
        cluster_id = self._parse_uuid(request.cluster_id, "cluster_id")
        if not request.usecase:
            raise GRPCError(Status.INVALID_ARGUMENT, "usecase must be provided.")
        if not request.name:
            raise GRPCError(Status.INVALID_ARGUMENT, "name must be provided.")
        if cluster_id != self._cluster_id:
            raise GRPCError(
                Status.INVALID_ARGUMENT,
                "cluster_id does not match the service collection.",
            )
        if request.usecase != self._usecase:
            raise GRPCError(
                Status.INVALID_ARGUMENT,
                "usecase does not match the service collection.",
            )

        with lumesof_logging.loggingContext(
            **{
                lumesof_logging.RPC_METHOD: "CreateController",
                lumesof_logging.LUMESOF_CLUSTER_ID: str(cluster_id),
            }
        ):
            structuredLogger.info(
                "CreateController received",
                event="lumeflow.opnet.create_controller.received",
                attrs={
                    "usecase": request.usecase,
                    "controller_name": request.name,
                },
            )
            try:
                inst = await self._controller_collection.async_createController(
                    session_maker=self._controller_session_maker,
                    name=request.name,
                )
            except OpNetError as exc:
                self._abort_with_opnet_error(exc)

            response = opnet_controller_pb2.OpNetCreateControllerResponse(
                controller_id=str(inst.getId()),
                substrate=self._controller_collection.getSubstrate(),
            )
            structuredLogger.info(
                "CreateController completed",
                event="lumeflow.opnet.create_controller.completed",
                attrs={
                    lumesof_logging.LUMESOF_CLUSTER_ID: str(cluster_id),
                    lumesof_logging.LUMESOF_CONTROLLER_ID: response.controller_id,
                    lumesof_logging.LUMESOF_SUBSTRATE: response.substrate,
                    "usecase": request.usecase,
                },
            )
            await stream.send_message(response)

    async def CreateLinks(
        self,
        stream: Stream[
            opnet_controller_pb2.OpNetCreateLinksRequest,
            opnet_controller_pb2.OpNetCreateLinksResponse,
        ],
    ) -> None:
        request = await self._recv_request(stream, "CreateLinks")
        cluster_id = self._parse_uuid(request.cluster_id, "cluster_id")
        if not request.usecase:
            raise GRPCError(Status.INVALID_ARGUMENT, "usecase must be provided.")
        if not request.links:
            raise GRPCError(Status.INVALID_ARGUMENT, "links must include at least one entry.")
        if cluster_id != self._cluster_id:
            raise GRPCError(
                Status.INVALID_ARGUMENT,
                "cluster_id does not match the service collection.",
            )
        if request.usecase != self._usecase:
            raise GRPCError(
                Status.INVALID_ARGUMENT,
                "usecase does not match the service collection.",
            )

        with lumesof_logging.loggingContext(
            **{
                lumesof_logging.RPC_METHOD: "CreateLinks",
                lumesof_logging.LUMESOF_CLUSTER_ID: str(cluster_id),
            }
        ):
            structuredLogger.info(
                "CreateLinks received",
                event="lumeflow.opnet.create_links.received",
                attrs={
                    "usecase": request.usecase,
                    "link_count": len(request.links),
                },
            )
            results: list[opnet_controller_pb2.OpNetCreateLinkResult] = []
            for link in request.links:
                result = opnet_controller_pb2.OpNetCreateLinkResult(
                    controller_id=link.controller_id,
                    link_name=link.link_name,
                    status=opnet_controller_pb2.FAILED,
                )
                if not link.controller_id:
                    result.message = "controller_id must be provided."
                    results.append(result)
                    continue
                try:
                    controller_id = uuid.UUID(link.controller_id)
                except ValueError:
                    result.message = "controller_id must be a valid UUID string."
                    results.append(result)
                    continue
                if not link.link_name:
                    result.message = "link_name must be provided."
                    results.append(result)
                    continue
                if not link.payload_type:
                    result.message = "payload_type must be provided."
                    results.append(result)
                    continue

                try:
                    inst = await self._link_collection.async_createLink(
                        session_maker=self._controller_session_maker,
                        controller_id=controller_id,
                        link_name=link.link_name,
                        payload_type=link.payload_type,
                    )
                except OpNetError as exc:
                    if exc.code == OpNetErrorCode.ALREADY_EXISTS:
                        async with self._controller_session_maker() as session:
                            existing = (
                                await session.execute(
                                    select(TabLinks.id).where(
                                        (TabLinks.controller_id == controller_id)
                                        & (TabLinks.link_name == link.link_name)
                                    )
                                )
                            ).one_or_none()
                        if existing is None:
                            logger.error(
                                "CreateLinks already exists but missing link row controller_id=%s link_name=%s",
                                controller_id,
                                link.link_name,
                            )
                            result.status = opnet_controller_pb2.FAILED
                            result.message = "link exists but could not be resolved."
                            results.append(result)
                            continue
                        (link_id,) = existing
                        result.link_id = str(link_id)
                        resolved_link_ref = await self._async_resolveLinkRefById(link_id=link_id)
                        if resolved_link_ref is not None:
                            result.link_ref = resolved_link_ref
                        result.status = opnet_controller_pb2.ALREADY_EXISTS
                        result.message = exc.message
                        results.append(result)
                        continue
                    result.status = opnet_controller_pb2.FAILED
                    result.message = exc.message
                    results.append(result)
                    continue
                except Exception as exc:
                    logger.exception(
                        "CreateLinks failed unexpected error controller_id=%s link_name=%s",
                        controller_id,
                        link.link_name,
                    )
                    result.status = opnet_controller_pb2.FAILED
                    result.message = str(exc)
                    results.append(result)
                    continue

                result.link_id = str(inst.getId())
                resolved_link_ref = await self._async_resolveLinkRefById(link_id=inst.getId())
                if resolved_link_ref is None:
                    result.status = opnet_controller_pb2.FAILED
                    result.message = "link created but could not be resolved to a link_ref."
                    results.append(result)
                    continue
                result.link_ref = resolved_link_ref
                result.status = opnet_controller_pb2.CREATED
                results.append(result)

            response = opnet_controller_pb2.OpNetCreateLinksResponse(results=results)
            structuredLogger.info(
                "CreateLinks completed",
                event="lumeflow.opnet.create_links.completed",
                attrs={"result_count": len(results)},
            )
            await stream.send_message(response)

    async def _async_resolveLinkRefById(self, *, link_id: uuid.UUID) -> str | None:
        plugin = getattr(self._link_collection, "_plugin", None)
        if plugin is None:
            logger.error("CreateLinks could not resolve link_ref: link plugin unavailable")
            return None
        try:
            result, maybe_link_ref = await plugin.async_getLink(link_id=str(link_id))
        except Exception:
            logger.exception("CreateLinks failed resolving link_ref link_id=%s", link_id)
            return None
        if not result.ok:
            logger.error(
                "CreateLinks failed resolving link_ref link_id=%s message=%s",
                link_id,
                result.message,
            )
            return None
        link_ref = (maybe_link_ref or "").strip()
        if not link_ref:
            logger.error("CreateLinks resolved empty link_ref link_id=%s", link_id)
            return None
        return link_ref

    async def CreateNodes(
        self,
        stream: Stream[
            opnet_controller_pb2.OpNetCreateNodesRequest,
            opnet_controller_pb2.OpNetCreateNodesResponse,
        ],
    ) -> None:
        request = await self._recv_request(stream, "CreateNodes")
        cluster_id = self._parse_uuid(request.cluster_id, "cluster_id")
        if not request.usecase:
            raise GRPCError(Status.INVALID_ARGUMENT, "usecase must be provided.")
        if not request.nodes:
            raise GRPCError(Status.INVALID_ARGUMENT, "nodes must include at least one entry.")
        if cluster_id != self._cluster_id:
            raise GRPCError(
                Status.INVALID_ARGUMENT,
                "cluster_id does not match the service collection.",
            )
        if request.usecase != self._usecase:
            raise GRPCError(
                Status.INVALID_ARGUMENT,
                "usecase does not match the service collection.",
            )

        with lumesof_logging.loggingContext(
            **{
                lumesof_logging.RPC_METHOD: "CreateNodes",
                lumesof_logging.LUMESOF_CLUSTER_ID: str(cluster_id),
            }
        ):
            structuredLogger.info(
                "CreateNodes received",
                event="lumeflow.opnet.create_nodes.received",
                attrs={
                    "usecase": request.usecase,
                    "node_count": len(request.nodes),
                },
            )
            node_ids: list[str] = []
            for node in request.nodes:
                controller_id = self._parse_uuid(node.controller_id, "controller_id")
                if not node.name:
                    raise GRPCError(Status.INVALID_ARGUMENT, "name must be provided.")

                ports: list[PortInfo] = []
                for port in node.ports:
                    if not port.name:
                        raise GRPCError(Status.INVALID_ARGUMENT, "port.name must be provided.")
                    if not port.kind:
                        raise GRPCError(Status.INVALID_ARGUMENT, "port.kind must be provided.")
                    if not port.payload_type:
                        raise GRPCError(Status.INVALID_ARGUMENT, "port.payload_type must be provided.")
                    link_id = None
                    if port.link_id:
                        link_id = self._parse_uuid(port.link_id, "port.link_id")
                    ports.append(
                        PortInfo(
                            name=port.name,
                            kind=port.kind,
                            payload_type=port.payload_type,
                            link_id=link_id,
                        )
                    )

                try:
                    inst = await self._node_collection.async_createNode(
                        session_maker=self._controller_session_maker,
                        controller_id=controller_id,
                        name=node.name,
                        ports=ports or None,
                    )
                except OpNetError as exc:
                    self._abort_with_opnet_error(exc)
                node_ids.append(str(inst.id))

            response = opnet_controller_pb2.OpNetCreateNodesResponse(node_ids=node_ids)
            structuredLogger.info(
                "CreateNodes completed",
                event="lumeflow.opnet.create_nodes.completed",
                attrs={"node_count": len(node_ids)},
            )
            await stream.send_message(response)

    async def DestroyControllerResources(
        self,
        stream: Stream[
            opnet_controller_pb2.OpNetDestroyControllerResourcesRequest,
            opnet_controller_pb2.OpNetDestroyControllerResourcesResponse,
        ],
    ) -> None:
        request = await self._recv_request(stream, "DestroyControllerResources")
        response = await self.async_destroyControllerResources(request=request)
        await stream.send_message(response)

    async def async_destroyControllerResources(
        self,
        *,
        request: opnet_controller_pb2.OpNetDestroyControllerResourcesRequest,
    ) -> opnet_controller_pb2.OpNetDestroyControllerResourcesResponse:
        cluster_id = self._parse_uuid(request.cluster_id, "cluster_id")
        if not request.usecase:
            raise GRPCError(Status.INVALID_ARGUMENT, "usecase must be provided.")
        controller_id = self._parse_uuid(request.controller_id, "controller_id")
        if cluster_id != self._cluster_id:
            raise GRPCError(
                Status.INVALID_ARGUMENT,
                "cluster_id does not match the service collection.",
            )
        if request.usecase != self._usecase:
            raise GRPCError(
                Status.INVALID_ARGUMENT,
                "usecase does not match the service collection.",
            )

        async with self._controller_session_maker() as session:
            row = (
                await session.execute(
                    select(TabControllers.id)
                    .where(
                        (TabControllers.id == controller_id)
                        & (TabControllers.cluster_id == self._cluster_id)
                        & (TabControllers.usecase == self._usecase)
                    )
                )
            ).one_or_none()
        if row is None:
            return opnet_controller_pb2.OpNetDestroyControllerResourcesResponse()

        await self._node_collection.async_loadAllNodes(
            session_maker=self._controller_session_maker,
            controller_ids=[controller_id],
        )
        nodes = self._node_collection.getNodesByController(controller_id)
        for node in nodes:
            try:
                await self._node_collection.async_removeNode(
                    session_maker=self._controller_session_maker,
                    node_id=node.id,
                )
            except OpNetError as exc:
                if exc.code != OpNetErrorCode.NOT_FOUND:
                    self._abort_with_opnet_error(exc)

        async with self._controller_session_maker() as session:
            link_rows = (
                await session.execute(
                    select(TabLinks.id)
                    .join(TabControllers, TabLinks.controller_id == TabControllers.id)
                    .where(
                        (TabLinks.controller_id == controller_id)
                        & (TabControllers.cluster_id == self._cluster_id)
                        & (TabControllers.usecase == self._usecase)
                    )
                )
            ).all()
        for (link_id,) in link_rows:
            try:
                await self._link_collection.async_removeLink(
                    session_maker=self._controller_session_maker,
                    link_id=link_id,
                )
            except OpNetError as exc:
                if exc.code != OpNetErrorCode.NOT_FOUND:
                    self._abort_with_opnet_error(exc)

        try:
            await self._controller_collection.async_stopController(
                session_maker=self._controller_session_maker,
                controller_id=controller_id,
            )
        except OpNetError as exc:
            if exc.code != OpNetErrorCode.NOT_FOUND:
                self._abort_with_opnet_error(exc)
        return opnet_controller_pb2.OpNetDestroyControllerResourcesResponse()
    async def SetHeartbeatResp(
        self,
        stream: Stream[
            opnet_controller_pb2.OpNetSetHeartbeatRespRequest,
            opnet_controller_pb2.OpNetSetHeartbeatRespResponse,
        ],
    ) -> None:
        request = await self._recv_request(stream, "SetHeartbeatResp")
        if not request.entries:
            raise GRPCError(Status.INVALID_ARGUMENT, "entries must include at least one entry.")

        entries: List[Tuple[uuid.UUID, opnet_types_pb2.OpNetCtlToNodeHeartbeat]] = []
        seen_node_ids: set[uuid.UUID] = set()
        for entry in request.entries:
            node_id = self._parse_uuid(entry.node_id, "entries.node_id")
            if node_id in seen_node_ids:
                raise GRPCError(Status.INVALID_ARGUMENT, "entries must not contain duplicate node_id values.")
            seen_node_ids.add(node_id)
            if not entry.HasField("resp"):
                raise GRPCError(Status.INVALID_ARGUMENT, "entries.resp must be provided.")
            entries.append((node_id, entry.resp))

        try:
            await self._controller_collection.async_setHeartbeatResp(
                session_maker=self._controller_session_maker,
                entries=entries,
            )
        except OpNetError as exc:
            self._abort_with_opnet_error(exc)

        await stream.send_message(opnet_controller_pb2.OpNetSetHeartbeatRespResponse())

    async def GetNumHeartbeatDeliveries(
        self,
        stream: Stream[
            opnet_controller_pb2.OpNetGetNumHeartbeatDeliveriesRequest,
            opnet_controller_pb2.OpNetGetNumHeartbeatDeliveriesResponse,
        ],
    ) -> None:
        request = await self._recv_request(stream, "GetNumHeartbeatDeliveries")
        if not request.node_ids:
            raise GRPCError(Status.INVALID_ARGUMENT, "node_ids must include at least one entry.")

        node_ids: List[uuid.UUID] = []
        seen_node_ids: set[uuid.UUID] = set()
        for raw_node_id in request.node_ids:
            node_id = self._parse_uuid(raw_node_id, "node_ids")
            if node_id in seen_node_ids:
                raise GRPCError(Status.INVALID_ARGUMENT, "node_ids must not contain duplicate values.")
            seen_node_ids.add(node_id)
            node_ids.append(node_id)

        try:
            counts = await self._controller_collection.async_getNumHeartbeatDeliveries(
                session_maker=self._controller_session_maker,
                node_ids=node_ids,
            )
        except OpNetError as exc:
            self._abort_with_opnet_error(exc)

        response = opnet_controller_pb2.OpNetGetNumHeartbeatDeliveriesResponse()
        for node_id in node_ids:
            response.entries.add(node_id=str(node_id), delivery_count=counts[node_id])
        await stream.send_message(response)

    async def GetHeartbeatCount(
        self,
        stream: Stream[
            opnet_controller_pb2.OpNetGetHeartbeatCountRequest,
            opnet_controller_pb2.OpNetGetHeartbeatCountResponse,
        ],
    ) -> None:
        request = await self._recv_request(stream, "GetHeartbeatCount")
        logger.info(
            "GetHeartbeatCount request received node_count=%d since_unix_millis=%d",
            len(request.node_ids),
            request.since_unix_millis,
        )
        if not request.node_ids:
            logger.warning("GetHeartbeatCount rejected: node_ids is empty")
            raise GRPCError(Status.INVALID_ARGUMENT, "node_ids must include at least one entry.")
        if request.since_unix_millis < 0:
            logger.warning(
                "GetHeartbeatCount rejected: since_unix_millis=%d is negative",
                request.since_unix_millis,
            )
            raise GRPCError(Status.INVALID_ARGUMENT, "since_unix_millis must be >= 0.")

        node_ids: List[uuid.UUID] = []
        seen_node_ids: set[uuid.UUID] = set()
        for raw_node_id in request.node_ids:
            node_id = self._parse_uuid(raw_node_id, "node_ids")
            if node_id in seen_node_ids:
                raise GRPCError(Status.INVALID_ARGUMENT, "node_ids must not contain duplicate values.")
            seen_node_ids.add(node_id)
            node_ids.append(node_id)

        try:
            counts = await self._controller_collection.async_getHeartbeatCount(
                session_maker=self._controller_session_maker,
                node_ids=node_ids,
                since_unix_millis=request.since_unix_millis,
            )
        except OpNetError as exc:
            self._abort_with_opnet_error(exc)

        response = opnet_controller_pb2.OpNetGetHeartbeatCountResponse()
        for node_id in node_ids:
            response.entries.add(node_id=str(node_id), heartbeat_count=counts[node_id])
        logger.info(
            "GetHeartbeatCount response ready node_count=%d entries=%d",
            len(node_ids),
            len(response.entries),
        )
        await stream.send_message(response)

    async def GetNodesWithoutHeartbeats(
        self,
        stream: Stream[
            opnet_controller_pb2.OpNetGetNodesWithoutHeartbeatsRequest,
            opnet_controller_pb2.OpNetGetNodesWithoutHeartbeatsResponse,
        ],
    ) -> None:
        request = await self._recv_request(stream, "GetNodesWithoutHeartbeats")
        logger.info(
            "GetNodesWithoutHeartbeats request received since_unix_millis=%d",
            request.since_unix_millis,
        )
        if request.since_unix_millis < 0:
            logger.warning(
                "GetNodesWithoutHeartbeats rejected: since_unix_millis=%d is negative",
                request.since_unix_millis,
            )
            raise GRPCError(Status.INVALID_ARGUMENT, "since_unix_millis must be >= 0.")

        since_value = request.since_unix_millis if request.since_unix_millis > 0 else None
        if since_value is None:
            since_value = int((datetime.utcnow() - timedelta(minutes=10)).timestamp() * 1000)
            logger.info(
                "GetNodesWithoutHeartbeats using default since_unix_millis=%d",
                since_value,
            )

        try:
            node_ids = await self._controller_collection.async_getNodesWithoutHeartbeats(
                session_maker=self._controller_session_maker,
                since_unix_millis=since_value,
            )
        except OpNetError as exc:
            self._abort_with_opnet_error(exc)

        response = opnet_controller_pb2.OpNetGetNodesWithoutHeartbeatsResponse(
            node_ids=[str(node_id) for node_id in node_ids],
        )
        logger.info(
            "GetNodesWithoutHeartbeats response ready node_count=%d",
            len(response.node_ids),
        )
        await stream.send_message(response)

    async def GetNodeStatuses(
        self,
        stream: Stream[
            opnet_controller_pb2.OpNetGetNodeStatusesRequest,
            opnet_controller_pb2.OpNetGetNodeStatusesResponse,
        ],
    ) -> None:
        request = await self._recv_request(stream, "GetNodeStatuses")
        if not request.node_ids:
            raise GRPCError(Status.INVALID_ARGUMENT, "node_ids must include at least one entry.")
        if request.min_heartbeat_unix_millis < 0:
            raise GRPCError(Status.INVALID_ARGUMENT, "min_heartbeat_unix_millis must be >= 0.")

        node_ids: List[uuid.UUID] = []
        seen_node_ids: set[uuid.UUID] = set()
        for raw_node_id in request.node_ids:
            node_id = self._parse_uuid(raw_node_id, "node_ids")
            if node_id in seen_node_ids:
                raise GRPCError(Status.INVALID_ARGUMENT, "node_ids must not contain duplicate values.")
            seen_node_ids.add(node_id)
            node_ids.append(node_id)

        with lumesof_logging.loggingContext(
            **{
                lumesof_logging.RPC_METHOD: "GetNodeStatuses",
                lumesof_logging.LUMESOF_CLUSTER_ID: str(self._cluster_id),
            }
        ):
            structuredLogger.info(
                "GetNodeStatuses request received",
                event="lumeflow.opnet.get_node_statuses.received",
                attrs={
                    "node_count": len(node_ids),
                    "min_heartbeat_unix_millis": request.min_heartbeat_unix_millis,
                },
            )
            try:
                snapshots = await self._controller_collection.async_getNodeStatuses(
                    session_maker=self._controller_session_maker,
                    node_ids=node_ids,
                    min_heartbeat_unix_millis=request.min_heartbeat_unix_millis,
                )
            except OpNetError as exc:
                self._abort_with_opnet_error(exc)

            response = opnet_controller_pb2.OpNetGetNodeStatusesResponse()
            default_snapshot = OpNetNodeStatusSnapshot(
                status=opnet_types_pb2.OperatorStatus.OPERATOR_STATUS_UNSPECIFIED,
                last_contact_ts=None,
                heartbeat_ts=None,
                has_heartbeat=False,
            )
            for node_id in node_ids:
                snapshot = snapshots.get(node_id, default_snapshot)
                entry = response.entries.add(
                    node_id=str(node_id),
                    status=snapshot.status,
                    has_heartbeat=snapshot.has_heartbeat,
                    message=snapshot.message or "",
                )
                last_contact_ts = _timestampFromDatetime(snapshot.last_contact_ts)
                if last_contact_ts is not None:
                    entry.last_contact_ts.CopyFrom(last_contact_ts)
                heartbeat_ts = _timestampFromDatetime(snapshot.heartbeat_ts)
                if heartbeat_ts is not None:
                    entry.heartbeat_ts.CopyFrom(heartbeat_ts)

            structuredLogger.info(
                "GetNodeStatuses response ready",
                event="lumeflow.opnet.get_node_statuses.completed",
                attrs={
                    "node_count": len(node_ids),
                    "entry_count": len(response.entries),
                },
            )
            await stream.send_message(response)

    async def GetSubstrate(
        self,
        stream: Stream[
            opnet_controller_pb2.OpNetGetSubstrateRequest,
            opnet_controller_pb2.OpNetGetSubstrateResponse,
        ],
    ) -> None:
        await self._recv_request(stream, "GetSubstrate")
        substrate = self._controller_collection.getSubstrate()
        await stream.send_message(
            opnet_controller_pb2.OpNetGetSubstrateResponse(substrate=substrate)
        )

    async def InjectMessageIntoLink(
        self,
        stream: Stream[
            opnet_controller_pb2.OpNetInjectMessageIntoLinkRequest,
            opnet_controller_pb2.OpNetInjectMessageIntoLinkResponse,
        ],
    ) -> None:
        request = await self._recv_request(stream, "InjectMessageIntoLink")
        trace_id = (
            request.message.message_context.trace_id
            if request.HasField("message")
            and request.message.HasField("message_context")
            and request.message.message_context.trace_id
            else "<none>"
        )
        cluster_id = self._parse_uuid(request.cluster_id, "cluster_id")
        if not request.usecase:
            raise GRPCError(Status.INVALID_ARGUMENT, "usecase must be provided.")
        if cluster_id != self._cluster_id:
            raise GRPCError(
                Status.INVALID_ARGUMENT,
                "cluster_id does not match the service collection.",
            )
        if request.usecase != self._usecase:
            raise GRPCError(
                Status.INVALID_ARGUMENT,
                "usecase does not match the service collection.",
            )
        link_ref = request.link_ref.strip()
        if not link_ref:
            raise GRPCError(Status.INVALID_ARGUMENT, "link_ref must be provided.")
        if not request.HasField("message"):
            raise GRPCError(Status.INVALID_ARGUMENT, "message must be provided.")
        if not request.message.payload_type.SerializeToString():
            raise GRPCError(Status.INVALID_ARGUMENT, "message.payload_type must be provided.")
        if self._controller_plugin is None:
            raise GRPCError(Status.FAILED_PRECONDITION, "controller plugin is not configured.")
        injectContextAttrs = {
            lumesof_logging.RPC_METHOD: "InjectMessageIntoLink",
            lumesof_logging.LUMESOF_CLUSTER_ID: str(cluster_id),
            lumesof_logging.LUMESOF_LINK_REF: link_ref,
        }
        if trace_id != "<none>":
            injectContextAttrs[lumesof_logging.TRACE_ID] = trace_id
        with lumesof_logging.loggingContext(**injectContextAttrs):
            structuredLogger.debug(
                "InjectMessageIntoLink request",
                event="lumeflow.opnet.inject_message.request",
                attrs={
                    "usecase": request.usecase,
                    "payload_type": (
                        request.message.payload_type.type_url
                        if request.HasField("message")
                        else "<none>"
                    ),
                    "payload_bytes": len(request.message.payload) if request.HasField("message") else 0,
                    "bridge_link_ref_count": (
                        len(request.message.message_context.bridge_link_refs)
                        if request.HasField("message") and request.message.HasField("message_context")
                        else 0
                    ),
                },
            )
            parse_result, link_id_raw = self._controller_plugin.getLinkIdFromLinkRef(link_ref=link_ref)
            if not parse_result.ok or not link_id_raw:
                structuredLogger.debug(
                    "InjectMessageIntoLink invalid link_ref",
                    event="lumeflow.opnet.inject_message.invalid_link_ref",
                    attrs={"details": parse_result.message or "<none>"},
                )
                raise GRPCError(
                    Status.INVALID_ARGUMENT,
                    parse_result.message or "link_ref is invalid for configured controller plugin.",
                )
            link_id = self._parse_uuid(link_id_raw, "link_ref")
            structuredLogger.debug(
                "InjectMessageIntoLink resolved link",
                event="lumeflow.opnet.inject_message.link_resolved",
                attrs={"link_id": str(link_id)},
            )
            async with self._controller_session_maker() as session:
                row = (
                    await session.execute(
                        select(
                            TabLinks.payload_type,
                        )
                        .join(TabControllers, TabLinks.controller_id == TabControllers.id)
                        .where(TabLinks.id == link_id)
                        .where(TabControllers.cluster_id == self._cluster_id)
                        .where(TabControllers.usecase == self._usecase)
                        .limit(1)
                    )
                ).one_or_none()
            if row is None:
                raise GRPCError(Status.NOT_FOUND, f"link_ref not found: {link_ref}")
            (payload_type_bytes,) = row
            expected_payload = bytes(payload_type_bytes) if isinstance(payload_type_bytes, memoryview) else payload_type_bytes
            if expected_payload != request.message.payload_type.SerializeToString():
                structuredLogger.debug(
                    "InjectMessageIntoLink payload mismatch",
                    event="lumeflow.opnet.inject_message.payload_mismatch",
                    attrs={"link_id": str(link_id)},
                )
                raise GRPCError(Status.FAILED_PRECONDITION, "message payload_type does not match link payload_type.")

            structuredLogger.debug(
                "InjectMessageIntoLink invoking controller plugin",
                event="lumeflow.opnet.inject_message.dispatch",
                attrs={"link_id": str(link_id)},
            )
            inject_result = await self._controller_plugin.async_injectMessageIntoLink(
                link_ref=link_ref,
                opnet_message=request.message,
            )
            structuredLogger.debug(
                "InjectMessageIntoLink plugin response",
                event="lumeflow.opnet.inject_message.completed",
                attrs={
                    "link_id": str(link_id),
                    "ok": inject_result.ok,
                    "details": inject_result.message or "<none>",
                },
            )
            response = opnet_controller_pb2.OpNetInjectMessageIntoLinkResponse()
            response.result.CopyFrom(inject_result)
            await stream.send_message(response)

    async def _recv_request(
        self,
        stream: Stream[object, object],
        rpc_name: str,
    ) -> object:
        request = await stream.recv_message()
        if request is None:
            raise GRPCError(Status.INVALID_ARGUMENT, f"{rpc_name} request missing payload.")
        return request

    def _parse_uuid(
        self,
        raw_value: str,
        field_name: str,
    ) -> uuid.UUID:
        if not raw_value:
            raise GRPCError(Status.INVALID_ARGUMENT, f"{field_name} must be provided.")
        try:
            return uuid.UUID(raw_value)
        except ValueError:
            raise GRPCError(Status.INVALID_ARGUMENT, f"{field_name} must be a valid UUID string.")

    def _abort_with_opnet_error(
        self,
        error: OpNetError,
    ) -> None:
        status = _grpc_status_from_opnet(error.code)
        structuredLogger.info(
            "RPC aborted",
            event="lumeflow.opnet.rpc.aborted",
            attrs={
                "grpc_status": status.name,
                "opnet_error_code": error.code.name,
                "details": error.message,
            },
        )
        raise GRPCError(status, error.message)


def add_OpNetControllerService_to_server(
    service: OpNetControllerService,
    server,
) -> None:
    """Attach the OpNet controller servicer to a grpclib server instance."""
    if hasattr(server, "add_service"):
        server.add_service(service)
    elif hasattr(server, "services"):
        server.services.append(service)
    else:  # pragma: no cover - defensive: unexpected server type
        raise TypeError("Server does not support grpclib service registration.")
