# lumecode/lumeflow/runtime/v1/opnet_link.py

from __future__ import annotations

import asyncio
import contextlib
import logging
import threading
import uuid
from typing import Dict, Iterable, List, Optional, Set, Tuple

from sqlalchemy import delete, insert, select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker
from sqlalchemy.exc import DBAPIError, IntegrityError

from lumecode.base.python.sqldb import crdb_async_utils as sqldb_utils
from lumecode.lumeflow.runtime.v1.opnet.opnet_plugin_interface import OpNetControllerPlugin
from lumecode.lumeflow.runtime.v1.opnet.opnet_error import OpNetError, OpNetErrorCode

from lumecode.crdb.schemas.dev_cluster.flow.db_orm_models import TabControllers, TabLinks

logger = logging.getLogger(__name__)

_Key = Tuple[uuid.UUID, uuid.UUID]  # (cluster_id, link_id)


def _like_prefix(prefix: Optional[str]) -> Optional[str]:
    if not prefix:
        return None
    return f"{prefix}%"


@contextlib.asynccontextmanager
async def _transaction(session: AsyncSession):
    async with sqldb_utils.async_transactionContext(existing_session=session) as tx_ctx:
        yield tx_ctx.session


class OpNetLink:
    """Lightweight runtime wrapper for an OpNet link."""

    def __init__(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        controller_plugin: OpNetControllerPlugin,
        id: uuid.UUID,
        cluster: uuid.UUID,
        usecase: str,
        link_name: str,
        controller_id: uuid.UUID,
        payload_type: bytes,
    ) -> None:
        self._session_maker = session_maker
        self._controller_plugin = controller_plugin
        self._id = id
        self._cluster = cluster
        self._usecase = usecase
        self._link_name = link_name
        self._controller_id = controller_id
        self._payload_type = payload_type

    def getId(self) -> uuid.UUID:
        return self._id

    def getClusterId(self) -> uuid.UUID:
        return self._cluster

    def getUsecase(self) -> str:
        return self._usecase

    def getName(self) -> str:
        return self._link_name

    def getLinkName(self) -> str:
        return self._link_name

    def getControllerId(self) -> uuid.UUID:
        return self._controller_id

    def getPayloadType(self) -> bytes:
        return self._payload_type

    async def async_refresh(self) -> None:
        async with self._session_maker() as session:
            row = (
                await session.execute(
                    select(
                        TabLinks.link_name,
                        TabLinks.controller_id,
                        TabLinks.payload_type,
                        TabControllers.cluster_id,
                        TabControllers.usecase,
                    )
                    .select_from(TabLinks)
                    .join(TabControllers, TabLinks.controller_id == TabControllers.id)
                    .where(
                        (TabLinks.id == self._id)
                        & (TabControllers.cluster_id == self._cluster)
                        & (TabControllers.usecase == self._usecase)
                    )
                )
            ).one_or_none()

        if row is None:
            raise OpNetError(OpNetErrorCode.NOT_FOUND, "Link not found in this collection.")

        name, controller_id, payload, cluster_id, usecase = row
        self._link_name = name
        self._controller_id = controller_id
        self._payload_type = bytes(payload) if isinstance(payload, memoryview) else payload
        self._cluster = cluster_id
        self._usecase = usecase


class OpNetLinkCollection:
    """In-memory cache of links scoped to (cluster_id, usecase)."""

    def __init__(
        self,
        *,
        cluster_id: uuid.UUID,
        usecase: str,
        plugin: OpNetControllerPlugin,
    ) -> None:
        self._cluster_id = cluster_id
        self._usecase = usecase
        self._plugin = plugin

        self._instances: Dict[_Key, OpNetLink] = {}
        self._locks: Dict[_Key, asyncio.Lock] = {}
        self._dict_lock = threading.Lock()

    def _getKey(self, link_id: uuid.UUID) -> _Key:
        return (self._cluster_id, link_id)

    def _getOrCreateLock(self, key: _Key) -> asyncio.Lock:
        with self._dict_lock:
            lock = self._locks.get(key)
            if lock is None:
                lock = asyncio.Lock()
                self._locks[key] = lock
        return lock

    def _cachePut(self, inst: OpNetLink) -> None:
        key = self._getKey(inst.getId())
        with self._dict_lock:
            existed = key in self._instances
            self._instances[key] = inst
        logger.debug(
            f"cachePut: {'replaced' if existed else 'inserted'} link key={key}"
        )

    def _cacheGet(self, link_id: uuid.UUID) -> Optional[OpNetLink]:
        with self._dict_lock:
            return self._instances.get(self._getKey(link_id))

    def _cacheBulkPut(self, items: Dict[_Key, OpNetLink]) -> None:
        with self._dict_lock:
            self._instances.update(items)
        logger.info(
            f"cacheBulkPut: upserted {len(items)} links (cluster={self._cluster_id} usecase={self._usecase})"
        )

    async def async_loadAllLinks(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        controller_ids: Optional[Iterable[uuid.UUID]] = None,
        name_prefix: Optional[str] = None,
    ) -> None:
        logger.info(
            f"async_loadAllLinks: begin cluster={self._cluster_id} usecase={self._usecase}"
        )
        async with session_maker() as session:
            stmt = (
                select(
                    TabLinks.id,
                    TabLinks.link_name,
                    TabLinks.controller_id,
                    TabLinks.payload_type,
                    TabControllers.cluster_id,
                    TabControllers.usecase,
                )
                .select_from(TabLinks)
                .join(TabControllers, TabLinks.controller_id == TabControllers.id)
                .where(
                    (TabControllers.cluster_id == self._cluster_id)
                    & (TabControllers.usecase == self._usecase)
                )
            )
            if controller_ids:
                stmt = stmt.where(TabLinks.controller_id.in_(list(controller_ids)))
            prefix = _like_prefix(name_prefix)
            if prefix:
                stmt = stmt.where(TabLinks.link_name.like(prefix))
            rows = (await session.execute(stmt)).all()

        new_items: Dict[_Key, OpNetLink] = {}
        for (lid, link_name, controller_id, payload, clid, usecase) in rows:
            new_items[self._getKey(lid)] = OpNetLink(
                session_maker=session_maker,
                controller_plugin=self._plugin,
                id=lid,
                cluster=clid,
                usecase=usecase,
                link_name=link_name,
                controller_id=controller_id,
                payload_type=bytes(payload) if isinstance(payload, memoryview) else payload,
            )

        if new_items:
            self._cacheBulkPut(new_items)

        logger.info(
            f"async_loadAllLinks: done cluster={self._cluster_id} usecase={self._usecase} cached={len(new_items)}"
        )

    async def async_refreshLinks(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        link_ids: Optional[List[uuid.UUID]] = None,
        controller_ids: Optional[Iterable[uuid.UUID]] = None,
        name_prefix: Optional[str] = None,
    ) -> None:
        ids = link_ids

        if ids is None:
            await self.async_loadAllLinks(
                session_maker=session_maker,
                controller_ids=controller_ids,
                name_prefix=name_prefix,
            )
            return

        if len(ids) == 0:
            logger.debug(
                f"async_refreshLinks: no ids cluster={self._cluster_id} usecase={self._usecase}"
            )
            return

        logger.info(
            f"async_refreshLinks: begin cluster={self._cluster_id} usecase={self._usecase} count={len(ids)}"
        )

        async with session_maker() as session:
            stmt = (
                select(
                    TabLinks.id,
                    TabLinks.link_name,
                    TabLinks.controller_id,
                    TabLinks.payload_type,
                    TabControllers.cluster_id,
                    TabControllers.usecase,
                )
                .select_from(TabLinks)
                .join(TabControllers, TabLinks.controller_id == TabControllers.id)
                .where(
                    (TabLinks.id.in_(ids))
                    & (TabControllers.cluster_id == self._cluster_id)
                    & (TabControllers.usecase == self._usecase)
                )
            )
            rows = (await session.execute(stmt)).all()

        updated: Dict[_Key, OpNetLink] = {}
        found_keys: Set[_Key] = set()
        for (lid, link_name, controller_id, payload, clid, usecase) in rows:
            key = self._getKey(lid)
            found_keys.add(key)
            updated[key] = OpNetLink(
                session_maker=session_maker,
                controller_plugin=self._plugin,
                id=lid,
                cluster=clid,
                usecase=usecase,
                link_name=link_name,
                controller_id=controller_id,
                payload_type=bytes(payload) if isinstance(payload, memoryview) else payload,
            )

        if updated:
            self._cacheBulkPut(updated)

        requested_keys = {self._getKey(lid) for lid in ids}
        missing_keys = requested_keys - found_keys
        if missing_keys:
            with self._dict_lock:
                for key in missing_keys:
                    self._instances.pop(key, None)
            logger.info(
                f"async_refreshLinks: removed {len(missing_keys)} links no longer present in DB"
            )

        logger.info(
            f"async_refreshLinks: done cluster={self._cluster_id} usecase={self._usecase}"
        )

    async def async_getLink(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        link_id: uuid.UUID,
    ) -> OpNetLink:
        inst = self._cacheGet(link_id)
        if inst is not None:
            if inst.getUsecase() != self._usecase or inst.getClusterId() != self._cluster_id:
                logger.error(
                    f"async_getLink: cached instance mismatch key={self._getKey(link_id)}"
                )
                raise OpNetError(OpNetErrorCode.INTERNAL, "Cached instance collection mismatch.")
            return inst

        async with session_maker() as session:
            row = (
                await session.execute(
                    select(
                        TabLinks.id,
                        TabLinks.link_name,
                        TabLinks.controller_id,
                        TabLinks.payload_type,
                        TabControllers.cluster_id,
                        TabControllers.usecase,
                    )
                    .select_from(TabLinks)
                    .join(TabControllers, TabLinks.controller_id == TabControllers.id)
                    .where(
                        (TabLinks.id == link_id)
                        & (TabControllers.cluster_id == self._cluster_id)
                        & (TabControllers.usecase == self._usecase)
                    )
                )
            ).one_or_none()

        if row is None:
            logger.info(
                f"async_getLink: link not found cluster={self._cluster_id} usecase={self._usecase} id={link_id}"
            )
            raise OpNetError(OpNetErrorCode.NOT_FOUND, "Link not found in this collection.")

        lid, link_name, controller_id, payload, clid, usecase = row
        inst = OpNetLink(
            session_maker=session_maker,
            controller_plugin=self._plugin,
            id=lid,
            cluster=clid,
            usecase=usecase,
            link_name=link_name,
            controller_id=controller_id,
            payload_type=bytes(payload) if isinstance(payload, memoryview) else payload,
        )
        self._cachePut(inst)
        return inst

    async def async_createLink(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        controller_id: uuid.UUID,
        link_name: str,
        payload_type: bytes,
    ) -> OpNetLink:
        logger.info(
            f"async_createLink: begin cluster={self._cluster_id} usecase={self._usecase} controller={controller_id} link_name={link_name}"
        )

        async with session_maker() as session:
            row: Optional[Tuple[uuid.UUID, str, uuid.UUID, bytes]] = None

            async def _attempt() -> None:
                nonlocal row
                async with _transaction(session) as tx_session:
                    controller_row = (
                        await tx_session.execute(
                            select(TabControllers.id)
                            .where(
                                (TabControllers.id == controller_id)
                                & (TabControllers.cluster_id == self._cluster_id)
                                & (TabControllers.usecase == self._usecase)
                            )
                        )
                    ).scalar_one_or_none()
                    if controller_row is None:
                        logger.error(
                            f"async_createLink: controller out of scope controller_id={controller_id}"
                        )
                        raise OpNetError(
                            OpNetErrorCode.FAILED_PRECONDITION,
                            "Controller not found in this collection.",
                        )

                    ins = (
                        insert(TabLinks)
                        .values(
                            link_name=link_name,
                            controller_id=controller_id,
                            payload_type=payload_type,
                        )
                        .returning(
                            TabLinks.id,
                            TabLinks.link_name,
                            TabLinks.controller_id,
                            TabLinks.payload_type,
                        )
                    )
                    res = await tx_session.execute(ins)
                    row = res.one()

            try:
                await sqldb_utils.async_runWithSerializationRetries(
                    _attempt,
                    is_retryable=sqldb_utils.isRetryableSerializationError,
                    sleep_fn=asyncio.sleep,
                )
            except IntegrityError as e:
                existing = (
                    await session.execute(
                        select(
                            TabLinks.id,
                            TabLinks.link_name,
                            TabLinks.controller_id,
                            TabLinks.payload_type,
                            TabControllers.cluster_id,
                            TabControllers.usecase,
                        )
                        .select_from(TabLinks)
                        .join(TabControllers, TabLinks.controller_id == TabControllers.id)
                        .where(
                            (TabLinks.controller_id == controller_id)
                            & (TabLinks.link_name == link_name)
                        )
                    )
                ).one_or_none()

                if existing is not None:
                    eid, ename, econtroller, epayload, ecluster, eusecase = existing
                    if ecluster != self._cluster_id or eusecase != self._usecase:
                        logger.error(
                            f"async_createLink: name conflict outside collection controller={controller_id} link_name={link_name}"
                        )
                        raise OpNetError(
                            OpNetErrorCode.FAILED_PRECONDITION,
                            "Link exists outside of this collection scope.",
                        ) from e

                    logger.error(
                        f"async_createLink: name conflict controller={controller_id} link_name={link_name} existing_id={eid}"
                    )
                    raise OpNetError(
                        OpNetErrorCode.ALREADY_EXISTS,
                        "Link with this name already exists for controller.",
                    ) from e

                logger.error("async_createLink: integrity error with no matching row")
                raise OpNetError(
                    OpNetErrorCode.FAILED_PRECONDITION,
                    "Link could not be created due to conflicting state.",
                ) from e
            except OpNetError:
                raise
            except DBAPIError as exc:
                if sqldb_utils.isRetryableSerializationError(exc):
                    logger.warning(
                        "async_createLink serialization retries exhausted controller_id=%s link_name=%s",
                        controller_id,
                        link_name,
                    )
                raise

        if row is None:
            raise OpNetError(
                OpNetErrorCode.INTERNAL,
                "Link could not be created due to unexpected state.",
            )
        lid, db_name, db_controller, db_payload = row
        key = self._getKey(lid)
        lock = self._getOrCreateLock(key)

        async with lock:
            cached = self._cacheGet(lid)
            if cached is not None:
                logger.debug(f"async_createLink: cache hit post-insert key={key}")
                return cached
            inst = None

            try:
                result, _ref = await self._plugin.async_createLink(link_id=str(lid))
                if not result.ok:
                    logger.error(
                        f"async_createLink: backend provision failed id={lid} msg={result.message}"
                    )
                    raise OpNetError(
                        OpNetErrorCode.FAILED_PRECONDITION,
                        f"Backend createLink failed: {result.message}",
                    )
            except OpNetError:
                raise
            except Exception as exc:
                logger.error(f"async_createLink: plugin async_createLink failed id={lid}: {exc}")
                raise OpNetError(
                    OpNetErrorCode.INTERNAL,
                    f"plugin async_createLink failed: {exc}",
                ) from exc

            inst = OpNetLink(
                session_maker=session_maker,
                controller_plugin=self._plugin,
                id=lid,
                cluster=self._cluster_id,
                usecase=self._usecase,
                link_name=db_name,
                controller_id=db_controller,
                payload_type=bytes(db_payload) if isinstance(db_payload, memoryview) else db_payload,
            )
            if inst:
                self._cachePut(inst)
                logger.info(f"async_createLink: done id={lid}")
            return inst

    async def async_removeLink(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        link_id: uuid.UUID,
    ) -> None:
        key = self._getKey(link_id)
        logger.info(
            f"async_removeLink: begin cluster={self._cluster_id} usecase={self._usecase} id={link_id}"
        )
        lock = self._getOrCreateLock(key)
        max_attempts = 5
        delay_base_s = 0.02
        backend_removed = False

        async with lock:
            async def _attempt() -> None:
                nonlocal backend_removed
                async with session_maker() as session:
                    async with _transaction(session) as tx_session:
                        row = (
                            await tx_session.execute(
                                select(
                                    TabLinks.id,
                                    TabLinks.link_name,
                                    TabLinks.controller_id,
                                )
                                .select_from(TabLinks)
                                .join(TabControllers, TabLinks.controller_id == TabControllers.id)
                                .where(
                                    (TabLinks.id == link_id)
                                    & (TabControllers.cluster_id == self._cluster_id)
                                    & (TabControllers.usecase == self._usecase)
                                )
                            )
                        ).one_or_none()
                        if row is None:
                            logger.info(
                                f"async_removeLink: not found cluster={self._cluster_id} usecase={self._usecase} id={link_id}"
                            )
                            raise OpNetError(
                                OpNetErrorCode.NOT_FOUND, "Link not found in this collection."
                            )

                        if not backend_removed:
                            try:
                                result, link_ref = await self._plugin.async_getLink(
                                    link_id=str(link_id)
                                )
                                if result.ok and link_ref:
                                    rm = await self._plugin.async_removeLink(link_ref=link_ref)
                                    if not rm.ok:
                                        logger.error(
                                            f"async_removeLink: backend remove failed id={link_id} msg={rm.message}"
                                        )
                                        raise OpNetError(
                                            OpNetErrorCode.INTERNAL,
                                            f"Backend removeLink failed: {rm.message}",
                                        )
                            except OpNetError:
                                raise
                            except Exception as exc:
                                logger.error(
                                    f"async_removeLink: plugin async_removeLink failed id={link_id}: {exc}"
                                )
                                raise OpNetError(
                                    OpNetErrorCode.INTERNAL,
                                    f"plugin async_removeLink failed: {exc}",
                                ) from exc
                            backend_removed = True

                        await tx_session.execute(delete(TabLinks).where(TabLinks.id == link_id))

            try:
                await sqldb_utils.async_runWithSerializationRetries(
                    _attempt,
                    max_attempts=max_attempts,
                    base_delay_s=delay_base_s,
                    is_retryable=sqldb_utils.isRetryableSerializationError,
                    sleep_fn=asyncio.sleep,
                )
            except DBAPIError as exc:
                if sqldb_utils.isRetryableSerializationError(exc):
                    logger.warning(
                        "async_removeLink serialization retries exhausted link_id=%s",
                        link_id,
                    )
                raise

            with self._dict_lock:
                removed = self._instances.pop(key, None)

        logger.info(
            f"async_removeLink: deleted link id={link_id} cache_removed={removed is not None}"
        )
