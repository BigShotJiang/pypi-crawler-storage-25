from __future__ import annotations

import argparse
import asyncio
import logging
from typing import Optional, Tuple, Literal

from grpclib import GRPCError, Status
from grpclib.server import Server

from lumecode.base.python.net.target_parser import NetTarget
from lumecode.lumeflow.runtime.v1.opnet.opnet_types_pb2 import OpNetMessage, Result
from lumecode.lumeflow.runtime.v1.opnet.inmemory_opnet import inmemory_opnet_plugins_pb2 as pb
from lumecode.lumeflow.runtime.v1.opnet.inmemory_opnet import inmemory_opnet_plugins_grpc as pb_grpc

from lumecode.lumeflow.runtime.v1.opnet.inmemory_opnet.inmemory_opnet_plugins import (
    InMemoryOpNetControllerPlugin,
    InMemoryOpNetNodePlugin,
)

logger = logging.getLogger(__name__)


# --------------------------- grpclib servicer ---------------------------

class _SidecarServicer(pb_grpc.OpNetNodeControlBase):
    """Unary grpclib facade over InMemoryOpNetNodePlugin."""

    def __init__(self, impl: InMemoryOpNetNodePlugin) -> None:
        self._impl = impl

    # Helpers
    @staticmethod
    def _to_result(r) -> pb.Result:
        return pb.Result(ok=r.ok, message=r.message)

    @staticmethod
    def _mem_link(link_name: str) -> str:
        return f"mem://{link_name}"
    
    # RPCs (grpclib style: stream.recv_message() / stream.send_message())
    async def AddProducer(self, stream) -> None:
        req = await stream.recv_message()
        logger.info(
            f"GrpcOpNet server AddProducer request port_name={req.port_name} "
            f"link_name={req.link_name}"
        )
        res, prod_ref = await self._impl.async_addProducer(
            link_ref=self._mem_link(req.link_name),
            port_name=req.port_name,
        )
        logger.info(
            f"GrpcOpNet server AddProducer response port_name={req.port_name} "
            f"ok={res.ok} producer_ref={prod_ref or '<none>'} message={res.message or '<none>'}"
        )

        await stream.send_message(pb.AddProducerResponse(result=res, producer_ref=prod_ref))

    async def AddConsumer(self, stream) -> None:
        req = await stream.recv_message()
        logger.info(
            f"GrpcOpNet server AddConsumer request port_name={req.port_name} "
            f"link_name={req.link_name} max_concurrency={int(req.max_concurrency)}"
        )
        try:
            res, cons_ref = await self._impl.async_addConsumer(
                link_ref=self._mem_link(req.link_name),
                port_name=req.port_name,
                max_concurrency=int(req.max_concurrency),
            )
        except ValueError as e:
            raise GRPCError(Status.INVALID_ARGUMENT, str(e))
        logger.info(
            f"GrpcOpNet server AddConsumer response port_name={req.port_name} "
            f"ok={res.ok} consumer_ref={cons_ref or '<none>'} message={res.message or '<none>'}"
        )
        await stream.send_message(pb.AddConsumerResponse(result=res, consumer_ref=cons_ref))

    async def PutOpNetMessage(self, stream) -> None:
        req = await stream.recv_message()
        trace_id = (
            req.opnet_message.message_context.trace_id
            if req.opnet_message.HasField("message_context")
            and req.opnet_message.message_context.trace_id
            else "<none>"
        )
        logger.debug(
            "GrpcOpNet server PutOpNetMessage routing port_name=%s payload_bytes=%d",
            req.port_name,
            len(req.opnet_message.payload),
        )
        logger.info(
            f"GrpcOpNet server PutOpNetMessage request port_name={req.port_name} "
            f"trace_id={trace_id} payload_type={req.opnet_message.payload_type.type_url or '<none>'}"
        )
        res = await self._impl.async_putOpNetMessage(
            port_name=req.port_name,
            opnet_message=req.opnet_message,
        )
        logger.info(
            f"GrpcOpNet server PutOpNetMessage response port_name={req.port_name} "
            f"ok={res.ok} message={res.message or '<none>'}"
        )
        await stream.send_message(pb.PutOpNetMessageResponse(result=res))

    async def GetOpNetMessage(self, stream) -> None:
        req = await stream.recv_message()
        logger.info(f"GrpcOpNet server GetOpNetMessage request port_name={req.port_name}")
        res, message_id, wi = await self._impl.async_getOpNetMessage(
            port_name=req.port_name,
        )
        resp = pb.GetOpNetMessageResponse(result=res)
        if res.ok and message_id and wi is not None:
            resp.message_id = message_id
            resp.opnet_message.CopyFrom(wi)  # type: ignore[arg-type]
            trace_id = (
                wi.message_context.trace_id
                if wi.HasField("message_context") and wi.message_context.trace_id
                else "<none>"
            )
            logger.debug(
                "GrpcOpNet server GetOpNetMessage payload port_name=%s message_id=%s payload_bytes=%d",
                req.port_name,
                message_id,
                len(wi.payload),
            )
            logger.info(
                f"GrpcOpNet server GetOpNetMessage response port_name={req.port_name} "
                f"ok={res.ok} message_id={message_id} trace_id={trace_id}"
            )
        else:
            logger.info(
                f"GrpcOpNet server GetOpNetMessage response port_name={req.port_name} "
                f"ok={res.ok} message={res.message or '<none>'}"
            )
        await stream.send_message(resp)

    async def Ack(self, stream) -> None:
        req = await stream.recv_message()
        logger.info(
            f"GrpcOpNet server Ack request port_name={req.port_name} "
            f"message_id={req.message_id or '<none>'}"
        )
        res = await self._impl.async_ack(
            port_name=req.port_name,
            message_id=req.message_id,
        )
        logger.info(
            f"GrpcOpNet server Ack response port_name={req.port_name} "
            f"message_id={req.message_id or '<none>'} ok={res.ok} message={res.message or '<none>'}"
        )
        await stream.send_message(pb.AckResponse(result=res))

    async def Nack(self, stream) -> None:
        req = await stream.recv_message()
        logger.info(
            f"GrpcOpNet server Nack request port_name={req.port_name} "
            f"message_id={req.message_id or '<none>'}"
        )
        res = await self._impl.async_nack(
            port_name=req.port_name,
            message_id=req.message_id,
        )
        logger.info(
            f"GrpcOpNet server Nack response port_name={req.port_name} "
            f"message_id={req.message_id or '<none>'} ok={res.ok} message={res.message or '<none>'}"
        )
        await stream.send_message(pb.NackResponse(result=res))

    async def NackAll(self, stream) -> None:
        req = await stream.recv_message()
        logger.info(f"GrpcOpNet server NackAll request port_name={req.port_name}")
        res = await self._impl.async_nackAll(port_name=req.port_name)
        logger.info(
            f"GrpcOpNet server NackAll response port_name={req.port_name} "
            f"ok={res.ok} message={res.message or '<none>'}"
        )
        await stream.send_message(pb.NackAllResponse(result=res))


def createNodeControlService(*, bus) -> pb_grpc.OpNetNodeControlBase:
    """Build a grpclib node-plugin service backed by the provided in-memory bus."""
    sidecar_impl = InMemoryOpNetNodePlugin(bus=bus)
    return _SidecarServicer(sidecar_impl)


# ------------- Controller wrapper that announces grpc-aware refs -------------

class AnnouncingOpNetControllerPlugin(InMemoryOpNetControllerPlugin):
    """
    Returns link refs with grpc connection info instead of mem://...:
      - tcp://<host>:<port>:<link>
      - unix:///<uds_path>:<link>
    """

    def __init__(self, *, bus, scheme: Literal["tcp", "unix"], target: str) -> None:
        super().__init__(bus=bus)
        if scheme not in ("tcp", "unix"):
            raise ValueError("scheme must be 'tcp' or 'unix'")
        self._scheme = scheme
        self._target = target  # host:port or /path/to.sock

    def getSubstrate(self) -> str:
        return "grpc"

    def _announce_ref(self, link_name: str) -> str:
        if self._scheme == "tcp":
            return f"tcp://{self._target}:{link_name}"
        return f"unix:///{self._target}:{link_name}"

    @staticmethod
    def _asMemLinkRef(link_ref: str) -> str:
        if link_ref.startswith("mem://"):
            return link_ref
        if link_ref.startswith("tcp://") or link_ref.startswith("unix:///"):
            link_name = AnnouncingOpNetControllerPlugin._linkRefToLinkName(link_ref=link_ref)
            return f"mem://{link_name}"
        return f"mem://{link_ref}"

    @staticmethod
    def _linkRefToLinkName(link_ref: str) -> str:
        """
        Accepts:
          - tcp://<host>:<port>:<link-name>
          - unix:///<uds-path>:<link-name>
        """
        if link_ref.startswith("tcp://"):
            rest = link_ref[len("tcp://") :]
            pivot = rest.rfind(":")
            if pivot <= 0:
                raise ValueError(f"invalid tcp link_ref: {link_ref}")
            host_port = rest[:pivot]
            link_name = rest[pivot + 1 :]
            if not host_port or not link_name:
                raise ValueError(f"invalid tcp link_ref: {link_ref}")
            host, port_str = host_port.split(":")
            return link_name

        if link_ref.startswith("unix:///"):
            rest = link_ref[len("unix:///") :]
            pivot = rest.rfind(":")
            if pivot <= 0:
                raise ValueError(f"invalid unix link_ref: {link_ref}")
            uds_path = rest[:pivot]
            link_name = rest[pivot + 1 :]
            if not uds_path or not link_name:
                raise ValueError(f"invalid unix link_ref: {link_ref}")
            return link_name

        raise ValueError(f"invalid link_ref: {link_ref}")

    async def async_createLink(self, *, link_id: str) -> Tuple[pb.Result, str]:  # type: ignore[override]
        res, _ = await super().async_createLink(link_id=link_id)
        return res, self._announce_ref(link_id)

    async def async_getLink(self, *, link_id: str):
        res, ref = await super().async_getLink(link_id=link_id)
        if not res.ok or ref is None:
            return res, None
        return res, self._announce_ref(link_id)

    def getLinkIdFromLinkRef(self, *, link_ref: str):
        if link_ref.startswith("mem://") or "://" not in link_ref:
            return super().getLinkIdFromLinkRef(link_ref=link_ref)
        try:
            link_name = self._linkRefToLinkName(link_ref=link_ref)
        except ValueError as exc:
            return Result(ok=False, message=str(exc)), None
        return Result(ok=True, message="ok"), link_name

    async def async_getBacklog(self, *, link_ref: str):
        return await super().async_getBacklog(link_ref=self._asMemLinkRef(link_ref))

    async def async_removeLink(self, *, link_ref: str):
        return await super().async_removeLink(link_ref=self._asMemLinkRef(link_ref))

    async def async_injectMessageIntoLink(self, *, link_ref: str, opnet_message):
        trace_id = (
            opnet_message.message_context.trace_id
            if opnet_message.HasField("message_context")
            and opnet_message.message_context.trace_id
            else "<none>"
        )
        logger.debug(
            "AnnouncingOpNetControllerPlugin inject translate link_ref=%s mem_link_ref=%s trace_id=%s",
            link_ref,
            self._asMemLinkRef(link_ref=link_ref),
            trace_id,
        )
        return await super().async_injectMessageIntoLink(
            link_ref=self._asMemLinkRef(link_ref),
            opnet_message=opnet_message,
        )

# ------------------------------- Server APIs -------------------------------

async def start_server(*, bus, bind: str) -> Server:
    """
    Start a grpclib server bound to TCP host:port or UDS path ("unix:///...").
    Returns the running Server instance (close with .close() + .wait_closed()).
    """
    server = Server([createNodeControlService(bus=bus)])
    normalizedBind = bind if bind.startswith("tcp://") or bind.startswith("unix:///") else f"tcp://{bind}"
    bindTarget = NetTarget.parseTarget(normalizedBind).withUdsMode(0o666)
    await bindTarget.async_bindGrpclibServer(server)
    if bindTarget.getPath():
        logger.info("OpNet grpclib server listening on unix:///%s", bindTarget.getPath())
    else:
        logger.info("OpNet grpclib server listening on %s:%s", bindTarget.getHost(), bindTarget.getPort())

    return server


async def main() -> None:
    logging.basicConfig(level=logging.INFO)
    parser = argparse.ArgumentParser(description="OpNet grpclib Server")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--tcp", metavar="HOST:PORT", help="Bind TCP, e.g. 0.0.0.0:50051")
    group.add_argument("--uds", metavar="PATH", help="Bind Unix Domain Socket, e.g. /tmp/opnet.sock")
    args = parser.parse_args()

    bind = f"unix:///{args.uds}" if args.uds else args.tcp
    # Fresh bus in standalone mode
    bus = InMemoryOpNetControllerPlugin().bus

    server = await start_server(bus=bus, bind=bind)
    try:
        await server.wait_closed()
    finally:
        await server.close()


if __name__ == "__main__":
    asyncio.run(main())
