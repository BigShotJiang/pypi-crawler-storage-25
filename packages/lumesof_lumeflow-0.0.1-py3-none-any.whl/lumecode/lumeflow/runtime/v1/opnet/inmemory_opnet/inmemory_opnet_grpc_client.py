from __future__ import annotations

import asyncio
import logging
import uuid

from dataclasses import dataclass
from typing import Dict, Optional, Tuple, Set

from grpclib import GRPCError, Status
from grpclib.client import Channel

from lumecode.lumeflow.runtime.v1.opnet.opnet_types_pb2 import OpNetMessage
from lumecode.lumeflow.runtime.v1.opnet.inmemory_opnet import inmemory_opnet_plugins_pb2 as pb
from lumecode.lumeflow.runtime.v1.opnet.inmemory_opnet import inmemory_opnet_plugins_grpc as pb_grpc

from lumecode.lumeflow.runtime.v1.opnet.opnet_plugin_interface import (
    Result,
    OpNetNodePlugin,
)

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class _Target:
    scheme: str          # "tcp" or "unix"
    target_key: str      # "tcp://host:port" or "unix:///path"
    link_name: str
    host: Optional[str] = None
    port: Optional[int] = None
    uds_path: Optional[str] = None


class GrpcOpNetNodePlugin(OpNetNodePlugin):
    """
    grpclib-based client with hidden routing:
      - On AddProducer/AddConsumer, remember server for port_name.
      - Route Put/Get/Ack/Nack via that server only.
    """

    def __init__(
        self,
        *,
        node_id: Optional[str] = None,
        default_timeout_s: Optional[float] = None,
        get_timeout_s: Optional[float] = None,
    ) -> None:
        self._node_id = node_id if node_id else uuid.uuid4().hex
        self._default_timeout_s = default_timeout_s
        self._getTimeoutS = get_timeout_s if get_timeout_s is not None else default_timeout_s
        self._channels: Dict[str, Channel] = {}
        self._stubs: Dict[str, pb_grpc.OpNetNodeControlStub] = {}
        self._producer_bindings: Dict[tuple[str, str], str] = {}
        self._consumer_bindings: Dict[tuple[str, str], str] = {}
        self._lock = asyncio.Lock()

    def getSubstrate(self) -> str:
        return "grpc"

    # ---------------------- OpNetNodePlugin API ----------------------

    async def async_addProducer(self, *, link_ref: str, port_name: str) -> Tuple[Result, str]:
        t = self._parseLinkRef(link_ref)
        logger.info(
            f"GrpcOpNet addProducer request node_id={self._node_id} "
            f"port_name={port_name} link_ref={link_ref}"
        )
        stub = await self._stubFor(t)
        try:
            resp = await stub.AddProducer(pb.AddProducerRequest(
                link_name=t.link_name, port_name=f"{self._node_id}:{port_name}"
            ), timeout=self._default_timeout_s)
        except Exception:
            logger.exception(
                "GrpcOpNet addProducer RPC failed node_id=%s port_name=%s link_ref=%s",
                self._node_id,
                port_name,
                link_ref,
            )
            raise
        res = self._fromPbResult(resp.result)
        if res.ok:
            await self._rememberProducerBinding(port_name, t.target_key)
        logger.info(
            f"GrpcOpNet addProducer response node_id={self._node_id} "
            f"port_name={port_name} ok={res.ok} producer_ref={resp.producer_ref or '<none>'} "
            f"message={res.message or '<none>'}"
        )
        return res, resp.producer_ref

    async def async_addConsumer(
        self, *, link_ref: str, port_name: str, max_concurrency: int
    ) -> Tuple[Result, str]:
        t = self._parseLinkRef(link_ref)
        logger.info(
            f"GrpcOpNet addConsumer request node_id={self._node_id} "
            f"port_name={port_name} link_ref={link_ref} max_concurrency={int(max_concurrency)}"
        )
        stub = await self._stubFor(t)
        try:
            resp = await stub.AddConsumer(pb.AddConsumerRequest(
                link_name=t.link_name, port_name=f"{self._node_id}:{port_name}", max_concurrency=int(max_concurrency)
            ), timeout=self._default_timeout_s)
        except GRPCError as e:
            if e.status is Status.INVALID_ARGUMENT:
                logger.info(
                    "GrpcOpNet addConsumer RPC invalid argument node_id=%s "
                    "port_name=%s link_ref=%s status=%s message=%s",
                    self._node_id,
                    port_name,
                    link_ref,
                    e.status,
                    e.message or "<none>",
                )
                # Preserve in-memory semantics
                raise ValueError(e.message or "invalid argument")
            logger.exception(
                "GrpcOpNet addConsumer RPC failed node_id=%s port_name=%s link_ref=%s status=%s message=%s",
                self._node_id,
                port_name,
                link_ref,
                e.status,
                e.message or "<none>",
            )
            raise
        except Exception:
            logger.exception(
                "GrpcOpNet addConsumer RPC failed node_id=%s port_name=%s link_ref=%s",
                self._node_id,
                port_name,
                link_ref,
            )
            raise
        
        res = self._fromPbResult(resp.result)
        if res.ok:
            await self._rememberConsumerBinding(port_name, t.target_key)
        logger.info(
            f"GrpcOpNet addConsumer response node_id={self._node_id} "
            f"port_name={port_name} ok={res.ok} consumer_ref={resp.consumer_ref or '<none>'} "
            f"message={res.message or '<none>'}"
        )
        return res, resp.consumer_ref

    async def async_putOpNetMessage(
        self,
        *,
        port_name: str,
        work_item: Optional[OpNetMessage] = None,
        opnet_message: Optional[OpNetMessage] = None,
    ) -> Result:
        key = await self._producerKey(port_name)
        if key is None:
            return Result(ok=False, message=f"no producer binding for {port_name}")
        message = work_item if work_item is not None else opnet_message
        if message is None:
            return Result(ok=False, message="missing opnet message")
        trace_id = (
            message.message_context.trace_id
            if message.HasField("message_context") and message.message_context.trace_id
            else "<none>"
        )
        payload_type = message.payload_type.type_url or "<none>"
        logger.debug(
            "GrpcOpNet put routing node_id=%s port_name=%s target=%s payload_bytes=%d",
            self._node_id,
            port_name,
            key,
            len(message.payload),
        )
        logger.info(
            f"GrpcOpNet put request node_id={self._node_id} "
            f"port_name={port_name} trace_id={trace_id} payload_type={payload_type}"
        )
        stub = await self._stubForKey(key)
        try:
            resp = await stub.PutOpNetMessage(pb.PutOpNetMessageRequest(
                port_name=f"{self._node_id}:{port_name}", opnet_message=message
            ), timeout=self._default_timeout_s)
        except Exception:
            logger.exception(
                "GrpcOpNet put RPC failed node_id=%s port_name=%s trace_id=%s",
                self._node_id,
                port_name,
                trace_id,
            )
            raise
        result = self._fromPbResult(resp.result)
        logger.info(
            f"GrpcOpNet put response node_id={self._node_id} "
            f"port_name={port_name} ok={result.ok} message={result.message or '<none>'}"
        )
        return result

    async def async_getOpNetMessage(self, *, port_name: str):
        key = await self._consumerKey(port_name)
        if key is None:
            return Result(ok=False, message=f"no consumer binding for {port_name}"), None, None
        logger.debug(
            "GrpcOpNet get routing node_id=%s port_name=%s target=%s",
            self._node_id,
            port_name,
            key,
        )
        logger.info(
            f"GrpcOpNet get request node_id={self._node_id} port_name={port_name}"
        )
        stub = await self._stubForKey(key)
        try:
            resp = await stub.GetOpNetMessage(pb.GetOpNetMessageRequest(
                port_name=f"{self._node_id}:{port_name}"
            ), timeout=self._getTimeoutS)
        except Exception:
            logger.exception(
                "GrpcOpNet get RPC failed node_id=%s port_name=%s",
                self._node_id,
                port_name,
            )
            raise
        res = self._fromPbResult(resp.result)
        if not res.ok:
            logger.info(
                f"GrpcOpNet get response node_id={self._node_id} "
                f"port_name={port_name} ok={res.ok} message={res.message or '<none>'}"
            )
            return res, None, None
        wi = OpNetMessage()
        wi.CopyFrom(resp.opnet_message)
        trace_id = (
            wi.message_context.trace_id
            if wi.HasField("message_context") and wi.message_context.trace_id
            else "<none>"
        )
        logger.info(
            f"GrpcOpNet get response node_id={self._node_id} "
            f"port_name={port_name} ok={res.ok} message_id={resp.message_id or '<none>'} "
            f"trace_id={trace_id}"
        )
        return res, resp.message_id, wi

    async def async_ack(self, *, port_name: str, message_id: str) -> Result:
        key = await self._consumerKey(port_name)
        if key is None:
            return Result(ok=False, message=f"no consumer binding for {port_name}")
        logger.debug(
            "GrpcOpNet ack routing node_id=%s port_name=%s message_id=%s target=%s",
            self._node_id,
            port_name,
            message_id,
            key,
        )
        logger.info(
            f"GrpcOpNet ack request node_id={self._node_id} "
            f"port_name={port_name} message_id={message_id}"
        )
        stub = await self._stubForKey(key)
        try:
            resp = await stub.Ack(pb.AckRequest(
                port_name=f"{self._node_id}:{port_name}", message_id=message_id
            ), timeout=self._default_timeout_s)
        except Exception:
            logger.exception(
                "GrpcOpNet ack RPC failed node_id=%s port_name=%s message_id=%s",
                self._node_id,
                port_name,
                message_id,
            )
            raise
        result = self._fromPbResult(resp.result)
        logger.info(
            f"GrpcOpNet ack response node_id={self._node_id} "
            f"port_name={port_name} message_id={message_id} ok={result.ok} "
            f"message={result.message or '<none>'}"
        )
        return result

    async def async_nack(self, *, port_name: str, message_id: str) -> Result:
        key = await self._consumerKey(port_name)
        if key is None:
            return Result(ok=False, message=f"no consumer binding for {port_name}")
        logger.debug(
            "GrpcOpNet nack routing node_id=%s port_name=%s message_id=%s target=%s",
            self._node_id,
            port_name,
            message_id,
            key,
        )
        logger.info(
            f"GrpcOpNet nack request node_id={self._node_id} "
            f"port_name={port_name} message_id={message_id}"
        )
        stub = await self._stubForKey(key)
        try:
            resp = await stub.Nack(pb.NackRequest(
                port_name=f"{self._node_id}:{port_name}", message_id=message_id
            ), timeout=self._default_timeout_s)
        except Exception:
            logger.exception(
                "GrpcOpNet nack RPC failed node_id=%s port_name=%s message_id=%s",
                self._node_id,
                port_name,
                message_id,
            )
            raise
        result = self._fromPbResult(resp.result)
        logger.info(
            f"GrpcOpNet nack response node_id={self._node_id} "
            f"port_name={port_name} message_id={message_id} ok={result.ok} "
            f"message={result.message or '<none>'}"
        )
        return result

    async def async_nackAll(self, *, port_name: str) -> Result:
        key = await self._consumerKey(port_name)
        if not key:
            return Result(ok=False, message=f"no bindings for consumer {port_name}")
        logger.debug(
            "GrpcOpNet nackAll routing node_id=%s port_name=%s target=%s",
            self._node_id,
            port_name,
            key,
        )
        logger.info(
            f"GrpcOpNet nackAll request node_id={self._node_id} port_name={port_name}"
        )
        stub = await self._stubForKey(key)
        try:
            resp = await stub.NackAll(
                pb.NackAllRequest(port_name=f"{self._node_id}:{port_name}"),
                timeout=self._default_timeout_s,
            )
        except Exception:
            logger.exception(
                "GrpcOpNet nackAll RPC failed node_id=%s port_name=%s",
                self._node_id,
                port_name,
            )
            raise
        logger.info(
            f"GrpcOpNet nackAll response node_id={self._node_id} "
            f"port_name={port_name} ok={resp.result.ok} message={resp.result.message or '<none>'}"
        )
        return resp.result

    async def async_close(self) -> None:
        # grpclib.Channel.close() is sync
        for ch in self._channels.values():
            try:
                ch.close()
            except Exception:  # best-effort
                pass
        self._channels.clear()
        self._stubs.clear()
        async with self._lock:
            self._producer_bindings.clear()
            self._consumer_bindings.clear()

    # ----------------------------- Helpers -----------------------------

    @staticmethod
    def _fromPbResult(r: pb.Result) -> Result:
        return Result(ok=bool(r.ok), message=str(r.message))

    async def _stubFor(self, t: _Target) -> pb_grpc.OpNetNodeControlStub:
        stub = self._stubs.get(t.target_key)
        if stub is not None:
            return stub
        if t.scheme == "unix":
            ch = Channel(path=t.uds_path or "")
        else:
            ch = Channel(t.host or "127.0.0.1", t.port or 0)
        logger.info(
            f"GrpcOpNet opening channel node_id={self._node_id} "
            f"target={t.target_key} scheme={t.scheme}"
        )
        self._channels[t.target_key] = ch
        stub = pb_grpc.OpNetNodeControlStub(ch)
        self._stubs[t.target_key] = stub
        return stub

    async def _stubForKey(self, key: str) -> pb_grpc.OpNetNodeControlStub:
        stub = self._stubs.get(key)
        if stub is None:
            raise RuntimeError(f"no stub for {key}; did you bind first?")
        return stub

    @staticmethod
    def _parseLinkRef(link_ref: str) -> _Target:
        """
        Accepts:
          - tcp://<host>:<port>:<link-name>
          - unix:///<uds-path>:<link-name>
        """
        if link_ref.startswith("tcp://"):
            rest = link_ref[len("tcp://") :]
            pivot = rest.rfind(":")
            if pivot <= 0:
                raise ValueError(f"invalid tcp link_ref: {link_ref}")
            host_port = rest[:pivot]
            link_name = rest[pivot + 1 :]
            if not host_port or not link_name:
                raise ValueError(f"invalid tcp link_ref: {link_ref}")
            host, port_str = host_port.split(":")
            return _Target(
                scheme="tcp",
                target_key=f"tcp://{host}:{port_str}",
                link_name=link_name,
                host=host,
                port=int(port_str),
            )

        if link_ref.startswith("unix:///"):
            rest = link_ref[len("unix:///") :]
            pivot = rest.rfind(":")
            if pivot <= 0:
                raise ValueError(f"invalid unix link_ref: {link_ref}")
            uds_path = rest[:pivot]
            link_name = rest[pivot + 1 :]
            if not uds_path or not link_name:
                raise ValueError(f"invalid unix link_ref: {link_ref}")
            return _Target(
                scheme="unix",
                target_key=f"unix:///{uds_path}",
                link_name=link_name,
                uds_path=uds_path,
            )

        raise ValueError(f"unsupported link_ref scheme (expected tcp:// or unix:///): {link_ref}")

    # ---------------------- Hidden-state bookkeeping ----------------------

    async def _rememberProducerBinding(self, port_name: str, target_key: str) -> None:
        async with self._lock:
            self._producer_bindings[port_name] = target_key
            logger.debug("bound producer %s -> %s", port_name, target_key)

    async def _rememberConsumerBinding(self, port_name: str, target_key: str) -> None:
        async with self._lock:
            self._consumer_bindings[port_name] = target_key
            logger.debug("bound consumer %s -> %s", port_name, target_key)

    async def _producerKey(self, port_name: str) -> Optional[str]:
        async with self._lock:
            return self._producer_bindings.get(port_name)

    async def _consumerKey(self, port_name: str) -> Optional[str]:
        async with self._lock:
            return self._consumer_bindings.get(port_name)
