from __future__ import annotations

import asyncio
import logging
import uuid
from dataclasses import dataclass
from typing import Dict, Iterable, Optional, Tuple

from lumecode.lumeflow.runtime.v1.opnet.opnet_types_pb2 import Result, OpNetMessage
from lumecode.lumeflow.runtime.v1.opnet.opnet_plugin_interface import (
    OpNetControllerPlugin,
    OpNetNodePlugin,
)

logger = logging.getLogger(__name__)


# ----------------------------- Internal model -----------------------------

@dataclass
class _InFlight:
    message_id: str
    opnet_message: OpNetMessage
    consumer: str
    link_name: str


class _ConsumerState:
    """Per-consumer concurrency cap."""
    __slots__ = ("slots",)

    def __init__(self, max_concurrency: int) -> None:
        if max_concurrency < 1:
            raise ValueError("max_concurrency must be >= 1")
        # Hard cap on concurrent, un-acked deliveries.
        self.slots = asyncio.Semaphore(max_concurrency)


class _Link:
    """One independent FIFO queue per link."""
    __slots__ = ("name", "queue", "producers", "consumers")

    def __init__(self, name: str) -> None:
        self.name = name
        self.queue: asyncio.Queue[OpNetMessage] = asyncio.Queue()
        self.producers: set[str] = set()
        self.consumers: set[str] = set()


# ---------------------------- Shared in-memory bus ----------------------------

class _InMemoryBus:
    """Process-local registry shared by controller and sidecar plugins."""
    def __init__(self) -> None:
        logger.debug("InMemoryBus: initializing")
        self._lock = asyncio.Lock()
        self._links: Dict[str, _Link] = {}
        self._consumer_to_state: Dict[str, _ConsumerState] = {}
        self._producer_to_link: Dict[str, str] = {}
        self._consumer_to_link: Dict[str, str] = {}
        self._in_flight_by_id: Dict[str, _InFlight] = {}

    # ---------- validation ----------

    @classmethod
    def _validateName(cls, name: str) -> None:
        if ":" in name:
            raise ValueError(f"Invalid input: '{name}' contains a colon (:)")

    @classmethod
    def _validateNames(cls, names: Iterable[str]) -> None:
        for n in names:
            cls._validateName(n)

    # ---------- link ops ----------

    async def async_createLink(self, link_id: str) -> Tuple[Result, str]:
        self._validateName(link_id)
        async with self._lock:
            if link_id in self._links:
                logger.info('createLink("%s"): exists', link_id)
                return Result(ok=True, message="exists"), f"mem://{link_id}"
            self._links[link_id] = _Link(link_id)
            logger.info('createLink("%s"): created', link_id)
            return Result(ok=True, message="created"), f"mem://{link_id}"

    async def async_getLink(self, link_id: str) -> Tuple[Result, Optional[str]]:
        self._validateName(link_id)
        async with self._lock:
            if link_id not in self._links:
                logger.debug('getLink("%s"): not found', link_id)
                return Result(ok=False, message="not found"), None
            logger.debug('getLink("%s"): found', link_id)
            return Result(ok=True), f"mem://{link_id}"

    async def async_removeLink(self, link_ref: str) -> Result:
        link_name = self._parseMemUri(link_ref)
        self._validateName(link_name)
        async with self._lock:
            if link_name not in self._links:
                logger.info('removeLink("%s"): already absent', link_name)
                return Result(ok=True, message="already absent")
            link = self._links.pop(link_name)
            logger.info('removeLink("%s")', link_name)
            for producer in link.producers:
                self._producer_to_link.pop(producer, None)
            for consumer in link.consumers:
                self._consumer_to_link.pop(consumer, None)
                self._consumer_to_state.pop(consumer, None)
            # Orphan inflight tokens for this link (idempotent acks/nacks will no-op later)
            to_delete = [tid for tid, inf in self._in_flight_by_id.items() if inf.link_name == link_name]
            for tid in to_delete:
                self._in_flight_by_id.pop(tid, None)
            # Drain queue
            drained = 0
            while not link.queue.empty():
                try:
                    link.queue.get_nowait()
                    link.queue.task_done()
                    drained += 1
                except asyncio.QueueEmpty:
                    break
            logger.debug(
                'removeLink("%s"): drained=%d orphaned_inflight=%d',
                link_name,
                drained,
                len(to_delete),
            )
            return Result(ok=True, message="removed")
        
    async def async_getBacklog(self, link_ref: str) -> Tuple[Result, Optional[int]]:
        link_name = self._parseMemUri(link_ref)
        link = self._links.get(link_name, None)
        if not link:
            logger.info("getBacklog(%s): link not found", link_ref)
            return Result(ok=False, message=f"link {link_ref} not_found"), None
        return Result(ok=True, message=""), link.queue.qsize()

    # ---------- bindings ----------

    async def async_addProducer(
        self,
        link_ref: str,
        port_name: str,
    ) -> Tuple[Result, str]:
        link_name = self._parseMemUri(link_ref)
        producer = port_name
        async with self._lock:
            link = self._links.get(link_name)
            if not link:
                logger.debug(
                    'addProducer("%s"): link "%s" not found',
                    producer,
                    link_name,
                )
                return Result(ok=False, message="link not found"), ""
            if producer in link.producers:
                logger.debug(
                    'addProducer("%s"): idempotent on link "%s"',
                    producer,
                    link_name,
                )
                return Result(ok=True, message="exists"), f"prod://{producer}"
            if producer in self._producer_to_link or producer in self._consumer_to_link:
                logger.info(
                    'addProducer("%s"): has a conflict',
                    producer,
                )
                return Result(ok=False, message=f"name '{producer}' has a conflict"), ""
            link.producers.add(producer)
            self._producer_to_link[producer] = link_name
            logger.info(
                'addProducer("%s"): bound to link "%s"',
                producer,
                link_name,
            )
            return Result(ok=True, message="bound"), f"prod://{producer}"

    async def async_addConsumer(
        self,
        link_ref: str,
        port_name: str,
        max_concurrency: int,
    ) -> Tuple[Result, str]:
        link_name = self._parseMemUri(link_ref)
        consumer = port_name
        async with self._lock:
            link = self._links.get(link_name)
            if not link:
                logger.debug(
                    'addConsumer("%s"): link "%s" not found',
                    consumer,
                    link_name,
                )
                return Result(ok=False, message="link not found"), ""
            if consumer in link.consumers:
                logger.debug(
                    'addConsumer("%s"): idempotent on link "%s"',
                    consumer,
                    link_name,
                )
                return Result(ok=True, message="exists"), f"cons://{consumer}"
            if consumer in self._producer_to_link or consumer in self._consumer_to_link:
                logger.info(
                    'addConsumer("%s"): has a conflict',
                    consumer,
                )
                return Result(ok=False, message=f"name '{consumer}' has a conflict"), ""
            link.consumers.add(consumer)
            self._consumer_to_link[consumer] = link_name
            self._consumer_to_state[consumer] = _ConsumerState(max_concurrency)
            logger.info(
                'addConsumer("%s"): bound to link "%s" (max_concurrency=%d)',
                consumer,
                link_name,
                max_concurrency,
            )
            return Result(ok=True, message="bound"), f"cons://{consumer}"

    # ---------- data path ----------

    async def async_putOpNetMessage(self, port_name: str, wi: OpNetMessage) -> Result:
        producer = port_name
        trace_id = (
            wi.message_context.trace_id
            if wi.HasField("message_context") and wi.message_context.trace_id
            else "<none>"
        )
        async with self._lock:
            link_name = self._producer_to_link.get(producer)
            if not link_name:
                logger.debug('putOpNetMessage("%s"): unknown producer', producer)
                return Result(ok=False, message="unknown producer")
            link = self._links.get(link_name)
            if not link:
                logger.debug('putOpNetMessage("%s"): link not found "%s"', producer, link_name)
                return Result(ok=False, message="link not found")
            link.queue.put_nowait(wi)
            logger.debug(
                'putOpNetMessage("%s"): enqueued on link "%s" trace_id=%s (qsize=%d)',
                producer,
                link_name,
                trace_id,
                link.queue.qsize(),
            )
            return Result(ok=True)

    async def async_getOpNetMessage(self, port_name: str) -> Tuple[Result, Optional[str], Optional[OpNetMessage]]:
        consumer = port_name
        link_name: Optional[str] = None
        cstate: Optional[_ConsumerState] = None
        link: Optional[_Link] = None
        acquired = False
        got_item = False
        wi: Optional[OpNetMessage] = None

        try:
            # First read under lock
            async with self._lock:
                link_name = self._consumer_to_link.get(consumer)
                if not link_name:
                    logger.debug('getOpNetMessage("%s"): unknown consumer', consumer)
                    return Result(ok=False, message="unknown consumer"), None, None
                link = self._links.get(link_name)
                if not link:
                    logger.debug('getOpNetMessage("%s"): link not found "%s"', consumer, link_name)
                    return Result(ok=False, message="link not found"), None, None
                cstate = self._consumer_to_state.get(consumer)
                if not cstate:
                    logger.debug('getOpNetMessage("%s"): consumer state missing', consumer)
                    return Result(ok=False, message="consumer state missing"), None, None

            # Acquire slot outside lock; this blocks if at cap
            logger.debug('getOpNetMessage("%s"): acquiring slot (max_concurrency gate)', consumer)
            await cstate.slots.acquire()
            acquired = True
            logger.debug('getOpNetMessage("%s"): slot acquired', consumer)

            # Re-validate link under lock in case of concurrent removal
            async with self._lock:
                # Re-fetch in case links changed
                assert link_name is not None
                link = self._links.get(link_name)
                if not link:
                    logger.debug('getOpNetMessage("%s"): link disappeared "%s"; releasing slot', consumer, link_name)
                    cstate.slots.release()
                    acquired = False
                    return Result(ok=False, message="link not found"), None, None

            logger.debug('getOpNetMessage("%s"): waiting for queue item on link "%s"', consumer, link_name)
            wi = await link.queue.get()  # increments unfinished task count
            got_item = True
            message_id = str(uuid.uuid4())
            trace_id = (
                wi.message_context.trace_id
                if wi.HasField("message_context") and wi.message_context.trace_id
                else "<none>"
            )
            async with self._lock:
                self._in_flight_by_id[message_id] = _InFlight(
                    message_id=message_id, opnet_message=wi, consumer=consumer, link_name=link_name
                )
            logger.debug(
                'getOpNetMessage("%s"): delivered message_id=%s trace_id=%s (qsize=%d)',
                consumer,
                message_id,
                trace_id,
                link.queue.qsize(),
            )
            return Result(ok=True), message_id, wi

        except asyncio.CancelledError:
            logger.info('getOpNetMessage("%s"): cancelled; restoring state', consumer)
            if got_item and wi is not None and link is not None:
                # Balance unfinished count, then re-queue
                link.queue.task_done()
                link.queue.put_nowait(wi)
                logger.debug(
                    'getOpNetMessage("%s"): item restored to queue (qsize=%d)',
                    consumer,
                    link.queue.qsize(),
                )
            if acquired and cstate is not None:
                cstate.slots.release()
            raise

    async def async_ack(self, port_name: str, message_id: str) -> Result:
        consumer = port_name
        async with self._lock:
            if message_id not in self._in_flight_by_id:
                logger.debug("ack(%s): unknown/duplicate", message_id)
                return Result(ok=True, message="unknown or already acked/nacked")
            inf = self._in_flight_by_id.get(message_id)
            if inf is None:
                return Result(ok=True, message="unknown or already acked/nacked")
            if inf.consumer != consumer:
                logger.warning("ack(%s) from incorrect consumer %s", message_id, consumer)
            # Remove from inflight under lock
            self._in_flight_by_id.pop(message_id, None)
            link = self._links.get(inf.link_name)
            cstate = self._consumer_to_state.get(inf.consumer)
        # Balance unfinished tasks and release slot
        if link:
            link.queue.task_done()
        if cstate:
            cstate.slots.release()
        logger.info('ack(%s): ok (consumer="%s" link="%s")', message_id, inf.consumer, inf.link_name)
        return Result(ok=True)

    async def async_nack(self, port_name: str, message_id: str) -> Result:
        consumer = port_name
        async with self._lock:
            if message_id not in self._in_flight_by_id:
                logger.debug("nack(%s): unknown/duplicate", message_id)
                return Result(ok=True, message="unknown or already acked/nacked")
            inf = self._in_flight_by_id.get(message_id)
            if inf is None:
                return Result(ok=True, message="unknown or already acked/nacked")
            if inf.consumer != consumer:
                logger.warning("nack(%s) from incorrect consumer %s", message_id, consumer)
            self._in_flight_by_id.pop(message_id, None)
            link = self._links.get(inf.link_name)
            cstate = self._consumer_to_state.get(inf.consumer)
        # Mark prior get() complete, then requeue for redelivery; release slot
        if link:
            link.queue.task_done()
            link.queue.put_nowait(inf.opnet_message)
            logger.debug(
                'nack(%s): requeued on link "%s" (qsize=%d)',
                message_id,
                inf.link_name,
                link.queue.qsize(),
            )
        if cstate:
            cstate.slots.release()
        logger.info('nack(%s): ok (consumer="%s" link="%s")', message_id, inf.consumer, inf.link_name)
        return Result(ok=True)

    async def async_nackAll(self, port_name: str) -> Result:
        async with self._lock:
            inflight_ids = list(self._in_flight_by_id.keys())
            logger.info("nackAll(%s): initiating shutdown; inflight_count=%d", port_name, len(inflight_ids))

        nacked_count = 0
        for tid in inflight_ids:
            async with self._lock:
                inf = self._in_flight_by_id.get(tid)
                if not inf or not inf.consumer == port_name:
                    continue
                # Remove from inflight, capture refs
                self._in_flight_by_id.pop(tid, None)
                link = self._links.get(inf.link_name)
                cstate = self._consumer_to_state.get(inf.consumer)
                nacked_count += 1
            if link:
                # Mark done for the prior get() and requeue
                link.queue.task_done()
                link.queue.put_nowait(inf.opnet_message)
            if cstate:
                cstate.slots.release()

        logger.info("nackAll(%s): completed; nacked_inflight=%d", port_name, nacked_count)
        return Result(ok=True, message=f"nacked {nacked_count} in-flight items")

    # ---------- helpers ----------

    @staticmethod
    def _parseMemUri(s: str) -> str:
        return s[len("mem://") :] if s.startswith("mem://") else s


# -------------------------- Public plugin implementations --------------------------

class InMemoryOpNetControllerPlugin(OpNetControllerPlugin):
    def __init__(self, bus: Optional[_InMemoryBus] = None) -> None:
        self._bus = bus or _InMemoryBus()
        logger.debug("InMemoryOpNetControllerPlugin: initialized (bus=%s)", id(self._bus))

    def getSubstrate(self) -> str:
        return "in-memory"

    @property
    def bus(self) -> _InMemoryBus:
        return self._bus

    async def async_createLink(self, *, link_id: str) -> Tuple[Result, str]:
        logger.debug('Controller.async_createLink("%s")', link_id)
        return await self._bus.async_createLink(link_id)

    async def async_getLink(self, *, link_id: str) -> Tuple[Result, Optional[str]]:
        logger.debug('Controller.async_getLink("%s")', link_id)
        return await self._bus.async_getLink(link_id)

    def getLinkIdFromLinkRef(self, *, link_ref: str) -> Tuple[Result, Optional[str]]:
        link_id = link_ref[len("mem://") :] if link_ref.startswith("mem://") else link_ref
        link_id = link_id.strip()
        if not link_id:
            return Result(ok=False, message="invalid link_ref"), None
        if ":" in link_id:
            return Result(ok=False, message="invalid link_ref"), None
        return Result(ok=True, message="ok"), link_id

    async def async_removeLink(self, *, link_ref: str) -> Result:
        logger.debug('Controller.async_removeLink("%s")', link_ref)
        return await self._bus.async_removeLink(link_ref)
    
    async def async_getBacklog(self, *, link_ref: str) -> Tuple[Result, Optional[int]]:
        logger.debug('Controller.async_getBackog(%s)', link_ref)
        return await self._bus.async_getBacklog(link_ref)

    async def async_injectMessageIntoLink(self, *, link_ref: str, opnet_message: OpNetMessage) -> Result:
        link_name = link_ref[len("mem://") :] if link_ref.startswith("mem://") else link_ref
        injector_name = f"opnet-manager-injector-{link_name}"
        trace_id = (
            opnet_message.message_context.trace_id
            if opnet_message.HasField("message_context")
            and opnet_message.message_context.trace_id
            else "<none>"
        )
        logger.debug(
            'Controller.async_injectMessageIntoLink(link_ref="%s", injector="%s", trace_id=%s, payload_type=%s, payload_bytes=%d)',
            link_ref,
            injector_name,
            trace_id,
            opnet_message.payload_type.type_url or "<none>",
            len(opnet_message.payload),
        )
        bind_result, _ = await self._bus.async_addProducer(link_ref, injector_name)
        if not bind_result.ok:
            logger.debug(
                'Controller.async_injectMessageIntoLink bind failed link_ref="%s" injector="%s" message=%s',
                link_ref,
                injector_name,
                bind_result.message or "<none>",
            )
            return bind_result
        put_result = await self._bus.async_putOpNetMessage(injector_name, opnet_message)
        logger.debug(
            'Controller.async_injectMessageIntoLink publish result link_ref="%s" injector="%s" trace_id=%s ok=%s message=%s',
            link_ref,
            injector_name,
            trace_id,
            put_result.ok,
            put_result.message or "<none>",
        )
        return put_result


class InMemoryOpNetNodePlugin(OpNetNodePlugin):
    def __init__(self, bus: _InMemoryBus) -> None:
        self._bus = bus
        logger.debug("InMemoryOpNetNodePlugin: initialized (bus=%s)", id(self._bus))

    def getSubstrate(self) -> str:
        return "in-memory"

    async def async_addProducer(self, *, link_ref: str, port_name: str) -> Tuple[Result, str]:
        logger.debug('Sidecar.async_addProducer(name="%s", link="%s")', port_name, link_ref)
        return await self._bus.async_addProducer(link_ref, port_name)

    async def async_addConsumer(
        self, *, link_ref: str, port_name: str, max_concurrency: int
    ) -> Tuple[Result, str]:
        logger.debug(
            'Sidecar.async_addConsumer(name="%s", link="%s", max_concurrency=%d)',
            port_name,
            link_ref,
            max_concurrency,
        )
        return await self._bus.async_addConsumer(link_ref, port_name, max_concurrency)

    async def async_putOpNetMessage(self, *, port_name: str, opnet_message: OpNetMessage) -> Result:
        logger.debug('Sidecar.async_putOpNetMessage(conn="%s")', port_name)
        return await self._bus.async_putOpNetMessage(port_name, opnet_message)

    async def async_getOpNetMessage(self, *, port_name: str) -> Tuple[Result, Optional[str], Optional[OpNetMessage]]:
        logger.debug('Sidecar.async_getOpNetMessage(conn="%s")', port_name)
        return await self._bus.async_getOpNetMessage(port_name)

    async def async_ack(self, *, port_name: str, message_id: str) -> Result:
        logger.debug('Sidecar.async_ack(message_id=%s)', message_id)
        return await self._bus.async_ack(port_name, message_id)

    async def async_nack(self, *, port_name: str, message_id: str) -> Result:
        logger.debug('Sidecar.async_nack(message_id=%s)', message_id)
        return await self._bus.async_nack(port_name, message_id)

    async def async_nackAll(self, *, port_name: str) -> Result:
        logger.debug('Sidecar.async_nackAll()')
        return await self._bus.async_nackAll(port_name)
