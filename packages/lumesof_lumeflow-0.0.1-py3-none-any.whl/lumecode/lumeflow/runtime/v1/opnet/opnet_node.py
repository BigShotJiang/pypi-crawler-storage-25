# lumecode/lumeflow/runtime/v1/opnet_node.py

from __future__ import annotations

import asyncio
import logging
import threading
import uuid
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence, Set, Tuple

from contextlib import asynccontextmanager

from sqlalchemy import delete, func, insert, outerjoin, select, update
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker
from sqlalchemy.exc import DBAPIError, IntegrityError

from lumecode.base.python.sqldb import crdb_async_utils as sqldb_utils
from lumecode.lumeflow.runtime.v1.opnet import opnet_types_pb2
from lumecode.lumeflow.runtime.v1.opnet.opnet_error import OpNetError, OpNetErrorCode
from lumecode.lumeflow.runtime.v1.opnet.opnet_plugin_interface import OpNetControllerPlugin

from lumecode.crdb.schemas.dev_cluster.flow.db_orm_models import (
    TabControllers,
    TabNodes,
    TabPorts,
    t_join_port_link_bindings,
)

logger = logging.getLogger(__name__)

_NodeKey = Tuple[uuid.UUID, uuid.UUID]  # (cluster_id, node_id)
JoinPortLinkBindings = t_join_port_link_bindings


def _likePrefix(prefix: Optional[str]) -> Optional[str]:
    if not prefix:
        return None
    return f"{prefix}%"


@dataclass
class PortInfo:
    name: str
    kind: str
    payload_type: bytes
    link_id: Optional[uuid.UUID] = None


@dataclass
class OpNetPort:
    id: uuid.UUID
    node_id: uuid.UUID
    name: str
    kind: str
    payload_type: bytes
    link_id: Optional[uuid.UUID]


@dataclass(frozen=True)
class _DeactivateItem:
    name: str
    port_id: uuid.UUID


@asynccontextmanager
async def _transaction(session):
    async with sqldb_utils.async_transactionContext(existing_session=session) as tx_ctx:
        yield tx_ctx.session


class OpNetNode:
    """Lightweight runtime wrapper for an OpNet node and its ports."""

    def __init__(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        plugin: OpNetControllerPlugin,
        node_id: uuid.UUID,
        cluster_id: uuid.UUID,
        controller_id: uuid.UUID,
        usecase: str,
        name: str,
        connection_status: str,
    ) -> None:
        self.session_maker = session_maker
        self.plugin = plugin
        self.id = node_id
        self.cluster_id = cluster_id
        self.controller_id = controller_id
        self.usecase = usecase
        self.name = name
        self.connection_status = connection_status

        self._ports: Dict[uuid.UUID, OpNetPort] = {}
        self._lock = asyncio.Lock()

    async def async_listPorts(self) -> List[OpNetPort]:
        async with self._lock:
            return list(self._ports.values())

    async def async_getPort(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        port_id: uuid.UUID,
    ) -> OpNetPort:
        async with self._lock:
            cached = self._ports.get(port_id)
        if cached is not None:
            return cached

        ports_join = outerjoin(
            TabPorts,
            JoinPortLinkBindings,
            TabPorts.id == JoinPortLinkBindings.c.port_id,
        )
        async with session_maker() as session:
            row = (
                await session.execute(
                    select(
                        TabPorts.id,
                        TabPorts.name,
                        TabPorts.kind,
                        TabPorts.payload_type,
                        JoinPortLinkBindings.c.link_id,
                    )
                    .select_from(ports_join)
                    .where(
                        (TabPorts.id == port_id)
                        & (TabPorts.node_id == self.id)
                    )
                )
            ).one_or_none()

        if row is None:
            raise OpNetError(OpNetErrorCode.NOT_FOUND, "Port not found in this node.")

        pid, name, kind, payload, link_id = row
        port = OpNetPort(
            id=pid,
            node_id=self.id,
            name=name,
            kind=kind,
            payload_type=bytes(payload) if isinstance(payload, memoryview) else payload,
            link_id=link_id,
        )
        async with self._lock:
            self._ports[pid] = port
        return port

    async def async_createPort(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        port: PortInfo,
    ) -> OpNetPort:
        port_info = port
        name = port_info.name
        kind = port_info.kind
        payload_type = port_info.payload_type
        link_id = port_info.link_id

        async with session_maker() as session:
            try:
                async with _transaction(session):
                    existing = (
                        await session.execute(
                            select(TabPorts.id)
                            .where((TabPorts.node_id == self.id) & (TabPorts.name == name))
                        )
                    ).scalar_one_or_none()
                    if existing is not None:
                        raise OpNetError(
                            OpNetErrorCode.ALREADY_EXISTS,
                            f"Port name {name!r} already exists on node.",
                        )
                    row = (
                        await session.execute(
                            insert(TabPorts)
                            .values(
                                node_id=self.id,
                                name=name,
                                kind=kind,
                                payload_type=payload_type,
                            )
                            .returning(
                                TabPorts.id,
                                TabPorts.name,
                                TabPorts.kind,
                                TabPorts.payload_type,
                            )
                        )
                    ).one()
            except IntegrityError as exc:
                raise OpNetError(
                    OpNetErrorCode.ALREADY_EXISTS,
                    f"Port name {name!r} already exists on node.",
                ) from exc

        pid, db_name, db_kind, db_payload = row
        created_port = OpNetPort(
            id=pid,
            node_id=self.id,
            name=db_name,
            kind=db_kind,
            payload_type=bytes(db_payload) if isinstance(db_payload, memoryview) else db_payload,
            link_id=None,
        )

        if link_id is not None:
            await self.async_bindPortToLink(
                session_maker=session_maker,
                port_id=pid,
                link_id=link_id,
            )
            created_port.link_id = link_id

        async with self._lock:
            self._ports[pid] = created_port
        return created_port

    async def async_deletePort(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        port_id: uuid.UUID,
    ) -> None:
        async with session_maker() as session:
            async with _transaction(session):
                res = await session.execute(
                    delete(TabPorts)
                    .where(
                        (TabPorts.id == port_id)
                        & (TabPorts.node_id == self.id)
                    )
                    .returning(TabPorts.id)
                )
                row = res.one_or_none()
                if row is None:
                    raise OpNetError(OpNetErrorCode.NOT_FOUND, "Port not found in this node.")

        async with self._lock:
            self._ports.pop(port_id, None)

    async def async_bindPortToLink(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        port_id: uuid.UUID,
        link_id: uuid.UUID,
    ) -> None:
        port = await self.async_getPort(session_maker=session_maker, port_id=port_id)

        async with session_maker() as session:
            async with _transaction(session):
                await session.execute(
                    delete(JoinPortLinkBindings).where(JoinPortLinkBindings.c.port_id == port_id)
                )
                await session.execute(
                    insert(JoinPortLinkBindings).values(port_id=port_id, link_id=link_id)
                )

        port.link_id = link_id

    async def async_unbindPort(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        port_id: uuid.UUID,
    ) -> None:
        port = await self.async_getPort(session_maker=session_maker, port_id=port_id)

        async with session_maker() as session:
            async with _transaction(session):
                await session.execute(
                    delete(JoinPortLinkBindings).where(JoinPortLinkBindings.c.port_id == port_id)
                )

        port.link_id = None

    async def async_refreshPorts(self) -> None:
        ports_join = outerjoin(
            TabPorts,
            JoinPortLinkBindings,
            TabPorts.id == JoinPortLinkBindings.c.port_id,
        )
        async with self.session_maker() as session:
            rows = (
                await session.execute(
                    select(
                        TabPorts.id,
                        TabPorts.name,
                        TabPorts.kind,
                        TabPorts.payload_type,
                        JoinPortLinkBindings.c.link_id,
                    )
                    .select_from(ports_join)
                    .where(TabPorts.node_id == self.id)
                )
            ).all()

        ports = {
            pid: OpNetPort(
                id=pid,
                node_id=self.id,
                name=name,
                kind=kind,
                payload_type=bytes(payload) if isinstance(payload, memoryview) else payload,
                link_id=link_id,
            )
            for pid, name, kind, payload, link_id in rows
        }

        async with self._lock:
            self._ports = ports

    async def async_refresh(self) -> None:
        async with self.session_maker() as session:
            row = (
                await session.execute(
                    select(
                        TabNodes.id,
                        TabNodes.name,
                        TabNodes.controller_id,
                        TabNodes.connection_status,
                        TabControllers.cluster_id,
                        TabControllers.usecase,
                    )
                    .join(TabControllers, TabNodes.controller_id == TabControllers.id)
                    .where(
                        (TabNodes.id == self.id)
                        & (TabControllers.cluster_id == self.cluster_id)
                        & (TabControllers.usecase == self.usecase)
                    )
                )
            ).one_or_none()

        if row is None:
            raise OpNetError(OpNetErrorCode.NOT_FOUND, "Node not found in this collection.")

        _, name, controller_id, connection_status, cluster_id, usecase = row
        self.name = name
        self.controller_id = controller_id
        self.cluster_id = cluster_id
        self.usecase = usecase
        self.connection_status = connection_status

        await self.async_refreshPorts()


class OpNetNodeCollection:
    """Collection of nodes scoped to (cluster_id, usecase)."""

    def __init__(
        self,
        *,
        cluster_id: uuid.UUID,
        usecase: str,
        plugin: OpNetControllerPlugin,
    ) -> None:
        self._cluster_id = cluster_id
        self._usecase = usecase
        self._plugin = plugin

        self._instances: Dict[_NodeKey, OpNetNode] = {}
        self._locks: Dict[_NodeKey, asyncio.Lock] = {}
        self._by_controller: Dict[uuid.UUID, Dict[uuid.UUID, OpNetNode]] = {}
        self._dict_lock = threading.Lock()

    def _nkey(self, node_id: uuid.UUID) -> _NodeKey:
        return (self._cluster_id, node_id)

    def _getOrCreateLock(self, key: _NodeKey) -> asyncio.Lock:
        with self._dict_lock:
            lock = self._locks.get(key)
            if lock is None:
                lock = asyncio.Lock()
                self._locks[key] = lock
        return lock

    def _cachePut(self, node: OpNetNode) -> None:
        key = self._nkey(node.id)
        with self._dict_lock:
            self._instances[key] = node
            bucket = self._by_controller.setdefault(node.controller_id, {})
            bucket[node.id] = node

    def _cacheBulkPut(self, items: Dict[_NodeKey, OpNetNode]) -> None:
        with self._dict_lock:
            for key, node in items.items():
                self._instances[key] = node
                bucket = self._by_controller.setdefault(node.controller_id, {})
                bucket[node.id] = node
        logger.info(
            f"NodeCollection cacheBulkPut: upserted {len(items)} nodes (cluster={self._cluster_id} usecase={self._usecase})"
        )

    def _cacheGet(self, node_id: uuid.UUID) -> Optional[OpNetNode]:
        with self._dict_lock:
            return self._instances.get(self._nkey(node_id))

    def getCachedNode(self, node_id: uuid.UUID) -> Optional[OpNetNode]:
        """Return the cached node if present without touching the database."""
        return self._cacheGet(node_id)

    async def _upsertPorts(
        self,
        *,
        session: AsyncSession,
        node_id: uuid.UUID,
        ports: Iterable[PortInfo],
    ) -> None:
        port_items = list(ports)
        if not port_items:
            return

        ports_join = outerjoin(
            TabPorts,
            JoinPortLinkBindings,
            TabPorts.id == JoinPortLinkBindings.c.port_id,
        )
        rows = (
            await session.execute(
                select(
                    TabPorts.id,
                    TabPorts.name,
                    TabPorts.kind,
                    TabPorts.payload_type,
                    JoinPortLinkBindings.c.link_id,
                )
                .select_from(ports_join)
                .where(TabPorts.node_id == node_id)
            )
        ).all()

        existing_by_name: Dict[str, Tuple[uuid.UUID, str, bytes, Optional[uuid.UUID]]] = {}
        for pid, name, kind, payload, link_id in rows:
            payload_bytes = bytes(payload) if isinstance(payload, memoryview) else payload
            existing_by_name[name] = (pid, kind, payload_bytes, link_id)

        for port in port_items:
            desired_payload = port.payload_type
            existing = existing_by_name.get(port.name)
            if existing is not None:
                pid, existing_kind, existing_payload, existing_link = existing
                updates = {}
                if existing_kind != port.kind:
                    updates["kind"] = port.kind
                if existing_payload != desired_payload:
                    updates["payload_type"] = desired_payload
                if updates:
                    await session.execute(
                        update(TabPorts)
                        .where((TabPorts.id == pid) & (TabPorts.node_id == node_id))
                        .values(**updates)
                    )
            else:
                result = await session.execute(
                    insert(TabPorts)
                    .values(
                        node_id=node_id,
                        name=port.name,
                        kind=port.kind,
                        payload_type=desired_payload,
                    )
                    .returning(TabPorts.id)
                )
                pid = result.scalar_one()
                existing_link = None

            desired_link = port.link_id
            current_link = existing_link if existing is not None else None
            if current_link != desired_link:
                await session.execute(
                    delete(JoinPortLinkBindings).where(JoinPortLinkBindings.c.port_id == pid)
                )
                if desired_link is not None:
                    await session.execute(
                        insert(JoinPortLinkBindings).values(port_id=pid, link_id=desired_link)
                    )

            existing_by_name[port.name] = (pid, port.kind, desired_payload, desired_link)

    def getNodesByController(self, controller_id: uuid.UUID) -> List[OpNetNode]:
        with self._dict_lock:
            bucket = self._by_controller.get(controller_id)
            if not bucket:
                return []
            return list(bucket.values())

    async def _asyncActivateNodeAndPorts(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        node: OpNetNode,
    ) -> None:
        logger.info(
            f"NodeCollection _asyncMarkNodeConnected: updating node_id={node.id} controller_id={node.controller_id}"
        )
        async with session_maker() as session:
            async with _transaction(session):
                node_result = await session.execute(
                    update(TabNodes)
                    .where((TabNodes.id == node.id) & (TabNodes.controller_id == node.controller_id))
                    .values(connection_status="CONNECTED")
                )
                if node_result.rowcount == 0:
                    raise OpNetError(
                        OpNetErrorCode.NOT_FOUND,
                        "Node not found while updating connection status.",
                    )

                await session.execute(
                    update(TabPorts)
                    .where((TabPorts.node_id == node.id) & (TabPorts.activity_status != "ACTIVE"))
                    .values(activity_status="ACTIVE")
                )

        node.connection_status = "CONNECTED"

    async def async_loadAllNodes(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        controller_ids: Optional[Iterable[uuid.UUID]] = None,
        name_prefix: Optional[str] = None,
    ) -> None:
        logger.info(
            f"NodeCollection async_loadAllNodes: begin cluster={self._cluster_id} usecase={self._usecase}"
        )
        async with session_maker() as session:
            stmt = (
                select(
                    TabNodes.id,
                    TabNodes.name,
                    TabNodes.controller_id,
                    TabNodes.connection_status,
                    TabControllers.cluster_id,
                    TabControllers.usecase,
                )
                .join(TabControllers, TabNodes.controller_id == TabControllers.id)
                .where(
                    (TabControllers.cluster_id == self._cluster_id)
                    & (TabControllers.usecase == self._usecase)
                )
            )
            if controller_ids:
                stmt = stmt.where(TabNodes.controller_id.in_(list(controller_ids)))
            prefix = _likePrefix(name_prefix)
            if prefix:
                stmt = stmt.where(TabNodes.name.like(prefix))
            rows = (await session.execute(stmt)).all()

        new_items: Dict[_NodeKey, OpNetNode] = {}
        for (nid, name, controller_id, connection_status, clid, usecase) in rows:
            new_items[self._nkey(nid)] = OpNetNode(
                session_maker=session_maker,
                plugin=self._plugin,
                node_id=nid,
                cluster_id=clid,
                controller_id=controller_id,
                usecase=usecase,
                name=name,
                connection_status=connection_status,
            )

        if new_items:
            self._cacheBulkPut(new_items)

        logger.info(
            f"NodeCollection async_loadAllNodes: done cluster={self._cluster_id} usecase={self._usecase} cached={len(new_items)}"
        )

    async def async_refreshNodes(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        node_ids: Optional[List[uuid.UUID]] = None,
        controller_ids: Optional[Iterable[uuid.UUID]] = None,
        name_prefix: Optional[str] = None,
    ) -> None:
        ids = node_ids

        if ids is None:
            await self.async_loadAllNodes(
                session_maker=session_maker,
                controller_ids=controller_ids,
                name_prefix=name_prefix,
            )
            return

        if len(ids) == 0:
            logger.debug(
                f"NodeCollection async_refreshNodes: no ids cluster={self._cluster_id} usecase={self._usecase}"
            )
            return

        logger.info(
            f"NodeCollection async_refreshNodes: begin cluster={self._cluster_id} usecase={self._usecase} count={len(ids)}"
        )

        async with session_maker() as session:
            stmt = (
                select(
                    TabNodes.id,
                    TabNodes.name,
                    TabNodes.controller_id,
                    TabNodes.connection_status,
                    TabControllers.cluster_id,
                    TabControllers.usecase,
                )
                .join(TabControllers, TabNodes.controller_id == TabControllers.id)
                .where(
                    (TabNodes.id.in_(ids))
                    & (TabControllers.cluster_id == self._cluster_id)
                    & (TabControllers.usecase == self._usecase)
                )
            )
            rows = (await session.execute(stmt)).all()

        updated: Dict[_NodeKey, OpNetNode] = {}
        found_keys: Set[_NodeKey] = set()
        for (nid, name, controller_id, connection_status, clid, usecase) in rows:
            key = self._nkey(nid)
            found_keys.add(key)
            updated[key] = OpNetNode(
                session_maker=session_maker,
                plugin=self._plugin,
                node_id=nid,
                cluster_id=clid,
                controller_id=controller_id,
                usecase=usecase,
                name=name,
                connection_status=connection_status,
            )

        if updated:
            self._cacheBulkPut(updated)

        requested_keys = {self._nkey(nid) for nid in ids}
        missing_keys = requested_keys - found_keys
        if missing_keys:
            with self._dict_lock:
                for key in missing_keys:
                    node = self._instances.pop(key, None)
                    if node is not None:
                        bucket = self._by_controller.get(node.controller_id)
                        if bucket:
                            bucket.pop(node.id, None)
            logger.info(
                f"NodeCollection async_refreshNodes: removed {len(missing_keys)} nodes no longer present in DB"
            )

        logger.info(
            f"NodeCollection async_refreshNodes: done cluster={self._cluster_id} usecase={self._usecase}"
        )

    async def async_createNode(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        controller_id: uuid.UUID,
        name: str,
        ports: Optional[Iterable[PortInfo]] = None,
    ) -> OpNetNode:
        port_items = list(ports or [])
        should_refresh_ports = bool(port_items)
        async with session_maker() as session:
            row: Optional[Tuple[uuid.UUID, str, uuid.UUID, str]] = None

            async def _attempt() -> None:
                nonlocal row
                async with _transaction(session):
                    controller_row = (
                        await session.execute(
                            select(TabControllers.id)
                            .where(
                                (TabControllers.id == controller_id)
                                & (TabControllers.cluster_id == self._cluster_id)
                                & (TabControllers.usecase == self._usecase)
                            )
                        )
                    ).scalar_one_or_none()
                    if controller_row is None:
                        raise OpNetError(
                            OpNetErrorCode.FAILED_PRECONDITION,
                            "Controller not found in this collection.",
                        )

                    row = (
                        await session.execute(
                            insert(TabNodes)
                            .values(
                                name=name,
                                controller_id=controller_id,
                            )
                            .returning(
                                TabNodes.id,
                                TabNodes.name,
                                TabNodes.controller_id,
                                TabNodes.connection_status,
                            )
                        )
                    ).one()
                    if should_refresh_ports:
                        await self._upsertPorts(
                            session=session,
                            node_id=row[0],
                            ports=port_items,
                        )

            try:
                await sqldb_utils.async_runWithSerializationRetries(
                    _attempt,
                    is_retryable=sqldb_utils.isRetryableSerializationError,
                    sleep_fn=asyncio.sleep,
                )
            except IntegrityError as exc:
                existing = (
                    await session.execute(
                        select(
                            TabNodes.id,
                            TabNodes.name,
                            TabNodes.controller_id,
                            TabNodes.connection_status,
                            TabControllers.cluster_id,
                            TabControllers.usecase,
                        )
                        .join(TabControllers, TabNodes.controller_id == TabControllers.id)
                        .where(
                            (TabNodes.controller_id == controller_id)
                            & (TabNodes.name == name)
                        )
                    )
                ).one_or_none()
                if existing is None:
                    raise OpNetError(
                        OpNetErrorCode.FAILED_PRECONDITION,
                        "Node could not be created due to conflicting state.",
                    ) from exc
                nid, db_name, db_controller, connection_status, clid, usecase = existing
                if clid != self._cluster_id or usecase != self._usecase:
                    raise OpNetError(
                        OpNetErrorCode.FAILED_PRECONDITION,
                        "Node id already exists with different attributes.",
                    ) from exc
                row = (nid, db_name, db_controller, connection_status)
                if should_refresh_ports:
                    try:
                        async with session_maker() as port_session:
                            async with _transaction(port_session):
                                await self._upsertPorts(
                                    session=port_session,
                                    node_id=nid,
                                    ports=port_items,
                                )
                    except IntegrityError as port_exc:
                        raise OpNetError(
                            OpNetErrorCode.FAILED_PRECONDITION,
                            "Node could not be created due to conflicting state.",
                        ) from port_exc
            except OpNetError:
                raise
            except DBAPIError:
                raise

        if row is None:
            raise OpNetError(
                OpNetErrorCode.INTERNAL,
                "Node could not be created.",
            )
        nid, db_name, db_controller, connection_status = row
        cached = self._cacheGet(nid)
        if cached is not None:
            cached.connection_status = connection_status
            if should_refresh_ports:
                await cached.async_refreshPorts()
            return cached

        node = OpNetNode(
            session_maker=session_maker,
            plugin=self._plugin,
            node_id=nid,
            cluster_id=self._cluster_id,
            controller_id=db_controller,
            usecase=self._usecase,
            name=db_name,
            connection_status=connection_status,
        )
        if should_refresh_ports:
            await node.async_refreshPorts()
        self._cachePut(node)
        logger.info(f"NodeCollection async_createNode: created id={nid}")
        return node

    async def async_removeNode(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        node_id: uuid.UUID,
    ) -> None:
        key = self._nkey(node_id)
        lock = self._getOrCreateLock(key)

        async with lock:
            async def _attempt() -> None:
                async with session_maker() as session:
                    async with _transaction(session):
                        row = (
                            await session.execute(
                                select(TabNodes.controller_id)
                                .join(TabControllers, TabNodes.controller_id == TabControllers.id)
                                .where(
                                    (TabNodes.id == node_id)
                                    & (TabControllers.cluster_id == self._cluster_id)
                                    & (TabControllers.usecase == self._usecase)
                                )
                            )
                        ).scalar_one_or_none()
                        if row is None:
                            raise OpNetError(
                                OpNetErrorCode.NOT_FOUND,
                                "Node not found in this collection.",
                            )

                        await session.execute(delete(TabNodes).where(TabNodes.id == node_id))

            try:
                await sqldb_utils.async_runWithSerializationRetries(
                    _attempt,
                    is_retryable=sqldb_utils.isRetryableSerializationError,
                    sleep_fn=asyncio.sleep,
                )
            except DBAPIError as exc:
                if sqldb_utils.isRetryableSerializationError(exc):
                    logger.warning(
                        f"NodeCollection async_removeNode serialization retries exhausted node_id={node_id}",
                    )
                raise

            with self._dict_lock:
                node = self._instances.pop(key, None)
                if node is not None:
                    bucket = self._by_controller.get(node.controller_id)
                    if bucket:
                        bucket.pop(node.id, None)

        logger.info(
            f"NodeCollection async_removeNode: deleted node id={node_id}"
        )

    async def async_getNode(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        node_id: uuid.UUID,
    ) -> OpNetNode:
        cached = self._cacheGet(node_id)
        if cached is not None:
            if cached.cluster_id != self._cluster_id or cached.usecase != self._usecase:
                logger.error(
                    f"NodeCollection async_getNode: cached instance mismatch key={self._nkey(node_id)}"
                )
                raise OpNetError(OpNetErrorCode.INTERNAL, "Cached instance collection mismatch.")
            return cached

        async with session_maker() as session:
            row = (
                await session.execute(
                    select(
                        TabNodes.id,
                        TabNodes.name,
                        TabNodes.controller_id,
                        TabNodes.connection_status,
                        TabControllers.cluster_id,
                        TabControllers.usecase,
                    )
                    .join(TabControllers, TabNodes.controller_id == TabControllers.id)
                    .where(
                        (TabNodes.id == node_id)
                        & (TabControllers.cluster_id == self._cluster_id)
                        & (TabControllers.usecase == self._usecase)
                    )
                )
            ).one_or_none()

        if row is None:
            logger.info(
                f"NodeCollection async_getNode: node not found cluster={self._cluster_id} usecase={self._usecase} id={node_id}"
            )
            raise OpNetError(OpNetErrorCode.NOT_FOUND, "Node not found in this collection.")

        nid, name, controller_id, connection_status, clid, usecase = row
        node = OpNetNode(
            session_maker=session_maker,
            plugin=self._plugin,
            node_id=nid,
            cluster_id=clid,
            controller_id=controller_id,
            usecase=usecase,
            name=name,
            connection_status=connection_status,
        )
        self._cachePut(node)
        return node

    async def async_connect(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        node_id: uuid.UUID,
        ports: Iterable[opnet_types_pb2.OpNetPort],
    ) -> Tuple[opnet_types_pb2.Result, Optional[List[opnet_types_pb2.OpNetConnection]]]:
        try:
            if ports is None:
                raise OpNetError(OpNetErrorCode.INVALID_ARGUMENT, "ports must be provided.")

            requested_ports = list(ports)
            logger.info(
                f"NodeCollection async_connect: begin cluster={self._cluster_id} usecase={self._usecase} node_id={node_id} port_count={len(requested_ports)}"
            )

            node = self.getCachedNode(node_id)
            if node is None:
                node = await self.async_getNode(session_maker=session_maker, node_id=node_id)

            request_by_name: Dict[str, opnet_types_pb2.OpNetPort] = {}
            request_order: List[str] = []
            for proto in requested_ports:
                name = proto.port_name
                if not name:
                    raise OpNetError(
                        OpNetErrorCode.INVALID_ARGUMENT,
                        "ports must include port_name for every entry.",
                    )
                if name in request_by_name:
                    raise OpNetError(
                        OpNetErrorCode.INVALID_ARGUMENT,
                        f"Duplicate port_name {name!r} in connect request.",
                    )
                request_by_name[name] = proto
                request_order.append(name)

            async def _ports_by_name(*, refresh: bool = False) -> Dict[str, OpNetPort]:
                if refresh:
                    await node.async_refreshPorts()
                current_ports = await node.async_listPorts()
                mapping = {p.name: p for p in current_ports}
                if len(mapping) != len(current_ports):
                    raise OpNetError(
                        OpNetErrorCode.INTERNAL,
                        f"Duplicate port names detected for node {node.id}",
                    )
                return mapping

            actual_by_name = await _ports_by_name()
            actual_names = set(actual_by_name)
            requested_names = set(request_by_name)
            if not actual_by_name or actual_names != requested_names:
                actual_by_name = await _ports_by_name(refresh=True)
                actual_names = set(actual_by_name)

            if actual_names != requested_names:
                missing = sorted(actual_names - requested_names)
                extras = sorted(requested_names - actual_names)
                raise OpNetError(
                    OpNetErrorCode.FAILED_PRECONDITION,
                    f"Port set mismatch for node {node_id}: missing={missing} extras={extras}",
                )

            port_connections: List[opnet_types_pb2.OpNetConnection] = []
            link_cache: Dict[uuid.UUID, str] = {}

            for name in request_order:
                actual_port = actual_by_name[name]
                request_port = request_by_name[name]
                try:
                    expected_kind = opnet_types_pb2.OpNetPort.PortType.Name(request_port.port_type)
                except ValueError as exc:
                    raise OpNetError(
                        OpNetErrorCode.INVALID_ARGUMENT,
                        f"Unknown port_type value {request_port.port_type} for port {name}",
                    ) from exc

                if actual_port.kind != expected_kind:
                    raise OpNetError(
                        OpNetErrorCode.FAILED_PRECONDITION,
                        f"Port {name} kind mismatch: expected {actual_port.kind}, got {expected_kind}",
                    )

                expected_payload = request_port.payload_type.SerializeToString()
                if actual_port.payload_type != expected_payload:
                    raise OpNetError(
                        OpNetErrorCode.FAILED_PRECONDITION,
                        f"Port {name} payload_type mismatch.",
                    )

                if actual_port.link_id is None:
                    raise OpNetError(
                        OpNetErrorCode.FAILED_PRECONDITION,
                        f"Port {name} is not bound to a link.",
                    )

                link_id = actual_port.link_id
                link_ref = link_cache.get(link_id)
                if link_ref is None:
                    try:
                        result, maybe_ref = await self._plugin.async_getLink(link_id=str(link_id))
                    except OpNetError:
                        raise
                    except Exception as exc:
                        raise OpNetError(
                            OpNetErrorCode.INTERNAL,
                            f"plugin async_getLink failed for link {link_id}: {exc}",
                        ) from exc

                    if not result.ok or not maybe_ref:
                        raise OpNetError(
                            OpNetErrorCode.FAILED_PRECONDITION,
                            f"Link {link_id} unavailable: {result.message}",
                        )
                    link_ref = maybe_ref
                    link_cache[link_id] = link_ref

                port_connections.append(
                    opnet_types_pb2.OpNetConnection(
                        port_name=name,
                        link_ref=link_ref,
                        port_type=request_port.port_type,
                    )
                )

            await self._asyncActivateNodeAndPorts(session_maker=session_maker, node=node)

            logger.info(
                f"NodeCollection async_connect: success cluster={self._cluster_id} usecase={self._usecase} node_id={node_id} connections={len(port_connections)}"
            )
            return opnet_types_pb2.Result(ok=True), port_connections
        except OpNetError as exc:
            message = f"{exc.code.name}: {exc.message}"
            logger.info(
                f"NodeCollection async_connect: failure cluster={self._cluster_id} usecase={self._usecase} node_id={node_id} error={message}"
            )
            return opnet_types_pb2.Result(ok=False, message=message), None

    async def async_deactivatePorts(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        node_id: uuid.UUID,
        closure_reasons: Dict[str, str],
    ) -> Tuple[opnet_types_pb2.Result, Dict[str, opnet_types_pb2.Result]]:
        """Deactivate specific ports on a node, severing bindings and marking them inactive."""
        if closure_reasons is None:
            raise OpNetError(OpNetErrorCode.INVALID_ARGUMENT, "closure_reasons must be provided.")

        requested_names: List[str] = list(closure_reasons.keys())
        if len(requested_names) == 0:
            return opnet_types_pb2.Result(ok=False, message="No ports requested for deactivation."), {}

        node = self.getCachedNode(node_id)
        if node is None:
            node = await self.async_getNode(session_maker=session_maker, node_id=node_id)

        success_names: Set[str] = set()
        failure_reasons: Dict[str, str] = {}

        async def _portsByName(*, refresh: bool = False) -> Dict[str, OpNetPort]:
            if refresh:
                await node.async_refreshPorts()
            ports = await node.async_listPorts()
            mapping = {p.name: p for p in ports}
            if len(mapping) != len(ports):
                raise OpNetError(
                    OpNetErrorCode.INTERNAL,
                    f"Duplicate port names detected for node {node.id}",
                )
            return mapping

        async def _buildItems(*, refresh: bool = False) -> Tuple[List[_DeactivateItem], Dict[str, OpNetPort]]:
            mapping = await _portsByName(refresh=refresh)
            items: List[_DeactivateItem] = []
            for name in requested_names:
                port = mapping.get(name)
                if port is None:
                    failure_reasons.setdefault(name, "Port not found.")
                else:
                    items.append(_DeactivateItem(name=name, port_id=port.id))
            return items, mapping

        async def _persistChunk(chunk: Sequence[_DeactivateItem]) -> Set[uuid.UUID]:
            ids = [item.port_id for item in chunk]
            updated_ids: Set[uuid.UUID] = set()
            async with session_maker() as session:
                async with _transaction(session):
                    res = await session.execute(
                        update(TabPorts)
                        .where(TabPorts.id.in_(ids))
                        .values(activity_status="INACTIVE")
                        .returning(TabPorts.id)
                    )
                    updated_ids = {row[0] for row in res}
                    if updated_ids:
                        await session.execute(
                            delete(JoinPortLinkBindings).where(JoinPortLinkBindings.c.port_id.in_(updated_ids))
                        )
            for item in chunk:
                if item.port_id in updated_ids:
                    success_names.add(item.name)
                    failure_reasons.pop(item.name, None)
                else:
                    failure_reasons.setdefault(item.name, "Port not found while deactivating.")
            return updated_ids

        items, port_mapping = await _buildItems(refresh=False)
        fallback_needed = bool(failure_reasons)

        if items and not fallback_needed:
            try:
                await sqldb_utils.async_runWithSerializationRetries(
                    lambda: _persistChunk(items),
                    is_retryable=_isSerializationError,
                    sleep_fn=asyncio.sleep,
                )
            except IntegrityError:
                fallback_needed = True
            except DBAPIError as exc:
                if _isSerializationError(exc):
                    fallback_needed = True
                else:
                    message = f"{OpNetErrorCode.INTERNAL.name}: {exc}"
                    logger.info(
                        f"NodeCollection async_deactivatePorts: failure cluster={self._cluster_id} usecase={self._usecase} node_id={node_id} error={message}"
                    )
                    return opnet_types_pb2.Result(ok=False, message=message), {}

            if len(success_names) != len(items):
                fallback_needed = True

        if fallback_needed:
            success_names.clear()
            # Rebuild after refresh to reconcile concurrent mutations and then bisect on integrity errors.
            items, port_mapping = await _buildItems(refresh=True)
            if items:
                def _reason_fn(exc: IntegrityError) -> Optional[str]:
                    text = str(exc)
                    return text if text else None

                successes, failures = await sqldb_utils.async_partitionOnIntegrityErrors(
                    items,
                    _persistChunk,
                    reason_fn=_reason_fn,
                )
                for item in successes:
                    success_names.add(item.name)
                for item, reason in failures:
                    failure_reasons[item.name] = reason or "Constraint violation during deactivation."

        # Optionally mark node disconnected if nothing remains active after a successful deactivation.
        if success_names:
            async with session_maker() as session:
                async with _transaction(session):
                    active_count = (
                        await session.execute(
                            select(func.count())
                            .select_from(TabPorts)
                            .where(
                                (TabPorts.node_id == node.id)
                                & (TabPorts.activity_status == "ACTIVE")
                            )
                        )
                    ).scalar_one()
                    if active_count == 0:
                        await session.execute(
                            update(TabNodes)
                            .where(TabNodes.id == node.id)
                            .values(connection_status="DISCONNECTED")
                        )
                        node.connection_status = "DISCONNECTED"

        # Update cached ports to reflect that bindings were severed.
        for name in success_names:
            cached = port_mapping.get(name)
            if cached is not None:
                cached.link_id = None

        per_port_status: Dict[str, opnet_types_pb2.Result] = {}
        for name in requested_names:
            if name in success_names:
                per_port_status[name] = opnet_types_pb2.Result(ok=True)
            else:
                per_port_status[name] = opnet_types_pb2.Result(
                    ok=False,
                    message=failure_reasons.get(name, "Deactivation failed."),
                )

        overall_ok = all(r.ok for r in per_port_status.values())
        overall_message = ""
        if not overall_ok:
            first_failure = next((r.message for r in per_port_status.values() if not r.ok), None)
            overall_message = first_failure or "One or more ports failed to deactivate."

        logger.info(
            f"NodeCollection async_deactivatePorts: cluster={self._cluster_id} usecase={self._usecase} node_id={node_id} ok={overall_ok} successes={len(success_names)} failures={len(per_port_status) - len(success_names)}"
        )
        return opnet_types_pb2.Result(ok=overall_ok, message=overall_message), per_port_status

    async def async_deactivateAll(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        node_id: uuid.UUID,
        reason: Optional[str] = None,
    ) -> Tuple[opnet_types_pb2.Result, Dict[str, opnet_types_pb2.Result]]:
        node = self.getCachedNode(node_id)
        if node is None:
            node = await self.async_getNode(session_maker=session_maker, node_id=node_id)

        ports = await node.async_listPorts()
        closure_reasons = {p.name: (reason or "") for p in ports}
        return await self.async_deactivatePorts(
            session_maker=session_maker,
            node_id=node_id,
            closure_reasons=closure_reasons,
        )
