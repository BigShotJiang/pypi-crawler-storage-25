"""Loopback OpNet proxy that re-delivers published messages locally."""

from __future__ import annotations

import asyncio
from typing import Sequence, Tuple

from lumecode.lumeflow.runtime.v1.operator import operator_pb2
from lumecode.lumeflow.runtime.v1.opnet import opnet_types_pb2
from lumecode.lumeflow.runtime.v1.opnet.opnet_proxy import OpNetProxy
from lumecode.lumeflow.runtime.v1.opnet.opnet_types_pb2 import Result


class LoopbackOpNetProxy(OpNetProxy):
    """Caches publish requests and yields them back when queried."""

    def __init__(self) -> None:
        self._queue: asyncio.Queue[operator_pb2.DeliverRequest] = asyncio.Queue()
        self.published: list[operator_pb2.DeliverRequest] = []
        self.acknowledged: list[operator_pb2.AckRequest] = []

    async def async_setup(
        self,
        *,
        connections: Sequence[opnet_types_pb2.OpNetConnection],
    ) -> Result:
        del connections
        return Result(ok=True)

    async def async_putOpNetMessage(
        self, request: operator_pb2.DeliverRequest
    ) -> Result:
        cloned = operator_pb2.DeliverRequest()
        cloned.CopyFrom(request)
        await self._queue.put(cloned)
        self.published.append(cloned)
        return Result(ok=True)

    async def async_getOpNetMessage(self) -> Tuple[Result, operator_pb2.DeliverRequest]:
        delivery = await self._queue.get()
        return Result(ok=True), delivery

    async def async_ack(self, request: operator_pb2.AckRequest) -> Result:
        cloned = operator_pb2.AckRequest()
        cloned.CopyFrom(request)
        self.acknowledged.append(cloned)
        return Result(ok=True)

    async def async_reset(self, reset_id: str) -> Result:
        del reset_id
        return Result(ok=True)

    async def async_hasWork(self) -> bool:
        return not self._queue.empty()


__all__ = ["LoopbackOpNetProxy"]
