from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Optional, Tuple

from lumecode.lumeflow.runtime.v1.opnet.opnet_types_pb2 import Result, OpNetMessage


class OpNetControllerPlugin(ABC):
    @abstractmethod
    def getSubstrate(self) -> str:
        """Return the OpNet transport substrate identifier."""
        raise NotImplementedError

    @abstractmethod
    async def async_createLink(self, *, link_id: str) -> Tuple[Result, str]:
        """
        Provision (or ensure) a link with identifier `link_id` in the underlying pub/sub.

        Returns:
            (result, link_ref)
              - connection_string: opaque str the sidecar can pass to async_addProducer/Consumer
                             (stable across reconnects).
        Contract:
            - Idempotent: if the link already exists with identical settings, return ok=True
              and the same handle.
            - On incompatibility or unrecoverable errors, return ok=False with message.
            - The identifier link_id uniquely identifies the link in the underlying pub-sub framework.
        """
        raise NotImplementedError

    @abstractmethod
    async def async_getLink(self, *, link_id: str) -> Tuple[Result, Optional[str]]:
        """
        Look up an existing link. The lookup is expected to be algorithmic.

        Returns:
            (result, link_ref_or_none)
              - If ok=True, connection_string_or_none is the same handle as async_createLink would return.
              - If not found or error, ok=False and handle is None with a diagnostic message.
        """
        raise NotImplementedError

    @abstractmethod
    def getLinkIdFromLinkRef(self, *, link_ref: str) -> Tuple[Result, Optional[str]]:
        """
        Parse a controller-issued opaque link_ref into its logical link_id.

        Returns:
            (result, link_id_or_none)
              - If ok=True, link_id_or_none is non-empty.
              - If parsing fails, ok=False and link_id_or_none is None.
        """
        raise NotImplementedError

    @abstractmethod
    async def async_removeLink(self, *, link_ref: str) -> Result:
        """
        Remove link `link_ref`.

        Returns:
            Result(ok=...) — ok=True if removed or already absent.
        Contract:
            - Best-effort clean detach first if the backend supports it.
            - Idempotent.
        """
        raise NotImplementedError
    
    @abstractmethod
    async def async_getBacklog(self, *, link_ref: str) -> Tuple[Result, Optional[int]]:
        """
        Get backlog on link `link_ref`.

        Returns:
            Result(ok=...) — ok=True if link-backlog retrieved successfully, else false.
        Contract:
            - Idempotent.
        """
        raise NotImplementedError

    @abstractmethod
    async def async_injectMessageIntoLink(self, *, link_ref: str, opnet_message: OpNetMessage) -> Result:
        """
        Inject an OpNet message into an existing link.

        Returns:
            Result(ok=...) — ok=True when the message is accepted for delivery.
        """
        raise NotImplementedError


class OpNetNodePlugin(ABC):
    @abstractmethod
    def getSubstrate(self) -> str:
        """Return the OpNet transport substrate identifier."""
        raise NotImplementedError

    @abstractmethod
    async def async_addProducer(self, *, link_ref: str, port_name: str) -> Tuple[Result, str]:
        """
        Bind a producer named `port_name` to the publish endpoint described by
        `connection_string` (opaque handle from the controller).

        Returns:
            (result, producer_handle)
              - producer_handle: opaque str you can log/trace; stable for this binding.
        Contract:
            - Idempotent: same (port_name, connection_string) → same handle, ok=True.
        """
        raise NotImplementedError

    @abstractmethod
    async def async_addConsumer(
        self, *, link_ref: str, port_name: str, max_concurrency: int
    ) -> Tuple[Result, str]:
        """
        Bind a consumer named `port_name` to the receive endpoint with the specified
        in-flight window (`max_concurrency`).

        Returns:
            (result, consumer_handle)
        Contract:
            - Idempotent.
            - The plugin must not surface more than `max_concurrency` concurrently
              un-acked deliveries for this connection. Each ack/nack frees one credit.
            - Push-only backends may buffer internally but must respect the effective window.
        """
        raise NotImplementedError

    @abstractmethod
    async def async_putOpNetMessage(self, *, port_name: str, work_item: OpNetMessage) -> Result:
        """
        Publish a work item on the named producer connection.

        Returns:
            Result(ok=...) — ok=True on durable accept by the backend (per backend guarantees).
        Contract:
            - Retry transient errors internally as appropriate; return ok=False on definitive failure.
        """
        raise NotImplementedError

    @abstractmethod
    async def async_getOpNetMessage(self, *, port_name: str) -> Tuple[Result, Optional[str], Optional[OpNetMessage]]:
        """
        Receive one work item from the named consumer connection.

        Returns:
            (result, message_id, work_item)
              - On success: result.ok=True and both `message_id` and `work_item` are non-None.
              - On timeout/transient issues: result.ok=False with message; message_id/work_item=None.
        Contract:
            - May block until an item is available; must be cancel-safe (cancelling the task
              must not lose a delivery token or leak a lease).
            - `message_id` is the delivery token for this attempt (ackId/receipt-handle/tag/etc.);
              it may differ across redeliveries of the same logical message.
            - The item stays “in-flight” until acked/nacked or lease expires.
        """
        raise NotImplementedError

    @abstractmethod
    async def async_ack(self, *, port_name: str, message_id: str) -> Result:
        """
        Acknowledge successful processing of a previously delivered item.

        Returns:
            Result(ok=...) — ok=True if the ack was accepted (or already applied).
        Contract:
            - Idempotent: repeated acks of the same token are no-ops (ok=True).
            - Frees exactly one credit on the associated consumer connection.
        """
        raise NotImplementedError

    @abstractmethod
    async def async_nack(self, *, port_name: str, message_id: str) -> Result:
        """
        Negative-ack a previously delivered item (request redelivery).

        Returns:
            Result(ok=...) — ok=True if the nack/release was accepted (or already applied).
        Contract:
            - Idempotent.
            - Frees exactly one credit on the associated consumer connection.
            - For backends without an explicit nack, simulate by immediate lease/visibility
              release so the item is available for redelivery.
        """
        raise NotImplementedError

    @abstractmethod
    async def async_nackAll(self, port_name: str) -> Result:
        """
        Best-effort negative-ack of **all in-flight** items across all consumer connections.

        Returns:
            Result(ok=...) — ok=True if the request was issued; message may summarize counts.
        Intended use:
            - Shutdown (e.g., SIGTERM): proactively return leased items to the backend to
              avoid waiting for lease expiration.
        Contract:
            - Idempotent and fast; must not pull new items after this begins.
        """
        raise NotImplementedError
