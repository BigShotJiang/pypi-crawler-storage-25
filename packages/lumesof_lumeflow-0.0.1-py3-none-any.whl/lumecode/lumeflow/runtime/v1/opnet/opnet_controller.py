# lumecode/lumeflow/runtime/v1/opnet_controller.py

from __future__ import annotations

import asyncio
import contextlib
import logging
import threading
import uuid
from collections import deque
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional, Tuple, List, Set

from lumecode.base.python.logging import lumesof_logging
from sqlalchemy import delete, exists, func, insert, select, update
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker
from sqlalchemy.exc import DBAPIError, IntegrityError

from lumecode.base.python.sqldb import crdb_async_utils as sqldb_utils
from lumecode.lumeflow.runtime.v1.opnet.opnet_plugin_interface import OpNetControllerPlugin
from lumecode.lumeflow.runtime.v1.opnet.opnet_error import OpNetError, OpNetErrorCode
from lumecode.lumeflow.runtime.v1.opnet.opnet_link import OpNetLinkCollection
from lumecode.lumeflow.runtime.v1.opnet.opnet_node import OpNetNodeCollection
from lumecode.lumeflow.runtime.v1.opnet.opnet_types_pb2 import (
    OpNetCtlToNodeHeartbeat,
    OpNetNodeToCtlHeartbeat,
    OperatorStatus,
    Result,
)

from lumecode.crdb.schemas.dev_cluster.flow.db_orm_models import (
    TabControllers,
    TabHeartbeatResponseOverrides,
    TabNodeHeartbeats,
    TabNodes,
)

logger = logging.getLogger(__name__)
structuredLogger = lumesof_logging.getLogger(__name__)

_HEARTBEAT_BATCH_COUNT = "heartbeat.batch_count"
_HEARTBEAT_BATCH_SIZE = "heartbeat.batch_size"
_HEARTBEAT_FAILURE_COUNT = "heartbeat.failure_count"
_HEARTBEAT_HEARTBEAT_COUNT = "heartbeat.heartbeat_count"
_HEARTBEAT_NOT_CONNECTED_COUNT = "heartbeat.not_connected_count"
_HEARTBEAT_NOT_FOUND_COUNT = "heartbeat.not_found_count"
_HEARTBEAT_PERSISTED_COUNT = "heartbeat.persisted_count"
_HEARTBEAT_WINDOW_S = "heartbeat.window_s"
_HEARTBEAT_SUMMARY_INTERVAL_S = 60.0

_Key = Tuple[uuid.UUID, uuid.UUID]  # (cluster_id, controller_id)


@dataclass
class _HeartbeatSubmission:
    heartbeat: OpNetNodeToCtlHeartbeat
    node_id: uuid.UUID
    response_future: asyncio.Future[OpNetCtlToNodeHeartbeat]


@dataclass
class _HeartbeatPersistResult:
    success: bool
    reason: Optional[str] = None


@dataclass
class _HeartbeatPersistStats:
    persisted_count: int = 0
    failed_count: int = 0


@dataclass(frozen=True)
class OpNetNodeStatusSnapshot:
    status: int
    last_contact_ts: Optional[datetime]
    heartbeat_ts: Optional[datetime]
    has_heartbeat: bool
    message: str = ""


def _normalizeTimestamp(value: datetime) -> datetime:
    if value.tzinfo is None:
        return value
    return value.astimezone(timezone.utc).replace(tzinfo=None)


def _timestampToDatetime(value) -> datetime:
    seconds = float(value.seconds) + (float(value.nanos) / 1_000_000_000.0)
    return datetime.fromtimestamp(seconds, tz=timezone.utc).replace(tzinfo=None)


@contextlib.asynccontextmanager
async def _transaction(session: AsyncSession):
    async with sqldb_utils.async_transactionContext(existing_session=session) as tx_ctx:
        yield tx_ctx.session


class OpNetController:
    """Runtime holder for an OpNet controller."""

    def __init__(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        plugin: OpNetControllerPlugin,
        id: uuid.UUID,
        cluster: uuid.UUID,
        usecase: str,
        name: str,
    ) -> None:
        self._session_maker = session_maker
        self._plugin = plugin
        self._id = id
        self._cluster = cluster
        self._usecase = usecase
        self._name = name

    def getId(self) -> uuid.UUID:
        return self._id

    def getClusterId(self) -> uuid.UUID:
        return self._cluster

    def getUsecase(self) -> str:
        return self._usecase

    def getName(self) -> str:
        return self._name

    async def async_refresh(self) -> None:
        logger.info(
            f"OpNetController async_refresh begin id={self._id} "
            f"cluster={self._cluster} usecase={self._usecase}"
        )
        try:
            async with self._session_maker() as session:
                row = (
                    await session.execute(
                        select(
                            TabControllers.id,
                            TabControllers.name,
                            TabControllers.cluster_id,
                            TabControllers.usecase,
                        )
                        .where(
                            (TabControllers.id == self._id)
                            & (TabControllers.cluster_id == self._cluster)
                            & (TabControllers.usecase == self._usecase)
                        )
                    )
                ).one_or_none()
        except DBAPIError:
            logger.exception(
                f"OpNetController async_refresh db error id={self._id} "
                f"cluster={self._cluster} usecase={self._usecase}"
            )
            raise

        if row is None:
            logger.warning(
                f"OpNetController async_refresh not found id={self._id} "
                f"cluster={self._cluster} usecase={self._usecase}"
            )
            raise OpNetError(OpNetErrorCode.NOT_FOUND, "Controller not found in this collection.")

        _, name, clid, usecase = row
        self._name = name
        self._cluster = clid
        self._usecase = usecase
        logger.info(
            f"OpNetController async_refresh done id={self._id} "
            f"cluster={self._cluster} usecase={self._usecase} name={self._name}"
        )


class OpNetControllerCollection:
    """Collection view over controllers for a given (cluster_id, usecase)."""

    def __init__(
        self,
        *,
        cluster_id: uuid.UUID,
        usecase: str,
        plugin: OpNetControllerPlugin,
        node_session_maker: async_sessionmaker[AsyncSession],
        node_collection: Optional[OpNetNodeCollection] = None,
        link_collection: Optional[OpNetLinkCollection] = None,
        heartbeat_batching_interval_s: float = 5.0,
    ) -> None:
        self._cluster_id = cluster_id
        self._usecase = usecase
        self._plugin = plugin
        self._heartbeat_batching_interval_s = heartbeat_batching_interval_s
        if self._heartbeat_batching_interval_s <= 0:
            logger.warning(
                f"OpNetControllerCollection invalid heartbeat interval "
                f"cluster={cluster_id} usecase={usecase} "
                f"interval_s={heartbeat_batching_interval_s}"
            )
            raise ValueError("heartbeat_batching_interval_s must be positive.")

        self._instances: Dict[_Key, OpNetController] = {}
        self._locks: Dict[_Key, asyncio.Lock] = {}
        self._dict_lock = threading.Lock()

        try:
            self._loop = asyncio.get_running_loop()
        except RuntimeError as exc:  # pragma: no cover - defensive: construction must be in event loop
            logger.error(
                f"OpNetControllerCollection constructed without running loop "
                f"cluster={cluster_id} usecase={usecase}"
            )
            raise RuntimeError(
                "OpNetControllerCollection must be constructed within a running asyncio event loop."
            ) from exc

        if node_session_maker is None:
            logger.warning(
                f"OpNetControllerCollection missing node_session_maker "
                f"cluster={cluster_id} usecase={usecase}"
            )
            raise ValueError("node_session_maker must be provided.")

        self._node_collection = node_collection or OpNetNodeCollection(
            cluster_id=cluster_id,
            usecase=usecase,
            plugin=plugin,
        )
        self._link_collection = link_collection or OpNetLinkCollection(
            cluster_id=cluster_id,
            usecase=usecase,
            plugin=plugin,
        )
        self._node_session_maker = node_session_maker
        self._heartbeat_lock = asyncio.Lock()
        self._pending_heartbeats: List[_HeartbeatSubmission] = []
        self._heartbeat_summary_interval_s = _HEARTBEAT_SUMMARY_INTERVAL_S
        self._resetHeartbeatSummaryWindow(start_time=self._loop.time())
        self._heartbeat_task = self._loop.create_task(
            self._async_heartbeatProcessorLoop(),
            name=f"opnet-heartbeat-processor-{cluster_id}-{usecase}",
        )
        logger.info(
            f"OpNetControllerCollection initialized cluster={cluster_id} "
            f"usecase={usecase} heartbeat_interval_s={heartbeat_batching_interval_s}"
        )

    # ---- helpers ----
    def getNodeCollection(self) -> OpNetNodeCollection:
        """Return the node collection associated with this controller collection."""
        return self._node_collection

    def getLinkCollection(self) -> OpNetLinkCollection:
        """Return the link collection associated with this controller collection."""
        return self._link_collection

    def getSubstrate(self) -> str:
        """Return the transport substrate from the configured OpNet plugin."""
        return self._plugin.getSubstrate()

    def _getKey(self, controller_id: uuid.UUID) -> _Key:
        return (self._cluster_id, controller_id)

    def _getOrCreateLock(self, key: _Key) -> asyncio.Lock:
        with self._dict_lock:
            lock = self._locks.get(key)
            if lock is None:
                lock = asyncio.Lock()
                self._locks[key] = lock
        return lock

    def _cachePut(self, inst: OpNetController) -> None:
        key = self._getKey(inst.getId())
        with self._dict_lock:
            existed = key in self._instances
            self._instances[key] = inst
        logger.debug(
            f"cachePut: {'replaced' if existed else 'inserted'} controller key={key}"
        )

    def _heartbeatBaseAttrs(self) -> dict[str, Any]:
        return {
            lumesof_logging.LUMESOF_CLUSTER_ID: str(self._cluster_id),
            lumesof_logging.LUMESOF_USECASE: self._usecase,
        }

    def _heartbeatAttrs(self, **attrs: Any) -> dict[str, Any]:
        mergedAttrs = self._heartbeatBaseAttrs()
        mergedAttrs.update(attrs)
        return mergedAttrs

    def _resetHeartbeatSummaryWindow(self, *, start_time: float) -> None:
        self._heartbeat_summary_started_at = start_time
        self._heartbeat_summary_batch_count = 0
        self._heartbeat_summary_heartbeat_count = 0
        self._heartbeat_summary_persisted_count = 0
        self._heartbeat_summary_not_connected_count = 0
        self._heartbeat_summary_not_found_count = 0
        self._heartbeat_summary_failure_count = 0

    def _recordHeartbeatSummaryWindow(
        self,
        *,
        batch_size: int,
        persisted_count: int,
        not_connected_count: int,
        not_found_count: int,
        failure_count: int,
    ) -> None:
        self._heartbeat_summary_batch_count += 1
        self._heartbeat_summary_heartbeat_count += batch_size
        self._heartbeat_summary_persisted_count += persisted_count
        self._heartbeat_summary_not_connected_count += not_connected_count
        self._heartbeat_summary_not_found_count += not_found_count
        self._heartbeat_summary_failure_count += failure_count

    def _logHeartbeatSummaryIfNeeded(self, *, force: bool = False) -> None:
        now = self._loop.time()
        elapsedSeconds = now - self._heartbeat_summary_started_at
        if not force and elapsedSeconds < self._heartbeat_summary_interval_s:
            return
        if self._heartbeat_summary_batch_count == 0:
            self._resetHeartbeatSummaryWindow(start_time=now)
            return
        structuredLogger.info(
            "Heartbeat processor summary",
            event="lumeflow.opnet.heartbeat.summary",
            attrs=self._heartbeatAttrs(
                **{
                    lumesof_logging.EVENT_OUTCOME: (
                        "success" if self._heartbeat_summary_failure_count == 0 else "partial"
                    ),
                    _HEARTBEAT_WINDOW_S: max(1, int(round(elapsedSeconds))),
                    _HEARTBEAT_BATCH_COUNT: self._heartbeat_summary_batch_count,
                    _HEARTBEAT_HEARTBEAT_COUNT: self._heartbeat_summary_heartbeat_count,
                    _HEARTBEAT_PERSISTED_COUNT: self._heartbeat_summary_persisted_count,
                    _HEARTBEAT_NOT_CONNECTED_COUNT: self._heartbeat_summary_not_connected_count,
                    _HEARTBEAT_NOT_FOUND_COUNT: self._heartbeat_summary_not_found_count,
                    _HEARTBEAT_FAILURE_COUNT: self._heartbeat_summary_failure_count,
                }
            ),
        )
        self._resetHeartbeatSummaryWindow(start_time=now)

    def _cacheGet(self, controller_id: uuid.UUID) -> Optional[OpNetController]:
        key = self._getKey(controller_id)
        with self._dict_lock:
            inst = self._instances.get(key)
        logger.debug(f"cacheGet: {'hit' if inst is not None else 'miss'} controller key={key}")
        return inst

    def _cacheBulkPut(self, items: Dict[_Key, OpNetController]) -> None:
        with self._dict_lock:
            self._instances.update(items)
        logger.info(
            f"cacheBulkPut: upserted {len(items)} controllers (cluster={self._cluster_id} usecase={self._usecase})"
        )

    # ---- API: load all controllers ----
    async def async_loadAllControllers(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
    ) -> None:
        logger.info(
            f"async_loadAllControllers: begin cluster={self._cluster_id} usecase={self._usecase}"
        )
        async with session_maker() as session:
            stmt = (
                select(
                    TabControllers.id,
                    TabControllers.name,
                    TabControllers.cluster_id,
                    TabControllers.usecase,
                )
                .where(
                    (TabControllers.cluster_id == self._cluster_id)
                    & (TabControllers.usecase == self._usecase)
                )
            )
            rows = (await session.execute(stmt)).all()

        new_items: Dict[_Key, OpNetController] = {}
        for (cid, name, clid, usecase) in rows:
            new_items[self._getKey(cid)] = OpNetController(
                session_maker=session_maker,
                plugin=self._plugin,
                id=cid,
                cluster=clid,
                usecase=usecase,
                name=name,
            )

        if new_items:
            self._cacheBulkPut(new_items)

        logger.info(
            f"async_loadAllControllers: done cluster={self._cluster_id} usecase={self._usecase} cached={len(new_items)}"
        )

    # ---- API: refresh subset ----
    async def async_refreshControllers(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        controller_ids: Optional[List[uuid.UUID]] = None,
    ) -> None:
        ids = controller_ids

        if ids is None:
            logger.info(
                f"async_refreshControllers: full refresh requested "
                f"cluster={self._cluster_id} usecase={self._usecase}"
            )
            await self.async_loadAllControllers(session_maker=session_maker)
            return

        if len(ids) == 0:
            logger.debug(
                f"async_refreshControllers: no ids cluster={self._cluster_id} usecase={self._usecase}"
            )
            return

        logger.info(
            f"async_refreshControllers: begin cluster={self._cluster_id} usecase={self._usecase} count={len(ids)}"
        )

        async with session_maker() as session:
            stmt = (
                select(
                    TabControllers.id,
                    TabControllers.name,
                    TabControllers.cluster_id,
                    TabControllers.usecase,
                )
                .where(
                    (TabControllers.cluster_id == self._cluster_id)
                    & (TabControllers.usecase == self._usecase)
                    & (TabControllers.id.in_(ids))
                )
            )
            rows = (await session.execute(stmt)).all()

        updated: Dict[_Key, OpNetController] = {}
        found_keys: Set[_Key] = set()
        for (cid, name, clid, usecase) in rows:
            key = self._getKey(cid)
            found_keys.add(key)
            updated[key] = OpNetController(
                session_maker=session_maker,
                plugin=self._plugin,
                id=cid,
                cluster=clid,
                usecase=usecase,
                name=name,
            )

        if updated:
            self._cacheBulkPut(updated)

        requested_keys = {self._getKey(cid) for cid in ids}
        missing_keys = requested_keys - found_keys
        if missing_keys:
            with self._dict_lock:
                for key in missing_keys:
                    self._instances.pop(key, None)
            logger.info(
                f"async_refreshControllers: removed {len(missing_keys)} controllers no longer present in DB"
            )

        logger.info(
            f"async_refreshControllers: done cluster={self._cluster_id} usecase={self._usecase}"
        )

    # ---- API: create ----
    async def async_createController(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        name: str,
    ) -> OpNetController:
        logger.info(
            f"async_createController: begin cluster={self._cluster_id} usecase={self._usecase} name={name}"
        )

        async with session_maker() as session:
            try:
                async with _transaction(session) as tx_session:
                    ins = (
                        insert(TabControllers)
                        .values(
                            cluster_id=self._cluster_id,
                            usecase=self._usecase,
                            name=name,
                        )
                        .returning(
                            TabControllers.id,
                            TabControllers.name,
                            TabControllers.cluster_id,
                            TabControllers.usecase,
                        )
                    )
                    res = await tx_session.execute(ins)
                    row = res.one()
            except IntegrityError as e:
                existing = (
                    await session.execute(
                        select(
                            TabControllers.id,
                            TabControllers.name,
                            TabControllers.cluster_id,
                            TabControllers.usecase,
                        )
                        .where(
                            (TabControllers.cluster_id == self._cluster_id)
                            & (TabControllers.name == name)
                        )
                    )
                ).one_or_none()

                if existing is None:
                    logger.error("async_createController: integrity error with no matching row")
                    raise OpNetError(
                        OpNetErrorCode.FAILED_PRECONDITION,
                        "Controller could not be created due to conflicting state.",
                    ) from e

                cid, db_name, clid, usecase = existing
                if usecase != self._usecase:
                    logger.warning(
                        f"async_createController: name conflict across usecases cluster={self._cluster_id} name={name} existing_usecase={usecase}"
                    )
                    raise OpNetError(
                        OpNetErrorCode.FAILED_PRECONDITION,
                        "Controller name already exists with different usecase.",
                    ) from e

                logger.warning(
                    f"async_createController: name conflict cluster={self._cluster_id} usecase={self._usecase} name={name} existing_id={cid}"
                )
                raise OpNetError(
                    OpNetErrorCode.ALREADY_EXISTS,
                    f"Controller with name={name!r} already exists in cluster.",
                ) from e

        cid, db_name, clid, usecase = row
        inst = OpNetController(
            session_maker=session_maker,
            plugin=self._plugin,
            id=cid,
            cluster=clid,
            usecase=usecase,
            name=db_name,
        )
        self._cachePut(inst)
        logger.info(
            f"async_createController: done cluster={self._cluster_id} "
            f"usecase={self._usecase} name={db_name} id={cid}"
        )
        return inst

    # ---- API: delete ----
    async def async_stopController(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        controller_id: uuid.UUID,
    ) -> None:
        key = self._getKey(controller_id)
        logger.info(
            f"async_stopController: begin cluster={self._cluster_id} usecase={self._usecase} id={controller_id}"
        )
        lock = self._getOrCreateLock(key)

        async with lock:
            async with session_maker() as session:
                async with _transaction(session) as tx_session:
                    res = await tx_session.execute(
                        delete(TabControllers)
                        .where(
                            (TabControllers.id == controller_id)
                            & (TabControllers.cluster_id == self._cluster_id)
                            & (TabControllers.usecase == self._usecase)
                        )
                        .returning(TabControllers.id)
                    )
                    row = res.one_or_none()
                    if row is None:
                        logger.warning(
                            f"async_stopController: controller not found cluster={self._cluster_id} usecase={self._usecase} id={controller_id}"
                        )
                        raise OpNetError(
                            OpNetErrorCode.NOT_FOUND, "Controller not found in this collection."
                        )

            with self._dict_lock:
                removed = self._instances.pop(key, None)

        logger.info(
            f"async_stopController: deleted controller id={controller_id} cache_removed={removed is not None}"
        )

    # ---- API: get ----
    async def async_getController(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        controller_id: uuid.UUID,
    ) -> OpNetController:
        inst = self._cacheGet(controller_id)
        if inst is not None:
            if inst.getUsecase() != self._usecase or inst.getClusterId() != self._cluster_id:
                logger.error(
                    f"async_getController: cached instance mismatch key={self._getKey(controller_id)}"
                )
                raise OpNetError(OpNetErrorCode.INTERNAL, "Cached instance collection mismatch.")
            logger.debug(
                f"async_getController: cache hit cluster={self._cluster_id} "
                f"usecase={self._usecase} id={controller_id}"
            )
            return inst

        async with session_maker() as session:
            row = (
                await session.execute(
                    select(
                        TabControllers.id,
                        TabControllers.name,
                        TabControllers.cluster_id,
                        TabControllers.usecase,
                    )
                    .where(
                        (TabControllers.id == controller_id)
                        & (TabControllers.cluster_id == self._cluster_id)
                        & (TabControllers.usecase == self._usecase)
                    )
                )
            ).one_or_none()

        if row is None:
            logger.warning(
                f"async_getController: controller not found cluster={self._cluster_id} usecase={self._usecase} id={controller_id}"
            )
            raise OpNetError(OpNetErrorCode.NOT_FOUND, "Controller not found in this collection.")

        cid, name, clid, usecase = row
        inst = OpNetController(
            session_maker=session_maker,
            plugin=self._plugin,
            id=cid,
            cluster=clid,
            usecase=usecase,
            name=name,
        )
        self._cachePut(inst)
        logger.info(
            f"async_getController: loaded from db cluster={self._cluster_id} "
            f"usecase={self._usecase} id={controller_id}"
        )
        return inst

    async def async_setHeartbeatResp(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        entries: List[Tuple[uuid.UUID, OpNetCtlToNodeHeartbeat]],
    ) -> None:
        if not entries:
            logger.warning(
                f"async_setHeartbeatResp: empty entries cluster={self._cluster_id} usecase={self._usecase}"
            )
            raise OpNetError(OpNetErrorCode.INVALID_ARGUMENT, "entries must include at least one item.")

        node_ids = [node_id for node_id, _ in entries]
        if len(set(node_ids)) != len(node_ids):
            logger.warning(
                f"async_setHeartbeatResp: duplicate node ids cluster={self._cluster_id} "
                f"usecase={self._usecase} count={len(node_ids)}"
            )
            raise OpNetError(OpNetErrorCode.INVALID_ARGUMENT, "entries must not contain duplicate node_id values.")
        logger.info(
            f"async_setHeartbeatResp: begin cluster={self._cluster_id} "
            f"usecase={self._usecase} node_count={len(entries)}"
        )

        async with session_maker() as session:
            async with _transaction(session) as tx_session:
                await self._async_assertManagedNodesExist(session=tx_session, node_ids=node_ids)
                now = datetime.utcnow()
                for node_id, resp in entries:
                    payload = resp.SerializeToString()
                    update_result = await tx_session.execute(
                        update(TabHeartbeatResponseOverrides)
                        .where(TabHeartbeatResponseOverrides.node_id == node_id)
                        .values(
                            ts=now,
                            resp_override=payload,
                            num_deliveries=0,
                        )
                    )
                    if update_result.rowcount and update_result.rowcount > 0:
                        continue
                    try:
                        await tx_session.execute(
                            insert(TabHeartbeatResponseOverrides).values(
                                node_id=node_id,
                                ts=now,
                                resp_override=payload,
                                num_deliveries=0,
                            )
                        )
                    except IntegrityError:
                        # A concurrent write inserted the row; overwrite still resets delivery count.
                        logger.debug(
                            f"async_setHeartbeatResp: concurrent insert raced node_id={node_id} "
                            f"cluster={self._cluster_id} usecase={self._usecase}"
                        )
                        await tx_session.execute(
                            update(TabHeartbeatResponseOverrides)
                            .where(TabHeartbeatResponseOverrides.node_id == node_id)
                            .values(
                                ts=now,
                                resp_override=payload,
                                num_deliveries=0,
                            )
                        )
        logger.info(
            f"async_setHeartbeatResp: done cluster={self._cluster_id} "
            f"usecase={self._usecase} node_count={len(entries)}"
        )

    async def async_getNumHeartbeatDeliveries(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        node_ids: List[uuid.UUID],
    ) -> Dict[uuid.UUID, int]:
        if not node_ids:
            logger.warning(
                f"async_getNumHeartbeatDeliveries: empty node ids "
                f"cluster={self._cluster_id} usecase={self._usecase}"
            )
            raise OpNetError(OpNetErrorCode.INVALID_ARGUMENT, "node_ids must include at least one item.")
        if len(set(node_ids)) != len(node_ids):
            logger.warning(
                f"async_getNumHeartbeatDeliveries: duplicate node ids "
                f"cluster={self._cluster_id} usecase={self._usecase} count={len(node_ids)}"
            )
            raise OpNetError(
                OpNetErrorCode.INVALID_ARGUMENT,
                "node_ids must not contain duplicate values.",
            )
        logger.info(
            f"async_getNumHeartbeatDeliveries: begin cluster={self._cluster_id} "
            f"usecase={self._usecase} node_count={len(node_ids)}"
        )

        async with session_maker() as session:
            await self._async_assertManagedNodesExist(session=session, node_ids=node_ids)
            rows = await session.execute(
                select(
                    TabHeartbeatResponseOverrides.node_id,
                    TabHeartbeatResponseOverrides.num_deliveries,
                ).where(TabHeartbeatResponseOverrides.node_id.in_(node_ids))
            )
            counts = {row_node_id: row_num_deliveries for row_node_id, row_num_deliveries in rows.all()}

        missing_override_ids = [node_id for node_id in node_ids if node_id not in counts]
        if missing_override_ids:
            logger.warning(
                f"async_getNumHeartbeatDeliveries: override missing "
                f"cluster={self._cluster_id} usecase={self._usecase} "
                f"node_id={missing_override_ids[0]}"
            )
            raise OpNetError(
                OpNetErrorCode.NOT_FOUND,
                f"Heartbeat override not found for node_id={missing_override_ids[0]}",
            )
        result = {node_id: counts[node_id] for node_id in node_ids}
        logger.info(
            f"async_getNumHeartbeatDeliveries: done cluster={self._cluster_id} "
            f"usecase={self._usecase} node_count={len(result)}"
        )
        return result

    async def async_getHeartbeatCount(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        node_ids: List[uuid.UUID],
        since_unix_millis: int = 0,
    ) -> Dict[uuid.UUID, int]:
        logger.info(
            f"async_getHeartbeatCount: begin cluster={self._cluster_id} "
            f"usecase={self._usecase} node_count={len(node_ids)} "
            f"since_unix_millis={since_unix_millis}"
        )
        if not node_ids:
            logger.warning(
                f"async_getHeartbeatCount: empty node ids "
                f"cluster={self._cluster_id} usecase={self._usecase}"
            )
            raise OpNetError(OpNetErrorCode.INVALID_ARGUMENT, "node_ids must include at least one item.")
        if len(set(node_ids)) != len(node_ids):
            logger.warning(
                f"async_getHeartbeatCount: duplicate node ids "
                f"cluster={self._cluster_id} usecase={self._usecase} count={len(node_ids)}"
            )
            raise OpNetError(
                OpNetErrorCode.INVALID_ARGUMENT,
                "node_ids must not contain duplicate values.",
            )
        if since_unix_millis < 0:
            logger.warning(
                f"async_getHeartbeatCount: negative since_unix_millis "
                f"cluster={self._cluster_id} usecase={self._usecase} "
                f"since_unix_millis={since_unix_millis}"
            )
            raise OpNetError(
                OpNetErrorCode.INVALID_ARGUMENT,
                "since_unix_millis must be >= 0.",
            )

        since_dt = datetime.utcfromtimestamp(since_unix_millis / 1000.0)
        async with session_maker() as session:
            await self._async_assertManagedNodesExist(session=session, node_ids=node_ids)
            rows = await session.execute(
                select(
                    TabNodeHeartbeats.node_id,
                    func.count(),
                )
                .where(
                    (TabNodeHeartbeats.node_id.in_(node_ids))
                    & (TabNodeHeartbeats.ts >= since_dt)
                )
                .group_by(TabNodeHeartbeats.node_id)
            )
            counts_by_node = {row_node_id: row_count for row_node_id, row_count in rows.all()}
        result = {node_id: int(counts_by_node.get(node_id, 0)) for node_id in node_ids}
        logger.info(
            f"async_getHeartbeatCount: done cluster={self._cluster_id} "
            f"usecase={self._usecase} node_count={len(result)}"
        )
        return result

    async def async_getNodesWithoutHeartbeats(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        since_unix_millis: Optional[int] = None,
    ) -> List[uuid.UUID]:
        logger.info(
            f"async_getNodesWithoutHeartbeats: begin cluster={self._cluster_id} "
            f"usecase={self._usecase} since_unix_millis={since_unix_millis}"
        )
        if since_unix_millis is not None and since_unix_millis < 0:
            logger.warning(
                f"async_getNodesWithoutHeartbeats: negative since_unix_millis "
                f"cluster={self._cluster_id} usecase={self._usecase} "
                f"since_unix_millis={since_unix_millis}"
            )
            raise OpNetError(
                OpNetErrorCode.INVALID_ARGUMENT,
                "since_unix_millis must be >= 0.",
            )
        if since_unix_millis is None:
            since_dt = datetime.utcnow() - timedelta(minutes=10)
        else:
            since_dt = datetime.utcfromtimestamp(since_unix_millis / 1000.0)

        heartbeat_exists = exists(
            select(TabNodeHeartbeats.node_id).where(
                (TabNodeHeartbeats.node_id == TabNodes.id)
                & (TabNodeHeartbeats.ts >= since_dt)
            )
        )
        async with session_maker() as session:
            rows = await session.execute(
                select(TabNodes.id)
                .join(TabControllers, TabNodes.controller_id == TabControllers.id)
                .where(
                    (TabControllers.cluster_id == self._cluster_id)
                    & (TabControllers.usecase == self._usecase)
                    & (~heartbeat_exists)
                )
                .order_by(TabNodes.id.asc())
            )
        node_ids = [node_id for (node_id,) in rows.all()]
        logger.info(
            f"async_getNodesWithoutHeartbeats: done cluster={self._cluster_id} "
            f"usecase={self._usecase} node_count={len(node_ids)}"
        )
        return node_ids

    async def async_getNodeStatuses(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        node_ids: List[uuid.UUID],
        min_heartbeat_unix_millis: int = 0,
    ) -> Dict[uuid.UUID, OpNetNodeStatusSnapshot]:
        logger.info(
            f"async_getNodeStatuses: begin cluster={self._cluster_id} "
            f"usecase={self._usecase} node_count={len(node_ids)} "
            f"min_heartbeat_unix_millis={min_heartbeat_unix_millis}"
        )
        if not node_ids:
            logger.warning(
                f"async_getNodeStatuses: empty node ids "
                f"cluster={self._cluster_id} usecase={self._usecase}"
            )
            raise OpNetError(OpNetErrorCode.INVALID_ARGUMENT, "node_ids must include at least one entry.")
        if len(set(node_ids)) != len(node_ids):
            logger.warning(
                f"async_getNodeStatuses: duplicate node ids "
                f"cluster={self._cluster_id} usecase={self._usecase} count={len(node_ids)}"
            )
            raise OpNetError(
                OpNetErrorCode.INVALID_ARGUMENT,
                "node_ids must not contain duplicate values.",
            )
        if min_heartbeat_unix_millis < 0:
            logger.warning(
                f"async_getNodeStatuses: negative min_heartbeat_unix_millis "
                f"cluster={self._cluster_id} usecase={self._usecase} "
                f"value={min_heartbeat_unix_millis}"
            )
            raise OpNetError(
                OpNetErrorCode.INVALID_ARGUMENT,
                "min_heartbeat_unix_millis must be >= 0.",
            )

        min_ts: Optional[datetime] = None
        if min_heartbeat_unix_millis > 0:
            min_ts = datetime.fromtimestamp(
                min_heartbeat_unix_millis / 1000.0,
                tz=timezone.utc,
            ).replace(tzinfo=None)

        async with session_maker() as session:
            try:
                rows = (
                    await session.execute(
                        select(
                            TabNodeHeartbeats.node_id,
                            TabNodeHeartbeats.ts,
                            TabNodeHeartbeats.heartbeat,
                        )
                        .where(TabNodeHeartbeats.node_id.in_(node_ids))
                        .order_by(
                            TabNodeHeartbeats.node_id.asc(),
                            TabNodeHeartbeats.ts.desc(),
                        )
                    )
                ).all()
            except DBAPIError as exc:
                logger.warning(
                    f"async_getNodeStatuses: db error cluster={self._cluster_id} usecase={self._usecase}",
                    exc_info=True,
                )
                raise OpNetError(OpNetErrorCode.INTERNAL, "Database error while reading heartbeats.") from exc

        latest_by_node: Dict[uuid.UUID, tuple[datetime, bytes]] = {}
        for node_id, ts, heartbeat_bytes in rows:
            if node_id in latest_by_node:
                continue
            latest_by_node[node_id] = (_normalizeTimestamp(ts), heartbeat_bytes)

        snapshots: Dict[uuid.UUID, OpNetNodeStatusSnapshot] = {}
        default_status = OperatorStatus.OPERATOR_STATUS_UNSPECIFIED
        for node_id in node_ids:
            record = latest_by_node.get(node_id)
            if record is None:
                snapshots[node_id] = OpNetNodeStatusSnapshot(
                    status=default_status,
                    last_contact_ts=None,
                    heartbeat_ts=None,
                    has_heartbeat=False,
                )
                continue
            heartbeat_ts, heartbeat_bytes = record
            if min_ts is not None and heartbeat_ts < min_ts:
                snapshots[node_id] = OpNetNodeStatusSnapshot(
                    status=default_status,
                    last_contact_ts=None,
                    heartbeat_ts=heartbeat_ts,
                    has_heartbeat=False,
                    message="latest heartbeat is older than min_heartbeat_unix_millis",
                )
                continue

            heartbeat = OpNetNodeToCtlHeartbeat()
            try:
                heartbeat.ParseFromString(heartbeat_bytes)
            except Exception:
                logger.warning(
                    f"async_getNodeStatuses: failed to parse heartbeat "
                    f"cluster={self._cluster_id} usecase={self._usecase} node_id={node_id}",
                    exc_info=True,
                )
                snapshots[node_id] = OpNetNodeStatusSnapshot(
                    status=default_status,
                    last_contact_ts=None,
                    heartbeat_ts=heartbeat_ts,
                    has_heartbeat=True,
                    message="failed to parse heartbeat payload",
                )
                continue

            last_contact_ts = None
            if heartbeat.HasField("last_contact_ts"):
                last_contact_ts = _timestampToDatetime(heartbeat.last_contact_ts)
            snapshots[node_id] = OpNetNodeStatusSnapshot(
                status=int(heartbeat.operator_status),
                last_contact_ts=last_contact_ts,
                heartbeat_ts=heartbeat_ts,
                has_heartbeat=True,
                message=heartbeat.operator_status_message or "",
            )

        logger.info(
            f"async_getNodeStatuses: done cluster={self._cluster_id} "
            f"usecase={self._usecase} node_count={len(snapshots)}"
        )
        return snapshots

    async def _async_assertManagedNodesExist(
        self,
        *,
        session: AsyncSession,
        node_ids: List[uuid.UUID],
    ) -> None:
        rows = await session.execute(
            select(TabNodes.id)
            .join(TabControllers, TabNodes.controller_id == TabControllers.id)
            .where(
                (TabNodes.id.in_(node_ids))
                & (TabControllers.cluster_id == self._cluster_id)
                & (TabControllers.usecase == self._usecase)
            )
        )
        existing_ids = {row_node_id for (row_node_id,) in rows}
        missing_ids = [node_id for node_id in node_ids if node_id not in existing_ids]
        if missing_ids:
            logger.warning(
                f"_async_assertManagedNodesExist missing node_id={missing_ids[0]} "
                f"cluster={self._cluster_id} usecase={self._usecase}"
            )
            raise OpNetError(
                OpNetErrorCode.NOT_FOUND,
                f"Node not found in this collection: node_id={missing_ids[0]}",
            )

    # ---- API: heartbeats ----
    async def async_captureHeartbeat(
        self,
        *,
        node_id: uuid.UUID,
        heartbeat: OpNetNodeToCtlHeartbeat,
    ) -> OpNetCtlToNodeHeartbeat:
        loop = asyncio.get_running_loop()
        response_future: asyncio.Future[OpNetCtlToNodeHeartbeat] = loop.create_future()
        submission = _HeartbeatSubmission(
            heartbeat=heartbeat,
            node_id=node_id,
            response_future=response_future,
        )

        async with self._heartbeat_lock:
            self._pending_heartbeats.append(submission)

        try:
            return await response_future
        except asyncio.CancelledError:
            logger.warning(f"async_captureHeartbeat: cancelled node_id={node_id}")
            if not response_future.done():
                response_future.cancel()
            raise

    async def async_close(self) -> None:
        logger.info(
            f"async_close: begin cluster={self._cluster_id} usecase={self._usecase}"
        )
        task = getattr(self, "_heartbeat_task", None)
        if task is None:
            logger.info(
                f"async_close: no heartbeat task cluster={self._cluster_id} usecase={self._usecase}"
            )
            return
        if task.done():
            self._heartbeat_task = None
            logger.info(
                f"async_close: heartbeat task already complete "
                f"cluster={self._cluster_id} usecase={self._usecase}"
            )
            return
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task
        self._heartbeat_task = None
        logger.info(
            f"async_close: done cluster={self._cluster_id} usecase={self._usecase}"
        )

    async def _async_drainPendingHeartbeats(self) -> List[_HeartbeatSubmission]:
        async with self._heartbeat_lock:
            if not self._pending_heartbeats:
                return []
            batch = self._pending_heartbeats
            self._pending_heartbeats = []
        structuredLogger.debug(
            "Heartbeat batch drained",
            event="lumeflow.opnet.heartbeat_batch.drained",
            attrs=self._heartbeatAttrs(
                **{
                    lumesof_logging.EVENT_OUTCOME: "success",
                    _HEARTBEAT_BATCH_SIZE: len(batch),
                }
            ),
        )
        return batch

    def _setHeartbeatResult(
        self,
        submission: _HeartbeatSubmission,
        *,
        ok: bool,
        message: str = "",
    ) -> None:
        future = submission.response_future
        if future.done():
            return
        future.set_result(OpNetCtlToNodeHeartbeat(result=Result(ok=ok, message=message)))

    def _setHeartbeatOverride(
        self,
        submission: _HeartbeatSubmission,
        override_proto: OpNetCtlToNodeHeartbeat,
    ) -> None:
        future = submission.response_future
        if future.done():
            return
        response = OpNetCtlToNodeHeartbeat()
        response.CopyFrom(override_proto)
        future.set_result(response)

    def _rejectHeartbeatBatch(self, batch: List[_HeartbeatSubmission], exc: Exception) -> None:
        structuredLogger.warning(
            "Heartbeat batch rejected",
            event="lumeflow.opnet.heartbeat_batch.failed",
            attrs=self._heartbeatAttrs(
                **{
                    lumesof_logging.EVENT_OUTCOME: "failure",
                    lumesof_logging.EXCEPTION: type(exc).__name__,
                    _HEARTBEAT_BATCH_SIZE: len(batch),
                    _HEARTBEAT_FAILURE_COUNT: len(batch),
                }
            ),
        )
        for submission in batch:
            future = submission.response_future
            if future.done():
                continue
            future.set_exception(exc)

    async def _async_processHeartbeatBatch(self, batch: List[_HeartbeatSubmission]) -> None:
        if not batch:
            return

        pending_by_node: Dict[uuid.UUID, List[_HeartbeatSubmission]] = {}
        ready_for_persistence: List[_HeartbeatSubmission] = []
        not_connected_msg = "Node is not connected."
        not_found_count = 0
        not_connected_count = 0

        for submission in batch:
            node = self._node_collection.getCachedNode(submission.node_id)
            if node is None or node.connection_status != "CONNECTED":
                pending_by_node.setdefault(submission.node_id, []).append(submission)
            else:
                ready_for_persistence.append(submission)

        if pending_by_node:
            await self._node_collection.async_refreshNodes(
                session_maker=self._node_session_maker,
                node_ids=list(pending_by_node.keys()),
            )

            for node_id, submissions in pending_by_node.items():
                node = self._node_collection.getCachedNode(node_id)
                if node is None:
                    structuredLogger.warning(
                        "Heartbeat rejected for missing node",
                        event="lumeflow.opnet.heartbeat.rejected",
                        attrs=self._heartbeatAttrs(
                            **{
                                lumesof_logging.EVENT_OUTCOME: "failure",
                                lumesof_logging.EXCEPTION: "Node not found in this collection.",
                                lumesof_logging.LUMESOF_NODE_ID: str(node_id),
                            }
                        ),
                    )
                    for submission in submissions:
                        not_found_count += 1
                        self._setHeartbeatResult(
                            submission,
                            ok=False,
                            message="Node not found in this collection.",
                        )
                elif node.connection_status != "CONNECTED":
                    structuredLogger.warning(
                        "Heartbeat rejected for disconnected node",
                        event="lumeflow.opnet.heartbeat.rejected",
                        attrs=self._heartbeatAttrs(
                            **{
                                lumesof_logging.EVENT_OUTCOME: "failure",
                                lumesof_logging.EXCEPTION: not_connected_msg,
                                lumesof_logging.LUMESOF_NODE_ID: str(node_id),
                            }
                        ),
                    )
                    for submission in submissions:
                        not_connected_count += 1
                        self._setHeartbeatResult(
                            submission,
                            ok=False,
                            message=not_connected_msg,
                        )
                else:
                    ready_for_persistence.extend(submissions)

        persistStats = _HeartbeatPersistStats()
        if ready_for_persistence:
            persistStats = await self._async_persistHeartbeats(ready_for_persistence)
        failureCount = not_found_count + not_connected_count + persistStats.failed_count
        structuredLogger.debug(
            "Heartbeat batch processed",
            event="lumeflow.opnet.heartbeat_batch.processed",
            attrs=self._heartbeatAttrs(
                **{
                    lumesof_logging.EVENT_OUTCOME: (
                        "success" if failureCount == 0 else "partial"
                    ),
                    _HEARTBEAT_BATCH_SIZE: len(batch),
                    _HEARTBEAT_PERSISTED_COUNT: persistStats.persisted_count,
                    _HEARTBEAT_NOT_CONNECTED_COUNT: not_connected_count,
                    _HEARTBEAT_NOT_FOUND_COUNT: not_found_count,
                    _HEARTBEAT_FAILURE_COUNT: failureCount,
                }
            ),
        )
        self._recordHeartbeatSummaryWindow(
            batch_size=len(batch),
            persisted_count=persistStats.persisted_count,
            not_connected_count=not_connected_count,
            not_found_count=not_found_count,
            failure_count=failureCount,
        )

    async def _async_persistHeartbeats(
        self,
        submissions: List[_HeartbeatSubmission],
    ) -> _HeartbeatPersistStats:
        if not submissions:
            return _HeartbeatPersistStats()

        submissions_by_node: Dict[uuid.UUID, List[_HeartbeatSubmission]] = {}
        for submission in submissions:
            submissions_by_node.setdefault(submission.node_id, []).append(submission)

        queue: deque[List[_HeartbeatSubmission]] = deque([submissions])
        stats = _HeartbeatPersistStats()

        async with self._node_session_maker() as session:
            await self._async_applyHeartbeatResponseOverrides(
                session=session,
                submissions_by_node=submissions_by_node,
            )
            while queue:
                batch = queue.popleft()
                if not batch:
                    continue

                result = await self._async_tryPersistBatch(session, batch)
                if result is None:
                    logger.exception(
                        "OpNetControllerCollection heartbeat batch persistence raised unexpected error"
                    )
                    structuredLogger.error(
                        "Heartbeat batch persistence failed",
                        event="lumeflow.opnet.heartbeat_batch.failed",
                        attrs=self._heartbeatAttrs(
                            **{
                                lumesof_logging.EVENT_OUTCOME: "failure",
                                lumesof_logging.EXCEPTION: "unexpected_error",
                                _HEARTBEAT_BATCH_SIZE: len(batch),
                                _HEARTBEAT_FAILURE_COUNT: len(batch),
                            }
                        ),
                    )
                    for submission in batch:
                        self._setHeartbeatResult(
                            submission,
                            ok=False,
                            message="Failed to persist heartbeat batch.",
                        )
                    stats.failed_count += len(batch)
                    continue
                if result.success:
                    for submission in batch:
                        self._setHeartbeatResult(submission, ok=True)
                    stats.persisted_count += len(batch)
                    continue

                if len(batch) == 1:
                    submission = batch[0]
                    if result.reason == "missing_node":
                        self._setHeartbeatResult(
                            submission,
                            ok=False,
                            message="Node not found in this collection.",
                        )
                    elif result.reason == "serialization_exhausted":
                        self._setHeartbeatResult(
                            submission,
                            ok=False,
                            message="Failed to persist heartbeat batch after retries.",
                        )
                    else:
                        self._setHeartbeatResult(
                            submission,
                            ok=False,
                            message="Failed to persist heartbeat batch.",
                        )
                    structuredLogger.warning(
                        "Heartbeat persistence failed for node",
                        event="lumeflow.opnet.heartbeat.failed",
                        attrs=self._heartbeatAttrs(
                            **{
                                lumesof_logging.EVENT_OUTCOME: "failure",
                                lumesof_logging.EXCEPTION: result.reason or "persist_failed",
                                lumesof_logging.LUMESOF_NODE_ID: str(submission.node_id),
                                _HEARTBEAT_BATCH_SIZE: 1,
                                _HEARTBEAT_FAILURE_COUNT: 1,
                            }
                        ),
                    )
                    stats.failed_count += 1
                    continue

                structuredLogger.warning(
                    "Heartbeat batch bisected",
                    event="lumeflow.opnet.heartbeat_batch.bisected",
                    attrs=self._heartbeatAttrs(
                        **{
                            lumesof_logging.EVENT_OUTCOME: "partial",
                            lumesof_logging.EXCEPTION: result.reason or "persist_failed",
                            _HEARTBEAT_BATCH_SIZE: len(batch),
                        }
                    ),
                )
                mid = len(batch) // 2
                queue.append(batch[:mid])
                queue.append(batch[mid:])
        return stats

    async def _async_tryPersistBatch(
        self,
        session: AsyncSession,
        batch: List[_HeartbeatSubmission],
    ) -> Optional[_HeartbeatPersistResult]:
        if not batch:
            return _HeartbeatPersistResult(success=True)
        logger.debug(
            f"_async_tryPersistBatch: begin cluster={self._cluster_id} "
            f"usecase={self._usecase} batch_size={len(batch)}"
        )
        node_ids = {submission.node_id for submission in batch}
        last_record_count = 0

        async def _attempt() -> None:
            nonlocal last_record_count
            async with _transaction(session) as tx_session:
                existing_rows = await tx_session.execute(
                    select(TabNodes.id).where(TabNodes.id.in_(list(node_ids)))
                )
                existing_ids = {row[0] for row in existing_rows}

                missing_ids = node_ids - existing_ids
                for submission in batch:
                    if submission.node_id in missing_ids:
                        self._setHeartbeatResult(
                            submission,
                            ok=False,
                            message="Node not found in this collection.",
                        )

                present_submissions = [
                    submission for submission in batch if submission.node_id in existing_ids
                ]
                if not present_submissions:
                    return

                records = [
                    {
                        "node_id": submission.node_id,
                        "ts": datetime.utcnow(),
                        "heartbeat": submission.heartbeat.SerializeToString(),
                    }
                    for submission in present_submissions
                ]
                last_record_count = len(records)
                await tx_session.execute(insert(TabNodeHeartbeats), records)

        try:
            await sqldb_utils.async_runWithSerializationRetries(_attempt)
            logger.debug(
                f"_async_tryPersistBatch: success cluster={self._cluster_id} "
                f"usecase={self._usecase} batch_size={len(batch)} "
                f"record_count={last_record_count}"
            )
            return _HeartbeatPersistResult(success=True)
        except IntegrityError:
            reason = "missing_node" if last_record_count == 1 else "integrity_error"
            logger.warning(
                f"_async_tryPersistBatch: integrity error cluster={self._cluster_id} "
                f"usecase={self._usecase} batch_size={len(batch)} reason={reason}"
            )
            return _HeartbeatPersistResult(success=False, reason=reason)
        except DBAPIError as exc:
            if sqldb_utils.isRetryableSerializationError(exc):
                logger.warning(
                    f"Heartbeat persistence exhausted serialization retries "
                    f"(batch_size={last_record_count})"
                )
                if len(node_ids) == 1:
                    existing_rows = await session.execute(
                        select(TabNodes.id).where(TabNodes.id.in_(list(node_ids)))
                    )
                    existing_ids = {row[0] for row in existing_rows}
                    if not existing_ids:
                        return _HeartbeatPersistResult(success=False, reason="missing_node")
                return _HeartbeatPersistResult(success=False, reason="serialization_exhausted")
            logger.exception(
                "OpNetControllerCollection heartbeat persistence encountered unexpected DB error"
            )
            return _HeartbeatPersistResult(success=False, reason="unexpected_db_error")
        except Exception:
            logger.exception(
                "OpNetControllerCollection heartbeat persistence encountered unexpected error"
            )
            return None

    async def _async_applyHeartbeatResponseOverrides(
        self,
        *,
        session: AsyncSession,
        submissions_by_node: Dict[uuid.UUID, List[_HeartbeatSubmission]],
    ) -> None:
        if not submissions_by_node:
            return

        node_ids = list(submissions_by_node.keys())
        if not node_ids:
            return

        override_table = TabHeartbeatResponseOverrides.__table__
        try:
            rows = await session.execute(
                select(
                    TabHeartbeatResponseOverrides.node_id,
                    TabHeartbeatResponseOverrides.resp_override,
                ).where(TabHeartbeatResponseOverrides.node_id.in_(node_ids))
            )
            override_rows = rows.all()
            if not override_rows:
                logger.debug(
                    f"_async_applyHeartbeatResponseOverrides: none found "
                    f"cluster={self._cluster_id} usecase={self._usecase} "
                    f"node_count={len(node_ids)}"
                )
                return

            async with _transaction(session) as tx_session:
                overridden_submission_count = 0
                for node_id, resp_override in override_rows:
                    response_proto = OpNetCtlToNodeHeartbeat()
                    response_proto.ParseFromString(resp_override)
                    for submission in submissions_by_node.get(node_id, []):
                        self._setHeartbeatOverride(submission, response_proto)
                        overridden_submission_count += 1

                for node_id, _ in override_rows:
                    count = len(submissions_by_node.get(node_id, []))
                    if count == 0:
                        continue
                    stmt = (
                        update(override_table)
                        .where(override_table.c.node_id == node_id)
                        .values(num_deliveries=override_table.c.num_deliveries + count)
                    )
                    await tx_session.execute(stmt)
            logger.info(
                f"_async_applyHeartbeatResponseOverrides: applied "
                f"cluster={self._cluster_id} usecase={self._usecase} "
                f"override_node_count={len(override_rows)} "
                f"overridden_submission_count={overridden_submission_count}"
            )
        except Exception:
            logger.exception("OpNetControllerCollection failed to apply heartbeat response overrides")

    async def _async_heartbeatProcessorLoop(self) -> None:
        logger.info(
            f"_async_heartbeatProcessorLoop: started cluster={self._cluster_id} "
            f"usecase={self._usecase} interval_s={self._heartbeat_batching_interval_s}"
        )
        try:
            while True:
                await asyncio.sleep(self._heartbeat_batching_interval_s)
                batch = await self._async_drainPendingHeartbeats()
                if not batch:
                    self._logHeartbeatSummaryIfNeeded()
                    continue
                try:
                    await self._async_processHeartbeatBatch(batch)
                    self._logHeartbeatSummaryIfNeeded()
                except Exception:  # pragma: no cover - defensive guard
                    logger.exception("OpNetControllerCollection heartbeat batch processing failed")
                    self._recordHeartbeatSummaryWindow(
                        batch_size=len(batch),
                        persisted_count=0,
                        not_connected_count=0,
                        not_found_count=0,
                        failure_count=len(batch),
                    )
                    self._logHeartbeatSummaryIfNeeded()
                    self._rejectHeartbeatBatch(
                        batch,
                        RuntimeError("Heartbeat processor encountered an unexpected error."),
                    )
        except asyncio.CancelledError:
            self._logHeartbeatSummaryIfNeeded(force=True)
            batch = await self._async_drainPendingHeartbeats()
            cancelled_count = 0
            for submission in batch:
                future = submission.response_future
                if not future.done():
                    future.cancel()
                    cancelled_count += 1
            logger.info(
                f"_async_heartbeatProcessorLoop: cancelled cluster={self._cluster_id} "
                f"usecase={self._usecase} drained_batch_size={len(batch)} "
                f"cancelled_futures={cancelled_count}"
            )
            raise
