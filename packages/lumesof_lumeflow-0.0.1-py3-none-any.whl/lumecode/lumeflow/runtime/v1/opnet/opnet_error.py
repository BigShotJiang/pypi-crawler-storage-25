from __future__ import annotations
from enum import IntEnum
from typing import Any, Optional


class OpNetErrorCode(IntEnum):
    # Google RPC status codes
    OK = 0
    CANCELLED = 1
    UNKNOWN = 2
    INVALID_ARGUMENT = 3
    DEADLINE_EXCEEDED = 4
    NOT_FOUND = 5
    ALREADY_EXISTS = 6
    PERMISSION_DENIED = 7
    RESOURCE_EXHAUSTED = 8
    FAILED_PRECONDITION = 9
    ABORTED = 10
    OUT_OF_RANGE = 11
    UNIMPLEMENTED = 12
    INTERNAL = 13
    UNAVAILABLE = 14
    DATA_LOSS = 15
    UNAUTHENTICATED = 16


class OpNetError(Exception):
    """Domain error with machine-usable status code."""
    def __init__(
        self,
        code: OpNetErrorCode,
        message: str,
        *,
        details: Optional[dict[str, Any]] = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details or {}

    def __str__(self) -> str:  # pragma: no cover
        return f"{self.code.name}: {self.message}"

    def to_dict(self) -> dict[str, Any]:
        return {"code": int(self.code), "name": self.code.name, "message": self.message, "details": self.details}
