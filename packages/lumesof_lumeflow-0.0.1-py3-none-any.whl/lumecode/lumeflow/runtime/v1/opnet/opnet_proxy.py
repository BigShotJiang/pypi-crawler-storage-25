"""Abstract interface for OpNet proxy implementations."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Sequence, Tuple

from lumecode.lumeflow.runtime.v1.operator import operator_pb2
from lumecode.lumeflow.runtime.v1.opnet import opnet_types_pb2
from lumecode.lumeflow.runtime.v1.opnet.opnet_types_pb2 import Result


class OpNetUpstream(ABC):
    """Interface for retrieving deliveries and acknowledging them."""

    @abstractmethod
    async def async_getOpNetMessage(self) -> Tuple[Result, operator_pb2.DeliverRequest]:
        """
        Retrieve a delivery message from the OpNet backend.

        Returns:
            (result, deliver_request)
              - deliver_request encapsulates the payload and metadata to forward.
        """
        raise NotImplementedError

    @abstractmethod
    async def async_ack(self, request: operator_pb2.AckRequest) -> Result:
        """
        Acknowledge completion of a delivery to the OpNet backend.

        Returns:
            Result(ok=...) — ok=True when the backend accepts the acknowledgement.
        """
        raise NotImplementedError

    @abstractmethod
    async def async_reset(self, reset_id: str) -> Result:
        """
        Reset or discard any upstream state associated with `reset_id`.

        Args:
            reset_id: Identifier for the upstream stream or delivery to reset.

        Returns:
            Result(ok=...) — ok=True when the reset was handled successfully.
        """
        raise NotImplementedError


class OpNetDownstream(ABC):
    """Interface for forwarding outbound publish requests to the backend."""

    @abstractmethod
    async def async_putOpNetMessage(self, request: operator_pb2.DeliverRequest) -> Result:
        """
        Forward a publish request into the OpNet backend.

        Returns:
            Result(ok=...) — ok=True when the publish succeeds per backend guarantees.
        """
        raise NotImplementedError


class OpNetProxy(OpNetUpstream, OpNetDownstream):
    """Composite proxy surface exposing upstream and downstream operations."""

    @abstractmethod
    async def async_setup(
        self,
        *,
        connections: Sequence[opnet_types_pb2.OpNetConnection],
    ) -> Result:
        """
        Configure the proxy using controller-resolved connections.

        Returns:
            Result(ok=...) — ok=True if the configuration completes successfully.
        """
        raise NotImplementedError

    @abstractmethod
    async def async_hasWork(self) -> bool:
        """
        Return whether the proxy currently has, or expects, work for the operator.

        This signal is used by sidecar responsiveness tracking to avoid marking the
        operator non-responsive while no work is available.
        """
        raise NotImplementedError
