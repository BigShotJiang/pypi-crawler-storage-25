"""Concrete OpNet proxy backed by an OpNet node plugin."""

from __future__ import annotations

import asyncio
import hashlib
import logging
import time
from collections import deque
from dataclasses import dataclass
from typing import Mapping, Optional, Sequence

from lumecode.lumeflow.runtime.v1.operator import operator_pb2
from lumecode.lumeflow.runtime.v1.opnet import opnet_types_pb2
from lumecode.lumeflow.runtime.v1.opnet.opnet_plugin_interface import OpNetNodePlugin
from lumecode.lumeflow.runtime.v1.opnet.opnet_proxy import OpNetProxy
from lumecode.lumeflow.runtime.v1.opnet.opnet_types_pb2 import Result

_DEFAULT_MAX_BUFFERED_MESSAGES = 2
_DEFAULT_WORKER_BACKOFF_S = 0.1
_DEFAULT_CONSUMER_MAX_CONCURRENCY = 1

logger = logging.getLogger(__name__)


class _ConfigValidationError(ValueError):
    pass


@dataclass(frozen=True)
class _QueuedDelivery:
    portName: str
    messageId: str
    opnetMessage: opnet_types_pb2.OpNetMessage


@dataclass(frozen=True)
class _ProxyState:
    portToLink: dict[str, str]
    portTypes: dict[str, int]
    producerPorts: tuple[str, ...]
    consumerPorts: tuple[str, ...]
    consumerMaxConcurrency: dict[str, int]
    consumerPortByLink: dict[str, str]
    maxBufferedMessages: int
    consumerWorkerBackoffS: float


class PluginBackedOpNetProxy(OpNetProxy):
    """Routes operator sidecar traffic through an ``OpNetNodePlugin``."""

    def __init__(
        self,
        *,
        node_plugin: OpNetNodePlugin,
        consumer_max_concurrency: Optional[Mapping[str, int]] = None,
        default_consumer_max_concurrency: int = _DEFAULT_CONSUMER_MAX_CONCURRENCY,
        max_buffered_messages: int = _DEFAULT_MAX_BUFFERED_MESSAGES,
        consumer_worker_backoff_s: float = _DEFAULT_WORKER_BACKOFF_S,
        consumer_get_timeout_s: Optional[float] = None,
    ) -> None:
        self._nodePlugin = node_plugin
        self._lifecycleLock = asyncio.Lock()
        self._state: Optional[_ProxyState] = None

        self._defaultConsumerMaxConcurrency = default_consumer_max_concurrency
        if (
            not isinstance(self._defaultConsumerMaxConcurrency, int)
            or self._defaultConsumerMaxConcurrency <= 0
        ):
            raise ValueError("'default_consumer_max_concurrency' must be a positive integer")

        if consumer_max_concurrency is None:
            consumer_max_concurrency = {}
        self._consumerMaxConcurrencyOverrides: dict[str, int] = {}
        for portName, value in consumer_max_concurrency.items():
            if not isinstance(portName, str) or not portName:
                raise ValueError("consumer_max_concurrency keys must be non-empty strings")
            if not isinstance(value, int) or value <= 0:
                raise ValueError(f"consumer_max_concurrency['{portName}'] must be a positive integer")
            self._consumerMaxConcurrencyOverrides[portName] = value

        self._maxBufferedMessages = max_buffered_messages
        if not isinstance(self._maxBufferedMessages, int) or self._maxBufferedMessages <= 0:
            raise ValueError("'max_buffered_messages' must be a positive integer")

        self._consumerWorkerBackoffS = float(consumer_worker_backoff_s)
        if self._consumerWorkerBackoffS < 0:
            raise ValueError("'consumer_worker_backoff_s' must be a non-negative number")

        self._consumerGetTimeoutS = (
            float(consumer_get_timeout_s)
            if consumer_get_timeout_s is not None
            else None
        )
        if self._consumerGetTimeoutS is not None and self._consumerGetTimeoutS <= 0:
            raise ValueError("'consumer_get_timeout_s' must be a positive number")

        self._queueLock = asyncio.Lock()
        self._queueCondition = asyncio.Condition(self._queueLock)
        self._bufferedDeliveries: deque[_QueuedDelivery] = deque()
        self._hasWorkByPort: dict[str, bool] = {}

        self._workerTasksByLink: dict[str, asyncio.Task[None]] = {}
        self._workersStopEvent = asyncio.Event()
        self._bridgeProducerPortsByPortAndLink: dict[tuple[str, str], str] = {}

    async def async_setup(
        self,
        *,
        connections: Sequence[opnet_types_pb2.OpNetConnection],
    ) -> Result:
        logger.debug("OpNet proxy setup requested connection_count=%d", len(connections))
        try:
            pendingState = self._buildState(connections=connections)
        except _ConfigValidationError as exc:
            logger.debug("OpNet proxy setup rejected config error=%s", exc)
            return Result(ok=False, message=f"invalid opnet proxy setup: {exc}")
        logger.debug(
            "OpNet proxy setup state producer_ports=%s consumer_ports=%s "
            "max_buffered_messages=%d worker_backoff_s=%s",
            pendingState.producerPorts,
            pendingState.consumerPorts,
            pendingState.maxBufferedMessages,
            pendingState.consumerWorkerBackoffS,
        )

        bindResult = await self._async_bindState(state=pendingState)
        if not bindResult.ok:
            logger.debug(
                "OpNet proxy setup binding failed message=%s",
                bindResult.message or "<none>",
            )
            return bindResult

        failures: list[str] = []
        async with self._lifecycleLock:
            await self._async_stopWorkersLocked()
            drained = await self._async_drainQueueLocked()
            failures.extend(await self._async_nackDeliveries(drained))

            self._state = pendingState
            self._workersStopEvent = asyncio.Event()
            self._bridgeProducerPortsByPortAndLink = {}
            self._hasWorkByPort = {portName: False for portName in pendingState.consumerPorts}
            await self._async_startWorkersLocked(state=pendingState)
            logger.debug(
                "OpNet proxy setup activated producer_ports=%s consumer_ports=%s",
                pendingState.producerPorts,
                pendingState.consumerPorts,
            )

        if len(failures) > 0:
            logger.debug(
                "OpNet proxy setup queue drain nack failures count=%d failures=%s",
                len(failures),
                failures,
            )
            return Result(
                ok=False,
                message=f"setup completed with queue nack failures: {'; '.join(failures)}",
            )
        logger.debug("OpNet proxy setup completed successfully")
        return Result(ok=True)

    async def async_putOpNetMessage(self, request: operator_pb2.DeliverRequest) -> Result:
        traceId = (
            request.message_context.trace_id
            if request.HasField("message_context") and request.message_context.trace_id
            else "<none>"
        )
        payloadType = request.payload.type_url or "<none>"
        logger.debug(
            "OpNet proxy publish received port=%s message_id=%s trace_id=%s payload_type=%s",
            request.port,
            request.message_id or "<none>",
            traceId,
            payloadType,
        )
        state, stateResult = await self._async_getState()
        if state is None:
            logger.debug(
                "OpNet proxy publish rejected port=%s reason=%s",
                request.port,
                stateResult.message or "<none>",
            )
            return stateResult

        portName = request.port
        if portName not in state.portToLink:
            logger.debug("OpNet proxy publish rejected unknown_port=%s", portName)
            return Result(ok=False, message=f"unknown port '{portName}'")
        if not self._isProducerPortType(state.portTypes[portName]):
            logger.debug("OpNet proxy publish rejected non_producer_port=%s", portName)
            return Result(
                ok=False,
                message=f"port '{portName}' is not configured as a producer",
            )

        opnetMessage = self._toOpNetMessage(request=request)
        if state.portTypes[portName] == opnet_types_pb2.OpNetPort.PortType.EGRESS_BRIDGE:
            bridgeLinks = self._extractBridgeLinks(request=request)
            logger.debug(
                "OpNet proxy publish bridge fanout port=%s bridge_links=%s",
                portName,
                bridgeLinks,
            )
            if len(bridgeLinks) == 0:
                return Result(
                    ok=False,
                    message=f"bridge egress port '{portName}' requires message_context.bridge_link_refs",
                )
            results = await asyncio.gather(
                *[
                    self._async_publishBridgeEgressLink(
                        portName=portName,
                        bridgeLinkRef=bridgeLinkRef,
                        opnetMessage=opnetMessage,
                    )
                    for bridgeLinkRef in bridgeLinks
                ]
            )
            failures = [failure for failure in results if failure is not None]
            if len(failures) > 0:
                logger.debug(
                    "OpNet proxy bridge publish failed port=%s failures=%s",
                    portName,
                    failures,
                )
                return Result(
                    ok=False,
                    message=f"bridge egress publish failures: {'; '.join(failures)}",
                )
            logger.debug("OpNet proxy bridge publish succeeded port=%s", portName)
            return Result(ok=True)

        try:
            result = await self._nodePlugin.async_putOpNetMessage(
                port_name=portName,
                opnet_message=opnetMessage,
            )
            logger.debug(
                "OpNet proxy publish completed port=%s ok=%s message=%s",
                portName,
                result.ok,
                result.message or "<none>",
            )
            return result
        except Exception as exc:
            logger.debug(
                "OpNet proxy publish raised port=%s error=%s",
                portName,
                exc,
            )
            return Result(ok=False, message=f"failed to publish on port '{portName}': {exc}")

    async def async_getOpNetMessage(self) -> tuple[Result, operator_pb2.DeliverRequest]:
        state, stateResult = await self._async_getState()
        if state is None:
            logger.debug(
                "OpNet proxy delivery fetch rejected reason=%s",
                stateResult.message or "<none>",
            )
            return stateResult, operator_pb2.DeliverRequest()

        if len(state.consumerPorts) == 0:
            logger.debug("OpNet proxy delivery fetch rejected reason=no consumer ports")
            return Result(ok=False, message="no consumer ports configured"), operator_pb2.DeliverRequest()

        logger.debug(
            "OpNet proxy delivery fetch begin queue_depth=%d consumer_ports=%s "
            "active_workers=%d",
            len(self._bufferedDeliveries),
            state.consumerPorts,
            len(self._workerTasksByLink),
        )

        async with self._queueCondition:
            waitCycle = 0
            while len(self._bufferedDeliveries) == 0:
                currentState = self._state
                if currentState is None or len(currentState.consumerPorts) == 0:
                    logger.debug("OpNet proxy delivery fetch stopped while waiting")
                    return (
                        Result(ok=False, message="no consumer ports configured"),
                        operator_pb2.DeliverRequest(),
                    )
                waitCycle += 1
                logger.debug(
                    "OpNet proxy delivery queue empty; waiting for worker cycle=%d "
                    "stop_event=%s active_workers=%d",
                    waitCycle,
                    self._workersStopEvent.is_set(),
                    len(self._workerTasksByLink),
                )
                await self._queueCondition.wait()
                logger.debug(
                    "OpNet proxy delivery wait woke cycle=%d queue_depth=%d",
                    waitCycle,
                    len(self._bufferedDeliveries),
                )

            queued = self._bufferedDeliveries.popleft()
            queueDepth = len(self._bufferedDeliveries)
            self._queueCondition.notify_all()

        traceId = (
            queued.opnetMessage.message_context.trace_id
            if queued.opnetMessage.HasField("message_context")
            and queued.opnetMessage.message_context.trace_id
            else "<none>"
        )
        delivery = self._toDeliverRequest(
            portName=queued.portName,
            messageId=queued.messageId,
            opnetMessage=queued.opnetMessage,
        )
        logger.debug(
            "OpNet proxy delivery dequeued port=%s message_id=%s trace_id=%s queue_depth=%d",
            queued.portName,
            queued.messageId,
            traceId,
            queueDepth,
        )
        return Result(ok=True), delivery

    async def async_hasWork(self) -> bool:
        async with self._queueCondition:
            if len(self._bufferedDeliveries) > 0:
                return True
            return any(self._hasWorkByPort.values())

    async def async_ack(self, request: operator_pb2.AckRequest) -> Result:
        logger.debug(
            "OpNet proxy ack received port=%s message_id=%s",
            request.port,
            request.message_id or "<none>",
        )
        state, stateResult = await self._async_getState()
        if state is None:
            logger.debug(
                "OpNet proxy ack rejected reason=%s",
                stateResult.message or "<none>",
            )
            return stateResult

        portName = request.port
        if portName not in state.portToLink:
            logger.debug("OpNet proxy ack rejected unknown_port=%s", portName)
            return Result(ok=False, message=f"unknown port '{portName}'")
        if not self._isConsumerPortType(state.portTypes[portName]):
            logger.debug("OpNet proxy ack rejected non_consumer_port=%s", portName)
            return Result(
                ok=False,
                message=f"port '{portName}' is not configured as a consumer",
            )
        if not request.message_id:
            logger.debug("OpNet proxy ack rejected missing_message_id port=%s", portName)
            return Result(ok=False, message=f"ack request for port '{portName}' must include message_id")

        try:
            result = await self._nodePlugin.async_ack(
                port_name=portName,
                message_id=request.message_id,
            )
            logger.debug(
                "OpNet proxy ack completed port=%s message_id=%s ok=%s message=%s",
                portName,
                request.message_id,
                result.ok,
                result.message or "<none>",
            )
            return result
        except Exception as exc:
            logger.debug(
                "OpNet proxy ack raised port=%s message_id=%s error=%s",
                portName,
                request.message_id,
                exc,
            )
            return Result(ok=False, message=f"failed to ack port '{portName}': {exc}")

    async def async_reset(self, reset_id: str) -> Result:
        logger.debug("OpNet proxy reset requested reset_id=%s", reset_id)

        state, _ = await self._async_getState()
        if state is None:
            logger.debug("OpNet proxy reset skipped: proxy not configured")
            return Result(ok=True, message="opnet proxy is not configured")

        failures: list[str] = []
        async with self._lifecycleLock:
            currentState = self._state
            if currentState is None:
                logger.debug("OpNet proxy reset skipped during lifecycle: proxy not configured")
                return Result(ok=True, message="opnet proxy is not configured")

            await self._async_stopWorkersLocked()
            drained = await self._async_drainQueueLocked()
            failures.extend(await self._async_nackDeliveries(drained))
            failures.extend(await self._async_nackAllConsumers(consumerPorts=currentState.consumerPorts))

            self._workersStopEvent = asyncio.Event()
            self._hasWorkByPort = {portName: False for portName in currentState.consumerPorts}
            await self._async_startWorkersLocked(state=currentState)

        if len(failures) > 0:
            logger.debug("OpNet proxy reset completed with failures=%s", failures)
            return Result(ok=False, message=f"failed to reset consumer ports: {'; '.join(failures)}")
        logger.debug("OpNet proxy reset completed reset_id=%s", reset_id)
        return Result(ok=True)

    async def _async_getState(self) -> tuple[Optional[_ProxyState], Result]:
        async with self._lifecycleLock:
            if self._state is None:
                return None, Result(ok=False, message="opnet proxy is not configured")
            return self._state, Result(ok=True)

    async def _async_bindState(self, *, state: _ProxyState) -> Result:
        for portName in state.producerPorts:
            linkRef = state.portToLink[portName]
            logger.debug(
                "OpNet proxy binding producer port=%s link_ref=%s",
                portName,
                linkRef,
            )
            try:
                result, _ = await self._nodePlugin.async_addProducer(
                    link_ref=linkRef,
                    port_name=portName,
                )
            except Exception as exc:
                logger.debug(
                    "OpNet proxy producer bind raised port=%s link_ref=%s error=%s",
                    portName,
                    linkRef,
                    exc,
                )
                return Result(
                    ok=False,
                    message=f"failed to bind producer port '{portName}' to '{linkRef}': {exc}",
                )
            if not result.ok:
                logger.debug(
                    "OpNet proxy producer bind failed port=%s link_ref=%s message=%s",
                    portName,
                    linkRef,
                    result.message or "<none>",
                )
                return Result(
                    ok=False,
                    message=(
                        f"failed to bind producer port '{portName}' to '{linkRef}': "
                        f"{result.message or 'unknown error'}"
                    ),
                )
            logger.debug("OpNet proxy producer bound port=%s link_ref=%s", portName, linkRef)

        for portName in state.consumerPorts:
            linkRef = state.portToLink[portName]
            maxConcurrency = state.consumerMaxConcurrency[portName]
            logger.debug(
                "OpNet proxy binding consumer port=%s link_ref=%s max_concurrency=%d",
                portName,
                linkRef,
                maxConcurrency,
            )
            try:
                result, _ = await self._nodePlugin.async_addConsumer(
                    link_ref=linkRef,
                    port_name=portName,
                    max_concurrency=maxConcurrency,
                )
            except Exception as exc:
                logger.debug(
                    "OpNet proxy consumer bind raised port=%s link_ref=%s error=%s",
                    portName,
                    linkRef,
                    exc,
                )
                return Result(
                    ok=False,
                    message=f"failed to bind consumer port '{portName}' to '{linkRef}': {exc}",
                )
            if not result.ok:
                logger.debug(
                    "OpNet proxy consumer bind failed port=%s link_ref=%s message=%s",
                    portName,
                    linkRef,
                    result.message or "<none>",
                )
                return Result(
                    ok=False,
                    message=(
                        f"failed to bind consumer port '{portName}' to '{linkRef}': "
                        f"{result.message or 'unknown error'}"
                    ),
                )
            logger.debug(
                "OpNet proxy consumer bound port=%s link_ref=%s max_concurrency=%d",
                portName,
                linkRef,
                maxConcurrency,
            )

        return Result(ok=True)

    async def _async_startWorkersLocked(self, *, state: _ProxyState) -> None:
        logger.debug(
            "OpNet proxy starting consumer workers count=%d",
            len(state.consumerPortByLink),
        )
        self._workerTasksByLink = {}
        for linkRef, portName in state.consumerPortByLink.items():
            task = asyncio.create_task(
                self._async_consumerWorker(
                    linkRef=linkRef,
                    portName=portName,
                    stopEvent=self._workersStopEvent,
                    maxBufferedMessages=state.maxBufferedMessages,
                    backoffS=state.consumerWorkerBackoffS,
                    getTimeoutS=self._consumerGetTimeoutS,
                ),
                name=f"opnet-consumer-{linkRef}",
            )
            self._workerTasksByLink[linkRef] = task
            logger.debug(
                "OpNet proxy worker started link_ref=%s port=%s task_name=%s",
                linkRef,
                portName,
                task.get_name(),
            )

        async with self._queueCondition:
            self._queueCondition.notify_all()

    async def _async_stopWorkersLocked(self) -> None:
        logger.debug("OpNet proxy stopping workers count=%d", len(self._workerTasksByLink))
        self._workersStopEvent.set()
        tasks = list(self._workerTasksByLink.values())
        self._workerTasksByLink = {}

        for task in tasks:
            if task.done():
                continue
            task.cancel()

        async with self._queueCondition:
            self._queueCondition.notify_all()

        if len(tasks) > 0:
            await asyncio.gather(*tasks, return_exceptions=True)
        logger.debug("OpNet proxy workers stopped count=%d", len(tasks))

    async def _async_drainQueueLocked(self) -> list[_QueuedDelivery]:
        async with self._queueCondition:
            drained = list(self._bufferedDeliveries)
            self._bufferedDeliveries.clear()
            self._queueCondition.notify_all()
            logger.debug("OpNet proxy drained buffered queue count=%d", len(drained))
            return drained

    async def _async_consumerWorker(
        self,
        *,
        linkRef: str,
        portName: str,
        stopEvent: asyncio.Event,
        maxBufferedMessages: int,
        backoffS: float,
        getTimeoutS: Optional[float],
    ) -> None:
        logger.debug(
            "OpNet proxy worker loop started link_ref=%s port=%s max_buffered_messages=%d "
            "get_timeout_s=%s",
            linkRef,
            portName,
            maxBufferedMessages,
            getTimeoutS,
        )

        pullAttempt = 0
        while not stopEvent.is_set():
            logger.debug(
                "OpNet proxy worker iteration begin port=%s attempt_next=%d "
                "stop_event=%s queue_depth=%d",
                portName,
                pullAttempt + 1,
                stopEvent.is_set(),
                len(self._bufferedDeliveries),
            )
            async with self._queueCondition:
                while (
                    len(self._bufferedDeliveries) >= maxBufferedMessages
                    and not stopEvent.is_set()
                ):
                    logger.debug(
                        "OpNet proxy worker waiting for queue capacity port=%s queue_depth=%d max=%d",
                        portName,
                        len(self._bufferedDeliveries),
                        maxBufferedMessages,
                    )
                    await self._queueCondition.wait()
                if stopEvent.is_set():
                    logger.debug("OpNet proxy worker exiting after stop signal port=%s", portName)
                    return
                logger.debug(
                    "OpNet proxy worker queue gate open port=%s queue_depth=%d max=%d",
                    portName,
                    len(self._bufferedDeliveries),
                    maxBufferedMessages,
                )

            pullAttempt += 1
            fetchStart = time.monotonic()
            logger.debug(
                "OpNet proxy worker pull begin port=%s attempt=%d queue_depth=%d",
                portName,
                pullAttempt,
                len(self._bufferedDeliveries),
            )
            try:
                if getTimeoutS is not None:
                    result, messageId, opnetMessage = await asyncio.wait_for(
                        self._nodePlugin.async_getOpNetMessage(port_name=portName),
                        timeout=getTimeoutS,
                    )
                else:
                    result, messageId, opnetMessage = await self._nodePlugin.async_getOpNetMessage(
                        port_name=portName,
                    )
            except asyncio.CancelledError:
                logger.debug("OpNet proxy worker cancelled port=%s", portName)
                raise
            except TimeoutError:
                elapsedMs = int((time.monotonic() - fetchStart) * 1000)
                logger.debug(
                    "OpNet proxy worker fetch timed out port=%s attempt=%d elapsed_ms=%d",
                    portName,
                    pullAttempt,
                    elapsedMs,
                )
                await self._async_setHasWork(portName=portName, hasWork=False)
                await self._async_sleepBackoff(backoffS=backoffS, stopEvent=stopEvent)
                continue
            except Exception as exc:
                elapsedMs = int((time.monotonic() - fetchStart) * 1000)
                logger.debug(
                    "OpNet proxy worker fetch raised port=%s attempt=%d "
                    "elapsed_ms=%d error_type=%s error=%s",
                    portName,
                    pullAttempt,
                    elapsedMs,
                    type(exc).__name__,
                    exc,
                )
                await self._async_sleepBackoff(backoffS=backoffS, stopEvent=stopEvent)
                continue

            elapsedMs = int((time.monotonic() - fetchStart) * 1000)
            traceId = (
                opnetMessage.message_context.trace_id
                if opnetMessage is not None
                and opnetMessage.HasField("message_context")
                and opnetMessage.message_context.trace_id
                else "<none>"
            )
            logger.debug(
                "OpNet proxy worker pull result port=%s attempt=%d elapsed_ms=%d "
                "ok=%s message_id=%s trace_id=%s",
                portName,
                pullAttempt,
                elapsedMs,
                result.ok,
                messageId or "<none>",
                traceId,
            )

            if stopEvent.is_set():
                if messageId:
                    logger.debug(
                        "OpNet proxy worker stop while holding message port=%s message_id=%s",
                        portName,
                        messageId,
                    )
                    await self._async_nackSingle(portName=portName, messageId=messageId)
                else:
                    logger.debug(
                        "OpNet proxy worker stop after fetch without message "
                        "port=%s attempt=%d",
                        portName,
                        pullAttempt,
                    )
                return

            if not result.ok or not messageId or opnetMessage is None:
                logger.debug(
                    "OpNet proxy worker fetch miss port=%s ok=%s message_id=%s "
                    "has_message=%s miss_flags=(result_not_ok:%s missing_id:%s "
                    "missing_payload:%s) reason=%s",
                    portName,
                    result.ok,
                    messageId or "<none>",
                    opnetMessage is not None,
                    not result.ok,
                    not bool(messageId),
                    opnetMessage is None,
                    result.message or "<none>",
                )
                await self._async_sleepBackoff(backoffS=backoffS, stopEvent=stopEvent)
                continue

            await self._async_setHasWork(portName=portName, hasWork=True)
            clonedMessage = opnet_types_pb2.OpNetMessage()
            clonedMessage.CopyFrom(opnetMessage)
            queued = _QueuedDelivery(
                portName=portName,
                messageId=messageId,
                opnetMessage=clonedMessage,
            )

            shouldNack = False
            shouldNackReason = ""
            async with self._queueCondition:
                if stopEvent.is_set():
                    shouldNack = True
                    shouldNackReason = "stop_event_set_before_enqueue"
                    logger.debug(
                        "OpNet proxy worker enqueue decision port=%s message_id=%s "
                        "trace_id=%s should_nack=%s reason=%s",
                        portName,
                        messageId,
                        traceId,
                        shouldNack,
                        shouldNackReason,
                    )
                elif len(self._bufferedDeliveries) < maxBufferedMessages:
                    self._bufferedDeliveries.append(queued)
                    traceId = (
                        queued.opnetMessage.message_context.trace_id
                        if queued.opnetMessage.HasField("message_context")
                        and queued.opnetMessage.message_context.trace_id
                        else "<none>"
                    )
                    logger.debug(
                        "OpNet proxy worker queued message port=%s message_id=%s trace_id=%s queue_depth=%d",
                        portName,
                        messageId,
                        traceId,
                        len(self._bufferedDeliveries),
                    )
                    self._queueCondition.notify_all()
                else:
                    shouldNack = True
                    shouldNackReason = (
                        "buffer_full_before_enqueue "
                        f"queue_depth={len(self._bufferedDeliveries)} "
                        f"max={maxBufferedMessages}"
                    )
                    logger.debug(
                        "OpNet proxy worker enqueue decision port=%s message_id=%s "
                        "trace_id=%s should_nack=%s reason=%s",
                        portName,
                        messageId,
                        traceId,
                        shouldNack,
                        shouldNackReason,
                    )

            if shouldNack:
                logger.debug(
                    "OpNet proxy worker nacking undeliverable message port=%s "
                    "message_id=%s trace_id=%s reason=%s",
                    portName,
                    messageId,
                    traceId,
                    shouldNackReason or "<none>",
                )
                await self._async_nackSingle(portName=portName, messageId=messageId)
        logger.debug("OpNet proxy worker loop stopped port=%s", portName)

    async def _async_setHasWork(self, *, portName: str, hasWork: bool) -> None:
        async with self._queueCondition:
            if portName not in self._hasWorkByPort:
                return
            currentValue = self._hasWorkByPort[portName]
            if currentValue == hasWork:
                return
            self._hasWorkByPort[portName] = hasWork
            logger.debug(
                "OpNet proxy has_work updated port=%s has_work=%s",
                portName,
                hasWork,
            )

    async def _async_nackSingle(self, *, portName: str, messageId: str) -> None:
        logger.debug(
            "OpNet proxy nack single request port=%s message_id=%s",
            portName,
            messageId,
        )
        try:
            result = await self._nodePlugin.async_nack(
                port_name=portName,
                message_id=messageId,
            )
            logger.debug(
                "OpNet proxy nack single response port=%s message_id=%s ok=%s message=%s",
                portName,
                messageId,
                result.ok,
                result.message or "<none>",
            )
        except Exception as exc:
            logger.debug(
                "OpNet proxy nack single raised port=%s message_id=%s error=%s",
                portName,
                messageId,
                exc,
            )
            return

    async def _async_nackDeliveries(self, deliveries: Sequence[_QueuedDelivery]) -> list[str]:
        logger.debug("OpNet proxy nack queued deliveries count=%d", len(deliveries))
        failures: list[str] = []
        for delivery in deliveries:
            try:
                result = await self._nodePlugin.async_nack(
                    port_name=delivery.portName,
                    message_id=delivery.messageId,
                )
            except Exception as exc:
                failures.append(f"{delivery.portName}:{delivery.messageId}: {exc}")
                continue
            if not result.ok:
                failures.append(
                    f"{delivery.portName}:{delivery.messageId}: {result.message or 'nack failed'}"
                )
        if len(failures) > 0:
            logger.debug(
                "OpNet proxy nack queued deliveries had failures count=%d",
                len(failures),
            )
        return failures

    async def _async_nackAllConsumers(self, *, consumerPorts: Sequence[str]) -> list[str]:
        logger.debug("OpNet proxy nackAll consumers count=%d", len(consumerPorts))
        failures: list[str] = []
        tasks = [
            asyncio.create_task(self._nodePlugin.async_nackAll(port_name=portName))
            for portName in consumerPorts
        ]
        if len(tasks) == 0:
            return failures

        results = await asyncio.gather(*tasks, return_exceptions=True)
        for portName, result in zip(consumerPorts, results):
            if isinstance(result, Exception):
                failures.append(f"{portName}: {result}")
                continue
            if not result.ok:
                failures.append(f"{portName}: {result.message or 'nackAll failed'}")
        if len(failures) > 0:
            logger.debug(
                "OpNet proxy nackAll consumers had failures count=%d",
                len(failures),
            )
        return failures

    async def _async_sleepBackoff(self, *, backoffS: float, stopEvent: asyncio.Event) -> None:
        if backoffS <= 0:
            await asyncio.sleep(0)
            return
        try:
            await asyncio.wait_for(stopEvent.wait(), timeout=backoffS)
        except asyncio.TimeoutError:
            pass

    async def _async_getOrCreateBridgeProducerPort(
        self,
        *,
        portName: str,
        bridgeLinkRef: str,
    ) -> tuple[str, Result]:
        key = (portName, bridgeLinkRef)
        existing = self._bridgeProducerPortsByPortAndLink.get(key)
        if existing is not None:
            logger.debug(
                "OpNet proxy bridge producer cache hit port=%s bridge_link_ref=%s producer_port=%s",
                portName,
                bridgeLinkRef,
                existing,
            )
            return existing, Result(ok=True)

        bridgePortName = self._buildBridgeProducerPortName(
            portName=portName,
            bridgeLinkRef=bridgeLinkRef,
        )
        logger.debug(
            "OpNet proxy bridge producer bind request port=%s bridge_link_ref=%s producer_port=%s",
            portName,
            bridgeLinkRef,
            bridgePortName,
        )
        try:
            bindResult, _ = await self._nodePlugin.async_addProducer(
                link_ref=bridgeLinkRef,
                port_name=bridgePortName,
            )
        except Exception as exc:
            return bridgePortName, Result(
                ok=False,
                message=f"failed to bind bridge producer '{bridgePortName}' to '{bridgeLinkRef}': {exc}",
            )
        if not bindResult.ok:
            return bridgePortName, Result(
                ok=False,
                message=(
                    f"failed to bind bridge producer '{bridgePortName}' to '{bridgeLinkRef}': "
                    f"{bindResult.message or 'unknown error'}"
                ),
            )
        self._bridgeProducerPortsByPortAndLink[key] = bridgePortName
        logger.debug(
            "OpNet proxy bridge producer bound port=%s bridge_link_ref=%s producer_port=%s",
            portName,
            bridgeLinkRef,
            bridgePortName,
        )
        return bridgePortName, Result(ok=True)

    async def _async_publishBridgeEgressLink(
        self,
        *,
        portName: str,
        bridgeLinkRef: str,
        opnetMessage: opnet_types_pb2.OpNetMessage,
    ) -> Optional[str]:
        bridgePortName, bindResult = await self._async_getOrCreateBridgeProducerPort(
            portName=portName,
            bridgeLinkRef=bridgeLinkRef,
        )
        if not bindResult.ok:
            return bindResult.message or f"failed to bind bridge producer for '{bridgeLinkRef}'"
        traceId = (
            opnetMessage.message_context.trace_id
            if opnetMessage.HasField("message_context") and opnetMessage.message_context.trace_id
            else "<none>"
        )
        logger.debug(
            "OpNet proxy bridge publish request port=%s bridge_link_ref=%s producer_port=%s trace_id=%s",
            portName,
            bridgeLinkRef,
            bridgePortName,
            traceId,
        )
        try:
            putResult = await self._nodePlugin.async_putOpNetMessage(
                port_name=bridgePortName,
                opnet_message=opnetMessage,
            )
        except Exception as exc:
            return f"{bridgeLinkRef}: {exc}"
        if not putResult.ok:
            return f"{bridgeLinkRef}: {putResult.message or 'publish failed'}"
        logger.debug(
            "OpNet proxy bridge publish completed port=%s bridge_link_ref=%s producer_port=%s",
            portName,
            bridgeLinkRef,
            bridgePortName,
        )
        return None

    @staticmethod
    def _buildBridgeProducerPortName(*, portName: str, bridgeLinkRef: str) -> str:
        digest = hashlib.sha256(bridgeLinkRef.encode("utf-8")).hexdigest()[:16]
        return f"{portName}__bridge_{digest}"

    @staticmethod
    def _extractBridgeLinks(*, request: operator_pb2.DeliverRequest) -> tuple[str, ...]:
        if not request.HasField("message_context"):
            return ()
        seen: set[str] = set()
        ordered: list[str] = []
        for linkRef in request.message_context.bridge_link_refs:
            cleaned = linkRef.strip()
            if not cleaned or cleaned in seen:
                continue
            seen.add(cleaned)
            ordered.append(cleaned)
        return tuple(ordered)

    def _buildState(
        self,
        *,
        connections: Sequence[opnet_types_pb2.OpNetConnection],
    ) -> _ProxyState:
        if not isinstance(connections, Sequence):
            raise _ConfigValidationError("'connections' must be a sequence of OpNetConnection")

        portToLink: dict[str, str] = {}
        portTypes: dict[str, int] = {}
        for idx, connection in enumerate(connections):
            portName = connection.port_name
            linkRef = connection.link_ref
            if not portName:
                raise _ConfigValidationError(f"connections[{idx}] must include non-empty port_name")
            if not linkRef:
                raise _ConfigValidationError(f"connections[{idx}] must include non-empty link_ref")
            if not self._isSupportedPortType(connection.port_type):
                raise _ConfigValidationError(
                    f"connections[{idx}] has unsupported port_type '{connection.port_type}' for '{portName}'",
                )
            if portName in portToLink:
                existingLink = portToLink[portName]
                raise _ConfigValidationError(
                    f"port '{portName}' is mapped to both '{existingLink}' and '{linkRef}'",
                )
            portToLink[portName] = linkRef
            portTypes[portName] = connection.port_type

        if len(portToLink) == 0:
            raise _ConfigValidationError("'connections' must configure at least one port")

        consumerMaxConcurrency: dict[str, int] = {}
        for portName, value in self._consumerMaxConcurrencyOverrides.items():
            if portName not in portToLink:
                raise _ConfigValidationError(
                    f"consumer_max_concurrency contains unknown port '{portName}'",
                )
            if not self._isConsumerPortType(portTypes[portName]):
                raise _ConfigValidationError(
                    f"consumer_max_concurrency contains non-consumer port '{portName}'",
                )
            consumerMaxConcurrency[portName] = value

        producerPorts = tuple(
            sorted(
                portName
                for portName, portType in portTypes.items()
                if self._isProducerPortType(portType)
            )
        )
        consumerPorts = tuple(
            sorted(
                portName
                for portName, portType in portTypes.items()
                if self._isConsumerPortType(portType)
            )
        )
        for portName in consumerPorts:
            consumerMaxConcurrency.setdefault(portName, self._defaultConsumerMaxConcurrency)

        consumerPortByLink: dict[str, str] = {}
        for portName in consumerPorts:
            linkRef = portToLink[portName]
            existingConsumerPort = consumerPortByLink.get(linkRef)
            if existingConsumerPort is not None:
                raise _ConfigValidationError(
                    f"link '{linkRef}' has multiple consumer ports: {existingConsumerPort}, {portName}",
                )
            consumerPortByLink[linkRef] = portName

        return _ProxyState(
            portToLink=portToLink,
            portTypes=portTypes,
            producerPorts=producerPorts,
            consumerPorts=consumerPorts,
            consumerMaxConcurrency=consumerMaxConcurrency,
            consumerPortByLink=consumerPortByLink,
            maxBufferedMessages=self._maxBufferedMessages,
            consumerWorkerBackoffS=self._consumerWorkerBackoffS,
        )

    @staticmethod
    def _isProducerPortType(portType: int) -> bool:
        return portType in (
            opnet_types_pb2.OpNetPort.PortType.EGRESS,
            opnet_types_pb2.OpNetPort.PortType.EGRESS_BRIDGE,
        )

    @staticmethod
    def _isConsumerPortType(portType: int) -> bool:
        return portType in (
            opnet_types_pb2.OpNetPort.PortType.INGRESS,
            opnet_types_pb2.OpNetPort.PortType.INGRESS_BRIDGE,
        )

    @classmethod
    def _isSupportedPortType(cls, portType: int) -> bool:
        return cls._isProducerPortType(portType) or cls._isConsumerPortType(portType)

    @staticmethod
    def _toOpNetMessage(*, request: operator_pb2.DeliverRequest) -> opnet_types_pb2.OpNetMessage:
        opnetMessage = opnet_types_pb2.OpNetMessage()
        if request.HasField("message_context"):
            opnetMessage.message_context.CopyFrom(request.message_context)
        opnetMessage.payload_type.serialization_format = (
            opnet_types_pb2.OpNetPayloadType.SerializationFormat.PROTO
        )
        if request.payload.type_url:
            opnetMessage.payload_type.type_url = request.payload.type_url
        opnetMessage.payload = request.payload.value
        return opnetMessage

    @staticmethod
    def _toDeliverRequest(
        *,
        portName: str,
        messageId: str,
        opnetMessage: opnet_types_pb2.OpNetMessage,
    ) -> operator_pb2.DeliverRequest:
        deliverRequest = operator_pb2.DeliverRequest(port=portName)
        deliverRequest.message_id = messageId
        if opnetMessage.HasField("message_context"):
            deliverRequest.message_context.CopyFrom(opnetMessage.message_context)
        if opnetMessage.payload_type.type_url:
            deliverRequest.payload.type_url = opnetMessage.payload_type.type_url
        deliverRequest.payload.value = opnetMessage.payload
        return deliverRequest


__all__ = ["PluginBackedOpNetProxy"]
