from __future__ import annotations

import asyncio
import json
import logging
import re
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Optional, Tuple

import requests

logger = logging.getLogger(__name__)

_ACCEPT_MANIFESTS = ",".join(
    [
        "application/vnd.oci.image.manifest.v1+json",
        "application/vnd.docker.distribution.manifest.v2+json",
        "application/vnd.oci.image.index.v1+json",
        "application/vnd.docker.distribution.manifest.list.v2+json",
    ]
)


class OperatorDescriptorError(Exception):
    """Raised when labels or metadata cannot be fetched or parsed."""


@dataclass(frozen=True)
class OperatorDescriptor:
    """
    Descriptor for an operator image.

    name:
      - Logical name of the operator (stable identifier in your flow).

    info:
      - MUST contain key "url" with an OCI image reference like:
        <registry>/<repo>/<image>:<tag>  OR  <registry>/<repo>/<image>@sha256:<digest>
      - Optional: "bearer_token" to force an Authorization header.
      - May also contain "name"; if present it does not need to match `name`.
    """
    name: str
    info: Mapping[str, str]

    def __post_init__(self) -> None:
        url = self.info.get("url")
        if not url:
            raise OperatorDescriptorError('missing required key "url" in info')
        object.__setattr__(self, "_url", url)

    async def async_getLabels(self) -> Dict[str, str]:
        """
        Return all image labels as a dict[str, str].

        Contract:
        - Resolves the image reference (tag or digest), fetches the image manifest,
          then fetches the config blob and returns `config.Labels` (or {} if none).
        - Raises OperatorDescriptorError on auth/IO/parse issues.
        """
        try:
            return await asyncio.to_thread(self._get_labels_sync)
        except Exception as e:  # narrow + rewrap for callers
            raise OperatorDescriptorError(f"failed to read labels: {e}") from e

    async def async_getLumesofOperatorInfo(self) -> Dict[str, Any]:
        """
        Return the JSON-deserialized value of the "lumesof_operator_info" label.

        Contract:
        - Fetches labels via async_getLabels.
        - Parses the "lumesof_operator_info" label as JSON and returns a dict.
        - Raises OperatorDescriptorError if the label is missing or not valid JSON/dict.
        """
        labels = await self.async_getLabels()
        raw = labels.get("lumesof_operator_info")
        if raw is None:
            raise OperatorDescriptorError('label "lumesof_operator_info" not found')
        try:
            value = json.loads(raw)
        except json.JSONDecodeError as e:
            raise OperatorDescriptorError('label "lumesof_operator_info" is not valid JSON') from e
        if not isinstance(value, dict):
            raise OperatorDescriptorError('label "lumesof_operator_info" JSON is not an object')
        return value

    # ----------------------- internal helpers (sync) -----------------------

    def _get_labels_sync(self) -> Dict[str, str]:
        host, repo, reference = self._split_image_ref(self._url)
        host = self._normalize_host(host)
        sess = requests.Session()

        # Pre-auth for Google registries if available
        headers: Dict[str, str] = {"Accept": _ACCEPT_MANIFESTS}
        forced_bearer = self.info.get("bearer_token")
        if forced_bearer:
            headers["Authorization"] = f"Bearer {forced_bearer}"
        elif host.endswith(".pkg.dev") or host.endswith(".gcr.io") or host == "gcr.io":
            token = self._google_bearer_token()
            if token:
                headers["Authorization"] = f"Bearer {token}"

        # 1) Fetch manifest (may be image manifest or index)
        m_url = f"https://{host}/v2/{repo}/manifests/{reference}"
        resp = self._get_with_auth(sess, m_url, headers)
        manifest = resp.json()
        media_type = manifest.get("mediaType", "")

        # 1a) If index/manifest list, pick a candidate (prefer linux/amd64)
        if "manifest.list" in media_type or media_type.endswith(".index.v1+json"):
            desc = self._pick_manifest_descriptor(manifest)
            resp = self._get_with_auth(sess, f"https://{host}/v2/{repo}/manifests/{desc['digest']}", headers)
            manifest = resp.json()

        # 2) Fetch config blob to read labels
        cfg_desc = manifest.get("config") or {}
        cfg_digest = cfg_desc.get("digest")
        if not cfg_digest:
            raise OperatorDescriptorError("manifest has no config digest")

        cfg_url = f"https://{host}/v2/{repo}/blobs/{cfg_digest}"
        cfg_resp = self._get_with_auth(sess, cfg_url, headers)
        cfg_json = cfg_resp.json()

        labels = (cfg_json.get("config") or {}).get("Labels") or {}
        # Ensure we return a plain dict[str, str]
        return {str(k): str(v) for k, v in labels.items()}

    @staticmethod
    def _split_image_ref(ref: str) -> Tuple[str, str, str]:
        """
        Split "<host>/<repo>[/...]/name[:tag|@sha256:digest]" into (host, repo, reference).
        Reference is a tag ("latest" default) or a digest.
        """
        m = re.match(r"^(?P<host>[^/]+)/(?P<path>.+)$", ref)
        if not m:
            raise OperatorDescriptorError(f"invalid image URL: {ref}")
        host = m.group("host")
        path = m.group("path")

        if "@sha256:" in path:
            name, reference = path.split("@", 1)
        else:
            parts = path.rsplit(":", 1)
            name, reference = (parts[0], parts[1]) if len(parts) == 2 else (path, "latest")
        return host, name, reference

    @staticmethod
    def _normalize_host(host: str) -> str:
        # Docker Hub short-hands map to registry-1.docker.io
        if host in {"docker.io", "index.docker.io"}:
            return "registry-1.docker.io"
        return host

    @staticmethod
    def _pick_manifest_descriptor(index_json: Mapping[str, Any]) -> Mapping[str, Any]:
        manifests = index_json.get("manifests") or []
        # Prefer linux/amd64 if present; else first
        for d in manifests:
            plat = d.get("platform") or {}
            if plat.get("os") == "linux" and plat.get("architecture") == "amd64":
                return d
        if not manifests:
            raise OperatorDescriptorError("index has no manifests")
        return manifests[0]

    def _get_with_auth(self, sess: requests.Session, url: str, headers: Mapping[str, str]) -> requests.Response:
        """GET with Bearer challenge handling (Docker Registry v2)."""
        r = sess.get(url, headers=headers)
        if r.status_code != 401:
            r.raise_for_status()
            return r

        www = r.headers.get("Www-Authenticate", "")
        if "Bearer" not in www:
            r.raise_for_status()  # will raise 401
        auth = self._parse_www_authenticate(www)
        token = self._fetch_bearer_token(sess, auth)
        h2 = dict(headers)
        h2["Authorization"] = f"Bearer {token}"
        r2 = sess.get(url, headers=h2)
        r2.raise_for_status()
        return r2

    @staticmethod
    def _parse_www_authenticate(h: str) -> Dict[str, str]:
        # Example: Bearer realm="https://auth.docker.io/token",service="registry.docker.io",scope="repository:library/ubuntu:pull"
        out: Dict[str, str] = {}
        for part in h.split(","):
            if "=" in part:
                k, v = part.split("=", 1)
                k = k.strip().replace("Bearer ", "")
                out[k] = v.strip().strip('"')
        return out

    @staticmethod
    def _fetch_bearer_token(sess: requests.Session, auth: Mapping[str, str]) -> str:
        realm = auth.get("realm")
        if not realm:
            raise OperatorDescriptorError("missing Bearer realm for token fetch")
        params = {}
        for k in ("service", "scope"):
            if k in auth:
                params[k] = auth[k]
        resp = sess.get(realm, params=params)
        resp.raise_for_status()
        data = resp.json()
        token = data.get("token") or data.get("access_token")
        if not token:
            raise OperatorDescriptorError("token endpoint did not return a token")
        return token

    @staticmethod
    def _google_bearer_token() -> Optional[str]:
        """Best-effort: fetch Google ADC bearer for Artifact Registry / gcr.io; None if unavailable."""
        try:
            import google.auth
            from google.auth.transport.requests import Request

            creds, _ = google.auth.default(scopes=["https://www.googleapis.com/auth/cloud-platform.read-only"])
            Request().refresh(creds)
            return creds.token
        except Exception:
            return None
