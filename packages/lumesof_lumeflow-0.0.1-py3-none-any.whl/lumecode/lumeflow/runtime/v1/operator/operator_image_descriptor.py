from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Tuple


_INGRESS_DIRECTION = "ingress"
_EGRESS_DIRECTION = "egress"
_CANONICAL_SHA256_PREFIX = "@sha256:"


@dataclass(frozen=True)
class OperatorPortDescriptor:
    name: str
    direction: str
    serializationFormat: str
    typeUrl: str

    def __post_init__(self) -> None:
        if not isinstance(self.name, str) or not self.name:
            raise ValueError("OperatorPortDescriptor.name must be a non-empty string")
        if self.direction not in (_INGRESS_DIRECTION, _EGRESS_DIRECTION):
            raise ValueError(
                f"OperatorPortDescriptor.direction must be '{_INGRESS_DIRECTION}' or '{_EGRESS_DIRECTION}'"
            )
        if not isinstance(self.serializationFormat, str) or not self.serializationFormat:
            raise ValueError(
                "OperatorPortDescriptor.serializationFormat must be a non-empty string"
            )
        if not isinstance(self.typeUrl, str) or not self.typeUrl:
            raise ValueError("OperatorPortDescriptor.typeUrl must be a non-empty string")


@dataclass(frozen=True)
class OperatorImageDescriptor:
    imageUrl: str
    ports: Tuple[OperatorPortDescriptor, ...] = ()

    def __post_init__(self) -> None:
        if not isinstance(self.imageUrl, str) or not self.imageUrl:
            raise ValueError("OperatorImageDescriptor.imageUrl must be a non-empty string")
        if _CANONICAL_SHA256_PREFIX not in self.imageUrl:
            raise ValueError(
                "OperatorImageDescriptor.imageUrl must be canonical and include '@sha256:<digest>'"
            )
        normalizedPorts = self._normalizePorts(self.ports)
        object.__setattr__(self, "ports", normalizedPorts)

    @staticmethod
    def _normalizePorts(
        rawPorts: Iterable[OperatorPortDescriptor],
    ) -> Tuple[OperatorPortDescriptor, ...]:
        normalized: list[OperatorPortDescriptor] = []
        for port in rawPorts:
            if not isinstance(port, OperatorPortDescriptor):
                raise ValueError(
                    "OperatorImageDescriptor.ports must contain OperatorPortDescriptor values"
                )
            normalized.append(port)
        return tuple(normalized)

