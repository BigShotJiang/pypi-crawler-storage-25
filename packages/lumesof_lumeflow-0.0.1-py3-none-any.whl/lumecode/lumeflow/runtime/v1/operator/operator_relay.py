"""Relay utilities for bridging operator upstream and downstream proxies."""

from __future__ import annotations

import asyncio
import logging

from google.rpc import status_pb2
from grpclib import exceptions as grpclib_exceptions

from lumecode.lumeflow.runtime.v1.operator import operator_pb2
from lumecode.lumeflow.runtime.v1.opnet.opnet_proxy import OpNetDownstream, OpNetUpstream
from lumecode.lumeflow.runtime.v1.opnet.opnet_types_pb2 import Result

LOG = logging.getLogger(__name__)

_STREAM_CLOSED_MARKER = "stream closed"

# Alias names to match external terminology.
OperatorUpstream = OpNetUpstream
OperatorDownstream = OpNetDownstream


class OperatorRelay:
    """Continuously forwards deliveries from an upstream proxy to a downstream proxy."""

    def __init__(
        self,
        upstream: OperatorUpstream,
        downstream: OperatorDownstream,
        *,
        error_backoff: float = 0.1,
        pass_through: bool = False,
    ) -> None:
        self._upstream = upstream
        self._downstream = downstream
        self._error_backoff = error_backoff
        self._running = False
        self._pass_through = pass_through

    def stop(self) -> None:
        """Signal the relay loop to exit."""

        self._running = False

    async def start(self) -> None:
        """Begin relaying messages until `stop` is invoked."""

        self._running = True
        while self._running:
            upstream_result, deliver_request = await self._upstream.async_getOpNetMessage()
            if not upstream_result.ok:
                if not self._running:
                    LOG.debug("Relay is stopped. Dropping failed message: %s", upstream_result.message)
                    break
                message_text = (upstream_result.message or "").lower()
                if _STREAM_CLOSED_MARKER in message_text:
                    LOG.info("Detected upstream stream closure (%s); terminating relay", upstream_result.message)
                    raise grpclib_exceptions.StreamTerminatedError()
                LOG.warning("Upstream delivery failed: %s", upstream_result.message)
                await self._maybe_backoff()
                continue

            downstream_result = await self._downstream.async_putOpNetMessage(deliver_request)
            if not downstream_result.ok:
                LOG.warning("Downstream publish failed: %s", downstream_result.message)
                if not self._pass_through and deliver_request.message_id:
                    ack_request = operator_pb2.AckRequest(
                        port=deliver_request.port,
                        message_id=deliver_request.message_id,
                    )
                    ack_request.error.CopyFrom(self._result_to_status(downstream_result))
                    ack_result = await self._upstream.async_ack(ack_request)
                    if not ack_result.ok:
                        LOG.warning("Upstream ack failed: %s", ack_result.message)
                        await self._maybe_backoff()
                await self._maybe_backoff()
                continue

            if self._pass_through:
                continue

            if deliver_request.message_id:
                ack_request = operator_pb2.AckRequest(
                    port=deliver_request.port,
                    message_id=deliver_request.message_id,
                )
                ack_result = await self._upstream.async_ack(ack_request)
                if not ack_result.ok:
                    LOG.warning("Upstream ack failed: %s", ack_result.message)
                    await self._maybe_backoff()

    async def _maybe_backoff(self) -> None:
        """Sleep for the configured backoff period when needed."""

        if self._error_backoff > 0:
            await asyncio.sleep(self._error_backoff)

    @staticmethod
    def _result_to_status(result: Result) -> status_pb2.Status:
        status = status_pb2.Status(code=13)
        status.message = result.message or "downstream publish failed"
        return status
