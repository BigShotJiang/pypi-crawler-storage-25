"""Operator base utilities for binding event handlers."""

from __future__ import annotations

import asyncio
import contextlib
import contextvars
import inspect
import logging
import os
from typing import Any, Callable, Dict, Mapping, Optional

from google.protobuf import message_factory, symbol_database, text_format
from google.protobuf.any_pb2 import Any as AnyMessage
from google.protobuf.message import Message
from grpclib import exceptions as grpclib_exceptions
from grpclib.client import Channel, Stream
from google.rpc import status_pb2

from lumecode.lumeflow.runtime.v1.operator import operator_grpc, operator_pb2
from lumecode.lumeflow.runtime.v1.operator.operator_relay import (
    OperatorDownstream,
    OperatorRelay,
    OperatorUpstream,
)
from lumecode.lumeflow.runtime.v1.opnet.opnet_types_pb2 import (
    MessageContext,
    OpNetPayloadType,
    Result,
)

LOG = logging.getLogger(__name__)

_OPERATOR_CONNECT_MAX_ATTEMPTS_ENV = "LUMEFLOW_OPERATOR_CONNECT_MAX_ATTEMPTS"
_OPERATOR_CONNECT_BACKOFF_MS_ENV = "LUMEFLOW_OPERATOR_CONNECT_BACKOFF_MS"
_DEFAULT_OPERATOR_CONNECT_MAX_ATTEMPTS = 60
_DEFAULT_OPERATOR_CONNECT_BACKOFF_MS = 500
_OPERATOR_CONNECT_ATTEMPT_TIMEOUT_SECONDS = 5.0
_OPERATOR_PORTS_ATTR = "__lumesof_operator_ports__"
_OPERATOR_PORTS_SCHEMA_VERSION = 1
_OPERATOR_PORTS_REQUIRED_KEYS = frozenset({"ingress", "egress"})
_OPERATOR_PORT_SPEC_REQUIRED_KEYS = frozenset({"name", "serialization_format", "type_url"})
_SERIALIZATION_FORMAT_PROTO = int(OpNetPayloadType.PROTO)
_SERIALIZATION_FORMAT_NAME_BY_VALUE = {
    _SERIALIZATION_FORMAT_PROTO: "PROTO",
}

try:  # Prefer the explicitly named OperatorSidecarStub when available.
    OperatorSidecarStubType = operator_grpc.OperatorSidecarStub
except AttributeError:  # pragma: no cover - fallback for generated name
    OperatorSidecarStubType = operator_grpc.OperatorStub  # type: ignore[attr-defined]


def operator_ports(
    ports: Mapping[str, Any],
) -> Callable[[type["Operator"]], type["Operator"]]:
    """Declare the operator ingress/egress contract on an Operator subclass."""

    def decorator(cls: type["Operator"]) -> type["Operator"]:
        if not issubclass(cls, Operator):
            raise TypeError("@operator_ports can only decorate Operator subclasses")
        normalizedContract = cls._normalizeOperatorPorts(ports=ports)
        setattr(cls, _OPERATOR_PORTS_ATTR, normalizedContract)
        cls._validateOperatorPortContract()
        return cls

    return decorator


class Operator:
    """Base class for runtime operators with event-bound handlers."""

    _CANONICAL_ANY_TYPE_PREFIX = "type.googleapis.com/"
    _ON_ATTR = "__lumesof_on__"
    _SYMBOL_DB = symbol_database.Default()
    _MESSAGE_FACTORY = message_factory.MessageFactory()
    _MESSAGE_CONTEXT_VAR: contextvars.ContextVar[Optional[MessageContext]] = contextvars.ContextVar(
        "lumeflow_operator_message_context",
        default=None,
    )

    def __init__(self) -> None:
        self._channel: Optional[Channel] = None
        self._sidecar_stub: Optional[OperatorSidecarStubType] = None
        self._publish_upstream: Optional[Operator._PublishUpstream] = None
        self._publish_relay: Optional[OperatorRelay] = None
        self._publish_relay_task: Optional[asyncio.Task[None]] = None
        self._publish_response_relay: Optional[Operator._PublishResponseRelay] = None
        self._publish_response_task: Optional[asyncio.Task[None]] = None
        self._deliver_upstream: Optional[Operator._DeliverStreamUpstream] = None
        self._relay: Optional[OperatorRelay] = None
        self._stream_task: Optional[asyncio.Task[None]] = None
        self._deliver_stop: Optional[asyncio.Event] = None
        self._stream_ready = asyncio.Event()
        self._publish_started = asyncio.Event()
        self._on_start_task: Optional[asyncio.Task[None]] = None
        self.__class__._requireOperatorPortContract()

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        handlers: Dict[str, str] = {}
        handler_is_async: Dict[str, bool] = {}
        for name, member in cls.__dict__.items():
            metadata = getattr(member, cls._ON_ATTR, None)
            if metadata is None:
                continue
            input_port = metadata["input_port"]
            if input_port in handlers:
                raise ValueError(f"duplicate handler registered for input port '{input_port}'")
            handlers[input_port] = name
            handler_is_async[input_port] = metadata.get("is_async", False)
        cls._handlers = handlers
        cls._handler_is_async = handler_is_async

    @classmethod
    def _emptyPortContract(cls) -> dict[str, Any]:
        return {
            "schema_version": _OPERATOR_PORTS_SCHEMA_VERSION,
            "ingress": {},
            "egress": {},
        }

    @classmethod
    def _requireOperatorPortContract(cls) -> None:
        if cls is Operator:
            return
        if not hasattr(cls, _OPERATOR_PORTS_ATTR):
            raise TypeError(
                f"Operator subclass '{cls.__name__}' must be decorated with @operator_ports(...)"
            )

    @classmethod
    def _operatorPortContract(cls) -> dict[str, Any]:
        if cls is Operator:
            return cls._emptyPortContract()
        cls._requireOperatorPortContract()
        return getattr(cls, _OPERATOR_PORTS_ATTR)

    @classmethod
    def _normalizeOperatorPorts(
        cls,
        *,
        ports: Mapping[str, Any],
    ) -> dict[str, Any]:
        if not isinstance(ports, Mapping):
            raise TypeError("@operator_ports(...) requires a mapping with ingress/egress keys")
        extraKeys = sorted(key for key in ports.keys() if key not in _OPERATOR_PORTS_REQUIRED_KEYS)
        missingKeys = sorted(key for key in _OPERATOR_PORTS_REQUIRED_KEYS if key not in ports)
        if extraKeys or missingKeys:
            raise TypeError(
                "@operator_ports(...) requires exactly {'ingress', 'egress'} keys; "
                f"missing={missingKeys} extra={extraKeys}"
            )

        ingress = cls._normalizePortSection(sectionName="ingress", rawPorts=ports["ingress"])
        egress = cls._normalizePortSection(sectionName="egress", rawPorts=ports["egress"])

        return {
            "schema_version": _OPERATOR_PORTS_SCHEMA_VERSION,
            "ingress": ingress,
            "egress": egress,
        }

    @classmethod
    def _normalizePortSection(
        cls,
        *,
        sectionName: str,
        rawPorts: Any,
    ) -> Dict[str, dict[str, Any]]:
        if not isinstance(rawPorts, list):
            raise TypeError(f"@operator_ports(...).{sectionName} must be a list")

        portsByName: Dict[str, dict[str, Any]] = {}
        for index, rawPort in enumerate(rawPorts):
            portSpec = cls._normalizePortSpec(
                sectionName=sectionName,
                index=index,
                rawPort=rawPort,
            )
            portName = portSpec["name"]
            if portName in portsByName:
                raise ValueError(
                    f"@operator_ports(...).{sectionName} has duplicate port '{portName}'"
                )
            portsByName[portName] = portSpec
        return portsByName

    @classmethod
    def _normalizePortSpec(
        cls,
        *,
        sectionName: str,
        index: int,
        rawPort: Any,
    ) -> dict[str, Any]:
        if not isinstance(rawPort, Mapping):
            raise TypeError(
                f"@operator_ports(...).{sectionName}[{index}] must be an object"
            )
        extraKeys = sorted(key for key in rawPort.keys() if key not in _OPERATOR_PORT_SPEC_REQUIRED_KEYS)
        missingKeys = sorted(key for key in _OPERATOR_PORT_SPEC_REQUIRED_KEYS if key not in rawPort)
        if extraKeys or missingKeys:
            raise TypeError(
                f"@operator_ports(...).{sectionName}[{index}] requires exactly "
                f"{sorted(_OPERATOR_PORT_SPEC_REQUIRED_KEYS)}; missing={missingKeys} extra={extraKeys}"
            )

        name = rawPort["name"]
        if not isinstance(name, str) or not name:
            raise TypeError(
                f"@operator_ports(...).{sectionName}[{index}].name must be a non-empty string"
            )

        serializationFormat = cls._normalizeSerializationFormat(
            sectionName=sectionName,
            index=index,
            value=rawPort["serialization_format"],
        )
        if serializationFormat != _SERIALIZATION_FORMAT_PROTO:
            formatName = _SERIALIZATION_FORMAT_NAME_BY_VALUE.get(
                serializationFormat,
                str(serializationFormat),
            )
            raise TypeError(
                f"@operator_ports(...).{sectionName}[{index}] has unsupported serialization_format "
                f"'{formatName}'; only PROTO is currently supported"
            )

        typeUrl = rawPort["type_url"]
        if not isinstance(typeUrl, str) or not typeUrl:
            raise TypeError(
                f"@operator_ports(...).{sectionName}[{index}].type_url must be a non-empty string"
            )
        canonicalTypeUrl = cls._canonicalizeTypeUrl(typeUrl)
        if not canonicalTypeUrl:
            raise TypeError(
                f"@operator_ports(...).{sectionName}[{index}].type_url must resolve to a canonical proto type URL"
            )

        return {
            "name": name,
            "serialization_format": serializationFormat,
            "serialization_format_name": _SERIALIZATION_FORMAT_NAME_BY_VALUE[serializationFormat],
            "type_url": canonicalTypeUrl,
        }

    @classmethod
    def _normalizeSerializationFormat(
        cls,
        *,
        sectionName: str,
        index: int,
        value: Any,
    ) -> int:
        if isinstance(value, bool):
            raise TypeError(
                f"@operator_ports(...).{sectionName}[{index}].serialization_format must be an enum value"
            )
        if isinstance(value, str):
            strippedValue = value.strip()
            if strippedValue == "PROTO" or strippedValue.endswith(".PROTO"):
                return _SERIALIZATION_FORMAT_PROTO
            raise TypeError(
                f"@operator_ports(...).{sectionName}[{index}].serialization_format='{value}' is unsupported"
            )
        if isinstance(value, int):
            return int(value)
        raise TypeError(
            f"@operator_ports(...).{sectionName}[{index}].serialization_format must be an enum value"
        )

    @classmethod
    def _validateOperatorPortContract(cls) -> None:
        contract = cls._operatorPortContract()
        ingressByName: Dict[str, dict[str, Any]] = contract["ingress"]
        handlers = getattr(cls, "_handlers", {})

        for inputPort in handlers:
            ingressSpec = ingressByName.get(inputPort)
            if ingressSpec is None:
                raise ValueError(
                    f"Operator subclass '{cls.__name__}' registers handler port '{inputPort}' via "
                    f"Operator.on_ingress but @operator_ports ingress does not declare it"
                )

        for ingressPort in ingressByName:
            if ingressPort not in handlers:
                raise ValueError(
                    f"Operator subclass '{cls.__name__}' declares ingress port '{ingressPort}' in "
                    f"@operator_ports but has no Operator.on_ingress handler for it"
                )

    @classmethod
    def on_ingress(
        cls,
        input_port: str,
    ) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        """Decorator to mark a method as the handler for an input port."""

        def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
            return cls._markHandler(func, input_port=input_port)

        return decorator

    @classmethod
    def _markHandler(
        cls,
        func: Callable[..., Any],
        *,
        input_port: str,
    ) -> Callable[..., Any]:
        if not isinstance(input_port, str) or not input_port:
            raise TypeError("Operator.on_ingress requires a non-empty string input port name")

        sig = inspect.signature(func)
        params = list(sig.parameters.values())

        if len(params) < 3:
            raise TypeError(
                "Operator handler '{name}' must accept (self, input_port, message) parameters".format(
                    name=func.__name__
                )
            )

        input_port_param = params[1]
        message_param = params[2]
        allowed_kinds = {
            inspect.Parameter.KEYWORD_ONLY,
        }

        if input_port_param.kind not in allowed_kinds or input_port_param.name != "input_port":
            raise TypeError(
                "Operator handler '{name}' must define an 'input_port' keyword-only parameter".format(
                    name=func.__name__
                )
            )

        if message_param.kind not in allowed_kinds or message_param.name != "message":
            raise TypeError(
                "Operator handler '{name}' must define a 'message' keyword-only parameter".format(
                    name=func.__name__
                )
            )

        trailing_params = params[3:]
        if trailing_params:
            raise TypeError(
                "Operator handler '{name}' must only define (self, *, input_port, message)".format(
                    name=func.__name__
                )
            )

        setattr(
            func,
            cls._ON_ATTR,
            {
                "input_port": input_port,
                "is_async": inspect.iscoroutinefunction(func),
            },
        )
        return func

    def handlers(self) -> Mapping[str, Callable[..., Any]]:
        """Return the bound handlers keyed by input port for this operator instance."""

        bound: Dict[str, Callable[..., Any]] = {}
        for input_port, attr_name in getattr(self.__class__, "_handlers", {}).items():
            bound[input_port] = getattr(self, attr_name)
        return bound

    def dispatch(
        self,
        *,
        input_port: str,
        message: Message,
    ) -> Any:
        """Invoke the handler associated with `input_port` using a protobuf `message`.
        """

        if not isinstance(input_port, str) or not input_port:
            raise TypeError("Operator.dispatch requires a non-empty string input port name")

        if not isinstance(message, Message):
            raise TypeError("Operator.dispatch requires a protobuf Message instance")

        handler = self.handlers().get(input_port)
        if handler is None:
            formatted_message = text_format.MessageToString(message, as_one_line=True).strip()
            if not formatted_message:
                formatted_message = "<empty>"
            LOG.warning(
                "No handler registered for input_port '%s' (type=%s, message=%s)",
                input_port,
                message.DESCRIPTOR.full_name,
                formatted_message,
            )
            return Result(ok=False, message=f"handler for input_port '{input_port}' not found")

        LOG.debug(
            f"Dispatching message for input_port='{input_port}' "
            f"(type={message.DESCRIPTOR.full_name})"
        )

        result = handler(input_port=input_port, message=message)

        if inspect.isawaitable(result):
            return result
        return result

    async def async_connect(self, uri: str) -> None:
        """Asynchronously connect to the OperatorSidecar service and cache channel + stub.

        Supports TCP ("tcp://host:port") and Unix domain sockets ("unix:///path").
        """

        if not isinstance(uri, str) or not uri:
            raise TypeError("Operator.connect requires a non-empty string uri")

        maxAttempts, backoffMs = self._resolveConnectRetrySettings()
        backoffSeconds = backoffMs / 1000.0
        LOG.info(
            "Connecting to OperatorSidecar at %s with max_attempts=%d backoff_ms=%d",
            uri,
            maxAttempts,
            backoffMs,
        )

        await self._async_shutdownStream()

        for attempt in range(1, maxAttempts + 1):
            try:
                await self._async_connectOnce(uri)
                if attempt > 1:
                    LOG.info(
                        "Operator connected after retry uri=%s attempt=%d/%d",
                        uri,
                        attempt,
                        maxAttempts,
                    )
                return
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                await self._async_shutdownStream()
                if isinstance(exc, ValueError):
                    raise
                if attempt < maxAttempts:
                    LOG.warning(
                        "Operator connect attempt failed uri=%s attempt=%d/%d error=%s; retrying in %.3fs",
                        uri,
                        attempt,
                        maxAttempts,
                        f"{type(exc).__name__}: {exc}",
                        backoffSeconds,
                    )
                    if backoffSeconds > 0:
                        await asyncio.sleep(backoffSeconds)
                    continue
                LOG.critical(
                    "Operator connect failed uri=%s attempts=%d error=%s",
                    uri,
                    maxAttempts,
                    f"{type(exc).__name__}: {exc}",
                    exc_info=True,
                )
                raise

    def _resolveConnectRetrySettings(self) -> tuple[int, int]:
        maxAttempts = _DEFAULT_OPERATOR_CONNECT_MAX_ATTEMPTS
        maxAttemptsRaw = os.environ.get(_OPERATOR_CONNECT_MAX_ATTEMPTS_ENV, "").strip()
        if maxAttemptsRaw:
            try:
                parsedMaxAttempts = int(maxAttemptsRaw)
                if parsedMaxAttempts >= 1:
                    maxAttempts = parsedMaxAttempts
                else:
                    LOG.warning(
                        "Ignoring %s=%r because it must be >= 1; using default=%d",
                        _OPERATOR_CONNECT_MAX_ATTEMPTS_ENV,
                        maxAttemptsRaw,
                        _DEFAULT_OPERATOR_CONNECT_MAX_ATTEMPTS,
                    )
            except ValueError:
                LOG.warning(
                    "Ignoring %s=%r because it is not an integer; using default=%d",
                    _OPERATOR_CONNECT_MAX_ATTEMPTS_ENV,
                    maxAttemptsRaw,
                    _DEFAULT_OPERATOR_CONNECT_MAX_ATTEMPTS,
                )

        backoffMs = _DEFAULT_OPERATOR_CONNECT_BACKOFF_MS
        backoffMsRaw = os.environ.get(_OPERATOR_CONNECT_BACKOFF_MS_ENV, "").strip()
        if backoffMsRaw:
            try:
                parsedBackoffMs = int(backoffMsRaw)
                if parsedBackoffMs >= 0:
                    backoffMs = parsedBackoffMs
                else:
                    LOG.warning(
                        "Ignoring %s=%r because it must be >= 0; using default=%d",
                        _OPERATOR_CONNECT_BACKOFF_MS_ENV,
                        backoffMsRaw,
                        _DEFAULT_OPERATOR_CONNECT_BACKOFF_MS,
                    )
            except ValueError:
                LOG.warning(
                    "Ignoring %s=%r because it is not an integer; using default=%d",
                    _OPERATOR_CONNECT_BACKOFF_MS_ENV,
                    backoffMsRaw,
                    _DEFAULT_OPERATOR_CONNECT_BACKOFF_MS,
                )
        return maxAttempts, backoffMs

    async def _async_connectOnce(self, uri: str) -> None:
        channel: Channel
        if uri.startswith("unix:///"):
            uds_path = uri[len("unix:///") :]
            if not uds_path:
                raise ValueError("unix uri must provide a socket path")
            channel = Channel(path=uds_path)
        elif uri.startswith("tcp://"):
            rest = uri[len("tcp://") :]
            host, sep, port_str = rest.rpartition(":")
            if not sep or not host or not port_str:
                raise ValueError("tcp uri must be in the form tcp://host:port")
            try:
                port = int(port_str)
            except ValueError as exc:
                raise ValueError("tcp uri must include a valid integer port") from exc
            channel = Channel(host, port)
        else:
            raise ValueError("unsupported uri scheme (expected tcp:// or unix:///)")

        self._channel = channel
        self._sidecar_stub = OperatorSidecarStubType(channel)

        self._deliver_stop = asyncio.Event()
        self._publish_upstream = self._PublishUpstream()
        self._stream_ready = asyncio.Event()
        self._stream_task = asyncio.create_task(self._async_streamWorker())
        await self._async_waitForStreamReady(
            timeoutSeconds=_OPERATOR_CONNECT_ATTEMPT_TIMEOUT_SECONDS
        )
        LOG.info(f"Operator publish stream established for {uri}")
        self._invokeOnStart()

    async def _async_waitForStreamReady(self, *, timeoutSeconds: float) -> None:
        if self._stream_task is None:
            raise RuntimeError("Operator stream worker was not started")

        streamTask = self._stream_task
        readyTask = asyncio.create_task(self._stream_ready.wait())
        try:
            done, _ = await asyncio.wait(
                {readyTask, streamTask},
                timeout=timeoutSeconds,
                return_when=asyncio.FIRST_COMPLETED,
            )
            if readyTask in done and self._stream_ready.is_set():
                return

            if streamTask in done:
                if streamTask.cancelled():
                    raise RuntimeError("Operator stream worker exited before stream was ready")
                streamError = streamTask.exception()
                if streamError is not None:
                    raise RuntimeError("Operator stream worker failed before stream was ready") from streamError
                raise RuntimeError("Operator stream worker exited before stream was ready")

            raise RuntimeError("Operator failed to establish publish stream")
        finally:
            if not readyTask.done():
                readyTask.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await readyTask

    async def async_runUntilStopped(self, uri: str) -> None:
        """Connect to the sidecar and block until the operator stream terminates."""

        try:
            await self.async_connect(uri)
            LOG.info(f"{self.__class__.__name__} connected to {uri}")
            await self.async_waitUntilTerminated()
        except grpclib_exceptions.StreamTerminatedError:
            LOG.info(f"{self.__class__.__name__} connection lost; shutting down.")
        finally:
            with contextlib.suppress(Exception):
                await self.async_shutdown()

    async def async_onStart(self) -> None:
        """Hook invoked once the Operator finishes connecting to the sidecar."""
        LOG.debug("Operator started")
        return None

    def _invokeOnStart(self) -> None:
        try:
            result = self.async_onStart()
        except Exception:  # pragma: no cover - allow subclasses to raise synchronously
            LOG.exception("Operator.onStart raised an error")
            return

        if inspect.isawaitable(result):
            loop = asyncio.get_running_loop()

            async def _async_awaitOnStart(task_result) -> None:
                try:
                    await task_result
                except asyncio.CancelledError:  # pragma: no cover - cooperative shutdown
                    raise
                except Exception:
                    LOG.exception("Operator.onStart coroutine failed")
                finally:
                    current = asyncio.current_task()
                    if current is self._on_start_task:
                        self._on_start_task = None

            self._on_start_task = loop.create_task(_async_awaitOnStart(result))
        else:
            self._on_start_task = None

    async def async_emit(
        self,
        *,
        output_port: str,
        message_context: Optional[MessageContext] = None,
        message: Message,
    ) -> None:
        """Publish `message` on the given `output_port` via the sidecar.

        Args:
            output_port: Logical port name that the message should be published to.
            message_context: Optional message context propagated with the delivery.
            message: Protobuf payload to forward to the OperatorSidecar.
        """

        if not isinstance(output_port, str) or not output_port:
            raise TypeError("Operator.async_emit requires a non-empty string output port name")

        if not isinstance(message, Message):
            raise TypeError("Operator.async_emit requires a protobuf Message instance")

        if message_context is not None and not isinstance(message_context, MessageContext):
            raise TypeError("Operator.async_emit requires `message_context` to be MessageContext when provided")

        if self._sidecar_stub is None:
            raise RuntimeError("Operator is not connected; call async_connect() before async_emit()")

        if self._publish_upstream is None or self._publish_relay is None or self._deliver_stop is None:
            raise RuntimeError("Operator publish stream is not initialized")

        if not self._stream_ready.is_set():
            raise RuntimeError("Operator publish stream is not ready")

        egressPorts = self.__class__._operatorPortContract()["egress"]
        egressSpec = egressPorts.get(output_port)
        if egressSpec is None:
            raise ValueError(
                f"Operator subclass '{self.__class__.__name__}' cannot publish to undeclared "
                f"egress port '{output_port}'"
            )
        if egressSpec["serialization_format"] != _SERIALIZATION_FORMAT_PROTO:
            raise ValueError(
                f"Operator subclass '{self.__class__.__name__}' cannot publish on egress port "
                f"'{output_port}' because serialization_format='{egressSpec['serialization_format_name']}' "
                "is unsupported"
            )
        canonicalMessageTypeUrl = self._canonicalizeTypeUrl(message.DESCRIPTOR.full_name)
        if canonicalMessageTypeUrl != egressSpec["type_url"]:
            raise ValueError(
                f"Operator subclass '{self.__class__.__name__}' cannot publish protobuf type "
                f"'{canonicalMessageTypeUrl}' to egress port '{output_port}' "
                f"(declared type_url='{egressSpec['type_url']}')"
            )

        payload = AnyMessage()
        payload.Pack(message)

        publish_request = operator_pb2.DeliverRequest(port=output_port, payload=payload)
        resolvedMessageContext = (
            message_context
            if message_context is not None
            else self.currentMessageContext()
        )
        if resolvedMessageContext is not None:
            publish_request.message_context.CopyFrom(resolvedMessageContext)

        traceId = (
            resolvedMessageContext.trace_id
            if resolvedMessageContext is not None and resolvedMessageContext.trace_id
            else "<none>"
        )
        LOG.info(
            f"Publishing message on output_port='{output_port}' "
            f"type='{message.DESCRIPTOR.full_name}' trace_id='{traceId}'"
        )

        if self._deliver_stop.is_set():
            raise RuntimeError("Operator publish stream is closed")

        await self._publish_upstream.async_put(publish_request)

    @classmethod
    def currentMessageContext(cls) -> Optional[MessageContext]:
        """Return the current request-scoped MessageContext, if one is active."""

        return cls._MESSAGE_CONTEXT_VAR.get()

    async def async_waitUntilTerminated(self) -> None:
        """Wait until the operator's publish stream has terminated."""

        stream_task = self._stream_task
        deliver_stop = self._deliver_stop

        if stream_task is None and deliver_stop is None:
            raise RuntimeError("Operator.async_waitUntilTerminated requires an active connection")

        waiters = []
        if stream_task is not None:
            waiters.append(stream_task)

        deliver_stop_task: Optional[asyncio.Task[None]] = None
        if deliver_stop is not None:
            deliver_stop_task = asyncio.create_task(deliver_stop.wait())
            waiters.append(deliver_stop_task)

        done, pending = await asyncio.wait(waiters, return_when=asyncio.FIRST_COMPLETED)

        for future in pending:
            if future is stream_task:
                continue
            future.cancel()

        for future in pending:
            if future is stream_task:
                continue
            with contextlib.suppress(asyncio.CancelledError):
                await future

        for future in done:
            if future is deliver_stop_task:
                continue
            if future.cancelled():
                continue
            exc = future.exception()
            if exc is None or isinstance(exc, asyncio.CancelledError):
                continue
            raise exc

    async def async_shutdown(self) -> None:
        """Terminate the operator's publish stream and close any active connections."""
        LOG.debug("Operator shutdown")
        await self._async_shutdownStream()

    async def _async_shutdownStream(self) -> None:
        if self._deliver_stop is not None:
            self._deliver_stop.set()

        self._publish_started.set()

        self._signalQueueShutdown()

        if self._publish_upstream is not None:
            self._publish_upstream.close()
        if self._publish_relay is not None:
            self._publish_relay.stop()
        if self._publish_response_relay is not None:
            self._publish_response_relay.stop()
        if self._publish_relay_task is not None:
            try:
                await asyncio.wait_for(self._publish_relay_task, timeout=5)
            except asyncio.TimeoutError:
                self._publish_relay_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await self._publish_relay_task
            finally:
                self._publish_relay_task = None
        if self._publish_response_task is not None:
            try:
                await asyncio.wait_for(self._publish_response_task, timeout=5)
            except asyncio.TimeoutError:
                self._publish_response_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await self._publish_response_task
            except asyncio.CancelledError:
                # The async stream worker cancels this task during teardown.
                pass
            finally:
                self._publish_response_task = None
        if self._stream_task is not None:
            try:
                await asyncio.wait_for(self._stream_task, timeout=5)
            except asyncio.TimeoutError:
                self._stream_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await self._stream_task
            except grpclib_exceptions.ProtocolError:
                # Stream teardown can race with half-close and surface protocol errors.
                pass
            except asyncio.CancelledError:
                # Cancellation is expected when shutdown races with stream teardown.
                pass
            finally:
                self._stream_task = None
        if self._on_start_task is not None:
            if not self._on_start_task.done():
                self._on_start_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await self._on_start_task
            self._on_start_task = None

        if self._channel is not None:
            with contextlib.suppress(Exception):
                self._channel.close()
            self._channel = None
        self._sidecar_stub = None
        self._deliver_stop = None
        self._relay = None
        self._publish_relay = None
        self._publish_response_relay = None
        self._deliver_upstream = None
        self._publish_upstream = None
        self._stream_ready = asyncio.Event()
        self._publish_started = asyncio.Event()

    def _signalQueueShutdown(self) -> None:
        if self._publish_upstream is not None:
            self._publish_upstream.close()
        if self._deliver_upstream is not None:
            self._deliver_upstream.close()

    class _DispatchDownstream(OperatorDownstream):
        """Relay downstream that hands delivered messages to operator dispatch."""

        def __init__(self, operator: "Operator") -> None:
            self._operator = operator

        async def async_putOpNetMessage(self, request: operator_pb2.DeliverRequest) -> Result:
            """Forward a sidecar delivery request into operator handler dispatch."""
            return await self._operator._async_processDeliverRequest(request)

    class _PublishUpstream(OperatorUpstream):
        """In-memory upstream queue backing the sidecar Publish stream.

        ``async_emit`` enqueues ``DeliverRequest`` payloads here. The publish
        relay consumes this queue via ``async_getOpNetMessage`` and writes each
        request onto the gRPC publish stream.
        """

        def __init__(self) -> None:
            self._queue: asyncio.Queue[Optional[operator_pb2.DeliverRequest]] = asyncio.Queue()
            self._closed = False

        async def async_getOpNetMessage(self) -> tuple[Result, operator_pb2.DeliverRequest]:
            """Return next publish request for relay consumption.

            Returns ``Result(ok=False)`` when the publish queue has been closed,
            which signals the relay loop to stop.
            """
            if self._closed:
                return Result(ok=False, message="publish stream closed"), operator_pb2.DeliverRequest()
            request = await self._queue.get()
            if request is None:
                self._closed = True
                return Result(ok=False, message="publish stream closed"), operator_pb2.DeliverRequest()
            return Result(ok=True), request

        async def async_ack(self, request: operator_pb2.AckRequest) -> Result:
            """No-op for publish upstream; acks are handled on the deliver stream."""
            return Result(ok=True)

        async def async_reset(self, reset_id: str) -> Result:
            """No-op reset hook to satisfy the ``OperatorUpstream`` contract."""
            return Result(ok=True)

        async def async_put(self, request: operator_pb2.DeliverRequest) -> None:
            """Queue a publish request generated by ``async_emit``."""
            if not self._closed:
                await self._queue.put(request)

        def close(self) -> None:
            """Close queue and wake relay consumers with sentinel shutdown message."""
            if not self._closed:
                self._closed = True
                with contextlib.suppress(asyncio.QueueFull):
                    self._queue.put_nowait(None)

    class _StreamDownstream(OperatorDownstream):
        """Downstream writer that sends queued publish messages to sidecar stream."""

        def __init__(
            self,
            operator: "Operator",
            stream: Stream[operator_pb2.DeliverRequest, operator_pb2.PublishResponse],
        ) -> None:
            self._operator = operator
            self._stream = stream

        async def async_putOpNetMessage(self, request: operator_pb2.DeliverRequest) -> Result:
            """Write one publish request onto the gRPC Publish stream."""
            await self._stream.send_message(request)
            if not self._operator._publish_started.is_set():
                self._operator._publish_started.set()
            return Result(ok=True)

    class _DeliverStreamUpstream(OperatorUpstream):
        """Upstream reader for sidecar-delivered input messages.

        This adapter reads ``DeliverRequest`` payloads from the sidecar Ack
        stream and forwards them into the operator dispatch relay.
        """

        def __init__(
            self,
            operator: "Operator",
            stream: Stream[operator_pb2.AckRequest, operator_pb2.DeliverRequest],
        ) -> None:
            self._operator = operator
            self._stream = stream
            self._closed = False

        async def async_getOpNetMessage(self) -> tuple[Result, operator_pb2.DeliverRequest]:
            """Read next sidecar delivery request from the Ack stream."""
            if self._closed:
                return Result(ok=False, message="deliver stream closed"), operator_pb2.DeliverRequest()
            message = await self._stream.recv_message()
            if message is None:
                self._closed = True
                if self._operator._deliver_stop is not None:
                    self._operator._deliver_stop.set()
                return Result(ok=False, message="deliver stream closed"), operator_pb2.DeliverRequest()
            return Result(ok=True), message

        async def async_ack(self, request: operator_pb2.AckRequest) -> Result:
            """Send delivery acknowledgement back to sidecar for ``message_id``."""
            if self._closed or not request.message_id:
                return Result(ok=True)
            try:
                await self._stream.send_message(request)
            except Exception as exc:  # pragma: no cover - network failures
                return Result(ok=False, message=str(exc))
            return Result(ok=True)

        async def async_reset(self, reset_id: str) -> Result:
            """No-op reset hook to satisfy the ``OperatorUpstream`` contract."""
            return Result(ok=True)

        def close(self) -> None:
            """Mark deliver stream adapter as closed."""
            self._closed = True

    class _PublishResponseRelay:
        """Background reader for sidecar publish responses.

        Sidecar may return non-zero status values for failed publishes. These
        responses are surfaced through ``Operator.onPublishError``.
        """

        def __init__(
            self,
            operator: "Operator",
            stream: Stream[operator_pb2.DeliverRequest, operator_pb2.PublishResponse],
        ) -> None:
            self._operator = operator
            self._stream = stream
            self._running = False

        def stop(self) -> None:
            self._running = False

        async def async_start(self) -> None:
            """Continuously read publish responses and route errors to callbacks."""
            self._running = True
            if not self._operator._publish_started.is_set():
                await self._operator._publish_started.wait()
            if not self._running:
                return
            while self._running:
                response = await self._stream.recv_message()
                if response is None:
                    break
                self._operator._handlePublishResponse(response)

    async def _async_streamWorker(self) -> None:
        """Main stream worker that coordinates publish + deliver relay loops.

        Flow:
        1. Opens ``Publish`` and ``Ack`` bidirectional streams.
        2. Sends initial ack handshake so sidecar can start delivery.
        3. Starts three relay tasks:
           - deliver relay (Ack stream -> operator dispatch),
           - publish relay (emit queue -> Publish stream),
           - publish-response relay (Publish responses -> onPublishError).
        """
        if (
            self._sidecar_stub is None
            or self._publish_upstream is None
            or self._deliver_stop is None
        ):
            self._stream_ready.set()
            return

        publish_stream = None
        ack_stream = None
        tasks: list[asyncio.Task[None]] = []
        try:
            async with contextlib.AsyncExitStack() as exit_stack:
                publish_stream = await self._async_openStream(exit_stack, "Publish")
                ack_stream = await self._async_openStream(exit_stack, "Ack")

                send_initial_metadata = getattr(publish_stream, "send_initial_metadata", None)
                if callable(send_initial_metadata):
                    with contextlib.suppress(Exception):
                        await send_initial_metadata()

                ack_send_initial = getattr(ack_stream, "send_initial_metadata", None)
                if callable(ack_send_initial):
                    with contextlib.suppress(Exception):
                        await ack_send_initial()

                # Send an initial handshake on the ack stream so the sidecar
                # is permitted to start delivering messages immediately.
                try:
                    await ack_stream.send_message(operator_pb2.AckRequest(message_id=""))
                except Exception:
                    LOG.debug("Initial Ack handshake failed", exc_info=True)
                    return

                self._deliver_upstream = self._DeliverStreamUpstream(self, ack_stream)

                deliver_relay = OperatorRelay(self._deliver_upstream, self._DispatchDownstream(self))
                publish_relay = OperatorRelay(self._publish_upstream, self._StreamDownstream(self, publish_stream))
                publish_response_relay = self._PublishResponseRelay(self, publish_stream)

                self._relay = deliver_relay
                self._publish_relay = publish_relay
                self._publish_response_relay = publish_response_relay

                self._stream_ready.set()

                deliver_task = asyncio.create_task(deliver_relay.start())
                publish_task = asyncio.create_task(publish_relay.start())
                response_task = asyncio.create_task(publish_response_relay.async_start())

                self._publish_relay_task = publish_task
                self._publish_response_task = response_task

                tasks = [deliver_task, publish_task, response_task]

                try:
                    await asyncio.gather(*tasks)
                except asyncio.CancelledError:
                    if self._deliver_stop is not None and self._deliver_stop.is_set():
                        LOG.info("Operator stream worker cancelled during shutdown.")
                    else:
                        raise
                except grpclib_exceptions.StreamTerminatedError:
                    LOG.info("Operator stream terminated; shutting down.")
                except Exception:
                    LOG.exception("Operator stream worker encountered an error")
                finally:
                    deliver_relay.stop()
                    publish_relay.stop()
                    publish_response_relay.stop()
                    if self._deliver_upstream is not None:
                        self._deliver_upstream.close()
                    if self._deliver_stop is not None:
                        self._deliver_stop.set()
                    for task in tasks:
                        task.cancel()
                    for task in tasks:
                        with contextlib.suppress(asyncio.CancelledError, grpclib_exceptions.StreamTerminatedError):
                            await task
                    for stream in (publish_stream, ack_stream):
                        if stream is None:
                            continue
                        end = getattr(stream, "end", None)
                        if not callable(end):
                            continue
                        with contextlib.suppress(
                            asyncio.CancelledError,
                            grpclib_exceptions.ProtocolError,
                            grpclib_exceptions.StreamTerminatedError,
                        ):
                            await end()
        finally:
            self._stream_ready = asyncio.Event()
            self._publish_started = asyncio.Event()
            self._deliver_upstream = None
            self._relay = None
            self._publish_relay = None
            self._publish_response_relay = None
            self._publish_relay_task = None
            self._publish_response_task = None

    async def _async_openStream(
        self,
        exit_stack: contextlib.AsyncExitStack,
        method_name: str,
    ) -> Any:
        """Open sidecar bidirectional stream and register cleanup callbacks.

        Supports both real grpclib method handles (with ``.open()``) and test
        doubles that directly return stream-like objects.
        """

        if self._sidecar_stub is None:
            raise RuntimeError("Operator sidecar stub is not initialized")

        method = getattr(self._sidecar_stub, method_name)
        open_attr = getattr(method, "open", None)

        if callable(open_attr):
            return await exit_stack.enter_async_context(open_attr())

        stream = method()
        if inspect.isawaitable(stream):
            stream = await stream

        async_close = getattr(stream, "aclose", None)
        if callable(async_close):
            exit_stack.push_async_callback(async_close)
        else:
            close = getattr(stream, "close", None)
            if callable(close):
                exit_stack.callback(close)

        return stream

    async def _async_processDeliverRequest(self, request: operator_pb2.DeliverRequest) -> Result:
        """Decode one incoming delivery request and dispatch to handler."""
        port = request.port
        payload = request.payload
        requestMessageId = request.message_id or "<none>"
        requestTraceId = (
            request.message_context.trace_id
            if request.HasField("message_context") and request.message_context.trace_id
            else "<none>"
        )
        LOG.info(
            "Received delivery input_port='%s' message_id='%s' trace_id='%s' payload_type='%s'",
            port or "<none>",
            requestMessageId,
            requestTraceId,
            payload.type_url or "<none>",
        )
        requestMessageContext: Optional[MessageContext] = None
        if request.HasField("message_context"):
            requestMessageContext = MessageContext()
            requestMessageContext.CopyFrom(request.message_context)
        messageContextToken = self._MESSAGE_CONTEXT_VAR.set(requestMessageContext)

        try:
            ingressPorts = self.__class__._operatorPortContract()["ingress"]
            ingressSpec = ingressPorts.get(port)
            if ingressSpec is None:
                LOG.error(
                    "Problem handling input_port='%s' message_id='%s' trace_id='%s': "
                    "port is not declared in @operator_ports ingress",
                    port or "<none>",
                    requestMessageId,
                    requestTraceId,
                )
                return Result(ok=False, message=f"input_port '{port}' is not declared")

            declaredTypeUrl = ingressSpec["type_url"]
            canonicalPayloadTypeUrl = self._canonicalizeTypeUrl(payload.type_url)
            payloadForUnpack = payload
            if payload.type_url and canonicalPayloadTypeUrl != payload.type_url:
                LOG.warning(
                    "Received non-canonical payload type_url='%s' input_port='%s' message_id='%s' trace_id='%s'; "
                    "canonicalized to '%s'",
                    payload.type_url,
                    port or "<none>",
                    requestMessageId,
                    requestTraceId,
                    canonicalPayloadTypeUrl,
                )
                normalizedPayload = AnyMessage()
                normalizedPayload.CopyFrom(payload)
                normalizedPayload.type_url = canonicalPayloadTypeUrl
                payloadForUnpack = normalizedPayload
            if canonicalPayloadTypeUrl and canonicalPayloadTypeUrl != declaredTypeUrl:
                LOG.error(
                    "Problem unpacking message for input_port='%s' message_id='%s' trace_id='%s': "
                    "payload_type='%s' does not match declared_type='%s'",
                    port or "<none>",
                    requestMessageId,
                    requestTraceId,
                    canonicalPayloadTypeUrl,
                    declaredTypeUrl,
                )
                return Result(
                    ok=False,
                    message=(
                        f"payload type '{canonicalPayloadTypeUrl}' for input_port '{port}' "
                        f"does not match declared '{declaredTypeUrl}'"
                    ),
                )

            unpacked_message = self._tryUnpackPayload(
                payload=payloadForUnpack,
                identifier=declaredTypeUrl,
            )
            if unpacked_message is None:
                LOG.error(
                    "Problem unpacking message to the declared type for input_port='%s' message_id='%s' "
                    "trace_id='%s' expected_type='%s' payload_type='%s'; returning NACK",
                    port or "<none>",
                    requestMessageId,
                    requestTraceId,
                    declaredTypeUrl,
                    canonicalPayloadTypeUrl or "<none>",
                )
                return Result(
                    ok=False,
                    message=(
                        f"failed to unpack message for input_port '{port}' as "
                        f"'{self._normalizeTypeName(declaredTypeUrl)}'"
                    ),
                )
            message: Message = unpacked_message

            try:
                messageType = getattr(message.DESCRIPTOR, "full_name", payload.type_url or "<unknown>")
                LOG.info(
                    "Dispatching input_port='%s' message_id='%s' trace_id='%s' message_type='%s'",
                    port or "<none>",
                    requestMessageId,
                    requestTraceId,
                    messageType,
                )
                handler_result = self.dispatch(
                    input_port=port,
                    message=message,
                )
                if inspect.isawaitable(handler_result):
                    handler_result = await handler_result
                if isinstance(handler_result, Result):
                    if handler_result.ok:
                        LOG.info(
                            "Handler completed input_port='%s' message_id='%s' trace_id='%s' result=ok",
                            port or "<none>",
                            requestMessageId,
                            requestTraceId,
                        )
                    else:
                        LOG.warning(
                            "Handler completed input_port='%s' message_id='%s' trace_id='%s' result=error message='%s'",
                            port or "<none>",
                            requestMessageId,
                            requestTraceId,
                            handler_result.message or "<none>",
                        )
                    return handler_result
            except Exception:  # pragma: no cover - bubble unexpected handler failures via logs
                message_type = getattr(message.DESCRIPTOR, "full_name", payload.type_url or "<unknown>")
                LOG.exception(
                    f"Handler for input_port='{port}' failed "
                    f"(type={message_type})"
                )
                return Result(ok=False, message=f"handler for input_port '{port}' failed")

            LOG.info(
                "Handler completed input_port='%s' message_id='%s' trace_id='%s' result=ok",
                port or "<none>",
                requestMessageId,
                requestTraceId,
            )
            return Result(ok=True)
        finally:
            self._MESSAGE_CONTEXT_VAR.reset(messageContextToken)

    def _handlePublishResponse(self, response: operator_pb2.PublishResponse) -> None:
        if response.error.code == 0:
            return

        self.onPublishError(
            port=response.port,
            error=response.error,
        )

    def onPublishError(
        self,
        *,
        port: str,
        error: status_pb2.Status,
    ) -> None:
        """Handle publish errors surfaced by the OperatorSidecar stream."""

        LOG.error(
            f"Publish to port '{port}' failed "
            f"(code={error.code}): {error.message}"
        )

    @classmethod
    def _lookupDescriptor(cls, type_name: str):
        try:
            return cls._SYMBOL_DB.pool.FindMessageTypeByName(type_name)
        except KeyError:
            return None

    @classmethod
    def _resolveMessageClass(cls, type_name: str):
        try:
            return cls._SYMBOL_DB.GetSymbol(type_name)
        except KeyError:
            descriptor = cls._lookupDescriptor(type_name)
            if descriptor is None:
                return None
            return cls._MESSAGE_FACTORY.GetPrototype(descriptor)

    @classmethod
    def _candidateTypeNames(cls, identifier: str) -> list[str]:
        normalized = cls._normalizeTypeName(identifier)
        if normalized == identifier:
            return [identifier]
        return [identifier, normalized]

    @classmethod
    def _canonicalizeTypeUrl(cls, identifier: str) -> str:
        if not isinstance(identifier, str):
            return ""
        normalizedTypeName = cls._normalizeTypeName(identifier)
        if not normalizedTypeName:
            return ""
        return f"{cls._CANONICAL_ANY_TYPE_PREFIX}{normalizedTypeName}"

    @classmethod
    def _tryUnpackPayload(cls, *, payload: AnyMessage, identifier: str) -> Optional[Message]:
        for type_name in cls._candidateTypeNames(identifier):
            if not type_name:
                continue
            message_cls = cls._resolveMessageClass(type_name)
            if message_cls is None:
                continue
            candidate = message_cls()
            if payload.Unpack(candidate):
                return candidate
        return None

    @classmethod
    def _isCanonicalAnyTypeUrl(cls, type_url: str) -> bool:
        return bool(type_url) and type_url.startswith(cls._CANONICAL_ANY_TYPE_PREFIX)

    @staticmethod
    def _normalizeTypeName(identifier: str) -> str:
        if not identifier:
            return identifier
        if "/" in identifier:
            return identifier.rsplit("/", 1)[-1]
        return identifier

@operator_ports(
    {
        "ingress": [],
        "egress": [],
    }
)
# TODO: remove this class
class CompositeOperator(Operator):
    """Composite that delegates dispatch to a list of sub-operators."""

    def __init__(self, operators: list[Operator]) -> None:
        super().__init__()
        self._operators = operators

    async def async_connect(self, uri: str) -> None:
        await super().async_connect(uri)

        publish_upstream = self._publish_upstream
        sidecar_stub = self._sidecar_stub
        publish_relay = self._publish_relay
        deliver_stop = self._deliver_stop
        stream_ready = self._stream_ready

        if (
            publish_upstream is None
            or sidecar_stub is None
            or publish_relay is None
            or deliver_stop is None
            or stream_ready is None
        ):
            return

        for operator in self._operators:
            operator._publish_upstream = publish_upstream
            operator._sidecar_stub = sidecar_stub
            operator._publish_relay = publish_relay
            operator._deliver_stop = deliver_stop
            operator._stream_ready = stream_ready

    def dispatch(
        self,
        *,
        input_port: str,
        message: Message,
    ) -> Any:
        last_result: Optional[Result] = None
        has_matching_handler = False
        for op in self._operators:
            if input_port not in op.handlers():
                continue

            has_matching_handler = True
            try:
                result = op.dispatch(input_port=input_port, message=message)
            except Exception:
                # Propagate unexpected errors from sub-operators.
                raise
            if isinstance(result, Result):
                if result.ok:
                    return result
                last_result = result
                continue
            return result

        if not has_matching_handler:
            formatted_message = text_format.MessageToString(message, as_one_line=True).strip()
            if not formatted_message:
                formatted_message = "<empty>"
            LOG.warning(
                "No handler registered for input_port '%s' (type=%s, message=%s)",
                input_port,
                message.DESCRIPTOR.full_name,
                formatted_message,
            )
            return Result(ok=False, message=f"handler for input_port '{input_port}' not found in composite")

        return last_result or Result(ok=False, message=f"handler for input_port '{input_port}' not found in composite")


__all__ = ["Operator", "CompositeOperator", "operator_ports"]
