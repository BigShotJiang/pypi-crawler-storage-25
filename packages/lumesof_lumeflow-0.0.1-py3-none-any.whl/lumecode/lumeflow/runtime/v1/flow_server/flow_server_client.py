from __future__ import annotations

from dataclasses import dataclass

from grpclib import GRPCError
from grpclib.client import Channel

from lumecode.base.python.net.target_parser import NetTarget
from lumecode.lumeflow.runtime.v1.flow_server import flow_server_grpc


@dataclass
class FlowServerClientConfigError(Exception):
    target: str
    reason: str


@dataclass
class FlowServerClientTransportError(Exception):
    rpcName: str
    target: str
    message: str


@dataclass
class FlowServerClientRpcError(Exception):
    rpcName: str
    status: str
    message: str


class FlowServerClient:
    def __init__(self, *, target: str):
        self._target = target

    def _buildChannel(self) -> Channel:
        try:
            _parsed = NetTarget.parseTarget(self._target)
        except ValueError as exc:
            raise FlowServerClientConfigError(
                target=self._target,
                reason=str(exc),
            ) from exc

        if _parsed.getPath() is not None:
            return Channel(path=_parsed.getPath())
        if _parsed.getHost() is None or _parsed.getPort() is None:
            raise FlowServerClientConfigError(
                target=self._target,
                reason="target must resolve to tcp host/port or unix socket path",
            )
        return Channel(host=_parsed.getHost(), port=_parsed.getPort())

    async def _async_callUnary(self, rpcName: str, request):
        channel = self._buildChannel()
        stub = flow_server_grpc.FlowServerStub(channel)
        method = getattr(stub, rpcName)
        try:
            return await method(request)
        except GRPCError as exc:
            raise FlowServerClientRpcError(
                rpcName=rpcName,
                status=str(exc.status),
                message=str(exc.message),
            ) from exc
        except OSError as exc:
            raise FlowServerClientTransportError(
                rpcName=rpcName,
                target=self._target,
                message=str(exc),
            ) from exc
        finally:
            channel.close()

    async def async_submitJob(self, request):
        return await self._async_callUnary("SubmitJob", request)

    async def async_getJobStatus(self, request):
        return await self._async_callUnary("GetJobStatus", request)

    async def async_startJob(self, request):
        return await self._async_callUnary("StartJob", request)

    async def async_cancelJob(self, request):
        return await self._async_callUnary("CancelJob", request)

    async def async_listJobs(self, request):
        return await self._async_callUnary("List", request)

    async def async_injectMessage(self, request):
        return await self._async_callUnary("InjectMessage", request)

    async def async_getJobIngressLinkRefByAppId(self, request):
        return await self._async_callUnary("GetJobIngressLinkRefByAppId", request)

    async def async_getBridgeReplicaLinkMap(self, request):
        return await self._async_callUnary("GetBridgeReplicaLinkMap", request)

    async def async_injectMessage(self, request):
        return await self._async_callUnary("InjectMessage", request)
