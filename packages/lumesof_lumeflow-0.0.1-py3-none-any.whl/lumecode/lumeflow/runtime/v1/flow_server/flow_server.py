"""gRPC surface area for the Lumeflow flow server."""

from __future__ import annotations

import asyncio
import base64
from collections import deque
from datetime import timezone
import json
import logging
import time
import urllib.request
import uuid
from contextlib import asynccontextmanager
from typing import Mapping

from google.protobuf import timestamp_pb2
from grpclib import GRPCError
from grpclib.client import Channel
from grpclib.const import Status
from grpclib.server import Stream
from sqlalchemy import delete, func, insert, select, text, update
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker
from sqlalchemy.exc import DBAPIError, IntegrityError, SQLAlchemyError

from lumecode.base.python.logging import lumesof_logging
from lumecode.lumeflow.runtime.v1.flow_server import dag_pb2, flow_server_pb2
from lumecode.lumeflow.runtime.v1.flow_server import flow_server_grpc
from lumecode.lumeflow.runtime.v1.graph.flow_graph import FlowGraph
from lumecode.lumeflow.runtime.v1.opnet import opnet_controller_pb2
from lumecode.lumeflow.runtime.v1.opnet import opnet_types_pb2
from lumecode.lumeflow.runtime.v1.executor import executor_control_service_pb2
from lumecode.base.python.net.retry_until_ready import RetryDeadlineExceededError, RetryUntilReady
from lumecode.base.python.net.target_parser import NetTarget
from lumecode.lumeflow.runtime.v1.config_query_server import (
    config_query_server_grpc,
    config_query_server_pb2,
)
from lumecode.base.python.sqldb import crdb_async_utils as sqldb_utils
from lumecode.storage.cas import cas_pb2

from lumecode.crdb.schemas.dev_cluster.flow.db_orm_models import (
    TabDagLinks,
    TabDagOperators,
    TabFlowJobs,
    TabNodes,
    TabOperatorInstances,
    TabRpcBridgeLinks,
)

DEFAULT_BIND_ADDRESS = "127.0.0.1:50070"
DEFAULT_SIDECAR_OPERATOR_CONNECT_MAX_ATTEMPTS = 60
DEFAULT_SIDECAR_OPERATOR_CONNECT_BACKOFF_MS = 500
DEFAULT_CARTOND_FALLBACK_LOG_BUFFER_BYTES = 8 * 1024 * 1024
DEFAULT_START_JOB_LAUNCH_MAX_PARALLELISM = 8
DEFAULT_START_JOB_OPERATOR_READY_TIMEOUT_SECONDS = 900.0
DEFAULT_START_JOB_OPERATOR_LAUNCH_TIMEOUT_SECONDS = 600.0
DEFAULT_START_JOB_OPERATOR_NONRESPONSIVE_TIMEOUT_SECONDS = 30.0
DEFAULT_START_JOB_OPERATOR_READY_POLL_INTERVAL_SECONDS = 1.0
DEFAULT_START_JOB_OPERATOR_READY_HEARTBEAT_RECENCY_SECONDS = 0.0
DEFAULT_CREATE_EXECUTORS_MAX_PARALLELISM = 8
DEFAULT_CANCEL_JOB_DESTROY_MAX_PARALLELISM = 8

_OCI_REGISTRY_TYPE_CONFIG_KEY = "oci_registry.type"
_START_JOB_OPERATOR_READY_TIMEOUT_CONFIG_KEY = "flow.start_job_operator_ready_timeout_s"
_START_JOB_OPERATOR_LAUNCH_TIMEOUT_CONFIG_KEY = "flow.start_job_operator_launch_timeout_s"
_START_JOB_OPERATOR_NONRESPONSIVE_TIMEOUT_CONFIG_KEY = "flow.start_job_operator_nonresponsive_timeout_s"
_START_JOB_OPERATOR_READY_POLL_INTERVAL_CONFIG_KEY = "flow.start_job_operator_ready_poll_interval_s"
_START_JOB_OPERATOR_READY_HEARTBEAT_RECENCY_CONFIG_KEY = "flow.start_job_operator_ready_heartbeat_recency_s"
_OCI_REGISTRY_TYPE_NONE = "none"
_OCI_REGISTRY_TYPE_GCR = "gcr"
_OCI_TOKEN_REFRESH_WINDOW_SECONDS = 1800  # refresh when < 30 min remain
_GCE_METADATA_TOKEN_URL = (
    "http://metadata.google.internal/computeMetadata/v1"
    "/instance/service-accounts/default/token"
)
_OCI_REGISTRY_USER_NAME_ENV = "OCI_REGISTRY_USER_NAME"
_OCI_REGISTRY_ACCESS_TOKEN_ENV = "OCI_REGISTRY_ACCESS_TOKEN"

logger = logging.getLogger(__name__)
structuredLogger = lumesof_logging.getLogger(__name__)

_FLOW_LOG_ATTR_ALIASES = {
    "app_id": lumesof_logging.LUMESOF_APP_ID,
    "cluster_id": lumesof_logging.LUMESOF_CLUSTER_ID,
    "controller_id": lumesof_logging.LUMESOF_CONTROLLER_ID,
    "exception": lumesof_logging.EXCEPTION,
    "executor_id": lumesof_logging.LUMESOF_EXECUTOR_ID,
    "job_id": lumesof_logging.LUMESOF_JOB_ID,
    "job_status": lumesof_logging.LUMESOF_JOB_STATUS,
    "link_ref": lumesof_logging.LUMESOF_LINK_REF,
    "node_id": lumesof_logging.LUMESOF_NODE_ID,
    "operator_name": lumesof_logging.LUMESOF_OPERATOR_NAME,
    "owner": lumesof_logging.LUMESOF_OWNER,
    "payload_type": lumesof_logging.LUMESOF_PAYLOAD_TYPE,
    "stage": lumesof_logging.LUMESOF_STAGE,
    "trace_id": lumesof_logging.TRACE_ID,
}
_FLOW_LOG_ALLOWED_ATTRS = {
    lumesof_logging.EVENT_OUTCOME,
    lumesof_logging.EXCEPTION,
    lumesof_logging.RPC_METHOD,
    lumesof_logging.TRACE_ID,
    lumesof_logging.LUMESOF_APP_ID,
    lumesof_logging.LUMESOF_CLUSTER_ID,
    lumesof_logging.LUMESOF_CONTROLLER_ID,
    lumesof_logging.LUMESOF_EXECUTOR_ID,
    lumesof_logging.LUMESOF_JOB_ID,
    lumesof_logging.LUMESOF_JOB_STATUS,
    lumesof_logging.LUMESOF_LINK_REF,
    lumesof_logging.LUMESOF_NODE_ID,
    lumesof_logging.LUMESOF_OPERATOR_NAME,
    lumesof_logging.LUMESOF_OWNER,
    lumesof_logging.LUMESOF_PAYLOAD_TYPE,
    lumesof_logging.LUMESOF_STAGE,
}


def _flowLogAttrs(**attrs: object) -> dict[str, object]:
    normalizedAttrs: dict[str, object] = {}
    for key, value in attrs.items():
        normalizedKey = _FLOW_LOG_ATTR_ALIASES.get(key, key)
        if normalizedKey not in _FLOW_LOG_ALLOWED_ATTRS:
            continue
        if value is None:
            continue
        if isinstance(value, uuid.UUID):
            normalizedAttrs[normalizedKey] = str(value)
        else:
            normalizedAttrs[normalizedKey] = value
    return normalizedAttrs


def _flowEventAttrs(*, outcome: str, **attrs: object) -> dict[str, object]:
    return _flowLogAttrs(**{lumesof_logging.EVENT_OUTCOME: outcome, **attrs})


def _jobLoggingContext(*, jobId: uuid.UUID | str):
    return lumesof_logging.loggingContext(
        **{
            lumesof_logging.LUMESOF_JOB_ID: str(jobId),
        }
    )


def _fetchGceMetadataToken() -> tuple[str, str, float]:
    """Fetch an access token from the GCE metadata server (blocking; run in executor).

    Returns (username, access_token, expiry_unix_ts).
    """
    req = urllib.request.Request(
        _GCE_METADATA_TOKEN_URL,
        headers={"Metadata-Flavor": "Google"},
    )
    with urllib.request.urlopen(req, timeout=5) as resp:  # noqa: S310
        data = json.loads(resp.read())
    token: str = data["access_token"]
    expires_in: int = int(data.get("expires_in", 3600))
    return ("oauth2accesstoken", token, time.time() + expires_in)


_LINK_TYPE_REGULAR = "REGULAR"
_LINK_TYPE_SYNC_INJECTOR = "SYNC_INJECTOR"
_LINK_TYPE_ASYNC_INJECTOR = "ASYNC_INJECTOR"
_LINK_TYPE_SYNC_RETRIEVER = "SYNC_RETRIEVER"
_JOB_TYPE_SYNCHRONOUS = "SYNCHRONOUS"
_JOB_TYPE_ASYNCHRONOUS = "ASYNCHRONOUS"
_CREATE_PARAM_CAPTURE_FALLBACK_LOGS = "--capture_fallback_logs"
_CREATE_PARAM_FALLBACK_OTLP_TARGET = "--fallback_otlp_target"
_CREATE_PARAM_FALLBACK_LOG_BUFFER_BYTES = "--fallback_log_buffer_bytes"
_OTEL_EXPORTER_OTLP_ENDPOINT_ENV = "OTEL_EXPORTER_OTLP_ENDPOINT"
_LUMESOF_LOGS_FILE_ENV = "LUMESOF_LOGS_FILE"
_LUMESOF_LOG_LEVEL_ENV = lumesof_logging.LOG_LEVEL_ENV


@asynccontextmanager
async def _async_transaction(session: AsyncSession):
    async with sqldb_utils.async_transactionContext(existing_session=session) as tx_ctx:
        yield tx_ctx.session


class FlowServerService(flow_server_grpc.FlowServerBase):
    """Async grpclib servicer that fronts the flow server RPCs."""

    def __init__(
        self,
        *,
        session_maker: async_sessionmaker[AsyncSession],
        cluster_id: uuid.UUID,
        opnet_manager_client: object | None = None,
        executor_control_client: object | None = None,
        cas_client: object | None = None,
        enableCreateLoop: bool = True,
        createLoopIntervalSeconds: float = 1.0,
        createLoopBatchSize: int = 50,
        opnetControllerTarget: str | None = None,
        sidecarGrpcOpnetTarget: str | None = None,
        sidecarLogLevel: str | None = None,
        sidecarOtelLogsEndpoint: str | None = None,
        sidecarOperatorConnectMaxAttempts: int = DEFAULT_SIDECAR_OPERATOR_CONNECT_MAX_ATTEMPTS,
        sidecarOperatorConnectBackoffMs: int = DEFAULT_SIDECAR_OPERATOR_CONNECT_BACKOFF_MS,
        includeOperatorDockerImageInSidecarArgv: bool = True,
        startJobLeaseSeconds: float = 180.0,
        startJobLaunchMaxParallelism: int = DEFAULT_START_JOB_LAUNCH_MAX_PARALLELISM,
        startJobOperatorReadyTimeoutSeconds: float = DEFAULT_START_JOB_OPERATOR_READY_TIMEOUT_SECONDS,
        startJobOperatorLaunchTimeoutSeconds: float = DEFAULT_START_JOB_OPERATOR_LAUNCH_TIMEOUT_SECONDS,
        startJobOperatorNonresponsiveTimeoutSeconds: float = DEFAULT_START_JOB_OPERATOR_NONRESPONSIVE_TIMEOUT_SECONDS,
        startJobOperatorReadyPollIntervalSeconds: float = DEFAULT_START_JOB_OPERATOR_READY_POLL_INTERVAL_SECONDS,
        startJobOperatorReadyHeartbeatRecencySeconds: float = DEFAULT_START_JOB_OPERATOR_READY_HEARTBEAT_RECENCY_SECONDS,
        createExecutorsMaxParallelism: int = DEFAULT_CREATE_EXECUTORS_MAX_PARALLELISM,
        cancelJobDestroyMaxParallelism: int = DEFAULT_CANCEL_JOB_DESTROY_MAX_PARALLELISM,
        configServiceTarget: str = "",
        bridgeReplicaToLinkRef: Mapping[str, str] | None = None,
        enableBridgeBootstrap: bool = False,
    ) -> None:
        if opnet_manager_client is None or executor_control_client is None or cas_client is None:
            logger.fatal(
                "FlowServerService requires opnet_manager_client, executor_control_client, and cas_client."
            )
            raise RuntimeError("FlowServerService missing required clients.")
        self._session_maker = session_maker
        self._cluster_id = cluster_id
        self._opnet_manager_client = opnet_manager_client
        self._executor_control_client = executor_control_client
        self._cas_client = cas_client
        if startJobLeaseSeconds <= 0:
            raise ValueError(f"startJobLeaseSeconds must be > 0, got {startJobLeaseSeconds}")
        if startJobLaunchMaxParallelism < 1:
            raise ValueError(
                f"startJobLaunchMaxParallelism must be >= 1, got {startJobLaunchMaxParallelism}"
            )
        if startJobOperatorReadyTimeoutSeconds <= 0:
            raise ValueError(
                "startJobOperatorReadyTimeoutSeconds must be > 0, "
                f"got {startJobOperatorReadyTimeoutSeconds}"
            )
        if startJobOperatorLaunchTimeoutSeconds <= 0:
            raise ValueError(
                "startJobOperatorLaunchTimeoutSeconds must be > 0, "
                f"got {startJobOperatorLaunchTimeoutSeconds}"
            )
        if startJobOperatorNonresponsiveTimeoutSeconds < 0:
            raise ValueError(
                "startJobOperatorNonresponsiveTimeoutSeconds must be >= 0, "
                f"got {startJobOperatorNonresponsiveTimeoutSeconds}"
            )
        if startJobOperatorReadyPollIntervalSeconds <= 0:
            raise ValueError(
                "startJobOperatorReadyPollIntervalSeconds must be > 0, "
                f"got {startJobOperatorReadyPollIntervalSeconds}"
            )
        if startJobOperatorReadyHeartbeatRecencySeconds < 0:
            raise ValueError(
                "startJobOperatorReadyHeartbeatRecencySeconds must be >= 0, "
                f"got {startJobOperatorReadyHeartbeatRecencySeconds}"
            )
        if createExecutorsMaxParallelism < 1:
            raise ValueError(
                f"createExecutorsMaxParallelism must be >= 1, got {createExecutorsMaxParallelism}"
            )
        if cancelJobDestroyMaxParallelism < 1:
            raise ValueError(
                "cancelJobDestroyMaxParallelism must be >= 1, "
                f"got {cancelJobDestroyMaxParallelism}"
            )
        self._enableCreateLoop = enableCreateLoop
        self._createLoopIntervalSeconds = createLoopIntervalSeconds
        self._createLoopBatchSize = createLoopBatchSize
        self._createLoopStopEvent = asyncio.Event()
        self._createLoopTask: asyncio.Task[None] | None = None
        self._opnetControllerTarget = opnetControllerTarget or ""
        self._sidecarGrpcOpnetTarget = sidecarGrpcOpnetTarget or self._opnetControllerTarget
        self._sidecarLogLevel = (sidecarLogLevel or "").strip().upper()
        self._sidecarOtelLogsEndpoint = (sidecarOtelLogsEndpoint or "").strip()
        if sidecarOperatorConnectMaxAttempts < 1:
            raise ValueError(
                f"sidecarOperatorConnectMaxAttempts must be >= 1, got {sidecarOperatorConnectMaxAttempts}"
            )
        if sidecarOperatorConnectBackoffMs < 0:
            raise ValueError(
                f"sidecarOperatorConnectBackoffMs must be >= 0, got {sidecarOperatorConnectBackoffMs}"
            )
        self._sidecarOperatorConnectMaxAttempts = sidecarOperatorConnectMaxAttempts
        self._sidecarOperatorConnectBackoffMs = sidecarOperatorConnectBackoffMs
        self._includeOperatorDockerImageInSidecarArgv = includeOperatorDockerImageInSidecarArgv
        self._sidecarLaunchRefBySubstrate: dict[str, tuple[str, str]] = {}
        self._sidecarLaunchRefLock = asyncio.Lock()
        self._startJobLeaseSeconds = startJobLeaseSeconds
        self._startJobLaunchMaxParallelism = startJobLaunchMaxParallelism
        self._startJobOperatorReadyTimeoutSeconds = startJobOperatorReadyTimeoutSeconds
        self._startJobOperatorLaunchTimeoutSeconds = startJobOperatorLaunchTimeoutSeconds
        self._startJobOperatorNonresponsiveTimeoutSeconds = startJobOperatorNonresponsiveTimeoutSeconds
        self._startJobOperatorReadyPollIntervalSeconds = startJobOperatorReadyPollIntervalSeconds
        self._startJobOperatorReadyHeartbeatRecencySeconds = startJobOperatorReadyHeartbeatRecencySeconds
        self._startJobOperatorReadyTimeoutSecondsResolved: float | None = None
        self._startJobOperatorLaunchTimeoutSecondsResolved: float | None = None
        self._startJobOperatorNonresponsiveTimeoutSecondsResolved: float | None = None
        self._startJobOperatorReadyPollIntervalSecondsResolved: float | None = None
        self._startJobOperatorReadyHeartbeatRecencySecondsResolved: float | None = None
        self._startJobOperatorReadyConfigLock = asyncio.Lock()
        self._createExecutorsMaxParallelism = createExecutorsMaxParallelism
        self._cancelJobDestroyMaxParallelism = cancelJobDestroyMaxParallelism
        self._configServiceTarget = configServiceTarget.strip()
        self._ociRegistryType: str | None = None
        self._ociCreds: tuple[str, str, float] | None = None  # (username, token, expiry_unix_ts)
        self._ociCredsLock = asyncio.Lock()
        self._bridgeReplicaToLinkRef = dict(bridgeReplicaToLinkRef or {})
        self._enableBridgeBootstrap = enableBridgeBootstrap
        self._bridgeBootstrapComplete = False
        self._bridgeBootstrapLock = asyncio.Lock()
        self._dependencyRetry = RetryUntilReady()
        self._startCreateLoopIfEnabled()

    def _startCreateLoopIfEnabled(self) -> None:
        if not self._enableCreateLoop:
            return
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            logger.warning("CreateLoop not started: no running event loop in constructor context")
            return
        self._createLoopTask = asyncio.create_task(self._async_createLoop())

    async def async_close(self) -> None:
        await self.async_stopCreateLoop()

    async def async_startCreateLoop(self) -> None:
        if not self._enableCreateLoop:
            return
        if self._createLoopTask is not None and not self._createLoopTask.done():
            return
        self._createLoopStopEvent.clear()
        self._createLoopTask = asyncio.create_task(self._async_createLoop())

    async def async_stopCreateLoop(self) -> None:
        task = self._createLoopTask
        if task is None:
            return
        self._createLoopStopEvent.set()
        try:
            await task
        finally:
            self._createLoopTask = None

    async def _async_createLoop(self) -> None:
        logger.info("CreateLoop started")
        try:
            while not self._createLoopStopEvent.is_set():
                try:
                    await self._async_createLoopOnce()
                except Exception as error:
                    if self._isRetryableCreateLoopError(error):
                        logger.warning("CreateLoop iteration hit retryable error; continuing loop", exc_info=True)
                    else:
                        logger.exception("CreateLoop iteration failed unexpectedly; stopping loop")
                        return
                try:
                    await asyncio.wait_for(
                        self._createLoopStopEvent.wait(),
                        timeout=self._createLoopIntervalSeconds,
                    )
                except asyncio.TimeoutError:
                    continue
        finally:
            logger.info("CreateLoop stopped")

    async def _async_createLoopOnce(self) -> int:
        async with self._session_maker() as session:
            try:
                rows = (
                    await session.execute(
                        select(TabFlowJobs.id, TabFlowJobs.status)
                        .where(TabFlowJobs.cluster_id == self._cluster_id)
                        .where(
                            (
                                (TabFlowJobs.status == "SUBMITTED")
                                & (
                                    TabFlowJobs.last_action_ts
                                    <= (func.now() - text("INTERVAL '60 seconds'"))
                                )
                            )
                            | (TabFlowJobs.status == "CANCEL_PENDING")
                        )
                        .order_by(TabFlowJobs.last_action_ts.asc())
                        .limit(self._createLoopBatchSize)
                    )
                ).all()
            except (SQLAlchemyError, OSError):
                logger.warning("CreateLoop failed reading submitted jobs; will retry", exc_info=True)
                return 0

        if not rows:
            return 0

        async def _async_processClaimedJob(job_id: uuid.UUID, status: str) -> None:
            with _jobLoggingContext(jobId=job_id):
                try:
                    if status == "SUBMITTED":
                        await self.async_createFlowJob(job_id)
                        return
                    if status == "CANCEL_PENDING":
                        await self._async_finalizeCancelledJob(job_id)
                        return
                    logger.debug(
                        "CreateLoop skipping unsupported status=%s",
                        status,
                        extra=_flowLogAttrs(job_status=status),
                    )
                except Exception:
                    logger.exception(
                        "CreateLoop failed while processing claimed job status=%s",
                        status,
                        extra=_flowLogAttrs(job_status=status),
                    )
                    if status == "SUBMITTED":
                        await self._async_markJobFailed(job_id)

        async with asyncio.TaskGroup() as task_group:
            for job_id, status in rows:
                task_group.create_task(_async_processClaimedJob(job_id, status))
        return len(rows)

    def _isRetryableCreateLoopError(self, error: Exception) -> bool:
        return isinstance(error, (SQLAlchemyError, OSError))

    async def SubmitJob(
        self,
        stream: Stream[
            flow_server_pb2.SubmitJobRequest,
            flow_server_pb2.SubmitJobResponse,
        ],
    ) -> None:
        await self.async_submitJob(stream)

    async def async_submitJob(
        self,
        stream: Stream[
            flow_server_pb2.SubmitJobRequest,
            flow_server_pb2.SubmitJobResponse,
        ],
    ) -> None:
        request = await self._async_recvRequest(stream, "SubmitJob")
        contextAttrs = {
            lumesof_logging.RPC_METHOD: "SubmitJob",
            lumesof_logging.LUMESOF_CLUSTER_ID: request.cluster_id.strip(),
            lumesof_logging.LUMESOF_OWNER: request.owner,
        }
        requestAppId = request.app_id.strip() if request.app_id else ""
        if requestAppId:
            contextAttrs[lumesof_logging.LUMESOF_APP_ID] = requestAppId
        with lumesof_logging.loggingContext(**contextAttrs):
            structuredLogger.info(
                "SubmitJob received",
                event="lumeflow.flow.submit_job.received",
                attrs=_flowEventAttrs(outcome="start"),
            )
            job_id = await self._async_submitJob(request)
            structuredLogger.info(
                "SubmitJob completed",
                event="lumeflow.flow.submit_job.completed",
                attrs=_flowEventAttrs(outcome="success", job_id=job_id),
            )
            await self._async_sendMessage(stream, flow_server_pb2.SubmitJobResponse(job_id=job_id))

    async def GetJobIngressLinkRefByAppId(
        self,
        stream: Stream[
            flow_server_pb2.GetJobIngressLinkRefByAppIdRequest,
            flow_server_pb2.GetJobIngressLinkRefByAppIdResponse,
        ],
    ) -> None:
        await self.async_getJobIngressLinkRefByAppId(stream)

    async def async_getJobIngressLinkRefByAppId(
        self,
        stream: Stream[
            flow_server_pb2.GetJobIngressLinkRefByAppIdRequest,
            flow_server_pb2.GetJobIngressLinkRefByAppIdResponse,
        ],
    ) -> None:
        request = await self._async_recvRequest(stream, "GetJobIngressLinkRefByAppId")
        response = await self._async_getJobIngressLinkRefByAppId(request)
        await self._async_sendMessage(stream, response)

    async def _async_getJobIngressLinkRefByAppId(
        self,
        request: flow_server_pb2.GetJobIngressLinkRefByAppIdRequest,
    ) -> flow_server_pb2.GetJobIngressLinkRefByAppIdResponse:
        app_id = request.app_id.strip()
        if not app_id:
            raise GRPCError(Status.INVALID_ARGUMENT, "app_id must be provided.")

        terminal_statuses = ("FINISHED", "FAILED", "CANCELLED")
        async with self._session_maker() as session:
            row = (
                await session.execute(
                    select(
                        TabFlowJobs.id,
                        TabFlowJobs.app_id,
                        TabFlowJobs.bridge_ingress_link_ref,
                    )
                    .where(TabFlowJobs.cluster_id == self._cluster_id)
                    .where(TabFlowJobs.app_id == app_id)
                    .where(~TabFlowJobs.status.in_(terminal_statuses))
                    .where(TabFlowJobs.bridge_ingress_link_ref.is_not(None))
                    .order_by(TabFlowJobs.created_at.desc())
                    .limit(1)
                )
            ).first()

        if row is None:
            raise GRPCError(
                Status.NOT_FOUND,
                f"active bridge ingress link ref not found for app_id='{app_id}'",
            )

        return flow_server_pb2.GetJobIngressLinkRefByAppIdResponse(
            app_id=row.app_id or "",
            job_id=str(row.id),
            bridge_ingress_link_ref=(row.bridge_ingress_link_ref or ""),
        )

    async def GetBridgeReplicaLinkMap(
        self,
        stream: Stream[
            flow_server_pb2.GetBridgeReplicaLinkMapRequest,
            flow_server_pb2.GetBridgeReplicaLinkMapResponse,
        ],
    ) -> None:
        await self.async_getBridgeReplicaLinkMap(stream)

    async def async_getBridgeReplicaLinkMap(
        self,
        stream: Stream[
            flow_server_pb2.GetBridgeReplicaLinkMapRequest,
            flow_server_pb2.GetBridgeReplicaLinkMapResponse,
        ],
    ) -> None:
        request = await self._async_recvRequest(stream, "GetBridgeReplicaLinkMap")
        requested_substrate = request.substrate.strip()
        if not requested_substrate:
            raise GRPCError(Status.INVALID_ARGUMENT, "GetBridgeReplicaLinkMap substrate must be provided.")
        if (
            self._enableBridgeBootstrap
            and not self._bridgeBootstrapComplete
            and len(self._bridgeReplicaToLinkRef) > 0
        ):
            async with self._bridgeBootstrapLock:
                if not self._bridgeBootstrapComplete:
                    try:
                        await self._async_bootstrapBridgeLinks()
                    except GRPCError:
                        raise
                    except Exception as exc:
                        logger.exception("GetBridgeReplicaLinkMap bootstrap failed")
                        raise GRPCError(Status.INTERNAL, "GetBridgeReplicaLinkMap bootstrap failed.") from exc
                    self._bridgeBootstrapComplete = True

        try:
            persisted, persisted_substrates = await self._async_getPersistedBridgeLinks()
        except GRPCError:
            raise
        except Exception as exc:
            logger.exception("GetBridgeReplicaLinkMap failed reading persisted links")
            raise GRPCError(Status.INTERNAL, "GetBridgeReplicaLinkMap failed reading persisted links.") from exc
        if len(persisted_substrates) > 1:
            raise GRPCError(
                Status.FAILED_PRECONDITION,
                "GetBridgeReplicaLinkMap found inconsistent bridge link substrates.",
            )
        expected_substrate = next(iter(persisted_substrates), None)
        if expected_substrate is not None and expected_substrate != requested_substrate:
            raise GRPCError(
                Status.FAILED_PRECONDITION,
                (
                    f"GetBridgeReplicaLinkMap substrate mismatch: "
                    f"requested='{requested_substrate}' expected='{expected_substrate}'."
                ),
            )
        response = flow_server_pb2.GetBridgeReplicaLinkMapResponse()
        if len(persisted) > 0:
            response.replica_to_link_ref_map.update(persisted)
        else:
            response.replica_to_link_ref_map.update(self._bridgeReplicaToLinkRef)
        await self._async_sendMessage(stream, response)

    async def _async_getPersistedBridgeLinks(self) -> tuple[dict[str, str], set[str]]:
        async with self._session_maker() as session:
            rows = (
                await session.execute(
                    select(
                        TabRpcBridgeLinks.replica_id,
                        TabRpcBridgeLinks.link_ref,
                        TabRpcBridgeLinks.substrate,
                    ).where(TabRpcBridgeLinks.cluster_id == self._cluster_id)
                )
            ).all()
        substrate_set: set[str] = set()
        for _, _, substrate in rows:
            normalized_substrate = (substrate or "").strip()
            if normalized_substrate:
                substrate_set.add(normalized_substrate)
        return ({replica_id: link_ref for (replica_id, link_ref, _) in rows}, substrate_set)

    async def _async_bootstrapBridgeLinks(self) -> None:
        try:
            create_controller_response = await self._dependencyRetry.async_retryUntilReady(
                operationName="FlowServer bootstrap bridge CreateController",
                invocation=lambda: self._opnet_manager_client.CreateController(
                    opnet_controller_pb2.OpNetCreateControllerRequest(
                        cluster_id=str(self._cluster_id),
                        usecase="OPERATORS",
                        name="rpc-opnet-bridge",
                    )
                ),
            )
        except RetryDeadlineExceededError as exc:
            raise GRPCError(Status.UNAVAILABLE, "OpNet manager is not ready.") from exc
        controller_id = self._parseUuid(
            create_controller_response.controller_id,
            "controller_id",
        )
        substrate = create_controller_response.substrate.strip() or None
        payload_type = opnet_types_pb2.OpNetPayloadType(
            serialization_format=opnet_types_pb2.OpNetPayloadType.SerializationFormat.PROTO,
            type_url="lumecode.lumeflow.runtime.v1.rpc_opnet_bridge.ReplicaEnvelope",
        )
        create_links_request = opnet_controller_pb2.OpNetCreateLinksRequest(
            cluster_id=str(self._cluster_id),
            usecase="OPERATORS",
        )
        for replica_id in sorted(self._bridgeReplicaToLinkRef):
            create_links_request.links.add(
                controller_id=str(controller_id),
                link_name=replica_id,
                payload_type=payload_type.SerializeToString(),
            )
        try:
            create_links_response = await self._dependencyRetry.async_retryUntilReady(
                operationName="FlowServer bootstrap bridge CreateLinks",
                invocation=lambda: self._opnet_manager_client.CreateLinks(create_links_request),
            )
        except RetryDeadlineExceededError as exc:
            raise GRPCError(Status.UNAVAILABLE, "OpNet manager is not ready.") from exc
        link_id_by_replica: dict[str, uuid.UUID] = {}
        link_ref_by_replica: dict[str, str] = {}
        result_by_replica = {
            result.link_name: result for result in create_links_response.results
        }
        for replica_id in self._bridgeReplicaToLinkRef:
            result = result_by_replica.get(replica_id)
            if result is None:
                raise GRPCError(Status.INTERNAL, f"missing bridge link creation result for replica '{replica_id}'")
            if result.status not in (
                opnet_controller_pb2.CREATED,
                opnet_controller_pb2.ALREADY_EXISTS,
            ):
                raise GRPCError(
                    Status.INTERNAL,
                    f"bridge link creation failed for replica '{replica_id}': {result.message}",
                )
            if not result.link_id:
                raise GRPCError(Status.INTERNAL, f"missing link_id for replica '{replica_id}'")
            try:
                link_id_by_replica[replica_id] = uuid.UUID(result.link_id)
            except Exception as exc:
                raise GRPCError(
                    Status.INTERNAL,
                    f"invalid link_id for replica '{replica_id}': {result.link_id}",
                ) from exc
            chosen_link_ref = (result.link_ref or "").strip()
            if not chosen_link_ref:
                raise GRPCError(
                    Status.INTERNAL,
                    f"missing link_ref for replica '{replica_id}'",
                )
            link_ref_by_replica[replica_id] = chosen_link_ref

        async with self._session_maker() as session:
            async with _async_transaction(session):
                existing_rows = (
                    await session.execute(
                        select(
                            TabRpcBridgeLinks.id,
                            TabRpcBridgeLinks.replica_id,
                        ).where(TabRpcBridgeLinks.cluster_id == self._cluster_id)
                    )
                ).all()
                existing_by_replica = {replica_id: row_id for (row_id, replica_id) in existing_rows}
                desired_replicas = set(self._bridgeReplicaToLinkRef)

                for replica_id in self._bridgeReplicaToLinkRef:
                    row_id = existing_by_replica.get(replica_id)
                    link_id = link_id_by_replica[replica_id]
                    opaque_link_ref = link_ref_by_replica[replica_id]
                    if row_id is None:
                        await session.execute(
                            insert(TabRpcBridgeLinks).values(
                                cluster_id=self._cluster_id,
                                replica_id=replica_id,
                                controller_id=controller_id,
                                link_id=link_id,
                                link_ref=opaque_link_ref,
                                substrate=substrate,
                            )
                        )
                    else:
                        await session.execute(
                            update(TabRpcBridgeLinks)
                            .where(TabRpcBridgeLinks.id == row_id)
                            .values(
                                controller_id=controller_id,
                                link_id=link_id,
                                link_ref=opaque_link_ref,
                                substrate=substrate,
                            )
                        )

                stale_ids = [
                    row_id
                    for (row_id, replica_id) in existing_rows
                    if replica_id not in desired_replicas
                ]
                if len(stale_ids) > 0:
                    await session.execute(
                        delete(TabRpcBridgeLinks).where(TabRpcBridgeLinks.id.in_(stale_ids))
                    )

    async def _async_submitJob(self, request: flow_server_pb2.SubmitJobRequest) -> str:
        if not request.owner:
            raise GRPCError(Status.INVALID_ARGUMENT, "owner must be provided.")

        if not request.cluster_id:
            raise GRPCError(Status.INVALID_ARGUMENT, "cluster_id must be provided.")

        try:
            cluster_id = uuid.UUID(request.cluster_id)
        except ValueError as exc:
            structuredLogger.warning(
                "SubmitJob invalid cluster_id",
                event="lumeflow.flow.submit_job.invalid_cluster_id",
                attrs=_flowEventAttrs(outcome="failure", cluster_id=request.cluster_id),
                exc_info=True,
            )
            raise GRPCError(Status.INVALID_ARGUMENT, "cluster_id must be a valid UUID string.") from exc

        app_id = request.app_id.strip() if request.app_id else None
        if app_id == "":
            app_id = None

        try:
            loaded_flow = FlowGraph(dag=request.job_dag)
            containsLoops = loaded_flow.validate(allowLoop=loaded_flow.getAllowLoops())
            job_type = self._inferAndValidateJobType(loaded_flow=loaded_flow, app_id=app_id)
        except ValueError as exc:
            raise GRPCError(Status.INVALID_ARGUMENT, str(exc)) from exc
        except Exception as exc:
            structuredLogger.warning(
                "SubmitJob failed DAG validation",
                event="lumeflow.flow.submit_job.dag_validation_failed",
                attrs=_flowEventAttrs(
                    outcome="failure",
                    owner=request.owner,
                    cluster_id=request.cluster_id,
                    app_id=app_id,
                    exception=str(exc),
                ),
                exc_info=True,
            )
            raise GRPCError(Status.INVALID_ARGUMENT, "job_dag is invalid.") from exc

        dag_bytes = request.job_dag.SerializeToString()
        serialized_dag = base64.b64encode(dag_bytes).decode("ascii")

        async with self._session_maker() as session:
            try:
                async with _async_transaction(session):
                    row = (
                        await session.execute(
                            insert(TabFlowJobs)
                            .values(
                                serialized_dag=serialized_dag,
                                owner=request.owner,
                                cluster_id=cluster_id,
                                status="SUBMITTED",
                                last_action_ts=text("to_timestamp(0)"),
                                app_id=app_id,
                                job_type=job_type,
                                contains_loops=containsLoops,
                            )
                            .returning(TabFlowJobs.id)
                        )
                    ).one()
            except IntegrityError as exc:
                structuredLogger.warning(
                    "SubmitJob failed integrity error",
                    event="lumeflow.flow.submit_job.integrity_error",
                    attrs=_flowEventAttrs(
                        outcome="failure",
                        owner=request.owner,
                        cluster_id=request.cluster_id,
                        app_id=app_id,
                        exception=str(exc),
                    ),
                    exc_info=True,
                )
                raise GRPCError(Status.FAILED_PRECONDITION, "Failed to submit job.") from exc
            except DBAPIError as exc:
                structuredLogger.exception(
                    "SubmitJob failed database error",
                    event="lumeflow.flow.submit_job.database_error",
                    attrs=_flowEventAttrs(
                        outcome="failure",
                        owner=request.owner,
                        cluster_id=request.cluster_id,
                        app_id=app_id,
                        exception=str(exc),
                    ),
                )
                raise GRPCError(Status.INTERNAL, "Database error while submitting job.") from exc

        (job_id,) = row
        structuredLogger.debug(
            "SubmitJob persisted",
            event="lumeflow.flow.submit_job.persisted",
            attrs=_flowEventAttrs(
                outcome="success",
                job_id=str(job_id),
                owner=request.owner,
                cluster_id=request.cluster_id,
                app_id=app_id,
            ),
        )
        return str(job_id)

    def _inferAndValidateJobType(self, *, loaded_flow: FlowGraph, app_id: str | None) -> str:
        injectorCount = 0
        deadendCount = 0
        for spec in loaded_flow.iterLinkSpecs():
            if spec.linkType in (_LINK_TYPE_SYNC_INJECTOR, _LINK_TYPE_ASYNC_INJECTOR):
                injectorCount += 1
            elif spec.linkType == _LINK_TYPE_SYNC_RETRIEVER:
                deadendCount += 1

        if app_id:
            if injectorCount != 1 or deadendCount != 1:
                raise ValueError(
                    "SYNCHRONOUS jobs (jobs with app_id) must include exactly one SYNC_INJECTOR "
                    "link and exactly one SYNC_RETRIEVER link."
                )
            return _JOB_TYPE_SYNCHRONOUS

        if deadendCount != 0:
            raise ValueError(
                "ASYNCHRONOUS jobs (jobs without app_id) must not include SYNC_RETRIEVER links."
            )
        return _JOB_TYPE_ASYNCHRONOUS

    async def async_startJob(
        self,
        stream: Stream[
            flow_server_pb2.StartJobRequest,
            flow_server_pb2.StartJobResponse,
        ],
    ) -> None:
        request_job_id = ""
        try:
            request = await self._async_recvRequest(stream, "StartJob")
            request_job_id = request.job_id
            with lumesof_logging.loggingContext(
                **{
                    lumesof_logging.RPC_METHOD: "StartJob",
                    lumesof_logging.LUMESOF_CLUSTER_ID: str(self._cluster_id),
                    lumesof_logging.LUMESOF_JOB_ID: request.job_id.strip(),
                }
            ):
                job_id = self._parseUuid(request.job_id, "job_id")
                await self._async_startJob(job_id)
                structuredLogger.info(
                    "StartJob completed",
                    event="lumeflow.flow.start_job.completed",
                    attrs=_flowEventAttrs(outcome="success"),
                )
                await self._async_sendMessage(
                    stream,
                    flow_server_pb2.StartJobResponse(job_id=str(job_id)),
                )
        except Exception:
            structuredLogger.exception(
                "StartJob failed",
                event="lumeflow.flow.start_job.failed",
                attrs=_flowEventAttrs(
                    outcome="failure",
                    cluster_id=str(self._cluster_id),
                    job_id=request_job_id or "<missing>",
                ),
            )
            raise

    async def StartJob(
        self,
        stream: Stream[
            flow_server_pb2.StartJobRequest,
            flow_server_pb2.StartJobResponse,
        ],
    ) -> None:
        await self.async_startJob(stream)

    async def async_cancelJob(
        self,
        stream: Stream[
            flow_server_pb2.CancelJobRequest,
            flow_server_pb2.CancelJobResponse,
        ],
    ) -> None:
        request = await self._async_recvRequest(stream, "CancelJob")
        with lumesof_logging.loggingContext(
            **{
                lumesof_logging.RPC_METHOD: "CancelJob",
                lumesof_logging.LUMESOF_CLUSTER_ID: str(self._cluster_id),
                lumesof_logging.LUMESOF_JOB_ID: request.job_id.strip(),
            }
        ):
            job_id = self._parseUuid(request.job_id, "job_id")
            response_job_id = await self._async_markCancelRequested(
                job_id=job_id,
                reason=request.reason or "",
            )
            structuredLogger.info(
                "CancelJob completed",
                event="lumeflow.flow.cancel_job.completed",
                attrs=_flowEventAttrs(outcome="success"),
            )
            await self._async_sendMessage(
                stream,
                flow_server_pb2.CancelJobResponse(job_id=response_job_id),
            )

    async def CancelJob(
        self,
        stream: Stream[
            flow_server_pb2.CancelJobRequest,
            flow_server_pb2.CancelJobResponse,
        ],
    ) -> None:
        await self.async_cancelJob(stream)

    async def async_getJobStatus(
        self,
        stream: Stream[
            flow_server_pb2.GetJobStatusRequest,
            flow_server_pb2.GetJobStatusResponse,
        ],
    ) -> None:
        request = await self._async_recvRequest(stream, "GetJobStatus")
        with lumesof_logging.loggingContext(
            **{
                lumesof_logging.RPC_METHOD: "GetJobStatus",
                lumesof_logging.LUMESOF_CLUSTER_ID: str(self._cluster_id),
                lumesof_logging.LUMESOF_JOB_ID: request.job_id.strip(),
            }
        ):
            job_id = self._parseUuid(request.job_id, "job_id")
            status, message, updated_at = await self._async_getJobStatus(job_id)
            structuredLogger.debug(
                "GetJobStatus completed",
                event="lumeflow.flow.get_job_status.completed",
                attrs=_flowEventAttrs(outcome="success", job_status=status),
            )
            await self._async_sendMessage(
                stream,
                flow_server_pb2.GetJobStatusResponse(
                    job_id=str(job_id),
                    status=status,
                    message=message,
                    updated_at=updated_at,
                )
            )

    async def GetJobStatus(
        self,
        stream: Stream[
            flow_server_pb2.GetJobStatusRequest,
            flow_server_pb2.GetJobStatusResponse,
        ],
    ) -> None:
        await self.async_getJobStatus(stream)

    async def async_listJobs(
        self,
        stream: Stream[
            flow_server_pb2.ListRequest,
            flow_server_pb2.ListResponse,
        ],
    ) -> None:
        _ = await self._async_recvRequest(stream, "List")
        response = await self._async_listActiveJobs()
        await self._async_sendMessage(stream, response)

    async def List(
        self,
        stream: Stream[
            flow_server_pb2.ListRequest,
            flow_server_pb2.ListResponse,
        ],
    ) -> None:
        await self.async_listJobs(stream)

    async def async_injectMessage(
        self,
        stream: Stream[
            flow_server_pb2.InjectMessageRequest,
            flow_server_pb2.InjectMessageResponse,
        ],
    ) -> None:
        request = await self._async_recvRequest(stream, "InjectMessage")
        requestTraceId = (
            request.message.message_context.trace_id
            if request.HasField("message")
            and request.message.HasField("message_context")
            and request.message.message_context.trace_id
            else ""
        )
        contextAttrs = {
            lumesof_logging.RPC_METHOD: "InjectMessage",
            lumesof_logging.LUMESOF_CLUSTER_ID: str(self._cluster_id),
            lumesof_logging.LUMESOF_JOB_ID: request.job_id.strip(),
        }
        if requestTraceId:
            contextAttrs[lumesof_logging.TRACE_ID] = requestTraceId
        with lumesof_logging.loggingContext(**contextAttrs):
            response = await self._async_injectMessage(request)
            structuredLogger.debug(
                "InjectMessage completed",
                event="lumeflow.flow.inject_message.completed",
                attrs=_flowEventAttrs(outcome="success"),
            )
            await self._async_sendMessage(stream, response)

    async def InjectMessage(
        self,
        stream: Stream[
            flow_server_pb2.InjectMessageRequest,
            flow_server_pb2.InjectMessageResponse,
        ],
    ) -> None:
        await self.async_injectMessage(stream)

    async def async_maintain(
        self,
        stream: Stream[
            flow_server_pb2.MaintainRequest,
            flow_server_pb2.MaintainResponse,
        ],
    ) -> None:
        _ = await self._async_recvRequest(stream, "Maintain")
        logger.debug("Maintain received")
        await self._async_sendMessage(stream, flow_server_pb2.MaintainResponse(accepted=False))

    async def Maintain(
        self,
        stream: Stream[
            flow_server_pb2.MaintainRequest,
            flow_server_pb2.MaintainResponse,
        ],
    ) -> None:
        await self.async_maintain(stream)

    async def _async_recvRequest(
        self,
        stream: Stream[object, object],
        rpc_name: str,
    ) -> object:
        recv_message = getattr(stream, "async_recvMessage", None) or stream.recv_message
        request = await recv_message()
        if request is None:
            raise GRPCError(Status.INVALID_ARGUMENT, f"{rpc_name} request missing payload.")
        return request

    async def _async_sendMessage(self, stream: Stream[object, object], response: object) -> None:
        send_message = getattr(stream, "async_sendMessage", None) or stream.send_message
        await send_message(response)

    def _parseUuid(self, raw_value: str, field_name: str) -> uuid.UUID:
        if not raw_value:
            raise GRPCError(Status.INVALID_ARGUMENT, f"{field_name} must be provided.")
        try:
            return uuid.UUID(raw_value)
        except ValueError as exc:
            logger.warning(
                f"Invalid UUID field field_name={field_name} raw_value={raw_value}",
                exc_info=True,
            )
            raise GRPCError(Status.INVALID_ARGUMENT, f"{field_name} must be a valid UUID string.") from exc

    def _toJobStatusEnum(self, status: str) -> int:
        return {
            "SUBMITTED": flow_server_pb2.JOB_STATUS_SUBMITTED,
            "CREATED": flow_server_pb2.JOB_STATUS_CREATED,
            "READY": flow_server_pb2.JOB_STATUS_CREATED,
            "STARTED": flow_server_pb2.JOB_STATUS_STARTED,
            "FINISHED": flow_server_pb2.JOB_STATUS_FINISHED,
            "FAILED": flow_server_pb2.JOB_STATUS_FAILED,
            "CANCEL_PENDING": flow_server_pb2.JOB_STATUS_CANCEL_PENDING,
            "CANCELLED": flow_server_pb2.JOB_STATUS_CANCELLED,
        }.get(status, flow_server_pb2.JOB_STATUS_UNKNOWN)

    def _timestampFromDatetime(self, value: object) -> timestamp_pb2.Timestamp:
        timestamp = timestamp_pb2.Timestamp()
        if value is None:
            return timestamp
        if not hasattr(value, "tzinfo"):
            return timestamp
        dt_value = value
        if dt_value.tzinfo is None:
            dt_value = dt_value.replace(tzinfo=timezone.utc)
        else:
            dt_value = dt_value.astimezone(timezone.utc)
        timestamp.FromDatetime(dt_value)
        return timestamp

    async def _async_listActiveJobs(self) -> flow_server_pb2.ListResponse:
        terminal_statuses = ("FINISHED", "FAILED", "CANCELLED")
        async with self._session_maker() as session:
            try:
                rows = (
                    await session.execute(
                        select(
                            TabFlowJobs.id,
                            TabFlowJobs.status,
                            TabFlowJobs.owner,
                            TabFlowJobs.app_id,
                            TabFlowJobs.job_type,
                            TabFlowJobs.controller_id,
                            TabFlowJobs.substrate,
                            TabFlowJobs.bridge_ingress_link_ref,
                            TabFlowJobs.created_at,
                            TabFlowJobs.last_action_ts,
                        )
                        .where(TabFlowJobs.cluster_id == self._cluster_id)
                        .where(~TabFlowJobs.status.in_(terminal_statuses))
                        .order_by(TabFlowJobs.created_at.desc())
                    )
                ).all()
            except DBAPIError as exc:
                logger.exception("List failed reading active jobs.")
                raise GRPCError(Status.INTERNAL, "Database error while listing jobs.") from exc

        response = flow_server_pb2.ListResponse()
        for row in rows:
            job = response.jobs.add(
                job_id=str(row.id),
                status=self._toJobStatusEnum(row.status),
                owner=row.owner or "",
                app_id=row.app_id or "",
                job_type=row.job_type or "",
                controller_id=str(row.controller_id) if row.controller_id else "",
                substrate=row.substrate or "",
                injector_link_ref=row.bridge_ingress_link_ref or "",
            )
            job.created_at.CopyFrom(self._timestampFromDatetime(row.created_at))
            job.updated_at.CopyFrom(self._timestampFromDatetime(row.last_action_ts))
        return response

    async def _async_injectMessage(
        self,
        request: flow_server_pb2.InjectMessageRequest,
    ) -> flow_server_pb2.InjectMessageResponse:
        job_id = self._parseUuid(request.job_id, "job_id")
        if not request.HasField("message"):
            raise GRPCError(Status.INVALID_ARGUMENT, "message must be provided.")
        if not request.message.payload_type.SerializeToString():
            raise GRPCError(Status.INVALID_ARGUMENT, "message.payload_type must be provided.")
        trace_id = (
            request.message.message_context.trace_id
            if request.message.HasField("message_context")
            and request.message.message_context.trace_id
            else "<none>"
        )
        structuredLogger.debug(
            "InjectMessage request",
            event="lumeflow.flow.inject_message.request",
            attrs=_flowEventAttrs(
                outcome="start",
                job_id=str(job_id),
                trace_id=trace_id,
                payload_type=request.message.payload_type.type_url or "<none>",
            ),
        )

        async with self._session_maker() as session:
            try:
                row = (
                    await session.execute(
                        select(
                            TabFlowJobs.status,
                            TabFlowJobs.job_type,
                            TabFlowJobs.bridge_ingress_link_ref,
                        )
                        .where(TabFlowJobs.id == job_id)
                        .where(TabFlowJobs.cluster_id == self._cluster_id)
                        .limit(1)
                    )
                ).one_or_none()
            except DBAPIError as exc:
                logger.exception("InjectMessage failed reading job row")
                raise GRPCError(Status.INTERNAL, "Database error while loading job metadata.") from exc

        if row is None:
            raise GRPCError(Status.NOT_FOUND, "job_id is not found.")
        status, job_type, injector_link_ref = row
        if status != "STARTED":
            raise GRPCError(
                Status.FAILED_PRECONDITION,
                f"InjectMessage is allowed only for STARTED jobs. Current status={status}.",
            )
        if job_type != _JOB_TYPE_ASYNCHRONOUS:
            raise GRPCError(
                Status.FAILED_PRECONDITION,
                "InjectMessage is allowed only for ASYNCHRONOUS jobs.",
            )
        link_ref = (injector_link_ref or "").strip()
        if not link_ref:
            raise GRPCError(
                Status.FAILED_PRECONDITION,
                "InjectMessage requires a persisted injector link_ref.",
            )
        structuredLogger.debug(
            "InjectMessage resolved injector link",
            event="lumeflow.flow.inject_message.link_resolved",
            attrs=_flowEventAttrs(
                outcome="success",
                job_id=str(job_id),
                link_ref=link_ref,
                job_status=status,
            ),
        )

        opnet_request = opnet_controller_pb2.OpNetInjectMessageIntoLinkRequest(
            cluster_id=str(self._cluster_id),
            usecase="OPERATORS",
            link_ref=link_ref,
        )
        opnet_request.message.CopyFrom(request.message)
        structuredLogger.debug(
            "InjectMessage invoking opnet manager",
            event="lumeflow.flow.inject_message.dispatch",
            attrs=_flowEventAttrs(
                outcome="start",
                job_id=str(job_id),
                link_ref=link_ref,
                trace_id=trace_id,
            ),
        )
        try:
            inject_response = await self._dependencyRetry.async_retryUntilReady(
                operationName="FlowServer InjectMessage InjectMessageIntoLink",
                invocation=lambda: self._opnet_manager_client.InjectMessageIntoLink(opnet_request),
            )
        except RetryDeadlineExceededError as exc:
            raise GRPCError(Status.UNAVAILABLE, "OpNet manager is not ready.") from exc

        if not inject_response.result.ok:
            structuredLogger.debug(
                "InjectMessage rejected by opnet manager",
                event="lumeflow.flow.inject_message.rejected",
                attrs=_flowEventAttrs(
                    outcome="failure",
                    job_id=str(job_id),
                    link_ref=link_ref,
                    trace_id=trace_id,
                    exception=inject_response.result.message or "<none>",
                ),
            )
            raise GRPCError(
                Status.FAILED_PRECONDITION,
                inject_response.result.message or "InjectMessageIntoLink failed.",
            )
        structuredLogger.debug(
            "InjectMessage accepted by opnet manager",
            event="lumeflow.flow.inject_message.accepted",
            attrs=_flowEventAttrs(
                outcome="success",
                job_id=str(job_id),
                link_ref=link_ref,
                trace_id=trace_id,
            ),
        )
        return flow_server_pb2.InjectMessageResponse(
            accepted=True,
            details=inject_response.result.message or "",
        )

    async def _async_startJob(self, job_id: uuid.UUID) -> None:
        starter_id = uuid.uuid4()
        claimed = await self._async_tryClaimStartJob(job_id=job_id, starterId=starter_id)
        if not claimed:
            logger.warning(
                "StartJob claim precondition failed",
                extra=_flowLogAttrs(starter_id=starter_id),
            )
            raise GRPCError(Status.FAILED_PRECONDITION, self._buildStartJobPreconditionMessage())

        launch_plan = await self._async_loadStartJobLaunchPlan(job_id=job_id, starterId=starter_id)
        dag = launch_plan["dag"]
        try:
            launch_levels = FlowGraph(dag=dag).buildBfsLevels()
        except ValueError as exc:
            logger.warning(f"StartJob BFS failed: {exc}")
            raise GRPCError(Status.FAILED_PRECONDITION, str(exc))
        operator_by_name = launch_plan["operators"]
        instances_by_name = launch_plan["instances"]
        substrate = launch_plan["substrate"]
        node_ids = sorted(
            {node_id for instances in instances_by_name.values() for node_id, _ in instances}
        )
        try:
            hash_scheme, hash_value = await self._async_getOperatorSidecarLaunchRef(substrate=substrate)
        except GRPCError as exc:
            logger.warning(
                "StartJob failed resolving sidecar launch reference "
                f"starter_id={starter_id} status={exc.status} message={exc.message}",
                extra=_flowLogAttrs(starter_id=starter_id, status=exc.status),
            )
            if exc.status == Status.FAILED_PRECONDITION:
                await self._async_markJobFailed(job_id)
            raise
        for launch_level in launch_levels:
            level_semaphore = asyncio.Semaphore(self._startJobLaunchMaxParallelism)

            async def _async_launchOperatorInstanceInLevel(
                operator_name: str,
                node_id: str,
                executor_id: str,
            ) -> None:
                async with level_semaphore:
                    operator = operator_by_name[operator_name]
                    await self._async_launchSingleOperator(
                        jobId=job_id,
                        starterId=starter_id,
                        operatorName=operator_name,
                        nodeId=node_id,
                        executorId=executor_id,
                        operator=operator,
                        dag=dag,
                        hashScheme=hash_scheme,
                        hashValue=hash_value,
                        substrate=substrate,
                    )

            launch_operations: list[object] = []
            for operator_name in launch_level:
                for node_id, executor_id in instances_by_name[operator_name]:
                    launch_operations.append(
                        _async_launchOperatorInstanceInLevel(
                            operator_name,
                            node_id,
                            executor_id,
                        )
                    )
            launch_results = await asyncio.gather(
                *launch_operations,
                return_exceptions=True,
            )
            for launch_result in launch_results:
                if isinstance(launch_result, Exception):
                    if isinstance(launch_result, GRPCError):
                        raise launch_result
                    raise GRPCError(
                        Status.UNAVAILABLE,
                        "Failed launching one or more operators in a BFS level.",
                    ) from launch_result

            refreshed = await self._async_refreshStartJobLease(
                job_id=job_id,
                starterId=starter_id,
            )
            if not refreshed:
                logger.warning(
                    "StartJob lease refresh precondition failed",
                    extra=_flowLogAttrs(
                        starter_id=starter_id,
                        level_size=len(launch_level),
                    ),
                )
                raise GRPCError(Status.FAILED_PRECONDITION, self._buildStartJobPreconditionMessage())

        try:
            await self._async_waitForOperatorReadiness(
                job_id=job_id,
                starterId=starter_id,
                nodeIds=node_ids,
            )
        except Exception as exc:
            reason = self._formatStartJobFailureReason(exc)
            await self._async_handleStartJobFailure(
                job_id=job_id,
                starterId=starter_id,
                reason=reason,
            )
            raise

        marked_started = await self._async_markJobStarted(job_id=job_id, starterId=starter_id)
        if not marked_started:
            logger.warning(
                "StartJob mark-started precondition failed",
                extra=_flowLogAttrs(starter_id=starter_id),
            )
            raise GRPCError(Status.FAILED_PRECONDITION, self._buildStartJobPreconditionMessage())

    async def _async_launchSingleOperator(
        self,
        *,
        jobId: uuid.UUID,
        starterId: uuid.UUID,
        operatorName: str,
        nodeId: str,
        executorId: str,
        operator: dag_pb2.Operator,
        dag: dag_pb2.Dag,
        hashScheme: str,
        hashValue: str,
        substrate: str,
    ) -> None:
        ociCreds = await self._async_getOciRegistryCreds()
        operatorLaunchTimeoutSeconds = await self._async_getStartJobOperatorLaunchTimeoutSeconds()
        operatorNonresponsiveTimeoutSeconds = (
            await self._async_getStartJobOperatorNonresponsiveTimeoutSeconds()
        )
        request = self._buildExecutorLaunchRequest(
            executorId=executorId,
            nodeId=nodeId,
            operator=operator,
            dag=dag,
            hashScheme=hashScheme,
            hashValue=hashValue,
            substrate=substrate,
            ociCreds=ociCreds,
            operatorLaunchTimeoutSeconds=operatorLaunchTimeoutSeconds,
            operatorNonresponsiveTimeoutSeconds=operatorNonresponsiveTimeoutSeconds,
        )
        logger.debug(
            f"StartJob launch sending CAS reference "
            f"starter_id={starterId} operator_name={operatorName} "
            f"executor_id={executorId} node_id={nodeId} substrate={substrate} "
            f"hash_scheme={hashScheme} hash_value={hashValue}"
        )
        try:
            response = await self._dependencyRetry.async_retryUntilReady(
                operationName="FlowServer StartJob Launch",
                invocation=lambda: self._executor_control_client.Launch(request),
            )
        except RetryDeadlineExceededError as exc:
            raise GRPCError(
                Status.UNAVAILABLE,
                f"Executor control service is not ready for operator {operatorName}.",
            ) from exc
        except GRPCError:
            raise
        except Exception as exc:
            logger.warning(
                f"StartJob launch RPC failed "
                f"starter_id={starterId} operator_name={operatorName}",
                exc_info=True,
                extra=_flowLogAttrs(
                    starter_id=starterId,
                    **{
                        lumesof_logging.LUMESOF_EXECUTOR_ID: executorId,
                        lumesof_logging.LUMESOF_NODE_ID: nodeId,
                        lumesof_logging.LUMESOF_OPERATOR_NAME: operatorName,
                    },
                ),
            )
            raise GRPCError(Status.UNAVAILABLE, f"Failed launching operator {operatorName}.") from exc
        if response.status not in (
            executor_control_service_pb2.LAUNCH_STATUS_PENDING,
            executor_control_service_pb2.LAUNCH_STATUS_RUNNING,
        ):
            logger.warning(
                f"StartJob launch returned non-running status "
                f"starter_id={starterId} operator_name={operatorName} status={response.status}",
                extra=_flowLogAttrs(
                    starter_id=starterId,
                    **{
                        lumesof_logging.LUMESOF_EXECUTOR_ID: executorId,
                        lumesof_logging.LUMESOF_NODE_ID: nodeId,
                        lumesof_logging.LUMESOF_OPERATOR_NAME: operatorName,
                    },
                    status=response.status,
                ),
            )
            raise GRPCError(
                Status.INTERNAL,
                f"Executor launch failed for operator {operatorName}.",
            )

    async def _async_waitForOperatorReadiness(
        self,
        *,
        job_id: uuid.UUID,
        starterId: uuid.UUID,
        nodeIds: list[str],
    ) -> None:
        if not nodeIds:
            return
        timeout_seconds = await self._async_getStartJobOperatorReadyTimeoutSeconds()
        poll_interval = await self._async_getStartJobOperatorReadyPollIntervalSeconds()
        heartbeat_recency_seconds = await self._async_getStartJobOperatorReadyHeartbeatRecencySeconds()
        deadline = time.monotonic() + timeout_seconds
        logger.info(
            "StartJob waiting for operator readiness node_count=%s timeout_s=%s",
            len(nodeIds),
            timeout_seconds,
            extra=_flowLogAttrs(node_count=len(nodeIds), timeout_s=timeout_seconds),
        )

        while True:
            now = time.monotonic()
            if now >= deadline:
                raise GRPCError(
                    Status.DEADLINE_EXCEEDED,
                    "StartJob timed out waiting for operators to become RUNNING.",
                )

            min_heartbeat_millis = 0
            if heartbeat_recency_seconds > 0:
                min_heartbeat_millis = int((time.time() - heartbeat_recency_seconds) * 1000)

            request = opnet_controller_pb2.OpNetGetNodeStatusesRequest(
                node_ids=nodeIds,
                min_heartbeat_unix_millis=min_heartbeat_millis,
            )
            try:
                response = await self._dependencyRetry.async_retryUntilReady(
                    operationName="FlowServer StartJob GetNodeStatuses",
                    invocation=lambda request=request: self._opnet_manager_client.GetNodeStatuses(request),
                )
            except RetryDeadlineExceededError as exc:
                raise GRPCError(Status.UNAVAILABLE, "OpNet manager is not ready.") from exc
            except GRPCError:
                raise
            except Exception as exc:
                logger.warning(
                    "StartJob failed querying operator status",
                    exc_info=True,
                )
                raise GRPCError(Status.UNAVAILABLE, "Failed querying OpNet node status.") from exc

            entries_by_node = {entry.node_id: entry for entry in response.entries if entry.node_id}
            failed_entries: list[opnet_controller_pb2.OpNetNodeStatus] = []
            running_count = 0
            pending_count = 0
            for node_id in nodeIds:
                entry = entries_by_node.get(node_id)
                if entry is None or not entry.has_heartbeat:
                    pending_count += 1
                    continue
                if entry.status in (
                    opnet_types_pb2.DOWNLOAD_FAILED,
                    opnet_types_pb2.LAUNCH_FAILED,
                ):
                    failed_entries.append(entry)
                    continue
                if entry.status == opnet_types_pb2.RUNNING:
                    running_count += 1
                    continue
                pending_count += 1

            if failed_entries:
                failure_descriptions = ", ".join(
                    f"{entry.node_id}:{opnet_types_pb2.OperatorStatus.Name(entry.status)}"
                    for entry in failed_entries
                )
                raise GRPCError(
                    Status.FAILED_PRECONDITION,
                    f"StartJob detected operator launch failure: {failure_descriptions}.",
                )

            if running_count == len(nodeIds):
                logger.info(
                    "StartJob operators ready node_count=%s",
                    running_count,
                    extra=_flowLogAttrs(node_count=running_count),
                )
                return

            logger.debug(
                "StartJob waiting for operators running=%s pending=%s",
                running_count,
                pending_count,
                extra=_flowLogAttrs(running=running_count, pending=pending_count),
            )

            refreshed = await self._async_refreshStartJobLease(
                job_id=job_id,
                starterId=starterId,
            )
            if not refreshed:
                logger.warning(
                    "StartJob lease refresh precondition failed while waiting",
                    extra=_flowLogAttrs(starter_id=starterId),
                )
                raise GRPCError(Status.FAILED_PRECONDITION, self._buildStartJobPreconditionMessage())

            remaining = deadline - time.monotonic()
            if remaining <= 0:
                continue
            await asyncio.sleep(min(poll_interval, remaining))

    async def _async_tryClaimStartJob(self, *, job_id: uuid.UUID, starterId: uuid.UUID) -> bool:
        with _jobLoggingContext(jobId=job_id):
            lease_seconds = max(1, int(self._startJobLeaseSeconds))
            stale_interval = text(f"INTERVAL '{lease_seconds} seconds'")
            async with self._session_maker() as session:
                try:
                    async with _async_transaction(session):
                        result = await session.execute(
                            update(TabFlowJobs)
                            .where(
                                (TabFlowJobs.id == job_id)
                                & (TabFlowJobs.status == "CREATED")
                                & (
                                    (TabFlowJobs.job_starter_id.is_(None))
                                    | (TabFlowJobs.job_starter_ts.is_(None))
                                    | (TabFlowJobs.job_starter_ts <= (func.now() - stale_interval))
                                )
                            )
                            .values(
                                job_starter_id=starterId,
                                job_starter_ts=func.now(),
                                last_action_ts=func.now(),
                            )
                        )
                except DBAPIError:
                    logger.warning("StartJob claim failed", exc_info=True)
                    return False

            if result.rowcount != 1:
                logger.warning(
                    "StartJob claim update affected unexpected rows",
                    extra=_flowLogAttrs(starter_id=starterId, rowcount=result.rowcount),
                )
                return False

            async with self._session_maker() as session:
                try:
                    row = (
                        await session.execute(
                            select(
                                TabFlowJobs.status,
                                TabFlowJobs.job_starter_id,
                            ).where(TabFlowJobs.id == job_id)
                        )
                    ).one_or_none()
                except DBAPIError:
                    logger.warning("StartJob claim check failed", exc_info=True)
                    return False

            if row is None:
                logger.warning(
                    "StartJob claim check missing job row",
                    extra=_flowLogAttrs(starter_id=starterId),
                )
                return False
            status, claimed_starter_id = row
            if status != "CREATED" or str(claimed_starter_id) != str(starterId):
                logger.warning(
                    "StartJob claim check mismatch",
                    extra=_flowLogAttrs(
                        starter_id=starterId,
                        expected_status="CREATED",
                        actual_status=status,
                        actual_starter_id=claimed_starter_id,
                    ),
                )
                return False
            return True

    async def _async_loadStartJobLaunchPlan(
        self,
        *,
        job_id: uuid.UUID,
        starterId: uuid.UUID,
    ) -> dict[str, object]:
        with _jobLoggingContext(jobId=job_id):
            async with self._session_maker() as session:
                try:
                    job_row = (
                        await session.execute(
                            select(
                                TabFlowJobs.serialized_dag,
                                TabFlowJobs.status,
                                TabFlowJobs.job_starter_id,
                                TabFlowJobs.contains_loops,
                                TabFlowJobs.substrate,
                            ).where(TabFlowJobs.id == job_id)
                        )
                    ).one_or_none()
                except DBAPIError as exc:
                    logger.warning("StartJob failed reading job row", exc_info=True)
                    raise GRPCError(Status.INTERNAL, "Database error while preparing StartJob.") from exc

            if job_row is None:
                logger.warning(
                    "StartJob launch plan precondition failed missing job row",
                    extra=_flowLogAttrs(starter_id=starterId),
                )
                raise GRPCError(Status.FAILED_PRECONDITION, self._buildStartJobPreconditionMessage())
            serialized_dag, status, starter_id, contains_loops, substrate = job_row
            if status != "CREATED" or str(starter_id) != str(starterId):
                logger.warning(
                    "StartJob launch plan precondition failed job state mismatch",
                    extra=_flowLogAttrs(
                        starter_id=starterId,
                        expected_status="CREATED",
                        actual_status=status,
                        actual_starter_id=starter_id,
                    ),
                )
                raise GRPCError(Status.FAILED_PRECONDITION, self._buildStartJobPreconditionMessage())
            if substrate is None or not str(substrate).strip():
                logger.warning(
                    "StartJob launch plan missing substrate",
                    extra=_flowLogAttrs(starter_id=starterId),
                )
                raise GRPCError(Status.FAILED_PRECONDITION, "Job is not startable. Missing OpNet substrate.")

            try:
                dag_bytes = base64.b64decode(serialized_dag.encode("ascii"))
                dag = dag_pb2.Dag()
                dag.ParseFromString(dag_bytes)
                loaded_flow = FlowGraph(dag=dag)
                loaded_flow.validate(allowLoop=contains_loops)
            except Exception as exc:
                logger.warning(
                    "StartJob launch plan DAG validation failed",
                    exc_info=True,
                )
                raise GRPCError(Status.FAILED_PRECONDITION, "Job DAG is invalid.") from exc

            operators_by_name = {operator.name: operator for operator in dag.operators}
            async with self._session_maker() as session:
                try:
                    instance_rows = (
                        await session.execute(
                            select(
                                TabDagOperators.name,
                                TabOperatorInstances.node_id,
                                TabOperatorInstances.executor_id,
                            )
                            .join(
                                TabOperatorInstances,
                                TabOperatorInstances.operator_id == TabDagOperators.id,
                            )
                            .where(TabDagOperators.flow_job_id == job_id)
                            .order_by(TabDagOperators.name.asc(), TabOperatorInstances.node_id.asc())
                        )
                    ).all()
                except DBAPIError as exc:
                    logger.warning("StartJob failed reading operator instances", exc_info=True)
                    raise GRPCError(Status.INTERNAL, "Database error while loading operator instances.") from exc

            instances_by_name: dict[str, list[tuple[str, str]]] = {}
            for operator_name, node_id, executor_id in instance_rows:
                if not node_id or not executor_id:
                    logger.warning(
                        "StartJob launch plan missing operator instance fields",
                        extra=_flowLogAttrs(
                            operator_name=operator_name,
                            node_id=node_id,
                            executor_id=executor_id,
                        ),
                    )
                    raise GRPCError(
                        Status.FAILED_PRECONDITION,
                        "Job is not startable. Missing operator instance fields.",
                    )
                instances_by_name.setdefault(operator_name, []).append((str(node_id), str(executor_id)))

            missing = [name for name in operators_by_name if len(instances_by_name.get(name, [])) == 0]
            if missing:
                logger.warning(
                    "StartJob launch plan missing operator instances",
                    extra=_flowLogAttrs(missing_count=len(missing), missing=sorted(missing)),
                )
                raise GRPCError(
                    Status.FAILED_PRECONDITION,
                    "Job is not startable. Missing operator instances.",
                )

            return {
                "dag": dag,
                "operators": operators_by_name,
                "instances": instances_by_name,
                "substrate": str(substrate).strip(),
            }

    async def _async_refreshStartJobLease(self, *, job_id: uuid.UUID, starterId: uuid.UUID) -> bool:
        with _jobLoggingContext(jobId=job_id):
            async with self._session_maker() as session:
                try:
                    async with _async_transaction(session):
                        result = await session.execute(
                            update(TabFlowJobs)
                            .where(
                                (TabFlowJobs.id == job_id)
                                & (TabFlowJobs.status == "CREATED")
                                & (TabFlowJobs.job_starter_id == starterId)
                            )
                            .values(job_starter_ts=func.now(), last_action_ts=func.now())
                        )
                except DBAPIError:
                    logger.warning("StartJob failed updating lease", exc_info=True)
                    return False
            if result.rowcount != 1:
                logger.warning(
                    "StartJob lease refresh affected unexpected rows",
                    extra=_flowLogAttrs(starter_id=starterId, rowcount=result.rowcount),
                )
                return False
            return True

    async def _async_isStartJobClaimValid(self, *, job_id: uuid.UUID, starterId: uuid.UUID) -> bool:
        with _jobLoggingContext(jobId=job_id):
            async with self._session_maker() as session:
                try:
                    row = (
                        await session.execute(
                            select(
                                TabFlowJobs.status,
                                TabFlowJobs.job_starter_id,
                            ).where(TabFlowJobs.id == job_id)
                        )
                    ).one_or_none()
                except DBAPIError:
                    logger.warning(
                        "StartJob claim validation failed",
                        exc_info=True,
                        extra=_flowLogAttrs(starter_id=starterId),
                    )
                    return False

            if row is None:
                logger.warning(
                    "StartJob claim validation missing job row",
                    extra=_flowLogAttrs(starter_id=starterId),
                )
                return False
            status, claimed_starter_id = row
            return status == "CREATED" and str(claimed_starter_id) == str(starterId)

    async def _async_handleStartJobFailure(
        self,
        *,
        job_id: uuid.UUID,
        starterId: uuid.UUID,
        reason: str,
    ) -> None:
        with _jobLoggingContext(jobId=job_id):
            claim_valid = await self._async_isStartJobClaimValid(
                job_id=job_id,
                starterId=starterId,
            )
            if not claim_valid:
                logger.warning(
                    "StartJob failure skipped teardown because claim was lost",
                    extra=_flowLogAttrs(starter_id=starterId),
                )
                return

            await self._async_markJobFailed(job_id, reason=reason)
            try:
                await self._async_teardownJobResources(job_id=job_id)
            except Exception:
                logger.warning(
                    "StartJob teardown failed",
                    exc_info=True,
                    extra=_flowLogAttrs(starter_id=starterId),
                )

    async def _async_markJobStarted(self, *, job_id: uuid.UUID, starterId: uuid.UUID) -> bool:
        with _jobLoggingContext(jobId=job_id):
            async with self._session_maker() as session:
                try:
                    async with _async_transaction(session):
                        result = await session.execute(
                            update(TabFlowJobs)
                            .where(
                                (TabFlowJobs.id == job_id)
                                & (TabFlowJobs.status == "CREATED")
                                & (TabFlowJobs.job_starter_id == starterId)
                            )
                            .values(
                                status="STARTED",
                                last_action_ts=func.now(),
                                job_starter_ts=func.now(),
                            )
                        )
                except DBAPIError:
                    logger.warning("StartJob failed marking STARTED", exc_info=True)
                    return False
            if result.rowcount != 1:
                logger.warning(
                    "StartJob mark STARTED affected unexpected rows",
                    extra=_flowLogAttrs(starter_id=starterId, rowcount=result.rowcount),
                )
                return False
            return True

    def _buildExecutorLaunchRequest(
        self,
        *,
        executorId: str,
        nodeId: str,
        operator: dag_pb2.Operator,
        dag: dag_pb2.Dag,
        hashScheme: str,
        hashValue: str,
        substrate: str,
        ociCreds: tuple[str, str] | None = None,
        operatorLaunchTimeoutSeconds: float = DEFAULT_START_JOB_OPERATOR_LAUNCH_TIMEOUT_SECONDS,
        operatorNonresponsiveTimeoutSeconds: float = (
            DEFAULT_START_JOB_OPERATOR_NONRESPONSIVE_TIMEOUT_SECONDS
        ),
    ) -> executor_control_service_pb2.LaunchRequest:
        argv = ["__sidecar_cas_override__"]
        if self._includeOperatorDockerImageInSidecarArgv:
            argv.extend(["--docker-image", operator.image_url])
        argv.extend(
            [
                "--opnet-controller-target",
                self._opnetControllerTarget,
                "--opnet-node-id",
                nodeId,
            ]
        )
        if substrate == "grpc":
            if not self._sidecarGrpcOpnetTarget:
                logger.warning("StartJob grpc sidecar launch missing grpc opnet target")
                raise GRPCError(
                    Status.FAILED_PRECONDITION,
                    "StartJob grpc opnet target is not configured.",
                )
            argv.extend(["--grpc-opnet-target", self._sidecarGrpcOpnetTarget])
        if self._sidecarOtelLogsEndpoint:
            argv.extend(["--otel-logs-endpoint", self._sidecarOtelLogsEndpoint])
        argv.extend(
            [
                "--docker-launch-timeout-s",
                str(operatorLaunchTimeoutSeconds),
                "--operator-nonresponsive-timeout-s",
                str(operatorNonresponsiveTimeoutSeconds),
                "--operator-connect-max-attempts",
                str(self._sidecarOperatorConnectMaxAttempts),
                "--operator-connect-backoff-ms",
                str(self._sidecarOperatorConnectBackoffMs),
            ]
        )
        for port in operator.ports:
            if port.direction == dag_pb2.Port.INGRESS:
                if operator.name == dag.dag_ingress.operator and port.name == dag.dag_ingress.port:
                    direction = "INGRESS_BRIDGE"
                else:
                    direction = "INGRESS"
            elif port.direction == dag_pb2.Port.EGRESS:
                if (
                    dag.dag_egress.operator
                    and operator.name == dag.dag_egress.operator
                    and port.name == dag.dag_egress.port
                ):
                    direction = "EGRESS_BRIDGE"
                else:
                    direction = "EGRESS"
            else:
                logger.warning(f"StartJob invalid port direction direction={port.direction}")
                raise GRPCError(Status.FAILED_PRECONDITION, "Port direction is invalid for StartJob.")
            serialization = self._getSerializationName(port.payload_type.serialization_format)
            argv.extend(
                [
                    "--opnet-port",
                    f"{port.name},{direction},{port.payload_type.type_url},{serialization}",
                ]
            )
        params = {
            "--argv": json.dumps(argv),
        }
        env: dict[str, str] = {}
        env[_LUMESOF_LOGS_FILE_ENV] = f"{executorId}.log"
        if self._sidecarLogLevel:
            env[_LUMESOF_LOG_LEVEL_ENV] = self._sidecarLogLevel
        if self._sidecarOtelLogsEndpoint:
            env[_OTEL_EXPORTER_OTLP_ENDPOINT_ENV] = self._sidecarOtelLogsEndpoint
            params[_CREATE_PARAM_CAPTURE_FALLBACK_LOGS] = "true"
            params[_CREATE_PARAM_FALLBACK_OTLP_TARGET] = self._sidecarOtelLogsEndpoint
            params[_CREATE_PARAM_FALLBACK_LOG_BUFFER_BYTES] = str(
                DEFAULT_CARTOND_FALLBACK_LOG_BUFFER_BYTES
            )
        if ociCreds is not None:
            env[_OCI_REGISTRY_USER_NAME_ENV] = ociCreds[0]
            env[_OCI_REGISTRY_ACCESS_TOKEN_ENV] = ociCreds[1]
        if env:
            params["--env"] = json.dumps(env)
        return executor_control_service_pb2.LaunchRequest(
            executor_id=executorId,
            hash_scheme=hashScheme,
            hash_value=hashValue,
            params=params,
        )

    def _getPortDirectionName(self, direction: int) -> str:
        if direction == dag_pb2.Port.INGRESS:
            return "INGRESS"
        if direction == dag_pb2.Port.EGRESS:
            return "EGRESS"
        logger.warning(f"StartJob invalid port direction direction={direction}")
        raise GRPCError(Status.FAILED_PRECONDITION, "Port direction is invalid for StartJob.")

    def _getSerializationName(self, serialization_format: int) -> str:
        try:
            name = opnet_types_pb2.OpNetPayloadType.SerializationFormat.Name(serialization_format)
        except ValueError as exc:
            logger.warning(
                f"StartJob invalid payload serialization format value={serialization_format}"
            )
            raise GRPCError(Status.FAILED_PRECONDITION, "Port serialization format is invalid.") from exc
        if name == "SERIALIZATION_FORMAT_UNSPECIFIED":
            return "UNSPECIFIED"
        return name

    def _normalizeDagLinkType(self, *, link: dag_pb2.Link) -> str:
        if link.link_type in (dag_pb2.Link.LINK_TYPE_UNSPECIFIED, dag_pb2.Link.REGULAR):
            return _LINK_TYPE_REGULAR
        if link.link_type == dag_pb2.Link.SYNC_INJECTOR:
            return _LINK_TYPE_SYNC_INJECTOR
        if link.link_type == dag_pb2.Link.ASYNC_INJECTOR:
            return _LINK_TYPE_ASYNC_INJECTOR
        if link.link_type == dag_pb2.Link.SYNC_RETRIEVER:
            return _LINK_TYPE_SYNC_RETRIEVER
        logger.warning(f"Unsupported link_type value link_name={link.name} link_type={link.link_type}")
        raise ValueError(f'Unsupported link_type for link "{link.name}".')

    def _buildConfigServiceChannel(self) -> Channel:
        _parsed = NetTarget.parseTarget(self._configServiceTarget)
        if _parsed.getPath() is not None:
            return Channel(path=_parsed.getPath())
        if _parsed.getHost() is None or _parsed.getPort() is None:
            raise ValueError(f"configServiceTarget must include host and port: {self._configServiceTarget}")
        return Channel(host=_parsed.getHost(), port=_parsed.getPort())

    async def _async_getOptionalConfigFloat(
        self,
        *,
        key: str,
        fallback: float,
        minValue: float | None = None,
    ) -> float:
        if not self._configServiceTarget:
            return fallback
        channel: Channel | None = None
        try:
            channel = self._buildConfigServiceChannel()
            stub = config_query_server_grpc.ClusterConfigServiceStub(channel)
            try:
                response = await stub.GetConfig(
                    config_query_server_pb2.GetConfigRequest(key=key)
                )
            except GRPCError as exc:
                if exc.status == Status.NOT_FOUND:
                    return fallback
                raise
        except Exception:
            logger.warning(
                "StartJob config fetch failed key=%s; using fallback=%s",
                key,
                fallback,
                exc_info=True,
            )
            return fallback
        finally:
            if channel is not None:
                channel.close()

        if not response.HasField("entry"):
            return fallback
        value_kind = response.entry.value.WhichOneof("kind")
        if value_kind == "number_value":
            value = float(response.entry.value.number_value)
        elif value_kind == "string_value":
            try:
                value = float(response.entry.value.string_value.strip())
            except ValueError:
                logger.warning(
                    "StartJob config value must be a float key=%s value=%s; using fallback=%s",
                    key,
                    response.entry.value.string_value,
                    fallback,
                )
                return fallback
        else:
            logger.warning(
                "StartJob config value must be numeric key=%s kind=%s; using fallback=%s",
                key,
                value_kind or "<unset>",
                fallback,
            )
            return fallback

        if minValue is not None and value < minValue:
            logger.warning(
                "StartJob config value below minimum key=%s value=%s min=%s; using fallback=%s",
                key,
                value,
                minValue,
                fallback,
            )
            return fallback
        return value

    async def _async_getStartJobOperatorReadyTimeoutSeconds(self) -> float:
        if self._startJobOperatorReadyTimeoutSecondsResolved is not None:
            return self._startJobOperatorReadyTimeoutSecondsResolved
        async with self._startJobOperatorReadyConfigLock:
            if self._startJobOperatorReadyTimeoutSecondsResolved is not None:
                return self._startJobOperatorReadyTimeoutSecondsResolved
            resolved = await self._async_getOptionalConfigFloat(
                key=_START_JOB_OPERATOR_READY_TIMEOUT_CONFIG_KEY,
                fallback=self._startJobOperatorReadyTimeoutSeconds,
                minValue=0.1,
            )
            self._startJobOperatorReadyTimeoutSecondsResolved = resolved
            return resolved

    async def _async_getStartJobOperatorLaunchTimeoutSeconds(self) -> float:
        if self._startJobOperatorLaunchTimeoutSecondsResolved is not None:
            return self._startJobOperatorLaunchTimeoutSecondsResolved
        async with self._startJobOperatorReadyConfigLock:
            if self._startJobOperatorLaunchTimeoutSecondsResolved is not None:
                return self._startJobOperatorLaunchTimeoutSecondsResolved
            resolved = await self._async_getOptionalConfigFloat(
                key=_START_JOB_OPERATOR_LAUNCH_TIMEOUT_CONFIG_KEY,
                fallback=self._startJobOperatorLaunchTimeoutSeconds,
                minValue=0.1,
            )
            self._startJobOperatorLaunchTimeoutSecondsResolved = resolved
            return resolved

    async def _async_getStartJobOperatorNonresponsiveTimeoutSeconds(self) -> float:
        if self._startJobOperatorNonresponsiveTimeoutSecondsResolved is not None:
            return self._startJobOperatorNonresponsiveTimeoutSecondsResolved
        async with self._startJobOperatorReadyConfigLock:
            if self._startJobOperatorNonresponsiveTimeoutSecondsResolved is not None:
                return self._startJobOperatorNonresponsiveTimeoutSecondsResolved
            resolved = await self._async_getOptionalConfigFloat(
                key=_START_JOB_OPERATOR_NONRESPONSIVE_TIMEOUT_CONFIG_KEY,
                fallback=self._startJobOperatorNonresponsiveTimeoutSeconds,
                minValue=0.0,
            )
            self._startJobOperatorNonresponsiveTimeoutSecondsResolved = resolved
            return resolved

    async def _async_getStartJobOperatorReadyPollIntervalSeconds(self) -> float:
        if self._startJobOperatorReadyPollIntervalSecondsResolved is not None:
            return self._startJobOperatorReadyPollIntervalSecondsResolved
        async with self._startJobOperatorReadyConfigLock:
            if self._startJobOperatorReadyPollIntervalSecondsResolved is not None:
                return self._startJobOperatorReadyPollIntervalSecondsResolved
            resolved = await self._async_getOptionalConfigFloat(
                key=_START_JOB_OPERATOR_READY_POLL_INTERVAL_CONFIG_KEY,
                fallback=self._startJobOperatorReadyPollIntervalSeconds,
                minValue=0.1,
            )
            self._startJobOperatorReadyPollIntervalSecondsResolved = resolved
            return resolved

    async def _async_getStartJobOperatorReadyHeartbeatRecencySeconds(self) -> float:
        if self._startJobOperatorReadyHeartbeatRecencySecondsResolved is not None:
            return self._startJobOperatorReadyHeartbeatRecencySecondsResolved
        async with self._startJobOperatorReadyConfigLock:
            if self._startJobOperatorReadyHeartbeatRecencySecondsResolved is not None:
                return self._startJobOperatorReadyHeartbeatRecencySecondsResolved
            resolved = await self._async_getOptionalConfigFloat(
                key=_START_JOB_OPERATOR_READY_HEARTBEAT_RECENCY_CONFIG_KEY,
                fallback=self._startJobOperatorReadyHeartbeatRecencySeconds,
                minValue=0.0,
            )
            self._startJobOperatorReadyHeartbeatRecencySecondsResolved = resolved
            return resolved

    async def _async_getOciRegistryType(self) -> str:
        if self._ociRegistryType is not None:
            return self._ociRegistryType
        channel = self._buildConfigServiceChannel()
        try:
            stub = config_query_server_grpc.ClusterConfigServiceStub(channel)
            try:
                response = await stub.GetConfig(
                    config_query_server_pb2.GetConfigRequest(key=_OCI_REGISTRY_TYPE_CONFIG_KEY)
                )
                registry_type = response.entry.value.string_value.strip().lower()
            except GRPCError as exc:
                if exc.status == Status.NOT_FOUND:
                    registry_type = _OCI_REGISTRY_TYPE_NONE
                else:
                    raise
        finally:
            channel.close()
        self._ociRegistryType = registry_type
        logger.debug(f"OCI registry type resolved: {registry_type}")
        return registry_type

    async def _async_getOciRegistryCreds(self) -> tuple[str, str] | None:
        if not self._configServiceTarget:
            return None
        registry_type = await self._async_getOciRegistryType()
        if registry_type == _OCI_REGISTRY_TYPE_NONE:
            return None
        async with self._ociCredsLock:
            if (
                self._ociCreds is not None
                and time.time() + _OCI_TOKEN_REFRESH_WINDOW_SECONDS < self._ociCreds[2]
            ):
                return (self._ociCreds[0], self._ociCreds[1])
            if registry_type == _OCI_REGISTRY_TYPE_GCR:
                try:
                    username, token, expiry = await asyncio.get_running_loop().run_in_executor(
                        None, _fetchGceMetadataToken
                    )
                except Exception:
                    logger.warning("Failed to mint GCR access token from GCE metadata server", exc_info=True)
                    return None
            else:
                logger.warning(f"Unknown OCI registry type '{registry_type}'; skipping OCI auth")
                return None
            self._ociCreds = (username, token, expiry)
            logger.debug(f"Minted OCI registry token for type={registry_type} username={username}")
            return (username, token)

    async def _async_getOperatorSidecarLaunchRef(self, *, substrate: str) -> tuple[str, str]:
        if not self._opnetControllerTarget:
            logger.warning("StartJob sidecar launch reference missing opnet controller target")
            raise GRPCError(Status.FAILED_PRECONDITION, "StartJob opnet controller target is not configured.")
        normalized_substrate = substrate.strip()
        if not normalized_substrate:
            logger.warning("StartJob sidecar launch reference missing substrate")
            raise GRPCError(Status.FAILED_PRECONDITION, "StartJob substrate is not configured.")
        cached = self._sidecarLaunchRefBySubstrate.get(normalized_substrate)
        if cached is not None:
            return cached
        tag = f"opnet-substrate-{normalized_substrate}"
        async with self._sidecarLaunchRefLock:
            cached = self._sidecarLaunchRefBySubstrate.get(normalized_substrate)
            if cached is not None:
                return cached
            try:
                response = await self._dependencyRetry.async_retryUntilReady(
                    operationName="FlowServer sidecar launch ref CAS List",
                    invocation=lambda: self._cas_client.List(cas_pb2.ListRequest()),
                )
            except RetryDeadlineExceededError as exc:
                raise GRPCError(Status.UNAVAILABLE, "CAS service is not ready.") from exc
            for entry in response.artifacts.entries:
                metadata = entry.metadata
                if metadata.family != "opnet-sidecar":
                    continue
                if tag not in metadata.tags:
                    continue
                if not entry.hash_scheme or not entry.hash_value:
                    continue
                sidecar_ref = (entry.hash_scheme, entry.hash_value)
                self._sidecarLaunchRefBySubstrate[normalized_substrate] = sidecar_ref
                return sidecar_ref
        logger.warning(
            "StartJob sidecar launch reference not found for substrate=%s family=opnet-sidecar",
            normalized_substrate,
        )
        raise GRPCError(
            Status.FAILED_PRECONDITION,
            f"StartJob sidecar is not available for substrate '{normalized_substrate}'.",
        )

    def _buildStartJobPreconditionMessage(self) -> str:
        lease_seconds = int(self._startJobLeaseSeconds)
        return (
            "Job is not startable. If this is unexpected, "
            f"please wait {lease_seconds} seconds and try again"
        )

    def _formatStartJobFailureReason(self, exc: Exception) -> str:
        if isinstance(exc, GRPCError):
            if exc.message:
                return exc.message
            return f"StartJob failed with status={exc.status}"
        message = str(exc).strip()
        if message:
            return message
        return exc.__class__.__name__

    async def _async_getJobStatus(
        self,
        job_id: uuid.UUID,
    ) -> tuple[int, str, timestamp_pb2.Timestamp]:
        with _jobLoggingContext(jobId=job_id):
            async with self._session_maker() as session:
                try:
                    row = (
                        await session.execute(
                            select(
                                TabFlowJobs.status,
                                TabFlowJobs.last_action_ts,
                                TabFlowJobs.job_termination_reason,
                            ).where(TabFlowJobs.id == job_id)
                        )
                    ).one_or_none()
                except DBAPIError as exc:
                    logger.exception("GetJobStatus failed database error")
                    raise GRPCError(Status.INTERNAL, "Database error while fetching job status.") from exc

            if row is None:
                logger.warning("GetJobStatus missing job row")
                raise GRPCError(Status.NOT_FOUND, "job_id is not found.")

            status, last_action_ts, termination_reason = row
            timestamp = self._timestampFromDatetime(last_action_ts)
            return self._toJobStatusEnum(status), (termination_reason or ""), timestamp

    async def _async_markCancelRequested(
        self,
        *,
        job_id: uuid.UUID,
        reason: str,
    ) -> str:
        with _jobLoggingContext(jobId=job_id):
            async with self._session_maker() as session:
                try:
                    row = (
                        await session.execute(
                            select(TabFlowJobs.status).where(TabFlowJobs.id == job_id)
                        )
                    ).one_or_none()
                except DBAPIError as exc:
                    logger.exception("CancelJob failed reading job row")
                    raise GRPCError(Status.INTERNAL, "Database error while cancelling job.") from exc

            if row is None:
                logger.warning("CancelJob missing job row")
                raise GRPCError(Status.NOT_FOUND, "job_id is not found.")
            (status,) = row
            if status in ("FINISHED", "FAILED"):
                raise GRPCError(Status.FAILED_PRECONDITION, f"Cannot cancel terminal job with status={status}.")
            if status == "CANCELLED":
                return str(job_id)
            if status == "CANCEL_PENDING":
                return str(job_id)

            async with self._session_maker() as session:
                try:
                    async with _async_transaction(session):
                        result = await session.execute(
                            update(TabFlowJobs)
                            .where(
                                (TabFlowJobs.id == job_id)
                                & (
                                    TabFlowJobs.status.in_(
                                        ["SUBMITTED", "CREATED", "READY", "STARTED", "CANCEL_PENDING"]
                                    )
                                )
                            )
                            .values(
                                status="CANCEL_PENDING",
                                last_action_ts=func.now(),
                                job_termination_reason=reason or None,
                            )
                        )
                except DBAPIError as exc:
                    logger.exception("CancelJob failed updating job row")
                    raise GRPCError(Status.INTERNAL, "Database error while cancelling job.") from exc

            if result.rowcount != 1:
                logger.warning(
                    "CancelJob update race encountered",
                    extra=_flowLogAttrs(rowcount=result.rowcount),
                )
            return str(job_id)

    async def _async_teardownJobResources(
        self,
        *,
        job_id: uuid.UUID,
        expectedStatus: str | None = None,
        finalStatus: str | None = None,
        terminationReason: str | None = None,
    ) -> None:
        with _jobLoggingContext(jobId=job_id):
            async with self._session_maker() as session:
                try:
                    row = (
                        await session.execute(
                            select(TabFlowJobs.status, TabFlowJobs.controller_id)
                            .where(TabFlowJobs.id == job_id)
                        )
                    ).one_or_none()
                except DBAPIError:
                    logger.warning("Flow teardown failed reading job row", exc_info=True)
                    return
            if row is None:
                logger.debug("Flow teardown skipping missing job row")
                return

            status, controller_id = row
            if expectedStatus is not None and status != expectedStatus:
                logger.debug(
                    "Flow teardown skipping unexpected status=%s expected=%s",
                    status,
                    expectedStatus,
                    extra=_flowLogAttrs(expected_status=expectedStatus, actual_status=status),
                )
                return

            controllerReferenceCleared = False
            async with self._session_maker() as session:
                try:
                    async with _async_transaction(session):
                        update_stmt = update(TabFlowJobs).where(TabFlowJobs.id == job_id)
                        if expectedStatus is not None:
                            update_stmt = update_stmt.where(TabFlowJobs.status == expectedStatus)
                        result = await session.execute(
                            update_stmt.values(
                                controller_id=None,
                                substrate=None,
                                last_action_ts=func.now(),
                            )
                        )
                        controllerReferenceCleared = result.rowcount == 1
                except DBAPIError:
                    logger.warning(
                        "Flow teardown failed clearing controller reference",
                        exc_info=True,
                    )

            async with self._session_maker() as session:
                try:
                    operator_rows = (
                        await session.execute(
                            select(
                                TabOperatorInstances.executor_id,
                                TabDagOperators.id,
                            )
                            .join(
                                TabDagOperators,
                                TabOperatorInstances.operator_id == TabDagOperators.id,
                            )
                            .where(TabDagOperators.flow_job_id == job_id)
                        )
                    ).all()
                except DBAPIError:
                    logger.warning("Flow teardown failed reading operator instances", exc_info=True)
                    operator_rows = []

            executor_ids: list[uuid.UUID] = []
            for executor_id, _ in operator_rows:
                if executor_id is not None:
                    executor_ids.append(executor_id)

            async with self._session_maker() as session:
                try:
                    async with _async_transaction(session):
                        operator_subquery = (
                            select(TabDagOperators.id).where(TabDagOperators.flow_job_id == job_id)
                        )
                        await session.execute(
                            delete(TabOperatorInstances).where(
                                TabOperatorInstances.operator_id.in_(operator_subquery)
                            )
                        )
                        await session.execute(delete(TabDagLinks).where(TabDagLinks.flow_job_id == job_id))
                        await session.execute(delete(TabDagOperators).where(TabDagOperators.flow_job_id == job_id))
                        await session.execute(
                            update(TabFlowJobs)
                            .where(TabFlowJobs.id == job_id)
                            .values(last_action_ts=func.now())
                        )
                except DBAPIError:
                    logger.warning("Flow teardown failed deleting flow resources", exc_info=True)

            destroy_semaphore = asyncio.Semaphore(self._cancelJobDestroyMaxParallelism)

            async def _async_destroyExecutor(executor_id: uuid.UUID) -> None:
                async with destroy_semaphore:
                    try:
                        await self._dependencyRetry.async_retryUntilReady(
                            operationName="FlowServer FlowTeardown Destroy",
                            invocation=lambda executor_id=executor_id: self._executor_control_client.Destroy(
                                executor_control_service_pb2.DestroyRequest(executor_id=str(executor_id))
                            ),
                        )
                    except GRPCError as exc:
                        if exc.status != Status.NOT_FOUND:
                            logger.warning(
                                "Flow teardown executor destroy failed status=%s message=%s",
                                exc.status,
                                exc.message,
                                extra=_flowLogAttrs(
                                    executor_id=executor_id,
                                    status=exc.status,
                                ),
                            )
                    except Exception:
                        logger.warning(
                            "Flow teardown executor destroy failed",
                            exc_info=True,
                            extra=_flowLogAttrs(executor_id=executor_id),
                        )

            await asyncio.gather(*[_async_destroyExecutor(eid) for eid in executor_ids])

            if controller_id is not None and controllerReferenceCleared:
                try:
                    await self._dependencyRetry.async_retryUntilReady(
                        operationName="FlowServer FlowTeardown DestroyControllerResources",
                        invocation=lambda: self._opnet_manager_client.DestroyControllerResources(
                            opnet_controller_pb2.OpNetDestroyControllerResourcesRequest(
                                cluster_id=str(self._cluster_id),
                                usecase="OPERATORS",
                                controller_id=str(controller_id),
                            )
                        ),
                    )
                except Exception:
                    logger.warning(
                        "Flow teardown opnet teardown failed",
                        exc_info=True,
                        extra=_flowLogAttrs(controller_id=controller_id),
                    )
            elif controller_id is not None:
                logger.warning(
                    "Flow teardown skipping opnet teardown because controller reference was not cleared",
                    extra=_flowLogAttrs(controller_id=controller_id),
                )

            if finalStatus is None:
                return

            async with self._session_maker() as session:
                try:
                    async with _async_transaction(session):
                        update_stmt = update(TabFlowJobs).where(TabFlowJobs.id == job_id)
                        if expectedStatus is not None:
                            update_stmt = update_stmt.where(TabFlowJobs.status == expectedStatus)
                        update_values: dict[str, object] = {
                            "status": finalStatus,
                            "last_action_ts": func.now(),
                        }
                        if terminationReason is not None:
                            update_values["job_termination_reason"] = terminationReason or None
                        await session.execute(update_stmt.values(**update_values))
                except DBAPIError:
                    logger.warning(
                        "Flow teardown failed marking final status status=%s",
                        finalStatus,
                        exc_info=True,
                        extra=_flowLogAttrs(status=finalStatus),
                    )

    async def _async_finalizeCancelledJob(self, job_id: uuid.UUID) -> None:
        await self._async_teardownJobResources(
            job_id=job_id,
            expectedStatus="CANCEL_PENDING",
            finalStatus="CANCELLED",
        )

    async def async_createFlowJob(self, job_id: uuid.UUID) -> int:
        with lumesof_logging.loggingContext(
            **{
                lumesof_logging.LUMESOF_JOB_ID: str(job_id),
            }
        ):
            structuredLogger.info(
                "CreateFlowJob start",
                event="lumeflow.flow.create_flow_job.start",
                attrs=_flowEventAttrs(outcome="start"),
            )
            async with self._session_maker() as session:
                try:
                    async with _async_transaction(session):
                        row = (
                            await session.execute(
                                select(
                                TabFlowJobs.status,
                                TabFlowJobs.last_action_ts,
                                TabFlowJobs.controller_id,
                                TabFlowJobs.serialized_dag,
                                TabFlowJobs.contains_loops,
                                TabFlowJobs.app_id,
                                TabFlowJobs.job_type,
                                (
                                    TabFlowJobs.last_action_ts
                                    <= (func.now() - text("INTERVAL '60 seconds'"))
                                    ).label("is_stale"),
                                ).where(TabFlowJobs.id == job_id)
                            )
                        ).one_or_none()
                        if row is None:
                            logger.warning("CreateFlowJob missing job row")
                            return flow_server_pb2.JOB_STATUS_UNKNOWN

                        (
                            status,
                            last_action_ts,
                            controller_id,
                            serialized_dag,
                            contains_loops,
                            app_id,
                            persisted_job_type,
                            is_stale,
                        ) = row
                        if last_action_ts is not None and last_action_ts.tzinfo is not None:
                            last_action_ts = last_action_ts.astimezone(timezone.utc).replace(tzinfo=None)
                        if status != "SUBMITTED":
                            logger.debug(f"CreateFlowJob skipping non-submitted status={status}")
                            return flow_server_pb2.JOB_STATUS_UNKNOWN
                        if not is_stale:
                            logger.debug("CreateFlowJob skipping recent last_action_ts")
                            return flow_server_pb2.JOB_STATUS_UNKNOWN

                        update_stmt = (
                            update(TabFlowJobs)
                            .where(
                                (TabFlowJobs.id == job_id)
                                & (TabFlowJobs.status == "SUBMITTED")
                                & (TabFlowJobs.last_action_ts == last_action_ts)
                            )
                            .values(last_action_ts=func.now())
                        )
                        result = await session.execute(update_stmt)
                        if result.rowcount != 1:
                            logger.warning(f"CreateFlowJob claim update affected {result.rowcount} rows")
                            return flow_server_pb2.JOB_STATUS_UNKNOWN
                except DBAPIError:
                    logger.warning("CreateFlowJob database error", exc_info=True)
                    return flow_server_pb2.JOB_STATUS_UNKNOWN

            structuredLogger.debug(
                "CreateFlowJob claimed",
                event="lumeflow.flow.create_flow_job.claimed",
                attrs=_flowEventAttrs(outcome="success"),
            )
            try:
                dag_bytes = base64.b64decode(serialized_dag.encode("ascii"))
                dag = dag_pb2.Dag()
                dag.ParseFromString(dag_bytes)
                loaded_flow = FlowGraph(dag=dag)
                loaded_flow.validate(allowLoop=loaded_flow.getAllowLoops())
                inferred_job_type = self._inferAndValidateJobType(loaded_flow=loaded_flow, app_id=app_id)
                structuredLogger.debug(
                    "CreateFlowJob dag validated",
                    event="lumeflow.flow.create_flow_job.dag_validated",
                    attrs=_flowEventAttrs(outcome="success", app_id=app_id),
                )
            except Exception:
                logger.warning("CreateFlowJob failed to parse or validate dag", exc_info=True)
                await self._async_markJobFailed(job_id)
                return flow_server_pb2.JOB_STATUS_FAILED

            if persisted_job_type and persisted_job_type != inferred_job_type:
                logger.warning(
                    f"CreateFlowJob job_type mismatch "
                    f"persisted={persisted_job_type} inferred={inferred_job_type}"
                )
                await self._async_markJobFailed(job_id)
                return flow_server_pb2.JOB_STATUS_FAILED
            if persisted_job_type != inferred_job_type:
                async with self._session_maker() as session:
                    try:
                        async with _async_transaction(session):
                            await session.execute(
                                update(TabFlowJobs)
                                .where(TabFlowJobs.id == job_id)
                                .values(job_type=inferred_job_type, last_action_ts=func.now())
                            )
                    except DBAPIError:
                        logger.warning(
                            f"CreateFlowJob failed to persist inferred job_type "
                            f"inferred={inferred_job_type}",
                            exc_info=True,
                        )
                        await self._async_markJobFailed(job_id)
                        return flow_server_pb2.JOB_STATUS_FAILED

            structuredLogger.info(
                "CreateFlowJob stage begin",
                event="lumeflow.flow.create_flow_job.stage.begin",
                attrs=_flowEventAttrs(outcome="start", stage="CreateFlowJobController"),
            )
            controller_step_status = await self._async_createFlowJobController(job_id)
            if controller_step_status == flow_server_pb2.JOB_STATUS_FAILED:
                structuredLogger.error(
                    "CreateFlowJob stage failed",
                    event="lumeflow.flow.create_flow_job.stage.failed",
                    attrs=_flowEventAttrs(outcome="failure", stage="CreateFlowJobController"),
                )
                return controller_step_status

            structuredLogger.info(
                "CreateFlowJob stage begin",
                event="lumeflow.flow.create_flow_job.stage.begin",
                attrs=_flowEventAttrs(outcome="start", stage="CreateDagOperators"),
            )
            operators_ok = await self._async_createDagOperators(job_id, dag)
            if not operators_ok:
                structuredLogger.error(
                    "CreateFlowJob stage failed",
                    event="lumeflow.flow.create_flow_job.stage.failed",
                    attrs=_flowEventAttrs(outcome="failure", stage="CreateDagOperators"),
                )
                return flow_server_pb2.JOB_STATUS_FAILED

            structuredLogger.info(
                "CreateFlowJob stage begin",
                event="lumeflow.flow.create_flow_job.stage.begin",
                attrs=_flowEventAttrs(outcome="start", stage="CreateDagLinks"),
            )
            try:
                links_ok = await self._async_createDagLinks(job_id, dag)
            except Exception:
                structuredLogger.exception(
                    "CreateFlowJob stage exception",
                    event="lumeflow.flow.create_flow_job.stage.exception",
                    attrs=_flowEventAttrs(outcome="failure", stage="CreateDagLinks"),
                )
                await self._async_markJobFailed(job_id)
                return flow_server_pb2.JOB_STATUS_FAILED
            if not links_ok:
                structuredLogger.error(
                    "CreateFlowJob stage failed",
                    event="lumeflow.flow.create_flow_job.stage.failed",
                    attrs=_flowEventAttrs(outcome="failure", stage="CreateDagLinks"),
                )
                return flow_server_pb2.JOB_STATUS_FAILED

            structuredLogger.info(
                "CreateFlowJob stage begin",
                event="lumeflow.flow.create_flow_job.stage.begin",
                attrs=_flowEventAttrs(outcome="start", stage="CreateOperatorInstances"),
            )
            instances_ok = await self._async_createOperatorInstances(job_id, dag)
            if not instances_ok:
                structuredLogger.error(
                    "CreateFlowJob stage failed",
                    event="lumeflow.flow.create_flow_job.stage.failed",
                    attrs=_flowEventAttrs(outcome="failure", stage="CreateOperatorInstances"),
                )
                return flow_server_pb2.JOB_STATUS_FAILED

            structuredLogger.info(
                "CreateFlowJob stage begin",
                event="lumeflow.flow.create_flow_job.stage.begin",
                attrs=_flowEventAttrs(outcome="start", stage="MarkCreated"),
            )
            return await self._async_markJobCreated(job_id)

    async def _async_markJobFailed(self, job_id: uuid.UUID, *, reason: str | None = None) -> None:
        with _jobLoggingContext(jobId=job_id):
            logger.error(
                "Marking job failed reason=%s",
                reason or "<none>",
                extra=_flowLogAttrs(exception=reason or "<none>"),
            )
            async with self._session_maker() as session:
                try:
                    async with _async_transaction(session):
                        update_values: dict[str, object] = {
                            "status": "FAILED",
                            "last_action_ts": func.now(),
                        }
                        if reason is not None:
                            update_values["job_termination_reason"] = reason or None
                        await session.execute(
                            update(TabFlowJobs)
                            .where(TabFlowJobs.id == job_id)
                            .values(**update_values)
                        )
                    logger.debug("Marked job failed")
                except DBAPIError:
                    logger.exception("Failed to mark job failed")

    async def _async_markJobCreated(self, job_id: uuid.UUID) -> int:
        with _jobLoggingContext(jobId=job_id):
            async with self._session_maker() as session:
                try:
                    async with _async_transaction(session):
                        result = await session.execute(
                            update(TabFlowJobs)
                            .where(
                                (TabFlowJobs.id == job_id)
                                & (TabFlowJobs.status == "SUBMITTED")
                            )
                            .values(status="CREATED", last_action_ts=func.now())
                        )
                except DBAPIError:
                    logger.warning("CreateFlowJob failed to mark job created", exc_info=True)
                    return flow_server_pb2.JOB_STATUS_UNKNOWN

            if result.rowcount == 1:
                return flow_server_pb2.JOB_STATUS_CREATED
            return await self._async_getJobStatus(job_id)

    async def _async_createFlowJobController(self, job_id: uuid.UUID) -> int:
        async with self._session_maker() as session:
            try:
                row = (
                    await session.execute(
                        select(TabFlowJobs.controller_id).where(TabFlowJobs.id == job_id)
                    )
                ).one_or_none()
            except DBAPIError:
                logger.warning("CreateFlowJobController database error", exc_info=True)
                return flow_server_pb2.JOB_STATUS_UNKNOWN

        if row is None:
            logger.warning("CreateFlowJobController missing job row")
            return flow_server_pb2.JOB_STATUS_UNKNOWN

        (controller_id,) = row
        if controller_id is not None:
            logger.debug(f"CreateFlowJobController reusing existing controller controller_id={controller_id}")
            return flow_server_pb2.JOB_STATUS_CREATED

        if self._opnet_manager_client is None:
            logger.warning("CreateFlowJobController missing opnet manager client")
            await self._async_markJobFailed(job_id)
            return flow_server_pb2.JOB_STATUS_FAILED

        controller_name = f"contoller-{str(job_id)}"
        create_request = opnet_controller_pb2.OpNetCreateControllerRequest(
            cluster_id=str(self._cluster_id),
            usecase="OPERATORS",
            name=controller_name,
        )
        try:
            response = await self._dependencyRetry.async_retryUntilReady(
                operationName="FlowServer CreateFlowJobController CreateController",
                invocation=lambda: self._opnet_manager_client.CreateController(create_request),
            )
        except RetryDeadlineExceededError:
            logger.warning(
                "CreateFlowJobController opnet manager not ready before deadline",
                exc_info=True,
            )
            await self._async_markJobFailed(job_id)
            return flow_server_pb2.JOB_STATUS_FAILED
        except Exception:
            logger.warning("CreateFlowJobController failed to create controller", exc_info=True)
            await self._async_markJobFailed(job_id)
            return flow_server_pb2.JOB_STATUS_FAILED

        try:
            controller_id = uuid.UUID(response.controller_id)
        except Exception:
            logger.warning(
                f"CreateFlowJobController returned invalid controller id "
                f"value={getattr(response, 'controller_id', None)}",
                exc_info=True,
            )
            await self._async_markJobFailed(job_id)
            return flow_server_pb2.JOB_STATUS_FAILED
        substrate = response.substrate.strip() or None
        logger.debug(f"CreateFlowJobController created controller controller_id={controller_id}")

        async with self._session_maker() as session:
            try:
                async with _async_transaction(session):
                    result = await session.execute(
                        update(TabFlowJobs)
                        .where(
                            (TabFlowJobs.id == job_id)
                            & (TabFlowJobs.controller_id.is_(None))
                            & (TabFlowJobs.status == "SUBMITTED")
                        )
                        .values(
                            controller_id=controller_id,
                            substrate=substrate,
                            last_action_ts=func.now(),
                        )
                    )
                    if result.rowcount != 1:
                        logger.warning(f"CreateFlowJobController final update affected {result.rowcount} rows")
                        return await self._async_checkControllerCreated(job_id)
            except DBAPIError:
                logger.warning("CreateFlowJobController failed to persist controller", exc_info=True)
                return flow_server_pb2.JOB_STATUS_UNKNOWN

        logger.info(f"CreateFlowJobController updated job controller_id={controller_id}")
        return flow_server_pb2.JOB_STATUS_CREATED

    async def _async_createDagOperators(self, job_id: uuid.UUID, dag: dag_pb2.Dag) -> bool:
        async with self._session_maker() as session:
            try:
                async with _async_transaction(session):
                    await session.execute(
                        update(TabFlowJobs)
                        .where(TabFlowJobs.id == job_id)
                        .values(last_action_ts=func.now())
                    )
                    row = (
                        await session.execute(
                            select(TabFlowJobs.id).where(TabFlowJobs.id == job_id)
                        )
                    ).one_or_none()
            except DBAPIError:
                logger.warning("CreateDagOperators database error", exc_info=True)
                return True

        if row is None:
            logger.warning("CreateDagOperators missing job row")
            return True

        desired = []
        for op in dag.operators:
            if not op.name:
                logger.warning("CreateDagOperators missing operator name")
                await self._async_markJobFailed(job_id)
                return False
            if not op.image_url:
                logger.warning(f"CreateDagOperators missing operator image_url name={op.name}")
                await self._async_markJobFailed(job_id)
                return False
            policy_bytes = self._serializeOperatorInstancePolicy(op)
            desired.append(
                {
                    "flow_job_id": job_id,
                    "name": op.name,
                    "image_url": op.image_url,
                    "is_entry_point": False,  # dag_ingress on Dag is the source of truth; column retained for schema compat
                    "info": None,
                    "serialized_operator": op.SerializeToString(),
                    "policy": policy_bytes,
                }
            )

        async with self._session_maker() as session:
            try:
                existing_rows = (
                    await session.execute(
                        select(TabDagOperators.name).where(TabDagOperators.flow_job_id == job_id)
                    )
                ).all()
            except DBAPIError:
                logger.warning("CreateDagOperators failed reading existing operators", exc_info=True)
                return True

        existing = {name for (name,) in existing_rows}
        missing = [item for item in desired if item["name"] not in existing]
        if missing:
            async def _async_persist(batch):
                async with self._session_maker() as session:
                    async with _async_transaction(session):
                        await session.execute(insert(TabDagOperators), batch)

            try:
                _, failures = await sqldb_utils.async_partitionOnIntegrityErrors(
                    missing,
                    _async_persist,
                    reason_fn=lambda exc: str(exc.orig),
                )
            except DBAPIError:
                logger.warning("CreateDagOperators failed inserting operators", exc_info=True)
                return True
            if failures:
                logger.debug(f"CreateDagOperators ignored {len(failures)} operator insert failures")

        async with self._session_maker() as session:
            try:
                async with _async_transaction(session):
                    await session.execute(
                        update(TabFlowJobs)
                        .where(TabFlowJobs.id == job_id)
                        .values(last_action_ts=func.now())
                    )
            except DBAPIError:
                logger.warning("CreateDagOperators failed to update last_action_ts", exc_info=True)
                return True

        logger.info(f"CreateDagOperators completed missing={len(missing)}")
        return True

    def _serializeOperatorInstancePolicy(self, operator: dag_pb2.Operator) -> bytes:
        policy = dag_pb2.OperatorInstancePolicy(
            num_min_instances=1,
            num_max_instances=1,
        )
        policy.MergeFrom(operator.instance_policy)
        return policy.SerializeToString()

    def _instanceCountFromPolicyBytes(self, policy_bytes: bytes | memoryview | None) -> int:
        if not policy_bytes:
            return 1
        if isinstance(policy_bytes, memoryview):
            policy_bytes = bytes(policy_bytes)
        policy = dag_pb2.OperatorInstancePolicy()
        try:
            policy.ParseFromString(policy_bytes)
        except Exception:
            return 1
        if policy.num_min_instances <= 0:
            return 1
        return int(policy.num_min_instances)

    async def _async_createDagLinks(self, job_id: uuid.UUID, dag: dag_pb2.Dag) -> bool:
        logger.debug(f"CreateDagLinks begin dag_link_count={len(dag.links)}")
        async with self._session_maker() as session:
            try:
                async with _async_transaction(session):
                    await session.execute(
                        update(TabFlowJobs)
                        .where(TabFlowJobs.id == job_id)
                        .values(last_action_ts=func.now())
                    )
                    row = (
                        await session.execute(
                            select(TabFlowJobs.controller_id)
                            .where(TabFlowJobs.id == job_id)
                        )
                    ).one_or_none()
            except DBAPIError:
                logger.warning("CreateDagLinks database error", exc_info=True)
                return True

        if row is None:
            logger.warning("CreateDagLinks missing job row")
            return True

        (controller_id,) = row
        if controller_id is None:
            logger.warning("CreateDagLinks missing controller")
            await self._async_markJobFailed(job_id)
            return False

        desired = []
        for link in dag.links:
            if not link.name:
                logger.warning("CreateDagLinks missing link name")
                await self._async_markJobFailed(job_id)
                return False
            try:
                link_type = self._normalizeDagLinkType(link=link)
            except ValueError:
                logger.warning(
                    f"CreateDagLinks unsupported link type link_name={link.name}",
                    exc_info=True,
                )
                await self._async_markJobFailed(job_id)
                return False
            egress_operator = link.egress_operator or None
            egress_port = link.egress_port or None
            ingress_operator = link.ingress_operator or None
            ingress_port = link.ingress_port or None
            logger.debug(
                f"CreateDagLinks parsed link "
                f"link_name={link.name} link_type={link_type} "
                f"egress_operator={egress_operator} egress_port={egress_port} "
                f"ingress_operator={ingress_operator} ingress_port={ingress_port}"
            )

            if link_type == _LINK_TYPE_REGULAR:
                if egress_operator is None:
                    logger.warning(f"CreateDagLinks missing egress operator link_name={link.name}")
                    await self._async_markJobFailed(job_id)
                    return False
                if egress_port is None:
                    logger.warning(f"CreateDagLinks missing egress port link_name={link.name}")
                    await self._async_markJobFailed(job_id)
                    return False
                if ingress_operator is None:
                    logger.warning(f"CreateDagLinks missing ingress operator link_name={link.name}")
                    await self._async_markJobFailed(job_id)
                    return False
                if ingress_port is None:
                    logger.warning(f"CreateDagLinks missing ingress port link_name={link.name}")
                    await self._async_markJobFailed(job_id)
                    return False
            elif link_type in (_LINK_TYPE_SYNC_INJECTOR, _LINK_TYPE_ASYNC_INJECTOR):
                if egress_operator is not None or egress_port is not None:
                    logger.warning(f"CreateDagLinks invalid {link_type} egress fields link_name={link.name}")
                    await self._async_markJobFailed(job_id)
                    return False
                if ingress_operator is None or ingress_port is None:
                    logger.warning(
                        f"CreateDagLinks missing {link_type} ingress fields link_name={link.name}"
                    )
                    await self._async_markJobFailed(job_id)
                    return False
            elif link_type == _LINK_TYPE_SYNC_RETRIEVER:
                if ingress_operator is not None or ingress_port is not None:
                    logger.warning(
                        f"CreateDagLinks invalid SYNC_RETRIEVER ingress fields link_name={link.name}"
                    )
                    await self._async_markJobFailed(job_id)
                    return False
                if egress_operator is None or egress_port is None:
                    logger.warning(f"CreateDagLinks missing SYNC_RETRIEVER egress fields link_name={link.name}")
                    await self._async_markJobFailed(job_id)
                    return False
            if not link.payload_type.SerializeToString():
                logger.warning(f"CreateDagLinks missing payload type link_name={link.name}")
                await self._async_markJobFailed(job_id)
                return False
            desired.append(
                {
                    "name": link.name,
                    "link_type": link_type,
                    "egress_operator": egress_operator,
                    "egress_port": egress_port,
                    "ingress_operator": ingress_operator,
                    "ingress_port": ingress_port,
                    "payload_type": link.payload_type.SerializeToString(),
                }
            )
        logger.debug(f"CreateDagLinks desired materialized desired_count={len(desired)}")

        if not desired:
            logger.info("CreateDagLinks completed with no links")
            return await self._async_persistInjectorLinkRefForJob(job_id=job_id)

        async with self._session_maker() as session:
            try:
                existing_rows = (
                    await session.execute(
                        select(TabDagLinks.name).where(TabDagLinks.flow_job_id == job_id)
                    )
                ).all()
            except DBAPIError:
                logger.warning("CreateDagLinks failed reading existing links", exc_info=True)
                return True

        existing = {name for (name,) in existing_rows}
        missing = [item for item in desired if item["name"] not in existing]
        logger.debug(
            f"CreateDagLinks reconciliation "
            f"existing_count={len(existing)} missing_count={len(missing)}"
        )
        if not missing:
            logger.info("CreateDagLinks completed with no missing links")
            return await self._async_persistInjectorLinkRefForJob(job_id=job_id)

        logger.debug(f"CreateDagLinks creating opnet links missing_count={len(missing)}")
        create_request = opnet_controller_pb2.OpNetCreateLinksRequest(
            cluster_id=str(self._cluster_id),
            usecase="OPERATORS",
        )
        for item in missing:
            create_request.links.add(
                controller_id=str(controller_id),
                link_name=item["name"],
                payload_type=item["payload_type"],
            )

        try:
            response = await self._dependencyRetry.async_retryUntilReady(
                operationName="FlowServer CreateDagLinks CreateLinks",
                invocation=lambda: self._opnet_manager_client.CreateLinks(create_request),
            )
        except RetryDeadlineExceededError:
            logger.warning(
                "CreateDagLinks opnet manager not ready before deadline",
                exc_info=True,
            )
            await self._async_markJobFailed(job_id)
            return False
        except Exception:
            logger.warning("CreateDagLinks failed to create opnet links", exc_info=True)
            await self._async_markJobFailed(job_id)
            return False

        result_map = {
            (result.controller_id, result.link_name): result for result in response.results
        }
        logger.debug(
            f"CreateDagLinks opnet create response "
            f"result_count={len(response.results)}"
        )
        for item in missing:
            key = (str(controller_id), item["name"])
            result = result_map.get(key)
            if result is None:
                logger.error(
                    f"CreateDagLinks missing opnet link result "
                    f"link_name={item['name']}"
                )
                await self._async_markJobFailed(job_id)
                return False
            if result.status not in (
                opnet_controller_pb2.CREATED,
                opnet_controller_pb2.ALREADY_EXISTS,
            ):
                logger.warning(
                    f"CreateDagLinks opnet link failed "
                    f"link_name={item['name']} "
                    f"status={result.status} message={result.message}"
                )
                await self._async_markJobFailed(job_id)
                return False
            if not result.link_id:
                logger.error(
                    f"CreateDagLinks missing link_id for opnet link "
                    f"link_name={item['name']}"
                )
                await self._async_markJobFailed(job_id)
                return False
            try:
                item["link_id"] = uuid.UUID(result.link_id)
            except Exception:
                logger.error(
                    f"CreateDagLinks invalid link_id for opnet link "
                    f"link_name={item['name']} value={result.link_id}",
                    exc_info=True,
                )
                await self._async_markJobFailed(job_id)
                return False
            if item["link_type"] in (_LINK_TYPE_SYNC_INJECTOR, _LINK_TYPE_ASYNC_INJECTOR):
                link_ref = (result.link_ref or "").strip()
                if not link_ref:
                    logger.error(
                        f"CreateDagLinks missing link_ref for injector link "
                        f"link_name={item['name']}"
                    )
                    await self._async_markJobFailed(job_id)
                    return False
                item["link_ref"] = link_ref
            logger.debug(
                f"CreateDagLinks opnet link resolved "
                f"link_name={item['name']} link_id={item['link_id']}"
            )

        async with self._session_maker() as session:
            try:
                operator_rows = (
                    await session.execute(
                        select(TabDagOperators.id, TabDagOperators.name)
                        .where(TabDagOperators.flow_job_id == job_id)
                    )
                ).all()
            except DBAPIError:
                logger.warning("CreateDagLinks failed reading operators", exc_info=True)
                await self._async_markJobFailed(job_id)
                return False

        operator_ids = {name: operator_id for (operator_id, name) in operator_rows}
        logger.debug(
            f"CreateDagLinks operator rows loaded operator_count={len(operator_ids)}"
        )
        for item in missing:
            egress_name = item["egress_operator"]
            ingress_name = item["ingress_operator"]
            if egress_name:
                item["egress_operator_id"] = operator_ids.get(egress_name)
                if item["egress_operator_id"] is None:
                    logger.warning(
                        f"CreateDagLinks missing egress operator row "
                        f"link_name={item['name']} operator={egress_name}"
                    )
                    await self._async_markJobFailed(job_id)
                    return False
            else:
                item["egress_operator_id"] = None
            if ingress_name:
                item["ingress_operator_id"] = operator_ids.get(ingress_name)
                if item["ingress_operator_id"] is None:
                    logger.warning(
                        f"CreateDagLinks missing ingress operator row "
                        f"link_name={item['name']} operator={ingress_name}"
                    )
                    await self._async_markJobFailed(job_id)
                    return False
            else:
                item["ingress_operator_id"] = None

        async def _async_persist(batch):
            async with self._session_maker() as session:
                async with _async_transaction(session):
                    await session.execute(
                        insert(TabDagLinks),
                        [
                            {
                                "flow_job_id": job_id,
                                "name": item["name"],
                                "link_type": item["link_type"],
                                "egress_operator_id": item["egress_operator_id"],
                                "egress_port": item["egress_port"],
                                "ingress_operator_id": item["ingress_operator_id"],
                                "ingress_port": item["ingress_port"],
                                "payload_type": item["payload_type"],
                                "link_id": item["link_id"],
                            }
                            for item in batch
                        ],
                    )

        try:
            _, failures = await sqldb_utils.async_partitionOnIntegrityErrors(
                missing,
                _async_persist,
                reason_fn=lambda exc: str(exc.orig),
            )
        except DBAPIError:
            logger.warning("CreateDagLinks failed inserting links", exc_info=True)
            await self._async_markJobFailed(job_id)
            return False
        logger.debug(
            f"CreateDagLinks persisted batch attempted={len(missing)} failures={len(failures)}"
        )

        unexpected_failures = [
            reason
            for _, reason in failures
            if reason is None or "tab_dag_links_flow_job_id_name_uk" not in reason
        ]
        if unexpected_failures:
            logger.warning(f"CreateDagLinks failed to persist links failures={len(unexpected_failures)}")
            await self._async_markJobFailed(job_id)
            return False

        injectorLinkRef = None
        for item in missing:
            if item["link_type"] not in (_LINK_TYPE_SYNC_INJECTOR, _LINK_TYPE_ASYNC_INJECTOR):
                continue
            candidate = item.get("link_ref")
            if not candidate:
                continue
            if injectorLinkRef is not None and injectorLinkRef != candidate:
                logger.error("CreateDagLinks found multiple injector refs")
                await self._async_markJobFailed(job_id)
                return False
            injectorLinkRef = candidate

        async with self._session_maker() as session:
            try:
                async with _async_transaction(session):
                    values: dict[str, object] = {"last_action_ts": func.now()}
                    if injectorLinkRef:
                        values["bridge_ingress_link_ref"] = injectorLinkRef
                    await session.execute(update(TabFlowJobs).where(TabFlowJobs.id == job_id).values(**values))
            except DBAPIError:
                logger.warning("CreateDagLinks failed to update last_action_ts", exc_info=True)
                return True

        logger.info(f"CreateDagLinks completed missing={len(missing)}")
        return await self._async_persistInjectorLinkRefForJob(job_id=job_id)

    async def _async_persistInjectorLinkRefForJob(self, *, job_id: uuid.UUID) -> bool:
        async with self._session_maker() as session:
            try:
                injector_rows = (
                    await session.execute(
                        select(TabDagLinks.link_id)
                        .where(TabDagLinks.flow_job_id == job_id)
                        .where(TabDagLinks.link_type.in_([_LINK_TYPE_SYNC_INJECTOR, _LINK_TYPE_ASYNC_INJECTOR]))
                        .order_by(TabDagLinks.name.asc())
                        .limit(2)
                    )
                ).all()
            except DBAPIError:
                logger.warning("PersistInjectorLinkRef failed reading links", exc_info=True)
                await self._async_markJobFailed(job_id)
                return False

        if len(injector_rows) > 1:
            logger.warning("PersistInjectorLinkRef found multiple injectors")
            await self._async_markJobFailed(job_id)
            return False

        has_injector = len(injector_rows) == 1

        async with self._session_maker() as session:
            try:
                current = (
                    await session.execute(
                        select(TabFlowJobs.bridge_ingress_link_ref).where(TabFlowJobs.id == job_id)
                    )
                ).one_or_none()
                if current is None:
                    logger.warning("PersistInjectorLinkRef missing job row")
                    await self._async_markJobFailed(job_id)
                    return False
                (current_bridge_link_ref,) = current
                current_bridge_link_ref = (current_bridge_link_ref or "").strip()

                # Never replace an opaque CreateLinks-returned ref with link_id text.
                # If injector exists but ref is empty, caller must populate it from CreateLinks response.
                if has_injector and not current_bridge_link_ref:
                    logger.warning(
                        "PersistInjectorLinkRef injector present but bridge ingress ref is empty"
                    )

                async with _async_transaction(session):
                    await session.execute(
                        update(TabFlowJobs)
                        .where(TabFlowJobs.id == job_id)
                        .values(last_action_ts=func.now())
                    )
            except DBAPIError:
                logger.warning(
                    "PersistInjectorLinkRef failed writing flow job",
                    exc_info=True,
                )
                await self._async_markJobFailed(job_id)
                return False
        return True

    async def _async_checkControllerCreated(self, job_id: uuid.UUID) -> int:
        async with self._session_maker() as session:
            try:
                row = (
                    await session.execute(
                        select(TabFlowJobs.controller_id).where(TabFlowJobs.id == job_id)
                    )
                ).one_or_none()
            except DBAPIError:
                logger.warning("CreateFlowJobController check database error", exc_info=True)
                return flow_server_pb2.JOB_STATUS_UNKNOWN

        if row is None:
            logger.warning("CreateFlowJobController check missing job row")
            return flow_server_pb2.JOB_STATUS_UNKNOWN

        (controller_id,) = row
        if controller_id is not None:
            logger.debug(f"CreateFlowJobController check found controller controller_id={controller_id}")
            return flow_server_pb2.JOB_STATUS_UNKNOWN

        logger.warning("CreateFlowJobController check no controller")
        return flow_server_pb2.JOB_STATUS_UNKNOWN

    async def _async_createOperatorInstances(self, job_id: uuid.UUID, dag: dag_pb2.Dag) -> bool:
        logger.debug(
            f"CreateOperatorInstances begin "
            f"dag_operator_count={len(dag.operators)} dag_link_count={len(dag.links)}"
        )
        async with self._session_maker() as session:
            try:
                async with _async_transaction(session):
                    await session.execute(
                        update(TabFlowJobs)
                        .where(TabFlowJobs.id == job_id)
                        .values(last_action_ts=func.now())
                    )
                    row = (
                        await session.execute(
                            select(TabFlowJobs.controller_id, TabFlowJobs.app_id)
                            .where(TabFlowJobs.id == job_id)
                        )
                    ).one_or_none()
            except DBAPIError:
                logger.warning("CreateOperatorInstances database error", exc_info=True)
                return True

        if row is None:
            logger.warning("CreateOperatorInstances missing job row")
            return True

        controller_id, persistedAppId = row
        if controller_id is None:
            logger.warning("CreateOperatorInstances missing controller")
            await self._async_markJobFailed(job_id)
            return False
        loggingAppId = (persistedAppId or "").strip() or str(job_id)

        operator_names = {operator.name for operator in dag.operators if operator.name}
        if not operator_names and dag.operators:
            logger.warning("CreateOperatorInstances missing operator names")
            await self._async_markJobFailed(job_id)
            return False

        async with self._session_maker() as session:
            try:
                operator_rows = (
                    await session.execute(
                        select(
                            TabDagOperators.id,
                            TabDagOperators.name,
                            TabDagOperators.policy,
                        )
                        .where(TabDagOperators.flow_job_id == job_id)
                    )
                ).all()
            except DBAPIError:
                logger.warning("CreateOperatorInstances failed reading operators", exc_info=True)
                await self._async_markJobFailed(job_id)
                return False

        operator_ids: dict[str, uuid.UUID] = {}
        desired_counts_by_operator_name: dict[str, int] = {}
        for operator_id, name, policy_bytes in operator_rows:
            operator_ids[name] = operator_id
            desired_counts_by_operator_name[name] = self._instanceCountFromPolicyBytes(policy_bytes)
        logger.debug(
            f"CreateOperatorInstances operator rows loaded operator_count={len(operator_ids)}"
        )
        missing_operators = [name for name in operator_names if name not in operator_ids]
        if missing_operators:
            logger.warning(f"CreateOperatorInstances missing operators missing={len(missing_operators)}")
            await self._async_markJobFailed(job_id)
            return False

        async with self._session_maker() as session:
            try:
                link_rows = (
                    await session.execute(
                        select(TabDagLinks.name, TabDagLinks.link_id)
                        .where(TabDagLinks.flow_job_id == job_id)
                    )
                ).all()
            except DBAPIError:
                logger.warning("CreateOperatorInstances failed reading links", exc_info=True)
                await self._async_markJobFailed(job_id)
                return False

        link_ids = {name: link_id for (name, link_id) in link_rows}
        logger.debug(f"CreateOperatorInstances link rows loaded link_count={len(link_ids)}")

        port_links: dict[tuple[str, str, str], tuple[str, str]] = {}
        port_payloads: dict[tuple[str, str, str], bytes] = {}

        def _registerPortLink(
            *,
            operator_name: str,
            link_direction: str,
            port_name: str,
            port_kind: str,
            link_name: str,
            payload_bytes: bytes,
        ) -> bool:
            key = (operator_name, link_direction, port_name)
            if key in port_links:
                logger.warning(
                    f"CreateOperatorInstances multiple links for port "
                    f"operator={operator_name} port={port_name}"
                )
                return False
            port_links[key] = (link_name, port_kind)
            port_payloads[key] = payload_bytes
            logger.debug(
                f"CreateOperatorInstances registered port-link "
                f"operator={operator_name} direction={link_direction} "
                f"port={port_name} port_kind={port_kind} link_name={link_name}"
            )
            return True

        for link in dag.links:
            if not link.name:
                logger.warning("CreateOperatorInstances missing link name")
                await self._async_markJobFailed(job_id)
                return False

            payload_bytes = link.payload_type.SerializeToString()
            if not payload_bytes:
                logger.warning(f"CreateOperatorInstances missing link payload link_name={link.name}")
                await self._async_markJobFailed(job_id)
                return False

            try:
                link_type = self._normalizeDagLinkType(link=link)
            except ValueError:
                logger.warning(
                    f"CreateOperatorInstances unsupported link type link_name={link.name}",
                    exc_info=True,
                )
                await self._async_markJobFailed(job_id)
                return False
            egress_operator = link.egress_operator or None
            egress_port = link.egress_port or None
            ingress_operator = link.ingress_operator or None
            ingress_port = link.ingress_port or None
            logger.debug(
                f"CreateOperatorInstances parsed link "
                f"link_name={link.name} link_type={link_type} "
                f"egress_operator={egress_operator} egress_port={egress_port} "
                f"ingress_operator={ingress_operator} ingress_port={ingress_port}"
            )

            if link_type == _LINK_TYPE_REGULAR:
                if egress_operator is None or egress_port is None:
                    logger.warning("CreateOperatorInstances missing egress link fields")
                    await self._async_markJobFailed(job_id)
                    return False
                if ingress_operator is None or ingress_port is None:
                    logger.warning("CreateOperatorInstances missing ingress link fields")
                    await self._async_markJobFailed(job_id)
                    return False
                if egress_operator not in operator_names or ingress_operator not in operator_names:
                    logger.warning("CreateOperatorInstances missing operator for link")
                    await self._async_markJobFailed(job_id)
                    return False
                if not _registerPortLink(
                    operator_name=egress_operator,
                    link_direction="EGRESS",
                    port_name=egress_port,
                    port_kind="EGRESS",
                    link_name=link.name,
                    payload_bytes=payload_bytes,
                ):
                    await self._async_markJobFailed(job_id)
                    return False
                if not _registerPortLink(
                    operator_name=ingress_operator,
                    link_direction="INGRESS",
                    port_name=ingress_port,
                    port_kind="INGRESS",
                    link_name=link.name,
                    payload_bytes=payload_bytes,
                ):
                    await self._async_markJobFailed(job_id)
                    return False
                continue

            if link_type in (_LINK_TYPE_SYNC_INJECTOR, _LINK_TYPE_ASYNC_INJECTOR):
                if egress_operator is not None or egress_port is not None:
                    logger.warning(
                        f"CreateOperatorInstances invalid injector egress fields "
                        f"link_name={link.name}"
                    )
                    await self._async_markJobFailed(job_id)
                    return False
                if ingress_operator is None or ingress_port is None:
                    logger.warning(
                        f"CreateOperatorInstances missing injector ingress fields "
                        f"link_name={link.name}"
                    )
                    await self._async_markJobFailed(job_id)
                    return False
                if ingress_operator not in operator_names:
                    logger.warning("CreateOperatorInstances missing ingress operator for link")
                    await self._async_markJobFailed(job_id)
                    return False
                ingress_port_kind = (
                    "INGRESS_BRIDGE"
                    if ingress_operator == dag.dag_ingress.operator and ingress_port == dag.dag_ingress.port
                    else "INGRESS"
                )
                if not _registerPortLink(
                    operator_name=ingress_operator,
                    link_direction="INGRESS",
                    port_name=ingress_port,
                    port_kind=ingress_port_kind,
                    link_name=link.name,
                    payload_bytes=payload_bytes,
                ):
                    await self._async_markJobFailed(job_id)
                    return False
                continue

            if link_type == _LINK_TYPE_SYNC_RETRIEVER:
                if ingress_operator is not None or ingress_port is not None:
                    logger.warning(
                        f"CreateOperatorInstances invalid deadend ingress fields "
                        f"link_name={link.name}"
                    )
                    await self._async_markJobFailed(job_id)
                    return False
                if egress_operator is None or egress_port is None:
                    logger.warning(
                        f"CreateOperatorInstances missing deadend egress fields "
                        f"link_name={link.name}"
                    )
                    await self._async_markJobFailed(job_id)
                    return False
                if egress_operator not in operator_names:
                    logger.warning("CreateOperatorInstances missing egress operator for link")
                    await self._async_markJobFailed(job_id)
                    return False
                egress_port_kind = (
                    "EGRESS_BRIDGE"
                    if dag.dag_egress.operator and egress_operator == dag.dag_egress.operator and egress_port == dag.dag_egress.port
                    else "EGRESS"
                )
                if not _registerPortLink(
                    operator_name=egress_operator,
                    link_direction="EGRESS",
                    port_name=egress_port,
                    port_kind=egress_port_kind,
                    link_name=link.name,
                    payload_bytes=payload_bytes,
                ):
                    await self._async_markJobFailed(job_id)
                    return False
                continue

        logger.debug(
            f"CreateOperatorInstances link registration complete "
            f"port_link_count={len(port_links)}"
        )
        desired_nodes: list[tuple[uuid.UUID, str, list[opnet_controller_pb2.OpNetPortCreateSpec]]] = []
        for operator in dag.operators:
            if not operator.name:
                logger.warning("CreateOperatorInstances missing operator name")
                await self._async_markJobFailed(job_id)
                return False
            operator_id = operator_ids.get(operator.name)
            if operator_id is None:
                logger.warning("CreateOperatorInstances missing operator id")
                await self._async_markJobFailed(job_id)
                return False
            port_specs: list[opnet_controller_pb2.OpNetPortCreateSpec] = []
            if operator.ports:
                for port in operator.ports:
                    if not port.name:
                        logger.warning("CreateOperatorInstances missing port name")
                        await self._async_markJobFailed(job_id)
                        return False
                    if port.direction == dag_pb2.Port.INGRESS:
                        link_direction = "INGRESS"
                        port_kind = (
                            "INGRESS_BRIDGE"
                            if operator.name == dag.dag_ingress.operator and port.name == dag.dag_ingress.port
                            else "INGRESS"
                        )
                    elif port.direction == dag_pb2.Port.EGRESS:
                        link_direction = "EGRESS"
                        port_kind = (
                            "EGRESS_BRIDGE"
                            if dag.dag_egress.operator and operator.name == dag.dag_egress.operator and port.name == dag.dag_egress.port
                            else "EGRESS"
                        )
                    else:
                        logger.warning("CreateOperatorInstances missing port direction")
                        await self._async_markJobFailed(job_id)
                        return False
                    key = (operator.name, link_direction, port.name)
                    link_info = port_links.get(key)
                    if link_info is None:
                        logger.warning(f"CreateOperatorInstances missing link for port operator={operator.name} port={port.name}")
                        await self._async_markJobFailed(job_id)
                        return False
                    link_name, inferred_port_kind = link_info
                    if inferred_port_kind != port_kind:
                        logger.warning(
                            f"CreateOperatorInstances port kind mismatch "
                            f"operator={operator.name} port={port.name} "
                            f"link_name={link_name} expected={inferred_port_kind} actual={port_kind}"
                        )
                        await self._async_markJobFailed(job_id)
                        return False
                    link_id = link_ids.get(link_name)
                    if link_id is None:
                        logger.warning(f"CreateOperatorInstances missing link id for port link={link_name}")
                        await self._async_markJobFailed(job_id)
                        return False
                    link_payload = port_payloads[key]
                    port_payload = port.payload_type.SerializeToString()
                    if port_payload and port_payload != link_payload:
                        logger.warning(f"CreateOperatorInstances payload mismatch operator={operator.name} port={port.name}")
                        await self._async_markJobFailed(job_id)
                        return False
                    payload_bytes = port_payload or link_payload
                    port_specs.append(
                        opnet_controller_pb2.OpNetPortCreateSpec(
                            name=port.name,
                            kind=inferred_port_kind,
                            payload_type=payload_bytes,
                            link_id=str(link_id),
                        )
                    )
            else:
                for (operator_name, direction, port_name), (link_name, port_kind) in port_links.items():
                    if operator_name != operator.name:
                        continue
                    link_id = link_ids.get(link_name)
                    if link_id is None:
                        logger.warning(f"CreateOperatorInstances missing link id for port link={link_name}")
                        await self._async_markJobFailed(job_id)
                        return False
                    port_specs.append(
                        opnet_controller_pb2.OpNetPortCreateSpec(
                            name=port_name,
                            kind=port_kind,
                            payload_type=port_payloads[(operator_name, direction, port_name)],
                            link_id=str(link_id),
                        )
                    )

            logger.debug(
                f"CreateOperatorInstances operator port specs prepared "
                f"operator={operator.name} port_spec_count={len(port_specs)}"
            )
            desired_count = desired_counts_by_operator_name.get(operator.name, 1)
            for index in range(desired_count):
                desired_nodes.append((operator_id, f"{operator.name}-{index}", port_specs))

        if not desired_nodes:
            logger.info("CreateOperatorInstances completed with no operators")
            return True

        async with self._session_maker() as session:
            try:
                existing_rows = (
                    await session.execute(
                        select(
                            TabOperatorInstances.operator_id,
                            TabNodes.name,
                            TabOperatorInstances.node_id,
                            TabOperatorInstances.executor_id,
                        )
                        .join(TabNodes, TabNodes.id == TabOperatorInstances.node_id)
                        .where(TabOperatorInstances.operator_id.in_([op_id for op_id, _, _ in desired_nodes]))
                    )
                ).all()
            except DBAPIError:
                logger.warning("CreateOperatorInstances failed reading existing instances", exc_info=True)
                await self._async_markJobFailed(job_id)
                return False

        existing_instances: dict[uuid.UUID, dict[str, tuple[uuid.UUID, uuid.UUID | None]]] = {}
        for operator_id, node_name, node_id, executor_id in existing_rows:
            existing_instances.setdefault(operator_id, {})[node_name] = (node_id, executor_id)
        nodes_to_create = []
        executor_targets: dict[tuple[uuid.UUID, str], uuid.UUID | None] = {}
        for operator_id, node_name, ports in desired_nodes:
            existing = existing_instances.get(operator_id, {}).get(node_name)
            if existing is None:
                nodes_to_create.append((operator_id, node_name, ports))
                executor_targets[(operator_id, node_name)] = None
                continue
            existing_node_id, existing_executor_id = existing
            if existing_executor_id is None:
                executor_targets[(operator_id, node_name)] = existing_node_id
        logger.debug(
            f"CreateOperatorInstances plan computed "
            f"nodes_to_create={len(nodes_to_create)} executor_targets={len(executor_targets)}"
        )

        node_ids_by_instance: dict[tuple[uuid.UUID, str], uuid.UUID] = {}
        if nodes_to_create:
            logger.debug(f"CreateOperatorInstances creating opnet nodes count={len(nodes_to_create)}")
            create_request = opnet_controller_pb2.OpNetCreateNodesRequest(
                cluster_id=str(self._cluster_id),
                usecase="OPERATORS",
            )
            for _, node_name, ports in nodes_to_create:
                node = create_request.nodes.add(
                    controller_id=str(controller_id),
                    name=node_name,
                )
                for port in ports:
                    node.ports.add(
                        name=port.name,
                        kind=port.kind,
                        payload_type=port.payload_type,
                        link_id=port.link_id,
                    )

            try:
                response = await self._dependencyRetry.async_retryUntilReady(
                    operationName="FlowServer CreateOperatorInstances CreateNodes",
                    invocation=lambda: self._opnet_manager_client.CreateNodes(create_request),
                )
            except RetryDeadlineExceededError:
                logger.warning(
                    "CreateOperatorInstances opnet manager not ready before deadline",
                    exc_info=True,
                )
                await self._async_markJobFailed(job_id)
                return False
            except Exception:
                logger.warning("CreateOperatorInstances failed to create opnet nodes", exc_info=True)
                await self._async_markJobFailed(job_id)
                return False

            if len(response.node_ids) != len(nodes_to_create):
                logger.warning("CreateOperatorInstances node count mismatch")
                await self._async_markJobFailed(job_id)
                return False

            for (operator_id, node_name, _), node_id_value in zip(nodes_to_create, response.node_ids):
                try:
                    node_ids_by_instance[(operator_id, node_name)] = uuid.UUID(node_id_value)
                except Exception:
                    logger.warning(
                        f"CreateOperatorInstances invalid node id "
                        f"node_id={node_id_value}",
                        exc_info=True,
                    )
                    await self._async_markJobFailed(job_id)
                    return False
                logger.debug(
                    f"CreateOperatorInstances node created "
                    f"operator_id={operator_id} node_name={node_name} "
                    f"node_id={node_ids_by_instance[(operator_id, node_name)]}"
                )

        executor_ids_by_instance: dict[tuple[uuid.UUID, str], uuid.UUID] = {}
        if len(executor_targets) > 0:
            executor_semaphore = asyncio.Semaphore(self._createExecutorsMaxParallelism)

            async def _async_createExecutor(
                operator_key: tuple[uuid.UUID, str],
                node_name: str,
            ) -> tuple[tuple[uuid.UUID, str], uuid.UUID]:
                operator_id, _ = operator_key
                async with executor_semaphore:
                    node_id = executor_targets[operator_key] or node_ids_by_instance[operator_key]
                    create_request = executor_control_service_pb2.CreateRequest(
                        executor_name=node_name,
                        job_id=str(job_id),
                        runtime_identity=executor_control_service_pb2.OperatorRuntimeIdentity(
                            operator_name=node_name.rsplit("-", 1)[0],
                            instance_id=str(node_id),
                            logging_app_id=loggingAppId,
                        ),
                    )
                    try:
                        response = await self._dependencyRetry.async_retryUntilReady(
                            operationName="FlowServer CreateOperatorInstances CreateExecutor",
                            invocation=lambda: self._executor_control_client.Create(create_request),
                        )
                    except RetryDeadlineExceededError as exc:
                        raise RuntimeError(
                            f"executor control not ready before deadline operator_id={operator_id}"
                        ) from exc
                    except Exception as exc:
                        raise RuntimeError(
                            f"failed to create executor operator_id={operator_id}"
                        ) from exc
                    if not response.executor_id:
                        raise RuntimeError(
                            f"missing executor id operator_id={operator_id}"
                        )
                    try:
                        executor_id = uuid.UUID(response.executor_id)
                    except Exception as exc:
                        raise RuntimeError(
                            f"invalid executor id executor_id={response.executor_id}"
                        ) from exc
                    logger.debug(
                        f"CreateOperatorInstances executor created "
                        f"operator_id={operator_id} node_name={node_name} executor_id={executor_id}"
                    )
                    return operator_key, executor_id

            creation_results = await asyncio.gather(
                *[
                    _async_createExecutor(operator_key, operator_key[1])
                    for operator_key in executor_targets.keys()
                ],
                return_exceptions=True,
            )
            for creation_result in creation_results:
                if isinstance(creation_result, Exception):
                    logger.warning(
                        f"CreateOperatorInstances executor creation failed "
                        f"reason={creation_result}",
                    )
                    await self._async_markJobFailed(job_id)
                    return False
                operator_key, executor_id = creation_result
                executor_ids_by_instance[operator_key] = executor_id

        if not nodes_to_create and not executor_targets:
            logger.info("CreateOperatorInstances completed with no missing nodes")
            return True

        instance_rows = []
        for instance_key, node_id in node_ids_by_instance.items():
            operator_id, _ = instance_key
            executor_id = executor_ids_by_instance.get(instance_key)
            if executor_id is None:
                logger.warning(f"CreateOperatorInstances missing executor for operator operator_id={operator_id}")
                await self._async_markJobFailed(job_id)
                return False
            instance_rows.append(
                {
                    "operator_id": operator_id,
                    "node_id": node_id,
                    "executor_id": executor_id,
                }
            )
        logger.debug(
            f"CreateOperatorInstances persistence rows prepared row_count={len(instance_rows)}"
        )

        async with self._session_maker() as session:
            try:
                async with _async_transaction(session):
                    for row in instance_rows:
                        try:
                            async with session.begin_nested():
                                await session.execute(insert(TabOperatorInstances).values(**row))
                        except IntegrityError as exc:
                            reason = str(exc.orig) if getattr(exc, "orig", None) else str(exc)
                            if "tab_operator_instances_node_id_uk" not in reason:
                                raise
                    for instance_key, executor_id in executor_ids_by_instance.items():
                        operator_id, node_name = instance_key
                        existing_node_id = executor_targets.get(instance_key)
                        if existing_node_id is None:
                            continue
                        result = await session.execute(
                            update(TabOperatorInstances)
                            .where(
                                (TabOperatorInstances.operator_id == operator_id)
                                & (TabOperatorInstances.node_id == existing_node_id)
                                & (TabOperatorInstances.executor_id.is_(None))
                            )
                            .values(executor_id=executor_id)
                        )
                        if result.rowcount not in (0, 1):
                            logger.warning(
                                f"CreateOperatorInstances update affected {result.rowcount} rows "
                                f"operator_id={operator_id} node_name={node_name}"
                            )
                            await self._async_markJobFailed(job_id)
                            return False
                    await session.execute(
                        update(TabFlowJobs)
                        .where(TabFlowJobs.id == job_id)
                        .values(last_action_ts=func.now())
                    )
            except DBAPIError:
                logger.warning("CreateOperatorInstances failed persisting instances", exc_info=True)
                await self._async_markJobFailed(job_id)
                return False

        logger.info(f"CreateOperatorInstances completed missing={len(nodes_to_create)}")
        return True



def addFlowServerServiceToServer(
    service: FlowServerService,
    server,
) -> None:
    """Attach the FlowServer servicer to a grpclib server instance."""
    if hasattr(server, "add_service"):
        server.add_service(service)
    elif hasattr(server, "services"):
        server.services.append(service)
    else:  # pragma: no cover - defensive: unexpected server type
        raise TypeError("Server does not support grpclib service registration.")
