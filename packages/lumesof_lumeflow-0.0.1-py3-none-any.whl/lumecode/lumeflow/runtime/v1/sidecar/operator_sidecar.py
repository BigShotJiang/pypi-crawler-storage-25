"""Library runtime for the OperatorSidecar streaming service."""

from __future__ import annotations

import asyncio
import contextlib
import logging
import os
import shlex
import threading
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Awaitable, Callable, Optional, Sequence

from grpclib.client import Channel
from grpclib.server import Server, Stream

from google.protobuf.any_pb2 import Any as AnyMessage

try:  # pragma: no cover - optional dependency
    from google.rpc import code_pb2  # type: ignore
except ImportError:  # pragma: no cover - fallback when googleapis not installed
    class _RpcCode:
        OK = 0
        UNKNOWN = 2
        UNAVAILABLE = 14

    code_pb2 = _RpcCode()  # type: ignore

try:  # pragma: no cover - optional dependency
    from google.rpc import status_pb2  # type: ignore
except ImportError:  # pragma: no cover - fallback when googleapis not installed
    status_pb2 = None  # type: ignore

from google.protobuf import timestamp_pb2  # type: ignore

from lumecode.base.python.logging import lumesof_logging
from lumecode.lumeflow.runtime.v1.operator import operator_grpc, operator_pb2
from lumecode.lumeflow.runtime.v1.opnet.loopback_opnet_proxy import LoopbackOpNetProxy
from lumecode.lumeflow.runtime.v1.operator.operator_relay import OperatorRelay
from lumecode.lumeflow.runtime.v1.opnet.opnet_proxy import (
    OpNetDownstream,
    OpNetProxy,
    OpNetUpstream,
)
from lumecode.lumeflow.runtime.v1.opnet import opnet_controller_pb2, opnet_types_pb2
from lumecode.lumeflow.runtime.v1.opnet.opnet_types_pb2 import Result
from lumecode.lumeflow.runtime.v1.opnet import opnet_controller_grpc
from lumecode.base.python.net.target_parser import NetTarget

LOG = logging.getLogger(__name__)
structuredLogger = lumesof_logging.getLogger(__name__)

OPERATOR_CONNECT_MAX_ATTEMPTS_ENV = "LUMEFLOW_OPERATOR_CONNECT_MAX_ATTEMPTS"
OPERATOR_CONNECT_BACKOFF_MS_ENV = "LUMEFLOW_OPERATOR_CONNECT_BACKOFF_MS"
DEFAULT_OPERATOR_CONNECT_MAX_ATTEMPTS = 60
DEFAULT_OPERATOR_CONNECT_BACKOFF_MS = 500
DEFAULT_OPNET_CONNECT_MAX_ATTEMPTS = 3
DEFAULT_OPNET_CONNECT_BACKOFF_MS = 1000
DEFAULT_OPNET_HEARTBEAT_MAX_CONSECUTIVE_FAILURES = 3
DOCKER_LAUNCH_TIMEOUT_SECONDS = 600.0

try:  # pragma: no cover - optional dependency at runtime
    import docker  # type: ignore
    from docker.errors import DockerException, NotFound  # type: ignore
except ImportError:  # pragma: no cover - handled in helpers
    docker = None  # type: ignore

    class _DockerUnavailable(RuntimeError):
        """Placeholder exception used when docker SDK is missing."""

    class _DockerNotFound(_DockerUnavailable):
        """Placeholder for docker.errors.NotFound when SDK is missing."""

    DockerException = _DockerUnavailable  # type: ignore
    NotFound = _DockerNotFound  # type: ignore


class DockerImageDownloadError(RuntimeError):
    """Raised when the docker image cannot be pulled or downloaded."""


class DockerLaunchError(RuntimeError):
    """Raised when the docker container fails to launch."""


class OpNetConnectRetriesExceededError(RuntimeError):
    """Raised when OpNet controller connect retries are exhausted."""


class OpNetHeartbeatConsecutiveFailuresExceededError(RuntimeError):
    """Raised when OpNet heartbeat failures exceed the configured threshold."""


@dataclass(frozen=True)
class OperatorStatusSnapshot:
    status: int
    last_contact_ts: Optional[datetime]
    message: str


def _sidecarFlowAttrs(
    *,
    port: Optional[str] = None,
    messageId: Optional[str] = None,
    traceId: Optional[str] = None,
    streamKind: Optional[str] = None,
    exception: Optional[str] = None,
) -> dict[str, Any]:
    attrs: dict[str, Any] = {}
    if port:
        attrs[lumesof_logging.LUMESOF_PORT] = port
    if messageId:
        attrs[lumesof_logging.LUMESOF_MESSAGE_ID] = messageId
    if traceId:
        attrs[lumesof_logging.TRACE_ID] = traceId
    if streamKind:
        attrs[lumesof_logging.LUMESOF_STREAM_KIND] = streamKind
    if exception:
        attrs[lumesof_logging.EXCEPTION] = exception
    return attrs


def _formatDockerRunArgv(
    *,
    image: str,
    name: Optional[str],
    runArgs: Sequence[str],
    command: Sequence[str],
) -> str:
    argv = ["docker", "run"]
    if name:
        argv.extend(["--name", name])
    argv.extend(runArgs)
    argv.append(image)
    argv.extend(command)
    return " ".join(shlex.quote(token) for token in argv)


class OperatorStatusTracker:
    def __init__(self) -> None:
        self._status = opnet_types_pb2.OperatorStatus.NOT_STARTED
        self._last_contact_ts: Optional[datetime] = None
        self._message = ""
        self._lock = asyncio.Lock()

    async def async_markDownloadFailed(self, message: str) -> None:
        await self._async_markTerminalFailure(
            opnet_types_pb2.OperatorStatus.DOWNLOAD_FAILED,
            message,
        )

    async def async_markLaunchFailed(self, message: str) -> None:
        await self._async_markTerminalFailure(
            opnet_types_pb2.OperatorStatus.LAUNCH_FAILED,
            message,
        )

    async def async_markOperatorConnected(self) -> None:
        await self.async_recordOperatorActivity()

    async def async_recordOperatorActivity(self) -> None:
        now = datetime.utcnow()
        async with self._lock:
            if self._status in (
                opnet_types_pb2.OperatorStatus.DOWNLOAD_FAILED,
                opnet_types_pb2.OperatorStatus.LAUNCH_FAILED,
            ):
                return
            self._status = opnet_types_pb2.OperatorStatus.RUNNING
            self._last_contact_ts = now
            self._message = ""

    async def async_refreshResponsiveness(self, *, timeout_s: float, has_work: bool = True) -> None:
        now = datetime.utcnow()
        async with self._lock:
            if self._status in (
                opnet_types_pb2.OperatorStatus.DOWNLOAD_FAILED,
                opnet_types_pb2.OperatorStatus.LAUNCH_FAILED,
            ):
                return
            if self._last_contact_ts is None:
                return
            drift_s = (now - self._last_contact_ts).total_seconds()
            if drift_s > timeout_s and has_work:
                self._status = opnet_types_pb2.OperatorStatus.NOT_RESPONSIVE
            else:
                self._status = opnet_types_pb2.OperatorStatus.RUNNING
            if self._status != opnet_types_pb2.OperatorStatus.NOT_RESPONSIVE:
                self._message = ""

    async def async_snapshot(self) -> OperatorStatusSnapshot:
        async with self._lock:
            return OperatorStatusSnapshot(
                status=self._status,
                last_contact_ts=self._last_contact_ts,
                message=self._message,
            )

    async def _async_markTerminalFailure(self, status: int, message: str) -> None:
        async with self._lock:
            if self._status in (
                opnet_types_pb2.OperatorStatus.DOWNLOAD_FAILED,
                opnet_types_pb2.OperatorStatus.LAUNCH_FAILED,
            ):
                return
            self._status = status
            self._message = message


def _parseOpNetPortSpec(spec: str) -> opnet_types_pb2.OpNetPort:
    """Parse a CLI port spec into an OpNetPort proto."""

    parts = [part.strip() for part in spec.split(",")]
    if len(parts) < 3 or len(parts) > 4:
        raise RuntimeError(
            "opnet port must be 'name,port_type,type_url[,serialization_format]'"
        )
    name, port_type_raw, type_url = parts[:3]
    format_raw = parts[3] if len(parts) == 4 else "PROTO"
    if not name:
        raise RuntimeError("opnet port name must be provided")
    if not type_url:
        raise RuntimeError("opnet port type_url must be provided")

    port_type_value: Optional[int] = None
    port_type_key = port_type_raw.upper()
    if port_type_key in ("INGRESS", "EGRESS", "INGRESS_BRIDGE", "EGRESS_BRIDGE"):
        port_type_value = opnet_types_pb2.OpNetPort.PortType.Value(port_type_key)
    if port_type_value is None:
        raise RuntimeError(
            f"opnet port_type must be INGRESS, EGRESS, INGRESS_BRIDGE, or EGRESS_BRIDGE: {port_type_raw}"
        )

    format_key = format_raw.upper()
    if format_key == "UNSPECIFIED":
        format_key = "SERIALIZATION_FORMAT_UNSPECIFIED"
    try:
        format_value = opnet_types_pb2.OpNetPayloadType.SerializationFormat.Value(format_key)
    except ValueError as exc:
        raise RuntimeError(
            f"opnet serialization_format must be PROTO, JSON, CUSTOM, or UNSPECIFIED: {format_raw}"
        ) from exc

    port_proto = opnet_types_pb2.OpNetPort(port_name=name, port_type=port_type_value)
    port_proto.payload_type.CopyFrom(
        opnet_types_pb2.OpNetPayloadType(
            serialization_format=format_value,
            type_url=type_url,
        )
    )
    return port_proto


def addOperatorConnectFlags(parser: Any) -> None:
    parser.add_argument(
        "--operator-connect-max-attempts",
        type=int,
        default=DEFAULT_OPERATOR_CONNECT_MAX_ATTEMPTS,
        help=(
            "Maximum operator connect attempts from inside the container "
            f"(exported as {OPERATOR_CONNECT_MAX_ATTEMPTS_ENV})."
        ),
    )
    parser.add_argument(
        "--operator-connect-backoff-ms",
        type=int,
        default=DEFAULT_OPERATOR_CONNECT_BACKOFF_MS,
        help=(
            "Backoff in milliseconds between operator connect attempts from inside the container "
            f"(exported as {OPERATOR_CONNECT_BACKOFF_MS_ENV})."
        ),
    )
    parser.add_argument(
        "--opnet-connect-max-attempts",
        type=int,
        default=DEFAULT_OPNET_CONNECT_MAX_ATTEMPTS,
        help="Maximum attempts to connect to OpNet controller before sidecar exits.",
    )
    parser.add_argument(
        "--opnet-connect-backoff-ms",
        type=int,
        default=DEFAULT_OPNET_CONNECT_BACKOFF_MS,
        help="Backoff in milliseconds between OpNet controller connect retry attempts.",
    )
    parser.add_argument(
        "--opnet-heartbeat-max-consecutive-failures",
        type=int,
        default=DEFAULT_OPNET_HEARTBEAT_MAX_CONSECUTIVE_FAILURES,
        help="Maximum consecutive OpNet heartbeat failures before sidecar exits.",
    )


async def _async_connectOpNetController(
    *,
    target: str,
    node_id: str,
    ports: Sequence[opnet_types_pb2.OpNetPort],
    node_version: str = "", # TODO Retrieve these from the plugin once the interface is implemented
    node_backend: str = "",
) -> Sequence[opnet_types_pb2.OpNetConnection]:
    """Connect to the OpNet controller and activate the provided ports."""

    portNames = [port.port_name for port in ports]
    with lumesof_logging.loggingContext(
        **{
            lumesof_logging.LUMESOF_NODE_ID: node_id,
        }
    ):
        structuredLogger.info(
            f"OpNet controller Connect RPC request target={target}",
            event="lumeflow.sidecar.opnet.connect.request",
            attrs={
                lumesof_logging.EVENT_OUTCOME: "start",
            },
        )
        request = opnet_controller_pb2.OpNetConnectionRequest(
            node_id=node_id,
            node_version=node_version,
            node_backend=node_backend,
            ports=list(ports),
        )

        _parsed = NetTarget.parseTarget(target)
        channel = Channel(host=_parsed.getHost(), port=_parsed.getPort()) if _parsed.getPath() is None else Channel(path=_parsed.getPath())
        try:
            stub = opnet_controller_grpc.OpNetControllerStub(channel)
            try:
                response = await stub.Connect(request)
            except Exception:
                structuredLogger.exception(
                    f"OpNet controller Connect RPC failed target={target}",
                    event="lumeflow.sidecar.opnet.connect.failed",
                    attrs={
                        lumesof_logging.EVENT_OUTCOME: "failure",
                    },
                )
                raise
            structuredLogger.info(
                f"OpNet controller Connect RPC response target={target}",
                event="lumeflow.sidecar.opnet.connect.completed",
                attrs={
                    lumesof_logging.EVENT_OUTCOME: "success",
                },
            )
            return response.connections
        finally:
            channel.close()


async def _async_connectOpNetControllerWithRetry(
    *,
    target: str,
    node_id: str,
    ports: Sequence[opnet_types_pb2.OpNetPort],
    node_version: str = "",
    node_backend: str = "",
    max_attempts: int = DEFAULT_OPNET_CONNECT_MAX_ATTEMPTS,
    backoff_ms: int = DEFAULT_OPNET_CONNECT_BACKOFF_MS,
) -> Sequence[opnet_types_pb2.OpNetConnection]:
    """Connect to OpNet controller with retries and rich error context."""

    if max_attempts < 1:
        raise RuntimeError("--opnet-connect-max-attempts must be >= 1")
    if backoff_ms < 0:
        raise RuntimeError("--opnet-connect-backoff-ms must be >= 0")

    for attempt in range(1, max_attempts + 1):
        LOG.info(
            "OpNet connect attempt target=%s node_id=%s attempt=%d/%d",
            target,
            node_id,
            attempt,
            max_attempts,
        )
        try:
            connections = await _async_connectOpNetController(
                target=target,
                node_id=node_id,
                ports=ports,
                node_version=node_version,
                node_backend=node_backend,
            )
            if attempt > 1:
                LOG.info(
                    "OpNet connect recovered target=%s node_id=%s succeeded_attempt=%d/%d",
                    target,
                    node_id,
                    attempt,
                    max_attempts,
                )
            return connections
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            if attempt >= max_attempts:
                message = (
                    f"OpNet controller connect failed after {max_attempts} attempts "
                    f"target={target} node_id={node_id} "
                    f"last_error={type(exc).__name__}: {exc}"
                )
                LOG.error(message)
                raise OpNetConnectRetriesExceededError(message) from exc
            LOG.warning(
                "OpNet connect failed target=%s node_id=%s attempt=%d/%d "
                "error_type=%s error=%s retry_backoff_ms=%d",
                target,
                node_id,
                attempt,
                max_attempts,
                type(exc).__name__,
                str(exc) or "<empty>",
                backoff_ms,
            )
            if backoff_ms > 0:
                await asyncio.sleep(backoff_ms / 1000.0)

    raise RuntimeError(
        f"Unreachable: connect retry loop exhausted target={target} node_id={node_id}"
    )


def _timestampFromDatetime(value: Optional[datetime]) -> Optional[timestamp_pb2.Timestamp]:
    if value is None:
        return None
    if timestamp_pb2 is None:
        raise RuntimeError("google.protobuf.timestamp_pb2 is required for operator status heartbeats.")
    proto = timestamp_pb2.Timestamp()
    proto.FromDatetime(value.replace(tzinfo=timezone.utc))
    return proto


def _buildOpNetHeartbeatPayload(
    snapshot: OperatorStatusSnapshot,
) -> opnet_types_pb2.OpNetNodeToCtlHeartbeat:
    """Build heartbeat payload for the sidecar -> controller RPC."""

    heartbeat = opnet_types_pb2.OpNetNodeToCtlHeartbeat(
        operator_status=snapshot.status,
        operator_status_message=snapshot.message or "",
    )
    last_contact_ts = _timestampFromDatetime(snapshot.last_contact_ts)
    if last_contact_ts is not None:
        heartbeat.last_contact_ts.CopyFrom(last_contact_ts)
    return heartbeat


async def _async_sendOpNetControllerHeartbeat(
    *,
    target: str,
    node_id: str,
    heartbeat: opnet_types_pb2.OpNetNodeToCtlHeartbeat,
) -> opnet_controller_pb2.OpNetSendHeartbeatResponse:
    """Send one heartbeat to the OpNet controller."""

    with lumesof_logging.loggingContext(
        **{
            lumesof_logging.LUMESOF_NODE_ID: node_id,
        }
    ):
        structuredLogger.info(
            f"OpNet controller SendHeartbeat RPC request target={target}",
            event="lumeflow.sidecar.opnet.heartbeat.request",
            attrs={
                lumesof_logging.EVENT_OUTCOME: "start",
            },
        )
        request = opnet_controller_pb2.OpNetSendHeatbeatRequest(
            node_id=node_id,
            hb=heartbeat,
        )
        _parsed = NetTarget.parseTarget(target)
        channel = Channel(host=_parsed.getHost(), port=_parsed.getPort()) if _parsed.getPath() is None else Channel(path=_parsed.getPath())
        try:
            stub = opnet_controller_grpc.OpNetControllerStub(channel)
            try:
                response = await stub.SendHeartbeat(request)
            except Exception:
                structuredLogger.exception(
                    f"OpNet controller SendHeartbeat RPC failed target={target}",
                    event="lumeflow.sidecar.opnet.heartbeat.failed",
                    attrs={
                        lumesof_logging.EVENT_OUTCOME: "failure",
                    },
                )
                raise
            resultOk = True
            resultMessage = ""
            if response.resp.HasField("result"):
                resultOk = bool(response.resp.result.ok)
                resultMessage = response.resp.result.message or ""
            structuredLogger.info(
                f"OpNet controller SendHeartbeat RPC response target={target}",
                event="lumeflow.sidecar.opnet.heartbeat.completed",
                attrs=_sidecarFlowAttrs(
                    exception=resultMessage or None,
                ) | {
                    lumesof_logging.EVENT_OUTCOME: "success" if resultOk else "failure",
                },
            )
            return response
        finally:
            channel.close()


async def _async_opnetHeartbeatLoop(
    *,
    target: str,
    node_id: str,
    interval_s: float,
    status_provider: Callable[[], Awaitable[OperatorStatusSnapshot]],
    stop_event: asyncio.Event,
    max_consecutive_failures: int = DEFAULT_OPNET_HEARTBEAT_MAX_CONSECUTIVE_FAILURES,
) -> None:
    """Send periodic heartbeats to the OpNet controller until shutdown."""

    if max_consecutive_failures < 1:
        raise RuntimeError("--opnet-heartbeat-max-consecutive-failures must be >= 1")

    consecutiveFailures = 0
    while True:
        try:
            await asyncio.wait_for(stop_event.wait(), timeout=interval_s)
            return
        except asyncio.TimeoutError:
            pass

        snapshot = await status_provider()
        heartbeat = _buildOpNetHeartbeatPayload(snapshot)
        try:
            operatorStatusName = opnet_types_pb2.OperatorStatus.Name(snapshot.status)
        except ValueError:
            operatorStatusName = f"UNKNOWN({snapshot.status})"
        LOG.info(
            "Sending OpNet heartbeat node_id=%s target=%s operator_status=%s "
            "operator_status_message=%s has_last_contact_ts=%s",
            node_id,
            target,
            operatorStatusName,
            snapshot.message or "<none>",
            snapshot.last_contact_ts is not None,
        )
        try:
            response = await _async_sendOpNetControllerHeartbeat(
                target=target,
                node_id=node_id,
                heartbeat=heartbeat,
            )
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            consecutiveFailures += 1
            LOG.warning(
                "Failed to send OpNet heartbeat node_id=%s target=%s "
                "consecutive_failures=%d/%d error_type=%s error=%s",
                node_id,
                target,
                consecutiveFailures,
                max_consecutive_failures,
                type(exc).__name__,
                str(exc) or "<empty>",
            )
            if consecutiveFailures >= max_consecutive_failures:
                message = (
                    "OpNet heartbeat failed too many times "
                    f"target={target} node_id={node_id} "
                    f"consecutive_failures={consecutiveFailures} "
                    f"threshold={max_consecutive_failures} "
                    f"last_error={type(exc).__name__}: {exc}"
                )
                LOG.error(message)
                raise OpNetHeartbeatConsecutiveFailuresExceededError(message) from exc
            continue

        if response.resp.HasField("result") and not response.resp.result.ok:
            consecutiveFailures += 1
            resultMessage = response.resp.result.message or "<no message>"
            LOG.warning(
                "OpNet heartbeat returned failure node_id=%s target=%s "
                "consecutive_failures=%d/%d message=%s",
                node_id,
                target,
                consecutiveFailures,
                max_consecutive_failures,
                resultMessage,
            )
            if consecutiveFailures >= max_consecutive_failures:
                message = (
                    "OpNet heartbeat returned too many non-ok responses "
                    f"target={target} node_id={node_id} "
                    f"consecutive_failures={consecutiveFailures} "
                    f"threshold={max_consecutive_failures} "
                    f"last_result_message={resultMessage}"
                )
                LOG.error(message)
                raise OpNetHeartbeatConsecutiveFailuresExceededError(message)
            continue

        if consecutiveFailures > 0:
            LOG.info(
                "OpNet heartbeat recovered node_id=%s target=%s previous_consecutive_failures=%d",
                node_id,
                target,
                consecutiveFailures,
            )
            consecutiveFailures = 0


async def _async_operatorResponsivenessLoop(
    *,
    tracker: OperatorStatusTracker,
    timeout_s: float,
    has_work_provider: Callable[[], Awaitable[bool]],
    stop_event: asyncio.Event,
) -> None:
    interval_s = max(1.0, min(5.0, timeout_s / 2.0))
    while True:
        try:
            await asyncio.wait_for(stop_event.wait(), timeout=interval_s)
            return
        except asyncio.TimeoutError:
            pass
        hasWork = True
        try:
            hasWork = await has_work_provider()
        except asyncio.CancelledError:
            raise
        except Exception:
            LOG.exception("Operator has_work probe failed; defaulting to has_work=true")
        await tracker.async_refreshResponsiveness(timeout_s=timeout_s, has_work=hasWork)


class _PublishStreamUpstream(OpNetUpstream):
    """Adapts the Publish gRPC stream to the OperatorRelay upstream API."""

    def __init__(
        self,
        stream: Stream[operator_pb2.DeliverRequest, operator_pb2.PublishResponse],
        reset_id: str,
        on_reset: Optional[Callable[[str], Awaitable[None]]] = None,
        on_activity: Optional[Callable[[], Awaitable[None]]] = None,
    ) -> None:
        self._stream = stream
        self._closed = False
        self._relay: Optional[OperatorRelay] = None
        self._reset_id = reset_id
        self._on_reset = on_reset
        self._on_activity = on_activity
        self._reset_notified = False

    def attachRelay(self, relay: OperatorRelay) -> None:
        self._relay = relay

    async def _notifyReset(self) -> None:
        if self._on_reset is None or self._reset_notified:
            return
        self._reset_notified = True
        await self._on_reset(self._reset_id)

    async def _notifyActivity(self) -> None:
        if self._on_activity is None:
            return
        with contextlib.suppress(Exception):
            await self._on_activity()

    async def async_getOpNetMessage(
        self,
    ) -> tuple[Result, operator_pb2.DeliverRequest]:
        if self._closed:
            await self._notifyReset()
            return Result(ok=False, message="publish stream closed"), operator_pb2.DeliverRequest()

        try:
            request = await self._stream.recv_message()
        except Exception:
            self._closed = True
            if self._relay is not None:
                self._relay.stop()
            await self._notifyReset()
            raise
        if request is None:
            self._closed = True
            if self._relay is not None:
                self._relay.stop()
            await self._notifyReset()
            return Result(ok=False, message="publish stream closed"), operator_pb2.DeliverRequest()

        structuredLogger.info(
            "Publish stream received request",
            event="lumeflow.sidecar.publish.received",
            attrs=_sidecarFlowAttrs(
                port=request.port,
                messageId=request.message_id or None,
                traceId=request.message_context.trace_id or None,
                streamKind="publish",
            ) | {
                lumesof_logging.EVENT_OUTCOME: "start",
            },
        )
        await self._notifyActivity()
        return Result(ok=True), request

    async def async_ack(self, request: operator_pb2.AckRequest) -> Result:
        return Result(ok=True)

    async def async_reset(self, reset_id: str) -> Result:
        return Result(ok=True)

    @property
    def resetNotified(self) -> bool:
        return self._reset_notified

    async def sendResponse(
        self, response: operator_pb2.PublishResponse
    ) -> None:
        if response.error.code == 0:
            response.error.code = code_pb2.OK
        await self._stream.send_message(response)


class _ProxyPublishDownstream(OpNetDownstream):
    """Forwards publish requests into the OpNet proxy and records responses."""

    def __init__(self, proxy: OpNetProxy, upstream: _PublishStreamUpstream) -> None:
        self._proxy = proxy
        self._upstream = upstream

    async def async_putOpNetMessage(
        self, request: operator_pb2.DeliverRequest
    ) -> Result:
        structuredLogger.info(
            "Dispatching publish to OpNet",
            event="lumeflow.sidecar.publish.dispatch",
            attrs=_sidecarFlowAttrs(
                port=request.port,
                messageId=request.message_id or None,
                traceId=request.message_context.trace_id or None,
                streamKind="publish",
            ) | {
                lumesof_logging.EVENT_OUTCOME: "start",
            },
        )
        try:
            result = await self._proxy.async_putOpNetMessage(request)
        except asyncio.CancelledError:  # pragma: no cover - cooperative shutdown
            raise
        except Exception as exc:  # pragma: no cover - backend failure
            LOG.exception("OpNet proxy publish raised for port=%s", request.port)
            result = Result(ok=False, message=str(exc) or "opnet proxy publish failed")

        response = operator_pb2.PublishResponse(
            port=request.port,
            message_id=request.message_id,
        )
        if request.HasField("message_context"):
            response.message_context.CopyFrom(request.message_context)

        if result.ok:
            response.error.code = code_pb2.OK
        else:
            if result.message == "opnet proxy is not configured":
                response.error.code = code_pb2.UNAVAILABLE
            else:
                response.error.code = code_pb2.UNKNOWN
            response.error.message = result.message or "opnet publish failed"
            structuredLogger.warning(
                "OpNet publish failed",
                event="lumeflow.sidecar.publish.failed",
                attrs=_sidecarFlowAttrs(
                    port=request.port,
                    messageId=request.message_id or None,
                    traceId=request.message_context.trace_id or None,
                    streamKind="publish",
                    exception=result.message or None,
                ) | {
                    lumesof_logging.EVENT_OUTCOME: "failure",
                },
            )

        with contextlib.suppress(asyncio.CancelledError):
            await self._upstream.sendResponse(response)

        if result.ok:
            structuredLogger.info(
                "Publish dispatched to OpNet",
                event="lumeflow.sidecar.publish.completed",
                attrs=_sidecarFlowAttrs(
                    port=request.port,
                    messageId=request.message_id or None,
                    traceId=request.message_context.trace_id or None,
                    streamKind="publish",
                ) | {
                    lumesof_logging.EVENT_OUTCOME: "success",
                },
            )

        # Always report success back to the relay so that the response is emitted.
        return Result(ok=True)


class _AckStreamUpstream(OpNetUpstream):
    """Adapts the Ack gRPC stream for OperatorRelay consumption."""

    def __init__(
        self,
        stream: Stream[operator_pb2.AckRequest, operator_pb2.DeliverRequest],
        stop_event: asyncio.Event,
        reset_id: str,
        on_reset: Optional[Callable[[str], Awaitable[None]]] = None,
        on_activity: Optional[Callable[[], Awaitable[None]]] = None,
    ) -> None:
        self._stream = stream
        self._stop_event = stop_event
        self._relay: Optional[OperatorRelay] = None
        self._closed = False
        self._reset_id = reset_id
        self._on_reset = on_reset
        self._on_activity = on_activity
        self._reset_notified = False

    def attachRelay(self, relay: OperatorRelay) -> None:
        self._relay = relay

    async def _notifyReset(self) -> None:
        if self._on_reset is None or self._reset_notified:
            return
        self._reset_notified = True
        await self._on_reset(self._reset_id)

    async def _notifyActivity(self) -> None:
        if self._on_activity is None:
            return
        with contextlib.suppress(Exception):
            await self._on_activity()

    async def async_getOpNetMessage(
        self,
    ) -> tuple[Result, operator_pb2.DeliverRequest]:
        if self._closed or self._stop_event.is_set():
            await self._notifyReset()
            return Result(ok=False, message="ack stream stopping"), operator_pb2.DeliverRequest()

        while True:
            try:
                ack = await self._stream.recv_message()
            except Exception:
                self._closed = True
                self._stop_event.set()
                if self._relay is not None:
                    self._relay.stop()
                await self._notifyReset()
                raise
            if ack is None:
                self._closed = True
                self._stop_event.set()
                if self._relay is not None:
                    self._relay.stop()
                await self._notifyReset()
                return Result(ok=False, message="ack stream closed"), operator_pb2.DeliverRequest()

            if not ack.message_id:
                LOG.debug("received ack handshake without message id; ignoring")
                continue

            structuredLogger.info(
                "Ack stream received request",
                event="lumeflow.sidecar.ack.received",
                attrs=_sidecarFlowAttrs(
                    port=ack.port,
                    messageId=ack.message_id,
                    streamKind="ack",
                ) | {
                    lumesof_logging.EVENT_OUTCOME: "start",
                },
            )
            await self._notifyActivity()
            deliver = operator_pb2.DeliverRequest(port=ack.port, message_id=ack.message_id)
            if (
                status_pb2 is not None
                and (ack.error.code != 0 or bool(ack.error.message))
            ):
                packedStatus = AnyMessage()
                packedStatus.Pack(ack.error)
                deliver.payload.CopyFrom(packedStatus)
            return Result(ok=True), deliver

    async def async_ack(self, request: operator_pb2.AckRequest) -> Result:
        # Ack stream does not require additional acknowledgements back to the client.
        return Result(ok=True)

    async def async_reset(self, reset_id: str) -> Result:
        return Result(ok=True)

    @property
    def resetNotified(self) -> bool:
        return self._reset_notified


class _ProxyAckDownstream(OpNetDownstream):
    """Converts relay deliveries back into proxy acknowledgements."""

    def __init__(self, proxy: OpNetProxy) -> None:
        self._proxy = proxy

    async def async_putOpNetMessage(
        self, request: operator_pb2.DeliverRequest
    ) -> Result:
        ack = operator_pb2.AckRequest(port=request.port, message_id=request.message_id)
        if status_pb2 is not None and request.payload.type_url:
            unpackedStatus = status_pb2.Status()
            if request.payload.Unpack(unpackedStatus):
                ack.error.CopyFrom(unpackedStatus)
        structuredLogger.info(
            "Dispatching ack to OpNet",
            event="lumeflow.sidecar.ack.dispatch",
            attrs=_sidecarFlowAttrs(
                port=ack.port,
                messageId=ack.message_id or None,
                streamKind="ack",
            ) | {
                lumesof_logging.EVENT_OUTCOME: "start",
            },
        )
        try:
            result = await self._proxy.async_ack(ack)
        except asyncio.CancelledError:  # pragma: no cover - cooperative shutdown
            raise
        except Exception as exc:  # pragma: no cover - backend failure
            LOG.exception(
                "OpNet proxy ack raised for port=%s message_id=%s",
                ack.port,
                ack.message_id or "<none>",
            )
            return Result(ok=False, message=str(exc) or "opnet ack failed")

        if not result.ok:
            structuredLogger.warning(
                "OpNet ack failed",
                event="lumeflow.sidecar.ack.failed",
                attrs=_sidecarFlowAttrs(
                    port=ack.port,
                    messageId=ack.message_id or None,
                    streamKind="ack",
                    exception=result.message or None,
                ) | {
                    lumesof_logging.EVENT_OUTCOME: "failure",
                },
            )
        else:
            structuredLogger.info(
                "Ack dispatched to OpNet",
                event="lumeflow.sidecar.ack.completed",
                attrs=_sidecarFlowAttrs(
                    port=ack.port,
                    messageId=ack.message_id or None,
                    streamKind="ack",
                ) | {
                    lumesof_logging.EVENT_OUTCOME: "success",
                },
            )
        return result


class _StreamDeliverDownstream(OpNetDownstream):
    """Forwards deliveries from the proxy to the operator Ack stream."""

    def __init__(
        self,
        stream: Stream[operator_pb2.AckRequest, operator_pb2.DeliverRequest],
        on_activity: Optional[Callable[[], Awaitable[None]]] = None,
    ) -> None:
        self._stream = stream
        self._initial_sent = False
        self._on_activity = on_activity

    async def async_putOpNetMessage(
        self, request: operator_pb2.DeliverRequest
    ) -> Result:
        if not self._initial_sent:
            send_initial = getattr(self._stream, "send_initial_metadata", None)
            if callable(send_initial):
                with contextlib.suppress(Exception):
                    await send_initial()
            self._initial_sent = True
        try:
            await self._stream.send_message(request)
        except asyncio.CancelledError:
            raise
        except Exception:
            LOG.exception("Failed to forward delivery to operator")
            return Result(ok=False, message="failed to send delivery to operator")
        if self._on_activity is not None:
            with contextlib.suppress(Exception):
                await self._on_activity()
        structuredLogger.info(
            "Forwarded delivery to operator",
            event="lumeflow.sidecar.delivery.forwarded",
            attrs=_sidecarFlowAttrs(
                port=request.port,
                messageId=request.message_id or None,
                traceId=request.message_context.trace_id or None,
                streamKind="ack",
            ) | {
                lumesof_logging.EVENT_OUTCOME: "success",
            },
        )
        return Result(ok=True)


class _ProxyDeliverUpstream(OpNetUpstream):
    """Fetches deliveries from the OpNet proxy for operator consumption."""

    def __init__(self, proxy: OpNetProxy, stop_event: asyncio.Event) -> None:
        self._proxy = proxy
        self._stop_event = stop_event
        self._relay: Optional[OperatorRelay] = None

    def attachRelay(self, relay: OperatorRelay) -> None:
        self._relay = relay

    async def async_getOpNetMessage(
        self,
    ) -> tuple[Result, operator_pb2.DeliverRequest]:
        if self._stop_event.is_set():
            if self._relay is not None:
                self._relay.stop()
            return Result(ok=False, message="deliver relay stopped"), operator_pb2.DeliverRequest()

        try:
            result, delivery = await self._proxy.async_getOpNetMessage()
        except asyncio.CancelledError:
            raise
        except TimeoutError:
            LOG.info("GetOpNetMessage timed out")
            return Result(ok=False, message="GetOpNetMessage timed out"), operator_pb2.DeliverRequest()
        except Exception:
            LOG.exception("OpNet proxy delivery retrieval failed")
            return Result(ok=False, message="opnet delivery failure"), operator_pb2.DeliverRequest()

        if not result.ok:
            LOG.warning("OpNet delivery fetch failed: %s", result.message or "<no message>")
            return result, operator_pb2.DeliverRequest()

        structuredLogger.info(
            "Fetched delivery from OpNet",
            event="lumeflow.sidecar.delivery.fetched",
            attrs=_sidecarFlowAttrs(
                port=delivery.port,
                messageId=delivery.message_id or None,
                traceId=delivery.message_context.trace_id or None,
                streamKind="ack",
            ) | {
                lumesof_logging.EVENT_OUTCOME: "success",
            },
        )
        return Result(ok=True), delivery

    async def async_ack(self, request: operator_pb2.AckRequest) -> Result:
        # Passing acks back into the proxy is handled by the main ack relay.
        return Result(ok=True)

    async def async_reset(self, reset_id: str) -> Result:
        try:
            return await self._proxy.async_reset(reset_id)
        except asyncio.CancelledError:
            raise
        except Exception:
            LOG.exception("OpNet proxy reset failed for id=%s", reset_id)
            return Result(ok=False, message="opnet reset failed")


class SimpleOperatorSidecar(operator_grpc.OperatorSidecarBase):
    """grpclib OperatorSidecar service with optional OpNet proxy routing."""

    def __init__(
        self,
        opnet_proxy: Optional[OpNetProxy] = None,
        status_tracker: Optional[OperatorStatusTracker] = None,
        *,
        error_backoff: float = 0.1,
    ) -> None:
        super().__init__()
        self._opnet_proxy: OpNetProxy = opnet_proxy or LoopbackOpNetProxy()
        self._error_backoff = max(error_backoff, 0.0)
        self._status_tracker = status_tracker

    async def _maybeBackoff(self) -> None:
        if self._error_backoff > 0:
            await asyncio.sleep(self._error_backoff)

    async def _async_markOperatorConnected(self) -> None:
        if self._status_tracker is None:
            return
        await self._status_tracker.async_markOperatorConnected()

    async def _async_recordOperatorActivity(self) -> None:
        if self._status_tracker is None:
            return
        await self._status_tracker.async_recordOperatorActivity()

    async def async_hasWork(self) -> bool:
        return await self._opnet_proxy.async_hasWork()

    @staticmethod
    def _streamResetId(kind: str, stream: Stream[Any, Any]) -> str:
        return f"{kind}:{id(stream)}"

    async def _handleStreamReset(self, reset_id: str) -> None:
        LOG.info("Initiating OpNet proxy reset for id=%s", reset_id)
        try:
            result = await self._opnet_proxy.async_reset(reset_id)
        except asyncio.CancelledError:
            raise
        except Exception:
            LOG.exception("OpNet proxy reset raised for id=%s", reset_id)
            return
        if not result.ok:
            LOG.warning(
                "OpNet proxy reset failed for id=%s: %s",
                reset_id,
                result.message or "<no message>",
            )

    async def async_configureOpNetLinks(
        self,
        connections: Sequence[opnet_types_pb2.OpNetConnection],
    ) -> None:
        LOG.info(
            "Configuring OpNet proxy links connection_count=%d",
            len(connections),
        )
        result = await self._opnet_proxy.async_setup(
            connections=connections,
        )
        if not result.ok:
            LOG.warning(
                "OpNet proxy link configuration failed message=%s",
                result.message or "<none>",
            )
            raise RuntimeError(f"OpNet proxy setup failed: {result.message or 'unknown error'}")
        LOG.info("Configured OpNet proxy links successfully")

    async def Publish(
        self, stream: Stream[operator_pb2.DeliverRequest, operator_pb2.PublishResponse]
    ) -> None:  # type: ignore[override]
        structuredLogger.info(
            "Operator connected to Publish stream",
            event="lumeflow.sidecar.publish.connected",
        )
        await self._async_markOperatorConnected()
        reset_id = self._streamResetId("publish", stream)
        structuredLogger.info(
            "Starting publish dispatch loop",
            event="lumeflow.sidecar.publish.loop_started",
            attrs={"reset_id": reset_id},
        )
        publish_upstream = _PublishStreamUpstream(
            stream,
            reset_id,
            self._handleStreamReset,
            self._async_recordOperatorActivity,
        )
        try:
            proxy = self._opnet_proxy

            publish_downstream = _ProxyPublishDownstream(proxy, publish_upstream)
            relay = OperatorRelay(
                publish_upstream,
                publish_downstream,
                error_backoff=self._error_backoff,
                pass_through=True,
            )
            publish_upstream.attachRelay(relay)

            try:
                await relay.start()
            finally:
                relay.stop()
        finally:
            if not publish_upstream.resetNotified:
                await self._handleStreamReset(reset_id)
            structuredLogger.info(
                "Operator disconnected from Publish stream",
                event="lumeflow.sidecar.publish.disconnected",
                attrs={"reset_id": reset_id},
            )

    async def Ack(
        self, stream: Stream[operator_pb2.AckRequest, operator_pb2.DeliverRequest]
    ) -> None:  # type: ignore[override]
        structuredLogger.info(
            "Operator connected to Ack stream",
            event="lumeflow.sidecar.ack.connected",
        )
        await self._async_markOperatorConnected()
        reset_id = self._streamResetId("ack", stream)
        structuredLogger.info(
            "Starting ack and deliver dispatch loops",
            event="lumeflow.sidecar.ack.loop_started",
            attrs={"reset_id": reset_id},
        )
        ack_upstream: Optional[_AckStreamUpstream] = None
        try:
            proxy = self._opnet_proxy

            stop_event = asyncio.Event()
            ack_upstream = _AckStreamUpstream(
                stream,
                stop_event,
                reset_id,
                self._handleStreamReset,
                self._async_recordOperatorActivity,
            )
            ack_downstream = _ProxyAckDownstream(proxy)
            ack_relay = OperatorRelay(
                ack_upstream,
                ack_downstream,
                error_backoff=self._error_backoff,
                pass_through=True,
            )
            ack_upstream.attachRelay(ack_relay)

            deliver_upstream = _ProxyDeliverUpstream(proxy, stop_event)
            deliver_downstream = _StreamDeliverDownstream(
                stream,
                self._async_recordOperatorActivity,
            )
            deliver_relay = OperatorRelay(
                deliver_upstream,
                deliver_downstream,
                error_backoff=self._error_backoff,
                pass_through=True,
            )
            deliver_upstream.attachRelay(deliver_relay)

            send_initial = getattr(stream, "send_initial_metadata", None)
            if callable(send_initial):
                with contextlib.suppress(Exception):
                    await send_initial()

            ack_task = asyncio.create_task(ack_relay.start())
            deliver_task = asyncio.create_task(deliver_relay.start())

            try:
                await asyncio.wait(
                    {ack_task, deliver_task},
                    return_when=asyncio.FIRST_COMPLETED,
                )
            except asyncio.CancelledError:
                raise
            finally:
                stop_event.set()
                ack_relay.stop()
                deliver_relay.stop()
                for task in (ack_task, deliver_task):
                    if not task.done():
                        task.cancel()
                for task in (ack_task, deliver_task):
                    with contextlib.suppress(asyncio.CancelledError):
                        await task
        finally:
            if ack_upstream is not None and not ack_upstream.resetNotified:
                await self._handleStreamReset(reset_id)
            structuredLogger.info(
                "Operator disconnected from Ack stream",
                event="lumeflow.sidecar.ack.disconnected",
                attrs={"reset_id": reset_id},
            )


async def serve(bind: str, *, service: Optional[SimpleOperatorSidecar] = None) -> Server:
    """Start the OperatorSidecar server bound to TCP or a Unix socket."""

    sidecar = service or SimpleOperatorSidecar()
    server = Server([sidecar])
    normalizedBind = bind if bind.startswith("tcp://") or bind.startswith("unix:///") else f"tcp://{bind}"
    bindTarget = NetTarget.parseTarget(normalizedBind).withUdsMode(0o666)
    await bindTarget.async_bindGrpclibServer(server)
    if bindTarget.getPath():
        LOG.info("listening on unix:///%s", bindTarget.getPath())
    else:
        LOG.info("listening on %s:%s", bindTarget.getHost(), bindTarget.getPort())

    return server


def _buildDockerRunKwargs(run_args: Sequence[str]) -> dict[str, Any]:
    """Translate selected docker CLI-style flags into docker SDK kwargs."""

    ports: dict[str, Any] = {}
    environment: dict[str, str] = {}
    extra_hosts: dict[str, str] = {}
    network: Optional[str] = None

    def _consumeValue(idx: int, flag: str) -> str:
        if idx >= len(run_args):
            raise RuntimeError(f"{flag} requires a value")
        return run_args[idx]

    i = 0
    while i < len(run_args):
        token = run_args[i]
        value: Optional[str] = None
        if token.startswith("--publish="):
            value = token.split("=", 1)[1]
        elif token in ("-p", "--publish"):
            i += 1
            value = _consumeValue(i, token)
        elif token.startswith("--env="):
            value = token.split("=", 1)[1]
            if "=" not in value:
                raise RuntimeError(f"Invalid environment assignment '{value}'")
            name, env_value = value.split("=", 1)
            environment[name] = env_value
        elif token in ("-e", "--env"):
            i += 1
            value = _consumeValue(i, token)
            if "=" not in value:
                raise RuntimeError(f"Invalid environment assignment '{value}'")
            name, env_value = value.split("=", 1)
            environment[name] = env_value
        elif token == "--network":
            i += 1
            network = _consumeValue(i, token)
        elif token.startswith("--network="):
            network = token.split("=", 1)[1]
        elif token == "--add-host":
            i += 1
            value = _consumeValue(i, token)
            host_name, sep, host_address = value.partition(":")
            if not sep or not host_name or not host_address:
                raise RuntimeError(f"Invalid --add-host value '{value}'")
            extra_hosts[host_name] = host_address
        elif token.startswith("--add-host="):
            value = token.split("=", 1)[1]
            host_name, sep, host_address = value.partition(":")
            if not sep or not host_name or not host_address:
                raise RuntimeError(f"Invalid --add-host value '{value}'")
            extra_hosts[host_name] = host_address
        else:
            LOG.warning("Unsupported docker argument '%s' ignored", token)
        if value is not None and token.startswith(("-p", "--publish")):
            parts = value.split(":")
            if len(parts) == 2:
                host_port_str, container_part = parts
                host_ip = None
            elif len(parts) == 3:
                host_ip, host_port_str, container_part = parts
            else:
                raise RuntimeError(f"Invalid port mapping '{value}'")
            if not host_port_str or not container_part:
                raise RuntimeError(f"Invalid port mapping '{value}'")
            if "/" in container_part:
                container_port_str, proto = container_part.split("/", 1)
            else:
                container_port_str, proto = container_part, "tcp"
            try:
                host_port = int(host_port_str)
                container_port = int(container_port_str)
            except ValueError as exc:
                raise RuntimeError(f"Invalid port mapping '{value}'") from exc
            key = f"{container_port}/{proto}"
            binding: Any = (host_ip, host_port) if host_ip else host_port
            ports[key] = binding
        i += 1

    kwargs: dict[str, Any] = {}
    if ports:
        kwargs["ports"] = ports
    if environment:
        kwargs["environment"] = environment
    if extra_hosts:
        kwargs["extra_hosts"] = extra_hosts
    if network is not None:
        kwargs["network"] = network
    return kwargs


def _streamDockerContainerLogs(container_id: str, skip_client: Any = None) -> None:
    """Continuously stream logs from the Docker container to the logger."""

    if docker is None:
        return

    client = docker.from_env()  # type: ignore[union-attr]
    try:
        container = client.containers.get(container_id)  # type: ignore[union-attr]
        for chunk in container.logs(stream=True, follow=True):  # type: ignore[union-attr]
            if not chunk:
                continue
            if isinstance(chunk, bytes):
                try:
                    text = chunk.decode("utf-8", errors="replace")
                except Exception:
                    text = repr(chunk)
            else:
                text = str(chunk)
            text = text.rstrip()
            if text:
                LOG.info("[docker %s] %s", container_id[:12], text)
    except DockerException as exc:  # type: ignore[arg-type]
        LOG.warning("Failed to stream logs from Docker container %s: %s", container_id, exc)
    except Exception as exc:  # pragma: no cover - unexpected docker errors
        LOG.warning("Unexpected error while streaming logs from Docker container %s: %s", container_id, exc)
    finally:
        if client is not skip_client:
            close = getattr(client, "close", None)
            if callable(close):
                with contextlib.suppress(Exception):
                    close()


def _spawnDockerLogStreamer(container_id: str, *, skip_client: Any = None) -> None:
    """Spawn a background thread that streams Docker logs to the logger."""

    if docker is None:
        return

    thread = threading.Thread(
        target=_streamDockerContainerLogs,
        args=(container_id, skip_client),
        name=f"docker-log-{container_id[:12]}",
        daemon=True,
    )
    thread.start()


def _startDockerContainer(
    image: str,
    name: Optional[str] = None,
    run_args: Optional[Sequence[str]] = None,
    command: Optional[Sequence[str]] = None,
    dockerLaunchTimeoutSeconds: float = DOCKER_LAUNCH_TIMEOUT_SECONDS,
) -> str:
    """Start a detached Docker container and return its identifier."""

    if docker is None:
        raise RuntimeError(
            "Docker SDK for Python is required when --docker-image is provided"
        )
    if dockerLaunchTimeoutSeconds <= 0:
        raise RuntimeError(
            f"dockerLaunchTimeoutSeconds must be > 0, got {dockerLaunchTimeoutSeconds}"
        )

    run_args_list = list(run_args or [])
    docker_kwargs = _buildDockerRunKwargs(run_args_list)
    command_list = list(command) if command else None
    oci_user = os.environ.get("OCI_REGISTRY_USER_NAME")
    oci_token = os.environ.get("OCI_REGISTRY_ACCESS_TOKEN")
    auth_config = {"username": oci_user, "password": oci_token} if oci_user and oci_token else None
    dockerHostEnv = os.environ.get("DOCKER_HOST", "").strip()
    dockerConfigEnv = os.environ.get("DOCKER_CONFIG", "").strip()
    dockerAuthConfigEnv = os.environ.get("DOCKER_AUTH_CONFIG", "").strip()
    dockerTlsVerifyEnv = os.environ.get("DOCKER_TLS_VERIFY", "").strip()
    dockerCertPathEnv = os.environ.get("DOCKER_CERT_PATH", "").strip()
    homeEnv = os.environ.get("HOME", "").strip()
    xdgConfigHomeEnv = os.environ.get("XDG_CONFIG_HOME", "").strip()
    candidateConfigPaths: list[str] = []
    if dockerConfigEnv:
        candidateConfigPaths.append(os.path.join(dockerConfigEnv, "config.json"))
    if xdgConfigHomeEnv:
        candidateConfigPaths.append(os.path.join(xdgConfigHomeEnv, "docker", "config.json"))
    if homeEnv:
        candidateConfigPaths.append(os.path.join(homeEnv, ".docker", "config.json"))
        candidateConfigPaths.append(os.path.join(homeEnv, ".dockercfg"))
    existingConfigPaths = [path for path in candidateConfigPaths if os.path.exists(path)]

    LOG.info(
        "Starting Docker container from image '%s' (oci_auth=%s)",
        image,
        auth_config is not None,
    )
    LOG.info(
        "Docker auth/config context: docker_host=%s docker_tls_verify=%s "
        "docker_cert_path=%s docker_config=%s docker_auth_config_present=%s "
        "home=%s xdg_config_home=%s candidate_config_paths=%s existing_config_paths=%s",
        dockerHostEnv or "<default>",
        dockerTlsVerifyEnv or "<default>",
        dockerCertPathEnv or "<default>",
        dockerConfigEnv or "<unset>",
        bool(dockerAuthConfigEnv),
        homeEnv or "<unset>",
        xdgConfigHomeEnv or "<unset>",
        candidateConfigPaths if candidateConfigPaths else ["<none>"],
        existingConfigPaths if existingConfigPaths else ["<none>"],
    )
    LOG.debug(
        "docker SDK run parameters: name=%s, command=%s, kwargs=%s",
        name,
        command_list,
        docker_kwargs,
    )
    launchStartedAt = time.monotonic()

    def _raiseIfLaunchDeadlineExceeded(*, phase: str) -> None:
        elapsedSeconds = time.monotonic() - launchStartedAt
        if elapsedSeconds > dockerLaunchTimeoutSeconds:
            raise TimeoutError(
                f"Docker launch exceeded {dockerLaunchTimeoutSeconds:.1f}s "
                f"for image='{image}' phase={phase} elapsed={elapsedSeconds:.3f}s"
            )

    client = None
    container = None
    try:
        _raiseIfLaunchDeadlineExceeded(phase="before_client_create")
        client = docker.from_env(timeout=max(1, int(dockerLaunchTimeoutSeconds)))  # type: ignore[union-attr]
        if auth_config is not None:
            imagePresentLocally = False
            _raiseIfLaunchDeadlineExceeded(phase="before_local_image_check")
            try:
                _ = client.images.get(image)  # type: ignore[union-attr]
                imagePresentLocally = True
                LOG.info(
                    "Docker image already present locally; skipping authenticated pre-pull image='%s'",
                    image,
                )
            except NotFound:  # type: ignore[arg-type]
                LOG.info(
                    "Docker image not present locally; authenticated pre-pull required image='%s'",
                    image,
                )
            except DockerException:  # type: ignore[arg-type]
                LOG.exception(
                    "Docker local-image check failed; attempting authenticated pre-pull image='%s'",
                    image,
                )
            _raiseIfLaunchDeadlineExceeded(phase="after_local_image_check")
            if not imagePresentLocally:
                LOG.info(
                    "Docker registry credentials detected; pre-pulling image before run image='%s'",
                    image,
                )
                _raiseIfLaunchDeadlineExceeded(phase="before_authenticated_pre_pull")
                try:
                    client.images.pull(image, auth_config=auth_config)  # type: ignore[union-attr]
                    _raiseIfLaunchDeadlineExceeded(phase="after_authenticated_pre_pull")
                except DockerException as prePullExc:  # type: ignore[arg-type]
                    LOG.exception(
                        "Docker authenticated pre-pull failed for image '%s'",
                        image,
                    )
                    raise DockerImageDownloadError(
                        f"Docker authenticated pre-pull failed for image '{image}': {prePullExc}"
                    ) from prePullExc
        _raiseIfLaunchDeadlineExceeded(phase="before_initial_run")
        try:
            container = client.containers.run(  # type: ignore[union-attr]
                image,
                command_list,
                name=name,
                detach=True,
                remove=True,
                **docker_kwargs,
            )
            _raiseIfLaunchDeadlineExceeded(phase="after_initial_run")
        except DockerException as exc:  # type: ignore[arg-type]
            if not _shouldAutoPullDockerImage(exc):
                LOG.exception(
                    "Docker run failed without auto-pull for image '%s' name=%s args=%s",
                    image,
                    name or "<none>",
                    run_args_list,
                )
                raise DockerLaunchError(f"Docker run failed: {exc}") from exc
            LOG.warning(
                "Docker run failed for image '%s'; attempting auto-pull and one retry: %s",
                image,
                exc,
            )
            _raiseIfLaunchDeadlineExceeded(phase="before_pull")
            try:
                client.images.pull(image, auth_config=auth_config)  # type: ignore[union-attr]
                _raiseIfLaunchDeadlineExceeded(phase="after_pull")
            except DockerException as pullExc:  # type: ignore[arg-type]
                LOG.exception(
                    "Docker auto-pull failed for image '%s' (oci_auth=%s)",
                    image,
                    auth_config is not None,
                )
                raise DockerImageDownloadError(
                    f"Docker run failed and auto-pull failed for image '{image}': {pullExc}"
                ) from pullExc
            _raiseIfLaunchDeadlineExceeded(phase="before_retry_run")
            try:
                container = client.containers.run(  # type: ignore[union-attr]
                    image,
                    command_list,
                    name=name,
                    detach=True,
                    remove=True,
                    **docker_kwargs,
                )
                _raiseIfLaunchDeadlineExceeded(phase="after_retry_run")
            except DockerException as retryExc:  # type: ignore[arg-type]
                LOG.exception(
                    "Docker run retry failed after auto-pull for image '%s' name=%s args=%s",
                    image,
                    name or "<none>",
                    run_args_list,
                )
                raise DockerLaunchError(
                    f"Docker run failed after auto-pull for image '{image}': {retryExc}"
                ) from retryExc
    except Exception as exc:
        elapsedSeconds = time.monotonic() - launchStartedAt
        containerRef = ""
        if container is not None:
            containerRef = getattr(container, "id", None) or getattr(container, "short_id", None) or ""
        if containerRef:
            LOG.warning(
                "Cleaning up Docker container after launch failure image='%s' container_id=%s",
                image,
                containerRef,
            )
            with contextlib.suppress(Exception):
                _stopDockerContainer(containerRef)
        LOG.exception(
            "Docker launch failed image='%s' name=%s elapsed=%.3fs deadline=%.1fs",
            image,
            name or "<none>",
            elapsedSeconds,
            dockerLaunchTimeoutSeconds,
        )
        if isinstance(exc, RuntimeError):
            raise
        raise RuntimeError(
            f"Docker launch failed for image '{image}' after {elapsedSeconds:.3f}s: {exc}"
        ) from exc
    finally:
        if client is not None:
            with contextlib.suppress(Exception):
                client.close()  # type: ignore[union-attr]

    container_id = getattr(container, "id", None) or getattr(
        container, "short_id", None
    )
    if not container_id:
        raise RuntimeError("Docker run did not return a container ID")
    LOG.info("Started Docker container %s", container_id)
    _spawnDockerLogStreamer(container_id, skip_client=client)
    return container_id


def _shouldAutoPullDockerImage(exc: Exception) -> bool:
    errorText = str(exc).lower()
    missingImageMarkers = (
        "no such image",
        "not found",
        "pull access denied",
        "manifest unknown",
        "repository does not exist",
    )
    return any(marker in errorText for marker in missingImageMarkers)


def _stopDockerContainer(container_ref: str) -> None:
    """Stop a Docker container by id or name, logging but ignoring errors."""

    if docker is None:
        LOG.warning(
            "Docker SDK for Python is not available; skipping stop for %s",
            container_ref,
        )
        return

    client = docker.from_env()  # type: ignore[union-attr]
    try:
        container = client.containers.get(container_ref)  # type: ignore[union-attr]
        container.stop()
    except NotFound:  # type: ignore[arg-type]
        LOG.warning("Docker container %s not found when stopping", container_ref)
    except DockerException as exc:  # type: ignore[arg-type]
        LOG.warning("Failed to stop Docker container %s: %s", container_ref, exc)
    finally:
        with contextlib.suppress(Exception):
            client.close()  # type: ignore[union-attr]


async def _asyncMain(
    bind: str,
    *,
    docker_image: Optional[str],
    docker_name: Optional[str],
    docker_args: Sequence[str],
    docker_command: Sequence[str],
    opnet_controller_target: Optional[str],
    opnet_node_id: Optional[str],
    opnet_ports: Sequence[opnet_types_pb2.OpNetPort],
    opnet_node_version: str,
    opnet_node_backend: str,
    opnet_heartbeat_interval_s: float = 30.0,
    docker_launch_timeout_s: float = DOCKER_LAUNCH_TIMEOUT_SECONDS,
    operator_nonresponsive_timeout_s: float = 30.0,
    opnet_connect_max_attempts: int = DEFAULT_OPNET_CONNECT_MAX_ATTEMPTS,
    opnet_connect_backoff_ms: int = DEFAULT_OPNET_CONNECT_BACKOFF_MS,
    opnet_heartbeat_max_consecutive_failures: int = DEFAULT_OPNET_HEARTBEAT_MAX_CONSECUTIVE_FAILURES,
    operator_connect_max_attempts: int = DEFAULT_OPERATOR_CONNECT_MAX_ATTEMPTS,
    operator_connect_backoff_ms: int = DEFAULT_OPERATOR_CONNECT_BACKOFF_MS,
    sidecar_service: Optional[SimpleOperatorSidecar] = None,
    status_tracker: Optional[OperatorStatusTracker] = None,
) -> None:
    tracker = status_tracker or OperatorStatusTracker()
    if sidecar_service is None:
        sidecar = SimpleOperatorSidecar(status_tracker=tracker)
    else:
        sidecar = sidecar_service
        if isinstance(sidecar_service, SimpleOperatorSidecar) and sidecar_service._status_tracker is None:
            sidecar_service._status_tracker = tracker
    server: Optional[Server] = None
    event_loop = asyncio.get_running_loop()
    docker_container: Optional[str] = None
    heartbeat_stop_event: Optional[asyncio.Event] = None
    heartbeat_task: Optional[asyncio.Task[None]] = None
    responsiveness_stop_event: Optional[asyncio.Event] = None
    responsiveness_task: Optional[asyncio.Task[None]] = None
    server_wait_task: Optional[asyncio.Task[None]] = None

    def _ensureNetworkArgs(args: Sequence[str]) -> list[str]:
        result = list(args)
        is_unix_bind = bind.startswith("unix:///")
        has_network = False

        i = 0
        while i < len(result):
            token = result[i]
            if token == "--network":
                has_network = True
                if i + 1 < len(result):
                    i += 1
            elif token.startswith("--network="):
                has_network = True
            i += 1

        if not has_network and not is_unix_bind:
            result.append("--network=host")
        return result

    def _injectOperatorConnectEnv(args: Sequence[str]) -> list[str]:
        if operator_connect_max_attempts < 1:
            raise RuntimeError("--operator-connect-max-attempts must be >= 1")
        if operator_connect_backoff_ms < 0:
            raise RuntimeError("--operator-connect-backoff-ms must be >= 0")
        envValues = {
            OPERATOR_CONNECT_MAX_ATTEMPTS_ENV: str(operator_connect_max_attempts),
            OPERATOR_CONNECT_BACKOFF_MS_ENV: str(operator_connect_backoff_ms),
        }

        result: list[str] = []
        i = 0
        while i < len(args):
            token = args[i]
            if token in ("-e", "--env"):
                if i + 1 < len(args):
                    assignment = args[i + 1]
                    key = assignment.split("=", 1)[0]
                    if key in envValues:
                        i += 2
                        continue
                    result.extend([token, assignment])
                    i += 2
                    continue
            if token.startswith("--env="):
                assignment = token.split("=", 1)[1]
                key = assignment.split("=", 1)[0]
                if key in envValues:
                    i += 1
                    continue
            result.append(token)
            i += 1
        for key, value in envValues.items():
            result.extend(["--env", f"{key}={value}"])
        return result

    try:
        structuredLogger.info(
            f"Operator sidecar runtime starting bind={bind} "
            f"docker_image={bool(docker_image)} "
            f"opnet_controller={bool(opnet_controller_target)}",
            event="lumeflow.sidecar.runtime.starting",
            attrs={
                lumesof_logging.EVENT_OUTCOME: "start",
                lumesof_logging.LUMESOF_NODE_ID: opnet_node_id or None,
            },
        )
        if docker_launch_timeout_s <= 0:
            raise RuntimeError("--docker-launch-timeout-s must be positive")
        if opnet_controller_target:
            if not opnet_node_id:
                raise RuntimeError("--opnet-node-id is required when --opnet-controller-target is set")
            if opnet_heartbeat_interval_s <= 0:
                raise RuntimeError("--opnet-heartbeat-interval-s must be positive when --opnet-controller-target is set")
            if opnet_connect_max_attempts < 1:
                raise RuntimeError("--opnet-connect-max-attempts must be >= 1")
            if opnet_connect_backoff_ms < 0:
                raise RuntimeError("--opnet-connect-backoff-ms must be >= 0")
            if opnet_heartbeat_max_consecutive_failures < 1:
                raise RuntimeError("--opnet-heartbeat-max-consecutive-failures must be >= 1")
            port_names = ",".join(port.port_name for port in opnet_ports) if opnet_ports else "<none>"
            LOG.info(
                f"Connecting to OpNet controller target={opnet_controller_target} "
                f"ports={port_names}"
            )
            LOG.info(
                "OpNet failure policy target=%s node_id=%s connect_max_attempts=%d "
                "connect_backoff_ms=%d heartbeat_max_consecutive_failures=%d",
                opnet_controller_target,
                opnet_node_id,
                opnet_connect_max_attempts,
                opnet_connect_backoff_ms,
                opnet_heartbeat_max_consecutive_failures,
            )
            connections = await _async_connectOpNetControllerWithRetry(
                target=opnet_controller_target,
                node_id=opnet_node_id,
                ports=opnet_ports,
                node_version=opnet_node_version,
                node_backend=opnet_node_backend,
                max_attempts=opnet_connect_max_attempts,
                backoff_ms=opnet_connect_backoff_ms,
            )
            await sidecar.async_configureOpNetLinks(connections)
            try:
                snapshot = await tracker.async_snapshot()
                initial_response = await _async_sendOpNetControllerHeartbeat(
                    target=opnet_controller_target,
                    node_id=opnet_node_id,
                    heartbeat=_buildOpNetHeartbeatPayload(snapshot),
                )
                if initial_response.resp.HasField("result") and not initial_response.resp.result.ok:
                    LOG.warning(
                        "Initial OpNet heartbeat returned failure node_id=%s target=%s message=%s",
                        opnet_node_id,
                        opnet_controller_target,
                        initial_response.resp.result.message or "<no message>",
                    )
            except asyncio.CancelledError:
                raise
            except Exception:
                LOG.exception(
                    "Initial OpNet heartbeat failed node_id=%s target=%s",
                    opnet_node_id,
                    opnet_controller_target,
                )

            heartbeat_stop_event = asyncio.Event()
            heartbeat_task = asyncio.create_task(
                _async_opnetHeartbeatLoop(
                    target=opnet_controller_target,
                    node_id=opnet_node_id,
                    interval_s=opnet_heartbeat_interval_s,
                    status_provider=tracker.async_snapshot,
                    stop_event=heartbeat_stop_event,
                    max_consecutive_failures=opnet_heartbeat_max_consecutive_failures,
                ),
                name=f"opnet-heartbeat-{opnet_node_id}",
            )
            if operator_nonresponsive_timeout_s > 0:
                responsiveness_stop_event = asyncio.Event()
                responsiveness_task = asyncio.create_task(
                    _async_operatorResponsivenessLoop(
                        tracker=tracker,
                        timeout_s=operator_nonresponsive_timeout_s,
                        has_work_provider=sidecar.async_hasWork,
                        stop_event=responsiveness_stop_event,
                    ),
                    name=f"opnet-responsiveness-{opnet_node_id}",
                )

        if docker_image:
            docker_args_with_env = _injectOperatorConnectEnv(docker_args)
            docker_args_with_forwarding = _ensureNetworkArgs(docker_args_with_env)
            structuredLogger.info(
                f"Launching Docker operator image argv={_formatDockerRunArgv(image=docker_image, name=docker_name, runArgs=docker_args_with_forwarding, command=docker_command)}",
                event="lumeflow.sidecar.docker.launching",
                attrs={
                    lumesof_logging.EVENT_OUTCOME: "start",
                    lumesof_logging.LUMESOF_NODE_ID: opnet_node_id or None,
                },
            )
            try:
                docker_container = await event_loop.run_in_executor(
                    None,
                    _startDockerContainer,
                    docker_image,
                    docker_name,
                    docker_args_with_forwarding,
                    docker_command,
                    docker_launch_timeout_s,
                )
            except DockerImageDownloadError as exc:
                await tracker.async_markDownloadFailed(str(exc))
                LOG.warning("Docker image download failed: %s", exc)
            except DockerLaunchError as exc:
                await tracker.async_markLaunchFailed(str(exc))
                LOG.warning("Docker launch failed: %s", exc)
            except RuntimeError as exc:
                await tracker.async_markLaunchFailed(str(exc))
                LOG.warning("Docker launch failed: %s", exc)

        server = await serve(bind, service=sidecar)
        server_wait_task = asyncio.create_task(
            server.wait_closed(),
            name="operator-sidecar-server-wait",
        )
        try:
            monitored_tasks: list[asyncio.Task[Any]] = [server_wait_task]
            if heartbeat_task is not None:
                monitored_tasks.append(heartbeat_task)
            if responsiveness_task is not None:
                monitored_tasks.append(responsiveness_task)

            while True:
                done, _ = await asyncio.wait(
                    monitored_tasks,
                    return_when=asyncio.FIRST_COMPLETED,
                )
                if server_wait_task in done:
                    await server_wait_task
                    break

                for completed_task in done:
                    if completed_task is server_wait_task:
                        continue
                    try:
                        await completed_task
                    except asyncio.CancelledError:
                        raise
                    except Exception as exc:
                        LOG.error(
                            "Background sidecar task failed; shutting down server "
                            "bind=%s error_type=%s error=%s",
                            bind,
                            type(exc).__name__,
                            str(exc) or "<empty>",
                        )
                        server.close()
                        if server_wait_task is not None and not server_wait_task.done():
                            await server_wait_task
                        raise
                    else:
                        message = (
                            "Background sidecar task terminated unexpectedly "
                            f"without error bind={bind}"
                        )
                        LOG.error(message)
                        server.close()
                        if server_wait_task is not None and not server_wait_task.done():
                            await server_wait_task
                        raise RuntimeError(message)
        except asyncio.CancelledError:
            LOG.info("Shutdown requested; closing OperatorSidecar server")
            server.close()
            if server_wait_task is not None and not server_wait_task.done():
                await server_wait_task
            raise
    finally:
        if heartbeat_stop_event is not None:
            heartbeat_stop_event.set()
        if heartbeat_task is not None and not heartbeat_task.done():
            heartbeat_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await heartbeat_task
        if responsiveness_stop_event is not None:
            responsiveness_stop_event.set()
        if responsiveness_task is not None and not responsiveness_task.done():
            responsiveness_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await responsiveness_task
        if server is not None:
            server.close()
        if docker_container:
            LOG.info(
                "Stopping Docker container due to sidecar shutdown container_id=%s",
                docker_container,
            )
            _stopDockerContainer(docker_container)


def _normalizeDockerArgFlags(argv: Sequence[str]) -> list[str]:
    """Ensure --docker-arg values that start with '-' are passed correctly."""

    normalized: list[str] = []
    i = 0
    while i < len(argv):
        token = argv[i]
        if token == "--docker-arg" and i + 1 < len(argv):
            value = argv[i + 1]
            if value.startswith("-"):
                normalized.append(f"--docker-arg={value}")
                i += 2
                continue
        normalized.append(token)
        i += 1
    return normalized


__all__ = [
    "SimpleOperatorSidecar",
    "serve",
    "_asyncMain",
    "_normalizeDockerArgFlags",
    "_parseOpNetPortSpec",
    "_async_connectOpNetController",
    "addOperatorConnectFlags",
]
