from __future__ import annotations

import re
from typing import Any
from typing import Callable
from typing import Optional

from lumecode.lumeflow.runtime.v1.flow_server import dag_pb2
from lumecode.lumeflow.runtime.v1.graph.flow_graph import FlowGraph
from lumecode.lumeflow.runtime.v1.graph.flow_graph import _LINK_TYPE_ASYNC_INJECTOR
from lumecode.lumeflow.runtime.v1.graph.flow_graph import _LINK_TYPE_SYNC_INJECTOR
from lumecode.lumeflow.runtime.v1.graph.flow_graph import _LINK_TYPE_SYNC_RETRIEVER
from lumecode.lumeflow.runtime.v1.operator.operator_image_descriptor import (
    OperatorImageDescriptor,
)
from lumecode.lumeflow.runtime.v1.operator.operator_image_descriptor import (
    OperatorPortDescriptor,
)
from lumecode.lumeflow.runtime.v1.operator.operator_descriptor import OperatorDescriptor
from lumecode.lumeflow.runtime.v1.opnet import opnet_types_pb2


_GRAPH_TYPE_ATTR = "__lumeflow_graph_type__"
_MATERIALIZE_ATTR = "__lumeflow_graph_materialize__"
_VALID_GRAPH_TYPES = frozenset({"sync", "async"})
_CANONICAL_ANY_TYPE_PREFIX = "type.googleapis.com/"


def graph_type(value: str) -> Callable[[type], type]:
    normalized = value.strip().lower()
    if normalized not in _VALID_GRAPH_TYPES:
        raise ValueError(f"graph_type must be one of {sorted(_VALID_GRAPH_TYPES)}, got '{value}'")

    def _decorateGraphClass(cls: type) -> type:
        setattr(cls, _GRAPH_TYPE_ATTR, normalized)
        cls.validateGraphContract()
        return cls

    return _decorateGraphClass


def materialize(method: Callable[..., Any]) -> Callable[..., Any]:
    setattr(method, _MATERIALIZE_ATTR, True)
    return method


class Graph:
    def __init__(self) -> None:
        self.__class__.validateGraphContract()
        self._resetGraphState()

    @classmethod
    def validateGraphContract(cls) -> None:
        graphType = cls._graphTypeValue()
        if graphType not in _VALID_GRAPH_TYPES:
            raise ValueError(
                f"{cls.__name__} must declare @graph_type('sync'|'async'); got '{graphType}'"
            )
        cls._materializeMethodName()

    @classmethod
    def graphType(cls) -> str:
        cls.validateGraphContract()
        graphType = cls._graphTypeValue()
        if graphType is None:
            raise ValueError(f"{cls.__name__} missing @graph_type annotation")
        return graphType

    @classmethod
    def materializeMethodName(cls) -> str:
        cls.validateGraphContract()
        methodName = cls._materializeMethodName()
        if methodName is None:
            raise ValueError(f"{cls.__name__} missing @materialize method")
        return methodName

    def materializeDag(self) -> dag_pb2.Dag:
        self.__class__.validateGraphContract()
        self._resetGraphState()
        methodName = self.__class__.materializeMethodName()
        materializeMethod = getattr(self, methodName)
        dag = materializeMethod()
        if not isinstance(dag, dag_pb2.Dag):
            raise TypeError(
                f"{self.__class__.__name__}.{methodName} must return dag_pb2.Dag, "
                f"got {type(dag).__name__}"
            )
        return dag

    def createOperatorFromImageDescriptor(
        self,
        *,
        name: str,
        descriptor: OperatorImageDescriptor,
    ) -> OperatorDescriptor:
        if not isinstance(descriptor, OperatorImageDescriptor):
            raise TypeError("descriptor must be an OperatorImageDescriptor")
        normalizedName = name.strip()
        if not normalizedName:
            raise ValueError("operator name must be a non-empty string")
        operator = self._flowGraph().createOperatorFromImageDescriptor(
            name=normalizedName,
            descriptor=descriptor,
        )
        self._operatorDescriptors[normalizedName] = descriptor
        return operator

    def connect(
        self,
        *,
        from_: dict[str, str],
        to: dict[str, str],
        linkName: Optional[str] = None,
    ) -> None:
        fromOperatorName, fromPortName = self._parseEndpoint(endpoint=from_, endpointName="from")
        toOperatorName, toPortName = self._parseEndpoint(endpoint=to, endpointName="to")

        fromOperator = self._requireOperator(operatorName=fromOperatorName)
        toOperator = self._requireOperator(operatorName=toOperatorName)

        fromPort = self._requirePortDescriptor(
            operatorName=fromOperatorName,
            portName=fromPortName,
            direction="egress",
        )
        toPort = self._requirePortDescriptor(
            operatorName=toOperatorName,
            portName=toPortName,
            direction="ingress",
        )

        fromPayload = self._payloadFromDescriptor(port=fromPort)
        toPayload = self._payloadFromDescriptor(port=toPort)
        self._ensurePayloadsCompatible(
            fromPayload=fromPayload,
            toPayload=toPayload,
            fromEndpoint=f"{fromOperatorName}.{fromPortName}",
            toEndpoint=f"{toOperatorName}.{toPortName}",
        )

        resolvedLinkName = self._resolveLinkName(
            linkName=linkName,
            defaultValue=self._autoGeneratedLinkName(
                fromOperatorName=fromOperatorName,
                fromPortName=fromPortName,
                toOperatorName=toOperatorName,
                toPortName=toPortName,
            ),
        )

        self._flowGraph().getLink(name=resolvedLinkName).addProducer(
            fromOperator,
            port=fromPortName,
            payload_type=fromPayload,
        ).addConsumer(
            toOperator,
            port=toPortName,
            payload_type=toPayload,
        )

    def setIngress(
        self,
        *,
        to: dict[str, str],
        linkName: Optional[str] = None,
    ) -> None:
        toOperatorName, toPortName = self._parseEndpoint(endpoint=to, endpointName="to")
        toOperator = self._requireOperator(operatorName=toOperatorName)
        toPort = self._requirePortDescriptor(
            operatorName=toOperatorName,
            portName=toPortName,
            direction="ingress",
        )
        toPayload = self._payloadFromDescriptor(port=toPort)

        injectorType = (
            _LINK_TYPE_SYNC_INJECTOR
            if self.__class__.graphType() == "sync"
            else _LINK_TYPE_ASYNC_INJECTOR
        )
        resolvedLinkName = self._resolveLinkName(
            linkName=linkName,
            defaultValue=self._autoGeneratedIngressLinkName(
                toOperatorName=toOperatorName,
                toPortName=toPortName,
            ),
        )

        self._flowGraph().getLink(name=resolvedLinkName).setLinkType(linkType=injectorType).addConsumer(
            toOperator,
            port=toPortName,
            payload_type=toPayload,
        )

    def setEgress(
        self,
        *,
        from_: dict[str, str],
        linkName: Optional[str] = None,
    ) -> None:
        if self.__class__.graphType() != "sync":
            raise ValueError("setEgress is only allowed on @graph_type('sync') graphs")

        fromOperatorName, fromPortName = self._parseEndpoint(endpoint=from_, endpointName="from")
        fromOperator = self._requireOperator(operatorName=fromOperatorName)
        fromPort = self._requirePortDescriptor(
            operatorName=fromOperatorName,
            portName=fromPortName,
            direction="egress",
        )
        fromPayload = self._payloadFromDescriptor(port=fromPort)

        resolvedLinkName = self._resolveLinkName(
            linkName=linkName,
            defaultValue=self._autoGeneratedEgressLinkName(
                fromOperatorName=fromOperatorName,
                fromPortName=fromPortName,
            ),
        )

        self._flowGraph().getLink(name=resolvedLinkName).setLinkType(
            linkType=_LINK_TYPE_SYNC_RETRIEVER
        ).addProducer(
            fromOperator,
            port=fromPortName,
            payload_type=fromPayload,
        )

    def setAllowLoops(self, value: bool) -> None:
        self._flowGraph().setAllowLoops(value)

    def getAllowLoops(self) -> bool:
        return self._flowGraph().getAllowLoops()

    def setDagName(self, name: str) -> None:
        self._flowGraph().setName(name)

    def createDag(self) -> dag_pb2.Dag:
        return self._flowGraph().createDag()

    def validate(self, *, allowLoop: bool = False) -> bool:
        return self._flowGraph().validate(allowLoop=allowLoop)

    def protoPayload(self, schema: str) -> opnet_types_pb2.OpNetPayloadType:
        return self._flowGraph().protoPayload(schema)

    def jsonPayload(self, schema: str) -> opnet_types_pb2.OpNetPayloadType:
        return self._flowGraph().jsonPayload(schema)

    @classmethod
    def _graphTypeValue(cls) -> Optional[str]:
        value = getattr(cls, _GRAPH_TYPE_ATTR, None)
        if not isinstance(value, str):
            return None
        return value.strip().lower()

    @classmethod
    def _materializeMethodName(cls) -> Optional[str]:
        names: list[str] = []
        for name, rawValue in cls.__dict__.items():
            candidate = rawValue
            if isinstance(rawValue, staticmethod):
                candidate = rawValue.__func__
            elif isinstance(rawValue, classmethod):
                candidate = rawValue.__func__
            if callable(candidate) and getattr(candidate, _MATERIALIZE_ATTR, False):
                names.append(name)

        if len(names) == 1:
            return names[0]
        if len(names) == 0:
            raise ValueError(f"{cls.__name__} must define exactly one @materialize method")
        raise ValueError(
            f"{cls.__name__} defines multiple @materialize methods: {sorted(names)}"
        )

    def _resetGraphState(self) -> None:
        self._graphFacade = FlowGraph()
        self._operatorDescriptors: dict[str, OperatorImageDescriptor] = {}

    def _flowGraph(self) -> FlowGraph:
        graph = getattr(self, "_graphFacade", None)
        if graph is None:
            self._resetGraphState()
            graph = self._graphFacade
        return graph

    def _parseEndpoint(self, *, endpoint: dict[str, str], endpointName: str) -> tuple[str, str]:
        if not isinstance(endpoint, dict):
            raise TypeError(f"{endpointName} endpoint must be a dictionary")
        operatorName = str(endpoint.get("operator_name", "")).strip()
        portName = str(endpoint.get("port_name", "")).strip()
        if not operatorName:
            raise ValueError(f"{endpointName}.operator_name must be a non-empty string")
        if not portName:
            raise ValueError(f"{endpointName}.port_name must be a non-empty string")
        return operatorName, portName

    def _requireOperator(self, *, operatorName: str) -> OperatorDescriptor:
        try:
            return self._flowGraph().getOperator(name=operatorName)
        except ValueError as exc:
            raise ValueError(
                f"operator '{operatorName}' must be created via createOperatorFromImageDescriptor before wiring"
            ) from exc

    def _requirePortDescriptor(
        self,
        *,
        operatorName: str,
        portName: str,
        direction: str,
    ) -> OperatorPortDescriptor:
        descriptor = self._operatorDescriptors.get(operatorName)
        if descriptor is None:
            raise ValueError(
                f"operator '{operatorName}' does not have an associated OperatorImageDescriptor"
            )

        matches = [
            port
            for port in descriptor.ports
            if port.name == portName and port.direction == direction
        ]
        if len(matches) == 0:
            raise ValueError(
                f"operator '{operatorName}' port '{portName}' is not declared as {direction}"
            )
        if len(matches) > 1:
            raise ValueError(
                f"operator '{operatorName}' port '{portName}' is ambiguously declared as {direction}"
            )
        return matches[0]

    def _payloadFromDescriptor(self, *, port: OperatorPortDescriptor) -> opnet_types_pb2.OpNetPayloadType:
        payload = opnet_types_pb2.OpNetPayloadType()
        payload.serialization_format = self._serializationFormatEnum(
            serializationFormat=port.serializationFormat
        )
        payload.type_url = self._canonicalizeTypeUrl(
            serializationFormat=payload.serialization_format,
            typeUrl=port.typeUrl,
        )
        return payload

    def _serializationFormatEnum(self, *, serializationFormat: object) -> int:
        if isinstance(serializationFormat, int):
            if serializationFormat == opnet_types_pb2.OpNetPayloadType.SERIALIZATION_FORMAT_UNSPECIFIED:
                raise ValueError("serialization format must not be SERIALIZATION_FORMAT_UNSPECIFIED")
            return serializationFormat

        normalized = str(serializationFormat).strip().upper()
        if "." in normalized:
            normalized = normalized.split(".")[-1]

        if normalized == "PROTO":
            return opnet_types_pb2.OpNetPayloadType.PROTO
        if normalized == "JSON":
            return opnet_types_pb2.OpNetPayloadType.JSON
        if normalized in {"", "SERIALIZATION_FORMAT_UNSPECIFIED"}:
            raise ValueError("serialization format must be PROTO or JSON")

        raise ValueError(f"unsupported serialization format '{serializationFormat}'")

    def _canonicalizeTypeUrl(self, *, serializationFormat: int, typeUrl: str) -> str:
        normalizedTypeUrl = typeUrl.strip()
        if not normalizedTypeUrl:
            raise ValueError("type_url must be non-empty")

        if serializationFormat != opnet_types_pb2.OpNetPayloadType.PROTO:
            return normalizedTypeUrl

        if normalizedTypeUrl.startswith(_CANONICAL_ANY_TYPE_PREFIX):
            return normalizedTypeUrl
        if "/" in normalizedTypeUrl:
            return normalizedTypeUrl
        return f"{_CANONICAL_ANY_TYPE_PREFIX}{normalizedTypeUrl}"

    def _ensurePayloadsCompatible(
        self,
        *,
        fromPayload: opnet_types_pb2.OpNetPayloadType,
        toPayload: opnet_types_pb2.OpNetPayloadType,
        fromEndpoint: str,
        toEndpoint: str,
    ) -> None:
        if fromPayload.serialization_format != toPayload.serialization_format:
            raise ValueError(
                f"serialization format mismatch between '{fromEndpoint}' and '{toEndpoint}'"
            )
        if fromPayload.type_url != toPayload.type_url:
            raise ValueError(
                f"type_url mismatch between '{fromEndpoint}' and '{toEndpoint}' after canonicalization"
            )

    def _resolveLinkName(self, *, linkName: Optional[str], defaultValue: str) -> str:
        if linkName is None:
            return defaultValue
        normalized = linkName.strip()
        if not normalized:
            raise ValueError("linkName must be a non-empty string when provided")
        return normalized

    def _autoGeneratedLinkName(
        self,
        *,
        fromOperatorName: str,
        fromPortName: str,
        toOperatorName: str,
        toPortName: str,
    ) -> str:
        return self._sanitizeLinkName(
            f"{fromOperatorName}-{fromPortName}-{toOperatorName}-{toPortName}"
        )

    def _autoGeneratedIngressLinkName(self, *, toOperatorName: str, toPortName: str) -> str:
        return self._sanitizeLinkName(f"ingress-{toOperatorName}-{toPortName}")

    def _autoGeneratedEgressLinkName(self, *, fromOperatorName: str, fromPortName: str) -> str:
        return self._sanitizeLinkName(f"egress-{fromOperatorName}-{fromPortName}")

    def _sanitizeLinkName(self, value: str) -> str:
        sanitized = re.sub(r"[^A-Za-z0-9]+", "-", value.strip())
        sanitized = sanitized.strip("-")
        if not sanitized:
            raise ValueError("auto-generated link name is empty")
        return sanitized
