from __future__ import annotations

from typing import Dict, Optional

from lumecode.lumeflow.runtime.v1.graph.internal_graph import _InternalFlowGraph
from lumecode.lumeflow.runtime.v1.operator.operator_image_descriptor import (
    OperatorImageDescriptor,
)
from lumecode.lumeflow.runtime.v1.operator.operator_descriptor import OperatorDescriptor
from lumecode.lumeflow.runtime.v1.flow_server import dag_pb2
from lumecode.lumeflow.runtime.v1.opnet import opnet_types_pb2

_LINK_TYPE_REGULAR = "REGULAR"
_LINK_TYPE_SYNC_INJECTOR = "SYNC_INJECTOR"
_LINK_TYPE_ASYNC_INJECTOR = "ASYNC_INJECTOR"
_LINK_TYPE_SYNC_RETRIEVER = "SYNC_RETRIEVER"
_INJECTOR_LINK_TYPES = {_LINK_TYPE_SYNC_INJECTOR, _LINK_TYPE_ASYNC_INJECTOR}
_DEFAULT_MIN_INSTANCES = 1
_DEFAULT_MAX_INSTANCES = 1


class FlowGraph:
    """Internal graph-builder for constructing and validating Flow DAGs.

    This class wraps the in-memory planning graph and provides methods for:

    1. Declaring operators and links.
    2. Assigning typed ingress/egress ports.
    3. Validating graph integrity.
    4. Materializing a ``dag_pb2.Dag`` for submission.
    """

    def __init__(
        self,
        *,
        backend: object | None = None,
        dag: Optional[dag_pb2.Dag] = None,
        name: Optional[str] = None,
    ):
        self._backend = backend
        self._graph = _InternalFlowGraph()
        self._name = name
        if dag is not None:
            self._loadDag(dag=dag, name_override=name)

    # -------- plan-building APIs (delegated to _InternalFlowGraph) --------

    def getLink(self, *, name: str):
        """Return an existing logical link plan, or create it if missing."""
        return self._graph.getLink(name=name)

    def getOperator(
        self, *, name: str, info: Optional[Dict[str, str]] = None, is_entrypoint: bool = False
    ) -> OperatorDescriptor:
        """Return an existing operator plan, or create it if missing.

        Args:
            name: Operator name.
            info: Optional metadata dictionary (for example image URL metadata).
            is_entrypoint: Marks this operator as graph entrypoint when true.
        """
        return self._graph.getOperator(name=name, info=info, is_entrypoint=is_entrypoint)

    def createOperator(self, *, name: str, info: Dict[str, str], is_entrypoint: bool = False) -> OperatorDescriptor:
        """Create and return a new operator plan.

        Raises:
            ValueError: If an operator with the same name already exists.
        """
        return self._graph.createOperator(name=name, info=info, is_entrypoint=is_entrypoint)

    def createOperatorFromImageDescriptor(
        self,
        *,
        name: str,
        descriptor: OperatorImageDescriptor,
    ) -> OperatorDescriptor:
        """Create and return a new operator plan from an image descriptor."""
        if not isinstance(descriptor, OperatorImageDescriptor):
            raise TypeError("descriptor must be an OperatorImageDescriptor")
        return self._graph.createOperator(
            name=name,
            info={"url": descriptor.imageUrl},
            is_entrypoint=False,
        )

    def protoPayload(self, schema: str) -> opnet_types_pb2.OpNetPayloadType:
        """Build a protobuf payload-type descriptor for ports and links."""
        return self._graph.protoPayload(schema)

    def jsonPayload(self, schema: str) -> opnet_types_pb2.OpNetPayloadType:
        """Build a JSON payload-type descriptor for ports and links."""
        return self._graph.jsonPayload(schema)

    def addProducer(
        self,
        *,
        link_name: str,
        operator: OperatorDescriptor,
        port: str,
        payload_type: opnet_types_pb2.OpNetPayloadType,
    ):
        """Attach a producer endpoint to a named link and return the link plan."""
        link = self._graph.getLink(name=link_name)
        return link.addProducer(operator, port=port, payload_type=payload_type)

    def addConsumer(
        self,
        *,
        link_name: str,
        operator: OperatorDescriptor,
        port: str,
        payload_type: opnet_types_pb2.OpNetPayloadType,
    ):
        """Attach a consumer endpoint to a named link and return the link plan."""
        link = self._graph.getLink(name=link_name)
        return link.addConsumer(operator, port=port, payload_type=payload_type)

    def createDag(self) -> dag_pb2.Dag:
        """Validate and serialize this graph into ``dag_pb2.Dag``.

        Returns:
            Fully-populated DAG protobuf ready for ``SubmitJob``.
        """
        # Validate to ensure we only emit valid DAGs (and that entrypoint is present/unique).
        self.validate(allowLoop=self._graph.getAllowLoops())

        dag_msg = dag_pb2.Dag()
        if self._name:
            dag_msg.name = self._name

        # Write graph_type derived from the injector link type.
        graph_type_str = self._graph.getGraphType()
        if graph_type_str == "SYNC":
            dag_msg.graph_type = dag_pb2.GraphType.SYNC
        elif graph_type_str == "ASYNC":
            dag_msg.graph_type = dag_pb2.GraphType.ASYNC

        dag_msg.allow_loops = self._graph.getAllowLoops()

        # Operators
        operator_msgs: Dict[str, dag_pb2.Operator] = {}
        for name, op in sorted(self._graph.iterOperators()):
            op_msg = dag_msg.operators.add()
            op_msg.name = name
            op_msg.image_url = getattr(op, "_url", op.info.get("url", ""))
            min_instances, max_instances = self._resolveOperatorInstancePolicy(op.info)
            op_msg.instance_policy.num_min_instances = min_instances
            op_msg.instance_policy.num_max_instances = max_instances
            if not op_msg.image_url:
                raise ValueError(f'Operator "{name}" is missing required url/image_url.')
            operator_msgs[name] = op_msg

        # Links (and derive ports)
        ports_seen: Dict[str, set[tuple[str, int]]] = {}

        def _attachPort(op_name: str, port_name: str, direction: dag_pb2.Port.Direction, payload_type):
            op_msg = operator_msgs.get(op_name)
            if op_msg is None:
                raise ValueError(f'Port references unknown operator "{op_name}".')
            seen = ports_seen.setdefault(op_name, set())
            key = (port_name, direction)
            if key in seen:
                return
            port_msg = op_msg.ports.add()
            port_msg.name = port_name
            port_msg.direction = direction
            port_msg.payload_type.CopyFrom(payload_type)
            seen.add(key)

        for link_name, plan in sorted(self._graph.iterLinks()):
            producers = [a for a in plan._attachments if a.direction == "ingress"]
            consumers = [a for a in plan._attachments if a.direction == "egress"]
            linkType = plan.getLinkType()
            link_msg = dag_msg.links.add()
            link_msg.name = link_name
            link_msg.link_type = self._linkTypeToProtoEnum(linkType=linkType)

            if linkType == _LINK_TYPE_REGULAR:
                if len(producers) != 1 or len(consumers) != 1:
                    raise ValueError(
                        f'Link "{link_name}" with link_type REGULAR must have exactly one producer and one consumer.'
                    )
                prod = producers[0]
                cons = consumers[0]
                prod_payload_type = self._ensurePayloadTypeValid(link_name, prod.payload_type)
                cons_payload_type = self._ensurePayloadTypeValid(link_name, cons.payload_type)

                prod_name = self._resolveOperatorName(link_name=link_name, attachment=prod)
                cons_name = self._resolveOperatorName(link_name=link_name, attachment=cons)
                _attachPort(prod_name, prod.port, dag_pb2.Port.EGRESS, prod_payload_type)
                _attachPort(cons_name, cons.port, dag_pb2.Port.INGRESS, cons_payload_type)

                link_msg.egress_operator = prod_name
                link_msg.egress_port = prod.port
                link_msg.ingress_operator = cons_name
                link_msg.ingress_port = cons.port
                link_msg.payload_type.CopyFrom(prod_payload_type)
                continue

            if linkType in _INJECTOR_LINK_TYPES:
                if len(producers) != 0 or len(consumers) != 1:
                    raise ValueError(
                        f'Link "{link_name}" with link_type {linkType} must have no producer and exactly one consumer.'
                    )
                cons = consumers[0]
                cons_payload_type = self._ensurePayloadTypeValid(link_name, cons.payload_type)
                cons_name = self._resolveOperatorName(link_name=link_name, attachment=cons)
                _attachPort(cons_name, cons.port, dag_pb2.Port.INGRESS, cons_payload_type)

                link_msg.ingress_operator = cons_name
                link_msg.ingress_port = cons.port
                link_msg.payload_type.CopyFrom(cons_payload_type)
                dag_msg.dag_ingress.operator = cons_name
                dag_msg.dag_ingress.port = cons.port
                continue

            if linkType == _LINK_TYPE_SYNC_RETRIEVER:
                if len(producers) != 1 or len(consumers) != 0:
                    raise ValueError(
                        f'Link "{link_name}" with link_type SYNC_RETRIEVER must have exactly one producer and no consumer.'
                    )
                prod = producers[0]
                prod_payload_type = self._ensurePayloadTypeValid(link_name, prod.payload_type)
                prod_name = self._resolveOperatorName(link_name=link_name, attachment=prod)
                _attachPort(prod_name, prod.port, dag_pb2.Port.EGRESS, prod_payload_type)

                link_msg.egress_operator = prod_name
                link_msg.egress_port = prod.port
                link_msg.payload_type.CopyFrom(prod_payload_type)
                dag_msg.dag_egress.operator = prod_name
                dag_msg.dag_egress.port = prod.port
                continue

            raise ValueError(f'Link "{link_name}" has unsupported link_type "{linkType}".')

        return dag_msg

    def validate(self, *, allowLoop: bool = False) -> bool:
        """Validate the graph and return whether loops are present.

        Args:
            allowLoop: When false, cyclic graphs are rejected.
        """
        return self._graph.validate(allowLoop=allowLoop)

    # -------- graph property accessors --------

    def setAllowLoops(self, value: bool) -> None:
        """Set whether this graph allows cycles."""
        self._graph.setAllowLoops(value)

    def getAllowLoops(self) -> bool:
        """Return whether this graph allows cycles."""
        return self._graph.getAllowLoops()

    def getName(self) -> Optional[str]:
        """Return the DAG name, if set."""
        return self._name

    def setName(self, name: Optional[str]) -> None:
        """Set the DAG name."""
        if name is None:
            self._name = None
            return
        normalizedName = str(name).strip()
        if not normalizedName:
            raise ValueError("name must be a non-empty string when provided")
        self._name = normalizedName

    def getGraphType(self) -> str:
        """Return 'SYNC', 'ASYNC', or 'UNKNOWN' derived from the injector link type."""
        return self._graph.getGraphType()

    def getDagIngress(self) -> Optional[tuple[str, str]]:
        """Return (operator, port) for the DAG ingress, derived from the injector link."""
        return self._graph.getDagIngress()

    def getDagEgress(self) -> Optional[tuple[str, str]]:
        """Return (operator, port) for the DAG egress, derived from the SYNC_RETRIEVER link."""
        return self._graph.getDagEgress()

    def iterOperatorSpecs(self):
        """Yield OperatorSpec for each operator in the graph."""
        return self._graph.iterOperatorSpecs()

    def iterLinkSpecs(self):
        """Yield LinkSpec for each link in the graph."""
        return self._graph.iterLinkSpecs()

    def buildBfsLevels(self) -> list[list[str]]:
        """Return BFS-ordered operator name levels from the dag_ingress entrypoint.

        Raises ValueError if no injector link is set or unreachable operators exist.
        """
        return self._graph.buildBfsLevels()

    def _loadDag(self, *, dag: dag_pb2.Dag, name_override: Optional[str]) -> None:
        """Hydrate the in-memory graph from a Dag proto."""
        if name_override and dag.name and dag.name != name_override:
            raise ValueError(f'DAG name "{dag.name}" does not match override "{name_override}".')

        if dag.graph_type == dag_pb2.GraphType.GRAPH_TYPE_UNSPECIFIED:
            raise ValueError("Dag.graph_type must be set to SYNC or ASYNC.")

        self._name = name_override if name_override is not None else (dag.name or None)
        self._graphType = dag.graph_type
        self._graph.setAllowLoops(dag.allow_loops)

        # Operators first (collect port definitions for validation)
        operator_ports: Dict[str, Dict[tuple[str, int], opnet_types_pb2.OpNetPayloadType]] = {}
        for op_msg in dag.operators:
            if not op_msg.name:
                raise ValueError("DAG operator entry is missing a name")
            if not op_msg.image_url:
                raise ValueError(f'Operator "{op_msg.name}" is missing required image_url')

            info_map = {"url": op_msg.image_url}
            min_instances, max_instances = self._policyFromProto(op_msg=op_msg)
            info_map["instancePolicyMin"] = min_instances
            info_map["instancePolicyMax"] = max_instances

            is_entrypoint = op_msg.name == dag.dag_ingress.operator and bool(dag.dag_ingress.operator)
            self._graph.createOperator(name=op_msg.name, info=info_map, is_entrypoint=is_entrypoint)

            ports_for_op: Dict[tuple[str, int], opnet_types_pb2.OpNetPayloadType] = {}
            for port in op_msg.ports:
                if not port.name:
                    raise ValueError(f'Operator "{op_msg.name}" port is missing a name')
                if port.direction == dag_pb2.Port.Direction.DIRECTION_UNSPECIFIED:
                    raise ValueError(f'Operator "{op_msg.name}" port "{port.name}" has unspecified direction')
                canonical_port_payload = self._ensurePayloadTypeValid(f"{op_msg.name}.{port.name}", port.payload_type)
                key = (port.name, port.direction)
                if key in ports_for_op:
                    raise ValueError(
                        f'Operator "{op_msg.name}" has duplicate port "{port.name}" with direction {port.direction}'
                    )
                ports_for_op[key] = canonical_port_payload
            operator_ports[op_msg.name] = ports_for_op

        # Links
        for link_msg in dag.links:
            if not link_msg.name:
                raise ValueError("DAG link entry is missing a name")
            linkType = self._normalizeLinkTypeFromProto(linkType=link_msg.link_type)
            canonical_link_payload = self._ensurePayloadTypeValid(link_msg.name, link_msg.payload_type)

            plan = self._graph.getLink(name=link_msg.name)
            plan.setLinkType(linkType=linkType)

            if linkType == _LINK_TYPE_REGULAR:
                if not link_msg.egress_operator or not link_msg.ingress_operator:
                    raise ValueError(
                        f'Link "{link_msg.name}" with link_type REGULAR must have both ingress and egress operators set.'
                    )
                if not link_msg.egress_port or not link_msg.ingress_port:
                    raise ValueError(
                        f'Link "{link_msg.name}" with link_type REGULAR must have both ingress and egress ports set.'
                    )

                try:
                    producer = self._graph.getOperator(name=link_msg.egress_operator)
                    consumer = self._graph.getOperator(name=link_msg.ingress_operator)
                except ValueError as e:
                    raise ValueError(
                        f'Link "{link_msg.name}" references unknown operators '
                        f'"{link_msg.egress_operator}" or "{link_msg.ingress_operator}".'
                    ) from e

                prod_ports = operator_ports.get(link_msg.egress_operator, {})
                cons_ports = operator_ports.get(link_msg.ingress_operator, {})
                prod_port_type = self._portPayloadForDirections(
                    linkName=link_msg.name,
                    operatorName=link_msg.egress_operator,
                    portName=link_msg.egress_port,
                    directionKind="egress",
                    portsForOperator=prod_ports,
                    allowedDirections=(dag_pb2.Port.EGRESS,),
                )
                cons_port_type = self._portPayloadForDirections(
                    linkName=link_msg.name,
                    operatorName=link_msg.ingress_operator,
                    portName=link_msg.ingress_port,
                    directionKind="ingress",
                    portsForOperator=cons_ports,
                    allowedDirections=(dag_pb2.Port.INGRESS,),
                )
                if prod_port_type != canonical_link_payload:
                    raise ValueError(
                        f'Link "{link_msg.name}" payload_type does not match operator '
                        f'"{link_msg.egress_operator}" port "{link_msg.egress_port}".'
                    )
                if cons_port_type != canonical_link_payload:
                    raise ValueError(
                        f'Link "{link_msg.name}" payload_type does not match operator '
                        f'"{link_msg.ingress_operator}" port "{link_msg.ingress_port}".'
                    )

                plan.addProducer(producer, port=link_msg.egress_port, payload_type=canonical_link_payload)
                plan.addConsumer(consumer, port=link_msg.ingress_port, payload_type=canonical_link_payload)
                continue

            if linkType in _INJECTOR_LINK_TYPES:
                if link_msg.egress_operator or link_msg.egress_port:
                    raise ValueError(
                        f'Link "{link_msg.name}" with link_type {linkType} must not set egress operator or egress port.'
                    )
                if not link_msg.ingress_operator or not link_msg.ingress_port:
                    raise ValueError(
                        f'Link "{link_msg.name}" with link_type {linkType} must set ingress operator and ingress port.'
                    )
                try:
                    consumer = self._graph.getOperator(name=link_msg.ingress_operator)
                except ValueError as e:
                    raise ValueError(
                        f'Link "{link_msg.name}" references unknown ingress operator "{link_msg.ingress_operator}".'
                    ) from e

                cons_ports = operator_ports.get(link_msg.ingress_operator, {})
                cons_port_type = self._portPayloadForDirections(
                    linkName=link_msg.name,
                    operatorName=link_msg.ingress_operator,
                    portName=link_msg.ingress_port,
                    directionKind="ingress",
                    portsForOperator=cons_ports,
                    allowedDirections=(dag_pb2.Port.INGRESS,),
                )
                if cons_port_type != canonical_link_payload:
                    raise ValueError(
                        f'Link "{link_msg.name}" payload_type does not match operator '
                        f'"{link_msg.ingress_operator}" port "{link_msg.ingress_port}".'
                    )
                plan.addConsumer(consumer, port=link_msg.ingress_port, payload_type=canonical_link_payload)
                continue

            if linkType == _LINK_TYPE_SYNC_RETRIEVER:
                if link_msg.ingress_operator or link_msg.ingress_port:
                    raise ValueError(
                        f'Link "{link_msg.name}" with link_type SYNC_RETRIEVER must not set ingress operator or ingress port.'
                    )
                if not link_msg.egress_operator or not link_msg.egress_port:
                    raise ValueError(
                        f'Link "{link_msg.name}" with link_type SYNC_RETRIEVER must set egress operator and egress port.'
                    )
                try:
                    producer = self._graph.getOperator(name=link_msg.egress_operator)
                except ValueError as e:
                    raise ValueError(
                        f'Link "{link_msg.name}" references unknown egress operator "{link_msg.egress_operator}".'
                    ) from e

                prod_ports = operator_ports.get(link_msg.egress_operator, {})
                prod_port_type = self._portPayloadForDirections(
                    linkName=link_msg.name,
                    operatorName=link_msg.egress_operator,
                    portName=link_msg.egress_port,
                    directionKind="egress",
                    portsForOperator=prod_ports,
                    allowedDirections=(dag_pb2.Port.EGRESS,),
                )
                if prod_port_type != canonical_link_payload:
                    raise ValueError(
                        f'Link "{link_msg.name}" payload_type does not match operator '
                        f'"{link_msg.egress_operator}" port "{link_msg.egress_port}".'
                    )
                plan.addProducer(producer, port=link_msg.egress_port, payload_type=canonical_link_payload)
                continue

            raise ValueError(f'Link "{link_msg.name}" has unsupported link_type "{linkType}".')

        # Validate graph_type consistency with derived type from link structure.
        derived_graph_type = self._graph.getGraphType()
        if derived_graph_type == "SYNC" and dag.graph_type != dag_pb2.GraphType.SYNC:
            raise ValueError(
                "Dag.graph_type must be SYNC when a SYNC_INJECTOR link is present."
            )
        if derived_graph_type == "ASYNC" and dag.graph_type != dag_pb2.GraphType.ASYNC:
            raise ValueError(
                "Dag.graph_type must be ASYNC when an ASYNC_INJECTOR link is present."
            )

        # Validate dag_ingress and dag_egress explicit proto fields.
        if not dag.dag_ingress.operator or not dag.dag_ingress.port:
            raise ValueError("Dag.dag_ingress.operator and Dag.dag_ingress.port are required.")
        op_names = set(self._graph._operators.keys())
        if dag.dag_ingress.operator not in op_names:
            raise ValueError(
                f'Dag.dag_ingress.operator "{dag.dag_ingress.operator}" is not a known operator.'
            )
        ingress_op_ports = {
            p.name for op in dag.operators if op.name == dag.dag_ingress.operator for p in op.ports
        }
        if dag.dag_ingress.port not in ingress_op_ports:
            raise ValueError(
                f'Dag.dag_ingress.port "{dag.dag_ingress.port}" is not a port on '
                f'operator "{dag.dag_ingress.operator}".'
            )
        if dag.graph_type == dag_pb2.GraphType.SYNC:
            if not dag.dag_egress.operator or not dag.dag_egress.port:
                raise ValueError(
                    "Dag.dag_egress.operator and Dag.dag_egress.port are required for SYNC dags."
                )
            if dag.dag_egress.operator not in op_names:
                raise ValueError(
                    f'Dag.dag_egress.operator "{dag.dag_egress.operator}" is not a known operator.'
                )
            egress_op_ports = {
                p.name for op in dag.operators if op.name == dag.dag_egress.operator for p in op.ports
            }
            if dag.dag_egress.port not in egress_op_ports:
                raise ValueError(
                    f'Dag.dag_egress.port "{dag.dag_egress.port}" is not a port on '
                    f'operator "{dag.dag_egress.operator}".'
                )
        elif dag.graph_type == dag_pb2.GraphType.ASYNC:
            if dag.dag_egress.operator or dag.dag_egress.port:
                raise ValueError("Dag.dag_egress must not be set for ASYNC dags.")

    @staticmethod
    def _ensurePayloadTypeValid(
        link_name: str,
        payload_type: opnet_types_pb2.OpNetPayloadType,
    ) -> opnet_types_pb2.OpNetPayloadType:
        """Return a validated canonicalized payload_type copy."""
        canonical_payload_type = opnet_types_pb2.OpNetPayloadType()
        canonical_payload_type.CopyFrom(payload_type)
        _InternalFlowGraph._canonicalizePayloadType(link_name=link_name, payload_type=canonical_payload_type)
        return canonical_payload_type

    @staticmethod
    def _linkTypeToProtoEnum(*, linkType: str) -> dag_pb2.Link.LinkType:
        normalized = (linkType or "").strip().upper()
        if normalized == _LINK_TYPE_REGULAR:
            return dag_pb2.Link.REGULAR
        if normalized == _LINK_TYPE_SYNC_INJECTOR:
            return dag_pb2.Link.SYNC_INJECTOR
        if normalized == _LINK_TYPE_ASYNC_INJECTOR:
            return dag_pb2.Link.ASYNC_INJECTOR
        if normalized == _LINK_TYPE_SYNC_RETRIEVER:
            return dag_pb2.Link.SYNC_RETRIEVER
        raise ValueError(f'Unsupported link_type "{linkType}".')

    @staticmethod
    def _normalizeLinkTypeFromProto(*, linkType: int) -> str:
        if linkType in (dag_pb2.Link.LINK_TYPE_UNSPECIFIED, dag_pb2.Link.REGULAR):
            return _LINK_TYPE_REGULAR
        if linkType == dag_pb2.Link.SYNC_INJECTOR:
            return _LINK_TYPE_SYNC_INJECTOR
        if linkType == dag_pb2.Link.ASYNC_INJECTOR:
            return _LINK_TYPE_ASYNC_INJECTOR
        if linkType == dag_pb2.Link.SYNC_RETRIEVER:
            return _LINK_TYPE_SYNC_RETRIEVER
        raise ValueError(f"Unsupported link_type enum value: {linkType}")

    @staticmethod
    def _resolveOperatorName(*, link_name: str, attachment) -> str:
        op_name = getattr(attachment.operator, "name", None) or (
            attachment.operator.info.get("name") if isinstance(attachment.operator.info, dict) else None
        )
        if not op_name:
            raise ValueError(f'Link "{link_name}" attachment references unnamed operator.')
        return op_name

    def _policyFromProto(self, *, op_msg: dag_pb2.Operator) -> tuple[int, int]:
        policy = dag_pb2.OperatorInstancePolicy(
            num_min_instances=_DEFAULT_MIN_INSTANCES,
            num_max_instances=_DEFAULT_MAX_INSTANCES,
        )
        policy.MergeFrom(op_msg.instance_policy)
        num_min_instances = int(policy.num_min_instances)
        num_max_instances = int(policy.num_max_instances)
        self._validateOperatorInstancePolicy(
            operator_name=op_msg.name,
            num_min_instances=num_min_instances,
            num_max_instances=num_max_instances,
        )
        return num_min_instances, num_max_instances

    @staticmethod
    def _resolveOperatorInstancePolicy(info: dict[str, object]) -> tuple[int, int]:
        raw_min = info.get("instancePolicyMin", _DEFAULT_MIN_INSTANCES)
        raw_max = info.get("instancePolicyMax", _DEFAULT_MAX_INSTANCES)
        try:
            num_min_instances = int(raw_min)
            num_max_instances = int(raw_max)
        except (TypeError, ValueError) as exc:
            raise ValueError("Operator instance policy values must be integers.") from exc
        FlowGraph._validateOperatorInstancePolicy(
            operator_name=str(info.get("name", "")),
            num_min_instances=num_min_instances,
            num_max_instances=num_max_instances,
        )
        return num_min_instances, num_max_instances

    @staticmethod
    def _validateOperatorInstancePolicy(
        *,
        operator_name: str,
        num_min_instances: int,
        num_max_instances: int,
    ) -> None:
        if num_min_instances <= 0 or num_max_instances <= 0:
            raise ValueError(
                f'Operator "{operator_name}" instance policy must set positive '
                f"num_min_instances and num_max_instances."
            )
        if num_min_instances != num_max_instances:
            raise ValueError(
                f'Operator "{operator_name}" instance policy must satisfy '
                "num_min_instances == num_max_instances."
            )

    @staticmethod
    def _portPayloadForDirections(
        *,
        linkName: str,
        operatorName: str,
        portName: str,
        directionKind: str,
        portsForOperator: Dict[tuple[str, int], opnet_types_pb2.OpNetPayloadType],
        allowedDirections: tuple[int, ...],
    ) -> opnet_types_pb2.OpNetPayloadType:
        matches = [portsForOperator.get((portName, direction)) for direction in allowedDirections]
        present = [payload for payload in matches if payload is not None]
        if not present:
            raise ValueError(
                f'Link "{linkName}" {directionKind} port "{portName}" is missing on operator "{operatorName}".'
            )
        if len(present) > 1:
            raise ValueError(
                f'Link "{linkName}" {directionKind} port "{portName}" is ambiguously defined on operator "{operatorName}".'
            )
        return present[0]
