# lumecode/lumeflow/runtime/v1/flow_server/flow_graph.py
from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass
from typing import DefaultDict, Dict, List, Optional, Set

from lumecode.lumeflow.runtime.v1.opnet.opnet_types_pb2 import OpNetPayloadType
from lumecode.lumeflow.runtime.v1.operator.operator_descriptor import OperatorDescriptor

_LINK_TYPE_REGULAR = "REGULAR"
_LINK_TYPE_SYNC_INJECTOR = "SYNC_INJECTOR"
_LINK_TYPE_ASYNC_INJECTOR = "ASYNC_INJECTOR"
_LINK_TYPE_SYNC_RETRIEVER = "SYNC_RETRIEVER"
_CANONICAL_ANY_TYPE_PREFIX = "type.googleapis.com/"
_SUPPORTED_LINK_TYPES = {
    _LINK_TYPE_REGULAR,
    _LINK_TYPE_SYNC_INJECTOR,
    _LINK_TYPE_ASYNC_INJECTOR,
    _LINK_TYPE_SYNC_RETRIEVER,
}
_INJECTOR_LINK_TYPES = {_LINK_TYPE_SYNC_INJECTOR, _LINK_TYPE_ASYNC_INJECTOR}


@dataclass(frozen=True)
class OperatorSpec:
    """Read-only view of an operator in the flow graph."""

    name: str
    imageUrl: str
    instancePolicyMin: int
    instancePolicyMax: int


@dataclass(frozen=True)
class LinkSpec:
    """Read-only view of a link in the flow graph."""

    name: str
    linkType: str
    egressOperator: Optional[str]
    egressPort: Optional[str]
    ingressOperator: Optional[str]
    ingressPort: Optional[str]


@dataclass(frozen=True)
class _Attachment:
    operator: OperatorDescriptor
    port: str
    direction: str  # "ingress" | "egress"
    payload_type: OpNetPayloadType


class _InternalFlowGraph:
    """
    In-memory flow graph planner/validator (no backend dependencies).

    Link types:
      - REGULAR: one producer and one consumer
      - SYNC_INJECTOR: entry-point link for sync graphs (zero producers, one consumer)
      - ASYNC_INJECTOR: entry-point link for async graphs (zero producers, one consumer)
      - SYNC_RETRIEVER: exit-point link (one producer, zero consumers)

    The graph entrypoint is derived from the single INJECTOR link's consumer during
    validation. Callers no longer explicitly mark operators as entrypoints.
    """

    def __init__(self):
        self._links: Dict[str, _FlowLinkPlan] = {}
        self._operators: Dict[str, OperatorDescriptor] = {}
        self._entrypoints: Set[str] = set()
        self._allowLoops: bool = False

    def _markEntrypoint(self, name: str) -> None:
        """Record an operator name as the graph entrypoint."""
        if not isinstance(name, str) or not name.strip():
            raise ValueError("Entrypoint operator name must be a non-empty string")
        self._entrypoints.add(name)

    # -------- plan-building APIs --------

    def getLink(self, *, name: str) -> "_FlowLinkPlan":
        """Return the link plan (create if missing)."""
        plan = self._links.get(name)
        if plan is None:
            plan = _FlowLinkPlan(graph=self, name=name)
            self._links[name] = plan
        return plan

    def getOperator(
        self, *, name: str, info: Optional[Dict[str, str]] = None, is_entrypoint: bool = False
    ) -> OperatorDescriptor:
        """
        Return an OperatorDescriptor by name; create if missing.

        If creating, `info` is required and must at least contain "url".
        If the operator already exists and `info` is provided, it must be consistent.
        """
        existing = self._operators.get(name)
        if existing is not None:
            if info and "url" in info and hasattr(existing, "_url"):
                if info["url"] != getattr(existing, "_url"):
                    raise ValueError(f'Operator "{name}" already exists with a different URL')
            if is_entrypoint:
                self._markEntrypoint(name)
            return existing

        if info is None:
            raise ValueError(f'Operator "{name}" does not exist; `info` is required to create it')

        info_copy = dict(info)
        info_copy.setdefault("name", name)
        op = OperatorDescriptor(name=name, info=info_copy)
        self._operators[name] = op
        if is_entrypoint:
            self._markEntrypoint(name)
        return op

    def createOperator(self, *, name: str, info: Dict[str, str], is_entrypoint: bool = False) -> OperatorDescriptor:
        """Create a new OperatorDescriptor with the given name; error if it already exists."""
        if name in self._operators:
            raise ValueError(f'Operator "{name}" already exists')
        info_copy = dict(info)
        info_copy.setdefault("name", name)
        op = OperatorDescriptor(name=name, info=info_copy)
        self._operators[name] = op
        if is_entrypoint:
            self._markEntrypoint(name)
        return op

    def protoPayload(self, type_url: str) -> OpNetPayloadType:
        pt = OpNetPayloadType()
        pt.serialization_format = OpNetPayloadType.PROTO
        pt.type_url = self._canonicalizeProtoTypeUrl(type_url=type_url)
        return pt

    def jsonPayload(self, type_url: str) -> OpNetPayloadType:
        pt = OpNetPayloadType()
        pt.serialization_format = OpNetPayloadType.JSON
        pt.type_url = type_url
        return pt

    def getEntrypointName(self) -> Optional[str]:
        """Return the marked entrypoint operator name, if any."""
        if not self._entrypoints:
            return None
        # If multiple have been marked, return one deterministically for callers (validate will enforce uniqueness).
        return sorted(self._entrypoints)[0]

    def iterOperators(self):
        """Yield (name, OperatorDescriptor) pairs."""
        return self._operators.items()

    def iterLinks(self):
        """Yield (link_name, _FlowLinkPlan) pairs."""
        return self._links.items()

    # -------- allow-loops --------

    def setAllowLoops(self, value: bool) -> None:
        self._allowLoops = value

    def getAllowLoops(self) -> bool:
        return self._allowLoops

    # -------- derived graph properties --------

    def getGraphType(self) -> str:
        """Derive graph type from injector link type.

        Returns 'SYNC', 'ASYNC', or 'UNKNOWN' (no injector link present).
        """
        for plan in self._links.values():
            if plan.getLinkType() == _LINK_TYPE_SYNC_INJECTOR:
                return "SYNC"
            if plan.getLinkType() == _LINK_TYPE_ASYNC_INJECTOR:
                return "ASYNC"
        return "UNKNOWN"

    def getDagIngress(self) -> Optional[tuple[str, str]]:
        """Derive (operator, port) for dag_ingress from the INJECTOR link's consumer.

        Returns None if no injector link is present.
        """
        for plan in self._links.values():
            if plan.getLinkType() in _INJECTOR_LINK_TYPES:
                consumers = [a for a in plan._attachments if a.direction == "egress"]
                if consumers:
                    op_name = self._operatorNameForAttachment(
                        link_name=plan.name, attachment=consumers[0]
                    )
                    return (op_name, consumers[0].port)
        return None

    def getDagEgress(self) -> Optional[tuple[str, str]]:
        """Derive (operator, port) for dag_egress from the SYNC_RETRIEVER link's producer.

        Returns None if no SYNC_RETRIEVER link is present.
        """
        for plan in self._links.values():
            if plan.getLinkType() == _LINK_TYPE_SYNC_RETRIEVER:
                producers = [a for a in plan._attachments if a.direction == "ingress"]
                if producers:
                    op_name = self._operatorNameForAttachment(
                        link_name=plan.name, attachment=producers[0]
                    )
                    return (op_name, producers[0].port)
        return None

    def iterOperatorSpecs(self):
        """Yield OperatorSpec for each operator in the graph."""
        for name, op in self._operators.items():
            image_url = getattr(op, "_url", None) or (
                op.info.get("url", "") if isinstance(op.info, dict) else ""
            )
            info = op.info if isinstance(op.info, dict) else {}
            policy_min = int(info.get("instancePolicyMin", 1))
            policy_max = int(info.get("instancePolicyMax", 1))
            yield OperatorSpec(
                name=name,
                imageUrl=image_url,
                instancePolicyMin=policy_min,
                instancePolicyMax=policy_max,
            )

    def iterLinkSpecs(self):
        """Yield LinkSpec for each link in the graph."""
        for link_name, plan in self._links.items():
            producers = [a for a in plan._attachments if a.direction == "ingress"]
            consumers = [a for a in plan._attachments if a.direction == "egress"]
            egress_op = egress_port = ingress_op = ingress_port = None
            if producers:
                egress_op = getattr(producers[0].operator, "name", None) or (
                    producers[0].operator.info.get("name")
                    if isinstance(producers[0].operator.info, dict)
                    else None
                )
                egress_port = producers[0].port
            if consumers:
                ingress_op = getattr(consumers[0].operator, "name", None) or (
                    consumers[0].operator.info.get("name")
                    if isinstance(consumers[0].operator.info, dict)
                    else None
                )
                ingress_port = consumers[0].port
            yield LinkSpec(
                name=link_name,
                linkType=plan.getLinkType(),
                egressOperator=egress_op,
                egressPort=egress_port,
                ingressOperator=ingress_op,
                ingressPort=ingress_port,
            )

    def buildBfsLevels(self) -> list[list[str]]:
        """Return BFS-ordered operator name levels from the dag_ingress entrypoint.

        Each entry in the returned list is one BFS depth level.  Operators at
        level 0 are launched first, then level 1, etc.

        Raises ValueError if no injector link is set or if unreachable operators
        are detected.
        """
        ingress = self.getDagIngress()
        if ingress is None:
            raise ValueError("DAG has no injector link; cannot compute BFS launch levels.")
        entrypoint = ingress[0]

        all_names = set(self._operators.keys())
        adjacency: Dict[str, Set[str]] = {name: set() for name in all_names}
        for plan in self._links.values():
            producers = [a for a in plan._attachments if a.direction == "ingress"]
            consumers = [a for a in plan._attachments if a.direction == "egress"]
            if producers and consumers:
                prod_name = getattr(producers[0].operator, "name", None) or (
                    producers[0].operator.info.get("name")
                    if isinstance(producers[0].operator.info, dict)
                    else None
                )
                cons_name = getattr(consumers[0].operator, "name", None) or (
                    consumers[0].operator.info.get("name")
                    if isinstance(consumers[0].operator.info, dict)
                    else None
                )
                if prod_name and cons_name:
                    adjacency.setdefault(prod_name, set()).add(cons_name)

        levels: list[list[str]] = []
        visited: Set[str] = set()
        queue: deque[tuple[str, int]] = deque([(entrypoint, 0)])
        while queue:
            current, depth = queue.popleft()
            if current in visited:
                continue
            visited.add(current)
            while len(levels) <= depth:
                levels.append([])
            levels[depth].append(current)
            for neighbor in sorted(adjacency.get(current, set())):
                if neighbor not in visited:
                    queue.append((neighbor, depth + 1))

        missing = [name for name in sorted(all_names) if name not in visited]
        if missing:
            raise ValueError(
                f"DAG contains unreachable operators: {', '.join(missing)}"
            )
        return levels

    # -------------------------- validation --------------------------

    def validate(self, *, allowLoop: bool = False) -> bool:
        """
        Validate the staged graph.

        Raises ValueError on failure. Returns True when a loop is detected.

        The graph entrypoint is the consumer of the single INJECTOR link. If the
        graph has no links at all (single-operator case) validation passes trivially.

        Validation order:
          1) Entrypoint derivation from single INJECTOR link (or trivial pass if no links)
          2) Per-link invariants by link type
          3) Build edges and run reachability + cycle checks
          4) Enforce "entrypoint must not be a consumer on non-INJECTOR links" when loops
             are disallowed
        """
        # If no links at all, single-operator case is valid
        if not self._links:
            return False

        # Build edges using operator NAMES to avoid hashing mutable objects
        operators_in_links: Set[str] = set()
        edges: DefaultDict[str, Set[str]] = defaultdict(set)
        injector_consumers: List[str] = []

        for link_name, plan in self._links.items():
            for attachment in plan._attachments:
                self._canonicalizePayloadType(link_name=link_name, payload_type=attachment.payload_type)
            producers = [a for a in plan._attachments if a.direction == "ingress"]
            consumers = [a for a in plan._attachments if a.direction == "egress"]
            linkType = plan.getLinkType()
            if linkType not in _SUPPORTED_LINK_TYPES:
                raise ValueError(f'Link "{link_name}" has unsupported link_type "{linkType}".')

            if linkType == _LINK_TYPE_REGULAR:
                if len(producers) != 1 or len(consumers) != 1:
                    raise ValueError(
                        f'Link "{link_name}" with link_type REGULAR must have exactly one producer and one consumer.'
                    )
                producerName = self._operatorNameForAttachment(link_name=link_name, attachment=producers[0])
                consumerName = self._operatorNameForAttachment(link_name=link_name, attachment=consumers[0])
                if producers[0].payload_type.type_url != consumers[0].payload_type.type_url:
                    raise ValueError(
                        f'Link "{link_name}" has mixed payload type_urls: '
                        f'{{"{producers[0].payload_type.type_url}", "{consumers[0].payload_type.type_url}"}}'
                    )
                operators_in_links.add(producerName)
                operators_in_links.add(consumerName)
                edges[producerName].add(consumerName)
                continue

            if linkType in _INJECTOR_LINK_TYPES:
                if len(producers) != 0 or len(consumers) != 1:
                    raise ValueError(
                        f'Link "{link_name}" with link_type {linkType} must have no producer and exactly one consumer.'
                    )
                consumerName = self._operatorNameForAttachment(link_name=link_name, attachment=consumers[0])
                operators_in_links.add(consumerName)
                injector_consumers.append(consumerName)
                continue

            if linkType == _LINK_TYPE_SYNC_RETRIEVER:
                if len(producers) != 1 or len(consumers) != 0:
                    raise ValueError(
                        f'Link "{link_name}" with link_type SYNC_RETRIEVER must have exactly one producer and no consumer.'
                    )
                producerName = self._operatorNameForAttachment(link_name=link_name, attachment=producers[0])
                operators_in_links.add(producerName)
                continue

        if len(injector_consumers) != 1:
            raise ValueError(
                f"Exactly one INJECTOR link (SYNC_INJECTOR or ASYNC_INJECTOR) with a single consumer is required "
                f"(found {len(injector_consumers)})."
            )

        entrypoint_name = injector_consumers[0]
        entrypoint_obj = self._operators.get(entrypoint_name)
        if entrypoint_obj is None:
            raise ValueError(f'Entrypoint operator "{entrypoint_name}" is not present in the graph.')

        # Reachability + DAG checks over all involved operators (plus entrypoint)
        operators = set(operators_in_links) | {entrypoint_name}
        containsLoops = self._validateReachabilityAndCycles(
            entrypoint=entrypoint_name,
            operators=operators,
            edges=edges,
            allowLoop=allowLoop,
        )

        # Enforce entrypoint consumer restriction only for DAG-only validation mode.
        # When loops are explicitly allowed, entrypoint self-consumption may be intentional.
        if not allowLoop:
            for link_name, plan in self._links.items():
                for a in plan._attachments:
                    op_name = getattr(a.operator, "name", None) or (
                        a.operator.info.get("name") if isinstance(a.operator.info, dict) else None
                    )
                    if a.direction == "egress" and op_name == entrypoint_name and plan.getLinkType() not in _INJECTOR_LINK_TYPES:
                        raise ValueError(
                            f'Entrypoint operator is attached as a consumer on link "{link_name}", which is not allowed.'
                        )
        return containsLoops

    # -------------------------- helpers --------------------------

    @staticmethod
    def _operatorNameForAttachment(*, link_name: str, attachment: _Attachment) -> str:
        operatorName = getattr(attachment.operator, "name", None) or (
            attachment.operator.info.get("name") if isinstance(attachment.operator.info, dict) else None
        )
        if not operatorName:
            raise ValueError(f'Link "{link_name}" attachments must reference named operators.')
        return operatorName

    @staticmethod
    def _validateReachabilityAndCycles(
        *, entrypoint: str, operators: Set[str], edges: DefaultDict[str, Set[str]], allowLoop: bool
    ) -> bool:
        # Reachability from entrypoint
        reachable: Set[str] = set()
        q = deque([entrypoint])
        while q:
            cur = q.popleft()
            if cur in reachable:
                continue
            reachable.add(cur)
            for nxt in edges.get(cur, ()):
                if nxt not in reachable:
                    q.append(nxt)

        unreachable = [op for op in operators if op != entrypoint and op not in reachable]
        if unreachable:
            raise ValueError("Unreachable operators from entrypoint: " + ", ".join(unreachable))

        # DAG check (Kahn's algorithm)
        indeg: DefaultDict[str, int] = defaultdict(int)
        for u in operators:
            for v in edges.get(u, ()):
                indeg[v] += 1

        zero = deque([u for u in operators if indeg[u] == 0])
        visited_count = 0
        while zero:
            u = zero.popleft()
            visited_count += 1
            for v in edges.get(u, ()):
                indeg[v] -= 1
                if indeg[v] == 0:
                    zero.append(v)

        containsLoops = visited_count != len(operators)
        if containsLoops and not allowLoop:
            raise ValueError("Graph must be a DAG (cycle detected).")
        return containsLoops

    @classmethod
    def _canonicalizePayloadType(cls, *, link_name: str, payload_type: OpNetPayloadType) -> None:
        if payload_type.serialization_format == OpNetPayloadType.SERIALIZATION_FORMAT_UNSPECIFIED:
            raise ValueError(f'Link "{link_name}" payload_type.serialization_format is required')
        normalized_type_url = (payload_type.type_url or "").strip()
        if not normalized_type_url:
            raise ValueError(f'Link "{link_name}" payload_type.type_url is required')
        if payload_type.serialization_format == OpNetPayloadType.PROTO:
            payload_type.type_url = cls._canonicalizeProtoTypeUrl(
                type_url=normalized_type_url,
                link_name=link_name,
            )
            return
        payload_type.type_url = normalized_type_url

    @classmethod
    def _canonicalizeProtoTypeUrl(cls, *, type_url: str, link_name: Optional[str] = None) -> str:
        normalized_type_url = (type_url or "").strip()
        if not normalized_type_url:
            return normalized_type_url
        if normalized_type_url.startswith(_CANONICAL_ANY_TYPE_PREFIX):
            return normalized_type_url
        return f"{_CANONICAL_ANY_TYPE_PREFIX}{normalized_type_url}"


class _FlowLinkPlan:
    """
    Builder returned by _InternalFlowGraph.getLink(); records producer/consumer for a link.
    Purely in-memory; no backends are touched.

    Each link defaults to link_type REGULAR unless changed by setLinkType.
    """

    def __init__(self, graph: _InternalFlowGraph, name: str):
        self._graph = graph
        self.name = name
        self._linkType: str = _LINK_TYPE_REGULAR
        self._attachments: List[_Attachment] = []

    def setLinkType(self, *, linkType: str) -> "_FlowLinkPlan":
        normalizedLinkType = (linkType or "").strip().upper()
        if normalizedLinkType not in _SUPPORTED_LINK_TYPES:
            raise ValueError(f'Link "{self.name}" has unsupported link_type "{linkType}".')
        self._linkType = normalizedLinkType
        return self

    def getLinkType(self) -> str:
        return self._linkType

    def addProducer(self, operator: OperatorDescriptor, *, port: str, payload_type: OpNetPayloadType) -> "_FlowLinkPlan":
        self._graph._canonicalizePayloadType(link_name=self.name, payload_type=payload_type)
        self._attachments.append(
            _Attachment(operator=operator, port=port, direction="ingress", payload_type=payload_type)
        )
        return self

    def addConsumer(self, operator: OperatorDescriptor, *, port: str, payload_type: OpNetPayloadType) -> "_FlowLinkPlan":
        self._graph._canonicalizePayloadType(link_name=self.name, payload_type=payload_type)
        self._attachments.append(
            _Attachment(operator=operator, port=port, direction="egress", payload_type=payload_type)
        )
        return self
