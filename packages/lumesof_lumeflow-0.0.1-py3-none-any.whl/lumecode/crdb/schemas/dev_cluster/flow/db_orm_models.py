from sqlalchemy import BLOB, Boolean, CheckConstraint, Column, DateTime, Enum, ForeignKeyConstraint, Index, Integer, JSON, PrimaryKeyConstraint, String, Table, UniqueConstraint, Uuid, text
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship
from typing import Optional
import datetime
import uuid

class Base(DeclarativeBase):
    pass


class TabClusters(Base):
    __tablename__ = 'tab_clusters'
    __table_args__ = (
        PrimaryKeyConstraint('id', name='tab_clusters_pkey'),
        UniqueConstraint('name', name='idxu__tab_clusters__name__active'),
        Index('idx__tab_clusters__name', 'name'),
        {'comment': 'Customer clusters. Active cluster names are unique globally.'}
    )

    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, server_default=text('gen_random_uuid()'))
    name: Mapped[str] = mapped_column(String(128), nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False, server_default=text('now()'))

    tab_controllers: Mapped[list['TabControllers']] = relationship('TabControllers', back_populates='cluster')
    tab_flow_jobs: Mapped[list['TabFlowJobs']] = relationship('TabFlowJobs', back_populates='cluster')
    tab_rpc_bridge_links: Mapped[list['TabRpcBridgeLinks']] = relationship('TabRpcBridgeLinks', back_populates='cluster')


class TabLinks(Base):
    __tablename__ = 'tab_links'
    __table_args__ = (
        PrimaryKeyConstraint('id', name='tab_links_pkey'),
        UniqueConstraint('controller_id', 'link_name', name='tab_links_link_name_uk'),
        Index('idx__tab_links__link_name', 'link_name'),
        {'comment': 'OpNet fabric links (logical channels carrying a specific payload '
                'type).'}
    )

    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, server_default=text('gen_random_uuid()'))
    link_name: Mapped[str] = mapped_column(String(128), nullable=False, comment='Stable identifier used in the OpNet domain.')
    controller_id: Mapped[uuid.UUID] = mapped_column(Uuid, nullable=False, comment='Id of the opnet controller controlling this link.')
    payload_type: Mapped[bytes] = mapped_column(BLOB, nullable=False, comment='Serialized protobuf depicting the payload type.')
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False, server_default=text('now()'))

    port: Mapped[list['TabPorts']] = relationship('TabPorts', secondary='join_port_link_bindings', back_populates='link')
    tab_rpc_bridge_links: Mapped[list['TabRpcBridgeLinks']] = relationship('TabRpcBridgeLinks', back_populates='link')
    tab_dag_links: Mapped[list['TabDagLinks']] = relationship('TabDagLinks', back_populates='link')


class TabControllers(Base):
    __tablename__ = 'tab_controllers'
    __table_args__ = (
        ForeignKeyConstraint(['cluster_id'], ['tab_clusters.id'], onupdate='RESTRICT', name='tab_controllers_cluster_id_fkey'),
        PrimaryKeyConstraint('id', name='tab_controllers_pkey'),
        UniqueConstraint('cluster_id', 'name', name='tab_controllers_cluster_id_name_uk'),
        Index('idx__tab_controllers__name', 'name'),
        {'comment': 'OpNet controllers; own nodes and links; belong to a customer '
                'cluster.'}
    )

    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, server_default=text('gen_random_uuid()'))
    usecase: Mapped[str] = mapped_column(Enum('OPERATORS', 'VIRTUAL_MACHINES', native_enum=False), nullable=False, comment='Use case.')
    name: Mapped[str] = mapped_column(String(128), nullable=False, comment='Stable identifier within a cluster.')
    cluster_id: Mapped[uuid.UUID] = mapped_column(Uuid, nullable=False, comment='Customer cluster id.')
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False, server_default=text('now()'))

    cluster: Mapped['TabClusters'] = relationship('TabClusters', back_populates='tab_controllers')
    tab_flow_jobs: Mapped[Optional['TabFlowJobs']] = relationship('TabFlowJobs', uselist=False, back_populates='controller')
    tab_nodes: Mapped[list['TabNodes']] = relationship('TabNodes', back_populates='controller')
    tab_rpc_bridge_links: Mapped[list['TabRpcBridgeLinks']] = relationship('TabRpcBridgeLinks', back_populates='controller')


class TabFlowJobs(Base):
    __tablename__ = 'tab_flow_jobs'
    __table_args__ = (
        ForeignKeyConstraint(['cluster_id'], ['tab_clusters.id'], onupdate='RESTRICT', name='tab_flow_jobs_cluster_id_fkey'),
        ForeignKeyConstraint(['controller_id'], ['tab_controllers.id'], onupdate='RESTRICT', name='tab_flow_jobs_controller_id_fkey'),
        PrimaryKeyConstraint('id', name='tab_flow_jobs_pkey'),
        UniqueConstraint('cluster_id', 'app_id', name='tab_flow_jobs_cluster_id_app_id_non_terminal_uk'),
        UniqueConstraint('controller_id', name='tab_flow_jobs_controller_id_uk'),
        Index('idx__tab_flow_jobs__app_id', 'app_id'),
        Index('idx__tab_flow_jobs__bridge_ingress_link_ref', 'bridge_ingress_link_ref'),
        Index('idx__tab_flow_jobs__cluster_id', 'cluster_id'),
        Index('idx__tab_flow_jobs__owner', 'owner'),
        Index('idx__tab_flow_jobs__status', 'status'),
        {'comment': 'Flow server jobs created per customer cluster.'}
    )

    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, server_default=text('gen_random_uuid()'), comment='Randomly generated identifier.')
    serialized_dag: Mapped[str] = mapped_column(String, nullable=False, comment='Serialized DAG describing the job topology.')
    status: Mapped[str] = mapped_column(Enum('SUBMITTED', 'CREATED', 'READY', 'STARTED', 'FINISHED', 'FAILED', 'CANCEL_PENDING', 'CANCELLED', native_enum=False), nullable=False, server_default=text("'SUBMITTED'"), comment='Lifecycle status for the job.')
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False, server_default=text('now()'))
    last_action_ts: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False, server_default=text('now()'), comment='Time of last lifecycle action on this job')
    owner: Mapped[str] = mapped_column(String(128), nullable=False, comment='Cluster user that submitted the job.')
    cluster_id: Mapped[uuid.UUID] = mapped_column(Uuid, nullable=False, comment='Cluster that owns the job.')
    contains_loops: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default=text('false'), comment='Whether the submitted job DAG contains one or more loops.')
    job_starter_id: Mapped[Optional[uuid.UUID]] = mapped_column(Uuid, comment='UUID of the StartJob caller that claimed startup for this job.')
    job_starter_ts: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime, comment='Time when the current job_starter_id claim was recorded.')
    controller_id: Mapped[Optional[uuid.UUID]] = mapped_column(Uuid, comment='OpNet controller responsible for this job.')
    app_id: Mapped[Optional[str]] = mapped_column(String(256), comment='Stable external application identifier for bridge-enabled jobs.')
    bridge_ingress_link_ref: Mapped[Optional[str]] = mapped_column(String(1024), comment='Resolved bridge ingress link reference for bridge-enabled jobs.')
    substrate: Mapped[Optional[str]] = mapped_column(String(64), comment="OpNet transport substrate backing this job's controller.")
    job_termination_reason: Mapped[Optional[str]] = mapped_column(String(1024), comment='Reason for terminating the job.')
    job_type: Mapped[Optional[str]] = mapped_column(Enum('SYNCHRONOUS', 'ASYNCHRONOUS', native_enum=False), comment='Inferred job type. SYNCHRONOUS jobs support RPC bridge responses; ASYNCHRONOUS jobs do not.')

    cluster: Mapped['TabClusters'] = relationship('TabClusters', back_populates='tab_flow_jobs')
    controller: Mapped[Optional['TabControllers']] = relationship('TabControllers', back_populates='tab_flow_jobs')
    tab_dag_operators: Mapped[list['TabDagOperators']] = relationship('TabDagOperators', back_populates='flow_job')
    tab_executors: Mapped[list['TabExecutors']] = relationship('TabExecutors', back_populates='flow_job')
    tab_dag_links: Mapped[list['TabDagLinks']] = relationship('TabDagLinks', back_populates='flow_job')


class TabNodes(Base):
    __tablename__ = 'tab_nodes'
    __table_args__ = (
        ForeignKeyConstraint(['controller_id'], ['tab_controllers.id'], onupdate='RESTRICT', name='tab_nodes_controller_id_fkey'),
        PrimaryKeyConstraint('id', name='tab_nodes_pkey'),
        UniqueConstraint('controller_id', 'name', name='tab_nodes_node_name_uk'),
        Index('idx__tab_nodes__node_name', 'name'),
        {'comment': 'OpNet nodes, addressable by stable node name.'}
    )

    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, server_default=text('gen_random_uuid()'))
    name: Mapped[str] = mapped_column(String(128), nullable=False, comment='Stable identifier used in the OpNet domain.')
    controller_id: Mapped[uuid.UUID] = mapped_column(Uuid, nullable=False, comment='Id of the opnet controller controling this node.')
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False, server_default=text('now()'))
    connection_status: Mapped[str] = mapped_column(Enum('CONNECTED', 'DISCONNECTED', native_enum=False), nullable=False, server_default=text("'DISCONNECTED'"), comment='Connection status for the node')

    controller: Mapped['TabControllers'] = relationship('TabControllers', back_populates='tab_nodes')
    tab_heartbeat_response_overrides: Mapped['TabHeartbeatResponseOverrides'] = relationship('TabHeartbeatResponseOverrides', uselist=False, back_populates='node')
    tab_node_heartbeats: Mapped[list['TabNodeHeartbeats']] = relationship('TabNodeHeartbeats', back_populates='node')
    tab_ports: Mapped[list['TabPorts']] = relationship('TabPorts', back_populates='node')
    tab_operator_instances: Mapped['TabOperatorInstances'] = relationship('TabOperatorInstances', uselist=False, back_populates='node')


class TabRpcBridgeLinks(Base):
    __tablename__ = 'tab_rpc_bridge_links'
    __table_args__ = (
        ForeignKeyConstraint(['cluster_id'], ['tab_clusters.id'], onupdate='RESTRICT', name='tab_rpc_bridge_links_cluster_id_fkey'),
        ForeignKeyConstraint(['controller_id'], ['tab_controllers.id'], onupdate='RESTRICT', name='tab_rpc_bridge_links_controller_id_fkey'),
        ForeignKeyConstraint(['link_id'], ['tab_links.id'], onupdate='RESTRICT', name='tab_rpc_bridge_links_link_id_fkey'),
        PrimaryKeyConstraint('id', name='tab_rpc_bridge_links_pkey'),
        UniqueConstraint('cluster_id', 'link_id', name='tab_rpc_bridge_links_cluster_id_link_id_uk'),
        UniqueConstraint('cluster_id', 'replica_id', name='tab_rpc_bridge_links_cluster_id_replica_id_uk'),
        Index('idx__tab_rpc_bridge_links__cluster_id', 'cluster_id'),
        Index('idx__tab_rpc_bridge_links__controller_id', 'controller_id'),
        Index('idx__tab_rpc_bridge_links__replica_id', 'replica_id'),
        {'comment': 'Cluster-level mapping from bridge replica identity to dedicated '
                'OpNet link metadata.'}
    )

    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, server_default=text('gen_random_uuid()'))
    cluster_id: Mapped[uuid.UUID] = mapped_column(Uuid, nullable=False, comment='Customer cluster id.')
    replica_id: Mapped[str] = mapped_column(String(128), nullable=False, comment='Bridge replica identity (for example bridge-shard-0-replica-1).')
    link_id: Mapped[uuid.UUID] = mapped_column(Uuid, nullable=False, comment='OpNet link id dedicated to this bridge replica.')
    link_ref: Mapped[str] = mapped_column(String(1024), nullable=False, comment='OpNet link reference used by replicas and egress fanout.')
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False, server_default=text('now()'))
    controller_id: Mapped[Optional[uuid.UUID]] = mapped_column(Uuid, comment='OpNet controller that owns the bridge replica link.')
    substrate: Mapped[Optional[str]] = mapped_column(String(64), comment='OpNet transport substrate used to create this bridge replica link.')

    cluster: Mapped['TabClusters'] = relationship('TabClusters', back_populates='tab_rpc_bridge_links')
    controller: Mapped[Optional['TabControllers']] = relationship('TabControllers', back_populates='tab_rpc_bridge_links')
    link: Mapped['TabLinks'] = relationship('TabLinks', back_populates='tab_rpc_bridge_links')


class TabDagOperators(Base):
    __tablename__ = 'tab_dag_operators'
    __table_args__ = (
        ForeignKeyConstraint(['flow_job_id'], ['tab_flow_jobs.id'], onupdate='CASCADE', name='tab_dag_operators_flow_job_id_fkey'),
        PrimaryKeyConstraint('id', name='tab_dag_operators_pkey'),
        UniqueConstraint('flow_job_id', 'name', name='tab_dag_operators_flow_job_id_name_uk'),
        Index('idx__tab_dag_operators__flow_job_id', 'flow_job_id'),
        {'comment': 'Operators extracted from a flow job DAG.'}
    )

    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, server_default=text('gen_random_uuid()'))
    flow_job_id: Mapped[uuid.UUID] = mapped_column(Uuid, nullable=False, comment='Flow job owning this DAG operator.')
    name: Mapped[str] = mapped_column(String(128), nullable=False, comment='Operator name unique within the flow job DAG.')
    image_url: Mapped[str] = mapped_column(String(1024), nullable=False, comment='URL of the operator image.')
    is_entry_point: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default=text('false'), comment='Whether this operator is the DAG entrypoint.')
    info: Mapped[dict] = mapped_column(JSON, nullable=False, server_default=text("'{}'"), comment='Info map from Operator.info.')
    serialized_operator: Mapped[bytes] = mapped_column(BLOB, nullable=False, comment='Serialized Operator proto (includes ports).')
    policy: Mapped[Optional[bytes]] = mapped_column(BLOB, comment='Serialized OperatorInstancePolicy proto.')

    flow_job: Mapped['TabFlowJobs'] = relationship('TabFlowJobs', back_populates='tab_dag_operators')
    tab_dag_links: Mapped[list['TabDagLinks']] = relationship('TabDagLinks', foreign_keys='[TabDagLinks.egress_operator_id]', back_populates='egress_operator')
    tab_dag_links_: Mapped[list['TabDagLinks']] = relationship('TabDagLinks', foreign_keys='[TabDagLinks.ingress_operator_id]', back_populates='ingress_operator')
    tab_operator_instances: Mapped[list['TabOperatorInstances']] = relationship('TabOperatorInstances', back_populates='operator')


class TabExecutors(Base):
    __tablename__ = 'tab_executors'
    __table_args__ = (
        ForeignKeyConstraint(['flow_job_id'], ['tab_flow_jobs.id'], onupdate='CASCADE', name='tab_executors_flow_job_id_fkey'),
        PrimaryKeyConstraint('id', name='tab_executors_pkey'),
        UniqueConstraint('flow_job_id', 'name', name='tab_executors_flow_job_id_name_uk'),
        Index('idx__tab_executors__flow_job_id', 'flow_job_id'),
        {'comment': 'Runtime executors declared for a flow job.'}
    )

    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, server_default=text('gen_random_uuid()'))
    flow_job_id: Mapped[uuid.UUID] = mapped_column(Uuid, nullable=False, comment='Owns this executor.')
    name: Mapped[str] = mapped_column(String(256), nullable=False, comment='Identifier unique within the owning flow job.')
    executor_type: Mapped[str] = mapped_column(String(64), nullable=False, comment='Executor type (e.g., PROCESS_GROUP_EXECUTOR).')
    serialized_executor: Mapped[bytes] = mapped_column(BLOB, nullable=False, comment='Opaque payload for deserializing a prepared executor.')
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False, server_default=text('now()'))
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False, server_default=text('now()'))

    flow_job: Mapped['TabFlowJobs'] = relationship('TabFlowJobs', back_populates='tab_executors')
    tab_operator_instances: Mapped[Optional['TabOperatorInstances']] = relationship('TabOperatorInstances', uselist=False, back_populates='executor')


class TabHeartbeatResponseOverrides(Base):
    __tablename__ = 'tab_heartbeat_response_overrides'
    __table_args__ = (
        ForeignKeyConstraint(['node_id'], ['tab_nodes.id'], onupdate='CASCADE', name='tab_heartbeat_response_overrides_node_id_fkey'),
        PrimaryKeyConstraint('id', name='tab_heartbeat_response_overrides_pkey'),
        UniqueConstraint('node_id', name='tab_heartbeat_response_overrides_node_id_uk'),
        {'comment': 'Overrides for heartbeat responses sent to nodes.'}
    )

    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, server_default=text('gen_random_uuid()'))
    node_id: Mapped[uuid.UUID] = mapped_column(Uuid, nullable=False, comment='Id of the node receiving the response override.')
    ts: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False, server_default=text('now()'), comment='Timestamp when the override was recorded.')
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False, server_default=text('now()'))
    resp_override: Mapped[bytes] = mapped_column(BLOB, nullable=False, comment='Serialized heartbeat response override.')
    num_deliveries: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text('0'), comment='Number of times the override has been delivered.')

    node: Mapped['TabNodes'] = relationship('TabNodes', back_populates='tab_heartbeat_response_overrides')


class TabNodeHeartbeats(Base):
    __tablename__ = 'tab_node_heartbeats'
    __table_args__ = (
        ForeignKeyConstraint(['node_id'], ['tab_nodes.id'], onupdate='CASCADE', name='tab_node_heartbeats_node_id_fkey'),
        PrimaryKeyConstraint('id', name='tab_node_heartbeats_pkey'),
        Index('idx__tab_node_heartbeats__node_id_ts', 'node_id', 'ts'),
        Index('idx__tab_node_heartbeats__ts', 'ts'),
        {'comment': 'Recorded heartbeats from nodes to controller.'}
    )

    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, server_default=text('gen_random_uuid()'))
    node_id: Mapped[uuid.UUID] = mapped_column(Uuid, nullable=False)
    ts: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False, server_default=text('now()'))
    heartbeat: Mapped[bytes] = mapped_column(BLOB, nullable=False, comment='Serialized OpNetNodeToCtlHeartbeat.')

    node: Mapped['TabNodes'] = relationship('TabNodes', back_populates='tab_node_heartbeats')


class TabPorts(Base):
    __tablename__ = 'tab_ports'
    __table_args__ = (
        ForeignKeyConstraint(['node_id'], ['tab_nodes.id'], onupdate='CASCADE', name='tab_ports_node_id_fkey'),
        PrimaryKeyConstraint('id', name='tab_ports_pkey'),
        UniqueConstraint('node_id', 'name', name='tab_ports_port_name_uk'),
        Index('idx__tab_ports__node_id', 'node_id'),
        {'comment': 'OpNet ports, addressable by stable port name.'}
    )

    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, server_default=text('gen_random_uuid()'))
    name: Mapped[str] = mapped_column(String(32), nullable=False, comment='Stable identifier used within an OpNet node.')
    node_id: Mapped[uuid.UUID] = mapped_column(Uuid, nullable=False, comment='Id of the node to which the port belongs.')
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, nullable=False, server_default=text('now()'))
    kind: Mapped[str] = mapped_column(Enum('INGRESS', 'EGRESS', 'INGRESS_BRIDGE', 'EGRESS_BRIDGE', native_enum=False), nullable=False, server_default=text("'INGRESS'"), comment='Direction: ingress/egress, including bridge variants.')
    payload_type: Mapped[bytes] = mapped_column(BLOB, nullable=False, comment='Serialized protobuf depicting the payload type.')
    activity_status: Mapped[str] = mapped_column(Enum('ACTIVE', 'INACTIVE', native_enum=False), nullable=False, server_default=text("'INACTIVE'"), comment="Port's activity status: ACTIVE or INACTIVE")

    link: Mapped[list['TabLinks']] = relationship('TabLinks', secondary='join_port_link_bindings', back_populates='port')
    node: Mapped['TabNodes'] = relationship('TabNodes', back_populates='tab_ports')


t_join_port_link_bindings = Table(
    'join_port_link_bindings', Base.metadata,
    Column('port_id', Uuid, primary_key=True),
    Column('link_id', Uuid, primary_key=True),
    ForeignKeyConstraint(['link_id'], ['tab_links.id'], onupdate='RESTRICT', name='join_port_link_bindings_link_id_fkey'),
    ForeignKeyConstraint(['port_id'], ['tab_ports.id'], onupdate='CASCADE', name='join_port_link_bindings_port_id_fkey'),
    PrimaryKeyConstraint('port_id', 'link_id', name='join_port_link_bindings_pkey'),
    Index('idx__join_port_link_bindings__link_id', 'link_id'),
    comment='Bindings declaring which link each node port connects to.'
)


class TabDagLinks(Base):
    __tablename__ = 'tab_dag_links'
    __table_args__ = (
        CheckConstraint("(((((((link_type = 'REGULAR'::STRING) AND (egress_operator_id IS NOT NULL)) AND (egress_port IS NOT NULL)) AND (ingress_operator_id IS NOT NULL)) AND (ingress_port IS NOT NULL)) OR (((((link_type = 'SYNC_INJECTOR'::STRING) AND (egress_operator_id IS NULL)) AND (egress_port IS NULL)) AND (ingress_operator_id IS NOT NULL)) AND (ingress_port IS NOT NULL))) OR (((((link_type = 'ASYNC_INJECTOR'::STRING) AND (egress_operator_id IS NULL)) AND (egress_port IS NULL)) AND (ingress_operator_id IS NOT NULL)) AND (ingress_port IS NOT NULL))) OR (((((link_type = 'SYNC_RETRIEVER'::STRING) AND (egress_operator_id IS NOT NULL)) AND (egress_port IS NOT NULL)) AND (ingress_operator_id IS NULL)) AND (ingress_port IS NULL))", name='tab_dag_links_link_type_endpoints_ck'),
        ForeignKeyConstraint(['egress_operator_id'], ['tab_dag_operators.id'], onupdate='CASCADE', name='tab_dag_links_egress_operator_id_fkey'),
        ForeignKeyConstraint(['flow_job_id'], ['tab_flow_jobs.id'], onupdate='CASCADE', name='tab_dag_links_flow_job_id_fkey'),
        ForeignKeyConstraint(['ingress_operator_id'], ['tab_dag_operators.id'], onupdate='CASCADE', name='tab_dag_links_ingress_operator_id_fkey'),
        ForeignKeyConstraint(['link_id'], ['tab_links.id'], onupdate='RESTRICT', name='tab_dag_links_link_id_fkey'),
        PrimaryKeyConstraint('id', name='tab_dag_links_pkey'),
        UniqueConstraint('flow_job_id', 'name', name='tab_dag_links_flow_job_id_name_uk'),
        Index('idx__tab_dag_links__flow_job_id', 'flow_job_id'),
        Index('idx__tab_dag_links__link_id', 'link_id'),
        {'comment': 'Links extracted from a flow job DAG.'}
    )

    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, server_default=text('gen_random_uuid()'))
    flow_job_id: Mapped[uuid.UUID] = mapped_column(Uuid, nullable=False, comment='Flow job owning this DAG link.')
    name: Mapped[str] = mapped_column(String(128), nullable=False, comment='Link name unique within the flow job DAG.')
    payload_type: Mapped[bytes] = mapped_column(BLOB, nullable=False, comment='Serialized OpNetPayloadType.')
    link_id: Mapped[uuid.UUID] = mapped_column(Uuid, nullable=False, comment='Foreign key to provisioned tab_links row.')
    link_type: Mapped[str] = mapped_column(Enum('REGULAR', 'SYNC_INJECTOR', 'ASYNC_INJECTOR', 'SYNC_RETRIEVER', native_enum=False), nullable=False, server_default=text("'REGULAR'"), comment='Link classification: REGULAR, SYNC_INJECTOR, ASYNC_INJECTOR, or SYNC_RETRIEVER.')
    egress_operator_id: Mapped[Optional[uuid.UUID]] = mapped_column(Uuid, comment='Producer operator for the link.')
    egress_port: Mapped[Optional[str]] = mapped_column(String(128), comment='Producer port name.')
    ingress_operator_id: Mapped[Optional[uuid.UUID]] = mapped_column(Uuid, comment='Consumer operator for the link.')
    ingress_port: Mapped[Optional[str]] = mapped_column(String(128), comment='Consumer port name.')

    egress_operator: Mapped[Optional['TabDagOperators']] = relationship('TabDagOperators', foreign_keys=[egress_operator_id], back_populates='tab_dag_links')
    flow_job: Mapped['TabFlowJobs'] = relationship('TabFlowJobs', back_populates='tab_dag_links')
    ingress_operator: Mapped[Optional['TabDagOperators']] = relationship('TabDagOperators', foreign_keys=[ingress_operator_id], back_populates='tab_dag_links_')
    link: Mapped['TabLinks'] = relationship('TabLinks', back_populates='tab_dag_links')


class TabOperatorInstances(Base):
    __tablename__ = 'tab_operator_instances'
    __table_args__ = (
        ForeignKeyConstraint(['executor_id'], ['tab_executors.id'], onupdate='CASCADE', name='tab_operator_instances_executor_id_fkey'),
        ForeignKeyConstraint(['node_id'], ['tab_nodes.id'], onupdate='CASCADE', name='tab_operator_instances_node_id_fkey'),
        ForeignKeyConstraint(['operator_id'], ['tab_dag_operators.id'], onupdate='CASCADE', name='tab_operator_instances_operator_id_fkey'),
        PrimaryKeyConstraint('id', name='tab_operator_instances_pkey'),
        UniqueConstraint('executor_id', name='tab_operator_instances_executor_id_uk'),
        UniqueConstraint('node_id', name='tab_operator_instances_node_id_uk'),
        {'comment': 'Operator instances bound to nodes and executors.'}
    )

    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, server_default=text('gen_random_uuid()'), comment='Randomly generated identifier.')
    operator_id: Mapped[uuid.UUID] = mapped_column(Uuid, nullable=False, comment='Referenced DAG operator.')
    node_id: Mapped[uuid.UUID] = mapped_column(Uuid, nullable=False, comment='OpNet node responsible for this operator instance.')
    executor_id: Mapped[Optional[uuid.UUID]] = mapped_column(Uuid, comment='Executor running this operator instance.')

    executor: Mapped[Optional['TabExecutors']] = relationship('TabExecutors', back_populates='tab_operator_instances')
    node: Mapped['TabNodes'] = relationship('TabNodes', back_populates='tab_operator_instances')
    operator: Mapped['TabDagOperators'] = relationship('TabDagOperators', back_populates='tab_operator_instances')
