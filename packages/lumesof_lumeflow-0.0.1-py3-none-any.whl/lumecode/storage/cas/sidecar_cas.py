from __future__ import annotations

import argparse
import asyncio
import hashlib
import logging
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Optional, Sequence

from google.protobuf.json_format import MessageToJson
from grpclib import GRPCError
from grpclib.const import Status
from grpclib.server import Server, Stream
from python.runfiles import Runfiles

from lumecode.base.python.grpc_health.health_service import StandardGrpcHealthService
from lumecode.base.python.net.target_parser import NetTarget
from lumecode.storage.cas import cas_grpc, cas_pb2

LOG = logging.getLogger(__name__)

_DEFAULT_BIND = "tcp://127.0.0.1:50073"
_DEFAULT_HASH_SCHEME = "sha256"


def _normalizeBind(bind: str) -> str:
    if not bind.startswith("tcp://") and not bind.startswith("unix:///"):
        return f"tcp://{bind}"
    return bind
_DEFAULT_READ_CHUNK_BYTES = 256 * 1024
_MAX_READ_CHUNK_BYTES = 4 * 1024 * 1024


@dataclass(frozen=True)
class SidecarCasEntry:
    hashScheme: str
    hashValue: str
    description: str
    tags: tuple[str, ...]
    family: str
    artifactPath: str


def _normalizeHashScheme(hashScheme: str) -> str:
    normalized = hashScheme.strip().lower()
    if not normalized:
        raise RuntimeError("hash scheme must be provided")
    try:
        hashlib.new(normalized)
    except ValueError as exc:
        raise RuntimeError(f"unsupported hash scheme: {hashScheme}") from exc
    return normalized


def _computeFileHash(*, filePath: str, hashScheme: str) -> str:
    hasher = hashlib.new(hashScheme)
    with open(filePath, "rb") as artifactFile:
        while True:
            chunk = artifactFile.read(1024 * 1024)
            if not chunk:
                break
            hasher.update(chunk)
    return hasher.hexdigest()


def buildEntriesForArtifacts(
    *,
    hashScheme: str,
    artifacts: Sequence[tuple[str, Sequence[str], str, str]],
) -> tuple[SidecarCasEntry, ...]:
    normalizedScheme = _normalizeHashScheme(hashScheme)
    entries: list[SidecarCasEntry] = []
    seenHashes: set[str] = set()
    for description, tags, family, artifactPath in artifacts:
        if not description.strip():
            raise RuntimeError("artifact description must be provided")
        normalizedTags = tuple(tag.strip() for tag in tags)
        if any(not tag for tag in normalizedTags):
            raise RuntimeError("artifact tags must be non-empty")
        if not family.strip():
            raise RuntimeError("artifact family must be provided")
        path = Path(artifactPath)
        if not path.is_file():
            raise RuntimeError(f"artifact path does not exist: {artifactPath}")
        hashValue = _computeFileHash(filePath=str(path), hashScheme=normalizedScheme)
        if hashValue in seenHashes:
            raise RuntimeError(
                "duplicate artifact hash detected; each sidecar artifact must hash uniquely"
            )
        seenHashes.add(hashValue)
        entries.append(
            SidecarCasEntry(
                hashScheme=normalizedScheme,
                hashValue=hashValue,
                description=description,
                tags=normalizedTags,
                family=family,
                artifactPath=str(path),
            )
        )
    return tuple(entries)


def _createRunfiles():
    return Runfiles.Create()


def _resolveRunfilePath(*, runfiles, candidateRunfilesPaths: Sequence[str]) -> str:
    candidates: list[str] = []
    runfiles_root = os.environ.get("RUNFILES_DIR") or os.environ.get("RUNFILES_ROOT", "")
    for runfilePath in candidateRunfilesPaths:
        if runfiles is not None:
            resolved = runfiles.Rlocation(runfilePath) or ""
            if resolved:
                candidates.append(resolved)
        if runfiles_root:
            candidates.append(os.path.join(runfiles_root, runfilePath))
        candidates.append(runfilePath)
    for candidate in candidates:
        if os.path.isfile(candidate):
            return candidate
    joinedCandidates = ", ".join(candidates) if candidates else "<none>"
    raise RuntimeError(
        f"sidecar artifact runfile path not found; checked: {joinedCandidates}"
    )


def loadDefaultSidecarEntries(*, hashScheme: str) -> tuple[SidecarCasEntry, ...]:
    runfiles = _createRunfiles()
    artifactSpecs = (
        (
            "Dummy Sidecar",
            ("opnet-substrate-dummy",),
            "opnet-sidecar",
            (
                "_main/lumecode/lumeflow/runtime/v1/sidecar/dummy_operator_sidecar_app_image.appimage",
                "lumecode/lumeflow/runtime/v1/sidecar/dummy_operator_sidecar_app_image.appimage",
            ),
        ),
        (
            "Loopback Sidecar",
            ("opnet-substrate-loopback",),
            "opnet-sidecar",
            (
                "_main/lumecode/lumeflow/runtime/v1/sidecar/loopback_sidecar_app_image.appimage",
                "lumecode/lumeflow/runtime/v1/sidecar/loopback_sidecar_app_image.appimage",
            ),
        ),
        (
            "gRPC OpNet Sidecar",
            ("opnet-substrate-grpc",),
            "opnet-sidecar",
            (
                "_main/lumecode/lumeflow/runtime/v1/sidecar/grpc_opnet_sidecar_app_image.appimage",
                "lumecode/lumeflow/runtime/v1/sidecar/grpc_opnet_sidecar_app_image.appimage",
            ),
        ),
    )

    resolvedArtifacts: list[tuple[str, Sequence[str], str, str]] = []
    for description, tags, family, runfileCandidates in artifactSpecs:
        artifactPath = _resolveRunfilePath(
            runfiles=runfiles,
            candidateRunfilesPaths=runfileCandidates,
        )
        resolvedArtifacts.append((description, tags, family, artifactPath))

    return buildEntriesForArtifacts(
        hashScheme=hashScheme,
        artifacts=tuple(resolvedArtifacts),
    )


class SidecarCasService(cas_grpc.CasServiceBase):
    def __init__(
        self,
        *,
        entries: Sequence[SidecarCasEntry],
        hashScheme: str,
        maxReadChunkBytes: int = _MAX_READ_CHUNK_BYTES,
    ) -> None:
        self._hashScheme = _normalizeHashScheme(hashScheme)
        if maxReadChunkBytes <= 0:
            raise RuntimeError("maxReadChunkBytes must be > 0")
        self._maxReadChunkBytes = maxReadChunkBytes
        self._entriesByHash: dict[str, SidecarCasEntry] = {
            entry.hashValue: entry for entry in entries
        }

    async def Read(
        self,
        stream: Stream[cas_pb2.ReadRequest, cas_pb2.ReadChunk],
    ) -> None:  # type: ignore[override]
        await self.async_handleRead(stream)

    async def OpenWrite(
        self, stream: Stream[cas_pb2.OpenWriteRequest, cas_pb2.OpenWriteResponse]
    ) -> None:  # type: ignore[override]
        await self.async_handleOpenWrite(stream)

    async def Write(
        self, stream: Stream[cas_pb2.WriteChunk, cas_pb2.WriteResponse]
    ) -> None:  # type: ignore[override]
        await self.async_handleWrite(stream)

    async def List(
        self,
        stream: Stream[cas_pb2.ListRequest, cas_pb2.ListResponse],
    ) -> None:  # type: ignore[override]
        await self.async_handleList(stream)

    async def async_handleRead(
        self,
        stream: Stream[cas_pb2.ReadRequest, cas_pb2.ReadChunk],
    ) -> None:
        request = await stream.recv_message()
        if request is None:
            raise GRPCError(Status.INVALID_ARGUMENT, "Read request is required")

        requestedScheme = _normalizeHashScheme(request.hash_scheme)
        if requestedScheme != self._hashScheme:
            raise GRPCError(
                Status.INVALID_ARGUMENT,
                f"unsupported hash_scheme '{request.hash_scheme}'",
            )

        hashValue = request.hash_value.strip().lower()
        if not hashValue:
            raise GRPCError(Status.INVALID_ARGUMENT, "hash_value must be provided")

        entry = self._entriesByHash.get(hashValue)
        if entry is None:
            raise GRPCError(Status.NOT_FOUND, f"hash not found: {hashValue}")

        chunkSize = request.chunk_size_bytes
        if chunkSize <= 0:
            chunkSize = _DEFAULT_READ_CHUNK_BYTES
        chunkSize = min(chunkSize, self._maxReadChunkBytes)

        with open(entry.artifactPath, "rb") as artifactFile:
            while True:
                chunk = artifactFile.read(chunkSize)
                if not chunk:
                    break
                await stream.send_message(cas_pb2.ReadChunk(data=chunk))

    async def async_handleOpenWrite(
        self,
        stream: Stream[cas_pb2.OpenWriteRequest, cas_pb2.OpenWriteResponse],
    ) -> None:
        _ = await stream.recv_message()
        raise GRPCError(Status.PERMISSION_DENIED, "sidecar CAS is read-only")

    async def async_handleWrite(
        self,
        stream: Stream[cas_pb2.WriteChunk, cas_pb2.WriteResponse],
    ) -> None:
        raise GRPCError(Status.PERMISSION_DENIED, "sidecar CAS is read-only")

    async def async_handleList(
        self,
        stream: Stream[cas_pb2.ListRequest, cas_pb2.ListResponse],
    ) -> None:
        request = await stream.recv_message()
        if request is None:
            raise GRPCError(Status.INVALID_ARGUMENT, "List request is required")

        response = _buildListResponse(entries=tuple(self._entriesByHash.values()))
        await stream.send_message(response)


def _buildParser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Read-only CAS service for sidecar artifacts")
    parser.add_argument(
        "--bind",
        default=None,
        help=(
            "CAS service listen address in parseTarget format "
            "(tcp://host:port or unix:///path)."
        ),
    )
    parser.add_argument(
        "--hash-scheme",
        default=_DEFAULT_HASH_SCHEME,
        help="Hash scheme used for all advertised sidecar artifacts",
    )
    parser.add_argument(
        "--list",
        action="store_true",
        help="List embedded sidecar artifacts and exit without starting gRPC server",
    )
    return parser


def _validateListFlags(args: argparse.Namespace) -> None:
    if args.list and args.bind is not None:
        raise SystemExit("--bind cannot be used with --list")


def _buildArtifactList(
    *,
    entries: Sequence[SidecarCasEntry],
) -> cas_pb2.ArtifactList:
    orderedEntries = sorted(entries, key=lambda entry: entry.description)
    artifactList = cas_pb2.ArtifactList()
    for entry in orderedEntries:
        listEntry = artifactList.entries.add(
            hash_scheme=entry.hashScheme,
            hash_value=entry.hashValue,
        )
        listEntry.metadata.description = entry.description
        listEntry.metadata.family = entry.family
        for tag in entry.tags:
            listEntry.metadata.tags.append(tag)
    return artifactList


def _buildListResponse(
    *,
    entries: Sequence[SidecarCasEntry],
) -> cas_pb2.ListResponse:
    return cas_pb2.ListResponse(
        artifacts=_buildArtifactList(entries=entries),
    )


async def async_serve(*, bind: str, hashScheme: str) -> None:
    entries = loadDefaultSidecarEntries(hashScheme=hashScheme)
    service = SidecarCasService(entries=entries, hashScheme=hashScheme)
    healthService = StandardGrpcHealthService()
    server = Server([service, healthService])

    _parsed = NetTarget.parseTarget(bind)
    if _parsed.getPath() is None:
        await server.start(host=_parsed.getHost(), port=_parsed.getPort())
    else:
        await server.start(path=_parsed.getPath())

    await healthService.async_setLive()
    await healthService.async_setReady()

    LOG.info("Serving sidecar CAS at %s with %d entries", bind, len(entries))
    try:
        await server.wait_closed()
    finally:
        await healthService.async_markShutdown()


def main(argv: Optional[list[str]] = None) -> None:
    logging.basicConfig(level=logging.INFO)
    args = _buildParser().parse_args(argv)
    try:
        _validateListFlags(args)
        if args.list:
            entries = loadDefaultSidecarEntries(hashScheme=args.hash_scheme)
            response = _buildListResponse(entries=entries)
            print(MessageToJson(response, preserving_proto_field_name=True))
            return

        bind = _normalizeBind(args.bind or _DEFAULT_BIND)
        asyncio.run(async_serve(bind=bind, hashScheme=args.hash_scheme))
    except RuntimeError as exc:
        LOG.error("Failed to start sidecar CAS service: %s", exc)
        raise SystemExit(1) from exc


if __name__ == "__main__":
    main()
