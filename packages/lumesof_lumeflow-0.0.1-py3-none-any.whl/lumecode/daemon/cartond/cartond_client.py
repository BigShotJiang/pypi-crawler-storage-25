from __future__ import annotations

import logging
from collections.abc import AsyncIterator, Mapping, Sequence
from dataclasses import dataclass

from grpclib.client import Channel

from lumecode.base.python.net.retry_until_ready import RetryUntilReady
from lumecode.base.python.net.target_parser import NetTarget
from lumecode.daemon.cartond import cartond_grpc, cartond_pb2

LOG = logging.getLogger(__name__)


@dataclass
class CartondUploadAppImageResult:
    code: int
    message: str
    uploadedBinaryPath: str


@dataclass
class CartondAppStatusResult:
    code: int
    message: str
    appId: str
    cartonId: str
    launchHandle: str
    runStatus: int
    exitCode: int


@dataclass
class CartondInfoResult:
    code: int
    message: str
    daemonVersion: str
    listenTarget: str
    listensOnUds: bool
    udsPath: str
    runtimeRoot: str
    cgroupRoot: str
    cartonInitBinary: str
    allowExternalMounts: bool
    enableDockerMediation: bool
    runAsEnabled: bool
    daemonPid: int
    daemonStartUnixMs: int
    daemonUptimeMs: int


class CartondClient:
    def __init__(
        self,
        target: str,
        *,
        retryUntilReady: RetryUntilReady | None = None,
    ) -> None:
        normalizedTarget = target.strip()
        if not normalizedTarget:
            raise ValueError("target must be provided.")
        self._target = normalizedTarget
        self._retryUntilReady = retryUntilReady or RetryUntilReady()

    def _makeChannel(self) -> Channel:
        _parsed = NetTarget.parseTarget(self._target)
        if _parsed.getPath() is not None:
            return Channel(path=_parsed.getPath())
        return Channel(host=_parsed.getHost(), port=_parsed.getPort())

    async def async_getInfo(self) -> CartondInfoResult:
        LOG.info(f"CartondClient GetInfo request target={self._target}")
        response = await self._async_callGetInfo(cartond_pb2.GetInfoRequest())
        result = CartondInfoResult(
            code=response.code,
            message=response.message,
            daemonVersion=response.daemon_version,
            listenTarget=response.listen_target,
            listensOnUds=response.listens_on_uds,
            udsPath=response.uds_path,
            runtimeRoot=response.runtime_root,
            cgroupRoot=response.cgroup_root,
            cartonInitBinary=response.carton_init_binary,
            allowExternalMounts=response.allow_external_mounts,
            enableDockerMediation=response.enable_docker_mediation,
            runAsEnabled=response.run_as_enabled,
            daemonPid=response.daemon_pid,
            daemonStartUnixMs=response.daemon_start_unix_ms,
            daemonUptimeMs=response.daemon_uptime_ms,
        )
        LOG.info(
            f"CartondClient GetInfo response target={self._target} "
            f"code={result.code} daemon_pid={result.daemonPid} "
            f"listen_target={result.listenTarget} message={result.message!r}"
        )
        return result

    async def async_createApp(
        self,
        *,
        appId: str,
        skipTmpPivot: bool = False,
        externalMounts: Sequence[cartond_pb2.ExternalMount] | None = None,
        defaultEnv: Mapping[str, str] | None = None,
        dockerMediationPolicy: cartond_pb2.DockerMediationPolicy | None = None,
        captureFallbackLogs: bool = False,
        fallbackOtlpTarget: str = "",
        fallbackLogBufferBytes: int = 0,
        memoryLimitBytes: int | None = None,
        memorySwapLimitBytes: int | None = None,
        pidsLimit: int | None = None,
        cpuQuotaMicros: int | None = None,
    ) -> CartondAppStatusResult:
        normalizedAppId = self._normalizeAppId(appId)
        request = cartond_pb2.CreateAppRequest(
            app_id=normalizedAppId,
            skip_tmp_pivot=skipTmpPivot,
            capture_fallback_logs=captureFallbackLogs,
            fallback_otlp_target=fallbackOtlpTarget,
            fallback_log_buffer_bytes=fallbackLogBufferBytes,
        )
        if externalMounts is not None:
            request.external_mounts.extend(externalMounts)
        if defaultEnv is not None:
            request.default_env.update({str(key): str(value) for key, value in defaultEnv.items()})
        if dockerMediationPolicy is not None:
            request.docker_mediation.CopyFrom(dockerMediationPolicy)
        if memoryLimitBytes is not None:
            request.memory_limit_bytes = memoryLimitBytes
        if memorySwapLimitBytes is not None:
            request.memory_swap_limit_bytes = memorySwapLimitBytes
        if pidsLimit is not None:
            request.pids_limit = pidsLimit
        if cpuQuotaMicros is not None:
            request.cpu_quota_micros = cpuQuotaMicros
        LOG.info(
            f"CartondClient CreateApp request target={self._target} app_id={normalizedAppId} "
            f"external_mount_count={len(request.external_mounts)} "
            f"default_env_count={len(request.default_env)} "
            f"docker_label_count={len(request.docker_mediation.container_labels)} "
            f"docker_log_driver={request.docker_mediation.log_policy.driver} "
            f"capture_fallback_logs={captureFallbackLogs} "
            f"fallback_otlp_target={fallbackOtlpTarget!r} "
            f"fallback_log_buffer_bytes={fallbackLogBufferBytes} "
            f"memory_limit_bytes={memoryLimitBytes} "
            f"memory_swap_limit_bytes={memorySwapLimitBytes} "
            f"pids_limit={pidsLimit} cpu_quota_micros={cpuQuotaMicros}"
        )
        response = await self._async_callCreateApp(request)
        result = self._mapAppStatus(response.result)
        LOG.info(
            f"CartondClient CreateApp response target={self._target} "
            f"app_id={normalizedAppId} code={result.code} run_status={result.runStatus} "
            f"exit_code={result.exitCode} message={result.message!r}"
        )
        return result

    async def async_uploadAppImageStream(
        self,
        *,
        appId: str,
        chunkStream: AsyncIterator[bytes],
    ) -> CartondUploadAppImageResult:
        normalizedAppId = self._normalizeAppId(appId)
        LOG.info(
            f"CartondClient UploadAppImage request target={self._target} app_id={normalizedAppId}"
        )
        channel = self._makeChannel()
        chunkCount = 0
        totalBytes = 0
        try:
            stub = cartond_grpc.CartonDaemonStub(channel)

            async def _async_openUploadStream():
                streamContext = stub.UploadAppImage.open()
                stream = await streamContext.__aenter__()
                return streamContext, stream

            streamContext, stream = await self._retryUntilReady.async_retryUntilReady(
                operationName="Cartond UploadAppImage.open",
                invocation=_async_openUploadStream,
            )
            try:
                async for chunk in chunkStream:
                    chunkBytes = bytes(chunk)
                    chunkCount += 1
                    totalBytes += len(chunkBytes)
                    await stream.send_message(
                        cartond_pb2.UploadAppImageRequest(
                            app_id=normalizedAppId,
                            chunk=chunkBytes,
                        )
                    )
                await stream.end()
                response = await stream.recv_message()
            finally:
                await streamContext.__aexit__(None, None, None)
        finally:
            channel.close()

        if response is None:
            raise RuntimeError("UploadAppImage returned no response.")

        result = CartondUploadAppImageResult(
            code=response.code,
            message=response.message,
            uploadedBinaryPath=response.uploaded_binary_path,
        )
        LOG.info(
            f"CartondClient UploadAppImage response target={self._target} "
            f"app_id={normalizedAppId} code={result.code} "
            f"uploaded_binary_path={result.uploadedBinaryPath!r} "
            f"chunks={chunkCount} total_bytes={totalBytes} message={result.message!r}"
        )
        return result

    async def async_launchApp(
        self,
        *,
        appId: str,
        argv: Sequence[str] | None = None,
        env: Mapping[str, str] | None = None,
        workingDir: str = "",
        timeoutMs: int = 0,
        runAsUid: int | None = None,
        runAsGid: int | None = None,
        runAsToken: str = "",
    ) -> CartondAppStatusResult:
        normalizedAppId = self._normalizeAppId(appId)
        request = cartond_pb2.LaunchAppRequest(
            app_id=normalizedAppId,
            argv=list(argv or []),
            env=dict(env or {}),
            working_dir=workingDir,
            timeout_ms=timeoutMs,
            run_as_token=runAsToken,
        )
        if runAsUid is not None:
            request.run_as_uid = runAsUid
        if runAsGid is not None:
            request.run_as_gid = runAsGid
        LOG.info(
            f"CartondClient LaunchApp request target={self._target} app_id={normalizedAppId} "
            f"argv={list(request.argv)} env_keys={sorted(request.env.keys())} "
            f"working_dir={request.working_dir!r} timeout_ms={request.timeout_ms} "
            f"run_as_uid={runAsUid} run_as_gid={runAsGid} "
            f"run_as_token_present={bool(runAsToken)}"
        )
        response = await self._async_callLaunchApp(request)
        result = self._mapAppStatus(response.result)
        LOG.info(
            f"CartondClient LaunchApp response target={self._target} "
            f"app_id={normalizedAppId} code={result.code} run_status={result.runStatus} "
            f"exit_code={result.exitCode} launch_handle={result.launchHandle!r} "
            f"message={result.message!r}"
        )
        return result

    async def async_getAppStatus(self, appId: str) -> CartondAppStatusResult:
        normalizedAppId = self._normalizeAppId(appId)
        LOG.info(
            f"CartondClient GetAppStatus request target={self._target} app_id={normalizedAppId}"
        )
        response = await self._async_callGetAppStatus(
            cartond_pb2.GetAppStatusRequest(app_id=normalizedAppId)
        )
        result = self._mapAppStatus(response.result)
        LOG.info(
            f"CartondClient GetAppStatus response target={self._target} "
            f"app_id={normalizedAppId} code={result.code} run_status={result.runStatus} "
            f"exit_code={result.exitCode} launch_handle={result.launchHandle!r} "
            f"message={result.message!r}"
        )
        return result

    async def async_tearDownApp(self, appId: str) -> CartondAppStatusResult:
        normalizedAppId = self._normalizeAppId(appId)
        LOG.info(
            f"CartondClient TearDownApp request target={self._target} app_id={normalizedAppId}"
        )
        response = await self._async_callTearDownApp(
            cartond_pb2.TearDownAppRequest(app_id=normalizedAppId)
        )
        result = self._mapAppStatus(response.result)
        LOG.info(
            f"CartondClient TearDownApp response target={self._target} "
            f"app_id={normalizedAppId} code={result.code} run_status={result.runStatus} "
            f"exit_code={result.exitCode} message={result.message!r}"
        )
        return result

    async def _async_callCreateApp(
        self,
        request: cartond_pb2.CreateAppRequest,
    ) -> cartond_pb2.CreateAppResponse:
        channel = self._makeChannel()
        try:
            stub = cartond_grpc.CartonDaemonStub(channel)
            return await self._retryUntilReady.async_retryUntilReady(
                operationName="Cartond CreateApp",
                invocation=lambda: stub.CreateApp(request),
            )
        finally:
            channel.close()

    async def _async_callGetInfo(
        self,
        request: cartond_pb2.GetInfoRequest,
    ) -> cartond_pb2.GetInfoResponse:
        channel = self._makeChannel()
        try:
            stub = cartond_grpc.CartonDaemonStub(channel)
            return await self._retryUntilReady.async_retryUntilReady(
                operationName="Cartond GetInfo",
                invocation=lambda: stub.GetInfo(request),
            )
        finally:
            channel.close()

    async def _async_callLaunchApp(
        self,
        request: cartond_pb2.LaunchAppRequest,
    ) -> cartond_pb2.LaunchAppResponse:
        channel = self._makeChannel()
        try:
            stub = cartond_grpc.CartonDaemonStub(channel)
            return await self._retryUntilReady.async_retryUntilReady(
                operationName="Cartond LaunchApp",
                invocation=lambda: stub.LaunchApp(request),
            )
        finally:
            channel.close()

    async def _async_callGetAppStatus(
        self,
        request: cartond_pb2.GetAppStatusRequest,
    ) -> cartond_pb2.GetAppStatusResponse:
        channel = self._makeChannel()
        try:
            stub = cartond_grpc.CartonDaemonStub(channel)
            return await self._retryUntilReady.async_retryUntilReady(
                operationName="Cartond GetAppStatus",
                invocation=lambda: stub.GetAppStatus(request),
            )
        finally:
            channel.close()

    async def _async_callTearDownApp(
        self,
        request: cartond_pb2.TearDownAppRequest,
    ) -> cartond_pb2.TearDownAppResponse:
        channel = self._makeChannel()
        try:
            stub = cartond_grpc.CartonDaemonStub(channel)
            return await self._retryUntilReady.async_retryUntilReady(
                operationName="Cartond TearDownApp",
                invocation=lambda: stub.TearDownApp(request),
            )
        finally:
            channel.close()

    @staticmethod
    def _normalizeAppId(appId: str) -> str:
        if not isinstance(appId, str) or not appId.strip():
            raise ValueError("appId must be provided.")
        return appId.strip()

    @staticmethod
    def _mapAppStatus(status: cartond_pb2.AppStatus) -> CartondAppStatusResult:
        return CartondAppStatusResult(
            code=status.code,
            message=status.message,
            appId=status.app_id,
            cartonId=status.carton_id,
            launchHandle=status.launch_handle,
            runStatus=status.run_status,
            exitCode=status.exit_code,
        )
