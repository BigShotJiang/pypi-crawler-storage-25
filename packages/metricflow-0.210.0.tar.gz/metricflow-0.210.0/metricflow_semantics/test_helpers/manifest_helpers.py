from __future__ import annotations

import json
import pathlib
from pathlib import Path
from typing import Dict, Optional

from metricflow_semantics.toolkit.mf_logging.lazy_formattable import LazyFormat

from metricflow_semantic_interfaces.implementations.metric import PydanticMetric
from metricflow_semantic_interfaces.implementations.project_configuration import PydanticProjectConfiguration
from metricflow_semantic_interfaces.implementations.saved_query import PydanticSavedQuery
from metricflow_semantic_interfaces.implementations.semantic_manifest import PydanticSemanticManifest
from metricflow_semantic_interfaces.implementations.semantic_model import PydanticSemanticModel
from metricflow_semantic_interfaces.parsing.dir_to_model import (
    parse_directory_of_yaml_files_to_semantic_manifest,
)
from metricflow_semantic_interfaces.transformations.semantic_manifest_transformer import (
    PydanticSemanticManifestTransformer,
)
from metricflow_semantic_interfaces.validations.semantic_manifest_validator import SemanticManifestValidator


def mf_load_manifest_from_yaml_directory(
    yaml_file_directory: pathlib.Path,
    template_mapping: Optional[Dict[str, str]] = None,
) -> PydanticSemanticManifest:
    """Reads the manifest YAMLs from the standard location, applies transformations, runs validations."""
    try:
        build_result = parse_directory_of_yaml_files_to_semantic_manifest(
            str(yaml_file_directory), template_mapping=template_mapping
        )
        validator = SemanticManifestValidator[PydanticSemanticManifest]()
        validator.checked_validations(build_result.semantic_manifest)
        return build_result.semantic_manifest
    except Exception as e:
        raise RuntimeError(
            LazyFormat("Error while loading semantic manifest", yaml_file_directory=yaml_file_directory)
        ) from e


def mf_load_manifest_from_json_file(
    json_file_path: Path,
    override_project_configuration: Optional[PydanticProjectConfiguration] = None,
    apply_transforms: bool = False,
) -> PydanticSemanticManifest:
    """Load a manifest from a file containing the JSON-serialized form of a `PydanticSemanticManifest`.

    Args:
        json_file_path: The path to the semantic-manifest JSON file.
        override_project_configuration: If set, use this project configuration instead of the one in the manifest.
        apply_transforms: Apply transformations that are typically applied after deserializing from YAML files.
    Returns: The deserialized semantic manifest.
    """
    try:
        with open(json_file_path) as fp:
            manifest_json = json.load(fp)

        semantic_models = [
            PydanticSemanticModel.parse_obj(semantic_model_json)
            for semantic_model_json in manifest_json["semantic_models"]
        ]
        metrics = [PydanticMetric.parse_obj(metric_json) for metric_json in manifest_json["metrics"]]
        saved_queries = [
            PydanticSavedQuery.parse_obj(saved_query_json) for saved_query_json in manifest_json["saved_queries"]
        ]
        project_configuration = override_project_configuration or PydanticProjectConfiguration.parse_obj(
            manifest_json["project_configuration"]
        )

        semantic_manifest = PydanticSemanticManifest(
            semantic_models=semantic_models,
            metrics=metrics,
            saved_queries=saved_queries,
            project_configuration=project_configuration,
        )

        if apply_transforms:
            return PydanticSemanticManifestTransformer.transform(semantic_manifest)
        return semantic_manifest

    except Exception as e:
        raise RuntimeError(LazyFormat("Error while loading semantic manifest", json_file_path=json_file_path)) from e
