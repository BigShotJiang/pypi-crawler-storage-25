"""MemScale benchmark suite.

Reproducible VRAM benchmarks any user can rerun::

    python -m memscale.benchmarks --models bert-large,gpt2-xl

Programmatic use::

    from memscale.benchmarks import BenchmarkSuite
    suite = BenchmarkSuite(["bert-base"], steps=5)
    results = suite.run()

See ``methodology.md`` for the measurement protocol.
"""
from __future__ import annotations

from memscale.benchmarks.models import BENCHMARK_MODELS, ModelSpec
from memscale.benchmarks.runner import BenchmarkResult, BenchmarkSuite, collect_environment

__all__ = [
    "BenchmarkSuite",
    "BenchmarkResult",
    "BENCHMARK_MODELS",
    "ModelSpec",
    "collect_environment",
]
