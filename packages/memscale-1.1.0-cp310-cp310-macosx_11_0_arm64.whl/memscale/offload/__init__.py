"""MemScale internal async offload module.

Not part of the public API. The public, user-facing surface for offloading
is ``memscale.techniques.offloading``; this package holds the async
implementation behind it.

See PHASE2_DESIGN_DOC.md for the Phase 2 design.
"""
from memscale.offload.canary import AsyncCorrectnessMonitor
from memscale.offload.hook import (
    AsyncOffloadConfig,
    AsyncOffloadEngine,
    ExperimentalFeatureWarning,
)
from memscale.offload.pinned_pool import PinnedMemoryPool
from memscale.offload.scheduler import (
    LayerInfo,
    OffloadAction,
    OffloadScheduler,
    PrefetchingScheduler,
)
from memscale.offload.stream import AsyncOffloadStream

__all__ = [
    "PinnedMemoryPool",
    "AsyncOffloadStream",
    "OffloadScheduler",
    "PrefetchingScheduler",
    "LayerInfo",
    "OffloadAction",
    "AsyncCorrectnessMonitor",
    "AsyncOffloadEngine",
    "AsyncOffloadConfig",
    "ExperimentalFeatureWarning",
]
