"""
MemScale - Drop-in memory optimizer for PyTorch training.

Usage:
    import memscale

    trainer = memscale.wrap(your_trainer)
    # That's it. VRAM optimization is now active.

Optional anonymous telemetry (off by default):
    memscale.enable_telemetry()
    # or: export MEMSCALE_TELEMETRY=1
"""

# Core
from memscale.core.profiler import MemoryProfiler
from memscale.core.decision_engine import DecisionEngine
from memscale.core.executor import Executor
from memscale.core.config import Config, OptimizationMode

# Public API
from memscale.api import wrap, optimize, detach

# Distributed
from memscale.distributed import get_distributed_context, wrap_ddp_model

# v0.2 features
from memscale.autotuning import AutoTuner

# Phase 3 features
from memscale.oom_predictor import OOMPredictor, OOMRisk, OOMPrediction
from memscale.cost_attribution import CostTracker, CostReport, estimate_savings
from memscale.compatibility import (
    detect_framework,
    TrainingFramework,
    CompatibilityChecker,
    safe_wrap_with_compatibility,
)

# v1.0.2: telemetry (opt-in) + legacy compat
from memscale._telemetry import (
    enable_telemetry,
    disable_telemetry,
    is_telemetry_enabled,
)
from memscale._compat import (
    set_api_key,        # deprecated no-op
    get_client,         # deprecated no-op
    check_quota,        # deprecated no-op
    get_usage_today,    # deprecated no-op
    require_quota,      # deprecated pass-through
    warn_if_env_api_key_set,
)

# Config getters/setters (kept for backward compat)
from memscale._config import get_config, set_config

from memscale.advisor import LocalAdvisor, AIAdvisor, Recommendation
from memscale.exceptions import (
    MemScaleError,
    AuthenticationError,    # kept for backward import-compat
    QuotaExceededError,     # kept for backward import-compat
    APIError,
    ConfigurationError,
    ProviderError,
)

__version__ = "1.1.0"

__all__ = [
    # Public API
    "wrap",
    "optimize",
    "detach",
    "safe_wrap_with_compatibility",
    # Configuration
    "Config",
    "OptimizationMode",
    # Core components
    "MemoryProfiler",
    "DecisionEngine",
    "Executor",
    # Distributed
    "get_distributed_context",
    "wrap_ddp_model",
    # Auto-tuning
    "AutoTuner",
    # OOM prediction
    "OOMPredictor",
    "OOMRisk",
    "OOMPrediction",
    # Cost attribution
    "CostTracker",
    "CostReport",
    "estimate_savings",
    # Compatibility
    "detect_framework",
    "TrainingFramework",
    "CompatibilityChecker",
    # Advisor
    "LocalAdvisor",
    "AIAdvisor",
    "Recommendation",
    # Telemetry (NEW v1.0.2)
    "enable_telemetry",
    "disable_telemetry",
    "is_telemetry_enabled",
    # Legacy / deprecated (kept for import-compat)
    "set_api_key",
    "get_client",
    "check_quota",
    "get_usage_today",
    "require_quota",
    "get_config",
    "set_config",
    # Exceptions
    "MemScaleError",
    "AuthenticationError",
    "QuotaExceededError",
    "APIError",
    "ConfigurationError",
    "ProviderError",
    # Version
    "__version__",
]

# Phase F: Combined memory optimization techniques
try:
    from memscale.phase_f import apply_all_optimizations, estimate_combined_savings
    __all__ += ["apply_all_optimizations", "estimate_combined_savings"]
except ImportError:
    pass

# Emit deprecation warning at import time if user has MEMSCALE_API_KEY set
warn_if_env_api_key_set()
