"""MCP server for namefyi — naming and Korean romanization tools for AI assistants.

Run: uvx --from "namefyi[mcp]" python -m namefyi.mcp_server
"""
from __future__ import annotations

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("namefyi")


@mcp.tool()
def romanize(hangul: str) -> str:
    """Romanize a Korean name using Revised Romanization.

    Args:
        hangul: Korean name in Hangul (e.g. "김민준").
    """
    from namefyi import romanize_korean

    result = romanize_korean(hangul)
    return f"**{hangul}** → {result}"


@mcp.tool()
def stroke_count(character: str) -> str:
    """Get the CJK stroke count for a character.

    Args:
        character: A single CJK character (e.g. "金").
    """
    from namefyi import get_stroke_count

    count = get_stroke_count(character)
    return f"**{character}** has {count} strokes"


@mcp.tool()
def five_elements(stroke_count: int) -> str:
    """Get the Five Elements (오행) association for a stroke count.

    The Five Elements cycle: 木(Wood) → 火(Fire) → 土(Earth) → 金(Metal) → 水(Water).

    Args:
        stroke_count: Number of strokes in a character.
    """
    from namefyi import five_elements_for_strokes

    element = five_elements_for_strokes(stroke_count)
    element_names = {"木": "Wood", "火": "Fire", "土": "Earth", "金": "Metal", "水": "Water"}
    name = element_names.get(element, element)
    return f"{stroke_count} strokes → **{element}** ({name})"


@mcp.tool()
def element_compatibility(element_a: str, element_b: str) -> str:
    """Check Five Elements compatibility between two elements.

    Args:
        element_a: First element (木, 火, 土, 金, or 水).
        element_b: Second element (木, 火, 土, 金, or 水).
    """
    from namefyi import check_element_compatibility

    result = check_element_compatibility(element_a, element_b)
    return f"**{element_a}** + **{element_b}** → {result}"


@mcp.tool()
def search_names(query: str) -> str:
    """Search namefyi.com for names, characters, and cultures.

    Args:
        query: Search query string.
    """
    from namefyi.api import NameFYI

    with NameFYI() as api:
        data = api.search(query)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return f"No results found for \"{query}\"."
        items = results[:10] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


def main() -> None:
    """Run the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
