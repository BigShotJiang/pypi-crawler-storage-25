from client.synome.entities._shared.axis_asc_entities_primes import EligiblePrimeAgentASC
from client.synome.entities._shared.axis_asc_entities_types import Position
from client.synome.formulas.latent_asc import latent_asc
from client.synome.formulas.resting_asc import resting_asc

def asc_incentive(prime: EligiblePrimeAgentASC, positions: list[Position], base_rate: float, treasury_bill_rate: float) -> float:
    """ASC incentive payment: eligible ASC times (base_rate - treasury_bill_rate).

    :source_uuid: 693330d6-9072-4054-bd61-d788537e34e8
    """
    eligible_asc_usd: float = resting_asc(positions) + latent_asc(prime, positions)
    return eligible_asc_usd * (base_rate - treasury_bill_rate)

formula_asc_incentive = asc_incentive
