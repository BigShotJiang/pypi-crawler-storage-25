"""Generated identities."""

def formula_recovery(liquidation_penalty: float, liquidation_threshold: float, slippage: float) -> float:
    """
    Intermediate calculation: recovery

    Atlas section: Formula Evaluation
    """
    return (1.0 - liquidation_penalty)*(1.0 - slippage)/liquidation_threshold
