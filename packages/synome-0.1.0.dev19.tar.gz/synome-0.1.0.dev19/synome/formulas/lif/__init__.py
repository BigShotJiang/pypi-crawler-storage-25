"""Generated identities."""

def formula_lif(M: float, denominator: float) -> float:
    """
    Calculate the liquidation incentive factor (LIF) for a given LLTV.

Returns a value between 1.0 and M (1.15).

    Atlas section: Formula Evaluation
    """
    return min(M, 1.0/denominator)
