from typing import Final
from client.synome.entities._shared.axis_asc_entities_primes import EligiblePrimeAgentASC
from client.synome.entities._shared.axis_asc_entities_types import Position
from client.synome.formulas.latent_asc import latent_asc
from client.synome.formulas.resting_asc import resting_asc
DAB_REQUIRED_PCT: Final[float] = 0.25
'Required DAB as a fraction of total ASC.\n\n:source_uuid: 1e129119-a2ce-4978-b235-c50f2a1c5e2e\n'

def dab_required(prime: EligiblePrimeAgentASC, positions: list[Position]) -> float:
    """Required DAB: DAB_REQUIRED_PCT of ASC.

    :source_uuid: 1e129119-a2ce-4978-b235-c50f2a1c5e2e
    """
    asc_usd = resting_asc(positions) + latent_asc(prime, positions)
    return asc_usd * DAB_REQUIRED_PCT

formula_dab_required = dab_required
