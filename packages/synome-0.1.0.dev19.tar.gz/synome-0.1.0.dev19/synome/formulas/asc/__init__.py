from client.synome.entities._shared.axis_asc_entities_primes import EligiblePrimeAgentASC
from client.synome.entities._shared.axis_asc_entities_types import Position
from client.synome.formulas.latent_asc import latent_asc
from client.synome.formulas.resting_asc import resting_asc

def asc(prime: EligiblePrimeAgentASC, positions: list[Position]) -> float:
    """
    Total Actively Stabilizing Capital for a prime.

    :source_uuid: 62495dee-8d2a-45d4-87c4-01150e3db3c8
    """
    resting_asc_usd: float = resting_asc(positions)
    latent_asc_usd: float = latent_asc(prime, positions)
    return resting_asc_usd + latent_asc_usd

formula_asc = asc
