"""Generated identities."""

def formula_denominator(BETA: float, lltv: float) -> float:
    """
    Intermediate calculation: denominator

    Atlas section: Formula Evaluation
    """
    return BETA*lltv - BETA + 1.0
