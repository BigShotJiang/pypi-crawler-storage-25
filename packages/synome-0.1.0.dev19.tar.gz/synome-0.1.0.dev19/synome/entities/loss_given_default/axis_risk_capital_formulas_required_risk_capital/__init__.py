"""Generated entity placeholders inferred from formula imports."""

loss_given_default: object = object()
