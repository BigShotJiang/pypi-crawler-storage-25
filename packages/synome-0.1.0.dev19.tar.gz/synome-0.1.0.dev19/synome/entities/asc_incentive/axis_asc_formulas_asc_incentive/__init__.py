"""Generated entity placeholders inferred from formula imports."""

asc_incentive: object = object()
