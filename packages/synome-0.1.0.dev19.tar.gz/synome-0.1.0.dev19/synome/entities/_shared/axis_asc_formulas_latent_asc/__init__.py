"""Generated entity placeholders inferred from formula imports."""

latent_asc: object = object()
