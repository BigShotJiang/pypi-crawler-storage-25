"""Generated entity placeholders inferred from formula imports."""

DAB_REQUIRED_PCT: object = object()


dab_required: object = object()
