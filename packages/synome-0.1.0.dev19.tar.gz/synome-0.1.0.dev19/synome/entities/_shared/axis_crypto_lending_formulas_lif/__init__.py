"""Generated entity placeholders inferred from formula imports."""

BETA: object = object()
M: object = object()


lif: object = object()
