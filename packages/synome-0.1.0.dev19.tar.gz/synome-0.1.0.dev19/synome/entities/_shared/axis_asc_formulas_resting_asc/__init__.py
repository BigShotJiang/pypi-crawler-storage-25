"""Generated entity placeholders inferred from formula imports."""

resting_asc: object = object()
