"""Generated entity placeholders inferred from formula imports."""

asc_collateral_ratio: object = object()
asc_collateral_ratio_satisfied: object = object()
collateral_portfolio: object = object()
