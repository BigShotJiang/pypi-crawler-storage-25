from client.synome.entities.asc.axis_asc_entities_assets import Asset
from axis_synome.spec_support.validated_dataclass import validated_dataclass

@validated_dataclass
class Position:
    """A single holding of a token in a protocol on a network.

    This is the main computational unit for all ASC / DAB formulas.
    """
    asset: Asset
    value_usd: float
    pool_paired_with_usds: bool | None = None
    fee_tier: float | None = None