"""Generated entity placeholders inferred from formula imports."""

asc: object = object()
