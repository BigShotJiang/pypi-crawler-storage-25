# beta

Tiny HTTP hello server for fixture use only.
