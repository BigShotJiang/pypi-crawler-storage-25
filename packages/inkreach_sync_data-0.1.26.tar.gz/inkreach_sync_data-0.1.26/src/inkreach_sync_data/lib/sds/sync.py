import asyncio
import arrow
import asyncpg
from pprint import pprint
from inkreach_sync_data.lib.sds.order import fetch_sds_order
from inkreach_sync_data.lib.sds.database import upsert_orders, create_pool
from inkreach_sync_data.lib.sds.config import SDS_QUERY_MAX_BATCH, SYNC_DATA_MAX_CONCURRENT
from sds_mng.util import logger


async def sync_recent_order(pool, start, end):
    data = await fetch_sds_order(
        start,
        end,
    )
    await upsert_orders(data, pool)


async def sync_order_incremental(pool, default_days_back=2):
    arrow.default_tz = "Asia/Shanghai"

    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            "SELECT MAX(created_at) as latest_ordered_at FROM orders"
        )
        latest = row["latest_ordered_at"]

    if latest:
        start = arrow.get(latest).floor("hour")
    else:
        start = arrow.now().shift(days=-default_days_back).floor("day")

    logger.info(f"SDS最新支付时间为 {start.format('YYYY-MM-DD HH:mm:ss')}")

    end = arrow.now().ceil("day")

    data = await fetch_sds_order(
        start.format("YYYY-MM-DD HH:mm:ss"),
        end.format("YYYY-MM-DD HH:mm:ss"),
    )

    if data:
        await upsert_orders(data, pool)


async def refresh_orders(
    pool: asyncpg.Pool, query: str, delete_before_insert: bool = True
):
    async with pool.acquire() as conn:
        rows = await conn.fetch(query)
        order_nos = [r["order_no"] for r in rows]

    pprint(order_nos)

    if not order_nos:
        return

    batches = [
        order_nos[i : i + SDS_QUERY_MAX_BATCH]
        for i in range(0, len(order_nos), SDS_QUERY_MAX_BATCH)
    ]
    semaphore = asyncio.Semaphore(SYNC_DATA_MAX_CONCURRENT)

    async def process_batch(batch):
        async with semaphore:
            keywords = "\n".join(batch)
            latest_data = await fetch_sds_order(filters={"keywords": keywords})
            if not latest_data:
                return

            async with pool.acquire() as conn:
                async with conn.transaction():
                    if delete_before_insert:
                        await conn.execute(
                            "DELETE FROM orders WHERE order_no = ANY($1::text[])",
                            batch,
                        )

            await upsert_orders(latest_data, pool)

    await asyncio.gather(*[process_batch(batch) for batch in batches])
