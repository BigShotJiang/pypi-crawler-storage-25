"""
MCP server entry point for clinicaltrials-mcp.

Registers all 5 tools with the official MCP Python SDK and handles
tool calls by routing to client.py (data fetching) and formatters.py
(output formatting).

Run via stdio transport — compatible with Cursor, Claude Desktop,
and any other MCP client that uses the stdio protocol.

Usage (after installing the package):
    clinicaltrials-mcp

Or directly:
    python -m clinicaltrials_mcp.server
"""

import asyncio
import logging
from typing import Any

import mcp.types as types
from mcp.server import Server
from mcp.server.stdio import stdio_server

from .client import (
    ALL_STATUSES,
    DEFAULT_EXCLUDED_STATUSES,
    ClinicalTrialsClient,
    APIError,
    StudyNotFoundError,
)
from .formatters import (
    format_search_results,
    format_trial_details,
    format_trial_comparison,
    format_trial_results,
    format_recruiting_near,
)

# ── Logging ────────────────────────────────────────────────────────────────────

logging.basicConfig(level=logging.WARNING)
logger = logging.getLogger(__name__)

# ── Server instance ────────────────────────────────────────────────────────────

server = Server("clinicaltrials-mcp")

# ── Tool definitions ───────────────────────────────────────────────────────────

@server.list_tools()
async def list_tools() -> list[types.Tool]:
    """
    Return the list of tools this server exposes.

    The MCP client calls this once on startup to discover what tools
    are available, their descriptions, and their input schemas.
    The input schema is JSON Schema — the client uses it to validate
    arguments before sending them to call_tool.
    """
    return [
        types.Tool(
            name="search_trials",
            description=(
                "Search ClinicalTrials.gov for trials matching a condition. "
                "Returns a ranked list with status, phase, sponsor, site count, "
                "and a brief summary. WITHDRAWN and TERMINATED trials are excluded "
                "by default — pass status= to override. Results are ordered with "
                "RECRUITING trials first."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "condition": {
                        "type": "string",
                        "description": "Disease or condition to search for, e.g. 'breast cancer', 'Type 2 diabetes'.",
                    },
                    "location": {
                        "type": "string",
                        "description": "Optional. City, state, or country to filter by, e.g. 'India', 'Boston', 'Germany'.",
                    },
                    "phase": {
                        "type": "string",
                        "description": "Optional. Trial phase: 'PHASE1', 'PHASE2', 'PHASE3', 'PHASE4'. Omit for all phases.",
                    },
                    "status": {
                        "type": "string",
                        "description": (
                            "Optional. Override the default status filter. "
                            "Pass a single CT.gov status value e.g. 'RECRUITING', "
                            "'COMPLETED', 'TERMINATED'. Default excludes WITHDRAWN and TERMINATED."
                        ),
                    },
                    "max_results": {
                        "type": "integer",
                        "description": "Number of results to return. Default 10, maximum 50.",
                        "default": 10,
                        "minimum": 1,
                        "maximum": 50,
                    },
                },
                "required": ["condition"],
            },
        ),

        types.Tool(
            name="get_trial_details",
            description=(
                "Get a full structured summary of one clinical trial by NCT ID. "
                "Returns: overview, what's being studied, verbatim eligibility criteria, "
                "site locations, and whether results have been posted. "
                "NCT ID hyperlink appears at the top and bottom for easy verification."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "nct_id": {
                        "type": "string",
                        "description": "The NCT identifier, e.g. 'NCT02142803'. Case-insensitive.",
                    },
                },
                "required": ["nct_id"],
            },
        ),

        types.Tool(
            name="compare_trials",
            description=(
                "Compare 2 to 5 clinical trials side by side. "
                "Produces structured tables for design, timeline, locations, "
                "endpoints, and eligibility criteria. "
                "Use compare_on to focus on one category."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "nct_ids": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "List of 2 to 5 NCT identifiers to compare.",
                        "minItems": 2,
                        "maxItems": 5,
                    },
                    "compare_on": {
                        "type": "string",
                        "description": (
                            "What to compare. Options: 'all' (default), 'design', "
                            "'timeline', 'locations', 'endpoints', 'eligibility'."
                        ),
                        "default": "all",
                        "enum": ["all", "design", "timeline", "locations", "endpoints", "eligibility"],
                    },
                },
                "required": ["nct_ids"],
            },
        ),

        types.Tool(
            name="get_trial_results",
            description=(
                "Fetch posted results for a clinical trial: participant flow, "
                "baseline characteristics, primary and secondary outcomes, "
                "and adverse events. "
                "Handles 4 cases: results posted, trial ongoing, completed but "
                "no results posted, and NCT ID not found. "
                "Adverse events default to serious events (Grade 3+) only."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "nct_id": {
                        "type": "string",
                        "description": "The NCT identifier, e.g. 'NCT02142803'.",
                    },
                    "summary_only": {
                        "type": "boolean",
                        "description": "If true, return only the primary outcome in 2–3 lines. Default false.",
                        "default": False,
                    },
                    "ae_grade": {
                        "type": "string",
                        "description": (
                            "Adverse event filter. '3+' (default): serious events only. "
                            "'all': serious + Grade 1/2 events. 'serious': SAEs only."
                        ),
                        "default": "3+",
                        "enum": ["3+", "all", "serious"],
                    },
                },
                "required": ["nct_id"],
            },
        ),

        types.Tool(
            name="find_recruiting_near",
            description=(
                "Find actively recruiting trials for a condition near a location. "
                "Results are grouped by location ring: trials in the queried city first, "
                "then elsewhere in the country. "
                "Location is city/country level — CT.gov has no GPS radius data. "
                "IMPORTANT: filtered by overall trial status, not individual site status. "
                "A site in your city may still show 'Not yet recruiting' even if the trial "
                "is recruiting globally. Always verify the specific site status at clinicaltrials.gov."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "condition": {
                        "type": "string",
                        "description": "Disease or condition, e.g. 'Type 2 diabetes'.",
                    },
                    "location": {
                        "type": "string",
                        "description": "City and/or country, e.g. 'Bangalore, India' or 'Germany'.",
                    },
                    "phase": {
                        "type": "string",
                        "description": "Optional phase filter: 'PHASE1', 'PHASE2', 'PHASE3', 'PHASE4'.",
                    },
                    "max_results": {
                        "type": "integer",
                        "description": "Maximum results per ring. Default 10, maximum 50.",
                        "default": 10,
                        "minimum": 1,
                        "maximum": 50,
                    },
                },
                "required": ["condition", "location"],
            },
        ),
    ]


# ── Tool call handler ──────────────────────────────────────────────────────────

@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[types.TextContent]:
    """
    Route an incoming tool call to the correct handler.

    All errors are caught here and returned as readable text — never
    as unhandled exceptions that would crash the server process.
    """
    try:
        match name:
            case "search_trials":
                result = await _handle_search_trials(arguments)
            case "get_trial_details":
                result = await _handle_get_trial_details(arguments)
            case "compare_trials":
                result = await _handle_compare_trials(arguments)
            case "get_trial_results":
                result = await _handle_get_trial_results(arguments)
            case "find_recruiting_near":
                result = await _handle_find_recruiting_near(arguments)
            case _:
                result = f"❌ Unknown tool: '{name}'"

    except StudyNotFoundError as exc:
        result = (
            f"❌ **Study not found:** `{exc.nct_id}` does not exist on ClinicalTrials.gov.\n\n"
            "Check that the NCT ID is correct. NCT IDs are in the format `NCT` followed by "
            "8 digits, e.g. `NCT02142803`."
        )
    except APIError as exc:
        result = (
            f"❌ **ClinicalTrials.gov API error (HTTP {exc.status_code}).**\n\n"
            "The CT.gov API may be temporarily unavailable. Please try again in a moment."
        )
    except Exception as exc:
        logger.exception("Unexpected error in tool '%s': %s", name, exc)
        result = (
            f"❌ **Unexpected error:** {type(exc).__name__}: {exc}\n\n"
            "Please report this at https://github.com/agents100x/clinicaltrials-mcp/issues"
        )

    return [types.TextContent(type="text", text=result)]


# ── Private tool handlers ──────────────────────────────────────────────────────

async def _handle_search_trials(args: dict[str, Any]) -> str:
    """Handle search_trials tool call."""
    condition: str = args["condition"]
    location: str | None = args.get("location")
    phase: str | None = args.get("phase")
    status_override: str | None = args.get("status")
    max_results: int = min(int(args.get("max_results", 10)), 50)

    if status_override:
        statuses = [status_override.upper()]
    else:
        statuses = [s for s in ALL_STATUSES if s not in DEFAULT_EXCLUDED_STATUSES]

    async with ClinicalTrialsClient() as client:
        data = await client.search_studies(
            condition=condition,
            location=location,
            phase=phase,
            statuses=statuses,
            max_results=max_results,
        )

    return format_search_results(data, condition, statuses)


async def _handle_get_trial_details(args: dict[str, Any]) -> str:
    """Handle get_trial_details tool call."""
    nct_id: str = args["nct_id"]

    async with ClinicalTrialsClient() as client:
        data = await client.get_study(nct_id)

    return format_trial_details(data)


async def _handle_compare_trials(args: dict[str, Any]) -> str:
    """Handle compare_trials tool call."""
    nct_ids: list[str] = args["nct_ids"]
    compare_on: str = args.get("compare_on", "all")

    if len(nct_ids) < 2:
        return "❌ **compare_trials requires at least 2 NCT IDs.** Please provide 2–5 NCT IDs."
    if len(nct_ids) > 5:
        return "❌ **compare_trials supports a maximum of 5 NCT IDs.** Please reduce your list."

    async with ClinicalTrialsClient() as client:
        studies = await client.get_studies(nct_ids)

    return format_trial_comparison(studies, compare_on)


async def _handle_get_trial_results(args: dict[str, Any]) -> str:
    """Handle get_trial_results tool call."""
    nct_id: str = args["nct_id"]
    summary_only: bool = bool(args.get("summary_only", False))
    ae_grade: str = args.get("ae_grade", "3+")

    async with ClinicalTrialsClient() as client:
        data = await client.get_study(nct_id)

    return format_trial_results(data, summary_only=summary_only, ae_grade=ae_grade)


async def _handle_find_recruiting_near(args: dict[str, Any]) -> str:
    """
    Handle find_recruiting_near tool call.

    Implements the city → country location ring hierarchy from the masterplan.
    CT.gov has no GPS or radius-based filtering — we approximate rings by
    running two searches (city, then country) and labelling results by which
    query matched.

    The 'state' ring is omitted in v1 — CT.gov location querying doesn't
    reliably distinguish city vs state searches.
    """
    condition: str = args["condition"]
    location: str = args["location"]
    phase: str | None = args.get("phase")
    max_results: int = min(int(args.get("max_results", 10)), 50)

    # Parse city and country from location string.
    # "Bangalore, India" → city="Bangalore", country="India"
    # "Germany" → city="Germany", country=None (treated as country-only search)
    parts = [p.strip() for p in location.split(",")]
    city = parts[0]
    country = parts[-1] if len(parts) > 1 else None

    async with ClinicalTrialsClient() as client:
        # Ring 1: city-level search
        city_data = await client.search_studies(
            condition=condition,
            location=city,
            phase=phase,
            statuses=["RECRUITING"],
            max_results=max_results,
        )
        city_nct_ids = {
            s.get("protocolSection", {})
            .get("identificationModule", {})
            .get("nctId")
            for s in city_data.get("studies", [])
        }

        # Ring 2: country-level search (deduplicated against city results)
        country_studies: list[dict[str, Any]] = []
        if country:
            country_data = await client.search_studies(
                condition=condition,
                location=country,
                phase=phase,
                statuses=["RECRUITING"],
                max_results=max_results,
            )
            country_studies = [
                s for s in country_data.get("studies", [])
                if s.get("protocolSection", {})
                .get("identificationModule", {})
                .get("nctId") not in city_nct_ids
            ]

    rings: dict[str, list[dict[str, Any]]] = {
        "city": city_data.get("studies", []),
        "state": [],
        "country": country_studies,
    }

    return format_recruiting_near(rings, condition, location)


# ── Entry point ────────────────────────────────────────────────────────────────

async def main() -> None:
    """Run the MCP server over stdio transport."""
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )


def run() -> None:
    """Synchronous entry point — called by the CLI command `clinicaltrials-mcp`."""
    asyncio.run(main())


if __name__ == "__main__":
    run()
