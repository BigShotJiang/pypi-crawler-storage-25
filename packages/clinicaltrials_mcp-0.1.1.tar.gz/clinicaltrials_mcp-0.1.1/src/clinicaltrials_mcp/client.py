"""
HTTP client for the ClinicalTrials.gov public API v2.

This module owns everything related to talking to CT.gov:
- the base URL and request parameters
- timeout and connection management
- error detection and custom exception types
- concurrent fetching for multi-study operations

It returns raw JSON dicts only. No formatting, no MCP logic.
If CT.gov changes their API, this is the only file that needs to change.
"""

import asyncio
from typing import Any

import httpx

# ── Constants ──────────────────────────────────────────────────────────────────

BASE_URL = "https://clinicaltrials.gov/api/v2"

# 30 seconds is generous but CT.gov can be slow under high load.
DEFAULT_TIMEOUT = 30.0

# The masterplan specifies max_results capped at 50. We enforce that here so
# the server layer never accidentally requests more than the API handles well.
MAX_PAGE_SIZE = 50

# Every valid overallStatus value in CT.gov v2.
# Defined here as the single source of truth — server.py and formatters.py
# import from here rather than each defining their own string lists.
ALL_STATUSES: list[str] = [
    "RECRUITING",
    "ACTIVE_NOT_RECRUITING",
    "ENROLLING_BY_INVITATION",
    "COMPLETED",
    "NOT_YET_RECRUITING",
    "SUSPENDED",
    "TERMINATED",
    "WITHDRAWN",
    "UNKNOWN",
]

# The masterplan decision: exclude these two by default in search_trials.
# Users can override by passing status= explicitly.
DEFAULT_EXCLUDED_STATUSES: frozenset[str] = frozenset({"WITHDRAWN", "TERMINATED"})

# The display order for search results — RECRUITING surfaces first.
# Used in formatters.py but defined here alongside the status constants.
STATUS_DISPLAY_ORDER: list[str] = [
    "RECRUITING",
    "ACTIVE_NOT_RECRUITING",
    "ENROLLING_BY_INVITATION",
    "COMPLETED",
    "NOT_YET_RECRUITING",
    "SUSPENDED",
    "UNKNOWN",
]


# ── Exceptions ─────────────────────────────────────────────────────────────────

class ClinicalTrialsError(Exception):
    """Base class for all errors raised by this client."""


class StudyNotFoundError(ClinicalTrialsError):
    """Raised when the CT.gov API returns 404 for an NCT ID."""

    def __init__(self, nct_id: str) -> None:
        self.nct_id = nct_id
        super().__init__(f"Study not found: {nct_id}")


class APIError(ClinicalTrialsError):
    """Raised when CT.gov returns a non-200, non-404 response."""

    def __init__(self, status_code: int, detail: str) -> None:
        self.status_code = status_code
        super().__init__(f"ClinicalTrials.gov API error {status_code}: {detail}")


# ── Client ─────────────────────────────────────────────────────────────────────

class ClinicalTrialsClient:
    """
    Async HTTP client for the ClinicalTrials.gov public API v2.

    Must be used as an async context manager so the underlying
    httpx connection pool is properly opened and closed:

        async with ClinicalTrialsClient() as client:
            study = await client.get_study("NCT02142803")

    All methods return raw JSON dicts — no formatting is applied here.
    """

    def __init__(self, timeout: float = DEFAULT_TIMEOUT) -> None:
        self._timeout = timeout
        self._http: httpx.AsyncClient | None = None

    async def __aenter__(self) -> "ClinicalTrialsClient":
        self._http = httpx.AsyncClient(
            base_url=BASE_URL,
            timeout=self._timeout,
            headers={"Accept": "application/json"},
            follow_redirects=True,
        )
        return self

    async def __aexit__(self, *_: Any) -> None:
        if self._http is not None:
            await self._http.aclose()
            self._http = None

    def _client(self) -> httpx.AsyncClient:
        """Return the active HTTP client or raise if used outside context manager."""
        if self._http is None:
            raise RuntimeError(
                "ClinicalTrialsClient must be used as an async context manager.\n"
                "Use: async with ClinicalTrialsClient() as client: ..."
            )
        return self._http

    async def get_study(self, nct_id: str) -> dict[str, Any]:
        """
        Fetch the full record for one study by NCT ID.

        Returns the raw API response — a dict with keys including
        'protocolSection', 'resultsSection' (if posted), and 'hasResults'.

        Args:
            nct_id: The NCT identifier, e.g. "NCT02142803". Case-insensitive.

        Raises:
            StudyNotFoundError: If the NCT ID does not exist on CT.gov.
            APIError: For any other non-200 HTTP response.
        """
        nct_id = nct_id.strip().upper()
        response = await self._client().get(f"/studies/{nct_id}")

        if response.status_code == 404:
            raise StudyNotFoundError(nct_id)

        if response.status_code != 200:
            raise APIError(response.status_code, response.text[:300])

        return response.json()

    async def get_studies(self, nct_ids: list[str]) -> list[dict[str, Any]]:
        """
        Fetch multiple studies concurrently.

        Fires all requests in parallel using asyncio.gather so compare_trials
        fetching 5 studies takes ~1× the latency of one request, not 5×.

        Args:
            nct_ids: List of NCT identifiers. Order is preserved in the result.

        Raises:
            StudyNotFoundError: If any NCT ID in the list does not exist.
            APIError: If any request fails with a non-200, non-404 response.
        """
        tasks = [self.get_study(nct_id) for nct_id in nct_ids]
        results: list[dict[str, Any]] = list(await asyncio.gather(*tasks))
        return results

    async def search_studies(
        self,
        condition: str,
        location: str | None = None,
        phase: str | None = None,
        statuses: list[str] | None = None,
        max_results: int = 10,
    ) -> dict[str, Any]:
        """
        Search for studies matching the given criteria.

        Used by both search_trials (general search) and find_recruiting_near
        (location-focused search). The caller controls which statuses are
        included — the masterplan default of excluding WITHDRAWN and TERMINATED
        is applied here if statuses is not provided.

        Args:
            condition: Disease or condition term, e.g. "diabetes". Required.
            location: City, state, or country string, e.g. "Bangalore, India".
            phase: Phase filter. Accepts "PHASE1", "PHASE2", "PHASE3", "PHASE4",
                   or None for all phases. Case-insensitive.
            statuses: List of CT.gov status values to include. If None, all
                      statuses except WITHDRAWN and TERMINATED are included.
            max_results: Number of results to return. Capped at MAX_PAGE_SIZE.

        Returns:
            Raw API response dict with keys:
              - 'studies': list of study dicts
              - 'totalCount': total matching studies on CT.gov
              - 'nextPageToken': pagination token (None if no more pages)

        Raises:
            APIError: If the CT.gov API returns a non-200 response.
        """
        if statuses is None:
            statuses = [
                s for s in ALL_STATUSES
                if s not in DEFAULT_EXCLUDED_STATUSES
            ]

        params: dict[str, Any] = {
            "query.cond": condition,
            "filter.overallStatus": ",".join(statuses),
            "pageSize": min(max_results, MAX_PAGE_SIZE),
        }

        if location:
            params["query.locn"] = location

        if phase:
            # Normalise: accept "Phase 3", "phase3", "PHASE3" → "PHASE3"
            params["filter.phase"] = phase.upper().replace(" ", "")

        response = await self._client().get("/studies", params=params)

        if response.status_code != 200:
            raise APIError(response.status_code, response.text[:300])

        return response.json()
