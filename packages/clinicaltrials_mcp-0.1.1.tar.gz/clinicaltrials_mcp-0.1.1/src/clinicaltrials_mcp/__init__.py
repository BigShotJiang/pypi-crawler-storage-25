# clinicaltrials-mcp — agents100x
# https://github.com/agents100x/clinicaltrials-mcp

__version__ = "0.1.1"
