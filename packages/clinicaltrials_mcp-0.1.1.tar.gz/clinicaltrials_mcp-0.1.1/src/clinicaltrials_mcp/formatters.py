"""
Output formatters for all 5 clinicaltrials-mcp tools.

Each public function takes a raw JSON dict from client.py and returns
a clean markdown string. No HTTP calls happen here — this module only
knows how to read dicts and write strings.

Design rules enforced in every formatter:
  - Eligibility criteria are always verbatim. Never paraphrase clinical text.
  - NCT hyperlinks appear at the TOP and BOTTOM of get_trial_details output.
  - AE grade notes appear at the TOP and BOTTOM of get_trial_results output.
  - Every search response includes a status-filter transparency footer.
  - find_recruiting_near labels each result by location ring (city/state/country).
"""

from __future__ import annotations

from typing import Any

from .client import STATUS_DISPLAY_ORDER, DEFAULT_EXCLUDED_STATUSES

# ── Constants ──────────────────────────────────────────────────────────────────

CT_GOV_BASE = "https://clinicaltrials.gov/study"

PHASE_LABELS: dict[str, str] = {
    "EARLY_PHASE1": "Early Phase 1",
    "PHASE1": "Phase 1",
    "PHASE2": "Phase 2",
    "PHASE3": "Phase 3",
    "PHASE4": "Phase 4",
    "NA": "N/A",
}

STATUS_LABELS: dict[str, str] = {
    "RECRUITING": "Recruiting",
    "ACTIVE_NOT_RECRUITING": "Active, Not Recruiting",
    "ENROLLING_BY_INVITATION": "Enrolling by Invitation",
    "COMPLETED": "Completed",
    "NOT_YET_RECRUITING": "Not Yet Recruiting",
    "SUSPENDED": "Suspended",
    "TERMINATED": "Terminated",
    "WITHDRAWN": "Withdrawn",
    "UNKNOWN": "Unknown",
}


# ── Private helpers ────────────────────────────────────────────────────────────

def _url(nct_id: str) -> str:
    return f"{CT_GOV_BASE}/{nct_id}"


def _link(nct_id: str) -> str:
    return f"[{nct_id}]({_url(nct_id)})"


def _fmt_phase(phases: list[str] | None) -> str:
    if not phases:
        return "N/A"
    return ", ".join(PHASE_LABELS.get(p, p.replace("_", " ").title()) for p in phases)


def _fmt_status(status: str) -> str:
    return STATUS_LABELS.get(status, status.replace("_", " ").title())


def _fmt_date(date_struct: dict[str, Any] | None) -> str:
    if not date_struct:
        return "N/A"
    date = date_struct.get("date", "N/A")
    type_ = date_struct.get("type", "")
    suffix = " (estimated)" if type_ == "ESTIMATED" else ""
    return f"{date}{suffix}"


def _fmt_enrollment(info: dict[str, Any] | None) -> str:
    if not info:
        return "N/A"
    count = info.get("count")
    type_ = info.get("type", "").lower()
    if count is None:
        return "N/A"
    return f"{count:,} ({type_})"


def _sort_by_status(studies: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Sort studies so RECRUITING appears first, per masterplan STATUS_DISPLAY_ORDER."""
    def rank(study: dict[str, Any]) -> int:
        status = (
            study.get("protocolSection", {})
            .get("statusModule", {})
            .get("overallStatus", "UNKNOWN")
        )
        try:
            return STATUS_DISPLAY_ORDER.index(status)
        except ValueError:
            return len(STATUS_DISPLAY_ORDER)
    return sorted(studies, key=rank)


def _sponsor_name(sponsor_module: dict[str, Any] | None) -> str:
    if not sponsor_module:
        return "Unknown"
    return sponsor_module.get("leadSponsor", {}).get("name", "Unknown")


def _locations_summary(locations: list[dict[str, Any]] | None) -> tuple[int, str]:
    """Return (site_count, human-readable countries string)."""
    if not locations:
        return 0, "No location data"
    site_count = len(locations)
    countries = sorted({loc.get("country", "Unknown") for loc in locations})
    if len(countries) <= 3:
        country_str = ", ".join(countries)
    else:
        country_str = ", ".join(countries[:3]) + f" + {len(countries) - 3} more countries"
    return site_count, country_str


def _truncate(text: str, max_chars: int = 220) -> str:
    """Trim long text to max_chars, breaking at a word boundary."""
    if not text or len(text) <= max_chars:
        return text
    return text[:max_chars].rsplit(" ", 1)[0] + "…"


def _parse_eligibility(criteria_text: str) -> tuple[str, str]:
    """Split verbatim eligibility text into (inclusion, exclusion) sections."""
    text = (criteria_text or "").strip()
    if "Exclusion Criteria:" in text:
        parts = text.split("Exclusion Criteria:", 1)
        inclusion = parts[0].replace("Inclusion Criteria:", "").strip()
        exclusion = parts[1].strip()
    else:
        inclusion = text.replace("Inclusion Criteria:", "").strip()
        exclusion = ""
    return inclusion, exclusion


def _pct(n: int | None, at_risk: int | None) -> str:
    """Format n/N (x.x%) for AE tables."""
    if n is None or at_risk is None or at_risk == 0:
        return "N/A"
    pct = (n / at_risk) * 100
    return f"{n}/{at_risk} ({pct:.1f}%)"


# ── Public formatters ──────────────────────────────────────────────────────────

def format_search_results(
    data: dict[str, Any],
    condition: str,
    statuses_used: list[str],
) -> str:
    """
    Format search results from search_trials into a numbered list.

    Sorts studies by status (RECRUITING first) and appends a transparency
    footer explaining exactly which statuses were included and excluded.
    """
    studies = _sort_by_status(data.get("studies", []))

    if not studies:
        return (
            f"No trials found for **{condition}**.\n\n"
            "This may be because:\n"
            "- The condition name used doesn't match CT.gov's terminology "
            "(try a broader or alternate term)\n"
            "- All matching trials are WITHDRAWN or TERMINATED (excluded by default)\n\n"
            "To include terminated trials: specify `status=\"TERMINATED\"`"
        )

    lines: list[str] = [f"Found **{len(studies)} trial(s)** for **{condition}**:\n"]

    for i, study in enumerate(studies, 1):
        proto = study.get("protocolSection", {})
        id_mod = proto.get("identificationModule", {})
        status_mod = proto.get("statusModule", {})
        sponsor_mod = proto.get("sponsorCollaboratorsModule", {})
        design_mod = proto.get("designModule", {})
        desc_mod = proto.get("descriptionModule", {})
        locs = proto.get("contactsLocationsModule", {}).get("locations", [])

        nct_id = id_mod.get("nctId", "Unknown")
        title = id_mod.get("briefTitle", "No title")
        status = status_mod.get("overallStatus", "UNKNOWN")
        phases = design_mod.get("phases", [])
        enrollment = design_mod.get("enrollmentInfo")
        summary = desc_mod.get("briefSummary", "")
        site_count, countries = _locations_summary(locs)

        lines.append(
            f"**{i}. {_link(nct_id)} — {title}**\n"
            f"   Status: {_fmt_status(status)} | Phase: {_fmt_phase(phases)} | "
            f"Sponsor: {_sponsor_name(sponsor_mod)}\n"
            f"   Enrollment: {_fmt_enrollment(enrollment)} | "
            f"Sites: {site_count} site(s) in {countries}\n"
            f"   _{_truncate(summary)}_\n"
        )

    excluded = sorted(DEFAULT_EXCLUDED_STATUSES)
    included = sorted(set(statuses_used) - DEFAULT_EXCLUDED_STATUSES)

    lines.append(
        "---\n"
        f"**Status filter:** Showing {', '.join(included)}. "
        f"{', '.join(excluded)} excluded by default.\n"
        "To include them, pass `status=\"TERMINATED\"` or `status=\"WITHDRAWN\"` explicitly.\n"
        "_Data is self-reported by sponsors on ClinicalTrials.gov and may lag real-world updates._"
    )

    return "\n".join(lines)


def format_trial_details(data: dict[str, Any]) -> str:
    """
    Format a full structured summary of one trial for get_trial_details.

    Eligibility criteria are presented verbatim — never paraphrased.
    NCT hyperlink appears at the TOP and BOTTOM of output per masterplan.
    """
    proto = data.get("protocolSection", {})
    id_mod = proto.get("identificationModule", {})
    status_mod = proto.get("statusModule", {})
    sponsor_mod = proto.get("sponsorCollaboratorsModule", {})
    desc_mod = proto.get("descriptionModule", {})
    cond_mod = proto.get("conditionsModule", {})
    design_mod = proto.get("designModule", {})
    arms_mod = proto.get("armsInterventionsModule", {})
    outcomes_mod = proto.get("outcomesModule", {})
    elig_mod = proto.get("eligibilityModule", {})
    contacts_mod = proto.get("contactsLocationsModule", {})

    nct_id = id_mod.get("nctId", "Unknown")
    title = id_mod.get("briefTitle", "No title")
    status = status_mod.get("overallStatus", "UNKNOWN")
    has_results = data.get("hasResults", False)

    url = _url(nct_id)
    lines: list[str] = [f"🔗 {url}\n"]

    # ── Overview ──────────────────────────────────────────────────────────────
    lines.append(f"## {nct_id} — {title}\n")
    lines.append("### Trial Overview")
    lines.append(f"- **Status:** {_fmt_status(status)}")
    lines.append(f"- **Phase:** {_fmt_phase(design_mod.get('phases'))}")
    lines.append(f"- **Sponsor:** {_sponsor_name(sponsor_mod)}")
    lines.append(f"- **Start date:** {_fmt_date(status_mod.get('startDateStruct'))}")
    lines.append(
        f"- **Primary completion:** "
        f"{_fmt_date(status_mod.get('primaryCompletionDateStruct'))}"
    )
    lines.append(
        f"- **Study completion:** {_fmt_date(status_mod.get('completionDateStruct'))}"
    )
    lines.append(
        f"- **Enrollment:** {_fmt_enrollment(design_mod.get('enrollmentInfo'))}"
    )
    lines.append(f"- **Study type:** {design_mod.get('studyType', 'N/A')}")

    design_info = design_mod.get("designInfo", {})
    allocation = design_info.get("allocation", "N/A")
    masking = design_info.get("maskingInfo", {}).get("masking", "N/A")
    lines.append(f"- **Allocation:** {allocation} | **Masking:** {masking}")

    # ── What's Being Studied ───────────────────────────────────────────────────
    lines.append("\n### What's Being Studied")

    conditions = cond_mod.get("conditions", [])
    if conditions:
        lines.append(f"**Conditions:** {', '.join(conditions)}")

    interventions = arms_mod.get("interventions", [])
    if interventions:
        intervention_names = [
            f"{iv.get('name', 'Unknown')} ({iv.get('type', '').lower()})"
            for iv in interventions
            if iv.get("type") not in ("OTHER",)
        ]
        if intervention_names:
            lines.append(f"**Interventions:** {', '.join(intervention_names)}")

    summary = desc_mod.get("briefSummary", "")
    if summary:
        lines.append(f"\n_{summary.strip()}_")

    primary_outcomes = outcomes_mod.get("primaryOutcomes", [])
    if primary_outcomes:
        lines.append("\n**Primary Endpoints:**")
        for j, outcome in enumerate(primary_outcomes, 1):
            lines.append(
                f"{j}. {outcome.get('measure', 'N/A')} "
                f"_(timeframe: {outcome.get('timeFrame', 'N/A')})_"
            )

    secondary_outcomes = outcomes_mod.get("secondaryOutcomes", [])
    if secondary_outcomes:
        lines.append("\n**Secondary Endpoints:**")
        for j, outcome in enumerate(secondary_outcomes[:5], 1):
            lines.append(f"{j}. {outcome.get('measure', 'N/A')}")
        if len(secondary_outcomes) > 5:
            lines.append(f"   _…and {len(secondary_outcomes) - 5} more_")

    # ── Eligibility (always verbatim) ─────────────────────────────────────────
    lines.append("\n### Eligibility")
    sex = elig_mod.get("sex", "N/A")
    min_age = elig_mod.get("minimumAge", "N/A")
    max_age = elig_mod.get("maximumAge", "N/A")
    healthy = elig_mod.get("healthyVolunteers", False)

    lines.append(
        f"**Sex:** {sex.title()} | **Age:** {min_age}"
        + (f" to {max_age}" if max_age and max_age != "N/A" else "+")
        + (f" | Healthy volunteers: {'Yes' if healthy else 'No'}")
    )

    criteria_text = elig_mod.get("eligibilityCriteria", "")
    if criteria_text:
        lines.append(
            "\n> **Note for AI assistants:** The eligibility criteria below are "
            "verbatim clinical text from ClinicalTrials.gov. Do not summarise, "
            "paraphrase, or condense them — present them exactly as shown."
        )
        inclusion, exclusion = _parse_eligibility(criteria_text)
        if inclusion:
            lines.append("\n**Inclusion Criteria (verbatim):**")
            lines.append(inclusion)
        if exclusion:
            lines.append("\n**Exclusion Criteria (verbatim):**")
            lines.append(exclusion)

    # ── Sites ─────────────────────────────────────────────────────────────────
    lines.append("\n### Sites")
    locations = contacts_mod.get("locations", [])
    site_count, countries = _locations_summary(locations)
    unique_countries = sorted({loc.get("country", "Unknown") for loc in locations})

    lines.append(
        f"**{site_count} site(s)** in {len(unique_countries)} "
        f"{'country' if len(unique_countries) == 1 else 'countries'}: "
        f"{', '.join(unique_countries)}"
    )
    for loc in locations[:10]:
        city = loc.get("city", "")
        state = loc.get("state", "")
        country = loc.get("country", "")
        facility = loc.get("facility", "")
        location_parts = ", ".join(filter(None, [city, state, country]))
        lines.append(f"- {facility} — {location_parts}")
    if len(locations) > 10:
        lines.append(f"  _…and {len(locations) - 10} more sites_")

    # ── Results ───────────────────────────────────────────────────────────────
    lines.append("\n### Results")
    if has_results:
        lines.append(
            "✅ Results have been posted. "
            f"Use `get_trial_results(\"{nct_id}\")` for full outcome data."
        )
    else:
        lines.append(
            "⏳ No results have been posted to ClinicalTrials.gov yet. "
            "This does not mean the trial failed — ~60% of completed trials "
            "never post results."
        )

    # ── Footer (link repeated at bottom per masterplan) ───────────────────────
    lines.append(
        "\n---\n"
        "_Verify all information at the source before regulatory or clinical use._\n"
        f"🔗 {url}"
    )

    return "\n".join(lines)


def format_trial_comparison(
    studies: list[dict[str, Any]],
    compare_on: str = "all",
) -> str:
    """
    Format a side-by-side comparison of 2–5 trials.

    compare_on options: "all", "design", "eligibility", "endpoints",
                        "locations", "timeline"
    """
    if len(studies) < 2:
        return "❌ compare_trials requires at least 2 NCT IDs."
    if len(studies) > 5:
        return "❌ compare_trials supports a maximum of 5 NCT IDs."

    nct_ids = [
        s.get("protocolSection", {})
        .get("identificationModule", {})
        .get("nctId", f"Study {i+1}")
        for i, s in enumerate(studies)
    ]
    short_titles = [
        s.get("protocolSection", {})
        .get("identificationModule", {})
        .get("briefTitle", "N/A")[:50]
        for s in studies
    ]

    def _table(rows: list[tuple[str, list[str]]]) -> str:
        """Build a markdown table. rows = [(attribute, [val_per_study])]."""
        header = "| Attribute | " + " | ".join(nct_ids) + " |"
        sep = "|---|" + "---|" * len(nct_ids)
        body = "\n".join(
            f"| {attr} | " + " | ".join(vals) + " |"
            for attr, vals in rows
        )
        return f"{header}\n{sep}\n{body}"

    sections: list[str] = [
        f"## Trial Comparison — {len(studies)} studies\n",
        "| # | NCT ID | Brief Title |",
        "|---|---|---|",
        *[
            f"| {i+1} | {_link(nct_ids[i])} | {short_titles[i]}… |"
            for i in range(len(studies))
        ],
        "",
    ]

    def _get(study: dict, *keys: str, default: str = "N/A") -> str:
        val = study
        for k in keys:
            if not isinstance(val, dict):
                return default
            val = val.get(k, {})
        return str(val) if val else default

    include_all = compare_on == "all"

    # ── Design ────────────────────────────────────────────────────────────────
    if compare_on in ("all", "design"):
        sections.append("### Design")
        rows = [
            ("Status", [
                _fmt_status(_get(s, "protocolSection", "statusModule", "overallStatus"))
                for s in studies
            ]),
            ("Phase", [
                _fmt_phase(
                    s.get("protocolSection", {}).get("designModule", {}).get("phases")
                )
                for s in studies
            ]),
            ("Sponsor", [
                _sponsor_name(s.get("protocolSection", {}).get("sponsorCollaboratorsModule"))
                for s in studies
            ]),
            ("Allocation", [
                _get(s, "protocolSection", "designModule", "designInfo", "allocation")
                for s in studies
            ]),
            ("Masking", [
                s.get("protocolSection", {})
                .get("designModule", {})
                .get("designInfo", {})
                .get("maskingInfo", {})
                .get("masking", "N/A")
                for s in studies
            ]),
        ]
        sections.append(_table(rows))
        sections.append("")

    # ── Timeline ──────────────────────────────────────────────────────────────
    if compare_on in ("all", "timeline"):
        sections.append("### Timeline & Enrollment")
        rows = [
            ("Start date", [
                _fmt_date(
                    s.get("protocolSection", {})
                    .get("statusModule", {})
                    .get("startDateStruct")
                )
                for s in studies
            ]),
            ("Primary completion", [
                _fmt_date(
                    s.get("protocolSection", {})
                    .get("statusModule", {})
                    .get("primaryCompletionDateStruct")
                )
                for s in studies
            ]),
            ("Enrollment", [
                _fmt_enrollment(
                    s.get("protocolSection", {})
                    .get("designModule", {})
                    .get("enrollmentInfo")
                )
                for s in studies
            ]),
        ]
        sections.append(_table(rows))
        sections.append("")

    # ── Locations ─────────────────────────────────────────────────────────────
    if compare_on in ("all", "locations"):
        sections.append("### Locations")
        rows_loc = []
        for nct_id, study in zip(nct_ids, studies):
            locs = (
                study.get("protocolSection", {})
                .get("contactsLocationsModule", {})
                .get("locations", [])
            )
            count, countries = _locations_summary(locs)
            rows_loc.append((nct_id, [f"{count} sites", countries]))

        site_row = ("Sites", [r[1][0] for r in rows_loc])
        country_row = ("Countries", [r[1][1] for r in rows_loc])
        sections.append(_table([site_row, country_row]))
        sections.append("")

    # ── Endpoints ─────────────────────────────────────────────────────────────
    if compare_on in ("all", "endpoints"):
        sections.append("### Primary Endpoints")
        for nct_id, study in zip(nct_ids, studies):
            primaries = (
                study.get("protocolSection", {})
                .get("outcomesModule", {})
                .get("primaryOutcomes", [])
            )
            sections.append(f"**{nct_id}:**")
            for j, o in enumerate(primaries, 1):
                sections.append(f"{j}. {o.get('measure', 'N/A')}")
            if not primaries:
                sections.append("_No primary outcomes listed._")
            sections.append("")

    # ── Eligibility (verbatim per trial, not in a table — text is too long) ───
    if compare_on in ("all", "eligibility"):
        sections.append("### Eligibility Criteria")
        sections.append(
            "_Criteria are shown verbatim from ClinicalTrials.gov. "
            "Do not rely on this comparison for clinical or regulatory decisions._\n"
        )
        for nct_id, study in zip(nct_ids, studies):
            criteria = (
                study.get("protocolSection", {})
                .get("eligibilityModule", {})
                .get("eligibilityCriteria", "")
            )
            elig_mod = study.get("protocolSection", {}).get("eligibilityModule", {})
            sex = elig_mod.get("sex", "N/A")
            min_age = elig_mod.get("minimumAge", "N/A")
            sections.append(f"#### {_link(nct_id)}")
            sections.append(f"Sex: {sex} | Min age: {min_age}")
            if criteria:
                inclusion, exclusion = _parse_eligibility(criteria)
                sections.append(f"\n**Inclusion:**\n{inclusion}")
                if exclusion:
                    sections.append(f"\n**Exclusion:**\n{exclusion}")
            else:
                sections.append("_No eligibility criteria text available._")
            sections.append("")

    # ── Footer ────────────────────────────────────────────────────────────────
    sections.append("---")
    sections.append(
        "_Comparison reflects only what is posted on ClinicalTrials.gov. "
        "Data is self-reported by sponsors._"
    )
    sections.append("\n**Links:**")
    for nct_id in nct_ids:
        sections.append(f"- {_url(nct_id)}")

    return "\n".join(sections)


def format_trial_results(
    data: dict[str, Any],
    summary_only: bool = False,
    ae_grade: str = "3+",
) -> str:
    """
    Format posted results for get_trial_results.

    Handles all 4 no-results cases from the masterplan:
      1. Results posted → show them
      2. Trial ongoing → say so with estimated completion date
      3. Completed, no results posted → flag clearly
      4. NCT doesn't exist → handled upstream by StudyNotFoundError

    AE grade note appears at TOP and BOTTOM per masterplan.
    """
    proto = data.get("protocolSection", {})
    id_mod = proto.get("identificationModule", {})
    status_mod = proto.get("statusModule", {})
    has_results = data.get("hasResults", False)

    nct_id = id_mod.get("nctId", "Unknown")
    title = id_mod.get("briefTitle", "No title")
    status = status_mod.get("overallStatus", "UNKNOWN")

    # ── Case 2 & 3: No results posted ─────────────────────────────────────────
    if not has_results:
        if status == "COMPLETED":
            completion = _fmt_date(status_mod.get("completionDateStruct"))
            return (
                f"## Results — {_link(nct_id)}\n\n"
                f"⚠️ **This trial completed on {completion} but no results have been "
                f"posted to ClinicalTrials.gov.**\n\n"
                "This is common — approximately 60% of completed trials never post results. "
                "It does not mean the trial failed.\n\n"
                f"View the trial directly: {_url(nct_id)}\n\n"
                "_If you need results for this trial, search for associated publications "
                "in PubMed or contact the sponsor directly._"
            )
        else:
            completion = _fmt_date(status_mod.get("completionDateStruct"))
            return (
                f"## Results — {_link(nct_id)}\n\n"
                f"⏳ **Trial is {_fmt_status(status)} — results have not been posted yet.**\n\n"
                f"Estimated completion: {completion}\n\n"
                f"Check for updates: {_url(nct_id)}"
            )

    # ── Case 1: Results available ──────────────────────────────────────────────
    results = data.get("resultsSection", {})

    # AE note at TOP
    ae_note = _ae_grade_note_top(ae_grade, nct_id)

    lines: list[str] = [
        ae_note,
        f"\n## Results — {_link(nct_id)}",
        f"_{title}_\n",
    ]

    if summary_only:
        lines.append(_format_primary_outcomes_summary(results))
        lines.append(
            f"\n---\n_Summary only. Use `summary_only=False` for full results._\n"
            f"Source: {_url(nct_id)}"
        )
        return "\n".join(lines)

    # Participant flow
    flow = results.get("participantFlowModule")
    if flow:
        lines.append(_format_participant_flow(flow))

    # Baseline characteristics
    baseline = results.get("baselineCharacteristicsModule")
    if baseline:
        lines.append(_format_baseline(baseline))

    # Outcomes
    outcomes_mod = results.get("outcomeMeasuresModule", {})
    outcome_measures = outcomes_mod.get("outcomeMeasures", [])
    if outcome_measures:
        lines.append(_format_outcomes(outcome_measures))

    # Adverse events
    ae_mod = results.get("adverseEventsModule")
    if ae_mod:
        lines.append(_format_ae(ae_mod, ae_grade))

    # AE note at BOTTOM (repeated per masterplan)
    lines.append(
        "\n---\n"
        f"⚠️ **SAFETY DISCLAIMER:** Adverse event data is self-reported by sponsors. "
        f"{'Only serious events are shown by default. Use ae_grade=\"all\" for Grade 1/2 events. ' if ae_grade != 'all' else ''}"
        f"This summary must NOT be used for regulatory submissions without independent "
        f"verification at {_url(nct_id)}"
    )

    return "\n".join(lines)


def format_recruiting_near(
    rings: dict[str, list[dict[str, Any]]],
    condition: str,
    location: str,
) -> str:
    """
    Format find_recruiting_near results grouped by location ring.

    rings keys: "city", "state", "country"
    Each value is a list of study dicts for that ring.
    Studies already in a closer ring are excluded from outer rings by server.py.
    """
    city_studies = rings.get("city", [])
    state_studies = rings.get("state", [])
    country_studies = rings.get("country", [])
    total = len(city_studies) + len(state_studies) + len(country_studies)

    if total == 0:
        return (
            f"No recruiting trials found for **{condition}** near **{location}**.\n\n"
            "Try:\n"
            "- Broadening the condition term (e.g. 'cancer' instead of 'breast cancer')\n"
            "- Removing the location filter to search worldwide\n"
            "- Checking if trials exist in `status=\"NOT_YET_RECRUITING\"` status\n\n"
            "_Location data in CT.gov is city-level — no GPS radius is available._"
        )

    lines: list[str] = [
        f"## Recruiting Trials for **{condition}** near **{location}**\n",
        f"Found **{total} recruiting trial(s)**:\n",
    ]

    def _render_ring(label: str, studies: list[dict]) -> None:
        if not studies:
            return
        lines.append(f"### 📍 {label}\n")
        for i, study in enumerate(studies, 1):
            proto = study.get("protocolSection", {})
            id_mod = proto.get("identificationModule", {})
            design_mod = proto.get("designModule", {})
            sponsor_mod = proto.get("sponsorCollaboratorsModule", {})
            desc_mod = proto.get("descriptionModule", {})
            locs = proto.get("contactsLocationsModule", {}).get("locations", [])

            nct_id = id_mod.get("nctId", "Unknown")
            title = id_mod.get("briefTitle", "No title")
            phases = design_mod.get("phases", [])
            enrollment = design_mod.get("enrollmentInfo")
            summary = desc_mod.get("briefSummary", "")
            site_count, countries = _locations_summary(locs)

            lines.append(
                f"**{i}. {_link(nct_id)} — {title}**\n"
                f"   Phase: {_fmt_phase(phases)} | Sponsor: {_sponsor_name(sponsor_mod)}\n"
                f"   Enrollment target: {_fmt_enrollment(enrollment)} | "
                f"Sites: {site_count} in {countries}\n"
                f"   _{_truncate(summary)}_\n"
            )

    _render_ring(f"In {location}", city_studies)
    _render_ring(f"Same region as {location}", state_studies)
    _render_ring(f"Elsewhere in {location.split(',')[-1].strip()}", country_studies)

    lines.append(
        "---\n"
        "⚠️ **Important — verify site status before contacting:** Results are filtered "
        "by *overall* trial status (RECRUITING). Individual site recruitment status can "
        "differ — a site in your city may still show 'Not yet recruiting' even within a "
        "globally recruiting trial. Always click the NCT link and check the specific "
        "site's status before reaching out.\n\n"
        "⚠️ **Location note:** CT.gov stores site locations at city/country level — "
        "there are no GPS coordinates or radius-based filtering. Results are grouped "
        "by whether site cities match your query, not by physical distance.\n"
        "_To find more trials, try searching without a location filter._"
    )

    return "\n".join(lines)


# ── Private result-section helpers ────────────────────────────────────────────

def _ae_grade_note_top(ae_grade: str, nct_id: str) -> str:
    if ae_grade == "all":
        return (
            "⚠️ **ADVERSE EVENTS (ALL GRADES):** Showing both serious events (SAEs) "
            "and other events (typically Grade 1/2). This is a summary — not a complete "
            "safety profile. Always verify at the source."
        )
    return (
        "⚠️ **ADVERSE EVENTS (SERIOUS ONLY):** Showing serious adverse events (SAEs) "
        "by default. Grade 1/2 non-serious events are excluded. "
        "To include all grades, use `ae_grade=\"all\"`."
    )


def _format_participant_flow(flow: dict[str, Any]) -> str:
    groups = flow.get("groups", [])
    periods = flow.get("periods", [])

    if not groups or not periods:
        return "\n### Participant Flow\n_No participant flow data available._"

    group_ids = [g["id"] for g in groups]
    group_titles = [g["title"][:30] for g in groups]

    lines = ["\n### Participant Flow"]
    header = "| Milestone | " + " | ".join(group_titles) + " |"
    sep = "|---|" + "---|" * len(groups)
    lines.append(header)
    lines.append(sep)

    for period in periods[:1]:  # Show first period (usually "Overall Study")
        for milestone in period.get("milestones", []):
            m_type = milestone.get("type", "")
            achievements = {a["groupId"]: a["numSubjects"] for a in milestone.get("achievements", [])}
            row = f"| {m_type.title()} | " + " | ".join(
                achievements.get(gid, "N/A") for gid in group_ids
            ) + " |"
            lines.append(row)

        withdrawals = period.get("dropWithdraws", [])
        for w in withdrawals[:3]:
            w_type = w.get("type", "")
            reasons = {r["groupId"]: r["numSubjects"] for r in w.get("reasons", [])}
            row = f"| ↳ {w_type} | " + " | ".join(
                reasons.get(gid, "0") for gid in group_ids
            ) + " |"
            lines.append(row)

    return "\n".join(lines)


def _format_baseline(baseline: dict[str, Any]) -> str:
    groups = baseline.get("groups", [])
    measures = baseline.get("measures", [])

    if not groups:
        return "\n### Baseline Characteristics\n_No baseline data available._"

    group_ids = [g["id"] for g in groups if g.get("title", "").lower() != "total"]
    group_titles = [g["title"][:25] for g in groups if g.get("title", "").lower() != "total"]

    lines = ["\n### Baseline Characteristics"]
    header = "| Characteristic | " + " | ".join(group_titles) + " |"
    sep = "|---|" + "---|" * len(group_ids)
    lines.append(header)
    lines.append(sep)

    for measure in measures[:6]:  # Show first 6 measures to keep output readable
        title = measure.get("title", "N/A")[:40]
        param = measure.get("paramType", "")
        unit = measure.get("unitOfMeasure", "")
        display = f"{title} ({param} {unit})".strip(" ()")

        classes = measure.get("classes", [])
        if not classes:
            continue

        categories = classes[0].get("categories", [])
        if not categories:
            continue

        if len(categories) == 1:
            measurements = {
                m["groupId"]: m.get("value", "N/A")
                for m in categories[0].get("measurements", [])
            }
            row = f"| {display} | " + " | ".join(
                measurements.get(gid, "N/A") for gid in group_ids
            ) + " |"
            lines.append(row)
        else:
            for cat in categories[:3]:
                cat_title = cat.get("title", "")
                measurements = {
                    m["groupId"]: m.get("value", "N/A")
                    for m in cat.get("measurements", [])
                }
                row = f"| {title}: {cat_title} | " + " | ".join(
                    measurements.get(gid, "N/A") for gid in group_ids
                ) + " |"
                lines.append(row)

    return "\n".join(lines)


def _format_primary_outcomes_summary(results: dict[str, Any]) -> str:
    """For summary_only=True — just primary outcomes in 2-3 lines."""
    outcome_measures = results.get("outcomeMeasuresModule", {}).get("outcomeMeasures", [])
    primaries = [o for o in outcome_measures if o.get("type") == "PRIMARY"]

    if not primaries:
        return "_No primary outcome results posted._"

    lines = ["### Primary Outcome(s)"]
    for o in primaries:
        title = o.get("title", "N/A")
        unit = o.get("unitOfMeasure", "")
        classes = o.get("classes", [])
        value_str = "N/A"

        if classes:
            cats = classes[0].get("categories", [])
            if cats:
                measurements = cats[0].get("measurements", [])
                if measurements:
                    vals = [
                        f"{m.get('value', '?')} {unit}".strip()
                        for m in measurements[:2]
                    ]
                    value_str = " vs ".join(vals)

        analyses = o.get("analyses", [])
        sig = ""
        if analyses:
            p = analyses[0].get("pValue", "")
            hr = analyses[0].get("paramValue", "")
            if p:
                sig = f" | p={p}"
                try:
                    p_float = float(p.replace("<", "").replace(">", ""))
                    sig = f" ✅ p={p}" if p_float < 0.05 else f" ❌ p={p}"
                except ValueError:
                    sig = f" | p={p}"
            if hr:
                sig += f" | HR={hr}"

        lines.append(f"- **{title[:80]}**")
        lines.append(f"  Result: {value_str}{sig}")

    return "\n".join(lines)


def _format_outcomes(outcome_measures: list[dict[str, Any]]) -> str:
    primaries = [o for o in outcome_measures if o.get("type") == "PRIMARY"]
    secondaries = [o for o in outcome_measures if o.get("type") == "SECONDARY"]

    lines = []

    if primaries:
        lines.append("\n### Primary Outcomes")
        for o in primaries:
            lines.append(_format_single_outcome(o))

    if secondaries:
        lines.append("\n### Secondary Outcomes")
        for o in secondaries[:5]:
            lines.append(_format_single_outcome(o))
        if len(secondaries) > 5:
            lines.append(f"_…and {len(secondaries) - 5} more secondary outcomes_")

    return "\n".join(lines)


def _format_single_outcome(outcome: dict[str, Any]) -> str:
    title = outcome.get("title", "N/A")
    param = outcome.get("paramType", "")
    unit = outcome.get("unitOfMeasure", "")
    dispersion = outcome.get("dispersionType", "")
    groups = {g["id"]: g["title"][:25] for g in outcome.get("groups", [])}
    classes = outcome.get("classes", [])
    analyses = outcome.get("analyses", [])

    parts = [f"\n**{title[:100]}**"]
    if param:
        parts.append(f"_{param}{', ' + dispersion if dispersion else ''} | {unit}_")

    if classes:
        for cls in classes[:1]:
            for cat in cls.get("categories", [])[:1]:
                for m in cat.get("measurements", []):
                    gid = m.get("groupId", "")
                    val = m.get("value", "N/A")
                    lo = m.get("lowerLimit", "")
                    hi = m.get("upperLimit", "")
                    ci = f" (95% CI: {lo}–{hi})" if lo and hi and hi != "NA" else ""
                    group_name = groups.get(gid, gid)
                    parts.append(f"- {group_name}: **{val} {unit}**{ci}")

    if analyses:
        a = analyses[0]
        p = a.get("pValue", "")
        hr = a.get("paramValue", "")
        hr_type = a.get("paramType", "")
        ci_lo = a.get("ciLowerLimit", "")
        ci_hi = a.get("ciUpperLimit", "")

        sig_str = ""
        if p:
            try:
                p_float = float(p.replace("<", "").replace(">", ""))
                sig_str = f"✅ Statistically significant (p={p})" if p_float < 0.05 else f"❌ Not significant (p={p})"
            except ValueError:
                sig_str = f"p={p}"
        if hr:
            ci_str = f" (95% CI: {ci_lo}–{ci_hi})" if ci_lo and ci_hi else ""
            sig_str += f" | {hr_type}={hr}{ci_str}"

        if sig_str:
            parts.append(f"_{sig_str}_")

    return "\n".join(parts)


def _format_ae(ae_mod: dict[str, Any], ae_grade: str) -> str:
    event_groups = ae_mod.get("eventGroups", [])
    serious = ae_mod.get("seriousEvents", [])
    other = ae_mod.get("otherEvents", [])
    timeframe = ae_mod.get("timeFrame", "")

    group_ids = [g["id"] for g in event_groups]
    group_titles = [g["title"][:20] for g in event_groups]

    lines = [f"\n### Adverse Events"]
    if timeframe:
        lines.append(f"_Timeframe: {timeframe}_\n")

    def _ae_table(events: list[dict], label: str) -> list[str]:
        if not events:
            return []
        table = [f"\n**{label}**"]
        header = "| Event | System | " + " | ".join(
            f"{t} n/N (%)" for t in group_titles
        ) + " |"
        sep = "|---|---|" + "---|" * len(group_ids)
        table.append(header)
        table.append(sep)
        for ev in events[:15]:
            term = ev.get("term", "N/A")[:35]
            system = ev.get("organSystem", "N/A")[:30]
            stats = {s["groupId"]: s for s in ev.get("stats", [])}
            cells = []
            for gid in group_ids:
                s = stats.get(gid, {})
                cells.append(_pct(s.get("numAffected"), s.get("numAtRisk")))
            table.append(f"| {term} | {system} | " + " | ".join(cells) + " |")
        if len(events) > 15:
            table.append(f"_…and {len(events) - 15} more events_")
        return table

    lines.extend(_ae_table(serious, "Serious Adverse Events (SAEs)"))

    if ae_grade == "all" and other:
        lines.extend(_ae_table(other, "Other Adverse Events (Grade 1/2)"))

    return "\n".join(lines)
