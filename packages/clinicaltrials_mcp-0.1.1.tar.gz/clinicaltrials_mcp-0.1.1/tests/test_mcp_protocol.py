"""
MCP protocol layer tests for clinicaltrials-mcp.

These tests verify the server's behaviour as a service — not the formatting
logic (that's in test_tools.py), but whether the MCP wiring itself is correct:

  1. Tool registration  — are all 5 tools registered with the right names?
  2. Schema correctness — do schemas mark required/optional fields correctly?
                          do constraints match the masterplan (minItems, maximum)?
  3. Error handling     — does every bad input produce TextContent, not a crash?
  4. Integration        — does it work against the live CT.gov API?
                          (marked @pytest.mark.integration, skipped offline)

Why protocol tests catch things unit tests don't:
  A formatter bug → bad output text.
  A protocol bug  → server crash → Claude Desktop shows "server disconnected".
  These are completely different failure modes and need separate test coverage.

Run offline tests only (fast, no network):
    pytest tests/test_mcp_protocol.py -v -m "not integration"

Run all tests including live API (requires network):
    pytest tests/test_mcp_protocol.py -v
"""

import asyncio
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

import mcp.types as types
from clinicaltrials_mcp.server import list_tools, call_tool


# ── Helpers ────────────────────────────────────────────────────────────────────

def _run(coro):
    """Run a coroutine synchronously — avoids requiring pytest-asyncio."""
    return asyncio.run(coro)


def _get_tool(tools: list[types.Tool], name: str) -> types.Tool:
    """Find a tool by name or raise a clear assertion error."""
    match = next((t for t in tools if t.name == name), None)
    assert match is not None, f"Tool '{name}' not found. Registered: {[t.name for t in tools]}"
    return match


# ── Tool registration tests ────────────────────────────────────────────────────

class TestToolRegistration:
    """Verify all 5 tools are registered with correct names and metadata.

    These are the cheapest protocol tests — no API calls, just inspect
    what list_tools() returns.
    """

    @pytest.fixture(scope="class")
    def tools(self):
        return _run(list_tools())

    def test_exactly_5_tools_registered(self, tools):
        assert len(tools) == 5, (
            f"Expected 5 tools, got {len(tools)}: {[t.name for t in tools]}"
        )

    def test_all_required_tool_names_present(self, tools):
        names = {t.name for t in tools}
        expected = {
            "search_trials",
            "get_trial_details",
            "compare_trials",
            "get_trial_results",
            "find_recruiting_near",
        }
        assert names == expected

    def test_every_tool_has_a_description(self, tools):
        for tool in tools:
            assert tool.description, f"Tool '{tool.name}' has no description"
            assert len(tool.description) > 20, (
                f"Tool '{tool.name}' description is too short: '{tool.description}'"
            )

    def test_every_tool_has_an_input_schema(self, tools):
        for tool in tools:
            assert tool.inputSchema, f"Tool '{tool.name}' has no inputSchema"
            assert "properties" in tool.inputSchema, (
                f"Tool '{tool.name}' inputSchema missing 'properties'"
            )

    def test_every_tool_schema_has_object_type(self, tools):
        for tool in tools:
            assert tool.inputSchema.get("type") == "object", (
                f"Tool '{tool.name}' inputSchema type should be 'object'"
            )


# ── Input schema correctness tests ────────────────────────────────────────────

class TestInputSchemas:
    """Verify that input schemas match the masterplan spec exactly.

    These tests make the schema a tested contract — if someone accidentally
    changes a required field to optional or removes a constraint, the test
    fails immediately rather than silently shipping a broken schema.
    """

    @pytest.fixture(scope="class")
    def tools(self):
        return _run(list_tools())

    # ── search_trials ──────────────────────────────────────────────────────────

    def test_search_trials_condition_is_required(self, tools):
        tool = _get_tool(tools, "search_trials")
        assert "condition" in tool.inputSchema["required"]

    def test_search_trials_location_is_optional(self, tools):
        tool = _get_tool(tools, "search_trials")
        assert "location" in tool.inputSchema["properties"]
        assert "location" not in tool.inputSchema.get("required", [])

    def test_search_trials_max_results_maximum_is_50(self, tools):
        tool = _get_tool(tools, "search_trials")
        schema = tool.inputSchema["properties"]["max_results"]
        assert schema["maximum"] == 50

    def test_search_trials_max_results_minimum_is_1(self, tools):
        tool = _get_tool(tools, "search_trials")
        schema = tool.inputSchema["properties"]["max_results"]
        assert schema["minimum"] == 1

    # ── get_trial_details ──────────────────────────────────────────────────────

    def test_get_trial_details_nct_id_is_required(self, tools):
        tool = _get_tool(tools, "get_trial_details")
        assert "nct_id" in tool.inputSchema["required"]

    def test_get_trial_details_has_only_one_property(self, tools):
        tool = _get_tool(tools, "get_trial_details")
        assert list(tool.inputSchema["properties"].keys()) == ["nct_id"]

    # ── compare_trials ─────────────────────────────────────────────────────────

    def test_compare_trials_nct_ids_is_required(self, tools):
        tool = _get_tool(tools, "compare_trials")
        assert "nct_ids" in tool.inputSchema["required"]

    def test_compare_trials_nct_ids_min_items_is_2(self, tools):
        tool = _get_tool(tools, "compare_trials")
        schema = tool.inputSchema["properties"]["nct_ids"]
        assert schema["minItems"] == 2

    def test_compare_trials_nct_ids_max_items_is_5(self, tools):
        tool = _get_tool(tools, "compare_trials")
        schema = tool.inputSchema["properties"]["nct_ids"]
        assert schema["maxItems"] == 5

    def test_compare_trials_nct_ids_is_array_of_strings(self, tools):
        tool = _get_tool(tools, "compare_trials")
        schema = tool.inputSchema["properties"]["nct_ids"]
        assert schema["type"] == "array"
        assert schema["items"]["type"] == "string"

    def test_compare_trials_compare_on_has_valid_enum(self, tools):
        tool = _get_tool(tools, "compare_trials")
        schema = tool.inputSchema["properties"]["compare_on"]
        expected_options = {"all", "design", "timeline", "locations", "endpoints", "eligibility"}
        assert set(schema["enum"]) == expected_options

    def test_compare_trials_compare_on_is_optional(self, tools):
        tool = _get_tool(tools, "compare_trials")
        assert "compare_on" not in tool.inputSchema.get("required", [])

    # ── get_trial_results ──────────────────────────────────────────────────────

    def test_get_trial_results_nct_id_is_required(self, tools):
        tool = _get_tool(tools, "get_trial_results")
        assert "nct_id" in tool.inputSchema["required"]

    def test_get_trial_results_ae_grade_enum_matches_masterplan(self, tools):
        tool = _get_tool(tools, "get_trial_results")
        schema = tool.inputSchema["properties"]["ae_grade"]
        assert set(schema["enum"]) == {"3+", "all", "serious"}

    def test_get_trial_results_summary_only_is_boolean(self, tools):
        tool = _get_tool(tools, "get_trial_results")
        schema = tool.inputSchema["properties"]["summary_only"]
        assert schema["type"] == "boolean"

    def test_get_trial_results_summary_only_is_optional(self, tools):
        tool = _get_tool(tools, "get_trial_results")
        assert "summary_only" not in tool.inputSchema.get("required", [])

    # ── find_recruiting_near ───────────────────────────────────────────────────

    def test_find_recruiting_near_condition_is_required(self, tools):
        tool = _get_tool(tools, "find_recruiting_near")
        assert "condition" in tool.inputSchema["required"]

    def test_find_recruiting_near_location_is_required(self, tools):
        # Unlike search_trials where location is optional,
        # find_recruiting_near requires it — that's the whole point of the tool
        tool = _get_tool(tools, "find_recruiting_near")
        assert "location" in tool.inputSchema["required"]

    def test_find_recruiting_near_max_results_maximum_is_50(self, tools):
        tool = _get_tool(tools, "find_recruiting_near")
        schema = tool.inputSchema["properties"]["max_results"]
        assert schema["maximum"] == 50


# ── Error handling / resilience tests ─────────────────────────────────────────

class TestErrorHandling:
    """Verify the server never crashes — all errors return TextContent.

    An MCP server is a long-running process. Any unhandled exception kills it.
    These tests confirm every foreseeable failure mode is caught and returned
    as readable text, not as a Python exception that would crash the server.
    """

    def test_unknown_tool_name_returns_text_not_exception(self):
        result = _run(call_tool("nonexistent_tool_xyz", {}))
        assert isinstance(result, list)
        assert len(result) == 1
        assert result[0].type == "text"

    def test_unknown_tool_message_is_informative(self):
        result = _run(call_tool("nonexistent_tool_xyz", {}))
        assert "Unknown tool" in result[0].text
        assert "nonexistent_tool_xyz" in result[0].text

    def test_compare_trials_with_1_id_returns_text_not_exception(self):
        result = _run(call_tool("compare_trials", {"nct_ids": ["NCT02142803"]}))
        assert result[0].type == "text"

    def test_compare_trials_with_1_id_message_says_at_least_2(self):
        result = _run(call_tool("compare_trials", {"nct_ids": ["NCT02142803"]}))
        assert "at least 2" in result[0].text

    def test_compare_trials_with_6_ids_returns_text_not_exception(self):
        six_ids = [f"NCT0000000{i}" for i in range(6)]
        result = _run(call_tool("compare_trials", {"nct_ids": six_ids}))
        assert result[0].type == "text"

    def test_compare_trials_with_6_ids_message_says_maximum_5(self):
        six_ids = [f"NCT0000000{i}" for i in range(6)]
        result = _run(call_tool("compare_trials", {"nct_ids": six_ids}))
        assert "maximum of 5" in result[0].text

    def test_all_error_responses_are_single_text_content(self):
        """Every error path must return exactly one TextContent item."""
        error_cases = [
            ("nonexistent_tool", {}),
            ("compare_trials", {"nct_ids": ["only_one"]}),
            ("compare_trials", {"nct_ids": ["a", "b", "c", "d", "e", "f"]}),
        ]
        for tool_name, args in error_cases:
            result = _run(call_tool(tool_name, args))
            assert len(result) == 1, f"Expected 1 result for {tool_name}, got {len(result)}"
            assert result[0].type == "text", f"Expected text type for {tool_name}"
            assert isinstance(result[0].text, str), f"Expected string text for {tool_name}"
            assert len(result[0].text) > 0, f"Expected non-empty text for {tool_name}"


# ── Integration tests (live CT.gov API) ───────────────────────────────────────

class TestIntegration:
    """End-to-end tests against the live ClinicalTrials.gov API.

    These are marked @pytest.mark.integration and require network access.
    They are skipped by default in offline/CI environments.

    Run them explicitly:
        pytest tests/test_mcp_protocol.py -m integration -v

    What these test that offline tests cannot:
    - The StudyNotFoundError path (requires a real API 404 response)
    - That real search results contain NCT IDs (live data validation)
    - That get_trial_details returns real verbatim eligibility criteria
    - That the full stack (server → client → CT.gov → formatter) works end-to-end
    """

    @pytest.mark.integration
    def test_invalid_nct_id_returns_not_found_message(self):
        result = _run(call_tool("get_trial_details", {"nct_id": "NCT99999999"}))
        assert result[0].type == "text"
        assert "not found" in result[0].text.lower()
        # Must contain the NCT ID so the user knows which ID failed
        assert "NCT99999999" in result[0].text

    @pytest.mark.integration
    def test_invalid_nct_id_does_not_crash_server(self):
        # Call once with bad ID, then again with good ID — server must still work
        _run(call_tool("get_trial_details", {"nct_id": "NCT99999999"}))
        result = _run(call_tool("get_trial_details", {"nct_id": "NCT02142803"}))
        assert result[0].type == "text"
        assert "NCT02142803" in result[0].text

    @pytest.mark.integration
    def test_search_trials_returns_nct_ids_in_output(self):
        result = _run(
            call_tool("search_trials", {"condition": "diabetes", "max_results": 2})
        )
        assert result[0].type == "text"
        assert "NCT" in result[0].text

    @pytest.mark.integration
    def test_get_trial_details_real_study_has_eligibility(self):
        result = _run(call_tool("get_trial_details", {"nct_id": "NCT02142803"}))
        assert "Inclusion Criteria" in result[0].text
        assert "Exclusion Criteria" in result[0].text

    @pytest.mark.integration
    def test_get_trial_results_real_study_has_ae_note_at_top(self):
        result = _run(call_tool("get_trial_results", {"nct_id": "NCT02142803"}))
        first_nonempty = next(
            line for line in result[0].text.split("\n") if line.strip()
        )
        assert "ADVERSE EVENTS" in first_nonempty

    @pytest.mark.integration
    def test_compare_trials_real_studies_returns_both_nct_ids(self):
        result = _run(
            call_tool(
                "compare_trials",
                {"nct_ids": ["NCT02142803", "NCT04280341"], "compare_on": "design"},
            )
        )
        assert "NCT02142803" in result[0].text

    @pytest.mark.integration
    def test_find_recruiting_near_returns_text_for_real_location(self):
        result = _run(
            call_tool(
                "find_recruiting_near",
                {"condition": "diabetes", "location": "Bangalore, India"},
            )
        )
        assert result[0].type == "text"
        assert len(result[0].text) > 0

    @pytest.mark.integration
    def test_status_override_is_respected(self):
        # Passing status="TERMINATED" should include terminated trials
        result = _run(
            call_tool(
                "search_trials",
                {"condition": "diabetes", "status": "TERMINATED", "max_results": 2},
            )
        )
        assert result[0].type == "text"
        # Either we get results or a clean "no results" message — never a crash
        assert len(result[0].text) > 0
