"""
Unit tests for clinicaltrials-mcp formatters and server input validation.

These tests run completely offline — they use saved JSON fixtures from
tests/fixtures/ instead of making live API calls. Fast (milliseconds),
deterministic (same output every run), no network required.

Testing philosophy used here:
  Assert on INVARIANTS (design rules that must always hold), not on
  exact text (which is brittle and breaks when wording changes).

  Good:  assert "Inclusion Criteria" in output
  Bad:   assert output == "Inclusion Criteria:\n\n* Adults aged..."

Layer 1 tests (this file) — per the masterplan's 4-layer testing strategy:
  - Formatter logic against fixtures
  - Client constant correctness
  - Server-layer input validation (no API calls)

Layer 2 (integration, live API) and Layer 3 (MCP protocol) are in
test_mcp_protocol.py.
"""

import asyncio
import json
import sys
from pathlib import Path

import pytest

# Add src/ to path so imports work without installing the package
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from clinicaltrials_mcp.client import (
    ALL_STATUSES,
    DEFAULT_EXCLUDED_STATUSES,
    MAX_PAGE_SIZE,
    STATUS_DISPLAY_ORDER,
)
from clinicaltrials_mcp.formatters import (
    format_recruiting_near,
    format_search_results,
    format_trial_comparison,
    format_trial_details,
    format_trial_results,
)
from clinicaltrials_mcp.server import call_tool


# ── Fixtures ───────────────────────────────────────────────────────────────────

FIXTURES_DIR = Path(__file__).parent / "fixtures"


def _load(filename: str) -> dict:
    with open(FIXTURES_DIR / filename) as f:
        return json.load(f)


@pytest.fixture(scope="module")
def details():
    return _load("nct_02142803_details.json")


@pytest.fixture(scope="module")
def results():
    return _load("nct_02142803_results.json")


@pytest.fixture(scope="module")
def search():
    return _load("search_diabetes_india.json")


@pytest.fixture(scope="module")
def no_results():
    return _load("search_no_results.json")


@pytest.fixture(scope="module")
def completed_no_results():
    return _load("nct_completed_no_results.json")


@pytest.fixture(scope="module")
def default_statuses():
    return [s for s in ALL_STATUSES if s not in DEFAULT_EXCLUDED_STATUSES]


# ── Client constant tests ──────────────────────────────────────────────────────

class TestClientConstants:
    """The constants in client.py are the single source of truth for
    status logic. These tests make sure they're correct."""

    def test_withdrawn_and_terminated_are_excluded_by_default(self):
        assert "WITHDRAWN" in DEFAULT_EXCLUDED_STATUSES
        assert "TERMINATED" in DEFAULT_EXCLUDED_STATUSES

    def test_recruiting_and_completed_are_not_excluded_by_default(self):
        assert "RECRUITING" not in DEFAULT_EXCLUDED_STATUSES
        assert "COMPLETED" not in DEFAULT_EXCLUDED_STATUSES

    def test_recruiting_is_first_in_display_order(self):
        assert STATUS_DISPLAY_ORDER[0] == "RECRUITING"

    def test_max_page_size_is_50(self):
        assert MAX_PAGE_SIZE == 50

    def test_all_statuses_contains_9_values(self):
        assert len(ALL_STATUSES) == 9

    def test_display_order_contains_no_excluded_statuses(self):
        # WITHDRAWN and TERMINATED should not be in display order —
        # they're excluded by default and have no display rank
        for status in DEFAULT_EXCLUDED_STATUSES:
            assert status not in STATUS_DISPLAY_ORDER


# ── format_search_results tests ───────────────────────────────────────────────

class TestFormatSearchResults:
    """Tests for the search_trials output formatter."""

    def test_returns_nonempty_string_for_valid_data(self, search, default_statuses):
        output = format_search_results(search, "diabetes", default_statuses)
        assert isinstance(output, str)
        assert len(output) > 0

    def test_shows_number_of_results(self, search, default_statuses):
        output = format_search_results(search, "diabetes", default_statuses)
        # The fixture has 4 studies
        assert "4 trial(s)" in output

    def test_recruiting_appears_before_completed(self, search, default_statuses):
        # RECRUITING trials must sort before COMPLETED trials
        output = format_search_results(search, "diabetes", default_statuses)
        recruiting_pos = output.find("Status: Recruiting")
        completed_pos = output.find("Status: Completed")
        assert recruiting_pos != -1, "Should have at least one Recruiting trial"
        assert completed_pos != -1, "Should have at least one Completed trial"
        assert recruiting_pos < completed_pos

    def test_footer_names_excluded_statuses(self, search, default_statuses):
        # The transparency footer must name what was excluded and how to override
        output = format_search_results(search, "diabetes", default_statuses)
        assert "WITHDRAWN" in output
        assert "TERMINATED" in output
        assert "excluded by default" in output

    def test_footer_shows_how_to_override_filter(self, search, default_statuses):
        output = format_search_results(search, "diabetes", default_statuses)
        assert "status=" in output

    def test_each_result_has_nct_hyperlink(self, search, default_statuses):
        output = format_search_results(search, "diabetes", default_statuses)
        assert "clinicaltrials.gov/study/NCT" in output

    def test_each_result_shows_sponsor(self, search, default_statuses):
        output = format_search_results(search, "diabetes", default_statuses)
        assert "Sponsor:" in output

    def test_no_results_returns_helpful_message(self, no_results, default_statuses):
        output = format_search_results(no_results, "xyzzy", default_statuses)
        assert "No trials found" in output
        assert "xyzzy" in output

    def test_no_results_does_not_crash(self, no_results, default_statuses):
        # An empty studies list must produce a string, not raise an exception
        output = format_search_results(no_results, "xyzzy", default_statuses)
        assert isinstance(output, str)

    def test_condition_name_appears_in_output(self, search, default_statuses):
        output = format_search_results(search, "diabetes", default_statuses)
        assert "diabetes" in output


# ── format_trial_details tests ────────────────────────────────────────────────

class TestFormatTrialDetails:
    """Tests for the get_trial_details output formatter.

    Key design rules: NCT link at top AND bottom, eligibility verbatim.
    """

    def test_nct_link_at_top(self, details):
        output = format_trial_details(details)
        first_nonempty_line = next(
            line for line in output.split("\n") if line.strip()
        )
        assert "clinicaltrials.gov" in first_nonempty_line

    def test_nct_link_at_bottom(self, details):
        output = format_trial_details(details)
        last_nonempty_line = next(
            line for line in reversed(output.split("\n")) if line.strip()
        )
        assert "clinicaltrials.gov" in last_nonempty_line

    def test_nct_id_appears_in_output(self, details):
        output = format_trial_details(details)
        assert "NCT02142803" in output

    def test_eligibility_inclusion_criteria_verbatim(self, details):
        # We show "Inclusion Criteria" header and verbatim text
        output = format_trial_details(details)
        assert "Inclusion Criteria" in output

    def test_eligibility_exclusion_criteria_verbatim(self, details):
        output = format_trial_details(details)
        assert "Exclusion Criteria" in output

    def test_eligibility_contains_actual_verbatim_text(self, details):
        # A specific phrase from the real eligibility text in the fixture
        # that could only be present if the text is verbatim, not paraphrased
        output = format_trial_details(details)
        assert "ECOG" in output

    def test_shows_trial_overview_section(self, details):
        output = format_trial_details(details)
        assert "Trial Overview" in output

    def test_shows_sites_section(self, details):
        output = format_trial_details(details)
        assert "Sites" in output

    def test_shows_results_section(self, details):
        output = format_trial_details(details)
        assert "Results" in output

    def test_has_results_flag_shown(self, details):
        # NCT02142803 has hasResults: true in our fixture
        output = format_trial_details(details)
        assert "get_trial_results" in output  # tells user how to fetch results

    def test_verification_disclaimer_present(self, details):
        output = format_trial_details(details)
        assert "verify" in output.lower() or "verification" in output.lower()


# ── format_trial_results tests ────────────────────────────────────────────────

class TestFormatTrialResults:
    """Tests for the get_trial_results output formatter.

    Key design rules: AE note at TOP and BOTTOM, 4 no-results cases handled.
    """

    # ── Case 1: results posted ────────────────────────────────────────────────

    def test_ae_note_at_top_when_results_exist(self, results):
        output = format_trial_results(results)
        first_nonempty_line = next(
            line for line in output.split("\n") if line.strip()
        )
        assert "ADVERSE EVENTS" in first_nonempty_line

    def test_ae_safety_disclaimer_at_bottom(self, results):
        output = format_trial_results(results)
        # Disclaimer must appear near the bottom (within last 5 non-empty lines)
        nonempty_lines = [line for line in output.split("\n") if line.strip()]
        last_section = "\n".join(nonempty_lines[-8:])
        assert "SAFETY DISCLAIMER" in last_section

    def test_participant_flow_shown(self, results):
        output = format_trial_results(results)
        assert "Participant Flow" in output

    def test_primary_outcomes_shown(self, results):
        output = format_trial_results(results)
        assert "Primary Outcome" in output

    def test_serious_ae_table_shown_by_default(self, results):
        output = format_trial_results(results, ae_grade="3+")
        assert "Serious Adverse Events" in output

    def test_other_events_hidden_by_default(self, results):
        output = format_trial_results(results, ae_grade="3+")
        assert "Other Adverse Events (Grade 1/2)" not in output

    def test_ae_grade_all_shows_other_events(self, results):
        output = format_trial_results(results, ae_grade="all")
        assert "Other Adverse Events" in output

    def test_ae_grade_all_note_at_top_mentions_all_grades(self, results):
        output = format_trial_results(results, ae_grade="all")
        first_nonempty_line = next(
            line for line in output.split("\n") if line.strip()
        )
        assert "ALL GRADES" in first_nonempty_line

    # ── summary_only flag ─────────────────────────────────────────────────────

    def test_summary_only_shows_primary_outcome(self, results):
        output = format_trial_results(results, summary_only=True)
        assert "Primary Outcome" in output

    def test_summary_only_omits_participant_flow(self, results):
        output = format_trial_results(results, summary_only=True)
        assert "Participant Flow" not in output

    def test_summary_only_omits_baseline_characteristics(self, results):
        output = format_trial_results(results, summary_only=True)
        assert "Baseline Characteristics" not in output

    def test_summary_only_omits_full_ae_table(self, results):
        output = format_trial_results(results, summary_only=True)
        assert "Serious Adverse Events" not in output

    # ── Case 2: ongoing trial, no results posted ──────────────────────────────

    def test_ongoing_trial_no_results_returns_status_message(self, details):
        ongoing = {**details, "hasResults": False}
        output = format_trial_results(ongoing)
        # Must say something about no results and why
        assert "not been posted" in output or "ongoing" in output.lower()

    def test_ongoing_no_results_does_not_show_outcomes(self, details):
        ongoing = {**details, "hasResults": False}
        output = format_trial_results(ongoing)
        assert "Primary Outcome" not in output
        assert "Participant Flow" not in output

    # ── Case 3: completed trial, no results posted ────────────────────────────

    def test_completed_no_results_mentions_completion(self, completed_no_results):
        output = format_trial_results(completed_no_results)
        assert "completed" in output.lower()

    def test_completed_no_results_shows_60_percent_note(self, completed_no_results):
        # The 60% educational disclaimer is required by the masterplan
        output = format_trial_results(completed_no_results)
        assert "60%" in output

    def test_completed_no_results_does_not_show_outcomes(self, completed_no_results):
        output = format_trial_results(completed_no_results)
        assert "Primary Outcome" not in output
        assert "Participant Flow" not in output

    def test_completed_no_results_explicitly_negates_failure(self, completed_no_results):
        output = format_trial_results(completed_no_results)
        # The formatter must explicitly tell the user that no results ≠ trial failed.
        # The phrase "does not mean" (as in "does not mean the trial failed") is required.
        # Note: asserting "failed" not in output would be wrong — the correct phrase
        # IS "does not mean the trial failed", which contains the word "failed".
        assert "does not mean" in output.lower()


# ── format_trial_comparison tests ─────────────────────────────────────────────

class TestFormatTrialComparison:
    """Tests for the compare_trials output formatter."""

    def test_shows_both_nct_ids(self, details, completed_no_results):
        output = format_trial_comparison([details, completed_no_results])
        assert "NCT02142803" in output
        assert "NCT03444521" in output

    def test_shows_links_at_bottom(self, details, completed_no_results):
        output = format_trial_comparison([details, completed_no_results])
        assert "Links:" in output
        assert "clinicaltrials.gov" in output

    def test_comparison_disclaimer_present(self, details, completed_no_results):
        output = format_trial_comparison([details, completed_no_results])
        assert "self-reported" in output.lower() or "ClinicalTrials.gov" in output

    def test_too_few_studies_returns_error(self):
        output = format_trial_comparison([])
        assert "at least 2" in output

    def test_too_many_studies_returns_error(self, details):
        output = format_trial_comparison([details] * 6)
        assert "maximum of 5" in output

    def test_compare_on_design_shows_phase(self, details, completed_no_results):
        output = format_trial_comparison(
            [details, completed_no_results], compare_on="design"
        )
        assert "Phase" in output

    def test_compare_on_eligibility_shows_criteria(self, details, completed_no_results):
        output = format_trial_comparison(
            [details, completed_no_results], compare_on="eligibility"
        )
        assert "Eligibility" in output
        assert "Inclusion" in output

    def test_compare_on_eligibility_has_verbatim_warning(self, details, completed_no_results):
        output = format_trial_comparison(
            [details, completed_no_results], compare_on="eligibility"
        )
        assert "verbatim" in output.lower()

    def test_compare_on_timeline_shows_dates(self, details, completed_no_results):
        output = format_trial_comparison(
            [details, completed_no_results], compare_on="timeline"
        )
        assert "Timeline" in output or "date" in output.lower()

    def test_compare_on_all_shows_multiple_sections(self, details, completed_no_results):
        output = format_trial_comparison(
            [details, completed_no_results], compare_on="all"
        )
        assert "Design" in output
        assert "Timeline" in output
        assert "Eligibility" in output


# ── format_recruiting_near tests ──────────────────────────────────────────────

class TestFormatRecruitingNear:
    """Tests for the find_recruiting_near output formatter."""

    def _make_rings(self, search_fixture: dict) -> dict:
        studies = search_fixture.get("studies", [])
        return {
            "city": studies[:1],
            "state": [],
            "country": studies[1:2],
        }

    def test_returns_string(self, search):
        output = format_recruiting_near(
            self._make_rings(search), "diabetes", "Bangalore, India"
        )
        assert isinstance(output, str)

    def test_shows_condition_and_location(self, search):
        output = format_recruiting_near(
            self._make_rings(search), "diabetes", "Bangalore, India"
        )
        assert "diabetes" in output
        assert "Bangalore" in output

    def test_city_ring_labelled(self, search):
        output = format_recruiting_near(
            self._make_rings(search), "diabetes", "Bangalore, India"
        )
        assert "In Bangalore" in output

    def test_location_note_footer_present(self, search):
        # The city-level location disclaimer is required by the masterplan
        output = format_recruiting_near(
            self._make_rings(search), "diabetes", "Bangalore, India"
        )
        assert "Location note" in output or "city" in output.lower()

    def test_no_gps_disclaimer_present(self, search):
        output = format_recruiting_near(
            self._make_rings(search), "diabetes", "Bangalore, India"
        )
        assert "GPS" in output or "radius" in output.lower()

    def test_no_results_returns_helpful_message(self):
        output = format_recruiting_near({}, "diabetes", "Nowhere")
        assert "No recruiting trials" in output

    def test_no_results_gives_search_suggestions(self):
        output = format_recruiting_near({}, "diabetes", "Nowhere")
        # Must give the user actionable next steps, not just "nothing found"
        assert "Try" in output or "Broaden" in output or "broader" in output.lower()


# ── Server input validation tests ─────────────────────────────────────────────

class TestServerValidation:
    """Tests for server-layer input validation in server.py.

    These tests call call_tool() directly. The validation cases (wrong
    number of IDs, unknown tool name) return before hitting the API,
    so no network calls happen.
    """

    def test_compare_trials_requires_at_least_2_ids(self):
        result = asyncio.run(
            call_tool("compare_trials", {"nct_ids": ["NCT02142803"]})
        )
        assert "at least 2" in result[0].text

    def test_compare_trials_rejects_more_than_5_ids(self):
        six_ids = [f"NCT0000000{i}" for i in range(6)]
        result = asyncio.run(
            call_tool("compare_trials", {"nct_ids": six_ids})
        )
        assert "maximum of 5" in result[0].text

    def test_unknown_tool_returns_error_not_exception(self):
        result = asyncio.run(call_tool("nonexistent_tool", {}))
        assert "Unknown tool" in result[0].text
        assert result[0].type == "text"

    def test_all_responses_are_text_content(self):
        result = asyncio.run(call_tool("nonexistent_tool", {}))
        assert len(result) == 1
        assert result[0].type == "text"
        assert isinstance(result[0].text, str)
