# Disclaimer & Limitations

clinicaltrials-mcp is a query and retrieval tool that provides
conversational access to publicly available data from
ClinicalTrials.gov. Built and maintained by agents100x.

## What This Tool Is

A free, open-source interface for querying the ClinicalTrials.gov
public API. It makes clinical trial data more accessible and
readable. Nothing more.

## What This Tool Is Not

- Not a medical advisor or clinical decision support system
- Not a replacement for professional regulatory, clinical,
  or scientific judgment
- Not a real-time monitoring or alerting system
- Not a verified or curated data source

## Data Source

All data is sourced from ClinicalTrials.gov, maintained by the
U.S. National Library of Medicine. Data is self-reported by
trial sponsors and is not independently verified by agents100x.

## Known Data Limitations

- Not all trials in the world are registered on CT.gov
- ~60% of completed trials have no posted results
- Trial status and site data may lag real-world updates by weeks
- Eligibility criteria are free text and may be ambiguous
- Overall trial status (RECRUITING) does not guarantee that every
  listed site is actively recruiting — individual site status can
  differ. Always verify the specific site's status at clinicaltrials.gov
  before contacting a site or assuming patient enrolment is open

## Regulatory Use

Data returned by this tool should NEVER be used directly in
regulatory submissions, publications, or clinical decisions
without independent verification at clinicaltrials.gov.

## Adverse Events

By default, only serious adverse events are shown. This is
not a complete safety profile. Always consult the full results
on ClinicalTrials.gov and the relevant publications.

## Accuracy

agents100x makes no warranty about the accuracy, completeness,
or timeliness of any data returned by this tool.

---

agents100x · agents100x.com · agents100x@gmail.com
