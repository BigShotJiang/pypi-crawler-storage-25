"""Pytest configuration and shared fixtures."""

import os
import shlex
import sys
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import TYPE_CHECKING, Protocol
from unittest.mock import MagicMock

import pytest
from loguru import logger

from pimp_my_repo.core.tools.boost_tools import BoostTools
from pimp_my_repo.core.tools.repo import RepositoryController
from pimp_my_repo.core.tools.subprocess import run_command


@pytest.fixture(scope="session", autouse=True)
def configure_logging() -> None:
    logger.remove()
    logger.add(
        sys.stderr,
        format=(
            "[<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green>] [<blue>{level.name:.4}</blue>]"
            " <bold>{message}</bold> [<dim>{name}</dim>] [<dim>{file}:{line}</dim>]"
        ),
        level="DEBUG",
        colorize=True,
    )
    logger.debug("Logging configured for tests")


if TYPE_CHECKING:
    from collections.abc import Generator


def pytest_addoption(parser: pytest.Parser) -> None:
    parser.addoption("--e2e-url", default=None, help="Git URL for remote e2e test")
    parser.addoption("--e2e-rev", default=None, help="Git revision for remote e2e test")
    parser.addoption("--fixture-name", default=None, help="Fixture name for manual local e2e test")


@pytest.fixture
def e2e_url(request: pytest.FixtureRequest) -> str:
    url = request.config.getoption("--e2e-url")
    if url is None:
        pytest.skip("--e2e-url not provided")
    return str(url)


@pytest.fixture
def e2e_rev(request: pytest.FixtureRequest) -> str | None:
    rev = request.config.getoption("--e2e-rev")
    return str(rev) or None


@pytest.fixture
def e2e_pmr_args() -> list[str]:
    return shlex.split(os.environ.get("PMR_ARGS", ""))


@pytest.fixture
def fixture_name_arg(request: pytest.FixtureRequest) -> str:
    name = request.config.getoption("--fixture-name")
    if name is None:
        pytest.skip("--fixture-name not provided")
    return str(name)


@pytest.fixture
def mock_repo() -> Generator[RepositoryController]:
    """Create a temporary directory with an initialized git repository."""
    tmp_dir = TemporaryDirectory()
    tmp_path = Path(tmp_dir.name)

    run_command(["git", "init"], cwd=tmp_path)
    run_command(["git", "config", "user.email", "test@example.com"], cwd=tmp_path)
    run_command(["git", "config", "user.name", "Test User"], cwd=tmp_path)
    repo = RepositoryController(tmp_path)
    repo.add_and_commit(relative_path="README.md", content="# Test", message="Initial commit")
    yield repo
    tmp_dir.cleanup()


class SubprocessResultFactory(Protocol):
    """Callable that builds a MagicMock simulating a subprocess result."""

    def __call__(self, output: str = "") -> MagicMock: ...


def _make_result(*, returncode: int, output: str) -> MagicMock:
    r = MagicMock()
    r.returncode = returncode
    r.stdout = output
    r.stderr = ""
    return r


@pytest.fixture
def ok_result() -> SubprocessResultFactory:
    """Build a MagicMock simulating a successful subprocess result."""

    def _factory(output: str = "") -> MagicMock:
        return _make_result(returncode=0, output=output)

    return _factory


@pytest.fixture
def fail_result() -> SubprocessResultFactory:
    """Build a MagicMock simulating a failed subprocess result."""

    def _factory(output: str = "") -> MagicMock:
        return _make_result(returncode=1, output=output)

    return _factory


@pytest.fixture
def git_controller(mock_repo: RepositoryController) -> RepositoryController:
    return RepositoryController(path=mock_repo.path)


@pytest.fixture
def repo_controller(mock_repo: RepositoryController) -> RepositoryController:
    """Alias for mock_repo, used by boost fixtures that need a RepositoryController."""
    return mock_repo


@pytest.fixture
def boost_tools(mock_repo: RepositoryController) -> BoostTools:
    return BoostTools.create(repo_path=mock_repo.path)
