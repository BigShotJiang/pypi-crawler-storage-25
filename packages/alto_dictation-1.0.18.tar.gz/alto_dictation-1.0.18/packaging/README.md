# Alto Packaging

Packaging configurations for distributing Alto.

## Supported Formats

- **PyPI**: `pip install alto-dictation`
- **Debian/Ubuntu**: `.deb` package
- **Fedora/RHEL**: `.rpm` package
- **Arch Linux**: `PKGBUILD` for AUR

## Recommended Installation

```bash
curl -fsSL https://alto-dictation.com/install.sh | bash
```

## License

Proprietary. See LICENSE in the repository root.
