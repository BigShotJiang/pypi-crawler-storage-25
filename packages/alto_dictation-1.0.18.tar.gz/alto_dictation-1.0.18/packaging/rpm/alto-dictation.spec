Name:           alto-dictation
Version:        1.0.5
Release:        1%{?dist}
Summary:        System-wide push-to-talk speech-to-text service for Linux

License:        Proprietary
URL:            https://alto-dictation.com
Source0:        alto-dictation-%{version}.tar.gz

BuildArch:      noarch
BuildRequires:  python3-devel >= 3.11
BuildRequires:  python3-setuptools
BuildRequires:  python3-pip
BuildRequires:  python3-wheel

Requires:       python3 >= 3.11
Requires:       ydotool
Requires:       portaudio-devel
Requires:       python3-devel
Requires:       libappindicator-gtk3
Requires:       python3-mistralai >= 1.0.0
Requires:       python3-sounddevice >= 0.4.6
Requires:       python3-numpy >= 1.24.0
Requires:       python3-evdev >= 1.7.0
Requires:       python3-pystray >= 0.19.5
Requires:       python3-pillow >= 10.0.0

%description
Alto is a lightweight background daemon that enables voice dictation in any
Linux application. It uses a simple push-to-talk workflow: hold a dedicated
key, speak, release, and the transcribed text is automatically typed at your
cursor position.

Features:
- Universal dictation in any application
- Push-to-talk workflow (no wake words)
- Compatible with X11 and Wayland
- Powered by Mistral AI
- System tray indicator
- Lightweight and configurable

%prep
%autosetup -n Alto-%{version}

%build
%py3_build

%install
%py3_install

# Install systemd user service template
install -D -m 0644 alto.service.template %{buildroot}%{_datadir}/alto/alto.service.template

# Install config template
install -D -m 0644 config.json %{buildroot}%{_sysconfdir}/alto/config.json

# Install icons
mkdir -p %{buildroot}%{_datadir}/alto/icons
install -D -m 0644 icons/*.png %{buildroot}%{_datadir}/alto/icons/

%post
# Add user to input group for keyboard access
if ! groups | grep -q input; then
    echo "Adding user to input group..."
    usermod -a -G input $SUDO_USER 2>/dev/null || true
    echo "Please log out and log back in for input group to take effect."
fi

# Enable and start ydotool service
if systemctl is-enabled ydotool.service >/dev/null 2>&1; then
    systemctl enable ydotool.service || true
    systemctl start ydotool.service || true
fi

echo ""
echo "Alto has been installed successfully!"
echo ""
echo "Next steps:"
echo "  1. Set your MISTRAL_API_KEY environment variable"
echo "  2. Configure your push-to-talk key in /etc/alto/config.json"
echo "  3. Run 'alto --detect-key' to find your preferred key"
echo "  4. Start Alto with 'alto' or install the systemd service"
echo ""

%files
%license LICENSE
%doc README.md
%{python3_sitelib}/alto/
%{python3_sitelib}/alto_dictation-*.egg-info/
%{_bindir}/alto
%{_datadir}/alto/
%config(noreplace) %{_sysconfdir}/alto/config.json

%changelog
* Sat Feb 08 2026 Michael Nedjam <contact@chink.fr> - 0.1.0-1
- Initial release
- Push-to-talk speech-to-text daemon for Linux
- Support for X11 and Wayland
- Mistral AI integration for transcription
- System tray indicator
- Configurable hotkey and language settings
