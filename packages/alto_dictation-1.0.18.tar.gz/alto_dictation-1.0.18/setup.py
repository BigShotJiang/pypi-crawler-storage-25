"""
setup.py for Alto

This is a minimal setup.py that redirects to pyproject.toml.
Modern Python packaging uses pyproject.toml exclusively, but this file
is provided for backward compatibility with older tools.
"""

from setuptools import setup

# All configuration is in pyproject.toml
setup()
