"""
Speech-to-text transcription module.

Transcription via the Alto backend API (cloud).
"""

import logging
import time
from pathlib import Path
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from alto.api_client import AltoAPIClient

logger = logging.getLogger(__name__)

# API error retry configuration
MAX_RETRIES = 3
RETRY_DELAY_SECONDS = 0.5  # Initial delay for transient errors
RETRY_BACKOFF_MULTIPLIER = 2.0


class Transcriber:
    """Handles speech-to-text transcription via the Alto backend API.

    Args:
        api_client: AltoAPIClient instance.
        language: Language code for transcription.
    """

    def __init__(
        self,
        api_client: "AltoAPIClient",
        language: str = "fr",
    ):
        self.language = language
        self._api_client = api_client
        logger.debug("Transcriber initialized")

        # Performance tracking
        self._total_requests = 0
        self._total_latency = 0.0
        self._fastest_request = float('inf')
        self._slowest_request = 0.0

    def transcribe(self, audio_path: Path) -> Optional[str]:
        """Transcribe an audio file to text with automatic retry on failure.

        Args:
            audio_path: Path to the WAV audio file to transcribe.

        Returns:
            Transcribed text, or None if transcription failed after all retries.
        """
        if not audio_path.exists():
            logger.error(f"Audio file not found: {audio_path}")
            return None

        if not audio_path.is_file():
            logger.error(f"Path is not a file: {audio_path}")
            return None

        logger.info(f"Starting transcription of {audio_path}")
        start_time = time.time()

        try:
            return self._transcribe(audio_path, start_time)
        finally:
            # Always clean up temporary file
            try:
                if audio_path.exists():
                    audio_path.unlink()
                    logger.debug(f"Deleted temporary audio file: {audio_path}")
            except Exception as e:
                logger.warning(
                    f"Failed to delete temporary audio file {audio_path}: {e}"
                )

    def _transcribe(self, audio_path: Path, start_time: float) -> Optional[str]:
        """Transcribe via the Alto backend API."""
        from alto.api_client import UsageLimitError

        last_error = None
        for attempt in range(1, MAX_RETRIES + 1):
            try:
                text = self._api_client.transcribe(audio_path, self.language)

                if text is not None:
                    latency = time.time() - start_time
                    self._update_performance_metrics(latency)
                    if attempt > 1:
                        logger.info(f"Transcription succeeded on attempt {attempt} after {latency:.2f}s: '{text}'")
                    else:
                        logger.info(f"Transcription completed in {latency:.2f}s: '{text}' (avg: {self.get_average_latency():.2f}s)")
                    return text

                last_error = Exception("Empty transcription result")

            except UsageLimitError:
                raise  # Don't retry usage limit errors
            except Exception as e:
                last_error = e
                if attempt < MAX_RETRIES:
                    delay = RETRY_DELAY_SECONDS * (RETRY_BACKOFF_MULTIPLIER ** (attempt - 1))
                    logger.warning(f"Transcription attempt {attempt}/{MAX_RETRIES} failed: {e}. Retrying in {delay:.1f}s...")
                    time.sleep(delay)
                else:
                    logger.error(f"Transcription failed after {attempt} attempts: {e}")

        return None

    def _update_performance_metrics(self, latency: float) -> None:
        self._total_requests += 1
        self._total_latency += latency
        self._fastest_request = min(self._fastest_request, latency)
        self._slowest_request = max(self._slowest_request, latency)

    def get_average_latency(self) -> float:
        if self._total_requests == 0:
            return 0.0
        return self._total_latency / self._total_requests

    def get_performance_stats(self) -> dict:
        return {
            "total_requests": self._total_requests,
            "average_latency_s": self.get_average_latency(),
            "fastest_request_s": self._fastest_request if self._total_requests > 0 else 0.0,
            "slowest_request_s": self._slowest_request if self._total_requests > 0 else 0.0,
        }
