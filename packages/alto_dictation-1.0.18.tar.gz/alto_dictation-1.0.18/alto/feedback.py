"""
User feedback and telemetry module for Alto service.

This module provides functionality for:
- Opening feedback/issue reporting URLs
- Collecting anonymized usage data (opt-in only)
- Logging telemetry events
"""

import hashlib
import json
import logging
import platform
import webbrowser
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional

logger = logging.getLogger(__name__)


class FeedbackManager:
    """Manages user feedback and telemetry collection.

    Provides methods to:
    - Open issue reporting URLs in the browser
    - Collect anonymized usage statistics (opt-in)
    - Log telemetry events to a local file

    Args:
        feedback_url: URL to the issue tracker or feedback form
        enable_telemetry: Whether to collect anonymized usage data (opt-in)
        telemetry_file: Optional path to telemetry log file
    """

    def __init__(
        self,
        feedback_url: str,
        enable_telemetry: bool = False,
        telemetry_file: Optional[Path] = None,
    ):
        """Initialize the feedback manager.

        Args:
            feedback_url: URL to the issue tracker or feedback form
            enable_telemetry: Whether to collect anonymized usage data (opt-in)
            telemetry_file: Optional path to telemetry log file (defaults to ~/.alto/telemetry.jsonl)
        """
        self.feedback_url = feedback_url
        self.enable_telemetry = enable_telemetry

        # Set telemetry file location
        if telemetry_file is None:
            home_dir = Path.home()
            alto_dir = home_dir / ".alto"
            alto_dir.mkdir(parents=True, exist_ok=True)
            self.telemetry_file = alto_dir / "telemetry.jsonl"
        else:
            self.telemetry_file = telemetry_file

        # Generate anonymized session ID
        self.session_id = self._generate_session_id()

        logger.info(
            f"FeedbackManager initialized (telemetry: {enable_telemetry}, "
            f"session_id: {self.session_id[:8]}...)"
        )

    def open_feedback_url(self) -> bool:
        """Open the feedback/issue reporting URL in the default browser.

        Returns:
            True if the URL was opened successfully, False otherwise
        """
        try:
            logger.info(f"Opening feedback URL: {self.feedback_url}")
            webbrowser.open(self.feedback_url)
            return True
        except Exception as e:
            logger.error(f"Failed to open feedback URL: {e}", exc_info=True)
            return False

    def log_event(
        self,
        event_type: str,
        event_data: Optional[Dict] = None,
        include_system_info: bool = False,
    ) -> None:
        """Log a telemetry event (only if telemetry is enabled).

        Events are logged to a JSONL file with anonymized data.
        No personally identifiable information is collected.

        Args:
            event_type: Type of event (e.g., "startup", "recording", "transcription")
            event_data: Optional dictionary with event-specific data
            include_system_info: Whether to include system information
        """
        if not self.enable_telemetry:
            return

        try:
            event = {
                "timestamp": datetime.utcnow().isoformat(),
                "session_id": self.session_id,
                "event_type": event_type,
            }

            # Add event-specific data
            if event_data:
                # Filter out any potentially sensitive data
                safe_data = self._anonymize_data(event_data)
                event["data"] = safe_data

            # Add system information if requested
            if include_system_info:
                event["system"] = self._get_system_info()

            # Write to JSONL file
            with open(self.telemetry_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(event) + "\n")

            logger.debug(f"Logged telemetry event: {event_type}")

        except Exception as e:
            logger.error(f"Failed to log telemetry event: {e}", exc_info=True)

    def _generate_session_id(self) -> str:
        """Generate an anonymized session ID.

        Uses a hash of the current time and machine ID to create a unique
        but anonymized session identifier.

        Returns:
            Anonymized session ID string
        """
        # Create a unique session ID based on timestamp and machine
        timestamp = datetime.utcnow().isoformat()
        machine_id = platform.node()  # Hostname
        session_data = f"{timestamp}_{machine_id}"

        # Hash it to anonymize
        session_hash = hashlib.sha256(session_data.encode()).hexdigest()

        return session_hash

    def _get_system_info(self) -> Dict:
        """Get anonymized system information.

        Returns:
            Dictionary with anonymized system information
        """
        return {
            "platform": platform.system(),
            "platform_version": platform.release(),
            "python_version": platform.python_version(),
            "architecture": platform.machine(),
        }

    def _anonymize_data(self, data: Dict) -> Dict:
        """Remove or anonymize potentially sensitive data.

        Args:
            data: Dictionary with event data

        Returns:
            Dictionary with anonymized data
        """
        # List of keys to exclude (potentially sensitive)
        sensitive_keys = {
            "api_key",
            "token",
            "password",
            "secret",
            "username",
            "email",
            "user",
            "path",
            "file",
            "dir",
            "directory",
        }

        # Create a copy and filter out sensitive keys
        safe_data = {}
        for key, value in data.items():
            # Skip sensitive keys
            if any(sensitive in key.lower() for sensitive in sensitive_keys):
                continue

            # Include safe data
            safe_data[key] = value

        return safe_data

    def get_telemetry_stats(self) -> Dict:
        """Get telemetry statistics from the log file.

        Returns:
            Dictionary with telemetry statistics
        """
        if not self.enable_telemetry or not self.telemetry_file.exists():
            return {"enabled": False, "event_count": 0}

        try:
            event_count = 0
            event_types = {}

            with open(self.telemetry_file, "r", encoding="utf-8") as f:
                for line in f:
                    event = json.loads(line)
                    event_count += 1
                    event_type = event.get("event_type", "unknown")
                    event_types[event_type] = event_types.get(event_type, 0) + 1

            return {
                "enabled": True,
                "event_count": event_count,
                "event_types": event_types,
                "telemetry_file": str(self.telemetry_file),
            }

        except Exception as e:
            logger.error(f"Failed to get telemetry stats: {e}", exc_info=True)
            return {"enabled": True, "event_count": 0, "error": str(e)}
