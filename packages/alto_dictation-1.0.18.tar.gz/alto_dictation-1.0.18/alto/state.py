"""
State machine for Alto service state management.
"""

import logging
from enum import Enum, auto
from threading import Lock
from typing import Callable, Optional, Set

logger = logging.getLogger(__name__)


class State(Enum):
    """All possible states for the Alto service."""

    READY = auto()
    RECORDING = auto()
    TRANSCRIBING = auto()
    TYPING = auto()
    ERROR = auto()


class StateMachine:
    """Thread-safe state machine for managing Alto service state transitions.

    The state machine enforces valid state transitions and provides callback
    mechanisms for state changes. It also handles error states with automatic
    recovery to READY state.

    Valid transitions:
        READY -> RECORDING
        RECORDING -> TRANSCRIBING
        RECORDING -> READY (cancel)
        RECORDING -> ERROR (hardware failure)
        TRANSCRIBING -> TYPING
        TRANSCRIBING -> ERROR
        TYPING -> READY
        TYPING -> ERROR
        ERROR -> READY (automatic recovery)

    Args:
        initial_state: The initial state. Defaults to State.READY.
    """

    # Define valid state transitions
    _VALID_TRANSITIONS: dict[State, Set[State]] = {
        State.READY: {State.RECORDING, State.ERROR},
        State.RECORDING: {State.TRANSCRIBING, State.READY, State.ERROR},
        State.TRANSCRIBING: {State.TYPING, State.ERROR},
        State.TYPING: {State.READY, State.ERROR},
        State.ERROR: {State.READY},
    }

    def __init__(self, initial_state: State = State.READY):
        """Initialize the state machine.

        Args:
            initial_state: The initial state. Defaults to State.READY.
        """
        self._state = initial_state
        self._lock = Lock()
        self._callbacks: list[Callable[[State, State], None]] = []
        self._error_context: Optional[str] = None  # Track last error context

        logger.info(f"State machine initialized in {initial_state.name} state")

    @property
    def state(self) -> State:
        """Get the current state.

        Returns:
            The current state.
        """
        with self._lock:
            return self._state

    def transition(self, new_state: State, error_context: Optional[str] = None) -> bool:
        """Transition to a new state if valid.

        Args:
            new_state: The target state to transition to.
            error_context: Optional error context if transitioning to ERROR state.

        Returns:
            True if transition was successful, False otherwise.

        Raises:
            ValueError: If the transition is not allowed.
        """
        with self._lock:
            old_state = self._state

            # Check if transition is valid
            if new_state not in self._VALID_TRANSITIONS.get(old_state, set()):
                raise ValueError(
                    f"Invalid transition from {old_state.name} to {new_state.name}. "
                    f"Valid transitions from {old_state.name}: "
                    f"{', '.join(s.name for s in self._VALID_TRANSITIONS.get(old_state, set()))}"
                )

            # Perform transition
            self._state = new_state

            # Store error context if transitioning to ERROR
            if new_state == State.ERROR:
                self._error_context = error_context or "Unknown error"
                logger.warning(
                    f"Entered ERROR state from {old_state.name}: {self._error_context}. "
                    "Will auto-recover to READY"
                )
                logger.info(f"State transition: {old_state.name} -> {new_state.name}")
            else:
                # Clear error context when leaving ERROR state
                if old_state == State.ERROR:
                    logger.info(f"State transition: {old_state.name} -> {new_state.name} (recovered)")
                    self._error_context = None
                else:
                    logger.info(f"State transition: {old_state.name} -> {new_state.name}")

        # Call callbacks outside of lock to avoid deadlock
        self._notify_callbacks(old_state, new_state)

        return True

    def recover_from_error(self) -> bool:
        """Recover from ERROR state to READY state.

        This is typically called automatically, but can be called manually
        if needed.

        Returns:
            True if recovery was successful, False if not in ERROR state.
        """
        with self._lock:
            if self._state != State.ERROR:
                logger.warning(
                    f"Cannot recover from non-ERROR state {self._state.name}"
                )
                return False

            old_state = self._state
            error_ctx = self._error_context
            self._state = State.READY
            self._error_context = None

            if error_ctx:
                logger.info(f"Recovered from ERROR to READY (previous error: {error_ctx})")
            else:
                logger.info(f"Recovered from ERROR to READY")

        # Call callbacks outside of lock
        self._notify_callbacks(old_state, State.READY)

        return True

    def get_error_context(self) -> Optional[str]:
        """Get the error context from the last ERROR state.

        Returns:
            Error context string, or None if not in ERROR state or no context available.
        """
        with self._lock:
            return self._error_context

    def register_callback(
        self, callback: Callable[[State, State], None]
    ) -> None:
        """Register a callback to be called on state transitions.

        The callback will be called with (old_state, new_state) as arguments.

        Args:
            callback: Function to call on state transitions. Should accept
                     two State arguments (old_state, new_state).
        """
        with self._lock:
            if callback not in self._callbacks:
                self._callbacks.append(callback)
                logger.debug(f"Registered state transition callback: {callback.__name__}")

    def unregister_callback(
        self, callback: Callable[[State, State], None]
    ) -> bool:
        """Unregister a previously registered callback.

        Args:
            callback: The callback function to unregister.

        Returns:
            True if callback was found and removed, False otherwise.
        """
        with self._lock:
            try:
                self._callbacks.remove(callback)
                logger.debug(f"Unregistered state transition callback: {callback.__name__}")
                return True
            except ValueError:
                logger.warning(
                    f"Callback {callback.__name__} not found in registered callbacks"
                )
                return False

    def _notify_callbacks(self, old_state: State, new_state: State) -> None:
        """Notify all registered callbacks of a state transition.

        Args:
            old_state: The previous state.
            new_state: The new current state.
        """
        # Make a copy of callbacks to avoid issues if callbacks modify the list
        callbacks_copy = self._callbacks.copy()

        for callback in callbacks_copy:
            try:
                callback(old_state, new_state)
            except Exception as e:
                logger.error(
                    f"Error in state transition callback {callback.__name__}: {e}",
                    exc_info=True
                )

    def can_transition(self, target_state: State) -> bool:
        """Check if a transition to the target state is valid.

        Args:
            target_state: The state to check transition validity for.

        Returns:
            True if transition is valid, False otherwise.
        """
        with self._lock:
            return target_state in self._VALID_TRANSITIONS.get(self._state, set())

    def reset(self) -> None:
        """Reset the state machine to READY state.

        This bypasses normal transition validation and should only be used
        for initialization or emergency recovery.
        """
        with self._lock:
            old_state = self._state
            self._state = State.READY
            logger.warning(f"State machine reset from {old_state.name} to READY")

        # Call callbacks outside of lock
        self._notify_callbacks(old_state, State.READY)
