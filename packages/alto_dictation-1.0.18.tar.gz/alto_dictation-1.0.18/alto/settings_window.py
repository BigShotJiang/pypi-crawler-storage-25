"""
Settings window for Alto — native window with web UI via pywebview.

The webview runs in a subprocess because GTK webview requires the main
thread, which is occupied by pystray + hotkey listener in the daemon.
"""

import json
import logging
import subprocess
import sys
import threading
from pathlib import Path
from typing import TYPE_CHECKING, Callable, Optional

from alto.config import ServiceConfig, save_config

if TYPE_CHECKING:
    from alto.api_client import AltoAPIClient
    from alto.platforms.linux.hotkey import HotkeyListener

logger = logging.getLogger(__name__)

LANGUAGES = {
    "fr": "Francais",
    "en": "English",
    "es": "Espanol",
    "de": "Deutsch",
    "it": "Italiano",
    "pt": "Portugues",
    "nl": "Nederlands",
    "pl": "Polski",
    "ru": "Russian",
    "ja": "Japanese",
    "zh": "Chinese",
    "ko": "Korean",
    "ar": "Arabic",
}

_SETTINGS_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Alto</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, sans-serif;
         background: #fff; color: #1a1a1a; display: flex; flex-direction: column; height: 100vh;
         -webkit-user-select: none; user-select: none; overflow: hidden; }

  /* Layout */
  .topbar { padding: 18px 24px 14px; border-bottom: 1px solid #f0f0f0; }
  .topbar h1 { font-size: 17px; font-weight: 600; }
  .layout { display: flex; flex: 1; overflow: hidden; }
  .sidebar { width: 140px; background: #fafafa; border-right: 1px solid #f0f0f0; padding: 12px 0; flex-shrink: 0; }
  .sidebar-item { display: block; padding: 8px 20px; font-size: 13px; color: #666; cursor: pointer;
                  border: none; background: none; width: 100%; text-align: left; font-family: inherit;
                  transition: all 0.1s; }
  .sidebar-item:hover { color: #1a1a1a; background: #f0f0f0; }
  .sidebar-item.active { color: #1a1a1a; font-weight: 600; background: #fff; }
  .content { flex: 1; padding: 20px 24px; overflow-y: auto; }
  .section-content { display: none; }
  .section-content.active { display: block; }

  /* Shared */
  .section { margin-bottom: 20px; }
  .section-label { font-size: 12px; font-weight: 500; color: #666; margin-bottom: 8px; }
  .sep { height: 1px; background: #f0f0f0; margin: 16px 0; }

  /* Account */
  .account { display: flex; align-items: center; justify-content: space-between; }
  .account-left { display: flex; flex-direction: column; gap: 2px; }
  .account-email { font-size: 14px; font-weight: 500; color: #1a1a1a; }
  .account-meta { font-size: 12px; color: #666; }
  .tier-badge { display: inline-block; font-size: 11px; font-weight: 600; color: #fff;
                background: #1a1a1a; padding: 2px 8px; border-radius: 10px; margin-left: 6px; }
  .tier-badge.free { background: #888; }
  .tier-badge.pro { background: #2563eb; }
  .tier-badge.max { background: #7c3aed; }

  /* Subscription summary */
  .sub-summary { background: #fafafa; border: 1px solid #e8e8e8; border-radius: 10px;
                 padding: 16px; margin-bottom: 16px; }
  .sub-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px; }
  .sub-status { font-size: 12px; }

  /* Usage bar */
  .usage { margin-top: 10px; }
  .bar { height: 4px; background: #f0f0f0; border-radius: 2px; overflow: hidden; }
  .bar-fill { height: 100%; background: #1a1a1a; border-radius: 2px; transition: width 0.3s; min-width: 2px; }
  .bar-fill.warn { background: #f59e0b; }
  .bar-fill.crit { background: #ef4444; }

  /* Plan cards */
  .plans { display: flex; gap: 10px; margin-top: 8px; }
  .plan-card { flex: 1; border: 1px solid #e8e8e8; border-radius: 10px; padding: 16px;
               position: relative; background: #fafafa; transition: border-color 0.15s; }
  .plan-card.current { border-color: #1a1a1a; background: #f8f8f8; border-width: 2px; }
  .plan-card.featured { border-color: #2563eb; background: #fafbff; }
  .plan-badge { position: absolute; top: -8px; right: 12px;
                color: #fff; font-size: 9px; font-weight: 600; padding: 2px 8px;
                border-radius: 8px; text-transform: uppercase; letter-spacing: 0.5px; }
  .plan-badge.current-badge { background: #1a1a1a; }
  .plan-badge.popular-badge { background: #2563eb; }
  .plan-name { font-size: 14px; font-weight: 600; color: #1a1a1a; }
  .plan-price { font-size: 24px; font-weight: 700; color: #1a1a1a; margin: 6px 0 2px; }
  .plan-price span { font-size: 12px; font-weight: 400; color: #888; }
  .plan-quota { font-size: 12px; color: #666; margin-bottom: 12px; }
  .plan-btn { display: block; text-align: center; padding: 8px; border-radius: 6px;
              font-size: 12px; font-weight: 500; text-decoration: none; transition: all 0.15s; cursor: pointer; }
  .plan-btn-primary { background: #1a1a1a; color: #fff; border: none; }
  .plan-btn-primary:hover { background: #333; }
  .plan-btn-secondary { background: #fff; color: #1a1a1a; border: 1px solid #ddd; }
  .plan-btn-secondary:hover { border-color: #1a1a1a; }
  .plan-btn-disabled { background: #f0f0f0; color: #999; border: none; cursor: default; }
  .plan-current-label { text-align: center; font-size: 12px; color: #1a1a1a; font-weight: 500; padding: 8px; }

  /* Form fields */
  select { width: 100%; padding: 10px 14px; font-size: 14px; font-family: inherit;
           background: #fafafa; border: 1px solid #e8e8e8; border-radius: 8px;
           color: #1a1a1a; outline: none; transition: border-color 0.15s;
           appearance: none; -webkit-appearance: none;
           background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%23999' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E");
           background-repeat: no-repeat; background-position: right 12px center; }
  select:focus { border-color: #1a1a1a; background-color: #fff; }

  /* Key */
  .key-row { display: flex; gap: 8px; align-items: center; }
  .key-display { flex: 1; padding: 10px 14px; font-size: 14px; font-weight: 500;
                 background: #fafafa; border: 1px solid #e8e8e8; border-radius: 8px;
                 color: #1a1a1a; display: flex; align-items: center; }
  .key-badge { display: inline-block; background: #f0f0f0; padding: 3px 10px;
               border-radius: 4px; font-size: 13px; font-weight: 600; font-family: "SF Mono", monospace; }
  .detect-btn { padding: 10px 16px; font-size: 13px; font-family: inherit; font-weight: 500;
                background: #fafafa; border: 1px solid #e8e8e8;
                border-radius: 8px; color: #1a1a1a; cursor: pointer; white-space: nowrap;
                transition: all 0.15s; }
  .detect-btn:hover { background: #f0f0f0; border-color: #ccc; }
  .detect-btn.detecting { background: #fef3c7; color: #92400e; border-color: #fcd34d; }
  .hint { font-size: 12px; color: #888; margin-top: 6px; }

  /* Actions */
  .actions { display: flex; align-items: center; gap: 8px; padding: 12px 24px;
             border-top: 1px solid #f0f0f0; }
  .pause-notice { font-size: 11px; color: #999; margin-right: auto; }
  .btn { padding: 9px 22px; font-size: 14px; font-family: inherit; border-radius: 8px;
         border: none; cursor: pointer; font-weight: 500; transition: all 0.15s; }
  .btn-cancel { background: transparent; color: #666; }
  .btn-cancel:hover { color: #1a1a1a; }
  .btn-save { background: #1a1a1a; color: #fff; }
  .btn-save:hover { background: #333; }

  .not-connected { color: #999; font-size: 13px; }

  /* Billing table */
  .billing-table { width: 100%; border-collapse: collapse; font-size: 13px; }
  .billing-table th { text-align: left; padding: 8px 6px; color: #888; font-weight: 500;
                      font-size: 11px; text-transform: uppercase; letter-spacing: 0.3px;
                      border-bottom: 1px solid #e8e8e8; }
  .billing-table td { padding: 8px 6px; border-bottom: 1px solid #f0f0f0; color: #444; }
  .billing-table tr:last-child td { border-bottom: none; }
  .status-paid { color: #16a34a; font-weight: 500; }
  .status-refunded { color: #ea580c; font-weight: 500; }
  .status-disputed { color: #dc2626; font-weight: 500; }
  .billing-empty { color: #999; font-size: 13px; padding: 20px 0; }
  .invoice-link { display: inline-block; margin-top: 16px; font-size: 12px; color: #2563eb;
                  text-decoration: none; }
  .invoice-link:hover { text-decoration: underline; }

  /* Help */
  .help-colors { display: flex; flex-direction: column; gap: 10px; }
  .help-row { display: flex; align-items: center; gap: 10px; font-size: 13px; color: #444; }
  .help-dot { width: 12px; height: 12px; border-radius: 50%; flex-shrink: 0; border: 1px solid rgba(0,0,0,0.1); }
  .help-text { font-size: 13px; color: #444; line-height: 1.5; }

  /* Modal */
  .modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.3);
                   z-index: 100; align-items: center; justify-content: center; }
  .modal-overlay.visible { display: flex; }
  .modal { background: #fff; border-radius: 12px; padding: 24px; width: 320px;
           box-shadow: 0 8px 30px rgba(0,0,0,0.12); }
  .modal h3 { font-size: 15px; font-weight: 600; margin-bottom: 8px; }
  .modal p { font-size: 13px; color: #666; line-height: 1.5; margin-bottom: 18px; }
  .modal-actions { display: flex; gap: 8px; justify-content: flex-end; }
  .modal-btn { padding: 8px 18px; border-radius: 8px; font-size: 13px; font-family: inherit;
               font-weight: 500; cursor: pointer; border: none; transition: all 0.15s; }
  .modal-btn-cancel { background: #f0f0f0; color: #666; }
  .modal-btn-cancel:hover { background: #e0e0e0; color: #1a1a1a; }
  .modal-btn-confirm { background: #ef4444; color: #fff; }
  .modal-btn-confirm:hover { background: #dc2626; }
</style>
</head>
<body>

<div class="topbar"><h1>Settings</h1></div>

<div class="layout">
  <div class="sidebar">
    <button class="sidebar-item active" data-section="general" onclick="showSection('general')">General</button>
    <button class="sidebar-item" data-section="subscription" onclick="showSection('subscription')">Subscription</button>
    <button class="sidebar-item" data-section="billing" onclick="showSection('billing')">Billing</button>
    <button class="sidebar-item" data-section="help" onclick="showSection('help')">Help</button>
    <button class="sidebar-item" data-section="contact" onclick="showSection('contact')">Contact</button>
  </div>

  <div class="content">
    <!-- General -->
    <div class="section-content active" id="section-general">
      <div id="account-card" style="display:{account_display}">
        <div class="section-label">Account</div>
        <div id="account-content">{account_html}</div>
        <a href="#" onclick="resetPassword(); return false" style="font-size:12px;color:#666;text-decoration:none;display:inline-block;margin-top:8px">Reset password</a>
        <div class="sep"></div>
      </div>

      <div class="section">
        <div class="section-label">Transcription language</div>
        <select id="language">{language_options}</select>
      </div>

      <div class="section">
        <div class="section-label">Push-to-talk</div>
        <div class="key-row">
          <div class="key-display"><span class="key-badge" id="key-display">{current_key}</span></div>
          <button class="detect-btn" id="detect-btn" onclick="detectKey()">Change</button>
        </div>
        <div class="hint">Press Change, then hit your desired key or combo</div>
      </div>
    </div>

    <!-- Subscription -->
    <div class="section-content" id="section-subscription">
      <div class="section-label">Choose your plan</div>
      {subscription_html}
    </div>

    <!-- Billing -->
    <div class="section-content" id="section-billing">
      <div class="section-label">Payment history</div>
      {billing_html}
    </div>

    <!-- Help -->
    <div class="section-content" id="section-help">
      <div class="section-label">Tray icon colors</div>
      <div class="help-colors">
        <div class="help-row"><span class="help-dot" style="background:#00c800"></span><span>Ready — waiting for you to speak</span></div>
        <div class="help-row"><span class="help-dot" style="background:#ff0000"></span><span>Recording — hold your key and speak</span></div>
        <div class="help-row"><span class="help-dot" style="background:#ffc800"></span><span>Transcribing — processing your audio</span></div>
        <div class="help-row"><span class="help-dot" style="background:#0064ff"></span><span>Typing — text is being inserted</span></div>
        <div class="help-row"><span class="help-dot" style="background:#ffa500"></span><span>Not connected — click the tray to log in</span></div>
        <div class="help-row"><span class="help-dot" style="background:#808080"></span><span>Error — check logs for details</span></div>
      </div>
      <div class="sep"></div>
      <div class="section-label">How to dictate</div>
      <div class="help-text">Hold your push-to-talk key, speak, then release. The transcribed text appears at your cursor.</div>
    </div>

    <!-- Contact -->
    <div class="section-content" id="section-contact">
      <div class="section-label">Get in touch</div>
      <div class="help-text" style="margin-bottom:16px">For questions, feedback, or support:</div>
      <div class="help-text" style="display:flex;align-items:center;gap:6px">
        <span style="color:#2563eb;font-weight:500">contact@alto-dictation.com</span>
        <button onclick="copyEmail(this)" title="Copy email" style="border:none;background:none;cursor:pointer;padding:2px;display:flex;opacity:0.4" onmouseover="this.style.opacity='0.8'" onmouseout="this.style.opacity='0.4'"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg></button>
        <span id="copy-msg" style="font-size:11px;color:#16a34a;display:none">Copied!</span>
      </div>
      <div class="sep"></div>
      <div class="section-label">Links</div>
      <div class="help-text"><a href="https://alto-dictation.com" target="_blank" style="color:#2563eb;text-decoration:none">alto-dictation.com</a></div>
      <div class="help-text" style="margin-top:6px"><a href="https://alto-dictation.com/privacy" target="_blank" style="color:#2563eb;text-decoration:none">Privacy policy</a></div>
      <div class="help-text" style="margin-top:6px"><a href="https://alto-dictation.com/terms" target="_blank" style="color:#2563eb;text-decoration:none">Terms of service</a></div>
    </div>
  </div>
</div>

<div class="actions">
  <span class="pause-notice">Dictation is paused while this window is open</span>
  <button class="btn btn-cancel" onclick="cancel()">Cancel</button>
  <button class="btn btn-save" onclick="save()">Save</button>
</div>

<!-- Cancel subscription modal -->
<div class="modal-overlay" id="cancel-modal">
  <div class="modal">
    <h3>Cancel subscription?</h3>
    <p>You will keep access to your current plan until the end of your billing period.</p>
    <div class="modal-actions">
      <button class="modal-btn modal-btn-cancel" onclick="closeModal()">Keep plan</button>
      <button class="modal-btn modal-btn-confirm" id="confirm-cancel-btn" onclick="confirmCancel()">Cancel subscription</button>
    </div>
  </div>
</div>

<script>
var currentKey = "{current_key}";

function showSection(name) {
  document.querySelectorAll('.section-content').forEach(function(s) { s.classList.remove('active'); });
  document.querySelectorAll('.sidebar-item').forEach(function(s) { s.classList.remove('active'); });
  document.getElementById('section-' + name).classList.add('active');
  document.querySelector('[data-section="' + name + '"]').classList.add('active');
}

function copyEmail(btn) {
  var t = document.createElement('textarea');
  t.value = 'contact@alto-dictation.com';
  document.body.appendChild(t);
  t.select();
  document.execCommand('copy');
  document.body.removeChild(t);
  var msg = document.getElementById('copy-msg');
  msg.style.display = 'inline';
  setTimeout(function() { msg.style.display = 'none'; }, 1500);
}

function formatKey(k) {
  var parts = k.split('+');
  var out = [];
  for (var i = 0; i < parts.length; i++) {
    var p = parts[i].trim();
    if (p === 'CTRL' || p === 'SHIFT' || p === 'ALT' || p === 'SUPER') {
      out.push(p.charAt(0) + p.slice(1).toLowerCase());
    } else {
      p = p.replace('KEY_', '');
      if (p === 'GRAVE') p = '`';
      else if (p === 'SPACE') p = 'Space';
      else if (p === 'TAB') p = 'Tab';
      else if (p === 'ENTER') p = 'Enter';
      else if (p === 'BACKSPACE') p = 'Backspace';
      else if (p === 'ESC' || p === 'ESCAPE') p = 'Esc';
      else if (p.length === 1) p = p.toUpperCase();
      else p = p.charAt(0).toUpperCase() + p.slice(1).toLowerCase();
      out.push(p);
    }
  }
  return out.join(' + ');
}

function detectKey() {
  var btn = document.getElementById('detect-btn');
  btn.textContent = 'Press a key...';
  btn.classList.add('detecting');
  btn.disabled = true;
  pywebview.api.detect_key().then(function(key) {
    if (key) {
      currentKey = key;
      document.getElementById('key-display').textContent = formatKey(key);
    }
    btn.textContent = 'Change';
    btn.classList.remove('detecting');
    btn.disabled = false;
  });
}

function save() {
  var data = JSON.stringify({
    language: document.getElementById('language').value,
    evdev_key: currentKey
  });
  pywebview.api.save_settings(data);
}

function cancel() {
  pywebview.api.close_window();
}

var pendingUpgradeTier = '';
function upgradePlan(tier) {
  pendingUpgradeTier = tier;
  var label = tier.charAt(0).toUpperCase() + tier.slice(1);
  document.getElementById('cancel-modal').classList.add('visible');
  document.querySelector('#cancel-modal .modal h3').textContent = 'Change to ' + label + '?';
  document.querySelector('#cancel-modal .modal p').textContent = 'Your plan will change immediately. Proration will be applied to your next invoice.';
  document.querySelector('#cancel-modal .modal-actions').innerHTML =
    '<button class="modal-btn modal-btn-cancel" onclick="closeModal()">Keep current plan</button>' +
    '<button class="modal-btn" style="background:#1a1a1a;color:#fff" onclick="doUpgrade()">Change to ' + label + '</button>';
}
function doUpgrade() { confirmUpgrade(pendingUpgradeTier); }

function confirmUpgrade(tier) {
  var btns = document.querySelectorAll('#cancel-modal .modal-btn');
  btns.forEach(function(b) { b.disabled = true; });
  btns[btns.length - 1].textContent = 'Changing...';
  pywebview.api.upgrade_subscription(tier).then(function(ok) {
    if (ok) {
      document.querySelector('#cancel-modal .modal h3').textContent = 'Plan changed!';
      document.querySelector('#cancel-modal .modal p').textContent = 'Your new plan is active. Proration has been applied.';
      document.querySelector('#cancel-modal .modal-actions').innerHTML = '<button class="modal-btn modal-btn-cancel" onclick="pywebview.api.close_window()">Close</button>';
    } else {
      document.querySelector('#cancel-modal .modal h3').textContent = 'Error';
      document.querySelector('#cancel-modal .modal p').textContent = 'Could not change plan. Please try again later.';
      document.querySelector('#cancel-modal .modal-actions').innerHTML = '<button class="modal-btn modal-btn-cancel" onclick="closeModal()">Close</button>';
    }
  });
}

function resetPassword() {
  pywebview.api.open_url(window._resetPasswordUrl || 'https://api.alto-dictation.com/v1/auth/forgot-password');
}

function cancelSubscription() {
  document.getElementById('cancel-modal').classList.add('visible');
}

function closeModal() {
  document.getElementById('cancel-modal').classList.remove('visible');
}

function confirmCancel() {
  var btn = document.getElementById('confirm-cancel-btn');
  btn.textContent = 'Canceling...';
  btn.disabled = true;
  pywebview.api.cancel_subscription().then(function(ok) {
    if (ok) {
      document.querySelector('#cancel-modal .modal h3').textContent = 'Subscription canceled';
      document.querySelector('#cancel-modal .modal p').textContent = 'You keep access until the end of your billing period.';
      document.querySelector('#cancel-modal .modal-actions').innerHTML = '<button class="modal-btn modal-btn-cancel" onclick="pywebview.api.close_window()">Close</button>';
    } else {
      document.querySelector('#cancel-modal .modal h3').textContent = 'Error';
      document.querySelector('#cancel-modal .modal p').textContent = 'Could not cancel subscription. Please try again later.';
      document.querySelector('#cancel-modal .modal-actions').innerHTML = '<button class="modal-btn modal-btn-cancel" onclick="closeModal()">Close</button>';
    }
  });
}

document.getElementById('key-display').textContent = formatKey(currentKey);
</script>
</body>
</html>"""


def _build_account_html(api_client: Optional["AltoAPIClient"]) -> tuple[str, str]:
    if api_client is None:
        return "", "none"
    try:
        user_info = api_client.get_me()
    except Exception:
        return '<span class="not-connected">Not connected</span>', "block"

    import html as html_mod
    email = html_mod.escape(user_info.get("email", ""))
    t = user_info.get("tier", "free")
    tier_display = html_mod.escape(t.capitalize())
    tier_class = t if t in ("free", "pro", "max") else "free"

    html = '<div class="account">'
    html += '<div class="account-left">'
    html += f'<span class="account-email">{email}<span class="tier-badge {tier_class}">{tier_display}</span></span>'

    try:
        usage = api_client.get_usage()
        secs = usage.get("audio_seconds", 0)
        mins = secs / 60.0
        lim = {"free": 15, "pro": 180, "max": 600}.get(t, 0)
        if lim > 0:
            html += f'<span class="account-meta">{mins:.1f} / {lim} min this month</span>'
        else:
            html += f'<span class="account-meta">{mins:.1f} min this month</span>'
    except Exception:
        pass

    html += '</div>'
    html += '</div>'  # close .account

    # Usage bar
    try:
        if lim > 0:
            pct = min(1.0, mins / lim)
            cls = " crit" if pct >= 0.9 else (" warn" if pct >= 0.7 else "")
            html += f'<div class="usage"><div class="bar"><div class="bar-fill{cls}" style="width:{pct*100:.0f}%"></div></div></div>'
    except Exception:
        pass

    return html, "block"


def _build_subscription_html(api_client: Optional["AltoAPIClient"]) -> str:
    """Build the subscription summary + plan cards HTML."""
    if api_client is None:
        return '<span class="not-connected">Log in to manage your subscription.</span>'

    try:
        user_info = api_client.get_me()
    except Exception:
        return '<span class="not-connected">Could not load subscription info.</span>'

    t = user_info.get("tier", "free")
    active = user_info.get("subscription_active", False)

    html = ""

    # Subscription summary block (only for paying users)
    if active and t in ("pro", "max"):
        sub_info = None
        try:
            sub_info = api_client.get_subscription_info()
            logger.info(f"Subscription info: {sub_info is not None}")
        except Exception as e:
            logger.warning(f"Failed to get subscription info: {e}")

        if sub_info:
            import html as html_mod
            status_str = sub_info.get("subscription_status", "active")
            price = html_mod.escape(sub_info.get("price", ""))
            period_end = sub_info.get("current_period_end") or sub_info.get("next_billing_date") or sub_info.get("subscription_ends_at")

            # Format dates
            def _fmt_date(iso_str):
                if not iso_str:
                    return None
                try:
                    from datetime import datetime
                    dt = datetime.fromisoformat(iso_str.replace("Z", "+00:00"))
                    return dt.strftime("%B %d, %Y")
                except Exception:
                    return iso_str

            period_end = sub_info.get("current_period_end") or sub_info.get("subscription_period_end") or sub_info.get("subscription_ends_at")
            period_start = sub_info.get("subscription_period_start")
            end_display = _fmt_date(period_end)
            start_display = _fmt_date(period_start)

            # Format status
            if status_str == "active":
                status_display = '<span style="color:#16a34a;font-weight:500">Active</span>'
            elif status_str == "scheduled_cancel":
                status_display = '<span style="color:#ea580c;font-weight:500">Ends ' + (end_display or "end of period") + '</span>'
            elif status_str == "scheduled_downgrade":
                status_display = '<span style="color:#ea580c;font-weight:500">Changes ' + (end_display or "end of period") + '</span>'
            elif status_str == "past_due":
                status_display = '<span style="color:#dc2626;font-weight:500">Payment failed</span>'
            else:
                status_display = status_str.replace("_", " ").capitalize()

            # Date labels
            date_label = ""
            if end_display and status_str == "active":
                date_label = f"Renews: {end_display}"
            period_label = ""
            if start_display and end_display:
                period_label = f"Current period: {start_display} — {end_display}"

            # Usage
            usage = sub_info.get("usage", {})
            mins = usage.get("audio_seconds", 0) / 60.0
            lim = {"pro": 180, "max": 600}.get(t, 0)

            html += '<div class="sub-summary">'
            html += '<div class="sub-header">'
            html += f'<span class="account-email">{t.capitalize()} plan<span class="tier-badge {t}">{price}</span></span>'
            html += f'<span class="sub-status">{status_display}</span>'
            html += '</div>'
            if date_label:
                html += f'<div class="account-meta">{date_label}</div>'
            if period_label:
                html += f'<div class="account-meta">{period_label}</div>'
            if lim > 0:
                pct = min(1.0, mins / lim)
                cls = " crit" if pct >= 0.9 else (" warn" if pct >= 0.7 else "")
                html += f'<div class="account-meta" style="margin-top:8px">{mins:.1f} / {lim} min this month</div>'
                html += f'<div class="usage"><div class="bar"><div class="bar-fill{cls}" style="width:{pct*100:.0f}%"></div></div></div>'
            html += '</div>'

    plans = [
        {"id": "free", "name": "Free", "price": "0 EUR", "quota": "15 min/month", "limit": "50 requests/month"},
        {"id": "pro", "name": "Pro", "price": "5 EUR", "quota": "180 min/month", "limit": "Unlimited requests"},
        {"id": "max", "name": "Max", "price": "9 EUR", "quota": "600 min/month", "limit": "Unlimited requests"},
    ]

    # Pre-generate checkout URLs (only for FREE users — subscribed users use upgrade)
    checkout_urls = {}
    if not active:
        for plan in plans:
            if plan["id"] != "free":
                try:
                    url = api_client.create_checkout(plan["id"])
                    if url:
                        checkout_urls[plan["id"]] = url
                except Exception:
                    pass

    html += '<div class="plans">'
    for plan in plans:
        is_current = (plan["id"] == t) if active else (plan["id"] == "free")
        is_featured = plan["id"] == "max" and not is_current

        card_class = "plan-card"
        if is_current:
            card_class += " current"
        elif is_featured:
            card_class += " featured"

        html += f'<div class="{card_class}">'

        if is_current:
            html += '<span class="plan-badge current-badge">Current</span>'
        elif is_featured:
            html += '<span class="plan-badge popular-badge">Popular</span>'

        html += f'<div class="plan-name">{plan["name"]}</div>'
        html += f'<div class="plan-price">{plan["price"]}<span>/mo</span></div>'
        html += f'<div class="plan-quota">{plan["quota"]}</div>'

        if is_current:
            html += '<div class="plan-current-label">&#10003; Your plan</div>'
        elif plan["id"] == "free" and active:
            # Downgrade to free = cancel subscription
            html += '<button class="plan-btn plan-btn-secondary" onclick="cancelSubscription()">Choose Free</button>'
        elif plan["id"] == "free":
            html += '<div class="plan-current-label"></div>'
        elif active:
            # Subscribed user changing plan = upgrade via Creem API (no new checkout)
            html += f'<button class="plan-btn plan-btn-primary" onclick="upgradePlan(\'{plan["id"]}\')">Choose {plan["name"]}</button>'
        elif plan["id"] in checkout_urls:
            # Free user subscribing = checkout (new subscription)
            html += f'<a class="plan-btn plan-btn-primary" href="{checkout_urls[plan["id"]]}" target="_blank">Choose {plan["name"]}</a>'

        html += '</div>'

    html += '</div>'

    return html


def _build_billing_html(api_client: Optional["AltoAPIClient"]) -> str:
    """Build the billing/payment history HTML."""
    if api_client is None:
        return '<div class="billing-empty">Log in to view payment history.</div>'

    try:
        payments = api_client.get_payments()
    except Exception:
        return '<div class="billing-empty">Could not load payment history.</div>'

    if not payments:
        html = '<div class="billing-empty">No payments yet.</div>'
    else:
        html = '<table class="billing-table">'
        html += '<thead><tr><th>Date</th><th>Amount</th><th>Plan</th><th>Status</th></tr></thead>'
        html += '<tbody>'
        for p in payments:
            # Format date
            date_str = p.get("date", "")
            try:
                from datetime import datetime
                dt = datetime.fromisoformat(date_str.replace("Z", "+00:00"))
                date_display = dt.strftime("%b %d, %Y")
            except Exception:
                date_display = date_str[:10] if date_str else "-"

            amount = p.get("amount", "-")
            tier = (p.get("tier") or "-").capitalize()
            status = p.get("status", "succeeded")
            ptype = p.get("type", "charge")

            if status == "succeeded":
                status_display = '<span class="status-paid">Paid</span>'
            elif status == "refunded":
                status_display = '<span class="status-refunded">Refunded</span>'
            elif status == "disputed":
                status_display = '<span class="status-disputed">Disputed</span>'
            else:
                status_display = status.capitalize()

            if ptype == "refund":
                amount = "-" + amount if not amount.startswith("-") else amount

            import html as html_mod
            html += f'<tr><td>{html_mod.escape(date_display)}</td><td>{html_mod.escape(str(amount))}</td>'
            html += f'<td>{html_mod.escape(tier)}</td><td>{status_display}</td></tr>'

        html += '</tbody></table>'

    # Add "View invoices" link to Creem portal
    try:
        portal_url = api_client.get_billing_portal()
        if portal_url:
            html += f'<a class="invoice-link" href="{portal_url}" target="_blank">View invoices on Creem</a>'
    except Exception:
        pass

    return html


def _build_language_options(current: str) -> str:
    return "".join(
        f'<option value="{code}" {"selected" if code == current else ""}>{name} ({code})</option>'
        for code, name in LANGUAGES.items()
    )


def open_settings_window(
    config: ServiceConfig,
    config_path: Path,
    on_close: Optional[Callable[[bool], None]] = None,
    api_client: Optional["AltoAPIClient"] = None,
    # Legacy compat
    on_save: Optional[Callable[[], None]] = None,
    hotkey_listener: Optional["HotkeyListener"] = None,
) -> None:
    thread = threading.Thread(
        target=_run_settings,
        args=(config, config_path, on_close or (lambda saved: on_save() if saved and on_save else None), api_client),
        daemon=True,
        name="SettingsWindow",
    )
    thread.start()


def _run_settings(
    config: ServiceConfig,
    config_path: Path,
    on_close: Optional[Callable[[bool], None]],
    api_client: Optional["AltoAPIClient"],
) -> None:
    # Build page HTML
    account_html, account_display = _build_account_html(api_client)
    subscription_html = _build_subscription_html(api_client)
    billing_html = _build_billing_html(api_client)
    page = (
        _SETTINGS_HTML
        .replace("{account_display}", account_display)
        .replace("{account_html}", account_html)
        .replace("{subscription_html}", subscription_html)
        .replace("{billing_html}", billing_html)
        .replace("{language_options}", _build_language_options(config.language))
        .replace("{current_key}", config.evdev_key)
    )

    # Build meta for subprocess (cancel URL + auth)
    meta = {}
    if api_client:
        meta["cancel_url"] = f"{api_client.base_url}/v1/billing/cancel"
        meta["reset_password_url"] = f"{api_client.base_url}/v1/auth/forgot-password"
        if api_client._access_token:
            meta["auth_header"] = f"Bearer {api_client._access_token}"

    stdin_data = page + "\n---SETTINGS_META---\n" + json.dumps(meta)

    # Run webview in a subprocess (GTK needs the main thread)
    proc = subprocess.run(
        [sys.executable, "-c", _SUBPROCESS_CODE],
        input=stdin_data,
        capture_output=True,
        text=True,
        timeout=600,
    )

    logger.info(f"Settings subprocess stdout: {proc.stdout.strip()!r}")

    result = None
    stdout = proc.stdout.strip()
    # Extract last line (JSON result), ignore any prior debug output
    if stdout:
        last_line = stdout.splitlines()[-1]
        try:
            result = json.loads(last_line)
        except json.JSONDecodeError:
            logger.warning(f"Settings subprocess output not JSON: {last_line!r}")

    if proc.stderr.strip():
        for line in proc.stderr.strip().split("\n"):
            if "Gtk" not in line and "WARNING" not in line:
                logger.debug(f"Settings subprocess: {line}")

    logger.info(f"Settings subprocess exited with code {proc.returncode}")

    saved = False
    if result and result.get("saved"):
        config.language = result.get("language", config.language)
        config.evdev_key = result.get("evdev_key", config.evdev_key)
        try:
            config.validate()
            save_config(config_path, config)
            logger.info("Settings saved")
            saved = True
        except Exception as e:
            logger.error(f"Settings save error: {e}")

    logger.info(f"Settings window closed (saved={saved}), calling on_close")
    if on_close:
        on_close(saved)


# Code executed in the subprocess — receives HTML on stdin, outputs JSON on stdout
_SUBPROCESS_CODE = '''
import json
import sys
import threading

raw = sys.stdin.read()
parts = raw.split('\\n---SETTINGS_META---\\n', 1)
html = parts[0]
meta = json.loads(parts[1]) if len(parts) > 1 else {}
cancel_url = meta.get('cancel_url', '')
auth_header = meta.get('auth_header', '')
reset_password_url = meta.get('reset_password_url', 'https://api.alto-dictation.com/v1/auth/forgot-password')
result = {"saved": False}

def detect_key(timeout=10.0):
    try:
        import select, time, evdev
        from evdev import InputDevice, ecodes
        MOD_CODES = {
            "CTRL": {ecodes.KEY_LEFTCTRL, ecodes.KEY_RIGHTCTRL},
            "SHIFT": {ecodes.KEY_LEFTSHIFT, ecodes.KEY_RIGHTSHIFT},
            "ALT": {ecodes.KEY_LEFTALT, ecodes.KEY_RIGHTALT},
            "SUPER": {ecodes.KEY_LEFTMETA, ecodes.KEY_RIGHTMETA},
        }
        ALL_MODS = set()
        for codes in MOD_CODES.values():
            ALL_MODS |= codes
        BLOCKED = {
            frozenset({"CTRL"}): None,
            frozenset({"SUPER"}): None,
            frozenset({"ALT"}): {"KEY_TAB", "KEY_F4", "KEY_F1", "KEY_F2", "KEY_F3"},
            frozenset({"CTRL", "ALT"}): {"KEY_DELETE", "KEY_T", "KEY_L"},
            frozenset({"CTRL", "SHIFT"}): {"KEY_C", "KEY_V", "KEY_Q", "KEY_T", "KEY_N", "KEY_Z", "KEY_ESC"},
        }
        devices = []
        for path in evdev.list_devices():
            try:
                dev = InputDevice(path)
                if "alto" in dev.name.lower():
                    dev.close()
                    continue
                caps = dev.capabilities(verbose=False)
                if ecodes.EV_KEY in caps:
                    devices.append(dev)
            except (OSError, PermissionError):
                continue
        if not devices:
            return ""
        fd_map = {dev.fd: dev for dev in devices}
        held_mods = set()
        deadline = time.time() + timeout
        try:
            while time.time() < deadline:
                r, _, _ = select.select(fd_map.keys(), [], [], 0.2)
                for fd in r:
                    dev = fd_map[fd]
                    for event in dev.read():
                        if event.type != ecodes.EV_KEY:
                            continue
                        if event.code in ALL_MODS:
                            if event.value == 1:
                                held_mods.add(event.code)
                            elif event.value == 0:
                                held_mods.discard(event.code)
                            continue
                        if event.value == 1 and event.code < 272:
                            key_event = evdev.categorize(event)
                            name = key_event.keycode
                            if isinstance(name, (list, tuple)):
                                name = name[0]
                            mod_names = set()
                            for mn, mc in MOD_CODES.items():
                                if held_mods & mc:
                                    mod_names.add(mn)
                            if mod_names:
                                mods_frozen = frozenset(mod_names)
                                blocked = BLOCKED.get(mods_frozen)
                                if blocked is None and mods_frozen in BLOCKED:
                                    continue
                                if blocked and name in blocked:
                                    continue
                                return "+".join(sorted(mod_names)) + "+" + name
                            return name
        finally:
            for dev in devices:
                try: dev.close()
                except: pass
    except Exception:
        pass
    return ""

class Api:
    def detect_key(self):
        return detect_key()

    def cancel_subscription(self):
        try:
            import urllib.request
            req = urllib.request.Request(
                cancel_url,
                method='POST',
                headers={'Authorization': auth_header, 'Content-Type': 'application/json'},
            )
            resp = urllib.request.urlopen(req, timeout=15)
            return resp.status == 200
        except Exception:
            return False

    def upgrade_subscription(self, tier):
        try:
            import urllib.request, json as _json
            upgrade_url = cancel_url.replace('/cancel', '/upgrade')
            body = _json.dumps({"tier": tier}).encode()
            req = urllib.request.Request(
                upgrade_url,
                data=body,
                method='POST',
                headers={'Authorization': auth_header, 'Content-Type': 'application/json'},
            )
            resp = urllib.request.urlopen(req, timeout=15)
            return resp.status == 200
        except Exception:
            return False

    def save_settings(self, data_json):
        data = json.loads(data_json)
        result["saved"] = True
        result["language"] = data.get("language", "en")
        result["evdev_key"] = data.get("evdev_key", "KEY_GRAVE")
        # Delay destroy to let the js_bridge_call wrapper finish first
        threading.Timer(0.2, window.destroy).start()

    def open_url(self, url):
        import webbrowser
        webbrowser.open(url)

    def close_window(self):
        threading.Timer(0.1, window.destroy).start()

    def upgrade(self):
        pass

import webview
api = Api()
window = webview.create_window("Alto", html=html, js_api=api,
                               width=600, height=480, resizable=False,
                               text_select=False)

def on_loaded():
    import json as _j
    window.evaluate_js('window._resetPasswordUrl = ' + _j.dumps(reset_password_url) + ';')

window.events.loaded += on_loaded
webview.start()
print(json.dumps(result), flush=True)
'''


def _detect_next_key(timeout: float = 10.0) -> str:
    """Fallback key detection (used outside webview)."""
    try:
        import select
        import time
        import evdev
        from evdev import InputDevice, ecodes

        devices = []
        for path in evdev.list_devices():
            try:
                dev = InputDevice(path)
                if "alto" in dev.name.lower():
                    dev.close()
                    continue
                caps = dev.capabilities(verbose=False)
                if ecodes.EV_KEY in caps:
                    devices.append(dev)
            except (OSError, PermissionError):
                continue
        if not devices:
            return ""
        fd_map = {dev.fd: dev for dev in devices}
        deadline = time.time() + timeout
        try:
            while time.time() < deadline:
                r, _, _ = select.select(fd_map.keys(), [], [], 0.2)
                for fd in r:
                    dev = fd_map[fd]
                    for event in dev.read():
                        if event.type == ecodes.EV_KEY and event.value == 1 and event.code < 272:
                            from evdev import categorize
                            key_event = categorize(event)
                            name = key_event.keycode
                            if isinstance(name, (list, tuple)):
                                name = name[0]
                            return name
        finally:
            for dev in devices:
                try:
                    dev.close()
                except Exception:
                    pass
    except Exception as e:
        logger.error(f"Key detection failed: {e}")
    return ""
