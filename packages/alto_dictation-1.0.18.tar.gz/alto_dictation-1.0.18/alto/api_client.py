"""
HTTP client for the Alto backend API.

Handles authentication, token refresh, and transcription requests
for the SaaS (cloud) mode.
"""

import json
import logging
import os
import socket
import ssl
import time
import urllib.error
import urllib.request
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from threading import Event, Thread
from typing import Optional
from urllib.parse import parse_qs, urlparse

logger = logging.getLogger(__name__)

# Default credentials path
CREDENTIALS_PATH = Path.home() / ".alto" / "credentials.json"


class AltoAPIClient:
    """Client for the Alto backend API.

    Manages authentication (JWT tokens), automatic token refresh,
    and transcription proxy requests.

    Args:
        base_url: Base URL of the Alto API (e.g., "https://api.alto-dictation.com").
        credentials_path: Path to the credentials file.
    """

    def __init__(
        self,
        base_url: str = "https://api.alto-dictation.com",
        credentials_path: Optional[Path] = None,
    ):
        self.base_url = base_url.rstrip("/")
        self.credentials_path = credentials_path or CREDENTIALS_PATH
        self._access_token: Optional[str] = None
        self._refresh_token: Optional[str] = None
        self._token_expires_at: float = 0.0
        self._user_info: Optional[dict] = None

        # Load saved credentials
        self._load_credentials()

    def _load_credentials(self) -> None:
        """Load saved credentials from disk."""
        if not self.credentials_path.exists():
            return

        try:
            with open(self.credentials_path, "r") as f:
                data = json.load(f)
            self._access_token = data.get("access_token")
            self._refresh_token = data.get("refresh_token")
            self._token_expires_at = data.get("expires_at", 0.0)
            logger.debug("Loaded saved credentials")
        except (json.JSONDecodeError, OSError) as e:
            logger.warning(f"Failed to load credentials: {e}")

    def _save_credentials(self) -> None:
        """Save credentials to disk with restricted permissions."""
        self.credentials_path.parent.mkdir(parents=True, exist_ok=True)

        data = {
            "access_token": self._access_token,
            "refresh_token": self._refresh_token,
            "expires_at": self._token_expires_at,
        }

        # Write atomically
        tmp_path = self.credentials_path.with_suffix(".tmp")
        try:
            with open(tmp_path, "w") as f:
                json.dump(data, f, indent=2)
            # Set restrictive permissions before moving into place
            os.chmod(tmp_path, 0o600)
            os.replace(tmp_path, self.credentials_path)
            logger.debug("Credentials saved")
        except OSError as e:
            logger.error(f"Failed to save credentials: {e}")
            try:
                tmp_path.unlink(missing_ok=True)
            except OSError:
                pass

    def _clear_credentials(self) -> None:
        """Remove saved credentials."""
        self._access_token = None
        self._refresh_token = None
        self._token_expires_at = 0.0
        self._user_info = None

        try:
            self.credentials_path.unlink(missing_ok=True)
            logger.debug("Credentials cleared")
        except OSError as e:
            logger.warning(f"Failed to remove credentials file: {e}")

    def _request(
        self,
        method: str,
        path: str,
        data: Optional[dict] = None,
        headers: Optional[dict] = None,
        body: Optional[bytes] = None,
        content_type: Optional[str] = None,
        timeout: int = 30,
    ) -> dict:
        """Make an HTTP request to the API.

        Args:
            method: HTTP method.
            path: API path (e.g., "/v1/auth/login").
            data: JSON body (for POST requests).
            headers: Additional headers.
            body: Raw body bytes (for file uploads).
            content_type: Content-Type header override.
            timeout: Request timeout in seconds.

        Returns:
            Parsed JSON response.

        Raises:
            APIError: On HTTP errors.
        """
        url = f"{self.base_url}{path}"
        req_headers = headers or {}

        # Send client version for API compatibility checks
        try:
            from alto import __version__
            req_headers["X-Alto-Version"] = __version__
        except ImportError:
            pass

        if body is not None:
            req_body = body
            if content_type:
                req_headers["Content-Type"] = content_type
        elif data is not None:
            req_body = json.dumps(data).encode("utf-8")
            req_headers["Content-Type"] = "application/json"
        else:
            req_body = None

        req = urllib.request.Request(
            url, data=req_body, headers=req_headers, method=method
        )

        try:
            ctx = ssl.create_default_context()
            with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
                response_data = resp.read().decode("utf-8")
                if response_data:
                    return json.loads(response_data)
                return {}
        except urllib.error.HTTPError as e:
            error_body = ""
            try:
                error_body = e.read().decode("utf-8")
            except Exception:
                pass
            raise APIError(e.code, error_body, str(e)) from e
        except urllib.error.URLError as e:
            raise APIError(0, "", f"Connection error: {e.reason}") from e

    def _authenticated_request(
        self, method: str, path: str, **kwargs
    ) -> dict:
        """Make an authenticated request, refreshing the token if needed."""
        self._ensure_authenticated()

        headers = kwargs.pop("headers", {})
        headers["Authorization"] = f"Bearer {self._access_token}"

        try:
            return self._request(method, path, headers=headers, **kwargs)
        except APIError as e:
            if e.status_code == 401 and self._refresh_token:
                # Token expired, try to refresh
                if self._do_refresh():
                    headers["Authorization"] = f"Bearer {self._access_token}"
                    return self._request(method, path, headers=headers, **kwargs)
            raise

    def _ensure_authenticated(self) -> None:
        """Ensure we have a valid access token, refreshing if needed."""
        if not self._access_token:
            raise AuthenticationError("Not logged in. Run 'alto login' first.")

        # Proactively refresh if token expires within 5 minutes
        if self._token_expires_at and time.time() > self._token_expires_at - 300:
            if self._refresh_token:
                self._do_refresh()

    def _do_refresh(self) -> bool:
        """Refresh the access token.

        Returns:
            True if refresh succeeded, False otherwise.
        """
        if not self._refresh_token:
            return False

        try:
            result = self._request("POST", "/v1/auth/refresh", data={
                "refresh_token": self._refresh_token,
            })
            self._access_token = result["access_token"]
            self._refresh_token = result.get("refresh_token", self._refresh_token)
            self._token_expires_at = time.time() + result.get("expires_in", 3600)
            self._save_credentials()
            logger.debug("Token refreshed successfully")
            return True
        except (APIError, KeyError) as e:
            logger.warning(f"Token refresh failed: {e}")
            self._clear_credentials()
            return False

    def login(self, email: str, password: str) -> bool:
        """Authenticate with email and password.

        Args:
            email: User email.
            password: User password.

        Returns:
            True if login succeeded.

        Raises:
            APIError: On authentication failure.
        """
        result = self._request("POST", "/v1/auth/login", data={
            "email": email,
            "password": password,
        })

        self._access_token = result["access_token"]
        self._refresh_token = result.get("refresh_token")
        self._token_expires_at = time.time() + result.get("expires_in", 3600)
        self._save_credentials()

        logger.info(f"Logged in as {email}")
        return True

    def cancel_browser_login(self) -> None:
        """Cancel any in-progress browser login."""
        server = getattr(self, "_login_server", None)
        event = getattr(self, "_login_done_event", None)
        if server:
            server.shutdown()
            self._login_server = None
        if event:
            event.set()
            self._login_done_event = None

    def browser_login(self, timeout: int = 120) -> bool:
        """Authenticate via browser-based login flow.

        Opens the browser to the Alto login page. A local HTTP server
        catches the callback with an auth code, which is exchanged for tokens.

        Args:
            timeout: Max seconds to wait for the user to complete login.

        Returns:
            True if login succeeded.

        Raises:
            TimeoutError: If the user didn't complete login within timeout.
            APIError: On server errors.
        """
        # Cancel any previous pending login
        self.cancel_browser_login()

        # Find a free port
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("127.0.0.1", 0))
            port = s.getsockname()[1]

        auth_code: list[str] = []  # mutable container for closure
        error_msg: list[str] = []
        done_event = Event()
        self._login_done_event = done_event

        class CallbackHandler(BaseHTTPRequestHandler):
            def do_GET(self):
                parsed = urlparse(self.path)
                if parsed.path != "/callback":
                    self.send_error(404)
                    return

                params = parse_qs(parsed.query)
                code = params.get("code", [None])[0]
                err = params.get("error", [None])[0]

                if code:
                    auth_code.append(code)
                    self.send_response(200)
                    self.send_header("Content-Type", "text/html; charset=utf-8")
                    self.end_headers()
                    self.wfile.write(
                        b"<!DOCTYPE html><html><head><style>"
                        b"body{font-family:-apple-system,sans-serif;background:#fafafa;"
                        b"color:#1a1a1a;display:flex;justify-content:center;"
                        b"align-items:center;min-height:100vh;}"
                        b".msg{background:#fff;border:1px solid #e5e5e5;"
                        b"border-radius:12px;padding:48px 56px;text-align:center;}"
                        b"h2{font-size:18px;font-weight:600;margin-bottom:8px;}"
                        b"p{color:#999;font-size:14px;}"
                        b"</style></head><body><div class='msg'>"
                        b"<h2>Login successful</h2>"
                        b"<p>You can close this tab.</p>"
                        b"</div><script>setTimeout(function(){window.close()},1500);</script>"
                        b"</body></html>"
                    )
                elif err:
                    error_msg.append(err)
                    self.send_response(200)
                    self.send_header("Content-Type", "text/html; charset=utf-8")
                    self.end_headers()
                    import html as _html
                    self.wfile.write(f"<h2>Error: {_html.escape(err)}</h2>".encode())
                else:
                    self.send_error(400)
                    return

                done_event.set()

            def log_message(self, format, *args):
                logger.debug(f"Login callback server: {format % args}")

        server = HTTPServer(("127.0.0.1", port), CallbackHandler)
        self._login_server = server
        server_thread = Thread(target=server.serve_forever, daemon=True, name="LoginCallbackServer")
        server_thread.start()

        redirect_uri = f"http://localhost:{port}/callback"
        login_url = f"{self.base_url}/v1/auth/browser-login?redirect_uri={redirect_uri}"

        logger.info(f"Opening browser for login: {login_url}")
        webbrowser.open(login_url)

        try:
            if not done_event.wait(timeout=timeout):
                raise TimeoutError("Browser login timed out")

            if error_msg:
                raise APIError(401, "", f"Login failed: {error_msg[0]}")

            if not auth_code:
                raise APIError(401, "", "No authorization code received")

            # Exchange code for tokens
            result = self._request("POST", "/v1/auth/exchange-code", data={
                "code": auth_code[0],
            })

            self._access_token = result["access_token"]
            self._refresh_token = result.get("refresh_token")
            self._token_expires_at = time.time() + result.get("expires_in", 3600)
            self._save_credentials()

            logger.info("Browser login successful")
            return True
        finally:
            server.shutdown()
            self._login_server = None
            self._login_done_event = None

    def register(self, email: str, password: str) -> bool:
        """Register a new account.

        Args:
            email: User email.
            password: User password.

        Returns:
            True if registration succeeded.

        Raises:
            APIError: On registration failure.
        """
        result = self._request("POST", "/v1/auth/register", data={
            "email": email,
            "password": password,
        })

        self._access_token = result["access_token"]
        self._refresh_token = result.get("refresh_token")
        self._token_expires_at = time.time() + result.get("expires_in", 3600)
        self._save_credentials()

        logger.info(f"Registered and logged in as {email}")
        return True

    def logout(self) -> None:
        """Log out and clear credentials."""
        self._clear_credentials()
        logger.info("Logged out")

    def get_me(self) -> dict:
        """Get current user info and subscription status.

        Returns:
            User info dict with keys: email, tier, subscription_active, etc.
        """
        result = self._authenticated_request("GET", "/v1/auth/me")
        self._user_info = result
        return result

    def get_usage(self) -> dict:
        """Get usage for the current billing period.

        Returns:
            Usage dict with keys: requests, audio_seconds, period, etc.
        """
        return self._authenticated_request("GET", "/v1/usage")

    def transcribe(self, audio_path: Path, language: str = "fr") -> Optional[str]:
        """Send audio to the backend for transcription.

        Args:
            audio_path: Path to the WAV audio file.
            language: Language code for transcription.

        Returns:
            Transcribed text, or None on failure.
        """
        if not audio_path.exists():
            logger.error(f"Audio file not found: {audio_path}")
            return None

        # Build multipart form data
        boundary = f"----AltoUpload{int(time.time() * 1000)}"

        body_parts = []

        # Language field
        body_parts.append(f"--{boundary}".encode())
        body_parts.append(b'Content-Disposition: form-data; name="language"')
        body_parts.append(b"")
        body_parts.append(language.encode())

        # Audio file
        body_parts.append(f"--{boundary}".encode())
        body_parts.append(
            f'Content-Disposition: form-data; name="file"; filename="{audio_path.name}"'.encode()
        )
        body_parts.append(b"Content-Type: audio/wav")
        body_parts.append(b"")
        with open(audio_path, "rb") as f:
            body_parts.append(f.read())

        body_parts.append(f"--{boundary}--".encode())

        body = b"\r\n".join(body_parts)
        content_type = f"multipart/form-data; boundary={boundary}"

        try:
            result = self._authenticated_request(
                "POST", "/v1/transcribe",
                body=body,
                content_type=content_type,
                timeout=60,
            )
            # Track remaining usage for low-quota warnings
            remaining = result.get("usage_remaining_seconds")
            if remaining is not None:
                self._usage_remaining_seconds = remaining
            return result.get("text")
        except APIError as e:
            if e.status_code == 402:
                logger.warning("Usage limit reached. Upgrade your plan to continue.")
                raise UsageLimitError(
                    "Monthly usage limit reached. "
                    "Upgrade to Pro or Unlimited at https://alto-dictation.com/pricing"
                ) from e
            logger.error(f"Transcription API error: {e}")
            return None

    @property
    def usage_remaining_seconds(self) -> float | None:
        """Remaining usage seconds from the last transcription response."""
        return getattr(self, "_usage_remaining_seconds", None)

    def create_checkout(self, tier: str) -> Optional[str]:
        """Create a Creem checkout session.

        Args:
            tier: Subscription tier ("pro" or "max").

        Returns:
            Checkout URL, or None on failure.
        """
        try:
            result = self._authenticated_request(
                "POST", "/v1/billing/checkout",
                data={"tier": tier},
            )
            return result.get("checkout_url")
        except APIError as e:
            logger.error(f"Checkout creation failed: {e}")
            return None

    def get_billing_portal(self) -> Optional[str]:
        """Get the Creem customer billing portal URL.

        Returns:
            Portal URL, or None on failure.
        """
        try:
            result = self._authenticated_request("GET", "/v1/billing/portal")
            return result.get("portal_url")
        except APIError as e:
            logger.error(f"Billing portal request failed: {e}")
            return None

    def get_subscription_info(self) -> Optional[dict]:
        """Get subscription details.

        Returns:
            Dict with tier, price, status, dates, usage. None on failure.
        """
        try:
            return self._authenticated_request("GET", "/v1/billing/subscription")
        except APIError as e:
            logger.error(f"Subscription info request failed: {e}")
            return None

    def get_payments(self) -> list:
        """Get payment history.

        Returns:
            List of payment dicts, or empty list on failure.
        """
        try:
            result = self._authenticated_request("GET", "/v1/billing/payments")
            return result.get("payments", [])
        except APIError as e:
            logger.error(f"Payments request failed: {e}")
            return []

    def upgrade_subscription(self, tier: str) -> bool:
        """Upgrade/downgrade subscription to a different tier.

        Returns:
            True if upgrade was successful.
        """
        try:
            self._authenticated_request("POST", "/v1/billing/upgrade", data={"tier": tier})
            return True
        except APIError as e:
            logger.error(f"Subscription upgrade failed: {e}")
            return False

    def cancel_subscription(self) -> bool:
        """Cancel subscription at end of billing period.

        Returns:
            True if cancellation was scheduled.
        """
        try:
            self._authenticated_request("POST", "/v1/billing/cancel")
            return True
        except APIError as e:
            logger.error(f"Subscription cancellation failed: {e}")
            return False

    def delete_account(self) -> bool:
        """Delete the user's account (GDPR right to erasure).

        Returns:
            True if deletion succeeded.
        """
        try:
            self._authenticated_request("DELETE", "/v1/auth/me")
            self._clear_credentials()
            logger.info("Account deleted")
            return True
        except APIError as e:
            logger.error(f"Account deletion failed: {e}")
            return False

    def is_authenticated(self) -> bool:
        """Check if the client has valid credentials."""
        return self._access_token is not None

    @property
    def cached_user_info(self) -> Optional[dict]:
        """Return the last fetched user info without making a request."""
        return self._user_info


class APIError(Exception):
    """Error from the Alto API."""

    def __init__(self, status_code: int, body: str, message: str = ""):
        self.status_code = status_code
        self.body = body
        detail = ""
        try:
            detail = json.loads(body).get("detail", "")
        except (json.JSONDecodeError, AttributeError):
            pass
        self.detail = detail or message
        super().__init__(f"API error {status_code}: {self.detail}")


class AuthenticationError(APIError):
    """Authentication required."""

    def __init__(self, message: str = "Not authenticated"):
        super().__init__(401, "", message)


class UsageLimitError(APIError):
    """Monthly usage limit exceeded."""

    def __init__(self, message: str = "Usage limit reached"):
        super().__init__(402, "", message)
